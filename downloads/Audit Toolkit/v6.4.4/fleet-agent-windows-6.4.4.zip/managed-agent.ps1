#Requires -Version 5.1
<#
.SYNOPSIS
    Managed Security Audit Agent for Windows - Two-Way API Communication
.DESCRIPTION
    Enhanced agent with full two-way API communication:
    - Remote configuration from central server (server -> agent)
    - Automatic audit script synchronization (server -> agent)
    - Database-compatible result submission (agent -> server)
    - Full integration with reporting and analytics system

    This agent can be deployed once and then managed entirely via API
    without requiring WinRM, SSH, or any inbound connections.
.PARAMETER Mode
    interactive, daemon, poll, register, sync, discovery, upload, run
.PARAMETER ServerUrl
    Central server URL (e.g., https://audit-server.company.com)
.PARAMETER ApiKey
    API key for server authentication
.PARAMETER AgentId
    Unique agent identifier (auto-generated if not provided)
.PARAMETER PollInterval
    Seconds between server polls in daemon mode (default: 60)
.PARAMETER AuditPath
    Specific audit to run (for -Mode run)
.EXAMPLE
    .\fleet-agent.ps1
    Runs in interactive menu mode
.EXAMPLE
    .\fleet-agent.ps1 -Mode daemon -ServerUrl https://audit.company.com -ApiKey abc123
    Runs as background daemon, polling server for commands
.EXAMPLE
    .\fleet-agent.ps1 -Mode run -AuditPath platform/baseline/updates
    Runs a specific audit
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Managed agent provides interactive menu and operator-facing status output by design')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidOverwritingBuiltInCmdlets', '', Justification='Agent logging interface uses Write-Log naming consistently across toolkit scripts')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification='Legacy operational function contracts are preserved; ShouldProcess integration would alter established automation behavior')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Legacy function naming is maintained for backward compatibility with existing orchestration and scripts')]
[CmdletBinding()]
param(
    [ValidateSet('interactive', 'daemon', 'poll', 'register', 'sync', 'discovery', 'upload', 'run', 'rotate-key', 'show-cert', 'self-update')]
    [string]$Mode = 'interactive',

    [string]$ServerUrl = $env:AUDIT_SERVER_URL,

    [string]$ApiKey = $env:AUDIT_API_KEY,

    [string]$AgentId = $env:AUDIT_AGENT_ID,

    [int]$PollInterval = 60,

    [string]$AuditPath,

    # Resource Throttling
    [ValidateSet('Idle', 'BelowNormal', 'Normal', 'AboveNormal', 'High')]
    [string]$ProcessPriority = 'Idle',

    [ValidateRange(5, 95)]
    [int]$MinFreeMemoryPct = 10,

    [ValidateRange(0, 100)]
    [int]$MaxCpuPct = 0,

    # TLS Security Options
    [switch]$SkipCertificateCheck,  # Skip certificate validation (NOT recommended for production)

    [string]$TlsPinnedCertHash = $env:AUDIT_TLS_PINNED_CERT_HASH,  # SHA256 hash of pinned certificate

    [switch]$TlsPinningEnabled = [bool]$env:AUDIT_TLS_PINNING_ENABLED,  # Enable certificate pinning

    # Key Rotation
    [string]$NewApiKey,  # New API key for rotate-key mode

    # Auto-Discovery Configuration
    [switch]$AutoDiscovery = [bool]$env:AUDIT_AUTO_DISCOVERY,  # Enable automatic discovery scans

    [int]$DiscoveryInterval = $(if ($env:AUDIT_DISCOVERY_INTERVAL) { [int]$env:AUDIT_DISCOVERY_INTERVAL } else { 3600 }),  # Discovery interval in seconds

    [string]$AssetDiscoveryUrl = $env:AUDIT_ASSET_DISCOVERY_URL,  # Asset Discovery service URL

    # Elevation Options
    [switch]$RequireElevation = [bool]$env:AUDIT_REQUIRE_ELEVATION,  # Require running as Administrator

    # JEA (Just Enough Administration) Options for AD/Entra ID environments
    [ValidateSet('None', 'JEA', 'RunAs', 'Auto')]
    [string]$ElevationMethod = $(if ($env:AUDIT_ELEVATION_METHOD) { $env:AUDIT_ELEVATION_METHOD } else { 'Auto' }),

    [string]$JeaEndpoint = $env:AUDIT_JEA_ENDPOINT,  # JEA session configuration name (e.g., "AuditAgent.JEA")

    [string]$JeaComputerName = $env:AUDIT_JEA_COMPUTER  # Computer to connect to for JEA (default: localhost)
)

@(
    $ServerUrl,
    $ApiKey,
    $AgentId,
    $PollInterval,
    $ProcessPriority,
    $MinFreeMemoryPct,
    $MaxCpuPct,
    [bool]$SkipCertificateCheck,
    $TlsPinnedCertHash,
    [bool]$TlsPinningEnabled,
    [bool]$AutoDiscovery,
    $DiscoveryInterval,
    $AssetDiscoveryUrl,
    [bool]$RequireElevation,
    $ElevationMethod,
    $JeaEndpoint,
    $JeaComputerName
) | Out-Null

# Persist JEA endpoint selection in script scope so it can be updated from config sync.
$script:JeaEndpoint = $JeaEndpoint
$script:JeaEndpointProvided = $PSBoundParameters.ContainsKey('JeaEndpoint') -or -not [string]::IsNullOrWhiteSpace($env:AUDIT_JEA_ENDPOINT)

# =============================================================================
# Configuration
# =============================================================================
$script:AgentVersion = "6.2.1"
$script:AgentScriptPath = $MyInvocation.MyCommand.Path
$script:AgentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigFile = Join-Path $AgentDir "agent.config.json"
$script:ResultsDir = Join-Path $AgentDir "results"
$script:AuditsDir = Join-Path $AgentDir "audits"
$script:LibDir = Join-Path $AgentDir "lib"
$script:CacheDir = Join-Path $AgentDir ".cache"

$script:ConfigVersion = 0
$script:LastDiscoveryTime = [datetime]::MinValue
$script:HeartbeatTimeout = $(if ($env:AUDIT_HEARTBEAT_TIMEOUT) { [int]$env:AUDIT_HEARTBEAT_TIMEOUT } else { 30 })
$script:MaxHeartbeatFailures = $(if ($env:AUDIT_MAX_HEARTBEAT_FAILURES) { [int]$env:AUDIT_MAX_HEARTBEAT_FAILURES } else { 3 })
$script:ConsecutiveHeartbeatFailures = 0
$script:LastHeartbeatStatus = 'unknown'
$script:LastHeartbeatReason = ''
$script:MaxLocalResultFiles = $(if ($env:AUDIT_AGENT_MAX_LOCAL_RESULT_FILES) { [int]$env:AUDIT_AGENT_MAX_LOCAL_RESULT_FILES } else { 1000 })
$script:MinFreeDiskMB = $(if ($env:AUDIT_MIN_FREE_DISK_MB) { [int]$env:AUDIT_MIN_FREE_DISK_MB } else { 512 })
$script:MinFreeDiskPct = $(if ($env:AUDIT_MIN_FREE_DISK_PCT) { [int]$env:AUDIT_MIN_FREE_DISK_PCT } else { 3 })

# =============================================================================
# Elevation / Privilege Functions
# =============================================================================
function Test-IsElevated {
    <#
    .SYNOPSIS
        Check if the current session is running with administrative privileges
    .RETURNS
        $true if running as Administrator, $false otherwise
    #>
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]$identity
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-Elevation {
    <#
    .SYNOPSIS
        Ensure script is running with elevation, exit if not and required
    .PARAMETER Message
        Optional message to display if not elevated
    #>
    param([string]$Message = "This operation requires administrative privileges.")

    if (-not (Test-IsElevated)) {
        if ($RequireElevation) {
            Write-Log $Message -Level ERROR
            Write-Log "Please run PowerShell as Administrator and try again." -Level ERROR
            exit 1
        } else {
            Write-Log "Not running as Administrator - some audits may have limited access" -Level WARN
        }
    }
}

# =============================================================================
# JEA (Just Enough Administration) Support
# =============================================================================
# JEA allows running audit scripts with elevated privileges through AD/Entra ID
# without requiring the agent to run as Administrator

$script:JeaSession = $null
$script:JeaAvailable = $false
$script:ElevationMode = 'None'

function Test-JeaEndpointAvailable {
    <#
    .SYNOPSIS
        Check if a JEA endpoint is available and accessible
    .PARAMETER EndpointName
        Name of the JEA session configuration
    .RETURNS
        $true if endpoint exists and is accessible
    #>
    param([string]$EndpointName)

    if ([string]::IsNullOrEmpty($EndpointName)) { return $false }

    try {
        $computerName = if ($JeaComputerName) { $JeaComputerName } else { 'localhost' }

        # Check if the session configuration exists
        $config = Get-PSSessionConfiguration -Name $EndpointName -ErrorAction SilentlyContinue
        if (-not $config) {
            Write-Log "JEA endpoint '$EndpointName' not found" -Level DEBUG
            return $false
        }

        # Try to create a test session
        $testSession = New-PSSession -ComputerName $computerName -ConfigurationName $EndpointName -ErrorAction Stop
        Remove-PSSession $testSession -ErrorAction SilentlyContinue

        Write-Log "JEA endpoint '$EndpointName' is available" -Level DEBUG
        return $true
    }
    catch {
        Write-Log "JEA endpoint test failed: $_" -Level DEBUG
        return $false
    }
}

function Get-JeaSession {
    <#
    .SYNOPSIS
        Get or create a JEA session for privileged operations
    .RETURNS
        PSSession object connected to JEA endpoint
    #>
    if ($script:JeaSession -and $script:JeaSession.State -eq 'Opened') {
        return $script:JeaSession
    }

    if ([string]::IsNullOrEmpty($script:JeaEndpoint)) {
        throw "JEA endpoint not configured"
    }

    $computerName = if ($JeaComputerName) { $JeaComputerName } else { 'localhost' }

    try {
        $script:JeaSession = New-PSSession -ComputerName $computerName -ConfigurationName $script:JeaEndpoint -ErrorAction Stop
        Write-Log "Connected to JEA endpoint: $script:JeaEndpoint" -Level INFO
        return $script:JeaSession
    }
    catch {
        Write-Log "Failed to connect to JEA endpoint: $_" -Level ERROR
        throw
    }
}

function Close-JeaSession {
    <#
    .SYNOPSIS
        Close the JEA session if open
    #>
    if ($script:JeaSession) {
        Remove-PSSession $script:JeaSession -ErrorAction SilentlyContinue
        $script:JeaSession = $null
    }
}

function Invoke-PrivilegedCommand {
    <#
    .SYNOPSIS
        Run a command with elevated privileges using the configured method
    .PARAMETER ScriptBlock
        Script block to execute
    .PARAMETER ArgumentList
        Arguments to pass to the script block
    .RETURNS
        Output from the command
    #>
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,

        [object[]]$ArgumentList = @()
    )

    switch ($script:ElevationMode) {
        'JEA' {
            try {
                $session = Get-JeaSession
                return Invoke-Command -Session $session -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList
            }
            catch {
                Write-Log "JEA command failed: $_" -Level WARN
                # Fall back to direct execution
                return & $ScriptBlock @ArgumentList
            }
        }
        'Admin' {
            # Already running as admin
            return & $ScriptBlock @ArgumentList
        }
        default {
            # Run directly (may have limited access)
            return & $ScriptBlock @ArgumentList
        }
    }
}

function Invoke-PrivilegedScript {
    <#
    .SYNOPSIS
        Run an audit script with elevated privileges
    .PARAMETER ScriptPath
        Path to the PowerShell script
    .PARAMETER Arguments
        Arguments to pass to the script
    .RETURNS
        Output from the script
    #>
    param(
        [Parameter(Mandatory)]
        [string]$ScriptPath,

        [hashtable]$Arguments = @{}
    )

    if (-not (Test-Path $ScriptPath)) {
        throw "Script not found: $ScriptPath"
    }

    $fullScriptPath = [System.IO.Path]::GetFullPath($ScriptPath)
    $agentRoot = [System.IO.Path]::GetFullPath($script:AgentDir)
    $auditsRoot = [System.IO.Path]::GetFullPath((Join-Path $script:AgentDir 'audits'))
    $fleetAgentPath = [System.IO.Path]::GetFullPath((Join-Path $script:AgentDir 'fleet-agent.ps1'))

    $isAuditScript = $fullScriptPath.StartsWith($auditsRoot, [System.StringComparison]::OrdinalIgnoreCase)
    $isDiscoveryScript = $fullScriptPath.Equals($fleetAgentPath, [System.StringComparison]::OrdinalIgnoreCase)

    if (-not ($isAuditScript -or $isDiscoveryScript)) {
        throw "Rejected script path outside elevated scope: $ScriptPath"
    }

    switch ($script:ElevationMode) {
        'JEA' {
            try {
                $session = Get-JeaSession

                if ($isAuditScript) {
                    $relativeAuditPath = $fullScriptPath.Substring($agentRoot.Length).TrimStart('\\', '/') -replace '/', '\\'
                    $auditParameters = $Arguments
                    return Invoke-Command -Session $session -ScriptBlock {
                        Invoke-AuditScript -ScriptPath $using:relativeAuditPath -Parameters $using:auditParameters
                    }
                }

                return Invoke-Command -Session $session -ScriptBlock {
                    Invoke-DiscoveryScript -Mode 'discovery'
                }
            }
            catch {
                Write-Log "JEA script execution failed: $_" -Level WARN
                throw
            }
        }
        'Admin' {
            return & $ScriptPath @Arguments
        }
        default {
            return & $ScriptPath @Arguments
        }
    }
}

function Initialize-ElevationMethod {
    <#
    .SYNOPSIS
        Detect and configure the best elevation method available
    .DESCRIPTION
        Order of preference:
        1. Already running as Administrator
        2. JEA endpoint available (AD/Entra ID integration)
        3. Reduced-privilege mode (graceful degradation)
    #>

    Write-Log "Detecting elevation capabilities..." -Level DEBUG

    # Check if already elevated
    if (Test-IsElevated) {
        $script:ElevationMode = 'Admin'
        Write-Log "Running as Administrator - full capabilities" -Level INFO
        return
    }

    # If specific method requested
    if ($ElevationMethod -eq 'JEA') {
        if (Test-JeaEndpointAvailable -EndpointName $script:JeaEndpoint) {
            $script:ElevationMode = 'JEA'
            $script:JeaAvailable = $true
            Write-Log "Using JEA endpoint: $script:JeaEndpoint" -Level INFO
            return
        } else {
            Write-Log "JEA endpoint not available, falling back to reduced mode" -Level WARN
        }
    }

    # Auto-detect best method
    if ($ElevationMethod -eq 'Auto') {
        # Try JEA if endpoint configured
        if ($script:JeaEndpoint -and (Test-JeaEndpointAvailable -EndpointName $script:JeaEndpoint)) {
            $script:ElevationMode = 'JEA'
            $script:JeaAvailable = $true
            Write-Log "Auto-detected JEA endpoint: $script:JeaEndpoint" -Level INFO
            return
        }

        # Try default audit endpoint
        if (Test-JeaEndpointAvailable -EndpointName 'AuditAgent.JEA') {
            $script:JeaEndpoint = 'AuditAgent.JEA'
            $script:ElevationMode = 'JEA'
            $script:JeaAvailable = $true
            Write-Log "Auto-detected default JEA endpoint: $script:JeaEndpoint" -Level INFO
            return
        }
    }

    # No elevation available - reduced mode
    $script:ElevationMode = 'None'
    Write-Log "Running in reduced-privilege mode" -Level WARN
}

function Get-ElevationStatus {
    <#
    .SYNOPSIS
        Get current elevation status for reporting
    .RETURNS
        Hashtable with elevation details
    #>
    @{
        Mode = $script:ElevationMode
        IsAdmin = Test-IsElevated
        JeaAvailable = $script:JeaAvailable
        JeaEndpoint = $script:JeaEndpoint
        ReducedMode = ($script:ElevationMode -eq 'None' -and -not (Test-IsElevated))
    }
}

function Get-AgentCapabilities {
    <#
    .SYNOPSIS
        Get list of capabilities based on current elevation
    .RETURNS
        Array of capability strings
    #>
    $caps = @(
        'discovery_basic'
        'audit_unprivileged'
        'result_upload'
        'config_sync'
    )

    if ($script:ElevationMode -eq 'Admin' -or $script:ElevationMode -eq 'JEA') {
        $caps += @(
            'discovery_full'
            'audit_privileged'
            'port_scan_full'
            'security_audit'
            'registry_audit'
            'firewall_audit'
            'defender_audit'
        )
    }

    return $caps
}

function Get-AuditElevationLevel {
    <#
    .SYNOPSIS
        Read audit metadata and determine required elevation level
    .DESCRIPTION
        Uses audit header marker: @elevation: none|partial|admin|root
        Defaults to 'partial' when marker is absent.
    #>
    param([Parameter(Mandatory)][string]$ScriptPath)

    try {
        if (-not (Test-Path $ScriptPath)) { return 'partial' }

        $header = Get-Content -Path $ScriptPath -TotalCount 80 -ErrorAction Stop
        $line = $header | Where-Object { $_ -match '@elevation\s*:\s*(none|partial|admin|root)' } | Select-Object -First 1
        if (-not $line) { return 'partial' }

        $m = [regex]::Match($line, '@elevation\s*:\s*(none|partial|admin|root)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if (-not $m.Success) { return 'partial' }

        $value = $m.Groups[1].Value.ToLowerInvariant()
        if ($value -eq 'root') { return 'admin' }
        return $value
    }
    catch {
        return 'partial'
    }
}

function Test-ShouldElevateAudit {
    <#
    .SYNOPSIS
        Decide whether this audit should execute through elevation path
    #>
    param([Parameter(Mandatory)][string]$ScriptPath)

    $level = Get-AuditElevationLevel -ScriptPath $ScriptPath

    if ($script:ElevationMode -eq 'None') {
        return @{ ShouldElevate = $false; Level = $level; Reason = 'No elevation capability available' }
    }

    if ($level -eq 'none') {
        return @{ ShouldElevate = $false; Level = $level; Reason = 'Audit metadata marked non-elevated' }
    }

    return @{ ShouldElevate = $true; Level = $level; Reason = "Audit metadata requires/benefits from $level elevation" }
}

# =============================================================================
# Secure Credential Storage (DPAPI)
# =============================================================================
$script:SecureCredFile = Join-Path $AgentDir ".credentials"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function Protect-ApiKey {
    <#
    .SYNOPSIS
        Encrypt API key using Windows DPAPI (user-scope encryption)
    .PARAMETER PlainText
        The API key to encrypt
    .RETURNS
        Base64-encoded encrypted string
    #>
    param([string]$PlainText)

    if ([string]::IsNullOrEmpty($PlainText)) { return "" }

    try {
        $secureString = ConvertTo-InMemorySecureString -Value $PlainText
        $encrypted = ConvertFrom-SecureString $secureString
        return $encrypted
    }
    catch {
        Write-Log "Failed to encrypt API key: $_" -Level ERROR
        return ""
    }
}

function Unprotect-ApiKey {
    <#
    .SYNOPSIS
        Decrypt API key encrypted with Windows DPAPI
    .PARAMETER EncryptedText
        Base64-encoded encrypted string from Protect-ApiKey
    .RETURNS
        Plain text API key
    #>
    param([string]$EncryptedText)

    if ([string]::IsNullOrEmpty($EncryptedText)) { return "" }

    try {
        $secureString = ConvertTo-SecureString $EncryptedText
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureString)
        $plainText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        return $plainText
    }
    catch {
        Write-Log "Failed to decrypt API key - may be corrupted or encrypted by different user" -Level WARN
        return ""
    }
}

function Save-SecureCredentials {
    <#
    .SYNOPSIS
        Save API key securely using DPAPI encryption
    #>
    if ([string]::IsNullOrEmpty($ApiKey)) { return }

    try {
        $encrypted = Protect-ApiKey -PlainText $ApiKey
        if ($encrypted) {
            $encrypted | Set-Content $script:SecureCredFile -Force
            # Set restrictive permissions on the credentials file
            $acl = Get-Acl $script:SecureCredFile
            $acl.SetAccessRuleProtection($true, $false)
            $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
                "FullControl",
                "Allow"
            )
            $acl.SetAccessRule($rule)
            Set-Acl $script:SecureCredFile $acl
            Write-Log "API key encrypted and saved securely" -Level DEBUG
        }
    }
    catch {
        Write-Log "Failed to save secure credentials: $_" -Level ERROR
    }
}

function Get-SecureCredentials {
    <#
    .SYNOPSIS
        Load API key from secure DPAPI-encrypted storage
    #>
    if (Test-Path $script:SecureCredFile) {
        try {
            $encrypted = Get-Content $script:SecureCredFile -Raw
            $decrypted = Unprotect-ApiKey -EncryptedText $encrypted.Trim()
            if ($decrypted) {
                $script:ApiKey = $decrypted
                Write-Log "Loaded API key from secure storage" -Level DEBUG
                return $true
            }
        }
        catch {
            Write-Log "Failed to load secure credentials: $_" -Level WARN
        }
    }
    return $false
}

# =============================================================================
# TLS Certificate Pinning
# =============================================================================
$script:TlsCertHash = $null

function Get-ServerCertificateHash {
    <#
    .SYNOPSIS
        Get SHA256 hash of the server's TLS certificate
    .PARAMETER Url
        Server URL to connect to
    .RETURNS
        SHA256 hash string of the certificate
    #>
    param([string]$Url)

    try {
        $uri = [System.Uri]::new($Url)
        $targetHost = $uri.Host
        $port = if ($uri.Port -gt 0) { $uri.Port } else { 443 }

        $tcpClient = New-Object System.Net.Sockets.TcpClient($targetHost, $port)
        $sslStream = New-Object System.Net.Security.SslStream(
            $tcpClient.GetStream(),
            $false,
            { $true }  # Accept all for inspection
        )

        $sslStream.AuthenticateAsClient($targetHost)
        $cert = $sslStream.RemoteCertificate

        if ($cert) {
            $certData = $cert.GetRawCertData()
            $hashBytes = [System.Security.Cryptography.SHA256]::Create().ComputeHash($certData)
            $hash = [System.BitConverter]::ToString($hashBytes).Replace("-", "").ToLower()

            $sslStream.Dispose()
            $tcpClient.Close()

            return $hash
        }
    }
    catch {
        Write-Log "Failed to get server certificate: $_" -Level ERROR
    }

    return $null
}

function Test-CertificatePinning {
    <#
    .SYNOPSIS
        Validate server certificate against pinned hash
    .RETURNS
        $true if certificate is valid, $false otherwise
    #>
    if (-not $TlsPinningEnabled -or [string]::IsNullOrEmpty($TlsPinnedCertHash)) {
        return $true  # Pinning not enabled, allow connection
    }

    $serverHash = Get-ServerCertificateHash -Url $ServerUrl

    if ([string]::IsNullOrEmpty($serverHash)) {
        Write-Log "Certificate pinning FAILED: Could not retrieve server certificate" -Level ERROR
        return $false
    }

    $pinnedHash = $TlsPinnedCertHash.ToLower().Replace(":", "").Replace("-", "")

    if ($serverHash -eq $pinnedHash) {
        Write-Log "Certificate pinning verified" -Level DEBUG
        return $true
    }
    else {
        Write-Log "Certificate pinning FAILED: Hash mismatch" -Level ERROR
        Write-Log "  Expected: $pinnedHash" -Level ERROR
        Write-Log "  Got: $serverHash" -Level ERROR
        return $false
    }
}

function Show-ServerCertificateHash {
    <#
    .SYNOPSIS
        Display the server's certificate hash for pinning configuration
    #>
    if (-not $ServerUrl) {
        Write-Log "SERVER_URL not configured" -Level ERROR
        return
    }

    $hash = Get-ServerCertificateHash -Url $ServerUrl

    if ($hash) {
        Write-Output ""
        Write-Output "Server Certificate SHA256 Hash:"
        Write-Output "  $hash"
        Write-Output ""
        Write-Output "To enable certificate pinning, set:"
        Write-Output '  $env:AUDIT_TLS_PINNED_CERT_HASH = "'
        Write-Output "$hash"
        Write-Output '"'
        Write-Output '  $env:AUDIT_TLS_PINNING_ENABLED = "true"'
        Write-Output ""
    }
}

# =============================================================================
# API Key Rotation
# =============================================================================
function Update-ApiKey {
    <#
    .SYNOPSIS
        Update the agent's API key (for key rotation)
    .PARAMETER NewKey
        The new API key to use
    .PARAMETER Force
        Skip confirmation prompt
    .DESCRIPTION
        This function securely replaces the stored API key with a new one.
        The old key is immediately invalidated. Use this when rotating
        keys from the central server.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$NewKey,

        [switch]$Force
    )

    if ([string]::IsNullOrEmpty($NewKey)) {
        Write-Log "New API key cannot be empty" -Level ERROR
        return $false
    }

    # Validate new key format (should be URL-safe base64, ~43 chars)
    if ($NewKey.Length -lt 20) {
        Write-Log "New API key appears too short - verify this is correct" -Level WARN
    }

    if (-not $Force) {
        Write-Output ""
        Write-Output "WARNING: This will replace your current API key."
        Write-Output "The old key will stop working immediately."
        Write-Output ""
        $confirm = Read-Host "Type 'ROTATE' to confirm"
        if ($confirm -ne 'ROTATE') {
            Write-Log "Key rotation cancelled" -Level INFO
            return $false
        }
    }

    try {
        # Backup current key info for logging
        $oldKeyPreview = if ($script:ApiKey) {
            $script:ApiKey.Substring(0, [Math]::Min(8, $script:ApiKey.Length)) + "..."
        } else {
            "(none)"
        }

        # Update the key
        $script:ApiKey = $NewKey

        # Save to secure storage
        Save-SecureCredentials

        # Update environment variable for current session
        $env:AUDIT_API_KEY = $NewKey

        # Record rotation timestamp in config
        Import-Config  # Reload config

        $newKeyPreview = $NewKey.Substring(0, [Math]::Min(8, $NewKey.Length)) + "..."
        Write-Log "API key rotated successfully" -Level INFO
        Write-Log "  Old key: $oldKeyPreview" -Level DEBUG
        Write-Log "  New key: $newKeyPreview" -Level DEBUG

        # Verify we can still connect to server
        if ($ServerUrl) {
            Write-Log "Verifying connection with new key..."
            try {
                $response = Invoke-AgentApi -Endpoint "/api/agent/status" -Method GET
                if ($response.success) {
                    Write-Log "Connection verified with new API key" -Level INFO
                }
                else {
                    Write-Log "Warning: Server returned error - verify the new key is correct" -Level WARN
                }
            }
            catch {
                Write-Log "Warning: Could not verify connection - check server connectivity" -Level WARN
            }
        }

        return $true
    }
    catch {
        Write-Log "Failed to rotate API key: $_" -Level ERROR
        return $false
    }
}

function Get-KeyRotationStatus {
    <#
    .SYNOPSIS
        Display information about the current API key for rotation planning
    #>
    Write-Output ""
    Write-Output "API Key Rotation Status"
    Write-Output "======================="

    if ([string]::IsNullOrEmpty($script:ApiKey)) {
        Write-Output "  No API key configured"
        return
    }

    $keyPreview = $script:ApiKey.Substring(0, [Math]::Min(8, $script:ApiKey.Length)) + "..."
    Write-Output "  Current Key: $keyPreview"

    # Check secure storage
    if (Test-Path $script:SecureCredFile) {
        $fileInfo = Get-Item $script:SecureCredFile
        Write-Output "  Secure Storage: $($fileInfo.FullName)"
        Write-Output "  Last Modified: $($fileInfo.LastWriteTime)"
    }
    else {
        Write-Output "  Secure Storage: Not configured (key in config file)"
    }

    Write-Output ""
    Write-Output "To rotate this key:"
    Write-Output '  1. Request new key from server: POST /api/agent/<agent_id>/rotate-key'
    Write-Output '  2. Run: .\fleet-agent.ps1 -Mode rotate-key -NewApiKey "NEW_KEY_HERE"'
    Write-Output ""
}

function Invoke-KeyRotation {
    <#
    .SYNOPSIS
        Handle automated key rotation from server command

    .DESCRIPTION
        This is called when the server sends a key_rotation command during heartbeat.
        It fetches the new key from the server, updates local storage, and confirms.
    #>
    param([PSCustomObject]$CommandData)

    $agentId = $CommandData.agent_id
    $gracePeriodHours = if ($CommandData.grace_period_hours) { $CommandData.grace_period_hours } else { 24 }

    if ([string]::IsNullOrEmpty($agentId)) {
        $agentId = $script:AgentId
    }

    if ([string]::IsNullOrEmpty($agentId)) {
        Write-Log "Cannot rotate key: agent_id not available" -Level ERROR
        return @{ success = $false; error = "Agent ID not configured" }
    }

    Write-Log "Fetching new API key from server (grace period: ${gracePeriodHours}h)"

    # Fetch new key from server (using current key which is still valid during grace period)
    try {
        $fetchResponse = Invoke-AgentApi -Method GET -Endpoint "/api/agent/$agentId/fetch-new-key"

        if ($null -eq $fetchResponse) {
            Write-Log "Failed to fetch new key from server" -Level ERROR
            return @{ success = $false; error = "Failed to fetch new key" }
        }

        $newKey = $fetchResponse.new_api_key

        if ([string]::IsNullOrEmpty($newKey)) {
            $errorMsg = if ($fetchResponse.error) { $fetchResponse.error } else { "No new key in response" }
            Write-Log "Server did not return new key: $errorMsg" -Level ERROR
            return @{ success = $false; error = $errorMsg }
        }

        # Update the key locally
        $script:ApiKey = $newKey

        # Save to secure storage
        if (Save-SecureCredentials) {
            Write-Log "API key updated in secure storage"
        }
        else {
            Write-Log "Warning: Could not save key to secure storage" -Level WARN
        }

        Write-Log "API key updated locally, confirming with server..."

        # Confirm successful update with server
        try {
            $confirmResponse = Invoke-AgentApi -Method POST -Endpoint "/api/agent/$agentId/confirm-key-update" -Body @{}

            if ($confirmResponse.success -eq $true) {
                Write-Log "Key rotation completed successfully"
                return @{ success = $true; message = "Key rotated and confirmed" }
            }
            else {
                $confirmError = if ($confirmResponse.error) { $confirmResponse.error } else { "Confirmation failed" }
                Write-Log "Key updated but confirmation failed: $confirmError" -Level WARN
                return @{ success = $true; message = "Key updated, confirmation pending"; warning = $confirmError }
            }
        }
        catch {
            Write-Log "Key updated but confirmation request failed: $_" -Level WARN
            return @{ success = $true; message = "Key updated, confirmation pending"; warning = $_.Exception.Message }
        }
    }
    catch {
        Write-Log "Key rotation failed: $_" -Level ERROR
        return @{ success = $false; error = $_.Exception.Message }
    }
}

# =============================================================================
# Utility Functions
# =============================================================================
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')]
        [string]$Level = 'INFO'
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Output "[$Level] $timestamp $Message"
}

function Initialize-Directories {
    @($script:ResultsDir, $script:AuditsDir, $script:LibDir, $script:CacheDir) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -ItemType Directory -Path $_ -Force | Out-Null
        }
    }
}

function Import-Config {
    # First, try to load API key from secure storage (DPAPI encrypted)
    $secureLoaded = Get-SecureCredentials

    if (Test-Path $script:ConfigFile) {
        try {
            $config = Get-Content $script:ConfigFile | ConvertFrom-Json
            if (-not $ServerUrl -and $config.server_url) { $script:ServerUrl = $config.server_url }
            # Only load API key from config if not already loaded from secure storage
            if (-not $secureLoaded -and -not $ApiKey -and $config.api_key) {
                $script:ApiKey = $config.api_key
                # Migrate plaintext key to secure storage
                Write-Log "Migrating API key to secure storage..." -Level INFO
                Save-SecureCredentials
            }
            if (-not $AgentId -and $config.agent_id) { $script:AgentId = $config.agent_id }
            if (-not $script:JeaEndpointProvided -and $config.jea_endpoint) { $script:JeaEndpoint = [string]$config.jea_endpoint }
            if ($config.config_version) { $script:ConfigVersion = $config.config_version }
            if ($null -ne $config.max_local_result_files) {
                try {
                    $script:MaxLocalResultFiles = [Math]::Max(0, [int]$config.max_local_result_files)
                }
                catch {
                    $script:MaxLocalResultFiles = 1000
                }
            }

            if ($null -ne $config.min_free_disk_mb) {
                try {
                    $script:MinFreeDiskMB = [Math]::Max(64, [int]$config.min_free_disk_mb)
                }
                catch {
                    Write-Log "Invalid min_free_disk_mb in config; keeping current value" -Level WARN
                }
            }

            if ($null -ne $config.min_free_disk_pct) {
                try {
                    $script:MinFreeDiskPct = [Math]::Max(1, [int]$config.min_free_disk_pct)
                }
                catch {
                    Write-Log "Invalid min_free_disk_pct in config; keeping current value" -Level WARN
                }
            }
        }
        catch {
            Write-Log "Failed to load config: $_" -Level ERROR
        }
    }

    # Generate agent ID if not set
    if (-not $script:AgentId) {
        $hostname = $env:COMPUTERNAME
        $hash = [System.BitConverter]::ToString(
            [System.Security.Cryptography.SHA256]::Create().ComputeHash(
                [System.Text.Encoding]::UTF8.GetBytes($hostname + (Get-Date -Format "yyyyMMdd"))
            )
        ).Replace("-", "").Substring(0, 16).ToLower()
        $script:AgentId = $hash
        Write-Log "Generated agent ID: $script:AgentId"
    }
}

function Save-Config {
    # Save API key to secure storage (DPAPI encrypted)
    Save-SecureCredentials

    # Save config WITHOUT the API key (security best practice)
    $config = @{
        server_url = $ServerUrl
        # api_key intentionally omitted - stored in secure DPAPI storage
        agent_id = $script:AgentId
        config_version = $script:ConfigVersion
        jea_endpoint = $script:JeaEndpoint
        max_local_result_files = $script:MaxLocalResultFiles
        updated_at = (Get-Date -Format "o")
        credentials_storage = "dpapi"  # Indicate secure storage is used
    }
    $config | ConvertTo-Json | Set-Content $script:ConfigFile
}

# =============================================================================
# System Information
# =============================================================================
function Get-SystemInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem

    @{
        hostname = $env:COMPUTERNAME
        os_name = $os.Caption
        os_version = $os.Version
        os_type = if ($os.ProductType -eq 1) { "windows-desktop" } else { "windows-server" }
        architecture = $env:PROCESSOR_ARCHITECTURE
        domain = $cs.Domain
        total_memory_gb = [math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
    }
}

function Get-DiskInfo {
    param(
        [string]$Path
    )

    try {
        if (-not (Test-Path $Path)) {
            New-Item -ItemType Directory -Path $Path -Force | Out-Null
        }

        $resolvedPath = (Resolve-Path $Path -ErrorAction Stop).Path
        $root = [System.IO.Path]::GetPathRoot($resolvedPath)
        $drive = [System.IO.DriveInfo]::new($root)

        $totalMB = [math]::Floor($drive.TotalSize / 1MB)
        $freeMB = [math]::Floor($drive.AvailableFreeSpace / 1MB)
        $freePct = if ($totalMB -gt 0) { [math]::Round(($freeMB / $totalMB) * 100, 0) } else { 0 }

        return @{
            total_mb = [int]$totalMB
            free_mb = [int]$freeMB
            free_pct = [int]$freePct
            root = $root
        }
    }
    catch {
        return @{
            total_mb = 0
            free_mb = 0
            free_pct = 0
            root = "unknown"
        }
    }
}

function Test-DiskHeadroom {
    param(
        [string]$Path,
        [string]$Context = "local storage"
    )

    $disk = Get-DiskInfo -Path $Path
    if ($disk.free_mb -lt $script:MinFreeDiskMB -or $disk.free_pct -lt $script:MinFreeDiskPct) {
        Write-Log "Low disk space for $Context`: $($disk.free_mb)MB/$($disk.free_pct)% free (min: $($script:MinFreeDiskMB)MB/$($script:MinFreeDiskPct)%)" -Level WARN
        return $false
    }

    return $true
}

function Get-MemoryInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $totalMB = [math]::Round($os.TotalVisibleMemorySize / 1024, 0)
    $freeMB = [math]::Round($os.FreePhysicalMemory / 1024, 0)
    $freePct = [math]::Round(($freeMB / $totalMB) * 100, 0)

    @{
        total_mb = $totalMB
        free_mb = $freeMB
        free_pct = $freePct
    }
}

function Get-CpuUsage {
    try {
        $cpu = Get-CimInstance -ClassName Win32_Processor | Measure-Object -Property LoadPercentage -Average
        [math]::Round($cpu.Average, 0)
    }
    catch { 0 }
}

function Test-ResourcesAvailable {
    $mem = Get-MemoryInfo
    if ($mem.free_pct -lt $MinFreeMemoryPct) {
        Write-Log "Low memory: $($mem.free_pct)% free (min: ${MinFreeMemoryPct}%)" -Level WARN
        return $false
    }

    if ($MaxCpuPct -gt 0) {
        $cpu = Get-CpuUsage
        if ($cpu -gt $MaxCpuPct) {
            Write-Log "High CPU: ${cpu}% (max: ${MaxCpuPct}%)" -Level WARN
            return $false
        }
    }

    if (-not (Test-DiskHeadroom -Path $script:ResultsDir -Context "result storage")) {
        return $false
    }

    return $true
}

# =============================================================================
# API Communication
# =============================================================================
function Invoke-AgentApi {
    param(
        [string]$Method = 'GET',
        [string]$Endpoint,
        [object]$Body
    )

    if (-not $ServerUrl) {
        Write-Log "SERVER_URL not configured" -Level ERROR
        return $null
    }

    if ($config.storage -and ($null -ne $config.storage.min_free_disk_mb)) {
        try {
            $script:MinFreeDiskMB = [Math]::Max(64, [int]$config.storage.min_free_disk_mb)
        }
        catch {
            Write-Log "Invalid storage.min_free_disk_mb in config; keeping current value" -Level WARN
        }
    }

    if ($config.storage -and ($null -ne $config.storage.min_free_disk_pct)) {
        try {
            $script:MinFreeDiskPct = [Math]::Max(1, [int]$config.storage.min_free_disk_pct)
        }
        catch {
            Write-Log "Invalid storage.min_free_disk_pct in config; keeping current value" -Level WARN
        }
    }

    # Validate certificate pinning if enabled
    if ($TlsPinningEnabled -and -not (Test-CertificatePinning)) {
        Write-Log "API request blocked: Certificate pinning validation failed" -Level ERROR
        return $null
    }

    $url = "$ServerUrl$Endpoint"
    $headers = @{
        "Content-Type" = "application/json"
        "X-API-Key" = $ApiKey
        "X-Agent-ID" = $script:AgentId
    }

    $params = @{
        Uri = $url
        Method = $Method
        Headers = $headers
        TimeoutSec = 120
        UseBasicParsing = $true
    }

    # Handle SkipCertificateCheck for PowerShell 6+ (Core)
    if ($SkipCertificateCheck -and $PSVersionTable.PSVersion.Major -ge 6) {
        $params.SkipCertificateCheck = $true
    }
    elseif ($SkipCertificateCheck) {
        # PowerShell 5.x workaround
        Write-Log "Warning: SkipCertificateCheck on PS 5.x may require manual trust configuration" -Level WARN
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    }

    if ($Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 10)
    }

    try {
        $response = Invoke-RestMethod @params
        return $response
    }
    catch {
        Write-Log "API request failed: $($_.Exception.Message)" -Level ERROR
        return $null
    }
    finally {
        # Reset certificate callback if we modified it
        if ($SkipCertificateCheck -and $PSVersionTable.PSVersion.Major -lt 6) {
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
        }
    }
}

# =============================================================================
# Registration & Heartbeat
# =============================================================================
function Register-Agent {
    Write-Log "Registering with server..."

    $sysInfo = Get-SystemInfo
    $elevationStatus = Get-ElevationStatus
    $capabilities = Get-AgentCapabilities

    $payload = @{
        hostname = $sysInfo.hostname
        os_name = $sysInfo.os_name
        os_version = $sysInfo.os_version
        os_type = $sysInfo.os_type
        architecture = $sysInfo.architecture
        agent_version = $script:AgentVersion
        elevation = @{
            mode = $elevationStatus.Mode
            is_admin = $elevationStatus.IsAdmin
            jea_available = $elevationStatus.JeaAvailable
            jea_endpoint = $elevationStatus.JeaEndpoint
            reduced_mode = $elevationStatus.ReducedMode
        }
        capabilities = $capabilities
    }

    $response = Invoke-AgentApi -Method POST -Endpoint "/api/agent/register" -Body $payload

    if ($response -and $response.success) {
        if ($response.agent_id) {
            $script:AgentId = $response.agent_id
            Save-Config
        }
        Write-Log "Registered successfully as: $script:AgentId"
        Write-Log "Elevation mode: $($elevationStatus.Mode), Capabilities: $($capabilities.Count)" -Level INFO
        return $true
    }

    Write-Log "Registration failed" -Level ERROR
    return $false
}

function Invoke-AgentHeartbeat {
    $mem = Get-MemoryInfo
    $cpu = Get-CpuUsage

    $payload = @{
        pending_results = (Get-PendingResultsCount)
        status = 'idle'
        resources = @{
            cpu_usage_pct = $cpu
            memory_free_pct = $mem.free_pct
        }
        request_license = $true
    }

    $response = Invoke-AgentApi -Method POST -Endpoint "/api/agent/heartbeat" -Body $payload

    if ($response -and $response.success) {
        $script:ConsecutiveHeartbeatFailures = 0
        $script:LastHeartbeatStatus = 'ok'
        $script:LastHeartbeatReason = ''
        return $true
    }

    $script:ConsecutiveHeartbeatFailures++
    if ($response -and $response.error) {
        $script:LastHeartbeatReason = $response.error
        $script:LastHeartbeatStatus = 'rejected'
    }
    else {
        $script:LastHeartbeatReason = 'No response from core server'
        $script:LastHeartbeatStatus = 'connection_error'
    }

    Write-Log "Heartbeat failed ($($script:ConsecutiveHeartbeatFailures)/$($script:MaxHeartbeatFailures)): $($script:LastHeartbeatReason)" -Level WARN
    return $false
}

function Invoke-ServerPoll {
    if (-not (Invoke-AgentHeartbeat)) {
        return $false
    }

    $mem = Get-MemoryInfo
    $cpu = Get-CpuUsage
    $checksums = Get-AuditChecksums

    $payload = @{
        agent_id = $script:AgentId
        hostname = $env:COMPUTERNAME
        status = "idle"
        current_config_version = $script:ConfigVersion
        audit_checksums = $checksums
        resources = @{
            cpu_pct = $cpu
            memory_free_pct = $mem.free_pct
        }
        pending_results_count = (Get-PendingResultsCount)
    }

    $response = Invoke-AgentApi -Method POST -Endpoint "/api/agent/managed/poll" -Body $payload

    if (-not $response -or -not $response.success) {
        Write-Log "Poll failed" -Level ERROR
        return $false
    }

    # Update poll interval from server
    if ($response.next_poll_seconds) {
        $script:PollInterval = $response.next_poll_seconds
    }

    # Handle config update
    if ($response.config_update_available) {
        Write-Log "Configuration update available, fetching..."
        Get-AgentConfig
    }

    # Handle audit updates
    if ($response.audit_updates -and $response.audit_updates.Count -gt 0) {
        Write-Log "Audit updates available: $($response.audit_updates.Count) files"
        Sync-AuditFiles -Files $response.audit_updates
    }

    # Process commands
    if ($response.commands -and $response.commands.Count -gt 0) {
        Write-Log "Processing $($response.commands.Count) pending commands"
        $response.commands | ForEach-Object { Invoke-AgentCommand -Command $_ }
    }

    return $true
}

# =============================================================================
# Configuration Sync (Server -> Agent)
# =============================================================================
function Get-AgentConfig {
    $response = Invoke-AgentApi -Method GET -Endpoint "/api/agent/managed/config/$script:AgentId"

    if (-not $response -or -not $response.success) {
        Write-Log "Failed to fetch config" -Level ERROR
        return $false
    }

    $config = $response.config

    # Update local settings
    $script:ConfigVersion = $config.config_version

    # Throttle settings
    if ($config.throttle) {
        $script:ProcessPriority = $config.throttle.cpu_priority ?? 'Idle'
        $script:MinFreeMemoryPct = $config.throttle.min_free_memory_pct ?? 10
        $script:MaxCpuPct = $config.throttle.max_cpu_pct ?? 0
    }

    if ($config.storage -and ($null -ne $config.storage.max_local_result_files)) {
        try {
            $script:MaxLocalResultFiles = [Math]::Max(0, [int]$config.storage.max_local_result_files)
        }
        catch {
            Write-Log "Invalid storage.max_local_result_files in config; keeping current value" -Level WARN
        }
    }

    $syncedJeaEndpoint = $null
    if ($config.jea_endpoint) {
        $syncedJeaEndpoint = [string]$config.jea_endpoint
    }
    elseif ($config.elevation -and $config.elevation.jea_endpoint) {
        $syncedJeaEndpoint = [string]$config.elevation.jea_endpoint
    }

    if (-not [string]::IsNullOrWhiteSpace($syncedJeaEndpoint) -and -not $script:JeaEndpointProvided) {
        $script:JeaEndpoint = $syncedJeaEndpoint
    }

    # Save to cache
    $config | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $script:CacheDir "server_config.json")
    Save-Config

    Write-Log "Configuration updated to version $script:ConfigVersion"
    return $true
}

# =============================================================================
# Audit Sync (Server -> Agent)
# =============================================================================
function Get-AuditChecksums {
    $checksums = @{}

    # Walk audit directories and calculate checksums
    $auditFiles = Get-ChildItem -Path $script:AuditsDir -Filter "*.ps1" -Recurse -ErrorAction SilentlyContinue

    foreach ($file in $auditFiles) {
        $relPath = $file.FullName.Replace($script:AgentDir, "").TrimStart("\").Replace("\", "/")
        $hash = (Get-FileHash -Path $file.FullName -Algorithm SHA256).Hash.ToLower()
        $checksums[$relPath] = $hash
    }

    return $checksums
}

function Sync-AuditFiles {
    param([string[]]$Files)

    if (-not $Files -or $Files.Count -eq 0) { return }

    $payload = @{
        files = $Files
        format = "zip"
    }

    $tempFile = Join-Path $env:TEMP "audit_sync.zip"

    try {
        $headers = @{
            "Content-Type" = "application/json"
            "X-API-Key" = $ApiKey
            "X-Agent-ID" = $script:AgentId
        }

        Invoke-WebRequest `
            -Uri "$ServerUrl/api/agent/managed/sync/download" `
            -Method POST `
            -Headers $headers `
            -Body ($payload | ConvertTo-Json) `
            -OutFile $tempFile `
            -UseBasicParsing

        # Extract to agent directory
        Expand-Archive -Path $tempFile -DestinationPath $script:AgentDir -Force
        Write-Log "Audit sync completed successfully"
    }
    catch {
        Write-Log "Failed to sync audits: $_" -Level ERROR
    }
    finally {
        if (Test-Path $tempFile) { Remove-Item $tempFile -Force }
    }
}

function Sync-FullPackage {
    Write-Log "Downloading full audit package..."

    $tempFile = Join-Path $env:TEMP "full_package.zip"

    try {
        $headers = @{
            "X-API-Key" = $ApiKey
            "X-Agent-ID" = $script:AgentId
        }

        Invoke-WebRequest `
            -Uri "$ServerUrl/api/agent/managed/sync/full-package?os_type=windows&include_lib=true" `
            -Method GET `
            -Headers $headers `
            -OutFile $tempFile `
            -UseBasicParsing

        # Extract
        Expand-Archive -Path $tempFile -DestinationPath $script:AgentDir -Force
        Write-Log "Full package sync completed"
        return $true
    }
    catch {
        Write-Log "Full package sync failed: $_" -Level ERROR
        return $false
    }
    finally {
        if (Test-Path $tempFile) { Remove-Item $tempFile -Force }
    }
}

function Invoke-SelfUpdate {
    if (-not $ServerUrl) {
        Write-Log "SERVER_URL not configured" -Level ERROR
        return $false
    }

    $headers = @{
        "Content-Type" = "application/json"
        "X-API-Key" = $ApiKey
        "X-Agent-ID" = $script:AgentId
    }

    try {
        $manifestUrl = "$ServerUrl/api/agent/update/manifest?agent_type=managed&os_type=windows&current_version=$($script:AgentVersion)"
        $manifest = Invoke-RestMethod -Uri $manifestUrl -Method Get -Headers $headers -UseBasicParsing
    }
    catch {
        Write-Log "Failed to fetch update manifest: $_" -Level ERROR
        return $false
    }

    if (-not $manifest.success) {
        Write-Log "Update manifest error: $($manifest.error)" -Level ERROR
        return $false
    }

    if (-not $manifest.update_available) {
        Write-Log "Managed agent is up to date (current: $($script:AgentVersion), latest: $($manifest.latest_version))"
        return $true
    }

    if (-not $manifest.download_url -or -not $manifest.verify_url -or -not $manifest.signature -or -not $manifest.sha256) {
        Write-Log "Invalid update manifest: missing download/verify/signature/sha256" -Level ERROR
        return $false
    }

    $tempFile = Join-Path $env:TEMP ("fleet_agent_update_{0}.ps1" -f [Guid]::NewGuid().ToString('N'))
    try {
        Invoke-WebRequest -Uri $manifest.download_url -Method Get -Headers $headers -OutFile $tempFile -UseBasicParsing
    }
    catch {
        Write-Log "Failed to download fleet agent update: $_" -Level ERROR
        return $false
    }

    $downloadHash = (Get-FileHash -Path $tempFile -Algorithm SHA256).Hash.ToLower()
    if ($downloadHash -ne ([string]$manifest.sha256).ToLower()) {
        Write-Log "Managed agent update checksum mismatch" -Level ERROR
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    $verifyPayload = @{
        signature = [string]$manifest.signature
        file_sha256 = $downloadHash
        agent_type = 'managed'
        os_type = 'windows'
        version = [string]$manifest.latest_version
    }

    try {
        $verify = Invoke-RestMethod -Uri $manifest.verify_url -Method Post -Headers $headers -Body ($verifyPayload | ConvertTo-Json) -UseBasicParsing
    }
    catch {
        Write-Log "Signed update verification request failed: $_" -Level ERROR
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    if (-not $verify.success) {
        Write-Log "Managed agent signed update verification failed: $($verify.error)" -Level ERROR
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    $scriptPath = $script:AgentScriptPath
    $backupPath = "$scriptPath.bak.$(Get-Date -Format 'yyyyMMdd_HHmmss')"

    try {
        Copy-Item -Path $scriptPath -Destination $backupPath -Force
        Copy-Item -Path $tempFile -Destination $scriptPath -Force
        Write-Log "Managed agent updated $($script:AgentVersion) -> $($manifest.latest_version)" -Level INFO
        Write-Log "Backup saved to: $backupPath" -Level INFO
        Write-Log "Restart agent process to run the new version" -Level WARN
        return $true
    }
    catch {
        Write-Log "Failed to install fleet agent update: $_" -Level ERROR
        return $false
    }
    finally {
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
}

# =============================================================================
# Command Processing
# =============================================================================
function Invoke-AgentCommand {
    param([PSCustomObject]$Command)

    $cmdId = $Command.id
    $cmdType = $Command.command_type
    $cmdData = $Command.command_data

    Write-Log "Processing command $cmdId ($cmdType)"

    # Acknowledge receipt
    Invoke-AgentApi -Method POST -Endpoint "/api/agent/commands/$cmdId/ack" -Body @{} | Out-Null

    # Mark as started
    Invoke-AgentApi -Method POST -Endpoint "/api/agent/commands/$cmdId/start" -Body @{} | Out-Null

    # Execute based on type
    $result = switch ($cmdType) {
        "run_audit" {
            $auditPath = $cmdData.audit_path
            Invoke-Audit -AuditPath $auditPath
        }
        "run_plan" {
            $auditPaths = $cmdData.audit_paths
            Invoke-AuditPlan -AuditPaths $auditPaths
        }
        "run_discovery" {
            Invoke-Discovery
        }
        "sync_audits" {
            if (Sync-FullPackage) {
                @{ success = $true }
            } else {
                @{ success = $false; error = "Sync failed" }
            }
        }
        "key_rotation" {
            # Server has rotated our API key - fetch and update
            Write-Log "Key rotation command received - fetching new key"
            Invoke-KeyRotation -CommandData $cmdData
        }
        "self_update" {
            if (Invoke-SelfUpdate) {
                @{ success = $true }
            } else {
                @{ success = $false; error = "self update failed" }
            }
        }
        default {
            Write-Log "Unknown command type: $cmdType" -Level WARN
            @{ success = $false; error = "Unknown command type" }
        }
    }

    # Complete command with result
    $completePayload = @{
        result_data = $result
        exit_code = if ($result.success) { 0 } else { 1 }
    }

    Invoke-AgentApi -Method POST -Endpoint "/api/agent/commands/$cmdId/complete" -Body $completePayload | Out-Null
}

# =============================================================================
# Audit Execution
# =============================================================================
function Invoke-Audit {
    param([string]$AuditPath)

    if ([string]::IsNullOrWhiteSpace($AuditPath)) {
        return @{
            success = $false
            error = "Audit path is required"
        }
    }

    if ($AuditPath -match '\.\.' -or $AuditPath -notmatch '^audits[\\/].+\.ps1$') {
        Write-Log "Rejected audit path outside allowed scope: $AuditPath" -Level ERROR
        return @{
            success = $false
            error = "Rejected audit path"
        }
    }

    $scriptPath = Join-Path $script:AgentDir $AuditPath

    # Add .ps1 extension if not present
    if (-not $scriptPath.EndsWith(".ps1")) {
        $scriptPath = "$scriptPath.ps1"
    }

    # Check if audit exists locally
    if (-not (Test-Path $scriptPath)) {
        # Try to fetch it
        Sync-AuditFiles -Files @($AuditPath)
    }

    if (-not (Test-Path $scriptPath)) {
        Write-Log "Audit not found: $AuditPath" -Level ERROR
        return @{
            success = $false
            error = "Audit script not found"
        }
    }

    # Check resources
    if (-not (Test-ResourcesAvailable)) {
        Write-Log "Insufficient resources, waiting..." -Level WARN
        Start-Sleep -Seconds 30
        if (-not (Test-ResourcesAvailable)) {
            return @{
                success = $false
                error = "Insufficient system resources"
            }
        }
    }

    Write-Log "Running audit: $AuditPath"

    $startTime = Get-Date
    $output = ""
    $exitCode = 0
    $elevationDecision = Test-ShouldElevateAudit -ScriptPath $scriptPath
    $auditElevationLevel = $elevationDecision.Level

    try {
        if ($elevationDecision.ShouldElevate) {
            try {
                $result = Invoke-PrivilegedScript -ScriptPath $scriptPath -Arguments @{}
                if ($null -eq $result) {
                    $output = ''
                }
                elseif ($result -is [string]) {
                    $output = $result
                }
                else {
                    $output = ($result | Out-String)
                }
                $exitCode = 0
            }
            catch {
                $output = "NOTICE: Elevated execution failed; retrying non-elevated.`n--- elevated output ---`n$($_.Exception.Message)`n"
                Write-Log "Elevated audit execution failed for $AuditPath; retrying non-elevated: $_" -Level WARN

                $process = Start-Process -FilePath "powershell.exe" `
                    -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $scriptPath `
                    -Wait -PassThru -NoNewWindow `
                    -RedirectStandardOutput (Join-Path $env:TEMP "audit_stdout.txt") `
                    -RedirectStandardError (Join-Path $env:TEMP "audit_stderr.txt")

                try { $process.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::$ProcessPriority }
                catch { Write-Log "Could not set process priority for fallback audit execution" -Level DEBUG }

                $exitCode = $process.ExitCode
                $stdout = Get-Content (Join-Path $env:TEMP "audit_stdout.txt") -Raw -ErrorAction SilentlyContinue
                $stderr = Get-Content (Join-Path $env:TEMP "audit_stderr.txt") -Raw -ErrorAction SilentlyContinue
                $output += "--- non-elevated output ---`n$stdout"
                if ($stderr) { $output += "`n$stderr" }
            }
        }
        else {
            if ($auditElevationLevel -ne 'none') {
                Write-Log "Audit $AuditPath requested '$auditElevationLevel' elevation metadata, but running non-elevated: $($elevationDecision.Reason)" -Level WARN
            }

            # Run with throttling
            $process = Start-Process -FilePath "powershell.exe" `
                -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $scriptPath `
                -Wait -PassThru -NoNewWindow `
                -RedirectStandardOutput (Join-Path $env:TEMP "audit_stdout.txt") `
                -RedirectStandardError (Join-Path $env:TEMP "audit_stderr.txt")

            # Set priority
            try {
                $process.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::$ProcessPriority
            }
            catch { Write-Log "Could not set process priority for audit execution" -Level DEBUG }

            $exitCode = $process.ExitCode
            $output = Get-Content (Join-Path $env:TEMP "audit_stdout.txt") -Raw -ErrorAction SilentlyContinue
            $stderr = Get-Content (Join-Path $env:TEMP "audit_stderr.txt") -Raw -ErrorAction SilentlyContinue

            if ($stderr) { $output += "`n$stderr" }
        }
    }
    catch {
        $output = $_.Exception.Message
        $exitCode = 1
    }

    $endTime = Get-Date

    # Parse output for summary
    $summary = Get-AuditSummary -Output $output

    # Create result object
    $result = @{
        audit_path = $AuditPath
        executed_at = $startTime.ToString("o")
        completed_at = $endTime.ToString("o")
        exit_code = $exitCode
        status = if ($exitCode -eq 0) { "success" } else { "failure" }
        output = $output
        summary = $summary
    }

    # Store result locally
    $hostname = $env:COMPUTERNAME
    $auditName = [System.IO.Path]::GetFileNameWithoutExtension($AuditPath)
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $resultFile = Join-Path $script:ResultsDir "${hostname}_${auditName}_${timestamp}.json"

    if (-not (Test-DiskHeadroom -Path $script:ResultsDir -Context "local audit result storage")) {
        return @{
            success = $false
            error = "Insufficient local disk for result storage"
        }
    }

    $result | ConvertTo-Json -Depth 10 | Set-Content $resultFile

    # Upload result
    Send-AuditResult -ResultFile $resultFile

    return $result
}

function Invoke-AuditPlan {
    param([string[]]$AuditPaths)

    foreach ($auditPath in $AuditPaths) {
        Invoke-Audit -AuditPath $auditPath
    }

    return @{ success = $true }
}

function Get-AuditSummary {
    param([string]$Output)

    if (-not $Output) {
        return @{ total = 0; pass = 0; warn = 0; fail = 0; skip = 0 }
    }

    $passCount = ([regex]::Matches($Output, '\[PASS\]')).Count
    $warnCount = ([regex]::Matches($Output, '\[WARN\]')).Count
    $failCount = ([regex]::Matches($Output, '\[FAIL\]')).Count
    $skipCount = ([regex]::Matches($Output, '\[SKIP\]')).Count

    @{
        total = $passCount + $warnCount + $failCount + $skipCount
        pass = $passCount
        warn = $warnCount
        fail = $failCount
        skip = $skipCount
    }
}

# =============================================================================
# Result Management
# =============================================================================
function Get-PendingResultsCount {
    if (Test-Path $script:ResultsDir) {
        (Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -File).Count
    } else {
        0
    }
}

function Invoke-ResultRetention {
    if ($script:MaxLocalResultFiles -le 0) { return }
    if (-not (Test-Path $script:ResultsDir)) { return }

    $allFiles = Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -File -Recurse -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime

    $overflow = $allFiles.Count - $script:MaxLocalResultFiles
    if ($overflow -le 0) { return }

    $uploadedFiles = $allFiles | Where-Object { $_.FullName -match '[\\/]uploaded[\\/]' }
    $pendingFiles = $allFiles | Where-Object { $_.FullName -notmatch '[\\/]uploaded[\\/]' }

    $removed = 0

    foreach ($file in $uploadedFiles) {
        if ($removed -ge $overflow) { break }
        try {
            Remove-Item -Path $file.FullName -Force -ErrorAction Stop
            $removed++
        }
        catch {
            Write-Log "Failed to prune uploaded result file $($file.FullName): $_" -Level WARN
        }
    }

    if ($removed -lt $overflow) {
        Write-Log "Result retention removing pending result files due to local cap (max=$($script:MaxLocalResultFiles))" -Level WARN
        foreach ($file in $pendingFiles) {
            if ($removed -ge $overflow) { break }
            try {
                Remove-Item -Path $file.FullName -Force -ErrorAction Stop
                $removed++
            }
            catch {
                Write-Log "Failed to prune pending result file $($file.FullName): $_" -Level WARN
            }
        }
    }

    if ($removed -gt 0) {
        Write-Log "Pruned $removed local result files (max_local_result_files=$($script:MaxLocalResultFiles))" -Level INFO
    }
}

function Send-AuditResult {
    param([string]$ResultFile)

    if (-not (Test-Path $ResultFile)) { return $false }

    $result = Get-Content $ResultFile | ConvertFrom-Json

    $payload = @{
        agent_id = $script:AgentId
        hostname = $env:COMPUTERNAME
        results = @($result)
    }

    $response = Invoke-AgentApi -Method POST -Endpoint "/api/agent/managed/results/ingest" -Body $payload

    if ($response -and $response.success) {
        Write-Log "Uploaded result: $(Split-Path $ResultFile -Leaf)"

        # Archive uploaded result
        $uploadedDir = Join-Path $script:ResultsDir "uploaded"
        if (-not (Test-Path $uploadedDir)) { New-Item -ItemType Directory -Path $uploadedDir -Force | Out-Null }
        Move-Item -Path $ResultFile -Destination $uploadedDir -Force
        Invoke-ResultRetention

        return $true
    }

    Write-Log "Failed to upload result" -Level ERROR
    return $false
}

function Send-AllPendingResults {
    Write-Log "Uploading pending results..."

    if (-not (Test-Path $script:ResultsDir)) { return }

    $files = Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -File
    $count = 0

    foreach ($file in $files) {
        if (Send-AuditResult -ResultFile $file.FullName) {
            $count++
        }
    }

    Write-Log "Uploaded $count results"
}

# =============================================================================
# Discovery (Enhanced for Asset Discovery & CVE Integration)
# =============================================================================
function Invoke-Discovery {
    Write-Log "Running comprehensive system discovery..."

    $sysInfo = Get-SystemInfo

    # Get IP addresses
    $ipAddresses = @()
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -ne "127.0.0.1" } |
        ForEach-Object { $ipAddresses += $_.IPAddress }

    # Get installed software (from multiple registry locations)
    $packages = @()
    $regPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    foreach ($regPath in $regPaths) {
        Get-ItemProperty $regPath -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName } |
            ForEach-Object {
                $packages += @{
                    name = $_.DisplayName
                    version = $_.DisplayVersion
                    publisher = $_.Publisher
                    source = "registry"
                }
            }
    }
    $packages = $packages | Select-Object -First 500

    # Get running services
    $services = @()
    Get-Service -ErrorAction SilentlyContinue |
        Where-Object { $_.Status -eq 'Running' } |
        Select-Object -First 100 |
        ForEach-Object {
            $services += @{
                name = $_.Name
                display_name = $_.DisplayName
                status = "running"
            }
        }

    # Get open ports (listening)
    $openPorts = @()
    try {
        Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
            $process = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
            $openPorts += @{
                port = $_.LocalPort
                protocol = "tcp"
                process = if ($process) { $process.Name } else { "unknown" }
                address = $_.LocalAddress
            }
        }
        Get-NetUDPEndpoint -ErrorAction SilentlyContinue | ForEach-Object {
            $process = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
            $openPorts += @{
                port = $_.LocalPort
                protocol = "udp"
                process = if ($process) { $process.Name } else { "unknown" }
                address = $_.LocalAddress
            }
        }
        $openPorts = $openPorts | Sort-Object port -Unique
    } catch {
        Write-Log "Failed to enumerate ports: $_" -Level WARN
    }

    # Get pending updates
    $updateCount = 0
    $updatesAvailable = @()
    try {
        $updateSession = New-Object -ComObject Microsoft.Update.Session
        $updateSearcher = $updateSession.CreateUpdateSearcher()
        $searchResult = $updateSearcher.Search("IsInstalled=0 and Type='Software'")
        $updateCount = $searchResult.Updates.Count
        $searchResult.Updates | Select-Object -First 100 | ForEach-Object {
            $updatesAvailable += @{ name = $_.Title; severity = $_.MsrcSeverity }
        }
    } catch {
        Write-Log "Failed to check Windows Update: $_" -Level WARN
    }

    # Get user accounts
    $users = @()
    try {
        Get-LocalUser -ErrorAction SilentlyContinue | ForEach-Object {
            $users += @{
                name = $_.Name
                enabled = $_.Enabled
                last_logon = if ($_.LastLogon) { $_.LastLogon.ToString("o") } else { $null }
            }
        }
    }
    catch { Write-Log "Local user enumeration failed: $_" -Level DEBUG }

    # Security info
    $security = @{
        firewall_status = "unknown"
        firewall_profiles = @()
        defender_enabled = $false
        antivirus_enabled = $false
        bitlocker_enabled = $false
    }

    try {
        $fwProfiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue
        $enabledProfiles = $fwProfiles | Where-Object { $_.Enabled }
        $security.firewall_status = if ($enabledProfiles) { "active" } else { "disabled" }
        $security.firewall_profiles = $fwProfiles | ForEach-Object {
            @{ name = $_.Name; enabled = $_.Enabled }
        }
    }
    catch { Write-Log "Firewall profile inspection failed: $_" -Level DEBUG }

    try {
        $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($defender) {
            $security.defender_enabled = $defender.AntivirusEnabled
            $security.antivirus_enabled = $defender.AntivirusEnabled
            $security.realtime_protection = $defender.RealTimeProtectionEnabled
            $security.definitions_age_days = $defender.AntivirusSignatureAge
        }
    }
    catch { Write-Log "Defender status inspection failed: $_" -Level DEBUG }

    try {
        $bitlocker = Get-BitLockerVolume -MountPoint "C:" -ErrorAction SilentlyContinue
        if ($bitlocker) {
            $security.bitlocker_enabled = $bitlocker.ProtectionStatus -eq "On"
        }
    }
    catch { Write-Log "BitLocker status inspection failed: $_" -Level DEBUG }

    $payload = @{
        agent_id = $AgentId
        hostname = $sysInfo.hostname
        os_type = $sysInfo.os_type
        os_name = $sysInfo.os_name
        os_version = $sysInfo.os_version
        architecture = $sysInfo.architecture
        domain = $sysInfo.domain
        ip_addresses = $ipAddresses
        packages = $packages
        services = $services
        open_ports = $openPorts
        updates_available = $updatesAvailable
        update_count = $updateCount
        users = $users
        security = $security
        agent_version = $script:AgentVersion
        discovered_at = (Get-Date).ToString("o")
    }

    # Save discovery data locally (for FleetAgentExecutor to read)
    $discoveryFile = Join-Path $script:CacheDir "last_discovery.json"
    if (Test-DiskHeadroom -Path $script:CacheDir -Context "discovery cache storage") {
        $payload | ConvertTo-Json -Depth 10 | Set-Content $discoveryFile -Encoding UTF8
    }
    else {
        Write-Log "Skipping local discovery cache write due to low disk" -Level WARN
    }

    $response = Invoke-AgentApi -Method POST -Endpoint "/api/agent/discovery" -Body $payload

    if ($response -and $response.success) {
        Write-Log "Discovery data uploaded successfully"
        $script:LastDiscoveryTime = Get-Date
        return @{ success = $true; payload = $payload }
    }

    Write-Log "Discovery upload failed" -Level ERROR
    return @{ success = $false }
}

# =============================================================================
# Asset Discovery Sync
# =============================================================================
function Sync-ToAssetDiscovery {
    <#
    .SYNOPSIS
        Sync discovery data to the Asset Discovery service
    #>
    if ([string]::IsNullOrEmpty($AssetDiscoveryUrl)) {
        Write-Log "Asset Discovery URL not configured, skipping sync" -Level DEBUG
        return @{ success = $true; skipped = $true }
    }

    Write-Log "Syncing discovery data to Asset Discovery service..."

    $discoveryFile = Join-Path $script:CacheDir "last_discovery.json"
    if (-not (Test-Path $discoveryFile)) {
        Write-Log "No discovery data available, run discovery first" -Level WARN
        return @{ success = $false; error = "No discovery data" }
    }

    try {
        $discoveryData = Get-Content $discoveryFile -Raw | ConvertFrom-Json

        # Add connectivity info
        $discoveryData | Add-Member -NotePropertyName "agent_connectivity" -NotePropertyValue @{
            agent_id = $AgentId
            server_url = $ServerUrl
            status = "online"
            last_seen = (Get-Date).ToString("o")
            capabilities = @("discovery", "audit", "cve_scan", "port_scan")
        } -Force

        $headers = @{
            "Content-Type" = "application/json"
            "X-Agent-ID" = $AgentId
            "X-API-Key" = $ApiKey
        }

        $body = $discoveryData | ConvertTo-Json -Depth 10

        $null = Invoke-RestMethod -Uri "$AssetDiscoveryUrl/api/agent/discovery/sync" `
            -Method POST -Headers $headers -Body $body `
            -TimeoutSec 30 -ErrorAction Stop

        Write-Log "Successfully synced to Asset Discovery service"
        return @{ success = $true }
    }
    catch {
        if ($_.Exception.Response.StatusCode -eq 404) {
            Write-Log "Asset Discovery sync endpoint not available (404)" -Level DEBUG
            return @{ success = $true; skipped = $true }
        }
        Write-Log "Asset Discovery sync failed: $_" -Level WARN
        return @{ success = $false; error = $_.Exception.Message }
    }
}

# =============================================================================
# Daemon Mode
# =============================================================================
function Start-AgentDaemon {
    Write-Log "Starting fleet agent daemon (poll interval: ${PollInterval}s)"
    Write-Log "Auto-discovery: $AutoDiscovery (interval: ${DiscoveryInterval}s)"

    # Initialize and detect elevation capabilities (JEA, Admin, or reduced mode)
    Initialize-ElevationMethod
    $elevStatus = Get-ElevationStatus

    Write-Log "Elevation mode: $($elevStatus.Mode)"
    if ($elevStatus.ReducedMode) {
        Write-Log "Running in reduced-privilege mode - some audits may have limited access" -Level WARN
        Write-Log "For full capabilities, configure JEA or run as Administrator" -Level INFO
    }

    # Register on startup (includes capabilities)
    if (-not (Register-Agent)) {
        Write-Log "Registration failed, will retry" -Level WARN
    }

    # Initial heartbeat gate: fleet agent cannot run without core server association
    $heartbeatOk = $false
    for ($attempt = 1; $attempt -le $script:MaxHeartbeatFailures; $attempt++) {
        if (Invoke-AgentHeartbeat) {
            $heartbeatOk = $true
            break
        }

        Write-Log "Initial heartbeat attempt $attempt/$($script:MaxHeartbeatFailures) failed" -Level WARN
        Start-Sleep -Seconds $script:HeartbeatTimeout
    }

    if (-not $heartbeatOk) {
        Write-Log "Core server heartbeat validation failed after $($script:MaxHeartbeatFailures) attempts" -Level ERROR
        Write-Log "Managed agent cannot run without successful heartbeat association" -Level ERROR
        exit 1
    }

    # Initial config fetch
    Get-AgentConfig | Out-Null

    # Initial sync
    try {
        $serverConfig = Get-Content (Join-Path $script:CacheDir "server_config.json") | ConvertFrom-Json
        if ($serverConfig.sync.sync_on_startup) {
            Sync-FullPackage | Out-Null
        }
    }
    catch { Write-Log "Initial sync-on-startup check skipped: $_" -Level DEBUG }

    # Run initial discovery on startup (required for Asset Discovery integration)
    if ($AutoDiscovery) {
        Write-Log "Running initial discovery scan..."
        $discResult = Invoke-Discovery
        if ($discResult.success) {
            Sync-ToAssetDiscovery | Out-Null
        }
    }

    # Upload pending results
    Send-AllPendingResults
    Invoke-ResultRetention

    # Main loop
    while ($true) {
        try {
            $pollOk = Invoke-ServerPoll

            if (-not $pollOk) {
                if ($script:ConsecutiveHeartbeatFailures -ge $script:MaxHeartbeatFailures) {
                    Write-Log "Max heartbeat failures reached ($($script:ConsecutiveHeartbeatFailures)/$($script:MaxHeartbeatFailures)); stopping agent" -Level ERROR
                    Write-Log "Last heartbeat status: $($script:LastHeartbeatStatus); reason: $($script:LastHeartbeatReason)" -Level ERROR
                    exit 1
                }

                Write-Log "Poll failed, will retry" -Level WARN
            }

            # Check if discovery is due
            if ($AutoDiscovery) {
                $elapsed = (Get-Date) - $script:LastDiscoveryTime
                if ($elapsed.TotalSeconds -ge $DiscoveryInterval) {
                    Write-Log "Running scheduled discovery scan..."
                    $discResult = Invoke-Discovery
                    if ($discResult.success) {
                        Sync-ToAssetDiscovery | Out-Null
                    }
                }
            }

            Invoke-ResultRetention
        }
        catch {
            Write-Log "Poll error: $_" -Level WARN
        }

        Start-Sleep -Seconds $PollInterval
    }
}

# =============================================================================
# Interactive Mode
# =============================================================================
function Show-Menu {
    Clear-Host
    Write-Output ""
    Write-Output "=================================================================="
    Write-Output "Managed Security Audit Agent for Windows v$script:AgentVersion"
    Write-Output "=================================================================="
    Write-Output ""
    Write-Output "  Agent ID: $script:AgentId"
    Write-Output "  Server:   $ServerUrl"
    Write-Output "  Config:   Version $script:ConfigVersion"
    Write-Output ""
    Write-Output "-------------------------------------------------------------------"
    Write-Output ""
    Write-Output "  1) Register with server"
    Write-Output "  2) Fetch configuration"
    Write-Output "  3) Sync audit scripts"
    Write-Output "  4) Run discovery"
    Write-Output "  5) Upload pending results"
    Write-Output "  6) Poll for commands"
    Write-Output "  7) Start daemon mode"
    Write-Output "  8) Configure server URL"
    Write-Output "  q) Quit"
    Write-Output ""

    $choice = Read-Host "Select option"

    switch ($choice) {
        "1" { Register-Agent; Read-Host "Press Enter to continue" }
        "2" { Get-AgentConfig; Read-Host "Press Enter to continue" }
        "3" { Sync-FullPackage; Read-Host "Press Enter to continue" }
        "4" { Invoke-Discovery; Read-Host "Press Enter to continue" }
        "5" { Send-AllPendingResults; Read-Host "Press Enter to continue" }
        "6" { Invoke-ServerPoll; Read-Host "Press Enter to continue" }
        "7" { Start-AgentDaemon }
        "8" {
            $script:ServerUrl = Read-Host "Server URL"
            $script:ApiKey = Read-Host "API Key"
            Save-Config
            Write-Output "Configuration saved"
            Read-Host "Press Enter to continue"
        }
        "q" { exit 0 }
        "Q" { exit 0 }
        default { Write-Host "Invalid option" }
    }
}

# =============================================================================
# Main
# =============================================================================
Initialize-Directories
Import-Config

switch ($Mode) {
    "daemon" {
        Start-AgentDaemon
    }
    "poll" {
        Invoke-ServerPoll
    }
    "register" {
        Register-Agent
    }
    "sync" {
        Sync-FullPackage
    }
    "discovery" {
        Invoke-Discovery
    }
    "upload" {
        Send-AllPendingResults
    }
    "run" {
        if (-not $AuditPath) {
            Write-Log "AuditPath required for run mode" -Level ERROR
            exit 1
        }
        Invoke-Audit -AuditPath $AuditPath
    }
    "rotate-key" {
        if (-not $NewApiKey) {
            Write-Log "NewApiKey parameter required for rotate-key mode" -Level ERROR
            Write-Output ""
            Write-Output "Usage: .\fleet-agent.ps1 -Mode rotate-key -NewApiKey 'YOUR_NEW_KEY'"
            Write-Output ""
            Get-KeyRotationStatus
            exit 1
        }
        $result = Update-ApiKey -NewKey $NewApiKey -Force
        if (-not $result) {
            exit 1
        }
    }
    "show-cert" {
        Show-ServerCertificateHash
        Get-KeyRotationStatus
    }
    "self-update" {
        if (-not (Invoke-SelfUpdate)) {
            exit 1
        }
    }
    "interactive" {
        while ($true) {
            Show-Menu
        }
    }
}
