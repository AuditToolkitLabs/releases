#!/usr/bin/env bash
# Sync audit scripts from the main repository to the standalone agent
# Copies Linux audit scripts and libraries to the agent's audits folder
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_DIR="$(dirname "$SCRIPT_DIR")"
AGENT_AUDITS_DIR="$AGENT_DIR/audits"
AGENT_LIB_DIR="$AGENT_AUDITS_DIR/_lib"

# Default source is parent of agent folder
SOURCE_PATH="${1:-$(dirname "$(dirname "$AGENT_DIR")")}"

echo "Standalone Agent Audit Sync"
echo "============================"
echo "Source: $SOURCE_PATH"
echo "Target: $AGENT_AUDITS_DIR"
echo ""

# Source paths
SOURCE_LINUX_AUDITS="$SOURCE_PATH/audits/linux"
SOURCE_LIB="$SOURCE_PATH/lib"

# Verify source exists
if [[ ! -d "$SOURCE_LINUX_AUDITS" ]]; then
    echo "[ERROR] Source audits not found: $SOURCE_LINUX_AUDITS" >&2
    echo "Usage: $0 [path-to-audit-tool-repo]" >&2
    exit 1
fi

if [[ ! -d "$SOURCE_LIB" ]]; then
    echo "[ERROR] Source lib not found: $SOURCE_LIB" >&2
    exit 1
fi

# Create directories
mkdir -p "$AGENT_LIB_DIR"

# Copy library files (required by all Linux audits)
echo "Copying library files..."
for lib in common.sh distro.sh pkg.sh svc.sh firewall.sh paths.sh security_stack.sh; do
    if [[ -f "$SOURCE_LIB/$lib" ]]; then
        cp "$SOURCE_LIB/$lib" "$AGENT_LIB_DIR/"
        echo "[OK] Copied $lib"
    fi
done

# Define audit categories to sync
declare -A CATEGORIES=(
    ["platform/baseline"]="platform/baseline"
    ["platform/hardening"]="platform/hardening"
    ["network"]="network"
    ["apps"]="apps"
    ["data"]="data"
    ["web"]="web"
)

total_copied=0

for source_cat in "${!CATEGORIES[@]}"; do
    target_cat="${CATEGORIES[$source_cat]}"
    source_dir="$SOURCE_LINUX_AUDITS/$source_cat"
    target_dir="$AGENT_AUDITS_DIR/linux/$target_cat"

    if [[ -d "$source_dir" ]]; then
        echo "Syncing $source_cat audits..."
        mkdir -p "$target_dir"

        count=0
        for script in "$source_dir"/*.sh; do
            [[ -f "$script" ]] || continue

            # Read and modify library paths for agent context
            filename=$(basename "$script")

            # Create modified version with updated lib paths
            # shellcheck disable=SC2016  # single-quote $ is intentional in sed pattern
            sed -E 's|\. "\$\(dirname.*\)/.*lib/([^"]+)"|. "$(dirname "$0")/../../_lib/\1"|g' \
                "$script" > "$target_dir/$filename"
            chmod +x "$target_dir/$filename"

            ((count++)) || true
            ((total_copied++)) || true
        done

        echo "[OK] Copied $count scripts from $source_cat"
    fi
done

echo ""
echo "============================"
echo "Sync complete: $total_copied audit scripts"
echo ""
echo "Available audit categories:"
find "$AGENT_AUDITS_DIR" -type d -mindepth 1 -maxdepth 2 | while read -r dir; do
    count=$(find "$dir" -name "*.sh" 2>/dev/null | wc -l)
    if [[ $count -gt 0 ]]; then
        relpath="${dir#"$AGENT_AUDITS_DIR"/}"
        echo "  - $relpath: $count audits"
    fi
done
