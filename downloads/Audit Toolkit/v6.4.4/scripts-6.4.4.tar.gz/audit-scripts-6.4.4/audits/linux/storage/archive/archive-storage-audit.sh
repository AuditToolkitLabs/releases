#!/usr/bin/env bash
# Portable Archive Storage Audit (multi-OS)
#
# @elevation: partial
# @elevation-reason: Archive checks may need root for protected directories
#
set -euo pipefail
. "$(dirname "$0")/../../../../lib/distro.sh"
SCRIPT_NAME="${0##*/}"; SCRIPT_VERSION="3.0.2"
LOG_FILE=""; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0
have(){ command -v "$1" >/dev/null 2>&1; }
_ts(){ date '+%Y-%m-%d %H:%M:%S'; }
log(){ [[ "$QUIET" == false ]] && echo "[$(_ts)] $*"; [[ -n "$LOG_FILE" ]] && echo "[$(_ts)] $*" >>"$LOG_FILE" || true; }
reg(){ local n="$1" r="$2" m="${3:-}"; N+=("$n"); R+=("$r"); M+=("$m"); ((++T)); case "$r" in PASS) ((++P));; FAIL) ((++F)); EXIT_CODE=2;; WARN) ((++W)); [[ $EXIT_CODE -eq 0 ]] && EXIT_CODE=1;; SKIP) ((++S));; esac; log "$r - $n${m:+: $m}"; }

N=(); R=(); M=(); T=0; P=0; F=0; W=0; S=0
CUSTOM_PATHS=()
RECENT_DAYS=30

# Override reg to use [MARKER] format for test detection
reg(){ local n="$1" r="$2" m="${3:-}"; N+=("$n"); R+=("$r"); M+=("$m"); ((++T)); case "$r" in PASS) ((++P));; FAIL) ((++F)); EXIT_CODE=2;; WARN) ((++W)); [[ $EXIT_CODE -eq 0 ]] && EXIT_CODE=1;; SKIP) ((++S));; esac; log "[$r] $n${m:+: $m}"; }

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [--log FILE] [--path DIR]... [--quiet] [--verbose]
EOF
}
parse(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-}"; shift 2;;
  -p|--path) [[ -n "${2:-}" ]] && CUSTOM_PATHS+=("$2"); shift 2;;
  -q|--quiet) QUIET=true; shift;;
  -v|--verbose) VERBOSE=true; shift;;
  --no-color) NO_COLOR=true; shift;;
  -h|--help) usage; exit 0;;
  --version) echo "$SCRIPT_NAME $SCRIPT_VERSION"; exit 0;;
  *) echo "Unknown option: $1" >&2; exit 1;; esac; done }

fmt_size(){ local s="$1"; if (( s>=1073741824 )); then echo "$((s/1073741824))G"; elif (( s>=1048576 )); then echo "$((s/1048576))M"; elif (( s>=1024 )); then echo "$((s/1024))K"; else echo "${s}B"; fi }

check_path(){
  local p="$1"; [[ -d "$p" ]] || return 1
  local perms owner; perms=$(stat -c '%a' "$p" 2>/dev/null || stat -f '%Lp' "$p" 2>/dev/null || echo unknown)
  owner=$(stat -c '%U:%G' "$p" 2>/dev/null || echo unknown)
  case "$perms" in 777|775) reg "Permissions: $p" WARN "Mode $perms may be too open";; *) reg "Permissions: $p" PASS "Mode $perms ($owner)";; esac
  local files size; files=$(find "$p" -type f 2>/dev/null | wc -l | awk '{print $1}')
  size=$(du -sb "$p" 2>/dev/null | awk '{print $1}')
  files=${files:-0}; size=${size:-0}
  reg "Archive: $p" PASS "$files files, $(fmt_size "$size") total"
  local recent; recent=$(find "$p" -type f -mtime -"$RECENT_DAYS" 2>/dev/null | wc -l | awk '{print $1}')
  recent=${recent:-0}; (( recent>0 )) && reg "Recent activity: $p" PASS "$recent files modified in last $RECENT_DAYS days" || reg "Recent activity: $p" WARN "No files modified in last $RECENT_DAYS days"
  local use; use=$(df "$p" 2>/dev/null | tail -1 | awk '{print $5}' | tr -d '%'); use=${use:-0}
  if (( use>=90 )); then reg "Disk space: $p" FAIL "Usage ${use}% (critical)"; elif (( use>=80 )); then reg "Disk space: $p" WARN "Usage ${use}% (high)"; else reg "Disk space: $p" PASS "Usage ${use}%"; fi
}

audit(){
  local defaults=(/srv/archive /data/archive /var/archive /backup /mnt/backup)
  local paths=("${defaults[@]}")
  if (( ${#CUSTOM_PATHS[@]} > 0 )); then paths+=("${CUSTOM_PATHS[@]}"); fi
  local found=0
  for p in "${paths[@]}"; do if check_path "$p"; then ((found++)); fi; done
  (( found==0 )) && reg "Archive locations" WARN "No archive directories found"
  # backup automation hints
  if is_systemd; then
    local svc; svc=$(systemctl list-units --type=service --all 2>/dev/null | grep -Ei 'backup|restic|borg|duplicity|rsync' | head -3 || true)
    local tmr; tmr=$(systemctl list-timers --all 2>/dev/null | grep -Ei 'backup|restic|borg|duplicity|rsync' | head -3 || true)
    if [[ -n "$svc$tmr" ]]; then reg "Backup automation" PASS "systemd services/timers present"; else reg "Backup automation" WARN "No backup services/timers detected"; fi
  elif is_openrc; then
    local cron; cron=$(grep -rilE 'backup|restic|borg|duplicity|rsync' /etc/cron.* 2>/dev/null | wc -l | awk '{print $1}')
    (( cron>0 )) && reg "Cron backup jobs" PASS "$cron job(s) found" || reg "Cron backup jobs" WARN "No cron jobs detected"
  else
    local cron; cron=$(grep -rilE 'backup|restic|borg|duplicity|rsync' /etc/cron.* 2>/dev/null | wc -l | awk '{print $1}')
    (( cron>0 )) && reg "Cron backup jobs" PASS "$cron job(s) found" || reg "Cron backup jobs" WARN "No cron jobs detected"
  fi
}

summary(){ echo; echo "== ARCHIVE STORAGE SUMMARY =="; echo " Checks: $T | Passed: $P | Failed: $F | Warnings: $W | Skipped: $S"
  if (( F>0 )); then echo " Status: FAILED"; elif (( W>0 )); then echo " Status: PASSED WITH WARNINGS"; elif (( P==0 )); then echo " Status: SKIPPED"; else echo " Status: PASSED"; fi }

parse "$@"; audit; summary; exit "$EXIT_CODE"
