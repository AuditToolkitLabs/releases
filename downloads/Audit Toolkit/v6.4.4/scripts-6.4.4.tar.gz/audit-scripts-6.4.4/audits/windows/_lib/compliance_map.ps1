# Compliance Mapping Module (PowerShell)
# Framework-aware compliance scoring and gap reporting helpers.

$script:ComplianceFrameworks = @{
    CIS = @{
        Name = 'CIS Windows Benchmark'
        Version = '3.0.0'
        Categories = @(
            'Account Policies',
            'Local Policies',
            'Event Log',
            'Restricted Groups',
            'System Services',
            'Registry',
            'File System',
            'Windows Firewall',
            'Advanced Audit Policy',
            'Administrative Templates'
        )
    }
    NIST = @{
        Name = 'NIST SP 800-53 Rev 5'
        Version = '5.1'
        Categories = @(
            'Access Control (AC)',
            'Audit and Accountability (AU)',
            'Configuration Management (CM)',
            'Identification and Authentication (IA)',
            'System and Communications Protection (SC)',
            'System and Information Integrity (SI)'
        )
    }
    PCI = @{
        Name = 'PCI DSS'
        Version = '4.0'
        Categories = @(
            'Requirement 1: Network Security',
            'Requirement 2: Secure Configurations',
            'Requirement 5: Anti-Malware',
            'Requirement 6: Secure Systems',
            'Requirement 7: Access Control',
            'Requirement 8: User Authentication',
            'Requirement 10: Logging and Monitoring'
        )
    }
    HIPAA = @{
        Name = 'HIPAA Security Rule'
        Version = '2024'
        Categories = @(
            'Administrative Safeguards',
            'Physical Safeguards',
            'Technical Safeguards',
            'Organizational Requirements'
        )
    }
    SOC2 = @{
        Name = 'SOC 2 Type II'
        Version = '2024'
        Categories = @('Security', 'Availability', 'Processing Integrity', 'Confidentiality', 'Privacy')
    }
}

$script:ControlMappings = @{
    'Password Policy' = @{ CIS = @('1.1.1', '1.1.2', '1.1.3', '1.1.4', '1.1.5', '1.1.6', '1.1.7'); NIST = @('IA-5', 'IA-5(1)'); PCI = @('8.3.6', '8.3.7', '8.3.9'); HIPAA = @('164.312(d)'); SOC2 = @('CC6.1') }
    'Account Lockout' = @{ CIS = @('1.2.1', '1.2.2', '1.2.3', '1.2.4'); NIST = @('AC-7'); PCI = @('8.3.4'); HIPAA = @('164.312(a)(1)'); SOC2 = @('CC6.1') }
    'User Rights Assignment' = @{ CIS = @('2.2.*'); NIST = @('AC-6', 'AC-6(1)', 'AC-6(5)'); PCI = @('7.1', '7.2'); HIPAA = @('164.312(a)(1)'); SOC2 = @('CC6.1', 'CC6.3') }
    'Security Options' = @{ CIS = @('2.3.*'); NIST = @('AC-3', 'SC-8', 'SC-13'); PCI = @('2.2', '4.1'); HIPAA = @('164.312(a)(1)', '164.312(e)(1)'); SOC2 = @('CC6.1', 'CC6.6', 'CC6.7') }
    'Audit Policy' = @{ CIS = @('17.*'); NIST = @('AU-2', 'AU-3', 'AU-6', 'AU-12'); PCI = @('10.2', '10.3', '10.5'); HIPAA = @('164.312(b)'); SOC2 = @('CC7.2', 'CC7.3') }
    'Windows Firewall' = @{ CIS = @('9.*'); NIST = @('SC-7', 'SC-7(5)'); PCI = @('1.1', '1.2', '1.3'); HIPAA = @('164.312(e)(1)'); SOC2 = @('CC6.6') }
    'Windows Defender' = @{ CIS = @('18.9.47.*'); NIST = @('SI-3', 'SI-3(1)', 'SI-3(2)'); PCI = @('5.1', '5.2', '5.3'); HIPAA = @('164.308(a)(5)(ii)(B)'); SOC2 = @('CC6.8') }
    BitLocker = @{ CIS = @('18.9.11.*'); NIST = @('SC-12', 'SC-13', 'SC-28'); PCI = @('3.4', '3.5'); HIPAA = @('164.312(a)(2)(iv)', '164.312(e)(2)(ii)'); SOC2 = @('CC6.1', 'CC6.7') }
    'Credential Guard' = @{ CIS = @('18.9.5.*'); NIST = @('IA-2', 'IA-5'); PCI = @('8.2'); HIPAA = @('164.312(d)'); SOC2 = @('CC6.1') }
    'NTLM Restrictions' = @{ CIS = @('2.3.11.*'); NIST = @('IA-2(8)', 'SC-8', 'SC-23'); PCI = @('4.1', '8.2'); HIPAA = @('164.312(d)', '164.312(e)(1)'); SOC2 = @('CC6.7') }
    'RDP Configuration' = @{ CIS = @('18.9.65.*'); NIST = @('AC-17', 'AC-17(2)', 'IA-2(1)'); PCI = @('8.3.1', '8.3.2'); HIPAA = @('164.312(d)', '164.312(e)(1)'); SOC2 = @('CC6.1', 'CC6.6') }
    'System Services' = @{ CIS = @('5.*'); NIST = @('CM-7', 'CM-7(1)'); PCI = @('2.2.2', '2.2.3'); HIPAA = @('164.308(a)(1)(ii)(B)'); SOC2 = @('CC6.1') }
    'Windows Update' = @{ CIS = @('18.9.108.*'); NIST = @('SI-2', 'SI-2(2)'); PCI = @('6.3.3'); HIPAA = @('164.308(a)(1)(ii)(B)'); SOC2 = @('CC7.1') }
    LAPS = @{ CIS = @('18.2.1', '18.2.2', '18.2.3'); NIST = @('AC-2(1)', 'IA-5(1)'); PCI = @('8.6.1', '8.6.2'); HIPAA = @('164.312(d)'); SOC2 = @('CC6.1') }
    'EDR Coverage' = @{ CIS = @(); NIST = @('SI-3', 'SI-4', 'SI-4(4)'); PCI = @('5.1', '5.2', '11.5'); HIPAA = @('164.308(a)(1)(ii)(D)'); SOC2 = @('CC6.8', 'CC7.2') }
    'SIEM Coverage' = @{ CIS = @(); NIST = @('AU-6', 'AU-6(1)', 'SI-4'); PCI = @('10.5.1', '10.6', '10.7'); HIPAA = @('164.312(b)'); SOC2 = @('CC7.2', 'CC7.3') }
    'VPN Configuration' = @{ CIS = @(); NIST = @('AC-17(2)', 'SC-8', 'SC-13'); PCI = @('4.1', '4.2'); HIPAA = @('164.312(e)(1)', '164.312(e)(2)(ii)'); SOC2 = @('CC6.7') }
    'MDM Enrollment' = @{ CIS = @(); NIST = @('CM-2', 'CM-6', 'CM-8'); PCI = @('2.2'); HIPAA = @('164.308(a)(1)(ii)(B)'); SOC2 = @('CC6.1') }
}

function Get-ComplianceMapping {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$CheckName,
        [ValidateSet('CIS', 'NIST', 'PCI', 'HIPAA', 'SOC2')]
        [string]$Framework
    )

    foreach ($category in $script:ControlMappings.Keys) {
        if ($CheckName -match [regex]::Escape($category) -or $category -match [regex]::Escape($CheckName)) {
            $categoryMapping = $script:ControlMappings[$category]
            if ($PSBoundParameters.ContainsKey('Framework')) {
                return @{ $Framework = @($categoryMapping[$Framework]) }
            }
            return $categoryMapping
        }
    }

    if ($PSBoundParameters.ContainsKey('Framework')) {
        return @{ $Framework = @() }
    }
    return @{}
}

function Get-ComplianceGap {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Results,
        [Parameter(Mandatory)]
        [ValidateSet('CIS', 'NIST', 'PCI', 'HIPAA', 'SOC2')]
        [string]$Framework
    )

    $gapList = @()
    $passedControlCount = 0
    $failedControlCount = 0

    foreach ($result in $Results) {
        $map = Get-ComplianceMapping -CheckName $result.Name
        $controlList = @()
        if ($map -and $map.ContainsKey($Framework)) {
            $controlList = @($map[$Framework])
        }

        if ($controlList.Count -eq 0) {
            continue
        }

        if ($result.Status -in @('FAIL', 'WARN')) {
            foreach ($control in $controlList) {
                $gapList += [pscustomobject]@{
                        Control = $control
                        CheckName = $result.Name
                        Status = $result.Status
                        Message = $result.Message
                    }
                $failedControlCount++
            }
            continue
        }

        if ($result.Status -eq 'PASS') {
            $passedControlCount += $controlList.Count
        }
    }

    $totalControlCount = $passedControlCount + $failedControlCount
    $score = 0
    if ($totalControlCount -gt 0) {
        $score = [math]::Round(($passedControlCount / $totalControlCount) * 100, 1)
    }

    return [pscustomobject]@{
        Framework = $Framework
        FrameworkName = $script:ComplianceFrameworks[$Framework].Name
        TotalControls = $totalControlCount
        PassedControls = $passedControlCount
        FailedControls = $failedControlCount
        ComplianceScore = $score
        Gaps = $gapList
    }
}

function Get-ComplianceReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Results
    )

    $frameworkReport = [ordered]@{}
    $scoreList = New-Object System.Collections.Generic.List[double]

    foreach ($frameworkName in @('CIS', 'NIST', 'PCI', 'HIPAA', 'SOC2')) {
        $frameworkResult = Get-ComplianceGap -Results $Results -Framework $frameworkName
        $frameworkReport[$frameworkName] = $frameworkResult
        $scoreList.Add([double]$frameworkResult.ComplianceScore)
    }

    $overallScore = 0
    if ($scoreList.Count -gt 0) {
        $overallScore = [math]::Round(($scoreList | Measure-Object -Average).Average, 1)
    }

    return [pscustomobject]@{
        GeneratedAt = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        ComputerName = $env:COMPUTERNAME
        Frameworks = $frameworkReport
        OverallScore = $overallScore
    }
}

function Format-ComplianceReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$Report
    )

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('')
    $lines.Add('=' * 70)
    $lines.Add("COMPLIANCE REPORT - $($Report.ComputerName)")
    $lines.Add("Generated: $($Report.GeneratedAt)")
    $lines.Add('=' * 70)
    $lines.Add('')
    $lines.Add("OVERALL COMPLIANCE SCORE: $($Report.OverallScore)%")
    $lines.Add('')
    $lines.Add('-' * 70)
    $lines.Add('FRAMEWORK SUMMARY')
    $lines.Add('-' * 70)

    foreach ($frameworkName in $Report.Frameworks.Keys) {
        $frameworkResult = $Report.Frameworks[$frameworkName]
        $status = if ($frameworkResult.ComplianceScore -ge 80) { 'GOOD' } elseif ($frameworkResult.ComplianceScore -ge 60) { 'NEEDS IMPROVEMENT' } else { 'CRITICAL' }
        $lines.Add(('{0,-20} {1,10}% ({2}/{3} controls) - {4}' -f $frameworkResult.FrameworkName, $frameworkResult.ComplianceScore, $frameworkResult.PassedControls, $frameworkResult.TotalControls, $status))
    }

    $lines.Add('')
    $lines.Add('-' * 70)
    $lines.Add('COMPLIANCE GAPS BY FRAMEWORK')
    $lines.Add('-' * 70)

    foreach ($frameworkName in $Report.Frameworks.Keys) {
        $frameworkResult = $Report.Frameworks[$frameworkName]
        if (@($frameworkResult.Gaps).Count -eq 0) {
            continue
        }

        $lines.Add('')
        $lines.Add("$($frameworkResult.FrameworkName):")
        $groupedGap = $frameworkResult.Gaps | Group-Object -Property Control
        foreach ($group in $groupedGap | Select-Object -First 10) {
            $sample = $group.Group[0]
            $lines.Add("  [$($sample.Status)] $($group.Name): $($sample.CheckName)")
        }

        if (@($frameworkResult.Gaps).Count -gt 10) {
            $lines.Add("  ... and $(@($frameworkResult.Gaps).Count - 10) more gaps")
        }
    }

    $lines.Add('')
    $lines.Add('=' * 70)
    return ($lines -join "`n")
}

# Compatibility aliases for legacy callers.
Set-Alias -Name Get-ComplianceGaps -Value Get-ComplianceGap -Scope Script

if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function Get-ComplianceMapping, Get-ComplianceGap, Get-ComplianceReport, Format-ComplianceReport
    Export-ModuleMember -Alias Get-ComplianceGaps
}
