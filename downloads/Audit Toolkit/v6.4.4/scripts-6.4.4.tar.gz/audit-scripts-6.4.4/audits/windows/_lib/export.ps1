# Export Module (PowerShell)
# Export security audit results to JSON, CSV, HTML, XML, and SIEM JSON.

function Get-AuditExportMeta {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Result
    )

    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    return [ordered]@{
        ComputerName = $env:COMPUTERNAME
        Domain = $env:USERDOMAIN
        Username = $env:USERNAME
        Timestamp = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssZ')
        OSVersion = $os.Caption
        OSBuild = $os.BuildNumber
        TotalChecks = $Result.Count
        PassedChecks = @($Result | Where-Object Status -eq 'PASS').Count
        FailedChecks = @($Result | Where-Object Status -eq 'FAIL').Count
        WarningChecks = @($Result | Where-Object Status -eq 'WARN').Count
        InfoChecks = @($Result | Where-Object Status -eq 'INFO').Count
        SkippedChecks = @($Result | Where-Object Status -eq 'SKIP').Count
    }
}

function Export-AuditResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Result,
        [Parameter(Mandatory)]
        [string]$OutputPath,
        [ValidateSet('JSON', 'CSV', 'HTML', 'XML', 'SIEM', 'All')]
        [string[]]$Format = @('JSON'),
        [switch]$IncludeMetadata
    )

    if (-not $PSBoundParameters.ContainsKey('IncludeMetadata')) {
        $IncludeMetadata = $true
    }

    if ($Format -contains 'All') {
        $Format = @('JSON', 'CSV', 'HTML', 'XML', 'SIEM')
    }

    $metadata = Get-AuditExportMeta -Result $Result
    $writtenFileList = New-Object System.Collections.Generic.List[string]

    foreach ($oneFormat in $Format) {
        switch ($oneFormat) {
            'JSON' {
                $path = "$OutputPath.json"
                $payload = if ($IncludeMetadata) { @{ metadata = $metadata; results = $Result } } else { @{ results = $Result } }
                $payload | ConvertTo-Json -Depth 10 | Set-Content -Path $path -Encoding UTF8
                $writtenFileList.Add($path)
            }
            'CSV' {
                $path = "$OutputPath.csv"
                $Result | Select-Object @{ Name = 'Timestamp'; Expression = { $metadata.Timestamp } }, @{ Name = 'Computer'; Expression = { $metadata.ComputerName } }, Name, Status, Message, Section |
                    Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
                $writtenFileList.Add($path)
            }
            'HTML' {
                $path = "$OutputPath.html"
                $html = Export-ToHtmlReport -Result $Result -Metadata $metadata
                $html | Set-Content -Path $path -Encoding UTF8
                $writtenFileList.Add($path)
            }
            'XML' {
                $path = "$OutputPath.xml"
                $payload = if ($IncludeMetadata) { @{ metadata = $metadata; results = $Result } } else { @{ results = $Result } }
                $payload | ConvertTo-Xml -Depth 10 -As String | Set-Content -Path $path -Encoding UTF8
                $writtenFileList.Add($path)
            }
            'SIEM' {
                $path = "$OutputPath.siem.json"
                $siem = Export-ToSiemJson -Result $Result -Metadata $metadata
                $siem | Set-Content -Path $path -Encoding UTF8
                $writtenFileList.Add($path)
            }
        }
    }

    return @($writtenFileList)
}

function Export-ToHtmlReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Result,
        [Parameter(Mandatory)]
        [hashtable]$Metadata
    )

    $passRate = 0
    if ($Metadata.TotalChecks -gt 0) {
        $passRate = [math]::Round(($Metadata.PassedChecks / $Metadata.TotalChecks) * 100, 1)
    }

    $statusColor = if ($passRate -ge 80) { '#28a745' } elseif ($passRate -ge 60) { '#ffc107' } else { '#dc3545' }
    $resultRowMarkupList = New-Object System.Collections.Generic.List[string]

    $currentSection = ''
    foreach ($item in $Result) {
        if ($item.Section -and $item.Section -ne $currentSection) {
            $currentSection = $item.Section
            $resultRowMarkupList.Add("<tr class='section-header'><td colspan='3'>$currentSection</td></tr>")
        }

        $name = [System.Web.HttpUtility]::HtmlEncode([string]$item.Name)
        $message = [System.Web.HttpUtility]::HtmlEncode([string]$item.Message)
        $status = [System.Web.HttpUtility]::HtmlEncode([string]$item.Status)

        $resultRowMarkupList.Add(@"
<tr data-status=\"$status\">
    <td><span class=\"status status-$status\">$status</span></td>
    <td>$name</td>
    <td>$message</td>
</tr>
"@)
    }

    return @"
<!DOCTYPE html>
<html>
<head>
    <title>Security Audit Report - $($Metadata.ComputerName)</title>
    <meta charset='UTF-8'>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #0078d4; padding-bottom: 10px; }
        h2 { color: #0078d4; margin-top: 30px; }
        .summary { display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap; }
        .summary-card { background: #f8f9fa; padding: 20px; border-radius: 8px; min-width: 150px; text-align: center; }
        .summary-card.score { background: $statusColor; color: white; }
        .summary-card h3 { margin: 0 0 10px 0; font-size: 14px; text-transform: uppercase; }
        .summary-card .value { font-size: 32px; font-weight: bold; }
        .metadata { background: #e9ecef; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .metadata table { width: 100%; }
        .metadata td { padding: 5px 10px; }
        .metadata td:first-child { font-weight: bold; width: 150px; }
        table.results { width: 100%; border-collapse: collapse; margin: 20px 0; }
        table.results th { background: #0078d4; color: white; padding: 12px; text-align: left; }
        table.results td { padding: 10px; border-bottom: 1px solid #ddd; }
        table.results tr:hover { background: #f5f5f5; }
        .status { padding: 4px 12px; border-radius: 4px; font-weight: bold; font-size: 12px; }
        .status-PASS { background: #d4edda; color: #155724; }
        .status-FAIL { background: #f8d7da; color: #721c24; }
        .status-WARN { background: #fff3cd; color: #856404; }
        .status-INFO { background: #d1ecf1; color: #0c5460; }
        .status-SKIP { background: #e2e3e5; color: #383d41; }
        .section-header { background: #f8f9fa; font-weight: bold; }
        .filter-bar { margin: 20px 0; }
        .filter-bar button { padding: 8px 16px; margin-right: 5px; border: 1px solid #ddd; background: white; cursor: pointer; border-radius: 4px; }
        .filter-bar button:hover { background: #e9ecef; }
        .filter-bar button.active { background: #0078d4; color: white; border-color: #0078d4; }
        footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>Security Audit Report</h1>
        <div class='summary'>
            <div class='summary-card score'><h3>Compliance Score</h3><div class='value'>$passRate%</div></div>
            <div class='summary-card'><h3>Total Checks</h3><div class='value'>$($Metadata.TotalChecks)</div></div>
            <div class='summary-card'><h3>Passed</h3><div class='value' style='color:#28a745;'>$($Metadata.PassedChecks)</div></div>
            <div class='summary-card'><h3>Failed</h3><div class='value' style='color:#dc3545;'>$($Metadata.FailedChecks)</div></div>
            <div class='summary-card'><h3>Warnings</h3><div class='value' style='color:#ffc107;'>$($Metadata.WarningChecks)</div></div>
        </div>
        <div class='metadata'>
            <table>
                <tr><td>Computer Name:</td><td>$($Metadata.ComputerName)</td></tr>
                <tr><td>Domain:</td><td>$($Metadata.Domain)</td></tr>
                <tr><td>OS Version:</td><td>$($Metadata.OSVersion)</td></tr>
                <tr><td>OS Build:</td><td>$($Metadata.OSBuild)</td></tr>
                <tr><td>Scan Time:</td><td>$($Metadata.Timestamp)</td></tr>
                <tr><td>Scanned By:</td><td>$($Metadata.Username)</td></tr>
            </table>
        </div>
        <h2>Audit Results</h2>
        <div class='filter-bar'>
            <button class='active' onclick='filterResults(this, "all")'>All</button>
            <button onclick='filterResults(this, "FAIL")'>Failed</button>
            <button onclick='filterResults(this, "WARN")'>Warnings</button>
            <button onclick='filterResults(this, "PASS")'>Passed</button>
            <button onclick='filterResults(this, "INFO")'>Info</button>
        </div>
        <table class='results' id='resultsTable'>
            <thead><tr><th style='width:100px;'>Status</th><th>Check Name</th><th>Details</th></tr></thead>
            <tbody>
                $($resultRowMarkupList -join "`n")
            </tbody>
        </table>
        <footer><p>Generated by Security Audit Toolkit | $($Metadata.Timestamp)</p></footer>
    </div>
<script>
function filterResults(btn, status) {
    const rows = document.querySelectorAll('#resultsTable tbody tr:not(.section-header)');
    const buttons = document.querySelectorAll('.filter-bar button');
    buttons.forEach(function(item){ item.classList.remove('active'); });
    btn.classList.add('active');
    rows.forEach(function(row){ row.style.display = (status === 'all' || row.dataset.status === status) ? '' : 'none'; });
}
</script>
</body>
</html>
"@
}

function Export-ToSiemJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Result,
        [Parameter(Mandatory)]
        [hashtable]$Metadata
    )

    $eventList = New-Object System.Collections.Generic.List[object]

    foreach ($item in $Result) {
        $severity = switch ($item.Status) {
            'FAIL' { 8 }
            'WARN' { 5 }
            'PASS' { 1 }
            'INFO' { 3 }
            'SKIP' { 0 }
            default { 3 }
        }

        $eventList.Add([ordered]@{
                version = '0'
                deviceVendor = 'SecurityAuditToolkit'
                deviceProduct = 'WindowsAudit'
                deviceVersion = '4.3.0'
                signatureId = ([string]$item.Name -replace '\s+', '_')
                name = $item.Name
                severity = $severity
                timestamp = $Metadata.Timestamp
                dvchost = $Metadata.ComputerName
                dvc = $Metadata.ComputerName
                outcome = $item.Status
                msg = $item.Message
                cs1 = $item.Section
                cs1Label = 'AuditSection'
                cs2 = $Metadata.Domain
                cs2Label = 'Domain'
                cat = 'SecurityAudit'
                suser = $Metadata.Username
                deviceExternalId = "$($Metadata.ComputerName)-$($Metadata.Timestamp)"
            })
    }

    return ($eventList | ConvertTo-Json -Depth 5)
}

function Export-ExecutiveSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Result,
        [string]$OutputPath
    )

    $total = $Result.Count
    $passed = @($Result | Where-Object Status -eq 'PASS').Count
    $failed = @($Result | Where-Object Status -eq 'FAIL').Count
    $warningCount = @($Result | Where-Object Status -eq 'WARN').Count

    $score = 0
    if ($total -gt 0) {
        $score = [math]::Round(($passed / $total) * 100, 1)
    }

    $headline = if ($score -ge 80) { 'GOOD' } elseif ($score -ge 60) { 'NEEDS ATTENTION' } else { 'CRITICAL' }

    $summary = @"
================================================================================
                    EXECUTIVE SECURITY SUMMARY
================================================================================

Computer:       $env:COMPUTERNAME
Date:           $(Get-Date -Format 'dddd, MMMM dd, yyyy')
Time:           $(Get-Date -Format 'HH:mm:ss')

--------------------------------------------------------------------------------
                           COMPLIANCE SCORE
--------------------------------------------------------------------------------

                              $score%

    [$headline]

--------------------------------------------------------------------------------
                              SUMMARY
--------------------------------------------------------------------------------

    Total Security Checks:    $total
    Passed:                   $passed
    Failed:                   $failed
    Warnings:                 $warningCount

--------------------------------------------------------------------------------
                         KEY FINDINGS
--------------------------------------------------------------------------------

"@

    $critical = $Result | Where-Object Status -eq 'FAIL' | Select-Object -First 5
    if (@($critical).Count -gt 0) {
        $summary += "CRITICAL ISSUES (Immediate Action Required):`n"
        foreach ($item in $critical) {
            $summary += "  - $($item.Name): $($item.Message)`n"
        }
        $summary += "`n"
    }

    $warnings = $Result | Where-Object Status -eq 'WARN' | Select-Object -First 5
    if (@($warnings).Count -gt 0) {
        $summary += "WARNINGS (Review Recommended):`n"
        foreach ($item in $warnings) {
            $summary += "  - $($item.Name): $($item.Message)`n"
        }
        $summary += "`n"
    }

    $summary += @"
--------------------------------------------------------------------------------
                         RECOMMENDATIONS
--------------------------------------------------------------------------------

1. Address all CRITICAL issues within 24-48 hours
2. Review WARNING items within 1-2 weeks
3. Schedule recurring audits (recommended: weekly)
4. Document exceptions in security risk register

================================================================================
                  Generated by Security Audit Toolkit
================================================================================
"@

    if ($PSBoundParameters.ContainsKey('OutputPath') -and $OutputPath) {
        $summary | Set-Content -Path $OutputPath -Encoding UTF8
    }

    return $summary
}

# Compatibility aliases for existing callers.
Set-Alias -Name Export-AuditResults -Value Export-AuditResult -Scope Script
Set-Alias -Name Export-ToHtml -Value Export-ToHtmlReport -Scope Script
Set-Alias -Name Export-ToSIEM -Value Export-ToSiemJson -Scope Script

if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function Export-AuditResult, Export-ToHtmlReport, Export-ToSiemJson, Export-ExecutiveSummary
    Export-ModuleMember -Alias Export-AuditResults, Export-ToHtml, Export-ToSIEM
}
