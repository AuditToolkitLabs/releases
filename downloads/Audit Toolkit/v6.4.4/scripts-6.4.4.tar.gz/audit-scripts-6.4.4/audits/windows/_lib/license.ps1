# License Enforcement Module (PowerShell)
# Validates local license token binding, signature, and expiration behavior.

$script:LicenseDirectory = Join-Path $env:USERPROFILE '.audit-tool'
$script:LicenseTokenPath = Join-Path $script:LicenseDirectory 'license.token'
$script:TokenGracePeriodDay = 7
$script:InGracePeriod = $false
$script:GraceDayRemaining = 0

function Get-MachineFingerprint {
    [CmdletBinding()]
    param()

    $identifierList = New-Object System.Collections.Generic.List[string]

    try {
        $bios = Get-CimInstance -ClassName Win32_BIOS -ErrorAction SilentlyContinue
        if ($bios.SerialNumber) {
            $identifierList.Add([string]$bios.SerialNumber)
        }

        $product = Get-CimInstance -ClassName Win32_ComputerSystemProduct -ErrorAction SilentlyContinue
        if ($product.UUID -and $product.UUID -ne 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF') {
            $identifierList.Add([string]$product.UUID)
        }

        $adapter = Get-CimInstance -ClassName Win32_NetworkAdapter -ErrorAction SilentlyContinue |
            Where-Object { $_.PhysicalAdapter -eq $true -and $_.MACAddress } |
            Select-Object -First 1

        if ($adapter.MACAddress) {
            $identifierList.Add([string]$adapter.MACAddress)
        }
    }
    catch {
        Write-Verbose "Hardware fingerprint probe failed: $($_.Exception.Message)"
    }

    if ($identifierList.Count -eq 0) {
        $identifierList.Add([string]$env:COMPUTERNAME)
    }

    $joined = ($identifierList -join '|')
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($joined)
        $hashBytes = $sha256.ComputeHash($bytes)
        return [System.BitConverter]::ToString($hashBytes).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha256.Dispose()
    }
}

function Test-LicenseToken {
    [CmdletBinding()]
    param()

    $result = [pscustomobject]@{
        Status = 2
        Message = ''
        Token = $null
        InGracePeriod = $false
        GraceDaysRemaining = 0
    }

    if (-not (Test-Path -LiteralPath $script:LicenseTokenPath)) {
        $result.Message = '[LICENSE] No license token found. Please sync with server.'
        return $result
    }

    try {
        $token = Get-Content -LiteralPath $script:LicenseTokenPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $result.Token = $token
    }
    catch {
        $result.Message = "[LICENSE] License token file is corrupted: $($_.Exception.Message)"
        return $result
    }

    $fingerprint = Get-MachineFingerprint
    if ($token.machine_id -and $token.machine_id -ne $fingerprint) {
        $result.Message = "[LICENSE] Token was issued for a different machine.`n[LICENSE] This prevents copying scripts between systems."
        return $result
    }

    if ($token.signature) {
        $payload = "$($token.machine_id)|$($token.tier)|$($token.issued)|$($token.expires)"
        $localKeyPart = 'audit-toolkit-v5-local'
        $serverKey = if ($env:AUDIT_TOKEN_SIGNING_KEY) { $env:AUDIT_TOKEN_SIGNING_KEY } else { 'audit-toolkit-default-signing-key-change-me' }
        $keyMaterial = "${localKeyPart}:${serverKey}"

        $hmac = [System.Security.Cryptography.HMACSHA256]::new([System.Text.Encoding]::UTF8.GetBytes($keyMaterial))
        try {
            $expectedSig = [System.BitConverter]::ToString($hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($payload))).Replace('-', '').ToLowerInvariant()
        }
        finally {
            $hmac.Dispose()
        }

        if ($token.signature -ne $expectedSig) {
            $result.Message = '[LICENSE] Token signature is invalid. Token may have been tampered with.'
            return $result
        }
    }

    if (-not $token.expires) {
        $result.Message = '[LICENSE] Token has no expiration date.'
        return $result
    }

    try {
        $expiryUtc = [DateTime]::Parse($token.expires)
        $daysUntilExpiry = ($expiryUtc - [DateTime]::UtcNow).Days
    }
    catch {
        $result.Message = '[LICENSE] Cannot parse token expiration date.'
        return $result
    }

    if ($daysUntilExpiry -ge 0) {
        $result.Status = 0
        $result.Message = 'Token valid'
        if ($daysUntilExpiry -le 7) {
            $result.Message = "[LICENSE] Token expires in $daysUntilExpiry day(s). Please sync with server to renew."
        }
        return $result
    }

    $daysExpired = -$daysUntilExpiry
    if ($daysExpired -le $script:TokenGracePeriodDay) {
        $graceRemaining = $script:TokenGracePeriodDay - $daysExpired
        $script:InGracePeriod = $true
        $script:GraceDayRemaining = $graceRemaining

        $result.Status = 1
        $result.InGracePeriod = $true
        $result.GraceDaysRemaining = $graceRemaining
        $result.Message = @"
========================================================
 LICENSE TOKEN EXPIRED - GRACE PERIOD ACTIVE
========================================================

 Your license token expired $daysExpired day(s) ago.
 Grace period: $graceRemaining day(s) remaining.

 Scripts will STOP WORKING after the grace period.
 Please sync with the server to renew your token.

========================================================
"@
        return $result
    }

    $result.Status = 2
    $result.Message = @"
========================================================
 LICENSE TOKEN EXPIRED
========================================================

 Your license token expired $daysExpired days ago.
 The $($script:TokenGracePeriodDay)-day grace period has ended.

 To continue using these scripts:
   1. Connect to the central server
   2. Run: audit-agent sync

 Or upgrade your license at:
   https://audit-tool.example.com/pricing

========================================================
"@
    return $result
}

function Assert-LicenseValid {
    [CmdletBinding()]
    param()

    $validation = Test-LicenseToken

    if ($validation.Status -eq 2) {
        Write-Output $validation.Message
        exit 1
    }

    if ($validation.Status -eq 1) {
        Write-Output $validation.Message
    }

    return $validation
}

function Write-GracePeriodBanner {
    [CmdletBinding()]
    param()

    if (-not $script:InGracePeriod) {
        return
    }

    Write-Output ''
    Write-Output '============================================================'
    Write-Output ("[LICENSE] WARNING: token expired - {0} day(s) grace remaining" -f $script:GraceDayRemaining)
    Write-Output '============================================================'
    Write-Output ''
}

function Initialize-LicenseDirectory {
    [CmdletBinding()]
    param()

    if (Test-Path -LiteralPath $script:LicenseDirectory) {
        return
    }

    New-Item -ItemType Directory -Path $script:LicenseDirectory -Force | Out-Null

    try {
        $acl = Get-Acl -Path $script:LicenseDirectory
        $acl.SetAccessRuleProtection($true, $false)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $env:USERNAME,
            'FullControl',
            'ContainerInherit,ObjectInherit',
            'None',
            'Allow'
        )
        $acl.ResetAccessRule($rule)
        Set-Acl -Path $script:LicenseDirectory -AclObject $acl
    }
    catch {
        Write-Verbose "Could not apply restrictive ACL to license directory: $($_.Exception.Message)"
    }
}

function Get-LicenseTokenInfo {
    [CmdletBinding()]
    param()

    $validation = Test-LicenseToken
    if (-not $validation.Token) {
        Write-Output $validation.Message
        return
    }

    $statusText = switch ($validation.Status) {
        0 { 'VALID' }
        1 { "GRACE PERIOD ($($validation.GraceDaysRemaining) day(s) remaining)" }
        default { 'EXPIRED' }
    }

    $machinePrefix = [string]$validation.Token.machine_id
    if ($machinePrefix.Length -gt 16) {
        $machinePrefix = $machinePrefix.Substring(0, 16) + '...'
    }

    Write-Output ''
    Write-Output 'License Token Information'
    Write-Output '========================='
    Write-Output "  Tier:     $($validation.Token.tier)"
    Write-Output "  Issued:   $($validation.Token.issued)"
    Write-Output "  Expires:  $($validation.Token.expires)"
    Write-Output "  Machine:  $machinePrefix"
    Write-Output "  Status:   $statusText"
    Write-Output ''
}

if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function Get-MachineFingerprint, Test-LicenseToken, Assert-LicenseValid, Write-GracePeriodBanner, Initialize-LicenseDirectory, Get-LicenseTokenInfo
}
