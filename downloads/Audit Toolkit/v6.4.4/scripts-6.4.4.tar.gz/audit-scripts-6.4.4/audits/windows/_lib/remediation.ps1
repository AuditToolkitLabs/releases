# Remediation Module (PowerShell)
# Generates remediation scripts and guidance for failed audit checks
# This module creates actionable remediation steps WITHOUT modifying the system

# ============================================================================
# REMEDIATION TEMPLATES
# ============================================================================

$script:RemediationTemplates = @{
    # Password Policy
    "Minimum Password Length" = @{
        Category = "Account Policy"
        Priority = "High"
        Guidance = "Configure minimum password length to at least 14 characters"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Account Policies > Password Policy"
        PowerShell = 'net accounts /minpwlen:14'
        Registry = $null
        Reference = "CIS 1.1.4"
    }

    "Password History" = @{
        Category = "Account Policy"
        Priority = "Medium"
        Guidance = "Configure password history to remember at least 24 passwords"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Account Policies > Password Policy"
        PowerShell = 'net accounts /uniquepw:24'
        Registry = $null
        Reference = "CIS 1.1.1"
    }

    # Account Lockout
    "Account Lockout Threshold" = @{
        Category = "Account Policy"
        Priority = "High"
        Guidance = "Configure account lockout threshold to 5 or fewer invalid attempts"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Account Policies > Account Lockout Policy"
        PowerShell = 'net accounts /lockoutthreshold:5'
        Registry = $null
        Reference = "CIS 1.2.1"
    }

    # Firewall
    "Windows Firewall" = @{
        Category = "Network Security"
        Priority = "Critical"
        Guidance = "Enable Windows Firewall for all profiles (Domain, Private, Public)"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Windows Defender Firewall"
        PowerShell = @'
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
'@
        Registry = $null
        Reference = "CIS 9.1.1, 9.2.1, 9.3.1"
    }

    # BitLocker
    "BitLocker" = @{
        Category = "Data Protection"
        Priority = "High"
        Guidance = "Enable BitLocker drive encryption on the system drive"
        GPO = "Computer Configuration > Administrative Templates > Windows Components > BitLocker Drive Encryption"
        PowerShell = @'
# Check TPM and enable BitLocker
$tpm = Get-Tpm
if ($tpm.TpmReady) {
    Enable-BitLocker -MountPoint "C:" -EncryptionMethod XtsAes256 -TpmProtector
    Add-BitLockerKeyProtector -MountPoint "C:" -RecoveryPasswordProtector
}
'@
        Registry = $null
        Reference = "CIS 18.9.11.1"
    }

    # Windows Defender
    "Windows Defender" = @{
        Category = "Endpoint Protection"
        Priority = "Critical"
        Guidance = "Enable Windows Defender real-time protection"
        GPO = "Computer Configuration > Administrative Templates > Windows Components > Microsoft Defender Antivirus"
        PowerShell = @'
Set-MpPreference -DisableRealtimeMonitoring $false
Set-MpPreference -DisableBehaviorMonitoring $false
Set-MpPreference -DisableIOAVProtection $false
'@
        Registry = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection\DisableRealtimeMonitoring = 0"
        Reference = "CIS 18.9.47.4.1"
    }

    # RDP/NLA
    "Network Level Authentication" = @{
        Category = "Remote Access"
        Priority = "High"
        Guidance = "Enable Network Level Authentication for Remote Desktop"
        GPO = "Computer Configuration > Administrative Templates > Windows Components > Remote Desktop Services > Remote Desktop Session Host > Security"
        PowerShell = @'
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "UserAuthentication" -Value 1
'@
        Registry = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp\UserAuthentication = 1"
        Reference = "CIS 18.9.65.3.9.1"
    }

    # Credential Guard
    "Credential Guard" = @{
        Category = "Credential Protection"
        Priority = "High"
        Guidance = "Enable Credential Guard with UEFI lock"
        GPO = "Computer Configuration > Administrative Templates > System > Device Guard"
        PowerShell = @'
# Enable Credential Guard via registry (requires reboot)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "EnableVirtualizationBasedSecurity" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "RequirePlatformSecurityFeatures" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LsaCfgFlags" -Value 1
'@
        Registry = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\EnableVirtualizationBasedSecurity = 1"
        Reference = "CIS 18.9.5.1"
    }

    # NTLM
    "NTLM Restrictions" = @{
        Category = "Authentication"
        Priority = "High"
        Guidance = "Restrict NTLM authentication and configure LAN Manager authentication level"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Local Policies > Security Options"
        PowerShell = @'
# Set LAN Manager authentication level to NTLMv2 only
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LmCompatibilityLevel" -Value 5
# Disable LM hash storage
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLMHash" -Value 1
'@
        Registry = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\LmCompatibilityLevel = 5"
        Reference = "CIS 2.3.11.7"
    }

    # Audit Policy
    "Advanced Audit Policy" = @{
        Category = "Logging"
        Priority = "High"
        Guidance = "Configure comprehensive audit policies for security events"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration"
        PowerShell = @'
# Enable key audit categories
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Logoff" /success:enable
auditpol /set /subcategory:"Account Lockout" /success:enable /failure:enable
auditpol /set /subcategory:"Special Logon" /success:enable
auditpol /set /subcategory:"Security Group Management" /success:enable
auditpol /set /subcategory:"User Account Management" /success:enable /failure:enable
auditpol /set /subcategory:"Process Creation" /success:enable
auditpol /set /subcategory:"Audit Policy Change" /success:enable /failure:enable
'@
        Registry = $null
        Reference = "CIS 17.1-17.9"
    }

    # UAC
    "User Account Control" = @{
        Category = "Privilege Management"
        Priority = "High"
        Guidance = "Configure UAC to prompt for credentials on secure desktop"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Local Policies > Security Options"
        PowerShell = @'
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -Value 2
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "PromptOnSecureDesktop" -Value 1
'@
        Registry = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA = 1"
        Reference = "CIS 2.3.17"
    }

    # SMB Signing
    "SMB Signing" = @{
        Category = "Network Security"
        Priority = "High"
        Guidance = "Enable and require SMB signing on all connections"
        GPO = "Computer Configuration > Windows Settings > Security Settings > Local Policies > Security Options"
        PowerShell = @'
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RequireSecuritySignature" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "EnableSecuritySignature" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -Value 1
'@
        Registry = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters\RequireSecuritySignature = 1"
        Reference = "CIS 2.3.9.2"
    }

    # Windows Update
    "Windows Update" = @{
        Category = "Patch Management"
        Priority = "Critical"
        Guidance = "Configure automatic Windows Update with WSUS or Windows Update for Business"
        GPO = "Computer Configuration > Administrative Templates > Windows Components > Windows Update"
        PowerShell = @'
# Force Windows Update check
$UpdateSession = New-Object -ComObject Microsoft.Update.Session
$UpdateSearcher = $UpdateSession.CreateUpdateSearcher()
$Updates = $UpdateSearcher.Search("IsInstalled=0")
Write-Output "$($Updates.Updates.Count) updates pending"
'@
        Registry = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\NoAutoUpdate = 0"
        Reference = "CIS 18.9.108"
    }

    # PowerShell Logging
    "PowerShell Logging" = @{
        Category = "Logging"
        Priority = "Medium"
        Guidance = "Enable PowerShell script block logging and module logging"
        GPO = "Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell"
        PowerShell = @'
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name "EnableScriptBlockLogging" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging" -Name "EnableModuleLogging" -Value 1
'@
        Registry = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging\EnableScriptBlockLogging = 1"
        Reference = "CIS 18.9.100.1"
    }
}

# ============================================================================
# FUNCTIONS
# ============================================================================

function Get-Remediation {
    <#
    .SYNOPSIS
        Gets remediation guidance for a specific check
    .PARAMETER CheckName
        The name of the failed audit check
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$CheckName
    )

    foreach ($template in $script:RemediationTemplates.Keys) {
        if ($CheckName -match $template -or $template -match $CheckName) {
            return $script:RemediationTemplates[$template]
        }
    }

    # Return generic guidance if no specific template found
    return @{
        Category = "General"
        Priority = "Medium"
        Guidance = "Review the failed check and consult CIS Benchmark documentation for remediation steps"
        GPO = "Consult Group Policy documentation"
        PowerShell = "# No specific remediation script available"
        Registry = $null
        Reference = "See CIS Benchmark"
    }
}

function Get-RemediationScript {
    <#
    .SYNOPSIS
        Generates a remediation script for multiple failed checks
    .PARAMETER FailedChecks
        Array of failed check results with Name and Status properties
    .PARAMETER OutputPath
        Optional: Path to save the remediation script
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$FailedChecks,

        [Parameter(Mandatory=$false)]
        [string]$OutputPath
    )

    $script = @()
    $script += "#Requires -RunAsAdministrator"
    $script += "# Auto-generated Remediation Script"
    $script += "# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $script += "# Computer: $env:COMPUTERNAME"
    $script += "# WARNING: Review all changes before executing!"
    $script += ""
    $script += "param("
    $script += '    [switch]$WhatIf'
    $script += ")"
    $script += ""
    $script += 'if ($WhatIf) { Write-Host "Running in WhatIf mode - no changes will be made" -ForegroundColor Yellow }'
    $script += ""

    $groupedByCategory = @{}

    foreach ($check in $FailedChecks) {
        $remediation = Get-Remediation -CheckName $check.Name

        if (-not $groupedByCategory[$remediation.Category]) {
            $groupedByCategory[$remediation.Category] = @()
        }

        $groupedByCategory[$remediation.Category] += @{
            Check = $check
            Remediation = $remediation
        }
    }

    foreach ($category in $groupedByCategory.Keys | Sort-Object) {
        $script += "#" + "=" * 70
        $script += "# $category"
        $script += "#" + "=" * 70
        $script += ""

        foreach ($item in $groupedByCategory[$category]) {
            $script += "# Check: $($item.Check.Name)"
            $script += "# Status: $($item.Check.Status)"
            $script += "# Reference: $($item.Remediation.Reference)"
            $script += "# Priority: $($item.Remediation.Priority)"
            $script += ""

            if ($item.Remediation.PowerShell -and $item.Remediation.PowerShell -ne "# No specific remediation script available") {
                $script += 'if (-not $WhatIf) {'
                $script += $item.Remediation.PowerShell -split "`n" | ForEach-Object { "    $_" }
                $script += "} else {"
                $script += "    Write-Host `"Would remediate: $($item.Check.Name)`" -ForegroundColor Cyan"
                $script += "}"
            } else {
                $script += "# Manual remediation required: $($item.Remediation.Guidance)"
            }

            $script += ""
        }
    }

    $script += "Write-Host `"Remediation complete. Reboot may be required.`" -ForegroundColor Green"

    $scriptContent = $script -join "`n"

    if ($OutputPath) {
        $scriptContent | Out-File -FilePath $OutputPath -Encoding UTF8
        Write-Output "Remediation script saved to: $OutputPath"
    }

    return $scriptContent
}

function Get-RemediationReport {
    <#
    .SYNOPSIS
        Generates a human-readable remediation report
    .PARAMETER FailedChecks
        Array of failed check results
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$FailedChecks
    )

    $report = @()
    $report += ""
    $report += "=" * 70
    $report += "REMEDIATION REPORT"
    $report += "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $report += "Computer: $env:COMPUTERNAME"
    $report += "Total Issues: $($FailedChecks.Count)"
    $report += "=" * 70

    # Group by priority
    $critical = @()
    $high = @()
    $medium = @()
    $low = @()

    foreach ($check in $FailedChecks) {
        $remediation = Get-Remediation -CheckName $check.Name
        $item = @{Check = $check; Remediation = $remediation}

        switch ($remediation.Priority) {
            "Critical" { $critical += $item }
            "High" { $high += $item }
            "Medium" { $medium += $item }
            default { $low += $item }
        }
    }

    $report += ""
    $report += "ISSUES BY PRIORITY:"
    $report += "  Critical: $($critical.Count)"
    $report += "  High:     $($high.Count)"
    $report += "  Medium:   $($medium.Count)"
    $report += "  Low:      $($low.Count)"
    $report += ""

    if ($critical.Count -gt 0) {
        $report += "-" * 70
        $report += "[CRITICAL PRIORITY]"
        $report += "-" * 70
        foreach ($item in $critical) {
            $report += ""
            $report += "CHECK: $($item.Check.Name)"
            $report += "STATUS: $($item.Check.Status)"
            $report += "GUIDANCE: $($item.Remediation.Guidance)"
            $report += "GPO PATH: $($item.Remediation.GPO)"
            $report += "REFERENCE: $($item.Remediation.Reference)"
        }
    }

    if ($high.Count -gt 0) {
        $report += ""
        $report += "-" * 70
        $report += "[HIGH PRIORITY]"
        $report += "-" * 70
        foreach ($item in $high) {
            $report += ""
            $report += "CHECK: $($item.Check.Name)"
            $report += "STATUS: $($item.Check.Status)"
            $report += "GUIDANCE: $($item.Remediation.Guidance)"
            $report += "REFERENCE: $($item.Remediation.Reference)"
        }
    }

    if ($medium.Count -gt 0) {
        $report += ""
        $report += "-" * 70
        $report += "[MEDIUM PRIORITY]"
        $report += "-" * 70
        foreach ($item in $medium) {
            $report += ""
            $report += "CHECK: $($item.Check.Name)"
            $report += "GUIDANCE: $($item.Remediation.Guidance)"
        }
    }

    $report += ""
    $report += "=" * 70
    $report += "Use Get-RemediationScript to generate an executable remediation script"
    $report += "=" * 70

    return $report -join "`n"
}

# Export functions when loaded as a module
# When dot-sourced, Export-ModuleMember is not valid - skip it
if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function Get-Remediation, Get-RemediationScript, Get-RemediationReport
}
