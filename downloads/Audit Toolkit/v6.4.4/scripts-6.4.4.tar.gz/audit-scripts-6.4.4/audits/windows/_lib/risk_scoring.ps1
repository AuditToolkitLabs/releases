# Risk Scoring Module for Windows Audit Toolkit
# Provides CVSS-like 0-10 risk scoring for audit findings
#
# This module calculates risk scores based on:
# - Severity (Critical, High, Medium, Low, Info)
# - Exploitability (Network, Local, Physical)
# - Impact (Confidentiality, Integrity, Availability)
# - Remediation complexity
#
# Usage:
#   Import-Module "$PSScriptRoot/risk_scoring.ps1"
#   $score = Get-RiskScore -Severity "High" -Exploitability "Network"

# ============================================================================
# RISK SCORING CONSTANTS
# ============================================================================

$script:SeverityScores = @{
    "Critical" = 10.0
    "High"     = 8.0
    "Medium"   = 5.0
    "Low"      = 3.0
    "Info"     = 0.0
}

$script:ExploitabilityScores = @{
    "Network"  = 1.0    # Remotely exploitable
    "Adjacent" = 0.8    # Adjacent network required
    "Local"    = 0.6    # Local access required
    "Physical" = 0.4    # Physical access required
}

$script:ImpactScores = @{
    "High"   = 1.0
    "Medium" = 0.7
    "Low"    = 0.4
    "None"   = 0.0
}

$script:ComplexityScores = @{
    "Low"    = 1.0      # Easy to exploit
    "Medium" = 0.7
    "High"   = 0.4      # Difficult to exploit
}

# ============================================================================
# CORE FUNCTIONS
# ============================================================================

function Get-RiskScore {
    <#
    .SYNOPSIS
        Calculates a CVSS-like risk score for an audit finding.

    .PARAMETER Severity
        The severity level: Critical, High, Medium, Low, Info

    .PARAMETER Exploitability
        How the vulnerability can be exploited: Network, Adjacent, Local, Physical

    .PARAMETER ConfidentialityImpact
        Impact on confidentiality: High, Medium, Low, None

    .PARAMETER IntegrityImpact
        Impact on integrity: High, Medium, Low, None

    .PARAMETER AvailabilityImpact
        Impact on availability: High, Medium, Low, None

    .PARAMETER Complexity
        Attack complexity: Low, Medium, High

    .EXAMPLE
        Get-RiskScore -Severity "High" -Exploitability "Network"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet("Critical", "High", "Medium", "Low", "Info")]
        [string]$Severity,

        [ValidateSet("Network", "Adjacent", "Local", "Physical")]
        [string]$Exploitability = "Local",

        [ValidateSet("High", "Medium", "Low", "None")]
        [string]$ConfidentialityImpact = "Medium",

        [ValidateSet("High", "Medium", "Low", "None")]
        [string]$IntegrityImpact = "Medium",

        [ValidateSet("High", "Medium", "Low", "None")]
        [string]$AvailabilityImpact = "Low",

        [ValidateSet("Low", "Medium", "High")]
        [string]$Complexity = "Medium"
    )

    # Base score from severity
    $baseScore = $script:SeverityScores[$Severity]

    # Impact sub-score (average of CIA triad)
    $impactScore = (
        $script:ImpactScores[$ConfidentialityImpact] +
        $script:ImpactScores[$IntegrityImpact] +
        $script:ImpactScores[$AvailabilityImpact]
    ) / 3

    # Exploitability multiplier
    $exploitMultiplier = $script:ExploitabilityScores[$Exploitability]

    # Complexity multiplier
    $complexityMultiplier = $script:ComplexityScores[$Complexity]

    # Calculate final score: Base * (0.6 * Impact + 0.4 * Exploitability * Complexity)
    $finalScore = $baseScore * (0.6 * $impactScore + 0.4 * $exploitMultiplier * $complexityMultiplier)

    # Normalize to 0-10 scale
    $normalizedScore = [Math]::Round([Math]::Min(10.0, $finalScore), 1)

    return [PSCustomObject]@{
        Score = $normalizedScore
        Rating = Get-RiskRating -Score $normalizedScore
        BaseScore = $baseScore
        ImpactScore = [Math]::Round($impactScore, 2)
        ExploitabilityMultiplier = $exploitMultiplier
        ComplexityMultiplier = $complexityMultiplier
    }
}

function Get-RiskRating {
    <#
    .SYNOPSIS
        Converts a numeric score to a risk rating.
    #>
    param(
        [double]$Score
    )

    switch ($Score) {
        { $_ -ge 9.0 } { return "Critical" }
        { $_ -ge 7.0 } { return "High" }
        { $_ -ge 4.0 } { return "Medium" }
        { $_ -ge 0.1 } { return "Low" }
        default { return "Info" }
    }
}

function Get-AuditRiskProfile {
    <#
    .SYNOPSIS
        Generates a risk profile for an entire audit run.

    .PARAMETER Findings
        Array of finding objects with Status property (PASS, WARN, FAIL, SKIP, INFO)

    .EXAMPLE
        $findings = @(
            @{Name="Check1"; Status="FAIL"; Message="..."},
            @{Name="Check2"; Status="PASS"; Message="..."}
        )
        Get-AuditRiskProfile -Findings $findings
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Findings
    )

    $total = $Findings.Count
    $passed = ($Findings | Where-Object { $_.Status -eq "PASS" }).Count
    $failed = ($Findings | Where-Object { $_.Status -eq "FAIL" }).Count
    $warnings = ($Findings | Where-Object { $_.Status -eq "WARN" }).Count
    $skipped = ($Findings | Where-Object { $_.Status -eq "SKIP" }).Count
    $info = ($Findings | Where-Object { $_.Status -eq "INFO" }).Count

    # Calculate compliance percentage (exclude skipped and info)
    $applicable = $total - $skipped - $info
    $compliant = if ($applicable -gt 0) { [Math]::Round(($passed / $applicable) * 100, 1) } else { 100 }

    # Calculate risk score (weighted by severity)
    $riskScore = 0
    if ($failed -gt 0) {
        $riskScore += $failed * 3
    }
    if ($warnings -gt 0) {
        $riskScore += $warnings * 1
    }

    # Normalize to 0-10
    $maxPossibleRisk = $applicable * 3
    $normalizedRisk = if ($maxPossibleRisk -gt 0) {
        [Math]::Round(($riskScore / $maxPossibleRisk) * 10, 1)
    } else { 0 }

    return [PSCustomObject]@{
        TotalChecks = $total
        Passed = $passed
        Failed = $failed
        Warnings = $warnings
        Skipped = $skipped
        Info = $info
        CompliancePercentage = $compliant
        RiskScore = $normalizedRisk
        RiskRating = Get-RiskRating -Score $normalizedRisk
        Timestamp = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
    }
}

function Get-CheckSeverity {
    <#
    .SYNOPSIS
        Maps common check names to default severity levels.

    .PARAMETER CheckName
        The name of the security check.
    #>
    param(
        [string]$CheckName
    )

    # Critical severity patterns
    $critical = @(
        "Credential Guard", "BitLocker", "Admin Password",
        "Remote Code", "Privilege Escalation", "Authentication",
        "Encryption", "LAPS", "Secure Boot"
    )

    # High severity patterns
    $high = @(
        "Firewall", "Antivirus", "AppLocker", "PowerShell Logging",
        "SMB Signing", "NTLM", "Kerberos", "UAC", "Defender",
        "EDR", "VBS", "Device Guard", "HVCI"
    )

    # Medium severity patterns
    $medium = @(
        "Audit", "Policy", "Service", "Registry", "Update",
        "Network", "RDP", "Remote", "Password", "Account"
    )

    foreach ($pattern in $critical) {
        if ($CheckName -match $pattern) { return "Critical" }
    }

    foreach ($pattern in $high) {
        if ($CheckName -match $pattern) { return "High" }
    }

    foreach ($pattern in $medium) {
        if ($CheckName -match $pattern) { return "Medium" }
    }

    return "Low"
}

function Format-RiskReport {
    <#
    .SYNOPSIS
        Formats a risk profile as a text report.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$RiskProfile,

        [string]$Title = "Security Audit Risk Report"
    )

    $report = @"
================================================================================
$Title
Generated: $($RiskProfile.Timestamp)
================================================================================

SUMMARY
-------
Total Checks:    $($RiskProfile.TotalChecks)
Passed:          $($RiskProfile.Passed)
Failed:          $($RiskProfile.Failed)
Warnings:        $($RiskProfile.Warnings)
Skipped:         $($RiskProfile.Skipped)
Informational:   $($RiskProfile.Info)

RISK ASSESSMENT
---------------
Compliance:      $($RiskProfile.CompliancePercentage)%
Risk Score:      $($RiskProfile.RiskScore) / 10.0
Risk Rating:     $($RiskProfile.RiskRating)

================================================================================
"@

    return $report
}

# ============================================================================
# EXPORT MODULE MEMBERS
# ============================================================================

# Export functions when loaded as a module
# When dot-sourced, Export-ModuleMember is not valid - skip it
if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function @(
        'Get-RiskScore',
        'Get-RiskRating',
        'Get-AuditRiskProfile',
        'Get-CheckSeverity',
        'Format-RiskReport'
    )
}
