# SIEM Integration Module (PowerShell)
# Sends audit results to various SIEM platforms
# Supports Splunk HEC, Azure Sentinel, Elastic, and generic Syslog

# ============================================================================
# CONFIGURATION
# ============================================================================

$script:SIEMConfig = @{
    Splunk = @{
        Enabled = $false
        HECUrl = ""
        HECToken = ""
        Index = "security"
        SourceType = "security_audit"
    }
    AzureSentinel = @{
        Enabled = $false
        WorkspaceId = ""
        SharedKey = ""
        LogType = "SecurityAudit"
    }
    Elastic = @{
        Enabled = $false
        Url = ""
        ApiKey = ""
        Index = "security-audit"
    }
    Syslog = @{
        Enabled = $false
        Server = ""
        Port = 514
        Protocol = "UDP"
        Facility = 13  # Log Audit
    }
}

# ============================================================================
# SPLUNK HTTP EVENT COLLECTOR (HEC)
# ============================================================================

function Send-ToSplunk {
    <#
    .SYNOPSIS
        Sends audit events to Splunk via HTTP Event Collector
    .PARAMETER Events
        Array of event objects to send
    .PARAMETER HECUrl
        Splunk HEC endpoint URL
    .PARAMETER HECToken
        Splunk HEC authentication token
    .PARAMETER Index
        Target Splunk index
    .PARAMETER SourceType
        Splunk sourcetype
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Events,

        [Parameter(Mandatory=$true)]
        [string]$HECUrl,

        [Parameter(Mandatory=$true)]
        [string]$HECToken,

        [Parameter(Mandatory=$false)]
        [string]$Index = "security",

        [Parameter(Mandatory=$false)]
        [string]$SourceType = "security_audit"
    )

    $headers = @{
        "Authorization" = "Splunk $HECToken"
        "Content-Type" = "application/json"
    }

    $successCount = 0
    $failCount = 0

    foreach ($auditEvent in $Events) {
        $splunkEvent = @{
            time = [int][double]::Parse((Get-Date -UFormat %s))
            host = $env:COMPUTERNAME
            source = "SecurityAuditToolkit"
            sourcetype = $SourceType
            index = $Index
            event = $auditEvent
        }

        try {
            $body = $splunkEvent | ConvertTo-Json -Depth 10 -Compress
            Invoke-RestMethod -Uri $HECUrl -Method POST -Headers $headers -Body $body -SkipCertificateCheck -ErrorAction Stop | Out-Null
            $successCount++
        } catch {
            $failCount++
            Write-Warning "Failed to send event to Splunk: $_"
        }
    }

    return @{
        Success = $successCount
        Failed = $failCount
        Total = $Events.Count
    }
}

# ============================================================================
# AZURE SENTINEL / LOG ANALYTICS
# ============================================================================

function Send-ToAzureSentinel {
    <#
    .SYNOPSIS
        Sends audit events to Azure Sentinel via Log Analytics Data Collector API
    .PARAMETER Events
        Array of event objects to send
    .PARAMETER WorkspaceId
        Log Analytics Workspace ID
    .PARAMETER SharedKey
        Log Analytics Primary/Secondary Key
    .PARAMETER LogType
        Custom log type name
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Events,

        [Parameter(Mandatory=$true)]
        [string]$WorkspaceId,

        [Parameter(Mandatory=$true)]
        [string]$SharedKey,

        [Parameter(Mandatory=$false)]
        [string]$LogType = "SecurityAudit"
    )

    function Build-Signature {
        param($WorkspaceId, $SharedKey, $Date, $ContentLength, $Method, $ContentType, $Resource)

        $xHeaders = "x-ms-date:$Date"
        $stringToHash = "$Method`n$ContentLength`n$ContentType`n$xHeaders`n$Resource"

        $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
        $keyBytes = [Convert]::FromBase64String($SharedKey)

        $hmacsha256 = New-Object System.Security.Cryptography.HMACSHA256
        $hmacsha256.Key = $keyBytes
        $hash = $hmacsha256.ComputeHash($bytesToHash)
        $signature = [Convert]::ToBase64String($hash)

        return "SharedKey ${WorkspaceId}:$signature"
    }

    $body = $Events | ConvertTo-Json -Depth 10
    $contentLength = [Text.Encoding]::UTF8.GetBytes($body).Length
    $date = [DateTime]::UtcNow.ToString("r")

    $signature = Build-Signature -WorkspaceId $WorkspaceId -SharedKey $SharedKey -Date $date -ContentLength $contentLength -Method "POST" -ContentType "application/json" -Resource "/api/logs"

    $uri = "https://$WorkspaceId.ods.opinsights.azure.com/api/logs?api-version=2016-04-01"

    $headers = @{
        "Authorization" = $signature
        "Log-Type" = $LogType
        "x-ms-date" = $date
        "Content-Type" = "application/json"
        "time-generated-field" = "timestamp"
    }

    try {
        Invoke-RestMethod -Uri $uri -Method POST -Headers $headers -Body $body -UseBasicParsing -ErrorAction Stop | Out-Null
        return @{ Success = $Events.Count; Failed = 0; Total = $Events.Count }
    } catch {
        Write-Warning "Failed to send events to Azure Sentinel: $_"
        return @{ Success = 0; Failed = $Events.Count; Total = $Events.Count }
    }
}

# ============================================================================
# ELASTICSEARCH
# ============================================================================

function Send-ToElastic {
    <#
    .SYNOPSIS
        Sends audit events to Elasticsearch
    .PARAMETER Events
        Array of event objects to send
    .PARAMETER Url
        Elasticsearch URL (e.g., https://localhost:9200)
    .PARAMETER ApiKey
        Elasticsearch API Key (Base64 encoded)
    .PARAMETER Index
        Target index name
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Events,

        [Parameter(Mandatory=$true)]
        [string]$Url,

        [Parameter(Mandatory=$false)]
        [string]$ApiKey,

        [Parameter(Mandatory=$false)]
        [string]$Index = "security-audit"
    )

    $headers = @{
        "Content-Type" = "application/json"
    }

    if ($ApiKey) {
        $headers["Authorization"] = "ApiKey $ApiKey"
    }

    $successCount = 0
    $failCount = 0

    # Build bulk request
    $bulkBody = ""
    $indexDate = Get-Date -Format "yyyy.MM.dd"
    $targetIndex = "$Index-$indexDate"

    foreach ($auditEvent in $Events) {
        $auditEvent['@timestamp'] = (Get-Date).ToString("o")
        $auditEvent['host'] = @{ name = $env:COMPUTERNAME }

        $actionLine = @{ index = @{ _index = $targetIndex } } | ConvertTo-Json -Compress
        $eventLine = $auditEvent | ConvertTo-Json -Compress -Depth 10

        $bulkBody += "$actionLine`n$eventLine`n"
    }

    try {
        $uri = "$Url/_bulk"
        $response = Invoke-RestMethod -Uri $uri -Method POST -Headers $headers -Body $bulkBody -SkipCertificateCheck -ErrorAction Stop

        $successCount = ($response.items | Where-Object { $_.index.status -lt 300 }).Count
        $failCount = $Events.Count - $successCount
    } catch {
        Write-Warning "Failed to send events to Elasticsearch: $_"
        $failCount = $Events.Count
    }

    return @{
        Success = $successCount
        Failed = $failCount
        Total = $Events.Count
    }
}

# ============================================================================
# SYSLOG
# ============================================================================

function Send-ToSyslog {
    <#
    .SYNOPSIS
        Sends audit events to a Syslog server
    .PARAMETER Events
        Array of event objects to send
    .PARAMETER Server
        Syslog server hostname or IP
    .PARAMETER Port
        Syslog port (default: 514)
    .PARAMETER Protocol
        UDP or TCP
    .PARAMETER Facility
        Syslog facility (default: 13 - Log Audit)
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Events,

        [Parameter(Mandatory=$true)]
        [string]$Server,

        [Parameter(Mandatory=$false)]
        [int]$Port = 514,

        [Parameter(Mandatory=$false)]
        [ValidateSet("UDP", "TCP")]
        [string]$Protocol = "UDP",

        [Parameter(Mandatory=$false)]
        [int]$Facility = 13
    )

    $successCount = 0
    $failCount = 0

    try {
        if ($Protocol -eq "UDP") {
            $udpClient = New-Object System.Net.Sockets.UdpClient
            $udpClient.Connect($Server, $Port)
        } else {
            $tcpClient = New-Object System.Net.Sockets.TcpClient($Server, $Port)
            $stream = $tcpClient.GetStream()
            $writer = New-Object System.IO.StreamWriter($stream)
        }

        foreach ($auditEvent in $Events) {
            # Determine severity based on status
            $severity = switch ($auditEvent.Status) {
                "FAIL" { 3 }  # Error
                "WARN" { 4 }  # Warning
                "PASS" { 6 }  # Informational
                "INFO" { 6 }  # Informational
                default { 5 } # Notice
            }

            $priority = ($Facility * 8) + $severity
            $timestamp = Get-Date -Format "MMM dd HH:mm:ss"
            $hostname = $env:COMPUTERNAME
            $message = "SecurityAudit: [$($auditEvent.Status)] $($auditEvent.Name) - $($auditEvent.Message)"

            $syslogMessage = "<$priority>$timestamp $hostname $message"

            try {
                if ($Protocol -eq "UDP") {
                    $bytes = [Text.Encoding]::ASCII.GetBytes($syslogMessage)
                    $udpClient.Send($bytes, $bytes.Length) | Out-Null
                } else {
                    $writer.WriteLine($syslogMessage)
                    $writer.Flush()
                }
                $successCount++
            } catch {
                $failCount++
            }
        }
    } catch {
        Write-Warning "Failed to connect to Syslog server: $_"
        $failCount = $Events.Count
    } finally {
        if ($udpClient) { $udpClient.Close() }
        if ($writer) { $writer.Close() }
        if ($tcpClient) { $tcpClient.Close() }
    }

    return @{
        Success = $successCount
        Failed = $failCount
        Total = $Events.Count
    }
}

# ============================================================================
# UNIFIED SEND FUNCTION
# ============================================================================

function Send-AuditToSIEM {
    <#
    .SYNOPSIS
        Sends audit results to configured SIEM platforms
    .PARAMETER Results
        Array of audit check results
    .PARAMETER Target
        SIEM target: Splunk, AzureSentinel, Elastic, Syslog, or All
    .PARAMETER Config
        Configuration hashtable (optional, uses script config if not provided)
    #>
    param(
        [Parameter(Mandatory=$true)]
        [array]$Results,

        [Parameter(Mandatory=$true)]
        [ValidateSet("Splunk", "AzureSentinel", "Elastic", "Syslog", "All")]
        [string]$Target,

        [Parameter(Mandatory=$false)]
        [hashtable]$Config
    )

    if (-not $Config) {
        $Config = $script:SIEMConfig
    }

    # Convert results to SIEM events
    $events = @()
    foreach ($result in $Results) {
        $events += @{
            timestamp = (Get-Date).ToString("o")
            computer = $env:COMPUTERNAME
            domain = $env:USERDOMAIN
            checkName = $result.Name
            status = $result.Status
            message = $result.Message
            section = $result.Section
            eventType = "SecurityAudit"
            severity = switch ($result.Status) {
                "FAIL" { "High" }
                "WARN" { "Medium" }
                "PASS" { "Low" }
                default { "Informational" }
            }
        }
    }

    $results = @{}

    if ($Target -eq "All" -or $Target -eq "Splunk") {
        if ($Config.Splunk.Enabled -and $Config.Splunk.HECUrl) {
            $results.Splunk = Send-ToSplunk -Events $events -HECUrl $Config.Splunk.HECUrl -HECToken $Config.Splunk.HECToken -Index $Config.Splunk.Index -SourceType $Config.Splunk.SourceType
        }
    }

    if ($Target -eq "All" -or $Target -eq "AzureSentinel") {
        if ($Config.AzureSentinel.Enabled -and $Config.AzureSentinel.WorkspaceId) {
            $results.AzureSentinel = Send-ToAzureSentinel -Events $events -WorkspaceId $Config.AzureSentinel.WorkspaceId -SharedKey $Config.AzureSentinel.SharedKey -LogType $Config.AzureSentinel.LogType
        }
    }

    if ($Target -eq "All" -or $Target -eq "Elastic") {
        if ($Config.Elastic.Enabled -and $Config.Elastic.Url) {
            $results.Elastic = Send-ToElastic -Events $events -Url $Config.Elastic.Url -ApiKey $Config.Elastic.ApiKey -Index $Config.Elastic.Index
        }
    }

    if ($Target -eq "All" -or $Target -eq "Syslog") {
        if ($Config.Syslog.Enabled -and $Config.Syslog.Server) {
            $results.Syslog = Send-ToSyslog -Events $events -Server $Config.Syslog.Server -Port $Config.Syslog.Port -Protocol $Config.Syslog.Protocol -Facility $Config.Syslog.Facility
        }
    }

    return $results
}

# Export functions when loaded as a module
# When dot-sourced, Export-ModuleMember is not valid - skip it
if ($MyInvocation.MyCommand.ScriptBlock.Module) {
    Export-ModuleMember -Function Send-ToSplunk, Send-ToAzureSentinel, Send-ToElastic, Send-ToSyslog, Send-AuditToSIEM
}
