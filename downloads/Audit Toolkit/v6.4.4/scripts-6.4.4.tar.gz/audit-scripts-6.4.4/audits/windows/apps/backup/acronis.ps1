<#
.SYNOPSIS
    Acronis Cyber Protect Agent Security Audit

.DESCRIPTION
    Audits Acronis Cyber Protect/Backup Agent configuration including:
    - Service status and health
    - Agent registration status
    - Backup plan configuration
    - Encryption settings
    - Last backup timestamps
    - Management console connectivity

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 11.2 (Perform Automated Backups)
- NIST SP 800-53: CP-9 (Information System Backup)
- ISO 27001: A.12.3.1 (Information Backup)
- PCI DSS: 9.5, 12.10.1 (Backup procedures)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Acronis Cyber Protect Agent Security Audit"

# ============================================================================
# SERVICE STATUS
# ============================================================================
Write-Section "Acronis Service Status"

$acronisServices = @(
    @{ Name = "AcronisCyberProtectionService"; DisplayName = "Acronis Cyber Protection Service" },
    @{ Name = "acronis_mms"; DisplayName = "Acronis Managed Machine Service" },
    @{ Name = "AcronisScheduler2"; DisplayName = "Acronis Scheduler" },
    @{ Name = "MMS"; DisplayName = "Acronis MMS" },
    @{ Name = "syncagentsrv"; DisplayName = "Acronis Sync Agent" }
)

$acronisInstalled = $false

foreach ($svc in $acronisServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $acronisInstalled = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $acronisInstalled) {
    Register-Check -Name "Acronis Agent" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# INSTALLATION PATH AND VERSION
# ============================================================================
Write-Section "Installation Details"

$acronisPaths = @(
    "C:\Program Files\Acronis",
    "C:\Program Files (x86)\Acronis",
    "C:\Program Files\BackupClient"
)

foreach ($path in $acronisPaths) {
    if (Test-Path $path) {
        Register-Check -Name "Acronis Install Path" -Status PASS -Message $path

        # Check for main executable
        $acronisExes = @(
            (Join-Path $path "Agent\bin\AcronisAgent.exe"),
            (Join-Path $path "BackupAndRecovery\BackupAndRecovery.exe"),
            (Join-Path $path "TrueImageHome\TrueImage.exe")
        )

        foreach ($exe in $acronisExes) {
            if (Test-Path $exe) {
                $version = (Get-Item $exe).VersionInfo.FileVersion
                Register-Check -Name "Acronis Version" -Status PASS -Message "v$version"
                break
            }
        }
        break
    }
}

# ============================================================================
# AGENT REGISTRATION STATUS
# ============================================================================
Write-Section "Agent Registration"

# Check registration via registry
$regPaths = @(
    "HKLM:\SOFTWARE\Acronis\BackupAndRecovery\Settings",
    "HKLM:\SOFTWARE\Acronis\MMS",
    "HKLM:\SOFTWARE\Acronis\Agent"
)

foreach ($regPath in $regPaths) {
    try {
        $regInfo = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
        if ($regInfo) {
            # Check if registered to management server
            if ($regInfo.ManagementServerUrl -or $regInfo.ServerAddress) {
                $server = $regInfo.ManagementServerUrl ?? $regInfo.ServerAddress
                # Mask the server address for security
                if ($server -match '^https?://') {
                    Register-Check -Name "Management Server" -Status PASS -Message "Registered to cloud console"
                } else {
                    Register-Check -Name "Management Server" -Status PASS -Message "Registered to on-premises server"
                }
            }

            # Check machine ID
            if ($regInfo.MachineId -or $regInfo.AgentId) {
                $agentId = $regInfo.MachineId ?? $regInfo.AgentId
                Register-Check -Name "Agent ID" -Status PASS -Message "Registered ($($agentId.Substring(0,8))...)"
            }
            break
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# BACKUP PLAN STATUS
# ============================================================================
Write-Section "Backup Plan Configuration"

# Check for backup plans via configuration files
$planPaths = @(
    "$env:ProgramData\Acronis\BackupAndRecovery\MMS\Plans",
    "$env:ProgramData\Acronis\Agent\Plans"
)

$plansFound = $false
foreach ($planPath in $planPaths) {
    if (Test-Path $planPath) {
        $plans = Get-ChildItem -Path $planPath -Filter "*.xml" -ErrorAction SilentlyContinue
        if ($plans) {
            $plansFound = $true
            Register-Check -Name "Backup Plans" -Status PASS -Message "$($plans.Count) plan(s) configured"
        }
    }
}

if (-not $plansFound) {
    # Check registry for plan count
    try {
        $planCount = (Get-ItemProperty "HKLM:\SOFTWARE\Acronis\MMS\Plans" -ErrorAction SilentlyContinue).Count
        if ($planCount -and $planCount -gt 0) {
            Register-Check -Name "Backup Plans" -Status PASS -Message "$planCount plan(s) configured"
        } else {
            Register-Check -Name "Backup Plans" -Status WARN -Message "No backup plans detected"
        }
    } catch {
        Register-Check -Name "Backup Plans" -Status WARN -Message "Unable to determine plan configuration"
    }
}

# ============================================================================
# BACKUP STATUS AND HISTORY
# ============================================================================
Write-Section "Backup Status"

# Check Acronis event log
try {
    $backupEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        ProviderName = @('Acronis*', 'MMS')
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 20 -ErrorAction SilentlyContinue

    if ($backupEvents) {
        # Look for successful backup events
        $successEvents = $backupEvents | Where-Object { $_.Message -match 'success|completed' -and $_.Level -ne 2 }
        $errorEvents = $backupEvents | Where-Object { $_.Level -eq 2 }

        if ($successEvents) {
            $lastSuccess = $successEvents | Select-Object -First 1
            $hoursSince = ((Get-Date) - $lastSuccess.TimeCreated).TotalHours
            if ($hoursSince -le 24) {
                Register-Check -Name "Last Successful Backup" -Status PASS -Message "$($lastSuccess.TimeCreated.ToString('g'))"
            } elseif ($hoursSince -le 168) {
                Register-Check -Name "Last Successful Backup" -Status WARN -Message "$([int]$hoursSince) hours ago"
            } else {
                Register-Check -Name "Last Successful Backup" -Status FAIL -Message "More than 7 days ago"
            }
        }

        if ($errorEvents) {
            Register-Check -Name "Recent Backup Errors" -Status WARN -Message "$($errorEvents.Count) error(s) in last 7 days"
        } else {
            Register-Check -Name "Recent Backup Errors" -Status PASS -Message "None in last 7 days"
        }
    } else {
        Register-Check -Name "Backup History" -Status WARN -Message "No recent events found"
    }
} catch {
    Register-Check -Name "Backup History" -Status WARN -Message "Unable to query event log"
}

# Check for backup archives
$archivePaths = @(
    "$env:ProgramData\Acronis\BackupAndRecovery\MMS\Archives",
    "$env:ProgramData\Acronis\CyberProtect\Archives"
)

foreach ($archivePath in $archivePaths) {
    if (Test-Path $archivePath) {
        $archives = Get-ChildItem -Path $archivePath -Recurse -Filter "*.tibx" -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($archives) {
            $archiveAge = (Get-Date) - $archives.LastWriteTime
            if ($archiveAge.TotalDays -le 1) {
                Register-Check -Name "Latest Archive" -Status PASS -Message "Created $($archives.LastWriteTime.ToString('g'))"
            } elseif ($archiveAge.TotalDays -le 7) {
                Register-Check -Name "Latest Archive" -Status WARN -Message "$([int]$archiveAge.TotalDays) days old"
            } else {
                Register-Check -Name "Latest Archive" -Status FAIL -Message "More than 7 days old"
            }
        }
        break
    }
}

# ============================================================================
# ENCRYPTION SETTINGS
# ============================================================================
Write-Section "Encryption Configuration"

# Check for encryption settings in registry
$encryptionPaths = @(
    "HKLM:\SOFTWARE\Acronis\BackupAndRecovery\Settings\Encryption",
    "HKLM:\SOFTWARE\Acronis\MMS\Encryption"
)

$encryptionChecked = $false
foreach ($encPath in $encryptionPaths) {
    try {
        $encSettings = Get-ItemProperty -Path $encPath -ErrorAction SilentlyContinue
        if ($encSettings) {
            $encryptionChecked = $true
            if ($encSettings.Enabled -eq 1 -or $encSettings.UseEncryption -eq 1) {
                # Check encryption algorithm
                $algo = $encSettings.Algorithm ?? "AES-256"
                Register-Check -Name "Backup Encryption" -Status PASS -Message "Enabled ($algo)"
            } else {
                Register-Check -Name "Backup Encryption" -Status WARN -Message "Not enabled"
            }
            break
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $encryptionChecked) {
    Register-Check -Name "Backup Encryption" -Status WARN -Message "Unable to determine encryption status"
}

# ============================================================================
# STORAGE / DESTINATION
# ============================================================================
Write-Section "Backup Destination"

# Check configured destinations
$destPaths = @(
    "HKLM:\SOFTWARE\Acronis\BackupAndRecovery\Settings\Destinations",
    "HKLM:\SOFTWARE\Acronis\MMS\Storage"
)

foreach ($destPath in $destPaths) {
    try {
        if (Test-Path $destPath) {
            $destinations = Get-ChildItem -Path $destPath -ErrorAction SilentlyContinue
            if ($destinations) {
                Register-Check -Name "Backup Destinations" -Status PASS -Message "$($destinations.Count) destination(s) configured"

                foreach ($dest in $destinations) {
                    $destProps = Get-ItemProperty -Path $dest.PSPath -ErrorAction SilentlyContinue
                    if ($destProps.Type -eq "Cloud" -or $destProps.Path -match 'acronis\.com') {
                        Register-Check -Name "Cloud Backup" -Status PASS -Message "Acronis Cloud configured"
                    } elseif ($destProps.Path -match '^\\\\') {
                        Register-Check -Name "Network Backup" -Status PASS -Message "Network share configured"
                    }
                }
            }
            break
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SECURITY FEATURES
# ============================================================================
Write-Section "Security Features"

# Check for Acronis Active Protection (ransomware protection)
try {
    $activeProtection = Get-Service -Name "AcronisActiveProtectionService" -ErrorAction SilentlyContinue
    if ($activeProtection) {
        if ($activeProtection.Status -eq "Running") {
            Register-Check -Name "Active Protection (Anti-Ransomware)" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Active Protection (Anti-Ransomware)" -Status WARN -Message "$($activeProtection.Status)"
        }
    } else {
        Register-Check -Name "Active Protection" -Status WARN -Message "Not available (may require Cyber Protect edition)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for self-protection
$selfProtectPath = "HKLM:\SOFTWARE\Acronis\BackupAndRecovery\Settings\SelfProtection"
try {
    $selfProtect = Get-ItemProperty -Path $selfProtectPath -ErrorAction SilentlyContinue
    if ($selfProtect -and $selfProtect.Enabled -eq 1) {
        Register-Check -Name "Self-Protection" -Status PASS -Message "Enabled (prevents unauthorized uninstall)"
    } else {
        Register-Check -Name "Self-Protection" -Status WARN -Message "Not enabled"
    }
} catch {
    Register-Check -Name "Self-Protection" -Status WARN -Message "Unable to determine status"
}

# ============================================================================
# LICENSE STATUS
# ============================================================================
Write-Section "License Status"

$licensePaths = @(
    "HKLM:\SOFTWARE\Acronis\License",
    "HKLM:\SOFTWARE\Acronis\BackupAndRecovery\License"
)

foreach ($licensePath in $licensePaths) {
    try {
        $license = Get-ItemProperty -Path $licensePath -ErrorAction SilentlyContinue
        if ($license) {
            if ($license.LicenseType -or $license.ProductName) {
                $productName = $license.ProductName ?? $license.LicenseType
                Register-Check -Name "Product Edition" -Status PASS -Message $productName
            }

            if ($license.ExpirationDate) {
                $expDate = [DateTime]::Parse($license.ExpirationDate)
                $daysUntilExp = ($expDate - (Get-Date)).Days
                if ($daysUntilExp -gt 30) {
                    Register-Check -Name "License Expiration" -Status PASS -Message "Valid until $($expDate.ToString('d'))"
                } elseif ($daysUntilExp -gt 0) {
                    Register-Check -Name "License Expiration" -Status WARN -Message "Expires in $daysUntilExp days"
                } else {
                    Register-Check -Name "License Expiration" -Status FAIL -Message "Expired"
                }
            }
            break
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
