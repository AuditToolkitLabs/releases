<#
.SYNOPSIS
    Commvault Simpana/Complete Agent Security Audit

.DESCRIPTION
    Audits Commvault agent configuration including:
    - Service status (GxCVD, GxClMgrS)
    - Client registration with CommServe
    - Backup job status
    - Data aging policies
    - Encryption settings
    - Certificate validation

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 11.2 (Perform Automated Backups)
- NIST SP 800-53: CP-9 (Information System Backup)
- ISO 27001: A.12.3.1 (Information Backup)
- PCI DSS: 9.5, 12.10.1 (Backup procedures)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Commvault Agent Security Audit"

# ============================================================================
# SERVICE STATUS
# ============================================================================
Write-Section "Commvault Service Status"

$commvaultServices = @(
    @{ Name = "GxCVD"; DisplayName = "Commvault Communications Service (cvd)" },
    @{ Name = "GxClMgrS"; DisplayName = "Commvault Client Event Manager" },
    @{ Name = "GxFWD"; DisplayName = "Commvault Firewall Service" },
    @{ Name = "GXMMM"; DisplayName = "Commvault Media Manager" },
    @{ Name = "GxDLP"; DisplayName = "Commvault DLP Service" }
)

$commvaultInstalled = $false
$mainServiceRunning = $false

foreach ($svc in $commvaultServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $commvaultInstalled = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
                if ($svc.Name -eq "GxCVD") { $mainServiceRunning = $true }
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $commvaultInstalled) {
    Register-Check -Name "Commvault Agent" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# INSTALLATION PATH AND VERSION
# ============================================================================
Write-Section "Installation Details"

$commvaultPaths = @(
    "C:\Program Files\Commvault\Simpana",
    "C:\Program Files\Commvault\ContentStore",
    "C:\Program Files (x86)\Commvault\Simpana"
)

$installPath = $null
foreach ($path in $commvaultPaths) {
    if (Test-Path $path) {
        $installPath = $path
        Register-Check -Name "Commvault Install Path" -Status PASS -Message $path

        # Check for version file or executable
        $versionFile = Join-Path $path "Base\version.txt"
        if (Test-Path $versionFile) {
            $version = Get-Content $versionFile -First 1 -ErrorAction SilentlyContinue
            if ($version) {
                Register-Check -Name "Commvault Version" -Status PASS -Message "v$version"
            }
        }

        # Alternative: check registry for version
        $regVersion = Get-ItemProperty "HKLM:\SOFTWARE\CommVault Systems\Galaxy\Instance*" -ErrorAction SilentlyContinue |
            Select-Object -First 1 -ExpandProperty Version
        if ($regVersion) {
            Register-Check -Name "Commvault Version" -Status PASS -Message "v$regVersion"
        }
        break
    }
}

# ============================================================================
# COMMSERVE REGISTRATION
# ============================================================================
Write-Section "CommServe Registration"

# Check client registration
$instancePaths = Get-ChildItem "HKLM:\SOFTWARE\CommVault Systems\Galaxy" -ErrorAction SilentlyContinue |
    Where-Object { $_.PSChildName -match '^Instance\d+$' }

foreach ($instance in $instancePaths) {
    try {
        $instanceConfig = Get-ItemProperty -Path $instance.PSPath -ErrorAction SilentlyContinue
        if ($instanceConfig) {
            # CommServe hostname
            if ($instanceConfig.sCSHOSTNAME) {
                Register-Check -Name "CommServe" -Status PASS -Message "Registered to $($instanceConfig.sCSHOSTNAME)"
            }

            # Client name
            if ($instanceConfig.sHOSTNAME -or $instanceConfig.ClientName) {
                $clientName = $instanceConfig.sHOSTNAME ?? $instanceConfig.ClientName
                Register-Check -Name "Client Name" -Status PASS -Message $clientName
            }

            # Instance ID
            if ($instanceConfig.nINSTANCE) {
                Register-Check -Name "Instance ID" -Status PASS -Message "Instance $($instanceConfig.nINSTANCE)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check communication status
if ($mainServiceRunning) {
    # Test if cvd can communicate (basic check via port)
    $cvdPort = 8400  # Default Commvault port
    try {
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.Connect("localhost", $cvdPort)
        if ($tcpClient.Connected) {
            Register-Check -Name "CVD Port ($cvdPort)" -Status PASS -Message "Listening"
            $tcpClient.Close()
        }
    } catch {
        Register-Check -Name "CVD Port ($cvdPort)" -Status WARN -Message "Not responding"
    }
}

# ============================================================================
# BACKUP JOB STATUS
# ============================================================================
Write-Section "Backup Status"

# Check event log for Commvault events
try {
    $backupEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        ProviderName = @('EvMgrC', 'CVSession', 'Commvault*')
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 30 -ErrorAction SilentlyContinue

    if ($backupEvents) {
        # Look for success/failure patterns
        $successEvents = $backupEvents | Where-Object {
            $_.Message -match 'completed successfully|backup completed|job succeeded' -and $_.Level -ne 2
        }
        $failureEvents = $backupEvents | Where-Object { $_.Level -eq 2 -or $_.Message -match 'failed|error' }

        if ($successEvents) {
            $lastSuccess = $successEvents | Select-Object -First 1
            $hoursSince = ((Get-Date) - $lastSuccess.TimeCreated).TotalHours
            if ($hoursSince -le 24) {
                Register-Check -Name "Last Successful Backup" -Status PASS -Message "$($lastSuccess.TimeCreated.ToString('g'))"
            } elseif ($hoursSince -le 168) {
                Register-Check -Name "Last Successful Backup" -Status WARN -Message "$([int]$hoursSince) hours ago"
            } else {
                Register-Check -Name "Last Successful Backup" -Status FAIL -Message "More than 7 days ago"
            }
        } else {
            Register-Check -Name "Backup Status" -Status WARN -Message "No recent successful backups found"
        }

        if ($failureEvents) {
            Register-Check -Name "Recent Backup Errors" -Status WARN -Message "$($failureEvents.Count) error(s) in last 7 days"
        } else {
            Register-Check -Name "Recent Backup Errors" -Status PASS -Message "None in last 7 days"
        }
    } else {
        Register-Check -Name "Backup History" -Status WARN -Message "No recent events found in Application log"
    }
} catch {
    Register-Check -Name "Backup History" -Status WARN -Message "Unable to query event log"
}

# Check job results file if exists
if ($installPath) {
    $jobResultsPath = Join-Path $installPath "iDataAgent\JobResults"
    if (Test-Path $jobResultsPath) {
        $recentJobs = Get-ChildItem $jobResultsPath -Filter "*.log" -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 5
        if ($recentJobs) {
            $newestJob = $recentJobs | Select-Object -First 1
            $jobAge = (Get-Date) - $newestJob.LastWriteTime
            Register-Check -Name "Job Results Logs" -Status PASS -Message "$($recentJobs.Count) recent jobs, newest $([int]$jobAge.TotalHours)h ago"
        }
    }
}

# ============================================================================
# DATA AGING / RETENTION
# ============================================================================
Write-Section "Data Aging Configuration"

# Check for data aging configuration via registry
$agingPath = "HKLM:\SOFTWARE\CommVault Systems\Galaxy\Instance*\DataAging"
try {
    $agingConfig = Get-ItemProperty -Path $agingPath -ErrorAction SilentlyContinue
    if ($agingConfig) {
        if ($agingConfig.Enabled -eq 1) {
            Register-Check -Name "Data Aging" -Status PASS -Message "Enabled"

            if ($agingConfig.RetentionDays) {
                $retention = $agingConfig.RetentionDays
                if ($retention -ge 30) {
                    Register-Check -Name "Retention Period" -Status PASS -Message "$retention days"
                } elseif ($retention -ge 7) {
                    Register-Check -Name "Retention Period" -Status WARN -Message "$retention days (consider 30+)"
                } else {
                    Register-Check -Name "Retention Period" -Status WARN -Message "Only $retention days"
                }
            }
        } else {
            Register-Check -Name "Data Aging" -Status WARN -Message "Not enabled"
        }
    } else {
        Register-Check -Name "Data Aging" -Status WARN -Message "Configuration not found (may be managed by CommServe)"
    }
} catch {
    Register-Check -Name "Data Aging" -Status WARN -Message "Managed by CommServe (cannot query locally)"
}

# ============================================================================
# ENCRYPTION SETTINGS
# ============================================================================
Write-Section "Encryption Configuration"

# Check encryption settings
$encryptionPath = "HKLM:\SOFTWARE\CommVault Systems\Galaxy\Instance*\Encryption"
try {
    $encConfig = Get-ItemProperty -Path $encryptionPath -ErrorAction SilentlyContinue
    if ($encConfig) {
        if ($encConfig.Enabled -eq 1 -or $encConfig.UseEncryption -eq 1) {
            $cipher = $encConfig.CipherType ?? "AES"
            $keyLength = $encConfig.KeyLength ?? 256
            Register-Check -Name "Backup Encryption" -Status PASS -Message "Enabled ($cipher-$keyLength)"
        } else {
            Register-Check -Name "Backup Encryption" -Status WARN -Message "Not enabled"
        }
    } else {
        Register-Check -Name "Backup Encryption" -Status WARN -Message "Encryption configuration managed by CommServe"
    }
} catch {
    Register-Check -Name "Backup Encryption" -Status WARN -Message "Unable to determine encryption status"
}

# Check for network encryption (client-to-CommServe)
$networkEncPath = "HKLM:\SOFTWARE\CommVault Systems\Galaxy\Instance*\Network"
try {
    $netConfig = Get-ItemProperty -Path $networkEncPath -ErrorAction SilentlyContinue
    if ($netConfig -and $netConfig.UseSSL -eq 1) {
        Register-Check -Name "Network Encryption (SSL)" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Network Encryption (SSL)" -Status WARN -Message "Not enabled or managed centrally"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CERTIFICATE VALIDATION
# ============================================================================
Write-Section "Certificate Configuration"

if ($installPath) {
    $certPath = Join-Path $installPath "Base\certificates"
    if (Test-Path $certPath) {
        $certs = Get-ChildItem $certPath -Filter "*.pem" -ErrorAction SilentlyContinue
        if ($certs) {
            Register-Check -Name "SSL Certificates" -Status PASS -Message "$($certs.Count) certificate(s) present"
        } else {
            Register-Check -Name "SSL Certificates" -Status WARN -Message "No certificates found"
        }
    }
}

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check service account
try {
    $svcAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='GxCVD'" -ErrorAction SilentlyContinue).StartName
    if ($svcAccount) {
        if ($svcAccount -eq "LocalSystem") {
            Register-Check -Name "Service Account" -Status PASS -Message "LocalSystem"
        } elseif ($svcAccount -match 'NT SERVICE|Network') {
            Register-Check -Name "Service Account" -Status PASS -Message $svcAccount
        } else {
            Register-Check -Name "Service Account" -Status PASS -Message "$svcAccount (dedicated account)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for firewall service (Commvault's built-in firewall tunneling)
try {
    $fwdService = Get-Service -Name "GxFWD" -ErrorAction SilentlyContinue
    if ($fwdService -and $fwdService.Status -eq "Running") {
        Register-Check -Name "Firewall Tunneling" -Status PASS -Message "Enabled (GxFWD running)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check log file permissions
if ($installPath) {
    $logPath = Join-Path $installPath "Log Files"
    if (Test-Path $logPath) {
        $logAcl = Get-Acl $logPath -ErrorAction SilentlyContinue
        $everyoneAccess = $logAcl.Access | Where-Object { $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "Write" }
        if ($everyoneAccess) {
            Register-Check -Name "Log File Permissions" -Status WARN -Message "Broad write access detected"
        } else {
            Register-Check -Name "Log File Permissions" -Status PASS -Message "Restricted access"
        }
    }
}

# ============================================================================
# LICENSE STATUS
# ============================================================================
Write-Section "License Status"

# License is typically managed by CommServe, limited local visibility
$licensePath = "HKLM:\SOFTWARE\CommVault Systems\Galaxy\License"
try {
    $license = Get-ItemProperty -Path $licensePath -ErrorAction SilentlyContinue
    if ($license) {
        if ($license.LicenseType) {
            Register-Check -Name "License Type" -Status PASS -Message $license.LicenseType
        }
    } else {
        Register-Check -Name "License Status" -Status PASS -Message "Managed by CommServe"
    }
} catch {
    Register-Check -Name "License Status" -Status PASS -Message "Managed by CommServe"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
