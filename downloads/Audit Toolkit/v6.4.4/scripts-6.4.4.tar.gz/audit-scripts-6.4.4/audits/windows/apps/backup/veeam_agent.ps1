<#
.SYNOPSIS
    Veeam Agent for Windows Security Audit

.DESCRIPTION
    Audits Veeam Agent for Microsoft Windows configuration including:
    - Service status and health
    - Backup job configuration
    - Encryption settings
    - Repository connectivity
    - License status
    - Last backup timestamps

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 11.2 (Perform Automated Backups)
- NIST SP 800-53: CP-9 (Information System Backup)
- ISO 27001: A.12.3.1 (Information Backup)
- PCI DSS: 9.5, 12.10.1 (Backup procedures)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Veeam Agent for Windows Security Audit"

# ============================================================================
# SERVICE STATUS
# ============================================================================
Write-Section "Veeam Service Status"

$veeamServices = @(
    @{ Name = "VeeamEndpointBackupSvc"; DisplayName = "Veeam Agent Service" },
    @{ Name = "VeeamTransportSvc"; DisplayName = "Veeam Data Mover Service" },
    @{ Name = "VeeamDeploySvc"; DisplayName = "Veeam Installer Service" }
)

$veeamInstalled = $false

foreach ($svc in $veeamServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $veeamInstalled = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $veeamInstalled) {
    Register-Check -Name "Veeam Agent" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# INSTALLATION PATH AND VERSION
# ============================================================================
Write-Section "Installation Details"

$veeamPaths = @(
    "C:\Program Files\Veeam\Endpoint Backup",
    "C:\Program Files (x86)\Veeam\Endpoint Backup"
)

foreach ($path in $veeamPaths) {
    if (Test-Path $path) {
        Register-Check -Name "Veeam Install Path" -Status PASS -Message $path

        # Check version from executable
        $veeamExe = Join-Path $path "Veeam.EndPoint.Manager.exe"
        if (Test-Path $veeamExe) {
            $version = (Get-Item $veeamExe).VersionInfo.FileVersion
            Register-Check -Name "Veeam Version" -Status PASS -Message "v$version"
        }
        break
    }
}

# ============================================================================
# BACKUP JOB CONFIGURATION
# ============================================================================
Write-Section "Backup Job Configuration"

# Check registry for job configuration
$jobConfigPath = "HKLM:\SOFTWARE\Veeam\Veeam Endpoint Backup"
try {
    $jobConfig = Get-ItemProperty -Path $jobConfigPath -ErrorAction SilentlyContinue
    if ($jobConfig) {
        # Check if any backup jobs are configured
        if ($jobConfig.JobCount -and $jobConfig.JobCount -gt 0) {
            Register-Check -Name "Backup Jobs Configured" -Status PASS -Message "$($jobConfig.JobCount) job(s)"
        } else {
            Register-Check -Name "Backup Jobs Configured" -Status WARN -Message "No jobs configured"
        }
    }
} catch {
    Register-Check -Name "Backup Jobs" -Status WARN -Message "Unable to query job configuration"
}

# Check Veeam configuration file
$configFile = "$env:ProgramData\Veeam\Endpoint Backup\VeeamEndpointBackup.db"
if (Test-Path $configFile) {
    $configAge = (Get-Date) - (Get-Item $configFile).LastWriteTime
    if ($configAge.TotalDays -le 7) {
        Register-Check -Name "Configuration Database" -Status PASS -Message "Active (modified $([int]$configAge.TotalDays) days ago)"
    } else {
        Register-Check -Name "Configuration Database" -Status WARN -Message "Stale (modified $([int]$configAge.TotalDays) days ago)"
    }
} else {
    Register-Check -Name "Configuration Database" -Status WARN -Message "Not found"
}

# ============================================================================
# BACKUP STATUS AND HISTORY
# ============================================================================
Write-Section "Backup Status"

# Check recent backup via event log
try {
    $backupEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Veeam Agent'
        ID = @(110, 190)  # Backup started, Backup completed
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 10 -ErrorAction SilentlyContinue

    if ($backupEvents) {
        $lastBackup = $backupEvents | Where-Object { $_.Id -eq 190 } | Select-Object -First 1
        if ($lastBackup) {
            $hoursSince = ((Get-Date) - $lastBackup.TimeCreated).TotalHours
            if ($hoursSince -le 24) {
                Register-Check -Name "Last Backup" -Status PASS -Message "$($lastBackup.TimeCreated.ToString('g'))"
            } elseif ($hoursSince -le 168) {
                Register-Check -Name "Last Backup" -Status WARN -Message "$([int]$hoursSince) hours ago"
            } else {
                Register-Check -Name "Last Backup" -Status FAIL -Message "More than 7 days ago"
            }
        }

        # Check for failures
        $failureEvents = Get-WinEvent -FilterHashtable @{
            LogName = 'Veeam Agent'
            Level = 2  # Error
            StartTime = (Get-Date).AddDays(-7)
        } -MaxEvents 5 -ErrorAction SilentlyContinue

        if ($failureEvents) {
            Register-Check -Name "Recent Backup Errors" -Status WARN -Message "$($failureEvents.Count) error(s) in last 7 days"
        } else {
            Register-Check -Name "Recent Backup Errors" -Status PASS -Message "None in last 7 days"
        }
    } else {
        Register-Check -Name "Backup History" -Status WARN -Message "No recent backup events found"
    }
} catch {
    # Event log may not exist
    Register-Check -Name "Backup History" -Status WARN -Message "Unable to query event log"
}

# ============================================================================
# ENCRYPTION SETTINGS
# ============================================================================
Write-Section "Encryption Configuration"

# Check if encryption is enabled via registry
$encryptionPath = "HKLM:\SOFTWARE\Veeam\Veeam Endpoint Backup\Jobs"
try {
    $jobs = Get-ChildItem -Path $encryptionPath -ErrorAction SilentlyContinue
    $encryptedJobs = 0
    $totalJobs = 0

    foreach ($job in $jobs) {
        $totalJobs++
        $jobProps = Get-ItemProperty -Path $job.PSPath -ErrorAction SilentlyContinue
        if ($jobProps.EncryptionEnabled -eq 1) {
            $encryptedJobs++
        }
    }

    if ($totalJobs -gt 0) {
        if ($encryptedJobs -eq $totalJobs) {
            Register-Check -Name "Backup Encryption" -Status PASS -Message "All $totalJobs job(s) encrypted"
        } elseif ($encryptedJobs -gt 0) {
            Register-Check -Name "Backup Encryption" -Status WARN -Message "$encryptedJobs of $totalJobs job(s) encrypted"
        } else {
            Register-Check -Name "Backup Encryption" -Status FAIL -Message "No jobs encrypted"
        }
    }
} catch {
    Register-Check -Name "Backup Encryption" -Status WARN -Message "Unable to determine encryption status"
}

# ============================================================================
# REPOSITORY / TARGET CONFIGURATION
# ============================================================================
Write-Section "Backup Target"

# Check for configured backup targets
$targetPath = "HKLM:\SOFTWARE\Veeam\Veeam Endpoint Backup\Repositories"
try {
    $repos = Get-ChildItem -Path $targetPath -ErrorAction SilentlyContinue
    if ($repos) {
        Register-Check -Name "Backup Repositories" -Status PASS -Message "$($repos.Count) repository(s) configured"

        foreach ($repo in $repos) {
            $repoProps = Get-ItemProperty -Path $repo.PSPath -ErrorAction SilentlyContinue
            if ($repoProps.Path) {
                # Check if path is network or local
                if ($repoProps.Path -match '^\\\\') {
                    Register-Check -Name "Repository Type" -Status PASS -Message "Network path (offsite)"
                } elseif ($repoProps.Path -match '^[A-Z]:\\') {
                    Register-Check -Name "Repository Type" -Status WARN -Message "Local path (consider offsite backup)"
                }
            }
        }
    } else {
        Register-Check -Name "Backup Repositories" -Status WARN -Message "No repositories configured"
    }
} catch {
    Register-Check -Name "Backup Repositories" -Status WARN -Message "Unable to query repository configuration"
}

# ============================================================================
# LICENSE STATUS
# ============================================================================
Write-Section "License Status"

$licensePath = "HKLM:\SOFTWARE\Veeam\Veeam Endpoint Backup\License"
try {
    $license = Get-ItemProperty -Path $licensePath -ErrorAction SilentlyContinue
    if ($license) {
        if ($license.LicenseType -eq "Free") {
            Register-Check -Name "License Type" -Status PASS -Message "Free Edition"
        } elseif ($license.LicenseType -eq "Rental" -or $license.LicenseType -eq "Subscription") {
            if ($license.ExpirationDate) {
                $expDate = [DateTime]::Parse($license.ExpirationDate)
                $daysUntilExp = ($expDate - (Get-Date)).Days
                if ($daysUntilExp -gt 30) {
                    Register-Check -Name "License Status" -Status PASS -Message "Valid until $($expDate.ToString('d'))"
                } elseif ($daysUntilExp -gt 0) {
                    Register-Check -Name "License Status" -Status WARN -Message "Expires in $daysUntilExp days"
                } else {
                    Register-Check -Name "License Status" -Status FAIL -Message "Expired"
                }
            }
        }
    } else {
        Register-Check -Name "License Status" -Status PASS -Message "Free Edition (no license key)"
    }
} catch {
    Register-Check -Name "License Status" -Status WARN -Message "Unable to determine license status"
}

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check if service account is not LocalSystem (best practice)
try {
    $svcAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='VeeamEndpointBackupSvc'" -ErrorAction SilentlyContinue).StartName
    if ($svcAccount) {
        if ($svcAccount -eq "LocalSystem") {
            Register-Check -Name "Service Account" -Status PASS -Message "LocalSystem (default)"
        } else {
            Register-Check -Name "Service Account" -Status PASS -Message $svcAccount
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check file-level backup vs image-level
# Image-level is generally more secure for DR

# Check retention policy
$retentionPath = "HKLM:\SOFTWARE\Veeam\Veeam Endpoint Backup\Jobs"
try {
    $jobs = Get-ChildItem -Path $retentionPath -ErrorAction SilentlyContinue
    foreach ($job in $jobs) {
        $jobProps = Get-ItemProperty -Path $job.PSPath -ErrorAction SilentlyContinue
        if ($jobProps.RetentionPolicy) {
            $retention = $jobProps.RetentionPolicy
            if ($retention -ge 14) {
                Register-Check -Name "Retention Policy" -Status PASS -Message "$retention restore points"
            } elseif ($retention -ge 7) {
                Register-Check -Name "Retention Policy" -Status WARN -Message "$retention restore points (consider 14+)"
            } else {
                Register-Check -Name "Retention Policy" -Status WARN -Message "Only $retention restore points"
            }
            break
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
