<#
.SYNOPSIS
    Veritas NetBackup Client Security Audit

.DESCRIPTION
    Audits Veritas NetBackup client configuration including:
    - Service status (NetBackup Client Service, Legacy Network Service)
    - Master server connectivity
    - Policy assignment and backup schedules
    - Backup status and history
    - Encryption settings
    - Certificate configuration

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 11.2 (Perform Automated Backups)
- NIST SP 800-53: CP-9 (Information System Backup)
- ISO 27001: A.12.3.1 (Information Backup)
- PCI DSS: 9.5, 12.10.1 (Backup procedures)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Veritas NetBackup Client Security Audit"

# ============================================================================
# SERVICE STATUS
# ============================================================================
Write-Section "NetBackup Service Status"

$netbackupServices = @(
    @{ Name = "NetBackup Client Service"; DisplayName = "NetBackup Client Service (bpcd)" },
    @{ Name = "NetBackup Legacy Network Service"; DisplayName = "NetBackup Legacy Network Service" },
    @{ Name = "NetBackup Remote Manager and Monitor Service"; DisplayName = "NetBackup RMM Service" },
    @{ Name = "NetBackup SAN Client Fibre Transport Service"; DisplayName = "NetBackup SAN Client" }
)

$netbackupInstalled = $false
$mainServiceRunning = $false

foreach ($svc in $netbackupServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $netbackupInstalled = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
                if ($svc.Name -eq "NetBackup Client Service") { $mainServiceRunning = $true }
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $netbackupInstalled) {
    Register-Check -Name "NetBackup Client" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# INSTALLATION PATH AND VERSION
# ============================================================================
Write-Section "Installation Details"

$netbackupPaths = @(
    "C:\Program Files\Veritas\NetBackup",
    "C:\Program Files\VERITAS\NetBackup",
    "C:\Program Files (x86)\Veritas\NetBackup"
)

$installPath = $null
foreach ($path in $netbackupPaths) {
    if (Test-Path $path) {
        $installPath = $path
        Register-Check -Name "NetBackup Install Path" -Status PASS -Message $path
        break
    }
}

try {
    $versionInfo = Get-ItemProperty -Path $versionPath -ErrorAction SilentlyContinue
    if ($versionInfo) {
        if ($versionInfo.PackageVersion) {
            Register-Check -Name "NetBackup Version" -Status PASS -Message "v$($versionInfo.PackageVersion)"
        } elseif ($versionInfo.Version) {
            Register-Check -Name "NetBackup Version" -Status PASS -Message "v$($versionInfo.Version)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Alternative version check via executable
if ($installPath) {
    $bpcdPath = Join-Path $installPath "bin\bpcd.exe"
    if (Test-Path $bpcdPath) {
        try {
            $fileVersion = (Get-Item $bpcdPath).VersionInfo.ProductVersion
            if ($fileVersion) {
                Register-Check -Name "NetBackup Binary Version" -Status PASS -Message "v$fileVersion"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# MASTER SERVER CONFIGURATION
# ============================================================================
Write-Section "Master Server Configuration"

# Read bp.conf for master server
if ($installPath) {
    $bpConfPath = Join-Path $installPath "bp.conf"
    if (Test-Path $bpConfPath) {
        $bpConf = Get-Content $bpConfPath -ErrorAction SilentlyContinue

        # Find SERVER entries
        $servers = $bpConf | Where-Object { $_ -match '^SERVER\s*=' } | ForEach-Object { ($_ -split '=')[1].Trim() }
        if ($servers) {
            $masterServer = $servers | Select-Object -First 1
            Register-Check -Name "Master Server" -Status PASS -Message $masterServer

            if ($servers.Count -gt 1) {
                Register-Check -Name "Media Servers" -Status PASS -Message "$($servers.Count - 1) additional server(s)"
            }
        } else {
            Register-Check -Name "Master Server" -Status WARN -Message "Not configured in bp.conf"
        }

        # Check CLIENT_NAME
        $clientName = $bpConf | Where-Object { $_ -match '^CLIENT_NAME\s*=' } | ForEach-Object { ($_ -split '=')[1].Trim() }
        if ($clientName) {
            Register-Check -Name "Client Name" -Status PASS -Message $clientName
        } else {
            Register-Check -Name "Client Name" -Status WARN -Message "Using hostname (not explicitly configured)"
        }
    } else {
        Register-Check -Name "bp.conf" -Status WARN -Message "Configuration file not found"
    }
}

# Test connectivity to master server
if ($mainServiceRunning -and $installPath) {
    $bptestBpcdPath = Join-Path $installPath "bin\bptestbpcd.exe"
    if (Test-Path $bptestBpcdPath) {
        try {
            # Run quick connectivity test
            & $bptestBpcdPath -host localhost 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                Register-Check -Name "Local bpcd Test" -Status PASS -Message "Client daemon responding"
            } else {
                Register-Check -Name "Local bpcd Test" -Status WARN -Message "Test returned code $LASTEXITCODE"
            }
        } catch {
            Register-Check -Name "Local bpcd Test" -Status WARN -Message "Unable to run connectivity test"
        }
    }
}

# Check default port (bpcd = 13782)
try {
    $bpcdPort = 13782
    $tcpClient = New-Object System.Net.Sockets.TcpClient
    $tcpClient.Connect("localhost", $bpcdPort)
    if ($tcpClient.Connected) {
        Register-Check -Name "BPCD Port ($bpcdPort)" -Status PASS -Message "Listening"
        $tcpClient.Close()
    }
} catch {
    Register-Check -Name "BPCD Port (13782)" -Status WARN -Message "Not responding"
}

# ============================================================================
# BACKUP STATUS
# ============================================================================
Write-Section "Backup Status"

# Check progress logs
if ($installPath) {
    # Check for recent backup activity
    if (Test-Path (Join-Path $installPath "logs")) {
        $recentLogs = Get-ChildItem (Join-Path $installPath "logs") -Filter "*.log" -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
            Sort-Object LastWriteTime -Descending

        if ($recentLogs) {
            $newestLog = $recentLogs | Select-Object -First 1
            $logAge = (Get-Date) - $newestLog.LastWriteTime

            if ($logAge.TotalHours -le 24) {
                Register-Check -Name "Recent Backup Activity" -Status PASS -Message "$($recentLogs.Count) logs, newest $([int]$logAge.TotalHours)h ago"
            } elseif ($logAge.TotalHours -le 168) {
                Register-Check -Name "Recent Backup Activity" -Status WARN -Message "Newest log is $([int]$logAge.TotalHours) hours old"
            } else {
                Register-Check -Name "Recent Backup Activity" -Status FAIL -Message "No recent backup activity (>7 days)"
            }
        } else {
            Register-Check -Name "Backup Activity" -Status WARN -Message "No recent backup logs found"
        }
    }
}

# Check Event Log for NetBackup events
try {
    $nbEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        ProviderName = @('NetBackup*', 'Veritas*', 'VRTS*')
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 30 -ErrorAction SilentlyContinue

    if ($nbEvents) {
        $errorEvents = $nbEvents | Where-Object { $_.Level -eq 2 }  # Error level | Out-Null

        if ($errorEvents) {
            Register-Check -Name "NetBackup Errors" -Status WARN -Message "$($errorEvents.Count) error(s) in Application log"
        } else {
            Register-Check -Name "NetBackup Errors" -Status PASS -Message "No errors in last 7 days"
        }

        Register-Check -Name "NetBackup Events" -Status PASS -Message "$($nbEvents.Count) events in last 7 days"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ENCRYPTION SETTINGS
# ============================================================================
Write-Section "Encryption Configuration"

if ($installPath) {
    # Check for encryption configuration in bp.conf
    $bpConfPath = Join-Path $installPath "bp.conf"
    if (Test-Path $bpConfPath) {
        $bpConf = Get-Content $bpConfPath -ErrorAction SilentlyContinue

        # Check encryption settings
        $encryptEnabled = $bpConf | Where-Object { $_ -match 'ENCRYPTION|USE_VNETD' }
        if ($encryptEnabled) {
            Register-Check -Name "Encryption Settings" -Status PASS -Message "Encryption configuration found"
        } else {
            Register-Check -Name "Encryption Settings" -Status WARN -Message "No local encryption config (may be policy-driven)"
        }
    }

    # Check for key management
    $kmsPath = Join-Path $installPath "kms"
    if (Test-Path $kmsPath) {
        Register-Check -Name "Key Management" -Status PASS -Message "KMS directory present"
    }
}

# Registry encryption settings
$encRegPath = "HKLM:\SOFTWARE\Veritas\NetBackup\CurrentVersion\Encryption"
try {
    $encReg = Get-ItemProperty -Path $encRegPath -ErrorAction SilentlyContinue
    if ($encReg -and $encReg.Enabled -eq 1) {
        Register-Check -Name "Registry Encryption Flag" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CERTIFICATE CONFIGURATION
# ============================================================================
Write-Section "Certificate Configuration"

if ($installPath) {
    # Check for CA certificates
    $certPath = Join-Path $installPath "var\global\keystore"
    if (Test-Path $certPath) {
        $certs = Get-ChildItem $certPath -Recurse -Filter "*.pem" -ErrorAction SilentlyContinue
        if ($certs) {
            Register-Check -Name "SSL Certificates" -Status PASS -Message "$($certs.Count) certificate(s) in keystore"
        } else {
            Register-Check -Name "SSL Certificates" -Status WARN -Message "Keystore directory exists but no PEM files"
        }
    }

    # Check NetBackup CA certificate
    $caCertPath = Join-Path $installPath "var\global\keystore\cacerts"
    if (Test-Path $caCertPath) {
        $caCerts = Get-ChildItem $caCertPath -Filter "*.pem" -ErrorAction SilentlyContinue
        if ($caCerts) {
            Register-Check -Name "CA Certificates" -Status PASS -Message "$($caCerts.Count) CA cert(s)"
        }
    }

    # Check for webserver certificates
    $webCertPath = Join-Path $installPath "var\global\wmc\webserver\certificates"
    if (Test-Path $webCertPath) {
        Register-Check -Name "Web Certificates" -Status PASS -Message "Web certificate directory present"
    }
}

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check service account
try {
    $svcAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='NetBackup Client Service'" -ErrorAction SilentlyContinue).StartName
    if ($svcAccount) {
        if ($svcAccount -eq "LocalSystem") {
            Register-Check -Name "Service Account" -Status PASS -Message "LocalSystem"
        } elseif ($svcAccount -match 'NT SERVICE|Network') {
            Register-Check -Name "Service Account" -Status PASS -Message $svcAccount
        } else {
            Register-Check -Name "Service Account" -Status PASS -Message "$svcAccount (dedicated account)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for ALLOWED_SERVERS restriction
if ($installPath) {
    $bpConfPath = Join-Path $installPath "bp.conf"
    if (Test-Path $bpConfPath) {
        $bpConf = Get-Content $bpConfPath -ErrorAction SilentlyContinue
        $allowedServers = $bpConf | Where-Object { $_ -match '^ALLOW_SERVER\s*=' -or $_ -match '^ALLOWED_TO_LIST_CLIENTS\s*=' }
        if ($allowedServers) {
            Register-Check -Name "Server Restrictions" -Status PASS -Message "ALLOW_SERVER configured"
        } else {
            Register-Check -Name "Server Restrictions" -Status WARN -Message "ALLOW_SERVER not configured (any server can connect)"
        }
    }
}

# Check file permissions on install directory
if ($installPath) {
    try {
        $installAcl = Get-Acl $installPath -ErrorAction SilentlyContinue
        $broadAccess = $installAcl.Access | Where-Object {
            $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "FullControl|Modify|Write"
        }
        if ($broadAccess) {
            Register-Check -Name "Install Directory Permissions" -Status WARN -Message "Broad write access detected"
        } else {
            Register-Check -Name "Install Directory Permissions" -Status PASS -Message "Restricted access"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check for VNETD (secure communication)
if ($installPath) {
    $bpConfPath = Join-Path $installPath "bp.conf"
    if (Test-Path $bpConfPath) {
        $bpConf = Get-Content $bpConfPath -ErrorAction SilentlyContinue
        $vnetd = $bpConf | Where-Object { $_ -match 'VNETD_PORT|USE_VNETD' }
        if ($vnetd) {
            Register-Check -Name "VNETD (Secure Transport)" -Status PASS -Message "Configured"
        } else {
            Register-Check -Name "VNETD (Secure Transport)" -Status WARN -Message "Not explicitly configured"
        }
    }
}

# ============================================================================
# POLICY AND SCHEDULE INFO
# ============================================================================
Write-Section "Policy Configuration"

# Note: Policy info is stored on master server; limited local visibility
if ($installPath) {
    # Check for exclude list
    $excludeListPath = Join-Path $installPath "Exclude_List"
    if (Test-Path $excludeListPath) {
        $excludeCount = (Get-Content $excludeListPath -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
        Register-Check -Name "Exclude List" -Status PASS -Message "$excludeCount exclusion rule(s)"
    } else {
        Register-Check -Name "Exclude List" -Status PASS -Message "No local exclusions (using policy defaults)"
    }

    # Check for include list
    $includeListPath = Join-Path $installPath "Include_List"
    if (Test-Path $includeListPath) {
        $includeCount = (Get-Content $includeListPath -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
        Register-Check -Name "Include List" -Status PASS -Message "$includeCount inclusion rule(s)"
    }
}

Register-Check -Name "Policy Details" -Status PASS -Message "Managed by master server"

# ============================================================================
# LICENSE STATUS
# ============================================================================
Write-Section "License Status"

$licensePath = "HKLM:\SOFTWARE\Veritas\NetBackup\CurrentVersion\License"
try {
    $license = Get-ItemProperty -Path $licensePath -ErrorAction SilentlyContinue
    if ($license -and $license.LicenseType) {
        Register-Check -Name "License Type" -Status PASS -Message $license.LicenseType
    } else {
        Register-Check -Name "License Status" -Status PASS -Message "Managed by master server"
    }
} catch {
    Register-Check -Name "License Status" -Status PASS -Message "Managed by master server"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
