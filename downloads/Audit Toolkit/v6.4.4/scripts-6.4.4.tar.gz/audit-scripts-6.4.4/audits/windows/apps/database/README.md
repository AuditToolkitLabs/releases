# Database Audits

This folder contains security audit scripts for database applications on Windows hosts. Coverage includes:
- SQL Server
- MySQL
- PostgreSQL
- MariaDB
- MongoDB
- Microsoft Access
- Cassandra
- Oracle

Each script checks for service/account hardening, authentication, encryption, auditing, patch management, backup security, and configuration best practices. Manual review guidance is included for items not programmatically verifiable.