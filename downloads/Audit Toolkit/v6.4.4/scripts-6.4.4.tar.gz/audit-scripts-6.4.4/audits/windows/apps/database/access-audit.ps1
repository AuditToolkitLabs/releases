# Microsoft Access Security Audit Script (PowerShell)
# Based on Microsoft Access Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - Microsoft Access Security: https://learn.microsoft.com/en-us/office/troubleshoot/access/security-best-practices
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Check if Access/Office is installed
$accessInstalled = (Test-Path 'HKLM:\Software\Microsoft\Office\16.0\Access') -or
                   (Test-Path 'HKLM:\Software\Microsoft\Office\15.0\Access') -or
                   (Test-Path 'HKCU:\Software\Microsoft\Office\16.0\Access')
if (-not $accessInstalled) {
    Register-Check -Name "Access Installation" -Status SKIP -Message "Microsoft Access not installed"
    Print-Summary
    Exit-Audit
}

# Section: File & Account Hardening
# (Manual) Review Access file (.accdb/.mdb) permissions and user access
Register-Check -Name "File Permissions" -Status WARN -Message "Review Access file permissions and user access (manual)."

# Section: Authentication & Authorization
# (Manual) Review user/group access and password protection
Register-Check -Name "User Access" -Status WARN -Message "Review user/group access and password protection (manual)."

# Section: Encryption
# (Manual) Check file encryption and password protection
Register-Check -Name "Encryption" -Status WARN -Message "Check file encryption and password protection (manual)."

# Section: Auditing & Logging
# (Manual) Review audit trails and logging
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit trails and logging (manual)."

# Section: Patch Management
# (Manual) Check Access version and patch status
Register-Check -Name "Patch Management" -Status WARN -Message "Check Access version and patch status (manual)."

# Section: Backup Security
# (Manual) Review backup folder permissions and encryption
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions and encryption (manual)."

# Section: Configuration Hardening
# (Manual) Review macro settings and trusted locations
Register-Check -Name "Configuration Hardening" -Status WARN -Message "Review macro settings and trusted locations (manual)."

# Section: Security Policies
# (Manual) Review password policy and account lockout
Register-Check -Name "Security Policies" -Status WARN -Message "Review password policy and account lockout (manual)."

# Section: Monitoring & Response
# (Manual) Review event logs and configure alerts
Register-Check -Name "Monitoring & Response" -Status WARN -Message "Review event logs and configure alerts (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - File permissions and user access (File & Account Hardening section)"
Write-Output " - User/group access and password protection (Authentication & Authorization section)"
Write-Output " - Encryption and password protection (Encryption section)"
Write-Output " - Audit trails and logging (Auditing & Logging section)"
Write-Output " - Patch management and version (Patch Management section)"
Write-Output " - Backup folder permissions and encryption (Backup Security section)"
Write-Output " - Macro settings and trusted locations (Configuration Hardening section)"
Write-Output " - Password policy and account lockout (Security Policies section)"
Write-Output " - Event logs and alerting (Monitoring & Response section)"
Write-Output ""
Write-Output "Refer to Microsoft Access Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
