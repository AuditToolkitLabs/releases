
# Cassandra Security Audit Script (PowerShell)
# Based on CIS Benchmarks & Cassandra Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Cassandra Benchmark: https://www.cisecurity.org/benchmark/apache-cassandra
# - Cassandra Security Best Practices: https://cassandra.apache.org/doc/latest/cassandra/security/index.html
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Service & Account Hardening
$service = Get-Service -Name 'Cassandra*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $service) {
    Register-Check -Name "Cassandra Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "Cassandra Service" -Status PASS -Message "Service running: $($service.Name)"

# Section: Authentication & Authorization
# (Manual) Review superuser account and user privileges
Register-Check -Name "Superuser Account" -Status WARN -Message "Review superuser account and user privileges (manual)."

# Section: Network Security
# (Manual) Confirm Cassandra is not exposed to public networks
Register-Check -Name "Network Exposure" -Status WARN -Message "Confirm Cassandra is not exposed to public networks (manual)."

# Section: Encryption
# (Manual) Check SSL/TLS configuration and data-at-rest encryption
Register-Check -Name "Encryption" -Status WARN -Message "Check SSL/TLS configuration and data-at-rest encryption (manual)."

# Section: Auditing & Logging
# (Manual) Review audit log configuration and log retention
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit log configuration and log retention (manual)."

# Section: Patch Management
# (Manual) Check Cassandra version and patch status
Register-Check -Name "Patch Management" -Status WARN -Message "Check Cassandra version and patch status (manual)."

# Section: Backup Security
# (Manual) Review backup folder permissions and encryption
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions and encryption (manual)."

# Section: Configuration Hardening
# (Manual) Review cassandra.yaml for secure settings
Register-Check -Name "Configuration Hardening" -Status WARN -Message "Review cassandra.yaml for secure settings (manual)."

# Section: Security Policies
# (Manual) Review password policy and account lockout
Register-Check -Name "Security Policies" -Status WARN -Message "Review password policy and account lockout (manual)."

# Section: Monitoring & Response
# (Manual) Review event logs and configure alerts
Register-Check -Name "Monitoring & Response" -Status WARN -Message "Review event logs and configure alerts (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Superuser account and user privileges (Authentication & Authorization section)"
Write-Output " - Network exposure and firewall rules (Network Security section)"
Write-Output " - SSL/TLS and encryption settings (Encryption section)"
Write-Output " - Audit log configuration and retention (Auditing & Logging section)"
Write-Output " - Patch management and version (Patch Management section)"
Write-Output " - Backup folder permissions and encryption (Backup Security section)"
Write-Output " - Secure configuration in cassandra.yaml (Configuration Hardening section)"
Write-Output " - Password policy and account lockout (Security Policies section)"
Write-Output " - Event logs and alerting (Monitoring & Response section)"
Write-Output ""
Write-Output "Refer to CIS Cassandra Benchmark and Cassandra Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
