# MariaDB Security Audit Script (PowerShell)
# Based on CIS Benchmarks & MariaDB Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS MariaDB Benchmark: https://www.cisecurity.org/benchmark/mariadb
# - MariaDB Security Best Practices: https://mariadb.com/kb/en/security/
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Service & Account Hardening
$service = Get-Service -Name 'MariaDB*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $service) {
    Register-Check -Name "MariaDB Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "MariaDB Service" -Status PASS -Message "Service running: $($service.Name)"

# Section: Authentication & Authorization
# (Manual) Review root account status and user privileges
Register-Check -Name "Root Account" -Status WARN -Message "Review root account status and user privileges (manual)."

# Section: Network Security
# (Manual) Confirm MariaDB is not exposed to public networks
Register-Check -Name "Network Exposure" -Status WARN -Message "Confirm MariaDB is not exposed to public networks (manual)."

# Section: Encryption
# (Manual) Check SSL/TLS configuration and data-at-rest encryption
Register-Check -Name "Encryption" -Status WARN -Message "Check SSL/TLS configuration and data-at-rest encryption (manual)."

# Section: Auditing & Logging
# (Manual) Review audit log configuration and log retention
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit log configuration and log retention (manual)."

# Section: Patch Management
# (Manual) Check MariaDB version and patch status
Register-Check -Name "Patch Management" -Status WARN -Message "Check MariaDB version and patch status (manual)."

# Section: Backup Security
# (Manual) Review backup folder permissions and encryption
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions and encryption (manual)."

# Section: Configuration Hardening
# (Manual) Review my.cnf/my.ini for secure settings
Register-Check -Name "Configuration Hardening" -Status WARN -Message "Review my.cnf/my.ini for secure settings (manual)."

# Section: Security Policies
# (Manual) Review password policy and account lockout
Register-Check -Name "Security Policies" -Status WARN -Message "Review password policy and account lockout (manual)."

# Section: Monitoring & Response
# (Manual) Review event logs and configure alerts
Register-Check -Name "Monitoring & Response" -Status WARN -Message "Review event logs and configure alerts (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Root account status and user privileges (Authentication & Authorization section)"
Write-Output " - Network exposure and firewall rules (Network Security section)"
Write-Output " - SSL/TLS and encryption settings (Encryption section)"
Write-Output " - Audit log configuration and retention (Auditing & Logging section)"
Write-Output " - Patch management and version (Patch Management section)"
Write-Output " - Backup folder permissions and encryption (Backup Security section)"
Write-Output " - Secure configuration in my.cnf/my.ini (Configuration Hardening section)"
Write-Output " - Password policy and account lockout (Security Policies section)"
Write-Output " - Event logs and alerting (Monitoring & Response section)"
Write-Output ""
Write-Output "Refer to CIS MariaDB Benchmark and MariaDB Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
