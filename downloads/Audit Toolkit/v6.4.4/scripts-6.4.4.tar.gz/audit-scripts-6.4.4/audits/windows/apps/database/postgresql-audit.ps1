# PostgreSQL Security Audit Script (PowerShell)
# Based on CIS Benchmarks & PostgreSQL Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS PostgreSQL Benchmark: https://www.cisecurity.org/benchmark/postgresql
# - PostgreSQL Security Best Practices: https://www.postgresql.org/docs/current/security.html

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Service & Account Hardening
$service = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $service) {
    Register-Check -Name "PostgreSQL Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "PostgreSQL Service" -Status PASS -Message "Service running: $($service.Name)"

# Section: Authentication & Authorization
# (Manual) Review postgres superuser account and user privileges
Register-Check -Name "Superuser Account" -Status WARN -Message "Review postgres superuser account and user privileges (manual)."

# Section: Network Security
# (Manual) Confirm PostgreSQL is not exposed to public networks
Register-Check -Name "Network Exposure" -Status WARN -Message "Confirm PostgreSQL is not exposed to public networks (manual)."

# Section: Encryption
# (Manual) Check SSL/TLS configuration and data-at-rest encryption
Register-Check -Name "Encryption" -Status WARN -Message "Check SSL/TLS configuration and data-at-rest encryption (manual)."

# Section: Auditing & Logging
# (Manual) Review audit log configuration and log retention
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit log configuration and log retention (manual)."

# Section: Patch Management
# (Manual) Check PostgreSQL version and patch status
Register-Check -Name "Patch Management" -Status WARN -Message "Check PostgreSQL version and patch status (manual)."

# Section: Backup Security
# (Manual) Review backup folder permissions and encryption
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions and encryption (manual)."

# Section: Configuration Hardening
# (Manual) Review postgresql.conf and pg_hba.conf for secure settings
Register-Check -Name "Configuration Hardening" -Status WARN -Message "Review postgresql.conf and pg_hba.conf for secure settings (manual)."

# Section: Security Policies
# (Manual) Review password policy and account lockout
Register-Check -Name "Security Policies" -Status WARN -Message "Review password policy and account lockout (manual)."

# Section: Monitoring & Response
# (Manual) Review event logs and configure alerts
Register-Check -Name "Monitoring & Response" -Status WARN -Message "Review event logs and configure alerts (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Superuser account and user privileges (Authentication & Authorization section)"
Write-Output " - Network exposure and firewall rules (Network Security section)"
Write-Output " - SSL/TLS and encryption settings (Encryption section)"
Write-Output " - Audit log configuration and retention (Auditing & Logging section)"
Write-Output " - Patch management and version (Patch Management section)"
Write-Output " - Backup folder permissions and encryption (Backup Security section)"
Write-Output " - Secure configuration in postgresql.conf and pg_hba.conf (Configuration Hardening section)"
Write-Output " - Password policy and account lockout (Security Policies section)"
Write-Output " - Event logs and alerting (Monitoring & Response section)"
Write-Output ""
Write-Output "Refer to CIS PostgreSQL Benchmark and PostgreSQL Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
