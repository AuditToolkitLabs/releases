# SQL Server Security Audit Script (PowerShell)
# Integrates with common audit framework for consistent reporting
Import-Module "$PSScriptRoot/../../common/common-audit.psm1"
# Based on CIS Benchmarks & Microsoft Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft SQL Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_sql_server
# - Microsoft SQL Security Best Practices: https://learn.microsoft.com/en-us/sql/sql-server/
# - MySQL CIS Benchmark: https://www.cisecurity.org/benchmark/mysql
# - PostgreSQL CIS Benchmark: https://www.cisecurity.org/benchmark/postgresql

# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check below is annotated in comments with relevant compliance mappings.

<#+
    This script checks:
    - Service/account hardening
    - Authentication & authorization
    - Network security
    - Encryption
    - Auditing & logging
    - Patch management
    - Backup security
    - Configuration hardening
    - Security policies
    - Monitoring & response
#>

# Set strict mode
Set-StrictMode -Version Latest

# Section: Service & Account Hardening
Write-Output "[SECTION] Service & Account Hardening"
$service = Get-Service -Name 'MSSQL*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $service) {
    Register-Check -Name "SQL Server Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "SQL Server Service" -Status PASS -Message "Service running: $($service.Name)"
$svcAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='$($service.Name)'").StartName
if ($svcAccount -notmatch 'LocalSystem|Administrator') {
    Register-Check -Name "Service Account" -Status PASS -Message "Least-privilege account: $svcAccount"
} else {
    Register-Check -Name "Service Account" -Status FAIL -Message "High-privilege account: $svcAccount"
}

# Section: Authentication & Authorization
Write-Output "[SECTION] Authentication & Authorization"
# Check if 'sa' account is disabled (SQL query)
$sql = "SELECT name, is_disabled FROM sys.sql_logins WHERE name = 'sa';"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    if ($result.is_disabled -eq 1) {
        Register-Check -Name "'sa' Account" -Status PASS -Message "'sa' account is disabled."
    } else {
        Register-Check -Name "'sa' Account" -Status FAIL -Message "'sa' account is enabled."
    }
} catch {
    Register-Check -Name "'sa' Account" -Status WARN -Message "Could not query 'sa' account status. Ensure Invoke-Sqlcmd is available."
}

# Section: Network Security
Write-Output "[SECTION] Network Security"
# Check TCP/IP protocol status (SQL query)
$sql = "EXEC xp_readerrorlog 0, 1, 'Server is listening on';"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    $result | ForEach-Object { Register-Check -Name "Network Listener" -Status WARN -Message "Review: $_" }
} catch {
    Register-Check -Name "Network Listener" -Status WARN -Message "Could not check network listeners."
}

# Section: Encryption
Write-Output "[SECTION] Encryption"
# Check if TDE is enabled (SQL query)
$sql = "SELECT db.name, dm.encryption_state FROM sys.databases db LEFT JOIN sys.dm_database_encryption_keys dm ON db.database_id = dm.database_id;"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    foreach ($row in $result) {
        if ($row.encryption_state -eq 3) {
            Register-Check -Name "TDE Encryption ($($row.name))" -Status PASS -Message "TDE enabled"
        } else {
            Register-Check -Name "TDE Encryption ($($row.name))" -Status WARN -Message "TDE not enabled"
        }
    }
} catch {
    Register-Check -Name "TDE Encryption" -Status WARN -Message "Could not check TDE status."
}

# Section: Auditing & Logging
Write-Output "[SECTION] Auditing & Logging"
# Check if SQL Server Audit is enabled (SQL query)
$sql = "SELECT name, is_state_enabled FROM sys.server_audits;"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    foreach ($row in $result) {
        if ($row.is_state_enabled -eq 1) {
            Register-Check -Name "Audit ($($row.name))" -Status PASS -Message "Audit enabled"
        } else {
            Register-Check -Name "Audit ($($row.name))" -Status FAIL -Message "Audit disabled"
        }
    }
} catch {
    Register-Check -Name "Audit" -Status WARN -Message "Could not check audit status."
}

# Section: Patch Management
Write-Output "[SECTION] Patch Management"
# Check SQL Server version
$sql = "SELECT SERVERPROPERTY('ProductVersion') AS Version, SERVERPROPERTY('ProductLevel') AS Level, SERVERPROPERTY('Edition') AS Edition;"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    Register-Check -Name "SQL Server Version" -Status WARN -Message "Version: $($result.Version) $($result.Level) $($result.Edition) - verify patch level"
} catch {
    Register-Check -Name "SQL Server Version" -Status WARN -Message "Could not retrieve SQL Server version."
}

# Section: Backup Security
Write-Output "[SECTION] Backup Security"
# (Manual) Check backup folder permissions and encryption settings
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions and ensure backup encryption is enabled (manual)."

# Section: Configuration Hardening
Write-Output "[SECTION] Configuration Hardening"
# Check for dangerous features (xp_cmdshell)
$sql = "EXEC sp_configure 'show advanced options', 1; RECONFIGURE; EXEC sp_configure 'xp_cmdshell';"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    if ($result.config_value -eq 0) {
        Register-Check -Name "xp_cmdshell" -Status PASS -Message "xp_cmdshell is disabled."
    } else {
        Register-Check -Name "xp_cmdshell" -Status FAIL -Message "xp_cmdshell is enabled."
    }
} catch {
    Register-Check -Name "xp_cmdshell" -Status WARN -Message "Could not check xp_cmdshell status."
}

# Section: Security Policies
Write-Output "[SECTION] Security Policies"
# Check password policy enforcement (SQL query)
$sql = "SELECT name, is_policy_checked FROM sys.sql_logins WHERE is_disabled = 0;"
try {
    $result = Invoke-Sqlcmd -Query $sql -ServerInstance 'localhost' -ErrorAction Stop
    foreach ($row in $result) {
        if ($row.is_policy_checked -eq 1) {
            Register-Check -Name "Password Policy ($($row.name))" -Status PASS -Message "Password policy enforced"
        } else {
            Register-Check -Name "Password Policy ($($row.name))" -Status FAIL -Message "Password policy NOT enforced"
        }
    }
} catch {
    Register-Check -Name "Password Policy" -Status WARN -Message "Could not check password policy enforcement."
}

# Section: Monitoring & Response
Write-Output "[SECTION] Monitoring & Response"
# (Manual) Review event logs and configure alerts for failed logins, privilege changes, etc.
Register-Check -Name "Monitoring & Response" -Status WARN -Message "Review Windows Event Logs and SQL Server Agent Alerts (manual)."

# MySQL/PostgreSQL/MariaDB: See CIS Benchmarks for equivalent SQL queries.
# Example MySQL: SELECT user, host, plugin FROM mysql.user WHERE user = 'root';
# Example PostgreSQL: SELECT usename, usesuper FROM pg_user WHERE usename = 'postgres';

# [SECTION] Manual Checks & Guidance
Write-Output "[SUMMARY] Review all sections above for PASS/FAIL/WARN/INFO."
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Backup folder permissions and backup encryption settings (Backup Security section)"
Write-Output " - Windows Event Logs and SQL Server Agent Alerts for suspicious activity (Monitoring & Response section)"
Write-Output " - Review password complexity, account lockout, and least privilege assignments (Security Policies section)"
Write-Output " - Inspect user roles, orphaned accounts, and unused logins (Authentication & Authorization section)"
Write-Output " - Confirm network firewall rules and port exposure (Network Security section)"
Write-Output " - Validate encryption for sensitive columns and data-at-rest (Encryption section)"
Write-Output " - Review audit logs for anomalies and compliance (Auditing & Logging section)"
Write-Output ""
Write-Output "Refer to CIS SQL Server Benchmark and Microsoft Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
