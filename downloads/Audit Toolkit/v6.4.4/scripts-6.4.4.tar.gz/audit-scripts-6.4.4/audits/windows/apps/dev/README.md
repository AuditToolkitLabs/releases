# Windows Development Tools Security Audits

Security audits for development tools and environments on Windows systems.

## Planned Audits

### Docker Desktop
**File**: `docker_desktop.ps1`

**Checks**:
- [ ] Docker Desktop service running (`com.docker.service`)
- [ ] WSL2 backend vs Hyper-V backend
- [ ] Docker daemon configuration (`daemon.json`)
- [ ] TLS for Docker socket
- [ ] Experimental features disabled
- [ ] Privileged containers warning
- [ ] Default network isolation
- [ ] Image signing verification (DCT)
- [ ] Resource limits configured

### Windows Subsystem for Linux (WSL)
**File**: `wsl_security.ps1`

**Checks**:
- [ ] WSL version (WSL2 preferred)
- [ ] Default distribution
- [ ] Interop enabled (security consideration)
- [ ] Firewall integration
- [ ] Windows Defender integration
- [ ] Network isolation mode
- [ ] Mounted Windows drives permissions
- [ ] Systemd enabled (WSL2)

### Git Configuration
**File**: `git_config.ps1`

**Checks**:
- [ ] Git installed and version
- [ ] Credential helper configured (wincred/manager-core)
- [ ] GPG signing enabled for commits
- [ ] SSH vs HTTPS authentication
- [ ] `.gitconfig` permissions
- [ ] safe.directory settings
- [ ] core.autocrlf setting
- [ ] Git Credential Manager version

---

## Usage

```powershell
# Run individual audit
.\docker_desktop.ps1

# Run all dev tool audits
Get-ChildItem *.ps1 | ForEach-Object { & $_.FullName }
```

## Dependencies

- PowerShell 5.1+
- Common audit module: `..\..\common\common-audit.psm1`

## References

- [Docker Security Best Practices](https://docs.docker.com/engine/security/)
- [WSL Security](https://docs.microsoft.com/en-us/windows/wsl/security)
- [Git Security](https://git-scm.com/book/en/v2/Git-Internals-Environment-Variables)
