<#
.SYNOPSIS
    Docker Desktop Security Audit

.DESCRIPTION
    Audits Docker Desktop configuration including:
    - Service status and daemon configuration
    - TLS/security settings for remote API
    - Content trust and image signing
    - Resource limits
    - WSL2 vs Hyper-V backend
    - Network security settings

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Docker Benchmark: Multiple controls
- NIST SP 800-53: CM-7 (Least Functionality)
- ISO 27001: A.12.6.1 (Technical Vulnerabilities)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Docker Desktop Security Audit"

# ============================================================================
# DOCKER INSTALLATION & SERVICE STATUS
# ============================================================================
Write-Section "Docker Installation Status"

$dockerInstalled = $false
$dockerPaths = @(
    "$env:ProgramFiles\Docker\Docker",
    "$env:LOCALAPPDATA\Docker\wsl"
)

foreach ($path in $dockerPaths) {
    if (Test-Path $path) {
        $dockerInstalled = $true
        Register-Check -Name "Docker Install Path" -Status PASS -Message $path
        break
    }
}

# Check Docker Desktop service
$dockerService = Get-Service -Name "com.docker.service" -ErrorAction SilentlyContinue
if ($dockerService) {
    $dockerInstalled = $true
    if ($dockerService.Status -eq "Running") {
        Register-Check -Name "Docker Desktop Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Docker Desktop Service" -Status WARN -Message "$($dockerService.Status)"
    }
} else {
    # Check for Docker Engine (non-Desktop)
    $dockerEngine = Get-Service -Name "docker" -ErrorAction SilentlyContinue
    if ($dockerEngine) {
        $dockerInstalled = $true
        if ($dockerEngine.Status -eq "Running") {
            Register-Check -Name "Docker Engine Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Docker Engine Service" -Status WARN -Message "$($dockerEngine.Status)"
        }
    }
}

if (-not $dockerInstalled) {
    Register-Check -Name "Docker Desktop" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# Check Docker version
try {
    $dockerVersion = & docker version --format '{{.Server.Version}}' 2>$null
    if ($dockerVersion) {
        Register-Check -Name "Docker Version" -Status PASS -Message "v$dockerVersion"
    }
} catch {
    Register-Check -Name "Docker Version" -Status WARN -Message "Unable to query (daemon may not be running)"
}

# ============================================================================
# DOCKER DAEMON CONFIGURATION
# ============================================================================
Write-Section "Daemon Configuration"

$daemonJsonPaths = @(
    "$env:ProgramData\Docker\config\daemon.json",
    "$env:USERPROFILE\.docker\daemon.json"
)

$daemonConfig = $null
foreach ($path in $daemonJsonPaths) {
    if (Test-Path $path) {
        try {
            $daemonConfig = Get-Content $path -Raw | ConvertFrom-Json
            Register-Check -Name "Daemon Config File" -Status PASS -Message $path
            break
        } catch {
            Register-Check -Name "Daemon Config File" -Status WARN -Message "Found but invalid JSON"
        }
    }
}

if ($daemonConfig) {
    # Check TLS settings
    if ($daemonConfig.tls -eq $true -or $daemonConfig.tlsverify -eq $true) {
        Register-Check -Name "TLS Enabled" -Status PASS -Message "Remote API secured with TLS"
    } else {
        Register-Check -Name "TLS Enabled" -Status WARN -Message "TLS not explicitly enabled"
    }

    # Check for exposed TCP socket
    if ($daemonConfig.hosts) {
        $tcpHosts = $daemonConfig.hosts | Where-Object { $_ -match '^tcp://' }
        if ($tcpHosts) {
            if ($daemonConfig.tlsverify -eq $true) {
                Register-Check -Name "TCP Socket Exposure" -Status PASS -Message "TCP enabled with TLS verification"
            } else {
                Register-Check -Name "TCP Socket Exposure" -Status FAIL -Message "TCP exposed without TLS ($tcpHosts)"
            }
        } else {
            Register-Check -Name "TCP Socket Exposure" -Status PASS -Message "No TCP socket exposed"
        }
    }

    # Check userns-remap (user namespace isolation)
    if ($daemonConfig.'userns-remap') {
        Register-Check -Name "User Namespace Remap" -Status PASS -Message "Enabled: $($daemonConfig.'userns-remap')"
    } else {
        Register-Check -Name "User Namespace Remap" -Status WARN -Message "Not configured (containers run as root)"
    }

    # Check live-restore
    if ($daemonConfig.'live-restore' -eq $true) {
        Register-Check -Name "Live Restore" -Status PASS -Message "Enabled"
    }

    # Check logging driver
    if ($daemonConfig.'log-driver') {
        Register-Check -Name "Log Driver" -Status PASS -Message $daemonConfig.'log-driver'
    }

    # Check for insecure registries
    if ($daemonConfig.'insecure-registries' -and $daemonConfig.'insecure-registries'.Count -gt 0) {
        Register-Check -Name "Insecure Registries" -Status WARN -Message "$($daemonConfig.'insecure-registries'.Count) configured"
    } else {
        Register-Check -Name "Insecure Registries" -Status PASS -Message "None configured"
    }

    # Check seccomp profile
    if ($daemonConfig.'seccomp-profile') {
        Register-Check -Name "Seccomp Profile" -Status PASS -Message "Custom profile configured"
    }
} else {
    Register-Check -Name "Daemon Config" -Status WARN -Message "No daemon.json found (using defaults)"
}

# ============================================================================
# CONTENT TRUST & IMAGE SIGNING
# ============================================================================
Write-Section "Content Trust Configuration"

# Check DOCKER_CONTENT_TRUST environment variable
$contentTrust = [Environment]::GetEnvironmentVariable("DOCKER_CONTENT_TRUST", "User")
$contentTrustMachine = [Environment]::GetEnvironmentVariable("DOCKER_CONTENT_TRUST", "Machine")

if ($contentTrust -eq "1" -or $contentTrustMachine -eq "1") {
    Register-Check -Name "Content Trust (DCT)" -Status PASS -Message "Enabled via environment variable"
} else {
    Register-Check -Name "Content Trust (DCT)" -Status WARN -Message "Not enabled (unsigned images allowed)"
}

# Check for Docker trust keys
$trustKeyPath = "$env:USERPROFILE\.docker\trust"
if (Test-Path $trustKeyPath) {
    $privateKeys = Get-ChildItem $trustKeyPath -Recurse -Filter "*.key" -ErrorAction SilentlyContinue
    if ($privateKeys) {
        Register-Check -Name "Trust Signing Keys" -Status PASS -Message "$($privateKeys.Count) key(s) present"
    } else {
        Register-Check -Name "Trust Signing Keys" -Status WARN -Message "Trust directory exists but no keys"
    }
} else {
    Register-Check -Name "Trust Signing Keys" -Status WARN -Message "No signing keys configured"
}

# ============================================================================
# BACKEND CONFIGURATION (WSL2 vs Hyper-V)
# ============================================================================
Write-Section "Backend Configuration"

# Check Docker Desktop settings
$dockerSettingsPath = "$env:APPDATA\Docker\settings.json"
if (Test-Path $dockerSettingsPath) {
    try {
        $settings = Get-Content $dockerSettingsPath -Raw | ConvertFrom-Json

        # WSL2 backend
        if ($settings.wslEngineEnabled -eq $true) {
            Register-Check -Name "Backend Type" -Status PASS -Message "WSL2 (recommended)"
        } else {
            Register-Check -Name "Backend Type" -Status PASS -Message "Hyper-V"
        }

        # Resource limits
        if ($settings.memoryMiB) {
            $memGB = [math]::Round($settings.memoryMiB / 1024, 1)
            Register-Check -Name "Memory Limit" -Status PASS -Message "${memGB}GB allocated"
        }

        if ($settings.cpus) {
            Register-Check -Name "CPU Limit" -Status PASS -Message "$($settings.cpus) CPUs allocated"
        }

        # Auto-updates
        if ($settings.autoDownloadUpdates -eq $true) {
            Register-Check -Name "Auto Updates" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Auto Updates" -Status WARN -Message "Disabled"
        }

        # Kubernetes
        if ($settings.kubernetesEnabled -eq $true) {
            Register-Check -Name "Kubernetes" -Status PASS -Message "Enabled"
        }

        # Analytics
        if ($settings.analyticsEnabled -eq $false) {
            Register-Check -Name "Analytics/Telemetry" -Status PASS -Message "Disabled"
        } else {
            Register-Check -Name "Analytics/Telemetry" -Status WARN -Message "Enabled (privacy consideration)"
        }

    } catch {
        Register-Check -Name "Docker Settings" -Status WARN -Message "Unable to parse settings.json"
    }
} else {
    Register-Check -Name "Docker Settings" -Status WARN -Message "settings.json not found"
}

# ============================================================================
# NETWORK SECURITY
# ============================================================================
Write-Section "Network Security"

# Check Docker networks
try {
    $networks = & docker network ls --format '{{.Name}}' 2>$null
    if ($networks) {
        $customNetworks = $networks | Where-Object { $_ -notin @('bridge', 'host', 'none') }
        Register-Check -Name "Docker Networks" -Status PASS -Message "$($networks.Count) network(s), $($customNetworks.Count) custom"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for containers with host network mode
try {
    $hostNetContainers = & docker ps --filter "network=host" --format '{{.Names}}' 2>$null
    if ($hostNetContainers) {
        Register-Check -Name "Host Network Mode" -Status WARN -Message "$($hostNetContainers.Count) container(s) using host network"
    } else {
        Register-Check -Name "Host Network Mode" -Status PASS -Message "No containers using host network"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for privileged containers
try {
    $runningContainers = & docker ps --format '{{.ID}}' 2>$null
    $privilegedCount = 0
    foreach ($container in $runningContainers) {
        $inspect = & docker inspect $container --format '{{.HostConfig.Privileged}}' 2>$null
        if ($inspect -eq "true") { $privilegedCount++ }
    }

    if ($privilegedCount -gt 0) {
        Register-Check -Name "Privileged Containers" -Status WARN -Message "$privilegedCount container(s) running privileged"
    } else {
        Register-Check -Name "Privileged Containers" -Status PASS -Message "None running privileged"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for root user containers
try {
    $rootContainers = 0
    foreach ($container in $runningContainers) {
        $user = & docker inspect $container --format '{{.Config.User}}' 2>$null
        if ([string]::IsNullOrEmpty($user) -or $user -eq "root" -or $user -eq "0") {
            $rootContainers++
        }
    }

    if ($rootContainers -gt 0 -and $runningContainers) {
        Register-Check -Name "Root User Containers" -Status WARN -Message "$rootContainers of $($runningContainers.Count) running as root"
    } elseif ($runningContainers) {
        Register-Check -Name "Root User Containers" -Status PASS -Message "All containers using non-root users"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check Docker socket permissions
$dockerSocket = "\\.\pipe\docker_engine"
if (Test-Path $dockerSocket) {
    Register-Check -Name "Docker Socket" -Status PASS -Message "Named pipe accessible"
}

# Check Docker group membership
try {
    $dockerGroup = Get-LocalGroup -Name "docker-users" -ErrorAction SilentlyContinue
    if ($dockerGroup) {
        $members = Get-LocalGroupMember -Group "docker-users" -ErrorAction SilentlyContinue
        Register-Check -Name "Docker Users Group" -Status PASS -Message "$($members.Count) member(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# IMAGE SECURITY
# ============================================================================
Write-Section "Image Security"

# Check for outdated images (by age)
try {
    $images = & docker images --format '{{.Repository}}:{{.Tag}} {{.CreatedSince}}' 2>$null
    $oldImages = $images | Where-Object { $_ -match '\d+ (months|years) ago' }
    if ($oldImages) {
        Register-Check -Name "Image Age" -Status WARN -Message "$($oldImages.Count) image(s) older than 1 month"
    } else {
        Register-Check -Name "Image Age" -Status PASS -Message "All images recently updated"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for dangling images
try {
    $danglingImages = & docker images -f "dangling=true" -q 2>$null
    if ($danglingImages) {
        Register-Check -Name "Dangling Images" -Status WARN -Message "$($danglingImages.Count) dangling image(s) (run 'docker image prune')"
    } else {
        Register-Check -Name "Dangling Images" -Status PASS -Message "None"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
