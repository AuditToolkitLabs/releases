<#
.SYNOPSIS
    Example: Using Enhanced Audit Framework Features

.DESCRIPTION
    Demonstrates the new common-audit.psm1 v2.0 features:
    - Compliance mapping (CIS, NIST, ISO, PCI)
    - Risk scoring
    - Remediation commands
    - JSON export for SIEM integration

.NOTES
    Run this script to see the enhanced output and JSON export.
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Import the enhanced module
Import-Module "$PSScriptRoot/../common/common-audit.psm1" -Force

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

# Initialize audit session
Initialize-Audit -ScriptName "example_enhanced_audit.ps1"

Write-Section "Enhanced Audit Framework Demo"

# Example 1: Basic check (backward compatible)
Register-Check -Name "Basic Check Example" -Status PASS -Message "Works like before"

# Example 2: Check with compliance references
Register-Check -Name "Windows Firewall Enabled" `
    -Status PASS `
    -Message "Domain, Private, Public profiles enabled" `
    -CISReference "CIS 9.1.1" `
    -NISTReference "SC-7" `
    -ISOReference "A.13.1.1"

# Example 3: Failed check with remediation
Register-Check -Name "SMBv1 Protocol" `
    -Status FAIL `
    -Message "Legacy protocol enabled - security risk" `
    -CISReference "CIS 18.3.3" `
    -NISTReference "CM-7" `
    -RiskScore 8 `
    -RemediationCommand "Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart"

# Example 4: Warning with risk score
Register-Check -Name "Guest Account Status" `
    -Status WARN `
    -Message "Account exists but disabled" `
    -CISReference "CIS 1.1.1" `
    -NISTReference "AC-6" `
    -PCIReference "8.1.6" `
    -RiskScore 3

# Example 5: Critical finding
Register-Check -Name "Antivirus Status" `
    -Status FAIL `
    -Message "No AV product detected" `
    -NISTReference "SI-3" `
    -RiskScore 10 `
    -RemediationCommand "# Install Windows Defender or third-party AV solution"

# Example 6: Check with evidence
$serviceInfo = @{
    ServiceName = "wuauserv"
    Status = "Running"
    StartType = "Automatic"
}
Register-Check -Name "Windows Update Service" `
    -Status PASS `
    -Message "Running and set to Automatic" `
    -CISReference "CIS 18.9.101" `
    -Evidence $serviceInfo

# Example 7: Skipped check
Register-Check -Name "BitLocker Status" `
    -Status SKIP `
    -Message "Not applicable - no TPM detected" `
    -CISReference "CIS 18.9.11"

# Print enhanced summary
Print-Summary

# Demonstrate helper functions
Write-Section "Failed Checks with Remediations"
$failed = Get-FailedChecks
$failed | Format-Table -AutoSize

Write-Section "Critical/High Risk Findings"
$critical = Get-ChecksByRiskLevel -Level "Critical"
$high = Get-ChecksByRiskLevel -Level "High"
Write-Output "Critical: $($critical.Count), High: $($high.Count)"

Write-Section "Auto-Generated Remediation Script"
$remediationScript = Get-RemediationScript
Write-Output $remediationScript

# Export to JSON (to console for demo)
Write-Section "JSON Export Preview"
$json = Export-AuditJSON
Write-Output ($json | ConvertFrom-Json | ConvertTo-Json -Depth 3)

# Optionally save to file
# Export-AuditJSON -FilePath "C:\Reports\audit-results.json"

Write-Output ""
Write-Output "Demo complete. See common-audit.psm1 for full documentation."

Exit-Audit
