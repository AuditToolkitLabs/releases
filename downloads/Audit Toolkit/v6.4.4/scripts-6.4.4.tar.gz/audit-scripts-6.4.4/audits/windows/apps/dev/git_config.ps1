<#
.SYNOPSIS
    Git Configuration Security Audit

.DESCRIPTION
    Audits Git configuration including:
    - Credential helper security
    - GPG signing configuration
    - Safe directory settings
    - Proxy configuration (secrets exposure)
    - Global .gitignore for secrets
    - Hook directory permissions
    - SSH vs HTTPS preferences

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 16.4 (Encrypt Sensitive Data)
- NIST SP 800-53: IA-5 (Authenticator Management)
- ISO 27001: A.9.4.3 (Password Management)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Git Configuration Security Audit"

# ============================================================================
# GIT INSTALLATION STATUS
# ============================================================================
Write-Section "Git Installation Status"

$gitInstalled = $false
$gitPath = $null

# Check for Git in PATH
try {
    $gitVersion = & git --version 2>$null
    if ($gitVersion) {
        $gitInstalled = $true
        Register-Check -Name "Git Installation" -Status PASS -Message ($gitVersion -replace 'git version ', 'v')

        $gitPath = (Get-Command git -ErrorAction SilentlyContinue).Source
        if ($gitPath) {
            Register-Check -Name "Git Path" -Status PASS -Message $gitPath
        }
    }
} catch {
    Register-Check -Name "Git Installation" -Status SKIP -Message "Git not found in PATH"
    Print-Summary
    Exit-Audit
}

if (-not $gitInstalled) {
    Register-Check -Name "Git" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# CREDENTIAL HELPER CONFIGURATION
# ============================================================================
Write-Section "Credential Helper"

try {
    $credHelper = & git config --global credential.helper 2>$null
    if ($credHelper) {
        switch -Regex ($credHelper) {
            'manager-core|manager' {
                Register-Check -Name "Credential Helper" -Status PASS -Message "Git Credential Manager (secure)"
            }
            'wincred' {
                Register-Check -Name "Credential Helper" -Status PASS -Message "Windows Credential Manager"
            }
            'store' {
                Register-Check -Name "Credential Helper" -Status FAIL -Message "'store' helper saves credentials in PLAIN TEXT"
            }
            'cache' {
                & git config --global credential.helper 2>$null | Out-Null
                Register-Check -Name "Credential Helper" -Status WARN -Message "cache helper (credentials in memory, use manager-core instead)"
            }
            default {
                Register-Check -Name "Credential Helper" -Status WARN -Message $credHelper
            }
        }
    } else {
        Register-Check -Name "Credential Helper" -Status WARN -Message "Not configured (will prompt each time)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for plaintext credential file
$credStorePath = "$env:USERPROFILE\.git-credentials"
if (Test-Path $credStorePath) {
    Register-Check -Name "Plaintext Credentials" -Status FAIL -Message ".git-credentials file exists (contains plaintext passwords)"

    # Check file permissions
    $acl = Get-Acl $credStorePath -ErrorAction SilentlyContinue
    $everyoneAccess = $acl.Access | Where-Object { $_.IdentityReference -match "Everyone|Users" }
    if ($everyoneAccess) {
        Register-Check -Name "Credential File Permissions" -Status FAIL -Message "Accessible by other users"
    }
} else {
    Register-Check -Name "Plaintext Credentials" -Status PASS -Message "No .git-credentials file"
}

# ============================================================================
# GPG SIGNING CONFIGURATION
# ============================================================================
Write-Section "Commit Signing"

try {
    $gpgSign = & git config --global commit.gpgsign 2>$null
    if ($gpgSign -eq "true") {
        Register-Check -Name "GPG Commit Signing" -Status PASS -Message "Enabled globally"

        # Check for signing key
        $signingKey = & git config --global user.signingkey 2>$null
        if ($signingKey) {
            Register-Check -Name "GPG Signing Key" -Status PASS -Message "Configured ($($signingKey.Substring(0, [Math]::Min(8, $signingKey.Length)))...)"
        } else {
            Register-Check -Name "GPG Signing Key" -Status WARN -Message "No default signing key configured"
        }

        # Check GPG program
        $gpgProgram = & git config --global gpg.program 2>$null
        if ($gpgProgram) {
            Register-Check -Name "GPG Program" -Status PASS -Message $gpgProgram
        }
    } else {
        Register-Check -Name "GPG Commit Signing" -Status WARN -Message "Not enabled (commits not cryptographically verified)"
    }

    # Check for tag signing
    $tagSign = & git config --global tag.gpgsign 2>$null
    if ($tagSign -eq "true") {
        Register-Check -Name "GPG Tag Signing" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# SSH signing (Git 2.34+)
try {
    $gpgFormat = & git config --global gpg.format 2>$null
    if ($gpgFormat -eq "ssh") {
        Register-Check -Name "Signing Format" -Status PASS -Message "SSH key signing"

        $sshSigningKey = & git config --global user.signingkey 2>$null
        if ($sshSigningKey) {
            Register-Check -Name "SSH Signing Key" -Status PASS -Message "Configured"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SAFE DIRECTORY SETTINGS
# ============================================================================
Write-Section "Safe Directory Configuration"

try {
    $safeDirs = & git config --global --get-all safe.directory 2>$null
    if ($safeDirs) {
        $dirCount = ($safeDirs | Measure-Object).Count
        if ($safeDirs -contains '*') {
            Register-Check -Name "Safe Directory" -Status WARN -Message "'*' wildcard configured (allows any directory)"
        } else {
            Register-Check -Name "Safe Directories" -Status PASS -Message "$dirCount directory(ies) explicitly allowed"
        }
    } else {
        Register-Check -Name "Safe Directory" -Status PASS -Message "Default restrictions (owned directories only)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# PROXY CONFIGURATION
# ============================================================================
Write-Section "Proxy Configuration"

try {
    $httpProxy = & git config --global http.proxy 2>$null
    $httpsProxy = & git config --global https.proxy 2>$null

    if ($httpProxy) {
        if ($httpProxy -match '://[^:]+:[^@]+@') {
            Register-Check -Name "HTTP Proxy" -Status FAIL -Message "Credentials embedded in proxy URL"
        } else {
            Register-Check -Name "HTTP Proxy" -Status PASS -Message "Configured (no embedded credentials)"
        }
    }

    if ($httpsProxy) {
        if ($httpsProxy -match '://[^:]+:[^@]+@') {
            Register-Check -Name "HTTPS Proxy" -Status FAIL -Message "Credentials embedded in proxy URL"
        } else {
            Register-Check -Name "HTTPS Proxy" -Status PASS -Message "Configured (no embedded credentials)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SSL/TLS CONFIGURATION
# ============================================================================
Write-Section "SSL/TLS Configuration"

try {
    $sslVerify = & git config --global http.sslVerify 2>$null
    if ($sslVerify -eq "false") {
        Register-Check -Name "SSL Verification" -Status FAIL -Message "DISABLED globally (MitM risk)"
    } else {
        Register-Check -Name "SSL Verification" -Status PASS -Message "Enabled (default)"
    }

    # Check for custom CA bundle
    $sslCAInfo = & git config --global http.sslCAInfo 2>$null
    if ($sslCAInfo) {
        if (Test-Path $sslCAInfo) {
            Register-Check -Name "Custom CA Bundle" -Status PASS -Message "Configured: $sslCAInfo"
        } else {
            Register-Check -Name "Custom CA Bundle" -Status WARN -Message "Configured but file not found"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# GITIGNORE CONFIGURATION
# ============================================================================
Write-Section "Global Gitignore"

try {
    $globalIgnore = & git config --global core.excludesfile 2>$null
    if ($globalIgnore) {
        if (Test-Path $globalIgnore) {
            $ignoreContent = Get-Content $globalIgnore -Raw -ErrorAction SilentlyContinue

            # Check for common secret patterns
            $secretPatterns = @('.env', '*.pem', '*.key', '.aws', 'credentials', 'secrets', '*.p12', '*.pfx')
            $foundPatterns = @()
            foreach ($pattern in $secretPatterns) {
                if ($ignoreContent -match [regex]::Escape($pattern)) {
                    $foundPatterns += $pattern
                }
            }

            if ($foundPatterns.Count -gt 0) {
                Register-Check -Name "Global Gitignore" -Status PASS -Message "Excludes secret patterns ($($foundPatterns.Count) patterns)"
            } else {
                Register-Check -Name "Global Gitignore" -Status WARN -Message "Exists but may not exclude secret files"
            }
        } else {
            Register-Check -Name "Global Gitignore" -Status WARN -Message "Configured but file not found"
        }
    } else {
        Register-Check -Name "Global Gitignore" -Status WARN -Message "Not configured (recommend excluding .env, *.key, etc.)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# HOOKS CONFIGURATION
# ============================================================================
Write-Section "Git Hooks"

try {
    # Check global hooks path
    $hooksPath = & git config --global core.hooksPath 2>$null
    if ($hooksPath) {
        if (Test-Path $hooksPath) {
            $hooks = Get-ChildItem $hooksPath -File -ErrorAction SilentlyContinue
            Register-Check -Name "Global Hooks Path" -Status PASS -Message "$($hooks.Count) hook(s) in $hooksPath"

            # Check hooks permissions
            $hookAcl = Get-Acl $hooksPath -ErrorAction SilentlyContinue
            $broadAccess = $hookAcl.Access | Where-Object {
                $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "Write|Modify"
            }
            if ($broadAccess) {
                Register-Check -Name "Hooks Directory Permissions" -Status WARN -Message "Writable by non-admins"
            } else {
                Register-Check -Name "Hooks Directory Permissions" -Status PASS -Message "Restricted"
            }
        } else {
            Register-Check -Name "Global Hooks Path" -Status WARN -Message "Configured but directory not found"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# USER CONFIGURATION
# ============================================================================
Write-Section "User Configuration"

try {
    $userName = & git config --global user.name 2>$null
    $userEmail = & git config --global user.email 2>$null

    if ($userName) {
        Register-Check -Name "User Name" -Status PASS -Message $userName
    } else {
        Register-Check -Name "User Name" -Status WARN -Message "Not configured globally"
    }

    if ($userEmail) {
        # Check for personal email in corporate context
        if ($userEmail -match '@gmail\.com|@outlook\.com|@hotmail\.com|@yahoo\.com') {
            Register-Check -Name "User Email" -Status WARN -Message "$userEmail (personal email)"
        } else {
            Register-Check -Name "User Email" -Status PASS -Message $userEmail
        }
    } else {
        Register-Check -Name "User Email" -Status WARN -Message "Not configured globally"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# PROTOCOL PREFERENCES
# ============================================================================
Write-Section "Protocol Configuration"

try {
    # Check URL rewrites (e.g., SSH instead of HTTPS)
    $urlRewrites = & git config --global --get-regexp 'url\..*\.insteadOf' 2>$null
    if ($urlRewrites) {
        $rewriteCount = ($urlRewrites | Measure-Object).Count
        Register-Check -Name "URL Rewrites" -Status PASS -Message "$rewriteCount rewrite rule(s) configured"
    }

    # Check protocol version
    $protocolVersion = & git config --global protocol.version 2>$null
    if ($protocolVersion) {
        Register-Check -Name "Protocol Version" -Status PASS -Message "v$protocolVersion"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for fsmonitor (can execute arbitrary code)
try {
    $fsmonitor = & git config --global core.fsmonitor 2>$null
    if ($fsmonitor) {
        Register-Check -Name "FS Monitor" -Status WARN -Message "Custom fsmonitor configured (verify it's trusted)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for transfer.fsckObjects (integrity verification)
try {
    $fsckObjects = & git config --global transfer.fsckObjects 2>$null
    if ($fsckObjects -eq "true") {
        Register-Check -Name "Transfer Integrity Check" -Status PASS -Message "fsckObjects enabled"
    } else {
        Register-Check -Name "Transfer Integrity Check" -Status WARN -Message "fsckObjects not enabled"
    }

    $fetchFsck = & git config --global fetch.fsckObjects 2>$null
    $receiveFsck = & git config --global receive.fsckObjects 2>$null
    if ($fetchFsck -eq "true" -or $receiveFsck -eq "true") {
        Register-Check -Name "Fetch/Receive Integrity" -Status PASS -Message "Object verification enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for init.defaultBranch
try {
    $defaultBranch = & git config --global init.defaultBranch 2>$null
    if ($defaultBranch) {
        Register-Check -Name "Default Branch" -Status PASS -Message $defaultBranch
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
