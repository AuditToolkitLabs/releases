<#
.SYNOPSIS
    Java Runtime Security Audit

.DESCRIPTION
    Security audit for Java Runtime Environment (JRE/JDK):
    - Installation and version
    - Multiple Java versions
    - Security settings
    - Certificate store
    - Update configuration
    - java.security settings

.NOTES
    @elevation: partial
    @elevation-reason: HKLM JavaSoft keys and system deployment config require admin; java.security files in Program Files are readable
    Requires: Java JRE or JDK installed

Compliance Mapping:
- CIS Controls: 7.1 (Endpoint Configuration), 7.3 (Perform Updates)
- NIST SP 800-53: SI-2 (Flaw Remediation), CM-6 (Configuration Settings)
- Oracle Java SE Security Guidelines
- MITRE ATT&CK: T1059.007 (JavaScript), T1203 (Exploitation for Client Execution)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Java Runtime Security Audit"

# ============================================================================
# JAVA INSTALLATION CHECK
# ============================================================================
Write-Section "Java Installation"

$javaInstalled = $false
$javaVersions = @()

# Check common installation paths
$javaPaths = @(
    "${env:ProgramFiles}\Java",
    "${env:ProgramFiles(x86)}\Java",
    "${env:ProgramFiles}\Eclipse Adoptium",
    "${env:ProgramFiles}\AdoptOpenJDK",
    "${env:ProgramFiles}\Microsoft\jdk*",
    "${env:ProgramFiles}\Amazon Corretto",
    "${env:ProgramFiles}\Zulu"
)

foreach ($basePath in $javaPaths) {
    if (Test-Path $basePath) {
        $jreJdkDirs = Get-ChildItem -Path $basePath -Directory -ErrorAction SilentlyContinue
        foreach ($dir in $jreJdkDirs) {
            $javaExe = Join-Path $dir.FullName "bin\java.exe"
            if (Test-Path $javaExe) {
                $javaInstalled = $true
                try {
                    $verOutput = & $javaExe -version 2>&1 | Out-String
                    if ($verOutput -match '"(\d+\.\d+[^"]*)"' -or $verOutput -match '(\d+\.\d+\.\d+)') {
                        $version = $Matches[1]
                        $javaVersions += [PSCustomObject]@{
                            Path = $dir.FullName
                            Version = $version
                            Type = if ($dir.Name -match "jdk") { "JDK" } else { "JRE" }
                        }
                    }
                } catch { Write-Verbose 'Suppressed non-fatal error.' }
            }
        }
    }
}

# Also check JAVA_HOME
if ($env:JAVA_HOME -and (Test-Path $env:JAVA_HOME)) {
    $javaInstalled = $true
}

# Check registry for Java
$javaRegPaths = @(
    "HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment",
    "HKLM:\SOFTWARE\JavaSoft\Java Development Kit",
    "HKLM:\SOFTWARE\JavaSoft\JRE",
    "HKLM:\SOFTWARE\JavaSoft\JDK",
    "HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment"
)

foreach ($regPath in $javaRegPaths) {
    if (Test-Path $regPath) {
        $javaInstalled = $true
        try {
            $currentVersion = Get-ItemProperty -Path $regPath -Name "CurrentVersion" -ErrorAction SilentlyContinue
            if ($currentVersion) {
                $verPath = Join-Path $regPath $currentVersion.CurrentVersion
                if (Test-Path $verPath) {
                    $javaHome = Get-ItemProperty -Path $verPath -Name "JavaHome" -ErrorAction SilentlyContinue
                    if ($javaHome) {
                        $javaVersions += [PSCustomObject]@{
                            Path = $javaHome.JavaHome
                            Version = $currentVersion.CurrentVersion
                            Type = if ($regPath -match "JDK|Development") { "JDK" } else { "JRE" }
                        }
                    }
                }
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# Deduplicate
$javaVersions = $javaVersions | Sort-Object Path -Unique

if ($javaInstalled -and $javaVersions.Count -gt 0) {
    Register-Check -Name "Java Installation" -Status PASS -Message "Found"

    foreach ($java in $javaVersions) {
        Register-Check -Name "Java $($java.Type)" -Status INFO -Message "v$($java.Version) at $($java.Path)"
    }

    # Multiple versions warning
    if ($javaVersions.Count -gt 1) {
        Register-Check -Name "Multiple Java Versions" -Status WARN -Message "$($javaVersions.Count) versions - consider consolidating"
    }

    # Version currency check
    foreach ($java in $javaVersions) {
        $majorVer = [int]($java.Version -split '[\._]')[0]
        if ($majorVer -eq 1) {
            # Legacy versioning (1.8 = Java 8)
            $majorVer = [int]($java.Version -split '[\._]')[1]
        }

        if ($majorVer -ge 17) {
            Register-Check -Name "Version Currency ($majorVer)" -Status PASS -Message "LTS version (17+)"
        } elseif ($majorVer -ge 11) {
            Register-Check -Name "Version Currency ($majorVer)" -Status INFO -Message "LTS version but consider Java 17+"
        } elseif ($majorVer -eq 8) {
            Register-Check -Name "Version Currency ($majorVer)" -Status WARN -Message "Java 8 - still supported but aging"
        } else {
            Register-Check -Name "Version Currency ($majorVer)" -Status FAIL -Message "Unsupported version"
        }
    }
} elseif ($javaInstalled) {
    Register-Check -Name "Java Installation" -Status PASS -Message "Found (version unknown)"
} else {
    Register-Check -Name "Java Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# JAVA ENVIRONMENT
# ============================================================================
Write-Section "Java Environment"

# JAVA_HOME
if ($env:JAVA_HOME) {
    if (Test-Path $env:JAVA_HOME) {
        Register-Check -Name "JAVA_HOME" -Status PASS -Message $env:JAVA_HOME
    } else {
        Register-Check -Name "JAVA_HOME" -Status WARN -Message "Set but path invalid"
    }
} else {
    Register-Check -Name "JAVA_HOME" -Status INFO -Message "Not set"
}

# Java in PATH
$javaInPath = Get-Command "java.exe" -ErrorAction SilentlyContinue
if ($javaInPath) {
    Register-Check -Name "Java in PATH" -Status INFO -Message $javaInPath.Source
} else {
    Register-Check -Name "Java in PATH" -Status INFO -Message "Not in PATH"
}

# ============================================================================
# JAVA SECURITY SETTINGS
# ============================================================================
Write-Section "Security Settings"

# Find java.security file
$securityFiles = @()
foreach ($java in $javaVersions) {
    $secFile = Join-Path $java.Path "lib\security\java.security"
    if (-not (Test-Path $secFile)) {
        $secFile = Join-Path $java.Path "conf\security\java.security"
    }
    if (Test-Path $secFile) {
        $securityFiles += $secFile
    }
}

foreach ($secFile in $securityFiles) {
    Register-Check -Name "Security Config" -Status INFO -Message $secFile

    try {
        $secContent = Get-Content $secFile -Raw -ErrorAction SilentlyContinue

        # Check disabled algorithms
        if ($secContent -match "jdk\.tls\.disabledAlgorithms=(.+?)(?=\r?\n[a-z])") {
            $disabledAlgs = $Matches[1]
            if ($disabledAlgs -match "SSLv3" -and $disabledAlgs -match "TLSv1\.0|TLSv1,") {
                Register-Check -Name "Disabled TLS Versions" -Status PASS -Message "SSLv3, TLSv1.0 disabled"
            } else {
                Register-Check -Name "Disabled TLS Versions" -Status WARN -Message "Review disabled algorithms"
            }
        }

        # Check certificate validation
        if ($secContent -match "jdk\.certpath\.disabledAlgorithms=(.+?)(?=\r?\n[a-z])") {
            Register-Check -Name "Cert Path Algorithms" -Status INFO -Message "Configured"
        }

        # Check for security manager deprecation (Java 17+)
        if ($secContent -match "security\.manager") {
            Register-Check -Name "Security Manager" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# JAVA DEPLOYMENT SETTINGS
# ============================================================================
Write-Section "Deployment Settings"

$deploymentConfig = "${env:USERPROFILE}\AppData\LocalLow\Sun\Java\Deployment\deployment.config"
$deploymentProps = "${env:USERPROFILE}\AppData\LocalLow\Sun\Java\Deployment\deployment.properties"

$systemDeployConfig = "${env:WINDIR}\Sun\Java\Deployment\deployment.config"
$systemDeployProps = "${env:WINDIR}\Sun\Java\Deployment\deployment.properties"

# Check system-wide config first
if (Test-Path $systemDeployConfig) {
    Register-Check -Name "System Deployment Config" -Status PASS -Message "Centrally managed"
}

if (Test-Path $systemDeployProps) {
    Register-Check -Name "System Deployment Props" -Status INFO -Message "System-wide properties configured"
}

if (Test-Path $deploymentConfig) {
    Register-Check -Name "User Deployment Config" -Status INFO -Message "User config present"
}

if (Test-Path $deploymentProps) {
    Register-Check -Name "User Deployment Props" -Status INFO -Message "Present"

    try {
        $deployContent = Get-Content $deploymentProps -Raw -ErrorAction SilentlyContinue

        # Security level
        if ($deployContent -match "deployment\.security\.level=([A-Z]+)") {
            $secLevel = $Matches[1]
            if ($secLevel -eq "VERY_HIGH" -or $secLevel -eq "HIGH") {
                Register-Check -Name "Security Level" -Status PASS -Message $secLevel
            } else {
                Register-Check -Name "Security Level" -Status WARN -Message $secLevel
            }
        }

        # Mixed code
        if ($deployContent -match "deployment\.security\.mixcode=([A-Z_]+)") {
            $mixCode = $Matches[1]
            Register-Check -Name "Mixed Code" -Status INFO -Message $mixCode
        }

        # Trusted certificates
        if ($deployContent -match "deployment\.security\.askgrantdialog\.notinca=false") {
            Register-Check -Name "Non-CA Certs" -Status WARN -Message "May allow untrusted"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# JAVA UPDATE CONFIGURATION
# ============================================================================
Write-Section "Update Configuration"

$javaUpdateRegPath = "HKLM:\SOFTWARE\JavaSoft\Java Update\Policy"
$javaUpdateRegPathWow = "HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Update\Policy"

$updatePath = if (Test-Path $javaUpdateRegPath) { $javaUpdateRegPath }
              elseif (Test-Path $javaUpdateRegPathWow) { $javaUpdateRegPathWow }
              else { $null }

if ($updatePath) {
    try {
        $updatePolicy = Get-ItemProperty -Path $updatePath -ErrorAction SilentlyContinue

        # Auto-update
        if ($updatePolicy.EnableJavaUpdate -eq 1) {
            Register-Check -Name "Auto-Update" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Auto-Update" -Status WARN -Message "Disabled"
        }

        # Notify for update
        if ($updatePolicy.NotifyDownload -eq 1) {
            Register-Check -Name "Update Notification" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "Java Update Policy" -Status INFO -Message "Not configured (may be using alternative distro)"
}

# ============================================================================
# JAVA CERTIFICATE STORE
# ============================================================================
Write-Section "Certificate Store"

foreach ($java in $javaVersions) {
    $cacertsPath = Join-Path $java.Path "lib\security\cacerts"
    if (-not (Test-Path $cacertsPath)) {
        $cacertsPath = Join-Path $java.Path "lib\security\cacerts"
    }

    if (Test-Path $cacertsPath) {
        Register-Check -Name "CA Certs Store" -Status INFO -Message "Present at $cacertsPath"

        # Check cacerts age
        $cacertsAge = ((Get-Date) - (Get-Item $cacertsPath).LastWriteTime).Days
        if ($cacertsAge -gt 365) {
            Register-Check -Name "CA Certs Age" -Status WARN -Message "$cacertsAge days since update"
        } else {
            Register-Check -Name "CA Certs Age" -Status INFO -Message "Updated $cacertsAge days ago"
        }
    }
}

# ============================================================================
# JAVA WEB START
# ============================================================================
Write-Section "Java Web Start (Deprecated)"

# Java Web Start removed in Java 11+
$javawsPath = $null
foreach ($java in $javaVersions) {
    $ws = Join-Path $java.Path "bin\javaws.exe"
    if (Test-Path $ws) {
        $javawsPath = $ws
        break
    }
}

if ($javawsPath) {
    Register-Check -Name "Java Web Start" -Status WARN -Message "Present (deprecated/removed in Java 11+)"
} else {
    Register-Check -Name "Java Web Start" -Status PASS -Message "Not present (expected for Java 11+)"
}

# ============================================================================
# ENTERPRISE DEPLOYMENT
# ============================================================================
Write-Section "Enterprise Configuration"

# Check for enterprise deployment rule set
$deploymentRuleSet = "${env:WINDIR}\Sun\Java\Deployment\DeploymentRuleSet.jar"
if (Test-Path $deploymentRuleSet) {
    Register-Check -Name "Deployment Rule Set" -Status PASS -Message "Enterprise rules configured"
} else {
    Register-Check -Name "Deployment Rule Set" -Status INFO -Message "Not configured"
}

# Exception site list
$exceptionSites = "${env:USERPROFILE}\AppData\LocalLow\Sun\Java\Deployment\security\exception.sites"
if (Test-Path $exceptionSites) {
    try {
        $sites = Get-Content $exceptionSites -ErrorAction SilentlyContinue
        Register-Check -Name "Exception Sites" -Status WARN -Message "$($sites.Count) site(s) allowed"
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

Register-Check -Name "Recommendation" -Status INFO -Message "Use Java 17 LTS or newer for new projects"
Register-Check -Name "Recommendation" -Status INFO -Message "Disable Java browser plugin if not needed"
Register-Check -Name "Recommendation" -Status INFO -Message "Keep cacerts updated with trusted CAs"
Register-Check -Name "Recommendation" -Status INFO -Message "Consider using a commercial Java distribution with support"

Print-Summary
Exit-Audit
