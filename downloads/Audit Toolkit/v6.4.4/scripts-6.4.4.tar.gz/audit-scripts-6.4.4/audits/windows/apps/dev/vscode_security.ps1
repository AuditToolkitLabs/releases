<#
.SYNOPSIS
    Visual Studio Code Security Audit

.DESCRIPTION
    Audits VS Code configuration including:
    - Installation and version
    - Extension security (known malicious)
    - Remote/SSH tunnel settings
    - Workspace trust configuration
    - Telemetry settings
    - Auto-update status
    - Security-relevant settings

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 2.7 (Allowlist Authorized Software)
- NIST SP 800-53: CM-11 (User-Installed Software)
- ISO 27001: A.12.6.1 (Technical Vulnerabilities)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Visual Studio Code Security Audit"

# ============================================================================
# VS CODE INSTALLATION STATUS
# ============================================================================
Write-Section "VS Code Installation Status"

$vscodeInstalled = $false
$vscodePath = $null
$vscodeVersion = $null

# Check common installation paths
$vscodePaths = @(
    "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe",
    "$env:ProgramFiles\Microsoft VS Code\Code.exe",
    "$env:ProgramFiles(x86)\Microsoft VS Code\Code.exe"
)

foreach ($path in $vscodePaths) {
    if (Test-Path $path) {
        $vscodeInstalled = $true
        $vscodePath = $path
        $vscodeVersion = (Get-Item $path).VersionInfo.ProductVersion
        Register-Check -Name "VS Code Installation" -Status PASS -Message "v$vscodeVersion"
        Register-Check -Name "Install Path" -Status PASS -Message (Split-Path $path -Parent)
        break
    }
}

# Check for VS Code Insiders
$insidersPath = "$env:LOCALAPPDATA\Programs\Microsoft VS Code Insiders\Code - Insiders.exe"
if (Test-Path $insidersPath) {
    $insidersVersion = (Get-Item $insidersPath).VersionInfo.ProductVersion
    Register-Check -Name "VS Code Insiders" -Status WARN -Message "v$insidersVersion (pre-release version installed)"
}

if (-not $vscodeInstalled) {
    Register-Check -Name "VS Code" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# EXTENSION AUDIT
# ============================================================================
Write-Section "Extension Security"

$extensionsDir = "$env:USERPROFILE\.vscode\extensions"

# Known malicious or suspicious extension patterns (examples)
$suspiciousExtensions = @(
    'ms-vscode.cpptools-1.0.0',  # Specific old vulnerable versions
    'prettiest-',                 # Typosquatting attempt pattern
    'vscode-icons-team.vscode-icons-fake',
    'python-fake'
)

if (Test-Path $extensionsDir) {
    $extensions = Get-ChildItem $extensionsDir -Directory -ErrorAction SilentlyContinue
    $extensionCount = $extensions.Count

    Register-Check -Name "Installed Extensions" -Status PASS -Message "$extensionCount extension(s)"

    # Check for suspicious extensions
    $suspiciousFound = @()
    foreach ($ext in $extensions) {
        foreach ($pattern in $suspiciousExtensions) {
            if ($ext.Name -like "*$pattern*") {
                $suspiciousFound += $ext.Name
            }
        }
    }

    if ($suspiciousFound.Count -gt 0) {
        Register-Check -Name "Suspicious Extensions" -Status FAIL -Message "$($suspiciousFound.Count) potentially malicious extension(s)"
    } else {
        Register-Check -Name "Suspicious Extensions" -Status PASS -Message "None detected"
    }

    # Check for extensions with high permissions (by analyzing package.json)
    $highPermExtensions = 0
    foreach ($ext in $extensions | Select-Object -First 20) {
        $packagePath = Join-Path $ext.FullName "package.json"
        if (Test-Path $packagePath) {
            try {
                $package = Get-Content $packagePath -Raw | ConvertFrom-Json

                # Check for dangerous capabilities
                if ($package.contributes) {
                    if ($package.contributes.terminal -or
                        $package.contributes.debuggers -or
                        $package.activationEvents -match '\*') {
                        $highPermExtensions++
                    }
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }

    if ($highPermExtensions -gt 0) {
        Register-Check -Name "High-Permission Extensions" -Status WARN -Message "$highPermExtensions extension(s) with broad capabilities"
    }

    # Check extension verification/signing
    $verifiedCount = 0
    foreach ($ext in $extensions | Select-Object -First 10) {
        $packagePath = Join-Path $ext.FullName "package.json"
        if (Test-Path $packagePath) {
            try {
                $package = Get-Content $packagePath -Raw | ConvertFrom-Json
                if ($package.publisher -match '^ms-|^microsoft|^vscode') {
                    $verifiedCount++
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }
    Register-Check -Name "Microsoft/Verified Extensions" -Status PASS -Message "$verifiedCount from Microsoft/verified publishers"

} else {
    Register-Check -Name "Extensions Directory" -Status WARN -Message "Not found"
}

# ============================================================================
# SETTINGS CONFIGURATION
# ============================================================================
Write-Section "Security Settings"

$settingsPath = "$env:APPDATA\Code\User\settings.json"
$settings = $null

if (Test-Path $settingsPath) {
    try {
        $settingsRaw = Get-Content $settingsPath -Raw
        # Remove comments for JSON parsing
        $settingsClean = $settingsRaw -replace '(?m)^\s*//.*$', '' -replace '/\*[\s\S]*?\*/', ''
        $settings = $settingsClean | ConvertFrom-Json
        Register-Check -Name "User Settings" -Status PASS -Message "Found"
    } catch {
        Register-Check -Name "User Settings" -Status WARN -Message "Found but unable to parse"
    }
}

if ($settings) {
    # Check workspace trust
    $workspaceTrust = $settings.'security.workspace.trust.enabled'
    if ($workspaceTrust -eq $false) {
        Register-Check -Name "Workspace Trust" -Status FAIL -Message "DISABLED (untrusted code can run)"
    } else {
        Register-Check -Name "Workspace Trust" -Status PASS -Message "Enabled (default)"
    }

    # Check restricted mode
    $restrictedMode = $settings.'security.workspace.trust.startupPrompt'
    if ($restrictedMode -eq 'never') {
        Register-Check -Name "Trust Startup Prompt" -Status WARN -Message "Disabled (won't prompt for untrusted folders)"
    }

    # Check telemetry
    $telemetry = $settings.'telemetry.telemetryLevel'
    if (-not $telemetry) {
        $telemetry = $settings.'telemetry.enableTelemetry'
    }

    switch ($telemetry) {
        'off' { Register-Check -Name "Telemetry" -Status PASS -Message "Disabled" }
        'error' { Register-Check -Name "Telemetry" -Status PASS -Message "Errors only" }
        'crash' { Register-Check -Name "Telemetry" -Status PASS -Message "Crash reports only" }
        'all' { Register-Check -Name "Telemetry" -Status WARN -Message "Full telemetry enabled" }
        $false { Register-Check -Name "Telemetry" -Status PASS -Message "Disabled" }
        default { Register-Check -Name "Telemetry" -Status WARN -Message "Default (full telemetry)" }
    }

    # Check auto-update
    $updateMode = $settings.'update.mode'
    switch ($updateMode) {
        'none' { Register-Check -Name "Auto Update" -Status WARN -Message "Disabled (security patches may be missed)" }
        'manual' { Register-Check -Name "Auto Update" -Status WARN -Message "Manual only" }
        'start' { Register-Check -Name "Auto Update" -Status PASS -Message "Check on startup" }
        default { Register-Check -Name "Auto Update" -Status PASS -Message "Automatic (default)" }
    }

    # Check extension auto-update
    $extAutoUpdate = $settings.'extensions.autoUpdate'
    if ($extAutoUpdate -eq $false) {
        Register-Check -Name "Extension Auto Update" -Status WARN -Message "Disabled"
    } else {
        Register-Check -Name "Extension Auto Update" -Status PASS -Message "Enabled (default)"
    }

    # Check for npm script autodetect (potential security risk)
    $npmAutoDetect = $settings.'npm.autoDetect'
    if ($npmAutoDetect -ne 'off') {
        Register-Check -Name "NPM Auto Detect" -Status WARN -Message "Enabled (may auto-run scripts)"
    }

    # Check terminal shell integration
    $terminalShell = $settings.'terminal.integrated.defaultProfile.windows'
    if ($terminalShell) {
        Register-Check -Name "Default Terminal" -Status PASS -Message $terminalShell
    }

} else {
    Register-Check -Name "User Settings" -Status WARN -Message "Not found or empty (using defaults)"
}

# ============================================================================
# REMOTE DEVELOPMENT
# ============================================================================
Write-Section "Remote Development"

# Check for Remote-SSH extension
if (Test-Path $extensionsDir) {
    $remoteSsh = Get-ChildItem $extensionsDir -Directory -Filter "ms-vscode-remote.remote-ssh*" -ErrorAction SilentlyContinue
    if ($remoteSsh) {
        Register-Check -Name "Remote-SSH Extension" -Status PASS -Message "Installed"

        # Check SSH config permissions
        $sshConfigPath = "$env:USERPROFILE\.ssh\config"
        if (Test-Path $sshConfigPath) {
            $sshAcl = Get-Acl $sshConfigPath -ErrorAction SilentlyContinue
            $broadAccess = $sshAcl.Access | Where-Object {
                $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "Read"
            }
            if ($broadAccess) {
                Register-Check -Name "SSH Config Permissions" -Status WARN -Message "Readable by other users"
            } else {
                Register-Check -Name "SSH Config Permissions" -Status PASS -Message "Restricted"
            }
        }
    }

    # Check for Remote-Tunnels extension
    $remoteTunnels = Get-ChildItem $extensionsDir -Directory -Filter "ms-vscode.remote-server*" -ErrorAction SilentlyContinue
    if ($remoteTunnels) {
        Register-Check -Name "Remote Tunnels" -Status WARN -Message "Installed (allows remote access to this machine)"
    }

    # Check for Dev Containers
    $devContainers = Get-ChildItem $extensionsDir -Directory -Filter "ms-vscode-remote.remote-containers*" -ErrorAction SilentlyContinue
    if ($devContainers) {
        Register-Check -Name "Dev Containers" -Status PASS -Message "Installed"
    }
}

# ============================================================================
# CODE EXECUTION SETTINGS
# ============================================================================
Write-Section "Code Execution Settings"

if ($settings) {
    # Task auto-run
    $taskAutoRun = $settings.'task.allowAutomaticTasks'
    switch ($taskAutoRun) {
        'on' { Register-Check -Name "Automatic Tasks" -Status WARN -Message "Enabled (tasks run automatically)" }
        'off' { Register-Check -Name "Automatic Tasks" -Status PASS -Message "Disabled" }
        default { Register-Check -Name "Automatic Tasks" -Status PASS -Message "Prompt (default)" }
    }

    # Debug console execute
    $debugConsole = $settings.'debug.allowBreakpointsEverywhere'
    if ($debugConsole -eq $true) {
        Register-Check -Name "Breakpoints Everywhere" -Status WARN -Message "Enabled"
    }

    # Editor untrusted files
    $untrustedFiles = $settings.'security.workspace.trust.untrustedFiles'
    switch ($untrustedFiles) {
        'open' { Register-Check -Name "Untrusted Files" -Status WARN -Message "Opens without warning" }
        'newWindow' { Register-Check -Name "Untrusted Files" -Status PASS -Message "Opens in new window" }
        default { Register-Check -Name "Untrusted Files" -Status PASS -Message "Prompt (default)" }
    }
}

# ============================================================================
# PORTABLE MODE & DATA DIRECTORY
# ============================================================================
Write-Section "Data Security"

# Check for portable mode
$portableData = Join-Path (Split-Path $vscodePath -Parent) "data"
if (Test-Path $portableData) {
    Register-Check -Name "Portable Mode" -Status WARN -Message "Enabled (settings stored alongside executable)"
} else {
    Register-Check -Name "Portable Mode" -Status PASS -Message "Standard installation"
}

# Check for sensitive data in recent files
$recentPath = "$env:APPDATA\Code\User\globalStorage\state.vscdb"
if (Test-Path $recentPath) {
    Register-Check -Name "State Database" -Status PASS -Message "Recent files history exists"
}

# Check keybindings for potentially dangerous shortcuts
$keybindingsPath = "$env:APPDATA\Code\User\keybindings.json"
if (Test-Path $keybindingsPath) {
    try {
        $keybindings = Get-Content $keybindingsPath -Raw | ConvertFrom-Json
        if ($keybindings.Count -gt 0) {
            Register-Check -Name "Custom Keybindings" -Status PASS -Message "$($keybindings.Count) custom binding(s)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SYNC SETTINGS
# ============================================================================
Write-Section "Settings Sync"

if ($settings) {
    # Check Settings Sync
    # If sync settings exist, sync is likely configured
    if (Test-Path "$env:APPDATA\Code\User\syncLocalSettings.json") {
        Register-Check -Name "Settings Sync" -Status WARN -Message "Enabled (settings synced to Microsoft account)"

        # Check what's being synced
        $syncSettings = Get-Content "$env:APPDATA\Code\User\syncLocalSettings.json" -Raw -ErrorAction SilentlyContinue | ConvertFrom-Json
        if ($syncSettings.'sync.keybindingsPerPlatform' -eq $false) {
            Register-Check -Name "Sync Keybindings" -Status WARN -Message "Cross-platform sync enabled"
        }
    } else {
        Register-Check -Name "Settings Sync" -Status PASS -Message "Not configured"
    }
}

# ============================================================================
# FILE ASSOCIATIONS
# ============================================================================
Write-Section "File Associations"

# Check if VS Code is default for sensitive file types
$sensitiveExtensions = @('.json', '.env', '.pem', '.key', '.yaml', '.yml')
foreach ($ext in $sensitiveExtensions) {
    try {
        $assoc = (Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$ext\UserChoice" -ErrorAction SilentlyContinue).ProgId
        if ($assoc -match 'VSCode|Code') {
            Register-Check -Name "File Association: $ext" -Status PASS -Message "VS Code is default editor"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
