<#
.SYNOPSIS
    Windows Subsystem for Linux (WSL) Security Audit

.DESCRIPTION
    Audits WSL configuration including:
    - WSL version (1 vs 2)
    - Installed distributions
    - Default user configuration
    - Windows/Linux interop settings
    - Network configuration
    - Security-relevant .wslconfig settings

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 4.1 (Secure Configuration)
- NIST SP 800-53: CM-7 (Least Functionality)
- ISO 27001: A.12.6.1 (Technical Vulnerabilities)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows Subsystem for Linux Security Audit"

# ============================================================================
# WSL INSTALLATION STATUS
# ============================================================================
Write-Section "WSL Installation Status"

# Check if WSL feature is enabled
$wslFeature = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -ErrorAction SilentlyContinue
if ($wslFeature -and $wslFeature.State -eq "Enabled") {
    Register-Check -Name "WSL Feature" -Status PASS -Message "Enabled"
} else {
    Register-Check -Name "WSL Feature" -Status SKIP -Message "Not enabled"
    Print-Summary
    Exit-Audit
}

# Check Virtual Machine Platform (required for WSL2)
$vmPlatform = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue
if ($vmPlatform -and $vmPlatform.State -eq "Enabled") {
    Register-Check -Name "Virtual Machine Platform" -Status PASS -Message "Enabled (WSL2 capable)"
} else {
    Register-Check -Name "Virtual Machine Platform" -Status WARN -Message "Not enabled (WSL1 only)"
}

# Get WSL version info
try {
    $wslVersion = & wsl --version 2>$null
    if ($wslVersion) {
        $wslVersionLine = $wslVersion | Select-String "WSL version" | Select-Object -First 1
        if ($wslVersionLine) {
            Register-Check -Name "WSL Version" -Status PASS -Message ($wslVersionLine -replace 'WSL version:\s*', 'v').Trim()
        }
    }
} catch {
    Register-Check -Name "WSL Version" -Status WARN -Message "Unable to query version"
}

# ============================================================================
# INSTALLED DISTRIBUTIONS
# ============================================================================
Write-Section "Installed Distributions"

try {
    $distros = & wsl --list --verbose 2>$null
    if ($distros) {
        # Parse distribution list
        $distroLines = $distros | Where-Object { $_ -match '\S' } | Select-Object -Skip 1
        $distroCount = 0
        $wsl1Count = 0
        $wsl2Count = 0

        foreach ($line in $distroLines) {
            if ($line -match '^\s*\*?\s*(\S+)\s+(Running|Stopped)\s+(\d)') {
                $distroCount++
                $distroName = $Matches[1]
                $state = $Matches[2]
                $version = $Matches[3]

                if ($version -eq "1") { $wsl1Count++ }
                if ($version -eq "2") { $wsl2Count++ }

                $statusMsg = "WSL$version, $state"
                if ($line -match '^\s*\*') {
                    $statusMsg += " (default)"
                }
                Register-Check -Name "Distro: $distroName" -Status PASS -Message $statusMsg
            }
        }

        if ($wsl1Count -gt 0) {
            Register-Check -Name "WSL1 Distributions" -Status WARN -Message "$wsl1Count distro(s) on WSL1 (consider upgrading to WSL2)"
        }

        if ($distroCount -eq 0) {
            Register-Check -Name "Distributions" -Status WARN -Message "No distributions installed"
        }
    }
} catch {
    Register-Check -Name "Distribution List" -Status WARN -Message "Unable to enumerate distributions"
}

# ============================================================================
# DEFAULT USER CONFIGURATION
# ============================================================================
Write-Section "User Configuration"

# Check default users for each distro
try {
    $defaultDistro = & wsl --list --quiet 2>$null | Select-Object -First 1
    if ($defaultDistro) {
        $defaultDistro = $defaultDistro.Trim()

        # Check if default user is root
        $whoami = & wsl -d $defaultDistro -- whoami 2>$null
        if ($whoami) {
            $whoami = $whoami.Trim()
            if ($whoami -eq "root") {
                Register-Check -Name "Default User ($defaultDistro)" -Status WARN -Message "Running as root (security risk)"
            } else {
                Register-Check -Name "Default User ($defaultDistro)" -Status PASS -Message $whoami
            }
        }

        # Check sudoers configuration
        $sudoCheck = & wsl -d $defaultDistro -- sudo -l 2>$null
        if ($sudoCheck -match 'NOPASSWD') {
            Register-Check -Name "Sudo NOPASSWD ($defaultDistro)" -Status WARN -Message "Passwordless sudo enabled"
        } else {
            Register-Check -Name "Sudo Configuration" -Status PASS -Message "Password required for sudo"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# INTEROP CONFIGURATION
# ============================================================================
Write-Section "Windows/Linux Interop"

# Check wsl.conf in distributions
try {
    $defaultDistro = (& wsl --list --quiet 2>$null | Select-Object -First 1).Trim()
    if ($defaultDistro) {
        # Read /etc/wsl.conf
        $wslConf = & wsl -d $defaultDistro -- cat /etc/wsl.conf 2>$null
        if ($wslConf) {
            # Check interop enabled
            if ($wslConf -match 'enabled\s*=\s*false') {
                Register-Check -Name "Windows Interop" -Status PASS -Message "Disabled (more secure)"
            } else {
                Register-Check -Name "Windows Interop" -Status WARN -Message "Enabled (Linux can run Windows executables)"
            }

            # Check appendWindowsPath
            if ($wslConf -match 'appendWindowsPath\s*=\s*false') {
                Register-Check -Name "Append Windows PATH" -Status PASS -Message "Disabled"
            } else {
                Register-Check -Name "Append Windows PATH" -Status WARN -Message "Enabled (Windows binaries in PATH)"
            }

            # Check automount
            if ($wslConf -match 'enabled\s*=\s*false' -and $wslConf -match '\[automount\]') {
                Register-Check -Name "Automount Windows Drives" -Status PASS -Message "Disabled"
            } elseif ($wslConf -match 'options.*metadata') {
                Register-Check -Name "Automount Options" -Status PASS -Message "Metadata enabled for Linux permissions"
            }
        } else {
            Register-Check -Name "wsl.conf" -Status WARN -Message "Not configured (using defaults)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# WSLCONFIG (GLOBAL SETTINGS)
# ============================================================================
Write-Section "Global WSL Configuration (.wslconfig)"

$wslConfigPath = "$env:USERPROFILE\.wslconfig"
if (Test-Path $wslConfigPath) {
    $wslConfig = Get-Content $wslConfigPath -Raw
    Register-Check -Name ".wslconfig" -Status PASS -Message "Found"

    # Check memory limit
    if ($wslConfig -match 'memory\s*=\s*(\S+)') {
        Register-Check -Name "Memory Limit" -Status PASS -Message $Matches[1]
    } else {
        Register-Check -Name "Memory Limit" -Status WARN -Message "Not set (uses 50-80% of RAM)"
    }

    # Check processor limit
    if ($wslConfig -match 'processors\s*=\s*(\d+)') {
        Register-Check -Name "Processor Limit" -Status PASS -Message "$($Matches[1]) CPUs"
    }

    # Check swap
    if ($wslConfig -match 'swap\s*=\s*(\S+)') {
        Register-Check -Name "Swap Size" -Status PASS -Message $Matches[1]
    }

    # Check localhostForwarding
    if ($wslConfig -match 'localhostForwarding\s*=\s*false') {
        Register-Check -Name "Localhost Forwarding" -Status PASS -Message "Disabled"
    } elseif ($wslConfig -match 'localhostForwarding\s*=\s*true') {
        Register-Check -Name "Localhost Forwarding" -Status WARN -Message "Enabled (WSL services accessible from Windows)"
    }

    # Check nestedVirtualization
    if ($wslConfig -match 'nestedVirtualization\s*=\s*true') {
        Register-Check -Name "Nested Virtualization" -Status WARN -Message "Enabled (consider security implications)"
    }

    # Check kernel path (custom kernel)
    if ($wslConfig -match 'kernel\s*=') {
        Register-Check -Name "Custom Kernel" -Status WARN -Message "Custom kernel configured"
    }

    # Check debugConsole
    if ($wslConfig -match 'debugConsole\s*=\s*true') {
        Register-Check -Name "Debug Console" -Status WARN -Message "Enabled (disable in production)"
    }

    # Check guiApplications
    if ($wslConfig -match 'guiApplications\s*=\s*true') {
        Register-Check -Name "GUI Applications (WSLg)" -Status PASS -Message "Enabled"
    }
} else {
    Register-Check -Name ".wslconfig" -Status WARN -Message "Not found (using defaults)"
}

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================
Write-Section "Network Configuration"

# Check WSL network mode
try {
    $defaultDistro = (& wsl --list --quiet 2>$null | Select-Object -First 1).Trim()
    if ($defaultDistro) {
        # Get WSL IP
        $wslIP = & wsl -d $defaultDistro -- hostname -I 2>$null
        if ($wslIP) {
            Register-Check -Name "WSL IP Address" -Status PASS -Message $wslIP.Trim()
        }

        # Check for exposed services
        $listeningPorts = & wsl -d $defaultDistro -- ss -tlnp 2>$null | Select-Object -Skip 1
        if ($listeningPorts) {
            $portCount = ($listeningPorts | Measure-Object).Count
            if ($portCount -gt 0) {
                Register-Check -Name "Listening Services" -Status WARN -Message "$portCount service(s) listening in WSL"
            }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check Windows firewall rules for WSL
try {
    $wslRules = Get-NetFirewallRule -DisplayName "*WSL*" -ErrorAction SilentlyContinue
    if ($wslRules) {
        $enabledRules = $wslRules | Where-Object { $_.Enabled -eq $true }
        Register-Check -Name "WSL Firewall Rules" -Status PASS -Message "$($enabledRules.Count) rule(s) configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for SSH keys in WSL
try {
    $defaultDistro = (& wsl --list --quiet 2>$null | Select-Object -First 1).Trim()
    if ($defaultDistro) {
        $sshKeys = & wsl -d $defaultDistro -- ls -la ~/.ssh/ 2>$null
        if ($sshKeys -match 'id_rsa|id_ed25519|id_ecdsa') {
            # Check permissions
            $keyPerms = & wsl -d $defaultDistro -- stat -c '%a' ~/.ssh/id_* 2>$null | Select-Object -First 1
            if ($keyPerms -and $keyPerms -ne "600") {
                Register-Check -Name "SSH Key Permissions" -Status WARN -Message "Keys found with permissions $keyPerms (should be 600)"
            } else {
                Register-Check -Name "SSH Keys" -Status PASS -Message "Found with correct permissions"
            }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for sensitive files in Windows<->Linux shared locations
$wslSharedPaths = @(
    "$env:USERPROFILE\\.aws",
    "$env:USERPROFILE\\.ssh",
    "$env:USERPROFILE\\.kube"
)

foreach ($path in $wslSharedPaths) {
    if (Test-Path $path) {
        Register-Check -Name "Shared: $((Split-Path $path -Leaf))" -Status WARN -Message "Credentials directory accessible from both Windows and WSL"
    }
}

# Check for systemd
try {
    $defaultDistro = (& wsl --list --quiet 2>$null | Select-Object -First 1).Trim()
    if ($defaultDistro) {
        $systemdCheck = & wsl -d $defaultDistro -- ps -p 1 -o comm= 2>$null
        if ($systemdCheck -match 'systemd') {
            Register-Check -Name "Systemd" -Status PASS -Message "Enabled in WSL"
        } else {
            Register-Check -Name "Systemd" -Status PASS -Message "Not using systemd (init: $($systemdCheck.Trim()))"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
