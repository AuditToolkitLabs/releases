# File Server Audits

This folder contains audit scripts for Windows file servers. Coverage includes:
- SMB file server
- NFS file server
- DFS file server
- General file server baseline

Scripts check share permissions, NTFS permissions, guest/public share exposure, protocol version, audit logging, backup security, and sensitive data exposure. Manual review guidance is provided for areas requiring administrator attention.