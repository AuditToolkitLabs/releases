# DFS File Server Security Audit Script (PowerShell)
# Based on CIS Benchmarks & Microsoft Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows File Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server
# - Microsoft DFS Security: https://learn.microsoft.com/en-us/windows-server/storage/dfs-namespaces/dfs-security

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Check if DFS cmdlets are available
if (-not (Get-Command Get-DfsnRoot -ErrorAction SilentlyContinue)) {
    Register-Check -Name "DFS Feature" -Status SKIP -Message "DFS cmdlets not available"
    Print-Summary
    Exit-Audit
}

# Section: DFS Namespace Permissions
try {
    $namespaces = Get-DfsnRoot
    foreach ($ns in $namespaces) {
        $perm = Get-DfsnAccess -Path $ns.Path
        $public = $perm | Where-Object { $_.AccountName -eq 'Everyone' -and $_.AccessRight -eq 'Full' }
        if ($public) {
            Register-Check -Name "DFS Namespace ($($ns.Path))" -Status FAIL -Message "Public access (Everyone:Full) detected."
        } else {
            Register-Check -Name "DFS Namespace ($($ns.Path))" -Status PASS -Message "No public access."
        }
    }
} catch {
    Register-Check -Name "DFS Namespace Permissions" -Status WARN -Message "Error checking DFS namespaces: $($_.Exception.Message)"
}

# Section: NTFS Permissions
# (Manual) Review NTFS permissions for DFS folders
Register-Check -Name "NTFS Permissions" -Status WARN -Message "Review NTFS permissions for DFS folders (manual)."

# Section: Guest/Public Namespace Exposure
# (Manual) Review guest/public DFS namespaces
Register-Check -Name "Guest/Public Namespaces" -Status WARN -Message "Review guest/public DFS namespaces (manual)."

# Section: Audit Logging
# (Manual) Review audit logging for DFS access
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit logging for DFS access (manual)."

# Section: Shadow Copies & Backup Security
# (Manual) Review shadow copy and backup folder permissions
Register-Check -Name "Shadow Copies & Backup" -Status WARN -Message "Review shadow copy and backup folder permissions (manual)."

# Section: Sensitive Data Exposure
# (Manual) Review open namespaces for sensitive data exposure
Register-Check -Name "Sensitive Data Exposure" -Status WARN -Message "Review open namespaces for sensitive data exposure (manual)."

# Section: Mapped Drives & Network Shares
# (Manual) Review mapped drives and network shares
Register-Check -Name "Mapped Drives & Network Shares" -Status WARN -Message "Review mapped drives and network shares (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - DFS namespace permissions"
Write-Output " - NTFS permissions for DFS folders"
Write-Output " - Guest/public DFS namespaces"
Write-Output " - Audit logging for DFS access"
Write-Output " - Shadow copy and backup folder permissions"
Write-Output " - Sensitive data exposure in open namespaces"
Write-Output " - Mapped drives and network shares"
Write-Output ""
Write-Output "Refer to CIS Windows File Server Benchmark and Microsoft DFS Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
