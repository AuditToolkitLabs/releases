# General File Server Security Audit Script (PowerShell)
# Simplified baseline audit for Windows file servers
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows File Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Check if SMB server service is running
$service = Get-Service -Name 'LanmanServer' -ErrorAction SilentlyContinue
if (-not $service -or $service.Status -ne 'Running') {
    Register-Check -Name "SMB Service" -Status SKIP -Message "File server service not running"
    Print-Summary
    Exit-Audit
}

# Section: Share Permissions
try {
    $shares = Get-SmbShare | Where-Object { $_.Name -ne 'IPC$' }
    foreach ($share in $shares) {
        $perm = Get-SmbShareAccess -Name $share.Name
        $public = $perm | Where-Object { $_.AccountName -eq 'Everyone' -and $_.AccessRight -eq 'Full' }
        if ($public) {
            Register-Check -Name "Share ($($share.Name))" -Status FAIL -Message "Public access (Everyone:Full) detected."
        } else {
            Register-Check -Name "Share ($($share.Name))" -Status PASS -Message "No public access."
        }
    }
} catch {
    Register-Check -Name "Share Permissions" -Status WARN -Message "Error checking shares: $($_.Exception.Message)"
}

# Section: NTFS Permissions
# (Manual) Review NTFS permissions for shared folders
Register-Check -Name "NTFS Permissions" -Status WARN -Message "Review NTFS permissions for shared folders (manual)."

# Section: Guest/Public Share Exposure
# (Manual) Review guest/public shares
Register-Check -Name "Guest/Public Shares" -Status WARN -Message "Review guest/public shares (manual)."

# Section: Audit Logging
# (Manual) Review audit logging for file access
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit logging for file access (manual)."

# Section: Backup Security
# (Manual) Review backup folder permissions
Register-Check -Name "Backup Security" -Status WARN -Message "Review backup folder permissions (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - NTFS permissions for shared folders"
Write-Output " - Guest/public shares"
Write-Output " - Audit logging for file access"
Write-Output " - Backup folder permissions"
Write-Output ""
Write-Output "Refer to CIS Windows File Server Benchmark for detailed manual review procedures."
Print-Summary
Exit-Audit
