# NFS File Server Security Audit Script (PowerShell)
# Based on CIS Benchmarks & Microsoft Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows File Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server
# - Microsoft NFS Security: https://learn.microsoft.com/en-us/windows-server/storage/nfs/nfs-security

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: NFS Share Permissions
# (Manual) Review NFS share permissions and export settings
Register-Check -Name "NFS Share Permissions" -Status WARN -Message "Review NFS share permissions and export settings (manual)."

# Section: NTFS Permissions
# (Manual) Review NTFS permissions for exported folders
Register-Check -Name "NTFS Permissions" -Status WARN -Message "Review NTFS permissions for exported folders (manual)."

# Section: Guest/Public Share Exposure
# (Manual) Review guest/public NFS exports
Register-Check -Name "Guest/Public Exports" -Status WARN -Message "Review guest/public NFS exports (manual)."

# Section: NFS Protocol Version
# (Manual) Confirm NFSv4 is used and NFSv2/v3 are disabled
Register-Check -Name "NFS Protocol Version" -Status WARN -Message "Confirm NFSv4 is used and NFSv2/v3 are disabled (manual)."

# Section: Audit Logging
# (Manual) Review audit logging for NFS access
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit logging for NFS access (manual)."

# Section: Shadow Copies & Backup Security
# (Manual) Review shadow copy and backup folder permissions
Register-Check -Name "Shadow Copies & Backup" -Status WARN -Message "Review shadow copy and backup folder permissions (manual)."

# Section: Sensitive Data Exposure
# (Manual) Review open exports for sensitive data exposure
Register-Check -Name "Sensitive Data Exposure" -Status WARN -Message "Review open exports for sensitive data exposure (manual)."

# Section: Mapped Drives & Network Shares
# (Manual) Review mapped drives and network shares
Register-Check -Name "Mapped Drives & Network Shares" -Status WARN -Message "Review mapped drives and network shares (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - NFS share permissions and export settings"
Write-Output " - NTFS permissions for exported folders"
Write-Output " - Guest/public NFS exports"
Write-Output " - NFS protocol version"
Write-Output " - Audit logging for NFS access"
Write-Output " - Shadow copy and backup folder permissions"
Write-Output " - Sensitive data exposure in open exports"
Write-Output " - Mapped drives and network shares"
Write-Output ""
Write-Output "Refer to CIS Windows File Server Benchmark and Microsoft NFS Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
