# SMB File Server Security Audit Script (PowerShell)
# Based on CIS Benchmarks & Microsoft Best Practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows File Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server
# - Microsoft SMB Security: https://learn.microsoft.com/en-us/windows-server/storage/file-server/smb-security

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: SMB Service Status
$service = Get-Service -Name 'LanmanServer' -ErrorAction SilentlyContinue
if (-not $service -or $service.Status -ne 'Running') {
    Register-Check -Name "SMB Service" -Status SKIP -Message "Not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "SMB Service" -Status PASS -Message "Service running"

# Section: Share Permissions
try {
    $shares = Get-SmbShare | Where-Object { $_.Name -ne 'IPC$' }
    foreach ($share in $shares) {
        Register-Check -Name "Share ($($share.Name))" -Status WARN -Message "Review: Path: $($share.Path), Access: $($share.FolderEnumerationMode)"
    }
} catch {
    Register-Check -Name "Share Permissions" -Status WARN -Message "Could not enumerate SMB shares."
}

# Section: NTFS Permissions
# (Manual) Review NTFS permissions for each share
Register-Check -Name "NTFS Permissions" -Status WARN -Message "Review NTFS permissions for each share (manual)."

# Section: Guest/Public Share Exposure
try {
    $guestShares = Get-SmbShare | Where-Object { $_.ShareState -eq 'Available' -and $_.FolderEnumerationMode -eq 'AccessBased' }
    if ($guestShares.Count -gt 0) {
        Register-Check -Name "Guest/Public Shares" -Status WARN -Message "Guest/public shares detected. Review exposure."
    } else {
        Register-Check -Name "Guest/Public Shares" -Status PASS -Message "No guest/public shares detected."
    }
} catch {
    Register-Check -Name "Guest/Public Shares" -Status WARN -Message "Could not check guest/public share exposure."
}

# Section: Audit Logging
# (Manual) Review file access audit settings
Register-Check -Name "Audit Logging" -Status WARN -Message "Review file access audit settings (manual)."

# Section: Shadow Copies & Backup Security
# (Manual) Review shadow copy and backup folder permissions
Register-Check -Name "Shadow Copies & Backup" -Status WARN -Message "Review shadow copy and backup folder permissions (manual)."

# Section: SMB Protocol Version
try {
    $smbVersions = Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol, EnableSMB2Protocol, EnableSMB3Protocol
    if ($smbVersions.EnableSMB1Protocol -eq $true) {
        Register-Check -Name "SMB Protocol Version" -Status FAIL -Message "SMB1 enabled (security risk). SMB2: $($smbVersions.EnableSMB2Protocol), SMB3: $($smbVersions.EnableSMB3Protocol)"
    } else {
        Register-Check -Name "SMB Protocol Version" -Status PASS -Message "SMB1 disabled. SMB2: $($smbVersions.EnableSMB2Protocol), SMB3: $($smbVersions.EnableSMB3Protocol)"
    }
} catch {
    Register-Check -Name "SMB Protocol Version" -Status WARN -Message "Could not retrieve SMB protocol version."
}

# Section: Sensitive Data Exposure
# (Manual) Review open shares for sensitive data exposure
Register-Check -Name "Sensitive Data Exposure" -Status WARN -Message "Review open shares for sensitive data exposure (manual)."

# Section: Mapped Drives & Network Shares
# (Manual) Review mapped drives and network shares
Register-Check -Name "Mapped Drives & Network Shares" -Status WARN -Message "Review mapped drives and network shares (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - NTFS permissions for each share (NTFS Permissions section)"
Write-Output " - File access audit settings (Audit Logging section)"
Write-Output " - Shadow copy and backup folder permissions (Shadow Copies & Backup section)"
Write-Output " - Sensitive data exposure in open shares (Sensitive Data Exposure section)"
Write-Output " - Mapped drives and network shares (Mapped Drives & Network Shares section)"
Write-Output ""
Write-Output "Refer to CIS Windows File Server Benchmark and Microsoft SMB Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
