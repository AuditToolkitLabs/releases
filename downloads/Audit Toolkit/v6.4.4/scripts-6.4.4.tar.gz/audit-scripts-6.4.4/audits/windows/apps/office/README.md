# Microsoft Office Audits

This folder contains baseline security audit scripts for Microsoft Office applications on Windows hosts. Coverage includes:
- Macro settings
- Protected view
- Add-in restrictions
- Patch/version status
- Trusted locations
- Document encryption
- Audit logging

Manual review guidance is included for settings not directly accessible via script.