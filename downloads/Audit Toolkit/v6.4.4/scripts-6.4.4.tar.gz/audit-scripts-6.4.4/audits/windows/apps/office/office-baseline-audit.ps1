# Microsoft Office Baseline Security Audit Script (PowerShell)
# Simplified baseline audit for Office apps on Windows hosts
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Office Benchmark: https://www.cisecurity.org/benchmark/microsoft_office
# - Microsoft Office Security: https://learn.microsoft.com/en-us/deployoffice/security/security-baseline-office

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Check if Office is installed
$officeInstalled = (Test-Path 'HKLM:\Software\Microsoft\Office\16.0') -or
                   (Test-Path 'HKLM:\Software\Microsoft\Office\15.0') -or
                   (Test-Path 'HKCU:\Software\Microsoft\Office\16.0')
if (-not $officeInstalled) {
    Register-Check -Name "Office Installation" -Status SKIP -Message "Microsoft Office not installed"
    Print-Summary
    Exit-Audit
}

# Section: Macro Settings
try {
    $macroSetting = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Security' -Name 'MacroSecurityLevel' -ErrorAction SilentlyContinue
    if ($macroSetting.MacroSecurityLevel -ge 2) {
        Register-Check -Name "Macro Security" -Status PASS -Message "Macros restricted (level $($macroSetting.MacroSecurityLevel))."
    } else {
        Register-Check -Name "Macro Security" -Status FAIL -Message "Macros not sufficiently restricted (level $($macroSetting.MacroSecurityLevel))."
    }
} catch {
    Register-Check -Name "Macro Security" -Status WARN -Message "Could not check macro security: $($_.Exception.Message)"
}

# Section: Protected View
try {
    $pv = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Word\Security' -Name 'EnableProtectedView' -ErrorAction SilentlyContinue
    if ($pv.EnableProtectedView -eq 1) {
        Register-Check -Name "Protected View" -Status PASS -Message "Protected View enabled."
    } else {
        Register-Check -Name "Protected View" -Status FAIL -Message "Protected View not enabled."
    }
} catch {
    Register-Check -Name "Protected View" -Status WARN -Message "Could not check Protected View: $($_.Exception.Message)"
}

# Section: Add-in Restrictions
# (Manual) Review add-in and COM object restrictions
Register-Check -Name "Add-in Restrictions" -Status WARN -Message "Review add-in and COM object restrictions (manual)."

# Section: Office Patch/Version Status
try {
    $officeVer = Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Office\16.0\Common\InstallRoot' -Name 'Path' -ErrorAction SilentlyContinue
    if ($officeVer.Path) {
        Register-Check -Name "Office Version" -Status PASS -Message "Office installed at $($officeVer.Path)"
    } else {
        Register-Check -Name "Office Version" -Status WARN -Message "Office version not found."
    }
} catch {
    Register-Check -Name "Office Version" -Status WARN -Message "Could not check Office version: $($_.Exception.Message)"
}

# Section: Trusted Locations
# (Manual) Review trusted locations and template security
Register-Check -Name "Trusted Locations" -Status WARN -Message "Review trusted locations and template security (manual)."

# Section: Document Encryption
# (Manual) Review document encryption and password protection
Register-Check -Name "Document Encryption" -Status WARN -Message "Review document encryption and password protection (manual)."

# Section: Audit Logging
# (Manual) Review audit logging for Office applications
Register-Check -Name "Audit Logging" -Status WARN -Message "Review audit logging for Office applications (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Add-in and COM object restrictions"
Write-Output " - Trusted locations and template security"
Write-Output " - Document encryption and password protection"
Write-Output " - Audit logging for Office applications"
Write-Output ""
Write-Output "Refer to CIS Microsoft Office Benchmark and Microsoft Office Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
