# Remote Desktop Audits

This folder contains audit scripts specifically for Windows Remote Desktop Protocol (RDP). Coverage includes:
- RDP service configuration
- Authentication and access control
- Encryption settings
- Session logging
- Patch/version status

Manual review guidance is provided for settings not directly accessible via script.