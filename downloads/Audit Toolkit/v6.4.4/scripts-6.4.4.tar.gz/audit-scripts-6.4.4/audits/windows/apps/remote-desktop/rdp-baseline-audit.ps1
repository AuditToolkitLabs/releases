# Remote Desktop (RDP) Baseline Security Audit Script (PowerShell)
# Simplified baseline audit for Windows Remote Desktop Protocol (RDP)
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server
# - Microsoft RDP Security: https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/security

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: RDP Service Status
$rdp = Get-Service -Name 'TermService' -ErrorAction SilentlyContinue
if (-not $rdp -or $rdp.Status -ne 'Running') {
    Register-Check -Name "RDP Service" -Status SKIP -Message "Not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "RDP Service" -Status PASS -Message "RDP service running."

# Section: Authentication & Access Control
# (Manual) Review authentication methods and access control for RDP
Register-Check -Name "RDP Authentication & Access Control" -Status WARN -Message "Review authentication methods and access control for RDP (manual)."

# Section: Encryption Settings
# (Manual) Review encryption settings for RDP
Register-Check -Name "RDP Encryption Settings" -Status WARN -Message "Review encryption settings for RDP (manual)."

# Section: Session Logging & Audit Trails
# (Manual) Review session logging and audit trails for RDP
Register-Check -Name "RDP Session Logging" -Status WARN -Message "Review session logging and audit trails for RDP (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for RDP
Register-Check -Name "RDP Patch/Version Status" -Status WARN -Message "Review patch/version status for RDP (manual)."

# Section: Exposure to Public Networks
# (Manual) Review exposure of RDP to public networks
Register-Check -Name "RDP Public Network Exposure" -Status WARN -Message "Review exposure of RDP to public networks (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Authentication methods and access control for RDP"
Write-Output " - Encryption settings for RDP"
Write-Output " - Session logging and audit trails for RDP"
Write-Output " - Patch/version status for RDP"
Write-Output " - Exposure of RDP to public networks"
Write-Output ""
Write-Output "Refer to CIS Windows Server Benchmark and Microsoft RDP Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
