# Remote Access Audits

This folder is for audit scripts covering general remote access protocols on Windows hosts, including:
- SSH
- WinRM
- PowerShell Remoting
- Telnet
- VPN

Scripts should check authentication, encryption, access control, logging, and protocol configuration. Manual review guidance is included for areas requiring administrator review.