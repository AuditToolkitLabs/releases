<#
.SYNOPSIS
    AnyDesk Security Audit

.DESCRIPTION
    Security audit for AnyDesk remote desktop software:
    - Installation and version
    - Access control settings
    - Security settings
    - Unattended access configuration
    - Logging and audit trail

.NOTES
    @elevation: partial
    @elevation-reason: ProgramData config may require admin; HKCU and AppData config work without elevation
    Requires: AnyDesk installed

Compliance Mapping:
- CIS Controls: 4.3 (Remote Access), 6.1 (Account Management)
- NIST SP 800-53: AC-17 (Remote Access), AU-2 (Audit Events)
- MITRE ATT&CK: T1219 (Remote Access Software)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "AnyDesk Security Audit"

# ============================================================================
# ANYDESK INSTALLATION CHECK
# ============================================================================
Write-Section "AnyDesk Installation"

$anyDeskInstalled = $false
$anyDeskPath = $null
$anyDeskVersion = $null

# Check common installation paths
$adPaths = @(
    "${env:ProgramFiles}\AnyDesk\AnyDesk.exe",
    "${env:ProgramFiles(x86)}\AnyDesk\AnyDesk.exe",
    "${env:AppData}\AnyDesk\AnyDesk.exe"
)

foreach ($path in $adPaths) {
    if (Test-Path $path) {
        $anyDeskInstalled = $true
        $anyDeskPath = $path
        break
    }
}

# Check registry for installation
$adRegPaths = @(
    "HKLM:\SOFTWARE\AnyDesk Software GmbH\AnyDesk",
    "HKLM:\SOFTWARE\WOW6432Node\AnyDesk Software GmbH\AnyDesk",
    "HKCU:\SOFTWARE\AnyDesk Software GmbH\AnyDesk"
)

foreach ($regPath in $adRegPaths) {
    if (Test-Path $regPath) {
        $anyDeskInstalled = $true
        try {
            $adReg = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
            if ($adReg.Version) {
                $anyDeskVersion = $adReg.Version
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

# Also get version from executable
if ($anyDeskPath -and -not $anyDeskVersion) {
    try {
        $anyDeskVersion = (Get-Item $anyDeskPath).VersionInfo.ProductVersion
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($anyDeskInstalled) {
    Register-Check -Name "AnyDesk Installation" -Status PASS -Message "Installed"

    if ($anyDeskVersion) {
        Register-Check -Name "AnyDesk Version" -Status INFO -Message $anyDeskVersion

        # Version currency check
        $majorVer = [int]($anyDeskVersion -split '\.')[0]
        if ($majorVer -ge 7) {
            Register-Check -Name "Version Currency" -Status PASS -Message "Current major version"
        } elseif ($majorVer -ge 6) {
            Register-Check -Name "Version Currency" -Status INFO -Message "Recent version"
        } else {
            Register-Check -Name "Version Currency" -Status WARN -Message "Consider upgrading"
        }
    }
} else {
    Register-Check -Name "AnyDesk Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# ANYDESK SERVICE
# ============================================================================
Write-Section "AnyDesk Service"

$adService = Get-Service -Name "AnyDesk*" -ErrorAction SilentlyContinue | Select-Object -First 1

if ($adService) {
    if ($adService.Status -eq 'Running') {
        Register-Check -Name "AnyDesk Service" -Status INFO -Message "Running (unattended access available)"
    } else {
        Register-Check -Name "AnyDesk Service" -Status INFO -Message "Stopped"
    }

    # Check startup type
    $startType = $adService.StartType
    if ($startType -eq 'Automatic') {
        Register-Check -Name "Service Startup" -Status WARN -Message "Set to Automatic"
    } else {
        Register-Check -Name "Service Startup" -Status INFO -Message $startType
    }
} else {
    Register-Check -Name "AnyDesk Service" -Status INFO -Message "Not installed as service (portable mode)"
}

# ============================================================================
# SECURITY SETTINGS
# ============================================================================
Write-Section "Security Settings"

# AnyDesk config location
$adConfigPath = "${env:ProgramData}\AnyDesk"
$adUserConfigPath = "${env:AppData}\AnyDesk"

$configPath = if (Test-Path $adConfigPath) { $adConfigPath } elseif (Test-Path $adUserConfigPath) { $adUserConfigPath } else { $null }

if ($configPath) {
    $configFile = Join-Path $configPath "system.conf"

    if (Test-Path $configFile) {
        $config = Get-Content $configFile -Raw -ErrorAction SilentlyContinue

        # Check for unattended password
        if ($config -match "ad\.security\.password_hash=(.+)") {
            Register-Check -Name "Unattended Password" -Status WARN -Message "Configured (unattended access enabled)"
        } else {
            Register-Check -Name "Unattended Password" -Status PASS -Message "Not set"
        }

        # Check interactive access
        if ($config -match "ad\.security\.interactive_access=(\d+)") {
            $interactiveMode = $Matches[1]
            $modeDesc = switch ($interactiveMode) {
                "0" { "Never (disabled)" }
                "1" { "Always" }
                "2" { "When logged in" }
                default { "Unknown" }
            }
            Register-Check -Name "Interactive Access" -Status INFO -Message $modeDesc
        }

        # Check permissions
        if ($config -match "ad\.security\.permissions=(\d+)") {
            $permissions = $Matches[1]
            Register-Check -Name "Permission Profile" -Status INFO -Message "Level $permissions"
        }

        # Check for 2FA
        if ($config -match "ad\.security\.two_factor=1") {
            Register-Check -Name "Two-Factor Auth" -Status PASS -Message "Enabled"
        }

        # Check for whitelist
        if ($config -match "ad\.security\.allowed_ids=(.+)") {
            Register-Check -Name "ID Whitelist" -Status PASS -Message "Configured"
        }
    }
}

# ============================================================================
# ACCESS CONTROL LIST
# ============================================================================
Write-Section "Access Control"

if ($configPath) {
    $aclFile = Join-Path $configPath "acl.txt"
    if (Test-Path $aclFile) {
        $aclContent = Get-Content $aclFile -ErrorAction SilentlyContinue
        $aclEntries = ($aclContent | Where-Object { $_ -match "^\d+" } | Measure-Object).Count

        if ($aclEntries -gt 0) {
            Register-Check -Name "ACL Entries" -Status PASS -Message "$aclEntries allowed ID(s)"
        }
    } else {
        Register-Check -Name "ACL Entries" -Status INFO -Message "No whitelist configured"
    }
}

# ============================================================================
# LOGGING
# ============================================================================
Write-Section "Logging and Audit"

if ($configPath) {
    # Connection trace
    $traceDir = Join-Path $configPath "connection_trace"
    if (Test-Path $traceDir) {
        $traceFiles = Get-ChildItem -Path $traceDir -File -ErrorAction SilentlyContinue
        if ($traceFiles) {
            Register-Check -Name "Connection Trace" -Status PASS -Message "$($traceFiles.Count) trace file(s)"
        }
    }

    # Chat logs
    $chatDir = Join-Path $configPath "chat"
    if (Test-Path $chatDir) {
        Register-Check -Name "Chat Logs" -Status INFO -Message "Chat history present"
    }

    # AD trace log
    $adTraceLog = Join-Path $configPath "ad_svc.trace"
    if (Test-Path $adTraceLog) {
        Register-Check -Name "Service Trace" -Status PASS -Message "Logging enabled"
    }
}

# ============================================================================
# NETWORK SETTINGS
# ============================================================================
Write-Section "Network Configuration"

if ($configPath -and (Test-Path (Join-Path $configPath "system.conf"))) {
    $config = Get-Content (Join-Path $configPath "system.conf") -Raw -ErrorAction SilentlyContinue

    # Direct connections
    if ($config -match "ad\.net\.direct_connections=0") {
        Register-Check -Name "Direct Connections" -Status INFO -Message "Disabled (relay only)"
    } elseif ($config -match "ad\.net\.direct_connections=1") {
        Register-Check -Name "Direct Connections" -Status INFO -Message "Enabled"
    }

    # Listen port
    if ($config -match "ad\.net\.listen_port=(\d+)") {
        Register-Check -Name "Listen Port" -Status INFO -Message $Matches[1]
    }
}

# ============================================================================
# ANYDESK ID
# ============================================================================
Write-Section "AnyDesk Identification"

if ($configPath -and (Test-Path (Join-Path $configPath "system.conf"))) {
    $config = Get-Content (Join-Path $configPath "system.conf") -Raw -ErrorAction SilentlyContinue

    # Get AnyDesk ID
    if ($config -match "ad\.anynet\.id=(\d+)") {
        $adId = $Matches[1]
        Register-Check -Name "AnyDesk ID" -Status INFO -Message $adId
    }

    # Alias
    if ($config -match "ad\.anynet\.alias=(.+)") {
        $alias = $Matches[1].Trim()
        if ($alias) {
            Register-Check -Name "AnyDesk Alias" -Status INFO -Message $alias
        }
    }
}

# ============================================================================
# ENTERPRISE/CUSTOM CLIENT
# ============================================================================
Write-Section "Enterprise Configuration"

# Check for custom client
$customClientPath = "${env:ProgramData}\AnyDesk\custom_client"
if (Test-Path $customClientPath) {
    Register-Check -Name "Custom Client" -Status PASS -Message "Enterprise deployment"
}

# Check for policies
$adPolicyPath = "HKLM:\SOFTWARE\Policies\AnyDesk"
if (Test-Path $adPolicyPath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "GPO configured"
} else {
    Register-Check -Name "Enterprise Policies" -Status INFO -Message "Not configured"
}

# ============================================================================
# PROCESS CHECK
# ============================================================================
Write-Section "Runtime Status"

$adProcess = Get-Process -Name "AnyDesk*" -ErrorAction SilentlyContinue

if ($adProcess) {
    Register-Check -Name "AnyDesk Running" -Status INFO -Message "$($adProcess.Count) process(es)"
} else {
    Register-Check -Name "AnyDesk Running" -Status INFO -Message "Not currently running"
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

Register-Check -Name "Recommendation" -Status INFO -Message "Use ID whitelist to restrict connections"
Register-Check -Name "Recommendation" -Status INFO -Message "Enable two-factor authentication"
Register-Check -Name "Recommendation" -Status INFO -Message "Review connection traces regularly"

if ($adService -and $adService.Status -eq 'Running') {
    Register-Check -Name "Recommendation" -Status WARN -Message "Consider disabling service if unattended access not needed"
}

Print-Summary
Exit-Audit
