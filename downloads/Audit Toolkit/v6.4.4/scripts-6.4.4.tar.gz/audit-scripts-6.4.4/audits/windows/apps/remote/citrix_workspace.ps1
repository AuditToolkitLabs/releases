<#
.SYNOPSIS
    Citrix Workspace Security Audit

.DESCRIPTION
    Security audit for Citrix Workspace App (formerly Receiver):
    - Installation and version
    - ICA client settings
    - Security configuration
    - StoreFront connections
    - SSL/TLS settings
    - Authentication settings

.NOTES
    @elevation: partial
    @elevation-reason: HKLM ICA Client settings require admin; HKCU StoreFront config works without elevation
    Requires: Citrix Workspace App installed

Compliance Mapping:
- CIS Controls: 4.3 (Remote Access), 13.6 (Encryption)
- NIST SP 800-53: AC-17 (Remote Access), SC-8 (Transmission Confidentiality)
- Citrix Security Best Practices
- MITRE ATT&CK: T1021 (Remote Services)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Citrix Workspace Security Audit"

# ============================================================================
# CITRIX WORKSPACE INSTALLATION CHECK
# ============================================================================
Write-Section "Citrix Workspace Installation"

$citrixInstalled = $false
$citrixVersion = $null

# Check common installation paths
$citrixPaths = @(
    "${env:ProgramFiles}\Citrix\ICA Client\wfica32.exe",
    "${env:ProgramFiles(x86)}\Citrix\ICA Client\wfica32.exe",
    "${env:ProgramFiles}\Citrix\ICA Client\Receiver\Receiver.exe"
)

foreach ($path in $citrixPaths) {
    if (Test-Path $path) {
        $citrixInstalled = $true
        break
    }
}

# Check registry for installation
$citrixRegPaths = @(
    "HKLM:\SOFTWARE\Citrix\Install",
    "HKLM:\SOFTWARE\WOW6432Node\Citrix\Install"
)

foreach ($regPath in $citrixRegPaths) {
    if (Test-Path $regPath) {
        $citrixInstalled = $true
        try {
            $citrixReg = Get-ItemProperty -Path $regPath -Name "Version" -ErrorAction SilentlyContinue
            if ($citrixReg) {
                $citrixVersion = $citrixReg.Version
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

# Also check uninstall registry for version
$uninstallReg = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -like "*Citrix Workspace*" -or $_.DisplayName -like "*Citrix Receiver*" }
if ($uninstallReg -and -not $citrixVersion) {
    $citrixVersion = $uninstallReg.DisplayVersion | Select-Object -First 1
}

if ($citrixInstalled) {
    Register-Check -Name "Citrix Workspace" -Status PASS -Message "Installed"

    if ($citrixVersion) {
        Register-Check -Name "Citrix Version" -Status INFO -Message $citrixVersion

        # Version currency check - Citrix Workspace 2xxx is current
        $yearVer = $citrixVersion -replace '\..*', ''
        if ([int]$yearVer -ge 2000) {
            if ([int]$yearVer -ge 2300) {
                Register-Check -Name "Version Currency" -Status PASS -Message "Current (2023+)"
            } else {
                Register-Check -Name "Version Currency" -Status WARN -Message "Consider upgrading to latest LTSR or CR"
            }
        } else {
            Register-Check -Name "Version Currency" -Status WARN -Message "Legacy version - upgrade recommended"
        }
    }
} else {
    Register-Check -Name "Citrix Workspace" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# ICA CLIENT CONFIGURATION
# ============================================================================
Write-Section "ICA Client Configuration"

$icaClientRegPath = "HKLM:\SOFTWARE\WOW6432Node\Citrix\ICA Client"
if (-not (Test-Path $icaClientRegPath)) {
    $icaClientRegPath = "HKLM:\SOFTWARE\Citrix\ICA Client"
}

if (Test-Path $icaClientRegPath) {
    # Client selective trust
    try {
        $cst = Get-ItemProperty -Path "$icaClientRegPath\Client Selective Trust" -ErrorAction SilentlyContinue
        if ($cst) {
            Register-Check -Name "Client Selective Trust" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Engine configuration
    try {
        $enginePath = "$icaClientRegPath\Engine\Configuration\Advanced"
        if (Test-Path $enginePath) {
            $engine = Get-ItemProperty -Path $enginePath -ErrorAction SilentlyContinue
            if ($engine) {
                Register-Check -Name "Engine Configuration" -Status INFO -Message "Present"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SECURITY SETTINGS
# ============================================================================
Write-Section "Security Configuration"

$icaSecurityPath = "$icaClientRegPath\SecureChannelProtocol"

if (Test-Path $icaSecurityPath -ErrorAction SilentlyContinue) {
    # TLS version
    try {
        $sslMinVer = Get-ItemProperty -Path $icaSecurityPath -Name "SSLMinVersion" -ErrorAction SilentlyContinue
        if ($sslMinVer) {
            $tlsDesc = switch ($sslMinVer.SSLMinVersion) {
                "TLS_1.0" { "TLS 1.0 (insecure)" }
                "TLS_1.1" { "TLS 1.1 (deprecated)" }
                "TLS_1.2" { "TLS 1.2" }
                "TLS_1.3" { "TLS 1.3 (secure)" }
                default { $sslMinVer.SSLMinVersion }
            }

            if ($sslMinVer.SSLMinVersion -match "1\.[23]") {
                Register-Check -Name "Minimum TLS Version" -Status PASS -Message $tlsDesc
            } else {
                Register-Check -Name "Minimum TLS Version" -Status WARN -Message $tlsDesc
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # SSL cipher suite
    try {
        $sslCiphers = Get-ItemProperty -Path $icaSecurityPath -Name "SSLCiphers" -ErrorAction SilentlyContinue
        if ($sslCiphers) {
            Register-Check -Name "SSL Ciphers" -Status INFO -Message "Custom configuration"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Certificate revocation
    try {
        $crlCheck = Get-ItemProperty -Path $icaSecurityPath -Name "SSLCertificateRevocationCheckPolicy" -ErrorAction SilentlyContinue
        if ($crlCheck) {
            $crlDesc = switch ($crlCheck.SSLCertificateRevocationCheckPolicy) {
                "NoCheck" { "Disabled (insecure)" }
                "CheckWithNoNetworkAccess" { "Local only" }
                "FullAccessCheck" { "Full check" }
                "FullAccessCheckAndCrl" { "Full check with CRL" }
                default { $crlCheck.SSLCertificateRevocationCheckPolicy }
            }

            if ($crlCheck.SSLCertificateRevocationCheckPolicy -ne "NoCheck") {
                Register-Check -Name "Certificate Revocation" -Status PASS -Message $crlDesc
            } else {
                Register-Check -Name "Certificate Revocation" -Status WARN -Message $crlDesc
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# STOREFRONT / WEB INTERFACE
# ============================================================================
Write-Section "StoreFront Configuration"

$storefrontRegPath = "HKCU:\SOFTWARE\Citrix\Receiver\SR"

if (Test-Path $storefrontRegPath) {
    $storeUrls = Get-ChildItem -Path $storefrontRegPath -ErrorAction SilentlyContinue
    if ($storeUrls) {
        Register-Check -Name "StoreFront Stores" -Status INFO -Message "$($storeUrls.Count) store(s) configured"

        foreach ($store in $storeUrls) {
            $storeName = $store.PSChildName

            # Check if HTTPS
            try {
                $storeUrl = Get-ItemProperty -Path $store.PSPath -Name "Address" -ErrorAction SilentlyContinue
                if ($storeUrl) {
                    if ($storeUrl.Address -match "^https://") {
                        Register-Check -Name "Store: $storeName" -Status PASS -Message "HTTPS"
                    } else {
                        Register-Check -Name "Store: $storeName" -Status WARN -Message "Not HTTPS"
                    }
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }
} else {
    Register-Check -Name "StoreFront Configuration" -Status INFO -Message "No stores configured"
}

# ============================================================================
# AUTHENTICATION
# ============================================================================
Write-Section "Authentication Settings"

$authRegPath = "$icaClientRegPath\Authentication"

if (Test-Path $authRegPath -ErrorAction SilentlyContinue) {
    # Smart card
    try {
        $smartCard = Get-ItemProperty -Path $authRegPath -Name "EnableSmartCard" -ErrorAction SilentlyContinue
        if ($smartCard -and $smartCard.EnableSmartCard -eq 1) {
            Register-Check -Name "Smart Card Auth" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Pass-through authentication
    try {
        $passthrough = Get-ItemProperty -Path "$icaClientRegPath\PNAgent\PassthroughAuthentication" -ErrorAction SilentlyContinue
        if ($passthrough) {
            Register-Check -Name "Passthrough Auth" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Single Sign-On
$ssoRegPath = "HKLM:\SOFTWARE\Citrix\AuthManager"
if (Test-Path $ssoRegPath) {
    try {
        $sso = Get-ItemProperty -Path $ssoRegPath -ErrorAction SilentlyContinue
        if ($sso) {
            Register-Check -Name "Auth Manager" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# FILE TYPE ASSOCIATIONS
# ============================================================================
Write-Section "File Type Associations"

$ftaRegPath = "$icaClientRegPath\Client Selective Trust\oidFileTypeAssociation"

if (Test-Path $ftaRegPath -ErrorAction SilentlyContinue) {
    try {
        $ftaSetting = Get-ItemProperty -Path $ftaRegPath -ErrorAction SilentlyContinue
        if ($ftaSetting) {
            Register-Check -Name "FTA Security" -Status INFO -Message "Client Selective Trust configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# CLIENT DRIVE MAPPING
# ============================================================================
Write-Section "Client Drive Mapping"

$cdmRegPath = "$icaClientRegPath\CDM"

if (Test-Path $cdmRegPath -ErrorAction SilentlyContinue) {
    try {
        $cdmEnabled = Get-ItemProperty -Path $cdmRegPath -Name "AutoMap" -ErrorAction SilentlyContinue
        if ($cdmEnabled) {
            if ($cdmEnabled.AutoMap -eq 0) {
                Register-Check -Name "Client Drive Mapping" -Status PASS -Message "Disabled"
            } else {
                Register-Check -Name "Client Drive Mapping" -Status INFO -Message "Enabled"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Write access
    try {
        $cdmWrite = Get-ItemProperty -Path $cdmRegPath -Name "AllowWriteAccess" -ErrorAction SilentlyContinue
        if ($cdmWrite -and $cdmWrite.AllowWriteAccess -eq 1) {
            Register-Check -Name "CDM Write Access" -Status WARN -Message "Allowed"
        } else {
            Register-Check -Name "CDM Write Access" -Status PASS -Message "Restricted"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# CLIPBOARD REDIRECTION
# ============================================================================
Write-Section "Clipboard Redirection"

$clipboardRegPath = "$icaClientRegPath\Client Selective Trust\oidClipboard"

if (Test-Path $clipboardRegPath -ErrorAction SilentlyContinue) {
    try {
        Get-ItemProperty -Path $clipboardRegPath -ErrorAction SilentlyContinue | Out-Null
        Register-Check -Name "Clipboard Control" -Status INFO -Message "Client Selective Trust configured"
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# ENTERPRISE POLICY
# ============================================================================
Write-Section "Enterprise Policies"

$citrixPolicyPath = "HKLM:\SOFTWARE\Policies\Citrix"

if (Test-Path $citrixPolicyPath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "GPO configured"

    # Check specific policies
    try {
        $icaPolicies = Get-ChildItem -Path $citrixPolicyPath -Recurse -ErrorAction SilentlyContinue
        if ($icaPolicies) {
            Register-Check -Name "Policy Count" -Status INFO -Message "$($icaPolicies.Count) policy setting(s)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "Enterprise Policies" -Status INFO -Message "Not configured via GPO"
}

# ============================================================================
# SERVICES
# ============================================================================
Write-Section "Citrix Services"

$citrixServices = @{
    "BrowserSvc" = "Citrix Browser Service"
    "FMAService" = "Citrix FMA Service"
}

foreach ($svc in $citrixServices.GetEnumerator()) {
    $service = Get-Service -Name $svc.Key -ErrorAction SilentlyContinue
    if ($service) {
        Register-Check -Name $svc.Value -Status INFO -Message $service.Status
    }
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

Register-Check -Name "Recommendation" -Status INFO -Message "Enforce TLS 1.2 minimum"
Register-Check -Name "Recommendation" -Status INFO -Message "Enable certificate revocation checking"
Register-Check -Name "Recommendation" -Status INFO -Message "Use StoreFront with HTTPS only"
Register-Check -Name "Recommendation" -Status INFO -Message "Configure Client Selective Trust appropriately"

Print-Summary
Exit-Audit
