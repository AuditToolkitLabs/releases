# PowerShell Remoting Security Audit Script (PowerShell)
# Audit for PowerShell Remoting on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: PowerShell Remoting Status
try {
    $psRemoting = Get-PSSessionConfiguration -ErrorAction SilentlyContinue | Select-Object -First 1
} catch {
    $psRemoting = $null
}
if (-not $psRemoting) {
    Register-Check -Name "PowerShell Remoting" -Status SKIP -Message "Not enabled"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "PowerShell Remoting" -Status PASS -Message "Remoting enabled."

# Section: Authentication
# (Manual) Review authentication methods for PowerShell Remoting
Register-Check -Name "Remoting Authentication" -Status WARN -Message "Review authentication methods for PowerShell Remoting (manual)."

# Section: Encryption
# (Manual) Review encryption settings for PowerShell Remoting
Register-Check -Name "Remoting Encryption" -Status WARN -Message "Review encryption settings for PowerShell Remoting (manual)."

# Section: Logging
# (Manual) Review logging and audit trails for PowerShell Remoting
Register-Check -Name "Remoting Logging" -Status WARN -Message "Review logging and audit trails for PowerShell Remoting (manual)."

# Section: Exposure
# (Manual) Review exposure of PowerShell Remoting to public networks
Register-Check -Name "Remoting Exposure" -Status WARN -Message "Review exposure of PowerShell Remoting to public networks (manual)."

Print-Summary
Exit-Audit
