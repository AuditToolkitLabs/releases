# Remote Access Baseline Security Audit Script (PowerShell)
# Simplified baseline audit for remote access protocols on Windows hosts
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Remote Services Status
try {
    $winrm = Get-Service -Name 'WinRM' -ErrorAction SilentlyContinue
    if ($winrm.Status -eq 'Running') {
        Register-Check -Name "WinRM Service" -Status PASS -Message "WinRM running."
    } else {
        Register-Check -Name "WinRM Service" -Status WARN -Message "WinRM not running."
    }
} catch {
    Register-Check -Name "WinRM Service" -Status WARN -Message "Could not check WinRM status: $($_.Exception.Message)"
}

# Section: Authentication & Access Control
# (Manual) Review authentication methods and access control for remote services
Register-Check -Name "Authentication & Access Control" -Status WARN -Message "Review authentication methods and access control for remote services (manual)."

# Section: Encryption Settings
# (Manual) Review encryption settings for remote protocols
Register-Check -Name "Encryption Settings" -Status WARN -Message "Review encryption settings for remote protocols (manual)."

# Section: Logging & Audit Trails
# (Manual) Review logging and audit trails for remote access
Register-Check -Name "Logging & Audit Trails" -Status WARN -Message "Review logging and audit trails for remote access (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for remote access tools
Register-Check -Name "Patch/Version Status" -Status WARN -Message "Review patch/version status for remote access tools (manual)."

# Section: Exposure to Public Networks
# (Manual) Review exposure of remote services to public networks
Register-Check -Name "Public Network Exposure" -Status WARN -Message "Review exposure of remote services to public networks (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Authentication methods and access control"
Write-Output " - Encryption settings for remote protocols"
Write-Output " - Logging and audit trails for remote access"
Write-Output " - Patch/version status for remote access tools"
Write-Output " - Exposure of remote services to public networks"
Write-Output ""
Write-Output "Refer to CIS Windows Server Benchmark for detailed manual review procedures."
Print-Summary
Exit-Audit
