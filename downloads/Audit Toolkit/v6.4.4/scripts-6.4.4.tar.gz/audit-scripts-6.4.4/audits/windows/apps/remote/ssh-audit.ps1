# SSH Security Audit Script (PowerShell)
# Audit for SSH protocol on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: SSH Service Status
$ssh = Get-Service -Name 'sshd' -ErrorAction SilentlyContinue
if (-not $ssh -or $ssh.Status -ne 'Running') {
    Register-Check -Name "SSH Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "SSH Service" -Status PASS -Message "SSH running."

# Section: Authentication
# (Manual) Review authentication methods for SSH
Register-Check -Name "SSH Authentication" -Status WARN -Message "Review authentication methods for SSH (manual)."

# Section: Encryption
# (Manual) Review encryption settings for SSH
Register-Check -Name "SSH Encryption" -Status WARN -Message "Review encryption settings for SSH (manual)."

# Section: Logging
# (Manual) Review logging and audit trails for SSH
Register-Check -Name "SSH Logging" -Status WARN -Message "Review logging and audit trails for SSH (manual)."

# Section: Exposure
# (Manual) Review exposure of SSH to public networks
Register-Check -Name "SSH Exposure" -Status WARN -Message "Review exposure of SSH to public networks (manual)."

Print-Summary
Exit-Audit
