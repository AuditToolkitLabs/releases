<#
.SYNOPSIS
    TeamViewer Security Audit

.DESCRIPTION
    Security audit for TeamViewer remote access software:
    - Installation and version
    - Access control settings
    - Security settings
    - Logging configuration
    - Unattended access settings

.NOTES
    @elevation: partial
    @elevation-reason: HKLM policy/config require admin; user logs and connection history work without elevation
    Requires: TeamViewer installed

Compliance Mapping:
- CIS Controls: 4.3 (Remote Access), 6.1 (Account Management)
- NIST SP 800-53: AC-17 (Remote Access), AU-2 (Audit Events)
- MITRE ATT&CK: T1219 (Remote Access Software)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "TeamViewer Security Audit"

# ============================================================================
# TEAMVIEWER INSTALLATION CHECK
# ============================================================================
Write-Section "TeamViewer Installation"

$teamViewerInstalled = $false
$teamViewerVersion = $null

# Check common installation paths
$tvPaths = @(
    "${env:ProgramFiles}\TeamViewer\TeamViewer.exe",
    "${env:ProgramFiles(x86)}\TeamViewer\TeamViewer.exe"
)

foreach ($path in $tvPaths) {
    if (Test-Path $path) {
        $teamViewerInstalled = $true
        break
    }
}

# Check registry for installation
$tvRegPaths = @(
    "HKLM:\SOFTWARE\TeamViewer",
    "HKLM:\SOFTWARE\WOW6432Node\TeamViewer"
)

foreach ($regPath in $tvRegPaths) {
    if (Test-Path $regPath) {
        $teamViewerInstalled = $true
        try {
            $tvReg = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
            $teamViewerVersion = $tvReg.Version
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

if ($teamViewerInstalled) {
    Register-Check -Name "TeamViewer Installation" -Status PASS -Message "Installed"

    if ($teamViewerVersion) {
        Register-Check -Name "TeamViewer Version" -Status INFO -Message $teamViewerVersion

        # Version currency check
        $majorVer = [int]($teamViewerVersion -split '\.')[0]
        if ($majorVer -ge 15) {
            Register-Check -Name "Version Currency" -Status PASS -Message "Current major version"
        } else {
            Register-Check -Name "Version Currency" -Status WARN -Message "Consider upgrading to v15+"
        }
    }
} else {
    Register-Check -Name "TeamViewer Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# TEAMVIEWER SERVICE
# ============================================================================
Write-Section "TeamViewer Service"

$tvService = Get-Service -Name "TeamViewer*" -ErrorAction SilentlyContinue | Select-Object -First 1

if ($tvService) {
    if ($tvService.Status -eq 'Running') {
        Register-Check -Name "TeamViewer Service" -Status INFO -Message "Running (unattended access enabled)"
    } else {
        Register-Check -Name "TeamViewer Service" -Status INFO -Message "Stopped (on-demand only)"
    }

    # Check service startup type
    $startType = $tvService.StartType
    if ($startType -eq 'Automatic') {
        Register-Check -Name "Service Startup" -Status WARN -Message "Set to Automatic"
    } else {
        Register-Check -Name "Service Startup" -Status INFO -Message $startType
    }
} else {
    Register-Check -Name "TeamViewer Service" -Status INFO -Message "Not running as service"
}

# ============================================================================
# SECURITY SETTINGS
# ============================================================================
Write-Section "Security Settings"

$tvSettingsPath = "HKLM:\SOFTWARE\WOW6432Node\TeamViewer"
if (-not (Test-Path $tvSettingsPath)) {
    $tvSettingsPath = "HKLM:\SOFTWARE\TeamViewer"
}

if (Test-Path $tvSettingsPath) {
    # Random password generation
    try {
        $securityPwComplexity = Get-ItemProperty -Path $tvSettingsPath -Name "Security_PasswordStrength" -ErrorAction SilentlyContinue
        if ($securityPwComplexity) {
            $pwStrength = switch ($securityPwComplexity.Security_PasswordStrength) {
                1 { "4 digits (insecure)" }
                2 { "6 characters" }
                3 { "8 characters" }
                4 { "10 characters (secure)" }
                default { "Unknown" }
            }

            if ($securityPwComplexity.Security_PasswordStrength -ge 3) {
                Register-Check -Name "Password Strength" -Status PASS -Message $pwStrength
            } else {
                Register-Check -Name "Password Strength" -Status WARN -Message $pwStrength
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Permanent password (unattended access)
    try {
        $permPwd = Get-ItemProperty -Path $tvSettingsPath -Name "PermanentPassword" -ErrorAction SilentlyContinue
        if ($permPwd) {
            Register-Check -Name "Permanent Password" -Status WARN -Message "Configured (unattended access enabled)"
        } else {
            Register-Check -Name "Permanent Password" -Status PASS -Message "Not set"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Access control mode
    try {
        $accessControl = Get-ItemProperty -Path $tvSettingsPath -Name "AccessControl" -ErrorAction SilentlyContinue
        if ($accessControl) {
            $acMode = switch ($accessControl.AccessControl) {
                0 { "Full Access" }
                1 { "Confirm All" }
                2 { "View and Show" }
                3 { "Custom" }
                default { "Unknown" }
            }

            if ($accessControl.AccessControl -ge 1) {
                Register-Check -Name "Access Control" -Status PASS -Message $acMode
            } else {
                Register-Check -Name "Access Control" -Status WARN -Message "$acMode (consider restricting)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Allowlist/Blocklist
    try {
        $allowlist = Get-ItemProperty -Path $tvSettingsPath -Name "Security_Allowlist" -ErrorAction SilentlyContinue
        if ($allowlist) {
            Register-Check -Name "Allowlist" -Status PASS -Message "Configured"
        }

        $blocklist = Get-ItemProperty -Path $tvSettingsPath -Name "Security_Denylist" -ErrorAction SilentlyContinue
        if ($blocklist) {
            Register-Check -Name "Blocklist" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Two-factor authentication
    try {
        $tfa = Get-ItemProperty -Path $tvSettingsPath -Name "Security_2FA" -ErrorAction SilentlyContinue
        if ($tfa -and $tfa.Security_2FA -eq 1) {
            Register-Check -Name "Two-Factor Auth" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Two-Factor Auth" -Status WARN -Message "Not confirmed enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# NETWORK SETTINGS
# ============================================================================
Write-Section "Network Settings"

if (Test-Path $tvSettingsPath) {
    # Proxy settings
    try {
        $proxy = Get-ItemProperty -Path $tvSettingsPath -Name "ProxyIP" -ErrorAction SilentlyContinue
        if ($proxy) {
            Register-Check -Name "Proxy" -Status INFO -Message "Configured"
        } else {
            Register-Check -Name "Proxy" -Status INFO -Message "Direct connection"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # LAN only mode
    try {
        $lanOnly = Get-ItemProperty -Path $tvSettingsPath -Name "LAN_Only" -ErrorAction SilentlyContinue
        if ($lanOnly -and $lanOnly.LAN_Only -eq 1) {
            Register-Check -Name "LAN Only Mode" -Status PASS -Message "Enabled (no internet connections)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# LOGGING
# ============================================================================
Write-Section "Logging"

# Check log directory
$tvLogPath = "${env:ProgramFiles}\TeamViewer\Logs"
if (-not (Test-Path $tvLogPath)) {
    $tvLogPath = "${env:ProgramFiles(x86)}\TeamViewer\Logs"
}

if (Test-Path $tvLogPath) {
    $logFiles = Get-ChildItem -Path $tvLogPath -Filter "*.log" -ErrorAction SilentlyContinue
    if ($logFiles) {
        Register-Check -Name "Log Files" -Status PASS -Message "$($logFiles.Count) log file(s)"

        # Check for connection logs
        $connLogs = $logFiles | Where-Object { $_.Name -match "connections" }
        if ($connLogs) {
            Register-Check -Name "Connection Logging" -Status PASS -Message "Enabled"
        }
    }
}

# Incoming connection log
$tvUserLogPath = "${env:AppData}\TeamViewer"
if (Test-Path $tvUserLogPath) {
    $incomingLog = Join-Path $tvUserLogPath "connections_incoming.txt"
    if (Test-Path $incomingLog) {
        Register-Check -Name "Incoming Connections Log" -Status PASS -Message "Present"

        # Check recent connections
        try {
            Get-Content $incomingLog -Tail 5 -ErrorAction SilentlyContinue | Out-Null
            $connectionCount = (Get-Content $incomingLog -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
            Register-Check -Name "Connection History" -Status INFO -Message "$connectionCount connection(s) logged"
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# ENTERPRISE/POLICY SETTINGS
# ============================================================================
Write-Section "Enterprise Configuration"

$tvPolicyPath = "HKLM:\SOFTWARE\Policies\TeamViewer"
if (Test-Path $tvPolicyPath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "GPO configured"

    # Check for specific policies
    try {
        $disableUpdates = Get-ItemProperty -Path $tvPolicyPath -Name "DisableAutoUpdate" -ErrorAction SilentlyContinue
        if ($disableUpdates -and $disableUpdates.DisableAutoUpdate -eq 1) {
            Register-Check -Name "Auto-Update" -Status WARN -Message "Disabled via policy"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "Enterprise Policies" -Status INFO -Message "Not configured"
}

# ============================================================================
# PROCESS CHECK
# ============================================================================
Write-Section "Runtime Status"

$tvProcess = Get-Process -Name "TeamViewer*" -ErrorAction SilentlyContinue

if ($tvProcess) {
    Register-Check -Name "TeamViewer Running" -Status INFO -Message "$($tvProcess.Count) process(es)"

    # Check if running elevated
    try {
        foreach ($proc in $tvProcess) {
            $owner = (Get-CimInstance -ClassName Win32_Process -Filter "ProcessId = $($proc.Id)" -ErrorAction SilentlyContinue | Invoke-CimMethod -MethodName GetOwner -ErrorAction SilentlyContinue)
            if ($owner.User -eq "SYSTEM") {
                Register-Check -Name "Running as SYSTEM" -Status INFO -Message "Service mode active"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "TeamViewer Running" -Status INFO -Message "Not currently running"
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

Register-Check -Name "Recommendation" -Status INFO -Message "Use allowlist to restrict incoming connections"
Register-Check -Name "Recommendation" -Status INFO -Message "Enable 2FA for TeamViewer account"
Register-Check -Name "Recommendation" -Status INFO -Message "Review connection logs regularly"

if ($tvService -and $tvService.Status -eq 'Running') {
    Register-Check -Name "Recommendation" -Status WARN -Message "Consider disabling service if unattended access not needed"
}

Print-Summary
Exit-Audit
