# Telnet Security Audit Script (PowerShell)
# Audit for Telnet protocol on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Telnet Service Status
$telnet = Get-Service -Name 'Telnet' -ErrorAction SilentlyContinue
if (-not $telnet -or $telnet.Status -ne 'Running') {
    Register-Check -Name "Telnet Service" -Status SKIP -Message "Not installed (recommended)"
    Print-Summary
    Exit-Audit
}
# Telnet is running - this is a security concern
Register-Check -Name "Telnet Service" -Status WARN -Message "Telnet running - consider disabling (insecure protocol)"

# Section: Authentication
# (Manual) Review authentication methods for Telnet
Register-Check -Name "Telnet Authentication" -Status WARN -Message "Review authentication methods for Telnet (manual)."

# Section: Encryption
# (Manual) Review encryption settings for Telnet
Register-Check -Name "Telnet Encryption" -Status WARN -Message "Review encryption settings for Telnet (manual)."

# Section: Logging
# (Manual) Review logging and audit trails for Telnet
Register-Check -Name "Telnet Logging" -Status WARN -Message "Review logging and audit trails for Telnet (manual)."

# Section: Exposure
# (Manual) Review exposure of Telnet to public networks
Register-Check -Name "Telnet Exposure" -Status WARN -Message "Review exposure of Telnet to public networks (manual)."

Print-Summary
Exit-Audit
