# VPN Security Audit Script (PowerShell)
# Comprehensive audit for enterprise VPN clients on Windows
# This script is read-only and does not modify system state.
#
# Supported VPN Clients:
# - Cisco AnyConnect
# - Palo Alto GlobalProtect
# - Zscaler Client Connector
# - Fortinet FortiClient
# - Pulse Secure / Ivanti Connect Secure
# - OpenVPN
# - Windows Built-in VPN
#
# References:
# - CIS Controls 12: Network Infrastructure Management
# - NIST SP 800-77: Guide to IPsec VPNs

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# ============================================================================
# CISCO ANYCONNECT
# ============================================================================
Write-Output "=== Cisco AnyConnect ==="

$anyConnectPath = "C:\Program Files (x86)\Cisco\Cisco AnyConnect Secure Mobility Client"
$anyConnectPath64 = "C:\Program Files\Cisco\Cisco AnyConnect Secure Mobility Client"

$acInstalled = $false
if (Test-Path $anyConnectPath) {
    $acInstalled = $true
    $acPath = $anyConnectPath
} elseif (Test-Path $anyConnectPath64) {
    $acInstalled = $true
    $acPath = $anyConnectPath64
}

if ($acInstalled) {
    Register-Check -Name "Cisco AnyConnect" -Status INFO -Message "Installed"

    # Check version
    $vpnui = Get-Item "$acPath\vpnui.exe" -ErrorAction SilentlyContinue
    if ($vpnui) {
        $version = $vpnui.VersionInfo.FileVersion
        Register-Check -Name "AnyConnect Version" -Status INFO -Message $version

        # Check for known vulnerable versions
        $versionNum = [version]($version -replace '[^0-9.]', '')
        if ($versionNum -lt [version]"4.10.0") {
            Register-Check -Name "AnyConnect Version Check" -Status WARN -Message "Version < 4.10 - consider updating"
        } else {
            Register-Check -Name "AnyConnect Version Check" -Status PASS -Message "Recent version"
        }
    }

    # Check AnyConnect service
    $acService = Get-Service -Name "vpnagent" -ErrorAction SilentlyContinue
    if ($acService) {
        if ($acService.Status -eq "Running") {
            Register-Check -Name "AnyConnect Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "AnyConnect Service" -Status WARN -Message $acService.Status
        }
    }

    # Check AnyConnect local policy
    $localPolicyPath = "$acPath\AnyConnectLocalPolicy.xml"
    if (Test-Path $localPolicyPath) {
        $policy = [xml](Get-Content $localPolicyPath -ErrorAction SilentlyContinue)

        # Check bypass downloader
        $bypassDownloader = $policy.AnyConnectLocalPolicy.BypassDownloader
        if ($bypassDownloader -eq "true") {
            Register-Check -Name "AnyConnect Bypass Downloader" -Status INFO -Message "Enabled"
        }

        # Check FIPS mode
        $fipsMode = $policy.AnyConnectLocalPolicy.FipsMode
        if ($fipsMode -eq "true") {
            Register-Check -Name "AnyConnect FIPS Mode" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "AnyConnect FIPS Mode" -Status INFO -Message "Not enforced"
        }

        # Check strict certificate trust
        $strictCert = $policy.AnyConnectLocalPolicy.StrictCertificateTrust
        if ($strictCert -eq "true") {
            Register-Check -Name "AnyConnect Strict Cert Trust" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "AnyConnect Strict Cert Trust" -Status WARN -Message "Not enforced"
        }
    }

    # Check AnyConnect Profile
    $profilePath = "$env:ProgramData\Cisco\Cisco AnyConnect Secure Mobility Client\Profile"
    if (Test-Path $profilePath) {
        $profiles = Get-ChildItem "$profilePath\*.xml" -ErrorAction SilentlyContinue
        if ($profiles) {
            Register-Check -Name "AnyConnect Profiles" -Status INFO -Message "$($profiles.Count) profile(s) found"

            foreach ($vpnProfile in $profiles) {
                $profXml = [xml](Get-Content $vpnProfile.FullName -ErrorAction SilentlyContinue)

                # Check auto reconnect
                $autoReconnect = $profXml.AnyConnectProfile.ClientInitialization.AutoReconnect
                if ($autoReconnect -eq "true") {
                    Register-Check -Name "Profile $($vpnProfile.BaseName) AutoReconnect" -Status PASS -Message "Enabled"
                }

                # Check always-on
                $alwaysOn = $profXml.AnyConnectProfile.ClientInitialization.AlwaysOn
                if ($alwaysOn -eq "true") {
                    Register-Check -Name "Profile $($vpnProfile.BaseName) Always-On" -Status PASS -Message "Enabled"
                }
            }
        }
    }
} else {
    Register-Check -Name "Cisco AnyConnect" -Status INFO -Message "Not installed"
}

# ============================================================================
# PALO ALTO GLOBALPROTECT
# ============================================================================
Write-Output ""
Write-Output "=== Palo Alto GlobalProtect ==="

$gpPath = "C:\Program Files\Palo Alto Networks\GlobalProtect"
$gpInstalled = Test-Path $gpPath

if ($gpInstalled) {
    Register-Check -Name "GlobalProtect" -Status INFO -Message "Installed"

    # Check version
    $pangpa = Get-Item "$gpPath\PanGPA.exe" -ErrorAction SilentlyContinue
    if ($pangpa) {
        $version = $pangpa.VersionInfo.FileVersion
        Register-Check -Name "GlobalProtect Version" -Status INFO -Message $version
    }

    # Check GlobalProtect service
    $gpService = Get-Service -Name "PanGPS" -ErrorAction SilentlyContinue
    if ($gpService) {
        if ($gpService.Status -eq "Running") {
            Register-Check -Name "GlobalProtect Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "GlobalProtect Service" -Status WARN -Message $gpService.Status
        }
    }

    # Check registry settings
    $gpReg = "HKLM:\SOFTWARE\Palo Alto Networks\GlobalProtect\Settings"
    if (Test-Path $gpReg) {
        # Check portal address
        $portal = Get-ItemProperty -Path $gpReg -Name "Portal" -ErrorAction SilentlyContinue
        if ($portal.Portal) {
            Register-Check -Name "GlobalProtect Portal" -Status INFO -Message $portal.Portal
        }

        # Check connect method
        $connectMethod = Get-ItemProperty -Path $gpReg -Name "connect-method" -ErrorAction SilentlyContinue
        if ($connectMethod.'connect-method' -eq "pre-logon") {
            Register-Check -Name "GlobalProtect Connect Method" -Status PASS -Message "Pre-logon (Always-On)"
        } elseif ($connectMethod.'connect-method' -eq "user-logon") {
            Register-Check -Name "GlobalProtect Connect Method" -Status INFO -Message "User-logon"
        }
    }

    # Check HIP (Host Information Profile) settings
    $hipReg = "HKLM:\SOFTWARE\Palo Alto Networks\GlobalProtect\HIP"
    if (Test-Path $hipReg) {
        Register-Check -Name "GlobalProtect HIP" -Status PASS -Message "Host Information Profile enabled"
    } else {
        Register-Check -Name "GlobalProtect HIP" -Status INFO -Message "HIP not configured"
    }
} else {
    Register-Check -Name "GlobalProtect" -Status INFO -Message "Not installed"
}

# ============================================================================
# ZSCALER CLIENT CONNECTOR
# ============================================================================
Write-Output ""
Write-Output "=== Zscaler Client Connector ==="

$zscalerPath = "C:\Program Files\Zscaler\ZSATunnel"
$zscalerPath2 = "C:\Program Files (x86)\Zscaler\ZSATunnel"
$zccPath = "C:\Program Files\Zscaler\Zscaler App"

$zscalerInstalled = (Test-Path $zscalerPath) -or (Test-Path $zscalerPath2) -or (Test-Path $zccPath)

if ($zscalerInstalled) {
    Register-Check -Name "Zscaler Client Connector" -Status INFO -Message "Installed"

    # Check Zscaler service
    $zscalerSvc = Get-Service -Name "ZSATunnelService" -ErrorAction SilentlyContinue
    if (-not $zscalerSvc) {
        $zscalerSvc = Get-Service -Name "ZscalerService" -ErrorAction SilentlyContinue
    }

    if ($zscalerSvc) {
        if ($zscalerSvc.Status -eq "Running") {
            Register-Check -Name "Zscaler Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Zscaler Service" -Status WARN -Message $zscalerSvc.Status
        }
    }

    # Check Zscaler Tunnel Driver
    $zsaTunDriver = Get-Service -Name "zsatun" -ErrorAction SilentlyContinue
    if ($zsaTunDriver -and $zsaTunDriver.Status -eq "Running") {
        Register-Check -Name "Zscaler Tunnel Driver" -Status PASS -Message "Active"
    }

    # Check for Zscaler certificate
    $zscalerCert = Get-ChildItem Cert:\LocalMachine\Root | Where-Object { $_.Subject -match "Zscaler" }
    if ($zscalerCert) {
        $daysToExpiry = ($zscalerCert[0].NotAfter - (Get-Date)).Days
        if ($daysToExpiry -gt 30) {
            Register-Check -Name "Zscaler Root Certificate" -Status PASS -Message "Valid ($daysToExpiry days)"
        } else {
            Register-Check -Name "Zscaler Root Certificate" -Status WARN -Message "Expires in $daysToExpiry days"
        }
    }

    # Check Zscaler App configuration
    $zccConfig = "$env:ProgramData\Zscaler\ZCC\config.json"
    if (Test-Path $zccConfig) {
        try {
            $config = Get-Content $zccConfig -Raw | ConvertFrom-Json
            if ($config.strictEnforcement -eq $true) {
                Register-Check -Name "Zscaler Strict Enforcement" -Status PASS -Message "Enabled"
            }
            if ($config.cloudName) {
                Register-Check -Name "Zscaler Cloud" -Status INFO -Message $config.cloudName
            }
        } catch {
            Register-Check -Name "Zscaler Config" -Status INFO -Message "Cannot parse config"
        }
    }
} else {
    Register-Check -Name "Zscaler" -Status INFO -Message "Not installed"
}

# ============================================================================
# FORTINET FORTICLIENT
# ============================================================================
Write-Output ""
Write-Output "=== Fortinet FortiClient ==="

$fortiPath = "C:\Program Files\Fortinet\FortiClient"
$fortiPath86 = "C:\Program Files (x86)\Fortinet\FortiClient"

$fortiInstalled = (Test-Path $fortiPath) -or (Test-Path $fortiPath86)

if ($fortiInstalled) {
    $fcPath = if (Test-Path $fortiPath) { $fortiPath } else { $fortiPath86 }
    Register-Check -Name "FortiClient" -Status INFO -Message "Installed"

    # Check version
    $fortiTray = Get-Item "$fcPath\FortiTray.exe" -ErrorAction SilentlyContinue
    if ($fortiTray) {
        $version = $fortiTray.VersionInfo.FileVersion
        Register-Check -Name "FortiClient Version" -Status INFO -Message $version
    }

    # Check FortiClient service
    $fortiSvc = Get-Service -Name "FA_Scheduler" -ErrorAction SilentlyContinue
    if (-not $fortiSvc) {
        $fortiSvc = Get-Service -Name "FortiClient Service Scheduler" -ErrorAction SilentlyContinue
    }

    if ($fortiSvc) {
        if ($fortiSvc.Status -eq "Running") {
            Register-Check -Name "FortiClient Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "FortiClient Service" -Status WARN -Message $fortiSvc.Status
        }
    }

    # Check VPN daemon
    $vpnDaemon = Get-Service -Name "FortiVPNDaemon" -ErrorAction SilentlyContinue
    if ($vpnDaemon -and $vpnDaemon.Status -eq "Running") {
        Register-Check -Name "FortiVPN Daemon" -Status PASS -Message "Running"
    }

    # Check EMS connection (FortiClient EMS management)
    $emsReg = "HKLM:\SOFTWARE\Fortinet\FortiClient\Sslvpn\EMS"
    if (Test-Path $emsReg) {
        $emsServer = Get-ItemProperty -Path $emsReg -Name "server" -ErrorAction SilentlyContinue
        if ($emsServer.server) {
            Register-Check -Name "FortiClient EMS" -Status PASS -Message "Managed by $($emsServer.server)"
        }
    } else {
        Register-Check -Name "FortiClient EMS" -Status INFO -Message "Standalone (not EMS managed)"
    }
} else {
    Register-Check -Name "FortiClient" -Status INFO -Message "Not installed"
}

# ============================================================================
# PULSE SECURE / IVANTI CONNECT SECURE
# ============================================================================
Write-Output ""
Write-Output "=== Pulse Secure / Ivanti ==="

$pulsePath = "C:\Program Files (x86)\Pulse Secure\Pulse"
$pulsePath64 = "C:\Program Files\Pulse Secure\Pulse"
$ivantiPath = "C:\Program Files (x86)\Ivanti\Ivanti Secure Access Client"
$ivantiPath64 = "C:\Program Files\Ivanti\Ivanti Secure Access Client"

$pulseInstalled = (Test-Path $pulsePath) -or (Test-Path $pulsePath64) -or (Test-Path $ivantiPath) -or (Test-Path $ivantiPath64)

if ($pulseInstalled) {
    $vendor = if ((Test-Path $ivantiPath) -or (Test-Path $ivantiPath64)) { "Ivanti" } else { "Pulse Secure" }
    Register-Check -Name $vendor -Status INFO -Message "Installed"

    # Check Pulse service
    $pulseSvc = Get-Service -Name "PulseSecureService" -ErrorAction SilentlyContinue
    if (-not $pulseSvc) {
        $pulseSvc = Get-Service -Name "dsAccessService" -ErrorAction SilentlyContinue
    }
    if (-not $pulseSvc) {
        $pulseSvc = Get-Service -Name "IvantiSecureAccessService" -ErrorAction SilentlyContinue
    }

    if ($pulseSvc) {
        if ($pulseSvc.Status -eq "Running") {
            Register-Check -Name "$vendor Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "$vendor Service" -Status WARN -Message $pulseSvc.Status
        }
    }

    # Check for certificate-based auth
    $pulseCerts = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Subject -match "Pulse|Ivanti|VPN" }
    if ($pulseCerts) {
        Register-Check -Name "$vendor Client Cert" -Status INFO -Message "$($pulseCerts.Count) certificate(s)"
    }

    # Check Host Checker component
    $hostChecker = Get-Process -Name "dsHostChecker" -ErrorAction SilentlyContinue
    if ($hostChecker) {
        Register-Check -Name "$vendor Host Checker" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "$vendor Host Checker" -Status INFO -Message "Not running (may be on-demand)"
    }
} else {
    Register-Check -Name "Pulse Secure / Ivanti" -Status INFO -Message "Not installed"
}

# ============================================================================
# OPENVPN
# ============================================================================
Write-Output ""
Write-Output "=== OpenVPN ==="

$openVpnPath = "C:\Program Files\OpenVPN"
$openVpnPath86 = "C:\Program Files (x86)\OpenVPN"

$openVpnInstalled = (Test-Path $openVpnPath) -or (Test-Path $openVpnPath86)

if ($openVpnInstalled) {
    $ovpnPath = if (Test-Path $openVpnPath) { $openVpnPath } else { $openVpnPath86 }
    Register-Check -Name "OpenVPN" -Status INFO -Message "Installed"

    # Check version
    $ovpn = Get-Item "$ovpnPath\bin\openvpn.exe" -ErrorAction SilentlyContinue
    if ($ovpn) {
        $version = $ovpn.VersionInfo.FileVersion
        Register-Check -Name "OpenVPN Version" -Status INFO -Message $version

        # Check for old versions
        $versionNum = [version]($version -replace '[^0-9.]', '' -replace '\.+$', '')
        if ($versionNum -lt [version]"2.5.0") {
            Register-Check -Name "OpenVPN Version Check" -Status WARN -Message "Version < 2.5 - consider updating"
        }
    }

    # Check OpenVPN service
    $ovpnSvc = Get-Service -Name "OpenVPNService" -ErrorAction SilentlyContinue
    if ($ovpnSvc) {
        if ($ovpnSvc.Status -eq "Running") {
            Register-Check -Name "OpenVPN Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "OpenVPN Service" -Status INFO -Message $ovpnSvc.Status
        }
    }

    # Check TAP adapter
    $tapAdapter = Get-NetAdapter | Where-Object { $_.Name -match "TAP|OpenVPN" }
    if ($tapAdapter) {
        Register-Check -Name "OpenVPN TAP Adapter" -Status INFO -Message "$($tapAdapter.Count) adapter(s)"
    }

    # Check config directory security
    $configPath = "$ovpnPath\config"
    if (Test-Path $configPath) {
        $configs = Get-ChildItem "$configPath\*.ovpn" -ErrorAction SilentlyContinue
        if ($configs) {
            Register-Check -Name "OpenVPN Configs" -Status INFO -Message "$($configs.Count) profile(s)"

            # Check for embedded credentials (security risk)
            foreach ($cfg in $configs) {
                $content = Get-Content $cfg.FullName -ErrorAction SilentlyContinue
                $hasAuthUser = $content | Where-Object { $_ -match "^auth-user-pass\s+\S" }
                if ($hasAuthUser) {
                    Register-Check -Name "Config $($cfg.BaseName)" -Status WARN -Message "May have embedded credentials"
                }

                # Check cipher
                $cipher = $content | Where-Object { $_ -match "^cipher\s+(\S+)" }
                if ($cipher -match "BF-CBC|DES") {
                    Register-Check -Name "Config $($cfg.BaseName) Cipher" -Status WARN -Message "Weak cipher in use"
                }
            }
        }
    }
} else {
    Register-Check -Name "OpenVPN" -Status INFO -Message "Not installed"
}

# ============================================================================
# WINDOWS BUILT-IN VPN
# ============================================================================
Write-Output ""
Write-Output "=== Windows Built-in VPN ==="

try {
    $vpnConnections = Get-VpnConnection -ErrorAction Stop

    if ($vpnConnections.Count -eq 0) {
        Register-Check -Name "Windows VPN" -Status INFO -Message "No connections configured"
    } else {
        Register-Check -Name "Windows VPN Connections" -Status INFO -Message "$($vpnConnections.Count) connection(s)"

        foreach ($vpn in $vpnConnections) {
            Register-Check -Name "VPN: $($vpn.Name)" -Status INFO -Message "Type: $($vpn.TunnelType)"

            # Check tunnel type security
            if ($vpn.TunnelType -eq "Pptp") {
                Register-Check -Name "$($vpn.Name) Protocol" -Status FAIL -Message "PPTP is insecure - use IKEv2 or L2TP/IPsec"
            } elseif ($vpn.TunnelType -eq "Ikev2") {
                Register-Check -Name "$($vpn.Name) Protocol" -Status PASS -Message "IKEv2 (recommended)"
            } elseif ($vpn.TunnelType -eq "L2tp") {
                Register-Check -Name "$($vpn.Name) Protocol" -Status INFO -Message "L2TP/IPsec"
            } elseif ($vpn.TunnelType -eq "Sstp") {
                Register-Check -Name "$($vpn.Name) Protocol" -Status PASS -Message "SSTP (TLS-based)"
            }

            # Check authentication method
            $authMethod = $vpn.AuthenticationMethod
            if ($authMethod -contains "Pap") {
                Register-Check -Name "$($vpn.Name) Auth" -Status FAIL -Message "PAP - use EAP or certificate"
            } elseif ($authMethod -contains "Eap") {
                Register-Check -Name "$($vpn.Name) Auth" -Status PASS -Message "EAP"
            } elseif ($authMethod -contains "MachineCertificate") {
                Register-Check -Name "$($vpn.Name) Auth" -Status PASS -Message "Machine Certificate"
            }

            # Check split tunneling
            if ($vpn.SplitTunneling -eq $true) {
                Register-Check -Name "$($vpn.Name) Split Tunnel" -Status INFO -Message "Enabled"
            } else {
                Register-Check -Name "$($vpn.Name) Split Tunnel" -Status PASS -Message "Disabled (all traffic through VPN)"
            }

            # Check remember credentials
            if ($vpn.RememberCredential -eq $true) {
                Register-Check -Name "$($vpn.Name) Remember Creds" -Status INFO -Message "Enabled"
            }
        }
    }
} catch {
    Register-Check -Name "Windows VPN" -Status INFO -Message "Cannot query VPN connections"
}

# ============================================================================
# VPN-RELATED SERVICES
# ============================================================================
Write-Output ""
Write-Output "=== VPN-Related Services ==="

# Check RRAS (Routing and Remote Access)
$rras = Get-Service -Name "RemoteAccess" -ErrorAction SilentlyContinue
if ($rras) {
    if ($rras.Status -eq "Running") {
        Register-Check -Name "RRAS Service" -Status INFO -Message "Running (VPN server capability)"
    } else {
        Register-Check -Name "RRAS Service" -Status INFO -Message $rras.Status
    }
}

# Check IKE and AuthIP services
$ikeext = Get-Service -Name "IKEEXT" -ErrorAction SilentlyContinue
if ($ikeext -and $ikeext.Status -eq "Running") {
    Register-Check -Name "IKE/AuthIP Service" -Status INFO -Message "Running"
}

# Check IPsec Policy Agent
$policyAgent = Get-Service -Name "PolicyAgent" -ErrorAction SilentlyContinue
if ($policyAgent) {
    if ($policyAgent.Status -eq "Running") {
        Register-Check -Name "IPsec Policy Agent" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "IPsec Policy Agent" -Status INFO -Message $policyAgent.Status
    }
}

# ============================================================================
# VPN SECURITY POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== VPN Security Policies ==="

# Check for Always On VPN profile (Windows 10/11 Enterprise)
$alwaysOnVpn = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\VPNv2" -ErrorAction SilentlyContinue
if ($alwaysOnVpn) {
    Register-Check -Name "Always On VPN" -Status PASS -Message "Configured via MDM"
}

# Check for DirectAccess
$daConfig = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableDirectAccessDnsResolution" -ErrorAction SilentlyContinue
if ($daConfig -and $daConfig.EnableDirectAccessDnsResolution -eq 1) {
    Register-Check -Name "DirectAccess" -Status INFO -Message "Configured"
}

# Check VPN before logon capability
$vpnBeforeLogon = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator" -ErrorAction SilentlyContinue
if ($vpnBeforeLogon) {
    Register-Check -Name "VPN Before Logon" -Status INFO -Message "Policy configured"
}

# Summary of installed VPN clients
$installedClients = @()
if ($acInstalled) { $installedClients += "AnyConnect" }
if ($gpInstalled) { $installedClients += "GlobalProtect" }
if ($zscalerInstalled) { $installedClients += "Zscaler" }
if ($fortiInstalled) { $installedClients += "FortiClient" }
if ($pulseInstalled) { $installedClients += $vendor }
if ($openVpnInstalled) { $installedClients += "OpenVPN" }

Write-Output ""
if ($installedClients.Count -gt 0) {
    Register-Check -Name "VPN Clients Summary" -Status INFO -Message ($installedClients -join ", ")
} else {
    Register-Check -Name "VPN Clients Summary" -Status WARN -Message "No enterprise VPN client detected"
}

Print-Summary
Exit-Audit
