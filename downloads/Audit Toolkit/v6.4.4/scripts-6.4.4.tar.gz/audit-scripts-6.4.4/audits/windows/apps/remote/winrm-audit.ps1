# WinRM Security Audit Script (PowerShell)
# Audit for Windows Remote Management (WinRM) on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: WinRM Service Status
$winrm = Get-Service -Name 'WinRM' -ErrorAction SilentlyContinue
if (-not $winrm -or $winrm.Status -ne 'Running') {
    Register-Check -Name "WinRM Service" -Status SKIP -Message "Not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "WinRM Service" -Status PASS -Message "WinRM running."

# Section: Authentication
# (Manual) Review authentication methods for WinRM
Register-Check -Name "WinRM Authentication" -Status WARN -Message "Review authentication methods for WinRM (manual)."

# Section: Encryption
# (Manual) Review encryption settings for WinRM
Register-Check -Name "WinRM Encryption" -Status WARN -Message "Review encryption settings for WinRM (manual)."

# Section: Logging
# (Manual) Review logging and audit trails for WinRM
Register-Check -Name "WinRM Logging" -Status WARN -Message "Review logging and audit trails for WinRM (manual)."

# Section: Exposure
# (Manual) Review exposure of WinRM to public networks
Register-Check -Name "WinRM Exposure" -Status WARN -Message "Review exposure of WinRM to public networks (manual)."

Print-Summary
Exit-Audit
