<#
.SYNOPSIS
    Third-Party EDR/Endpoint Security Audit

.DESCRIPTION
    Security audit for third-party Endpoint Detection and Response solutions:
    - CrowdStrike Falcon
    - SentinelOne
    - Carbon Black
    - Sophos Intercept X
    - Symantec Endpoint Protection
    - ESET Endpoint Security
    - Trend Micro Apex One
    - Palo Alto Cortex XDR
    Installation, service status, and configuration checks

.NOTES
    @elevation: partial
    @elevation-reason: Service queries work without admin; detailed config and some registry paths require elevation
    Requires: Admin rights for full audit

Compliance Mapping:
- CIS Controls: 10.1 (Deploy Malware Defense), 10.2 (Configure Auto AV Updates)
- NIST SP 800-53: SI-3 (Malicious Code Protection), SI-4 (System Monitoring)
- PCI-DSS: 5.1, 5.2, 5.3 (Anti-malware Programs)
- MITRE ATT&CK: T1562 (Impair Defenses)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Third-Party EDR/Endpoint Security Audit"

$edrFound = $false

# ============================================================================
# CROWDSTRIKE FALCON
# ============================================================================
Write-Section "CrowdStrike Falcon"

$crowdstrikeSvc = Get-Service -Name "CSFalconService" -ErrorAction SilentlyContinue

if ($crowdstrikeSvc) {
    $edrFound = $true
    Register-Check -Name "CrowdStrike Falcon" -Status PASS -Message "Installed"

    if ($crowdstrikeSvc.Status -eq 'Running') {
        Register-Check -Name "CrowdStrike Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "CrowdStrike Service" -Status FAIL -Message "Not running: $($crowdstrikeSvc.Status)"
    }

    # Check sensor version
    $csAgentPath = "${env:ProgramFiles}\CrowdStrike\CSFalconService.exe"
    if (Test-Path $csAgentPath) {
        try {
            $csVersion = (Get-Item $csAgentPath).VersionInfo.ProductVersion
            Register-Check -Name "CrowdStrike Version" -Status INFO -Message $csVersion
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    # Check for CSAgentReporter
    $csReporter = Get-Service -Name "CSAgentReporter" -ErrorAction SilentlyContinue
    if ($csReporter -and $csReporter.Status -eq 'Running') {
        Register-Check -Name "CrowdStrike Reporter" -Status PASS -Message "Running"
    }

    # Check registry for configuration
    $csRegPath = "HKLM:\SYSTEM\CrowdStrike\{9b03c1d9-3138-44ed-9fae-d9f4190dc7d9}\{16e0423f-7058-48c9-a204-725362b67639}"
    if (Test-Path $csRegPath) {
        try {
            $cid = Get-ItemProperty -Path $csRegPath -Name "CID" -ErrorAction SilentlyContinue
            if ($cid) {
                Register-Check -Name "CrowdStrike CID" -Status PASS -Message "Configured"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# SENTINELONE
# ============================================================================
Write-Section "SentinelOne"

$sentinelSvc = Get-Service -Name "SentinelAgent" -ErrorAction SilentlyContinue

if ($sentinelSvc) {
    $edrFound = $true
    Register-Check -Name "SentinelOne" -Status PASS -Message "Installed"

    if ($sentinelSvc.Status -eq 'Running') {
        Register-Check -Name "SentinelOne Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "SentinelOne Service" -Status FAIL -Message "Not running: $($sentinelSvc.Status)"
    }

    # Check version
    $s1AgentPath = "${env:ProgramFiles}\SentinelOne\Sentinel Agent*"
    $s1Path = Get-ChildItem -Path $s1AgentPath -Directory -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($s1Path) {
        $s1Exe = Join-Path $s1Path.FullName "SentinelAgent.exe"
        if (Test-Path $s1Exe) {
            try {
                $s1Version = (Get-Item $s1Exe).VersionInfo.ProductVersion
                Register-Check -Name "SentinelOne Version" -Status INFO -Message $s1Version
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }

    # Check static engine
    $s1StaticSvc = Get-Service -Name "SentinelStaticEngine*" -ErrorAction SilentlyContinue
    if ($s1StaticSvc -and $s1StaticSvc.Status -eq 'Running') {
        Register-Check -Name "SentinelOne Static Engine" -Status PASS -Message "Running"
    }
}

# ============================================================================
# CARBON BLACK
# ============================================================================
Write-Section "Carbon Black"

# Carbon Black Cloud Sensor
$cbSvc = Get-Service -Name "CarbonBlack*" -ErrorAction SilentlyContinue | Select-Object -First 1

if ($cbSvc) {
    $edrFound = $true
    Register-Check -Name "Carbon Black" -Status PASS -Message "Installed"

    if ($cbSvc.Status -eq 'Running') {
        Register-Check -Name "Carbon Black Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Carbon Black Service" -Status FAIL -Message "Not running"
    }

    # Check for CB Defense vs CB Response
    $cbDefenseSvc = Get-Service -Name "CbDefense" -ErrorAction SilentlyContinue
    $cbResponseSvc = Get-Service -Name "CarbonBlackSensor" -ErrorAction SilentlyContinue

    if ($cbDefenseSvc) {
        Register-Check -Name "Carbon Black Type" -Status INFO -Message "CB Defense (Cloud)"
    } elseif ($cbResponseSvc) {
        Register-Check -Name "Carbon Black Type" -Status INFO -Message "CB Response (On-Prem)"
    }
}

# ============================================================================
# SOPHOS INTERCEPT X
# ============================================================================
Write-Section "Sophos"

$sophosSvc = Get-Service -Name "Sophos*" -ErrorAction SilentlyContinue | Select-Object -First 1

if ($sophosSvc) {
    $edrFound = $true
    Register-Check -Name "Sophos" -Status PASS -Message "Installed"

    # Key Sophos services
    $sophosServices = @{
        "Sophos Endpoint Defense Service" = "SAVService"
        "Sophos MCS Agent" = "Sophos MCS Agent"
        "Sophos Health Service" = "Sophos Health Service"
    }

    foreach ($svc in $sophosServices.GetEnumerator()) {
        $service = Get-Service -Name $svc.Value -ErrorAction SilentlyContinue
        if ($service) {
            if ($service.Status -eq 'Running') {
                Register-Check -Name $svc.Key -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Key -Status WARN -Message $service.Status
            }
        }
    }

    # Check Intercept X
    $interceptXSvc = Get-Service -Name "HitmanPro.Alert" -ErrorAction SilentlyContinue
    if ($interceptXSvc) {
        if ($interceptXSvc.Status -eq 'Running') {
            Register-Check -Name "Sophos Intercept X" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Sophos Intercept X" -Status WARN -Message $interceptXSvc.Status
        }
    }
}

# ============================================================================
# SYMANTEC ENDPOINT PROTECTION
# ============================================================================
Write-Section "Symantec/Broadcom Endpoint Protection"

$symantecSvc = Get-Service -Name "SepMasterService" -ErrorAction SilentlyContinue

if ($symantecSvc) {
    $edrFound = $true
    Register-Check -Name "Symantec SEP" -Status PASS -Message "Installed"

    if ($symantecSvc.Status -eq 'Running') {
        Register-Check -Name "SEP Master Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "SEP Master Service" -Status FAIL -Message "Not running"
    }

    # Additional SEP services
    $sepServices = @("ccSvcHst", "SmcService", "SNAC")
    foreach ($svcName in $sepServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq 'Running') {
            Register-Check -Name "SEP $svcName" -Status PASS -Message "Running"
        }
    }

    # Check definitions
    $sepDefsPath = "${env:ProgramData}\Symantec\Symantec Endpoint Protection\CurrentVersion\Data\Definitions\VirusDefs"
    if (Test-Path $sepDefsPath) {
        $latestDef = Get-ChildItem -Path $sepDefsPath -Directory -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending | Select-Object -First 1
        if ($latestDef) {
            Register-Check -Name "SEP Definitions" -Status INFO -Message $latestDef.Name
        }
    }
}

# ============================================================================
# ESET ENDPOINT SECURITY
# ============================================================================
Write-Section "ESET Endpoint Security"

$esetSvc = Get-Service -Name "ekrn" -ErrorAction SilentlyContinue

if ($esetSvc) {
    $edrFound = $true
    Register-Check -Name "ESET" -Status PASS -Message "Installed"

    if ($esetSvc.Status -eq 'Running') {
        Register-Check -Name "ESET Kernel Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "ESET Kernel Service" -Status FAIL -Message "Not running"
    }

    # Check ESET modules
    $esetSvcAgent = Get-Service -Name "EraAgentSvc" -ErrorAction SilentlyContinue
    if ($esetSvcAgent -and $esetSvcAgent.Status -eq 'Running') {
        Register-Check -Name "ESET Management Agent" -Status PASS -Message "Connected to ESMC/ESET PROTECT"
    }
}

# ============================================================================
# TREND MICRO
# ============================================================================
Write-Section "Trend Micro"

$trendSvc = Get-Service -Name "Tmccsf" -ErrorAction SilentlyContinue
if (-not $trendSvc) {
    $trendSvc = Get-Service -Name "ntrtscan" -ErrorAction SilentlyContinue
}

if ($trendSvc) {
    $edrFound = $true
    Register-Check -Name "Trend Micro" -Status PASS -Message "Installed"

    if ($trendSvc.Status -eq 'Running') {
        Register-Check -Name "Trend Micro Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Trend Micro Service" -Status FAIL -Message "Not running"
    }

    # Check for Apex One specific service
    $apexOneSvc = Get-Service -Name "Trend Micro Endpoint Agent" -ErrorAction SilentlyContinue
    if ($apexOneSvc) {
        Register-Check -Name "Trend Micro Apex One" -Status INFO -Message $apexOneSvc.Status
    }
}

# ============================================================================
# PALO ALTO CORTEX XDR
# ============================================================================
Write-Section "Palo Alto Cortex XDR"

$cortexSvc = Get-Service -Name "cyserver" -ErrorAction SilentlyContinue

if ($cortexSvc) {
    $edrFound = $true
    Register-Check -Name "Cortex XDR" -Status PASS -Message "Installed"

    if ($cortexSvc.Status -eq 'Running') {
        Register-Check -Name "Cortex XDR Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Cortex XDR Service" -Status FAIL -Message "Not running"
    }

    # Check for Traps service (legacy name)
    $trapsSvc = Get-Service -Name "CyveraService" -ErrorAction SilentlyContinue
    if ($trapsSvc) {
        Register-Check -Name "Cortex Agent" -Status INFO -Message $trapsSvc.Status
    }
}

# ============================================================================
# MCAFEE / TRELLIX
# ============================================================================
Write-Section "McAfee/Trellix"

$mcafeeSvc = Get-Service -Name "McAfeeFramework" -ErrorAction SilentlyContinue
if (-not $mcafeeSvc) {
    $mcafeeSvc = Get-Service -Name "mfemms" -ErrorAction SilentlyContinue
}

if ($mcafeeSvc) {
    $edrFound = $true
    Register-Check -Name "McAfee/Trellix" -Status PASS -Message "Installed"

    if ($mcafeeSvc.Status -eq 'Running') {
        Register-Check -Name "McAfee Framework" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "McAfee Framework" -Status FAIL -Message "Not running"
    }

    # ENS services
    $ensSvc = Get-Service -Name "mfefire" -ErrorAction SilentlyContinue
    if ($ensSvc) {
        Register-Check -Name "McAfee Firewall" -Status INFO -Message $ensSvc.Status
    }
}

# ============================================================================
# SUMMARY
# ============================================================================
Write-Section "EDR Summary"

if (-not $edrFound) {
    Register-Check -Name "Third-Party EDR" -Status WARN -Message "No third-party EDR detected"

    # Check for Windows Defender as fallback
    $defenderSvc = Get-Service -Name "WinDefend" -ErrorAction SilentlyContinue
    if ($defenderSvc -and $defenderSvc.Status -eq 'Running') {
        Register-Check -Name "Windows Defender" -Status INFO -Message "Running (built-in protection)"
    }
} else {
    Register-Check -Name "EDR Protection" -Status PASS -Message "Third-party EDR active"
}

# Check for multiple EDR (can cause conflicts)
$activeEDRs = @()
$edrServices = @("CSFalconService", "SentinelAgent", "CarbonBlack*", "SAVService", "SepMasterService", "ekrn", "ntrtscan", "cyserver", "McAfeeFramework")
foreach ($svcPattern in $edrServices) {
    $svc = Get-Service -Name $svcPattern -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' }
    if ($svc) {
        $activeEDRs += $svc.DisplayName
    }
}

if ($activeEDRs.Count -gt 1) {
    Register-Check -Name "Multiple EDR" -Status WARN -Message "$($activeEDRs.Count) running - potential conflict"
}

Print-Summary
Exit-Audit
