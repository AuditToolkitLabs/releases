# Windows Security Baseline Audit Script (PowerShell)
# Simplified baseline audit for Windows host security
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Server Benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_server

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Local User/Group Security
try {
    $admins = Get-LocalGroupMember -Group 'Administrators' -ErrorAction SilentlyContinue
    $adminCount = ($admins | Measure-Object).Count
    if ($adminCount -le 2) {
        Register-Check -Name "Administrators Group" -Status PASS -Message "Administrators group has $adminCount members."
    } else {
        Register-Check -Name "Administrators Group" -Status WARN -Message "Administrators group has $adminCount members. Review for excess privileges."
    }
} catch {
    Register-Check -Name "Administrators Group" -Status WARN -Message "Could not check Administrators group: $($_.Exception.Message)"
}

# Section: Password Policy
try {
    $policy = Get-LocalUser | Select-Object Name, PasswordRequired
    $weak = $policy | Where-Object { $_.PasswordRequired -eq $false }
    if ($weak) {
        Register-Check -Name "Password Policy" -Status FAIL -Message "Some users do not require passwords."
    } else {
        Register-Check -Name "Password Policy" -Status PASS -Message "All users require passwords."
    }
} catch {
    Register-Check -Name "Password Policy" -Status WARN -Message "Could not check password policy: $($_.Exception.Message)"
}

# Section: Windows Defender/Antivirus
try {
    $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
    if ($defender.AntivirusEnabled) {
        Register-Check -Name "Antivirus Status" -Status PASS -Message "Antivirus enabled."
    } else {
        Register-Check -Name "Antivirus Status" -Status FAIL -Message "Antivirus not enabled."
    }
} catch {
    Register-Check -Name "Antivirus Status" -Status WARN -Message "Could not check antivirus status: $($_.Exception.Message)"
}

# Section: Firewall Configuration
try {
    $fw = Get-NetFirewallProfile | Where-Object { $_.Enabled -eq $true }
    $fwCount = ($fw | Measure-Object).Count
    if ($fwCount -ge 1) {
        Register-Check -Name "Firewall Status" -Status PASS -Message "Firewall enabled on $fwCount profile(s)."
    } else {
        Register-Check -Name "Firewall Status" -Status FAIL -Message "Firewall not enabled."
    }
} catch {
    Register-Check -Name "Firewall Status" -Status WARN -Message "Could not check firewall status: $($_.Exception.Message)"
}

# Section: BitLocker/Encryption
# (Manual) Review BitLocker/encryption status
Register-Check -Name "BitLocker/Encryption" -Status WARN -Message "Review BitLocker/encryption status (manual)."

# Section: Security Updates/Patching
try {
    $updates = Get-HotFix | Where-Object { $_.InstalledOn -gt (Get-Date).AddMonths(-1) }
    $updateCount = ($updates | Measure-Object).Count
    if ($updateCount -ge 1) {
        Register-Check -Name "Security Updates" -Status PASS -Message "$updateCount updates installed in last month."
    } else {
        Register-Check -Name "Security Updates" -Status WARN -Message "No recent security updates found."
    }
} catch {
    Register-Check -Name "Security Updates" -Status WARN -Message "Could not check security updates: $($_.Exception.Message)"
}

# Section: Audit Policy/Event Logging
# (Manual) Review audit policy and event logging
Register-Check -Name "Audit Policy/Event Logging" -Status WARN -Message "Review audit policy and event logging (manual)."

# Section: UAC/Privilege Escalation
# (Manual) Review UAC and privilege escalation controls
Register-Check -Name "UAC/Privilege Escalation" -Status WARN -Message "Review UAC and privilege escalation controls (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - BitLocker/encryption status"
Write-Output " - Audit policy and event logging"
Write-Output " - UAC and privilege escalation controls"
Write-Output ""
Write-Output "Refer to CIS Windows Server Benchmark for detailed manual review procedures."
Print-Summary
Exit-Audit
