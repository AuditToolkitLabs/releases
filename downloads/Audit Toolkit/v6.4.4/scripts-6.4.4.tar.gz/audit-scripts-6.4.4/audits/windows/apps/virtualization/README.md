# Windows Desktop Virtualization Security Audits

Security audits for desktop virtualization software running on Windows.

> **Note**: Enterprise hypervisors (ESXi, Proxmox, Xen) have their own dedicated
> platform at `audits/hypervisors/`. This folder covers desktop virtualization
> tools that run as applications on Windows.

## Planned Audits

### VMware Workstation/Player
**File**: `vmware_workstation.ps1`

**Checks**:
- [ ] VMware services running (`VMwareHostd`, `VMAuthdService`)
- [ ] Installation version and updates
- [ ] VM encryption enabled
- [ ] Shared folders security (disabled by default recommended)
- [ ] USB device auto-connect policy
- [ ] VMware Tools version in VMs
- [ ] Network isolation (NAT, Bridged, Host-Only)
- [ ] VNC access disabled
- [ ] Copy/paste isolation
- [ ] Drag-and-drop isolation

### VMware vSphere Client/PowerCLI
**File**: `vmware_vcenter_client.ps1`

**Checks**:
- [ ] vSphere Client installed
- [ ] PowerCLI module version
- [ ] Certificate validation enabled
- [ ] Saved credentials security
- [ ] Session timeout configured
- [ ] TLS version enforcement

### Oracle VirtualBox
**File**: `virtualbox.ps1`

**Checks**:
- [ ] VirtualBox service (`VBoxSDS`)
- [ ] Installation version (CVE patching)
- [ ] Extension Pack installed and version
- [ ] Host-only network configuration
- [ ] Guest Additions version
- [ ] Clipboard/drag-drop isolation
- [ ] USB controller passthrough
- [ ] 3D acceleration (security implications)
- [ ] Remote Display (VRDE) disabled
- [ ] Shared folders restrictions

---

## Usage

```powershell
# Run individual audit
.\vmware_workstation.ps1

# Run all virtualization audits
Get-ChildItem *.ps1 | ForEach-Object { & $_.FullName }
```

## Dependencies

- PowerShell 5.1+
- Common audit module: `..\..\common\common-audit.psm1`

## Related

- **Hyper-V audits**: `audits/windows/server/hyperv.ps1`
- **Enterprise hypervisors**: `audits/hypervisors/`

## References

- [VMware Workstation Security](https://docs.vmware.com/en/VMware-Workstation-Pro/index.html)
- [VirtualBox Security Guide](https://www.virtualbox.org/manual/ch13.html)
