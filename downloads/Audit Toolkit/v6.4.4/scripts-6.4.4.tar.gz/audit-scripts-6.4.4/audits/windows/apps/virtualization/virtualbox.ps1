<#
.SYNOPSIS
    Oracle VirtualBox Security Audit

.DESCRIPTION
    Audits Oracle VirtualBox configuration including:
    - Service status and version
    - Extension Pack security
    - Host-only network configuration
    - Guest Additions version
    - Clipboard/drag-drop restrictions
    - USB filter policy
    - Hardening mode

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 4.1 (Secure Configuration)
- NIST SP 800-53: CM-7 (Least Functionality), SC-7 (Boundary Protection)
- ISO 27001: A.12.6.1 (Technical Vulnerabilities)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Oracle VirtualBox Security Audit"

# ============================================================================
# VIRTUALBOX INSTALLATION STATUS
# ============================================================================
Write-Section "VirtualBox Installation Status"

$vboxInstalled = $false
$vboxPath = $null
$vboxManage = $null

# Check common installation paths
$vboxPaths = @(
    "$env:ProgramFiles\Oracle\VirtualBox",
    "$env:ProgramFiles (x86)\Oracle\VirtualBox"
)

foreach ($path in $vboxPaths) {
    if (Test-Path $path) {
        $vboxInstalled = $true
        $vboxPath = $path
        $vboxManage = Join-Path $path "VBoxManage.exe"
        Register-Check -Name "VirtualBox Installation" -Status PASS -Message "Found"
        Register-Check -Name "Install Path" -Status PASS -Message $path
        break
    }
}

# Check version via registry
$vboxRegPath = "HKLM:\SOFTWARE\Oracle\VirtualBox"
if (Test-Path $vboxRegPath) {
    $vboxReg = Get-ItemProperty $vboxRegPath -ErrorAction SilentlyContinue
    if ($vboxReg.VersionExt) {
        Register-Check -Name "VirtualBox Version" -Status PASS -Message "v$($vboxReg.VersionExt)"
        $vboxInstalled = $true
    } elseif ($vboxReg.Version) {
        Register-Check -Name "VirtualBox Version" -Status PASS -Message "v$($vboxReg.Version)"
        $vboxInstalled = $true
    }
    if ($vboxReg.InstallDir -and -not $vboxPath) {
        $vboxPath = $vboxReg.InstallDir
        $vboxManage = Join-Path $vboxPath "VBoxManage.exe"
    }
}

if (-not $vboxInstalled) {
    Register-Check -Name "Oracle VirtualBox" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# VIRTUALBOX SERVICES
# ============================================================================
Write-Section "VirtualBox Services"

$vboxServices = @(
    @{ Name = "VBoxSDS"; DisplayName = "VirtualBox System Service" },
    @{ Name = "VBoxDRV"; DisplayName = "VirtualBox Driver" }
)

foreach ($svc in $vboxServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# EXTENSION PACK
# ============================================================================
Write-Section "Extension Pack"

if (Test-Path $vboxManage) {
    try {
        $extPacks = & $vboxManage list extpacks 2>$null
        if ($extPacks) {
            if ($extPacks -match 'Extension Packs:\s*0') {
                Register-Check -Name "Extension Packs" -Status PASS -Message "None installed"
            } else {
                # Parse extension pack details
                $packCount = ($extPacks | Where-Object { $_ -match '^Pack no\.' }).Count
                $versions = $extPacks | Where-Object { $_ -match '^Version:' } | ForEach-Object { ($_ -split ':')[1].Trim() }
                $usable = $extPacks | Where-Object { $_ -match '^Usable:' } | ForEach-Object { ($_ -split ':')[1].Trim() }

                if ($packCount -gt 0) {
                    $version = $versions | Select-Object -First 1
                    $isUsable = $usable | Select-Object -First 1

                    if ($isUsable -eq 'true') {
                        Register-Check -Name "Extension Pack" -Status PASS -Message "v$version (active)"
                    } else {
                        Register-Check -Name "Extension Pack" -Status WARN -Message "v$version (not usable)"
                    }

                    # Check if extension pack is outdated vs VirtualBox version
                    $vboxVer = (Get-ItemProperty $vboxRegPath -ErrorAction SilentlyContinue).Version
                    if ($vboxVer -and $version -and $vboxVer -ne $version) {
                        Register-Check -Name "Extension Pack Version Match" -Status WARN -Message "Pack v$version != VBox v$vboxVer"
                    }
                }
            }
        }
    } catch {
        Register-Check -Name "Extension Packs" -Status WARN -Message "Unable to query"
    }
} else {
    Register-Check -Name "VBoxManage" -Status WARN -Message "Not found"
}

# ============================================================================
# HOST-ONLY NETWORKS
# ============================================================================
Write-Section "Network Configuration"

if (Test-Path $vboxManage) {
    try {
        # List host-only networks
        $hostonlyNets = & $vboxManage list hostonlyifs 2>$null
        if ($hostonlyNets -and $hostonlyNets -notmatch 'No host-only') {
            $netCount = ($hostonlyNets | Where-Object { $_ -match '^Name:' }).Count
            Register-Check -Name "Host-Only Networks" -Status PASS -Message "$netCount network(s)"

            # Check DHCP servers
            $dhcpServers = & $vboxManage list dhcpservers 2>$null
            if ($dhcpServers -and $dhcpServers -notmatch 'DHCP Servers:\s*0') {
                $dhcpCount = ($dhcpServers | Where-Object { $_ -match '^NetworkName:' }).Count
                Register-Check -Name "DHCP Servers" -Status PASS -Message "$dhcpCount server(s)"
            }
        } else {
            Register-Check -Name "Host-Only Networks" -Status PASS -Message "None configured"
        }

        # List NAT networks
        $natNets = & $vboxManage list natnets 2>$null
        if ($natNets -and $natNets -notmatch 'NAT Networks:\s*0') {
            $natCount = ($natNets | Where-Object { $_ -match '^NetworkName:' }).Count
            Register-Check -Name "NAT Networks" -Status PASS -Message "$natCount network(s)"
        }

        # Check bridged interfaces
        $bridgedIfs = & $vboxManage list bridgedifs 2>$null
        if ($bridgedIfs) {
            $bridgedCount = ($bridgedIfs | Where-Object { $_ -match '^Name:' }).Count
            Register-Check -Name "Bridged Interfaces" -Status PASS -Message "$bridgedCount available"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# VIRTUAL MACHINE SECURITY
# ============================================================================
Write-Section "Virtual Machine Security"

if (Test-Path $vboxManage) {
    try {
        $vms = & $vboxManage list vms 2>$null
        if ($vms) {
            $vmList = $vms | ForEach-Object {
                if ($_ -match '"([^"]+)"\s+\{([^\}]+)\}') {
                    @{ Name = $Matches[1]; UUID = $Matches[2] }
                }
            }

            $vmCount = $vmList.Count
            Register-Check -Name "Registered VMs" -Status PASS -Message "$vmCount VM(s)"

            # Analyze first few VMs for security settings
            $clipboardEnabled = 0
            $dragDropEnabled = 0
            $sharedFoldersEnabled = 0

            foreach ($vm in $vmList | Select-Object -First 5) {
                $vmInfo = & $vboxManage showvminfo $vm.UUID --machinereadable 2>$null
                if ($vmInfo) {
                    # Check clipboard
                    $clipboard = $vmInfo | Where-Object { $_ -match '^clipboard=' }
                    if ($clipboard -and $clipboard -notmatch 'disabled') {
                        $clipboardEnabled++
                    }

                    # Check drag-drop
                    $draganddrop = $vmInfo | Where-Object { $_ -match '^draganddrop=' }
                    if ($draganddrop -and $draganddrop -notmatch 'disabled') {
                        $dragDropEnabled++
                    }

                    # Check shared folders
                    $sharedFolders = $vmInfo | Where-Object { $_ -match '^SharedFolderName' }
                    if ($sharedFolders) {
                        $sharedFoldersEnabled++
                    }
                }
            }

            if ($clipboardEnabled -gt 0) {
                Register-Check -Name "Clipboard Sharing" -Status WARN -Message "$clipboardEnabled VM(s) with clipboard enabled"
            } else {
                Register-Check -Name "Clipboard Sharing" -Status PASS -Message "Disabled on all checked VMs"
            }

            if ($dragDropEnabled -gt 0) {
                Register-Check -Name "Drag and Drop" -Status WARN -Message "$dragDropEnabled VM(s) with drag-drop enabled"
            } else {
                Register-Check -Name "Drag and Drop" -Status PASS -Message "Disabled on all checked VMs"
            }

            if ($sharedFoldersEnabled -gt 0) {
                Register-Check -Name "Shared Folders" -Status WARN -Message "$sharedFoldersEnabled VM(s) with shared folders"
            } else {
                Register-Check -Name "Shared Folders" -Status PASS -Message "No shared folders configured"
            }
        } else {
            Register-Check -Name "Registered VMs" -Status PASS -Message "None"
        }
    } catch {
        Register-Check -Name "VM Enumeration" -Status WARN -Message "Unable to list VMs"
    }
}

# ============================================================================
# USB CONFIGURATION
# ============================================================================
Write-Section "USB Configuration"

if (Test-Path $vboxManage) {
    try {
        $usbFilters = & $vboxManage list usbhost 2>$null
        if ($usbFilters -and $usbFilters -notmatch 'No USB devices') {
            $usbCount = ($usbFilters | Where-Object { $_ -match '^UUID:' }).Count
            Register-Check -Name "USB Devices Available" -Status PASS -Message "$usbCount device(s)"
        } else {
            Register-Check -Name "USB Devices" -Status PASS -Message "None available"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check USB controller extension pack requirement
# USB 2.0/3.0 requires extension pack
$extPackNeeded = $false
if (Test-Path $vboxManage) {
    try {
        $vms = & $vboxManage list vms 2>$null
        if ($vms) {
            $vmList = $vms | ForEach-Object {
                if ($_ -match '"([^"]+)"\s+\{([^\}]+)\}') {
                    $Matches[2]
                }
            }

            foreach ($vmUuid in $vmList | Select-Object -First 3) {
                $vmInfo = & $vboxManage showvminfo $vmUuid --machinereadable 2>$null
                if ($vmInfo -match 'usb="on"' -or $vmInfo -match 'usbxhci="on"' -or $vmInfo -match 'usbehci="on"') {
                    $extPackNeeded = $true
                    break
                }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($extPackNeeded) {
    Register-Check -Name "USB Support" -Status PASS -Message "VMs use USB (Extension Pack recommended)"
}

# ============================================================================
# HARDENING MODE
# ============================================================================
Write-Section "Security Hardening"

# Check for hardening mode (driver signature enforcement)
$vboxDrvPath = Join-Path $vboxPath "drivers"
if (Test-Path $vboxDrvPath) {
    # VirtualBox uses signed drivers - check if they're present
    $signedDrivers = Get-ChildItem $vboxDrvPath -Recurse -Filter "*.sys" -ErrorAction SilentlyContinue |
        Where-Object { (Get-AuthenticodeSignature $_.FullName).Status -eq 'Valid' }

    if ($signedDrivers) {
        Register-Check -Name "Driver Signing" -Status PASS -Message "Drivers are signed"
    } else {
        Register-Check -Name "Driver Signing" -Status WARN -Message "Unable to verify driver signatures"
    }
}

# Check system properties
if (Test-Path $vboxManage) {
    try {
        $sysProps = & $vboxManage list systemproperties 2>$null
        if ($sysProps) {
            # Default machine folder
            $defaultFolder = $sysProps | Where-Object { $_ -match 'Default machine folder:' }
            if ($defaultFolder) {
                $folder = ($defaultFolder -split ':')[1].Trim()
                Register-Check -Name "Default VM Folder" -Status PASS -Message $folder
            }

            # Hardware virtualization
            $hwVirt = $sysProps | Where-Object { $_ -match 'Hardware.*virt' }
            if ($hwVirt -match 'Supported') {
                Register-Check -Name "Hardware Virtualization" -Status PASS -Message "Supported"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check if running with admin rights affects hardening
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin) {
    Register-Check -Name "Audit Running As" -Status PASS -Message "Administrator"
} else {
    Register-Check -Name "Audit Running As" -Status PASS -Message "Standard User"
}

# ============================================================================
# FILE PERMISSIONS
# ============================================================================
Write-Section "File Permissions"

if ($vboxPath) {
    try {
        $installAcl = Get-Acl $vboxPath -ErrorAction SilentlyContinue
        $broadAccess = $installAcl.Access | Where-Object {
            $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "Write|Modify|FullControl"
        }
        if ($broadAccess) {
            Register-Check -Name "Install Directory Permissions" -Status WARN -Message "Writable by non-admins"
        } else {
            Register-Check -Name "Install Directory Permissions" -Status PASS -Message "Restricted to administrators"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check VM folder permissions
$vmFolderPath = "$env:USERPROFILE\VirtualBox VMs"
if (Test-Path $vmFolderPath) {
    try {
        $vmAcl = Get-Acl $vmFolderPath -ErrorAction SilentlyContinue
        $everyoneAccess = $vmAcl.Access | Where-Object {
            $_.IdentityReference -match "Everyone" -and $_.FileSystemRights -match "Read"
        }
        if ($everyoneAccess) {
            Register-Check -Name "VM Folder Permissions" -Status WARN -Message "Readable by Everyone"
        } else {
            Register-Check -Name "VM Folder Permissions" -Status PASS -Message "User-restricted"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# GUEST ADDITIONS
# ============================================================================
Write-Section "Guest Additions"

# Check for Guest Additions ISO
$gaIsoPath = Join-Path $vboxPath "VBoxGuestAdditions.iso"
if (Test-Path $gaIsoPath) {
    $gaDate = (Get-Item $gaIsoPath).LastWriteTime
    Register-Check -Name "Guest Additions ISO" -Status PASS -Message "Available (dated $($gaDate.ToString('yyyy-MM-dd')))"
} else {
    Register-Check -Name "Guest Additions ISO" -Status WARN -Message "Not found in installation directory"
}

# ============================================================================
# LOGGING
# ============================================================================
Write-Section "Logging"

$vboxLogPath = "$env:USERPROFILE\.VirtualBox"
if (Test-Path $vboxLogPath) {
    $logFiles = Get-ChildItem $vboxLogPath -Filter "*.log" -ErrorAction SilentlyContinue
    if ($logFiles) {
        Register-Check -Name "VirtualBox Logs" -Status PASS -Message "$($logFiles.Count) log file(s)"
    }

    # Check VirtualBox.xml for settings
    $vboxXmlPath = Join-Path $vboxLogPath "VirtualBox.xml"
    if (Test-Path $vboxXmlPath) {
        Register-Check -Name "Configuration File" -Status PASS -Message "VirtualBox.xml present"
    }
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
