<#
.SYNOPSIS
    VMware Workstation/Player Security Audit

.DESCRIPTION
    Audits VMware Workstation/Player configuration including:
    - Service status
    - Installation and version
    - VM encryption settings
    - Shared folders security
    - Network configuration
    - USB passthrough policy
    - Security hardening options

.NOTES
    This script is read-only and does not modify system state.

Compliance Mapping:
- CIS Controls: 4.1 (Secure Configuration)
- NIST SP 800-53: CM-7 (Least Functionality), SC-7 (Boundary Protection)
- ISO 27001: A.12.6.1 (Technical Vulnerabilities)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "VMware Workstation/Player Security Audit"

# ============================================================================
# VMWARE INSTALLATION STATUS
# ============================================================================
Write-Section "VMware Installation Status"

$vmwareInstalled = $false
$vmwarePath = $null
$vmwareProduct = $null

# Check common installation paths
$vmwarePaths = @(
    "$env:ProgramFiles\VMware\VMware Workstation",
    "$env:ProgramFiles (x86)\VMware\VMware Workstation",
    "$env:ProgramFiles\VMware\VMware Player",
    "$env:ProgramFiles (x86)\VMware\VMware Player"
)

foreach ($path in $vmwarePaths) {
    if (Test-Path $path) {
        $vmwareInstalled = $true
        $vmwarePath = $path
        if ($path -match 'Player') {
            $vmwareProduct = "VMware Player"
        } else {
            $vmwareProduct = "VMware Workstation"
        }
        Register-Check -Name "VMware Installation" -Status PASS -Message "$vmwareProduct found"
        Register-Check -Name "Install Path" -Status PASS -Message $path
        break
    }
}

# Check version via registry
$vmwareRegPaths = @(
    "HKLM:\SOFTWARE\VMware, Inc.\VMware Workstation",
    "HKLM:\SOFTWARE\VMware, Inc.\VMware Player",
    "HKLM:\SOFTWARE\WOW6432Node\VMware, Inc.\VMware Workstation"
)

foreach ($regPath in $vmwareRegPaths) {
    if (Test-Path $regPath) {
        $vmwareReg = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
        if ($vmwareReg.ProductVersion) {
            Register-Check -Name "VMware Version" -Status PASS -Message "v$($vmwareReg.ProductVersion)"
            $vmwareInstalled = $true
        }
        if ($vmwareReg.InstallPath -and -not $vmwarePath) {
            $vmwarePath = $vmwareReg.InstallPath
        }
        break
    }
}

if (-not $vmwareInstalled) {
    Register-Check -Name "VMware Workstation/Player" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# VMWARE SERVICES
# ============================================================================
Write-Section "VMware Services"

$vmwareServices = @(
    @{ Name = "VMwareHostd"; DisplayName = "VMware Workstation Server" },
    @{ Name = "VMAuthdService"; DisplayName = "VMware Authorization Service" },
    @{ Name = "VMnetDHCP"; DisplayName = "VMware DHCP Service" },
    @{ Name = "VMware NAT Service"; DisplayName = "VMware NAT Service" },
    @{ Name = "VMUSBArbService"; DisplayName = "VMware USB Arbitration Service" }
)

foreach ($svc in $vmwareServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.DisplayName -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.DisplayName -Status WARN -Message "$($service.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# GLOBAL PREFERENCES
# ============================================================================
Write-Section "Global VMware Preferences"

$prefsPath = "$env:APPDATA\VMware\preferences.ini"
if (Test-Path $prefsPath) {
    $prefs = Get-Content $prefsPath -ErrorAction SilentlyContinue
    Register-Check -Name "Preferences File" -Status PASS -Message "Found"

    # Check for important security settings
    $autoUpdate = $prefs | Where-Object { $_ -match 'installerDefaults\.autoSoftwareUpdateEnabled\s*=\s*"?(\w+)"?' }
    if ($autoUpdate -match 'TRUE|yes|1') {
        Register-Check -Name "Auto Software Update" -Status PASS -Message "Enabled"
    } elseif ($autoUpdate -match 'FALSE|no|0') {
        Register-Check -Name "Auto Software Update" -Status WARN -Message "Disabled"
    }

    # Check CEIP
    $ceip = $prefs | Where-Object { $_ -match 'ceip\.enabled\s*=\s*"?(\w+)"?' }
    if ($ceip -match 'FALSE|no|0') {
        Register-Check -Name "CEIP Telemetry" -Status PASS -Message "Disabled"
    }

} else {
    Register-Check -Name "Preferences File" -Status WARN -Message "Not found (using defaults)"
}

# ============================================================================
# VM INVENTORY AND ENCRYPTION
# ============================================================================
Write-Section "Virtual Machine Security"

# Check VM inventory
$vmInventoryPath = "$env:APPDATA\VMware\inventory.vmls"
$vmxFiles = @()

if (Test-Path $vmInventoryPath) {
    $inventory = Get-Content $vmInventoryPath -ErrorAction SilentlyContinue
    $vmConfigs = $inventory | Where-Object { $_ -match '\.vmx"' } | ForEach-Object {
        if ($_ -match '"([^"]+\.vmx)"') { $Matches[1] }
    }

    if ($vmConfigs) {
        Register-Check -Name "VM Inventory" -Status PASS -Message "$($vmConfigs.Count) VM(s) registered"
        $vmxFiles = $vmConfigs
    }
}

# Also scan common VM locations
$commonVmPaths = @(
    "$env:USERPROFILE\Documents\Virtual Machines",
    "$env:USERPROFILE\Virtual Machines",
    "C:\VMs",
    "D:\VMs"
)

foreach ($vmPath in $commonVmPaths) {
    if (Test-Path $vmPath) {
        $foundVmx = Get-ChildItem $vmPath -Recurse -Filter "*.vmx" -ErrorAction SilentlyContinue
        $vmxFiles += $foundVmx.FullName
    }
}

$vmxFiles = $vmxFiles | Select-Object -Unique

# Analyze VM configurations
$encryptedVMs = 0
$unencryptedVMs = 0
$sharedFolderVMs = 0

foreach ($vmx in $vmxFiles | Select-Object -First 10) {
    if (Test-Path $vmx) {
        $vmConfig = Get-Content $vmx -ErrorAction SilentlyContinue

        # Check encryption
        if ($vmConfig | Where-Object { $_ -match 'encryption\.keySafe' }) {
            $encryptedVMs++
        } else {
            $unencryptedVMs++
        }

        # Check shared folders
        if ($vmConfig | Where-Object { $_ -match 'sharedFolder\d+\.present\s*=\s*"TRUE"' }) {
            $sharedFolderVMs++
        }
    }
}

if ($encryptedVMs -gt 0 -or $unencryptedVMs -gt 0) {
    if ($unencryptedVMs -gt 0) {
        Register-Check -Name "VM Encryption" -Status WARN -Message "$unencryptedVMs VM(s) not encrypted"
    } else {
        Register-Check -Name "VM Encryption" -Status PASS -Message "All $encryptedVMs VM(s) encrypted"
    }
}

if ($sharedFolderVMs -gt 0) {
    Register-Check -Name "Shared Folders" -Status WARN -Message "$sharedFolderVMs VM(s) with shared folders enabled"
} else {
    Register-Check -Name "Shared Folders" -Status PASS -Message "No VMs with shared folders"
}

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================
Write-Section "Network Configuration"

# Check VMware network adapters
$vmnetNat = Get-NetAdapter | Where-Object { $_.InterfaceDescription -match 'VMware' }

if ($vmnetNat) {
    Register-Check -Name "VMware Network Adapters" -Status PASS -Message "$($vmnetNat.Count) adapter(s)"

    foreach ($adapter in $vmnetNat) {
        $adapterName = $adapter.Name
        if ($adapter.Status -eq "Up") {
            Register-Check -Name "Adapter: $adapterName" -Status PASS -Message "Up"
        } else {
            Register-Check -Name "Adapter: $adapterName" -Status WARN -Message "$($adapter.Status)"
        }
    }
}

# Check NAT configuration
$natConfPath = "$env:ProgramData\VMware\vmnetnat.conf"
if (Test-Path $natConfPath) {
    $natConf = Get-Content $natConfPath -ErrorAction SilentlyContinue

    # Check for port forwarding (potential security concern)
    $portForwards = $natConf | Where-Object { $_ -match '^\d+\s*=' }
    if ($portForwards) {
        Register-Check -Name "NAT Port Forwarding" -Status WARN -Message "$($portForwards.Count) rule(s) configured"
    } else {
        Register-Check -Name "NAT Port Forwarding" -Status PASS -Message "No forwarding rules"
    }
}

# Check for promiscuous mode
$vmnetConfPath = "$env:ProgramData\VMware\vmnetbridge.conf"
if (Test-Path $vmnetConfPath) {
    Register-Check -Name "Bridge Configuration" -Status PASS -Message "Found"
}

# ============================================================================
# USB AND DEVICE SECURITY
# ============================================================================
Write-Section "USB and Device Security"

# Check USB arbitration service
$usbArbService = Get-Service -Name "VMUSBArbService" -ErrorAction SilentlyContinue
if ($usbArbService -and $usbArbService.Status -eq "Running") {
    Register-Check -Name "USB Arbitration" -Status PASS -Message "Running (USB passthrough enabled)"
} elseif ($usbArbService) {
    Register-Check -Name "USB Arbitration" -Status PASS -Message "Stopped (USB passthrough disabled)"
}

# Check global USB settings in preferences
if (Test-Path $prefsPath) {
    $prefs = Get-Content $prefsPath -ErrorAction SilentlyContinue

    $usbAutoConnect = $prefs | Where-Object { $_ -match 'usb\.autoConnect\s*=\s*"?(\w+)"?' }
    if ($usbAutoConnect -match 'FALSE|no|0') {
        Register-Check -Name "USB Auto Connect" -Status PASS -Message "Disabled (more secure)"
    } else {
        Register-Check -Name "USB Auto Connect" -Status WARN -Message "Enabled (devices auto-attach to VMs)"
    }
}

# ============================================================================
# SECURITY HARDENING
# ============================================================================
Write-Section "Security Hardening"

# Check for VBS (Virtualization Based Security) compatibility
try {
    $vbsStatus = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction SilentlyContinue
    if ($vbsStatus) {
        if ($vbsStatus.VirtualizationBasedSecurityStatus -eq 2) {
            Register-Check -Name "Windows VBS" -Status WARN -Message "Enabled (may conflict with VMware)"
        } else {
            Register-Check -Name "Windows VBS" -Status PASS -Message "Compatible with VMware"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check Hyper-V status (conflicts with VMware)
$hyperv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -ErrorAction SilentlyContinue
if ($hyperv -and $hyperv.State -eq "Enabled") {
    Register-Check -Name "Hyper-V Status" -Status WARN -Message "Enabled (VMware uses WHP mode)"
} else {
    Register-Check -Name "Hyper-V Status" -Status PASS -Message "Disabled (VMware native mode)"
}

# Check for VMware WHP (Windows Hypervisor Platform) mode
if (Test-Path $prefsPath) {
    $prefs = Get-Content $prefsPath -ErrorAction SilentlyContinue
    $whpMode = $prefs | Where-Object { $_ -match 'ws\.runlevel\s*=\s*"?(\d+)"?' }
    if ($whpMode) {
        # runlevel 1 = restrict, 2 = WHP mode
        if ($whpMode -match '2') {
            Register-Check -Name "VMware Mode" -Status PASS -Message "Windows Hypervisor Platform (WHP)"
        }
    }
}

# ============================================================================
# INSTALLATION PERMISSIONS
# ============================================================================
Write-Section "File Permissions"

if ($vmwarePath) {
    try {
        $installAcl = Get-Acl $vmwarePath -ErrorAction SilentlyContinue
        $broadAccess = $installAcl.Access | Where-Object {
            $_.IdentityReference -match "Everyone|Users" -and $_.FileSystemRights -match "Write|Modify|FullControl"
        }
        if ($broadAccess) {
            Register-Check -Name "Install Directory Permissions" -Status WARN -Message "Writable by non-admins"
        } else {
            Register-Check -Name "Install Directory Permissions" -Status PASS -Message "Restricted to administrators"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check VM directory permissions
foreach ($vmPath in $commonVmPaths | Select-Object -First 2) {
    if (Test-Path $vmPath) {
        try {
            $vmAcl = Get-Acl $vmPath -ErrorAction SilentlyContinue
            $everyoneWrite = $vmAcl.Access | Where-Object {
                $_.IdentityReference -match "Everyone" -and $_.FileSystemRights -match "Write"
            }
            if ($everyoneWrite) {
                Register-Check -Name "VM Directory: $vmPath" -Status WARN -Message "World-writable"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# VMWARE TOOLS
# ============================================================================
Write-Section "VMware Tools (Guest)"

# This runs on host, so we check for Tools ISO availability
$toolsIsoPath = Join-Path $vmwarePath "windows.iso"
if (Test-Path $toolsIsoPath) {
    $toolsVersion = (Get-Item $toolsIsoPath).LastWriteTime
    Register-Check -Name "VMware Tools ISO" -Status PASS -Message "Available (dated $($toolsVersion.ToString('yyyy-MM-dd')))"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
