# Apache Security Audit Script (PowerShell)
# Audit for Apache web server on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Apache Service Status
$apache = Get-Service -Name 'Apache*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $apache) {
    Register-Check -Name "Apache Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "Apache Service" -Status PASS -Message "Apache service running: $($apache.Name)"

# Section: Authentication & Access Control
# (Manual) Review authentication and access control for Apache
Register-Check -Name "Apache Authentication & Access Control" -Status WARN -Message "Review authentication and access control for Apache (manual)."

# Section: SSL/TLS Encryption
# (Manual) Review SSL/TLS certificate and encryption settings for Apache
Register-Check -Name "Apache SSL/TLS Encryption" -Status WARN -Message "Review SSL/TLS certificate and encryption settings for Apache (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for Apache
Register-Check -Name "Apache Patch/Version Status" -Status WARN -Message "Review patch/version status for Apache (manual)."

# Section: Directory Listing & File Exposure
# (Manual) Review directory listing and file exposure settings for Apache
Register-Check -Name "Apache Directory Listing & File Exposure" -Status WARN -Message "Review directory listing and file exposure settings for Apache (manual)."

# Section: Logging & Audit Trails
# (Manual) Review logging and audit trails for Apache
Register-Check -Name "Apache Logging & Audit Trails" -Status WARN -Message "Review logging and audit trails for Apache (manual)."

# Section: Firewall Rules
# (Manual) Review firewall rules for Apache web traffic
Register-Check -Name "Apache Firewall Rules" -Status WARN -Message "Review firewall rules for Apache web traffic (manual)."

Print-Summary
Exit-Audit
