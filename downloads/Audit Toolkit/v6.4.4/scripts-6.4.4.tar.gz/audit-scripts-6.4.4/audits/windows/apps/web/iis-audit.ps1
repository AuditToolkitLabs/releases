# IIS Security Audit Script (PowerShell)
# Audit for Microsoft IIS web server on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: IIS Service Status
$iis = Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue
if (-not $iis -or $iis.Status -ne 'Running') {
    Register-Check -Name "IIS Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "IIS Service" -Status PASS -Message "IIS service running."

# Section: Authentication & Access Control
# (Manual) Review authentication and access control for IIS
Register-Check -Name "IIS Authentication & Access Control" -Status WARN -Message "Review authentication and access control for IIS (manual)."

# Section: SSL/TLS Encryption
# (Manual) Review SSL/TLS certificate and encryption settings for IIS
Register-Check -Name "IIS SSL/TLS Encryption" -Status WARN -Message "Review SSL/TLS certificate and encryption settings for IIS (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for IIS
Register-Check -Name "IIS Patch/Version Status" -Status WARN -Message "Review patch/version status for IIS (manual)."

# Section: Directory Listing & File Exposure
# (Manual) Review directory listing and file exposure settings for IIS
Register-Check -Name "IIS Directory Listing & File Exposure" -Status WARN -Message "Review directory listing and file exposure settings for IIS (manual)."

# Section: Logging & Audit Trails
# (Manual) Review logging and audit trails for IIS
Register-Check -Name "IIS Logging & Audit Trails" -Status WARN -Message "Review logging and audit trails for IIS (manual)."

# Section: Firewall Rules
# (Manual) Review firewall rules for IIS web traffic
Register-Check -Name "IIS Firewall Rules" -Status WARN -Message "Review firewall rules for IIS web traffic (manual)."

Print-Summary
Exit-Audit
