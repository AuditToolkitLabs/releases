# NGINX Security Audit Script (PowerShell)
# Audit for NGINX web server on Windows hosts
# This script is read-only and does not modify system state.

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: NGINX Service Status
$nginx = Get-Service -Name 'nginx*' -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
if (-not $nginx) {
    Register-Check -Name "NGINX Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "NGINX Service" -Status PASS -Message "NGINX service running: $($nginx.Name)"

# Section: Authentication & Access Control
# (Manual) Review authentication and access control for NGINX
Register-Check -Name "NGINX Authentication & Access Control" -Status WARN -Message "Review authentication and access control for NGINX (manual)."

# Section: SSL/TLS Encryption
# (Manual) Review SSL/TLS certificate and encryption settings for NGINX
Register-Check -Name "NGINX SSL/TLS Encryption" -Status WARN -Message "Review SSL/TLS certificate and encryption settings for NGINX (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for NGINX
Register-Check -Name "NGINX Patch/Version Status" -Status WARN -Message "Review patch/version status for NGINX (manual)."

# Section: Directory Listing & File Exposure
# (Manual) Review directory listing and file exposure settings for NGINX
Register-Check -Name "NGINX Directory Listing & File Exposure" -Status WARN -Message "Review directory listing and file exposure settings for NGINX (manual)."

# Section: Logging & Audit Trails
# (Manual) Review logging and audit trails for NGINX
Register-Check -Name "NGINX Logging & Audit Trails" -Status WARN -Message "Review logging and audit trails for NGINX (manual)."

# Section: Firewall Rules
# (Manual) Review firewall rules for NGINX web traffic
Register-Check -Name "NGINX Firewall Rules" -Status WARN -Message "Review firewall rules for NGINX web traffic (manual)."

Print-Summary
Exit-Audit
