# Web Server Baseline Security Audit Script (PowerShell)
# Simplified baseline audit for web servers on Windows hosts
# This script is read-only and does not modify system state.
#
# References:
# - CIS IIS Benchmark: https://www.cisecurity.org/benchmark/microsoft_iis
# - Microsoft IIS Security: https://learn.microsoft.com/en-us/iis/manage/security/

Import-Module "$PSScriptRoot/../../common/common-audit.psm1"

# Section: Web Service Status
$iis = Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue
if (-not $iis -or $iis.Status -ne 'Running') {
    Register-Check -Name "IIS Service" -Status SKIP -Message "Not installed or not running"
    Print-Summary
    Exit-Audit
}
Register-Check -Name "IIS Service" -Status PASS -Message "IIS service running."

# Section: Authentication & Access Control
# (Manual) Review authentication and access control for web server
Register-Check -Name "Authentication & Access Control" -Status WARN -Message "Review authentication and access control for web server (manual)."

# Section: SSL/TLS Encryption
# (Manual) Review SSL/TLS certificate and encryption settings
Register-Check -Name "SSL/TLS Encryption" -Status WARN -Message "Review SSL/TLS certificate and encryption settings (manual)."

# Section: Patch/Version Status
# (Manual) Review patch/version status for web server
Register-Check -Name "Patch/Version Status" -Status WARN -Message "Review patch/version status for web server (manual)."

# Section: Directory Listing & File Exposure
# (Manual) Review directory listing and file exposure settings
Register-Check -Name "Directory Listing & File Exposure" -Status WARN -Message "Review directory listing and file exposure settings (manual)."

# Section: Logging & Audit Trails
# (Manual) Review logging and audit trails for web server
Register-Check -Name "Logging & Audit Trails" -Status WARN -Message "Review logging and audit trails for web server (manual)."

# Section: Firewall Rules
# (Manual) Review firewall rules for web traffic
Register-Check -Name "Firewall Rules" -Status WARN -Message "Review firewall rules for web traffic (manual)."

# Guidance Section
Write-Output "[GUIDANCE] The following items require manual review:"
Write-Output " - Authentication and access control for web server"
Write-Output " - SSL/TLS certificate and encryption settings"
Write-Output " - Patch/version status for web server"
Write-Output " - Directory listing and file exposure settings"
Write-Output " - Logging and audit trails for web server"
Write-Output " - Firewall rules for web traffic"
Write-Output ""
Write-Output "Refer to CIS IIS Benchmark and Microsoft IIS Security Best Practices for detailed manual review procedures."
Print-Summary
Exit-Audit
