# Windows Common Audit Scripts

This folder contains PowerShell audit scripts for Windows settings that apply to both servers and desktops, aligned with CIS hardening guidelines and the provided checklist.

## Scripts to implement (examples):
- os_version.ps1
- patch_level.ps1
- secure_boot.ps1
- tpm_status.ps1
- lsass_protection.ps1
- credential_guard.ps1
- winlogon.ps1
- kerberos_policy.ps1
- ntlm_restrictions.ps1
- dns_client_service.ps1
- dhcp_client_service.ps1
- windows_firewall.ps1
- smb_configuration.ps1
- netbios_llmnr.ps1
- winrm.ps1
- windows_update_service.ps1
- bits_service.ps1
- task_scheduler.ps1
- event_log_services.ps1
- defender_av.ps1
- smartscreen.ps1
- exploit_guard.ps1
- uac.ps1
- bitlocker.ps1
- rdp_configuration.ps1
- remote_assistance.ps1
- remote_registry.ps1
- ps_remoting.ps1
- office_macros.ps1
- powershell_logging.ps1
- cmd_elevation.ps1
- mmc_permissions.ps1
- registry_editor.ps1
- tls_versions.ps1
- wpad_mdns.ps1
- audit_policy.ps1
- event_log_size.ps1
- ntfs_permissions.ps1
- vss_shadow_copies.ps1
- shares.ps1
- gpo_baseline.ps1
- gpo_permissions.ps1
- wsus_sccm.ps1
- driver_updates.ps1
- secure_boot.ps1
- tpm.ps1
- firmware_updates.ps1

See each script for details and example checks.
