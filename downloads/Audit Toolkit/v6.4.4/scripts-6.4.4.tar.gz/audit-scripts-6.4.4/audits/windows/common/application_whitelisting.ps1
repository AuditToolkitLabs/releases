<#
.SYNOPSIS
    Application Whitelisting Security Audit (AppLocker & WDAC)

.DESCRIPTION
    Audits application control mechanisms:
    - AppLocker policies and enforcement
    - Windows Defender Application Control (WDAC)
    - Software Restriction Policies (legacy)
    - SmartScreen and related controls

.NOTES
    Requires: Local Admin for full checks
    Enterprise features may require Windows 10/11 Enterprise or Server

Compliance Mapping:
- CIS Controls: 2.5 (Allowlist Authorized Software), 2.6 (Allowlist Libraries)
- NIST SP 800-53: CM-7 (Least Functionality), SI-7 (Software Integrity)
- ISO 27001: A.12.5.1 (Installation of Software)
- PCI DSS: 2.2, 6.4 (Change Control)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Application Whitelisting Audit"

# ============================================================================
# APPLOCKER STATUS
# ============================================================================
Write-Section "AppLocker"

# Check AppLocker service
try {
    $appIdSvc = Get-Service -Name AppIDSvc -ErrorAction SilentlyContinue
    if ($appIdSvc) {
        if ($appIdSvc.Status -eq 'Running') {
            Register-Check -Name "AppID Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "AppID Service" -Status WARN -Message "Status: $($appIdSvc.Status)"
        }

        if ($appIdSvc.StartType -eq 'Automatic') {
            Register-Check -Name "AppID Startup" -Status PASS -Message "Automatic"
        } else {
            Register-Check -Name "AppID Startup" -Status WARN -Message "$($appIdSvc.StartType)"
        }
    } else {
        Register-Check -Name "AppID Service" -Status SKIP -Message "Not found"
    }
} catch {
    Register-Check -Name "AppID Service" -Status SKIP -Message "Cannot query"
}

# Get AppLocker Policy
$applockerConfigured = $false
try {
    $applockerPolicy = Get-AppLockerPolicy -Effective -ErrorAction Stop
    $applockerConfigured = $true

    $ruleCollections = $applockerPolicy.RuleCollections

    foreach ($collection in $ruleCollections) {
        $collType = $collection.RuleCollectionType
        $mode = $collection.EnforcementMode
        $ruleCount = $collection.Count

        if ($ruleCount -gt 0) {
            if ($mode -eq "Enabled" -or $mode -eq "Enforced") {
                Register-Check -Name "AppLocker $collType" -Status PASS -Message "Enforced ($ruleCount rules)"
            } elseif ($mode -eq "AuditOnly") {
                Register-Check -Name "AppLocker $collType" -Status WARN -Message "Audit mode ($ruleCount rules)"
            } else {
                Register-Check -Name "AppLocker $collType" -Status WARN -Message "Mode: $mode ($ruleCount rules)"
            }
        }
    }

    # Check for default deny rules
    $hasExeRules = ($ruleCollections | Where-Object { $_.RuleCollectionType -eq "Exe" }).Count -gt 0
    $hasScriptRules = ($ruleCollections | Where-Object { $_.RuleCollectionType -eq "Script" }).Count -gt 0
    $hasDllRules = ($ruleCollections | Where-Object { $_.RuleCollectionType -eq "Dll" }).Count -gt 0

    if ($hasExeRules -and $hasScriptRules) {
        Register-Check -Name "AppLocker Coverage" -Status PASS -Message "Exe and Script rules configured"
    } elseif ($hasExeRules) {
        Register-Check -Name "AppLocker Coverage" -Status WARN -Message "Only Exe rules - consider adding Script rules"
    } else {
        Register-Check -Name "AppLocker Coverage" -Status WARN -Message "Limited rule coverage"
    }

    if ($hasDllRules) {
        Register-Check -Name "AppLocker DLL Rules" -Status PASS -Message "DLL rules enabled (performance impact)"
    }

} catch {
    Register-Check -Name "AppLocker Policy" -Status SKIP -Message "No policy or cannot retrieve"
}

# Check AppLocker via registry as backup
if (-not $applockerConfigured) {
    try {
        $srpv2Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\SrpV2"
        if (Test-Path $srpv2Path) {
            $collections = Get-ChildItem $srpv2Path -ErrorAction SilentlyContinue
            if ($collections) {
                Register-Check -Name "AppLocker Registry" -Status WARN -Message "Policy in registry but not applied"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# WINDOWS DEFENDER APPLICATION CONTROL (WDAC)
# ============================================================================
Write-Section "Windows Defender Application Control (WDAC)"

$wdacConfigured = $false

# Check for WDAC policies via CIM
try {
    $ciPolicies = Get-CimInstance -Namespace root\Microsoft\Windows\CI -ClassName Win32_CIPolicy -ErrorAction SilentlyContinue

    if ($ciPolicies) {
        $wdacConfigured = $true

        foreach ($policy in $ciPolicies) {
            $policyId = $policy.PolicyId
            $isEnforced = $policy.IsEnforced
            $isAudit = $policy.IsAudit

            if ($isEnforced) {
                Register-Check -Name "WDAC Policy $policyId" -Status PASS -Message "Enforced"
            } elseif ($isAudit) {
                Register-Check -Name "WDAC Policy $policyId" -Status WARN -Message "Audit mode"
            } else {
                Register-Check -Name "WDAC Policy $policyId" -Status WARN -Message "Unknown mode"
            }
        }
    }
} catch {
    # CIM namespace may not exist on older systems
    Write-Verbose 'Suppressed non-fatal error.'
}

# Check Device Guard registry settings
try {
    $dgPath = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard"
    $dgConfig = Get-ItemProperty $dgPath -ErrorAction SilentlyContinue

    if ($dgConfig) {
        # HVIC (Hypervisor-protected Code Integrity)
        if ($dgConfig.HypervisorEnforcedCodeIntegrity -eq 1) {
            Register-Check -Name "HVCI Enabled" -Status PASS -Message "Memory integrity on"
            $wdacConfigured = $true
        }

        # VBS (Virtualization-based Security)
        if ($dgConfig.EnableVirtualizationBasedSecurity -eq 1) {
            Register-Check -Name "VBS Enabled" -Status PASS -Message "Virtualization-based security"
        }

        # Locked (UEFI lock)
        if ($dgConfig.Locked -eq 1) {
            Register-Check -Name "Device Guard Lock" -Status PASS -Message "UEFI locked"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check WDAC via CI policy files
try {
    $sipolicyPath = "$env:SystemRoot\System32\CodeIntegrity\SIPolicy.p7b"
    if (Test-Path $sipolicyPath) {
        $wdacConfigured = $true
        $policyFile = Get-Item $sipolicyPath
        Register-Check -Name "WDAC Policy File" -Status PASS -Message "SIPolicy.p7b present ($([int]($policyFile.Length/1KB)) KB)"
    }

    # Check for multiple policies (Windows 10 1903+)
    $ciPoliciesPath = "$env:SystemRoot\System32\CodeIntegrity\CIPolicies\Active"
    if (Test-Path $ciPoliciesPath) {
        $activePolicies = Get-ChildItem $ciPoliciesPath -Filter "*.cip" -ErrorAction SilentlyContinue
        $policyCount = @($activePolicies).Count
        if ($policyCount -gt 0) {
            Register-Check -Name "WDAC Active Policies" -Status PASS -Message "$policyCount policy file(s)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if (-not $wdacConfigured) {
    Register-Check -Name "WDAC" -Status WARN -Message "Not configured (consider for high-security environments)"
}

# ============================================================================
# SMART APP CONTROL (Windows 11 22H2+)
# ============================================================================
Write-Section "Smart App Control"

try {
    $sacPath = "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy"
    $sacConfig = Get-ItemProperty $sacPath -Name "VerifiedAndReputablePolicyState" -ErrorAction SilentlyContinue

    if ($sacConfig) {
        $state = $sacConfig.VerifiedAndReputablePolicyState
        switch ($state) {
            0 { Register-Check -Name "Smart App Control" -Status WARN -Message "Off" }
            1 { Register-Check -Name "Smart App Control" -Status PASS -Message "Evaluation mode" }
            2 { Register-Check -Name "Smart App Control" -Status PASS -Message "Enforced" }
            default { Register-Check -Name "Smart App Control" -Status SKIP -Message "State: $state" }
        }
    } else {
        Register-Check -Name "Smart App Control" -Status SKIP -Message "Not available (Windows 11 22H2+ feature)"
    }
} catch {
    Register-Check -Name "Smart App Control" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# SOFTWARE RESTRICTION POLICIES (Legacy)
# ============================================================================
Write-Section "Software Restriction Policies (Legacy)"

try {
    $srpPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers"
    $srpConfig = Get-ItemProperty $srpPath -ErrorAction SilentlyContinue

    if ($srpConfig) {
        $defaultLevel = $srpConfig.DefaultLevel
        if ($defaultLevel -eq 0) {
            Register-Check -Name "SRP Default Level" -Status PASS -Message "Disallowed (whitelist mode)"
        } elseif ($defaultLevel -eq 262144) {
            Register-Check -Name "SRP Default Level" -Status WARN -Message "Unrestricted (blacklist mode)"
        } else {
            Register-Check -Name "SRP Default Level" -Status WARN -Message "Level: $defaultLevel"
        }

        Register-Check -Name "SRP" -Status WARN -Message "Legacy SRP in use - consider migration to AppLocker/WDAC"
    } else {
        Register-Check -Name "SRP" -Status SKIP -Message "Not configured"
    }
} catch {
    Register-Check -Name "SRP" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# SMARTSCREEN
# ============================================================================
Write-Section "Windows SmartScreen"

try {
    # SmartScreen for Windows
    $ssPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer"
    $ssConfig = Get-ItemProperty $ssPath -Name "SmartScreenEnabled" -ErrorAction SilentlyContinue

    if ($ssConfig.SmartScreenEnabled -eq "RequireAdmin") {
        Register-Check -Name "SmartScreen" -Status PASS -Message "Require admin approval"
    } elseif ($ssConfig.SmartScreenEnabled -eq "Warn") {
        Register-Check -Name "SmartScreen" -Status PASS -Message "Warn users"
    } elseif ($ssConfig.SmartScreenEnabled -eq "Off") {
        Register-Check -Name "SmartScreen" -Status FAIL -Message "Disabled"
    } else {
        Register-Check -Name "SmartScreen" -Status WARN -Message "Unknown state"
    }
} catch {
    Register-Check -Name "SmartScreen" -Status SKIP -Message "Cannot query"
}

# SmartScreen via policy
try {
    $ssPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableSmartScreen" -ErrorAction SilentlyContinue
    if ($ssPolicy.EnableSmartScreen -eq 1) {
        Register-Check -Name "SmartScreen (Policy)" -Status PASS -Message "Enabled via policy"
    } elseif ($ssPolicy.EnableSmartScreen -eq 0) {
        Register-Check -Name "SmartScreen (Policy)" -Status FAIL -Message "Disabled via policy"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CONSTRAINED LANGUAGE MODE
# ============================================================================
Write-Section "PowerShell Constrained Language"

try {
    $clmPolicy = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name "__PSLockdownPolicy" -ErrorAction SilentlyContinue

    if ($clmPolicy.__PSLockdownPolicy) {
        $policy = $clmPolicy.__PSLockdownPolicy
        if ($policy -eq 8) {
            Register-Check -Name "PS Constrained Language" -Status PASS -Message "Enforced system-wide"
        } elseif ($policy -eq 4) {
            Register-Check -Name "PS Constrained Language" -Status PASS -Message "Full language mode"
        } else {
            Register-Check -Name "PS Constrained Language" -Status WARN -Message "Policy value: $policy"
        }
    } else {
        # Check current session
        $languageMode = $ExecutionContext.SessionState.LanguageMode
        if ($languageMode -eq "ConstrainedLanguage") {
            Register-Check -Name "PS Constrained Language" -Status PASS -Message "Current session in CLM"
        } else {
            Register-Check -Name "PS Constrained Language" -Status WARN -Message "Not enforced (current: $languageMode)"
        }
    }
} catch {
    Register-Check -Name "PS Constrained Language" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# OVERALL APPLICATION CONTROL STATUS
# ============================================================================
Write-Section "Overall Assessment"

if ($wdacConfigured) {
    Register-Check -Name "Application Control Level" -Status PASS -Message "WDAC configured - strongest protection"
} elseif ($applockerConfigured) {
    Register-Check -Name "Application Control Level" -Status PASS -Message "AppLocker configured - good protection"
} else {
    Register-Check -Name "Application Control Level" -Status FAIL -Message "No application whitelisting - high risk"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
