# Advanced Audit Policy Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Audit Policy Configuration
# This script is read-only and does not modify system state.
#
# @elevation: admin
# @elevation-reason: AuditPol.exe requires Administrator privileges
#
# References:
# - CIS Windows 11 Benchmark: 17.x
# - Microsoft Audit Policy: https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/

Import-Module "$PSScriptRoot/common-audit.psm1"

# Required CIS audit subcategories (CIS 17.x)
$requiredAudits = @{
    # Account Logon - CIS 17.1.x
    "Credential Validation" = "Success and Failure"
    # Account Management - CIS 17.2.x
    "Computer Account Management" = "Success"
    "Security Group Management" = "Success"
    "User Account Management" = "Success and Failure"
    # Logon/Logoff - CIS 17.5.x
    "Account Lockout" = "Failure"
    "Logoff" = "Success"
    "Logon" = "Success and Failure"
    "Special Logon" = "Success"
    # Object Access - CIS 17.6.x
    "Removable Storage" = "Success and Failure"
    # Policy Change - CIS 17.7.x
    "Audit Policy Change" = "Success"
    "Authentication Policy Change" = "Success"
    "Authorization Policy Change" = "Success"
    # Privilege Use - CIS 17.8.x
    "Sensitive Privilege Use" = "Success and Failure"
    # System - CIS 17.9.x
    "Security State Change" = "Success"
    "Security System Extension" = "Success"
    "System Integrity" = "Success and Failure"
}

# Register privilege level as a check
Register-AdminCheck -Message "AuditPol requires Administrator privileges for full coverage"

try {
    # Get current audit policy (requires admin)
    $auditOutput = Invoke-AdminCommand -ScriptBlock {
        & AuditPol /get /category:* 2>&1
    } -CheckName "Audit Policy Access"

    if ($null -eq $auditOutput -or $LASTEXITCODE -ne 0) {
        # Already registered as SKIP by Invoke-AdminCommand
        Print-Summary
        Exit-Audit
    }

    $passCount = 0
    $failCount = 0

    foreach ($subcategory in $requiredAudits.Keys) {
        $required = $requiredAudits[$subcategory]
        $line = $auditOutput | Where-Object { $_ -match $subcategory }

        if ($line) {
            $hasSuccess = $line -match "Success"
            $hasFailure = $line -match "Failure"

            $configured = $false
            if ($required -eq "Success and Failure") {
                $configured = $hasSuccess -and $hasFailure
            } elseif ($required -eq "Success") {
                $configured = $hasSuccess
            } elseif ($required -eq "Failure") {
                $configured = $hasFailure
            }

            if ($configured) {
                $passCount++
            } else {
                $failCount++
            }
        } else {
            $failCount++
        }
    }

    $total = $requiredAudits.Count
    if ($failCount -eq 0) {
        Register-Check -Name "CIS Audit Policy" -Status PASS -Message "All $total required audit subcategories configured"
    } elseif ($passCount -gt $failCount) {
        Register-Check -Name "CIS Audit Policy" -Status WARN -Message "$passCount of $total required audits configured, $failCount missing"
    } else {
        Register-Check -Name "CIS Audit Policy" -Status FAIL -Message "Only $passCount of $total required audits configured"
    }

    # Check if audit logs are being generated
    $secLog = Get-WinEvent -LogName Security -MaxEvents 1 -ErrorAction SilentlyContinue
    if ($secLog) {
        Register-Check -Name "Security Event Log" -Status PASS -Message "Security events are being logged"
    } else {
        Register-Check -Name "Security Event Log" -Status WARN -Message "No recent security events found"
    }

} catch {
    Register-Check -Name "Advanced Audit Policy" -Status WARN -Message "Could not check audit policy: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit
