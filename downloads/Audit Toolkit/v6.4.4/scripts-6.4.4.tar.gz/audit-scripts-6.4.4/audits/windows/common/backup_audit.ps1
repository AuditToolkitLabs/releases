# Backup Solutions Audit Script (PowerShell)
# Checks backup software configuration and status
# This script is read-only and does not modify system state.
#
# References:
# - NIST SP 800-53: CP-9 (System Backup)
# - CIS Controls 11: Data Recovery

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# WINDOWS BACKUP
# ============================================================================
Write-Section "Windows Backup"

# Windows Backup Service (wbengine)
try {
    $wbService = Get-Service -Name "wbengine" -ErrorAction SilentlyContinue
    if ($wbService) {
        Register-Check -Name "Windows Backup Service" -Status INFO -Message "$($wbService.Status)"
    } else {
        Register-Check -Name "Windows Backup Service" -Status INFO -Message "Not installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Windows Server Backup (if available)
try {
    $wbadmin = Get-Command wbadmin -ErrorAction SilentlyContinue
    if ($wbadmin) {
        Register-Check -Name "wbadmin Available" -Status PASS -Message "Windows Server Backup tools present"

        # Get backup summary
        try {
            $backupSummary = wbadmin get versions -backupTarget:* 2>&1
            if ($backupSummary -notmatch "ERROR") {
                $lastBackup = $backupSummary | Select-String -Pattern "Backup time:" | Select-Object -First 1
                if ($lastBackup) {
                    Register-Check -Name "Last Server Backup" -Status PASS -Message $lastBackup.Line.Trim()
                }
            } else {
                Register-Check -Name "Server Backup History" -Status INFO -Message "No backups found or access denied"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# File History
try {
    $fhService = Get-Service -Name "fhsvc" -ErrorAction SilentlyContinue

    if ($fhService) {
        if ($fhService.Status -eq "Running") {
            Register-Check -Name "File History Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "File History Service" -Status INFO -Message "$($fhService.Status)"
        }
    }

    # Check File History config
    $fhConfig = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\FileHistory\Configuration" -ErrorAction SilentlyContinue
    if ($fhConfig) {
        Register-Check -Name "File History" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# System Restore
try {
    $vssService = Get-Service -Name "VSS" -ErrorAction SilentlyContinue

    if ($vssService -and $vssService.Status -eq "Running") {
        Register-Check -Name "Volume Shadow Copy" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Volume Shadow Copy" -Status INFO -Message "Available on-demand"
    }

    # Check for existing restore points
    try {
        $restorePoints = Get-ComputerRestorePoint -ErrorAction SilentlyContinue
        if ($restorePoints) {
            $latestRP = $restorePoints | Sort-Object CreationTime -Descending | Select-Object -First 1
            $rpCount = $restorePoints.Count
            Register-Check -Name "System Restore Points" -Status PASS -Message "$rpCount point(s), latest: $($latestRP.CreationTime)"
        } else {
            Register-Check -Name "System Restore Points" -Status WARN -Message "None found"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# VEEAM
# ============================================================================
Write-Section "Veeam Backup"

# Veeam Backup Service
try {
    $veeamServices = @(
        @{Name="VeeamBackupSvc"; Display="Veeam Backup Service"},
        @{Name="VeeamEndpointBackupSvc"; Display="Veeam Agent"},
        @{Name="VeeamTransportSvc"; Display="Veeam Data Mover"}
    )

    $veeamFound = $false
    foreach ($svc in $veeamServices) {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $veeamFound = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.Display -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Display -Status WARN -Message "$($service.Status)"
            }
        }
    }

    if (-not $veeamFound) {
        Register-Check -Name "Veeam Backup" -Status INFO -Message "Not installed"
    } else {
        # Check Veeam installation
        $veeamPath = "C:\Program Files\Veeam"
        if (Test-Path $veeamPath) {
            Register-Check -Name "Veeam Installation" -Status PASS -Message "Found"
        }
    }
} catch {
    Register-Check -Name "Veeam" -Status INFO -Message "Not detected"
}

# ============================================================================
# ACRONIS
# ============================================================================
Write-Section "Acronis Backup"

try {
    $acronisServices = @(
        @{Name="AcrSch2Svc"; Display="Acronis Scheduler"},
        @{Name="AcronisAgent"; Display="Acronis Agent"},
        @{Name="afcdpsrv"; Display="Acronis CDP Service"},
        @{Name="MMS"; Display="Acronis Managed Machine Service"}
    )

    $acronisFound = $false
    foreach ($svc in $acronisServices) {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $acronisFound = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.Display -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Display -Status WARN -Message "$($service.Status)"
            }
        }
    }

    if (-not $acronisFound) {
        Register-Check -Name "Acronis Backup" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Acronis" -Status INFO -Message "Not detected"
}

# ============================================================================
# CARBONITE
# ============================================================================
Write-Section "Carbonite Backup"

try {
    $carboniteService = Get-Service -Name "CarboniteService" -ErrorAction SilentlyContinue
    if ($carboniteService) {
        if ($carboniteService.Status -eq "Running") {
            Register-Check -Name "Carbonite Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Carbonite Service" -Status WARN -Message "$($carboniteService.Status)"
        }
    } else {
        Register-Check -Name "Carbonite Backup" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Carbonite" -Status INFO -Message "Not detected"
}

# ============================================================================
# COMMVAULT
# ============================================================================
Write-Section "Commvault"

try {
    $cvServices = @("GxCLMgrS", "GxCVD", "GXMMM")
    $cvFound = $false

    foreach ($svcName in $cvServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $cvFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "Commvault $svcName" -Status PASS -Message "Running"
            } else {
                Register-Check -Name "Commvault $svcName" -Status WARN -Message "$($svc.Status)"
            }
        }
    }

    if (-not $cvFound) {
        Register-Check -Name "Commvault" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Commvault" -Status INFO -Message "Not detected"
}

# ============================================================================
# VERITAS NETBACKUP
# ============================================================================
Write-Section "Veritas NetBackup"

try {
    $nbServices = @("NetBackup Client Service", "NetBackup Legacy Client Service")
    $nbFound = $false

    foreach ($svcName in $nbServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $nbFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "NetBackup Client" -Status PASS -Message "Running"
            } else {
                Register-Check -Name "NetBackup Client" -Status WARN -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $nbFound) {
        Register-Check -Name "NetBackup" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "NetBackup" -Status INFO -Message "Not detected"
}

# ============================================================================
# DATTO / UNITY
# ============================================================================
Write-Section "Datto/Kaseya"

try {
    $dattoService = Get-Service -Name "Datto Windows Agent" -ErrorAction SilentlyContinue
    if (-not $dattoService) {
        $dattoService = Get-Service -Name "ShadowProtect*" -ErrorAction SilentlyContinue
    }

    if ($dattoService) {
        if ($dattoService.Status -eq "Running") {
            Register-Check -Name "Datto Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Datto Agent" -Status WARN -Message "$($dattoService.Status)"
        }
    } else {
        Register-Check -Name "Datto/Kaseya" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Datto" -Status INFO -Message "Not detected"
}

# ============================================================================
# AZURE BACKUP
# ============================================================================
Write-Section "Azure Backup"

try {
    $azureServices = @(
        @{Name="obengine"; Display="Azure Backup Engine"},
        @{Name="AzureWLBackupCoordinatorSvc"; Display="Azure Workload Backup"}
    )

    $azureFound = $false
    foreach ($svc in $azureServices) {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $azureFound = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.Display -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Display -Status WARN -Message "$($service.Status)"
            }
        }
    }

    if (-not $azureFound) {
        Register-Check -Name "Azure Backup" -Status INFO -Message "Not installed (MARS agent not present)"
    }
} catch {
    Register-Check -Name "Azure Backup" -Status INFO -Message "Not detected"
}

# ============================================================================
# AWS BACKUP
# ============================================================================
Write-Section "AWS Backup"

try {
    # AWS Backup typically works through SSM or doesn't have a dedicated agent
    $ssmService = Get-Service -Name "AmazonSSMAgent" -ErrorAction SilentlyContinue
    if ($ssmService -and $ssmService.Status -eq "Running") {
        Register-Check -Name "AWS SSM (Backup-capable)" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "AWS Backup" -Status INFO -Message "No agent installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CRASHPLAN
# ============================================================================
Write-Section "CrashPlan"

try {
    $crashPlanService = Get-Service -Name "CrashPlanService" -ErrorAction SilentlyContinue
    if ($crashPlanService) {
        if ($crashPlanService.Status -eq "Running") {
            Register-Check -Name "CrashPlan Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "CrashPlan Service" -Status WARN -Message "$($crashPlanService.Status)"
        }
    } else {
        Register-Check -Name "CrashPlan" -Status INFO -Message "Not installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# BACKUP SUMMARY
# ============================================================================
Write-Section "Backup Coverage Summary"

$backupProducts = @(
    @{Service="wbengine"; Name="Windows Backup"},
    @{Service="VeeamBackupSvc"; Name="Veeam"},
    @{Service="VeeamEndpointBackupSvc"; Name="Veeam Agent"},
    @{Service="AcrSch2Svc"; Name="Acronis"},
    @{Service="CarboniteService"; Name="Carbonite"},
    @{Service="GxCVD"; Name="Commvault"},
    @{Service="obengine"; Name="Azure Backup"},
    @{Service="CrashPlanService"; Name="CrashPlan"}
)

$runningBackup = @()
foreach ($backup in $backupProducts) {
    $svc = Get-Service -Name $backup.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningBackup += $backup.Name
    }
}

# Check VSS as a fallback
$vss = Get-Service -Name "VSS" -ErrorAction SilentlyContinue
$hasVSS = $null -ne $vss

if ($runningBackup.Count -ge 1) {
    Register-Check -Name "Backup Coverage" -Status PASS -Message "Protected by: $($runningBackup -join ', ')"
} elseif ($hasVSS) {
    # Check for restore points as minimal backup
    try {
        $restorePoints = Get-ComputerRestorePoint -ErrorAction SilentlyContinue
        if ($restorePoints) {
            Register-Check -Name "Backup Coverage" -Status WARN -Message "Only System Restore available ($($restorePoints.Count) points)"
        } else {
            Register-Check -Name "Backup Coverage" -Status WARN -Message "No backup solution detected"
        }
    } catch {
        Register-Check -Name "Backup Coverage" -Status WARN -Message "No backup solution detected"
    }
} else {
    Register-Check -Name "Backup Coverage" -Status FAIL -Message "No backup solution detected"
}

# Check for backup target locations
try {
    # Check for USB drives that might be backup targets
    $usbDrives = Get-CimInstance -ClassName Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object {
        $_.DriveType -eq 2 -and $_.Size -gt 50GB
    }
    if ($usbDrives) {
        Register-Check -Name "Removable Backup Drives" -Status INFO -Message "$($usbDrives.Count) USB drive(s) detected"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
