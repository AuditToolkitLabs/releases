<#
.SYNOPSIS
    BitLocker Drive Encryption Security Audit

.DESCRIPTION
    Comprehensive BitLocker audit based on CIS Windows Benchmark:
    - Drive encryption status
    - Recovery key configuration
    - TPM integration
    - Encryption algorithm strength
    - Policy settings
    - Fixed and removable drive encryption

.NOTES
    @elevation: admin
    @elevation-reason: BitLocker cmdlets require Administrator privileges

Compliance Mapping:
- CIS Controls: 3.4 (Encrypt Data at Rest), 13.1 (Data Inventory), 16.11 (Mobile Device Security)
- CIS Windows Benchmark: 18.9.11.x (BitLocker Drive Encryption)
- NIST SP 800-53: SC-28 (Protection of Information at Rest), MP-4 (Media Storage), SC-12 (Cryptographic Key Management)
- PCI DSS: 3.4 (Render PAN Unreadable), 3.5 (Cryptographic Keys)
- ISO 27001: A.8.2, A.10.1, A.13.2
- HIPAA: 164.312(a)(2)(iv), 164.312(e)(2)(ii)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

$blPath = "HKLM:\SOFTWARE\Policies\Microsoft\FVE"

function Test-BLRegistry {
    param(
        [string]$Name,
        [string]$CheckName,
        [string]$CISRef,
        $ExpectedValue,
        [string]$PassMessage,
        [string]$FailMessage,
        [switch]$GreaterOrEqual
    )

    $displayName = if ($CISRef) { "($CISRef) $CheckName" } else { $CheckName }

    try {
        $value = Get-ItemProperty -Path $blPath -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        $passed = if ($GreaterOrEqual) { $actualValue -ge $ExpectedValue } else { $actualValue -eq $ExpectedValue }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message $PassMessage
        } else {
            Register-Check -Name $displayName -Status WARN -Message "$FailMessage (Current: $actualValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status INFO -Message "Not configured (using default)"
    }
}

# ============================================================================
# BITLOCKER STATUS
# ============================================================================
Write-Section "BitLocker Drive Encryption Status"

try {
    $volumes = Get-BitLockerVolume -ErrorAction Stop

    foreach ($vol in $volumes) {
        $mountPoint = $vol.MountPoint
        $volumeType = switch ($vol.VolumeType) {
            "OperatingSystem" { "OS" }
            "FixedData" { "Fixed" }
            "RemovableData" { "Removable" }
            default { $vol.VolumeType }
        }

        # Protection Status
        if ($vol.ProtectionStatus -eq 'On') {
            Register-Check -Name "[$mountPoint] Protection Status" -Status PASS -Message "Protected ($volumeType)"
        } elseif ($vol.ProtectionStatus -eq 'Off' -and $vol.VolumeStatus -eq 'FullyEncrypted') {
            Register-Check -Name "[$mountPoint] Protection Status" -Status WARN -Message "Encrypted but protection suspended"
        } else {
            if ($vol.VolumeType -eq 'OperatingSystem') {
                Register-Check -Name "[$mountPoint] Protection Status" -Status FAIL -Message "OS drive not encrypted"
            } else {
                Register-Check -Name "[$mountPoint] Protection Status" -Status WARN -Message "$volumeType drive not encrypted"
            }
        }

        # Encryption Method/Algorithm
        if ($vol.EncryptionMethod) {
            $method = $vol.EncryptionMethod.ToString()
            $isStrong = $method -match 'Aes256|XtsAes256|XtsAes128'

            if ($isStrong) {
                Register-Check -Name "[$mountPoint] Encryption Algorithm" -Status PASS -Message $method
            } else {
                Register-Check -Name "[$mountPoint] Encryption Algorithm" -Status WARN -Message "$method (consider XTS-AES 256)"
            }
        }

        # Key Protector Check
        if ($vol.KeyProtector) {
            $protectorTypes = ($vol.KeyProtector | Select-Object -ExpandProperty KeyProtectorType) -join ", "

            # Check for TPM
            $hasTPM = $vol.KeyProtector | Where-Object { $_.KeyProtectorType -match 'Tpm' }
            $hasRecoveryKey = $vol.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' }

            if ($hasTPM) {
                Register-Check -Name "[$mountPoint] TPM Protection" -Status PASS -Message "TPM key protector present"
            } elseif ($vol.VolumeType -eq 'OperatingSystem') {
                Register-Check -Name "[$mountPoint] TPM Protection" -Status WARN -Message "No TPM protector (using: $protectorTypes)"
            }

            if ($hasRecoveryKey) {
                Register-Check -Name "[$mountPoint] Recovery Key" -Status PASS -Message "Recovery password configured"
            } else {
                Register-Check -Name "[$mountPoint] Recovery Key" -Status WARN -Message "No recovery password"
            }
        }
    }

} catch {
    Register-Check -Name "BitLocker Status" -Status SKIP -Message "Cannot query BitLocker (requires admin privileges)"
}

# ============================================================================
# TPM STATUS
# ============================================================================
Write-Section "TPM Status"

try {
    $tpm = Get-Tpm -ErrorAction Stop

    if ($tpm.TpmPresent) {
        Register-Check -Name "TPM Present" -Status PASS -Message "TPM chip detected"
    } else {
        Register-Check -Name "TPM Present" -Status FAIL -Message "No TPM - BitLocker less secure"
    }

    if ($tpm.TpmReady) {
        Register-Check -Name "TPM Ready" -Status PASS -Message "TPM is ready for use"
    } else {
        Register-Check -Name "TPM Ready" -Status WARN -Message "TPM not ready"
    }

    if ($tpm.TpmEnabled) {
        Register-Check -Name "TPM Enabled" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "TPM Enabled" -Status FAIL -Message "TPM disabled in BIOS/UEFI"
    }

    # TPM version (2.0 recommended)
    try {
        $tpmWmi = Get-CimInstance -Namespace "Root\CIMv2\Security\MicrosoftTpm" -ClassName "Win32_Tpm" -ErrorAction Stop
        $specVersion = $tpmWmi.SpecVersion
        if ($specVersion -match '^2\.') {
            Register-Check -Name "TPM Version" -Status PASS -Message "TPM 2.0 ($specVersion)"
        } elseif ($specVersion -match '^1\.2') {
            Register-Check -Name "TPM Version" -Status WARN -Message "TPM 1.2 (upgrade to 2.0 recommended)"
        } else {
            Register-Check -Name "TPM Version" -Status INFO -Message $specVersion
        }
    } catch {
        Register-Check -Name "TPM Version" -Status SKIP -Message "Cannot determine"
    }

} catch {
    Register-Check -Name "TPM Status" -Status SKIP -Message "Cannot query TPM (requires admin)"
}

# ============================================================================
# CIS 18.9.11.x - BITLOCKER POLICY SETTINGS
# ============================================================================
Write-Section "BitLocker Policy Settings (CIS 18.9.11.x)"

# CIS 18.9.11.1.1 - Allow enhanced PINs for startup
Test-BLRegistry -Name "UseEnhancedPin" -CISRef "18.9.11.1.1" `
    -CheckName "Allow Enhanced PINs" `
    -ExpectedValue 1 `
    -PassMessage "Enabled (alphanumeric PINs)" `
    -FailMessage "Disabled (numeric only)"

# CIS 18.9.11.1.2 - Choose how BitLocker-protected OS drives can be recovered
Test-BLRegistry -Name "OSRecovery" -CISRef "18.9.11.1.2" `
    -CheckName "Configure OS Drive Recovery" `
    -ExpectedValue 1 `
    -PassMessage "Policy configured" `
    -FailMessage "Not configured"

# CIS 18.9.11.1.3 - Allow access to BitLocker-protected fixed drives from earlier versions
Test-BLRegistry -Name "FDVDiscoveryVolumeType" -CISRef "18.9.11.1.3" `
    -CheckName "Fixed Drive Backward Compatibility" `
    -ExpectedValue "" `
    -PassMessage "Disabled" `
    -FailMessage "Enabled (reduced security)"

# CIS 18.9.11.1.4 - Configure encryption method for OS drives
try {
    $encMethod = Get-ItemProperty -Path $blPath -Name "EncryptionMethodWithXtsOs" -ErrorAction SilentlyContinue
    if ($encMethod.EncryptionMethodWithXtsOs -ge 6) {
        Register-Check -Name "(18.9.11.1.4) OS Encryption Method Policy" -Status PASS -Message "XTS-AES 256 or stronger"
    } elseif ($encMethod.EncryptionMethodWithXtsOs -ge 4) {
        Register-Check -Name "(18.9.11.1.4) OS Encryption Method Policy" -Status INFO -Message "XTS-AES 128"
    } else {
        Register-Check -Name "(18.9.11.1.4) OS Encryption Method Policy" -Status WARN -Message "Weaker encryption or not configured"
    }
} catch {
    Register-Check -Name "(18.9.11.1.4) OS Encryption Method Policy" -Status INFO -Message "Using default"
}

# CIS 18.9.11.1.5 - Require additional authentication at startup
Test-BLRegistry -Name "UseTPM" -CISRef "18.9.11.1.5" `
    -CheckName "Require TPM at Startup" `
    -ExpectedValue 2 `
    -PassMessage "TPM required" `
    -FailMessage "TPM not required"

# CIS 18.9.11.2.x - Fixed Data Drives
Write-Section "Fixed Data Drive Policies (CIS 18.9.11.2.x)"

# CIS 18.9.11.2.1 - Deny write access to fixed drives not protected by BitLocker
Test-BLRegistry -Name "FDVDenyWriteAccess" -CISRef "18.9.11.2.1" `
    -CheckName "Deny Write to Unencrypted Fixed Drives" `
    -ExpectedValue 1 `
    -PassMessage "Enabled (enhanced security)" `
    -FailMessage "Disabled (data leakage risk)"

# CIS 18.9.11.3.x - Removable Data Drives
Write-Section "Removable Data Drive Policies (CIS 18.9.11.3.x)"

# CIS 18.9.11.3.1 - Control use of BitLocker on removable drives
Test-BLRegistry -Name "RDVConfigureBDE" -CISRef "18.9.11.3.1" `
    -CheckName "Allow BitLocker on Removable Drives" `
    -ExpectedValue 1 `
    -PassMessage "Configured" `
    -FailMessage "Not configured"

# CIS 18.9.11.3.2 - Deny write access to removable drives not protected by BitLocker
Test-BLRegistry -Name "RDVDenyWriteAccess" -CISRef "18.9.11.3.2" `
    -CheckName "Deny Write to Unencrypted Removable" `
    -ExpectedValue 1 `
    -PassMessage "Enabled (DLP protection)" `
    -FailMessage "Disabled (data leakage risk)"

# ============================================================================
# ADDITIONAL SECURITY CHECKS
# ============================================================================
Write-Section "Additional BitLocker Security"

# Check if Secure Boot is enabled (enhances BitLocker)
try {
    $secureBoot = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
    if ($secureBoot) {
        Register-Check -Name "Secure Boot" -Status PASS -Message "Enabled (enhances BitLocker protection)"
    } else {
        Register-Check -Name "Secure Boot" -Status WARN -Message "Disabled or unavailable"
    }
} catch {
    Register-Check -Name "Secure Boot" -Status SKIP -Message "Cannot determine"
}

# Check recovery key backup to AD
try {
    $adBackup = Get-ItemProperty -Path $blPath -Name "ActiveDirectoryBackup" -ErrorAction SilentlyContinue
    if ($adBackup.ActiveDirectoryBackup -eq 1) {
        Register-Check -Name "AD Recovery Key Backup" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "AD Recovery Key Backup" -Status INFO -Message "Not configured (manual backup needed)"
    }
} catch {
    Register-Check -Name "AD Recovery Key Backup" -Status INFO -Message "Policy not set"
}

# Check preboot PIN/password requirements
try {
    $prebootPIN = Get-ItemProperty -Path $blPath -Name "UseTPMPIN" -ErrorAction SilentlyContinue
    if ($prebootPIN.UseTPMPIN -eq 1) {
        Register-Check -Name "Preboot PIN Required" -Status PASS -Message "TPM+PIN required (multi-factor)"
    } elseif ($prebootPIN.UseTPMPIN -eq 2) {
        Register-Check -Name "Preboot PIN Required" -Status INFO -Message "TPM+PIN allowed (optional)"
    } else {
        Register-Check -Name "Preboot PIN Required" -Status INFO -Message "TPM-only (single factor)"
    }
} catch {
    Register-Check -Name "Preboot PIN Required" -Status INFO -Message "Using default"
}

Print-Summary
Exit-Audit
