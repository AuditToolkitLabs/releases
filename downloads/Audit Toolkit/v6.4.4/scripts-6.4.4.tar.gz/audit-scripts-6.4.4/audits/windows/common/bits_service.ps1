# Check BITS Service
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $svc = Get-Service -Name "BITS" -ErrorAction SilentlyContinue
    if ($svc.Status -eq 'Running') {
        Register-Check -Name "BITS Service" -Status PASS -Message "Service is running."
    } else {
        Register-Check -Name "BITS Service" -Status FAIL -Message "Service is not running."
    }
} catch {
    Register-Check -Name "BITS Service" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit