# Google Chrome Browser Security Audit Script (PowerShell)
# Checks Chrome security settings, policies, and enterprise configuration
# This script is read-only and does not modify system state.
#
# References:
# - CIS Google Chrome Benchmark v2.0
# - NIST SP 800-53: CM-6, CM-7

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

function Get-ChromeInstallPath {
    $paths = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($path in $paths) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Test-ChromePolicy {
    param(
        [string]$PolicyName,
        [object]$ExpectedValue,
        [string]$Description,
        [switch]$InvertCheck
    )

    $paths = @(
        "HKLM:\SOFTWARE\Policies\Google\Chrome",
        "HKCU:\SOFTWARE\Policies\Google\Chrome"
    )

    foreach ($path in $paths) {
        try {
            $value = Get-ItemProperty -Path $path -Name $PolicyName -ErrorAction SilentlyContinue
            if ($null -ne $value.$PolicyName) {
                $status = if ($InvertCheck) {
                    if ($value.$PolicyName -ne $ExpectedValue) { "PASS" } else { "WARN" }
                } else {
                    if ($value.$PolicyName -eq $ExpectedValue) { "PASS" } else { "WARN" }
                }
                Register-Check -Name $Description -Status $status -Message "Value: $($value.$PolicyName)"
                return
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
    Register-Check -Name $Description -Status INFO -Message "Not configured via policy"
}

# ============================================================================
# CHROME INSTALLATION CHECK
# ============================================================================
Write-Section "Chrome Installation"

$chromePath = Get-ChromeInstallPath
if ($chromePath) {
    Register-Check -Name "Chrome Installed" -Status PASS -Message "Found"

    # Version check
    $version = (Get-Item $chromePath).VersionInfo.FileVersion
    Register-Check -Name "Chrome Version" -Status INFO -Message "v$version"

    # Check if enterprise managed
    $managedPath = "HKLM:\SOFTWARE\Policies\Google\Chrome"
    if (Test-Path $managedPath) {
        $policyCount = (Get-ItemProperty -Path $managedPath -ErrorAction SilentlyContinue).PSObject.Properties.Count
        if ($policyCount -gt 0) {
            Register-Check -Name "Enterprise Managed" -Status PASS -Message "$policyCount policies applied"
        } else {
            Register-Check -Name "Enterprise Managed" -Status WARN -Message "Policy key exists but empty"
        }
    } else {
        Register-Check -Name "Enterprise Managed" -Status WARN -Message "No GPO/Intune policies detected"
    }
} else {
    Register-Check -Name "Chrome Installed" -Status INFO -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# CIS 1.x - SAFE BROWSING (Major Section)
# ============================================================================
Write-Section "Safe Browsing & Phishing Protection"

# 1.1 - SafeBrowsingEnabled
Test-ChromePolicy -PolicyName "SafeBrowsingEnabled" -ExpectedValue 1 -Description "Safe Browsing Enabled"

# 1.2 - SafeBrowsingProtectionLevel (0=off, 1=standard, 2=enhanced)
$sbLevel = $null
$paths = @("HKLM:\SOFTWARE\Policies\Google\Chrome", "HKCU:\SOFTWARE\Policies\Google\Chrome")
foreach ($path in $paths) {
    $val = Get-ItemProperty -Path $path -Name "SafeBrowsingProtectionLevel" -ErrorAction SilentlyContinue
    if ($val.SafeBrowsingProtectionLevel) { $sbLevel = $val.SafeBrowsingProtectionLevel; break }
}
if ($sbLevel -eq 2) {
    Register-Check -Name "Safe Browsing Level" -Status PASS -Message "Enhanced protection"
} elseif ($sbLevel -eq 1) {
    Register-Check -Name "Safe Browsing Level" -Status PASS -Message "Standard protection"
} elseif ($sbLevel -eq 0) {
    Register-Check -Name "Safe Browsing Level" -Status FAIL -Message "Disabled"
} else {
    Register-Check -Name "Safe Browsing Level" -Status INFO -Message "Not policy-enforced"
}

# 1.3 - SiteEngagementOverride (should not bypass Safe Browsing)
Test-ChromePolicy -PolicyName "SafeBrowsingAllowlistDomains" -ExpectedValue $null -Description "Safe Browsing Allowlist" -InvertCheck

# 1.4 - Download protection
Test-ChromePolicy -PolicyName "DownloadRestrictions" -ExpectedValue 0 -Description "Download Restrictions" -InvertCheck

# ============================================================================
# CIS 2.x - PASSWORD MANAGEMENT
# ============================================================================
Write-Section "Password Management"

# 2.1 - PasswordManagerEnabled
Test-ChromePolicy -PolicyName "PasswordManagerEnabled" -ExpectedValue 0 -Description "Password Manager Disabled"

# 2.2 - PasswordLeakDetectionEnabled
Test-ChromePolicy -PolicyName "PasswordLeakDetectionEnabled" -ExpectedValue 1 -Description "Password Leak Detection"

# 2.3 - AutofillAddressEnabled
Test-ChromePolicy -PolicyName "AutofillAddressEnabled" -ExpectedValue 0 -Description "Address Autofill Disabled"

# 2.4 - AutofillCreditCardEnabled
Test-ChromePolicy -PolicyName "AutofillCreditCardEnabled" -ExpectedValue 0 -Description "Credit Card Autofill Disabled"

# ============================================================================
# CIS 3.x - EXTENSION MANAGEMENT
# ============================================================================
Write-Section "Extension Management"

# 3.1 - ExtensionInstallBlocklist
$blocklist = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallBlocklist" -ErrorAction SilentlyContinue
if ($blocklist) {
    $blockAll = $blocklist.PSObject.Properties | Where-Object { $_.Value -eq "*" }
    if ($blockAll) {
        Register-Check -Name "Extension Blocklist" -Status PASS -Message "All extensions blocked by default"
    } else {
        $count = ($blocklist.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
        Register-Check -Name "Extension Blocklist" -Status INFO -Message "$count extension(s) blocked"
    }
} else {
    Register-Check -Name "Extension Blocklist" -Status WARN -Message "No blocklist configured"
}

# 3.2 - ExtensionInstallAllowlist
$allowlist = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallAllowlist" -ErrorAction SilentlyContinue
if ($allowlist) {
    $count = ($allowlist.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
    Register-Check -Name "Extension Allowlist" -Status INFO -Message "$count extension(s) allowed"
} else {
    Register-Check -Name "Extension Allowlist" -Status INFO -Message "Not configured"
}

# 3.3 - ExtensionInstallForcelist (enterprise-pushed extensions)
$forcelist = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist" -ErrorAction SilentlyContinue
if ($forcelist) {
    $count = ($forcelist.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
    Register-Check -Name "Force-Installed Extensions" -Status INFO -Message "$count extension(s)"
}

# 3.4 - BlockExternalExtensions
Test-ChromePolicy -PolicyName "BlockExternalExtensions" -ExpectedValue 1 -Description "Block External Extensions"

# ============================================================================
# CIS 4.x - SITE ISOLATION & SECURITY
# ============================================================================
Write-Section "Site Isolation & Process Security"

# 4.1 - SitePerProcess (Strict Site Isolation)
Test-ChromePolicy -PolicyName "SitePerProcess" -ExpectedValue 1 -Description "Strict Site Isolation"

# 4.2 - IsolateOrigins
$isolate = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "IsolateOrigins" -ErrorAction SilentlyContinue
if ($isolate.IsolateOrigins) {
    Register-Check -Name "Origin Isolation" -Status PASS -Message "Additional origins isolated"
} else {
    Register-Check -Name "Origin Isolation" -Status INFO -Message "Using defaults"
}

# 4.3 - ThirdPartyCookiesBlocked
Test-ChromePolicy -PolicyName "BlockThirdPartyCookies" -ExpectedValue 1 -Description "Third-Party Cookies Blocked"

# 4.4 - DNS over HTTPS
$dnsMode = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DnsOverHttpsMode" -ErrorAction SilentlyContinue
if ($dnsMode.DnsOverHttpsMode -eq "secure") {
    Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Secure mode"
} elseif ($dnsMode.DnsOverHttpsMode -eq "automatic") {
    Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Automatic mode"
} elseif ($dnsMode.DnsOverHttpsMode -eq "off") {
    Register-Check -Name "DNS over HTTPS" -Status WARN -Message "Disabled"
} else {
    Register-Check -Name "DNS over HTTPS" -Status INFO -Message "Not policy-enforced"
}

# ============================================================================
# CIS 5.x - PRIVACY & DATA PROTECTION
# ============================================================================
Write-Section "Privacy & Data Protection"

# 5.1 - MetricsReportingEnabled
Test-ChromePolicy -PolicyName "MetricsReportingEnabled" -ExpectedValue 0 -Description "Telemetry Disabled"

# 5.2 - UrlKeyedAnonymizedDataCollectionEnabled
Test-ChromePolicy -PolicyName "UrlKeyedAnonymizedDataCollectionEnabled" -ExpectedValue 0 -Description "URL Data Collection Disabled"

# 5.3 - NetworkPredictionOptions
Test-ChromePolicy -PolicyName "NetworkPredictionOptions" -ExpectedValue 2 -Description "Network Prediction Disabled"

# 5.4 - TranslateEnabled
Test-ChromePolicy -PolicyName "TranslateEnabled" -ExpectedValue 0 -Description "Translate Disabled"

# 5.5 - SpellCheckServiceEnabled
Test-ChromePolicy -PolicyName "SpellCheckServiceEnabled" -ExpectedValue 0 -Description "Cloud Spellcheck Disabled"

# 5.6 - Sync policies
Test-ChromePolicy -PolicyName "SyncDisabled" -ExpectedValue 1 -Description "Chrome Sync Disabled"

# ============================================================================
# CIS 6.x - CONTENT SETTINGS
# ============================================================================
Write-Section "Content Settings"

# 6.1 - DefaultGeolocationSetting
$geoSetting = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DefaultGeolocationSetting" -ErrorAction SilentlyContinue
if ($geoSetting.DefaultGeolocationSetting -eq 2) {
    Register-Check -Name "Geolocation Default" -Status PASS -Message "Blocked"
} elseif ($geoSetting.DefaultGeolocationSetting -eq 3) {
    Register-Check -Name "Geolocation Default" -Status PASS -Message "Ask"
} else {
    Register-Check -Name "Geolocation Default" -Status INFO -Message "Not restricted by policy"
}

# 6.2 - DefaultNotificationsSetting
$notifSetting = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DefaultNotificationsSetting" -ErrorAction SilentlyContinue
if ($notifSetting.DefaultNotificationsSetting -eq 2) {
    Register-Check -Name "Notifications Default" -Status PASS -Message "Blocked"
} else {
    Register-Check -Name "Notifications Default" -Status INFO -Message "Not restricted by policy"
}

# 6.3 - DefaultPopupsSetting
Test-ChromePolicy -PolicyName "DefaultPopupsSetting" -ExpectedValue 2 -Description "Popups Blocked"

# 6.4 - DefaultWebUsbGuardSetting
Test-ChromePolicy -PolicyName "DefaultWebUsbGuardSetting" -ExpectedValue 2 -Description "WebUSB Blocked"

# 6.5 - DefaultWebBluetoothGuardSetting
Test-ChromePolicy -PolicyName "DefaultWebBluetoothGuardSetting" -ExpectedValue 2 -Description "Web Bluetooth Blocked"

# 6.6 - DefaultSerialGuardSetting
Test-ChromePolicy -PolicyName "DefaultSerialGuardSetting" -ExpectedValue 2 -Description "Web Serial Blocked"

# ============================================================================
# CIS 7.x - CERTIFICATE & TLS
# ============================================================================
Write-Section "Certificate & TLS Security"

# 7.1 - SSLVersionMin
$sslMin = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "SSLVersionMin" -ErrorAction SilentlyContinue
if ($sslMin.SSLVersionMin -eq "tls1.2") {
    Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.2"
} elseif ($sslMin.SSLVersionMin -eq "tls1.3") {
    Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.3"
} else {
    Register-Check -Name "Minimum TLS Version" -Status WARN -Message "Not enforced (legacy protocols may work)"
}

# 7.2 - CertificateTransparencyEnforcementDisabledForUrls
$ctDisabled = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome\CertificateTransparencyEnforcementDisabledForUrls" -ErrorAction SilentlyContinue
if ($ctDisabled) {
    $count = ($ctDisabled.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
    if ($count -gt 0) {
        Register-Check -Name "CT Enforcement Exceptions" -Status WARN -Message "$count URL(s) exempt from CT"
    }
} else {
    Register-Check -Name "Certificate Transparency" -Status PASS -Message "No exceptions configured"
}

# 7.3 - HSTS Preload
Test-ChromePolicy -PolicyName "HSTSPolicyBypassList" -ExpectedValue $null -Description "HSTS Bypass List Empty" -InvertCheck

# ============================================================================
# CIS 8.x - UPDATE & MAINTENANCE
# ============================================================================
Write-Section "Update & Maintenance"

# 8.1 - AutoUpdate
$updatePath = "HKLM:\SOFTWARE\Policies\Google\Update"
$autoUpdate = Get-ItemProperty -Path $updatePath -Name "AutoUpdateCheckPeriodMinutes" -ErrorAction SilentlyContinue
if ($autoUpdate.AutoUpdateCheckPeriodMinutes -eq 0) {
    Register-Check -Name "Chrome Auto-Update" -Status FAIL -Message "Disabled"
} elseif ($autoUpdate.AutoUpdateCheckPeriodMinutes) {
    Register-Check -Name "Chrome Auto-Update" -Status PASS -Message "Check every $($autoUpdate.AutoUpdateCheckPeriodMinutes) min"
} else {
    Register-Check -Name "Chrome Auto-Update" -Status PASS -Message "Default (enabled)"
}

# 8.2 - RelaunchNotification
Test-ChromePolicy -PolicyName "RelaunchNotification" -ExpectedValue 2 -Description "Relaunch Notification Required"

# 8.3 - ComponentUpdatesEnabled
Test-ChromePolicy -PolicyName "ComponentUpdatesEnabled" -ExpectedValue 1 -Description "Component Updates Enabled"

# ============================================================================
# CIS 9.x - DEVELOPER & ADVANCED
# ============================================================================
Write-Section "Developer & Advanced Settings"

# 9.1 - DeveloperToolsAvailability
$devTools = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "DeveloperToolsAvailability" -ErrorAction SilentlyContinue
if ($devTools.DeveloperToolsAvailability -eq 2) {
    Register-Check -Name "Developer Tools" -Status PASS -Message "Blocked"
} elseif ($devTools.DeveloperToolsAvailability -eq 1) {
    Register-Check -Name "Developer Tools" -Status INFO -Message "Allowed on unpacked extensions"
} else {
    Register-Check -Name "Developer Tools" -Status INFO -Message "Allowed"
}

# 9.2 - RemoteDebuggingAllowed
Test-ChromePolicy -PolicyName "RemoteDebuggingAllowed" -ExpectedValue 0 -Description "Remote Debugging Blocked"

# 9.3 - AllowDinosaurEasterEgg
Test-ChromePolicy -PolicyName "AllowDinosaurEasterEgg" -ExpectedValue 0 -Description "Dinosaur Game Disabled"

# 9.4 - BrowserGuestModeEnabled
Test-ChromePolicy -PolicyName "BrowserGuestModeEnabled" -ExpectedValue 0 -Description "Guest Mode Disabled"

# 9.5 - IncognitoModeAvailability (0=default, 1=forced, 2=disabled)
$incognito = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Google\Chrome" -Name "IncognitoModeAvailability" -ErrorAction SilentlyContinue
if ($incognito.IncognitoModeAvailability -eq 1) {
    Register-Check -Name "Incognito Mode" -Status WARN -Message "Forced (unusual)"
} elseif ($incognito.IncognitoModeAvailability -eq 2) {
    Register-Check -Name "Incognito Mode" -Status INFO -Message "Disabled"
} else {
    Register-Check -Name "Incognito Mode" -Status INFO -Message "Available (default)"
}

# ============================================================================
# INSTALLED EXTENSIONS SCAN
# ============================================================================
Write-Section "Installed Extensions"

try {
    $extensionPaths = @(
        "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Extensions",
        "$env:LOCALAPPDATA\Google\Chrome\User Data\Profile 1\Extensions"
    )

    $extensionCount = 0
    foreach ($extPath in $extensionPaths) {
        if (Test-Path $extPath) {
            $extensions = Get-ChildItem -Path $extPath -Directory -ErrorAction SilentlyContinue
            $extensionCount += $extensions.Count
        }
    }

    if ($extensionCount -gt 0) {
        Register-Check -Name "User Extensions" -Status INFO -Message "$extensionCount extension(s) installed"

        # Warn if too many extensions
        if ($extensionCount -gt 20) {
            Register-Check -Name "Extension Count" -Status WARN -Message "High number of extensions - review recommended"
        }
    } else {
        Register-Check -Name "User Extensions" -Status INFO -Message "None detected"
    }
} catch {
    Register-Check -Name "User Extensions" -Status INFO -Message "Unable to enumerate"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
