# Cloud Agents Audit Script (PowerShell)
# Checks for cloud management agents (Azure Arc, AWS SSM, GCP Guest Agent, etc.)
# This script is read-only and does not modify system state.
#
# References:
# - CIS Controls 1: Inventory and Control of Hardware Assets
# - NIST SP 800-53: CM-2, CM-8

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# AZURE ARC
# ============================================================================
Write-Section "Azure Arc"

# Connected Machine Agent
try {
    $arcService = Get-Service -Name "himds" -ErrorAction SilentlyContinue
    if ($arcService) {
        if ($arcService.Status -eq "Running") {
            Register-Check -Name "Azure Arc Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Azure Arc Agent" -Status WARN -Message "$($arcService.Status)"
        }

        # Check Arc configuration
        $arcPath = "C:\Program Files\AzureConnectedMachineAgent"
        if (Test-Path $arcPath) {
            $azcmagent = Join-Path $arcPath "azcmagent.exe"
            if (Test-Path $azcmagent) {
                # Get agent info
                try {
                    $agentInfo = & $azcmagent show 2>&1

                    # Parse status
                    if ($agentInfo -match "Agent Status\s*:\s*(\w+)") {
                        $status = $Matches[1]
                        if ($status -eq "Connected") {
                            Register-Check -Name "Arc Connection Status" -Status PASS -Message "Connected to Azure"
                        } else {
                            Register-Check -Name "Arc Connection Status" -Status WARN -Message $status
                        }
                    }

                    # Subscription
                    if ($agentInfo -match "Subscription ID\s*:\s*([a-f0-9-]+)") {
                        Register-Check -Name "Arc Subscription" -Status INFO -Message "$($Matches[1].Substring(0,8))..."
                    }

                    # Resource Group
                    if ($agentInfo -match "Resource Group\s*:\s*(.+)") {
                        Register-Check -Name "Arc Resource Group" -Status INFO -Message $Matches[1].Trim()
                    }
                } catch {
                    Register-Check -Name "Arc Agent Info" -Status INFO -Message "Unable to query (run as admin)"
                }
            }
        }

        # Extension service
        $extService = Get-Service -Name "GCArcService" -ErrorAction SilentlyContinue
        if ($extService -and $extService.Status -eq "Running") {
            Register-Check -Name "Arc Extension Service" -Status PASS -Message "Running"
        }
    } else {
        Register-Check -Name "Azure Arc" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Azure Arc" -Status INFO -Message "Not detected"
}

# ============================================================================
# AWS SYSTEMS MANAGER (SSM) AGENT
# ============================================================================
Write-Section "AWS Systems Manager"

try {
    $ssmService = Get-Service -Name "AmazonSSMAgent" -ErrorAction SilentlyContinue
    if ($ssmService) {
        if ($ssmService.Status -eq "Running") {
            Register-Check -Name "AWS SSM Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "AWS SSM Agent" -Status WARN -Message "$($ssmService.Status)"
        }

        # Check version
        $ssmPath = "C:\Program Files\Amazon\SSM\amazon-ssm-agent.exe"
        if (Test-Path $ssmPath) {
            $version = (Get-Item $ssmPath).VersionInfo.FileVersion
            Register-Check -Name "SSM Agent Version" -Status INFO -Message "v$version"
        }

        # Check SSM Agent configuration
        $ssmSeelog = "C:\Program Files\Amazon\SSM\seelog.xml"
        if (Test-Path $ssmSeelog) {
            Register-Check -Name "SSM Logging" -Status INFO -Message "Configured"
        }
    } else {
        Register-Check -Name "AWS SSM Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "AWS SSM Agent" -Status INFO -Message "Not detected"
}

# AWS CloudWatch Agent
try {
    $cwService = Get-Service -Name "AmazonCloudWatchAgent" -ErrorAction SilentlyContinue
    if ($cwService) {
        if ($cwService.Status -eq "Running") {
            Register-Check -Name "AWS CloudWatch Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "AWS CloudWatch Agent" -Status WARN -Message "$($cwService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# AWS Inspector Agent
try {
    $inspectorService = Get-Service -Name "AWSAgent" -ErrorAction SilentlyContinue
    if ($inspectorService) {
        if ($inspectorService.Status -eq "Running") {
            Register-Check -Name "AWS Inspector Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "AWS Inspector Agent" -Status INFO -Message "$($inspectorService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# GOOGLE CLOUD PLATFORM (GCP)
# ============================================================================
Write-Section "Google Cloud Platform"

# GCP Guest Agent
try {
    $gcpService = Get-Service -Name "GCEAgent" -ErrorAction SilentlyContinue
    if ($gcpService) {
        if ($gcpService.Status -eq "Running") {
            Register-Check -Name "GCP Guest Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "GCP Guest Agent" -Status WARN -Message "$($gcpService.Status)"
        }
    } else {
        Register-Check -Name "GCP Guest Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "GCP Guest Agent" -Status INFO -Message "Not detected"
}

# Google Compute Engine Windows services
try {
    $gceServices = @("google_accounts_daemon", "google_clock_skew_daemon", "google_network_daemon")
    foreach ($svcName in $gceServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq "Running") {
            Register-Check -Name "GCE Service: $svcName" -Status PASS -Message "Running"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# GCP Ops Agent (formerly Stackdriver)
try {
    $opsAgent = Get-Service -Name "google-cloud-ops-agent*" -ErrorAction SilentlyContinue
    if ($opsAgent) {
        if ($opsAgent.Status -eq "Running") {
            Register-Check -Name "GCP Ops Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "GCP Ops Agent" -Status WARN -Message "$($opsAgent.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ORACLE CLOUD INFRASTRUCTURE (OCI)
# ============================================================================
Write-Section "Oracle Cloud Infrastructure"

try {
    $ociService = Get-Service -Name "OracleCloudAgent" -ErrorAction SilentlyContinue
    if ($ociService) {
        if ($ociService.Status -eq "Running") {
            Register-Check -Name "OCI Cloud Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "OCI Cloud Agent" -Status WARN -Message "$($ociService.Status)"
        }
    } else {
        Register-Check -Name "OCI Cloud Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "OCI Cloud Agent" -Status INFO -Message "Not detected"
}

# ============================================================================
# ALIBABA CLOUD
# ============================================================================
Write-Section "Alibaba Cloud"

try {
    $aliService = Get-Service -Name "Alibaba Cloud Assistant*" -ErrorAction SilentlyContinue
    if (-not $aliService) {
        $aliService = Get-Service -Name "AliYunAssistService" -ErrorAction SilentlyContinue
    }

    if ($aliService) {
        if ($aliService.Status -eq "Running") {
            Register-Check -Name "Alibaba Cloud Assistant" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Alibaba Cloud Assistant" -Status WARN -Message "$($aliService.Status)"
        }
    } else {
        Register-Check -Name "Alibaba Cloud" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Alibaba Cloud" -Status INFO -Message "Not detected"
}

# ============================================================================
# HASHICORP TOOLS
# ============================================================================
Write-Section "HashiCorp Tools"

# Consul
try {
    $consulService = Get-Service -Name "Consul" -ErrorAction SilentlyContinue
    if ($consulService) {
        if ($consulService.Status -eq "Running") {
            Register-Check -Name "HashiCorp Consul" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "HashiCorp Consul" -Status INFO -Message "$($consulService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Nomad
try {
    $nomadService = Get-Service -Name "Nomad" -ErrorAction SilentlyContinue
    if ($nomadService) {
        if ($nomadService.Status -eq "Running") {
            Register-Check -Name "HashiCorp Nomad" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "HashiCorp Nomad" -Status INFO -Message "$($nomadService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Vault Agent
try {
    $vaultService = Get-Service -Name "Vault" -ErrorAction SilentlyContinue
    if ($vaultService) {
        if ($vaultService.Status -eq "Running") {
            Register-Check -Name "HashiCorp Vault" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "HashiCorp Vault" -Status INFO -Message "$($vaultService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# PUPPET / CHEF / ANSIBLE
# ============================================================================
Write-Section "Configuration Management"

# Puppet Agent
try {
    $puppetService = Get-Service -Name "puppet" -ErrorAction SilentlyContinue
    if ($puppetService) {
        if ($puppetService.Status -eq "Running") {
            Register-Check -Name "Puppet Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Puppet Agent" -Status INFO -Message "$($puppetService.Status)"
        }
    } else {
        Register-Check -Name "Puppet Agent" -Status INFO -Message "Not installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Chef Client
try {
    $chefService = Get-Service -Name "chef-client" -ErrorAction SilentlyContinue
    if ($chefService) {
        if ($chefService.Status -eq "Running") {
            Register-Check -Name "Chef Client" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Chef Client" -Status INFO -Message "$($chefService.Status)"
        }
    } else {
        Register-Check -Name "Chef Client" -Status INFO -Message "Not installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Salt Minion
try {
    $saltService = Get-Service -Name "salt-minion" -ErrorAction SilentlyContinue
    if ($saltService) {
        if ($saltService.Status -eq "Running") {
            Register-Check -Name "Salt Minion" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Salt Minion" -Status INFO -Message "$($saltService.Status)"
        }
    } else {
        Register-Check -Name "Salt Minion" -Status INFO -Message "Not installed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# WinRM for Ansible
try {
    $winrmService = Get-Service -Name "WinRM" -ErrorAction SilentlyContinue
    if ($winrmService -and $winrmService.Status -eq "Running") {
        Register-Check -Name "WinRM (Ansible)" -Status INFO -Message "Running (Ansible-capable)"

        # Check WinRM listeners
        $listeners = Get-WSManInstance -ResourceURI winrm/config/Listener -Enumerate -ErrorAction SilentlyContinue
        $httpsListener = $listeners | Where-Object { $_.Transport -eq "HTTPS" }
        if ($httpsListener) {
            Register-Check -Name "WinRM HTTPS" -Status PASS -Message "HTTPS listener configured"
        } else {
            Register-Check -Name "WinRM HTTPS" -Status WARN -Message "No HTTPS listener (HTTP only)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CONTAINER ORCHESTRATION
# ============================================================================
Write-Section "Container Orchestration"

# Docker
try {
    $dockerService = Get-Service -Name "docker" -ErrorAction SilentlyContinue
    if ($dockerService) {
        if ($dockerService.Status -eq "Running") {
            Register-Check -Name "Docker Engine" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Docker Engine" -Status INFO -Message "$($dockerService.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Kubernetes (kubelet)
try {
    $kubeletProcess = Get-Process -Name "kubelet" -ErrorAction SilentlyContinue
    if ($kubeletProcess) {
        Register-Check -Name "Kubernetes Node" -Status PASS -Message "kubelet running"
    }

    # Rancher Agent
    $rancherService = Get-Service -Name "rancher*" -ErrorAction SilentlyContinue
    if ($rancherService -and $rancherService.Status -eq "Running") {
        Register-Check -Name "Rancher Agent" -Status PASS -Message "Running"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CLOUD PROVIDER DETECTION
# ============================================================================
Write-Section "Cloud Provider Detection"

# Try to detect cloud provider from metadata
$cloudProvider = "Unknown/On-Premises"

try {
    # Azure IMDS
    $azureMetadata = Invoke-RestMethod -Uri "http://169.254.169.254/metadata/instance?api-version=2021-02-01" -Headers @{"Metadata"="true"} -TimeoutSec 2 -ErrorAction SilentlyContinue
    if ($azureMetadata) {
        $cloudProvider = "Microsoft Azure"
        Register-Check -Name "Cloud Provider" -Status INFO -Message "Azure (Location: $($azureMetadata.compute.location))"
        Register-Check -Name "Azure VM Name" -Status INFO -Message $azureMetadata.compute.name
        Register-Check -Name "Azure VM Size" -Status INFO -Message $azureMetadata.compute.vmSize
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if ($cloudProvider -eq "Unknown/On-Premises") {
    try {
        # AWS IMDS
        $awsMetadata = Invoke-RestMethod -Uri "http://169.254.169.254/latest/meta-data/instance-id" -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($awsMetadata) {
            $cloudProvider = "Amazon Web Services"
            Register-Check -Name "Cloud Provider" -Status INFO -Message "AWS"
            Register-Check -Name "AWS Instance ID" -Status INFO -Message $awsMetadata

            $awsRegion = Invoke-RestMethod -Uri "http://169.254.169.254/latest/meta-data/placement/region" -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($awsRegion) {
                Register-Check -Name "AWS Region" -Status INFO -Message $awsRegion
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($cloudProvider -eq "Unknown/On-Premises") {
    try {
        # GCP metadata
        $gcpMetadata = Invoke-RestMethod -Uri "http://metadata.google.internal/computeMetadata/v1/instance/id" -Headers @{"Metadata-Flavor"="Google"} -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($gcpMetadata) {
            $cloudProvider = "Google Cloud Platform"
            Register-Check -Name "Cloud Provider" -Status INFO -Message "GCP"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($cloudProvider -eq "Unknown/On-Premises") {
    Register-Check -Name "Cloud Provider" -Status INFO -Message "On-Premises or undetected cloud"
}

# ============================================================================
# CLOUD AGENT SUMMARY
# ============================================================================
Write-Section "Cloud Agent Summary"

$cloudAgents = @(
    @{Service="himds"; Name="Azure Arc"},
    @{Service="AmazonSSMAgent"; Name="AWS SSM"},
    @{Service="GCEAgent"; Name="GCP Guest Agent"},
    @{Service="OracleCloudAgent"; Name="OCI Agent"},
    @{Service="AliYunAssistService"; Name="Alibaba Cloud"},
    @{Service="puppet"; Name="Puppet"},
    @{Service="chef-client"; Name="Chef"},
    @{Service="salt-minion"; Name="Salt"},
    @{Service="Consul"; Name="Consul"},
    @{Service="docker"; Name="Docker"}
)

$runningAgents = @()
foreach ($agent in $cloudAgents) {
    $svc = Get-Service -Name $agent.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningAgents += $agent.Name
    }
}

if ($runningAgents.Count -ge 1) {
    Register-Check -Name "Cloud/Config Management" -Status PASS -Message "Active: $($runningAgents -join ', ')"
} else {
    Register-Check -Name "Cloud/Config Management" -Status INFO -Message "No cloud agents detected"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
