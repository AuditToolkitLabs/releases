# Check CMD.exe Elevation Protections
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction SilentlyContinue
    if ($reg.EnableLUA -eq 1) {
        Register-Check -Name "CMD.exe Elevation Protections" -Status PASS -Message "Elevation protections are enabled."
    } else {
        Register-Check -Name "CMD.exe Elevation Protections" -Status FAIL -Message "Elevation protections are not enabled."
    }
} catch {
    Register-Check -Name "CMD.exe Elevation Protections" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit