# Common Audit Module for Windows Audit Scripts
# Clean baseline implementation with compatibility aliases.

$script:CheckList = @()
$script:ExitCode = 0
$script:IsAdminCached = $null
$script:AuditMetadata = @{
    StartTime = $null
    EndTime = $null
    Hostname = $env:COMPUTERNAME
    Username = $env:USERNAME
    OSVersion = $null
    AuditScript = $null
    AuditVersion = '3.0.0'
    IsElevated = $null
}

function Get-RiskLevel {
    [CmdletBinding()]
    param(
        [int]$Score
    )

    if ($Score -ge 9) { return 'Critical' }
    if ($Score -ge 7) { return 'High' }
    if ($Score -ge 4) { return 'Medium' }
    if ($Score -ge 1) { return 'Low' }
    return 'Info'
}

function Test-IsAdmin {
    [CmdletBinding()]
    param()

    if ($null -eq $script:IsAdminCached) {
        $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
        $script:IsAdminCached = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        $script:AuditMetadata.IsElevated = $script:IsAdminCached
    }

    return $script:IsAdminCached
}

function Test-AdminWarn {
    [CmdletBinding()]
    param()

    if (Test-IsAdmin) {
        return $true
    }

    Write-Output '[WARN] Not running as administrator - some checks may be skipped'
    return $false
}

function Test-AdminRequired {
    [CmdletBinding()]
    param()

    if (Test-IsAdmin) {
        return
    }

    Write-Output '[ERROR] This audit requires administrator privileges'
    Write-Output '        Run PowerShell as Administrator or use: Start-Process -Verb RunAs'
    exit 1
}

function Register-AdminCheck {
    [CmdletBinding()]
    param(
        [string]$Message = 'Some checks require administrator privileges'
    )

    if (Test-IsAdmin) {
        Register-Check -Name 'Privilege Level' -Status PASS -Message 'Running as Administrator'
    }
    else {
        Register-Check -Name 'Privilege Level' -Status WARN -Message $Message
    }
}

function Invoke-AdminCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,
        [string]$CheckName,
        $FallbackValue = $null
    )

    try {
        return & $ScriptBlock
    }
    catch {
        $accessDenied = $_.Exception.Message -match 'Access.*(denied|forbidden)|not.*authorized|requires.*admin|elevation|privilege'

        if ($CheckName) {
            if ($accessDenied -or -not (Test-IsAdmin)) {
                Register-Check -Name $CheckName -Status SKIP -Message 'Requires elevated privileges'
            }
            else {
                Register-Check -Name $CheckName -Status WARN -Message $_.Exception.Message
            }
        }

        return $FallbackValue
    }
}

function Register-Check {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [ValidateSet('PASS', 'FAIL', 'WARN', 'SKIP', 'INFO')]
        [string]$Status,
        [string]$Message = '',
        [string]$CISReference = '',
        [string]$NISTReference = '',
        [string]$ISOReference = '',
        [string]$PCIReference = '',
        [ValidateRange(0, 10)]
        [int]$RiskScore = -1,
        [string]$RemediationCommand = '',
        [object]$Evidence = $null
    )

    if ($RiskScore -eq -1) {
        $RiskScore = switch ($Status) {
            'FAIL' { 7 }
            'WARN' { 4 }
            default { 0 }
        }
    }

    $compliance = @{}
    if ($CISReference) { $compliance.CIS = $CISReference }
    if ($NISTReference) { $compliance.NIST = $NISTReference }
    if ($ISOReference) { $compliance.ISO27001 = $ISOReference }
    if ($PCIReference) { $compliance.PCIDSS = $PCIReference }

    $record = [pscustomobject]@{
        Name = $Name
        Status = $Status
        Message = $Message
        Timestamp = (Get-Date).ToString('o')
        RiskScore = $RiskScore
        RiskLevel = Get-RiskLevel -Score $RiskScore
        Compliance = if ($compliance.Count -gt 0) { $compliance } else { $null }
        Remediation = if ($RemediationCommand) { $RemediationCommand } else { $null }
        Evidence = $Evidence
    }

    $script:CheckList += $record

    $line = "[$Status] $Name"
    if ($Message) { $line += " - $Message" }
    if ($compliance.Count -gt 0) {
        $refs = ($compliance.GetEnumerator() | ForEach-Object { "{0}:{1}" -f $_.Key, $_.Value }) -join ', '
        $line += " ($refs)"
    }
    Write-Output $line

    if ($Status -eq 'FAIL') { $script:ExitCode = 2 }
    elseif ($Status -eq 'WARN' -and $script:ExitCode -lt 2) { $script:ExitCode = 1 }
}

function Write-Section {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Title
    )

    Write-Output ''
    Write-Output ("=== {0} ===" -f $Title)
    Write-Output ''
}

function Get-AuditSummary {
    [CmdletBinding()]
    param()

    $total = $script:CheckList.Count
    $averageRisk = 0
    $maxRisk = 0

    if ($total -gt 0) {
        $averageRisk = [math]::Round(($script:CheckList | Measure-Object -Property RiskScore -Average).Average, 2)
        $maxRisk = ($script:CheckList | Measure-Object -Property RiskScore -Maximum).Maximum
    }

    return [pscustomobject]@{
        TotalChecks = $total
        Passed = @($script:CheckList | Where-Object Status -eq 'PASS').Count
        Warned = @($script:CheckList | Where-Object Status -eq 'WARN').Count
        Failed = @($script:CheckList | Where-Object Status -eq 'FAIL').Count
        Skipped = @($script:CheckList | Where-Object Status -eq 'SKIP').Count
        Info = @($script:CheckList | Where-Object Status -eq 'INFO').Count
        CriticalFindings = @($script:CheckList | Where-Object RiskLevel -eq 'Critical').Count
        HighFindings = @($script:CheckList | Where-Object RiskLevel -eq 'High').Count
        MediumFindings = @($script:CheckList | Where-Object RiskLevel -eq 'Medium').Count
        LowFindings = @($script:CheckList | Where-Object RiskLevel -eq 'Low').Count
        AverageRiskScore = $averageRisk
        MaxRiskScore = $maxRisk
    }
}

function Show-Summary {
    [CmdletBinding()]
    param()

    $summary = Get-AuditSummary

    Write-Output ''
    Write-Output ('=' * 60)
    Write-Output 'AUDIT SUMMARY'
    Write-Output ('=' * 60)
    Write-Output ("Total Checks: {0}" -f $summary.TotalChecks)
    Write-Output ("  PASS: {0} | WARN: {1} | FAIL: {2} | SKIP: {3} | INFO: {4}" -f $summary.Passed, $summary.Warned, $summary.Failed, $summary.Skipped, $summary.Info)
    Write-Output ''
    Write-Output 'Risk Analysis:'
    Write-Output ("  Critical: {0} | High: {1} | Average Score: {2}/10" -f $summary.CriticalFindings, $summary.HighFindings, $summary.AverageRiskScore)
    Write-Output ('=' * 60)
}

function Get-ComplianceSummary {
    [CmdletBinding()]
    param()

    $frameworkList = @('CIS', 'NIST', 'ISO27001', 'PCIDSS')
    $result = @{}

    foreach ($framework in $frameworkList) {
        $frameworkChecks = $script:CheckList | Where-Object { $_.Compliance -and $_.Compliance.ContainsKey($framework) }
        if (@($frameworkChecks).Count -eq 0) {
            continue
        }

        $passed = @($frameworkChecks | Where-Object Status -eq 'PASS').Count
        $failed = @($frameworkChecks | Where-Object Status -eq 'FAIL').Count
        $warned = @($frameworkChecks | Where-Object Status -eq 'WARN').Count
        $total = @($frameworkChecks).Count

        $result[$framework] = [ordered]@{
            totalControls = $total
            passed = $passed
            failed = $failed
            warned = $warned
            complianceRate = if ($total -gt 0) { [math]::Round(($passed / $total) * 100, 1) } else { 0 }
        }
    }

    return $result
}

function Export-AuditJson {
    [CmdletBinding()]
    param(
        [string]$FilePath = '',
        [switch]$IncludeEvidence,
        [switch]$CompactOutput
    )

    $script:AuditMetadata.EndTime = (Get-Date).ToString('o')
    if (-not $script:AuditMetadata.StartTime) {
        $script:AuditMetadata.StartTime = $script:AuditMetadata.EndTime
    }

    if (-not $script:AuditMetadata.OSVersion) {
        try {
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
            if ($os) {
                $script:AuditMetadata.OSVersion = "{0} {1}" -f $os.Caption, $os.Version
            }
            else {
                $script:AuditMetadata.OSVersion = 'Unknown'
            }
        }
        catch {
            $script:AuditMetadata.OSVersion = 'Unknown'
        }
    }

    $exportFindingList = foreach ($item in $script:CheckList) {
        $outItem = [ordered]@{
            name = $item.Name
            status = $item.Status
            message = $item.Message
            timestamp = $item.Timestamp
            riskScore = $item.RiskScore
            riskLevel = $item.RiskLevel
        }

        if ($item.Compliance) { $outItem.compliance = $item.Compliance }
        if ($item.Remediation) { $outItem.remediation = $item.Remediation }
        if ($IncludeEvidence -and $item.Evidence) { $outItem.evidence = $item.Evidence }

        [pscustomobject]$outItem
    }

    $report = [ordered]@{
        schema = 'audit-toolkit/v3'
        metadata = [ordered]@{
            hostname = $script:AuditMetadata.Hostname
            username = $script:AuditMetadata.Username
            osVersion = $script:AuditMetadata.OSVersion
            auditScript = $script:AuditMetadata.AuditScript
            auditVersion = $script:AuditMetadata.AuditVersion
            startTime = $script:AuditMetadata.StartTime
            endTime = $script:AuditMetadata.EndTime
            exitCode = $script:ExitCode
            isElevated = $script:AuditMetadata.IsElevated
        }
        summary = Get-AuditSummary
        findings = @($exportFindingList)
        complianceSummary = Get-ComplianceSummary
    }

    $json = if ($CompactOutput) { $report | ConvertTo-Json -Depth 10 -Compress } else { $report | ConvertTo-Json -Depth 10 }

    if ($FilePath) {
        $json | Set-Content -Path $FilePath -Encoding UTF8
        Write-Output ("Audit report saved to: {0}" -f $FilePath)
        return $FilePath
    }

    return $json
}

function Initialize-Audit {
    [CmdletBinding()]
    param(
        [string]$ScriptName = ''
    )

    $script:CheckList = @()
    $script:ExitCode = 0
    $script:AuditMetadata.StartTime = (Get-Date).ToString('o')
    $script:AuditMetadata.EndTime = $null
    $script:AuditMetadata.AuditScript = $ScriptName

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os) {
            $script:AuditMetadata.OSVersion = "{0} {1}" -f $os.Caption, $os.Version
        }
    }
    catch {
        Write-Verbose "OS metadata probe failed: $($_.Exception.Message)"
    }
}

function Reset-AuditState {
    [CmdletBinding(SupportsShouldProcess)]
    param()

    if (-not $PSCmdlet.ShouldProcess('Audit state', 'Reset in-memory audit state')) {
        return
    }

    $script:CheckList = @()
    $script:ExitCode = 0
    $script:AuditMetadata.StartTime = $null
    $script:AuditMetadata.EndTime = $null
    $script:AuditMetadata.AuditScript = $null
}

function Get-FailedCheck {
    [CmdletBinding()]
    param()

    return $script:CheckList | Where-Object { $_.Status -eq 'FAIL' } | Select-Object Name, Message, RiskScore, RiskLevel, Remediation
}

function Get-CheckByRiskLevel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Critical', 'High', 'Medium', 'Low', 'Info')]
        [string]$Level
    )

    return $script:CheckList | Where-Object { $_.RiskLevel -eq $Level }
}

function Get-RemediationScript {
    [CmdletBinding()]
    param()

    $failWithRemediation = $script:CheckList | Where-Object { $_.Status -eq 'FAIL' -and $_.Remediation }
    if (@($failWithRemediation).Count -eq 0) {
        return '# No remediations available for failed checks'
    }

    $out = @"
# Auto-generated Remediation Script
# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
# Host: $($script:AuditMetadata.Hostname)
#
# WARNING: Review each command before execution.

"@

    foreach ($item in $failWithRemediation) {
        $out += @"
# Remediation for: $($item.Name)
# Risk Level: $($item.RiskLevel) (Score: $($item.RiskScore))
# Finding: $($item.Message)
$($item.Remediation)

"@
    }

    return $out
}

function Exit-Audit {
    [CmdletBinding()]
    param()

    $summary = Get-AuditSummary
    if ($summary.Failed -gt 0) { exit 2 }
    if ($summary.Warned -gt 0) { exit 1 }
    exit 0
}

Set-Alias -Name Print-Summary -Value Show-Summary -Scope Script
Set-Alias -Name Export-AuditJSON -Value Export-AuditJson -Scope Script
Set-Alias -Name Get-FailedChecks -Value Get-FailedCheck -Scope Script
Set-Alias -Name Get-ChecksByRiskLevel -Value Get-CheckByRiskLevel -Scope Script

Export-ModuleMember -Function @(
    'Register-Check',
    'Show-Summary',
    'Write-Section',
    'Test-IsAdmin',
    'Test-AdminWarn',
    'Test-AdminRequired',
    'Register-AdminCheck',
    'Invoke-AdminCommand',
    'Initialize-Audit',
    'Reset-AuditState',
    'Get-AuditSummary',
    'Export-AuditJson',
    'Get-ComplianceSummary',
    'Get-FailedCheck',
    'Get-CheckByRiskLevel',
    'Exit-Audit',
    'Get-RemediationScript',
    'Get-RiskLevel'
) -Alias @(
    'Print-Summary',
    'Export-AuditJSON',
    'Get-FailedChecks',
    'Get-ChecksByRiskLevel'
)
