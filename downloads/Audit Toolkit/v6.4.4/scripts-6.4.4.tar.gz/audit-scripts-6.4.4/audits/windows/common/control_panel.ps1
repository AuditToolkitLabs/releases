# Control Panel & Personalization Audit Script (PowerShell)
# Checks CIS 18.1.x Administrative Templates (Computer) - Control Panel settings
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Windows 11 Benchmark v2.0 - Section 18.1
# - NIST SP 800-53: CM-6, AC-3

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTION
# ============================================================================

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$ExpectedValue,
        [string]$Description,
        [string]$CISRef = "",
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual
    )

    $displayName = if ($CISRef) { "($CISRef) $Description" } else { $Description }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        $passed = $false
        if ($GreaterOrEqual) {
            $passed = $actualValue -ge $ExpectedValue
        } elseif ($LessOrEqual) {
            $passed = $actualValue -le $ExpectedValue
        } else {
            $passed = $actualValue -eq $ExpectedValue
        }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message "Value: $actualValue"
        } else {
            Register-Check -Name $displayName -Status WARN -Message "Value: $actualValue (expected: $ExpectedValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status INFO -Message "Not configured"
    }
}

# ============================================================================
# CIS 18.1.1 - PERSONALIZATION
# ============================================================================
Write-Section "18.1.1 Personalization"

# 18.1.1.1 (L1) Ensure 'Prevent enabling lock screen camera' is set to 'Enabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization" `
    -Name "NoLockScreenCamera" -ExpectedValue 1 `
    -Description "Prevent lock screen camera" -CISRef "18.1.1.1"

# 18.1.1.2 (L1) Ensure 'Prevent enabling lock screen slide show' is set to 'Enabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization" `
    -Name "NoLockScreenSlideshow" -ExpectedValue 1 `
    -Description "Prevent lock screen slide show" -CISRef "18.1.1.2"

# ============================================================================
# CIS 18.1.2 - REGIONAL AND LANGUAGE OPTIONS
# ============================================================================
Write-Section "18.1.2 Regional and Language Options"

# 18.1.2.1 (L1) Ensure 'Allow users to enable online speech recognition services'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization" `
    -Name "AllowInputPersonalization" -ExpectedValue 0 `
    -Description "Online speech recognition" -CISRef "18.1.2.1"

# ============================================================================
# CIS 18.1.3 - CONTROL PANEL VISIBILITY
# ============================================================================
Write-Section "18.1.3 Control Panel Access"

# Check if Control Panel is restricted
try {
    $restrictCpl = Get-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" `
        -Name "NoControlPanel" -ErrorAction SilentlyContinue
    if ($restrictCpl.NoControlPanel -eq 1) {
        Register-Check -Name "Control Panel Access" -Status INFO -Message "Restricted for current user"
    } else {
        Register-Check -Name "Control Panel Access" -Status INFO -Message "Allowed"
    }
} catch {
    Register-Check -Name "Control Panel Access" -Status INFO -Message "Not restricted"
}

# ============================================================================
# ADDITIONAL PRIVACY - LOCATION
# ============================================================================
Write-Section "Location Services"

# App location access
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" `
    -Name "DisableLocation" -ExpectedValue 1 `
    -Description "Disable location services"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" `
    -Name "DisableLocationScripting" -ExpectedValue 1 `
    -Description "Disable location scripting"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" `
    -Name "DisableWindowsLocationProvider" -ExpectedValue 1 `
    -Description "Disable Windows location provider"

# ============================================================================
# ADDITIONAL PRIVACY - CAMERA
# ============================================================================
Write-Section "Camera Access"

# Camera access
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessCamera" -ExpectedValue 2 `
    -Description "Camera app access (2=Deny)"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Camera" `
    -Name "AllowCamera" -ExpectedValue 0 `
    -Description "Camera hardware disabled"

# ============================================================================
# ADDITIONAL PRIVACY - MICROPHONE
# ============================================================================
Write-Section "Microphone Access"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessMicrophone" -ExpectedValue 2 `
    -Description "Microphone app access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - NOTIFICATIONS
# ============================================================================
Write-Section "Notifications"

# Notifications on lock screen
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications" `
    -Name "NoCloudApplicationNotification" -ExpectedValue 1 `
    -Description "Disable cloud notifications"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications" `
    -Name "NoToastApplicationNotificationOnLockScreen" -ExpectedValue 1 `
    -Description "No toast on lock screen"

# ============================================================================
# ADDITIONAL PRIVACY - ADVERTISING
# ============================================================================
Write-Section "Advertising and Tracking"

# Advertising ID
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" `
    -Name "DisabledByGroupPolicy" -ExpectedValue 1 `
    -Description "Disable advertising ID"

# Activity History
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "EnableActivityFeed" -ExpectedValue 0 `
    -Description "Activity feed disabled"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "PublishUserActivities" -ExpectedValue 0 `
    -Description "Publish user activities disabled"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "UploadUserActivities" -ExpectedValue 0 `
    -Description "Upload user activities disabled"

# ============================================================================
# ADDITIONAL PRIVACY - SYNC
# ============================================================================
Write-Section "Sync Settings"

# Sync your settings
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync" `
    -Name "DisableSettingSync" -ExpectedValue 2 `
    -Description "Settings sync disabled"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync" `
    -Name "DisableSettingSyncUserOverride" -ExpectedValue 1 `
    -Description "Prevent user from enabling sync"

# ============================================================================
# ADDITIONAL PRIVACY - CLIPBOARD
# ============================================================================
Write-Section "Clipboard"

# Cloud clipboard
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "AllowClipboardHistory" -ExpectedValue 0 `
    -Description "Clipboard history disabled"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "AllowCrossDeviceClipboard" -ExpectedValue 0 `
    -Description "Cross-device clipboard disabled"

# ============================================================================
# ADDITIONAL PRIVACY - MESSAGING
# ============================================================================
Write-Section "Messaging"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessMessaging" -ExpectedValue 2 `
    -Description "Messaging app access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - APP DIAGNOSTICS
# ============================================================================
Write-Section "App Diagnostics"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsGetDiagnosticInfo" -ExpectedValue 2 `
    -Description "App diagnostic info (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - CALENDAR
# ============================================================================
Write-Section "Calendar Access"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessCalendar" -ExpectedValue 2 `
    -Description "Calendar app access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - CONTACTS
# ============================================================================
Write-Section "Contacts Access"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessContacts" -ExpectedValue 2 `
    -Description "Contacts app access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - CALL HISTORY
# ============================================================================
Write-Section "Call History"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessCallHistory" -ExpectedValue 2 `
    -Description "Call history access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - EMAIL
# ============================================================================
Write-Section "Email Access"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessEmail" -ExpectedValue 2 `
    -Description "Email app access (2=Deny)"

# ============================================================================
# ADDITIONAL PRIVACY - TASKS
# ============================================================================
Write-Section "Tasks Access"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" `
    -Name "LetAppsAccessTasks" -ExpectedValue 2 `
    -Description "Tasks app access (2=Deny)"

# ============================================================================
# SCREEN SAVER
# ============================================================================
Write-Section "Screen Saver"

# Screen saver timeout and password
try {
    $ssTimeout = Get-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ScreenSaveTimeOut" -ErrorAction SilentlyContinue
    $ssActive = Get-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ScreenSaveActive" -ErrorAction SilentlyContinue
    $ssSecure = Get-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ScreenSaverIsSecure" -ErrorAction SilentlyContinue

    if ($ssActive.ScreenSaveActive -eq "1") {
        Register-Check -Name "Screen Saver Enabled" -Status PASS -Message "Active"
    } else {
        Register-Check -Name "Screen Saver Enabled" -Status INFO -Message "Not active"
    }

    if ($ssSecure.ScreenSaverIsSecure -eq "1") {
        Register-Check -Name "Screen Saver Password" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "Screen Saver Password" -Status WARN -Message "Not required"
    }

    if ($ssTimeout.ScreenSaveTimeOut) {
        $timeoutSec = [int]$ssTimeout.ScreenSaveTimeOut
        if ($timeoutSec -le 900) {
            Register-Check -Name "Screen Saver Timeout" -Status PASS -Message "$timeoutSec seconds"
        } else {
            Register-Check -Name "Screen Saver Timeout" -Status WARN -Message "$timeoutSec seconds (>15 min)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Policy-based screen saver
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Control Panel\Desktop" `
    -Name "ScreenSaveActive" -ExpectedValue "1" `
    -Description "Screen saver policy enabled"

Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Control Panel\Desktop" `
    -Name "ScreenSaverIsSecure" -ExpectedValue "1" `
    -Description "Screen saver password policy"

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
