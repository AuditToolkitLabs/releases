<#
.SYNOPSIS
    Credential Guard and Virtualization-Based Security Audit

.DESCRIPTION
    Audits Windows credential protection features:
    - Credential Guard status
    - Virtualization-Based Security (VBS)
    - Hypervisor-Enforced Code Integrity (HVCI)
    - LSA protection
    - WDigest credential caching
    - NTLM restrictions

.NOTES
    Requires: Administrator privileges, Enterprise edition for full features

Compliance Mapping:
- CIS Controls: 6.5 (Password Credential Protection)
- NIST SP 800-53: IA-5 (Authenticator Management)
- MITRE ATT&CK: T1003 (OS Credential Dumping), T1558 (Golden Ticket)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Credential Guard Audit"

# ============================================================================
# HARDWARE REQUIREMENTS
# ============================================================================
Write-Section "Hardware/Firmware Requirements"

# Check for UEFI
try {
    $firmware = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State" -ErrorAction SilentlyContinue
    if ($firmware.UEFISecureBootEnabled -eq 1) {
        Register-Check -Name "Secure Boot" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Secure Boot" -Status WARN -Message "Disabled or not supported"
    }
} catch {
    # Alternative check
    try {
        $confirm = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
        if ($confirm) {
            Register-Check -Name "Secure Boot" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Secure Boot" -Status WARN -Message "Not enabled"
        }
    } catch {
        Register-Check -Name "Secure Boot" -Status SKIP -Message "Cannot determine"
    }
}

# Check Hyper-V / Virtualization
try {
    $hvFeature = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Hypervisor -ErrorAction SilentlyContinue
    if ($hvFeature -and $hvFeature.State -eq "Enabled") {
        Register-Check -Name "Hyper-V Hypervisor" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "Hyper-V Hypervisor" -Status WARN -Message "Not installed (required for VBS)"
    }
} catch {
    # Try on Server
    try {
        $hvRole = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
        if ($hvRole -and $hvRole.Installed) {
            Register-Check -Name "Hyper-V Role" -Status PASS -Message "Installed"
        } else {
            Register-Check -Name "Hyper-V Role" -Status INFO -Message "Not installed"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# TPM Check
try {
    $tpm = Get-Tpm -ErrorAction SilentlyContinue
    if ($tpm) {
        if ($tpm.TpmPresent -and $tpm.TpmReady) {
            Register-Check -Name "TPM" -Status PASS -Message "Present and ready (v$($tpm.ManufacturerVersion))"
        } elseif ($tpm.TpmPresent) {
            Register-Check -Name "TPM" -Status WARN -Message "Present but not ready"
        } else {
            Register-Check -Name "TPM" -Status WARN -Message "Not present"
        }
    }
} catch {
    Register-Check -Name "TPM" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# VIRTUALIZATION-BASED SECURITY (VBS)
# ============================================================================
Write-Section "Virtualization-Based Security"

try {
    $dgPath = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard"
    $dgConfig = Get-ItemProperty $dgPath -ErrorAction SilentlyContinue

    if ($dgConfig) {
        # VBS Enabled
        if ($dgConfig.EnableVirtualizationBasedSecurity -eq 1) {
            Register-Check -Name "VBS Policy" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "VBS Policy" -Status WARN -Message "Not enabled"
        }

        # Required security properties
        if ($dgConfig.RequirePlatformSecurityFeatures) {
            $secLevel = switch ($dgConfig.RequirePlatformSecurityFeatures) {
                1 { "Secure Boot" }
                3 { "Secure Boot + DMA Protection" }
                default { "Level $($dgConfig.RequirePlatformSecurityFeatures)" }
            }
            Register-Check -Name "VBS Security Requirements" -Status PASS -Message $secLevel
        }

        # UEFI Lock
        if ($dgConfig.Locked -eq 1) {
            Register-Check -Name "VBS UEFI Lock" -Status PASS -Message "Locked (cannot be disabled remotely)"
        } else {
            Register-Check -Name "VBS UEFI Lock" -Status WARN -Message "Not locked"
        }
    } else {
        Register-Check -Name "VBS Configuration" -Status WARN -Message "Not configured"
    }
} catch {
    Register-Check -Name "VBS Configuration" -Status SKIP -Message "Cannot query"
}

# VBS Runtime Status
try {
    $dgInfo = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction SilentlyContinue

    if ($dgInfo) {
        # VBS Status
        $vbsStatus = switch ($dgInfo.VirtualizationBasedSecurityStatus) {
            0 { "Not enabled" }
            1 { "Enabled but not running" }
            2 { "Running" }
            default { "Unknown" }
        }

        if ($dgInfo.VirtualizationBasedSecurityStatus -eq 2) {
            Register-Check -Name "VBS Status" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "VBS Status" -Status WARN -Message $vbsStatus
        }

        # Security services running
        $runningServices = $dgInfo.SecurityServicesRunning
        if ($runningServices -contains 1) {
            Register-Check -Name "Credential Guard" -Status PASS -Message "Running"
        }
        if ($runningServices -contains 2) {
            Register-Check -Name "HVCI" -Status PASS -Message "Running"
        }

        # Configured services
        $configuredServices = $dgInfo.SecurityServicesConfigured
        if ($configuredServices -contains 1 -and $runningServices -notcontains 1) {
            Register-Check -Name "Credential Guard" -Status WARN -Message "Configured but not running"
        }
        if ($configuredServices -contains 2 -and $runningServices -notcontains 2) {
            Register-Check -Name "HVCI" -Status WARN -Message "Configured but not running"
        }
    }
} catch {
    Register-Check -Name "VBS Runtime" -Status SKIP -Message "Cannot query WMI"
}

# ============================================================================
# CREDENTIAL GUARD CONFIGURATION
# ============================================================================
Write-Section "Credential Guard Settings"

try {
    $lsaCfgPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    $lsaCfg = Get-ItemProperty $lsaCfgPath -ErrorAction SilentlyContinue

    # LsaCfgFlags (Credential Guard config)
    if ($lsaCfg.LsaCfgFlags) {
        $flags = $lsaCfg.LsaCfgFlags
        switch ($flags) {
            0 { Register-Check -Name "Credential Guard Config" -Status WARN -Message "Disabled" }
            1 { Register-Check -Name "Credential Guard Config" -Status PASS -Message "Enabled with UEFI lock" }
            2 { Register-Check -Name "Credential Guard Config" -Status WARN -Message "Enabled without lock (can be disabled)" }
            default { Register-Check -Name "Credential Guard Config" -Status INFO -Message "Flags: $flags" }
        }
    } else {
        Register-Check -Name "Credential Guard Config" -Status WARN -Message "Not configured via registry"
    }
} catch {
    Register-Check -Name "Credential Guard Config" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# HYPERVISOR CODE INTEGRITY (HVCI)
# ============================================================================
Write-Section "HVCI / Memory Integrity"

try {
    $hvciPath = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity"
    $hvci = Get-ItemProperty $hvciPath -ErrorAction SilentlyContinue

    if ($hvci) {
        if ($hvci.Enabled -eq 1) {
            Register-Check -Name "HVCI Policy" -Status PASS -Message "Enabled"

            if ($hvci.Locked -eq 1) {
                Register-Check -Name "HVCI Lock" -Status PASS -Message "UEFI locked"
            } else {
                Register-Check -Name "HVCI Lock" -Status WARN -Message "Not locked"
            }
        } else {
            Register-Check -Name "HVCI Policy" -Status WARN -Message "Not enabled"
        }
    } else {
        Register-Check -Name "HVCI Policy" -Status WARN -Message "Not configured"
    }
} catch {
    Register-Check -Name "HVCI" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# LSA PROTECTION (RunAsPPL)
# ============================================================================
Write-Section "LSA Protection"

try {
    $lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    $runAsPpl = Get-ItemProperty $lsaPath -Name "RunAsPPL" -ErrorAction SilentlyContinue

    if ($runAsPpl.RunAsPPL -eq 1) {
        Register-Check -Name "LSA Protection (PPL)" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "LSA Protection (PPL)" -Status WARN -Message "Not enabled - credential theft possible"
    }
} catch {
    Register-Check -Name "LSA Protection" -Status WARN -Message "Not configured"
}

# Check for LSA protection UEFI variable (truly protected)
try {
    $lsaPplConfig = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RunAsPPLBoot" -ErrorAction SilentlyContinue
    if ($lsaPplConfig.RunAsPPLBoot -eq 2) {
        Register-Check -Name "LSA PPL UEFI" -Status PASS -Message "UEFI enforced"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# WDIGEST CREDENTIAL CACHING
# ============================================================================
Write-Section "WDigest Credential Caching"

try {
    $wdigestPath = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest"
    $wdigest = Get-ItemProperty $wdigestPath -Name "UseLogonCredential" -ErrorAction SilentlyContinue

    if ($wdigest.UseLogonCredential -eq 0) {
        Register-Check -Name "WDigest Caching" -Status PASS -Message "Disabled (cleartext creds not stored)"
    } elseif ($wdigest.UseLogonCredential -eq 1) {
        Register-Check -Name "WDigest Caching" -Status FAIL -Message "Enabled - cleartext passwords in LSASS"
    } else {
        # Default behavior varies by OS version
        $osVersion = [System.Environment]::OSVersion.Version
        if ($osVersion.Major -ge 10 -or ($osVersion.Major -eq 6 -and $osVersion.Minor -ge 3)) {
            Register-Check -Name "WDigest Caching" -Status PASS -Message "Disabled by default (Win 8.1+)"
        } else {
            Register-Check -Name "WDigest Caching" -Status WARN -Message "Check manually - older OS"
        }
    }
} catch {
    Register-Check -Name "WDigest Caching" -Status WARN -Message "Cannot determine"
}

# ============================================================================
# NTLM RESTRICTIONS
# ============================================================================
Write-Section "NTLM Restrictions"

try {
    $lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0"

    # NTLMMinClientSec
    $ntlmClient = Get-ItemProperty $lsaPath -Name "NTLMMinClientSec" -ErrorAction SilentlyContinue
    if ($ntlmClient.NTLMMinClientSec -ge 537395200) {
        Register-Check -Name "NTLM Client Security" -Status PASS -Message "NTLMv2 + 128-bit"
    } elseif ($ntlmClient.NTLMMinClientSec) {
        Register-Check -Name "NTLM Client Security" -Status WARN -Message "Value: $($ntlmClient.NTLMMinClientSec)"
    }

    # NTLMMinServerSec
    $ntlmServer = Get-ItemProperty $lsaPath -Name "NTLMMinServerSec" -ErrorAction SilentlyContinue
    if ($ntlmServer.NTLMMinServerSec -ge 537395200) {
        Register-Check -Name "NTLM Server Security" -Status PASS -Message "NTLMv2 + 128-bit"
    } elseif ($ntlmServer.NTLMMinServerSec) {
        Register-Check -Name "NTLM Server Security" -Status WARN -Message "Value: $($ntlmServer.NTLMMinServerSec)"
    }

    # Restrict NTLM in domain
    $ntlmPolicy = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0"
    $restrictNtlm = Get-ItemProperty $ntlmPolicy -Name "RestrictSendingNTLMTraffic" -ErrorAction SilentlyContinue
    if ($restrictNtlm.RestrictSendingNTLMTraffic -eq 2) {
        Register-Check -Name "NTLM Outbound" -Status PASS -Message "Deny all"
    } elseif ($restrictNtlm.RestrictSendingNTLMTraffic -eq 1) {
        Register-Check -Name "NTLM Outbound" -Status WARN -Message "Audit only"
    } else {
        Register-Check -Name "NTLM Outbound" -Status INFO -Message "Allowed"
    }

} catch {
    Register-Check -Name "NTLM Restrictions" -Status SKIP -Message "Cannot query"
}

# LM Hash storage
try {
    $noLmHash = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLMHash" -ErrorAction SilentlyContinue
    if ($noLmHash.NoLMHash -eq 1) {
        Register-Check -Name "LM Hash Storage" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "LM Hash Storage" -Status FAIL -Message "Enabled - weak hash stored"
    }
} catch {
    Register-Check -Name "LM Hash Storage" -Status WARN -Message "Cannot determine"
}

# ============================================================================
# REMOTE CREDENTIAL GUARD
# ============================================================================
Write-Section "Remote Credential Guard"

try {
    $rcgPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    $rcg = Get-ItemProperty $rcgPath -Name "DisableRestrictedAdmin" -ErrorAction SilentlyContinue

    # Restricted Admin mode
    if ($rcg.DisableRestrictedAdmin -eq 0) {
        Register-Check -Name "Restricted Admin Mode" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Restricted Admin Mode" -Status INFO -Message "Disabled"
    }

    # Remote Credential Guard
    $rcgPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "RemoteCredentialGuard" -ErrorAction SilentlyContinue
    if ($rcgPolicy.RemoteCredentialGuard -eq 1) {
        Register-Check -Name "Remote Credential Guard" -Status PASS -Message "Preferred"
    } elseif ($rcgPolicy.RemoteCredentialGuard -eq 2) {
        Register-Check -Name "Remote Credential Guard" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "Remote Credential Guard" -Status INFO -Message "Not configured"
    }
} catch {
    Register-Check -Name "Remote Credential Guard" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# CACHED LOGON CREDENTIALS
# ============================================================================
Write-Section "Cached Credentials"

try {
    $cachedPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
    $cached = Get-ItemProperty $cachedPath -Name "CachedLogonsCount" -ErrorAction SilentlyContinue

    $count = $cached.CachedLogonsCount
    if ($count -eq 0) {
        Register-Check -Name "Cached Logons" -Status PASS -Message "Disabled"
    } elseif ($count -le 2) {
        Register-Check -Name "Cached Logons" -Status PASS -Message "$count (minimal)"
    } elseif ($count -le 4) {
        Register-Check -Name "Cached Logons" -Status WARN -Message "$count - consider reducing"
    } else {
        Register-Check -Name "Cached Logons" -Status WARN -Message "$count - too many cached"
    }
} catch {
    Register-Check -Name "Cached Logons" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit