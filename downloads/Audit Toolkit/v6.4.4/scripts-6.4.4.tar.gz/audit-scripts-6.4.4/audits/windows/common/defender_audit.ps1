<#
.SYNOPSIS
    Windows Defender / Microsoft Defender Antivirus Audit

.DESCRIPTION
    Comprehensive Defender configuration audit:
    - Real-time protection status
    - Cloud protection settings
    - Tamper protection
    - Exclusion analysis
    - Attack Surface Reduction (ASR) rules
    - Exploit protection
    - Controlled folder access
    - Scan configuration

.NOTES
    @elevation: admin
    @elevation-reason: Get-MpComputerStatus and Defender cmdlets require Administrator
    Requires: Administrator for full configuration access

Compliance Mapping:
- CIS Controls: 10.1 (Deploy Anti-Malware), 10.2 (Configure Auto Updates)
- CIS Windows Benchmark: 18.9.47.x (Defender Settings)
- NIST SP 800-53: SI-3 (Malicious Code Protection)
- MITRE ATT&CK: Defense Evasion Techniques
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows Defender Audit"

# ============================================================================
# DEFENDER SERVICE STATUS
# ============================================================================
Write-Section "Defender Services"

$defenderServices = @{
    "WinDefend" = "Windows Defender Antivirus Service"
    "WdNisSvc" = "Windows Defender Network Inspection Service"
    "Sense" = "Windows Defender Advanced Threat Protection"
}

foreach ($svc in $defenderServices.GetEnumerator()) {
    try {
        $service = Get-Service -Name $svc.Key -ErrorAction SilentlyContinue
        if ($service) {
            if ($service.Status -eq 'Running') {
                Register-Check -Name $svc.Value -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Value -Status WARN -Message "Status: $($service.Status)"
            }
        } else {
            Register-Check -Name $svc.Value -Status SKIP -Message "Not installed"
        }
    } catch {
        Register-Check -Name $svc.Value -Status SKIP -Message "Cannot query"
    }
}

# ============================================================================
# REAL-TIME PROTECTION
# ============================================================================
Write-Section "Real-Time Protection"

try {
    $mpStatus = Get-MpComputerStatus -ErrorAction Stop

    # Real-time protection
    if ($mpStatus.RealTimeProtectionEnabled) {
        Register-Check -Name "Real-Time Protection" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Real-Time Protection" -Status FAIL -Message "Disabled"
    }

    # Behavior monitoring
    if ($mpStatus.BehaviorMonitorEnabled) {
        Register-Check -Name "Behavior Monitoring" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Behavior Monitoring" -Status FAIL -Message "Disabled"
    }

    # On-access protection
    if ($mpStatus.OnAccessProtectionEnabled) {
        Register-Check -Name "On-Access Protection" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "On-Access Protection" -Status FAIL -Message "Disabled"
    }

    # IoaV protection (downloading files)
    if ($mpStatus.IoavProtectionEnabled) {
        Register-Check -Name "Download Protection" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Download Protection" -Status FAIL -Message "Disabled"
    }

    # Antispyware
    if ($mpStatus.AntispywareEnabled) {
        Register-Check -Name "Antispyware" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Antispyware" -Status WARN -Message "Disabled"
    }

} catch {
    Register-Check -Name "Real-Time Protection" -Status SKIP -Message "Cannot query MpComputerStatus"
}

# ============================================================================
# CLOUD PROTECTION
# ============================================================================
Write-Section "Cloud Protection"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    # Cloud-delivered protection (MAPS)
    if ($mpPref.MAPSReporting -ge 1) {
        $mapLevel = switch ($mpPref.MAPSReporting) {
            1 { "Basic" }
            2 { "Advanced" }
            default { "Level $($mpPref.MAPSReporting)" }
        }
        Register-Check -Name "Cloud Protection (MAPS)" -Status PASS -Message "$mapLevel reporting"
    } else {
        Register-Check -Name "Cloud Protection (MAPS)" -Status FAIL -Message "Disabled - reduced protection"
    }

    # Block at first sight
    if ($mpPref.DisableBlockAtFirstSeen -eq $false) {
        Register-Check -Name "Block at First Sight" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Block at First Sight" -Status WARN -Message "Disabled"
    }

    # Cloud block level
    $cloudLevel = switch ($mpPref.CloudBlockLevel) {
        0 { "Default" }
        1 { "Moderate" }
        2 { "High" }
        4 { "High+" }
        6 { "Zero Tolerance" }
        default { "Level $($mpPref.CloudBlockLevel)" }
    }

    if ($mpPref.CloudBlockLevel -ge 2) {
        Register-Check -Name "Cloud Block Level" -Status PASS -Message $cloudLevel
    } else {
        Register-Check -Name "Cloud Block Level" -Status WARN -Message "$cloudLevel - consider High or above"
    }

    # Cloud extended timeout
    $timeout = $mpPref.CloudExtendedTimeout
    if ($timeout -ge 50) {
        Register-Check -Name "Cloud Extended Timeout" -Status PASS -Message "$timeout seconds"
    } else {
        Register-Check -Name "Cloud Extended Timeout" -Status INFO -Message "$timeout seconds"
    }

} catch {
    Register-Check -Name "Cloud Protection" -Status SKIP -Message "Cannot query preferences"
}

# ============================================================================
# TAMPER PROTECTION
# ============================================================================
Write-Section "Tamper Protection"

try {
    $mpStatus = Get-MpComputerStatus -ErrorAction SilentlyContinue

    if ($mpStatus.IsTamperProtected) {
        Register-Check -Name "Tamper Protection" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Tamper Protection" -Status FAIL -Message "Disabled - settings can be modified"
    }
} catch {
    # Try registry fallback
    try {
        $tamperPath = "HKLM:\SOFTWARE\Microsoft\Windows Defender\Features"
        $tamper = Get-ItemProperty $tamperPath -Name "TamperProtection" -ErrorAction SilentlyContinue

        if ($tamper.TamperProtection -eq 5) {
            Register-Check -Name "Tamper Protection" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Tamper Protection" -Status WARN -Message "Value: $($tamper.TamperProtection)"
        }
    } catch {
        Register-Check -Name "Tamper Protection" -Status SKIP -Message "Cannot determine"
    }
}

# ============================================================================
# DEFINITION UPDATES
# ============================================================================
Write-Section "Signature Updates"

try {
    $mpStatus = Get-MpComputerStatus -ErrorAction SilentlyContinue

    # Signature age
    $sigAge = $mpStatus.AntivirusSignatureAge
    if ($sigAge -le 1) {
        Register-Check -Name "Signature Age" -Status PASS -Message "$sigAge day(s) old"
    } elseif ($sigAge -le 3) {
        Register-Check -Name "Signature Age" -Status WARN -Message "$sigAge days old"
    } else {
        Register-Check -Name "Signature Age" -Status FAIL -Message "$sigAge days old - update immediately"
    }

    # Signature version
    $sigVer = $mpStatus.AntivirusSignatureVersion
    Register-Check -Name "Signature Version" -Status INFO -Message $sigVer

    # Engine version
    $engineVer = $mpStatus.AMEngineVersion
    Register-Check -Name "Engine Version" -Status INFO -Message $engineVer

    # Last update time
    $lastUpdate = $mpStatus.AntivirusSignatureLastUpdated
    if ($lastUpdate) {
        Register-Check -Name "Last Update" -Status INFO -Message $lastUpdate.ToString("yyyy-MM-dd HH:mm")
    }

} catch {
    Register-Check -Name "Signature Updates" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# EXCLUSIONS (Security Risk)
# ============================================================================
Write-Section "Exclusions"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    # Path exclusions
    $pathExclusions = $mpPref.ExclusionPath
    $pathCount = @($pathExclusions | Where-Object { $_ }).Count

    if ($pathCount -eq 0) {
        Register-Check -Name "Path Exclusions" -Status PASS -Message "None"
    } elseif ($pathCount -le 5) {
        Register-Check -Name "Path Exclusions" -Status WARN -Message "$pathCount path(s) excluded"
    } else {
        Register-Check -Name "Path Exclusions" -Status WARN -Message "$pathCount paths - review for necessity"
    }

    # Check for risky exclusions
    $riskyPaths = @("C:\", "C:\Windows", "C:\Users", "C:\Program Files")
    foreach ($exclusion in $pathExclusions) {
        if ($exclusion -in $riskyPaths) {
            Register-Check -Name "Risky Exclusion" -Status FAIL -Message "Critical path excluded: $exclusion"
        }
    }

    # Process exclusions
    $procExclusions = $mpPref.ExclusionProcess
    $procCount = @($procExclusions | Where-Object { $_ }).Count

    if ($procCount -eq 0) {
        Register-Check -Name "Process Exclusions" -Status PASS -Message "None"
    } else {
        Register-Check -Name "Process Exclusions" -Status WARN -Message "$procCount process(es) excluded"
    }

    # Extension exclusions
    $extExclusions = $mpPref.ExclusionExtension
    $extCount = @($extExclusions | Where-Object { $_ }).Count

    if ($extCount -eq 0) {
        Register-Check -Name "Extension Exclusions" -Status PASS -Message "None"
    } else {
        Register-Check -Name "Extension Exclusions" -Status WARN -Message "$extCount extension(s) excluded"

        # Check for risky extensions
        $riskyExts = @(".exe", ".dll", ".ps1", ".bat", ".cmd", ".vbs", ".js")
        foreach ($ext in $extExclusions) {
            if ($ext -in $riskyExts) {
                Register-Check -Name "Risky Extension" -Status FAIL -Message "Executable extension excluded: $ext"
            }
        }
    }

} catch {
    Register-Check -Name "Exclusions" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# ATTACK SURFACE REDUCTION (ASR)
# ============================================================================
Write-Section "Attack Surface Reduction"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    $asrRules = $mpPref.AttackSurfaceReductionRules_Ids
    $asrActions = $mpPref.AttackSurfaceReductionRules_Actions

    if ($asrRules -and $asrRules.Count -gt 0) {
        $blockCount = 0
        $auditCount = 0
        $warnCount = 0

        for ($i = 0; $i -lt $asrRules.Count; $i++) {
            $action = if ($asrActions -and $i -lt $asrActions.Count) { $asrActions[$i] } else { 0 }
            switch ($action) {
                0 { } # Disabled
                1 { $blockCount++ }
                2 { $auditCount++ }
                6 { $warnCount++ }
            }
        }

        Register-Check -Name "ASR Rules Configured" -Status PASS -Message "$($asrRules.Count) rule(s)"

        if ($blockCount -gt 0) {
            Register-Check -Name "ASR Blocking" -Status PASS -Message "$blockCount rule(s) in block mode"
        }
        if ($auditCount -gt 0) {
            Register-Check -Name "ASR Audit" -Status WARN -Message "$auditCount rule(s) in audit mode - consider blocking"
        }
    } else {
        Register-Check -Name "ASR Rules" -Status FAIL -Message "Not configured - significant attack surface"
    }

} catch {
    Register-Check -Name "ASR Rules" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# CONTROLLED FOLDER ACCESS
# ============================================================================
Write-Section "Controlled Folder Access"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    $cfaState = $mpPref.EnableControlledFolderAccess
    switch ($cfaState) {
        0 { Register-Check -Name "Controlled Folder Access" -Status WARN -Message "Disabled" }
        1 { Register-Check -Name "Controlled Folder Access" -Status PASS -Message "Enabled (Block)" }
        2 { Register-Check -Name "Controlled Folder Access" -Status WARN -Message "Audit mode" }
        default { Register-Check -Name "Controlled Folder Access" -Status INFO -Message "State: $cfaState" }
    }

    # Protected folders
    $protectedFolders = $mpPref.ControlledFolderAccessProtectedFolders
    if ($protectedFolders) {
        Register-Check -Name "Custom Protected Folders" -Status INFO -Message "$(@($protectedFolders).Count) folder(s)"
    }

} catch {
    Register-Check -Name "Controlled Folder Access" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# NETWORK PROTECTION
# ============================================================================
Write-Section "Network Protection"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    $netProtect = $mpPref.EnableNetworkProtection
    switch ($netProtect) {
        0 { Register-Check -Name "Network Protection" -Status WARN -Message "Disabled" }
        1 { Register-Check -Name "Network Protection" -Status PASS -Message "Enabled (Block)" }
        2 { Register-Check -Name "Network Protection" -Status WARN -Message "Audit mode" }
        default { Register-Check -Name "Network Protection" -Status INFO -Message "State: $netProtect" }
    }
} catch {
    Register-Check -Name "Network Protection" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# SCAN SETTINGS
# ============================================================================
Write-Section "Scan Configuration"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    # Scan type
    $scanType = switch ($mpPref.ScanParameters) {
        1 { "Quick Scan" }
        2 { "Full Scan" }
        default { "Type $($mpPref.ScanParameters)" }
    }
    Register-Check -Name "Default Scan Type" -Status INFO -Message $scanType

    # Scan schedule
    $scanDay = $mpPref.ScanScheduleDay
    if ($scanDay -eq 0) {
        Register-Check -Name "Scheduled Scan" -Status PASS -Message "Daily"
    } elseif ($scanDay -le 7) {
        Register-Check -Name "Scheduled Scan" -Status PASS -Message "Weekly"
    } elseif ($scanDay -eq 8) {
        Register-Check -Name "Scheduled Scan" -Status WARN -Message "Never scheduled"
    }

    # Archive scanning
    if ($mpPref.DisableArchiveScanning -eq $false) {
        Register-Check -Name "Archive Scanning" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Archive Scanning" -Status WARN -Message "Disabled"
    }

    # Email scanning
    if ($mpPref.DisableEmailScanning -eq $false) {
        Register-Check -Name "Email Scanning" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Email Scanning" -Status INFO -Message "Disabled"
    }

    # Removable drive scanning
    if ($mpPref.DisableRemovableDriveScanning -eq $false) {
        Register-Check -Name "Removable Drive Scanning" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Removable Drive Scanning" -Status WARN -Message "Disabled"
    }

} catch {
    Register-Check -Name "Scan Configuration" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# PUA PROTECTION
# ============================================================================
Write-Section "PUA Protection"

try {
    $mpPref = Get-MpPreference -ErrorAction Stop

    $puaMode = $mpPref.PUAProtection
    switch ($puaMode) {
        0 { Register-Check -Name "PUA Protection" -Status WARN -Message "Disabled" }
        1 { Register-Check -Name "PUA Protection" -Status PASS -Message "Enabled (Block)" }
        2 { Register-Check -Name "PUA Protection" -Status INFO -Message "Audit mode" }
        default { Register-Check -Name "PUA Protection" -Status INFO -Message "Mode: $puaMode" }
    }
} catch {
    Register-Check -Name "PUA Protection" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# THIRD-PARTY AV CHECK
# ============================================================================
Write-Section "Third-Party Antivirus"

try {
    $avProducts = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue

    if ($avProducts) {
        foreach ($av in $avProducts) {
            $avName = $av.displayName
            if ($avName -notmatch "Windows Defender") {
                Register-Check -Name "Third-Party AV" -Status INFO -Message $avName
            }
        }
    }
} catch {
    Register-Check -Name "Third-Party AV" -Status SKIP -Message "Cannot detect"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
