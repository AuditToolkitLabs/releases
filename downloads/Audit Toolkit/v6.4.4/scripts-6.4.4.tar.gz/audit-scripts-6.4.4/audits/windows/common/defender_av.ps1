<#
Microsoft Defender Antivirus Audit

Compliance Mapping:
- CIS Controls: 8.1, 8.2, 16.11
- NIST SP 800-53: SI-3, SI-4, SI-7
- ISO 27001: A.12.2, A.12.4, A.13.2
- OWASP ASVS: V10
- UK NCSC: Endpoint Security, Malware Protection
- PCI DSS: 5.1, 5.2, 10.2

Each check in this script is annotated in comments with relevant compliance mappings.
#>
# Check Microsoft Defender Antivirus Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
    if ($defender.AntivirusEnabled -and $defender.RealTimeProtectionEnabled) {
        Register-Check -Name "Defender Antivirus" -Status PASS -Message "Active and real-time protection enabled."
    } else {
        Register-Check -Name "Defender Antivirus" -Status FAIL -Message "Not fully active."
    }
} catch {
    Register-Check -Name "Defender Antivirus" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit