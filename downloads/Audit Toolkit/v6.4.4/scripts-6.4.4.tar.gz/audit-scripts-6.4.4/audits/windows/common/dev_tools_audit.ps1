# Developer Tools Security Audit Script (PowerShell)
# Checks security configuration of common developer tools
# This script is read-only and does not modify system state.
#
# References:
# - CIS Controls 2: Inventory of Software Assets
# - NIST SP 800-53: CM-7, SA-22

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# GIT SECURITY
# ============================================================================
Write-Section "Git Configuration"

$gitPath = Get-Command git -ErrorAction SilentlyContinue
if ($gitPath) {
    $gitVersion = git --version 2>$null
    Register-Check -Name "Git Installed" -Status PASS -Message $gitVersion

    # Git credential helper
    try {
        $credHelper = git config --global credential.helper 2>$null
        if ($credHelper -eq "manager" -or $credHelper -eq "manager-core" -or $credHelper -eq "wincred") {
            Register-Check -Name "Git Credential Helper" -Status PASS -Message $credHelper
        } elseif ($credHelper -eq "store") {
            Register-Check -Name "Git Credential Helper" -Status WARN -Message "Plaintext store (insecure)"
        } elseif ($credHelper -eq "cache") {
            Register-Check -Name "Git Credential Helper" -Status INFO -Message "Cache (temporary)"
        } else {
            Register-Check -Name "Git Credential Helper" -Status INFO -Message "None or custom"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Commit signing
    try {
        $gpgSign = git config --global commit.gpgsign 2>$null
        if ($gpgSign -eq "true") {
            Register-Check -Name "Commit Signing" -Status PASS -Message "GPG signing enabled"
        } else {
            Register-Check -Name "Commit Signing" -Status INFO -Message "Not configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Safe directory configuration
    try {
        $safeDir = git config --global --get-all safe.directory 2>$null
        if ($safeDir -eq "*") {
            Register-Check -Name "Git Safe Directory" -Status WARN -Message "All directories trusted (CVE-2022-24765 risk)"
        } else {
            Register-Check -Name "Git Safe Directory" -Status PASS -Message "Restricted"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # HTTPS enforcement
    try {
        $sslVerify = git config --global http.sslVerify 2>$null
        if ($sslVerify -eq "false") {
            Register-Check -Name "Git SSL Verify" -Status FAIL -Message "Disabled (insecure)"
        } else {
            Register-Check -Name "Git SSL Verify" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # User identity configured
    try {
        $userName = git config --global user.name 2>$null
        $userEmail = git config --global user.email 2>$null
        if ($userName -and $userEmail) {
            Register-Check -Name "Git Identity" -Status PASS -Message "$userName <$userEmail>"
        } else {
            Register-Check -Name "Git Identity" -Status WARN -Message "Not configured globally"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "Git Installed" -Status INFO -Message "Not installed"
}

# ============================================================================
# DOCKER SECURITY
# ============================================================================
Write-Section "Docker Configuration"

$dockerService = Get-Service -Name "Docker" -ErrorAction SilentlyContinue
if ($dockerService) {
    if ($dockerService.Status -eq "Running") {
        Register-Check -Name "Docker Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Docker Service" -Status INFO -Message "$($dockerService.Status)"
    }

    # Docker version
    try {
        $dockerVersion = docker --version 2>$null
        if ($dockerVersion) {
            Register-Check -Name "Docker Version" -Status INFO -Message $dockerVersion
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Docker context (rootless?)
    try {
        $dockerInfo = docker info --format '{{.SecurityOptions}}' 2>$null
        if ($dockerInfo -match "rootless") {
            Register-Check -Name "Docker Mode" -Status PASS -Message "Rootless mode"
        } else {
            Register-Check -Name "Docker Mode" -Status INFO -Message "Standard (root) mode"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Check if user is in docker group
    try {
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $dockerUsers = Get-LocalGroupMember -Group "docker-users" -ErrorAction SilentlyContinue
        if ($dockerUsers | Where-Object { $_.SID -eq $currentUser.User }) {
            Register-Check -Name "Docker Access" -Status INFO -Message "Current user in docker-users group"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Docker Desktop settings
    $dockerSettingsPath = "$env:APPDATA\Docker\settings.json"
    if (Test-Path $dockerSettingsPath) {
        try {
            $dockerSettings = Get-Content $dockerSettingsPath -Raw | ConvertFrom-Json

            # WSL 2 backend
            if ($dockerSettings.wslEngineEnabled -eq $true) {
                Register-Check -Name "Docker Backend" -Status INFO -Message "WSL 2"
            } else {
                Register-Check -Name "Docker Backend" -Status INFO -Message "Hyper-V"
            }

            # Kubernetes enabled
            if ($dockerSettings.kubernetesEnabled -eq $true) {
                Register-Check -Name "Docker Kubernetes" -Status INFO -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
} else {
    # Check for Docker CLI without service (Rancher Desktop, Podman, etc.)
    $dockerCli = Get-Command docker -ErrorAction SilentlyContinue
    if ($dockerCli) {
        Register-Check -Name "Docker CLI" -Status INFO -Message "Available (alternative runtime)"
    } else {
        Register-Check -Name "Docker" -Status INFO -Message "Not installed"
    }
}

# ============================================================================
# WSL (WINDOWS SUBSYSTEM FOR LINUX)
# ============================================================================
Write-Section "WSL Configuration"

try {
    $wslOutput = wsl --list --verbose 2>$null
    if ($wslOutput) {
        Register-Check -Name "WSL Installed" -Status PASS -Message "Enabled"

        # Parse distros
        $distros = $wslOutput | Where-Object { $_ -match "^\s*\*?\s*(\S+)\s+(Running|Stopped)\s+(\d)" }
        $runningCount = ($wslOutput | Select-String -Pattern "Running").Count
        $totalCount = ($distros | Measure-Object).Count

        Register-Check -Name "WSL Distributions" -Status INFO -Message "$totalCount installed, $runningCount running"

        # Check WSL version
        $wsl2Count = ($wslOutput | Select-String -Pattern "\s+2\s*$").Count
        if ($wsl2Count -gt 0) {
            Register-Check -Name "WSL Version" -Status PASS -Message "WSL 2 in use"
        } else {
            Register-Check -Name "WSL Version" -Status INFO -Message "WSL 1 only"
        }

        # Check .wslconfig
        $wslConfigPath = "$env:USERPROFILE\.wslconfig"
        if (Test-Path $wslConfigPath) {
            Register-Check -Name "WSL Config" -Status INFO -Message ".wslconfig present"

            $wslConfig = Get-Content $wslConfigPath -Raw

            # Memory limit
            if ($wslConfig -match "memory\s*=\s*(\d+)") {
                Register-Check -Name "WSL Memory Limit" -Status PASS -Message "$($Matches[1]) configured"
            }

            # nestedVirtualization
            if ($wslConfig -match "nestedVirtualization\s*=\s*true") {
                Register-Check -Name "WSL Nested Virtualization" -Status INFO -Message "Enabled"
            }
        }
    } else {
        Register-Check -Name "WSL Installed" -Status INFO -Message "Not enabled"
    }
} catch {
    Register-Check -Name "WSL" -Status INFO -Message "Not available"
}

# ============================================================================
# VISUAL STUDIO CODE
# ============================================================================
Write-Section "Visual Studio Code"

$vscodePaths = @(
    "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe",
    "$env:ProgramFiles\Microsoft VS Code\Code.exe",
    "$env:LOCALAPPDATA\Programs\Microsoft VS Code Insiders\Code - Insiders.exe"
)

$vscodeFound = $false
foreach ($path in $vscodePaths) {
    if (Test-Path $path) {
        $vscodeFound = $true
        $version = (Get-Item $path).VersionInfo.FileVersion
        $edition = if ($path -match "Insiders") { "Insiders" } else { "Stable" }
        Register-Check -Name "VS Code Installed" -Status PASS -Message "v$version ($edition)"
        break
    }
}

if (-not $vscodeFound) {
    Register-Check -Name "VS Code Installed" -Status INFO -Message "Not installed"
}

# VS Code settings
$vscodeSettingsPath = "$env:APPDATA\Code\User\settings.json"
if (Test-Path $vscodeSettingsPath) {
    try {
        $vscodeSettings = Get-Content $vscodeSettingsPath -Raw | ConvertFrom-Json

        # Telemetry settings
        if ($vscodeSettings."telemetry.telemetryLevel" -eq "off") {
            Register-Check -Name "VS Code Telemetry" -Status PASS -Message "Disabled"
        } elseif ($vscodeSettings."telemetry.enableTelemetry" -eq $false) {
            Register-Check -Name "VS Code Telemetry" -Status PASS -Message "Disabled (legacy setting)"
        } else {
            Register-Check -Name "VS Code Telemetry" -Status INFO -Message "Enabled"
        }

        # Remote SSH settings
        if ($vscodeSettings."remote.SSH.useLocalServer" -eq $false) {
            Register-Check -Name "VS Code Remote SSH" -Status INFO -Message "Local server disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# VS Code extensions
$extensionsPath = "$env:USERPROFILE\.vscode\extensions"
if (Test-Path $extensionsPath) {
    $extensions = Get-ChildItem -Path $extensionsPath -Directory
    $extCount = $extensions.Count
    Register-Check -Name "VS Code Extensions" -Status INFO -Message "$extCount installed"

    # Check for potentially risky extensions (remote, shell, etc.)
    $remoteExt = $extensions | Where-Object { $_.Name -match "remote|ssh|container" }
    if ($remoteExt) {
        Register-Check -Name "Remote Extensions" -Status INFO -Message "$($remoteExt.Count) remote-capable extension(s)"
    }
}

# ============================================================================
# NODE.JS / NPM
# ============================================================================
Write-Section "Node.js / npm"

$nodePath = Get-Command node -ErrorAction SilentlyContinue
if ($nodePath) {
    $nodeVersion = node --version 2>$null
    Register-Check -Name "Node.js Installed" -Status PASS -Message $nodeVersion

    # npm version
    $npmVersion = npm --version 2>$null
    if ($npmVersion) {
        Register-Check -Name "npm Version" -Status INFO -Message "v$npmVersion"
    }

    # npm audit (check if available)
    try {
        npm audit --version 2>$null | Out-Null
        Register-Check -Name "npm Audit" -Status PASS -Message "Available"
    } catch {
        Register-Check -Name "npm Audit" -Status INFO -Message "Not available"
    }

    # Global packages location
    $npmPrefix = npm config get prefix 2>$null
    if ($npmPrefix) {
        Register-Check -Name "npm Global Path" -Status INFO -Message $npmPrefix
    }

    # npm registry
    $npmRegistry = npm config get registry 2>$null
    if ($npmRegistry -eq "https://registry.npmjs.org/") {
        Register-Check -Name "npm Registry" -Status PASS -Message "Official registry"
    } elseif ($npmRegistry) {
        Register-Check -Name "npm Registry" -Status INFO -Message $npmRegistry
    }
} else {
    Register-Check -Name "Node.js" -Status INFO -Message "Not installed"
}

# ============================================================================
# PYTHON
# ============================================================================
Write-Section "Python"

$pythonPaths = @("python", "python3", "py")
$pythonFound = $false

foreach ($pyCmd in $pythonPaths) {
    $pyPath = Get-Command $pyCmd -ErrorAction SilentlyContinue
    if ($pyPath) {
        $pyVersion = & $pyCmd --version 2>&1
        Register-Check -Name "Python Installed" -Status PASS -Message $pyVersion
        $pythonFound = $true

        # pip version
        $pipVersion = & $pyCmd -m pip --version 2>$null
        if ($pipVersion) {
            Register-Check -Name "pip" -Status INFO -Message ($pipVersion -split " ")[1]
        }
        break
    }
}

if (-not $pythonFound) {
    Register-Check -Name "Python" -Status INFO -Message "Not installed"
}

# ============================================================================
# PACKAGE MANAGERS
# ============================================================================
Write-Section "Package Managers"

# Chocolatey
$chocoPath = Get-Command choco -ErrorAction SilentlyContinue
if ($chocoPath) {
    $chocoVersion = choco --version 2>$null
    Register-Check -Name "Chocolatey" -Status PASS -Message "v$chocoVersion"
} else {
    Register-Check -Name "Chocolatey" -Status INFO -Message "Not installed"
}

# Scoop
$scoopPath = Get-Command scoop -ErrorAction SilentlyContinue
if ($scoopPath) {
    Register-Check -Name "Scoop" -Status INFO -Message "Installed"
} else {
    Register-Check -Name "Scoop" -Status INFO -Message "Not installed"
}

# winget
$wingetPath = Get-Command winget -ErrorAction SilentlyContinue
if ($wingetPath) {
    $wingetVersion = winget --version 2>$null
    Register-Check -Name "winget" -Status PASS -Message $wingetVersion
} else {
    Register-Check -Name "winget" -Status INFO -Message "Not installed"
}

# ============================================================================
# JAVA / JDK
# ============================================================================
Write-Section "Java"

$javaPath = Get-Command java -ErrorAction SilentlyContinue
if ($javaPath) {
    $javaVersion = java -version 2>&1 | Select-Object -First 1
    Register-Check -Name "Java Installed" -Status PASS -Message $javaVersion

    # Check JAVA_HOME
    if ($env:JAVA_HOME) {
        Register-Check -Name "JAVA_HOME" -Status INFO -Message $env:JAVA_HOME
    }
} else {
    Register-Check -Name "Java" -Status INFO -Message "Not installed"
}

# ============================================================================
# PODMAN (Alternative Container Runtime)
# ============================================================================
Write-Section "Podman"

$podmanPath = Get-Command podman -ErrorAction SilentlyContinue
if ($podmanPath) {
    $podmanVersion = podman --version 2>$null
    Register-Check -Name "Podman" -Status PASS -Message $podmanVersion
} else {
    Register-Check -Name "Podman" -Status INFO -Message "Not installed"
}

# ============================================================================
# KUBERNETES TOOLS
# ============================================================================
Write-Section "Kubernetes Tools"

# kubectl
$kubectlPath = Get-Command kubectl -ErrorAction SilentlyContinue
if ($kubectlPath) {
    $kubectlVersion = kubectl version --client --short 2>$null
    if (-not $kubectlVersion) {
        $kubectlVersion = kubectl version --client 2>$null | Select-Object -First 1
    }
    Register-Check -Name "kubectl" -Status PASS -Message $kubectlVersion

    # Check kubeconfig
    $kubeconfig = $env:KUBECONFIG
    if (-not $kubeconfig) { $kubeconfig = "$env:USERPROFILE\.kube\config" }
    if (Test-Path $kubeconfig) {
        Register-Check -Name "kubeconfig" -Status INFO -Message "Present"
    }
} else {
    Register-Check -Name "kubectl" -Status INFO -Message "Not installed"
}

# helm
$helmPath = Get-Command helm -ErrorAction SilentlyContinue
if ($helmPath) {
    $helmVersion = helm version --short 2>$null
    Register-Check -Name "Helm" -Status INFO -Message $helmVersion
}

# ============================================================================
# TERRAFORM
# ============================================================================
Write-Section "Infrastructure as Code"

$terraformPath = Get-Command terraform -ErrorAction SilentlyContinue
if ($terraformPath) {
    $tfVersion = terraform version -json 2>$null | ConvertFrom-Json
    if ($tfVersion) {
        Register-Check -Name "Terraform" -Status PASS -Message "v$($tfVersion.terraform_version)"
    } else {
        Register-Check -Name "Terraform" -Status PASS -Message "Installed"
    }
} else {
    Register-Check -Name "Terraform" -Status INFO -Message "Not installed"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
