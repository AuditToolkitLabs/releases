# Check DNS Client Service
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $svc = Get-Service -Name "Dnscache" -ErrorAction SilentlyContinue
    if ($svc.Status -eq 'Running') {
        Register-Check -Name "DNS Client Service" -Status PASS -Message "Service is running."
    } else {
        Register-Check -Name "DNS Client Service" -Status FAIL -Message "Service is not running."
    }
} catch {
    Register-Check -Name "DNS Client Service" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit