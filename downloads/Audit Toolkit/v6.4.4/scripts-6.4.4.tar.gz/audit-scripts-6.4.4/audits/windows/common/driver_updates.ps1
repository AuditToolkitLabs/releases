# Check for Blocked Unsigned Drivers
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $drivers = Get-WindowsDriver -Online | Where-Object { $null -eq $_.SignerName }
    if ($drivers) {
        Register-Check -Name "Driver Updates" -Status FAIL -Message "Unsigned drivers are present."
    } else {
        Register-Check -Name "Driver Updates" -Status PASS -Message "No unsigned drivers found."
    }
} catch {
    Register-Check -Name "Driver Updates" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit