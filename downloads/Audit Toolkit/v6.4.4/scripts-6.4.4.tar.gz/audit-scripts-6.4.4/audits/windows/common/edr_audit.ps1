# EDR (Endpoint Detection and Response) Audit Script (PowerShell)
# Checks for enterprise EDR/XDR solutions and their configuration
# This script is read-only and does not modify system state.
#
# References:
# - PCI DSS 5.3: Anti-malware solutions
# - NIST SP 800-53: SI-3, SI-4

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# MICROSOFT DEFENDER FOR ENDPOINT (MDE)
# ============================================================================
Write-Section "Microsoft Defender for Endpoint"

# Check Defender ATP/MDE onboarding
try {
    $sensePath = "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status"
    $onboarded = Get-ItemProperty -Path $sensePath -Name "OnboardingState" -ErrorAction Stop

    if ($onboarded.OnboardingState -eq 1) {
        Register-Check -Name "Defender for Endpoint" -Status PASS -Message "Onboarded and active"

        # Check last connection
        $lastConn = Get-ItemProperty -Path $sensePath -Name "LastConnected" -ErrorAction SilentlyContinue
        if ($lastConn.LastConnected) {
            $lastConnect = [DateTime]::FromFileTime($lastConn.LastConnected)
            $hoursSince = (Get-Date) - $lastConnect
            if ($hoursSince.TotalHours -le 24) {
                Register-Check -Name "MDE Last Connection" -Status PASS -Message "$($lastConnect.ToString('g'))"
            } else {
                Register-Check -Name "MDE Last Connection" -Status WARN -Message "$([int]$hoursSince.TotalHours) hours ago"
            }
        }

        # Org ID
        $orgId = Get-ItemProperty -Path $sensePath -Name "OrgId" -ErrorAction SilentlyContinue
        if ($orgId.OrgId) {
            Register-Check -Name "MDE Organization" -Status INFO -Message "OrgId: $($orgId.OrgId.Substring(0,8))..."
        }
    } else {
        Register-Check -Name "Defender for Endpoint" -Status WARN -Message "Not onboarded"
    }
} catch {
    Register-Check -Name "Defender for Endpoint" -Status INFO -Message "Not configured"
}

# SENSE service (Defender ATP sensor)
try {
    $sense = Get-Service -Name "SENSE" -ErrorAction SilentlyContinue
    if ($sense) {
        if ($sense.Status -eq "Running") {
            Register-Check -Name "MDE Sensor Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "MDE Sensor Service" -Status WARN -Message "$($sense.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Defender for Endpoint tamper protection
try {
    $tamper = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Features" -Name "TamperProtection" -ErrorAction SilentlyContinue
    if ($tamper.TamperProtection -eq 5) {
        Register-Check -Name "MDE Tamper Protection" -Status PASS -Message "Enabled via cloud"
    } elseif ($tamper.TamperProtection -gt 0) {
        Register-Check -Name "MDE Tamper Protection" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "MDE Tamper Protection" -Status WARN -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CROWDSTRIKE FALCON
# ============================================================================
Write-Section "CrowdStrike Falcon"

try {
    $csService = Get-Service -Name "CSFalconService" -ErrorAction SilentlyContinue
    if ($csService) {
        if ($csService.Status -eq "Running") {
            Register-Check -Name "CrowdStrike Falcon" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "CrowdStrike Falcon" -Status FAIL -Message "Service not running"
        }

        # Check CrowdStrike agent info
        try {
            $csAgentPath = Get-ItemProperty -Path "HKLM:\SYSTEM\CrowdStrike\{9b03c1d9-3138-44ed-9fae-d9f4190f0fa0}\{16e0423f-7058-48c9-a204-725362b67639}\Default" -ErrorAction SilentlyContinue
            if ($csAgentPath) {
                Register-Check -Name "CrowdStrike Agent" -Status INFO -Message "Agent configuration present"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # CSAgent process
        $csAgent = Get-Process -Name "CSAgent*" -ErrorAction SilentlyContinue
        if ($csAgent) {
            Register-Check -Name "CrowdStrike Agent Process" -Status PASS -Message "$($csAgent.Count) process(es)"
        }
    } else {
        Register-Check -Name "CrowdStrike Falcon" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "CrowdStrike Falcon" -Status INFO -Message "Not detected"
}

# ============================================================================
# SENTINELONE
# ============================================================================
Write-Section "SentinelOne"

try {
    $s1Service = Get-Service -Name "SentinelAgent" -ErrorAction SilentlyContinue
    if (-not $s1Service) {
        $s1Service = Get-Service -Name "Sentinel Agent" -ErrorAction SilentlyContinue
    }

    if ($s1Service) {
        if ($s1Service.Status -eq "Running") {
            Register-Check -Name "SentinelOne Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "SentinelOne Agent" -Status FAIL -Message "Service not running"
        }

        # Check SentinelOne installation
        $s1Path = Get-ItemProperty -Path "HKLM:\SOFTWARE\Sentinel Labs\Sentinel Agent" -ErrorAction SilentlyContinue
        if ($s1Path) {
            $version = $s1Path.Version
            Register-Check -Name "SentinelOne Version" -Status INFO -Message "v$version"
        }
    } else {
        Register-Check -Name "SentinelOne Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "SentinelOne Agent" -Status INFO -Message "Not detected"
}

# ============================================================================
# CARBON BLACK
# ============================================================================
Write-Section "VMware Carbon Black"

# Carbon Black Cloud
try {
    $cbCloud = Get-Service -Name "RepMgr" -ErrorAction SilentlyContinue
    if ($cbCloud) {
        if ($cbCloud.Status -eq "Running") {
            Register-Check -Name "Carbon Black Cloud" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Carbon Black Cloud" -Status WARN -Message "$($cbCloud.Status)"
        }
    } else {
        Register-Check -Name "Carbon Black Cloud" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Carbon Black Cloud" -Status INFO -Message "Not detected"
}

# Carbon Black Response (legacy)
try {
    $cbr = Get-Service -Name "CbDefense" -ErrorAction SilentlyContinue
    if (-not $cbr) {
        $cbr = Get-Service -Name "CbDefenseSensor" -ErrorAction SilentlyContinue
    }

    if ($cbr) {
        Register-Check -Name "Carbon Black Defense" -Status PASS -Message "$($cbr.Status)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SOPHOS
# ============================================================================
Write-Section "Sophos Endpoint"

try {
    $sophosServices = @(
        @{Name="Sophos Endpoint Defense Service"; Display="Sophos Endpoint Defense"},
        @{Name="Sophos Health Service"; Display="Sophos Health"},
        @{Name="Sophos MCS Agent"; Display="Sophos MCS Agent"}
    )

    $sophosFound = $false
    foreach ($svc in $sophosServices) {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if ($service) {
            $sophosFound = $true
            if ($service.Status -eq "Running") {
                Register-Check -Name $svc.Display -Status PASS -Message "Running"
            } else {
                Register-Check -Name $svc.Display -Status WARN -Message "$($service.Status)"
            }
        }
    }

    if (-not $sophosFound) {
        Register-Check -Name "Sophos Endpoint" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Sophos Endpoint" -Status INFO -Message "Not detected"
}

# ============================================================================
# SYMANTEC/BROADCOM ENDPOINT PROTECTION
# ============================================================================
Write-Section "Symantec Endpoint Protection"

try {
    $sepServices = @("SepMasterService", "Symantec Endpoint Protection", "ccSvcHst")
    $sepFound = $false

    foreach ($svcName in $sepServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $sepFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "Symantec/Broadcom SEP" -Status PASS -Message "Running ($svcName)"
            } else {
                Register-Check -Name "Symantec/Broadcom SEP" -Status WARN -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $sepFound) {
        Register-Check -Name "Symantec/Broadcom SEP" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Symantec/Broadcom SEP" -Status INFO -Message "Not detected"
}

# ============================================================================
# TREND MICRO
# ============================================================================
Write-Section "Trend Micro"

try {
    $trendServices = @("Trend Micro Endpoint Basecamp", "Amsp", "TMiACAgentSvc", "TmWSCSvc")
    $trendFound = $false

    foreach ($svcName in $trendServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $trendFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "Trend Micro Apex One" -Status PASS -Message "Running"
            } else {
                Register-Check -Name "Trend Micro Apex One" -Status WARN -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $trendFound) {
        Register-Check -Name "Trend Micro" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Trend Micro" -Status INFO -Message "Not detected"
}

# ============================================================================
# PALO ALTO CORTEX XDR
# ============================================================================
Write-Section "Palo Alto Cortex XDR"

try {
    $cortexService = Get-Service -Name "cyserver" -ErrorAction SilentlyContinue
    if (-not $cortexService) {
        $cortexService = Get-Service -Name "CortexXDR" -ErrorAction SilentlyContinue
    }

    if ($cortexService) {
        if ($cortexService.Status -eq "Running") {
            Register-Check -Name "Cortex XDR" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Cortex XDR" -Status WARN -Message "$($cortexService.Status)"
        }
    } else {
        Register-Check -Name "Cortex XDR" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Cortex XDR" -Status INFO -Message "Not detected"
}

# ============================================================================
# CYBEREASON
# ============================================================================
Write-Section "Cybereason"

try {
    $crbService = Get-Service -Name "CybereasonActiveProbe" -ErrorAction SilentlyContinue
    if ($crbService) {
        if ($crbService.Status -eq "Running") {
            Register-Check -Name "Cybereason" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Cybereason" -Status WARN -Message "$($crbService.Status)"
        }
    } else {
        Register-Check -Name "Cybereason" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Cybereason" -Status INFO -Message "Not detected"
}

# ============================================================================
# HUNTRESS
# ============================================================================
Write-Section "Huntress"

try {
    $huntress = Get-Service -Name "HuntressAgent" -ErrorAction SilentlyContinue
    if ($huntress) {
        if ($huntress.Status -eq "Running") {
            Register-Check -Name "Huntress Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Huntress Agent" -Status WARN -Message "$($huntress.Status)"
        }
    } else {
        Register-Check -Name "Huntress Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Huntress Agent" -Status INFO -Message "Not detected"
}

# ============================================================================
# EDR SUMMARY
# ============================================================================
Write-Section "EDR Coverage Summary"

$edrProducts = @(
    @{Service="SENSE"; Name="Microsoft Defender ATP"},
    @{Service="CSFalconService"; Name="CrowdStrike"},
    @{Service="SentinelAgent"; Name="SentinelOne"},
    @{Service="RepMgr"; Name="Carbon Black"},
    @{Service="Sophos Endpoint Defense Service"; Name="Sophos"},
    @{Service="SepMasterService"; Name="Symantec"},
    @{Service="Amsp"; Name="Trend Micro"},
    @{Service="cyserver"; Name="Cortex XDR"},
    @{Service="CybereasonActiveProbe"; Name="Cybereason"},
    @{Service="HuntressAgent"; Name="Huntress"}
)

$runningEDR = @()
foreach ($edr in $edrProducts) {
    $svc = Get-Service -Name $edr.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningEDR += $edr.Name
    }
}

if ($runningEDR.Count -ge 1) {
    Register-Check -Name "EDR Coverage" -Status PASS -Message "Protected by: $($runningEDR -join ', ')"
} else {
    # Check WinDefend as fallback
    $winDefend = Get-Service -Name "WinDefend" -ErrorAction SilentlyContinue
    if ($winDefend -and $winDefend.Status -eq "Running") {
        Register-Check -Name "EDR Coverage" -Status WARN -Message "Only Windows Defender (basic) - consider enterprise EDR"
    } else {
        Register-Check -Name "EDR Coverage" -Status FAIL -Message "No EDR solution detected"
    }
}

# Multiple EDR warning
if ($runningEDR.Count -gt 1) {
    Register-Check -Name "Multiple EDR" -Status WARN -Message "$($runningEDR.Count) EDR products - may cause conflicts"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
