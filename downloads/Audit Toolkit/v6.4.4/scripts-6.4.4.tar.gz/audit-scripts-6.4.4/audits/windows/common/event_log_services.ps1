<#
Event Log Services Audit

Compliance Mapping:
- CIS Controls: 6.2, 8.1, 16.11
- NIST SP 800-53: AU-2, AU-6, SI-4
- ISO 27001: A.12.4, A.13.1
- OWASP ASVS: V10
- UK NCSC: Logging and Monitoring
- PCI DSS: 10.2, 10.3

Each check in this script is annotated in comments with relevant compliance mappings.
#>
# Check Event Log Services
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $svc = Get-Service -Name "eventlog" -ErrorAction SilentlyContinue
    if ($svc.Status -eq 'Running') {
        Register-Check -Name "Event Log Service" -Status PASS -Message "Service is running."
    } else {
        Register-Check -Name "Event Log Service" -Status FAIL -Message "Service is not running."
    }
} catch {
    Register-Check -Name "Event Log Service" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit