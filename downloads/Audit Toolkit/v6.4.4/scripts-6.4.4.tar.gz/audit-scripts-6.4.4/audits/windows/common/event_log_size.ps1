# Check Event Log Size
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $log = Get-EventLog -List | Where-Object { $_.Log -eq 'Security' }
    if ($log.MaximumKilobytes -ge 196608) {
        Register-Check -Name "Event Log Size" -Status PASS -Message "Security event log size meets CIS minimum."
    } else {
        Register-Check -Name "Event Log Size" -Status FAIL -Message "Security event log size is below CIS minimum."
    }
} catch {
    Register-Check -Name "Event Log Size" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit