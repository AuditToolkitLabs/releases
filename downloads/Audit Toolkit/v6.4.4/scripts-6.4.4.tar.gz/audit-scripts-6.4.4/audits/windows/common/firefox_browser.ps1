# Mozilla Firefox Browser Security Audit Script (PowerShell)
# Read-only checks for enterprise Firefox policy hardening.

Import-Module "$PSScriptRoot/common-audit.psm1"

function Get-FirefoxExecutablePath {
    [CmdletBinding()]
    param()

    $programFilesX86 = [Environment]::GetFolderPath('ProgramFilesX86')
    $pathList = @(
        "$env:ProgramFiles\Mozilla Firefox\firefox.exe",
        "$programFilesX86\Mozilla Firefox\firefox.exe"
    )

    foreach ($pathItem in $pathList) {
        if (Test-Path -LiteralPath $pathItem) {
            return $pathItem
        }
    }

    return $null
}

function Get-FirefoxPolicyObject {
    [CmdletBinding()]
    param()

    $programFilesX86 = [Environment]::GetFolderPath('ProgramFilesX86')
    $policyPathList = @(
        "$env:ProgramFiles\Mozilla Firefox\distribution\policies.json",
        "$programFilesX86\Mozilla Firefox\distribution\policies.json"
    )

    foreach ($policyPath in $policyPathList) {
        if (-not (Test-Path -LiteralPath $policyPath)) {
            continue
        }

        try {
            $json = Get-Content -LiteralPath $policyPath -Raw -ErrorAction Stop | ConvertFrom-Json
            if ($json.policies) {
                return $json.policies
            }
        }
        catch {
            Write-Verbose "Unable to parse Firefox policy file at ${policyPath}: $($_.Exception.Message)"
        }
    }

    $registryPath = 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox'
    if (Test-Path -LiteralPath $registryPath) {
        return Get-ItemProperty -LiteralPath $registryPath -ErrorAction SilentlyContinue
    }

    return $null
}

function Test-FirefoxPolicyValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$PolicyObject,
        [Parameter(Mandatory)]
        [string]$PolicyName,
        [Parameter(Mandatory)]
        [object]$ExpectedValue,
        [Parameter(Mandatory)]
        [string]$CheckName,
        [switch]$Invert
    )

    if ($null -eq $PolicyObject) {
        Register-Check -Name $CheckName -Status INFO -Message 'No policies configured'
        return
    }

    $value = $PolicyObject.$PolicyName
    if ($null -eq $value) {
        Register-Check -Name $CheckName -Status INFO -Message 'Not configured'
        return
    }

    $isPass = if ($Invert) { $value -ne $ExpectedValue } else { $value -eq $ExpectedValue }
    if ($isPass) {
        Register-Check -Name $CheckName -Status PASS -Message ("Value: {0}" -f $value)
    }
    else {
        Register-Check -Name $CheckName -Status WARN -Message ("Value: {0}" -f $value)
    }
}

Write-Section 'Firefox Installation'
$firefoxPath = Get-FirefoxExecutablePath
if ($null -eq $firefoxPath) {
    Register-Check -Name 'Firefox Installed' -Status INFO -Message 'Not installed'
    Print-Summary
    Exit-Audit
}

Register-Check -Name 'Firefox Installed' -Status PASS -Message 'Found'
$version = (Get-Item -LiteralPath $firefoxPath).VersionInfo.FileVersion
Register-Check -Name 'Firefox Version' -Status INFO -Message ("v{0}" -f $version)

$applicationIniPath = Join-Path (Split-Path -Path $firefoxPath -Parent) 'application.ini'
if (Test-Path -LiteralPath $applicationIniPath) {
    $isEsg = (Get-Content -LiteralPath $applicationIniPath -ErrorAction SilentlyContinue | Select-String -Pattern 'esr' -Quiet)
    if ($isEsg) {
        Register-Check -Name 'Firefox Edition' -Status PASS -Message 'ESR (Enterprise)'
    }
    else {
        Register-Check -Name 'Firefox Edition' -Status INFO -Message 'Standard Release'
    }
}

$policyObject = Get-FirefoxPolicyObject
if ($policyObject) {
    Register-Check -Name 'Enterprise Managed' -Status PASS -Message 'Policies applied'
}
else {
    Register-Check -Name 'Enterprise Managed' -Status WARN -Message 'No policies detected'
}

Write-Section 'Safe Browsing and Security'
if ($policyObject.EnableTrackingProtection) {
    $trackingSetting = $policyObject.EnableTrackingProtection
    if (($trackingSetting.Value -eq $true) -or ($trackingSetting -eq $true)) {
        Register-Check -Name 'Tracking Protection' -Status PASS -Message 'Enabled'
    }
    else {
        Register-Check -Name 'Tracking Protection' -Status WARN -Message 'Disabled'
    }
}
else {
    Register-Check -Name 'Tracking Protection' -Status INFO -Message 'Not policy-enforced'
}

Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'DisableSafeMode' -ExpectedValue $true -CheckName 'Safe Mode Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'NetworkPrediction' -ExpectedValue $false -CheckName 'Network Prediction Disabled'

if ($policyObject.DNSOverHTTPS) {
    if ($policyObject.DNSOverHTTPS.Enabled -eq $true) {
        Register-Check -Name 'DNS over HTTPS' -Status PASS -Message 'Enabled'
    }
    else {
        Register-Check -Name 'DNS over HTTPS' -Status WARN -Message 'Disabled'
    }
}
else {
    Register-Check -Name 'DNS over HTTPS' -Status INFO -Message 'Not policy-enforced'
}

Write-Section 'Password and Privacy Controls'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'PasswordManagerEnabled' -ExpectedValue $false -CheckName 'Password Manager Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'OfferToSaveLogins' -ExpectedValue $false -CheckName 'Save Logins Prompt Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'OfferToSaveLoginsDefault' -ExpectedValue $false -CheckName 'Default Save Logins Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'DisableTelemetry' -ExpectedValue $true -CheckName 'Telemetry Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'DisableFirefoxStudies' -ExpectedValue $true -CheckName 'Firefox Studies Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'DisablePocket' -ExpectedValue $true -CheckName 'Pocket Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'SearchSuggestEnabled' -ExpectedValue $false -CheckName 'Search Suggestions Disabled'

if ($policyObject.PrimaryPassword) {
    Register-Check -Name 'Primary Password' -Status PASS -Message 'Required'
}
else {
    Register-Check -Name 'Primary Password' -Status INFO -Message 'Not policy-enforced'
}

Write-Section 'Extension and Developer Controls'
if ($policyObject.ExtensionSettings) {
    Register-Check -Name 'Extension Settings' -Status PASS -Message 'Policy configured'
    $defaultPolicy = $policyObject.ExtensionSettings.'*'
    if ($defaultPolicy -and $defaultPolicy.installation_mode -eq 'blocked') {
        Register-Check -Name 'Default Extension Policy' -Status PASS -Message 'Blocked by default'
    }
    elseif ($defaultPolicy) {
        Register-Check -Name 'Default Extension Policy' -Status INFO -Message ("Mode: {0}" -f $defaultPolicy.installation_mode)
    }
}
else {
    Register-Check -Name 'Extension Settings' -Status WARN -Message 'Not configured'
}

if ($policyObject.InstallAddonsPermission) {
    if ($policyObject.InstallAddonsPermission.Default -eq $false) {
        Register-Check -Name 'Add-on Installation' -Status PASS -Message 'Blocked by default'
    }
    else {
        Register-Check -Name 'Add-on Installation' -Status WARN -Message 'Allowed'
    }
}
else {
    Register-Check -Name 'Add-on Installation' -Status INFO -Message 'Not restricted'
}

Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'DisableDeveloperTools' -ExpectedValue $true -CheckName 'Developer Tools Disabled'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'BlockAboutConfig' -ExpectedValue $true -CheckName 'about:config Blocked'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'BlockAboutAddons' -ExpectedValue $true -CheckName 'about:addons Blocked'
Test-FirefoxPolicyValue -PolicyObject $policyObject -PolicyName 'BlockAboutProfiles' -ExpectedValue $true -CheckName 'about:profiles Blocked'

Write-Section 'TLS, Certificates, and Updates'
if ($policyObject.SSLVersionMin) {
    if ($policyObject.SSLVersionMin -in @('tls1.2', 'tls1.3')) {
        Register-Check -Name 'Minimum TLS Version' -Status PASS -Message $policyObject.SSLVersionMin
    }
    else {
        Register-Check -Name 'Minimum TLS Version' -Status WARN -Message $policyObject.SSLVersionMin
    }
}
else {
    Register-Check -Name 'Minimum TLS Version' -Status INFO -Message 'Not policy-enforced'
}

if ($policyObject.Certificates) {
    if ($policyObject.Certificates.ImportEnterpriseRoots -eq $true) {
        Register-Check -Name 'Enterprise Root Certificates' -Status PASS -Message 'Imported from Windows trust store'
    }

    if ($policyObject.Certificates.Install) {
        Register-Check -Name 'Policy-Installed Certificates' -Status INFO -Message ("{0} certificate(s)" -f $policyObject.Certificates.Install.Count)
    }
}
else {
    Register-Check -Name 'Certificate Policy' -Status INFO -Message 'Not configured'
}

if ($policyObject.DisableAppUpdate -eq $true) {
    Register-Check -Name 'Firefox Updates' -Status FAIL -Message 'Disabled by policy'
}
elseif ($policyObject.DisableAppUpdate -eq $false -or $policyObject.AppAutoUpdate -eq $true) {
    Register-Check -Name 'Firefox Updates' -Status PASS -Message 'Enabled'
}
elseif ($policyObject.AppAutoUpdate -eq $false) {
    Register-Check -Name 'Firefox Updates' -Status WARN -Message 'Auto-update disabled'
}
else {
    Register-Check -Name 'Firefox Updates' -Status INFO -Message 'Default behavior (enabled)'
}

Write-Section 'User Extension Footprint'
try {
    $profileRoot = Join-Path $env:APPDATA 'Mozilla\Firefox\Profiles'
    if (-not (Test-Path -LiteralPath $profileRoot)) {
        Register-Check -Name 'User Extensions' -Status INFO -Message 'No Firefox profile directory found'
    }
    else {
        $profileList = Get-ChildItem -LiteralPath $profileRoot -Directory -ErrorAction SilentlyContinue
        $extensionCount = 0
        foreach ($profileItem in $profileList) {
            $extensionPath = Join-Path $profileItem.FullName 'extensions'
            if (Test-Path -LiteralPath $extensionPath) {
                $extensionCount += @(Get-ChildItem -LiteralPath $extensionPath -ErrorAction SilentlyContinue).Count
            }
        }

        Register-Check -Name 'User Extensions' -Status INFO -Message ("{0} extension(s) across {1} profile(s)" -f $extensionCount, $profileList.Count)
    }
}
catch {
    Register-Check -Name 'User Extensions' -Status INFO -Message 'Unable to enumerate user profile extensions'
}

Print-Summary
Exit-Audit
