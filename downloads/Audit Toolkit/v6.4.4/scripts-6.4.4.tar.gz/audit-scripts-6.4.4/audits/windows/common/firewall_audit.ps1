<#
.SYNOPSIS
    Windows Firewall Security Audit

.DESCRIPTION
    Comprehensive Windows Defender Firewall audit:
    - Profile status (Domain, Private, Public)
    - Default actions (inbound/outbound)
    - Logging configuration
    - Rule analysis
    - IPsec settings

.NOTES
    Requires: Administrator for full rule enumeration

Compliance Mapping:
- CIS Controls: 4.4 (Implement and Manage Firewall), 4.5 (Firewall Rule Management)
- CIS Windows Benchmark: 9.1.x-9.3.x (Firewall Settings)
- NIST SP 800-53: SC-7 (Boundary Protection)
- PCI DSS: 1.2, 1.3
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows Firewall Audit"

# ============================================================================
# FIREWALL SERVICE
# ============================================================================
Write-Section "Firewall Service"

try {
    $fwSvc = Get-Service -Name MpsSvc -ErrorAction SilentlyContinue
    if ($fwSvc.Status -eq 'Running') {
        Register-Check -Name "Windows Firewall Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Windows Firewall Service" -Status FAIL -Message "Status: $($fwSvc.Status)"
    }

    if ($fwSvc.StartType -eq 'Automatic') {
        Register-Check -Name "Firewall Service Startup" -Status PASS -Message "Automatic"
    } else {
        Register-Check -Name "Firewall Service Startup" -Status WARN -Message "$($fwSvc.StartType)"
    }
} catch {
    Register-Check -Name "Firewall Service" -Status FAIL -Message "Cannot query"
}

# ============================================================================
# PROFILE STATUS
# ============================================================================
Write-Section "Firewall Profiles"

$fwProfiles = @("Domain", "Private", "Public")

foreach ($profileName in $fwProfiles) {
    try {
        $fwProfile = Get-NetFirewallProfile -Name $profileName -ErrorAction SilentlyContinue

        if ($fwProfile) {
            # Enabled state - CIS 9.x.1
            if ($fwProfile.Enabled -eq $true) {
                Register-Check -Name "$profileName Profile" -Status PASS -Message "Enabled"
            } else {
                Register-Check -Name "$profileName Profile" -Status FAIL -Message "Disabled"
            }

            # Inbound default - CIS 9.x.2
            if ($fwProfile.DefaultInboundAction -eq "Block") {
                Register-Check -Name "$profileName Inbound Default" -Status PASS -Message "Block"
            } else {
                Register-Check -Name "$profileName Inbound Default" -Status FAIL -Message "$($fwProfile.DefaultInboundAction) - should be Block"
            }

            # Outbound default - CIS 9.x.3
            if ($fwProfile.DefaultOutboundAction -eq "Allow") {
                Register-Check -Name "$profileName Outbound Default" -Status PASS -Message "Allow (default)"
            } elseif ($fwProfile.DefaultOutboundAction -eq "Block") {
                Register-Check -Name "$profileName Outbound Default" -Status PASS -Message "Block (restrictive)"
            }

            # Notifications - CIS 9.x.4
            if ($fwProfile.NotifyOnListen -eq $false) {
                Register-Check -Name "$profileName Notifications" -Status PASS -Message "Disabled (CIS)"
            } else {
                Register-Check -Name "$profileName Notifications" -Status INFO -Message "Enabled"
            }
        }
    } catch {
        Register-Check -Name "$profileName Profile" -Status SKIP -Message "Cannot query"
    }
}

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================
Write-Section "Firewall Logging"

foreach ($profileName in $fwProfiles) {
    try {
        $fwProfile = Get-NetFirewallProfile -Name $profileName -ErrorAction SilentlyContinue

        if ($fwProfile) {
            $logPath = $fwProfile.LogFileName
            $logSize = $fwProfile.LogMaxSizeKilobytes
            $logDropped = $fwProfile.LogBlocked
            $logSuccess = $fwProfile.LogAllowed

            # Log dropped packets - CIS 9.x.7
            if ($logDropped -eq $true) {
                Register-Check -Name "$profileName Log Dropped" -Status PASS -Message "Enabled"
            } else {
                Register-Check -Name "$profileName Log Dropped" -Status FAIL -Message "Disabled - cannot detect attacks"
            }

            # Log successful connections - CIS 9.x.8
            if ($logSuccess -eq $true) {
                Register-Check -Name "$profileName Log Success" -Status PASS -Message "Enabled"
            } else {
                Register-Check -Name "$profileName Log Success" -Status WARN -Message "Disabled (optional)"
            }

            # Log size - CIS recommends 16384 KB minimum
            if ($logSize -ge 16384) {
                Register-Check -Name "$profileName Log Size" -Status PASS -Message "$logSize KB"
            } elseif ($logSize -ge 4096) {
                Register-Check -Name "$profileName Log Size" -Status WARN -Message "$logSize KB - consider 16384+"
            } else {
                Register-Check -Name "$profileName Log Size" -Status WARN -Message "$logSize KB - too small"
            }

            # Check log file exists and is accessible
            if ($logPath -and (Test-Path (Split-Path $logPath -Parent))) {
                Register-Check -Name "$profileName Log Path" -Status PASS -Message (Split-Path $logPath -Leaf)
            }
        }
    } catch {
        Register-Check -Name "$profileName Logging" -Status SKIP -Message "Cannot query"
    }
}

# ============================================================================
# RULE ANALYSIS
# ============================================================================
Write-Section "Firewall Rules"

try {
    $allRules = Get-NetFirewallRule -ErrorAction SilentlyContinue
    $enabledRules = $allRules | Where-Object { $_.Enabled -eq $true }
    $inboundAllow = $enabledRules | Where-Object { $_.Direction -eq "Inbound" -and $_.Action -eq "Allow" }

    $totalRules = @($allRules).Count
    $enabledCount = @($enabledRules).Count
    $inboundAllowCount = @($inboundAllow).Count

    Register-Check -Name "Total Rules" -Status INFO -Message "$totalRules ($enabledCount enabled)"
    Register-Check -Name "Inbound Allow Rules" -Status INFO -Message "$inboundAllowCount rule(s)"

    # Check for overly permissive rules
    $anyAnyRules = $enabledRules | Where-Object {
        $_.Direction -eq "Inbound" -and
        $_.Action -eq "Allow"
    } | ForEach-Object {
        $portFilter = $_ | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue
        $addrFilter = $_ | Get-NetFirewallAddressFilter -ErrorAction SilentlyContinue

        if ($portFilter.LocalPort -eq "Any" -and
            $addrFilter.RemoteAddress -eq "Any") {
            $_
        }
    }

    $anyAnyCount = @($anyAnyRules).Count
    if ($anyAnyCount -gt 0) {
        Register-Check -Name "Any/Any Inbound Rules" -Status WARN -Message "$anyAnyCount overly permissive rule(s)"
    } else {
        Register-Check -Name "Any/Any Inbound Rules" -Status PASS -Message "None found"
    }

} catch {
    Register-Check -Name "Rule Analysis" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# RISKY INBOUND RULES
# ============================================================================
Write-Section "Risky Inbound Rules"

$riskyPorts = @{
    23 = "Telnet"
    21 = "FTP"
    69 = "TFTP"
    135 = "RPC"
    137 = "NetBIOS-NS"
    138 = "NetBIOS-DGM"
    139 = "NetBIOS-SSN"
    445 = "SMB"
    1433 = "SQL Server"
    1434 = "SQL Browser"
    3389 = "RDP"
    5985 = "WinRM HTTP"
    5986 = "WinRM HTTPS"
}

try {
    $inboundRules = Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True -ErrorAction SilentlyContinue

    foreach ($rule in $inboundRules) {
        $portFilter = $rule | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue
        $addrFilter = $rule | Get-NetFirewallAddressFilter -ErrorAction SilentlyContinue

        if ($portFilter.LocalPort -and $portFilter.LocalPort -ne "Any") {
            $ports = $portFilter.LocalPort -split ","
            foreach ($port in $ports) {
                $portNum = [int]$port
                if ($riskyPorts.ContainsKey($portNum)) {
                    $svcName = $riskyPorts[$portNum]

                    # Check if restricted to specific IPs
                    if ($addrFilter.RemoteAddress -eq "Any") {
                        Register-Check -Name "$svcName ($portNum)" -Status WARN -Message "Open to any source"
                    } else {
                        Register-Check -Name "$svcName ($portNum)" -Status INFO -Message "Restricted to $($addrFilter.RemoteAddress)"
                    }
                }
            }
        }
    }
} catch {
    Register-Check -Name "Risky Ports" -Status SKIP -Message "Cannot analyze"
}

# ============================================================================
# REMOTE MANAGEMENT RULES
# ============================================================================
Write-Section "Remote Management"

# RDP
try {
    $rdpRules = Get-NetFirewallRule -DisplayName "*Remote Desktop*" -ErrorAction SilentlyContinue |
        Where-Object { $_.Enabled -eq $true -and $_.Direction -eq "Inbound" -and $_.Action -eq "Allow" }

    if ($rdpRules) {
        $rdpCount = @($rdpRules).Count
        Register-Check -Name "RDP Rules" -Status WARN -Message "$rdpCount inbound rule(s) enabled"

        # Check NLA requirement
        $nlaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        $nla = Get-ItemProperty $nlaPath -Name "UserAuthentication" -ErrorAction SilentlyContinue
        if ($nla.UserAuthentication -eq 1) {
            Register-Check -Name "RDP NLA Required" -Status PASS -Message "Network Level Authentication required"
        } else {
            Register-Check -Name "RDP NLA Required" -Status FAIL -Message "NLA not required"
        }
    } else {
        Register-Check -Name "RDP Rules" -Status PASS -Message "No enabled inbound rules"
    }
} catch {
    Register-Check -Name "RDP Rules" -Status SKIP -Message "Cannot check"
}

# WinRM
try {
    $winrmRules = Get-NetFirewallRule -DisplayName "*Windows Remote Management*" -ErrorAction SilentlyContinue |
        Where-Object { $_.Enabled -eq $true -and $_.Direction -eq "Inbound" -and $_.Action -eq "Allow" }

    if ($winrmRules) {
        Register-Check -Name "WinRM Inbound" -Status WARN -Message "$(@($winrmRules).Count) rule(s) enabled"
    } else {
        Register-Check -Name "WinRM Inbound" -Status PASS -Message "No enabled inbound rules"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# IPSEC SETTINGS
# ============================================================================
Write-Section "IPsec Configuration"

try {
    $mainMode = Get-NetIPsecMainModeSA -ErrorAction SilentlyContinue
    $quickMode = Get-NetIPsecQuickModeSA -ErrorAction SilentlyContinue

    $mmCount = @($mainMode).Count
    $qmCount = @($quickMode).Count

    if ($mmCount -gt 0 -or $qmCount -gt 0) {
        Register-Check -Name "IPsec Active SAs" -Status PASS -Message "$mmCount main mode, $qmCount quick mode"
    } else {
        Register-Check -Name "IPsec Active SAs" -Status INFO -Message "No active security associations"
    }
} catch {
    Register-Check -Name "IPsec" -Status SKIP -Message "Cannot query"
}

# IPsec rules
try {
    $ipsecRules = Get-NetIPsecRule -ErrorAction SilentlyContinue
    $enabledIpsec = $ipsecRules | Where-Object { $_.Enabled -eq $true }

    if ($enabledIpsec) {
        Register-Check -Name "IPsec Rules" -Status PASS -Message "$(@($enabledIpsec).Count) enabled rule(s)"
    } else {
        Register-Check -Name "IPsec Rules" -Status INFO -Message "No IPsec rules defined"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# THIRD-PARTY FIREWALL CHECK
# ============================================================================
Write-Section "Third-Party Firewall"

try {
    $wmiFirewall = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName FirewallProduct -ErrorAction SilentlyContinue

    if ($wmiFirewall) {
        foreach ($fw in $wmiFirewall) {
            $fwName = $fw.displayName
            $state = $fw.productState

            # Decode product state
            $enabled = ($state -band 0x00001000) -ne 0

            if ($enabled) {
                Register-Check -Name "Third-Party Firewall" -Status INFO -Message "$fwName (enabled)"
            } else {
                Register-Check -Name "Third-Party Firewall" -Status WARN -Message "$fwName (disabled)"
            }
        }
    } else {
        Register-Check -Name "Third-Party Firewall" -Status INFO -Message "None detected"
    }
} catch {
    Register-Check -Name "Third-Party Firewall" -Status SKIP -Message "Cannot detect"
}

# ============================================================================
# STEALTH MODE / SCAN DETECTION
# ============================================================================
Write-Section "Stealth Settings"

foreach ($profileName in $fwProfiles) {
    try {
        $fwSettings = Get-NetFirewallProfile -Name $profileName -ErrorAction SilentlyContinue

        # Unicast response to multicast
        if ($fwSettings.AllowUnicastResponseToMulticast -eq $false) {
            Register-Check -Name "$profileName Unicast Response" -Status PASS -Message "Disabled (stealthy)"
        } else {
            Register-Check -Name "$profileName Unicast Response" -Status WARN -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# GROUP POLICY OVERRIDE
# ============================================================================
Write-Section "Policy Settings"

try {
    $policyPath = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"
    $fwPolicy = Get-ItemProperty $policyPath -ErrorAction SilentlyContinue

    if ($fwPolicy) {
        Register-Check -Name "GPO Firewall Policy" -Status PASS -Message "Configured via Group Policy"

        if ($fwPolicy.EnableFirewall -eq 1) {
            Register-Check -Name "GPO Domain Profile" -Status PASS -Message "Enabled via GPO"
        }
    } else {
        Register-Check -Name "GPO Firewall Policy" -Status INFO -Message "Not configured via GPO"
    }
} catch {
    Register-Check -Name "GPO Firewall Policy" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
