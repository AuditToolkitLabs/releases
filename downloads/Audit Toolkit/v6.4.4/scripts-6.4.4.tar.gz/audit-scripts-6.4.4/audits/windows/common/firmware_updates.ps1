# Check Firmware Updates (Manual Review)
Import-Module "$PSScriptRoot/common-audit.psm1"
Register-Check -Name "Firmware Updates" -Status WARN -Message "Review OEM firmware update status manually."
Print-Summary
Exit-Audit
