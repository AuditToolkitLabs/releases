<#
.SYNOPSIS
    Comprehensive Group Policy Analysis Audit

.DESCRIPTION
    Advanced GPO analysis including:
    - Empty/unused GPOs
    - Unlinked GPOs
    - Conflicting settings
    - Inheritance blocking
    - Enforcement analysis
    - GPO age and modification tracking

.NOTES
    Requires: GroupPolicy module (RSAT)
    Run on: Domain Controller or domain-joined workstation with RSAT

Compliance Mapping:
- CIS Controls: 4.1 (Secure Configuration), 11.3 (Automated Configuration)
- NIST SP 800-53: CM-2 (Baseline), CM-3 (Change Control), CM-6 (Settings)
- ISO 27001: A.12.5 (Control of Operational Software)
- PCI DSS: 2.2 (Configuration Standards)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

function Test-GPModule {
    try {
        Import-Module GroupPolicy -ErrorAction Stop
        Import-Module ActiveDirectory -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

Write-Section "Comprehensive GPO Analysis"

# Check if domain-joined
$computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
$isDomainJoined = $computerSystem.PartOfDomain

if (-not $isDomainJoined) {
    Register-Check -Name "Domain Membership" -Status SKIP -Message "Not domain-joined"
    Print-Summary
    Exit-Audit
}

if (-not (Test-GPModule)) {
    Register-Check -Name "Required Modules" -Status SKIP -Message "GroupPolicy/ActiveDirectory modules not available"
    Print-Summary
    Exit-Audit
}

Register-Check -Name "Required Modules" -Status PASS -Message "Loaded"

# Get domain info
try {
    $domain = Get-ADDomain
    Register-Check -Name "Domain Connection" -Status PASS -Message $domain.DNSRoot
} catch {
    Register-Check -Name "Domain Connection" -Status FAIL -Message "Cannot connect: $_"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# GPO INVENTORY
# ============================================================================
Write-Section "GPO Inventory"

try {
    $allGPOs = Get-GPO -All -ErrorAction Stop
    $gpoCount = @($allGPOs).Count
    Register-Check -Name "Total GPOs" -Status PASS -Message "$gpoCount GPO(s)"
} catch {
    Register-Check -Name "GPO Enumeration" -Status FAIL -Message "Cannot enumerate GPOs: $_"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# EMPTY GPOs (No settings configured)
# ============================================================================
Write-Section "Empty GPOs"

$emptyGPOs = @()
foreach ($gpo in $allGPOs) {
    try {
        $report = Get-GPOReport -Guid $gpo.Id -ReportType XML -ErrorAction SilentlyContinue

        # More accurate: check for actual policy data
        $hasSettings = $report -match "<q\d+:" -or $report -match "<Extension "

        if (-not $hasSettings) {
            $emptyGPOs += $gpo.DisplayName
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

$emptyCount = $emptyGPOs.Count
if ($emptyCount -eq 0) {
    Register-Check -Name "Empty GPOs" -Status PASS -Message "None found"
} elseif ($emptyCount -le 5) {
    Register-Check -Name "Empty GPOs" -Status WARN -Message "$emptyCount GPO(s) - consider cleanup"
} else {
    Register-Check -Name "Empty GPOs" -Status WARN -Message "$emptyCount GPOs without settings - cleanup recommended"
}

# ============================================================================
# UNLINKED GPOs
# ============================================================================
Write-Section "Unlinked GPOs"

$unlinkedGPOs = @()
foreach ($gpo in $allGPOs) {
    try {
        $report = Get-GPOReport -Guid $gpo.Id -ReportType XML -ErrorAction SilentlyContinue

        if ($report -notmatch "<LinksTo>") {
            $unlinkedGPOs += $gpo.DisplayName
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

$unlinkedCount = $unlinkedGPOs.Count
if ($unlinkedCount -eq 0) {
    Register-Check -Name "Unlinked GPOs" -Status PASS -Message "All GPOs are linked"
} elseif ($unlinkedCount -le 5) {
    Register-Check -Name "Unlinked GPOs" -Status WARN -Message "$unlinkedCount GPO(s) not linked - review/cleanup"
} else {
    Register-Check -Name "Unlinked GPOs" -Status WARN -Message "$unlinkedCount unlinked GPOs"
}

# ============================================================================
# DISABLED GPOs
# ============================================================================
Write-Section "GPO Status Analysis"

$fullyDisabled = @($allGPOs | Where-Object {
    $_.GpoStatus -eq "AllSettingsDisabled"
}).Count

$computerDisabled = @($allGPOs | Where-Object {
    $_.GpoStatus -eq "ComputerSettingsDisabled"
}).Count

$userDisabled = @($allGPOs | Where-Object {
    $_.GpoStatus -eq "UserSettingsDisabled"
}).Count

if ($fullyDisabled -eq 0) {
    Register-Check -Name "Fully Disabled GPOs" -Status PASS -Message "None"
} else {
    Register-Check -Name "Fully Disabled GPOs" -Status WARN -Message "$fullyDisabled GPO(s) - consider deletion"
}

if (($computerDisabled + $userDisabled) -gt 0) {
    Register-Check -Name "Partially Disabled GPOs" -Status PASS -Message "$computerDisabled computer, $userDisabled user disabled"
} else {
    Register-Check -Name "Partially Disabled GPOs" -Status PASS -Message "None"
}

# ============================================================================
# GPO AGE ANALYSIS
# ============================================================================
Write-Section "GPO Age Analysis"

$now = Get-Date
$oldThreshold = $now.AddYears(-2)
$veryOldThreshold = $now.AddYears(-5)

$oldGPOs = @($allGPOs | Where-Object {
    $_.ModificationTime -lt $oldThreshold -and $_.ModificationTime -gt $veryOldThreshold
}).Count

$veryOldGPOs = @($allGPOs | Where-Object {
    $_.ModificationTime -lt $veryOldThreshold
}).Count

if ($veryOldGPOs -gt 0) {
    Register-Check -Name "Very Old GPOs (5+ years)" -Status WARN -Message "$veryOldGPOs GPO(s) - review relevance"
} else {
    Register-Check -Name "Very Old GPOs (5+ years)" -Status PASS -Message "None"
}

if ($oldGPOs -gt 10) {
    Register-Check -Name "Stale GPOs (2-5 years)" -Status WARN -Message "$oldGPOs GPO(s) not modified in 2+ years"
} else {
    Register-Check -Name "Stale GPOs (2-5 years)" -Status PASS -Message "$oldGPOs GPO(s)"
}

# Recently modified (potential concern or expected)
$recentGPOs = @($allGPOs | Where-Object {
    $_.ModificationTime -gt $now.AddDays(-7)
})
$recentCount = $recentGPOs.Count

if ($recentCount -gt 0) {
    Register-Check -Name "Recent Changes (7 days)" -Status WARN -Message "$recentCount GPO(s) modified - verify changes"
    foreach ($recent in $recentGPOs | Select-Object -First 5) {
        Write-Output "  - $($recent.DisplayName): $($recent.ModificationTime)"
    }
} else {
    Register-Check -Name "Recent Changes (7 days)" -Status PASS -Message "No recent modifications"
}

# ============================================================================
# INHERITANCE BLOCKING
# ============================================================================
Write-Section "GPO Inheritance"

try {
    # Get all OUs
    $allOUs = Get-ADOrganizationalUnit -Filter * -Properties gpOptions -ErrorAction SilentlyContinue

    $blockedOUs = @($allOUs | Where-Object { $_.gpOptions -eq 1 })
    $blockedCount = $blockedOUs.Count

    if ($blockedCount -eq 0) {
        Register-Check -Name "Inheritance Blocking" -Status PASS -Message "No OUs blocking inheritance"
    } elseif ($blockedCount -le 5) {
        Register-Check -Name "Inheritance Blocking" -Status PASS -Message "$blockedCount OU(s) block inheritance"
    } else {
        Register-Check -Name "Inheritance Blocking" -Status WARN -Message "$blockedCount OUs block inheritance - review necessity"
    }
} catch {
    Register-Check -Name "Inheritance Blocking" -Status SKIP -Message "Cannot query OUs"
}

# ============================================================================
# ENFORCED GPO LINKS
# ============================================================================
Write-Section "Enforced GPO Links"

$enforcedLinks = 0
foreach ($gpo in $allGPOs) {
    try {
        $report = Get-GPOReport -Guid $gpo.Id -ReportType XML -ErrorAction SilentlyContinue
        if ($report -match "<NoOverride>true</NoOverride>") {
            $enforcedLinks++
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($enforcedLinks -eq 0) {
    Register-Check -Name "Enforced GPO Links" -Status PASS -Message "None"
} elseif ($enforcedLinks -le 5) {
    Register-Check -Name "Enforced GPO Links" -Status PASS -Message "$enforcedLinks enforced link(s)"
} else {
    Register-Check -Name "Enforced GPO Links" -Status WARN -Message "$enforcedLinks enforced links - review GPO design"
}

# ============================================================================
# SECURITY FILTERING ANALYSIS
# ============================================================================
Write-Section "Security Filtering"

$customFilteringCount = 0
foreach ($gpo in $allGPOs) {
    try {
        $perms = Get-GPPermission -Guid $gpo.Id -All -ErrorAction SilentlyContinue

        # Check if Authenticated Users has Apply permission
        $authUsersApply = $perms | Where-Object {
            $_.Trustee.Name -eq "Authenticated Users" -and
            $_.Permission -eq "GpoApply"
        }

        if (-not $authUsersApply) {
            $customFilteringCount++
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($customFilteringCount -eq 0) {
    Register-Check -Name "Custom Security Filtering" -Status PASS -Message "All GPOs apply to Authenticated Users"
} else {
    Register-Check -Name "Custom Security Filtering" -Status PASS -Message "$customFilteringCount GPO(s) use custom filtering"
}

# ============================================================================
# WMI FILTERING
# ============================================================================
Write-Section "WMI Filtering Usage"

$wmiFilteredCount = 0
foreach ($gpo in $allGPOs) {
    if ($gpo.WmiFilter) {
        $wmiFilteredCount++
    }
}

if ($wmiFilteredCount -eq 0) {
    Register-Check -Name "WMI Filtered GPOs" -Status PASS -Message "None use WMI filters"
} else {
    Register-Check -Name "WMI Filtered GPOs" -Status PASS -Message "$wmiFilteredCount GPO(s) use WMI filtering"
}

# ============================================================================
# NAMING CONVENTION ANALYSIS
# ============================================================================
Write-Section "GPO Naming"

# Check for common naming issues
$poorNames = @($allGPOs | Where-Object {
    $_.DisplayName -match "^New Group Policy Object" -or
    $_.DisplayName -match "^Copy of " -or
    $_.DisplayName -match "^GPO\d+" -or
    $_.DisplayName.Length -lt 5
})

$poorNamesCount = $poorNames.Count

if ($poorNamesCount -eq 0) {
    Register-Check -Name "GPO Naming Convention" -Status PASS -Message "No generic names found"
} else {
    Register-Check -Name "GPO Naming Convention" -Status WARN -Message "$poorNamesCount GPO(s) with poor/generic names"
}

# ============================================================================
# BACKUP STATUS (if accessible)
# ============================================================================
Write-Section "GPO Management"

# Check for GPO backup location policy
try {
    $backupPath = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy" -Name "GPOBackupPath" -ErrorAction SilentlyContinue
    if ($backupPath) {
        Register-Check -Name "GPO Backup Path" -Status PASS -Message "Configured"
    } else {
        Register-Check -Name "GPO Backup Path" -Status WARN -Message "No automated backup path configured"
    }
} catch {
    Register-Check -Name "GPO Backup Path" -Status WARN -Message "Not configured (consider AGPM or manual backups)"
}

# ============================================================================
# SUMMARY STATISTICS
# ============================================================================
Write-Section "Summary Statistics"

Write-Output "GPO Health Summary:"
Write-Output "  Total GPOs:        $gpoCount"
Write-Output "  Empty:             $emptyCount"
Write-Output "  Unlinked:          $unlinkedCount"
Write-Output "  Disabled:          $fullyDisabled"
Write-Output "  Stale (2+ years):  $oldGPOs"
Write-Output "  Recently Modified: $recentCount"
Write-Output ""

$healthScore = 100
$healthScore -= ($emptyCount * 2)
$healthScore -= ($unlinkedCount * 2)
$healthScore -= ($fullyDisabled * 3)
$healthScore -= ($veryOldGPOs * 1)
$healthScore = [Math]::Max(0, $healthScore)

if ($healthScore -ge 80) {
    Register-Check -Name "GPO Health Score" -Status PASS -Message "$healthScore/100"
} elseif ($healthScore -ge 60) {
    Register-Check -Name "GPO Health Score" -Status WARN -Message "$healthScore/100 - cleanup recommended"
} else {
    Register-Check -Name "GPO Health Score" -Status WARN -Message "$healthScore/100 - significant cleanup needed"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
