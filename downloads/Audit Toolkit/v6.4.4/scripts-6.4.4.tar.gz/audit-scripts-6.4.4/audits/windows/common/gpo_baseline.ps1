<#
.SYNOPSIS
    Group Policy Baseline Security Audit

.DESCRIPTION
    Audits Group Policy configuration for security baseline alignment.
    Checks RSoP, GPO application, inheritance, and key security policies.

.NOTES
    Requires: GroupPolicy module (RSAT) for full functionality
    Can run on domain-joined workstation for local GPO checks

Compliance Mapping:
- CIS Controls: 4.1 (Secure Configuration), 5.4 (Controlled Use of Admin Privileges)
- NIST SP 800-53: CM-2 (Baseline Configuration), CM-6 (Configuration Settings)
- ISO 27001: A.12.5 (Control of Operational Software)
- PCI DSS: 2.2 (Configuration Standards)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

function Test-GPModule {
    try {
        Import-Module GroupPolicy -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

Write-Section "Group Policy Baseline Audit"

# Check if domain-joined
$computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
$isDomainJoined = $computerSystem.PartOfDomain

if (-not $isDomainJoined) {
    Register-Check -Name "Domain Membership" -Status WARN -Message "Not domain-joined - limited GPO checks"
}

# ============================================================================
# LOCAL GPO STATUS
# ============================================================================
Write-Section "Local Group Policy"

# Check gpupdate last run
try {
    $gpHistory = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine" -ErrorAction SilentlyContinue
    if ($gpHistory) {
        Register-Check -Name "Local GP Applied" -Status PASS -Message "Group Policy has been applied"
    } else {
        Register-Check -Name "Local GP Applied" -Status WARN -Message "Cannot determine GP application status"
    }
} catch {
    Register-Check -Name "Local GP Applied" -Status SKIP -Message "Cannot query"
}

# Check GP Client service
try {
    $gpsvc = Get-Service -Name gpsvc -ErrorAction SilentlyContinue
    if ($gpsvc.Status -eq 'Running') {
        Register-Check -Name "GP Client Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "GP Client Service" -Status FAIL -Message "Not running: $($gpsvc.Status)"
    }
} catch {
    Register-Check -Name "GP Client Service" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# RSOP (Resultant Set of Policy)
# ============================================================================
Write-Section "Policy Application Status"

if ($isDomainJoined -and (Test-GPModule)) {
    try {
        # Get GPO application info
        $gpResult = gpresult /r 2>$null

        if ($gpResult) {
            # Count applied GPOs
            ($gpResult | Select-String -Pattern "^\s+\w+.*$" -Context 0,0 |
                Where-Object { $_.Line -match "^\s+[A-Za-z]" }).Count

            Register-Check -Name "GPO Application" -Status PASS -Message "GPOs are being applied"

            # Check for GPO application errors
            $errors = $gpResult | Select-String -Pattern "error|failed|denied" -CaseSensitive:$false
            if ($errors) {
                Register-Check -Name "GPO Errors" -Status WARN -Message "Errors detected in GP application"
            } else {
                Register-Check -Name "GPO Errors" -Status PASS -Message "No application errors"
            }
        }
    } catch {
        Register-Check -Name "GPO Application" -Status SKIP -Message "Cannot run gpresult"
    }

    # Check last GP refresh time
    try {
        $lastRefresh = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine\Extension-List\{00000000-0000-0000-0000-000000000000}" -Name "EndTimeLo","EndTimeHi" -ErrorAction SilentlyContinue
        if ($lastRefresh) {
            $fileTime = ([long]$lastRefresh.EndTimeHi -shl 32) + $lastRefresh.EndTimeLo
            $lastUpdate = [DateTime]::FromFileTime($fileTime)
            $hoursSince = ((Get-Date) - $lastUpdate).TotalHours

            if ($hoursSince -le 2) {
                Register-Check -Name "GP Refresh" -Status PASS -Message "Last refresh: $($lastUpdate.ToString('g'))"
            } elseif ($hoursSince -le 24) {
                Register-Check -Name "GP Refresh" -Status PASS -Message "Last refresh: $($lastUpdate.ToString('g'))"
            } else {
                Register-Check -Name "GP Refresh" -Status WARN -Message "Last refresh > 24h ago: $($lastUpdate.ToString('g'))"
            }
        }
    } catch {
        Register-Check -Name "GP Refresh" -Status SKIP -Message "Cannot determine last refresh"
    }
} else {
    Register-Check -Name "Domain GPO Checks" -Status SKIP -Message "Not domain-joined or GPMC not available"
}

# ============================================================================
# SECURITY POLICY BASELINE CHECKS
# ============================================================================
Write-Section "Security Policy Verification"

# Export current security policy for analysis
$tempFile = "$env:TEMP\secpol_audit_$(Get-Date -Format 'yyyyMMddHHmmss').cfg"
try {
    $null = secedit /export /cfg $tempFile 2>$null
    $secpolContent = Get-Content $tempFile -Raw -ErrorAction SilentlyContinue

    if ($secpolContent) {
        # Password Policy Checks
        if ($secpolContent -match 'MinimumPasswordLength\s*=\s*(\d+)') {
            $minPwdLen = [int]$Matches[1]
            if ($minPwdLen -ge 14) {
                Register-Check -Name "Min Password Length (Policy)" -Status PASS -Message "$minPwdLen characters"
            } elseif ($minPwdLen -ge 8) {
                Register-Check -Name "Min Password Length (Policy)" -Status WARN -Message "$minPwdLen (CIS recommends 14+)"
            } else {
                Register-Check -Name "Min Password Length (Policy)" -Status FAIL -Message "$minPwdLen characters"
            }
        }

        # Password Complexity
        if ($secpolContent -match 'PasswordComplexity\s*=\s*(\d+)') {
            $complexity = [int]$Matches[1]
            if ($complexity -eq 1) {
                Register-Check -Name "Password Complexity" -Status PASS -Message "Enabled"
            } else {
                Register-Check -Name "Password Complexity" -Status FAIL -Message "Disabled"
            }
        }

        # Account Lockout
        if ($secpolContent -match 'LockoutBadCount\s*=\s*(\d+)') {
            $lockoutThreshold = [int]$Matches[1]
            if ($lockoutThreshold -ge 1 -and $lockoutThreshold -le 5) {
                Register-Check -Name "Account Lockout Threshold" -Status PASS -Message "$lockoutThreshold attempts"
            } elseif ($lockoutThreshold -eq 0) {
                Register-Check -Name "Account Lockout Threshold" -Status FAIL -Message "Disabled"
            } else {
                Register-Check -Name "Account Lockout Threshold" -Status WARN -Message "$lockoutThreshold attempts (CIS: 1-5)"
            }
        }

        # Rename Administrator
        if ($secpolContent -match 'NewAdministratorName\s*=\s*"([^"]+)"') {
            $adminName = $Matches[1]
            if ($adminName -ne "Administrator") {
                Register-Check -Name "Administrator Renamed" -Status PASS -Message "Renamed to: $adminName"
            } else {
                Register-Check -Name "Administrator Renamed" -Status WARN -Message "Default name in use"
            }
        }

        # Rename Guest
        if ($secpolContent -match 'NewGuestName\s*=\s*"([^"]+)"') {
            $guestName = $Matches[1]
            if ($guestName -ne "Guest") {
                Register-Check -Name "Guest Renamed" -Status PASS -Message "Renamed to: $guestName"
            } else {
                Register-Check -Name "Guest Renamed" -Status WARN -Message "Default name in use"
            }
        }

        # Audit Policy - Logon Events
        if ($secpolContent -match 'AuditLogonEvents\s*=\s*(\d+)') {
            $logonAudit = [int]$Matches[1]
            if ($logonAudit -eq 3) {
                Register-Check -Name "Audit Logon Events" -Status PASS -Message "Success and Failure"
            } elseif ($logonAudit -gt 0) {
                Register-Check -Name "Audit Logon Events" -Status WARN -Message "Partial auditing"
            } else {
                Register-Check -Name "Audit Logon Events" -Status FAIL -Message "Not configured"
            }
        }
    }

    # Cleanup temp file
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
} catch {
    Register-Check -Name "Security Policy Export" -Status SKIP -Message "Cannot export security policy"
    if (Test-Path $tempFile) { Remove-Item $tempFile -Force -ErrorAction SilentlyContinue }
}

# ============================================================================
# CRITICAL SECURITY SETTINGS VIA REGISTRY
# ============================================================================
Write-Section "Registry-Based Security Settings"

# UAC enabled
try {
    $uac = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction SilentlyContinue
    if ($uac.EnableLUA -eq 1) {
        Register-Check -Name "UAC Enabled" -Status PASS
    } else {
        Register-Check -Name "UAC Enabled" -Status FAIL -Message "UAC is disabled"
    }
} catch {
    Register-Check -Name "UAC Enabled" -Status SKIP -Message "Cannot query"
}

# Secure Desktop for UAC
try {
    $secureDesktop = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "PromptOnSecureDesktop" -ErrorAction SilentlyContinue
    if ($secureDesktop.PromptOnSecureDesktop -eq 1) {
        Register-Check -Name "UAC Secure Desktop" -Status PASS
    } else {
        Register-Check -Name "UAC Secure Desktop" -Status WARN -Message "Secure desktop disabled"
    }
} catch {
    Register-Check -Name "UAC Secure Desktop" -Status SKIP -Message "Cannot query"
}

# SMB1 Disabled
try {
    $smb1 = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction SilentlyContinue
    if ($smb1.State -eq 'Disabled') {
        Register-Check -Name "SMBv1 Disabled" -Status PASS
    } else {
        Register-Check -Name "SMBv1 Disabled" -Status FAIL -Message "SMBv1 is enabled"
    }
} catch {
    # Try registry check
    try {
        $smb1Reg = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB1" -ErrorAction SilentlyContinue
        if ($smb1Reg.SMB1 -eq 0) {
            Register-Check -Name "SMBv1 Disabled" -Status PASS
        } else {
            Register-Check -Name "SMBv1 Disabled" -Status FAIL -Message "SMBv1 may be enabled"
        }
    } catch {
        Register-Check -Name "SMBv1 Disabled" -Status WARN -Message "Cannot determine SMBv1 status"
    }
}

# LM Hash Storage Disabled
try {
    $noLmHash = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLmHash" -ErrorAction SilentlyContinue
    if ($noLmHash.NoLmHash -eq 1) {
        Register-Check -Name "LM Hash Storage Disabled" -Status PASS
    } else {
        Register-Check -Name "LM Hash Storage Disabled" -Status FAIL -Message "LM hashes may be stored"
    }
} catch {
    Register-Check -Name "LM Hash Storage" -Status WARN -Message "Cannot determine (default: disabled on modern OS)"
}

# ============================================================================
# GPO INFRASTRUCTURE (if GPMC available)
# ============================================================================
if ($isDomainJoined -and (Test-GPModule)) {
    Write-Section "GPO Infrastructure"

    try {
        # Get all GPOs
        $allGPOs = Get-GPO -All -ErrorAction Stop
        $gpoCount = @($allGPOs).Count
        Register-Check -Name "Total GPOs" -Status PASS -Message "$gpoCount GPO(s) in domain"

        # Check for GPOs modified recently (7 days)
        $recentlyModified = $allGPOs | Where-Object {
            $_.ModificationTime -gt (Get-Date).AddDays(-7)
        }
        $recentCount = @($recentlyModified).Count
        if ($recentCount -gt 0) {
            Register-Check -Name "Recently Modified GPOs" -Status WARN -Message "$recentCount GPO(s) modified in last 7 days - verify changes"
        } else {
            Register-Check -Name "Recently Modified GPOs" -Status PASS -Message "No recent changes"
        }

        # Check Default Domain Policy
        $ddp = $allGPOs | Where-Object { $_.DisplayName -eq "Default Domain Policy" }
        if ($ddp) {
            Register-Check -Name "Default Domain Policy" -Status PASS -Message "Exists"
        } else {
            Register-Check -Name "Default Domain Policy" -Status WARN -Message "Not found"
        }

        # Check Default Domain Controllers Policy
        $ddcp = $allGPOs | Where-Object { $_.DisplayName -eq "Default Domain Controllers Policy" }
        if ($ddcp) {
            Register-Check -Name "Default DC Policy" -Status PASS -Message "Exists"
        } else {
            Register-Check -Name "Default DC Policy" -Status WARN -Message "Not found"
        }

    } catch {
        Register-Check -Name "GPO Enumeration" -Status SKIP -Message "Cannot enumerate: $_"
    }
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit

