<#
.SYNOPSIS
    Group Policy Object Permissions Security Audit

.DESCRIPTION
    Audits GPO permissions to identify potential privilege escalation risks.
    Checks who can create, edit, link, and delete GPOs.

.NOTES
    Requires: GroupPolicy module (RSAT)
    Run on: Domain Controller or domain-joined workstation with RSAT

Compliance Mapping:
- CIS Controls: 5.4 (Controlled Use of Admin Privileges), 6.1 (Access Control)
- NIST SP 800-53: AC-6 (Least Privilege), CM-5 (Access Restrictions for Change)
- ISO 27001: A.9.2.3 (Management of Privileged Access Rights)
- PCI DSS: 7.1 (Limit Access)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

function Test-GPModule {
    try {
        Import-Module GroupPolicy -ErrorAction Stop
        Import-Module ActiveDirectory -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

Write-Section "GPO Permissions Security Audit"

# Check if domain-joined
$computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
$isDomainJoined = $computerSystem.PartOfDomain

if (-not $isDomainJoined) {
    Register-Check -Name "Domain Membership" -Status SKIP -Message "Not domain-joined - GPO permission audit requires AD"
    Print-Summary
    Exit-Audit
}

if (-not (Test-GPModule)) {
    Register-Check -Name "Required Modules" -Status SKIP -Message "GroupPolicy and/or ActiveDirectory modules not available"
    Print-Summary
    Exit-Audit
}

Register-Check -Name "Required Modules" -Status PASS -Message "GroupPolicy and ActiveDirectory modules loaded"

# ============================================================================
# GPO CREATION RIGHTS
# ============================================================================
Write-Section "GPO Creation Rights"

try {
    $domain = Get-ADDomain
    $domainDN = $domain.DistinguishedName

    # Check who can create GPOs (Group Policy Creator Owners)
    $gpcoMembers = Get-ADGroupMember -Identity "Group Policy Creator Owners" -ErrorAction SilentlyContinue
    $gpcoCount = if ($gpcoMembers) { @($gpcoMembers).Count } else { 0 }

    if ($gpcoCount -eq 0) {
        Register-Check -Name "GP Creator Owners" -Status PASS -Message "Empty (only Domain Admins can create GPOs)"
    } elseif ($gpcoCount -le 5) {
        Register-Check -Name "GP Creator Owners" -Status PASS -Message "$gpcoCount member(s)"
    } else {
        Register-Check -Name "GP Creator Owners" -Status WARN -Message "$gpcoCount members - review necessity"
    }
} catch {
    Register-Check -Name "GP Creator Owners" -Status SKIP -Message "Cannot query: $_"
}

# ============================================================================
# GPO EDIT PERMISSIONS (Per-GPO Analysis)
# ============================================================================
Write-Section "GPO Edit Permissions"

try {
    $allGPOs = Get-GPO -All -ErrorAction Stop
    $riskyGPOCount = 0
    $criticalGPOs = @("Default Domain Policy", "Default Domain Controllers Policy")

    foreach ($gpo in $allGPOs) {
        try {
            $permissions = Get-GPPermission -Guid $gpo.Id -All -ErrorAction SilentlyContinue

            # Check for non-standard edit permissions
            $editors = $permissions | Where-Object {
                $_.Permission -in @("GpoEdit", "GpoEditDeleteModifySecurity") -and
                $_.Trustee.Name -notin @("Domain Admins", "Enterprise Admins", "SYSTEM")
            }

            if ($editors) {
                $riskyGPOCount++

                # Flag critical GPOs with non-standard permissions
                if ($gpo.DisplayName -in $criticalGPOs) {
                    $editorNames = ($editors.Trustee.Name | Select-Object -Unique) -join ", "
                    Register-Check -Name "Critical GPO: $($gpo.DisplayName)" -Status WARN -Message "Non-standard editors: $editorNames"
                }
            }
        } catch {
            # Continue to next GPO
            Write-Verbose 'Suppressed non-fatal error.'
        }
    }

    if ($riskyGPOCount -eq 0) {
        Register-Check -Name "GPO Edit Permissions" -Status PASS -Message "Standard permissions on all GPOs"
    } elseif ($riskyGPOCount -le 5) {
        Register-Check -Name "GPO Edit Permissions" -Status WARN -Message "$riskyGPOCount GPO(s) with delegated edit rights"
    } else {
        Register-Check -Name "GPO Edit Permissions" -Status WARN -Message "$riskyGPOCount GPOs with delegated edit - review delegation model"
    }

} catch {
    Register-Check -Name "GPO Edit Permissions" -Status SKIP -Message "Cannot analyze: $_"
}

# ============================================================================
# SYSVOL PERMISSIONS
# ============================================================================
Write-Section "SYSVOL Security"

try {
    $sysvolPath = "\\$($domain.DNSRoot)\SYSVOL\$($domain.DNSRoot)\Policies"

    if (Test-Path $sysvolPath) {
        Register-Check -Name "SYSVOL Access" -Status PASS -Message "SYSVOL reachable"

        # Check SYSVOL ACL
        $sysvolAcl = Get-Acl $sysvolPath -ErrorAction SilentlyContinue
        if ($sysvolAcl) {
            # Check for Everyone or Authenticated Users with write access
            $riskyPerms = $sysvolAcl.Access | Where-Object {
                ($_.IdentityReference -match "Everyone|Authenticated Users|Users") -and
                ($_.FileSystemRights -match "Write|Modify|FullControl") -and
                ($_.AccessControlType -eq "Allow")
            }

            if ($riskyPerms) {
                Register-Check -Name "SYSVOL Write Access" -Status FAIL -Message "Broad write permissions detected"
            } else {
                Register-Check -Name "SYSVOL Write Access" -Status PASS -Message "Properly restricted"
            }
        }
    } else {
        Register-Check -Name "SYSVOL Access" -Status WARN -Message "Cannot access SYSVOL"
    }
} catch {
    Register-Check -Name "SYSVOL Security" -Status SKIP -Message "Cannot analyze: $_"
}

# ============================================================================
# GPO LINK PERMISSIONS
# ============================================================================
Write-Section "GPO Link Permissions"

try {
    # Check delegation on critical OUs
    $criticalOUs = @(
        "OU=Domain Controllers,$domainDN",
        $domainDN  # Domain root
    )

    foreach ($ou in $criticalOUs) {
        try {
            $ouAcl = Get-Acl "AD:$ou" -ErrorAction SilentlyContinue
            if ($ouAcl) {
                # Check for GPLink write permission
                $gpLinkDelegation = $ouAcl.Access | Where-Object {
                    $_.ActiveDirectoryRights -match "WriteProperty" -and
                    $_.ObjectType -eq "f30e3bbe-9ff0-11d1-b603-0000f80367c1"  # GP-Link attribute GUID
                } | Where-Object {
                    $_.IdentityReference -notmatch "Domain Admins|Enterprise Admins|SYSTEM|Administrators"
                }

                $ouName = if ($ou -eq $domainDN) { "Domain Root" } else { "Domain Controllers OU" }

                if ($gpLinkDelegation) {
                    Register-Check -Name "GPO Link: $ouName" -Status WARN -Message "Non-standard link delegation"
                } else {
                    Register-Check -Name "GPO Link: $ouName" -Status PASS -Message "Standard permissions"
                }
            }
        } catch {
            # Continue to next OU
            Write-Verbose 'Suppressed non-fatal error.'
        }
    }
} catch {
    Register-Check -Name "GPO Link Permissions" -Status SKIP -Message "Cannot analyze AD permissions"
}

# ============================================================================
# SECURITY-SENSITIVE GPO SETTINGS EXPOSURE
# ============================================================================
Write-Section "GPO Security Settings"

try {
    # Check if any GPO exposes credentials or sensitive data
    foreach ($gpo in $allGPOs) {
        try {
            $report = Get-GPOReport -Guid $gpo.Id -ReportType XML -ErrorAction SilentlyContinue

            # Check for Group Policy Preferences passwords (CVE-2014-1812)
            if ($report -match "cpassword") {
                Register-Check -Name "GPP Password: $($gpo.DisplayName)" -Status FAIL -Message "Contains GPP password (CVE-2014-1812)"
            }

            # Check for scheduled task credentials
            if ($report -match "<ScheduledTasks>.*<Password>" -or $report -match "runAs.*password") {
                Register-Check -Name "Scheduled Task Creds: $($gpo.DisplayName)" -Status WARN -Message "May contain scheduled task credentials"
            }

        } catch {
            # Continue to next GPO
            Write-Verbose 'Suppressed non-fatal error.'
        }
    }

    Register-Check -Name "GPP Password Scan" -Status PASS -Message "Scanned $($allGPOs.Count) GPOs"

} catch {
    Register-Check -Name "GPO Content Scan" -Status SKIP -Message "Cannot analyze GPO content"
}

# ============================================================================
# WMI FILTER PERMISSIONS
# ============================================================================
Write-Section "WMI Filter Permissions"

try {
    $wmiFiltersPath = "CN=SOM,CN=WMIPolicy,CN=System,$domainDN"
    $wmiFilters = Get-ADObject -SearchBase $wmiFiltersPath -Filter { objectClass -eq "msWMI-Som" } -Properties * -ErrorAction SilentlyContinue

    $wmiCount = if ($wmiFilters) { @($wmiFilters).Count } else { 0 }

    if ($wmiCount -eq 0) {
        Register-Check -Name "WMI Filters" -Status PASS -Message "None configured"
    } else {
        Register-Check -Name "WMI Filters" -Status PASS -Message "$wmiCount filter(s) configured"

        # WMI filters with broad access could be abused
        foreach ($filter in $wmiFilters) {
            try {
                $filterAcl = Get-Acl "AD:$($filter.DistinguishedName)" -ErrorAction SilentlyContinue
                $broadAccess = $filterAcl.Access | Where-Object {
                    $_.ActiveDirectoryRights -match "WriteProperty|WriteDacl|Delete" -and
                    $_.IdentityReference -notmatch "Domain Admins|Enterprise Admins|SYSTEM"
                }

                if ($broadAccess) {
                    Register-Check -Name "WMI Filter: $($filter.Name)" -Status WARN -Message "Non-standard write permissions"
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }
} catch {
    Register-Check -Name "WMI Filters" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# STARTER GPOS
# ============================================================================
Write-Section "Starter GPOs"

try {
    $starterGPOs = Get-GPStarterGPO -All -ErrorAction SilentlyContinue
    $starterCount = if ($starterGPOs) { @($starterGPOs).Count } else { 0 }

    if ($starterCount -gt 0) {
        Register-Check -Name "Starter GPOs" -Status PASS -Message "$starterCount starter GPO(s) available"
    } else {
        Register-Check -Name "Starter GPOs" -Status SKIP -Message "None configured"
    }
} catch {
    Register-Check -Name "Starter GPOs" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
