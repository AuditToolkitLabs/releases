# Guest Account Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Security Options
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 2.3.1.1, 2.3.1.2
# - Microsoft Guest Account: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/accounts-guest-account-status

Import-Module "$PSScriptRoot/common-audit.psm1"

# CIS 2.3.1.1 - Guest account status (should be disabled)
try {
    $guestAccount = Get-LocalUser -Name "Guest" -ErrorAction Stop

    if ($guestAccount.Enabled -eq $false) {
        Register-Check -Name "Guest Account Status" -Status PASS -Message "Guest account is disabled"
    } else {
        Register-Check -Name "Guest Account Status" -Status FAIL -Message "Guest account is enabled (security risk)"
    }

    # Check if account is password protected (if enabled, this matters)
    if ($guestAccount.PasswordRequired -eq $false -and $guestAccount.Enabled) {
        Register-Check -Name "Guest Password Required" -Status FAIL -Message "Guest account has no password required"
    }

} catch [Microsoft.PowerShell.Commands.UserNotFoundException] {
    Register-Check -Name "Guest Account Status" -Status PASS -Message "Guest account does not exist"
} catch {
    Register-Check -Name "Guest Account Status" -Status WARN -Message "Could not check guest account: $($_.Exception.Message)"
}

# CIS 2.3.1.2 - Guest account renamed (recommended for obfuscation)
try {
    $guest = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount=True" -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-501" }

    if ($guest) {
        if ($guest.Name -ne "Guest") {
            Register-Check -Name "Guest Account Renamed" -Status PASS -Message "Guest account renamed to '$($guest.Name)'"
        } else {
            Register-Check -Name "Guest Account Renamed" -Status WARN -Message "Guest account has default name (consider renaming)"
        }
    }
} catch {
    Register-Check -Name "Guest Account Renamed" -Status WARN -Message "Could not verify guest account name"
}

# CIS 2.3.1.3 - Administrator account renamed (recommended)
try {
    $admin = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount=True" -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-500" }

    if ($admin) {
        if ($admin.Name -ne "Administrator") {
            Register-Check -Name "Admin Account Renamed" -Status PASS -Message "Admin account renamed to '$($admin.Name)'"
        } else {
            Register-Check -Name "Admin Account Renamed" -Status WARN -Message "Admin account has default name (consider renaming)"
        }

        # Check if admin account is disabled (for workstations, this is recommended)
        $adminLocal = Get-LocalUser | Where-Object { $_.SID -like "*-500" }
        if ($adminLocal -and $adminLocal.Enabled -eq $false) {
            Register-Check -Name "Admin Account Disabled" -Status PASS -Message "Built-in Administrator is disabled"
        } elseif ($adminLocal) {
            Register-Check -Name "Admin Account Disabled" -Status WARN -Message "Built-in Administrator is enabled (consider disabling)"
        }
    }
} catch {
    Register-Check -Name "Admin Account Renamed" -Status WARN -Message "Could not verify admin account name"
}

# Check for blank passwords allowed
try {
    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    $limitBlank = Get-ItemProperty -Path $regPath -Name "LimitBlankPasswordUse" -ErrorAction Stop

    if ($limitBlank.LimitBlankPasswordUse -eq 1) {
        Register-Check -Name "Blank Passwords Limited" -Status PASS -Message "Blank passwords limited to console logon only"
    } else {
        Register-Check -Name "Blank Passwords Limited" -Status FAIL -Message "Blank passwords allowed for network logon"
    }
} catch {
    Register-Check -Name "Blank Passwords Limited" -Status WARN -Message "Could not check blank password policy"
}

Print-Summary
Exit-Audit
