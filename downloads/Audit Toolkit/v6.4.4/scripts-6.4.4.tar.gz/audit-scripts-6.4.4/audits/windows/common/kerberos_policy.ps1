# Kerberos Policy Security Audit Script (PowerShell)
# Comprehensive Kerberos hardening checks per CIS and Microsoft best practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Benchmark: 2.3.6.x (Domain Member policies)
# - Microsoft Kerberos: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/kerberos-policy

Import-Module "$PSScriptRoot/common-audit.psm1"

$kerbPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters"
$kerbPolPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters"

# ============================================================================
# KERBEROS ENCRYPTION TYPES
# ============================================================================
Write-Section "Kerberos Encryption Types"

# Supported encryption types - critical for security
try {
    $encTypes = Get-ItemProperty -Path $kerbPolPath -Name "SupportedEncryptionTypes" -ErrorAction Stop
    $val = $encTypes.SupportedEncryptionTypes

    $types = @()
    if ($val -band 0x1) { $types += "DES_CBC_CRC (weak)" }
    if ($val -band 0x2) { $types += "DES_CBC_MD5 (weak)" }
    if ($val -band 0x4) { $types += "RC4_HMAC_MD5 (deprecated)" }
    if ($val -band 0x8) { $types += "AES128_HMAC_SHA1" }
    if ($val -band 0x10) { $types += "AES256_HMAC_SHA1" }
    if ($val -band 0x20) { $types += "AES256_HMAC_SHA384" }

    # Check for weak encryption
    $hasWeak = ($val -band 0x7) -ne 0
    $hasAes = ($val -band 0x18) -ne 0

    if ($hasAes -and -not $hasWeak) {
        Register-Check -Name "Kerberos Encryption" -Status PASS -Message "AES only: $($types -join ', ')"
    } elseif ($hasAes -and $hasWeak) {
        Register-Check -Name "Kerberos Encryption" -Status WARN -Message "AES + weak: $($types -join ', ')"
    } elseif ($hasWeak) {
        Register-Check -Name "Kerberos Encryption" -Status FAIL -Message "Weak only: $($types -join ', ')"
    } else {
        Register-Check -Name "Kerberos Encryption" -Status INFO -Message "Types: $($types -join ', ')"
    }
} catch {
    # Check via registry fallback
    try {
        $msKdc = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kdc\Parameters" -Name "SupportedEncryptionTypes" -ErrorAction SilentlyContinue
        if ($msKdc) {
            Register-Check -Name "Kerberos Encryption" -Status INFO -Message "KDC config found"
        } else {
            Register-Check -Name "Kerberos Encryption" -Status INFO -Message "Using default encryption types"
        }
    } catch {
        Register-Check -Name "Kerberos Encryption" -Status INFO -Message "Default encryption types (may include RC4)"
    }
}

# RC4 for TGS requests
try {
    $allowRc4 = Get-ItemProperty -Path $kerbPath -Name "AllowTGTSessionKey" -ErrorAction SilentlyContinue
    Register-Check -Name "TGT Session Key Export" -Status INFO -Message "Configured: $($allowRc4.AllowTGTSessionKey ?? 'Default')"
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# KERBEROS TICKET POLICIES
# ============================================================================
Write-Section "Kerberos Ticket Policies"

# Check via GPResult if possible
try {
    $tempFile = "$env:TEMP\secpol_kerb_$(Get-Date -Format 'yyyyMMddHHmmss').txt"
    $null = & secedit /export /cfg $tempFile /quiet 2>&1

    if (Test-Path $tempFile) {
        $secpol = Get-Content $tempFile -Raw
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue

        # Maximum lifetime for service ticket (CIS: 600 minutes = 10 hours)
        if ($secpol -match 'MaxServiceAge\s*=\s*(\d+)') {
            $maxService = [int]$matches[1]
            if ($maxService -le 600) {
                Register-Check -Name "Service Ticket Lifetime" -Status PASS -Message "$maxService minutes (max 600)"
            } else {
                Register-Check -Name "Service Ticket Lifetime" -Status WARN -Message "$maxService minutes (recommend 600)"
            }
        }

        # Maximum lifetime for user ticket (CIS: 10 hours)
        if ($secpol -match 'MaxTicketAge\s*=\s*(\d+)') {
            $maxTicket = [int]$matches[1]
            if ($maxTicket -le 10) {
                Register-Check -Name "User Ticket Lifetime" -Status PASS -Message "$maxTicket hours (max 10)"
            } else {
                Register-Check -Name "User Ticket Lifetime" -Status WARN -Message "$maxTicket hours (recommend 10)"
            }
        }

        # Maximum lifetime for user ticket renewal (CIS: 7 days)
        if ($secpol -match 'MaxRenewAge\s*=\s*(\d+)') {
            $maxRenew = [int]$matches[1]
            if ($maxRenew -le 7) {
                Register-Check -Name "Ticket Renewal Lifetime" -Status PASS -Message "$maxRenew days (max 7)"
            } else {
                Register-Check -Name "Ticket Renewal Lifetime" -Status WARN -Message "$maxRenew days (recommend 7)"
            }
        }

        # Maximum clock skew (CIS: 5 minutes)
        if ($secpol -match 'MaxClockSkew\s*=\s*(\d+)') {
            $maxSkew = [int]$matches[1]
            if ($maxSkew -le 5) {
                Register-Check -Name "Maximum Clock Skew" -Status PASS -Message "$maxSkew minutes (max 5)"
            } else {
                Register-Check -Name "Maximum Clock Skew" -Status WARN -Message "$maxSkew minutes (recommend 5)"
            }
        }

        # Enforce user logon restrictions
        if ($secpol -match 'TicketValidateClient\s*=\s*(\d+)') {
            if ($matches[1] -eq "1") {
                Register-Check -Name "Validate User Logon" -Status PASS -Message "Enabled"
            } else {
                Register-Check -Name "Validate User Logon" -Status WARN -Message "Disabled"
            }
        }
    }
} catch {
    Register-Check -Name "Kerberos Ticket Policies" -Status WARN -Message "Cannot export security policy"
}

# ============================================================================
# KERBEROS DELEGATION
# ============================================================================
Write-Section "Kerberos Delegation Security"

# Check for unconstrained delegation (requires AD module)
try {
    if (Get-Module -ListAvailable -Name ActiveDirectory -ErrorAction SilentlyContinue) {
        Import-Module ActiveDirectory -ErrorAction Stop

        # Computers with unconstrained delegation
        $unconstrainedComputers = Get-ADComputer -Filter {TrustedForDelegation -eq $true} -Properties TrustedForDelegation -ErrorAction SilentlyContinue
        $count = ($unconstrainedComputers | Measure-Object).Count

        if ($count -eq 0) {
            Register-Check -Name "Unconstrained Delegation" -Status PASS -Message "No computers with unconstrained delegation"
        } elseif ($count -le 5) {
            Register-Check -Name "Unconstrained Delegation" -Status WARN -Message "$count computer(s) - review needed"
        } else {
            Register-Check -Name "Unconstrained Delegation" -Status FAIL -Message "$count computers with unconstrained delegation"
        }

        # Users with unconstrained delegation
        $unconstrainedUsers = Get-ADUser -Filter {TrustedForDelegation -eq $true} -Properties TrustedForDelegation -ErrorAction SilentlyContinue
        $userCount = ($unconstrainedUsers | Measure-Object).Count

        if ($userCount -eq 0) {
            Register-Check -Name "User Unconstrained Delegation" -Status PASS -Message "No users with unconstrained delegation"
        } else {
            Register-Check -Name "User Unconstrained Delegation" -Status FAIL -Message "$userCount user(s) - high risk"
        }

        # Protected Users group membership (Kerberos hardening)
        try {
            $protectedUsers = Get-ADGroupMember -Identity "Protected Users" -ErrorAction SilentlyContinue
            $protectedCount = ($protectedUsers | Measure-Object).Count

            if ($protectedCount -gt 0) {
                Register-Check -Name "Protected Users Group" -Status PASS -Message "$protectedCount members protected"
            } else {
                Register-Check -Name "Protected Users Group" -Status WARN -Message "No members - consider adding privileged accounts"
            }
        } catch {
            Register-Check -Name "Protected Users Group" -Status INFO -Message "Cannot query group"
        }

    } else {
        Register-Check -Name "AD Delegation Check" -Status SKIP -Message "AD module not available"
    }
} catch {
    Register-Check -Name "AD Delegation Check" -Status SKIP -Message "Not a domain controller or no AD access"
}

# ============================================================================
# KERBEROS ARMORING (FAST)
# ============================================================================
Write-Section "Kerberos Armoring (FAST)"

# Kerberos armoring (Flexible Authentication Secure Tunneling)
try {
    $armorPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters"
    $armor = Get-ItemProperty -Path $armorPath -Name "RequireFast" -ErrorAction SilentlyContinue

    if ($armor.RequireFast -eq 1) {
        Register-Check -Name "Kerberos Armoring" -Status PASS -Message "FAST required"
    } elseif ($armor.RequireFast -eq 0) {
        Register-Check -Name "Kerberos Armoring" -Status INFO -Message "FAST supported but not required"
    } else {
        Register-Check -Name "Kerberos Armoring" -Status INFO -Message "FAST not configured"
    }
} catch {
    Register-Check -Name "Kerberos Armoring" -Status INFO -Message "Not configured"
}

# Claims-based access control
try {
    $claims = Get-ItemProperty -Path $kerbPolPath -Name "EnableCbacAndArmor" -ErrorAction SilentlyContinue
    if ($claims.EnableCbacAndArmor -eq 1) {
        Register-Check -Name "Claims & Compound Auth" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Claims & Compound Auth" -Status INFO -Message "Not enabled"
    }
} catch {
    Register-Check -Name "Claims & Compound Auth" -Status INFO -Message "Default configuration"
}

# ============================================================================
# KERBEROS LOGGING & AUDITING
# ============================================================================
Write-Section "Kerberos Logging"

# Kerberos logging
try {
    $kerbLog = Get-ItemProperty -Path $kerbPath -Name "LogLevel" -ErrorAction SilentlyContinue
    if ($kerbLog.LogLevel -ge 1) {
        Register-Check -Name "Kerberos Debug Logging" -Status INFO -Message "Level $($kerbLog.LogLevel) - may impact performance"
    } else {
        Register-Check -Name "Kerberos Debug Logging" -Status PASS -Message "Disabled (production setting)"
    }
} catch {
    Register-Check -Name "Kerberos Debug Logging" -Status PASS -Message "Not configured (default: off)"
}

# Check for Kerberos events
try {
    # TGT/TGS events
    $kerbEvents = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=@(4768,4769,4770,4771,4772)} -MaxEvents 5 -ErrorAction SilentlyContinue
    if ($kerbEvents) {
        Register-Check -Name "Kerberos Event Logging" -Status PASS -Message "Kerberos auth events being logged"
    } else {
        Register-Check -Name "Kerberos Event Logging" -Status INFO -Message "No recent Kerberos events"
    }
} catch {
    Register-Check -Name "Kerberos Event Logging" -Status INFO -Message "Cannot query security log"
}

# ============================================================================
# KERBEROS CONFIGURATION PARAMETERS
# ============================================================================
Write-Section "Kerberos Configuration"

# Maximum token size
try {
    $maxToken = Get-ItemProperty -Path $kerbPath -Name "MaxTokenSize" -ErrorAction SilentlyContinue
    if ($maxToken.MaxTokenSize) {
        $size = $maxToken.MaxTokenSize
        if ($size -ge 65535) {
            Register-Check -Name "Max Token Size" -Status INFO -Message "$size bytes (may indicate many group memberships)"
        } else {
            Register-Check -Name "Max Token Size" -Status PASS -Message "$size bytes"
        }
    } else {
        Register-Check -Name "Max Token Size" -Status PASS -Message "Default (12KB)"
    }
} catch {
    Register-Check -Name "Max Token Size" -Status PASS -Message "Default configuration"
}

# Allow clock skew
try {
    $allowSkew = Get-ItemProperty -Path $kerbPath -Name "SkewTime" -ErrorAction SilentlyContinue
    if ($allowSkew.SkewTime) {
        Register-Check -Name "Clock Skew Tolerance" -Status INFO -Message "$($allowSkew.SkewTime) minutes"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# UDP fallback behavior
try {
    $udpFallback = Get-ItemProperty -Path $kerbPath -Name "MaxPacketSize" -ErrorAction SilentlyContinue
    if ($udpFallback.MaxPacketSize -eq 1) {
        Register-Check -Name "Kerberos UDP" -Status PASS -Message "Forced TCP (more secure)"
    } elseif ($udpFallback.MaxPacketSize) {
        Register-Check -Name "Kerberos UDP" -Status INFO -Message "Max packet: $($udpFallback.MaxPacketSize) bytes"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# KERBEROASTING PROTECTION
# ============================================================================
Write-Section "Kerberoasting Protection"

# Check for SPNs on user accounts (requires AD)
try {
    if (Get-Module -ListAvailable -Name ActiveDirectory -ErrorAction SilentlyContinue) {
        Import-Module ActiveDirectory -ErrorAction Stop

        # Users with SPNs (Kerberoastable)
        $spnUsers = Get-ADUser -Filter {ServicePrincipalName -like "*"} -Properties ServicePrincipalName -ErrorAction SilentlyContinue
        $spnCount = ($spnUsers | Measure-Object).Count

        if ($spnCount -eq 0) {
            Register-Check -Name "Kerberoastable Accounts" -Status PASS -Message "No user accounts with SPNs"
        } elseif ($spnCount -le 5) {
            Register-Check -Name "Kerberoastable Accounts" -Status WARN -Message "$spnCount user(s) with SPNs - verify necessity"
        } else {
            Register-Check -Name "Kerberoastable Accounts" -Status WARN -Message "$spnCount users with SPNs - review for Kerberoasting risk"
        }

        # Check for weak passwords on SPN accounts (just count, don't expose)
        $spnAdmins = $spnUsers | Where-Object { $_.MemberOf -match "Admin" }
        if ($spnAdmins) {
            Register-Check -Name "Admin Accounts with SPN" -Status WARN -Message "Admin accounts with SPNs detected - high value targets"
        }
    }
} catch {
    Register-Check -Name "Kerberoastable Accounts" -Status SKIP -Message "No AD access"
}

# AES encryption for service accounts
try {
    if (Get-Module -ListAvailable -Name ActiveDirectory -ErrorAction SilentlyContinue) {
        $aesAccounts = Get-ADUser -Filter {ServicePrincipalName -like "*"} -Properties msDS-SupportedEncryptionTypes -ErrorAction SilentlyContinue
        $noAes = $aesAccounts | Where-Object {
            $_.'msDS-SupportedEncryptionTypes' -and
            (-not ($_.'msDS-SupportedEncryptionTypes' -band 0x18))
        }

        if ($noAes) {
            Register-Check -Name "SPN Accounts AES" -Status WARN -Message "$(($noAes | Measure-Object).Count) SPN account(s) may not support AES"
        } else {
            Register-Check -Name "SPN Accounts AES" -Status PASS -Message "All SPN accounts support AES"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit