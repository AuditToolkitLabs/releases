<#
.SYNOPSIS
    Local Administrator Password Solution (LAPS) Security Audit

.DESCRIPTION
    Audits LAPS configuration including:
    - Windows LAPS (new, Server 2019+ with April 2023 update)
    - Legacy LAPS (Microsoft LAPS)
    - Password age and rotation
    - Encryption and backup status
    - AD schema and permissions

.NOTES
    Requires: ActiveDirectory module for full AD checks
    Can run locally to check LAPS client status

Compliance Mapping:
- CIS Controls: 4.4 (Use Unique Passwords), 5.2 (Restrict Admin Privileges)
- NIST SP 800-53: IA-5 (Authenticator Management), AC-6 (Least Privilege)
- ISO 27001: A.9.4.3 (Password Management System)
- PCI DSS: 8.2 (Unique Authentication)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "LAPS Security Audit"

# Detect Windows version for feature availability
[System.Environment]::OSVersion.Version | Out-Null

# ============================================================================
# WINDOWS LAPS (New - April 2023+)
# ============================================================================
Write-Section "Windows LAPS (Native)"

$windowsLapsAvailable = $false
$windowsLapsConfigured = $false

# Check if Windows LAPS is available (requires April 2023 update)
try {
    $lapsModule = Get-Module -ListAvailable -Name "LAPS" -ErrorAction SilentlyContinue
    if ($lapsModule) {
        Import-Module LAPS -ErrorAction Stop
        $windowsLapsAvailable = $true
        Register-Check -Name "Windows LAPS Module" -Status PASS -Message "Available (v$($lapsModule.Version))"
    }
} catch {
    # Module not available
    Write-Verbose 'Suppressed non-fatal error.'
}

if (-not $windowsLapsAvailable) {
    # Check registry for Windows LAPS configuration
    try {
        $wlapsConfig = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\LAPS\Config" -ErrorAction SilentlyContinue
        if ($wlapsConfig) {
            $windowsLapsConfigured = $true
            Register-Check -Name "Windows LAPS Registry" -Status PASS -Message "Configuration present"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check Windows LAPS Policy settings
$wlapsGPOPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\LAPS"
try {
    $wlapsPolicy = Get-ItemProperty $wlapsGPOPath -ErrorAction SilentlyContinue
    if ($wlapsPolicy) {
        $windowsLapsConfigured = $true

        # Check backup directory
        $backupDir = $wlapsPolicy.BackupDirectory
        if ($backupDir -eq 1) {
            Register-Check -Name "WLAPS Backup" -Status PASS -Message "Backing up to Azure AD"
        } elseif ($backupDir -eq 2) {
            Register-Check -Name "WLAPS Backup" -Status PASS -Message "Backing up to AD DS"
        } else {
            Register-Check -Name "WLAPS Backup" -Status WARN -Message "Backup directory not configured"
        }

        # Check password age
        $pwdAge = $wlapsPolicy.PasswordAgeDays
        if ($pwdAge) {
            if ($pwdAge -le 30) {
                Register-Check -Name "WLAPS Password Age" -Status PASS -Message "$pwdAge days"
            } elseif ($pwdAge -le 60) {
                Register-Check -Name "WLAPS Password Age" -Status WARN -Message "$pwdAge days (consider 30 or less)"
            } else {
                Register-Check -Name "WLAPS Password Age" -Status FAIL -Message "$pwdAge days (too long)"
            }
        }

        # Check password complexity
        $pwdComplexity = $wlapsPolicy.PasswordComplexity
        if ($pwdComplexity -ge 4) {
            Register-Check -Name "WLAPS Password Complexity" -Status PASS -Message "Large letters, small letters, numbers, specials"
        } elseif ($pwdComplexity -ge 3) {
            Register-Check -Name "WLAPS Password Complexity" -Status PASS -Message "Good complexity"
        } else {
            Register-Check -Name "WLAPS Password Complexity" -Status WARN -Message "Low complexity"
        }

        # Check encryption
        $adPwdEncryption = $wlapsPolicy.ADPasswordEncryptionEnabled
        if ($adPwdEncryption -eq 1) {
            Register-Check -Name "WLAPS Encryption" -Status PASS -Message "Password encryption enabled"
        } else {
            Register-Check -Name "WLAPS Encryption" -Status WARN -Message "Password encryption not enabled"
        }

        # Check password length
        $pwdLength = $wlapsPolicy.PasswordLength
        if ($pwdLength -ge 14) {
            Register-Check -Name "WLAPS Password Length" -Status PASS -Message "$pwdLength characters"
        } elseif ($pwdLength -ge 12) {
            Register-Check -Name "WLAPS Password Length" -Status WARN -Message "$pwdLength characters (recommend 14+)"
        } else {
            Register-Check -Name "WLAPS Password Length" -Status FAIL -Message "$pwdLength characters (too short)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if (-not $windowsLapsConfigured) {
    Register-Check -Name "Windows LAPS" -Status SKIP -Message "Not configured via policy"
}

# ============================================================================
# LEGACY LAPS (Microsoft LAPS)
# ============================================================================
Write-Section "Legacy LAPS"

$legacyLapsConfigured = $false
$legacyGPOPath = "HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd"

try {
    $legacyLaps = Get-ItemProperty $legacyGPOPath -ErrorAction SilentlyContinue
    if ($legacyLaps) {
        $legacyLapsConfigured = $true

        # Check if enabled
        if ($legacyLaps.AdmPwdEnabled -eq 1) {
            Register-Check -Name "Legacy LAPS Enabled" -Status PASS -Message "Enabled"

            # Password expiration
            $pwExpDays = $legacyLaps.PasswordExpirationProtectionEnabled
            if ($pwExpDays -eq 1) {
                Register-Check -Name "Legacy LAPS Expiration Protection" -Status PASS -Message "Enabled"
            }

            # Password complexity
            $complexity = $legacyLaps.PasswordComplexity
            if ($complexity -ge 4) {
                Register-Check -Name "Legacy LAPS Complexity" -Status PASS -Message "All character types"
            } elseif ($complexity -ge 3) {
                Register-Check -Name "Legacy LAPS Complexity" -Status PASS -Message "Good"
            } else {
                Register-Check -Name "Legacy LAPS Complexity" -Status WARN -Message "Low complexity"
            }

            # Password length
            $length = $legacyLaps.PasswordLength
            if ($length -ge 14) {
                Register-Check -Name "Legacy LAPS Length" -Status PASS -Message "$length characters"
            } elseif ($length -ge 12) {
                Register-Check -Name "Legacy LAPS Length" -Status WARN -Message "$length characters"
            } else {
                Register-Check -Name "Legacy LAPS Length" -Status FAIL -Message "$length characters"
            }

            # Password age
            $age = $legacyLaps.PasswordAgeDays
            if ($age -le 30) {
                Register-Check -Name "Legacy LAPS Age" -Status PASS -Message "$age days"
            } else {
                Register-Check -Name "Legacy LAPS Age" -Status WARN -Message "$age days (recommend 30 or less)"
            }
        } else {
            Register-Check -Name "Legacy LAPS Enabled" -Status FAIL -Message "Policy present but disabled"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if (-not $legacyLapsConfigured) {
    Register-Check -Name "Legacy LAPS" -Status SKIP -Message "Not configured"
}

# ============================================================================
# LAPS CLIENT STATUS
# ============================================================================
Write-Section "LAPS Client Status"

# Check if LAPS CSE is installed (Legacy LAPS)
try {
    $lapsDll = Test-Path "$env:ProgramFiles\LAPS\CSE\AdmPwd.dll"
    $lapsDll64 = Test-Path "${env:ProgramFiles(x86)}\LAPS\CSE\AdmPwd.dll"

    if ($lapsDll -or $lapsDll64) {
        Register-Check -Name "Legacy LAPS CSE" -Status PASS -Message "Installed"
    } else {
        if ($legacyLapsConfigured) {
            Register-Check -Name "Legacy LAPS CSE" -Status FAIL -Message "Policy configured but CSE not installed"
        } else {
            Register-Check -Name "Legacy LAPS CSE" -Status SKIP -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "LAPS CSE" -Status SKIP -Message "Cannot check"
}

# Check last password change via event log
try {
    $lapsEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        ProviderName = 'AdmPwd'
    } -MaxEvents 5 -ErrorAction SilentlyContinue

    if ($lapsEvents) {
        $lastEvent = $lapsEvents | Select-Object -First 1
        Register-Check -Name "LAPS Activity" -Status PASS -Message "Last event: $($lastEvent.TimeCreated)"
    }
} catch {
    # Try Windows LAPS events
    try {
        $wlapsEvents = Get-WinEvent -FilterHashtable @{
            LogName = 'Microsoft-Windows-LAPS/Operational'
        } -MaxEvents 5 -ErrorAction SilentlyContinue

        if ($wlapsEvents) {
            $lastEvent = $wlapsEvents | Select-Object -First 1
            Register-Check -Name "Windows LAPS Activity" -Status PASS -Message "Last event: $($lastEvent.TimeCreated)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# AD SCHEMA CHECK (if AD module available)
# ============================================================================
Write-Section "Active Directory Integration"

try {
    Import-Module ActiveDirectory -ErrorAction Stop
    Get-ADDomain | Out-Null

    # Check for LAPS schema attributes
    $schemaContext = (Get-ADRootDSE).schemaNamingContext

    # Legacy LAPS attributes
    $legacyAttr = Get-ADObject -SearchBase $schemaContext -Filter { lDAPDisplayName -eq 'ms-Mcs-AdmPwd' } -ErrorAction SilentlyContinue
    if ($legacyAttr) {
        Register-Check -Name "Legacy LAPS Schema" -Status PASS -Message "ms-Mcs-AdmPwd attribute present"
    } else {
        Register-Check -Name "Legacy LAPS Schema" -Status SKIP -Message "Schema not extended for legacy LAPS"
    }

    # Windows LAPS attributes
    $wlapsAttr = Get-ADObject -SearchBase $schemaContext -Filter { lDAPDisplayName -eq 'msLAPS-Password' } -ErrorAction SilentlyContinue
    if ($wlapsAttr) {
        Register-Check -Name "Windows LAPS Schema" -Status PASS -Message "msLAPS-Password attribute present"
    } else {
        Register-Check -Name "Windows LAPS Schema" -Status SKIP -Message "Schema not extended for Windows LAPS"
    }

} catch {
    Register-Check -Name "AD Schema Check" -Status SKIP -Message "Cannot query AD schema"
}

# ============================================================================
# OVERALL LAPS STATUS
# ============================================================================
Write-Section "Overall Assessment"

if ($windowsLapsConfigured) {
    Register-Check -Name "LAPS Implementation" -Status PASS -Message "Windows LAPS (recommended)"
} elseif ($legacyLapsConfigured) {
    Register-Check -Name "LAPS Implementation" -Status WARN -Message "Legacy LAPS (consider upgrade to Windows LAPS)"
} else {
    Register-Check -Name "LAPS Implementation" -Status FAIL -Message "No LAPS solution configured - local admin passwords not managed"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
