# LSASS (Local Security Authority Subsystem Service) Protection Audit
# Comprehensive security checks for credential protection
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 18.4.x (LSA Protection), 2.3.10.x (Network Security)
# - CIS Windows Server 2022: 18.4.x, 2.3.10.x
# - Microsoft LSASS Security: https://learn.microsoft.com/en-us/windows-server/security/credentials-protection-and-management/configuring-additional-lsa-protection
#
# Compliance Mapping:
# - CIS Controls: 6.5 (Password Credential Protection), 10.5 (Anti-Exploitation)
# - NIST SP 800-53: IA-5 (Authenticator Management), SI-7 (Software Integrity)
# - MITRE ATT&CK: T1003 (OS Credential Dumping), T1003.001 (LSASS Memory)
# - PCI DSS: 8.2.1

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

$lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$securityProvidersPath = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders"

function Test-LsaRegistry {
    param(
        [string]$Path,
        [string]$Name,
        [string]$CheckName,
        [string]$CISRef = "",
        $ExpectedValue,
        [string]$PassMessage,
        [string]$FailMessage
    )

    $displayName = if ($CISRef) { "($CISRef) $CheckName" } else { $CheckName }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        if ($actualValue -eq $ExpectedValue) {
            Register-Check -Name $displayName -Status PASS -Message $PassMessage
        } else {
            Register-Check -Name $displayName -Status FAIL -Message "$FailMessage (Current: $actualValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status WARN -Message "Not configured"
    }
}

# ============================================================================
# LSASS PROTECTION (RunAsPPL)
# ============================================================================
Write-Section "LSASS Protection (RunAsPPL)"

# CIS 18.4.8 (approx) - Configure LSA Protection (RunAsPPL)
Test-LsaRegistry -Path $lsaPath -Name "RunAsPPL" `
    -CheckName "LSASS Protected Process Light" -CISRef "18.4" `
    -ExpectedValue 1 `
    -PassMessage "Enabled (Protected Process Light)" `
    -FailMessage "Disabled - LSASS vulnerable to credential dumping"

# Additional PPL UEFI lock check (Windows 11+)
try {
    $runAsPPLBoot = Get-ItemProperty -Path $lsaPath -Name "RunAsPPLBoot" -ErrorAction SilentlyContinue
    if ($runAsPPLBoot.RunAsPPLBoot -eq 2) {
        Register-Check -Name "LSASS PPL UEFI Lock" -Status PASS -Message "Enforced via UEFI (cannot be disabled)"
    } elseif ($runAsPPLBoot.RunAsPPLBoot -eq 1) {
        Register-Check -Name "LSASS PPL UEFI Lock" -Status INFO -Message "Configured but not UEFI locked"
    }
} catch {
    Register-Check -Name "LSASS PPL UEFI Lock" -Status INFO -Message "Not configured (Windows 11+ feature)"
}

# ============================================================================
# WDIGEST AUTHENTICATION (Credential Caching)
# ============================================================================
Write-Section "WDigest Authentication"

# WDigest stores plaintext passwords in memory - should be disabled
Test-LsaRegistry -Path $lsaPath -Name "UseLogonCredential" `
    -CheckName "WDigest Credential Caching" `
    -ExpectedValue 0 `
    -PassMessage "Disabled (no plaintext credentials in memory)" `
    -FailMessage "ENABLED - plaintext passwords stored in LSASS memory"

# ============================================================================
# LSA SECURITY PROVIDERS
# ============================================================================
Write-Section "LSA Security Providers"

# Check for suspicious security providers
try {
    Get-ItemProperty -Path "$securityProvidersPath\WDigest" -ErrorAction SilentlyContinue | Out-Null
    $secSupportProviders = (Get-ItemProperty -Path $lsaPath -Name "Security Packages" -ErrorAction SilentlyContinue).'Security Packages'

    # Known good providers
    $knownProviders = @('kerberos', 'msv1_0', 'schannel', 'wdigest', 'tspkg', 'pku2u', 'cloudap', 'livessp')

    if ($secSupportProviders) {
        $unknown = $secSupportProviders | Where-Object { $_ -notin $knownProviders -and $_ -ne '' }
        if ($unknown) {
            Register-Check -Name "Suspicious Security Providers" -Status WARN -Message "Unknown: $($unknown -join ', ')"
        } else {
            Register-Check -Name "Security Providers" -Status PASS -Message "Only known providers configured"
        }
    }
} catch {
    Register-Check -Name "Security Providers" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# NTLM RESTRICTIONS
# ============================================================================
Write-Section "NTLM Restrictions (CIS 2.3.11.x)"

# CIS 2.3.11.1 - Network security: Allow Local System to use computer identity for NTLM
Test-LsaRegistry -Path $lsaPath -Name "UseMachineId" `
    -CheckName "Use Machine ID for NTLM" -CISRef "2.3.11.1" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.11.2 - Network security: Allow LocalSystem NULL session fallback
Test-LsaRegistry -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "AllowNullSessionFallback" `
    -CheckName "NULL Session Fallback" -CISRef "2.3.11.2" `
    -ExpectedValue 0 `
    -PassMessage "Disabled (secure)" `
    -FailMessage "Enabled - NULL sessions allowed"

# CIS 2.3.11.4 - LAN Manager authentication level
try {
    $lmLevel = (Get-ItemProperty -Path $lsaPath -Name "LmCompatibilityLevel" -ErrorAction Stop).LmCompatibilityLevel
    $levelDesc = switch ($lmLevel) {
        0 { "Send LM & NTLM (Insecure)" }
        1 { "Send LM & NTLM - use NTLMv2 if negotiated" }
        2 { "Send NTLM only" }
        3 { "Send NTLMv2 only" }
        4 { "Send NTLMv2 only, refuse LM" }
        5 { "Send NTLMv2 only, refuse LM & NTLM (Most Secure)" }
        default { "Unknown ($lmLevel)" }
    }

    if ($lmLevel -ge 5) {
        Register-Check -Name "(2.3.11.4) LAN Manager Auth Level" -Status PASS -Message $levelDesc
    } elseif ($lmLevel -ge 3) {
        Register-Check -Name "(2.3.11.4) LAN Manager Auth Level" -Status WARN -Message "$levelDesc (recommend 5)"
    } else {
        Register-Check -Name "(2.3.11.4) LAN Manager Auth Level" -Status FAIL -Message $levelDesc
    }
} catch {
    Register-Check -Name "(2.3.11.4) LAN Manager Auth Level" -Status WARN -Message "Not configured"
}

# CIS 2.3.11.5 - Minimum session security for NTLM SSP clients
Test-LsaRegistry -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "NTLMMinClientSec" `
    -CheckName "NTLM Client Min Security" -CISRef "2.3.11.5" `
    -ExpectedValue 537395200 `
    -PassMessage "Require NTLMv2 and 128-bit encryption" `
    -FailMessage "Weak security configured"

# CIS 2.3.11.6 - Minimum session security for NTLM SSP servers
Test-LsaRegistry -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "NTLMMinServerSec" `
    -CheckName "NTLM Server Min Security" -CISRef "2.3.11.6" `
    -ExpectedValue 537395200 `
    -PassMessage "Require NTLMv2 and 128-bit encryption" `
    -FailMessage "Weak security configured"

# ============================================================================
# ADDITIONAL LSASS HARDENING
# ============================================================================
Write-Section "Additional LSASS Hardening"

# Audit DPAPI backup (credential manager)
try {
    $dpapi = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Cryptography\Protect\Providers\df9d8cd0-1501-11d1-8c7a-00c04fc297eb" -ErrorAction SilentlyContinue
    if ($null -ne $dpapi) {
        Register-Check -Name "DPAPI Master Key Backup" -Status INFO -Message "DPAPI configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for credential delegation restrictions
try {
    $credSSP = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowDefCredentialsWhenNTLMOnly" -ErrorAction SilentlyContinue
    if ($credSSP.AllowDefCredentialsWhenNTLMOnly -eq 0 -or $null -eq $credSSP) {
        Register-Check -Name "CredSSP NTLM Delegation" -Status PASS -Message "Restricted"
    } else {
        Register-Check -Name "CredSSP NTLM Delegation" -Status WARN -Message "NTLM delegation allowed"
    }
} catch {
    Register-Check -Name "CredSSP NTLM Delegation" -Status INFO -Message "Default (restricted)"
}

# Check for debug programs privilege (can access LSASS)
try {
    $tempFile = "$env:TEMP\secpol_lsass_$(Get-Date -Format 'yyyyMMddHHmmss').txt"
    $null = & secedit /export /cfg $tempFile /quiet 2>&1

    if (Test-Path $tempFile) {
        $secpol = Get-Content $tempFile -Raw
        if ($secpol -match "SeDebugPrivilege\s*=\s*(.*)") {
            $debugUsers = $matches[1].Trim()
            if ([string]::IsNullOrWhiteSpace($debugUsers)) {
                Register-Check -Name "Debug Programs Privilege" -Status PASS -Message "Not assigned (secure)"
            } else {
                Register-Check -Name "Debug Programs Privilege" -Status WARN -Message "Assigned - can dump LSASS"
            }
        }
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
} catch {
    Register-Check -Name "Debug Programs Privilege" -Status SKIP -Message "Cannot check (requires elevation)"
}

Print-Summary
Exit-Audit
