# MDM Enrollment Audit Script (PowerShell)
# Checks for MDM enrollment, compliance status, and management agent configuration
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Controls: Device Management
# - NIST SP 800-53: CM-2, CM-6

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# MICROSOFT INTUNE / ENDPOINT MANAGER
# ============================================================================
Write-Section "Microsoft Intune / Endpoint Manager"

# Check Intune MDM enrollment
try {
    $mdmPath = "HKLM:\SOFTWARE\Microsoft\Enrollments"
    if (Test-Path $mdmPath) {
        $enrollments = Get-ChildItem -Path $mdmPath -ErrorAction SilentlyContinue | Where-Object {
            (Get-ItemProperty -Path $_.PSPath -Name "ProviderID" -ErrorAction SilentlyContinue).ProviderID -eq "MS DM Server"
        }

        if ($enrollments) {
            Register-Check -Name "Intune Enrollment" -Status PASS -Message "Device enrolled in Intune"

            foreach ($enrollment in $enrollments) {
                $enrollProps = Get-ItemProperty -Path $enrollment.PSPath -ErrorAction SilentlyContinue

                # UPN
                if ($enrollProps.UPN) {
                    Register-Check -Name "Intune User" -Status INFO -Message "$($enrollProps.UPN)"
                }

                # AAD Join status
                $aadPath = "HKLM:\SYSTEM\CurrentControlSet\Control\CloudDomainJoin\JoinInfo"
                if (Test-Path $aadPath) {
                    $aadInfo = Get-ChildItem -Path $aadPath -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($aadInfo) {
                        $aadProps = Get-ItemProperty -Path $aadInfo.PSPath -ErrorAction SilentlyContinue
                        if ($aadProps.TenantId) {
                            Register-Check -Name "Azure AD Joined" -Status PASS -Message "TenantId: $($aadProps.TenantId.Substring(0,8))..."
                        }
                    }
                }
            }
        } else {
            Register-Check -Name "Intune Enrollment" -Status WARN -Message "Not enrolled"
        }
    } else {
        Register-Check -Name "Intune Enrollment" -Status WARN -Message "No MDM enrollments found"
    }
} catch {
    Register-Check -Name "Intune Enrollment" -Status INFO -Message "Unable to check"
}

# Intune Management Extension (aka SideCar / Win32 app deployment)
try {
    $imeService = Get-Service -Name "IntuneManagementExtension" -ErrorAction SilentlyContinue
    if ($imeService) {
        if ($imeService.Status -eq "Running") {
            Register-Check -Name "Intune Management Extension" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Intune Management Extension" -Status WARN -Message "$($imeService.Status)"
        }
    } else {
        Register-Check -Name "Intune Management Extension" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Intune Management Extension" -Status INFO -Message "Not detected"
}

# Entra ID Hybrid Join status
try {
    $dsreg = dsregcmd /status 2>$null
    if ($dsreg) {
        # Azure AD Joined
        if ($dsreg -match "AzureAdJoined\s*:\s*YES") {
            Register-Check -Name "Azure AD Join" -Status PASS -Message "YES"
        } elseif ($dsreg -match "AzureAdJoined\s*:\s*NO") {
            Register-Check -Name "Azure AD Join" -Status INFO -Message "NO"
        }

        # Domain Joined
        if ($dsreg -match "DomainJoined\s*:\s*YES") {
            Register-Check -Name "Domain Joined" -Status INFO -Message "YES"
        }

        # Hybrid Joined
        if (($dsreg -match "AzureAdJoined\s*:\s*YES") -and ($dsreg -match "DomainJoined\s*:\s*YES")) {
            Register-Check -Name "Hybrid Azure AD Join" -Status PASS -Message "Device is hybrid joined"
        }

        # Device State
        if ($dsreg -match "DeviceId\s*:\s*([a-f0-9-]+)") {
            Register-Check -Name "Entra Device ID" -Status INFO -Message "$($Matches[1].Substring(0,8))..."
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SCCM / MECM (CONFIGURATION MANAGER)
# ============================================================================
Write-Section "Microsoft SCCM / MECM"

# CM Client
try {
    $ccmService = Get-Service -Name "CcmExec" -ErrorAction SilentlyContinue
    if ($ccmService) {
        if ($ccmService.Status -eq "Running") {
            Register-Check -Name "SCCM Client Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "SCCM Client Agent" -Status WARN -Message "$($ccmService.Status)"
        }

        # Check client version
        try {
            $ccmVersion = Get-CimInstance -Namespace "root\ccm" -ClassName "SMS_Client" -ErrorAction SilentlyContinue
            if ($ccmVersion) {
                Register-Check -Name "SCCM Client Version" -Status INFO -Message "$($ccmVersion.ClientVersion)"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Site assignment
        try {
            $ccmSite = Get-CimInstance -Namespace "root\ccm" -ClassName "SMS_Client" -ErrorAction SilentlyContinue
            if ($ccmSite.AssignedSite) {
                Register-Check -Name "SCCM Site Code" -Status INFO -Message "$($ccmSite.AssignedSite)"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Management Point
        try {
            $ccmMP = Get-CimInstance -Namespace "root\ccm" -Query "SELECT CurrentManagementPoint FROM SMS_Authority" -ErrorAction SilentlyContinue
            if ($ccmMP.CurrentManagementPoint) {
                Register-Check -Name "SCCM Management Point" -Status PASS -Message "Connected"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    } else {
        Register-Check -Name "SCCM Client" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "SCCM Client" -Status INFO -Message "Not detected"
}

# Co-management status
try {
    $coMgmt = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\CCM\CoManagementHandler" -Name "CoManagementFlags" -ErrorAction SilentlyContinue
    if ($coMgmt.CoManagementFlags -gt 0) {
        Register-Check -Name "Co-Management" -Status PASS -Message "Enabled (flags: $($coMgmt.CoManagementFlags))"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# VMWARE WORKSPACE ONE (AIRWATCH)
# ============================================================================
Write-Section "VMware Workspace ONE"

try {
    $ws1Service = Get-Service -Name "AirWatchService" -ErrorAction SilentlyContinue
    if (-not $ws1Service) {
        $ws1Service = Get-Service -Name "AWACMService" -ErrorAction SilentlyContinue
    }

    if ($ws1Service) {
        if ($ws1Service.Status -eq "Running") {
            Register-Check -Name "Workspace ONE Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Workspace ONE Agent" -Status WARN -Message "$($ws1Service.Status)"
        }

        # Hub services
        $hubService = Get-Service -Name "VMware Hub Health*" -ErrorAction SilentlyContinue
        if ($hubService -and $hubService.Status -eq "Running") {
            Register-Check -Name "Workspace ONE Hub" -Status PASS -Message "Running"
        }
    } else {
        Register-Check -Name "Workspace ONE" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Workspace ONE" -Status INFO -Message "Not detected"
}

# ============================================================================
# JAMF (FOR WINDOWS)
# ============================================================================
Write-Section "Jamf"

try {
    $jamfService = Get-Service -Name "JamfProtect*" -ErrorAction SilentlyContinue
    if ($jamfService) {
        if ($jamfService.Status -eq "Running") {
            Register-Check -Name "Jamf Protect" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Jamf Protect" -Status WARN -Message "$($jamfService.Status)"
        }
    } else {
        Register-Check -Name "Jamf" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Jamf" -Status INFO -Message "Not detected"
}

# ============================================================================
# KANDJI / OTHER MDM
# ============================================================================
Write-Section "Other MDM Solutions"

$otherMDM = @(
    @{Service="MobicontrolService"; Name="Soti MobiControl"},
    @{Service="ManageEngine*"; Name="ManageEngine"},
    @{Service="NinjaRMMAgent"; Name="NinjaRMM"},
    @{Service="Atera*"; Name="Atera Agent"},
    @{Service="ConnectWiseControl.WindowsService"; Name="ConnectWise Control"},
    @{Service="Automox*"; Name="Automox"}
)

foreach ($mdm in $otherMDM) {
    try {
        $svc = Get-Service -Name $mdm.Service -ErrorAction SilentlyContinue
        if ($svc) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name $mdm.Name -Status PASS -Message "Running"
            } else {
                Register-Check -Name $mdm.Name -Status WARN -Message "$($svc.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# MDM POLICY COMPLIANCE
# ============================================================================
Write-Section "MDM Policy Compliance"

# Check if device is compliant (Intune)
try {
    $complianceKeys = Get-ChildItem -Path "HKLM:\SOFTWARE\Microsoft\Enrollments" -ErrorAction SilentlyContinue | ForEach-Object {
        Join-Path $_.PSPath "DMClient\MS DM Server"
    }

    foreach ($key in $complianceKeys) {
        if (Test-Path $key) {
            $compliance = Get-ItemProperty -Path $key -Name "ComplianceState" -ErrorAction SilentlyContinue
            if ($compliance.ComplianceState -eq 0) {
                Register-Check -Name "Intune Compliance" -Status PASS -Message "Device is compliant"
            } elseif ($compliance.ComplianceState -eq 1) {
                Register-Check -Name "Intune Compliance" -Status WARN -Message "Device is non-compliant"
            }
            break
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Last sync time
try {
    $syncPath = "HKLM:\SOFTWARE\Microsoft\Enrollments"
    $enrollments = Get-ChildItem -Path $syncPath -ErrorAction SilentlyContinue
    foreach ($enrollment in $enrollments) {
        $lastSync = Get-ItemProperty -Path $enrollment.PSPath -Name "LastSuccessfulSync" -ErrorAction SilentlyContinue
        if ($lastSync.LastSuccessfulSync) {
            $syncTime = [DateTime]::FromFileTime($lastSync.LastSuccessfulSync)
            $hoursSince = (Get-Date) - $syncTime
            if ($hoursSince.TotalHours -le 24) {
                Register-Check -Name "MDM Last Sync" -Status PASS -Message "$($syncTime.ToString('g'))"
            } else {
                Register-Check -Name "MDM Last Sync" -Status WARN -Message "$([int]$hoursSince.TotalDays) days ago"
            }
            break
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DEVICE HEALTH ATTESTATION
# ============================================================================
Write-Section "Device Health Attestation"

try {
    $dhaService = Get-Service -Name "DeviceAssociationService" -ErrorAction SilentlyContinue
    if ($dhaService -and $dhaService.Status -eq "Running") {
        Register-Check -Name "Device Association Service" -Status PASS -Message "Running"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# TPM Health
try {
    $tpm = Get-CimInstance -Namespace "root\cimv2\security\microsofttpm" -ClassName "Win32_Tpm" -ErrorAction SilentlyContinue
    if ($tpm) {
        if ($tpm.IsEnabled_InitialValue -and $tpm.IsActivated_InitialValue) {
            Register-Check -Name "TPM Health" -Status PASS -Message "TPM enabled and ready"
        } else {
            Register-Check -Name "TPM Health" -Status WARN -Message "TPM not fully activated"
        }
    } else {
        Register-Check -Name "TPM Health" -Status INFO -Message "TPM not detected"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Secure Boot
try {
    $secureBoot = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
    if ($secureBoot -eq $true) {
        Register-Check -Name "Secure Boot" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Secure Boot" -Status WARN -Message "Not enabled"
    }
} catch {
    Register-Check -Name "Secure Boot" -Status INFO -Message "Unable to check (legacy BIOS?)"
}

# ============================================================================
# MDM COVERAGE SUMMARY
# ============================================================================
Write-Section "MDM Coverage Summary"

$mdmProducts = @(
    @{Service="IntuneManagementExtension"; Name="Intune"},
    @{Service="CcmExec"; Name="SCCM/MECM"},
    @{Service="AirWatchService"; Name="Workspace ONE"},
    @{Service="AWACMService"; Name="Workspace ONE"},
    @{Service="NinjaRMMAgent"; Name="NinjaRMM"},
    @{Service="Automox*"; Name="Automox"}
)

$runningMDM = @()
foreach ($mdm in $mdmProducts) {
    $svc = Get-Service -Name $mdm.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningMDM += $mdm.Name
    }
}

# Also check enrollment registry
try {
    $mdmPath = "HKLM:\SOFTWARE\Microsoft\Enrollments"
    if (Test-Path $mdmPath) {
        $enrollments = Get-ChildItem -Path $mdmPath -ErrorAction SilentlyContinue | Where-Object {
            (Get-ItemProperty -Path $_.PSPath -Name "ProviderID" -ErrorAction SilentlyContinue).ProviderID -eq "MS DM Server"
        }
        if ($enrollments -and ("Intune" -notin $runningMDM)) {
            $runningMDM += "Intune (enrolled)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if ($runningMDM.Count -ge 1) {
    Register-Check -Name "MDM Coverage" -Status PASS -Message "Managed by: $($runningMDM -join ', ')"
} else {
    Register-Check -Name "MDM Coverage" -Status WARN -Message "No MDM solution detected"
}

# Domain membership as fallback
try {
    $domainInfo = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    if ($domainInfo.PartOfDomain -and $runningMDM.Count -eq 0) {
        Register-Check -Name "Domain Membership" -Status INFO -Message "Domain: $($domainInfo.Domain) (GPO management available)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
