# Check MMC Console Permissions
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
	Register-Check -Name "MMC Console Permissions" -Status WARN -Message "Review permissions on .msc files in %SystemRoot%\System32 manually."
} catch {
	Register-Check -Name "MMC Console Permissions" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit
