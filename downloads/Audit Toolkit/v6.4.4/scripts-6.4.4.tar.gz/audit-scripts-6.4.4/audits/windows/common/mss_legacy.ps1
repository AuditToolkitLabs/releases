# MSS (Legacy) Security Settings Audit Script (PowerShell)
# Checks CIS 18.4.x MSS (Legacy) registry settings
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Windows 11 Benchmark v2.0 - Section 18.4
# - Microsoft Security Baseline

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTION
# ============================================================================

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$ExpectedValue,
        [string]$Description,
        [string]$CISRef = "",
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual
    )

    $displayName = if ($CISRef) { "($CISRef) $Description" } else { $Description }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        $passed = $false
        if ($GreaterOrEqual) {
            $passed = $actualValue -ge $ExpectedValue
        } elseif ($LessOrEqual) {
            $passed = $actualValue -le $ExpectedValue
        } else {
            $passed = $actualValue -eq $ExpectedValue
        }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message "Value: $actualValue"
        } else {
            Register-Check -Name $displayName -Status WARN -Message "Value: $actualValue (expected: $ExpectedValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status INFO -Message "Not configured"
    }
}

# ============================================================================
# CIS 18.4.1 - MSS: (AutoAdminLogon)
# ============================================================================
Write-Section "18.4.1 AutoAdminLogon"

# 18.4.1 (L1) Ensure 'MSS: (AutoAdminLogon) Enable Automatic Logon' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" `
    -Name "AutoAdminLogon" -ExpectedValue "0" `
    -Description "Auto Admin Logon disabled" -CISRef "18.4.1"

# ============================================================================
# CIS 18.4.2 - MSS: (DisableIPSourceRouting IPv6)
# ============================================================================
Write-Section "18.4.2 IP Source Routing (IPv6)"

# 18.4.2 (L1) Ensure 'MSS: (DisableIPSourceRouting IPv6)' is set to 'Highest protection'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" `
    -Name "DisableIPSourceRouting" -ExpectedValue 2 `
    -Description "IPv6 Source Routing disabled" -CISRef "18.4.2"

# ============================================================================
# CIS 18.4.3 - MSS: (DisableIPSourceRouting)
# ============================================================================
Write-Section "18.4.3 IP Source Routing (IPv4)"

# 18.4.3 (L1) Ensure 'MSS: (DisableIPSourceRouting)' is set to 'Highest protection'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "DisableIPSourceRouting" -ExpectedValue 2 `
    -Description "IPv4 Source Routing disabled" -CISRef "18.4.3"

# ============================================================================
# CIS 18.4.4 - MSS: (EnableICMPRedirect)
# ============================================================================
Write-Section "18.4.4 ICMP Redirects"

# 18.4.4 (L1) Ensure 'MSS: (EnableICMPRedirect)' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "EnableICMPRedirect" -ExpectedValue 0 `
    -Description "ICMP Redirects disabled" -CISRef "18.4.4"

# ============================================================================
# CIS 18.4.5 - MSS: (KeepAliveTime)
# ============================================================================
Write-Section "18.4.5 TCP Keep-Alive Time"

# 18.4.5 (L2) Ensure 'MSS: (KeepAliveTime)' is set to '300,000 or 5 minutes'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "KeepAliveTime" -ExpectedValue 300000 -LessOrEqual `
    -Description "TCP Keep-Alive Time" -CISRef "18.4.5"

# ============================================================================
# CIS 18.4.6 - MSS: (NoNameReleaseOnDemand)
# ============================================================================
Write-Section "18.4.6 NetBIOS Name Release"

# 18.4.6 (L1) Ensure 'MSS: (NoNameReleaseOnDemand)' is set to 'Enabled'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" `
    -Name "NoNameReleaseOnDemand" -ExpectedValue 1 `
    -Description "NoNameReleaseOnDemand enabled" -CISRef "18.4.6"

# ============================================================================
# CIS 18.4.7 - MSS: (PerformRouterDiscovery)
# ============================================================================
Write-Section "18.4.7 Router Discovery"

# 18.4.7 (L2) Ensure 'MSS: (PerformRouterDiscovery)' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "PerformRouterDiscovery" -ExpectedValue 0 `
    -Description "Router Discovery disabled" -CISRef "18.4.7"

# ============================================================================
# CIS 18.4.8 - MSS: (SafeDllSearchMode)
# ============================================================================
Write-Section "18.4.8 Safe DLL Search Mode"

# 18.4.8 (L1) Ensure 'MSS: (SafeDllSearchMode)' is set to 'Enabled'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" `
    -Name "SafeDllSearchMode" -ExpectedValue 1 `
    -Description "Safe DLL Search Mode enabled" -CISRef "18.4.8"

# ============================================================================
# CIS 18.4.9 - MSS: (ScreenSaverGracePeriod)
# ============================================================================
Write-Section "18.4.9 Screen Saver Grace Period"

# 18.4.9 (L1) Ensure 'MSS: (ScreenSaverGracePeriod)' is set to '5 or fewer seconds'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" `
    -Name "ScreenSaverGracePeriod" -ExpectedValue 5 -LessOrEqual `
    -Description "Screen Saver Grace Period" -CISRef "18.4.9"

# ============================================================================
# CIS 18.4.10 - MSS: (TcpMaxDataRetransmissions IPv6)
# ============================================================================
Write-Section "18.4.10 TCP Max Data Retransmissions (IPv6)"

# 18.4.10 (L2) Ensure 'MSS: (TcpMaxDataRetransmissions IPv6)' is set to '3'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" `
    -Name "TcpMaxDataRetransmissions" -ExpectedValue 3 -LessOrEqual `
    -Description "IPv6 TCP Max Retransmissions" -CISRef "18.4.10"

# ============================================================================
# CIS 18.4.11 - MSS: (TcpMaxDataRetransmissions)
# ============================================================================
Write-Section "18.4.11 TCP Max Data Retransmissions (IPv4)"

# 18.4.11 (L2) Ensure 'MSS: (TcpMaxDataRetransmissions)' is set to '3'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "TcpMaxDataRetransmissions" -ExpectedValue 3 -LessOrEqual `
    -Description "IPv4 TCP Max Retransmissions" -CISRef "18.4.11"

# ============================================================================
# CIS 18.4.12 - MSS: (WarningLevel)
# ============================================================================
Write-Section "18.4.12 Security Log Warning Level"

# 18.4.12 (L1) Ensure 'MSS: (WarningLevel)' is set to '90% or less'
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security" `
    -Name "WarningLevel" -ExpectedValue 90 -LessOrEqual `
    -Description "Security Log Warning Level" -CISRef "18.4.12"

# ============================================================================
# ADDITIONAL MSS SETTINGS (Best Practice)
# ============================================================================
Write-Section "Additional MSS Settings"

# Hidden (don't display last username)
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" `
    -Name "DontDisplayLastUserName" -ExpectedValue 1 `
    -Description "Don't display last username"

# DisableSavePassword (RAS/VPN)
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Parameters" `
    -Name "DisableSavePassword" -ExpectedValue 1 `
    -Description "Disable save password for dial-up"

# EnableDeadGWDetect
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "EnableDeadGWDetect" -ExpectedValue 0 `
    -Description "Dead Gateway Detection disabled"

# SynAttackProtect
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "SynAttackProtect" -ExpectedValue 1 `
    -Description "SYN Attack Protection enabled"

# EnablePMTUDiscovery
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "EnablePMTUDiscovery" -ExpectedValue 1 `
    -Description "PMTU Discovery enabled"

# TCPMaxConnectResponseRetransmissions
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "TcpMaxConnectResponseRetransmissions" -ExpectedValue 2 -LessOrEqual `
    -Description "TCP SYN-ACK Retransmissions"

# TCPMaxHalfOpen
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "TcpMaxHalfOpen" -ExpectedValue 500 -LessOrEqual `
    -Description "TCP Max Half-Open connections"

# TCPMaxHalfOpenRetried
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "TcpMaxHalfOpenRetried" -ExpectedValue 400 -LessOrEqual `
    -Description "TCP Max Half-Open Retried"

# ============================================================================
# NETWORK ADAPTER HARDENING
# ============================================================================
Write-Section "Network Adapter Settings"

# Disable NetBIOS over TCP/IP (check registry)
try {
    $adapters = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces" -ErrorAction Stop
    $netbiosDisabled = 0
    $netbiosTotal = 0

    foreach ($adapter in $adapters) {
        $netbiosTotal++
        $nbOption = Get-ItemProperty -Path $adapter.PSPath -Name "NetbiosOptions" -ErrorAction SilentlyContinue
        if ($nbOption.NetbiosOptions -eq 2) {
            $netbiosDisabled++
        }
    }

    if ($netbiosTotal -gt 0) {
        if ($netbiosDisabled -eq $netbiosTotal) {
            Register-Check -Name "NetBIOS over TCP/IP" -Status PASS -Message "Disabled on all $netbiosTotal adapters"
        } elseif ($netbiosDisabled -gt 0) {
            Register-Check -Name "NetBIOS over TCP/IP" -Status WARN -Message "Disabled on $netbiosDisabled of $netbiosTotal adapters"
        } else {
            Register-Check -Name "NetBIOS over TCP/IP" -Status WARN -Message "Enabled on all adapters"
        }
    }
} catch {
    Register-Check -Name "NetBIOS over TCP/IP" -Status INFO -Message "Unable to check"
}

# Disable LMHOSTS Lookup
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" `
    -Name "EnableLMHOSTS" -ExpectedValue 0 `
    -Description "LMHOSTS Lookup disabled"

# ============================================================================
# LANMAN SETTINGS
# ============================================================================
Write-Section "LanMan Settings"

# LanMan authentication level (already in ntlm_restrictions.ps1 but included for completeness)
try {
    $lmLevel = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LmCompatibilityLevel" -ErrorAction SilentlyContinue
    if ($lmLevel.LmCompatibilityLevel -ge 5) {
        Register-Check -Name "LM Compatibility Level" -Status PASS -Message "Level $($lmLevel.LmCompatibilityLevel) (NTLMv2 only)"
    } elseif ($lmLevel.LmCompatibilityLevel -ge 3) {
        Register-Check -Name "LM Compatibility Level" -Status WARN -Message "Level $($lmLevel.LmCompatibilityLevel) (NTLMv2 preferred)"
    } else {
        Register-Check -Name "LM Compatibility Level" -Status FAIL -Message "Level $($lmLevel.LmCompatibilityLevel) (weak)"
    }
} catch {
    Register-Check -Name "LM Compatibility Level" -Status INFO -Message "Not configured"
}

# NoDriveTypeAutoRun
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" `
    -Name "NoDriveTypeAutoRun" -ExpectedValue 255 `
    -Description "AutoRun disabled for all drives"

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
