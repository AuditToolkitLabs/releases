# Check NetBIOS and LLMNR Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $llmnr = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -ErrorAction SilentlyContinue
    if ($llmnr.EnableMulticast -eq 0) {
        Register-Check -Name "LLMNR" -Status PASS -Message "LLMNR is disabled."
    } else {
        Register-Check -Name "LLMNR" -Status FAIL -Message "LLMNR is enabled."
    }
    $netbios = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled } | Select-Object -ExpandProperty TcpipNetbiosOptions -Unique
    if ($netbios -eq 2) {
        Register-Check -Name "NetBIOS over TCP/IP" -Status PASS -Message "NetBIOS is disabled."
    } else {
        Register-Check -Name "NetBIOS over TCP/IP" -Status FAIL -Message "NetBIOS is enabled."
    }
} catch {
    Register-Check -Name "NetBIOS/LLMNR" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit