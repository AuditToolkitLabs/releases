# Network Settings Audit Script (PowerShell)
# Checks CIS 18.6.x Network security settings
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Windows 11 Benchmark v2.0 - Section 18.6
# - NIST SP 800-53: SC-7, SC-8

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTION
# ============================================================================

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$ExpectedValue,
        [string]$Description,
        [string]$CISRef = "",
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual
    )

    $displayName = if ($CISRef) { "($CISRef) $Description" } else { $Description }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        $passed = $false
        if ($GreaterOrEqual) {
            $passed = $actualValue -ge $ExpectedValue
        } elseif ($LessOrEqual) {
            $passed = $actualValue -le $ExpectedValue
        } else {
            $passed = $actualValue -eq $ExpectedValue
        }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message "Value: $actualValue"
        } else {
            Register-Check -Name $displayName -Status WARN -Message "Value: $actualValue (expected: $ExpectedValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status INFO -Message "Not configured"
    }
}

# ============================================================================
# CIS 18.6.4 - DNS Client
# ============================================================================
Write-Section "18.6.4 DNS Client"

# 18.6.4.1 (L1) Ensure 'Configure DNS over HTTPS (DoH) name resolution'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" `
    -Name "DoHPolicy" -ExpectedValue 2 `
    -Description "DNS over HTTPS required" -CISRef "18.6.4.1"

# Check actual DoH configuration
try {
    $dohSettings = Get-DnsClientDohServerAddress -ErrorAction SilentlyContinue
    if ($dohSettings) {
        Register-Check -Name "DoH Servers Configured" -Status INFO -Message "$($dohSettings.Count) server(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# 18.6.4.2 (L1) Ensure 'Configure NetBIOS settings'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" `
    -Name "EnableNetbios" -ExpectedValue 0 `
    -Description "NetBIOS disabled via DNS policy" -CISRef "18.6.4.2"

# 18.6.4.3 (L1) Ensure 'Turn off multicast name resolution' (LLMNR)
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" `
    -Name "EnableMulticast" -ExpectedValue 0 `
    -Description "LLMNR disabled" -CISRef "18.6.4.3"

# ============================================================================
# CIS 18.6.5 - Fonts
# ============================================================================
Write-Section "18.6.5 Fonts"

# 18.6.5.1 (L2) Ensure 'Enable Font Providers' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "EnableFontProviders" -ExpectedValue 0 `
    -Description "Font Providers disabled" -CISRef "18.6.5.1"

# ============================================================================
# CIS 18.6.8 - Lanman Workstation
# ============================================================================
Write-Section "18.6.8 Lanman Workstation"

# 18.6.8.1 (L1) Ensure 'Enable insecure guest logons' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation" `
    -Name "AllowInsecureGuestAuth" -ExpectedValue 0 `
    -Description "Insecure guest logons disabled" -CISRef "18.6.8.1"

# ============================================================================
# CIS 18.6.9 - Link-Layer Topology Discovery
# ============================================================================
Write-Section "18.6.9 LLTD"

# 18.6.9.1 (L2) Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LLTD" `
    -Name "EnableLLTDIO" -ExpectedValue 0 `
    -Description "LLTDIO driver disabled" -CISRef "18.6.9.1"

# 18.6.9.2 (L2) Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LLTD" `
    -Name "EnableRspndr" -ExpectedValue 0 `
    -Description "RSPNDR driver disabled" -CISRef "18.6.9.2"

# ============================================================================
# CIS 18.6.10 - Microsoft Peer-to-Peer Networking Services
# ============================================================================
Write-Section "18.6.10 Peer-to-Peer"

# 18.6.10.2 (L2) Ensure 'Turn off Microsoft Peer-to-Peer Networking Services'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Peernet" `
    -Name "Disabled" -ExpectedValue 1 `
    -Description "P2P Networking disabled" -CISRef "18.6.10.2"

# ============================================================================
# CIS 18.6.11 - Network Connections
# ============================================================================
Write-Section "18.6.11 Network Connections"

# 18.6.11.2 (L1) Ensure 'Prohibit installation of network bridge'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections" `
    -Name "NC_AllowNetBridge_NLA" -ExpectedValue 0 `
    -Description "Network bridge prohibited" -CISRef "18.6.11.2"

# 18.6.11.3 (L1) Ensure 'Prohibit use of Internet Connection Sharing'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections" `
    -Name "NC_ShowSharedAccessUI" -ExpectedValue 0 `
    -Description "ICS prohibited" -CISRef "18.6.11.3"

# 18.6.11.4 (L1) Ensure 'Require domain users to elevate when setting a network's location'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections" `
    -Name "NC_StdDomainUserSetLocation" -ExpectedValue 1 `
    -Description "Elevation for network location" -CISRef "18.6.11.4"

# ============================================================================
# CIS 18.6.14 - Network Provider
# ============================================================================
Write-Section "18.6.14 Network Provider"

# 18.6.14.1 (L1) Ensure 'Hardened UNC Paths' is set to 'Enabled'
$uncPaths = @(
    @{Path="\\*\NETLOGON"; Setting="RequireMutualAuthentication=1, RequireIntegrity=1"},
    @{Path="\\*\SYSVOL"; Setting="RequireMutualAuthentication=1, RequireIntegrity=1"}
)

try {
    $hardenedUNC = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -ErrorAction Stop

    foreach ($unc in $uncPaths) {
        $pathValue = $hardenedUNC.($unc.Path)
        if ($pathValue -match "RequireMutualAuthentication=1" -and $pathValue -match "RequireIntegrity=1") {
            Register-Check -Name "Hardened UNC: $($unc.Path)" -Status PASS -Message "Hardened"
        } else {
            Register-Check -Name "Hardened UNC: $($unc.Path)" -Status WARN -Message "Not fully hardened"
        }
    }
} catch {
    Register-Check -Name "(18.6.14.1) Hardened UNC Paths" -Status WARN -Message "Not configured"
}

# ============================================================================
# CIS 18.6.19 - TCPIP Settings
# ============================================================================
Write-Section "18.6.19 TCP/IP Settings"

# 18.6.19.2.1 (L2) Disable IPv6
try {
    $ipv6Disabled = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" `
        -Name "DisabledComponents" -ErrorAction SilentlyContinue
    if ($ipv6Disabled.DisabledComponents -eq 255) {
        Register-Check -Name "(18.6.19.2.1) IPv6 Disabled" -Status PASS -Message "Fully disabled (255)"
    } elseif ($ipv6Disabled.DisabledComponents -gt 0) {
        Register-Check -Name "(18.6.19.2.1) IPv6 Disabled" -Status INFO -Message "Partially disabled ($($ipv6Disabled.DisabledComponents))"
    } else {
        Register-Check -Name "(18.6.19.2.1) IPv6" -Status INFO -Message "Enabled"
    }
} catch {
    Register-Check -Name "(18.6.19.2.1) IPv6" -Status INFO -Message "Default (enabled)"
}

# ============================================================================
# CIS 18.6.20 - WLAN Settings
# ============================================================================
Write-Section "18.6.20 WLAN"

# 18.6.20.1 (L1) Ensure 'Allow Windows to automatically connect to suggested open hotspots'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config" `
    -Name "AutoConnectAllowedOEM" -ExpectedValue 0 `
    -Description "Auto-connect open hotspots disabled" -CISRef "18.6.20.1"

# 18.6.20.2 (L2) Ensure 'Prohibit connection to non-domain networks when on domain'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy" `
    -Name "fBlockNonDomain" -ExpectedValue 1 `
    -Description "Block non-domain networks" -CISRef "18.6.20.2"

# ============================================================================
# ADDITIONAL NETWORK SETTINGS
# ============================================================================
Write-Section "Additional Network Settings"

# mDNS
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" `
    -Name "EnableMDNS" -ExpectedValue 0 `
    -Description "mDNS disabled"

# WINS
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" `
    -Name "NodeType" -ExpectedValue 2 `
    -Description "WINS Node Type (P-node=2)"

# WPAD
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad" `
    -Name "WpadOverride" -ExpectedValue 1 `
    -Description "WPAD disabled"

# WebDAV
try {
    $webClient = Get-Service -Name "WebClient" -ErrorAction SilentlyContinue
    if ($webClient) {
        if ($webClient.StartType -eq "Disabled") {
            Register-Check -Name "WebClient (WebDAV)" -Status PASS -Message "Disabled"
        } else {
            Register-Check -Name "WebClient (WebDAV)" -Status WARN -Message "$($webClient.StartType)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Wi-Fi Sense
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config" `
    -Name "AutoConnectToOpenHotspots" -ExpectedValue 0 `
    -Description "Wi-Fi Sense hotspots disabled"

# Hotspot 2.0
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\WlanSvc\AnqpCache" `
    -Name "OsuRegistrationDone" -ExpectedValue 0 `
    -Description "Hotspot 2.0 registration"

# ============================================================================
# NETWORK PROFILE SETTINGS
# ============================================================================
Write-Section "Network Profile Settings"

# Check network profile
try {
    $connections = Get-NetConnectionProfile -ErrorAction SilentlyContinue
    foreach ($conn in $connections) {
        $status = switch ($conn.NetworkCategory) {
            "DomainAuthenticated" { "PASS" }
            "Private" { "INFO" }
            "Public" { "PASS" }
            default { "INFO" }
        }
        Register-Check -Name "Network: $($conn.Name)" -Status $status -Message "$($conn.NetworkCategory)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# NETWORK ADAPTER SECURITY
# ============================================================================
Write-Section "Network Adapter Security"

# Check for enabled network adapters
try {
    $adapters = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Up" }
    Register-Check -Name "Active Network Adapters" -Status INFO -Message "$($adapters.Count) adapter(s)"

    # Check for potentially risky adapters
    $riskyAdapters = $adapters | Where-Object {
        $_.InterfaceDescription -match "VMware|VirtualBox|Hyper-V|TAP|VPN|Tunnel"
    }
    if ($riskyAdapters) {
        Register-Check -Name "Virtual/VPN Adapters" -Status INFO -Message "$($riskyAdapters.Count) detected"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Promiscuous mode detection
try {
    Get-NetAdapter -ErrorAction SilentlyContinue | ForEach-Object {
        Get-NetAdapterBinding -Name $_.Name -ComponentID "ms_pacer" -ErrorAction SilentlyContinue | Out-Null
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# FIREWALL PROFILES
# ============================================================================
Write-Section "Firewall Profile Status"

try {
    $fwProfiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue
    foreach ($fwProfile in $fwProfiles) {
        if ($fwProfile.Enabled) {
            Register-Check -Name "Firewall: $($fwProfile.Name)" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Firewall: $($fwProfile.Name)" -Status FAIL -Message "Disabled"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
