# Check NTFS Permissions on System Directories
Import-Module "$PSScriptRoot/common-audit.psm1"
$dirs = @("C:\Windows", "C:\Windows\System32")
foreach ($dir in $dirs) {
    try {
        $acl = Get-Acl $dir
        $users = $acl.Access | Where-Object { $_.IdentityReference -match 'Users|Everyone' -and $_.FileSystemRights -match 'Write' }
        if ($users) {
            Register-Check -Name "NTFS Permissions ($dir)" -Status FAIL -Message "$dir is writable by Users/Everyone."
        } else {
            Register-Check -Name "NTFS Permissions ($dir)" -Status PASS -Message "$dir is not writable by Users/Everyone."
        }
    } catch {
        Register-Check -Name "NTFS Permissions ($dir)" -Status WARN -Message $_.Exception.Message
    }
}
Print-Summary
Exit-Audit