# NTLM Restrictions Security Audit Script (PowerShell)
# Comprehensive NTLM hardening checks per CIS and Microsoft best practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows Benchmark: 2.3.11.x (Network Security)
# - Microsoft NTLM Audit: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/network-security-restrict-ntlm

Import-Module "$PSScriptRoot/common-audit.psm1"

$lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$msvPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0"
$ntlmPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"

# ============================================================================
# LAN MANAGER AUTHENTICATION LEVEL
# ============================================================================
Write-Section "LAN Manager Authentication Level"

# CIS 2.3.11.7 - LM Authentication Level
try {
    $lmLevel = Get-ItemProperty -Path $lsaPath -Name "LmCompatibilityLevel" -ErrorAction Stop
    $level = $lmLevel.LmCompatibilityLevel

    $levelDescriptions = @{
        0 = "Send LM & NTLM responses"
        1 = "Send LM & NTLM - use NTLMv2 if negotiated"
        2 = "Send NTLM response only"
        3 = "Send NTLMv2 response only"
        4 = "Send NTLMv2, refuse LM"
        5 = "Send NTLMv2, refuse LM & NTLM"
    }

    $desc = if ($levelDescriptions.ContainsKey([int]$level)) { $levelDescriptions[[int]$level] } else { "Unknown" }

    if ($level -ge 5) {
        Register-Check -Name "LM Compatibility Level" -Status PASS -Message "Level ${level}: $desc"
    } elseif ($level -ge 3) {
        Register-Check -Name "LM Compatibility Level" -Status WARN -Message "Level ${level}: $desc (recommend 5)"
    } else {
        Register-Check -Name "LM Compatibility Level" -Status FAIL -Message "Level ${level}: $desc - weak authentication"
    }
} catch {
    Register-Check -Name "LM Compatibility Level" -Status WARN -Message "Not configured (default: 3)"
}

# LM Hash Storage - CIS 2.3.11.5
try {
    $noLMHash = Get-ItemProperty -Path $lsaPath -Name "NoLMHash" -ErrorAction Stop
    if ($noLMHash.NoLMHash -eq 1) {
        Register-Check -Name "LM Hash Storage" -Status PASS -Message "Disabled - no LM hashes stored"
    } else {
        Register-Check -Name "LM Hash Storage" -Status FAIL -Message "LM hashes stored - crack vulnerable"
    }
} catch {
    Register-Check -Name "LM Hash Storage" -Status INFO -Message "Not explicitly set"
}

# ============================================================================
# NTLM SSP SESSION SECURITY
# ============================================================================
Write-Section "NTLM SSP Session Security"

# Minimum client security - CIS 2.3.11.8
try {
    $clientSec = Get-ItemProperty -Path $msvPath -Name "NTLMMinClientSec" -ErrorAction Stop
    $val = $clientSec.NTLMMinClientSec

    $flags = @()
    if ($val -band 0x00000010) { $flags += "Message Integrity" }
    if ($val -band 0x00000020) { $flags += "Message Confidentiality" }
    if ($val -band 0x00080000) { $flags += "NTLMv2 Session" }
    if ($val -band 0x20000000) { $flags += "128-bit Encryption" }

    # CIS recommends 537395200 (0x20080000) = NTLMv2 + 128-bit
    if ($val -ge 537395200) {
        Register-Check -Name "NTLM Client Min Security" -Status PASS -Message "NTLMv2 + 128-bit required"
    } elseif ($val -band 0x00080000) {
        Register-Check -Name "NTLM Client Min Security" -Status WARN -Message "NTLMv2 but weaker encryption"
    } else {
        Register-Check -Name "NTLM Client Min Security" -Status FAIL -Message "Weak session security: $($flags -join ', ')"
    }
} catch {
    Register-Check -Name "NTLM Client Min Security" -Status WARN -Message "Not configured"
}

# Minimum server security - CIS 2.3.11.9
try {
    $serverSec = Get-ItemProperty -Path $msvPath -Name "NTLMMinServerSec" -ErrorAction Stop
    $val = $serverSec.NTLMMinServerSec

    if ($val -ge 537395200) {
        Register-Check -Name "NTLM Server Min Security" -Status PASS -Message "NTLMv2 + 128-bit required"
    } elseif ($val -band 0x00080000) {
        Register-Check -Name "NTLM Server Min Security" -Status WARN -Message "NTLMv2 but weaker encryption"
    } else {
        Register-Check -Name "NTLM Server Min Security" -Status FAIL -Message "Weak session security"
    }
} catch {
    Register-Check -Name "NTLM Server Min Security" -Status WARN -Message "Not configured"
}

# ============================================================================
# NTLM RESTRICTION POLICIES
# ============================================================================
Write-Section "NTLM Restriction Policies"

$sysNtlm = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0"

# Restrict NTLM: Incoming NTLM traffic
try {
    $inbound = Get-ItemProperty -Path $sysNtlm -Name "RestrictReceivingNTLMTraffic" -ErrorAction Stop
    $val = $inbound.RestrictReceivingNTLMTraffic

    $levels = @{
        0 = "Allow all"
        1 = "Deny all domain accounts"
        2 = "Deny all accounts"
    }

    if ($val -ge 1) {
        Register-Check -Name "Restrict Inbound NTLM" -Status PASS -Message ($levels[$val] ?? "Unknown")
    } else {
        Register-Check -Name "Restrict Inbound NTLM" -Status WARN -Message "All NTLM allowed"
    }
} catch {
    Register-Check -Name "Restrict Inbound NTLM" -Status INFO -Message "Not configured (default: allow)"
}

# Restrict NTLM: Outgoing NTLM traffic to remote servers
try {
    $outbound = Get-ItemProperty -Path $sysNtlm -Name "RestrictSendingNTLMTraffic" -ErrorAction Stop
    $val = $outbound.RestrictSendingNTLMTraffic

    $levels = @{
        0 = "Allow all"
        1 = "Audit all"
        2 = "Deny all"
    }

    if ($val -ge 2) {
        Register-Check -Name "Restrict Outbound NTLM" -Status PASS -Message "Denied"
    } elseif ($val -eq 1) {
        Register-Check -Name "Restrict Outbound NTLM" -Status WARN -Message "Audit only"
    } else {
        Register-Check -Name "Restrict Outbound NTLM" -Status INFO -Message "All NTLM allowed"
    }
} catch {
    Register-Check -Name "Restrict Outbound NTLM" -Status INFO -Message "Not configured"
}

# Restrict NTLM: NTLM authentication in this domain
try {
    $restrictDomain = Get-ItemProperty -Path $sysNtlm -Name "RestrictNTLMInDomain" -ErrorAction SilentlyContinue

    if ($restrictDomain.RestrictNTLMInDomain -ge 1) {
        Register-Check -Name "Domain NTLM Restriction" -Status PASS -Message "Restricted (Level $($restrictDomain.RestrictNTLMInDomain))"
    } else {
        Register-Check -Name "Domain NTLM Restriction" -Status INFO -Message "Not restricted in domain"
    }
} catch {
    Register-Check -Name "Domain NTLM Restriction" -Status INFO -Message "Not configured"
}

# ============================================================================
# NTLM AUDITING
# ============================================================================
Write-Section "NTLM Auditing"

# Audit incoming NTLM traffic
try {
    $auditNtlm = Get-ItemProperty -Path $sysNtlm -Name "AuditReceivingNTLMTraffic" -ErrorAction Stop
    if ($auditNtlm.AuditReceivingNTLMTraffic -ge 1) {
        Register-Check -Name "Audit Incoming NTLM" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Audit Incoming NTLM" -Status WARN -Message "Disabled"
    }
} catch {
    Register-Check -Name "Audit Incoming NTLM" -Status WARN -Message "Not configured"
}

# Audit outgoing NTLM to remote servers
try {
    $auditOut = Get-ItemProperty -Path $msvPath -Name "AuditExceptionList" -ErrorAction SilentlyContinue
    if ($auditOut -and $auditOut.AuditExceptionList) {
        Register-Check -Name "NTLM Audit Exceptions" -Status INFO -Message "Exception list configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for NTLM audit events in security log
try {
    $ntlmEvents = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=@(4776,8001,8002,8003,8004)} -MaxEvents 1 -ErrorAction SilentlyContinue
    if ($ntlmEvents) {
        Register-Check -Name "NTLM Audit Events" -Status PASS -Message "NTLM authentication being logged"
    } else {
        Register-Check -Name "NTLM Audit Events" -Status INFO -Message "No recent NTLM events found"
    }
} catch {
    Register-Check -Name "NTLM Audit Events" -Status INFO -Message "Cannot query event log"
}

# ============================================================================
# NULL SESSION & ANONYMOUS ACCESS
# ============================================================================
Write-Section "NULL Session and Anonymous Access"

# Allow LocalSystem NULL session fallback
try {
    $nullFallback = Get-ItemProperty -Path $msvPath -Name "AllowNullSessionFallback" -ErrorAction Stop
    if ($nullFallback.AllowNullSessionFallback -eq 0) {
        Register-Check -Name "NULL Session Fallback" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "NULL Session Fallback" -Status FAIL -Message "Enabled - security risk"
    }
} catch {
    Register-Check -Name "NULL Session Fallback" -Status PASS -Message "Not configured (default: disabled)"
}

# Restrict anonymous SAM enumeration
try {
    $restrictSam = Get-ItemProperty -Path $lsaPath -Name "RestrictAnonymousSAM" -ErrorAction Stop
    if ($restrictSam.RestrictAnonymousSAM -eq 1) {
        Register-Check -Name "Anonymous SAM Enum" -Status PASS -Message "Restricted"
    } else {
        Register-Check -Name "Anonymous SAM Enum" -Status FAIL -Message "Allowed"
    }
} catch {
    Register-Check -Name "Anonymous SAM Enum" -Status WARN -Message "Not configured"
}

# Restrict anonymous access (level 1 or 2)
try {
    $restrictAnon = Get-ItemProperty -Path $lsaPath -Name "RestrictAnonymous" -ErrorAction Stop
    if ($restrictAnon.RestrictAnonymous -ge 1) {
        Register-Check -Name "Anonymous Access Level" -Status PASS -Message "Restricted (Level $($restrictAnon.RestrictAnonymous))"
    } else {
        Register-Check -Name "Anonymous Access Level" -Status FAIL -Message "Not restricted"
    }
} catch {
    Register-Check -Name "Anonymous Access Level" -Status WARN -Message "Not configured"
}

# ============================================================================
# NETLOGON SECURE CHANNEL
# ============================================================================
Write-Section "Netlogon Secure Channel"

# Require secure channel signing
try {
    $signChannel = Get-ItemProperty -Path $ntlmPath -Name "RequireSignOrSeal" -ErrorAction Stop
    if ($signChannel.RequireSignOrSeal -eq 1) {
        Register-Check -Name "Secure Channel Sign/Seal" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "Secure Channel Sign/Seal" -Status FAIL -Message "Not required"
    }
} catch {
    Register-Check -Name "Secure Channel Sign/Seal" -Status WARN -Message "Not configured"
}

# Require strong key
try {
    $strongKey = Get-ItemProperty -Path $ntlmPath -Name "RequireStrongKey" -ErrorAction Stop
    if ($strongKey.RequireStrongKey -eq 1) {
        Register-Check -Name "Strong Session Key" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "Strong Session Key" -Status FAIL -Message "Not required"
    }
} catch {
    Register-Check -Name "Strong Session Key" -Status WARN -Message "Not configured"
}

# ============================================================================
# PASS-THE-HASH MITIGATIONS
# ============================================================================
Write-Section "Pass-the-Hash Mitigations"

# WDigest caching (should be disabled for PTH protection)
try {
    $wdigest = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -ErrorAction SilentlyContinue
    if ($null -eq $wdigest -or $wdigest.UseLogonCredential -eq 0) {
        Register-Check -Name "WDigest Caching" -Status PASS -Message "Disabled - PTH mitigated"
    } else {
        Register-Check -Name "WDigest Caching" -Status FAIL -Message "Enabled - plaintext credentials in memory"
    }
} catch {
    Register-Check -Name "WDigest Caching" -Status PASS -Message "Not configured (default: disabled on Win8+)"
}

# Credential caching - CachedLogonsCount
try {
    $cached = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "CachedLogonsCount" -ErrorAction Stop
    $count = [int]$cached.CachedLogonsCount
    if ($count -le 2) {
        Register-Check -Name "Cached Logons" -Status PASS -Message "$count cached (minimal)"
    } elseif ($count -le 4) {
        Register-Check -Name "Cached Logons" -Status WARN -Message "$count cached (recommend 2 or less)"
    } else {
        Register-Check -Name "Cached Logons" -Status FAIL -Message "$count cached - high credential exposure"
    }
} catch {
    Register-Check -Name "Cached Logons" -Status INFO -Message "Using default (10)"
}

# TokenLeakDetectDelaySecs (Credential Guard related)
try {
    $tokenLeak = Get-ItemProperty -Path $lsaPath -Name "TokenLeakDetectDelaySecs" -ErrorAction SilentlyContinue
    if ($tokenLeak.TokenLeakDetectDelaySecs -gt 0) {
        Register-Check -Name "Token Leak Detection" -Status PASS -Message "Configured ($($tokenLeak.TokenLeakDetectDelaySecs)s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# RunAsPPL (LSA Protection)
try {
    $runAsPPL = Get-ItemProperty -Path $lsaPath -Name "RunAsPPL" -ErrorAction Stop
    if ($runAsPPL.RunAsPPL -eq 1) {
        Register-Check -Name "LSA Protection (PPL)" -Status PASS -Message "Enabled - blocks credential dumping"
    } else {
        Register-Check -Name "LSA Protection (PPL)" -Status WARN -Message "Disabled"
    }
} catch {
    Register-Check -Name "LSA Protection (PPL)" -Status WARN -Message "Not configured"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
