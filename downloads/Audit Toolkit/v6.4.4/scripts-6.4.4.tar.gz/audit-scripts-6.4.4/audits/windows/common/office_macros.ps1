# Check Office Macros Policy
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKCU:\Software\Microsoft\Office\16.0\Word\Security" -Name "VBAWarnings" -ErrorAction SilentlyContinue
    if ($reg.VBAWarnings -eq 4) {
        Register-Check -Name "Office Macros" -Status PASS -Message "Office macros are blocked."
    } else {
        Register-Check -Name "Office Macros" -Status FAIL -Message "Office macros are not blocked."
    }
} catch {
    Register-Check -Name "Office Macros" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit