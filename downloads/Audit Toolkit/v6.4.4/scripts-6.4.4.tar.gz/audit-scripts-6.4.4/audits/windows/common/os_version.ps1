# Windows OS Version Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Operating System Version
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: https://www.cisecurity.org/benchmark/windows_11
# - Microsoft Lifecycle: https://learn.microsoft.com/en-us/lifecycle/products/

Import-Module "$PSScriptRoot/common-audit.psm1"

try {
    $os = Get-CimInstance Win32_OperatingSystem
    $caption = $os.Caption
    $build = $os.BuildNumber
    Register-Check -Name "OS Version" -Status PASS -Message "Detected: $caption (Build $build)"

    # Check for supported versions (Windows 10 21H2+, Windows 11, Server 2019+)
    # Build numbers: 19044+ (Win10 21H2), 22000+ (Win11), 17763+ (Server 2019), 20348+ (Server 2022)
    $buildNum = [int]$build
    $isSupported = $false
    $isServer = $caption -match "Server"

    if ($isServer) {
        # Server 2019 = 17763, Server 2022 = 20348
        if ($buildNum -ge 17763) {
            $isSupported = $true
            Register-Check -Name "OS Support Status" -Status PASS -Message "Server OS is supported (Build $buildNum)"
        }
    } else {
        # Windows 10 21H2+ = 19044+, Windows 11 = 22000+
        if ($buildNum -ge 19044) {
            $isSupported = $true
            Register-Check -Name "OS Support Status" -Status PASS -Message "Desktop OS is supported (Build $buildNum)"
        }
    }

    if (-not $isSupported) {
        Register-Check -Name "OS Support Status" -Status FAIL -Message "OS build $buildNum may be unsupported - check Microsoft Lifecycle"
    }

    # Check if latest feature update
    if ($buildNum -lt 22631 -and -not $isServer) {
        Register-Check -Name "OS Update Status" -Status WARN -Message "Consider updating to Windows 11 23H2 (Build 22631+) for latest security"
    }
} catch {
    Register-Check -Name "OS Version" -Status WARN -Message "Could not determine OS version: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit