# Password Policy Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Account Policies / Password Policy
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 1.1.x
# - Microsoft Password Policy: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/password-policy

Import-Module "$PSScriptRoot/common-audit.psm1"

try {
    # Export security policy to temp file
    $tempFile = "$env:TEMP\secpol_export.txt"
    & secedit /export /cfg $tempFile /quiet 2>&1 | Out-Null

    if (-not (Test-Path $tempFile)) {
        Register-Check -Name "Password Policy Access" -Status WARN -Message "Requires elevated privileges to read security policy"
        Print-Summary
        Exit-Audit
    }

    $secpol = Get-Content $tempFile -Raw
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue

    # CIS 1.1.1 - Password History (Recommended: 24)
    if ($secpol -match 'PasswordHistorySize\s*=\s*(\d+)') {
        $histSize = [int]$matches[1]
        if ($histSize -ge 24) {
            Register-Check -Name "Password History" -Status PASS -Message "Password history is $histSize (CIS: 24+)"
        } else {
            Register-Check -Name "Password History" -Status FAIL -Message "Password history is $histSize (CIS requires 24+)"
        }
    } else {
        Register-Check -Name "Password History" -Status WARN -Message "Could not determine password history setting"
    }

    # CIS 1.1.2 - Maximum Password Age (Recommended: 365 or less, but not 0)
    if ($secpol -match 'MaximumPasswordAge\s*=\s*(\d+)') {
        $maxAge = [int]$matches[1]
        if ($maxAge -gt 0 -and $maxAge -le 365) {
            Register-Check -Name "Maximum Password Age" -Status PASS -Message "Max password age is $maxAge days"
        } elseif ($maxAge -eq 0) {
            Register-Check -Name "Maximum Password Age" -Status FAIL -Message "Password never expires (not recommended)"
        } else {
            Register-Check -Name "Maximum Password Age" -Status WARN -Message "Max password age is $maxAge days (CIS: 365 or less)"
        }
    }

    # CIS 1.1.3 - Minimum Password Age (Recommended: 1+ day)
    if ($secpol -match 'MinimumPasswordAge\s*=\s*(\d+)') {
        $minAge = [int]$matches[1]
        if ($minAge -ge 1) {
            Register-Check -Name "Minimum Password Age" -Status PASS -Message "Min password age is $minAge days"
        } else {
            Register-Check -Name "Minimum Password Age" -Status FAIL -Message "Min password age is $minAge days (CIS requires 1+)"
        }
    }

    # CIS 1.1.4 - Minimum Password Length (Recommended: 14+)
    if ($secpol -match 'MinimumPasswordLength\s*=\s*(\d+)') {
        $minLen = [int]$matches[1]
        if ($minLen -ge 14) {
            Register-Check -Name "Minimum Password Length" -Status PASS -Message "Min password length is $minLen characters"
        } elseif ($minLen -ge 8) {
            Register-Check -Name "Minimum Password Length" -Status WARN -Message "Min length is $minLen (CIS recommends 14+)"
        } else {
            Register-Check -Name "Minimum Password Length" -Status FAIL -Message "Min length is $minLen (CIS requires 14+)"
        }
    }

    # CIS 1.1.5 - Password Complexity (Recommended: Enabled)
    if ($secpol -match 'PasswordComplexity\s*=\s*(\d+)') {
        $complexity = [int]$matches[1]
        if ($complexity -eq 1) {
            Register-Check -Name "Password Complexity" -Status PASS -Message "Password complexity is enabled"
        } else {
            Register-Check -Name "Password Complexity" -Status FAIL -Message "Password complexity is disabled"
        }
    }

    # CIS 1.1.6 - Reversible Encryption (Recommended: Disabled)
    if ($secpol -match 'ClearTextPassword\s*=\s*(\d+)') {
        $reversible = [int]$matches[1]
        if ($reversible -eq 0) {
            Register-Check -Name "Reversible Encryption" -Status PASS -Message "Reversible encryption is disabled"
        } else {
            Register-Check -Name "Reversible Encryption" -Status FAIL -Message "Reversible encryption is enabled (security risk)"
        }
    }

} catch {
    Register-Check -Name "Password Policy" -Status WARN -Message "Could not check password policy: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit
