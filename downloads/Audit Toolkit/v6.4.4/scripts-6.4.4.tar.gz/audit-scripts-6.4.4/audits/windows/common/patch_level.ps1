# Check Windows Patch Level
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $hotfixes = Get-HotFix | Sort-Object -Property InstalledOn -Descending
    if ($hotfixes) {
        Register-Check -Name "Patch Level" -Status PASS -Message "Latest patch: $($hotfixes[0].Description) $($hotfixes[0].HotFixID) Installed: $($hotfixes[0].InstalledOn)"
    } else {
        Register-Check -Name "Patch Level" -Status FAIL -Message "No patches found. System may be unpatched."
    }
} catch {
    Register-Check -Name "Patch Level" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit