<#
.SYNOPSIS
    PowerShell Security and Logging Audit

.DESCRIPTION
    Comprehensive PowerShell security audit covering:
    - Script Block Logging (CIS 18.9.100.1)
    - Module Logging (CIS 18.9.100.2)
    - Transcription (CIS 18.9.100.3)
    - AMSI (Antimalware Scan Interface)
    - Protected Event Logging
    - Constrained Language Mode
    - Downgrade Attack Prevention
    - Event Log Configuration

.NOTES
    CIS Windows 11 Benchmark: 18.9.100.x
    MITRE ATT&CK: T1059.001 (PowerShell)

Compliance Mapping:
- CIS Controls: 8.8 (Log Command Execution)
- NIST SP 800-53: AU-3 (Content of Audit Records), SI-4 (System Monitoring)
- ISO 27001: A.12.4.1 (Event Logging)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "PowerShell Security Audit"

# ============================================================================
# SCRIPT BLOCK LOGGING - CIS 18.9.100.1
# ============================================================================
Write-Section "Script Block Logging"

try {
    $sblPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging"
    $sbl = Get-ItemProperty -Path $sblPath -ErrorAction SilentlyContinue

    if ($sbl.EnableScriptBlockLogging -eq 1) {
        Register-Check -Name "Script Block Logging" -Status PASS -Message "Enabled"

        # Check invocation logging (logs when blocks are invoked, not just first load)
        if ($sbl.EnableScriptBlockInvocationLogging -eq 1) {
            Register-Check -Name "SBL Invocation Logging" -Status PASS -Message "Full invocation logging enabled"
        } else {
            Register-Check -Name "SBL Invocation Logging" -Status WARN -Message "Only first execution logged (default)"
        }
    } else {
        Register-Check -Name "Script Block Logging" -Status FAIL -Message "Not enabled - critical for threat detection"
    }
} catch {
    Register-Check -Name "Script Block Logging" -Status FAIL -Message "Not configured via policy"
}

# ============================================================================
# MODULE LOGGING - CIS 18.9.100.2
# ============================================================================
Write-Section "Module Logging"

try {
    $mlPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging"
    $ml = Get-ItemProperty -Path $mlPath -ErrorAction SilentlyContinue

    if ($ml.EnableModuleLogging -eq 1) {
        Register-Check -Name "Module Logging" -Status PASS -Message "Enabled"

        # Check which modules are logged
        $modulesPath = "$mlPath\ModuleNames"
        if (Test-Path $modulesPath) {
            $modules = Get-ItemProperty -Path $modulesPath -ErrorAction SilentlyContinue
            $loggedModules = $modules.PSObject.Properties | Where-Object { $_.Name -ne "PSPath" -and $_.Name -ne "PSParentPath" }

            if ($loggedModules | Where-Object { $_.Name -eq "*" }) {
                Register-Check -Name "Module Log Scope" -Status PASS -Message "All modules logged (*)"
            } else {
                $count = @($loggedModules).Count
                Register-Check -Name "Module Log Scope" -Status WARN -Message "$count specific modules - consider logging all (*)"
            }
        }
    } else {
        Register-Check -Name "Module Logging" -Status WARN -Message "Not enabled - consider for audit trails"
    }
} catch {
    Register-Check -Name "Module Logging" -Status WARN -Message "Not configured"
}

# ============================================================================
# TRANSCRIPTION - CIS 18.9.100.3
# ============================================================================
Write-Section "PowerShell Transcription"

try {
    $transPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription"
    $trans = Get-ItemProperty -Path $transPath -ErrorAction SilentlyContinue

    if ($trans.EnableTranscripting -eq 1) {
        Register-Check -Name "Transcription" -Status PASS -Message "Enabled"

        # Check output directory
        if ($trans.OutputDirectory) {
            $outDir = $trans.OutputDirectory
            if (Test-Path $outDir) {
                Register-Check -Name "Transcript Directory" -Status PASS -Message "$outDir exists"

                # Check ACL on transcript dir
                $acl = Get-Acl $outDir -ErrorAction SilentlyContinue
                $hasEveryone = $acl.Access | Where-Object { $_.IdentityReference -match "Everyone" -and $_.FileSystemRights -match "Write|FullControl" }
                if ($hasEveryone) {
                    Register-Check -Name "Transcript Dir Security" -Status FAIL -Message "Everyone has write access"
                } else {
                    Register-Check -Name "Transcript Dir Security" -Status PASS -Message "Restricted permissions"
                }
            } else {
                Register-Check -Name "Transcript Directory" -Status WARN -Message "Directory not found: $outDir"
            }
        } else {
            Register-Check -Name "Transcript Directory" -Status WARN -Message "Using default user profile location"
        }

        # Include invocation headers
        if ($trans.EnableInvocationHeader -eq 1) {
            Register-Check -Name "Invocation Headers" -Status PASS -Message "Command timestamps included"
        }
    } else {
        Register-Check -Name "Transcription" -Status WARN -Message "Not enabled - valuable for forensics"
    }
} catch {
    Register-Check -Name "Transcription" -Status WARN -Message "Not configured"
}

# ============================================================================
# AMSI (Antimalware Scan Interface)
# ============================================================================
Write-Section "AMSI (Antimalware Scan Interface)"

# Check AMSI provider registration
try {
    $amsiProvPath = "HKLM:\SOFTWARE\Microsoft\AMSI\Providers"
    if (Test-Path $amsiProvPath) {
        $providers = Get-ChildItem $amsiProvPath -ErrorAction SilentlyContinue
        $provCount = @($providers).Count

        if ($provCount -gt 0) {
            Register-Check -Name "AMSI Providers" -Status PASS -Message "$provCount provider(s) registered"

            # Check for known providers
            foreach ($prov in $providers) {
                try {
                    $clsid = $prov.PSChildName
                    $provInfo = Get-ItemProperty "HKLM:\SOFTWARE\Classes\CLSID\$clsid" -ErrorAction SilentlyContinue
                    if ($provInfo."(default)") {
                        Write-Output "    Provider: $($provInfo.'(default)')"
                    }
                } catch { Write-Verbose 'Suppressed non-fatal error.' }
            }
        } else {
            Register-Check -Name "AMSI Providers" -Status WARN -Message "No providers registered"
        }
    } else {
        Register-Check -Name "AMSI Providers" -Status WARN -Message "AMSI path not found"
    }
} catch {
    Register-Check -Name "AMSI Providers" -Status SKIP -Message "Cannot query"
}

# Check AMSI DLL integrity
try {
    $amsiDll = "$env:SystemRoot\System32\amsi.dll"
    if (Test-Path $amsiDll) {
        $sig = Get-AuthenticodeSignature $amsiDll -ErrorAction SilentlyContinue
        if ($sig.Status -eq "Valid") {
            Register-Check -Name "AMSI DLL" -Status PASS -Message "amsi.dll signed and valid"
        } else {
            Register-Check -Name "AMSI DLL" -Status FAIL -Message "Invalid signature - potential tampering"
        }
    } else {
        Register-Check -Name "AMSI DLL" -Status FAIL -Message "amsi.dll not found"
    }
} catch {
    Register-Check -Name "AMSI DLL" -Status SKIP -Message "Cannot verify"
}

# ============================================================================
# PROTECTED EVENT LOGGING (PEL)
# ============================================================================
Write-Section "Protected Event Logging"

try {
    $pelPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\ProtectedEventLogging"
    $pel = Get-ItemProperty -Path $pelPath -ErrorAction SilentlyContinue

    if ($pel.EnableProtectedEventLogging -eq 1) {
        Register-Check -Name "Protected Event Logging" -Status PASS -Message "Enabled"

        if ($pel.EncryptionCertificate) {
            Register-Check -Name "PEL Certificate" -Status PASS -Message "Certificate configured"
        } else {
            Register-Check -Name "PEL Certificate" -Status WARN -Message "No certificate specified"
        }
    } else {
        Register-Check -Name "Protected Event Logging" -Status WARN -Message "Not enabled - logs script content in clear text"
    }
} catch {
    Register-Check -Name "Protected Event Logging" -Status WARN -Message "Not configured (Windows 10+)"
}

# ============================================================================
# CONSTRAINED LANGUAGE MODE
# ============================================================================
Write-Section "Constrained Language Mode"

# Current session mode
$currentMode = $ExecutionContext.SessionState.LanguageMode
if ($currentMode -eq 'ConstrainedLanguage') {
    Register-Check -Name "Current Language Mode" -Status PASS -Message "Constrained Language Mode"
} else {
    Register-Check -Name "Current Language Mode" -Status WARN -Message "$currentMode - consider CLM on sensitive systems"
}

# System-wide lockdown policy
try {
    $lockdownPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
    $lockdown = Get-ItemProperty $lockdownPath -Name "__PSLockdownPolicy" -ErrorAction SilentlyContinue

    if ($lockdown.__PSLockdownPolicy) {
        $policy = $lockdown.__PSLockdownPolicy
        switch ($policy) {
            8 { Register-Check -Name "System Lockdown Policy" -Status PASS -Message "Constrained Language enforced" }
            4 { Register-Check -Name "System Lockdown Policy" -Status WARN -Message "Full Language Mode" }
            default { Register-Check -Name "System Lockdown Policy" -Status WARN -Message "Policy value: $policy" }
        }
    } else {
        Register-Check -Name "System Lockdown Policy" -Status SKIP -Message "Not set (WDAC/AppLocker can enforce CLM)"
    }
} catch {
    Register-Check -Name "System Lockdown Policy" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# DOWNGRADE ATTACK PREVENTION
# ============================================================================
Write-Section "Downgrade Attack Prevention"

# Check PowerShell 2.0 (disable for security)
try {
    $ps2Feature = Get-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2Root -ErrorAction SilentlyContinue
    if ($ps2Feature) {
        if ($ps2Feature.State -eq "Disabled") {
            Register-Check -Name "PowerShell 2.0" -Status PASS -Message "Disabled (prevents downgrade attacks)"
        } else {
            Register-Check -Name "PowerShell 2.0" -Status FAIL -Message "Enabled - disable to prevent logging bypass"
        }
    }
} catch {
    # Try server feature detection
    try {
        $ps2Role = Get-WindowsFeature -Name PowerShell-V2 -ErrorAction SilentlyContinue
        if ($ps2Role) {
            if ($ps2Role.Installed) {
                Register-Check -Name "PowerShell 2.0" -Status FAIL -Message "Installed - remove to prevent bypass"
            } else {
                Register-Check -Name "PowerShell 2.0" -Status PASS -Message "Not installed"
            }
        }
    } catch {
        # Check for powershell.exe -version 2 capability
        Test-Path "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" | Out-Null
        Register-Check -Name "PowerShell 2.0" -Status WARN -Message "Cannot determine - check manually"
    }
}

# Check current PowerShell version
$psVersion = $PSVersionTable.PSVersion
if ($psVersion.Major -ge 5) {
    Register-Check -Name "PowerShell Version" -Status PASS -Message "$($psVersion.Major).$($psVersion.Minor)"
} else {
    Register-Check -Name "PowerShell Version" -Status WARN -Message "$($psVersion.Major).$($psVersion.Minor) - upgrade recommended"
}

# ============================================================================
# EVENT LOG CONFIGURATION
# ============================================================================
Write-Section "PowerShell Event Log"

# Check PowerShell/Operational log
try {
    $logName = "Microsoft-Windows-PowerShell/Operational"
    $logConfig = Get-WinEvent -ListLog $logName -ErrorAction SilentlyContinue

    if ($logConfig) {
        # Log enabled
        if ($logConfig.IsEnabled) {
            Register-Check -Name "PS Operational Log" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "PS Operational Log" -Status FAIL -Message "Disabled"
        }

        # Log size (should be adequate for retention)
        $sizeMB = [math]::Round($logConfig.MaximumSizeInBytes / 1MB, 0)
        if ($sizeMB -ge 50) {
            Register-Check -Name "PS Log Size" -Status PASS -Message "$sizeMB MB"
        } elseif ($sizeMB -ge 20) {
            Register-Check -Name "PS Log Size" -Status WARN -Message "$sizeMB MB - consider increasing for retention"
        } else {
            Register-Check -Name "PS Log Size" -Status WARN -Message "$sizeMB MB - too small for enterprise"
        }

        # Log mode
        if ($logConfig.LogMode -eq "Circular") {
            Register-Check -Name "PS Log Mode" -Status WARN -Message "Circular - oldest events overwritten"
        } else {
            Register-Check -Name "PS Log Mode" -Status PASS -Message "$($logConfig.LogMode)"
        }
    }
} catch {
    Register-Check -Name "PS Operational Log" -Status SKIP -Message "Cannot query"
}

# Check for recent script block events
try {
    $recentEvents = Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 10 -ErrorAction SilentlyContinue |
        Where-Object { $_.Id -eq 4104 }  # Script Block Logging event ID

    if ($recentEvents) {
        Register-Check -Name "SBL Events" -Status PASS -Message "Script block events present in log"
    } else {
        Register-Check -Name "SBL Events" -Status WARN -Message "No recent script block events"
    }
} catch {
    Register-Check -Name "SBL Events" -Status SKIP -Message "Cannot query events"
}

# ============================================================================
# EXECUTION POLICY
# ============================================================================
Write-Section "Execution Policy"

try {
    $machinePolicy = Get-ExecutionPolicy -Scope MachinePolicy -ErrorAction SilentlyContinue
    Get-ExecutionPolicy -Scope UserPolicy -ErrorAction SilentlyContinue | Out-Null
    $currentPolicy = Get-ExecutionPolicy -ErrorAction SilentlyContinue

    # Machine policy (GPO)
    if ($machinePolicy -and $machinePolicy -ne "Undefined") {
        if ($machinePolicy -eq "Unrestricted" -or $machinePolicy -eq "Bypass") {
            Register-Check -Name "Machine Execution Policy" -Status WARN -Message "$machinePolicy (GPO) - consider tightening"
        } else {
            Register-Check -Name "Machine Execution Policy" -Status PASS -Message "$machinePolicy (GPO enforced)"
        }
    }

    # Current effective policy
    if ($currentPolicy -eq "Unrestricted" -or $currentPolicy -eq "Bypass") {
        Register-Check -Name "Effective Execution Policy" -Status WARN -Message "$currentPolicy - scripts can run freely"
    } elseif ($currentPolicy -eq "AllSigned") {
        Register-Check -Name "Effective Execution Policy" -Status PASS -Message "AllSigned - only signed scripts"
    } else {
        Register-Check -Name "Effective Execution Policy" -Status PASS -Message "$currentPolicy"
    }
} catch {
    Register-Check -Name "Execution Policy" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
