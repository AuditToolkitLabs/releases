# Print Spooler Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - System Services
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 5.34
# - PrintNightmare CVE: https://msrc.microsoft.com/update-guide/vulnerability/CVE-2021-34527
# - Microsoft Guidance: https://learn.microsoft.com/en-us/troubleshoot/windows-server/printing/print-spooler-security

Import-Module "$PSScriptRoot/common-audit.psm1"

# CIS 5.34 - Print Spooler service (should be disabled on non-print servers)
try {
    $spooler = Get-Service -Name "Spooler" -ErrorAction Stop

    if ($spooler.Status -eq "Running") {
        # Check if this is a server or workstation
        $os = Get-CimInstance -ClassName Win32_OperatingSystem
        $isServer = $os.ProductType -ne 1  # 1 = Workstation, 2/3 = Server

        if ($isServer) {
            Register-Check -Name "Print Spooler Running" -Status WARN -Message "Print Spooler is running on server (disable if not needed)"
        } else {
            Register-Check -Name "Print Spooler Running" -Status WARN -Message "Print Spooler is running (disable if printing not needed)"
        }
    } else {
        Register-Check -Name "Print Spooler Running" -Status PASS -Message "Print Spooler is stopped"
    }

    if ($spooler.StartType -eq "Disabled") {
        Register-Check -Name "Print Spooler Startup" -Status PASS -Message "Print Spooler is disabled"
    } elseif ($spooler.StartType -eq "Manual") {
        Register-Check -Name "Print Spooler Startup" -Status WARN -Message "Print Spooler set to Manual (disable for security)"
    } else {
        Register-Check -Name "Print Spooler Startup" -Status WARN -Message "Print Spooler is set to $($spooler.StartType)"
    }

} catch {
    Register-Check -Name "Print Spooler Service" -Status PASS -Message "Print Spooler service not found"
}

# Check Point and Print restrictions (PrintNightmare mitigations)
try {
    $pnpRestrict = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -ErrorAction SilentlyContinue

    if ($pnpRestrict) {
        # NoWarningNoElevationOnInstall should be 0
        if ($pnpRestrict.NoWarningNoElevationOnInstall -eq 0) {
            Register-Check -Name "Point and Print Warning" -Status PASS -Message "UAC prompt required for Point and Print"
        } else {
            Register-Check -Name "Point and Print Warning" -Status FAIL -Message "Point and Print bypasses UAC (PrintNightmare risk)"
        }

        # NoWarningNoElevationOnUpdate should be 0
        if ($pnpRestrict.NoWarningNoElevationOnUpdate -eq 0) {
            Register-Check -Name "Point and Print Update" -Status PASS -Message "UAC prompt required for driver updates"
        } else {
            Register-Check -Name "Point and Print Update" -Status FAIL -Message "Driver updates bypass UAC"
        }

        # RestrictDriverInstallationToAdministrators should be 1
        if ($pnpRestrict.RestrictDriverInstallationToAdministrators -eq 1) {
            Register-Check -Name "Driver Install Restriction" -Status PASS -Message "Only admins can install print drivers"
        } else {
            Register-Check -Name "Driver Install Restriction" -Status FAIL -Message "Non-admins can install print drivers"
        }
    } else {
        Register-Check -Name "Point and Print Policy" -Status WARN -Message "Point and Print restrictions not configured"
    }

} catch {
    Register-Check -Name "Point and Print Policy" -Status WARN -Message "Could not check Point and Print settings"
}

# Check if remote printing is allowed
try {
    $printSharing = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "RpcAuthnLevelPrivacyEnabled" -ErrorAction SilentlyContinue

    if ($printSharing.RpcAuthnLevelPrivacyEnabled -eq 1) {
        Register-Check -Name "Print RPC Privacy" -Status PASS -Message "RPC authentication privacy enabled"
    } else {
        Register-Check -Name "Print RPC Privacy" -Status WARN -Message "RPC authentication privacy not enabled"
    }
} catch {
    Register-Check -Name "Print RPC Privacy" -Status WARN -Message "Could not check RPC print settings"
}

# Check for shared printers (potential attack surface)
try {
    $sharedPrinters = Get-Printer -Full -ErrorAction SilentlyContinue | Where-Object { $_.Shared -eq $true }

    if ($sharedPrinters) {
        $count = @($sharedPrinters).Count
        Register-Check -Name "Shared Printers" -Status WARN -Message "$count printer(s) shared (review if necessary)"
    } else {
        Register-Check -Name "Shared Printers" -Status PASS -Message "No printers are shared"
    }
} catch {
    Register-Check -Name "Shared Printers" -Status SKIP -Message "Could not enumerate shared printers"
}

Print-Summary
Exit-Audit
