# Check PowerShell Remoting Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $remoting = Get-Item WSMan:\localhost\Shell\MaxConcurrentUsers -ErrorAction SilentlyContinue
    if ($remoting) {
        Register-Check -Name "PowerShell Remoting" -Status WARN -Message "Remoting is enabled. Review policy."
    } else {
        Register-Check -Name "PowerShell Remoting" -Status PASS -Message "Remoting is not enabled."
    }
} catch {
    Register-Check -Name "PowerShell Remoting" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit