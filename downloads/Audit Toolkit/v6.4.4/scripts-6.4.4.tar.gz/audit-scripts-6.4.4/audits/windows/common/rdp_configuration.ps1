# RDP Configuration Security Audit Script (PowerShell)
# Comprehensive CIS Windows Benchmark - Remote Desktop Protocol
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 18.9.65.3.x
# - CIS Windows Server 2022: 18.10.56.x
# - Microsoft RDP Security: https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/security

Import-Module "$PSScriptRoot/common-audit.psm1"

$tsPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server"
$rdpTcpPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
$tsPolicyPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"

# ============================================================================
# RDP STATUS AND ACCESS CONTROL
# ============================================================================
Write-Section "RDP Status and Access Control"

# Check if RDP is enabled
$rdpEnabled = $false
try {
    $reg = Get-ItemProperty -Path $tsPath -Name "fDenyTSConnections" -ErrorAction SilentlyContinue
    if ($reg.fDenyTSConnections -eq 1) {
        Register-Check -Name "RDP Status" -Status PASS -Message "RDP is disabled"
    } else {
        Register-Check -Name "RDP Status" -Status INFO -Message "RDP is enabled"
        $rdpEnabled = $true
    }
} catch {
    Register-Check -Name "RDP Status" -Status WARN -Message "Cannot determine RDP status"
    $rdpEnabled = $true  # Assume enabled for safety
}

# Check RDP service status
try {
    $termService = Get-Service -Name "TermService" -ErrorAction SilentlyContinue
    if ($termService.Status -eq "Running") {
        Register-Check -Name "RDP Service" -Status INFO -Message "Running"
    } else {
        Register-Check -Name "RDP Service" -Status PASS -Message "Not running ($($termService.Status))"
    }
} catch {
    Register-Check -Name "RDP Service" -Status SKIP -Message "Cannot query service"
}

# Check who can connect via RDP
try {
    $rdpGroup = Get-LocalGroupMember -Group "Remote Desktop Users" -ErrorAction SilentlyContinue
    $memberCount = ($rdpGroup | Measure-Object).Count

    if ($memberCount -eq 0) {
        Register-Check -Name "RDP Users Group" -Status PASS -Message "Empty (Admins-only access)"
    } elseif ($memberCount -le 5) {
        Register-Check -Name "RDP Users Group" -Status INFO -Message "$memberCount member(s)"
    } else {
        Register-Check -Name "RDP Users Group" -Status WARN -Message "$memberCount members - review needed"
    }
} catch {
    Register-Check -Name "RDP Users Group" -Status SKIP -Message "Cannot enumerate"
}

# Firewall rule for RDP
try {
    $rdpRules = Get-NetFirewallRule -DisplayName "*Remote Desktop*" -ErrorAction SilentlyContinue |
        Where-Object { $_.Enabled -eq $true -and $_.Direction -eq "Inbound" }

    if ($rdpRules) {
        $anyProfile = $rdpRules | Where-Object { $_.Profile -match "Any|Public" }
        if ($anyProfile) {
            Register-Check -Name "RDP Firewall Rule" -Status WARN -Message "Allowed on Public profile"
        } else {
            Register-Check -Name "RDP Firewall Rule" -Status INFO -Message "Enabled (Domain/Private)"
        }
    } else {
        Register-Check -Name "RDP Firewall Rule" -Status PASS -Message "Not enabled in firewall"
    }
} catch {
    Register-Check -Name "RDP Firewall Rule" -Status SKIP -Message "Cannot check firewall"
}

if (-not $rdpEnabled) {
    Print-Summary
    Exit-Audit
}

# ============================================================================
# AUTHENTICATION SECURITY
# ============================================================================
Write-Section "Authentication Security"

# Network Level Authentication (NLA) - CIS 18.9.65.3.9.1
try {
    $nla = Get-ItemProperty -Path $rdpTcpPath -Name "UserAuthentication" -ErrorAction SilentlyContinue
    if ($nla.UserAuthentication -eq 1) {
        Register-Check -Name "Network Level Authentication" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "Network Level Authentication" -Status FAIL -Message "Not required - credential theft risk"
    }
} catch {
    Register-Check -Name "Network Level Authentication" -Status WARN -Message "Not configured"
}

# NLA via policy
try {
    $nlaPol = Get-ItemProperty -Path $tsPolicyPath -Name "UserAuthentication" -ErrorAction SilentlyContinue
    if ($nlaPol.UserAuthentication -eq 1) {
        Register-Check -Name "NLA Policy" -Status PASS -Message "Enforced via GPO"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Credential delegation (CredSSP)
try {
    $credSSP = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowDefaultCredentials" -ErrorAction SilentlyContinue
    if ($credSSP.AllowDefaultCredentials) {
        Register-Check -Name "Credential Delegation" -Status WARN -Message "Default credentials allowed"
    } else {
        Register-Check -Name "Credential Delegation" -Status PASS -Message "Not allowing default delegation"
    }
} catch {
    Register-Check -Name "Credential Delegation" -Status INFO -Message "Default configuration"
}

# Restricted Admin Mode
try {
    $restrictedAdmin = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "DisableRestrictedAdmin" -ErrorAction SilentlyContinue
    if ($null -eq $restrictedAdmin.DisableRestrictedAdmin -or $restrictedAdmin.DisableRestrictedAdmin -eq 0) {
        Register-Check -Name "Restricted Admin Mode" -Status PASS -Message "Available"
    } else {
        Register-Check -Name "Restricted Admin Mode" -Status WARN -Message "Disabled"
    }
} catch {
    Register-Check -Name "Restricted Admin Mode" -Status INFO -Message "Default (available)"
}

# Remote Credential Guard
try {
    Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "DisableRestrictedAdminOutboundCreds" -ErrorAction SilentlyContinue | Out-Null
    Register-Check -Name "Remote Credential Guard" -Status INFO -Message "Check client-side configuration"
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ENCRYPTION AND SECURITY LAYER
# ============================================================================
Write-Section "Encryption and Security Layer"

# Encryption Level - CIS 18.9.65.3.11.1
try {
    $enc = Get-ItemProperty -Path $rdpTcpPath -Name "MinEncryptionLevel" -ErrorAction SilentlyContinue
    $levels = @{1="Low"; 2="Client Compatible"; 3="High"; 4="FIPS"}
    $levelName = $levels[$enc.MinEncryptionLevel] ?? "Unknown"

    if ($enc.MinEncryptionLevel -ge 3) {
        Register-Check -Name "Encryption Level" -Status PASS -Message "$levelName"
    } elseif ($enc.MinEncryptionLevel -eq 2) {
        Register-Check -Name "Encryption Level" -Status WARN -Message "$levelName (recommend High)"
    } else {
        Register-Check -Name "Encryption Level" -Status FAIL -Message "$levelName - vulnerable"
    }
} catch {
    Register-Check -Name "Encryption Level" -Status WARN -Message "Not configured"
}

# Security Layer - CIS 18.9.65.3.11.2
try {
    $sec = Get-ItemProperty -Path $rdpTcpPath -Name "SecurityLayer" -ErrorAction SilentlyContinue
    $layers = @{0="RDP Security"; 1="Negotiate"; 2="TLS 1.0"}
    $null = $layers[$sec.SecurityLayer] ?? "Unknown"

    if ($sec.SecurityLayer -eq 2) {
        Register-Check -Name "Security Layer" -Status PASS -Message "TLS"
    } elseif ($sec.SecurityLayer -eq 1) {
        Register-Check -Name "Security Layer" -Status WARN -Message "Negotiate (prefer TLS)"
    } else {
        Register-Check -Name "Security Layer" -Status FAIL -Message "RDP native - insecure"
    }
} catch {
    Register-Check -Name "Security Layer" -Status WARN -Message "Not configured"
}

# FIPS compliance mode
try {
    $fips = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" -ErrorAction SilentlyContinue
    if ($fips.Enabled -eq 1) {
        Register-Check -Name "FIPS Mode" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "FIPS Mode" -Status INFO -Message "Not enabled"
    }
} catch {
    Register-Check -Name "FIPS Mode" -Status INFO -Message "Not configured"
}

# RDP Certificate
try {
    $cert = Get-ItemProperty -Path $rdpTcpPath -Name "SSLCertificateSHA1Hash" -ErrorAction SilentlyContinue
    if ($cert.SSLCertificateSHA1Hash) {
        Register-Check -Name "RDP Certificate" -Status PASS -Message "Custom certificate configured"
    } else {
        Register-Check -Name "RDP Certificate" -Status WARN -Message "Using self-signed certificate"
    }
} catch {
    Register-Check -Name "RDP Certificate" -Status WARN -Message "Self-signed (default)"
}

# ============================================================================
# SESSION TIMEOUTS AND LIMITS
# ============================================================================
Write-Section "Session Timeouts and Limits"

# Idle session timeout - CIS 18.9.65.3.10.1
try {
    $idleTimeout = Get-ItemProperty -Path $tsPolicyPath -Name "MaxIdleTime" -ErrorAction SilentlyContinue
    if ($idleTimeout.MaxIdleTime -and $idleTimeout.MaxIdleTime -gt 0) {
        $minutes = $idleTimeout.MaxIdleTime / 60000
        if ($minutes -le 15) {
            Register-Check -Name "Idle Timeout" -Status PASS -Message "$minutes minutes"
        } elseif ($minutes -le 30) {
            Register-Check -Name "Idle Timeout" -Status WARN -Message "$minutes minutes (recommend 15)"
        } else {
            Register-Check -Name "Idle Timeout" -Status FAIL -Message "$minutes minutes (too long)"
        }
    } else {
        Register-Check -Name "Idle Timeout" -Status WARN -Message "Not configured"
    }
} catch {
    Register-Check -Name "Idle Timeout" -Status WARN -Message "Not configured via policy"
}

# Disconnected session timeout - CIS 18.9.65.3.10.2
try {
    $discTimeout = Get-ItemProperty -Path $tsPolicyPath -Name "MaxDisconnectionTime" -ErrorAction SilentlyContinue
    if ($discTimeout.MaxDisconnectionTime -and $discTimeout.MaxDisconnectionTime -gt 0) {
        $minutes = $discTimeout.MaxDisconnectionTime / 60000
        Register-Check -Name "Disconnected Session Limit" -Status PASS -Message "$minutes minutes"
    } else {
        Register-Check -Name "Disconnected Session Limit" -Status WARN -Message "Disconnected sessions persist"
    }
} catch {
    Register-Check -Name "Disconnected Session Limit" -Status WARN -Message "Not configured"
}

# Active session timeout
try {
    $activeLimit = Get-ItemProperty -Path $tsPolicyPath -Name "MaxConnectionTime" -ErrorAction SilentlyContinue
    if ($activeLimit.MaxConnectionTime -and $activeLimit.MaxConnectionTime -gt 0) {
        $hours = $activeLimit.MaxConnectionTime / 3600000
        Register-Check -Name "Active Session Limit" -Status INFO -Message "$hours hours"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Delete temp folders on exit
try {
    $delTemp = Get-ItemProperty -Path $tsPolicyPath -Name "DeleteTempDirsOnExit" -ErrorAction SilentlyContinue
    if ($delTemp.DeleteTempDirsOnExit -eq 1) {
        Register-Check -Name "Delete Temp Folders" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Delete Temp Folders" -Status WARN -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DEVICE AND DRIVE REDIRECTION
# ============================================================================
Write-Section "Device and Drive Redirection"

# Drive redirection - CIS 18.9.65.3.3.2
try {
    $driveRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableCdm" -ErrorAction SilentlyContinue
    if ($driveRedir.fDisableCdm -eq 1) {
        Register-Check -Name "Drive Redirection" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Drive Redirection" -Status WARN -Message "Allowed - data exfiltration risk"
    }
} catch {
    Register-Check -Name "Drive Redirection" -Status WARN -Message "Allowed (default)"
}

# Clipboard redirection - CIS 18.9.65.3.3.1
try {
    $clipRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableClip" -ErrorAction SilentlyContinue
    if ($clipRedir.fDisableClip -eq 1) {
        Register-Check -Name "Clipboard Redirection" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Clipboard Redirection" -Status INFO -Message "Allowed"
    }
} catch {
    Register-Check -Name "Clipboard Redirection" -Status INFO -Message "Allowed (default)"
}

# COM port redirection
try {
    $comRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableCcm" -ErrorAction SilentlyContinue
    if ($comRedir.fDisableCcm -eq 1) {
        Register-Check -Name "COM Port Redirection" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# LPT port redirection
try {
    $lptRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableLPT" -ErrorAction SilentlyContinue
    if ($lptRedir.fDisableLPT -eq 1) {
        Register-Check -Name "LPT Port Redirection" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Printer redirection
try {
    $prnRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableCpm" -ErrorAction SilentlyContinue
    if ($prnRedir.fDisableCpm -eq 1) {
        Register-Check -Name "Printer Redirection" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Printer Redirection" -Status INFO -Message "Allowed"
    }
} catch {
    Register-Check -Name "Printer Redirection" -Status INFO -Message "Allowed (default)"
}

# Audio redirection
try {
    $audioRedir = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableAudioCapture" -ErrorAction SilentlyContinue
    if ($audioRedir.fDisableAudioCapture -eq 1) {
        Register-Check -Name "Audio Capture" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# WebAuthn redirection
try {
    $webauthn = Get-ItemProperty -Path $tsPolicyPath -Name "fDisableWebAuthn" -ErrorAction SilentlyContinue
    if ($null -eq $webauthn.fDisableWebAuthn -or $webauthn.fDisableWebAuthn -eq 0) {
        Register-Check -Name "WebAuthn Redirection" -Status PASS -Message "Allowed (for passwordless)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# RD GATEWAY AND LICENSING
# ============================================================================
Write-Section "RD Gateway and Advanced"

# Check for RD Gateway requirement
try {
    $rdGateway = Get-ItemProperty -Path $tsPolicyPath -Name "AuthenticationLevel" -ErrorAction SilentlyContinue
    if ($rdGateway.AuthenticationLevel -eq 0) {
        Register-Check -Name "Server Authentication" -Status WARN -Message "Connect even if fails"
    } else {
        Register-Check -Name "Server Authentication" -Status PASS -Message "Required"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# RD Session Host configuration
try {
    $rdsh = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server\TSAppAllowList" -ErrorAction SilentlyContinue
    if ($rdsh) {
        Register-Check -Name "RemoteApp Configuration" -Status INFO -Message "RemoteApp configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for RD Connection Broker (server role)
try {
    $rdcb = Get-Service -Name "Tssdis" -ErrorAction SilentlyContinue
    if ($rdcb) {
        Register-Check -Name "RD Connection Broker" -Status INFO -Message "$($rdcb.Status)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Limit concurrent sessions
try {
    $maxConn = Get-ItemProperty -Path $rdpTcpPath -Name "MaxInstanceCount" -ErrorAction SilentlyContinue
    if ($maxConn.MaxInstanceCount -and $maxConn.MaxInstanceCount -ne 0xffffffff) {
        Register-Check -Name "Max Connections" -Status INFO -Message "$($maxConn.MaxInstanceCount) maximum"
    } else {
        Register-Check -Name "Max Connections" -Status INFO -Message "Unlimited"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# LOGGING AND AUDITING
# ============================================================================
Write-Section "RDP Logging"

# Check for RDP-related security events
try {
    $rdpEvents = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=@(4624,4625)} -MaxEvents 100 -ErrorAction SilentlyContinue |
        Where-Object { $_.Message -match "Type.*10|RemoteInteractive" } | Select-Object -First 1

    if ($rdpEvents) {
        Register-Check -Name "RDP Auth Logging" -Status PASS -Message "RDP logon events being captured"
    } else {
        Register-Check -Name "RDP Auth Logging" -Status INFO -Message "No recent RDP logon events"
    }
} catch {
    Register-Check -Name "RDP Auth Logging" -Status SKIP -Message "Cannot query security log"
}

# Check RemoteDesktopServices-RdpCoreTS operational log
try {
    $rdpCoreLog = Get-WinEvent -LogName "Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational" -MaxEvents 1 -ErrorAction SilentlyContinue
    if ($rdpCoreLog) {
        Register-Check -Name "RDP Core Logging" -Status PASS -Message "Operational log active"
    }
} catch {
    Register-Check -Name "RDP Core Logging" -Status INFO -Message "Log may be disabled"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
