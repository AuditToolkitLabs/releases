# Check Registry Editor Access Restrictions
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DisableRegistryTools" -ErrorAction SilentlyContinue
    if ($reg.DisableRegistryTools -eq 1) {
        Register-Check -Name "Registry Editor Restrictions" -Status PASS -Message "Registry Editor is restricted for standard users."
    } else {
        Register-Check -Name "Registry Editor Restrictions" -Status FAIL -Message "Registry Editor is not restricted for standard users."
    }
} catch {
    Register-Check -Name "Registry Editor Restrictions" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit