# Remote Access Tools Audit Script (PowerShell)
# Detects remote access/desktop tools and their security configuration
# This script is read-only and does not modify system state.
#
# References:
# - CIS Controls 4: Secure Configuration of Assets
# - MITRE ATT&CK: T1219 Remote Access Software

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# TEAMVIEWER
# ============================================================================
Write-Section "TeamViewer"

try {
    $tvService = Get-Service -Name "TeamViewer*" -ErrorAction SilentlyContinue
    if ($tvService) {
        foreach ($svc in $tvService) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name "TeamViewer Service" -Status WARN -Message "Running - review if authorized"
            } else {
                Register-Check -Name "TeamViewer Service" -Status INFO -Message "$($svc.Status)"
            }
        }

        # Check version and settings
        $tvPaths = @(
            "C:\Program Files\TeamViewer",
            "C:\Program Files (x86)\TeamViewer"
        )

        foreach ($path in $tvPaths) {
            if (Test-Path $path) {
                $tvExe = Get-ChildItem -Path $path -Filter "TeamViewer.exe" -ErrorAction SilentlyContinue
                if ($tvExe) {
                    $version = $tvExe.VersionInfo.FileVersion
                    Register-Check -Name "TeamViewer Version" -Status INFO -Message "v$version"
                }
                break
            }
        }

        # Check registry for unattended access
        $tvReg = Get-ItemProperty -Path "HKLM:\SOFTWARE\TeamViewer" -ErrorAction SilentlyContinue
        if (-not $tvReg) {
            $tvReg = Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\TeamViewer" -ErrorAction SilentlyContinue
        }

        if ($tvReg) {
            if ($tvReg.Security_PasswordStrength) {
                Register-Check -Name "TeamViewer Password Strength" -Status INFO -Message "Level: $($tvReg.Security_PasswordStrength)"
            }
        }
    } else {
        # Check for running process (portable version)
        $tvProcess = Get-Process -Name "TeamViewer*" -ErrorAction SilentlyContinue
        if ($tvProcess) {
            Register-Check -Name "TeamViewer" -Status WARN -Message "Running (portable/no service) - review if authorized"
        } else {
            Register-Check -Name "TeamViewer" -Status PASS -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "TeamViewer" -Status INFO -Message "Not detected"
}

# ============================================================================
# ANYDESK
# ============================================================================
Write-Section "AnyDesk"

try {
    $anydeskService = Get-Service -Name "AnyDesk*" -ErrorAction SilentlyContinue
    if ($anydeskService) {
        foreach ($svc in $anydeskService) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name "AnyDesk Service" -Status WARN -Message "Running - review if authorized"
            } else {
                Register-Check -Name "AnyDesk Service" -Status INFO -Message "$($svc.Status)"
            }
        }

        # Check version
        $anydeskPaths = @(
            "C:\Program Files (x86)\AnyDesk",
            "C:\Program Files\AnyDesk",
            "$env:APPDATA\AnyDesk"
        )

        foreach ($path in $anydeskPaths) {
            $exe = Join-Path $path "AnyDesk.exe"
            if (Test-Path $exe) {
                $version = (Get-Item $exe).VersionInfo.FileVersion
                Register-Check -Name "AnyDesk Version" -Status INFO -Message "v$version"
                break
            }
        }
    } else {
        # Check for running process
        $adProcess = Get-Process -Name "AnyDesk*" -ErrorAction SilentlyContinue
        if ($adProcess) {
            Register-Check -Name "AnyDesk" -Status WARN -Message "Running (no service) - review if authorized"
        } else {
            Register-Check -Name "AnyDesk" -Status PASS -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "AnyDesk" -Status INFO -Message "Not detected"
}

# ============================================================================
# RUSTDESK
# ============================================================================
Write-Section "RustDesk"

try {
    $rustdeskService = Get-Service -Name "RustDesk*" -ErrorAction SilentlyContinue
    if ($rustdeskService) {
        if ($rustdeskService.Status -eq "Running") {
            Register-Check -Name "RustDesk Service" -Status WARN -Message "Running - open source remote access"
        } else {
            Register-Check -Name "RustDesk Service" -Status INFO -Message "$($rustdeskService.Status)"
        }
    } else {
        $process = Get-Process -Name "rustdesk*" -ErrorAction SilentlyContinue
        if ($process) {
            Register-Check -Name "RustDesk" -Status WARN -Message "Running - review if authorized"
        } else {
            Register-Check -Name "RustDesk" -Status PASS -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "RustDesk" -Status INFO -Message "Not detected"
}

# ============================================================================
# LOGMEIN / GOTOMYPC
# ============================================================================
Write-Section "LogMeIn / GoToMyPC"

try {
    $logmeinServices = @("LogMeIn", "LMIGuardianSvc", "GoToMyPC")

    foreach ($svcName in $logmeinServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name $svcName -Status WARN -Message "Running - review if authorized"
            } else {
                Register-Check -Name $svcName -Status INFO -Message "$($svc.Status)"
            }
        }
    }

    # Check if any were found
    $found = $logmeinServices | ForEach-Object { Get-Service -Name $_ -ErrorAction SilentlyContinue } | Where-Object { $_ }
    if (-not $found) {
        Register-Check -Name "LogMeIn/GoToMyPC" -Status PASS -Message "Not installed"
    }
} catch {
    Register-Check -Name "LogMeIn" -Status INFO -Message "Not detected"
}

# ============================================================================
# SPLASHTOP
# ============================================================================
Write-Section "Splashtop"

try {
    $splashtopService = Get-Service -Name "SplashtopRemoteService" -ErrorAction SilentlyContinue
    if ($splashtopService) {
        if ($splashtopService.Status -eq "Running") {
            Register-Check -Name "Splashtop" -Status WARN -Message "Running - review if authorized"
        } else {
            Register-Check -Name "Splashtop" -Status INFO -Message "$($splashtopService.Status)"
        }
    } else {
        Register-Check -Name "Splashtop" -Status PASS -Message "Not installed"
    }
} catch {
    Register-Check -Name "Splashtop" -Status INFO -Message "Not detected"
}

# ============================================================================
# SCREENCONNECT / CONNECTWISE CONTROL
# ============================================================================
Write-Section "ConnectWise Control (ScreenConnect)"

try {
    $scService = Get-Service -Name "ScreenConnect*" -ErrorAction SilentlyContinue
    if (-not $scService) {
        $scService = Get-Service -Name "ConnectWiseControl*" -ErrorAction SilentlyContinue
    }

    if ($scService) {
        foreach ($svc in $scService) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name "ConnectWise Control" -Status WARN -Message "Running - $($svc.Name)"
            } else {
                Register-Check -Name "ConnectWise Control" -Status INFO -Message "$($svc.Status)"
            }
        }
    } else {
        Register-Check -Name "ConnectWise Control" -Status PASS -Message "Not installed"
    }
} catch {
    Register-Check -Name "ConnectWise Control" -Status INFO -Message "Not detected"
}

# ============================================================================
# BOMGAR / BEYONDTRUST
# ============================================================================
Write-Section "BeyondTrust (Bomgar)"

try {
    $bomgarService = Get-Service -Name "bomgar*" -ErrorAction SilentlyContinue
    if (-not $bomgarService) {
        $bomgarService = Get-Service -Name "BeyondTrust*" -ErrorAction SilentlyContinue
    }

    if ($bomgarService) {
        foreach ($svc in $bomgarService) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name "BeyondTrust Remote" -Status INFO -Message "Running - enterprise remote access"
            } else {
                Register-Check -Name "BeyondTrust Remote" -Status INFO -Message "$($svc.Status)"
            }
        }
    } else {
        Register-Check -Name "BeyondTrust" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "BeyondTrust" -Status INFO -Message "Not detected"
}

# ============================================================================
# DAMEWARE
# ============================================================================
Write-Section "SolarWinds DameWare"

try {
    $damewareService = Get-Service -Name "DameWare*" -ErrorAction SilentlyContinue
    if (-not $damewareService) {
        $damewareService = Get-Service -Name "dwrcs*" -ErrorAction SilentlyContinue
    }

    if ($damewareService) {
        foreach ($svc in $damewareService) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name "DameWare" -Status INFO -Message "Running - enterprise remote access"
            } else {
                Register-Check -Name "DameWare" -Status INFO -Message "$($svc.Status)"
            }
        }
    } else {
        Register-Check -Name "DameWare" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "DameWare" -Status INFO -Message "Not detected"
}

# ============================================================================
# VNC SERVERS
# ============================================================================
Write-Section "VNC Servers"

$vncServices = @(
    @{Name="uvnc_service"; Display="UltraVNC"},
    @{Name="tvnserver"; Display="TightVNC"},
    @{Name="vncserver"; Display="RealVNC"},
    @{Name="WinVNC*"; Display="WinVNC"}
)

$vncFound = $false
foreach ($vnc in $vncServices) {
    try {
        $svc = Get-Service -Name $vnc.Name -ErrorAction SilentlyContinue
        if ($svc) {
            $vncFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name $vnc.Display -Status WARN -Message "Running - potential security risk"
            } else {
                Register-Check -Name $vnc.Display -Status INFO -Message "$($svc.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check for VNC listening ports
if (-not $vncFound) {
    try {
        $vncPorts = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in 5900..5910 }
        if ($vncPorts) {
            Register-Check -Name "VNC Port" -Status WARN -Message "Listening on port(s): $($vncPorts.LocalPort -join ', ')"
        } else {
            Register-Check -Name "VNC Server" -Status PASS -Message "Not detected"
        }
    } catch {
        Register-Check -Name "VNC Server" -Status INFO -Message "Not detected"
    }
}

# ============================================================================
# REMOTE UTILITIES
# ============================================================================
Write-Section "Remote Utilities"

try {
    $ruService = Get-Service -Name "rutserv" -ErrorAction SilentlyContinue
    if ($ruService) {
        if ($ruService.Status -eq "Running") {
            Register-Check -Name "Remote Utilities" -Status WARN -Message "Running - review if authorized"
        } else {
            Register-Check -Name "Remote Utilities" -Status INFO -Message "$($ruService.Status)"
        }
    } else {
        Register-Check -Name "Remote Utilities" -Status PASS -Message "Not installed"
    }
} catch {
    Register-Check -Name "Remote Utilities" -Status INFO -Message "Not detected"
}

# ============================================================================
# AMMYY ADMIN (OFTEN MALWARE-ASSOCIATED)
# ============================================================================
Write-Section "Suspicious Remote Access Tools"

try {
    # Ammyy Admin
    $ammyy = Get-Process -Name "AA_v*" -ErrorAction SilentlyContinue
    if (-not $ammyy) {
        $ammyy = Get-Process -Name "Ammyy*" -ErrorAction SilentlyContinue
    }

    if ($ammyy) {
        Register-Check -Name "Ammyy Admin" -Status FAIL -Message "RUNNING - commonly abused by threat actors"
    }

    # SupRemo
    $supremo = Get-Process -Name "Supremo*" -ErrorAction SilentlyContinue
    if ($supremo) {
        Register-Check -Name "Supremo" -Status WARN -Message "Running - review if authorized"
    }

    # SimpleHelp
    $simplehelp = Get-Service -Name "SimpleHelp*" -ErrorAction SilentlyContinue
    if ($simplehelp -and $simplehelp.Status -eq "Running") {
        Register-Check -Name "SimpleHelp" -Status WARN -Message "Running - review if authorized"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# NGROK / TUNNEL SERVICES
# ============================================================================
Write-Section "Tunnel / Proxy Services"

try {
    # Ngrok
    $ngrok = Get-Process -Name "ngrok*" -ErrorAction SilentlyContinue
    if ($ngrok) {
        Register-Check -Name "Ngrok" -Status FAIL -Message "RUNNING - tunneling service (potential data exfil)"
    } else {
        Register-Check -Name "Ngrok" -Status PASS -Message "Not running"
    }

    # Cloudflare Tunnel (cloudflared)
    $cloudflared = Get-Process -Name "cloudflared*" -ErrorAction SilentlyContinue
    if ($cloudflared) {
        Register-Check -Name "Cloudflare Tunnel" -Status WARN -Message "Running - review if authorized"
    }

    # LocalTunnel
    $localtunnel = Get-Process -Name "lt*" -ErrorAction SilentlyContinue | Where-Object { $_.Path -match "localtunnel" }
    if ($localtunnel) {
        Register-Check -Name "LocalTunnel" -Status WARN -Message "Running - review if authorized"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================
Write-Section "Remote Access Summary"

$remoteTools = @(
    @{Name="TeamViewer*"; Display="TeamViewer"; Risk="Medium"},
    @{Name="AnyDesk*"; Display="AnyDesk"; Risk="Medium"},
    @{Name="RustDesk*"; Display="RustDesk"; Risk="Medium"},
    @{Name="LogMeIn"; Display="LogMeIn"; Risk="Low"},
    @{Name="ScreenConnect*"; Display="ScreenConnect"; Risk="Medium"},
    @{Name="uvnc_service"; Display="VNC"; Risk="High"},
    @{Name="rutserv"; Display="Remote Utilities"; Risk="Medium"}
)

$runningTools = @()
$riskLevel = 0

foreach ($tool in $remoteTools) {
    $svc = Get-Service -Name $tool.Name -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningTools += $tool.Display
        switch ($tool.Risk) {
            "High" { $riskLevel += 3 }
            "Medium" { $riskLevel += 2 }
            "Low" { $riskLevel += 1 }
        }
    }
}

# Check processes too
$remoteProcesses = @("TeamViewer", "AnyDesk", "rustdesk", "ngrok", "Ammyy")
foreach ($proc in $remoteProcesses) {
    $running = Get-Process -Name "$proc*" -ErrorAction SilentlyContinue
    if ($running -and ($proc -notin $runningTools)) {
        $runningTools += $proc
        $riskLevel += 2
    }
}

if ($runningTools.Count -eq 0) {
    Register-Check -Name "Remote Access Tools" -Status PASS -Message "No unauthorized remote access tools detected"
} elseif ($riskLevel -ge 5) {
    Register-Check -Name "Remote Access Tools" -Status FAIL -Message "High risk: $($runningTools -join ', ')"
} else {
    Register-Check -Name "Remote Access Tools" -Status WARN -Message "Review: $($runningTools -join ', ')"
}

# ============================================================================
# FINAL SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
