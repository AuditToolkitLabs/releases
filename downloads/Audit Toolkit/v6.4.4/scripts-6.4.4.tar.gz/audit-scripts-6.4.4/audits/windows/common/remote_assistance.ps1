# Check Remote Assistance Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance" -Name "fAllowToGetHelp" -ErrorAction SilentlyContinue
    if ($reg.fAllowToGetHelp -eq 0) {
        Register-Check -Name "Remote Assistance" -Status PASS -Message "Remote Assistance is disabled."
    } else {
        Register-Check -Name "Remote Assistance" -Status FAIL -Message "Remote Assistance is enabled."
    }
} catch {
    Register-Check -Name "Remote Assistance" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit