# Check Remote Registry Service Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $svc = Get-Service -Name "RemoteRegistry" -ErrorAction SilentlyContinue
    if ($svc.Status -eq 'Stopped') {
        Register-Check -Name "Remote Registry Service" -Status PASS -Message "Service is stopped."
    } else {
        Register-Check -Name "Remote Registry Service" -Status FAIL -Message "Service is running."
    }
} catch {
    Register-Check -Name "Remote Registry Service" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit