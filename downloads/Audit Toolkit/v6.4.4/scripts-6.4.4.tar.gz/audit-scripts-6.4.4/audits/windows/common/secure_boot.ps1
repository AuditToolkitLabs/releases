# Secure Boot Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Firmware Security
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: https://www.cisecurity.org/benchmark/windows_11
# - Microsoft Secure Boot: https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/oem-secure-boot

Import-Module "$PSScriptRoot/common-audit.psm1"

# Check Secure Boot Status
try {
    $sb = Confirm-SecureBootUEFI
    if ($sb) {
    Register-Check -Name "Secure Boot" -Status PASS -Message "Secure Boot is enabled."
    } else {
    Register-Check -Name "Secure Boot" -Status FAIL -Message "Secure Boot is disabled."
    }
} catch {
    Register-Check -Name "Secure Boot" -Status WARN -Message "Secure Boot status could not be determined."
}
Print-Summary
Exit-Audit