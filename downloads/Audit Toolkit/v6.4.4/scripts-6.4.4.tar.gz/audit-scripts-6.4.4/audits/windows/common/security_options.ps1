# Security Options Audit Script (PowerShell)
# Comprehensive CIS Windows Benchmark - Security Options (2.3.x)
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 2.3.x (90+ controls)
# - CIS Windows Server 2022: 2.3.x
# - Microsoft Security Options: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/security-options

Import-Module "$PSScriptRoot/common-audit.psm1"

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [string]$CheckName,
        $ExpectedValue,
        [string]$PassMessage,
        [string]$FailMessage,
        [switch]$InvertCheck,
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual,
        [switch]$NotEmpty
    )

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        if ($NotEmpty) {
            if (-not [string]::IsNullOrWhiteSpace($actualValue)) {
                Register-Check -Name $CheckName -Status PASS -Message $PassMessage
            } else {
                Register-Check -Name $CheckName -Status FAIL -Message $FailMessage
            }
        } elseif ($GreaterOrEqual) {
            if ($actualValue -ge $ExpectedValue) {
                Register-Check -Name $CheckName -Status PASS -Message "$PassMessage ($actualValue)"
            } else {
                Register-Check -Name $CheckName -Status FAIL -Message "$FailMessage ($actualValue)"
            }
        } elseif ($LessOrEqual) {
            if ($actualValue -le $ExpectedValue) {
                Register-Check -Name $CheckName -Status PASS -Message "$PassMessage ($actualValue)"
            } else {
                Register-Check -Name $CheckName -Status FAIL -Message "$FailMessage ($actualValue)"
            }
        } elseif ($InvertCheck) {
            if ($actualValue -ne $ExpectedValue) {
                Register-Check -Name $CheckName -Status PASS -Message $PassMessage
            } else {
                Register-Check -Name $CheckName -Status FAIL -Message $FailMessage
            }
        } else {
            if ($actualValue -eq $ExpectedValue) {
                Register-Check -Name $CheckName -Status PASS -Message $PassMessage
            } else {
                Register-Check -Name $CheckName -Status FAIL -Message "$FailMessage (Current: $actualValue)"
            }
        }
    } catch {
        Register-Check -Name $CheckName -Status WARN -Message "Not configured or inaccessible"
    }
}

# ============================================================================
# CIS 2.3.1: ACCOUNTS POLICIES
# ============================================================================
Write-Section "Accounts Policies (CIS 2.3.1)"

$lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"

# CIS 2.3.1.1 - Administrator account status (check if renamed)
try {
    $adminAccount = Get-LocalUser | Where-Object { $_.SID -like "S-1-5-*-500" }
    if ($adminAccount.Name -ne "Administrator") {
        Register-Check -Name "Administrator Renamed" -Status PASS -Message "Renamed to: $($adminAccount.Name)"
    } else {
        Register-Check -Name "Administrator Renamed" -Status WARN -Message "Default name 'Administrator' in use"
    }

    if (-not $adminAccount.Enabled) {
        Register-Check -Name "Administrator Disabled" -Status PASS -Message "Built-in Administrator is disabled"
    } else {
        Register-Check -Name "Administrator Disabled" -Status INFO -Message "Built-in Administrator is enabled"
    }
} catch {
    Register-Check -Name "Administrator Account" -Status SKIP -Message "Cannot query local users"
}

# CIS 2.3.1.2 - Guest account status
try {
    $guestAccount = Get-LocalUser | Where-Object { $_.SID -like "S-1-5-*-501" }
    if (-not $guestAccount.Enabled) {
        Register-Check -Name "Guest Account" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Guest Account" -Status FAIL -Message "Enabled - should be disabled"
    }

    if ($guestAccount.Name -ne "Guest") {
        Register-Check -Name "Guest Renamed" -Status PASS -Message "Renamed to: $($guestAccount.Name)"
    }
} catch {
    Register-Check -Name "Guest Account" -Status SKIP -Message "Cannot query"
}

# CIS 2.3.1.3 - Limit local account use of blank passwords to console logon only
Test-RegistryValue -Path $lsaPath -Name "LimitBlankPasswordUse" `
    -CheckName "Limit Blank Password" `
    -ExpectedValue 1 `
    -PassMessage "Console only access for blank passwords" `
    -FailMessage "Blank passwords can access network"

# ============================================================================
# CIS 2.3.2: AUDIT POLICIES
# ============================================================================
Write-Section "Audit Policies (CIS 2.3.2)"

# CIS 2.3.2.1 - Audit: Force audit policy subcategory settings
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SCENoApplyLegacyAuditPolicy" `
    -CheckName "Force Audit Subcategory" `
    -ExpectedValue 1 `
    -PassMessage "Subcategory settings override category" `
    -FailMessage "Legacy audit policy may override"

# CIS 2.3.2.2 - Audit: Shut down if unable to log security audits
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "CrashOnAuditFail" `
    -CheckName "Crash On Audit Fail" `
    -ExpectedValue 0 `
    -PassMessage "Disabled (recommended for most)" `
    -FailMessage "Enabled - system will shut down if auditing fails"

# ============================================================================
# CIS 2.3.4: DEVICES POLICIES
# ============================================================================
Write-Section "Devices Policies (CIS 2.3.4)"

# CIS 2.3.4.1 - Allow undock without logon
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "UndockWithoutLogon" `
    -CheckName "Undock Without Logon" `
    -ExpectedValue 0 `
    -PassMessage "Disabled" `
    -FailMessage "Allowed - physical security risk"

# CIS 2.3.4.2 - Allowed to format and eject removable media
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "AllocateDASD" `
    -CheckName "Format/Eject Removable Media" `
    -ExpectedValue 0 `
    -PassMessage "Administrators only" `
    -FailMessage "Users may format removable media"

# CIS 2.3.4.3 - Prevent installation of print drivers
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers" -Name "AddPrinterDrivers" `
    -CheckName "Prevent Print Driver Install" `
    -ExpectedValue 1 `
    -PassMessage "Only Administrators can install drivers" `
    -FailMessage "Non-admins may install print drivers"

# ============================================================================
# CIS 2.3.6: DOMAIN MEMBER POLICIES
# ============================================================================
Write-Section "Domain Member Policies (CIS 2.3.6)"

$netlogonPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters"

# CIS 2.3.6.1 - Digitally encrypt or sign secure channel data (always)
Test-RegistryValue -Path $netlogonPath -Name "RequireSignOrSeal" `
    -CheckName "Secure Channel Sign/Seal" `
    -ExpectedValue 1 `
    -PassMessage "Required" `
    -FailMessage "Not required"

# CIS 2.3.6.2 - Digitally encrypt secure channel data
Test-RegistryValue -Path $netlogonPath -Name "SealSecureChannel" `
    -CheckName "Secure Channel Encrypt" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Not enabled"

# CIS 2.3.6.3 - Digitally sign secure channel data
Test-RegistryValue -Path $netlogonPath -Name "SignSecureChannel" `
    -CheckName "Secure Channel Sign" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Not enabled"

# CIS 2.3.6.4 - Disable machine account password changes
Test-RegistryValue -Path $netlogonPath -Name "DisablePasswordChange" `
    -CheckName "Machine Password Changes" `
    -ExpectedValue 0 `
    -PassMessage "Enabled (passwords rotate)" `
    -FailMessage "Disabled - stale machine passwords"

# CIS 2.3.6.5 - Maximum machine account password age
Test-RegistryValue -Path $netlogonPath -Name "MaximumPasswordAge" `
    -CheckName "Machine Password Age" `
    -ExpectedValue 30 -LessOrEqual `
    -PassMessage "30 days or less" `
    -FailMessage "Greater than 30 days"

# CIS 2.3.6.6 - Require strong session key
Test-RegistryValue -Path $netlogonPath -Name "RequireStrongKey" `
    -CheckName "Strong Session Key" `
    -ExpectedValue 1 `
    -PassMessage "Required" `
    -FailMessage "Not required"

# ============================================================================
# CIS 2.3.7: INTERACTIVE LOGON
# ============================================================================
Write-Section "Interactive Logon (CIS 2.3.7)"

$winlogonPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
$systemPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"

# CIS 2.3.7.1 - Display user information when session is locked
Test-RegistryValue -Path $systemPath -Name "DontDisplayLockedUserId" `
    -CheckName "Locked Session User Info" `
    -ExpectedValue 3 `
    -PassMessage "Do not display user info" `
    -FailMessage "User info displayed on lock screen"

# CIS 2.3.7.2 - Do not display last user name
Test-RegistryValue -Path $systemPath -Name "DontDisplayLastUserName" `
    -CheckName "Last User Name Display" `
    -ExpectedValue 1 `
    -PassMessage "Not displayed" `
    -FailMessage "Last username shown at logon"

# CIS 2.3.7.3 - Do not require CTRL+ALT+DEL
Test-RegistryValue -Path $systemPath -Name "DisableCAD" `
    -CheckName "CTRL+ALT+DEL Required" `
    -ExpectedValue 0 `
    -PassMessage "Required (secure)" `
    -FailMessage "Not required - vulnerable to spoofing"

# CIS 2.3.7.4 - Machine inactivity limit (900 seconds = 15 min)
Test-RegistryValue -Path $systemPath -Name "InactivityTimeoutSecs" `
    -CheckName "Inactivity Timeout" `
    -ExpectedValue 900 -LessOrEqual `
    -PassMessage "15 minutes or less" `
    -FailMessage "Too long"

# CIS 2.3.7.5 - Message text for users attempting to logon
Test-RegistryValue -Path $systemPath -Name "LegalNoticeText" `
    -CheckName "Legal Notice Banner" -NotEmpty `
    -PassMessage "Configured" `
    -FailMessage "No legal banner configured"

# CIS 2.3.7.6 - Message title for users attempting to logon
Test-RegistryValue -Path $systemPath -Name "LegalNoticeCaption" `
    -CheckName "Legal Notice Title" -NotEmpty `
    -PassMessage "Configured" `
    -FailMessage "No legal notice title"

# CIS 2.3.7.7 - Number of previous logons to cache (4 or less)
Test-RegistryValue -Path $winlogonPath -Name "CachedLogonsCount" `
    -CheckName "Cached Logons" `
    -ExpectedValue 4 -LessOrEqual `
    -PassMessage "4 or fewer cached" `
    -FailMessage "Too many cached logons"

# CIS 2.3.7.8 - Password expiration warning (14 days)
Test-RegistryValue -Path $winlogonPath -Name "PasswordExpiryWarning" `
    -CheckName "Password Expiry Warning" `
    -ExpectedValue 14 -GreaterOrEqual `
    -PassMessage "14+ days warning" `
    -FailMessage "Less than 14 days"

# CIS 2.3.7.9 - Require Domain Controller authentication to unlock
Test-RegistryValue -Path $winlogonPath -Name "ForceUnlockLogon" `
    -CheckName "DC Auth to Unlock" `
    -ExpectedValue 1 `
    -PassMessage "Required" `
    -FailMessage "Not required"

# CIS 2.3.7.10 - Smart card removal behavior
Test-RegistryValue -Path $winlogonPath -Name "ScRemoveOption" `
    -CheckName "Smart Card Removal" `
    -ExpectedValue 1 -GreaterOrEqual `
    -PassMessage "Lock or logoff on removal" `
    -FailMessage "No action on smart card removal"

# ============================================================================
# CIS 2.3.8: MICROSOFT NETWORK CLIENT
# ============================================================================
Write-Section "Microsoft Network Client (CIS 2.3.8)"

$lanmanWksPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"

# CIS 2.3.8.1 - Digitally sign communications (always)
Test-RegistryValue -Path $lanmanWksPath -Name "RequireSecuritySignature" `
    -CheckName "SMB Client Signing Required" `
    -ExpectedValue 1 `
    -PassMessage "Required" `
    -FailMessage "Not required - relay attack risk"

# CIS 2.3.8.2 - Digitally sign communications (if server agrees)
Test-RegistryValue -Path $lanmanWksPath -Name "EnableSecuritySignature" `
    -CheckName "SMB Client Signing Enabled" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.8.3 - Send unencrypted password to third-party SMB servers
Test-RegistryValue -Path $lanmanWksPath -Name "EnablePlainTextPassword" `
    -CheckName "SMB Plaintext Password" `
    -ExpectedValue 0 `
    -PassMessage "Disabled" `
    -FailMessage "Enabled - passwords sent in clear"

# ============================================================================
# CIS 2.3.9: MICROSOFT NETWORK SERVER
# ============================================================================
Write-Section "Microsoft Network Server (CIS 2.3.9)"

$lanmanSrvPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"

# CIS 2.3.9.1 - Amount of idle time required before suspending session
Test-RegistryValue -Path $lanmanSrvPath -Name "AutoDisconnect" `
    -CheckName "SMB Idle Disconnect" `
    -ExpectedValue 15 -LessOrEqual `
    -PassMessage "15 min or less" `
    -FailMessage "Too long"

# CIS 2.3.9.2 - Digitally sign communications (always)
Test-RegistryValue -Path $lanmanSrvPath -Name "RequireSecuritySignature" `
    -CheckName "SMB Server Signing Required" `
    -ExpectedValue 1 `
    -PassMessage "Required" `
    -FailMessage "Not required"

# CIS 2.3.9.3 - Digitally sign communications (if client agrees)
Test-RegistryValue -Path $lanmanSrvPath -Name "EnableSecuritySignature" `
    -CheckName "SMB Server Signing Enabled" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.9.4 - Disconnect clients when logon hours expire
Test-RegistryValue -Path $lanmanSrvPath -Name "EnableForcedLogoff" `
    -CheckName "Forced Logoff on Expire" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.9.5 - SMB1 Support
Test-RegistryValue -Path $lanmanSrvPath -Name "SMB1" `
    -CheckName "SMB1 Protocol" `
    -ExpectedValue 0 `
    -PassMessage "Disabled" `
    -FailMessage "Enabled - security risk"

# ============================================================================
# CIS 2.3.10: NETWORK ACCESS
# ============================================================================
Write-Section "Network Access (CIS 2.3.10)"

# CIS 2.3.10.1 - Allow anonymous SID/Name translation
Test-RegistryValue -Path $lsaPath -Name "TurnOffAnonymousBlock" `
    -CheckName "Anonymous SID Translation" `
    -ExpectedValue 0 `
    -PassMessage "Blocked" `
    -FailMessage "Allowed"

# CIS 2.3.10.2 - Do not allow anonymous enumeration of SAM accounts
Test-RegistryValue -Path $lsaPath -Name "RestrictAnonymousSAM" `
    -CheckName "Anonymous SAM Enum" `
    -ExpectedValue 1 `
    -PassMessage "Restricted" `
    -FailMessage "Allowed"

# CIS 2.3.10.3 - Do not allow anonymous enumeration of SAM and shares
Test-RegistryValue -Path $lsaPath -Name "RestrictAnonymous" `
    -CheckName "Anonymous SAM/Share Enum" `
    -ExpectedValue 1 `
    -PassMessage "Restricted" `
    -FailMessage "Allowed"

# CIS 2.3.10.4 - Do not allow storage of passwords for network auth
Test-RegistryValue -Path $lsaPath -Name "DisableDomainCreds" `
    -CheckName "Stored Network Passwords" `
    -ExpectedValue 1 `
    -PassMessage "Disabled" `
    -FailMessage "Allowed - credential theft risk"

# CIS 2.3.10.5 - Let Everyone permissions apply to anonymous users
Test-RegistryValue -Path $lsaPath -Name "EveryoneIncludesAnonymous" `
    -CheckName "Everyone Includes Anonymous" `
    -ExpectedValue 0 `
    -PassMessage "No (secure)" `
    -FailMessage "Yes - anonymous gets Everyone perms"

# CIS 2.3.10.6 - Named Pipes accessible anonymously (should be empty)
try {
    $nullPipes = Get-ItemProperty -Path $lanmanSrvPath -Name "NullSessionPipes" -ErrorAction Stop
    $pipeList = $nullPipes.NullSessionPipes
    if ([string]::IsNullOrWhiteSpace($pipeList) -or $pipeList.Count -eq 0) {
        Register-Check -Name "Null Session Pipes" -Status PASS -Message "None configured"
    } else {
        Register-Check -Name "Null Session Pipes" -Status WARN -Message "Configured: $($pipeList -join ', ')"
    }
} catch {
    Register-Check -Name "Null Session Pipes" -Status PASS -Message "Not configured"
}

# CIS 2.3.10.7 - Remotely accessible registry paths
try {
    $paths = Get-ItemProperty -Path $lsaPath -Name "Machine" -ErrorAction SilentlyContinue
    if ($paths) {
        Register-Check -Name "Remote Registry Paths" -Status INFO -Message "Remote registry access configured"
    } else {
        Register-Check -Name "Remote Registry Paths" -Status PASS -Message "Not configured"
    }
} catch {
    Register-Check -Name "Remote Registry Paths" -Status PASS -Message "Not configured"
}

# CIS 2.3.10.10 - Restrict clients allowed to make remote calls to SAM
Test-RegistryValue -Path $lsaPath -Name "RestrictRemoteSAM" -NotEmpty `
    -CheckName "Remote SAM Access" `
    -PassMessage "Restricted" `
    -FailMessage "Not restricted - enumeration possible"

# CIS 2.3.10.11 - Shares accessible anonymously (should be empty)
try {
    $nullShares = Get-ItemProperty -Path $lanmanSrvPath -Name "NullSessionShares" -ErrorAction Stop
    $shareList = $nullShares.NullSessionShares
    if ([string]::IsNullOrWhiteSpace($shareList) -or $shareList.Count -eq 0) {
        Register-Check -Name "Null Session Shares" -Status PASS -Message "None configured"
    } else {
        Register-Check -Name "Null Session Shares" -Status FAIL -Message "Anonymous access: $($shareList -join ', ')"
    }
} catch {
    Register-Check -Name "Null Session Shares" -Status PASS -Message "Not configured"
}

# CIS 2.3.10.12 - Sharing and security model for local accounts
Test-RegistryValue -Path $lsaPath -Name "ForceGuest" `
    -CheckName "Local Account Security Model" `
    -ExpectedValue 0 `
    -PassMessage "Classic - local auth" `
    -FailMessage "Guest only - insecure"

# ============================================================================
# CIS 2.3.11: NETWORK SECURITY
# ============================================================================
Write-Section "Network Security (CIS 2.3.11)"

$msvPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0"

# CIS 2.3.11.1 - Allow LocalSystem NULL session fallback
Test-RegistryValue -Path $msvPath -Name "AllowNullSessionFallback" `
    -CheckName "LocalSystem NULL Fallback" `
    -ExpectedValue 0 `
    -PassMessage "Disabled" `
    -FailMessage "Enabled"

# CIS 2.3.11.2 - Allow PKU2U authentication with online identities
Test-RegistryValue -Path $lsaPath -Name "pku2u\AllowOnlineID" `
    -CheckName "PKU2U Auth" `
    -ExpectedValue 0 `
    -PassMessage "Disabled" `
    -FailMessage "Allowed"

# CIS 2.3.11.3 - Kerberos encryption types
try {
    $kerbPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters"
    $encTypes = Get-ItemProperty -Path $kerbPath -Name "SupportedEncryptionTypes" -ErrorAction SilentlyContinue
    if ($encTypes.SupportedEncryptionTypes -band 0x18) { # AES128 + AES256
        Register-Check -Name "Kerberos Encryption" -Status PASS -Message "AES enabled"
    } else {
        Register-Check -Name "Kerberos Encryption" -Status WARN -Message "May include weak algorithms"
    }
} catch {
    Register-Check -Name "Kerberos Encryption" -Status INFO -Message "Using defaults"
}

# CIS 2.3.11.4 - Do not store LAN Manager hash
Test-RegistryValue -Path $lsaPath -Name "NoLMHash" `
    -CheckName "LM Hash Storage" `
    -ExpectedValue 1 `
    -PassMessage "Disabled (secure)" `
    -FailMessage "Storing LM hashes - crack risk"

# CIS 2.3.11.5 - LAN Manager authentication level
Test-RegistryValue -Path $lsaPath -Name "LmCompatibilityLevel" `
    -CheckName "LM Auth Level" `
    -ExpectedValue 5 -GreaterOrEqual `
    -PassMessage "NTLMv2 only" `
    -FailMessage "Weak NTLM allowed"

# CIS 2.3.11.6 - LDAP client signing requirements
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LDAP" -Name "LDAPClientIntegrity" `
    -CheckName "LDAP Client Signing" `
    -ExpectedValue 1 -GreaterOrEqual `
    -PassMessage "Required or negotiated" `
    -FailMessage "Not required"

# CIS 2.3.11.7 - Minimum session security for NTLM SSP clients
Test-RegistryValue -Path $msvPath -Name "NTLMMinClientSec" `
    -CheckName "NTLM Client Min Security" `
    -ExpectedValue 537395200 `
    -PassMessage "NTLMv2 + 128-bit" `
    -FailMessage "Weak session security"

# CIS 2.3.11.8 - Minimum session security for NTLM SSP servers
Test-RegistryValue -Path $msvPath -Name "NTLMMinServerSec" `
    -CheckName "NTLM Server Min Security" `
    -ExpectedValue 537395200 `
    -PassMessage "NTLMv2 + 128-bit" `
    -FailMessage "Weak session security"

# ============================================================================
# CIS 2.3.13: SHUTDOWN
# ============================================================================
Write-Section "Shutdown Policies (CIS 2.3.13)"

# CIS 2.3.13.1 - Allow shutdown without logon
Test-RegistryValue -Path $systemPath -Name "ShutdownWithoutLogon" `
    -CheckName "Shutdown Without Logon" `
    -ExpectedValue 0 `
    -PassMessage "Disabled (secure)" `
    -FailMessage "Allowed"

# CIS 2.3.13.2 - Clear virtual memory pagefile
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name "ClearPageFileAtShutdown" `
    -CheckName "Clear Pagefile on Shutdown" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - data may persist"

# ============================================================================
# CIS 2.3.14: SYSTEM CRYPTOGRAPHY
# ============================================================================
Write-Section "System Cryptography (CIS 2.3.14)"

# CIS 2.3.14.1 - Force strong key protection
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography" -Name "ForceKeyProtection" `
    -CheckName "Force Strong Key Protection" `
    -ExpectedValue 2 `
    -PassMessage "User prompted each time" `
    -FailMessage "Weak or no protection"

# CIS 2.3.14.2 - FIPS algorithm policy
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" `
    -CheckName "FIPS Mode" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# ============================================================================
# CIS 2.3.15: SYSTEM OBJECTS
# ============================================================================
Write-Section "System Objects (CIS 2.3.15)"

# CIS 2.3.15.1 - Require case insensitivity for non-Windows subsystems
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" -Name "ObCaseInsensitive" `
    -CheckName "Case Insensitivity" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.15.2 - Strengthen default permissions
Test-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "ProtectionMode" `
    -CheckName "Strengthen Global Objects" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - weaker permissions"

# ============================================================================
# CIS 2.3.17: USER ACCOUNT CONTROL
# ============================================================================
Write-Section "User Account Control (CIS 2.3.17)"

# CIS 2.3.17.1 - Admin Approval Mode for built-in Administrator
Test-RegistryValue -Path $systemPath -Name "FilterAdministratorToken" `
    -CheckName "UAC Admin Approval Mode" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.17.2 - Behavior of elevation prompt for admins
Test-RegistryValue -Path $systemPath -Name "ConsentPromptBehaviorAdmin" `
    -CheckName "Admin Elevation Prompt" `
    -ExpectedValue 2 -LessOrEqual `
    -PassMessage "Prompt for consent/credentials" `
    -FailMessage "Elevates without prompt"

# CIS 2.3.17.3 - Behavior of elevation prompt for users
Test-RegistryValue -Path $systemPath -Name "ConsentPromptBehaviorUser" `
    -CheckName "User Elevation Prompt" `
    -ExpectedValue 0 `
    -PassMessage "Auto-deny" `
    -FailMessage "Prompts standard users"

# CIS 2.3.17.4 - Detect application installations
Test-RegistryValue -Path $systemPath -Name "EnableInstallerDetection" `
    -CheckName "Installer Detection" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.17.5 - Only elevate executables that are signed
Test-RegistryValue -Path $systemPath -Name "ValidateAdminCodeSignatures" `
    -CheckName "UAC Validate Signatures" `
    -ExpectedValue 1 `
    -PassMessage "Only signed executables" `
    -FailMessage "Unsigned allowed"

# CIS 2.3.17.6 - Only elevate UIAccess in secure locations
Test-RegistryValue -Path $systemPath -Name "EnableSecureUIAPaths" `
    -CheckName "UAC Secure UI Paths" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# CIS 2.3.17.7 - Run all administrators in Admin Approval Mode
Test-RegistryValue -Path $systemPath -Name "EnableLUA" `
    -CheckName "UAC Enabled" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - major security risk"

# CIS 2.3.17.8 - Switch to secure desktop on elevation
Test-RegistryValue -Path $systemPath -Name "PromptOnSecureDesktop" `
    -CheckName "UAC Secure Desktop" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - spoofing possible"

# CIS 2.3.17.9 - Virtualize file and registry failures
Test-RegistryValue -Path $systemPath -Name "EnableVirtualization" `
    -CheckName "UAC Virtualization" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled"

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
