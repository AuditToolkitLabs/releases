# Check Shares for Anonymous Access
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin 'ADMIN$', 'C$', 'IPC$' }
    if (-not $shares -or $shares.Count -eq 0) {
        Register-Check -Name "SMB Shares" -Status PASS -Message "No non-default SMB shares found."
    } else {
        foreach ($share in $shares) {
            try {
                $perm = Get-SmbShareAccess -Name $share.Name | Where-Object { $_.AccountName -eq 'Everyone' -and $_.AccessControlType -eq 'Allow' }
                if ($perm) {
                    Register-Check -Name "Share $($share.Name)" -Status FAIL -Message "Share $($share.Name) allows anonymous access."
                } else {
                    Register-Check -Name "Share $($share.Name)" -Status PASS -Message "Share $($share.Name) does not allow anonymous access."
                }
            } catch {
                Register-Check -Name "Share $($share.Name)" -Status WARN -Message $_.Exception.Message
            }
        }
    }
} catch {
    Register-Check -Name "SMB Shares" -Status WARN -Message "Unable to enumerate SMB shares: $($_.Exception.Message)"
}
Print-Summary
Exit-Audit