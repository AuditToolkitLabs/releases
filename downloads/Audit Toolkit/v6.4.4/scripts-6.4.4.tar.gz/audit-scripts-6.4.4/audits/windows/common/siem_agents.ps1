# SIEM Agents Audit Script (PowerShell)
# Checks for enterprise SIEM/log forwarding agents and their configuration
# This script is read-only and does not modify system state.
#
# References:
# - PCI DSS 10.3: Log management
# - NIST SP 800-53: AU-6, SI-4

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# SPLUNK UNIVERSAL FORWARDER
# ============================================================================
Write-Section "Splunk Universal Forwarder"

try {
    $splunkService = Get-Service -Name "SplunkForwarder" -ErrorAction SilentlyContinue
    if ($splunkService) {
        if ($splunkService.Status -eq "Running") {
            Register-Check -Name "Splunk Forwarder Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Splunk Forwarder Service" -Status WARN -Message "$($splunkService.Status)"
        }

        # Check Splunk installation path
        $splunkPaths = @(
            "C:\Program Files\SplunkUniversalForwarder",
            "C:\Program Files (x86)\SplunkUniversalForwarder"
        )

        foreach ($path in $splunkPaths) {
            if (Test-Path $path) {
                $splunkExe = Join-Path $path "bin\splunk.exe"
                if (Test-Path $splunkExe) {
                    $version = (Get-Item $splunkExe).VersionInfo.FileVersion
                    Register-Check -Name "Splunk Version" -Status INFO -Message "v$version"
                }

                # Check outputs.conf for forwarding configuration
                $outputsConf = Join-Path $path "etc\system\local\outputs.conf"
                if (Test-Path $outputsConf) {
                    $hasServer = Select-String -Path $outputsConf -Pattern "server\s*=" -Quiet
                    if ($hasServer) {
                        Register-Check -Name "Splunk Forwarding" -Status PASS -Message "Configured"
                    } else {
                        Register-Check -Name "Splunk Forwarding" -Status WARN -Message "No server configured"
                    }
                }
                break
            }
        }
    } else {
        Register-Check -Name "Splunk Universal Forwarder" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Splunk Universal Forwarder" -Status INFO -Message "Not detected"
}

# ============================================================================
# MICROSOFT SENTINEL (AZURE MONITOR AGENT / MMA)
# ============================================================================
Write-Section "Microsoft Sentinel / Azure Monitor"

# Azure Monitor Agent (AMA) - newer agent
try {
    $amaService = Get-Service -Name "AzureMonitorAgent" -ErrorAction SilentlyContinue
    if ($amaService) {
        if ($amaService.Status -eq "Running") {
            Register-Check -Name "Azure Monitor Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Azure Monitor Agent" -Status WARN -Message "$($amaService.Status)"
        }
    } else {
        Register-Check -Name "Azure Monitor Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Azure Monitor Agent" -Status INFO -Message "Not detected"
}

# Microsoft Monitoring Agent (MMA) - legacy
try {
    $mmaService = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
    if ($mmaService) {
        if ($mmaService.Status -eq "Running") {
            Register-Check -Name "Microsoft Monitoring Agent (MMA)" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Microsoft Monitoring Agent (MMA)" -Status WARN -Message "$($mmaService.Status)"
        }

        # Check workspace configuration
        $mmaPath = "HKLM:\SYSTEM\CurrentControlSet\Services\HealthService\Parameters\Workspaces"
        if (Test-Path $mmaPath) {
            $workspaces = Get-ChildItem -Path $mmaPath -ErrorAction SilentlyContinue
            if ($workspaces) {
                Register-Check -Name "MMA Workspaces" -Status PASS -Message "$($workspaces.Count) workspace(s) configured"
            }
        }
    } else {
        Register-Check -Name "Microsoft Monitoring Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Microsoft Monitoring Agent" -Status INFO -Message "Not detected"
}

# Windows Event Forwarding for Sentinel
try {
    $wefService = Get-Service -Name "wecsvc" -ErrorAction SilentlyContinue
    if ($wefService -and $wefService.Status -eq "Running") {
        Register-Check -Name "Windows Event Collector" -Status PASS -Message "Running (for WEF)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ELASTIC AGENT / BEATS
# ============================================================================
Write-Section "Elastic Stack"

# Elastic Agent
try {
    $elasticAgent = Get-Service -Name "elastic-agent" -ErrorAction SilentlyContinue
    if ($elasticAgent) {
        if ($elasticAgent.Status -eq "Running") {
            Register-Check -Name "Elastic Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Elastic Agent" -Status WARN -Message "$($elasticAgent.Status)"
        }
    } else {
        Register-Check -Name "Elastic Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Elastic Agent" -Status INFO -Message "Not detected"
}

# Winlogbeat
try {
    $winlogbeat = Get-Service -Name "winlogbeat" -ErrorAction SilentlyContinue
    if ($winlogbeat) {
        if ($winlogbeat.Status -eq "Running") {
            Register-Check -Name "Winlogbeat" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Winlogbeat" -Status WARN -Message "$($winlogbeat.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Filebeat
try {
    $filebeat = Get-Service -Name "filebeat" -ErrorAction SilentlyContinue
    if ($filebeat) {
        if ($filebeat.Status -eq "Running") {
            Register-Check -Name "Filebeat" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Filebeat" -Status WARN -Message "$($filebeat.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DATADOG
# ============================================================================
Write-Section "Datadog"

try {
    $ddService = Get-Service -Name "datadogagent" -ErrorAction SilentlyContinue
    if ($ddService) {
        if ($ddService.Status -eq "Running") {
            Register-Check -Name "Datadog Agent" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Datadog Agent" -Status WARN -Message "$($ddService.Status)"
        }

        # Check Datadog configuration
        $ddConfig = "C:\ProgramData\Datadog\datadog.yaml"
        if (Test-Path $ddConfig) {
            Register-Check -Name "Datadog Config" -Status PASS -Message "Configuration present"
        }
    } else {
        Register-Check -Name "Datadog Agent" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Datadog Agent" -Status INFO -Message "Not detected"
}

# ============================================================================
# IBM QRADAR WINCOLLECT
# ============================================================================
Write-Section "IBM QRadar WinCollect"

try {
    $qradarService = Get-Service -Name "WinCollect" -ErrorAction SilentlyContinue
    if ($qradarService) {
        if ($qradarService.Status -eq "Running") {
            Register-Check -Name "QRadar WinCollect" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "QRadar WinCollect" -Status WARN -Message "$($qradarService.Status)"
        }
    } else {
        Register-Check -Name "QRadar WinCollect" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "QRadar WinCollect" -Status INFO -Message "Not detected"
}

# ============================================================================
# SUMO LOGIC
# ============================================================================
Write-Section "Sumo Logic"

try {
    $sumoService = Get-Service -Name "sumo-collector" -ErrorAction SilentlyContinue
    if ($sumoService) {
        if ($sumoService.Status -eq "Running") {
            Register-Check -Name "Sumo Logic Collector" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Sumo Logic Collector" -Status WARN -Message "$($sumoService.Status)"
        }
    } else {
        Register-Check -Name "Sumo Logic Collector" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Sumo Logic Collector" -Status INFO -Message "Not detected"
}

# ============================================================================
# GRAYLOG / NXLOG
# ============================================================================
Write-Section "Log Shippers"

# NXLog
try {
    $nxlog = Get-Service -Name "nxlog" -ErrorAction SilentlyContinue
    if ($nxlog) {
        if ($nxlog.Status -eq "Running") {
            Register-Check -Name "NXLog" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "NXLog" -Status WARN -Message "$($nxlog.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Fluentd/td-agent
try {
    $fluentd = Get-Service -Name "fluentdwinsvc" -ErrorAction SilentlyContinue
    if (-not $fluentd) {
        $fluentd = Get-Service -Name "td-agent" -ErrorAction SilentlyContinue
    }
    if ($fluentd) {
        if ($fluentd.Status -eq "Running") {
            Register-Check -Name "Fluentd" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Fluentd" -Status WARN -Message "$($fluentd.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# WINDOWS EVENT FORWARDING (WEF)
# ============================================================================
Write-Section "Windows Event Forwarding"

try {
    $winrmService = Get-Service -Name "WinRM" -ErrorAction SilentlyContinue
    if ($winrmService -and $winrmService.Status -eq "Running") {
        Register-Check -Name "WinRM Service" -Status PASS -Message "Running (required for WEF)"
    } else {
        Register-Check -Name "WinRM Service" -Status INFO -Message "Not running"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check subscription configuration
try {
    $subscriptions = wecutil es 2>$null
    if ($subscriptions) {
        $subCount = ($subscriptions | Measure-Object).Count
        Register-Check -Name "WEF Subscriptions" -Status PASS -Message "$subCount subscription(s) configured"
    } else {
        Register-Check -Name "WEF Subscriptions" -Status INFO -Message "No subscriptions"
    }
} catch {
    Register-Check -Name "WEF Subscriptions" -Status INFO -Message "WEF not configured"
}

# ============================================================================
# SYSLOG AGENTS
# ============================================================================
Write-Section "Syslog Agents"

# Check for common syslog agents
$syslogAgents = @(
    @{Name="SyslogAgent"; Display="Datagram SyslogAgent"},
    @{Name="Snare"; Display="Snare Agent"},
    @{Name="EventSentry"; Display="EventSentry"}
)

foreach ($agent in $syslogAgents) {
    try {
        $svc = Get-Service -Name $agent.Name -ErrorAction SilentlyContinue
        if ($svc) {
            if ($svc.Status -eq "Running") {
                Register-Check -Name $agent.Display -Status PASS -Message "Running"
            } else {
                Register-Check -Name $agent.Display -Status WARN -Message "$($svc.Status)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SIEM COVERAGE SUMMARY
# ============================================================================
Write-Section "SIEM/Log Forwarding Summary"

$siemProducts = @(
    @{Service="SplunkForwarder"; Name="Splunk"},
    @{Service="AzureMonitorAgent"; Name="Azure Monitor"},
    @{Service="HealthService"; Name="MMA/OMS"},
    @{Service="elastic-agent"; Name="Elastic"},
    @{Service="winlogbeat"; Name="Winlogbeat"},
    @{Service="datadogagent"; Name="Datadog"},
    @{Service="WinCollect"; Name="QRadar"},
    @{Service="sumo-collector"; Name="Sumo Logic"},
    @{Service="nxlog"; Name="NXLog"}
)

$runningSIEM = @()
foreach ($siem in $siemProducts) {
    $svc = Get-Service -Name $siem.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningSIEM += $siem.Name
    }
}

# Check WEF as a forwarding mechanism
$wef = Get-Service -Name "wecsvc" -ErrorAction SilentlyContinue
if ($wef -and $wef.Status -eq "Running") {
    $runningSIEM += "WEF"
}

if ($runningSIEM.Count -ge 1) {
    Register-Check -Name "SIEM Coverage" -Status PASS -Message "Forwarding to: $($runningSIEM -join ', ')"
} else {
    Register-Check -Name "SIEM Coverage" -Status WARN -Message "No log forwarding agent detected"
}

# Check Windows Event Log service
try {
    $eventLog = Get-Service -Name "EventLog" -ErrorAction SilentlyContinue
    if ($eventLog -and $eventLog.Status -eq "Running") {
        Register-Check -Name "Windows Event Log" -Status PASS -Message "Running (local logging active)"
    } else {
        Register-Check -Name "Windows Event Log" -Status FAIL -Message "Not running - critical issue"
    }
} catch {
    Register-Check -Name "Windows Event Log" -Status FAIL -Message "Unable to check"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
