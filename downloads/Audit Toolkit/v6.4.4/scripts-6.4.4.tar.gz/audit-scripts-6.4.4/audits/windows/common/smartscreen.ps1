# Check SmartScreen Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -ErrorAction SilentlyContinue
    if ($reg.SmartScreenEnabled -eq 'RequireAdmin') {
        Register-Check -Name "SmartScreen" -Status PASS -Message "SmartScreen is enabled."
    } else {
        Register-Check -Name "SmartScreen" -Status FAIL -Message "SmartScreen is not enabled."
    }
} catch {
    Register-Check -Name "SmartScreen" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit