# SMB Configuration Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - SMB Protocol Security
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 2.3.8.x, 18.3.x
# - Microsoft SMB Security: https://learn.microsoft.com/en-us/windows-server/storage/file-server/smb-security

Import-Module "$PSScriptRoot/common-audit.psm1"

# Check SMBv1 Protocol - CIS 18.3.3
try {
    $smb1 = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction SilentlyContinue | Select-Object -ExpandProperty State
    if ($smb1 -eq 'Disabled') {
        Register-Check -Name "SMBv1 Protocol" -Status PASS -Message "SMBv1 is disabled"
    } elseif ($smb1 -eq 'Enabled') {
        Register-Check -Name "SMBv1 Protocol" -Status FAIL -Message "SMBv1 is enabled - disable for security"
    } else {
        # Try alternate method for Server
        $smb1Server = Get-SmbServerConfiguration -ErrorAction SilentlyContinue | Select-Object -ExpandProperty EnableSMB1Protocol
        if ($smb1Server -eq $false) {
            Register-Check -Name "SMBv1 Protocol" -Status PASS -Message "SMBv1 is disabled"
        } else {
            Register-Check -Name "SMBv1 Protocol" -Status FAIL -Message "SMBv1 may be enabled"
        }
    }
} catch {
    Register-Check -Name "SMBv1 Protocol" -Status WARN -Message "Could not determine SMBv1 status: $($_.Exception.Message)"
}

# Check SMB Server Signing - CIS 2.3.8.1, 2.3.8.2
try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction Stop

    # RequireSecuritySignature - CIS 2.3.8.1
    if ($smbConfig.RequireSecuritySignature) {
        Register-Check -Name "SMB Server Signing Required" -Status PASS -Message "SMB server requires signing"
    } else {
        Register-Check -Name "SMB Server Signing Required" -Status FAIL -Message "SMB server signing not required"
    }

    # EnableSecuritySignature - CIS 2.3.8.2
    if ($smbConfig.EnableSecuritySignature) {
        Register-Check -Name "SMB Server Signing Enabled" -Status PASS -Message "SMB server signing is enabled"
    } else {
        Register-Check -Name "SMB Server Signing Enabled" -Status WARN -Message "SMB server signing not enabled"
    }

    # Encryption
    if ($smbConfig.EncryptData) {
        Register-Check -Name "SMB Encryption" -Status PASS -Message "SMB encryption is enabled"
    } else {
        Register-Check -Name "SMB Encryption" -Status WARN -Message "SMB encryption not enabled - consider for sensitive data"
    }
} catch {
    Register-Check -Name "SMB Server Signing" -Status WARN -Message "Could not check server SMB config: $($_.Exception.Message)"
}

# Check SMB Client Signing - CIS 2.3.8.3, 2.3.8.4
try {
    $clientReqSign = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -ErrorAction SilentlyContinue
    if ($clientReqSign.RequireSecuritySignature -eq 1) {
        Register-Check -Name "SMB Client Signing Required" -Status PASS -Message "SMB client requires signing"
    } else {
        Register-Check -Name "SMB Client Signing Required" -Status FAIL -Message "SMB client signing not required"
    }

    $clientEnSign = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "EnableSecuritySignature" -ErrorAction SilentlyContinue
    if ($clientEnSign.EnableSecuritySignature -eq 1) {
        Register-Check -Name "SMB Client Signing Enabled" -Status PASS -Message "SMB client signing is enabled"
    } else {
        Register-Check -Name "SMB Client Signing Enabled" -Status WARN -Message "SMB client signing not enabled"
    }
} catch {
    Register-Check -Name "SMB Client Signing" -Status WARN -Message "Could not check client SMB settings"
}

Print-Summary
Exit-Audit