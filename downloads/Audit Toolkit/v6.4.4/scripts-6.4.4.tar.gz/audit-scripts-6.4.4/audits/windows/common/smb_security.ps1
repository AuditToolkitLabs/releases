<#
.SYNOPSIS
    SMB Security Hardening Audit

.DESCRIPTION
    Comprehensive SMB (Server Message Block) security audit:
    - SMB protocol versions
    - SMB signing requirements
    - SMB encryption
    - Guest/null session access
    - Share permissions
    - Administrative share exposure

.NOTES
    Requires: Administrator privileges for full checks

Compliance Mapping:
- CIS Controls: 3.10 (Encrypt Sensitive Data in Transit)
- CIS Windows Benchmark: 2.3.9.x (SMB Client/Server Settings)
- NIST SP 800-53: SC-8 (Transmission Confidentiality)
- MITRE ATT&CK: T1021.002 (SMB/Windows Admin Shares)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "SMB Security Audit"

# ============================================================================
# SMB SERVER SERVICE
# ============================================================================
Write-Section "SMB Server Service"

try {
    $smbSvc = Get-Service -Name LanmanServer -ErrorAction SilentlyContinue
    if ($smbSvc.Status -eq 'Running') {
        Register-Check -Name "SMB Server" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "SMB Server" -Status WARN -Message "Status: $($smbSvc.Status)"
    }
} catch {
    Register-Check -Name "SMB Server" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# SMB PROTOCOL VERSIONS
# ============================================================================
Write-Section "SMB Protocol Versions"

# SMBv1 - Should be DISABLED
try {
    # Check via Get-SmbServerConfiguration
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        if ($smbConfig.EnableSMB1Protocol -eq $false) {
            Register-Check -Name "SMBv1 Server" -Status PASS -Message "Disabled"
        } else {
            Register-Check -Name "SMBv1 Server" -Status FAIL -Message "Enabled - critical security risk (EternalBlue)"
        }

        if ($smbConfig.EnableSMB2Protocol -eq $true) {
            Register-Check -Name "SMBv2/v3 Server" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "SMBv2/v3 Server" -Status FAIL -Message "Disabled"
        }
    }
} catch {
    # Fallback to registry check
    try {
        $smb1Path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
        $smb1Reg = Get-ItemProperty $smb1Path -Name "SMB1" -ErrorAction SilentlyContinue

        if ($smb1Reg.SMB1 -eq 0) {
            Register-Check -Name "SMBv1 Server" -Status PASS -Message "Disabled via registry"
        } else {
            Register-Check -Name "SMBv1 Server" -Status FAIL -Message "Enabled via registry"
        }
    } catch {
        Register-Check -Name "SMBv1 Server" -Status WARN -Message "Cannot determine"
    }
}

# Check SMBv1 client
try {
    $smb1Client = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\mrxsmb10" -Name "Start" -ErrorAction SilentlyContinue
    if ($smb1Client.Start -eq 4) {
        Register-Check -Name "SMBv1 Client" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "SMBv1 Client" -Status WARN -Message "Enabled (Start=$($smb1Client.Start))"
    }
} catch {
    Register-Check -Name "SMBv1 Client" -Status WARN -Message "Cannot determine"
}

# Check Windows Feature for SMBv1
try {
    $smb1Feature = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -ErrorAction SilentlyContinue
    if ($smb1Feature) {
        if ($smb1Feature.State -eq "Disabled") {
            Register-Check -Name "SMBv1 Feature" -Status PASS -Message "Feature removed"
        } else {
            Register-Check -Name "SMBv1 Feature" -Status WARN -Message "Feature installed"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SMB SIGNING
# ============================================================================
Write-Section "SMB Signing"

# Server signing - CIS 2.3.9.1 & 2.3.9.2
try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        if ($smbConfig.RequireSecuritySignature -eq $true) {
            Register-Check -Name "SMB Server Signing" -Status PASS -Message "Required"
        } else {
            Register-Check -Name "SMB Server Signing" -Status FAIL -Message "Not required - relay attacks possible"
        }

        if ($smbConfig.EnableSecuritySignature -eq $true) {
            Register-Check -Name "SMB Server Signing Enabled" -Status PASS -Message "Enabled"
        }
    }
} catch {
    # Registry fallback
    try {
        $serverPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
        $reqSign = Get-ItemProperty $serverPath -Name "RequireSecuritySignature" -ErrorAction SilentlyContinue

        if ($reqSign.RequireSecuritySignature -eq 1) {
            Register-Check -Name "SMB Server Signing" -Status PASS -Message "Required"
        } else {
            Register-Check -Name "SMB Server Signing" -Status FAIL -Message "Not required"
        }
    } catch {
        Register-Check -Name "SMB Server Signing" -Status WARN -Message "Cannot determine"
    }
}

# Client signing - CIS 2.3.9.3 & 2.3.9.4
try {
    $clientPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
    $clientReq = Get-ItemProperty $clientPath -Name "RequireSecuritySignature" -ErrorAction SilentlyContinue
    $clientEn = Get-ItemProperty $clientPath -Name "EnableSecuritySignature" -ErrorAction SilentlyContinue

    if ($clientReq.RequireSecuritySignature -eq 1) {
        Register-Check -Name "SMB Client Signing" -Status PASS -Message "Required"
    } else {
        Register-Check -Name "SMB Client Signing" -Status WARN -Message "Not required"
    }

    if ($clientEn.EnableSecuritySignature -eq 1) {
        Register-Check -Name "SMB Client Signing Enabled" -Status PASS -Message "Enabled"
    }
} catch {
    Register-Check -Name "SMB Client Signing" -Status WARN -Message "Cannot determine"
}

# ============================================================================
# SMB ENCRYPTION
# ============================================================================
Write-Section "SMB Encryption"

try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        # Encryption enabled
        if ($smbConfig.EncryptData -eq $true) {
            Register-Check -Name "SMB Encryption" -Status PASS -Message "Enabled (all shares)"
        } else {
            Register-Check -Name "SMB Encryption" -Status WARN -Message "Not enforced globally"
        }

        # Reject unencrypted access
        if ($smbConfig.RejectUnencryptedAccess -eq $true) {
            Register-Check -Name "Reject Unencrypted" -Status PASS -Message "Unencrypted access blocked"
        } else {
            Register-Check -Name "Reject Unencrypted" -Status WARN -Message "Unencrypted access allowed"
        }
    }
} catch {
    Register-Check -Name "SMB Encryption" -Status SKIP -Message "Cannot determine"
}

# Check per-share encryption
try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Special -eq $false }
    $encryptedShares = $shares | Where-Object { $_.EncryptData -eq $true }

    if ($shares) {
        $totalShares = @($shares).Count
        $encCount = @($encryptedShares).Count

        if ($encCount -eq $totalShares -and $totalShares -gt 0) {
            Register-Check -Name "Per-Share Encryption" -Status PASS -Message "All $totalShares shares encrypted"
        } elseif ($encCount -gt 0) {
            Register-Check -Name "Per-Share Encryption" -Status WARN -Message "$encCount of $totalShares shares encrypted"
        } else {
            Register-Check -Name "Per-Share Encryption" -Status INFO -Message "No shares with encryption required"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# NULL/GUEST SESSION ACCESS
# ============================================================================
Write-Section "Anonymous/Guest Access"

# Restrict anonymous access - CIS 2.3.10.x
try {
    $lsaPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"

    # Restrict anonymous enumeration of SAM accounts
    $restrictSam = Get-ItemProperty $lsaPath -Name "RestrictAnonymousSAM" -ErrorAction SilentlyContinue
    if ($restrictSam.RestrictAnonymousSAM -eq 1) {
        Register-Check -Name "Anonymous SAM Enum" -Status PASS -Message "Restricted"
    } else {
        Register-Check -Name "Anonymous SAM Enum" -Status FAIL -Message "Allowed"
    }

    # Restrict anonymous access to shares
    $restrictAnon = Get-ItemProperty $lsaPath -Name "RestrictAnonymous" -ErrorAction SilentlyContinue
    if ($restrictAnon.RestrictAnonymous -ge 1) {
        Register-Check -Name "Anonymous Access" -Status PASS -Message "Restricted (Level $($restrictAnon.RestrictAnonymous))"
    } else {
        Register-Check -Name "Anonymous Access" -Status FAIL -Message "Not restricted"
    }

    # EveryoneIncludesAnonymous
    $everyoneAnon = Get-ItemProperty $lsaPath -Name "EveryoneIncludesAnonymous" -ErrorAction SilentlyContinue
    if ($everyoneAnon.EveryoneIncludesAnonymous -eq 0) {
        Register-Check -Name "Everyone Includes Anonymous" -Status PASS -Message "No"
    } else {
        Register-Check -Name "Everyone Includes Anonymous" -Status FAIL -Message "Yes - security risk"
    }
} catch {
    Register-Check -Name "Anonymous Access" -Status WARN -Message "Cannot query"
}

# Named pipes accessible anonymously
try {
    $nullPipes = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "NullSessionPipes" -ErrorAction SilentlyContinue
    if ($nullPipes.NullSessionPipes) {
        $pipeCount = @($nullPipes.NullSessionPipes).Count
        if ($pipeCount -gt 0) {
            Register-Check -Name "Null Session Pipes" -Status WARN -Message "$pipeCount pipe(s) accessible anonymously"
        } else {
            Register-Check -Name "Null Session Pipes" -Status PASS -Message "None"
        }
    } else {
        Register-Check -Name "Null Session Pipes" -Status PASS -Message "None configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Null session shares
try {
    $nullShares = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "NullSessionShares" -ErrorAction SilentlyContinue
    if ($nullShares.NullSessionShares) {
        $shareCount = @($nullShares.NullSessionShares).Count
        if ($shareCount -gt 0) {
            Register-Check -Name "Null Session Shares" -Status FAIL -Message "$shareCount share(s) accessible anonymously"
        } else {
            Register-Check -Name "Null Session Shares" -Status PASS -Message "None"
        }
    } else {
        Register-Check -Name "Null Session Shares" -Status PASS -Message "None configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ADMINISTRATIVE SHARES
# ============================================================================
Write-Section "Administrative Shares"

try {
    $adminShares = Get-SmbShare -Special $true -ErrorAction SilentlyContinue

    $cDriveShare = $adminShares | Where-Object { $_.Name -eq 'C$' }
    $adminShare = $adminShares | Where-Object { $_.Name -eq 'ADMIN$' }

    if ($cDriveShare) {
        Register-Check -Name 'C$ Share' -Status WARN -Message "Present (used by admin tools, lateral movement risk)"
    } else {
        Register-Check -Name 'C$ Share' -Status PASS -Message "Disabled"
    }

    if ($adminShare) {
        Register-Check -Name 'ADMIN$ Share' -Status WARN -Message "Present"
    }

    # Check AutoShareServer/AutoShareWks
    $serverParams = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
    $autoShare = Get-ItemProperty $serverParams -Name "AutoShareServer" -ErrorAction SilentlyContinue
    $autoShareWks = Get-ItemProperty $serverParams -Name "AutoShareWks" -ErrorAction SilentlyContinue

    if ($autoShare.AutoShareServer -eq 0 -or $autoShareWks.AutoShareWks -eq 0) {
        Register-Check -Name "Admin Shares Auto-Create" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Admin Shares Auto-Create" -Status INFO -Message "Enabled (default)"
    }
} catch {
    Register-Check -Name "Administrative Shares" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# SHARE PERMISSIONS
# ============================================================================
Write-Section "Share Permissions"

try {
    $userShares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Special -eq $false }

    foreach ($share in $userShares | Select-Object -First 10) {
        $perms = Get-SmbShareAccess -Name $share.Name -ErrorAction SilentlyContinue

        # Check for Everyone with Full access
        $everyoneFull = $perms | Where-Object {
            $_.AccountName -match "Everyone" -and $_.AccessRight -eq "Full"
        }

        if ($everyoneFull) {
            Register-Check -Name "Share: $($share.Name)" -Status FAIL -Message "Everyone has Full access"
        }

        # Check for Everyone with Change access
        $everyoneChange = $perms | Where-Object {
            $_.AccountName -match "Everyone" -and $_.AccessRight -eq "Change"
        }

        if ($everyoneChange) {
            Register-Check -Name "Share: $($share.Name)" -Status WARN -Message "Everyone has Change access"
        }
    }

    if (($userShares | Measure-Object).Count -gt 0) {
        Register-Check -Name "User Shares" -Status INFO -Message "$(@($userShares).Count) non-system share(s)"
    }
} catch {
    Register-Check -Name "Share Permissions" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# SMB COMPRESSION (CVE-2020-0796)
# ============================================================================
Write-Section "SMB Compression"

try {
    # Check if SMB compression is disabled (mitigates SMBGhost)
    $compressionPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
    $compression = Get-ItemProperty $compressionPath -Name "DisableCompression" -ErrorAction SilentlyContinue

    if ($compression.DisableCompression -eq 1) {
        Register-Check -Name "SMB Compression" -Status PASS -Message "Disabled (SMBGhost mitigation)"
    } else {
        # Check Windows version - only affects some builds
        $build = [System.Environment]::OSVersion.Version.Build
        if ($build -ge 18362 -and $build -lt 19041) {
            Register-Check -Name "SMB Compression" -Status WARN -Message "Enabled - verify patched for CVE-2020-0796"
        } else {
            Register-Check -Name "SMB Compression" -Status INFO -Message "Enabled (check if patched)"
        }
    }
} catch {
    Register-Check -Name "SMB Compression" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# SMB INSECURE GUEST LOGON
# ============================================================================
Write-Section "Insecure Guest Logon"

try {
    $guestPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
    $insecureGuest = Get-ItemProperty $guestPath -Name "AllowInsecureGuestAuth" -ErrorAction SilentlyContinue

    if ($insecureGuest.AllowInsecureGuestAuth -eq 0) {
        Register-Check -Name "Insecure Guest Auth" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Insecure Guest Auth" -Status FAIL -Message "Enabled - allows unauthenticated access"
    }
} catch {
    Register-Check -Name "Insecure Guest Auth" -Status WARN -Message "Cannot determine"
}

# ============================================================================
# ACTIVE SMB SESSIONS
# ============================================================================
Write-Section "Active Sessions"

try {
    $sessions = Get-SmbSession -ErrorAction SilentlyContinue
    $sessionCount = @($sessions).Count

    Register-Check -Name "Active SMB Sessions" -Status INFO -Message "$sessionCount session(s)"

    if ($sessionCount -gt 0) {
        # Check for sessions from unusual users
        $uniqueUsers = $sessions | Select-Object -ExpandProperty ClientUserName -Unique
        Write-Output "    Connected users: $($uniqueUsers -join ', ')"
    }
} catch {
    Register-Check -Name "Active Sessions" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
