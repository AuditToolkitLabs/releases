# System Services Audit Script (PowerShell)
# Comprehensive CIS Windows Benchmark - System Services (5.x)
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 5.x (40+ service controls)
# - CIS Windows Server 2022: 5.x
# - Microsoft Security Baselines

Import-Module "$PSScriptRoot/common-audit.psm1"

function Test-ServiceStartType {
    param(
        [string]$ServiceName,
        [string]$DisplayName,
        [string]$CISRef,
        [string]$ExpectedStartType,  # Disabled, Manual, Automatic
        [string]$Reason
    )

    $null = $CISRef

    try {
        $service = Get-Service -Name $ServiceName -ErrorAction Stop
        $startType = (Get-CimInstance -Query "SELECT StartMode FROM Win32_Service WHERE Name='$ServiceName'" -ErrorAction SilentlyContinue).StartMode

        $checkName = if ($DisplayName) { $DisplayName } else { $ServiceName }

        if ($ExpectedStartType -eq "Disabled") {
            if ($startType -eq "Disabled") {
                Register-Check -Name $checkName -Status PASS -Message "Disabled"
            } elseif ($service.Status -eq "Stopped") {
                Register-Check -Name $checkName -Status WARN -Message "Stopped but not disabled ($startType)"
            } else {
                Register-Check -Name $checkName -Status FAIL -Message "Running ($startType) - $Reason"
            }
        } elseif ($ExpectedStartType -eq "Manual") {
            if ($startType -eq "Disabled" -or $startType -eq "Manual") {
                Register-Check -Name $checkName -Status PASS -Message $startType
            } else {
                Register-Check -Name $checkName -Status WARN -Message "Auto-start ($startType)"
            }
        } else {
            Register-Check -Name $checkName -Status INFO -Message "$startType"
        }
    } catch {
        # Service doesn't exist - generally good for security-risk services
        if ($ExpectedStartType -eq "Disabled") {
            Register-Check -Name $checkName -Status PASS -Message "Not installed"
        } else {
            Register-Check -Name $checkName -Status SKIP -Message "Not found"
        }
    }
}

# ============================================================================
# CIS 5.1-5.10: REMOTE ACCESS & NETWORK SERVICES
# ============================================================================
Write-Section "Remote Access & Network Services"

# CIS 5.1 - Bluetooth Support Service
Test-ServiceStartType -ServiceName "bthserv" -DisplayName "Bluetooth Support" `
    -CISRef "5.1" -ExpectedStartType "Disabled" -Reason "Attack surface"

# CIS 5.2 - Computer Browser
Test-ServiceStartType -ServiceName "Browser" -DisplayName "Computer Browser" `
    -CISRef "5.2" -ExpectedStartType "Disabled" -Reason "Legacy protocol"

# CIS 5.3 - Downloaded Maps Manager
Test-ServiceStartType -ServiceName "MapsBroker" -DisplayName "Downloaded Maps Manager" `
    -CISRef "5.3" -ExpectedStartType "Disabled" -Reason "Unnecessary"

# CIS 5.4 - Geolocation Service
Test-ServiceStartType -ServiceName "lfsvc" -DisplayName "Geolocation Service" `
    -CISRef "5.4" -ExpectedStartType "Disabled" -Reason "Privacy concern"

# CIS 5.5 - IIS Admin Service
Test-ServiceStartType -ServiceName "IISADMIN" -DisplayName "IIS Admin Service" `
    -CISRef "5.5" -ExpectedStartType "Disabled" -Reason "Only needed for IIS"

# CIS 5.6 - Infrared Monitor Service
Test-ServiceStartType -ServiceName "irmon" -DisplayName "Infrared Monitor" `
    -CISRef "5.6" -ExpectedStartType "Disabled" -Reason "Legacy hardware"

# CIS 5.7 - Internet Connection Sharing
Test-ServiceStartType -ServiceName "SharedAccess" -DisplayName "Internet Connection Sharing" `
    -CISRef "5.7" -ExpectedStartType "Disabled" -Reason "Network security risk"

# CIS 5.8 - Link-Layer Topology Discovery Mapper
Test-ServiceStartType -ServiceName "lltdsvc" -DisplayName "LLTD Mapper" `
    -CISRef "5.8" -ExpectedStartType "Disabled" -Reason "Network discovery"

# CIS 5.9 - LxssManager (WSL)
Test-ServiceStartType -ServiceName "LxssManager" -DisplayName "WSL Service" `
    -CISRef "5.9" -ExpectedStartType "Disabled" -Reason "Linux subsystem - attack surface"

# CIS 5.10 - Microsoft FTP Service
Test-ServiceStartType -ServiceName "FTPSVC" -DisplayName "FTP Service" `
    -CISRef "5.10" -ExpectedStartType "Disabled" -Reason "Insecure protocol"

# ============================================================================
# CIS 5.11-5.20: PUBLISHING & MEDIA SERVICES
# ============================================================================
Write-Section "Publishing & Media Services"

# CIS 5.11 - Microsoft iSCSI Initiator Service
Test-ServiceStartType -ServiceName "MSiSCSI" -DisplayName "iSCSI Initiator" `
    -CISRef "5.11" -ExpectedStartType "Disabled" -Reason "Unless iSCSI storage used"

# CIS 5.12 - OpenSSH SSH Server
Test-ServiceStartType -ServiceName "sshd" -DisplayName "OpenSSH Server" `
    -CISRef "5.12" -ExpectedStartType "Disabled" -Reason "Remote access if not needed"

# CIS 5.13 - Peer Name Resolution Protocol
Test-ServiceStartType -ServiceName "PNRPsvc" -DisplayName "PNRP Service" `
    -CISRef "5.13" -ExpectedStartType "Disabled" -Reason "P2P networking"

# CIS 5.14 - Peer Networking Grouping
Test-ServiceStartType -ServiceName "p2psvc" -DisplayName "Peer Networking Grouping" `
    -CISRef "5.14" -ExpectedStartType "Disabled" -Reason "P2P networking"

# CIS 5.15 - Peer Networking Identity Manager
Test-ServiceStartType -ServiceName "p2pimsvc" -DisplayName "PNRP Identity Manager" `
    -CISRef "5.15" -ExpectedStartType "Disabled" -Reason "P2P networking"

# CIS 5.16 - PNRP Machine Name Publication Service
Test-ServiceStartType -ServiceName "PNRPAutoReg" -DisplayName "PNRP Machine Name Pub" `
    -CISRef "5.16" -ExpectedStartType "Disabled" -Reason "P2P networking"

# CIS 5.17 - Problem Reports Control Panel Support
# Removed in recent Windows

# CIS 5.18 - Remote Access Auto Connection Manager
Test-ServiceStartType -ServiceName "RasAuto" -DisplayName "Remote Access Auto Connect" `
    -CISRef "5.18" -ExpectedStartType "Disabled" -Reason "Automatic VPN dial"

# CIS 5.19 - Remote Desktop Configuration
Test-ServiceStartType -ServiceName "SessionEnv" -DisplayName "RD Configuration" `
    -CISRef "5.19" -ExpectedStartType "Manual" -Reason "Only if RDP needed"

# CIS 5.20 - Remote Desktop Services
Test-ServiceStartType -ServiceName "TermService" -DisplayName "Remote Desktop Services" `
    -CISRef "5.20" -ExpectedStartType "Manual" -Reason "Disable if not needed"

# ============================================================================
# CIS 5.21-5.30: REMOTE & AUXILIARY SERVICES
# ============================================================================
Write-Section "Remote & Auxiliary Services"

# CIS 5.21 - Remote Desktop UserMode Port Redirector
Test-ServiceStartType -ServiceName "UmRdpService" -DisplayName "RD Port Redirector" `
    -CISRef "5.21" -ExpectedStartType "Disabled" -Reason "RDP device redirection"

# CIS 5.22 - Remote Procedure Call (RPC) Locator
Test-ServiceStartType -ServiceName "RpcLocator" -DisplayName "RPC Locator" `
    -CISRef "5.22" -ExpectedStartType "Disabled" -Reason "Legacy RPC"

# CIS 5.23 - Remote Registry
Test-ServiceStartType -ServiceName "RemoteRegistry" -DisplayName "Remote Registry" `
    -CISRef "5.23" -ExpectedStartType "Disabled" -Reason "Remote registry access"

# CIS 5.24 - Routing and Remote Access
Test-ServiceStartType -ServiceName "RemoteAccess" -DisplayName "Routing and Remote Access" `
    -CISRef "5.24" -ExpectedStartType "Disabled" -Reason "VPN/routing server"

# CIS 5.25 - Server (LanManServer)
Test-ServiceStartType -ServiceName "LanmanServer" -DisplayName "Server (File Sharing)" `
    -CISRef "5.25" -ExpectedStartType "Manual" -Reason "File sharing - disable if not needed"

# CIS 5.26 - Simple TCP/IP Services
Test-ServiceStartType -ServiceName "simptcp" -DisplayName "Simple TCP/IP Services" `
    -CISRef "5.26" -ExpectedStartType "Disabled" -Reason "Legacy services"

# CIS 5.27 - SNMP Service
Test-ServiceStartType -ServiceName "SNMP" -DisplayName "SNMP Service" `
    -CISRef "5.27" -ExpectedStartType "Disabled" -Reason "Information disclosure"

# CIS 5.28 - Special Administration Console Helper
Test-ServiceStartType -ServiceName "sacsvr" -DisplayName "SAC Helper" `
    -CISRef "5.28" -ExpectedStartType "Disabled" -Reason "EMS console"

# CIS 5.29 - SSDP Discovery
Test-ServiceStartType -ServiceName "SSDPSRV" -DisplayName "SSDP Discovery" `
    -CISRef "5.29" -ExpectedStartType "Disabled" -Reason "UPnP discovery"

# CIS 5.30 - Telnet
Test-ServiceStartType -ServiceName "TlntSvr" -DisplayName "Telnet" `
    -CISRef "5.30" -ExpectedStartType "Disabled" -Reason "Insecure plaintext"

# ============================================================================
# CIS 5.31-5.40: SUBSYSTEM & LEGACY SERVICES
# ============================================================================
Write-Section "Subsystem & Legacy Services"

# CIS 5.31 - UPnP Device Host
Test-ServiceStartType -ServiceName "upnphost" -DisplayName "UPnP Device Host" `
    -CISRef "5.31" -ExpectedStartType "Disabled" -Reason "UPnP vulnerabilities"

# CIS 5.32 - Web Management Service
Test-ServiceStartType -ServiceName "WMSvc" -DisplayName "Web Management Service" `
    -CISRef "5.32" -ExpectedStartType "Disabled" -Reason "IIS remote management"

# CIS 5.33 - Windows Error Reporting Service
Test-ServiceStartType -ServiceName "WerSvc" -DisplayName "Windows Error Reporting" `
    -CISRef "5.33" -ExpectedStartType "Disabled" -Reason "Data exfiltration concerns"

# CIS 5.34 - Windows Event Collector
Test-ServiceStartType -ServiceName "Wecsvc" -DisplayName "Windows Event Collector" `
    -CISRef "5.34" -ExpectedStartType "Manual" -Reason "Only for event forwarding"

# CIS 5.35 - Windows Media Player Network Sharing Service
Test-ServiceStartType -ServiceName "WMPNetworkSvc" -DisplayName "WMP Network Sharing" `
    -CISRef "5.35" -ExpectedStartType "Disabled" -Reason "Media streaming"

# CIS 5.36 - Windows Mobile Hotspot Service
Test-ServiceStartType -ServiceName "icssvc" -DisplayName "Mobile Hotspot" `
    -CISRef "5.36" -ExpectedStartType "Disabled" -Reason "Hotspot sharing"

# CIS 5.37 - Windows Push Notifications System Service
Test-ServiceStartType -ServiceName "WpnService" -DisplayName "Push Notifications" `
    -CISRef "5.37" -ExpectedStartType "Manual" -Reason "Disable in high-security"

# CIS 5.38 - Windows Remote Management (WS-Management)
Test-ServiceStartType -ServiceName "WinRM" -DisplayName "WinRM" `
    -CISRef "5.38" -ExpectedStartType "Manual" -Reason "Remote PowerShell - secure carefully"

# CIS 5.39 - World Wide Web Publishing Service
Test-ServiceStartType -ServiceName "W3SVC" -DisplayName "WWW Publishing (IIS)" `
    -CISRef "5.39" -ExpectedStartType "Disabled" -Reason "Web server if not needed"

# CIS 5.40 - Xbox Services (multiple)
Test-ServiceStartType -ServiceName "XblAuthManager" -DisplayName "Xbox Live Auth" `
    -CISRef "5.40" -ExpectedStartType "Disabled" -Reason "Gaming services"
Test-ServiceStartType -ServiceName "XblGameSave" -DisplayName "Xbox Game Save" `
    -CISRef "5.40" -ExpectedStartType "Disabled" -Reason "Gaming services"
Test-ServiceStartType -ServiceName "XboxNetApiSvc" -DisplayName "Xbox Net API" `
    -CISRef "5.40" -ExpectedStartType "Disabled" -Reason "Gaming services"

# ============================================================================
# ADDITIONAL HIGH-RISK SERVICES
# ============================================================================
Write-Section "Additional High-Risk Services"

# Print Spooler (PrintNightmare)
Test-ServiceStartType -ServiceName "Spooler" -DisplayName "Print Spooler" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "PrintNightmare - disable if printing not needed"

# Fax Service
Test-ServiceStartType -ServiceName "Fax" -DisplayName "Fax Service" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "Legacy fax"

# TFTP
Test-ServiceStartType -ServiceName "tftpd" -DisplayName "TFTP Daemon" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "Insecure file transfer"

# NetBIOS over TCP
Test-ServiceStartType -ServiceName "Netbt" -DisplayName "NetBIOS over TCP" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "Legacy protocol"

# LLMNR/mDNS (often via registry but service related)
Test-ServiceStartType -ServiceName "Dnscache" -DisplayName "DNS Client" `
    -CISRef "Extra" -ExpectedStartType "Automatic" -Reason "Required but check LLMNR settings"

# Windows Search (indexing)
Test-ServiceStartType -ServiceName "WSearch" -DisplayName "Windows Search" `
    -CISRef "Extra" -ExpectedStartType "Manual" -Reason "Attack surface via search protocol handlers"

# Connected User Experiences and Telemetry
Test-ServiceStartType -ServiceName "DiagTrack" -DisplayName "Connected User Telemetry" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "Telemetry data collection"

# Windows Insider Service
Test-ServiceStartType -ServiceName "wisvc" -DisplayName "Windows Insider Service" `
    -CISRef "Extra" -ExpectedStartType "Disabled" -Reason "Preview builds"

# ============================================================================
# CRITICAL SECURITY SERVICES (Should be Running)
# ============================================================================
Write-Section "Critical Security Services"

$criticalServices = @(
    @{Name="EventLog"; Display="Windows Event Log"},
    @{Name="MpsSvc"; Display="Windows Firewall"},
    @{Name="WinDefend"; Display="Windows Defender"},
    @{Name="SamSs"; Display="Security Accounts Manager"},
    @{Name="SENS"; Display="System Event Notification"},
    @{Name="Schedule"; Display="Task Scheduler"},
    @{Name="CryptSvc"; Display="Cryptographic Services"},
    @{Name="Netlogon"; Display="Netlogon"},
    @{Name="W32Time"; Display="Windows Time"}
)

foreach ($svc in $criticalServices) {
    try {
        $service = Get-Service -Name $svc.Name -ErrorAction Stop
        if ($service.Status -eq "Running") {
            Register-Check -Name $svc.Display -Status PASS -Message "Running"
        } else {
            Register-Check -Name $svc.Display -Status FAIL -Message "Not running ($($service.Status))"
        }
    } catch {
        Register-Check -Name $svc.Display -Status WARN -Message "Not found"
    }
}

# ============================================================================
# SERVICE ACCOUNT SECURITY
# ============================================================================
Write-Section "Service Account Security"

# Count services running as LocalSystem (highest privilege)
try {
    $localSystemServices = Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue | Where-Object {
        $_.StartName -eq "LocalSystem" -and
        $_.State -eq "Running"
    }

    $count = ($localSystemServices | Measure-Object).Count

    if ($count -le 20) {
        Register-Check -Name "LocalSystem Services" -Status PASS -Message "$count running as SYSTEM"
    } elseif ($count -le 40) {
        Register-Check -Name "LocalSystem Services" -Status INFO -Message "$count running as SYSTEM"
    } else {
        Register-Check -Name "LocalSystem Services" -Status WARN -Message "$count services as SYSTEM - review needed"
    }
} catch {
    Register-Check -Name "LocalSystem Services" -Status SKIP -Message "Cannot enumerate"
}

# Services running as a domain account
try {
    $domainServices = Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue | Where-Object {
        $_.StartName -and
        $_.StartName -notmatch 'LocalSystem|LocalService|NetworkService|NT AUTHORITY|NT SERVICE'
    }

    $domainCount = ($domainServices | Measure-Object).Count

    if ($domainCount -eq 0) {
        Register-Check -Name "Domain Account Services" -Status INFO -Message "None found"
    } else {
        Register-Check -Name "Domain Account Services" -Status INFO -Message "$domainCount service(s) use domain accounts"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
