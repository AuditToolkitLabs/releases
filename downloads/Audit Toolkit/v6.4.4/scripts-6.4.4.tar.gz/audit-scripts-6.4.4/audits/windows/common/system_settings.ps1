# System Settings Audit Script (PowerShell)
# Checks CIS 18.8.x System security settings
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Windows 11 Benchmark v2.0 - Section 18.8
# - NIST SP 800-53: CM-6, CM-7, SC-28

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTION
# ============================================================================

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$ExpectedValue,
        [string]$Description,
        [string]$CISRef = "",
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual,
        [switch]$NotExist
    )

    $displayName = if ($CISRef) { "($CISRef) $Description" } else { $Description }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        if ($NotExist) {
            Register-Check -Name $displayName -Status WARN -Message "Value exists: $actualValue"
            return
        }

        $passed = $false
        if ($GreaterOrEqual) {
            $passed = $actualValue -ge $ExpectedValue
        } elseif ($LessOrEqual) {
            $passed = $actualValue -le $ExpectedValue
        } else {
            $passed = $actualValue -eq $ExpectedValue
        }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message "Value: $actualValue"
        } else {
            Register-Check -Name $displayName -Status WARN -Message "Value: $actualValue (expected: $ExpectedValue)"
        }
    } catch {
        if ($NotExist) {
            Register-Check -Name $displayName -Status PASS -Message "Not present (correct)"
        } else {
            Register-Check -Name $displayName -Status INFO -Message "Not configured"
        }
    }
}

# ============================================================================
# CIS 18.8.3 - Audit Process Creation
# ============================================================================
Write-Section "18.8.3 Audit Process Creation"

# 18.8.3.1 (L1) Ensure 'Include command line in process creation events'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" `
    -Name "ProcessCreationIncludeCmdLine_Enabled" -ExpectedValue 1 `
    -Description "Command line in audit events" -CISRef "18.8.3.1"

# ============================================================================
# CIS 18.8.4 - Credentials Delegation
# ============================================================================
Write-Section "18.8.4 Credentials Delegation"

# 18.8.4.1 (L1) Ensure 'Encryption Oracle Remediation' is set to 'Enabled: Force Updated Clients'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\CredSSP\Parameters" `
    -Name "AllowEncryptionOracle" -ExpectedValue 0 `
    -Description "CredSSP Encryption Oracle" -CISRef "18.8.4.1"

# 18.8.4.2 (L1) Ensure 'Remote host allows delegation of non-exportable credentials'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" `
    -Name "AllowProtectedCreds" -ExpectedValue 1 `
    -Description "Protected credentials delegation" -CISRef "18.8.4.2"

# ============================================================================
# CIS 18.8.5 - Device Guard
# ============================================================================
Write-Section "18.8.5 Device Guard"

# 18.8.5.1 (NG) Ensure 'Turn On Virtualization Based Security'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "EnableVirtualizationBasedSecurity" -ExpectedValue 1 `
    -Description "VBS enabled" -CISRef "18.8.5.1"

# 18.8.5.2 (NG) Ensure 'Turn On Virtualization Based Security: Select Platform Security Level'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "RequirePlatformSecurityFeatures" -ExpectedValue 3 `
    -Description "VBS Platform Security (UEFI+DMA)" -CISRef "18.8.5.2"

# 18.8.5.3 (NG) Ensure 'Virtualization Based Protection of Code Integrity'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "HypervisorEnforcedCodeIntegrity" -ExpectedValue 1 `
    -Description "HVCI enabled" -CISRef "18.8.5.3"

# 18.8.5.4 (NG) Ensure 'Require UEFI Memory Attributes Table'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "HVCIMATRequired" -ExpectedValue 1 `
    -Description "HVCI MAT Required" -CISRef "18.8.5.4"

# 18.8.5.5 (NG) Ensure 'Credential Guard Configuration'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "LsaCfgFlags" -ExpectedValue 1 `
    -Description "Credential Guard enabled" -CISRef "18.8.5.5"

# 18.8.5.6 (NG) Ensure 'Secure Launch Configuration'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "ConfigureSystemGuardLaunch" -ExpectedValue 1 `
    -Description "Secure Launch enabled" -CISRef "18.8.5.6"

# 18.8.5.7 (NG) Ensure 'Kernel-mode Hardware-enforced Stack Protection'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" `
    -Name "ConfigureKernelShadowStacksLaunch" -ExpectedValue 1 `
    -Description "Kernel Stack Protection" -CISRef "18.8.5.7"

# ============================================================================
# CIS 18.8.7 - Early Launch Antimalware
# ============================================================================
Write-Section "18.8.7 ELAM"

# 18.8.7.1.1 (L1) Ensure 'Boot-Start Driver Initialization Policy'
$elamPath = "HKLM:\SYSTEM\CurrentControlSet\Policies\EarlyLaunch"
$val = Get-ItemProperty -Path $elamPath -Name "DriverLoadPolicy" -ErrorAction SilentlyContinue
if ($val) {
    $policyText = switch ($val.DriverLoadPolicy) {
        0 { "Unknown" }
        1 { "Good only" }
        3 { "Good, unknown" }
        7 { "Good, unknown, bad but critical" }
        8 { "All" }
        default { "$($val.DriverLoadPolicy)" }
    }
    if ($val.DriverLoadPolicy -le 3) {
        Register-Check -Name "(18.8.7.1.1) ELAM Driver Policy" -Status PASS -Message $policyText
    } else {
        Register-Check -Name "(18.8.7.1.1) ELAM Driver Policy" -Status WARN -Message $policyText
    }
} else {
    Register-Check -Name "(18.8.7.1.1) ELAM Driver Policy" -Status INFO -Message "Not configured (defaults to Good+Unknown)"
}

# ============================================================================
# CIS 18.8.12 - Device Installation
# ============================================================================
Write-Section "18.8.12 Device Installation"

# 18.8.12.1 (BL) Ensure 'Allow installation of devices using drivers that match these device setup classes' is set to 'Enabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" `
    -Name "AllowDeviceClasses" -ExpectedValue 1 `
    -Description "Device class restrictions" -CISRef "18.8.12.1"

# 18.8.12.2 (L2) Ensure 'Prevent installation of devices using drivers that match these device setup classes'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" `
    -Name "DenyDeviceClasses" -ExpectedValue 1 `
    -Description "Deny device classes" -CISRef "18.8.12.2"

# ============================================================================
# CIS 18.8.14 - DMA Guard
# ============================================================================
Write-Section "18.8.14 DMA Guard"

# 18.8.14.1 (L1) Ensure 'Enumeration policy for external devices incompatible with Kernel DMA Protection'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Kernel DMA Protection" `
    -Name "DeviceEnumerationPolicy" -ExpectedValue 0 `
    -Description "Block external DMA devices" -CISRef "18.8.14.1"

# Check actual Kernel DMA Protection status
try {
    $dmaGuard = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace "root\Microsoft\Windows\DeviceGuard" -ErrorAction SilentlyContinue
    if ($dmaGuard.SecurityServicesRunning -contains 6) {
        Register-Check -Name "Kernel DMA Protection" -Status PASS -Message "Active"
    } else {
        Register-Check -Name "Kernel DMA Protection" -Status INFO -Message "Not active (may need UEFI support)"
    }
} catch {
    Register-Check -Name "Kernel DMA Protection" -Status INFO -Message "Status unknown"
}

# ============================================================================
# CIS 18.8.21 - File Explorer
# ============================================================================
Write-Section "18.8.21 File Explorer"

# 18.8.21.2 (L1) Ensure 'Configure Windows Defender SmartScreen'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "EnableSmartScreen" -ExpectedValue 1 `
    -Description "SmartScreen enabled" -CISRef "18.8.21.2"

# 18.8.21.3 (L1) Ensure 'Configure Windows Defender SmartScreen behavior'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "ShellSmartScreenLevel" -ExpectedValue "Block" `
    -Description "SmartScreen = Block" -CISRef "18.8.21.3"

# 18.8.21.4 (L1) Ensure 'Explore shell shortcuts for enhanced security'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" `
    -Name "EnableShellShortcutIconRemotePath" -ExpectedValue 0 `
    -Description "Remote shortcut icons disabled" -CISRef "18.8.21.4"

# ============================================================================
# CIS 18.8.22 - HomeGroup
# ============================================================================
Write-Section "18.8.22 HomeGroup"

# 18.8.22.1.1 (L1) Ensure 'Prevent the computer from joining a homegroup'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\HomeGroup" `
    -Name "DisableHomeGroup" -ExpectedValue 1 `
    -Description "HomeGroup disabled" -CISRef "18.8.22.1.1"

# ============================================================================
# CIS 18.8.25 - Logon
# ============================================================================
Write-Section "18.8.25 Logon"

# 18.8.25.1 (L1) Ensure 'Block user from showing account details on sign-in'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "BlockUserFromShowingAccountDetailsOnSignin" -ExpectedValue 1 `
    -Description "Block account details on sign-in" -CISRef "18.8.25.1"

# 18.8.25.2 (L1) Ensure 'Do not display network selection UI'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "DontDisplayNetworkSelectionUI" -ExpectedValue 1 `
    -Description "Hide network selection UI" -CISRef "18.8.25.2"

# 18.8.25.3 (L1) Ensure 'Do not enumerate connected users on domain-joined computers'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "DontEnumerateConnectedUsers" -ExpectedValue 1 `
    -Description "Don't enumerate connected users" -CISRef "18.8.25.3"

# 18.8.25.4 (L1) Ensure 'Enumerate local users on domain-joined computers' is disabled
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "EnumerateLocalUsers" -ExpectedValue 0 `
    -Description "Don't enumerate local users" -CISRef "18.8.25.4"

# 18.8.25.5 (L1) Ensure 'Turn off app notifications on the lock screen'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "DisableLockScreenAppNotifications" -ExpectedValue 1 `
    -Description "Lock screen notifications off" -CISRef "18.8.25.5"

# 18.8.25.6 (L1) Ensure 'Turn off picture password sign-in'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "BlockDomainPicturePassword" -ExpectedValue 1 `
    -Description "Picture password disabled" -CISRef "18.8.25.6"

# 18.8.25.7 (L1) Ensure 'Turn on convenience PIN sign-in'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "AllowDomainPINLogon" -ExpectedValue 0 `
    -Description "Domain PIN disabled" -CISRef "18.8.25.7"

# ============================================================================
# CIS 18.8.26 - OS Policies
# ============================================================================
Write-Section "18.8.26 OS Policies"

# 18.8.26.1 (L1) Ensure 'Allow Clipboard synchronization across devices' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "AllowCrossDeviceClipboard" -ExpectedValue 0 `
    -Description "Cross-device clipboard disabled" -CISRef "18.8.26.1"

# 18.8.26.2 (L2) Ensure 'Allow upload of User Activities' is set to 'Disabled'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" `
    -Name "UploadUserActivities" -ExpectedValue 0 `
    -Description "Activity upload disabled" -CISRef "18.8.26.2"

# ============================================================================
# CIS 18.8.27 - Power Management
# ============================================================================
Write-Section "18.8.27 Power Management"

# 18.8.27.1 (BL) Ensure 'Allow Standby States (S1-S3) When Sleeping (On Battery)'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\abfc2519-3608-4c2a-94ea-171b0ed546ab" `
    -Name "DCSettingIndex" -ExpectedValue 0 `
    -Description "Standby states (Battery) disabled" -CISRef "18.8.27.1"

# 18.8.27.2 (BL) Ensure 'Allow Standby States (S1-S3) When Sleeping (Plugged In)'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\abfc2519-3608-4c2a-94ea-171b0ed546ab" `
    -Name "ACSettingIndex" -ExpectedValue 0 `
    -Description "Standby states (Plugged) disabled" -CISRef "18.8.27.2"

# 18.8.27.3 (L1) Ensure 'Require a password when a computer wakes (On Battery)'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51" `
    -Name "DCSettingIndex" -ExpectedValue 1 `
    -Description "Wake password (Battery)" -CISRef "18.8.27.3"

# 18.8.27.4 (L1) Ensure 'Require a password when a computer wakes (Plugged In)'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51" `
    -Name "ACSettingIndex" -ExpectedValue 1 `
    -Description "Wake password (Plugged)" -CISRef "18.8.27.4"

# ============================================================================
# CIS 18.8.34 - Sleep Settings
# ============================================================================
Write-Section "18.8.34 Sleep Settings"

# 18.8.34.6.1 (L2) Ensure 'Allow network connectivity during connected-standby (on battery)' is disabled
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\f15576e8-98b7-4186-b944-eafa664402d9" `
    -Name "DCSettingIndex" -ExpectedValue 0 `
    -Description "Network in standby (Battery) disabled" -CISRef "18.8.34.6.1"

# 18.8.34.6.2 (L2) Ensure 'Allow network connectivity during connected-standby (plugged in)' is disabled
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\f15576e8-98b7-4186-b944-eafa664402d9" `
    -Name "ACSettingIndex" -ExpectedValue 0 `
    -Description "Network in standby (Plugged) disabled" -CISRef "18.8.34.6.2"

# 18.8.34.6.3 (BL) Ensure 'Require a password when a computer wakes (on battery)' is set to 'Enabled'
# Same as 18.8.27.3 - already checked above

# 18.8.34.6.4 (BL) Ensure 'Require a password when a computer wakes (plugged in)' is set to 'Enabled'
# Same as 18.8.27.4 - already checked above

# ============================================================================
# CIS 18.8.36 - Remote Assistance
# ============================================================================
Write-Section "18.8.36 Remote Assistance"

# 18.8.36.1 (L1) Ensure 'Configure Offer Remote Assistance'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" `
    -Name "fAllowUnsolicited" -ExpectedValue 0 `
    -Description "Unsolicited RA disabled" -CISRef "18.8.36.1"

# 18.8.36.2 (L1) Ensure 'Configure Solicited Remote Assistance'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" `
    -Name "fAllowToGetHelp" -ExpectedValue 0 `
    -Description "Solicited RA disabled" -CISRef "18.8.36.2"

# ============================================================================
# CIS 18.8.37 - Remote Procedure Call
# ============================================================================
Write-Section "18.8.37 RPC"

# 18.8.37.1 (L1) Ensure 'Enable RPC Endpoint Mapper Client Authentication'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" `
    -Name "EnableAuthEpResolution" -ExpectedValue 1 `
    -Description "RPC Endpoint Mapper Auth" -CISRef "18.8.37.1"

# 18.8.37.2 (L2) Ensure 'Restrict Unauthenticated RPC clients'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" `
    -Name "RestrictRemoteClients" -ExpectedValue 1 `
    -Description "Restrict unauth RPC clients" -CISRef "18.8.37.2"

# ============================================================================
# CIS 18.8.45 - Troubleshooting and Diagnostics
# ============================================================================
Write-Section "18.8.45 Troubleshooting"

# 18.8.45.5.1 (L2) Ensure 'Microsoft Support Diagnostic Tool: Turn on MSDT interactive communication with support provider'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy" `
    -Name "DisableQueryRemoteServer" -ExpectedValue 0 `
    -Description "MSDT disabled" -CISRef "18.8.45.5.1"

# 18.8.45.11.1 (L2) Ensure 'Enable/Disable PerfTrack'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}" `
    -Name "ScenarioExecutionEnabled" -ExpectedValue 0 `
    -Description "PerfTrack disabled" -CISRef "18.8.45.11.1"

# ============================================================================
# CIS 18.8.47 - User Profiles
# ============================================================================
Write-Section "18.8.47 User Profiles"

# 18.8.47.1 (L2) Ensure 'Turn off the advertising ID'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" `
    -Name "DisabledByGroupPolicy" -ExpectedValue 1 `
    -Description "Advertising ID disabled" -CISRef "18.8.47.1"

# ============================================================================
# CIS 18.8.50 - Windows Time Service
# ============================================================================
Write-Section "18.8.50 Windows Time"

# 18.8.50.1 (L2) Ensure 'Enable Windows NTP Client'
Test-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\W32Time\TimeProviders\NtpClient" `
    -Name "Enabled" -ExpectedValue 1 `
    -Description "NTP Client enabled" -CISRef "18.8.50.1"

# Check time sync status
try {
    $w32time = Get-Service -Name "W32Time" -ErrorAction SilentlyContinue
    if ($w32time.Status -eq "Running") {
        Register-Check -Name "Windows Time Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Windows Time Service" -Status WARN -Message "$($w32time.Status)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ADDITIONAL SYSTEM SETTINGS
# ============================================================================
Write-Section "Additional System Settings"

# Secure Boot status
try {
    $secureBoot = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
    if ($secureBoot) {
        Register-Check -Name "Secure Boot" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Secure Boot" -Status WARN -Message "Disabled or not supported"
    }
} catch {
    Register-Check -Name "Secure Boot" -Status INFO -Message "Unable to determine"
}

# TPM status
try {
    $tpm = Get-Tpm -ErrorAction SilentlyContinue
    if ($tpm.TpmPresent -and $tpm.TpmReady) {
        Register-Check -Name "TPM" -Status PASS -Message "Present and Ready"
    } elseif ($tpm.TpmPresent) {
        Register-Check -Name "TPM" -Status WARN -Message "Present but not ready"
    } else {
        Register-Check -Name "TPM" -Status WARN -Message "Not present"
    }
} catch {
    Register-Check -Name "TPM" -Status INFO -Message "Unable to determine"
}

# VBS status
try {
    $deviceGuard = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace "root\Microsoft\Windows\DeviceGuard" -ErrorAction SilentlyContinue
    if ($deviceGuard.VirtualizationBasedSecurityStatus -eq 2) {
        Register-Check -Name "VBS Status" -Status PASS -Message "Running"
    } elseif ($deviceGuard.VirtualizationBasedSecurityStatus -eq 1) {
        Register-Check -Name "VBS Status" -Status INFO -Message "Enabled but not running"
    } else {
        Register-Check -Name "VBS Status" -Status INFO -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
