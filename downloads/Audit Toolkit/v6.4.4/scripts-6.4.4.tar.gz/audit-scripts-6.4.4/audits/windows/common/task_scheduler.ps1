# Check Task Scheduler for Suspicious Tasks
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $tasks = Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\\Microsoft*' }
    if ($tasks) {
        Register-Check -Name "Task Scheduler" -Status WARN -Message "Non-Microsoft scheduled tasks found. Review for persistence mechanisms."
        $tasks | Format-Table TaskName, TaskPath
    } else {
        Register-Check -Name "Task Scheduler" -Status PASS -Message "No suspicious scheduled tasks found."
    }
} catch {
    Register-Check -Name "Task Scheduler" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit