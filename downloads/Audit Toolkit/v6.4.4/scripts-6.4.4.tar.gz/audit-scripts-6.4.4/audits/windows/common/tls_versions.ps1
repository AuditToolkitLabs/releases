# Check TLS Version Settings
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" -Name "Enabled" -ErrorAction SilentlyContinue
    if ($reg.Enabled -eq 0) {
        Register-Check -Name "TLS 1.0" -Status PASS -Message "TLS 1.0 is disabled."
    } else {
        Register-Check -Name "TLS 1.0" -Status FAIL -Message "TLS 1.0 is enabled."
    }
    $reg2 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" -Name "Enabled" -ErrorAction SilentlyContinue
    if ($reg2.Enabled -eq 0) {
        Register-Check -Name "TLS 1.1" -Status PASS -Message "TLS 1.1 is disabled."
    } else {
        Register-Check -Name "TLS 1.1" -Status FAIL -Message "TLS 1.1 is enabled."
    }
} catch {
    Register-Check -Name "TLS Versions" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit