# TPM Status Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Device Guard / TPM
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: https://www.cisecurity.org/benchmark/windows_11

Import-Module "$PSScriptRoot/common-audit.psm1"

# Check TPM Status
try {
    $tpm = Get-CimInstance -Namespace "Root\CIMv2\Security\MicrosoftTpm" -ClassName Win32_Tpm -ErrorAction Stop
    if ($tpm -and $tpm.IsEnabled_InitialValue) {
        Register-Check -Name "TPM Status" -Status PASS -Message "TPM is enabled and ready"
        # Check TPM version (2.0 recommended for security)
        if ($tpm.SpecVersion -match "^2\.") {
            Register-Check -Name "TPM Version" -Status PASS -Message "TPM 2.0 detected: $($tpm.SpecVersion)"
        } else {
            Register-Check -Name "TPM Version" -Status WARN -Message "TPM 1.2 detected - TPM 2.0 recommended: $($tpm.SpecVersion)"
        }
    } else {
        Register-Check -Name "TPM Status" -Status FAIL -Message "TPM is not enabled or not present"
    }
} catch {
    Register-Check -Name "TPM Status" -Status SKIP -Message "TPM not available: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit