# User Account Control (UAC) Security Audit Script (PowerShell)
# Comprehensive CIS Windows Benchmark - UAC Settings (2.3.17.x)
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: 2.3.17.x (8 controls)
# - CIS Windows Server 2022: 2.3.17.x
# - Microsoft UAC Best Practices: https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/user-account-control
#
# Compliance Mapping:
# - CIS Controls: 4.7 (Manage Default Accounts), 5.4 (Restrict Admin Privileges)
# - NIST SP 800-53: AC-6 (Least Privilege), AC-6(1) (Authorize Access)
# - PCI DSS: 7.1, 7.2 (Access Control)
# - MITRE ATT&CK: T1548.002 (Bypass UAC)

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

$uacPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"

function Test-UACRegistry {
    param(
        [string]$Name,
        [string]$CheckName,
        [string]$CISRef,
        $ExpectedValue,
        [string]$PassMessage,
        [string]$FailMessage
    )

    $displayName = "($CISRef) $CheckName"

    try {
        $value = Get-ItemProperty -Path $uacPath -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        if ($actualValue -eq $ExpectedValue) {
            Register-Check -Name $displayName -Status PASS -Message $PassMessage
        } else {
            Register-Check -Name $displayName -Status FAIL -Message "$FailMessage (Current: $actualValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status WARN -Message "Not configured"
    }
}

# ============================================================================
# CIS 2.3.17: USER ACCOUNT CONTROL SETTINGS
# ============================================================================
Write-Section "User Account Control (UAC) Settings"

# CIS 2.3.17.1 - Admin Approval Mode for Built-in Administrator
# EnableLUA must be 1 for this to take effect
Test-UACRegistry -Name "FilterAdministratorToken" -CISRef "2.3.17.1" `
    -CheckName "Admin Approval Mode for Built-in Admin" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - Built-in admin bypasses UAC"

# CIS 2.3.17.2 - Behavior of elevation prompt for admins
# 0 = Elevate without prompting
# 1 = Prompt for credentials on secure desktop
# 2 = Prompt for consent on secure desktop (recommended)
# 3 = Prompt for credentials
# 4 = Prompt for consent
# 5 = Prompt for consent for non-Windows binaries (default)
Test-UACRegistry -Name "ConsentPromptBehaviorAdmin" -CISRef "2.3.17.2" `
    -CheckName "Elevation Prompt for Admins" `
    -ExpectedValue 2 `
    -PassMessage "Prompt for consent on secure desktop" `
    -FailMessage "Should be 2 (prompt on secure desktop)"

# CIS 2.3.17.3 - Behavior of elevation prompt for standard users
# 0 = Automatically deny elevation
# 1 = Prompt for credentials on secure desktop (recommended)
# 3 = Prompt for credentials
Test-UACRegistry -Name "ConsentPromptBehaviorUser" -CISRef "2.3.17.3" `
    -CheckName "Elevation Prompt for Standard Users" `
    -ExpectedValue 0 `
    -PassMessage "Automatically deny elevation" `
    -FailMessage "Should be 0 (auto deny) or 1 (prompt credentials)"

# CIS 2.3.17.4 - Detect application installations and prompt
Test-UACRegistry -Name "EnableInstallerDetection" -CISRef "2.3.17.4" `
    -CheckName "Detect App Installations" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - installer detection bypassed"

# CIS 2.3.17.5 - Only elevate UIAccess apps in secure locations
Test-UACRegistry -Name "EnableSecureUIAPaths" -CISRef "2.3.17.5" `
    -CheckName "Elevate UIAccess in Secure Locations" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - UIAccess apps can run from any path"

# CIS 2.3.17.6 - Run all admins in Admin Approval Mode (UAC enabled)
Test-UACRegistry -Name "EnableLUA" -CISRef "2.3.17.6" `
    -CheckName "Admin Approval Mode (UAC Enabled)" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "UAC DISABLED - Critical security risk"

# CIS 2.3.17.7 - Switch to secure desktop for elevation prompts
Test-UACRegistry -Name "PromptOnSecureDesktop" -CISRef "2.3.17.7" `
    -CheckName "Secure Desktop for Elevation" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - elevation prompt spoofing possible"

# CIS 2.3.17.8 - Virtualize file/registry write failures
Test-UACRegistry -Name "EnableVirtualization" -CISRef "2.3.17.8" `
    -CheckName "File/Registry Write Virtualization" `
    -ExpectedValue 1 `
    -PassMessage "Enabled" `
    -FailMessage "Disabled - legacy app compatibility reduced"

# ============================================================================
# ADDITIONAL UAC SECURITY CHECKS
# ============================================================================
Write-Section "Additional UAC Security"

# Check if UAC is globally enabled
try {
    $uacStatus = Get-ItemProperty -Path $uacPath -Name "EnableLUA" -ErrorAction SilentlyContinue
    if ($uacStatus.EnableLUA -eq 1) {
        Register-Check -Name "UAC Global Status" -Status PASS -Message "UAC is enabled system-wide"
    } else {
        Register-Check -Name "UAC Global Status" -Status FAIL -Message "UAC is DISABLED - immediate security risk"
    }
} catch {
    Register-Check -Name "UAC Global Status" -Status WARN -Message "Cannot determine UAC status"
}

# Check UAC notification level via slider (registry)
try {
    # ConsentPromptBehaviorAdmin + PromptOnSecureDesktop determine slider position
    $adminBehavior = (Get-ItemProperty -Path $uacPath -Name "ConsentPromptBehaviorAdmin" -ErrorAction SilentlyContinue).ConsentPromptBehaviorAdmin
    $secureDesktop = (Get-ItemProperty -Path $uacPath -Name "PromptOnSecureDesktop" -ErrorAction SilentlyContinue).PromptOnSecureDesktop

    $sliderLevel = switch ("$adminBehavior-$secureDesktop") {
        "2-1" { "Always notify (Highest)" }
        "5-1" { "Notify on changes (Default)" }
        "5-0" { "Notify without dimming" }
        "0-0" { "Never notify (Lowest - Insecure)" }
        default { "Custom ($adminBehavior-$secureDesktop)" }
    }

    if ($adminBehavior -eq 2 -and $secureDesktop -eq 1) {
        Register-Check -Name "UAC Slider Level" -Status PASS -Message $sliderLevel
    } elseif ($adminBehavior -eq 0) {
        Register-Check -Name "UAC Slider Level" -Status FAIL -Message $sliderLevel
    } else {
        Register-Check -Name "UAC Slider Level" -Status INFO -Message $sliderLevel
    }
} catch {
    Register-Check -Name "UAC Slider Level" -Status SKIP -Message "Cannot determine"
}

# Check for UAC bypass indicators (common attack paths)
Write-Section "UAC Bypass Detection"

# Check fodhelper.exe exploit path (T1548.002)
$bypassPaths = @(
    @{Path = "HKCU:\Software\Classes\ms-settings\shell\open\command"; Name = "fodhelper bypass"},
    @{Path = "HKCU:\Software\Classes\mscfile\shell\open\command"; Name = "eventvwr bypass"},
    @{Path = "HKCU:\Software\Classes\exefile\shell\runas\command"; Name = "sdclt bypass"}
)

foreach ($bp in $bypassPaths) {
    try {
        if (Test-Path $bp.Path) {
            $value = Get-ItemProperty -Path $bp.Path -ErrorAction SilentlyContinue
            if ($value.'(default)' -or $value.DelegateExecute) {
                Register-Check -Name "UAC Bypass: $($bp.Name)" -Status FAIL -Message "Suspicious registry key found"
            } else {
                Register-Check -Name "UAC Bypass: $($bp.Name)" -Status WARN -Message "Key exists but empty"
            }
        } else {
            Register-Check -Name "UAC Bypass: $($bp.Name)" -Status PASS -Message "Not present"
        }
    } catch {
        Register-Check -Name "UAC Bypass: $($bp.Name)" -Status PASS -Message "Not accessible"
    }
}

# Check Local Account Token Filter Policy (affects remote admin)
try {
    $tokenFilter = Get-ItemProperty -Path $uacPath -Name "LocalAccountTokenFilterPolicy" -ErrorAction SilentlyContinue
    if ($null -eq $tokenFilter -or $tokenFilter.LocalAccountTokenFilterPolicy -eq 0) {
        Register-Check -Name "Local Account Token Filter" -Status PASS -Message "Enabled (default)"
    } else {
        Register-Check -Name "Local Account Token Filter" -Status WARN -Message "Disabled - remote admin full tokens allowed"
    }
} catch {
    Register-Check -Name "Local Account Token Filter" -Status PASS -Message "Default (enabled)"
}

Print-Summary
Exit-Audit
