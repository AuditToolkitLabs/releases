<#
.SYNOPSIS
    USB and Removable Storage Security Audit

.DESCRIPTION
    Audits device installation and removable storage restrictions:
    - USB storage device controls
    - Device installation restrictions
    - BitLocker To Go requirements
    - Removable Storage Access policies
    - AutoPlay/AutoRun settings

.NOTES
    Requires: Local Administrator for full registry access

Compliance Mapping:
- CIS Controls: 10.3 (Disable Autorun), 13.3 (Configure Removable Media)
- NIST SP 800-53: MP-7 (Media Use), SC-41 (Port and I/O Device Access)
- ISO 27001: A.8.3.1 (Management of Removable Media)
- PCI DSS: 5.1.2, 6.5.4
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "USB and Removable Storage Audit"

# ============================================================================
# DEVICE INSTALLATION RESTRICTIONS
# ============================================================================
Write-Section "Device Installation Policies"

# Check if device installation is restricted
try {
    $devInstallPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
    $devRestrict = Get-ItemProperty -Path $devInstallPath -ErrorAction SilentlyContinue

    if ($devRestrict) {
        # Deny installation of devices not described by other policy settings
        if ($devRestrict.DenyUnspecified -eq 1) {
            Register-Check -Name "Deny Unspecified Devices" -Status PASS -Message "Only allowed devices can install"
        }

        # Prevent installation of removable devices
        if ($devRestrict.DenyRemovable -eq 1) {
            Register-Check -Name "Removable Device Install" -Status PASS -Message "Blocked via policy"
        } else {
            Register-Check -Name "Removable Device Install" -Status WARN -Message "Allowed"
        }

        # Device setup class deny list
        $denyClassPath = "$devInstallPath\DenyDeviceClasses"
        if (Test-Path $denyClassPath) {
            $denyClasses = Get-ItemProperty $denyClassPath -ErrorAction SilentlyContinue
            $classCount = ($denyClasses.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
            if ($classCount -gt 0) {
                Register-Check -Name "Denied Device Classes" -Status PASS -Message "$classCount class(es) blocked"
            }
        }

        # Device ID deny list
        $denyIdPath = "$devInstallPath\DenyDeviceIDs"
        if (Test-Path $denyIdPath) {
            $denyIds = Get-ItemProperty $denyIdPath -ErrorAction SilentlyContinue
            $idCount = ($denyIds.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" }).Count
            if ($idCount -gt 0) {
                Register-Check -Name "Denied Device IDs" -Status PASS -Message "$idCount device ID(s) blocked"
            }
        }
    } else {
        Register-Check -Name "Device Installation Policy" -Status WARN -Message "No restrictions configured"
    }
} catch {
    Register-Check -Name "Device Installation Policy" -Status WARN -Message "Cannot query"
}

# ============================================================================
# USB STORAGE DRIVER
# ============================================================================
Write-Section "USB Storage Service"

try {
    $usbstorSvc = Get-Service -Name USBSTOR -ErrorAction SilentlyContinue

    if ($usbstorSvc) {
        # Check startup type
        if ($usbstorSvc.StartType -eq 'Disabled') {
            Register-Check -Name "USBSTOR Service" -Status PASS -Message "Disabled - USB storage blocked"
        } elseif ($usbstorSvc.StartType -eq 'Manual') {
            Register-Check -Name "USBSTOR Service" -Status WARN -Message "Manual - USB storage available on demand"
        } else {
            Register-Check -Name "USBSTOR Service" -Status WARN -Message "StartType: $($usbstorSvc.StartType)"
        }

        # Check registry start value
        $usbstorReg = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR" -Name "Start" -ErrorAction SilentlyContinue
        if ($usbstorReg.Start -eq 4) {
            Register-Check -Name "USBSTOR Registry" -Status PASS -Message "Start=4 (Disabled)"
        } elseif ($usbstorReg.Start -eq 3) {
            Register-Check -Name "USBSTOR Registry" -Status WARN -Message "Start=3 (Manual)"
        }
    }
} catch {
    Register-Check -Name "USBSTOR Service" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# REMOVABLE STORAGE ACCESS
# ============================================================================
Write-Section "Removable Storage Access"

$rsaPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices"

try {
    # All Removable Storage Classes - Deny All Access
    $allDeny = Get-ItemProperty "$rsaPath\{53f5630d-b6bf-11d0-94f2-00a0c91efb8b}" -ErrorAction SilentlyContinue
    if ($allDeny) {
        if ($allDeny.Deny_Read -eq 1 -and $allDeny.Deny_Write -eq 1) {
            Register-Check -Name "Removable Storage" -Status PASS -Message "Read and write denied"
        } elseif ($allDeny.Deny_Write -eq 1) {
            Register-Check -Name "Removable Storage" -Status PASS -Message "Write denied (read-only)"
        } elseif ($allDeny.Deny_Read -eq 1) {
            Register-Check -Name "Removable Storage" -Status WARN -Message "Read denied but write allowed"
        } else {
            Register-Check -Name "Removable Storage" -Status WARN -Message "Policy exists but not enforcing"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Removable Disks (USB drives)
try {
    $usbDisk = Get-ItemProperty "$rsaPath\{53f5630d-b6bf-11d0-94f2-00a0c91efb8b}" -Name "Deny_Write" -ErrorAction SilentlyContinue
    if ($usbDisk.Deny_Write -eq 1) {
        Register-Check -Name "USB Disk Write" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "USB Disk Write" -Status WARN -Message "Allowed"
    }
} catch {
    Register-Check -Name "USB Disk Write" -Status WARN -Message "No policy - write allowed"
}

# CD/DVD
try {
    $cdDvd = Get-ItemProperty "$rsaPath\{53f56308-b6bf-11d0-94f2-00a0c91efb8b}" -ErrorAction SilentlyContinue
    if ($cdDvd.Deny_Write -eq 1) {
        Register-Check -Name "CD/DVD Write" -Status PASS -Message "Blocked"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Floppy
try {
    $floppy = Get-ItemProperty "$rsaPath\{53f56311-b6bf-11d0-94f2-00a0c91efb8b}" -ErrorAction SilentlyContinue
    if ($floppy.Deny_Read -eq 1 -or $floppy.Deny_Write -eq 1) {
        Register-Check -Name "Floppy Drive" -Status PASS -Message "Access restricted"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Tape drives
try {
    $tape = Get-ItemProperty "$rsaPath\{53f5630b-b6bf-11d0-94f2-00a0c91efb8b}" -ErrorAction SilentlyContinue
    if ($tape.Deny_Read -eq 1 -or $tape.Deny_Write -eq 1) {
        Register-Check -Name "Tape Drive" -Status PASS -Message "Access restricted"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# WPD (Windows Portable Devices - phones, cameras)
try {
    $wpdPath = "$rsaPath\{6AC27878-A6FA-4155-BA85-F98F491D4F33}"

    $wpd = Get-ItemProperty $wpdPath -ErrorAction SilentlyContinue
    if ($wpd.Deny_Read -eq 1 -or $wpd.Deny_Write -eq 1) {
        Register-Check -Name "WPD Devices" -Status PASS -Message "Access restricted"
    } else {
        Register-Check -Name "WPD Devices" -Status WARN -Message "Phones/cameras can connect"
    }
} catch {
    Register-Check -Name "WPD Devices" -Status WARN -Message "No policy"
}

# ============================================================================
# BITLOCKER TO GO
# ============================================================================
Write-Section "BitLocker To Go"

try {
    $blPath = "HKLM:\SOFTWARE\Policies\Microsoft\FVE"
    Get-ItemProperty $blPath -ErrorAction SilentlyContinue | Out-Null

    # Deny write to removable drives not protected by BitLocker
    $rdvDeny = Get-ItemProperty $blPath -Name "RDVDenyWriteAccess" -ErrorAction SilentlyContinue

    if ($rdvDeny.RDVDenyWriteAccess -eq 1) {
        Register-Check -Name "BitLocker To Go Required" -Status PASS -Message "Write to unencrypted removable drives blocked"
    } else {
        Register-Check -Name "BitLocker To Go Required" -Status WARN -Message "Write to unencrypted drives allowed"
    }

    # Cross-org access
    $rdvCrossOrg = Get-ItemProperty $blPath -Name "RDVAllowCrossOrg" -ErrorAction SilentlyContinue
    if ($rdvCrossOrg.RDVAllowCrossOrg -eq 0) {
        Register-Check -Name "Cross-Org BitLocker" -Status PASS -Message "Only org-encrypted drives allowed"
    }
} catch {
    Register-Check -Name "BitLocker To Go" -Status SKIP -Message "Policy not configured"
}

# ============================================================================
# AUTOPLAY/AUTORUN
# ============================================================================
Write-Section "AutoPlay/AutoRun"

# AutoPlay for all drives - CIS 18.9.8.1
try {
    $autoPlayPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    $noAutoPlay = Get-ItemProperty $autoPlayPath -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue

    if ($noAutoPlay.NoDriveTypeAutoRun -eq 255) {
        Register-Check -Name "AutoPlay All Drives" -Status PASS -Message "Disabled (0xFF)"
    } elseif ($noAutoPlay.NoDriveTypeAutoRun -ge 128) {
        Register-Check -Name "AutoPlay All Drives" -Status WARN -Message "Partially restricted"
    } else {
        Register-Check -Name "AutoPlay All Drives" -Status FAIL -Message "Enabled - security risk"
    }
} catch {
    Register-Check -Name "AutoPlay All Drives" -Status WARN -Message "Not configured via policy"
}

# AutoRun default behavior - CIS 18.9.8.2
try {
    $autoRunPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    $noAutoRun = Get-ItemProperty $autoRunPath -Name "NoAutorun" -ErrorAction SilentlyContinue

    if ($noAutoRun.NoAutorun -eq 1) {
        Register-Check -Name "AutoRun" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "AutoRun" -Status FAIL -Message "Enabled - malware vector"
    }
} catch {
    Register-Check -Name "AutoRun" -Status WARN -Message "Not explicitly disabled"
}

# Honor autorun.inf for non-volume devices - CIS 18.9.8.3
try {
    $honorPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer"
    $noAutorunInf = Get-ItemProperty $honorPath -Name "NoAutoplayfornonVolume" -ErrorAction SilentlyContinue

    if ($noAutorunInf.NoAutoplayfornonVolume -eq 1) {
        Register-Check -Name "AutoRun Non-Volume" -Status PASS -Message "Disabled for non-volume devices"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DMA PROTECTION
# ============================================================================
Write-Section "DMA Protection"

# Kernel DMA Protection
try {
    $dmaPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Kernel DMA Protection"
    $dmaConfig = Get-ItemProperty $dmaPath -ErrorAction SilentlyContinue

    if ($dmaConfig.DeviceEnumerationPolicy -eq 0) {
        Register-Check -Name "Kernel DMA Protection" -Status PASS -Message "Block all DMA-capable external devices"
    } elseif ($dmaConfig.DeviceEnumerationPolicy -eq 1) {
        Register-Check -Name "Kernel DMA Protection" -Status WARN -Message "Only after login/screen unlock"
    } elseif ($dmaConfig.DeviceEnumerationPolicy -eq 2) {
        Register-Check -Name "Kernel DMA Protection" -Status FAIL -Message "Allow all DMA-capable devices"
    }
} catch {
    Register-Check -Name "Kernel DMA Protection" -Status WARN -Message "Not configured via policy"
}

# Check hardware DMA guard support
try {
    $dgInfo = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction SilentlyContinue
    if ($dgInfo) {
        $null = $dgInfo.CodeIntegrityPolicyEnforcementStatus
        # Just check if DMA protections are available
        Register-Check -Name "Hardware DMA Support" -Status PASS -Message "Device Guard available"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Thunderbolt security level
try {
    $tbPath = "HKLM:\SOFTWARE\Microsoft\Thunderbolt"
    $tbConfig = Get-ItemProperty $tbPath -Name "SecurityLevel" -ErrorAction SilentlyContinue

    if ($tbConfig.SecurityLevel) {
        switch ($tbConfig.SecurityLevel) {
            0 { Register-Check -Name "Thunderbolt Security" -Status FAIL -Message "No security" }
            1 { Register-Check -Name "Thunderbolt Security" -Status WARN -Message "User authorization" }
            2 { Register-Check -Name "Thunderbolt Security" -Status PASS -Message "Secure connect" }
            3 { Register-Check -Name "Thunderbolt Security" -Status PASS -Message "Display Port and USB only" }
            default { Register-Check -Name "Thunderbolt Security" -Status WARN -Message "Level: $($tbConfig.SecurityLevel)" }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CURRENT USB DEVICES
# ============================================================================
Write-Section "Connected USB Devices"

try {
    $usbDevices = Get-CimInstance -ClassName Win32_USBHub -ErrorAction SilentlyContinue
    $usbCount = @($usbDevices).Count

    Register-Check -Name "Connected USB Hubs" -Status INFO -Message "$usbCount device(s)"

    # Check for USB Mass Storage
    $massStorage = Get-CimInstance -ClassName Win32_DiskDrive | Where-Object { $_.InterfaceType -eq "USB" }
    $storageCount = @($massStorage).Count

    if ($storageCount -gt 0) {
        Register-Check -Name "USB Storage Devices" -Status WARN -Message "$storageCount connected"
        foreach ($drive in $massStorage) {
            Write-Output "    - $($drive.Model) ($([math]::Round($drive.Size/1GB)) GB)"
        }
    } else {
        Register-Check -Name "USB Storage Devices" -Status PASS -Message "None connected"
    }
} catch {
    Register-Check -Name "USB Devices" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
