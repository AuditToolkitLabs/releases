# User Rights Assignment Security Audit Script (PowerShell)
# Read-only audit for CIS-style user rights assignment checks.

Import-Module "$PSScriptRoot/common-audit.psm1"

$script:WellKnownSidMap = @{
    'S-1-5-32-544' = 'Administrators'
    'S-1-5-545' = 'Users'
    'S-1-5-32-546' = 'Guests'
    'S-1-5-32-547' = 'Power Users'
    'S-1-5-32-548' = 'Account Operators'
    'S-1-5-32-549' = 'Server Operators'
    'S-1-5-32-550' = 'Print Operators'
    'S-1-5-32-551' = 'Backup Operators'
    'S-1-5-18' = 'SYSTEM'
    'S-1-5-19' = 'LOCAL SERVICE'
    'S-1-5-20' = 'NETWORK SERVICE'
    'S-1-5-11' = 'Authenticated Users'
    'S-1-1-0' = 'Everyone'
    'S-1-5-32-555' = 'Remote Desktop Users'
    'S-1-5-32-580' = 'Remote Management Users'
    'S-1-5-83-0' = 'NT VIRTUAL MACHINE\\Virtual Machines'
}

function Convert-SidListToName {
    [CmdletBinding()]
    param(
        [string]$SidList
    )

    if ([string]::IsNullOrWhiteSpace($SidList)) {
        return '(None)'
    }

    $valueList = @()
    foreach ($rawItem in ($SidList -split ',')) {
        $sidValue = $rawItem.Trim().TrimStart('*')
        if ([string]::IsNullOrWhiteSpace($sidValue)) {
            continue
        }

        if ($script:WellKnownSidMap.ContainsKey($sidValue)) {
            $valueList += $script:WellKnownSidMap[$sidValue]
            continue
        }

        try {
            $sid = New-Object System.Security.Principal.SecurityIdentifier($sidValue)
            $valueList += $sid.Translate([System.Security.Principal.NTAccount]).Value
        }
        catch {
            $valueList += $sidValue
        }
    }

    if ($valueList.Count -eq 0) {
        return '(None)'
    }

    return ($valueList -join ', ')
}

function Get-SecurityPolicyExport {
    [CmdletBinding()]
    param()

    $path = Join-Path $env:TEMP ("secpol_export_{0}.txt" -f (Get-Date -Format 'yyyyMMddHHmmss'))
    $null = & secedit /export /cfg $path /quiet 2>&1

    if (-not (Test-Path -LiteralPath $path)) {
        return $null
    }

    return [pscustomobject]@{
        Path = $path
        Content = Get-Content -LiteralPath $path -Raw
    }
}

function Test-PrivilegeRule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$PolicyText,
        [Parameter(Mandatory)]
        [string]$Privilege,
        [Parameter(Mandatory)]
        [string]$CheckName,
        [ValidateSet('Empty', 'Contains', 'DenyGuest', 'Any')]
        [string]$Mode = 'Contains',
        [string]$ExpectedPattern = ''
    )

    $pattern = "{0}\s*=\s*(.*)" -f [regex]::Escape($Privilege)
    $match = [regex]::Match($PolicyText, $pattern)

    if (-not $match.Success) {
        if ($Mode -eq 'Empty') {
            Register-Check -Name $CheckName -Status PASS -Message 'Not configured (empty)'
        }
        else {
            Register-Check -Name $CheckName -Status INFO -Message 'Not explicitly configured'
        }
        return
    }

    $assignedRaw = $match.Groups[1].Value.Trim()
    $assignedName = Convert-SidListToName -SidList $assignedRaw

    switch ($Mode) {
        'Empty' {
            if ([string]::IsNullOrWhiteSpace($assignedRaw)) {
                Register-Check -Name $CheckName -Status PASS -Message 'Not assigned (correct)'
            }
            else {
                Register-Check -Name $CheckName -Status FAIL -Message ("Should be empty, assigned to: {0}" -f $assignedName)
            }
            return
        }
        'DenyGuest' {
            if ($assignedRaw -match 'S-1-5-32-546|Guest') {
                Register-Check -Name $CheckName -Status PASS -Message 'Guest denied (CIS aligned)'
            }
            else {
                Register-Check -Name $CheckName -Status WARN -Message ("Guest not explicitly denied. Current: {0}" -f $assignedName)
            }
            return
        }
        'Any' {
            Register-Check -Name $CheckName -Status PASS -Message $assignedName
            return
        }
        default {
            if ([string]::IsNullOrWhiteSpace($ExpectedPattern)) {
                Register-Check -Name $CheckName -Status INFO -Message $assignedName
                return
            }

            if ($assignedRaw -match $ExpectedPattern -or [string]::IsNullOrWhiteSpace($assignedRaw)) {
                Register-Check -Name $CheckName -Status PASS -Message $assignedName
            }
            else {
                Register-Check -Name $CheckName -Status WARN -Message ("Assigned: {0}" -f $assignedName)
            }
        }
    }
}

function Add-PrivilegeRule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Collections.Generic.List[object]]$RuleList,
        [Parameter(Mandatory)]
        [string]$Section,
        [Parameter(Mandatory)]
        [string]$Privilege,
        [Parameter(Mandatory)]
        [string]$CheckName,
        [ValidateSet('Empty', 'Contains', 'DenyGuest', 'Any')]
        [string]$Mode = 'Contains',
        [string]$ExpectedPattern = ''
    )

    $RuleList.Add([pscustomobject]@{
            Section = $Section
            Privilege = $Privilege
            CheckName = $CheckName
            Mode = $Mode
            ExpectedPattern = $ExpectedPattern
        })
}

Write-Section 'User Rights Assignment Audit'

$policyExport = $null
try {
    $policyExport = Get-SecurityPolicyExport
    if ($null -eq $policyExport) {
        Register-Check -Name 'User Rights Access' -Status WARN -Message 'Requires elevated privileges or secedit export is unavailable'
        Print-Summary
        Exit-Audit
    }

    Register-Check -Name 'Policy Export' -Status PASS -Message 'Security policy exported successfully'

    $ruleList = New-Object System.Collections.Generic.List[object]

    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeTrustedCredManAccessPrivilege' -CheckName 'Access Credential Manager' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeNetworkLogonRight' -CheckName 'Network Access' -ExpectedPattern 'S-1-5-32-544|S-1-5-11|Administrators|Authenticated Users'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeTcbPrivilege' -CheckName 'Act as OS (TCB)' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeMachineAccountPrivilege' -CheckName 'Add Workstations to Domain' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeIncreaseQuotaPrivilege' -CheckName 'Adjust Memory Quotas' -ExpectedPattern 'S-1-5-32-544|S-1-5-19|S-1-5-20'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeInteractiveLogonRight' -CheckName 'Allow Local Logon' -ExpectedPattern 'S-1-5-32-544|S-1-5-545|Administrators|Users'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeRemoteInteractiveLogonRight' -CheckName 'Allow RDP Logon' -ExpectedPattern 'S-1-5-32-544|S-1-5-32-555|Administrators|Remote Desktop Users'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Access and Logon Rights' -Privilege 'SeBackupPrivilege' -CheckName 'Backup Files' -ExpectedPattern 'S-1-5-32-544|Administrators'

    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeSystemtimePrivilege' -CheckName 'Change System Time' -ExpectedPattern 'S-1-5-32-544|S-1-5-19|Administrators|LOCAL SERVICE'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeTimeZonePrivilege' -CheckName 'Change Time Zone' -ExpectedPattern 'S-1-5-32-544|S-1-5-19|S-1-5-545|Administrators|LOCAL SERVICE|Users'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeCreatePagefilePrivilege' -CheckName 'Create Pagefile' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeCreateTokenPrivilege' -CheckName 'Create Token Object' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeCreateGlobalPrivilege' -CheckName 'Create Global Objects' -ExpectedPattern 'S-1-5-32-544|S-1-5-19|S-1-5-20|S-1-5-6|Administrators|SERVICE'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeCreatePermanentPrivilege' -CheckName 'Create Permanent Shared Objects' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeCreateSymbolicLinkPrivilege' -CheckName 'Create Symbolic Links' -ExpectedPattern 'S-1-5-32-544|S-1-5-83-0|Administrators|NT VIRTUAL MACHINE'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Creation and Process Rights' -Privilege 'SeDebugPrivilege' -CheckName 'Debug Programs' -ExpectedPattern 'S-1-5-32-544|Administrators'

    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeDenyNetworkLogonRight' -CheckName 'Deny Network Access' -Mode DenyGuest
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeDenyBatchLogonRight' -CheckName 'Deny Batch Logon' -Mode DenyGuest
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeDenyServiceLogonRight' -CheckName 'Deny Service Logon' -Mode DenyGuest
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeDenyInteractiveLogonRight' -CheckName 'Deny Local Logon' -Mode DenyGuest
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeDenyRemoteInteractiveLogonRight' -CheckName 'Deny RDP Logon' -Mode DenyGuest
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeEnableDelegationPrivilege' -CheckName 'Enable Delegation' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeRemoteShutdownPrivilege' -CheckName 'Force Remote Shutdown' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeAuditPrivilege' -CheckName 'Generate Security Audits' -ExpectedPattern 'S-1-5-19|S-1-5-20|LOCAL SERVICE|NETWORK SERVICE'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Deny and Impersonation Rights' -Privilege 'SeImpersonatePrivilege' -CheckName 'Impersonate Client' -ExpectedPattern 'S-1-5-32-544|S-1-5-19|S-1-5-20|S-1-5-6|Administrators|SERVICE'

    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeIncreaseBasePriorityPrivilege' -CheckName 'Increase Scheduling Priority' -ExpectedPattern 'S-1-5-32-544|S-1-5-90-0|Administrators|Window Manager'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeLoadDriverPrivilege' -CheckName 'Load/Unload Drivers' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeLockMemoryPrivilege' -CheckName 'Lock Pages in Memory' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeBatchLogonRight' -CheckName 'Log on as Batch' -ExpectedPattern 'S-1-5-32-544|S-1-5-32-551|Administrators|Backup Operators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeServiceLogonRight' -CheckName 'Log on as Service' -Mode Any
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeSecurityPrivilege' -CheckName 'Manage Audit/Security Log' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeRelabelPrivilege' -CheckName 'Modify Object Label' -Mode Empty
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeSystemEnvironmentPrivilege' -CheckName 'Modify Firmware Environment' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeManageVolumePrivilege' -CheckName 'Volume Maintenance Tasks' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeProfileSingleProcessPrivilege' -CheckName 'Profile Single Process' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeSystemProfilePrivilege' -CheckName 'Profile System Performance' -ExpectedPattern 'S-1-5-32-544|Administrators|WdiServiceHost'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeAssignPrimaryTokenPrivilege' -CheckName 'Replace Process Token' -ExpectedPattern 'S-1-5-19|S-1-5-20|LOCAL SERVICE|NETWORK SERVICE'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeRestorePrivilege' -CheckName 'Restore Files' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeShutdownPrivilege' -CheckName 'Shutdown System' -ExpectedPattern 'S-1-5-32-544|S-1-5-545|Administrators|Users'
    Add-PrivilegeRule -RuleList $ruleList -Section 'System Rights' -Privilege 'SeSyncAgentPrivilege' -CheckName 'Sync Directory Service' -Mode Empty

    Add-PrivilegeRule -RuleList $ruleList -Section 'Ownership and Final Rights' -Privilege 'SeTakeOwnershipPrivilege' -CheckName 'Take Ownership' -ExpectedPattern 'S-1-5-32-544|Administrators'
    Add-PrivilegeRule -RuleList $ruleList -Section 'Ownership and Final Rights' -Privilege 'SeIncreaseWorkingSetPrivilege' -CheckName 'Increase Process Working Set' -ExpectedPattern 'S-1-5-545|S-1-5-19|Users|LOCAL SERVICE'

    $currentSection = ''
    foreach ($rule in $ruleList) {
        if ($rule.Section -ne $currentSection) {
            $currentSection = $rule.Section
            Write-Section $currentSection
        }

        Test-PrivilegeRule -PolicyText $policyExport.Content -Privilege $rule.Privilege -CheckName $rule.CheckName -Mode $rule.Mode -ExpectedPattern $rule.ExpectedPattern
    }

    Write-Section 'High-Risk Privilege Summary'
    $highRiskRule = @('SeDebugPrivilege', 'SeTcbPrivilege', 'SeCreateTokenPrivilege', 'SeLoadDriverPrivilege', 'SeTakeOwnershipPrivilege', 'SeBackupPrivilege', 'SeRestorePrivilege')
    $riskyCount = 0

    foreach ($privilegeName in $highRiskRule) {
        $privilegeMatch = [regex]::Match($policyExport.Content, ("{0}\\s*=\\s*(.*)" -f [regex]::Escape($privilegeName)))
        if (-not $privilegeMatch.Success) {
            continue
        }

        $assigned = $privilegeMatch.Groups[1].Value.Trim()
        if ([string]::IsNullOrWhiteSpace($assigned)) {
            continue
        }

        if ($assigned -notmatch '^\\*S-1-5-32-544$|^\\*S-1-5-18$') {
            $riskyCount++
        }
    }

    if ($riskyCount -eq 0) {
        Register-Check -Name 'High-Risk Privileges' -Status PASS -Message 'All high-risk privileges properly restricted'
    }
    elseif ($riskyCount -le 2) {
        Register-Check -Name 'High-Risk Privileges' -Status WARN -Message ("{0} privilege assignment(s) should be reviewed" -f $riskyCount)
    }
    else {
        Register-Check -Name 'High-Risk Privileges' -Status FAIL -Message ("{0} high-risk privilege assignment(s) are overly permissive" -f $riskyCount)
    }
}
catch {
    Register-Check -Name 'User Rights Access' -Status FAIL -Message ("Cannot export security policy: {0}" -f $_.Exception.Message)
}
finally {
    if ($policyExport -and $policyExport.Path) {
        Remove-Item -LiteralPath $policyExport.Path -Force -ErrorAction SilentlyContinue
    }
}

Print-Summary
Exit-Audit
