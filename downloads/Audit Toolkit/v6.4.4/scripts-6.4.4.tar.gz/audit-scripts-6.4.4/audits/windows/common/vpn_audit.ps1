# VPN Audit Script (PowerShell)
# Checks for enterprise VPN clients and their security configuration
# This script is read-only and does not modify system state.
#
# References:
# - CIS Controls 12: Network Infrastructure Management
# - NIST SP 800-53: AC-17, SC-8, SC-13

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# CISCO ANYCONNECT
# ============================================================================
Write-Section "Cisco AnyConnect"

try {
    $anyConnectServices = @("vpnagent", "aciseposture", "caboraacsvc")
    $anyConnectFound = $false

    foreach ($svcName in $anyConnectServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $anyConnectFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "AnyConnect VPN Agent" -Status PASS -Message "Running"
            } else {
                Register-Check -Name "AnyConnect VPN Agent" -Status INFO -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $anyConnectFound) {
        # Check installation
        $anyConnectPath = "C:\Program Files (x86)\Cisco\Cisco AnyConnect Secure Mobility Client"
        if (Test-Path $anyConnectPath) {
            Register-Check -Name "Cisco AnyConnect" -Status INFO -Message "Installed but service not running"

            $vpnui = Join-Path $anyConnectPath "vpnui.exe"
            if (Test-Path $vpnui) {
                $version = (Get-Item $vpnui).VersionInfo.FileVersion
                Register-Check -Name "AnyConnect Version" -Status INFO -Message "v$version"
            }
        } else {
            Register-Check -Name "Cisco AnyConnect" -Status INFO -Message "Not installed"
        }
    } else {
        # Check version
        $vpnui = "C:\Program Files (x86)\Cisco\Cisco AnyConnect Secure Mobility Client\vpnui.exe"
        if (Test-Path $vpnui) {
            $version = (Get-Item $vpnui).VersionInfo.FileVersion
            Register-Check -Name "AnyConnect Version" -Status INFO -Message "v$version"
        }
    }

    # AnyConnect ISE Posture
    $posture = Get-Service -Name "aciseposture" -ErrorAction SilentlyContinue
    if ($posture -and $posture.Status -eq "Running") {
        Register-Check -Name "AnyConnect ISE Posture" -Status PASS -Message "Running (posture assessment enabled)"
    }
} catch {
    Register-Check -Name "Cisco AnyConnect" -Status INFO -Message "Not detected"
}

# ============================================================================
# PALO ALTO GLOBALPROTECT
# ============================================================================
Write-Section "Palo Alto GlobalProtect"

try {
    $gpService = Get-Service -Name "PanGPS" -ErrorAction SilentlyContinue
    if ($gpService) {
        if ($gpService.Status -eq "Running") {
            Register-Check -Name "GlobalProtect Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "GlobalProtect Service" -Status INFO -Message "$($gpService.Status)"
        }

        # Check version
        $gpPath = "C:\Program Files\Palo Alto Networks\GlobalProtect"
        $gpExe = Join-Path $gpPath "PanGPA.exe"
        if (Test-Path $gpExe) {
            $version = (Get-Item $gpExe).VersionInfo.FileVersion
            Register-Check -Name "GlobalProtect Version" -Status INFO -Message "v$version"
        }

        # Check connection status via registry
        $gpReg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Palo Alto Networks\GlobalProtect\PanSetup" -ErrorAction SilentlyContinue
        if ($gpReg.Portal) {
            Register-Check -Name "GlobalProtect Portal" -Status INFO -Message "$($gpReg.Portal)"
        }
    } else {
        Register-Check -Name "GlobalProtect" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "GlobalProtect" -Status INFO -Message "Not detected"
}

# ============================================================================
# ZSCALER
# ============================================================================
Write-Section "Zscaler"

try {
    $zscalerServices = @("ZSATunnel", "ZSAService", "ZscalerService")
    $zscalerFound = $false

    foreach ($svcName in $zscalerServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $zscalerFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "Zscaler Service" -Status PASS -Message "Running ($svcName)"
            } else {
                Register-Check -Name "Zscaler Service" -Status INFO -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $zscalerFound) {
        # Check installation paths
        $zscalerPaths = @(
            "C:\Program Files\Zscaler",
            "C:\Program Files (x86)\Zscaler"
        )

        $installed = $false
        foreach ($path in $zscalerPaths) {
            if (Test-Path $path) {
                $installed = $true
                Register-Check -Name "Zscaler" -Status INFO -Message "Installed but service not running"
                break
            }
        }

        if (-not $installed) {
            Register-Check -Name "Zscaler" -Status INFO -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "Zscaler" -Status INFO -Message "Not detected"
}

# ============================================================================
# FORTINET FORTICLIENT
# ============================================================================
Write-Section "Fortinet FortiClient"

try {
    $fortiServices = @("FA_Scheduler", "FortiClient", "FortiClientAgent")
    $fortiFound = $false

    foreach ($svcName in $fortiServices) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) {
            $fortiFound = $true
            if ($svc.Status -eq "Running") {
                Register-Check -Name "FortiClient Service" -Status PASS -Message "Running"
            } else {
                Register-Check -Name "FortiClient Service" -Status INFO -Message "$($svc.Status)"
            }
            break
        }
    }

    if (-not $fortiFound) {
        $fortiPath = "C:\Program Files\Fortinet\FortiClient"
        if (Test-Path $fortiPath) {
            Register-Check -Name "FortiClient" -Status INFO -Message "Installed but service not running"
        } else {
            Register-Check -Name "FortiClient" -Status INFO -Message "Not installed"
        }
    } else {
        # Version check
        $fortiExe = "C:\Program Files\Fortinet\FortiClient\FortiClient.exe"
        if (Test-Path $fortiExe) {
            $version = (Get-Item $fortiExe).VersionInfo.FileVersion
            Register-Check -Name "FortiClient Version" -Status INFO -Message "v$version"
        }
    }
} catch {
    Register-Check -Name "FortiClient" -Status INFO -Message "Not detected"
}

# ============================================================================
# NETSKOPE
# ============================================================================
Write-Section "Netskope Client"

try {
    $netskopeService = Get-Service -Name "SteerlightTeService" -ErrorAction SilentlyContinue
    if (-not $netskopeService) {
        $netskopeService = Get-Service -Name "NetskopeClient" -ErrorAction SilentlyContinue
    }

    if ($netskopeService) {
        if ($netskopeService.Status -eq "Running") {
            Register-Check -Name "Netskope Client" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Netskope Client" -Status INFO -Message "$($netskopeService.Status)"
        }
    } else {
        $netskopePath = "C:\Program Files (x86)\Netskope"
        if (Test-Path $netskopePath) {
            Register-Check -Name "Netskope" -Status INFO -Message "Installed but service not running"
        } else {
            Register-Check -Name "Netskope" -Status INFO -Message "Not installed"
        }
    }
} catch {
    Register-Check -Name "Netskope" -Status INFO -Message "Not detected"
}

# ============================================================================
# PULSE SECURE / IVANTI CONNECT SECURE
# ============================================================================
Write-Section "Pulse Secure / Ivanti"

try {
    $pulseService = Get-Service -Name "PulseSecureService" -ErrorAction SilentlyContinue
    if (-not $pulseService) {
        $pulseService = Get-Service -Name "dsNcService" -ErrorAction SilentlyContinue
    }

    if ($pulseService) {
        if ($pulseService.Status -eq "Running") {
            Register-Check -Name "Pulse Secure" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Pulse Secure" -Status INFO -Message "$($pulseService.Status)"
        }
    } else {
        Register-Check -Name "Pulse Secure" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Pulse Secure" -Status INFO -Message "Not detected"
}

# ============================================================================
# CITRIX GATEWAY (NetScaler)
# ============================================================================
Write-Section "Citrix Gateway"

try {
    $citrixService = Get-Service -Name "CitrixNetworkVPN" -ErrorAction SilentlyContinue
    if ($citrixService) {
        if ($citrixService.Status -eq "Running") {
            Register-Check -Name "Citrix Gateway VPN" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Citrix Gateway VPN" -Status INFO -Message "$($citrixService.Status)"
        }
    } else {
        Register-Check -Name "Citrix Gateway" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "Citrix Gateway" -Status INFO -Message "Not detected"
}

# ============================================================================
# WINDOWS BUILT-IN VPN
# ============================================================================
Write-Section "Windows Built-in VPN"

# Check for configured VPN connections
try {
    $vpnConnections = Get-VpnConnection -ErrorAction SilentlyContinue
    if ($vpnConnections) {
        $count = ($vpnConnections | Measure-Object).Count
        Register-Check -Name "Windows VPN Profiles" -Status INFO -Message "$count profile(s) configured"

        foreach ($vpn in $vpnConnections) {
            $status = if ($vpn.ConnectionStatus -eq "Connected") { "PASS" } else { "INFO" }
            $tunnelType = $vpn.TunnelType
            $authMethod = $vpn.AuthenticationMethod -join ", "
            Register-Check -Name "VPN: $($vpn.Name)" -Status $status -Message "$tunnelType ($authMethod)"

            # Check for weak protocols
            if ($vpn.TunnelType -eq "Pptp") {
                Register-Check -Name "VPN Protocol Warning" -Status WARN -Message "$($vpn.Name) uses PPTP (insecure)"
            }
        }
    } else {
        Register-Check -Name "Windows VPN Profiles" -Status INFO -Message "None configured"
    }
} catch {
    Register-Check -Name "Windows VPN" -Status INFO -Message "Unable to enumerate"
}

# RASMAN service
try {
    $rasman = Get-Service -Name "RasMan" -ErrorAction SilentlyContinue
    if ($rasman) {
        if ($rasman.Status -eq "Running") {
            Register-Check -Name "Remote Access Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Remote Access Service" -Status INFO -Message "$($rasman.Status)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ALWAYS ON VPN
# ============================================================================
Write-Section "Always On VPN"

try {
    # Check for device tunnel (SYSTEM context VPN)
    $deviceTunnel = Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue | Where-Object { $_.TunnelType -eq "Ikev2" }
    if ($deviceTunnel) {
        Register-Check -Name "Always On VPN Device Tunnel" -Status PASS -Message "Configured"
    }

    # Check registry for AOVPN config
    $aovpnPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\VPN"
    if (Test-Path $aovpnPath) {
        Register-Check -Name "AOVPN Registry" -Status INFO -Message "VPN configuration present"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# VPN SECURITY SETTINGS
# ============================================================================
Write-Section "VPN Security Configuration"

# Check IKEv2 settings
try {
    $ikev2Path = "HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Parameters"

    # Strong crypto negotiation
    $negotAuth = Get-ItemProperty -Path $ikev2Path -Name "NegotiateDH2048_AES256" -ErrorAction SilentlyContinue
    if ($negotAuth.NegotiateDH2048_AES256 -eq 1) {
        Register-Check -Name "IKEv2 Strong Crypto" -Status PASS -Message "DH2048+AES256 negotiation enabled"
    } else {
        Register-Check -Name "IKEv2 Strong Crypto" -Status INFO -Message "Standard negotiation"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Split tunneling detection
try {
    $vpnConnections = Get-VpnConnection -ErrorAction SilentlyContinue
    foreach ($vpn in $vpnConnections) {
        if ($vpn.SplitTunneling -eq $true) {
            Register-Check -Name "Split Tunneling: $($vpn.Name)" -Status WARN -Message "Enabled (security consideration)"
        } elseif ($vpn.SplitTunneling -eq $false) {
            Register-Check -Name "Full Tunnel: $($vpn.Name)" -Status PASS -Message "All traffic via VPN"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# VPN COVERAGE SUMMARY
# ============================================================================
Write-Section "VPN Coverage Summary"

$vpnProducts = @(
    @{Service="vpnagent"; Name="Cisco AnyConnect"},
    @{Service="PanGPS"; Name="GlobalProtect"},
    @{Service="ZSATunnel"; Name="Zscaler"},
    @{Service="FA_Scheduler"; Name="FortiClient"},
    @{Service="SteerlightTeService"; Name="Netskope"},
    @{Service="PulseSecureService"; Name="Pulse Secure"},
    @{Service="CitrixNetworkVPN"; Name="Citrix Gateway"}
)

$runningVPN = @()
foreach ($vpn in $vpnProducts) {
    $svc = Get-Service -Name $vpn.Service -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq "Running") {
        $runningVPN += $vpn.Name
    }
}

# Check Windows VPN connections
try {
    $connectedVPN = Get-VpnConnection -ErrorAction SilentlyContinue | Where-Object { $_.ConnectionStatus -eq "Connected" }
    if ($connectedVPN) {
        $runningVPN += "Windows VPN (Connected)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if ($runningVPN.Count -ge 1) {
    Register-Check -Name "VPN Status" -Status PASS -Message "Active: $($runningVPN -join ', ')"
} else {
    # Check if any VPN client is installed
    $installedVPN = @()
    foreach ($vpn in $vpnProducts) {
        $svc = Get-Service -Name $vpn.Service -ErrorAction SilentlyContinue
        if ($svc) {
            $installedVPN += $vpn.Name
        }
    }

    if ($installedVPN.Count -ge 1) {
        Register-Check -Name "VPN Status" -Status INFO -Message "Installed but not connected: $($installedVPN -join ', ')"
    } else {
        Register-Check -Name "VPN Status" -Status INFO -Message "No enterprise VPN client detected"
    }
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
