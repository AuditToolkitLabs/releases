# VSS Shadow Copies Security Audit Script (PowerShell)
# CIS Windows - Backup and Recovery
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: https://www.cisecurity.org/benchmark/windows_11

Import-Module "$PSScriptRoot/common-audit.psm1"

# Check VSS Shadow Copies
try {
    $shadows = Get-CimInstance -ClassName Win32_ShadowCopy -ErrorAction SilentlyContinue
    if ($shadows) {
        $count = @($shadows).Count
        Register-Check -Name "VSS Shadow Copies" -Status PASS -Message "$count shadow copies found - backup protection active"
        # Check if VSS service is running
        $vss = Get-Service -Name "VSS" -ErrorAction SilentlyContinue
        if ($vss.Status -eq 'Running') {
            Register-Check -Name "VSS Service" -Status PASS -Message "Volume Shadow Copy service is running"
        } else {
            Register-Check -Name "VSS Service" -Status WARN -Message "VSS service not running - may affect backups"
        }
    } else {
        Register-Check -Name "VSS Shadow Copies" -Status WARN -Message "No shadow copies found - consider enabling System Protection"
    }
} catch {
    Register-Check -Name "VSS Shadow Copies" -Status WARN -Message "Could not check shadow copies: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit