# Check Windows Firewall Status
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $profiles = Get-NetFirewallProfile
    $allActive = $profiles | Where-Object { $_.Enabled -eq $true }
    if ($allActive.Count -eq 3) {
        Register-Check -Name "Windows Firewall" -Status PASS -Message "All profiles enabled."
    } else {
        Register-Check -Name "Windows Firewall" -Status FAIL -Message "Not all profiles enabled."
    }
} catch {
    Register-Check -Name "Windows Firewall" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit