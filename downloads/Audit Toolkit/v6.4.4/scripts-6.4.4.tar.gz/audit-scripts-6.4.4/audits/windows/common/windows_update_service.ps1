# Check Windows Update Service
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $svc = Get-Service -Name "wuauserv" -ErrorAction SilentlyContinue
    if ($svc.Status -eq 'Running') {
        Register-Check -Name "Windows Update Service" -Status PASS -Message "Service is running."
    } else {
        Register-Check -Name "Windows Update Service" -Status FAIL -Message "Service is not running."
    }
} catch {
    Register-Check -Name "Windows Update Service" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit