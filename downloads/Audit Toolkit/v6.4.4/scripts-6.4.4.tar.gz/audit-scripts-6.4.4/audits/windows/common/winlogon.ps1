# Check Winlogon Auto-Logon
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "AutoAdminLogon" -ErrorAction SilentlyContinue
    if ($reg.AutoAdminLogon -eq 1) {
        Register-Check -Name "Winlogon Auto-Logon" -Status FAIL -Message "Auto-Logon is enabled."
    } else {
        Register-Check -Name "Winlogon Auto-Logon" -Status PASS -Message "Auto-Logon is disabled."
    }
} catch {
    Register-Check -Name "Winlogon Auto-Logon" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit