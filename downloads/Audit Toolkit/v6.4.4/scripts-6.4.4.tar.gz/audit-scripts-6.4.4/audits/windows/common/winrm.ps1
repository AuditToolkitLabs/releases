# Check WinRM Configuration
Import-Module "$PSScriptRoot/common-audit.psm1"
try {
    $winrm = Get-Service -Name WinRM -ErrorAction SilentlyContinue
    if ($winrm.Status -eq 'Running') {
        $config = winrm get winrm/config/Service
        if ($config -match 'Transport = HTTPS') {
            Register-Check -Name "WinRM" -Status PASS -Message "Running and requires HTTPS."
        } else {
            Register-Check -Name "WinRM" -Status WARN -Message "Running but may not require HTTPS."
        }
    } else {
        Register-Check -Name "WinRM" -Status PASS -Message "Not running."
    }
} catch {
    Register-Check -Name "WinRM" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit