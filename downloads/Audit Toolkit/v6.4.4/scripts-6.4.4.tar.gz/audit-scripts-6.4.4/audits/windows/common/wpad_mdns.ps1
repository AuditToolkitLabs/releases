# WPAD and mDNS Security Audit Script (PowerShell)
# CIS Windows 11 Benchmark - Network Security
# This script is read-only and does not modify system state.
#
# References:
# - CIS Windows 11 Benchmark: https://www.cisecurity.org/benchmark/windows_11
# - WPAD Security Risks: https://en.wikipedia.org/wiki/Web_Proxy_Auto-Discovery_Protocol

Import-Module "$PSScriptRoot/common-audit.psm1"

# Check WPAD (Web Proxy Auto-Discovery) - CIS 18.5.14.1
$wpad = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinHttpAutoProxySvc" -Name "Start" -ErrorAction SilentlyContinue
if ($wpad.Start -eq 4) {
    Register-Check -Name "WPAD Service" -Status PASS -Message "WinHTTP Auto-Proxy service is disabled"
} elseif ($wpad.Start) {
    Register-Check -Name "WPAD Service" -Status WARN -Message "WPAD service is enabled (Start=$($wpad.Start)) - consider disabling"
} else {
    Register-Check -Name "WPAD Service" -Status WARN -Message "Could not determine WPAD service status"
}

# Check mDNS (Multicast DNS) - CIS 18.5.5.1
try {
    $mdnsKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -ErrorAction SilentlyContinue
    if ($mdnsKey.EnableMulticast -eq 0) {
        Register-Check -Name "mDNS (Multicast DNS)" -Status PASS -Message "mDNS is disabled via policy"
    } else {
        Register-Check -Name "mDNS (Multicast DNS)" -Status WARN -Message "mDNS is enabled - potential name resolution spoofing risk"
    }
} catch {
    Register-Check -Name "mDNS (Multicast DNS)" -Status WARN -Message "mDNS policy not configured - enabled by default"
}

# Check LLMNR - CIS 18.5.4.1
try {
    Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -ErrorAction SilentlyContinue | Out-Null
    # LLMNR uses same key in some configurations, also check specific LLMNR key
    $llmnrKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -ErrorAction SilentlyContinue
    if ($llmnrKey -and $llmnrKey.EnableMulticast -eq 0) {
        Register-Check -Name "LLMNR" -Status PASS -Message "LLMNR is disabled"
    } else {
        Register-Check -Name "LLMNR" -Status WARN -Message "LLMNR may be enabled - potential MITM risk"
    }
} catch {
    Register-Check -Name "LLMNR" -Status WARN -Message "Could not check LLMNR status"
}

Print-Summary
Exit-Audit