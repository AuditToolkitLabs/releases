# WSUS/SCCM/Intune Update Compliance Audit (PowerShell)
# Checks Windows Update policies per CIS 18.10.x and enterprise management status
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Windows 11 Benchmark v2.0 - Section 18.10
# - NIST SP 800-53: SI-2 (Flaw Remediation)

Import-Module "$PSScriptRoot/common-audit.psm1"

# ============================================================================
# HELPER FUNCTION
# ============================================================================

function Test-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$ExpectedValue,
        [string]$Description,
        [string]$CISRef = "",
        [switch]$GreaterOrEqual,
        [switch]$LessOrEqual
    )

    $displayName = if ($CISRef) { "($CISRef) $Description" } else { $Description }

    try {
        $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        $actualValue = $value.$Name

        $passed = $false
        if ($GreaterOrEqual) {
            $passed = $actualValue -ge $ExpectedValue
        } elseif ($LessOrEqual) {
            $passed = $actualValue -le $ExpectedValue
        } else {
            $passed = $actualValue -eq $ExpectedValue
        }

        if ($passed) {
            Register-Check -Name $displayName -Status PASS -Message "Value: $actualValue"
        } else {
            Register-Check -Name $displayName -Status WARN -Message "Value: $actualValue (expected: $ExpectedValue)"
        }
    } catch {
        Register-Check -Name $displayName -Status INFO -Message "Not configured"
    }
}

# ============================================================================
# WINDOWS UPDATE SERVICE
# ============================================================================
Write-Section "Windows Update Service"

try {
    $wuService = Get-Service -Name wuauserv -ErrorAction SilentlyContinue
    if ($wuService -and $wuService.Status -eq 'Running') {
        Register-Check -Name "Windows Update Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Windows Update Service" -Status WARN -Message "$($wuService.Status)"
    }
} catch {
    Register-Check -Name "Windows Update Service" -Status WARN -Message $_.Exception.Message
}

# BITS service
try {
    $bits = Get-Service -Name BITS -ErrorAction SilentlyContinue
    if ($bits.Status -eq 'Running' -or $bits.StartType -eq 'Manual') {
        Register-Check -Name "BITS Service" -Status PASS -Message "$($bits.Status)"
    } else {
        Register-Check -Name "BITS Service" -Status WARN -Message "$($bits.StartType)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# WSUS CONFIGURATION
# ============================================================================
Write-Section "WSUS Configuration"

$wuPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
$auPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"

try {
    $wsusReg = Get-ItemProperty -Path $wuPath -ErrorAction SilentlyContinue
    if ($wsusReg -and $wsusReg.WUServer) {
        Register-Check -Name "WSUS Server" -Status PASS -Message $wsusReg.WUServer

        # Status server
        if ($wsusReg.WUStatusServer) {
            Register-Check -Name "WSUS Status Server" -Status INFO -Message $wsusReg.WUStatusServer
        }
    } else {
        Register-Check -Name "WSUS Server" -Status INFO -Message "Not configured (using Microsoft Update)"
    }
} catch {
    Register-Check -Name "WSUS Configuration" -Status WARN -Message "Unable to check"
}

# ============================================================================
# CIS 18.10.92 - Windows Update for Business
# ============================================================================
Write-Section "18.10.92 Windows Update for Business"

# 18.10.92.1.1 (L1) Ensure 'Manage preview builds' is set to 'Disabled'
Test-RegistryValue -Path $wuPath -Name "ManagePreviewBuildsPolicyValue" -ExpectedValue 1 `
    -Description "Manage preview builds" -CISRef "18.10.92.1.1"

# 18.10.92.2.1 (L1) Ensure 'Select when Preview Builds and Feature Updates are received'
Test-RegistryValue -Path $wuPath -Name "DeferFeatureUpdates" -ExpectedValue 1 `
    -Description "Defer feature updates enabled" -CISRef "18.10.92.2.1"

# Deferral period (days)
try {
    $deferral = Get-ItemProperty -Path $wuPath -Name "DeferFeatureUpdatesPeriodInDays" -ErrorAction SilentlyContinue
    if ($deferral.DeferFeatureUpdatesPeriodInDays -ge 180) {
        Register-Check -Name "Feature Update Deferral" -Status PASS -Message "$($deferral.DeferFeatureUpdatesPeriodInDays) days"
    } elseif ($deferral.DeferFeatureUpdatesPeriodInDays -gt 0) {
        Register-Check -Name "Feature Update Deferral" -Status INFO -Message "$($deferral.DeferFeatureUpdatesPeriodInDays) days (recommend 180+)"
    } else {
        Register-Check -Name "Feature Update Deferral" -Status INFO -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# 18.10.92.3.1 (L1) Ensure 'Select when Quality Updates are received'
Test-RegistryValue -Path $wuPath -Name "DeferQualityUpdates" -ExpectedValue 1 `
    -Description "Defer quality updates enabled" -CISRef "18.10.92.3.1"

# Quality update deferral (days)
try {
    $qualDeferral = Get-ItemProperty -Path $wuPath -Name "DeferQualityUpdatesPeriodInDays" -ErrorAction SilentlyContinue
    if ($qualDeferral.DeferQualityUpdatesPeriodInDays -ge 0 -and $qualDeferral.DeferQualityUpdatesPeriodInDays -le 30) {
        Register-Check -Name "Quality Update Deferral" -Status INFO -Message "$($qualDeferral.DeferQualityUpdatesPeriodInDays) days"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# AUTOMATIC UPDATE SETTINGS
# ============================================================================
Write-Section "Automatic Update Settings"

# Configure Automatic Updates
try {
    $auSettings = Get-ItemProperty -Path $auPath -ErrorAction SilentlyContinue
    if ($auSettings) {
        $auOptionText = switch ($auSettings.AUOptions) {
            2 { "Notify before download" }
            3 { "Auto download, notify install" }
            4 { "Auto download, schedule install" }
            5 { "Local admin chooses" }
            7 { "Auto download, notify restart" }
            default { "Unknown ($($auSettings.AUOptions))" }
        }
        Register-Check -Name "Auto Update Option" -Status INFO -Message $auOptionText

        if ($auSettings.NoAutoUpdate -eq 1) {
            Register-Check -Name "Auto Updates Disabled" -Status FAIL -Message "Updates disabled via policy"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Active Hours
try {
    $activeHours = Get-ItemProperty -Path $wuPath -Name "ActiveHoursStart","ActiveHoursEnd" -ErrorAction SilentlyContinue
    if ($null -ne $activeHours.ActiveHoursStart -and $null -ne $activeHours.ActiveHoursEnd) {
        Register-Check -Name "Active Hours" -Status INFO -Message "$($activeHours.ActiveHoursStart):00 - $($activeHours.ActiveHoursEnd):00"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Scheduled install day/time
try {
    $schedule = Get-ItemProperty -Path $auPath -Name "ScheduledInstallDay","ScheduledInstallTime" -ErrorAction SilentlyContinue
    if ($null -ne $schedule.ScheduledInstallDay) {
        $dayName = switch ($schedule.ScheduledInstallDay) {
            0 { "Every day" }
            1 { "Sunday" }
            2 { "Monday" }
            3 { "Tuesday" }
            4 { "Wednesday" }
            5 { "Thursday" }
            6 { "Friday" }
            7 { "Saturday" }
            default { "Day $($schedule.ScheduledInstallDay)" }
        }
        Register-Check -Name "Scheduled Install" -Status INFO -Message "$dayName at $($schedule.ScheduledInstallTime):00"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DELIVERY OPTIMIZATION
# ============================================================================
Write-Section "Delivery Optimization"

$doPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization"

# 18.10.15.1 (L1) Ensure 'Download Mode' is NOT set to 'Internet'
try {
    $doMode = Get-ItemProperty -Path $doPath -Name "DODownloadMode" -ErrorAction SilentlyContinue
    $modeText = switch ($doMode.DODownloadMode) {
        0 { "HTTP only (Bypass)" }
        1 { "LAN" }
        2 { "Group" }
        3 { "Internet (not recommended)" }
        99 { "Simple (HTTP only)" }
        100 { "Bypass" }
        default { "Unknown ($($doMode.DODownloadMode))" }
    }

    if ($doMode.DODownloadMode -eq 3) {
        Register-Check -Name "(18.10.15.1) DO Download Mode" -Status WARN -Message $modeText
    } else {
        Register-Check -Name "(18.10.15.1) DO Download Mode" -Status PASS -Message $modeText
    }
} catch {
    Register-Check -Name "(18.10.15.1) DO Download Mode" -Status INFO -Message "Not configured (defaults to LAN)"
}

# DO Group ID (for enterprise)
try {
    $doGroupId = Get-ItemProperty -Path $doPath -Name "DOGroupId" -ErrorAction SilentlyContinue
    if ($doGroupId.DOGroupId) {
        Register-Check -Name "DO Group ID" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# DO Cache Server
try {
    $doCacheHost = Get-ItemProperty -Path $doPath -Name "DOCacheHost" -ErrorAction SilentlyContinue
    if ($doCacheHost.DOCacheHost) {
        Register-Check -Name "DO Cache Server" -Status INFO -Message $doCacheHost.DOCacheHost
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SCCM/CONFIGMGR CLIENT
# ============================================================================
Write-Section "Configuration Manager (SCCM)"

try {
    $ccmExec = Get-Service -Name "CcmExec" -ErrorAction SilentlyContinue

    if ($ccmExec) {
        if ($ccmExec.Status -eq "Running") {
            Register-Check -Name "SCCM Client Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "SCCM Client Service" -Status WARN -Message "$($ccmExec.Status)"
        }

        # Get assigned site
        try {
            $sms = Get-CimInstance -Namespace "root\ccm" -ClassName "SMS_Client" -ErrorAction SilentlyContinue
            if ($sms) {
                $siteCode = (Get-CimInstance -Namespace "root\ccm" -ClassName "SMS_Authority" -ErrorAction SilentlyContinue).Name
                Register-Check -Name "SCCM Site Assignment" -Status INFO -Message $siteCode
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Check compliance state
        try {
            $compliance = Get-CimInstance -Namespace "root\ccm\SoftwareUpdates\UpdatesStore" -ClassName "CCM_UpdateStatus" -ErrorAction SilentlyContinue |
                Where-Object { $_.Status -eq "Missing" } |
                Measure-Object
            if ($compliance.Count -eq 0) {
                Register-Check -Name "SCCM Update Compliance" -Status PASS -Message "No missing updates"
            } else {
                Register-Check -Name "SCCM Update Compliance" -Status WARN -Message "$($compliance.Count) missing update(s)"
            }
        } catch {
            Register-Check -Name "SCCM Update Compliance" -Status INFO -Message "Unable to query"
        }
    } else {
        Register-Check -Name "SCCM Client" -Status INFO -Message "Not installed"
    }
} catch {
    Register-Check -Name "SCCM Client" -Status INFO -Message "Not detected"
}

# ============================================================================
# INTUNE/MDM ENROLLMENT
# ============================================================================
Write-Section "Intune/MDM Enrollment"

try {
    $mdmPath = "HKLM:\SOFTWARE\Microsoft\Enrollments"
    $enrollments = Get-ChildItem -Path $mdmPath -ErrorAction SilentlyContinue | Where-Object {
        $props = Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue
        $props.EnrollmentType -ne $null
    }

    if ($enrollments) {
        Register-Check -Name "MDM Enrollment" -Status PASS -Message "Device enrolled"

        foreach ($enrollment in $enrollments) {
            $props = Get-ItemProperty -Path $enrollment.PSPath -ErrorAction SilentlyContinue
            if ($props.UPN) {
                Register-Check -Name "MDM UPN" -Status INFO -Message $props.UPN
            }
            if ($props.ProviderID) {
                Register-Check -Name "MDM Provider" -Status INFO -Message $props.ProviderID
            }
        }
    } else {
        Register-Check -Name "MDM Enrollment" -Status INFO -Message "Not enrolled"
    }
} catch {
    Register-Check -Name "MDM Enrollment" -Status INFO -Message "Unable to check"
}

# Check DMClient service
try {
    $dmClient = Get-Service -Name "dmwappushservice" -ErrorAction SilentlyContinue
    if ($dmClient.Status -eq "Running") {
        Register-Check -Name "Device Management Service" -Status PASS -Message "Running"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# PENDING UPDATES
# ============================================================================
Write-Section "Update Status"

try {
    $session = New-Object -ComObject Microsoft.Update.Session -ErrorAction SilentlyContinue
    $searcher = $session.CreateUpdateSearcher()
    $pending = $searcher.Search("IsInstalled=0 and Type='Software'")

    if ($pending.Updates.Count -eq 0) {
        Register-Check -Name "Pending Updates" -Status PASS -Message "No pending updates"
    } else {
        $critical = ($pending.Updates | Where-Object { $_.MsrcSeverity -eq "Critical" }).Count
        $important = ($pending.Updates | Where-Object { $_.MsrcSeverity -eq "Important" }).Count

        if ($critical -gt 0) {
            Register-Check -Name "Pending Updates" -Status FAIL -Message "$($pending.Updates.Count) pending ($critical critical)"
        } elseif ($important -gt 0) {
            Register-Check -Name "Pending Updates" -Status WARN -Message "$($pending.Updates.Count) pending ($important important)"
        } else {
            Register-Check -Name "Pending Updates" -Status INFO -Message "$($pending.Updates.Count) pending"
        }
    }
} catch {
    Register-Check -Name "Pending Updates" -Status INFO -Message "Unable to query (may require elevation)"
}

# Last successful update
try {
    $lastUpdate = Get-HotFix -ErrorAction SilentlyContinue |
        Sort-Object InstalledOn -Descending |
        Select-Object -First 1
    if ($lastUpdate.InstalledOn) {
        $daysSince = ((Get-Date) - $lastUpdate.InstalledOn).Days
        if ($daysSince -le 30) {
            Register-Check -Name "Last Update Installed" -Status PASS -Message "$($lastUpdate.InstalledOn.ToString('yyyy-MM-dd')) ($daysSince days ago)"
        } elseif ($daysSince -le 60) {
            Register-Check -Name "Last Update Installed" -Status WARN -Message "$($lastUpdate.InstalledOn.ToString('yyyy-MM-dd')) ($daysSince days ago)"
        } else {
            Register-Check -Name "Last Update Installed" -Status FAIL -Message "$($lastUpdate.InstalledOn.ToString('yyyy-MM-dd')) ($daysSince days ago)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# REBOOT PENDING
# ============================================================================
Write-Section "Reboot Status"

$rebootRequired = $false
$rebootReasons = @()

# Component Based Servicing
if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") {
    $rebootRequired = $true
    $rebootReasons += "CBS"
}

# Windows Update
if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") {
    $rebootRequired = $true
    $rebootReasons += "Windows Update"
}

# Pending file rename operations
try {
    $pendingRename = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "PendingFileRenameOperations" -ErrorAction SilentlyContinue
    if ($pendingRename.PendingFileRenameOperations) {
        $rebootRequired = $true
        $rebootReasons += "File rename"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# SCCM reboot pending
try {
    $ccmReboot = Invoke-CimMethod -Namespace "root\ccm\ClientSDK" -ClassName "CCM_ClientUtilities" -MethodName "DetermineIfRebootPending" -ErrorAction SilentlyContinue
    if ($ccmReboot.RebootPending -or $ccmReboot.IsHardRebootPending) {
        $rebootRequired = $true
        $rebootReasons += "SCCM"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

if ($rebootRequired) {
    Register-Check -Name "Reboot Pending" -Status WARN -Message "Required: $($rebootReasons -join ', ')"
} else {
    Register-Check -Name "Reboot Pending" -Status PASS -Message "No reboot required"
}

# ============================================================================
# SUMMARY
# ============================================================================

Print-Summary
Exit-Audit
