# Check Edge Browser Extensions Policy
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallBlocklist" -ErrorAction SilentlyContinue
    if ($reg) {
        Register-Check -Name "Edge Extension Blocklist" -Status PASS -Message "Blocklist is configured."
    } else {
        Register-Check -Name "Edge Extension Blocklist" -Status FAIL -Message "Blocklist is not configured."
    }
} catch {
    Register-Check -Name "Edge Extension Blocklist" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit