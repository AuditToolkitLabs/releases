# Check Edge Browser SmartScreen Policy
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "SmartScreenEnabled" -ErrorAction SilentlyContinue
    if ($reg.SmartScreenEnabled -eq 1) {
        Register-Check -Name "Edge SmartScreen" -Status PASS -Message "SmartScreen is enabled."
    } else {
        Register-Check -Name "Edge SmartScreen" -Status FAIL -Message "SmartScreen is not enabled."
    }
} catch {
    Register-Check -Name "Edge SmartScreen" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit