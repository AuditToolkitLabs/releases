# Check Teams Telemetry Settings
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Teams" -Name "UploadTelemetry" -ErrorAction SilentlyContinue
    if ($reg.UploadTelemetry -eq 0) {
        Register-Check -Name "Teams Telemetry Upload" -Status PASS -Message "Telemetry upload is disabled."
    } else {
        Register-Check -Name "Teams Telemetry Upload" -Status FAIL -Message "Telemetry upload is not disabled."
    }
} catch {
    Register-Check -Name "Teams Telemetry Upload" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit