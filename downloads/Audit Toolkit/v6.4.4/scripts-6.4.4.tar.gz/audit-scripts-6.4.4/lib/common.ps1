#Requires -Version 5.1
<#
.SYNOPSIS
    Common PowerShell library for Windows security audits

.DESCRIPTION
    This library provides reusable functions for Windows audit scripts,
    equivalent to the Bash lib/common.sh for Linux audits.

    Functions include:
    - Write-Section: Output formatted section headers
    - Register-Check: Register audit check results ([PASS]/[WARN]/[FAIL]/[SKIP])
    - Print-Summary: Output audit summary with totals
    - Get-WindowsVersion: Detect Windows version and edition
    - Test-IsAdminMode: Check if running as Administrator
    - Test-IsServerOS: Check if Windows Server (vs. Workstation)
    - Test-IsDomainJoined: Check if joined to Active Directory domain

.EXAMPLE
    # Source this library at the start of audit scripts
    . "$PSScriptRoot\..\lib\common.ps1"

    Write-Section "Windows Updates Audit"

    if (Test-IsAdminMode) {
        Register-Check "Administrator Mode" "PASS" "Running with admin privileges"
    } else {
        Register-Check "Administrator Mode" "FAIL" "Admin rights required"
        exit 2
    }

    Print-Summary

.NOTES
    Author: Multi-Server Audit Dashboard Team
    Version: 1.0.0
    Created: February 2026
    License: Business Source License 1.1
#>

# Exit codes (match Bash audit conventions)
$script:EXIT_CODE_PASS = 0
$script:EXIT_CODE_WARN = 1
$script:EXIT_CODE_FAIL = 2

# Global counters for audit results
$script:TotalChecks = 0
$script:PassedChecks = 0
$script:WarnedChecks = 0
$script:FailedChecks = 0
$script:SkippedChecks = 0
$script:ExitCode = 0

# Color scheme (matches Bash output)
$script:Colors = @{
    Section = 'Cyan'
    Pass = 'Green'
    Warn = 'Yellow'
    Fail = 'Red'
    Skip = 'Gray'
    Info = 'White'
}

<#
.SYNOPSIS
    Output a formatted section header

.DESCRIPTION
    Displays a section title with visual separators, matching the Bash
    audit script output format.

.PARAMETER Title
    The section title to display

.EXAMPLE
    Write-Section "Windows Updates Check"

.OUTPUTS
    None. Writes to host with colored formatting.
#>
function Write-Section {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, Position=0)]
        [string]$Title
    )

    Write-Output ""
    Write-Output "========================================"
    Write-Output "  $Title"
    Write-Output "========================================"
    Write-Output ""
}

<#
.SYNOPSIS
    Register an audit check result

.DESCRIPTION
    Records the result of a single audit check and updates global counters.
    Outputs formatted result matching Bash script format: [PASS], [WARN], [FAIL], [SKIP]

.PARAMETER Name
    Name of the check being performed

.PARAMETER Status
    Result status: 'PASS', 'WARN', 'FAIL', or 'SKIP'

.PARAMETER Message
    Optional message providing additional context

.EXAMPLE
    Register-Check "Windows Defender" "PASS" "Real-time protection enabled"

.EXAMPLE
    Register-Check "Pending Updates" "WARN" "12 updates available"

.OUTPUTS
    None. Updates global counters and writes formatted output to host.
#>
function Register-Check {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, Position=0)]
        [string]$Name,

        [Parameter(Mandatory=$true, Position=1)]
        [ValidateSet('PASS', 'WARN', 'FAIL', 'SKIP')]
        [string]$Status,

        [Parameter(Mandatory=$false, Position=2)]
        [string]$Message = ""
    )

    $script:TotalChecks++

    switch ($Status) {
        'PASS' {
            $script:PassedChecks++
            Write-Output "  [PASS] $Name"

            # Keep exit code 0 if currently passing
            if ($script:ExitCode -eq 0) {
                $script:ExitCode = $script:EXIT_CODE_PASS
            }
        }

        'WARN' {
            $script:WarnedChecks++
            Write-Output "  [WARN] $Name"

            # Set exit code to 1 if not already failed
            if ($script:ExitCode -lt $script:EXIT_CODE_WARN) {
                $script:ExitCode = $script:EXIT_CODE_WARN
            }
        }

        'FAIL' {
            $script:FailedChecks++
            Write-Output "  [FAIL] $Name"

            # Set exit code to 2 (highest severity)
            $script:ExitCode = $script:EXIT_CODE_FAIL
        }

        'SKIP' {
            $script:SkippedChecks++
            Write-Output "  [SKIP] $Name"

            # Skipped checks don't change exit code
        }
    }

    # Print message if provided
    if ($Message) {
        Write-Output "        $Message"
    }
}

<#
.SYNOPSIS
    Print audit summary with totals

.DESCRIPTION
    Outputs a formatted summary table showing total checks performed and
    results breakdown. Should be called at the end of every audit script.

.EXAMPLE
    Print-Summary

.OUTPUTS
    None. Writes formatted summary to host.
#>
function Show-Summary {
    [CmdletBinding()]
    param()

    Write-Output ""
    Write-Output "========================================"
    Write-Output "AUDIT SUMMARY"
    Write-Output "========================================"
    Write-Output "Total Checks:   $script:TotalChecks"
    Write-Output "Passed:         $script:PassedChecks"
    Write-Output "Warnings:       $script:WarnedChecks"
    Write-Output "Failed:         $script:FailedChecks"
    Write-Output "Skipped:        $script:SkippedChecks"
    Write-Output "========================================"
    Write-Output ""
}

function Print-Summary {
    [CmdletBinding()]
    param()

    Show-Summary
}

# Backward compatibility alias retained for existing external callers.
Set-Alias -Name print_summary -Value Print-Summary -Scope Script

<#
.SYNOPSIS
    Get Windows version and edition information

.DESCRIPTION
    Detects the Windows version, build number, edition (Server/Workstation),
    and product type (Standard/Datacenter/Professional/etc.)

.EXAMPLE
    $version = Get-WindowsVersion
    if ($version.IsServer) {
        Write-Output "Running on Windows Server $($version.FriendlyVersion)"
    }

.OUTPUTS
    PSCustomObject with properties:
    - Caption: Full OS name (e.g., "Microsoft Windows Server 2019 Datacenter")
    - Version: Version number (e.g., "10.0.17763")
    - Build: Build number (e.g., "17763")
    - FriendlyVersion: Marketing version (e.g., "Server 2019")
    - Edition: Edition name (e.g., "Datacenter")
    - IsServer: Boolean indicating if Windows Server
    - ProductType: 1=Workstation, 2=Domain Controller, 3=Server
#>
function Get-WindowsVersion {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $os = Get-CimInstance -ClassName Win32_OperatingSystem

    # Map build numbers to marketing versions
    $buildMap = @{
        '17763' = 'Server 2019'
        '20348' = 'Server 2022'
        '14393' = 'Server 2016'
        '9600'  = 'Server 2012 R2'
        '9200'  = 'Server 2012'
        '19041' = '10 version 2004'
        '19042' = '10 version 20H2'
        '19043' = '10 version 21H1'
        '19044' = '10 version 21H2'
        '22000' = '11 version 21H2'
        '22621' = '11 version 22H2'
    }

    $build = $os.BuildNumber
    $friendlyVersion = $buildMap[$build]

    if (-not $friendlyVersion) {
        $friendlyVersion = "Build $build"
    }

    # Determine edition
    $caption = $os.Caption
    $edition = 'Unknown'

    if ($caption -match 'Datacenter') {
        $edition = 'Datacenter'
    }
    elseif ($caption -match 'Standard') {
        $edition = 'Standard'
    }
    elseif ($caption -match 'Essentials') {
        $edition = 'Essentials'
    }
    elseif ($caption -match 'Professional') {
        $edition = 'Professional'
    }
    elseif ($caption -match 'Enterprise') {
        $edition = 'Enterprise'
    }
    elseif ($caption -match 'Home') {
        $edition = 'Home'
    }

    [PSCustomObject]@{
        Caption = $caption
        Version = $os.Version
        Build = $build
        FriendlyVersion = $friendlyVersion
        Edition = $edition
        ProductType = $os.ProductType
        IsServer = ($os.ProductType -eq 2 -or $os.ProductType -eq 3)
        IsWorkstation = ($os.ProductType -eq 1)
        IsDomainController = ($os.ProductType -eq 2)
        Architecture = $os.OSArchitecture
    }
}

<#
.SYNOPSIS
    Test if script is running as Administrator

.DESCRIPTION
    Checks if the current PowerShell session has Administrator privileges.
    Most audit scripts require admin rights to access security settings.

.EXAMPLE
    if (-not (Test-IsAdminMode)) {
        Write-Error "This script requires Administrator privileges"
        exit 2
    }

.OUTPUTS
    Boolean. $true if running as Administrator, $false otherwise.
#>
function Test-IsAdminMode {
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

<#
.SYNOPSIS
    Test if running on Windows Server

.DESCRIPTION
    Determines if the OS is Windows Server (any edition) or Windows Workstation.
    Useful for skipping server-specific checks on workstations.

.EXAMPLE
    if (Test-IsServerOS) {
        # Perform server-specific checks
        Register-Check "IIS Configuration" "PASS"
    } else {
        Register-Check "IIS Configuration" "SKIP" "Not a server OS"
    }

.OUTPUTS
    Boolean. $true if Windows Server, $false if workstation/client.
#>
function Test-IsServerOS {
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    $os = Get-CimInstance -ClassName Win32_OperatingSystem

    # ProductType: 1 = Workstation, 2 = Domain Controller, 3 = Server
    return ($os.ProductType -eq 2 -or $os.ProductType -eq 3)
}

<#
.SYNOPSIS
    Test if computer is joined to an Active Directory domain

.DESCRIPTION
    Checks if the computer is a member of an Active Directory domain
    or is in a workgroup.

.EXAMPLE
    if (Test-IsDomainJoined) {
        $domain = (Get-CimInstance Win32_ComputerSystem).Domain
        Register-Check "Domain Membership" "PASS" "Joined to $domain"
    } else {
        Register-Check "Domain Membership" "WARN" "Not domain-joined"
    }

.OUTPUTS
    Boolean. $true if domain-joined, $false if workgroup.
#>
function Test-IsDomainJoined {
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    return $cs.PartOfDomain
}

<#
.SYNOPSIS
    Get Active Directory domain information

.DESCRIPTION
    Retrieves domain name and domain controller details if computer is
    domain-joined. Returns $null if in workgroup.

.EXAMPLE
    $domain = Get-DomainInfo
    if ($domain) {
        Write-Output "Domain: $($domain.Name)"
        Write-Output "Domain Controller: $($domain.DomainController)"
    }

.OUTPUTS
    PSCustomObject with domain information, or $null if not domain-joined.
#>
function Get-DomainInfo {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    if (-not (Test-IsDomainJoined)) {
        return $null
    }

    $cs = Get-CimInstance -ClassName Win32_ComputerSystem

    try {
        $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()

        [PSCustomObject]@{
            Name = $cs.Domain
            DomainController = $domain.PdcRoleOwner.Name
            ForestName = $domain.Forest.Name
            DomainMode = $domain.DomainMode
            ForestMode = $domain.Forest.ForestMode
        }
    }
    catch {
        # Fallback if AD queries fail
        [PSCustomObject]@{
            Name = $cs.Domain
            DomainController = $null
            ForestName = $null
            DomainMode = $null
            ForestMode = $null
        }
    }
}

<#
.SYNOPSIS
    Test if a Windows service exists and is running

.DESCRIPTION
    Checks if a Windows service is installed and optionally if it's running.
    Useful for auditing security-related services.

.PARAMETER ServiceName
    Name of the service to check

.PARAMETER MustBeRunning
    If $true, requires service to be running (not just installed)

.EXAMPLE
    if (Test-ServiceRunning "WinDefend") {
        Register-Check "Windows Defender Service" "PASS"
    } else {
        Register-Check "Windows Defender Service" "FAIL" "Service not running"
    }

.OUTPUTS
    Boolean. $true if service exists (and running if required), $false otherwise.
#>
function Test-ServiceRunning {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,

        [Parameter(Mandatory=$false)]
        [switch]$MustBeRunning
    )

    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

    if (-not $service) {
        return $false
    }

    if ($MustBeRunning) {
        return ($service.Status -eq 'Running')
    }

    return $true
}

<#
.SYNOPSIS
    Test if Windows Firewall is enabled

.DESCRIPTION
    Checks if Windows Defender Firewall is enabled for all profiles
    (Domain, Private, Public).

.EXAMPLE
    if (Test-FirewallEnabled) {
        Register-Check "Windows Firewall" "PASS" "Enabled on all profiles"
    } else {
        Register-Check "Windows Firewall" "FAIL" "Disabled on one or more profiles"
    }

.OUTPUTS
    Boolean. $true if enabled on all profiles, $false otherwise.
#>
function Test-FirewallEnabled {
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        $allEnabled = $true

        foreach ($fwEntry in $profiles) {
            if (-not $fwEntry.Enabled) {
                $allEnabled = $false
                break
            }
        }

        return $allEnabled
    }
    catch {
        # If command fails (older Windows versions), try registry
        try {
            $key = 'HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy'

            $domainEnabled = (Get-ItemProperty "$key\DomainProfile" -Name EnableFirewall).EnableFirewall
            $privateEnabled = (Get-ItemProperty "$key\StandardProfile" -Name EnableFirewall).EnableFirewall
            $publicEnabled = (Get-ItemProperty "$key\PublicProfile" -Name EnableFirewall).EnableFirewall

            return ($domainEnabled -eq 1 -and $privateEnabled -eq 1 -and $publicEnabled -eq 1)
        }
        catch {
            return $false
        }
    }
}

<#
.SYNOPSIS
    Get count of pending Windows updates

.DESCRIPTION
    Queries Windows Update for available updates that haven't been installed.
    Requires Windows Update service to be accessible.

.EXAMPLE
    $updateCount = Get-PendingUpdateCount
    if ($updateCount -eq 0) {
        Register-Check "Pending Updates" "PASS" "No updates pending"
    } else {
        Register-Check "Pending Updates" "WARN" "$updateCount updates available"
    }

.OUTPUTS
    Integer. Number of pending updates, or -1 if unable to query.
#>
function Get-PendingUpdateCount {
    [CmdletBinding()]
    [OutputType([int])]
    param()

    try {
        # Try PSWindowsUpdate module first (if installed)
        if (Get-Module -ListAvailable -Name PSWindowsUpdate) {
            Import-Module PSWindowsUpdate -ErrorAction Stop
            $updates = Get-WindowsUpdate -ErrorAction Stop
            return $updates.Count
        }

        # Fallback to COM objects
        $updateSession = New-Object -ComObject Microsoft.Update.Session
        $updateSearcher = $updateSession.CreateUpdateSearcher()
        $searchResult = $updateSearcher.Search("IsInstalled=0 and Type='Software'")

        return $searchResult.Updates.Count
    }
    catch {
        # Return -1 if unable to query
        return -1
    }
}

<#
.SYNOPSIS
    Export functions for use by audit scripts

.DESCRIPTION
    Makes library functions available to scripts that source this file.
#>
Export-ModuleMember -Function @(
    'Write-Section',
    'Register-Check',
    'Print-Summary',
    'Get-WindowsVersion',
    'Test-IsAdminMode',
    'Test-IsServerOS',
    'Test-IsDomainJoined',
    'Get-DomainInfo',
    'Test-ServiceRunning',
    'Test-FirewallEnabled',
    'Get-PendingUpdateCount'
)

# Make exit code accessible to scripts
Export-ModuleMember -Variable 'ExitCode'
