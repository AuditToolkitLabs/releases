#!/usr/bin/env bash
# Common logging, markers, and summary helpers
set -euo pipefail

: "${LOG_FILE:=}"
: "${QUIET:=false}"
: "${VERBOSE:=false}"
: "${VERY_VERBOSE:=false}"
: "${NO_COLOR:=false}"
: "${JSON_OUTPUT:=}"
: "${JSON_PRETTY:=false}"

# License token validation bypass (for development/testing only)
# Set AUDIT_SKIP_LICENSE_CHECK=1 to bypass in development environments
: "${AUDIT_SKIP_LICENSE_CHECK:=0}"

EXIT_CODE=0
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0

# =============================================================================
# License Token Validation
# =============================================================================
# Scripts require a valid license token to run. Token is machine-bound and
# time-limited, preventing unauthorized use of extracted scripts.
# =============================================================================
_validate_license() {
    # Skip validation if explicitly disabled (development only)
    if [[ "$AUDIT_SKIP_LICENSE_CHECK" == "1" ]] || [[ "$AUDIT_SKIP_LICENSE_CHECK" == "true" ]]; then
        return 0
    fi
    
    # Find and source token library
    local lib_dir
    lib_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    if [[ -f "${lib_dir}/token.sh" ]]; then
        # shellcheck source=./token.sh
        . "${lib_dir}/token.sh"
        require_license_token
    fi
    # If token.sh doesn't exist, allow execution (dev environment)
}

# Run license validation on source
_validate_license

setup_colors() {
  if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then
    RED=""; GREEN=""; YELLOW=""; BLUE=""; CYAN=""; BOLD=""; NC=""
  else
    RED='[0;31m'; GREEN='[0;32m'; YELLOW='[0;33m'
    BLUE='[0;34m'; CYAN='[0;36m'; BOLD='[1m'; NC='[0m'
  fi
}
# Check if running as root/sudo and warn if not (for audits with graceful degradation)
# Returns 0 if root, 1 if unprivileged (warning logged)
check_root_warn() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    warn "Not running as root/sudo (some checks may be limited)"
    _log "WARN" "Privilege check: unprivileged execution (EUID=${EUID:-$(id -u)})"
    return 1
  fi
  _log "DEBUG" "Privilege check: root/sudo execution (EUID=${EUID:-$(id -u)})"
  return 0
}

# Check if running as root/sudo and exit if not (for install/deployment scripts)
check_root_required() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    _log "ERROR" "This script requires root privileges"
    echo -e "${RED}[ERROR]${NC} This script must be run as root (use sudo)" >&2
    exit 1
  fi
  _log "INFO" "Privilege check: root/sudo confirmed (EUID=${EUID:-$(id -u)})"
}

# Check root status and register as a check result (PASS if root, WARN if not)
check_root_register() {
  local msg="${1:-Run as root for complete results}"
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    register_check "Root privileges" WARN "$msg"
    return 1
  else
    register_check "Root privileges" PASS "Running as root"
    return 0
  fi
}
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }

_log() {
  local level="$1"; shift
  local msg="$*"
  local line
  printf -v line '[%s] [%s] %s' "$(_timestamp)" "$level" "$msg"
  if [[ -n "$LOG_FILE" ]]; then echo "$line" >> "$LOG_FILE" 2>/dev/null || :; fi
  if [[ "$QUIET" != "true" ]]; then
    case "$level" in
      ERROR|WARN) echo "$line" >&2 ;;
      DEBUG) [[ "$VERBOSE" == "true" ]] && echo "$line" ;;
      TRACE) [[ "$VERY_VERBOSE" == "true" ]] && echo "$line" ;;
      *) echo "$line" ;;
    esac
  fi
}

# Convenience logging wrappers (used by audit scripts)
log_info()  { _log "INFO" "$@"; }
log_warn()  { _log "WARN" "$@"; }
log_error() { _log "ERROR" "$@"; }
log_debug() { _log "DEBUG" "$@"; }
log_trace() { _log "TRACE" "$@"; }

# Set up log file with fallback for non-root execution
# Usage: setup_log_file "script-name" -> sets LOG_FILE variable
# Falls back to /tmp if /var/log/security-audit is not writable, or disables logging
setup_log_file() {
  local script_name="${1:-audit}"
  local default_log="/var/log/security-audit/${script_name}.log"
  local fallback_log="/tmp/security-audit-${script_name}.log"

  if mkdir -p "$(dirname "$default_log")" 2>/dev/null && touch "$default_log" 2>/dev/null; then
    LOG_FILE="$default_log"
  elif touch "$fallback_log" 2>/dev/null; then
    LOG_FILE="$fallback_log"
  else
    LOG_FILE=""  # Disable file logging
  fi
}

register_check() {
  local name="$1" result="$2" message="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS+1))
  case "$result" in
    PASS) PASSED_CHECKS=$((PASSED_CHECKS+1)); echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}" ;;
    FAIL) FAILED_CHECKS=$((FAILED_CHECKS+1)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC} $name${message:+: $message}" ;;
    WARN) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
    SKIP) SKIPPED_CHECKS=$((SKIPPED_CHECKS+1)); echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}" ;;
    *) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
  esac
  if [[ -n "$LOG_FILE" ]]; then echo "[$(_timestamp)] [$result] $name${message:+: $message}" >> "$LOG_FILE" 2>/dev/null || :; fi
}

# JSON output helpers
_json_escape() {
  local s="$1"
  s="${s//\\/\\\\}"
  s="${s//\"/\\\"}"
  s="${s//$'\n'/\\n}"
  s="${s//$'\r'/\\r}"
  s="${s//$'\t'/\\t}"
  printf '%s' "$s"
}

_json_init() {
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    printf '{"audit_start":"%s","hostname":"%s","checks":[' \
      "$(date -Iseconds)" "$(hostname -f 2>/dev/null || hostname)" > "$JSON_OUTPUT"
    _JSON_FIRST_CHECK=true
  fi
}

_json_finalize() {
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    printf '],"audit_end":"%s","summary":{"total":%d,"passed":%d,"failed":%d,"warnings":%d,"skipped":%d,"exit_code":%d}}\n' \
      "$(date -Iseconds)" "$TOTAL_CHECKS" "$PASSED_CHECKS" "$FAILED_CHECKS" "$WARNING_CHECKS" "$SKIPPED_CHECKS" "$EXIT_CODE" >> "$JSON_OUTPUT"
  fi
}

# Register check with JSON output and optional severity
# Usage: register_check_json <name> <PASS|WARN|FAIL|SKIP> [message] [severity]
# Severity: CRITICAL, HIGH, MEDIUM, LOW (default: MEDIUM)
register_check_json() {
  local name="$1" result="$2" message="${3:-}" severity="${4:-MEDIUM}"

  # Call base register_check for console/log output
  register_check "$name" "$result" "$message"

  # Append to JSON output if enabled
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    local json_name json_msg json_sev
    json_name=$(_json_escape "$name")
    json_msg=$(_json_escape "$message")
    json_sev=$(_json_escape "$severity")

    # Add comma separator after first check
    if [[ "${_JSON_FIRST_CHECK:-true}" == "true" ]]; then
      _JSON_FIRST_CHECK=false
    else
      printf ',' >> "$JSON_OUTPUT"
    fi

    printf '{"check":"%s","result":"%s","message":"%s","severity":"%s","timestamp":"%s"}' \
      "$json_name" "$result" "$json_msg" "$json_sev" "$(date -Iseconds)" >> "$JSON_OUTPUT"
  fi
}

section() {
  local title="$1"
  echo
  printf "%s
" "${BOLD}${CYAN}============================================================${NC}"
  printf "%s
" "${BOLD}${CYAN} $title${NC}"
  printf "%s
" "${BOLD}${CYAN}============================================================${NC}"
  if [[ -n "$LOG_FILE" ]]; then { echo; echo "=== $title ==="; } >> "$LOG_FILE" 2>/dev/null || :; fi
}

print_summary() {
  echo
  printf "%s
" "${BOLD}+==========================================================+${NC}"
  printf "%s
" "${BOLD} AUDIT SUMMARY ${NC}"
  printf "%s
" "${BOLD}+==========================================================+${NC}"
  printf "%s
" " Hostname: $(hostname -f 2>/dev/null || hostname)"
  printf "%s
" " Date:     $(date '+%Y-%m-%d %H:%M:%S')"
  printf "%s
" "${BOLD}+----------------------+----------------------+----------------------+${NC}"
  printf " %s %-6d %s %-6d %s
"     "${GREEN}[+] PASSED:${NC}"   "$PASSED_CHECKS"     "${RED}[X] FAILED:${NC}"   "$FAILED_CHECKS"     ""
  printf " %s %-6d %s %-6d %s
"     "${YELLOW}[!] WARNINGS:${NC}" "$WARNING_CHECKS"     "${BLUE}[>] SKIPPED:${NC}"  "$SKIPPED_CHECKS"     ""
  printf "%s
" "${BOLD}+----------------------+----------------------+----------------------+${NC}"
  printf " TOTAL CHECKS: %-6d
" "$TOTAL_CHECKS"
  printf "%s
" "${BOLD}+==========================================================+${NC}"
}

setup_colors
# ─────────────────────────────────────────────────────────────────────────────
# Compliance Tagging Support
# ─────────────────────────────────────────────────────────────────────────────
# Enables mapping audit checks to compliance frameworks (CIS, NIST, PCI-DSS, etc.)
#
# Usage:
#   register_check_tagged "SSH PermitRootLogin" PASS "no" '"CIS:5.2.8","NIST:AC-6","PCI:2.2.4"'
#
: "${COMPLIANCE_OUTPUT:=}"

# Register check with compliance framework tags
# Usage: register_check_tagged <name> <PASS|WARN|FAIL|SKIP> [message] [tags]
# Tags should be comma-separated quoted strings: '"CIS:5.2.8","NIST:AC-6"'
register_check_tagged() {
  local name="$1" result="$2" message="${3:-}" tags="${4:-}"

  # Call base register_check for console/log output
  register_check "$name" "$result" "$message"

  # Append to compliance JSON output if enabled
  if [[ -n "${COMPLIANCE_OUTPUT:-}" ]]; then
    local json_name json_msg
    json_name=$(_json_escape "$name")
    json_msg=$(_json_escape "$message")

    # Add comma separator after first check
    if [[ "${_COMPLIANCE_FIRST_CHECK:-true}" == "true" ]]; then
      _COMPLIANCE_FIRST_CHECK=false
    else
      printf ',' >> "$COMPLIANCE_OUTPUT"
    fi

    printf '{"check":"%s","result":"%s","message":"%s","compliance":[%s],"timestamp":"%s"}' \
      "$json_name" "$result" "$json_msg" "$tags" "$(date -Iseconds)" >> "$COMPLIANCE_OUTPUT"
  fi

  # Also output to JSON if enabled
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    local json_name json_msg severity="MEDIUM"
    json_name=$(_json_escape "$name")
    json_msg=$(_json_escape "$message")

    # Determine severity from result
    case "$result" in
      FAIL) severity="HIGH" ;;
      WARN) severity="MEDIUM" ;;
      PASS|SKIP) severity="LOW" ;;
    esac

    if [[ "${_JSON_FIRST_CHECK:-true}" == "true" ]]; then
      _JSON_FIRST_CHECK=false
    else
      printf ',' >> "$JSON_OUTPUT"
    fi

    printf '{"check":"%s","result":"%s","message":"%s","severity":"%s","compliance":[%s],"timestamp":"%s"}' \
      "$json_name" "$result" "$json_msg" "$severity" "$tags" "$(date -Iseconds)" >> "$JSON_OUTPUT"
  fi
}

# Initialize compliance output
_compliance_init() {
  if [[ -n "${COMPLIANCE_OUTPUT:-}" ]]; then
    printf '{"audit_start":"%s","hostname":"%s","framework_checks":[' \
      "$(date -Iseconds)" "$(hostname -f 2>/dev/null || hostname)" > "$COMPLIANCE_OUTPUT"
    _COMPLIANCE_FIRST_CHECK=true
  fi
}

# ─────────────────────────────────────────────────────────────────────────────
# CEF/LEEF Output Format Support (SIEM Integration)
# ─────────────────────────────────────────────────────────────────────────────
# Common Event Format (CEF) and Log Event Extended Format (LEEF) for SIEM ingestion
#
# Usage:
#   CEF_OUTPUT="/var/log/audit-cef.log" ./my-audit.sh
#   LEEF_OUTPUT="/var/log/audit-leef.log" ./my-audit.sh
#
: "${CEF_OUTPUT:=}"
: "${LEEF_OUTPUT:=}"
: "${CEF_VENDOR:=SecurityAuditToolkit}"
: "${CEF_PRODUCT:=LinuxAudit}"
: "${CEF_VERSION:=2.0}"

# Convert result to CEF severity (0-10 scale)
_result_to_cef_severity() {
  local result="$1"
  case "$result" in
    PASS) echo "0" ;;
    SKIP) echo "1" ;;
    WARN) echo "5" ;;
    FAIL) echo "8" ;;
    *) echo "3" ;;
  esac
}

# Convert result to LEEF severity
_result_to_leef_severity() {
  local result="$1"
  case "$result" in
    PASS) echo "1" ;;
    SKIP) echo "2" ;;
    WARN) echo "5" ;;
    FAIL) echo "9" ;;
    *) echo "3" ;;
  esac
}

# Initialize CEF output file with header
_cef_init() {
  if [[ -n "${CEF_OUTPUT:-}" ]]; then
    echo "# CEF Audit Log - Started $(date -Iseconds)" > "$CEF_OUTPUT"
    echo "# Host: $(hostname -f 2>/dev/null || hostname)" >> "$CEF_OUTPUT"
  fi
  if [[ -n "${LEEF_OUTPUT:-}" ]]; then
    echo "# LEEF Audit Log - Started $(date -Iseconds)" > "$LEEF_OUTPUT"
    echo "# Host: $(hostname -f 2>/dev/null || hostname)" >> "$LEEF_OUTPUT"
  fi
}

# Finalize CEF/LEEF output
_cef_finalize() {
  if [[ -n "${CEF_OUTPUT:-}" ]]; then
    printf 'CEF:0|%s|%s|%s|AUDIT_COMPLETE|Audit Completed|0|total=%d passed=%d failed=%d warnings=%d skipped=%d exitCode=%d\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$TOTAL_CHECKS" "$PASSED_CHECKS" "$FAILED_CHECKS" "$WARNING_CHECKS" "$SKIPPED_CHECKS" "$EXIT_CODE" >> "$CEF_OUTPUT"
  fi
  if [[ -n "${LEEF_OUTPUT:-}" ]]; then
    printf 'LEEF:2.0|%s|%s|%s|AuditComplete|total=%d\tpassed=%d\tfailed=%d\twarnings=%d\tskipped=%d\texitCode=%d\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$TOTAL_CHECKS" "$PASSED_CHECKS" "$FAILED_CHECKS" "$WARNING_CHECKS" "$SKIPPED_CHECKS" "$EXIT_CODE" >> "$LEEF_OUTPUT"
  fi
}

# Register check with CEF/LEEF output
# Usage: register_check_cef <name> <PASS|WARN|FAIL|SKIP> [message] [check_id]
register_check_cef() {
  local name="$1" result="$2" message="${3:-}" check_id="${4:-CHECK}"

  # Call base register_check for console/log output
  register_check "$name" "$result" "$message"

  local severity hostname timestamp
  hostname=$(hostname -f 2>/dev/null || hostname)
  timestamp=$(date -Iseconds)

  # CEF output
  if [[ -n "${CEF_OUTPUT:-}" ]]; then
    severity=$(_result_to_cef_severity "$result")
    # CEF format: CEF:Version|Device Vendor|Device Product|Device Version|Signature ID|Name|Severity|Extension
    local cef_name cef_msg
    cef_name="${name//|/_}"
    cef_msg="${message//|/_}"
    printf 'CEF:0|%s|%s|%s|%s|%s|%s|result=%s msg=%s dhost=%s rt=%s\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$check_id" "$cef_name" "$severity" \
      "$result" "$cef_msg" "$hostname" "$timestamp" >> "$CEF_OUTPUT"
  fi

  # LEEF output (IBM QRadar compatible)
  if [[ -n "${LEEF_OUTPUT:-}" ]]; then
    severity=$(_result_to_leef_severity "$result")
    # LEEF format: LEEF:Version|Vendor|Product|Version|EventID|key=value pairs (tab-separated)
    local leef_msg
    leef_msg="${message//$'\t'/ }"
    printf 'LEEF:2.0|%s|%s|%s|%s|cat=SecurityAudit\tresult=%s\tmsg=%s\tdhost=%s\tdevTime=%s\tsev=%s\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$check_id" "$result" "$leef_msg" "$hostname" "$timestamp" "$severity" >> "$LEEF_OUTPUT"
  fi
}

# Combined function: register with all formats (console, JSON, CEF, LEEF, compliance)
# Usage: register_check_full <name> <PASS|WARN|FAIL|SKIP> [message] [severity] [check_id] [compliance_tags]
register_check_full() {
  local name="$1" result="$2" message="${3:-}" severity="${4:-MEDIUM}" check_id="${5:-CHECK}" tags="${6:-}"

  # Console and log output
  TOTAL_CHECKS=$((TOTAL_CHECKS+1))
  case "$result" in
    PASS) PASSED_CHECKS=$((PASSED_CHECKS+1)); echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}" ;;
    FAIL) FAILED_CHECKS=$((FAILED_CHECKS+1)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC} $name${message:+: $message}" ;;
    WARN) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
    SKIP) SKIPPED_CHECKS=$((SKIPPED_CHECKS+1)); echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}" ;;
    *) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
  esac
  if [[ -n "$LOG_FILE" ]]; then echo "[$(_timestamp)] [$result] $name${message:+: $message}" >> "$LOG_FILE" 2>/dev/null || :; fi

  # JSON output
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    local json_name json_msg
    json_name=$(_json_escape "$name")
    json_msg=$(_json_escape "$message")

    if [[ "${_JSON_FIRST_CHECK:-true}" == "true" ]]; then
      _JSON_FIRST_CHECK=false
    else
      printf ',' >> "$JSON_OUTPUT"
    fi

    if [[ -n "$tags" ]]; then
      printf '{"check":"%s","result":"%s","message":"%s","severity":"%s","checkId":"%s","compliance":[%s],"timestamp":"%s"}' \
        "$json_name" "$result" "$json_msg" "$severity" "$check_id" "$tags" "$(date -Iseconds)" >> "$JSON_OUTPUT"
    else
      printf '{"check":"%s","result":"%s","message":"%s","severity":"%s","checkId":"%s","timestamp":"%s"}' \
        "$json_name" "$result" "$json_msg" "$severity" "$check_id" "$(date -Iseconds)" >> "$JSON_OUTPUT"
    fi
  fi

  # CEF output
  if [[ -n "${CEF_OUTPUT:-}" ]]; then
    local cef_sev cef_name cef_msg
    cef_sev=$(_result_to_cef_severity "$result")
    cef_name="${name//|/_}"
    cef_msg="${message//|/_}"
    printf 'CEF:0|%s|%s|%s|%s|%s|%s|result=%s msg=%s dhost=%s rt=%s\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$check_id" "$cef_name" "$cef_sev" \
      "$result" "$cef_msg" "$(hostname)" "$(date -Iseconds)" >> "$CEF_OUTPUT"
  fi

  # LEEF output
  if [[ -n "${LEEF_OUTPUT:-}" ]]; then
    local leef_sev leef_msg
    leef_sev=$(_result_to_leef_severity "$result")
    leef_msg="${message//$'\t'/ }"
    printf 'LEEF:2.0|%s|%s|%s|%s|cat=SecurityAudit\tresult=%s\tmsg=%s\tdhost=%s\tdevTime=%s\tsev=%s\n' \
      "$CEF_VENDOR" "$CEF_PRODUCT" "$CEF_VERSION" \
      "$check_id" "$result" "$leef_msg" "$(hostname)" "$(date -Iseconds)" "$leef_sev" >> "$LEEF_OUTPUT"
  fi
}
