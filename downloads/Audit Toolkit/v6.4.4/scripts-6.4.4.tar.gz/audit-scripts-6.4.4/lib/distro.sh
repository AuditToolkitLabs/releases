#!/usr/bin/env bash
# Distro detection and feature probes
set -euo pipefail

# Cache for distro detection (avoids repeated reads of /etc/os-release)
_DISTRO_CACHE=""

detect_distro() {
  # Return cached value if available
  if [[ -n "$_DISTRO_CACHE" ]]; then
    echo "$_DISTRO_CACHE"
    return 0
  fi

  if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    _DISTRO_CACHE="${ID,,}"
    echo "$_DISTRO_CACHE"
  else
    _DISTRO_CACHE="unknown"
    echo "unknown"
  fi
}

is_systemd() { command -v systemctl >/dev/null 2>&1 && pidof systemd >/dev/null 2>&1; }
is_openrc()  { command -v rc-status >/dev/null 2>&1; }

# runit init system (Void Linux, Artix with runit)
is_runit() {
  command -v sv >/dev/null 2>&1 && {
    [[ -d /run/runit/supervise ]] || [[ -d /var/service ]] || [[ -d /service ]]
  }
}

# s6 init system (Artix with s6, Obarun)
is_s6() {
  command -v s6-svc >/dev/null 2>&1 && {
    [[ -d /run/s6/services ]] || [[ -d /var/run/s6/services ]]
  }
}

# dinit init system (Artix with dinit, Chimera Linux)
is_dinit() {
  command -v dinitctl >/dev/null 2>&1
}

# sysvinit (Devuan, Slackware, older systems)
is_sysvinit() {
  # sysvinit if /sbin/init is not a symlink to systemd and no other init detected
  [[ -x /sbin/init ]] && ! is_systemd && ! is_openrc && ! is_runit && ! is_s6 && ! is_dinit && {
    command -v update-rc.d >/dev/null 2>&1 || command -v chkconfig >/dev/null 2>&1 || [[ -d /etc/rc.d ]]
  }
}

# Returns the detected init system name
detect_init_system() {
  if is_systemd; then echo "systemd"
  elif is_openrc; then echo "openrc"
  elif is_runit; then echo "runit"
  elif is_s6; then echo "s6"
  elif is_dinit; then echo "dinit"
  elif is_sysvinit; then echo "sysvinit"
  else echo "unknown"
  fi
}

has_selinux()  { command -v getenforce >/dev/null 2>&1; }
has_apparmor() { [[ -d /sys/kernel/security/apparmor ]] || command -v aa-status >/dev/null 2>&1; }
