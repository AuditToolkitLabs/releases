#!/usr/bin/env bash
# Firewall detection - works without root (graceful degradation)
set -euo pipefail

# Helper: run command with sudo -n if available and needed
_fw_try_privileged() {
  local cmd="$1"
  shift
  # Try without sudo first (might work if user has permissions)
  if output=$("$cmd" "$@" 2>&1); then
    echo "$output"
    return 0
  fi
  # If failed due to permissions, try sudo -n (non-interactive)
  if [[ "$output" == *"root"* ]] || [[ "$output" == *"permission"* ]] || [[ "$output" == *"Permission"* ]]; then
    if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
      sudo -n "$cmd" "$@" 2>&1
      return $?
    fi
    # No sudo access - return permission error indicator
    echo "PERMISSION_DENIED"
    return 1
  fi
  # Other error
  echo "$output"
  return 1
}

fw_state() {
  if command -v ufw >/dev/null 2>&1; then
    local result
    result=$(_fw_try_privileged ufw status 2>&1 | head -n1)
    if [[ "$result" == "PERMISSION_DENIED" ]]; then
      echo "ufw installed (status requires root)"
    else
      echo "$result"
    fi
  elif command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --state 2>/dev/null || echo "firewalld not running"
  elif command -v nft >/dev/null 2>&1; then
    echo "nftables present"
  else
    echo "no firewall tooling found"
  fi
}

fw_is_active() {
  local result
  if command -v ufw >/dev/null 2>&1; then
    result=$(_fw_try_privileged ufw status 2>&1)
    if [[ "$result" == "PERMISSION_DENIED" ]]; then
      # Can't determine - return special code
      return 2
    fi
    echo "$result" | grep -q "Status: active" 2>/dev/null || return 1
  elif command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --state 2>/dev/null | grep -q "running" || return 1
  elif command -v nft >/dev/null 2>&1; then
    result=$(_fw_try_privileged nft list tables 2>&1)
    [[ "$result" != "PERMISSION_DENIED" ]] || return 2
  else
    return 1
  fi
}

# Returns: 0=has rules, 1=no rules, 2=permission denied
fw_list_rules() {
  local result
  if command -v ufw >/dev/null 2>&1; then
    result=$(_fw_try_privileged ufw status numbered 2>&1)
    if [[ "$result" == "PERMISSION_DENIED" ]]; then
      echo "PERMISSION_DENIED"
      return 2
    fi
    echo "$result"
  elif command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --list-all 2>/dev/null || true
  elif command -v iptables >/dev/null 2>&1; then
    result=$(_fw_try_privileged iptables -L -n 2>&1)
    if [[ "$result" == "PERMISSION_DENIED" ]]; then
      echo "PERMISSION_DENIED"
      return 2
    fi
    echo "$result"
  elif command -v nft >/dev/null 2>&1; then
    result=$(_fw_try_privileged nft list ruleset 2>&1)
    if [[ "$result" == "PERMISSION_DENIED" ]]; then
      echo "PERMISSION_DENIED"
      return 2
    fi
    echo "$result"
  else
    echo "No firewall rules found"
  fi
}
