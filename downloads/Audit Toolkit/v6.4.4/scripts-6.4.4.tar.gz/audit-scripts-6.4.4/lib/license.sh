#!/usr/bin/env bash
# =============================================================================
# License Enforcement Library
# =============================================================================
# Enforces BSL license limits:
# - Free tier: Up to 25 unique machines
# - Professional: Up to 100 machines ($499/year)
# - Enterprise: Unlimited machines ($1,999/year)
# =============================================================================

set -euo pipefail

# License configuration
readonly LICENSE_DIR="${LICENSE_DIR:-${HOME}/.audit-tool}"
readonly LICENSE_FILE="${LICENSE_DIR}/license.json"
readonly LICENSE_TOKEN_FILE="${LICENSE_DIR}/license.token"
readonly MACHINES_FILE="${LICENSE_DIR}/machines.db"
readonly FREE_TIER_LIMIT=25
readonly STARTER_LIMIT=50
readonly PROFESSIONAL_LIMIT=150
readonly BUSINESS_LIMIT=500

# License tiers
readonly TIER_FREE="free"
readonly TIER_TRIAL="trial"
readonly TIER_STARTER="starter"
readonly TIER_PROFESSIONAL="professional"
readonly TIER_BUSINESS="business"
readonly TIER_ENTERPRISE="enterprise"

# Token validity periods (days) - per tier
readonly TOKEN_VALIDITY_FREE=7
readonly TOKEN_VALIDITY_TRIAL=14       # Trial period itself
readonly TOKEN_VALIDITY_STARTER=30
readonly TOKEN_VALIDITY_PROFESSIONAL=60
readonly TOKEN_VALIDITY_BUSINESS=90
readonly TOKEN_VALIDITY_ENTERPRISE=90

# Grace period (days) - scripts run with warnings after token expires
readonly TOKEN_GRACE_PERIOD=7

# =============================================================================
# INITIALIZATION
# =============================================================================

license_init() {
    # Create license directory if needed
    if [[ ! -d "${LICENSE_DIR}" ]]; then
        mkdir -p "${LICENSE_DIR}"
        chmod 700 "${LICENSE_DIR}"
    fi
    
    # Initialize machines file if needed
    if [[ ! -f "${MACHINES_FILE}" ]]; then
        echo "# Audit Tool - Machine Registry" > "${MACHINES_FILE}"
        echo "# Format: machine_id|hostname|first_seen|last_seen" >> "${MACHINES_FILE}"
        chmod 600 "${MACHINES_FILE}"
    fi
}

# =============================================================================
# LICENSE TOKEN VALIDATION (Offline Protection)
# =============================================================================
# Tokens are issued by the server during sync and have tier-based validity.
# This prevents extracted scripts from running indefinitely without a license.
# =============================================================================

# Global state for grace period warnings
_LICENSE_IN_GRACE_PERIOD=false
_LICENSE_GRACE_DAYS_REMAINING=0

get_token_validity_days() {
    local tier="${1:-free}"
    
    case "${tier}" in
        "${TIER_ENTERPRISE}")
            echo "${TOKEN_VALIDITY_ENTERPRISE}"
            ;;
        "${TIER_BUSINESS}")
            echo "${TOKEN_VALIDITY_BUSINESS}"
            ;;
        "${TIER_PROFESSIONAL}")
            echo "${TOKEN_VALIDITY_PROFESSIONAL}"
            ;;
        "${TIER_STARTER}")
            echo "${TOKEN_VALIDITY_STARTER}"
            ;;
        "${TIER_TRIAL}")
            echo "${TOKEN_VALIDITY_TRIAL}"
            ;;
        *)
            echo "${TOKEN_VALIDITY_FREE}"
            ;;
    esac
}

validate_license_token() {
    # Returns: 0=valid, 1=grace period (warnings), 2=invalid/expired
    
    if [[ ! -f "${LICENSE_TOKEN_FILE}" ]]; then
        echo "[LICENSE] No license token found. Please sync with server."
        return 2
    fi
    
    # Read token file (JSON format)
    local token_data
    token_data=$(cat "${LICENSE_TOKEN_FILE}" 2>/dev/null)
    
    if [[ -z "${token_data}" ]]; then
        echo "[LICENSE] License token file is empty or corrupted."
        return 2
    fi
    
    # Parse token fields
    local token_tier token_expires token_machine_id token_signature token_issued
    token_tier=$(echo "${token_data}" | grep -o '"tier"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    token_expires=$(echo "${token_data}" | grep -o '"expires"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    token_machine_id=$(echo "${token_data}" | grep -o '"machine_id"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    token_signature=$(echo "${token_data}" | grep -o '"signature"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    token_issued=$(echo "${token_data}" | grep -o '"issued"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    
    # Verify machine binding (token is tied to specific machine fingerprint)
    local current_machine_id
    current_machine_id=$(get_machine_id)
    
    if [[ -n "${token_machine_id}" && "${token_machine_id}" != "${current_machine_id}" ]]; then
        echo "[LICENSE] Token was issued for a different machine."
        echo "[LICENSE] This prevents copying scripts between systems."
        return 2
    fi
    
    # Verify signature using HMAC-SHA256 (matches server-side signing)
    if [[ -n "${token_signature}" ]]; then
        # Construct payload exactly as server does: machine_id|tier|issued|expires
        local sig_payload="${token_machine_id}|${token_tier}|${token_issued}|${token_expires}"
        
        # Combined key: local part + configurable secret (default for non-production)
        local local_key_part="audit-toolkit-v5-local"
        local server_key="${AUDIT_TOKEN_SIGNING_KEY:-audit-toolkit-default-signing-key-change-me}"
        local combined_key="${local_key_part}:${server_key}"
        
        # Calculate HMAC-SHA256 signature
        local expected_sig
        if command -v openssl &>/dev/null; then
            expected_sig=$(echo -n "${sig_payload}" | openssl dgst -sha256 -hmac "${combined_key}" | awk '{print $2}')
        else
            # Fallback: simple hash (less secure but works without openssl)
            expected_sig=$(echo -n "${combined_key}:${sig_payload}" | sha256sum | cut -d' ' -f1)
        fi
        
        if [[ "${token_signature}" != "${expected_sig}" ]]; then
            echo "[LICENSE] Token signature is invalid. Token may have been tampered with."
            return 2
        fi
    fi
    
    # Check expiration
    if [[ -z "${token_expires}" ]]; then
        echo "[LICENSE] Token has no expiration date."
        return 2
    fi
    
    local expires_epoch now_epoch
    expires_epoch=$(date -d "${token_expires}" +%s 2>/dev/null || date -j -f "%Y-%m-%dT%H:%M:%S" "${token_expires}" +%s 2>/dev/null || echo "0")
    now_epoch=$(date +%s)
    
    if [[ ${expires_epoch} -eq 0 ]]; then
        echo "[LICENSE] Cannot parse token expiration date."
        return 2
    fi
    
    local days_until_expiry=$(( (expires_epoch - now_epoch) / 86400 ))
    
    if [[ ${days_until_expiry} -ge 0 ]]; then
        # Token is valid
        if [[ ${days_until_expiry} -le 7 ]]; then
            echo "[LICENSE] Token expires in ${days_until_expiry} days. Please sync with server to renew."
        fi
        return 0
    fi
    
    # Token has expired - check grace period
    local days_expired=$(( -days_until_expiry ))
    
    if [[ ${days_expired} -le ${TOKEN_GRACE_PERIOD} ]]; then
        # Within grace period - allow with warnings
        local grace_remaining=$(( TOKEN_GRACE_PERIOD - days_expired ))
        _LICENSE_IN_GRACE_PERIOD=true
        _LICENSE_GRACE_DAYS_REMAINING=${grace_remaining}
        
        echo ""
        echo "========================================================"
        echo " LICENSE TOKEN EXPIRED - GRACE PERIOD ACTIVE"
        echo "========================================================"
        echo ""
        echo " Your license token expired ${days_expired} day(s) ago."
        echo " Grace period: ${grace_remaining} day(s) remaining."
        echo ""
        echo " Scripts will STOP WORKING after the grace period."
        echo " Please sync with the server to renew your token."
        echo ""
        echo "========================================================"
        echo ""
        return 1  # Grace period - continue with warnings
    fi
    
    # Past grace period - deny execution
    echo ""
    echo "========================================================"
    echo " LICENSE TOKEN EXPIRED"
    echo "========================================================"
    echo ""
    echo " Your license token expired ${days_expired} days ago."
    echo " The ${TOKEN_GRACE_PERIOD}-day grace period has ended."
    echo ""
    echo " To continue using these scripts:"
    echo "   1. Connect to the central server"
    echo "   2. Run: audit-agent sync"
    echo ""
    echo " Or upgrade your license at:"
    echo "   https://audit-tool.example.com/pricing"
    echo ""
    echo "========================================================"
    return 2
}

print_grace_period_warning() {
    # Call at start of audit output if in grace period
    if [[ "${_LICENSE_IN_GRACE_PERIOD}" == "true" ]]; then
        echo ""
        echo "╔══════════════════════════════════════════════════════════════╗"
        echo "║  ⚠ WARNING: License token expired - ${_LICENSE_GRACE_DAYS_REMAINING} days grace remaining  ║"
        echo "╚══════════════════════════════════════════════════════════════╝"
        echo ""
    fi
}

# =============================================================================
# MACHINE IDENTIFICATION
# =============================================================================

get_machine_id() {
    local machine_id=""
    
    # Try multiple methods to get unique machine ID
    if [[ -f /etc/machine-id ]]; then
        machine_id=$(cat /etc/machine-id 2>/dev/null || true)
    elif [[ -f /var/lib/dbus/machine-id ]]; then
        machine_id=$(cat /var/lib/dbus/machine-id 2>/dev/null || true)
    elif command -v hostid &>/dev/null; then
        machine_id=$(hostid 2>/dev/null || true)
    fi
    
    # Fallback: hash of hostname + network interfaces
    if [[ -z "${machine_id}" ]]; then
        local hostname_part
        hostname_part=$(hostname 2>/dev/null || echo "unknown")
        local mac_part=""
        if command -v ip &>/dev/null; then
            mac_part=$(ip link 2>/dev/null | grep -o 'link/ether [^ ]*' | head -1 | awk '{print $2}' || true)
        elif command -v ifconfig &>/dev/null; then
            mac_part=$(ifconfig 2>/dev/null | grep -o 'ether [^ ]*' | head -1 | awk '{print $2}' || true)
        fi
        machine_id=$(echo "${hostname_part}:${mac_part}" | sha256sum | cut -d' ' -f1)
    fi
    
    echo "${machine_id}"
}

get_machine_hostname() {
    hostname 2>/dev/null || echo "unknown"
}

# =============================================================================
# LICENSE MANAGEMENT
# =============================================================================

get_license_tier() {
    if [[ ! -f "${LICENSE_FILE}" ]]; then
        echo "${TIER_FREE}"
        return
    fi
    
    local tier
    tier=$(grep -o '"tier"[[:space:]]*:[[:space:]]*"[^"]*"' "${LICENSE_FILE}" 2>/dev/null | \
           sed 's/.*"\([^"]*\)"$/\1/' || echo "${TIER_FREE}")
    
    # Validate license hasn't expired
    local expires
    expires=$(grep -o '"expires"[[:space:]]*:[[:space:]]*"[^"]*"' "${LICENSE_FILE}" 2>/dev/null | \
              sed 's/.*"\([^"]*\)"$/\1/' || echo "")
    
    if [[ -n "${expires}" ]]; then
        local expires_epoch
        local now_epoch
        expires_epoch=$(date -d "${expires}" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "${expires}" +%s 2>/dev/null || echo "0")
        now_epoch=$(date +%s)
        
        if [[ ${now_epoch} -gt ${expires_epoch} ]]; then
            echo "${TIER_FREE}"  # Expired license falls back to free
            return
        fi
    fi
    
    echo "${tier}"
}

get_license_limit() {
    local tier
    tier=$(get_license_tier)
    
    case "${tier}" in
        "${TIER_ENTERPRISE}")
            echo "unlimited"
            ;;
        "${TIER_BUSINESS}")
            echo "${BUSINESS_LIMIT}"
            ;;
        "${TIER_PROFESSIONAL}"|"${TIER_TRIAL}")
            echo "${PROFESSIONAL_LIMIT}"
            ;;
        "${TIER_STARTER}")
            echo "${STARTER_LIMIT}"
            ;;
        *)
            echo "${FREE_TIER_LIMIT}"
            ;;
    esac
}

get_license_info() {
    license_init
    
    local tier
    local limit
    local machine_count
    
    tier=$(get_license_tier)
    limit=$(get_license_limit)
    machine_count=$(get_registered_machine_count)
    
    echo "License Tier: ${tier}"
    echo "Machine Limit: ${limit}"
    echo "Machines Used: ${machine_count}"
    
    if [[ "${limit}" != "unlimited" ]]; then
        local remaining=$((limit - machine_count))
        if [[ ${remaining} -lt 0 ]]; then
            remaining=0
        fi
        echo "Remaining: ${remaining}"
    fi
}

# =============================================================================
# MACHINE REGISTRATION
# =============================================================================

get_registered_machine_count() {
    if [[ ! -f "${MACHINES_FILE}" ]]; then
        echo "0"
        return
    fi
    
    grep -v '^#' "${MACHINES_FILE}" 2>/dev/null | grep -c '|' || echo "0"
}

is_machine_registered() {
    local machine_id="$1"
    
    if [[ ! -f "${MACHINES_FILE}" ]]; then
        return 1
    fi
    
    grep -q "^${machine_id}|" "${MACHINES_FILE}" 2>/dev/null
}

register_machine() {
    local machine_id="$1"
    local hostname="$2"
    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    
    if is_machine_registered "${machine_id}"; then
        # Update last_seen
        local temp_file="${MACHINES_FILE}.tmp"
        while IFS='|' read -r id host first_seen _; do
            if [[ "${id}" == "${machine_id}" ]]; then
                echo "${id}|${host}|${first_seen}|${timestamp}"
            else
                echo "${id}|${host}|${first_seen}|${_}"
            fi
        done < <(grep -v '^#' "${MACHINES_FILE}") > "${temp_file}"
        
        # Preserve header
        head -2 "${MACHINES_FILE}" > "${MACHINES_FILE}.new"
        cat "${temp_file}" >> "${MACHINES_FILE}.new"
        mv "${MACHINES_FILE}.new" "${MACHINES_FILE}"
        rm -f "${temp_file}"
        return 0
    fi
    
    # Add new machine
    echo "${machine_id}|${hostname}|${timestamp}|${timestamp}" >> "${MACHINES_FILE}"
}

list_registered_machines() {
    if [[ ! -f "${MACHINES_FILE}" ]]; then
        echo "No machines registered"
        return
    fi
    
    echo "Registered Machines:"
    echo "===================="
    printf "%-20s %-24s %-24s\n" "Hostname" "First Seen" "Last Seen"
    echo "------------------------------------------------------------"
    
    while IFS='|' read -r _ hostname first_seen last_seen; do
        printf "%-20s %-24s %-24s\n" "${hostname:0:20}" "${first_seen}" "${last_seen}"
    done < <(grep -v '^#' "${MACHINES_FILE}" 2>/dev/null)
}

# =============================================================================
# LICENSE ENFORCEMENT
# =============================================================================

check_license() {
    license_init
    
    # STEP 1: Validate license token (offline protection)
    # This ensures scripts can't run indefinitely if extracted
    local token_status
    validate_license_token
    token_status=$?
    
    if [[ ${token_status} -eq 2 ]]; then
        # Token invalid or expired past grace period - deny execution
        return 1
    fi
    
    # token_status 0 = valid, 1 = grace period (warnings already shown)
    
    # STEP 2: Check machine registration limits
    local machine_id
    local hostname
    local tier
    local limit
    local current_count
    
    machine_id=$(get_machine_id)
    hostname=$(get_machine_hostname)
    tier=$(get_license_tier)
    limit=$(get_license_limit)
    current_count=$(get_registered_machine_count)
    
    # If machine is already registered, allow it
    if is_machine_registered "${machine_id}"; then
        register_machine "${machine_id}" "${hostname}"  # Update last_seen
        return 0
    fi
    
    # Check if we can add a new machine
    if [[ "${limit}" == "unlimited" ]]; then
        register_machine "${machine_id}" "${hostname}"
        return 0
    fi
    
    if [[ ${current_count} -ge ${limit} ]]; then
        echo ""
        echo "=========================================="
        echo " LICENSE LIMIT REACHED"
        echo "=========================================="
        echo ""
        echo " Your ${tier} license allows ${limit} machines."
        echo " You have already registered ${current_count} machines."
        echo ""
        echo " To scan additional machines, please upgrade:"
        echo ""
        echo "   Starter (\$299/year): Up to 50 machines"
        echo "   Professional (\$799/year): Up to 150 machines"
        echo "   Business (\$1,999/year): Up to 500 machines"
        echo "   Enterprise (\$4,999/year): Unlimited machines"
        echo ""
        echo " Website: https://audit-tool.example.com/pricing"
        echo ""
        echo "=========================================="
        return 1
    fi
    
    # Register new machine
    register_machine "${machine_id}" "${hostname}"
    
    # Warn if approaching limit
    local remaining=$((limit - current_count - 1))
    if [[ ${remaining} -le 5 ]]; then
        echo ""
        echo "[WARNING] License: ${remaining} machine slots remaining (${tier} tier: ${limit} max)"
        echo ""
    fi
    
    return 0
}

# =============================================================================
# LICENSE ACTIVATION
# =============================================================================

activate_license() {
    local license_key="$1"
    
    license_init
    
    # Validate license key format (XXXX-XXXX-XXXX-XXXX)
    if [[ ! "${license_key}" =~ ^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$ ]]; then
        echo "Invalid license key format"
        echo "Expected format: XXXX-XXXX-XXXX-XXXX"
        return 1
    fi
    
    # For offline validation, decode the license key
    # In production, this would validate against a license server
    local tier="${TIER_FREE}"
    local expires=""
    local valid=false
    local enable_demo_keys="${ENABLE_DEMO_KEYS:-false}"

    enable_demo_keys="${enable_demo_keys,,}"
    
    # Demo keys are disabled by default and intended only for isolated test environments
    if [[ "${enable_demo_keys}" == "1" || "${enable_demo_keys}" == "true" || "${enable_demo_keys}" == "yes" || "${enable_demo_keys}" == "on" ]]; then
        case "${license_key}" in
            "STRT-TEST-2026-DEMO")
                tier="${TIER_STARTER}"
                expires="2027-12-31"
                valid=true
                ;;
            "PROF-TEST-2026-DEMO")
                tier="${TIER_PROFESSIONAL}"
                expires="2027-12-31"
                valid=true
                ;;
            "BUSN-TEST-2026-DEMO")
                tier="${TIER_BUSINESS}"
                expires="2027-12-31"
                valid=true
                ;;
            "ENTR-TEST-2026-DEMO")
                tier="${TIER_ENTERPRISE}"
                expires="2027-12-31"
                valid=true
                ;;
        esac
    fi

    if [[ "${valid}" != true ]]; then
        # In production: validate against license server
        # For now, attempt offline validation based on key structure
        echo "License validation requires online verification."
        echo "Please ensure internet connectivity and try again."
        return 1
    fi
    
    if [[ "${valid}" == true ]]; then
        # Write license file
        cat > "${LICENSE_FILE}" << EOF
{
    "key": "${license_key}",
    "tier": "${tier}",
    "issued": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "expires": "${expires}",
    "features": ["unlimited_audits", "priority_support", "advanced_reports"]
}
EOF
        chmod 600 "${LICENSE_FILE}"
        
        echo ""
        echo "License activated successfully!"
        echo ""
        get_license_info
        return 0
    fi
    
    return 1
}

deactivate_license() {
    if [[ -f "${LICENSE_FILE}" ]]; then
        rm -f "${LICENSE_FILE}"
        echo "License deactivated. Reverted to free tier."
    else
        echo "No active license found."
    fi
}

# =============================================================================
# CLI INTERFACE
# =============================================================================

license_cli() {
    local command="${1:-status}"
    shift || true
    
    case "${command}" in
        status|info)
            get_license_info
            ;;
        check)
            if check_license; then
                echo "License check passed"
            else
                exit 1
            fi
            ;;
        activate)
            if [[ $# -lt 1 ]]; then
                echo "Usage: license activate <license-key>"
                exit 1
            fi
            activate_license "$1"
            ;;
        deactivate)
            deactivate_license
            ;;
        machines)
            list_registered_machines
            ;;
        reset-machines)
            if [[ -f "${MACHINES_FILE}" ]]; then
                echo "# Audit Tool - Machine Registry" > "${MACHINES_FILE}"
                echo "# Format: machine_id|hostname|first_seen|last_seen" >> "${MACHINES_FILE}"
                echo "Machine registry reset."
            fi
            ;;
        *)
            echo "Audit Tool License Manager"
            echo ""
            echo "Usage: license <command>"
            echo ""
            echo "Commands:"
            echo "  status          Show license status"
            echo "  check           Verify license allows scanning this machine"
            echo "  activate <key>  Activate a license key"
            echo "  deactivate      Remove current license"
            echo "  machines        List registered machines"
            echo ""
            echo "License Tiers:"
            echo "  Free:          25 machines (BSL license)"
            echo "  Professional:  100 machines (\$499/year)"
            echo "  Enterprise:    Unlimited (\$1,999/year)"
            ;;
    esac
}

# Run CLI if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    license_cli "$@"
fi
