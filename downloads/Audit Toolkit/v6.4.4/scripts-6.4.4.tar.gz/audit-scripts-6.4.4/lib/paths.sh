#!/usr/bin/env bash
# Path helpers by distro — distro-specific config locations
set -euo pipefail

# shellcheck source=./distro.sh
. "$(dirname "${BASH_SOURCE[0]}")/distro.sh"

# ============================================================================
# LOGROTATE PATHS
# ============================================================================

path_logrotate_conf() { echo "/etc/logrotate.conf"; }
path_logrotate_d()    { echo "/etc/logrotate.d"; }

# ============================================================================
# PACKAGE MANAGER PATHS
# ============================================================================

path_pkg_conf_dir() {
  case "$(detect_distro)" in
    ubuntu|debian|linuxmint|pop|kali|elementary|zorin)  echo "/etc/apt/apt.conf.d" ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn) echo "/etc/dnf" ;;
    sles|suse|opensuse*) echo "/etc/zypp" ;;
    arch|manjaro|endeavouros|garuda|artix)   echo "/etc/pacman.d" ;;
    alpine)         echo "/etc/apk" ;;
    gentoo|funtoo)  echo "/etc/portage" ;;
    void)           echo "/etc/xbps.d" ;;
    nixos)          echo "/etc/nixos" ;;
    *) echo "/etc" ;;
  esac
}

# ============================================================================
# SSH PATHS
# ============================================================================

path_sshd_config() {
  echo "/etc/ssh/sshd_config"
}

path_sshd_config_d() {
  if [[ -d /etc/ssh/sshd_config.d ]]; then
    echo "/etc/ssh/sshd_config.d"
  else
    echo ""
  fi
}

# ============================================================================
# FIREWALL PATHS
# ============================================================================

path_iptables_rules() {
  case "$(detect_distro)" in
    debian|ubuntu|linuxmint|pop|kali|elementary|zorin)
      echo "/etc/iptables/rules.v4"
      ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn)
      echo "/etc/sysconfig/iptables"
      ;;
    arch|manjaro|endeavouros|garuda|artix)
      echo "/etc/iptables/iptables.rules"
      ;;
    alpine)
      echo "/etc/iptables/rules-save"
      ;;
    *)
      echo "/etc/iptables.rules"
      ;;
  esac
}

path_nftables_config() {
  echo "/etc/nftables.conf"
}

# ============================================================================
# WEB SERVER PATHS
# ============================================================================

path_nginx_conf() {
  echo "/etc/nginx/nginx.conf"
}

path_nginx_sites() {
  case "$(detect_distro)" in
    debian|ubuntu|linuxmint|pop|kali|elementary|zorin)
      echo "/etc/nginx/sites-enabled"
      ;;
    *)
      echo "/etc/nginx/conf.d"
      ;;
  esac
}

path_apache_conf() {
  case "$(detect_distro)" in
    debian|ubuntu|linuxmint|pop|kali|elementary|zorin)
      echo "/etc/apache2/apache2.conf"
      ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn|arch|manjaro)
      echo "/etc/httpd/conf/httpd.conf"
      ;;
    alpine)
      echo "/etc/apache2/httpd.conf"
      ;;
    *)
      echo "/etc/apache2/apache2.conf"
      ;;
  esac
}

# ============================================================================
# DATABASE PATHS
# ============================================================================

path_mysql_conf() {
  case "$(detect_distro)" in
    debian|ubuntu|linuxmint|pop|kali|elementary|zorin)
      echo "/etc/mysql/mysql.conf.d/mysqld.cnf"
      ;;
    *)
      echo "/etc/my.cnf"
      ;;
  esac
}

path_postgresql_data() {
  # Common data directory locations
  local locations=(
    "/var/lib/postgresql"
    "/var/lib/pgsql"
    "/var/lib/postgres"
  )
  for loc in "${locations[@]}"; do
    if [[ -d "$loc" ]]; then
      echo "$loc"
      return
    fi
  done
  echo "/var/lib/postgresql"
}

# ============================================================================
# LOGGING PATHS
# ============================================================================

path_syslog_conf() {
  if [[ -f /etc/rsyslog.conf ]]; then
    echo "/etc/rsyslog.conf"
  elif [[ -f /etc/syslog-ng/syslog-ng.conf ]]; then
    echo "/etc/syslog-ng/syslog-ng.conf"
  else
    echo "/etc/syslog.conf"
  fi
}

path_journald_conf() {
  echo "/etc/systemd/journald.conf"
}

path_audit_conf() {
  echo "/etc/audit/auditd.conf"
}

path_audit_rules() {
  if [[ -d /etc/audit/rules.d ]]; then
    echo "/etc/audit/rules.d"
  else
    echo "/etc/audit/audit.rules"
  fi
}

# ============================================================================
# VPN PATHS
# ============================================================================

path_openvpn() {
  if [[ -d /etc/openvpn/server ]]; then
    echo "/etc/openvpn/server"
  else
    echo "/etc/openvpn"
  fi
}

path_wireguard() {
  echo "/etc/wireguard"
}

path_strongswan() {
  if [[ -f /etc/strongswan.conf ]]; then
    echo "/etc/strongswan.conf"
  else
    echo "/etc/ipsec.conf"
  fi
}

# ============================================================================
# CONTAINER PATHS
# ============================================================================

path_docker_config() {
  echo "/etc/docker/daemon.json"
}

path_containerd_config() {
  echo "/etc/containerd/config.toml"
}

path_podman_config() {
  echo "/etc/containers/containers.conf"
}

# ============================================================================
# NETWORK PATHS
# ============================================================================

path_network_config() {
  case "$(detect_distro)" in
    debian|ubuntu|linuxmint|pop|kali|elementary|zorin)
      if [[ -d /etc/netplan ]]; then
        echo "/etc/netplan"
      else
        echo "/etc/network/interfaces"
      fi
      ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn)
      echo "/etc/sysconfig/network-scripts"
      ;;
    *)
      echo "/etc/network"
      ;;
  esac
}

path_resolv_conf() {
  echo "/etc/resolv.conf"
}

# ============================================================================
# TIME/NTP PATHS
# ============================================================================

path_chrony_conf() {
  case "$(detect_distro)" in
    alpine)
      echo "/etc/chrony/chrony.conf"
      ;;
    *)
      echo "/etc/chrony.conf"
      ;;
  esac
}

path_timesyncd_conf() {
  echo "/etc/systemd/timesyncd.conf"
}
