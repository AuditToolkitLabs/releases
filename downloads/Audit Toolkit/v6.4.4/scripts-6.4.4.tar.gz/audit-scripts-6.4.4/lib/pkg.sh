#!/usr/bin/env bash
# Package manager shims
set -euo pipefail

# shellcheck source=./distro.sh
. "$(dirname "${BASH_SOURCE[0]}")/distro.sh"

pkg_refresh() {
  case "$(detect_distro)" in
    ubuntu|debian|linuxmint|pop|kali|elementary|zorin)
      apt -qq update ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn|nobara|scientific)
      dnf -q makecache || yum makecache -q || true ;;
    sles|suse|opensuse*)
      zypper -q refresh || true ;;
    arch|manjaro|endeavouros|garuda|artix)
      pacman -Sy --noconfirm || true ;;
    alpine)
      apk update || true ;;
    gentoo|funtoo)
      emerge --sync -q 2>/dev/null || true ;;
    void)
      xbps-install -S || true ;;
    nixos)
      # NixOS uses declarative package management; refresh channel
      nix-channel --update 2>/dev/null || true ;;
    clear-linux-os|clearlinux)
      swupd check-update 2>/dev/null || true ;;
    photon)
      tdnf makecache -q || true ;;
    slackware)
      slackpkg update 2>/dev/null || true ;;
    *) return 0 ;;
  esac
}

pkg_installed() { # pkg_installed <name>
  local p="$1"
  case "$(detect_distro)" in
    ubuntu|debian|linuxmint|pop|kali|elementary|zorin)
      dpkg -s "$p" >/dev/null 2>&1 ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn|sles|suse|opensuse*|nobara|scientific)
      rpm -q "$p" >/dev/null 2>&1 ;;
    arch|manjaro|endeavouros|garuda|artix)
      pacman -Q "$p" >/dev/null 2>&1 ;;
    alpine)
      apk info -e "$p" >/dev/null 2>&1 ;;
    gentoo|funtoo)
      qlist -I "$p" >/dev/null 2>&1 || equery -q list "$p" >/dev/null 2>&1 ;;
    void)
      xbps-query "$p" >/dev/null 2>&1 ;;
    nixos)
      nix-env -q "$p" >/dev/null 2>&1 || nix profile list 2>/dev/null | grep -q "$p" ;;
    clear-linux-os|clearlinux)
      swupd bundle-list | grep -qw "$p" 2>/dev/null ;;
    photon)
      tdnf list installed "$p" >/dev/null 2>&1 ;;
    slackware)
      # shellcheck disable=SC2144
      [[ -n "$(compgen -G "/var/log/packages/${p}-*")" ]] ;;
    *) return 1 ;;
  esac
}

pkg_list_upgrades() {
  case "$(detect_distro)" in
    ubuntu|debian|linuxmint|pop|kali|elementary|zorin)
      apt list --upgradable 2>/dev/null || true ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn|nobara|scientific)
      dnf -q check-update || true ;;
    sles|suse|opensuse*)
      zypper list-updates || true ;;
    arch|manjaro|endeavouros|garuda|artix)
      pacman -Qu || true ;;
    alpine)
      apk version -l '<' || true ;;
    gentoo|funtoo)
      emerge -puDN @world 2>/dev/null | grep -E '^\[' || true ;;
    void)
      xbps-install -un 2>/dev/null || true ;;
    nixos)
      # NixOS doesn't have traditional upgrades; check channel updates
      nix-channel --list 2>/dev/null || true ;;
    clear-linux-os|clearlinux)
      swupd check-update 2>/dev/null || true ;;
    photon)
      tdnf check-update -q 2>/dev/null || true ;;
    slackware)
      slackpkg check-updates 2>/dev/null || true ;;
    *) return 0 ;;
  esac
}
