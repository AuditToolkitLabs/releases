#!/usr/bin/env bash
# lib/risk.sh — Risk Scoring Framework
#
# Provides severity-weighted risk scoring for security audits.
# Works with lib/common.sh to add quantifiable risk metrics.
#
# Usage:
#   . lib/risk.sh
#   register_check_risk "SSH Root Login" FAIL "enabled" HIGH
#   register_check_risk "NTP Configured" PASS "" LOW
#   print_risk_summary
#
# Severity Levels:
#   CRITICAL - Immediate exploitation risk (weight: 10)
#   HIGH     - Significant security gap (weight: 7)
#   MEDIUM   - Moderate concern (weight: 4)
#   LOW      - Minor issue (weight: 1)

set -euo pipefail

# Ensure common.sh is loaded
if ! declare -f register_check >/dev/null 2>&1; then
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  . "$SCRIPT_DIR/common.sh"
fi

# Severity weight mapping (associative array)
declare -A SEVERITY_WEIGHT=(
  ["CRITICAL"]=10
  ["HIGH"]=7
  ["MEDIUM"]=4
  ["LOW"]=1
)

# Risk score accumulators
RISK_SCORE=0
RISK_CRITICAL=0
RISK_HIGH=0
RISK_MEDIUM=0
RISK_LOW=0

# Track checks by severity for detailed reporting
declare -a RISK_CRITICAL_CHECKS=()
declare -a RISK_HIGH_CHECKS=()
declare -a RISK_MEDIUM_CHECKS=()
declare -a RISK_LOW_CHECKS=()

# Risk thresholds for overall assessment
RISK_THRESHOLD_LOW=10
RISK_THRESHOLD_MEDIUM=30
RISK_THRESHOLD_HIGH=60

# Reset risk tracking (useful for multiple audit runs)
reset_risk() {
  RISK_SCORE=0
  RISK_CRITICAL=0
  RISK_HIGH=0
  RISK_MEDIUM=0
  RISK_LOW=0
  RISK_CRITICAL_CHECKS=()
  RISK_HIGH_CHECKS=()
  RISK_MEDIUM_CHECKS=()
  RISK_LOW_CHECKS=()
}

# Register a check with risk scoring
# Usage: register_check_risk <name> <PASS|WARN|FAIL|SKIP> [message] [severity]
register_check_risk() {
  local name="$1"
  local result="$2"
  local message="${3:-}"
  local severity="${4:-MEDIUM}"
  
  # Normalize severity to uppercase
  severity="${severity^^}"
  
  # Validate severity
  if [[ -z "${SEVERITY_WEIGHT[$severity]:-}" ]]; then
    severity="MEDIUM"
  fi
  
  # Use JSON-enabled register if available, otherwise base register
  if declare -f register_check_json >/dev/null 2>&1; then
    register_check_json "$name" "$result" "$message" "$severity"
  else
    register_check "$name" "$result" "$message"
  fi
  
  # Calculate risk score for FAILures
  if [[ "$result" == "FAIL" ]]; then
    local weight="${SEVERITY_WEIGHT[$severity]}"
    RISK_SCORE=$((RISK_SCORE + weight))
    
    # Track by severity
    case "$severity" in
      CRITICAL)
        RISK_CRITICAL=$((RISK_CRITICAL + 1))
        RISK_CRITICAL_CHECKS+=("$name")
        ;;
      HIGH)
        RISK_HIGH=$((RISK_HIGH + 1))
        RISK_HIGH_CHECKS+=("$name")
        ;;
      MEDIUM)
        RISK_MEDIUM=$((RISK_MEDIUM + 1))
        RISK_MEDIUM_CHECKS+=("$name")
        ;;
      LOW)
        RISK_LOW=$((RISK_LOW + 1))
        RISK_LOW_CHECKS+=("$name")
        ;;
    esac
  fi
  
  # WARNings add half weight to risk score
  if [[ "$result" == "WARN" ]]; then
    local weight="${SEVERITY_WEIGHT[$severity]}"
    RISK_SCORE=$((RISK_SCORE + (weight / 2)))
  fi
}

# Get risk rating based on score
get_risk_rating() {
  local score="${1:-$RISK_SCORE}"
  
  if [[ "$score" -eq 0 ]]; then
    echo "NONE"
  elif [[ "$score" -le "$RISK_THRESHOLD_LOW" ]]; then
    echo "LOW"
  elif [[ "$score" -le "$RISK_THRESHOLD_MEDIUM" ]]; then
    echo "MEDIUM"
  elif [[ "$score" -le "$RISK_THRESHOLD_HIGH" ]]; then
    echo "HIGH"
  else
    echo "CRITICAL"
  fi
}

# Get color for risk rating
_risk_color() {
  local rating="$1"
  case "$rating" in
    NONE) echo "${GREEN:-}" ;;
    LOW) echo "${BLUE:-}" ;;
    MEDIUM) echo "${YELLOW:-}" ;;
    HIGH) echo "${RED:-}" ;;
    CRITICAL) echo "${RED:-}${BOLD:-}" ;;
    *) echo "" ;;
  esac
}

# Print risk summary
print_risk_summary() {
  local rating
  rating=$(get_risk_rating)
  local color
  color=$(_risk_color "$rating")
  
  echo
  printf "%s\n" "${BOLD:-}+==========================================================+${NC:-}"
  printf "%s\n" "${BOLD:-} RISK ASSESSMENT ${NC:-}"
  printf "%s\n" "${BOLD:-}+==========================================================+${NC:-}"
  
  # Overall score and rating
  printf " Risk Score: %s%d%s  Rating: %s%s%s\n" \
    "$color" "$RISK_SCORE" "${NC:-}" \
    "$color" "$rating" "${NC:-}"
  
  echo
  printf "%s\n" "${BOLD:-}+------------------------+------------------------+${NC:-}"
  printf " ${RED:-}CRITICAL Failures:%s %-4d  ${RED:-}HIGH Failures:%s %-4d\n" \
    "${NC:-}" "$RISK_CRITICAL" "${NC:-}" "$RISK_HIGH"
  printf " ${YELLOW:-}MEDIUM Failures:%s %-4d   ${BLUE:-}LOW Failures:%s %-4d\n" \
    "${NC:-}" "$RISK_MEDIUM" "${NC:-}" "$RISK_LOW"
  printf "%s\n" "${BOLD:-}+------------------------+------------------------+${NC:-}"
  
  # List critical failures if any
  if [[ "${#RISK_CRITICAL_CHECKS[@]}" -gt 0 ]]; then
    echo
    printf '%b' " ${RED:-}${BOLD:-}Critical Issues Requiring Immediate Attention:${NC:-}\n"
    for check in "${RISK_CRITICAL_CHECKS[@]}"; do
      printf '%b %s\n' "   ${RED:-}•${NC:-}" "$check"
    done
  fi
  
  # List high failures if any
  if [[ "${#RISK_HIGH_CHECKS[@]}" -gt 0 ]]; then
    echo
    printf '%b' " ${RED:-}High Priority Issues:${NC:-}\n"
    for check in "${RISK_HIGH_CHECKS[@]}"; do
      printf '%b %s\n' "   ${RED:-}•${NC:-}" "$check"
    done
  fi
  
  printf "%s\n" "${BOLD:-}+==========================================================+${NC:-}"
  
  # Risk thresholds explanation
  echo
  printf " Risk Thresholds: LOW ≤%d, MEDIUM ≤%d, HIGH ≤%d, CRITICAL >%d\n" \
    "$RISK_THRESHOLD_LOW" "$RISK_THRESHOLD_MEDIUM" "$RISK_THRESHOLD_HIGH" "$RISK_THRESHOLD_HIGH"
  printf " Weights: CRITICAL=%d, HIGH=%d, MEDIUM=%d, LOW=%d\n" \
    "${SEVERITY_WEIGHT[CRITICAL]}" "${SEVERITY_WEIGHT[HIGH]}" \
    "${SEVERITY_WEIGHT[MEDIUM]}" "${SEVERITY_WEIGHT[LOW]}"
}

# Export risk data as JSON
export_risk_json() {
  local output_file="${1:-/dev/stdout}"
  
  cat > "$output_file" << EOF
{
  "risk_score": $RISK_SCORE,
  "risk_rating": "$(get_risk_rating)",
  "thresholds": {
    "low": $RISK_THRESHOLD_LOW,
    "medium": $RISK_THRESHOLD_MEDIUM,
    "high": $RISK_THRESHOLD_HIGH
  },
  "failures_by_severity": {
    "critical": $RISK_CRITICAL,
    "high": $RISK_HIGH,
    "medium": $RISK_MEDIUM,
    "low": $RISK_LOW
  },
  "weights": {
    "critical": ${SEVERITY_WEIGHT[CRITICAL]},
    "high": ${SEVERITY_WEIGHT[HIGH]},
    "medium": ${SEVERITY_WEIGHT[MEDIUM]},
    "low": ${SEVERITY_WEIGHT[LOW]}
  }
}
EOF
}

# Set custom risk thresholds
set_risk_thresholds() {
  RISK_THRESHOLD_LOW="${1:-10}"
  RISK_THRESHOLD_MEDIUM="${2:-30}"
  RISK_THRESHOLD_HIGH="${3:-60}"
}

# Check if risk exceeds a threshold
risk_exceeds() {
  local threshold="$1"
  local level="${2:-}"
  
  if [[ -n "$level" ]]; then
    # Check by level name
    case "${level^^}" in
      LOW) threshold="$RISK_THRESHOLD_LOW" ;;
      MEDIUM) threshold="$RISK_THRESHOLD_MEDIUM" ;;
      HIGH) threshold="$RISK_THRESHOLD_HIGH" ;;
    esac
  fi
  
  [[ "$RISK_SCORE" -gt "$threshold" ]]
}
