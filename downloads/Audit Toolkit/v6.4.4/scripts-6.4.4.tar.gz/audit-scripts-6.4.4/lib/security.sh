#!/usr/bin/env bash
# Security stack shims — SELinux, AppArmor, MAC abstraction
# Cross-distro: RHEL/Fedora (SELinux), Ubuntu/Debian/SUSE (AppArmor), Alpine (optional)
set -euo pipefail

# shellcheck source=./distro.sh
. "$(dirname "${BASH_SOURCE[0]}")/distro.sh"

# ============================================================================
# MANDATORY ACCESS CONTROL (MAC) DETECTION
# ============================================================================

# Detect active MAC system: returns "selinux", "apparmor", or "none"
mac_system() {
  if has_selinux && [[ "$(getenforce 2>/dev/null)" != "Disabled" ]]; then
    echo "selinux"
  elif has_apparmor && [[ -d /sys/kernel/security/apparmor ]]; then
    echo "apparmor"
  else
    echo "none"
  fi
}

# Check if any MAC is enforcing
mac_is_enforcing() {
  local sys
  sys=$(mac_system)
  case "$sys" in
    selinux)  [[ "$(getenforce 2>/dev/null)" == "Enforcing" ]] ;;
    apparmor) aa-status --enabled 2>/dev/null ;;
    *)        return 1 ;;
  esac
}

# ============================================================================
# SELINUX SHIMS
# ============================================================================

selinux_mode() {
  # Returns: Enforcing, Permissive, Disabled
  getenforce 2>/dev/null || echo "Disabled"
}

selinux_policy() {
  # Returns current policy type (targeted, mls, minimum)
  sestatus 2>/dev/null | awk -F: '/Loaded policy name/ {gsub(/^[ \t]+/, "", $2); print $2}'
}

selinux_booleans() {
  # List security-relevant booleans
  getsebool -a 2>/dev/null || true
}

selinux_denials() {
  # Get recent AVC denials (last 100)
  if command -v ausearch >/dev/null 2>&1; then
    ausearch -m avc -ts recent 2>/dev/null | tail -n 100 || true
  elif [[ -r /var/log/audit/audit.log ]]; then
    grep 'type=AVC' /var/log/audit/audit.log 2>/dev/null | tail -n 100 || true
  fi
}

selinux_file_context() {
  # Get SELinux context for a file
  local path="$1"
  ls -Z "$path" 2>/dev/null | awk '{print $1}' || true
}

# ============================================================================
# APPARMOR SHIMS
# ============================================================================

apparmor_status() {
  # Returns profiles in enforce/complain/unconfined counts
  aa-status 2>/dev/null || true
}

apparmor_profiles() {
  # List loaded profiles
  if command -v aa-status >/dev/null 2>&1; then
    aa-status --profiled 2>/dev/null || true
  elif [[ -d /sys/kernel/security/apparmor/policy/profiles ]]; then
    ls /sys/kernel/security/apparmor/policy/profiles 2>/dev/null || true
  fi
}

apparmor_enforced() {
  # List profiles in enforce mode
  aa-status 2>/dev/null | awk '/profiles are in enforce mode/,/profiles are in complain mode/' | grep -v 'profiles are' || true
}

apparmor_complain() {
  # List profiles in complain mode
  aa-status 2>/dev/null | awk '/profiles are in complain mode/,/profiles are unconfined/' | grep -v 'profiles are' || true
}

apparmor_denials() {
  # Get recent AppArmor denials
  if command -v journalctl >/dev/null 2>&1; then
    journalctl -k --grep="apparmor=\"DENIED\"" -n 100 2>/dev/null || true
  elif [[ -r /var/log/kern.log ]]; then
    grep 'apparmor="DENIED"' /var/log/kern.log 2>/dev/null | tail -n 100 || true
  elif [[ -r /var/log/syslog ]]; then
    grep 'apparmor="DENIED"' /var/log/syslog 2>/dev/null | tail -n 100 || true
  fi
}

# ============================================================================
# DISTRO-SPECIFIC SECURITY TOOL PATHS
# ============================================================================

# Get path to audit daemon config
audit_conf_path() {
  local distro
  distro=$(detect_distro)
  case "$distro" in
    alpine)     echo "/etc/audit/auditd.conf" ;;
    *)          echo "/etc/audit/auditd.conf" ;;
  esac
}

# Get path to audit rules
audit_rules_path() {
  if [[ -d /etc/audit/rules.d ]]; then
    echo "/etc/audit/rules.d"
  else
    echo "/etc/audit/audit.rules"
  fi
}

# Get path to PAM config directory
pam_conf_dir() {
  echo "/etc/pam.d"
}

# Get path to sudo config
sudoers_path() {
  echo "/etc/sudoers"
}

sudoers_d_path() {
  echo "/etc/sudoers.d"
}

# ============================================================================
# PASSWORD/AUTH POLICY DETECTION
# ============================================================================

# Get password policy tool
password_policy_tool() {
  local distro
  distro=$(detect_distro)
  case "$distro" in
    ubuntu|debian|linuxmint|pop)
      if command -v pam-auth-update >/dev/null 2>&1; then
        echo "pam-auth-update"
      else
        echo "pam"
      fi
      ;;
    rhel|fedora|centos|almalinux|rocky|ol|amzn)
      if command -v authselect >/dev/null 2>&1; then
        echo "authselect"
      elif command -v authconfig >/dev/null 2>&1; then
        echo "authconfig"
      else
        echo "pam"
      fi
      ;;
    sles|suse|opensuse*)
      if command -v pam-config >/dev/null 2>&1; then
        echo "pam-config"
      else
        echo "pam"
      fi
      ;;
    *)
      echo "pam"
      ;;
  esac
}

# Check if password complexity is configured
password_complexity_enabled() {
  local distro
  distro=$(detect_distro)

  # Check pwquality (modern)
  if [[ -f /etc/security/pwquality.conf ]]; then
    grep -qE '^(minlen|dcredit|ucredit|lcredit|ocredit)' /etc/security/pwquality.conf 2>/dev/null && return 0
  fi

  # Check PAM (cracklib or pwquality)
  if grep -rqE 'pam_pwquality|pam_cracklib' /etc/pam.d/ 2>/dev/null; then
    return 0
  fi

  return 1
}

# ============================================================================
# ACCOUNT LOCKOUT DETECTION
# ============================================================================

# Check if faillock/pam_tally2 is configured
account_lockout_enabled() {
  # Modern: pam_faillock
  if grep -rq 'pam_faillock' /etc/pam.d/ 2>/dev/null; then
    return 0
  fi

  # Legacy: pam_tally2
  if grep -rq 'pam_tally2' /etc/pam.d/ 2>/dev/null; then
    return 0
  fi

  return 1
}

# Get lockout threshold
lockout_threshold() {
  # Check faillock.conf (RHEL 8+)
  if [[ -f /etc/security/faillock.conf ]]; then
    grep -E '^deny' /etc/security/faillock.conf | awk -F= '{print $2}' | tr -d ' '
    return
  fi

  # Check PAM inline
  grep -rh 'pam_faillock\|pam_tally2' /etc/pam.d/ 2>/dev/null | \
    grep -oE 'deny=[0-9]+' | head -1 | cut -d= -f2
}

# ============================================================================
# LOGGING SYSTEM DETECTION
# ============================================================================

# Detect primary logging daemon
logging_daemon() {
  if is_systemd && systemctl is-active --quiet rsyslog 2>/dev/null; then
    echo "rsyslog"
  elif is_systemd && systemctl is-active --quiet syslog-ng 2>/dev/null; then
    echo "syslog-ng"
  elif is_openrc && rc-service rsyslog status >/dev/null 2>&1; then
    echo "rsyslog"
  elif is_openrc && rc-service syslog-ng status >/dev/null 2>&1; then
    echo "syslog-ng"
  elif is_systemd; then
    echo "journald"
  else
    echo "syslog"
  fi
}

# Get syslog config path
syslog_conf_path() {
  local daemon
  daemon=$(logging_daemon)
  case "$daemon" in
    rsyslog)   echo "/etc/rsyslog.conf" ;;
    syslog-ng) echo "/etc/syslog-ng/syslog-ng.conf" ;;
    journald)  echo "/etc/systemd/journald.conf" ;;
    *)         echo "/etc/syslog.conf" ;;
  esac
}

# ============================================================================
# KERNEL HARDENING
# ============================================================================

# Check sysctl value
sysctl_get() {
  local key="$1"
  sysctl -n "$key" 2>/dev/null || echo ""
}

# Check if kernel hardening is enabled
kernel_hardening_check() {
  local param="$1"
  local expected="${2:-1}"
  local actual
  actual=$(sysctl_get "$param")
  [[ "$actual" == "$expected" ]]
}

# Standard kernel hardening parameters
kernel_hardening_params() {
  cat <<'EOF'
kernel.randomize_va_space=2
kernel.kptr_restrict=2
kernel.dmesg_restrict=1
kernel.perf_event_paranoid=3
kernel.yama.ptrace_scope=2
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.default.accept_source_route=0
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv4.tcp_syncookies=1
net.ipv6.conf.all.accept_redirects=0
net.ipv6.conf.default.accept_redirects=0
net.ipv6.conf.all.accept_source_route=0
net.ipv6.conf.default.accept_source_route=0
EOF
}
