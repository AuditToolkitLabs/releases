#!/usr/bin/env bash
# SELinux/AppArmor status
set -euo pipefail

selinux_status() { command -v getenforce >/dev/null 2>&1 && getenforce || echo "not present"; }
apparmor_status(){ command -v aa-status  >/dev/null 2>&1 && aa-status  || echo "not present"; }
