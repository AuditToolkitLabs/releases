#!/usr/bin/env bash
# Service manager shims - supports systemd, OpenRC, runit, s6, dinit, sysvinit
set -euo pipefail

# shellcheck source=./distro.sh
. "$(dirname "${BASH_SOURCE[0]}")/distro.sh"

# ============================================================================
# SERVICE ENABLED CHECK
# ============================================================================

svc_is_enabled() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl is-enabled --quiet "$s" 2>/dev/null
  elif is_openrc; then
    # Use -F to prevent regex injection via service names
    rc-update show 2>/dev/null | grep -qF " ${s} "
  elif is_runit; then
    # runit: service is enabled if symlinked in /var/service or /service
    [[ -L "/var/service/$s" ]] || [[ -L "/service/$s" ]] || [[ -L "/run/runit/service/$s" ]]
  elif is_s6; then
    # s6: check if service directory exists in scan directory
    [[ -d "/run/s6/services/$s" ]] || [[ -d "/var/run/s6/services/$s" ]] || \
    s6-rc-db list all 2>/dev/null | grep -qF "$s"
  elif is_dinit; then
    # dinit: check if service is in boot target
    dinitctl list 2>/dev/null | grep -qE "^\[\+\].*$s"
  elif is_sysvinit; then
    # sysvinit: check rc.d symlinks
    # shellcheck disable=SC2144
    [[ -n "$(compgen -G "/etc/rc*.d/S*${s}")" ]] || \
    chkconfig --list "$s" 2>/dev/null | grep -q ':on'
  else
    return 1
  fi
}

# ============================================================================
# SERVICE ACTIVE/RUNNING CHECK
# ============================================================================

svc_is_active() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl is-active --quiet "$s" 2>/dev/null
  elif is_openrc; then
    # Use -F to prevent regex injection; check for " started " for status
    rc-status 2>/dev/null | grep -F " ${s} " | grep -qF "started"
  elif is_runit; then
    # runit: sv status returns 0 if running
    sv status "$s" 2>/dev/null | grep -qE '^run:'
  elif is_s6; then
    # s6: s6-svstat checks service status
    s6-svstat "/run/s6/services/$s" 2>/dev/null | grep -q 'up' || \
    s6-rc -a list 2>/dev/null | grep -qF "$s"
  elif is_dinit; then
    # dinit: dinitctl status shows service state
    dinitctl status "$s" 2>/dev/null | grep -qE 'STARTED|running'
  elif is_sysvinit; then
    # sysvinit: try service command
    service "$s" status 2>/dev/null | grep -qiE 'running|active|started' || \
    /etc/init.d/"$s" status 2>/dev/null
  else
    return 1
  fi
}

# ============================================================================
# SERVICE CONTROL
# ============================================================================

svc_start() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl start "$s"
  elif is_openrc; then
    rc-service "$s" start
  elif is_runit; then
    sv start "$s"
  elif is_s6; then
    s6-svc -u "/run/s6/services/$s" 2>/dev/null || s6-rc -u change "$s"
  elif is_dinit; then
    dinitctl start "$s"
  elif is_sysvinit; then
    service "$s" start 2>/dev/null || /etc/init.d/"$s" start
  else
    return 1
  fi
}

svc_stop() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl stop "$s"
  elif is_openrc; then
    rc-service "$s" stop
  elif is_runit; then
    sv stop "$s"
  elif is_s6; then
    s6-svc -d "/run/s6/services/$s" 2>/dev/null || s6-rc -d change "$s"
  elif is_dinit; then
    dinitctl stop "$s"
  elif is_sysvinit; then
    service "$s" stop 2>/dev/null || /etc/init.d/"$s" stop
  else
    return 1
  fi
}

svc_reload() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl reload "$s"
  elif is_openrc; then
    rc-service "$s" reload
  elif is_runit; then
    sv reload "$s" 2>/dev/null || sv hup "$s"
  elif is_s6; then
    s6-svc -h "/run/s6/services/$s"
  elif is_dinit; then
    dinitctl reload "$s" 2>/dev/null || { dinitctl stop "$s"; dinitctl start "$s"; }
  elif is_sysvinit; then
    service "$s" reload 2>/dev/null || /etc/init.d/"$s" reload
  else
    return 1
  fi
}

svc_restart() { # <service>
  local s="$1"

  if is_systemd; then
    systemctl restart "$s"
  elif is_openrc; then
    rc-service "$s" restart
  elif is_runit; then
    sv restart "$s"
  elif is_s6; then
    s6-svc -r "/run/s6/services/$s"
  elif is_dinit; then
    dinitctl restart "$s"
  elif is_sysvinit; then
    service "$s" restart 2>/dev/null || /etc/init.d/"$s" restart
  else
    return 1
  fi
}

# ============================================================================
# SERVICE LISTING
# ============================================================================

svc_list_all() {
  if is_systemd; then
    systemctl list-units --type=service --all --no-legend 2>/dev/null | awk '{print $1}' | sed 's/\.service$//'
  elif is_openrc; then
    rc-service --list 2>/dev/null
  elif is_runit; then
    # List all available services
    ls /etc/sv/ 2>/dev/null || ls /var/service/ 2>/dev/null
  elif is_s6; then
    s6-rc-db list all 2>/dev/null || ls /run/s6/services/ 2>/dev/null
  elif is_dinit; then
    dinitctl list 2>/dev/null | awk '{print $2}'
  elif is_sysvinit; then
    for f in /etc/init.d/*; do
      [[ -x "$f" ]] && [[ "$(basename "$f")" != "README" ]] && basename "$f"
    done 2>/dev/null
  else
    return 1
  fi
}

svc_list_running() {
  if is_systemd; then
    systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk '{print $1}' | sed 's/\.service$//'
  elif is_openrc; then
    rc-status 2>/dev/null | grep -F 'started' | awk '{print $1}'
  elif is_runit; then
    # List running runit services
    local svc_dirs=(/var/service/* /service/*)
    for svc in "${svc_dirs[@]}"; do
      [[ -d "$svc" ]] && sv status "$svc" 2>/dev/null | grep -q '^run:' && basename "$svc"
    done 2>/dev/null || true
  elif is_s6; then
    s6-rc -a list 2>/dev/null
  elif is_dinit; then
    dinitctl list 2>/dev/null | grep -E '^\[\+\]' | awk '{print $2}'
  elif is_sysvinit; then
    service --status-all 2>/dev/null | grep ' + ' | awk '{print $4}'
  else
    return 1
  fi
}
