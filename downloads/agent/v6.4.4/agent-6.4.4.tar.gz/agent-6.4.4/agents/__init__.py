"""Agent package compatibility namespace."""
