"""
Hypervisor Fleet Agent Framework

Provides API-only fleet agents for hypervisor security audits.

Supported Platforms:
- Proxmox VE (proxmox)
- VMware ESXi (esxi)
- VMware vCenter (vcenter)
- KVM/libvirt (kvm)
- XCP-ng (xcp-ng)
- Xen Orchestra (xen-orchestra)
- Nutanix AHV (nutanix)

Usage:
    from hypervisor import get_agent

    # Get platform-specific agent
    agent = get_agent('proxmox', server_url='https://audit.example.com', api_key='...')

    # Run audit
    results = agent.run_audit()

    # Submit results to server
    agent.submit_results(results)

Author: Security Audit Toolkit Team
Version: 6.2.1
"""

__version__ = "6.2.1"
__author__ = "Security Audit Toolkit Team"

from .core import (
    HypervisorAgent,
    APIClient,
    AuditResults,
    CheckResult,
    Command,
    logger
)
from .platforms import get_agent, SUPPORTED_PLATFORMS

__all__ = [
    # Core classes
    "HypervisorAgent",
    "APIClient",
    "AuditResults",
    "CheckResult",
    "Command",
    "logger",
    # Platform loader
    "get_agent",
    "SUPPORTED_PLATFORMS",
    # Version info
    "__version__",
]


def list_supported_platforms():
    """List all supported hypervisor platforms"""
    return list(SUPPORTED_PLATFORMS.keys())


def detect_platform():
    """
    Attempt to detect the current hypervisor platform.

    Returns:
        str: Platform ID if detected, None otherwise
    """
    from pathlib import Path
    import subprocess

    # Check for Proxmox
    if Path("/etc/pve").exists():
        return "proxmox"

    # Check for ESXi
    try:
        result = subprocess.run(['vmware', '-v'], capture_output=True, text=True)
        if 'ESXi' in result.stdout:
            return "esxi"
    except FileNotFoundError:
        pass

    # Check for libvirt/KVM
    if Path("/etc/libvirt").exists():
        return "kvm"

    # Check for XCP-ng/Xen
    if Path("/etc/xensource").exists():
        return "xcp-ng"

    return None
