#!/usr/bin/env python3
"""
Hypervisor Agent - Entry Point

Auto-detects the hypervisor platform and launches the appropriate
platform-specific agent. Communicates with the central Security Audit
Toolkit server via HTTPS only (outbound, polling model).

Supported platforms:
  proxmox   - Proxmox VE (pvesh / qm / pct)
  kvm       - KVM/libvirt (virsh / virt-*)
  xen       - XCP-ng / Citrix Hypervisor (xe / xapi)
  nutanix   - Nutanix AHV on CVM (acli / ncli)
  esxi      - VMware ESXi (esxcli / vim-cmd)

Usage:
  hypervisor-agent.py daemon   [--platform <p>] [--config <f>] [--server <url>] [--api-key <k>]
  hypervisor-agent.py register [--platform <p>] [--config <f>] [--server <url>] [--api-key <k>]
  hypervisor-agent.py audit    [--platform <p>] [--config <f>] [--categories <c1,c2>]
  hypervisor-agent.py discovery [--platform <p>] [--config <f>]
  hypervisor-agent.py status   [--platform <p>] [--config <f>]
  hypervisor-agent.py version

Author: Security Audit Toolkit Team
"""

import argparse
import importlib
import json
import logging
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger('hypervisor-agent')

# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------
_VERSION_FILE = Path(__file__).parent / 'VERSION'
AGENT_VERSION = (
    _VERSION_FILE.read_text(encoding='utf-8').strip()
    if _VERSION_FILE.exists()
    else '1.0.0'
)

# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

_PLATFORM_PROBES = {
    'proxmox': [
        lambda: Path('/etc/pve').is_dir(),
        lambda: _cmd_exists('pvesh'),
    ],
    'esxi': [
        lambda: Path('/etc/vmware').is_dir(),
        lambda: _cmd_exists('esxcli'),
        lambda: Path('/vmfs').is_dir(),
    ],
    'xen': [
        lambda: Path('/etc/xensource').is_dir(),
        lambda: _cmd_exists('xe'),
        lambda: Path('/var/xapi').is_dir(),
    ],
    'nutanix': [
        lambda: Path('/home/nutanix').is_dir(),
        lambda: _cmd_exists('acli'),
        lambda: _cmd_exists('ncli'),
    ],
    'kvm': [
        lambda: Path('/etc/libvirt').is_dir(),
        lambda: _cmd_exists('virsh'),
    ],
}

_PLATFORM_MODULES = {
    'proxmox': ('platforms.proxmox', 'ProxmoxAgent'),
    'esxi':    ('platforms.esxi',    'ESXiAgent'),
    'xen':     ('platforms.xen',     'XenAgent'),
    'nutanix': ('platforms.nutanix', 'NutanixAgent'),
    'kvm':     ('platforms.kvm',     'KVMAgent'),
}


def _cmd_exists(name: str) -> bool:
    try:
        result = subprocess.run(
            ['which', name], capture_output=True, timeout=3
        )
        return result.returncode == 0
    except Exception:
        return False


def detect_platform() -> str:
    """Return the first platform whose probes match, or 'unknown'."""
    for platform, probes in _PLATFORM_PROBES.items():
        for probe in probes:
            try:
                if probe():
                    logger.info(f'Auto-detected platform: {platform}')
                    return platform
            except Exception:
                pass
    return 'unknown'


def load_agent_class(platform: str):
    """Import and return the agent class for the given platform."""
    if platform not in _PLATFORM_MODULES:
        logger.error(f"Unknown platform: {platform}. "
                     f"Supported: {', '.join(_PLATFORM_MODULES)}")
        sys.exit(1)

    module_path, class_name = _PLATFORM_MODULES[platform]

    # Support both package (installed) and direct-file execution
    try:
        mod = importlib.import_module(module_path)
    except ModuleNotFoundError:
        # Try relative to this file's directory
        sys.path.insert(0, str(Path(__file__).parent))
        mod = importlib.import_module(module_path)

    return getattr(mod, class_name)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _default_config_path(platform: str) -> Path:
    # Nutanix runs on CVM - use the nutanix home dir
    if platform == 'nutanix':
        return Path('/home/nutanix/audit-agent/config.json')
    return Path('/opt/audit-hypervisor-agent/config.json')


def load_config(config_path: str, platform: str) -> dict:
    path = Path(config_path) if config_path else _default_config_path(platform)
    if path.exists():
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f'Could not read config {path}: {e}')
    return {}


# ---------------------------------------------------------------------------
# Daemon loop
# ---------------------------------------------------------------------------

_POLL_INTERVAL_DEFAULT = 60  # seconds


def run_daemon(agent, poll_interval: int = _POLL_INTERVAL_DEFAULT):
    """Main polling loop: register → heartbeat → dispatch commands."""
    logger.info(
        f'Starting daemon — platform={agent.PLATFORM}  '
        f'agent_id={agent.agent_id}  poll={poll_interval}s'
    )

    if not agent.register():
        logger.warning('Registration failed — will retry on next heartbeat cycle')

    while True:
        try:
            commands = agent.heartbeat()
            for cmd in commands:
                _dispatch_command(agent, cmd)
        except KeyboardInterrupt:
            logger.info('Daemon stopped by user')
            break
        except Exception as exc:
            logger.error(f'Heartbeat cycle error: {exc}')

        time.sleep(poll_interval)


def _dispatch_command(agent, cmd):
    ctype = cmd.type
    params = cmd.params or {}
    logger.info(f'Dispatching command id={cmd.id} type={ctype}')

    try:
        if ctype == 'run_audit':
            categories = params.get('categories')
            results = agent.run_audit(categories=categories)
            agent.submit_results(results)

        elif ctype == 'discovery':
            include_guests = params.get('include_guest_details', False)
            inventory = agent.collect_discovery_inventory(
                include_guest_details=include_guests
            )
            if agent.api:
                agent.api.post(
                    f'/api/hypervisor-agent/{agent.agent_id}/discovery',
                    inventory
                )

        elif ctype == 'run_platform_audit_script':
            script = params.get('script')
            args = params.get('args', [])
            if not script:
                logger.warning('run_platform_audit_script: missing "script" param')
                return
            result = agent._run_platform_audit_script(script, args=args)
            logger.info(f'Script result: rc={result.get("returncode")}')

        elif ctype == 'update_config':
            # Apply server-pushed config overrides and persist
            if isinstance(params, dict):
                agent.config.update(params)
                agent._save_config()
                logger.info('Config updated from server')

        elif ctype == 'key_rotation':
            new_key = params.get('new_api_key')
            if new_key:
                agent.api_key = new_key
                agent._save_api_key(new_key)
                logger.info('API key rotated')

        else:
            logger.warning(f'Unknown command type: {ctype}')

    except Exception as exc:
        logger.error(f'Command {ctype} (id={cmd.id}) failed: {exc}')


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='hypervisor-agent',
        description='Security Audit Toolkit — Hypervisor Agent',
    )
    parser.add_argument('command',
                        choices=['daemon', 'register', 'audit', 'discovery', 'status', 'version'],
                        help='Action to perform')
    parser.add_argument('--platform', '-p',
                        choices=list(_PLATFORM_MODULES.keys()),
                        help='Force hypervisor platform (auto-detect if omitted)')
    parser.add_argument('--config', '-c',
                        help='Path to config.json (uses platform default if omitted)')
    parser.add_argument('--server', '-s',
                        help='Central server URL (overrides config)')
    parser.add_argument('--api-key', '-k',
                        help='API key (overrides config; prefer AUDIT_API_KEY env var)')
    parser.add_argument('--categories',
                        help='Comma-separated audit categories for "audit" command')
    parser.add_argument('--poll-interval', type=int, default=_POLL_INTERVAL_DEFAULT,
                        help=f'Heartbeat interval in seconds (default: {_POLL_INTERVAL_DEFAULT})')
    parser.add_argument('--log-level', default='INFO',
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='Logging verbosity')
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    logging.getLogger().setLevel(getattr(logging, args.log_level))

    if args.command == 'version':
        print(f'hypervisor-agent {AGENT_VERSION}')
        sys.exit(0)

    # Resolve platform
    platform = args.platform or detect_platform()
    if platform == 'unknown':
        logger.error(
            'Could not auto-detect hypervisor platform. '
            'Specify --platform explicitly.'
        )
        sys.exit(1)

    # Load config
    cfg = load_config(args.config, platform)

    # Build agent kwargs — CLI/env takes precedence over config file
    agent_kwargs = dict(
        config_path=args.config or str(_default_config_path(platform)),
        server_url=args.server or os.environ.get('AUDIT_SERVER_URL') or cfg.get('server_url'),
        api_key=(args.api_key
                 or os.environ.get('AUDIT_API_KEY')
                 or cfg.get('api_key')),
    )

    AgentClass = load_agent_class(platform)
    agent = AgentClass(**agent_kwargs)

    # -----------------------------------------------------------------------
    if args.command == 'daemon':
        run_daemon(agent, poll_interval=args.poll_interval)

    elif args.command == 'register':
        ok = agent.register()
        sys.exit(0 if ok else 1)

    elif args.command == 'audit':
        categories = args.categories.split(',') if args.categories else None
        results = agent.run_audit(categories=categories)
        results.print_summary()
        if agent.api:
            agent.submit_results(results)
        else:
            print(results.to_json())

    elif args.command == 'discovery':
        inventory = agent.collect_discovery_inventory(include_guest_details=True)
        if agent.api:
            agent.api.post(
                f'/api/hypervisor-agent/{agent.agent_id}/discovery',
                inventory
            )
        else:
            print(json.dumps(inventory, indent=2))

    elif args.command == 'status':
        print(f'Platform     : {agent.PLATFORM_NAME}')
        print(f'Platform ver : {agent.platform_version}')
        print(f'Agent ID     : {agent.agent_id}')
        print(f'Server URL   : {agent.server_url or "(not configured)"}')
        print(f'Hostname     : {socket.gethostname()}')
        print(f'Agent version: {AGENT_VERSION}')
        buffered = list(agent._buffered_results_path.glob('result_*.json'))
        print(f'Buffered results: {len(buffered)}')


if __name__ == '__main__':
    main()
