#!/bin/sh
# =============================================================================
# Hypervisor Agent - ESXi Installer
# =============================================================================
# Installs the Security Audit Toolkit Hypervisor Agent on VMware ESXi hosts.
#
# ESXi CONSTRAINTS:
#   - BusyBox shell (not bash) — POSIX sh only; no 'set -euo pipefail'
#   - Python may be embedded and version/path varies between ESXi releases
#   - No systemd or OpenRC — persistence via /etc/rc.local.d/
#   - Runs as root (no service user concept)
#   - 'requests' library typically unavailable; agent runs in buffered/offline
#     mode unless requests is installed (via pip or vendor/ wheels in bundle)
#   - Files written to local datastores do NOT survive firmware upgrades;
#     re-install the agent after ESXi upgrades
#
# Run as:  sh ./install-esxi.sh [OPTIONS]
#
# Options:
#   -s  <url>   Central audit server URL
#   -k  <key>   Agent API key (prefer AUDIT_API_KEY env var)
#   -d  <path>  Install directory (default: /opt/audit-agent)
#   -h          Show this help
#
# Note: The agent communicates with the server via HTTPS. Without the
#       'requests' library the agent stores results locally and they
#       must be retrieved manually or via a periodic sync script.
#
# Author: Security Audit Toolkit Team
# =============================================================================

INSTALL_DIR_DEFAULT="/opt/audit-agent"
INSTALL_DIR=""
SERVICE_SCRIPT="/etc/rc.local.d/audit-hypervisor-agent.sh"
AGENT_VERSION="${AUDIT_AGENT_VERSION:-1.0.0}"

SERVER_URL="${AUDIT_SERVER_URL:-}"
API_KEY="${AUDIT_API_KEY:-}"

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

# ---------------------------------------------------------------------------
log_info()  { echo "[INFO]  $*"; }
log_warn()  { echo "[WARN]  $*" >&2; }
log_error() { echo "[ERROR] $*" >&2; }
log_step()  { echo "[STEP]  $*"; }

# ---------------------------------------------------------------------------
# Argument parsing (BusyBox getopts)
# ---------------------------------------------------------------------------
while getopts "s:k:d:h" opt; do
    case "${opt}" in
        s) SERVER_URL="${OPTARG}" ;;
        k) API_KEY="${OPTARG}" ;;
        d) INSTALL_DIR="${OPTARG}" ;;
        h)
            sed -n '3,22p' "$0"
            exit 0
            ;;
        *)
            log_error "Unknown option: -${OPTARG}"
            exit 1
            ;;
    esac
done

INSTALL_DIR="${INSTALL_DIR:-${INSTALL_DIR_DEFAULT}}"

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------
check_esxi() {
    if [ ! -f /etc/vmware/esx.conf ] && [ ! -d /etc/vmware ]; then
        log_warn "ESXi environment not detected (/etc/vmware missing)"
        log_warn "This installer is designed for VMware ESXi only."
        printf "Continue anyway? [y/N] "
        read -r answer
        case "${answer}" in
            y|Y) ;;
            *) exit 1 ;;
        esac
    fi
}

check_python() {
    PYTHON=""
    for candidate in python3 python3.11 python3.8 python3.6 python; do
        if command -v "${candidate}" >/dev/null 2>&1; then
            ver=$("${candidate}" -c 'import sys; print(sys.version_info.major)' 2>/dev/null || true)
            if [ "${ver}" = "3" ]; then
                PYTHON="${candidate}"
                break
            fi
        fi
    done

    if [ -z "${PYTHON}" ]; then
        log_error "Python 3 is required but was not found."
        log_error "ESXi 7.0+ ships Python 3 — check your ESXi build version."
        exit 1
    fi
    log_info "Using Python: ${PYTHON} ($("${PYTHON}" --version 2>&1))"
}

install_requests_if_possible() {
    log_step "Checking for 'requests' library..."

    if "${PYTHON}" -c 'import requests' >/dev/null 2>&1; then
        log_info "'requests' already available"
        return 0
    fi

    # Try pip (may not exist on all ESXi builds)
    PIP=""
    for candidate in pip3 pip; do
        if command -v "${candidate}" >/dev/null 2>&1; then
            PIP="${candidate}"
            break
        fi
    done

    if [ -n "${PIP}" ]; then
        log_info "Attempting: ${PIP} install requests"
        if "${PIP}" install --quiet requests >/dev/null 2>&1; then
            log_info "'requests' installed via pip"
            return 0
        fi
    fi

    # Try vendor wheels shipped in the bundle
    if [ -d "${SCRIPT_DIR}/vendor" ]; then
        log_info "Attempting offline install from vendor/ directory..."
        if "${PIP:-pip3}" install --quiet --no-index \
            --find-links "${SCRIPT_DIR}/vendor" requests >/dev/null 2>&1; then
            log_info "'requests' installed from vendor/"
            return 0
        fi
    fi

    # requests unavailable — agent will operate in buffered/offline mode
    log_warn "========================================================"
    log_warn "'requests' library could not be installed."
    log_warn "The agent will run in LOCAL BUFFER mode:"
    log_warn "  - Audit results are stored in: ${INSTALL_DIR}/buffered_results/"
    log_warn "  - Results will not be sent to the server automatically."
    log_warn "  - Install 'requests' later and the agent will begin sending."
    log_warn "========================================================"
    return 0
}

# ---------------------------------------------------------------------------
# Installation
# ---------------------------------------------------------------------------
create_directories() {
    log_step "Creating install directories..."
    mkdir -p "${INSTALL_DIR}/platforms"
    mkdir -p "${INSTALL_DIR}/buffered_results"
    # Permissions: root-owned, restricted
    chmod 700 "${INSTALL_DIR}"
    chmod 700 "${INSTALL_DIR}/buffered_results"
    log_info "Install dir: ${INSTALL_DIR}"
}

install_agent_files() {
    log_step "Installing agent files..."

    for f in hypervisor-agent.py core.py; do
        if [ -f "${SCRIPT_DIR}/${f}" ]; then
            cp "${SCRIPT_DIR}/${f}" "${INSTALL_DIR}/${f}"
        else
            log_error "Required file not found: ${SCRIPT_DIR}/${f}"
            exit 1
        fi
    done

    if [ -d "${SCRIPT_DIR}/platforms" ]; then
        cp -r "${SCRIPT_DIR}/platforms/." "${INSTALL_DIR}/platforms/"
    else
        log_error "platforms/ directory not found in ${SCRIPT_DIR}"
        exit 1
    fi

    [ -f "${SCRIPT_DIR}/VERSION" ] && cp "${SCRIPT_DIR}/VERSION" "${INSTALL_DIR}/VERSION"

    # Make entry point executable
    chmod 700 "${INSTALL_DIR}/hypervisor-agent.py"
    log_info "Agent files installed"
}

create_config() {
    log_step "Creating configuration..."

    config_file="${INSTALL_DIR}/config.json"
    key_file="${INSTALL_DIR}/.api_key"

    if [ -z "${SERVER_URL}" ]; then
        printf "Audit Server URL (e.g., https://audit.example.com): "
        read -r SERVER_URL
    fi

    if [ -z "${API_KEY}" ]; then
        printf "API Key: "
        # Disable echo for password input — BusyBox stty
        stty -echo 2>/dev/null || true
        read -r API_KEY
        stty echo 2>/dev/null || true
        echo
    fi

    # Derive a stable agent ID from ESXi host UUID
    AGENT_ID=""
    if command -v vim-cmd >/dev/null 2>&1; then
        AGENT_ID=$(vim-cmd hostsvc/hosthardware 2>/dev/null \
            | grep -i 'uuid' | head -1 | sed 's/.*= //;s/[",]//g;s/ //g' | cut -c1-16 || true)
    fi
    if [ -z "${AGENT_ID}" ]; then
        AGENT_ID=$(hostname | cksum | awk '{print $1}' | head -c16)
    fi

    cat > "${config_file}" << EOF
{
    "server_url": "${SERVER_URL}",
    "agent_id": "${AGENT_ID}",
    "platform": "esxi",
    "poll_interval": 60,
    "verify_ssl": true,
    "buffer_dir": "${INSTALL_DIR}/buffered_results",
    "created_at": "$(date)"
}
EOF
    chmod 600 "${config_file}"

    # Store API key in a restricted plain file (no openssl guaranteed on BusyBox)
    printf '%s' "${API_KEY}" > "${key_file}"
    chmod 600 "${key_file}"

    log_info "Config: ${config_file}"
    log_info "Key file: ${key_file} (mode 600, root only)"
}

install_persistence() {
    log_step "Installing rc.local.d startup script..."

    # /etc/rc.local.d/ is the ESXi mechanism for persistent startup scripts
    if [ ! -d /etc/rc.local.d ]; then
        log_warn "/etc/rc.local.d does not exist — persistence requires ESXi 6.0+"
        log_warn "The agent was installed but will NOT start automatically."
        log_warn "Start manually: ${PYTHON} ${INSTALL_DIR}/hypervisor-agent.py daemon"
        return
    fi

    cat > "${SERVICE_SCRIPT}" << EOF
#!/bin/sh
# Security Audit Toolkit - Hypervisor Agent startup
# Auto-generated by install-esxi.sh on $(date)
${PYTHON} ${INSTALL_DIR}/hypervisor-agent.py daemon \\
    --config "${INSTALL_DIR}/config.json" \\
    --platform esxi \\
    >> "${INSTALL_DIR}/agent.log" 2>&1 &
echo \$! > /var/run/audit-hypervisor-agent.pid
EOF
    chmod +x "${SERVICE_SCRIPT}"
    log_info "Startup script installed: ${SERVICE_SCRIPT}"

    log_info "The agent will start automatically on next ESXi boot."
    log_info "Note: Files on scratch/local storage survive reboots but NOT firmware upgrades."
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    echo ""
    echo "================================================================"
    printf "  Security Audit Toolkit - ESXi Hypervisor Agent v%s\n" "${AGENT_VERSION}"
    echo "================================================================"
    echo ""

    check_esxi
    check_python
    install_requests_if_possible
    create_directories
    install_agent_files
    create_config
    install_persistence

    echo ""
    log_info "Installation complete!"
    echo ""
    echo "================================================================"
    echo " Next steps"
    echo "================================================================"
    echo " Start now   :  ${PYTHON} ${INSTALL_DIR}/hypervisor-agent.py daemon &"
    echo " Check status:  ${PYTHON} ${INSTALL_DIR}/hypervisor-agent.py status"
    echo " View logs   :  tail -f ${INSTALL_DIR}/agent.log"
    echo " Buffered res:  ls ${INSTALL_DIR}/buffered_results/"
    echo ""
    echo " Agent will auto-start on next ESXi boot via:"
    echo "   ${SERVICE_SCRIPT}"
    echo ""
    echo " IMPORTANT: Re-run this installer after ESXi firmware upgrades"
    echo "   as local files may not persist across upgrades."
    echo "================================================================"
}

main "$@"
