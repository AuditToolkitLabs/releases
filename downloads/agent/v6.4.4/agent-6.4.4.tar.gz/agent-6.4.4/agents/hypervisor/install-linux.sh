#!/usr/bin/env bash
# =============================================================================
# Hypervisor Agent - Linux Installer
# =============================================================================
# Installs the Security Audit Toolkit Hypervisor Agent on Linux-based
# hypervisor platforms: Proxmox VE, KVM/libvirt, XCP-ng/Xen, Nutanix AHV (CVM).
#
# For VMware ESXi use install-esxi.sh instead.
#
# Run as: sudo ./install-linux.sh [OPTIONS]
#
# Options:
#   -s, --server <url>        Central audit server URL
#   -k, --api-key <key>       Agent API key (prefer AUDIT_API_KEY env var)
#   -p, --platform <name>     Force platform: proxmox|kvm|xen|nutanix (auto-detect)
#   -d, --install-dir <path>  Override install directory
#   -u, --user <name>         Override service user name
#       --no-service          Skip service unit installation
#       --no-venv             Skip Python venv creation (use system Python)
#   -h, --help                Show this help
#
# Author: Security Audit Toolkit Team
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION_FILE="${SCRIPT_DIR}/VERSION"
if [[ -f "${VERSION_FILE}" ]]; then
    AGENT_VERSION="$(tr -d '\r\n' < "${VERSION_FILE}")"
else
    AGENT_VERSION="${AUDIT_AGENT_VERSION:-1.0.0}"
fi

# =============================================================================
# Defaults (overridden by platform detection or CLI flags)
# =============================================================================
INSTALL_DIR_DEFAULT="/opt/audit-hypervisor-agent"
INSTALL_DIR=""
SERVICE_USER_DEFAULT="audit-hypervisor-agent"
SERVICE_USER=""
SERVICE_GROUP=""
SERVICE_NAME="audit-hypervisor-agent"
CONFIG_DIR="/etc/audit-hypervisor-agent"
LOG_DIR="/var/log/audit-hypervisor-agent"

DETECTED_PLATFORM=""
SERVER_URL="${AUDIT_SERVER_URL:-}"
API_KEY="${AUDIT_API_KEY:-}"
SKIP_SERVICE=false
SKIP_VENV=false

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# =============================================================================
# Helpers
# =============================================================================
log_info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_step()  { echo -e "${CYAN}[STEP]${NC} $*"; }

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

detect_init_system() {
    if command -v systemctl &>/dev/null && systemctl --version &>/dev/null 2>&1; then
        echo "systemd"
    elif command -v rc-service &>/dev/null; then
        echo "openrc"
    else
        echo "unknown"
    fi
}

# =============================================================================
# Platform detection
# =============================================================================
detect_platform() {
    if [[ -d /etc/pve ]] || command -v pvesh &>/dev/null 2>&1; then
        echo "proxmox"; return
    fi
    if [[ -d /home/nutanix ]] || command -v acli &>/dev/null 2>&1; then
        echo "nutanix"; return
    fi
    if [[ -d /etc/xensource ]] || command -v xe &>/dev/null 2>&1; then
        echo "xen"; return
    fi
    if [[ -d /etc/libvirt ]] || command -v virsh &>/dev/null 2>&1; then
        echo "kvm"; return
    fi
    echo "unknown"
}

resolve_platform_defaults() {
    local platform="$1"
    case "${platform}" in
        nutanix)
            # Nutanix CVM: install alongside existing nutanix tooling
            INSTALL_DIR="${INSTALL_DIR:-/home/nutanix/audit-agent}"
            SERVICE_USER="${SERVICE_USER:-nutanix}"
            SERVICE_GROUP="${SERVICE_GROUP:-nutanix}"
            ;;
        proxmox|kvm|xen|*)
            INSTALL_DIR="${INSTALL_DIR:-${INSTALL_DIR_DEFAULT}}"
            SERVICE_USER="${SERVICE_USER:-${SERVICE_USER_DEFAULT}}"
            SERVICE_GROUP="${SERVICE_GROUP:-${SERVICE_USER_DEFAULT}}"
            ;;
    esac
}

# =============================================================================
# Installation steps
# =============================================================================

create_service_user() {
    # Skip for nutanix — use existing nutanix user
    if [[ "${SERVICE_USER}" == "nutanix" ]]; then
        log_info "Using existing user: nutanix"
        return
    fi

    log_step "Creating service user: ${SERVICE_USER}"
    if ! getent group "${SERVICE_GROUP}" &>/dev/null; then
        groupadd --system "${SERVICE_GROUP}"
    fi
    if ! getent passwd "${SERVICE_USER}" &>/dev/null; then
        useradd --system \
            --gid "${SERVICE_GROUP}" \
            --home-dir "${INSTALL_DIR}" \
            --shell /usr/sbin/nologin \
            --comment "Audit Hypervisor Agent" \
            "${SERVICE_USER}"
    fi
    log_info "Service user ready: ${SERVICE_USER}"
}

create_directories() {
    log_step "Creating directories..."
    mkdir -p "${INSTALL_DIR}"/{platforms,buffered_results}
    mkdir -p "${LOG_DIR}"
    mkdir -p "${CONFIG_DIR}"

    chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}" "${LOG_DIR}"
    chmod 750 "${INSTALL_DIR}" "${LOG_DIR}"
    chmod 700 "${INSTALL_DIR}/buffered_results"
    log_info "Directories created"
}

install_agent_files() {
    log_step "Installing agent files..."

    # Core Python modules
    local agent_py="${SCRIPT_DIR}/hypervisor-agent.py"
    local core_py="${SCRIPT_DIR}/core.py"
    local platforms_dir="${SCRIPT_DIR}/platforms"

    [[ -f "${agent_py}" ]] || { log_error "hypervisor-agent.py not found in ${SCRIPT_DIR}"; exit 1; }
    [[ -f "${core_py}" ]] || { log_error "core.py not found in ${SCRIPT_DIR}"; exit 1; }
    [[ -d "${platforms_dir}" ]] || { log_error "platforms/ not found in ${SCRIPT_DIR}"; exit 1; }

    cp "${agent_py}"  "${INSTALL_DIR}/hypervisor-agent.py"
    cp "${core_py}"   "${INSTALL_DIR}/core.py"
    cp -r "${platforms_dir}/." "${INSTALL_DIR}/platforms/"

    # VERSION file
    [[ -f "${SCRIPT_DIR}/VERSION" ]] && cp "${SCRIPT_DIR}/VERSION" "${INSTALL_DIR}/VERSION"

    # Convenience wrapper so the agent can be called as a command
    cat > "${INSTALL_DIR}/run-agent.sh" << 'WRAPPER'
#!/usr/bin/env bash
set -euo pipefail
AGENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${AGENT_DIR}/.venv/bin/python3"
[[ -x "${PYTHON}" ]] || PYTHON="$(command -v python3 2>/dev/null || command -v python)"
exec "${PYTHON}" "${AGENT_DIR}/hypervisor-agent.py" "$@"
WRAPPER
    chmod 750 "${INSTALL_DIR}/run-agent.sh"

    chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
    log_info "Agent files installed to ${INSTALL_DIR}"
}

install_python_deps() {
    if ${SKIP_VENV}; then
        log_warn "--no-venv specified: using system Python (requests must be pre-installed)"
        return
    fi

    log_step "Setting up Python virtual environment..."

    local python_bin
    python_bin="$(command -v python3 2>/dev/null || command -v python || true)"
    if [[ -z "${python_bin}" ]]; then
        log_error "Python 3 not found. Install python3 before running this installer."
        exit 1
    fi

    local py_ver
    py_ver="$("${python_bin}" -c 'import sys; print(sys.version_info.major)')"
    if [[ "${py_ver}" != "3" ]]; then
        log_error "Python 3 required; found: $("${python_bin}" --version)"
        exit 1
    fi

    "${python_bin}" -m venv "${INSTALL_DIR}/.venv"
    "${INSTALL_DIR}/.venv/bin/pip" install --quiet --upgrade pip

    # Install from bundled wheelhouse if present (offline installs)
    if [[ -d "${SCRIPT_DIR}/vendor" ]]; then
        log_info "Installing from bundled vendor wheels..."
        "${INSTALL_DIR}/.venv/bin/pip" install --quiet --no-index \
            --find-links "${SCRIPT_DIR}/vendor" requests
    else
        "${INSTALL_DIR}/.venv/bin/pip" install --quiet requests
    fi

    chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}/.venv"
    log_info "Python environment ready: ${INSTALL_DIR}/.venv"
}

create_config_file() {
    log_step "Creating configuration..."

    local config_file="${CONFIG_DIR}/config.json"

    if [[ -z "${SERVER_URL}" ]]; then
        read -rp "Audit Server URL (e.g., https://audit.example.com): " SERVER_URL
    fi
    if [[ -z "${API_KEY}" ]]; then
        read -rsp "API Key: " API_KEY
        echo
    fi

    local agent_id
    if [[ -f /etc/machine-id ]]; then
        agent_id="$(sha256sum /etc/machine-id | cut -c1-16)"
    else
        agent_id="$(hostname | sha256sum | cut -c1-16)"
    fi

    cat > "${config_file}" << EOF
{
    "server_url": "${SERVER_URL}",
    "agent_id": "${agent_id}",
    "platform": "${DETECTED_PLATFORM}",
    "poll_interval": 60,
    "verify_ssl": true,
    "created_at": "$(date -Iseconds)"
}
EOF
    chmod 640 "${config_file}"
    chown "${SERVICE_USER}:${SERVICE_GROUP}" "${config_file}"

    # Encrypt API key with machine-derived key
    local cred_file="${INSTALL_DIR}/.credentials.enc"
    if command -v openssl &>/dev/null; then
        local machine_key
        machine_key="$(cat /etc/machine-id 2>/dev/null || hostname)$(hostname)audit-hv-key"
        machine_key="$(echo -n "${machine_key}" | sha256sum | cut -d' ' -f1)"
        echo -n "${API_KEY}" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
            -pass "pass:${machine_key}" -base64 > "${cred_file}"
        chmod 600 "${cred_file}"
        chown "${SERVICE_USER}:${SERVICE_GROUP}" "${cred_file}"
    else
        log_warn "OpenSSL not available — storing API key in restricted plain file"
        echo -n "${API_KEY}" > "${INSTALL_DIR}/.api_key"
        chmod 600 "${INSTALL_DIR}/.api_key"
        chown "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}/.api_key"
    fi

    # Symlink so the agent's default_config_path() lookup finds it
    ln -sf "${config_file}" "${INSTALL_DIR}/config.json"
    log_info "Configuration written to ${config_file}"
}

install_systemd_service() {
    log_step "Installing systemd service: ${SERVICE_NAME}"

    local python_exec
    if ${SKIP_VENV}; then
        python_exec="$(command -v python3)"
    else
        python_exec="${INSTALL_DIR}/.venv/bin/python3"
    fi

    cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=Security Audit Toolkit - Hypervisor Agent (${DETECTED_PLATFORM})
Documentation=https://github.com/AuditToolkitLabs/Audit-Tool-
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_GROUP}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${python_exec} ${INSTALL_DIR}/hypervisor-agent.py daemon \\
    --config ${CONFIG_DIR}/config.json
Restart=always
RestartSec=30
StandardOutput=append:${LOG_DIR}/agent.log
StandardError=append:${LOG_DIR}/agent.log

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${INSTALL_DIR} ${LOG_DIR} /tmp
ProtectHome=read-only

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable "${SERVICE_NAME}"
    log_info "Systemd service installed and enabled"
}

install_openrc_service() {
    log_step "Installing OpenRC service: ${SERVICE_NAME}"

    local python_exec
    if ${SKIP_VENV}; then
        python_exec="$(command -v python3)"
    else
        python_exec="${INSTALL_DIR}/.venv/bin/python3"
    fi

    cat > "/etc/init.d/${SERVICE_NAME}" << EOF
#!/sbin/openrc-run
# OpenRC service for Hypervisor Agent (${DETECTED_PLATFORM})

name="${SERVICE_NAME}"
description="Security Audit Toolkit - Hypervisor Agent"
command="${python_exec}"
command_args="${INSTALL_DIR}/hypervisor-agent.py daemon --config ${CONFIG_DIR}/config.json"
command_user="${SERVICE_USER}:${SERVICE_GROUP}"
command_background=true
pidfile="/run/${SERVICE_NAME}.pid"
output_log="${LOG_DIR}/agent.log"
error_log="${LOG_DIR}/agent.log"

depend() {
    need net
    after firewall
}
EOF
    chmod 755 "/etc/init.d/${SERVICE_NAME}"
    rc-update add "${SERVICE_NAME}" default
    log_info "OpenRC service installed and enabled"
}

# =============================================================================
# Argument parsing
# =============================================================================
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -s|--server)    SERVER_URL="$2";    shift 2 ;;
            -k|--api-key)   API_KEY="$2";       shift 2 ;;
            -p|--platform)  DETECTED_PLATFORM="$2"; shift 2 ;;
            -d|--install-dir) INSTALL_DIR="$2"; shift 2 ;;
            -u|--user)      SERVICE_USER="$2"; SERVICE_GROUP="$2"; shift 2 ;;
            --no-service)   SKIP_SERVICE=true;  shift ;;
            --no-venv)      SKIP_VENV=true;     shift ;;
            -h|--help)
                sed -n '3,20p' "$0"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

# =============================================================================
# Main
# =============================================================================
main() {
    parse_args "$@"

    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    printf "║  Security Audit Toolkit - Hypervisor Agent Installer v%-6s ║\n" "${AGENT_VERSION}"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""

    check_root

    # Platform
    if [[ -z "${DETECTED_PLATFORM}" ]]; then
        DETECTED_PLATFORM="$(detect_platform)"
    fi
    if [[ "${DETECTED_PLATFORM}" == "unknown" ]]; then
        log_warn "Could not auto-detect platform — proceeding with generic Linux install"
        DETECTED_PLATFORM="kvm"
    fi
    log_info "Platform: ${DETECTED_PLATFORM}"

    resolve_platform_defaults "${DETECTED_PLATFORM}"
    log_info "Install dir  : ${INSTALL_DIR}"
    log_info "Service user : ${SERVICE_USER}"

    local init_system
    init_system="$(detect_init_system)"
    log_info "Init system  : ${init_system}"

    create_service_user
    create_directories
    install_agent_files
    install_python_deps
    create_config_file

    if ! ${SKIP_SERVICE}; then
        case "${init_system}" in
            systemd) install_systemd_service ;;
            openrc)  install_openrc_service  ;;
            *)
                log_warn "Unknown init system — skipping service installation"
                log_warn "Start manually: ${INSTALL_DIR}/run-agent.sh daemon"
                ;;
        esac
    fi

    echo ""
    log_info "Installation complete!"
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo " Next steps"
    echo "═══════════════════════════════════════════════════════════════"
    if [[ "${init_system}" == "systemd" ]] && ! ${SKIP_SERVICE}; then
        echo " Start agent :  sudo systemctl start ${SERVICE_NAME}"
        echo " Check status:  sudo systemctl status ${SERVICE_NAME}"
        echo " View logs   :  sudo journalctl -fu ${SERVICE_NAME}"
    elif [[ "${init_system}" == "openrc" ]] && ! ${SKIP_SERVICE}; then
        echo " Start agent :  sudo rc-service ${SERVICE_NAME} start"
        echo " Check status:  sudo rc-service ${SERVICE_NAME} status"
        echo " View logs   :  tail -f ${LOG_DIR}/agent.log"
    else
        echo " Start agent :  sudo -u ${SERVICE_USER} ${INSTALL_DIR}/run-agent.sh daemon"
        echo " View logs   :  tail -f ${LOG_DIR}/agent.log"
    fi
    echo " Agent status:  sudo ${INSTALL_DIR}/run-agent.sh status"
    echo "═══════════════════════════════════════════════════════════════"
}

main "$@"
