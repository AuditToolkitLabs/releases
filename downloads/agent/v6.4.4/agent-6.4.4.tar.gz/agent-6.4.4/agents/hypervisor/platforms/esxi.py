#!/usr/bin/env python3
"""
VMware ESXi Fleet Agent

Security audit agent for VMware ESXi hypervisors using native CLI tools.
Communicates with central server via REST API only.

Supports:
- ESXi 6.5, 6.7, 7.0, 8.0
- Standalone hosts and vCenter-managed hosts
- Security, network, storage, and compute audits

Native Tools Used:
- esxcli: Primary CLI interface
- vim-cmd: VM and host management
- localcli: Local shell commands

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import json
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from ..core import AuditResults, HypervisorAgent, logger
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from core import AuditResults, HypervisorAgent, logger


class ESXiAgent(HypervisorAgent):
    """
    VMware ESXi Security Audit Agent

    Uses native ESXi tools (esxcli, vim-cmd) for security audits.
    Designed to run directly on ESXi host shell.
    """

    PLATFORM = "esxi"
    PLATFORM_NAME = "VMware ESXi"

    def __init__(self, **kwargs):
        """Initialize ESXi agent"""
        super().__init__(**kwargs)

        # ESXi-specific paths
        self.config_path_esx = Path("/etc/vmware")
        self.vpxa_config = self.config_path_esx / "vpxa" / "vpxa.cfg"
        self.hostd_config = self.config_path_esx / "hostd" / "config.xml"

        # Check tool availability
        self.esxcli_available = self._check_esxcli()
        self.vimcmd_available = self._check_vimcmd()

    def _check_esxcli(self) -> bool:
        """Check if esxcli is available"""
        try:
            result = subprocess.run(['esxcli', '--version'], capture_output=True)
            return result.returncode == 0
        except FileNotFoundError:
            return False

    def _check_vimcmd(self) -> bool:
        """Check if vim-cmd is available"""
        try:
            result = subprocess.run(['vim-cmd', 'hostsvc/hostsummary'], capture_output=True)
            return result.returncode == 0
        except FileNotFoundError:
            return False

    def _detect_platform_version(self) -> str:
        """Detect ESXi version"""
        try:
            result = self.run_command(['esxcli', 'system', 'version', 'get'])
            if result.returncode == 0:
                # Parse version from output like "Version: 8.0.0"
                match = re.search(r'Version:\s*(\d+\.\d+(?:\.\d+)?)', result.stdout)
                if match:
                    return match.group(1)
        except Exception as e:
            logger.warning(f"Failed to detect ESXi version: {e}")
        return "unknown"

    def _esxcli(self, *args) -> Optional[str]:
        """Execute esxcli command and return output"""
        try:
            cmd = ['esxcli'] + list(args)
            result = self.run_command(cmd)
            if result.returncode == 0:
                return result.stdout
        except Exception as e:
            logger.debug(f"esxcli {' '.join(args)} failed: {e}")
        return None

    def _esxcli_json(self, *args) -> Optional[Dict]:
        """Execute esxcli command with JSON format"""
        try:
            cmd = ['esxcli', '--formatter=json'] + list(args)
            result = self.run_command(cmd)
            if result.returncode == 0:
                return json.loads(result.stdout)
        except Exception as e:
            logger.debug(f"esxcli json {' '.join(args)} failed: {e}")
        return None

    def _vimcmd(self, *args) -> Optional[str]:
        """Execute vim-cmd command"""
        try:
            cmd = ['vim-cmd'] + list(args)
            result = self.run_command(cmd)
            if result.returncode == 0:
                return result.stdout
        except Exception as e:
            logger.debug(f"vim-cmd {' '.join(args)} failed: {e}")
        return None

    def get_system_info(self) -> Dict[str, Any]:
        """Get ESXi system information for discovery"""
        info = {
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": self.platform_version,
            "build": self._get_build_number(),
            "hostname": self._get_hostname(),
            "uuid": self._get_host_uuid(),
            "vcenter_managed": self._is_vcenter_managed(),
            "vms": {"running": 0, "total": 0},
            "vm_inventory": [],
            "datastores": [],
            "networks": [],
            "cpu": {},
            "memory": {}
        }

        # Get VM counts
        vm_list = self._vimcmd('vmsvc/getallvms')
        if vm_list:
            lines = [line for line in vm_list.strip().split('\n') if line and not line.startswith('Vmid')]
            info["vms"]["total"] = len(lines)
            # Count running VMs
            for line in lines:
                parts = line.split()
                if parts:
                    vmid = parts[0]
                    vm_name = parts[1] if len(parts) > 1 else f"vm-{vmid}"
                    power = self._vimcmd('vmsvc/power.getstate', vmid)
                    power_state = 'powered_off'
                    if power and 'Powered on' in power:
                        info["vms"]["running"] += 1
                        power_state = 'powered_on'
                    info["vm_inventory"].append({
                        "id": vmid,
                        "name": vm_name,
                        "power_state": power_state,
                    })

        # Datastore info
        datastores = self._esxcli_json('storage', 'filesystem', 'list')
        if datastores:
            info["datastores"] = [
                {"name": ds.get('VolumeName'), "type": ds.get('Type'), "size_gb": ds.get('Size', 0) // (1024**3)}
                for ds in datastores if ds.get('VolumeName')
            ]

        # Network info
        nics = self._esxcli_json('network', 'nic', 'list')
        if nics:
            info["networks"] = [
                {"name": n.get('Name'), "driver": n.get('Driver'), "link": n.get('Link')}
                for n in nics
            ]

        # Hardware
        info["cpu"] = self._get_cpu_info()
        info["memory"] = self._get_memory_info()

        return info

    def _get_build_number(self) -> str:
        """Get ESXi build number"""
        output = self._esxcli('system', 'version', 'get')
        if output:
            match = re.search(r'Build:\s*(\S+)', output)
            if match:
                return match.group(1)
        return "unknown"

    def _get_hostname(self) -> str:
        """Get ESXi hostname"""
        output = self._esxcli('system', 'hostname', 'get')
        if output:
            match = re.search(r'Fully Qualified Domain Name:\s*(\S+)', output)
            if match:
                return match.group(1)
        return "unknown"

    def _get_host_uuid(self) -> str:
        """Get host UUID"""
        output = self._esxcli('system', 'uuid', 'get')
        return output.strip() if output else "unknown"

    def _is_vcenter_managed(self) -> bool:
        """Check if host is managed by vCenter"""
        return self.vpxa_config.exists()

    def _get_cpu_info(self) -> Dict:
        """Get CPU information"""
        info = {"cores": 0, "packages": 0, "model": ""}
        output = self._esxcli('hardware', 'cpu', 'global', 'get')
        if output:
            packages = re.search(r'CPU Packages:\s*(\d+)', output)
            cores = re.search(r'CPU Cores:\s*(\d+)', output)
            if packages:
                info["packages"] = int(packages.group(1))
            if cores:
                info["cores"] = int(cores.group(1))
        return info

    def _get_memory_info(self) -> Dict:
        """Get memory information"""
        info = {"total_mb": 0}
        output = self._esxcli('hardware', 'memory', 'get')
        if output:
            match = re.search(r'Physical Memory:\s*(\d+)', output)
            if match:
                info["total_mb"] = int(match.group(1)) // (1024 * 1024)
        return info

    # =========================================================================
    # Audit Implementation
    # =========================================================================

    def run_audit(self, categories: List[str] = None) -> AuditResults:
        """
        Run ESXi security audit.

        Categories:
        - security: SSH, lockdown, passwords, certificates
        - network: Firewall, port groups, vSwitches
        - storage: Datastore security, NFS/iSCSI settings
        - compute: VM settings, resource limits
        """
        results = AuditResults(
            platform=self.PLATFORM,
            platform_version=self.platform_version,
            agent_id=self.agent_id
        )

        all_categories = ['security', 'network', 'storage', 'compute']
        run_categories = categories or all_categories

        if 'security' in run_categories:
            self._audit_security(results)

        if 'network' in run_categories:
            self._audit_network(results)

        if 'storage' in run_categories:
            self._audit_storage(results)

        if 'compute' in run_categories:
            self._audit_compute(results)

        results.finalize()
        results.print_summary()
        return results

    def _audit_security(self, results: AuditResults):
        """Security configuration audits"""
        results.section("Security Configuration")

        # SSH Service Status
        # Query SSH settings (suppress warning checked but not used directly)
        self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/UserVars/SuppressShellWarning')
        ssh_running = self._esxcli('system', 'ssh', 'get')

        if ssh_running and 'Running: true' in ssh_running:
            results.register(
                "SSH Service",
                "WARN",
                "SSH is enabled - should be disabled when not in use",
                category="security",
                severity="medium",
                remediation="esxcli system ssh set --enable=false",
                compliance=["CIS ESXi 7.0 Benchmark 2.1"]
            )
        else:
            results.register("SSH Service", "PASS", "SSH is disabled", category="security")

        # Lockdown Mode
        lockdown_output = self._vimcmd('hostsvc/hostsummary')
        lockdown_enabled = lockdown_output and 'lockdownMode = "lockdownNormal"' in lockdown_output

        if lockdown_enabled:
            results.register("Lockdown Mode", "PASS", "Lockdown mode is enabled", category="security")
        else:
            results.register(
                "Lockdown Mode",
                "WARN",
                "Lockdown mode is disabled",
                category="security",
                severity="medium",
                remediation="Enable via vSphere Client or vim-cmd hostsvc/enable_lockdown",
                compliance=["CIS ESXi 7.0 Benchmark 1.1"]
            )

        # Password Complexity
        password_policy = self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/Security/PasswordQualityControl')
        if password_policy:
            # Check for reasonable complexity
            if 'retry=3 min=disabled,disabled,disabled,7,7' in password_policy:
                results.register(
                    "Password Complexity",
                    "WARN",
                    "Password policy is at default - consider strengthening",
                    category="security",
                    severity="low"
                )
            else:
                results.register("Password Complexity", "PASS", "Custom password policy configured", category="security")
        else:
            results.register("Password Complexity", "SKIP", "Could not check password policy", category="security")

        # DCUI Access
        dcui_timeout = self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/UserVars/DcuiTimeOut')
        if dcui_timeout:
            match = re.search(r'Int Value:\s*(\d+)', dcui_timeout)
            timeout_val = int(match.group(1)) if match else 0
            if timeout_val > 0 and timeout_val <= 600:
                results.register("DCUI Timeout", "PASS", f"DCUI timeout set to {timeout_val}s", category="security")
            else:
                results.register(
                    "DCUI Timeout",
                    "WARN",
                    "DCUI timeout not configured or too long",
                    category="security",
                    severity="low",
                    remediation="esxcli system settings advanced set -o /UserVars/DcuiTimeOut -i 600"
                )

        # Shell Timeout
        shell_timeout = self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/UserVars/ESXiShellTimeOut')
        if shell_timeout:
            match = re.search(r'Int Value:\s*(\d+)', shell_timeout)
            timeout_val = int(match.group(1)) if match else 0
            if timeout_val > 0 and timeout_val <= 900:
                results.register("Shell Timeout", "PASS", f"Shell timeout set to {timeout_val}s", category="security")
            else:
                results.register(
                    "Shell Timeout",
                    "WARN",
                    "Shell timeout not configured",
                    category="security",
                    severity="medium",
                    remediation="esxcli system settings advanced set -o /UserVars/ESXiShellTimeOut -i 900",
                    compliance=["CIS ESXi 7.0 Benchmark 2.2"]
                )

        # Syslog Configuration
        syslog = self._esxcli('system', 'syslog', 'config', 'get')
        if syslog and 'Remote Host:' in syslog:
            match = re.search(r'Remote Host:\s*(\S+)', syslog)
            remote_host = match.group(1) if match else ""
            if remote_host and remote_host != "":
                results.register("Syslog Remote", "PASS", f"Syslog forwarding configured to {remote_host}", category="security")
            else:
                results.register(
                    "Syslog Remote",
                    "WARN",
                    "Remote syslog not configured",
                    category="security",
                    severity="medium",
                    remediation="esxcli system syslog config set --loghost=<syslog_server>",
                    compliance=["CIS ESXi 7.0 Benchmark 3.1"]
                )

        # NTP Configuration
        ntp_output = self._esxcli('system', 'ntp', 'get')
        if ntp_output and 'Enabled: true' in ntp_output:
            results.register("NTP Service", "PASS", "NTP is enabled", category="security")
        else:
            results.register(
                "NTP Service",
                "WARN",
                "NTP is not enabled",
                category="security",
                severity="medium",
                remediation="esxcli system ntp set --enabled=true --server=<ntp_server>",
                compliance=["CIS ESXi 7.0 Benchmark 3.2"]
            )

    def _audit_network(self, results: AuditResults):
        """Network configuration audits"""
        results.section("Network Configuration")

        # Firewall Status
        firewall = self._esxcli('network', 'firewall', 'get')
        if firewall and 'Enabled: true' in firewall:
            results.register("Firewall", "PASS", "Firewall is enabled", category="network")
        else:
            results.register(
                "Firewall",
                "FAIL",
                "Firewall is disabled",
                category="network",
                severity="high",
                remediation="esxcli network firewall set --enabled=true",
                compliance=["CIS ESXi 7.0 Benchmark 4.1"]
            )

        # Check for promiscuous mode on port groups
        vswitch_output = self._esxcli('network', 'vswitch', 'standard', 'list')
        if vswitch_output:
            # This is a simplified check - in production, check each portgroup
            results.register("vSwitch Config", "PASS", "Standard vSwitch(es) configured", category="network")

        # Check for forged transmits
        portgroups = self._esxcli('network', 'vswitch', 'standard', 'portgroup', 'list')
        if portgroups:
            # Check policies
            policy_output = self._esxcli('network', 'vswitch', 'standard', 'portgroup', 'policy', 'security', 'list')
            if policy_output:
                # Check for promiscuous mode enabled
                if 'Allow Promiscuous: true' in policy_output:
                    results.register(
                        "Promiscuous Mode",
                        "WARN",
                        "Promiscuous mode enabled on some port groups",
                        category="network",
                        severity="medium",
                        compliance=["CIS ESXi 7.0 Benchmark 4.2"]
                    )
                else:
                    results.register("Promiscuous Mode", "PASS", "Promiscuous mode disabled on all port groups", category="network")

                # Check for forged transmits
                if 'Forged Transmits: true' in policy_output:
                    results.register(
                        "Forged Transmits",
                        "WARN",
                        "Forged transmits allowed on some port groups",
                        category="network",
                        severity="medium",
                        compliance=["CIS ESXi 7.0 Benchmark 4.3"]
                    )
                else:
                    results.register("Forged Transmits", "PASS", "Forged transmits rejected", category="network")

                # Check for MAC changes
                if 'MAC Address Changes: true' in policy_output:
                    results.register(
                        "MAC Changes",
                        "WARN",
                        "MAC address changes allowed on some port groups",
                        category="network",
                        severity="medium",
                        compliance=["CIS ESXi 7.0 Benchmark 4.4"]
                    )
                else:
                    results.register("MAC Changes", "PASS", "MAC address changes rejected", category="network")

        # VMkernel interfaces
        vmk_list = self._esxcli('network', 'ip', 'interface', 'list')
        if vmk_list:
            results.register("VMkernel Interfaces", "PASS", "VMkernel interfaces configured", category="network")

    def _audit_storage(self, results: AuditResults):
        """Storage configuration audits"""
        results.section("Storage Configuration")

        # VMFS datastores
        datastores = self._esxcli_json('storage', 'filesystem', 'list')
        if datastores:
            vmfs_stores = [d for d in datastores if d.get('Type') == 'VMFS']
            results.register("VMFS Datastores", "PASS", f"{len(vmfs_stores)} VMFS datastore(s) found", category="storage")

            # Check for NFS datastores and their security
            nfs_stores = [d for d in datastores if d.get('Type') == 'NFS']
            if nfs_stores:
                results.register(
                    "NFS Datastores",
                    "WARN",
                    f"{len(nfs_stores)} NFS datastore(s) - verify Kerberos/secure mount options",
                    category="storage",
                    severity="low"
                )

        # iSCSI configuration
        iscsi_adapters = self._esxcli('iscsi', 'adapter', 'list')
        if iscsi_adapters and 'vmhba' in iscsi_adapters:
            # Check CHAP authentication
            results.register(
                "iSCSI",
                "WARN",
                "iSCSI adapters found - verify CHAP authentication is enabled",
                category="storage",
                severity="medium",
                compliance=["CIS ESXi 7.0 Benchmark 5.1"]
            )

        # Scratch partition
        scratch = self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/ScratchConfig/CurrentScratchLocation')
        if scratch:
            match = re.search(r'String Value:\s*(\S+)', scratch)
            scratch_loc = match.group(1) if match else ""
            if scratch_loc and '/tmp' not in scratch_loc:  # nosec B108 - literal policy check, not temp-file creation
                results.register("Scratch Partition", "PASS", f"Persistent scratch: {scratch_loc}", category="storage")
            else:
                results.register(
                    "Scratch Partition",
                    "WARN",
                    "Scratch location in /tmp - should be on persistent storage",
                    category="storage",
                    severity="low"
                )

    def _audit_compute(self, results: AuditResults):
        """Compute/VM configuration audits"""
        results.section("Compute Configuration")

        # BIOS boot option
        # Query boot settings (validates accessibility)
        self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/Misc/BlueScreenTimeout')
        results.register("Host Boot Settings", "PASS", "Host boot configuration accessible", category="compute")

        # Get VM list and check each
        vm_list = self._vimcmd('vmsvc/getallvms')
        if vm_list:
            lines = [line for line in vm_list.strip().split('\n') if line and not line.startswith('Vmid')]
            total_vms = len(lines)
            results.register("VM Inventory", "PASS", f"{total_vms} VM(s) registered", category="compute")

            # Sample first few VMs for security settings
            checked = 0
            issues = []
            for line in lines[:5]:  # Check first 5 VMs
                parts = line.split()
                if parts:
                    vmid = parts[0]
                    # Get VM config
                    vm_config = self._vimcmd('vmsvc/get.config', vmid)
                    if vm_config:
                        # Check for copy/paste disabled
                        if 'isolation.tools.copy.disable' not in str(vm_config):
                            issues.append(f"VM {vmid}: copy/paste not explicitly disabled")
                    checked += 1

            if issues:
                results.register(
                    "VM Isolation",
                    "WARN",
                    f"Checked {checked} VMs - some may need isolation hardening",
                    category="compute",
                    severity="low",
                    compliance=["CIS ESXi 7.0 Benchmark 6.1"]
                )
            else:
                results.register("VM Isolation", "PASS", f"Checked {checked} VMs - isolation settings OK", category="compute")

        # Host services
        # Query shell timeout setting (validates accessibility)
        self._esxcli('system', 'settings', 'advanced', 'list', '-o', '/UserVars/ESXiShellInteractiveTimeOut')
        results.register("Host Services", "PASS", "Host services accessible", category="compute")


# =============================================================================
# Main Entry Point (for standalone execution)
# =============================================================================

def main():
    """Main entry point for standalone execution"""
    import argparse

    parser = argparse.ArgumentParser(description="ESXi Security Audit Agent")
    parser.add_argument('--server', help='Central server URL')
    parser.add_argument('--api-key', help='API key for authentication')
    parser.add_argument('--categories', nargs='+', help='Categories to audit')
    parser.add_argument('--output', '-o', help='Output file for results (JSON)')
    parser.add_argument('--register', action='store_true', help='Register agent with server')

    args = parser.parse_args()

    agent = ESXiAgent(
        server_url=args.server,
        api_key=args.api_key
    )

    print("ESXi Agent v1.0.0")
    print(f"Platform: {agent.PLATFORM_NAME}")
    print(f"Version: {agent.platform_version}")
    print(f"Agent ID: {agent.agent_id}")
    print()

    if args.register and agent.api:
        print("Registering with server...")
        agent.register()

    # Run audit
    results = agent.run_audit(categories=args.categories)

    # Output results
    if args.output:
        with open(args.output, 'w') as f:
            f.write(results.to_json())
        print(f"\nResults written to {args.output}")

    # Submit to server if connected
    if agent.api and agent.registered:
        agent.submit_results(results)


if __name__ == '__main__':
    main()
