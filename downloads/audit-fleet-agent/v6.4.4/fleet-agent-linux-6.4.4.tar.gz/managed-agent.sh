#!/usr/bin/env bash
# =============================================================================
# Managed Security Audit Agent - Linux
# =============================================================================
# Enhanced agent with two-way API communication:
# - Remote configuration from central server
# - Automatic audit script synchronization
# - Database-compatible result submission
# - Full integration with reporting system
#
# Author: Security Audit Toolkit Team
# Date: May 5, 2026
# Version: 6.2.1
# =============================================================================

set -euo pipefail

# =============================================================================
# Configuration
# =============================================================================
AGENT_VERSION="6.2.1"
AGENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${AGENT_DIR}/agent.config.json"
RESULTS_DIR="${AGENT_DIR}/results"
AUDITS_DIR="${AGENT_DIR}/audits"
LIB_DIR="${AGENT_DIR}/lib"
CACHE_DIR="${AGENT_DIR}/.cache"
# shellcheck disable=SC2034  # Reserved for future audit checksum caching
CHECKSUMS_FILE="${CACHE_DIR}/audit_checksums.json"

# Server connection settings (from config or environment)
SERVER_URL="${AUDIT_SERVER_URL:-}"
API_KEY="${AUDIT_API_KEY:-}"
AGENT_ID="${AUDIT_AGENT_ID:-}"

# Polling settings
POLL_INTERVAL="${AUDIT_POLL_INTERVAL:-60}"
HEARTBEAT_TIMEOUT="${AUDIT_HEARTBEAT_TIMEOUT:-30}"
MAX_HEARTBEAT_FAILURES="${AUDIT_MAX_HEARTBEAT_FAILURES:-3}"
AGENT_MAX_LOCAL_RESULT_FILES="${AUDIT_AGENT_MAX_LOCAL_RESULT_FILES:-1000}"
CONSECUTIVE_HEARTBEAT_FAILURES=0
LAST_HEARTBEAT_STATUS="unknown"
LAST_HEARTBEAT_REASON=""
CONFIG_VERSION=0

# Throttling defaults
CPU_NICE="${AUDIT_CPU_NICE:-19}"
# shellcheck disable=SC2034  # Reserved for ionice integration
IO_CLASS="${AUDIT_IO_CLASS:-idle}"
MIN_FREE_MEMORY_PCT="${AUDIT_MIN_FREE_MEMORY_PCT:-10}"
MAX_CPU_PCT="${AUDIT_MAX_CPU_PCT:-0}"
MIN_FREE_DISK_MB="${AUDIT_MIN_FREE_DISK_MB:-512}"
MIN_FREE_DISK_PCT="${AUDIT_MIN_FREE_DISK_PCT:-3}"

# Privilege Escalation Configuration
# AUDIT_ELEVATION_MODE controls per-audit elevation behavior:
#   auto (default): elevate only for audits marked @elevation: root|partial
#   on: elevate whenever possible for all audits
#   off: never elevate (run as current user)
ELEVATION_MODE="${AUDIT_ELEVATION_MODE:-auto}"
# Legacy compatibility flag: AUDIT_USE_SUDO=true maps to ELEVATION_MODE=on
USE_SUDO="${AUDIT_USE_SUDO:-false}"
SUDO_TIMEOUT=300  # Max seconds for sudo commands

# Discovery Configuration
# Auto-discovery runs on startup and at intervals to support Asset Discovery
AUTO_DISCOVERY="${AUDIT_AUTO_DISCOVERY:-true}"
DISCOVERY_INTERVAL="${AUDIT_DISCOVERY_INTERVAL:-3600}"  # 1 hour default
LAST_DISCOVERY=0

# Asset Discovery Integration
ASSET_DISCOVERY_URL="${ASSET_DISCOVERY_URL:-}"  # Optional separate URL

# Secure credential storage
SECURE_CRED_FILE="${AGENT_DIR}/.credentials.enc"

# TLS Security Options
TLS_SKIP_VERIFY="${AUDIT_TLS_SKIP_VERIFY:-false}"
TLS_PINNING_ENABLED="${AUDIT_TLS_PINNING_ENABLED:-false}"
TLS_PINNED_CERT_HASH="${AUDIT_TLS_PINNED_CERT_HASH:-}"
AGENT_ENVIRONMENT="${AUDIT_ENVIRONMENT:-production}"
ALLOW_INSECURE_TLS_IN_NONPROD="${AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD:-false}"
MANAGED_REQUIRE_HTTPS="${AUDIT_MANAGED_REQUIRE_HTTPS:-false}"
MANAGED_ALLOW_PRIVATE_HOSTS="${AUDIT_MANAGED_ALLOW_PRIVATE_HOSTS:-true}"
MANAGED_ALLOWED_SERVER_DOMAINS="${AUDIT_MANAGED_ALLOWED_SERVER_DOMAINS:-}"
MANAGED_BLOCKED_SERVER_KEYWORDS="${AUDIT_MANAGED_BLOCKED_SERVER_KEYWORDS:-wazuh,splunk,elastic,datadog,newrelic}"
MANAGED_ENFORCE_SIGNED_CONFIG="${AUDIT_MANAGED_ENFORCE_SIGNED_CONFIG:-true}"
MANAGED_CONFIG_SIGNING_KEY="${AUDIT_MANAGED_CONFIG_SIGNING_KEY:-}"
MANAGED_CONFIG_SIGNING_USE_ECDSA="${AUDIT_MANAGED_CONFIG_SIGNING_USE_ECDSA:-false}"
MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE="${AUDIT_MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE:-}"
MANAGED_CONFIG_MAX_AGE_SECONDS="${AUDIT_MANAGED_CONFIG_MAX_AGE_SECONDS:-900}"
CONFIG_ENVELOPE_STATE_FILE="${CACHE_DIR}/config_envelope_state.json"

# Request Signature Configuration (Phase 3 hardening)
MANAGED_REQUIRE_REQUEST_SIGNATURES="${AUDIT_MANAGED_REQUIRE_REQUEST_SIGNATURES:-false}"
MANAGED_REQUEST_SIGNING_KEY="${AUDIT_MANAGED_REQUEST_SIGNING_KEY:-}"
MANAGED_REQUEST_SIGNATURE_USE_ECDSA="${AUDIT_MANAGED_REQUEST_SIGNATURE_USE_ECDSA:-false}"
MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE="${AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE:-}"

is_non_production_environment() {
    case "${AGENT_ENVIRONMENT,,}" in
        dev|development|test|testing|beta|staging)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

to_lower() {
    echo "$1" | tr '[:upper:]' '[:lower:]'
}

extract_url_parts() {
    local url="$1"
    local scheme host

    scheme=$(echo "$url" | sed -E 's|^([a-zA-Z][a-zA-Z0-9+.-]*)://.*|\1|')
    host=$(echo "$url" | sed -E 's|^[a-zA-Z][a-zA-Z0-9+.-]*://([^/:]+).*|\1|')

    if [[ -z "$scheme" || -z "$host" || "$scheme" == "$url" || "$host" == "$url" ]]; then
        return 1
    fi

    echo "$(to_lower "$scheme")|$(to_lower "$host")"
}

is_private_or_local_host() {
    local host="$1"

    [[ -z "$host" ]] && return 0
    [[ "$host" == "localhost" || "$host" == "127.0.0.1" || "$host" == "::1" ]] && return 0

    if [[ "$host" =~ ^10\. ]] || [[ "$host" =~ ^192\.168\. ]]; then
        return 0
    fi

    if [[ "$host" =~ ^172\.([1][6-9]|2[0-9]|3[0-1])\. ]]; then
        return 0
    fi

    return 1
}

host_matches_allowed_domains() {
    local host="$1"
    local allowed_csv="$2"

    [[ -z "$allowed_csv" ]] && return 0

    local IFS=','
    local domain
    for domain in $allowed_csv; do
        domain=$(to_lower "${domain//[[:space:]]/}")
        [[ -z "$domain" ]] && continue
        if [[ "$host" == "$domain" || "$host" == *".$domain" ]]; then
            return 0
        fi
    done

    return 1
}

validate_server_url() {
    local url="$1"

    if [[ -z "$url" ]]; then
        log_error "Server URL validation failed: URL is empty"
        return 1
    fi

    local parsed scheme host
    parsed=$(extract_url_parts "$url") || {
        log_error "Server URL validation failed: invalid URL format"
        return 1
    }

    scheme="${parsed%%|*}"
    host="${parsed##*|}"

    if [[ "$MANAGED_REQUIRE_HTTPS" == "true" && "$scheme" != "https" ]]; then
        log_error "Server URL validation failed: HTTPS is required"
        return 1
    fi

    local blocked
    local IFS=','
    for blocked in $MANAGED_BLOCKED_SERVER_KEYWORDS; do
        blocked=$(to_lower "${blocked//[[:space:]]/}")
        [[ -z "$blocked" ]] && continue
        if [[ "$host" == *"$blocked"* ]]; then
            log_error "Server URL validation failed: blocked destination keyword '$blocked'"
            return 1
        fi
    done

    if [[ "$MANAGED_ALLOW_PRIVATE_HOSTS" != "true" ]] && is_private_or_local_host "$host"; then
        log_error "Server URL validation failed: private/localhost destinations are not allowed"
        return 1
    fi

    if ! host_matches_allowed_domains "$host" "$MANAGED_ALLOWED_SERVER_DOMAINS"; then
        log_error "Server URL validation failed: destination not in allowed domains"
        return 1
    fi

    return 0
}

# =============================================================================
# Secure Credential Storage (OpenSSL)
# =============================================================================

# Generate machine-specific encryption key from hardware identifiers
_get_machine_key() {
    # Combine multiple system identifiers for machine-specific key derivation
    local machine_id=""

    # Try /etc/machine-id first (systemd)
    if [[ -f /etc/machine-id ]]; then
        machine_id=$(cat /etc/machine-id)
    # Fall back to DMI product UUID
    elif [[ -f /sys/class/dmi/id/product_uuid ]] && [[ -r /sys/class/dmi/id/product_uuid ]]; then
        machine_id=$(cat /sys/class/dmi/id/product_uuid 2>/dev/null || echo "")
    fi

    # Add hostname for additional uniqueness
    local hostname
    hostname=$(hostname 2>/dev/null || echo "localhost")

    # Generate key from machine ID + hostname using SHA256
    echo -n "${machine_id}${hostname}audit-agent-key" | sha256sum | cut -d' ' -f1
}

# Encrypt API key using OpenSSL AES-256-CBC
protect_api_key() {
    local plaintext="$1"

    if [[ -z "$plaintext" ]]; then
        return 1
    fi

    if ! command -v openssl >/dev/null 2>&1; then
        log_warn "OpenSSL not available - cannot encrypt API key"
        return 1
    fi

    local key
    key=$(_get_machine_key)

    # Encrypt using AES-256-CBC with PBKDF2 key derivation
    echo -n "$plaintext" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -pass "pass:${key}" -base64 2>/dev/null
}

# Decrypt API key
unprotect_api_key() {
    local encrypted="$1"

    if [[ -z "$encrypted" ]]; then
        return 1
    fi

    if ! command -v openssl >/dev/null 2>&1; then
        log_warn "OpenSSL not available - cannot decrypt API key"
        return 1
    fi

    local key
    key=$(_get_machine_key)

    echo -n "$encrypted" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -pass "pass:${key}" -base64 -d 2>/dev/null
}

# Save API key securely
save_secure_credentials() {
    if [[ -z "$API_KEY" ]]; then
        return 0
    fi

    local encrypted
    encrypted=$(protect_api_key "$API_KEY")

    if [[ -n "$encrypted" ]]; then
        echo "$encrypted" > "$SECURE_CRED_FILE"
        chmod 600 "$SECURE_CRED_FILE"
        log_debug "API key encrypted and saved securely"
        return 0
    else
        log_warn "Failed to encrypt API key"
        return 1
    fi
}

# Load API key from secure storage
load_secure_credentials() {
    if [[ -f "$SECURE_CRED_FILE" ]]; then
        local encrypted decrypted
        encrypted=$(cat "$SECURE_CRED_FILE" 2>/dev/null)

        if [[ -n "$encrypted" ]]; then
            decrypted=$(unprotect_api_key "$encrypted")
            if [[ -n "$decrypted" ]]; then
                API_KEY="$decrypted"
                log_debug "Loaded API key from secure storage"
                return 0
            else
                log_warn "Failed to decrypt API key - may be corrupted or encrypted on different machine"
            fi
        fi
    fi
    return 1
}

# =============================================================================
# Results Encryption (Phase 2 Hardening)
# =============================================================================

# Feature flag for result encryption (default ON)
RESULTS_ENCRYPT_ENABLED="${AUDIT_MANAGED_ENCRYPT_RESULTS:-true}"

# Encrypt result JSON data for storage at rest
encrypt_result() {
    local plaintext="$1"

    if [[ "$RESULTS_ENCRYPT_ENABLED" != "true" ]]; then
        echo "$plaintext"
        return 0
    fi

    if [[ -z "$plaintext" ]]; then
        return 1
    fi

    if ! command -v openssl >/dev/null 2>&1; then
        log_warn "OpenSSL not available - storing result unencrypted"
        echo "$plaintext"
        return 0
    fi

    local key
    key=$(_get_machine_key)

    # Encrypt using AES-256-CBC with PBKDF2 key derivation
    local encrypted
    encrypted=$(echo -n "$plaintext" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -pass "pass:${key}" -base64 2>/dev/null)

    if [[ -n "$encrypted" ]]; then
        # Prepend marker so we know this is encrypted
        echo "ENC:${encrypted}"
    else
        log_warn "Encryption failed - storing result unencrypted"
        echo "$plaintext"
    fi
}

# Decrypt result data
decrypt_result() {
    local content="$1"

    if [[ -z "$content" ]]; then
        return 1
    fi

    # Check if content is encrypted (has ENC: prefix)
    if [[ "$content" != ENC:* ]]; then
        # Not encrypted, return as-is (supports legacy unencrypted files)
        echo "$content"
        return 0
    fi

    if ! command -v openssl >/dev/null 2>&1; then
        log_error "OpenSSL not available - cannot decrypt result"
        return 1
    fi

    local key encrypted
    key=$(_get_machine_key)
    encrypted="${content#ENC:}"

    local decrypted
    decrypted=$(echo -n "$encrypted" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -pass "pass:${key}" -base64 -d 2>/dev/null)

    if [[ -n "$decrypted" ]]; then
        echo "$decrypted"
        return 0
    else
        log_error "Failed to decrypt result - may be corrupted or encrypted on different machine"
        return 1
    fi
}

# =============================================================================
# TLS Certificate Pinning
# =============================================================================

# Get SHA256 hash of the server's TLS certificate
get_server_cert_hash() {
    local url="$1"

    if [[ -z "$url" ]]; then
        return 1
    fi

    # Extract host and port from URL
    local host port
    host=$(echo "$url" | sed -E 's|https?://([^:/]+).*|\1|')
    port=$(echo "$url" | sed -E 's|.*:([0-9]+).*|\1|')
    [[ -z "$port" || "$port" == "$url" ]] && port=443

    if ! command -v openssl >/dev/null 2>&1; then
        log_warn "OpenSSL not available - cannot verify certificate pinning"
        return 1
    fi

    # Get certificate and compute SHA256 hash
    local cert_hash
    cert_hash=$(echo | openssl s_client -connect "${host}:${port}" -servername "$host" 2>/dev/null | \
                openssl x509 -outform DER 2>/dev/null | \
                openssl dgst -sha256 2>/dev/null | \
                awk '{print $2}')

    if [[ -n "$cert_hash" ]]; then
        echo "$cert_hash"
        return 0
    fi

    return 1
}

# Validate server certificate against pinned hash
test_certificate_pinning() {
    # If pinning not enabled, allow connection
    if [[ "$TLS_PINNING_ENABLED" != "true" ]] || [[ -z "$TLS_PINNED_CERT_HASH" ]]; then
        return 0
    fi

    local server_hash
    server_hash=$(get_server_cert_hash "$SERVER_URL")

    if [[ -z "$server_hash" ]]; then
        log_error "Certificate pinning FAILED: Could not retrieve server certificate"
        return 1
    fi

    # Normalize hashes (lowercase, no colons/dashes)
    local pinned_hash
    pinned_hash=$(echo "$TLS_PINNED_CERT_HASH" | tr '[:upper:]' '[:lower:]' | tr -d ':' | tr -d '-')
    server_hash=$(echo "$server_hash" | tr '[:upper:]' '[:lower:]')

    if [[ "$server_hash" == "$pinned_hash" ]]; then
        log_debug "Certificate pinning verified"
        return 0
    else
        log_error "Certificate pinning FAILED: Hash mismatch"
        log_error "  Expected: $pinned_hash"
        log_error "  Got: $server_hash"
        return 1
    fi
}

# Display server certificate hash for pinning configuration
show_server_cert_hash() {
    if [[ -z "$SERVER_URL" ]]; then
        log_error "SERVER_URL not configured"
        return 1
    fi

    local hash
    hash=$(get_server_cert_hash "$SERVER_URL")

    if [[ -n "$hash" ]]; then
        echo ""
        echo "Server Certificate SHA256 Hash:"
        echo "  $hash"
        echo ""
        echo "To enable certificate pinning, set:"
        echo "  export AUDIT_TLS_PINNED_CERT_HASH=\"$hash\""
        echo "  export AUDIT_TLS_PINNING_ENABLED=\"true\""
        echo ""
        return 0
    fi

    log_error "Failed to retrieve server certificate"
    return 1
}

# =============================================================================
# API Key Rotation
# =============================================================================

# Update the agent's API key (for key rotation)
# Arguments: $1 = new_api_key, $2 = --force (optional)
update_api_key() {
    local new_key="$1"
    local force="${2:-}"

    if [[ -z "$new_key" ]]; then
        log_error "New API key cannot be empty"
        return 1
    fi

    # Validate new key format
    if [[ ${#new_key} -lt 20 ]]; then
        log_warn "New API key appears too short - verify this is correct"
    fi

    if [[ "$force" != "--force" ]]; then
        echo ""
        echo "WARNING: This will replace your current API key."
        echo "The old key will stop working immediately."
        echo ""
        read -rp "Type 'ROTATE' to confirm: " confirm
        if [[ "$confirm" != "ROTATE" ]]; then
            log_info "Key rotation cancelled"
            return 1
        fi
    fi

    # Backup current key info for logging
    local old_key_preview
    if [[ -n "$API_KEY" ]]; then
        old_key_preview="${API_KEY:0:8}..."
    else
        old_key_preview="(none)"
    fi

    # Update the key
    API_KEY="$new_key"

    # Save to secure storage
    save_secure_credentials

    # Update environment variable for current session
    export AUDIT_API_KEY="$new_key"

    local new_key_preview="${new_key:0:8}..."
    log_info "API key rotated successfully"
    log_debug "  Old key: $old_key_preview"
    log_debug "  New key: $new_key_preview"

    # Verify connection with new key
    if [[ -n "$SERVER_URL" ]]; then
        log_info "Verifying connection with new key..."
        if api_request GET "/api/agent/status" >/dev/null 2>&1; then
            log_info "Connection verified with new API key"
        else
            log_warn "Warning: Could not verify connection - check server connectivity"
        fi
    fi

    return 0
}

# Handle automated key rotation from server command
# This is called when server sends a key_rotation command during heartbeat
handle_key_rotation() {
    local cmd_data="$1"

    local agent_id
    agent_id=$(echo "$cmd_data" | jq -r '.agent_id // empty')
    local grace_period_hours
    grace_period_hours=$(echo "$cmd_data" | jq -r '.grace_period_hours // 24')

    if [[ -z "$agent_id" ]]; then
        agent_id="${AGENT_ID:-}"
    fi

    if [[ -z "$agent_id" ]]; then
        log_error "Cannot rotate key: agent_id not available"
        echo '{"success": false, "error": "Agent ID not configured"}'
        return 1
    fi

    log_info "Fetching new API key from server (grace period: ${grace_period_hours}h)"

    # Fetch new key from server (using current key which is still valid during grace period)
    local fetch_response
    fetch_response=$(api_request GET "/api/agent/${agent_id}/fetch-new-key")

    if [[ -z "$fetch_response" ]]; then
        log_error "Failed to fetch new key from server"
        echo '{"success": false, "error": "Failed to fetch new key"}'
        return 1
    fi

    local new_key
    new_key=$(echo "$fetch_response" | jq -r '.new_api_key // empty')

    if [[ -z "$new_key" ]]; then
        local error_msg
        error_msg=$(echo "$fetch_response" | jq -r '.error // "No new key in response"')
        log_error "Server did not return new key: $error_msg"
        echo "{\"success\": false, \"error\": \"$error_msg\"}"
        return 1
    fi

    # Update the key locally (force mode, no confirmation needed for automated rotation)
    API_KEY="$new_key"
    save_secure_credentials
    export AUDIT_API_KEY="$new_key"

    log_info "API key updated locally, confirming with server..."

    # Confirm successful update with server
    local confirm_response
    confirm_response=$(api_request POST "/api/agent/${agent_id}/confirm-key-update" '{}')

    if echo "$confirm_response" | jq -e '.success == true' >/dev/null 2>&1; then
        log_info "Key rotation completed successfully"
        echo '{"success": true, "message": "Key rotated and confirmed"}'
        return 0
    else
        local confirm_error
        confirm_error=$(echo "$confirm_response" | jq -r '.error // "Confirmation failed"')
        log_warn "Key updated but confirmation failed: $confirm_error"
        echo "{\"success\": true, \"message\": \"Key updated, confirmation pending\", \"warning\": \"$confirm_error\"}"
        return 0
    fi
}

# Display information about the current API key
get_key_rotation_status() {
    echo ""
    echo "API Key Rotation Status"
    echo "======================="

    if [[ -z "$API_KEY" ]]; then
        echo "  No API key configured"
        return
    fi

    local key_preview="${API_KEY:0:8}..."
    echo "  Current Key: $key_preview"

    # Check secure storage
    if [[ -f "$SECURE_CRED_FILE" ]]; then
        local file_date
        file_date=$(stat -c %y "$SECURE_CRED_FILE" 2>/dev/null || stat -f %Sm "$SECURE_CRED_FILE" 2>/dev/null)
        echo "  Secure Storage: $SECURE_CRED_FILE"
        echo "  Last Modified: $file_date"
    else
        echo "  Secure Storage: Not configured (key in config file)"
    fi

    echo ""
    echo "To rotate this key:"
    echo "  1. Request new key from server: POST /api/agent/<agent_id>/rotate-key"
    echo "  2. Run: ./fleet-agent.sh rotate-key NEW_KEY_HERE"
    echo ""
}

# =============================================================================
# Utilities
# =============================================================================
log_info() { echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*"; }
log_warn() { echo "[WARN] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2; }
log_error() { echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2; }
log_debug() { [[ "${DEBUG:-0}" == "1" ]] && echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $*"; }

safe_chmod() {
    local mode="$1"
    local target="$2"
    chmod "$mode" "$target" 2>/dev/null || log_warn "Could not set permissions $mode on $target"
}

normalize_hex() {
    echo "$1" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]'
}

compute_config_payload_hash() {
    local config_json="$1"
    echo "$config_json" | jq -cS . 2>/dev/null | sha256sum | awk '{print $1}'
}

compute_config_signature_hmac() {
    local message="$1"
    local key="$2"

    if ! command -v openssl >/dev/null 2>&1; then
        return 1
    fi

    printf '%s' "$message" | openssl dgst -sha256 -hmac "$key" 2>/dev/null | awk '{print $2}'
}

verify_config_signature_ecdsa() {
    local message="$1"
    local signature_b64="$2"
    local pubkey_file="$3"

    if ! command -v openssl >/dev/null 2>&1; then
        log_error "ECDSA config verification: OpenSSL not available"
        return 1
    fi

    if [[ ! -f "$pubkey_file" ]]; then
        log_error "ECDSA config verification: public key file not found: $pubkey_file"
        return 1
    fi

    # Decode base64 signature to binary
    local sig_file
    sig_file=$(mktemp)
    if ! echo "$signature_b64" | base64 -d > "$sig_file" 2>/dev/null; then
        rm -f "$sig_file"
        log_error "ECDSA config verification: failed to decode signature"
        return 1
    fi

    # Verify signature
    if printf '%s' "$message" | openssl dgst -sha256 -verify "$pubkey_file" -signature "$sig_file" >/dev/null 2>&1; then
        rm -f "$sig_file"
        return 0
    else
        rm -f "$sig_file"
        return 1
    fi
}

iso8601_to_epoch() {
    local timestamp="$1"
    date -u -d "$timestamp" +%s 2>/dev/null
}

persist_config_envelope_state() {
    local version="$1"
    local nonce="$2"
    local issued_at="$3"
    local payload_hash="$4"
    local signature="$5"

    local state_json
    state_json=$(jq -n \
        --argjson version "$version" \
        --arg nonce "$nonce" \
        --arg issued_at "$issued_at" \
        --arg payload_hash "$payload_hash" \
        --arg signature "$signature" \
        --arg verified_at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        '{version: $version, nonce: $nonce, issued_at: $issued_at, payload_hash: $payload_hash, signature: $signature, verified_at: $verified_at}')

    echo "$state_json" > "$CONFIG_ENVELOPE_STATE_FILE"
    safe_chmod 600 "$CONFIG_ENVELOPE_STATE_FILE"
}

verify_signed_config_envelope() {
    local response="$1"
    local config_json="$2"

    if [[ "$MANAGED_ENFORCE_SIGNED_CONFIG" != "true" ]]; then
        return 0
    fi

    # Check required credentials based on mode
    if [[ "$MANAGED_CONFIG_SIGNING_USE_ECDSA" == "true" ]]; then
        if [[ -z "$MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE" ]]; then
            log_error "Signed config verification enabled with ECDSA, but AUDIT_MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE is not set"
            return 1
        fi
    else
        if [[ -z "$MANAGED_CONFIG_SIGNING_KEY" ]]; then
            log_error "Signed config verification enabled, but AUDIT_MANAGED_CONFIG_SIGNING_KEY is not set"
            return 1
        fi
    fi

    local signature nonce issued_at declared_hash new_version
    signature=$(echo "$response" | jq -r '.config_signature // .config_envelope.signature // empty')
    nonce=$(echo "$response" | jq -r '.config_nonce // .config_envelope.nonce // empty')
    issued_at=$(echo "$response" | jq -r '.config_issued_at // .config_envelope.issued_at // empty')
    declared_hash=$(echo "$response" | jq -r '.config_payload_sha256 // .config_envelope.payload_sha256 // empty')
    new_version=$(echo "$config_json" | jq -r '.config_version // 0')

    if [[ -z "$signature" || -z "$nonce" || -z "$issued_at" || -z "$declared_hash" ]]; then
        log_error "Signed config verification failed: missing envelope fields (signature/nonce/issued_at/payload hash)"
        return 1
    fi

    if ! [[ "$new_version" =~ ^[0-9]+$ ]]; then
        log_error "Signed config verification failed: invalid config_version '$new_version'"
        return 1
    fi

    local actual_hash normalized_declared_hash normalized_actual_hash
    actual_hash=$(compute_config_payload_hash "$config_json")
    normalized_declared_hash=$(normalize_hex "$declared_hash")
    normalized_actual_hash=$(normalize_hex "$actual_hash")
    if [[ -z "$normalized_actual_hash" || "$normalized_declared_hash" != "$normalized_actual_hash" ]]; then
        log_error "Signed config verification failed: payload hash mismatch"
        return 1
    fi

    local issued_epoch now_epoch age
    issued_epoch=$(iso8601_to_epoch "$issued_at") || {
        log_error "Signed config verification failed: invalid issued_at timestamp '$issued_at'"
        return 1
    }
    now_epoch=$(date -u +%s)
    age=$((now_epoch - issued_epoch))
    if [[ "$age" -lt 0 ]]; then
        log_error "Signed config verification failed: issued_at is in the future"
        return 1
    fi
    if [[ "$age" -gt "$MANAGED_CONFIG_MAX_AGE_SECONDS" ]]; then
        log_error "Signed config verification failed: envelope is stale (${age}s > ${MANAGED_CONFIG_MAX_AGE_SECONDS}s)"
        return 1
    fi

    if [[ -f "$CONFIG_ENVELOPE_STATE_FILE" ]]; then
        local last_nonce last_version
        last_nonce=$(jq -r '.nonce // empty' "$CONFIG_ENVELOPE_STATE_FILE" 2>/dev/null)
        last_version=$(jq -r '.version // 0' "$CONFIG_ENVELOPE_STATE_FILE" 2>/dev/null)

        if [[ -n "$last_nonce" && "$nonce" == "$last_nonce" ]]; then
            log_error "Signed config verification failed: replay detected (nonce reused)"
            return 1
        fi

        if [[ "$last_version" =~ ^[0-9]+$ ]] && [[ "$new_version" -le "$last_version" ]]; then
            log_error "Signed config verification failed: stale/replayed config version ($new_version <= $last_version)"
            return 1
        fi
    fi

    local message computed_signature normalized_signature normalized_computed
    message="${new_version}:${issued_at}:${nonce}:${normalized_actual_hash}"

    # Signature verification: ECDSA or HMAC based on mode and signature format
    local sig_verified=false
    if [[ "$signature" == ecdsa:* ]]; then
        # ECDSA signature detected (ecdsa:<base64>)
        local ecdsa_sig_b64="${signature#ecdsa:}"
        if [[ "$MANAGED_CONFIG_SIGNING_USE_ECDSA" == "true" && -n "$MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE" ]]; then
            if verify_config_signature_ecdsa "$message" "$ecdsa_sig_b64" "$MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_FILE"; then
                sig_verified=true
                log_debug "Config signature verified via ECDSA"
            fi
        else
            log_error "Signed config verification failed: ECDSA signature received but ECDSA mode not enabled"
            return 1
        fi
    else
        # HMAC signature (legacy)
        if [[ -n "$MANAGED_CONFIG_SIGNING_KEY" ]]; then
            computed_signature=$(compute_config_signature_hmac "$message" "$MANAGED_CONFIG_SIGNING_KEY") || {
                log_error "Signed config verification failed: OpenSSL unavailable for HMAC verification"
                return 1
            }
            normalized_signature=$(normalize_hex "$signature")
            normalized_computed=$(normalize_hex "$computed_signature")
            if [[ -n "$normalized_computed" && "$normalized_signature" == "$normalized_computed" ]]; then
                sig_verified=true
                log_debug "Config signature verified via HMAC"
            fi
        else
            log_error "Signed config verification failed: HMAC signature received but HMAC key not configured"
            return 1
        fi
    fi

    if [[ "$sig_verified" != "true" ]]; then
        log_error "Signed config verification failed: signature mismatch"
        return 1
    fi

    persist_config_envelope_state "$new_version" "$nonce" "$issued_at" "$normalized_actual_hash" "$normalized_signature"
    log_info "Signed config envelope verified (version $new_version)"
    return 0
}

# =============================================================================
# Capability Detection (for reduced-privilege mode)
# =============================================================================

# Check if sudo is available for passwordless execution
can_sudo() {
    # Already root
    if [[ $EUID -eq 0 ]]; then
        return 0
    fi

    # Check for sudo command
    if ! command -v sudo &>/dev/null; then
        return 1
    fi

    # Check for passwordless sudo
    if sudo -n true 2>/dev/null; then
        return 0
    fi

    return 1
}

# Detect agent capabilities based on available privileges
detect_capabilities() {
    local caps=()

    # Basic capabilities (always available)
    caps+=("discovery_basic")
    caps+=("audit_unprivileged")
    caps+=("result_upload")
    caps+=("config_sync")

    # Privileged capabilities (require root or sudo)
    if [[ $EUID -eq 0 ]] || can_sudo; then
        caps+=("discovery_full")
        caps+=("audit_privileged")
        caps+=("port_scan_full")
        caps+=("security_audit")
        caps+=("read_shadow")
        caps+=("read_sudoers")
        caps+=("firewall_audit")
    fi

    # Return as JSON array
    printf '%s\n' "${caps[@]}" | jq -R . | jq -s .
}

# Get sudo mode string for reporting
get_sudo_mode() {
    if [[ $EUID -eq 0 ]]; then
        echo "root"
    elif can_sudo; then
        echo "sudo_nopasswd"
    elif command -v sudo &>/dev/null && groups 2>/dev/null | grep -qE '\b(sudo|wheel|admin)\b'; then
        echo "sudo_password"
    else
        echo "none"
    fi
}

# Check if we're in reduced-privilege mode
is_reduced_mode() {
    [[ $EUID -ne 0 ]] && ! can_sudo
}

# Check if we should use sudo
should_use_sudo() {
    local policy="${1:-auto}"

    if [[ "$policy" == "never" || "$policy" == "off" ]]; then
        return 1
    fi

    # If USE_SUDO is explicitly false, don't use sudo
    if [[ "$policy" != "always" && "$USE_SUDO" == "false" && "${ELEVATION_MODE,,}" == "off" ]]; then
        return 1
    fi

    # If we're already root, don't need sudo
    if [[ $EUID -eq 0 ]]; then
        return 1
    fi

    # Check for passwordless sudo
    if can_sudo; then
        return 0
    fi

    return 1
}

_extract_audit_elevation() {
    local script_path="$1"
    local marker
    marker=$(grep -Eim1 '^[[:space:]]*#[[:space:]]*@elevation:[[:space:]]*(none|partial|root|admin)' "$script_path" 2>/dev/null | \
        sed -E 's/^[[:space:]]*#[[:space:]]*@elevation:[[:space:]]*//I' | \
        tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')

    case "$marker" in
        root|admin|partial|none)
            echo "$marker"
            ;;
        *)
            echo "partial"
            ;;
    esac
}

_resolve_elevation_policy() {
    local script_path="$1"
    local mode="${ELEVATION_MODE,,}"
    local level
    level="$(_extract_audit_elevation "$script_path")"

    if [[ "$USE_SUDO" == "true" && "$mode" == "auto" ]]; then
        mode="on"
    fi

    case "$mode" in
        off|disabled|none)
            echo "never|$level"
            ;;
        on|always|force)
            echo "always|$level"
            ;;
        *)
            if [[ "$level" == "none" ]]; then
                echo "never|$level"
            else
                echo "auto|$level"
            fi
            ;;
    esac
}

# Run command with privilege escalation if needed
# Falls back gracefully if sudo not available
run_privileged() {
    local cmd=("$@")

    if should_use_sudo; then
        # Run with sudo, timeout protection
        timeout "$SUDO_TIMEOUT" sudo -n "${cmd[@]}" 2>&1
    else
        # Run directly (may fail for privileged commands, caller should handle)
        "${cmd[@]}" 2>&1
    fi
}

# Try to run privileged, but don't fail - return empty on permission error
run_privileged_or_empty() {
    local cmd=("$@")
    local output

    output=$(run_privileged "${cmd[@]}" 2>&1)
    local rc=$?

    # Check for permission denied errors
    if echo "$output" | grep -qiE 'permission denied|operation not permitted|not permitted'; then
        echo ""
        return 0
    fi

    echo "$output"
    return $rc
}

# Detect if error is elevation-related
_is_elevation_error() {
    local output="$1"
    local lower
    lower=$(echo "$output" | tr '[:upper:]' '[:lower:]')

    # Check for sudo/elevation specific error patterns
    if echo "$lower" | grep -qiE \
        'sudo:|a password is required|not in the sudoers file|operation not permitted|permission denied'; then
        return 0
    fi
    return 1
}

# Run a script with privilege escalation and fallback
is_allowed_elevated_script() {
    local script_path="$1"

    if [[ ! -f "$script_path" ]] || [[ "${script_path##*.}" != "sh" ]]; then
        return 1
    fi

    local script_abs audits_abs
    script_abs="$(cd "$(dirname "$script_path")" && pwd -P)/$(basename "$script_path")"
    audits_abs="$(cd "$AUDITS_DIR" && pwd -P)"

    if [[ "$script_abs" == "$audits_abs/"* ]]; then
        return 0
    fi

    if [[ "$script_abs" == "$AGENT_DIR/fleet-agent.sh" ]]; then
        return 0
    fi

    return 1
}

run_privileged_script() {
    local script_path="$1"
    local policy="${2:-auto}"
    shift
    if [[ "$#" -gt 0 ]]; then
        shift
    fi
    local args=("$@")
    local bash_bin
    bash_bin="$(command -v bash 2> /dev/null || echo /bin/bash)"

    if ! is_allowed_elevated_script "$script_path"; then
        log_warn "Refusing elevated execution for out-of-scope script path: $script_path"
        "$bash_bin" "$script_path" "${args[@]}" 2>&1
        return $?
    fi

    if should_use_sudo "$policy"; then
        # Try elevated first
        local elevated_output
        elevated_output=$(timeout "$SUDO_TIMEOUT" sudo -n "$bash_bin" "$script_path" "${args[@]}" 2>&1)
        local elevated_rc=$?

        # If elevated failed with elevation-related error, retry non-elevated
        if [[ $elevated_rc -ne 0 ]] && _is_elevation_error "$elevated_output"; then
            log_warn "Elevated execution failed; retrying non-elevated"
            local fallback_output
            fallback_output=$("$bash_bin" "$script_path" "${args[@]}" 2>&1)
            local fallback_rc=$?

            # Return combined output for logging
            echo "NOTICE: Elevated execution failed; retried non-elevated."
            echo "--- elevated output ---"
            echo "$elevated_output"
            echo "--- non-elevated output ---"
            echo "$fallback_output"
            return $fallback_rc
        else
            echo "$elevated_output"
            return $elevated_rc
        fi
    else
        # Run directly
        "$bash_bin" "$script_path" "${args[@]}" 2>&1
    fi
}

# Run script from stdin (stream mode) with privilege escalation and fallback
run_privileged_stdin() {
    local script_content="$1"

    if should_use_sudo; then
        # Try elevated first
        local elevated_output
        elevated_output=$(echo "$script_content" | timeout "$SUDO_TIMEOUT" sudo -n bash -s 2>&1)
        local elevated_rc=$?

        # If elevated failed with elevation-related error, retry non-elevated
        if [[ $elevated_rc -ne 0 ]] && _is_elevation_error "$elevated_output"; then
            log_warn "Elevated execution (stdin) failed; retrying non-elevated"
            local fallback_output
            fallback_output=$(echo "$script_content" | bash -s 2>&1)
            local fallback_rc=$?

            # Return combined output for logging
            echo "NOTICE: Elevated execution failed; retried non-elevated."
            echo "--- elevated output ---"
            echo "$elevated_output"
            echo "--- non-elevated output ---"
            echo "$fallback_output"
            return $fallback_rc
        else
            echo "$elevated_output"
            return $elevated_rc
        fi
    else
        # Run directly
        echo "$script_content" | bash -s 2>&1
    fi
}

ensure_dirs() {
    mkdir -p "$RESULTS_DIR" "$AUDITS_DIR" "$LIB_DIR" "$CACHE_DIR"
    safe_chmod 700 "$RESULTS_DIR"
    safe_chmod 700 "$AUDITS_DIR"
    safe_chmod 700 "$LIB_DIR"
    safe_chmod 700 "$CACHE_DIR"
}

# Load configuration from file
load_config() {
    # First, try to load API key from secure storage
    local secure_loaded=false
    if load_secure_credentials; then
        secure_loaded=true
    fi

    if [[ -f "$CONFIG_FILE" ]]; then
        SERVER_URL="${SERVER_URL:-$(jq -r '.server_url // empty' "$CONFIG_FILE" 2>/dev/null)}"
        # Only load API key from config if not already loaded from secure storage
        if [[ "$secure_loaded" != "true" ]]; then
            local config_api_key
            config_api_key=$(jq -r '.api_key // empty' "$CONFIG_FILE" 2>/dev/null)
            if [[ -n "$config_api_key" ]]; then
                API_KEY="$config_api_key"
                # Migrate plaintext key to secure storage
                log_info "Migrating API key to secure storage..."
                save_secure_credentials
            fi
        fi
        AGENT_ID="${AGENT_ID:-$(jq -r '.agent_id // empty' "$CONFIG_FILE" 2>/dev/null)}"
        CONFIG_VERSION=$(jq -r '.config_version // 0' "$CONFIG_FILE" 2>/dev/null)
        AGENT_MAX_LOCAL_RESULT_FILES=$(jq -r '.max_local_result_files // 1000' "$CONFIG_FILE" 2>/dev/null)
        MIN_FREE_DISK_MB=$(jq -r '.min_free_disk_mb // 512' "$CONFIG_FILE" 2>/dev/null)
        MIN_FREE_DISK_PCT=$(jq -r '.min_free_disk_pct // 3' "$CONFIG_FILE" 2>/dev/null)
    fi

    if [[ -n "$SERVER_URL" ]] && ! validate_server_url "$SERVER_URL"; then
        log_error "Configured SERVER_URL is invalid; aborting startup"
        exit 1
    fi

    # Generate agent ID if not set
    if [[ -z "$AGENT_ID" ]]; then
        AGENT_ID=$(hostname | sha256sum | cut -c1-16)
        log_info "Generated agent ID: $AGENT_ID"
    fi
}

# Save configuration to file
save_config() {
    # Save API key to secure storage (encrypted)
    save_secure_credentials

    # Save config WITHOUT the API key (security best practice)
    local config
    config=$(cat <<EOF
{
    "server_url": "$SERVER_URL",
    "agent_id": "$AGENT_ID",
    "config_version": $CONFIG_VERSION,
    "max_local_result_files": $AGENT_MAX_LOCAL_RESULT_FILES,
    "min_free_disk_mb": $MIN_FREE_DISK_MB,
    "min_free_disk_pct": $MIN_FREE_DISK_PCT,
    "credentials_storage": "openssl-aes256",
    "updated_at": "$(date -Iseconds)"
}
EOF
)
    echo "$config" > "$CONFIG_FILE"
    safe_chmod 600 "$CONFIG_FILE"
}

# =============================================================================
# System Information
# =============================================================================
get_hostname() { hostname -f 2>/dev/null || hostname; }

get_os_info() {
    local os_name os_version
    if [[ -f /etc/os-release ]]; then
        os_name=$(grep '^PRETTY_NAME=' /etc/os-release | cut -d'"' -f2)
        os_version=$(grep '^VERSION_ID=' /etc/os-release | cut -d'"' -f2)
    else
        os_name=$(uname -s)
        os_version=$(uname -r)
    fi
    echo "${os_name} ${os_version}"
}

get_architecture() { uname -m; }

get_memory_info() {
    local total_kb free_kb
    total_kb=$(grep '^MemTotal:' /proc/meminfo | awk '{print $2}')
    free_kb=$(grep '^MemAvailable:' /proc/meminfo | awk '{print $2}' 2>/dev/null || \
              grep '^MemFree:' /proc/meminfo | awk '{print $2}')
    local free_pct=$((free_kb * 100 / total_kb))
    echo "{\"total_mb\": $((total_kb/1024)), \"free_mb\": $((free_kb/1024)), \"free_pct\": $free_pct}"
}

get_cpu_usage() {
    # Get CPU usage from /proc/stat
    local idle total
    read -r _ user nice system idle iowait irq softirq _ < /proc/stat
    total=$((user + nice + system + idle + iowait + irq + softirq))
    sleep 0.5
    read -r _ user2 nice2 system2 idle2 iowait2 irq2 softirq2 _ < /proc/stat
    local total2=$((user2 + nice2 + system2 + idle2 + iowait2 + irq2 + softirq2))
    local delta_idle=$((idle2 - idle))
    local delta_total=$((total2 - total))
    local cpu_pct=$((100 * (delta_total - delta_idle) / delta_total))
    echo "$cpu_pct"
}

get_disk_info() {
    local target_path="$1"
    local df_line total_kb avail_kb free_pct mount_point

    mkdir -p "$target_path" 2>/dev/null || true
    df_line=$(df -Pk "$target_path" 2>/dev/null | awk 'NR==2')

    if [[ -z "$df_line" ]]; then
        echo '{"total_mb": 0, "free_mb": 0, "free_pct": 0, "mount": "unknown"}'
        return 1
    fi

    total_kb=$(echo "$df_line" | awk '{print $2}')
    avail_kb=$(echo "$df_line" | awk '{print $4}')
    mount_point=$(echo "$df_line" | awk '{print $6}')
    if [[ "$total_kb" -le 0 ]]; then
        free_pct=0
    else
        free_pct=$((avail_kb * 100 / total_kb))
    fi

    echo "{\"total_mb\": $((total_kb/1024)), \"free_mb\": $((avail_kb/1024)), \"free_pct\": $free_pct, \"mount\": \"$mount_point\"}"
}

has_disk_headroom() {
    local target_path="$1"
    local context="${2:-local storage}"
    local disk_info free_mb free_pct

    disk_info=$(get_disk_info "$target_path") || true
    free_mb=$(echo "$disk_info" | jq -r '.free_mb // 0')
    free_pct=$(echo "$disk_info" | jq -r '.free_pct // 0')

    if [[ "$free_mb" -lt "$MIN_FREE_DISK_MB" || "$free_pct" -lt "$MIN_FREE_DISK_PCT" ]]; then
        log_warn "Low disk space for ${context}: ${free_mb}MB/${free_pct}% free (min: ${MIN_FREE_DISK_MB}MB/${MIN_FREE_DISK_PCT}%)"
        return 1
    fi

    return 0
}

check_resources_available() {
    # Check memory
    local mem_info free_pct
    mem_info=$(get_memory_info)
    free_pct=$(echo "$mem_info" | jq -r '.free_pct')

    if [[ "$free_pct" -lt "$MIN_FREE_MEMORY_PCT" ]]; then
        log_warn "Low memory: ${free_pct}% free (min: ${MIN_FREE_MEMORY_PCT}%)"
        return 1
    fi

    # Check CPU if threshold set
    if [[ "$MAX_CPU_PCT" -gt 0 ]]; then
        local cpu_pct
        cpu_pct=$(get_cpu_usage)
        if [[ "$cpu_pct" -gt "$MAX_CPU_PCT" ]]; then
            log_warn "High CPU: ${cpu_pct}% (max: ${MAX_CPU_PCT}%)"
            return 1
        fi
    fi

    if ! has_disk_headroom "$RESULTS_DIR" "result storage"; then
        return 1
    fi

    return 0
}

# =============================================================================
# API Communication
# =============================================================================
api_request() {
    local method="$1"
    local endpoint="$2"
    local data="${3:-}"

    if [[ -z "$SERVER_URL" ]]; then
        log_error "SERVER_URL not configured"
        return 1
    fi

    if ! validate_server_url "$SERVER_URL"; then
        log_error "API request blocked due to invalid SERVER_URL"
        return 1
    fi

    # Validate certificate pinning if enabled
    if [[ "$TLS_PINNING_ENABLED" == "true" ]]; then
        if ! test_certificate_pinning; then
            log_error "API request blocked: Certificate pinning validation failed"
            return 1
        fi
    fi

    local url="${SERVER_URL}${endpoint}"
    local curl_args=(
        -s -S
        -X "$method"
        -H "Content-Type: application/json"
        -H "X-API-Key: ${API_KEY}"
        -H "X-Agent-ID: ${AGENT_ID}"
        --connect-timeout 30
        --max-time 120
    )

    # Optional insecure TLS bypass for explicit non-production use only.
    if [[ "$TLS_SKIP_VERIFY" == "true" ]]; then
        if [[ "$ALLOW_INSECURE_TLS_IN_NONPROD" == "true" ]] && is_non_production_environment; then
            log_warn "TLS certificate verification bypass enabled for non-production environment: ${AGENT_ENVIRONMENT}"
            curl_args+=(-k)
        else
            log_error "Blocked insecure TLS bypass. Set AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD=true and AUDIT_ENVIRONMENT=dev|test|beta|staging for explicit non-production use."
            return 1
        fi
    fi

    if [[ -n "$data" ]]; then
        curl_args+=(-d "$data")
    fi

    # Phase 3 hardening: Add request signature headers when enabled
    if [[ "${MANAGED_REQUIRE_REQUEST_SIGNATURES,,}" == "true" ]]; then
        local request_path request_timestamp payload_hash signature_message request_signature
        request_path="$endpoint"
        request_timestamp=$(date +%s)
        payload_hash=$(printf '%s' "${data:-}" | sha256sum | awk '{print $1}')
        signature_message="${method^^}:${request_path}:${AGENT_ID}:${request_timestamp}:${payload_hash}"

        if command -v openssl >/dev/null 2>&1; then
            if [[ "${MANAGED_REQUEST_SIGNATURE_USE_ECDSA,,}" == "true" ]]; then
                if [[ -z "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" ]]; then
                    log_error "ECDSA request-signature mode enabled but AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE is not set"
                    return 1
                fi
                if [[ ! -f "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" ]]; then
                    log_error "ECDSA private key file not found: $MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE"
                    return 1
                fi
                request_signature=$(printf '%s' "$signature_message" | openssl dgst -sha256 -sign "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" 2>/dev/null | openssl base64 -A 2>/dev/null)
                request_signature="ecdsa:${request_signature}"
            else
                if [[ -z "$MANAGED_REQUEST_SIGNING_KEY" ]]; then
                    log_error "Managed request-signature enforcement enabled but AUDIT_MANAGED_REQUEST_SIGNING_KEY is not set"
                    return 1
                fi
                request_signature=$(printf '%s' "$signature_message" | openssl dgst -sha256 -hmac "$MANAGED_REQUEST_SIGNING_KEY" 2>/dev/null | awk '{print $2}')
            fi
        else
            log_error "Managed request-signature enforcement requires openssl"
            return 1
        fi

        if [[ -z "$request_signature" ]]; then
            log_error "Failed to compute managed request signature"
            return 1
        fi

        curl_args+=(
            -H "X-Agent-Timestamp: ${request_timestamp}"
            -H "X-Agent-Content-SHA256: ${payload_hash}"
            -H "X-Agent-Signature: ${request_signature}"
        )
    fi

    curl "${curl_args[@]}" "$url"
}

# =============================================================================
# Registration & Heartbeat
# =============================================================================
register_agent() {
    log_info "Registering with server..."

    local hostname os_info arch sudo_mode capabilities
    hostname=$(get_hostname)
    os_info=$(get_os_info)
    arch=$(get_architecture)
    sudo_mode=$(get_sudo_mode)
    capabilities=$(detect_capabilities)

    local payload
    payload=$(cat <<EOF
{
    "hostname": "$hostname",
    "os_name": "$os_info",
    "os_type": "linux",
    "architecture": "$arch",
    "agent_version": "$AGENT_VERSION",
    "sudo_mode": "$sudo_mode",
    "reduced_mode": $(is_reduced_mode && echo "true" || echo "false"),
    "capabilities": $capabilities
}
EOF
)

    local response
    response=$(api_request POST "/api/agent/register" "$payload")

    if echo "$response" | jq -e '.success' >/dev/null 2>&1; then
        local new_agent_id
        new_agent_id=$(echo "$response" | jq -r '.agent_id')
        if [[ -n "$new_agent_id" && "$new_agent_id" != "null" ]]; then
            AGENT_ID="$new_agent_id"
            save_config
            log_info "Registered successfully as: $AGENT_ID"
            log_info "Capabilities: $(echo "$capabilities" | jq -c .)"
            return 0
        fi
    fi

    log_error "Registration failed: $response"
    return 1
}

send_agent_heartbeat() {
    local hostname mem_info cpu_pct payload response failure_reason
    hostname=$(get_hostname)
    mem_info=$(get_memory_info)
    cpu_pct=$(get_cpu_usage)

    payload=$(cat <<EOF
{
    "pending_results": $(count_pending_results),
    "status": "idle",
    "resources": {
        "cpu_usage_pct": $cpu_pct,
        "memory_free_pct": $(echo "$mem_info" | jq -r '.free_pct')
    },
    "request_license": true
}
EOF
)

    if ! response=$(api_request POST "/api/agent/heartbeat" "$payload"); then
        CONSECUTIVE_HEARTBEAT_FAILURES=$((CONSECUTIVE_HEARTBEAT_FAILURES + 1))
        LAST_HEARTBEAT_STATUS="connection_error"
        LAST_HEARTBEAT_REASON="No response from core server"
        log_warn "Heartbeat failed (${CONSECUTIVE_HEARTBEAT_FAILURES}/${MAX_HEARTBEAT_FAILURES}): ${LAST_HEARTBEAT_REASON}"
        return 1
    fi

    if ! echo "$response" | jq -e '.success == true' >/dev/null 2>&1; then
        failure_reason=$(echo "$response" | jq -r '.error // .message // "Invalid heartbeat response"' 2>/dev/null || echo "Invalid heartbeat response")
        CONSECUTIVE_HEARTBEAT_FAILURES=$((CONSECUTIVE_HEARTBEAT_FAILURES + 1))
        LAST_HEARTBEAT_STATUS="rejected"
        LAST_HEARTBEAT_REASON="$failure_reason"
        log_warn "Heartbeat rejected (${CONSECUTIVE_HEARTBEAT_FAILURES}/${MAX_HEARTBEAT_FAILURES}): ${LAST_HEARTBEAT_REASON}"
        return 1
    fi

    CONSECUTIVE_HEARTBEAT_FAILURES=0
    LAST_HEARTBEAT_STATUS="ok"
    LAST_HEARTBEAT_REASON=""
    return 0
}

# Unified poll endpoint for two-way communication
poll_server() {
    if ! send_agent_heartbeat; then
        return 1
    fi

    local hostname mem_info cpu_pct checksums
    hostname=$(get_hostname)
    mem_info=$(get_memory_info)
    cpu_pct=$(get_cpu_usage)

    # Build checksums of local audit files
    checksums=$(build_audit_checksums)

    local payload
    payload=$(cat <<EOF
{
    "agent_id": "$AGENT_ID",
    "hostname": "$hostname",
    "status": "idle",
    "current_config_version": $CONFIG_VERSION,
    "audit_checksums": $checksums,
    "resources": {
        "cpu_pct": $cpu_pct,
        "memory_free_pct": $(echo "$mem_info" | jq -r '.free_pct')
    },
    "pending_results_count": $(count_pending_results)
}
EOF
)

    local response
    response=$(api_request POST "/api/agent/managed/poll" "$payload")

    if ! echo "$response" | jq -e '.success' >/dev/null 2>&1; then
        log_error "Poll failed: $response"
        return 1
    fi

    # Process response
    local commands config_update audit_updates next_poll
    commands=$(echo "$response" | jq -r '.commands // []')
    config_update=$(echo "$response" | jq -r '.config_update_available // false')
    audit_updates=$(echo "$response" | jq -r '.audit_updates // []')
    next_poll=$(echo "$response" | jq -r '.next_poll_seconds // 60')

    POLL_INTERVAL="$next_poll"

    # Handle config update
    if [[ "$config_update" == "true" ]]; then
        log_info "Configuration update available, fetching..."
        fetch_config
    fi

    # Handle audit updates
    local update_count
    update_count=$(echo "$audit_updates" | jq -r 'length')
    if [[ "$update_count" -gt 0 ]]; then
        log_info "Audit updates available: $update_count files"
        sync_audits "$audit_updates"
    fi

    # Process commands
    local cmd_count
    cmd_count=$(echo "$commands" | jq -r 'length')
    if [[ "$cmd_count" -gt 0 ]]; then
        log_info "Processing $cmd_count pending commands"
        process_commands "$commands"
    fi

    return 0
}

# =============================================================================
# Configuration Sync (Server → Agent)
# =============================================================================
fetch_config() {
    local response
    response=$(api_request GET "/api/agent/managed/config/${AGENT_ID}")

    if ! echo "$response" | jq -e '.success' >/dev/null 2>&1; then
        log_error "Failed to fetch config: $response"
        return 1
    fi

    local config
    config=$(echo "$response" | jq '.config')

    if [[ -z "$config" || "$config" == "null" ]]; then
        log_error "Failed to fetch config: response missing config payload"
        return 1
    fi

    if ! verify_signed_config_envelope "$response" "$config"; then
        log_error "Config apply blocked: envelope verification failed"
        return 1
    fi

    # Update local settings from config
    CONFIG_VERSION=$(echo "$config" | jq -r '.config_version // 0')

    local enforce_signed_config config_max_age_seconds
    enforce_signed_config=$(echo "$config" | jq -r '.security.enforce_signed_config // empty')
    config_max_age_seconds=$(echo "$config" | jq -r '.security.config_max_age_seconds // empty')

    if [[ "$enforce_signed_config" == "true" || "$enforce_signed_config" == "false" ]]; then
        MANAGED_ENFORCE_SIGNED_CONFIG="$enforce_signed_config"
    fi

    if [[ "$config_max_age_seconds" =~ ^[0-9]+$ ]] && [[ "$config_max_age_seconds" -ge 30 ]] && [[ "$config_max_age_seconds" -le 86400 ]]; then
        MANAGED_CONFIG_MAX_AGE_SECONDS="$config_max_age_seconds"
    fi

    local max_local_result_files
    max_local_result_files=$(echo "$config" | jq -r '.storage.max_local_result_files // empty')
    if [[ "$max_local_result_files" =~ ^[0-9]+$ ]]; then
        AGENT_MAX_LOCAL_RESULT_FILES="$max_local_result_files"
    fi

    local min_free_disk_mb min_free_disk_pct
    min_free_disk_mb=$(echo "$config" | jq -r '.storage.min_free_disk_mb // empty')
    min_free_disk_pct=$(echo "$config" | jq -r '.storage.min_free_disk_pct // empty')
    if [[ "$min_free_disk_mb" =~ ^[0-9]+$ ]]; then
        MIN_FREE_DISK_MB="$min_free_disk_mb"
    fi
    if [[ "$min_free_disk_pct" =~ ^[0-9]+$ ]]; then
        MIN_FREE_DISK_PCT="$min_free_disk_pct"
    fi

    # Throttle settings
    CPU_NICE=$(echo "$config" | jq -r '.throttle.cpu_priority // "19"' | tr '[:upper:]' '[:lower:]')
    MIN_FREE_MEMORY_PCT=$(echo "$config" | jq -r '.throttle.min_free_memory_pct // 10')
    MAX_CPU_PCT=$(echo "$config" | jq -r '.throttle.max_cpu_pct // 0')

    # Save updated config
    echo "$config" > "${CACHE_DIR}/server_config.json"
    safe_chmod 600 "${CACHE_DIR}/server_config.json"
    save_config

    log_info "Configuration updated to version $CONFIG_VERSION"
    return 0
}

# =============================================================================
# Audit Sync (Server → Agent)
# =============================================================================
build_audit_checksums() {
    local checksums="{}"

    # Walk audit directories and calculate checksums
    if [[ -d "$AUDITS_DIR" ]]; then
        while IFS= read -r -d '' file; do
            local rel_path checksum
            rel_path="${file#"$AGENT_DIR"/}"
            checksum=$(sha256sum "$file" | cut -d' ' -f1)
            checksums=$(echo "$checksums" | jq --arg p "$rel_path" --arg c "$checksum" '. + {($p): $c}')
        done < <(find "$AUDITS_DIR" -name "*.sh" -type f -print0 2>/dev/null)
    fi

    # Include lib files
    if [[ -d "$LIB_DIR" ]]; then
        while IFS= read -r -d '' file; do
            local rel_path checksum
            rel_path="${file#"$AGENT_DIR"/}"
            checksum=$(sha256sum "$file" | cut -d' ' -f1)
            checksums=$(echo "$checksums" | jq --arg p "$rel_path" --arg c "$checksum" '. + {($p): $c}')
        done < <(find "$LIB_DIR" -name "*.sh" -type f -print0 2>/dev/null)
    fi

    echo "$checksums"
}

sync_audits() {
    local updates="$1"

    # Convert to array
    local files
    files=$(echo "$updates" | jq -r '.[]')

    if [[ -z "$files" ]]; then
        return 0
    fi

    # Request specific files from server
    local payload
    payload=$(cat <<EOF
{
    "files": $updates,
    "format": "tar.gz"
}
EOF
)

    local tmp_file="${CACHE_DIR}/audit_sync.tar.gz"

    # Download package
    if curl -s -S \
        -X POST \
        -H "Content-Type: application/json" \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        -d "$payload" \
        -o "$tmp_file" \
        "${SERVER_URL}/api/agent/managed/sync/download"; then

        # Extract to agent directory
        if tar -xzf "$tmp_file" -C "$AGENT_DIR" 2>/dev/null; then
            log_info "Audit sync completed successfully"
            rm -f "$tmp_file"
            # Refresh license token after successful audit sync
            refresh_license_token_if_needed || log_debug "Token refresh skipped"
            return 0
        else
            log_error "Failed to extract audit package"
        fi
    else
        log_error "Failed to download audit updates"
    fi

    rm -f "$tmp_file"
    return 1
}

sync_full_package() {
    log_info "Downloading full audit package..."

    local tmp_file="${CACHE_DIR}/full_package.tar.gz"

    if curl -s -S \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        -o "$tmp_file" \
        "${SERVER_URL}/api/agent/managed/sync/full-package?os_type=linux&include_lib=true"; then

        if tar -xzf "$tmp_file" -C "$AGENT_DIR" 2>/dev/null; then
            log_info "Full package sync completed"
            rm -f "$tmp_file"
            # Fetch license token after successful sync
            fetch_license_token
            return 0
        fi
    fi

    log_error "Full package sync failed"
    rm -f "$tmp_file"
    return 1
}

# =============================================================================
# License Token Management
# =============================================================================
# Fetches a machine-bound license token from the server.
# Token is required for audit scripts to execute (IP protection).
# =============================================================================

_get_machine_fingerprint() {
    # Get stable machine identifier and hash it
    local fingerprint=""

    # Linux - /etc/machine-id
    if [[ -f /etc/machine-id ]]; then
        fingerprint=$(cat /etc/machine-id 2>/dev/null || true)
    elif [[ -f /var/lib/dbus/machine-id ]]; then
        fingerprint=$(cat /var/lib/dbus/machine-id 2>/dev/null || true)
    fi

    # Fallback - hostname + MAC
    if [[ -z "$fingerprint" ]]; then
        local host
        host=$(hostname 2>/dev/null || echo "unknown")
        local iface
        iface=$(ip link 2>/dev/null | grep -oE 'link/ether [0-9a-f:]+' | head -1 | cut -d' ' -f2 || true)
        fingerprint="${host}-${iface:-unknown}"
    fi

    # Hash the fingerprint (SHA256)
    if command -v sha256sum >/dev/null 2>&1; then
        echo -n "$fingerprint" | sha256sum | cut -d' ' -f1
    elif command -v shasum >/dev/null 2>&1; then
        echo -n "$fingerprint" | shasum -a 256 | cut -d' ' -f1
    else
        # Fallback - md5 if sha256 unavailable
        echo -n "$fingerprint" | md5sum | cut -d' ' -f1
    fi
}

fetch_license_token() {
    # Fetch license token from server for audit script execution

    if [[ -z "$SERVER_URL" ]] || [[ -z "$API_KEY" ]]; then
        log_warn "Cannot fetch license token: SERVER_URL or API_KEY not configured"
        return 1
    fi

    local machine_fingerprint
    machine_fingerprint=$(_get_machine_fingerprint)

    log_debug "Fetching license token for machine ${machine_fingerprint:0:16}..."

    local payload
    payload=$(cat <<EOF
{
    "machine_fingerprint": "$machine_fingerprint",
    "days_valid": 7
}
EOF
)

    local response
    response=$(curl -s -S \
        -X POST \
        -H "Content-Type: application/json" \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        -d "$payload" \
        "${SERVER_URL}/api/agent/managed/sync/license-token" 2>/dev/null)

    if [[ -z "$response" ]]; then
        log_error "Failed to fetch license token: empty response"
        return 1
    fi

    # Check success
    local success
    success=$(echo "$response" | jq -r '.success // false' 2>/dev/null || echo "false")

    if [[ "$success" != "true" ]]; then
        local error
        error=$(echo "$response" | jq -r '.error // "unknown error"' 2>/dev/null)
        log_error "License token request failed: $error"
        return 1
    fi

    # Extract and save token
    local token
    token=$(echo "$response" | jq '.token' 2>/dev/null)

    if [[ -z "$token" ]] || [[ "$token" == "null" ]]; then
        log_error "License token response missing token data"
        return 1
    fi

    # Save token to agent directory
    echo "$token" > "${AGENT_DIR}/.license_token"
    chmod 600 "${AGENT_DIR}/.license_token"

    local expires
    expires=$(echo "$token" | jq -r '.expires // "unknown"' 2>/dev/null)
    log_info "License token saved, expires: $expires"

    return 0
}

check_license_token() {
    # Check if license token exists and is not expired
    local token_file="${AGENT_DIR}/.license_token"

    if [[ ! -f "$token_file" ]]; then
        return 1
    fi

    local token_data
    token_data=$(cat "$token_file" 2>/dev/null)

    local expires
    expires=$(echo "$token_data" | jq -r '.expires // ""' 2>/dev/null)

    if [[ -z "$expires" ]]; then
        return 1
    fi

    # Check if expired (basic check)
    local expires_epoch current_epoch
    if command -v date >/dev/null 2>&1; then
        if date --version 2>&1 | grep -q GNU; then
            expires_epoch=$(date -d "${expires}" +%s 2>/dev/null || echo 0)
        else
            expires_epoch=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "${expires}" +%s 2>/dev/null || echo 0)
        fi
        current_epoch=$(date +%s)

        if [[ "$expires_epoch" -gt 0 ]] && [[ "$current_epoch" -gt "$expires_epoch" ]]; then
            log_debug "License token expired"
            return 1
        fi
    fi

    return 0
}

refresh_license_token_if_needed() {
    # Refresh license token if expired or expiring soon (within 1 day)
    local token_file="${AGENT_DIR}/.license_token"

    if [[ ! -f "$token_file" ]]; then
        fetch_license_token
        return $?
    fi

    local token_data expires
    token_data=$(cat "$token_file" 2>/dev/null)
    expires=$(echo "$token_data" | jq -r '.expires // ""' 2>/dev/null)

    if [[ -z "$expires" ]]; then
        fetch_license_token
        return $?
    fi

    # Check if expiring within 1 day
    local expires_epoch current_epoch refresh_threshold
    if command -v date >/dev/null 2>&1; then
        if date --version 2>&1 | grep -q GNU; then
            expires_epoch=$(date -d "${expires}" +%s 2>/dev/null || echo 0)
        else
            expires_epoch=$(date -j -f "%Y-%m-%dT%H:%M:%SZ" "${expires}" +%s 2>/dev/null || echo 0)
        fi
        current_epoch=$(date +%s)
        refresh_threshold=$((expires_epoch - 86400))  # 1 day before expiry

        if [[ "$current_epoch" -gt "$refresh_threshold" ]]; then
            log_info "License token expiring soon, refreshing..."
            fetch_license_token
            return $?
        fi
    fi

    return 0
}

self_update_agent() {
    if [[ -z "$SERVER_URL" ]]; then
        log_error "SERVER_URL not configured"
        return 1
    fi

    if ! command -v curl >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
        log_error "self-update requires curl and jq"
        return 1
    fi

    local manifest_url response success update_available latest_version download_url verify_url signature expected_sha
    manifest_url="${SERVER_URL}/api/agent/update/manifest?agent_type=managed&os_type=linux&current_version=${AGENT_VERSION}"

    response=$(curl -s -X GET \
        -H "Content-Type: application/json" \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        "$manifest_url")

    success=$(echo "$response" | jq -r '.success // false' 2>/dev/null || echo "false")
    if [[ "$success" != "true" ]]; then
        log_error "Update manifest request failed: $(echo "$response" | jq -r '.error // "unknown error"' 2>/dev/null || echo "unknown error")"
        return 1
    fi

    update_available=$(echo "$response" | jq -r '.update_available // false')
    latest_version=$(echo "$response" | jq -r '.latest_version // ""')
    download_url=$(echo "$response" | jq -r '.download_url // ""')
    verify_url=$(echo "$response" | jq -r '.verify_url // ""')
    signature=$(echo "$response" | jq -r '.signature // ""')
    expected_sha=$(echo "$response" | jq -r '.sha256 // ""')

    if [[ "$update_available" != "true" ]]; then
        log_info "Managed agent is up to date (current: ${AGENT_VERSION}, latest: ${latest_version})"
        return 0
    fi

    if [[ -z "$download_url" || -z "$verify_url" || -z "$signature" || -z "$expected_sha" ]]; then
        log_error "Invalid update manifest: missing download/verify/signature/sha256"
        return 1
    fi

    local tmp_file
    tmp_file=$(mktemp)
    if ! curl -s -S -L \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        -o "$tmp_file" \
        "$download_url"; then
        log_error "Failed to download fleet agent update"
        rm -f "$tmp_file"
        return 1
    fi

    local actual_sha
    actual_sha=$(sha256sum "$tmp_file" | awk '{print $1}')
    if [[ "$actual_sha" != "$expected_sha" ]]; then
        log_error "Managed agent update checksum mismatch"
        rm -f "$tmp_file"
        return 1
    fi

    local verify_payload verify_response verify_success
    verify_payload=$(jq -n \
        --arg signature "$signature" \
        --arg file_sha256 "$actual_sha" \
        --arg agent_type "managed" \
        --arg os_type "linux" \
        --arg version "$latest_version" \
        '{signature: $signature, file_sha256: $file_sha256, agent_type: $agent_type, os_type: $os_type, version: $version}')

    verify_response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -H "X-API-Key: ${API_KEY}" \
        -H "X-Agent-ID: ${AGENT_ID}" \
        -d "$verify_payload" \
        "$verify_url")

    verify_success=$(echo "$verify_response" | jq -r '.success // false' 2>/dev/null || echo "false")
    if [[ "$verify_success" != "true" ]]; then
        log_error "Managed agent signed update verification failed: $(echo "$verify_response" | jq -r '.error // "unknown error"' 2>/dev/null || echo "unknown error")"
        rm -f "$tmp_file"
        return 1
    fi

    local script_path backup_path
    script_path="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
    backup_path="${script_path}.bak.$(date +%Y%m%d_%H%M%S)"

    cp "$script_path" "$backup_path"
    cp "$tmp_file" "$script_path"
    chmod +x "$script_path"
    rm -f "$tmp_file"

    log_info "Managed agent updated ${AGENT_VERSION} -> ${latest_version}"
    log_info "Backup saved to: ${backup_path}"
    log_warn "Restart agent process to run the new version"
    return 0
}

# =============================================================================
# Command Processing
# =============================================================================
process_commands() {
    local commands="$1"

    echo "$commands" | jq -c '.[]' | while read -r cmd; do
        local cmd_id cmd_type cmd_data
        cmd_id=$(echo "$cmd" | jq -r '.id')
        cmd_type=$(echo "$cmd" | jq -r '.command_type')
        cmd_data=$(echo "$cmd" | jq '.command_data')

        log_info "Processing command $cmd_id ($cmd_type)"

        # Acknowledge receipt
        acknowledge_command "$cmd_id"

        # Mark as started
        start_command "$cmd_id"

        # Execute based on type
        local result
        case "$cmd_type" in
            run_audit)
                local audit_path
                audit_path=$(echo "$cmd_data" | jq -r '.audit_path')
                result=$(run_audit "$audit_path")
                ;;
            run_plan)
                local audit_paths
                audit_paths=$(echo "$cmd_data" | jq -r '.audit_paths')
                result=$(run_plan "$audit_paths")
                ;;
            run_discovery)
                result=$(run_discovery)
                ;;
            sync_audits)
                result=$(sync_full_package && echo '{"success": true}' || echo '{"success": false}')
                ;;
            key_rotation)
                # Server has rotated our API key - fetch and update
                log_info "Key rotation command received - fetching new key"
                result=$(handle_key_rotation "$cmd_data")
                ;;
            self_update)
                result=$(self_update_agent && echo '{"success": true}' || echo '{"success": false, "error": "self update failed"}')
                ;;
            *)
                log_warn "Unknown command type: $cmd_type"
                result='{"success": false, "error": "Unknown command type"}'
                ;;
        esac

        # Complete command with result
        complete_command "$cmd_id" "$result"
    done
}

acknowledge_command() {
    local cmd_id="$1"
    api_request POST "/api/agent/commands/${cmd_id}/ack" '{}' >/dev/null 2>&1 || true
}

start_command() {
    local cmd_id="$1"
    api_request POST "/api/agent/commands/${cmd_id}/start" '{}' >/dev/null 2>&1 || true
}

complete_command() {
    local cmd_id="$1"
    local result="$2"

    local payload
    payload=$(cat <<EOF
{
    "result_data": $result,
    "exit_code": 0
}
EOF
)

    api_request POST "/api/agent/commands/${cmd_id}/complete" "$payload" >/dev/null 2>&1 || true
}

# =============================================================================
# Audit Execution
# =============================================================================
run_audit() {
    local audit_path="$1"
    local script_path="${AGENT_DIR}/${audit_path}"

    # Check if audit exists locally
    if [[ ! -f "$script_path" ]]; then
        # Try to fetch it
        sync_audits "[\"$audit_path\"]"
    fi

    if [[ ! -f "$script_path" ]]; then
        log_error "Audit not found: $audit_path"
        echo '{"success": false, "error": "Audit script not found"}'
        return 1
    fi

    if ! is_allowed_elevated_script "$script_path"; then
        log_error "Rejected script path outside audit scope: $script_path"
        echo '{"success": false, "error": "Rejected script path"}'
        return 1
    fi

    # Check resources
    if ! check_resources_available; then
        log_warn "Insufficient resources, waiting..."
        sleep 30
        if ! check_resources_available; then
            echo '{"success": false, "error": "Insufficient system resources"}'
            return 1
        fi
    fi

    log_info "Running audit: $audit_path"

    local start_time output exit_code
    start_time=$(date -Iseconds)

    local elevation_policy_info elevation_policy audit_elevation
    elevation_policy_info="$(_resolve_elevation_policy "$script_path")"
    elevation_policy="${elevation_policy_info%%|*}"
    audit_elevation="${elevation_policy_info##*|}"

    if [[ "$audit_elevation" != "none" ]] && [[ $EUID -ne 0 ]] && ! can_sudo; then
        log_warn "Audit $audit_path requests '$audit_elevation' elevation but non-interactive sudo is unavailable; running non-elevated"
    fi

    # Run with throttling and per-audit privilege policy
    # ionice may not be available on all systems
    if command -v ionice &>/dev/null; then
        output=$(nice -n "$CPU_NICE" ionice -c 3 run_privileged_script "$script_path" "$elevation_policy" 2>&1) || exit_code=$?
    else
        output=$(nice -n "$CPU_NICE" run_privileged_script "$script_path" "$elevation_policy" 2>&1) || exit_code=$?
    fi
    exit_code=${exit_code:-0}

    local end_time
    end_time=$(date -Iseconds)

    # Parse output for summary
    local summary
    summary=$(parse_audit_output "$output")

    # Store result locally
    local result_file hostname
    hostname=$(get_hostname)
    result_file="${RESULTS_DIR}/${hostname}_$(basename "$audit_path" .sh)_$(date +%Y%m%d_%H%M%S).json"

    local result
    result=$(cat <<EOF
{
    "audit_path": "$audit_path",
    "executed_at": "$start_time",
    "completed_at": "$end_time",
    "exit_code": $exit_code,
    "status": "$([ "$exit_code" -eq 0 ] && echo success || echo failure)",
    "output": $(echo "$output" | jq -Rs .),
    "summary": $summary
}
EOF
)

    if ! has_disk_headroom "$RESULTS_DIR" "local audit result storage"; then
        echo '{"success": false, "error": "Insufficient local disk for result storage"}'
        return 1
    fi

    # Phase 2 hardening: encrypt result at rest
    encrypt_result "$result" > "$result_file"
    safe_chmod 600 "$result_file"

    # Upload result
    upload_results "$result_file"

    echo "$result"
}

run_plan() {
    local audit_paths="$1"
    # shellcheck disable=SC2034  # Reserved for future batch result collection
    local results=()

    echo "$audit_paths" | jq -r '.[]' | while read -r audit_path; do
        run_audit "$audit_path"
    done

    echo '{"success": true}'
}

parse_audit_output() {
    local output="$1"

    # Parse [PASS], [WARN], [FAIL], [SKIP] markers
    local pass_count warn_count fail_count skip_count total
    pass_count=$(echo "$output" | grep -c '\[PASS\]' || echo 0)
    warn_count=$(echo "$output" | grep -c '\[WARN\]' || echo 0)
    fail_count=$(echo "$output" | grep -c '\[FAIL\]' || echo 0)
    skip_count=$(echo "$output" | grep -c '\[SKIP\]' || echo 0)
    total=$((pass_count + warn_count + fail_count + skip_count))

    cat <<EOF
{
    "total": $total,
    "pass": $pass_count,
    "warn": $warn_count,
    "fail": $fail_count,
    "skip": $skip_count
}
EOF
}

# =============================================================================
# Result Management
# =============================================================================
count_pending_results() {
    if [[ -d "$RESULTS_DIR" ]]; then
        find "$RESULTS_DIR" -maxdepth 1 -name "*.json" -type f 2>/dev/null | wc -l
    else
        echo 0
    fi
}

prune_local_result_files() {
    if [[ ! "$AGENT_MAX_LOCAL_RESULT_FILES" =~ ^[0-9]+$ ]]; then
        return 0
    fi

    local max_files
    max_files=$AGENT_MAX_LOCAL_RESULT_FILES
    if [[ "$max_files" -le 0 ]]; then
        return 0
    fi

    mapfile -t uploaded_files < <(find "${RESULTS_DIR}/uploaded" -name "*.json" -type f -printf '%T@|%p\n' 2>/dev/null | sort -n)
    mapfile -t pending_files < <(find "$RESULTS_DIR" -maxdepth 1 -name "*.json" -type f -printf '%T@|%p\n' 2>/dev/null | sort -n)

    local total
    total=$((${#uploaded_files[@]} + ${#pending_files[@]}))
    local overflow=$((total - max_files))
    [[ "$overflow" -le 0 ]] && return 0

    local removed=0
    local entry path

    for entry in "${uploaded_files[@]}"; do
        [[ "$removed" -ge "$overflow" ]] && break
        path="${entry#*|}"
        if rm -f "$path" 2>/dev/null; then
            ((removed++))
        fi
    done

    if [[ "$removed" -lt "$overflow" ]]; then
        log_warn "Result retention removing pending result files due to local cap (max=${max_files})"
        for entry in "${pending_files[@]}"; do
            [[ "$removed" -ge "$overflow" ]] && break
            path="${entry#*|}"
            if rm -f "$path" 2>/dev/null; then
                ((removed++))
            fi
        done
    fi

    if [[ "$removed" -gt 0 ]]; then
        log_info "Pruned $removed local result files (max_local_result_files=${max_files})"
    fi
}

upload_results() {
    local result_file="$1"

    if [[ ! -f "$result_file" ]]; then
        return 1
    fi

    local hostname result file_content
    hostname=$(get_hostname)
    file_content=$(cat "$result_file")
    # Phase 2 hardening: decrypt result for upload (handles both encrypted and legacy plaintext)
    result=$(decrypt_result "$file_content")
    if [[ -z "$result" ]]; then
        log_error "Failed to decrypt result file: $result_file"
        return 1
    fi

    local payload
    payload=$(cat <<EOF
{
    "agent_id": "$AGENT_ID",
    "hostname": "$hostname",
    "results": [$result]
}
EOF
)

    local response
    response=$(api_request POST "/api/agent/managed/results/ingest" "$payload")

    if echo "$response" | jq -e '.success' >/dev/null 2>&1; then
        log_info "Uploaded result: $(basename "$result_file")"
        # Archive uploaded result
        mkdir -p "${RESULTS_DIR}/uploaded"
        safe_chmod 700 "${RESULTS_DIR}/uploaded"
        mv "$result_file" "${RESULTS_DIR}/uploaded/"
        prune_local_result_files
        return 0
    else
        log_error "Failed to upload result: $response"
        return 1
    fi
}

upload_all_pending() {
    log_info "Uploading pending results..."

    if [[ ! -d "$RESULTS_DIR" ]]; then
        return 0
    fi

    local count=0
    while IFS= read -r -d '' file; do
        if upload_results "$file"; then
            ((count++))
        fi
    done < <(find "$RESULTS_DIR" -maxdepth 1 -name "*.json" -type f -print0 2>/dev/null)

    log_info "Uploaded $count results"
}

# =============================================================================
# Discovery (Enhanced for Asset Discovery & CVE Integration)
# =============================================================================
run_discovery() {
    log_info "Running comprehensive system discovery..."

    local hostname os_info arch
    hostname=$(get_hostname)
    os_info=$(get_os_info)
    arch=$(get_architecture)

    # Get IP addresses
    local ip_addresses
    ip_addresses=$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^$' | jq -R . | jq -s . 2>/dev/null || echo '[]')

    # Get installed packages (with version for CVE matching)
    local packages="[]"
    if command -v dpkg &>/dev/null; then
        packages=$(run_privileged dpkg-query -W -f="{\"name\":\"\${Package}\",\"version\":\"\${Version}\",\"source\":\"dpkg\"}\n" 2>/dev/null | head -500 | jq -s . 2>/dev/null || echo '[]')
    elif command -v rpm &>/dev/null; then
        packages=$(run_privileged rpm -qa --qf '{"name":"%{NAME}","version":"%{VERSION}-%{RELEASE}","source":"rpm"}\n' 2>/dev/null | head -500 | jq -s . 2>/dev/null || echo '[]')
    elif command -v apk &>/dev/null; then
        packages=$(apk info -v 2>/dev/null | awk -F- '{name=""; for(i=1;i<=NF-2;i++) name=name (i>1?"-":"") $i; ver=$(NF-1)"-"$NF; print "{\"name\":\""name"\",\"version\":\""ver"\",\"source\":\"apk\"}"}' | head -500 | jq -s . 2>/dev/null || echo '[]')
    elif command -v pacman &>/dev/null; then
        packages=$(pacman -Q 2>/dev/null | awk '{print "{\"name\":\""$1"\",\"version\":\""$2"\",\"source\":\"pacman\"}"}' | head -500 | jq -s . 2>/dev/null || echo '[]')
    fi

    # Get running services
    local services="[]"
    if command -v systemctl &>/dev/null; then
        services=$(run_privileged systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk '{print "{\"name\":\""$1"\",\"status\":\"running\"}"}' | head -100 | jq -s . 2>/dev/null || echo '[]')
    elif command -v rc-service &>/dev/null; then
        services=$(rc-service --list 2>/dev/null | while read -r svc; do
            status=$(rc-service "$svc" status 2>/dev/null | grep -q 'started' && echo "running" || echo "stopped")
            echo "{\"name\":\"$svc\",\"status\":\"$status\"}"
        done | head -100 | jq -s . 2>/dev/null || echo '[]')
    fi

    # Get open ports (for Asset Discovery)
    local open_ports="[]"
    if command -v ss &>/dev/null; then
        open_ports=$(run_privileged ss -tulpn 2>/dev/null | grep LISTEN | awk '{
            split($5, addr, ":");
            port=addr[length(addr)];
            proto=($1=="tcp"?"tcp":"udp");
            proc=$7;
            gsub(/.*users:\(\("|",.*/,"",proc);
            print "{\"port\":" port ",\"protocol\":\"" proto "\",\"process\":\"" proc "\"}"
        }' | jq -s . 2>/dev/null || echo '[]')
    elif command -v netstat &>/dev/null; then
        open_ports=$(run_privileged netstat -tulpn 2>/dev/null | grep LISTEN | awk '{
            split($4, addr, ":");
            port=addr[length(addr)];
            proto=tolower($1);
            proc=$7;
            gsub(/[0-9]+\//,"",proc);
            print "{\"port\":" port ",\"protocol\":\"" proto "\",\"process\":\"" proc "\"}"
        }' | jq -s . 2>/dev/null || echo '[]')
    fi

    # Get pending updates (for vulnerability tracking)
    local updates_available="[]"
    local update_count=0
    if command -v apt &>/dev/null; then
        updates_available=$(apt list --upgradable 2>/dev/null | grep -v '^Listing' | awk -F/ '{print "{\"name\":\""$1"\"}"}' | head -100 | jq -s . 2>/dev/null || echo '[]')
        update_count=$(echo "$updates_available" | jq 'length' 2>/dev/null || echo 0)
    elif command -v yum &>/dev/null; then
        updates_available=$(yum check-update 2>/dev/null | grep -E '^\S+\s+\S+\s+\S+' | awk '{print "{\"name\":\""$1"\"}"}' | head -100 | jq -s . 2>/dev/null || echo '[]')
        update_count=$(echo "$updates_available" | jq 'length' 2>/dev/null || echo 0)
    fi

    # Get user accounts (for security auditing)
    local users="[]"
    if [[ -f /etc/passwd ]]; then
        users=$(run_privileged cat /etc/passwd 2>/dev/null | awk -F: '$3 >= 1000 && $3 < 65534 {print "{\"name\":\""$1"\",\"uid\":"$3",\"shell\":\""$7"\"}"}' | jq -s . 2>/dev/null || echo '[]')
    fi

    # Get security info
    local firewall_status="unknown"
    local firewall_rules="[]"
    if command -v ufw &>/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
        firewall_status="active"
        firewall_rules=$(ufw status numbered 2>/dev/null | grep -E '^\[' | jq -R . | jq -s . 2>/dev/null || echo '[]')
    elif command -v firewall-cmd &>/dev/null && firewall-cmd --state 2>/dev/null | grep -q running; then
        firewall_status="active"
        firewall_rules=$(run_privileged firewall-cmd --list-all 2>/dev/null | jq -R . | jq -s . 2>/dev/null || echo '[]')
    elif command -v iptables &>/dev/null; then
        local rule_count
        rule_count=$(run_privileged iptables -S 2>/dev/null | wc -l)
        firewall_status=$([[ $rule_count -gt 3 ]] && echo "active" || echo "minimal")
        firewall_rules=$(run_privileged iptables -S 2>/dev/null | head -50 | jq -R . | jq -s . 2>/dev/null || echo '[]')
    fi

    local selinux_status="disabled"
    if command -v getenforce &>/dev/null; then
        selinux_status=$(getenforce 2>/dev/null | tr '[:upper:]' '[:lower:]')
    fi

    local apparmor_status="disabled"
    if command -v aa-status &>/dev/null; then
        apparmor_status=$(run_privileged aa-status 2>/dev/null | grep -q 'profiles are loaded' && echo "enabled" || echo "disabled")
    fi

    # Build comprehensive discovery payload
    local sudo_mode reduced_mode capabilities
    sudo_mode=$(get_sudo_mode)
    reduced_mode=$(is_reduced_mode && echo "true" || echo "false")
    capabilities=$(detect_capabilities)

    local payload
    payload=$(cat <<EOF
{
    "agent_id": "$AGENT_ID",
    "hostname": "$hostname",
    "os_type": "linux",
    "os_name": "$os_info",
    "architecture": "$arch",
    "ip_addresses": $ip_addresses,
    "packages": $packages,
    "services": $services,
    "open_ports": $open_ports,
    "updates_available": $updates_available,
    "update_count": $update_count,
    "users": $users,
    "security": {
        "firewall_status": "$firewall_status",
        "firewall_rules": $firewall_rules,
        "selinux_status": "$selinux_status",
        "apparmor_status": "$apparmor_status"
    },
    "agent_version": "$AGENT_VERSION",
    "sudo_mode": "$sudo_mode",
    "reduced_mode": $reduced_mode,
    "capabilities": $capabilities,
    "discovered_at": "$(date -Iseconds)"
}
EOF
)

    # Save discovery data locally (for FleetAgentExecutor to read)
    local discovery_file="${CACHE_DIR}/last_discovery.json"
    if has_disk_headroom "$CACHE_DIR" "discovery cache storage"; then
        echo "$payload" > "$discovery_file"
        safe_chmod 600 "$discovery_file"
    else
        log_warn "Skipping local discovery cache write due to low disk"
    fi

    # Upload to main audit server
    local response
    response=$(api_request POST "/api/agent/discovery" "$payload")

    if echo "$response" | jq -e '.success' >/dev/null 2>&1; then
        log_info "Discovery data uploaded successfully"
        echo '{"success": true}'
    else
        log_error "Discovery upload failed: $response"
        echo '{"success": false}'
    fi
}

# =============================================================================
# Asset Discovery Sync
# =============================================================================
# Syncs discovery data to the Asset Discovery service (separate from main audit server)
# This enables the FleetAgentExecutor to retrieve real-time data from agents
sync_to_asset_discovery() {
    # Skip if Asset Discovery URL not configured
    if [[ -z "$ASSET_DISCOVERY_URL" ]] || [[ "$ASSET_DISCOVERY_URL" == "null" ]]; then
        log_debug "Asset Discovery URL not configured, skipping sync"
        return 0
    fi

    log_info "Syncing discovery data to Asset Discovery service..."

    local discovery_file="${CACHE_DIR}/last_discovery.json"
    if [[ ! -f "$discovery_file" ]]; then
        log_warn "No discovery data available, run discovery first"
        return 1
    fi

    # Read discovery data and enhance with agent connectivity info
    local discovery_data
    discovery_data=$(cat "$discovery_file")

    # Add connectivity information for Asset Discovery
    local enhanced_payload
    enhanced_payload=$(echo "$discovery_data" | jq --arg agent_id "$AGENT_ID" --arg server_url "$SERVER_URL" --arg status "online" '
        . + {
            "agent_connectivity": {
                "agent_id": $agent_id,
                "server_url": $server_url,
                "status": $status,
                "last_seen": (now | strftime("%Y-%m-%dT%H:%M:%SZ")),
                "capabilities": ["discovery", "audit", "cve_scan", "port_scan"]
            }
        }
    ')

    # POST to Asset Discovery API
    local response
    local http_code
    local temp_file
    temp_file=$(mktemp)

    http_code=$(curl -s -w "%{http_code}" -o "$temp_file" \
        -X POST \
        -H "Content-Type: application/json" \
        -H "X-Agent-ID: $AGENT_ID" \
        -H "X-API-Key: $API_KEY" \
        --connect-timeout 10 \
        --max-time 30 \
        -d "$enhanced_payload" \
        "${ASSET_DISCOVERY_URL}/api/agent/discovery/sync" 2>/dev/null)

    response=$(cat "$temp_file")
    rm -f "$temp_file"

    if [[ "$http_code" == "200" ]] || [[ "$http_code" == "201" ]]; then
        log_info "Successfully synced to Asset Discovery service"
        return 0
    elif [[ "$http_code" == "404" ]]; then
        # Endpoint may not exist in older versions
        log_debug "Asset Discovery sync endpoint not available (404)"
        return 0
    else
        log_warn "Asset Discovery sync failed (HTTP $http_code): $response"
        return 1
    fi
}

# =============================================================================
# Daemon Mode
# =============================================================================
run_daemon() {
    local sudo_mode
    sudo_mode=$(get_sudo_mode)

    log_info "Starting fleet agent daemon (poll interval: ${POLL_INTERVAL}s)"
    log_info "Auto-discovery: ${AUTO_DISCOVERY} (interval: ${DISCOVERY_INTERVAL}s)"
    log_info "Privilege mode: $sudo_mode"

    # Display capability status
    if is_reduced_mode; then
        log_warn "═══════════════════════════════════════════════════════════════"
        log_warn "  RUNNING IN REDUCED-PRIVILEGE MODE"
        log_warn "  Some audit checks that require root will be skipped."
        log_warn "  To enable full auditing, ask admin to run setup-sudoers.sh"
        log_warn "═══════════════════════════════════════════════════════════════"
    else
        log_info "Full audit capabilities available"
    fi

    # Don't exit if sudo not available - just run in reduced mode
    if [[ "$USE_SUDO" == "true" ]] && [[ $EUID -ne 0 ]]; then
        if ! can_sudo; then
            log_warn "USE_SUDO=true but passwordless sudo not available"
            log_warn "Running in reduced-privilege mode"
            # Continue instead of exit - graceful degradation
        else
            log_info "Passwordless sudo verified"
        fi
    fi

    # Register on startup (include capabilities)
    register_agent || log_warn "Registration failed, will retry"

    # Initial heartbeat gate: agent must be associated with core server
    local heartbeat_ok=false
    local attempt=1
    while [[ "$attempt" -le "$MAX_HEARTBEAT_FAILURES" ]]; do
        if send_agent_heartbeat; then
            heartbeat_ok=true
            break
        fi
        log_warn "Initial heartbeat attempt ${attempt}/${MAX_HEARTBEAT_FAILURES} failed"
        attempt=$((attempt + 1))
        sleep "$HEARTBEAT_TIMEOUT"
    done

    if [[ "$heartbeat_ok" != "true" ]]; then
        log_error "Core server heartbeat validation failed after ${MAX_HEARTBEAT_FAILURES} attempts"
        log_error "Managed agent cannot run without successful heartbeat association"
        exit 1
    fi

    # Initial config fetch
    fetch_config || log_warn "Config fetch failed, using defaults"

    # Initial sync if configured
    local sync_on_startup
    sync_on_startup=$(jq -r '.sync.sync_on_startup // true' "${CACHE_DIR}/server_config.json" 2>/dev/null)
    if [[ "$sync_on_startup" == "true" ]]; then
        sync_full_package || log_warn "Initial sync failed"
    fi

    # Run initial discovery on startup (required for Asset Discovery integration)
    if [[ "$AUTO_DISCOVERY" == "true" ]]; then
        log_info "Running initial discovery scan..."
        run_discovery || log_warn "Initial discovery failed"
        LAST_DISCOVERY=$(date +%s)
        # Also sync to Asset Discovery if configured
        sync_to_asset_discovery || true
    fi

    # Upload any pending results
    upload_all_pending
    prune_local_result_files

    # Main loop
    while true; do
        # Poll for commands
        if ! poll_server; then
            if [[ "$CONSECUTIVE_HEARTBEAT_FAILURES" -ge "$MAX_HEARTBEAT_FAILURES" ]]; then
                log_error "Max heartbeat failures reached (${CONSECUTIVE_HEARTBEAT_FAILURES}/${MAX_HEARTBEAT_FAILURES}); stopping agent"
                log_error "Last heartbeat status: ${LAST_HEARTBEAT_STATUS}; reason: ${LAST_HEARTBEAT_REASON}"
                exit 1
            fi
            log_warn "Poll failed, will retry"
        fi

        # Refresh license token if needed (for audit script execution)
        refresh_license_token_if_needed || log_debug "License token refresh skipped/failed"

        # Check if discovery is due
        local now
        now=$(date +%s)
        if [[ "$AUTO_DISCOVERY" == "true" ]] && (( now - LAST_DISCOVERY >= DISCOVERY_INTERVAL )); then
            log_info "Running scheduled discovery scan..."
            run_discovery || log_warn "Scheduled discovery failed"
            LAST_DISCOVERY=$now
            sync_to_asset_discovery || true
        fi

        prune_local_result_files

        sleep "$POLL_INTERVAL"
    done
}

# =============================================================================
# Interactive Mode
# =============================================================================
show_menu() {
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║     Managed Security Audit Agent for Linux v${AGENT_VERSION}              ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    echo "  Agent ID: ${AGENT_ID:-Not registered}"
    echo "  Server:   ${SERVER_URL:-Not configured}"
    echo "  Config:   Version ${CONFIG_VERSION}"
    echo ""
    echo "───────────────────────────────────────────────────────────────────"
    echo ""
    echo "  1) Register with server"
    echo "  2) Fetch configuration"
    echo "  3) Sync audit scripts"
    echo "  4) Run discovery"
    echo "  5) Upload pending results"
    echo "  6) Poll for commands"
    echo "  7) Start daemon mode"
    echo "  8) Configure server URL"
    echo "  q) Quit"
    echo ""
    read -rp "Select option: " choice

    case "$choice" in
        1) register_agent ;;
        2) fetch_config ;;
        3) sync_full_package ;;
        4) run_discovery ;;
        5) upload_all_pending ;;
        6) poll_server ;;
        7) run_daemon ;;
        8) configure_server ;;
        q|Q) exit 0 ;;
        *) echo "Invalid option" ;;
    esac
}

configure_server() {
    local new_server_url
    read -rp "Server URL: " SERVER_URL
    new_server_url="$SERVER_URL"

    if ! validate_server_url "$new_server_url"; then
        echo "Configuration rejected: invalid server URL"
        return 1
    fi

    SERVER_URL="$new_server_url"
    read -rp "API Key: " API_KEY
    save_config
    echo "Configuration saved"
}

# =============================================================================
# Main
# =============================================================================
main() {
    ensure_dirs
    load_config

    local mode="${1:-interactive}"

    case "$mode" in
        daemon|--daemon|-d)
            run_daemon
            ;;
        poll|--poll)
            poll_server
            ;;
        register|--register)
            register_agent
            ;;
        sync|--sync)
            sync_full_package
            ;;
        discovery|--discovery)
            run_discovery
            ;;
        upload|--upload)
            upload_all_pending
            ;;
        run|--run)
            shift
            run_audit "$1"
            ;;
        rotate-key|--rotate-key)
            shift
            if [[ -z "$1" ]]; then
                log_error "New API key required for rotate-key mode"
                echo ""
                echo "Usage: $0 rotate-key NEW_KEY_HERE"
                echo ""
                get_key_rotation_status
                exit 1
            fi
            update_api_key "$1" --force
            ;;
        show-cert|--show-cert)
            show_server_cert_hash
            get_key_rotation_status
            ;;
        self-update|--self-update)
            self_update_agent
            ;;
        interactive|--interactive|-i|"")
            while true; do
                show_menu
            done
            ;;
        *)
            echo "Usage: $0 [daemon|poll|register|sync|discovery|upload|run <audit>|rotate-key <key>|show-cert|self-update|interactive]"
            exit 1
            ;;
    esac
}

main "$@"
