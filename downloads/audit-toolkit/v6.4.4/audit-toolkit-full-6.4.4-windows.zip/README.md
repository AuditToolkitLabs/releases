# OS-Independent Security Audit Toolkit

[![Version](https://img.shields.io/badge/Version-6.4.1--beta-orange?style=for-the-badge)](CHANGELOG.md)
[![Status](https://img.shields.io/badge/Status-Beta-orange?style=for-the-badge)](docs/BETA-PROGRAM-TERMS.md)
[![Security Score](https://img.shields.io/badge/Security%20Score-97.0%2F100-brightgreen?style=for-the-badge&logo=owasp&logoColor=white)](dev/code-reviews/SECURITY-SCORECARD.md)
[![Grade](https://img.shields.io/badge/Grade-A+-brightgreen?style=for-the-badge)](dev/code-reviews/SECURITY-SCORECARD.md)
[![Free Tier](https://img.shields.io/badge/Free%20Tier-25%20Servers-green?style=for-the-badge&logo=gnu&logoColor=white)](#license)
[![Enterprise Ready](https://img.shields.io/badge/Enterprise-Ready-purple?style=for-the-badge&logo=microsoft&logoColor=white)](#-premium-enterprise-features)
[![Agent Mode](https://img.shields.io/badge/Agent%20Mode-NEW-orange?style=for-the-badge&logo=robot&logoColor=white)](#-deployment-modes)
[![Script Studio](https://img.shields.io/badge/Script%20Studio-Included-orange?style=for-the-badge&logo=visualstudiocode&logoColor=white)](tools/developer-script-studio/README.md)

[![OWASP Top 10](https://img.shields.io/badge/OWASP%20Top%2010-99%25%20Compliant-blue?style=flat-square&logo=owasp)](docs/SECURITY-OVERVIEW.md)
[![ASVS Level 1](https://img.shields.io/badge/ASVS%20L1-96%25%20Compliant-blue?style=flat-square)](docs/SECURITY-OVERVIEW.md)
[![License](https://img.shields.io/badge/License-BSL%201.1-blue?style=flat-square)](LICENSE)
[![Platforms](https://img.shields.io/badge/Platforms-Linux%20%7C%20Windows%20%7C%20Hypervisors-informational?style=flat-square)](docs/00-overview.md)

A **production-ready**, **enterprise-grade** security audit toolkit with **297 audit scripts** (138 Linux + 147 Windows + 12 Hypervisors), **390+ API endpoints**, integrated **Developer Script Studio**, and premium integrations for **Slack/Teams**, **ServiceNow/Jira**, and **GitHub Actions**.

## Docs Hub

Use [docs/INDEX.md](docs/INDEX.md) as the canonical documentation entry point for product, deployment, operations, and API guides.

For strict host-native validation on Windows, use [tools/validation/run-strict-customer-confidence-validation.ps1](tools/validation/run-strict-customer-confidence-validation.ps1), which enables the reporting backfill smoke suite automatically.

📄 **Governance closure summary (2026-03-08):** [docs/GOVERNANCE-CLOSURE-SUMMARY-20260308.md](docs/GOVERNANCE-CLOSURE-SUMMARY-20260308.md)

---

## 🔐 First-Run Secrets Setup (Idiot-Proof)

Before first production start, run the automated setup to generate required secrets:

```bash
# Linux/macOS
./scripts/setup-secrets.sh
```

```powershell
# Windows
.\scripts\setup-secrets.ps1
```

This will:
1. Generate cryptographically secure `FLASK_SECRET_KEY` (session signing)
2. Generate Fernet-formatted `DB_FIELD_ENCRYPTION_KEY` (field encryption)
3. Set `PRODUCTION_HARDENING_REQUIRED=true` (enforces startup validation)
4. Write values to `.env` **without overwriting existing entries**

**Idempotent:** Run multiple times safely — existing secrets are never replaced.

### Environment Profiles

Choose the right profile for your deployment:

| Profile | Use Case | Command |
|---------|----------|---------|
| **Development** | Local testing, feature dev | `cp .env.dev .env` |
| **Test/Staging** | Pre-production validation | `cp .env.test .env && ./scripts/setup-secrets.sh` |
| **Production** | Customer-facing deployments | `cp .env.production .env && ./scripts/setup-secrets.sh` |

📖 **[Environment Profile Guide](docs/DEPLOYMENT-GUIDE.md#-environment-profiles)** — Detailed comparison of dev/test/prod settings

---

## ⚠️ Early Release Notice

> **Important:** This tool is developed and maintained by a **single developer**.

### What This Means for You

| Aspect | Current Status |
|--------|----------------|
| **Free Tier** | 25 machines - Evaluate before scaling |
| **Support** | Community only (GitHub Issues) |
| **SLA** | None - best effort responses |
| **Stability** | Tested, but use in non-production first |

### Why the 25-Machine Limit?

The free tier limit exists to:
1. **Ensure stability** - Validate the tool works in your environment before scaling
2. **Encourage testing** - Security audit tools require careful evaluation
3. **Manage support** - Solo developer capacity is limited

**This is not a sales tactic** - it's responsible software distribution. If you need higher limits after thorough evaluation, paid tiers unlock more machines with the understanding that support remains community-based.

📖 See [License](#license) and [Support Policy](#support-policy) for details.

---

## 🛡️ Security First

> **This toolkit is built with enterprise-grade security.** Our codebase has been independently scored against OWASP standards.

| Standard | Compliance | Details |
|----------|------------|---------|
| **OWASP Top 10 (2021)** | 99% | [View Scorecard](dev/code-reviews/SECURITY-SCORECARD.md) |
| **OWASP ASVS Level 1** | 96% | [View Details](docs/SECURITY-OVERVIEW.md) |
| **OWASP ASVS Level 2** | 85% | Sensitive data protections |
| **Overall Security Grade** | **A+ (97.0/100)** | [Full Report](dev/code-reviews/SECURITY-SCORECARD.md) |

**Security Features:**
- ✅ OWASP-compliant input validation & output encoding
- ✅ Role-based access control (RBAC) with 5-tier permissions
- ✅ HaveIBeenPwned integration for password breach detection
- ✅ Account lockout (5 attempts / 30 min) with MFA (TOTP + backup codes)
- ✅ SSRF/XSS/Injection protection throughout
- ✅ Automated CI/CD security scanning (CodeQL, Trivy, pip-audit, Gitleaks)

📄 **[Executive Security Overview](docs/SECURITY-OVERVIEW.md)** | 📊 **[Detailed Scorecard](dev/code-reviews/SECURITY-SCORECARD.md)** | 🔒 **[Threat Model](docs/THREAT-MODEL.md)**

---

## ⚡ Verified Performance

> **Tested and validated** - Sub-5ms API responses with 100% authentication enforcement.

| Metric | Value | Status |
|--------|-------|--------|
| **Average API Response** | 3.7ms | Excellent |
| **Authentication Enforcement** | 100% | All endpoints protected |
| **Functional Test Pass Rate** | 95% | Production ready |
| **API Endpoints** | 390+ routes | Comprehensive coverage |
| **Security Score Progression** | 75 → 96.6 | C to A+ in 6 days |

📊 **[Full Performance Report](docs/FUNCTIONAL-PERFORMANCE-REPORT.md)**

---

## 📸 Screenshots

> **Coming Soon** - Screenshots will be added after beta testing. Run locally to preview:
>
> ```bash
> cd web && python app.py
> # Open http://localhost:5000
> ```

| View | Description |
|------|-------------|
| **Dashboard** | Real-time security posture, pass/fail/warning counts |
| **Audit Results** | Detailed findings with severity levels and remediation |
| **Server List** | Registered machines, status, last audit time |
| **Reports** | PDF/CSV export, compliance mapping |
| **Admin Panel** | User management, LDAP/SSO config, license status |

📷 **Capture your own**: `.\tools\capture-screenshots.ps1`

---

## 🏢 Enterprise Capabilities

> **297 audit scripts, 390+ API endpoints, 7 SIEM integrations** - This is enterprise-grade infrastructure security.

### Identity & Access Management

| Integration | Features | Documentation |
|-------------|----------|---------------|
| **LDAP / Active Directory** | JIT provisioning, group-to-role mapping, fallback auth | [Setup Guide](docs/LDAP-INTEGRATION.md) |
| **Microsoft Entra ID** | OAuth 2.0/OIDC, Conditional Access, single logout | [Setup Guide](docs/ENTRA-ID-INTEGRATION.md) |
| **Okta OIDC** | SSO, group-based RBAC, JIT provisioning | [Setup Guide](docs/OKTA-SETUP.md) |
| **TOTP MFA** | Google/Microsoft Authenticator, backup codes, rate limiting | [Setup Guide](docs/MFA-SETUP.md) |

### SIEM & Monitoring Integration

| Platform | Methods | Documentation |
|----------|---------|---------------|
| **Wazuh** | Syslog, Agent | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **Splunk** | HTTP Event Collector (HEC) | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **Elastic SIEM (ELK)** | Webhook, Filebeat | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **Microsoft Sentinel** | Webhook, Log Analytics | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **IBM QRadar** | Syslog, REST | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **Graylog** | GELF, Syslog | [SIEM Guide](docs/SIEM-INTEGRATION-GUIDE.md) |
| **Prometheus/Grafana** | 60+ metrics, pre-built dashboards | [Monitoring Guide](docs/MONITORING.md) |

### Compliance Frameworks

| Framework | Coverage | Features |
|-----------|----------|----------|
| **CIS Benchmarks** | Level 1 & 2 | 110+ automated checks, remediation scripts |
| **PCI-DSS** | Mapped | Finding-to-control mapping |
| **SOC 2** | Mapped | Audit trail, access controls |
| **NIST SP 800-53** | Mapped | Control family mapping |
| **ISO 27001** | Mapped | Annex A alignment |

---

## 💎 Premium Enterprise Features

> **NEW in v2.0**: Commercial-grade capabilities that justify enterprise pricing and drive customer retention.

### Trend Analysis & ROI Demonstration

| Feature | Benefit |
|---------|---------|
| **Run Comparison** | Compare latest vs previous audit results to show improvement |
| **Trend Reports** | Organization-wide compliance trajectory over 30/60/90 days |
| **Visual Dashboards** | Before/after metrics with compliance deltas (+/-%) |
| **Auto-generated Summaries** | Sales-ready text: "Compliance improved from 72% to 89%" |

**API Endpoints:**
- `GET /api/analytics/servers/<id>/compare-runs` — Server-level before/after comparison
- `GET /api/analytics/trend-report` — Org-wide improvement summary for renewals

**Business Value:** Makes renewal/upsell conversations data-driven. Show prospects tangible security improvement.

### Compliance Evidence Collector (Premium)

> **Reduces audit prep time from days to hours.** Creates tamper-evident evidence packages accepted by Big 4 auditors.

| Feature | Description |
|---------|-------------|
| **Evidence Types** | Audit output, configurations, screenshots, logs, attestations |
| **Integrity Verification** | SHA-256 checksums for every artifact |
| **Framework Mapping** | Auto-organizes by PCI-DSS, SOC 2, ISO 27001, NIST, CIS controls |
| **Auditor-Ready Export** | ZIP with MANIFEST.json, SHA256SUMS.txt, README for auditors |
| **Digital Signatures** | Package signing for chain-of-custody |

**API Endpoints:**
- `POST /api/evidence/collect/assessment` — Create multi-server evidence package
- `GET /api/evidence/packages/<id>/export` — Download auditor-ready ZIP
- `POST /api/evidence/packages/<id>/sign` — Add attestation signature

**Business Value:** Premium pricing justification. Enterprises pay significantly more for audit-ready tooling.

### Slack & Microsoft Teams Integration

> **Daily touchpoint = stickiness.** Users see value every morning, making cancellation psychologically difficult.

| Feature | Description |
|---------|-------------|
| **Daily Security Digest** | Morning compliance summary delivered to team channels |
| **Real-time Alerts** | Instant notification when compliance drops below threshold |
| **Slash Commands** | `/audit status`, `/audit server <name>` for quick lookups |
| **Interactive Actions** | Button clicks to trigger audits directly from chat |
| **Adaptive Cards** | Rich formatting for Microsoft Teams |

**API Endpoints:**
- `POST /api/integrations/chat/configs` — Configure Slack/Teams webhooks
- `POST /api/integrations/chat/digest/send` — Trigger security digest
- `POST /api/integrations/chat/alert/send` — Send real-time alert

**Business Value:** Daily value demonstration reduces churn. Hard to cancel when your team relies on morning reports.

### ServiceNow & Jira Ticketing

> **Enterprise table stakes.** Security teams already live in these tools — meet them where they are.

| Feature | Description |
|---------|-------------|
| **Auto-Create Tickets** | Automatically create tickets for FAIL findings |
| **Bi-directional Sync** | Tickets auto-close when issues remediated |
| **SLA Tracking** | Track time-to-remediation, alert on breaches |
| **Priority Mapping** | Critical=P1, High=P2 automatically |
| **Bulk Operations** | Create tickets for all compliance gaps at once |

**API Endpoints:**
- `POST /api/integrations/ticketing/tickets` — Create ticket for finding
- `POST /api/integrations/ticketing/tickets/bulk` — Bulk ticket creation
- `GET /api/integrations/ticketing/tickets/sla-breached` — Get overdue tickets

**Business Value:** Enterprise sales requirement. Deals stall without ServiceNow/Jira integration.

### GitHub Actions & Marketplace

> **Viral growth engine.** Developers discover via GitHub Marketplace, try free tier, recommend to enterprise.

| Feature | Description |
|---------|-------------|
| **One-Click Workflow** | Generate GitHub Actions YAML instantly |
| **Marketplace Action** | `uses: audit-tool/security-check@v1` |
| **SARIF Output** | Results appear in GitHub Security tab |
| **PR Comments** | Audit summaries posted to pull requests |
| **Status Checks** | Block merges when compliance below threshold |

**API Endpoints:**
- `POST /api/integrations/github/workflow/generate` — Generate workflow YAML
- `POST /api/integrations/github/sarif/generate` — Generate SARIF output
- `POST /api/integrations/github/check-run` — Create GitHub check run

**Business Value:** Viral acquisition channel. Free developer adoption leads to enterprise deals.

---

---

## 🤖 Deployment Modes

> **NEW in v5.0**: Choose the deployment mode that fits your security requirements

### Three Ways to Deploy

| Mode | Connection | Best For |
|------|------------|----------|
| **SSH/WinRM** | Persistent remote access | Full control, real-time execution |
| **JRE Agent (Standalone)** | HTTPS push only | High-security, air-gapped environments |
| **JRE Agent (Managed)** | HTTPS poll + push | Centralized fleet management |

> Deployment Center scope: use package downloads for full toolkit distribution; use remote push workflows for agent deployment.

### JRE Agent Highlights

The **JRE Agent** is the recommended deployment path for high-security environments:

- **No SSH/WinRM Required** - Deploy once, then disable remote access protocols
- **Push-Based Results** - Agent pushes results to server via HTTPS (no inbound ports)
- **Network Discovery** - Discover hosts from inside the network
- **Resource Throttling** - CPU, memory, and bandwidth limits to avoid impact
- **Background Runtime** - Runs detached from terminal with PID/log lifecycle scripts
- **Auto-Start on Reboot** - Windows Scheduled Task / Linux systemd enablement scripts
- **Automatic Sync** - Keep audit scripts up-to-date automatically

```bash
# Linux package lifecycle
bash start-agent.sh
sudo bash enable-autostart.sh

# Windows package lifecycle
pwsh -ExecutionPolicy Bypass -File .\START-AGENT.ps1
pwsh -ExecutionPolicy Bypass -File .\ENABLE-AUTOSTART.ps1
```

📖 **[Full Agent Deployment Guide](docs/17-agent-deployment-guide.md)**
🔐 **[JRE Operations + IP Protection](docs/JRE-OPERATIONS-IP-PROTECTION.md)**

> **Deprecation note:** Legacy standalone agent deployment has been deprecated in favor of JRE standalone mode.

---

### Multi-Platform Support

| Platform | Coverage |
|----------|----------|
| **Linux** | Ubuntu, Debian, RHEL, Fedora, Arch, Alpine, openSUSE |
| **Windows** | Server 2016/2019/2022/2025, Windows 10/11 |
| **Hypervisors** | VMware ESXi/vCenter, Hyper-V, Proxmox, KVM, Nutanix, XenServer |
| **Cloud** | AWS, Azure, GCP, Oracle Cloud |

### Deployment Options

| Method | Features | Documentation |
|--------|----------|---------------|
| **Docker** | Production-ready, multi-distro images | [Docker Guide](deployment/docker/) |
| **Kubernetes** | HPA, PDB, Ingress, NetworkPolicy | [K8s Manifests](deployment/kubernetes/) |
| **Ansible** | Fleet deployment playbooks | [Deployment Guide](docs/DEPLOYMENT-GUIDE.md) |
| **Terraform** | AWS, Azure, GCP configurations | [Deployment Guide](docs/DEPLOYMENT-GUIDE.md) |
| **Standalone Agent** | No SSH/WinRM, HTTPS push | [Agent Guide](docs/17-agent-deployment-guide.md) |

#### VM Appliance Quick Rebuild (Elevated PowerShell)

```powershell
.\tools\rebuild-vm-appliance.ps1 -Version "<version>"
```

Produces VHDX and auto-packages OVF/OVA without requiring VMware OVF Tool. See [VM Appliance Build Guide](deployment/vm-appliance/OVA-BUILD-GUIDE.md).

#### VM Appliance Runtime Drift Repair (PostgreSQL)

```powershell
pwsh -File .\run-vm-postgres-runtime-fix.ps1
```

Use this when appliance runtime drifts to SQLite or after migration-chain repairs. See [Host OS Validation Runbook](docs/HOST-OS-VALIDATION-RUNBOOK.md) and [Appliance Security Guide](deployment/vm-appliance/APPLIANCE-SECURITY-GUIDE.md#postgresql-only-runtime-enforcement-vm-operations).

### EDR/XDR Validation

Detects and validates installation/status of:
- Microsoft Defender for Endpoint, CrowdStrike Falcon, Carbon Black
- SentinelOne, Sophos, Trend Micro, ESET, Cylance
- Wazuh Agent, OSSEC, Malwarebytes

### API & Extensibility

- **390+ REST API endpoints** with Swagger UI documentation
- **Webhook notifications** with SSRF protection
- **Custom audit framework** for organization-specific checks
- **Celery task queue** for distributed processing

---

## 🔄 Zero-Risk Remediation & One-Click Rollback

> **Industry-first**: Atomic transaction support with automatic rollback. No other open-source security tool offers this level of safety.

### Why This Matters

| Problem | Our Solution |
|---------|--------------|
| Fear of breaking production systems | **Atomic transactions** - changes fully apply or fully revert |
| Manual backup/restore tedium | **Automatic backup-before-change** with timestamped snapshots |
| "Fix one thing, break another" | **Transaction isolation** - rollback affects only changed files |
| No audit trail for changes | **Manifest logging** - every change tracked with checksums |
| Weekend emergencies from bad patches | **Dead man's switch** - auto-rollback if confirmation not received |

### Remediation Coverage

| Platform | Fixes | Categories |
|----------|-------|------------|
| **Linux** | 110+ | SSH hardening, kernel security, PAM, logging, permissions, services |
| **Windows** | 180+ | CIS Level 1/2, firewall, audit policy, NTLM, BitLocker, UAC, services |
| **Hypervisors** | 30+ | ESXi, vCenter, Hyper-V security configurations |

### How It Works

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Transaction-Safe Remediation                      │
├─────────────────────────────────────────────────────────────────────┤
│  1. START TRANSACTION                                               │
│     └── Create rollback point with timeout (default: 5 min)         │
│                                                                     │
│  2. BACKUP FILES                                                    │
│     └── /etc/ssh/sshd_config → backups/sshd_config.20260213-143022 │
│     └── SHA256 checksums recorded in manifest.json                  │
│                                                                     │
│  3. APPLY CHANGES                                                   │
│     └── Modify configuration files                                  │
│     └── Restart services (if needed)                                │
│                                                                     │
│  4. VALIDATE                                                        │
│     ├── Success → COMMIT (backups retained for manual rollback)     │
│     └── Failure → AUTO-ROLLBACK (original files restored)           │
└─────────────────────────────────────────────────────────────────────┘
```

### CLI Usage

```bash
# Linux: Apply fix with transaction safety
sudo ./fix/linux/run-fix.sh --fix SSH-001 --with-rollback --timeout 300

# List available rollback points
sudo ./fix/linux/rollback-manager.sh --list

# Rollback from last backup
sudo ./fix/linux/rollback-manager.sh --rollback --latest

# Rollback specific fix
sudo ./fix/linux/rollback-manager.sh --rollback sshd-hardening-20260213
```

```powershell
# Windows: Apply fix with transaction safety
.\fix\windows\Run-Fix.ps1 -FixId ACCT-001 -WithRollback -Timeout 300

# List available rollback points
.\fix\windows\Rollback-Manager.ps1 -List

# Rollback from last backup
.\fix\windows\Rollback-Manager.ps1 -Restore -Latest
```

### Web UI Integration

The web dashboard provides **point-and-click remediation** with full rollback support:

- **One-click fixes** - Select findings and apply recommended remediations
- **Dry-run preview** - See exactly what will change before applying
- **Rollback buttons** - Instantly revert any fix from the execution history
- **Audit trail** - Complete log of who applied what, when, and from where

### Competitive Advantage

| Feature | This Toolkit | OpenVAS | Nessus | Qualys |
|---------|-------------|---------|--------|--------|
| Atomic rollback | ✅ Built-in | ❌ | ❌ | ❌ |
| Auto-backup before change | ✅ | ❌ | ❌ | Limited |
| Transaction timeout | ✅ | ❌ | ❌ | ❌ |
| Open-source remediation | ✅ | ❌ | ❌ | ❌ |
| Self-hosted option | ✅ | ✅ | ❌ | ❌ |

📄 **[Complete Remediation Documentation](fix/README.md)** | 🔧 **[Fix Script Development](docs/04-audit-authoring.md#remediation-scripts)**

---

## Installation

> **Windows Users:** Use the Windows section in [docs/DEPLOYMENT-GUIDE.md](docs/DEPLOYMENT-GUIDE.md) for MSI prerequisites and setup.

### Quick Install (One-Liner)

```bash
curl -fsSL https://raw.githubusercontent.com/AuditToolkitLabs/Audit-Tool-/main/install.sh | sudo bash
```

**What it does:**
- Installs to `/opt/audit-toolkit`
- Creates `audit-toolkit` command
- Optionally sets up automated daily audits
- Configures logging

**After installation:**
```bash
audit-toolkit --interactive
```

See [docs/DEPLOYMENT-GUIDE.md](docs/DEPLOYMENT-GUIDE.md) for installation, automated deployment (Ansible, Terraform, Docker, Kubernetes), and troubleshooting.

For storage guardrails across core DB/host and target agents (managed/standalone/hypervisor channels), see
[docs/21-storage-control-matrix.md](docs/21-storage-control-matrix.md).
For schedule tuning of cleanup/maintenance actions (enable + interval), see
[docs/21-storage-control-matrix.md#operator-note-policy-driven-schedules](docs/21-storage-control-matrix.md#operator-note-policy-driven-schedules).

For in-place upgrades of deployed instances from GitHub (Windows/Linux,
native or Docker), see
[docs/12-github-update-guide.md](docs/12-github-update-guide.md).

## Features
- OS detection via `/etc/os-release`
- Shims for **package managers** (APT, DNF, Zypper, Pacman, Apk)
- Shims for **service managers** (systemd, OpenRC)
- **Hardware inventory** audit (CPU, RAM, disk, network)
- **Security hardening** checks (SSH, firewall, SELinux, AppArmor)
- Consistent output: `[PASS] [WARN] [FAIL] [SKIP]` + final summary
- Sample audits: **OS Updates**, **Hardware Info**, **Service Basics**, **Firewall State**
- **GitHub Actions** matrix CI across multiple distros

## Quick Start

### Option 1: Interactive Selection (Recommended!)
```bash
# Pick audits interactively with a user-friendly menu
bash orchestrator/orchestrator.sh --interactive
```

**No file editing required!** Just select what you want to run.

### Option 2: Use Presets
```bash
# Quick daily health check (4 essential audits)
bash orchestrator/orchestrator.sh --preset minimal

# Security-focused audits
bash orchestrator/orchestrator.sh --preset security

# All platform audits
bash orchestrator/orchestrator.sh --preset platform
```

### Option 3: Run Individual Audits
```bash
# Run a single audit directly
bash audits/linux/platform/baseline/updates.sh
bash audits/linux/platform/baseline/hardware-info-audit.sh
```

**See [docs/11-orchestrator-examples.md](docs/11-orchestrator-examples.md) for more examples and workflows.**

## Orchestrator Features

The orchestrator provides flexible audit selection **without editing any files**:

✅ **Interactive Selection** - User-friendly menu with domain grouping
✅ **Presets** - Pre-configured audit sets (minimal, security, platform, web, all)
✅ **Domain Filtering** - Run audits by category (--domain platform)
✅ **Pattern Matching** - Filter by regex (--match nginx)
✅ **Plan Files** - Save/reuse selections (--save-plan, --plan)
✅ **Range Selection** - Pick multiple audits easily (1-5, 10-12, all)

**Quick examples:**
```bash
# Interactive menu - pick what you want
bash orchestrator/orchestrator.sh --interactive

# Daily health check (4 core audits)
bash orchestrator/orchestrator.sh --preset minimal

# Create reusable plan file
bash orchestrator/orchestrator.sh --interactive --save-plan my-audits.txt
bash orchestrator/orchestrator.sh --plan my-audits.txt
```

See [docs/09-orchestrator-interactive-guide.md](docs/09-orchestrator-interactive-guide.md) for comprehensive documentation.

## Usage Scenarios

### Development & CI/CD (Unprivileged)

Run audits without sudo for continuous monitoring:

```bash
# Single domain
bash orchestrator/orchestrator.sh --domain web

# Multiple domains
bash orchestrator/orchestrator.sh --domain platform --domain data

# Interactive selection
bash orchestrator/orchestrator.sh --interactive
```

**Coverage**: 85-93% of checks (permission-gated checks skipped)
**Use Case**: Developer workstations, CI pipelines, rootless containers

### Production & Compliance (With Sudo)

Run with root privileges for complete coverage:

```bash
# Full audit (all domains)
sudo bash orchestrator/orchestrator.sh --preset all

# Specific domain with root
sudo bash orchestrator/orchestrator.sh --domain platform

# Strict mode (exit if not root)
sudo bash orchestrator/orchestrator.sh --preset security --require-root
```

**Coverage**: 100% of checks (no skips)
**Use Case**: Compliance audits (PCI-DSS, HIPAA), incident response, production hardening

### Hybrid Approach (Recommended)

Combine frequent unprivileged checks with periodic root audits:

```bash
# Cron example (/etc/crontab)

# Continuous monitoring (every 15 minutes) - unprivileged
*/15 * * * * audit-user /opt/audit-toolkit/orchestrator/orchestrator.sh --domain platform >> /var/log/audit-continuous.log 2>&1

# Compliance audit (weekly Sunday 2 AM) - with root
0 2 * * 0 root /opt/audit-toolkit/orchestrator/orchestrator.sh --preset all >> /var/log/audit-compliance.log 2>&1
```

**Benefits**:
- Frequent checks detect emerging issues (config drift, new vulnerabilities)
- Weekly root checks validate firewall, logs, and privileged settings
- Minimal sudo usage (security best practice)

## Supported (out of the box)
- Ubuntu/Debian (APT)
- RHEL/Fedora/Alma/Rocky (DNF)
- openSUSE/SLES (Zypper)
- Arch/Manjaro (Pacman)
- Alpine (Apk, OpenRC)

See **[docs/04-audit-authoring.md](docs/04-audit-authoring.md)** to write new audits and **[docs/05-ci-cd.md](docs/05-ci-cd.md)** for CI.

## Contributing

We welcome contributions! See **[CONTRIBUTING.md](CONTRIBUTING.md)** for:
- How to report bugs and request features
- Development workflow and coding standards
- Testing requirements
- Pull request guidelines

Please read our **[Code of Conduct](CODE_OF_CONDUCT.md)** before contributing.

## Documentation

### Technical Documentation
- [Deployment Guide](docs/DEPLOYMENT-GUIDE.md) - Installation, deployment options, troubleshooting
- [Developer Guide](docs/03-developer-guide.md) - Local development, Git workflows
- [Audit Authoring](docs/04-audit-authoring.md) - Writing new security audits
- [Architecture](docs/07-architecture.md) - System design and compatibility layer
- [Library API Reference](docs/06-library-api-reference.md) - Shim functions and utilities
- [Security Policy](SECURITY.md) - Comprehensive security documentation
- [Roadmap](ROADMAP.md) - Future plans and features
- [Changelog](CHANGELOG.md) - Version history

### Commercialization & Sharing
- **[Quick Start: Private Sharing](docs/QUICK-START-PRIVATE-SHARING.md)** ⚡ - Share with investors/advisors today (30 min setup)
- [Private Sharing Guide](docs/PRIVATE-SHARING-GUIDE.md) - Complete strategies for pre-launch sharing
- [License Protection Guide](docs/LICENSE-PROTECTION-GUIDE.md) - Prevent commercial forks (BSL vs AGPL)
- [License Choice Quick Reference](docs/LICENSE-CHOICE-QUICK-REFERENCE.md) - Which license to use and why
- [License Protection Action Plan](docs/LICENSE-PROTECTION-ACTION-PLAN.md) - Pre-GitHub release checklist
- [Commercialization Strategy](docs/COMMERCIALIZATION-STRATEGY.md) - Business plan and revenue models
- [Market Comparison](docs/MARKET-COMPARISON.md) - Competitive analysis vs commercial tools

## Support Policy

| Tier | Support Channel | Response Time | SLA |
|------|-----------------|---------------|-----|
| **Community (Free)** | GitHub Issues | Best effort | None |
| **Starter** | GitHub Issues + Email | 2-5 days target | None |
| **Professional** | GitHub Issues + Email | 1-3 days target | None |
| **Business** | GitHub Issues + Email | 1-2 days target | None |
| **Add-on onboarding engagements** | By written agreement | By onboarding window | By agreement |

**Important Notes:**
- This is a solo developer project - response times are targets, not guarantees
- All support is provided as time permits alongside development
- Paid tiers unlock machine limits and software usage rights
- Commercial add-on packs provide extended enterprise capabilities (for qualifying paid subscriptions)
- Paid-tier support is limited to basic, best-effort email for activation and product usage
- Calls, consulting, remediation execution, and managed services are not included in standard license tiers
- For urgent production issues, consider engaging a qualified security consultant

📖 **Full details:** [SUPPORT-POLICY.md](SUPPORT-POLICY.md) | [FAQ.md](FAQ.md)

### Responsible Use Guidelines

1. **Always test in non-production first** - Audit scripts inspect system configurations
2. **Review audit results before acting** - The tool identifies issues; remediation is your decision
3. **Start small** - Begin with a few machines, validate results, then expand
4. **Keep backups** - Before making any system changes based on audit findings

## License

This project is licensed under the **Business Source License 1.1 (BSL)**.

### Quick Summary:

| Use Case | Allowed? |
|----------|----------|
| Internal security auditing | ✅ Yes |
| Up to 25 machines (free) | ✅ Yes |
| Evaluation and testing | ✅ Yes |
| Offering as a commercial service | ❌ Requires license |
| Embedding in commercial products | ❌ Requires license |
| Operating as SaaS for others | ❌ Requires license |

**On February 9, 2031** (BSL 1.1 Change Date), this software automatically converts to the **MIT License**.
📖 **Full details:** [LICENSE](LICENSE) | [EULA.md](EULA.md) | [PRIVACY.md](PRIVACY.md)

### Current Sellable Tier Matrix

| Plan | Machine limit | Core positioning |
|------|---------------|------------------|
| **Community (Free)** | 25 | Evaluation and small internal environments |
| **Starter** | 50 | Entry commercial usage |
| **Professional** | 150 | Scheduling, reporting, and broader integrations |
| **Business** | 500 | Team-scale operations and enterprise workflow features |
| **Advanced Operations Pack Add-On** | Add-on to Professional+ baseline where eligible features require it | Unlocks gated advanced operations capabilities (for example, hypervisor advanced workflows and external source/asset ingest controls) |

Notes:
- Enterprise is not a public self-serve tier; availability is by separate written agreement only.
- External source ingest and external asset push require Business tier plus Advanced Operations Pack add-on.
- External findings push is included with Business tier.

### Disclaimer

```
THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.

Security audit tools inspect system configurations and may identify
sensitive information. The developer assumes no liability for:
- Issues arising from tool usage or misuse
- Decisions made based on audit results
- System changes implemented after audits
- Data exposed during security assessments

Users are responsible for:
- Testing in appropriate environments
- Reviewing results before taking action
- Maintaining proper backups
- Compliance with applicable laws and policies
```
