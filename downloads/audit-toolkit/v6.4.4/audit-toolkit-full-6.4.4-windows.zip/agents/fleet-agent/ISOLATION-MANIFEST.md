# Fleet Agent Isolation Manifest

This file defines the extraction and isolation boundary for the Fleet Agent.

## Goal

Keep Fleet Agent runtime logic self-contained so release packaging and future
repository extraction are path changes, not runtime rewrites.

## Canonical Boundary

Fleet implementation root:

- `agents/fleet-agent/`

Legacy source area retained for transition:

- `agents/html-standalone/`

## Guardrails

1. New Fleet runtime code must be added under `agents/fleet-agent/`.
2. Managed build packaging must source Fleet runtime files from this directory.
3. JEA and installer references must use `fleet-agent.ps1` and `fleet-agent.sh`.
4. Standalone packaging must not include Fleet runtime files.

## Verification

Run:

```powershell
python agents/fleet-agent/tools/check-isolation.py
```
