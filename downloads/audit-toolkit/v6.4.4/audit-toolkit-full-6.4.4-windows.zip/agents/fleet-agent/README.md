# Fleet Agent Runtime

This directory is the canonical source boundary for the Fleet Agent runtime.

## Scope

The Fleet Agent is the Core-managed runtime installed on target hosts to:

- run audit scripts locally
- collect and store results locally first
- receive orchestration directives from Core over API
- push or expose results to Core over API

## Product Boundary

This runtime is separate from:

- Core Server
- Standalone Agent

The Fleet Agent is not independently licensed. Capability and action scope are
controlled by Core-issued policy derived from Core licensing.

## Packaging Inputs

The managed build stage (`deployment/agents/_build/managed-*`) must source from
this directory, not from `agents/html-standalone/`.

Key runtime files:

- `fleet-agent.sh`
- `fleet-agent.ps1`
- `fleet-agent-api.py`
- `install-linux.sh`
- `install-user.sh`
- `install-windows.ps1`
- `setup-sudoers.sh`
- `jea/`
- `audits/`
- `lib/`
