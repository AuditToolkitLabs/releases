# Hypervisor Platform Audits

Security audits for standalone hypervisor platforms.

## Platform Categories

| Directory | Platform | Description |
|-----------|----------|-------------|
| `kvm/` | KVM/QEMU | Linux-based kernel virtualization |
| `esxi/` | VMware ESXi | Bare-metal hypervisor with VMkernel |
| `proxmox/` | Proxmox VE | Debian-based virtualization platform |
| `xen/` | XenServer/XCP-ng | Xen-based hypervisor platforms |
| `nutanix/` | Nutanix AHV | Nutanix Acropolis Hypervisor |

## Why Separate from Linux/Windows?

These platforms have:
- **Unique CLIs**: `virsh`, `esxcli`, `pvesh`, `xe`, `acli`
- **Custom APIs**: libvirt, vSphere, Proxmox REST, XAPI
- **Platform-specific security controls**: vSwitch policies, HA/DRS, storage encryption
- **Distinct compliance requirements**: CIS Benchmarks, VMware STIG, vendor hardening guides

## Audit Execution Methods

| Platform | Local | SSH | API |
|----------|-------|-----|-----|
| KVM/QEMU | ✓ | ✓ | libvirt |
| ESXi | ✓ | ✓ | vSphere API |
| Proxmox | ✓ | ✓ | REST API |
| XenServer | ✓ | ✓ | XAPI |
| Nutanix | - | ✓ | Prism API |

## Related Audits (Stay in Linux/Windows)

These remain in their native OS categories:
- **Hyper-V** → `audits/windows/server/hyperv.ps1`
- **VirtualBox** → `audits/windows/apps/` or `audits/linux/apps/`
- **VMware Workstation** → `audits/windows/apps/` or `audits/linux/apps/`

## Implementation Status

### Hypervisor Hosts

| Platform | Status | Scripts |
|----------|--------|---------|
| KVM/QEMU | ✅ Complete | [kvm-qemu-audit.sh](kvm/kvm-qemu-audit.sh) |
| ESXi | ✅ Complete | [vmware-esxi-audit.sh](esxi/vmware-esxi-audit.sh) |
| Proxmox | ✅ Complete | [proxmox-audit.sh](proxmox/proxmox-audit.sh) |
| XenServer | ✅ Complete | [xen-audit.sh](xen/xen-audit.sh) |
| Nutanix AHV | 🔲 Planned | - |

### Management Consoles (On-Appliance)

| Platform | Status | Scripts | Notes |
|----------|--------|---------|-------|
| vCenter/VCSA | ✅ Complete | [vcenter-audit.sh](esxi/vcenter-audit.sh) | Runs on VCSA appliance |
| XenOrchestra | ✅ Complete | [xenorchestra-audit.sh](xen/xenorchestra-audit.sh) | Runs on XO server |
| Nutanix Prism | ✅ Complete | [nutanix-prism-audit.sh](nutanix/nutanix-prism-audit.sh) | Runs on CVM |

### Cross-Platform API Audits (Remote Execution)

Run these from any Windows, Linux, or macOS workstation against remote management consoles.

| Platform | Language | Script | Requirements |
|----------|----------|--------|--------------|
| vCenter | PowerShell | [vcenter-powercli-audit.ps1](esxi/vcenter-powercli-audit.ps1) | PowerShell 7+, VMware.PowerCLI |
| vCenter | Python | [vcenter-api-audit.py](esxi/vcenter-api-audit.py) | Python 3.8+, requests |
| **ESXi** | Python | [esxi-api-audit.py](esxi/esxi-api-audit.py) | Python 3.8+, requests |
| **Proxmox VE** | Python | [proxmox-api-audit.py](proxmox/proxmox-api-audit.py) | Python 3.8+, requests |
| **XCP-ng/Xen** | Python | [xen-api-audit.py](xen/xen-api-audit.py) | Python 3.8+ (built-in xmlrpc) |
| **KVM/QEMU** | Python | [kvm-api-audit.py](kvm/kvm-api-audit.py) | Python 3.8+, libvirt-python |
| Nutanix | Python | [nutanix-api-audit.py](nutanix/nutanix-api-audit.py) | Python 3.8+, requests |
| XenOrchestra | Python | [xo-api-audit.py](xen/xo-api-audit.py) | Python 3.8+, requests |

## Authentication & Connection Guide

### When to Use SSH vs API

| Method | Best For | Drawbacks |
|--------|----------|-----------|
| **SSH/Local** | Full OS access, service files, logs | Requires SSH enabled, shell access |
| **REST API** | Lockdown mode, automation, remote | Limited to exposed API endpoints |
| **PowerCLI** | VMware-specific, bulk operations | Requires PowerCLI module |
| **libvirt** | KVM/QEMU programmatic access | Requires libvirt-python |
| **XAPI** | XenServer/XCP-ng native | XML-RPC complexity |

### Platform-Specific Authentication

#### VMware ESXi (Direct Host)
```bash
# SSH (requires SSH enabled)
ssh root@esxi-host ./vmware-esxi-audit.sh

# API (works with lockdown mode enabled)
python esxi-api-audit.py --server esxi-host --username root --insecure
```

#### VMware vCenter
```bash
# REST API (vSphere 7.0+)
python vcenter-api-audit.py --server vcenter.local --username administrator@vsphere.local

# PowerCLI (any version)
pwsh vcenter-powercli-audit.ps1 -Server vcenter.local
```

#### Proxmox VE
```bash
# SSH
ssh root@proxmox ./proxmox-audit.sh

# API with password
python proxmox-api-audit.py --server proxmox:8006 --username root@pam

# API with token (recommended for automation)
python proxmox-api-audit.py --server proxmox:8006 --token-id user@pam!audit --token-secret <secret>
```

#### XCP-ng / Citrix Hypervisor
```bash
# SSH
ssh root@xcp-ng ./xen-audit.sh

# XAPI (XML-RPC)
python xen-api-audit.py --server xcp-ng --username root --insecure
```

#### KVM/QEMU
```bash
# Local (on KVM host)
python kvm-api-audit.py

# Remote via SSH tunnel
python kvm-api-audit.py --host kvm-server --transport ssh --user root

# Remote via TLS (certificate auth)
python kvm-api-audit.py --host kvm-server --transport tls
```

### Permission Requirements

| Platform | SSH/Local | API |
|----------|-----------|-----|
| ESXi | root or Admin | Administrator or ReadOnly role |
| vCenter | - | administrator@vsphere.local or Admin role |
| Proxmox | root | PVEAdmin or Audit role |
| XCP-ng | root | pool-admin or pool-operator |
| KVM | root or libvirt group | Same as transport method |
| Nutanix | nutanix user | Cluster Admin or Viewer role |

### Security Considerations

1. **API tokens over passwords** - Proxmox, Nutanix, vCenter all support API tokens
2. **TLS verification** - Use `--insecure` only for testing
3. **Least privilege** - Use read-only roles for auditing
4. **Credential storage** - Use environment variables or vault integrations
5. **Audit logging** - API calls are logged; SSH sessions may not be

## Audit Scripts Overview

### KVM/QEMU (`kvm/kvm-qemu-audit.sh`)
- Libvirt service and configuration
- QEMU security settings (seccomp, user separation)
- SELinux/AppArmor sVirt profiles
- Network isolation and storage permissions
- VNC/SPICE TLS configuration

### VMware ESXi (`esxi/vmware-esxi-audit.sh`)
- SSH hardening and shell timeout
- Lockdown mode verification
- Service configuration
- Logging and syslog forwarding
- Network security (vSwitch, portgroups)

### VMware vCenter (`esxi/vcenter-audit.sh`)
- SSO/Identity configuration and password policies
- Certificate management and expiration
- Appliance services (vpxd, stsd, vpostgres)
- VAMI security and session timeout
- Backup configuration and encryption
- TLS/network security

### Proxmox VE (`proxmox/proxmox-audit.sh`)
- Web interface (pveproxy) TLS
- Cluster security and quorum
- User/permission management
- VM/container isolation
- Firewall and backup encryption

### Xen (`xen/xen-audit.sh`)
- XSM (Xen Security Modules) / Flask
- Dom0 hardening
- Guest isolation (IOMMU, memory)
- Stubdom usage
- Network bridge security

### XenOrchestra (`xen/xenorchestra-audit.sh`)
- HTTPS/TLS configuration
- LDAP/SAML/OIDC authentication
- Backup job encryption
- ACL and RBAC configuration
- Plugin and API security

### Nutanix Prism (`nutanix/nutanix-prism-audit.sh`)
- Cluster and CVM security
- LDAP/SAML authentication
- Data-at-rest encryption
- Protection domains and DR
- Flow microsegmentation policies
- RBAC and user management

## Cross-Platform API Scripts

### vCenter PowerCLI (`esxi/vcenter-powercli-audit.ps1`)
```powershell
# Windows/Linux/macOS with PowerShell 7+
pwsh vcenter-powercli-audit.ps1 -Server vcenter.example.com -Credential (Get-Credential)
```
- SSO configuration and password policies
- Certificate expiration (30/90 day warning)
- Host compliance (SSH, ESXi version)
- VM security (snapshots, tools, isolation)
- vSphere HA and DRS settings
- vSwitch security policies

### vCenter REST API (`esxi/vcenter-api-audit.py`)
```bash
python vcenter-api-audit.py --server vcenter.example.com --username administrator@vsphere.local
```
- vSphere 7.0+ REST API
- Appliance health and services
- NTP and Syslog configuration
- Local accounts (non-SSO)
- Host and VM inventory
- Storage and network configuration

### Nutanix Prism API (`nutanix/nutanix-api-audit.py`)
```bash
python nutanix-api-audit.py --server prism.example.com --username admin
```
- Uses Prism v2/v3 REST APIs
- Cluster and host configuration
- Authentication providers (LDAP, SAML)
- RBAC users and roles
- Protection domains and snapshots
- SSL certificate validation

### XenOrchestra API (`xen/xo-api-audit.py`)

```bash
python xo-api-audit.py --server xo.example.com --username admin@admin.net
```

- JSON-RPC API over HTTPS
- User management and RBAC
- Connected Xen server security
- Backup jobs and encryption
- Authentication plugins (LDAP, SAML, GitHub)
- API token management

### ESXi REST API (`esxi/esxi-api-audit.py`)

```bash
# Works even with SSH disabled / lockdown mode enabled
python esxi-api-audit.py --server esxi-host --username root --insecure
```

- VMware ESXi REST API (6.5+)
- CIS Benchmark Sections 1-9 coverage
- SSH and shell timeout settings
- Lockdown mode verification
- DCUI access and MOB disable
- NTP, syslog, network security
- VIB acceptance levels and certificates

### Proxmox VE REST API (`proxmox/proxmox-api-audit.py`)

```bash
# Password authentication
python proxmox-api-audit.py --server pve.example.com --username root@pam

# API token authentication (recommended)
python proxmox-api-audit.py --server pve.example.com \
  --token-id user@pam!audit --token-secret <secret>
```

- Proxmox VE REST API on port 8006
- Cluster information and quorum
- Authentication and 2FA status
- User/group RBAC configuration
- Cluster and node firewall
- VM and container security (unprivileged CTs)
- Backup jobs and PBS integration
- High Availability configuration

### XCP-ng / Xen XAPI (`xen/xen-api-audit.py`)

```bash
python xen-api-audit.py --server xcp-ng --username root --insecure
```

- Native XAPI (XML-RPC) protocol
- Pool and host configuration
- External authentication (LDAP/AD)
- Network and storage security
- VM and Dom0 configuration
- Certificate and patch status
- High Availability settings

### KVM libvirt API (`kvm/kvm-api-audit.py`)

```bash
# Local audit
python kvm-api-audit.py

# Remote via SSH
python kvm-api-audit.py --host kvm-server --transport ssh --user root

# Remote via TLS
python kvm-api-audit.py --host kvm-server --transport tls
```

- libvirt Python bindings
- SELinux/AppArmor (sVirt) verification
- VM security labels and memory balloon
- Virtual network isolation
- Storage pool permissions
- Network filters (nwfilters)
- PCI/USB passthrough audit
- Snapshot retention review

---

## Multi-Host Auditing

For auditing multiple hypervisor hosts, use the dedicated runner:

```bash
# Single host
python orchestrator/hypervisor-audit-runner.py --host esxi01.local --type esxi --user root

# Multiple hosts from inventory file
python orchestrator/hypervisor-audit-runner.py --inventory settings/hypervisors.yml

# Filter by platform
python orchestrator/hypervisor-audit-runner.py --inventory settings/hypervisors.yml --platform proxmox,esxi

# Export results
python orchestrator/hypervisor-audit-runner.py --inventory settings/hypervisors.yml --output results.json
```

See `settings/hypervisors.yml.example` for inventory file format.

---
**Document Version:** 3.0
**Updated:** February 2025
