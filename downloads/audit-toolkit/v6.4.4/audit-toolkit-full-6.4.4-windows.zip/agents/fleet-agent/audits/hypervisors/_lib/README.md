# Hypervisor Audit Libraries

Standalone library functions for hypervisor security audits. These libraries are independent of the root `lib/` directory, allowing hypervisor audits to run as a self-contained module.

## Library Files

| File | Description |
|------|-------------|
| `common.sh` | Output formatting, color codes, check registration, summary |
| `distro.sh` | Linux distro detection, init system, security stack (SELinux/AppArmor) |
| `hypervisor.sh` | Platform detection (KVM, ESXi, Proxmox, Xen, Nutanix), platform-specific utilities |

## Usage

From any audit script under `audits/hypervisors/<platform>/`:

```bash
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "My Audit Section"
register_check "Check Name" PASS "Description"

print_summary
exit "$EXIT_CODE"
```

## Available Functions

### common.sh

| Function | Description |
|----------|-------------|
| `setup_colors` | Initialize terminal colors (auto-detects TTY) |
| `section "Title"` | Print section header |
| `register_check NAME STATUS [MSG]` | Register check result (PASS/WARN/FAIL/SKIP) |
| `print_summary` | Print totals table |
| `info/warn/error/success MSG` | Colored output helpers |

### distro.sh

| Function | Description |
|----------|-------------|
| `detect_distro` | Returns distro ID (ubuntu, rhel, alpine, etc.) |
| `is_systemd` | True if systemd is in use |
| `is_openrc` | True if OpenRC is in use |
| `has_selinux` | True if SELinux is available |
| `has_apparmor` | True if AppArmor is available |
| `svc_is_active SVC` | Check if service is running |
| `svc_is_enabled SVC` | Check if service is enabled |
| `pkg_installed PKG` | Check if package is installed |

### hypervisor.sh

| Function | Description |
|----------|-------------|
| `detect_hypervisor` | Returns: kvm, esxi, proxmox, xen, nutanix, unknown |
| `is_esxi`, `is_proxmox`, `is_xen`, `is_kvm`, `is_nutanix` | Boolean checks |
| `esxi_version`, `proxmox_version`, `xen_version`, `kvm_version` | Get platform version |
| `get_virtual_networks` | List virtual switches/bridges (cross-platform) |
| `get_storage_pools` | List storage pools/datastores (cross-platform) |
| `get_running_guests` | List running VMs (cross-platform) |

## Independence from Root lib/

These libraries duplicate core functionality from `lib/` to allow:

1. **Standalone deployment** - Copy just `audits/hypervisors/` to audit a host
2. **Version isolation** - Hypervisor audits can evolve independently
3. **Minimal dependencies** - Only Bash 4+ and coreutils required

The root `lib/` remains the canonical source for Linux/Windows host audits.
