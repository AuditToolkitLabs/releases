#!/usr/bin/env bash
# Hypervisor Audits - Common Library (Standalone)
# This is a self-contained version for independent hypervisor audit distribution
set -euo pipefail

: "${LOG_FILE:=}"
: "${QUIET:=false}"
: "${VERBOSE:=false}"
: "${VERY_VERBOSE:=false}"
: "${NO_COLOR:=false}"
: "${JSON_OUTPUT:=}"
: "${JSON_PRETTY:=false}"

# License token validation bypass (for development/testing only)
# Set AUDIT_SKIP_LICENSE_CHECK=1 to bypass in development environments
: "${AUDIT_SKIP_LICENSE_CHECK:=0}"

EXIT_CODE=0
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0

# ────────────────────────────────────────────────────────────────────────────────
# License Token Validation
# ────────────────────────────────────────────────────────────────────────────────
# Hypervisor audits require a valid license token to run. Token is machine-bound
# and time-limited, preventing unauthorized use of extracted scripts.
# ────────────────────────────────────────────────────────────────────────────────
_validate_license() {
  if [[ "$AUDIT_SKIP_LICENSE_CHECK" == "1" ]] || [[ "$AUDIT_SKIP_LICENSE_CHECK" == "true" ]]; then
    return 0
  fi

  local script_dir repo_root token_lib
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  repo_root="$(cd "${script_dir}/../../.." && pwd)"

  if [[ -f "${script_dir}/token.sh" ]]; then
    token_lib="${script_dir}/token.sh"
  elif [[ -f "${repo_root}/lib/token.sh" ]]; then
    token_lib="${repo_root}/lib/token.sh"
  fi

  if [[ -n "${token_lib:-}" ]]; then
    # shellcheck source=agents/fleet-agent/lib/token.sh
    . "$token_lib"
    require_license_token
  fi
}

_validate_license

# ────────────────────────────────────────────────────────────────────────────────
# Color Setup
# ────────────────────────────────────────────────────────────────────────────────
setup_colors() {
  if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then
    RED=""; GREEN=""; YELLOW=""; BLUE=""; CYAN=""; BOLD=""; NC=""
  else
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'
    BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
  fi
}

# ────────────────────────────────────────────────────────────────────────────────
# Logging
# ────────────────────────────────────────────────────────────────────────────────
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }

_log() {
  local level="$1"; shift
  local msg="$*"
  local line
  printf -v line '[%s] [%s] %s' "$(_timestamp)" "$level" "$msg"
  if [[ -n "$LOG_FILE" ]]; then echo "$line" >> "$LOG_FILE" 2>/dev/null || :; fi
  if [[ "$QUIET" != "true" ]]; then
    case "$level" in
      ERROR|WARN) echo "$line" >&2 ;;
      DEBUG) [[ "$VERBOSE" == "true" ]] && echo "$line" ;;
      TRACE) [[ "$VERY_VERBOSE" == "true" ]] && echo "$line" ;;
      *) echo "$line" ;;
    esac
  fi
}

warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
info() { echo -e "${BLUE}[INFO]${NC} $*"; }

# ────────────────────────────────────────────────────────────────────────────────
# Privilege Checks
# ────────────────────────────────────────────────────────────────────────────────
check_root_warn() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    warn "Not running as root/sudo (some checks may be limited)"
    return 1
  fi
  return 0
}

check_root_required() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    error "This script requires root privileges"
    exit 1
  fi
}

check_root_register() {
  local msg="${1:-Run as root for complete results}"
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    register_check "Root privileges" WARN "$msg"
    return 1
  else
    register_check "Root privileges" PASS "Running as root"
    return 0
  fi
}

# ────────────────────────────────────────────────────────────────────────────────
# Check Registration
# ────────────────────────────────────────────────────────────────────────────────
register_check() {
  local name="$1" result="$2" message="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS+1))
  case "$result" in
    PASS) PASSED_CHECKS=$((PASSED_CHECKS+1)); echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}" ;;
    FAIL) FAILED_CHECKS=$((FAILED_CHECKS+1)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC} $name${message:+: $message}" ;;
    WARN) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
    SKIP) SKIPPED_CHECKS=$((SKIPPED_CHECKS+1)); echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}" ;;
    *) WARNING_CHECKS=$((WARNING_CHECKS+1)); [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
  esac
  if [[ -n "$LOG_FILE" ]]; then echo "[$(_timestamp)] [$result] $name${message:+: $message}" >> "$LOG_FILE" 2>/dev/null || :; fi
}

# ────────────────────────────────────────────────────────────────────────────────
# JSON Output Helpers
# ────────────────────────────────────────────────────────────────────────────────
_json_escape() {
  local s="$1"
  s="${s//\\/\\\\}"
  s="${s//\"/\\\"}"
  s="${s//$'\n'/\\n}"
  s="${s//$'\r'/\\r}"
  s="${s//$'\t'/\\t}"
  printf '%s' "$s"
}

_json_init() {
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    printf '{"audit_start":"%s","hostname":"%s","platform":"%s","checks":[' \
      "$(date -Iseconds)" "$(hostname -f 2>/dev/null || hostname)" "${HYPERVISOR_PLATFORM:-unknown}" > "$JSON_OUTPUT"
    _JSON_FIRST_CHECK=true
  fi
}

_json_finalize() {
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    printf '],"audit_end":"%s","summary":{"total":%d,"passed":%d,"failed":%d,"warnings":%d,"skipped":%d,"exit_code":%d}}\n' \
      "$(date -Iseconds)" "$TOTAL_CHECKS" "$PASSED_CHECKS" "$FAILED_CHECKS" "$WARNING_CHECKS" "$SKIPPED_CHECKS" "$EXIT_CODE" >> "$JSON_OUTPUT"
  fi
}

register_check_json() {
  local name="$1" result="$2" message="${3:-}" severity="${4:-MEDIUM}"
  register_check "$name" "$result" "$message"
  if [[ -n "${JSON_OUTPUT:-}" ]]; then
    local json_name json_msg json_sev
    json_name=$(_json_escape "$name")
    json_msg=$(_json_escape "$message")
    json_sev=$(_json_escape "$severity")
    if [[ "${_JSON_FIRST_CHECK:-true}" == "true" ]]; then
      _JSON_FIRST_CHECK=false
    else
      printf ',' >> "$JSON_OUTPUT"
    fi
    printf '{"check":"%s","result":"%s","message":"%s","severity":"%s","timestamp":"%s"}' \
      "$json_name" "$result" "$json_msg" "$json_sev" "$(date -Iseconds)" >> "$JSON_OUTPUT"
  fi
}

# ────────────────────────────────────────────────────────────────────────────────
# Section and Summary
# ────────────────────────────────────────────────────────────────────────────────
section() {
  local title="$1"
  echo
  printf "%b\n" "${BOLD}${CYAN}============================================================${NC}"
  printf "%b\n" "${BOLD}${CYAN} $title${NC}"
  printf "%b\n" "${BOLD}${CYAN}============================================================${NC}"
  if [[ -n "$LOG_FILE" ]]; then { echo; echo "=== $title ==="; } >> "$LOG_FILE" 2>/dev/null || :; fi
}

print_summary() {
  echo
  printf "%b\n" "${BOLD}+==========================================================+${NC}"
  printf "%b\n" "${BOLD} HYPERVISOR AUDIT SUMMARY ${NC}"
  printf "%b\n" "${BOLD}+==========================================================+${NC}"
  printf "%b\n" " Hostname: $(hostname -f 2>/dev/null || hostname)"
  printf "%b\n" " Platform: ${HYPERVISOR_PLATFORM:-unknown}"
  printf "%b\n" " Date:     $(date '+%Y-%m-%d %H:%M:%S')"
  printf "%b\n" "${BOLD}+----------------------+----------------------+----------------------+${NC}"
  printf " %b %-6d %b %-6d %s\n"     "${GREEN}✓ PASSED:${NC}"   "$PASSED_CHECKS"     "${RED}✗ FAILED:${NC}"   "$FAILED_CHECKS"     ""
  printf " %b %-6d %b %-6d %s\n"     "${YELLOW}⚠ WARNINGS:${NC}" "$WARNING_CHECKS"     "${BLUE}▷ SKIPPED:${NC}"  "$SKIPPED_CHECKS"     ""
  printf "%b\n" "${BOLD}+----------------------+----------------------+----------------------+${NC}"
  printf " TOTAL CHECKS: %-6d\n" "$TOTAL_CHECKS"
  printf "%b\n" "${BOLD}+==========================================================+${NC}"

  # Finalize JSON if enabled
  _json_finalize
}

# Initialize colors on source
setup_colors
