#!/usr/bin/env bash
# distro.sh - Minimal distro detection for hypervisor audits
# Standalone library - no dependencies on root lib/

set -euo pipefail

# ============================================================================
# DISTRO DETECTION
# ============================================================================

# Detect Linux distribution
# Returns lowercase ID from /etc/os-release
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        echo "${ID:-unknown}" | tr '[:upper:]' '[:lower:]'
    elif [[ -f /etc/redhat-release ]]; then
        echo "rhel"
    elif [[ -f /etc/debian_version ]]; then
        echo "debian"
    else
        echo "unknown"
    fi
}

# Get distro version
get_distro_version() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        echo "${VERSION_ID:-unknown}"
    else
        echo "unknown"
    fi
}

# ============================================================================
# INIT SYSTEM DETECTION
# ============================================================================

# Check if system uses systemd
is_systemd() {
    [[ -d /run/systemd/system ]] || command -v systemctl >/dev/null 2>&1
}

# Check if system uses OpenRC
is_openrc() {
    command -v rc-service >/dev/null 2>&1 && [[ -d /etc/runlevels ]]
}

# Check if system uses SysVinit
is_sysvinit() {
    [[ -f /etc/inittab ]] && ! is_systemd && ! is_openrc
}

# ============================================================================
# SECURITY STACK DETECTION
# ============================================================================

# Check if SELinux is available
has_selinux() {
    command -v getenforce >/dev/null 2>&1 && [[ -d /sys/fs/selinux ]]
}

# Check if AppArmor is available
has_apparmor() {
    command -v apparmor_status >/dev/null 2>&1 && [[ -d /sys/kernel/security/apparmor ]]
}

# Get SELinux mode (enforcing, permissive, disabled)
get_selinux_mode() {
    if has_selinux; then
        getenforce 2>/dev/null | tr '[:upper:]' '[:lower:]'
    else
        echo "disabled"
    fi
}

# Get AppArmor mode
get_apparmor_mode() {
    if has_apparmor; then
        if apparmor_status 2>/dev/null | grep -q "profiles are in enforce mode"; then
            echo "enforce"
        elif apparmor_status 2>/dev/null | grep -q "profiles are in complain mode"; then
            echo "complain"
        else
            echo "loaded"
        fi
    else
        echo "disabled"
    fi
}

# ============================================================================
# SERVICE MANAGEMENT (Cross-init)
# ============================================================================

# Check if service is active/running
svc_is_active() {
    local svc="$1"
    if is_systemd; then
        systemctl is-active "$svc" >/dev/null 2>&1
    elif is_openrc; then
        rc-service "$svc" status >/dev/null 2>&1
    else
        service "$svc" status >/dev/null 2>&1
    fi
}

# Check if service is enabled
svc_is_enabled() {
    local svc="$1"
    if is_systemd; then
        systemctl is-enabled "$svc" >/dev/null 2>&1
    elif is_openrc; then
        rc-update show default 2>/dev/null | grep -q "$svc"
    else
        chkconfig --list "$svc" 2>/dev/null | grep -q "3:on"
    fi
}

# ============================================================================
# PACKAGE MANAGEMENT
# ============================================================================

# Check if package is installed
pkg_installed() {
    local pkg="$1"
    local distro
    distro=$(detect_distro)
    
    case "$distro" in
        ubuntu|debian|proxmox)
            dpkg -l "$pkg" 2>/dev/null | grep -q "^ii"
            ;;
        rhel|centos|fedora|rocky|alma)
            rpm -q "$pkg" >/dev/null 2>&1
            ;;
        arch|manjaro)
            pacman -Q "$pkg" >/dev/null 2>&1
            ;;
        alpine)
            apk info -e "$pkg" >/dev/null 2>&1
            ;;
        opensuse*|sles)
            rpm -q "$pkg" >/dev/null 2>&1
            ;;
        *)
            command -v "$pkg" >/dev/null 2>&1
            ;;
    esac
}
