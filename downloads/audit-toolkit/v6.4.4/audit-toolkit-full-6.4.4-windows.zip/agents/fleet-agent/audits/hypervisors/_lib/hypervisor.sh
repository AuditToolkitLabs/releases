#!/usr/bin/env bash
# hypervisor.sh - Hypervisor platform detection and utilities
# Standalone library for hypervisor audits

set -euo pipefail

# ============================================================================
# PLATFORM DETECTION
# ============================================================================

# Detect hypervisor platform
# Returns: kvm, esxi, proxmox, xen, nutanix, hyper-v, unknown
detect_hypervisor() {
    # ESXi detection
    if command -v esxcli >/dev/null 2>&1; then
        echo "esxi"
        return 0
    fi
    
    # Proxmox detection (check before generic KVM)
    if command -v pvesh >/dev/null 2>&1 || [[ -f /etc/pve/pve-root-ca.pem ]]; then
        echo "proxmox"
        return 0
    fi
    
    # Xen detection
    if command -v xe >/dev/null 2>&1 || command -v xl >/dev/null 2>&1; then
        echo "xen"
        return 0
    fi
    
    # Nutanix detection
    if command -v acli >/dev/null 2>&1 || [[ -f /etc/nutanix/cluster_id ]]; then
        echo "nutanix"
        return 0
    fi
    
    # KVM/QEMU detection (most generic, check last)
    if command -v virsh >/dev/null 2>&1; then
        echo "kvm"
        return 0
    fi
    
    # Hyper-V detection (Windows)
    if command -v Get-VM >/dev/null 2>&1 2>&1; then
        echo "hyper-v"
        return 0
    fi
    
    echo "unknown"
    return 1
}

# Check if running on specific hypervisor
is_esxi()    { [[ "$(detect_hypervisor)" == "esxi" ]]; }
is_proxmox() { [[ "$(detect_hypervisor)" == "proxmox" ]]; }
is_xen()     { [[ "$(detect_hypervisor)" == "xen" ]]; }
is_kvm()     { [[ "$(detect_hypervisor)" == "kvm" ]]; }
is_nutanix() { [[ "$(detect_hypervisor)" == "nutanix" ]]; }

# ============================================================================
# ESXI UTILITIES
# ============================================================================

esxi_version() {
    if command -v esxcli >/dev/null 2>&1; then
        esxcli system version get 2>/dev/null | grep -i "version" | head -1 | awk '{print $2}'
    fi
}

esxi_get_config() {
    local key="$1"
    esxcli system settings advanced list -o "$key" 2>/dev/null | grep -i "value" | awk '{print $2}'
}

esxi_service_running() {
    local svc="$1"
    /etc/init.d/"$svc" status 2>/dev/null | grep -qi "running"
}

# ============================================================================
# PROXMOX UTILITIES
# ============================================================================

proxmox_version() {
    if command -v pveversion >/dev/null 2>&1; then
        pveversion 2>/dev/null | awk -F'/' '{print $2}' | cut -d'-' -f1
    fi
}

proxmox_api_get() {
    local path="$1"
    pvesh get "$path" --output-format json 2>/dev/null
}

proxmox_cluster_status() {
    pvesh get /cluster/status --output-format json 2>/dev/null
}

proxmox_node_list() {
    pvesh get /nodes --output-format json 2>/dev/null | grep -o '"node":"[^"]*"' | cut -d'"' -f4
}

# ============================================================================
# XEN UTILITIES
# ============================================================================

xen_version() {
    if command -v xl >/dev/null 2>&1; then
        xl info 2>/dev/null | grep "xen_version" | awk '{print $3}'
    elif command -v xe >/dev/null 2>&1; then
        xe host-list params=software-version 2>/dev/null | grep "xen" | head -1
    fi
}

xen_dom0_memory() {
    xl info 2>/dev/null | grep "total_memory" | awk '{print $3}'
}

xen_list_vms() {
    if command -v xl >/dev/null 2>&1; then
        xl list 2>/dev/null | tail -n +2 | awk '{print $1}'
    elif command -v xe >/dev/null 2>&1; then
        xe vm-list --minimal 2>/dev/null | tr ',' '\n'
    fi
}

xen_xsm_enabled() {
    xl info 2>/dev/null | grep -qi "xsm.*enabled"
}

# ============================================================================
# KVM/QEMU UTILITIES
# ============================================================================

kvm_version() {
    if command -v virsh >/dev/null 2>&1; then
        virsh version --daemon 2>/dev/null | grep "libvirt" | head -1 | awk '{print $3}'
    fi
}

kvm_list_vms() {
    virsh list --all --name 2>/dev/null | grep -v "^$"
}

kvm_get_vm_xml() {
    local vm="$1"
    virsh dumpxml "$vm" 2>/dev/null
}

kvm_connection_uri() {
    virsh uri 2>/dev/null
}

kvm_qemu_version() {
    if command -v qemu-system-x86_64 >/dev/null 2>&1; then
        qemu-system-x86_64 --version 2>/dev/null | head -1 | awk '{print $4}'
    fi
}

# ============================================================================
# NUTANIX UTILITIES
# ============================================================================

nutanix_version() {
    if [[ -f /etc/nutanix/release_version ]]; then
        cat /etc/nutanix/release_version 2>/dev/null
    fi
}

nutanix_cluster_id() {
    if [[ -f /etc/nutanix/cluster_id ]]; then
        cat /etc/nutanix/cluster_id 2>/dev/null
    fi
}

nutanix_acli() {
    local cmd="$1"
    acli "$cmd" 2>/dev/null
}

# ============================================================================
# NETWORK UTILITIES (Cross-platform)
# ============================================================================

# Get virtual switches/bridges
get_virtual_networks() {
    local platform
    platform=$(detect_hypervisor)
    
    case "$platform" in
        esxi)
            esxcli network vswitch standard list 2>/dev/null | grep "Name:" | awk '{print $2}'
            ;;
        proxmox)
            pvesh get /nodes/localhost/network --output-format json 2>/dev/null | grep -o '"iface":"[^"]*"' | cut -d'"' -f4
            ;;
        xen)
            xe network-list params=name-label --minimal 2>/dev/null | tr ',' '\n'
            ;;
        kvm)
            virsh net-list --all --name 2>/dev/null | grep -v "^$"
            ;;
        *)
            return 1
            ;;
    esac
}

# Get storage pools/datastores
get_storage_pools() {
    local platform
    platform=$(detect_hypervisor)
    
    case "$platform" in
        esxi)
            esxcli storage filesystem list 2>/dev/null | tail -n +3 | awk '{print $2}'
            ;;
        proxmox)
            pvesh get /storage --output-format json 2>/dev/null | grep -o '"storage":"[^"]*"' | cut -d'"' -f4
            ;;
        xen)
            xe sr-list params=name-label --minimal 2>/dev/null | tr ',' '\n'
            ;;
        kvm)
            virsh pool-list --all --name 2>/dev/null | grep -v "^$"
            ;;
        *)
            return 1
            ;;
    esac
}

# ============================================================================
# SECURITY CHECKING HELPERS
# ============================================================================

# Check if a security feature is enabled
check_security_feature() {
    local feature="$1"
    local platform
    platform=$(detect_hypervisor)
    
    case "$platform:$feature" in
        esxi:lockdown)
            esxcli system settings advanced list -o /UserVars/ESXiShellInteractiveTimeOut 2>/dev/null | grep -q "0" && return 1
            return 0
            ;;
        proxmox:2fa)
            pvesh get /access/tfa --output-format json 2>/dev/null | grep -q '"type"' && return 0
            return 1
            ;;
        xen:xsm)
            xen_xsm_enabled && return 0
            return 1
            ;;
        kvm:selinux)
            [[ -f /etc/libvirt/qemu.conf ]] && grep -q 'security_driver.*selinux' /etc/libvirt/qemu.conf && return 0
            return 1
            ;;
        *)
            return 1
            ;;
    esac
}

# Get list of running VMs/guests
get_running_guests() {
    local platform
    platform=$(detect_hypervisor)
    
    case "$platform" in
        esxi)
            esxcli vm process list 2>/dev/null | grep "Display Name:" | awk -F': ' '{print $2}'
            ;;
        proxmox)
            pvesh get /cluster/resources --type vm --output-format json 2>/dev/null | grep -o '"name":"[^"]*"' | cut -d'"' -f4
            ;;
        xen)
            xl list 2>/dev/null | tail -n +2 | grep -v "Domain-0" | awk '{print $1}'
            ;;
        kvm)
            virsh list --name 2>/dev/null | grep -v "^$"
            ;;
        nutanix)
            acli vm.list power_state=on 2>/dev/null | tail -n +2 | awk '{print $1}'
            ;;
        *)
            return 1
            ;;
    esac
}
