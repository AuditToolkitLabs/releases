# VMware ESXi Security Audits

Security audits for VMware ESXi bare-metal hypervisor.

## Execution Methods

1. **Local** - Run directly on ESXi shell (requires SSH enabled)
2. **Remote SSH** - Execute via SSH from management host
3. **PowerCLI** - Use VMware PowerCLI from Windows/Linux
4. **vSphere API** - REST/SOAP API calls

## Planned Audits

### esxi-baseline-audit.sh
Core ESXi hardening checks:
- [ ] SSH daemon configuration (`/etc/ssh/sshd_config`)
- [ ] Shell timeout settings
- [ ] DCUI timeout
- [ ] Lockdown mode status
- [ ] Password complexity
- [ ] Account lockout policy
- [ ] NTP/chrony configuration
- [ ] Syslog forwarding
- [ ] SNMP configuration

### esxi-network-audit.sh
Virtual networking security:
- [ ] vSwitch security policy (promiscuous, MAC changes, forged transmits)
- [ ] Port group VLAN configuration
- [ ] VMkernel isolation
- [ ] Management network separation
- [ ] Distributed switch security (if applicable)
- [ ] Traffic shaping policies

### esxi-storage-audit.sh
Storage security checks:
- [ ] iSCSI CHAP authentication
- [ ] NFS security (Kerberos, no_root_squash)
- [ ] VMFS permissions
- [ ] vSAN encryption (if applicable)
- [ ] Datastore access control

### esxi-vm-audit.sh
Virtual machine security:
- [ ] VM encryption status
- [ ] Secure Boot enabled
- [ ] vTPM configured
- [ ] Guest isolation settings
- [ ] VMX file permissions
- [ ] Connected devices (CD/USB)
- [ ] Copy/paste disabled

### esxi-patch-audit.sh
Patch and update status:
- [ ] ESXi version/build
- [ ] VIB inventory
- [ ] Pending patches
- [ ] Image profile
- [ ] vCenter connection status

## CIS Benchmark Mapping

Based on **CIS VMware ESXi 7.0 Benchmark**:
- Section 1: Install and Patches
- Section 2: Communication
- Section 3: Logging
- Section 4: Access
- Section 5: Console
- Section 6: Virtual Machines
- Section 7: vNetwork

## Key Commands Reference

```bash
# System info
esxcli system version get
esxcli system settings advanced list

# Network
esxcli network vswitch standard list
esxcli network vswitch standard policy security get -v vSwitch0

# Services
esxcli system settings advanced list -o /UserVars/ESXiShellTimeOut
esxcli system settings advanced list -o /UserVars/SuppressShellWarning

# Accounts
esxcli system account list
esxcli system permission list

# Firewall
esxcli network firewall ruleset list
esxcli network firewall get

# VIBs/Patches
esxcli software vib list
esxcli software profile get
```

## Implementation Notes

- ESXi uses BusyBox shell (limited Bash features)
- Many checks require root access
- Consider using PowerCLI for bulk auditing
- vCenter provides centralized policy enforcement
