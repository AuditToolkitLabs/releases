﻿#Requires -Modules VMware.PowerCLI
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Audit output intentionally uses formatted console markers for operators.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPositionalParameters', '', Justification='Existing audit script call style is retained to avoid broad non-functional churn.')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseBOMForUnicodeEncodedFile', '', Justification='Repository standardizes UTF-8 without BOM for cross-platform compatibility.')]
<#
.SYNOPSIS
    VMware vCenter Security Audit via PowerCLI

.DESCRIPTION
    Cross-platform security audit for vCenter Server using PowerCLI.
    Can run from Windows, Linux, or macOS with PowerShell 7+ and PowerCLI installed.

.PARAMETER Server
    vCenter Server hostname or IP address

.PARAMETER Credential
    PSCredential object. If not provided, will prompt for credentials.

.PARAMETER SkipCertificateCheck
    Skip SSL certificate validation (not recommended for production)

.EXAMPLE
    .\vcenter-powercli-audit.ps1 -Server vcenter.example.com

.EXAMPLE
    $cred = Get-Credential
    .\vcenter-powercli-audit.ps1 -Server vcenter.example.com -Credential $cred

.NOTES
    Compliance Mapping:
    - CIS VMware vCenter Benchmark
    - VMware Security Hardening Guide
    - NIST SP 800-53: AC-2, AC-6, AU-2
    - PCI DSS: 8.1, 10.1
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Server,

    [Parameter(Mandatory = $false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory = $false)]
    [switch]$SkipCertificateCheck
)

# ============================================================================
# CONFIGURATION
# ============================================================================

$ErrorActionPreference = "Continue"
$script:PassCount = 0
$script:WarnCount = 0
$script:FailCount = 0
$script:SkipCount = 0

# ============================================================================
# OUTPUT FUNCTIONS
# ============================================================================

function Write-Section {
    param([string]$Title)
    Write-Output "`n=== $Title ==="
}

function Register-Check {
    param(
        [string]$Name,
        [ValidateSet("PASS", "WARN", "FAIL", "SKIP")]
        [string]$Status,
        [string]$Message = ""
    )

    $null = switch ($Status) {
        "PASS" { "Green"; $script:PassCount++ }
        "WARN" { "Yellow"; $script:WarnCount++ }
        "FAIL" { "Red"; $script:FailCount++ }
        "SKIP" { "DarkGray"; $script:SkipCount++ }
    }

    $output = "[$Status] $Name"
    if ($Message) { $output += ": $Message" }
    Write-Output $output
}

function Write-Summary {
    Write-Output "`n=== Summary ==="
    Write-Output "PASS: $script:PassCount"
    Write-Output "WARN: $script:WarnCount"
    Write-Output "FAIL: $script:FailCount"
    Write-Output "SKIP: $script:SkipCount"

    $total = $script:PassCount + $script:WarnCount + $script:FailCount + $script:SkipCount
    Write-Output "Total: $total checks"
}

# ============================================================================
# MAIN AUDIT
# ============================================================================

Write-Section "vCenter Connection"

# Check PowerCLI module
if (-not (Get-Module -ListAvailable VMware.PowerCLI)) {
    Write-Output "ERROR: VMware.PowerCLI module not installed"
    Write-Output "Install with: Install-Module VMware.PowerCLI -Scope CurrentUser"
    exit 1
}

# Suppress CEIP prompt
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false -ErrorAction SilentlyContinue | Out-Null

# Handle certificate validation
if ($SkipCertificateCheck) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
    Register-Check "Certificate validation" "WARN" "disabled (SkipCertificateCheck)"
} else {
    Set-PowerCLIConfiguration -InvalidCertificateAction Fail -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
    Register-Check "Certificate validation" "PASS" "enabled"
}

# Connect to vCenter
try {
    if ($Credential) {
        $connection = Connect-VIServer -Server $Server -Credential $Credential -ErrorAction Stop
    } else {
        $connection = Connect-VIServer -Server $Server -ErrorAction Stop
    }
    Register-Check "vCenter connection" "PASS" "$($connection.Name) v$($connection.Version)"
} catch {
    Register-Check "vCenter connection" "FAIL" $_.Exception.Message
    exit 1
}

# ============================================================================
Write-Section "vCenter Configuration"
# ============================================================================

# Get vCenter info
try {
    $null = Get-View ServiceInstance
    $null = Get-AdvancedSetting -Entity $connection.Name -ErrorAction SilentlyContinue

    # Check vCenter version
    $vcVersion = $connection.Version
    $majorVersion = [int]($vcVersion.Split('.')[0])
    if ($majorVersion -ge 7) {
        Register-Check "vCenter version" "PASS" "$vcVersion (current)"
    } elseif ($majorVersion -ge 6) {
        Register-Check "vCenter version" "WARN" "$vcVersion (consider upgrade to 7.x/8.x)"
    } else {
        Register-Check "vCenter version" "FAIL" "$vcVersion (EOL)"
    }
} catch {
    Register-Check "vCenter info" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "SSO/Identity Security"
# ============================================================================

try {
    # Get SSO configuration
    $ssoAdmin = Get-SsoAdminServer -ErrorAction SilentlyContinue
    if ($ssoAdmin) {
        Register-Check "SSO Server" "PASS" "connected"

        # Check identity sources
        $identitySources = Get-SsoIdentitySource -ErrorAction SilentlyContinue
        $adSources = $identitySources | Where-Object { $_.Type -match "ActiveDirectory|LDAP" }

        if ($adSources) {
            Register-Check "External identity source" "PASS" "$($adSources.Count) AD/LDAP source(s)"
        } else {
            Register-Check "External identity source" "WARN" "local SSO only"
        }

        # Check password policy
        $pwdPolicy = Get-SsoPasswordPolicy -ErrorAction SilentlyContinue
        if ($pwdPolicy) {
            if ($pwdPolicy.MinLength -ge 12) {
                Register-Check "SSO password length" "PASS" "min $($pwdPolicy.MinLength) chars"
            } else {
                Register-Check "SSO password length" "WARN" "min $($pwdPolicy.MinLength) chars (recommend 12+)"
            }

            if ($pwdPolicy.MaxFailedAttempts -le 5) {
                Register-Check "SSO lockout threshold" "PASS" "$($pwdPolicy.MaxFailedAttempts) attempts"
            } else {
                Register-Check "SSO lockout threshold" "WARN" "$($pwdPolicy.MaxFailedAttempts) attempts (recommend ≤5)"
            }
        }

        # Check lockout policy
        $lockoutPolicy = Get-SsoLockoutPolicy -ErrorAction SilentlyContinue
        if ($lockoutPolicy) {
            Register-Check "SSO lockout policy" "PASS" "configured"
        }
    } else {
        Register-Check "SSO configuration" "SKIP" "SSO admin module not available"
    }
} catch {
    Register-Check "SSO configuration" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Account Security"
# ============================================================================

try {
    # Get all permissions
    $permissions = Get-VIPermission

    # Count admin-level permissions
    $adminPerms = $permissions | Where-Object { $_.Role -eq "Admin" }
    if ($adminPerms.Count -le 5) {
        Register-Check "Administrator accounts" "PASS" "$($adminPerms.Count) admin permission(s)"
    } else {
        Register-Check "Administrator accounts" "WARN" "$($adminPerms.Count) admin permissions (review)"
    }

    # Check for root folder permissions
    $rootPerms = $permissions | Where-Object { $_.Entity.Name -eq "Datacenters" -or $_.EntityId -match "Folder-group-d1" }
    if ($rootPerms) {
        Register-Check "Root folder permissions" "WARN" "$($rootPerms.Count) permissions at root level"
    } else {
        Register-Check "Root folder permissions" "PASS" "no root-level permissions"
    }

    # Check roles
    $customRoles = Get-VIRole | Where-Object { -not $_.IsSystem }
    Register-Check "Custom roles" "PASS" "$($customRoles.Count) custom role(s)"

} catch {
    Register-Check "Account security" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Certificate Security"
# ============================================================================

try {
    # Get certificate info via API
    $certMgr = Get-View -Id 'CertificateManager-certificateManager' -ErrorAction SilentlyContinue
    if ($certMgr) {
        Register-Check "Certificate Manager" "PASS" "accessible"
    }

    # Check VMCA certificates
    $vmcaCerts = & {
        $uri = "https://$Server/api/vcenter/certificate-management/vcenter/tls"
        try {
            $session = $connection.SessionSecret
            $headers = @{
                "vmware-api-session-id" = $session
            }
            $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get -SkipCertificateCheck:$SkipCertificateCheck
            $response
        } catch {
            $null
        }
    }

    if ($vmcaCerts) {
        $expiry = [DateTime]::Parse($vmcaCerts.valid_to)
        $daysLeft = ($expiry - (Get-Date)).Days

        if ($daysLeft -gt 30) {
            Register-Check "TLS certificate" "PASS" "$daysLeft days until expiry"
        } elseif ($daysLeft -gt 0) {
            Register-Check "TLS certificate" "WARN" "expires in $daysLeft days"
        } else {
            Register-Check "TLS certificate" "FAIL" "expired"
        }
    }
} catch {
    Register-Check "Certificate check" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Logging and Audit"
# ============================================================================

try {
    # Check syslog configuration
    $syslogSettings = Get-AdvancedSetting -Entity $Server -Name "Syslog.*" -ErrorAction SilentlyContinue

    $syslogServer = $syslogSettings | Where-Object { $_.Name -match "Syslog.global.logHost" }
    if ($syslogServer -and $syslogServer.Value) {
        Register-Check "Syslog forwarding" "PASS" $syslogServer.Value
    } else {
        Register-Check "Syslog forwarding" "WARN" "not configured"
    }

    # Check log level
    $logLevel = $syslogSettings | Where-Object { $_.Name -match "log.level" }
    if ($logLevel -and $logLevel.Value -match "info|verbose") {
        Register-Check "Log level" "PASS" $logLevel.Value
    }

    # Check events retention
    $eventRetention = Get-AdvancedSetting -Entity $Server -Name "event.maxAge*" -ErrorAction SilentlyContinue
    if ($eventRetention) {
        Register-Check "Event retention" "PASS" "configured"
    }
} catch {
    Register-Check "Logging configuration" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Network Security"
# ============================================================================

try {
    # Get all ESXi hosts for network checks
    $vmHosts = Get-VMHost

    foreach ($vmHost in $vmHosts) {
        # Check lockdown mode
        $lockdownLevel = (Get-View $vmHost.Id).Config.LockdownMode
        if ($lockdownLevel -eq "lockdownDisabled") {
            Register-Check "Lockdown mode ($($vmHost.Name))" "WARN" "disabled"
        } else {
            Register-Check "Lockdown mode ($($vmHost.Name))" "PASS" $lockdownLevel
        }

        # Check SSH service
        $sshService = Get-VMHostService -VMHost $vmHost | Where-Object { $_.Key -eq "TSM-SSH" }
        if ($sshService.Running) {
            Register-Check "SSH service ($($vmHost.Name))" "WARN" "running"
        } else {
            Register-Check "SSH service ($($vmHost.Name))" "PASS" "stopped"
        }
    }

    # Check distributed switches
    $vdSwitches = Get-VDSwitch -ErrorAction SilentlyContinue
    foreach ($vds in $vdSwitches) {
        $security = Get-VDSecurityPolicy -VDSwitch $vds -ErrorAction SilentlyContinue
        if ($security) {
            if ($security.AllowPromiscuous -eq $false) {
                Register-Check "Promiscuous mode ($($vds.Name))" "PASS" "disabled"
            } else {
                Register-Check "Promiscuous mode ($($vds.Name))" "WARN" "enabled"
            }

            if ($security.ForgedTransmits -eq $false) {
                Register-Check "Forged transmits ($($vds.Name))" "PASS" "rejected"
            } else {
                Register-Check "Forged transmits ($($vds.Name))" "WARN" "accepted"
            }
        }
    }
} catch {
    Register-Check "Network security" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "VM Security Policies"
# ============================================================================

try {
    $vms = Get-VM
    $vmCount = $vms.Count
    Register-Check "Total VMs" "PASS" "$vmCount VMs"

    # Sample security checks on VMs (limit to first 10 for performance)
    $sampleVMs = $vms | Select-Object -First 10

    $copyPasteEnabled = 0
    $dndEnabled = 0

    foreach ($vm in $sampleVMs) {
        $vmConfig = Get-AdvancedSetting -Entity $vm -ErrorAction SilentlyContinue

        # Check copy/paste
        $cpSetting = $vmConfig | Where-Object { $_.Name -eq "isolation.tools.copy.disable" }
        if (-not $cpSetting -or $cpSetting.Value -eq "false") {
            $copyPasteEnabled++
        }

        # Check drag and drop
        $dndSetting = $vmConfig | Where-Object { $_.Name -eq "isolation.tools.dnd.disable" }
        if (-not $dndSetting -or $dndSetting.Value -eq "false") {
            $dndEnabled++
        }
    }

    if ($copyPasteEnabled -eq 0) {
        Register-Check "VM copy/paste (sample)" "PASS" "disabled on sampled VMs"
    } else {
        Register-Check "VM copy/paste (sample)" "WARN" "$copyPasteEnabled of $($sampleVMs.Count) VMs have it enabled"
    }

    if ($dndEnabled -eq 0) {
        Register-Check "VM drag/drop (sample)" "PASS" "disabled on sampled VMs"
    } else {
        Register-Check "VM drag/drop (sample)" "WARN" "$dndEnabled of $($sampleVMs.Count) VMs have it enabled"
    }
} catch {
    Register-Check "VM security" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Backup and HA"
# ============================================================================

try {
    # Check clusters for HA/DRS
    $clusters = Get-Cluster

    foreach ($cluster in $clusters) {
        # HA status
        if ($cluster.HAEnabled) {
            Register-Check "HA ($($cluster.Name))" "PASS" "enabled"

            # HA admission control
            if ($cluster.HAAdmissionControlEnabled) {
                Register-Check "HA Admission Control ($($cluster.Name))" "PASS" "enabled"
            } else {
                Register-Check "HA Admission Control ($($cluster.Name))" "WARN" "disabled"
            }
        } else {
            Register-Check "HA ($($cluster.Name))" "WARN" "disabled"
        }

        # DRS status
        if ($cluster.DrsEnabled) {
            Register-Check "DRS ($($cluster.Name))" "PASS" "enabled ($($cluster.DrsAutomationLevel))"
        }
    }

    # Check for vSphere Replication
    $vrManager = Get-View -ViewType VirtualMachine -Filter @{Name="vSphere Replication"} -ErrorAction SilentlyContinue
    if ($vrManager) {
        Register-Check "vSphere Replication" "PASS" "deployed"
    }
} catch {
    Register-Check "Backup/HA check" "SKIP" $_.Exception.Message
}

# ============================================================================
Write-Section "Storage Security"
# ============================================================================

try {
    $datastores = Get-Datastore

    # Check for VMFS version
    $vmfsDatastores = $datastores | Where-Object { $_.Type -eq "VMFS" }
    foreach ($ds in $vmfsDatastores | Select-Object -First 5) {
        $vmfsVersion = (Get-View $ds.Id).Info.Vmfs.Version
        if ($vmfsVersion -ge "6") {
            Register-Check "VMFS version ($($ds.Name))" "PASS" "VMFS $vmfsVersion"
        } else {
            Register-Check "VMFS version ($($ds.Name))" "WARN" "VMFS $vmfsVersion (consider upgrade)"
        }
    }

    # Check for vSAN encryption
    $vsanClusters = Get-Cluster | Where-Object { $_.VsanEnabled }
    foreach ($vc in $vsanClusters) {
        $vsanConfig = Get-VsanClusterConfiguration -Cluster $vc -ErrorAction SilentlyContinue
        if ($vsanConfig.EncryptionEnabled) {
            Register-Check "vSAN encryption ($($vc.Name))" "PASS" "enabled"
        } else {
            Register-Check "vSAN encryption ($($vc.Name))" "WARN" "not enabled"
        }
    }
} catch {
    Register-Check "Storage security" "SKIP" $_.Exception.Message
}

# ============================================================================
# CLEANUP AND SUMMARY
# ============================================================================

Write-Section "Cleanup"

try {
    Disconnect-VIServer -Server $Server -Confirm:$false -ErrorAction SilentlyContinue
    Register-Check "Disconnected" "PASS" "session closed"
} catch {
    Register-Check "Disconnect" "WARN" "manual cleanup may be needed"
}

Write-Summary

# Return exit code based on failures
if ($script:FailCount -gt 0) {
    exit 2
} elseif ($script:WarnCount -gt 0) {
    exit 1
} else {
    exit 0
}
