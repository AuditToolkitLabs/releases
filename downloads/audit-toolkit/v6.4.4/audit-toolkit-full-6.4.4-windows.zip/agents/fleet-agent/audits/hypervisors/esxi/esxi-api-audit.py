#!/usr/bin/env python3
"""
VMware ESXi Security Audit via REST API

Cross-platform ESXi audit using vSphere REST API (7.0+).
Runs on Windows, Linux, or macOS with Python 3.8+.
Does NOT require SSH enabled - works with lockdown mode.

Compliance Mapping:
- CIS VMware ESXi Benchmark 7.0/8.0
- NIST SP 800-125: Virtualization Security
- NIST SP 800-53: SC-3, SC-4, AC-4
- VMware Security Hardening Guide
- PCI DSS: 2.2.1 (Hypervisor Hardening)
- DISA STIG for vSphere

Usage:
    python esxi-api-audit.py --server esxi01.example.com --username root
    python esxi-api-audit.py --server esxi01.example.com --username root --insecure
    python esxi-api-audit.py --server esxi01.example.com --username admin@vsphere.local --vcenter

Requirements:
    pip install requests urllib3

Note: For ESXi hosts managed by vCenter, you can authenticate via vCenter
      using the --vcenter flag and vCenter credentials.
"""

import argparse
import json
import sys
import urllib3
from datetime import datetime
from getpass import getpass
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    print("ERROR: requests module required. Install with: pip install requests")
    sys.exit(1)


class AuditResults:
    """Track audit results"""

    def __init__(self):
        self.checks: List[Dict[str, str]] = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0

    def register(self, name: str, status: str, message: str = "") -> None:
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"

        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))

        self.checks.append({"name": name, "status": status, "message": message})

        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1

    def section(self, title: str) -> None:
        """Print section header"""
        print(f"\n\033[96m=== {title} ===\033[0m\n")

    def summary(self) -> None:
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")

    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "timestamp": datetime.now().isoformat(),
            "checks": self.checks,
            "summary": {
                "total": len(self.checks),
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class ESXiAudit:
    """ESXi REST API Audit Client"""

    def __init__(self, server: str, username: str, password: str,
                 verify_ssl: bool = True, via_vcenter: bool = False):
        self.server = server
        self.base_url = f"https://{server}"
        self.via_vcenter = via_vcenter
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session_id: Optional[str] = None
        self.results = AuditResults()
        self.host_info: Dict[str, Any] = {}

        # Authenticate
        self._authenticate(username, password)

    def _authenticate(self, username: str, password: str) -> None:
        """Authenticate and get session token"""
        try:
            if self.via_vcenter:
                # Authenticate via vCenter API
                auth_url = f"{self.base_url}/api/session"
            else:
                # Direct ESXi authentication
                auth_url = f"{self.base_url}/api/session"

            response = self.session.post(
                auth_url,
                auth=(username, password),
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()

            # ESXi 7.0+ returns session ID in body
            self.session_id = response.json() if response.text else response.headers.get("vmware-api-session-id")
            self.session.headers["vmware-api-session-id"] = self.session_id

            self.results.register("API Authentication", "PASS", f"Connected to {self.server}")
        except requests.exceptions.RequestException as e:
            self.results.register("API Authentication", "FAIL", str(e))
            raise SystemExit(1)

    def _get(self, endpoint: str, params: Dict = None) -> Optional[Any]:
        """Make GET request to API"""
        try:
            response = self.session.get(
                f"{self.base_url}{endpoint}",
                params=params
            )
            if response.status_code == 200:
                return response.json() if response.text else None
            return None
        except Exception:
            return None

    def _get_advanced_setting(self, key: str) -> Optional[str]:
        """Get ESXi advanced setting value"""
        # Try REST API endpoint for settings
        settings = self._get("/api/appliance/system/globalSettings") or {}
        return settings.get(key)

    def close(self) -> None:
        """Close the session"""
        try:
            self.session.delete(f"{self.base_url}/api/session")
        except Exception:
            pass

    def audit_host_info(self) -> None:
        """Audit basic host information"""
        self.results.section("Host Information")

        # Get system version
        version_info = self._get("/api/appliance/system/version") or {}
        if version_info:
            version = version_info.get("version", "unknown")
            build = version_info.get("build", "unknown")
            self.results.register("ESXi Version", "PASS", f"{version} (Build {build})")
            self.host_info["version"] = version
        else:
            # Try alternative endpoint
            system_info = self._get("/api/esx/hosts") or []
            if system_info:
                self.results.register("Host Info", "PASS", "Retrieved via API")
            else:
                self.results.register("Host Info", "SKIP", "Could not retrieve")

    def audit_ssh_hardening(self) -> None:
        """CIS 1.x: SSH Hardening"""
        self.results.section("SSH Hardening (CIS Section 1)")

        # Check SSH service status
        services = self._get("/api/esx/settings/defaults/hosts/policies/services") or {}
        ssh_service = services.get("TSM-SSH", {})

        if ssh_service.get("enabled", True):
            self.results.register("SSH Service", "WARN", "Enabled (CIS 1.1 - disable if not needed)")
        else:
            self.results.register("SSH Service", "PASS", "Disabled (CIS 1.1)")

        # Check ESXi Shell
        shell_service = services.get("TSM", {})
        if shell_service.get("enabled", True):
            self.results.register("ESXi Shell", "WARN", "Enabled (CIS 1.2 - disable if not needed)")
        else:
            self.results.register("ESXi Shell", "PASS", "Disabled (CIS 1.2)")

        # Check shell timeout via advanced settings API
        timeout_settings = self._get("/api/esx/settings/defaults/hosts/configuration") or {}

        shell_timeout = timeout_settings.get("UserVars.ESXiShellTimeOut", 0)
        if shell_timeout and int(shell_timeout) > 0 and int(shell_timeout) <= 900:
            self.results.register("Shell Timeout", "PASS", f"{shell_timeout}s (CIS 1.2)")
        elif shell_timeout:
            self.results.register("Shell Timeout", "WARN", f"{shell_timeout}s (recommend <=900)")
        else:
            self.results.register("Shell Timeout", "WARN", "Not configured or default")

        # Check shell interactive timeout
        interactive_timeout = timeout_settings.get("UserVars.ESXiShellInteractiveTimeOut", 0)
        if interactive_timeout and int(interactive_timeout) > 0:
            self.results.register("Interactive Timeout", "PASS", f"{interactive_timeout}s (CIS 1.3)")
        else:
            self.results.register("Interactive Timeout", "WARN", "Not configured")

    def audit_lockdown_mode(self) -> None:
        """CIS 2.x: Lockdown Mode"""
        self.results.section("Lockdown Mode (CIS Section 2)")

        # Check lockdown mode via API
        security_config = self._get("/api/esx/settings/defaults/hosts/security") or {}

        lockdown = security_config.get("lockdown_mode", "disabled")
        if lockdown in ["lockdownNormal", "normal"]:
            self.results.register("Lockdown Mode", "PASS", "Normal mode enabled (CIS 2.1)")
        elif lockdown in ["lockdownStrict", "strict"]:
            self.results.register("Lockdown Mode", "PASS", "Strict mode enabled (CIS 2.1)")
        else:
            self.results.register("Lockdown Mode", "WARN", f"{lockdown} (CIS 2.1 - enable lockdown)")

        # MOB (Managed Object Browser)
        mob_setting = security_config.get("Config.HostAgent.plugins.solo.enableMob", True)
        if not mob_setting:
            self.results.register("MOB Disabled", "PASS", "CIS 1.4")
        else:
            self.results.register("MOB Disabled", "FAIL", "MOB enabled - CIS 1.4 violation")

    def audit_dcui_timeout(self) -> None:
        """CIS 3.x: DCUI Timeout"""
        self.results.section("DCUI Configuration (CIS Section 3)")

        config = self._get("/api/esx/settings/defaults/hosts/configuration") or {}

        dcui_timeout = config.get("UserVars.DcuiTimeOut", 0)
        if dcui_timeout and int(dcui_timeout) >= 600:
            self.results.register("DCUI Timeout", "PASS", f"{dcui_timeout}s (CIS 3.1)")
        elif dcui_timeout:
            self.results.register("DCUI Timeout", "WARN", f"{dcui_timeout}s (recommend >=600)")
        else:
            self.results.register("DCUI Timeout", "WARN", "Not configured (CIS 3.1)")

    def audit_logging(self) -> None:
        """CIS 4.x: Logging Configuration"""
        self.results.section("Logging Configuration (CIS Section 4)")

        config = self._get("/api/esx/settings/defaults/hosts/configuration") or {}

        # Check syslog configuration
        syslog_host = config.get("Syslog.global.logHost", "")
        if syslog_host:
            self.results.register("Remote Syslog", "PASS", f"{syslog_host} (CIS 4.1)")
        else:
            self.results.register("Remote Syslog", "WARN", "Not configured (CIS 4.1)")

        # Check log level
        log_level = config.get("Syslog.global.logLevel", "")
        if log_level in ["info", "warning", "error"]:
            self.results.register("Log Level", "PASS", log_level)
        else:
            self.results.register("Log Level", "WARN", f"{log_level or 'default'}")

    def audit_ntp(self) -> None:
        """CIS 5.x: NTP Configuration"""
        self.results.section("NTP Configuration (CIS Section 5)")

        # Check NTP service
        services = self._get("/api/esx/settings/defaults/hosts/policies/services") or {}
        ntp_service = services.get("ntpd", {})

        if ntp_service.get("enabled"):
            self.results.register("NTP Service", "PASS", "Enabled (CIS 5.1)")
        else:
            self.results.register("NTP Service", "WARN", "Not enabled (CIS 5.1)")

        # Check NTP servers
        config = self._get("/api/esx/settings/defaults/hosts/configuration") or {}
        ntp_servers = config.get("Ntp.NtpServers", [])
        if ntp_servers:
            self.results.register("NTP Servers", "PASS", f"{len(ntp_servers)} configured (CIS 5.2)")
        else:
            self.results.register("NTP Servers", "WARN", "No NTP servers configured")

    def audit_network_security(self) -> None:
        """CIS 6.x: Network Security"""
        self.results.section("Network Security (CIS Section 6)")

        # Get virtual switches
        vswitches = self._get("/api/esx/hcl/hosts/networks") or []

        for vswitch in vswitches if isinstance(vswitches, list) else []:
            name = vswitch.get("name", "unknown")

            # Check promiscuous mode
            promisc = vswitch.get("allowPromiscuous", False)
            if not promisc:
                self.results.register(f"{name} Promiscuous", "PASS", "Rejected (CIS 6.1)")
            else:
                self.results.register(f"{name} Promiscuous", "WARN", "Allowed (CIS 6.1)")

            # Check forged transmits
            forged = vswitch.get("forgedTransmits", False)
            if not forged:
                self.results.register(f"{name} Forged Transmits", "PASS", "Rejected (CIS 6.2)")
            else:
                self.results.register(f"{name} Forged Transmits", "WARN", "Allowed (CIS 6.2)")

            # Check MAC changes
            mac_changes = vswitch.get("macChanges", False)
            if not mac_changes:
                self.results.register(f"{name} MAC Changes", "PASS", "Rejected (CIS 6.3)")
            else:
                self.results.register(f"{name} MAC Changes", "WARN", "Allowed (CIS 6.3)")

    def audit_firewall(self) -> None:
        """CIS 8.x: Firewall Configuration"""
        self.results.section("Firewall Configuration (CIS Section 8)")

        # Check firewall status
        firewall = self._get("/api/esx/settings/defaults/hosts/security/firewall") or {}

        if firewall.get("enabled", True):
            self.results.register("Firewall", "PASS", "Enabled (CIS 8.1)")
        else:
            self.results.register("Firewall", "FAIL", "Disabled (CIS 8.1)")

        # Check default action
        default_action = firewall.get("defaultAction", "DROP")
        if default_action == "DROP":
            self.results.register("Default Action", "PASS", "DROP (CIS 8.2)")
        else:
            self.results.register("Default Action", "WARN", f"{default_action} (recommend DROP)")

    def audit_account_security(self) -> None:
        """CIS 9.x: Account Security"""
        self.results.section("Account Security (CIS Section 9)")

        config = self._get("/api/esx/settings/defaults/hosts/configuration") or {}

        # Check password quality
        password_quality = config.get("Security.PasswordQualityControl", "")
        if password_quality:
            self.results.register("Password Quality", "PASS", "Configured (CIS 9.1)")
        else:
            self.results.register("Password Quality", "WARN", "Default settings (CIS 9.1)")

        # Check account lockout
        lockout_failures = config.get("Security.AccountLockFailures", 0)
        if lockout_failures and int(lockout_failures) <= 5:
            self.results.register("Lockout Failures", "PASS", f"{lockout_failures} attempts (CIS 9.2)")
        elif lockout_failures:
            self.results.register("Lockout Failures", "WARN", f"{lockout_failures} (recommend <=5)")
        else:
            self.results.register("Lockout Failures", "WARN", "Not configured")

        # Check lockout duration
        lockout_duration = config.get("Security.AccountUnlockTime", 0)
        if lockout_duration and int(lockout_duration) >= 900:
            self.results.register("Lockout Duration", "PASS", f"{lockout_duration}s (CIS 9.3)")
        elif lockout_duration:
            self.results.register("Lockout Duration", "WARN", f"{lockout_duration}s (recommend >=900)")
        else:
            self.results.register("Lockout Duration", "WARN", "Not configured")

    def audit_vib_acceptance(self) -> None:
        """CIS: VIB Acceptance Level"""
        self.results.section("Software Security")

        software = self._get("/api/esx/software") or {}

        acceptance = software.get("acceptance_level", "unknown")
        if acceptance in ["VMwareCertified", "VMwareAccepted", "PartnerSupported"]:
            self.results.register("VIB Acceptance", "PASS", f"{acceptance} (CIS compliant)")
        elif acceptance == "CommunitySupported":
            self.results.register("VIB Acceptance", "FAIL", "CommunitySupported - CIS violation")
        else:
            self.results.register("VIB Acceptance", "WARN", f"{acceptance}")

    def audit_certificates(self) -> None:
        """Certificate Security"""
        self.results.section("Certificate Security")

        certs = self._get("/api/vcenter/certificate-management/vcenter/tls") or {}

        if certs:
            # Check expiry
            expiry = certs.get("valid_to", "")
            if expiry:
                self.results.register("TLS Certificate", "PASS", f"Valid until {expiry}")

            # Check if self-signed
            issuer = certs.get("issuer_dn", "")
            subject = certs.get("subject_dn", "")
            if issuer == subject:
                self.results.register("Certificate Type", "WARN", "Self-signed (recommend CA-signed)")
            else:
                self.results.register("Certificate Type", "PASS", "CA-signed")
        else:
            self.results.register("TLS Certificate", "SKIP", "Could not retrieve")

    def run_full_audit(self) -> None:
        """Run complete security audit"""
        print(f"\033[96m{'='*60}\033[0m")
        print(f"\033[96mVMware ESXi Security Audit via REST API\033[0m")
        print(f"\033[96mTarget: {self.server}\033[0m")
        print(f"\033[96mTime: {datetime.now().isoformat()}\033[0m")
        print(f"\033[96m{'='*60}\033[0m")

        self.audit_host_info()
        self.audit_ssh_hardening()
        self.audit_lockdown_mode()
        self.audit_dcui_timeout()
        self.audit_logging()
        self.audit_ntp()
        self.audit_network_security()
        self.audit_firewall()
        self.audit_account_security()
        self.audit_vib_acceptance()
        self.audit_certificates()

        self.results.summary()
        self.close()


def main():
    parser = argparse.ArgumentParser(
        description="VMware ESXi Security Audit via REST API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    %(prog)s --server esxi01.example.com --username root
    %(prog)s --server vcenter.example.com --username admin@vsphere.local --vcenter
    %(prog)s --server esxi01.example.com --username root --insecure --output results.json
        """
    )
    parser.add_argument("--server", "-s", required=True, help="ESXi host or vCenter server")
    parser.add_argument("--username", "-u", required=True, help="Username for authentication")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--vcenter", "-V", action="store_true", help="Connect via vCenter instead of direct ESXi")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--output", "-o", help="Output JSON results to file")

    args = parser.parse_args()

    # Get password
    password = args.password or getpass("Password: ")

    # Disable SSL warnings if insecure
    if args.insecure:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # Run audit
    try:
        audit = ESXiAudit(
            server=args.server,
            username=args.username,
            password=password,
            verify_ssl=not args.insecure,
            via_vcenter=args.vcenter
        )
        audit.run_full_audit()

        # Output JSON if requested
        if args.output:
            with open(args.output, "w") as f:
                f.write(audit.results.to_json())
            print(f"\nResults saved to: {args.output}")

        # Exit with appropriate code
        sys.exit(1 if audit.results.failed > 0 else 0)

    except KeyboardInterrupt:
        print("\nAudit cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
