#!/usr/bin/env python3
"""
VMware vCenter Security Audit via REST API

Cross-platform vCenter audit using vSphere REST API (7.0+).
Runs on Windows, Linux, or macOS with Python 3.8+.

Compliance Mapping:
- CIS VMware vCenter Benchmark
- NIST SP 800-53: AC-2, AC-6, AU-2
- VMware Security Hardening Guide
- PCI DSS: 8.1, 10.1

Usage:
    python vcenter-api-audit.py --server vcenter.example.com --username admin@vsphere.local
    python vcenter-api-audit.py --server vcenter.example.com --username admin@vsphere.local --insecure

Requirements:
    pip install requests urllib3
"""

import argparse
import json
import sys
import urllib3
from datetime import datetime
from getpass import getpass
from typing import Any

try:
    import requests
except ImportError:
    print("ERROR: requests module required. Install with: pip install requests")
    sys.exit(1)


class AuditResults:
    """Track audit results"""
    
    def __init__(self):
        self.checks = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0
    
    def register(self, name: str, status: str, message: str = ""):
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",  # Green
            "WARN": "\033[93m",  # Yellow
            "FAIL": "\033[91m",  # Red
            "SKIP": "\033[90m",  # Gray
        }
        reset = "\033[0m"
        
        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))
        
        self.checks.append({"name": name, "status": status, "message": message})
        
        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1
    
    def summary(self):
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")
    
    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "checks": self.checks,
            "summary": {
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class VCenterAudit:
    """vCenter REST API Audit Client"""
    
    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = True):
        self.server = server
        self.base_url = f"https://{server}"
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session_id = None
        self.results = AuditResults()
        
        if not verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        self._authenticate(username, password)
    
    def _authenticate(self, username: str, password: str):
        """Authenticate and get session token"""
        try:
            response = self.session.post(
                f"{self.base_url}/api/session",
                auth=(username, password),
                timeout=30
            )
            response.raise_for_status()
            self.session_id = response.json()
            self.session.headers["vmware-api-session-id"] = self.session_id
            self.results.register("vCenter Connection", "PASS", self.server)
        except requests.exceptions.SSLError:
            self.results.register("vCenter Connection", "FAIL", "SSL error (try --insecure)")
            sys.exit(1)
        except requests.exceptions.RequestException as e:
            self.results.register("vCenter Connection", "FAIL", str(e))
            sys.exit(1)
    
    def _get(self, endpoint: str) -> Any:
        """Make GET request to API"""
        try:
            response = self.session.get(f"{self.base_url}{endpoint}", timeout=30)
            if response.status_code == 200:
                return response.json()
            return None
        except Exception:
            return None
    
    def section(self, title: str):
        """Print section header"""
        print(f"\n=== {title} ===\n")
    
    def audit_vcenter_info(self):
        """Audit vCenter version and appliance info"""
        self.section("vCenter Information")
        
        # Get vCenter version via appliance API
        info = self._get("/api/appliance/system/version")
        if info:
            version = info.get("version", "unknown")
            build = info.get("build", "unknown")
            self.results.register("vCenter Version", "PASS", f"{version} (Build {build})")
        else:
            # Try legacy API
            about = self._get("/rest/vcenter/system-config/version")
            if about and "value" in about:
                self.results.register("vCenter Version", "PASS", about["value"].get("version", "unknown"))
            else:
                self.results.register("vCenter Version", "SKIP", "Could not retrieve")
        
        # Check appliance health
        health = self._get("/api/appliance/health/system")
        if health:
            if health == "green":
                self.results.register("Appliance Health", "PASS", "Green")
            elif health == "yellow":
                self.results.register("Appliance Health", "WARN", "Yellow - check services")
            else:
                self.results.register("Appliance Health", "FAIL", health)
        else:
            self.results.register("Appliance Health", "SKIP", "Could not retrieve")
    
    def audit_hosts(self):
        """Audit ESXi hosts"""
        self.section("ESXi Host Security")
        
        hosts = self._get("/api/vcenter/host")
        if not hosts:
            self.results.register("ESXi Hosts", "SKIP", "Could not enumerate")
            return
        
        self.results.register("ESXi Hosts", "PASS", f"{len(hosts)} host(s)")
        
        for host in hosts:
            host_name = host.get("name", host.get("host", "unknown"))
            conn_state = host.get("connection_state", "unknown")
            power_state = host.get("power_state", "unknown")
            
            if conn_state == "CONNECTED" and power_state == "POWERED_ON":
                self.results.register(f"{host_name} Status", "PASS", "Connected")
            elif conn_state == "DISCONNECTED":
                self.results.register(f"{host_name} Status", "WARN", "Disconnected")
            else:
                self.results.register(f"{host_name} Status", "WARN", f"{conn_state}/{power_state}")
    
    def audit_vms(self):
        """Audit virtual machines"""
        self.section("Virtual Machine Security")
        
        vms = self._get("/api/vcenter/vm")
        if not vms:
            self.results.register("Virtual Machines", "SKIP", "Could not enumerate")
            return
        
        self.results.register("Virtual Machines", "PASS", f"{len(vms)} VM(s)")
        
        # Count VMs without tools
        powered_on = [vm for vm in vms if vm.get("power_state") == "POWERED_ON"]
        self.results.register("Powered On VMs", "PASS", f"{len(powered_on)} running")
    
    def audit_datacenters(self):
        """Audit datacenter configuration"""
        self.section("Datacenter Configuration")
        
        dcs = self._get("/api/vcenter/datacenter")
        if dcs:
            self.results.register("Datacenters", "PASS", f"{len(dcs)} datacenter(s)")
        else:
            self.results.register("Datacenters", "SKIP", "Could not enumerate")
        
        # Check clusters
        clusters = self._get("/api/vcenter/cluster")
        if clusters:
            self.results.register("Clusters", "PASS", f"{len(clusters)} cluster(s)")
            
            for cluster in clusters:
                cluster_name = cluster.get("name", cluster.get("cluster", "unknown"))
                ha_enabled = cluster.get("ha_enabled", False)
                drs_enabled = cluster.get("drs_enabled", False)
                
                if ha_enabled:
                    self.results.register(f"{cluster_name} HA", "PASS", "Enabled")
                else:
                    self.results.register(f"{cluster_name} HA", "WARN", "Disabled")
                
                if drs_enabled:
                    self.results.register(f"{cluster_name} DRS", "PASS", "Enabled")
                else:
                    self.results.register(f"{cluster_name} DRS", "WARN", "Disabled")
    
    def audit_networks(self):
        """Audit network configuration"""
        self.section("Network Security")
        
        networks = self._get("/api/vcenter/network")
        if networks:
            self.results.register("Networks", "PASS", f"{len(networks)} network(s)")
            
            # Check for distributed vs standard
            dvs_count = len([n for n in networks if n.get("type") == "DISTRIBUTED_PORTGROUP"])
            std_count = len([n for n in networks if n.get("type") == "STANDARD_PORTGROUP"])
            
            if dvs_count > 0:
                self.results.register("Distributed Portgroups", "PASS", f"{dvs_count} DVS portgroup(s)")
            if std_count > 0:
                self.results.register("Standard Portgroups", "PASS", f"{std_count} standard portgroup(s)")
        else:
            self.results.register("Networks", "SKIP", "Could not enumerate")
    
    def audit_storage(self):
        """Audit storage configuration"""
        self.section("Storage Security")
        
        datastores = self._get("/api/vcenter/datastore")
        if datastores:
            self.results.register("Datastores", "PASS", f"{len(datastores)} datastore(s)")
            
            total_capacity = 0
            total_free = 0
            for ds in datastores:
                total_capacity += ds.get("capacity", 0)
                total_free += ds.get("free_space", 0)
            
            if total_capacity > 0:
                used_pct = ((total_capacity - total_free) / total_capacity) * 100
                if used_pct < 80:
                    self.results.register("Storage Utilization", "PASS", f"{used_pct:.1f}% used")
                elif used_pct < 90:
                    self.results.register("Storage Utilization", "WARN", f"{used_pct:.1f}% used")
                else:
                    self.results.register("Storage Utilization", "FAIL", f"{used_pct:.1f}% used (critical)")
        else:
            self.results.register("Datastores", "SKIP", "Could not enumerate")
    
    def audit_appliance_services(self):
        """Audit VCSA appliance services"""
        self.section("Appliance Services")
        
        services = self._get("/api/appliance/services")
        if not services:
            self.results.register("Appliance Services", "SKIP", "Not accessible (run on VCSA)")
            return
        
        critical_services = ["vpxd", "vsphere-ui", "sso", "vpostgres"]
        
        for svc_id, svc_info in services.items():
            if any(cs in svc_id.lower() for cs in critical_services):
                state = svc_info.get("state", "unknown")
                if state == "STARTED":
                    self.results.register(f"Service {svc_id}", "PASS", "Running")
                else:
                    self.results.register(f"Service {svc_id}", "WARN", state)
    
    def audit_local_accounts(self):
        """Audit local accounts"""
        self.section("Local Accounts")
        
        accounts = self._get("/api/appliance/local-accounts")
        if accounts:
            self.results.register("Local Accounts", "PASS", f"{len(accounts)} account(s)")
            
            for account in accounts:
                username = account.get("username", "unknown")
                enabled = account.get("enabled", True)
                
                # Check password age
                last_set = account.get("password_last_set")
                if last_set:
                    try:
                        last_set_date = datetime.fromisoformat(last_set.replace("Z", "+00:00"))
                        age_days = (datetime.now(last_set_date.tzinfo) - last_set_date).days
                        if age_days > 90:
                            self.results.register(f"Account {username}", "WARN", f"Password {age_days} days old")
                        else:
                            self.results.register(f"Account {username}", "PASS", f"Password {age_days} days old")
                    except Exception:
                        pass
        else:
            self.results.register("Local Accounts", "SKIP", "Not accessible")
    
    def audit_ntp(self):
        """Audit NTP configuration"""
        self.section("Time Synchronization")
        
        ntp = self._get("/api/appliance/ntp")
        if ntp:
            servers = ntp.get("servers", [])
            if servers:
                self.results.register("NTP Servers", "PASS", ", ".join(servers))
            else:
                self.results.register("NTP Servers", "WARN", "No NTP servers configured")
            
            status = ntp.get("status", "unknown")
            if status == "SYNCHRONIZED":
                self.results.register("NTP Status", "PASS", "Synchronized")
            else:
                self.results.register("NTP Status", "WARN", status)
        else:
            self.results.register("NTP", "SKIP", "Not accessible")
    
    def audit_syslog(self):
        """Audit syslog configuration"""
        self.section("Logging Configuration")
        
        syslog = self._get("/api/appliance/logging/forwarding")
        if syslog:
            if syslog:
                self.results.register("Syslog Forwarding", "PASS", f"{len(syslog)} destination(s)")
            else:
                self.results.register("Syslog Forwarding", "WARN", "No remote syslog configured")
        else:
            self.results.register("Syslog", "SKIP", "Not accessible")
    
    def disconnect(self):
        """Disconnect from vCenter"""
        try:
            self.session.delete(f"{self.base_url}/api/session")
        except Exception:
            pass
    
    def run_full_audit(self):
        """Run complete audit"""
        self.audit_vcenter_info()
        self.audit_appliance_services()
        self.audit_local_accounts()
        self.audit_ntp()
        self.audit_syslog()
        self.audit_datacenters()
        self.audit_hosts()
        self.audit_vms()
        self.audit_networks()
        self.audit_storage()
        
        self.disconnect()
        self.results.summary()
        
        return self.results


def main():
    parser = argparse.ArgumentParser(
        description="VMware vCenter Security Audit via REST API"
    )
    parser.add_argument("--server", "-s", required=True, help="vCenter server hostname or IP")
    parser.add_argument("--username", "-u", required=True, help="Username (e.g., admin@vsphere.local)")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--json", "-j", action="store_true", help="Output results as JSON")
    
    args = parser.parse_args()
    
    password = args.password or getpass("Password: ")
    
    try:
        audit = VCenterAudit(
            server=args.server,
            username=args.username,
            password=password,
            verify_ssl=not args.insecure
        )
        
        results = audit.run_full_audit()
        
        if args.json:
            print(results.to_json())
        
        # Exit code based on results
        if results.failed > 0:
            sys.exit(2)
        elif results.warnings > 0:
            sys.exit(1)
        else:
            sys.exit(0)
            
    except KeyboardInterrupt:
        print("\nAudit cancelled")
        sys.exit(130)


if __name__ == "__main__":
    main()
