#!/usr/bin/env bash
# vcenter-audit.sh — VMware vCenter Server Appliance (VCSA) Security Audit
#
# Compliance Mapping:
# - CIS VMware vCenter Benchmark
# - NIST SP 800-53: AC-2, AC-6, AU-2 (Access Control, Audit)
# - VMware Security Hardening Guide
# - PCI DSS: 8.1, 10.1 (Authentication, Audit Logging)
# - DISA STIG: vSphere 7.0 vCenter
#
# Note: Run this on the VCSA appliance itself or remotely via SSH.
# For API-based audits, use vcenter-api-audit.sh (future)
#
# Checks:
# - Appliance services and versions
# - SSO/Identity configuration
# - Certificate management
# - Logging and syslog
# - Backup configuration
# - Network/TLS settings
# - VAMI access controls

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "vCenter Server Detection"

# Check if we're on VCSA (Photon OS based)
is_vcsa=false
vcsa_version=""

if [[ -f /etc/vmware/appliance-manifest.xml ]]; then
    is_vcsa=true
    vcsa_version=$(grep -oP '(?<=<version>)[^<]+' /etc/vmware/appliance-manifest.xml 2>/dev/null | head -1 || echo "unknown")
elif command -v vmon-cli >/dev/null 2>&1; then
    is_vcsa=true
    vcsa_version=$(vpxd -v 2>/dev/null | head -1 || echo "unknown")
fi

if ! $is_vcsa; then
    register_check "vCenter Server" SKIP "not detected (run on VCSA appliance)"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "vCenter Server" PASS "version: $vcsa_version"

# ============================================================================
section "Appliance Services"
# ============================================================================

# Check critical services
declare -A vcsa_services=(
    ["vmware-vpxd"]="vCenter Server"
    ["vmware-vpostgres"]="PostgreSQL Database"
    ["vmware-stsd"]="Security Token Service"
    ["vmware-rhttpproxy"]="Reverse Proxy"
    ["vmware-sca"]="Service Control Agent"
    ["vmware-content-library"]="Content Library"
    ["vmware-vsan-health"]="vSAN Health"
    ["vmware-eam"]="ESX Agent Manager"
)

if command -v vmon-cli >/dev/null 2>&1; then
    for svc in "${!vcsa_services[@]}"; do
        svc_name="${vcsa_services[$svc]}"
        if vmon-cli --status "$svc" 2>/dev/null | grep -qi "running"; then
            register_check "$svc_name" PASS "running"
        else
            # Check if service is expected to be running
            state=$(vmon-cli --status "$svc" 2>/dev/null | grep -i "state" | awk '{print $NF}' || echo "unknown")
            if [[ "$state" == "STOPPED" ]]; then
                register_check "$svc_name" WARN "stopped"
            else
                register_check "$svc_name" SKIP "state: $state"
            fi
        fi
    done
else
    register_check "Service check" SKIP "vmon-cli not available"
fi

# ============================================================================
section "SSO/Identity Security"
# ============================================================================

# Check SSO domain
if [[ -f /etc/vmware-sso/keys.properties ]]; then
    register_check "SSO keys config" PASS "exists"
else
    register_check "SSO keys config" WARN "not found"
fi

# Check password policy in SSO
if command -v /usr/lib/vmware-vmafd/bin/dir-cli >/dev/null 2>&1; then
    # Check lockout policy
    lockout_threshold=$(/usr/lib/vmware-vmafd/bin/dir-cli password-policy get 2>/dev/null | \
        grep -i "failed.*threshold" | awk '{print $NF}' || echo "unknown")
    if [[ "$lockout_threshold" != "unknown" ]] && [[ "$lockout_threshold" -le 5 ]]; then
        register_check "SSO lockout threshold" PASS "$lockout_threshold attempts"
    elif [[ "$lockout_threshold" != "unknown" ]]; then
        register_check "SSO lockout threshold" WARN "$lockout_threshold attempts (recommend ≤5)"
    else
        register_check "SSO lockout threshold" SKIP "could not query"
    fi

    # Check password complexity
    min_length=$(/usr/lib/vmware-vmafd/bin/dir-cli password-policy get 2>/dev/null | \
        grep -i "minimum.*length" | awk '{print $NF}' || echo "unknown")
    if [[ "$min_length" != "unknown" ]] && [[ "$min_length" -ge 12 ]]; then
        register_check "SSO password length" PASS "min $min_length chars"
    elif [[ "$min_length" != "unknown" ]]; then
        register_check "SSO password length" WARN "min $min_length chars (recommend ≥12)"
    else
        register_check "SSO password length" SKIP "could not query"
    fi
else
    register_check "SSO policy" SKIP "dir-cli not available"
fi

# Check for external identity sources (LDAP/AD)
if [[ -d /etc/vmware-sso/config ]]; then
    if grep -rqi "ldap\|ActiveDirectory" /etc/vmware-sso/config 2>/dev/null; then
        register_check "External identity source" PASS "LDAP/AD configured"
    else
        register_check "External identity source" WARN "local SSO only"
    fi
fi

# ============================================================================
section "Certificate Security"
# ============================================================================

# Check machine SSL certificate
cert_file="/etc/vmware-vpx/ssl/rui.crt"
if [[ -f "$cert_file" ]]; then
    # Check expiration
    expiry=$(openssl x509 -enddate -noout -in "$cert_file" 2>/dev/null | cut -d= -f2)
    expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo 0)
    now_epoch=$(date +%s)
    days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

    if [[ $days_left -gt 30 ]]; then
        register_check "Machine SSL cert" PASS "$days_left days until expiry"
    elif [[ $days_left -gt 0 ]]; then
        register_check "Machine SSL cert" WARN "expires in $days_left days"
    else
        register_check "Machine SSL cert" FAIL "expired or invalid"
    fi

    # Check key strength
    key_bits=$(openssl x509 -text -noout -in "$cert_file" 2>/dev/null | \
        grep -i "public-key" | grep -oP '\d+' || echo "unknown")
    if [[ "$key_bits" != "unknown" ]] && [[ "$key_bits" -ge 2048 ]]; then
        register_check "Certificate key strength" PASS "$key_bits bits"
    elif [[ "$key_bits" != "unknown" ]]; then
        register_check "Certificate key strength" FAIL "$key_bits bits (require ≥2048)"
    fi

    # Check if self-signed
    issuer=$(openssl x509 -issuer -noout -in "$cert_file" 2>/dev/null | cut -d= -f2-)
    subject=$(openssl x509 -subject -noout -in "$cert_file" 2>/dev/null | cut -d= -f2-)
    if [[ "$issuer" == "$subject" ]]; then
        register_check "Certificate type" WARN "self-signed (recommend CA-signed)"
    else
        register_check "Certificate type" PASS "CA-signed"
    fi
else
    register_check "Machine SSL cert" SKIP "not found at $cert_file"
fi

# Check VMCA root certificate
vmca_root="/etc/vmware-vpx/ssl/vmca_root.cer"
if [[ -f "$vmca_root" ]]; then
    register_check "VMCA root certificate" PASS "exists"
else
    register_check "VMCA root certificate" WARN "not found"
fi

# ============================================================================
section "Logging and Audit"
# ============================================================================

# Check syslog forwarding
syslog_conf="/etc/rsyslog.conf"
if [[ -f "$syslog_conf" ]]; then
    if grep -qE "^[^#]*@@?[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+" "$syslog_conf" 2>/dev/null; then
        register_check "Syslog forwarding" PASS "remote syslog configured"
    elif grep -rqE "^[^#]*@@?" /etc/rsyslog.d/ 2>/dev/null; then
        register_check "Syslog forwarding" PASS "remote syslog in rsyslog.d"
    else
        register_check "Syslog forwarding" WARN "no remote syslog configured"
    fi
fi

# Check vpxd logging level
vpxd_cfg="/etc/vmware-vpx/vpxd.cfg"
if [[ -f "$vpxd_cfg" ]]; then
    log_level=$(grep -i "logLevel" "$vpxd_cfg" 2>/dev/null | head -1 || echo "")
    if echo "$log_level" | grep -qi "info\|verbose\|trivia"; then
        register_check "vpxd log level" PASS "adequate logging"
    else
        register_check "vpxd log level" WARN "check logging verbosity"
    fi
fi

# Check log rotation
if [[ -f /etc/logrotate.d/vmware-vpxd ]] || [[ -f /etc/logrotate.d/vmware ]]; then
    register_check "Log rotation" PASS "configured"
else
    register_check "Log rotation" WARN "vmware logrotate not found"
fi

# ============================================================================
section "Backup Configuration"
# ============================================================================

# Check file-based backup schedule
backup_schedule="/etc/vmware-vpx/backup/backupSchedule.json"
if [[ -f "$backup_schedule" ]]; then
    if grep -qi "enabled.*true" "$backup_schedule" 2>/dev/null; then
        register_check "Scheduled backups" PASS "enabled"
    else
        register_check "Scheduled backups" WARN "not enabled"
    fi
else
    register_check "Scheduled backups" WARN "no backup schedule found"
fi

# Check backup location encryption
if [[ -f /etc/vmware-vpx/backup/backupConfig.json ]]; then
    if grep -qi "encryptionKey\|encrypted" /etc/vmware-vpx/backup/backupConfig.json 2>/dev/null; then
        register_check "Backup encryption" PASS "configured"
    else
        register_check "Backup encryption" WARN "encryption not detected"
    fi
fi

# ============================================================================
section "Network Security"
# ============================================================================

# Check TLS version
ssl_conf="/etc/vmware-rhttpproxy/config.xml"
if [[ -f "$ssl_conf" ]]; then
    if grep -qi "TLSv1.2\|TLSv1.3" "$ssl_conf" 2>/dev/null; then
        register_check "TLS version" PASS "TLS 1.2+ configured"
    elif grep -qi "TLSv1.0\|TLSv1.1\|SSLv3" "$ssl_conf" 2>/dev/null; then
        register_check "TLS version" FAIL "legacy TLS/SSL enabled"
    else
        register_check "TLS version" WARN "check TLS configuration"
    fi
fi

# Check listening ports
listening_ports=$(ss -tlnp 2>/dev/null | grep LISTEN || netstat -tlnp 2>/dev/null | grep LISTEN || echo "")
if echo "$listening_ports" | grep -q ":443"; then
    register_check "HTTPS port 443" PASS "listening"
fi

# Check if HTTP redirect is enabled (port 80 should redirect, not serve)
if echo "$listening_ports" | grep -q ":80"; then
    register_check "HTTP port 80" WARN "listening (ensure redirect-only)"
else
    register_check "HTTP port 80" PASS "not listening"
fi

# Check firewall rules (VCSA uses iptables)
if command -v iptables >/dev/null 2>&1; then
    rule_count=$(iptables -L -n 2>/dev/null | grep -c "ACCEPT\|DROP\|REJECT" || echo "0")
    if [[ "$rule_count" -gt 5 ]]; then
        register_check "Firewall rules" PASS "$rule_count rules"
    else
        register_check "Firewall rules" WARN "minimal rules ($rule_count)"
    fi
fi

# ============================================================================
section "VAMI Security"
# ============================================================================

# Check VAMI (port 5480) configuration
vami_conf="/opt/vmware/etc/lighttpd/lighttpd.conf"
if [[ -f "$vami_conf" ]]; then
    # Check if VAMI is enabled
    if grep -qi "server.port.*5480" "$vami_conf" 2>/dev/null; then
        register_check "VAMI interface" PASS "enabled on port 5480"

        # Check VAMI SSL
        if grep -qi "ssl.engine.*enable" "$vami_conf" 2>/dev/null; then
            register_check "VAMI SSL" PASS "enabled"
        else
            register_check "VAMI SSL" FAIL "not enabled"
        fi
    else
        register_check "VAMI interface" SKIP "not standard config"
    fi
fi

# Check VAMI session timeout
if [[ -f /opt/vmware/etc/appliance/appliance.cfg ]]; then
    session_timeout=$(grep -i "session.*timeout" /opt/vmware/etc/appliance/appliance.cfg 2>/dev/null | \
        awk -F= '{print $2}' | tr -d ' ' || echo "unknown")
    if [[ "$session_timeout" != "unknown" ]] && [[ "$session_timeout" -le 30 ]]; then
        register_check "VAMI session timeout" PASS "${session_timeout}min"
    elif [[ "$session_timeout" != "unknown" ]]; then
        register_check "VAMI session timeout" WARN "${session_timeout}min (recommend ≤30)"
    fi
fi

# ============================================================================
section "Appliance Hardening"
# ============================================================================

# Check root SSH access
sshd_config="/etc/ssh/sshd_config"
if [[ -f "$sshd_config" ]]; then
    if grep -qi "^PermitRootLogin.*yes" "$sshd_config" 2>/dev/null; then
        register_check "Root SSH login" WARN "enabled (disable for production)"
    elif grep -qi "^PermitRootLogin.*no\|^PermitRootLogin.*prohibit" "$sshd_config" 2>/dev/null; then
        register_check "Root SSH login" PASS "disabled"
    else
        register_check "Root SSH login" WARN "not explicitly set"
    fi
fi

# Check shell timeout
bashrc="/etc/bash.bashrc"
if [[ -f "$bashrc" ]] && grep -q "TMOUT" "$bashrc" 2>/dev/null; then
    tmout=$(grep "TMOUT" "$bashrc" 2>/dev/null | head -1 | grep -oP '\d+' || echo "unknown")
    register_check "Shell timeout" PASS "${tmout}s"
elif [[ -n "${TMOUT:-}" ]]; then
    register_check "Shell timeout" PASS "${TMOUT}s"
else
    register_check "Shell timeout" WARN "not set"
fi

# Check if debug/developer mode is disabled
if [[ -f /etc/vmware-vpx/vpxd.cfg ]]; then
    if grep -qi "developerMode.*true\|debugMode.*true" /etc/vmware-vpx/vpxd.cfg 2>/dev/null; then
        register_check "Developer/debug mode" FAIL "enabled"
    else
        register_check "Developer/debug mode" PASS "disabled"
    fi
fi

# Check NTP synchronization
if command -v ntpq >/dev/null 2>&1; then
    ntp_status=$(ntpq -p 2>/dev/null | grep -c "^\*" || echo "0")
    if [[ "$ntp_status" -ge 1 ]]; then
        register_check "NTP synchronization" PASS "synchronized"
    else
        register_check "NTP synchronization" WARN "not synchronized"
    fi
elif timedatectl status 2>/dev/null | grep -qi "synchronized.*yes"; then
    register_check "Time synchronization" PASS "synchronized"
else
    register_check "Time synchronization" WARN "check time sync"
fi

# ============================================================================
section "CIS Additional Controls"
# ============================================================================

# CIS 2.1: vSphere Client session timeout
if [[ -f /etc/vmware-vpx/client/webclient.properties ]]; then
    session_timeout=$(grep -E "session\.timeout" /etc/vmware-vpx/client/webclient.properties 2>/dev/null | awk -F'=' '{print $2}' || echo "")
    if [[ -n "$session_timeout" ]] && [[ "$session_timeout" -le 10 ]]; then
        register_check "Client session timeout" PASS "${session_timeout}min - CIS 2.1"
    elif [[ -n "$session_timeout" ]]; then
        register_check "Client session timeout" WARN "${session_timeout}min (recommend <=10)"
    else
        register_check "Client session timeout" WARN "not configured"
    fi
fi

# CIS 2.2: Password reuse restriction
if command -v /opt/vmware/bin/sso-config.sh >/dev/null 2>&1; then
    password_history=$(/opt/vmware/bin/sso-config.sh -get_password_policy 2>/dev/null | grep -i "prohibitedPreviousPasswordsCount" | awk -F':' '{print $2}' | tr -d ' ' || echo "")
    if [[ -n "$password_history" ]] && [[ "$password_history" -ge 5 ]]; then
        register_check "Password history" PASS "$password_history previous - CIS 2.2"
    elif [[ -n "$password_history" ]]; then
        register_check "Password history" WARN "$password_history (recommend >=5)"
    fi
fi

# CIS 2.3: SSO token lifetime
if command -v /opt/vmware/bin/sso-config.sh >/dev/null 2>&1; then
    # shellcheck disable=SC2034  # clock_tolerance used for logging purposes
    clock_tolerance=$(/opt/vmware/bin/sso-config.sh -get_clocktolerance 2>/dev/null | grep -i "clockTolerance" | awk -F':' '{print $2}' || echo "")
    bearer_lifetime=$(/opt/vmware/bin/sso-config.sh -get_bearer_token_lifetime 2>/dev/null | grep -i "bearerTokenLifetime" | awk -F':' '{print $2}' || echo "")
    if [[ -n "$bearer_lifetime" ]]; then
        if [[ "$bearer_lifetime" -le 300000 ]]; then
            register_check "Bearer token lifetime" PASS "${bearer_lifetime}ms - CIS 2.3"
        else
            register_check "Bearer token lifetime" WARN "${bearer_lifetime}ms (recommend <=300000)"
        fi
    fi
fi

# CIS 3.1: PostgreSQL security hardening
PG_HBA="/storage/db/vpostgres/pg_hba.conf"
if [[ -f "$PG_HBA" ]]; then
    # Check for md5/scram-sha-256 authentication
    if grep -qE "^(local|host).*md5|scram-sha-256" "$PG_HBA" 2>/dev/null; then
        register_check "PostgreSQL auth" PASS "secure auth configured - CIS 3.1"
    elif grep -qE "^(local|host).*trust" "$PG_HBA" 2>/dev/null; then
        register_check "PostgreSQL auth" FAIL "trust auth detected - CIS 3.1"
    fi

    # Check pg_hba.conf permissions
    pg_perms=$(stat -c "%a" "$PG_HBA" 2>/dev/null || echo "unknown")
    if [[ "$pg_perms" == "600" ]] || [[ "$pg_perms" == "640" ]]; then
        register_check "PostgreSQL config perms" PASS "$pg_perms"
    else
        register_check "PostgreSQL config perms" WARN "$pg_perms (recommend 600)"
    fi
fi

# CIS 4.1: Content Library access controls
if command -v /usr/lib/vmware-content-library/support/scripts/cls-cli.sh >/dev/null 2>&1; then
    # Check for subscribed libraries with auto-sync
    cls_count=$(/usr/lib/vmware-content-library/support/scripts/cls-cli.sh list 2>/dev/null | grep -c "SUBSCRIBED" || echo "0")
    if [[ "$cls_count" -gt 0 ]]; then
        register_check "Subscribed content libraries" WARN "$cls_count libraries (review sync settings)"
    else
        register_check "Content libraries" PASS "no subscribed libraries"
    fi
fi

# CIS 5.1: Verify vSphere Lifecycle Manager patches
if command -v software-packages >/dev/null 2>&1; then
    pending_updates=$(software-packages list --staged 2>/dev/null | grep -c "." || echo "0")
    if [[ "$pending_updates" -gt 0 ]]; then
        register_check "Staged updates" WARN "$pending_updates pending - CIS 5.1"
    else
        register_check "Staged updates" PASS "none pending"
    fi
fi

# CIS 6.1: Verify VAMI access restrictions
if [[ -f /opt/vmware/etc/lighttpd/lighttpd.conf ]]; then
    vami_bind=$(grep -E "^server\.bind" /opt/vmware/etc/lighttpd/lighttpd.conf 2>/dev/null | awk -F'=' '{print $2}' | tr -d ' "' || echo "")
    if [[ "$vami_bind" == "127.0.0.1" ]] || [[ "$vami_bind" == "localhost" ]]; then
        register_check "VAMI bind address" PASS "localhost only - CIS 6.1"
    elif [[ -n "$vami_bind" ]]; then
        register_check "VAMI bind address" WARN "$vami_bind (consider localhost only)"
    fi
fi

# CIS 7.1: Verify bash shell access logging
if [[ -f /etc/profile.d/audit.sh ]] || grep -qi "HISTFILE\|HISTTIMEFORMAT" /etc/profile 2>/dev/null; then
    register_check "Shell history audit" PASS "configured - CIS 7.1"
else
    register_check "Shell history audit" WARN "not configured"
fi

# CIS 8.1: Reverse proxy TLS settings
if [[ -f /etc/vmware-rhttpproxy/config.xml ]]; then
    ssl_protocols=$(grep -i "sslProtocol" /etc/vmware-rhttpproxy/config.xml 2>/dev/null || echo "")
    if echo "$ssl_protocols" | grep -qi "TLSv1.2\|TLSv1.3"; then
        register_check "Reverse proxy TLS" PASS "TLS 1.2+ - CIS 8.1"
    else
        register_check "Reverse proxy TLS" WARN "verify TLS 1.2+ only"
    fi
fi

# ============================================================================
section "Summary"
# ============================================================================

print_summary
exit "$EXIT_CODE"
