<#
.SYNOPSIS
    VMware vCenter Security Audit via PowerCLI

.DESCRIPTION
    Cross-platform vCenter audit script using VMware PowerCLI.
    Runs on Windows, Linux, or macOS with PowerShell 7+ and VMware.PowerCLI module.

.PARAMETER Server
    vCenter Server hostname or IP address

.PARAMETER Credential
    PSCredential object for authentication. If not provided, prompts for credentials.

.PARAMETER SkipCertificateCheck
    Skip SSL certificate validation (for self-signed certs)

.EXAMPLE
    ./vcenter-powercli-audit.ps1 -Server vcenter.example.com

.EXAMPLE
    $cred = Get-Credential
    ./vcenter-powercli-audit.ps1 -Server vcenter.example.com -Credential $cred -SkipCertificateCheck

.NOTES
    Compliance Mapping:
    - CIS VMware vCenter Benchmark
    - NIST SP 800-53: AC-2, AC-6, AU-2
    - VMware Security Hardening Guide
    - PCI DSS: 8.1, 10.1
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Server,

    [Parameter(Mandatory = $false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory = $false)]
    [switch]$SkipCertificateCheck
)

#region Initialization
$ErrorActionPreference = "Stop"

# Check for PowerCLI
if (-not (Get-Module -ListAvailable -Name VMware.PowerCLI)) {
    Write-Error "VMware.PowerCLI module not installed. Install with: Install-Module VMware.PowerCLI -Scope CurrentUser"
    exit 1
}

Import-Module VMware.PowerCLI -ErrorAction SilentlyContinue

# Suppress CEIP warning
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false -ErrorAction SilentlyContinue | Out-Null

if ($SkipCertificateCheck) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
}

# Results tracking
$script:Results = @{
    Checks = @()
    Passed = 0
    Warnings = 0
    Failed = 0
    Skipped = 0
}

function Register-Check {
    param(
        [string]$Name,
        [ValidateSet("PASS", "WARN", "FAIL", "SKIP")]
        [string]$Status,
        [string]$Message = ""
    )

    $null = switch ($Status) {
        "PASS" { "Green" }
        "WARN" { "Yellow" }
        "FAIL" { "Red" }
        "SKIP" { "Gray" }
    }

    Write-Output "[$Status] "
    Write-Output "$Name"
    if ($Message) { Write-Output " - $Message" } else { Write-Output "" }

    $script:Results.Checks += @{
        Name = $Name
        Status = $Status
        Message = $Message
    }

    switch ($Status) {
        "PASS" { $script:Results.Passed++ }
        "WARN" { $script:Results.Warnings++ }
        "FAIL" { $script:Results.Failed++ }
        "SKIP" { $script:Results.Skipped++ }
    }
}

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}
#endregion

#region Connection
Write-Section "vCenter Connection"

try {
    if ($Credential) {
        $viServer = Connect-VIServer -Server $Server -Credential $Credential -ErrorAction Stop
    } else {
        $viServer = Connect-VIServer -Server $Server -ErrorAction Stop
    }
    Register-Check -Name "vCenter Connection" -Status PASS -Message $viServer.Name
} catch {
    Register-Check -Name "vCenter Connection" -Status FAIL -Message $_.Exception.Message
    exit 1
}

# Get vCenter version
try {
    $vcVersion = $viServer.Version
    $vcBuild = $viServer.Build
    Register-Check -Name "vCenter Version" -Status PASS -Message "$vcVersion (Build $vcBuild)"
} catch {
    Register-Check -Name "vCenter Version" -Status SKIP -Message "Could not retrieve"
}
#endregion

#region SSO and Authentication
Write-Section "SSO and Authentication"

try {
    # Get SSO domain
    $ssoConfig = Get-AdvancedSetting -Entity $viServer -Name "config.vpxd.sso.*" -ErrorAction SilentlyContinue
    if ($ssoConfig) {
        Register-Check -Name "SSO Configuration" -Status PASS -Message "Retrieved"
    }
} catch {
    Register-Check -Name "SSO Configuration" -Status SKIP -Message "Requires VCSA access"
}

# Check password policies via API
try {
    $passwordPolicy = Get-VIPermission | Where-Object { $_.Principal -like "*admin*" } | Select-Object -First 1
    if ($passwordPolicy) {
        Register-Check -Name "Admin permissions" -Status PASS -Message "Admin roles configured"
    }
} catch {
    Register-Check -Name "Admin permissions" -Status SKIP
}

# Check for too many administrators
try {
    $adminPerms = Get-VIPermission | Where-Object { $_.Role -eq "Admin" }
    $adminCount = ($adminPerms | Select-Object -Property Principal -Unique).Count
    if ($adminCount -le 5) {
        Register-Check -Name "Administrator count" -Status PASS -Message "$adminCount admin(s)"
    } else {
        Register-Check -Name "Administrator count" -Status WARN -Message "$adminCount admins (review necessity)"
    }
} catch {
    Register-Check -Name "Administrator count" -Status SKIP
}

# Check for orphaned permissions
try {
    $orphaned = Get-VIPermission | Where-Object { $_.Principal -match "^\?" }
    if ($orphaned.Count -eq 0) {
        Register-Check -Name "Orphaned permissions" -Status PASS -Message "None found"
    } else {
        Register-Check -Name "Orphaned permissions" -Status WARN -Message "$($orphaned.Count) orphaned permission(s)"
    }
} catch {
    Register-Check -Name "Orphaned permissions" -Status SKIP
}
#endregion

#region Certificate Security
Write-Section "Certificate Security"

try {
    # Check vCenter certificate
    $cert = $viServer.CertificateInfo
    if ($cert) {
        $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days
        if ($daysUntilExpiry -gt 30) {
            Register-Check -Name "vCenter Certificate" -Status PASS -Message "$daysUntilExpiry days until expiry"
        } elseif ($daysUntilExpiry -gt 0) {
            Register-Check -Name "vCenter Certificate" -Status WARN -Message "Expires in $daysUntilExpiry days"
        } else {
            Register-Check -Name "vCenter Certificate" -Status FAIL -Message "Certificate expired"
        }

        # Check if self-signed
        if ($cert.Issuer -eq $cert.Subject) {
            Register-Check -Name "Certificate Type" -Status WARN -Message "Self-signed (recommend CA-signed)"
        } else {
            Register-Check -Name "Certificate Type" -Status PASS -Message "CA-signed"
        }
    }
} catch {
    Register-Check -Name "vCenter Certificate" -Status SKIP -Message "Could not retrieve"
}
#endregion

#region ESXi Host Security
Write-Section "ESXi Host Security"

try {
    $vmHosts = Get-VMHost -ErrorAction Stop
    Register-Check -Name "ESXi Hosts" -Status PASS -Message "$($vmHosts.Count) host(s) managed"

    foreach ($vmHost in $vmHosts) {
        # Check lockdown mode
        try {
            $lockdown = $vmHost.ExtensionData.Config.LockdownMode
            if ($lockdown -ne "lockdownDisabled") {
                Register-Check -Name "$($vmHost.Name) Lockdown" -Status PASS -Message $lockdown
            } else {
                Register-Check -Name "$($vmHost.Name) Lockdown" -Status WARN -Message "Disabled"
            }
        } catch {
            Register-Check -Name "$($vmHost.Name) Lockdown" -Status SKIP
        }

        # Check SSH status
        try {
            $sshService = Get-VMHostService -VMHost $vmHost | Where-Object { $_.Key -eq "TSM-SSH" }
            if ($sshService.Running) {
                Register-Check -Name "$($vmHost.Name) SSH" -Status WARN -Message "Running (disable if not needed)"
            } else {
                Register-Check -Name "$($vmHost.Name) SSH" -Status PASS -Message "Stopped"
            }
        } catch {
            Register-Check -Name "$($vmHost.Name) SSH" -Status SKIP
        }

        # Check NTP configuration
        try {
            $ntpServers = Get-VMHostNtpServer -VMHost $vmHost
            if ($ntpServers) {
                Register-Check -Name "$($vmHost.Name) NTP" -Status PASS -Message "$($ntpServers.Count) server(s)"
            } else {
                Register-Check -Name "$($vmHost.Name) NTP" -Status WARN -Message "No NTP configured"
            }
        } catch {
            Register-Check -Name "$($vmHost.Name) NTP" -Status SKIP
        }
    }
} catch {
    Register-Check -Name "ESXi Hosts" -Status SKIP -Message "Could not enumerate"
}
#endregion

#region Logging and Audit
Write-Section "Logging and Audit"

try {
    # Check syslog configuration on hosts
    foreach ($vmHost in $vmHosts) {
        try {
            $syslog = Get-AdvancedSetting -Entity $vmHost -Name "Syslog.global.logHost" -ErrorAction SilentlyContinue
            if ($syslog -and $syslog.Value) {
                Register-Check -Name "$($vmHost.Name) Syslog" -Status PASS -Message $syslog.Value
            } else {
                Register-Check -Name "$($vmHost.Name) Syslog" -Status WARN -Message "Not configured"
            }
        } catch {
            Register-Check -Name "$($vmHost.Name) Syslog" -Status SKIP
        }
    }
} catch {
    Register-Check -Name "Syslog Configuration" -Status SKIP
}

# Check vCenter events/tasks retention
try {
    $eventRetention = Get-AdvancedSetting -Entity $viServer -Name "event.maxAge" -ErrorAction SilentlyContinue
    if ($eventRetention) {
        if ($eventRetention.Value -ge 30) {
            Register-Check -Name "Event retention" -Status PASS -Message "$($eventRetention.Value) days"
        } else {
            Register-Check -Name "Event retention" -Status WARN -Message "$($eventRetention.Value) days (recommend >=30)"
        }
    }
} catch {
    Register-Check -Name "Event retention" -Status SKIP
}
#endregion

#region Network Security
Write-Section "Network Security"

try {
    # Check distributed switches
    $dvSwitches = Get-VDSwitch -ErrorAction SilentlyContinue
    if ($dvSwitches) {
        Register-Check -Name "Distributed Switches" -Status PASS -Message "$($dvSwitches.Count) VDS"

        foreach ($dvs in $dvSwitches) {
            # Check for promiscuous mode
            try {
                $secPolicy = $dvs | Get-VDSecurityPolicy
                if ($secPolicy.AllowPromiscuous) {
                    Register-Check -Name "$($dvs.Name) Promiscuous" -Status WARN -Message "Enabled"
                } else {
                    Register-Check -Name "$($dvs.Name) Promiscuous" -Status PASS -Message "Disabled"
                }

                if ($secPolicy.ForgedTransmits) {
                    Register-Check -Name "$($dvs.Name) Forged Transmits" -Status WARN -Message "Allowed"
                } else {
                    Register-Check -Name "$($dvs.Name) Forged Transmits" -Status PASS -Message "Rejected"
                }

                if ($secPolicy.MacChanges) {
                    Register-Check -Name "$($dvs.Name) MAC Changes" -Status WARN -Message "Allowed"
                } else {
                    Register-Check -Name "$($dvs.Name) MAC Changes" -Status PASS -Message "Rejected"
                }
            } catch {
                Register-Check -Name "$($dvs.Name) Security Policy" -Status SKIP
            }
        }
    } else {
        Register-Check -Name "Distributed Switches" -Status SKIP -Message "None found (using standard switches)"
    }
} catch {
    Register-Check -Name "Network Security" -Status SKIP
}
#endregion

#region Storage Security
Write-Section "Storage Security"

try {
    $datastores = Get-Datastore -ErrorAction SilentlyContinue
    Register-Check -Name "Datastores" -Status PASS -Message "$($datastores.Count) datastore(s)"

    # Check for thin provisioned VMs on shared storage
    $thinVMs = Get-VM | Get-HardDisk | Where-Object { $_.StorageFormat -eq "Thin" }
    if ($thinVMs) {
        Register-Check -Name "Thin provisioned disks" -Status PASS -Message "$($thinVMs.Count) disk(s)"
    }
} catch {
    Register-Check -Name "Storage" -Status SKIP
}
#endregion

#region VM Security
Write-Section "Virtual Machine Security"

try {
    $vms = Get-VM -ErrorAction Stop
    Register-Check -Name "Virtual Machines" -Status PASS -Message "$($vms.Count) VM(s)"

    # Sample check - VMware Tools
    $noTools = $vms | Where-Object { $_.ExtensionData.Guest.ToolsStatus -eq "toolsNotInstalled" }
    if ($noTools.Count -eq 0) {
        Register-Check -Name "VMware Tools" -Status PASS -Message "Installed on all VMs"
    } else {
        Register-Check -Name "VMware Tools" -Status WARN -Message "$($noTools.Count) VM(s) without tools"
    }

    # Check for VMs with CD/DVD connected
    $connectedCD = $vms | Get-CDDrive | Where-Object { $_.ConnectionState.Connected }
    if ($connectedCD.Count -eq 0) {
        Register-Check -Name "Connected CD/DVD" -Status PASS -Message "None"
    } else {
        Register-Check -Name "Connected CD/DVD" -Status WARN -Message "$($connectedCD.Count) connected (security risk)"
    }

    # Check for VMs with USB connected
    $usbDevices = $vms | Get-UsbDevice -ErrorAction SilentlyContinue
    if ($usbDevices.Count -eq 0) {
        Register-Check -Name "USB Devices" -Status PASS -Message "None connected"
    } else {
        Register-Check -Name "USB Devices" -Status WARN -Message "$($usbDevices.Count) USB device(s)"
    }
} catch {
    Register-Check -Name "Virtual Machines" -Status SKIP
}
#endregion

#region High Availability and DRS
Write-Section "Cluster Configuration"

try {
    $clusters = Get-Cluster -ErrorAction SilentlyContinue
    if ($clusters) {
        foreach ($cluster in $clusters) {
            # HA Status
            if ($cluster.HAEnabled) {
                Register-Check -Name "$($cluster.Name) HA" -Status PASS -Message "Enabled"

                # Check HA admission control
                if ($cluster.HAAdmissionControlEnabled) {
                    Register-Check -Name "$($cluster.Name) Admission Control" -Status PASS -Message "Enabled"
                } else {
                    Register-Check -Name "$($cluster.Name) Admission Control" -Status WARN -Message "Disabled"
                }
            } else {
                Register-Check -Name "$($cluster.Name) HA" -Status WARN -Message "Disabled"
            }

            # DRS Status
            if ($cluster.DrsEnabled) {
                Register-Check -Name "$($cluster.Name) DRS" -Status PASS -Message $cluster.DrsAutomationLevel
            } else {
                Register-Check -Name "$($cluster.Name) DRS" -Status WARN -Message "Disabled"
            }
        }
    }
} catch {
    Register-Check -Name "Clusters" -Status SKIP
}
#endregion

#region CIS Additional Controls
Write-Section "CIS Additional Security Controls"

# CIS: Check VM advanced settings for security
try {
    foreach ($vm in $vms | Select-Object -First 20) {
        # Check for isolation.tools.copy.disable (CIS)
        $copyDisable = Get-AdvancedSetting -Entity $vm -Name "isolation.tools.copy.disable" -ErrorAction SilentlyContinue
        if ($copyDisable -and $copyDisable.Value -eq $true) {
            # Good - copy is disabled
        } elseif ($copyDisable) {
            Register-Check -Name "$($vm.Name) Copy/Paste" -Status WARN -Message "Enabled (CIS violation)"
        }

        # Check for disk shrinking (CIS)
        $diskShrink = Get-AdvancedSetting -Entity $vm -Name "isolation.tools.diskShrink.disable" -ErrorAction SilentlyContinue
        if ($diskShrink -and $diskShrink.Value -eq $false) {
            Register-Check -Name "$($vm.Name) Disk Shrink" -Status WARN -Message "Enabled"
        }
    }
    Register-Check -Name "VM Isolation Settings" -Status PASS -Message "Audited"
} catch {
    Register-Check -Name "VM Isolation Settings" -Status SKIP
}

# CIS: Check ESXi host advanced settings
try {
    foreach ($vmHost in $vmHosts | Select-Object -First 5) {
        # Check DCUI timeout (CIS 1.3)
        $dcuiTimeout = Get-AdvancedSetting -Entity $vmHost -Name "UserVars.DcuiTimeOut" -ErrorAction SilentlyContinue
        if ($dcuiTimeout -and $dcuiTimeout.Value -ge 600) {
            Register-Check -Name "$($vmHost.Name) DCUI Timeout" -Status PASS -Message "$($dcuiTimeout.Value)s"
        } elseif ($dcuiTimeout) {
            Register-Check -Name "$($vmHost.Name) DCUI Timeout" -Status WARN -Message "$($dcuiTimeout.Value)s (recommend >=600)"
        }

        # Check shell timeout (CIS 1.2)
        $shellTimeout = Get-AdvancedSetting -Entity $vmHost -Name "UserVars.ESXiShellTimeOut" -ErrorAction SilentlyContinue
        if ($shellTimeout -and $shellTimeout.Value -le 900 -and $shellTimeout.Value -gt 0) {
            Register-Check -Name "$($vmHost.Name) Shell Timeout" -Status PASS -Message "$($shellTimeout.Value)s"
        } elseif ($shellTimeout -and $shellTimeout.Value -eq 0) {
            Register-Check -Name "$($vmHost.Name) Shell Timeout" -Status WARN -Message "Disabled (CIS violation)"
        }

        # Check account lockout (CIS 6.1)
        $lockoutFailures = Get-AdvancedSetting -Entity $vmHost -Name "Security.AccountLockFailures" -ErrorAction SilentlyContinue
        if ($lockoutFailures -and $lockoutFailures.Value -le 5) {
            Register-Check -Name "$($vmHost.Name) Lockout Failures" -Status PASS -Message "$($lockoutFailures.Value) attempts"
        } elseif ($lockoutFailures) {
            Register-Check -Name "$($vmHost.Name) Lockout Failures" -Status WARN -Message "$($lockoutFailures.Value) (recommend <=5)"
        }

        # Check password quality (CIS 6.2)
        $passwordQuality = Get-AdvancedSetting -Entity $vmHost -Name "Security.PasswordQualityControl" -ErrorAction SilentlyContinue
        if ($passwordQuality) {
            Register-Check -Name "$($vmHost.Name) Password Policy" -Status PASS -Message "Configured"
        }
    }
} catch {
    Register-Check -Name "Host Advanced Settings" -Status SKIP
}

# CIS: Verify vSwitch security policies
try {
    $vSwitches = Get-VirtualSwitch -ErrorAction SilentlyContinue
    foreach ($vSwitch in $vSwitches | Select-Object -First 10) {
        $secPolicy = $vSwitch | Get-SecurityPolicy -ErrorAction SilentlyContinue
        if ($secPolicy) {
            if ($secPolicy.AllowPromiscuous -eq $false) {
                Register-Check -Name "$($vSwitch.Name) Promiscuous" -Status PASS -Message "Disabled"
            } else {
                Register-Check -Name "$($vSwitch.Name) Promiscuous" -Status WARN -Message "Enabled (CIS violation)"
            }
        }
    }
} catch {
    Register-Check -Name "vSwitch Security" -Status SKIP
}

# CIS: Check for MOB (Managed Object Browser) - disabled by default in recent versions
try {
    foreach ($vmHost in $vmHosts | Select-Object -First 3) {
        $mob = Get-AdvancedSetting -Entity $vmHost -Name "Config.HostAgent.plugins.solo.enableMob" -ErrorAction SilentlyContinue
        if ($mob -and $mob.Value -eq $false) {
            Register-Check -Name "$($vmHost.Name) MOB" -Status PASS -Message "Disabled (CIS 1.4)"
        } elseif ($mob -and $mob.Value -eq $true) {
            Register-Check -Name "$($vmHost.Name) MOB" -Status FAIL -Message "Enabled (CIS 1.4 violation)"
        }
    }
} catch {
    Register-Check -Name "MOB Status" -Status SKIP
}

# CIS: Check iSCSI CHAP authentication
try {
    foreach ($vmHost in $vmHosts | Select-Object -First 3) {
        $iscsiHba = Get-VMHostHba -VMHost $vmHost -Type IScsi -ErrorAction SilentlyContinue
        if ($iscsiHba) {
            $authMethod = $iscsiHba.AuthenticationProperties
            if ($authMethod.MutualChapEnabled -or $authMethod.ChapType -eq "Required") {
                Register-Check -Name "$($vmHost.Name) iSCSI CHAP" -Status PASS -Message "Enabled (CIS 7.2)"
            } else {
                Register-Check -Name "$($vmHost.Name) iSCSI CHAP" -Status WARN -Message "Not enforced"
            }
        }
    }
} catch {
    Register-Check -Name "iSCSI CHAP" -Status SKIP -Message "No iSCSI or error"
}

# Check alarm definitions for security monitoring
try {
    $alarms = Get-AlarmDefinition -ErrorAction SilentlyContinue
    $secAlarms = $alarms | Where-Object { $_.Name -match "security|login|account|permission" }
    if ($secAlarms.Count -ge 3) {
        Register-Check -Name "Security Alarms" -Status PASS -Message "$($secAlarms.Count) security-related alarms"
    } else {
        Register-Check -Name "Security Alarms" -Status WARN -Message "$($secAlarms.Count) alarms (consider adding more)"
    }
} catch {
    Register-Check -Name "Security Alarms" -Status SKIP
}
#endregion

#region Cleanup and Summary
Write-Section "Disconnecting"

Disconnect-VIServer -Server $viServer -Confirm:$false -ErrorAction SilentlyContinue

Write-Section "Audit Summary"
Write-Output "Total Checks: $($script:Results.Checks.Count)"
Write-Output "Passed: $($script:Results.Passed)"
Write-Output "Warnings: $($script:Results.Warnings)"
Write-Output "Failed: $($script:Results.Failed)"
Write-Output "Skipped: $($script:Results.Skipped)"

# Return results object for automation
$script:Results
#endregion
