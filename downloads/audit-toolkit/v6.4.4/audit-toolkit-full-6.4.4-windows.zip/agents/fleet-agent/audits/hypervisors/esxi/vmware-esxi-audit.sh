#!/usr/bin/env bash
# vmware-esxi-audit.sh — VMware ESXi Remote Security Audit
#
# Compliance Mapping:
# - CIS VMware ESXi Benchmark
# - NIST SP 800-125: Virtualization Security
# - NIST SP 800-53: SC-3, SC-4, AC-4 (Isolation)
# - VMware Security Hardening Guide
# - PCI DSS: 2.2.1 (Hypervisor Hardening)
#
# Note: This script audits VMware ESXi via SSH or locally
# if running on a vSphere management appliance.
#
# Checks:
# - SSH hardening
# - Lockdown mode
# - Service timeouts
# - Logging/syslog
# - Network security
# - Account policies

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "VMware ESXi Detection"

# Check if we're on ESXi or have esxcli available
esxcli_cmd=""
if command -v esxcli >/dev/null 2>&1; then
  esxcli_cmd="esxcli"
elif command -v /bin/esxcli >/dev/null 2>&1; then
  esxcli_cmd="/bin/esxcli"
fi

# Check for vim-cmd (ESXi shell command)
vim_cmd=""
if command -v vim-cmd >/dev/null 2>&1; then
  vim_cmd="vim-cmd"
fi

# Check for PowerCLI (alternative)
pwcli=""
if command -v pwsh >/dev/null 2>&1; then
  if pwsh -Command "Get-Module -ListAvailable VMware.PowerCLI" 2>/dev/null | grep -q "VMware"; then
    pwcli="available"
  fi
fi

if [[ -z "$esxcli_cmd" ]] && [[ -z "$vim_cmd" ]] && [[ -z "$pwcli" ]]; then
  register_check "VMware ESXi" SKIP "not detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "VMware ESXi" PASS "detected"

# Get ESXi version
if [[ -n "$esxcli_cmd" ]]; then
  esxi_version=$($esxcli_cmd system version get 2>/dev/null | grep -E "Version:|Build:" | tr '\n' ' ' || echo "unknown")
  register_check "ESXi version" PASS "$esxi_version"
fi

section "SSH Hardening (CIS 1.x)"

# Check SSH service status
if [[ -n "$esxcli_cmd" ]]; then
  ssh_running=$($esxcli_cmd system settings advanced list -o /UserVars/ESXiShellInteractiveTimeOut 2>/dev/null | grep "Int Value" | awk '{print $NF}' || echo "0")

  # ESXiShellInteractiveTimeOut
  if [[ "$ssh_running" -gt 0 ]] && [[ "$ssh_running" -le 900 ]]; then
    register_check "Shell timeout" PASS "${ssh_running}s"
  elif [[ "$ssh_running" -gt 900 ]]; then
    register_check "Shell timeout" WARN "${ssh_running}s (should be <= 900)"
  else
    register_check "Shell timeout" WARN "not set"
  fi

  # ESXiShellTimeOut
  shell_timeout=$($esxcli_cmd system settings advanced list -o /UserVars/ESXiShellTimeOut 2>/dev/null | grep "Int Value" | awk '{print $NF}' || echo "0")
  if [[ "$shell_timeout" -gt 0 ]] && [[ "$shell_timeout" -le 3600 ]]; then
    register_check "Shell idle timeout" PASS "${shell_timeout}s"
  else
    register_check "Shell idle timeout" WARN "${shell_timeout}s"
  fi

  # Check SSH service policy
  ssh_policy=$($esxcli_cmd system settings advanced list -o /UserVars/SuppressShellWarning 2>/dev/null | grep "Int Value" | awk '{print $NF}' || echo "0")
  if [[ "$ssh_policy" -eq 0 ]]; then
    register_check "Shell warning" PASS "enabled"
  else
    register_check "Shell warning" WARN "suppressed"
  fi
fi

section "Lockdown Mode (CIS 2.x)"

if [[ -n "$vim_cmd" ]]; then
  lockdown=$($vim_cmd hostsvc/hostsummary 2>/dev/null | grep -i "lockdownMode" | awk -F'"' '{print $2}' || echo "unknown")

  if [[ "$lockdown" == "lockdownNormal" ]] || [[ "$lockdown" == "lockdownStrict" ]]; then
    register_check "Lockdown mode" PASS "$lockdown"
  elif [[ "$lockdown" == "lockdownDisabled" ]]; then
    register_check "Lockdown mode" WARN "disabled"
  else
    register_check "Lockdown mode" WARN "$lockdown"
  fi
fi

section "DCUI Timeout (CIS 3.x)"

if [[ -n "$esxcli_cmd" ]]; then
  dcui_timeout=$($esxcli_cmd system settings advanced list -o /UserVars/DcuiTimeOut 2>/dev/null | grep "Int Value" | awk '{print $NF}' || echo "0")

  if [[ "$dcui_timeout" -gt 0 ]] && [[ "$dcui_timeout" -le 600 ]]; then
    register_check "DCUI timeout" PASS "${dcui_timeout}s"
  elif [[ "$dcui_timeout" -eq 0 ]]; then
    register_check "DCUI timeout" WARN "disabled"
  else
    register_check "DCUI timeout" WARN "${dcui_timeout}s"
  fi
fi

section "Logging Configuration (CIS 4.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check syslog configuration
  syslog_host=$($esxcli_cmd system syslog config get 2>/dev/null | grep -E "Remote Host:" | awk '{print $NF}' || echo "")

  if [[ -n "$syslog_host" ]] && [[ "$syslog_host" != "n/a" ]]; then
    register_check "Remote syslog" PASS "$syslog_host"
  else
    register_check "Remote syslog" WARN "not configured"
  fi

  # Check log level
  log_level=$($esxcli_cmd system syslog config get 2>/dev/null | grep -E "Log Level:" | awk '{print $NF}' || echo "")
  if [[ -n "$log_level" ]]; then
    register_check "Log level" PASS "$log_level"
  fi

  # Check log rotation
  log_size=$($esxcli_cmd system syslog config get 2>/dev/null | grep -E "Log Size:" | awk '{print $NF}' || echo "")
  if [[ -n "$log_size" ]]; then
    register_check "Log size limit" PASS "$log_size"
  fi
fi

section "NTP Configuration (CIS 5.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check NTP servers
  ntp_servers=$($esxcli_cmd system ntp get 2>/dev/null | grep -E "Servers:" | awk -F': ' '{print $2}' || echo "")

  if [[ -n "$ntp_servers" ]]; then
    register_check "NTP servers" PASS "$ntp_servers"
  else
    register_check "NTP servers" WARN "not configured"
  fi

  # Check NTP service
  ntp_enabled=$($esxcli_cmd system ntp get 2>/dev/null | grep -E "Enabled:" | awk '{print $NF}' || echo "false")
  if [[ "$ntp_enabled" == "true" ]]; then
    register_check "NTP service" PASS "enabled"
  else
    register_check "NTP service" WARN "disabled"
  fi
fi

section "Network Security (CIS 6.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check vSwitch security policy
  vswitches=$($esxcli_cmd network vswitch standard list 2>/dev/null | grep "Name:" | awk '{print $2}' || echo "")

  for vswitch in $vswitches; do
    # Promiscuous mode
    promisc=$($esxcli_cmd network vswitch standard policy security get -v "$vswitch" 2>/dev/null | grep "Allow Promiscuous:" | awk '{print $NF}' || echo "")
    if [[ "$promisc" == "false" ]]; then
      register_check "$vswitch promiscuous" PASS "disabled"
    else
      register_check "$vswitch promiscuous" WARN "enabled"
    fi

    # MAC address changes
    mac_change=$($esxcli_cmd network vswitch standard policy security get -v "$vswitch" 2>/dev/null | grep "Allow MAC Address Change:" | awk '{print $NF}' || echo "")
    if [[ "$mac_change" == "false" ]]; then
      register_check "$vswitch MAC changes" PASS "disabled"
    else
      register_check "$vswitch MAC changes" WARN "enabled"
    fi

    # Forged transmits
    forged=$($esxcli_cmd network vswitch standard policy security get -v "$vswitch" 2>/dev/null | grep "Allow Forged Transmits:" | awk '{print $NF}' || echo "")
    if [[ "$forged" == "false" ]]; then
      register_check "$vswitch forged TX" PASS "disabled"
    else
      register_check "$vswitch forged TX" WARN "enabled"
    fi
  done
fi

section "Management Network (CIS 7.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check management network isolation
  mgmt_net=$($esxcli_cmd network ip interface list 2>/dev/null | grep -A5 "vmk0" | grep "Portgroup:" | awk '{print $2}' || echo "")

  if [[ -n "$mgmt_net" ]]; then
    register_check "Management network" PASS "$mgmt_net"
  fi

  # Check for VLAN tagging on management
  mgmt_vlan=$($esxcli_cmd network vswitch standard portgroup list 2>/dev/null | grep "Management" | awk '{print $4}' || echo "0")
  if [[ "$mgmt_vlan" -gt 0 ]]; then
    register_check "Management VLAN" PASS "VLAN $mgmt_vlan"
  else
    register_check "Management VLAN" WARN "untagged"
  fi
fi

section "Firewall Configuration (CIS 8.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check firewall status
  fw_enabled=$($esxcli_cmd network firewall get 2>/dev/null | grep "Enabled:" | awk '{print $2}' || echo "false")

  if [[ "$fw_enabled" == "true" ]]; then
    register_check "Firewall" PASS "enabled"
  else
    register_check "Firewall" FAIL "disabled"
  fi

  # Check default action
  fw_default=$($esxcli_cmd network firewall get 2>/dev/null | grep "Default Action:" | awk '{print $3}' || echo "")
  if [[ "$fw_default" == "DROP" ]]; then
    register_check "Firewall default" PASS "DROP"
  else
    register_check "Firewall default" WARN "$fw_default"
  fi

  # Count enabled rulesets
  enabled_rules=$($esxcli_cmd network firewall ruleset list 2>/dev/null | grep -c "true" || echo "0")
  register_check "Firewall rules" PASS "$enabled_rules enabled"
fi

section "Account Security (CIS 9.x)"

if [[ -n "$esxcli_cmd" ]]; then
  # Check password policies
  password_quality=$($esxcli_cmd system security password get 2>/dev/null || echo "")

  if [[ -n "$password_quality" ]]; then
    min_len=$(echo "$password_quality" | grep "Minimum Length:" | awk '{print $NF}' || echo "0")
    if [[ "$min_len" -ge 14 ]]; then
      register_check "Password min length" PASS "$min_len"
    else
      register_check "Password min length" WARN "$min_len (should be >= 14)"
    fi

    max_days=$(echo "$password_quality" | grep "Maximum Days:" | awk '{print $NF}' || echo "0")
    if [[ "$max_days" -gt 0 ]] && [[ "$max_days" -le 90 ]]; then
      register_check "Password max age" PASS "${max_days} days"
    else
      register_check "Password max age" WARN "${max_days} days"
    fi
  fi

  # Check account lockout
  lockout=$($esxcli_cmd system account list 2>/dev/null | head -n5 || echo "")
  if [[ -n "$lockout" ]]; then
    register_check "Account list" PASS "available"
  fi
fi

section "Storage Security"

if [[ -n "$esxcli_cmd" ]]; then
  # List datastores
  datastores=$($esxcli_cmd storage filesystem list 2>/dev/null | grep -c "VMFS\|NFS\|vsan" || echo "0")
  register_check "Datastores" PASS "$datastores"

  # Check vSAN encryption if applicable
  vsan_enabled=$($esxcli_cmd vsan cluster get 2>/dev/null | grep "Enabled:" | awk '{print $2}' || echo "false")
  if [[ "$vsan_enabled" == "true" ]]; then
    register_check "vSAN" PASS "enabled"

    vsan_encrypt=$($esxcli_cmd vsan encryption get 2>/dev/null | grep "Encryption Status:" | awk '{print $NF}' || echo "unknown")
    if [[ "$vsan_encrypt" == "enabled" ]]; then
      register_check "vSAN encryption" PASS "enabled"
    else
      register_check "vSAN encryption" WARN "disabled"
    fi
  fi
fi

section "VIB & Image Security"

if [[ -n "$esxcli_cmd" ]]; then
  # Check acceptance level
  accept_level=$($esxcli_cmd software acceptance get 2>/dev/null || echo "unknown")

  if [[ "$accept_level" == "VMwareCertified" ]] || [[ "$accept_level" == "VMwareAccepted" ]]; then
    register_check "VIB acceptance" PASS "$accept_level"
  elif [[ "$accept_level" == "PartnerSupported" ]]; then
    register_check "VIB acceptance" PASS "$accept_level"
  elif [[ "$accept_level" == "CommunitySupported" ]]; then
    register_check "VIB acceptance" WARN "$accept_level"
  else
    register_check "VIB acceptance" WARN "$accept_level"
  fi

  # Check for unsigned VIBs
  unsigned_vibs=$($esxcli_cmd software vib list 2>/dev/null | grep -c "CommunitySupported" || echo "0")
  if [[ "$unsigned_vibs" -eq 0 ]]; then
    register_check "Community VIBs" PASS "none"
  else
    register_check "Community VIBs" WARN "$unsigned_vibs installed"
  fi
fi

section "Certificate Security"

if [[ -n "$vim_cmd" ]]; then
  # Check certificate validity
  cert_info=$($vim_cmd hostsvc/summary 2>/dev/null | grep -i "ssl" || echo "")
  if [[ -n "$cert_info" ]]; then
    register_check "SSL certificate" PASS "configured"
  fi
fi

# Check for custom CA cert
if [[ -f "/etc/vmware/ssl/rui.crt" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    cert_issuer=$(openssl x509 -in /etc/vmware/ssl/rui.crt -noout -issuer 2>/dev/null | grep -v "self" || echo "self-signed")
    if echo "$cert_issuer" | grep -qi "self"; then
      register_check "SSL cert type" WARN "self-signed"
    else
      register_check "SSL cert type" PASS "CA-signed"
    fi
  fi
fi

section "Services Security"

if [[ -n "$esxcli_cmd" ]]; then
  # Check for unnecessary services
  services_running=$($esxcli_cmd system control service list 2>/dev/null | grep "Running: true" | wc -l || echo "0")
  register_check "Running services" PASS "$services_running"

  # Check SNMP
  snmp_enabled=$($esxcli_cmd system snmp get 2>/dev/null | grep "Enable:" | awk '{print $2}' || echo "false")
  if [[ "$snmp_enabled" == "false" ]]; then
    register_check "SNMP" PASS "disabled"
  else
    register_check "SNMP" WARN "enabled"
  fi
fi

section "CIS Additional Controls"

# CIS 1.4: Managed Object Browser (MOB) should be disabled
if [[ -n "$vim_cmd" ]]; then
  mob_enabled=$($vim_cmd hostsvc/advopt/get Config.HostAgent.plugins.solo.enableMob 2>/dev/null | grep -i "value" | awk '{print $3}' || echo "")
  if [[ "$mob_enabled" == "false" ]]; then
    register_check "MOB disabled" PASS "CIS 1.4"
  elif [[ "$mob_enabled" == "true" ]]; then
    register_check "MOB disabled" FAIL "enabled - CIS 1.4 violation"
  else
    register_check "MOB disabled" WARN "could not determine"
  fi
fi

# CIS 1.5: VIB acceptance level - PartnerSupported or VMwareCertified
if [[ -n "$esxcli_cmd" ]]; then
  acceptance_level=$($esxcli_cmd software acceptance get 2>/dev/null || echo "")
  if echo "$acceptance_level" | grep -qi "VMwareCertified\|VMwareAccepted\|PartnerSupported"; then
    register_check "VIB acceptance level" PASS "$acceptance_level - CIS 1.5"
  elif echo "$acceptance_level" | grep -qi "CommunitySupported"; then
    register_check "VIB acceptance level" FAIL "CommunitySupported - CIS 1.5 violation"
  else
    register_check "VIB acceptance level" WARN "$acceptance_level"
  fi
fi

# CIS 5.4: Active Directory integration audit
if [[ -n "$vim_cmd" ]]; then
  ad_enabled=$($vim_cmd hostsvc/advopt/get Config.HostAgent.plugins.hostsvc.esxAdminsGroup 2>/dev/null | grep -i "value" || echo "")
  if [[ -n "$ad_enabled" ]]; then
    register_check "AD integration" PASS "configured"
    # Check ESX Admins group name
    admins_group=$(echo "$ad_enabled" | awk '{print $3}')
    if [[ "$admins_group" != "ESX Admins" ]]; then
      register_check "AD admin group" PASS "renamed from default"
    else
      register_check "AD admin group" WARN "using default 'ESX Admins'"
    fi
  fi
fi

# CIS 6.1: Account lockout duration
if [[ -n "$vim_cmd" ]]; then
  lockout_duration=$($vim_cmd hostsvc/advopt/get Security.AccountUnlockTime 2>/dev/null | grep -i "value" | awk '{print $3}' || echo "")
  if [[ -n "$lockout_duration" ]] && [[ "$lockout_duration" -ge 900 ]]; then
    register_check "Account lockout duration" PASS "${lockout_duration}s - CIS 6.1"
  elif [[ -n "$lockout_duration" ]]; then
    register_check "Account lockout duration" WARN "${lockout_duration}s (recommend >=900)"
  fi
fi

# CIS 7.2: iSCSI CHAP authentication (when iSCSI is used)
if [[ -n "$esxcli_cmd" ]]; then
  iscsi_adapters=$($esxcli_cmd iscsi adapter list 2>/dev/null | grep -c "iSCSI" || echo "0")
  if [[ "$iscsi_adapters" -gt 0 ]]; then
    chap_enabled=$($esxcli_cmd iscsi adapter auth chap get 2>/dev/null | grep -i "Required\|Prohibited" || echo "")
    if echo "$chap_enabled" | grep -qi "Required"; then
      register_check "iSCSI CHAP" PASS "required - CIS 7.2"
    elif echo "$chap_enabled" | grep -qi "Prohibited"; then
      register_check "iSCSI CHAP" FAIL "prohibited - CIS 7.2 violation"
    else
      register_check "iSCSI CHAP" WARN "check mutual CHAP config"
    fi
  fi
fi

# CIS 8.1: Bidirectional CHAP for iSCSI
if [[ -n "$esxcli_cmd" ]] && [[ "$iscsi_adapters" -gt 0 ]]; then
  mutual_chap=$($esxcli_cmd iscsi adapter auth chap get --direction=uni 2>/dev/null | grep -i "level" || echo "")
  if echo "$mutual_chap" | grep -qi "Required"; then
    register_check "iSCSI mutual CHAP" PASS "CIS 8.1"
  else
    register_check "iSCSI mutual CHAP" WARN "not enforced"
  fi
fi

# CIS 8.4.1: DVFilter network APIs
if [[ -n "$vim_cmd" ]]; then
  dvfilter=$($vim_cmd hostsvc/advopt/get Net.DVFilterBindIpAddress 2>/dev/null | grep -i "value" | awk '{print $3}' || echo "")
  if [[ -z "$dvfilter" ]] || [[ "$dvfilter" == "" ]]; then
    register_check "DVFilter bind IP" PASS "not set - CIS 8.4.1"
  else
    register_check "DVFilter bind IP" WARN "$dvfilter configured"
  fi
fi

print_summary
exit "$EXIT_CODE"
