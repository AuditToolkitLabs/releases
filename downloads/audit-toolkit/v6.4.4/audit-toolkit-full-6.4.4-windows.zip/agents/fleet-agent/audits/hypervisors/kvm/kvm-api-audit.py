#!/usr/bin/env python3
"""
KVM/QEMU Security Audit via libvirt API

Cross-platform KVM audit using libvirt Python bindings.
Runs on Windows, Linux, or macOS with Python 3.8+.
Supports multiple connection methods: SSH, TCP, TLS.

Compliance Mapping:
- CIS Benchmark: RHEL/Ubuntu KVM Hosts
- NIST SP 800-125: Virtualization Security
- NIST SP 800-53: AC-2, AC-6, AU-2, SC-8
- PCI DSS: 2.2.1, 8.1, 10.1
- STIG: Various virtualization controls

Usage:
    # Local connection (run on KVM host)
    python kvm-api-audit.py

    # Remote via SSH
    python kvm-api-audit.py --host kvm.example.com --transport ssh --user root

    # Remote via TLS (certificate auth)
    python kvm-api-audit.py --host kvm.example.com --transport tls

Requirements:
    pip install libvirt-python

libvirt Documentation: https://libvirt.org/python.html
"""

import argparse
import json
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, List, Optional

try:
    import libvirt
except ImportError:
    print("ERROR: libvirt-python module required.")
    print("Install with: pip install libvirt-python")
    print("On Windows, may need: pip install libvirt-python-binary")
    sys.exit(1)


class AuditResults:
    """Track audit results"""

    def __init__(self):
        self.checks: List[Dict[str, str]] = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0

    def register(self, name: str, status: str, message: str = "") -> None:
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"

        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))

        self.checks.append({"name": name, "status": status, "message": message})

        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1

    def section(self, title: str) -> None:
        """Print section header"""
        print(f"\n\033[96m=== {title} ===\033[0m\n")

    def summary(self) -> None:
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")

    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "timestamp": datetime.now().isoformat(),
            "checks": self.checks,
            "summary": {
                "total": len(self.checks),
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class KVMAudit:
    """KVM/QEMU libvirt API Audit Client"""

    def __init__(self, host: str = None, transport: str = "ssh", user: str = None,
                 driver: str = "qemu", mode: str = "system"):
        self.results = AuditResults()
        self.conn = None
        self.host = host

        # Build connection URI
        if host:
            # Remote connection
            uri = f"{driver}+{transport}://"
            if user:
                uri += f"{user}@"
            uri += f"{host}/{mode}"
        else:
            # Local connection
            uri = f"{driver}:///{mode}"

        # Connect
        try:
            self.conn = libvirt.open(uri)
            if self.conn is None:
                raise Exception("Failed to open connection")

            hostname = self.conn.getHostname()
            self.results.register("libvirt Connection", "PASS", f"Connected to {hostname}")
        except libvirt.libvirtError as e:
            self.results.register("libvirt Connection", "FAIL", str(e))
            raise SystemExit(1)

    def audit_hypervisor_info(self) -> None:
        """Audit hypervisor information"""
        self.results.section("Hypervisor Information")

        # Get version info
        lib_version = self.conn.getLibVersion()
        lib_ver_str = f"{lib_version // 1000000}.{(lib_version % 1000000) // 1000}.{lib_version % 1000}"
        self.results.register("libvirt Version", "PASS", lib_ver_str)

        try:
            hv_type = self.conn.getType()
            self.results.register("Hypervisor Type", "PASS", hv_type)
        except Exception:
            pass

        try:
            hv_version = self.conn.getVersion()
            if hv_version:
                hv_ver_str = f"{hv_version // 1000000}.{(hv_version % 1000000) // 1000}.{hv_version % 1000}"
                self.results.register("Hypervisor Version", "PASS", hv_ver_str)
        except Exception:
            pass

        # Get host CPU info
        try:
            info = self.conn.getInfo()
            self.results.register("Host CPUs", "PASS", f"{info[2]} CPU(s), {info[3]}MHz")
            self.results.register("Host Memory", "PASS", f"{info[1]}MB total")
        except Exception:
            pass

        # Check encryption support
        try:
            caps_xml = self.conn.getCapabilities()
            caps = ET.fromstring(caps_xml)  # nosec B314 - libvirt capabilities XML is from local daemon

            # Check for SEV (AMD Secure Encrypted Virtualization)
            sev = caps.find(".//sev")
            if sev is not None:
                self.results.register("AMD SEV Support", "PASS", "Available")

            # Check for TDX (Intel Trust Domain Extensions)
            tdx = caps.find(".//tdx")
            if tdx is not None:
                self.results.register("Intel TDX Support", "PASS", "Available")
        except Exception:
            pass

    def audit_security_drivers(self) -> None:
        """Audit security driver configuration"""
        self.results.section("Security Drivers")

        try:
            caps_xml = self.conn.getCapabilities()
            caps = ET.fromstring(caps_xml)  # nosec B314 - libvirt capabilities XML is from local daemon

            # Find security drivers
            sec_models = caps.findall(".//secmodel")

            selinux_found = False
            apparmor_found = False
            dac_found = False

            for model in sec_models:
                name_elem = model.find("model")
                doi_elem = model.find("doi")

                if name_elem is not None:
                    model_name = name_elem.text
                    doi = doi_elem.text if doi_elem is not None else "N/A"

                    if model_name.lower() == "selinux":
                        selinux_found = True
                        self.results.register("SELinux", "PASS", f"Enabled (DOI: {doi})")
                    elif model_name.lower() == "apparmor":
                        apparmor_found = True
                        self.results.register("AppArmor", "PASS", f"Enabled (DOI: {doi})")
                    elif model_name.lower() == "dac":
                        dac_found = True
                        self.results.register("DAC", "PASS", f"Enabled (DOI: {doi})")

            if not selinux_found and not apparmor_found:
                self.results.register("MAC Security", "WARN", "No SELinux/AppArmor (recommend enabling)")

            if not dac_found:
                self.results.register("DAC Security", "WARN", "DAC not detected")

        except Exception as e:
            self.results.register("Security Drivers", "SKIP", str(e))

    def audit_domains(self) -> None:
        """Audit VM (domain) security"""
        self.results.section("Virtual Machines (Domains)")

        # Get domain counts
        try:
            active_domains = self.conn.listDomainsID()
            defined_domains = self.conn.listDefinedDomains()

            self.results.register("Running VMs", "PASS", f"{len(active_domains)}")
            self.results.register("Defined VMs", "PASS", f"{len(defined_domains)}")
        except Exception as e:
            self.results.register("Domain Count", "SKIP", str(e))
            return

        # Audit each domain
        domains = []

        # Active domains
        for dom_id in active_domains:
            try:
                dom = self.conn.lookupByID(dom_id)
                domains.append(dom)
            except Exception:
                pass

        # Defined but not running
        for name in defined_domains:
            try:
                dom = self.conn.lookupByName(name)
                domains.append(dom)
            except Exception:
                pass

        # Check domain configurations
        svirt_disabled = 0
        memballoon_disabled = 0
        vcpu_pinning = 0

        for dom in domains:
            try:
                xml_desc = dom.XMLDesc(0)
                root = ET.fromstring(xml_desc)  # nosec B314 - domain XML is from libvirt API

                name = dom.name()

                # Check for sVirt/security label
                seclabel = root.find("seclabel")
                if seclabel is not None:
                    model = seclabel.get("model", "none")
                    relabel = seclabel.get("relabel", "yes")

                    if model == "none":
                        svirt_disabled += 1
                else:
                    svirt_disabled += 1

                # Check memory balloon
                memballoon = root.find(".//memballoon")
                if memballoon is not None:
                    model = memballoon.get("model", "")
                    if model == "none":
                        memballoon_disabled += 1

                # Check vCPU pinning
                cputune = root.find("cputune")
                if cputune is not None:
                    vcpupin = cputune.findall("vcpupin")
                    if vcpupin:
                        vcpu_pinning += 1

            except Exception:
                pass

        total_vms = len(domains)
        if total_vms > 0:
            if svirt_disabled > 0:
                self.results.register("sVirt Security", "WARN",
                                      f"{svirt_disabled}/{total_vms} VM(s) without sVirt")
            else:
                self.results.register("sVirt Security", "PASS", "All VMs have sVirt labels")

            if memballoon_disabled > 0:
                self.results.register("Memory Ballooning", "PASS",
                                      f"{memballoon_disabled} VM(s) disabled (security)")

            if vcpu_pinning > 0:
                self.results.register("vCPU Pinning", "PASS", f"{vcpu_pinning} VM(s) pinned")

    def audit_networks(self) -> None:
        """Audit virtual network security"""
        self.results.section("Virtual Networks")

        try:
            networks = self.conn.listAllNetworks(0)
            self.results.register("Networks", "PASS", f"{len(networks)} network(s)")

            default_nat = 0
            isolated = 0

            for net in networks:
                try:
                    xml_desc = net.XMLDesc(0)
                    root = ET.fromstring(xml_desc)  # nosec B314 - network XML is from libvirt API

                    name = net.name()

                    # Check if NAT
                    forward = root.find("forward")
                    if forward is not None:
                        mode = forward.get("mode", "nat")
                        if mode == "nat" and name == "default":
                            default_nat += 1
                    else:
                        isolated += 1

                except Exception:
                    pass

            if default_nat > 0:
                self.results.register("Default NAT Network", "WARN",
                                      "Default network exists (review necessity)")

            if isolated > 0:
                self.results.register("Isolated Networks", "PASS", f"{isolated} isolated")

        except Exception as e:
            self.results.register("Networks", "SKIP", str(e))

    def audit_storage(self) -> None:
        """Audit storage pool security"""
        self.results.section("Storage Pools")

        try:
            pools = self.conn.listAllStoragePools(0)
            self.results.register("Storage Pools", "PASS", f"{len(pools)} pool(s)")

            for pool in pools:
                try:
                    name = pool.name()
                    xml_desc = pool.XMLDesc(0)
                    root = ET.fromstring(xml_desc)  # nosec B314 - storage XML is from libvirt API

                    pool_type = root.get("type", "unknown")

                    # Check pool permissions
                    target = root.find("target")
                    if target is not None:
                        perms = target.find("permissions")
                        if perms is not None:
                            mode = perms.findtext("mode", "")
                            owner = perms.findtext("owner", "")
                            group = perms.findtext("group", "")

                            # Check for world-readable
                            if mode and int(mode, 8) & 0o004:
                                self.results.register(f"{name} Pool Perms", "WARN",
                                                      f"World-readable ({mode})")
                            else:
                                self.results.register(f"{name} Pool Perms", "PASS",
                                                      f"Restricted ({mode})")

                except Exception:
                    pass

        except Exception as e:
            self.results.register("Storage Pools", "SKIP", str(e))

    def audit_secrets(self) -> None:
        """Audit libvirt secrets"""
        self.results.section("Secrets Management")

        try:
            secrets = self.conn.listAllSecrets(0)

            if secrets:
                self.results.register("Secrets", "WARN",
                                      f"{len(secrets)} secret(s) (review access)")
            else:
                self.results.register("Secrets", "PASS", "No secrets defined")

        except Exception as e:
            self.results.register("Secrets", "SKIP", str(e))

    def audit_interfaces(self) -> None:
        """Audit network interfaces"""
        self.results.section("Network Interfaces")

        try:
            # Get interface list
            ifaces = self.conn.listAllInterfaces(0)
            self.results.register("Host Interfaces", "PASS", f"{len(ifaces)} interface(s)")

            for iface in ifaces:
                try:
                    name = iface.name()
                    xml_desc = iface.XMLDesc(0)
                    root = ET.fromstring(xml_desc)  # nosec B314 - interface XML is from libvirt API

                    iface_type = root.get("type", "unknown")

                    # Check for bridges
                    if iface_type == "bridge":
                        self.results.register(f"Bridge {name}", "PASS", "Bridged networking")

                except Exception:
                    pass

        except Exception as e:
            self.results.register("Interfaces", "SKIP", str(e))

    def audit_node_devices(self) -> None:
        """Audit passthrough devices"""
        self.results.section("Node Devices (Passthrough)")

        try:
            # Check for passed-through devices
            devices = self.conn.listAllDevices(0)

            pci_devices = 0
            usb_devices = 0

            for dev in devices:
                try:
                    xml_desc = dev.XMLDesc(0)
                    root = ET.fromstring(xml_desc)  # nosec B314 - device XML is from libvirt API

                    cap = root.find("capability")
                    if cap is not None:
                        cap_type = cap.get("type", "")
                        if cap_type == "pci":
                            # Check if device is used for passthrough
                            driver = cap.find("driver")
                            if driver is not None:
                                drv_name = driver.findtext("name", "")
                                if drv_name in ["vfio-pci", "pci-stub"]:
                                    pci_devices += 1
                        elif cap_type == "usb_device":
                            usb_devices += 1

                except Exception:
                    pass

            if pci_devices > 0:
                self.results.register("PCI Passthrough", "WARN",
                                      f"{pci_devices} device(s) (review necessity)")
            else:
                self.results.register("PCI Passthrough", "PASS", "None configured")

        except Exception as e:
            self.results.register("Node Devices", "SKIP", str(e))

    def audit_nwfilters(self) -> None:
        """Audit network filters (firewall)"""
        self.results.section("Network Filters")

        try:
            filters = self.conn.listAllNWFilters(0)
            self.results.register("Network Filters", "PASS", f"{len(filters)} filter(s)")

            # Check for common security filters
            filter_names = [f.name() for f in filters]

            if "clean-traffic" in filter_names:
                self.results.register("Clean Traffic Filter", "PASS", "Available")

            if "allow-arp" in filter_names:
                self.results.register("ARP Filter", "PASS", "Available")

        except Exception as e:
            self.results.register("Network Filters", "SKIP", str(e))

    def audit_snapshots(self) -> None:
        """Audit domain snapshots"""
        self.results.section("Snapshots")

        try:
            # Get all domains and count snapshots
            domains = self.conn.listAllDomains(0)

            total_snapshots = 0
            for dom in domains:
                try:
                    snapshots = dom.listAllSnapshots(0)
                    total_snapshots += len(snapshots)
                except Exception:
                    pass

            if total_snapshots > 0:
                self.results.register("Snapshots", "WARN",
                                      f"{total_snapshots} snapshot(s) (review retention)")
            else:
                self.results.register("Snapshots", "PASS", "None (good for security)")

        except Exception as e:
            self.results.register("Snapshots", "SKIP", str(e))

    def close(self) -> None:
        """Close libvirt connection"""
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass

    def run_full_audit(self) -> None:
        """Run complete security audit"""
        print(f"\033[96m{'='*60}\033[0m")
        print(f"\033[96mKVM/QEMU Security Audit via libvirt API\033[0m")
        if self.host:
            print(f"\033[96mTarget: {self.host}\033[0m")
        else:
            print(f"\033[96mTarget: localhost\033[0m")
        print(f"\033[96mTime: {datetime.now().isoformat()}\033[0m")
        print(f"\033[96m{'='*60}\033[0m")

        try:
            self.audit_hypervisor_info()
            self.audit_security_drivers()
            self.audit_domains()
            self.audit_networks()
            self.audit_storage()
            self.audit_secrets()
            self.audit_interfaces()
            self.audit_node_devices()
            self.audit_nwfilters()
            self.audit_snapshots()
        finally:
            self.close()

        self.results.summary()


def main():
    parser = argparse.ArgumentParser(
        description="KVM/QEMU Security Audit via libvirt API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Local audit (run on KVM host)
    %(prog)s

    # Remote via SSH (uses SSH keys)
    %(prog)s --host kvm.example.com --transport ssh --user root

    # Remote via TLS (certificate auth)
    %(prog)s --host kvm.example.com --transport tls

    # Remote via TCP with SASL auth
    %(prog)s --host kvm.example.com --transport tcp

    # JSON output
    %(prog)s --host kvm.example.com --transport ssh --output results.json

Connection URIs:
    Local:  qemu:///system
    SSH:    qemu+ssh://user@host/system
    TLS:    qemu+tls://host/system
    TCP:    qemu+tcp://host/system
        """
    )
    parser.add_argument("--host", "-H", help="Remote KVM host (omit for local)")
    parser.add_argument("--transport", "-t", choices=["ssh", "tls", "tcp"], default="ssh",
                        help="Transport method (default: ssh)")
    parser.add_argument("--user", "-u", help="SSH username (for ssh transport)")
    parser.add_argument("--driver", "-d", default="qemu", help="Hypervisor driver (default: qemu)")
    parser.add_argument("--mode", "-m", choices=["system", "session"], default="system",
                        help="Connection mode (default: system)")
    parser.add_argument("--output", "-o", help="Output JSON results to file")

    args = parser.parse_args()

    # Run audit
    try:
        audit = KVMAudit(
            host=args.host,
            transport=args.transport,
            user=args.user,
            driver=args.driver,
            mode=args.mode
        )
        audit.run_full_audit()

        # Output JSON if requested
        if args.output:
            with open(args.output, "w") as f:
                f.write(audit.results.to_json())
            print(f"\nResults saved to: {args.output}")

        # Exit with appropriate code
        sys.exit(1 if audit.results.failed > 0 else 0)

    except KeyboardInterrupt:
        print("\nAudit cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
