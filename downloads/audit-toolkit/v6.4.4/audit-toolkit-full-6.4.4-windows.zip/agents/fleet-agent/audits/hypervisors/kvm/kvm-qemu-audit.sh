#!/usr/bin/env bash
# kvm-qemu-audit.sh — KVM/QEMU/libvirt Security Audit
#
# @elevation: root
# @elevation-reason: Requires virsh, libvirtd access, and /etc/libvirt config files
#
# Compliance Mapping:
# - CIS Benchmark: 5.2 (Virtualization Security)
# - NIST SP 800-53: SC-3, SC-39 (Process Isolation)
# - ISO 27001: A.13.1 (Network Security)
# - PCI DSS: 2.2.1, 6.4.1 (Virtualization Security)
# - DISA STIG: V-230221 (Hypervisor Security)
#
# Checks:
# - libvirtd service and configuration
# - QEMU security settings (seccomp, user separation)
# - SELinux/AppArmor profiles
# - Network isolation
# - Storage permissions
# - Polkit access control

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "KVM/QEMU Installation"

# Check if KVM is available
if [[ ! -e /dev/kvm ]]; then
  register_check "KVM device" SKIP "/dev/kvm not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "KVM device" PASS "present"

# Check KVM module loaded
if lsmod | grep -qE "^kvm"; then
  kvm_mod=$(lsmod | grep -E "^kvm" | head -n1 | awk '{print $1}')
  register_check "KVM module" PASS "$kvm_mod loaded"
else
  register_check "KVM module" WARN "not loaded"
fi

# Check for nested virtualization
nested_file=""
if [[ -f /sys/module/kvm_intel/parameters/nested ]]; then
  nested_file="/sys/module/kvm_intel/parameters/nested"
elif [[ -f /sys/module/kvm_amd/parameters/nested ]]; then
  nested_file="/sys/module/kvm_amd/parameters/nested"
fi

if [[ -n "$nested_file" ]]; then
  nested=$(cat "$nested_file" 2>/dev/null || echo "N")
  if [[ "$nested" == "Y" ]] || [[ "$nested" == "1" ]]; then
    register_check "Nested virtualization" WARN "enabled (security risk)"
  else
    register_check "Nested virtualization" PASS "disabled"
  fi
fi

# Check QEMU installed
if command -v qemu-system-x86_64 >/dev/null 2>&1 || command -v qemu-kvm >/dev/null 2>&1; then
  qemu_ver=$(qemu-system-x86_64 --version 2>/dev/null | head -n1 || qemu-kvm --version 2>/dev/null | head -n1 || echo "installed")
  register_check "QEMU installed" PASS "$qemu_ver"
else
  register_check "QEMU installed" WARN "not found"
fi

section "Libvirt Service"

# Check libvirtd
if ! command -v virsh >/dev/null 2>&1; then
  register_check "Libvirt installed" SKIP "virsh not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Libvirt installed" PASS "present"

# Check service status
if is_systemd; then
  if systemctl is-active libvirtd >/dev/null 2>&1; then
    register_check "Libvirtd running" PASS "active"
  else
    register_check "Libvirtd running" WARN "not running"
  fi

  if systemctl is-enabled libvirtd >/dev/null 2>&1; then
    register_check "Libvirtd enabled" PASS "enabled at boot"
  else
    register_check "Libvirtd enabled" WARN "not enabled"
  fi

  # Check virtlogd (log daemon)
  if systemctl is-active virtlogd >/dev/null 2>&1; then
    register_check "Virtlogd running" PASS "active"
  else
    register_check "Virtlogd running" WARN "not running"
  fi
else
  if pgrep -x libvirtd >/dev/null 2>&1; then
    register_check "Libvirtd running" PASS "active"
  else
    register_check "Libvirtd running" WARN "not running"
  fi
fi

section "Libvirt Configuration"

libvirtd_conf="/etc/libvirt/libvirtd.conf"
if [[ -f "$libvirtd_conf" ]]; then
  register_check "Libvirtd.conf" PASS "exists"

  # Check file permissions
  perms=$(stat -c "%a" "$libvirtd_conf" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "600" ]] || [[ "$perms" == "644" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi

  # Check unix socket permissions
  unix_sock_group=$(grep -E "^unix_sock_group" "$libvirtd_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  if [[ -n "$unix_sock_group" ]]; then
    register_check "Unix socket group" PASS "$unix_sock_group"
  else
    register_check "Unix socket group" WARN "using default"
  fi

  # Check socket permissions
  unix_sock_ro_perms=$(grep -E "^unix_sock_ro_perms" "$libvirtd_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  unix_sock_rw_perms=$(grep -E "^unix_sock_rw_perms" "$libvirtd_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")

  if [[ "$unix_sock_rw_perms" == "0770" ]] || [[ "$unix_sock_rw_perms" == "0700" ]]; then
    register_check "RW socket perms" PASS "$unix_sock_rw_perms"
  else
    register_check "RW socket perms" WARN "${unix_sock_rw_perms:-default}"
  fi

  # Check read-only socket permissions
  if [[ "$unix_sock_ro_perms" == "0777" ]] || [[ "$unix_sock_ro_perms" == "0755" ]]; then
    register_check "RO socket perms" PASS "$unix_sock_ro_perms"
  elif [[ -n "$unix_sock_ro_perms" ]]; then
    register_check "RO socket perms" WARN "$unix_sock_ro_perms"
  fi

  # Check auth settings
  auth_unix_ro=$(grep -E "^auth_unix_ro" "$libvirtd_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  auth_unix_rw=$(grep -E "^auth_unix_rw" "$libvirtd_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")

  if [[ "$auth_unix_rw" == "polkit" ]] || [[ "$auth_unix_rw" == "sasl" ]]; then
    register_check "RW auth method" PASS "$auth_unix_rw"
  else
    register_check "RW auth method" WARN "${auth_unix_rw:-none}"
  fi

  # Check read-only auth method
  if [[ "$auth_unix_ro" == "none" ]] || [[ "$auth_unix_ro" == "polkit" ]]; then
    register_check "RO auth method" PASS "${auth_unix_ro:-none}"
  elif [[ -n "$auth_unix_ro" ]]; then
    register_check "RO auth method" WARN "$auth_unix_ro"
  fi

  # Check TLS settings for remote access
  listen_tls=$(grep -E "^listen_tls" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' || echo "")
  if [[ "$listen_tls" == "1" ]]; then
    register_check "TLS listening" PASS "enabled"

    # Check certificates
    if [[ -f "/etc/pki/libvirt/servercert.pem" ]]; then
      register_check "TLS certificate" PASS "present"
    else
      register_check "TLS certificate" WARN "not found"
    fi
  fi

  # Check TCP (insecure) disabled
  listen_tcp=$(grep -E "^listen_tcp" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' || echo "0")
  if [[ "$listen_tcp" == "1" ]]; then
    register_check "TCP listening" FAIL "enabled (insecure)"
  else
    register_check "TCP listening" PASS "disabled"
  fi
else
  register_check "Libvirtd.conf" WARN "not found"
fi

section "QEMU Security Configuration"

qemu_conf="/etc/libvirt/qemu.conf"
if [[ -f "$qemu_conf" ]]; then
  register_check "QEMU config" PASS "$qemu_conf"

  # Check user/group separation
  qemu_user=$(grep -E "^user\s*=" "$qemu_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  qemu_group=$(grep -E "^group\s*=" "$qemu_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")

  if [[ -n "$qemu_user" ]] && [[ "$qemu_user" != "root" ]]; then
    register_check "QEMU user" PASS "$qemu_user (not root)"
  else
    register_check "QEMU user" WARN "${qemu_user:-root} (runs as root)"
  fi
  if [[ -n "$qemu_group" ]] && [[ "$qemu_group" != "root" ]]; then
    register_check "QEMU group" PASS "$qemu_group (not root)"
  elif [[ -n "$qemu_group" ]]; then
    register_check "QEMU group" WARN "$qemu_group (runs as root group)"
  fi
  # Check seccomp sandbox
  seccomp=$(grep -E "^seccomp_sandbox" "$qemu_conf" 2>/dev/null | awk '{print $3}' || echo "")
  if [[ "$seccomp" == "1" ]]; then
    register_check "Seccomp sandbox" PASS "enabled"
  elif [[ "$seccomp" == "0" ]]; then
    register_check "Seccomp sandbox" FAIL "disabled"
  else
    register_check "Seccomp sandbox" WARN "check setting (default: on)"
  fi

  # Check security driver
  security_driver=$(grep -E "^security_driver" "$qemu_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  if [[ -n "$security_driver" ]]; then
    register_check "Security driver" PASS "$security_driver"
  else
    register_check "Security driver" WARN "using default"
  fi

  # Check memory backing
  memory_backing_dir=$(grep -E "^memory_backing_dir" "$qemu_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  if [[ -n "$memory_backing_dir" ]]; then
    register_check "Memory backing dir" PASS "$memory_backing_dir"
  fi

  # Check VNC/SPICE security
  vnc_listen=$(grep -E "^vnc_listen" "$qemu_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  if [[ "$vnc_listen" == "127.0.0.1" ]] || [[ "$vnc_listen" == "::1" ]]; then
    register_check "VNC listen address" PASS "$vnc_listen (localhost only)"
  elif [[ -n "$vnc_listen" ]]; then
    register_check "VNC listen address" WARN "$vnc_listen"
  fi

  vnc_tls=$(grep -E "^vnc_tls" "$qemu_conf" 2>/dev/null | awk '{print $3}' || echo "")
  if [[ "$vnc_tls" == "1" ]]; then
    register_check "VNC TLS" PASS "enabled"
  else
    register_check "VNC TLS" WARN "not enabled"
  fi

  spice_tls=$(grep -E "^spice_tls" "$qemu_conf" 2>/dev/null | awk '{print $3}' || echo "")
  if [[ "$spice_tls" == "1" ]]; then
    register_check "SPICE TLS" PASS "enabled"
  fi
else
  register_check "QEMU config" WARN "not found"
fi

section "SELinux/AppArmor Profiles"

# Check SELinux sVirt
if command -v getenforce >/dev/null 2>&1; then
  selinux_status=$(getenforce 2>/dev/null || echo "Disabled")
  if [[ "$selinux_status" == "Enforcing" ]]; then
    register_check "SELinux status" PASS "enforcing"

    # Check sVirt
    if semodule -l 2>/dev/null | grep -q "virt"; then
      register_check "SELinux sVirt module" PASS "loaded"
    else
      register_check "SELinux sVirt module" WARN "not found"
    fi

    # Check VM context
    if ps auxZ 2>/dev/null | grep qemu | grep -q "svirt_t"; then
      register_check "VMs using sVirt" PASS "svirt_t context"
    fi
  else
    register_check "SELinux status" WARN "$selinux_status"
  fi
fi

# Check AppArmor
if command -v aa-status >/dev/null 2>&1; then
  aa_profiles=$(aa-status 2>/dev/null | grep -c "libvirt" || echo "0")
  if [[ "$aa_profiles" -gt 0 ]]; then
    register_check "AppArmor libvirt" PASS "$aa_profiles profiles"

    # Check QEMU profile
    if aa-status 2>/dev/null | grep -q "libvirt-qemu"; then
      register_check "libvirt-qemu profile" PASS "loaded"
    fi
  else
    register_check "AppArmor libvirt" WARN "no profiles loaded"
  fi
fi

section "Network Configuration"

# Check default network
if virsh net-list --all 2>/dev/null | grep -q "default"; then
  default_active=$(virsh net-list 2>/dev/null | grep "default" | awk '{print $2}')
  if [[ "$default_active" == "active" ]]; then
    register_check "Default network" PASS "active"

    # Check NAT/isolation mode
    net_xml=$(virsh net-dumpxml default 2>/dev/null || echo "")
    if echo "$net_xml" | grep -q "nat"; then
      register_check "Network mode" PASS "NAT"
    elif echo "$net_xml" | grep -q "isolated"; then
      register_check "Network mode" PASS "isolated"
    fi
  else
    register_check "Default network" WARN "inactive"
  fi
fi

# Count networks
net_count=$(virsh net-list --all 2>/dev/null | grep -c "active\|inactive" || echo "0")
register_check "Defined networks" PASS "$net_count networks"

# Check for bridged interfaces
bridge_count=$(ip link show type bridge 2>/dev/null | grep -c "state" || echo "0")
if [[ "$bridge_count" -gt 0 ]]; then
  register_check "Bridge interfaces" PASS "$bridge_count bridges"
fi

section "Storage Security"

# Check storage pools
pool_count=$(virsh pool-list --all 2>/dev/null | grep -c "active\|inactive" || echo "0")
register_check "Storage pools" PASS "$pool_count pools"

# Check default pool permissions
default_pool=$(virsh pool-dumpxml default 2>/dev/null || echo "")
if [[ -n "$default_pool" ]]; then
  pool_path=$(echo "$default_pool" | grep -oP '(?<=<path>)[^<]+' || echo "")
  if [[ -d "$pool_path" ]]; then
    pool_perms=$(stat -c "%a" "$pool_path" 2>/dev/null || echo "unknown")
    pool_owner=$(stat -c "%U:%G" "$pool_path" 2>/dev/null || echo "unknown")

    if [[ "$pool_perms" == "711" ]] || [[ "$pool_perms" == "755" ]]; then
      register_check "Pool dir perms" PASS "$pool_perms $pool_owner"
    else
      register_check "Pool dir perms" WARN "$pool_perms"
    fi
  fi
fi

# Check image directory
images_dir="/var/lib/libvirt/images"
if [[ -d "$images_dir" ]]; then
  img_perms=$(stat -c "%a" "$images_dir" 2>/dev/null || echo "unknown")
  if [[ "$img_perms" == "711" ]] || [[ "$img_perms" == "751" ]]; then
    register_check "Images dir perms" PASS "$img_perms"
  else
    register_check "Images dir perms" WARN "$img_perms"
  fi
fi

section "Socket & Access Control"

# Check libvirt socket
libvirt_sock="/var/run/libvirt/libvirt-sock"
if [[ -S "$libvirt_sock" ]]; then
  sock_perms=$(stat -c "%a" "$libvirt_sock" 2>/dev/null || echo "unknown")
  sock_owner=$(stat -c "%U:%G" "$libvirt_sock" 2>/dev/null || echo "unknown")
  register_check "Libvirt socket" PASS "$sock_perms $sock_owner"
fi

# Check polkit rules
polkit_rules="/etc/polkit-1/rules.d"
if [[ -d "$polkit_rules" ]]; then
  libvirt_rules=$(find "$polkit_rules" -name "*libvirt*" -type f 2>/dev/null | wc -l)
  if [[ "$libvirt_rules" -gt 0 ]]; then
    register_check "Polkit rules" PASS "$libvirt_rules libvirt rules"
  else
    register_check "Polkit rules" WARN "no custom rules"
  fi
fi

# Check libvirt group membership
libvirt_group_members=$(getent group libvirt 2>/dev/null | cut -d: -f4 || echo "")
if [[ -n "$libvirt_group_members" ]]; then
  member_count=$(echo "$libvirt_group_members" | tr ',' '\n' | wc -l)
  register_check "Libvirt group members" PASS "$member_count users"
fi

section "VM Security Features"

# Count running VMs
running_vms=$(virsh list 2>/dev/null | grep -c "running" || echo "0")
register_check "Running VMs" PASS "$running_vms VMs"

# Check for VMs with vTPM
vtpm_vms=0
for vm in $(virsh list --name 2>/dev/null); do
  if virsh dumpxml "$vm" 2>/dev/null | grep -q "<tpm"; then
    ((vtpm_vms++)) || true
  fi
done
if [[ "$vtpm_vms" -gt 0 ]]; then
  register_check "VMs with vTPM" PASS "$vtpm_vms VMs"
fi

# Check for secure boot capable VMs
secboot_vms=0
for vm in $(virsh list --name 2>/dev/null); do
  if virsh dumpxml "$vm" 2>/dev/null | grep -q "secure='yes'"; then
    ((secboot_vms++)) || true
  fi
done
if [[ "$secboot_vms" -gt 0 ]]; then
  register_check "Secure Boot VMs" PASS "$secboot_vms VMs"
fi

# Check for memory encryption (AMD SEV)
if [[ -f /sys/module/kvm_amd/parameters/sev ]]; then
  sev_enabled=$(cat /sys/module/kvm_amd/parameters/sev 2>/dev/null || echo "N")
  if [[ "$sev_enabled" == "Y" ]] || [[ "$sev_enabled" == "1" ]]; then
    register_check "AMD SEV" PASS "enabled"
  else
    register_check "AMD SEV" WARN "available but disabled"
  fi
fi

section "Logging & Auditing"

# Check libvirt logging
log_level=$(grep -E "^log_level" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' || echo "")
if [[ -n "$log_level" ]] && [[ "$log_level" -le 3 ]]; then
  register_check "Log level" PASS "level $log_level"
else
  register_check "Log level" WARN "default or verbose"
fi

# Check audit logging
audit_level=$(grep -E "^audit_level" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' || echo "")
if [[ "$audit_level" == "1" ]] || [[ "$audit_level" == "2" ]]; then
  register_check "Audit logging" PASS "level $audit_level"
else
  register_check "Audit logging" WARN "not configured"
fi

# Check log file
log_file="/var/log/libvirt/libvirtd.log"
if [[ -f "$log_file" ]]; then
  log_perms=$(stat -c "%a" "$log_file" 2>/dev/null || echo "unknown")
  register_check "Libvirt log file" PASS "$log_perms"
fi

section "Advanced Security Controls"

# NIST SP 800-125: cgroup isolation enforcement
if [[ -f /sys/fs/cgroup/cgroup.controllers ]]; then
  # cgroup v2

  register_check "Cgroup version" PASS "cgroup v2 (unified)"

  # Check memory controller
  if grep -q "memory" /sys/fs/cgroup/cgroup.controllers 2>/dev/null; then
    register_check "Memory cgroup" PASS "enabled"
  else
    register_check "Memory cgroup" WARN "not enabled"
  fi

  # Check CPU controller
  if grep -q "cpu" /sys/fs/cgroup/cgroup.controllers 2>/dev/null; then
    register_check "CPU cgroup" PASS "enabled"
  else
    register_check "CPU cgroup" WARN "not enabled"
  fi
else
  # cgroup v1
  if [[ -d /sys/fs/cgroup/memory ]] && [[ -d /sys/fs/cgroup/cpu ]]; then
    register_check "Cgroup v1 isolation" PASS "memory and CPU controllers"
  else
    register_check "Cgroup isolation" WARN "partial cgroup support"
  fi
fi

# Check libvirt cgroup device ACL
if grep -qE "^cgroup_device_acl" "$libvirtd_conf" 2>/dev/null; then
  register_check "Cgroup device ACL" PASS "configured"
else
  register_check "Cgroup device ACL" WARN "using defaults"
fi

# Live migration TLS enforcement
migration_tls=$(grep -E "^migrate_tls_x509_verify" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' || echo "")
if [[ "$migration_tls" == "1" ]]; then
  register_check "Migration TLS verify" PASS "enabled"
else
  register_check "Migration TLS verify" WARN "not enforced"
fi

# Check migration TLS certificate
migrate_tls_dir=$(grep -E "^migrate_tls_x509_cert_dir" "$libvirtd_conf" 2>/dev/null | awk '{print $3}' | tr -d '"' || echo "/etc/pki/libvirt-migrate")
if [[ -d "$migrate_tls_dir" ]] && [[ -f "$migrate_tls_dir/server-cert.pem" ]]; then
  register_check "Migration TLS certs" PASS "configured"
else
  register_check "Migration TLS certs" WARN "not configured"
fi

# CPU pinning and NUMA security
if command -v numactl >/dev/null 2>&1; then
  numa_nodes=$(numactl --hardware 2>/dev/null | grep -c "node [0-9]" || echo "0")
  if [[ "$numa_nodes" -gt 1 ]]; then
    register_check "NUMA nodes" PASS "$numa_nodes nodes available"
  elif [[ "$numa_nodes" -eq 1 ]]; then
    register_check "NUMA nodes" PASS "single node system"
  fi
fi

# Check for CPU isolation via kernel cmdline
if grep -qE "isolcpus|nohz_full" /proc/cmdline 2>/dev/null; then
  register_check "CPU isolation" PASS "kernel cmdline configured"
fi

# Intel TME (Total Memory Encryption)
if [[ -f /sys/module/kvm_intel/parameters/tdx ]]; then
  tdx_enabled=$(cat /sys/module/kvm_intel/parameters/tdx 2>/dev/null || echo "N")
  if [[ "$tdx_enabled" == "Y" ]] || [[ "$tdx_enabled" == "1" ]]; then
    register_check "Intel TDX" PASS "enabled"
  else
    register_check "Intel TDX" WARN "available but disabled"
  fi
fi

# Check for memory encryption via kernel
if grep -qi "mem_encrypt=on\|amd_iommu=on" /proc/cmdline 2>/dev/null; then
  register_check "Memory encryption" PASS "kernel enabled"
fi

# QEMU command injection prevention - check for seccomp
if grep -qE "^seccomp_sandbox" /etc/libvirt/qemu.conf 2>/dev/null; then
  seccomp_mode=$(grep -E "^seccomp_sandbox" /etc/libvirt/qemu.conf 2>/dev/null | awk '{print $3}' | tr -d '"')
  if [[ "$seccomp_mode" == "1" ]]; then
    register_check "QEMU seccomp sandbox" PASS "enabled"
  else
    register_check "QEMU seccomp sandbox" WARN "$seccomp_mode"
  fi
fi

# Check for dangerous QEMU options disabled
if grep -qE "^vnc_auto_unix_socket" /etc/libvirt/qemu.conf 2>/dev/null; then
  vnc_unix=$(grep -E "^vnc_auto_unix_socket" /etc/libvirt/qemu.conf 2>/dev/null | awk '{print $3}')
  if [[ "$vnc_unix" == "1" ]]; then
    register_check "VNC Unix sockets" PASS "using unix sockets"
  fi
fi

# Check for spice TLS
if grep -qE "^spice_tls" /etc/libvirt/qemu.conf 2>/dev/null; then
  spice_tls=$(grep -E "^spice_tls" /etc/libvirt/qemu.conf 2>/dev/null | awk '{print $3}')
  if [[ "$spice_tls" == "1" ]]; then
    register_check "SPICE TLS" PASS "enabled"
  else
    register_check "SPICE TLS" WARN "not enforced"
  fi
else
  register_check "SPICE TLS" WARN "not configured"
fi

# Verify huge pages configuration (if used)
if grep -q "hugetlb" /proc/mounts 2>/dev/null; then
  hugepages_total=$(grep -i "HugePages_Total" /proc/meminfo 2>/dev/null | awk '{print $2}' || echo "0")
  if [[ "$hugepages_total" -gt 0 ]]; then
    register_check "Huge pages" PASS "$hugepages_total allocated"
  fi
fi

print_summary
exit "$EXIT_CODE"
