# Nutanix AHV Security Audits

Security audits for Nutanix Acropolis Hypervisor (AHV).

## Execution Methods

1. **SSH to CVM** - Execute on Controller VM
2. **SSH to AHV Host** - Direct host access
3. **Prism API** - REST API via Prism Central/Element
4. **acli/ncli** - Nutanix command-line interfaces

## Planned Audits

### nutanix-baseline-audit.sh
Core Nutanix/AHV hardening:
- [ ] AOS version
- [ ] AHV version
- [ ] CVM security configuration
- [ ] SSH hardening (CVM and AHV)
- [ ] Password complexity
- [ ] Session timeout settings
- [ ] NTP configuration
- [ ] Syslog forwarding (Prism)
- [ ] SNMP configuration

### nutanix-cluster-audit.sh
Cluster security:
- [ ] Cluster encryption (data-at-rest)
- [ ] Software encryption status
- [ ] External KMS integration
- [ ] Cluster lockdown mode
- [ ] Node authentication
- [ ] Rebuild capacity policy

### nutanix-auth-audit.sh
Authentication and authorization:
- [ ] Local vs directory (AD/LDAP) users
- [ ] Role-based access control (RBAC)
- [ ] SSO configuration
- [ ] API key management
- [ ] Prism Central permissions
- [ ] Multi-cluster management security

### nutanix-network-audit.sh
Network configuration:
- [ ] AHV network segmentation
- [ ] Acropolis Flow (microsegmentation)
- [ ] VLAN configuration
- [ ] Virtual switch security
- [ ] CVM network isolation
- [ ] IPMI/iDRAC security

### nutanix-storage-audit.sh
Storage security:
- [ ] Storage container encryption
- [ ] Deduplication security
- [ ] Self-encrypting drives (SED)
- [ ] Snapshot retention
- [ ] Protection domain configuration
- [ ] Metro/async DR encryption

### nutanix-vm-audit.sh
Virtual machine security:
- [ ] VM categories and policies
- [ ] Guest tools installed
- [ ] Resource limits
- [ ] NGT (Nutanix Guest Tools) version
- [ ] VM backup (Prism/third-party)

## Key Commands Reference

```bash
# CVM Commands (ncli)
ncli cluster info
ncli cluster get-params
ncli user list
ncli authconfig list
ncli protection-domain list

# AHV Commands (acli)
acli vm.list
acli net.list
acli host.list

# REST API Examples
# GET https://<prism>:9440/PrismGateway/services/rest/v2.0/cluster/
# GET https://<prism>:9440/api/nutanix/v3/users/list

# Check versions
cat /etc/nutanix/release_version
cat /etc/nutanix/svm-version
hostnamectl (on AHV host)

# Security status
ncli cluster get-hypervisor-security-config
```

## Security Features Reference

| Feature | Description | Check |
|---------|-------------|-------|
| Data-at-Rest Encryption | Container-level encryption | `ncli container list` |
| Cluster Lockdown | Restrict SSH access | `ncli cluster get-cluster-lockdown-status` |
| Flow Microsegmentation | Network security policies | Prism Central only |
| SCMA | Security Configuration Management | Nutanix STIG automation |

## Nutanix STIG/Compliance

- Nutanix Security Configuration Management Automation (SCMA)
- DISA STIG for Nutanix AOS
- CIS Nutanix Benchmark (if available)

## Implementation Notes

- CVM runs on CentOS - standard Linux audits can supplement
- AHV is KVM-based - some KVM patterns apply
- Prism Element = single cluster management
- Prism Central = multi-cluster management
- Most security APIs require Prism Central

---
**Document Version:** 1.0  
**Created:** March 2026
