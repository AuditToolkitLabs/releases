#!/usr/bin/env python3
"""
Nutanix Prism Security Audit via REST API

Cross-platform Nutanix audit using Prism v2/v3 REST APIs.
Works with both Prism Element and Prism Central.
Runs on Windows, Linux, or macOS with Python 3.8+.

Compliance Mapping:
- Nutanix Security Technical Implementation Guide (STIG)
- NIST SP 800-53: AC-2, AC-6, AU-2, SC-8
- CIS Benchmark: Hyperconverged Infrastructure
- PCI DSS: 8.1, 10.1

Usage:
    python nutanix-api-audit.py --server prism.example.com --username admin
    python nutanix-api-audit.py --server prism.example.com --username admin --insecure

Requirements:
    pip install requests urllib3
"""

import argparse
import json
import sys
import urllib3
from getpass import getpass
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    print("ERROR: requests module required. Install with: pip install requests")
    sys.exit(1)


class AuditResults:
    """Track audit results"""
    
    def __init__(self):
        self.checks = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0
    
    def register(self, name: str, status: str, message: str = ""):
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"
        
        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))
        
        self.checks.append({"name": name, "status": status, "message": message})
        
        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1
    
    def summary(self):
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")
    
    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "checks": self.checks,
            "summary": {
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class NutanixAudit:
    """Nutanix Prism REST API Audit Client"""
    
    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = True, port: int = 9440):
        self.server = server
        self.base_url = f"https://{server}:{port}"
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session.auth = (username, password)
        self.session.headers["Content-Type"] = "application/json"
        self.results = AuditResults()
        self.is_pc = False  # Prism Central flag
        
        if not verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        self._verify_connection()
    
    def _verify_connection(self):
        """Verify connection and detect Prism type"""
        try:
            # Try v2 API first (works on both PE and PC)
            response = self.session.get(
                f"{self.base_url}/api/nutanix/v2.0/cluster",
                timeout=30
            )
            if response.status_code == 200:
                cluster_info = response.json()
                cluster_name = cluster_info.get("name", "unknown")
                self.results.register("Prism Connection", "PASS", cluster_name)
                
                # Check version
                version = cluster_info.get("version", "unknown")
                self.results.register("Cluster Version", "PASS", version)
                return
            elif response.status_code == 401:
                self.results.register("Prism Connection", "FAIL", "Authentication failed")
                sys.exit(1)
        except requests.exceptions.SSLError:
            self.results.register("Prism Connection", "FAIL", "SSL error (try --insecure)")
            sys.exit(1)
        except requests.exceptions.RequestException as e:
            self.results.register("Prism Connection", "FAIL", str(e))
            sys.exit(1)
    
    def _get_v2(self, endpoint: str) -> Optional[Dict]:
        """Make GET request to v2 API"""
        try:
            response = self.session.get(
                f"{self.base_url}/api/nutanix/v2.0/{endpoint}",
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception:
            return None
    
    def _post_v3(self, endpoint: str, data: Dict) -> Optional[Dict]:
        """Make POST request to v3 API (list operations)"""
        try:
            response = self.session.post(
                f"{self.base_url}/api/nutanix/v3/{endpoint}",
                json=data,
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception:
            return None
    
    def section(self, title: str):
        """Print section header"""
        print(f"\n=== {title} ===\n")
    
    def audit_cluster(self):
        """Audit cluster configuration"""
        self.section("Cluster Security")
        
        cluster = self._get_v2("cluster")
        if not cluster:
            self.results.register("Cluster Info", "SKIP", "Could not retrieve")
            return
        
        # Check cluster name
        cluster_name = cluster.get("name", "unknown")
        cluster_uuid = cluster.get("uuid", "")[:8]
        self.results.register("Cluster Name", "PASS", f"{cluster_name} ({cluster_uuid}...)")
        
        # Check number of nodes
        num_nodes = cluster.get("num_nodes", 0)
        if num_nodes >= 3:
            self.results.register("Cluster Nodes", "PASS", f"{num_nodes} nodes (HA supported)")
        elif num_nodes > 0:
            self.results.register("Cluster Nodes", "WARN", f"{num_nodes} node(s) (limited HA)")
        
        # Check cluster redundancy
        rf = cluster.get("cluster_redundancy_state", {}).get("current_redundancy_factor", 0)
        if rf >= 2:
            self.results.register("Redundancy Factor", "PASS", f"RF{rf}")
        else:
            self.results.register("Redundancy Factor", "WARN", f"RF{rf} (recommend RF2+)")
        
        # Check if encryption is enabled
        encryption = cluster.get("cluster_encryption_status", {})
        if encryption.get("is_encryption_enabled"):
            self.results.register("Data-at-Rest Encryption", "PASS", "Enabled")
        else:
            self.results.register("Data-at-Rest Encryption", "WARN", "Not enabled")
    
    def audit_hosts(self):
        """Audit hypervisor hosts"""
        self.section("Host Security")
        
        hosts = self._get_v2("hosts")
        if not hosts:
            self.results.register("Hosts", "SKIP", "Could not retrieve")
            return
        
        host_list = hosts.get("entities", [])
        self.results.register("Hosts", "PASS", f"{len(host_list)} host(s)")
        
        for host in host_list:
            host_name = host.get("name", host.get("uuid", "unknown")[:8])
            
            # Check host state
            state = host.get("state", "unknown")
            if state == "NORMAL":
                self.results.register(f"{host_name} State", "PASS", "Normal")
            else:
                self.results.register(f"{host_name} State", "WARN", state)
            
            # Check hypervisor type
            hypervisor = host.get("hypervisor_type", "unknown")
            self.results.register(f"{host_name} Hypervisor", "PASS", hypervisor)
            
            # Check maintenance mode
            in_maintenance = host.get("host_in_maintenance_mode", False)
            if in_maintenance:
                self.results.register(f"{host_name} Maintenance", "WARN", "In maintenance mode")
    
    def audit_vms(self):
        """Audit virtual machines"""
        self.section("Virtual Machine Security")
        
        vms = self._get_v2("vms")
        if not vms:
            self.results.register("Virtual Machines", "SKIP", "Could not retrieve")
            return
        
        vm_list = vms.get("entities", [])
        self.results.register("Virtual Machines", "PASS", f"{len(vm_list)} VM(s)")
        
        # Count VMs by power state
        powered_on = len([vm for vm in vm_list if vm.get("power_state") == "on"])
        self.results.register("Powered On VMs", "PASS", f"{powered_on} running")
        
        # Check for VMs without NGT (Nutanix Guest Tools)
        no_ngt = len([vm for vm in vm_list if not vm.get("nutanix_guest_tools", {}).get("enabled")])
        if no_ngt == 0:
            self.results.register("NGT Coverage", "PASS", "Installed on all VMs")
        else:
            self.results.register("NGT Coverage", "WARN", f"{no_ngt} VM(s) without NGT")
    
    def audit_storage(self):
        """Audit storage containers"""
        self.section("Storage Security")
        
        containers = self._get_v2("storage_containers")
        if not containers:
            self.results.register("Storage Containers", "SKIP", "Could not retrieve")
            return
        
        container_list = containers.get("entities", [])
        self.results.register("Storage Containers", "PASS", f"{len(container_list)} container(s)")
        
        for container in container_list:
            container_name = container.get("name", "unknown")
            
            # Check replication factor
            rf = container.get("replication_factor", 0)
            if rf >= 2:
                self.results.register(f"{container_name} RF", "PASS", f"RF{rf}")
            else:
                self.results.register(f"{container_name} RF", "WARN", f"RF{rf}")
            
            # Check compression
            compression = container.get("compression_enabled", False)
            if compression:
                self.results.register(f"{container_name} Compression", "PASS", "Enabled")
            
            # Check erasure coding
            ec = container.get("erasure_code", "")
            if ec:
                self.results.register(f"{container_name} Erasure Coding", "PASS", "Enabled")
    
    def audit_networks(self):
        """Audit network configuration"""
        self.section("Network Security")
        
        networks = self._get_v2("networks")
        if not networks:
            self.results.register("Networks", "SKIP", "Could not retrieve")
            return
        
        network_list = networks.get("entities", [])
        self.results.register("Networks", "PASS", f"{len(network_list)} network(s)")
        
        # Check for VLANs
        vlan_count = len([n for n in network_list if n.get("vlan_id")])
        if vlan_count > 0:
            self.results.register("VLANs", "PASS", f"{vlan_count} VLAN(s)")
        else:
            self.results.register("VLANs", "WARN", "No VLANs configured")
    
    def audit_users(self):
        """Audit user accounts"""
        self.section("User Management")
        
        users = self._get_v2("users")
        if not users:
            self.results.register("Users", "SKIP", "Could not retrieve")
            return
        
        user_list = users.get("entities", [])
        self.results.register("Users", "PASS", f"{len(user_list)} user(s)")
        
        # Count admins
        admin_count = len([u for u in user_list if "CLUSTER_ADMIN" in u.get("roles", [])])
        if admin_count <= 3:
            self.results.register("Cluster Admins", "PASS", f"{admin_count} admin(s)")
        else:
            self.results.register("Cluster Admins", "WARN", f"{admin_count} admins (review necessity)")
    
    def audit_auth_config(self):
        """Audit authentication configuration"""
        self.section("Authentication Security")
        
        auth = self._get_v2("authconfig")
        if not auth:
            self.results.register("Auth Config", "SKIP", "Could not retrieve")
            return
        
        # Check directory services
        directories = auth.get("directory_list", [])
        if directories:
            for directory in directories:
                dir_type = directory.get("directory_type", "unknown")
                dir_name = directory.get("name", "unknown")
                self.results.register(f"Directory {dir_name}", "PASS", dir_type)
                
                # Check connection type (SSL)
                conn_type = directory.get("connection_type", "")
                if "LDAPS" in conn_type or "SSL" in conn_type:
                    self.results.register(f"{dir_name} Encryption", "PASS", "LDAPS/SSL")
                else:
                    self.results.register(f"{dir_name} Encryption", "WARN", "Plain LDAP")
        else:
            self.results.register("Directory Services", "WARN", "Local auth only")
        
        # Check for SAML
        saml = auth.get("saml_idp_list", [])
        if saml:
            self.results.register("SAML/SSO", "PASS", f"{len(saml)} IdP(s)")
        
        # Check for CAC
        cac = auth.get("cac_config", {})
        if cac.get("enabled"):
            self.results.register("CAC/Smart Card", "PASS", "Enabled")
    
    def audit_protection_domains(self):
        """Audit data protection"""
        self.section("Data Protection")
        
        pds = self._get_v2("protection_domains")
        if not pds:
            self.results.register("Protection Domains", "SKIP", "Could not retrieve")
            return
        
        pd_list = pds.get("entities", [])
        if pd_list:
            self.results.register("Protection Domains", "PASS", f"{len(pd_list)} PD(s)")
            
            for pd in pd_list:
                pd_name = pd.get("name", "unknown")
                active = pd.get("active", False)
                
                if active:
                    self.results.register(f"PD {pd_name}", "PASS", "Active")
                else:
                    self.results.register(f"PD {pd_name}", "WARN", "Inactive")
        else:
            self.results.register("Protection Domains", "WARN", "None configured")
        
        # Check remote sites
        remote = self._get_v2("remote_sites")
        if remote:
            remote_list = remote.get("entities", [])
            if remote_list:
                self.results.register("Remote Sites (DR)", "PASS", f"{len(remote_list)} site(s)")
            else:
                self.results.register("Remote Sites (DR)", "WARN", "None configured")
    
    def audit_alerts(self):
        """Check critical alerts"""
        self.section("Alerts and Health")
        
        alerts = self._get_v2("alerts?resolved=false&severity=CRITICAL")
        if alerts:
            alert_list = alerts.get("entities", [])
            if len(alert_list) == 0:
                self.results.register("Critical Alerts", "PASS", "None")
            else:
                self.results.register("Critical Alerts", "FAIL", f"{len(alert_list)} critical alert(s)")
        else:
            self.results.register("Alerts", "SKIP", "Could not retrieve")
        
        # Check cluster health
        health = self._get_v2("cluster/health_check")
        if health:
            health_summary = health.get("health_summary", {})
            warning_count = health_summary.get("warning", 0)
            critical_count = health_summary.get("critical", 0)
            
            if critical_count == 0 and warning_count == 0:
                self.results.register("Cluster Health", "PASS", "All checks passed")
            elif critical_count == 0:
                self.results.register("Cluster Health", "WARN", f"{warning_count} warning(s)")
            else:
                self.results.register("Cluster Health", "FAIL", f"{critical_count} critical, {warning_count} warning(s)")
    
    def audit_ntp(self):
        """Audit NTP configuration"""
        self.section("Time Synchronization")
        
        cluster = self._get_v2("cluster")
        if cluster:
            ntp_servers = cluster.get("ntp_servers", [])
            if ntp_servers:
                self.results.register("NTP Servers", "PASS", ", ".join(ntp_servers))
            else:
                self.results.register("NTP Servers", "WARN", "None configured")
        else:
            self.results.register("NTP", "SKIP", "Could not retrieve")
    
    def audit_syslog(self):
        """Audit syslog configuration"""
        self.section("Logging Configuration")
        
        cluster = self._get_v2("cluster")
        if cluster:
            syslog_servers = cluster.get("syslog_servers", [])
            if syslog_servers:
                self.results.register("Syslog Servers", "PASS", f"{len(syslog_servers)} server(s)")
            else:
                self.results.register("Syslog Servers", "WARN", "None configured")
        else:
            self.results.register("Syslog", "SKIP", "Could not retrieve")
    
    def audit_ssl(self):
        """Audit SSL/TLS configuration"""
        self.section("SSL/TLS Security")
        
        ssl_cert = self._get_v2("cluster/ssl_certificate")
        if ssl_cert:
            # Check certificate validity
            self.results.register("SSL Certificate", "PASS", "Configured")
            
            # Check if custom cert
            is_custom = ssl_cert.get("is_custom_certificate", False)
            if is_custom:
                self.results.register("Certificate Type", "PASS", "Custom CA-signed")
            else:
                self.results.register("Certificate Type", "WARN", "Self-signed (consider CA cert)")
        else:
            self.results.register("SSL Certificate", "SKIP", "Could not retrieve")
    
    def run_full_audit(self) -> AuditResults:
        """Run complete audit"""
        self.audit_cluster()
        self.audit_hosts()
        self.audit_vms()
        self.audit_storage()
        self.audit_networks()
        self.audit_users()
        self.audit_auth_config()
        self.audit_protection_domains()
        self.audit_ntp()
        self.audit_syslog()
        self.audit_ssl()
        self.audit_alerts()
        
        self.results.summary()
        return self.results


def main():
    parser = argparse.ArgumentParser(
        description="Nutanix Prism Security Audit via REST API"
    )
    parser.add_argument("--server", "-s", required=True, help="Prism server hostname or IP")
    parser.add_argument("--username", "-u", required=True, help="Username")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--port", type=int, default=9440, help="API port (default: 9440)")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--json", "-j", action="store_true", help="Output results as JSON")
    
    args = parser.parse_args()
    
    password = args.password or getpass("Password: ")
    
    try:
        audit = NutanixAudit(
            server=args.server,
            username=args.username,
            password=password,
            verify_ssl=not args.insecure,
            port=args.port
        )
        
        results = audit.run_full_audit()
        
        if args.json:
            print(results.to_json())
        
        # Exit code based on results
        if results.failed > 0:
            sys.exit(2)
        elif results.warnings > 0:
            sys.exit(1)
        else:
            sys.exit(0)
            
    except KeyboardInterrupt:
        print("\nAudit cancelled")
        sys.exit(130)


if __name__ == "__main__":
    main()
