#!/usr/bin/env bash
# nutanix-prism-audit.sh — Nutanix Prism Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: Hyperconverged Infrastructure
# - NIST SP 800-53: AC-2, AC-6, AU-2, SC-8 (Access, Audit, Encryption)
# - Nutanix Security Technical Implementation Guide (STIG)
# - PCI DSS: 8.1, 10.1 (Authentication, Audit Logging)
# - HIPAA: 164.312 (Access Controls, Audit)
#
# Note: Run this on a Nutanix CVM (Controller VM) or use API mode.
# Supports both Prism Element (cluster) and Prism Central.
#
# Checks:
# - Cluster and CVM security
# - Authentication (local, LDAP, SAML)
# - Data Services IP and network
# - Data-at-rest encryption
# - Backup/DR policies
# - RBAC and user management
# - SSL/TLS configuration
# - Security policies

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "Nutanix Environment Detection"

# Check if we're on a CVM
is_cvm=false
is_pcvm=false  # Prism Central VM
ntnx_version=""

# Check for ncli (Nutanix CLI)
if command -v ncli >/dev/null 2>&1; then
    is_cvm=true
    ntnx_version=$(ncli cluster info 2>/dev/null | grep "Cluster Version" | awk -F': ' '{print $2}' || echo "unknown")
elif command -v nuclei >/dev/null 2>&1; then
    # Prism Central uses nuclei
    is_pcvm=true
    ntnx_version=$(nuclei version 2>/dev/null | head -1 || echo "PC")
fi

# Check for acli (Acropolis CLI)
has_acli=false
if command -v acli >/dev/null 2>&1; then
    has_acli=true
fi

# Check for Prism Central indicator
if [[ -f /home/nutanix/prism_central ]]; then
    is_pcvm=true
fi

if ! $is_cvm && ! $is_pcvm; then
    register_check "Nutanix Environment" SKIP "not detected (run on CVM)"
    print_summary
    exit "$EXIT_CODE"
fi

if $is_pcvm; then
    register_check "Prism Central" PASS "version: $ntnx_version"
else
    register_check "Prism Element (CVM)" PASS "version: $ntnx_version"
fi

# ============================================================================
section "Cluster Security"
# ============================================================================

if $is_cvm; then
    # Check cluster name
    cluster_name=$(ncli cluster info 2>/dev/null | grep "Cluster Name" | awk -F': ' '{print $2}' || echo "unknown")
    register_check "Cluster name" PASS "$cluster_name"

    # Check cluster ID
    cluster_uuid=$(ncli cluster info 2>/dev/null | grep "Cluster UUID" | awk -F': ' '{print $2}' || echo "")
    if [[ -n "$cluster_uuid" ]]; then
        register_check "Cluster UUID" PASS "${cluster_uuid:0:8}..."
    fi

    # Check number of nodes
    node_count=$(ncli host list 2>/dev/null | grep -c "Host Id" || echo "0")
    if [[ "$node_count" -ge 3 ]]; then
        register_check "Cluster nodes" PASS "$node_count nodes (HA supported)"
    elif [[ "$node_count" -gt 0 ]]; then
        register_check "Cluster nodes" WARN "$node_count node(s) (no HA)"
    fi

    # Check RF (Replication Factor)
    rf=$(ncli container ls 2>/dev/null | grep "Replication Factor" | head -1 | awk -F': ' '{print $2}' || echo "unknown")
    if [[ "$rf" != "unknown" ]] && [[ "$rf" -ge 2 ]]; then
        register_check "Replication factor" PASS "RF $rf"
    else
        register_check "Replication factor" WARN "RF $rf (recommend RF2+)"
    fi
fi

# ============================================================================
section "Authentication Security"
# ============================================================================

if $is_cvm; then
    # Check for directory services (LDAP/AD)
    ldap_enabled=$(ncli authconfig list-directory 2>/dev/null | grep -c "Directory Type" || echo "0")
    if [[ "$ldap_enabled" -gt 0 ]]; then
        ldap_type=$(ncli authconfig list-directory 2>/dev/null | grep "Directory Type" | head -1 | awk -F': ' '{print $2}')
        register_check "Directory authentication" PASS "$ldap_type configured"

        # Check LDAP over SSL
        ldap_ssl=$(ncli authconfig list-directory 2>/dev/null | grep -i "connection.*type\|ssl\|ldaps" | head -1 || echo "")
        if echo "$ldap_ssl" | grep -qi "ssl\|ldaps\|636"; then
            register_check "LDAP encryption" PASS "SSL/LDAPS enabled"
        else
            register_check "LDAP encryption" WARN "plain LDAP (use LDAPS)"
        fi
    else
        register_check "Directory authentication" WARN "local auth only"
    fi

    # Check for SAML/IDP
    saml_enabled=$(ncli authconfig list-saml-idp 2>/dev/null | grep -c "IDP Name" || echo "0")
    if [[ "$saml_enabled" -gt 0 ]]; then
        register_check "SAML/SSO" PASS "IdP configured"
    fi

    # Check for CAC/Smart Card
    cac_enabled=$(ncli authconfig get-cac-status 2>/dev/null | grep -i "enabled.*true" || echo "")
    if [[ -n "$cac_enabled" ]]; then
        register_check "CAC/Smart Card" PASS "enabled"
    fi
fi

# Check local admin account
if $is_cvm; then
    # Check if default admin password policy is set
    admin_exists=$(ncli user list 2>/dev/null | grep -c "admin" || echo "0")
    if [[ "$admin_exists" -gt 0 ]]; then
        register_check "Admin account" PASS "exists"
    fi

    # Check password complexity
    pwd_policy=$(ncli authconfig list-password-policy 2>/dev/null || echo "")
    if [[ -n "$pwd_policy" ]]; then
        min_length=$(echo "$pwd_policy" | grep -i "minimum.*length" | awk -F': ' '{print $2}' || echo "unknown")
        if [[ "$min_length" != "unknown" ]] && [[ "$min_length" -ge 12 ]]; then
            register_check "Password min length" PASS "$min_length chars"
        elif [[ "$min_length" != "unknown" ]]; then
            register_check "Password min length" WARN "$min_length chars (recommend ≥12)"
        fi

        complexity=$(echo "$pwd_policy" | grep -i "complexity" | awk -F': ' '{print $2}' || echo "")
        if [[ "$complexity" == *"true"* ]] || [[ "$complexity" == *"enabled"* ]]; then
            register_check "Password complexity" PASS "enabled"
        else
            register_check "Password complexity" WARN "not enabled"
        fi
    fi
fi

# ============================================================================
section "SSL/TLS Security"
# ============================================================================

if $is_cvm; then
    # Check SSL certificate
    cert_info=$(ncli ssl-cert info 2>/dev/null || echo "")
    if [[ -n "$cert_info" ]]; then
        # Check expiration
        expiry=$(echo "$cert_info" | grep -i "expiry\|valid.*until\|not.*after" | head -1 || echo "")
        if [[ -n "$expiry" ]]; then
            register_check "SSL certificate" PASS "configured"
        fi

        # Check if CA-signed
        issuer=$(echo "$cert_info" | grep -i "issuer" | head -1 || echo "")
        subject=$(echo "$cert_info" | grep -i "subject" | head -1 || echo "")
        if [[ "$issuer" != "$subject" ]] && [[ -n "$issuer" ]]; then
            register_check "Certificate type" PASS "CA-signed"
        else
            register_check "Certificate type" WARN "self-signed (consider CA cert)"
        fi
    else
        register_check "SSL certificate info" SKIP "could not query"
    fi

    # Check TLS version
    tls_config=$(ncli authconfig list 2>/dev/null | grep -i "tls\|ssl" || echo "")
    if echo "$tls_config" | grep -qi "1.2\|1.3"; then
        register_check "TLS version" PASS "TLS 1.2+"
    fi
fi

# Check Prism web interface certificate
prism_cert="/home/nutanix/config/ssl/*.crt"
if compgen -G "$prism_cert" > /dev/null 2>&1; then
    cert_file=$(ls -1 $prism_cert 2>/dev/null | head -1)
    if [[ -f "$cert_file" ]]; then
        expiry=$(openssl x509 -enddate -noout -in "$cert_file" 2>/dev/null | cut -d= -f2)
        if [[ -n "$expiry" ]]; then
            expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo 0)
            now_epoch=$(date +%s)
            days_left=$(( (expiry_epoch - now_epoch) / 86400 ))
            if [[ $days_left -gt 30 ]]; then
                register_check "Prism SSL cert" PASS "$days_left days until expiry"
            elif [[ $days_left -gt 0 ]]; then
                register_check "Prism SSL cert" WARN "expires in $days_left days"
            else
                register_check "Prism SSL cert" FAIL "expired"
            fi
        fi
    fi
fi

# ============================================================================
section "Data Security"
# ============================================================================

if $is_cvm; then
    # Check data-at-rest encryption
    encryption_status=$(ncli container ls 2>/dev/null | grep -i "encryption" | head -1 || echo "")
    if echo "$encryption_status" | grep -qi "enabled\|true\|yes"; then
        register_check "Data-at-rest encryption" PASS "enabled"
    else
        # Check cluster-wide setting
        cluster_enc=$(ncli cluster get-encryption-status 2>/dev/null || echo "")
        if echo "$cluster_enc" | grep -qi "enabled\|encrypted"; then
            register_check "Data-at-rest encryption" PASS "cluster encryption enabled"
        else
            register_check "Data-at-rest encryption" WARN "not detected"
        fi
    fi

    # Check erasure coding (storage efficiency with data protection)
    ec_enabled=$(ncli container ls 2>/dev/null | grep -i "erasure.*code\|ec.*strip" || echo "")
    if [[ -n "$ec_enabled" ]]; then
        register_check "Erasure coding" PASS "enabled on some containers"
    fi

    # Check data services IP
    dsip=$(ncli cluster info 2>/dev/null | grep -i "data.*services.*ip\|external.*data" | head -1 || echo "")
    if [[ -n "$dsip" ]]; then
        register_check "Data Services IP" PASS "configured"
    else
        register_check "Data Services IP" WARN "not configured"
    fi
fi

# ============================================================================
section "Network Security"
# ============================================================================

if $is_cvm; then
    # Check network segmentation
    net_list=$(ncli network list 2>/dev/null || echo "")
    net_count=$(echo "$net_list" | grep -c "Network UUID" || echo "0")
    if [[ "$net_count" -gt 1 ]]; then
        register_check "Network segmentation" PASS "$net_count networks"
    elif [[ "$net_count" -gt 0 ]]; then
        register_check "Network segmentation" WARN "single network"
    fi

    # Check for management VLAN
    mgmt_vlan=$(echo "$net_list" | grep -i "management\|mgmt" || echo "")
    if [[ -n "$mgmt_vlan" ]]; then
        register_check "Management network" PASS "dedicated management network"
    fi
fi

if $has_acli; then
    # Check microsegmentation / Flow
    flow_enabled=$(acli net.list_security_policies 2>/dev/null | grep -c "Security Policy" || echo "0")
    if [[ "$flow_enabled" -gt 0 ]]; then
        register_check "Flow microsegmentation" PASS "$flow_enabled policies"
    else
        register_check "Flow microsegmentation" WARN "no security policies"
    fi
fi

# ============================================================================
section "RBAC & Users"
# ============================================================================

if $is_cvm; then
    # Count local users
    user_count=$(ncli user list 2>/dev/null | grep -c "User Name" || echo "0")
    register_check "Local users" PASS "$user_count user(s)"

    # Check for role assignments
    role_count=$(ncli role list 2>/dev/null | grep -c "Role Name" || echo "0")
    if [[ "$role_count" -gt 0 ]]; then
        register_check "RBAC roles" PASS "$role_count role(s)"
    fi

    # Check for cluster admin accounts
    admin_count=$(ncli user list 2>/dev/null | grep -i "cluster.*admin\|Administrator" | wc -l || echo "0")
    if [[ "$admin_count" -le 3 ]]; then
        register_check "Cluster admins" PASS "$admin_count admin(s)"
    else
        register_check "Cluster admins" WARN "$admin_count admins (review necessity)"
    fi
fi

# ============================================================================
section "Backup & DR"
# ============================================================================

if $is_cvm; then
    # Check for protection domains
    pd_count=$(ncli protection-domain ls 2>/dev/null | grep -c "Protection Domain" || echo "0")
    if [[ "$pd_count" -gt 0 ]]; then
        register_check "Protection domains" PASS "$pd_count PD(s)"
    else
        register_check "Protection domains" WARN "no protection domains"
    fi

    # Check for remote sites
    remote_sites=$(ncli remote-site ls 2>/dev/null | grep -c "Remote Site" || echo "0")
    if [[ "$remote_sites" -gt 0 ]]; then
        register_check "Remote sites (DR)" PASS "$remote_sites site(s)"
    else
        register_check "Remote sites (DR)" WARN "no remote sites configured"
    fi

    # Check for async DR schedules
    schedules=$(ncli protection-domain ls 2>/dev/null | grep -i "schedule" || echo "")
    if [[ -n "$schedules" ]]; then
        register_check "Replication schedules" PASS "configured"
    fi
fi

# ============================================================================
section "Audit & Logging"
# ============================================================================

if $is_cvm; then
    # Check for syslog forwarding
    syslog_config=$(ncli rsyslog-config show 2>/dev/null || echo "")
    if echo "$syslog_config" | grep -qi "server.*ip\|remote"; then
        register_check "Syslog forwarding" PASS "remote syslog configured"
    else
        register_check "Syslog forwarding" WARN "no remote syslog"
    fi

    # Check audit log
    if [[ -d /home/nutanix/data/logs ]]; then
        audit_logs=$(find /home/nutanix/data/logs -name "*audit*" -mtime -1 2>/dev/null | wc -l)
        if [[ "$audit_logs" -gt 0 ]]; then
            register_check "Audit logging" PASS "active"
        else
            register_check "Audit logging" WARN "no recent audit logs"
        fi
    fi
fi

# Check API audit in Prism Central
if $is_pcvm; then
    if [[ -d /home/nutanix/data/logs/audit ]]; then
        register_check "PC audit logs" PASS "directory exists"
    fi
fi

# ============================================================================
section "System Hardening"
# ============================================================================

# Check SSH access
sshd_config="/etc/ssh/sshd_config"
if [[ -f "$sshd_config" ]]; then
    if grep -qi "^PermitRootLogin.*yes" "$sshd_config" 2>/dev/null; then
        register_check "Root SSH login" WARN "enabled"
    elif grep -qi "^PermitRootLogin.*no" "$sshd_config" 2>/dev/null; then
        register_check "Root SSH login" PASS "disabled"
    fi
fi

# Check NTP
if $is_cvm; then
    ntp_servers=$(ncli cluster get-ntp-servers 2>/dev/null || echo "")
    if [[ -n "$ntp_servers" ]] && [[ "$ntp_servers" != *"No NTP"* ]]; then
        register_check "NTP servers" PASS "configured"
    else
        register_check "NTP servers" WARN "not configured"
    fi
fi

# Check CVM memory/resources
cvm_memory=$(free -g 2>/dev/null | grep Mem | awk '{print $2}')
if [[ -n "$cvm_memory" ]] && [[ "$cvm_memory" -ge 24 ]]; then
    register_check "CVM memory" PASS "${cvm_memory}GB"
elif [[ -n "$cvm_memory" ]]; then
    register_check "CVM memory" WARN "${cvm_memory}GB (recommend ≥24GB)"
fi

# Check for Foundation security
if command -v foundation >/dev/null 2>&1; then
    register_check "Foundation CLI" PASS "available"
fi

# ============================================================================section "AHV Hypervisor Security"
# ============================================================================

# Check if running on AHV
if $is_cvm; then
    hypervisor_type=$(ncli cluster info 2>/dev/null | grep -i "Hypervisor" | head -1 | awk -F': ' '{print $2}' || echo "")
    if echo "$hypervisor_type" | grep -qi "AHV\|Acropolis"; then
        register_check "Hypervisor type" PASS "AHV"

        # Check AHV version
        ahv_version=$(ncli host list 2>/dev/null | grep -i "Hypervisor Version" | head -1 | awk -F': ' '{print $2}' || echo "")
        if [[ -n "$ahv_version" ]]; then
            register_check "AHV version" PASS "$ahv_version"
        fi

        # Check for AHV security features
        if $has_acli; then
            # Check secure boot status
            secureboot=$(acli host.list_secure_boot 2>/dev/null | grep -c "Enabled" || echo "0")
            if [[ "$secureboot" -gt 0 ]]; then
                register_check "AHV Secure Boot" PASS "$secureboot host(s) enabled"
            else
                register_check "AHV Secure Boot" WARN "not enabled"
            fi

            # Check vTPM status
            vtpm_vms=$(acli vm.list 2>/dev/null | grep -c "vtpm" || echo "0")
            if [[ "$vtpm_vms" -gt 0 ]]; then
                register_check "vTPM VMs" PASS "$vtpm_vms VM(s)"
            fi
        fi
    elif echo "$hypervisor_type" | grep -qi "ESXi\|VMware"; then
        register_check "Hypervisor type" PASS "VMware ESXi"
    elif echo "$hypervisor_type" | grep -qi "Hyper-V"; then
        register_check "Hypervisor type" PASS "Hyper-V"
    fi
fi

# AHV host-level security
if $is_cvm && $has_acli; then
    # Check AHV firewall
    ahv_firewall=$(acli host.list_firewall_rules 2>/dev/null | grep -c "ACCEPT\|DROP" || echo "0")
    if [[ "$ahv_firewall" -gt 0 ]]; then
        register_check "AHV firewall rules" PASS "$ahv_firewall rules"
    fi

    # Check VM high availability
    ha_vms=$(acli vm.list 2>/dev/null | grep -c "ha_priority" || echo "0")
    if [[ "$ha_vms" -gt 0 ]]; then
        register_check "HA-enabled VMs" PASS "$ha_vms VM(s)"
    fi
fi

# ============================================================================
section "IPMI/BMC Security"
# ============================================================================

if $is_cvm; then
    # Check IPMI configuration
    ipmi_config=$(ncli host list 2>/dev/null | grep -i "IPMI Address" | head -1 || echo "")
    if [[ -n "$ipmi_config" ]]; then
        register_check "IPMI configured" PASS "detected"

        # Check if IPMI is on separate network (best practice)
        ipmi_network=$(echo "$ipmi_config" | awk -F': ' '{print $2}' | cut -d. -f1-3)
        mgmt_network=$(ip route get 1 2>/dev/null | awk '{print $7}' | head -1 | cut -d. -f1-3)
        if [[ "$ipmi_network" != "$mgmt_network" ]]; then
            register_check "IPMI network isolation" PASS "separate network"
        else
            register_check "IPMI network isolation" WARN "same network as management"
        fi
    fi

    # Check for ipmitool
    if command -v ipmitool >/dev/null 2>&1; then
        # Check IPMI users (look for default accounts)
        ipmi_users=$(ipmitool user list 1 2>/dev/null | grep -c "ADMIN\|admin" || echo "0")
        if [[ "$ipmi_users" -gt 0 ]]; then
            register_check "IPMI admin users" WARN "default admin accounts may exist"
        fi

        # Check IPMI cipher suites (weak ciphers)
        cipher0=$(ipmitool raw 0x06 0x54 2>/dev/null | grep -c "00" || echo "false")
        if [[ "$cipher0" != "false" ]] && [[ "$cipher0" != "0" ]]; then
            register_check "IPMI cipher 0" WARN "weak cipher may be enabled"
        else
            register_check "IPMI ciphers" PASS "weak ciphers not detected"
        fi
    fi
fi

# ============================================================================
section "Additional Security Features"
# ============================================================================

if $is_cvm; then
    # Check Files (file server) security
    files_servers=$(ncli fs ls 2>/dev/null | grep -c "File Server" || echo "0")
    if [[ "$files_servers" -gt 0 ]]; then
        register_check "Nutanix Files" PASS "$files_servers file server(s)"

        # Check for SMB signing
        smb_signing=$(ncli fs ls 2>/dev/null | grep -i "smb.*signing\|signing.*required" || echo "")
        if [[ -n "$smb_signing" ]]; then
            register_check "SMB signing" PASS "configured"
        fi
    fi

    # Check Objects (S3) security
    objects_stores=$(ncli container ls 2>/dev/null | grep -i "objects" | wc -l || echo "0")
    if [[ "$objects_stores" -gt 0 ]]; then
        register_check "Nutanix Objects" PASS "$objects_stores store(s)"
    fi

    # Check for Calm (automation platform)
    if command -v calm >/dev/null 2>&1 || ncli app ls 2>/dev/null | grep -qi "application"; then
        register_check "Nutanix Calm" PASS "available"
    fi
fi

# Check for Prism Central specific features
if $is_pcvm; then
    # Check Prism Central categories
    categories=$(nuclei category.list 2>/dev/null | grep -c "name" || echo "0")
    if [[ "$categories" -gt 0 ]]; then
        register_check "PC categories" PASS "$categories categories"
    fi

    # Check for X-Play (playbooks)
    playbooks=$(nuclei action_rule.list 2>/dev/null | grep -c "name" || echo "0")
    if [[ "$playbooks" -gt 0 ]]; then
        register_check "X-Play playbooks" PASS "$playbooks playbook(s)"
    fi

    # Check for security policies (Flow)
    sec_policies=$(nuclei network_security_rule.list 2>/dev/null | grep -c "name" || echo "0")
    if [[ "$sec_policies" -gt 0 ]]; then
        register_check "Flow policies" PASS "$sec_policies policies"
    else
        register_check "Flow policies" WARN "no security policies defined"
    fi
fi

# Foundation security settings
if [[ -f /home/nutanix/foundation/config/foundation_settings.json ]]; then
    foundation_https=$(grep -i "https\|ssl" /home/nutanix/foundation/config/foundation_settings.json 2>/dev/null || echo "")
    if [[ -n "$foundation_https" ]]; then
        register_check "Foundation HTTPS" PASS "configured"
    fi
fi

# Karbon (Kubernetes) security - if installed
if command -v karbonctl >/dev/null 2>&1; then
    karbon_clusters=$(karbonctl cluster list 2>/dev/null | grep -c "ACTIVE" || echo "0")
    if [[ "$karbon_clusters" -gt 0 ]]; then
        register_check "Karbon clusters" PASS "$karbon_clusters active cluster(s)"

        # Check for private registry
        private_reg=$(karbonctl cluster get 2>/dev/null | grep -i "private.*registry" || echo "")
        if [[ -n "$private_reg" ]]; then
            register_check "Karbon private registry" PASS "configured"
        fi
    fi
fi

# LCM (Life Cycle Manager) status
if $is_cvm; then
    lcm_inventory=$(ncli software list 2>/dev/null | grep -c "Software" || echo "0")
    if [[ "$lcm_inventory" -gt 0 ]]; then
        register_check "LCM inventory" PASS "$lcm_inventory items"

        # Check for available updates
        lcm_updates=$(ncli software list 2>/dev/null | grep -i "available" | wc -l || echo "0")
        if [[ "$lcm_updates" -gt 0 ]]; then
            register_check "LCM updates" WARN "$lcm_updates updates available"
        else
            register_check "LCM updates" PASS "up to date"
        fi
    fi
fi

# ============================================================================section "Summary"
# ============================================================================

print_summary
exit "$EXIT_CODE"
