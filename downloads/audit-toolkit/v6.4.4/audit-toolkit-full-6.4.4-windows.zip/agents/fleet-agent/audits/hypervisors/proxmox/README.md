# Proxmox VE Security Audits

Security audits for Proxmox Virtual Environment (PVE).

## Execution Methods

1. **Local** - Run directly on Proxmox node
2. **Remote SSH** - Execute via SSH
3. **REST API** - Proxmox API with authentication token

## Planned Audits

### proxmox-baseline-audit.sh
Core Proxmox hardening:
- [ ] pveproxy TLS configuration
- [ ] Web UI access restrictions
- [ ] Two-factor authentication
- [ ] API token permissions
- [ ] Root account security
- [ ] SSH hardening
- [ ] Syslog configuration
- [ ] NTP synchronization

### proxmox-cluster-audit.sh
Cluster security:
- [ ] Cluster encryption enabled
- [ ] Corosync configuration
- [ ] Node authentication
- [ ] Quorum configuration
- [ ] HA fencing configuration
- [ ] Migration encryption

### proxmox-auth-audit.sh
Authentication and authorization:
- [ ] PAM vs PVE realm configuration
- [ ] LDAP/AD integration security
- [ ] User permissions (Datacenter level)
- [ ] Role definitions
- [ ] API token scopes
- [ ] Pool permissions

### proxmox-network-audit.sh
Network configuration:
- [ ] Bridge configuration
- [ ] VLAN tagging
- [ ] SDN configuration (if used)
- [ ] Firewall enabled (pve-firewall)
- [ ] Default firewall rules
- [ ] Management network isolation

### proxmox-storage-audit.sh
Storage security:
- [ ] Storage permissions
- [ ] ZFS encryption (if applicable)
- [ ] Ceph encryption (if applicable)
- [ ] NFS/iSCSI security
- [ ] Backup encryption
- [ ] PBS (Backup Server) configuration

### proxmox-vm-audit.sh
VM/Container security:
- [ ] VM agent enabled
- [ ] QEMU guest agent
- [ ] Container unprivileged mode
- [ ] AppArmor profiles
- [ ] Resource limits
- [ ] Snapshot encryption

## Key Commands Reference

```bash
# Cluster info
pvecm status
pvecm nodes

# System
pveversion -v
pvesubscription get

# Users/permissions
pveum user list
pveum acl list
pveum role list

# VMs/Containers
qm list
pct list
pvesh get /cluster/resources

# Storage
pvesm status
pvesh get /storage

# Firewall
pve-firewall status
cat /etc/pve/firewall/cluster.fw

# Certificates
pvenode cert info

# Backup
pvesh get /cluster/backup
```

## CIS/Security Standards

No official CIS Benchmark exists for Proxmox, but audits follow:
- CIS Debian Benchmark (base OS)
- General virtualization security best practices
- Proxmox official hardening guide

## Implementation Notes

- Proxmox is Debian-based, so many Linux audits apply
- `/etc/pve/` is cluster-synchronized configuration
- Use `pvesh` for API-like access from CLI
- Corosync requires careful network configuration
