#!/usr/bin/env python3
"""
Proxmox VE Security Audit via REST API

Cross-platform Proxmox audit using Proxmox VE REST API.
Runs on Windows, Linux, or macOS with Python 3.8+.
Does NOT require SSH access - uses API tokens for authentication.

Compliance Mapping:
- CIS Benchmark: Virtualization Platforms
- NIST SP 800-125: Virtualization Security
- NIST SP 800-53: AC-2, AC-6, AU-2, SC-8
- PCI DSS: 2.2.1, 8.1, 10.1

Usage:
    # With password authentication
    python proxmox-api-audit.py --server pve.example.com --username root@pam

    # With API token (recommended for automation)
    python proxmox-api-audit.py --server pve.example.com --token-id user@pam!audit --token-secret <secret>

Requirements:
    pip install requests urllib3

API Documentation: https://pve.proxmox.com/pve-docs/api-viewer/
"""

import argparse
import json
import sys
import urllib3
from datetime import datetime
from getpass import getpass
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    print("ERROR: requests module required. Install with: pip install requests")
    sys.exit(1)


class AuditResults:
    """Track audit results"""

    def __init__(self):
        self.checks: List[Dict[str, str]] = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0

    def register(self, name: str, status: str, message: str = "") -> None:
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"

        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))

        self.checks.append({"name": name, "status": status, "message": message})

        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1

    def section(self, title: str) -> None:
        """Print section header"""
        print(f"\n\033[96m=== {title} ===\033[0m\n")

    def summary(self) -> None:
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")

    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "timestamp": datetime.now().isoformat(),
            "checks": self.checks,
            "summary": {
                "total": len(self.checks),
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class ProxmoxAudit:
    """Proxmox VE REST API Audit Client"""

    def __init__(self, server: str, username: str = None, password: str = None,
                 token_id: str = None, token_secret: str = None,
                 verify_ssl: bool = True, port: int = 8006):
        self.server = server
        self.base_url = f"https://{server}:{port}/api2/json"
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.results = AuditResults()
        self.cluster_info: Dict[str, Any] = {}
        self.nodes: List[Dict[str, Any]] = []

        # Authenticate
        if token_id and token_secret:
            self._auth_token(token_id, token_secret)
        elif username and password:
            self._auth_password(username, password)
        else:
            raise ValueError("Must provide either username/password or token_id/token_secret")

    def _auth_token(self, token_id: str, token_secret: str) -> None:
        """Authenticate using API token"""
        self.session.headers["Authorization"] = f"PVEAPIToken={token_id}={token_secret}"

        # Test authentication
        try:
            response = self.session.get(f"{self.base_url}/version")
            response.raise_for_status()
            version = response.json().get("data", {}).get("version", "unknown")
            self.results.register("API Authentication", "PASS", f"Token auth - PVE {version}")
        except requests.exceptions.RequestException as e:
            self.results.register("API Authentication", "FAIL", str(e))
            raise SystemExit(1)

    def _auth_password(self, username: str, password: str) -> None:
        """Authenticate using username/password"""
        try:
            response = self.session.post(
                f"{self.base_url}/access/ticket",
                data={"username": username, "password": password}
            )
            response.raise_for_status()

            data = response.json().get("data", {})
            ticket = data.get("ticket")
            csrf_token = data.get("CSRFPreventionToken")

            self.session.cookies.set("PVEAuthCookie", ticket)
            self.session.headers["CSRFPreventionToken"] = csrf_token

            self.results.register("API Authentication", "PASS", f"Password auth as {username}")
        except requests.exceptions.RequestException as e:
            self.results.register("API Authentication", "FAIL", str(e))
            raise SystemExit(1)

    def _get(self, endpoint: str) -> Optional[Any]:
        """Make GET request to API"""
        try:
            response = self.session.get(f"{self.base_url}{endpoint}")
            if response.status_code == 200:
                return response.json().get("data")
            return None
        except Exception:
            return None

    def audit_cluster_info(self) -> None:
        """Audit basic cluster information"""
        self.results.section("Cluster Information")

        # Get version
        version = self._get("/version")
        if version:
            pve_version = version.get("version", "unknown")
            release = version.get("release", "")
            self.results.register("PVE Version", "PASS", f"{pve_version}-{release}")

        # Get cluster status
        cluster_status = self._get("/cluster/status")
        if cluster_status:
            for item in cluster_status:
                if item.get("type") == "cluster":
                    self.cluster_info = item
                    name = item.get("name", "standalone")
                    nodes = item.get("nodes", 1)
                    quorate = item.get("quorate", 0)

                    self.results.register("Cluster Name", "PASS", name)
                    self.results.register("Cluster Nodes", "PASS", str(nodes))

                    if quorate:
                        self.results.register("Quorum", "PASS", "Cluster has quorum")
                    else:
                        self.results.register("Quorum", "FAIL", "No quorum!")

        # Get nodes
        self.nodes = self._get("/nodes") or []
        self.results.register("Nodes Discovered", "PASS", f"{len(self.nodes)} node(s)")

    def audit_authentication(self) -> None:
        """Audit authentication configuration"""
        self.results.section("Authentication Security")

        # Get auth domains (realms)
        domains = self._get("/access/domains") or []

        pam_found = False
        ldap_found = False
        ad_found = False

        for domain in domains:
            realm = domain.get("realm", "")
            domain_type = domain.get("type", "")

            if domain_type == "pam":
                pam_found = True
            elif domain_type == "ldap":
                ldap_found = True
                # Check LDAP over TLS
                if domain.get("secure"):
                    self.results.register(f"LDAP {realm}", "PASS", "LDAPS/TLS enabled")
                else:
                    self.results.register(f"LDAP {realm}", "WARN", "Plain LDAP (use LDAPS)")
            elif domain_type == "ad":
                ad_found = True
                self.results.register(f"AD {realm}", "PASS", "Active Directory configured")

        if ldap_found or ad_found:
            self.results.register("External Auth", "PASS", "LDAP/AD configured")
        elif pam_found:
            self.results.register("External Auth", "WARN", "Only local PAM auth (consider LDAP/AD)")

        # Check for 2FA
        users = self._get("/access/users") or []
        tfa_users = sum(1 for u in users if u.get("totp") or u.get("keys"))
        if tfa_users > 0:
            self.results.register("2FA Users", "PASS", f"{tfa_users} user(s) with 2FA")
        else:
            self.results.register("2FA Users", "WARN", "No 2FA configured (recommend enabling)")

    def audit_users_permissions(self) -> None:
        """Audit users and permissions (RBAC)"""
        self.results.section("Users & RBAC")

        # Get users
        users = self._get("/access/users") or []
        enabled_users = [u for u in users if u.get("enable", True)]

        self.results.register("Total Users", "PASS", f"{len(users)} user(s)")
        self.results.register("Enabled Users", "PASS", f"{len(enabled_users)} active")

        # Check for admin users
        admin_count = sum(1 for u in users if "admin" in u.get("userid", "").lower())
        if admin_count <= 3:
            self.results.register("Admin Users", "PASS", f"{admin_count} admin(s)")
        else:
            self.results.register("Admin Users", "WARN", f"{admin_count} admins (review necessity)")

        # Get roles
        roles = self._get("/access/roles") or []
        self.results.register("Custom Roles", "PASS", f"{len(roles)} role(s)")

        # Get groups
        groups = self._get("/access/groups") or []
        if groups:
            self.results.register("User Groups", "PASS", f"{len(groups)} group(s)")
        else:
            self.results.register("User Groups", "WARN", "No groups defined (consider RBAC)")

        # Check API tokens
        token_count = 0
        for user in users:
            tokens = self._get(f"/access/users/{user.get('userid')}/token") or []
            token_count += len(tokens)

        if token_count > 0:
            self.results.register("API Tokens", "WARN", f"{token_count} token(s) (review permissions)")
        else:
            self.results.register("API Tokens", "PASS", "No API tokens")

    def audit_web_security(self) -> None:
        """Audit web interface security"""
        self.results.section("Web Interface Security")

        # Check datacenter config
        dc_config = self._get("/cluster/options") or {}

        # Check console settings
        console = dc_config.get("console", "default")
        self.results.register("Console Default", "PASS", console)

        # Check keyboard layout
        keyboard = dc_config.get("keyboard", "en-us")
        self.results.register("Keyboard Layout", "PASS", keyboard)

        # Check email settings (for alerts)
        if dc_config.get("email_from"):
            self.results.register("Email Alerts", "PASS", "Configured")
        else:
            self.results.register("Email Alerts", "WARN", "Not configured")

    def audit_cluster_security(self) -> None:
        """Audit cluster security settings"""
        self.results.section("Cluster Security")

        # Get corosync config (if cluster)
        if self.cluster_info:
            # Check cluster encryption via config
            config = self._get("/cluster/config") or {}

            # Check if encrypted
            totem = config.get("totem", {})
            if totem.get("secauth") == "on":
                self.results.register("Corosync Auth", "PASS", "Secure auth enabled")
            else:
                self.results.register("Corosync Auth", "WARN", "Check corosync security")
        else:
            self.results.register("Cluster Config", "SKIP", "Single node (no cluster)")

    def audit_firewall(self) -> None:
        """Audit firewall configuration"""
        self.results.section("Firewall Configuration")

        # Check cluster firewall
        fw_options = self._get("/cluster/firewall/options") or {}

        if fw_options.get("enable"):
            self.results.register("Cluster Firewall", "PASS", "Enabled")
        else:
            self.results.register("Cluster Firewall", "WARN", "Disabled (consider enabling)")

        # Check policy_in/out
        policy_in = fw_options.get("policy_in", "DROP")
        policy_out = fw_options.get("policy_out", "ACCEPT")

        if policy_in == "DROP":
            self.results.register("Inbound Policy", "PASS", "DROP (default deny)")
        else:
            self.results.register("Inbound Policy", "WARN", f"{policy_in} (recommend DROP)")

        self.results.register("Outbound Policy", "PASS", policy_out)

        # Count firewall rules
        rules = self._get("/cluster/firewall/rules") or []
        self.results.register("Cluster FW Rules", "PASS", f"{len(rules)} rule(s)")

        # Check per-node firewall
        for node in self.nodes:
            node_name = node.get("node", "")
            node_fw = self._get(f"/nodes/{node_name}/firewall/options") or {}

            if node_fw.get("enable"):
                self.results.register(f"{node_name} Firewall", "PASS", "Enabled")
            else:
                self.results.register(f"{node_name} Firewall", "WARN", "Disabled")

    def audit_storage(self) -> None:
        """Audit storage security"""
        self.results.section("Storage Security")

        storage = self._get("/storage") or []

        encrypted_count = 0
        for store in storage:
            name = store.get("storage", "")
            store_type = store.get("type", "")

            # Check for encryption indicators
            if store.get("encryption") or "crypt" in name.lower():
                encrypted_count += 1

        self.results.register("Storage Pools", "PASS", f"{len(storage)} pool(s)")

        if encrypted_count > 0:
            self.results.register("Encrypted Storage", "PASS", f"{encrypted_count} encrypted")
        else:
            self.results.register("Encrypted Storage", "WARN", "No encrypted storage detected")

    def audit_vms_containers(self) -> None:
        """Audit VMs and containers security"""
        self.results.section("VMs & Containers")

        total_vms = 0
        total_cts = 0
        unprivileged_cts = 0

        for node in self.nodes:
            node_name = node.get("node", "")

            # Get VMs
            vms = self._get(f"/nodes/{node_name}/qemu") or []
            total_vms += len(vms)

            # Get containers
            cts = self._get(f"/nodes/{node_name}/lxc") or []
            total_cts += len(cts)

            # Check for unprivileged containers
            for ct in cts:
                vmid = ct.get("vmid")
                config = self._get(f"/nodes/{node_name}/lxc/{vmid}/config") or {}
                if config.get("unprivileged"):
                    unprivileged_cts += 1

        self.results.register("Virtual Machines", "PASS", f"{total_vms} VM(s)")
        self.results.register("Containers", "PASS", f"{total_cts} CT(s)")

        if total_cts > 0:
            if unprivileged_cts == total_cts:
                self.results.register("Unprivileged CTs", "PASS", f"All {total_cts} unprivileged")
            else:
                privileged = total_cts - unprivileged_cts
                self.results.register("Unprivileged CTs", "WARN", f"{privileged} privileged CT(s)")

    def audit_backup(self) -> None:
        """Audit backup configuration"""
        self.results.section("Backup Configuration")

        # Check backup jobs
        jobs = self._get("/cluster/backup") or []

        if jobs:
            self.results.register("Backup Jobs", "PASS", f"{len(jobs)} job(s)")

            # Check for encryption
            encrypted_jobs = sum(1 for j in jobs if j.get("encrypt"))
            if encrypted_jobs > 0:
                self.results.register("Encrypted Backups", "PASS", f"{encrypted_jobs} job(s)")
            else:
                self.results.register("Encrypted Backups", "WARN", "No encrypted backup jobs")
        else:
            self.results.register("Backup Jobs", "FAIL", "No backup jobs configured!")

        # Check for PBS (Proxmox Backup Server) integration
        storage = self._get("/storage") or []
        pbs_count = sum(1 for s in storage if s.get("type") == "pbs")

        if pbs_count > 0:
            self.results.register("PBS Integration", "PASS", f"{pbs_count} PBS storage(s)")
        else:
            self.results.register("PBS Integration", "WARN", "Consider Proxmox Backup Server")

    def audit_ha(self) -> None:
        """Audit High Availability configuration"""
        self.results.section("High Availability")

        # Check HA status
        ha_status = self._get("/cluster/ha/status/current") or []

        if ha_status:
            self.results.register("HA Status", "PASS", "HA configured")

            # Check HA resources
            resources = self._get("/cluster/ha/resources") or []
            self.results.register("HA Resources", "PASS", f"{len(resources)} resource(s)")

            # Check HA groups
            groups = self._get("/cluster/ha/groups") or []
            if groups:
                self.results.register("HA Groups", "PASS", f"{len(groups)} group(s)")
        else:
            self.results.register("HA Status", "SKIP", "HA not configured")

    def audit_subscription(self) -> None:
        """Audit subscription status"""
        self.results.section("Subscription & Updates")

        for node in self.nodes:
            node_name = node.get("node", "")

            # Check subscription
            subscription = self._get(f"/nodes/{node_name}/subscription") or {}
            status = subscription.get("status", "notfound")

            if status == "Active":
                self.results.register(f"{node_name} Subscription", "PASS", "Active")
            else:
                self.results.register(f"{node_name} Subscription", "WARN",
                                      f"{status} (no enterprise updates)")

            # Check for updates
            updates = self._get(f"/nodes/{node_name}/apt/update") or []
            if updates:
                security_updates = sum(1 for u in updates if "security" in str(u).lower())
                if security_updates > 0:
                    self.results.register(f"{node_name} Security Updates", "WARN",
                                          f"{security_updates} pending")
                else:
                    self.results.register(f"{node_name} Updates", "PASS",
                                          f"{len(updates)} available")

    def run_full_audit(self) -> None:
        """Run complete security audit"""
        print(f"\033[96m{'='*60}\033[0m")
        print(f"\033[96mProxmox VE Security Audit via REST API\033[0m")
        print(f"\033[96mTarget: {self.server}\033[0m")
        print(f"\033[96mTime: {datetime.now().isoformat()}\033[0m")
        print(f"\033[96m{'='*60}\033[0m")

        self.audit_cluster_info()
        self.audit_authentication()
        self.audit_users_permissions()
        self.audit_web_security()
        self.audit_cluster_security()
        self.audit_firewall()
        self.audit_storage()
        self.audit_vms_containers()
        self.audit_backup()
        self.audit_ha()
        self.audit_subscription()

        self.results.summary()


def main():
    parser = argparse.ArgumentParser(
        description="Proxmox VE Security Audit via REST API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Password authentication
    %(prog)s --server pve.example.com --username root@pam

    # API token authentication (recommended)
    %(prog)s --server pve.example.com --token-id user@pam!audit --token-secret <secret>

    # With JSON output
    %(prog)s --server pve.example.com --username root@pam --output results.json

API Token Creation:
    pveum user token add root@pam audit --privsep=0
        """
    )
    parser.add_argument("--server", "-s", required=True, help="Proxmox VE server hostname or IP")
    parser.add_argument("--port", "-P", type=int, default=8006, help="API port (default: 8006)")
    parser.add_argument("--username", "-u", help="Username (e.g., root@pam)")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--token-id", help="API Token ID (e.g., user@pam!tokenname)")
    parser.add_argument("--token-secret", help="API Token Secret")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--output", "-o", help="Output JSON results to file")

    args = parser.parse_args()

    # Validate authentication args
    if not args.token_id and not args.username:
        parser.error("Must provide either --username or --token-id for authentication")

    # Get password if using username auth
    password = None
    if args.username:
        password = args.password or getpass("Password: ")

    # Disable SSL warnings if insecure
    if args.insecure:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # Run audit
    try:
        audit = ProxmoxAudit(
            server=args.server,
            port=args.port,
            username=args.username,
            password=password,
            token_id=args.token_id,
            token_secret=args.token_secret,
            verify_ssl=not args.insecure
        )
        audit.run_full_audit()

        # Output JSON if requested
        if args.output:
            with open(args.output, "w") as f:
                f.write(audit.results.to_json())
            print(f"\nResults saved to: {args.output}")

        # Exit with appropriate code
        sys.exit(1 if audit.results.failed > 0 else 0)

    except KeyboardInterrupt:
        print("\nAudit cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
