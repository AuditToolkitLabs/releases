#!/usr/bin/env bash
# proxmox-audit.sh — Proxmox VE Security Audit
#
# @elevation: root
# @elevation-reason: Proxmox API, pvesh, pct, and qm commands require root
#
# Compliance Mapping:
# - CIS Benchmark: Hypervisor Security
# - NIST SP 800-125: Virtualization Security
# - NIST SP 800-53: SC-3, SC-4, AC-4 (Isolation)
# - PCI DSS: 2.2.1 (Hypervisor Hardening)
#
# Checks:
# - Proxmox VE installation and version
# - Web interface security (pveproxy)
# - Cluster security
# - User/permission management
# - VM/container isolation
# - Firewall configuration
# - Backup encryption

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "Proxmox VE Installation"

# Check if Proxmox VE is installed
if ! command -v pvesh >/dev/null 2>&1; then
  register_check "Proxmox VE installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Proxmox VE installed" PASS "found"

# Get version
pve_version=$(pveversion 2>/dev/null | head -n1 || echo "unknown")
register_check "PVE version" PASS "$pve_version"

# Check for updates
if command -v apt >/dev/null 2>&1; then
  updates=$(apt list --upgradable 2>/dev/null | grep -c "pve-" || echo "0")
  if [[ "$updates" -eq 0 ]]; then
    register_check "PVE updates" PASS "up to date"
  else
    register_check "PVE updates" WARN "$updates packages"
  fi
fi

section "PVE Services Status"

# Check critical services
pve_services=(
  "pvedaemon"
  "pveproxy"
  "pvestatd"
  "pvescheduler"
)

for svc in "${pve_services[@]}"; do
  if systemctl is-active "$svc" >/dev/null 2>&1; then
    register_check "$svc service" PASS "running"
  else
    register_check "$svc service" FAIL "not running"
  fi
done

# Check spiceproxy if VMs use SPICE
if systemctl is-active spiceproxy >/dev/null 2>&1; then
  register_check "spiceproxy service" PASS "running"
fi

section "Web Interface Security (pveproxy)"

pveproxy_conf="/etc/default/pveproxy"
if [[ -f "$pveproxy_conf" ]]; then
  register_check "pveproxy config" PASS "exists"

  # Check for DENY_FROM / ALLOW_FROM
  if grep -qE "^DENY_FROM=" "$pveproxy_conf" 2>/dev/null; then
    register_check "IP deny list" PASS "configured"
  fi

  if grep -qE "^ALLOW_FROM=" "$pveproxy_conf" 2>/dev/null; then
    register_check "IP allow list" PASS "configured"
  else
    register_check "IP allow list" WARN "not set (all IPs allowed)"
  fi

  # Check for POLICY
  policy=$(grep -E "^POLICY=" "$pveproxy_conf" 2>/dev/null | cut -d= -f2)
  if [[ "$policy" == "deny" ]]; then
    register_check "Default policy" PASS "deny"
  else
    register_check "Default policy" WARN "${policy:-allow}"
  fi
fi

# Check TLS configuration
pveproxy_ssl="/etc/pve/local/pveproxy-ssl.pem"
if [[ -f "$pveproxy_ssl" ]]; then
  register_check "Custom SSL cert" PASS "configured"

  # Check expiry
  if command -v openssl >/dev/null 2>&1; then
    expiry=$(openssl x509 -in "$pveproxy_ssl" -noout -enddate 2>/dev/null | cut -d= -f2)
    if [[ -n "$expiry" ]]; then
      expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo "0")
      now_epoch=$(date +%s)
      days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

      if [[ "$days_left" -gt 30 ]]; then
        register_check "SSL cert expiry" PASS "${days_left} days"
      elif [[ "$days_left" -gt 0 ]]; then
        register_check "SSL cert expiry" WARN "${days_left} days"
      else
        register_check "SSL cert expiry" FAIL "expired"
      fi
    fi
  fi
else
  register_check "Custom SSL cert" WARN "using self-signed"
fi

section "Cluster Security"

# Check if clustered
if [[ -f "/etc/pve/corosync.conf" ]]; then
  register_check "Cluster mode" PASS "clustered"

  # Check cluster status
  if command -v pvecm >/dev/null 2>&1; then
    cluster_status=$(pvecm status 2>/dev/null | grep -E "Cluster|Quorum" | head -n2 || echo "")
    if echo "$cluster_status" | grep -q "Quorate:.*Yes"; then
      register_check "Cluster quorum" PASS "quorate"
    else
      register_check "Cluster quorum" WARN "check status"
    fi

    # Check node count
    node_count=$(pvecm nodes 2>/dev/null | grep -c "^[0-9]" || echo "1")
    register_check "Cluster nodes" PASS "$node_count nodes"
  fi

  # Check cluster encryption
  if grep -q "crypto_cipher:" /etc/pve/corosync.conf 2>/dev/null; then
    cipher=$(grep "crypto_cipher:" /etc/pve/corosync.conf | awk '{print $2}')
    register_check "Cluster encryption" PASS "$cipher"
  else
    register_check "Cluster encryption" WARN "not configured"
  fi

  # Check cluster hash
  if grep -q "crypto_hash:" /etc/pve/corosync.conf 2>/dev/null; then
    hash=$(grep "crypto_hash:" /etc/pve/corosync.conf | awk '{print $2}')
    register_check "Cluster hash" PASS "$hash"
  fi
else
  register_check "Cluster mode" PASS "standalone"
fi

section "Authentication & Users"

# Check authentication realms
if command -v pveum >/dev/null 2>&1; then
  # List realms
  realms=$(pveum realm list 2>/dev/null | tail -n +2 | awk '{print $1}' || echo "pam pve")
  realm_count=$(echo "$realms" | wc -w)
  register_check "Auth realms" PASS "$realm_count realms"

  # Check for LDAP/AD integration
  if echo "$realms" | grep -qE "ldap|ad"; then
    register_check "Directory auth" PASS "configured"
  fi

  # Check user count
  user_count=$(pveum user list 2>/dev/null | tail -n +2 | wc -l || echo "1")
  register_check "User accounts" PASS "$user_count users"

  # Check for root@pam only access
  root_only=$(pveum acl list 2>/dev/null | grep -c "root@pam" || echo "0")
  if [[ "$root_only" -gt 0 ]]; then
    register_check "ACL entries" PASS "configured"
  fi
fi

# Check two-factor auth
tfa_users=$(pveum user list 2>/dev/null | grep -c "totp\|u2f\|yubico" || echo "0")
if [[ "$tfa_users" -gt 0 ]]; then
  register_check "Two-factor auth" PASS "$tfa_users users"
else
  register_check "Two-factor auth" WARN "not configured"
fi

section "VM/Container Isolation"

# Count VMs and containers
vm_count=$(qm list 2>/dev/null | tail -n +2 | wc -l || echo "0")
ct_count=$(pct list 2>/dev/null | tail -n +2 | wc -l || echo "0")

register_check "Virtual machines" PASS "$vm_count VMs"
register_check "Containers (LXC)" PASS "$ct_count CTs"

# Check for unprivileged containers
if [[ "$ct_count" -gt 0 ]]; then
  priv_cts=$(for ctid in $(pct list 2>/dev/null | tail -n +2 | awk '{print $1}'); do
    pct config "$ctid" 2>/dev/null | grep -q "^unprivileged: 0" && echo "$ctid"
  done | wc -l || echo "0")

  if [[ "$priv_cts" -eq 0 ]]; then
    register_check "Unprivileged CTs" PASS "all unprivileged"
  else
    register_check "Unprivileged CTs" WARN "$priv_cts privileged"
  fi
fi

# Check AppArmor for containers
if [[ -d "/etc/apparmor.d/lxc" ]]; then
  register_check "LXC AppArmor" PASS "profiles exist"

  if aa-status 2>/dev/null | grep -q "lxc"; then
    register_check "LXC AppArmor active" PASS "yes"
  fi
fi

section "Storage Security"

# List storage
storages=$(pvesm status 2>/dev/null | tail -n +2 | awk '{print $1}' || echo "")
storage_count=$(echo "$storages" | wc -w)
register_check "Storage pools" PASS "$storage_count pools"

# Check for encrypted storage
for storage in $storages; do
  storage_type=$(pvesm status 2>/dev/null | grep "^$storage" | awk '{print $2}')
  if [[ "$storage_type" == "zfspool" ]]; then
    # Check ZFS encryption
    zfs_dataset=$(pvesm list "$storage" 2>/dev/null | grep "zfs" | head -n1 || echo "")
    if [[ -n "$zfs_dataset" ]] && zfs get -H encryption "$zfs_dataset" 2>/dev/null | grep -qv "off"; then
      register_check "Storage $storage" PASS "ZFS encrypted"
    fi
  fi
done

section "Firewall Configuration"

# Check PVE firewall status
if command -v pve-firewall >/dev/null 2>&1; then
  if pve-firewall status 2>/dev/null | grep -q "running"; then
    register_check "PVE firewall" PASS "running"
  else
    register_check "PVE firewall" WARN "not running"
  fi

  # Check cluster-level firewall
  if [[ -f "/etc/pve/firewall/cluster.fw" ]]; then
    if grep -q "enable: 1" /etc/pve/firewall/cluster.fw 2>/dev/null; then
      register_check "Cluster firewall" PASS "enabled"
    else
      register_check "Cluster firewall" WARN "disabled"
    fi
  fi

  # Check host-level firewall
  hostname=$(hostname)
  host_fw="/etc/pve/nodes/$hostname/host.fw"
  if [[ -f "$host_fw" ]]; then
    if grep -q "enable: 1" "$host_fw" 2>/dev/null; then
      register_check "Host firewall" PASS "enabled"
    else
      register_check "Host firewall" WARN "disabled"
    fi
  fi
fi

section "Backup Security"

# Check PBS (Proxmox Backup Server) integration
if pvesm status 2>/dev/null | grep -q "pbs"; then
  register_check "PBS storage" PASS "configured"
fi

# Check vzdump configuration
vzdump_conf="/etc/vzdump.conf"
if [[ -f "$vzdump_conf" ]]; then
  register_check "vzdump config" PASS "exists"

  # Check for encryption
  if grep -qE "^encrypt:" "$vzdump_conf" 2>/dev/null; then
    register_check "Backup encryption" PASS "configured"
  else
    register_check "Backup encryption" WARN "not set"
  fi

  # Check compression
  compress=$(grep -E "^compress:" "$vzdump_conf" 2>/dev/null | awk '{print $2}')
  if [[ -n "$compress" ]]; then
    register_check "Backup compression" PASS "$compress"
  fi
fi

# Check backup jobs
backup_jobs=$(pvesh get /cluster/backup 2>/dev/null | grep -c '"id"' || echo "0")
register_check "Scheduled backups" PASS "$backup_jobs jobs"

section "HA Configuration"

# Check HA status
if [[ -f "/etc/pve/ha/manager_status" ]]; then
  register_check "HA configured" PASS "yes"

  # Check fencing
  if [[ -f "/etc/pve/ha/fence.cfg" ]]; then
    register_check "HA fencing" PASS "configured"
  else
    register_check "HA fencing" WARN "not configured"
  fi

  # Check HA resources
  ha_resources=$(ha-manager status 2>/dev/null | grep -c "started\|stopped" || echo "0")
  register_check "HA resources" PASS "$ha_resources resources"
fi

section "Network Security"

# Check SDN configuration
if [[ -d "/etc/pve/sdn" ]]; then
  register_check "SDN configured" PASS "yes"
fi

# Check for VLANs
if grep -rq "vlan" /etc/network/interfaces 2>/dev/null; then
  vlan_count=$(grep -c "vlan" /etc/network/interfaces 2>/dev/null || echo "0")
  register_check "VLANs" PASS "$vlan_count configured"
fi

# Check bridge configuration
bridges=$(ip link show type bridge 2>/dev/null | grep -c "vmbr" || echo "0")
register_check "VM bridges" PASS "$bridges bridges"

section "SSH & Remote Access"

# Check SSH configuration for root
sshd_config="/etc/ssh/sshd_config"
if [[ -f "$sshd_config" ]]; then
  root_login=$(grep -E "^PermitRootLogin" "$sshd_config" 2>/dev/null | awk '{print $2}')
  if [[ "$root_login" == "prohibit-password" ]] || [[ "$root_login" == "without-password" ]]; then
    register_check "SSH root login" PASS "key-only"
  elif [[ "$root_login" == "no" ]]; then
    register_check "SSH root login" PASS "disabled"
  else
    register_check "SSH root login" WARN "${root_login:-yes}"
  fi
fi

section "Subscription Status"

# Check subscription
subscription=$(pvesubscription get 2>/dev/null | grep -E "^status:" | awk '{print $2}' || echo "unknown")
if [[ "$subscription" == "Active" ]]; then
  register_check "Subscription" PASS "active"
elif [[ "$subscription" == "NotFound" ]] || [[ "$subscription" == "Invalid" ]]; then
  register_check "Subscription" WARN "not active (no enterprise updates)"
else
  register_check "Subscription" WARN "$subscription"
fi

section "Advanced Security Controls"

# SPICE/VNC TLS enforcement
if [[ -f /etc/pve/datacenter.cfg ]]; then
  # Check VNC TLS
  vnc_tls=$(grep -E "^console:" /etc/pve/datacenter.cfg 2>/dev/null || echo "")
  if echo "$vnc_tls" | grep -qi "tls\|secure"; then
    register_check "Console TLS" PASS "TLS enforced"
  else
    register_check "Console TLS" WARN "TLS not enforced"
  fi

  # Check keyboard layout (security best practice)
  keyboard=$(grep -E "^keyboard:" /etc/pve/datacenter.cfg 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$keyboard" ]]; then
    register_check "Keyboard layout" PASS "$keyboard"
  fi
fi

# Check SPICE TLS certificate
if [[ -f /etc/pve/local/pve-ssl.pem ]] || [[ -f /etc/pve/pve-root-ca.pem ]]; then
  register_check "SPICE TLS certs" PASS "cluster certs available"
fi

# API Token permission scope audit
api_tokens=$(pvesh get /access/users --output-format=json 2>/dev/null | grep -o '"tokens":\[.*\]' | grep -c '"tokenid"' || echo "0")
if [[ "$api_tokens" -gt 0 ]]; then
  register_check "API tokens" WARN "$api_tokens token(s) - review permissions"
else
  register_check "API tokens" PASS "no API tokens"
fi

# Check for token privilege separation
if [[ -f /etc/pve/user.cfg ]]; then
  privsep_tokens=$(grep -c "privsep=1" /etc/pve/user.cfg 2>/dev/null || echo "0")
  if [[ "$privsep_tokens" -gt 0 ]]; then
    register_check "Token privilege separation" PASS "$privsep_tokens token(s) with privsep"
  fi
fi

# Corosync encryption strength validation
if [[ -f /etc/corosync/corosync.conf ]]; then
  corosync_crypto=$(grep -E "^\s*crypto_cipher:" /etc/corosync/corosync.conf 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$corosync_crypto" == "aes256" ]] || [[ "$corosync_crypto" == "aes128" ]]; then
    register_check "Corosync cipher" PASS "$corosync_crypto"
  elif [[ -n "$corosync_crypto" ]]; then
    register_check "Corosync cipher" WARN "$corosync_crypto (recommend aes256)"
  fi

  corosync_hash=$(grep -E "^\s*crypto_hash:" /etc/corosync/corosync.conf 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$corosync_hash" == "sha256" ]] || [[ "$corosync_hash" == "sha384" ]] || [[ "$corosync_hash" == "sha512" ]]; then
    register_check "Corosync hash" PASS "$corosync_hash"
  elif [[ -n "$corosync_hash" ]]; then
    register_check "Corosync hash" WARN "$corosync_hash (recommend sha256+)"
  fi
fi

# ZFS encryption check (if ZFS storage is used)
if command -v zfs >/dev/null 2>&1; then
  zfs_pools=$(zpool list -H -o name 2>/dev/null || echo "")
  for pool in $zfs_pools; do
    encryption=$(zfs get -H -o value encryption "$pool" 2>/dev/null | head -1 || echo "off")
    if [[ "$encryption" != "off" ]]; then
      register_check "ZFS $pool encryption" PASS "$encryption"
    else
      register_check "ZFS $pool encryption" WARN "not encrypted"
    fi
  done
fi

# Ceph encryption check (if Ceph storage is used)
if command -v ceph >/dev/null 2>&1 && [[ -f /etc/ceph/ceph.conf ]]; then
  ceph_encryption=$(grep -E "^\s*ms_cluster_mode" /etc/ceph/ceph.conf 2>/dev/null | awk '{print $3}' || echo "")
  if echo "$ceph_encryption" | grep -qi "secure"; then
    register_check "Ceph cluster encryption" PASS "secure mode"
  else
    register_check "Ceph cluster encryption" WARN "verify encryption settings"
  fi

  # Check Ceph auth
  ceph_auth=$(grep -E "^\s*auth_cluster_required" /etc/ceph/ceph.conf 2>/dev/null | awk '{print $3}' || echo "")
  if [[ "$ceph_auth" == "cephx" ]]; then
    register_check "Ceph auth" PASS "cephx authentication"
  elif [[ -n "$ceph_auth" ]]; then
    register_check "Ceph auth" WARN "$ceph_auth (recommend cephx)"
  fi
fi

# PVE security updates check
if command -v pveversion >/dev/null 2>&1; then
  pve_version=$(pveversion --verbose 2>/dev/null | grep "^pve-manager" | awk '{print $2}' || echo "")
  if [[ -n "$pve_version" ]]; then
    register_check "PVE version" PASS "$pve_version"
  fi
fi

# Check for pending updates
if command -v apt >/dev/null 2>&1; then
  security_updates=$(apt list --upgradable 2>/dev/null | grep -ci "security" || echo "0")
  if [[ "$security_updates" -gt 0 ]]; then
    register_check "Security updates" WARN "$security_updates pending"
  else
    register_check "Security updates" PASS "up to date"
  fi
fi

# Check QEMU version for security patches
if command -v qemu-system-x86_64 >/dev/null 2>&1; then
  qemu_version=$(qemu-system-x86_64 --version 2>/dev/null | head -1 | awk '{print $4}' || echo "")
  if [[ -n "$qemu_version" ]]; then
    register_check "QEMU version" PASS "$qemu_version"
  fi
fi

print_summary
exit "$EXIT_CODE"
