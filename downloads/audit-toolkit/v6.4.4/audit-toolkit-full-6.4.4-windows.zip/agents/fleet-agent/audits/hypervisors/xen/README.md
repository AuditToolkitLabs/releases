# XenServer / XCP-ng Security Audits

Security audits for Citrix XenServer and XCP-ng hypervisor platforms.

## Execution Methods

1. **Local** - Run directly on dom0 (control domain)
2. **Remote SSH** - Execute via SSH
3. **XAPI** - XenAPI calls via xe CLI or SDK

## Planned Audits

### xen-baseline-audit.sh
Core Xen hardening:
- [ ] XenServer/XCP-ng version
- [ ] Xen hypervisor version
- [ ] dom0 kernel hardening
- [ ] SSH configuration
- [ ] XAPI SSL/TLS settings
- [ ] Password complexity policy
- [ ] Account lockout settings
- [ ] NTP configuration
- [ ] Syslog forwarding

### xen-pool-audit.sh
Pool and cluster security:
- [ ] Pool master authentication
- [ ] Pool join restrictions
- [ ] HA configuration
- [ ] Workload balancing security
- [ ] License server connection
- [ ] Backup metadata

### xen-network-audit.sh
Network configuration:
- [ ] Network backend (bridge/openvswitch)
- [ ] VLAN configuration
- [ ] Bond security
- [ ] Management network isolation
- [ ] PIF security settings
- [ ] VIF permissions

### xen-storage-audit.sh
Storage repository security:
- [ ] SR authentication (iSCSI CHAP, NFS Kerberos)
- [ ] Thin provisioning settings
- [ ] VDI encryption
- [ ] GFS2/DRBD configuration (if applicable)
- [ ] Storage multipath

### xen-vm-audit.sh
Virtual machine security:
- [ ] HVM vs PV vs PVH mode
- [ ] Secure Boot (HVM)
- [ ] vTPM configuration
- [ ] Guest agent installed
- [ ] Resource limits (CPU/memory caps)
- [ ] XSM (Xen Security Modules) policy

### xen-patch-audit.sh
Updates and patches:
- [ ] Hotfix inventory
- [ ] Pending updates
- [ ] Repository configuration
- [ ] Driver versions

## Key Commands Reference

```bash
# System info
xe host-list
xe host-param-list uuid=<host-uuid>
cat /etc/xensource-inventory

# Pool
xe pool-list
xe pool-param-list uuid=<pool-uuid>

# VMs
xe vm-list
xe vm-param-list uuid=<vm-uuid>

# Network
xe network-list
xe pif-list
xe vif-list

# Storage
xe sr-list
xe vdi-list

# Patches (XenServer)
xe patch-list
xe update-list

# XCP-ng updates
yum check-update
```

## CIS/STIG References

- Citrix XenServer STIG
- CIS Citrix XenServer Benchmark (if available)

## Implementation Notes

- XCP-ng is the open-source fork of XenServer
- Most commands work on both platforms
- XAPI is primary management interface
- dom0 is a privileged Linux VM (CentOS-based)

---
**Document Version:** 1.0  
**Created:** March 2026
