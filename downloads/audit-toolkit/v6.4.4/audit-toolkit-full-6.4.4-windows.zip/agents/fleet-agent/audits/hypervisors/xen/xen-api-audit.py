#!/usr/bin/env python3
"""
XCP-ng / Citrix Hypervisor Security Audit via XAPI

Cross-platform Xen audit using XAPI (XML-RPC).
Runs on Windows, Linux, or macOS with Python 3.8+.
Does NOT require SSH access - uses XAPI for authentication.

Compliance Mapping:
- CIS Benchmark: Citrix XenServer
- NIST SP 800-125: Virtualization Security
- NIST SP 800-53: AC-2, AC-6, AU-2, SC-8
- PCI DSS: 2.2.1, 8.1, 10.1

Usage:
    # Basic usage
    python xen-api-audit.py --server xcp.example.com --username root

    # Pool master address
    python xen-api-audit.py --server 192.168.1.100 --username root --password <pass>

Requirements:
    Python 3.8+ (uses built-in xmlrpc.client)

XAPI Documentation: https://xapi-project.github.io/
"""

import argparse
import json
import ssl
import sys
import xmlrpc.client  # nosec B411 - Xen XAPI requires XML-RPC protocol
from datetime import datetime
from getpass import getpass
from typing import Any, Dict, List, Optional


class AuditResults:
    """Track audit results"""

    def __init__(self):
        self.checks: List[Dict[str, str]] = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0

    def register(self, name: str, status: str, message: str = "") -> None:
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"

        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))

        self.checks.append({"name": name, "status": status, "message": message})

        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1

    def section(self, title: str) -> None:
        """Print section header"""
        print(f"\n\033[96m=== {title} ===\033[0m\n")

    def summary(self) -> None:
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")

    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "timestamp": datetime.now().isoformat(),
            "checks": self.checks,
            "summary": {
                "total": len(self.checks),
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class XenAudit:
    """XCP-ng / Citrix Hypervisor XAPI Audit Client"""

    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = True):
        self.server = server
        self.results = AuditResults()
        self.session = None
        self.api = None
        self.hosts: Dict[str, Dict] = {}
        self.pool: Dict[str, Any] = {}

        # Create SSL context
        if verify_ssl:
            context = ssl.create_default_context()
        else:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

        # Connect to XAPI
        url = f"https://{server}"
        self.api = xmlrpc.client.ServerProxy(url, context=context)

        # Authenticate
        try:
            self.session = self.api.session.login_with_password(username, password, "1.0", "audit-tool")
            self.results.register("XAPI Authentication", "PASS", f"Connected as {username}")
        except Exception as e:
            self.results.register("XAPI Authentication", "FAIL", str(e))
            raise SystemExit(1)

    def _call(self, method: str, *args) -> Any:
        """Execute XAPI method with session"""
        try:
            parts = method.split(".")
            obj = self.api
            for part in parts:
                obj = getattr(obj, part)
            result = obj(self.session, *args)
            if isinstance(result, dict) and result.get("Status") == "Success":
                return result.get("Value")
            elif isinstance(result, dict) and result.get("Status") == "Failure":
                return None
            return result
        except Exception:
            return None

    def audit_pool_info(self) -> None:
        """Audit pool information"""
        self.results.section("Pool Information")

        # Get pool info
        pools = self._call("pool.get_all")
        if pools:
            pool_ref = pools[0]  # Only one pool per XAPI
            self.pool = self._call("pool.get_record", pool_ref) or {}

            pool_name = self.pool.get("name_label", "unnamed")
            self.results.register("Pool Name", "PASS", pool_name)

            # Check pool-wide settings
            ha_enabled = self.pool.get("ha_enabled", False)
            if ha_enabled:
                self.results.register("Pool HA", "PASS", "Enabled")
            else:
                self.results.register("Pool HA", "WARN", "Disabled")

        # Get hosts
        host_refs = self._call("host.get_all") or []
        for host_ref in host_refs:
            record = self._call("host.get_record", host_ref)
            if record:
                self.hosts[host_ref] = record

        self.results.register("Hosts in Pool", "PASS", f"{len(self.hosts)} host(s)")

    def audit_hosts(self) -> None:
        """Audit host configuration"""
        self.results.section("Host Security")

        for host_ref, host in self.hosts.items():
            name = host.get("name_label", "unknown")

            # Check enabled status
            enabled = host.get("enabled", False)
            if enabled:
                self.results.register(f"{name} Status", "PASS", "Enabled")
            else:
                self.results.register(f"{name} Status", "WARN", "Disabled")

            # Get software version
            sw_version = host.get("software_version", {})
            product_brand = sw_version.get("product_brand", "Unknown")
            product_version = sw_version.get("product_version", "Unknown")
            self.results.register(f"{name} Version", "PASS", f"{product_brand} {product_version}")

            # Check patches/updates
            patches = host.get("patches", [])
            if patches:
                self.results.register(f"{name} Patches", "PASS", f"{len(patches)} installed")
            else:
                self.results.register(f"{name} Patches", "WARN", "No patches listed")

    def audit_authentication(self) -> None:
        """Audit authentication settings"""
        self.results.section("Authentication Security")

        # Check external auth
        for host_ref, host in self.hosts.items():
            name = host.get("name_label", "unknown")

            ext_auth_type = host.get("external_auth_type", "")
            ext_auth_svc = host.get("external_auth_service_name", "")

            if ext_auth_type:
                self.results.register(f"{name} External Auth", "PASS", f"{ext_auth_type}: {ext_auth_svc}")
            else:
                self.results.register(f"{name} External Auth", "WARN", "Local auth only")

    def audit_network(self) -> None:
        """Audit network configuration"""
        self.results.section("Network Security")

        # Get networks
        network_refs = self._call("network.get_all") or []

        networks = []
        for net_ref in network_refs:
            record = self._call("network.get_record", net_ref)
            if record:
                networks.append(record)

        self.results.register("Networks", "PASS", f"{len(networks)} network(s)")

        # Check for management network
        mgmt_network = None
        for net in networks:
            other_config = net.get("other_config", {})
            if other_config.get("is_host_internal_management_network") == "true":
                mgmt_network = net.get("name_label", "unnamed")
                break

        if mgmt_network:
            self.results.register("Management Network", "PASS", mgmt_network)

        # Check VLANs
        vlan_refs = self._call("VLAN.get_all") or []
        self.results.register("VLANs", "PASS", f"{len(vlan_refs)} VLAN(s)")

        # Check bonds
        bond_refs = self._call("Bond.get_all") or []
        if bond_refs:
            self.results.register("Bonds", "PASS", f"{len(bond_refs)} bond(s)")
        else:
            self.results.register("Bonds", "WARN", "No network bonding")

    def audit_storage(self) -> None:
        """Audit storage configuration"""
        self.results.section("Storage Security")

        # Get Storage Repositories (SRs)
        sr_refs = self._call("SR.get_all") or []

        srs = []
        for sr_ref in sr_refs:
            record = self._call("SR.get_record", sr_ref)
            if record:
                srs.append(record)

        self.results.register("Storage Repositories", "PASS", f"{len(srs)} SR(s)")

        # Check for shared storage
        shared_srs = [sr for sr in srs if sr.get("shared", False)]
        if shared_srs:
            self.results.register("Shared Storage", "PASS", f"{len(shared_srs)} shared SR(s)")
        else:
            self.results.register("Shared Storage", "WARN", "No shared storage (HA limited)")

        # Check SR types
        sr_types = set(sr.get("type", "") for sr in srs)
        self.results.register("SR Types", "PASS", ", ".join(sr_types))

    def audit_vms(self) -> None:
        """Audit VM configuration"""
        self.results.section("VM Security")

        # Get VMs
        vm_refs = self._call("VM.get_all") or []

        vms = []
        for vm_ref in vm_refs:
            record = self._call("VM.get_record", vm_ref)
            if record and not record.get("is_control_domain") and not record.get("is_a_template"):
                vms.append(record)

        self.results.register("VMs", "PASS", f"{len(vms)} VM(s)")

        # Check for running VMs
        running = [vm for vm in vms if vm.get("power_state") == "Running"]
        self.results.register("Running VMs", "PASS", f"{len(running)} running")

        # Check for VMs with HA restart priority
        ha_protected = [vm for vm in vms if vm.get("ha_restart_priority") not in ["", "best-effort", None]]
        if ha_protected:
            self.results.register("HA Protected VMs", "PASS", f"{len(ha_protected)} VM(s)")

    def audit_dom0(self) -> None:
        """Audit Dom0 (control domain) configuration"""
        self.results.section("Dom0 Security")

        for host_ref, host in self.hosts.items():
            name = host.get("name_label", "unknown")

            # Get metrics
            metrics_ref = host.get("metrics")
            if metrics_ref:
                metrics = self._call("host_metrics.get_record", metrics_ref)
                if metrics:
                    memory_total = int(metrics.get("memory_total", 0)) / (1024**3)
                    memory_free = int(metrics.get("memory_free", 0)) / (1024**3)
                    self.results.register(f"{name} Memory", "PASS",
                                          f"{memory_total:.1f}GB total, {memory_free:.1f}GB free")

            # Check Dom0 memory allocation
            control_domain = host.get("control_domain")
            if control_domain:
                cd_record = self._call("VM.get_record", control_domain)
                if cd_record:
                    dom0_mem = int(cd_record.get("memory_target", 0)) / (1024**3)
                    if dom0_mem >= 4:
                        self.results.register(f"{name} Dom0 Memory", "PASS", f"{dom0_mem:.1f}GB")
                    else:
                        self.results.register(f"{name} Dom0 Memory", "WARN",
                                              f"{dom0_mem:.1f}GB (recommend 4GB+)")

    def audit_xapi_config(self) -> None:
        """Audit XAPI configuration"""
        self.results.section("XAPI Configuration")

        for host_ref, host in self.hosts.items():
            name = host.get("name_label", "unknown")

            # Check logging
            logging = host.get("logging", {})
            syslog_dest = logging.get("syslog_destination", "")
            if syslog_dest:
                self.results.register(f"{name} Syslog", "PASS", f"Forwarding to {syslog_dest}")
            else:
                self.results.register(f"{name} Syslog", "WARN", "Not forwarding (configure remote)")

            # Check other_config for security settings
            other_config = host.get("other_config", {})

            # Check for multipathing
            multipathing = other_config.get("multipathing") == "true"
            if multipathing:
                self.results.register(f"{name} Multipathing", "PASS", "Enabled")

    def audit_certificates(self) -> None:
        """Audit SSL/TLS certificates"""
        self.results.section("Certificate Security")

        # Get certificates
        try:
            cert_refs = self._call("Certificate.get_all") or []
            if cert_refs:
                for cert_ref in cert_refs:
                    record = self._call("Certificate.get_record", cert_ref)
                    if record:
                        name = record.get("name", "unnamed")
                        cert_type = record.get("type", "unknown")
                        self.results.register(f"Certificate {name}", "PASS", cert_type)
        except Exception:
            self.results.register("Certificates", "SKIP", "API not available")

    def audit_updates(self) -> None:
        """Audit update status"""
        self.results.section("Updates & Patches")

        # Get pool patches
        try:
            patch_refs = self._call("pool_patch.get_all") or []
            if patch_refs:
                self.results.register("Pool Patches", "PASS", f"{len(patch_refs)} applied")
            else:
                self.results.register("Pool Patches", "WARN", "Check for updates")
        except Exception:
            # XCP-ng uses pool_update instead
            try:
                update_refs = self._call("pool_update.get_all") or []
                if update_refs:
                    self.results.register("Pool Updates", "PASS", f"{len(update_refs)} applied")
            except Exception:
                self.results.register("Updates", "SKIP", "Update API not available")

    def audit_ha(self) -> None:
        """Audit High Availability configuration"""
        self.results.section("High Availability")

        if not self.pool:
            self.results.register("Pool HA", "SKIP", "No pool info")
            return

        ha_enabled = self.pool.get("ha_enabled", False)

        if ha_enabled:
            self.results.register("HA Status", "PASS", "Enabled")

            # Check HA configuration
            ha_plan_exists = self.pool.get("ha_plan_exists_for", 0)
            self.results.register("HA Failover Capacity", "PASS", f"{ha_plan_exists} host failures")

            # Check heartbeat SRs
            ha_heartbeat_srs = self.pool.get("ha_statefiles", [])
            if ha_heartbeat_srs:
                self.results.register("HA Statefiles", "PASS", f"{len(ha_heartbeat_srs)} statefile(s)")
        else:
            self.results.register("HA Status", "WARN", "Disabled (consider for production)")

    def close(self) -> None:
        """Close XAPI session"""
        if self.session:
            try:
                self.api.session.logout(self.session)
            except Exception:
                pass

    def run_full_audit(self) -> None:
        """Run complete security audit"""
        print(f"\033[96m{'='*60}\033[0m")
        print(f"\033[96mXCP-ng / Citrix Hypervisor Security Audit via XAPI\033[0m")
        print(f"\033[96mTarget: {self.server}\033[0m")
        print(f"\033[96mTime: {datetime.now().isoformat()}\033[0m")
        print(f"\033[96m{'='*60}\033[0m")

        try:
            self.audit_pool_info()
            self.audit_hosts()
            self.audit_authentication()
            self.audit_network()
            self.audit_storage()
            self.audit_vms()
            self.audit_dom0()
            self.audit_xapi_config()
            self.audit_certificates()
            self.audit_updates()
            self.audit_ha()
        finally:
            self.close()

        self.results.summary()


def main():
    parser = argparse.ArgumentParser(
        description="XCP-ng / Citrix Hypervisor Security Audit via XAPI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Basic usage
    %(prog)s --server xcp.example.com --username root

    # With password on command line
    %(prog)s --server 192.168.1.100 --username root --password <pass>

    # Skip SSL verification (self-signed certs)
    %(prog)s --server xcp.example.com --username root --insecure

    # JSON output
    %(prog)s --server xcp.example.com --username root --output results.json
        """
    )
    parser.add_argument("--server", "-s", required=True, help="XCP-ng/XenServer hostname or IP")
    parser.add_argument("--username", "-u", required=True, help="Username (e.g., root)")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--output", "-o", help="Output JSON results to file")

    args = parser.parse_args()

    # Get password
    password = args.password or getpass("Password: ")

    # Run audit
    try:
        audit = XenAudit(
            server=args.server,
            username=args.username,
            password=password,
            verify_ssl=not args.insecure
        )
        audit.run_full_audit()

        # Output JSON if requested
        if args.output:
            with open(args.output, "w") as f:
                f.write(audit.results.to_json())
            print(f"\nResults saved to: {args.output}")

        # Exit with appropriate code
        sys.exit(1 if audit.results.failed > 0 else 0)

    except KeyboardInterrupt:
        print("\nAudit cancelled.")
        sys.exit(130)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
