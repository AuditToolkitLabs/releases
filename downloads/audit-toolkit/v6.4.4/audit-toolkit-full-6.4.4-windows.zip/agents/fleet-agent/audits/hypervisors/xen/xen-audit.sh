#!/usr/bin/env bash
# xen-audit.sh — Xen Hypervisor Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: Hypervisor Security
# - NIST SP 800-125: Virtualization Security
# - NIST SP 800-53: SC-3, SC-4, AC-4 (Isolation)
# - Xen Security Advisory recommendations
#
# Checks:
# - Xen installation and version
# - Dom0 security configuration
# - XSM (Xen Security Modules)
# - Guest isolation
# - Memory and CPU isolation
# - Network security
# - Stubdom usage

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "Xen Hypervisor Detection"

# Check if Xen is installed
xen_cmd=""
if command -v xl >/dev/null 2>&1; then
  xen_cmd="xl"
elif command -v xm >/dev/null 2>&1; then
  xen_cmd="xm"
fi

# Check for Xen kernel
xen_kernel=false
if [[ -d "/proc/xen" ]] || dmesg 2>/dev/null | grep -qi "xen"; then
  xen_kernel=true
fi

if [[ -z "$xen_cmd" ]] && [[ "$xen_kernel" != "true" ]]; then
  register_check "Xen hypervisor" SKIP "not detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Xen hypervisor" PASS "detected"

# Determine toolstack
if [[ "$xen_cmd" == "xl" ]]; then
  register_check "Toolstack" PASS "xl (libxl)"
elif [[ "$xen_cmd" == "xm" ]]; then
  register_check "Toolstack" WARN "xm (deprecated)"
fi

# Get Xen version
if [[ -n "$xen_cmd" ]]; then
  xen_version=$($xen_cmd info 2>/dev/null | grep -E "^xen_version" | awk -F: '{print $2}' | tr -d ' ' || echo "unknown")
  register_check "Xen version" PASS "$xen_version"

  # Check for xen-changeset (build info)
  xen_changeset=$($xen_cmd info 2>/dev/null | grep -E "^xen_changeset" | awk -F: '{print $2}' | tr -d ' ' || echo "")
  if [[ -n "$xen_changeset" ]]; then
    register_check "Xen build" PASS "$xen_changeset"
  fi
fi

section "Dom0 Security"

# Check if we're in Dom0
if [[ -f "/proc/xen/capabilities" ]]; then
  capabilities=$(cat /proc/xen/capabilities 2>/dev/null || echo "")
  if echo "$capabilities" | grep -q "control_d"; then
    register_check "Running in Dom0" PASS "control domain"
  else
    register_check "Running in DomU" PASS "guest domain"
  fi
fi

# Check Dom0 memory allocation
if [[ -n "$xen_cmd" ]]; then
  dom0_mem=$($xen_cmd info 2>/dev/null | grep -E "^free_memory" | awk -F: '{print $2}' | tr -d ' ' || echo "0")
  register_check "Free memory" PASS "${dom0_mem}MB"

  # Check Dom0 CPU count
  dom0_vcpus=$($xen_cmd info 2>/dev/null | grep -E "^nr_cpus" | awk -F: '{print $2}' | tr -d ' ' || echo "0")
  register_check "Available CPUs" PASS "$dom0_vcpus"
fi

# Check for Dom0 memory cap
grub_conf="/etc/default/grub"
if [[ -f "$grub_conf" ]]; then
  dom0_mem_cap=$(grep -E "dom0_mem=" "$grub_conf" 2>/dev/null || echo "")
  if [[ -n "$dom0_mem_cap" ]]; then
    register_check "Dom0 memory cap" PASS "configured"
  else
    register_check "Dom0 memory cap" WARN "not set (can consume all RAM)"
  fi
fi

section "XSM (Xen Security Modules)"

# Check for XSM/Flask
xsm_enabled=false
if [[ -n "$xen_cmd" ]]; then
  xsm_status=$($xen_cmd info 2>/dev/null | grep -E "^xsm" | awk -F: '{print $2}' | tr -d ' ' || echo "")

  if [[ "$xsm_status" == "flask" ]]; then
    register_check "XSM framework" PASS "Flask enabled"
    xsm_enabled=true
  elif [[ "$xsm_status" == "dummy" ]]; then
    register_check "XSM framework" WARN "dummy (no enforcement)"
  else
    register_check "XSM framework" WARN "${xsm_status:-not detected}"
  fi
fi

# Check Flask policy if enabled
if [[ "$xsm_enabled" == "true" ]]; then
  if [[ -f "/etc/xen/flask/policy.bin" ]] || [[ -f "/boot/xenpolicy" ]]; then
    register_check "XSM policy" PASS "loaded"
  else
    register_check "XSM policy" WARN "not found"
  fi
fi

section "Guest Domain Isolation"

if [[ -n "$xen_cmd" ]]; then
  # List running domains
  dom_count=$($xen_cmd list 2>/dev/null | tail -n +2 | wc -l || echo "0")
  register_check "Running domains" PASS "$dom_count"

  # Check domain types
  for dom_type in "PV" "HVM" "PVH"; do
    type_count=$($xen_cmd list 2>/dev/null | grep -c "$dom_type" || echo "0")
    if [[ "$type_count" -gt 0 ]]; then
      register_check "$dom_type domains" PASS "$type_count"
    fi
  done
fi

# Check for PV driver usage in HVM (more secure than full emulation)
if [[ -n "$xen_cmd" ]]; then
  hvm_doms=$($xen_cmd list 2>/dev/null | grep "HVM" | awk '{print $1}' || echo "")
  for dom in $hvm_doms; do
    if [[ "$dom" == "Domain-0" ]]; then continue; fi

    # Check for PV drivers
    pv_drivers=$($xen_cmd list -l "$dom" 2>/dev/null | grep -E "xen_platform_pci|viridian" || echo "")
    if [[ -n "$pv_drivers" ]]; then
      register_check "HVM $dom PV drivers" PASS "using PV optimization"
    fi
  done
fi

section "Stubdom Configuration"

# Check for device model stubdoms (improves isolation)
if [[ -n "$xen_cmd" ]]; then
  stubdom_count=$($xen_cmd list 2>/dev/null | grep -c "stubdom" || echo "0")

  if [[ "$stubdom_count" -gt 0 ]]; then
    register_check "Stubdoms in use" PASS "$stubdom_count"
  else
    register_check "Stubdoms" WARN "not detected"
  fi

  # Check default device model
  qemu_dm=$(ls -la /usr/lib*/xen*/bin/qemu-* 2>/dev/null | head -n1 || echo "")
  if [[ -n "$qemu_dm" ]]; then
    register_check "Device model" PASS "QEMU available"
  fi
fi

section "Memory Security"

if [[ -n "$xen_cmd" ]]; then
  # Check for IOMMU
  iommu=$($xen_cmd info 2>/dev/null | grep -E "^virt_caps" | grep -o "hvm_directio" || echo "")
  if [[ -n "$iommu" ]]; then
    register_check "IOMMU/VT-d" PASS "enabled"
  else
    register_check "IOMMU/VT-d" WARN "not detected"
  fi

  # Check for HAP (Hardware Assisted Paging)
  hap=$($xen_cmd info 2>/dev/null | grep -E "^virt_caps" | grep -o "hvm" || echo "")
  if [[ -n "$hap" ]]; then
    register_check "HAP support" PASS "available"
  fi

  # Check for memory ballooning
  balloon_driver=$(lsmod 2>/dev/null | grep -c "xen_balloon" || echo "0")
  if [[ "$balloon_driver" -gt 0 ]]; then
    register_check "Memory ballooning" PASS "driver loaded"
  fi
fi

section "CPU Security"

if [[ -n "$xen_cmd" ]]; then
  # Check for CPU pinning capability
  cpu_pools=$($xen_cmd cpupool-list 2>/dev/null | tail -n +2 | wc -l || echo "1")
  register_check "CPU pools" PASS "$cpu_pools"

  # Check scheduler
  sched_name=$($xen_cmd info 2>/dev/null | grep -E "^xen_scheduler" | awk -F: '{print $2}' | tr -d ' ' || echo "credit2")
  register_check "Scheduler" PASS "$sched_name"
fi

# Check for CPU microcode
if dmesg 2>/dev/null | grep -qi "microcode"; then
  register_check "CPU microcode" PASS "loaded"
else
  register_check "CPU microcode" WARN "not detected"
fi

# Check for speculative execution mitigations
if [[ -f "/sys/devices/system/cpu/vulnerabilities/spectre_v2" ]]; then
  spectre=$(cat /sys/devices/system/cpu/vulnerabilities/spectre_v2 2>/dev/null | head -c 50)
  if echo "$spectre" | grep -qi "mitigated\|not affected"; then
    register_check "Spectre v2" PASS "mitigated"
  else
    register_check "Spectre v2" WARN "$spectre"
  fi
fi

section "Network Security"

# Check for network backend
if lsmod 2>/dev/null | grep -q "xen_netback"; then
  register_check "Network backend" PASS "xen-netback loaded"
fi

# Check bridge configuration
bridges=$(brctl show 2>/dev/null | grep -E "^xenbr|^virbr" | awk '{print $1}' || echo "")
if [[ -n "$bridges" ]]; then
  bridge_count=$(echo "$bridges" | wc -w)
  register_check "Xen bridges" PASS "$bridge_count configured"

  # Check for STP on bridges
  for br in $bridges; do
    stp=$(brctl showstp "$br" 2>/dev/null | grep -c "enabled" || echo "0")
    if [[ "$stp" -gt 0 ]]; then
      register_check "Bridge $br STP" PASS "enabled"
    else
      register_check "Bridge $br STP" WARN "disabled"
    fi
  done
fi

# Check for SR-IOV
sriov_vfs=$(find /sys/devices -name "sriov_numvfs" 2>/dev/null | head -n5)
if [[ -n "$sriov_vfs" ]]; then
  register_check "SR-IOV" PASS "available"
fi

section "Storage Security"

# Check block backend
if lsmod 2>/dev/null | grep -q "xen_blkback"; then
  register_check "Block backend" PASS "xen-blkback loaded"
fi

# Check for disk encryption awareness
dm_crypt=$(lsmod 2>/dev/null | grep -c "dm_crypt" || echo "0")
if [[ "$dm_crypt" -gt 0 ]]; then
  register_check "DM-Crypt available" PASS "yes"
fi

# Check storage paths
xen_storage="/var/lib/xen"
if [[ -d "$xen_storage" ]]; then
  storage_perms=$(stat -c "%a" "$xen_storage" 2>/dev/null || echo "unknown")
  if [[ "$storage_perms" == "700" ]] || [[ "$storage_perms" == "750" ]]; then
    register_check "Xen storage perms" PASS "$storage_perms"
  else
    register_check "Xen storage perms" WARN "$storage_perms"
  fi
fi

section "Xen Services"

# Check xencommons service
if is_systemd; then
  if systemctl is-active xen.service >/dev/null 2>&1 || systemctl is-active xencommons.service >/dev/null 2>&1; then
    register_check "Xen service" PASS "running"
  else
    register_check "Xen service" WARN "not running"
  fi

  # Check xenstored
  if systemctl is-active xenstored.service >/dev/null 2>&1; then
    register_check "Xenstored" PASS "running"
  fi

  # Check xenconsoled
  if systemctl is-active xenconsoled.service >/dev/null 2>&1; then
    register_check "Xenconsoled" PASS "running"
  fi
elif is_openrc; then
  if rc-service xencommons status >/dev/null 2>&1; then
    register_check "Xen service" PASS "running"
  else
    register_check "Xen service" WARN "check status"
  fi
fi

section "Configuration Security"

# Check Xen configuration directory
xen_conf="/etc/xen"
if [[ -d "$xen_conf" ]]; then
  conf_perms=$(stat -c "%a" "$xen_conf" 2>/dev/null || echo "unknown")
  if [[ "$conf_perms" == "755" ]] || [[ "$conf_perms" == "750" ]]; then
    register_check "Xen config dir" PASS "$conf_perms"
  else
    register_check "Xen config dir" WARN "$conf_perms"
  fi

  # Count domain configs
  dom_configs=$(find "$xen_conf" -name "*.cfg" -o -name "*.xl" 2>/dev/null | wc -l || echo "0")
  register_check "Domain configs" PASS "$dom_configs files"
fi

# Check xend-config (legacy) or xl.conf
if [[ -f "/etc/xen/xl.conf" ]]; then
  register_check "xl.conf" PASS "exists"

  # Check for autoballoon
  autoballoon=$(grep -E "^autoballoon" /etc/xen/xl.conf 2>/dev/null | awk -F'=' '{print $2}' | tr -d ' "' || echo "")
  if [[ "$autoballoon" == "off" ]] || [[ "$autoballoon" == "0" ]]; then
    register_check "Autoballoon" PASS "disabled"
  else
    register_check "Autoballoon" WARN "enabled"
  fi
fi

section "Logging & Monitoring"

# Check Xen logs
xen_log="/var/log/xen"
if [[ -d "$xen_log" ]]; then
  register_check "Xen log dir" PASS "exists"

  log_perms=$(stat -c "%a" "$xen_log" 2>/dev/null || echo "unknown")
  if [[ "$log_perms" == "755" ]] || [[ "$log_perms" == "750" ]]; then
    register_check "Log dir perms" PASS "$log_perms"
  else
    register_check "Log dir perms" WARN "$log_perms"
  fi
fi

# Check for QEMU logs
qemu_log="/var/log/xen/qemu-dm.log"
if [[ -f "$qemu_log" ]]; then
  register_check "QEMU logs" PASS "available"
fi

section "Security Advisories"

# Check Xen version against known vulnerabilities
if [[ -n "$xen_version" ]]; then
  major_ver=$(echo "$xen_version" | cut -d. -f1)
  minor_ver=$(echo "$xen_version" | cut -d. -f2)

  # Check for known EOL versions
  if [[ "$major_ver" -lt 4 ]]; then
    register_check "Version support" FAIL "EOL version"
  elif [[ "$major_ver" -eq 4 ]] && [[ "$minor_ver" -lt 14 ]]; then
    register_check "Version support" WARN "check for XSAs"
  else
    register_check "Version support" PASS "recent version"
  fi
fi

# Check for XSA patches (best effort)
if dmesg 2>/dev/null | grep -qi "xsa\|xen.*security"; then
  register_check "XSA patches" PASS "applied"
fi

section "Advanced Security Controls"

# XSA patch level verification
if [[ -n "$xen_cmd" ]]; then
  # Check for specific XSA mitigations
  xen_dmesg=$($xen_cmd dmesg 2>/dev/null || dmesg 2>/dev/null)

  # Check Spectre mitigations
  if echo "$xen_dmesg" | grep -qi "IBRS\|IBPB\|STIBP"; then
    register_check "Spectre mitigations" PASS "hardware mitigations active"
  fi

  # Check L1TF/MDS mitigations
  if echo "$xen_dmesg" | grep -qi "L1TF\|MDS\|flush"; then
    register_check "L1TF/MDS mitigations" PASS "detected"
  fi
fi

# Grant table limits (XSA-226 related)
if [[ -n "$xen_cmd" ]]; then
  max_grant_frames=$($xen_cmd info 2>/dev/null | grep -E "^max_grant_frames" | awk -F: '{print $2}' | tr -d ' ' || echo "")
  if [[ -n "$max_grant_frames" ]]; then
    if [[ "$max_grant_frames" -le 64 ]]; then
      register_check "Grant table limit" PASS "$max_grant_frames frames"
    else
      register_check "Grant table limit" WARN "$max_grant_frames frames (consider limiting)"
    fi
  fi

  # Check grant table version
  grant_version=$($xen_cmd info 2>/dev/null | grep -E "^gnttab_max_frames" | awk -F: '{print $2}' | tr -d ' ' || echo "")
  if [[ -n "$grant_version" ]]; then
    register_check "Grant table max" PASS "$grant_version"
  fi
fi

# Event channel limits (XSA-343 related)
if [[ -f /proc/xen/capabilities ]]; then
  # Check for event channel FIFO ABI
  if [[ -f /sys/hypervisor/properties/events ]]; then
    event_fifo=$(cat /sys/hypervisor/properties/events 2>/dev/null | grep -c "fifo" || echo "0")
    if [[ "$event_fifo" -gt 0 ]]; then
      register_check "Event channel ABI" PASS "FIFO (modern)"
    else
      register_check "Event channel ABI" WARN "2-level (legacy)"
    fi
  fi
fi

# Check for event channel per-domain limit in grub
if [[ -f /etc/default/grub ]]; then
  event_limit=$(grep -E "max_event_channels" /etc/default/grub 2>/dev/null || echo "")
  if [[ -n "$event_limit" ]]; then
    register_check "Event channel limit" PASS "configured"
  fi
fi

# PCI passthrough isolation
if [[ -n "$xen_cmd" ]]; then
  pci_passthrough=$($xen_cmd pci-list-assignable-devices 2>/dev/null | wc -l || echo "0")
  if [[ "$pci_passthrough" -gt 0 ]]; then
    register_check "PCI passthrough devices" PASS "$pci_passthrough available"

    # Check ACS (Access Control Services) for PCIe isolation
    acs_devices=$(lspci -vvv 2>/dev/null | grep -c "ACSCtl:" || echo "0")
    if [[ "$acs_devices" -gt 0 ]]; then
      register_check "PCIe ACS" PASS "$acs_devices devices with ACS"
    else
      register_check "PCIe ACS" WARN "not detected (passthrough isolation may be limited)"
    fi
  fi
fi

# Dom0 kernel hardening parameters
if [[ -f /proc/xen/capabilities ]]; then
  capabilities=$(cat /proc/xen/capabilities 2>/dev/null || echo "")
  if echo "$capabilities" | grep -q "control_d"; then
    # We're in Dom0 - check kernel hardening

    # Check KASLR
    if grep -qi "nokaslr" /proc/cmdline 2>/dev/null; then
      register_check "Dom0 KASLR" WARN "disabled"
    else
      register_check "Dom0 KASLR" PASS "enabled (default)"
    fi

    # Check SMEP/SMAP
    if grep -q "smep" /proc/cpuinfo 2>/dev/null; then
      register_check "Dom0 SMEP" PASS "CPU supported"
    fi
    if grep -q "smap" /proc/cpuinfo 2>/dev/null; then
      register_check "Dom0 SMAP" PASS "CPU supported"
    fi

    # Check kernel module loading restrictions
    if [[ -f /proc/sys/kernel/modules_disabled ]]; then
      modules_disabled=$(cat /proc/sys/kernel/modules_disabled 2>/dev/null || echo "0")
      if [[ "$modules_disabled" == "1" ]]; then
        register_check "Dom0 module loading" PASS "disabled"
      else
        register_check "Dom0 module loading" WARN "enabled"
      fi
    fi

    # Check kptr_restrict
    if [[ -f /proc/sys/kernel/kptr_restrict ]]; then
      kptr=$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null || echo "0")
      if [[ "$kptr" -ge 1 ]]; then
        register_check "Dom0 kptr_restrict" PASS "level $kptr"
      else
        register_check "Dom0 kptr_restrict" WARN "not set"
      fi
    fi
  fi
fi

# Xen virtual machine introspection
if [[ -n "$xen_cmd" ]]; then
  vmi_support=$($xen_cmd info 2>/dev/null | grep -i "vmi\|introspection" || echo "")
  if [[ -n "$vmi_support" ]]; then
    register_check "VM introspection" PASS "supported"
  fi
fi

# Check for pvshim (PVH shim for PV guests)
if [[ -f /usr/lib/xen/boot/xen-shim ]] || [[ -f /usr/libexec/xen/boot/xen-shim ]]; then
  register_check "PVH shim" PASS "available for legacy PV"
fi

print_summary
exit "$EXIT_CODE"
