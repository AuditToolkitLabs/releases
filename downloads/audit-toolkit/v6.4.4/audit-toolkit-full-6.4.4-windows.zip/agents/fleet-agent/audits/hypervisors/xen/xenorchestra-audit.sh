#!/usr/bin/env bash
# xenorchestra-audit.sh — Xen Orchestra Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: Web Application Security
# - NIST SP 800-53: AC-2, AC-6, AU-2 (Access Control, Audit)
# - ISO 27001: A.9.4 (System Access Control)
# - PCI DSS: 8.1, 10.1 (Authentication, Audit Logging)
#
# Note: Run this on the Xen Orchestra VM/container.
# XO is typically installed via xo-server (Node.js application).
#
# Checks:
# - XO server installation and version
# - Authentication configuration
# - HTTPS/TLS settings
# - Plugin security
# - Backup job encryption
# - User/ACL configuration
# - API token management

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../_lib/common.sh"
. "$SCRIPT_DIR/../_lib/distro.sh"
. "$SCRIPT_DIR/../_lib/hypervisor.sh"

setup_colors

section "Xen Orchestra Detection"

# Check for XO installation
xo_detected=false
xo_dir=""

# Common XO installation paths
xo_paths=(
    "/opt/xen-orchestra"
    "/opt/xo"
    "/home/xoa/xen-orchestra"
    "/usr/local/share/xen-orchestra"
)

for path in "${xo_paths[@]}"; do
    if [[ -d "$path" ]] && [[ -f "$path/packages/xo-server/package.json" ]]; then
        xo_dir="$path"
        xo_detected=true
        break
    fi
done

# Check for xo-server process
xo_running=false
if pgrep -f "xo-server" >/dev/null 2>&1; then
    xo_running=true
fi

# Check for XOA (Xen Orchestra Appliance)
is_xoa=false
if [[ -f /etc/xoa-version ]] || [[ -f /opt/xoa/version ]]; then
    is_xoa=true
    xo_detected=true
fi

if ! $xo_detected && ! $xo_running; then
    register_check "Xen Orchestra" SKIP "not detected"
    print_summary
    exit "$EXIT_CODE"
fi

# Get version
xo_version="unknown"
if [[ -n "$xo_dir" ]] && [[ -f "$xo_dir/packages/xo-server/package.json" ]]; then
    xo_version=$(grep -oP '"version":\s*"\K[^"]+' "$xo_dir/packages/xo-server/package.json" 2>/dev/null || echo "unknown")
elif $is_xoa && [[ -f /etc/xoa-version ]]; then
    xo_version=$(cat /etc/xoa-version 2>/dev/null || echo "XOA")
fi

if $is_xoa; then
    register_check "Xen Orchestra Appliance" PASS "version: $xo_version"
else
    register_check "Xen Orchestra (from source)" PASS "version: $xo_version"
fi

# ============================================================================
section "Server Configuration"
# ============================================================================

# Find config file
config_file=""
config_paths=(
    "$xo_dir/.xo-server.toml"
    "$xo_dir/packages/xo-server/.xo-server.toml"
    "/etc/xo-server/config.toml"
    "/opt/xoa/xo-server.toml"
    "$HOME/.config/xo-server/config.toml"
)

for cpath in "${config_paths[@]}"; do
    if [[ -f "$cpath" ]]; then
        config_file="$cpath"
        break
    fi
done

if [[ -z "$config_file" ]]; then
    register_check "Configuration file" WARN "not found in standard paths"
else
    register_check "Configuration file" PASS "found: $config_file"

    # Check HTTPS configuration
    if grep -qiE "^\s*cert\s*=" "$config_file" 2>/dev/null && \
       grep -qiE "^\s*key\s*=" "$config_file" 2>/dev/null; then
        register_check "HTTPS/TLS" PASS "certificate configured"

        # Check certificate path and validity
        cert_path=$(grep -oP "cert\s*=\s*['\"]?\K[^'\"#]+" "$config_file" 2>/dev/null | tr -d ' ' || echo "")
        if [[ -f "$cert_path" ]]; then
            expiry=$(openssl x509 -enddate -noout -in "$cert_path" 2>/dev/null | cut -d= -f2)
            if [[ -n "$expiry" ]]; then
                expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo 0)
                now_epoch=$(date +%s)
                days_left=$(( (expiry_epoch - now_epoch) / 86400 ))
                if [[ $days_left -gt 30 ]]; then
                    register_check "TLS certificate" PASS "$days_left days until expiry"
                elif [[ $days_left -gt 0 ]]; then
                    register_check "TLS certificate" WARN "expires in $days_left days"
                else
                    register_check "TLS certificate" FAIL "expired"
                fi
            fi
        fi
    else
        register_check "HTTPS/TLS" FAIL "not configured (HTTP only)"
    fi

    # Check listening address
    listen_addr=$(grep -oP "^\s*bind\s*=\s*['\"]?\K[^'\"#]+" "$config_file" 2>/dev/null | head -1 || echo "")
    if [[ -z "$listen_addr" ]] || [[ "$listen_addr" == "0.0.0.0" ]]; then
        register_check "Listen address" WARN "binds to all interfaces"
    elif [[ "$listen_addr" == "127.0.0.1" ]] || [[ "$listen_addr" == "localhost" ]]; then
        register_check "Listen address" PASS "localhost only"
    else
        register_check "Listen address" PASS "$listen_addr"
    fi
fi

# ============================================================================
section "Authentication Security"
# ============================================================================

# Check for LDAP/SSO configuration
ldap_configured=false
if [[ -n "$config_file" ]]; then
    if grep -qiE "^\s*\[authentication\.ldap\]|ldap.*uri\s*=" "$config_file" 2>/dev/null; then
        ldap_configured=true
        register_check "LDAP authentication" PASS "configured"
    fi

    # Check for SAML
    if grep -qiE "^\s*\[authentication\.saml\]|saml.*idp" "$config_file" 2>/dev/null; then
        register_check "SAML authentication" PASS "configured"
    fi

    # Check for OIDC
    if grep -qiE "^\s*\[authentication\.oidc\]|oidc.*issuer" "$config_file" 2>/dev/null; then
        register_check "OIDC authentication" PASS "configured"
    fi
fi

if ! $ldap_configured; then
    register_check "External authentication" WARN "local auth only (consider LDAP/SAML/OIDC)"
fi

# Check for default admin
xo_db=""
db_paths=(
    "$xo_dir/packages/xo-server/data/db.json"
    "/var/lib/xo-server/data/db.json"
    "/opt/xoa/data/db.json"
)

for dbpath in "${db_paths[@]}"; do
    if [[ -f "$dbpath" ]]; then
        xo_db="$dbpath"
        break
    fi
done

if [[ -n "$xo_db" ]]; then
    # Check for admin@ default email
    if grep -qi '"email":\s*"admin@admin.net"' "$xo_db" 2>/dev/null; then
        register_check "Default admin account" WARN "default admin@admin.net exists"
    else
        register_check "Default admin account" PASS "default account removed/renamed"
    fi
fi

# ============================================================================
section "Plugin Security"
# ============================================================================

# Check installed plugins
plugin_dir=""
plugin_paths=(
    "$xo_dir/packages"
    "/opt/xoa/node_modules"
)

for ppath in "${plugin_paths[@]}"; do
    if [[ -d "$ppath" ]]; then
        plugin_dir="$ppath"
        break
    fi
done

if [[ -n "$plugin_dir" ]]; then
    # Count plugins
    plugin_count=$(find "$plugin_dir" -maxdepth 1 -type d -name "xo-server-*" 2>/dev/null | wc -l)
    register_check "Installed plugins" PASS "$plugin_count plugins"

    # Check for backup plugin
    if [[ -d "$plugin_dir/xo-server-backup-reports" ]] || \
       find "$plugin_dir" -maxdepth 1 -name "*backup*" -type d 2>/dev/null | grep -q .; then
        register_check "Backup plugin" PASS "installed"
    else
        register_check "Backup plugin" WARN "backup-reports plugin not found"
    fi

    # Check for audit plugin
    if [[ -d "$plugin_dir/xo-server-audit" ]]; then
        register_check "Audit plugin" PASS "installed"
    else
        register_check "Audit plugin" WARN "audit plugin not installed"
    fi
fi

# ============================================================================
section "Backup Security"
# ============================================================================

# Check for backup encryption in config
if [[ -n "$xo_db" ]]; then
    # Check backup jobs for encryption
    if grep -qi '"encryption"' "$xo_db" 2>/dev/null; then
        if grep -qi '"encryption":\s*true\|"encryptionKeyId"' "$xo_db" 2>/dev/null; then
            register_check "Backup encryption" PASS "enabled on some jobs"
        else
            register_check "Backup encryption" WARN "encryption key defined but check job settings"
        fi
    else
        register_check "Backup encryption" WARN "no encryption detected in backup jobs"
    fi

    # Check for backup remotes
    remote_count=$(grep -o '"type":\s*"remote"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$remote_count" -gt 0 ]]; then
        register_check "Backup remotes" PASS "$remote_count remote(s) configured"
    else
        register_check "Backup remotes" WARN "no backup remotes configured"
    fi
fi

# ============================================================================
section "Access Control"
# ============================================================================

if [[ -n "$xo_db" ]]; then
    # Count admin users
    admin_count=$(grep -o '"permission":\s*"admin"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$admin_count" -le 3 ]]; then
        register_check "Admin users" PASS "$admin_count admin(s)"
    else
        register_check "Admin users" WARN "$admin_count admins (review necessity)"
    fi

    # Check for ACLs
    acl_count=$(grep -o '"type":\s*"acl"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$acl_count" -gt 0 ]]; then
        register_check "ACL rules" PASS "$acl_count ACL rule(s)"
    else
        register_check "ACL rules" WARN "no ACL rules defined"
    fi

    # Check for groups
    group_count=$(grep -o '"type":\s*"group"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$group_count" -gt 0 ]]; then
        register_check "User groups" PASS "$group_count group(s)"
    else
        register_check "User groups" WARN "no groups defined (consider RBAC)"
    fi
fi

# ============================================================================
section "API Security"
# ============================================================================

if [[ -n "$xo_db" ]]; then
    # Check for API tokens
    token_count=$(grep -o '"type":\s*"token"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$token_count" -gt 0 ]]; then
        register_check "API tokens" WARN "$token_count token(s) (review and rotate)"
    else
        register_check "API tokens" PASS "no API tokens"
    fi
fi

# Check API rate limiting (usually in reverse proxy)
if command -v nginx >/dev/null 2>&1; then
    nginx_conf="/etc/nginx/nginx.conf"
    if [[ -f "$nginx_conf" ]]; then
        if grep -qi "limit_req" "$nginx_conf" 2>/dev/null; then
            register_check "API rate limiting" PASS "nginx rate limiting enabled"
        else
            register_check "API rate limiting" WARN "no rate limiting in nginx"
        fi
    fi
fi

# ============================================================================
section "System Security"
# ============================================================================

# Check Node.js version
node_version=$(node --version 2>/dev/null | tr -d 'v' || echo "unknown")
if [[ "$node_version" != "unknown" ]]; then
    major_version=$(echo "$node_version" | cut -d. -f1)
    if [[ "$major_version" -ge 18 ]]; then
        register_check "Node.js version" PASS "$node_version (LTS)"
    elif [[ "$major_version" -ge 16 ]]; then
        register_check "Node.js version" WARN "$node_version (upgrade to 18+)"
    else
        register_check "Node.js version" FAIL "$node_version (EOL, upgrade required)"
    fi
fi

# Check if running as non-root
xo_user=$(ps aux 2>/dev/null | grep "xo-server" | grep -v grep | awk '{print $1}' | head -1)
if [[ -n "$xo_user" ]] && [[ "$xo_user" != "root" ]]; then
    register_check "XO service user" PASS "running as $xo_user"
elif [[ "$xo_user" == "root" ]]; then
    register_check "XO service user" FAIL "running as root"
else
    register_check "XO service user" SKIP "process not detected"
fi

# Check file permissions on config
if [[ -n "$config_file" ]]; then
    config_perms=$(stat -c "%a" "$config_file" 2>/dev/null || echo "unknown")
    if [[ "$config_perms" == "600" ]] || [[ "$config_perms" == "400" ]]; then
        register_check "Config file permissions" PASS "$config_perms"
    elif [[ "$config_perms" != "unknown" ]]; then
        register_check "Config file permissions" WARN "$config_perms (recommend 600)"
    fi
fi

# Check log directory
log_dirs=(
    "/var/log/xo-server"
    "$xo_dir/logs"
    "/opt/xoa/logs"
)

for logdir in "${log_dirs[@]}"; do
    if [[ -d "$logdir" ]]; then
        register_check "Log directory" PASS "$logdir"

        # Check if logs are being written
        recent_logs=$(find "$logdir" -type f -mtime -1 2>/dev/null | wc -l)
        if [[ "$recent_logs" -gt 0 ]]; then
            register_check "Recent logs" PASS "$recent_logs files in last 24h"
        else
            register_check "Recent logs" WARN "no recent log activity"
        fi
        break
    fi
done

# ============================================================================
section "Advanced Security Controls"
# ============================================================================

# Session management and security
if [[ -n "$config_file" ]]; then
    # Check session cookie settings
    if grep -qiE "sessionSecret|cookieSecret" "$config_file" 2>/dev/null; then
        register_check "Session secret" PASS "configured"
    else
        register_check "Session secret" WARN "using default (security risk)"
    fi

    # Check session timeout
    session_timeout=$(grep -oP "sessionTimeout\s*=\s*['\"]?\K[^'\"#]+" "$config_file" 2>/dev/null | head -1 || echo "")
    if [[ -n "$session_timeout" ]]; then
        register_check "Session timeout" PASS "$session_timeout"
    else
        register_check "Session timeout" WARN "not explicitly configured"
    fi
fi

# XO Proxy security (if deployed)
if pgrep -f "xo-proxy" >/dev/null 2>&1; then
    register_check "XO Proxy" PASS "running"

    # Check proxy config
    proxy_config="/etc/xo-proxy/config.toml"
    if [[ -f "$proxy_config" ]]; then
        # Check proxy TLS
        if grep -qiE "cert\s*=|tls" "$proxy_config" 2>/dev/null; then
            register_check "Proxy TLS" PASS "configured"
        else
            register_check "Proxy TLS" WARN "not configured"
        fi
    fi
fi

# Resource sets security audit
if [[ -n "$xo_db" ]]; then
    resource_sets=$(grep -o '"type":\s*"resourceSet"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$resource_sets" -gt 0 ]]; then
        register_check "Resource sets" PASS "$resource_sets set(s) for RBAC"
    else
        register_check "Resource sets" WARN "no resource sets (consider for RBAC)"
    fi
fi

# Continuous replication audit
if [[ -n "$xo_db" ]]; then
    cr_jobs=$(grep -o '"type":\s*"continuousReplication"\|"mode":\s*"delta"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$cr_jobs" -gt 0 ]]; then
        register_check "Continuous replication" PASS "$cr_jobs job(s)"
    fi

    # Check for health check jobs
    health_jobs=$(grep -o '"healthCheckSr"' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$health_jobs" -gt 0 ]]; then
        register_check "Backup health checks" PASS "$health_jobs configured"
    else
        register_check "Backup health checks" WARN "not configured"
    fi
fi

# XCP-ng Pool security checks
if $xo_running; then
    # Check for pool master connectivity
    if [[ -n "$xo_db" ]]; then
        servers_count=$(grep -o '"type":\s*"server"' "$xo_db" 2>/dev/null | wc -l || echo "0")
        if [[ "$servers_count" -gt 0 ]]; then
            register_check "Connected servers" PASS "$servers_count server(s)"
        fi
    fi
fi

# Webhook/notifications security
if [[ -n "$xo_db" ]]; then
    webhooks=$(grep -o '"type":\s*"webhook"\|webhookUrl' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$webhooks" -gt 0 ]]; then
        register_check "Webhooks" WARN "$webhooks webhook(s) (review endpoints)"
    fi

    # Check for SMTP configuration (for alerts)
    smtp_config=$(grep -o '"smtp":\|smtpServer' "$xo_db" 2>/dev/null | wc -l || echo "0")
    if [[ "$smtp_config" -gt 0 ]]; then
        register_check "Email alerts" PASS "SMTP configured"
    else
        register_check "Email alerts" WARN "SMTP not configured"
    fi
fi

# Check npm package vulnerabilities (if npm available)
if command -v npm >/dev/null 2>&1 && [[ -n "$xo_dir" ]] && [[ -f "$xo_dir/package.json" ]]; then
    # Check for outdated packages (security risk)
    outdated=$(cd "$xo_dir" && npm outdated --json 2>/dev/null | grep -c '"current"' || echo "0")
    if [[ "$outdated" -gt 10 ]]; then
        register_check "NPM packages" WARN "$outdated outdated packages"
    elif [[ "$outdated" -gt 0 ]]; then
        register_check "NPM packages" PASS "$outdated outdated (manageable)"
    else
        register_check "NPM packages" PASS "up to date"
    fi
fi

# ============================================================================
section "Summary"
# ============================================================================

print_summary
exit "$EXIT_CODE"
