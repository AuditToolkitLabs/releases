#!/usr/bin/env python3
"""
Xen Orchestra Security Audit via JSON-RPC API

Cross-platform XenOrchestra audit using JSON-RPC API.
Runs on Windows, Linux, or macOS with Python 3.8+.

Compliance Mapping:
- CIS Benchmark: Web Application Security
- NIST SP 800-53: AC-2, AC-6, AU-2
- ISO 27001: A.9.4 (System Access Control)
- PCI DSS: 8.1, 10.1

Usage:
    python xo-api-audit.py --server xo.example.com --username admin@admin.net
    python xo-api-audit.py --server xo.example.com --username admin@admin.net --insecure

Requirements:
    pip install requests urllib3
"""

import argparse
import json
import sys
import urllib3
from getpass import getpass
from typing import Any, Dict, List, Optional
import uuid

try:
    import requests
except ImportError:
    print("ERROR: requests module required. Install with: pip install requests")
    sys.exit(1)


class AuditResults:
    """Track audit results"""
    
    def __init__(self):
        self.checks = []
        self.passed = 0
        self.warnings = 0
        self.failed = 0
        self.skipped = 0
    
    def register(self, name: str, status: str, message: str = ""):
        """Register a check result"""
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"
        
        color = colors.get(status, "")
        print(f"{color}[{status}]{reset} {name}" + (f" - {message}" if message else ""))
        
        self.checks.append({"name": name, "status": status, "message": message})
        
        if status == "PASS":
            self.passed += 1
        elif status == "WARN":
            self.warnings += 1
        elif status == "FAIL":
            self.failed += 1
        else:
            self.skipped += 1
    
    def summary(self):
        """Print summary"""
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {len(self.checks)}")
        print(f"\033[92mPassed: {self.passed}\033[0m")
        print(f"\033[93mWarnings: {self.warnings}\033[0m")
        print(f"\033[91mFailed: {self.failed}\033[0m")
        print(f"\033[90mSkipped: {self.skipped}\033[0m")
    
    def to_json(self) -> str:
        """Export results as JSON"""
        return json.dumps({
            "checks": self.checks,
            "summary": {
                "passed": self.passed,
                "warnings": self.warnings,
                "failed": self.failed,
                "skipped": self.skipped
            }
        }, indent=2)


class XenOrchestraAudit:
    """Xen Orchestra JSON-RPC API Audit Client"""
    
    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = True, port: int = 443):
        self.server = server
        self.port = port
        protocol = "https" if port == 443 else "http"
        self.base_url = f"{protocol}://{server}:{port}/api"
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session.headers["Content-Type"] = "application/json"
        self.results = AuditResults()
        self.auth_token = None
        
        if not verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        self._authenticate(username, password)
    
    def _rpc_call(self, method: str, params: Dict = None) -> Optional[Any]:
        """Make JSON-RPC call"""
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": method,
            "params": params or {}
        }
        
        try:
            response = self.session.post(self.base_url, json=payload, timeout=30)
            if response.status_code == 200:
                result = response.json()
                if "error" in result:
                    return None
                return result.get("result")
            return None
        except Exception:
            return None
    
    def _authenticate(self, username: str, password: str):
        """Authenticate with XO"""
        try:
            result = self._rpc_call("session.signIn", {
                "email": username,
                "password": password
            })
            
            if result:
                self.auth_token = result
                self.results.register("XO Connection", "PASS", self.server)
            else:
                # Try with username instead of email
                result = self._rpc_call("session.signInWithPassword", {
                    "username": username,
                    "password": password
                })
                if result:
                    self.auth_token = result
                    self.results.register("XO Connection", "PASS", self.server)
                else:
                    self.results.register("XO Connection", "FAIL", "Authentication failed")
                    sys.exit(1)
        except requests.exceptions.SSLError:
            self.results.register("XO Connection", "FAIL", "SSL error (try --insecure)")
            sys.exit(1)
        except requests.exceptions.RequestException as e:
            self.results.register("XO Connection", "FAIL", str(e))
            sys.exit(1)
    
    def section(self, title: str):
        """Print section header"""
        print(f"\n=== {title} ===\n")
    
    def audit_server_info(self):
        """Audit XO server information"""
        self.section("XO Server Information")
        
        # Get server version
        version = self._rpc_call("server.getVersion")
        if version:
            self.results.register("XO Version", "PASS", version)
        else:
            self.results.register("XO Version", "SKIP", "Could not retrieve")
        
        # Get current user info
        user = self._rpc_call("user.getCurrent")
        if user:
            email = user.get("email", "unknown")
            permission = user.get("permission", "unknown")
            self.results.register("Current User", "PASS", f"{email} ({permission})")
    
    def audit_users(self):
        """Audit user accounts"""
        self.section("User Management")
        
        users = self._rpc_call("user.getAll")
        if not users:
            self.results.register("Users", "SKIP", "Could not retrieve")
            return
        
        self.results.register("Users", "PASS", f"{len(users)} user(s)")
        
        # Count admins
        admin_count = len([u for u in users if u.get("permission") == "admin"])
        if admin_count <= 3:
            self.results.register("Admin Users", "PASS", f"{admin_count} admin(s)")
        else:
            self.results.register("Admin Users", "WARN", f"{admin_count} admins (review necessity)")
        
        # Check for default admin account
        default_admin = [u for u in users if u.get("email") == "admin@admin.net"]
        if default_admin:
            self.results.register("Default Admin Account", "WARN", "admin@admin.net exists (rename/remove)")
        else:
            self.results.register("Default Admin Account", "PASS", "Removed/renamed")
    
    def audit_groups(self):
        """Audit user groups"""
        self.section("Groups and RBAC")
        
        groups = self._rpc_call("group.getAll")
        if groups:
            self.results.register("User Groups", "PASS", f"{len(groups)} group(s)")
        else:
            self.results.register("User Groups", "WARN", "None configured (consider RBAC)")
    
    def audit_acls(self):
        """Audit ACL configuration"""
        acls = self._rpc_call("acl.get")
        if acls:
            self.results.register("ACL Rules", "PASS", f"{len(acls)} rule(s)")
        else:
            self.results.register("ACL Rules", "WARN", "None configured")
    
    def audit_auth_providers(self):
        """Audit authentication providers"""
        self.section("Authentication Security")
        
        # Check for LDAP
        ldap = self._rpc_call("plugin.get", {"id": "auth-ldap"})
        if ldap and ldap.get("loaded"):
            self.results.register("LDAP Authentication", "PASS", "Plugin loaded")
            config = ldap.get("configuration", {})
            if config.get("uri", "").startswith("ldaps://"):
                self.results.register("LDAP Encryption", "PASS", "LDAPS")
            elif "ldap://" in config.get("uri", ""):
                self.results.register("LDAP Encryption", "WARN", "Plain LDAP")
        else:
            self.results.register("LDAP Authentication", "SKIP", "Not configured")
        
        # Check for SAML
        saml = self._rpc_call("plugin.get", {"id": "auth-saml"})
        if saml and saml.get("loaded"):
            self.results.register("SAML/SSO", "PASS", "Plugin loaded")
        
        # Check for GitHub auth
        github = self._rpc_call("plugin.get", {"id": "auth-github"})
        if github and github.get("loaded"):
            self.results.register("GitHub Auth", "PASS", "Plugin loaded")
    
    def audit_api_tokens(self):
        """Audit API tokens"""
        self.section("API Security")
        
        tokens = self._rpc_call("token.getAll")
        if tokens:
            if len(tokens) > 0:
                self.results.register("API Tokens", "WARN", f"{len(tokens)} token(s) (review and rotate)")
            else:
                self.results.register("API Tokens", "PASS", "None")
        else:
            self.results.register("API Tokens", "SKIP", "Could not retrieve")
    
    def audit_xen_servers(self):
        """Audit connected Xen servers"""
        self.section("Xen Server Connections")
        
        servers = self._rpc_call("server.getAll")
        if not servers:
            self.results.register("Xen Servers", "SKIP", "Could not retrieve")
            return
        
        self.results.register("Xen Servers", "PASS", f"{len(servers)} server(s)")
        
        for server in servers:
            server_name = server.get("label", server.get("host", "unknown"))
            status = server.get("status", "unknown")
            
            if status == "connected":
                self.results.register(f"Server {server_name}", "PASS", "Connected")
            else:
                self.results.register(f"Server {server_name}", "WARN", status)
            
            # Check if using HTTPS
            host = server.get("host", "")
            if server.get("allowUnauthorized"):
                self.results.register(f"{server_name} SSL Verify", "WARN", "Certificate verification disabled")
            else:
                self.results.register(f"{server_name} SSL Verify", "PASS", "Enabled")
    
    def audit_vms(self):
        """Audit virtual machines"""
        self.section("Virtual Machines")
        
        vms = self._rpc_call("xo.getAllObjects", {"filter": {"type": "VM"}})
        if not vms:
            self.results.register("Virtual Machines", "SKIP", "Could not retrieve")
            return
        
        vm_list = list(vms.values()) if isinstance(vms, dict) else vms
        self.results.register("Virtual Machines", "PASS", f"{len(vm_list)} VM(s)")
        
        # Count by power state
        running = len([vm for vm in vm_list if vm.get("power_state") == "Running"])
        self.results.register("Running VMs", "PASS", f"{running} running")
    
    def audit_backups(self):
        """Audit backup configuration"""
        self.section("Backup Security")
        
        # Get backup jobs
        jobs = self._rpc_call("backupNg.getAllJobs")
        if jobs:
            self.results.register("Backup Jobs", "PASS", f"{len(jobs)} job(s)")
            
            # Check for encryption
            encrypted_jobs = len([j for j in jobs if j.get("settings", {}).get("encryption")])
            if encrypted_jobs > 0:
                self.results.register("Encrypted Backups", "PASS", f"{encrypted_jobs} job(s) with encryption")
            else:
                self.results.register("Encrypted Backups", "WARN", "No encrypted backup jobs")
        else:
            self.results.register("Backup Jobs", "WARN", "None configured")
        
        # Check backup remotes
        remotes = self._rpc_call("remote.getAll")
        if remotes:
            self.results.register("Backup Remotes", "PASS", f"{len(remotes)} remote(s)")
            
            # Check remote types
            for remote in remotes:
                remote_name = remote.get("name", "unknown")
                remote_type = remote.get("type", "unknown")
                
                # Check if S3 with encryption
                if remote_type == "s3" and remote.get("encryption"):
                    self.results.register(f"Remote {remote_name}", "PASS", "S3 with encryption")
                elif remote_type == "s3":
                    self.results.register(f"Remote {remote_name}", "WARN", "S3 without encryption")
        else:
            self.results.register("Backup Remotes", "WARN", "None configured")
    
    def audit_plugins(self):
        """Audit installed plugins"""
        self.section("Plugins")
        
        plugins = self._rpc_call("plugin.getAll")
        if not plugins:
            self.results.register("Plugins", "SKIP", "Could not retrieve")
            return
        
        loaded_plugins = [p for p in plugins if p.get("loaded")]
        self.results.register("Loaded Plugins", "PASS", f"{len(loaded_plugins)} plugin(s)")
        
        # Check for security-related plugins
        audit_plugin = [p for p in plugins if p.get("id") == "audit"]
        if audit_plugin and audit_plugin[0].get("loaded"):
            self.results.register("Audit Plugin", "PASS", "Loaded")
        else:
            self.results.register("Audit Plugin", "WARN", "Not installed/loaded")
        
        # Check for backup reports
        backup_reports = [p for p in plugins if "backup" in p.get("id", "").lower() and "report" in p.get("id", "").lower()]
        if backup_reports and any(p.get("loaded") for p in backup_reports):
            self.results.register("Backup Reports Plugin", "PASS", "Loaded")
    
    def audit_resource_sets(self):
        """Audit resource sets (self-service)"""
        self.section("Self-Service / Resource Sets")
        
        resource_sets = self._rpc_call("resourceSet.getAll")
        if resource_sets:
            self.results.register("Resource Sets", "PASS", f"{len(resource_sets)} set(s)")
        else:
            self.results.register("Resource Sets", "SKIP", "None configured")
    
    def audit_metadata(self):
        """Audit audit logs / metadata"""
        self.section("Audit Logging")
        
        # Try to get recent audit records
        audit_records = self._rpc_call("audit.getRecords", {"nRecords": 10})
        if audit_records:
            self.results.register("Audit Records", "PASS", "Audit logging active")
        else:
            self.results.register("Audit Records", "WARN", "Audit plugin may not be configured")
    
    def disconnect(self):
        """Disconnect from XO"""
        try:
            self._rpc_call("session.signOut")
        except Exception:
            pass
    
    def run_full_audit(self) -> AuditResults:
        """Run complete audit"""
        self.audit_server_info()
        self.audit_users()
        self.audit_groups()
        self.audit_acls()
        self.audit_auth_providers()
        self.audit_api_tokens()
        self.audit_xen_servers()
        self.audit_vms()
        self.audit_backups()
        self.audit_plugins()
        self.audit_resource_sets()
        self.audit_metadata()
        
        self.disconnect()
        self.results.summary()
        
        return self.results


def main():
    parser = argparse.ArgumentParser(
        description="Xen Orchestra Security Audit via JSON-RPC API"
    )
    parser.add_argument("--server", "-s", required=True, help="XO server hostname or IP")
    parser.add_argument("--username", "-u", required=True, help="Email/username (e.g., admin@admin.net)")
    parser.add_argument("--password", "-p", help="Password (will prompt if not provided)")
    parser.add_argument("--port", type=int, default=443, help="API port (default: 443)")
    parser.add_argument("--insecure", "-k", action="store_true", help="Skip SSL certificate verification")
    parser.add_argument("--json", "-j", action="store_true", help="Output results as JSON")
    
    args = parser.parse_args()
    
    password = args.password or getpass("Password: ")
    
    try:
        audit = XenOrchestraAudit(
            server=args.server,
            username=args.username,
            password=password,
            verify_ssl=not args.insecure,
            port=args.port
        )
        
        results = audit.run_full_audit()
        
        if args.json:
            print(results.to_json())
        
        # Exit code based on results
        if results.failed > 0:
            sys.exit(2)
        elif results.warnings > 0:
            sys.exit(1)
        else:
            sys.exit(0)
            
    except KeyboardInterrupt:
        print("\nAudit cancelled")
        sys.exit(130)


if __name__ == "__main__":
    main()
