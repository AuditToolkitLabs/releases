#!/usr/bin/env bash
# AUDIT TEMPLATE: Copy this file as a starting point for new audits
#
# This template demonstrates the standard structure and conventions for writing
# security audits in this framework. Follow this pattern to ensure consistency
# and compatibility with the orchestrator.
#
# @elevation: partial
# @elevation-reason: Replace with appropriate reason for your audit
#
# Usage:
#   cp audits/_lib/audit-template.sh audits/<domain>/<category>/<name>.sh
#   # Then modify the audit-specific logic below

set -euo pipefail

# === REQUIRED: Source libraries in this order ===
# Always include common.sh for logging and check registration
. "$(dirname "$0")/../../../lib/common.sh"

# Include domain-specific libraries as needed (uncomment):
# . "$(dirname "$0")/../../../lib/distro.sh"   # For distro detection
# . "$(dirname "$0")/../../../lib/pkg.sh"      # For package manager shims
# . "$(dirname "$0")/../../../lib/svc.sh"      # For service manager shims
# . "$(dirname "$0")/../../../lib/firewall.sh" # For firewall shims
# . "$(dirname "$0")/../../../lib/security_stack.sh" # For SELinux/AppArmor
# . "$(dirname "$0")/../../../lib/paths.sh"    # For standard paths

# === OPTIONAL: Parse command-line arguments ===
# This section is optional; only include if your audit needs parameters
VERBOSE=false
CUSTOM_PARAM=""

usage() {
  cat <<'EOF'
Usage: audit-template.sh [OPTIONS]

Options:
  -v, --verbose              Enable debug output
  -p, --param VALUE          Example custom parameter
  -h, --help                 Show this help message

EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -v|--verbose) VERBOSE=true; shift ;;
    -p|--param)   CUSTOM_PARAM="$2"; shift 2 ;;
    -h|--help)    usage; exit 0 ;;
    *)            echo "Unknown option: $1"; usage; exit 1 ;;
  esac
done

# === BEGIN AUDIT CHECKS ===

# Group related checks with a section header
section "Example Check Category"

# Use register_check with results: PASS, WARN, FAIL, or SKIP
# Syntax: register_check <check_name> <result> [optional_message]

# Example 1: Simple pass/fail check
if [[ -f /etc/hostname ]]; then
  register_check "Hostname file exists" PASS
else
  register_check "Hostname file exists" FAIL "file not found"
fi

# Example 2: Check with message
hostname_value=$(hostname -f 2>/dev/null || echo "unknown")
if [[ "$hostname_value" != "unknown" ]]; then
  register_check "Hostname resolvable" PASS "$(hostname -f)"
else
  register_check "Hostname resolvable" WARN "could not resolve FQDN"
fi

# Example 3: Using debug logging (only shown with --verbose or VERBOSE=true)
if [[ "$VERBOSE" == "true" ]]; then
  _log DEBUG "This message only appears with VERBOSE=true"
fi

# Example 4: Conditional skip
if ! command -v example_tool >/dev/null 2>&1; then
  register_check "Example tool installed" SKIP "tool not found on this system"
else
  register_check "Example tool installed" PASS
fi

# === SECOND CATEGORY ===
section "Another Check Category"

# Example 5: Numeric comparison
file_count=$(find /var -maxdepth 1 -type f 2>/dev/null | wc -l || echo 0)
if [[ "$file_count" -gt 10 ]]; then
  register_check "File count in /var" WARN "Found $file_count files (expected < 10)"
else
  register_check "File count in /var" PASS "$file_count files"
fi

# Example 6: Using shims for cross-distro compatibility (if sourced)
# if pkg_installed "curl"; then
#   register_check "curl package installed" PASS
# else
#   register_check "curl package installed" FAIL
# fi

# === REQUIRED: Print summary and exit ===
# This MUST be called at the end to:
# 1. Display the summary table
# 2. Set EXIT_CODE based on failures/warnings
# 3. Allow the orchestrator to parse results

print_summary
exit "$EXIT_CODE"
