#!/usr/bin/env bash
# shellcheck shell=bash
# portable.sh — tiny helpers used by portable audits. Safe to source.
#
# @elevation: none
# @elevation-reason: Library file sourced by audits; does not require elevation itself
#

# If executed directly (not sourced), enable pipefail. When sourced as a library,
# we avoid mutating the caller's shell options.
if [[ ${BASH_SOURCE[0]} == "$0" ]]; then
  set -o pipefail
fi

have() { command -v -- "$1" >/dev/null 2>&1; }

get_os_id() {
  # shellcheck disable=SC1091,SC2154 source=/etc/os-release
  if [ "$(uname -s)" = "Darwin" ]; then
    echo "macos"
  elif [ -r /etc/os-release ]; then
    . /etc/os-release
    echo "${ID:-unknown}"
  else
    echo "unknown"
  fi
}

get_like() {
  # shellcheck disable=SC1091,SC2154 source=/etc/os-release
  if [ "$(uname -s)" = "Darwin" ]; then
    echo "bsd"
  elif [ -r /etc/os-release ]; then
    . /etc/os-release
    echo "${ID_LIKE:-}"
  else
    echo ""
  fi
}

is_root() {
  # Returns 0 if running as root, 1 otherwise
  [ "${EUID:-$(id -u)}" -eq 0 ]
}

get_shell() {
  # Returns the current shell name
  ps -p $$ -o comm= 2>/dev/null
}

service_active() {
  local svc="$1"
  # systemd
  if have systemctl; then
    if systemctl is-active --quiet "$svc" >/dev/null 2>&1; then
      return 0
    fi
  fi
  # OpenRC (Alpine, Gentoo)
  if have rc-service; then
    if rc-service "$svc" status >/dev/null 2>&1; then
      return 0
    fi
  fi
  # runit (Void Linux, Artix)
  if have sv; then
    if sv status "$svc" 2>/dev/null | grep -q '^run:'; then
      return 0
    fi
  fi
  # s6 (Artix, Obarun)
  if have s6-svstat; then
    if s6-svstat "/run/s6/services/$svc" 2>/dev/null | grep -q 'up'; then
      return 0
    fi
  fi
  # dinit (Artix, Chimera)
  if have dinitctl; then
    if dinitctl status "$svc" 2>/dev/null | grep -qiE 'STARTED|running'; then
      return 0
    fi
  fi
  # sysvinit fallback
  if have service; then
    if service "$svc" status >/dev/null 2>&1; then
      return 0
    fi
  fi
  # macOS
  if have launchctl; then
    # Use -F to prevent regex injection via service names
    if launchctl list | grep -qF -- "$svc"; then
      return 0
    fi
  fi
  return 1
}

# Aliases for compatibility with lib/svc.sh function names
svc_is_active() { service_active "$1"; }

svc_is_enabled() {
  local svc="$1"
  # systemd
  if have systemctl; then
    systemctl is-enabled "$svc" >/dev/null 2>&1 && return 0
  fi
  # OpenRC (Alpine, Gentoo)
  if have rc-update; then
    rc-update show 2>/dev/null | grep -qF " ${svc} " && return 0
  fi
  # runit (Void Linux, Artix)
  if have sv; then
    [[ -L "/var/service/$svc" ]] || [[ -L "/service/$svc" ]] && return 0
  fi
  # s6 (Artix, Obarun)
  if have s6-rc-db; then
    s6-rc-db list all 2>/dev/null | grep -qF "$svc" && return 0
  fi
  # dinit (Artix, Chimera)
  if have dinitctl; then
    dinitctl list 2>/dev/null | grep -qE "^\[\+\].*$svc" && return 0
  fi
  # sysvinit fallback
  # shellcheck disable=SC2144
  if [[ -n "$(compgen -G "/etc/rc*.d/S*${svc}")" ]]; then
    return 0
  fi
  return 1
}

list_services_matching() {
  local pat="$1"
  if have systemctl; then
    systemctl list-units --type=service --all 2>/dev/null \
      | awk '{print $1}' \
      | grep -E "$pat" \
      || true
  elif have rc-service; then
    # OpenRC (Alpine, Gentoo)
    rc-service --list 2>/dev/null | grep -E "$pat" || true
  elif have sv && [[ -d /etc/sv ]]; then
    # runit (Void Linux, Artix)
    for f in /etc/sv/*; do
      [[ -d "$f" ]] && basename "$f"
    done 2>/dev/null | grep -E "$pat" || true
  elif have dinitctl; then
    # dinit (Artix, Chimera)
    dinitctl list 2>/dev/null | awk '{print $2}' | grep -E "$pat" || true
  elif have launchctl; then
    # macOS
    launchctl list | awk '{print $3}' | grep -E "$pat" || true
  fi
}

prefer_path() {
  # take first existing directory from arguments
  local d
  for d in "$@"; do
    [ -d "$d" ] && { echo "$d"; return; }
  done
  echo ""
}
