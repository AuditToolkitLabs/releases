# Advanced Controls README

This folder contains advanced Linux audit scripts for controls recommended by CIS and other hardening standards. All scripts are cross-Unix compatible, use the standard error handling and reporting functions, and leverage the compatibility shims for multi-distro support.

## Included Audits
- Filesystem Partitioning & Mount Options
- USB Storage Kernel Module
- Kernel Hardening (sysctl, ASLR)
- Logging & Log Rotation
- Auditd & Audit Rules
- Cron Permissions
- File Integrity (AIDE)
- GRUB Password Protection

## Script Conventions
- All scripts start with `set -euo pipefail` for robust error handling.
- Standard reporting via `section`, `register_check`, and `print_summary` (see lib/common.sh).
- Distro detection and shims for package/service checks (see lib/distro.sh, lib/pkg.sh).
- No system modifications; all audits are read-only.

## Usage
Run any script directly:

```bash
bash audits/linux/advanced-controls/<script>.sh
```

Or run via orchestrator for aggregation:

```bash
bash orchestrator/orchestrator.sh --domain advanced-controls
```

## References
- [lib/common.sh](../../lib/common.sh): Error handling, reporting, summary
- [lib/distro.sh](../../lib/distro.sh): Distro detection, feature probes
- [lib/pkg.sh](../../lib/pkg.sh): Package manager shims

---
For full CIS coverage, include these advanced controls in your audit plans.
