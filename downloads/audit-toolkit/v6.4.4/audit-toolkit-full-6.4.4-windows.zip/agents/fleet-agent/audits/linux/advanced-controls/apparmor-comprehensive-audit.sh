#!/usr/bin/env bash
# apparmor-comprehensive-audit.sh — AppArmor Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 1.6.x (Mandatory Access Controls)
# - NIST SP 800-53: AC-3, AC-4, AC-6 (Access Enforcement, Least Privilege)
# - ISO 27001: A.9.4.1 (Information Access Restriction)
# - PCI DSS: 7.1, 7.2 (Access Control)
# - Ubuntu Security Baseline
#
# Checks:
# - AppArmor status
# - Profile enforcement modes
# - Profile coverage
# - Audit events
# - Tunables configuration
#
# @elevation: root
# @elevation-reason: AppArmor status commands (aa-status) require root privileges
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

section "AppArmor Comprehensive Audit"

# Check if AppArmor is available
if ! command -v apparmor_status >/dev/null 2>&1 && ! command -v aa-status >/dev/null 2>&1; then
  register_check "AppArmor available" SKIP "aa-status not found - AppArmor not installed"
  print_summary
  exit "$EXIT_CODE"
fi

# Use whichever command is available
if command -v aa-status >/dev/null 2>&1; then
  AA_STATUS="aa-status"
else
  AA_STATUS="apparmor_status"
fi

section "AppArmor Status (CIS 1.6.1.1)"

# Check if AppArmor kernel module is loaded
if [[ -d "/sys/kernel/security/apparmor" ]]; then
  register_check "Kernel module" PASS "loaded"
else
  register_check "Kernel module" FAIL "not loaded"
  print_summary
  exit "$EXIT_CODE"
fi

# Check if AppArmor is enabled
if grep -q "Y" /sys/module/apparmor/parameters/enabled 2>/dev/null; then
  register_check "AppArmor enabled" PASS "yes"
else
  register_check "AppArmor enabled" FAIL "no"
fi

# Get overall status
aa_output=$($AA_STATUS 2>/dev/null || echo "")
if [[ -z "$aa_output" ]]; then
  register_check "AppArmor status" FAIL "could not get status (run as root?)"
  print_summary
  exit "$EXIT_CODE"
fi

section "Profile Statistics"

# Parse profile counts
profiles_loaded=$(echo "$aa_output" | grep -E "profiles are loaded" | grep -oE "[0-9]+" | head -1 || echo "0")
enforce_mode=$(echo "$aa_output" | grep -E "profiles are in enforce mode" | grep -oE "[0-9]+" || echo "0")
complain_mode=$(echo "$aa_output" | grep -E "profiles are in complain mode" | grep -oE "[0-9]+" || echo "0")
unconfined=$(echo "$aa_output" | grep -E "processes are unconfined" | grep -oE "[0-9]+" || echo "0")

register_check "Profiles loaded" PASS "$profiles_loaded"

# Check enforce mode profiles
if [[ "$enforce_mode" -gt 0 ]]; then
  register_check "Enforce mode profiles" PASS "$enforce_mode"
else
  register_check "Enforce mode profiles" WARN "none in enforce mode"
fi

# Check complain mode profiles (should be minimal in production)
if [[ "$complain_mode" -gt 10 ]]; then
  register_check "Complain mode profiles" WARN "$complain_mode (too many in complain)"
elif [[ "$complain_mode" -gt 0 ]]; then
  register_check "Complain mode profiles" WARN "$complain_mode (review recommended)"
else
  register_check "Complain mode profiles" PASS "none"
fi

# Unconfined processes
if [[ "$unconfined" -gt 50 ]]; then
  register_check "Unconfined processes" WARN "$unconfined processes"
else
  register_check "Unconfined processes" PASS "$unconfined"
fi

section "Critical Service Profiles (CIS 1.6.1.3)"

# Check if critical services have profiles
critical_services=(
  "/usr/sbin/sshd:SSH daemon"
  "/usr/sbin/nginx:Nginx"
  "/usr/sbin/apache2:Apache"
  "/usr/sbin/named:BIND DNS"
  "/usr/sbin/mysqld:MySQL"
  "/usr/bin/postgres:PostgreSQL"
  "/usr/lib/snapd/snapd:Snapd"
  "/usr/bin/docker:Docker"
  "/usr/bin/containerd:Containerd"
)

for entry in "${critical_services[@]}"; do
  bin="${entry%%:*}"
  name="${entry##*:}"

  # Check if the binary exists
  if [[ ! -f "$bin" ]]; then
    continue
  fi

  # Check if profile exists
  profile_name=$(basename "$bin")
  if echo "$aa_output" | grep -q "$profile_name"; then
    # Check if in enforce mode
    if echo "$aa_output" | grep -A1000 "enforce mode" | grep -q "$profile_name"; then
      register_check "Profile: $name" PASS "enforce mode"
    else
      register_check "Profile: $name" WARN "loaded (not enforcing)"
    fi
  else
    register_check "Profile: $name" WARN "no profile"
  fi
done

section "Profile Directory Contents"

# Check /etc/apparmor.d
profile_dir="/etc/apparmor.d"
if [[ -d "$profile_dir" ]]; then
  # Count profile files
  profile_count=$(find "$profile_dir" -maxdepth 1 -type f -name "[a-z]*" 2>/dev/null | wc -l || echo "0")
  register_check "Profile definitions" PASS "$profile_count in $profile_dir"

  # Check for disabled profiles
  disabled_dir="$profile_dir/disable"
  if [[ -d "$disabled_dir" ]]; then
    disabled_count=$(find "$disabled_dir" -type l 2>/dev/null | wc -l || echo "0")
    if [[ "$disabled_count" -gt 0 ]]; then
      register_check "Disabled profiles" WARN "$disabled_count disabled"
    else
      register_check "Disabled profiles" PASS "none"
    fi
  fi

  # Check for local customizations
  if [[ -d "$profile_dir/local" ]]; then
    local_count=$(find "$profile_dir/local" -type f -size +0 2>/dev/null | wc -l || echo "0")
    if [[ "$local_count" -gt 0 ]]; then
      register_check "Local customizations" PASS "$local_count files"
    else
      register_check "Local customizations" PASS "none"
    fi
  fi
else
  register_check "Profile directory" FAIL "missing $profile_dir"
fi

section "Tunables Configuration"

tunables_dir="/etc/apparmor.d/tunables"
if [[ -d "$tunables_dir" ]]; then
  register_check "Tunables directory" PASS "exists"

  # Check home directory tunables
  if [[ -f "$tunables_dir/home" ]]; then
    register_check "Home tunables" PASS "configured"
  fi

  # Check for custom tunables
  if [[ -d "$tunables_dir/home.d" ]]; then
    custom_home=$(find "$tunables_dir/home.d" -type f 2>/dev/null | wc -l || echo "0")
    if [[ "$custom_home" -gt 0 ]]; then
      register_check "Custom home tunables" PASS "$custom_home files"
    fi
  fi
fi

section "AppArmor Service Status"

# Check if AppArmor service is enabled
if command -v systemctl >/dev/null 2>&1; then
  if systemctl is-enabled apparmor.service >/dev/null 2>&1; then
    register_check "AppArmor service enabled" PASS "yes"
  else
    register_check "AppArmor service enabled" FAIL "not enabled"
  fi

  if systemctl is-active apparmor.service >/dev/null 2>&1; then
    register_check "AppArmor service active" PASS "running"
  else
    register_check "AppArmor service active" FAIL "not running"
  fi
fi

section "Kernel Boot Parameters"

# Check for kernel parameters that affect AppArmor
if [[ -f "/proc/cmdline" ]]; then
  cmdline=$(cat /proc/cmdline)

  # Check if AppArmor is disabled via kernel params
  if echo "$cmdline" | grep -qE "apparmor=0"; then
    register_check "Kernel params" FAIL "AppArmor disabled via kernel"
  else
    register_check "Kernel params" PASS "no AppArmor overrides"
  fi

  # Check security module selection
  if echo "$cmdline" | grep -qE "security="; then
    lsm=$(echo "$cmdline" | grep -oE "security=[a-z,]+" | cut -d= -f2)
    if echo "$lsm" | grep -q "apparmor"; then
      register_check "LSM selection" PASS "apparmor in: $lsm"
    else
      register_check "LSM selection" WARN "apparmor not in LSM list: $lsm"
    fi
  fi
fi

section "Audit Events"

# Check for AppArmor denials in logs
if [[ -f "/var/log/syslog" ]]; then
  denial_count=$(grep -c "apparmor=\"DENIED\"" /var/log/syslog 2>/dev/null || echo "0")
  if [[ "$denial_count" -gt 100 ]]; then
    register_check "Syslog denials" WARN "$denial_count denials"
  elif [[ "$denial_count" -gt 0 ]]; then
    register_check "Syslog denials" WARN "$denial_count (review recommended)"
  else
    register_check "Syslog denials" PASS "none"
  fi
elif [[ -f "/var/log/kern.log" ]]; then
  denial_count=$(grep -c "apparmor=\"DENIED\"" /var/log/kern.log 2>/dev/null || echo "0")
  if [[ "$denial_count" -gt 0 ]]; then
    register_check "Kernel log denials" WARN "$denial_count denials"
  else
    register_check "Kernel log denials" PASS "none"
  fi
fi

# Check audit.log if auditd is running
if [[ -f "/var/log/audit/audit.log" ]]; then
  audit_denials=$(grep -c "apparmor=\"DENIED\"" /var/log/audit/audit.log 2>/dev/null || echo "0")
  if [[ "$audit_denials" -gt 100 ]]; then
    register_check "Audit log denials" WARN "$audit_denials denials"
  elif [[ "$audit_denials" -gt 0 ]]; then
    register_check "Audit log denials" WARN "$audit_denials (review recommended)"
  else
    register_check "Audit log denials" PASS "none"
  fi
fi

section "AppArmor Tools"

# Check if management tools are installed
tools=(
  "aa-enforce:Profile enforcement"
  "aa-complain:Complain mode"
  "aa-disable:Profile disable"
  "aa-genprof:Profile generation"
  "aa-logprof:Log-based profile update"
  "aa-unconfined:Unconfined process check"
)

tools_missing=0
for entry in "${tools[@]}"; do
  tool="${entry%%:*}"
  desc="${entry##*:}"

  if command -v "$tool" >/dev/null 2>&1; then
    register_check "Tool: $tool" PASS "available"
  else
    register_check "Tool: $tool" WARN "not installed"
    ((tools_missing++)) || true
  fi
done

if [[ "$tools_missing" -gt 3 ]]; then
  register_check "AppArmor utils package" WARN "missing - install apparmor-utils"
fi

section "Container Integration"

# Check for container-related profiles
container_profiles=(
  "docker-default"
  "cri-containerd.apparmor.d"
  "lxc-container-default"
  "lxc-container-default-cgns"
)

for profile in "${container_profiles[@]}"; do
  if [[ -f "/etc/apparmor.d/$profile" ]] || echo "$aa_output" | grep -q "$profile"; then
    register_check "Container: $profile" PASS "present"
  fi
done

# Check if Docker uses AppArmor
if command -v docker >/dev/null 2>&1; then
  if docker info 2>/dev/null | grep -q "apparmor"; then
    register_check "Docker AppArmor" PASS "enabled"
  fi
fi

section "Profile Permissions"

# Check permissions on profile directory
if [[ -d "/etc/apparmor.d" ]]; then
  perms=$(stat -c "%a" /etc/apparmor.d 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" /etc/apparmor.d 2>/dev/null || echo "unknown")

  if [[ "$perms" == "755" ]] && [[ "$owner" == "root:root" ]]; then
    register_check "Profile dir permissions" PASS "$perms $owner"
  else
    register_check "Profile dir permissions" WARN "$perms $owner"
  fi
fi

# Check cache directory
cache_dir="/var/cache/apparmor"
if [[ -d "$cache_dir" ]]; then
  cache_owner=$(stat -c "%U" "$cache_dir" 2>/dev/null || echo "unknown")
  if [[ "$cache_owner" == "root" ]]; then
    register_check "Cache dir owner" PASS "root"
  else
    register_check "Cache dir owner" WARN "$cache_owner"
  fi
fi

print_summary
exit "$EXIT_CODE"
