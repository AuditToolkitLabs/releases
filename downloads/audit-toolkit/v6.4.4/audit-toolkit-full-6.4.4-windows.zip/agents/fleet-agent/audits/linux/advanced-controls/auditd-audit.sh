#!/usr/bin/env bash
# auditd-audit.sh — Comprehensive Auditd Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 4.1.x (Auditd Configuration)
# - NIST SP 800-53: AU-2, AU-3, AU-12 (Audit Events)
# - ISO 27001: A.12.4 (Logging and Monitoring)
# - PCI DSS: 10.2, 10.3, 10.5 (Audit Trails)
# - DISA STIG: V-204503-V-204567 (Audit Configuration)
#
# Checks:
# - Auditd service status
# - Auditd.conf settings
# - CIS 4.1 required rules
# - Privileged command auditing
# - Immutable rules
#
# @elevation: root
# @elevation-reason: auditctl and auditd configuration files require root to read
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

setup_colors

section "Auditd Installation & Service (CIS 4.1.1)"

# Check if auditd is installed
if ! command -v auditctl >/dev/null 2>&1; then
  register_check "Auditd installed" FAIL "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Auditd installed" PASS "present"

# Check service status
if is_systemd; then
  if systemctl is-active auditd >/dev/null 2>&1; then
    register_check "Auditd running" PASS "active"
  else
    register_check "Auditd running" FAIL "not running"
  fi

  if systemctl is-enabled auditd >/dev/null 2>&1; then
    register_check "Auditd enabled" PASS "enabled at boot"
  else
    register_check "Auditd enabled" FAIL "not enabled"
  fi
else
  if pgrep -x auditd >/dev/null 2>&1; then
    register_check "Auditd running" PASS "active"
  else
    register_check "Auditd running" FAIL "not running"
  fi
fi

section "Auditd Configuration (CIS 4.1.2)"

auditd_conf="/etc/audit/auditd.conf"
if [[ -f "$auditd_conf" ]]; then
  register_check "Auditd.conf" PASS "exists"

  # Check file permissions
  perms=$(stat -c "%a" "$auditd_conf" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "640" ]] || [[ "$perms" == "600" ]]; then
    register_check "Auditd.conf permissions" PASS "$perms"
  else
    register_check "Auditd.conf permissions" WARN "$perms (should be 640)"
  fi

  # max_log_file
  max_log=$(grep -E "^max_log_file\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ -n "$max_log" ]] && [[ "$max_log" -ge 8 ]]; then
    register_check "max_log_file" PASS "${max_log}MB"
  else
    register_check "max_log_file" WARN "${max_log:-not set} (recommend >= 8)"
  fi

  # max_log_file_action
  max_action=$(grep -E "^max_log_file_action\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ "$max_action" == "keep_logs" ]] || [[ "$max_action" == "rotate" ]]; then
    register_check "max_log_file_action" PASS "$max_action"
  else
    register_check "max_log_file_action" WARN "${max_action:-not set}"
  fi

  # space_left_action
  space_action=$(grep -E "^space_left_action\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ "$space_action" == "email" ]] || [[ "$space_action" == "exec" ]] || [[ "$space_action" == "syslog" ]]; then
    register_check "space_left_action" PASS "$space_action"
  else
    register_check "space_left_action" WARN "${space_action:-not set}"
  fi

  # admin_space_left_action
  admin_action=$(grep -E "^admin_space_left_action\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ "$admin_action" == "single" ]] || [[ "$admin_action" == "halt" ]]; then
    register_check "admin_space_left_action" PASS "$admin_action"
  else
    register_check "admin_space_left_action" WARN "${admin_action:-not set}"
  fi

  # disk_full_action
  disk_full=$(grep -E "^disk_full_action\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ "$disk_full" == "single" ]] || [[ "$disk_full" == "halt" ]]; then
    register_check "disk_full_action" PASS "$disk_full"
  else
    register_check "disk_full_action" WARN "${disk_full:-not set}"
  fi

  # disk_error_action
  disk_err=$(grep -E "^disk_error_action\s*=" "$auditd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ "$disk_err" == "single" ]] || [[ "$disk_err" == "halt" ]] || [[ "$disk_err" == "syslog" ]]; then
    register_check "disk_error_action" PASS "$disk_err"
  else
    register_check "disk_error_action" WARN "${disk_err:-not set}"
  fi
else
  register_check "Auditd.conf" FAIL "not found"
fi

section "Audit Log Permissions"

audit_log="/var/log/audit/audit.log"
if [[ -f "$audit_log" ]]; then
  perms=$(stat -c "%a" "$audit_log" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$audit_log" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
    register_check "Audit log permissions" PASS "$perms $owner"
  else
    register_check "Audit log permissions" WARN "$perms $owner (should be 600)"
  fi
fi

# Check audit log directory
audit_dir="/var/log/audit"
if [[ -d "$audit_dir" ]]; then
  dir_perms=$(stat -c "%a" "$audit_dir" 2>/dev/null || echo "unknown")
  if [[ "$dir_perms" == "700" ]] || [[ "$dir_perms" == "750" ]]; then
    register_check "Audit dir permissions" PASS "$dir_perms"
  else
    register_check "Audit dir permissions" WARN "$dir_perms"
  fi
fi

section "Time Change Rules (CIS 4.1.3)"

# Get all active rules
rules=$(auditctl -l 2>/dev/null || echo "")

# Check time change rules
time_rules_needed=(
  "adjtimex"
  "settimeofday"
  "clock_settime"
  "/etc/localtime"
)

time_found=0
for rule in "${time_rules_needed[@]}"; do
  if echo "$rules" | grep -q "$rule"; then
    ((time_found++)) || true
  fi
done

if [[ "$time_found" -ge 3 ]]; then
  register_check "Time change rules" PASS "$time_found/4 rules"
else
  register_check "Time change rules" WARN "$time_found/4 rules"
fi

section "Identity Rules (CIS 4.1.4)"

# User/group identity files
identity_files=(
  "/etc/group"
  "/etc/passwd"
  "/etc/gshadow"
  "/etc/shadow"
  "/etc/security/opasswd"
)

identity_found=0
for file in "${identity_files[@]}"; do
  if echo "$rules" | grep -q "$file"; then
    ((identity_found++)) || true
  fi
done

if [[ "$identity_found" -ge 4 ]]; then
  register_check "Identity file rules" PASS "$identity_found/5 files"
else
  register_check "Identity file rules" WARN "$identity_found/5 files"
fi

section "System Locale Rules (CIS 4.1.5)"

# Network configuration changes
locale_rules=(
  "sethostname"
  "setdomainname"
  "/etc/issue"
  "/etc/hosts"
)

locale_found=0
for rule in "${locale_rules[@]}"; do
  if echo "$rules" | grep -q "$rule"; then
    ((locale_found++)) || true
  fi
done

if [[ "$locale_found" -ge 3 ]]; then
  register_check "System locale rules" PASS "$locale_found/4 rules"
else
  register_check "System locale rules" WARN "$locale_found/4 rules"
fi

section "Login/Session Rules (CIS 4.1.6-4.1.7)"

# Login files
login_files=(
  "/var/log/lastlog"
  "/var/run/faillock"
  "/var/log/tallylog"
)

login_found=0
for file in "${login_files[@]}"; do
  if echo "$rules" | grep -q "$file"; then
    ((login_found++)) || true
  fi
done

if [[ "$login_found" -ge 1 ]]; then
  register_check "Login monitoring rules" PASS "$login_found rules"
else
  register_check "Login monitoring rules" WARN "none found"
fi

# Session files
session_files=(
  "/var/run/utmp"
  "/var/log/wtmp"
  "/var/log/btmp"
)

session_found=0
for file in "${session_files[@]}"; do
  if echo "$rules" | grep -q "$file"; then
    ((session_found++)) || true
  fi
done

if [[ "$session_found" -ge 2 ]]; then
  register_check "Session monitoring rules" PASS "$session_found/3 files"
else
  register_check "Session monitoring rules" WARN "$session_found/3 files"
fi

section "Privilege Escalation Rules (CIS 4.1.8)"

# Sudo configuration
sudo_rules=0
if echo "$rules" | grep -q "/etc/sudoers"; then
  ((sudo_rules++)) || true
fi
if echo "$rules" | grep -q "/etc/sudoers.d"; then
  ((sudo_rules++)) || true
fi

if [[ "$sudo_rules" -ge 2 ]]; then
  register_check "Sudo config rules" PASS "$sudo_rules/2 rules"
else
  register_check "Sudo config rules" WARN "$sudo_rules/2 rules"
fi

section "Kernel Module Rules (CIS 4.1.9)"

# Module loading
module_rules=(
  "insmod"
  "rmmod"
  "modprobe"
  "init_module"
  "delete_module"
)

module_found=0
for rule in "${module_rules[@]}"; do
  if echo "$rules" | grep -q "$rule"; then
    ((module_found++)) || true
  fi
done

if [[ "$module_found" -ge 3 ]]; then
  register_check "Kernel module rules" PASS "$module_found/5 rules"
else
  register_check "Kernel module rules" WARN "$module_found/5 rules"
fi

section "Privileged Commands (CIS 4.1.10-4.1.11)"

# Check for SUID/SGID binary auditing
priv_commands=$(echo "$rules" | grep -c "perm=x.*auid>=1000" || echo "0")
if [[ "$priv_commands" -gt 10 ]]; then
  register_check "Privileged command rules" PASS "$priv_commands rules"
elif [[ "$priv_commands" -gt 0 ]]; then
  register_check "Privileged command rules" WARN "$priv_commands rules (check coverage)"
else
  register_check "Privileged command rules" WARN "none found"
fi

# Check common privileged commands explicitly
priv_bins=(
  "/usr/bin/su"
  "/usr/bin/sudo"
  "/usr/bin/passwd"
  "/usr/bin/chsh"
  "/usr/bin/chage"
  "/usr/sbin/usermod"
)

priv_found=0
for bin in "${priv_bins[@]}"; do
  if echo "$rules" | grep -q "$bin"; then
    ((priv_found++)) || true
  fi
done

if [[ "$priv_found" -ge 4 ]]; then
  register_check "Common priv commands" PASS "$priv_found/6 monitored"
else
  register_check "Common priv commands" WARN "$priv_found/6 monitored"
fi

section "File Access Rules (CIS 4.1.12)"

# Failed access attempts
access_syscalls=(
  "creat"
  "open"
  "openat"
  "truncate"
  "ftruncate"
)

access_found=0
for syscall in "${access_syscalls[@]}"; do
  if echo "$rules" | grep -q "EACCES\|EPERM" 2>/dev/null && echo "$rules" | grep -q "$syscall"; then
    ((access_found++)) || true
  fi
done

if [[ "$access_found" -ge 2 ]]; then
  register_check "Failed access rules" PASS "$access_found syscalls"
else
  register_check "Failed access rules" WARN "limited coverage"
fi

section "Mount Operations (CIS 4.1.13)"

# Mount/unmount operations
if echo "$rules" | grep -qE "mount|umount"; then
  register_check "Mount operation rules" PASS "configured"
else
  register_check "Mount operation rules" WARN "not found"
fi

section "File Deletion Rules (CIS 4.1.14)"

# File deletion by users
if echo "$rules" | grep -qE "unlink|unlinkat|rename|renameat"; then
  register_check "File deletion rules" PASS "configured"
else
  register_check "File deletion rules" WARN "not found"
fi

section "MAC Policy Rules (CIS 4.1.15)"

# SELinux/AppArmor changes
mac_rules=0
if echo "$rules" | grep -q "/etc/selinux"; then
  ((mac_rules++)) || true
fi
if echo "$rules" | grep -q "/etc/apparmor"; then
  ((mac_rules++)) || true
fi
if echo "$rules" | grep -qE "semanage|setsebool|chcon"; then
  ((mac_rules++)) || true
fi

if [[ "$mac_rules" -ge 1 ]]; then
  register_check "MAC policy rules" PASS "$mac_rules rules"
else
  register_check "MAC policy rules" WARN "none found"
fi

section "Immutable Rules (CIS 4.1.17)"

# Check for -e 2 (immutable audit rules)
rules_files="/etc/audit/rules.d/*.rules"
immutable=false

for file in $rules_files; do
  [[ -f "$file" ]] || continue
  if grep -qE "^-e\s*2" "$file" 2>/dev/null; then
    immutable=true
    break
  fi
done

if $immutable; then
  register_check "Immutable rules (-e 2)" PASS "configured"
else
  register_check "Immutable rules (-e 2)" WARN "not set"
fi

section "Rule Statistics"

# Count total rules
total_rules=$(echo "$rules" | grep -c "^-" 2>/dev/null || echo "0")
register_check "Total active rules" PASS "$total_rules rules"

# Check rule file count
rules_d="/etc/audit/rules.d"
if [[ -d "$rules_d" ]]; then
  file_count=$(find "$rules_d" -name "*.rules" -type f 2>/dev/null | wc -l || echo "0")
  register_check "Rule files" PASS "$file_count files in rules.d"
fi

section "Backlog Status"

# Check current backlog
if [[ -f "/proc/sys/kernel/audit_backlog" ]]; then
  backlog=$(cat /proc/sys/kernel/audit_backlog 2>/dev/null || echo "N/A")
  backlog_limit=$(auditctl -s 2>/dev/null | grep "backlog_limit" | awk '{print $2}' || echo "N/A")

  if [[ "$backlog" != "N/A" ]] && [[ "$backlog_limit" != "N/A" ]]; then
    if [[ "$backlog" -lt "$((backlog_limit / 2))" ]]; then
      register_check "Audit backlog" PASS "$backlog / $backlog_limit"
    else
      register_check "Audit backlog" WARN "$backlog / $backlog_limit (high)"
    fi
  fi
fi

# Check for lost events
audit_status=$(auditctl -s 2>/dev/null || echo "")
if [[ -n "$audit_status" ]]; then
  lost=$(echo "$audit_status" | grep "lost" | awk '{print $2}')
  if [[ -n "$lost" ]] && [[ "$lost" -gt 0 ]]; then
    register_check "Lost events" WARN "$lost events lost"
  else
    register_check "Lost events" PASS "none"
  fi
fi

print_summary
exit "$EXIT_CODE"
