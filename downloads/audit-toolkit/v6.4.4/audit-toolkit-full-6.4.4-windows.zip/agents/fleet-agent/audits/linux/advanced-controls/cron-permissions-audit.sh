#!/usr/bin/env bash
# cron-permissions-audit.sh — Cron & At Daemon Security Audit
#
# @elevation: root
# @elevation-reason: Checks cron and at configuration files
#
# Compliance Mapping:
# - CIS Benchmark: 5.1.x (Configure cron and at)
# - NIST SP 800-53: CM-7 (Least Functionality), AC-3 (Access Enforcement)
# - ISO 27001: A.12.5.1 (Installation of Software)
# - PCI DSS: 2.2 (System Hardening)
#
# Checks:
# - Cron daemon status (5.1.1)
# - /etc/crontab permissions (5.1.2)
# - /etc/cron.hourly|daily|weekly|monthly permissions (5.1.3-5.1.6)
# - /etc/cron.d permissions (5.1.7)
# - cron.allow and cron.deny (5.1.8)
# - at.allow and at.deny (5.1.9)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../lib/svc.sh"

setup_colors

section "Cron & At Daemon Security Audit (CIS 5.1.x)"
echo "Compliance: CIS 5.1.1-5.1.9, NIST CM-7/AC-3, PCI DSS 2.2"

# ============================================================
# CIS 5.1.1: Ensure cron daemon is enabled and running
# ============================================================
section "Cron Daemon Status (CIS 5.1.1)"

# Cron service name varies by distro
cron_active=false
for svc_name in cron crond; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Cron service (5.1.1)" PASS "$svc_name is active"
    cron_active=true
    break
  fi
done

if ! $cron_active; then
  register_check "Cron service (5.1.1)" FAIL "Not active"
fi

# ============================================================
# CIS 5.1.2: Ensure /etc/crontab permissions
# ============================================================
section "Crontab File (CIS 5.1.2)"

if [[ -f /etc/crontab ]]; then
  crontab_perms=$(stat -c "%a" /etc/crontab 2>/dev/null || echo "unknown")
  crontab_owner=$(stat -c "%U:%G" /etc/crontab 2>/dev/null || echo "unknown")

  if [[ "$crontab_perms" == "600" || "$crontab_perms" == "400" ]] && \
     [[ "$crontab_owner" == "root:root" ]]; then
    register_check "/etc/crontab perms (5.1.2)" PASS "perms=$crontab_perms owner=$crontab_owner"
  else
    register_check "/etc/crontab perms (5.1.2)" FAIL \
      "perms=$crontab_perms owner=$crontab_owner (should be 600 root:root)"
  fi
else
  register_check "/etc/crontab (5.1.2)" WARN "File not found"
fi

# ============================================================
# CIS 5.1.3-5.1.6: Cron directories
# ============================================================
section "Cron Directories (CIS 5.1.3-5.1.6)"

declare -A CRON_DIRS=(
  ["/etc/cron.hourly"]="5.1.3"
  ["/etc/cron.daily"]="5.1.4"
  ["/etc/cron.weekly"]="5.1.5"
  ["/etc/cron.monthly"]="5.1.6"
)

for dir in "${!CRON_DIRS[@]}"; do
  cis_ref="${CRON_DIRS[$dir]}"
  if [[ -d "$dir" ]]; then
    dir_perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "unknown")
    dir_owner=$(stat -c "%U:%G" "$dir" 2>/dev/null || echo "unknown")

    if [[ "$dir_perms" == "700" ]] && [[ "$dir_owner" == "root:root" ]]; then
      register_check "$dir ($cis_ref)" PASS "perms=$dir_perms owner=$dir_owner"
    else
      register_check "$dir ($cis_ref)" WARN \
        "perms=$dir_perms owner=$dir_owner (should be 700 root:root)"
    fi
  else
    register_check "$dir ($cis_ref)" SKIP "Directory not found"
  fi
done

# ============================================================
# CIS 5.1.7: /etc/cron.d permissions
# ============================================================
section "Cron.d Directory (CIS 5.1.7)"

if [[ -d /etc/cron.d ]]; then
  crond_perms=$(stat -c "%a" /etc/cron.d 2>/dev/null || echo "unknown")
  crond_owner=$(stat -c "%U:%G" /etc/cron.d 2>/dev/null || echo "unknown")

  if [[ "$crond_perms" == "700" ]] && [[ "$crond_owner" == "root:root" ]]; then
    register_check "/etc/cron.d (5.1.7)" PASS "perms=$crond_perms owner=$crond_owner"
  else
    register_check "/etc/cron.d (5.1.7)" WARN \
      "perms=$crond_perms owner=$crond_owner (should be 700 root:root)"
  fi

  # Check files inside cron.d
  bad_crond_files=0
  for f in /etc/cron.d/*; do
    [[ -f "$f" ]] || continue
    f_perms=$(stat -c "%a" "$f" 2>/dev/null || echo "644")
    f_owner=$(stat -c "%U" "$f" 2>/dev/null || echo "unknown")
    if [[ "$f_perms" -gt "600" ]] || [[ "$f_owner" != "root" ]]; then
      ((bad_crond_files++)) || true
    fi
  done

  if [[ $bad_crond_files -gt 0 ]]; then
    register_check "cron.d file perms" WARN "$bad_crond_files files need review"
  else
    register_check "cron.d file perms" PASS "All files properly secured"
  fi
else
  register_check "/etc/cron.d (5.1.7)" SKIP "Directory not found"
fi

# ============================================================
# CIS 5.1.8: Ensure cron is restricted to authorized users
# ============================================================
section "Cron Access Control (CIS 5.1.8)"

# cron.allow should exist and cron.deny should not (or vice versa)
if [[ -f /etc/cron.allow ]]; then
  allow_perms=$(stat -c "%a" /etc/cron.allow 2>/dev/null || echo "unknown")
  allow_owner=$(stat -c "%U:%G" /etc/cron.allow 2>/dev/null || echo "unknown")

  if [[ "$allow_perms" == "600" || "$allow_perms" == "640" ]] && \
     [[ "$allow_owner" == "root:root" || "$allow_owner" == "root:crontab" ]]; then
    user_count=$(wc -l < /etc/cron.allow 2>/dev/null || echo 0)
    register_check "cron.allow (5.1.8)" PASS "$user_count authorized users"
  else
    register_check "cron.allow (5.1.8)" WARN "perms=$allow_perms (should be 600)"
  fi
else
  register_check "cron.allow (5.1.8)" WARN "Not configured (consider creating)"
fi

if [[ -f /etc/cron.deny ]]; then
  deny_perms=$(stat -c "%a" /etc/cron.deny 2>/dev/null || echo "unknown")
  if [[ "$deny_perms" == "600" || "$deny_perms" == "640" ]]; then
    register_check "cron.deny perms" PASS "$deny_perms"
  else
    register_check "cron.deny perms" WARN "$deny_perms (should be 600)"
  fi
else
  # If neither cron.allow nor cron.deny exists, all users can use cron
  if [[ ! -f /etc/cron.allow ]]; then
    register_check "cron access" WARN "No cron.allow or cron.deny - all users allowed"
  fi
fi

# ============================================================
# CIS 5.1.9: Ensure at is restricted to authorized users
# ============================================================
section "At Daemon Access Control (CIS 5.1.9)"

# Check if at is installed
if command -v at >/dev/null 2>&1 || command -v atd >/dev/null 2>&1; then
  register_check "at daemon installed" PASS "present"

  # Check at service status
  if svc_is_active atd 2>/dev/null; then
    register_check "atd service" PASS "active"
  else
    register_check "atd service" WARN "not active"
  fi

  # Check at.allow
  if [[ -f /etc/at.allow ]]; then
    at_allow_perms=$(stat -c "%a" /etc/at.allow 2>/dev/null || echo "unknown")
    at_allow_owner=$(stat -c "%U:%G" /etc/at.allow 2>/dev/null || echo "unknown")

    if [[ "$at_allow_perms" == "600" || "$at_allow_perms" == "640" ]] && \
       [[ "$at_allow_owner" =~ ^root: ]]; then
      user_count=$(wc -l < /etc/at.allow 2>/dev/null || echo 0)
      register_check "at.allow (5.1.9)" PASS "$user_count authorized users"
    else
      register_check "at.allow (5.1.9)" WARN "perms=$at_allow_perms (should be 600)"
    fi
  else
    register_check "at.allow (5.1.9)" WARN "Not configured (consider creating)"
  fi

  if [[ -f /etc/at.deny ]]; then
    at_deny_perms=$(stat -c "%a" /etc/at.deny 2>/dev/null || echo "unknown")
    if [[ "$at_deny_perms" == "600" || "$at_deny_perms" == "640" ]]; then
      register_check "at.deny perms" PASS "$at_deny_perms"
    else
      register_check "at.deny perms" WARN "$at_deny_perms (should be 600)"
    fi
  else
    if [[ ! -f /etc/at.allow ]]; then
      register_check "at access" WARN "No at.allow or at.deny - all users allowed"
    fi
  fi
else
  register_check "at daemon (5.1.9)" SKIP "Not installed"
fi

print_summary
exit "$EXIT_CODE"
