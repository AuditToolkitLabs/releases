#!/usr/bin/env bash
# =============================================================================
# CUPS Printing Service Security Audit
# =============================================================================
# CIS Reference: CIS 2.2.2 (Ensure CUPS is not installed)
# NIST SP 800-53: CM-7 (Least Functionality), AC-3, SC-8
#
# Audits CUPS printing configuration security:
# - CUPS installation status
# - Network listening configuration
# - Access control (allowed hosts/users)
# - Web interface security
# - SSL/TLS configuration
# - Log configuration
#
# @elevation: partial
# @elevation-reason: Service checks and most config files readable without root, some require root
#
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../../lib/common.sh
. "${SCRIPT_DIR}/../../../lib/common.sh"
# shellcheck source=../../../lib/distro.sh
. "${SCRIPT_DIR}/../../../lib/distro.sh"
# shellcheck source=../../../lib/pkg.sh
. "${SCRIPT_DIR}/../../../lib/pkg.sh"
# shellcheck source=../../../lib/svc.sh
. "${SCRIPT_DIR}/../../../lib/svc.sh"

# =============================================================================
# CUPS Installation Detection
# =============================================================================

section "CUPS Installation Status"

CUPS_INSTALLED=false

# Check for CUPS packages
cups_packages=("cups" "cups-daemon" "cups-server" "cups-common")
installed_cups=""

for pkg in "${cups_packages[@]}"; do
    if pkg_installed "$pkg" 2>/dev/null; then
        installed_cups+="$pkg "
        CUPS_INSTALLED=true
    fi
done

if [[ "$CUPS_INSTALLED" == "true" ]]; then
    register_check "CUPS packages" INFO "Installed: $installed_cups"
else
    register_check "CUPS packages" PASS "Not installed (CIS 2.2.2 compliant)"
    print_summary
    exit "$EXIT_CODE"
fi

# =============================================================================
# CUPS Service Status
# =============================================================================

section "CUPS Service Status"

# Check if CUPS service is running
cups_running=false
if is_systemd; then
    if systemctl is-active cups >/dev/null 2>&1; then
        cups_running=true
        register_check "CUPS service" WARN "Running (disable if not needed)"
    elif systemctl is-enabled cups >/dev/null 2>&1; then
        register_check "CUPS service" INFO "Enabled but not running"
    else
        register_check "CUPS service" PASS "Not enabled"
    fi

    # Check cups-browsed (auto-discovery, security risk)
    if systemctl is-active cups-browsed >/dev/null 2>&1; then
        register_check "cups-browsed service" WARN "Running (printer auto-discovery enabled)"
    else
        register_check "cups-browsed service" PASS "Not running"
    fi
elif is_openrc; then
    if rc-service cupsd status >/dev/null 2>&1; then
        cups_running=true
        register_check "CUPS service" WARN "Running"
    else
        register_check "CUPS service" PASS "Not running"
    fi
fi

# If CUPS is not running, many checks below may not apply
if [[ "$cups_running" == "false" ]]; then
    register_check "CUPS security checks" SKIP "Service not running"
    print_summary
    exit "$EXIT_CODE"
fi

# =============================================================================
# CUPS Configuration Files
# =============================================================================

section "CUPS Configuration Security"

cupsd_conf="/etc/cups/cupsd.conf"
if [[ -f "$cupsd_conf" ]]; then
    register_check "cupsd.conf exists" PASS "$cupsd_conf"

    # Check file permissions
    conf_perms=$(stat -c "%a" "$cupsd_conf" 2>/dev/null)
    if [[ "$conf_perms" == "640" ]] || [[ "$conf_perms" == "644" ]]; then
        register_check "cupsd.conf permissions" PASS "$conf_perms"
    else
        register_check "cupsd.conf permissions" WARN "$conf_perms (recommend 640)"
    fi

    # Check ownership
    conf_owner=$(stat -c "%U:%G" "$cupsd_conf" 2>/dev/null)
    if [[ "$conf_owner" == "root:lp" ]] || [[ "$conf_owner" == "root:root" ]]; then
        register_check "cupsd.conf ownership" PASS "$conf_owner"
    else
        register_check "cupsd.conf ownership" WARN "$conf_owner"
    fi
else
    register_check "cupsd.conf exists" FAIL "Not found"
fi

# =============================================================================
# Network Listening Configuration
# =============================================================================

section "Network Listening"

if [[ -f "$cupsd_conf" ]]; then
    # Check Listen directives
    listen_directives=$(grep -E "^Listen|^Port" "$cupsd_conf" 2>/dev/null || echo "")

    if [[ -n "$listen_directives" ]]; then
        # Check if listening on all interfaces
        if echo "$listen_directives" | grep -qE "Listen\s+\*:|Port\s+631"; then
            register_check "CUPS network binding" FAIL "Listening on all interfaces"
        elif echo "$listen_directives" | grep -qE "Listen\s+localhost:|Listen\s+127\.0\.0\.1:"; then
            register_check "CUPS network binding" PASS "Listening only on localhost"
        elif echo "$listen_directives" | grep -qE "Listen\s+/"; then
            register_check "CUPS network binding" PASS "Using Unix socket"
        else
            register_check "CUPS network binding" INFO "$listen_directives"
        fi
    else
        register_check "CUPS network binding" INFO "Default configuration"
    fi

    # Check for Browsing (network printer discovery)
    browsing=$(grep -E "^Browsing" "$cupsd_conf" 2>/dev/null | awk '{print $2}' | head -1)
    if [[ "$browsing" == "Off" ]] || [[ "$browsing" == "No" ]]; then
        register_check "CUPS Browsing" PASS "Disabled"
    elif [[ "$browsing" == "On" ]] || [[ "$browsing" == "Yes" ]]; then
        register_check "CUPS Browsing" WARN "Enabled (network discovery)"
    else
        register_check "CUPS Browsing" INFO "Default (usually Off)"
    fi

    # Check BrowseLocalProtocols
    browse_protocols=$(grep -E "^BrowseLocalProtocols" "$cupsd_conf" 2>/dev/null || echo "")
    if [[ -n "$browse_protocols" ]]; then
        if echo "$browse_protocols" | grep -qi "none"; then
            register_check "BrowseLocalProtocols" PASS "None"
        else
            register_check "BrowseLocalProtocols" INFO "$browse_protocols"
        fi
    fi
fi

# Check actual listening ports
if command -v ss >/dev/null 2>&1; then
    cups_listen=$(ss -tlnp 2>/dev/null | grep -E ":631\s" || echo "")
    if [[ -n "$cups_listen" ]]; then
        if echo "$cups_listen" | grep -q "127.0.0.1:631"; then
            register_check "CUPS port 631" PASS "Bound to localhost"
        elif echo "$cups_listen" | grep -qE "\*:631|0\.0\.0\.0:631|:::631"; then
            register_check "CUPS port 631" FAIL "Listening on all interfaces"
        else
            register_check "CUPS port 631" INFO "Custom binding"
        fi
    fi
elif command -v netstat >/dev/null 2>&1; then
    cups_listen=$(netstat -tlnp 2>/dev/null | grep ":631 " || echo "")
    if [[ -n "$cups_listen" ]]; then
        register_check "CUPS listening" INFO "Port 631 in use"
    fi
fi

# =============================================================================
# Web Interface Security
# =============================================================================

section "Web Interface Security"

if [[ -f "$cupsd_conf" ]]; then
    # Check if web interface is enabled
    web_interface=$(grep -E "^WebInterface" "$cupsd_conf" 2>/dev/null | awk '{print $2}' | head -1)
    if [[ "$web_interface" == "No" ]]; then
        register_check "CUPS Web Interface" PASS "Disabled"
    elif [[ "$web_interface" == "Yes" ]]; then
        register_check "CUPS Web Interface" WARN "Enabled (https://localhost:631)"
    else
        register_check "CUPS Web Interface" INFO "Default (usually Yes)"
    fi

    # Check for authentication requirements
    # Look for <Location /> blocks
    if grep -qE "<Location\s+/>" "$cupsd_conf" 2>/dev/null; then
        # Check if auth is required
        if grep -A10 "<Location />" "$cupsd_conf" 2>/dev/null | grep -qE "AuthType|Require valid-user"; then
            register_check "Web auth root location" PASS "Authentication configured"
        else
            register_check "Web auth root location" INFO "Open access to root"
        fi
    fi

    # Check /admin location
    if grep -qE "<Location\s+/admin>" "$cupsd_conf" 2>/dev/null; then
        admin_auth=$(grep -A10 "<Location /admin>" "$cupsd_conf" 2>/dev/null)
        if echo "$admin_auth" | grep -qE "AuthType\s+Default|AuthType\s+Basic"; then
            register_check "Admin interface auth" PASS "Authentication required"
        else
            register_check "Admin interface auth" WARN "Check authentication settings"
        fi

        # Check for @SYSTEM group restriction
        if echo "$admin_auth" | grep -qE "Require\s+user\s+@SYSTEM"; then
            register_check "Admin access restriction" PASS "Restricted to @SYSTEM"
        fi
    fi
fi

# =============================================================================
# SSL/TLS Configuration
# =============================================================================

section "SSL/TLS Configuration"

if [[ -f "$cupsd_conf" ]]; then
    # Check DefaultEncryption
    default_enc=$(grep -E "^DefaultEncryption" "$cupsd_conf" 2>/dev/null | awk '{print $2}' | head -1)
    case "$default_enc" in
        Required)
            register_check "DefaultEncryption" PASS "Required"
            ;;
        IfRequested)
            register_check "DefaultEncryption" WARN "IfRequested (consider Required)"
            ;;
        Never)
            register_check "DefaultEncryption" FAIL "Never (no encryption)"
            ;;
        *)
            register_check "DefaultEncryption" INFO "Default (IfRequested)"
            ;;
    esac
fi

# Check for SSL certificates
cups_ssl_dir="/etc/cups/ssl"
if [[ -d "$cups_ssl_dir" ]]; then
    # Check for server certificate
    if [[ -f "$cups_ssl_dir/server.crt" ]] || [[ -f "$cups_ssl_dir/server.pem" ]]; then
        register_check "CUPS SSL certificate" PASS "Found"

        # Check certificate permissions
        # shellcheck disable=SC2231
        for cert in "$cups_ssl_dir"/*.crt "$cups_ssl_dir"/*.pem "$cups_ssl_dir"/*.key; do
            [[ -e "$cert" ]] || continue
            if [[ -f "$cert" ]]; then
                cert_perms=$(stat -c "%a" "$cert")
                if [[ "$cert_perms" == "600" ]] || [[ "$cert_perms" == "640" ]]; then
                    register_check "SSL file: $(basename "$cert")" PASS "$cert_perms"
                else
                    register_check "SSL file: $(basename "$cert")" WARN "$cert_perms"
                fi
            fi
        done
    else
        register_check "CUPS SSL certificate" INFO "Using auto-generated"
    fi
fi

# =============================================================================
# Access Control
# =============================================================================

section "Access Control"

if [[ -f "$cupsd_conf" ]]; then
    # Check for host-based access control
    allow_directives=$(grep -E "^Allow|^Deny" "$cupsd_conf" 2>/dev/null || echo "")

    if [[ -n "$allow_directives" ]]; then
        # Check for Allow from all
        if echo "$allow_directives" | grep -qiE "Allow\s+all"; then
            register_check "Host access control" FAIL "Allow all configured"
        elif echo "$allow_directives" | grep -qiE "Allow\s+@LOCAL"; then
            register_check "Host access control" WARN "@LOCAL allows local network"
        elif echo "$allow_directives" | grep -qiE "Allow\s+localhost|Allow\s+127\."; then
            register_check "Host access control" PASS "Restricted to localhost"
        fi
    fi

    # Check Order directive
    order=$(grep -E "^Order" "$cupsd_conf" 2>/dev/null | head -1)
    if [[ -n "$order" ]]; then
        if echo "$order" | grep -qi "deny,allow"; then
            register_check "Order directive" PASS "deny,allow (default deny)"
        elif echo "$order" | grep -qi "allow,deny"; then
            register_check "Order directive" WARN "allow,deny (default allow)"
        fi
    fi
fi

# =============================================================================
# Log Configuration
# =============================================================================

section "Logging Configuration"

if [[ -f "$cupsd_conf" ]]; then
    # Check LogLevel
    log_level=$(grep -E "^LogLevel" "$cupsd_conf" 2>/dev/null | awk '{print $2}' | head -1)
    case "$log_level" in
        debug|debug2)
            register_check "CUPS LogLevel" INFO "$log_level (verbose)"
            ;;
        info|warn)
            register_check "CUPS LogLevel" PASS "$log_level"
            ;;
        error|none)
            register_check "CUPS LogLevel" WARN "$log_level (minimal logging)"
            ;;
        *)
            register_check "CUPS LogLevel" INFO "Default (warn)"
            ;;
    esac

    # Check access log
    access_log=$(grep -E "^AccessLog" "$cupsd_conf" 2>/dev/null | awk '{print $2}')
    if [[ -n "$access_log" ]] && [[ "$access_log" != "none" ]]; then
        register_check "CUPS AccessLog" PASS "$access_log"
    elif [[ "$access_log" == "none" ]]; then
        register_check "CUPS AccessLog" WARN "Disabled"
    fi
fi

# Check log file permissions
cups_log_dir="/var/log/cups"
if [[ -d "$cups_log_dir" ]]; then
    log_perms=$(stat -c "%a" "$cups_log_dir" 2>/dev/null)
    if [[ "$log_perms" == "755" ]] || [[ "$log_perms" == "750" ]]; then
        register_check "CUPS log directory" PASS "$log_perms"
    else
        register_check "CUPS log directory" WARN "$log_perms"
    fi
fi

# =============================================================================
# IPP Configuration
# =============================================================================

section "IPP Protocol Security"

# Check if IPP Everywhere is enabled
if grep -qrE "share-printers" /etc/cups/ 2>/dev/null; then
    register_check "Printer sharing" WARN "Printer sharing may be enabled"
fi

# Check for remote printing protocols
if [[ -f "$cupsd_conf" ]]; then
    # Check ServerAlias
    server_alias=$(grep -E "^ServerAlias" "$cupsd_conf" 2>/dev/null || echo "")
    if [[ -n "$server_alias" ]]; then
        if echo "$server_alias" | grep -q "\*"; then
            register_check "ServerAlias" WARN "Wildcard (*) configured"
        else
            register_check "ServerAlias" PASS "Restricted"
        fi
    fi
fi

# =============================================================================
# Printer Configuration
# =============================================================================

section "Printer Configuration"

printers_conf="/etc/cups/printers.conf"
if [[ -f "$printers_conf" ]]; then
    # Count configured printers
    printer_count=$(grep -c "^<Printer" "$printers_conf" 2>/dev/null || echo "0")
    register_check "Configured printers" INFO "$printer_count printers"

    # Check for shared printers
    shared_count=$(grep -c "Shared Yes" "$printers_conf" 2>/dev/null || echo "0")
    if [[ "$shared_count" -gt 0 ]]; then
        register_check "Shared printers" WARN "$shared_count printers shared"
    else
        register_check "Shared printers" PASS "None shared"
    fi
fi

# =============================================================================
# Security Recommendations
# =============================================================================

section "Security Summary"

echo ""
echo "CUPS Security Recommendations:"
echo "  1. Disable CUPS if printing not required (CIS 2.2.2)"
echo "  2. Bind only to localhost if remote printing not needed"
echo "  3. Disable Browsing and cups-browsed service"
echo "  4. Set DefaultEncryption to Required"
echo "  5. Require authentication for /admin location"
echo "  6. Review printer sharing settings"
echo "  7. Monitor /var/log/cups/access_log"
echo ""

print_summary
exit "$EXIT_CODE"
