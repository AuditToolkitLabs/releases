#!/usr/bin/env bash
# file-integrity-audit.sh — AIDE File Integrity Audit
#
# @elevation: root
# @elevation-reason: AIDE and Tripwire database access require root privileges
#

set -euo pipefail
. "$(dirname "$0")/../../../lib/common.sh"
. "$(dirname "$0")/../../../lib/distro.sh"
section "File Integrity (AIDE)"

if command -v aide >/dev/null; then
  register_check "AIDE installed" PASS "AIDE present"
else
  register_check "AIDE installed" FAIL "AIDE not found"
fi

print_summary
exit "$EXIT_CODE"
