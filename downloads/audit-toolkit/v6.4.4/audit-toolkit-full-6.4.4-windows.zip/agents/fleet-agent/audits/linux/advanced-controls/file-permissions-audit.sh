#!/usr/bin/env bash
# file-permissions-audit.sh — Critical File Permissions Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.1.x (System File Permissions)
# - NIST SP 800-53: AC-3, AC-6 (Access Enforcement, Least Privilege)
# - ISO 27001: A.9.4.1 (Information Access Restriction)
# - PCI DSS: 7.1 (Limit Access to System Components)
# - DISA STIG: V-204392-V-204400 (File Permissions)
#
# Checks:
# - Critical config file permissions
# - SUID/SGID binaries
# - World-writable files
# - Unowned files
# - Sticky bit on world-writable directories
#
# @elevation: partial
# @elevation-reason: Some file permission checks readable without root, SUID/SGID search may need root for full coverage
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

section "Critical File Permissions Audit"

# Helper function to check file permissions
check_file_perms() {
  local file="$1"
  local expected_perms="$2"
  local expected_owner="$3"
  local name="$4"

  if [[ ! -e "$file" ]]; then
    register_check "$name" SKIP "not present"
    return
  fi

  local actual_perms actual_owner
  actual_perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")
  actual_owner=$(stat -c "%U:%G" "$file" 2>/dev/null || echo "unknown")

  local perms_ok=false
  local owner_ok=false

  # Check permissions (expected can be multiple values separated by |)
  if echo "$expected_perms" | grep -qE "(^|\\|)${actual_perms}(\\||$)"; then
    perms_ok=true
  fi

  # Check ownership (expected can be multiple values separated by |)
  if echo "$expected_owner" | grep -qE "(^|\\|)${actual_owner}(\\||$)"; then
    owner_ok=true
  fi

  if $perms_ok && $owner_ok; then
    register_check "$name" PASS "$actual_perms $actual_owner"
  elif $perms_ok; then
    register_check "$name" WARN "perms OK ($actual_perms), owner: $actual_owner (expected: $expected_owner)"
  elif $owner_ok; then
    register_check "$name" WARN "owner OK ($actual_owner), perms: $actual_perms (expected: $expected_perms)"
  else
    register_check "$name" FAIL "perms: $actual_perms (expected: $expected_perms), owner: $actual_owner"
  fi
}

section "Authentication Files (CIS 6.1.1-6.1.4)"

# /etc/passwd - CIS 6.1.1
check_file_perms "/etc/passwd" "644" "root:root" "/etc/passwd"

# /etc/shadow - CIS 6.1.3 (should be 0 or 600, owned by root:root or root:shadow)
check_file_perms "/etc/shadow" "0|000|600|640" "root:root|root:shadow" "/etc/shadow"

# /etc/group - CIS 6.1.2
check_file_perms "/etc/group" "644" "root:root" "/etc/group"

# /etc/gshadow - CIS 6.1.4
check_file_perms "/etc/gshadow" "0|000|600|640" "root:root|root:shadow" "/etc/gshadow"

# /etc/passwd- (backup)
check_file_perms "/etc/passwd-" "600|644" "root:root" "/etc/passwd-"

# /etc/shadow- (backup)
check_file_perms "/etc/shadow-" "0|000|600" "root:root|root:shadow" "/etc/shadow-"

section "SSH Configuration (CIS 5.2.1)"

# /etc/ssh/sshd_config
check_file_perms "/etc/ssh/sshd_config" "600|644" "root:root" "/etc/ssh/sshd_config"

# SSH host keys (private)
for key in /etc/ssh/ssh_host_*_key; do
  [[ -f "$key" ]] || continue
  check_file_perms "$key" "600" "root:root" "$(basename "$key")"
done

# SSH host keys (public)
for key in /etc/ssh/ssh_host_*_key.pub; do
  [[ -f "$key" ]] || continue
  check_file_perms "$key" "644" "root:root" "$(basename "$key")"
done

section "Cron Configuration (CIS 5.1.x)"

# /etc/crontab - CIS 5.1.2
check_file_perms "/etc/crontab" "600|700" "root:root" "/etc/crontab"

# Cron directories
check_file_perms "/etc/cron.hourly" "700" "root:root" "/etc/cron.hourly"
check_file_perms "/etc/cron.daily" "700" "root:root" "/etc/cron.daily"
check_file_perms "/etc/cron.weekly" "700" "root:root" "/etc/cron.weekly"
check_file_perms "/etc/cron.monthly" "700" "root:root" "/etc/cron.monthly"
check_file_perms "/etc/cron.d" "700" "root:root" "/etc/cron.d"

# cron.allow / cron.deny
if [[ -f "/etc/cron.allow" ]]; then
  check_file_perms "/etc/cron.allow" "600|640" "root:root" "/etc/cron.allow"
fi
if [[ -f "/etc/cron.deny" ]]; then
  check_file_perms "/etc/cron.deny" "600|640" "root:root" "/etc/cron.deny"
fi

# at.allow / at.deny
if [[ -f "/etc/at.allow" ]]; then
  check_file_perms "/etc/at.allow" "600|640" "root:root" "/etc/at.allow"
fi

section "Boot & Security Configuration"

# GRUB config
if [[ -f "/boot/grub2/grub.cfg" ]]; then
  check_file_perms "/boot/grub2/grub.cfg" "600" "root:root" "grub.cfg (grub2)"
elif [[ -f "/boot/grub/grub.cfg" ]]; then
  check_file_perms "/boot/grub/grub.cfg" "600" "root:root" "grub.cfg"
fi

# /etc/login.defs
check_file_perms "/etc/login.defs" "644" "root:root" "/etc/login.defs"

# /etc/security directory
check_file_perms "/etc/security" "755" "root:root" "/etc/security dir"

# PAM files
check_file_perms "/etc/pam.d" "755" "root:root" "/etc/pam.d dir"

section "Network Configuration"

# /etc/hosts
check_file_perms "/etc/hosts" "644" "root:root" "/etc/hosts"

# /etc/hosts.allow
if [[ -f "/etc/hosts.allow" ]]; then
  check_file_perms "/etc/hosts.allow" "644" "root:root" "/etc/hosts.allow"
fi

# /etc/hosts.deny
if [[ -f "/etc/hosts.deny" ]]; then
  check_file_perms "/etc/hosts.deny" "644" "root:root" "/etc/hosts.deny"
fi

section "SUID Binaries (CIS 6.1.11)"

# Find SUID binaries
suid_count=0
known_suid=(
  "/usr/bin/passwd"
  "/usr/bin/chsh"
  "/usr/bin/chfn"
  "/usr/bin/newgrp"
  "/usr/bin/gpasswd"
  "/usr/bin/sudo"
  "/usr/bin/su"
  "/usr/bin/mount"
  "/usr/bin/umount"
  "/usr/bin/pkexec"
  "/usr/lib/polkit-1/polkit-agent-helper-1"
  "/usr/libexec/polkit-agent-helper-1"
  "/bin/su"
  "/bin/mount"
  "/bin/umount"
  "/bin/ping"
  "/usr/bin/ping"
)

# Find all SUID files (limit search to standard locations)
suid_files=$(find /usr /bin /sbin -perm /4000 -type f 2>/dev/null | sort || echo "")
suid_count=$(echo "$suid_files" | grep -c "^" || echo "0")

# Count unknown SUID
unknown_suid=0
for file in $suid_files; do
  is_known=false
  for known in "${known_suid[@]}"; do
    if [[ "$file" == "$known" ]]; then
      is_known=true
      break
    fi
  done
  if ! $is_known; then
    ((unknown_suid++)) || true
  fi
done

if [[ "$unknown_suid" -gt 0 ]]; then
  register_check "SUID binaries" WARN "$suid_count total, $unknown_suid non-standard"
else
  register_check "SUID binaries" PASS "$suid_count (all standard)"
fi

section "SGID Binaries (CIS 6.1.12)"

# Find SGID binaries
sgid_files=$(find /usr /bin /sbin -perm /2000 -type f 2>/dev/null | sort || echo "")
sgid_count=$(echo "$sgid_files" | grep -c "^" || echo "0")

if [[ "$sgid_count" -gt 50 ]]; then
  register_check "SGID binaries" WARN "$sgid_count (review recommended)"
else
  register_check "SGID binaries" PASS "$sgid_count"
fi

section "World-Writable Files (CIS 6.1.9)"

# Find world-writable files (excluding specific allowed ones)
# Limit to specific directories for performance
ww_count=0
for dir in /etc /usr /var /home; do
  [[ -d "$dir" ]] || continue
  count=$(find "$dir" -xdev -type f -perm -0002 ! -path "/var/tmp/*" ! -path "*/cache/*" 2>/dev/null | wc -l || echo "0")
  ((ww_count += count)) || true
done

if [[ "$ww_count" -gt 0 ]]; then
  register_check "World-writable files" WARN "$ww_count files"
else
  register_check "World-writable files" PASS "none in critical dirs"
fi

section "World-Writable Directories Without Sticky Bit (CIS 6.1.10)"

# Find world-writable directories without sticky bit
ww_dirs=0
for dir in /tmp /var/tmp /dev/shm; do
  if [[ -d "$dir" ]]; then
    perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "000")
    # Check if world-writable (last digit >= 2) and no sticky (first digit not 1)
    if [[ "${perms: -1}" -ge 2 ]] && [[ "${perms:0:1}" != "1" ]]; then
      ((ww_dirs++)) || true
    fi
  fi
done

# Also check other directories
other_ww=$(find / -xdev -type d -perm -0002 ! -perm -1000 2>/dev/null | wc -l || echo "0")

if [[ "$ww_dirs" -gt 0 ]] || [[ "$other_ww" -gt 5 ]]; then
  register_check "WW dirs without sticky" FAIL "$((ww_dirs + other_ww)) directories"
else
  register_check "WW dirs without sticky" PASS "none"
fi

# Verify sticky bit on /tmp
tmp_perms=$(stat -c "%a" /tmp 2>/dev/null || echo "000")
if [[ "${tmp_perms:0:1}" == "1" ]]; then
  register_check "/tmp sticky bit" PASS "$tmp_perms"
else
  register_check "/tmp sticky bit" FAIL "missing (perms: $tmp_perms)"
fi

section "Unowned Files (CIS 6.1.13-6.1.14)"

# Find files without valid owner
nouser_count=$(find /home /etc /usr -xdev -nouser 2>/dev/null | wc -l || echo "0")
if [[ "$nouser_count" -gt 0 ]]; then
  register_check "Files without owner" WARN "$nouser_count files"
else
  register_check "Files without owner" PASS "none in critical dirs"
fi

# Find files without valid group
nogroup_count=$(find /home /etc /usr -xdev -nogroup 2>/dev/null | wc -l || echo "0")
if [[ "$nogroup_count" -gt 0 ]]; then
  register_check "Files without group" WARN "$nogroup_count files"
else
  register_check "Files without group" PASS "none in critical dirs"
fi

section "Log File Permissions"

# /var/log
check_file_perms "/var/log" "755|750" "root:root|root:syslog|root:adm" "/var/log dir"

# Common log files
for log in /var/log/messages /var/log/syslog /var/log/auth.log /var/log/secure; do
  if [[ -f "$log" ]]; then
    perms=$(stat -c "%a" "$log" 2>/dev/null || echo "unknown")
    owner=$(stat -c "%U:%G" "$log" 2>/dev/null || echo "unknown")
    # Log files should not be world-readable
    if [[ "${perms: -1}" -ge 4 ]]; then
      register_check "$(basename "$log")" WARN "world-readable ($perms)"
    else
      register_check "$(basename "$log")" PASS "$perms $owner"
    fi
  fi
done

section "Sensitive Directory Permissions"

# /root home directory
check_file_perms "/root" "700|550" "root:root" "/root home"

# /etc/cron* already checked above

# /var/spool/cron
if [[ -d "/var/spool/cron" ]]; then
  check_file_perms "/var/spool/cron" "700" "root:root" "/var/spool/cron"
fi

# /var/spool/at
if [[ -d "/var/spool/at" ]]; then
  check_file_perms "/var/spool/at" "700|770" "root:root|daemon:daemon" "/var/spool/at"
fi

section "Kernel & System Files"

# /etc/sysctl.conf
check_file_perms "/etc/sysctl.conf" "644" "root:root" "/etc/sysctl.conf"

# /etc/sysctl.d if exists
if [[ -d "/etc/sysctl.d" ]]; then
  check_file_perms "/etc/sysctl.d" "755" "root:root" "/etc/sysctl.d"
fi

# /etc/modules or /etc/modules-load.d
if [[ -f "/etc/modules" ]]; then
  check_file_perms "/etc/modules" "644" "root:root" "/etc/modules"
fi

# /etc/fstab
check_file_perms "/etc/fstab" "644" "root:root" "/etc/fstab"

# /etc/crypttab (if exists, contains sensitive info)
if [[ -f "/etc/crypttab" ]]; then
  check_file_perms "/etc/crypttab" "600|640" "root:root" "/etc/crypttab"
fi

print_summary
exit "$EXIT_CODE"
