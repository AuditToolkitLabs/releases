#!/usr/bin/env bash
# filesystem-partition-audit.sh — Filesystem Partitioning & Mount Options Audit
#
# @elevation: partial
# @elevation-reason: Mount info and lsmod readable without root, some partition checks need root
#

set -euo pipefail
. "$(dirname "$0")/../../../lib/common.sh"
. "$(dirname "$0")/../../../lib/distro.sh"
section "Filesystem Partitioning & Mount Options"

# Check for separate partitions (cross-Unix)
for part in /var /tmp /home /var/log; do
  mountpoint -q "$part" && register_check "Separate $part" PASS "$part partitioned" || register_check "Separate $part" WARN "$part not partitioned"
done

# Check mount options (nosuid, nodev, noexec)
for dir in /var /tmp /home /var/log; do
  opts=$(findmnt -no OPTIONS "$dir" 2>/dev/null || grep -E "^$dir " /etc/mtab | awk '{print $4}' || echo "")
  for opt in nosuid nodev noexec; do
    echo "$opts" | grep -q "$opt" && register_check "${dir} $opt" PASS "${dir} $opt option" || register_check "${dir} $opt" WARN "${dir} missing $opt"
  done
done

# Disable unused filesystems (cross-Unix)
for fs in cramfs squashfs udf; do
  lsmod | grep -q "$fs" && register_check "Disable $fs" FAIL "$fs module loaded" || register_check "Disable $fs" PASS "$fs module not loaded"
done

print_summary
exit "$EXIT_CODE"
