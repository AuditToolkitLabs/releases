#!/usr/bin/env bash
# =============================================================================
# FTP Server Security Audit
# =============================================================================
# CIS Reference: CIS 2.2.9 (Ensure FTP server is not installed)
# NIST SP 800-53: AC-17, CM-7, SC-8, SC-23
#
# Audits FTP server configuration security:
# - FTP server installation status
# - vsftpd, proftpd, pure-ftpd configuration
# - Anonymous access settings
# - Chroot configuration
# - TLS/SSL encryption (FTPS)
# - User restrictions
# - Logging configuration
#
# @elevation: partial
# @elevation-reason: Service status checks work without root, vsftpd/proftpd configs may need root
#
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../../lib/common.sh
. "${SCRIPT_DIR}/../../../lib/common.sh"
# shellcheck source=../../../lib/distro.sh
. "${SCRIPT_DIR}/../../../lib/distro.sh"
# shellcheck source=../../../lib/pkg.sh
. "${SCRIPT_DIR}/../../../lib/pkg.sh"
# shellcheck source=../../../lib/svc.sh
. "${SCRIPT_DIR}/../../../lib/svc.sh"

# =============================================================================
# FTP Server Detection
# =============================================================================

section "FTP Server Installation Status"

FTP_INSTALLED=false
FTP_SERVER=""

# Check for common FTP server packages
ftp_packages=(
    "vsftpd:vsftpd"
    "proftpd:proftpd"
    "proftpd-basic:proftpd"
    "pure-ftpd:pure-ftpd"
    "wu-ftpd:wu-ftpd"
)

for entry in "${ftp_packages[@]}"; do
    pkg="${entry%%:*}"
    server="${entry#*:}"
    if pkg_installed "$pkg" 2>/dev/null; then
        FTP_INSTALLED=true
        FTP_SERVER="$server"
        register_check "FTP server installed" WARN "$pkg (consider SFTP instead)"
        break
    fi
done

if [[ "$FTP_INSTALLED" == "false" ]]; then
    register_check "FTP server" PASS "Not installed (CIS 2.2.9 compliant)"

    # Also recommend SFTP
    echo ""
    echo "Recommendation: Use SFTP (SSH File Transfer Protocol) instead of FTP"
    echo "SFTP provides encryption and uses existing SSH infrastructure."
    echo ""

    print_summary
    exit "$EXIT_CODE"
fi

# =============================================================================
# FTP Service Status
# =============================================================================

section "FTP Service Status"

ftp_running=false

# Check service based on detected server
case "$FTP_SERVER" in
    vsftpd)
        if svc_is_active vsftpd 2>/dev/null; then
            ftp_running=true
            register_check "vsftpd service" WARN "Running"
        elif svc_is_enabled vsftpd 2>/dev/null; then
            register_check "vsftpd service" INFO "Enabled but not running"
        else
            register_check "vsftpd service" PASS "Not enabled"
        fi
        ;;
    proftpd)
        if svc_is_active proftpd 2>/dev/null; then
            ftp_running=true
            register_check "proftpd service" WARN "Running"
        elif svc_is_enabled proftpd 2>/dev/null; then
            register_check "proftpd service" INFO "Enabled but not running"
        else
            register_check "proftpd service" PASS "Not enabled"
        fi
        ;;
    pure-ftpd)
        if svc_is_active pure-ftpd 2>/dev/null; then
            ftp_running=true
            register_check "pure-ftpd service" WARN "Running"
        elif svc_is_enabled pure-ftpd 2>/dev/null; then
            register_check "pure-ftpd service" INFO "Enabled but not running"
        else
            register_check "pure-ftpd service" PASS "Not enabled"
        fi
        ;;
esac

# Check listening ports
if command -v ss >/dev/null 2>&1; then
    ftp_listen=$(ss -tlnp 2>/dev/null | grep -E ":21\s|:20\s" || echo "")
    if [[ -n "$ftp_listen" ]]; then
        register_check "FTP ports (20/21)" WARN "Listening"
        ftp_running=true
    fi
fi

# =============================================================================
# vsftpd Configuration
# =============================================================================

if [[ "$FTP_SERVER" == "vsftpd" ]]; then
    section "vsftpd Configuration Security"

    vsftpd_conf="/etc/vsftpd.conf"
    [[ ! -f "$vsftpd_conf" ]] && vsftpd_conf="/etc/vsftpd/vsftpd.conf"

    if [[ -f "$vsftpd_conf" ]]; then
        register_check "vsftpd.conf" PASS "Found: $vsftpd_conf"

        # Check file permissions
        conf_perms=$(stat -c "%a" "$vsftpd_conf" 2>/dev/null)
        if [[ "$conf_perms" == "600" ]] || [[ "$conf_perms" == "644" ]]; then
            register_check "Config permissions" PASS "$conf_perms"
        else
            register_check "Config permissions" WARN "$conf_perms"
        fi

        # Anonymous access
        anon_enable=$(grep -E "^anonymous_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$anon_enable" == "NO" ]]; then
            register_check "Anonymous FTP" PASS "Disabled"
        elif [[ "$anon_enable" == "YES" ]]; then
            register_check "Anonymous FTP" FAIL "Enabled (security risk)"

            # Check anonymous upload
            anon_upload=$(grep -E "^anon_upload_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            if [[ "$anon_upload" == "YES" ]]; then
                register_check "Anonymous upload" FAIL "Enabled (critical risk)"
            else
                register_check "Anonymous upload" PASS "Disabled"
            fi
        else
            register_check "Anonymous FTP" INFO "Default (usually NO)"
        fi

        # Local users
        local_enable=$(grep -E "^local_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$local_enable" == "YES" ]]; then
            register_check "Local users" PASS "Enabled"

            # Check chroot
            chroot_local=$(grep -E "^chroot_local_user=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            if [[ "$chroot_local" == "YES" ]]; then
                register_check "Chroot local users" PASS "Enabled"
            else
                register_check "Chroot local users" FAIL "Disabled (users can browse filesystem)"
            fi
        fi

        # SSL/TLS Configuration
        ssl_enable=$(grep -E "^ssl_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$ssl_enable" == "YES" ]]; then
            register_check "SSL/TLS" PASS "Enabled"

            # Check if SSL is forced
            force_ssl=$(grep -E "^force_local_data_ssl=|^force_local_logins_ssl=" "$vsftpd_conf" 2>/dev/null)
            if echo "$force_ssl" | grep -q "=YES"; then
                register_check "Force SSL" PASS "Enabled"
            else
                register_check "Force SSL" WARN "Not forced (optional encryption)"
            fi

            # Check SSL certificate
            rsa_cert=$(grep -E "^rsa_cert_file=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            if [[ -n "$rsa_cert" ]] && [[ -f "$rsa_cert" ]]; then
                register_check "SSL certificate" PASS "$rsa_cert"
            elif [[ -n "$rsa_cert" ]]; then
                register_check "SSL certificate" FAIL "File not found: $rsa_cert"
            fi

            # Check TLS version
            ssl_tlsv1=$(grep -E "^ssl_tlsv1=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            ssl_sslv2=$(grep -E "^ssl_sslv2=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            ssl_sslv3=$(grep -E "^ssl_sslv3=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)

            if [[ "$ssl_sslv2" == "NO" ]] && [[ "$ssl_sslv3" == "NO" ]]; then
                register_check "Legacy SSL disabled" PASS "SSLv2/v3 disabled"
            elif [[ "$ssl_sslv2" == "YES" ]] || [[ "$ssl_sslv3" == "YES" ]]; then
                register_check "Legacy SSL disabled" FAIL "SSLv2 or SSLv3 enabled (insecure)"
            fi
        else
            register_check "SSL/TLS" FAIL "Disabled (plain text transmission)"
        fi

        # User list configuration
        userlist_enable=$(grep -E "^userlist_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$userlist_enable" == "YES" ]]; then
            userlist_deny=$(grep -E "^userlist_deny=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            if [[ "$userlist_deny" == "NO" ]]; then
                register_check "User whitelist" PASS "Only listed users allowed"
            else
                register_check "User blacklist" PASS "Listed users denied"
            fi
        fi

        # Passive mode ports
        pasv_min=$(grep -E "^pasv_min_port=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        pasv_max=$(grep -E "^pasv_max_port=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ -n "$pasv_min" ]] && [[ -n "$pasv_max" ]]; then
            register_check "Passive port range" PASS "$pasv_min-$pasv_max"
        else
            register_check "Passive port range" INFO "Not configured (default)"
        fi

        # Logging
        xferlog_enable=$(grep -E "^xferlog_enable=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$xferlog_enable" == "YES" ]]; then
            register_check "Transfer logging" PASS "Enabled"

            xferlog_file=$(grep -E "^xferlog_file=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
            if [[ -n "$xferlog_file" ]]; then
                register_check "Log file" PASS "$xferlog_file"
            fi
        else
            register_check "Transfer logging" WARN "Disabled"
        fi

        log_ftp=$(grep -E "^log_ftp_protocol=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$log_ftp" == "YES" ]]; then
            register_check "Protocol logging" PASS "Enabled"
        fi

        # TCP Wrappers
        tcp_wrappers=$(grep -E "^tcp_wrappers=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ "$tcp_wrappers" == "YES" ]]; then
            register_check "TCP Wrappers" PASS "Enabled"
        fi

        # Deny file
        deny_file=$(grep -E "^deny_file=" "$vsftpd_conf" 2>/dev/null | cut -d= -f2)
        if [[ -n "$deny_file" ]]; then
            register_check "Deny file pattern" PASS "Configured"
        fi
    else
        register_check "vsftpd.conf" FAIL "Configuration not found"
    fi
fi

# =============================================================================
# proftpd Configuration
# =============================================================================

if [[ "$FTP_SERVER" == "proftpd" ]]; then
    section "proftpd Configuration Security"

    proftpd_conf="/etc/proftpd/proftpd.conf"
    [[ ! -f "$proftpd_conf" ]] && proftpd_conf="/etc/proftpd.conf"

    if [[ -f "$proftpd_conf" ]]; then
        register_check "proftpd.conf" PASS "Found: $proftpd_conf"

        # Server identity
        server_ident=$(grep -E "^ServerIdent" "$proftpd_conf" 2>/dev/null | head -1)
        if echo "$server_ident" | grep -qi "off"; then
            register_check "Server identity" PASS "Hidden"
        else
            register_check "Server identity" WARN "Exposed (consider ServerIdent off)"
        fi

        # Anonymous access
        if grep -q "<Anonymous" "$proftpd_conf" 2>/dev/null; then
            register_check "Anonymous FTP" FAIL "Anonymous section found"
        else
            register_check "Anonymous FTP" PASS "Not configured"
        fi

        # Default root (chroot)
        default_root=$(grep -E "^DefaultRoot" "$proftpd_conf" 2>/dev/null | awk '{print $2}')
        if [[ "$default_root" == "~" ]] || [[ -n "$default_root" ]]; then
            register_check "DefaultRoot (chroot)" PASS "$default_root"
        else
            register_check "DefaultRoot (chroot)" FAIL "Not set (users can browse)"
        fi

        # TLS configuration
        if grep -qE "^Include.*tls\.conf|^TLSEngine\s+on" "$proftpd_conf" 2>/dev/null; then
            register_check "TLS" PASS "Enabled"

            # Check TLS requirements
            tls_required=$(grep -E "^TLSRequired" "$proftpd_conf" 2>/dev/null | awk '{print $2}')
            if [[ "$tls_required" == "on" ]]; then
                register_check "TLS Required" PASS "Enforced"
            else
                register_check "TLS Required" WARN "Not enforced"
            fi

            # Check TLS protocol
            tls_protocol=$(grep -E "^TLSProtocol" "$proftpd_conf" 2>/dev/null)
            if [[ -n "$tls_protocol" ]]; then
                if echo "$tls_protocol" | grep -qiE "SSLv2|SSLv3"; then
                    register_check "TLS Protocol" WARN "Legacy protocols may be enabled"
                else
                    register_check "TLS Protocol" PASS "Modern protocols"
                fi
            fi
        else
            register_check "TLS" FAIL "Not configured (plain text)"
        fi

        # User restrictions
        if grep -qE "^<Limit LOGIN>" "$proftpd_conf" 2>/dev/null; then
            register_check "Login restrictions" PASS "Configured"
        fi

        # Logging
        if grep -qE "^SystemLog|^TransferLog" "$proftpd_conf" 2>/dev/null; then
            register_check "Logging" PASS "Configured"
        else
            register_check "Logging" WARN "Check logging configuration"
        fi

        # Umask
        umask_val=$(grep -E "^Umask" "$proftpd_conf" 2>/dev/null | awk '{print $2}')
        if [[ -n "$umask_val" ]]; then
            register_check "Umask" PASS "$umask_val"
        fi
    else
        register_check "proftpd.conf" FAIL "Configuration not found"
    fi
fi

# =============================================================================
# pure-ftpd Configuration
# =============================================================================

if [[ "$FTP_SERVER" == "pure-ftpd" ]]; then
    section "pure-ftpd Configuration Security"

    pure_conf_dir="/etc/pure-ftpd/conf"
    pure_conf="/etc/pure-ftpd/pure-ftpd.conf"

    # pure-ftpd uses individual conf files or a single conf
    if [[ -d "$pure_conf_dir" ]]; then
        register_check "pure-ftpd config dir" PASS "$pure_conf_dir"

        # Check key settings (stored as files)
        if [[ -f "$pure_conf_dir/NoAnonymous" ]]; then
            val=$(cat "$pure_conf_dir/NoAnonymous" 2>/dev/null)
            if [[ "$val" == "yes" ]]; then
                register_check "Anonymous FTP" PASS "Disabled"
            fi
        else
            register_check "Anonymous FTP" WARN "May be enabled (create NoAnonymous file)"
        fi

        if [[ -f "$pure_conf_dir/ChrootEveryone" ]]; then
            val=$(cat "$pure_conf_dir/ChrootEveryone" 2>/dev/null)
            if [[ "$val" == "yes" ]]; then
                register_check "Chroot" PASS "Enabled for all users"
            fi
        else
            register_check "Chroot" WARN "Check ChrootEveryone setting"
        fi

        if [[ -f "$pure_conf_dir/TLS" ]]; then
            val=$(cat "$pure_conf_dir/TLS" 2>/dev/null)
            case "$val" in
                0) register_check "TLS" FAIL "Disabled" ;;
                1) register_check "TLS" WARN "Optional" ;;
                2) register_check "TLS" PASS "Required" ;;
                3) register_check "TLS" PASS "Required (only TLS)" ;;
            esac
        else
            register_check "TLS" WARN "Not configured"
        fi

        if [[ -f "$pure_conf_dir/MinUID" ]]; then
            min_uid=$(cat "$pure_conf_dir/MinUID" 2>/dev/null)
            if [[ "$min_uid" -ge 1000 ]]; then
                register_check "MinUID" PASS "$min_uid (system users blocked)"
            else
                register_check "MinUID" WARN "$min_uid (consider 1000+)"
            fi
        fi

    elif [[ -f "$pure_conf" ]]; then
        register_check "pure-ftpd.conf" PASS "Found: $pure_conf"
        # Parse single config file format
        # ... similar checks
    else
        register_check "pure-ftpd config" WARN "Configuration not found"
    fi
fi

# =============================================================================
# FTP User Configuration
# =============================================================================

section "FTP User Security"

# Check ftpusers file (users denied FTP access)
ftpusers="/etc/ftpusers"
if [[ -f "$ftpusers" ]]; then
    denied_users=$(grep -cv '^#\|^$' "$ftpusers" 2>/dev/null || echo "0")
    register_check "ftpusers (denied)" PASS "$denied_users users denied FTP"

    # Check for root
    if grep -q "^root$" "$ftpusers" 2>/dev/null; then
        register_check "Root FTP denied" PASS "root in ftpusers"
    else
        register_check "Root FTP denied" FAIL "root not in ftpusers"
    fi
else
    register_check "ftpusers file" WARN "Not found (no user restrictions)"
fi

# Check vsftpd user list
vsftpd_userlist="/etc/vsftpd/user_list"
[[ ! -f "$vsftpd_userlist" ]] && vsftpd_userlist="/etc/vsftpd.user_list"
if [[ -f "$vsftpd_userlist" ]]; then
    register_check "vsftpd user_list" PASS "Found: $vsftpd_userlist"
fi

# =============================================================================
# Firewall Configuration
# =============================================================================

section "FTP Firewall Considerations"

# Check if FTP ports are open in firewall
if command -v iptables >/dev/null 2>&1; then
    ftp_rules=$(iptables -L -n 2>/dev/null | grep -E "dpt:21|dpt:20" || echo "")
    if [[ -n "$ftp_rules" ]]; then
        register_check "FTP firewall rules" INFO "Port 20/21 rules found"
    fi
fi

echo ""
echo "FTP Firewall Recommendations:"
echo "  - Limit FTP access to specific IP ranges"
echo "  - Use connection tracking for passive mode"
echo "  - Consider FTP over VPN only"
echo ""

# =============================================================================
# Security Recommendations
# =============================================================================

section "Security Summary"

echo ""
echo "FTP Security Recommendations:"
echo "  1. STRONGLY consider migrating to SFTP (CIS 2.2.9)"
echo "  2. If FTP required, enforce TLS/SSL (FTPS)"
echo "  3. Disable anonymous access"
echo "  4. Enable chroot for all users"
echo "  5. Use user whitelists instead of blacklists"
echo "  6. Set minimum UID to block system accounts"
echo "  7. Enable comprehensive logging"
echo "  8. Limit passive port range and firewall appropriately"
echo "  9. Disable legacy SSL versions (SSLv2, SSLv3)"
echo ""
echo "Alternative: Use SFTP with OpenSSH (SSH subsystem sftp)"
echo "  - Encrypted by default"
echo "  - Uses existing SSH infrastructure"
echo "  - Better security track record"
echo ""

print_summary
exit "$EXIT_CODE"
