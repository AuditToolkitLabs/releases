#!/usr/bin/env bash
# grub-password-audit.sh — GRUB Password Protection Audit
#
# @elevation: root
# @elevation-reason: GRUB configuration files in /boot/grub require root to read
#

set -euo pipefail
. "$(dirname "$0")/../../../lib/common.sh"
. "$(dirname "$0")/../../../lib/distro.sh"
section "GRUB Password Protection"

grub_cfg="/boot/grub/grub.cfg"
if [ -f "$grub_cfg" ]; then
  grep -q "password_pbkdf2" "$grub_cfg" && register_check "GRUB password set" PASS "password_pbkdf2 found" || register_check "GRUB password set" FAIL "No GRUB password"
else
  register_check "GRUB config exists" WARN "grub.cfg not found"
fi

print_summary
exit "$EXIT_CODE"
