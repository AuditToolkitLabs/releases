#!/usr/bin/env bash
# journald-comprehensive-audit.sh — Comprehensive systemd-journald Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 4.2.2.x (journald Configuration)
# - NIST SP 800-53: AU-2, AU-3, AU-4, AU-5, AU-8, AU-9
# - ISO 27001: A.12.4.1, A.12.4.2, A.12.4.3
# - PCI DSS: 10.2, 10.5, 10.7
# - HIPAA: 164.312(b)
#
# Checks:
# - journald service status and configuration
# - Log persistence and storage settings
# - Compression and sealing (integrity)
# - Rate limiting and forward to syslog
# - Access controls and permissions
# - Log rotation and retention
# - Remote forwarding configuration
#
# @elevation: partial
# @elevation-reason: journald.conf readable without root, some journal queries need root
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../lib/common.sh
. "$SCRIPT_DIR/../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/distro.sh
. "$SCRIPT_DIR/../../../lib/distro.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/svc.sh
. "$SCRIPT_DIR/../../../lib/svc.sh"

setup_colors

# Configuration paths
readonly JOURNALD_CONF="/etc/systemd/journald.conf"
readonly JOURNALD_CONF_D="/etc/systemd/journald.conf.d"
readonly JOURNAL_DIR="/var/log/journal"

section "systemd-journald Comprehensive Audit"

# Check if systemd is available
if ! is_systemd; then
  register_check "systemd" SKIP "systemd not available (OpenRC or other init)"
  print_summary
  exit "$EXIT_CODE"
fi

# Check journald service status
if svc_is_active systemd-journald; then
  register_check "journald service" PASS "running"
else
  register_check "journald service" FAIL "not running"
fi

section "Journal Configuration (journald.conf)"

# Function to get journald config value
get_journald_config() {
  local key="$1"
  local value=""

  # Check main config
  if [[ -f "$JOURNALD_CONF" ]]; then
    value=$(grep -E "^\s*${key}\s*=" "$JOURNALD_CONF" 2>/dev/null | tail -1 | cut -d= -f2 | xargs || echo "")
  fi

  # Check conf.d overrides
  if [[ -d "$JOURNALD_CONF_D" ]]; then
    local override
    override=$(find "$JOURNALD_CONF_D" -name "*.conf" -exec grep -lE "^\s*${key}\s*=" {} \; 2>/dev/null | head -1 || echo "")
    if [[ -n "$override" ]]; then
      value=$(grep -E "^\s*${key}\s*=" "$override" 2>/dev/null | tail -1 | cut -d= -f2 | xargs || echo "")
    fi
  fi

  echo "$value"
}

# CIS 4.2.2.1.1: Ensure journald is configured to write logs to persistent storage
storage=$(get_journald_config "Storage")
case "${storage,,}" in
  persistent)
    register_check_tagged "Persistent storage (CIS 4.2.2.1.1)" PASS "$storage" '"CIS:4.2.2.1.1","NIST:AU-4"'
    ;;
  auto)
    if [[ -d "$JOURNAL_DIR" ]]; then
      register_check_tagged "Persistent storage (CIS 4.2.2.1.1)" PASS "auto (journal dir exists)" '"CIS:4.2.2.1.1","NIST:AU-4"'
    else
      register_check_tagged "Persistent storage (CIS 4.2.2.1.1)" WARN "auto (journal dir missing - logs in memory only)" '"CIS:4.2.2.1.1","NIST:AU-4"'
    fi
    ;;
  volatile | none | "")
    register_check_tagged "Persistent storage (CIS 4.2.2.1.1)" FAIL "${storage:-not set} (logs not persisted)" '"CIS:4.2.2.1.1","NIST:AU-4"'
    ;;
  *)
    register_check_tagged "Persistent storage (CIS 4.2.2.1.1)" WARN "unknown value: $storage" '"CIS:4.2.2.1.1","NIST:AU-4"'
    ;;
esac

# CIS 4.2.2.1.2: Ensure journald is configured to compress large log files
compress=$(get_journald_config "Compress")
case "${compress,,}" in
  yes | "")
    register_check_tagged "Log compression (CIS 4.2.2.1.2)" PASS "${compress:-yes (default)}" '"CIS:4.2.2.1.2","NIST:AU-4"'
    ;;
  no)
    register_check_tagged "Log compression (CIS 4.2.2.1.2)" WARN "disabled" '"CIS:4.2.2.1.2","NIST:AU-4"'
    ;;
esac

# CIS 4.2.2.1.3: Ensure journald is configured to send logs to rsyslog (forward to syslog)
forward_to_syslog=$(get_journald_config "ForwardToSyslog")
case "${forward_to_syslog,,}" in
  yes)
    register_check_tagged "Forward to syslog (CIS 4.2.2.1.3)" PASS "enabled" '"CIS:4.2.2.1.3","NIST:AU-6"'
    ;;
  no | "")
    # Check if rsyslog is running - if so, recommend forwarding
    if svc_is_active rsyslog 2>/dev/null; then
      register_check_tagged "Forward to syslog (CIS 4.2.2.1.3)" WARN "disabled (rsyslog is running)" '"CIS:4.2.2.1.3","NIST:AU-6"'
    else
      register_check_tagged "Forward to syslog (CIS 4.2.2.1.3)" PASS "disabled (rsyslog not running)" '"CIS:4.2.2.1.3","NIST:AU-6"'
    fi
    ;;
esac

section "Log Integrity & Security"

# Check Seal setting (FSS - Forward Secure Sealing)
seal=$(get_journald_config "Seal")
case "${seal,,}" in
  yes | "")
    register_check_tagged "FSS Sealing (integrity)" PASS "${seal:-yes (default)}" '"NIST:AU-9","ISO:A.12.4.2"'
    ;;
  no)
    register_check_tagged "FSS Sealing (integrity)" WARN "disabled - log tampering not detectable" '"NIST:AU-9","ISO:A.12.4.2"'
    ;;
esac

# Check SplitMode for user isolation
split_mode=$(get_journald_config "SplitMode")
case "${split_mode,,}" in
  uid)
    register_check "User log isolation" PASS "uid - per-user journals"
    ;;
  login | "")
    register_check "User log isolation" PASS "${split_mode:-login (default)}"
    ;;
  none)
    register_check "User log isolation" WARN "disabled - all users in single journal"
    ;;
esac

section "Storage Limits & Retention"

# SystemMaxUse - Maximum disk space for journal
sys_max_use=$(get_journald_config "SystemMaxUse")
if [[ -n "$sys_max_use" ]]; then
  register_check "SystemMaxUse limit" PASS "$sys_max_use"
else
  register_check "SystemMaxUse limit" WARN "not set (default: 10% of filesystem)"
fi

# SystemKeepFree - Minimum free space to keep
sys_keep_free=$(get_journald_config "SystemKeepFree")
if [[ -n "$sys_keep_free" ]]; then
  register_check "SystemKeepFree" PASS "$sys_keep_free"
else
  register_check "SystemKeepFree" PASS "not set (default: 15% free)"
fi

# SystemMaxFileSize - Max size per journal file
sys_max_file_size=$(get_journald_config "SystemMaxFileSize")
if [[ -n "$sys_max_file_size" ]]; then
  register_check "SystemMaxFileSize" PASS "$sys_max_file_size"
else
  register_check "SystemMaxFileSize" PASS "not set (default: 1/8 of SystemMaxUse)"
fi

# MaxRetentionSec - Time-based retention
max_retention=$(get_journald_config "MaxRetentionSec")
if [[ -n "$max_retention" ]]; then
  register_check "MaxRetentionSec" PASS "$max_retention"
else
  register_check "MaxRetentionSec" WARN "not set (logs retained indefinitely until space limit)"
fi

# MaxFileSec - Rotation interval
max_file_sec=$(get_journald_config "MaxFileSec")
if [[ -n "$max_file_sec" ]]; then
  register_check "MaxFileSec (rotation)" PASS "$max_file_sec"
else
  register_check "MaxFileSec (rotation)" PASS "not set (default: 1 month)"
fi

section "Rate Limiting"

# RateLimitIntervalSec
rate_interval=$(get_journald_config "RateLimitIntervalSec")
if [[ -n "$rate_interval" ]]; then
  register_check "RateLimitIntervalSec" PASS "$rate_interval"
else
  register_check "RateLimitIntervalSec" PASS "not set (default: 30s)"
fi

# RateLimitBurst
rate_burst=$(get_journald_config "RateLimitBurst")
if [[ -n "$rate_burst" ]]; then
  if [[ "$rate_burst" == "0" ]]; then
    register_check "RateLimitBurst" WARN "0 (rate limiting disabled)"
  else
    register_check "RateLimitBurst" PASS "$rate_burst messages per interval"
  fi
else
  register_check "RateLimitBurst" PASS "not set (default: 10000)"
fi

section "Journal Directory Permissions"

# Check journal directory exists and permissions
if [[ -d "$JOURNAL_DIR" ]]; then
  register_check "Persistent journal directory" PASS "$JOURNAL_DIR exists"

  # Check permissions (should be 2755 or stricter)
  dir_perms=$(stat -c "%a" "$JOURNAL_DIR" 2>/dev/null || echo "")
  dir_owner=$(stat -c "%U:%G" "$JOURNAL_DIR" 2>/dev/null || echo "")

  if [[ "$dir_owner" == "root:systemd-journal" ]]; then
    register_check "Journal dir owner" PASS "$dir_owner"
  else
    register_check "Journal dir owner" WARN "$dir_owner (expected root:systemd-journal)"
  fi

  case "$dir_perms" in
    2755 | 2750 | 755 | 750)
      register_check "Journal dir permissions" PASS "$dir_perms"
      ;;
    *)
      register_check "Journal dir permissions" WARN "$dir_perms (expected 2755 or stricter)"
      ;;
  esac

  # Check for proper journal files
  journal_count=$(find "$JOURNAL_DIR" -name "*.journal" -type f 2>/dev/null | wc -l)
  if [[ "$journal_count" -gt 0 ]]; then
    register_check "Journal files" PASS "$journal_count files"
  else
    register_check "Journal files" WARN "no journal files found"
  fi
else
  register_check "Persistent journal directory" FAIL "$JOURNAL_DIR does not exist"
fi

section "Remote Forwarding Configuration"

# Forward to specific output
forward_to_kmsg=$(get_journald_config "ForwardToKMsg")
forward_to_console=$(get_journald_config "ForwardToConsole")
forward_to_wall=$(get_journald_config "ForwardToWall")

if [[ "${forward_to_kmsg,,}" == "yes" ]]; then
  register_check "Forward to KMsg" PASS "enabled"
else
  register_check "Forward to KMsg" SKIP "disabled"
fi

if [[ "${forward_to_console,,}" == "yes" ]]; then
  register_check "Forward to Console" PASS "enabled"
else
  register_check "Forward to Console" SKIP "disabled"
fi

if [[ "${forward_to_wall,,}" == "yes" ]]; then
  register_check "Forward to Wall" PASS "enabled (emergency alerts)"
else
  register_check "Forward to Wall" SKIP "disabled"
fi

# Check for systemd-journal-remote (remote logging)
if command -v systemd-journal-remote >/dev/null 2>&1; then
  register_check "journal-remote available" PASS "installed"
  if svc_is_active systemd-journal-remote 2>/dev/null; then
    register_check "journal-remote service" PASS "running (receiving logs)"
  else
    register_check "journal-remote service" SKIP "not active"
  fi
else
  register_check "journal-remote" SKIP "not installed"
fi

# Check for systemd-journal-upload (sending logs)
if command -v systemd-journal-upload >/dev/null 2>&1; then
  register_check "journal-upload available" PASS "installed"
  if svc_is_active systemd-journal-upload 2>/dev/null; then
    register_check "journal-upload service" PASS "running (sending logs)"
  else
    register_check "journal-upload service" SKIP "not active"
  fi
else
  register_check "journal-upload" SKIP "not installed"
fi

section "Journal Health Check"

# Check journal disk usage
if command -v journalctl >/dev/null 2>&1; then
  journal_usage=$(journalctl --disk-usage 2>/dev/null | grep -oE '[0-9.]+[KMGT]?' | head -1 || echo "unknown")
  register_check "Journal disk usage" PASS "$journal_usage"

  # Check for journal corruption
  if journalctl --verify 2>/dev/null | grep -qE "^PASS"; then
    register_check "Journal integrity" PASS "verified"
  elif journalctl --verify 2>&1 | grep -qE "FAIL|corrupt"; then
    register_check "Journal integrity" FAIL "corruption detected"
  else
    register_check "Journal integrity" WARN "unable to verify (may need root)"
  fi

  # Check oldest entry
  oldest_entry=$(journalctl --quiet --output=short-iso --reverse 2>/dev/null | tail -1 | cut -d' ' -f1 || echo "")
  if [[ -n "$oldest_entry" ]]; then
    register_check "Oldest log entry" PASS "$oldest_entry"
  fi
else
  register_check "journalctl command" FAIL "not available"
fi

print_summary
exit "$EXIT_CODE"
