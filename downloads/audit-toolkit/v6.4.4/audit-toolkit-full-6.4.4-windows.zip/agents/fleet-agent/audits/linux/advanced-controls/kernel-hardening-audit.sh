#!/usr/bin/env bash
# kernel-hardening-audit.sh — Comprehensive Kernel Security Audit
#
# @elevation: root
# @elevation-reason: Requires sysctl access and reading /proc/sys/kernel values
#
# Compliance Mapping:
# - CIS Benchmark: 3.1-3.3 (Network Parameters), 1.5 (Kernel)
# - NIST SP 800-53: SC-7, SC-8 (Network Protection)
# - ISO 27001: A.13.1 (Network Security)
# - PCI DSS: 1.4 (System Hardening)
# - DISA STIG: V-204399-V-204450 (Kernel Hardening)
#
# Checks:
# - IPv4/IPv6 network parameters
# - Kernel security settings
# - Filesystem protections
# - Module blacklist
# - Boot parameters

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

setup_colors

# Helper function to check sysctl value
check_sysctl() {
  local param="$1"
  local expected="$2"
  local name="${3:-$param}"

  local val
  val=$(sysctl -n "$param" 2>/dev/null || echo "N/A")

  if [[ "$val" == "N/A" ]]; then
    register_check "$name" SKIP "not available"
  elif [[ "$val" == "$expected" ]]; then
    register_check "$name" PASS "$param=$val"
  else
    register_check "$name" WARN "$param=$val (expected: $expected)"
  fi
}

section "IPv4 Network Security (CIS 3.2)"

# Source route validation
check_sysctl "net.ipv4.conf.all.accept_source_route" "0" "IPv4 source route (all)"
check_sysctl "net.ipv4.conf.default.accept_source_route" "0" "IPv4 source route (default)"

# ICMP redirects
check_sysctl "net.ipv4.conf.all.accept_redirects" "0" "IPv4 redirects (all)"
check_sysctl "net.ipv4.conf.default.accept_redirects" "0" "IPv4 redirects (default)"
check_sysctl "net.ipv4.conf.all.secure_redirects" "0" "IPv4 secure redirects (all)"
check_sysctl "net.ipv4.conf.default.secure_redirects" "0" "IPv4 secure redirects (default)"

# Sending redirects (should be 0 unless router)
check_sysctl "net.ipv4.conf.all.send_redirects" "0" "IPv4 send redirects (all)"
check_sysctl "net.ipv4.conf.default.send_redirects" "0" "IPv4 send redirects (default)"

# Martian packets logging
check_sysctl "net.ipv4.conf.all.log_martians" "1" "Log martians (all)"
check_sysctl "net.ipv4.conf.default.log_martians" "1" "Log martians (default)"

# ICMP settings
check_sysctl "net.ipv4.icmp_echo_ignore_broadcasts" "1" "Ignore ICMP broadcasts"
check_sysctl "net.ipv4.icmp_ignore_bogus_error_responses" "1" "Ignore bogus ICMP errors"

# TCP SYN flood protection
check_sysctl "net.ipv4.tcp_syncookies" "1" "TCP SYN cookies"

# Reverse path filtering
check_sysctl "net.ipv4.conf.all.rp_filter" "1" "Reverse path filter (all)"
check_sysctl "net.ipv4.conf.default.rp_filter" "1" "Reverse path filter (default)"

# IP forwarding (should be 0 unless router)
ip_forward=$(sysctl -n net.ipv4.ip_forward 2>/dev/null || echo "0")
if [[ "$ip_forward" == "0" ]]; then
  register_check "IPv4 forwarding" PASS "disabled"
else
  register_check "IPv4 forwarding" WARN "enabled (OK if router)"
fi

section "IPv6 Network Security (CIS 3.3)"

# Check if IPv6 is disabled
ipv6_disabled=$(sysctl -n net.ipv6.conf.all.disable_ipv6 2>/dev/null || echo "N/A")
if [[ "$ipv6_disabled" == "1" ]]; then
  register_check "IPv6 status" PASS "disabled"
else
  # If IPv6 enabled, check security settings
  register_check "IPv6 status" PASS "enabled (checking settings)"

  check_sysctl "net.ipv6.conf.all.accept_ra" "0" "IPv6 router ads (all)"
  check_sysctl "net.ipv6.conf.default.accept_ra" "0" "IPv6 router ads (default)"
  check_sysctl "net.ipv6.conf.all.accept_redirects" "0" "IPv6 redirects (all)"
  check_sysctl "net.ipv6.conf.default.accept_redirects" "0" "IPv6 redirects (default)"
  check_sysctl "net.ipv6.conf.all.accept_source_route" "0" "IPv6 source route (all)"
  check_sysctl "net.ipv6.conf.default.accept_source_route" "0" "IPv6 source route (default)"

  # CIS 3.1.x: Additional IPv6 hardening
  check_sysctl "net.ipv6.conf.all.use_tempaddr" "2" "IPv6 privacy extensions (all)"
  check_sysctl "net.ipv6.conf.default.use_tempaddr" "2" "IPv6 privacy extensions (default)"
  check_sysctl "net.ipv6.conf.all.max_addresses" "1" "IPv6 max addresses (all)"

  # IPv6 forwarding
  ipv6_forward=$(sysctl -n net.ipv6.conf.all.forwarding 2>/dev/null || echo "0")
  if [[ "$ipv6_forward" == "0" ]]; then
    register_check "IPv6 forwarding" PASS "disabled"
  else
    register_check "IPv6 forwarding" WARN "enabled"
  fi
fi

section "Kernel Security Settings (CIS 1.5)"

# ASLR
aslr=$(sysctl -n kernel.randomize_va_space 2>/dev/null || echo "")
if [[ "$aslr" == "2" ]]; then
  register_check "ASLR" PASS "full randomization ($aslr)"
elif [[ "$aslr" == "1" ]]; then
  register_check "ASLR" WARN "conservative ($aslr)"
else
  register_check "ASLR" FAIL "disabled ($aslr)"
fi

# Restrict dmesg access
check_sysctl "kernel.dmesg_restrict" "1" "Restrict dmesg"

# Restrict kernel pointer exposure
kptr=$(sysctl -n kernel.kptr_restrict 2>/dev/null || echo "0")
if [[ "$kptr" -ge 1 ]]; then
  register_check "Kernel pointer restrict" PASS "level $kptr"
else
  register_check "Kernel pointer restrict" WARN "not restricted ($kptr)"
fi

# Yama ptrace scope
check_sysctl "kernel.yama.ptrace_scope" "1" "Yama ptrace scope"

# Perf event paranoid
perf=$(sysctl -n kernel.perf_event_paranoid 2>/dev/null || echo "N/A")
if [[ "$perf" == "N/A" ]]; then
  register_check "Perf event paranoid" SKIP "not available"
elif [[ "$perf" -ge 2 ]]; then
  register_check "Perf event paranoid" PASS "level $perf"
else
  register_check "Perf event paranoid" WARN "level $perf (recommend >= 2)"
fi

# SysRq key
check_sysctl "kernel.sysrq" "0" "SysRq key"

# Core dump settings
check_sysctl "kernel.core_uses_pid" "1" "Core uses PID"

section "Filesystem Security"

# SUID dumpable
check_sysctl "fs.suid_dumpable" "0" "SUID dumpable"

# Protected hardlinks and symlinks
check_sysctl "fs.protected_hardlinks" "1" "Protected hardlinks"
check_sysctl "fs.protected_symlinks" "1" "Protected symlinks"

# Protected FIFOs and regular files (newer kernels)
protected_fifos=$(sysctl -n fs.protected_fifos 2>/dev/null || echo "N/A")
if [[ "$protected_fifos" != "N/A" ]]; then
  if [[ "$protected_fifos" -ge 1 ]]; then
    register_check "Protected FIFOs" PASS "$protected_fifos"
  else
    register_check "Protected FIFOs" WARN "$protected_fifos"
  fi
fi

protected_regular=$(sysctl -n fs.protected_regular 2>/dev/null || echo "N/A")
if [[ "$protected_regular" != "N/A" ]]; then
  if [[ "$protected_regular" -ge 1 ]]; then
    register_check "Protected regular files" PASS "$protected_regular"
  else
    register_check "Protected regular files" WARN "$protected_regular"
  fi
fi

section "Kernel Module Blacklist (CIS 1.1)"

# Modules that should be disabled
blacklist_modules=(
  "cramfs:Cramfs filesystem"
  "freevxfs:FreeVxFS filesystem"
  "jffs2:JFFS2 filesystem"
  "hfs:HFS filesystem"
  "hfsplus:HFS+ filesystem"
  "udf:UDF filesystem"
  "dccp:DCCP protocol"
  "sctp:SCTP protocol"
  "rds:RDS protocol"
  "tipc:TIPC protocol"
  "usb-storage:USB storage"
)

for entry in "${blacklist_modules[@]}"; do
  module="${entry%%:*}"
  desc="${entry##*:}"

  # Check if module is loaded
  if lsmod 2>/dev/null | grep -q "^${module}"; then
    register_check "Module: $module" WARN "loaded ($desc)"
    continue
  fi

  # Check if module is blacklisted
  blacklisted=false
  for conf in /etc/modprobe.d/*.conf; do
    [[ -f "$conf" ]] || continue
    if grep -qE "^(blacklist|install)\s+${module}" "$conf" 2>/dev/null; then
      blacklisted=true
      break
    fi
  done

  if $blacklisted; then
    register_check "Module: $module" PASS "blacklisted"
  else
    # Not loaded and not blacklisted - could be OK or missing
    if modinfo "$module" >/dev/null 2>&1; then
      register_check "Module: $module" WARN "available, not blacklisted"
    else
      register_check "Module: $module" PASS "not available"
    fi
  fi
done

section "Boot Parameters (CIS 1.5)"

# Check /proc/cmdline
if [[ -f "/proc/cmdline" ]]; then
  cmdline=$(cat /proc/cmdline)

  # Audit enabled at boot
  if echo "$cmdline" | grep -qE "audit=1"; then
    register_check "Audit at boot" PASS "audit=1"
  else
    register_check "Audit at boot" WARN "audit=1 not set"
  fi

  # Audit backlog limit
  if echo "$cmdline" | grep -qE "audit_backlog_limit="; then
    backlog=$(echo "$cmdline" | grep -oE "audit_backlog_limit=[0-9]+" | cut -d= -f2)
    if [[ "$backlog" -ge 8192 ]]; then
      register_check "Audit backlog limit" PASS "$backlog"
    else
      register_check "Audit backlog limit" WARN "$backlog (recommend >= 8192)"
    fi
  else
    register_check "Audit backlog limit" WARN "not set"
  fi

  # Check for insecure boot options
  if echo "$cmdline" | grep -qE "init=/bin/(ba)?sh"; then
    register_check "Init override" FAIL "init=/bin/sh detected"
  else
    register_check "Init override" PASS "none"
  fi

  # IOMMU
  if echo "$cmdline" | grep -qE "iommu=(soft|force)"; then
    register_check "IOMMU" PASS "enabled"
  fi

  # Spectre/Meltdown mitigations
  if echo "$cmdline" | grep -qE "mitigations=off"; then
    register_check "CPU mitigations" FAIL "disabled"
  elif echo "$cmdline" | grep -qE "mitigations=auto"; then
    register_check "CPU mitigations" PASS "auto"
  else
    register_check "CPU mitigations" PASS "default (on)"
  fi
fi

section "ExecShield & NX/XD"

# Check NX bit support
if [[ -f "/proc/cpuinfo" ]]; then
  if grep -q "^flags.*\bnx\b" /proc/cpuinfo 2>/dev/null; then
    register_check "NX/XD bit" PASS "supported"
  else
    register_check "NX/XD bit" WARN "not detected"
  fi
fi

# Check for exec-shield (older systems)
execshield=$(sysctl -n kernel.exec-shield 2>/dev/null || echo "N/A")
if [[ "$execshield" != "N/A" ]]; then
  if [[ "$execshield" == "1" ]]; then
    register_check "Exec-shield" PASS "enabled"
  else
    register_check "Exec-shield" WARN "disabled"
  fi
fi

section "Coredump Restrictions"

# Check coredump limits
if [[ -f "/etc/security/limits.conf" ]]; then
  if grep -qE "^\*.*hard.*core.*0" /etc/security/limits.conf 2>/dev/null; then
    register_check "Core dumps (hard limit)" PASS "disabled"
  else
    register_check "Core dumps (hard limit)" WARN "not restricted in limits.conf"
  fi
fi

# Check systemd coredump settings
if [[ -f "/etc/systemd/coredump.conf" ]]; then
  if grep -qE "^Storage=none" /etc/systemd/coredump.conf 2>/dev/null; then
    register_check "Systemd coredump" PASS "Storage=none"
  fi
fi

section "BPF Security"

# Check BPF restrictions (newer kernels)
bpf_disabled=$(sysctl -n kernel.unprivileged_bpf_disabled 2>/dev/null || echo "N/A")
if [[ "$bpf_disabled" != "N/A" ]]; then
  if [[ "$bpf_disabled" == "1" ]] || [[ "$bpf_disabled" == "2" ]]; then
    register_check "Unprivileged BPF" PASS "disabled ($bpf_disabled)"
  else
    register_check "Unprivileged BPF" WARN "enabled"
  fi
fi

# BPF JIT hardening
bpf_jit=$(sysctl -n net.core.bpf_jit_harden 2>/dev/null || echo "N/A")
if [[ "$bpf_jit" != "N/A" ]]; then
  if [[ "$bpf_jit" -ge 1 ]]; then
    register_check "BPF JIT hardening" PASS "$bpf_jit"
  else
    register_check "BPF JIT hardening" WARN "disabled"
  fi
fi

section "User Namespaces"

# Check unprivileged user namespaces
userns=$(sysctl -n kernel.unprivileged_userns_clone 2>/dev/null || echo "N/A")
if [[ "$userns" != "N/A" ]]; then
  if [[ "$userns" == "0" ]]; then
    register_check "Unprivileged userns" PASS "disabled"
  else
    register_check "Unprivileged userns" WARN "enabled (needed for rootless containers)"
  fi
fi

print_summary
exit "$EXIT_CODE"
