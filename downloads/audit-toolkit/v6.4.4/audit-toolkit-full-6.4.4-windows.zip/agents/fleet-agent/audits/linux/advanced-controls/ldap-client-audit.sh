#!/usr/bin/env bash
# =============================================================================
# LDAP Client Security Audit
# =============================================================================
# CIS Reference: CIS 2.3.5 (Ensure LDAP client is not installed)
# NIST SP 800-53: AC-2, IA-2, IA-5, SC-8, SC-23
#
# Audits LDAP client configuration security:
# - LDAP client installation status
# - TLS/SSL configuration (LDAPS)
# - Certificate verification
# - Bind credentials security
# - NSS/PAM LDAP integration
# - sssd vs nslcd configuration
#
# @elevation: partial
# @elevation-reason: ldap.conf usually readable, some credential files need root
#
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../../lib/common.sh
. "${SCRIPT_DIR}/../../../lib/common.sh"
# shellcheck source=../../../lib/distro.sh
. "${SCRIPT_DIR}/../../../lib/distro.sh"
# shellcheck source=../../../lib/pkg.sh
. "${SCRIPT_DIR}/../../../lib/pkg.sh"

# =============================================================================
# LDAP Client Detection
# =============================================================================

section "LDAP Client Installation Status"

# Track if LDAP is in use
LDAP_IN_USE=false

# Check for common LDAP client packages
ldap_packages=(
    "openldap-clients"
    "ldap-utils"
    "libldap"
    "openldap"
    "sssd-ldap"
    "nss-pam-ldapd"
    "libnss-ldap"
    "libpam-ldap"
)

installed_ldap=""
for pkg in "${ldap_packages[@]}"; do
    if pkg_installed "$pkg" 2>/dev/null; then
        installed_ldap+="$pkg "
        LDAP_IN_USE=true
    fi
done

if [[ -n "$installed_ldap" ]]; then
    register_check "LDAP packages installed" INFO "$installed_ldap"
else
    register_check "LDAP packages" PASS "No LDAP client packages installed (CIS 2.3.5 compliant)"
    print_summary
    exit "$EXIT_CODE"
fi

# =============================================================================
# SSSD LDAP Configuration (Modern/Preferred)
# =============================================================================

section "SSSD LDAP Configuration"

sssd_conf="/etc/sssd/sssd.conf"
if [[ -f "$sssd_conf" ]]; then
    register_check "SSSD configuration" PASS "Found: $sssd_conf"

    # Check file permissions (should be 600)
    sssd_perms=$(stat -c "%a" "$sssd_conf" 2>/dev/null)
    if [[ "$sssd_perms" == "600" ]]; then
        register_check "sssd.conf permissions" PASS "600 (correct)"
    else
        register_check "sssd.conf permissions" FAIL "$sssd_perms (should be 600)"
    fi

    # Check ownership
    sssd_owner=$(stat -c "%U:%G" "$sssd_conf" 2>/dev/null)
    if [[ "$sssd_owner" == "root:root" ]]; then
        register_check "sssd.conf ownership" PASS "root:root"
    else
        register_check "sssd.conf ownership" WARN "$sssd_owner (should be root:root)"
    fi

    # Check for LDAP domain
    if grep -q "id_provider.*=.*ldap" "$sssd_conf" 2>/dev/null; then
        register_check "SSSD LDAP provider" PASS "LDAP id_provider configured"

        # Check ldap_uri for TLS
        ldap_uri=$(grep -E "^ldap_uri" "$sssd_conf" 2>/dev/null | head -1)
        if [[ -n "$ldap_uri" ]]; then
            if echo "$ldap_uri" | grep -qE "ldaps://|ldap://.*:636"; then
                register_check "LDAP URI uses TLS" PASS "LDAPS configured"
            elif echo "$ldap_uri" | grep -q "ldap://"; then
                # Check for start_tls
                if grep -qE "ldap_id_use_start_tls.*=.*[Tt]rue" "$sssd_conf" 2>/dev/null; then
                    register_check "LDAP StartTLS" PASS "StartTLS enabled"
                else
                    register_check "LDAP URI security" FAIL "Using ldap:// without StartTLS"
                fi
            fi
        fi

        # Check TLS certificate verification
        tls_reqcert=$(grep -E "ldap_tls_reqcert" "$sssd_conf" 2>/dev/null | cut -d= -f2 | tr -d ' ')
        case "$tls_reqcert" in
            demand|hard)
                register_check "TLS cert verification" PASS "$tls_reqcert (strict)"
                ;;
            allow|try|"")
                register_check "TLS cert verification" WARN "${tls_reqcert:-not set} (recommend: demand)"
                ;;
            never)
                register_check "TLS cert verification" FAIL "never (certificates not verified!)"
                ;;
        esac

        # Check for CA certificate
        tls_cacert=$(grep -E "ldap_tls_cacert" "$sssd_conf" 2>/dev/null | cut -d= -f2 | tr -d ' ')
        if [[ -n "$tls_cacert" ]]; then
            if [[ -f "$tls_cacert" ]]; then
                register_check "TLS CA certificate" PASS "$tls_cacert"
            else
                register_check "TLS CA certificate" FAIL "File not found: $tls_cacert"
            fi
        else
            register_check "TLS CA certificate" WARN "Not explicitly configured"
        fi

        # Check for bind credentials
        if grep -qE "ldap_default_bind_dn" "$sssd_conf" 2>/dev/null; then
            register_check "LDAP bind DN" PASS "Configured"

            # Check if password is in config (bad) vs keytab/etc
            if grep -qE "ldap_default_authtok" "$sssd_conf" 2>/dev/null; then
                register_check "LDAP bind password" WARN "Password in config file"
            fi
        else
            register_check "LDAP bind DN" INFO "Anonymous bind or not configured"
        fi

        # Check enumeration settings
        if grep -qE "enumerate.*=.*[Tt]rue" "$sssd_conf" 2>/dev/null; then
            register_check "LDAP enumeration" WARN "Enabled (performance impact, consider disabling)"
        else
            register_check "LDAP enumeration" PASS "Disabled or default"
        fi
    fi
else
    register_check "SSSD configuration" INFO "Not found (may use nslcd or direct LDAP)"
fi

# =============================================================================
# nslcd Configuration (Legacy)
# =============================================================================

section "nslcd Configuration (Legacy)"

nslcd_conf="/etc/nslcd.conf"
if [[ -f "$nslcd_conf" ]]; then
    register_check "nslcd configuration" INFO "Found: $nslcd_conf (legacy, consider SSSD)"

    # Check file permissions
    nslcd_perms=$(stat -c "%a" "$nslcd_conf" 2>/dev/null)
    if [[ "$nslcd_perms" == "600" ]] || [[ "$nslcd_perms" == "640" ]]; then
        register_check "nslcd.conf permissions" PASS "$nslcd_perms"
    else
        register_check "nslcd.conf permissions" FAIL "$nslcd_perms (should be 600 or 640)"
    fi

    # Check for TLS
    if grep -qE "^ssl\s+(on|start_tls)" "$nslcd_conf" 2>/dev/null; then
        register_check "nslcd TLS" PASS "SSL/TLS enabled"
    else
        register_check "nslcd TLS" FAIL "TLS not enabled"
    fi

    # Check TLS verification
    tls_reqcert=$(grep -E "^tls_reqcert" "$nslcd_conf" 2>/dev/null | awk '{print $2}')
    case "$tls_reqcert" in
        demand|hard)
            register_check "nslcd TLS verification" PASS "$tls_reqcert"
            ;;
        allow|try|"")
            register_check "nslcd TLS verification" WARN "${tls_reqcert:-not set}"
            ;;
        never)
            register_check "nslcd TLS verification" FAIL "never"
            ;;
    esac

    # Check bind credentials
    if grep -qE "^binddn" "$nslcd_conf" 2>/dev/null; then
        if grep -qE "^bindpw" "$nslcd_conf" 2>/dev/null; then
            register_check "nslcd bind password" WARN "Password in config file"
        fi
    fi
fi

# =============================================================================
# OpenLDAP Client Configuration
# =============================================================================

section "OpenLDAP Client Configuration"

ldap_conf="/etc/openldap/ldap.conf"
[[ ! -f "$ldap_conf" ]] && ldap_conf="/etc/ldap/ldap.conf"

if [[ -f "$ldap_conf" ]]; then
    register_check "ldap.conf" PASS "Found: $ldap_conf"

    # Check BASE DN
    if grep -qE "^BASE" "$ldap_conf" 2>/dev/null; then
        base_dn=$(grep -E "^BASE" "$ldap_conf" | awk '{print $2}')
        register_check "LDAP BASE DN" PASS "$base_dn"
    fi

    # Check URI
    ldap_uri=$(grep -E "^URI" "$ldap_conf" 2>/dev/null | head -1)
    if [[ -n "$ldap_uri" ]]; then
        if echo "$ldap_uri" | grep -qE "ldaps://"; then
            register_check "ldap.conf URI" PASS "Using LDAPS"
        else
            register_check "ldap.conf URI" WARN "Consider using ldaps://"
        fi
    fi

    # Check TLS settings
    tls_cacert=$(grep -E "^TLS_CACERT" "$ldap_conf" 2>/dev/null | awk '{print $2}')
    if [[ -n "$tls_cacert" ]]; then
        if [[ -f "$tls_cacert" ]]; then
            register_check "TLS_CACERT" PASS "$tls_cacert"
        else
            register_check "TLS_CACERT" FAIL "File not found: $tls_cacert"
        fi
    fi

    tls_reqcert=$(grep -E "^TLS_REQCERT" "$ldap_conf" 2>/dev/null | awk '{print $2}')
    case "$tls_reqcert" in
        demand|hard)
            register_check "TLS_REQCERT" PASS "$tls_reqcert"
            ;;
        allow|try|"")
            register_check "TLS_REQCERT" WARN "${tls_reqcert:-not set} (recommend: demand)"
            ;;
        never)
            register_check "TLS_REQCERT" FAIL "never (insecure)"
            ;;
    esac
fi

# =============================================================================
# PAM LDAP Configuration
# =============================================================================

section "PAM LDAP Integration"

# Check if PAM uses LDAP
pam_ldap_found=false
for pam_file in /etc/pam.d/system-auth /etc/pam.d/common-auth /etc/pam.d/password-auth; do
    if [[ -f "$pam_file" ]]; then
        if grep -qE "pam_ldap|pam_sss" "$pam_file" 2>/dev/null; then
            pam_ldap_found=true
            register_check "PAM LDAP integration" PASS "Found in $pam_file"
            break
        fi
    fi
done

if [[ "$pam_ldap_found" == "false" ]] && [[ "$LDAP_IN_USE" == "true" ]]; then
    register_check "PAM LDAP integration" INFO "Not configured in PAM"
fi

# Check pam_ldap.conf if exists
pam_ldap_conf="/etc/pam_ldap.conf"
[[ ! -f "$pam_ldap_conf" ]] && pam_ldap_conf="/etc/ldap.conf"

if [[ -f "$pam_ldap_conf" ]]; then
    # Check for plaintext password
    if grep -qE "^rootbinddn" "$pam_ldap_conf" 2>/dev/null; then
        if [[ -f /etc/pam_ldap.secret ]] || [[ -f /etc/ldap.secret ]]; then
            secret_file="/etc/pam_ldap.secret"
            [[ -f /etc/ldap.secret ]] && secret_file="/etc/ldap.secret"
            secret_perms=$(stat -c "%a" "$secret_file" 2>/dev/null)
            if [[ "$secret_perms" == "600" ]] || [[ "$secret_perms" == "400" ]]; then
                register_check "LDAP secret file perms" PASS "$secret_perms"
            else
                register_check "LDAP secret file perms" FAIL "$secret_perms (should be 600)"
            fi
        fi
    fi
fi

# =============================================================================
# NSS LDAP Configuration
# =============================================================================

section "NSS Configuration"

nsswitch="/etc/nsswitch.conf"
if [[ -f "$nsswitch" ]]; then
    # Check which databases use LDAP/SSS
    for db in passwd group shadow; do
        db_config=$(grep -E "^${db}:" "$nsswitch" 2>/dev/null || echo "")
        if echo "$db_config" | grep -qE "ldap|sss"; then
            register_check "NSS $db" PASS "Uses LDAP/SSS"
        fi
    done
fi

# =============================================================================
# LDAP Service Status
# =============================================================================

section "LDAP Client Services"

# Check SSSD service
if command -v systemctl >/dev/null 2>&1; then
    if systemctl is-active sssd >/dev/null 2>&1; then
        register_check "SSSD service" PASS "Running"
    elif systemctl is-enabled sssd >/dev/null 2>&1; then
        register_check "SSSD service" WARN "Enabled but not running"
    fi

    if systemctl is-active nslcd >/dev/null 2>&1; then
        register_check "nslcd service" WARN "Running (legacy, consider SSSD)"
    fi
elif command -v rc-service >/dev/null 2>&1; then
    if rc-service sssd status >/dev/null 2>&1; then
        register_check "SSSD service" PASS "Running"
    fi
    if rc-service nslcd status >/dev/null 2>&1; then
        register_check "nslcd service" WARN "Running (legacy)"
    fi
fi

# =============================================================================
# Security Recommendations
# =============================================================================

section "LDAP Security Summary"

if [[ "$LDAP_IN_USE" == "true" ]]; then
    echo ""
    echo "LDAP Security Recommendations:"
    echo "  1. Use LDAPS (port 636) or StartTLS for all connections"
    echo "  2. Set TLS_REQCERT to 'demand' for certificate verification"
    echo "  3. Use SSSD instead of nslcd for modern systems"
    echo "  4. Avoid storing bind passwords in config files"
    echo "  5. Use service accounts with minimal privileges"
    echo "  6. Enable audit logging for LDAP authentication"
    echo ""
fi

print_summary
exit "$EXIT_CODE"
