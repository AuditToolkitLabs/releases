#!/usr/bin/env bash
# logging-audit.sh — Log Configuration and Permissions Audit
#
# @elevation: root
# @elevation-reason: Requires access to read log file permissions and configs
#
# Compliance Mapping:
# - CIS Benchmark: 4.2.3 (Log File Permissions)
# - NIST SP 800-53: AU-9 (Protection of Audit Information)
# - ISO 27001: A.12.4.1-A.12.4.2 (Event Logging, Protection of Logs)
# - PCI DSS: 10.5 (Secure Audit Trails)
#
# Checks:
# - rsyslog/syslog-ng service status
# - logrotate configuration
# - Log file permissions (CIS 4.2.3)
# - Log directory ownership

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

setup_colors

section "Logging Services"

# rsyslog check (cross-Unix)
if command -v rsyslogd >/dev/null; then
  if is_systemd; then
    if systemctl is-active rsyslog >/dev/null 2>&1; then
      register_check "rsyslog active" PASS "rsyslog running"
    else
      register_check "rsyslog active" FAIL "rsyslog not running"
    fi
  elif is_openrc; then
    if rc-service rsyslog status >/dev/null 2>&1; then
      register_check "rsyslog active" PASS "rsyslog running"
    else
      register_check "rsyslog active" FAIL "rsyslog not running"
    fi
  else
    if pgrep rsyslogd >/dev/null 2>&1; then
      register_check "rsyslog active" PASS "rsyslog running"
    else
      register_check "rsyslog active" FAIL "rsyslog not running"
    fi
  fi
elif command -v syslog-ng >/dev/null; then
  register_check "syslog-ng installed" PASS "syslog-ng present"
  if pgrep syslog-ng >/dev/null 2>&1; then
    register_check "syslog-ng active" PASS "syslog-ng running"
  else
    register_check "syslog-ng active" FAIL "syslog-ng not running"
  fi
else
  register_check "rsyslog installed" WARN "no syslog daemon found"
fi

# logrotate check
if command -v logrotate >/dev/null; then
  register_check "logrotate installed" PASS "logrotate present"

  # Check logrotate config exists
  if [[ -f /etc/logrotate.conf ]]; then
    register_check "logrotate.conf" PASS "config exists"
  else
    register_check "logrotate.conf" WARN "config missing"
  fi

  # Check logrotate.d directory
  if [[ -d /etc/logrotate.d ]]; then
    count=$(find /etc/logrotate.d -type f 2>/dev/null | wc -l)
    register_check "logrotate.d" PASS "$count configs in logrotate.d"
  fi
else
  register_check "logrotate installed" FAIL "logrotate not found"
fi

section "Log File Permissions (CIS 4.2.3)"

# Helper function to check log file permissions
check_log_perms() {
  local file="$1"
  local expected_mode="$2"
  local expected_owner="${3:-root}"
  local expected_group="${4:-root}"
  local name="${5:-$(basename "$file")}"

  if [[ ! -e "$file" ]]; then
    register_check "$name perms" SKIP "file not found"
    return
  fi

  local actual_mode actual_owner actual_group
  actual_mode=$(stat -c "%a" "$file" 2>/dev/null)
  actual_owner=$(stat -c "%U" "$file" 2>/dev/null)
  actual_group=$(stat -c "%G" "$file" 2>/dev/null)

  local issues=""

  # Check mode - file should be equal or more restrictive
  if [[ "$actual_mode" -gt "$expected_mode" ]]; then
    issues="mode=$actual_mode (expected <=$expected_mode)"
  fi

  # Check owner
  if [[ "$actual_owner" != "$expected_owner" ]]; then
    issues="${issues:+$issues, }owner=$actual_owner (expected $expected_owner)"
  fi

  # Check group (allow adm, syslog, or specified group)
  if [[ "$actual_group" != "$expected_group" && "$actual_group" != "adm" && "$actual_group" != "syslog" ]]; then
    issues="${issues:+$issues, }group=$actual_group"
  fi

  if [[ -z "$issues" ]]; then
    register_check "$name perms" PASS "mode=$actual_mode owner=$actual_owner:$actual_group"
  else
    register_check "$name perms" WARN "$issues"
  fi
}

# CIS 4.2.3: Check permissions on log files
# System logs - should be 640 or more restrictive, owned by root

# Main system log
if [[ -f /var/log/syslog ]]; then
  check_log_perms "/var/log/syslog" "640" "syslog" "adm" "syslog"
elif [[ -f /var/log/messages ]]; then
  check_log_perms "/var/log/messages" "640" "root" "root" "messages"
fi

# Auth logs
if [[ -f /var/log/auth.log ]]; then
  check_log_perms "/var/log/auth.log" "640" "syslog" "adm" "auth.log"
elif [[ -f /var/log/secure ]]; then
  check_log_perms "/var/log/secure" "600" "root" "root" "secure"
fi

# Kernel log
check_log_perms "/var/log/kern.log" "640" "syslog" "adm" "kern.log"

# Boot log
check_log_perms "/var/log/boot.log" "640" "root" "root" "boot.log"

# Cron log
if [[ -f /var/log/cron ]]; then
  check_log_perms "/var/log/cron" "640" "root" "root" "cron"
elif [[ -f /var/log/cron.log ]]; then
  check_log_perms "/var/log/cron.log" "640" "root" "root" "cron.log"
fi

# Mail log
if [[ -f /var/log/maillog ]]; then
  check_log_perms "/var/log/maillog" "640" "root" "root" "maillog"
elif [[ -f /var/log/mail.log ]]; then
  check_log_perms "/var/log/mail.log" "640" "root" "root" "mail.log"
fi

# Daemon log
check_log_perms "/var/log/daemon.log" "640" "syslog" "adm" "daemon.log"

# Debug log (if exists, should be restricted)
if [[ -f /var/log/debug ]]; then
  check_log_perms "/var/log/debug" "640" "syslog" "adm" "debug"
fi

# wtmp (login records) - CIS recommends 664 max
check_log_perms "/var/log/wtmp" "664" "root" "utmp" "wtmp"

# btmp (bad login attempts) - should be 600
check_log_perms "/var/log/btmp" "600" "root" "utmp" "btmp"

# lastlog - should be 644
check_log_perms "/var/log/lastlog" "644" "root" "root" "lastlog"

section "Log Directory Permissions"

# /var/log should be 755 or more restrictive
if [[ -d /var/log ]]; then
  varlog_mode=$(stat -c "%a" /var/log 2>/dev/null)
  varlog_owner=$(stat -c "%U" /var/log 2>/dev/null)
  if [[ "$varlog_mode" -le "755" && "$varlog_owner" == "root" ]]; then
    register_check "/var/log perms" PASS "mode=$varlog_mode owner=$varlog_owner"
  else
    register_check "/var/log perms" WARN "mode=$varlog_mode owner=$varlog_owner"
  fi
fi

# Audit log directory
if [[ -d /var/log/audit ]]; then
  audit_mode=$(stat -c "%a" /var/log/audit 2>/dev/null)
  audit_owner=$(stat -c "%U" /var/log/audit 2>/dev/null)
  if [[ "$audit_mode" -le "750" && "$audit_owner" == "root" ]]; then
    register_check "/var/log/audit perms" PASS "mode=$audit_mode owner=$audit_owner"
  else
    register_check "/var/log/audit perms" WARN "mode=$audit_mode owner=$audit_owner (expected <=750)"
  fi
fi

section "World-Readable Log Check"

# Find any world-readable log files (security risk)
world_readable=$(find /var/log -type f -perm -004 2>/dev/null | head -20)
if [[ -z "$world_readable" ]]; then
  register_check "No world-readable logs" PASS "no world-readable log files"
else
  count=$(echo "$world_readable" | wc -l)
  register_check "World-readable logs" WARN "$count world-readable files found"
fi

# Find any world-writable log files (critical security risk)
world_writable=$(find /var/log -type f -perm -002 2>/dev/null | head -10)
if [[ -z "$world_writable" ]]; then
  register_check "No world-writable logs" PASS "no world-writable log files"
else
  count=$(echo "$world_writable" | wc -l)
  register_check "World-writable logs" FAIL "$count world-writable files - SECURITY RISK"
fi

section "rsyslog Configuration Security"

if [[ -f /etc/rsyslog.conf ]]; then
  # Check rsyslog.conf permissions
  rsyslog_mode=$(stat -c "%a" /etc/rsyslog.conf 2>/dev/null)
  if [[ "$rsyslog_mode" -le "640" ]]; then
    register_check "rsyslog.conf perms" PASS "mode=$rsyslog_mode"
  else
    register_check "rsyslog.conf perms" WARN "mode=$rsyslog_mode (expected <=640)"
  fi

  # Check for remote logging configuration
  if grep -qE '^\s*\*\.\*\s+@@?' /etc/rsyslog.conf 2>/dev/null; then
    register_check "Remote logging" PASS "remote logging configured"
  else
    register_check "Remote logging" WARN "no remote logging detected"
  fi

  # Check FileCreateMode
  if grep -qE '^\$FileCreateMode\s+0[0-6][04]0' /etc/rsyslog.conf 2>/dev/null; then
    register_check "FileCreateMode" PASS "restrictive file creation mode"
  else
    register_check "FileCreateMode" WARN "FileCreateMode not set"
  fi
fi

print_summary
exit "$EXIT_CODE"
