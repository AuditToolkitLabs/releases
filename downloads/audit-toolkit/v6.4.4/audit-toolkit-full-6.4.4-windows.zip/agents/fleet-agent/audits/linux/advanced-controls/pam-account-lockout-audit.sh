#!/usr/bin/env bash
# pam-account-lockout-audit.sh — PAM Account Lockout Policy Audit
#
# Compliance Mapping:
# - CIS Benchmark: 5.4.2 (Account Lockout Configuration)
# - NIST SP 800-53: AC-7 (Unsuccessful Login Attempts)
# - ISO 27001: A.9.4.2 (Secure Log-on Procedures)
# - PCI DSS: 8.1.6-8.1.7 (Account Lockout)
# - DISA STIG: V-204422 (Login Attempts)
#
# Checks:
# - pam_faillock configuration (RHEL 8+/Ubuntu 22.04+)
# - Legacy pam_tally2 configuration
# - Lockout threshold (deny)
# - Unlock time
# - Root account lockout
#
# @elevation: root
# @elevation-reason: PAM configuration files require root privileges to read properly
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

# Configuration files
readonly FAILLOCK_CONF="/etc/security/faillock.conf"
readonly PAM_COMMON_AUTH="/etc/pam.d/common-auth"          # Debian/Ubuntu
readonly PAM_SYSTEM_AUTH="/etc/pam.d/system-auth"          # RHEL/Fedora
readonly PAM_PASSWORD_AUTH="/etc/pam.d/password-auth"      # RHEL alt
readonly PAM_COMMON_ACCOUNT="/etc/pam.d/common-account"    # Debian/Ubuntu
readonly PAM_SYSTEM_ACCOUNT="/etc/pam.d/system-auth"       # RHEL uses same file

section "PAM Account Lockout Policy Audit"

# Determine PAM files based on distro
pam_auth_file=""
pam_account_file=""
if [[ -f "$PAM_COMMON_AUTH" ]]; then
  pam_auth_file="$PAM_COMMON_AUTH"
  pam_account_file="$PAM_COMMON_ACCOUNT"
  register_check "PAM config type" PASS "Debian/Ubuntu"
elif [[ -f "$PAM_SYSTEM_AUTH" ]]; then
  pam_auth_file="$PAM_SYSTEM_AUTH"
  pam_account_file="$PAM_SYSTEM_AUTH"
  register_check "PAM config type" PASS "RHEL/Fedora"
else
  register_check "PAM config type" FAIL "no standard PAM auth file found"
fi

# Detect which lockout module is in use
lockout_module=""
if [[ -f "$FAILLOCK_CONF" ]]; then
  lockout_module="faillock"
elif [[ -n "$pam_auth_file" ]] && grep -q "pam_faillock" "$pam_auth_file" 2>/dev/null; then
  lockout_module="faillock"
elif [[ -n "$pam_auth_file" ]] && grep -q "pam_tally2" "$pam_auth_file" 2>/dev/null; then
  lockout_module="tally2"
elif [[ -n "$pam_auth_file" ]] && grep -q "pam_faildelay" "$pam_auth_file" 2>/dev/null; then
  lockout_module="faildelay"
fi

if [[ -n "$lockout_module" ]]; then
  register_check "Lockout module detected" PASS "$lockout_module"
else
  register_check "Lockout module detected" WARN "no lockout module configured"
fi

section "pam_faillock Configuration (Modern)"

# Check faillock.conf (RHEL 8+, Ubuntu 22.04+)
if [[ -f "$FAILLOCK_CONF" ]]; then
  register_check "faillock.conf" PASS "present"

  faillock_settings=$(cat "$FAILLOCK_CONF")

  # Check deny (lockout threshold) - CIS: >= 5
  deny=$(echo "$faillock_settings" | grep -E "^\s*deny\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$deny" ]] && [[ "$deny" -le 5 ]] && [[ "$deny" -gt 0 ]]; then
    register_check "Lockout threshold (deny)" PASS "$deny attempts"
  elif [[ -n "$deny" ]] && [[ "$deny" -le 10 ]]; then
    register_check "Lockout threshold (deny)" WARN "$deny attempts (recommend <= 5)"
  elif [[ -n "$deny" ]]; then
    register_check "Lockout threshold (deny)" FAIL "$deny attempts (too high)"
  else
    register_check "Lockout threshold (deny)" WARN "not set"
  fi

  # Check unlock_time (seconds) - CIS: >= 900 (15 min) or 0 (manual unlock)
  unlock_time=$(echo "$faillock_settings" | grep -E "^\s*unlock_time\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ "$unlock_time" == "0" ]]; then
    register_check "Unlock time" PASS "manual unlock required"
  elif [[ -n "$unlock_time" ]] && [[ "$unlock_time" -ge 900 ]]; then
    register_check "Unlock time" PASS "$unlock_time seconds ($((unlock_time / 60)) min)"
  elif [[ -n "$unlock_time" ]]; then
    register_check "Unlock time" WARN "$unlock_time seconds (recommend >= 900)"
  else
    register_check "Unlock time" WARN "not set"
  fi

  # Check fail_interval
  fail_interval=$(echo "$faillock_settings" | grep -E "^\s*fail_interval\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$fail_interval" ]] && [[ "$fail_interval" -ge 900 ]]; then
    register_check "Fail interval" PASS "$fail_interval seconds"
  elif [[ -n "$fail_interval" ]]; then
    register_check "Fail interval" WARN "$fail_interval seconds"
  else
    register_check "Fail interval" SKIP "using default (900)"
  fi

  # Check even_deny_root (root lockout)
  if echo "$faillock_settings" | grep -qE "^\s*even_deny_root"; then
    register_check "Root lockout" PASS "root can be locked out"

    # Check root_unlock_time if even_deny_root
    root_unlock=$(echo "$faillock_settings" | grep -E "^\s*root_unlock_time\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
    if [[ -n "$root_unlock" ]]; then
      register_check "Root unlock time" PASS "$root_unlock seconds"
    fi
  else
    register_check "Root lockout" WARN "root exempt from lockout"
  fi

  # Check dir (lockout state directory)
  faillock_dir=$(echo "$faillock_settings" | grep -E "^\s*dir\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  dir_path="${faillock_dir:-/var/run/faillock}"
  if [[ -d "$dir_path" ]]; then
    register_check "Faillock directory" PASS "$dir_path"
  else
    register_check "Faillock directory" SKIP "will be created on first failure"
  fi

  # Check silent option
  if echo "$faillock_settings" | grep -qE "^\s*silent"; then
    register_check "Silent mode" WARN "users not notified of lockout"
  else
    register_check "Silent mode" PASS "users notified of lockout"
  fi

  # Check audit option
  if echo "$faillock_settings" | grep -qE "^\s*audit"; then
    register_check "Audit logging" PASS "enabled"
  else
    register_check "Audit logging" WARN "not enabled"
  fi

elif [[ -n "$pam_auth_file" ]] && grep -q "pam_faillock" "$pam_auth_file" 2>/dev/null; then
  # faillock configured inline in PAM files
  register_check "faillock.conf" SKIP "using inline PAM config"

  pam_auth=$(cat "$pam_auth_file")

  # Extract inline parameters
  deny=$(echo "$pam_auth" | grep -oE "pam_faillock\.so.*deny=[0-9]+" | grep -oE "deny=[0-9]+" | head -1 | cut -d= -f2)
  if [[ -n "$deny" ]] && [[ "$deny" -le 5 ]]; then
    register_check "Lockout threshold (deny)" PASS "$deny attempts"
  elif [[ -n "$deny" ]]; then
    register_check "Lockout threshold (deny)" WARN "$deny attempts"
  else
    register_check "Lockout threshold (deny)" WARN "not set in PAM"
  fi

  unlock_time=$(echo "$pam_auth" | grep -oE "pam_faillock\.so.*unlock_time=[0-9]+" | grep -oE "unlock_time=[0-9]+" | head -1 | cut -d= -f2)
  if [[ -n "$unlock_time" ]] && [[ "$unlock_time" -ge 900 ]]; then
    register_check "Unlock time" PASS "$unlock_time seconds"
  elif [[ -n "$unlock_time" ]]; then
    register_check "Unlock time" WARN "$unlock_time seconds"
  fi

  if echo "$pam_auth" | grep "pam_faillock" | grep -q "even_deny_root"; then
    register_check "Root lockout" PASS "enabled"
  else
    register_check "Root lockout" WARN "root exempt"
  fi
else
  register_check "faillock.conf" SKIP "not present"
fi

section "pam_tally2 Configuration (Legacy)"

# Check for legacy pam_tally2 (deprecated in RHEL 8+)
if [[ -n "$pam_auth_file" ]] && grep -q "pam_tally2" "$pam_auth_file" 2>/dev/null; then
  register_check "pam_tally2 module" WARN "legacy module (migrate to pam_faillock)"

  pam_auth=$(cat "$pam_auth_file")

  # Extract pam_tally2 parameters
  deny=$(echo "$pam_auth" | grep -oE "pam_tally2\.so.*deny=[0-9]+" | grep -oE "deny=[0-9]+" | head -1 | cut -d= -f2)
  if [[ -n "$deny" ]]; then
    register_check "Legacy deny threshold" PASS "$deny"
  fi

  unlock_time=$(echo "$pam_auth" | grep -oE "pam_tally2\.so.*unlock_time=[0-9]+" | grep -oE "unlock_time=[0-9]+" | head -1 | cut -d= -f2)
  if [[ -n "$unlock_time" ]]; then
    register_check "Legacy unlock_time" PASS "$unlock_time"
  fi

  # Check for even_deny_root in tally2
  if echo "$pam_auth" | grep "pam_tally2" | grep -q "even_deny_root"; then
    register_check "Legacy root lockout" PASS "enabled"
  fi
elif [[ "$lockout_module" != "faillock" ]]; then
  register_check "pam_tally2 module" SKIP "not configured"
fi

section "PAM Module Order Validation"

# Check that faillock is configured correctly in auth stack
if [[ -n "$pam_auth_file" ]] && [[ -f "$pam_auth_file" ]]; then
  pam_auth=$(cat "$pam_auth_file")

  # faillock should appear before pam_unix (preauth) and after pam_unix (authfail)
  if echo "$pam_auth" | grep -q "pam_faillock.*preauth"; then
    register_check "faillock preauth" PASS "configured before auth"
  elif echo "$pam_auth" | grep -q "pam_faillock"; then
    register_check "faillock preauth" WARN "preauth not explicitly set"
  fi

  if echo "$pam_auth" | grep -q "pam_faillock.*authfail"; then
    register_check "faillock authfail" PASS "configured after auth failure"
  elif echo "$pam_auth" | grep -q "pam_faillock"; then
    register_check "faillock authfail" WARN "authfail not explicitly set"
  fi

  if echo "$pam_auth" | grep -q "pam_faillock.*authsucc"; then
    register_check "faillock authsucc" PASS "reset on success"
  fi
fi

# Check account phase
if [[ -n "$pam_account_file" ]] && [[ -f "$pam_account_file" ]]; then
  if grep -q "pam_faillock" "$pam_account_file" 2>/dev/null; then
    register_check "faillock in account" PASS "configured"
  elif [[ "$lockout_module" == "faillock" ]]; then
    register_check "faillock in account" WARN "should be in account phase"
  fi
fi

section "Current Lockout Status"

# Check for currently locked accounts using faillock command
if command -v faillock >/dev/null 2>&1; then
  locked_users=$(faillock --user root 2>/dev/null | grep -c "V" || echo "0")
  all_locked=$(faillock 2>/dev/null | grep -c "V" || echo "0")

  if [[ "$all_locked" -gt 0 ]]; then
    register_check "Currently locked accounts" WARN "$all_locked accounts locked"
  else
    register_check "Currently locked accounts" PASS "none"
  fi
elif command -v pam_tally2 >/dev/null 2>&1; then
  # Legacy check
  register_check "Tally2 status" SKIP "use: pam_tally2 --user <username>"
fi

section "Login Delay Configuration"

# Check pam_faildelay
if [[ -n "$pam_auth_file" ]] && grep -q "pam_faildelay" "$pam_auth_file" 2>/dev/null; then
  delay=$(grep "pam_faildelay" "$pam_auth_file" | grep -oE "delay=[0-9]+" | cut -d= -f2 | head -1)
  if [[ -n "$delay" ]] && [[ "$delay" -ge 2000000 ]]; then
    register_check "Login fail delay" PASS "$((delay / 1000000)) seconds"
  elif [[ -n "$delay" ]]; then
    register_check "Login fail delay" PASS "$delay microseconds"
  else
    register_check "Login fail delay" PASS "configured"
  fi
else
  register_check "Login fail delay" SKIP "pam_faildelay not configured"
fi

section "SSH Lockout Integration"

# Check if SSH uses PAM
readonly SSHD_CONFIG="/etc/ssh/sshd_config"
if [[ -f "$SSHD_CONFIG" ]]; then
  if grep -qE "^\s*UsePAM\s+yes" "$SSHD_CONFIG" 2>/dev/null; then
    register_check "SSH uses PAM" PASS "lockout applies to SSH"
  elif grep -qE "^\s*UsePAM\s+no" "$SSHD_CONFIG" 2>/dev/null; then
    register_check "SSH uses PAM" FAIL "PAM lockout bypassed for SSH"
  else
    register_check "SSH uses PAM" WARN "UsePAM not explicitly set"
  fi

  # Check MaxAuthTries (SSH's own limit)
  max_auth=$(grep -E "^\s*MaxAuthTries" "$SSHD_CONFIG" | awk '{print $2}' | head -1)
  if [[ -n "$max_auth" ]] && [[ "$max_auth" -le 4 ]]; then
    register_check "SSH MaxAuthTries" PASS "$max_auth"
  elif [[ -n "$max_auth" ]]; then
    register_check "SSH MaxAuthTries" WARN "$max_auth (recommend <= 4)"
  else
    register_check "SSH MaxAuthTries" WARN "not set (default: 6)"
  fi
fi

print_summary
exit "$EXIT_CODE"
