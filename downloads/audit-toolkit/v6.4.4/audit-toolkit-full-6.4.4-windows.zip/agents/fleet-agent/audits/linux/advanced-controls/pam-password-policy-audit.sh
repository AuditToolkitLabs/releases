#!/usr/bin/env bash
# pam-password-policy-audit.sh — PAM Password Quality Policy Audit
#
# Compliance Mapping:
# - CIS Benchmark: 5.4.1 (Ensure password creation requirements)
# - NIST SP 800-53: IA-5(1) (Authenticator Management)
# - ISO 27001: A.9.4.3 (Password Management System)
# - PCI DSS: 8.2.3-8.2.5 (Password Complexity/History)
# - DISA STIG: V-204405, V-204406 (Password Complexity)
#
# Checks:
# - pwquality.conf settings (minlen, complexity)
# - PAM configuration (pam_pwquality/pam_cracklib)
# - Password history (pam_pwhistory/remember)
# - Dictionary check configuration
#
# @elevation: root
# @elevation-reason: PAM configuration files require root privileges to read properly
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

# Configuration files
readonly PWQUALITY_CONF="/etc/security/pwquality.conf"
readonly PWQUALITY_D="/etc/security/pwquality.conf.d"
readonly PAM_COMMON_PASSWORD="/etc/pam.d/common-password"      # Debian/Ubuntu
readonly PAM_SYSTEM_AUTH="/etc/pam.d/system-auth"              # RHEL/Fedora
readonly PAM_PASSWORD_AUTH="/etc/pam.d/password-auth"          # RHEL/Fedora alternative

section "PAM Password Quality Policy Audit"

# Determine PAM file location based on distro
pam_file=""
if [[ -f "$PAM_COMMON_PASSWORD" ]]; then
  pam_file="$PAM_COMMON_PASSWORD"
  register_check "PAM config location" PASS "Debian/Ubuntu: $pam_file"
elif [[ -f "$PAM_SYSTEM_AUTH" ]]; then
  pam_file="$PAM_SYSTEM_AUTH"
  register_check "PAM config location" PASS "RHEL/Fedora: $pam_file"
elif [[ -f "$PAM_PASSWORD_AUTH" ]]; then
  pam_file="$PAM_PASSWORD_AUTH"
  register_check "PAM config location" PASS "RHEL (password-auth): $pam_file"
else
  register_check "PAM config location" FAIL "no standard PAM password file found"
fi

section "Password Quality Module (pwquality.conf)"

# Check if pwquality.conf exists
if [[ -f "$PWQUALITY_CONF" ]]; then
  register_check "pwquality.conf" PASS "present"

  # Read all pwquality settings (including conf.d)
  pwquality_settings=""
  pwquality_settings+=$(cat "$PWQUALITY_CONF" 2>/dev/null || echo "")
  if [[ -d "$PWQUALITY_D" ]]; then
    pwquality_settings+=$(cat "$PWQUALITY_D"/*.conf 2>/dev/null || echo "")
  fi

  # Check minimum length (CIS: >= 14)
  minlen=$(echo "$pwquality_settings" | grep -E "^\s*minlen\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$minlen" ]] && [[ "$minlen" -ge 14 ]]; then
    register_check "Minimum length (minlen)" PASS "$minlen (>= 14)"
  elif [[ -n "$minlen" ]] && [[ "$minlen" -ge 8 ]]; then
    register_check "Minimum length (minlen)" WARN "$minlen (recommend >= 14)"
  elif [[ -n "$minlen" ]]; then
    register_check "Minimum length (minlen)" FAIL "$minlen (< 8)"
  else
    register_check "Minimum length (minlen)" WARN "not set (default: 8)"
  fi

  # Check digit requirement (dcredit <= -1 means at least 1 digit required)
  dcredit=$(echo "$pwquality_settings" | grep -E "^\s*dcredit\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$dcredit" ]] && [[ "$dcredit" -le -1 ]]; then
    register_check "Digit requirement (dcredit)" PASS "$dcredit"
  elif [[ -n "$dcredit" ]]; then
    register_check "Digit requirement (dcredit)" WARN "$dcredit (should be <= -1)"
  else
    register_check "Digit requirement (dcredit)" WARN "not set"
  fi

  # Check uppercase requirement (ucredit <= -1)
  ucredit=$(echo "$pwquality_settings" | grep -E "^\s*ucredit\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$ucredit" ]] && [[ "$ucredit" -le -1 ]]; then
    register_check "Uppercase requirement (ucredit)" PASS "$ucredit"
  elif [[ -n "$ucredit" ]]; then
    register_check "Uppercase requirement (ucredit)" WARN "$ucredit (should be <= -1)"
  else
    register_check "Uppercase requirement (ucredit)" WARN "not set"
  fi

  # Check lowercase requirement (lcredit <= -1)
  lcredit=$(echo "$pwquality_settings" | grep -E "^\s*lcredit\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$lcredit" ]] && [[ "$lcredit" -le -1 ]]; then
    register_check "Lowercase requirement (lcredit)" PASS "$lcredit"
  elif [[ -n "$lcredit" ]]; then
    register_check "Lowercase requirement (lcredit)" WARN "$lcredit (should be <= -1)"
  else
    register_check "Lowercase requirement (lcredit)" WARN "not set"
  fi

  # Check special character requirement (ocredit <= -1)
  ocredit=$(echo "$pwquality_settings" | grep -E "^\s*ocredit\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$ocredit" ]] && [[ "$ocredit" -le -1 ]]; then
    register_check "Special char requirement (ocredit)" PASS "$ocredit"
  elif [[ -n "$ocredit" ]]; then
    register_check "Special char requirement (ocredit)" WARN "$ocredit (should be <= -1)"
  else
    register_check "Special char requirement (ocredit)" WARN "not set"
  fi

  # Check minimum character classes (minclass >= 4)
  minclass=$(echo "$pwquality_settings" | grep -E "^\s*minclass\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$minclass" ]] && [[ "$minclass" -ge 4 ]]; then
    register_check "Minimum character classes (minclass)" PASS "$minclass"
  elif [[ -n "$minclass" ]]; then
    register_check "Minimum character classes (minclass)" WARN "$minclass (recommend >= 4)"
  else
    register_check "Minimum character classes (minclass)" SKIP "not set (overridden by *credit settings)"
  fi

  # Check difok (difference from old password)
  difok=$(echo "$pwquality_settings" | grep -E "^\s*difok\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$difok" ]] && [[ "$difok" -ge 1 ]]; then
    register_check "Password difference (difok)" PASS "$difok"
  else
    register_check "Password difference (difok)" SKIP "using default"
  fi

  # Check dictionary check
  dictcheck=$(echo "$pwquality_settings" | grep -E "^\s*dictcheck\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ "$dictcheck" == "1" ]] || [[ -z "$dictcheck" ]]; then
    register_check "Dictionary check" PASS "enabled"
  else
    register_check "Dictionary check" WARN "disabled"
  fi

  # Check user/gecos check
  usercheck=$(echo "$pwquality_settings" | grep -E "^\s*usercheck\s*=" | tail -1 | cut -d= -f2 | tr -d ' ')
  if [[ "$usercheck" == "1" ]] || [[ -z "$usercheck" ]]; then
    register_check "Username check" PASS "enabled"
  else
    register_check "Username check" WARN "disabled"
  fi

  # Check enforcing for root
  enforce_for_root=$(echo "$pwquality_settings" | grep -E "^\s*enforce_for_root" | head -1)
  if [[ -n "$enforce_for_root" ]]; then
    register_check "Enforce for root" PASS "enabled"
  else
    register_check "Enforce for root" WARN "not set (root can bypass)"
  fi

else
  register_check "pwquality.conf" WARN "not found"
fi

section "PAM Password Module Configuration"

if [[ -n "$pam_file" ]] && [[ -f "$pam_file" ]]; then
  pam_contents=$(cat "$pam_file")

  # Check for pam_pwquality or pam_cracklib
  if echo "$pam_contents" | grep -qE "pam_pwquality\.so"; then
    register_check "pam_pwquality module" PASS "configured"

    # Check retry setting
    retry=$(echo "$pam_contents" | grep -oE "pam_pwquality\.so.*retry=[0-9]+" | grep -oE "retry=[0-9]+" | cut -d= -f2)
    if [[ -n "$retry" ]] && [[ "$retry" -le 3 ]]; then
      register_check "Password retry limit" PASS "$retry attempts"
    elif [[ -n "$retry" ]]; then
      register_check "Password retry limit" WARN "$retry attempts (recommend <= 3)"
    else
      register_check "Password retry limit" WARN "not set (default: 3)"
    fi

  elif echo "$pam_contents" | grep -qE "pam_cracklib\.so"; then
    register_check "pam_cracklib module" WARN "legacy (consider pam_pwquality)"
  else
    register_check "Password quality module" FAIL "neither pam_pwquality nor pam_cracklib configured"
  fi
fi

section "Password History (pam_pwhistory)"

if [[ -n "$pam_file" ]] && [[ -f "$pam_file" ]]; then
  pam_contents=$(cat "$pam_file")

  # Check pam_pwhistory
  if echo "$pam_contents" | grep -qE "pam_pwhistory\.so"; then
    register_check "pam_pwhistory module" PASS "configured"

    # Check remember value (should be >= 5)
    remember=$(echo "$pam_contents" | grep -oE "pam_pwhistory\.so.*remember=[0-9]+" | grep -oE "remember=[0-9]+" | cut -d= -f2)
    if [[ -n "$remember" ]] && [[ "$remember" -ge 5 ]]; then
      register_check "Password history (remember)" PASS "$remember passwords"
    elif [[ -n "$remember" ]]; then
      register_check "Password history (remember)" WARN "$remember passwords (recommend >= 5)"
    else
      register_check "Password history (remember)" WARN "not set"
    fi

    # Check use_authtok
    if echo "$pam_contents" | grep "pam_pwhistory" | grep -q "use_authtok"; then
      register_check "use_authtok flag" PASS "set"
    else
      register_check "use_authtok flag" WARN "not set (may cause issues)"
    fi

  elif echo "$pam_contents" | grep "pam_unix" | grep -qE "remember=[0-9]+"; then
    # Legacy: remember on pam_unix
    remember=$(echo "$pam_contents" | grep "pam_unix" | grep -oE "remember=[0-9]+" | cut -d= -f2 | head -1)
    register_check "pam_unix remember" WARN "$remember (consider pam_pwhistory)"
  else
    register_check "Password history" WARN "not configured"
  fi

  # Check for opasswd file (stores password history)
  if [[ -f "/etc/security/opasswd" ]]; then
    opasswd_perms=$(stat -c "%a" /etc/security/opasswd 2>/dev/null || echo "unknown")
    if [[ "$opasswd_perms" == "600" ]] || [[ "$opasswd_perms" == "000" ]]; then
      register_check "opasswd file permissions" PASS "$opasswd_perms"
    else
      register_check "opasswd file permissions" WARN "$opasswd_perms (should be 600)"
    fi
  else
    register_check "opasswd file" SKIP "not present (no history stored yet)"
  fi
fi

section "Password Encryption Algorithm"

# Check login.defs for ENCRYPT_METHOD
readonly LOGIN_DEFS="/etc/login.defs"
if [[ -f "$LOGIN_DEFS" ]]; then
  encrypt_method=$(grep -E "^ENCRYPT_METHOD" "$LOGIN_DEFS" | awk '{print $2}')
  if [[ "$encrypt_method" == "SHA512" ]] || [[ "$encrypt_method" == "YESCRYPT" ]]; then
    register_check "Encryption method" PASS "$encrypt_method"
  elif [[ "$encrypt_method" == "SHA256" ]]; then
    register_check "Encryption method" WARN "$encrypt_method (SHA512 or YESCRYPT recommended)"
  elif [[ -n "$encrypt_method" ]]; then
    register_check "Encryption method" FAIL "$encrypt_method (use SHA512 or YESCRYPT)"
  else
    register_check "Encryption method" WARN "not set in login.defs"
  fi

  # Check SHA_CRYPT_MIN_ROUNDS
  sha_rounds=$(grep -E "^SHA_CRYPT_MIN_ROUNDS" "$LOGIN_DEFS" | awk '{print $2}')
  if [[ -n "$sha_rounds" ]] && [[ "$sha_rounds" -ge 5000 ]]; then
    register_check "SHA crypt rounds" PASS "$sha_rounds"
  elif [[ -n "$sha_rounds" ]]; then
    register_check "SHA crypt rounds" WARN "$sha_rounds (recommend >= 5000)"
  else
    register_check "SHA crypt rounds" SKIP "using default"
  fi
fi

section "PAM Configuration Validation"

# Check for pam_unix requirements
if [[ -n "$pam_file" ]] && [[ -f "$pam_file" ]]; then
  pam_contents=$(cat "$pam_file")

  # Ensure sha512 or yescrypt in pam_unix
  if echo "$pam_contents" | grep "pam_unix" | grep -qE "sha512|yescrypt"; then
    register_check "pam_unix hashing" PASS "strong hashing configured"
  else
    register_check "pam_unix hashing" WARN "sha512/yescrypt not explicitly set"
  fi

  # Check nullok (should NOT be present for security)
  if echo "$pam_contents" | grep -q "nullok"; then
    register_check "nullok option" WARN "present (allows empty passwords)"
  else
    register_check "nullok option" PASS "not present"
  fi
fi

print_summary
exit "$EXIT_CODE"
