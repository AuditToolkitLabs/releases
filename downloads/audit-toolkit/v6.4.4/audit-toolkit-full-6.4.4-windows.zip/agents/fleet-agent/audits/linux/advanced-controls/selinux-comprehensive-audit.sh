#!/usr/bin/env bash
# selinux-comprehensive-audit.sh — SELinux Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 1.6.x (Mandatory Access Controls)
# - NIST SP 800-53: AC-3, AC-4, AC-6 (Access Enforcement, Least Privilege)
# - ISO 27001: A.9.4.1 (Information Access Restriction)
# - PCI DSS: 7.1, 7.2 (Access Control)
# - DISA STIG: V-204409-V-204414 (SELinux Configuration)
#
# Checks:
# - SELinux enforcement status
# - SELinux policy type
# - Boolean configurations
# - File context issues
# - AVC denials
# - Port contexts
# - User mappings
#
# @elevation: partial
# @elevation-reason: sestatus works without root, AVC logs and semanage may need root
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

section "SELinux Comprehensive Audit"

# Check if SELinux is available
if ! command -v getenforce >/dev/null 2>&1; then
  register_check "SELinux available" SKIP "getenforce not found - SELinux not installed"
  print_summary
  exit "$EXIT_CODE"
fi

section "SELinux Status (CIS 1.6.1.1-1.6.1.2)"

# Current enforcement mode
current_mode=$(getenforce 2>/dev/null || echo "Unknown")
case "$current_mode" in
  Enforcing)
    register_check "Enforcement mode" PASS "Enforcing"
    ;;
  Permissive)
    register_check "Enforcement mode" WARN "Permissive (logging only)"
    ;;
  Disabled)
    register_check "Enforcement mode" FAIL "SELinux disabled"
    # If disabled, skip remaining checks
    print_summary
    exit "$EXIT_CODE"
    ;;
  *)
    register_check "Enforcement mode" FAIL "Unknown: $current_mode"
    ;;
esac

# Check /etc/selinux/config
selinux_config="/etc/selinux/config"
if [[ -f "$selinux_config" ]]; then
  # Boot-time mode
  boot_mode=$(grep -E "^SELINUX=" "$selinux_config" 2>/dev/null | cut -d= -f2)
  case "$boot_mode" in
    enforcing)
      register_check "Boot mode config" PASS "enforcing"
      ;;
    permissive)
      register_check "Boot mode config" WARN "permissive"
      ;;
    disabled)
      register_check "Boot mode config" FAIL "disabled"
      ;;
    *)
      register_check "Boot mode config" WARN "unknown: $boot_mode"
      ;;
  esac

  # Check for mismatch between runtime and config
  if [[ "${current_mode,,}" != "$boot_mode" ]]; then
    register_check "Mode consistency" WARN "runtime($current_mode) != boot($boot_mode)"
  else
    register_check "Mode consistency" PASS "runtime matches config"
  fi
else
  register_check "SELinux config file" FAIL "missing $selinux_config"
fi

section "SELinux Policy Type (CIS 1.6.1.3)"

# Policy type
if [[ -f "$selinux_config" ]]; then
  policy_type=$(grep -E "^SELINUXTYPE=" "$selinux_config" 2>/dev/null | cut -d= -f2)
  case "$policy_type" in
    targeted)
      register_check "Policy type" PASS "targeted"
      ;;
    mls)
      register_check "Policy type" PASS "mls (multi-level security)"
      ;;
    minimum)
      register_check "Policy type" WARN "minimum (limited protection)"
      ;;
    *)
      register_check "Policy type" WARN "unknown: $policy_type"
      ;;
  esac
fi

# Get policy version if sestatus available
if command -v sestatus >/dev/null 2>&1; then
  policy_version=$(sestatus 2>/dev/null | grep "Loaded policy name" | awk '{print $NF}')
  max_kernel=$(sestatus 2>/dev/null | grep "Max kernel policy version" | awk '{print $NF}')
  if [[ -n "$policy_version" ]]; then
    register_check "Loaded policy" PASS "$policy_version"
  fi
  if [[ -n "$max_kernel" ]]; then
    register_check "Max kernel policy" PASS "version $max_kernel"
  fi
fi

section "SELinux Booleans"

if ! command -v getsebool >/dev/null 2>&1; then
  register_check "SELinux booleans" SKIP "getsebool not available"
else
  # Critical security booleans to check
  critical_booleans=(
    "selinuxuser_execmod:off"
    "selinuxuser_execstack:off"
    "selinuxuser_execheap:off"
    "deny_execmem:on"
    "allow_execmem:off"
    "allow_execmod:off"
    "allow_execstack:off"
    "polyinstantiation_enabled:on"
    "secure_mode:on"
    "secure_mode_insmod:on"
    "secure_mode_policyload:on"
  )

  bool_issues=0
  for entry in "${critical_booleans[@]}"; do
    bool_name="${entry%%:*}"
    expected="${entry##*:}"

    # Check if boolean exists
    actual=$(getsebool "$bool_name" 2>/dev/null | awk -F'-->' '{print $2}' | tr -d ' ')
    if [[ -z "$actual" ]]; then
      continue  # Boolean doesn't exist in this policy
    fi

    if [[ "$actual" == "$expected" ]]; then
      register_check "Bool: $bool_name" PASS "$actual"
    else
      register_check "Bool: $bool_name" WARN "$actual (expected: $expected)"
      ((bool_issues++)) || true
    fi
  done

  # Count total modified booleans
  if command -v semanage >/dev/null 2>&1; then
    modified_bools=$(semanage boolean -l -C 2>/dev/null | wc -l || echo "0")
    if [[ "$modified_bools" -gt 0 ]]; then
      register_check "Modified booleans" WARN "$modified_bools customized"
    else
      register_check "Modified booleans" PASS "none customized"
    fi
  fi
fi

section "AVC Denials"

# Check for recent AVC denials
if command -v ausearch >/dev/null 2>&1; then
  # Get count of AVC denials in last 24 hours
  avc_count=$(ausearch -m AVC -ts recent 2>/dev/null | grep -c "^type=AVC" || echo "0")
  if [[ "$avc_count" -gt 100 ]]; then
    register_check "Recent AVC denials" WARN "$avc_count denials"
  elif [[ "$avc_count" -gt 0 ]]; then
    register_check "Recent AVC denials" WARN "$avc_count denials (review recommended)"
  else
    register_check "Recent AVC denials" PASS "none"
  fi
elif [[ -f "/var/log/audit/audit.log" ]]; then
  # Fallback to grep
  today=$(date +%s)
  yesterday=$((today - 86400))
  avc_count=$(grep "type=AVC" /var/log/audit/audit.log 2>/dev/null | wc -l || echo "0")
  if [[ "$avc_count" -gt 100 ]]; then
    register_check "AVC denials (audit.log)" WARN "$avc_count total in log"
  else
    register_check "AVC denials (audit.log)" PASS "$avc_count in log"
  fi
else
  register_check "AVC denials" SKIP "ausearch & audit.log not available"
fi

# Check for permissive domains
if command -v seinfo >/dev/null 2>&1; then
  permissive_domains=$(seinfo --permissive 2>/dev/null | tail -n +3 | wc -l || echo "0")
  if [[ "$permissive_domains" -gt 0 ]]; then
    register_check "Permissive domains" WARN "$permissive_domains domains"
  else
    register_check "Permissive domains" PASS "none"
  fi
fi

section "File Context Issues"

# Check for files with incorrect labels
if command -v restorecon >/dev/null 2>&1; then
  # Check critical directories
  context_issues=0
  for dir in /etc /var /usr/bin /usr/sbin; do
    if [[ -d "$dir" ]]; then
      issues=$(restorecon -n -v -R "$dir" 2>/dev/null | wc -l || echo "0")
      ((context_issues += issues)) || true
    fi
  done

  if [[ "$context_issues" -gt 50 ]]; then
    register_check "File context issues" WARN "$context_issues mislabeled files"
  elif [[ "$context_issues" -gt 0 ]]; then
    register_check "File context issues" WARN "$context_issues mislabeled files"
  else
    register_check "File context issues" PASS "none detected"
  fi
else
  register_check "File context check" SKIP "restorecon not available"
fi

# Check for unlabeled files
if command -v find >/dev/null 2>&1; then
  unlabeled=$(find /etc /var -context '*:unlabeled_t:*' 2>/dev/null | wc -l || echo "0")
  if [[ "$unlabeled" -gt 0 ]]; then
    register_check "Unlabeled files" WARN "$unlabeled files"
  else
    register_check "Unlabeled files" PASS "none"
  fi
fi

section "SELinux User Mappings"

if command -v semanage >/dev/null 2>&1; then
  # Check SELinux user mappings
  default_user=$(semanage login -l 2>/dev/null | grep "^__default__" | awk '{print $2}')
  if [[ -n "$default_user" ]]; then
    if [[ "$default_user" == "unconfined_u" ]]; then
      register_check "Default SELinux user" WARN "unconfined_u (less restrictive)"
    else
      register_check "Default SELinux user" PASS "$default_user"
    fi
  fi

  # Count custom user mappings
  custom_mappings=$(semanage login -l 2>/dev/null | grep -v "^Login" | grep -v "^__default__" | wc -l || echo "0")
  register_check "Custom user mappings" PASS "$custom_mappings defined"
fi

section "Network Port Contexts"

if command -v semanage >/dev/null 2>&1; then
  # Count custom port definitions
  custom_ports=$(semanage port -l -C 2>/dev/null | wc -l || echo "0")
  if [[ "$custom_ports" -gt 0 ]]; then
    register_check "Custom port contexts" PASS "$custom_ports defined"
  else
    register_check "Custom port contexts" PASS "using defaults"
  fi
fi

section "SELinux Policy Modules"

if command -v semodule >/dev/null 2>&1; then
  # Count loaded modules
  module_count=$(semodule -l 2>/dev/null | wc -l || echo "0")
  register_check "Loaded modules" PASS "$module_count"

  # Check for disabled modules
  disabled=$(semodule -l 2>/dev/null | grep -c "disabled" || echo "0")
  if [[ "$disabled" -gt 0 ]]; then
    register_check "Disabled modules" WARN "$disabled modules"
  else
    register_check "Disabled modules" PASS "none disabled"
  fi
fi

section "SELinux File Systems"

# Check /sys/fs/selinux mount
if mount | grep -q "selinuxfs"; then
  register_check "SELinux filesystem" PASS "mounted"
else
  register_check "SELinux filesystem" FAIL "not mounted"
fi

# Check if /selinux exists (older systems)
if [[ -d "/selinux" ]]; then
  register_check "Legacy /selinux" WARN "exists (consider removing)"
fi

section "Kernel Parameters"

# Check for kernel boot parameters that disable SELinux
if [[ -f "/proc/cmdline" ]]; then
  cmdline=$(cat /proc/cmdline)
  if echo "$cmdline" | grep -qE "selinux=0|enforcing=0"; then
    register_check "Kernel params" FAIL "SELinux disabled via kernel params"
  else
    register_check "Kernel params" PASS "no SELinux overrides"
  fi
fi

print_summary
exit "$EXIT_CODE"
