#!/usr/bin/env bash
# services-hardening-audit.sh — Special Purpose Services & Clients Audit
#
# @elevation: root
# @elevation-reason: Checks service status and installed packages
#
# Compliance Mapping:
# - CIS Benchmark: 2.1.x (Time Synchronization), 2.2.x (Special Purpose Services),
#                  2.3.x (Service Clients)
# - NIST SP 800-53: CM-7 (Least Functionality), AC-17 (Remote Access)
# - ISO 27001: A.12.5.1 (Installation of Software)
# - PCI DSS: 2.2.2 (Enable Only Necessary Services)
# - DISA STIG: V-204406 through V-204420
#
# Checks:
# - Time synchronization (chrony, ntp, systemd-timesyncd)
# - Unnecessary services (avahi, cups, dhcpd, ldap, nfs, bind, vsftpd, etc.)
# - Unnecessary clients (ypbind, rsh, talk, telnet, ldap-utils, etc.)
# - inetd/xinetd services
# - Mail Transfer Agent (local only)

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../lib/svc.sh"
. "$SCRIPT_DIR/../../../lib/pkg.sh"

setup_colors

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="1.0.0"

# Detect distro for package name variations
DISTRO=$(detect_distro)

section "Services Hardening Audit (CIS 2.x)"
echo "Compliance: CIS 2.1.x, 2.2.x, 2.3.x, NIST CM-7, PCI DSS 2.2.2"
echo "Detected distro: $DISTRO"

# ============================================================
# CIS 2.1: Time Synchronization
# ============================================================
section "Time Synchronization (CIS 2.1.x)"

time_sync_found=false

# Check for chrony (CIS 2.1.1)
if command -v chronyd >/dev/null 2>&1 || pkg_installed chrony; then
  if svc_is_active chronyd 2>/dev/null || svc_is_active chrony 2>/dev/null; then
    register_check "chrony service (2.1.1)" PASS "Active"
    time_sync_found=true
  else
    register_check "chrony service (2.1.1)" WARN "Installed but not active"
  fi

  # Check chrony configuration
  if [[ -f /etc/chrony.conf || -f /etc/chrony/chrony.conf ]]; then
    chrony_conf="${chrony_conf:-/etc/chrony.conf}"
    [[ -f /etc/chrony/chrony.conf ]] && chrony_conf="/etc/chrony/chrony.conf"
    if grep -qE "^(server|pool)" "$chrony_conf" 2>/dev/null; then
      register_check "chrony NTP sources" PASS "Configured"
    else
      register_check "chrony NTP sources" WARN "No servers configured"
    fi
  fi
else
  register_check "chrony service (2.1.1)" SKIP "Not installed"
fi

# Check for ntp (legacy, CIS 2.1.2)
if command -v ntpd >/dev/null 2>&1 || pkg_installed ntp; then
  if svc_is_active ntpd 2>/dev/null || svc_is_active ntp 2>/dev/null; then
    register_check "ntp service (2.1.2)" WARN "Active (chrony preferred)"
    time_sync_found=true
  else
    register_check "ntp service (2.1.2)" SKIP "Installed but not active"
  fi
else
  register_check "ntp service (2.1.2)" SKIP "Not installed"
fi

# Check for systemd-timesyncd (CIS 2.1.3)
if is_systemd; then
  if svc_is_active systemd-timesyncd 2>/dev/null; then
    register_check "systemd-timesyncd (2.1.3)" PASS "Active"
    time_sync_found=true
  else
    register_check "systemd-timesyncd (2.1.3)" SKIP "Not active"
  fi
fi

# Summary check
if $time_sync_found; then
  register_check "Time synchronization" PASS "At least one service active"
else
  register_check "Time synchronization" FAIL "No time sync service active"
fi

# ============================================================
# CIS 2.2: Special Purpose Services (should be disabled unless needed)
# ============================================================
section "Special Purpose Services (CIS 2.2.x)"

# Array of services to check: "service_name|cis_ref|description"
declare -a SERVICES_TO_CHECK=(
  "avahi-daemon|2.2.1|Avahi mDNS/DNS-SD"
  "cups|2.2.2|CUPS printing"
  "dhcpd|2.2.3|DHCP Server"
  "slapd|2.2.4|LDAP Server"
  "nfs-server|2.2.5|NFS Server"
  "rpcbind|2.2.6|RPC Bind"
  "named|2.2.7|DNS Server (BIND)"
  "vsftpd|2.2.8|FTP Server (vsftpd)"
  "proftpd|2.2.8|FTP Server (proftpd)"
  "pure-ftpd|2.2.8|FTP Server (pure-ftpd)"
  "httpd|2.2.9|HTTP Server (httpd)"
  "apache2|2.2.9|HTTP Server (apache2)"
  "nginx|2.2.9|HTTP Server (nginx)"
  "dovecot|2.2.10|IMAP/POP3 Server"
  "smbd|2.2.11|Samba Server"
  "squid|2.2.12|HTTP Proxy"
  "snmpd|2.2.13|SNMP Server"
  "rsync|2.2.14|rsync daemon"
  "ypserv|2.2.15|NIS Server"
  "rsh.socket|2.2.16|RSH Server"
  "rlogin.socket|2.2.16|rlogin Server"
  "rexec.socket|2.2.16|rexec Server"
  "talk|2.2.17|Talk Server"
  "telnet.socket|2.2.18|Telnet Server"
  "tftp.socket|2.2.19|TFTP Server"
)

for entry in "${SERVICES_TO_CHECK[@]}"; do
  IFS='|' read -r svc cis_ref desc <<< "$entry"

  if svc_is_active "$svc" 2>/dev/null; then
    # Service is running - check if it's expected to be running
    case "$svc" in
      httpd|apache2|nginx)
        # Web servers might be intentional - WARN instead of FAIL
        register_check "$desc ($cis_ref)" WARN "Active - verify if needed"
        ;;
      cups)
        # Common on desktops
        register_check "$desc ($cis_ref)" WARN "Active - disable if not printing"
        ;;
      rsh*|rlogin*|rexec*|telnet*|ypserv|talk)
        # These are always bad
        register_check "$desc ($cis_ref)" FAIL "Active - INSECURE, disable immediately"
        ;;
      *)
        register_check "$desc ($cis_ref)" WARN "Active - verify if required"
        ;;
    esac
  elif svc_is_enabled "$svc" 2>/dev/null; then
    register_check "$desc ($cis_ref)" WARN "Enabled but not running"
  else
    register_check "$desc ($cis_ref)" PASS "Not active/enabled"
  fi
done

# ============================================================
# CIS 2.2.20: Ensure mail transfer agent is local-only
# ============================================================
section "Mail Transfer Agent Configuration (CIS 2.2.20)"

mta_local_only=true

# Check postfix
if command -v postconf >/dev/null 2>&1; then
  inet_interfaces=$(postconf -h inet_interfaces 2>/dev/null || echo "")
  if [[ "$inet_interfaces" == "loopback-only" || "$inet_interfaces" == "localhost" ]]; then
    register_check "Postfix local-only (2.2.20)" PASS "inet_interfaces=$inet_interfaces"
  elif [[ -n "$inet_interfaces" ]]; then
    register_check "Postfix local-only (2.2.20)" FAIL \
      "inet_interfaces=$inet_interfaces (should be loopback-only)"
    mta_local_only=false
  fi
fi

# Check sendmail
if command -v sendmail >/dev/null 2>&1 && [[ -f /etc/mail/sendmail.mc ]]; then
  if grep -q "DAEMON_OPTIONS.*127.0.0.1" /etc/mail/sendmail.mc 2>/dev/null; then
    register_check "Sendmail local-only (2.2.20)" PASS "Bound to localhost"
  elif svc_is_active sendmail 2>/dev/null; then
    register_check "Sendmail local-only (2.2.20)" WARN "Running - verify configuration"
  fi
fi

# Check exim
if command -v exim >/dev/null 2>&1 || command -v exim4 >/dev/null 2>&1; then
  if [[ -f /etc/exim4/update-exim4.conf.conf ]]; then
    dc_local=$(grep -E "^dc_local_interfaces" /etc/exim4/update-exim4.conf.conf 2>/dev/null || echo "")
    if [[ "$dc_local" == *"127.0.0.1"* || "$dc_local" == *"localhost"* ]]; then
      register_check "Exim local-only (2.2.20)" PASS "Bound to localhost"
    elif svc_is_active exim4 2>/dev/null; then
      register_check "Exim local-only (2.2.20)" WARN "Running - verify configuration"
    fi
  fi
fi

# ============================================================
# CIS 2.3: Service Clients (should not be installed)
# ============================================================
section "Service Clients (CIS 2.3.x)"

# Array of clients to check: "package_name|cis_ref|description"
declare -a CLIENTS_TO_CHECK=(
  "ypbind|2.3.1|NIS Client"
  "rsh-client|2.3.2|RSH Client"
  "rsh|2.3.2|RSH Client (RHEL)"
  "talk|2.3.3|Talk Client"
  "telnet|2.3.4|Telnet Client"
  "ldap-utils|2.3.5|LDAP Client"
  "openldap-clients|2.3.5|LDAP Client (RHEL)"
  "ftp|2.3.6|FTP Client"
)

for entry in "${CLIENTS_TO_CHECK[@]}"; do
  IFS='|' read -r pkg cis_ref desc <<< "$entry"

  if pkg_installed "$pkg" 2>/dev/null; then
    case "$pkg" in
      rsh*|telnet|talk|ypbind)
        # These are always bad
        register_check "$desc ($cis_ref)" FAIL "Installed - remove $pkg"
        ;;
      ftp)
        # FTP client might be needed for scripts
        register_check "$desc ($cis_ref)" WARN "Installed - use sftp/scp instead"
        ;;
      *)
        register_check "$desc ($cis_ref)" WARN "Installed - verify if needed"
        ;;
    esac
  else
    register_check "$desc ($cis_ref)" PASS "Not installed"
  fi
done

# ============================================================
# Additional: inetd/xinetd services
# ============================================================
section "Legacy Super-Server (inetd/xinetd)"

# Check for xinetd
if command -v xinetd >/dev/null 2>&1 || pkg_installed xinetd; then
  if svc_is_active xinetd 2>/dev/null; then
    register_check "xinetd service" FAIL "Active - review enabled services"
    # List enabled services
    if [[ -d /etc/xinetd.d ]]; then
      enabled=$(grep -l "disable.*=.*no" /etc/xinetd.d/* 2>/dev/null | wc -l || echo 0)
      register_check "xinetd enabled services" WARN "$enabled services enabled"
    fi
  else
    register_check "xinetd service" PASS "Not active"
  fi
else
  register_check "xinetd service" PASS "Not installed"
fi

# Check for inetd
if command -v inetd >/dev/null 2>&1 || pkg_installed openbsd-inetd; then
  if svc_is_active inetd 2>/dev/null; then
    register_check "inetd service" FAIL "Active - legacy, should be disabled"
  else
    register_check "inetd service" PASS "Not active"
  fi
else
  register_check "inetd service" PASS "Not installed"
fi

# ============================================================
# Additional: Wireless services
# ============================================================
section "Wireless Configuration (CIS 3.5)"

# Check if wireless interfaces exist
if command -v iwconfig >/dev/null 2>&1; then
  wireless_ifs=$(iwconfig 2>&1 | grep -v "no wireless extensions" | grep -E "^[a-zA-Z]" || true)
  if [[ -n "$wireless_ifs" ]]; then
    register_check "Wireless interfaces" WARN "Found - ensure properly secured"
    if command -v rfkill >/dev/null 2>&1; then
      blocked=$(rfkill list wifi 2>/dev/null | grep -c "Soft blocked: yes" || echo 0)
      register_check "Wireless soft-blocked" PASS "$blocked interfaces blocked"
    fi
  else
    register_check "Wireless interfaces" PASS "None found"
  fi
elif command -v ip >/dev/null 2>&1; then
  wireless_ifs=$(ip link show 2>/dev/null | grep -E "(wlan|wifi|wlp)" || true)
  if [[ -n "$wireless_ifs" ]]; then
    register_check "Wireless interfaces" WARN "Found - ensure properly secured"
  else
    register_check "Wireless interfaces" PASS "None found"
  fi
else
  register_check "Wireless interfaces" SKIP "Cannot detect (no iwconfig/ip)"
fi

# ============================================================
# Additional: Bluetooth
# ============================================================
section "Bluetooth Configuration"

if command -v bluetoothctl >/dev/null 2>&1 || pkg_installed bluez; then
  if svc_is_active bluetooth 2>/dev/null; then
    register_check "Bluetooth service" WARN "Active - disable if not needed"
  else
    register_check "Bluetooth service" PASS "Not active"
  fi
else
  register_check "Bluetooth service" PASS "Not installed"
fi

print_summary
exit "$EXIT_CODE"
