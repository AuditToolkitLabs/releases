#!/usr/bin/env bash
# shadow-password-audit.sh — Shadow File & Password Aging Audit
#
# Compliance Mapping:
# - CIS Benchmark: 5.5.1.x (Shadow Password Suite Parameters)
# - NIST SP 800-53: IA-4, IA-5 (Identifier/Authenticator Management)
# - ISO 27001: A.9.2.1, A.9.4.3 (User Registration, Password Management)
# - PCI DSS: 8.2.4 (Password Change Frequency)
# - DISA STIG: V-204409, V-204410
#
# Checks:
# - /etc/login.defs password aging settings
# - /etc/shadow file permissions
# - Password aging on existing accounts
# - Inactive account disable settings
#
# @elevation: root
# @elevation-reason: /etc/shadow file requires root privileges to read
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

# Configuration files
readonly LOGIN_DEFS="/etc/login.defs"
readonly SHADOW="/etc/shadow"
readonly PASSWD="/etc/passwd"
readonly USERADD_DEFAULTS="/etc/default/useradd"

section "Shadow Password Configuration Audit"

# Check login.defs exists
if [[ -f "$LOGIN_DEFS" ]]; then
  register_check "login.defs" PASS "present"
else
  register_check "login.defs" FAIL "not found"
  print_summary
  exit "$EXIT_CODE"
fi

login_defs=$(cat "$LOGIN_DEFS")

section "Password Aging Defaults (login.defs)"

# PASS_MAX_DAYS - Maximum password age (CIS: <= 365)
pass_max=$(echo "$login_defs" | grep -E "^PASS_MAX_DAYS" | awk '{print $2}')
if [[ -n "$pass_max" ]] && [[ "$pass_max" -le 365 ]] && [[ "$pass_max" -gt 0 ]]; then
  register_check "PASS_MAX_DAYS" PASS "$pass_max days (<= 365)"
elif [[ -n "$pass_max" ]] && [[ "$pass_max" -le 90 ]]; then
  register_check "PASS_MAX_DAYS" PASS "$pass_max days (strong)"
elif [[ -n "$pass_max" ]]; then
  register_check "PASS_MAX_DAYS" WARN "$pass_max days (recommend <= 365)"
else
  register_check "PASS_MAX_DAYS" WARN "not set"
fi

# PASS_MIN_DAYS - Minimum days between password changes (CIS: >= 1)
pass_min=$(echo "$login_defs" | grep -E "^PASS_MIN_DAYS" | awk '{print $2}')
if [[ -n "$pass_min" ]] && [[ "$pass_min" -ge 1 ]]; then
  register_check "PASS_MIN_DAYS" PASS "$pass_min days (>= 1)"
elif [[ -n "$pass_min" ]]; then
  register_check "PASS_MIN_DAYS" WARN "$pass_min (should be >= 1)"
else
  register_check "PASS_MIN_DAYS" WARN "not set"
fi

# PASS_WARN_AGE - Days before expiry to warn (CIS: >= 7)
pass_warn=$(echo "$login_defs" | grep -E "^PASS_WARN_AGE" | awk '{print $2}')
if [[ -n "$pass_warn" ]] && [[ "$pass_warn" -ge 7 ]]; then
  register_check "PASS_WARN_AGE" PASS "$pass_warn days"
elif [[ -n "$pass_warn" ]]; then
  register_check "PASS_WARN_AGE" WARN "$pass_warn days (recommend >= 7)"
else
  register_check "PASS_WARN_AGE" WARN "not set"
fi

section "Password Encryption Settings"

# ENCRYPT_METHOD
encrypt_method=$(echo "$login_defs" | grep -E "^ENCRYPT_METHOD" | awk '{print $2}')
if [[ "$encrypt_method" == "SHA512" ]] || [[ "$encrypt_method" == "YESCRYPT" ]]; then
  register_check "ENCRYPT_METHOD" PASS "$encrypt_method"
elif [[ "$encrypt_method" == "SHA256" ]]; then
  register_check "ENCRYPT_METHOD" WARN "$encrypt_method (prefer SHA512/YESCRYPT)"
elif [[ -n "$encrypt_method" ]]; then
  register_check "ENCRYPT_METHOD" FAIL "$encrypt_method (weak)"
else
  register_check "ENCRYPT_METHOD" WARN "not set (check default)"
fi

# SHA_CRYPT_MIN_ROUNDS / SHA_CRYPT_MAX_ROUNDS
sha_min_rounds=$(echo "$login_defs" | grep -E "^SHA_CRYPT_MIN_ROUNDS" | awk '{print $2}')
sha_max_rounds=$(echo "$login_defs" | grep -E "^SHA_CRYPT_MAX_ROUNDS" | awk '{print $2}')
if [[ -n "$sha_min_rounds" ]] && [[ "$sha_min_rounds" -ge 5000 ]]; then
  register_check "SHA_CRYPT_MIN_ROUNDS" PASS "$sha_min_rounds"
else
  register_check "SHA_CRYPT_MIN_ROUNDS" SKIP "not set or using default"
fi

section "Shadow File Security"

# Check shadow file exists and permissions
if [[ -f "$SHADOW" ]]; then
  shadow_perms=$(stat -c "%a" "$SHADOW" 2>/dev/null || echo "unknown")
  shadow_owner=$(stat -c "%U:%G" "$SHADOW" 2>/dev/null || echo "unknown")

  # Permissions should be 0000 or 0600 (CIS 6.1.3)
  if [[ "$shadow_perms" == "0" ]] || [[ "$shadow_perms" == "000" ]]; then
    register_check "Shadow permissions" PASS "0 (most secure)"
  elif [[ "$shadow_perms" == "600" ]]; then
    register_check "Shadow permissions" PASS "600"
  elif [[ "$shadow_perms" == "640" ]]; then
    register_check "Shadow permissions" WARN "640 (should be 0 or 600)"
  else
    register_check "Shadow permissions" FAIL "$shadow_perms (should be 0 or 600)"
  fi

  # Ownership should be root:root or root:shadow
  if [[ "$shadow_owner" == "root:root" ]] || [[ "$shadow_owner" == "root:shadow" ]]; then
    register_check "Shadow ownership" PASS "$shadow_owner"
  else
    register_check "Shadow ownership" FAIL "$shadow_owner (should be root:root)"
  fi
else
  register_check "Shadow file" FAIL "not found"
fi

# Check /etc/gshadow
readonly GSHADOW="/etc/gshadow"
if [[ -f "$GSHADOW" ]]; then
  gshadow_perms=$(stat -c "%a" "$GSHADOW" 2>/dev/null || echo "unknown")
  if [[ "$gshadow_perms" == "0" ]] || [[ "$gshadow_perms" == "000" ]] || [[ "$gshadow_perms" == "600" ]]; then
    register_check "gshadow permissions" PASS "$gshadow_perms"
  else
    register_check "gshadow permissions" WARN "$gshadow_perms"
  fi
fi

section "Passwd File Security"

# Check /etc/passwd permissions (CIS 6.1.1)
if [[ -f "$PASSWD" ]]; then
  passwd_perms=$(stat -c "%a" "$PASSWD" 2>/dev/null || echo "unknown")
  passwd_owner=$(stat -c "%U:%G" "$PASSWD" 2>/dev/null || echo "unknown")

  if [[ "$passwd_perms" == "644" ]]; then
    register_check "Passwd permissions" PASS "644"
  else
    register_check "Passwd permissions" WARN "$passwd_perms (should be 644)"
  fi

  if [[ "$passwd_owner" == "root:root" ]]; then
    register_check "Passwd ownership" PASS "root:root"
  else
    register_check "Passwd ownership" FAIL "$passwd_owner"
  fi
fi

# Check /etc/group permissions (CIS 6.1.2)
readonly GROUP="/etc/group"
if [[ -f "$GROUP" ]]; then
  group_perms=$(stat -c "%a" "$GROUP" 2>/dev/null || echo "unknown")
  if [[ "$group_perms" == "644" ]]; then
    register_check "Group permissions" PASS "644"
  else
    register_check "Group permissions" WARN "$group_perms"
  fi
fi

section "Account Password Aging Compliance"

# Check actual password aging on user accounts
if [[ -r "$SHADOW" ]] || [[ "$EUID" -eq 0 ]]; then
  # Get interactive users (UID >= 1000, not nologin/false shell)
  noncompliant_max=0
  noncompliant_min=0
  noncompliant_inactive=0
  total_users=0

  while IFS=: read -r username _ uid _ _ _ shell; do
    # Skip system accounts and accounts with no login
    [[ "$uid" -lt 1000 ]] && continue
    [[ "$shell" == */nologin ]] && continue
    [[ "$shell" == */false ]] && continue
    [[ -z "$shell" ]] && continue

    ((total_users++)) || true

    # Get shadow entry for this user
    shadow_entry=$(grep "^${username}:" "$SHADOW" 2>/dev/null || echo "")
    if [[ -z "$shadow_entry" ]]; then
      continue
    fi

    max_days=$(echo "$shadow_entry" | cut -d: -f5)
    min_days=$(echo "$shadow_entry" | cut -d: -f4)
    inactive=$(echo "$shadow_entry" | cut -d: -f7)

    # Check PASS_MAX_DAYS per user
    if [[ -n "$max_days" ]] && [[ "$max_days" -gt 365 ]]; then
      ((noncompliant_max++)) || true
    elif [[ -z "$max_days" ]] || [[ "$max_days" == "99999" ]]; then
      ((noncompliant_max++)) || true
    fi

    # Check PASS_MIN_DAYS per user
    if [[ -z "$min_days" ]] || [[ "$min_days" -lt 1 ]]; then
      ((noncompliant_min++)) || true
    fi

  done < "$PASSWD"

  if [[ "$noncompliant_max" -gt 0 ]]; then
    register_check "User PASS_MAX_DAYS" WARN "$noncompliant_max of $total_users users non-compliant"
  elif [[ "$total_users" -gt 0 ]]; then
    register_check "User PASS_MAX_DAYS" PASS "all $total_users users compliant"
  else
    register_check "User PASS_MAX_DAYS" SKIP "no interactive users found"
  fi

  if [[ "$noncompliant_min" -gt 0 ]]; then
    register_check "User PASS_MIN_DAYS" WARN "$noncompliant_min of $total_users users non-compliant"
  elif [[ "$total_users" -gt 0 ]]; then
    register_check "User PASS_MIN_DAYS" PASS "all users compliant"
  fi
else
  register_check "User password aging" SKIP "requires root to read /etc/shadow"
fi

section "Inactive Account Disable"

# Check INACTIVE in useradd defaults
if [[ -f "$USERADD_DEFAULTS" ]]; then
  inactive_default=$(grep -E "^INACTIVE" "$USERADD_DEFAULTS" | cut -d= -f2)
  if [[ -n "$inactive_default" ]] && [[ "$inactive_default" -ge 0 ]] && [[ "$inactive_default" -le 30 ]]; then
    register_check "Default INACTIVE" PASS "$inactive_default days"
  elif [[ "$inactive_default" == "-1" ]]; then
    register_check "Default INACTIVE" WARN "disabled (-1)"
  elif [[ -n "$inactive_default" ]]; then
    register_check "Default INACTIVE" WARN "$inactive_default days (recommend <= 30)"
  else
    register_check "Default INACTIVE" WARN "not set"
  fi
fi

# Also check login.defs for INACTIVE
login_inactive=$(echo "$login_defs" | grep -E "^INACTIVE" | awk '{print $2}')
if [[ -n "$login_inactive" ]]; then
  register_check "login.defs INACTIVE" PASS "$login_inactive"
fi

section "UID/GID Configuration"

# Check UID_MIN and UID_MAX
uid_min=$(echo "$login_defs" | grep -E "^UID_MIN" | awk '{print $2}')
uid_max=$(echo "$login_defs" | grep -E "^UID_MAX" | awk '{print $2}')
if [[ -n "$uid_min" ]]; then
  register_check "UID_MIN" PASS "$uid_min"
fi
if [[ -n "$uid_max" ]]; then
  register_check "UID_MAX" PASS "$uid_max"
fi

# Check SYS_UID range
sys_uid_min=$(echo "$login_defs" | grep -E "^SYS_UID_MIN" | awk '{print $2}')
sys_uid_max=$(echo "$login_defs" | grep -E "^SYS_UID_MAX" | awk '{print $2}')
if [[ -n "$sys_uid_min" ]] && [[ -n "$sys_uid_max" ]]; then
  register_check "SYS_UID range" PASS "${sys_uid_min}-${sys_uid_max}"
fi

section "UMASK Configuration"

# Check UMASK in login.defs
umask_val=$(echo "$login_defs" | grep -E "^UMASK" | awk '{print $2}')
if [[ "$umask_val" == "027" ]] || [[ "$umask_val" == "077" ]]; then
  register_check "UMASK (login.defs)" PASS "$umask_val (restrictive)"
elif [[ "$umask_val" == "022" ]]; then
  register_check "UMASK (login.defs)" WARN "$umask_val (recommend 027 or 077)"
elif [[ -n "$umask_val" ]]; then
  register_check "UMASK (login.defs)" WARN "$umask_val"
else
  register_check "UMASK (login.defs)" WARN "not set"
fi

# Check USERGROUPS_ENAB
usergroups=$(echo "$login_defs" | grep -E "^USERGROUPS_ENAB" | awk '{print $2}')
if [[ "$usergroups" == "yes" ]]; then
  register_check "USERGROUPS_ENAB" PASS "yes (private groups)"
else
  register_check "USERGROUPS_ENAB" WARN "$usergroups"
fi

section "Home Directory Defaults"

# Check CREATE_HOME
create_home=$(echo "$login_defs" | grep -E "^CREATE_HOME" | awk '{print $2}')
if [[ "$create_home" == "yes" ]]; then
  register_check "CREATE_HOME" PASS "yes"
fi

# Check HOME_MODE (RHEL/newer systems)
home_mode=$(echo "$login_defs" | grep -E "^HOME_MODE" | awk '{print $2}')
if [[ -n "$home_mode" ]]; then
  if [[ "$home_mode" == "0700" ]] || [[ "$home_mode" == "0750" ]]; then
    register_check "HOME_MODE" PASS "$home_mode (restrictive)"
  else
    register_check "HOME_MODE" WARN "$home_mode"
  fi
fi

print_summary
exit "$EXIT_CODE"
