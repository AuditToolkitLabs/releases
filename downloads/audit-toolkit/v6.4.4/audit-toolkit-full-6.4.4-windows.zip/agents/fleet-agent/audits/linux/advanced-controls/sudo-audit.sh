#!/usr/bin/env bash
# sudo-audit.sh — Sudo Configuration Security Audit
#
# @elevation: root
# @elevation-reason: Reads /etc/sudoers, /etc/sudoers.d/, runs visudo -c
#
# Compliance Mapping:
# - CIS Benchmark: 5.3.x (Sudo Configuration)
# - NIST SP 800-53: AC-6 (Least Privilege)
# - ISO 27001: A.9.2.3 (Management of Privileged Access)
# - PCI DSS: 7.1, 7.2 (Restrict Privileged Access)
# - DISA STIG: V-204429 (Sudo Configuration)
#
# Checks:
# - sudoers file permissions
# - use_pty enabled
# - logfile configured
# - NOPASSWD entries
# - Dangerous wildcards
# - env_reset, secure_path
# - Authentication timeout

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

# Configuration paths
readonly SUDOERS="/etc/sudoers"
readonly SUDOERS_D="/etc/sudoers.d"

section "Sudo Configuration Security Audit"

# Check sudo is installed
if ! command -v sudo >/dev/null 2>&1; then
  register_check "Sudo installed" FAIL "sudo not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Sudo installed" PASS "$(sudo --version 2>/dev/null | head -1)"

section "Sudoers File Security (CIS 5.3.2-5.3.4)"

# Check /etc/sudoers permissions (CIS: 0440)
if [[ -f "$SUDOERS" ]]; then
  sudoers_perms=$(stat -c "%a" "$SUDOERS" 2>/dev/null || echo "unknown")
  sudoers_owner=$(stat -c "%U:%G" "$SUDOERS" 2>/dev/null || echo "unknown")

  if [[ "$sudoers_perms" == "440" ]]; then
    register_check "Sudoers permissions" PASS "0440"
  elif [[ "$sudoers_perms" == "400" ]]; then
    register_check "Sudoers permissions" PASS "0400"
  else
    register_check "Sudoers permissions" FAIL "$sudoers_perms (should be 0440)"
  fi

  if [[ "$sudoers_owner" == "root:root" ]]; then
    register_check "Sudoers ownership" PASS "root:root"
  else
    register_check "Sudoers ownership" FAIL "$sudoers_owner"
  fi
else
  register_check "Sudoers file" FAIL "not found"
fi

# Check sudoers.d directory
if [[ -d "$SUDOERS_D" ]]; then
  sudoersd_perms=$(stat -c "%a" "$SUDOERS_D" 2>/dev/null || echo "unknown")
  if [[ "$sudoersd_perms" == "750" ]] || [[ "$sudoersd_perms" == "755" ]]; then
    register_check "sudoers.d permissions" PASS "$sudoersd_perms"
  else
    register_check "sudoers.d permissions" WARN "$sudoersd_perms"
  fi

  # Check individual files in sudoers.d
  bad_perms=0
  for f in "$SUDOERS_D"/*; do
    [[ -f "$f" ]] || continue
    perms=$(stat -c "%a" "$f" 2>/dev/null || echo "644")
    if [[ "$perms" != "440" ]] && [[ "$perms" != "400" ]]; then
      ((bad_perms++)) || true
    fi
  done

  if [[ "$bad_perms" -gt 0 ]]; then
    register_check "sudoers.d file permissions" WARN "$bad_perms files not 0440"
  else
    file_count=$(find "$SUDOERS_D" -type f 2>/dev/null | wc -l)
    register_check "sudoers.d file permissions" PASS "$file_count files OK"
  fi
fi

section "Sudo Configuration Parsing"

# Use visudo to check syntax
if visudo -c 2>&1 | grep -qi "parsed OK\|syntax ok"; then
  register_check "Sudoers syntax" PASS "valid"
else
  register_check "Sudoers syntax" FAIL "syntax errors"
fi

# Get all sudo configuration (sudoers + sudoers.d)
all_sudoers=""
if [[ -r "$SUDOERS" ]]; then
  all_sudoers=$(sudo cat "$SUDOERS" 2>/dev/null | grep -v "^#" | grep -v "^$" || cat "$SUDOERS" 2>/dev/null | grep -v "^#" | grep -v "^$")
fi
if [[ -d "$SUDOERS_D" ]]; then
  for f in "$SUDOERS_D"/*; do
    [[ -f "$f" ]] || continue
    [[ "$(basename "$f")" == *~ ]] && continue  # Skip backup files
    [[ "$(basename "$f")" == *.bak ]] && continue
    content=$(sudo cat "$f" 2>/dev/null | grep -v "^#" | grep -v "^$" || cat "$f" 2>/dev/null | grep -v "^#" | grep -v "^$")
    all_sudoers+=$'\n'"$content"
  done
fi

section "Security Defaults (CIS 5.3.5-5.3.7)"

# Check use_pty (CIS 5.3.5)
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*use_pty"; then
  register_check "Defaults use_pty" PASS "enabled"
else
  register_check "Defaults use_pty" WARN "not set (recommend for PTY allocation)"
fi

# Check logfile (CIS 5.3.6)
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+logfile"; then
  logfile=$(echo "$all_sudoers" | grep -oE "logfile\s*=\s*\"?[^\"\s]+" | head -1 | sed 's/logfile\s*=\s*"*//')
  register_check "Defaults logfile" PASS "$logfile"
else
  register_check "Defaults logfile" WARN "not set (recommend /var/log/sudo.log)"
fi

# Check log_input and log_output (sudo I/O logging)
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*log_input"; then
  register_check "Defaults log_input" PASS "enabled"
else
  register_check "Defaults log_input" SKIP "not configured (optional)"
fi

if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*log_output"; then
  register_check "Defaults log_output" PASS "enabled"
else
  register_check "Defaults log_output" SKIP "not configured (optional)"
fi

# Check env_reset (CIS 5.3.4)
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*env_reset" || echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+env_reset"; then
  register_check "Defaults env_reset" PASS "enabled"
elif echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*!env_reset"; then
  register_check "Defaults env_reset" FAIL "explicitly disabled"
else
  # Check default (usually enabled by default)
  register_check "Defaults env_reset" WARN "not explicit (check default)"
fi

# Check secure_path
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+secure_path"; then
  secure_path=$(echo "$all_sudoers" | grep -oE "secure_path\s*=\s*\"?[^\"#]+" | head -1 | sed 's/secure_path\s*=\s*"*//')
  register_check "Defaults secure_path" PASS "set"
else
  register_check "Defaults secure_path" WARN "not set"
fi

section "Authentication Settings"

# Check timestamp_timeout
timeout_val=$(echo "$all_sudoers" | grep -oE "timestamp_timeout\s*=\s*[0-9.-]+" | cut -d= -f2 | tr -d ' ' | head -1)
if [[ -n "$timeout_val" ]]; then
  if [[ "$timeout_val" == "0" ]]; then
    register_check "timestamp_timeout" PASS "0 (always ask)"
  elif [[ "$timeout_val" -le 5 ]]; then
    register_check "timestamp_timeout" PASS "$timeout_val minutes"
  else
    register_check "timestamp_timeout" WARN "$timeout_val minutes (recommend <= 5)"
  fi
else
  register_check "timestamp_timeout" WARN "not set (default: 5)"
fi

# Check passwd_tries
passwd_tries=$(echo "$all_sudoers" | grep -oE "passwd_tries\s*=\s*[0-9]+" | cut -d= -f2 | tr -d ' ' | head -1)
if [[ -n "$passwd_tries" ]]; then
  register_check "passwd_tries" PASS "$passwd_tries"
fi

# Check requiretty
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*requiretty"; then
  register_check "Defaults requiretty" PASS "enabled"
elif echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*!requiretty"; then
  register_check "Defaults requiretty" WARN "disabled"
else
  register_check "Defaults requiretty" SKIP "not set"
fi

section "Dangerous Configurations"

# Check for NOPASSWD entries (CIS concern)
nopasswd_entries=$(echo "$all_sudoers" | grep -i "NOPASSWD" | grep -v "^#" || echo "")
if [[ -n "$nopasswd_entries" ]]; then
  count=$(echo "$nopasswd_entries" | wc -l)
  register_check "NOPASSWD entries" WARN "$count entries (security risk)"
else
  register_check "NOPASSWD entries" PASS "none found"
fi

# Check for !authenticate (same as NOPASSWD)
if echo "$all_sudoers" | grep -qi "!authenticate"; then
  register_check "!authenticate" WARN "disabled authentication found"
else
  register_check "!authenticate" PASS "not found"
fi

# Check for dangerous wildcards
dangerous_wildcards=0
if echo "$all_sudoers" | grep -qE "\s+ALL\s*=\s*\(ALL[^)]*\)\s+ALL\s*$"; then
  ((dangerous_wildcards++)) || true
fi
if echo "$all_sudoers" | grep -qE "\s+/bin/\*|\s+/usr/bin/\*|\s+/sbin/\*"; then
  ((dangerous_wildcards++)) || true
fi
if echo "$all_sudoers" | grep -qE "\s+\*\s*$"; then
  ((dangerous_wildcards++)) || true
fi

if [[ "$dangerous_wildcards" -gt 0 ]]; then
  register_check "Dangerous wildcards" WARN "$dangerous_wildcards risky patterns"
else
  register_check "Dangerous wildcards" PASS "none found"
fi

# Check for dangerous command patterns
dangerous_cmds=0
dangerous_patterns=(
  "/bin/bash"
  "/bin/sh"
  "/bin/su"
  "/usr/bin/su"
  "sudoedit"
  "visudo"
  "/bin/vi"
  "/usr/bin/vi"
  "/usr/bin/vim"
  "/bin/chmod"
  "/usr/bin/passwd"
)

for pattern in "${dangerous_patterns[@]}"; do
  if echo "$all_sudoers" | grep -qE "\s+${pattern}(\s|$)" 2>/dev/null; then
    # Check if it's unrestricted
    if echo "$all_sudoers" | grep -E "\s+${pattern}(\s|$)" | grep -qE "NOPASSWD|ALL\s*=\s*\(ALL"; then
      ((dangerous_cmds++)) || true
    fi
  fi
done

if [[ "$dangerous_cmds" -gt 0 ]]; then
  register_check "Dangerous commands" WARN "$dangerous_cmds risky command grants"
else
  register_check "Dangerous commands" PASS "no unrestricted dangerous commands"
fi

section "Sudo Groups"

# Check sudo/wheel group membership
sudo_group=""
if getent group sudo >/dev/null 2>&1; then
  sudo_group="sudo"
elif getent group wheel >/dev/null 2>&1; then
  sudo_group="wheel"
fi

if [[ -n "$sudo_group" ]]; then
  members=$(getent group "$sudo_group" | cut -d: -f4)
  if [[ -n "$members" ]]; then
    count=$(echo "$members" | tr ',' '\n' | wc -l)
    register_check "$sudo_group group members" PASS "$count members"
  else
    register_check "$sudo_group group members" PASS "no direct members"
  fi
fi

# Check for %sudo or %wheel in sudoers
if echo "$all_sudoers" | grep -qE "^%sudo|^%wheel"; then
  register_check "Group sudo access" PASS "$sudo_group has sudo"
fi

section "Environment Variables"

# Check env_keep (what's preserved)
env_keep=$(echo "$all_sudoers" | grep -oE "env_keep\s*\+?=\s*\"[^\"]+\"" | head -1)
if [[ -n "$env_keep" ]]; then
  register_check "env_keep configured" PASS
fi

# Check env_check
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*env_check"; then
  register_check "env_check" PASS "configured"
fi

# Check for dangerous env preservation
if echo "$all_sudoers" | grep -qE "env_keep.*LD_PRELOAD|env_keep.*LD_LIBRARY"; then
  register_check "LD_ env preserved" FAIL "dangerous LD_* variables preserved"
else
  register_check "LD_ env preserved" PASS "not preserved"
fi

section "Sudo Authentication"

# Check if targetpw or rootpw is set
if echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*targetpw"; then
  register_check "Auth: targetpw" WARN "authenticate as target user"
elif echo "$all_sudoers" | grep -qiE "^\s*Defaults\s+.*rootpw"; then
  register_check "Auth: rootpw" WARN "authenticate as root"
else
  register_check "Auth: user password" PASS "authenticate as invoking user"
fi

# Check sudoers_locale
if echo "$all_sudoers" | grep -qiE "sudoers_locale"; then
  register_check "sudoers_locale" PASS "set"
fi

section "Sudo Logging Verification"

# Check if sudo log file exists if configured
logfile=$(echo "$all_sudoers" | grep -oE "logfile\s*=\s*\"?[^\"\s]+" | head -1 | sed 's/logfile\s*=\s*"*//')
if [[ -n "$logfile" ]] && [[ -f "$logfile" ]]; then
  log_perms=$(stat -c "%a" "$logfile" 2>/dev/null || echo "unknown")
  register_check "Sudo logfile exists" PASS "$logfile ($log_perms)"
elif [[ -n "$logfile" ]]; then
  register_check "Sudo logfile exists" WARN "configured but not created"
fi

# Check syslog integration
if echo "$all_sudoers" | grep -qiE "syslog\s*="; then
  syslog_facility=$(echo "$all_sudoers" | grep -oE "syslog\s*=\s*\w+" | head -1 | cut -d= -f2 | tr -d ' ')
  register_check "Syslog facility" PASS "$syslog_facility"
fi

print_summary
exit "$EXIT_CODE"
