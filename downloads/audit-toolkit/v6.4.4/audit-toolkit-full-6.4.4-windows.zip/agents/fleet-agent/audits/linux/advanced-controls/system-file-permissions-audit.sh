#!/usr/bin/env bash
# system-file-permissions-audit.sh — System File Permissions Audit
#
# @elevation: root
# @elevation-reason: Checks permissions on sensitive system files
#
# Compliance Mapping:
# - CIS Benchmark: 6.1.1-6.1.14 (System File Permissions)
# - NIST SP 800-53: AC-3 (Access Enforcement), AC-6 (Least Privilege)
# - ISO 27001: A.9.2.3 (Management of Privileged Access)
# - PCI DSS: 2.2 (System Hardening), 7.1 (Restrict Access)
# - DISA STIG: V-204392, V-204393, V-204394, V-204395
#
# Checks:
# - /etc/passwd permissions and ownership (CIS 6.1.1, 6.1.2)
# - /etc/shadow permissions and ownership (CIS 6.1.3, 6.1.4)
# - /etc/group permissions and ownership (CIS 6.1.5, 6.1.6)
# - /etc/gshadow permissions and ownership (CIS 6.1.7, 6.1.8)
# - /etc/passwd- backup file permissions (CIS 6.1.9)
# - /etc/shadow- backup file permissions (CIS 6.1.10)
# - /etc/group- backup file permissions (CIS 6.1.11)
# - /etc/gshadow- backup file permissions (CIS 6.1.12)
# - World-writable files (CIS 6.1.13)
# - Unowned files (CIS 6.1.14)

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

setup_colors

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="1.0.0"

section "System File Permissions Audit (CIS 6.1.x)"
echo "Compliance: CIS 6.1.1-6.1.14, NIST AC-3/AC-6, PCI DSS 2.2/7.1"

# Helper function to check file permissions and ownership
check_file_perms() {
  local file="$1"
  local expected_perms="$2"
  local expected_owner="$3"
  local expected_group="$4"
  local cis_ref="$5"
  local check_name="$6"

  if [[ ! -e "$file" ]]; then
    register_check "$check_name exists" SKIP "$file not found"
    return 0
  fi

  local actual_perms actual_owner actual_group
  actual_perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")
  actual_owner=$(stat -c "%U" "$file" 2>/dev/null || echo "unknown")
  actual_group=$(stat -c "%G" "$file" 2>/dev/null || echo "unknown")

  # Check permissions
  local perms_ok=true
  # Convert expected to numeric for comparison
  if [[ "$actual_perms" != "$expected_perms" ]]; then
    # Check if actual is more restrictive (lower octal value means more restrictive)
    if [[ "$actual_perms" -gt "$expected_perms" ]]; then
      perms_ok=false
    fi
  fi

  # Check ownership
  local owner_ok=true
  if [[ "$actual_owner" != "$expected_owner" ]]; then
    owner_ok=false
  fi

  local group_ok=true
  if [[ "$actual_group" != "$expected_group" ]]; then
    group_ok=false
  fi

  if $perms_ok && $owner_ok && $group_ok; then
    register_check "$check_name ($cis_ref)" PASS \
      "perms=$actual_perms owner=$actual_owner:$actual_group"
  elif ! $perms_ok; then
    register_check "$check_name ($cis_ref)" FAIL \
      "perms=$actual_perms (expected $expected_perms or more restrictive)"
  elif ! $owner_ok || ! $group_ok; then
    register_check "$check_name ($cis_ref)" FAIL \
      "owner=$actual_owner:$actual_group (expected $expected_owner:$expected_group)"
  fi
}

section "Authentication Files (CIS 6.1.1-6.1.8)"

# CIS 6.1.1: Ensure permissions on /etc/passwd are configured
# Expected: 644 or more restrictive, owned by root:root
check_file_perms "/etc/passwd" "644" "root" "root" "6.1.1" "/etc/passwd perms"

# CIS 6.1.2: Ensure permissions on /etc/passwd- are configured
check_file_perms "/etc/passwd-" "644" "root" "root" "6.1.2" "/etc/passwd- perms"

# CIS 6.1.3: Ensure permissions on /etc/group are configured
check_file_perms "/etc/group" "644" "root" "root" "6.1.3" "/etc/group perms"

# CIS 6.1.4: Ensure permissions on /etc/group- are configured
check_file_perms "/etc/group-" "644" "root" "root" "6.1.4" "/etc/group- perms"

# CIS 6.1.5: Ensure permissions on /etc/shadow are configured
# Shadow should be 640 or more restrictive (some distros use 000)
if [[ -f "/etc/shadow" ]]; then
  shadow_perms=$(stat -c "%a" "/etc/shadow" 2>/dev/null || echo "unknown")
  shadow_owner=$(stat -c "%U" "/etc/shadow" 2>/dev/null || echo "unknown")
  shadow_group=$(stat -c "%G" "/etc/shadow" 2>/dev/null || echo "unknown")

  # Valid groups: root or shadow
  if [[ "$shadow_perms" -le 640 && "$shadow_owner" == "root" ]] && \
     [[ "$shadow_group" == "root" || "$shadow_group" == "shadow" ]]; then
    register_check "/etc/shadow perms (6.1.5)" PASS \
      "perms=$shadow_perms owner=$shadow_owner:$shadow_group"
  else
    register_check "/etc/shadow perms (6.1.5)" FAIL \
      "perms=$shadow_perms (should be <=640), owner=$shadow_owner:$shadow_group"
  fi
else
  register_check "/etc/shadow perms (6.1.5)" SKIP "File not found"
fi

# CIS 6.1.6: Ensure permissions on /etc/shadow- are configured
if [[ -f "/etc/shadow-" ]]; then
  shadowb_perms=$(stat -c "%a" "/etc/shadow-" 2>/dev/null || echo "unknown")
  shadowb_owner=$(stat -c "%U" "/etc/shadow-" 2>/dev/null || echo "unknown")
  shadowb_group=$(stat -c "%G" "/etc/shadow-" 2>/dev/null || echo "unknown")

  if [[ "$shadowb_perms" -le 640 && "$shadowb_owner" == "root" ]] && \
     [[ "$shadowb_group" == "root" || "$shadowb_group" == "shadow" ]]; then
    register_check "/etc/shadow- perms (6.1.6)" PASS \
      "perms=$shadowb_perms owner=$shadowb_owner:$shadowb_group"
  else
    register_check "/etc/shadow- perms (6.1.6)" FAIL \
      "perms=$shadowb_perms owner=$shadowb_owner:$shadowb_group"
  fi
else
  register_check "/etc/shadow- perms (6.1.6)" SKIP "File not found"
fi

# CIS 6.1.7: Ensure permissions on /etc/gshadow are configured
if [[ -f "/etc/gshadow" ]]; then
  gshadow_perms=$(stat -c "%a" "/etc/gshadow" 2>/dev/null || echo "unknown")
  gshadow_owner=$(stat -c "%U" "/etc/gshadow" 2>/dev/null || echo "unknown")
  gshadow_group=$(stat -c "%G" "/etc/gshadow" 2>/dev/null || echo "unknown")

  if [[ "$gshadow_perms" -le 640 && "$gshadow_owner" == "root" ]] && \
     [[ "$gshadow_group" == "root" || "$gshadow_group" == "shadow" ]]; then
    register_check "/etc/gshadow perms (6.1.7)" PASS \
      "perms=$gshadow_perms owner=$gshadow_owner:$gshadow_group"
  else
    register_check "/etc/gshadow perms (6.1.7)" FAIL \
      "perms=$gshadow_perms owner=$gshadow_owner:$gshadow_group"
  fi
else
  register_check "/etc/gshadow perms (6.1.7)" SKIP "File not found (normal on some distros)"
fi

# CIS 6.1.8: Ensure permissions on /etc/gshadow- are configured
if [[ -f "/etc/gshadow-" ]]; then
  gshadowb_perms=$(stat -c "%a" "/etc/gshadow-" 2>/dev/null || echo "unknown")
  gshadowb_owner=$(stat -c "%U" "/etc/gshadow-" 2>/dev/null || echo "unknown")
  gshadowb_group=$(stat -c "%G" "/etc/gshadow-" 2>/dev/null || echo "unknown")

  if [[ "$gshadowb_perms" -le 640 && "$gshadowb_owner" == "root" ]] && \
     [[ "$gshadowb_group" == "root" || "$gshadowb_group" == "shadow" ]]; then
    register_check "/etc/gshadow- perms (6.1.8)" PASS \
      "perms=$gshadowb_perms owner=$gshadowb_owner:$gshadowb_group"
  else
    register_check "/etc/gshadow- perms (6.1.8)" FAIL \
      "perms=$gshadowb_perms owner=$gshadowb_owner:$gshadowb_group"
  fi
else
  register_check "/etc/gshadow- perms (6.1.8)" SKIP "File not found"
fi

section "Critical Configuration Files"

# Additional important system files
check_file_perms "/etc/shells" "644" "root" "root" "N/A" "/etc/shells perms"
check_file_perms "/etc/security/opasswd" "600" "root" "root" "N/A" "/etc/security/opasswd"
check_file_perms "/etc/crontab" "600" "root" "root" "5.1.2" "/etc/crontab perms"
check_file_perms "/etc/cron.hourly" "700" "root" "root" "5.1.3" "/etc/cron.hourly perms"
check_file_perms "/etc/cron.daily" "700" "root" "root" "5.1.4" "/etc/cron.daily perms"
check_file_perms "/etc/cron.weekly" "700" "root" "root" "5.1.5" "/etc/cron.weekly perms"
check_file_perms "/etc/cron.monthly" "700" "root" "root" "5.1.6" "/etc/cron.monthly perms"
check_file_perms "/etc/cron.d" "700" "root" "root" "5.1.7" "/etc/cron.d perms"

# SSH configuration
if [[ -f "/etc/ssh/sshd_config" ]]; then
  check_file_perms "/etc/ssh/sshd_config" "600" "root" "root" "5.2.1" "sshd_config perms"
fi

section "World-Writable Files (CIS 6.1.9)"

# Find world-writable files (excluding /proc, /sys, /dev)
ww_count=0
if [[ $EUID -eq 0 ]]; then
  while IFS= read -r file; do
    if [[ -n "$file" ]]; then
      ((ww_count++)) || true
      if [[ $ww_count -le 10 ]]; then
        echo "  [WARN] World-writable: $file"
      fi
    fi
  done < <(find / -xdev -type f -perm -0002 \
    -not -path "/proc/*" \
    -not -path "/sys/*" \
    -not -path "/dev/*" \
    -not -path "/run/*" \
    2>/dev/null | head -100)

  if [[ $ww_count -eq 0 ]]; then
    register_check "World-writable files (6.1.9)" PASS "None found"
  elif [[ $ww_count -le 5 ]]; then
    register_check "World-writable files (6.1.9)" WARN "$ww_count found"
  else
    register_check "World-writable files (6.1.9)" FAIL "$ww_count found"
  fi
else
  register_check "World-writable files (6.1.9)" SKIP "Requires root"
fi

section "Unowned Files and Directories (CIS 6.1.10-6.1.11)"

# Find files without valid owner
if [[ $EUID -eq 0 ]]; then
  unowned_count=0
  while IFS= read -r file; do
    if [[ -n "$file" ]]; then
      ((unowned_count++)) || true
      if [[ $unowned_count -le 10 ]]; then
        echo "  [WARN] No valid owner: $file"
      fi
    fi
  done < <(find / -xdev \( -nouser -o -nogroup \) \
    -not -path "/proc/*" \
    -not -path "/sys/*" \
    -not -path "/dev/*" \
    2>/dev/null | head -100)

  if [[ $unowned_count -eq 0 ]]; then
    register_check "Unowned files (6.1.10-11)" PASS "None found"
  elif [[ $unowned_count -le 10 ]]; then
    register_check "Unowned files (6.1.10-11)" WARN "$unowned_count found"
  else
    register_check "Unowned files (6.1.10-11)" FAIL "$unowned_count found"
  fi
else
  register_check "Unowned files (6.1.10-11)" SKIP "Requires root"
fi

section "Sticky Bit on World-Writable Directories (CIS 6.1.12)"

# World-writable directories should have sticky bit
if [[ $EUID -eq 0 ]]; then
  no_sticky=0
  while IFS= read -r dir; do
    if [[ -n "$dir" ]]; then
      ((no_sticky++)) || true
      if [[ $no_sticky -le 10 ]]; then
        echo "  [WARN] Missing sticky bit: $dir"
      fi
    fi
  done < <(find / -xdev -type d -perm -0002 ! -perm -1000 \
    -not -path "/proc/*" \
    -not -path "/sys/*" \
    -not -path "/dev/*" \
    2>/dev/null | head -100)

  if [[ $no_sticky -eq 0 ]]; then
    register_check "Sticky bit (6.1.12)" PASS "All world-writable dirs have sticky bit"
  else
    register_check "Sticky bit (6.1.12)" FAIL "$no_sticky dirs missing sticky bit"
  fi
else
  register_check "Sticky bit (6.1.12)" SKIP "Requires root"
fi

section "Boot Configuration Files"

# GRUB configuration permissions
for grub_cfg in /boot/grub/grub.cfg /boot/grub2/grub.cfg /boot/loader/loader.conf; do
  if [[ -f "$grub_cfg" ]]; then
    grub_perms=$(stat -c "%a" "$grub_cfg" 2>/dev/null || echo "unknown")
    grub_owner=$(stat -c "%U:%G" "$grub_cfg" 2>/dev/null || echo "unknown")
    if [[ "$grub_perms" -le 600 ]]; then
      register_check "$(basename "$grub_cfg") perms" PASS \
        "perms=$grub_perms owner=$grub_owner"
    else
      register_check "$(basename "$grub_cfg") perms" WARN \
        "perms=$grub_perms (should be 600 or less)"
    fi
    break
  fi
done

# Kernel files
for kernel_file in /boot/vmlinuz* /boot/initramfs* /boot/initrd*; do
  if [[ -f "$kernel_file" ]]; then
    k_perms=$(stat -c "%a" "$kernel_file" 2>/dev/null | head -1 || echo "unknown")
    k_owner=$(stat -c "%U" "$kernel_file" 2>/dev/null | head -1 || echo "unknown")
    if [[ "$k_owner" == "root" ]]; then
      register_check "Kernel file ownership" PASS "Owned by root"
    else
      register_check "Kernel file ownership" FAIL "Not owned by root"
    fi
    break
  fi
done

print_summary
exit "$EXIT_CODE"
