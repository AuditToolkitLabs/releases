#!/usr/bin/env bash
# tcp-wrappers-audit.sh — TCP Wrappers Security Audit
#
# @elevation: root
# @elevation-reason: Reads /etc/hosts.allow and /etc/hosts.deny
#
# Compliance Mapping:
# - CIS Benchmark: 3.3.x (TCP Wrappers)
# - NIST SP 800-53: SC-7 (Boundary Protection), AC-4 (Information Flow)
# - ISO 27001: A.13.1.1 (Network Controls)
# - PCI DSS: 1.1, 1.2 (Firewall Configuration)
#
# Checks:
# - TCP Wrappers packages installed (CIS 3.3.1)
# - /etc/hosts.allow configured (CIS 3.3.2)
# - /etc/hosts.deny configured (CIS 3.3.3)
# - hosts.allow and hosts.deny permissions (CIS 3.3.4, 3.3.5)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../lib/pkg.sh"

setup_colors

section "TCP Wrappers Security Audit (CIS 3.3.x)"
echo "Compliance: CIS 3.3.1-3.3.5, NIST SC-7/AC-4, PCI DSS 1.1-1.2"

# ============================================================
# CIS 3.3.1: Ensure TCP Wrappers is installed
# ============================================================
section "TCP Wrappers Installation (CIS 3.3.1)"

# Package names vary by distro
tcp_wrappers_installed=false
DISTRO=$(detect_distro)

case "$DISTRO" in
  ubuntu|debian)
    if pkg_installed tcpd 2>/dev/null || pkg_installed libwrap0 2>/dev/null; then
      tcp_wrappers_installed=true
      register_check "TCP Wrappers (3.3.1)" PASS "libwrap installed"
    fi
    ;;
  rhel|centos|fedora|rocky|alma)
    if pkg_installed tcp_wrappers 2>/dev/null; then
      tcp_wrappers_installed=true
      register_check "TCP Wrappers (3.3.1)" PASS "tcp_wrappers installed"
    fi
    ;;
  alpine)
    # Alpine doesn't typically use TCP Wrappers
    register_check "TCP Wrappers (3.3.1)" SKIP "Not applicable on Alpine"
    tcp_wrappers_installed=false
    ;;
  *)
    # Generic check
    if [[ -f /etc/hosts.allow ]] && [[ -f /etc/hosts.deny ]]; then
      tcp_wrappers_installed=true
      register_check "TCP Wrappers (3.3.1)" PASS "Config files present"
    fi
    ;;
esac

if ! $tcp_wrappers_installed && [[ "$DISTRO" != "alpine" ]]; then
  register_check "TCP Wrappers (3.3.1)" WARN "Not detected - consider installing"
fi

# ============================================================
# CIS 3.3.2: Ensure /etc/hosts.allow is configured
# ============================================================
section "hosts.allow Configuration (CIS 3.3.2)"

if [[ -f /etc/hosts.allow ]]; then
  # Check if there are any rules (non-comment, non-empty lines)
  allow_rules=$(grep -v '^\s*#' /etc/hosts.allow 2>/dev/null | grep -v '^\s*$' | wc -l || echo 0)

  if [[ "$allow_rules" -gt 0 ]]; then
    register_check "hosts.allow rules (3.3.2)" PASS "$allow_rules rules configured"

    # Check for overly permissive rules
    if grep -qE '^\s*ALL\s*:\s*ALL' /etc/hosts.allow 2>/dev/null; then
      register_check "hosts.allow ALL:ALL" FAIL "Overly permissive - allows all"
    else
      register_check "hosts.allow restrictions" PASS "No ALL:ALL rule"
    fi

    # Show summary of what's allowed
    echo "  Configured allow rules:"
    grep -v '^\s*#' /etc/hosts.allow 2>/dev/null | grep -v '^\s*$' | head -5 | while read -r line; do
      echo "    $line"
    done
  else
    register_check "hosts.allow rules (3.3.2)" WARN "No rules configured"
  fi
else
  register_check "hosts.allow (3.3.2)" WARN "File not found"
fi

# ============================================================
# CIS 3.3.3: Ensure /etc/hosts.deny is configured
# ============================================================
section "hosts.deny Configuration (CIS 3.3.3)"

if [[ -f /etc/hosts.deny ]]; then
  deny_rules=$(grep -v '^\s*#' /etc/hosts.deny 2>/dev/null | grep -v '^\s*$' | wc -l || echo 0)

  if [[ "$deny_rules" -gt 0 ]]; then
    register_check "hosts.deny rules (3.3.3)" PASS "$deny_rules rules configured"

    # Best practice: hosts.deny should have "ALL: ALL" as default deny
    if grep -qE '^\s*ALL\s*:\s*ALL' /etc/hosts.deny 2>/dev/null; then
      register_check "hosts.deny default deny" PASS "ALL:ALL configured (good)"
    else
      register_check "hosts.deny default deny" WARN "No ALL:ALL - consider adding"
    fi

    # Show deny rules
    echo "  Configured deny rules:"
    grep -v '^\s*#' /etc/hosts.deny 2>/dev/null | grep -v '^\s*$' | head -5 | while read -r line; do
      echo "    $line"
    done
  else
    register_check "hosts.deny rules (3.3.3)" WARN "No rules - add 'ALL: ALL' for default deny"
  fi
else
  register_check "hosts.deny (3.3.3)" WARN "File not found"
fi

# ============================================================
# CIS 3.3.4: Ensure permissions on /etc/hosts.allow are configured
# ============================================================
section "hosts.allow Permissions (CIS 3.3.4)"

if [[ -f /etc/hosts.allow ]]; then
  allow_perms=$(stat -c "%a" /etc/hosts.allow 2>/dev/null || echo "unknown")
  allow_owner=$(stat -c "%U:%G" /etc/hosts.allow 2>/dev/null || echo "unknown")

  # Should be 644 or more restrictive, owned by root:root
  if [[ "$allow_perms" -le "644" ]] && [[ "$allow_owner" == "root:root" ]]; then
    register_check "hosts.allow perms (3.3.4)" PASS "perms=$allow_perms owner=$allow_owner"
  else
    register_check "hosts.allow perms (3.3.4)" FAIL \
      "perms=$allow_perms owner=$allow_owner (should be 644 root:root)"
  fi
else
  register_check "hosts.allow perms (3.3.4)" SKIP "File not found"
fi

# ============================================================
# CIS 3.3.5: Ensure permissions on /etc/hosts.deny are configured
# ============================================================
section "hosts.deny Permissions (CIS 3.3.5)"

if [[ -f /etc/hosts.deny ]]; then
  deny_perms=$(stat -c "%a" /etc/hosts.deny 2>/dev/null || echo "unknown")
  deny_owner=$(stat -c "%U:%G" /etc/hosts.deny 2>/dev/null || echo "unknown")

  if [[ "$deny_perms" -le "644" ]] && [[ "$deny_owner" == "root:root" ]]; then
    register_check "hosts.deny perms (3.3.5)" PASS "perms=$deny_perms owner=$deny_owner"
  else
    register_check "hosts.deny perms (3.3.5)" FAIL \
      "perms=$deny_perms owner=$deny_owner (should be 644 root:root)"
  fi
else
  register_check "hosts.deny perms (3.3.5)" SKIP "File not found"
fi

# ============================================================
# Additional: Service compatibility check
# ============================================================
section "TCP Wrappers Service Compatibility"

# Check if common services support TCP Wrappers
services_with_tcpwrap=0

# SSH usually supports TCP Wrappers
if [[ -f /etc/ssh/sshd_config ]]; then
  # Modern sshd often compiled with libwrap support
  if command -v ldd >/dev/null 2>&1; then
    sshd_path=$(command -v sshd 2>/dev/null || echo "/usr/sbin/sshd")
    if [[ -x "$sshd_path" ]]; then
      if ldd "$sshd_path" 2>/dev/null | grep -q libwrap; then
        register_check "sshd TCP Wrappers" PASS "Compiled with libwrap"
        ((services_with_tcpwrap++)) || true
      else
        register_check "sshd TCP Wrappers" WARN "Not compiled with libwrap"
      fi
    fi
  fi
fi

# Check xinetd services if present
if [[ -d /etc/xinetd.d ]]; then
  xinetd_services=$(find /etc/xinetd.d -type f 2>/dev/null | wc -l || echo 0)
  if [[ "$xinetd_services" -gt 0 ]]; then
    register_check "xinetd services" WARN "$xinetd_services services - review TCP Wrappers settings"
  fi
fi

# Recommendation summary
section "TCP Wrappers Recommendation"

if [[ -f /etc/hosts.allow ]] && [[ -f /etc/hosts.deny ]]; then
  echo "  TCP Wrappers configuration found."
  echo "  Best practice:"
  echo "    1. /etc/hosts.deny should contain: ALL: ALL"
  echo "    2. /etc/hosts.allow should whitelist specific allowed hosts/services"
  echo "    3. Example hosts.allow: sshd: 192.168.1.0/24 10.0.0.0/8"

  if ! grep -qE '^\s*ALL\s*:\s*ALL' /etc/hosts.deny 2>/dev/null; then
    register_check "Default deny policy" WARN "Add 'ALL: ALL' to /etc/hosts.deny"
  else
    register_check "Default deny policy" PASS "Properly configured"
  fi
else
  echo "  TCP Wrappers not configured."
  echo "  Note: Modern systems often use firewall (iptables/nftables/firewalld)"
  echo "  instead of or in addition to TCP Wrappers."
  register_check "TCP Wrappers status" WARN "Consider configuring or use firewall"
fi

print_summary
exit "$EXIT_CODE"
