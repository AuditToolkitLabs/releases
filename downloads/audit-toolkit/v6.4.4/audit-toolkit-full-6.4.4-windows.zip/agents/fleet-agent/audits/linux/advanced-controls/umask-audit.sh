#!/usr/bin/env bash
# umask-audit.sh — Default Umask Security Audit
#
# @elevation: none
# @elevation-reason: Reads system configuration files accessible to all users
#
# Compliance Mapping:
# - CIS Benchmark: 5.4.4 (Ensure default user umask is 027 or more restrictive)
# - NIST SP 800-53: AC-6 (Least Privilege)
# - ISO 27001: A.9.1.2 (Access to Networks and Network Services)
# - PCI DSS: 7.1 (Restrict Access)
#
# Checks:
# - Default umask in /etc/bashrc, /etc/profile
# - Default umask in /etc/login.defs
# - Default umask in /etc/profile.d/
# - PAM umask settings (pam_umask)
# - User shell rc files

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

setup_colors

section "Default Umask Security Audit (CIS 5.4.4)"
echo "Compliance: CIS 5.4.4, NIST AC-6, PCI DSS 7.1"
echo "Requirement: Default umask should be 027 or more restrictive (e.g., 077)"

# ============================================================
# Helper function to check if umask is restrictive enough
# ============================================================
check_umask_value() {
  local umask_val="$1"
  local source="$2"

  # Remove leading zeros and normalize
  umask_val="${umask_val#0}"
  umask_val="${umask_val#0}"

  # Valid restrictive umasks: 027, 077, 077, etc.
  # The last digit (other permissions) should be 7
  # The middle digit (group permissions) should be >= 2 (no write) or 7

  local other_perms="${umask_val: -1}"
  local group_perms="${umask_val: -2:1}"

  if [[ "$other_perms" -ge 7 ]]; then
    # Fully restrictive for others
    if [[ "$group_perms" -ge 2 ]]; then
      register_check "Umask in $source" PASS "umask=$umask_val (restrictive)"
      return 0
    else
      register_check "Umask in $source" WARN "umask=$umask_val (group has write access)"
      return 1
    fi
  elif [[ "$other_perms" -ge 2 ]]; then
    # Others can read but not write
    register_check "Umask in $source" WARN "umask=$umask_val (others can read)"
    return 1
  else
    register_check "Umask in $source" FAIL "umask=$umask_val (too permissive)"
    return 1
  fi
}

# Track if we found any umask configuration
umask_found=false
restrictive=0
permissive=0

# ============================================================
# Check /etc/login.defs (CIS primary location)
# ============================================================
section "login.defs Configuration"

if [[ -f /etc/login.defs ]]; then
  login_defs_umask=$(grep -E "^\s*UMASK\s+" /etc/login.defs 2>/dev/null | awk '{print $2}' | tail -1 || echo "")

  if [[ -n "$login_defs_umask" ]]; then
    umask_found=true
    if check_umask_value "$login_defs_umask" "/etc/login.defs"; then
      ((restrictive++)) || true
    else
      ((permissive++)) || true
    fi
  else
    register_check "UMASK in login.defs" WARN "Not set (add UMASK 027)"
  fi

  # Also check USERGROUPS_ENAB
  usergroups=$(grep -E "^\s*USERGROUPS_ENAB\s+" /etc/login.defs 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$usergroups" == "yes" ]]; then
    register_check "USERGROUPS_ENAB" PASS "yes (users get private groups)"
  elif [[ -n "$usergroups" ]]; then
    register_check "USERGROUPS_ENAB" WARN "$usergroups"
  fi
else
  register_check "/etc/login.defs" SKIP "File not found"
fi

# ============================================================
# Check /etc/profile
# ============================================================
section "Shell Profile Configuration"

if [[ -f /etc/profile ]]; then
  profile_umask=$(grep -E "^\s*umask\s+" /etc/profile 2>/dev/null | awk '{print $2}' | tail -1 || echo "")

  if [[ -n "$profile_umask" ]]; then
    umask_found=true
    if check_umask_value "$profile_umask" "/etc/profile"; then
      ((restrictive++)) || true
    else
      ((permissive++)) || true
    fi
  else
    register_check "umask in /etc/profile" SKIP "Not explicitly set"
  fi
fi

# ============================================================
# Check /etc/bashrc or /etc/bash.bashrc
# ============================================================
bashrc_files=("/etc/bashrc" "/etc/bash.bashrc")
for bashrc in "${bashrc_files[@]}"; do
  if [[ -f "$bashrc" ]]; then
    bashrc_umask=$(grep -E "^\s*umask\s+" "$bashrc" 2>/dev/null | awk '{print $2}' | tail -1 || echo "")

    if [[ -n "$bashrc_umask" ]]; then
      umask_found=true
      if check_umask_value "$bashrc_umask" "$bashrc"; then
        ((restrictive++)) || true
      else
        ((permissive++)) || true
      fi
    fi
    break
  fi
done

# ============================================================
# Check /etc/profile.d/*.sh
# ============================================================
section "profile.d Scripts"

if [[ -d /etc/profile.d ]]; then
  profiled_umasks=0
  for script in /etc/profile.d/*.sh; do
    [[ -f "$script" ]] || continue
    script_umask=$(grep -E "^\s*umask\s+" "$script" 2>/dev/null | awk '{print $2}' | tail -1 || echo "")

    if [[ -n "$script_umask" ]]; then
      umask_found=true
      ((profiled_umasks++)) || true
      if check_umask_value "$script_umask" "$(basename "$script")"; then
        ((restrictive++)) || true
      else
        ((permissive++)) || true
      fi
    fi
  done

  if [[ $profiled_umasks -eq 0 ]]; then
    register_check "umask in profile.d" SKIP "No umask settings found"
  fi
fi

# ============================================================
# Check PAM umask (pam_umask.so)
# ============================================================
section "PAM Umask Configuration"

pam_umask_found=false
for pam_file in /etc/pam.d/common-session /etc/pam.d/system-auth /etc/pam.d/login; do
  if [[ -f "$pam_file" ]]; then
    if grep -q "pam_umask.so" "$pam_file" 2>/dev/null; then
      pam_umask_found=true
      pam_umask=$(grep "pam_umask.so" "$pam_file" 2>/dev/null | grep -oE "umask=[0-9]+" | cut -d= -f2 || echo "")

      if [[ -n "$pam_umask" ]]; then
        umask_found=true
        if check_umask_value "$pam_umask" "PAM ($pam_file)"; then
          ((restrictive++)) || true
        else
          ((permissive++)) || true
        fi
      else
        # pam_umask.so without explicit umask uses system default
        register_check "PAM umask ($pam_file)" PASS "pam_umask.so enabled"
      fi
      break
    fi
  fi
done

if ! $pam_umask_found; then
  register_check "PAM umask (pam_umask.so)" WARN "Not configured in PAM"
fi

# ============================================================
# Check current shell umask
# ============================================================
section "Current Session Umask"

current_umask=$(umask)
if [[ "$current_umask" == "0027" || "$current_umask" == "027" || \
      "$current_umask" == "0077" || "$current_umask" == "077" || \
      "$current_umask" == "0022" || "$current_umask" == "022" ]]; then
  if [[ "$current_umask" == "0022" || "$current_umask" == "022" ]]; then
    register_check "Current session umask" WARN "$current_umask (default, consider 027)"
  else
    register_check "Current session umask" PASS "$current_umask"
  fi
else
  register_check "Current session umask" WARN "$current_umask"
fi

# ============================================================
# Check root's umask
# ============================================================
if [[ $EUID -eq 0 ]]; then
  root_umask=$(umask)
  if [[ "${root_umask: -2}" == "77" || "${root_umask: -2}" == "27" ]]; then
    register_check "Root umask" PASS "$root_umask"
  else
    register_check "Root umask" WARN "$root_umask (consider 077 for root)"
  fi
fi

# ============================================================
# Summary
# ============================================================
section "Umask Configuration Summary"

if ! $umask_found; then
  register_check "System umask configuration" FAIL "No umask configured"
  echo "  Recommendation: Add 'UMASK 027' to /etc/login.defs"
  echo "  Or add 'umask 027' to /etc/profile"
elif [[ $permissive -gt 0 ]]; then
  register_check "Umask security" WARN "$permissive permissive settings found"
  echo "  Recommendation: Change umask to 027 or 077"
  echo "  Locations to update:"
  echo "    - /etc/login.defs: UMASK 027"
  echo "    - /etc/profile: umask 027"
  echo "    - /etc/bashrc: umask 027"
else
  register_check "Umask security" PASS "All umask settings are restrictive"
fi

echo ""
echo "  Umask values explained:"
echo "    027 - owner: full, group: read/execute, others: none"
echo "    077 - owner: full, group: none, others: none"
echo "    022 - owner: full, group: read/execute, others: read/execute (default, permissive)"

print_summary
exit "$EXIT_CODE"
