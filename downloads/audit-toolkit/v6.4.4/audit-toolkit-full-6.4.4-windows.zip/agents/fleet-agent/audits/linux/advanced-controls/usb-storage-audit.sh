#!/usr/bin/env bash
# usb-storage-audit.sh — USB Storage Kernel Module Audit
#
# @elevation: partial
# @elevation-reason: lsmod readable without root, modprobe blacklist checks may need root
#

set -euo pipefail
. "$(dirname "$0")/../../../lib/common.sh"
. "$(dirname "$0")/../../../lib/distro.sh"
section "USB Storage Kernel Module"

lsmod | grep -q usb_storage && register_check "Disable usb-storage" FAIL "usb-storage module loaded" || register_check "Disable usb-storage" PASS "usb-storage module not loaded"

print_summary
exit "$EXIT_CODE"
