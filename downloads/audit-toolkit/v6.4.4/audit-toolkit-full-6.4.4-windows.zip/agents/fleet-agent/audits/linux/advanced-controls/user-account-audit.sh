#!/usr/bin/env bash
# user-account-audit.sh — User Account Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.2.x (User and Group Settings)
# - NIST SP 800-53: AC-2, IA-2, IA-4 (Account Management)
# - ISO 27001: A.9.2.1, A.9.2.5 (User Registration, Asset Owner)
# - PCI DSS: 8.1.1, 8.1.4 (User ID Management)
# - DISA STIG: V-204462 (Account Security)
#
# Checks:
# - Empty passwords
# - Duplicate UIDs/GIDs
# - UID 0 accounts
# - Orphaned files
# - Home directory permissions
# - Inactive accounts
#
# @elevation: partial
# @elevation-reason: /etc/passwd readable without root, /etc/shadow checks need root
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

# Files
readonly PASSWD="/etc/passwd"
readonly SHADOW="/etc/shadow"
readonly GROUP="/etc/group"

section "User Account Security Audit"

# Verify we can read necessary files
if [[ ! -r "$PASSWD" ]]; then
  register_check "Passwd file" FAIL "cannot read $PASSWD"
  print_summary
  exit "$EXIT_CODE"
fi

section "Empty Passwords (CIS 6.2.1)"

# Check for users with empty password field in shadow
if [[ -r "$SHADOW" ]] || [[ "$EUID" -eq 0 ]]; then
  empty_pw_users=$(sudo awk -F: '($2 == "" || $2 == "!!" || $2 == "!") {print $1}' "$SHADOW" 2>/dev/null | grep -vE '^(nobody|nfsnobody)$' || echo "")

  # Filter to only interactive/login users with empty passwords (not locked)
  truly_empty=$(sudo awk -F: '($2 == "") {print $1}' "$SHADOW" 2>/dev/null || echo "")

  if [[ -n "$truly_empty" ]]; then
    count=$(echo "$truly_empty" | wc -w)
    register_check "Empty passwords" FAIL "$count accounts: $truly_empty"
  else
    register_check "Empty passwords" PASS "none found"
  fi
else
  # Non-root check - look for users without 'x' in passwd (local shadow not used)
  local_empty=$(awk -F: '($2 == "") {print $1}' "$PASSWD" 2>/dev/null || echo "")
  if [[ -n "$local_empty" ]]; then
    register_check "Empty passwords (passwd)" FAIL "found: $local_empty"
  else
    register_check "Empty passwords" SKIP "requires root to check shadow"
  fi
fi

section "UID 0 Accounts (CIS 6.2.9)"

# Only root should have UID 0
uid0_users=$(awk -F: '($3 == 0) {print $1}' "$PASSWD")
uid0_count=$(echo "$uid0_users" | wc -w)

if [[ "$uid0_count" -eq 1 ]] && [[ "$uid0_users" == "root" ]]; then
  register_check "UID 0 accounts" PASS "only root has UID 0"
elif [[ "$uid0_count" -gt 1 ]]; then
  non_root=$(echo "$uid0_users" | grep -v "^root$" || echo "")
  register_check "UID 0 accounts" FAIL "additional UID 0: $non_root"
else
  register_check "UID 0 accounts" WARN "unusual state - check manually"
fi

section "Duplicate UIDs (CIS 6.2.15)"

# Find duplicate UIDs
dup_uids=$(awk -F: '{print $3}' "$PASSWD" | sort | uniq -d)
if [[ -n "$dup_uids" ]]; then
  dup_count=$(echo "$dup_uids" | wc -w)
  # Get usernames for duplicate UIDs
  dup_users=""
  for uid in $dup_uids; do
    users=$(awk -F: -v uid="$uid" '$3 == uid {print $1}' "$PASSWD" | tr '\n' ',' | sed 's/,$//')
    dup_users+="UID $uid: $users; "
  done
  register_check "Duplicate UIDs" FAIL "$dup_count duplicates: ${dup_users%%; }"
else
  register_check "Duplicate UIDs" PASS "none found"
fi

section "Duplicate GIDs (CIS 6.2.16)"

# Find duplicate GIDs
dup_gids=$(awk -F: '{print $3}' "$GROUP" | sort | uniq -d)
if [[ -n "$dup_gids" ]]; then
  dup_count=$(echo "$dup_gids" | wc -w)
  register_check "Duplicate GIDs" FAIL "$dup_count duplicates"
else
  register_check "Duplicate GIDs" PASS "none found"
fi

section "Duplicate Usernames (CIS 6.2.17)"

# Find duplicate usernames
dup_names=$(awk -F: '{print $1}' "$PASSWD" | sort | uniq -d)
if [[ -n "$dup_names" ]]; then
  register_check "Duplicate usernames" FAIL "found: $dup_names"
else
  register_check "Duplicate usernames" PASS "none found"
fi

section "Duplicate Group Names (CIS 6.2.18)"

# Find duplicate group names
dup_groups=$(awk -F: '{print $1}' "$GROUP" | sort | uniq -d)
if [[ -n "$dup_groups" ]]; then
  register_check "Duplicate group names" FAIL "found: $dup_groups"
else
  register_check "Duplicate group names" PASS "none found"
fi

section "Root Account Configuration"

# Check root account has password set
if [[ -r "$SHADOW" ]] || [[ "$EUID" -eq 0 ]]; then
  root_pw=$(sudo grep "^root:" "$SHADOW" 2>/dev/null | cut -d: -f2)
  if [[ -n "$root_pw" ]] && [[ "$root_pw" != "!" ]] && [[ "$root_pw" != "!!" ]] && [[ "$root_pw" != "*" ]]; then
    register_check "Root password set" PASS
  elif [[ "$root_pw" == "!" ]] || [[ "$root_pw" == "!!" ]]; then
    register_check "Root account locked" WARN "root is locked (may be intentional)"
  else
    register_check "Root password" FAIL "not properly set"
  fi
fi

# Check root primary group
root_gid=$(awk -F: '/^root:/ {print $4}' "$PASSWD")
if [[ "$root_gid" == "0" ]]; then
  register_check "Root primary group" PASS "GID 0"
else
  register_check "Root primary group" WARN "GID $root_gid (expected 0)"
fi

# Check root shell
root_shell=$(awk -F: '/^root:/ {print $7}' "$PASSWD")
if [[ -x "$root_shell" ]]; then
  register_check "Root shell" PASS "$root_shell"
else
  register_check "Root shell" WARN "$root_shell (not executable)"
fi

section "Home Directory Security (CIS 6.2.6-6.2.8)"

# Count issues instead of listing each one
home_missing=0
home_bad_perms=0
home_bad_owner=0
checked_homes=0

while IFS=: read -r username _ uid gid _ home shell; do
  # Skip system accounts and nologin shells
  [[ "$uid" -lt 1000 ]] && [[ "$username" != "root" ]] && continue
  [[ "$shell" == */nologin ]] && continue
  [[ "$shell" == */false ]] && continue
  [[ -z "$home" ]] && continue
  [[ "$home" == "/" ]] && continue

  ((checked_homes++)) || true

  # Check home exists
  if [[ ! -d "$home" ]]; then
    ((home_missing++)) || true
    continue
  fi

  # Check ownership
  owner=$(stat -c "%U" "$home" 2>/dev/null || echo "unknown")
  if [[ "$owner" != "$username" ]] && [[ "$owner" != "root" ]]; then
    ((home_bad_owner++)) || true
  fi

  # Check permissions (should not be world-writable or world-readable)
  perms=$(stat -c "%a" "$home" 2>/dev/null || echo "777")
  world_bits=${perms: -1}
  if [[ "$world_bits" -gt "0" ]]; then
    ((home_bad_perms++)) || true
  fi

done < "$PASSWD"

if [[ "$home_missing" -gt 0 ]]; then
  register_check "Home directories exist" WARN "$home_missing missing"
else
  register_check "Home directories exist" PASS "all $checked_homes present"
fi

if [[ "$home_bad_owner" -gt 0 ]]; then
  register_check "Home directory ownership" WARN "$home_bad_owner incorrect"
else
  register_check "Home directory ownership" PASS "all correct"
fi

if [[ "$home_bad_perms" -gt 0 ]]; then
  register_check "Home directory permissions" WARN "$home_bad_perms world-accessible"
else
  register_check "Home directory permissions" PASS "none world-accessible"
fi

section "User Dot Files (CIS 6.2.10-6.2.14)"

# Check for insecure dot files in user homes
dotfile_issues=0

while IFS=: read -r username _ uid _ _ home shell; do
  [[ "$uid" -lt 1000 ]] && [[ "$username" != "root" ]] && continue
  [[ ! -d "$home" ]] && continue
  [[ "$shell" == */nologin ]] && continue

  # Check .netrc
  if [[ -f "$home/.netrc" ]]; then
    netrc_perms=$(stat -c "%a" "$home/.netrc" 2>/dev/null || echo "644")
    if [[ "$netrc_perms" != "600" ]] && [[ "$netrc_perms" != "400" ]]; then
      ((dotfile_issues++)) || true
    fi
  fi

  # Check .rhosts
  if [[ -f "$home/.rhosts" ]]; then
    ((dotfile_issues++)) || true
  fi

  # Check .forward
  if [[ -f "$home/.forward" ]]; then
    forward_perms=$(stat -c "%a" "$home/.forward" 2>/dev/null || echo "644")
    # world-writable is bad
    if [[ "${forward_perms: -1}" -ge 2 ]]; then
      ((dotfile_issues++)) || true
    fi
  fi

done < "$PASSWD"

if [[ "$dotfile_issues" -gt 0 ]]; then
  register_check "User dot files" WARN "$dotfile_issues insecure files"
else
  register_check "User dot files" PASS "no issues"
fi

# Check for .rhosts and hosts.equiv at system level
if [[ -f "/etc/hosts.equiv" ]]; then
  register_check "hosts.equiv" WARN "/etc/hosts.equiv exists (rsh trust)"
else
  register_check "hosts.equiv" PASS "not present"
fi

section "Inactive Accounts"

# Check for users who haven't logged in recently (90+ days)
if command -v lastlog >/dev/null 2>&1; then
  inactive_count=$(lastlog -b 90 2>/dev/null | tail -n +2 | grep -v "Never logged in" | wc -l || echo "0")
  never_logged=$(lastlog 2>/dev/null | grep "Never logged in" | wc -l || echo "0")

  if [[ "$inactive_count" -gt 0 ]]; then
    register_check "Inactive accounts (90d)" WARN "$inactive_count accounts"
  else
    register_check "Inactive accounts (90d)" PASS "none"
  fi

  if [[ "$never_logged" -gt 5 ]]; then
    register_check "Never logged in accounts" WARN "$never_logged accounts"
  else
    register_check "Never logged in accounts" PASS "$never_logged accounts"
  fi
else
  register_check "Inactive accounts" SKIP "lastlog not available"
fi

section "System Account Shells"

# System accounts should have nologin or false shell
bad_system_shells=0
while IFS=: read -r username _ uid _ _ _ shell; do
  [[ "$uid" -ge 1000 ]] && continue
  [[ "$username" == "root" ]] && continue
  [[ "$username" == "sync" ]] && continue  # sync traditionally has /bin/sync

  # Check for login shell
  if [[ "$shell" != */nologin ]] && [[ "$shell" != */false ]] && [[ -n "$shell" ]]; then
    if [[ -x "$shell" ]]; then
      ((bad_system_shells++)) || true
    fi
  fi
done < "$PASSWD"

if [[ "$bad_system_shells" -gt 0 ]]; then
  register_check "System account shells" WARN "$bad_system_shells have login shells"
else
  register_check "System account shells" PASS "all use nologin/false"
fi

section "Path Security (CIS 6.2.2-6.2.4)"

# Check root PATH for dangerous entries
if [[ "$EUID" -eq 0 ]]; then
  root_path="$PATH"
else
  root_path=$(sudo sh -c 'echo $PATH' 2>/dev/null || echo "$PATH")
fi

# Check for . (current directory) in PATH
if echo "$root_path" | grep -qE '(^:|::|:$|\.:)'; then
  register_check "PATH includes current dir" FAIL "dangerous: . in PATH"
else
  register_check "PATH includes current dir" PASS "not present"
fi

# Check for world-writable directories in PATH
path_issues=0
IFS=':' read -ra path_dirs <<< "$root_path"
for dir in "${path_dirs[@]}"; do
  [[ -z "$dir" ]] && continue
  [[ ! -d "$dir" ]] && continue

  perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "755")
  if [[ "${perms: -1}" -ge 2 ]]; then
    ((path_issues++)) || true
  fi
done

if [[ "$path_issues" -gt 0 ]]; then
  register_check "PATH world-writable dirs" WARN "$path_issues directories"
else
  register_check "PATH world-writable dirs" PASS "none"
fi

section "Shadow Group Membership"

# Check who's in the shadow group (should be minimal)
shadow_group=$(getent group shadow 2>/dev/null || grep "^shadow:" "$GROUP" 2>/dev/null || echo "")
if [[ -n "$shadow_group" ]]; then
  shadow_members=$(echo "$shadow_group" | cut -d: -f4)
  if [[ -n "$shadow_members" ]]; then
    register_check "Shadow group members" WARN "members: $shadow_members"
  else
    register_check "Shadow group members" PASS "no extra members"
  fi
fi

print_summary
exit "$EXIT_CODE"
