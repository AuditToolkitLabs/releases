# Alpine Linux Security Audits

This directory contains security audits specifically designed for **Alpine Linux** systems.

## Why Alpine-Specific Audits?

Alpine Linux differs significantly from other Linux distributions:

| Feature | Alpine | Other Distros (Ubuntu, RHEL, etc.) |
|---------|--------|-----------------------------------|
| Init System | **OpenRC** | systemd |
| Package Manager | **apk** | apt, dnf, yum |
| C Library | **musl** | glibc |
| Shell | **ash/busybox** | bash |
| Service Paths | `/etc/init.d/`, `/etc/runlevels/` | `/etc/systemd/`, `/lib/systemd/` |
| Default User | Often runs as **root** in containers | Non-root recommended |

## Audits Included

| Script | Description |
|--------|-------------|
| `openrc-services-audit.sh` | Audit OpenRC service configuration and security |
| `apk-package-audit.sh` | Check for outdated packages and security updates |
| `busybox-audit.sh` | Verify busybox configuration and applet security |
| `alpine-hardening-audit.sh` | Alpine-specific kernel and system hardening |
| `musl-security-audit.sh` | musl libc security considerations |
| `container-security-audit.sh` | Security checks for Alpine in Docker/K8s |

## Usage

Run individual audits:
```bash
bash audits/linux/alpine/openrc-services-audit.sh
```

Run all Alpine audits via orchestrator:
```bash
./orchestrator/orchestrator.sh --domain alpine
```

## Compatibility

These audits are designed for:
- Alpine Linux 3.15+
- Alpine-based container images
- Edge/testing branches

The main `lib/` shims handle Alpine detection automatically, but these audits provide deeper Alpine-specific checks.

## References

- [Alpine Security Wiki](https://wiki.alpinelinux.org/wiki/Category:Security)
- [Alpine Hardening Guide](https://wiki.alpinelinux.org/wiki/Securing_Alpine)
- [OpenRC Documentation](https://wiki.gentoo.org/wiki/OpenRC)
- [CIS Alpine Benchmark](https://www.cisecurity.org/) (when available)
