#!/usr/bin/env bash
# Alpine Linux System Hardening Audit
# Checks Alpine-specific security hardening configurations
#
# @elevation: partial
# @elevation-reason: Kernel sysctl and security config checks need root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine System Hardening Audit"

# Verify we're on Alpine
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# ============================================================================
# Kernel Hardening
# ============================================================================
section "Kernel Hardening"

# Check sysctl security settings
declare -A sysctl_checks=(
    ["kernel.kptr_restrict"]="1:Kernel pointer restrictions"
    ["kernel.dmesg_restrict"]="1:Restrict dmesg access"
    ["kernel.randomize_va_space"]="2:ASLR enabled"
    ["net.ipv4.conf.all.rp_filter"]="1:Reverse path filtering"
    ["net.ipv4.conf.default.rp_filter"]="1:Default reverse path filtering"
    ["net.ipv4.icmp_echo_ignore_broadcasts"]="1:Ignore ICMP broadcast"
    ["net.ipv4.conf.all.accept_redirects"]="0:Reject ICMP redirects"
    ["net.ipv4.conf.default.accept_redirects"]="0:Default reject redirects"
    ["net.ipv4.conf.all.secure_redirects"]="0:Reject secure redirects"
    ["net.ipv4.conf.all.send_redirects"]="0:Don't send redirects"
    ["net.ipv4.conf.default.send_redirects"]="0:Default don't send redirects"
    ["net.ipv4.tcp_syncookies"]="1:SYN cookies enabled"
    ["net.ipv4.ip_forward"]="0:IP forwarding disabled"
    ["net.ipv6.conf.all.accept_redirects"]="0:IPv6 reject redirects"
    ["net.ipv6.conf.default.accept_redirects"]="0:IPv6 default reject redirects"
)

for key in "${!sysctl_checks[@]}"; do
    expected="${sysctl_checks[$key]%%:*}"
    desc="${sysctl_checks[$key]##*:}"

    current=$(sysctl -n "$key" 2>/dev/null || echo "N/A")

    if [[ "$current" == "N/A" ]]; then
        register_check "sysctl: $desc" INFO "Setting not available (may be containerized)"
    elif [[ "$current" == "$expected" ]]; then
        register_check "sysctl: $desc" PASS "$key = $current"
    else
        register_check "sysctl: $desc" WARN "$key = $current (recommended: $expected)"
    fi
done

# Check for sysctl.conf persistence
if [[ -f /etc/sysctl.conf ]] || [[ -d /etc/sysctl.d ]]; then
    register_check "sysctl.conf Exists" PASS "Sysctl configuration found"
else
    register_check "sysctl.conf Exists" INFO "No persistent sysctl configuration"
fi

# ============================================================================
# File System Security
# ============================================================================
section "File System Security"

# Check /tmp mount options
if mount | grep -q ' /tmp '; then
    tmp_opts=$(mount | grep ' /tmp ' | head -1)
    if echo "$tmp_opts" | grep -q 'noexec'; then
        register_check "/tmp noexec" PASS "/tmp mounted with noexec"
    else
        register_check "/tmp noexec" WARN "/tmp not mounted with noexec"
    fi

    if echo "$tmp_opts" | grep -q 'nosuid'; then
        register_check "/tmp nosuid" PASS "/tmp mounted with nosuid"
    else
        register_check "/tmp nosuid" WARN "/tmp not mounted with nosuid"
    fi
else
    register_check "/tmp Mount" INFO "/tmp not a separate mount"
fi

# Check /var/tmp
if mount | grep -q ' /var/tmp '; then
    register_check "/var/tmp Mount" INFO "/var/tmp is a separate mount"
else
    register_check "/var/tmp Mount" INFO "/var/tmp is not a separate mount"
fi

# Check for sticky bit on world-writable directories
world_writable=$(find / -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null | head -10 | wc -l)
if [[ $world_writable -eq 0 ]]; then
    register_check "Sticky Bit" PASS "All world-writable dirs have sticky bit"
else
    register_check "Sticky Bit" WARN "$world_writable world-writable directories lack sticky bit"
fi

# ============================================================================
# User Security
# ============================================================================
section "User & Authentication Security"

# Check root account
root_shell=$(grep '^root:' /etc/passwd 2>/dev/null | cut -d: -f7)
if [[ "$root_shell" == "/sbin/nologin" ]] || [[ "$root_shell" == "/bin/false" ]]; then
    register_check "Root Shell" WARN "Root login disabled (shell: $root_shell)"
else
    register_check "Root Shell" INFO "Root shell: $root_shell"
fi

# Check for accounts with empty passwords
empty_pass=$(awk -F: '($2 == "" || $2 == "!") && $1 != "root" {print $1}' /etc/shadow 2>/dev/null | wc -l)
if [[ $empty_pass -eq 0 ]]; then
    register_check "Empty Passwords" PASS "No accounts with empty passwords"
else
    register_check "Empty Passwords" FAIL "$empty_pass accounts have empty passwords"
fi

# Check for UID 0 accounts other than root
uid_zero=$(awk -F: '$3 == 0 && $1 != "root" {print $1}' /etc/passwd 2>/dev/null)
if [[ -z "$uid_zero" ]]; then
    register_check "UID 0 Accounts" PASS "Only root has UID 0"
else
    register_check "UID 0 Accounts" FAIL "Non-root accounts with UID 0: $uid_zero"
fi

# Check /etc/passwd permissions
passwd_perms=$(stat -c '%a' /etc/passwd 2>/dev/null || echo "unknown")
if [[ "$passwd_perms" == "644" ]]; then
    register_check "/etc/passwd Perms" PASS "Correct permissions (644)"
else
    register_check "/etc/passwd Perms" WARN "Permissions are $passwd_perms (expected 644)"
fi

# Check /etc/shadow permissions
shadow_perms=$(stat -c '%a' /etc/shadow 2>/dev/null || echo "unknown")
if [[ "$shadow_perms" == "640" ]] || [[ "$shadow_perms" == "600" ]] || [[ "$shadow_perms" == "000" ]]; then
    register_check "/etc/shadow Perms" PASS "Correct permissions ($shadow_perms)"
else
    register_check "/etc/shadow Perms" FAIL "Permissions are $shadow_perms (expected 640 or stricter)"
fi

# ============================================================================
# Service Hardening
# ============================================================================
section "Service Hardening"

# Check for unnecessary services
unnecessary_services=(
    "telnet"
    "ftp"
    "rsh"
    "rlogin"
    "xinetd"
    "inetd"
)

for svc in "${unnecessary_services[@]}"; do
    if rc-service "$svc" status >/dev/null 2>&1; then
        register_check "Service: $svc" FAIL "$svc is running - insecure service"
    elif [[ -f /etc/init.d/$svc ]]; then
        register_check "Service: $svc" WARN "$svc is installed but not running"
    fi
done

# ============================================================================
# Network Hardening
# ============================================================================
section "Network Hardening"

# Check for listening services
listening_ports=$(ss -tlnp 2>/dev/null | grep LISTEN | wc -l || netstat -tlnp 2>/dev/null | grep LISTEN | wc -l || echo "0")
register_check "Listening Ports" INFO "$listening_ports TCP ports listening"

# Check if IPv6 is disabled (if not needed)
if [[ -f /proc/sys/net/ipv6/conf/all/disable_ipv6 ]]; then
    ipv6_disabled=$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6)
    if [[ "$ipv6_disabled" == "1" ]]; then
        register_check "IPv6 Disabled" INFO "IPv6 is disabled"
    else
        register_check "IPv6 Enabled" INFO "IPv6 is enabled - ensure firewall covers IPv6"
    fi
fi

# Check hosts.allow and hosts.deny
if [[ -f /etc/hosts.allow ]]; then
    if [[ -s /etc/hosts.allow ]]; then
        register_check "hosts.allow" INFO "TCP wrappers hosts.allow configured"
    fi
fi

if [[ -f /etc/hosts.deny ]]; then
    if grep -q 'ALL: ALL' /etc/hosts.deny 2>/dev/null; then
        register_check "hosts.deny" PASS "Default deny rule in hosts.deny"
    else
        register_check "hosts.deny" INFO "hosts.deny exists but no default deny"
    fi
fi

# ============================================================================
# Alpine-Specific Security Features
# ============================================================================
section "Alpine Security Features"

# Check for grsecurity/PaX (older Alpine versions)
if [[ -d /proc/sys/kernel/grsecurity ]]; then
    register_check "Grsecurity" INFO "Grsecurity kernel detected"
fi

# Check for hardened kernel
kernel_version=$(uname -r)
if [[ "$kernel_version" == *"-hardened"* ]]; then
    register_check "Hardened Kernel" PASS "Using hardened kernel"
else
    register_check "Hardened Kernel" INFO "Standard kernel in use"
fi

# Check for fortify-headers
if apk info -e fortify-headers >/dev/null 2>&1; then
    register_check "Fortify Headers" PASS "fortify-headers package installed"
else
    register_check "Fortify Headers" INFO "fortify-headers not installed"
fi

# Check for secfixes in apk database
if [[ -d /var/lib/apk ]]; then
    register_check "APK Database" PASS "APK security database present"
fi

# ============================================================================
# Boot Security
# ============================================================================
section "Boot Security"

# Check for bootloader password (GRUB/LILO)
if [[ -f /boot/grub/grub.cfg ]]; then
    if grep -q 'password' /boot/grub/grub.cfg 2>/dev/null; then
        register_check "Bootloader Password" PASS "GRUB password configured"
    else
        register_check "Bootloader Password" WARN "No GRUB password set"
    fi
elif [[ -f /etc/lilo.conf ]]; then
    if grep -q 'password' /etc/lilo.conf 2>/dev/null; then
        register_check "Bootloader Password" PASS "LILO password configured"
    else
        register_check "Bootloader Password" WARN "No LILO password set"
    fi
else
    register_check "Bootloader Config" INFO "No GRUB/LILO configuration found"
fi

# Check init directory permissions
if [[ -d /etc/init.d ]]; then
    init_perms=$(stat -c '%a' /etc/init.d 2>/dev/null || echo "unknown")
    if [[ "$init_perms" == "755" ]]; then
        register_check "/etc/init.d Perms" PASS "Correct permissions (755)"
    else
        register_check "/etc/init.d Perms" INFO "Permissions: $init_perms"
    fi
fi

print_summary
exit "$EXIT_CODE"
