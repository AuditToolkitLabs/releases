#!/usr/bin/env bash
# Alpine Linux Package Security Audit (apk)
# Checks for outdated packages, security updates, and package integrity
#
# @elevation: root
# @elevation-reason: apk operations require root privileges
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine apk Package Security Audit"

# Verify we're on Alpine
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# Check if apk is available
if ! command -v apk >/dev/null 2>&1; then
    register_check "apk Available" FAIL "apk package manager not found"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "apk Available" PASS "apk package manager found"

# ============================================================================
# Repository Configuration
# ============================================================================
section "Repository Configuration"

# Check repository configuration
if [[ -f /etc/apk/repositories ]]; then
    register_check "Repositories File" PASS "/etc/apk/repositories exists"

    # Count configured repositories
    repo_count=$(grep -v '^#' /etc/apk/repositories 2>/dev/null | grep -v '^$' | wc -l)
    register_check "Repository Count" INFO "$repo_count repositories configured"

    # Check for HTTPS repositories
    https_repos=$(grep -c '^https://' /etc/apk/repositories 2>/dev/null || echo 0)
    http_repos=$(grep -c '^http://' /etc/apk/repositories 2>/dev/null || echo 0)

    if [[ $http_repos -gt 0 ]] && [[ $https_repos -eq 0 ]]; then
        register_check "Repository Security" WARN "Only HTTP repositories configured - consider using HTTPS"
    elif [[ $https_repos -gt 0 ]]; then
        register_check "Repository Security" PASS "HTTPS repositories configured"
    fi

    # Check for community repo (often needed for security tools)
    if grep -q 'community' /etc/apk/repositories 2>/dev/null; then
        register_check "Community Repo" INFO "Community repository enabled"
    else
        register_check "Community Repo" INFO "Community repository not enabled"
    fi

    # Check for edge repo (unstable)
    if grep -q 'edge' /etc/apk/repositories 2>/dev/null; then
        register_check "Edge Repo" WARN "Edge (unstable) repository enabled - may have untested packages"
    fi
else
    register_check "Repositories File" FAIL "/etc/apk/repositories not found"
fi

# ============================================================================
# Package Updates
# ============================================================================
section "Package Updates"

# Update package index (quietly)
if apk update >/dev/null 2>&1; then
    register_check "Package Index Update" PASS "Successfully updated package index"
else
    register_check "Package Index Update" WARN "Failed to update package index (network issue?)"
fi

# Check for available upgrades
upgradable=$(apk version -l '<' 2>/dev/null | wc -l || echo 0)
if [[ $upgradable -eq 0 ]]; then
    register_check "Pending Updates" PASS "All packages are up to date"
elif [[ $upgradable -lt 10 ]]; then
    register_check "Pending Updates" WARN "$upgradable packages have updates available"
else
    register_check "Pending Updates" FAIL "$upgradable packages need updating - review for security patches"
fi

# List critical packages that may need updates
critical_packages=(
    "openssl"
    "openssh"
    "busybox"
    "musl"
    "linux-lts"
    "sudo"
    "curl"
    "wget"
)

for pkg in "${critical_packages[@]}"; do
    if apk info -e "$pkg" >/dev/null 2>&1; then
        if apk version -l '<' 2>/dev/null | grep -q "^$pkg-"; then
            register_check "Update: $pkg" WARN "$pkg has an update available"
        else
            installed_ver=$(apk info "$pkg" 2>/dev/null | head -1 | awk '{print $1}')
            register_check "Package: $pkg" PASS "$installed_ver is current"
        fi
    fi
done

# ============================================================================
# Package Integrity
# ============================================================================
section "Package Integrity"

# Check for packages with missing files
# Note: This can be slow, so we limit the check
if command -v apk >/dev/null 2>&1; then
    # Verify a sample of critical packages
    verify_packages=("busybox" "musl" "apk-tools")
    for pkg in "${verify_packages[@]}"; do
        if apk info -e "$pkg" >/dev/null 2>&1; then
            if apk verify "$pkg" >/dev/null 2>&1; then
                register_check "Verify: $pkg" PASS "$pkg integrity verified"
            else
                register_check "Verify: $pkg" WARN "$pkg may have modified files"
            fi
        fi
    done
fi

# ============================================================================
# World File (Explicitly Installed Packages)
# ============================================================================
section "Package Management"

# Check world file
if [[ -f /etc/apk/world ]]; then
    world_count=$(wc -l < /etc/apk/world)
    register_check "World File" PASS "$world_count explicitly installed packages"

    # Check for potentially dangerous packages
    dangerous_packages=(
        "telnet"
        "ftp"
        "rsh"
        "rlogin"
        "tftp"
    )

    for pkg in "${dangerous_packages[@]}"; do
        if grep -q "^$pkg$" /etc/apk/world 2>/dev/null; then
            register_check "Insecure Package: $pkg" WARN "$pkg is explicitly installed - insecure protocol"
        fi
    done
else
    register_check "World File" WARN "/etc/apk/world not found"
fi

# ============================================================================
# Security-Related Packages
# ============================================================================
section "Security Packages"

# Check for security-related packages
security_packages=(
    "openssh-server:SSH Server"
    "openssl:SSL/TLS Library"
    "ca-certificates:Certificate Authorities"
    "sudo:Privilege Escalation"
)

for entry in "${security_packages[@]}"; do
    pkg="${entry%%:*}"
    desc="${entry##*:}"
    if apk info -e "$pkg" >/dev/null 2>&1; then
        register_check "$desc" PASS "$pkg is installed"
    else
        register_check "$desc" INFO "$pkg not installed"
    fi
done

# Check for audit/security tools
audit_tools=(
    "lynis"
    "rkhunter"
    "aide"
    "tripwire"
)

for tool in "${audit_tools[@]}"; do
    if apk info -e "$tool" >/dev/null 2>&1; then
        register_check "Security Tool: $tool" PASS "$tool is installed"
    fi
done

# ============================================================================
# Package Cache
# ============================================================================
section "Package Cache"

# Check cache directory size
if [[ -d /var/cache/apk ]]; then
    cache_size=$(du -sh /var/cache/apk 2>/dev/null | cut -f1)
    register_check "Package Cache" INFO "Cache size: $cache_size"

    # Check for very large cache
    cache_bytes=$(du -sb /var/cache/apk 2>/dev/null | cut -f1 || echo 0)
    if [[ $cache_bytes -gt 104857600 ]]; then  # > 100MB
        register_check "Cache Size" WARN "Package cache is large (${cache_size}) - consider 'apk cache clean'"
    fi
fi

# ============================================================================
# apk Keys
# ============================================================================
section "Package Signing Keys"

# Check for apk signing keys
if [[ -d /etc/apk/keys ]]; then
    key_count=$(find /etc/apk/keys -name '*.pub' 2>/dev/null | wc -l)
    if [[ $key_count -gt 0 ]]; then
        register_check "Signing Keys" PASS "$key_count signing keys configured"
    else
        register_check "Signing Keys" WARN "No signing keys found in /etc/apk/keys"
    fi
else
    register_check "Signing Keys" FAIL "/etc/apk/keys directory not found"
fi

print_summary
exit "$EXIT_CODE"
