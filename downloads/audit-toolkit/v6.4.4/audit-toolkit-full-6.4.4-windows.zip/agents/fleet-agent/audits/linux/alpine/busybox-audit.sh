#!/usr/bin/env bash
# Alpine Linux BusyBox Security Audit
# Checks BusyBox configuration, enabled applets, and security settings
#
# @elevation: partial
# @elevation-reason: BusyBox config and binary checks readable without root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine BusyBox Security Audit"

# Verify we're on Alpine
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# Check if BusyBox is available
if ! command -v busybox >/dev/null 2>&1; then
    register_check "BusyBox Available" FAIL "BusyBox not found"
    print_summary
    exit "$EXIT_CODE"
fi

# Get BusyBox version
bb_version=$(busybox --help 2>&1 | head -1 | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
register_check "BusyBox Version" PASS "BusyBox $bb_version installed"

# ============================================================================
# BusyBox Binary Security
# ============================================================================
section "BusyBox Binary Security"

# Check BusyBox binary location and permissions
bb_path=$(command -v busybox)
if [[ -f "$bb_path" ]]; then
    bb_perms=$(stat -c '%a' "$bb_path" 2>/dev/null || stat -f '%Lp' "$bb_path" 2>/dev/null)
    bb_owner=$(stat -c '%U:%G' "$bb_path" 2>/dev/null || stat -f '%Su:%Sg' "$bb_path" 2>/dev/null)

    if [[ "$bb_owner" == "root:root" ]]; then
        register_check "BusyBox Ownership" PASS "Owned by root:root"
    else
        register_check "BusyBox Ownership" WARN "Owned by $bb_owner (expected root:root)"
    fi

    # Check for SUID bit
    if [[ $((bb_perms & 4000)) -ne 0 ]]; then
        register_check "BusyBox SUID" WARN "BusyBox has SUID bit set - review security implications"
    else
        register_check "BusyBox SUID" PASS "No SUID bit set"
    fi

    # Check for SGID bit
    if [[ $((bb_perms & 2000)) -ne 0 ]]; then
        register_check "BusyBox SGID" WARN "BusyBox has SGID bit set"
    else
        register_check "BusyBox SGID" PASS "No SGID bit set"
    fi
fi

# ============================================================================
# Enabled Applets Analysis
# ============================================================================
section "BusyBox Applets"

# Get list of enabled applets
applet_count=$(busybox --list 2>/dev/null | wc -l)
register_check "Applet Count" INFO "$applet_count applets enabled"

# Check for potentially dangerous applets
dangerous_applets=(
    "telnetd:Telnet daemon - unencrypted remote access"
    "ftpd:FTP daemon - unencrypted file transfer"
    "tftpd:TFTP daemon - trivial file transfer protocol"
    "httpd:HTTP daemon - web server"
    "nc:Netcat - network utility (can be misused)"
    "rsh:Remote shell - insecure"
    "rlogin:Remote login - insecure"
)

for entry in "${dangerous_applets[@]}"; do
    applet="${entry%%:*}"
    desc="${entry##*:}"
    if busybox --list 2>/dev/null | grep -q "^${applet}$"; then
        register_check "Applet: $applet" WARN "Enabled - $desc"
    fi
done

# Check for security-related applets
security_applets=(
    "su:Switch user"
    "passwd:Change passwords"
    "adduser:Add users"
    "addgroup:Add groups"
    "deluser:Delete users"
    "delgroup:Delete groups"
    "login:User login"
    "getty:Terminal login"
)

for entry in "${security_applets[@]}"; do
    applet="${entry%%:*}"
    desc="${entry##*:}"
    if busybox --list 2>/dev/null | grep -q "^${applet}$"; then
        register_check "Security Applet: $applet" INFO "Enabled - $desc"
    fi
done

# ============================================================================
# BusyBox Symlinks Audit
# ============================================================================
section "BusyBox Symlinks"

# Count symlinks pointing to BusyBox
symlink_count=0
broken_symlinks=0

# Check common directories for BusyBox symlinks
for dir in /bin /sbin /usr/bin /usr/sbin; do
    if [[ -d "$dir" ]]; then
        while IFS= read -r link; do
            if [[ -L "$link" ]]; then
                target=$(readlink -f "$link" 2>/dev/null || true)
                if [[ "$target" == *"busybox"* ]]; then
                    ((symlink_count++))
                fi
            fi
        done < <(find "$dir" -maxdepth 1 -type l 2>/dev/null | head -200)
    fi
done

register_check "BusyBox Symlinks" INFO "$symlink_count symlinks point to BusyBox"

# Check for broken symlinks in key directories
for dir in /bin /sbin; do
    if [[ -d "$dir" ]]; then
        broken=$(find "$dir" -maxdepth 1 -type l ! -exec test -e {} \; -print 2>/dev/null | wc -l)
        if [[ $broken -gt 0 ]]; then
            ((broken_symlinks += broken))
        fi
    fi
done

if [[ $broken_symlinks -gt 0 ]]; then
    register_check "Broken Symlinks" WARN "$broken_symlinks broken symlinks found"
else
    register_check "Broken Symlinks" PASS "No broken symlinks in /bin /sbin"
fi

# ============================================================================
# Shell Configuration
# ============================================================================
section "Shell Configuration"

# Check default shell
default_shell=$(grep '^root:' /etc/passwd 2>/dev/null | cut -d: -f7)
if [[ "$default_shell" == *"ash"* ]] || [[ "$default_shell" == *"sh"* ]]; then
    register_check "Root Shell" INFO "Root uses $default_shell (BusyBox ash)"
elif [[ "$default_shell" == *"bash"* ]]; then
    register_check "Root Shell" INFO "Root uses bash (not BusyBox ash)"
fi

# Check /etc/shells
if [[ -f /etc/shells ]]; then
    shell_count=$(grep -v '^#' /etc/shells 2>/dev/null | grep -v '^$' | wc -l)
    register_check "Allowed Shells" INFO "$shell_count shells in /etc/shells"

    # Check for insecure shells
    if grep -qE '/bin/(csh|tcsh)' /etc/shells 2>/dev/null; then
        register_check "Legacy Shells" INFO "C shell variants found in /etc/shells"
    fi
fi

# ============================================================================
# BusyBox syslogd
# ============================================================================
section "BusyBox Syslogd"

# Check if BusyBox syslogd is in use
if pgrep -x syslogd >/dev/null 2>&1; then
    # Check if it's BusyBox syslogd
    syslog_path=$(command -v syslogd 2>/dev/null)
    if [[ -L "$syslog_path" ]]; then
        target=$(readlink -f "$syslog_path" 2>/dev/null || true)
        if [[ "$target" == *"busybox"* ]]; then
            register_check "BusyBox syslogd" INFO "Using BusyBox syslogd"

            # Check syslogd configuration
            if [[ -f /etc/conf.d/syslog ]]; then
                register_check "Syslog Config" PASS "Syslog configuration exists"
            else
                register_check "Syslog Config" INFO "No custom syslog configuration"
            fi
        fi
    fi
fi

# ============================================================================
# Cron (crond from BusyBox)
# ============================================================================
section "BusyBox crond"

if pgrep -x crond >/dev/null 2>&1; then
    crond_path=$(command -v crond 2>/dev/null)
    if [[ -L "$crond_path" ]]; then
        target=$(readlink -f "$crond_path" 2>/dev/null || true)
        if [[ "$target" == *"busybox"* ]]; then
            register_check "BusyBox crond" INFO "Using BusyBox crond"
        fi
    fi

    # Check crontab permissions
    if [[ -d /var/spool/cron/crontabs ]]; then
        crontab_perms=$(stat -c '%a' /var/spool/cron/crontabs 2>/dev/null || echo "unknown")
        if [[ "$crontab_perms" == "700" ]] || [[ "$crontab_perms" == "750" ]]; then
            register_check "Crontab Permissions" PASS "Crontabs directory properly secured"
        else
            register_check "Crontab Permissions" WARN "Crontabs directory has permissions $crontab_perms"
        fi
    fi
fi

# ============================================================================
# Init Scripts Using BusyBox
# ============================================================================
section "Init Integration"

# Check for init scripts that may rely on BusyBox
if [[ -d /etc/init.d ]]; then
    bb_init_scripts=0
    while IFS= read -r script; do
        if grep -q 'busybox' "$script" 2>/dev/null; then
            ((bb_init_scripts++))
        fi
    done < <(find /etc/init.d -type f 2>/dev/null | head -50)

    if [[ $bb_init_scripts -gt 0 ]]; then
        register_check "Init BusyBox Deps" INFO "$bb_init_scripts init scripts reference BusyBox"
    fi
fi

print_summary
exit "$EXIT_CODE"
