#!/usr/bin/env bash
# Alpine Linux Container Security Audit
# Checks security configurations specific to Alpine in containerized environments
#
# @elevation: root
# @elevation-reason: Container namespace and cgroup checks require root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine Container Security Audit"

# Verify we're on Alpine
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# ============================================================================
# Container Detection
# ============================================================================
section "Container Environment Detection"

is_container=false
container_type="none"

# Check various container indicators
if [[ -f /.dockerenv ]]; then
    is_container=true
    container_type="docker"
    register_check "Docker Container" PASS "Running inside Docker container"
elif grep -q 'docker\|containerd' /proc/1/cgroup 2>/dev/null; then
    is_container=true
    container_type="docker"
    register_check "Docker Container" PASS "Docker/containerd detected via cgroup"
elif [[ -f /run/.containerenv ]]; then
    is_container=true
    container_type="podman"
    register_check "Podman Container" PASS "Running inside Podman container"
elif grep -q 'lxc' /proc/1/cgroup 2>/dev/null; then
    is_container=true
    container_type="lxc"
    register_check "LXC Container" PASS "Running inside LXC container"
elif [[ -d /run/secrets/kubernetes.io ]]; then
    is_container=true
    container_type="kubernetes"
    register_check "Kubernetes Pod" PASS "Running inside Kubernetes pod"
fi

if [[ "$is_container" == "false" ]]; then
    register_check "Container Detection" INFO "Not running in a container (bare metal/VM)"
fi

# ============================================================================
# Container User Security
# ============================================================================
section "Container User Security"

# Check if running as root
current_uid=$(id -u)
current_user=$(id -un)

if [[ $current_uid -eq 0 ]]; then
    if [[ "$is_container" == "true" ]]; then
        register_check "Running as Root" WARN "Running as root in container"
    else
        register_check "Running as Root" INFO "Running as root"
    fi
else
    register_check "Non-Root User" PASS "Running as non-root user ($current_user)"
fi

# Check for nobody/nogroup user
if id nobody >/dev/null 2>&1; then
    register_check "nobody User" PASS "nobody user exists for privilege dropping"
fi

# Check /etc/passwd for minimal users (container best practice)
user_count=$(wc -l < /etc/passwd)
if [[ "$is_container" == "true" ]]; then
    if [[ $user_count -lt 10 ]]; then
        register_check "Minimal Users" PASS "Only $user_count users defined (minimal)"
    else
        register_check "Minimal Users" INFO "$user_count users defined"
    fi
fi

# Check for setuid binaries
setuid_count=$(find / -xdev -perm /4000 -type f 2>/dev/null | wc -l || echo "0")
if [[ "$is_container" == "true" ]]; then
    if [[ $setuid_count -eq 0 ]]; then
        register_check "No Setuid Binaries" PASS "No setuid binaries (secure)"
    elif [[ $setuid_count -lt 5 ]]; then
        register_check "Setuid Binaries" INFO "$setuid_count setuid binaries found"
    else
        register_check "Setuid Binaries" WARN "$setuid_count setuid binaries found - consider removing"
    fi
fi

# ============================================================================
# Filesystem Security
# ============================================================================
section "Filesystem Security"

# Check if running with read-only root filesystem
if mount | grep ' / ' | grep -q 'ro[,\)]'; then
    register_check "Read-Only Root" PASS "Root filesystem is read-only"
else
    if [[ "$is_container" == "true" ]]; then
        register_check "Read-Only Root" INFO "Root filesystem is read-write"
    fi
fi

# Check tmpfs mounts
tmpfs_mounts=$(mount | grep -c tmpfs || echo "0")
if [[ $tmpfs_mounts -gt 0 ]]; then
    register_check "tmpfs Mounts" INFO "$tmpfs_mounts tmpfs mounts present"
fi

# Check for volume mounts (potential data exposure)
if [[ "$is_container" == "true" ]]; then
    # Look for bind mounts
    bind_mounts=$(mount | grep -E 'type (overlay|bind)' | wc -l || echo "0")
    register_check "Bind Mounts" INFO "$bind_mounts bind/overlay mounts detected"
fi

# Check /proc and /sys mount options
if mount | grep ' /proc ' | grep -q 'ro'; then
    register_check "/proc Read-Only" PASS "/proc is read-only"
fi

if mount | grep ' /sys ' | grep -q 'ro'; then
    register_check "/sys Read-Only" PASS "/sys is read-only"
fi

# ============================================================================
# Network Security
# ============================================================================
section "Network Security"

# Check network namespace
if [[ -f /proc/1/ns/net ]]; then
    host_netns=$(readlink /proc/1/ns/net 2>/dev/null || echo "unknown")
    register_check "Network Namespace" INFO "Network NS: ${host_netns##*[}"
fi

# Check listening ports
listening_tcp=$(ss -tlnp 2>/dev/null | grep -c LISTEN || echo "0")
listening_udp=$(ss -ulnp 2>/dev/null | grep -c '\*' || echo "0")

register_check "TCP Listeners" INFO "$listening_tcp TCP ports listening"
register_check "UDP Listeners" INFO "$listening_udp UDP ports listening"

# Check for iptables/nftables
if command -v iptables >/dev/null 2>&1; then
    iptables_rules=$(iptables -L 2>/dev/null | wc -l || echo "0")
    if [[ $iptables_rules -gt 10 ]]; then
        register_check "iptables Rules" PASS "iptables rules configured"
    else
        register_check "iptables Rules" INFO "Minimal iptables rules"
    fi
else
    register_check "iptables" INFO "iptables not available"
fi

# ============================================================================
# Capability Security
# ============================================================================
section "Linux Capabilities"

# Check if capsh is available
if command -v capsh >/dev/null 2>&1; then
    current_caps=$(capsh --print 2>/dev/null | grep -i 'current' | head -1 || echo "Unable to determine")
    register_check "Capabilities" INFO "Current: ${current_caps:0:80}"

    # Check for dangerous capabilities
    dangerous_caps="cap_sys_admin|cap_sys_ptrace|cap_sys_module|cap_net_admin|cap_net_raw"
    if capsh --print 2>/dev/null | grep -qE "$dangerous_caps"; then
        register_check "Dangerous Capabilities" WARN "Container has potentially dangerous capabilities"
    else
        register_check "Dangerous Capabilities" PASS "No dangerous capabilities detected"
    fi
elif [[ -f /proc/self/status ]]; then
    cap_eff=$(grep CapEff /proc/self/status 2>/dev/null | awk '{print $2}' || echo "unknown")
    register_check "Effective Capabilities" INFO "CapEff: $cap_eff"
fi

# ============================================================================
# Process Isolation
# ============================================================================
section "Process Isolation"

# Check PID namespace
if [[ -f /proc/1/status ]]; then
    pid1_name=$(grep Name /proc/1/status | awk '{print $2}')
    if [[ "$pid1_name" == "tini" ]] || [[ "$pid1_name" == "dumb-init" ]]; then
        register_check "Init Process" PASS "Proper init process ($pid1_name) detected"
    elif [[ "$pid1_name" == "sh" ]] || [[ "$pid1_name" == "bash" ]]; then
        register_check "Init Process" WARN "Shell as PID 1 - consider using tini/dumb-init"
    else
        register_check "Init Process" INFO "PID 1: $pid1_name"
    fi
fi

# Check process count
proc_count=$(ls -1d /proc/[0-9]* 2>/dev/null | wc -l || echo "unknown")
register_check "Process Count" INFO "$proc_count processes running"

# ============================================================================
# Secrets & Credentials
# ============================================================================
section "Secrets Management"

# Check for exposed secrets (Kubernetes)
if [[ -d /run/secrets ]]; then
    secret_count=$(find /run/secrets -type f 2>/dev/null | wc -l || echo "0")
    register_check "Docker Secrets" INFO "$secret_count Docker secrets mounted"
fi

if [[ -d /run/secrets/kubernetes.io ]]; then
    register_check "K8s Secrets" INFO "Kubernetes secrets directory present"

    # Check service account token
    if [[ -f /run/secrets/kubernetes.io/serviceaccount/token ]]; then
        register_check "K8s Service Account" INFO "Service account token mounted"
    fi
fi

# Check for common credential files
credential_files=(
    "/root/.ssh"
    "/root/.aws"
    "/root/.docker/config.json"
    "/etc/shadow"
)

for cred_file in "${credential_files[@]}"; do
    if [[ -e "$cred_file" ]]; then
        if [[ "$is_container" == "true" ]]; then
            register_check "Credential: ${cred_file##*/}" WARN "$cred_file exists in container"
        fi
    fi
done

# Check environment for secrets
# shellcheck disable=SC2013
for var in $(env | grep -iE '(password|secret|key|token|api_key)=' | cut -d= -f1 2>/dev/null | head -5); do
    register_check "Secret in Env: $var" WARN "Potential secret in environment variable"
done

# ============================================================================
# Alpine-Specific Container Checks
# ============================================================================
section "Alpine Container Best Practices"

# Check if using apk --no-cache
if [[ -d /var/cache/apk ]] && [[ -n "$(ls -A /var/cache/apk 2>/dev/null)" ]]; then
    register_check "APK Cache" WARN "APK cache not cleared - adds to image size"
else
    register_check "APK Cache" PASS "APK cache is empty"
fi

# Check for minimal shell
if [[ -L /bin/sh ]] && readlink /bin/sh | grep -q busybox; then
    register_check "BusyBox Shell" PASS "Using BusyBox shell (minimal)"
fi

# Check if unnecessary packages are installed
unnecessary_pkgs=(
    "build-base"
    "gcc"
    "make"
    "python3-dev"
    "linux-headers"
)

installed_dev_pkgs=0
for pkg in "${unnecessary_pkgs[@]}"; do
    if apk info -e "$pkg" >/dev/null 2>&1; then
        ((installed_dev_pkgs++)) || true
    fi
done

if [[ $installed_dev_pkgs -eq 0 ]]; then
    register_check "No Dev Packages" PASS "No development packages installed"
else
    register_check "Dev Packages" WARN "$installed_dev_pkgs dev packages installed (build-base, gcc, etc.)"
fi

# Check image size indicators
if [[ -f /.dockerenv ]] || [[ -f /run/.containerenv ]]; then
    total_packages=$(apk info 2>/dev/null | wc -l || echo "0")
    if [[ $total_packages -lt 20 ]]; then
        register_check "Minimal Packages" PASS "Only $total_packages packages installed"
    elif [[ $total_packages -lt 50 ]]; then
        register_check "Package Count" INFO "$total_packages packages installed"
    else
        register_check "Package Count" WARN "$total_packages packages - consider reducing"
    fi
fi

# ============================================================================
# Health & Monitoring
# ============================================================================
section "Health & Monitoring"

# Check for health check endpoint (if web service)
if ss -tlnp 2>/dev/null | grep -qE ':80|:8080|:443|:8443|:5000|:3000'; then
    register_check "Web Service" INFO "Web service ports detected"
fi

# Check for log output to stdout/stderr (container best practice)
if [[ -L /var/log/messages ]] || [[ ! -f /var/log/messages ]]; then
    register_check "Log to Stdout" INFO "Not logging to /var/log/messages"
fi

# Check resource limits (cgroups)
if [[ -f /sys/fs/cgroup/memory.max ]] || [[ -f /sys/fs/cgroup/memory/memory.limit_in_bytes ]]; then
    register_check "Memory Limits" INFO "Cgroup memory limits present"
fi

if [[ -f /sys/fs/cgroup/cpu.max ]] || [[ -f /sys/fs/cgroup/cpu/cpu.cfs_quota_us ]]; then
    register_check "CPU Limits" INFO "Cgroup CPU limits present"
fi

print_summary
exit "$EXIT_CODE"
