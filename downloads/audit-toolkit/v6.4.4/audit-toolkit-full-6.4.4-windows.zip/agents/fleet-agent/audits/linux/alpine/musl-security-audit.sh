#!/usr/bin/env bash
# Alpine Linux musl Security Audit
# Checks musl libc security configurations and considerations
#
# @elevation: partial
# @elevation-reason: musl config checks mostly readable without root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine musl libc Security Audit"

# Verify we're on Alpine (musl-based)
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# Verify musl is in use
if ! ldd --version 2>&1 | head -1 | grep -qi 'musl'; then
    register_check "musl Detection" SKIP "musl not detected as system libc"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "musl Detection" PASS "musl libc detected"

# ============================================================================
# musl Version & Security
# ============================================================================
section "musl Version Information"

# Get musl version
musl_version=$(ldd --version 2>&1 | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
register_check "musl Version" INFO "musl libc version: $musl_version"

# Check for known vulnerable versions
case "$musl_version" in
    1.2.4|1.2.5)
        register_check "musl Security Status" PASS "musl version is recent"
        ;;
    1.2.[0-3])
        register_check "musl Security Status" WARN "Consider updating musl to latest 1.2.x"
        ;;
    1.1.*)
        register_check "musl Security Status" WARN "musl 1.1.x - consider upgrading to 1.2.x for security improvements"
        ;;
    *)
        register_check "musl Security Status" INFO "Unable to assess musl version: $musl_version"
        ;;
esac

# ============================================================================
# musl-Specific Configuration
# ============================================================================
section "musl Configuration"

# Check nsswitch.conf (if using musl-nscd)
if [[ -f /etc/nsswitch.conf ]]; then
    register_check "NSS Configuration" INFO "nsswitch.conf present"

    # Check for specific NSS configurations
    if grep -q 'dns' /etc/nsswitch.conf 2>/dev/null; then
        register_check "DNS Resolution" INFO "DNS configured in NSS"
    fi
else
    register_check "NSS Configuration" INFO "No nsswitch.conf (using musl defaults)"
fi

# Check resolv.conf
if [[ -f /etc/resolv.conf ]]; then
    dns_servers=$(grep -c '^nameserver' /etc/resolv.conf 2>/dev/null || echo "0")
    register_check "DNS Servers" INFO "$dns_servers DNS servers configured"

    # Check for secure DNS options
    if grep -q 'options edns0' /etc/resolv.conf 2>/dev/null; then
        register_check "EDNS0 Support" PASS "EDNS0 enabled"
    fi
else
    register_check "resolv.conf" WARN "No /etc/resolv.conf found"
fi

# ============================================================================
# Stack Protection
# ============================================================================
section "Stack Protection"

# Check ASLR
aslr_status=$(cat /proc/sys/kernel/randomize_va_space 2>/dev/null || echo "unknown")
case "$aslr_status" in
    2)
        register_check "ASLR" PASS "Full ASLR enabled (level 2)"
        ;;
    1)
        register_check "ASLR" WARN "Partial ASLR enabled (level 1)"
        ;;
    0)
        register_check "ASLR" FAIL "ASLR disabled"
        ;;
    *)
        register_check "ASLR" INFO "Unable to determine ASLR status"
        ;;
esac

# Check for stack protector in key binaries
if command -v readelf >/dev/null 2>&1; then
    # Check if musl itself has stack protector
    musl_lib=$(find /lib /usr/lib -name 'libc.musl-*.so*' -type f 2>/dev/null | head -1)
    if [[ -n "$musl_lib" ]]; then
        if readelf -s "$musl_lib" 2>/dev/null | grep -q '__stack_chk_fail'; then
            register_check "musl Stack Protector" PASS "Stack protector support in musl"
        else
            register_check "musl Stack Protector" INFO "Stack protector check inconclusive"
        fi
    fi

    # Check busybox for stack protection
    if [[ -x /bin/busybox ]]; then
        if readelf -s /bin/busybox 2>/dev/null | grep -q '__stack_chk_fail'; then
            register_check "BusyBox Stack Protector" PASS "BusyBox compiled with stack protection"
        else
            register_check "BusyBox Stack Protector" WARN "BusyBox may lack stack protection"
        fi
    fi
else
    register_check "ELF Analysis" SKIP "readelf not available"
fi

# ============================================================================
# malloc Security (musl-specific)
# ============================================================================
section "Memory Allocator Security"

# musl's malloc has different security characteristics than glibc
register_check "musl malloc" INFO "musl uses its own malloc implementation"

# Check if MALLOC_CHECK_ equivalent is set (not applicable to musl, but check anyway)
if [[ -n "${MALLOC_CHECK_:-}" ]]; then
    register_check "MALLOC_CHECK_" INFO "MALLOC_CHECK_ set (not used by musl)"
fi

# Check for mmap randomization
mmap_rnd=$(cat /proc/sys/vm/mmap_rnd_bits 2>/dev/null || echo "unknown")
if [[ "$mmap_rnd" != "unknown" ]]; then
    if [[ "$mmap_rnd" -ge 28 ]]; then
        register_check "mmap Randomization" PASS "$mmap_rnd bits of mmap randomization"
    else
        register_check "mmap Randomization" WARN "Only $mmap_rnd bits of mmap randomization"
    fi
fi

# ============================================================================
# Binary Compatibility & Security
# ============================================================================
section "Binary Security"

# Check for glibc compatibility libs (potential security concern)
if apk info -e gcompat >/dev/null 2>&1; then
    register_check "gcompat Installed" WARN "gcompat (glibc compat) installed - may introduce vulnerabilities"
else
    register_check "gcompat" PASS "gcompat not installed"
fi

# Check for libc6-compat
if apk info -e libc6-compat >/dev/null 2>&1; then
    register_check "libc6-compat Installed" WARN "libc6-compat installed - adds glibc compatibility"
else
    register_check "libc6-compat" PASS "libc6-compat not installed"
fi

# Check for any preloaded libraries
if [[ -n "${LD_PRELOAD:-}" ]]; then
    register_check "LD_PRELOAD" WARN "LD_PRELOAD is set: $LD_PRELOAD"
else
    register_check "LD_PRELOAD" PASS "LD_PRELOAD not set"
fi

# Check /etc/ld.so.preload (musl uses /etc/ld-musl-*.path)
musl_arch=$(uname -m)
musl_path_file="/etc/ld-musl-${musl_arch}.path"
if [[ -f "$musl_path_file" ]]; then
    register_check "musl Library Path" INFO "Custom musl library path configured"
else
    register_check "musl Library Path" PASS "Using default musl library path"
fi

# ============================================================================
# Locale Security (musl has limited locale support)
# ============================================================================
section "Locale Configuration"

# musl has simplified locale handling
current_lang="${LANG:-C}"

if [[ "$current_lang" == "C" ]] || [[ "$current_lang" == "C.UTF-8" ]] || [[ "$current_lang" == "POSIX" ]]; then
    register_check "Locale Setting" PASS "Using simple locale ($current_lang)"
else
    register_check "Locale Setting" INFO "Using locale: $current_lang (musl has limited locale support)"
fi

# Check for musl-locales package
if apk info -e musl-locales >/dev/null 2>&1; then
    register_check "musl-locales" INFO "musl-locales package installed for extended locale support"
fi

# ============================================================================
# DNS Security (musl resolver)
# ============================================================================
section "DNS Security (musl resolver)"

# musl has its own DNS resolver implementation
register_check "musl DNS Resolver" INFO "musl uses built-in DNS resolver"

# Check for DNS over TLS support (requires additional setup on Alpine)
if command -v stubby >/dev/null 2>&1 || command -v dnscrypt-proxy >/dev/null 2>&1; then
    register_check "DNS Encryption" INFO "DNS encryption tool available"
else
    register_check "DNS Encryption" INFO "No DNS encryption tool detected"
fi

# Check resolv.conf for potentially insecure configurations
if [[ -f /etc/resolv.conf ]]; then
    # Check for search domains (potential DNS rebinding)
    if grep -q '^search' /etc/resolv.conf 2>/dev/null; then
        search_domains=$(grep '^search' /etc/resolv.conf | wc -l)
        register_check "DNS Search Domains" INFO "$search_domains search domain configurations"
    fi
fi

# ============================================================================
# Static Linking Considerations
# ============================================================================
section "Static Linking Analysis"

# Check for statically linked binaries (common in Alpine)
static_count=0
dynamic_count=0

# shellcheck disable=SC2044
for binary in $(find /bin /usr/bin -maxdepth 1 -type f -executable 2>/dev/null | head -100); do
    if file "$binary" 2>/dev/null | grep -q 'statically linked'; then
        ((static_count++)) || true
    elif file "$binary" 2>/dev/null | grep -q 'dynamically linked'; then
        ((dynamic_count++)) || true
    fi
done

register_check "Static Binaries" INFO "$static_count statically linked binaries found"
register_check "Dynamic Binaries" INFO "$dynamic_count dynamically linked binaries found"

# Note about static linking security implications
if [[ $static_count -gt $dynamic_count ]]; then
    register_check "Linking Strategy" INFO "More static than dynamic binaries - updates require rebuilding"
fi

print_summary
exit "$EXIT_CODE"
