#!/usr/bin/env bash
# Alpine Linux OpenRC Services Security Audit
# Checks OpenRC service configuration, runlevels, and security settings
#
# @elevation: partial
# @elevation-reason: rc-status and runlevel configs readable without root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"

section "Alpine OpenRC Services Security Audit"

# Verify we're on Alpine
if [[ "$(detect_distro)" != "alpine" ]]; then
    register_check "Alpine Detection" SKIP "Not running on Alpine Linux - this audit is Alpine-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# Check if OpenRC is available
if ! command -v rc-service >/dev/null 2>&1; then
    register_check "OpenRC Available" FAIL "OpenRC not found - is this Alpine Linux?"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "OpenRC Available" PASS "OpenRC is installed"

# ============================================================================
# Runlevel Configuration
# ============================================================================
section "Runlevel Configuration"

# Check default runlevel
if [[ -L /etc/runlevels/default ]]; then
    register_check "Default Runlevel" PASS "Default runlevel symlink exists"
else
    # Check for services in default runlevel
    if [[ -d /etc/runlevels/default ]] && [[ -n "$(ls -A /etc/runlevels/default 2>/dev/null)" ]]; then
        register_check "Default Runlevel" PASS "Default runlevel configured with services"
    else
        register_check "Default Runlevel" WARN "No services in default runlevel"
    fi
fi

# Validate boot runlevel
if [[ -d /etc/runlevels/boot ]] && [[ -n "$(ls -A /etc/runlevels/boot 2>/dev/null)" ]]; then
    register_check "Boot Runlevel" PASS "Boot runlevel has services"
else
    register_check "Boot Runlevel" WARN "Boot runlevel empty or missing"
fi

# Check sysinit runlevel
if [[ -d /etc/runlevels/sysinit ]] && [[ -n "$(ls -A /etc/runlevels/sysinit 2>/dev/null)" ]]; then
    register_check "Sysinit Runlevel" PASS "Sysinit runlevel configured"
else
    register_check "Sysinit Runlevel" WARN "Sysinit runlevel empty"
fi

# ============================================================================
# Critical Services Status
# ============================================================================
section "Critical Services Status"

# Check crond (Alpine's cron daemon)
if rc-service crond status >/dev/null 2>&1; then
    register_check "Cron Daemon" PASS "crond is running"
else
    if [[ -f /etc/init.d/crond ]]; then
        register_check "Cron Daemon" WARN "crond installed but not running"
    else
        register_check "Cron Daemon" INFO "crond not installed (may be intentional in containers)"
    fi
fi

# Check syslog
if rc-service syslog status >/dev/null 2>&1 || rc-service rsyslog status >/dev/null 2>&1; then
    register_check "Syslog Service" PASS "Syslog service is running"
else
    # In containers, syslog might not be needed
    if [[ -f /.dockerenv ]]; then
        register_check "Syslog Service" INFO "Syslog not running (container environment)"
    else
        register_check "Syslog Service" WARN "No syslog service running"
    fi
fi

# Check networking
if rc-service networking status >/dev/null 2>&1; then
    register_check "Networking Service" PASS "Networking service is running"
else
    # Alpine in containers often doesn't use traditional networking service
    if [[ -f /.dockerenv ]]; then
        register_check "Networking Service" INFO "Networking service not used (container)"
    else
        register_check "Networking Service" INFO "Networking service not running"
    fi
fi

# Check acpid (power management)
if rc-service acpid status >/dev/null 2>&1; then
    register_check "ACPI Daemon" PASS "acpid is running"
else
    # Not needed in containers or VMs often
    register_check "ACPI Daemon" INFO "acpid not running (may be intentional)"
fi

# ============================================================================
# Service Script Permissions
# ============================================================================
section "Service Script Permissions"

# Check init.d script permissions
insecure_scripts=0
if [[ -d /etc/init.d ]]; then
    while IFS= read -r script; do
        if [[ -f "$script" ]]; then
            perms=$(stat -c '%a' "$script" 2>/dev/null || stat -f '%Lp' "$script" 2>/dev/null)
            owner=$(stat -c '%U' "$script" 2>/dev/null || stat -f '%Su' "$script" 2>/dev/null)

            if [[ "$owner" != "root" ]]; then
                ((insecure_scripts++))
            fi

            # Check if world-writable
            if [[ $((perms & 2)) -ne 0 ]]; then
                ((insecure_scripts++))
            fi
        fi
    done < <(find /etc/init.d -type f -name '*.sh' -o -type f ! -name '*.*' 2>/dev/null | head -50)
fi

if [[ $insecure_scripts -eq 0 ]]; then
    register_check "Init Script Permissions" PASS "All init scripts have secure permissions"
else
    register_check "Init Script Permissions" FAIL "$insecure_scripts init scripts have insecure permissions"
fi

# Check conf.d permissions
if [[ -d /etc/conf.d ]]; then
    insecure_conf=0
    while IFS= read -r conf; do
        if [[ -f "$conf" ]]; then
            perms=$(stat -c '%a' "$conf" 2>/dev/null || stat -f '%Lp' "$conf" 2>/dev/null)
            if [[ $((perms & 2)) -ne 0 ]]; then
                ((insecure_conf++))
            fi
        fi
    done < <(find /etc/conf.d -type f 2>/dev/null | head -50)

    if [[ $insecure_conf -eq 0 ]]; then
        register_check "Conf.d Permissions" PASS "All conf.d files have secure permissions"
    else
        register_check "Conf.d Permissions" FAIL "$insecure_conf conf.d files are world-writable"
    fi
else
    register_check "Conf.d Permissions" INFO "/etc/conf.d not found"
fi

# ============================================================================
# Unnecessary Services
# ============================================================================
section "Unnecessary Services Check"

# Check for potentially unnecessary services in containers
unnecessary_services=(
    "swap"
    "swapfiles"
    "localmount"
    "netmount"
    "nfs"
    "nfsclient"
)

for svc in "${unnecessary_services[@]}"; do
    if rc-service "$svc" status >/dev/null 2>&1; then
        if [[ -f /.dockerenv ]]; then
            register_check "Service: $svc" WARN "$svc running in container (usually unnecessary)"
        else
            register_check "Service: $svc" INFO "$svc is running"
        fi
    fi
done

# ============================================================================
# Security-Related Services
# ============================================================================
section "Security Services"

# Check iptables/firewall
if rc-service iptables status >/dev/null 2>&1 || rc-service ip6tables status >/dev/null 2>&1; then
    register_check "Firewall Service" PASS "iptables service is running"
elif rc-service nftables status >/dev/null 2>&1; then
    register_check "Firewall Service" PASS "nftables service is running"
else
    if [[ -f /.dockerenv ]]; then
        register_check "Firewall Service" INFO "No firewall service (container uses host firewall)"
    else
        register_check "Firewall Service" WARN "No firewall service running"
    fi
fi

# Check for SSH daemon
if rc-service sshd status >/dev/null 2>&1; then
    register_check "SSH Daemon" INFO "sshd is running - ensure properly configured"

    # Check SSH config
    if [[ -f /etc/ssh/sshd_config ]]; then
        if grep -qE "^PermitRootLogin\s+no" /etc/ssh/sshd_config; then
            register_check "SSH Root Login" PASS "Root login disabled"
        elif grep -qE "^PermitRootLogin\s+prohibit-password" /etc/ssh/sshd_config; then
            register_check "SSH Root Login" PASS "Root login requires key authentication"
        else
            register_check "SSH Root Login" WARN "Root login may be enabled"
        fi
    fi
else
    register_check "SSH Daemon" INFO "sshd not running"
fi

# ============================================================================
# OpenRC Configuration
# ============================================================================
section "OpenRC Configuration"

# Check rc.conf
if [[ -f /etc/rc.conf ]]; then
    register_check "rc.conf Exists" PASS "/etc/rc.conf present"

    # Check for unicode support
    if grep -qE "^unicode=" /etc/rc.conf; then
        register_check "Unicode Config" INFO "Unicode setting configured in rc.conf"
    fi

    # Check for parallel startup
    if grep -qE "^rc_parallel=" /etc/rc.conf; then
        register_check "Parallel Startup" INFO "Parallel startup configured"
    fi
else
    register_check "rc.conf Exists" INFO "/etc/rc.conf not present (using defaults)"
fi

# Check local.d scripts
if [[ -d /etc/local.d ]]; then
    local_scripts=$(find /etc/local.d -type f -name '*.start' -o -name '*.stop' 2>/dev/null | wc -l)
    if [[ $local_scripts -gt 0 ]]; then
        register_check "Local.d Scripts" INFO "$local_scripts local.d scripts found - review for security"
    else
        register_check "Local.d Scripts" PASS "No local.d scripts"
    fi
fi

print_summary
exit "$EXIT_CODE"
