#!/usr/bin/env bash
# containerd-audit.sh — Containerd Security Audit
#
# Compliance Mapping:
# - CIS Kubernetes Benchmark (Container Runtime)
# - NIST SP 800-190 (Container Security)
# - NSA/CISA Kubernetes Hardening Guidance
#
# Checks:
# - Containerd installation and version
# - Service status
# - Configuration security
# - Runtime security (seccomp, AppArmor/SELinux)
# - Registry configuration
#
# @elevation: root
# @elevation-reason: containerd socket and config require root access
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "Containerd Security Audit"

# Check if containerd is installed
if ! command -v containerd >/dev/null 2>&1; then
  register_check "Containerd installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Containerd installed" PASS "found"

section "Containerd Version"

# Get version
version=$(containerd --version 2>/dev/null | head -1 || echo "")
if [[ -n "$version" ]]; then
  ver_num=$(echo "$version" | grep -oE "v[0-9]+\.[0-9]+\.[0-9]+" || echo "$version")
  register_check "Version" PASS "$ver_num"
fi

section "Service Status"

# Check containerd service
if systemctl is-active containerd >/dev/null 2>&1; then
  register_check "Service running" PASS "active"
else
  register_check "Service running" FAIL "inactive"
fi

if systemctl is-enabled containerd >/dev/null 2>&1; then
  register_check "Service enabled" PASS "yes"
else
  register_check "Service enabled" WARN "not enabled"
fi

section "Configuration"

# Check configuration file
config_file="/etc/containerd/config.toml"
if [[ -f "$config_file" ]]; then
  register_check "Config file" PASS "exists"

  # Check permissions
  perms=$(stat -c "%a" "$config_file" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$config_file" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "600" ]] || [[ "$perms" == "644" ]]; then
    register_check "Config permissions" PASS "$perms $owner"
  else
    register_check "Config permissions" WARN "$perms $owner"
  fi

  # Check for default runtime
  default_runtime=$(grep -E "default_runtime_name\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$default_runtime" ]]; then
    register_check "Default runtime" PASS "$default_runtime"
  else
    register_check "Default runtime" PASS "runc (implicit)"
  fi

  # Check for deprecated v1 config
  if grep -qE "^\[plugins\.cri\]" "$config_file" 2>/dev/null; then
    register_check "Config version" WARN "v1 format (deprecated)"
  elif grep -qE '^\[plugins\."io\.containerd' "$config_file" 2>/dev/null; then
    register_check "Config version" PASS "v2 format"
  fi
else
  register_check "Config file" WARN "not found (using defaults)"
fi

section "Runtime Security"

# Check for runc
if command -v runc >/dev/null 2>&1; then
  runc_version=$(runc --version 2>/dev/null | head -1 | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" || echo "")
  register_check "runc installed" PASS "v$runc_version"
else
  register_check "runc installed" WARN "not found"
fi

# Check for alternative runtimes
if command -v crun >/dev/null 2>&1; then
  register_check "crun available" PASS "yes"
fi

if command -v kata-runtime >/dev/null 2>&1; then
  register_check "kata-runtime available" PASS "yes (VM isolation)"
fi

if command -v gvisor >/dev/null 2>&1 || [[ -f "/usr/local/bin/runsc" ]]; then
  register_check "gVisor available" PASS "yes (sandboxed)"
fi

section "Seccomp Configuration"

# Check for seccomp support
if [[ -f "$config_file" ]]; then
  if grep -qE "enable_seccomp\s*=\s*true" "$config_file" 2>/dev/null; then
    register_check "Seccomp enabled" PASS "yes"
  elif grep -qE "enable_seccomp\s*=\s*false" "$config_file" 2>/dev/null; then
    register_check "Seccomp enabled" FAIL "explicitly disabled"
  else
    register_check "Seccomp enabled" PASS "default (enabled)"
  fi
fi

# Check for seccomp profile
seccomp_profiles=(
  "/etc/containerd/cri-base.json"
  "/etc/containerd/seccomp.json"
  "/var/lib/containerd/default-seccomp-profile.json"
)

for profile in "${seccomp_profiles[@]}"; do
  if [[ -f "$profile" ]]; then
    register_check "Seccomp profile" PASS "$profile"
    break
  fi
done

section "AppArmor/SELinux"

# Check SELinux integration
if command -v getenforce >/dev/null 2>&1; then
  selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
  if [[ "$selinux_mode" == "Enforcing" ]]; then
    register_check "SELinux mode" PASS "Enforcing"

    # Check containerd SELinux support
    if [[ -f "$config_file" ]] && grep -qE "enable_selinux\s*=\s*true" "$config_file" 2>/dev/null; then
      register_check "SELinux support" PASS "enabled"
    fi
  elif [[ "$selinux_mode" == "Permissive" ]]; then
    register_check "SELinux mode" WARN "Permissive"
  fi
fi

# Check AppArmor
if command -v aa-status >/dev/null 2>&1; then
  if aa-status 2>/dev/null | grep -qi "containerd\|cri-containerd"; then
    register_check "AppArmor profile" PASS "loaded"
  else
    register_check "AppArmor profile" WARN "no containerd profile"
  fi
fi

section "Registry Configuration"

# Check for registry mirrors/TLS
if [[ -f "$config_file" ]]; then
  # Check for insecure registries
  if grep -qE "skip_verify\s*=\s*true" "$config_file" 2>/dev/null; then
    insecure_count=$(grep -cE "skip_verify\s*=\s*true" "$config_file" 2>/dev/null || echo "0")
    register_check "Insecure registries" WARN "$insecure_count configured"
  else
    register_check "Insecure registries" PASS "none"
  fi

  # Check for registry mirrors
  if grep -qE "\[plugins.*registry\.mirrors\]" "$config_file" 2>/dev/null; then
    register_check "Registry mirrors" PASS "configured"
  fi

  # Check for registry auth
  if grep -qE "\[plugins.*registry\.configs.*auth\]" "$config_file" 2>/dev/null; then
    register_check "Registry auth" PASS "configured"
  fi
fi

section "Snapshotter"

# Check snapshotter configuration
if [[ -f "$config_file" ]]; then
  snapshotter=$(grep -E "snapshotter\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$snapshotter" ]]; then
    if [[ "$snapshotter" == "overlayfs" ]] || [[ "$snapshotter" == "overlay" ]]; then
      register_check "Snapshotter" PASS "$snapshotter (recommended)"
    else
      register_check "Snapshotter" PASS "$snapshotter"
    fi
  else
    register_check "Snapshotter" PASS "overlayfs (default)"
  fi
fi

section "CNI Configuration"

# Check CNI plugins
cni_bin_dir="/opt/cni/bin"
if [[ -d "$cni_bin_dir" ]]; then
  cni_count=$(find "$cni_bin_dir" -type f -executable 2>/dev/null | wc -l || echo "0")
  register_check "CNI plugins" PASS "$cni_count plugins"
else
  register_check "CNI plugins" WARN "directory not found"
fi

# Check CNI config
cni_conf_dir="/etc/cni/net.d"
if [[ -d "$cni_conf_dir" ]]; then
  conf_count=$(find "$cni_conf_dir" -name "*.conf" -o -name "*.conflist" 2>/dev/null | wc -l || echo "0")
  register_check "CNI configs" PASS "$conf_count files"
else
  register_check "CNI configs" WARN "directory not found"
fi

section "Socket and API"

# Check containerd socket
socket_path="/run/containerd/containerd.sock"
if [[ -S "$socket_path" ]]; then
  perms=$(stat -c "%a" "$socket_path" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$socket_path" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "660" ]] || [[ "$perms" == "600" ]]; then
    register_check "Socket permissions" PASS "$perms $owner"
  else
    register_check "Socket permissions" WARN "$perms $owner"
  fi
else
  register_check "Socket" WARN "not found"
fi

section "State Directory"

# Check state directory permissions
state_dir="/var/lib/containerd"
if [[ -d "$state_dir" ]]; then
  perms=$(stat -c "%a" "$state_dir" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$state_dir" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "700" ]] || [[ "$perms" == "711" ]]; then
    register_check "State dir permissions" PASS "$perms $owner"
  else
    register_check "State dir permissions" WARN "$perms $owner"
  fi
fi

section "OCI Hooks"

# Check for OCI hooks
hooks_dir="/etc/containerd/hooks.d"
if [[ -d "$hooks_dir" ]]; then
  hook_count=$(find "$hooks_dir" -name "*.json" -type f 2>/dev/null | wc -l || echo "0")
  if [[ "$hook_count" -gt 0 ]]; then
    register_check "OCI hooks" PASS "$hook_count configured"
  else
    register_check "OCI hooks" PASS "directory exists (empty)"
  fi
fi

section "Resource Limits"

# Check if containerd has resource limits configured
if [[ -f "/etc/systemd/system/containerd.service.d/override.conf" ]]; then
  register_check "Systemd overrides" PASS "configured"
fi

# Check LimitNOFILE
nofile=$(systemctl show containerd -p LimitNOFILE 2>/dev/null | cut -d= -f2)
if [[ -n "$nofile" ]] && [[ "$nofile" != "infinity" ]]; then
  register_check "LimitNOFILE" PASS "$nofile"
fi

section "Running Containers"

# Check for running containers via ctr
if command -v ctr >/dev/null 2>&1; then
  container_count=$(ctr -n k8s.io containers list -q 2>/dev/null | wc -l || echo "0")
  if [[ "$container_count" -gt 0 ]]; then
    register_check "k8s.io containers" PASS "$container_count"
  fi

  default_ns=$(ctr containers list -q 2>/dev/null | wc -l || echo "0")
  if [[ "$default_ns" -gt 0 ]]; then
    register_check "Default ns containers" PASS "$default_ns"
  fi
fi

print_summary
exit "$EXIT_CODE"
