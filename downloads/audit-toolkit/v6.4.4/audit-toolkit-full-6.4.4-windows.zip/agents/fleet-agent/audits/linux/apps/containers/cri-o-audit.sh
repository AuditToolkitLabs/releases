#!/usr/bin/env bash
# cri-o-audit.sh — CRI-O Security Audit
#
# Compliance Mapping:
# - CIS Kubernetes Benchmark (Container Runtime)
# - NIST SP 800-190 (Container Security)
# - NSA/CISA Kubernetes Hardening Guidance
# - Red Hat OpenShift Security Guidelines
#
# Checks:
# - CRI-O installation and version
# - Service status
# - Configuration security
# - Seccomp/AppArmor/SELinux
# - Image signature policy
# - Runtime configuration
#
# @elevation: root
# @elevation-reason: crictl and CRI-O socket require root access
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "CRI-O Security Audit"

# Check if CRI-O is installed
if ! command -v crio >/dev/null 2>&1; then
  register_check "CRI-O installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "CRI-O installed" PASS "found"

section "CRI-O Version"

# Get version
version=$(crio --version 2>/dev/null | head -1 || echo "")
if [[ -n "$version" ]]; then
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" | head -1 || echo "$version")
  register_check "Version" PASS "$ver_num"
fi

section "Service Status"

# Check crio service
if systemctl is-active crio >/dev/null 2>&1; then
  register_check "Service running" PASS "active"
else
  register_check "Service running" FAIL "inactive"
fi

if systemctl is-enabled crio >/dev/null 2>&1; then
  register_check "Service enabled" PASS "yes"
else
  register_check "Service enabled" WARN "not enabled"
fi

section "Configuration Files"

# Check main configuration
config_file="/etc/crio/crio.conf"
if [[ -f "$config_file" ]]; then
  register_check "Main config" PASS "exists"

  # Check permissions
  perms=$(stat -c "%a" "$config_file" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$config_file" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "600" ]] || [[ "$perms" == "644" ]]; then
    register_check "Config permissions" PASS "$perms $owner"
  else
    register_check "Config permissions" WARN "$perms $owner"
  fi
else
  register_check "Main config" WARN "not found"
fi

# Check config.d directory
config_d="/etc/crio/crio.conf.d"
if [[ -d "$config_d" ]]; then
  drop_in_count=$(find "$config_d" -name "*.conf" -type f 2>/dev/null | wc -l || echo "0")
  register_check "Drop-in configs" PASS "$drop_in_count files"
fi

section "Runtime Configuration"

if [[ -f "$config_file" ]]; then
  # Check default runtime
  default_runtime=$(grep -E "^default_runtime\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$default_runtime" ]]; then
    register_check "Default runtime" PASS "$default_runtime"
  else
    # Check in [crio.runtime] section
    default_runtime=$(sed -n '/\[crio\.runtime\]/,/\[/p' "$config_file" 2>/dev/null | grep "default_runtime" | cut -d'"' -f2 | head -1)
    if [[ -n "$default_runtime" ]]; then
      register_check "Default runtime" PASS "$default_runtime"
    else
      register_check "Default runtime" PASS "runc (implicit)"
    fi
  fi

  # Check for crun (more secure, uses cgroups v2)
  if grep -qE 'runtime_path.*crun' "$config_file" 2>/dev/null; then
    register_check "crun available" PASS "configured"
  fi
fi

# Check runc
if command -v runc >/dev/null 2>&1; then
  runc_version=$(runc --version 2>/dev/null | head -1 | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" || echo "")
  register_check "runc installed" PASS "v$runc_version"
fi

# Check crun
if command -v crun >/dev/null 2>&1; then
  crun_version=$(crun --version 2>/dev/null | head -1 | grep -oE "[0-9]+\.[0-9]+(\.[0-9]+)?" || echo "")
  register_check "crun installed" PASS "v$crun_version"
fi

section "Seccomp Configuration"

if [[ -f "$config_file" ]]; then
  # Check seccomp profile path
  seccomp_profile=$(grep -E "^seccomp_profile\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$seccomp_profile" ]] && [[ "$seccomp_profile" != '""' ]]; then
    if [[ -f "$seccomp_profile" ]]; then
      register_check "Seccomp profile" PASS "$seccomp_profile"
    else
      register_check "Seccomp profile" WARN "configured but missing: $seccomp_profile"
    fi
  else
    # Check default location
    default_seccomp="/usr/share/containers/seccomp.json"
    if [[ -f "$default_seccomp" ]]; then
      register_check "Seccomp profile" PASS "$default_seccomp (default)"
    else
      register_check "Seccomp profile" WARN "not configured"
    fi
  fi

  # Check seccomp use default when empty
  if grep -qE "seccomp_use_default_when_empty\s*=\s*true" "$config_file" 2>/dev/null; then
    register_check "Seccomp default" PASS "enabled"
  fi
fi

section "AppArmor Configuration"

if [[ -f "$config_file" ]]; then
  # Check AppArmor profile
  apparmor_profile=$(grep -E "^apparmor_profile\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$apparmor_profile" ]] && [[ "$apparmor_profile" != '""' ]]; then
    register_check "AppArmor profile" PASS "$apparmor_profile"
  else
    register_check "AppArmor profile" PASS "crio-default (implicit)"
  fi
fi

# Check if AppArmor is enabled on system
if command -v aa-status >/dev/null 2>&1; then
  if aa-status 2>/dev/null | grep -qi "crio\|container"; then
    register_check "AppArmor system" PASS "profiles loaded"
  fi
fi

section "SELinux Configuration"

if command -v getenforce >/dev/null 2>&1; then
  selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
  if [[ "$selinux_mode" == "Enforcing" ]]; then
    register_check "SELinux mode" PASS "Enforcing"

    # Check selinux setting in config
    if [[ -f "$config_file" ]]; then
      if grep -qE "^selinux\s*=\s*true" "$config_file" 2>/dev/null; then
        register_check "SELinux in CRI-O" PASS "enabled"
      fi
    fi
  elif [[ "$selinux_mode" == "Permissive" ]]; then
    register_check "SELinux mode" WARN "Permissive"
  else
    register_check "SELinux mode" SKIP "not available"
  fi
fi

section "Image Signature Policy"

# Check signature policy
policy_file="/etc/containers/policy.json"
if [[ -f "$policy_file" ]]; then
  register_check "Signature policy" PASS "exists"

  # Check policy content
  if grep -q '"type":\s*"insecureAcceptAnything"' "$policy_file" 2>/dev/null; then
    # Check if it's only for default or specific registries
    if grep -q '"default"' "$policy_file" 2>/dev/null; then
      register_check "Default policy" WARN "insecureAcceptAnything"
    fi
  elif grep -q '"type":\s*"signedBy"' "$policy_file" 2>/dev/null; then
    register_check "Signature verification" PASS "required"
  elif grep -q '"type":\s*"reject"' "$policy_file" 2>/dev/null; then
    register_check "Default policy" PASS "reject (whitelist mode)"
  fi
else
  register_check "Signature policy" WARN "not found"
fi

section "Registry Configuration"

# Check registries.conf
registries_conf="/etc/containers/registries.conf"
if [[ -f "$registries_conf" ]]; then
  register_check "Registries config" PASS "exists"

  # Check for insecure registries
  if grep -qE "^\s*insecure\s*=\s*true" "$registries_conf" 2>/dev/null; then
    insecure_count=$(grep -cE "^\s*insecure\s*=\s*true" "$registries_conf" 2>/dev/null || echo "0")
    register_check "Insecure registries" WARN "$insecure_count configured"
  else
    register_check "Insecure registries" PASS "none"
  fi

  # Check for blocked registries
  if grep -qE "^\[\[registry\.block\]\]" "$registries_conf" 2>/dev/null; then
    register_check "Blocked registries" PASS "configured"
  fi
else
  register_check "Registries config" WARN "not found"
fi

section "Storage Configuration"

# Check storage
if [[ -f "$config_file" ]]; then
  # Storage driver
  storage_driver=$(grep -E "^storage_driver\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$storage_driver" ]]; then
    if [[ "$storage_driver" == "overlay" ]]; then
      register_check "Storage driver" PASS "overlay (recommended)"
    else
      register_check "Storage driver" PASS "$storage_driver"
    fi
  fi

  # Root directory
  root_dir=$(grep -E "^root\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$root_dir" ]] && [[ -d "$root_dir" ]]; then
    perms=$(stat -c "%a" "$root_dir" 2>/dev/null || echo "unknown")
    register_check "Storage root" PASS "$root_dir ($perms)"
  fi
fi

section "Network Configuration"

# Check CNI
if [[ -f "$config_file" ]]; then
  cni_default=$(grep -E "^cni_default_network\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$cni_default" ]]; then
    register_check "CNI default network" PASS "$cni_default"
  fi

  network_dir=$(grep -E "^network_dir\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$network_dir" ]] && [[ -d "$network_dir" ]]; then
    register_check "CNI config dir" PASS "$network_dir"
  fi
fi

# Check CNI plugins
cni_plugin_dirs=(
  "/opt/cni/bin"
  "/usr/libexec/cni"
  "/usr/lib/cni"
)

for dir in "${cni_plugin_dirs[@]}"; do
  if [[ -d "$dir" ]]; then
    plugin_count=$(find "$dir" -type f -executable 2>/dev/null | wc -l || echo "0")
    if [[ "$plugin_count" -gt 0 ]]; then
      register_check "CNI plugins" PASS "$plugin_count in $dir"
      break
    fi
  fi
done

section "Socket and API"

# Check CRI-O socket
socket_path="/var/run/crio/crio.sock"
if [[ -S "$socket_path" ]]; then
  perms=$(stat -c "%a" "$socket_path" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$socket_path" 2>/dev/null || echo "unknown")

  if [[ "$perms" == "660" ]] || [[ "$perms" == "600" ]]; then
    register_check "Socket permissions" PASS "$perms $owner"
  else
    register_check "Socket permissions" WARN "$perms $owner"
  fi
else
  register_check "Socket" WARN "not found at $socket_path"
fi

section "Image Settings"

if [[ -f "$config_file" ]]; then
  # Check pause image
  pause_image=$(grep -E "^pause_image\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$pause_image" ]]; then
    register_check "Pause image" PASS "$pause_image"
  fi

  # Check image volumes
  image_volumes=$(grep -E "^image_volumes\s*=" "$config_file" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$image_volumes" ]]; then
    if [[ "$image_volumes" == "mkdir" ]]; then
      register_check "Image volumes" PASS "mkdir (safe)"
    elif [[ "$image_volumes" == "bind" ]]; then
      register_check "Image volumes" WARN "bind (less secure)"
    else
      register_check "Image volumes" PASS "$image_volumes"
    fi
  fi
fi

section "Resource Management"

if [[ -f "$config_file" ]]; then
  # Check pids limit
  pids_limit=$(grep -E "^pids_limit\s*=" "$config_file" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ -n "$pids_limit" ]] && [[ "$pids_limit" -gt 0 ]]; then
    register_check "PIDs limit" PASS "$pids_limit"
  fi

  # Check log size max
  log_size_max=$(grep -E "^log_size_max\s*=" "$config_file" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ')
  if [[ -n "$log_size_max" ]] && [[ "$log_size_max" -gt 0 ]]; then
    register_check "Log size limit" PASS "$log_size_max bytes"
  fi
fi

section "Namespaces"

if [[ -f "$config_file" ]]; then
  # Check manage network ns lifecycle
  if grep -qE "manage_ns_lifecycle\s*=\s*true" "$config_file" 2>/dev/null; then
    register_check "Manage NS lifecycle" PASS "enabled"
  fi

  # Check drop capabilities
  if grep -qE "default_capabilities\s*=" "$config_file" 2>/dev/null; then
    register_check "Default capabilities" PASS "customized"
  fi
fi

section "crictl Check"

# Use crictl if available to check running state
if command -v crictl >/dev/null 2>&1; then
  export CONTAINER_RUNTIME_ENDPOINT=unix:///var/run/crio/crio.sock

  # Get running pods
  pod_count=$(crictl pods -q 2>/dev/null | wc -l || echo "0")
  if [[ "$pod_count" -gt 0 ]]; then
    register_check "Running pods" PASS "$pod_count"
  fi

  # Get running containers
  container_count=$(crictl ps -q 2>/dev/null | wc -l || echo "0")
  if [[ "$container_count" -gt 0 ]]; then
    register_check "Running containers" PASS "$container_count"
  fi
fi

print_summary
exit "$EXIT_CODE"
