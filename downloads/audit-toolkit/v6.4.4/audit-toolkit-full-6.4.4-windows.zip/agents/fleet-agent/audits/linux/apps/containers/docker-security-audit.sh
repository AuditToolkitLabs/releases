#!/usr/bin/env bash
# =============================================================================
# Docker Security Audit - CIS Docker Benchmark v1.7.0 Aligned
# =============================================================================
# Version: 5.0.0
# Compliance: CIS Docker Benchmark v1.7.0, NIST SP 800-190, PCI DSS
#
# CIS Docker Benchmark Sections Covered:
#   1.x  - Host Configuration
#   2.x  - Docker Daemon Configuration
#   3.x  - Docker Daemon Configuration Files
#   4.x  - Container Images and Build File
#   5.x  - Container Runtime Configuration
#   6.x  - Docker Security Operations
#   7.x  - Docker Swarm Configuration
# =============================================================================
#
# @elevation: partial
# @elevation-reason: docker group membership or root needed for socket access
#
set -euo pipefail

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source libraries
. "$SCRIPT_DIR/../../../lib/common.sh"
. "$SCRIPT_DIR/../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../lib/svc.sh"
. "$SCRIPT_DIR/../../../lib/pkg.sh"

# Docker paths
DOCKER_SOCKET="/var/run/docker.sock"
DAEMON_JSON="/etc/docker/daemon.json"
DOCKER_SERVICE="/usr/lib/systemd/system/docker.service"
DOCKER_SOCKET_SERVICE="/usr/lib/systemd/system/docker.socket"

# Cache variables for performance
DOCKER_INFO=""
DOCKER_VERSION=""
DOCKER_CONTAINERS=""
DOCKER_IMAGES=""
DOCKER_NETWORKS=""
DOCKER_VOLUMES=""
DAEMON_JSON_CONTENT=""

# -----------------------------------------------------------------------------
# Helper functions with caching
# -----------------------------------------------------------------------------
get_docker_info() {
  if [[ -z "$DOCKER_INFO" ]]; then
    DOCKER_INFO=$(docker info 2>/dev/null || echo "")
  fi
  echo "$DOCKER_INFO"
}

get_docker_version() {
  if [[ -z "$DOCKER_VERSION" ]]; then
    DOCKER_VERSION=$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo "unknown")
  fi
  echo "$DOCKER_VERSION"
}

get_docker_containers() {
  if [[ -z "$DOCKER_CONTAINERS" ]]; then
    DOCKER_CONTAINERS=$(docker ps --format '{{.ID}}|{{.Image}}|{{.Names}}|{{.Status}}' 2>/dev/null || echo "")
  fi
  echo "$DOCKER_CONTAINERS"
}

get_docker_images() {
  if [[ -z "$DOCKER_IMAGES" ]]; then
    DOCKER_IMAGES=$(docker images --format '{{.Repository}}:{{.Tag}}|{{.ID}}|{{.Size}}' 2>/dev/null || echo "")
  fi
  echo "$DOCKER_IMAGES"
}

get_docker_networks() {
  if [[ -z "$DOCKER_NETWORKS" ]]; then
    DOCKER_NETWORKS=$(docker network ls --format '{{.Name}}|{{.Driver}}|{{.Scope}}' 2>/dev/null || echo "")
  fi
  echo "$DOCKER_NETWORKS"
}

get_docker_volumes() {
  if [[ -z "$DOCKER_VOLUMES" ]]; then
    DOCKER_VOLUMES=$(docker volume ls --format '{{.Name}}|{{.Driver}}' 2>/dev/null || echo "")
  fi
  echo "$DOCKER_VOLUMES"
}

get_daemon_json() {
  if [[ -z "$DAEMON_JSON_CONTENT" ]]; then
    if [[ -f "$DAEMON_JSON" ]]; then
      DAEMON_JSON_CONTENT=$(cat "$DAEMON_JSON" 2>/dev/null || echo "")
    fi
  fi
  echo "$DAEMON_JSON_CONTENT"
}

get_json_value() {
  local json="$1"
  local key="$2"
  echo "$json" | grep -oP "\"$key\"\s*:\s*\K[^,}]+" | tr -d '"' | head -n1
}

check_file_ownership() {
  local file="$1"
  local expected_user="${2:-root}"
  local expected_group="${3:-root}"

  if [[ -f "$file" ]] || [[ -S "$file" ]]; then
    local owner
    owner=$(stat -c "%U:%G" "$file" 2>/dev/null || stat -f "%Su:%Sg" "$file" 2>/dev/null)
    if [[ "$owner" == "$expected_user:$expected_group" ]]; then
      return 0
    fi
  fi
  return 1
}

check_file_permissions() {
  local file="$1"
  local max_perms="$2"  # e.g., 644

  if [[ -f "$file" ]] || [[ -S "$file" ]]; then
    local perms
    perms=$(stat -c "%a" "$file" 2>/dev/null || stat -f "%Lp" "$file" 2>/dev/null)
    # Simple check - could be enhanced for proper octal comparison
    if [[ "$perms" -le "$max_perms" ]]; then
      return 0
    fi
  fi
  return 1
}

# -----------------------------------------------------------------------------
# Usage
# -----------------------------------------------------------------------------
usage() {
  cat << EOF
Docker Security Audit - CIS Docker Benchmark v1.7.0 Aligned

Usage: $(basename "$0") [OPTIONS]

Options:
  -h, --help     Show this help message
  -v, --verbose  Enable verbose output

CIS Docker Benchmark v1.7.0 Sections:
  1.x  Host Configuration
       - Separate partition for containers
       - Hardened container host
       - Docker version updates
       - Only necessary packages

  2.x  Docker Daemon Configuration
       - Restrict network traffic between containers
       - Logging configuration
       - Docker socket exposure
       - TLS authentication
       - User namespace support
       - Default ulimit configurations
       - Authorization plugins
       - Live restore
       - Disable userland proxy
       - No experimental features
       - Container network restrictions

  3.x  Docker Daemon Configuration Files
       - docker.service file ownership/permissions
       - docker.socket file ownership/permissions
       - daemon.json ownership/permissions
       - TLS certificate files
       - Docker directories

  4.x  Container Images and Build File
       - Base image trust
       - Content trust enforcement
       - HEALTHCHECK instructions
       - Root user restrictions
       - Secrets in Dockerfiles

  5.x  Container Runtime Configuration
       - AppArmor/SELinux profiles
       - Privileged mode restrictions
       - Sensitive host directories
       - SSH in containers
       - Network restrictions
       - Memory/CPU limits
       - PIDs limit
       - Read-only root filesystem

  6.x  Docker Security Operations
       - Image vulnerability scanning
       - Secrets management
       - Security event logging
       - Host firewall rules

  7.x  Docker Swarm Configuration
       - Minimum manager nodes
       - Swarm mode security
       - Node certificate rotation
       - CA constraints

Compliance: NIST SP 800-190, PCI DSS v4.0
Reference: CIS Docker Benchmark v1.7.0
EOF
  exit 0
}

# Parse arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage ;;
    -v|--verbose) VERBOSE=1; shift ;;
    *) shift ;;
  esac
done

# -----------------------------------------------------------------------------
# Audit Start
# -----------------------------------------------------------------------------
section "System Information"
register_check "Audit Version" PASS "5.0.0 (CIS Docker Benchmark v1.7.0)"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check Docker is installed
if ! command -v docker >/dev/null 2>&1; then
  register_check "Docker Installation" FAIL "Docker not installed"
  print_summary
  exit "$EXIT_CODE"
fi

# Check Docker daemon is running
if ! docker info >/dev/null 2>&1; then
  register_check "Docker Daemon" FAIL "Docker daemon not running or not accessible"
  print_summary
  exit "$EXIT_CODE"
fi

docker_version=$(get_docker_version)
register_check "Docker Version" PASS "$docker_version"

# =============================================================================
# CIS 1.x - Host Configuration
# =============================================================================
section "CIS 1.x - Host Configuration"

# CIS 1.1.1 - Ensure a separate partition for containers has been created
if mount | grep -q "/var/lib/docker"; then
  register_check "CIS 1.1.1: Docker partition" PASS "Separate partition for /var/lib/docker"
else
  register_check "CIS 1.1.1: Docker partition" WARN "No separate partition for /var/lib/docker"
fi

# CIS 1.1.2 - Ensure only trusted users are allowed to control Docker daemon
docker_group_members=$(getent group docker 2>/dev/null | cut -d: -f4 || echo "")
if [[ -n "$docker_group_members" ]]; then
  register_check "CIS 1.1.2: Docker group" WARN "Users in docker group: $docker_group_members"
else
  register_check "CIS 1.1.2: Docker group" PASS "No non-root users in docker group"
fi

# CIS 1.1.3 - Audit Docker daemon
if command -v auditctl >/dev/null 2>&1; then
  if auditctl -l 2>/dev/null | grep -q "/usr/bin/docker"; then
    register_check "CIS 1.1.3: Audit docker daemon" PASS "Audit rules for docker daemon"
  else
    register_check "CIS 1.1.3: Audit docker daemon" WARN "No audit rules for docker daemon"
  fi
else
  register_check "CIS 1.1.3: Audit docker daemon" SKIP "auditctl not available"
fi

# CIS 1.1.4-1.1.18 - Audit various Docker files
audit_files=(
  "/var/lib/docker"
  "/etc/docker"
  "$DAEMON_JSON"
  "/etc/default/docker"
  "/etc/sysconfig/docker"
  "$DOCKER_SERVICE"
  "$DOCKER_SOCKET_SERVICE"
  "$DOCKER_SOCKET"
)

for file in "${audit_files[@]}"; do
  if [[ -e "$file" ]]; then
    if command -v auditctl >/dev/null 2>&1 && auditctl -l 2>/dev/null | grep -q "$file"; then
      register_check "CIS 1.1.x: Audit $file" PASS "Audit rules present"
    else
      register_check "CIS 1.1.x: Audit $file" WARN "No audit rules for $file"
    fi
  fi
done

# CIS 1.2.1 - Ensure Docker version is up to date
# Get major version
major_version=$(echo "$docker_version" | cut -d. -f1)
if [[ "$major_version" -ge 24 ]]; then
  register_check "CIS 1.2.1: Docker version" PASS "v$docker_version (recent version)"
elif [[ "$major_version" -ge 20 ]]; then
  register_check "CIS 1.2.1: Docker version" WARN "v$docker_version (consider updating)"
else
  register_check "CIS 1.2.1: Docker version" FAIL "v$docker_version (outdated - update immediately)"
fi

# =============================================================================
# CIS 2.x - Docker Daemon Configuration
# =============================================================================
section "CIS 2.x - Docker Daemon Configuration"

daemon_json=$(get_daemon_json)
docker_info=$(get_docker_info)

# CIS 2.1 - Run the Docker daemon as a non-root user, if possible
if echo "$docker_info" | grep -q "rootless"; then
  register_check "CIS 2.1: Rootless mode" PASS "Running in rootless mode"
else
  register_check "CIS 2.1: Rootless mode" WARN "Docker daemon running as root"
fi

# CIS 2.2 - Ensure network traffic is restricted between containers
if [[ -n "$daemon_json" ]]; then
  icc=$(get_json_value "$daemon_json" "icc")
  if [[ "$icc" == "false" ]]; then
    register_check "CIS 2.2: Inter-container communication" PASS "ICC disabled"
  else
    register_check "CIS 2.2: Inter-container communication" WARN "ICC enabled (containers can communicate freely)"
  fi
else
  register_check "CIS 2.2: Inter-container communication" WARN "daemon.json not found - ICC enabled by default"
fi

# CIS 2.3 - Ensure the logging level is set to 'info'
log_level=$(get_json_value "$daemon_json" "log-level")
if [[ "$log_level" == "info" ]] || [[ -z "$log_level" ]]; then
  register_check "CIS 2.3: Logging level" PASS "Set to info"
else
  register_check "CIS 2.3: Logging level" WARN "Set to $log_level (should be 'info')"
fi

# CIS 2.4 - Ensure Docker is allowed to make changes to iptables
iptables=$(get_json_value "$daemon_json" "iptables")
if [[ "$iptables" == "false" ]]; then
  register_check "CIS 2.4: iptables" WARN "Docker iptables management disabled"
else
  register_check "CIS 2.4: iptables" PASS "Docker can manage iptables"
fi

# CIS 2.5 - Ensure insecure registries are not used
insecure_registries=$(get_json_value "$daemon_json" "insecure-registries")
if [[ -z "$insecure_registries" ]] || [[ "$insecure_registries" == "[]" ]]; then
  register_check "CIS 2.5: Insecure registries" PASS "No insecure registries configured"
else
  register_check "CIS 2.5: Insecure registries" FAIL "Insecure registries: $insecure_registries"
fi

# CIS 2.6 - Ensure aufs storage driver is not used
storage_driver=$(echo "$docker_info" | grep "Storage Driver:" | awk '{print $3}')
if [[ "$storage_driver" == "aufs" ]]; then
  register_check "CIS 2.6: Storage driver" FAIL "Using aufs (deprecated and insecure)"
elif [[ "$storage_driver" == "overlay2" ]]; then
  register_check "CIS 2.6: Storage driver" PASS "Using $storage_driver"
else
  register_check "CIS 2.6: Storage driver" WARN "Using $storage_driver"
fi

# CIS 2.7 - Ensure TLS authentication for Docker daemon is configured
tls=$(get_json_value "$daemon_json" "tls")
tlsverify=$(get_json_value "$daemon_json" "tlsverify")
if [[ "$tlsverify" == "true" ]]; then
  register_check "CIS 2.7: TLS authentication" PASS "TLS verification enabled"
elif [[ "$tls" == "true" ]]; then
  register_check "CIS 2.7: TLS authentication" WARN "TLS enabled but verify disabled"
else
  register_check "CIS 2.7: TLS authentication" WARN "TLS not configured"
fi

# CIS 2.8 - Ensure the default ulimit is configured appropriately
ulimits=$(get_json_value "$daemon_json" "default-ulimits")
if [[ -n "$ulimits" ]]; then
  register_check "CIS 2.8: Default ulimits" PASS "Custom ulimits configured"
else
  register_check "CIS 2.8: Default ulimits" WARN "Using default ulimits"
fi

# CIS 2.9 - Enable user namespace support
userns_remap=$(get_json_value "$daemon_json" "userns-remap")
if [[ -n "$userns_remap" ]]; then
  register_check "CIS 2.9: User namespace remap" PASS "Enabled: $userns_remap"
else
  register_check "CIS 2.9: User namespace remap" WARN "Not configured - container root = host root"
fi

# CIS 2.10 - Ensure the default cgroup namespace mode is private
cgroup_ns=$(echo "$docker_info" | grep "Cgroup Namespace" | awk '{print $NF}')
if [[ "$cgroup_ns" == "private" ]]; then
  register_check "CIS 2.10: Cgroup namespace" PASS "Private (default)"
else
  register_check "CIS 2.10: Cgroup namespace" WARN "Mode: $cgroup_ns"
fi

# CIS 2.11 - Ensure that authorization for Docker client commands is enabled
auth_plugins=$(echo "$docker_info" | grep "Authorization Plugins" || echo "")
if [[ -n "$auth_plugins" ]] && ! echo "$auth_plugins" | grep -q ": $"; then
  register_check "CIS 2.11: Authorization plugins" PASS "$auth_plugins"
else
  register_check "CIS 2.11: Authorization plugins" WARN "No authorization plugins configured"
fi

# CIS 2.12 - Ensure centralized and remote logging is configured
log_driver=$(get_json_value "$daemon_json" "log-driver")
case "$log_driver" in
  syslog|journald|gelf|fluentd|awslogs|splunk|gcplogs|loki)
    register_check "CIS 2.12: Remote logging" PASS "Configured: $log_driver"
    ;;
  json-file|"")
    register_check "CIS 2.12: Remote logging" WARN "Using local json-file logging"
    ;;
  *)
    register_check "CIS 2.12: Remote logging" WARN "Using: $log_driver"
    ;;
esac

# CIS 2.13 - Ensure live restore is enabled
live_restore=$(get_json_value "$daemon_json" "live-restore")
if [[ "$live_restore" == "true" ]]; then
  register_check "CIS 2.13: Live restore" PASS "Enabled"
else
  register_check "CIS 2.13: Live restore" WARN "Disabled - containers stop with daemon"
fi

# CIS 2.14 - Ensure Userland Proxy is disabled
userland_proxy=$(get_json_value "$daemon_json" "userland-proxy")
if [[ "$userland_proxy" == "false" ]]; then
  register_check "CIS 2.14: Userland proxy" PASS "Disabled (better performance)"
else
  register_check "CIS 2.14: Userland proxy" WARN "Enabled (consider disabling)"
fi

# CIS 2.15 - Ensure that a daemon-wide custom seccomp profile is applied
seccomp_profile=$(get_json_value "$daemon_json" "seccomp-profile")
if [[ -n "$seccomp_profile" ]]; then
  register_check "CIS 2.15: Custom seccomp" PASS "Profile: $seccomp_profile"
else
  register_check "CIS 2.15: Custom seccomp" WARN "Using default seccomp profile"
fi

# CIS 2.16 - Ensure that experimental features are not implemented in production
experimental=$(echo "$docker_info" | grep "Experimental:" | awk '{print $2}')
if [[ "$experimental" == "true" ]]; then
  register_check "CIS 2.16: Experimental features" FAIL "Enabled (not for production)"
else
  register_check "CIS 2.16: Experimental features" PASS "Disabled"
fi

# CIS 2.17 - Ensure containers are restricted from acquiring new privileges
no_new_privs=$(get_json_value "$daemon_json" "no-new-privileges")
if [[ "$no_new_privs" == "true" ]]; then
  register_check "CIS 2.17: No new privileges" PASS "Default enabled"
else
  register_check "CIS 2.17: No new privileges" WARN "Not set - containers can escalate privileges"
fi

# =============================================================================
# CIS 3.x - Docker Daemon Configuration Files
# =============================================================================
section "CIS 3.x - Docker Daemon Configuration Files"

# CIS 3.1-3.2 - docker.service file
if [[ -f "$DOCKER_SERVICE" ]]; then
  if check_file_ownership "$DOCKER_SERVICE" "root" "root"; then
    register_check "CIS 3.1: docker.service ownership" PASS "root:root"
  else
    register_check "CIS 3.1: docker.service ownership" FAIL "Incorrect ownership"
  fi

  svc_perms=$(stat -c "%a" "$DOCKER_SERVICE" 2>/dev/null || echo "")
  if [[ "$svc_perms" -le 644 ]]; then
    register_check "CIS 3.2: docker.service permissions" PASS "$svc_perms"
  else
    register_check "CIS 3.2: docker.service permissions" FAIL "$svc_perms (should be 644 or less)"
  fi
else
  register_check "CIS 3.1-3.2: docker.service" SKIP "File not found"
fi

# CIS 3.3-3.4 - docker.socket file
if [[ -f "$DOCKER_SOCKET_SERVICE" ]]; then
  if check_file_ownership "$DOCKER_SOCKET_SERVICE" "root" "root"; then
    register_check "CIS 3.3: docker.socket ownership" PASS "root:root"
  else
    register_check "CIS 3.3: docker.socket ownership" FAIL "Incorrect ownership"
  fi

  socket_svc_perms=$(stat -c "%a" "$DOCKER_SOCKET_SERVICE" 2>/dev/null || echo "")
  if [[ "$socket_svc_perms" -le 644 ]]; then
    register_check "CIS 3.4: docker.socket permissions" PASS "$socket_svc_perms"
  else
    register_check "CIS 3.4: docker.socket permissions" FAIL "$socket_svc_perms (should be 644 or less)"
  fi
else
  register_check "CIS 3.3-3.4: docker.socket" SKIP "File not found"
fi

# CIS 3.5-3.6 - /etc/docker directory
if [[ -d "/etc/docker" ]]; then
  if check_file_ownership "/etc/docker" "root" "root"; then
    register_check "CIS 3.5: /etc/docker ownership" PASS "root:root"
  else
    register_check "CIS 3.5: /etc/docker ownership" FAIL "Incorrect ownership"
  fi

  etc_docker_perms=$(stat -c "%a" "/etc/docker" 2>/dev/null || echo "")
  if [[ "$etc_docker_perms" -le 755 ]]; then
    register_check "CIS 3.6: /etc/docker permissions" PASS "$etc_docker_perms"
  else
    register_check "CIS 3.6: /etc/docker permissions" FAIL "$etc_docker_perms (should be 755 or less)"
  fi
fi

# CIS 3.7-3.8 - Registry certificate files
cert_dir="/etc/docker/certs.d"
if [[ -d "$cert_dir" ]]; then
  bad_cert_perms=false
  while IFS= read -r -d '' cert; do
    if [[ -f "$cert" ]]; then
      cert_perms=$(stat -c "%a" "$cert" 2>/dev/null || echo "")
      if [[ "$cert_perms" -gt 444 ]]; then
        bad_cert_perms=true
        break
      fi
    fi
  done < <(find "$cert_dir" -type f -print0 2>/dev/null)

  if $bad_cert_perms; then
    register_check "CIS 3.7-3.8: Registry certificates" FAIL "Certificates too permissive"
  else
    register_check "CIS 3.7-3.8: Registry certificates" PASS "Proper permissions"
  fi
else
  register_check "CIS 3.7-3.8: Registry certificates" SKIP "No certificate directory"
fi

# CIS 3.9-3.10 - TLS CA certificate file
tls_cacert="/etc/docker/ca.pem"
if [[ -f "$tls_cacert" ]]; then
  if check_file_ownership "$tls_cacert" "root" "root"; then
    register_check "CIS 3.9: TLS CA ownership" PASS "root:root"
  else
    register_check "CIS 3.9: TLS CA ownership" FAIL "Incorrect ownership"
  fi

  ca_perms=$(stat -c "%a" "$tls_cacert" 2>/dev/null || echo "")
  if [[ "$ca_perms" -le 444 ]]; then
    register_check "CIS 3.10: TLS CA permissions" PASS "$ca_perms"
  else
    register_check "CIS 3.10: TLS CA permissions" FAIL "$ca_perms (should be 444 or less)"
  fi
else
  register_check "CIS 3.9-3.10: TLS CA certificate" SKIP "File not found"
fi

# CIS 3.11-3.14 - TLS server certificate and key
for cert_pair in "server-cert.pem:server-key.pem" "cert.pem:key.pem"; do
  cert_file="/etc/docker/${cert_pair%%:*}"
  key_file="/etc/docker/${cert_pair##*:}"

  if [[ -f "$cert_file" ]]; then
    cert_perms=$(stat -c "%a" "$cert_file" 2>/dev/null || echo "")
    if [[ "$cert_perms" -le 444 ]]; then
      register_check "CIS 3.11-3.12: TLS cert $cert_file" PASS "Permissions: $cert_perms"
    else
      register_check "CIS 3.11-3.12: TLS cert $cert_file" FAIL "Too permissive: $cert_perms"
    fi
  fi

  if [[ -f "$key_file" ]]; then
    key_perms=$(stat -c "%a" "$key_file" 2>/dev/null || echo "")
    if [[ "$key_perms" -le 400 ]]; then
      register_check "CIS 3.13-3.14: TLS key $key_file" PASS "Permissions: $key_perms"
    else
      register_check "CIS 3.13-3.14: TLS key $key_file" FAIL "Too permissive: $key_perms"
    fi
  fi
done

# CIS 3.15-3.16 - Docker socket file
if [[ -S "$DOCKER_SOCKET" ]]; then
  socket_owner=$(stat -c "%U:%G" "$DOCKER_SOCKET" 2>/dev/null || echo "")
  if [[ "$socket_owner" == "root:docker" ]]; then
    register_check "CIS 3.15: Socket ownership" PASS "$socket_owner"
  else
    register_check "CIS 3.15: Socket ownership" FAIL "$socket_owner (expected root:docker)"
  fi

  socket_perms=$(stat -c "%a" "$DOCKER_SOCKET" 2>/dev/null || echo "")
  if [[ "$socket_perms" == "660" ]]; then
    register_check "CIS 3.16: Socket permissions" PASS "$socket_perms"
  elif [[ "$socket_perms" == "666" ]]; then
    register_check "CIS 3.16: Socket permissions" FAIL "$socket_perms - world-writable (CRITICAL)"
  else
    register_check "CIS 3.16: Socket permissions" WARN "$socket_perms (expected 660)"
  fi
else
  register_check "CIS 3.15-3.16: Docker socket" SKIP "Socket not found"
fi

# CIS 3.17-3.18 - daemon.json file
if [[ -f "$DAEMON_JSON" ]]; then
  if check_file_ownership "$DAEMON_JSON" "root" "root"; then
    register_check "CIS 3.17: daemon.json ownership" PASS "root:root"
  else
    register_check "CIS 3.17: daemon.json ownership" FAIL "Incorrect ownership"
  fi

  daemon_perms=$(stat -c "%a" "$DAEMON_JSON" 2>/dev/null || echo "")
  if [[ "$daemon_perms" -le 644 ]]; then
    register_check "CIS 3.18: daemon.json permissions" PASS "$daemon_perms"
  else
    register_check "CIS 3.18: daemon.json permissions" FAIL "$daemon_perms (should be 644 or less)"
  fi
else
  register_check "CIS 3.17-3.18: daemon.json" WARN "File not found - using defaults"
fi

# CIS 3.19-3.20 - /etc/default/docker or /etc/sysconfig/docker
for config in "/etc/default/docker" "/etc/sysconfig/docker"; do
  if [[ -f "$config" ]]; then
    if check_file_ownership "$config" "root" "root"; then
      register_check "CIS 3.19-3.20: $config" PASS "Correct ownership and exists"
    else
      register_check "CIS 3.19-3.20: $config" FAIL "Incorrect ownership"
    fi
  fi
done

# CIS 3.21-3.22 - Containerd socket file
containerd_socket="/run/containerd/containerd.sock"
if [[ -S "$containerd_socket" ]]; then
  containerd_owner=$(stat -c "%U:%G" "$containerd_socket" 2>/dev/null || echo "")
  containerd_perms=$(stat -c "%a" "$containerd_socket" 2>/dev/null || echo "")
  if [[ "$containerd_owner" == "root:root" ]] && [[ "$containerd_perms" -le 660 ]]; then
    register_check "CIS 3.21-3.22: Containerd socket" PASS "$containerd_owner, $containerd_perms"
  else
    register_check "CIS 3.21-3.22: Containerd socket" WARN "$containerd_owner, $containerd_perms"
  fi
fi

# =============================================================================
# CIS 4.x - Container Images and Build File
# =============================================================================
section "CIS 4.x - Container Images and Build File"

images=$(get_docker_images)

# CIS 4.1 - Ensure that a user for the container has been created
if [[ -n "$images" ]]; then
  image_count=$(echo "$images" | wc -l)
  register_check "CIS 4.1: Images found" PASS "$image_count images"

  # Sample check on first few images
  checked=0
  while IFS='|' read -r image _id _size; do
    [[ $checked -ge 5 ]] && break

    user=$(docker inspect "$image" --format '{{.Config.User}}' 2>/dev/null || echo "")
    if [[ -z "$user" ]] || [[ "$user" == "root" ]] || [[ "$user" == "0" ]]; then
      register_check "CIS 4.1: Image user: $image" WARN "No non-root user defined"
    else
      register_check "CIS 4.1: Image user: $image" PASS "User: $user"
    fi
    ((checked++))
  done <<< "$images"
else
  register_check "CIS 4.x: Images" SKIP "No images found"
fi

# CIS 4.2 - Ensure that containers use only trusted base images
# (Manual check - provide guidance)
register_check "CIS 4.2: Trusted base images" WARN "Manual review required - verify base images"

# CIS 4.3 - Ensure that unnecessary packages are not installed
register_check "CIS 4.3: Minimal images" WARN "Manual review - use minimal base images (alpine, distroless)"

# CIS 4.4 - Ensure images are scanned for vulnerabilities
if command -v trivy >/dev/null 2>&1; then
  register_check "CIS 4.4: Vulnerability scanner" PASS "trivy installed"
elif command -v grype >/dev/null 2>&1; then
  register_check "CIS 4.4: Vulnerability scanner" PASS "grype installed"
elif command -v clair >/dev/null 2>&1; then
  register_check "CIS 4.4: Vulnerability scanner" PASS "clair installed"
else
  register_check "CIS 4.4: Vulnerability scanner" WARN "No scanner installed (trivy, grype, clair)"
fi

# CIS 4.5 - Ensure Content trust for Docker is enabled
if [[ "${DOCKER_CONTENT_TRUST:-}" == "1" ]]; then
  register_check "CIS 4.5: Content trust" PASS "DOCKER_CONTENT_TRUST=1"
else
  register_check "CIS 4.5: Content trust" WARN "DOCKER_CONTENT_TRUST not enabled"
fi

# CIS 4.6 - Ensure that HEALTHCHECK instructions have been added
if [[ -n "$images" ]]; then
  health_missing=0
  checked=0
  while IFS='|' read -r image _id _size; do
    [[ $checked -ge 5 ]] && break

    healthcheck=$(docker inspect "$image" --format '{{.Config.Healthcheck}}' 2>/dev/null || echo "")
    if [[ -z "$healthcheck" ]] || [[ "$healthcheck" == "<nil>" ]]; then
      ((health_missing++))
    fi
    ((checked++))
  done <<< "$images"

  if [[ $health_missing -gt 0 ]]; then
    register_check "CIS 4.6: HEALTHCHECK" WARN "$health_missing of $checked sampled images missing HEALTHCHECK"
  else
    register_check "CIS 4.6: HEALTHCHECK" PASS "Sampled images have HEALTHCHECK"
  fi
fi

# CIS 4.7 - Ensure update instructions are not used alone
register_check "CIS 4.7: Update instructions" WARN "Manual review - avoid standalone 'apt update' in Dockerfiles"

# CIS 4.8 - Ensure setuid and setgid permissions are removed
register_check "CIS 4.8: SUID/SGID" WARN "Manual review - remove setuid/setgid bits in images"

# CIS 4.9 - Ensure that COPY is used instead of ADD
register_check "CIS 4.9: COPY vs ADD" WARN "Manual review - prefer COPY over ADD in Dockerfiles"

# CIS 4.10 - Ensure secrets are not stored in Dockerfiles
register_check "CIS 4.10: Secrets in Dockerfiles" WARN "Manual review - use Docker secrets, not hardcoded values"

# CIS 4.11 - Ensure only verified packages are installed
register_check "CIS 4.11: Package verification" WARN "Manual review - verify package sources in Dockerfiles"

# CIS 4.12 - Ensure all signed artifacts are validated
if command -v notary >/dev/null 2>&1; then
  register_check "CIS 4.12: Notary" PASS "Installed for signature verification"
else
  register_check "CIS 4.12: Notary" SKIP "Not installed"
fi

# Check for :latest tags
if [[ -n "$images" ]]; then
  latest_count=$(echo "$images" | grep -c ":latest" || echo "0")
  if [[ "$latest_count" -gt 0 ]]; then
    register_check "CIS 4.x: Image tags" WARN "$latest_count images with ':latest' tag - not reproducible"
  else
    register_check "CIS 4.x: Image tags" PASS "No ':latest' tags - good versioning"
  fi
fi

# Check for dangling images
dangling_count=$(docker images -f "dangling=true" -q 2>/dev/null | wc -l)
if [[ "$dangling_count" -gt 0 ]]; then
  register_check "CIS 4.x: Dangling images" WARN "$dangling_count dangling images - run 'docker image prune'"
else
  register_check "CIS 4.x: Dangling images" PASS "No dangling images"
fi

# =============================================================================
# CIS 5.x - Container Runtime Configuration
# =============================================================================
section "CIS 5.x - Container Runtime Configuration"

containers=$(get_docker_containers)

if [[ -z "$containers" ]]; then
  register_check "CIS 5.x: Running containers" SKIP "No running containers to audit"
else
  container_count=$(echo "$containers" | wc -l)
  register_check "CIS 5.x: Running containers" PASS "$container_count containers"

  # Limit analysis for performance
  analyzed=0
  while IFS='|' read -r container_id _image name _status; do
    [[ $analyzed -ge 10 ]] && break

    inspect=$(docker inspect "$container_id" 2>/dev/null)

    # CIS 5.1 - Ensure that AppArmor profile is set appropriately
    apparmor=$(echo "$inspect" | grep -oP '"AppArmorProfile":\s*"\K[^"]+' || echo "")
    if [[ -n "$apparmor" ]] && [[ "$apparmor" != "unconfined" ]]; then
      register_check "CIS 5.1: AppArmor: $name" PASS "$apparmor"
    else
      register_check "CIS 5.1: AppArmor: $name" WARN "Not set or unconfined"
    fi

    # CIS 5.2 - Ensure that SELinux security options are set
    selinux=$(echo "$inspect" | grep -oP '"SecurityOpt":\s*\[\K[^\]]+' | grep -i selinux || echo "")
    if [[ -n "$selinux" ]]; then
      register_check "CIS 5.2: SELinux: $name" PASS "SELinux options set"
    else
      register_check "CIS 5.2: SELinux: $name" SKIP "No SELinux options"
    fi

    # CIS 5.3 - Ensure that Linux Kernel capabilities are restricted
    cap_add=$(echo "$inspect" | grep -oP '"CapAdd":\s*\[\K[^\]]*' || echo "")
    cap_drop=$(echo "$inspect" | grep -oP '"CapDrop":\s*\[\K[^\]]*' || echo "")
    if [[ -n "$cap_add" ]] && [[ "$cap_add" != "null" ]]; then
      register_check "CIS 5.3: Capabilities: $name" WARN "Added caps: $cap_add"
    elif [[ -z "$cap_drop" ]] || [[ "$cap_drop" == "null" ]]; then
      register_check "CIS 5.3: Capabilities: $name" WARN "No capabilities dropped"
    else
      register_check "CIS 5.3: Capabilities: $name" PASS "Caps dropped"
    fi

    # CIS 5.4 - Ensure that privileged containers are not used
    privileged=$(echo "$inspect" | grep -oP '"Privileged":\s*\K(true|false)' || echo "false")
    if [[ "$privileged" == "true" ]]; then
      register_check "CIS 5.4: Privileged: $name" FAIL "Running in privileged mode - CRITICAL"
    else
      register_check "CIS 5.4: Privileged: $name" PASS "Not privileged"
    fi

    # CIS 5.5 - Ensure sensitive host directories are not mounted
    mounts=$(docker inspect "$container_id" --format '{{range .Mounts}}{{.Source}}:{{end}}' 2>/dev/null || echo "")
    sensitive_mounts=false
    for sensitive_dir in "/" "/boot" "/dev" "/etc" "/lib" "/proc" "/sys" "/usr"; do
      if echo "$mounts" | grep -qE "(^|:)${sensitive_dir}:"; then
        register_check "CIS 5.5: Sensitive mount: $name" FAIL "Mounts $sensitive_dir"
        sensitive_mounts=true
        break
      fi
    done
    if ! $sensitive_mounts; then
      # Check for docker.sock mount
      if echo "$mounts" | grep -q "/var/run/docker.sock"; then
        register_check "CIS 5.5: Docker sock: $name" FAIL "Docker socket mounted - CRITICAL"
      fi
    fi

    # CIS 5.6 - Ensure sshd is not run within containers
    # (Runtime check - would need to exec into container)

    # CIS 5.7 - Ensure privileged ports are not mapped
    ports=$(docker inspect "$container_id" --format '{{range $p, $conf := .NetworkSettings.Ports}}{{$p}}->{{(index $conf 0).HostPort}}{{" "}}{{end}}' 2>/dev/null || echo "")
    priv_port_found=false
    for port in $ports; do
      host_port=$(echo "$port" | grep -oP '->(\d+)' | tr -d '>')
      if [[ -n "$host_port" ]] && [[ "$host_port" -lt 1024 ]]; then
        register_check "CIS 5.7: Privileged port: $name" WARN "Maps to host port $host_port"
        priv_port_found=true
        break
      fi
    done

    # CIS 5.8 - Ensure that only needed ports are open
    port_count=$(echo "$ports" | wc -w)
    if [[ $port_count -gt 5 ]]; then
      register_check "CIS 5.8: Open ports: $name" WARN "$port_count ports exposed"
    fi

    # CIS 5.9 - Ensure that the host's network namespace is not shared
    network_mode=$(echo "$inspect" | grep -oP '"NetworkMode":\s*"\K[^"]+' || echo "")
    if [[ "$network_mode" == "host" ]]; then
      register_check "CIS 5.9: Network mode: $name" FAIL "Using host network"
    else
      register_check "CIS 5.9: Network mode: $name" PASS "Isolated: $network_mode"
    fi

    # CIS 5.10 - Ensure that the memory usage is limited
    memory=$(echo "$inspect" | grep -oP '"Memory":\s*\K\d+' || echo "0")
    if [[ "$memory" == "0" ]]; then
      register_check "CIS 5.10: Memory limit: $name" WARN "No memory limit"
    else
      mem_mb=$((memory / 1024 / 1024))
      register_check "CIS 5.10: Memory limit: $name" PASS "${mem_mb}MB"
    fi

    # CIS 5.11 - Ensure that CPU priority is set appropriately
    cpu_shares=$(echo "$inspect" | grep -oP '"CpuShares":\s*\K\d+' || echo "0")
    if [[ "$cpu_shares" == "0" ]] || [[ "$cpu_shares" == "1024" ]]; then
      register_check "CIS 5.11: CPU shares: $name" WARN "Default CPU shares"
    else
      register_check "CIS 5.11: CPU shares: $name" PASS "$cpu_shares"
    fi

    # CIS 5.12 - Ensure that the container's root filesystem is read-only
    readonly_fs=$(echo "$inspect" | grep -oP '"ReadonlyRootfs":\s*\K(true|false)' || echo "false")
    if [[ "$readonly_fs" == "true" ]]; then
      register_check "CIS 5.12: Read-only FS: $name" PASS "Root filesystem is read-only"
    else
      register_check "CIS 5.12: Read-only FS: $name" WARN "Root filesystem is writable"
    fi

    # CIS 5.13 - Ensure that incoming traffic is bound to a specific host interface
    # Checked via port bindings

    # CIS 5.14 - Ensure that 'on-failure' container restart policy is set to '5'
    restart_policy=$(echo "$inspect" | grep -oP '"RestartPolicy":\s*\{[^}]+\}' || echo "")
    max_retry=$(echo "$restart_policy" | grep -oP '"MaximumRetryCount":\s*\K\d+' || echo "0")
    if [[ "$max_retry" -gt 0 ]] && [[ "$max_retry" -le 5 ]]; then
      register_check "CIS 5.14: Restart policy: $name" PASS "MaxRetry: $max_retry"
    else
      register_check "CIS 5.14: Restart policy: $name" WARN "MaxRetry: $max_retry (recommended: 5)"
    fi

    # CIS 5.15 - Ensure that the host's process namespace is not shared
    pid_mode=$(echo "$inspect" | grep -oP '"PidMode":\s*"\K[^"]*' || echo "")
    if [[ "$pid_mode" == "host" ]]; then
      register_check "CIS 5.15: PID namespace: $name" FAIL "Sharing host PID namespace"
    else
      register_check "CIS 5.15: PID namespace: $name" PASS "Isolated"
    fi

    # CIS 5.16 - Ensure that the host's IPC namespace is not shared
    ipc_mode=$(echo "$inspect" | grep -oP '"IpcMode":\s*"\K[^"]*' || echo "")
    if [[ "$ipc_mode" == "host" ]]; then
      register_check "CIS 5.16: IPC namespace: $name" FAIL "Sharing host IPC namespace"
    else
      register_check "CIS 5.16: IPC namespace: $name" PASS "Isolated"
    fi

    # CIS 5.17 - Ensure that host devices are not directly exposed
    devices=$(echo "$inspect" | grep -oP '"Devices":\s*\[\K[^\]]*' || echo "")
    if [[ -n "$devices" ]] && [[ "$devices" != "null" ]]; then
      register_check "CIS 5.17: Devices: $name" WARN "Host devices exposed"
    fi

    # CIS 5.20 - Ensure that the host's UTS namespace is not shared
    uts_mode=$(echo "$inspect" | grep -oP '"UTSMode":\s*"\K[^"]*' || echo "")
    if [[ "$uts_mode" == "host" ]]; then
      register_check "CIS 5.20: UTS namespace: $name" FAIL "Sharing host UTS namespace"
    else
      register_check "CIS 5.20: UTS namespace: $name" PASS "Isolated"
    fi

    # CIS 5.21 - Ensure the default seccomp profile is not disabled
    seccomp_opt=$(echo "$inspect" | grep -oP '"SecurityOpt":\s*\[\K[^\]]*' || echo "")
    if echo "$seccomp_opt" | grep -qi "seccomp=unconfined"; then
      register_check "CIS 5.21: Seccomp: $name" FAIL "Seccomp disabled"
    else
      register_check "CIS 5.21: Seccomp: $name" PASS "Seccomp enabled"
    fi

    # CIS 5.25 - Ensure that the container is restricted from acquiring additional privileges
    no_new_privs=$(echo "$inspect" | grep -oP '"NoNewPrivileges":\s*\K(true|false)' || echo "false")
    if [[ "$no_new_privs" == "true" ]]; then
      register_check "CIS 5.25: No new privs: $name" PASS "Enabled"
    else
      register_check "CIS 5.25: No new privs: $name" WARN "Not set"
    fi

    # CIS 5.26 - Ensure that container health is checked at runtime
    health_status=$(docker inspect "$container_id" --format '{{.State.Health.Status}}' 2>/dev/null || echo "none")
    if [[ "$health_status" != "none" ]] && [[ -n "$health_status" ]]; then
      register_check "CIS 5.26: Health check: $name" PASS "Status: $health_status"
    else
      register_check "CIS 5.26: Health check: $name" WARN "No health check configured"
    fi

    # CIS 5.28 - Ensure that the PIDs cgroup limit is used
    pids_limit=$(echo "$inspect" | grep -oP '"PidsLimit":\s*\K-?\d+' || echo "0")
    if [[ "$pids_limit" -gt 0 ]]; then
      register_check "CIS 5.28: PIDs limit: $name" PASS "$pids_limit"
    else
      register_check "CIS 5.28: PIDs limit: $name" WARN "No PIDs limit"
    fi

    # CIS 5.30 - Ensure that the host's user namespaces are not shared
    user_ns=$(echo "$inspect" | grep -oP '"UsernsMode":\s*"\K[^"]*' || echo "")
    if [[ "$user_ns" == "host" ]]; then
      register_check "CIS 5.30: User namespace: $name" FAIL "Sharing host user namespace"
    else
      register_check "CIS 5.30: User namespace: $name" PASS "Isolated"
    fi

    # CIS 5.31 - Ensure that the Docker socket is not mounted inside any containers
    if echo "$mounts" | grep -q "/var/run/docker.sock"; then
      register_check "CIS 5.31: Docker socket: $name" FAIL "Docker socket mounted - container escape risk"
    fi

    ((analyzed++))
  done <<< "$containers"

  if [[ $analyzed -lt $container_count ]]; then
    register_check "CIS 5.x: Analysis limit" WARN "Only analyzed first $analyzed containers (found $container_count)"
  fi
fi

# =============================================================================
# CIS 6.x - Docker Security Operations
# =============================================================================
section "CIS 6.x - Docker Security Operations"

# CIS 6.1 - Ensure that image sprawl is avoided
total_images=$(docker images -q 2>/dev/null | wc -l)
if [[ "$total_images" -gt 50 ]]; then
  register_check "CIS 6.1: Image sprawl" WARN "$total_images images - consider cleanup"
else
  register_check "CIS 6.1: Image sprawl" PASS "$total_images images"
fi

# CIS 6.2 - Ensure that container sprawl is avoided
total_containers=$(docker ps -aq 2>/dev/null | wc -l)
running_containers=$(docker ps -q 2>/dev/null | wc -l)
stopped_containers=$((total_containers - running_containers))
if [[ "$stopped_containers" -gt 10 ]]; then
  register_check "CIS 6.2: Container sprawl" WARN "$stopped_containers stopped containers - consider cleanup"
else
  register_check "CIS 6.2: Container sprawl" PASS "$running_containers running, $stopped_containers stopped"
fi

# Check for dangling volumes
dangling_volumes=$(docker volume ls -qf dangling=true 2>/dev/null | wc -l)
if [[ "$dangling_volumes" -gt 0 ]]; then
  register_check "CIS 6.x: Dangling volumes" WARN "$dangling_volumes - run 'docker volume prune'"
else
  register_check "CIS 6.x: Dangling volumes" PASS "No dangling volumes"
fi

# =============================================================================
# CIS 7.x - Docker Swarm Configuration
# =============================================================================
section "CIS 7.x - Docker Swarm Configuration"

if echo "$docker_info" | grep -q "Swarm: active"; then
  register_check "CIS 7.x: Swarm mode" PASS "Active"

  # CIS 7.1 - Ensure swarm mode is not enabled on a system running as a single container
  # (Optional - depends on use case)

  # CIS 7.2 - Ensure that the minimum number of manager nodes have been created
  managers=$(echo "$docker_info" | grep "Managers:" | awk '{print $2}')
  if [[ -n "$managers" ]]; then
    if [[ "$managers" -ge 3 ]] && [[ "$managers" -le 7 ]]; then
      register_check "CIS 7.2: Manager nodes" PASS "$managers managers (3-7 recommended)"
    elif [[ "$managers" == "1" ]]; then
      register_check "CIS 7.2: Manager nodes" WARN "Only 1 manager - no HA"
    else
      register_check "CIS 7.2: Manager nodes" WARN "$managers managers"
    fi
  fi

  # CIS 7.3 - Ensure that swarm services are bound to a specific host interface
  # Checked via swarm init/join command - manual review
  register_check "CIS 7.3: Swarm interface" WARN "Manual review - verify swarm advertise address"

  # CIS 7.4 - Ensure data exchanged between containers are encrypted on overlay networks
  overlay_networks=$(docker network ls --filter driver=overlay -q 2>/dev/null)
  if [[ -n "$overlay_networks" ]]; then
    encrypted_count=0
    total_overlay=0
    for net in $overlay_networks; do
      ((total_overlay++))
      encrypted=$(docker network inspect "$net" --format '{{.Options}}' 2>/dev/null | grep -c "encrypted" || echo "0")
      if [[ "$encrypted" -gt 0 ]]; then
        ((encrypted_count++))
      fi
    done
    if [[ "$encrypted_count" -eq "$total_overlay" ]] && [[ "$total_overlay" -gt 0 ]]; then
      register_check "CIS 7.4: Overlay encryption" PASS "All $total_overlay overlay networks encrypted"
    else
      register_check "CIS 7.4: Overlay encryption" WARN "$encrypted_count of $total_overlay encrypted"
    fi
  fi

  # CIS 7.5 - Ensure that swarm manager is run in auto-lock mode
  autolock=$(docker swarm unlock-key 2>&1 || echo "")
  if echo "$autolock" | grep -q "SWMKEY"; then
    register_check "CIS 7.5: Swarm auto-lock" PASS "Enabled"
  elif echo "$autolock" | grep -qi "not locked"; then
    register_check "CIS 7.5: Swarm auto-lock" WARN "Not enabled"
  else
    register_check "CIS 7.5: Swarm auto-lock" SKIP "Cannot determine"
  fi

  # CIS 7.6 - Ensure that swarm manager auto-lock key is rotated periodically
  register_check "CIS 7.6: Key rotation" WARN "Manual review - rotate unlock key periodically"

  # CIS 7.7 - Ensure that node certificates are rotated as appropriate
  cert_expiry=$(echo "$docker_info" | grep "CA Configuration:" -A 5 | grep "Expiry Duration" || echo "")
  if [[ -n "$cert_expiry" ]]; then
    register_check "CIS 7.7: Node certificates" PASS "$cert_expiry"
  fi

  # CIS 7.8 - Ensure that CA certificates are rotated as appropriate
  register_check "CIS 7.8: CA certificates" WARN "Manual review - rotate CA certificates"

  # CIS 7.9 - Ensure that management plane traffic is separated from data plane traffic
  register_check "CIS 7.9: Traffic separation" WARN "Manual review - use separate interfaces"

  # Check for secrets
  secrets_count=$(docker secret ls -q 2>/dev/null | wc -l)
  if [[ "$secrets_count" -gt 0 ]]; then
    register_check "CIS 7.x: Swarm secrets" PASS "$secrets_count secrets defined"
  else
    register_check "CIS 7.x: Swarm secrets" WARN "No secrets defined - use for sensitive data"
  fi

  # Check for configs
  configs_count=$(docker config ls -q 2>/dev/null | wc -l)
  if [[ "$configs_count" -gt 0 ]]; then
    register_check "CIS 7.x: Swarm configs" PASS "$configs_count configs defined"
  fi
else
  register_check "CIS 7.x: Swarm mode" SKIP "Not active"
fi

# =============================================================================
# Security Modules
# =============================================================================
section "Security Stack Integration"

# AppArmor
if command -v aa-status >/dev/null 2>&1; then
  if aa-status 2>/dev/null | grep -q "docker"; then
    register_check "AppArmor: Docker profile" PASS "Loaded"
  else
    register_check "AppArmor: Docker profile" WARN "AppArmor active but no Docker profiles"
  fi
elif [[ -f /sys/kernel/security/apparmor/profiles ]]; then
  register_check "AppArmor" WARN "Available but not configured for Docker"
fi

# SELinux
if command -v sestatus >/dev/null 2>&1; then
  selinux_status=$(sestatus 2>/dev/null | grep "SELinux status" | awk '{print $3}')
  selinux_mode=$(sestatus 2>/dev/null | grep "Current mode" | awk '{print $3}')
  if [[ "$selinux_status" == "enabled" ]] && [[ "$selinux_mode" == "enforcing" ]]; then
    register_check "SELinux" PASS "Enabled and enforcing"
  elif [[ "$selinux_status" == "enabled" ]]; then
    register_check "SELinux" WARN "Enabled but not enforcing (mode: $selinux_mode)"
  else
    register_check "SELinux" WARN "Disabled"
  fi
fi

# Security benchmarks tool
if command -v docker-bench-security >/dev/null 2>&1; then
  register_check "docker-bench-security" PASS "Installed - run for detailed CIS audit"
else
  register_check "docker-bench-security" WARN "Not installed - consider for comprehensive audit"
fi

# =============================================================================
# Docker Compose Security (additional best practices)
# =============================================================================
section "Docker Compose Security"

compose_files=$(find /var/www /opt /srv /home -maxdepth 3 \( -name "docker-compose.yml" -o -name "docker-compose.yaml" -o -name "compose.yml" -o -name "compose.yaml" \) 2>/dev/null || echo "")

if [[ -n "$compose_files" ]]; then
  compose_count=$(echo "$compose_files" | wc -l)
  register_check "Compose files found" PASS "$compose_count files"

  while IFS= read -r compose_file; do
    [[ -z "$compose_file" ]] && continue

    # Check for hardcoded secrets
    if grep -qE "(password|secret|key|token|apikey|api_key).*[:=]" "$compose_file" 2>/dev/null; then
      register_check "Secrets: $compose_file" WARN "Potential hardcoded secrets"
    fi

    # Check for privileged mode
    if grep -q "privileged.*true" "$compose_file" 2>/dev/null; then
      register_check "Privileged: $compose_file" FAIL "Privileged containers defined"
    fi

    # Check .env file permissions
    compose_dir=$(dirname "$compose_file")
    if [[ -f "$compose_dir/.env" ]]; then
      env_perms=$(stat -c "%a" "$compose_dir/.env" 2>/dev/null || echo "")
      if [[ "$env_perms" -gt 640 ]]; then
        register_check ".env perms: $compose_dir" FAIL "$env_perms (should be 640 or less)"
      fi
    fi
  done <<< "$compose_files"
else
  register_check "Compose files" SKIP "None found in common locations"
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo "Reference: CIS Docker Benchmark v1.7.0"
echo "Additional: NIST SP 800-190 (Container Security Guide)"

print_summary
exit "$EXIT_CODE"
