#!/usr/bin/env bash
# podman-security-audit.sh — Podman Container Security Audit
#
# Compliance Mapping:
# - CIS Docker Benchmark (applicable sections)
# - NIST SP 800-190 (Container Security)
# - NSA/CISA Kubernetes Hardening Guidance (container runtime)
#
# Checks:
# - Podman installation and version
# - Rootless vs root mode
# - Registry security
# - Storage configuration
# - Seccomp/AppArmor/SELinux
# - Container security settings
#
# @elevation: partial
# @elevation-reason: Rootless podman works without root; root mode needs root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "Podman Container Security Audit"

# Check if podman is installed
if ! command -v podman >/dev/null 2>&1; then
  register_check "Podman installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Podman installed" PASS "found"

section "Podman Version"

# Get version
version=$(podman --version 2>/dev/null | head -1 || echo "")
if [[ -n "$version" ]]; then
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" || echo "$version")
  register_check "Version" PASS "$ver_num"
fi

# Check if version is recent enough for security features
if [[ -n "$ver_num" ]]; then
  major=$(echo "$ver_num" | cut -d. -f1)
  if [[ "$major" -ge 4 ]]; then
    register_check "Version check" PASS "v4+ (current)"
  elif [[ "$major" -ge 3 ]]; then
    register_check "Version check" PASS "v3.x"
  else
    register_check "Version check" WARN "old version, consider upgrade"
  fi
fi

section "Podman Mode (Root vs Rootless)"

# Determine if running rootless
current_user=$(whoami)
if [[ "$current_user" == "root" ]]; then
  register_check "Current mode" WARN "running as root"
else
  register_check "Current mode" PASS "rootless ($current_user)"
fi

# Check for rootless configuration
if [[ -f "$HOME/.config/containers/storage.conf" ]]; then
  register_check "Rootless storage config" PASS "exists"
fi

# Check subuid/subgid for rootless
if [[ "$current_user" != "root" ]]; then
  if grep -q "^$current_user:" /etc/subuid 2>/dev/null; then
    subuid_range=$(grep "^$current_user:" /etc/subuid | cut -d: -f2,3)
    register_check "subuid configured" PASS "$subuid_range"
  else
    register_check "subuid configured" FAIL "not configured for $current_user"
  fi

  if grep -q "^$current_user:" /etc/subgid 2>/dev/null; then
    subgid_range=$(grep "^$current_user:" /etc/subgid | cut -d: -f2,3)
    register_check "subgid configured" PASS "$subgid_range"
  else
    register_check "subgid configured" FAIL "not configured for $current_user"
  fi
fi

section "Registry Configuration"

# Check registries.conf for security settings
registries_conf=""
for conf in /etc/containers/registries.conf "$HOME/.config/containers/registries.conf"; do
  if [[ -f "$conf" ]]; then
    registries_conf="$conf"
    break
  fi
done

if [[ -n "$registries_conf" ]]; then
  register_check "Registries config" PASS "$(basename "$registries_conf")"

  # Check for insecure registries
  if grep -qE "^\s*insecure\s*=\s*true" "$registries_conf" 2>/dev/null; then
    insecure_count=$(grep -cE "^\s*insecure\s*=\s*true" "$registries_conf" 2>/dev/null || echo "0")
    register_check "Insecure registries" WARN "$insecure_count configured"
  else
    register_check "Insecure registries" PASS "none"
  fi

  # Check for unqualified search registries
  if grep -qE "unqualified-search-registries" "$registries_conf" 2>/dev/null; then
    register_check "Search registries" PASS "configured"
  fi

  # Check for blocked registries
  if grep -qE "^\[\[registry\.block\]\]" "$registries_conf" 2>/dev/null; then
    register_check "Blocked registries" PASS "configured"
  fi
else
  register_check "Registries config" WARN "not found"
fi

section "Image Signature Policy"

# Check signature policy
policy_file=""
for policy in /etc/containers/policy.json "$HOME/.config/containers/policy.json"; do
  if [[ -f "$policy" ]]; then
    policy_file="$policy"
    break
  fi
done

if [[ -n "$policy_file" ]]; then
  register_check "Signature policy" PASS "exists"

  # Check if signatures are required
  if grep -q '"type":\s*"insecureAcceptAnything"' "$policy_file" 2>/dev/null; then
    register_check "Signature verification" WARN "insecureAcceptAnything (signatures not required)"
  elif grep -q '"type":\s*"signedBy"' "$policy_file" 2>/dev/null; then
    register_check "Signature verification" PASS "signatures required"
  else
    register_check "Signature verification" WARN "unknown policy"
  fi
else
  register_check "Signature policy" WARN "not found"
fi

section "Seccomp Profile"

# Check for seccomp profile
seccomp_profile=""
for profile in /usr/share/containers/seccomp.json /etc/containers/seccomp.json; do
  if [[ -f "$profile" ]]; then
    seccomp_profile="$profile"
    break
  fi
done

if [[ -n "$seccomp_profile" ]]; then
  register_check "Seccomp profile" PASS "exists"

  # Check profile permissions
  perms=$(stat -c "%a" "$seccomp_profile" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "644" ]] || [[ "$perms" == "600" ]]; then
    register_check "Seccomp perms" PASS "$perms"
  else
    register_check "Seccomp perms" WARN "$perms"
  fi
else
  register_check "Seccomp profile" WARN "not found"
fi

section "Storage Configuration"

# Check storage.conf
storage_conf=""
for conf in /etc/containers/storage.conf "$HOME/.config/containers/storage.conf"; do
  if [[ -f "$conf" ]]; then
    storage_conf="$conf"
    break
  fi
done

if [[ -n "$storage_conf" ]]; then
  register_check "Storage config" PASS "exists"

  # Check storage driver
  driver=$(grep -E "^driver\s*=" "$storage_conf" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$driver" ]]; then
    if [[ "$driver" == "overlay" ]]; then
      register_check "Storage driver" PASS "overlay (recommended)"
    elif [[ "$driver" == "vfs" ]]; then
      register_check "Storage driver" WARN "vfs (slow, not recommended)"
    else
      register_check "Storage driver" PASS "$driver"
    fi
  fi

  # Check for graphroot
  graphroot=$(grep -E "^graphroot\s*=" "$storage_conf" 2>/dev/null | cut -d'"' -f2 | head -1)
  if [[ -n "$graphroot" ]]; then
    register_check "Graph root" PASS "$graphroot"
  fi
fi

section "Containers.conf Security"

# Check containers.conf
containers_conf=""
for conf in /etc/containers/containers.conf /usr/share/containers/containers.conf "$HOME/.config/containers/containers.conf"; do
  if [[ -f "$conf" ]]; then
    containers_conf="$conf"
    break
  fi
done

if [[ -n "$containers_conf" ]]; then
  register_check "Containers config" PASS "exists"

  # Check security relevant settings
  # Default capabilities
  if grep -qE "default_capabilities\s*=" "$containers_conf" 2>/dev/null; then
    register_check "Default capabilities" PASS "customized"
  fi

  # Check for no_new_privileges
  if grep -qE "no_new_privileges\s*=\s*true" "$containers_conf" 2>/dev/null; then
    register_check "No new privileges" PASS "enabled"
  fi

  # Check default seccomp profile
  if grep -qE "seccomp_profile\s*=" "$containers_conf" 2>/dev/null; then
    register_check "Default seccomp" PASS "configured"
  fi

  # Check for userns mode
  if grep -qE "userns\s*=" "$containers_conf" 2>/dev/null; then
    userns=$(grep -E "userns\s*=" "$containers_conf" | cut -d'"' -f2 | head -1)
    register_check "User namespace" PASS "$userns"
  fi
fi

section "Running Containers Analysis"

# Get running containers
if podman ps --format "{{.ID}}" 2>/dev/null | head -1 >/dev/null; then
  container_count=$(podman ps -q 2>/dev/null | wc -l || echo "0")
  register_check "Running containers" PASS "$container_count"

  if [[ "$container_count" -gt 0 ]]; then
    # Check for privileged containers
    privileged=$(podman ps --format "{{.ID}}" 2>/dev/null | xargs -I {} podman inspect {} --format '{{.HostConfig.Privileged}}' 2>/dev/null | grep -c "true" || echo "0")
    if [[ "$privileged" -gt 0 ]]; then
      register_check "Privileged containers" WARN "$privileged running"
    else
      register_check "Privileged containers" PASS "none"
    fi

    # Check for root containers
    root_containers=$(podman ps --format "{{.ID}}" 2>/dev/null | xargs -I {} podman inspect {} --format '{{.Config.User}}' 2>/dev/null | grep -cE "^$|^root$|^0$" || echo "0")
    if [[ "$root_containers" -gt 0 ]]; then
      register_check "Root user containers" WARN "$root_containers running as root"
    else
      register_check "Root user containers" PASS "none"
    fi
  fi
else
  register_check "Running containers" PASS "none or no access"
fi

section "Image Security"

# Check for images without tags (dangling)
dangling=$(podman images -q --filter "dangling=true" 2>/dev/null | wc -l || echo "0")
if [[ "$dangling" -gt 10 ]]; then
  register_check "Dangling images" WARN "$dangling (cleanup recommended)"
elif [[ "$dangling" -gt 0 ]]; then
  register_check "Dangling images" PASS "$dangling"
else
  register_check "Dangling images" PASS "none"
fi

# Check for images using latest tag
latest_images=$(podman images --format "{{.Repository}}:{{.Tag}}" 2>/dev/null | grep -c ":latest$" || echo "0")
if [[ "$latest_images" -gt 5 ]]; then
  register_check "Images with :latest" WARN "$latest_images (use specific tags)"
elif [[ "$latest_images" -gt 0 ]]; then
  register_check "Images with :latest" WARN "$latest_images"
else
  register_check "Images with :latest" PASS "none"
fi

section "SELinux/AppArmor Integration"

# Check SELinux labeling
if command -v getenforce >/dev/null 2>&1; then
  selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
  if [[ "$selinux_mode" == "Enforcing" ]]; then
    register_check "SELinux" PASS "Enforcing"

    # Check if Podman uses SELinux labels by default
    if [[ -n "$containers_conf" ]] && grep -qE "label\s*=\s*true" "$containers_conf" 2>/dev/null; then
      register_check "SELinux labeling" PASS "enabled"
    fi
  elif [[ "$selinux_mode" == "Permissive" ]]; then
    register_check "SELinux" WARN "Permissive"
  else
    register_check "SELinux" SKIP "not available"
  fi
fi

# Check AppArmor
if command -v aa-status >/dev/null 2>&1; then
  if aa-status 2>/dev/null | grep -qi "podman"; then
    register_check "AppArmor profile" PASS "podman profile loaded"
  fi
fi

section "Network Security"

# Check default network
default_network=$(podman network ls --format "{{.Name}}" 2>/dev/null | head -1)
if [[ -n "$default_network" ]]; then
  register_check "Default network" PASS "$default_network"
fi

# Check for host network usage
host_net=$(podman ps --format "{{.ID}}" 2>/dev/null | xargs -I {} podman inspect {} --format '{{.HostConfig.NetworkMode}}' 2>/dev/null | grep -c "host" || echo "0")
if [[ "$host_net" -gt 0 ]]; then
  register_check "Host network containers" WARN "$host_net using host network"
else
  register_check "Host network containers" PASS "none"
fi

section "Podman Socket"

# Check if podman socket is enabled (for API access)
if systemctl is-active podman.socket >/dev/null 2>&1; then
  register_check "Podman socket" PASS "active"

  # Check socket permissions
  socket_path="/run/podman/podman.sock"
  if [[ -S "$socket_path" ]]; then
    perms=$(stat -c "%a" "$socket_path" 2>/dev/null || echo "unknown")
    if [[ "$perms" == "660" ]] || [[ "$perms" == "600" ]]; then
      register_check "Socket permissions" PASS "$perms"
    else
      register_check "Socket permissions" WARN "$perms"
    fi
  fi
elif systemctl --user is-active podman.socket >/dev/null 2>&1; then
  register_check "Podman socket" PASS "active (user mode)"
else
  register_check "Podman socket" PASS "not active"
fi

print_summary
exit "$EXIT_CODE"
