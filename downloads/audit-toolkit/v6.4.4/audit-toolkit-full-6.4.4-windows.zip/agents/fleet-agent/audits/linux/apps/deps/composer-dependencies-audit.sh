#!/usr/bin/env bash
# composer-dependencies-audit.sh
# Purpose : Non-destructive security posture audit for PHP Composer projects
# Usage   : sudo ./composer-dependencies-audit.sh [APP_PATH]
# Env     : APP_PATH=/var/www/html (default) | LOG_FILE=/var/log/composer-audit.log | NO_COLOR=1
# Exit    : 0=OK, 1=Errors, 2=Warnings only
#
# @elevation: none
# @elevation-reason: Composer file and dependency checks only
#
set -euo pipefail
IFS=$'\n\t'

APP_PATH="${1:-${APP_PATH:-/var/www/html}}"
LOG_FILE="${LOG_FILE:-/var/log/composer-audit.log}"

# ANSI colours (auto-disable if NO_COLOR is set or stdout is not a TTY)
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
if [[ -n "${NO_COLOR:-}" || ! -t 1 ]]; then
  RED=''; YELLOW=''; GREEN=''; BLUE=''; NC=''
fi

CHECKS=0; ERR=0; WARN=0

log(){  printf '[%(%Y-%m-%d %H:%M:%S)T] [%s] %s\n' -1 "$1" "$2" | tee -a "$LOG_FILE" >/dev/null; }
ok(){   printf '%b[PASS]%b  %s\n' "$GREEN" "$NC" "$1"; log PASS "$1"; }
warn(){ printf '%b[WARN]%b  %s\n' "$YELLOW" "$NC" "$1"; log WARN "$1"; WARN=$((WARN+1)); }
fail(){ printf '%b[FAIL]%b  %s\n' "$RED"   "$NC" "$1" 1>&2; log FAIL "$1"; ERR=$((ERR+1)); }
info(){ printf '%b[INFO]%b  %s\n' "$BLUE"  "$NC" "$1"; log INFO "$1"; }
skip(){ printf '%b[SKIP]%b  %s\n' "$BLUE"  "$NC" "$1"; log SKIP "$1"; }

section(){ echo; printf '\n================== %s ==================\n' "$1" | tee -a "$LOG_FILE" >/dev/null; CHECKS=$((CHECKS+1)); }

# Check if running as root/sudo and warn if not
check_root_warn() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    warn "Not running as root/sudo (some checks may be limited)"
    return 1
  fi
  return 0
}

# --- Platform check ---
case "$(uname -s)" in
  Linux|Darwin) ;;
  *)
    echo "Unsupported platform: $(uname -s)" >&2
    exit 1
    ;;
esac

# --- Ensure log path is writable (fallback early, before first section) ---
if ! : >>"$LOG_FILE" 2>/dev/null; then
  if [[ "$(uname -s)" == "Darwin" ]]; then
    alt_log="$(mktemp -t composer-audit.XXXXXX.log)"
  else
    alt_log="$(mktemp -t composer-audit.XXXXXX.log)"
  fi
  printf 'LOG_FILE not writable; using %s\n' "$alt_log" >&2
  LOG_FILE="$alt_log"
fi

# --- Privilege & path checks ---
section "Prerequisites"
check_root_warn
if [[ ! -d "$APP_PATH" ]]; then fail "APP_PATH not found: $APP_PATH"; echo; exit 1; fi
ok "Application root: $APP_PATH"

# --- Composer availability ---
section "Composer availability"
if command -v composer >/dev/null 2>&1; then
  ok "composer present: $(composer --version | head -n1)"
else
  fail "composer not installed (install via package manager or https://getcomposer.org)"; echo; exit 1
fi

# --- jq availability ---
section "jq availability"
if command -v jq >/dev/null 2>&1; then
  ok "jq present: $(jq --version)"
else
  fail "jq not installed (required for parsing composer audit output)"; echo; exit 1
fi

# --- Required commands check ---
section "Required commands"
for cmd in mktemp head grep awk; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    fail "Required command missing: $cmd"
  fi
done

# --- PHP version check ---
section "PHP version"
if command -v php >/dev/null 2>&1; then
  phpver=$(php -r 'echo PHP_VERSION;' 2>/dev/null)
  info "PHP version: $phpver"
else
  warn "php not installed"
fi

# --- Composer project files check ---
section "Composer project files"
if [[ ! -f "$APP_PATH/composer.lock" ]]; then
  warn "composer.lock not found in $APP_PATH (run 'composer install' first?)"
fi
if [[ ! -f "$APP_PATH/composer.json" ]]; then
  fail "composer.json not found in $APP_PATH"
  echo; exit 1
fi
ok "composer.json found"

# --- Composer audit ---
section "Composer security audit"
pushd "$APP_PATH" >/dev/null
if composer audit --no-interaction --format=json > audit.json 2>/dev/null; then
  vulns=$(jq '.advisories | length' audit.json)
  if [[ "$vulns" -eq 0 ]]; then
    ok "No known vulnerabilities found in dependencies"
  else
    warn "$vulns vulnerabilities found in dependencies"
    jq -r '.advisories[] | "\(.title): \(.cve) (\(.package_name))"' audit.json | while read -r line; do
      warn "$line"
    done
  fi
  rm -f audit.json
else
  fail "composer audit failed to run"
fi
popd >/dev/null

# --- Summary and exit code ---
section "Summary"
info "Checks run: $CHECKS"
info "Warnings: $WARN"
info "Errors: $ERR"
if [[ "$ERR" -gt 0 ]]; then
  exit 1
elif [[ "$WARN" -gt 0 ]]; then
  exit 2
else
  exit 0
fi
