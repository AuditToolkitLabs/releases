# Java Application Security Audits

This directory contains security audits for Java/JVM-based applications and application servers.

## Audits

### java-app-security-audit.sh

Comprehensive security audit for Java applications, covering:

- **JVM Security**
  - Java version and EOL status
  - JVM SecurityManager configuration
  - JVM security policies
  - System property security

- **Log4j Vulnerability Detection (Log4Shell)**
  - CVE-2021-44228 detection
  - Scans for vulnerable Log4j versions (1.x, 2.0-2.14, 2.15-2.16)
  - Checks JAR files in common paths
  - **Critical**: FAIL status for vulnerable versions

- **Spring Boot Security**
  - Actuator endpoint exposure
  - Health/metrics/env endpoint protection
  - Management port configuration
  - Application properties security

- **Apache Tomcat**
  - Version and EOL checks
  - server.xml security configuration
  - Connector security (SSL/TLS)
  - Manager application protection
  - AJP connector security

- **JBoss/WildFly**
  - Version checks
  - standalone.xml security
  - Management interface security
  - Deployment scanner configuration

- **Dependency Management**
  - Maven pom.xml scanning
  - Gradle build.gradle analysis
  - Dependency version checks
  - Known vulnerable dependencies

- **Keystore/Truststore Security**
  - File permissions (should be 600)
  - Location and ownership
  - Certificate expiration checks

## Usage

```bash
# Run Java application audit
bash audits/linux/apps/java/java-app-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain apps --match java
```

## Requirements

- Java runtime (openjdk/oracle-java)
- Optional: Maven, Gradle for dependency scanning
- Optional: Spring Boot CLI for advanced checks

## Remediation

### Log4Shell Vulnerability

If Log4j 1.x or vulnerable 2.x detected:

```bash
# Upgrade to Log4j 2.17.1 or later
# For Maven (pom.xml):
<dependency>
  <groupId>org.apache.logging.log4j</groupId>
  <artifactId>log4j-core</artifactId>
  <version>2.17.1</version>
</dependency>

# For Gradle (build.gradle):
implementation 'org.apache.logging.log4j:log4j-core:2.17.1'
```

### Spring Boot Actuator

Restrict actuator endpoints in `application.properties`:

```properties
# Expose only health and info
management.endpoints.web.exposure.include=health,info

# Bind management to localhost only
management.server.address=127.0.0.1

# Use separate management port
management.server.port=8090

# Require authentication
management.endpoints.web.base-path=/actuator
spring.security.user.name=admin
spring.security.user.password=<strong-password>
```

### Tomcat Security

Harden `server.xml`:

```xml
<!-- Disable Manager/Host-Manager apps -->
<!-- Use strong SSL/TLS configuration -->
<Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"
           maxThreads="150" SSLEnabled="true">
  <SSLHostConfig>
    <Certificate certificateKeystoreFile="conf/keystore.jks"
                 type="RSA" />
  </SSLHostConfig>
</Connector>

<!-- Disable insecure protocols -->
<Connector ... sslProtocols="TLSv1.2,TLSv1.3" />
```

### JVM SecurityManager

Enable SecurityManager for untrusted code:

```bash
# Start with security manager
java -Djava.security.manager \
     -Djava.security.policy=/path/to/policy.file \
     -jar app.jar
```

## References

- [Log4Shell (CVE-2021-44228)](https://logging.apache.org/log4j/2.x/security.html)
- [Spring Boot Actuator Security](https://docs.spring.io/spring-boot/docs/current/reference/html/actuator.html#actuator.endpoints.security)
- [Apache Tomcat Security](https://tomcat.apache.org/tomcat-9.0-doc/security-howto.html)
- [Java Security Guide](https://docs.oracle.com/en/java/javase/11/security/)
