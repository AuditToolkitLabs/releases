#!/usr/bin/env bash
# Java Application Security Audit (Spring Boot/Tomcat/JBoss)
# Checks Java application deployments including JVM security, dependencies, and application server hardening
#
# @elevation: partial
# @elevation-reason: Some app server paths may need root to read
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
JAVA_PATHS=(
  "/usr/bin/java"
  "/usr/lib/jvm/*/bin/java"
  "/opt/java/*/bin/java"
)

TOMCAT_PATHS=(
  "/opt/tomcat"
  "/usr/share/tomcat"
  "/var/lib/tomcat*"
  "/opt/apache-tomcat-*"
)

SPRING_BOOT_PATHS=(
  "/opt"
  "/srv"
  "/var/www"
  "$HOME"
)

# === Performance: Cache variables ===
JAVA_VERSION=""
JAVA_HOME=""
APP_TYPE=""
TOMCAT_HOME=""
SPRING_BOOT_JAR=""
LOG4J_VERSION=""

# === Helper Functions ===

# Detect Java installation
get_java_version() {
  if [[ -n "$JAVA_VERSION" ]]; then
    echo "$JAVA_VERSION"
    return 0
  fi

  if command -v java >/dev/null 2>&1; then
    java_ver=$(java -version 2>&1 | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9_]+' || echo "")
    if [[ -z "$java_ver" ]]; then
      # Java 9+ uses different version format
      java_ver=$(java -version 2>&1 | head -n1 | grep -oE 'version "([0-9]+' | grep -oE '[0-9]+' || echo "unknown")
    fi
    JAVA_VERSION="$java_ver"
    echo "$java_ver"
  else
    echo "not_installed"
  fi
}

# Detect JAVA_HOME
get_java_home() {
  if [[ -n "$JAVA_HOME" ]]; then
    echo "$JAVA_HOME"
    return 0
  fi

  if [[ -n "${JAVA_HOME:-}" ]]; then
    export JAVA_HOME="$JAVA_HOME"
    echo "$JAVA_HOME"
    return 0
  fi

  # Try readlink on java binary
  if command -v java >/dev/null 2>&1; then
    java_bin=$(command -v java)
    if [[ -L "$java_bin" ]]; then
      java_real=$(readlink -f "$java_bin" 2>/dev/null || echo "")
      if [[ -n "$java_real" ]]; then
        JAVA_HOME=$(dirname "$(dirname "$java_real")")
        echo "$JAVA_HOME"
        return 0
      fi
    fi
  fi

  echo ""
}

# Detect application type
detect_app_type() {
  if [[ -n "$APP_TYPE" ]]; then
    echo "$APP_TYPE"
    return 0
  fi

  # Check for Tomcat
  for path in "${TOMCAT_PATHS[@]}"; do
    for tomcat_dir in $path; do
      if [[ -d "$tomcat_dir" ]]; then
        if [[ -f "$tomcat_dir/bin/catalina.sh" || -f "$tomcat_dir/bin/startup.sh" ]]; then
          APP_TYPE="tomcat"
          TOMCAT_HOME="$tomcat_dir"
          echo "tomcat"
          return 0
        fi
      fi
    done
  done

  # Check for Spring Boot jar
  for base_path in "${SPRING_BOOT_PATHS[@]}"; do
    if [[ -d "$base_path" ]]; then
      spring_jar=$(find "$base_path" -maxdepth 3 -name "*.jar" -type f 2>/dev/null | \
        xargs -I {} sh -c 'jar tf {} 2>/dev/null | grep -q "BOOT-INF" && echo {}' | head -n1 || echo "")
      if [[ -n "$spring_jar" ]]; then
        APP_TYPE="springboot"
        SPRING_BOOT_JAR="$spring_jar"
        echo "springboot"
        return 0
      fi
    fi
  done

  # Check for JBoss/WildFly
  if [[ -d "/opt/jboss" || -d "/opt/wildfly" ]]; then
    APP_TYPE="jboss"
    echo "jboss"
    return 0
  fi

  APP_TYPE="generic"
  echo "generic"
}

# Check for Log4j vulnerability (Log4Shell)
check_log4j_version() {
  if [[ -n "$LOG4J_VERSION" ]]; then
    echo "$LOG4J_VERSION"
    return 0
  fi

  # Search for log4j jar files
  log4j_jars=$(find /opt /srv /var/www /usr/share 2>/dev/null -name "log4j-core-*.jar" -o -name "log4j-*.jar" | head -n 10 || echo "")

  if [[ -z "$log4j_jars" ]]; then
    LOG4J_VERSION="not_found"
    echo "not_found"
    return 0
  fi

  # Extract version from jar filename
  for jar in $log4j_jars; do
    ver=$(echo "$jar" | grep -oE '2\.[0-9]+\.[0-9]+' || echo "")
    if [[ -n "$ver" ]]; then
      LOG4J_VERSION="$ver"
      echo "$ver"
      return 0
    fi
  done

  LOG4J_VERSION="unknown"
  echo "unknown"
}

# === MAIN AUDIT ===

section "Java Installation"

java_ver=$(get_java_version)
if [[ "$java_ver" == "not_installed" ]]; then
  register_check "Java Installed" SKIP "Java not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Java Version" PASS "Java $java_ver detected"

# Check for EOL Java versions
if [[ "$java_ver" =~ ^1\.[0-7] ]]; then
  register_check "Java EOL Status" FAIL "Java $java_ver is End-of-Life (unsupported)"
elif [[ "$java_ver" =~ ^1\.8 || "$java_ver" =~ ^8 ]]; then
  register_check "Java EOL Status" WARN "Java 8 in extended support (consider upgrading to Java 11 or 17 LTS)"
elif [[ "$java_ver" =~ ^(11|17|21) ]]; then
  register_check "Java EOL Status" PASS "Java $java_ver is LTS (Long Term Support)"
else
  register_check "Java EOL Status" PASS "Java version OK"
fi

# Check JAVA_HOME
java_home=$(get_java_home)
if [[ -n "$java_home" ]]; then
  register_check "JAVA_HOME" PASS "set to $java_home"
else
  register_check "JAVA_HOME" WARN "JAVA_HOME not set (may cause issues)"
fi

# === Log4Shell Vulnerability Check ===
section "Log4j Security (Log4Shell CVE-2021-44228)"

log4j_ver=$(check_log4j_version)
if [[ "$log4j_ver" == "not_found" ]]; then
  register_check "Log4j Detected" SKIP "No Log4j jars found"
elif [[ "$log4j_ver" == "unknown" ]]; then
  register_check "Log4j Version" WARN "Log4j detected but version unclear - manual review needed"
else
  register_check "Log4j Version" PASS "Log4j $log4j_ver found"

  # Check for vulnerable versions (2.0-beta9 through 2.14.1)
  major=$(echo "$log4j_ver" | cut -d. -f1)
  minor=$(echo "$log4j_ver" | cut -d. -f2)
  patch=$(echo "$log4j_ver" | cut -d. -f3)

  if [[ "$major" == "2" ]]; then
    if [[ "$minor" -lt 15 ]]; then
      register_check "Log4Shell Vulnerability" FAIL "Log4j $log4j_ver is VULNERABLE to CVE-2021-44228 (Log4Shell)"
    elif [[ "$minor" -eq 15 && "$patch" -eq 0 ]]; then
      register_check "Log4Shell Vulnerability" WARN "Log4j 2.15.0 has incomplete fix (upgrade to 2.17.1+)"
    elif [[ "$minor" -eq 16 && "$patch" -eq 0 ]]; then
      register_check "Log4Shell Vulnerability" WARN "Log4j 2.16.0 vulnerable to CVE-2021-45105 (upgrade to 2.17.1+)"
    else
      register_check "Log4Shell Vulnerability" PASS "Log4j $log4j_ver not vulnerable (2.17.1+ safe)"
    fi
  fi
fi

# === Application Type Detection ===
section "Application Detection"

app_type=$(detect_app_type)
register_check "Application Type" PASS "$app_type detected"

# === JVM Security Settings ===
section "JVM Security Configuration"

# Check if SecurityManager is enabled (deprecated in Java 17+)
if [[ "$java_ver" =~ ^(1\.[0-9]|[0-9]|1[0-6]) ]]; then
  # SecurityManager relevant for Java <17
  sm_enabled=$(ps aux 2>/dev/null | grep java | grep -c "\-Djava.security.manager" || echo "0")
  if [[ "$sm_enabled" -gt 0 ]]; then
    register_check "SecurityManager" PASS "SecurityManager enabled on $sm_enabled Java process(es)"
  else
    register_check "SecurityManager" WARN "SecurityManager not enabled (recommended for untrusted code)"
  fi
fi

# Check for weak cryptography
if [[ -n "$java_home" && -f "$java_home/lib/security/java.security" ]]; then
  sec_file="$java_home/lib/security/java.security"

  # Check disabled algorithms
  if grep -q "jdk.tls.disabledAlgorithms" "$sec_file" 2>/dev/null; then
    disabled_algs=$(grep "jdk.tls.disabledAlgorithms" "$sec_file" | grep -v "^#" || echo "")
    if [[ -n "$disabled_algs" ]]; then
      if echo "$disabled_algs" | grep -qE "SSLv3|TLSv1|TLSv1\.1|MD5|RC4"; then
        register_check "Weak Crypto Disabled" PASS "Weak algorithms disabled in java.security"
      else
        register_check "Weak Crypto Disabled" WARN "Some weak algorithms may not be disabled"
      fi
    fi
  fi

  # Check TLS version
  if grep -q "jdk.tls.client.protocols" "$sec_file" 2>/dev/null; then
    register_check "TLS Configuration" PASS "TLS protocols configured"
  fi
fi

# === Tomcat-Specific Checks ===
if [[ "$app_type" == "tomcat" && -n "$TOMCAT_HOME" ]]; then
  section "Apache Tomcat Security"

  register_check "Tomcat Home" PASS "$TOMCAT_HOME"

  # Check Tomcat version
  if [[ -f "$TOMCAT_HOME/lib/catalina.jar" ]]; then
    tomcat_ver=$(java -cp "$TOMCAT_HOME/lib/catalina.jar" org.apache.catalina.util.ServerInfo 2>/dev/null | grep "Server number" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    if [[ "$tomcat_ver" != "unknown" ]]; then
      register_check "Tomcat Version" PASS "Tomcat $tomcat_ver"

      # Check for old versions
      major=$(echo "$tomcat_ver" | cut -d. -f1)
      if [[ "$major" -lt 9 ]]; then
        register_check "Tomcat EOL" WARN "Tomcat $major is EOL (upgrade to Tomcat 10+)"
      fi
    fi
  fi

  # Check server.xml configuration
  if [[ -f "$TOMCAT_HOME/conf/server.xml" ]]; then
    server_xml="$TOMCAT_HOME/conf/server.xml"

    # Check for default connectors (8080, 8005)
    if grep -q 'port="8080"' "$server_xml" 2>/dev/null; then
      register_check "HTTP Connector" WARN "Default port 8080 in use (consider changing)"
    fi

    if grep -q 'port="8005"' "$server_xml" 2>/dev/null; then
      shutdown_port=$(grep 'port="8005"' "$server_xml" | grep -oE 'shutdown="[^"]*"' || echo "")
      if [[ "$shutdown_port" == 'shutdown="SHUTDOWN"' ]]; then
        register_check "Shutdown Port" FAIL "Default shutdown command 'SHUTDOWN' on port 8005 (security risk)"
      else
        register_check "Shutdown Port" PASS "Shutdown port configured securely"
      fi
    fi

    # Check SSL/TLS connector
    if grep -q 'SSLEnabled="true"' "$server_xml" 2>/dev/null; then
      register_check "SSL Enabled" PASS "SSL/TLS connector configured"

      # Check SSL protocols
      if grep -q 'sslProtocol' "$server_xml" 2>/dev/null; then
        ssl_protocols=$(grep 'sslProtocol' "$server_xml" | grep -oE 'sslProtocol="[^"]*"')
        if echo "$ssl_protocols" | grep -qE "TLSv1\.2|TLSv1\.3"; then
          register_check "SSL Protocols" PASS "Modern TLS protocols configured"
        else
          register_check "SSL Protocols" WARN "TLS configuration may be weak"
        fi
      fi
    else
      register_check "SSL Enabled" WARN "No SSL connector found (HTTPS recommended)"
    fi

    # Check for RemoteAddrValve (IP filtering)
    if grep -q "RemoteAddrValve" "$server_xml" 2>/dev/null; then
      register_check "IP Filtering" PASS "RemoteAddrValve configured for access control"
    else
      register_check "IP Filtering" WARN "No IP filtering valve configured"
    fi
  fi

  # Check tomcat-users.xml
  if [[ -f "$TOMCAT_HOME/conf/tomcat-users.xml" ]]; then
    users_xml="$TOMCAT_HOME/conf/tomcat-users.xml"

    # Check for default users
    if grep -qE '<user.*username="(tomcat|admin|manager)"' "$users_xml" 2>/dev/null; then
      register_check "Default Users" FAIL "Default Tomcat users found (remove tomcat/admin/manager)"
    else
      register_check "Default Users" PASS "No default users in tomcat-users.xml"
    fi

    # Check file permissions
    users_perms=$(stat -c '%a' "$users_xml" 2>/dev/null || stat -f '%Lp' "$users_xml" 2>/dev/null || echo "000")
    if [[ "$users_perms" == "600" || "$users_perms" == "640" ]]; then
      register_check "tomcat-users.xml Perms" PASS "permissions $users_perms (secure)"
    else
      register_check "tomcat-users.xml Perms" WARN "permissions $users_perms (should be 600 or 640)"
    fi
  fi

  # Check for manager/host-manager apps
  if [[ -d "$TOMCAT_HOME/webapps/manager" ]]; then
    register_check "Manager App" WARN "Manager app deployed (remove if not needed)"
  fi

  # Check process user (optimized - single grep with pattern)
  tomcat_user=$(ps aux 2>/dev/null | grep '[c]atalina' | awk '{print $1}' | head -n1 || echo "")
  if [[ -n "$tomcat_user" ]]; then
    if [[ "$tomcat_user" == "root" ]]; then
      register_check "Process User" FAIL "Tomcat running as root (security risk)"
    else
      register_check "Process User" PASS "Tomcat running as $tomcat_user (not root)"
    fi
  fi
fi

# === Spring Boot Specific Checks ===
if [[ "$app_type" == "springboot" && -n "$SPRING_BOOT_JAR" ]]; then
  section "Spring Boot Security"

  register_check "Spring Boot JAR" PASS "$SPRING_BOOT_JAR"

  # Check if actuator is enabled
  if command -v unzip >/dev/null 2>&1; then
    actuator_present=$(unzip -l "$SPRING_BOOT_JAR" 2>/dev/null | grep -c "spring-boot-actuator" || echo "0")
    if [[ "$actuator_present" -gt 0 ]]; then
      register_check "Actuator Detected" WARN "Spring Boot Actuator present (ensure endpoints secured)"
    fi
  fi

  # Check application.properties/yml
  spring_dir=$(dirname "$SPRING_BOOT_JAR")
  if [[ -f "$spring_dir/application.properties" ]]; then
    app_props="$spring_dir/application.properties"

    # Check for exposed actuator endpoints
    if grep -q "management.endpoints.web.exposure.include=\*" "$app_props" 2>/dev/null; then
      register_check "Actuator Endpoints" FAIL "All actuator endpoints exposed (restrict to health,info only)"
    elif grep -q "management.endpoints.web.exposure.include" "$app_props" 2>/dev/null; then
      register_check "Actuator Endpoints" PASS "Actuator endpoints configured"
    fi

    # Check for security settings
    if grep -q "spring.security" "$app_props" 2>/dev/null; then
      register_check "Spring Security" PASS "Spring Security configuration found"
    fi

    # Check for plaintext secrets
    if grep -qE "(password|secret|key)=[^$]" "$app_props" 2>/dev/null; then
      register_check "Plaintext Secrets" WARN "Possible plaintext secrets in application.properties"
    fi
  fi

  # Check JAR file permissions
  jar_perms=$(stat -c '%a' "$SPRING_BOOT_JAR" 2>/dev/null || stat -f '%Lp' "$SPRING_BOOT_JAR" 2>/dev/null || echo "000")
  if [[ "$jar_perms" =~ ^[0-7][0-5][0-5]$ ]]; then
    register_check "JAR Permissions" PASS "permissions $jar_perms"
  else
    register_check "JAR Permissions" WARN "permissions $jar_perms (world-writable or executable)"
  fi
fi

# === Dependency Scanning ===
section "Dependency Security"

# Check for Maven
if command -v mvn >/dev/null 2>&1; then
  register_check "Maven Installed" PASS "Maven available for dependency scanning"

  # Look for pom.xml files
  pom_files=$(find /opt /srv /var/www "$HOME" 2>/dev/null -maxdepth 3 -name "pom.xml" | head -n5 || echo "")
  if [[ -n "$pom_files" ]]; then
    pom_count=$(echo "$pom_files" | wc -l)
    register_check "Maven Projects" PASS "$pom_count pom.xml file(s) found"

    # Could run: mvn dependency:tree or mvn versions:display-dependency-updates
    register_check "Dependency Scan" WARN "Run 'mvn dependency:tree' or use OWASP Dependency-Check plugin"
  fi
fi

# Check for Gradle
if command -v gradle >/dev/null 2>&1; then
  register_check "Gradle Installed" PASS "Gradle available for dependency scanning"

  # Look for build.gradle files
  gradle_files=$(find /opt /srv /var/www "$HOME" 2>/dev/null -maxdepth 3 -name "build.gradle" | head -n5 || echo "")
  if [[ -n "$gradle_files" ]]; then
    gradle_count=$(echo "$gradle_files" | wc -l)
    register_check "Gradle Projects" PASS "$gradle_count build.gradle file(s) found"

    register_check "Dependency Scan" WARN "Run 'gradle dependencies' to review dependency tree"
  fi
fi

# === Keystore/Truststore Security ===
section "Keystore & Certificate Security"

# Look for Java keystores
keystores=$(find /opt /etc /var /srv 2>/dev/null -name "*.jks" -o -name "*.keystore" -o -name "*.p12" | head -n10 || echo "")

if [[ -n "$keystores" ]]; then
  keystore_count=$(echo "$keystores" | wc -l)
  register_check "Keystores Found" PASS "$keystore_count keystore file(s) detected"

  # Check keystore permissions
  for ks in $keystores; do
    ks_perms=$(stat -c '%a' "$ks" 2>/dev/null || stat -f '%Lp' "$ks" 2>/dev/null || echo "000")
    ks_name=$(basename "$ks")

    if [[ "$ks_perms" == "600" || "$ks_perms" == "640" ]]; then
      register_check "Keystore Perms ($ks_name)" PASS "permissions $ks_perms (secure)"
    else
      register_check "Keystore Perms ($ks_name)" WARN "permissions $ks_perms (should be 600 or 640)"
    fi
  done
else
  register_check "Keystores" SKIP "No keystore files found"
fi

# === Process Security ===
section "Java Process Security"

# Check all running Java processes
java_procs=$(ps aux 2>/dev/null | grep '[j]ava' || echo "")

if [[ -n "$java_procs" ]]; then
  java_count=$(echo "$java_procs" | wc -l)
  register_check "Java Processes" PASS "$java_count Java process(es) running"

  # Check if any running as root
  root_java=$(echo "$java_procs" | grep -c "^root" || echo "0")
  if [[ "$root_java" -gt 0 ]]; then
    register_check "Root Processes" FAIL "$root_java Java process(es) running as root"
  else
    register_check "Root Processes" PASS "No Java processes running as root"
  fi

  # Check JVM heap settings
  heap_settings=$(echo "$java_procs" | grep -oE '\-Xm[sx][0-9]+[mMgG]' | head -n1 || echo "")
  if [[ -n "$heap_settings" ]]; then
    register_check "Heap Configuration" PASS "JVM heap configured: $heap_settings"
  else
    register_check "Heap Configuration" WARN "No explicit heap settings (using JVM defaults)"
  fi
else
  register_check "Java Processes" WARN "No Java processes currently running"
fi

# === Web Application Security (WAR files) ===
if [[ "$app_type" == "tomcat" && -d "$TOMCAT_HOME/webapps" ]]; then
  section "Web Application Security"

  # Count deployed applications
  war_count=$(find "$TOMCAT_HOME/webapps" -name "*.war" 2>/dev/null | wc -l || echo "0")
  app_count=$(ls -1 "$TOMCAT_HOME/webapps" 2>/dev/null | grep -v -E "*.war|ROOT|manager|host-manager|docs|examples" | wc -l || echo "0")

  total_apps=$((war_count + app_count))
  if [[ "$total_apps" -gt 0 ]]; then
    register_check "Deployed Applications" PASS "$total_apps application(s) deployed"
  fi

  # Check for example applications (should be removed in production)
  if [[ -d "$TOMCAT_HOME/webapps/examples" ]]; then
    register_check "Example Apps" WARN "Example applications still deployed (remove in production)"
  else
    register_check "Example Apps" PASS "Example applications removed"
  fi

  # Check for docs
  if [[ -d "$TOMCAT_HOME/webapps/docs" ]]; then
    register_check "Documentation" WARN "Tomcat documentation deployed (remove in production)"
  else
    register_check "Documentation" PASS "Tomcat documentation removed"
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
