#!/usr/bin/env bash
# Node.js Application Security Audit (portable) - Performance Optimized
# Checks Node.js applications, dependencies, process managers, and security configurations
#
# @elevation: none
# @elevation-reason: Package.json and npm dependency checks only
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
NODEJS_APP_PATHS=(
  "/var/www"
  "/opt"
  "/srv"
  "/home"
  "$HOME"
)

# === Performance: Cache variables ===
PACKAGE_JSON_FILES=()
NODE_PROCESSES=""
PM2_LIST=""

# Helper function to find package.json files
find_package_json_files() {
  if [[ ${#PACKAGE_JSON_FILES[@]} -gt 0 ]]; then
    printf '%s\n' "${PACKAGE_JSON_FILES[@]}"
    return 0
  fi

  # Search common application directories
  local found_files=()
  for base_path in "${NODEJS_APP_PATHS[@]}"; do
    if [[ -d "$base_path" ]]; then
      # Limit search depth to avoid performance issues
      while IFS= read -r -d '' file; do
        found_files+=("$file")
      done < <(find "$base_path" -maxdepth 4 -name "package.json" -type f -print0 2>/dev/null || true)
    fi
  done

  PACKAGE_JSON_FILES=("${found_files[@]}")
  printf '%s\n' "${PACKAGE_JSON_FILES[@]}"
}

# OPTIMIZED: Get Node.js processes (called once)
get_node_processes() {
  if [[ -n "$NODE_PROCESSES" ]]; then
    echo "$NODE_PROCESSES"
    return 0
  fi

  NODE_PROCESSES=$(pgrep -a node 2>/dev/null || echo "")
  echo "$NODE_PROCESSES"
}

# OPTIMIZED: Get PM2 process list (called once)
get_pm2_list() {
  if [[ -n "$PM2_LIST" ]]; then
    echo "$PM2_LIST"
    return 0
  fi

  if command -v pm2 >/dev/null 2>&1; then
    PM2_LIST=$(pm2 jlist 2>/dev/null || echo "[]")
  else
    PM2_LIST="[]"
  fi

  echo "$PM2_LIST"
}

# Check if npm audit is available and run it (cached)
run_npm_audit() {
  local package_dir="$1"

  if [[ ! -f "$package_dir/package.json" ]]; then
    return 1
  fi

  if ! command -v npm >/dev/null 2>&1; then
    return 1
  fi

  # Run npm audit and cache result
  # Note: npm audit exits with 1 when vulnerabilities exist, so we must capture output regardless
  local audit_output
  audit_output=$(cd "$package_dir" && npm audit --json 2>/dev/null)
  local npm_exit=$?

  # Return the audit output if successful or if vulnerabilities found (exit 1)
  # Only return error JSON if npm command actually failed (exit > 1)
  if [[ $npm_exit -le 1 ]]; then
    echo "$audit_output"
  else
    echo '{"error": true}'
  fi
}

# Parse package.json safely
parse_package_json() {
  local package_file="$1"
  local key="$2"

  if [[ ! -f "$package_file" ]]; then
    return 1
  fi

  # Try to extract value using grep and basic parsing
  # For more complex parsing, would need jq but want to keep dependencies minimal
  if command -v jq >/dev/null 2>&1; then
    jq -r ".$key // empty" "$package_file" 2>/dev/null || echo ""
  else
    # Fallback to grep-based parsing
    grep -oP "\"$key\"[[:space:]]*:[[:space:]]*\"\K[^\"]*" "$package_file" 2>/dev/null || echo ""
  fi
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for Node.js and related tools
section "Node.js Environment"

if command -v node >/dev/null 2>&1; then
  node_version=$(node --version 2>/dev/null || echo "unknown")
  register_check "Tool: node" PASS "$node_version"

  # Check Node.js version for EOL
  major_version=$(echo "$node_version" | grep -oP 'v?\K[0-9]+' | head -n1)
  if [[ -n "$major_version" ]]; then
    # Node.js versions < 14 are EOL
    if [[ "$major_version" -lt 14 ]]; then
      register_check "Node.js version" FAIL "version $major_version is End-of-Life (EOL)"
    elif [[ "$major_version" -lt 16 ]]; then
      register_check "Node.js version" WARN "version $major_version approaching EOL, upgrade to 18 LTS or 20 LTS"
    else
      register_check "Node.js version" PASS "version $major_version (supported)"
    fi
  fi
else
  register_check "Tool: node" FAIL "Node.js not found"
fi

if command -v npm >/dev/null 2>&1; then
  npm_version=$(npm --version 2>/dev/null || echo "unknown")
  register_check "Tool: npm" PASS "v$npm_version"
else
  register_check "Tool: npm" WARN "npm not found"
fi

# Check for package managers
for tool in yarn pnpm; do
  if command -v "$tool" >/dev/null 2>&1; then
    version=$("$tool" --version 2>/dev/null || echo "unknown")
    register_check "Tool: $tool" PASS "v$version"
  fi
done

# Check for process managers
section "Process Managers"

if command -v pm2 >/dev/null 2>&1; then
  pm2_version=$(pm2 --version 2>/dev/null || echo "unknown")
  register_check "Tool: pm2" PASS "v$pm2_version"

  # Check PM2 status
  pm2_list=$(get_pm2_list)
  if [[ "$pm2_list" != "[]" ]]; then
    app_count=$(echo "$pm2_list" | grep -c '"name"' 2>/dev/null || echo "0")
    register_check "PM2 applications" PASS "$app_count apps managed"
  else
    register_check "PM2 applications" WARN "no apps running under PM2"
  fi
else
  register_check "Tool: pm2" SKIP "not installed"
fi

if command -v forever >/dev/null 2>&1; then
  register_check "Tool: forever" PASS "installed"
else
  register_check "Tool: forever" SKIP "not installed"
fi

# Node.js Process Security
section "Node.js Process Security"

node_procs=$(get_node_processes)
if [[ -n "$node_procs" ]]; then
  proc_count=$(echo "$node_procs" | wc -l)
  register_check "Node.js processes" PASS "$proc_count running"

  # Check if any Node.js process is running as root
  root_procs=$(echo "$node_procs" | while read -r pid rest; do
    if [[ -n "$pid" ]]; then
      proc_user=$(ps -o user= -p "$pid" 2>/dev/null || echo "")
      if [[ "$proc_user" == "root" ]]; then
        echo "$pid"
      fi
    fi
  done)

  if [[ -n "$root_procs" ]]; then
    root_count=$(echo "$root_procs" | wc -l)
    register_check "Process user" FAIL "$root_count Node.js processes running as root - SECURITY RISK"
  else
    register_check "Process user" PASS "no Node.js processes running as root"
  fi

  # Check NODE_ENV for running processes
  # Collect NODE_ENV values (avoid subshell variable loss)
  node_envs=$(echo "$node_procs" | while read -r pid rest; do
    if [[ -n "$pid" ]] && [[ "$pid" =~ ^[0-9]+$ ]]; then
      grep -z "NODE_ENV" "/proc/$pid/environ" 2>/dev/null | tr '\0' '\n' | grep "NODE_ENV" | cut -d= -f2 || echo ""
    fi
  done)

  node_env_prod=$(echo "$node_envs" | grep -c "^production$" 2>/dev/null || echo "0")
  node_env_dev=$(echo "$node_envs" | grep -c "^development$" 2>/dev/null || echo "0")

  # Check for common development indicators in process args or NODE_ENV
  if [[ "$node_env_dev" -gt 0 ]] || echo "$node_procs" | grep -qE "(nodemon|dev|--inspect|--inspect-brk)"; then
    register_check "NODE_ENV setting" WARN "development mode detected in $node_env_dev processes"
  elif [[ "$node_env_prod" -gt 0 ]]; then
    register_check "NODE_ENV setting" PASS "$node_env_prod processes in production mode"
  else
    register_check "NODE_ENV setting" WARN "NODE_ENV not set for running processes"
  fi
else
  register_check "Node.js processes" WARN "no Node.js processes detected"
fi

# Package.json Security Checks
section "Package.json Security"

package_files=$(find_package_json_files)
if [[ -n "$package_files" ]]; then
  package_count=$(echo "$package_files" | grep -c "package.json" || echo "0")
  register_check "Package.json files" PASS "found $package_count files"

  # Analyze first few package.json files (limit to avoid performance issues)
  analyzed=0
  while IFS= read -r package_file; do
    if [[ $analyzed -ge 5 ]]; then
      register_check "Package analysis" WARN "only analyzed first 5 package.json files (found $package_count total)"
      break
    fi

    if [[ -f "$package_file" ]]; then
      package_dir=$(dirname "$package_file")
      package_name=$(parse_package_json "$package_file" "name")

      # Check for dependency wildcards
      if grep -qE '"(\^|~|\*|latest)"' "$package_file"; then
        register_check "Dependencies: $package_name" WARN "using version ranges (^, ~, *, latest) - consider pinning"
      else
        register_check "Dependencies: $package_name" PASS "dependencies pinned"
      fi

      # Check for package-lock.json or yarn.lock
      if [[ -f "$package_dir/package-lock.json" ]] || [[ -f "$package_dir/yarn.lock" ]] || [[ -f "$package_dir/pnpm-lock.yaml" ]]; then
        register_check "Lock file: $package_name" PASS "lock file exists"
      else
        register_check "Lock file: $package_name" FAIL "no lock file - dependencies not pinned"
      fi

      # Check for scripts with dangerous patterns
      if grep -qE '"(pre|post)?(install|uninstall)"[[:space:]]*:' "$package_file"; then
        register_check "Install scripts: $package_name" WARN "package has install/uninstall scripts - review for safety"
      fi

      ((analyzed++))
    fi
  done <<< "$package_files"
else
  register_check "Package.json files" WARN "no package.json files found in common locations"
fi

# NPM Audit Vulnerabilities
section "Dependency Vulnerabilities"

if command -v npm >/dev/null 2>&1 && [[ -n "$package_files" ]]; then
  # Run npm audit on first package.json found
  first_package=$(echo "$package_files" | head -n1)
  if [[ -n "$first_package" ]]; then
    package_dir=$(dirname "$first_package")
    package_name=$(parse_package_json "$first_package" "name")

    if [[ -d "$package_dir/node_modules" ]]; then
      register_check "NPM audit: $package_name" PASS "running npm audit..."
      audit_result=$(run_npm_audit "$package_dir")

      if echo "$audit_result" | grep -q '"error"'; then
        register_check "NPM audit result" SKIP "npm audit failed to run"
      else
        # Parse vulnerability counts
        if command -v jq >/dev/null 2>&1; then
          critical=$(echo "$audit_result" | jq -r '.metadata.vulnerabilities.critical // 0' 2>/dev/null || echo "0")
          high=$(echo "$audit_result" | jq -r '.metadata.vulnerabilities.high // 0' 2>/dev/null || echo "0")
          moderate=$(echo "$audit_result" | jq -r '.metadata.vulnerabilities.moderate // 0' 2>/dev/null || echo "0")
          low=$(echo "$audit_result" | jq -r '.metadata.vulnerabilities.low // 0' 2>/dev/null || echo "0")

          if [[ "$critical" -gt 0 ]] || [[ "$high" -gt 0 ]]; then
            register_check "NPM audit result" FAIL "$critical critical, $high high, $moderate moderate, $low low vulnerabilities"
          elif [[ "$moderate" -gt 0 ]]; then
            register_check "NPM audit result" WARN "$moderate moderate, $low low vulnerabilities"
          else
            register_check "NPM audit result" PASS "no known vulnerabilities"
          fi
        else
          # Fallback without jq
          if echo "$audit_result" | grep -qE '"critical"[[:space:]]*:[[:space:]]*[1-9]'; then
            register_check "NPM audit result" FAIL "critical vulnerabilities detected (install jq for details)"
          elif echo "$audit_result" | grep -qE '"high"[[:space:]]*:[[:space:]]*[1-9]'; then
            register_check "NPM audit result" FAIL "high vulnerabilities detected (install jq for details)"
          elif echo "$audit_result" | grep -qE '"moderate"[[:space:]]*:[[:space:]]*[1-9]'; then
            register_check "NPM audit result" WARN "moderate vulnerabilities detected (install jq for details)"
          else
            register_check "NPM audit result" PASS "no critical/high vulnerabilities"
          fi
        fi
      fi
    else
      register_check "NPM audit" SKIP "node_modules not found - run npm install first"
    fi
  fi
else
  register_check "NPM audit" SKIP "npm not available or no package.json found"
fi

# Environment Variable Security
section "Environment Variable Security"

# Find .env files
env_files=$(find "${NODEJS_APP_PATHS[@]}" -maxdepth 3 -name ".env*" -type f 2>/dev/null || echo "")
if [[ -n "$env_files" ]]; then
  env_count=$(echo "$env_files" | wc -l)
  register_check ".env files" PASS "found $env_count files"

  # Check permissions on .env files
  while IFS= read -r env_file; do
    if [[ -f "$env_file" ]]; then
      perms=$(stat -c "%a" "$env_file" 2>/dev/null || stat -f "%Lp" "$env_file" 2>/dev/null || echo "unknown")

      if [[ "$perms" == "600" ]] || [[ "$perms" == "400" ]]; then
        register_check ".env perms: $(basename "$env_file")" PASS "$perms"
      elif [[ "$perms" == "640" ]] || [[ "$perms" == "440" ]]; then
        register_check ".env perms: $(basename "$env_file")" WARN "$perms (group readable)"
      else
        register_check ".env perms: $(basename "$env_file")" FAIL "$perms (too permissive)"
      fi

      # Check for sensitive data exposure
      if grep -qE "(password|secret|key|token|api|private)" "$env_file" 2>/dev/null; then
        # Check if file is in git
        env_dir=$(dirname "$env_file")
        if [[ -f "$env_dir/.gitignore" ]]; then
          if grep -q "\.env" "$env_dir/.gitignore" 2>/dev/null; then
            register_check ".env git: $(basename "$env_file")" PASS "in .gitignore"
          else
            register_check ".env git: $(basename "$env_file")" FAIL "NOT in .gitignore - secrets may be committed"
          fi
        else
          register_check ".env git: $(basename "$env_file")" WARN "no .gitignore found"
        fi
      fi
    fi
  done <<< "$env_files"
else
  register_check ".env files" WARN "no .env files found (may use different config method)"
fi

# PM2 Security Configuration
section "PM2 Security Configuration"

if command -v pm2 >/dev/null 2>&1; then
  pm2_list=$(get_pm2_list)

  if [[ "$pm2_list" != "[]" ]]; then
    # Check PM2 ecosystem file
    ecosystem_files=$(find "${NODEJS_APP_PATHS[@]}" -maxdepth 3 -name "ecosystem.config.js" -o -name "pm2.config.js" 2>/dev/null || echo "")

    if [[ -n "$ecosystem_files" ]]; then
      register_check "PM2 config" PASS "ecosystem file found"

      # Check for NODE_ENV in ecosystem config
      if grep -qE "NODE_ENV.*production" "$ecosystem_files" 2>/dev/null; then
        register_check "PM2 NODE_ENV" PASS "NODE_ENV=production configured"
      else
        register_check "PM2 NODE_ENV" WARN "NODE_ENV not set to production in config"
      fi

      # Check for process limits
      if grep -qE "(max_memory_restart|max_restarts)" "$ecosystem_files" 2>/dev/null; then
        register_check "PM2 limits" PASS "resource limits configured"
      else
        register_check "PM2 limits" WARN "no resource limits (max_memory_restart, max_restarts)"
      fi
    else
      register_check "PM2 config" WARN "no ecosystem.config.js found"
    fi

    # Check PM2 startup script
    if pm2 startup 2>&1 | grep -q "already setup"; then
      register_check "PM2 startup" PASS "startup script configured"
    else
      register_check "PM2 startup" WARN "PM2 not configured to start on boot"
    fi

    # Check for PM2 log rotation
    if pm2 ls 2>&1 | grep -q "log-rotate"; then
      register_check "PM2 log rotation" PASS "pm2-logrotate installed"
    else
      register_check "PM2 log rotation" WARN "pm2-logrotate not detected - logs may grow indefinitely"
    fi
  fi
fi

# HTTPS/TLS Configuration
section "HTTPS/TLS Configuration"

# Check for common HTTPS indicators in package.json scripts
if [[ -n "$package_files" ]]; then
  https_found=false

  while IFS= read -r package_file; do
    if grep -qE "(https|ssl|tls|cert|key\.pem)" "$package_file" 2>/dev/null; then
      https_found=true
      break
    fi
  done <<< "$package_files"

  if $https_found; then
    register_check "HTTPS indicators" PASS "HTTPS/TLS configuration found in package files"
  else
    register_check "HTTPS indicators" WARN "no HTTPS/TLS configuration detected - ensure reverse proxy handles SSL"
  fi
fi

# Check for SSL certificate files
ssl_dirs=("/etc/ssl" "/etc/letsencrypt" "/etc/nginx/ssl" "/etc/apache2/ssl")
ssl_found=false

for ssl_dir in "${ssl_dirs[@]}"; do
  if [[ -d "$ssl_dir" ]]; then
    if find "$ssl_dir" -name "*.crt" -o -name "*.pem" 2>/dev/null | grep -q .; then
      ssl_found=true
      register_check "SSL certificates" PASS "found in $ssl_dir"
      break
    fi
  fi
done

if ! $ssl_found; then
  register_check "SSL certificates" WARN "no SSL certificates found - ensure HTTPS is configured via reverse proxy"
fi

# Security Headers Check (if Express detected)
section "Application Security Features"

if [[ -n "$package_files" ]]; then
  # Check for security-related packages
  security_packages=("helmet" "cors" "express-rate-limit" "csurf" "express-validator")

  for pkg in "${security_packages[@]}"; do
    pkg_found=false
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Security: $pkg" PASS "installed"
        pkg_found=true
        break
      fi
    done <<< "$package_files"

    if ! $pkg_found; then
      case "$pkg" in
        helmet)
          register_check "Security: $pkg" FAIL "not found - helmet sets secure HTTP headers (CSP, HSTS, etc.)"
          ;;
        cors)
          register_check "Security: $pkg" WARN "not found - CORS may not be configured"
          ;;
        express-rate-limit)
          register_check "Security: $pkg" WARN "not found - no rate limiting detected"
          ;;
        csurf)
          register_check "Security: $pkg" WARN "not found - CSRF protection not detected"
          ;;
        express-validator)
          register_check "Security: $pkg" WARN "not found - input validation not detected"
          ;;
      esac
    fi
  done

  # Check for dangerous packages
  dangerous_packages=("eval" "vm2" "node-serialize")
  for pkg in "${dangerous_packages[@]}"; do
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Dangerous: $pkg" FAIL "package '$pkg' has known security vulnerabilities"
        break
      fi
    done <<< "$package_files"
  done
fi

# File Upload Security
section "File Upload Security"

if [[ -n "$package_files" ]]; then
  # Check for file upload packages
  upload_packages=("multer" "formidable" "busboy" "express-fileupload")
  upload_found=false

  for pkg in "${upload_packages[@]}"; do
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Upload library: $pkg" PASS "detected"
        upload_found=true

        # Check for upload directory with proper permissions
        package_dir=$(dirname "$package_file")
        upload_dirs=("$package_dir/uploads" "$package_dir/public/uploads" "$package_dir/tmp")

        for upload_dir in "${upload_dirs[@]}"; do
          if [[ -d "$upload_dir" ]]; then
            perms=$(stat -c "%a" "$upload_dir" 2>/dev/null || stat -f "%Lp" "$upload_dir" 2>/dev/null || echo "unknown")

            if [[ "$perms" == "755" ]] || [[ "$perms" == "750" ]]; then
              register_check "Upload dir perms" PASS "$upload_dir: $perms"
            else
              register_check "Upload dir perms" WARN "$upload_dir: $perms"
            fi

            # Check if upload directory is in gitignore
            if [[ -f "$package_dir/.gitignore" ]]; then
              if grep -q "uploads" "$package_dir/.gitignore" 2>/dev/null; then
                register_check "Upload dir git" PASS "uploads in .gitignore"
              else
                register_check "Upload dir git" WARN "uploads NOT in .gitignore - user files may be committed"
              fi
            fi
          fi
        done
        break
      fi
    done <<< "$package_files"
  done

  if ! $upload_found; then
    register_check "File uploads" SKIP "no file upload libraries detected"
  fi
fi

# Logging and Monitoring
section "Logging & Monitoring"

# Check for logging packages
logging_packages=("winston" "bunyan" "pino" "morgan")
logging_found=false

if [[ -n "$package_files" ]]; then
  for pkg in "${logging_packages[@]}"; do
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Logging: $pkg" PASS "installed"
        logging_found=true
        break
      fi
    done <<< "$package_files"
  done

  if ! $logging_found; then
    register_check "Logging library" WARN "no structured logging library detected (winston, bunyan, pino)"
  fi
fi

# Check for monitoring/APM packages
monitoring_packages=("@sentry/node" "newrelic" "@datadog/datadog-apm" "prom-client")

if [[ -n "$package_files" ]]; then
  for pkg in "${monitoring_packages[@]}"; do
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Monitoring: $pkg" PASS "installed"
        break
      fi
    done <<< "$package_files"
  done
fi

# Database Security
section "Database Security"

# Check for database packages and security
db_packages=("mongoose" "pg" "mysql" "mysql2" "mongodb" "redis" "knex" "sequelize" "typeorm")

if [[ -n "$package_files" ]]; then
  for pkg in "${db_packages[@]}"; do
    while IFS= read -r package_file; do
      if grep -qE "\"$pkg\"" "$package_file" 2>/dev/null; then
        register_check "Database: $pkg" PASS "detected"

        # Warn about SQL injection if using raw SQL packages without ORM
        if [[ "$pkg" =~ ^(mysql|mysql2|pg)$ ]]; then
          register_check "SQL injection risk" WARN "$pkg detected - ensure parameterized queries are used"
        fi
        break
      fi
    done <<< "$package_files"
  done
fi

# Development Dependencies in Production
section "Production Build Check"

if [[ -n "$package_files" ]]; then
  first_package=$(echo "$package_files" | head -n1)
  package_dir=$(dirname "$first_package")

  # Check if devDependencies exist
  if grep -q '"devDependencies"' "$first_package" 2>/dev/null; then
    # Check if node_modules includes dev packages
    if [[ -d "$package_dir/node_modules" ]]; then
      # Check for common dev packages that shouldn't be in production
      dev_indicators=("nodemon" "webpack-dev-server" "@types" "eslint" "jest" "mocha")
      dev_found=false

      for indicator in "${dev_indicators[@]}"; do
        if [[ -d "$package_dir/node_modules/$indicator" ]]; then
          dev_found=true
          break
        fi
      done

      if $dev_found; then
        register_check "Production build" WARN "devDependencies installed - use npm ci --production"
      else
        register_check "Production build" PASS "devDependencies not installed"
      fi
    fi
  fi
fi

# Print summary
print_summary
exit "$EXIT_CODE"
