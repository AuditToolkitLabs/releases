# Container Orchestration Security Audits

This directory contains security audits for container orchestration platforms.

## Audits

### kubernetes-security-audit.sh

Comprehensive Kubernetes cluster security audit aligned with **CIS Kubernetes Benchmark**:

- **Cluster Access**
  - kubectl connectivity
  - Cluster API server reachability
  - Client authentication

- **RBAC (Role-Based Access Control)**
  - ClusterRoles with wildcard permissions
  - ClusterRoleBindings to default service accounts
  - Overly permissive roles
  - ServiceAccount token usage
  - Anonymous authentication status

- **Pod Security**
  - Pod Security Policies (PSP) - Kubernetes 1.21-1.24
  - Pod Security Standards (PSS) - Kubernetes 1.25+
  - Privileged pods detection
  - Host network/PID/IPC usage
  - Root container execution
  - ReadOnlyRootFilesystem enforcement

- **Network Policies**
  - NetworkPolicy resources present
  - Default deny policies
  - Ingress/egress rules
  - Namespace isolation

- **etcd Security**
  - Encryption at rest configuration
  - etcd API access restrictions
  - Certificate-based authentication
  - Backup encryption

- **API Server Security**
  - Anonymous authentication disabled
  - Authorization mode (RBAC required)
  - Admission controllers enabled
  - Audit logging configuration
  - TLS configuration

- **Admission Controllers**
  - PodSecurityPolicy (deprecated but checked)
  - AlwaysPullImages
  - NodeRestriction
  - SecurityContextDeny
  - EventRateLimit

- **Service Account Security**
  - Automatic token mounting
  - Service account permissions
  - Token rotation policies

- **Secret Management**
  - Secret encryption at rest
  - External secret providers (Vault, etc.)
  - Secret rotation

- **Audit Logging**
  - Audit policy configuration
  - Log retention
  - Audit backend setup

- **Kubelet Security**
  - Anonymous authentication
  - Authorization mode
  - Read-only port disabled
  - Certificate rotation

## Usage

```bash
# Run Kubernetes security audit
bash audits/linux/apps/orchestration/kubernetes-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain apps --match kubernetes
```

## Requirements

- `kubectl` CLI installed and configured
- Cluster admin access (for comprehensive checks)
- Kubernetes 1.19+ recommended

## Installation

```bash
# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# Configure cluster access
kubectl config use-context <your-cluster>

# Verify access
kubectl cluster-info
```

## Remediation

### RBAC Security

Remove wildcard permissions:

```yaml
# ❌ BAD: Wildcard permissions
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: dangerous-role
rules:
- apiGroups: ["*"]
  resources: ["*"]
  verbs: ["*"]

# ✅ GOOD: Specific permissions
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: pod-reader
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list"]
```

### Pod Security Standards

Apply pod security standards (Kubernetes 1.25+):

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: production
  labels:
    pod-security.kubernetes.io/enforce: restricted
    pod-security.kubernetes.io/audit: restricted
    pod-security.kubernetes.io/warn: restricted
```

### Network Policies

Default deny all traffic:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: default
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

### etcd Encryption

Enable encryption at rest (`/etc/kubernetes/enc/encryption-config.yaml`):

```yaml
apiVersion: apiserver.config.k8s.io/v1
kind: EncryptionConfiguration
resources:
  - resources:
      - secrets
    providers:
      - aescbc:
          keys:
            - name: key1
              secret: <base64-encoded-secret>
      - identity: {}
```

Apply to API server:

```yaml
# /etc/kubernetes/manifests/kube-apiserver.yaml
spec:
  containers:
  - command:
    - kube-apiserver
    - --encryption-provider-config=/etc/kubernetes/enc/encryption-config.yaml
```

### API Server Security

Secure API server flags:

```yaml
# /etc/kubernetes/manifests/kube-apiserver.yaml
spec:
  containers:
  - command:
    - kube-apiserver
    - --anonymous-auth=false
    - --authorization-mode=RBAC,Node
    - --enable-admission-plugins=NodeRestriction,PodSecurityPolicy,AlwaysPullImages
    - --audit-log-path=/var/log/kubernetes/audit.log
    - --audit-policy-file=/etc/kubernetes/audit-policy.yaml
```

### Admission Controllers

Enable critical admission controllers:

```bash
kube-apiserver \
  --enable-admission-plugins=NodeRestriction,PodSecurityPolicy,AlwaysPullImages,SecurityContextDeny,EventRateLimit
```

### Service Account Token Mounting

Disable automatic token mounting:

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: my-service-account
automountServiceAccountToken: false
```

Or in pod spec:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  automountServiceAccountToken: false
  containers:
  - name: app
    image: myapp:latest
```

## CIS Benchmark Alignment

This audit checks compliance with:

- **CIS Kubernetes Benchmark v1.7.0** (Kubernetes 1.23+)
- Key sections:
  - 3.1: Authentication and Authorization
  - 3.2: Logging
  - 4.1: Worker Node Configuration Files
  - 5.1: RBAC and Service Accounts
  - 5.2: Pod Security Policies/Standards
  - 5.3: Network Policies and CNI
  - 5.4: Secrets Management
  - 5.7: General Policies

## References

- [CIS Kubernetes Benchmark](https://www.cisecurity.org/benchmark/kubernetes)
- [Kubernetes Security Best Practices](https://kubernetes.io/docs/concepts/security/overview/)
- [Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/)
- [RBAC Documentation](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)
- [Network Policies](https://kubernetes.io/docs/concepts/services-networking/network-policies/)
