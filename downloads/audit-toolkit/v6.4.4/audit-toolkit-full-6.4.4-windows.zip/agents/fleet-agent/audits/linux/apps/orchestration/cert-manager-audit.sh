#!/usr/bin/env bash
# cert-manager-audit.sh — Kubernetes cert-manager Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: Custom (Certificate Management)
# - NIST SP 800-53: SC-12, SC-13, SC-17, IA-5(2)
# - SOC 2: CC6.1, CC6.6, CC6.7
# - PCI DSS: 4.1, 8.2.1
# - ISO 27001: A.10.1.2, A.13.1.1
#
# Checks:
# - cert-manager installation and version
# - Issuer/ClusterIssuer configuration
# - Certificate resources and expiration
# - Webhook TLS configuration
# - RBAC permissions
# - Challenge solvers security
#
# @elevation: partial
# @elevation-reason: Uses kubectl with user's kubeconfig context
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../../lib/svc.sh"

setup_colors

# ─────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────

# cert-manager namespace (default)
CERT_MANAGER_NS="${CERT_MANAGER_NS:-cert-manager}"

# Expiration warning threshold (days)
CERT_EXPIRY_WARN_DAYS="${CERT_EXPIRY_WARN_DAYS:-30}"
CERT_EXPIRY_CRIT_DAYS="${CERT_EXPIRY_CRIT_DAYS:-7}"

# ─────────────────────────────────────────────────────────────
# Helper Functions
# ─────────────────────────────────────────────────────────────

# Check if kubectl is available and cluster is reachable
check_kubectl() {
  if ! command -v kubectl >/dev/null 2>&1; then
    return 1
  fi

  # Check if cluster is reachable
  if ! kubectl cluster-info >/dev/null 2>&1; then
    return 1
  fi

  return 0
}

# Get cert-manager version
get_cert_manager_version() {
  kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" \
    -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null | \
    grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo ""
}

# Get all namespaces with certificates
get_cert_namespaces() {
  kubectl get certificates --all-namespaces -o jsonpath='{.items[*].metadata.namespace}' 2>/dev/null | \
    tr ' ' '\n' | sort -u
}

section "Kubernetes cert-manager Security Audit"

# ─────────────────────────────────────────────────────────────
# Prerequisite Checks
# ─────────────────────────────────────────────────────────────

if ! check_kubectl; then
  register_check "kubectl available" SKIP "kubectl not available or cluster not reachable"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "kubectl available" PASS "cluster reachable"

# Check if cert-manager is installed
if ! kubectl get namespace "$CERT_MANAGER_NS" >/dev/null 2>&1; then
  register_check "cert-manager namespace" SKIP "cert-manager not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "cert-manager namespace" PASS "$CERT_MANAGER_NS"

# ─────────────────────────────────────────────────────────────
# cert-manager Core Components
# ─────────────────────────────────────────────────────────────

section "cert-manager Core Components"

# Check cert-manager deployment
if kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" >/dev/null 2>&1; then
  replicas=$(kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" \
    -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
  desired=$(kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" \
    -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "0")

  if [[ "$replicas" == "$desired" ]] && [[ "$replicas" -gt 0 ]]; then
    register_check "cert-manager deployment" PASS "$replicas/$desired replicas ready"
  else
    register_check "cert-manager deployment" FAIL "$replicas/$desired replicas ready"
  fi
else
  register_check "cert-manager deployment" FAIL "not found"
fi

# Check version
version=$(get_cert_manager_version)
if [[ -n "$version" ]]; then
  # Check if version is recent (v1.x is current)
  major_version=$(echo "$version" | grep -oE '^v[0-9]+' | tr -d 'v')
  if [[ "$major_version" -ge 1 ]]; then
    register_check "cert-manager version" PASS "$version"
  else
    register_check "cert-manager version" WARN "$version (consider upgrading)"
  fi
else
  register_check "cert-manager version" WARN "unable to determine"
fi

# Check cert-manager-webhook
if kubectl get deployment cert-manager-webhook -n "$CERT_MANAGER_NS" >/dev/null 2>&1; then
  webhook_replicas=$(kubectl get deployment cert-manager-webhook -n "$CERT_MANAGER_NS" \
    -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")

  if [[ "$webhook_replicas" -gt 0 ]]; then
    register_check "cert-manager-webhook" PASS "$webhook_replicas replicas ready"
  else
    register_check "cert-manager-webhook" FAIL "no replicas ready"
  fi
else
  register_check "cert-manager-webhook" WARN "not found"
fi

# Check cert-manager-cainjector
if kubectl get deployment cert-manager-cainjector -n "$CERT_MANAGER_NS" >/dev/null 2>&1; then
  cainjector_replicas=$(kubectl get deployment cert-manager-cainjector -n "$CERT_MANAGER_NS" \
    -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")

  if [[ "$cainjector_replicas" -gt 0 ]]; then
    register_check "cert-manager-cainjector" PASS "$cainjector_replicas replicas ready"
  else
    register_check "cert-manager-cainjector" WARN "no replicas ready"
  fi
else
  register_check "cert-manager-cainjector" WARN "not found"
fi

# ─────────────────────────────────────────────────────────────
# Issuer/ClusterIssuer Configuration
# ─────────────────────────────────────────────────────────────

section "Certificate Issuers"

# Check ClusterIssuers
cluster_issuers=$(kubectl get clusterissuers -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo "")
if [[ -n "$cluster_issuers" ]]; then
  issuer_count=$(echo "$cluster_issuers" | wc -w)
  register_check "ClusterIssuers found" PASS "$issuer_count issuer(s)"

  # Check each issuer's status
  for issuer in $cluster_issuers; do
    ready=$(kubectl get clusterissuer "$issuer" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "")
    if [[ "$ready" == "True" ]]; then
      register_check "ClusterIssuer: $issuer" PASS "ready"
    else
      reason=$(kubectl get clusterissuer "$issuer" -o jsonpath='{.status.conditions[?(@.type=="Ready")].reason}' 2>/dev/null || echo "unknown")
      register_check "ClusterIssuer: $issuer" WARN "not ready: $reason"
    fi

    # Check issuer type (ACME vs CA vs Vault etc.)
    issuer_type=""
    if kubectl get clusterissuer "$issuer" -o jsonpath='{.spec.acme}' 2>/dev/null | grep -q server; then
      issuer_type="ACME"

      # Check ACME solver (HTTP01 vs DNS01)
      if kubectl get clusterissuer "$issuer" -o jsonpath='{.spec.acme.solvers}' 2>/dev/null | grep -q dns01; then
        register_check "ClusterIssuer $issuer solver" PASS "DNS01 (recommended)"
      elif kubectl get clusterissuer "$issuer" -o jsonpath='{.spec.acme.solvers}' 2>/dev/null | grep -q http01; then
        register_check "ClusterIssuer $issuer solver" PASS "HTTP01"
      fi
    elif kubectl get clusterissuer "$issuer" -o jsonpath='{.spec.ca}' 2>/dev/null | grep -q secretName; then
      issuer_type="CA"
    elif kubectl get clusterissuer "$issuer" -o jsonpath='{.spec.vault}' 2>/dev/null | grep -q server; then
      issuer_type="Vault"
      register_check "ClusterIssuer $issuer type" PASS "HashiCorp Vault"
    fi
  done
else
  register_check "ClusterIssuers" WARN "no ClusterIssuers found"
fi

# Check namespace Issuers
namespaced_issuers=$(kubectl get issuers --all-namespaces -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name} {end}' 2>/dev/null || echo "")
if [[ -n "$namespaced_issuers" ]]; then
  issuer_count=$(echo "$namespaced_issuers" | wc -w)
  register_check "Namespace Issuers found" PASS "$issuer_count issuer(s)"
else
  register_check "Namespace Issuers" SKIP "none configured"
fi

# ─────────────────────────────────────────────────────────────
# Certificate Resources
# ─────────────────────────────────────────────────────────────

section "Certificate Resources"

# Get all certificates across namespaces
all_certs=$(kubectl get certificates --all-namespaces -o json 2>/dev/null || echo '{"items":[]}')
cert_count=$(echo "$all_certs" | grep -c '"name"' 2>/dev/null || echo "0")

if [[ "$cert_count" -gt 0 ]]; then
  register_check "Certificate resources" PASS "$cert_count certificate(s) found"

  # Check certificate expiration
  expiring_soon=0
  expired=0

  while read -r cert_info; do
    [[ -z "$cert_info" ]] && continue

    ns=$(echo "$cert_info" | cut -d'|' -f1)
    name=$(echo "$cert_info" | cut -d'|' -f2)
    not_after=$(echo "$cert_info" | cut -d'|' -f3)
    ready=$(echo "$cert_info" | cut -d'|' -f4)

    if [[ -n "$not_after" ]]; then
      # Calculate days until expiration
      expiry_epoch=$(date -d "$not_after" +%s 2>/dev/null || echo "0")
      now_epoch=$(date +%s)
      days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

      if [[ "$days_left" -lt 0 ]]; then
        register_check "Certificate $ns/$name" FAIL "EXPIRED"
        ((expired++))
      elif [[ "$days_left" -lt "$CERT_EXPIRY_CRIT_DAYS" ]]; then
        register_check "Certificate $ns/$name" FAIL "expires in $days_left days"
        ((expiring_soon++))
      elif [[ "$days_left" -lt "$CERT_EXPIRY_WARN_DAYS" ]]; then
        register_check "Certificate $ns/$name" WARN "expires in $days_left days"
        ((expiring_soon++))
      else
        if [[ "$ready" == "True" ]]; then
          register_check "Certificate $ns/$name" PASS "valid ($days_left days left)"
        else
          register_check "Certificate $ns/$name" WARN "not ready ($days_left days left)"
        fi
      fi
    fi
  done < <(echo "$all_certs" | jq -r '.items[] | "\(.metadata.namespace)|\(.metadata.name)|\(.status.notAfter // "")|\(.status.conditions[]? | select(.type=="Ready") | .status)"' 2>/dev/null)

  if [[ "$expired" -gt 0 ]]; then
    register_check "Expired certificates" FAIL "$expired certificate(s) expired"
  fi

  if [[ "$expiring_soon" -gt 0 ]]; then
    register_check "Expiring certificates" WARN "$expiring_soon certificate(s) expiring soon"
  fi
else
  register_check "Certificate resources" SKIP "no certificates found"
fi

# ─────────────────────────────────────────────────────────────
# Security Configuration
# ─────────────────────────────────────────────────────────────

section "Security Configuration"

# Check webhook TLS
webhook_secret=$(kubectl get deployment cert-manager-webhook -n "$CERT_MANAGER_NS" \
  -o jsonpath='{.spec.template.spec.containers[0].args}' 2>/dev/null || echo "")

if echo "$webhook_secret" | grep -q "tls"; then
  register_check "Webhook TLS" PASS "TLS enabled"
else
  register_check "Webhook TLS" WARN "TLS configuration not verified"
fi

# Check if running as non-root
security_context=$(kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" \
  -o jsonpath='{.spec.template.spec.securityContext}' 2>/dev/null || echo "")

if echo "$security_context" | grep -q "runAsNonRoot"; then
  register_check "Non-root execution" PASS "runAsNonRoot enabled"
else
  register_check "Non-root execution" WARN "runAsNonRoot not explicitly set"
fi

# Check Pod Security
if echo "$security_context" | grep -q "readOnlyRootFilesystem"; then
  register_check "Read-only root filesystem" PASS "enabled"
else
  register_check "Read-only root filesystem" WARN "not set"
fi

# Check resource limits
resources=$(kubectl get deployment cert-manager -n "$CERT_MANAGER_NS" \
  -o jsonpath='{.spec.template.spec.containers[0].resources}' 2>/dev/null || echo "")

if echo "$resources" | grep -q "limits"; then
  register_check "Resource limits" PASS "configured"
else
  register_check "Resource limits" WARN "no limits set"
fi

# ─────────────────────────────────────────────────────────────
# RBAC Permissions
# ─────────────────────────────────────────────────────────────

section "RBAC Configuration"

# Check ClusterRoles
cert_manager_roles=$(kubectl get clusterrolebindings -o json 2>/dev/null | \
  jq -r '.items[] | select(.subjects[]?.namespace == "'"$CERT_MANAGER_NS"'") | .roleRef.name' 2>/dev/null || echo "")

if [[ -n "$cert_manager_roles" ]]; then
  role_count=$(echo "$cert_manager_roles" | wc -w)
  register_check "RBAC bindings" PASS "$role_count ClusterRoleBinding(s)"

  # Check for overly permissive roles
  for role in $cert_manager_roles; do
    # Check if role has cluster-admin
    if [[ "$role" == "cluster-admin" ]]; then
      register_check "RBAC: $role" FAIL "cluster-admin is overly permissive"
    else
      register_check "RBAC: $role" PASS "bound"
    fi
  done
else
  register_check "RBAC bindings" WARN "no bindings found"
fi

# ─────────────────────────────────────────────────────────────
# Challenge Solvers
# ─────────────────────────────────────────────────────────────

section "ACME Challenge Configuration"

# Check for pending challenges
pending_challenges=$(kubectl get challenges --all-namespaces -o json 2>/dev/null | \
  jq -r '.items[] | select(.status.state != "valid") | "\(.metadata.namespace)/\(.metadata.name)"' 2>/dev/null || echo "")

if [[ -n "$pending_challenges" ]]; then
  count=$(echo "$pending_challenges" | wc -w)
  register_check "Pending challenges" WARN "$count pending challenge(s)"

  for challenge in $pending_challenges; do
    state=$(kubectl get challenge "$challenge" -o jsonpath='{.status.state}' 2>/dev/null || echo "unknown")
    register_check "Challenge: $challenge" WARN "state: $state"
  done
else
  register_check "Pending challenges" PASS "none"
fi

# Check for failed orders
failed_orders=$(kubectl get orders --all-namespaces -o json 2>/dev/null | \
  jq -r '.items[] | select(.status.state == "errored") | "\(.metadata.namespace)/\(.metadata.name)"' 2>/dev/null || echo "")

if [[ -n "$failed_orders" ]]; then
  count=$(echo "$failed_orders" | wc -w)
  register_check "Failed orders" WARN "$count failed order(s)"
else
  register_check "Failed orders" PASS "none"
fi

# ─────────────────────────────────────────────────────────────
# CertificateRequest Approver
# ─────────────────────────────────────────────────────────────

section "Certificate Approval Policy"

# Check if approval is required (cert-manager 1.3+)
approver_policy=$(kubectl get deployment cert-manager-approver-policy -n "$CERT_MANAGER_NS" 2>/dev/null || echo "")
if [[ -n "$approver_policy" ]]; then
  register_check "Approver policy" PASS "deployed"
else
  register_check "Approver policy" SKIP "not deployed (optional component)"
fi

# Check CertificateRequestPolicy CRDs
if kubectl api-resources | grep -q "certificaterequestpolicies"; then
  policy_count=$(kubectl get certificaterequestpolicies --all-namespaces -o json 2>/dev/null | \
    jq '.items | length' 2>/dev/null || echo "0")

  if [[ "$policy_count" -gt 0 ]]; then
    register_check "Certificate policies" PASS "$policy_count policy/policies defined"
  else
    register_check "Certificate policies" WARN "no policies defined"
  fi
else
  register_check "Certificate policies" SKIP "CRD not installed"
fi

# ─────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────

print_summary
exit "$EXIT_CODE"
