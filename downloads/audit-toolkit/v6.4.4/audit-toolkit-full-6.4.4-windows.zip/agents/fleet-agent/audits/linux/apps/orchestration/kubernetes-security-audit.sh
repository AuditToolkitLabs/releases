#!/usr/bin/env bash
# Kubernetes Security Audit
# Checks Kubernetes cluster security including RBAC, network policies, pod security, and CIS Benchmark compliance
#
# @elevation: partial
# @elevation-reason: kubectl uses user context; kubelet checks may need root
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"

# === Configuration ===
K8S_CONTEXTS=""
CURRENT_CONTEXT=""
K8S_VERSION=""
API_SERVER=""
KUBECTL_AVAILABLE=false

# === Performance: Cache variables ===
NAMESPACES=""
PODS_INFO=""
SERVICES_INFO=""
RBAC_ROLES=""
NETWORK_POLICIES=""

# === Helper Functions ===

# Check if kubectl is available
check_kubectl() {
  if command -v kubectl >/dev/null 2>&1; then
    K8S_CONTEXTS=$(kubectl config get-contexts -o name 2>/dev/null || echo "")
    CURRENT_CONTEXT=$(kubectl config current-context 2>/dev/null || echo "")
    KUBECTL_AVAILABLE=true
    return 0
  fi
  KUBECTL_AVAILABLE=false
  return 1
}

# Get Kubernetes version
get_k8s_version() {
  if [[ -n "$K8S_VERSION" ]]; then
    echo "$K8S_VERSION"
    return 0
  fi

  if [[ "$KUBECTL_AVAILABLE" == true ]]; then
    version=$(kubectl version --short 2>/dev/null | grep "Server Version" | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    K8S_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Get namespaces
get_namespaces() {
  if [[ -n "$NAMESPACES" ]]; then
    echo "$NAMESPACES"
    return 0
  fi

  if [[ "$KUBECTL_AVAILABLE" == true ]]; then
    ns=$(kubectl get namespaces -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo "")
    NAMESPACES="$ns"
    echo "$ns"
  else
    echo ""
  fi
}

# === MAIN AUDIT ===

section "Kubernetes Detection"

if ! check_kubectl; then
  register_check "kubectl Available" SKIP "kubectl not found in PATH"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "kubectl Available" PASS "kubectl command available"

# Check current context
if [[ -n "$CURRENT_CONTEXT" ]]; then
  register_check "Current Context" PASS "$CURRENT_CONTEXT"
else
  register_check "Current Context" FAIL "No current context set"
  print_summary
  exit "$EXIT_CODE"
fi

# Check kubectl connectivity
if ! kubectl cluster-info >/dev/null 2>&1; then
  register_check "Cluster Connectivity" FAIL "Cannot connect to cluster (check kubeconfig)"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Cluster Connectivity" PASS "Connected to Kubernetes cluster"

# === Kubernetes Version ===
section "Kubernetes Version"

k8s_ver=$(get_k8s_version)
if [[ "$k8s_ver" != "unknown" ]]; then
  register_check "Kubernetes Version" PASS "$k8s_ver"

  # Check for old versions (warn if < 1.24)
  ver_num=$(echo "$k8s_ver" | grep -oE '[0-9]+\.[0-9]+' | tr -d 'v')
  major=$(echo "$ver_num" | cut -d. -f1)
  minor=$(echo "$ver_num" | cut -d. -f2)

  if [[ "$major" -eq 1 && "$minor" -lt 24 ]]; then
    register_check "Version EOL" WARN "Kubernetes $k8s_ver may be EOL (check support status)"
  else
    register_check "Version EOL" PASS "Kubernetes version in supported range"
  fi
else
  register_check "Kubernetes Version" WARN "Unable to determine Kubernetes version"
fi

# === RBAC Configuration ===
section "RBAC (Role-Based Access Control)"

# Check if RBAC is enabled
rbac_enabled=$(kubectl api-versions 2>/dev/null | grep -c "rbac.authorization.k8s.io" || echo "0")
if [[ "$rbac_enabled" -gt 0 ]]; then
  register_check "RBAC Enabled" PASS "RBAC API available"
else
  register_check "RBAC Enabled" FAIL "RBAC not enabled (critical security feature)"
fi

# Check for cluster roles
cluster_roles=$(kubectl get clusterroles 2>/dev/null | wc -l || echo "0")
if [[ "$cluster_roles" -gt 0 ]]; then
  register_check "ClusterRoles" PASS "$cluster_roles ClusterRoles defined"
else
  register_check "ClusterRoles" WARN "No ClusterRoles found"
fi

# Check for ClusterRoleBindings
cluster_role_bindings=$(kubectl get clusterrolebindings 2>/dev/null | wc -l || echo "0")
if [[ "$cluster_role_bindings" -gt 0 ]]; then
  register_check "ClusterRoleBindings" PASS "$cluster_role_bindings ClusterRoleBindings"
fi

# Check for overly permissive bindings (cluster-admin)
admin_bindings=$(kubectl get clusterrolebindings -o json 2>/dev/null | grep -c '"cluster-admin"' || echo "0")
if [[ "$admin_bindings" -gt 0 ]]; then
  register_check "cluster-admin Bindings" WARN "$admin_bindings cluster-admin binding(s) (review for least privilege)"
else
  register_check "cluster-admin Bindings" PASS "No cluster-admin bindings (good)"
fi

# Check for default service account usage
default_sa_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"serviceAccount": "default"' || echo "0")
if [[ "$default_sa_pods" -gt 10 ]]; then
  register_check "Default ServiceAccount" WARN "$default_sa_pods pods using default SA (create specific SAs)"
elif [[ "$default_sa_pods" -gt 0 ]]; then
  register_check "Default ServiceAccount" PASS "$default_sa_pods pods using default SA (acceptable)"
else
  register_check "Default ServiceAccount" PASS "No pods using default ServiceAccount"
fi

# === Pod Security ===
section "Pod Security"

# Check for Pod Security Policies (deprecated in 1.21, removed in 1.25)
if [[ "$minor" -lt 25 ]]; then
  psp_count=$(kubectl get psp 2>/dev/null | wc -l || echo "0")
  if [[ "$psp_count" -gt 0 ]]; then
    register_check "Pod Security Policies" PASS "$psp_count PSP(s) configured"
  else
    register_check "Pod Security Policies" WARN "No PSPs configured (deprecated, use Pod Security Standards)"
  fi
fi

# Check for Pod Security Standards (namespace labels)
namespaces=$(get_namespaces)
ns_count=$(echo "$namespaces" | wc -w)

pss_labeled=0
for ns in $namespaces; do
  labels=$(kubectl get namespace "$ns" -o json 2>/dev/null | grep -c "pod-security.kubernetes.io" || echo "0")
  if [[ "$labels" -gt 0 ]]; then
    pss_labeled=$((pss_labeled + 1))
  fi
done

if [[ "$pss_labeled" -gt 0 ]]; then
  register_check "Pod Security Standards" PASS "$pss_labeled/$ns_count namespaces with PSS labels"
else
  register_check "Pod Security Standards" WARN "No Pod Security Standard labels found (add pod-security.kubernetes.io labels)"
fi

# Check for privileged containers
priv_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"privileged": true' || echo "0")
if [[ "$priv_pods" -eq 0 ]]; then
  register_check "Privileged Containers" PASS "No privileged containers running"
elif [[ "$priv_pods" -lt 5 ]]; then
  register_check "Privileged Containers" WARN "$priv_pods privileged container(s) running"
else
  register_check "Privileged Containers" FAIL "$priv_pods privileged containers (minimize privileged pods)"
fi

# Check for hostNetwork usage
host_network_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"hostNetwork": true' || echo "0")
if [[ "$host_network_pods" -eq 0 ]]; then
  register_check "hostNetwork Usage" PASS "No pods using hostNetwork"
else
  register_check "hostNetwork Usage" WARN "$host_network_pods pod(s) using hostNetwork (review necessity)"
fi

# Check for hostPID usage
host_pid_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"hostPID": true' || echo "0")
if [[ "$host_pid_pods" -eq 0 ]]; then
  register_check "hostPID Usage" PASS "No pods using hostPID"
else
  register_check "hostPID Usage" WARN "$host_pid_pods pod(s) using hostPID (security risk)"
fi

# Check for hostPath volumes
host_path_vols=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"hostPath"' || echo "0")
if [[ "$host_path_vols" -eq 0 ]]; then
  register_check "hostPath Volumes" PASS "No hostPath volumes in use"
else
  register_check "hostPath Volumes" WARN "$host_path_vols hostPath volume(s) (minimize usage)"
fi

# === Network Policies ===
section "Network Security"

# Check for NetworkPolicies
network_policies=$(kubectl get networkpolicies --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$network_policies" -gt 0 ]]; then
  register_check "Network Policies" PASS "$network_policies NetworkPolicy resource(s) configured"
else
  register_check "Network Policies" WARN "No NetworkPolicies found (pods can communicate freely)"
fi

# Check default deny policies
for ns in $namespaces; do
  default_deny=$(kubectl get networkpolicies -n "$ns" -o json 2>/dev/null | grep -c '"podSelector": {}' || echo "0")
  if [[ "$default_deny" -gt 0 ]]; then
    register_check "Default Deny ($ns)" PASS "Default deny policy in namespace $ns"
    break
  fi
done

# === Secret Management ===
section "Secrets Management"

# Check for secrets
secrets=$(kubectl get secrets --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$secrets" -gt 0 ]]; then
  register_check "Secrets" PASS "$secrets Secret resource(s) in cluster"
else
  register_check "Secrets" WARN "No Secrets found (applications may use insecure config)"
fi

# Check etcd encryption (requires API server access)
encryption_config=$(kubectl get --raw /api/v1/namespaces/kube-system/secrets 2>/dev/null | head -c 100 || echo "")
if [[ -n "$encryption_config" ]]; then
  register_check "etcd Encryption" WARN "Cannot verify etcd encryption (requires node access)"
else
  register_check "etcd Encryption" SKIP "Unable to check etcd encryption"
fi

# Check for secrets in environment variables
env_secrets=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"secretKeyRef"' || echo "0")
if [[ "$env_secrets" -gt 0 ]]; then
  register_check "Secrets in Env" PASS "$env_secrets pod(s) using secretKeyRef (secure method)"
fi

# === API Server Security ===
section "API Server Configuration"

# Check if API server is accessible
api_server=$(kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}' 2>/dev/null || echo "")
if [[ -n "$api_server" ]]; then
  register_check "API Server" PASS "$api_server"

  # Check if TLS is enabled
  if echo "$api_server" | grep -q "https://"; then
    register_check "API Server TLS" PASS "HTTPS enabled"
  else
    register_check "API Server TLS" FAIL "API server not using HTTPS"
  fi
fi

# Check anonymous auth (CIS 1.2.1)
# Note: Requires access to API server flags which may not be available
register_check "Anonymous Auth" WARN "Check --anonymous-auth=false on API server (requires node access)"

# Check for admission controllers
admission_controllers=$(kubectl get pods -n kube-system -o json 2>/dev/null | grep "kube-apiserver" | grep -oE "\-\-enable-admission-plugins=[^ ]*" || echo "")
if [[ -n "$admission_controllers" ]]; then
  register_check "Admission Controllers" PASS "Configured: $admission_controllers"

  # Check for important admission controllers
  if echo "$admission_controllers" | grep -q "PodSecurityPolicy"; then
    register_check "PodSecurityPolicy AC" PASS "PodSecurityPolicy admission controller enabled"
  fi

  if echo "$admission_controllers" | grep -q "NodeRestriction"; then
    register_check "NodeRestriction AC" PASS "NodeRestriction admission controller enabled"
  fi
fi

# === Resource Limits & Quotas ===
section "Resource Management"

# Check for ResourceQuotas
resource_quotas=$(kubectl get resourcequotas --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$resource_quotas" -gt 0 ]]; then
  register_check "ResourceQuotas" PASS "$resource_quotas ResourceQuota(s) configured"
else
  register_check "ResourceQuotas" WARN "No ResourceQuotas (namespaces can consume unlimited resources)"
fi

# Check for LimitRanges
limit_ranges=$(kubectl get limitranges --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$limit_ranges" -gt 0 ]]; then
  register_check "LimitRanges" PASS "$limit_ranges LimitRange(s) configured"
else
  register_check "LimitRanges" WARN "No LimitRanges (pods can request unlimited resources)"
fi

# Check for pods without resource limits
pods_no_limits=$(kubectl get pods --all-namespaces -o json 2>/dev/null | jq '[.items[] | select(.spec.containers[].resources.limits == null)] | length' 2>/dev/null || echo "unknown")
if [[ "$pods_no_limits" != "unknown" && "$pods_no_limits" -gt 0 ]]; then
  register_check "Pod Resource Limits" WARN "$pods_no_limits pod(s) without resource limits"
elif [[ "$pods_no_limits" == "0" ]]; then
  register_check "Pod Resource Limits" PASS "All pods have resource limits"
fi

# === Image Security ===
section "Container Image Security"

# Check for image pull policies
always_pull=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"imagePullPolicy": "Always"' || echo "0")
total_pods=$(kubectl get pods --all-namespaces --no-headers 2>/dev/null | wc -l || echo "1")

if [[ "$total_pods" -gt 0 ]]; then
  pull_ratio=$((always_pull * 100 / total_pods))
  if [[ "$pull_ratio" -gt 80 ]]; then
    register_check "Image Pull Policy" PASS "$pull_ratio% pods use 'Always' pull policy"
  else
    register_check "Image Pull Policy" WARN "Only $pull_ratio% pods use 'Always' (recommend for production)"
  fi
fi

# Check for latest image tags
latest_tags=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c ':latest' || echo "0")
if [[ "$latest_tags" -eq 0 ]]; then
  register_check "Image Tag 'latest'" PASS "No containers using ':latest' tag"
else
  register_check "Image Tag 'latest'" WARN "$latest_tags container(s) using ':latest' (use specific versions)"
fi

# Check for private registry usage
private_registry=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep '"image"' | grep -v -c 'docker.io\|k8s.gcr.io\|gcr.io\|quay.io' || echo "0")
if [[ "$private_registry" -gt 0 ]]; then
  register_check "Private Registry" PASS "$private_registry image(s) from private registry"
fi

# === Service Account Security ===
section "Service Accounts"

# Check for service accounts
service_accounts=$(kubectl get serviceaccounts --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$service_accounts" -gt 0 ]]; then
  register_check "Service Accounts" PASS "$service_accounts ServiceAccount(s) in cluster"
fi

# Check for automountServiceAccountToken disabled
automount_disabled=$(kubectl get serviceaccounts --all-namespaces -o json 2>/dev/null | grep -c '"automountServiceAccountToken": false' || echo "0")
if [[ "$automount_disabled" -gt 0 ]]; then
  register_check "Token Automount" PASS "$automount_disabled SA(s) with automount disabled (secure)"
fi

# === Kubelet Security ===
section "Kubelet Configuration"

# Note: Many kubelet checks require node access
register_check "Kubelet Security" WARN "Verify on nodes: --anonymous-auth=false, --authorization-mode=Webhook, --read-only-port=0"

# Check if nodes are ready
nodes=$(kubectl get nodes --no-headers 2>/dev/null | wc -l || echo "0")
ready_nodes=$(kubectl get nodes --no-headers 2>/dev/null | grep -c " Ready " || echo "0")

if [[ "$nodes" -gt 0 ]]; then
  register_check "Cluster Nodes" PASS "$ready_nodes/$nodes nodes Ready"

  if [[ "$ready_nodes" -lt "$nodes" ]]; then
    register_check "Node Health" WARN "Some nodes not Ready"
  fi
fi

# === Audit Logging ===
section "Audit & Logging"

# Check if audit policy is configured (requires API server access)
register_check "Audit Policy" WARN "Verify --audit-policy-file configured on API server (requires node access)"

# Check for logging infrastructure
fluentd_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"fluentd"' || echo "0")
fluentbit_pods=$(kubectl get pods --all-namespaces -o json 2>/dev/null | grep -c '"fluent-bit"' || echo "0")
logging_pods=$((fluentd_pods + fluentbit_pods))

if [[ "$logging_pods" -gt 0 ]]; then
  register_check "Logging Infrastructure" PASS "Log aggregation pods detected ($logging_pods)"
else
  register_check "Logging Infrastructure" WARN "No log aggregation detected (consider Fluentd/Fluent Bit)"
fi

# === Ingress Security ===
section "Ingress Configuration"

# Check for Ingress resources
ingresses=$(kubectl get ingress --all-namespaces 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$ingresses" -gt 0 ]]; then
  register_check "Ingress Resources" PASS "$ingresses Ingress resource(s) configured"

  # Check for TLS
  tls_ingresses=$(kubectl get ingress --all-namespaces -o json 2>/dev/null | grep -c '"tls"' || echo "0")
  if [[ "$tls_ingresses" -gt 0 ]]; then
    register_check "Ingress TLS" PASS "$tls_ingresses Ingress(es) with TLS configured"
  else
    register_check "Ingress TLS" WARN "No Ingress resources have TLS (HTTP only)"
  fi
else
  register_check "Ingress Resources" SKIP "No Ingress resources found"
fi

# === CIS Kubernetes Benchmark Highlights ===
section "CIS Benchmark Recommendations"

register_check "CIS 1.1.1" WARN "Verify API server pod specification file permissions are 644 or more restrictive"
register_check "CIS 1.2.1" WARN "Verify --anonymous-auth=false on API server"
register_check "CIS 1.2.6" WARN "Verify --kubelet-certificate-authority is set"
register_check "CIS 1.2.7" WARN "Verify --authorization-mode includes RBAC"
register_check "CIS 1.2.12" WARN "Verify --etcd-certfile and --etcd-keyfile are set"
register_check "CIS 3.2.1" WARN "Verify --audit-log-path is set"
register_check "CIS 4.2.1" WARN "Verify --anonymous-auth=false on Kubelet"
register_check "CIS 4.2.2" WARN "Verify --authorization-mode=Webhook on Kubelet"

# Note for full CIS compliance
register_check "Full CIS Scan" WARN "For complete CIS Benchmark scan, use kube-bench tool: https://github.com/aquasecurity/kube-bench"

# === Summary ===
print_summary

exit "$EXIT_CODE"
