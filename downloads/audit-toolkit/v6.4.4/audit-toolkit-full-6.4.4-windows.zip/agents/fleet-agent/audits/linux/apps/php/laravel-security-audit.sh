#!/usr/bin/env bash
# laravel-security-audit.sh
# Purpose : Non-destructive audit for Laravel apps (.env hygiene, perms, caches, headers, queues)
# Usage   : sudo ./laravel-security-audit.sh [-p APP_PATH] [--url URL]
# Env     : LOG_FILE=/var/log/laravel-audit.log
# Exit    : 0=OK, 1=Errors, 2=Warnings only

# @elevation: none
# @elevation-reason: File and directory permission checks only
#
set -euo pipefail

# Source multi-OS compatibility shims
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"

APP_PATH=""
TARGET_URL=""
LOG_FILE="${LOG_FILE:-/var/log/laravel-audit.log}"
STRICT=0

RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

OK=0
WARN=0
ERR=0
STEPS=0

# Replace printf %(... )T date usage (not supported on older macOS bash)
log() {
  # Use external date for portability across Bash versions / macOS
  printf '[%s] [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" "$2" | tee -a "$LOG_FILE" >/dev/null
}

ok() {
  printf '%b[PASS]%b %s\n' "$GREEN" "$NC" "$1"
  log PASS "$1"
  OK=$((OK+1))
}

warn() {
  printf '%b[WARN]%b %s\n' "$YELLOW" "$NC" "$1"
  log WARN "$1"
  WARN=$((WARN+1))
}

fail() {
  printf '%b[FAIL]%b %s\n' "$RED" "$NC" "$1" 1>&2
  log FAIL "$1"
  ERR=$((ERR+1))
}

skip() {
  printf '%b[SKIP]%b %s\n' "$BLUE" "$NC" "$1"
  log SKIP "$1"
}

info() {
  printf '%b[INFO]%b %s\n' "$BLUE" "$NC" "$1"
  log INFO "$1"
}

section() {
  echo
  printf -- '---- %s ----\n' "$1" | tee -a "$LOG_FILE" >/dev/null
  STEPS=$((STEPS+1))
}

# ------------------------------
# Parse CLI arguments
# ------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    -p|--app-path)
      APP_PATH="$2"; shift 2;;
    -u|--url)
      TARGET_URL="$2"; shift 2;;
    --strict)
      STRICT=1; shift;;
    -h|--help)
      echo "Usage: $0 [-p APP_PATH] [--url URL] [--strict]"
      exit 0;;
    *)
      echo "Unknown option: $1"
      exit 1;;
  esac
done

# --- Auto-disable color if output is not a TTY or NO_COLOR is set ---
if [[ ! -t 1 || "${NO_COLOR:-}" == "1" ]]; then
  RED=''
  YELLOW=''
  GREEN=''
  BLUE=''
  NC=''
fi

# --- Ensure LOG_FILE directory exists (attempt) and writable (fallback) ---
log_dir="$(dirname "$LOG_FILE")"
if [[ ! -d "$log_dir" ]]; then
  if mkdir -p "$log_dir" 2>/dev/null; then
    ok "Created log directory: $log_dir"
  else
    warn "Cannot create log directory: $log_dir (will fallback to temp log)"
  fi
fi

# Check free space on log filesystem (warn if <10MB)
if df_out=$(df -P "$log_dir" 2>/dev/null | awk 'NR==2{print $4}'); then
  if [[ "$df_out" =~ ^[0-9]+$ ]] && (( df_out < 10240 )); then
    warn "Low free space on log filesystem for $log_dir: ${df_out}K"
  fi
fi

# Helper: portable file size (bytes). Uses GNU stat or BSD stat form.
get_file_size() {
  local f="$1"
  if [[ ! -e "$f" ]]; then
    printf '%s\n' 0
    return 0
  fi
  if stat -c%s "$f" >/dev/null 2>&1; then
    stat -c%s "$f"
  elif stat -f%z "$f" >/dev/null 2>&1; then
    stat -f%z "$f"
  else
    printf '%s\n' 0
  fi
}

# Existing writable check + fallback to temp file
if ! : >>"$LOG_FILE" 2>/dev/null; then
  alt_log="$(mktemp -t laravel-audit.XXXXXX.log 2>/dev/null || mktemp)"
  printf 'LOG_FILE not writable; using %s\n' "$alt_log" >&2
  LOG_FILE="$alt_log"
  # remove temporary log on exit
  trap '[[ -n "${alt_log:-}" && -f "$alt_log" ]] && rm -f "$alt_log"' EXIT
fi

# Rotate log if too large (simple local rotation; use system logrotate for production)
if [[ -f "$LOG_FILE" ]]; then
  size=$(get_file_size "$LOG_FILE")
  if [[ "$size" =~ ^[0-9]+$ ]] && (( size > 5242880 )); then
    ts=$(date '+%Y%m%d%H%M%S')
    mv "$LOG_FILE" "${LOG_FILE}.$ts" 2>/dev/null || true
    : > "$LOG_FILE" || true
    ok "Rotated large log file: ${LOG_FILE}.${ts}"
  fi
fi

# --- Platform detection ---
section "Platform detection"
UNAME=$(uname 2>/dev/null || echo unknown)
info "Platform: $UNAME"
case "$UNAME" in
  Linux|Darwin) ;;
  *)
    warn "This script is intended for Linux/macOS. Some checks may not work on: $UNAME"
    ;;
esac

# Report SELinux status when available
if command -v getenforce >/dev/null 2>&1; then
  sel=$(getenforce 2>/dev/null || echo unknown)
  info "SELinux mode: $sel"
elif [[ -r /sys/fs/selinux/enforce ]]; then
  sel=$(cat /sys/fs/selinux/enforce 2>/dev/null || echo unknown)
  info "SELinux enforce file: $sel"
fi

# --- Required commands check ---
section "Required commands"
for cmd in stat find grep awk mktemp pgrep; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    fail "Required command missing: $cmd"
  fi
done

# --- PHP version check ---
section "PHP version"
if command -v php >/dev/null 2>&1; then
  phpver=$(php -r 'echo PHP_VERSION;' 2>/dev/null)
  info "PHP version: $phpver"
else
  if [[ "$STRICT" -eq 1 ]]; then
    fail "php not installed (strict mode)"
    exit 1
  else
    warn "php not installed"
  fi
fi

# ------------------------------
# Discover app path
# ------------------------------
section "App discovery"

if [[ -z "$APP_PATH" ]]; then
  if [[ -f "./artisan" && -f "./composer.json" ]]; then
    APP_PATH="$(pwd)"
  fi

  for d in /var/www/html /var/www /srv/www; do
    if [[ -z "$APP_PATH" && -f "$d/artisan" && -f "$d/composer.json" ]]; then
      APP_PATH="$d"
    fi
  done
fi

if [[ -z "$APP_PATH" ]]; then
  fail "Laravel app not found. Use --app-path /path/to/app"
  exit 1
else
  ok "Using APP_PATH: $APP_PATH"
  if [[ ! -r "$APP_PATH" || ! -x "$APP_PATH" ]]; then
    warn "APP_PATH not fully accessible (read/execute) — some checks may fail: $APP_PATH"
  fi
fi

# ------------------------------
# Laravel indicators
# ------------------------------
section "Laravel indicators"

ind=0
[[ -f "$APP_PATH/artisan" ]] && ind=$((ind+1))
[[ -f "$APP_PATH/composer.json" ]] && ind=$((ind+1))
[[ -f "$APP_PATH/bootstrap/app.php" ]] && ind=$((ind+1))
[[ -d "$APP_PATH/app" ]] && ind=$((ind+1))

if (( ind >= 3 )); then
  ok "Indicators present: $ind/4"
else
  warn "Indicators present: $ind/4"
fi

# ------------------------------
# .env hygiene
# ------------------------------
section ".env hygiene"

envf="$APP_PATH/.env"

if [[ -f "$envf" ]]; then
  ok ".env present"

  # Cross-platform stat for permissions and owner
  if stat -c %a "$envf" >/dev/null 2>&1; then
    perms=$(stat -c %a "$envf" 2>/dev/null || echo unknown)
    owner=$(stat -c %U "$envf" 2>/dev/null || echo unknown)
  elif stat -f %Lp "$envf" >/dev/null 2>&1; then
    perms=$(stat -f %Lp "$envf" 2>/dev/null || echo unknown)
    owner=$(stat -f %Su "$envf" 2>/dev/null || echo unknown)
  else
    perms=unknown
    owner=unknown
  fi
  info ".env perms=$perms owner=$owner"

  # small ShellCheck-friendly tweak: ensure numeric permission comparison only when numeric
  if [[ "$perms" != unknown ]]; then
    if [[ "$perms" =~ ^[0-9]+$ ]]; then
      if (( perms > 640 )); then
        warn ".env permissions too open ($perms). Consider 640"
      fi
    else
      warn ".env permissions in non-numeric format: $perms"
    fi
  fi

  # Use portable POSIX character class instead of '\s' (grep -E '\s' is not portable)
  APP_ENV=$(grep -E '^[[:space:]]*APP_ENV=' "$envf" | head -n1 | cut -d= -f2- | tr -d "\"'")
  APP_DEBUG=$(grep -E '^[[:space:]]*APP_DEBUG=' "$envf" | head -n1 | cut -d= -f2- | tr -d "\"'")
  APP_KEY=$(grep -E '^[[:space:]]*APP_KEY=' "$envf" | head -n1 | cut -d= -f2- | tr -d "\"'")

  if [[ -n "${APP_ENV:-}" && "$APP_ENV" == "production" ]]; then
    ok "APP_ENV=production"
  else
    warn "APP_ENV is not 'production'"
  fi

  if [[ -n "${APP_DEBUG:-}" && ( "$APP_DEBUG" == false || "$APP_DEBUG" == 0 ) ]]; then
    ok "APP_DEBUG=false"
  else
    warn "APP_DEBUG enabled; disable in production"
  fi

  # Accept APP_KEY values including base64: prefix (must not be empty or just 'base64:')
  if [[ -n "${APP_KEY:-}" ]]; then
    if [[ "$APP_KEY" == base64:* ]]; then
      if [[ "${#APP_KEY}" -le 7 ]]; then
        fail "APP_KEY invalid (base64: prefix with empty payload); run: php artisan key:generate"
      else
        ok "APP_KEY configured (base64)"
      fi
    else
      ok "APP_KEY configured"
    fi
  else
    fail "APP_KEY missing/empty; run: php artisan key:generate"
  fi

  if [[ -z "$TARGET_URL" ]]; then
    TARGET_URL=$(grep -E '^[[:space:]]*APP_URL=' "$envf" | head -n1 | cut -d= -f2- | tr -d "\"'")
    if [[ -n "$TARGET_URL" ]]; then
      info "Derived URL: $TARGET_URL"
    fi
  fi

else
  warn ".env missing"
fi

# --- .env.example check ---
section ".env.example check"
if [[ -f "$APP_PATH/.env.example" ]]; then
  ok ".env.example present"
else
  warn ".env.example missing"
fi

# --- .git directory check ---
section ".git directory check"
if [[ -d "$APP_PATH/.git" ]]; then
  warn ".git directory present in app root (consider removing from production)"
fi

# --- Writable storage/cache check ---
section "Writable storage/cache check"
for d in storage bootstrap/cache; do
  p="$APP_PATH/$d"
  if [[ -d "$p" ]]; then
    if [[ -w "$p" ]]; then
      ok "$d is writable"
    else
      warn "$d is not writable"
    fi
  fi
done

# ------------------------------
# Filesystem permissions
# ------------------------------
section "Filesystem permissions"

# Filesystem permissions - normalize checks
for d in storage bootstrap/cache; do
  p="$APP_PATH/$d"
  if [[ -d "$p" ]]; then
    # Cross-platform stat for permissions
    if stat -c %a "$p" >/dev/null 2>&1; then
      perms=$(stat -c %a "$p" 2>/dev/null || echo unknown)
    elif stat -f %Lp "$p" >/dev/null 2>&1; then
      perms=$(stat -f %Lp "$p" 2>/dev/null || echo unknown)
    else
      perms=unknown
    fi
    info "$d perms=$perms"

    if [[ "$perms" =~ ^[0-9]+$ ]]; then
      if [[ "$perms" == 775 || "$perms" == 755 ]]; then
        ok "$d perms look reasonable"
      else
        warn "$d perms ($perms) - review"
      fi
    else
      warn "$d perms in non-numeric format: $perms"
    fi
  else
    warn "$d missing"
  fi
done

# ------------------------------
# Composer project files check
# ------------------------------
section "Composer project files"
if [[ ! -f "$APP_PATH/composer.lock" ]]; then
  warn "composer.lock not found in $APP_PATH (run 'composer install' first?)"
fi
if [[ ! -f "$APP_PATH/composer.json" ]]; then
  fail "composer.json not found in $APP_PATH"
  echo; exit 1
fi
ok "composer.json found"

# Validate composer.json (use jq if available, else python3 if available)
if command -v jq >/dev/null 2>&1; then
  if ! jq -e . "$APP_PATH/composer.json" >/dev/null 2>&1; then
    if [[ "$STRICT" -eq 1 ]]; then fail "composer.json is not valid JSON (jq)"; exit 1; else warn "composer.json is not valid JSON (jq)"; fi
  else
    ok "composer.json is valid JSON"
  fi
elif command -v python3 >/dev/null 2>&1; then
  if ! python3 -c 'import json,sys; json.load(open(sys.argv[1]));' "$APP_PATH/composer.json" >/dev/null 2>&1; then
    if [[ "$STRICT" -eq 1 ]]; then fail "composer.json is not valid JSON (python3)"; exit 1; else warn "composer.json is not valid JSON (python3)"; fi
  else
    ok "composer.json is valid JSON"
  fi
else
  if [[ "$STRICT" -eq 1 ]]; then fail "No JSON validator (jq/python3) available to validate composer.json (strict mode)"; exit 1; else warn "No JSON validator (jq/python3) available to validate composer.json"; fi
fi

# ------------------------------
# Cache posture
# ------------------------------
section "Config/route/view cache posture"

if [[ -f "$APP_PATH/bootstrap/cache/config.php" ]]; then
  ok "config cached"
else
  warn "config not cached"
fi

# Route cache check using glob (ShellCheck-friendly)
if compgen -G "$APP_PATH/bootstrap/cache/routes-*.php" >/dev/null; then
  ok "routes cached"
else
  warn "routes not cached"
fi

if [[ -d "$APP_PATH/storage/framework/views" ]] &&
   find "$APP_PATH/storage/framework/views" -type f -name '*.php' -print -quit | grep -q .; then
  ok "compiled views present"
else
  warn "compiled views not detected"
fi

# ------------------------------
# Public directory exposure
# ------------------------------
section "Public directory exposure"

if [[ -d "$APP_PATH/public" ]]; then
  ok "public/ exists"
else
  fail "public/ missing"
fi

for f in .env .git composer.json composer.lock artisan; do
  if [[ -e "$APP_PATH/public/$f" ]]; then
    fail "Sensitive file under public/: $f"
  fi
done

# ------------------------------
# HTTP security headers
# ------------------------------
section "HTTP security headers"

# Use a helper to ensure TARGET_URL has a scheme
sanitize_url() {
  local u="$1"
  if [[ -z "$u" ]]; then
    echo ""
    return 0
  fi
  if [[ "$u" =~ ^https?:// ]]; then
    echo "$u"
  else
    echo "https://$u"
  fi
}

if [[ -n "${TARGET_URL:-}" ]]; then
  TARGET_URL=$(sanitize_url "$TARGET_URL")
  if command -v curl >/dev/null 2>&1; then
    # follow redirects, set timeouts
    headers=$(curl -sS -I -L --max-time 10 --connect-timeout 5 "$TARGET_URL" 2>/dev/null | head -n 30 || true)

    if [[ -n "$headers" ]]; then
      info "Fetched headers from $TARGET_URL"
      printf '%s\n' "$headers" | sed 's/^/ /'

      if echo "$headers" | grep -qi 'X-Content-Type-Options:'; then
        ok "X-Content-Type-Options present"
      else
        warn "X-Content-Type-Options missing"
      fi

      if echo "$headers" | grep -qi 'X-Frame-Options:'; then
        ok "X-Frame-Options present"
      else
        warn "X-Frame-Options missing (or use CSP frame-ancestors)"
      fi

      if echo "$headers" | grep -qi 'Strict-Transport-Security:'; then
        ok "HSTS present"
      else
        warn "HSTS missing"
      fi

      if echo "$headers" | grep -qi 'Referrer-Policy:'; then
        ok "Referrer-Policy present"
      else
        warn "Referrer-Policy missing"
      fi
    else
      warn "No response from $TARGET_URL (curl timed out or failed)"
    fi
  else
    if [[ "$STRICT" -eq 1 ]]; then
      fail "curl not installed (strict mode)"; exit 1
    else
      warn "curl not installed; skipping header checks"
    fi
  fi
else
  warn "No URL provided; use --url to check response headers"
fi

# ------------------------------
# Queues / Horizon
# ------------------------------
section "Queues & Horizon"

active=0
if is_systemd; then
  for s in laravel-worker laravel-queue queue-worker horizon; do
    if svc_is_active "$s"; then
      active=$((active+1))
    fi
  done
elif command -v launchctl >/dev/null 2>&1; then
  # macOS: use pgrep for common worker/horizon processes
  if pgrep -f 'horizon' >/dev/null 2>&1; then active=$((active+1)); fi
  if pgrep -f 'artisan queue:work' >/dev/null 2>&1; then active=$((active+1)); fi
else
  # Fallback: search for worker/horizon processes
  if pgrep -f 'artisan queue:work' >/dev/null 2>&1; then active=$((active+1)); fi
  if pgrep -f 'horizon' >/dev/null 2>&1; then active=$((active+1)); fi
fi

if (( active > 0 )); then
  ok "$active queue service(s) active"
else
  warn "No active queue services detected"
fi

# Detect Horizon presence and running state
if [[ -f "$APP_PATH/composer.json" ]] && grep -q '"laravel/horizon"' "$APP_PATH/composer.json"; then
  if pgrep -f 'horizon' >/dev/null 2>&1 || (is_systemd && svc_is_active horizon); then
    ok "Horizon installed and running"
  else
    warn "Horizon installed but not running"
  fi
fi

# ------------------------------
# Summary
# ------------------------------
section "Summary"

printf 'Steps: %d Errors: %d Warnings: %d\n' "$STEPS" "$ERR" "$WARN"

if (( ERR > 0 )); then
  exit 1
elif (( WARN > 0 )); then
  exit 2
else
  exit 0
fi
