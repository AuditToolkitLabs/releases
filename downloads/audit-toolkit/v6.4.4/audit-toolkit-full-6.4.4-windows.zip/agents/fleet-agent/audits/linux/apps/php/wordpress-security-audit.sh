#!/usr/bin/env bash
# wordpress-security-audit.sh (Multi-host portable)
# Purpose : Non-destructive security audit for WordPress across common Linux hosts
# Supports: Debian/Ubuntu, RHEL/CentOS/Alma/Rocky, Fedora, Amazon Linux, SUSE, WSL (Linux)
# Usage   : sudo ./wordpress-security-audit.sh [--wp-path DIR] [--url URL]
# Env     : LOG_FILE=/var/log/wordpress-audit.log
# Exit    : 0=OK, 1=Warnings only, 2=Failures
#
# @elevation: partial
# @elevation-reason: Root provides file permission checks; wp-cli may need web user context
#
set -euo pipefail

# -------------------- Runtime options --------------------
WP_PATH="${WP_PATH:-}"
TARGET_URL="${TARGET_URL:-}"
LOG_FILE="${LOG_FILE:-/var/log/wordpress-audit.log}"
QUIET=false; VERBOSE=false; NO_COLOR=false

# -------------------- Colors & logging -------------------
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
log()  { printf '[%(%Y-%m-%d %H:%M:%S)T] [%s] %s\n' -1 "$1" "$2" | tee -a "$LOG_FILE" >/dev/null || true; }
info() { $QUIET || { printf '%b[INFO]%b  %s\n'  "$BLUE" "$NC" "$1"; }; log INFO "$1"; }
ok()   { $QUIET || { printf '%b[PASS]%b  %s\n' "$GREEN" "$NC" "$1"; }; log PASS "$1"; }
warn() { $QUIET || { printf '%b[WARN]%b  %s\n' "$YELLOW" "$NC" "$1"; }; log WARN "$1"; WARN=$((WARN+1)); }
fail() { printf '%b[FAIL]%b  %s\n' "$RED" "$NC" "$1" 1>&2; log FAIL "$1"; ERR=$((ERR+1)); }
skip() { $QUIET || { printf '%b[SKIP]%b  %s\n' "$BLUE" "$NC" "$1"; }; log SKIP "$1"; }
section(){ echo; printf '%s\n' "${BOLD}──────────────── ${1} ────────────────${NC}" | tee -a "$LOG_FILE" >/dev/null; STEPS=$((STEPS+1)); }

# Check if running as root/sudo and warn if not
check_root_warn() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    warn "Not running as root/sudo (some checks may be limited)"
    return 1
  fi
  return 0
}

# Disable colors if requested or not a TTY
if [ "$NO_COLOR" = "true" ] || [ ! -t 1 ]; then RED=''; YELLOW=''; GREEN=''; BLUE=''; BOLD=''; NC=''; fi

# -------------------- State counters ---------------------
STEPS=0; ERR=0; WARN=0

# -------------------- OS / tools helpers -----------------
# Portable stat helpers (GNU/BSD)
stat_mode()  { local p=$1; stat -c %a "$p" 2>/dev/null || stat -f %Lp "$p" 2>/dev/null || echo ""; }
stat_user()  { local p=$1; stat -c %U "$p" 2>/dev/null || stat -f %Su "$p" 2>/dev/null || echo ""; }
stat_group() { local p=$1; stat -c %G "$p" 2>/dev/null || stat -f %Sg "$p" 2>/dev/null || echo ""; }

# Safe grep (ignore locale pitfalls)
GREP='grep -E'

# -------------------- CLI parsing ------------------------
usage(){ cat <<'EOF'
Usage: wordpress-security-audit.sh [OPTIONS]
Options:
  -p, --wp-path DIR     WordPress root path (if omitted, auto-discovery is attempted)
  -u, --url URL         Optional site URL to validate HTTP security headers
  -l, --log FILE        Log file path (default: /var/log/wordpress-audit.log)
  -q, --quiet           Suppress stdout (errors still on stderr)
  -v, --verbose         Enable verbose logs
      --no-color        Disable colored output
  -h, --help            Show this help
      --version         Show version
EOF
}

VERSION="4.0.0-multihost"

while [ $# -gt 0 ]; do
  case "$1" in
    -p|--wp-path) WP_PATH="$2"; shift 2;;
    -u|--url)     TARGET_URL="$2"; shift 2;;
    -l|--log)     LOG_FILE="$2"; shift 2;;
    -q|--quiet)   QUIET=true; shift;;
    -v|--verbose) VERBOSE=true; shift;;
    --no-color)   NO_COLOR=true; shift;;
    -h|--help)    usage; exit 0;;
    --version)    printf '%s\n' "$VERSION"; exit 0;;
    *) printf 'Unknown option: %s\n' "$1" 1>&2; usage; exit 1;;
  esac
done

# Prepare logging target (best-effort)
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
: >"$LOG_FILE" 2>/dev/null || true

# -------------------- Discovery --------------------------
score_wp_path(){ # $1=path -> prints "score:path"
  local p="$1" s=0
  [ -f "$p/wp-config.php" ]   && s=$((s+1))
  [ -f "$p/wp-load.php" ]     && s=$((s+1))
  [ -f "$p/wp-settings.php" ] && s=$((s+1))
  [ -f "$p/index.php" ]       && s=$((s+1))
  [ -d "$p/wp-admin" ]        && s=$((s+1))
  [ -d "$p/wp-includes" ]     && s=$((s+1))
  [ -d "$p/wp-content" ]      && s=$((s+1))
  printf '%s:%s\n' "$s" "$p"
}

auto_discover_wp(){
  # Fast checks first
  if [ -n "${WP_PATH:-}" ] && [ -d "$WP_PATH" ]; then
    score_wp_path "$WP_PATH"; return 0
  fi
  if [ -f ./wp-includes/version.php ] && [ -f ./wp-config.php ]; then
    score_wp_path "$(pwd)"; return 0
  fi
  # Target common roots; depth-limited search (Linux distros)
  for r in /var/www/html /var/www /srv/www /usr/share/nginx/html /opt; do
    [ -d "$r" ] || continue
    # Search directories that contain version.php or wp-config.php within depth 3
    # Using two simple loops keeps compatibility with many distro finds
    while IFS= read -r d; do [ -d "$d" ] && score_wp_path "$d"; done < <(find "$r" -type f -name version.php -maxdepth 3 -printf '%h\n' 2>/dev/null | sort -u)
    while IFS= read -r d; do [ -d "$d" ] && score_wp_path "$d"; done < <(find "$r" -type f -name wp-config.php -maxdepth 3 -printf '%h\n' 2>/dev/null | sort -u)
  done
}

# Pick best-scoring candidate
choose_best_wp(){
  local best_s=-1 best_p=""
  while IFS=: read -r s p; do
    [ -z "$p" ] && continue
    if [ "$s" -gt "$best_s" ]; then best_s=$s; best_p="$p"; fi
  done
  [ "$best_s" -gt 0 ] && printf '%s\n' "$best_p" || printf '\n'
}

# If no path specified, attempt discovery
if [ -z "${WP_PATH:-}" ]; then
  mapfile -t candidates < <(auto_discover_wp || true)
  if [ ${#candidates[@]} -gt 0 ]; then
    WP_PATH=$(printf '%s\n' "${candidates[@]}" | choose_best_wp)
  fi
fi

if [ -z "${WP_PATH:-}" ] || [ ! -d "$WP_PATH" ]; then
  fail "Unable to locate WordPress installation automatically. Use --wp-path /var/www/html"
  exit 2
fi
ok "Target WordPress: $WP_PATH"

# -------------------- Checks -----------------------------
section "Privilege"
check_root_warn

section "Core indicators"
ind=0
[ -f "$WP_PATH/wp-config.php" ]   && ind=$((ind+1))
[ -f "$WP_PATH/wp-load.php" ]     && ind=$((ind+1))
[ -f "$WP_PATH/wp-settings.php" ] && ind=$((ind+1))
[ -d "$WP_PATH/wp-admin" ]        && ind=$((ind+1))
[ -d "$WP_PATH/wp-includes" ]     && ind=$((ind+1))
[ -d "$WP_PATH/wp-content" ]      && ind=$((ind+1))
if [ "$ind" -ge 5 ]; then ok "WP indicators present: $ind/6"; else fail "WP indicators insufficient: $ind/6"; fi

section "Version"
if [ -f "$WP_PATH/wp-includes/version.php" ]; then
  wpver=$(grep "wp_version =" "$WP_PATH/wp-includes/version.php" 2>/dev/null | awk -F"'" '{print $2}' || true)
  [ -n "$wpver" ] && ok "WordPress version: $wpver" || warn "Could not determine WordPress version"
else
  warn "wp-includes/version.php missing"
fi

section "File/Dir permissions"
# Files != 644 (first 30)
bad_files=$(find "$WP_PATH" -type f ! -perm 0644 -printf '%p %m\n' 2>/dev/null | head -n 30 || true)
if [ -n "$bad_files" ]; then warn "Files with non-644 perms (first 30):"; printf '%s\n' "$bad_files" | sed 's/^/  /'; else ok "No files with non-644 perms (sample)"; fi
# Dirs != 755 (first 30)
bad_dirs=$(find "$WP_PATH" -type d ! -perm 0755 -printf '%p %m\n' 2>/dev/null | head -n 30 || true)
if [ -n "$bad_dirs" ]; then warn "Dirs with non-755 perms (first 30):"; printf '%s\n' "$bad_dirs" | sed 's/^/  /'; else ok "No dirs with non-755 perms (sample)"; fi
# World-writable (first 20)
world_w=$(find "$WP_PATH" -type f -perm -0002 2>/dev/null | head -n 20 || true)
if [ -n "$world_w" ]; then fail "World-writable files found (first 20):"; printf '%s\n' "$world_w" | sed 's/^/  /'; else ok "No world-writable files detected (sample)"; fi

section "wp-config.php security"
conf="$WP_PATH/wp-config.php"
if [ ! -f "$conf" ]; then
  fail "wp-config.php not found";
else
  mode=$(stat_mode "$conf"); owner=$(stat_user "$conf"); group=$(stat_group "$conf")
  [ -n "$mode" ]  && info "wp-config.php mode=$mode" || info "wp-config.php mode=unknown"
  [ -n "$owner$group" ] && info "owner=$owner group=$group"
  if [ -n "$mode" ]; then
    if [ "$mode" -le 600 ]; then ok "wp-config perms are tight ($mode)";
    elif [ "$mode" -le 640 ]; then ok "wp-config perms acceptable ($mode)";
    elif [ "$mode" -le 644 ]; then warn "wp-config perms could be tighter ($mode)";
    else fail "wp-config perms too open ($mode)"; fi
  fi
  # Salts/keys (OWASP A02 - Cryptographic Failures)
  missing=0; defaulted=0; weak=0
  for k in AUTH_KEY SECURE_AUTH_KEY LOGGED_IN_KEY NONCE_KEY AUTH_SALT SECURE_AUTH_SALT LOGGED_IN_SALT NONCE_SALT; do
    if grep -qE "define\s*\(\s*'${k}'" "$conf" 2>/dev/null; then
      val=$(grep -E "define\s*\(\s*'${k}'" "$conf" 2>/dev/null | sed -E "s/.*'${k}'[^']*'([^']*).*/\1/" | head -n1)
      if echo "$val" | grep -q "put your unique phrase here"; then
        defaulted=$((defaulted+1))
      elif [ ${#val} -lt 64 ]; then
        weak=$((weak+1))
        warn "$k: Weak/short value (${#val} chars < 64)"
      fi
    else
      missing=$((missing+1))
    fi
  done
  if [ $missing -eq 0 ] && [ $defaulted -eq 0 ] && [ $weak -eq 0 ]; then ok "Security keys/salts: All 8 configured with strong values (OWASP A02)"; else
    [ $defaulted -gt 0 ] && fail "$defaulted defaulted security key(s) (OWASP A02)"
    [ $missing -gt 0 ]   && fail "$missing missing security key(s) (OWASP A02)"
    info "Generate fresh keys: https://api.wordpress.org/secret-key/1.1/salt/"
  fi
  # Table prefix
  if grep -q "\$table_prefix" "$conf" 2>/dev/null; then
    prefix=$(grep "\$table_prefix" "$conf" 2>/dev/null | awk -F"'" '{print $2}' | head -n1)
    [ "$prefix" = "wp_" ] && warn "Default DB table prefix 'wp_' in use" || ok "Custom DB table prefix in use"
  fi
  # Hardening constants (OWASP A05 - Security Misconfiguration)
  grep -qE "define\s*\(\s*'DISALLOW_FILE_EDIT'\s*,\s*true\s*\)" "$conf" 2>/dev/null && ok "DISALLOW_FILE_EDIT: true (OWASP A05 - prevents plugin/theme editing)" || warn "DISALLOW_FILE_EDIT: not set - file editing allowed in admin panel (OWASP A05)"
  grep -qE "define\s*\(\s*'DISALLOW_FILE_MODS'\s*,\s*true\s*\)" "$conf" 2>/dev/null && info "DISALLOW_FILE_MODS: true (blocks all plugin/theme installs)" || info "File mods allowed (acceptable if controlled)"
  grep -qE "define\s*\(\s*'FORCE_SSL_ADMIN'\s*,\s*true\s*\)" "$conf" 2>/dev/null && ok "FORCE_SSL_ADMIN: true (OWASP A02 - SSL enforced for admin)" || warn "FORCE_SSL_ADMIN: not set - consider enabling for HTTPS sites (OWASP A02)"
  grep -qE "define\s*\(\s*'AUTOMATIC_UPDATER_DISABLED'\s*,\s*true\s*\)" "$conf" 2>/dev/null && warn "AUTOMATIC_UPDATER_DISABLED: true - auto-updates disabled (OWASP A06)" || ok "Auto-updates: enabled or default (OWASP A06 - Vulnerable Components)"
  grep -qE "define\s*\(\s*'WP_DEBUG'\s*,\s*true\s*\)" "$conf" 2>/dev/null && warn "WP_DEBUG: true (disable in production - OWASP A05)" || ok "WP_DEBUG: false (prod-appropriate - OWASP A05)"
fi

section "Uploads security"
up="$WP_PATH/wp-content/uploads"
if [ -d "$up" ]; then
  ok "uploads/ present"
  php_in_uploads=$(find "$up" -type f -name '*.php' 2>/dev/null | head -n 10 || true)
  if [ -n "$php_in_uploads" ]; then fail "PHP files found in uploads (first 10):"; printf '%s\n' "$php_in_uploads" | sed 's/^/  /'; else ok "No PHP in uploads (sample)"; fi
  if [ -f "$up/.htaccess" ]; then
    if grep -qiE "php_flag\s+engine\s+off|<FilesMatch \\.(php|phps)$>" "$up/.htaccess" 2>/dev/null; then ok "uploads/.htaccess blocks PHP"; else warn "uploads/.htaccess present without explicit PHP block"; fi
  else
    warn "uploads/.htaccess missing (Apache-only recommendation)"
  fi
else
  warn "uploads/ not found (created on first upload)"
fi

section ".htaccess & headers (Apache)"
ht="$WP_PATH/.htaccess"
if [ -f "$ht" ]; then
  ok ".htaccess present"
  hmode=$(stat_mode "$ht"); [ -n "$hmode" ] && info ".htaccess mode=$hmode"
  grep -qi "BEGIN WordPress" "$ht" 2>/dev/null && ok "WP rewrite rules present" || warn "WP rewrite rules missing"
  # Header hints (pass if present)
  grep -qi "Strict-Transport-Security" "$ht" 2>/dev/null && ok "HSTS present" || warn "HSTS header missing (HTTPS only)"
  grep -qi "Content-Security-Policy" "$ht"   2>/dev/null && ok "CSP present"   || warn "CSP header missing (consider report-only first)"
  grep -qi "Referrer-Policy" "$ht"           2>/dev/null && ok "Referrer-Policy present" || warn "Referrer-Policy missing"
  grep -qi "X-Content-Type-Options" "$ht"    2>/dev/null && ok "X-Content-Type-Options present" || warn "X-Content-Type-Options missing"
  grep -qi "X-Frame-Options" "$ht"            2>/dev/null || grep -qi "frame-ancestors" "$ht" 2>/dev/null \
    && ok "Clickjacking defense present (XFO/CSP)" || warn "Clickjacking defense missing"
else
  warn ".htaccess not found (normal on Nginx)"
fi

section "PHP runtime hardening"
if command -v php >/dev/null 2>&1; then
  ok "PHP present: $(php -v 2>/dev/null | head -n1 || echo php)"
  ini_get(){ php -r "echo ini_get('$1');" 2>/dev/null || true; }
  [ "$(ini_get expose_php)" = "0" ] || [ "$(ini_get expose_php)" = "Off" ] && ok "expose_php=Off" || warn "expose_php enabled"
  [ "$(ini_get display_errors)" = "0" ] || [ "$(ini_get display_errors)" = "Off" ] && ok "display_errors=Off" || warn "display_errors On"
  [ "$(ini_get allow_url_fopen)" = "0" ] || [ "$(ini_get allow_url_fopen)" = "Off" ] && ok "allow_url_fopen=Off" || warn "allow_url_fopen On (review)"
  [ "$(ini_get allow_url_include)" = "0" ] || [ "$(ini_get allow_url_include)" = "Off" ] && ok "allow_url_include=Off" || fail "allow_url_include On (disable)"
  [ "$(ini_get session.cookie_secure)" = "1" ] && ok "session.cookie_secure=1" || warn "session.cookie_secure=0 (HTTPS recommend 1)"
  [ "$(ini_get session.cookie_httponly)" = "1" ] && ok "session.cookie_httponly=1" || warn "session.cookie_httponly=0"
  [ "$(ini_get session.use_strict_mode)" = "1" ] && ok "session.use_strict_mode=1" || warn "session.use_strict_mode=0"
else
  warn "php not installed; skipping runtime checks"
fi

section "XML-RPC posture"
xml="$WP_PATH/xmlrpc.php"; blocked=0
[ -f "$xml" ] && info "xmlrpc.php present"
if [ -f "$WP_PATH/.htaccess" ] && grep -qiE '<Files(.*)xmlrpc\.php' "$WP_PATH/.htaccess" 2>/dev/null; then blocked=1; fi
if grep -Rqi "xmlrpc_enabled'.*__return_false" "$WP_PATH/wp-content" 2>/dev/null; then blocked=1; fi
[ $blocked -eq 1 ] && ok "XML-RPC disabled/blocked" || warn "XML-RPC likely enabled (disable if not required)"

section "WP-CLI assisted checks (optional)"
if command -v wp >/dev/null 2>&1; then
  wp core version --path="$WP_PATH" >/dev/null 2>&1 && ok "WP-CLI core reachable" || warn "WP-CLI cannot read core version"
  # Core updates
  if wp core check-update --path="$WP_PATH" >/dev/null 2>&1; then
    out=$(wp core check-update --path="$WP_PATH" 2>/dev/null || true)
    if [ -n "$out" ]; then warn "Core updates available"; printf '%s\n' "$out" | sed 's/^/  /'; else ok "No core updates available"; fi
  fi
  # Plugin updates
  pout=$(wp plugin list --update=available --path="$WP_PATH" --format=table 2>/dev/null || true)
  if [ -n "$pout" ]; then warn "Plugin updates available"; printf '%s\n' "$pout"; else ok "No plugin updates available"; fi
  # Theme updates
  tout=$(wp theme list --update=available --path="$WP_PATH" --format=table 2>/dev/null || true)
  if [ -n "$tout" ]; then warn "Theme updates available"; printf '%s\n' "$tout"; else ok "No theme updates available"; fi
  # Admin username 'admin'
  admins=$(wp user list --role=administrator --field=user_login --path="$WP_PATH" 2>/dev/null || true)
  if printf '%s\n' "$admins" | grep -qx "admin"; then fail "Admin username 'admin' exists"; else ok "No 'admin' superuser"; fi
  # Admin count
  acount=$(printf '%s\n' "$admins" | sed '/^\s*$/d' | wc -l | tr -d ' ')
  [ -n "$acount" ] && { [ "$acount" -gt 5 ] && warn "Administrator count high: $acount" || ok "Administrator count: $acount"; }
  # 2FA presence (heuristic)
  twofa=$(wp plugin list --path="$WP_PATH" --field=name 2>/dev/null | grep -Ei 'two-factor|wp-2fa|google-authenticator' || true)
  [ -n "$twofa" ] && ok "2FA plugin(s) detected: $(printf '%s' "$twofa" | paste -sd, -)" || warn "No 2FA plugin detected"
else
  warn "wp (WP-CLI) not installed; skipping deep checks"
fi

section "Update posture"
if [ -f "$WP_PATH/wp-config.php" ]; then
  if grep -q "WP_AUTO_UPDATE_CORE" "$WP_PATH/wp-config.php" 2>/dev/null; then
    line=$(grep -m1 "WP_AUTO_UPDATE_CORE" "$WP_PATH/wp-config.php" 2>/dev/null || true)
    printf '%s\n' "$line" | grep -q "true" && ok "Core auto-update enabled" || warn "Core auto-update configured but not 'true'"
  else
    warn "Core auto-update not set in wp-config.php"
  fi
fi

section "HTTP security headers (live)"
if [ -n "${TARGET_URL:-}" ] && command -v curl >/dev/null 2>&1; then
  hdr=$(curl -sS -I "$TARGET_URL" 2>/dev/null | head -n 30 || true)
  if [ -n "$hdr" ]; then
    info "Fetched headers from $TARGET_URL"; printf '%s\n' "$hdr" | sed 's/^/  /'
    printf '%s\n' "$hdr" | grep -qi 'X-Content-Type-Options:' && ok "X-Content-Type-Options present" || warn "X-Content-Type-Options missing"
    printf '%s\n' "$hdr" | grep -qi 'X-Frame-Options:'        && ok "X-Frame-Options present"        || warn "X-Frame-Options missing (or use CSP frame-ancestors)"
    printf '%s\n' "$hdr" | grep -qi 'Strict-Transport-Security:' && ok "HSTS present"                 || warn "HSTS missing"
    printf '%s\n' "$hdr" | grep -qi 'Referrer-Policy:'           && ok "Referrer-Policy present"       || warn "Referrer-Policy missing"
  else
    warn "No response from $TARGET_URL"
  fi
elif [ -n "${TARGET_URL:-}" ]; then
  warn "curl not available; skipping live header checks"
else
  info "No --url provided; skipping live header checks"
fi

# -------------------- Summary & exit ---------------------
section "Summary"
printf 'Steps: %d  Errors: %d  Warnings: %d\n' "$STEPS" "$ERR" "$WARN"
if   [ "$ERR" -gt 0 ]; then exit 2
elif [ "$WARN" -gt 0 ]; then exit 1
else exit 0; fi
