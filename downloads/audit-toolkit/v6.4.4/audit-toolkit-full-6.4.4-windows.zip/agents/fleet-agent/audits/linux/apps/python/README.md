# Python Application Security Audits

This directory contains security audits for Python web applications including Django, Flask, and FastAPI frameworks.

## Audits

### python-app-security-audit.sh

Comprehensive security audit for Python web application deployments.

**Coverage:**
- Python version and security patches
- Dependency vulnerabilities (requirements.txt scanning with safety/pip-audit)
- Django security configuration (DEBUG, SECRET_KEY, ALLOWED_HOSTS, CSRF, session settings)
- Flask security configuration (SECRET_KEY, SESSION settings, security headers)
- FastAPI security middleware (CORS, rate limiting, dependency injection)
- Secrets management (environment variables vs hardcoded credentials)
- WSGI server security (Gunicorn/uWSGI hardening, worker configuration)
- Session security (cookie settings, session backends)
- Security headers (CSP, X-Frame-Options, HSTS)

**Usage:**
```bash
# Run standalone
bash audits/linux/apps/python/python-app-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain apps --match python
```

**Example Output:**
```
=== Python Application Security Audit ===

--- Python Installation ---
[PASS] Python Version: 3.11.2
[PASS] Python Security Patches: up to date

--- Django Security ---
[FAIL] DEBUG Mode: enabled in production
[PASS] SECRET_KEY: configured and not default
[WARN] ALLOWED_HOSTS: includes wildcard
[PASS] CSRF Protection: enabled
[PASS] Secure Cookies: SECURE_SSL_REDIRECT enabled

--- Dependency Security ---
[WARN] pip-audit vulnerabilities: 3 found
[WARN] Outdated packages: Django 6.4.1 (6.4.1 available)
```

## Common Issues & Remediation

### Django DEBUG Mode in Production
**Issue:** `DEBUG = True` in production exposes sensitive information.

**Fix:**
```python
# settings.py
DEBUG = os.environ.get('DEBUG', 'False') == 'True'
# or
DEBUG = False
```

### Weak SECRET_KEY
**Issue:** Default or hardcoded SECRET_KEY compromises session security.

**Fix:**
```python
# settings.py
SECRET_KEY = os.environ.get('SECRET_KEY')
if not SECRET_KEY:
    raise ValueError("SECRET_KEY environment variable not set")
```

### Missing ALLOWED_HOSTS
**Issue:** Empty or wildcard ALLOWED_HOSTS enables Host header attacks.

**Fix:**
```python
# settings.py
ALLOWED_HOSTS = ['yourdomain.com', 'www.yourdomain.com']
```

### Vulnerable Dependencies
**Issue:** Outdated packages with known CVEs.

**Fix:**
```bash
# Scan for vulnerabilities
pip install pip-audit
pip-audit

# Update vulnerable packages
pip install --upgrade <package-name>

# Use requirements with pinned versions
pip freeze > requirements.txt
```

### Insecure Gunicorn Configuration
**Issue:** Default Gunicorn settings lack hardening.

**Fix:**
```ini
# gunicorn.conf.py
bind = '127.0.0.1:8000'  # Bind to localhost only
workers = 4
worker_class = 'sync'
timeout = 30
max_requests = 1000
max_requests_jitter = 50
limit_request_line = 4096
limit_request_fields = 100
```

### Session Security
**Issue:** Insecure session cookie settings.

**Fix:**
```python
# Django settings.py
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_AGE = 3600  # 1 hour

# Flask app.py
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
```

## Best Practices

1. **Environment-Based Configuration:**
   - Use environment variables for secrets
   - Never commit credentials to version control
   - Use `.env` files with django-environ or python-dotenv

2. **Dependency Management:**
   - Pin all dependencies with exact versions
   - Regularly scan for vulnerabilities with pip-audit or safety
   - Use virtual environments to isolate project dependencies

3. **Production WSGI Server:**
   - Never use `python manage.py runserver` in production
   - Use Gunicorn, uWSGI, or Hypercorn behind a reverse proxy
   - Configure appropriate worker/thread counts for your workload

4. **Security Middleware:**
   - Enable Django SecurityMiddleware
   - Use Flask-Talisman or Flask-SeaSurf for Flask
   - Implement rate limiting (django-ratelimit, slowapi)

5. **Database Security:**
   - Use connection pooling
   - Enable SSL/TLS for database connections
   - Restrict database user permissions to minimum required

## References

- [Django Security Checklist](https://docs.djangoproject.com/en/stable/howto/deployment/checklist/)
- [Flask Security Best Practices](https://flask.palletsprojects.com/en/latest/security/)
- [FastAPI Security](https://fastapi.tiangolo.com/tutorial/security/)
- [OWASP Python Security Project](https://owasp.org/www-project-python-security/)
- [pip-audit Documentation](https://pypi.org/project/pip-audit/)


