#!/usr/bin/env bash
# Python Application Security Audit
# Checks Python app security including dependencies, framework configs, and deployment practices

# @elevation: none
# @elevation-reason: File and configuration checks only
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
PYTHON_COMMON_PATHS=(
  "."
  "/var/www"
  "/srv"
  "/opt"
  "/home"
)

# === Performance: Cache variables ===
PYTHON_VERSION=""
PIP_VERSION=""
FRAMEWORK_TYPE=""
APP_ROOT=""
VENV_PATH=""
REQUIREMENTS_FILE=""

# Detect Python version
get_python_version() {
  if [[ -n "$PYTHON_VERSION" ]]; then
    echo "$PYTHON_VERSION"
    return 0
  fi

  if command -v python3 >/dev/null 2>&1; then
    PYTHON_VERSION=$(python3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
  elif command -v python >/dev/null 2>&1; then
    PYTHON_VERSION=$(python --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
  else
    PYTHON_VERSION="not_found"
  fi

  echo "$PYTHON_VERSION"
}

# Detect pip version
get_pip_version() {
  if [[ -n "$PIP_VERSION" ]]; then
    echo "$PIP_VERSION"
    return 0
  fi

  if command -v pip3 >/dev/null 2>&1; then
    PIP_VERSION=$(pip3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
  elif command -v pip >/dev/null 2>&1; then
    PIP_VERSION=$(pip --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
  else
    PIP_VERSION="not_found"
  fi

  echo "$PIP_VERSION"
}

# Try to find Python app root
find_python_app() {
  if [[ -n "$APP_ROOT" ]]; then
    echo "$APP_ROOT"
    return 0
  fi

  # Look for common Python app indicators
  for base_path in "${PYTHON_COMMON_PATHS[@]}"; do
    if [[ -d "$base_path" ]]; then
      # Find directories with requirements.txt, manage.py, app.py, or main.py
      found_apps=$(find "$base_path" -maxdepth 3 -type f \( -name "requirements.txt" -o -name "manage.py" -o -name "app.py" -o -name "main.py" \) 2>/dev/null | head -n1)

      if [[ -n "$found_apps" ]]; then
        APP_ROOT=$(dirname "$found_apps")
        echo "$APP_ROOT"
        return 0
      fi
    fi
  done

  return 1
}

# Detect framework (Django, Flask, FastAPI)
detect_framework() {
  if [[ -n "$FRAMEWORK_TYPE" ]]; then
    echo "$FRAMEWORK_TYPE"
    return 0
  fi

  local app_path="${1:-.}"

  if [[ -f "$app_path/manage.py" ]]; then
    FRAMEWORK_TYPE="Django"
  elif [[ -f "$app_path/requirements.txt" ]]; then
    if grep -qi "django" "$app_path/requirements.txt"; then
      FRAMEWORK_TYPE="Django"
    elif grep -qi "flask" "$app_path/requirements.txt"; then
      FRAMEWORK_TYPE="Flask"
    elif grep -qi "fastapi" "$app_path/requirements.txt"; then
      FRAMEWORK_TYPE="FastAPI"
    else
      FRAMEWORK_TYPE="Generic"
    fi
  elif [[ -f "$app_path/Pipfile" ]]; then
    if grep -qi "django" "$app_path/Pipfile"; then
      FRAMEWORK_TYPE="Django"
    elif grep -qi "flask" "$app_path/Pipfile"; then
      FRAMEWORK_TYPE="Flask"
    elif grep -qi "fastapi" "$app_path/Pipfile"; then
      FRAMEWORK_TYPE="FastAPI"
    else
      FRAMEWORK_TYPE="Generic"
    fi
  else
    FRAMEWORK_TYPE="Unknown"
  fi

  echo "$FRAMEWORK_TYPE"
}

# Check if running in virtual environment
check_venv() {
  if [[ -n "$VIRTUAL_ENV" ]]; then
    VENV_PATH="$VIRTUAL_ENV"
    return 0
  fi

  # Check for common venv locations
  local app_path="${1:-.}"
  for venv_name in venv .venv env virtualenv; do
    if [[ -d "$app_path/$venv_name" ]]; then
      VENV_PATH="$app_path/$venv_name"
      return 0
    fi
  done

  return 1
}

# === MAIN AUDIT ===

section "Python Environment"

# Check Python installation
python_ver=$(get_python_version)
if [[ "$python_ver" == "not_found" ]]; then
  register_check "Python Installed" SKIP "Python not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Python Installed" PASS "Python $python_ver"

# Check Python EOL (End of Life)
major_ver=$(echo "$python_ver" | cut -d. -f1)
minor_ver=$(echo "$python_ver" | cut -d. -f2)
# Python 3.7 EOL June 2023, 3.8 EOL Oct 2024, 3.9 EOL Oct 2025
if [[ "$major_ver" -eq 3 && "$minor_ver" -lt 9 ]]; then
  register_check "Python Version EOL" WARN "Python $python_ver is End-of-Life (upgrade to 3.10+)"
elif [[ "$major_ver" -eq 2 ]]; then
  register_check "Python Version EOL" FAIL "Python 2.x is End-of-Life (critical security risk)"
else
  register_check "Python Version EOL" PASS "Python $python_ver is supported"
fi

# Check pip version
pip_ver=$(get_pip_version)
if [[ "$pip_ver" != "not_found" ]]; then
  register_check "Pip Installed" PASS "pip $pip_ver"
else
  register_check "Pip Installed" WARN "pip not found (package management unavailable)"
fi

# Check for virtual environment
if check_venv; then
  register_check "Virtual Environment" PASS "venv detected at $VENV_PATH"
else
  register_check "Virtual Environment" WARN "no virtualenv detected (recommend isolated environments)"
fi

# Try to find Python application
app_root=$(find_python_app)
if [[ -z "$app_root" ]]; then
  register_check "Python App Detection" SKIP "no Python app found in common locations"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Python App Detection" PASS "found Python app at $app_root"

# === Dependencies & Vulnerabilities ===
section "Dependencies & Vulnerabilities"

# Check for requirements.txt
if [[ -f "$app_root/requirements.txt" ]]; then
  REQUIREMENTS_FILE="$app_root/requirements.txt"
  register_check "Requirements File" PASS "requirements.txt found"

  # Check for unpinned dependencies (dangerous)
  unpinned_count=$(grep -cE '>|<|~|^|==' "$REQUIREMENTS_FILE" | grep -v "==" || echo "0")
  wildcard_count=$(grep -cF "*" "$REQUIREMENTS_FILE" || echo "0")

  if [[ "$wildcard_count" -gt 0 ]]; then
    register_check "Dependency Pinning" FAIL "$wildcard_count wildcard dependencies (security risk)"
  elif [[ "$unpinned_count" -gt 5 ]]; then
    register_check "Dependency Pinning" WARN "some dependencies not pinned with =="
  else
    register_check "Dependency Pinning" PASS "dependencies properly pinned"
  fi
elif [[ -f "$app_root/Pipfile" ]]; then
  register_check "Requirements File" PASS "Pipfile found (pipenv)"
  if [[ -f "$app_root/Pipfile.lock" ]]; then
    register_check "Dependency Lock File" PASS "Pipfile.lock exists"
  else
    register_check "Dependency Lock File" WARN "Pipfile.lock missing (run pipenv lock)"
  fi
elif [[ -f "$app_root/pyproject.toml" ]]; then
  register_check "Requirements File" PASS "pyproject.toml found (poetry)"
  if [[ -f "$app_root/poetry.lock" ]]; then
    register_check "Dependency Lock File" PASS "poetry.lock exists"
  else
    register_check "Dependency Lock File" WARN "poetry.lock missing (run poetry lock)"
  fi
else
  register_check "Requirements File" WARN "no requirements file found"
fi

# Run pip-audit if available
if command -v pip-audit >/dev/null 2>&1 && [[ -n "$REQUIREMENTS_FILE" ]]; then
  vuln_count=$(pip-audit -r "$REQUIREMENTS_FILE" --format json 2>/dev/null | grep -c '"id"' || echo "0")
  if [[ "$vuln_count" -eq 0 ]]; then
    register_check "Pip-audit Scan" PASS "no known vulnerabilities"
  else
    register_check "Pip-audit Scan" FAIL "$vuln_count known vulnerabilities (run: pip-audit -r requirements.txt)"
  fi
elif command -v safety >/dev/null 2>&1 && [[ -n "$REQUIREMENTS_FILE" ]]; then
  if safety check -r "$REQUIREMENTS_FILE" >/dev/null 2>&1; then
    register_check "Safety Scan" PASS "no known vulnerabilities"
  else
    register_check "Safety Scan" WARN "vulnerabilities detected (run: safety check -r requirements.txt)"
  fi
else
  register_check "Vulnerability Scanning" WARN "pip-audit or safety not available (recommend installing)"
fi

# === Framework-Specific Checks ===
framework=$(detect_framework "$app_root")
section "Framework Security ($framework)"

case "$framework" in
  "Django")
    # Check for settings.py
    settings_files=$(find "$app_root" -name "settings.py" -o -name "settings/*.py" 2>/dev/null)

    if [[ -n "$settings_files" ]]; then
      register_check "Django Settings" PASS "settings.py found"

      # Check DEBUG = False
      if echo "$settings_files" | xargs grep -q "DEBUG = True" 2>/dev/null; then
        register_check "DEBUG Mode" FAIL "DEBUG = True (MUST be False in production)"
      elif echo "$settings_files" | xargs grep -q "DEBUG = False" 2>/dev/null; then
        register_check "DEBUG Mode" PASS "DEBUG = False"
      else
        register_check "DEBUG Mode" WARN "DEBUG setting not found (verify production config)"
      fi

      # Check SECRET_KEY
      secret_key=$(echo "$settings_files" | xargs grep "SECRET_KEY" 2>/dev/null | head -n1)
      if echo "$secret_key" | grep -q "SECRET_KEY = os.environ\|SECRET_KEY = env"; then
        register_check "SECRET_KEY" PASS "SECRET_KEY uses environment variable (secure)"
      elif echo "$secret_key" | grep -qE "SECRET_KEY = ['\"][a-zA-Z0-9!@#$%^&*()-_=+]{50,}"; then
        secret_length=$(echo "$secret_key" | grep -oE "['\"][^'\"]+['\"]" | tr -d "'" | tr -d '"' | wc -c)
        if [[ "$secret_length" -ge 50 ]]; then
          register_check "SECRET_KEY Length" PASS "SECRET_KEY is >= 50 chars"
        else
          register_check "SECRET_KEY Length" WARN "SECRET_KEY < 50 chars (recommend 50+)"
        fi
      elif [[ -n "$secret_key" ]]; then
        register_check "SECRET_KEY" WARN "SECRET_KEY may be weak or hardcoded"
      fi

      # Check ALLOWED_HOSTS
      if echo "$settings_files" | xargs grep -q "ALLOWED_HOSTS = \[\]" 2>/dev/null; then
        register_check "ALLOWED_HOSTS" FAIL "ALLOWED_HOSTS empty (must specify domains)"
      elif echo "$settings_files" | xargs grep -q "ALLOWED_HOSTS = \['\*'\]" 2>/dev/null; then
        register_check "ALLOWED_HOSTS" FAIL "ALLOWED_HOSTS = ['*'] (security risk)"
      elif echo "$settings_files" | xargs grep -q "ALLOWED_HOSTS" 2>/dev/null; then
        register_check "ALLOWED_HOSTS" PASS "ALLOWED_HOSTS configured"
      else
        register_check "ALLOWED_HOSTS" WARN "ALLOWED_HOSTS not found"
      fi

      # Check SECURE_SSL_REDIRECT
      if echo "$settings_files" | xargs grep -q "SECURE_SSL_REDIRECT = True" 2>/dev/null; then
        register_check "SECURE_SSL_REDIRECT" PASS "HTTPS redirect enabled"
      else
        register_check "SECURE_SSL_REDIRECT" WARN "SECURE_SSL_REDIRECT not enabled (recommend True)"
      fi

      # Check session cookie security
      if echo "$settings_files" | xargs grep -q "SESSION_COOKIE_SECURE = True" 2>/dev/null; then
        register_check "SESSION_COOKIE_SECURE" PASS "secure session cookies"
      else
        register_check "SESSION_COOKIE_SECURE" WARN "SESSION_COOKIE_SECURE not True (recommend for HTTPS)"
      fi

      # Check CSRF cookie security
      if echo "$settings_files" | xargs grep -q "CSRF_COOKIE_SECURE = True" 2>/dev/null; then
        register_check "CSRF_COOKIE_SECURE" PASS "secure CSRF cookies"
      else
        register_check "CSRF_COOKIE_SECURE" WARN "CSRF_COOKIE_SECURE not True (recommend for HTTPS)"
      fi
    else
      register_check "Django Settings" WARN "settings.py not found"
    fi
    ;;

  "Flask")
    # Check for config.py or app.py
    config_files=$(find "$app_root" -name "config.py" -o -name "app.py" 2>/dev/null)

    if [[ -n "$config_files" ]]; then
      # Check DEBUG mode
      if echo "$config_files" | xargs grep -qi "DEBUG = True\|debug=True" 2>/dev/null; then
        register_check "Flask DEBUG Mode" FAIL "DEBUG enabled (disable in production)"
      else
        register_check "Flask DEBUG Mode" PASS "DEBUG not explicitly enabled"
      fi

      # Check SECRET_KEY
      if echo "$config_files" | xargs grep -qi "SECRET_KEY" 2>/dev/null; then
        register_check "Flask SECRET_KEY" PASS "SECRET_KEY configured"
      else
        register_check "Flask SECRET_KEY" WARN "SECRET_KEY not found (required for sessions)"
      fi

      # Check CORS
      if grep -rq "flask_cors\|Flask-CORS" "$app_root" 2>/dev/null; then
        register_check "CORS Configuration" PASS "Flask-CORS installed"
      fi
    else
      register_check "Flask Config" WARN "config/app files not found"
    fi
    ;;

  "FastAPI")
    # Check for main.py or app.py
    app_files=$(find "$app_root" -name "main.py" -o -name "app.py" 2>/dev/null)

    if [[ -n "$app_files" ]]; then
      # Check CORS middleware
      if echo "$app_files" | xargs grep -q "CORSMiddleware" 2>/dev/null; then
        if echo "$app_files" | xargs grep -q "allow_origins=\[\"*\"\]" 2>/dev/null; then
          register_check "CORS Origins" WARN "CORS allows all origins (restrict in production)"
        else
          register_check "CORS Origins" PASS "CORS properly configured"
        fi
      fi

      # Check for rate limiting
      if grep -rq "slowapi\|fastapi-limiter" "$app_root" 2>/dev/null; then
        register_check "Rate Limiting" PASS "rate limiting library detected"
      else
        register_check "Rate Limiting" WARN "no rate limiting detected (recommend slowapi)"
      fi
    fi
    ;;
esac

# === Environment Variables ===
section "Environment & Secrets"

# Check for .env files
if [[ -f "$app_root/.env" ]]; then
  register_check ".env File" PASS ".env file found"

  # Check .env permissions
  env_perms=$(stat -c '%a' "$app_root/.env" 2>/dev/null || stat -f '%Lp' "$app_root/.env" 2>/dev/null || echo "000")
  if [[ "$env_perms" =~ ^[0-9]{3}$ && "${env_perms:2:1}" -eq 0 ]]; then
    register_check ".env Permissions" PASS "permissions $env_perms (not world-readable)"
  else
    register_check ".env Permissions" WARN "permissions $env_perms (should restrict to 600/640)"
  fi

  # Check if .env is in .gitignore
  if [[ -f "$app_root/.gitignore" ]]; then
    if grep -q ".env" "$app_root/.gitignore"; then
      register_check ".env in .gitignore" PASS ".env excluded from git"
    else
      register_check ".env in .gitignore" FAIL ".env NOT in .gitignore (credentials may leak)"
    fi
  fi
else
  register_check ".env File" WARN "no .env file (verify environment variable management)"
fi

# Check for hardcoded secrets in requirements
if [[ -n "$REQUIREMENTS_FILE" ]]; then
  if grep -qE "://.*:.*@" "$REQUIREMENTS_FILE"; then
    register_check "Hardcoded Credentials" FAIL "credentials detected in requirements file"
  else
    register_check "Hardcoded Credentials" PASS "no obvious credentials in requirements"
  fi
fi

# === Process & Deployment ===
section "Process & Deployment"

# Check process manager
if command -v gunicorn >/dev/null 2>&1; then
  register_check "WSGI Server (Gunicorn)" PASS "gunicorn installed (production-ready)"
elif command -v uwsgi >/dev/null 2>&1; then
  register_check "WSGI Server (uWSGI)" PASS "uwsgi installed (production-ready)"
else
  register_check "WSGI Server" WARN "gunicorn/uwsgi not found (don't use Flask dev server in production)"
fi

# Check if running as root
app_services=$(systemctl list-units --type=service --all 2>/dev/null | grep -E "gunicorn|uwsgi|python.*app" || echo "")
if [[ -n "$app_services" ]]; then
  for service in $(echo "$app_services" | awk '{print $1}'); do
    service_user=$(systemctl show -p User "$service" 2>/dev/null | cut -d= -f2)
    if [[ "$service_user" == "root" || -z "$service_user" ]]; then
      register_check "Service User ($service)" WARN "running as root (security risk)"
    else
      register_check "Service User ($service)" PASS "running as $service_user"
    fi
  done
fi

# Check for systemd service hardening
if [[ -d "/etc/systemd/system" ]]; then
  python_services=$(find /etc/systemd/system -name "*.service" -exec grep -l "python\|gunicorn\|uwsgi" {} \; 2>/dev/null)
  if [[ -n "$python_services" ]]; then
    for service_file in $python_services; do
      if grep -q "PrivateTmp=true\|ProtectSystem=strict" "$service_file" 2>/dev/null; then
        register_check "Systemd Hardening" PASS "$(basename "$service_file") has security hardening"
      else
        register_check "Systemd Hardening" WARN "$(basename "$service_file") lacks hardening (add PrivateTmp, ProtectSystem)"
      fi
    done
  fi
fi

# === File Security ===
section "File & Directory Security"

# Check if __pycache__ is in .gitignore
if [[ -f "$app_root/.gitignore" ]]; then
  if grep -q "__pycache__\|*.pyc" "$app_root/.gitignore"; then
    register_check "Python Cache in .gitignore" PASS "cache files excluded"
  else
    register_check "Python Cache in .gitignore" WARN "add __pycache__ and *.pyc to .gitignore"
  fi
fi

# Check application directory permissions
app_perms=$(stat -c '%a' "$app_root" 2>/dev/null || stat -f '%Lp' "$app_root" 2>/dev/null || echo "000")
app_owner=$(stat -c '%U' "$app_root" 2>/dev/null || stat -f '%Su' "$app_root" 2>/dev/null || echo "unknown")

if [[ "$app_perms" =~ ^[0-9]{3}$ && "${app_perms:2:1}" -le 5 ]]; then
  register_check "App Directory Permissions" PASS "permissions $app_perms, owner $app_owner"
else
  register_check "App Directory Permissions" WARN "permissions $app_perms may be too permissive"
fi

# Check for file upload directories
upload_dirs=$(find "$app_root" -type d -name "uploads" -o -name "media" -o -name "static/uploads" 2>/dev/null)
if [[ -n "$upload_dirs" ]]; then
  for upload_dir in $upload_dirs; do
    # Check if executable
    if find "$upload_dir" -type f -executable 2>/dev/null | grep -q .; then
      register_check "Upload Dir Executables" WARN "executable files in $upload_dir (security risk)"
    else
      register_check "Upload Dir Executables" PASS "no executables in $upload_dir"
    fi
  done
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
