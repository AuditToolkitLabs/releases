# Ruby on Rails Security Audits

This directory contains security audits for Ruby on Rails web applications.

## Audits

### rails-security-audit.sh

Comprehensive Ruby on Rails security audit covering:

- **Ruby & Rails Versions**
  - Ruby version and EOL status
  - Rails version and security updates
  - Bundler version checks

- **Dependency Security**
  - Gemfile.lock scanning with bundle-audit
  - Known CVE detection in gems
  - Outdated gem identification
  - Bundler vulnerability checks

- **Rails Configuration Security**
  - `config/secrets.yml` or `config/credentials.yml.enc`
  - `secret_key_base` strength (128+ hex characters)
  - Force SSL in production
  - Session store security (secure, httponly, same_site)

- **CSRF Protection**
  - `protect_from_forgery` enabled
  - CSRF token validation
  - Authenticity token checks

- **Strong Parameters**
  - Mass assignment protection
  - `require` and `permit` usage
  - Model security

- **Database Configuration**
  - `config/database.yml` permissions (should be 600)
  - Database credential security
  - Production database separation

- **Rails Console Access**
  - Console access restrictions
  - Production console auditing
  - Sandbox mode availability

- **ActiveRecord Security**
  - SQL injection protection
  - Raw SQL usage auditing
  - Query parameterization

## Usage

```bash
# Run Rails security audit
bash audits/linux/apps/ruby/rails-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain apps --match rails
```

## Requirements

- Ruby runtime (2.7+)
- Rails application (5.x, 6.x, or 7.x)
- `bundle-audit` gem (install with `gem install bundler-audit`)

## Installation

```bash
# Install bundle-audit for vulnerability scanning
gem install bundler-audit

# Update vulnerability database
bundle-audit update

# Scan Gemfile.lock
bundle-audit check
```

## Remediation

### Vulnerable Dependencies

```bash
# Update vulnerable gems
bundle update <gem-name>

# Or update all gems
bundle update

# Check for vulnerabilities
bundle-audit check
```

### Secret Key Base

Ensure strong `secret_key_base` in `config/secrets.yml` or `credentials.yml.enc`:

```yaml
production:
  secret_key_base: <%= ENV["SECRET_KEY_BASE"] %>
```

Generate new secret:

```bash
rails secret
# => outputs 128-character hex string

# Set in environment
export SECRET_KEY_BASE="<generated-secret>"
```

### Force SSL

Enable in `config/environments/production.rb`:

```ruby
config.force_ssl = true
```

### CSRF Protection

Ensure enabled in `app/controllers/application_controller.rb`:

```ruby
class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
end
```

### Strong Parameters

Use in controllers:

```ruby
class UsersController < ApplicationController
  def create
    @user = User.new(user_params)
    @user.save
  end
  
  private
  
  def user_params
    params.require(:user).permit(:name, :email, :role)
  end
end
```

### Database Configuration Security

```bash
# Secure database.yml permissions
chmod 600 config/database.yml

# Use environment variables for credentials
production:
  adapter: postgresql
  database: <%= ENV['DB_NAME'] %>
  username: <%= ENV['DB_USER'] %>
  password: <%= ENV['DB_PASSWORD'] %>
```

### Session Security

Configure in `config/initializers/session_store.rb`:

```ruby
Rails.application.config.session_store :cookie_store,
  key: '_app_session',
  secure: Rails.env.production?, # HTTPS only
  httponly: true,                # No JavaScript access
  same_site: :lax                # CSRF protection
```

## References

- [Rails Security Guide](https://guides.rubyonrails.org/security.html)
- [bundle-audit](https://github.com/rubysec/bundler-audit)
- [Ruby Security](https://www.ruby-lang.org/en/security/)
- [OWASP Rails Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Ruby_on_Rails_Cheat_Sheet.html)
