#!/usr/bin/env bash
# Ruby on Rails Application Security Audit
# Checks Rails application configuration, dependencies, and security best practices

# @elevation: none
# @elevation-reason: File and configuration checks only
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
RAILS_PATHS=(
  "/opt"
  "/srv"
  "/var/www"
  "$HOME"
)

# === Performance: Cache variables ===
RUBY_VERSION=""
RAILS_VERSION=""
RAILS_ROOT=""
GEMFILE_LOCK=""
CONFIG_DIR=""

# === Helper Functions ===

# Detect Ruby version
get_ruby_version() {
  if [[ -n "$RUBY_VERSION" ]]; then
    echo "$RUBY_VERSION"
    return 0
  fi

  if command -v ruby >/dev/null 2>&1; then
    ruby_ver=$(ruby -v 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
    RUBY_VERSION="$ruby_ver"
    echo "$ruby_ver"
  else
    echo "not_installed"
  fi
}

# Detect Rails installation
find_rails_app() {
  if [[ -n "$RAILS_ROOT" ]]; then
    echo "$RAILS_ROOT"
    return 0
  fi

  # Look for Rails app (has config/application.rb and Gemfile)
  for base_path in "${RAILS_PATHS[@]}"; do
    if [[ -d "$base_path" ]]; then
      rails_app=$(find "$base_path" -maxdepth 3 -name "application.rb" -path "*/config/application.rb" 2>/dev/null -print -quit || echo "")
      if [[ -n "$rails_app" ]]; then
        RAILS_ROOT=$(dirname "$(dirname "$rails_app")")
        CONFIG_DIR="$RAILS_ROOT/config"

        # Check for Gemfile.lock
        if [[ -f "$RAILS_ROOT/Gemfile.lock" ]]; then
          GEMFILE_LOCK="$RAILS_ROOT/Gemfile.lock"
        fi

        echo "$RAILS_ROOT"
        return 0
      fi
    fi
  done

  echo ""
}

# Get Rails version from Gemfile.lock
get_rails_version() {
  if [[ -n "$RAILS_VERSION" ]]; then
    echo "$RAILS_VERSION"
    return 0
  fi

  if [[ -n "$GEMFILE_LOCK" ]]; then
    rails_ver=$(grep -A 1 "rails (" "$GEMFILE_LOCK" 2>/dev/null | tail -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    RAILS_VERSION="$rails_ver"
    echo "$rails_ver"
  else
    echo "unknown"
  fi
}

# Get config value from Rails config files
get_rails_config() {
  local config_file="$1"
  local key="$2"

  if [[ -f "$config_file" ]]; then
    grep "$key" "$config_file" 2>/dev/null | head -n1 || echo ""
  else
    echo ""
  fi
}

# === MAIN AUDIT ===

section "Ruby & Rails Detection"

ruby_ver=$(get_ruby_version)
if [[ "$ruby_ver" == "not_installed" ]]; then
  register_check "Ruby Installed" SKIP "Ruby not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Ruby Version" PASS "Ruby $ruby_ver"

# Check for EOL Ruby versions
if [[ "$ruby_ver" =~ ^2\.[0-4] ]]; then
  register_check "Ruby EOL Status" FAIL "Ruby $ruby_ver is End-of-Life"
elif [[ "$ruby_ver" =~ ^2\.[5-6] ]]; then
  register_check "Ruby EOL Status" WARN "Ruby $ruby_ver in security maintenance (upgrade to 3.x)"
else
  register_check "Ruby EOL Status" PASS "Ruby version supported"
fi

# Find Rails application
rails_root=$(find_rails_app)
if [[ -z "$rails_root" ]]; then
  register_check "Rails App" SKIP "No Rails application found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Rails Application" PASS "Found at $rails_root"

# Get Rails version
rails_ver=$(get_rails_version)
if [[ "$rails_ver" != "unknown" ]]; then
  register_check "Rails Version" PASS "Rails $rails_ver"

  # Check for old Rails versions
  major=$(echo "$rails_ver" | cut -d. -f1)
  if [[ "$major" -lt 6 ]]; then
    register_check "Rails EOL" FAIL "Rails $major.x is End-of-Life (upgrade to Rails 7+)"
  elif [[ "$major" -eq 6 ]]; then
    register_check "Rails EOL" WARN "Rails 6 in maintenance (consider upgrading to Rails 7)"
  else
    register_check "Rails EOL" PASS "Rails version current"
  fi
else
  register_check "Rails Version" WARN "Unable to determine Rails version"
fi

# === Gemfile & Dependencies ===
section "Gem Dependencies"

if [[ -f "$rails_root/Gemfile" ]]; then
  register_check "Gemfile" PASS "Gemfile found"

  # Check for version pinning
  unpinned=$(grep -cE "gem ['\"][^'\"]+['\"]$" "$rails_root/Gemfile" || echo "0")
  if [[ "$unpinned" -gt 5 ]]; then
    register_check "Gem Pinning" WARN "$unpinned gems without version constraints"
  else
    register_check "Gem Pinning" PASS "Most gems have version constraints"
  fi
fi

if [[ -n "$GEMFILE_LOCK" ]]; then
  register_check "Gemfile.lock" PASS "Gemfile.lock present (dependencies locked)"

  # Check for bundle-audit tool
  if command -v bundle-audit >/dev/null 2>&1; then
    register_check "bundle-audit Tool" PASS "bundle-audit available for vulnerability scanning"

    # Run bundle-audit if possible
    cd "$rails_root" || exit
    audit_output=$(bundle-audit check 2>/dev/null || echo "error")
    if [[ "$audit_output" == *"Vulnerabilities found"* ]]; then
      vuln_count=$(echo "$audit_output" | grep -c "Name:" || echo "0")
      register_check "Gem Vulnerabilities" FAIL "$vuln_count vulnerable gem(s) detected"
    elif [[ "$audit_output" == *"No vulnerabilities found"* ]]; then
      register_check "Gem Vulnerabilities" PASS "No known vulnerabilities (bundle-audit)"
    else
      register_check "Gem Vulnerabilities" WARN "Run 'bundle-audit check' to scan for CVEs"
    fi
  else
    register_check "bundle-audit Tool" WARN "Install with 'gem install bundler-audit' for vulnerability scanning"
  fi
else
  register_check "Gemfile.lock" WARN "No Gemfile.lock (run 'bundle install')"
fi

# === Rails Configuration Files ===
section "Rails Production Configuration"

# Check config/environments/production.rb
prod_config="$CONFIG_DIR/environments/production.rb"
if [[ -f "$prod_config" ]]; then
  register_check "Production Config" PASS "production.rb found"

  # Check force_ssl
  if grep -q "config.force_ssl = true" "$prod_config" 2>/dev/null; then
    register_check "Force SSL" PASS "Force SSL enabled in production"
  else
    register_check "Force SSL" FAIL "Force SSL not enabled (add config.force_ssl = true)"
  fi

  # Check log level
  if grep -qE "config.log_level = :(warn|error|fatal)" "$prod_config" 2>/dev/null; then
    register_check "Log Level" PASS "Production log level set appropriately"
  elif grep -q "config.log_level = :debug" "$prod_config" 2>/dev/null; then
    register_check "Log Level" FAIL "Debug logging enabled in production (security risk)"
  else
    register_check "Log Level" WARN "Log level not explicitly set (defaults to :debug)"
  fi

  # Check asset compilation
  if grep -q "config.assets.compile = false" "$prod_config" 2>/dev/null; then
    register_check "Asset Pipeline" PASS "Assets precompiled (config.assets.compile = false)"
  else
    register_check "Asset Pipeline" WARN "Assets may compile on-demand (precompile for production)"
  fi

  # Check consider_all_requests_local
  if grep -q "config.consider_all_requests_local.*=.*false" "$prod_config" 2>/dev/null; then
    register_check "Error Pages" PASS "Detailed errors disabled for production"
  else
    register_check "Error Pages" WARN "Detailed error pages may be shown (set consider_all_requests_local = false)"
  fi
else
  register_check "Production Config" WARN "config/environments/production.rb not found"
fi

# === Secrets & Credentials ===
section "Secrets Management"

# Check for secrets.yml (Rails 4.1-5.x)
if [[ -f "$CONFIG_DIR/secrets.yml" ]]; then
  secrets_yml="$CONFIG_DIR/secrets.yml"
  register_check "secrets.yml" PASS "Found (Rails 4.1-5.x style)"

  # Check secrets.yml permissions
  secrets_perms=$(stat -c '%a' "$secrets_yml" 2>/dev/null || stat -f '%Lp' "$secrets_yml" 2>/dev/null || echo "000")
  if [[ "$secrets_perms" == "600" || "$secrets_perms" == "640" ]]; then
    register_check "secrets.yml Perms" PASS "permissions $secrets_perms (secure)"
  else
    register_check "secrets.yml Perms" WARN "permissions $secrets_perms (should be 600 or 640)"
  fi

  # Check for hardcoded secrets
  if grep -qE "secret_key_base: [a-f0-9]{128}" "$secrets_yml" 2>/dev/null; then
    register_check "Secret Key Hardcoded" WARN "Secret key hardcoded in secrets.yml (use ENV vars)"
  fi
fi

# Check for credentials (Rails 5.2+)
if [[ -f "$CONFIG_DIR/credentials.yml.enc" ]]; then
  register_check "Encrypted Credentials" PASS "credentials.yml.enc found (Rails 5.2+ encrypted secrets)"

  # Check for master.key
  if [[ -f "$CONFIG_DIR/master.key" ]]; then
    register_check "Master Key" PASS "master.key present"

    # Check master.key permissions
    key_perms=$(stat -c '%a' "$CONFIG_DIR/master.key" 2>/dev/null || stat -f '%Lp' "$CONFIG_DIR/master.key" 2>/dev/null || echo "000")
    if [[ "$key_perms" == "600" ]]; then
      register_check "Master Key Perms" PASS "permissions $key_perms (secure)"
    else
      register_check "Master Key Perms" FAIL "permissions $key_perms (must be 600)"
    fi

    # Check if master.key is in .gitignore
    if [[ -f "$rails_root/.gitignore" ]]; then
      if grep -q "master.key" "$rails_root/.gitignore" 2>/dev/null; then
        register_check "Master Key Git" PASS "master.key in .gitignore"
      else
        register_check "Master Key Git" FAIL "master.key NOT in .gitignore (will expose secrets)"
      fi
    fi
  else
    register_check "Master Key" WARN "credentials.yml.enc present but no master.key (use $RAILS_MASTER_KEY env var)"
  fi
fi

# Check for .env files (dotenv gem)
if [[ -f "$rails_root/.env" ]]; then
  register_check ".env File" PASS ".env file found (dotenv configuration)"

  # Check .env permissions
  env_perms=$(stat -c '%a' "$rails_root/.env" 2>/dev/null || stat -f '%Lp' "$rails_root/.env" 2>/dev/null || echo "000")
  if [[ "$env_perms" =~ ^[0-7]00$ ]]; then
    register_check ".env Permissions" PASS "permissions $env_perms (secure)"
  else
    register_check ".env Permissions" WARN "permissions $env_perms (should restrict to owner only)"
  fi

  # Check if .env is in .gitignore
  if [[ -f "$rails_root/.gitignore" ]] && grep -q "^\.env$" "$rails_root/.gitignore" 2>/dev/null; then
    register_check ".env Git" PASS ".env in .gitignore"
  else
    register_check ".env Git" FAIL ".env NOT in .gitignore (will expose secrets)"
  fi
fi

# === Security Features ===
section "Rails Security Features"

# Check config/application.rb for security settings
app_config="$CONFIG_DIR/application.rb"
if [[ -f "$app_config" ]]; then
  # Check for CSRF protection
  if grep -q "protect_from_forgery" "$app_config" 2>/dev/null || grep -q "protect_from_forgery" "$CONFIG_DIR/initializers/devise.rb" 2>/dev/null; then
    register_check "CSRF Protection" PASS "protect_from_forgery enabled"
  else
    # CSRF is enabled by default in Rails, check if explicitly disabled
    if grep -q "protect_from_forgery.*:null_session\|:exception" "$rails_root/app/controllers/application_controller.rb" 2>/dev/null; then
      register_check "CSRF Protection" PASS "CSRF protection configured in ApplicationController"
    else
      register_check "CSRF Protection" WARN "Verify CSRF protection is active (check ApplicationController)"
    fi
  fi
fi

# Check for Strong Parameters usage (Rails 4+)
if [[ -d "$rails_root/app/controllers" ]]; then
  permit_count=$(grep -r "\.permit(" "$rails_root/app/controllers" 2>/dev/null | wc -l || echo "0")
  if [[ "$permit_count" -gt 0 ]]; then
    register_check "Strong Parameters" PASS "Strong Parameters in use ($permit_count occurrences)"
  else
    register_check "Strong Parameters" WARN "No Strong Parameters found (mass assignment protection missing)"
  fi
fi

# Check for SQL injection protection (parameterized queries)
if [[ -d "$rails_root/app/models" ]]; then
  unsafe_sql=$(grep -r "\.find_by_sql\|\.execute\|\.where(" "$rails_root/app/models" 2>/dev/null | grep -v "?" | wc -l || echo "0")
  if [[ "$unsafe_sql" -eq 0 ]]; then
    register_check "SQL Injection" PASS "No obvious unparameterized SQL queries"
  else
    register_check "SQL Injection" WARN "$unsafe_sql potential SQL injection point(s) (review queries)"
  fi
fi

# === Session Security ===
section "Session Configuration"

# Check config/initializers/session_store.rb
if [[ -f "$CONFIG_DIR/initializers/session_store.rb" ]]; then
  session_store="$CONFIG_DIR/initializers/session_store.rb"

  # Check for secure cookies
  if grep -q "secure: true" "$session_store" 2>/dev/null; then
    register_check "Secure Cookies" PASS "Secure flag set on session cookies"
  else
    register_check "Secure Cookies" WARN "Secure flag not set (cookies sent over HTTP)"
  fi

  # Check for httponly
  if grep -q "httponly: true" "$session_store" 2>/dev/null || ! grep -q "httponly:" "$session_store" 2>/dev/null; then
    register_check "HttpOnly Cookies" PASS "HttpOnly enabled (XSS protection)"
  else
    register_check "HttpOnly Cookies" WARN "HttpOnly not enabled"
  fi

  # Check for same_site
  if grep -qE "same_site: :(strict|lax)" "$session_store" 2>/dev/null; then
    register_check "SameSite Cookies" PASS "SameSite attribute configured"
  else
    register_check "SameSite Cookies" WARN "SameSite not set (CSRF risk)"
  fi
else
  register_check "Session Store" WARN "session_store.rb not found (using defaults)"
fi

# === Database Configuration ===
section "Database Security"

if [[ -f "$CONFIG_DIR/database.yml" ]]; then
  database_yml="$CONFIG_DIR/database.yml"
  register_check "database.yml" PASS "Database configuration found"

  # Check database.yml permissions
  db_perms=$(stat -c '%a' "$database_yml" 2>/dev/null || stat -f '%Lp' "$database_yml" 2>/dev/null || echo "000")
  if [[ "$db_perms" == "600" || "$db_perms" == "640" ]]; then
    register_check "database.yml Perms" PASS "permissions $db_perms (secure)"
  else
    register_check "database.yml Perms" WARN "permissions $db_perms (should be 600 or 640)"
  fi

  # Check for plaintext passwords
  if grep -qE "password: .+" "$database_yml" 2>/dev/null && ! grep -q "<%=" "$database_yml" 2>/dev/null; then
    register_check "Database Password" WARN "Plaintext password in database.yml (use ENV vars: <%= ENV['DB_PASSWORD'] %>)"
  else
    register_check "Database Password" PASS "Using environment variables for database password"
  fi
fi

# === Web Server Configuration ===
section "Web Server"

# Check for Puma configuration
if [[ -f "$CONFIG_DIR/puma.rb" ]]; then
  puma_config="$CONFIG_DIR/puma.rb"
  register_check "Puma" PASS "Puma configuration found"

  # Check bind address
  if grep -q 'bind.*127.0.0.1\|bind.*localhost' "$puma_config" 2>/dev/null; then
    register_check "Puma Bind" PASS "Puma bound to localhost (secure)"
  elif grep -q 'bind.*0.0.0.0' "$puma_config" 2>/dev/null; then
    register_check "Puma Bind" WARN "Puma bound to 0.0.0.0 (ensure behind reverse proxy)"
  fi

  # Check for SSL
  if grep -qE "ssl_bind|key_path|cert_path" "$puma_config" 2>/dev/null; then
    register_check "Puma SSL" PASS "SSL configuration present"
  else
    register_check "Puma SSL" WARN "No SSL config (ensure using reverse proxy with HTTPS)"
  fi
fi

# Check for Unicorn configuration
if [[ -f "$CONFIG_DIR/unicorn.rb" ]]; then
  register_check "Unicorn" PASS "Unicorn configuration found"
fi

# Check process user
rails_process=$(ps aux 2>/dev/null | grep -E '[p]uma|[u]nicorn|[r]ails' | head -n1 || echo "")
if [[ -n "$rails_process" ]]; then
  process_user=$(echo "$rails_process" | awk '{print $1}')
  if [[ "$process_user" == "root" ]]; then
    register_check "Process User" FAIL "Rails server running as root"
  else
    register_check "Process User" PASS "Rails running as $process_user (not root)"
  fi
fi

# === File Permissions ===
section "File Security"

# Check app directory permissions
if [[ -d "$rails_root/app" ]]; then
  app_perms=$(stat -c '%a' "$rails_root/app" 2>/dev/null || stat -f '%Lp' "$rails_root/app" 2>/dev/null || echo "000")
  if [[ "$app_perms" =~ ^7[0-5][0-5]$ ]]; then
    register_check "App Directory Perms" PASS "permissions $app_perms"
  else
    register_check "App Directory Perms" WARN "permissions $app_perms"
  fi
fi

# Check for world-writable files
writable_files=$(find "$rails_root" -type f -perm -002 2>/dev/null | wc -l || echo "0")
if [[ "$writable_files" -eq 0 ]]; then
  register_check "World-Writable Files" PASS "No world-writable files"
else
  register_check "World-Writable Files" WARN "$writable_files world-writable file(s)"
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
