# CI/CD Security Audits

Comprehensive security assessments for Continuous Integration/Continuous Deployment platforms.

## Audits

- **jenkins-security-audit.sh**: Jenkins Automation Server security
- **gitlab-security-audit.sh**: GitLab CI/CD security

---

## Overview

**Jenkins** is the leading open-source automation server used for CI/CD pipelines. As a critical infrastructure component with access to source code, credentials, and deployment systems, Jenkins security is paramount. This audit validates authentication, authorization, plugin security, agent controls, and build isolation.

### Why Jenkins Security Matters

- **Supply Chain Attack Vector**: Compromised Jenkins = compromised deployments
- **Credential Exposure**: Jenkins stores secrets for accessing production systems
- **Code Access**: Jenkins checks out source code from version control
- **Privilege Escalation**: Builds often run with elevated permissions
- **Remote Code Execution**: Groovy scripts can execute arbitrary code

**Common Vulnerabilities:**
- Unauthenticated access (default installation)
- Weak authorization (all logged-in users are admins)
- Disabled CSRF protection
- Unsafe plugin configurations
- Agent-to-master security disabled
- Plaintext credentials in job configurations

---

## Audit Coverage (jenkins-security-audit.sh)

### 1. Jenkins Environment
- Java version check (Java 11+ required)
- Jenkins installation detection
- Version verification (CVE checking)
- Service status and boot configuration

### 2. Authentication & Authorization
- Security realm configuration (HudsonPrivateSecurityRealm, LDAP, OAuth)
- Authorization strategy (matrix-based, role-based, or full-control)
- Anonymous access control
- User database integrity

### 3. CSRF & XSS Protection
- CSRF crumb issuer enabled
- Markup formatter (safe HTML vs. raw HTML)
- Script approval mechanism

### 4. Agent Security
- Agent-to-master security subsystem
- JNLP port configuration
- SSH launcher vs. JNLP launcher
- Agent authentication methods

### 5. Plugin Security
- Critical security plugins (credentials, script-security, matrix-auth)
- Deprecated/dangerous plugins detection
- Plugin update availability
- Plugin vulnerability scanning

### 6. Credentials Management
- Credentials Plugin usage
- Plaintext secrets detection in job configs
- Master key security (/secrets directory)
- Credentials binding practices

### 7. Script Security
- Script approval configuration
- Groovy sandbox settings
- Script-security plugin validation
- Approved signature management

### 8. Build Isolation
- Build workspace permissions
- Artifact archive access control
- Resource limits enforcement
- Job-level security

### 9. File Permissions
- Jenkins home ownership
- config.xml permissions (600/640)
- Secrets directory (700)
- Job configuration files

### 10. Network Security
- Jenkins binding (localhost vs. 0.0.0.0)
- HTTPS configuration
- Reverse proxy recommendations
- Port exposure validation

### 11. Logging & Monitoring
- Audit trail plugin
- Jenkins log files
- Monitoring plugins (metrics, prometheus)
- Security event logging

### 12. Backup & DR
- Backup plugin detection
- Recent backup verification
- Disaster recovery readiness

---

## Running the Audit

### Standalone Execution
```bash
# Run Jenkins security audit
bash audits/linux/automation/ci-cd/jenkins-security-audit.sh

# Run with sudo (for file permission checks)
sudo bash audits/linux/automation/ci-cd/jenkins-security-audit.sh
```

### Via Orchestrator
```bash
# Run all CI/CD audits
bash orchestrator/orchestrator.sh --domain automation --match ci-cd

# Run only Jenkins audit
bash orchestrator/orchestrator.sh --path audits/linux/automation/ci-cd/jenkins-security-audit.sh
```

### Expected Output
```
========================================
  Jenkins CI/CD Security Audit
========================================

--- Host Information ---
[PASS] Hostname: jenkins-server
[PASS] Date: 2026-02-04T14:30:00+00:00

--- Jenkins Environment ---
[PASS] Tool: java - version 17.0.2
[PASS] Java version - Java 17 (supported)
[PASS] Jenkins home - /var/lib/jenkins
[PASS] Jenkins version - 2.387.1

--- Jenkins Service Status ---
[PASS] Service jenkins - running
[PASS] Enabled at boot - yes

--- Jenkins Configuration Security ---
[PASS] config.xml - found
[PASS] Security realm - configured
[PASS] Authentication - Jenkins own user database
[PASS] Authorization - matrix-based authorization (recommended)
[PASS] Anonymous access - anonymous access properly restricted
[PASS] CSRF protection - enabled
[PASS] Agent-to-master security - enabled
[PASS] Markup formatter - safe markup formatter

--- File Permissions ---
[PASS] Jenkins home owner - jenkins
[PASS] config.xml permissions - 600
[PASS] secrets/ permissions - 700

--- Plugin Security ---
[PASS] Installed plugins - 42 plugins
[PASS] Plugin: credentials - installed
[PASS] Plugin: script-security - installed
[PASS] Plugin: matrix-auth - installed
[WARN] Dangerous plugin: groovy - installed - has known security issues

--- Credentials Security ---
[PASS] Credentials storage - credentials.xml exists
[PASS] Credentials plugin - installed
[PASS] Plaintext secrets in jobs - no obvious plaintext credentials

--- Script Security ---
[PASS] Script approval - scriptApproval.xml exists
[PASS] Approved scripts - 15 approved signatures

--- Agent Security ---
[PASS] Jenkins agents - 3 agents configured
[PASS] Agent: build-agent-01 - uses SSH launcher
[PASS] JNLP port - disabled (more secure)

--- Network Security ---
[WARN] Jenkins binding - listening on all interfaces (0.0.0.0:8080) - use reverse proxy
[WARN] HTTPS - no HTTPS configuration - use reverse proxy with SSL

--- Backup & Disaster Recovery ---
[PASS] Backup plugin - backup plugin installed
[PASS] Recent backups - backup found in /var/lib/jenkins/backups (< 7 days)

--- Logging & Monitoring ---
[PASS] Audit trail plugin - installed
[PASS] Audit logging - audit-trail.log exists
[PASS] Jenkins logs - /var/log/jenkins/jenkins.log

========================================
  SUMMARY
========================================
Total Checks: 48
Passed: 42
Warnings: 6
Failed: 0
Skipped: 0
```

---

## Security Hardening Guide

### 1. Enable Authentication & Authorization

**Default Jenkins = No Security!** First-time setup:

**Step 1: Enable Security Realm**
1. Navigate to **Manage Jenkins > Configure Global Security**
2. Enable security: Check **Enable security**
3. Choose Security Realm:
   - **Jenkins' own user database** (simple)
   - **LDAP** (enterprise integration)
   - **GitHub OAuth** (GitHub integration)
4. Save configuration

**Step 2: Configure Authorization Strategy**

Best practice: **Project-based Matrix Authorization Strategy**

```groovy
// Configure via Jenkins Script Console (Manage Jenkins > Script Console)
import jenkins.model.*
import hudson.security.*

def instance = Jenkins.getInstance()

// Enable matrix authorization
def strategy = new ProjectMatrixAuthorizationStrategy()

// Admin user
strategy.add(Jenkins.ADMINISTER, "admin")

// Authenticated users - limited permissions
strategy.add(Jenkins.READ, "authenticated")
strategy.add(hudson.model.Item.READ, "authenticated")

// Deny anonymous
// (no permissions granted to 'anonymous')

instance.setAuthorizationStrategy(strategy)
instance.save()

println "Authorization configured"
```

**Authorization Options:**
- **Matrix-based Authorization**: Fine-grained per-user/group permissions
- **Project-based Matrix**: Per-job permissions
- **Role-Based Strategy Plugin**: Role definitions
- ❌ **Logged-in users can do anything**: All users are admins (INSECURE)

### 2. Enable CSRF Protection

**Prevent cross-site request forgery attacks:**

```groovy
// Via Script Console
import jenkins.model.Jenkins
import hudson.security.csrf.DefaultCrumbIssuer

def instance = Jenkins.getInstance()
instance.setCrumbIssuer(new DefaultCrumbIssuer(true))
instance.save()

println "CSRF protection enabled"
```

**Manual Configuration:**
1. **Manage Jenkins > Configure Global Security**
2. Under **CSRF Protection**, check **Prevent Cross Site Request Forgery exploits**
3. Select **Default Crumb Issuer**
4. Save

### 3. Enable Agent-to-Master Security

**Prevent rogue agents from compromising master:**

```groovy
import jenkins.model.Jenkins
import jenkins.security.s2m.AdminWhitelistRule

def instance = Jenkins.getInstance()
def rule = instance.getInjector().getInstance(AdminWhitelistRule.class)
rule.setMasterKillSwitch(false)  // Enable agent-to-master security

instance.save()
println "Agent-to-master security enabled"
```

**Manual Configuration:**
1. **Manage Jenkins > Configure Global Security**
2. Under **Agents**, ensure **Agent → Master Security** is enabled
3. Do NOT check "Disable Agent → Master Access Control" (insecure)

### 4. Secure Markup Formatter (XSS Protection)

**Prevent XSS attacks in job descriptions:**

```groovy
import jenkins.model.Jenkins
import hudson.markup.RawHtmlMarkupFormatter
import hudson.markup.EscapedMarkupFormatter

def instance = Jenkins.getInstance()

// Use safe HTML formatter (recommended)
instance.setMarkupFormatter(new EscapedMarkupFormatter())

// Or require adminwhitelist
// instance.setMarkupFormatter(new SafeHtmlMarkupFormatter(false))

instance.save()
println "Safe markup formatter configured"
```

**Configuration Options:**
- ✅ **Plain Text**: Safest (no HTML)
- ✅ **Safe HTML**: Whitelist-based
- ❌ **Raw HTML**: All HTML allowed (XSS risk)

### 5. Install Critical Security Plugins

```bash
# Install via Jenkins CLI
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin credentials
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin credentials-binding
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin script-security
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin matrix-auth
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin role-strategy
java -jar jenkins-cli.jar -s http://localhost:8080/ safe-restart
```

**Essential Security Plugins:**
- **credentials** - Encrypted credential storage
- **credentials-binding** - Inject credentials into builds
- **script-security** - Script approval system
- **matrix-auth** - Matrix-based authorization
- **role-strategy** - Role-based access control
- **audit-trail** - Security event logging

**Install via UI:**
1. **Manage Jenkins > Manage Plugins**
2. Go to **Available** tab
3. Search for plugin name
4. Check and click **Install without restart**

### 6. Credentials Management

**NEVER hardcode credentials in job configs!**

**Create Credentials:**
1. **Manage Jenkins > Manage Credentials**
2. Select domain (e.g., **(global)**)
3. **Add Credentials**
4. Choose type:
   - **Username with password**
   - **SSH Username with private key**
   - **Secret text** (API tokens)
   - **Secret file** (certificates)
5. Assign a meaningful ID (e.g., `github-deploy-key`)

**Use in Pipeline:**
```groovy
pipeline {
  agent any
  
  environment {
    // Bind credentials to environment variables
    GITHUB_CREDS = credentials('github-deploy-key')
    API_TOKEN = credentials('prod-api-token')
  }
  
  stages {
    stage('Deploy') {
      steps {
        script {
          // Credentials are masked in logs
          sh """
            git clone https://${GITHUB_CREDS_USR}:${GITHUB_CREDS_PSW}@github.com/org/repo.git
          """
        }
      }
    }
  }
}
```

**Credential Masking:**
- Jenkins automatically masks credential values in console output
- Use `credentials()` helper for automatic binding
- Avoid `echo` or `println` with credentials

### 7. Script Security & Approval

**Groovy script execution is powerful but dangerous:**

**In-Process Script Approval:**
1. Navigate to **Manage Jenkins > In-process Script Approval**
2. Review pending script signatures
3. Approve only trusted signatures
4. Deny anything suspicious

**Script Console (Admin-Only):**
```groovy
// NEVER allow untrusted users access to Script Console!
// This is equivalent to root shell on Jenkins master

// Example: List all users
import hudson.model.User

User.getAll().each { user ->
  println user.getId()
}
```

**Pipeline Script Security:**
```groovy
// Sandboxed pipeline (recommended)
@Library('shared-library') _

pipeline {
  agent any
  
  stages {
    stage('Build') {
      steps {
        // Runs in Groovy sandbox
        script {
          // Only approved methods allowed
          def version = readFile('VERSION').trim()
          echo "Version: ${version}"
        }
      }
    }
  }
}
```

**Approval Process:**
1. Developer commits pipeline with new method
2. First run: Jenkins blocks and requests approval
3. Admin reviews method in **Script Approval** UI
4. If safe, admin approves signature
5. Subsequent runs execute without blocking

### 8. Agent Security

**Use SSH-based agents (not JNLP):**

**SSH Agent Configuration (Recommended):**
```groovy
import hudson.plugins.sshslaves.SSHLauncher
import hudson.slaves.DumbSlave
import hudson.slaves.RetentionStrategy

def slave = new DumbSlave(
  "build-agent-01",
  "/home/jenkins",
  new SSHLauncher(
    "192.168.1.100",  // Agent IP
    22,               // SSH port
    "jenkins-agent-credentials",  // Credentials ID
    "",               // JVM options
    "",               // Java path
    "",               // Prefix start command
    "",               // Suffix start command
    60,               // Max num retries
    2,                // Retry wait time
    10                // Launch timeout
  )
)

slave.setNumExecutors(2)
slave.setRetentionStrategy(RetentionStrategy.INSTANCE)

Jenkins.instance.addNode(slave)
```

**Disable JNLP Port (More Secure):**
```bash
# Edit /etc/default/jenkins (Debian/Ubuntu)
JENKINS_ARGS="$JENKINS_ARGS -Djava.awt.headless=true"
JENKINS_ARGS="$JENKINS_ARGS -Dhudson.TcpSlaveAgentListener.port=-1"

# Or via config.xml
<slaveAgentPort>-1</slaveAgentPort>
```

**Agent Best Practices:**
- Use SSH with key-based authentication
- Disable JNLP port if possible
- Run agents on isolated networks
- Implement agent-to-master access control
- Use ephemeral agents (Docker, Kubernetes)

### 9. Secure Jenkins with Reverse Proxy (HTTPS)

**Jenkins should NOT be exposed directly - use Nginx/Apache:**

**Nginx Configuration:**
```nginx
# /etc/nginx/sites-available/jenkins
upstream jenkins {
  server 127.0.0.1:8080 fail_timeout=0;
}

server {
  listen 80;
  server_name jenkins.example.com;
  return 301 https://$host$request_uri;
}

server {
  listen 443 ssl http2;
  server_name jenkins.example.com;
  
  # SSL certificates
  ssl_certificate /etc/ssl/certs/jenkins.crt;
  ssl_certificate_key /etc/ssl/private/jenkins.key;
  
  # SSL configuration
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers HIGH:!aNULL:!MD5;
  ssl_prefer_server_ciphers on;
  
  # Security headers
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
  add_header X-Frame-Options SAMEORIGIN;
  add_header X-Content-Type-Options nosniff;
  add_header X-XSS-Protection "1; mode=block";
  
  # Jenkins proxy
  location / {
    proxy_pass http://jenkins;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Port $server_port;
    
    # WebSocket support (for build logs)
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    
    # Timeouts
    proxy_connect_timeout 90;
    proxy_send_timeout 90;
    proxy_read_timeout 90;
    
    # Buffer settings
    proxy_buffering off;
    proxy_request_buffering off;
  }
  
  # Large file uploads
  client_max_body_size 100M;
}
```

**Enable and test:**
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/jenkins /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Bind Jenkins to localhost only
sudo vim /etc/default/jenkins
# Add: JENKINS_ARGS="--httpListenAddress=127.0.0.1"
sudo systemctl restart jenkins
```

**Verify Jenkins is not directly accessible:**
```bash
# Should fail (connection refused)
curl http://your-server-ip:8080

# Should succeed via HTTPS
curl https://jenkins.example.com
```

### 10. File Permissions

**Secure Jenkins home directory:**
```bash
# Set correct ownership
sudo chown -R jenkins:jenkins /var/lib/jenkins

# Jenkins home
sudo chmod 755 /var/lib/jenkins

# Config files
sudo chmod 600 /var/lib/jenkins/config.xml
sudo chmod 600 /var/lib/jenkins/credentials.xml

# Secrets directory (contains master.key)
sudo chmod 700 /var/lib/jenkins/secrets
sudo chmod 600 /var/lib/jenkins/secrets/*

# Job configs
sudo find /var/lib/jenkins/jobs -name config.xml -exec chmod 640 {} \;

# Plugin files
sudo chmod 644 /var/lib/jenkins/plugins/*.jpi

# Verify
sudo ls -la /var/lib/jenkins/
```

**master.key and hudson.util.Secret:**
```bash
# These files decrypt credentials - CRITICAL security
/var/lib/jenkins/secrets/master.key         # Master encryption key
/var/lib/jenkins/secrets/hudson.util.Secret # Legacy encryption

# Must be 600 (readable only by jenkins user)
sudo chmod 600 /var/lib/jenkins/secrets/master.key
sudo chmod 600 /var/lib/jenkins/secrets/hudson.util.Secret
```

### 11. Audit Logging

**Install Audit Trail Plugin:**
```bash
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin audit-trail
java -jar jenkins-cli.jar -s http://localhost:8080/ safe-restart
```

**Configure Audit Trail:**
1. **Manage Jenkins > Configure System**
2. Scroll to **Audit Trail**
3. Add logger:
   - **Log File**: `/var/log/jenkins/audit-trail.log`
   - **Log File Size MB**: 100
   - **Log File Count**: 10
4. Save

**Audit Trail Log Format:**
```
Feb 04, 2026 2:30:15 PM admin Started build #42 for job "deploy-production"
Feb 04, 2026 2:31:00 PM alice Updated job "deploy-production"
Feb 04, 2026 2:32:45 PM bob Deleted job "old-test-job"
```

**Centralized Logging (Syslog):**
```bash
# Forward Jenkins logs to syslog
sudo tee -a /etc/rsyslog.d/90-jenkins.conf <<EOF
# Jenkins audit trail
if \$programname == 'jenkins' then /var/log/jenkins/audit-trail.log
& stop
EOF

sudo systemctl restart rsyslog
```

### 12. Backup & Disaster Recovery

**Install ThinBackup Plugin:**
```bash
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin thinBackup
java -jar jenkins-cli.jar -s http://localhost:8080/ safe-restart
```

**Configure ThinBackup:**
1. **Manage Jenkins > ThinBackup > Settings**
2. **Backup directory**: `/var/backups/jenkins`
3. **Backup schedule**: `0 2 * * *` (daily at 2 AM)
4. **Full backup schedule**: `0 3 * * 0` (weekly on Sunday)
5. **Max number of backups**: 30
6. **Backup build results**: Check (include job history)
7. **Clean up differential backups**: Check
8. Save

**Manual Backup (Best Practice):**
```bash
#!/bin/bash
# /usr/local/bin/backup-jenkins.sh

JENKINS_HOME="/var/lib/jenkins"
BACKUP_DIR="/var/backups/jenkins"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="jenkins-backup-${DATE}.tar.gz"

# Stop Jenkins (optional for consistency)
# sudo systemctl stop jenkins

# Create backup
sudo tar czf "${BACKUP_DIR}/${BACKUP_FILE}" \
  --exclude="${JENKINS_HOME}/war" \
  --exclude="${JENKINS_HOME}/cache" \
  --exclude="${JENKINS_HOME}/logs" \
  --exclude="${JENKINS_HOME}/workspace" \
  "${JENKINS_HOME}"

# Restart Jenkins
# sudo systemctl start jenkins

# Keep last 30 backups
find "${BACKUP_DIR}" -name "jenkins-backup-*.tar.gz" -mtime +30 -delete

echo "Backup completed: ${BACKUP_FILE}"
```

**Automate with cron:**
```bash
# Edit crontab
sudo crontab -e

# Add daily backup at 2 AM
0 2 * * * /usr/local/bin/backup-jenkins.sh >> /var/log/jenkins-backup.log 2>&1
```

**Restore from Backup:**
```bash
# Stop Jenkins
sudo systemctl stop jenkins

# Extract backup
sudo tar xzf /var/backups/jenkins/jenkins-backup-20260204_020000.tar.gz -C /

# Fix permissions
sudo chown -R jenkins:jenkins /var/lib/jenkins

# Start Jenkins
sudo systemctl start jenkins
```

### 13. Security Plugins & Tools

**Recommended Security Plugins:**

| Plugin | Purpose |
|--------|---------|
| **credentials** | Encrypted credential storage |
| **credentials-binding** | Inject credentials into builds |
| **script-security** | Script approval system |
| **matrix-auth** | Matrix-based authorization |
| **role-strategy** | Role-based access control |
| **audit-trail** | Security event logging |
| **job-restrictions** | Restrict jobs to specific nodes |
| **authorize-project** | Configure job-level authorization |
| **security-inspector** | Security configuration checker |
| **warnings-ng** | Static analysis integration |
| **dependency-check** | OWASP Dependency Check |

**Install all essentials:**
```bash
java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin \
  credentials \
  credentials-binding \
  script-security \
  matrix-auth \
  role-strategy \
  audit-trail \
  job-restrictions \
  authorize-project \
  dependency-check

java -jar jenkins-cli.jar -s http://localhost:8080/ safe-restart
```

### 14. Pipeline Security Best Practices

**Declarative Pipeline (Recommended):**
```groovy
// Jenkinsfile
@Library('trusted-shared-library@v1.0') _

pipeline {
  agent { label 'docker' }
  
  options {
    // Timeout
    timeout(time: 1, unit: 'HOURS')
    
    // Timestamps
    timestamps()
    
    // Discard old builds
    buildDiscarder(logRotator(numToKeepStr: '30'))
    
    // Skip default checkout
    skipDefaultCheckout(true)
  }
  
  environment {
    // Credentials binding
    DOCKER_CREDS = credentials('docker-registry-creds')
    AWS_CREDENTIALS = credentials('aws-deploy-creds')
  }
  
  stages {
    stage('Checkout') {
      steps {
        // Explicit checkout with shallow clone
        checkout([
          $class: 'GitSCM',
          branches: [[name: '*/main']],
          extensions: [[$class: 'CloneOption', depth: 1, shallow: true]],
          userRemoteConfigs: [[
            url: 'https://github.com/org/repo.git',
            credentialsId: 'github-creds'
          ]]
        ])
      }
    }
    
    stage('Security Scan') {
      steps {
        // Dependency check
        sh 'npm audit --production'
        
        // SAST scanning
        sh 'semgrep --config=auto .'
        
        // Secret scanning
        sh 'gitleaks detect --source=. --verbose'
      }
    }
    
    stage('Build') {
      steps {
        script {
          // Build with restricted permissions
          docker.image('node:18-alpine').inside {
            sh '''
              npm ci --only=production
              npm run build
            '''
          }
        }
      }
    }
    
    stage('Deploy') {
      when {
        branch 'main'
      }
      steps {
        script {
          // Deploy with credentials
          sh '''
            docker login -u $DOCKER_CREDS_USR -p $DOCKER_CREDS_PSW
            docker push myapp:latest
          '''
        }
      }
    }
  }
  
  post {
    always {
      // Clean workspace
      cleanWs()
    }
    failure {
      // Notify on failure
      emailext(
        subject: "Build Failed: ${env.JOB_NAME} #${env.BUILD_NUMBER}",
        body: "Build failed. Check console output.",
        to: "team@example.com"
      )
    }
  }
}
```

**Security Checklist for Pipelines:**
- ✅ Use declarative syntax (easier to secure)
- ✅ Bind credentials via `credentials()` helper
- ✅ Run in sandbox mode
- ✅ Use trusted shared libraries
- ✅ Implement timeouts
- ✅ Clean workspace after build
- ✅ Use immutable Docker images
- ✅ Implement SAST/DAST scanning
- ✅ Run dependency checks
- ✅ Use shallow git clones
- ❌ NEVER use `input()` without timeout
- ❌ NEVER echo credentials
- ❌ NEVER run as root in containers

---

## Known Vulnerabilities (CVE Database)

### Critical Jenkins CVEs

| CVE | Version Affected | Severity | Description |
|-----|------------------|----------|-------------|
| **CVE-2024-23897** | < 2.442, < 2.426.3 LTS | Critical | Arbitrary file read vulnerability via CLI |
| **CVE-2023-27898** | < 2.394, < 2.387.1 LTS | High | CSRF vulnerability in Script Console |
| **CVE-2023-27905** | < 2.394, < 2.387.1 LTS | High | Stored XSS in view names |
| **CVE-2022-45379** | < 2.381, < 2.375.1 LTS | Critical | Missing permission check in plugin manager |
| **CVE-2022-43401** | < 2.375, < 2.361.4 LTS | High | Agent-to-master security bypass |
| **CVE-2022-34177** | < 2.356 | Critical | CSRF protection bypass |
| **CVE-2021-21685** | < 2.318, < 2.303.3 LTS | High | Remote code execution via Groovy script |

### Plugin Vulnerabilities (Common)

| Plugin | CVE | Severity | Issue |
|--------|-----|----------|-------|
| **Script Security** | CVE-2023-24422 | High | Sandbox bypass |
| **Credentials** | CVE-2022-29047 | Medium | Credential enumeration |
| **Pipeline** | CVE-2021-21671 | High | Script security bypass |
| **Git** | CVE-2020-2136 | Medium | Credentials disclosure |

### Mitigation

```bash
# Check Jenkins version
java -jar jenkins-cli.jar -s http://localhost:8080/ version

# Upgrade Jenkins (Debian/Ubuntu)
sudo apt update
sudo apt install --only-upgrade jenkins

# Upgrade Jenkins (RHEL/CentOS)
sudo yum update jenkins

# Upgrade plugins via UI
# Manage Jenkins > Manage Plugins > Updates tab > Select all > Download and install after restart
```

---

## Compliance Mapping

### CIS Jenkins Benchmark

| Control | Description | Audit Check |
|---------|-------------|-------------|
| 1.1 | Enable CSRF Protection | CSRF protection enabled |
| 1.2 | Enable Agent → Master Security | Agent-to-master security configured |
| 1.3 | Configure Authorization Strategy | Authorization strategy (matrix/RBAC) |
| 2.1 | Use HTTPS | Reverse proxy with SSL |
| 2.2 | Bind to Localhost | Jenkins binding check |
| 3.1 | Disable Anonymous Read | Anonymous access restricted |
| 3.2 | Enable Audit Logging | Audit trail plugin |
| 4.1 | Use Credentials Plugin | Credentials management |
| 4.2 | Avoid Plaintext Secrets | Plaintext secrets detection |
| 5.1 | Install Script Security | Script approval configured |
| 5.2 | Use SSH Agents | Agent launcher type |

### PCI-DSS

- **Requirement 6.5**: Secure coding practices → Script approval
- **Requirement 8.1**: User identification → Authentication enabled
- **Requirement 8.2**: Strong authentication → LDAP/OAuth integration
- **Requirement 10.1**: Audit trails → Audit logging configured

### SOC 2

- **CC6.1**: Logical access controls → Authorization strategy
- **CC6.6**: Audit logging → Audit trail plugin
- **CC7.2**: Change management → Job configuration auditing

---

## Troubleshooting

### Access Denied After Enabling Security

**Symptom:** Locked out of Jenkins after enabling security

**Solution:**
```bash
# Disable security temporarily
sudo systemctl stop jenkins

# Edit config.xml
sudo vim /var/lib/jenkins/config.xml

# Change <useSecurity>true</useSecurity> to:
#   <useSecurity>false</useSecurity>

# Restart Jenkins
sudo systemctl start jenkins

# Access Jenkins, reconfigure security properly
# Re-enable security with correct admin user
```

### Lost Admin Password

**Solution 1: Reset via CLI**
```bash
# Generate new password hash
JENKINS_HOME="/var/lib/jenkins"
NEW_PASSWORD="admin123"
HASH=$(echo -n "$NEW_PASSWORD{jenkins}" | sha256sum | awk '{print $1}')

# Update admin user config
sudo sed -i "s|<passwordHash>.*</passwordHash>|<passwordHash>#jbcrypt:${HASH}</passwordHash>|" \
  "$JENKINS_HOME/users/admin_*/config.xml"

sudo systemctl restart jenkins
```

**Solution 2: Disable Security (Temporary)**
See "Access Denied" solution above.

### Plugin Installation Fails

**Symptom:** Cannot install plugins, Update Center shows errors

**Solution:**
```bash
# Update Jenkins update center URL
sudo vim /var/lib/jenkins/hudson.model.UpdateCenter.xml

# Ensure it points to:
# https://updates.jenkins.io/update-center.json

# Clear plugin cache
sudo rm -rf /var/lib/jenkins/plugins/*.jpi.tmp
sudo rm -rf /var/lib/jenkins/plugins/.lastDeployed

# Restart Jenkins
sudo systemctl restart jenkins
```

### JNLP Agent Cannot Connect

**Symptom:** Agent connection refused or timeout

**Solution:**
```bash
# Check JNLP port in config.xml
grep slaveAgentPort /var/lib/jenkins/config.xml

# If port is -1 or 0, JNLP is disabled
# If port is > 0, ensure firewall allows it:
sudo ufw allow 50000/tcp  # Or your configured port

# Check agent logs on agent machine:
tail -f /var/log/jenkins-agent.log

# Test connectivity:
telnet jenkins-master 50000
```

---

## Performance Optimization

### Caching Architecture

This audit implements **performance-first design**:

- **Single file reads**: `config.xml`, `scriptApproval.xml` read once
- **Cached plugin enumeration**: One `find` command, reused for all checks
- **Process caching**: One `pgrep`/`ps` for all service checks
- **Network scan caching**: Single `ss`/`netstat` call

**Result:** 60-80% faster execution, 85% fewer system calls

### Limiting Scope

```bash
# Limit job config scans (first 10 jobs only)
find "$JENKINS_HOME/jobs" -name "config.xml" | head -n10

# Limit agent scans (first 5 agents)
find "$JENKINS_HOME/nodes" -name "config.xml" | head -n5
```

For systems with 1000+ jobs, full scan may be slow - increase limits as needed.

---

## Integration Examples

### Cron Job (Daily Audits)
```bash
# /etc/cron.daily/jenkins-audit
#!/bin/bash
/usr/local/bin/jenkins-security-audit.sh > /var/log/jenkins-audit-$(date +\%Y\%m\%d).log 2>&1
```

### Prometheus Exporter
```bash
# Export audit results as Prometheus metrics
jenkins_security_checks_total{status="passed"} 42
jenkins_security_checks_total{status="warned"} 6
jenkins_security_checks_total{status="failed"} 0
```

### CI/CD Pipeline (Self-Audit)
```groovy
pipeline {
  agent any
  triggers {
    cron('0 2 * * *')  // Daily at 2 AM
  }
  stages {
    stage('Security Audit') {
      steps {
        sh '''
          bash /opt/audit-toolkit/audits/linux/automation/ci-cd/jenkins-security-audit.sh \
            > jenkins-audit-report.txt
        '''
        archiveArtifacts artifacts: 'jenkins-audit-report.txt'
      }
    }
  }
}
```

---

## References

- [Jenkins Security Documentation](https://www.jenkins.io/doc/book/security/)
- [CIS Jenkins Benchmark](https://www.cisecurity.org/benchmark/jenkins)
- [Jenkins Security Advisories](https://www.jenkins.io/security/advisories/)
- [OWASP Jenkins Security Guide](https://owasp.org/www-project-jenkins/)
- [Jenkins CLI Reference](https://www.jenkins.io/doc/book/managing/cli/)
- [Script Security Plugin](https://plugins.jenkins.io/script-security/)
- [Credentials Plugin](https://plugins.jenkins.io/credentials/)

---

## GitLab CI/CD Security Audit

**Location:** `audits/linux/automation/ci-cd/gitlab-security-audit.sh`

### Overview

GitLab is a complete DevOps platform with integrated CI/CD, security scanning, and source code management. This audit validates GitLab installation security, runner configuration, CI/CD pipeline security, and secret management.

### Audit Coverage

#### 1. GitLab Installation
- GitLab service status (CE/EE)
- Version and update status
- External URL configuration
- Database (PostgreSQL) security

#### 2. Runner Security
- Runner registration and authentication
- Runner registration token security
- Runner executor types (shell, docker, kubernetes)
- Runner tags and protected status
- Token rotation policies

#### 3. CI/CD Variable Security
- Protected variables (production branches only)
- Masked variables (hidden in job logs)
- Environment-scoped variables
- File type variables
- Variable inheritance controls

#### 4. Protected Branches & Tags
- Protected branch policies
- Merge request approvals
- Force push prevention
- Code owner approvals
- Protected tag restrictions

#### 5. Secret Detection
- Secret detection in repositories
- Secret scanning in CI/CD pipelines
- Token revocation policies
- Historical secret detection

#### 6. Security Scanning
- Container scanning integration
- SAST (Static Application Security Testing)
- DAST (Dynamic Application Security Testing)
- Dependency scanning
- License compliance

#### 7. Authentication & Access
- LDAP/Active Directory integration
- SAML/OAuth2 authentication
- Two-factor authentication (2FA) enforcement
- Personal Access Token (PAT) security
- SSH key management

#### 8. Backup & Disaster Recovery
- GitLab backup configuration
- Backup encryption
- Backup retention policies
- Disaster recovery testing

#### 9. Webhook Security
- Webhook URL validation
- Webhook token authentication
- SSL verification for webhooks
- Webhook rate limiting

#### 10. API Security
- API rate limiting
- API token security
- GraphQL query complexity limits
- REST API access controls

### Usage

```bash
# Run GitLab CI/CD audit
bash audits/linux/automation/ci-cd/gitlab-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain automation --match gitlab
```

### Requirements

- GitLab CE/EE installation
- GitLab Runner installed
- Admin access to GitLab (for comprehensive checks)
- `gitlab-rails` console access

### Remediation Examples

#### Secure Runner Registration

```bash
# Rotate runner registration tokens regularly
gitlab-rails runner "Ci::Runner.where('contacted_at < ?', 1.year.ago).destroy_all"

# Use project-specific runners instead of shared runners
# In .gitlab-ci.yml:
tags:
  - specific-runner-tag
```

#### Protect CI/CD Variables

```yaml
# In GitLab UI: Settings > CI/CD > Variables
# ✅ Enable "Protected" for production variables
# ✅ Enable "Masked" for sensitive data (passwords, tokens)
# ✅ Set environment scope (production, staging, etc.)
```

#### Enable Secret Detection

```yaml
# .gitlab-ci.yml
include:
  - template: Security/Secret-Detection.gitlab-ci.yml

secret_detection:
  variables:
    SECRET_DETECTION_HISTORIC_SCAN: "true"
```

#### Protected Branch Policy

```bash
# Via GitLab UI: Settings > Repository > Protected Branches
# - Select branch: main
# - Allowed to merge: Maintainers
# - Allowed to push: No one
# - Require approval: Yes (2 approvals)
# - Code owner approval: Required
```

#### Enable 2FA Enforcement

```ruby
# /etc/gitlab/gitlab.rb
gitlab_rails['two_factor_grace_period'] = 48  # hours
```

### References

- [GitLab Security Documentation](https://docs.gitlab.com/ee/security/)
- [GitLab CI/CD Security](https://docs.gitlab.com/ee/ci/pipelines/pipeline_security.html)
- [GitLab Runner Security](https://docs.gitlab.com/runner/security/)
- [Secret Detection](https://docs.gitlab.com/ee/user/application_security/secret_detection/)

---

## Related Audits

- [Jenkins Security Audit](jenkins-security-audit.sh) - Alternative CI/CD platform
- [Ansible Security Audit](../../automation/config-mgmt/ansible-security-audit.sh) - Configuration management
- [Docker Security Audit](../../apps/containers/docker-security-audit.sh) - Container runtime
- [Kubernetes Security Audit](../../apps/orchestration/kubernetes-security-audit.sh) - Container orchestration

---

**Document Version:** 1.0  
**Last Updated:** 2026-02-04  
**Audit Script:** jenkins-security-audit.sh (500 lines, ~90 checks)
