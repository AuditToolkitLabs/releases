#!/usr/bin/env bash
# GitLab CI/CD Security Audit
# Checks GitLab installation, runner security, CI/CD variable protection, and pipeline best practices

# @elevation: partial
# @elevation-reason: Service status checks and system config file access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
GITLAB_PATHS=(
  "/opt/gitlab"
  "/etc/gitlab"
  "/var/opt/gitlab"
)

GITLAB_RUNNER_PATHS=(
  "/etc/gitlab-runner"
  "/opt/gitlab-runner"
)

# === Performance: Cache variables ===
GITLAB_VERSION=""
GITLAB_CONFIG=""
RUNNER_CONFIG=""
GITLAB_HOME=""
GITLAB_INSTALLED=false

# === Helper Functions ===

# Detect GitLab installation
detect_gitlab() {
  # Check for GitLab service
  if pkg_installed gitlab-ce || pkg_installed gitlab-ee; then
    GITLAB_INSTALLED=true

    # Find GitLab home
    for path in "${GITLAB_PATHS[@]}"; do
      if [[ -d "$path" ]]; then
        GITLAB_HOME="$path"
        break
      fi
    done

    # Find gitlab.rb config
    if [[ -f "/etc/gitlab/gitlab.rb" ]]; then
      GITLAB_CONFIG="/etc/gitlab/gitlab.rb"
    fi

    return 0
  fi

  # Check if GitLab is running (service or process)
  if systemctl is-active gitlab-runsvdir >/dev/null 2>&1 || pgrep -f gitlab-ctl >/dev/null 2>&1; then
    GITLAB_INSTALLED=true
    GITLAB_HOME="/opt/gitlab"
    GITLAB_CONFIG="/etc/gitlab/gitlab.rb"
    return 0
  fi

  return 1
}

# Get GitLab version
get_gitlab_version() {
  if [[ -n "$GITLAB_VERSION" ]]; then
    echo "$GITLAB_VERSION"
    return 0
  fi

  if command -v gitlab-rake >/dev/null 2>&1; then
    version=$(gitlab-rake gitlab:env:info 2>/dev/null | grep "GitLab information" -A5 | grep "Version:" | awk '{print $2}' || echo "unknown")
    GITLAB_VERSION="$version"
    echo "$version"
  elif command -v gitlab-ctl >/dev/null 2>&1; then
    version=$(gitlab-ctl status 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    GITLAB_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Find GitLab Runner config
find_runner_config() {
  if [[ -n "$RUNNER_CONFIG" ]]; then
    echo "$RUNNER_CONFIG"
    return 0
  fi

  for path in "${GITLAB_RUNNER_PATHS[@]}"; do
    if [[ -f "$path/config.toml" ]]; then
      RUNNER_CONFIG="$path/config.toml"
      echo "$path/config.toml"
      return 0
    fi
  done

  echo ""
}

# === MAIN AUDIT ===

section "GitLab Detection"

if ! detect_gitlab; then
  register_check "GitLab Installed" SKIP "GitLab not detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "GitLab Installed" PASS "GitLab detected"

# Get GitLab version
gitlab_ver=$(get_gitlab_version)
if [[ "$gitlab_ver" != "unknown" ]]; then
  register_check "GitLab Version" PASS "GitLab $gitlab_ver"

  # Check for old versions (warn if < 15.0)
  major=$(echo "$gitlab_ver" | cut -d. -f1)
  if [[ "$major" -lt 15 ]]; then
    register_check "Version Status" WARN "GitLab $major.x may be outdated (current is 17.x, consider upgrading)"
  else
    register_check "Version Status" PASS "GitLab version recent"
  fi
else
  register_check "GitLab Version" WARN "Unable to determine GitLab version"
fi

# === GitLab Service Status ===
section "GitLab Services"

if systemctl is-active gitlab-runsvdir >/dev/null 2>&1; then
  register_check "GitLab Service" PASS "gitlab-runsvdir running"
elif pgrep -f gitlab-ctl >/dev/null  2>&1; then
  register_check "GitLab Service" PASS "GitLab processes running"
else
  register_check "GitLab Service" FAIL "GitLab service not running"
fi

# Check individual GitLab components
if command -v gitlab-ctl >/dev/null 2>&1; then
  gitlab_status=$(gitlab-ctl status 2>/dev/null || echo "")

  if [[ -n "$gitlab_status" ]]; then
    # Check PostgreSQL
    if echo "$gitlab_status" | grep -q "run: postgresql"; then
      register_check "PostgreSQL" PASS "running"
    else
      register_check "PostgreSQL" WARN "not running or not found"
    fi

    # Check Redis
    if echo "$gitlab_status" | grep -q "run: redis"; then
      register_check "Redis" PASS "running"
    fi

    # Check Gitaly (Git RPC service)
    if echo "$gitlab_status" | grep -q "run: gitaly"; then
      register_check "Gitaly" PASS "running"
    fi

    # Check Puma (web server)
    if echo "$gitlab_status" | grep -q "run: puma"; then
      register_check "Puma" PASS "running"
    fi
  fi
fi

# === GitLab Configuration  ===
section "GitLab Configuration Security"

if [[ -n "$GITLAB_CONFIG" && -f "$GITLAB_CONFIG" ]]; then
  register_check "gitlab.rb Config" PASS "found at $GITLAB_CONFIG"

  # Check config file permissions
  config_perms=$(stat -c '%a' "$GITLAB_CONFIG" 2>/dev/null || stat -f '%Lp' "$GITLAB_CONFIG" 2>/dev/null || echo "000")
  if [[ "$config_perms" == "600" ]]; then
    register_check "Config Permissions" PASS "permissions $config_perms (secure)"
  else
    register_check "Config Permissions" WARN "permissions $config_perms (should be 600)"
  fi

  # Check HTTPS configuration
  if grep -q "^external_url.*https://" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "HTTPS External URL" PASS "GitLab configured with HTTPS"
  else
    register_check "HTTPS External URL" WARN "External URL not using HTTPS (security risk)"
  fi

  # Check SSH host key algorithms
  if grep -qE "gitlab_rails\['gitlab_shell_ssh_port'\]" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "SSH Port" PASS "Custom SSH port configured"
  fi

  # Check database encryption
  if grep -q "gitlab_rails\['db_key_base'\]" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "DB Encryption Key" PASS "Database encryption key configured"
  else
    register_check "DB Encryption Key" WARN "Database encryption key not set (use gitlab_rails['db_key_base'])"
  fi

  # Check two-factor authentication
  if grep -q "gitlab_rails\['require_two_factor_authentication'\] = true" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "2FA Enforcement" PASS "Two-factor authentication required"
  else
    register_check "2FA Enforcement" WARN "2FA not enforced (consider enabling)"
  fi

  # Check session timeout
  if grep -qE "gitlab_rails\['session_expire_delay'\]" "$GITLAB_CONFIG" 2>/dev/null; then
    timeout=$(grep "gitlab_rails\['session_expire_delay'\]" "$GITLAB_CONFIG" | grep -oE '[0-9]+' || echo "10080")
    if [[ "$timeout" -le 1440 ]]; then
      register_check "Session Timeout" PASS "Session timeout: ${timeout}min (secure)"
    else
      register_check "Session Timeout" WARN "Session timeout: ${timeout}min (consider reducing)"
    fi
  else
    register_check "Session Timeout" WARN "Session timeout not set (default 7 days)"
  fi

  # Check backup configuration
  if grep -qE "gitlab_rails\['backup_path'\]" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "Backup Configuration" PASS "Backup path configured"
  else
    register_check "Backup Configuration" WARN "Backup path not explicitly configured"
  fi
else
  register_check "gitlab.rb Config" WARN "Configuration file not found"
fi

# === GitLab Runner Security ===
section "GitLab Runner"

# Check if GitLab Runner is installed
if command -v gitlab-runner >/dev/null 2>&1; then
  register_check "GitLab Runner" PASS "gitlab-runner command available"

  # Get runner version
  runner_ver=$(gitlab-runner --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
  if [[ "$runner_ver" != "unknown" ]]; then
    register_check "Runner Version" PASS "GitLab Runner $runner_ver"
  fi

  # Check runner service
  if systemctl is-active gitlab-runner >/dev/null 2>&1; then
    register_check "Runner Service" PASS "gitlab-runner service running"
  elif pgrep -f gitlab-runner >/dev/null 2>&1; then
    register_check "Runner Service" PASS "gitlab-runner process running"
  else
    register_check "Runner Service" WARN "gitlab-runner not running"
  fi

  # Find runner config
  runner_config=$(find_runner_config)
  if [[ -n "$runner_config" ]]; then
    register_check "Runner Config" PASS "found at $runner_config"

    # Check config file permissions
    runner_perms=$(stat -c '%a' "$runner_config" 2>/dev/null || stat -f '%Lp' "$runner_config" 2>/dev/null || echo "000")
    if [[ "$runner_perms" == "600" ]]; then
      register_check "Runner Config Perms" PASS "permissions $runner_perms (secure)"
    else
      register_check "Runner Config Perms" WARN "permissions $runner_perms (should be 600, contains tokens)"
    fi

    # Check for registration tokens (these should be protected)
    if grep -q "registration_token" "$runner_config" 2>/dev/null; then
      register_check "Registration Token" WARN "Registration token in config (secure this file)"
    fi

    # Check runner executor
    executors=$(grep "executor" "$runner_config" 2>/dev/null | awk -F'"' '{print $2}' | sort -u || echo "")
    if [[ -n "$executors" ]]; then
      register_check "Runner Executors" PASS "executors: $executors"

      # Check for shell executor (less secure)
      if echo "$executors" | grep -q "shell"; then
        register_check "Shell Executor" WARN "Shell executor in use (consider docker for isolation)"
      fi

      # Check for docker executor
      if echo "$executors" | grep -q "docker"; then
        register_check "Docker Executor" PASS "Docker executor configured (good isolation)"

        # Check for privileged mode
        if grep -q "privileged = true" "$runner_config" 2>/dev/null; then
          register_check "Docker Privileged" FAIL "Privileged Docker mode enabled (security risk)"
        else
          register_check "Docker Privileged" PASS "Docker not in privileged mode"
        fi
      fi
    fi

    # Check for concurrent job limits
    if grep -qE "^concurrent *= *[0-9]+" "$runner_config" 2>/dev/null; then
      concurrent=$(grep "^concurrent" "$runner_config" | grep -oE '[0-9]+' || echo "1")
      register_check "Concurrent Jobs" PASS "limit: $concurrent"
    fi
  else
    register_check "Runner Config" WARN "config.toml not found"
  fi
else
  register_check "GitLab Runner" SKIP "gitlab-runner not installed"
fi

# === CI/CD Security Features ===
section "CI/CD Security (Requires GitLab API Access)"

# Note: Most CI/CD settings require GitLab API access or web UI
register_check "CI/CD Variables" WARN "Verify protected/masked variables via GitLab UI or API"
register_check "Protected Branches" WARN "Verify protected branches (main/master) in GitLab project settings"
register_check "Merge Request Approvals" WARN "Check if MR approvals required for protected branches"
register_check "Pipeline Permissions" WARN "Review CI/CD permissions in Settings > CI/CD > General pipelines"

# Check for .gitlab-ci.yml in common locations (if auditing a project)
if [[ -f "$HOME/.gitlab-ci.yml" ]] || [[ -f "$(pwd)/.gitlab-ci.yml" ]]; then
  gitlab_ci_file=""
  if [[ -f "$HOME/.gitlab-ci.yml" ]]; then
    gitlab_ci_file="$HOME/.gitlab-ci.yml"
  else
    gitlab_ci_file="$(pwd)/.gitlab-ci.yml"
  fi

  register_check ".gitlab-ci.yml" PASS "Found at $gitlab_ci_file"

  # Check for secrets in pipeline file
  if grep -qE '(password|secret|token|key).*:' "$gitlab_ci_file" 2>/dev/null; then
    register_check "Hardcoded Secrets" WARN "Possible secrets in .gitlab-ci.yml (use CI/CD variables)"
  else
    register_check "Hardcoded Secrets" PASS "No obvious secrets in pipeline file"
  fi

  # Check for script safety
  if grep -q "eval\|curl.*sh" "$gitlab_ci_file" 2>/dev/null; then
    register_check "Pipeline Script Safety" WARN "Potentially unsafe commands (eval, curl|sh) in pipeline"
  fi
fi

# === Container Registry Security ===
section "Container Registry"

if [[ -n "$GITLAB_CONFIG" ]] && grep -q "registry_external_url" "$GITLAB_CONFIG" 2>/dev/null; then
  register_check "Registry Enabled" PASS "GitLab Container Registry configured"

  # Check if registry uses HTTPS
  if grep -q "registry_external_url.*https://" "$GITLAB_CONFIG" 2>/dev/null; then
    register_check "Registry HTTPS" PASS "Container Registry using HTTPS"
  else
    register_check "Registry HTTPS" FAIL "Container Registry not using HTTPS"
  fi

  # Check registry storage path
  if grep -qE "gitlab_rails\['registry_path'\]" "$GITLAB_CONFIG" 2>/dev/null; then
    registry_path=$(grep "gitlab_rails\['registry_path'\]" "$GITLAB_CONFIG" | cut -d"'" -f4 || echo "")
    if [[ -d "$registry_path" ]]; then
      # Check permissions
      registry_perms=$(stat -c '%a' "$registry_path" 2>/dev/null || stat -f '%Lp' "$registry_path" 2>/dev/null || echo "000")
      if [[ "$registry_perms" =~ ^7[0-5][0-5]$ ]]; then
        register_check "Registry Storage Perms" PASS "permissions $registry_perms"
      fi
    fi
  fi
else
  register_check "Registry Enabled" SKIP "Container Registry not enabled"
fi

# === SSH Security ===
section "Git SSH Access"

# Check if GitLab Shell SSHauthorized_keys file exists
if [[ -d "/var/opt/gitlab/.ssh" ]]; then
  if [[ -f "/var/opt/gitlab/.ssh/authorized_keys" ]]; then
    register_check "SSH Authorized Keys" PASS "GitLab managed SSH keys"

    # Check file permissions
    auth_keys_perms=$(stat -c '%a' "/var/opt/gitlab/.ssh/authorized_keys" 2>/dev/null || stat -f '%Lp' "/var/opt/gitlab/.ssh/authorized_keys" 2>/dev/null || echo "000")
    if [[ "$auth_keys_perms" == "600" ]]; then
      register_check "SSH Key Permissions" PASS "permissions $auth_keys_perms"
    else
      register_check "SSH Key Permissions" WARN "permissions $auth_keys_perms (should be 600)"
    fi
  fi
fi

# Check SSH host key algorithms
if [[ -f "/etc/ssh/sshd_config" ]]; then
  if grep -qE "^HostKeyAlgorithms.*ssh-rsa" /etc/ssh/sshd_config 2>/dev/null; then
    register_check "SSH Algorithms" WARN "ssh-rsa algorithm enabled (consider removing, use ed25519)"
  else
    register_check "SSH Algorithms" PASS "Modern SSH algorithms in use"
  fi
fi

# === Database Security ===
section "PostgreSQL Database"

# Check PostgreSQL service (GitLab bundled)
if pgrep -f "postgres.*gitlab" >/dev/null 2>&1; then
  register_check "PostgreSQL" PASS "PostgreSQL running"

  # Check for PostgreSQL backups
  if [[ -d "/var/opt/gitlab/backups" ]]; then
    backup_count=$(ls -1 /var/opt/gitlab/backups/*.tar 2>/dev/null | wc -l || echo "0")
    if [[ "$backup_count" -gt 0 ]]; then
      register_check "Database Backups" PASS "$backup_count backup file(s) found"

      # Check backup age
      latest_backup=$(ls -t /var/opt/gitlab/backups/*.tar 2>/dev/null | head -n1 || echo "")
      if [[ -n "$latest_backup" ]]; then
        backup_age=$(($(date +%s) - $(stat -c %Y "$latest_backup" 2>/dev/null || echo "0")))
        backup_days=$((backup_age / 86400))
        if [[ "$backup_days" -le 1 ]]; then
          register_check "Backup Freshness" PASS "Latest backup: $backup_days day(s) old"
        elif [[ "$backup_days" -le 7 ]]; then
          register_check "Backup Freshness" WARN "Latest backup: $backup_days days old"
        else
          register_check "Backup Freshness" FAIL "Latest backup: $backup_days days old (stale)"
        fi
      fi
    else
      register_check "Database Backups" WARN "No backup files found in /var/opt/gitlab/backups"
    fi
  fi
fi

# === Redis Security ===
section "Redis (Sidekiq/Cache)"

# Check Redis service
if pgrep -f "redis-server.*gitlab" >/dev/null 2>&1 || systemctl is-active redis@gitlab >/dev/null 2>&1; then
  register_check "Redis Service" PASS "Redis running"

  # Check Redis configuration (GitLab bundled)
  redis_config="/var/opt/gitlab/redis/redis.conf"
  if [[ -f "$redis_config" ]]; then
    # Check if requirepass is set
    if grep -q "^requirepass" "$redis_config" 2>/dev/null; then
      register_check "Redis Authentication" PASS "requirepass configured"
    else
      register_check "Redis Authentication" WARN "No Redis password (bundled instance, may be OK)"
    fi

    # Check bind address
    if grep -q "^bind 127.0.0.1" "$redis_config" 2>/dev/null; then
      register_check "Redis Binding" PASS "Bound to localhost"
    elif grep -q "^bind 0.0.0.0" "$redis_config" 2>/dev/null; then
      register_check "Redis Binding" WARN "Bound to 0.0.0.0 (exposed to network)"
    fi
  fi
fi

# === Logging & Monitoring ===
section "Logging & Monitoring"

# Check for log files
if [[ -d "/var/log/gitlab" ]]; then
  register_check "GitLab Logs" PASS "Log directory: /var/log/gitlab"

  # Check log file sizes (warn if too large)
  large_logs=$(find /var/log/gitlab -name "*.log" -size +100M 2>/dev/null | wc -l || echo "0")
  if [[ "$large_logs" -gt 0 ]]; then
    register_check "Log Rotation" WARN "$large_logs log file(s) >100MB (configure log rotation)"
  else
    register_check "Log Rotation" PASS "Log files appropriately sized"
  fi
fi

# Check Prometheus monitoring
if pgrep -f "prometheus.*gitlab" >/dev/null 2>&1; then
  register_check "Prometheus Monitoring" PASS "Prometheus running"
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
