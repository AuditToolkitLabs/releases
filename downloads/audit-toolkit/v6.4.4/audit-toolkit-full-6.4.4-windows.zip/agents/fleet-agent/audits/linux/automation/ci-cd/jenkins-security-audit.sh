#!/usr/bin/env bash
# Jenkins CI/CD Security Audit (portable) - Performance Optimized
# Checks Jenkins installation, authentication, authorization, plugins, and security configurations

# @elevation: partial
# @elevation-reason: Service status checks and Jenkins home directory access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
JENKINS_HOME="${JENKINS_HOME:-/var/lib/jenkins}"

# === Performance: Cache variables ===
JENKINS_VERSION=""
JENKINS_CONFIG=""
JENKINS_PLUGINS=""

# OPTIMIZED: Get Jenkins version (called once)
get_jenkins_version() {
  if [[ -n "$JENKINS_VERSION" ]]; then
    echo "$JENKINS_VERSION"
    return 0
  fi

  # Try CLI first
  if [[ -f "$JENKINS_HOME/jenkins-cli.jar" ]]; then
    JENKINS_VERSION=$(java -jar "$JENKINS_HOME/jenkins-cli.jar" -s http://localhost:8080/ version 2>/dev/null || echo "")
  fi

  # Fallback to version file
  if [[ -z "$JENKINS_VERSION" ]] && [[ -f "$JENKINS_HOME/config.xml" ]]; then
    JENKINS_VERSION=$(grep -oP '<version>\K[^<]+' "$JENKINS_HOME/config.xml" 2>/dev/null || echo "")
  fi

  echo "$JENKINS_VERSION"
}

# OPTIMIZED: Get Jenkins config.xml (called once)
get_jenkins_config() {
  if [[ -n "$JENKINS_CONFIG" ]]; then
    echo "$JENKINS_CONFIG"
    return 0
  fi

  if [[ -f "$JENKINS_HOME/config.xml" ]]; then
    JENKINS_CONFIG=$(cat "$JENKINS_HOME/config.xml" 2>/dev/null || echo "")
  fi

  echo "$JENKINS_CONFIG"
}

# OPTIMIZED: Get installed plugins (called once)
get_jenkins_plugins() {
  if [[ -n "$JENKINS_PLUGINS" ]]; then
    echo "$JENKINS_PLUGINS"
    return 0
  fi

  if [[ -d "$JENKINS_HOME/plugins" ]]; then
    JENKINS_PLUGINS=$(find "$JENKINS_HOME/plugins" -maxdepth 1 \( -name "*.jpi" -o -name "*.hpi" \) -print0 2>/dev/null | xargs -0 -r basename -a -s .jpi -s .hpi || echo "")
  fi

  echo "$JENKINS_PLUGINS"
}

# Check if XML contains tag
has_xml_tag() {
  local xml="$1"
  local tag="$2"

  echo "$xml" | grep -q "<${tag}>" 2>/dev/null
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for Jenkins and Java
section "Jenkins Environment"

if command -v java >/dev/null 2>&1; then
  java_version=$(java -version 2>&1 | grep -oP 'version "\K[^"]+' | head -n1)
  register_check "Tool: java" PASS "version $java_version"

  # Check Java version (Jenkins requires Java 11+)
  java_major=$(echo "$java_version" | cut -d. -f1)
  if [[ "$java_major" -ge 11 ]]; then
    register_check "Java version" PASS "Java $java_major (supported)"
  else
    register_check "Java version" FAIL "Java $java_major (Jenkins requires Java 11+)"
  fi
else
  register_check "Tool: java" FAIL "Java not found - required for Jenkins"
fi

# Check Jenkins installation
if [[ -d "$JENKINS_HOME" ]]; then
  register_check "Jenkins home" PASS "$JENKINS_HOME"

  jenkins_version=$(get_jenkins_version)
  if [[ -n "$jenkins_version" ]]; then
    register_check "Jenkins version" PASS "$jenkins_version"

    # Check for known vulnerable versions
    version_major=$(echo "$jenkins_version" | cut -d. -f1)
    version_minor=$(echo "$jenkins_version" | cut -d. -f2)

    # Jenkins 2.361+ or 2.346.3+ LTS recommended
    if [[ "$version_major" -eq 2 ]] && [[ "$version_minor" -lt 346 ]]; then
      register_check "Jenkins version support" WARN "version $jenkins_version may have known vulnerabilities"
    fi
  else
    register_check "Jenkins version" WARN "cannot determine version"
  fi
else
  register_check "Jenkins home" FAIL "$JENKINS_HOME not found"
fi

# Check Jenkins service
section "Jenkins Service Status"

service_names=("jenkins" "jenkins.service")
service_found=false
service_active=false

for svc_name in "${service_names[@]}"; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Service $svc_name" PASS "running"
    service_active=true
    service_found=true
    break
  fi
done

if [[ "$service_found" == false ]]; then
  # Check for Jenkins process
  if pgrep -f "jenkins.war" >/dev/null 2>&1; then
    register_check "Jenkins process" PASS "running"
    service_active=true
  else
    register_check "Jenkins service" WARN "not running"
  fi
fi

if svc_is_enabled "jenkins" 2>/dev/null; then
  register_check "Enabled at boot" PASS "yes"
elif [[ "$service_active" == true ]]; then
  register_check "Enabled at boot" WARN "service running but not enabled"
fi

# Jenkins Configuration Security
section "Jenkins Configuration Security"

jenkins_config=$(get_jenkins_config)
if [[ -n "$jenkins_config" ]]; then
  register_check "config.xml" PASS "found"

  # Check security realm (authentication)
  if has_xml_tag "$jenkins_config" "securityRealm"; then
    register_check "Security realm" PASS "configured"

    # Check for specific authentication methods
    if echo "$jenkins_config" | grep -q "HudsonPrivateSecurityRealm"; then
      register_check "Authentication" PASS "Jenkins own user database"
    elif echo "$jenkins_config" | grep -q "LDAPSecurityRealm"; then
      register_check "Authentication" PASS "LDAP integration"
    elif echo "$jenkins_config" | grep -q "github-oauth"; then
      register_check "Authentication" PASS "GitHub OAuth"
    else
      register_check "Authentication" WARN "custom authentication method"
    fi
  else
    register_check "Security realm" FAIL "NOT configured - anyone can access Jenkins"
  fi

  # Check authorization strategy
  if has_xml_tag "$jenkins_config" "authorizationStrategy"; then
    auth_strategy=$(echo "$jenkins_config" | grep -oP '<authorizationStrategy class="\K[^"]+' | head -n1)

    if [[ "$auth_strategy" =~ "FullControlOnceLoggedInAuthorizationStrategy" ]]; then
      register_check "Authorization" WARN "full control once logged in - all users are admins"
    elif [[ "$auth_strategy" =~ "ProjectMatrixAuthorizationStrategy" ]] || [[ "$auth_strategy" =~ "GlobalMatrixAuthorizationStrategy" ]]; then
      register_check "Authorization" PASS "matrix-based authorization (recommended)"
    elif [[ "$auth_strategy" =~ "RoleBasedAuthorizationStrategy" ]]; then
      register_check "Authorization" PASS "role-based authorization"
    else
      register_check "Authorization" WARN "authorization strategy: $auth_strategy"
    fi
  else
    register_check "Authorization" FAIL "NOT configured - no access control"
  fi

  # Check if anonymous users have permissions
  if echo "$jenkins_config" | grep -q '<permission>hudson.model.Hudson.Read:anonymous</permission>'; then
    register_check "Anonymous access" FAIL "anonymous users can read - security risk"
  else
    register_check "Anonymous access" PASS "anonymous access properly restricted"
  fi

  # Check CSRF protection
  if has_xml_tag "$jenkins_config" "crumbIssuer"; then
    register_check "CSRF protection" PASS "enabled"
  else
    register_check "CSRF protection" FAIL "disabled - CSRF attacks possible"
  fi

  # Check agent-to-master security
  if has_xml_tag "$jenkins_config" "remotingSecurity"; then
    enable_flag=$(echo "$jenkins_config" | grep -oP '<remotingSecurity>.*?<enabled>\K[^<]+' 2>/dev/null)
    if [[ "$enable_flag" == "true" ]]; then
      register_check "Agent-to-master security" PASS "enabled"
    else
      register_check "Agent-to-master security" FAIL "disabled - agents have full access to master"
    fi
  else
    register_check "Agent-to-master security" WARN "not explicitly configured"
  fi

  # Check markup formatter (XSS protection)
  if echo "$jenkins_config" | grep -q "RawHtmlMarkupFormatter"; then
    register_check "Markup formatter" FAIL "Raw HTML enabled - XSS vulnerability"
  elif echo "$jenkins_config" | grep -q "SafeHtmlMarkupFormatter\|PlainTextMarkupFormatter"; then
    register_check "Markup formatter" PASS "safe markup formatter"
  else
    register_check "Markup formatter" WARN "markup formatter not explicitly set"
  fi
else
  register_check "config.xml" FAIL "not found at $JENKINS_HOME/config.xml"
fi

# File Permissions
section "File Permissions"

if [[ -d "$JENKINS_HOME" ]]; then
  # Check Jenkins home ownership
  jenkins_owner=$(stat -c "%U" "$JENKINS_HOME" 2>/dev/null || stat -f "%Su" "$JENKINS_HOME" 2>/dev/null || echo "unknown")
  if [[ "$jenkins_owner" == "jenkins" ]]; then
    register_check "Jenkins home owner" PASS "$jenkins_owner"
  else
    register_check "Jenkins home owner" WARN "$jenkins_owner (expected 'jenkins')"
  fi

  # Check config.xml permissions
  if [[ -f "$JENKINS_HOME/config.xml" ]]; then
    config_perms=$(stat -c "%a" "$JENKINS_HOME/config.xml" 2>/dev/null || stat -f "%Lp" "$JENKINS_HOME/config.xml" 2>/dev/null || echo "unknown")
    if [[ "$config_perms" == "600" ]] || [[ "$config_perms" == "640" ]]; then
      register_check "config.xml permissions" PASS "$config_perms"
    else
      register_check "config.xml permissions" WARN "$config_perms (should be 600 or 640)"
    fi
  fi

  # Check secrets directory
  if [[ -d "$JENKINS_HOME/secrets" ]]; then
    secrets_perms=$(stat -c "%a" "$JENKINS_HOME/secrets" 2>/dev/null || stat -f "%Lp" "$JENKINS_HOME/secrets" 2>/dev/null || echo "unknown")
    if [[ "$secrets_perms" == "700" ]]; then
      register_check "secrets/ permissions" PASS "$secrets_perms"
    else
      register_check "secrets/ permissions" FAIL "$secrets_perms (should be 700 - contains master.key)"
    fi
  fi
fi

# Plugin Security
section "Plugin Security"

plugins=$(get_jenkins_plugins)
if [[ -n "$plugins" ]]; then
  plugin_count=$(echo "$plugins" | wc -l)
  register_check "Installed plugins" PASS "$plugin_count plugins"

  # Check for critical security plugins
  security_plugins=(
    "credentials"
    "credentials-binding"
    "plain-credentials"
    "ssh-credentials"
    "script-security"
    "matrix-auth"
    "role-strategy"
  )

  for plugin in "${security_plugins[@]}"; do
    if echo "$plugins" | grep -q "^${plugin}$"; then
      register_check "Plugin: $plugin" PASS "installed"
    else
      if [[ "$plugin" == "credentials" ]]; then
        register_check "Plugin: $plugin" FAIL "NOT installed - credentials management missing"
      elif [[ "$plugin" == "script-security" ]]; then
        register_check "Plugin: $plugin" FAIL "NOT installed - script approval missing"
      fi
    fi
  done

  # Warn about deprecated/dangerous plugins
  dangerous_plugins=(
    "script"
    "groovy"
    "build-pipeline-plugin"
  )

  for plugin in "${dangerous_plugins[@]}"; do
    if echo "$plugins" | grep -q "^${plugin}$"; then
      register_check "Dangerous plugin: $plugin" WARN "installed - has known security issues"
    fi
  done

  # Check for plugin updates
  if [[ -f "$JENKINS_HOME/updates/default.json" ]]; then
    register_check "Plugin updates" PASS "update center configured"
  else
    register_check "Plugin updates" WARN "update center not configured - cannot check for updates"
  fi
else
  register_check "Installed plugins" WARN "cannot enumerate plugins"
fi

# Credentials Security
section "Credentials Security"

if [[ -d "$JENKINS_HOME/credentials.xml" ]] || [[ -f "$JENKINS_HOME/credentials.xml" ]]; then
  register_check "Credentials storage" PASS "credentials.xml exists"

  # Check if credentials plugin is installed
  if echo "$plugins" | grep -q "^credentials$"; then
    register_check "Credentials plugin" PASS "installed"
  else
    register_check "Credentials plugin" FAIL "NOT installed - credentials not encrypted"
  fi
else
  register_check "Credentials storage" SKIP "no credentials.xml found"
fi

# Check for plaintext credentials in jobs
if [[ -d "$JENKINS_HOME/jobs" ]]; then
  job_count=$(find "$JENKINS_HOME/jobs" -maxdepth 1 -type d 2>/dev/null | wc -l)

  if [[ $job_count -gt 1 ]]; then
    register_check "Job configurations" PASS "$((job_count - 1)) jobs found"

    # Sample check: look for password in job configs (limit to first 10 jobs)
    # Collect job names with plaintext secrets (avoid subshell variable loss)
    plaintext_jobs=$(find "$JENKINS_HOME/jobs" -maxdepth 2 -name "config.xml" 2>/dev/null | head -n10 | while read -r job_config; do
      if grep -qiE "(password|secret|token).*<.*>.*</" "$job_config" 2>/dev/null; then
        if ! grep -q "credentialsId" "$job_config" 2>/dev/null; then
          basename "$(dirname "$job_config")"
        fi
      fi
    done)

    if [[ -n "$plaintext_jobs" ]]; then
      while IFS= read -r job_name; do
        register_check "Plaintext secrets: $job_name" FAIL "contains plaintext credentials"
      done <<< "$plaintext_jobs"
    else
      register_check "Plaintext secrets in jobs" PASS "no obvious plaintext credentials in sampled jobs"
    fi
  fi
fi

# Script Security
section "Script Security"

# Check for script approval
if [[ -f "$JENKINS_HOME/scriptApproval.xml" ]]; then
  register_check "Script approval" PASS "scriptApproval.xml exists"

  # Check for approved scripts
  approved_count=$(grep -c "<string>" "$JENKINS_HOME/scriptApproval.xml" 2>/dev/null || echo "0")
  if [[ "$approved_count" -gt 0 ]]; then
    register_check "Approved scripts" PASS "$approved_count approved signatures"
  fi
else
  register_check "Script approval" WARN "scriptApproval.xml not found - may not have script-security plugin"
fi

# Check for Groovy sandbox
if echo "$jenkins_config" | grep -q "scriptSecurityPlugin"; then
  register_check "Script security plugin" PASS "configured"
else
  register_check "Script security plugin" WARN "not explicitly configured"
fi

# Agent Security
section "Agent Security"

# Check agents directory
if [[ -d "$JENKINS_HOME/nodes" ]]; then
  agent_count=$(find "$JENKINS_HOME/nodes" -maxdepth 1 -type d 2>/dev/null | wc -l)
  if [[ $agent_count -gt 1 ]]; then
    register_check "Jenkins agents" PASS "$((agent_count - 1)) agents configured"

    # Check agent security settings
    find "$JENKINS_HOME/nodes" -maxdepth 2 -name "config.xml" 2>/dev/null | head -n5 | while read -r agent_config; do
      agent_name=$(basename "$(dirname "$agent_config")")

      # Check for SSH-based agents (more secure)
      if grep -q "SSHLauncher" "$agent_config" 2>/dev/null; then
        register_check "Agent: $agent_name" PASS "uses SSH launcher"
      elif grep -q "JNLPLauncher" "$agent_config" 2>/dev/null; then
        register_check "Agent: $agent_name" WARN "uses JNLP (consider SSH)"
      fi
    done
  fi
else
  register_check "Jenkins agents" SKIP "no agents configured"
fi

# Check JNLP port configuration
if [[ -f "$JENKINS_HOME/config.xml" ]]; then
  jnlp_port=$(grep -oP '<slaveAgentPort>\K[^<]+' "$JENKINS_HOME/config.xml" 2>/dev/null || echo "")
  if [[ "$jnlp_port" == "-1" ]] || [[ "$jnlp_port" == "0" ]]; then
    register_check "JNLP port" PASS "disabled (more secure)"
  elif [[ -n "$jnlp_port" ]]; then
    register_check "JNLP port" WARN "port $jnlp_port enabled - ensure firewalled"
  fi
fi

# Build Security
section "Build Security"

# Check for build isolation
if echo "$jenkins_config" | grep -q "NodePropertyImpl"; then
  register_check "Build isolation" PASS "node properties configured"
else
  register_check "Build isolation" WARN "no explicit build isolation configured"
fi

# Check for artifact archiving permissions
if [[ -d "$JENKINS_HOME/jobs" ]]; then
  # Sample check for world-readable artifacts
  find "$JENKINS_HOME/jobs" -type d -name "archive" 2>/dev/null | head -n5 | while read -r archive_dir; do
    perms=$(stat -c "%a" "$archive_dir" 2>/dev/null || stat -f "%Lp" "$archive_dir" 2>/dev/null || echo "")
    if [[ -n "$perms" ]] && [[ "${perms:2:1}" -gt 0 ]]; then
      job_name=$(basename "$(dirname "$(dirname "$archive_dir")")")
      register_check "Archive perms: $job_name" WARN "$perms - world-readable artifacts"
    fi
  done
fi

# Network Security
section "Network Security"

# Check if Jenkins is listening on all interfaces
if command -v ss >/dev/null 2>&1; then
  jenkins_listen=$(ss -ltn 2>/dev/null | grep ":8080" || echo "")
elif command -v netstat >/dev/null 2>&1; then
  jenkins_listen=$(netstat -ltn 2>/dev/null | grep ":8080" || echo "")
fi

if [[ -n "$jenkins_listen" ]]; then
  if echo "$jenkins_listen" | grep -qE "(0\.0\.0\.0:8080|\*:8080)"; then
    register_check "Jenkins binding" WARN "listening on all interfaces (0.0.0.0:8080) - use reverse proxy"
  else
    bind_addr=$(echo "$jenkins_listen" | awk '{print $4}' | cut -d: -f1)
    register_check "Jenkins binding" PASS "bound to $bind_addr"
  fi
fi

# Check for HTTPS configuration
if [[ -f "/etc/default/jenkins" ]]; then
  if grep -q "JENKINS_ARGS.*--httpsPort" /etc/default/jenkins 2>/dev/null; then
    register_check "HTTPS" PASS "HTTPS port configured"
  else
    register_check "HTTPS" WARN "no HTTPS configuration - use reverse proxy (Nginx/Apache) with SSL"
  fi
elif [[ -f "/etc/sysconfig/jenkins" ]]; then
  if grep -q "JENKINS_HTTPS_PORT" /etc/sysconfig/jenkins 2>/dev/null; then
    register_check "HTTPS" PASS "HTTPS port configured"
  else
    register_check "HTTPS" WARN "no HTTPS configuration - use reverse proxy with SSL"
  fi
fi

# Backup & Disaster Recovery
section "Backup & Disaster Recovery"

# Check for backup plugins
if echo "$plugins" | grep -qE "(backup|thinBackup|periodic-backup)"; then
  register_check "Backup plugin" PASS "backup plugin installed"
else
  register_check "Backup plugin" WARN "no backup plugin detected"
fi

# Check for recent backups (if using filesystem backups)
backup_dirs=("$JENKINS_HOME/backup" "$JENKINS_HOME/backups" "/var/backups/jenkins")
backup_found=false

for backup_dir in "${backup_dirs[@]}"; do
  if [[ -d "$backup_dir" ]]; then
    recent_backup=$(find "$backup_dir" -type f -mtime -7 2>/dev/null -print -quit)
    if [[ -n "$recent_backup" ]]; then
      register_check "Recent backups" PASS "backup found in $backup_dir (< 7 days)"
      backup_found=true
      break
    fi
  fi
done

if ! $backup_found; then
  register_check "Recent backups" WARN "no recent backups found in standard locations"
fi

# Logging & Monitoring
section "Logging & Monitoring"

# Check for audit trail plugin
if echo "$plugins" | grep -q "audit-trail"; then
  register_check "Audit trail plugin" PASS "installed"

  # Check if audit trail is configured
  if [[ -f "$JENKINS_HOME/audit-trail.log" ]]; then
    register_check "Audit logging" PASS "audit-trail.log exists"
  else
    register_check "Audit logging" WARN "audit-trail plugin installed but no log file found"
  fi
else
  register_check "Audit trail plugin" WARN "NOT installed - no audit logging"
fi

# Check Jenkins logs
if [[ -f "/var/log/jenkins/jenkins.log" ]]; then
  register_check "Jenkins logs" PASS "/var/log/jenkins/jenkins.log"
elif [[ -f "$JENKINS_HOME/jenkins.log" ]]; then
  register_check "Jenkins logs" PASS "$JENKINS_HOME/jenkins.log"
else
  register_check "Jenkins logs" WARN "cannot find Jenkins log file"
fi

# Check for monitoring plugins
monitoring_plugins=("metrics" "prometheus" "monitoring")
for plugin in "${monitoring_plugins[@]}"; do
  if echo "$plugins" | grep -q "^${plugin}$"; then
    register_check "Monitoring: $plugin" PASS "installed"
  fi
done

# Jenkins Package
section "Jenkins Package"
if pkg_installed "jenkins"; then
  register_check "Jenkins package" PASS "installed via package manager"
else
  register_check "Jenkins package" SKIP "not installed via standard package manager"
fi

# Print summary
print_summary
exit "$EXIT_CODE"
