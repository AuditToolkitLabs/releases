# Configuration Management Security Audits

This directory contains security audits for infrastructure configuration management tools.

## Audits

### ansible-security-audit.sh

Comprehensive Ansible security audit covering:

- **Ansible Installation**
  - Version and EOL status
  - Installation method (package/pip)
  - Control node configuration

- **Vault Encryption**
  - Vault password file security
  - Encrypted variable files (vault.yml, secrets.yml)
  - `ansible.cfg` vault settings
  - Vault ID usage
  - **Critical**: Unencrypted sensitive data detection

- **SSH Key Management**
  - SSH private key permissions (must be 600)
  - SSH key locations (~/.ssh/, /etc/ansible/)
  - Known_hosts configuration
  - SSH agent usage

- **Playbook Security**
  - Shell module with user input (command injection risk)
  - `no_log` for sensitive tasks
  - Hardcoded passwords/secrets
  - `become` (sudo) usage without password
  - Unsafe variable interpolation

- **Inventory Security**
  - Inventory file permissions (should be 640)
  - Credentials in inventory (anti-pattern)
  - Dynamic inventory script security
  - Host variable encryption

- **Privilege Escalation**
  - `become_user` configuration
  - `become_method` (sudo, su, etc.)
  - NOPASSWD sudo usage
  - Privilege escalation logging

- **Ansible Tower/AWX**
  - Tower installation detection
  - Credential management
  - RBAC configuration
  - Job isolation
  - Audit logging

- **Galaxy Roles**
  - Role signature verification
  - Role source verification
  - Requirements.yml security
  - Community role vetting

- **Facts Caching**
  - Cache backend security (Redis, memcached)
  - Cache encryption
  - Cache permissions

- **Connection Plugins**
  - SSH connection security
  - WinRM security (if Windows targets)
  - Connection timeout settings

## Usage

```bash
# Run Ansible security audit
bash audits/linux/automation/config-mgmt/ansible-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain automation --match ansible
```

## Requirements

- Ansible 2.9+ (2.13+ recommended)
- Control node with Ansible installed
- Access to ansible.cfg and playbooks

## Remediation

### Ansible Vault

Encrypt sensitive data:

```bash
# Create encrypted file
ansible-vault create secrets.yml

# Encrypt existing file
ansible-vault encrypt database.yml

# Edit encrypted file
ansible-vault edit secrets.yml

# Run playbook with vault password
ansible-playbook site.yml --ask-vault-pass

# Use vault password file
ansible-playbook site.yml --vault-password-file ~/.vault_pass
```

Secure vault password file:

```bash
chmod 600 ~/.vault_pass
```

### SSH Key Security

```bash
# Secure private keys
chmod 600 ~/.ssh/id_rsa
chmod 600 ~/.ssh/ansible_key

# Secure public keys
chmod 644 ~/.ssh/id_rsa.pub

# Secure .ssh directory
chmod 700 ~/.ssh/
```

### Playbook Security

Use `no_log` for sensitive tasks:

```yaml
- name: Create database user
  mysql_user:
    name: "{{ db_user }}"
    password: "{{ db_password }}"
    priv: "*.*:ALL"
  no_log: true
```

Avoid shell module with user input:

```yaml
# ❌ BAD: Command injection risk
- name: Execute user command
  shell: "{{ user_input }}"

# ✅ GOOD: Use specific module
- name: Install package
  apt:
    name: "{{ package_name }}"
    state: present
```

### Inventory Security

```bash
# Secure inventory files
chmod 640 inventory/production

# Use encrypted group_vars
ansible-vault encrypt group_vars/production/vault.yml
```

Store credentials in vault:

```yaml
# group_vars/production/vault.yml (encrypted)
vault_db_password: "supersecret"

# group_vars/production/vars.yml (plaintext)
db_password: "{{ vault_db_password }}"
```

### Privilege Escalation

Configure in `ansible.cfg`:

```ini
[privilege_escalation]
become=True
become_method=sudo
become_user=root
become_ask_pass=True
```

Require sudo password in playbook:

```yaml
- name: Secure task
  apt:
    name: nginx
    state: present
  become: yes
  become_user: root
  # No 'become_flags: NOPASSWD'
```

### Ansible Tower/AWX

- Enable RBAC for all users
- Use credential types (Machine, SCM, Vault)
- Enable audit logging
- Configure job isolation (containers, bubblewrap)
- Restrict webhook access

### Galaxy Role Verification

```bash
# Check role before using
ansible-galaxy info geerlingguy.nginx

# Install from verified source
ansible-galaxy install geerlingguy.nginx

# Use requirements.yml with version pinning
---
roles:
  - name: geerlingguy.nginx
    version: 3.1.4
```

### ansible.cfg Security

```ini
[defaults]
# Disable host key checking only if necessary
host_key_checking = True

# Use encrypted vault
vault_password_file = ~/.vault_pass

# Enable logging
log_path = /var/log/ansible.log

# Restrict SSH
remote_user = ansible
private_key_file = ~/.ssh/ansible_key

[privilege_escalation]
become = True
become_method = sudo
become_ask_pass = True
```

## Security Best Practices

1. **Never commit secrets**: Use Ansible Vault for all sensitive data
2. **Secure SSH keys**: 600 permissions, passphrase-protected
3. **Use `no_log`**: For all tasks handling credentials
4. **Avoid shell module**: Use specific modules (apt, yum, copy, etc.)
5. **Inventory encryption**: Encrypt group_vars and host_vars
6. **Require become password**: Never use NOPASSWD sudo
7. **Pin Galaxy roles**: Specify versions in requirements.yml
8. **Enable audit logging**: Log all playbook executions
9. **Use dynamic inventory**: Avoid hardcoded credentials
10. **Regular updates**: Keep Ansible and roles updated

## References

- [Ansible Security Best Practices](https://docs.ansible.com/ansible/latest/user_guide/playbooks_best_practices.html#best-practices-for-variables-and-vaults)
- [Ansible Vault Documentation](https://docs.ansible.com/ansible/latest/user_guide/vault.html)
- [Ansible Tower Security](https://docs.ansible.com/ansible-tower/latest/html/administration/security.html)
- [Common Ansible Vulnerabilities](https://www.ansible.com/blog/ansible-security-automation-with-ansible-and-ansible-tower)
