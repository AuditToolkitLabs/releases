#!/usr/bin/env bash
# Ansible Security Audit
# Checks Ansible configuration, vault encryption, playbook security, and inventory management

# @elevation: partial
# @elevation-reason: System-wide Ansible config and vault file access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"

# === Configuration ===
ANSIBLE_PATHS=(
  "/etc/ansible"
  "$HOME/.ansible"
  "$(pwd)"
)

# === Performance: Cache variables ===
ANSIBLE_VERSION=""
ANSIBLE_CONFIG=""
INVENTORY_FILES=""
PLAYBOOK_DIR=""
VAULT_FILES=""

# === Helper Functions ===

# Get Ansible version
get_ansible_version() {
  if [[ -n "$ANSIBLE_VERSION" ]]; then
    echo "$ANSIBLE_VERSION"
    return 0
  fi

  if command -v ansible >/dev/null 2>&1; then
    ansible_ver=$(ansible --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    ANSIBLE_VERSION="$ansible_ver"
    echo "$ansible_ver"
  else
    echo "not_installed"
  fi
}

# Find Ansible config file
find_ansible_config() {
  if [[ -n "$ANSIBLE_CONFIG" ]]; then
    echo "$ANSIBLE_CONFIG"
    return 0
  fi

  # Check ANSIBLE_CONFIG env var
  if [[ -n "${ANSIBLE_CONFIG:-}" && -f "$ANSIBLE_CONFIG" ]]; then
    echo "$ANSIBLE_CONFIG"
    return 0
  fi

  # Check common locations
  if [[ -f "$(pwd)/ansible.cfg" ]]; then
    ANSIBLE_CONFIG="$(pwd)/ansible.cfg"
    echo "$ANSIBLE_CONFIG"
    return 0
  elif [[ -f "$HOME/.ansible.cfg" ]]; then
    ANSIBLE_CONFIG="$HOME/.ansible.cfg"
    echo "$ANSIBLE_CONFIG"
    return 0
  elif [[ -f "/etc/ansible/ansible.cfg" ]]; then
    ANSIBLE_CONFIG="/etc/ansible/ansible.cfg"
    echo "$ANSIBLE_CONFIG"
    return 0
  fi

  echo ""
}

# Find inventory files
find_inventory_files() {
  if [[ -n "$INVENTORY_FILES" ]]; then
    echo "$INVENTORY_FILES"
    return 0
  fi

  inventories=""

  # Check default locations
  if [[ -f "/etc/ansible/hosts" ]]; then
    inventories="/etc/ansible/hosts"
  fi

  # Check current directory
  for inv in hosts inventory inventory.ini inventory.yml inventory.yaml; do
    if [[ -f "$(pwd)/$inv" ]]; then
      inventories="$inventories $(pwd)/$inv"
    fi
  done

 # Check inventory directory
  if [[ -d "$(pwd)/inventory" ]]; then
    inv_files=$(find "$(pwd)/inventory" -type f \( -name "*.ini" -o -name "*.yml" -o -name "*.yaml" -o -name "hosts" \) 2>/dev/null || echo "")
    inventories="$inventories $inv_files"
  fi

  INVENTORY_FILES=$(echo "$inventories" | tr -s ' ')
  echo "$INVENTORY_FILES"
}

# Find playbook directory
find_playbook_dir() {
  if [[ -n "$PLAYBOOK_DIR" ]]; then
    echo "$PLAYBOOK_DIR"
    return 0
  fi

  # Check current directory for playbooks
  if ls "$(pwd)"/*.yml >/dev/null 2>&1 || ls "$(pwd)"/*.yaml >/dev/null 2>&1; then
    PLAYBOOK_DIR="$(pwd)"
    echo "$PLAYBOOK_DIR"
    return 0
  fi

  # Check common playbook directories
  for dir in /etc/ansible /opt/ansible "$HOME/ansible"; do
    if [[ -d "$dir" ]] && ls "$dir"/*.yml >/dev/null 2>&1 2>/dev/null; then
      PLAYBOOK_DIR="$dir"
      echo "$dir"
      return 0
    fi
  done

  echo ""
}

# === MAIN AUDIT ===

section "Ansible Detection"

ansible_ver=$(get_ansible_version)
if [[ "$ansible_ver" == "not_installed" ]]; then
  register_check "Ansible Installed" SKIP "Ansible not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Ansible Version" PASS "Ansible $ansible_ver"

# Check for old Ansible versions
major=$(echo "$ansible_ver" | cut -d. -f1)
minor=$(echo "$ansible_ver" | cut -d. -f2)

if [[ "$major" -lt 2 ]]; then
  register_check "Ansible EOL" FAIL "Ansible $major.x is End-of-Life (upgrade to Ansible 2.9+)"
elif [[ "$major" -eq 2 && "$minor" -lt 9 ]]; then
  register_check "Ansible EOL" WARN "Ansible $ansible_ver is outdated (upgrade to 2.9+ or Ansible Core 2.12+)"
else
  register_check "Ansible EOL" PASS "Ansible version current"
fi

# === Ansible Configuration ===
section "Ansible Configuration"

ansible_config=$(find_ansible_config)
if [[ -n "$ansible_config" ]]; then
  register_check "ansible.cfg" PASS "found at $ansible_config"

  # Check config file permissions
  config_perms=$(stat -c '%a' "$ansible_config" 2>/dev/null || stat -f '%Lp' "$ansible_config" 2>/dev/null || echo "000")
  if [[ "$config_perms" =~ ^[0-7][0-7]4$ ]]; then
    register_check "Config Permissions" PASS "permissions $config_perms"
  else
    register_check "Config Permissions" WARN "permissions $config_perms (should be 644 or more restrictive)"
  fi

  # Check host key checking
  if grep -q "^host_key_checking.*=.*[Ff]alse" "$ansible_config" 2>/dev/null; then
    register_check "Host Key Checking" FAIL "Host key checking disabled (MITM vulnerability)"
  else
    register_check "Host Key Checking" PASS "Host key checking enabled (default or explicit)"
  fi

  # Check SSH args
  if grep -q "ssh_args" "$ansible_config" 2>/dev/null; then
    ssh_args=$(grep "ssh_args" "$ansible_config" | cut -d= -f2 | tr -d ' ')
    if echo "$ssh_args" | grep -q "StrictHostKeyChecking=no"; then
      register_check "SSH Strict Mode" WARN "StrictHostKeyChecking=no in SSH args (weakens security)"
    else
      register_check "SSH Strict Mode" PASS "SSH strict mode not disabled"
    fi
  fi

  # Check privilege escalation defaults
  if grep -q "^become.*=.*[Tt]rue" "$ansible_config" 2>/dev/null; then
    register_check "Default Become" WARN "become=true by default (use task-level become for least privilege)"
  else
    register_check "Default Become" PASS "No default privilege escalation"
  fi

  # Check for become password in config (bad practice)
  if grep -q "^become_pass\|^ansible_become_pass" "$ansible_config" 2>/dev/null; then
    register_check "Become Password" FAIL "become_password in config (use vault or prompt)"
  else
    register_check "Become Password" PASS "No hardcoded become password"
  fi

  # Check logging
  if grep -q "^log_path" "$ansible_config" 2>/dev/null; then
    log_path=$(grep "^log_path" "$ansible_config" | cut -d= -f2 | tr -d ' ')
    register_check "Logging" PASS "log_path: $log_path"

    # Check log file permissions if it exists
    if [[ -f "$log_path" ]]; then
      log_perms=$(stat -c '%a' "$log_path" 2>/dev/null || stat -f '%Lp' "$log_path" 2>/dev/null || echo "000")
      if [[ "$log_perms" =~ ^[0-7]00$ ]]; then
        register_check "Log Permissions" PASS "permissions $log_perms (secure)"
      else
        register_check "Log Permissions" WARN "permissions $log_perms (may expose sensitive data)"
      fi
    fi
  else
    register_check "Logging" WARN "No log_path configured (command history not logged)"
  fi

  # Check vault password file
  if grep -q "^vault_password_file" "$ansible_config" 2>/dev/null; then
    vault_pass_file=$(grep "^vault_password_file" "$ansible_config" | cut -d= -f2 | tr -d ' ')
    register_check "Vault Password File" PASS "vault_password_file: $vault_pass_file"

    # Check vault password file permissions
    if [[ -f "$vault_pass_file" ]]; then
      vault_pass_perms=$(stat -c '%a' "$vault_pass_file" 2>/dev/null || stat -f '%Lp' "$vault_pass_file" 2>/dev/null || echo "000")
      if [[ "$vault_pass_perms" == "600" ]]; then
        register_check "Vault Pass Perms" PASS "permissions $vault_pass_perms (secure)"
      else
        register_check "Vault Pass Perms" FAIL "permissions $vault_pass_perms (must be 600)"
      fi
    else
      register_check "Vault Pass File" WARN "vault_password_file not found at $vault_pass_file"
    fi
  else
    register_check "Vault Password File" PASS "No vault_password_file (prompt for password is secure)"
  fi
else
  register_check "ansible.cfg" WARN "No ansible.cfg found (using defaults)"
fi

# === Ansible Vault Security ===
section "Ansible Vault Encryption"

# Check for ansible-vault command
if command -v ansible-vault >/dev/null 2>&1; then
  register_check "ansible-vault" PASS "ansible-vault command available"
else
  register_check "ansible-vault" WARN "ansible-vault command not found"
fi

# Find vault-encrypted files
playbook_dir=$(find_playbook_dir)
if [[ -n "$playbook_dir" ]]; then
  vault_files=$(grep -r "^\$ANSIBLE_VAULT" "$playbook_dir" -l 2>/dev/null || echo "")
  VAULT_FILES="$vault_files"

  if [[ -n "$vault_files" ]]; then
    vault_count=$(echo "$vault_files" | wc -l)
    register_check "Vault Files" PASS "$vault_count vault-encrypted file(s) found"

    # Check vault file permissions
    for vault_file in $vault_files; do
      vault_perms=$(stat -c '%a' "$vault_file" 2>/dev/null || stat -f '%Lp' "$vault_file" 2>/dev/null || echo "000")
      if [[ "$vault_perms" == "600" || "$vault_perms" == "640" ]]; then
        register_check "Vault File Perms ($(basename "$vault_file"))" PASS "permissions $vault_perms"
      else
        register_check "Vault File Perms ($(basename "$vault_file"))" WARN "permissions $vault_perms"
      fi
    done
  else
    register_check "Vault Files" WARN "No vault-encrypted files found (sensitive data may be plaintext)"
  fi
fi

# === Inventory Security ===
section "Inventory Management"

inventory_files=$(find_inventory_files)
if [[ -n "$inventory_files" ]]; then
  inv_count=$(echo "$inventory_files" | wc -w)
  register_check "Inventory Files" PASS "$inv_count inventory file(s) found"

  for inv_file in $inventory_files; do
    if [[ ! -f "$inv_file" ]]; then
      continue
    fi

    inv_name=$(basename "$inv_file")

    # Check inventory file permissions
    inv_perms=$(stat -c '%a' "$inv_file" 2>/dev/null || stat -f '%Lp' "$inv_file" 2>/dev/null || echo "000")
    if [[ "$inv_perms" =~ ^[0-7][04][04]$ ]]; then
      register_check "Inventory Perms ($inv_name)" PASS "permissions $inv_perms"
    else
      register_check "Inventory Perms ($inv_name)" WARN "permissions $inv_perms (may contain sensitive data)"
    fi

    # Check for plaintext passwords
    if grep -qE "ansible_.*password=|ansible_become_pass=" "$inv_file" 2>/dev/null; then
      register_check "Plaintext Passwords ($inv_name)" FAIL "Plaintext passwords in inventory (use vault)"
    else
      register_check "Plaintext Passwords ($inv_name)" PASS "No obvious plaintext passwords"
    fi

    # Check for private keys in inventory
    if grep -q "ansible_ssh_private_key_file" "$inv_file" 2>/dev/null; then
      key_file=$(grep "ansible_ssh_private_key_file" "$inv_file" | head -n1 | cut -d= -f2 | tr -d ' "')
      if [[ -f "$key_file" ]]; then
        key_perms=$(stat -c '%a' "$key_file" 2>/dev/null || stat -f '%Lp' "$key_file" 2>/dev/null || echo "000")
        if [[ "$key_perms" == "600" ]]; then
          register_check "SSH Key Perms" PASS "permissions $key_perms for $key_file"
        else
          register_check "SSH Key Perms" FAIL "permissions $key_perms for $key_file (must be 600)"
        fi
      fi
    fi

    # Check for default/weak usernames
    if grep -qE "ansible_(user|ssh_user)=(root|admin|ubuntu|centos)" "$inv_file" 2>/dev/null; then
      register_check "Default Users ($inv_name)" WARN "Common default usernames in inventory"
    fi
  done
else
  register_check "Inventory Files" WARN "No inventory files found"
fi

# === Playbook Security ===
section "Playbook Security"

if [[ -n "$playbook_dir" ]]; then
  register_check "Playbook Directory" PASS "$playbook_dir"

  # Find playbooks
  playbooks=$(find "$playbook_dir" -maxdepth 2 -name "*.yml" -o -name "*.yaml" 2>/dev/null || echo "")
  if [[ -n "$playbooks" ]]; then
    playbook_count=$(echo "$playbooks" | wc -l)
    register_check "Playbooks" PASS "$playbook_count playbook file(s) found"

    # Check for dangerous module usage
    dangerous_mods=0
    for pb in $playbooks; do
      # Check for shell/command with variables (injection risk)
      if grep -qE "shell:|command:" "$pb" 2>/dev/null; then
        if grep -qE "shell:.*\{\{.*\}\}|command:.*\{\{.*\}\}" "$pb" 2>/dev/null; then
          dangerous_mods=$((dangerous_mods + 1))
        fi
      fi
    done

    if [[ "$dangerous_mods" -gt 0 ]]; then
      register_check "Shell/Command Safety" WARN "$dangerous_mods playbook(s) with shell/command using variables (injection risk)"
    else
      register_check "Shell/Command Safety" PASS "No obvious shell injection risks"
    fi

    # Check for become usage
    become_count=$(grep -c "become: true" $playbooks 2>/dev/null || echo "0")
    if [[ "$become_count" -gt 0 ]]; then
      register_check "Privilege Escalation" PASS "$become_count task(s) using become (privilege escalation)"
    fi

    # Check for no_log on sensitive tasks
    nolog_count=$(grep -c "no_log: true" $playbooks 2>/dev/null || echo "0")
    if [[ "$nolog_count" -gt 0 ]]; then
      register_check "no_log Usage" PASS "$nolog_count task(s) using no_log (sensitive data protection)"
    else
      register_check "no_log Usage" WARN "No tasks using no_log (sensitive output may be logged)"
    fi

    # Check for hardcoded secrets
    if grep -qE "(password|secret|api_key|token):.*['\"]" $playbooks 2>/dev/null; then
      secret_count=$(grep -cE "(password|secret|api_key|token):.*['\"]" $playbooks 2>/dev/null || echo "0")
      register_check "Hardcoded Secrets" WARN "$secret_count potential hardcoded secret(s) (use vault)"
    else
      register_check "Hardcoded Secrets" PASS "No obvious hardcoded secrets"
    fi

    # Check for loop iteration safety
    if grep -q "with_items:.*lookup.*file\|with_fileglob:" $playbooks 2>/dev/null; then
      register_check "File Iteration" WARN "File iteration detected (ensure inputs are validated)"
    fi
  fi
else
  register_check "Playbooks" SKIP "No playbook directory found"
fi

# === Roles Security ===
section "Ansible Roles"

# Check for roles directory
if [[ -d "$playbook_dir/roles" ]]; then
  role_count=$(ls -1d "$playbook_dir/roles"/*/ 2>/dev/null | wc -l || echo "0")
  if [[ "$role_count" -gt 0 ]]; then
    register_check "Local Roles" PASS "$role_count role(s) in roles/ directory"
  fi
fi

# Check Ansible Galaxy roles
if [[ -d "$HOME/.ansible/roles" ]]; then
  galaxy_roles=$(ls -1 "$HOME/.ansible/roles" 2>/dev/null | wc -l || echo "0")
  if [[ "$galaxy_roles" -gt 0 ]]; then
    register_check "Galaxy Roles" PASS "$galaxy_roles role(s) from Ansible Galaxy"
    register_check "Role Trust" WARN "Review Galaxy roles for security (3rd-party code execution)"
  fi
fi

# Check for requirements.yml (role dependencies)
if [[ -f "$playbook_dir/requirements.yml" ]]; then
  register_check "requirements.yml" PASS "Role dependencies defined"

  # Check for version pinning
  if grep -qE "version:.*latest\|version: \"\"" "$playbook_dir/requirements.yml" 2>/dev/null; then
    register_check "Role Version Pinning" WARN "Some roles not pinned to specific versions"
  else
    register_check "Role Version Pinning" PASS "Roles appear to be version-pinned"
  fi
fi

# === SSH Key Management ===
section "SSH Key Security"

# Check for common SSH key locations
ssh_keys=$(find "$HOME/.ssh" /etc/ansible /opt/ansible 2>/dev/null -name "id_rsa" -o -name "id_ed25519" -o -name "*.pem" | head -n10 || echo "")

if [[ -n "$ssh_keys" ]]; then
  key_count=$(echo "$ssh_keys" | wc -l)
  register_check "SSH Keys" PASS "$key_count SSH key(s) found"

  # Check key permissions
  for key in $ssh_keys; do
    key_perms=$(stat -c '%a' "$key" 2>/dev/null || stat -f '%Lp' "$key" 2>/dev/null || echo "000")
    key_name=$(basename "$key")

    if [[ "$key_perms" == "600" ]]; then
      register_check "Key Perms ($key_name)" PASS "permissions $key_perms (secure)"
    else
      register_check "Key Perms ($key_name)" FAIL "permissions $key_perms (must be 600)"
    fi
  done
fi

# === Dynamic Inventory Security ===
section "Dynamic Inventory"

# Check for inventory scripts
if [[ -d "$playbook_dir/inventory" ]]; then
  inv_scripts=$(find "$playbook_dir/inventory" -type f -executable 2>/dev/null || echo "")
  if [[ -n "$inv_scripts" ]]; then
    script_count=$(echo "$inv_scripts" | wc -l)
    register_check "Dynamic Inventory" PASS "$script_count executable inventory script(s)"
    register_check "Script Security" WARN "Review inventory scripts for credential exposure (API tokens, etc.)"
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
