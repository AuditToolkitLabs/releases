#!/usr/bin/env bash
# chef-audit.sh — Chef Client Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.2 (System Maintenance)
# - NIST SP 800-53: CM-2, CM-3, CM-6 (Configuration Management)
# - ISO 27001: A.12.5 (Control of Operational Software)
# - PCI DSS: 2.2 (Configuration Standards)
#
# Checks:
# - Chef client installation and service
# - Client configuration and credentials
# - Server connectivity
# - Last converge status
# - Security configuration

# @elevation: partial
# @elevation-reason: Service status and /etc/chef config access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Chef Installation"

# Check if chef-client is installed
chef_cmd=""
if command -v chef-client >/dev/null 2>&1; then
  chef_cmd="chef-client"
elif [[ -x "/opt/chef/bin/chef-client" ]]; then
  chef_cmd="/opt/chef/bin/chef-client"
elif [[ -x "/opt/cinc/bin/cinc-client" ]]; then
  chef_cmd="/opt/cinc/bin/cinc-client"
fi

if [[ -z "$chef_cmd" ]]; then
  register_check "Chef installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Chef installed" PASS "found"

# Get version
chef_version=$($chef_cmd --version 2>/dev/null | head -n1 || echo "unknown")
register_check "Chef version" PASS "$chef_version"

# Check if Cinc (community fork) or Chef
if echo "$chef_cmd" | grep -q "cinc"; then
  register_check "Chef edition" PASS "Cinc (community)"
else
  register_check "Chef edition" PASS "Chef Infra Client"
fi

section "Chef Service Status"

# Check chef-client service/timer
if is_systemd; then
  # Check for timer (preferred method)
  if systemctl list-timers --all 2>/dev/null | grep -q "chef-client"; then
    register_check "Chef timer" PASS "active"
  else
    register_check "Chef timer" WARN "not found"
  fi

  # Check for service (legacy method)
  if systemctl is-active chef-client >/dev/null 2>&1; then
    register_check "Chef service" PASS "running"
  else
    register_check "Chef service" WARN "not running (check timer)"
  fi
elif is_openrc; then
  if rc-service chef-client status >/dev/null 2>&1; then
    register_check "Chef service" PASS "running"
  else
    register_check "Chef service" WARN "not running"
  fi
else
  if pgrep -f "chef-client" >/dev/null 2>&1; then
    register_check "Chef client" PASS "running"
  else
    register_check "Chef client" WARN "not running"
  fi
fi

# Check cron-based runs
if crontab -l 2>/dev/null | grep -q "chef-client"; then
  register_check "Chef cron job" PASS "configured"
fi

section "Chef Configuration"

# Check client.rb
chef_conf=""
if [[ -f "/etc/chef/client.rb" ]]; then
  chef_conf="/etc/chef/client.rb"
elif [[ -f "/etc/cinc/client.rb" ]]; then
  chef_conf="/etc/cinc/client.rb"
fi

if [[ -n "$chef_conf" && -f "$chef_conf" ]]; then
  register_check "Client config" PASS "$chef_conf"

  # Check file permissions
  perms=$(stat -c "%a" "$chef_conf" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "644" ]] || [[ "$perms" == "640" ]] || [[ "$perms" == "600" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi

  # Check chef_server_url
  server_url=$(grep -E "^chef_server_url" "$chef_conf" 2>/dev/null | awk -F'"' '{print $2}' | head -n1 || echo "")
  if [[ -n "$server_url" ]]; then
    register_check "Chef server URL" PASS "configured"

    # Check HTTPS
    if echo "$server_url" | grep -q "^https://"; then
      register_check "Server uses HTTPS" PASS "yes"
    else
      register_check "Server uses HTTPS" FAIL "no"
    fi
  else
    register_check "Chef server URL" WARN "not set"
  fi

  # Check node_name
  node_name=$(grep -E "^node_name" "$chef_conf" 2>/dev/null | awk -F'"' '{print $2}' || echo "")
  if [[ -n "$node_name" ]]; then
    register_check "Node name" PASS "$node_name"
  else
    register_check "Node name" WARN "using hostname"
  fi

  # Check ssl_verify_mode
  ssl_verify=$(grep -E "^ssl_verify_mode" "$chef_conf" 2>/dev/null || echo "")
  if echo "$ssl_verify" | grep -q ":verify_peer"; then
    register_check "SSL verification" PASS "verify_peer"
  elif echo "$ssl_verify" | grep -q ":verify_none"; then
    register_check "SSL verification" FAIL "verify_none (insecure)"
  else
    register_check "SSL verification" WARN "default (check setting)"
  fi

  # Check log_level
  log_level=$(grep -E "^log_level" "$chef_conf" 2>/dev/null | awk -F':' '{print $2}' || echo "")
  if [[ -n "$log_level" ]]; then
    register_check "Log level" PASS "$log_level"
  fi

  # Check interval and splay
  interval=$(grep -E "^interval" "$chef_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$interval" ]]; then
    register_check "Run interval" PASS "${interval}s"
  fi

  splay=$(grep -E "^splay" "$chef_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$splay" ]]; then
    register_check "Splay" PASS "${splay}s"
  fi
else
  register_check "Client config" FAIL "not found"
fi

section "Credential Security"

chef_dir="/etc/chef"
[[ -d "/etc/cinc" ]] && chef_dir="/etc/cinc"

# Check client.pem (node private key)
client_pem="$chef_dir/client.pem"
if [[ -f "$client_pem" ]]; then
  register_check "Client key" PASS "present"

  key_perms=$(stat -c "%a" "$client_pem" 2>/dev/null || echo "unknown")
  if [[ "$key_perms" == "600" ]] || [[ "$key_perms" == "640" ]]; then
    register_check "Client key perms" PASS "$key_perms"
  else
    register_check "Client key perms" FAIL "$key_perms (should be 600)"
  fi

  key_owner=$(stat -c "%U" "$client_pem" 2>/dev/null || echo "unknown")
  if [[ "$key_owner" == "root" ]]; then
    register_check "Client key owner" PASS "root"
  else
    register_check "Client key owner" WARN "$key_owner"
  fi
else
  register_check "Client key" WARN "not found (not registered?)"
fi

# Check validation.pem (should be removed after bootstrap)
validation_pem="$chef_dir/validation.pem"
if [[ -f "$validation_pem" ]]; then
  register_check "Validation key" WARN "present (remove after bootstrap)"

  val_perms=$(stat -c "%a" "$validation_pem" 2>/dev/null || echo "unknown")
  if [[ "$val_perms" == "600" ]]; then
    register_check "Validation perms" PASS "$val_perms"
  else
    register_check "Validation perms" FAIL "$val_perms (should be 600)"
  fi
else
  register_check "Validation key" PASS "removed (good)"
fi

# Check encrypted_data_bag_secret
data_bag_secret="$chef_dir/encrypted_data_bag_secret"
if [[ -f "$data_bag_secret" ]]; then
  register_check "Data bag secret" PASS "present"

  secret_perms=$(stat -c "%a" "$data_bag_secret" 2>/dev/null || echo "unknown")
  if [[ "$secret_perms" == "600" ]]; then
    register_check "Secret file perms" PASS "$secret_perms"
  else
    register_check "Secret file perms" FAIL "$secret_perms (should be 600)"
  fi
fi

section "SSL/TLS Configuration"

# Check trusted_certs directory
trusted_certs="$chef_dir/trusted_certs"
if [[ -d "$trusted_certs" ]]; then
  cert_count=$(find "$trusted_certs" -name "*.crt" -o -name "*.pem" 2>/dev/null | wc -l)
  register_check "Trusted certs" PASS "$cert_count certificates"

  # Check directory permissions
  cert_perms=$(stat -c "%a" "$trusted_certs" 2>/dev/null || echo "unknown")
  if [[ "$cert_perms" == "755" ]] || [[ "$cert_perms" == "750" ]]; then
    register_check "Trusted certs perms" PASS "$cert_perms"
  else
    register_check "Trusted certs perms" WARN "$cert_perms"
  fi
fi

# SSL verification with knife if available
knife_cmd=""
if command -v knife >/dev/null 2>&1; then
  knife_cmd="knife"
elif [[ -x "/opt/chef/bin/knife" ]]; then
  knife_cmd="/opt/chef/bin/knife"
fi

if [[ -n "$knife_cmd" ]]; then
  if $knife_cmd ssl check 2>/dev/null | grep -q "Successfully"; then
    register_check "SSL check (knife)" PASS "valid"
  else
    register_check "SSL check (knife)" WARN "check failed"
  fi
fi

section "Last Converge Status"

# Check last run report
run_report=""
if [[ -f "/var/chef/cache/last_run_summary.json" ]]; then
  run_report="/var/chef/cache/last_run_summary.json"
elif [[ -f "/var/cinc/cache/last_run_summary.json" ]]; then
  run_report="/var/cinc/cache/last_run_summary.json"
fi

if [[ -n "$run_report" && -f "$run_report" ]]; then
  register_check "Last run report" PASS "exists"

  # Check timestamp
  if command -v jq >/dev/null 2>&1; then
    last_run=$(jq -r '.end_time // empty' "$run_report" 2>/dev/null || echo "")
    if [[ -n "$last_run" ]]; then
      last_run_epoch=$(date -d "$last_run" +%s 2>/dev/null || echo "0")
      now_epoch=$(date +%s)
      mins_ago=$(( (now_epoch - last_run_epoch) / 60 ))

      if [[ "$mins_ago" -lt 120 ]]; then
        register_check "Last converge age" PASS "${mins_ago}m ago"
      elif [[ "$mins_ago" -lt 1440 ]]; then
        register_check "Last converge age" WARN "${mins_ago}m ago"
      else
        days_ago=$((mins_ago / 1440))
        register_check "Last converge age" FAIL "${days_ago}d ago"
      fi
    fi

    # Check status
    status=$(jq -r '.status // empty' "$run_report" 2>/dev/null || echo "")
    if [[ "$status" == "success" ]]; then
      register_check "Last run status" PASS "success"
    elif [[ "$status" == "failure" ]]; then
      register_check "Last run status" FAIL "failure"
    else
      register_check "Last run status" WARN "${status:-unknown}"
    fi

    # Check updated resources
    updated=$(jq -r '.updated_resources // 0' "$run_report" 2>/dev/null || echo "0")
    register_check "Updated resources" PASS "$updated"
  else
    # Fallback without jq
    file_age=$(( ($(date +%s) - $(stat -c %Y "$run_report" 2>/dev/null || echo "0")) / 60 ))
    if [[ "$file_age" -lt 120 ]]; then
      register_check "Last converge" PASS "${file_age}m ago"
    else
      register_check "Last converge" WARN "${file_age}m ago"
    fi
  fi
else
  register_check "Last run report" WARN "not found"
fi

section "Cookbook & Policy Security"

# Check cookbooks cache
cookbook_cache="/var/chef/cache/cookbooks"
[[ -d "/var/cinc/cache/cookbooks" ]] && cookbook_cache="/var/cinc/cache/cookbooks"

if [[ -d "$cookbook_cache" ]]; then
  cookbook_count=$(find "$cookbook_cache" -maxdepth 1 -type d 2>/dev/null | wc -l)
  register_check "Cached cookbooks" PASS "$((cookbook_count - 1)) cookbooks"

  # Check permissions
  cache_perms=$(stat -c "%a" "$cookbook_cache" 2>/dev/null || echo "unknown")
  if [[ "$cache_perms" == "755" ]] || [[ "$cache_perms" == "750" ]]; then
    register_check "Cache permissions" PASS "$cache_perms"
  else
    register_check "Cache permissions" WARN "$cache_perms"
  fi
fi

# Check for policy files (Policyfile mode)
policyfile_lock="/var/chef/cache/Policyfile.lock.json"
if [[ -f "$policyfile_lock" ]]; then
  register_check "Policyfile mode" PASS "enabled"
else
  register_check "Policyfile mode" WARN "not using (roles/environments)"
fi

section "Ohai Configuration"

# Check ohai
ohai_cmd=""
if command -v ohai >/dev/null 2>&1; then
  ohai_cmd="ohai"
elif [[ -x "/opt/chef/bin/ohai" ]]; then
  ohai_cmd="/opt/chef/bin/ohai"
fi

if [[ -n "$ohai_cmd" ]]; then
  ohai_version=$($ohai_cmd --version 2>/dev/null || echo "unknown")
  register_check "Ohai version" PASS "$ohai_version"

  # Check custom plugins
  ohai_plugins="$chef_dir/ohai/plugins"
  if [[ -d "$ohai_plugins" ]]; then
    plugin_count=$(find "$ohai_plugins" -name "*.rb" 2>/dev/null | wc -l)
    register_check "Custom ohai plugins" PASS "$plugin_count plugins"
  fi

  # Check ohai hints
  ohai_hints="$chef_dir/ohai/hints"
  if [[ -d "$ohai_hints" ]]; then
    hint_count=$(find "$ohai_hints" -name "*.json" 2>/dev/null | wc -l)
    register_check "Ohai hints" PASS "$hint_count hints"
  fi
fi

section "Handler Configuration"

# Check for custom handlers
handlers_dir="$chef_dir/handlers"
if [[ -d "$handlers_dir" ]]; then
  handler_count=$(find "$handlers_dir" -name "*.rb" 2>/dev/null | wc -l)
  if [[ "$handler_count" -gt 0 ]]; then
    register_check "Custom handlers" PASS "$handler_count handlers"
  fi
fi

# Check exception handlers in config
if [[ -f "$chef_conf" ]]; then
  if grep -q "exception_handlers" "$chef_conf" 2>/dev/null; then
    register_check "Exception handlers" PASS "configured"
  fi

  if grep -q "report_handlers" "$chef_conf" 2>/dev/null; then
    register_check "Report handlers" PASS "configured"
  fi
fi

section "Security Settings"

# Check if running as root
if [[ -f "$chef_conf" ]]; then
  # Check for solo mode (less secure)
  if grep -qE "^local_mode\s+true" "$chef_conf" 2>/dev/null; then
    register_check "Local/Solo mode" WARN "enabled (no server)"
  fi

  # Check for why-run safeguard
  if grep -qE "^why_run\s+true" "$chef_conf" 2>/dev/null; then
    register_check "Why-run mode" WARN "enabled (dry-run only)"
  fi

  # Check enable_reporting
  if grep -qE "^enable_reporting\s+true" "$chef_conf" 2>/dev/null; then
    register_check "Reporting" PASS "enabled"
  fi
fi

print_summary
exit "$EXIT_CODE"
