#!/usr/bin/env bash
# puppet-audit.sh — Puppet Agent Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.2 (System Maintenance)
# - NIST SP 800-53: CM-2, CM-3, CM-6 (Configuration Management)
# - ISO 27001: A.12.5 (Control of Operational Software)
# - PCI DSS: 2.2 (Configuration Standards)
#
# Checks:
# - Puppet agent installation and service
# - Certificate validation
# - Master/server connectivity
# - Run interval and compliance
# - Security configuration

# @elevation: partial
# @elevation-reason: Service status and /etc/puppetlabs config access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Puppet Installation"

# Check if puppet is installed
puppet_cmd=""
if command -v puppet >/dev/null 2>&1; then
  puppet_cmd="puppet"
elif command -v /opt/puppetlabs/bin/puppet >/dev/null 2>&1; then
  puppet_cmd="/opt/puppetlabs/bin/puppet"
fi

if [[ -z "$puppet_cmd" ]]; then
  register_check "Puppet installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Puppet installed" PASS "found"

# Get version
puppet_version=$($puppet_cmd --version 2>/dev/null || echo "unknown")
register_check "Puppet version" PASS "$puppet_version"

# Check agent type (open source vs enterprise)
if [[ -d "/opt/puppetlabs/puppet" ]]; then
  register_check "Puppet edition" PASS "Puppet Enterprise / AIO"
else
  register_check "Puppet edition" PASS "Open Source"
fi

section "Puppet Service Status"

# Check puppet agent service
if is_systemd; then
  if systemctl is-active puppet >/dev/null 2>&1; then
    register_check "Puppet agent running" PASS "active"
  else
    register_check "Puppet agent running" WARN "not running"
  fi

  if systemctl is-enabled puppet >/dev/null 2>&1; then
    register_check "Puppet agent enabled" PASS "enabled at boot"
  else
    register_check "Puppet agent enabled" WARN "not enabled"
  fi
elif is_openrc; then
  if rc-service puppet status >/dev/null 2>&1; then
    register_check "Puppet agent running" PASS "active"
  else
    register_check "Puppet agent running" WARN "not running"
  fi
else
  if pgrep -f "puppet agent" >/dev/null 2>&1; then
    register_check "Puppet agent running" PASS "active"
  else
    register_check "Puppet agent running" WARN "not running"
  fi
fi

section "Puppet Configuration"

# Check puppet.conf
puppet_conf=""
if [[ -f "/etc/puppetlabs/puppet/puppet.conf" ]]; then
  puppet_conf="/etc/puppetlabs/puppet/puppet.conf"
elif [[ -f "/etc/puppet/puppet.conf" ]]; then
  puppet_conf="/etc/puppet/puppet.conf"
fi

if [[ -n "$puppet_conf" && -f "$puppet_conf" ]]; then
  register_check "Puppet config" PASS "$puppet_conf"

  # Check file permissions
  perms=$(stat -c "%a" "$puppet_conf" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "644" ]] || [[ "$perms" == "640" ]] || [[ "$perms" == "600" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi

  # Check server configuration
  server=$($puppet_cmd config print server 2>/dev/null || echo "")
  if [[ -n "$server" ]] && [[ "$server" != "puppet" ]]; then
    register_check "Puppet server" PASS "$server"
  else
    register_check "Puppet server" WARN "${server:-not set}"
  fi

  # Check environment
  environment=$($puppet_cmd config print environment 2>/dev/null || echo "production")
  register_check "Environment" PASS "$environment"

  # Check run interval
  runinterval=$($puppet_cmd config print runinterval 2>/dev/null || echo "")
  if [[ -n "$runinterval" ]]; then
    interval_mins=$((runinterval / 60))
    if [[ "$interval_mins" -le 60 ]]; then
      register_check "Run interval" PASS "${interval_mins}m"
    else
      register_check "Run interval" WARN "${interval_mins}m (consider <= 60m)"
    fi
  fi
else
  register_check "Puppet config" WARN "not found"
fi

section "SSL/Certificate Security"

# Check SSL directory
ssl_dir=$($puppet_cmd config print ssldir 2>/dev/null || echo "/etc/puppetlabs/puppet/ssl")

if [[ -d "$ssl_dir" ]]; then
  register_check "SSL directory" PASS "$ssl_dir"

  # Check directory permissions
  ssl_perms=$(stat -c "%a" "$ssl_dir" 2>/dev/null || echo "unknown")
  if [[ "$ssl_perms" == "700" ]] || [[ "$ssl_perms" == "750" ]] || [[ "$ssl_perms" == "711" ]]; then
    register_check "SSL dir permissions" PASS "$ssl_perms"
  else
    register_check "SSL dir permissions" WARN "$ssl_perms (should be 700)"
  fi

  # Check for cert
  cert_file="$ssl_dir/certs/$($puppet_cmd config print certname 2>/dev/null).pem"
  if [[ -f "$cert_file" ]]; then
    register_check "Agent certificate" PASS "present"

    # Check cert expiry
    if command -v openssl >/dev/null 2>&1; then
      expiry=$(openssl x509 -in "$cert_file" -noout -enddate 2>/dev/null | cut -d= -f2)
      if [[ -n "$expiry" ]]; then
        expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo "0")
        now_epoch=$(date +%s)
        days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

        if [[ "$days_left" -gt 30 ]]; then
          register_check "Cert expiry" PASS "${days_left} days"
        elif [[ "$days_left" -gt 0 ]]; then
          register_check "Cert expiry" WARN "${days_left} days (renew soon)"
        else
          register_check "Cert expiry" FAIL "expired"
        fi
      fi
    fi
  else
    register_check "Agent certificate" WARN "not found"
  fi

  # Check private key permissions
  key_file="$ssl_dir/private_keys/$($puppet_cmd config print certname 2>/dev/null).pem"
  if [[ -f "$key_file" ]]; then
    key_perms=$(stat -c "%a" "$key_file" 2>/dev/null || echo "unknown")
    if [[ "$key_perms" == "600" ]] || [[ "$key_perms" == "640" ]]; then
      register_check "Private key perms" PASS "$key_perms"
    else
      register_check "Private key perms" FAIL "$key_perms (should be 600)"
    fi
  fi
else
  register_check "SSL directory" WARN "not found"
fi

# SSL verification
if $puppet_cmd ssl verify 2>/dev/null; then
  register_check "SSL verification" PASS "valid"
else
  register_check "SSL verification" WARN "check failed"
fi

section "Last Run Status"

# Check last run summary
last_run_summary=""
if [[ -f "/opt/puppetlabs/puppet/cache/state/last_run_summary.yaml" ]]; then
  last_run_summary="/opt/puppetlabs/puppet/cache/state/last_run_summary.yaml"
elif [[ -f "/var/lib/puppet/state/last_run_summary.yaml" ]]; then
  last_run_summary="/var/lib/puppet/state/last_run_summary.yaml"
fi

if [[ -n "$last_run_summary" && -f "$last_run_summary" ]]; then
  register_check "Last run summary" PASS "exists"

  # Check last run time
  last_run_epoch=$(grep -E "^  last_run:" "$last_run_summary" 2>/dev/null | awk '{print $2}' || echo "0")
  if [[ "$last_run_epoch" -gt 0 ]]; then
    now_epoch=$(date +%s)
    mins_ago=$(( (now_epoch - last_run_epoch) / 60 ))

    if [[ "$mins_ago" -lt 120 ]]; then
      register_check "Last run age" PASS "${mins_ago}m ago"
    elif [[ "$mins_ago" -lt 1440 ]]; then
      register_check "Last run age" WARN "${mins_ago}m ago"
    else
      days_ago=$((mins_ago / 1440))
      register_check "Last run age" FAIL "${days_ago}d ago"
    fi
  fi

  # Check for failures
  failures=$(grep -E "^    failure:" "$last_run_summary" 2>/dev/null | awk '{print $2}' || echo "0")
  if [[ "$failures" == "0" ]]; then
    register_check "Last run failures" PASS "none"
  else
    register_check "Last run failures" FAIL "$failures failures"
  fi

  # Check for changes
  changes=$(grep -E "^    changed:" "$last_run_summary" 2>/dev/null | awk '{print $2}' || echo "0")
  register_check "Last run changes" PASS "$changes resources"

  # Check config retrieval
  config_retrieval=$(grep -E "^    config_retrieval:" "$last_run_summary" 2>/dev/null | awk '{print $2}' || echo "0")
  register_check "Config retrieval" PASS "${config_retrieval}s"
else
  register_check "Last run summary" WARN "not found"
fi

section "Security Settings"

# Check if running as root
running_user=$($puppet_cmd config print user 2>/dev/null || echo "root")
if [[ "$running_user" == "root" ]]; then
  register_check "Running user" PASS "root"
else
  register_check "Running user" WARN "$running_user"
fi

# Check splay
splay=$($puppet_cmd config print splay 2>/dev/null || echo "false")
if [[ "$splay" == "true" ]]; then
  register_check "Splay enabled" PASS "yes (prevents thundering herd)"
else
  register_check "Splay enabled" WARN "no"
fi

# Check usecacheonfailure
usecache=$($puppet_cmd config print usecacheonfailure 2>/dev/null || echo "true")
if [[ "$usecache" == "true" ]]; then
  register_check "Cache on failure" PASS "enabled"
else
  register_check "Cache on failure" WARN "disabled"
fi

# Check daemonize
daemonize=$($puppet_cmd config print daemonize 2>/dev/null || echo "true")
if [[ "$daemonize" == "true" ]]; then
  register_check "Daemon mode" PASS "yes"
else
  register_check "Daemon mode" WARN "no (running via cron?)"
fi

section "Report Configuration"

# Check report settings
report=$($puppet_cmd config print report 2>/dev/null || echo "true")
if [[ "$report" == "true" ]]; then
  register_check "Reporting enabled" PASS "yes"
else
  register_check "Reporting enabled" WARN "no"
fi

# Check reports destination
reports=$($puppet_cmd config print reports 2>/dev/null || echo "")
if [[ -n "$reports" ]]; then
  register_check "Report handlers" PASS "$reports"
fi

section "Module & Code Security"

# Check modulepath
modulepath=$($puppet_cmd config print modulepath 2>/dev/null || echo "")
if [[ -n "$modulepath" ]]; then
  register_check "Module path" PASS "configured"

  # Check module directory permissions
  IFS=':' read -ra modpaths <<< "$modulepath"
  for modpath in "${modpaths[@]}"; do
    if [[ -d "$modpath" ]]; then
      mod_perms=$(stat -c "%a" "$modpath" 2>/dev/null || echo "unknown")
      if [[ "$mod_perms" == "755" ]] || [[ "$mod_perms" == "750" ]]; then
        register_check "Module dir $modpath" PASS "$mod_perms"
      else
        register_check "Module dir $modpath" WARN "$mod_perms"
      fi
    fi
  done
fi

# Check for hiera configuration
hiera_config=$($puppet_cmd config print hiera_config 2>/dev/null || echo "")
if [[ -n "$hiera_config" && -f "$hiera_config" ]]; then
  register_check "Hiera config" PASS "present"

  hiera_perms=$(stat -c "%a" "$hiera_config" 2>/dev/null || echo "unknown")
  if [[ "$hiera_perms" == "644" ]] || [[ "$hiera_perms" == "640" ]]; then
    register_check "Hiera config perms" PASS "$hiera_perms"
  else
    register_check "Hiera config perms" WARN "$hiera_perms"
  fi
else
  register_check "Hiera config" WARN "not found"
fi

# Check for eyaml (encrypted data)
if [[ -d "/etc/puppetlabs/puppet/eyaml" ]] || command -v eyaml >/dev/null 2>&1; then
  register_check "Hiera-eyaml" PASS "available"

  # Check eyaml key permissions
  eyaml_keys="/etc/puppetlabs/puppet/eyaml/keys"
  if [[ -d "$eyaml_keys" ]]; then
    key_perms=$(stat -c "%a" "$eyaml_keys" 2>/dev/null || echo "unknown")
    if [[ "$key_perms" == "700" ]] || [[ "$key_perms" == "750" ]]; then
      register_check "Eyaml keys dir" PASS "$key_perms"
    else
      register_check "Eyaml keys dir" WARN "$key_perms (should be 700)"
    fi
  fi
else
  register_check "Hiera-eyaml" WARN "not installed"
fi

section "Facter & Facts"

# Check facter
if command -v facter >/dev/null 2>&1 || [[ -x "/opt/puppetlabs/bin/facter" ]]; then
  facter_cmd="${puppet_cmd%puppet}facter"
  [[ -x "$facter_cmd" ]] || facter_cmd="facter"

  facter_version=$($facter_cmd --version 2>/dev/null || echo "unknown")
  register_check "Facter version" PASS "$facter_version"

  # Check custom facts directory
  custom_facts="/etc/puppetlabs/facter/facts.d"
  if [[ -d "$custom_facts" ]]; then
    fact_count=$(find "$custom_facts" -type f 2>/dev/null | wc -l)
    register_check "Custom facts" PASS "$fact_count files"

    # Check permissions
    fact_perms=$(stat -c "%a" "$custom_facts" 2>/dev/null || echo "unknown")
    if [[ "$fact_perms" == "755" ]] || [[ "$fact_perms" == "750" ]]; then
      register_check "Facts dir perms" PASS "$fact_perms"
    else
      register_check "Facts dir perms" WARN "$fact_perms"
    fi
  fi
fi

print_summary
exit "$EXIT_CODE"
