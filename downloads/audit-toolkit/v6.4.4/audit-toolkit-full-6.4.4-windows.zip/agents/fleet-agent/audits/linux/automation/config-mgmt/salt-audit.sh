#!/usr/bin/env bash
# salt-audit.sh — SaltStack Minion Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.2 (System Maintenance)
# - NIST SP 800-53: CM-2, CM-3, CM-6 (Configuration Management)
# - ISO 27001: A.12.5 (Control of Operational Software)
# - PCI DSS: 2.2 (Configuration Standards)
#
# Checks:
# - Salt minion installation and service
# - Master connectivity and authentication
# - Key management
# - Pillar security
# - State file security

# @elevation: partial
# @elevation-reason: Service status and /etc/salt config access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Salt Installation"

# Check if salt-minion is installed
salt_minion=""
if command -v salt-minion >/dev/null 2>&1; then
  salt_minion="salt-minion"
elif command -v salt-call >/dev/null 2>&1; then
  salt_minion="salt-call"
fi

if [[ -z "$salt_minion" ]]; then
  register_check "Salt installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Salt installed" PASS "found"

# Get version
salt_version=$(salt-call --version 2>/dev/null | head -n1 || echo "unknown")
register_check "Salt version" PASS "$salt_version"

# Check if master is also installed (indicates salt master)
if command -v salt-master >/dev/null 2>&1; then
  register_check "Salt role" PASS "master + minion"
else
  register_check "Salt role" PASS "minion only"
fi

section "Salt Minion Service"

if is_systemd; then
  if systemctl is-active salt-minion >/dev/null 2>&1; then
    register_check "Minion service" PASS "running"
  else
    register_check "Minion service" WARN "not running"
  fi

  if systemctl is-enabled salt-minion >/dev/null 2>&1; then
    register_check "Minion enabled" PASS "enabled at boot"
  else
    register_check "Minion enabled" WARN "not enabled"
  fi
elif is_openrc; then
  if rc-service salt-minion status >/dev/null 2>&1; then
    register_check "Minion service" PASS "running"
  else
    register_check "Minion service" WARN "not running"
  fi
else
  if pgrep -f "salt-minion" >/dev/null 2>&1; then
    register_check "Minion service" PASS "running"
  else
    register_check "Minion service" WARN "not running"
  fi
fi

section "Minion Configuration"

minion_conf="/etc/salt/minion"
minion_d="/etc/salt/minion.d"

if [[ -f "$minion_conf" ]]; then
  register_check "Minion config" PASS "$minion_conf"

  # Check file permissions
  perms=$(stat -c "%a" "$minion_conf" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "644" ]] || [[ "$perms" == "640" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi

  # Check master configuration
  master=$(grep -E "^master:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$master" ]] && [[ "$master" != "salt" ]]; then
    register_check "Salt master" PASS "$master"
  else
    register_check "Salt master" WARN "${master:-salt (default)}"
  fi

  # Check master_finger (fingerprint verification)
  master_finger=$(grep -E "^master_finger:" "$minion_conf" 2>/dev/null || echo "")
  if [[ -n "$master_finger" ]]; then
    register_check "Master fingerprint" PASS "configured"
  else
    register_check "Master fingerprint" WARN "not set (verify manually)"
  fi

  # Check minion ID
  minion_id=$(grep -E "^id:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$minion_id" ]]; then
    register_check "Minion ID" PASS "$minion_id"
  else
    register_check "Minion ID" WARN "using hostname"
  fi

  # Check grains file security
  grains_file=$(grep -E "^grains_file:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "/etc/salt/grains")
  if [[ -f "$grains_file" ]]; then
    grains_perms=$(stat -c "%a" "$grains_file" 2>/dev/null || echo "unknown")
    if [[ "$grains_perms" == "600" ]] || [[ "$grains_perms" == "640" ]] || [[ "$grains_perms" == "644" ]]; then
      register_check "Grains file perms" PASS "$grains_perms"
    else
      register_check "Grains file perms" WARN "$grains_perms"
    fi
  fi
else
  register_check "Minion config" WARN "not found"
fi

# Check minion.d directory
if [[ -d "$minion_d" ]]; then
  conf_count=$(find "$minion_d" -name "*.conf" -type f 2>/dev/null | wc -l)
  register_check "Minion.d configs" PASS "$conf_count files"

  # Check for insecure settings in conf files
  for conf in "$minion_d"/*.conf; do
    [[ -f "$conf" ]] || continue

    # Check for verify_env disabled
    if grep -qE "^verify_env:\s*False" "$conf" 2>/dev/null; then
      register_check "verify_env" WARN "disabled in $(basename "$conf")"
    fi
  done
fi

section "Key Management"

pki_dir="/etc/salt/pki/minion"
if [[ -d "$pki_dir" ]]; then
  register_check "PKI directory" PASS "$pki_dir"

  # Check directory permissions
  pki_perms=$(stat -c "%a" "$pki_dir" 2>/dev/null || echo "unknown")
  if [[ "$pki_perms" == "700" ]]; then
    register_check "PKI dir permissions" PASS "$pki_perms"
  else
    register_check "PKI dir permissions" WARN "$pki_perms (should be 700)"
  fi

  # Check minion key
  minion_pem="$pki_dir/minion.pem"
  if [[ -f "$minion_pem" ]]; then
    register_check "Minion private key" PASS "present"

    key_perms=$(stat -c "%a" "$minion_pem" 2>/dev/null || echo "unknown")
    if [[ "$key_perms" == "400" ]] || [[ "$key_perms" == "600" ]]; then
      register_check "Private key perms" PASS "$key_perms"
    else
      register_check "Private key perms" FAIL "$key_perms (should be 400)"
    fi
  else
    register_check "Minion private key" WARN "not found"
  fi

  # Check minion public key
  minion_pub="$pki_dir/minion.pub"
  if [[ -f "$minion_pub" ]]; then
    register_check "Minion public key" PASS "present"
  fi

  # Check master public key (indicates accepted connection)
  master_pub="$pki_dir/minion_master.pub"
  if [[ -f "$master_pub" ]]; then
    register_check "Master public key" PASS "accepted"
  else
    register_check "Master public key" WARN "not found (not accepted?)"
  fi
else
  register_check "PKI directory" WARN "not found"
fi

# Get local key fingerprint
if command -v salt-call >/dev/null 2>&1; then
  local_finger=$(salt-call --local key.finger 2>/dev/null | grep -v "local:" | tr -d ' ' || echo "")
  if [[ -n "$local_finger" ]]; then
    register_check "Local key fingerprint" PASS "available"
  fi
fi

section "Master Connectivity"

# Test connection to master
if command -v salt-call >/dev/null 2>&1; then
  if salt-call test.ping --timeout=5 2>/dev/null | grep -q "True"; then
    register_check "Master connection" PASS "connected"
  else
    register_check "Master connection" WARN "not connected"
  fi
fi

section "Transport Security"

# Check transport type
if [[ -f "$minion_conf" ]]; then
  transport=$(grep -E "^transport:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "zeromq")
  register_check "Transport" PASS "${transport:-zeromq}"

  # Check for TCP transport (more secure than ZeroMQ default)
  if [[ "$transport" == "tcp" ]]; then
    register_check "TCP transport" PASS "enabled"

    # Check TLS settings
    tls=$(grep -E "^ssl:" "$minion_conf" 2>/dev/null || echo "")
    if [[ -n "$tls" ]]; then
      register_check "TLS enabled" PASS "yes"
    else
      register_check "TLS enabled" WARN "check ssl: setting"
    fi
  fi
fi

section "Pillar Security"

# Check pillar cache
pillar_cache="/var/cache/salt/minion/pillar"
if [[ -d "$pillar_cache" ]]; then
  cache_perms=$(stat -c "%a" "$pillar_cache" 2>/dev/null || echo "unknown")
  if [[ "$cache_perms" == "700" ]] || [[ "$cache_perms" == "750" ]]; then
    register_check "Pillar cache perms" PASS "$cache_perms"
  else
    register_check "Pillar cache perms" WARN "$cache_perms"
  fi
fi

# Check pillar_opts (exposes master opts to minion - security risk)
if [[ -f "$minion_conf" ]]; then
  pillar_opts=$(grep -E "^pillar_opts:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$pillar_opts" == "True" ]]; then
    register_check "pillar_opts" WARN "enabled (exposes master config)"
  else
    register_check "pillar_opts" PASS "disabled"
  fi

  # Check pillar_safe_render_error
  pillar_safe=$(grep -E "^pillar_safe_render_error:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$pillar_safe" == "True" ]] || [[ -z "$pillar_safe" ]]; then
    register_check "Safe pillar errors" PASS "enabled"
  else
    register_check "Safe pillar errors" WARN "disabled"
  fi
fi

section "State File Security (Master)"

# Only check if this is also a master
if command -v salt-master >/dev/null 2>&1; then
  srv_salt="/srv/salt"
  srv_pillar="/srv/pillar"

  if [[ -d "$srv_salt" ]]; then
    salt_perms=$(stat -c "%a" "$srv_salt" 2>/dev/null || echo "unknown")
    salt_owner=$(stat -c "%U:%G" "$srv_salt" 2>/dev/null || echo "unknown")

    if [[ "$salt_perms" == "755" ]] || [[ "$salt_perms" == "750" ]]; then
      register_check "State files perms" PASS "$salt_perms $salt_owner"
    else
      register_check "State files perms" WARN "$salt_perms"
    fi

    # Count state files
    sls_count=$(find "$srv_salt" -name "*.sls" -type f 2>/dev/null | wc -l)
    register_check "State files" PASS "$sls_count .sls files"
  fi

  if [[ -d "$srv_pillar" ]]; then
    pillar_perms=$(stat -c "%a" "$srv_pillar" 2>/dev/null || echo "unknown")

    if [[ "$pillar_perms" == "700" ]] || [[ "$pillar_perms" == "750" ]]; then
      register_check "Pillar dir perms" PASS "$pillar_perms"
    else
      register_check "Pillar dir perms" WARN "$pillar_perms (should be 750)"
    fi

    # Check for plaintext secrets in pillar
    secrets_found=$(grep -rE "(password|secret|key|token):\s*['\"]?[^{]" "$srv_pillar" 2>/dev/null | wc -l || echo "0")
    if [[ "$secrets_found" -gt 0 ]]; then
      register_check "Plaintext secrets" WARN "$secrets_found potential secrets"
    else
      register_check "Plaintext secrets" PASS "none detected"
    fi
  fi
fi

section "Execution Modules Security"

# Check for dangerous modules disabled
if [[ -f "$minion_conf" ]]; then
  # Check disable_modules
  disabled=$(grep -E "^disable_modules:" "$minion_conf" 2>/dev/null || echo "")
  if [[ -n "$disabled" ]]; then
    register_check "Disabled modules" PASS "configured"
  else
    register_check "Disabled modules" WARN "none disabled"
  fi

  # Check publisher_acl (access control)
  acl=$(grep -E "^publisher_acl:" "$minion_conf" 2>/dev/null || echo "")
  if [[ -n "$acl" ]]; then
    register_check "Publisher ACL" PASS "configured"
  fi
fi

# Check external_auth configuration
master_conf="/etc/salt/master"
if [[ -f "$master_conf" ]]; then
  ext_auth=$(grep -E "^external_auth:" "$master_conf" 2>/dev/null || echo "")
  if [[ -n "$ext_auth" ]]; then
    register_check "External auth" PASS "configured"
  else
    register_check "External auth" WARN "not configured"
  fi
fi

section "Reactor & Events Security"

if [[ -f "$master_conf" ]]; then
  # Check reactor configuration
  reactor=$(grep -E "^reactor:" "$master_conf" 2>/dev/null || echo "")
  if [[ -n "$reactor" ]]; then
    register_check "Reactor" PASS "configured"
  fi

  # Check event return settings
  event_return=$(grep -E "^event_return:" "$master_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$event_return" ]]; then
    register_check "Event return" PASS "$event_return"
  fi
fi

section "Last Highstate Status"

# Check cache for last run
cache_dir="/var/cache/salt/minion"
if [[ -d "$cache_dir" ]]; then
  # Check for highstate cache
  if [[ -f "$cache_dir/highstate.cache.p" ]]; then
    cache_age=$(( ($(date +%s) - $(stat -c %Y "$cache_dir/highstate.cache.p" 2>/dev/null || echo "0")) / 60 ))
    if [[ "$cache_age" -lt 1440 ]]; then
      register_check "Highstate cache" PASS "${cache_age}m ago"
    else
      days_ago=$((cache_age / 1440))
      register_check "Highstate cache" WARN "${days_ago}d ago"
    fi
  fi

  # Check job cache
  jobs_dir="$cache_dir/proc"
  if [[ -d "$jobs_dir" ]]; then
    job_count=$(find "$jobs_dir" -type f 2>/dev/null | wc -l)
    register_check "Pending jobs" PASS "$job_count"
  fi
fi

# Try to get last highstate result
if command -v salt-call >/dev/null 2>&1; then
  last_result=$(salt-call state.last_run 2>/dev/null || echo "")
  if echo "$last_result" | grep -q "last_run"; then
    register_check "Last run info" PASS "available"
  fi
fi

section "Log Configuration"

# Check log settings
if [[ -f "$minion_conf" ]]; then
  log_level=$(grep -E "^log_level:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "warning")
  register_check "Log level" PASS "${log_level:-warning}"

  log_file=$(grep -E "^log_file:" "$minion_conf" 2>/dev/null | awk '{print $2}' || echo "/var/log/salt/minion")
  if [[ -f "$log_file" ]]; then
    log_perms=$(stat -c "%a" "$log_file" 2>/dev/null || echo "unknown")
    if [[ "$log_perms" == "640" ]] || [[ "$log_perms" == "600" ]]; then
      register_check "Log file perms" PASS "$log_perms"
    else
      register_check "Log file perms" WARN "$log_perms"
    fi
  fi
fi

section "Beacons & Scheduler"

# Check beacons configuration
if [[ -f "$minion_conf" ]]; then
  beacons=$(grep -E "^beacons:" "$minion_conf" 2>/dev/null || echo "")
  if [[ -n "$beacons" ]]; then
    register_check "Beacons" PASS "configured"
  fi

  # Check schedule
  schedule=$(grep -E "^schedule:" "$minion_conf" 2>/dev/null || echo "")
  if [[ -n "$schedule" ]]; then
    register_check "Scheduler" PASS "configured"
  fi
fi

print_summary
exit "$EXIT_CODE"
