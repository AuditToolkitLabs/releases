# Terraform Infrastructure as Code Security Audits

This directory contains security audits for Terraform infrastructure automation.

## Audits

### terraform-security-audit.sh

Comprehensive security audit for Terraform installations and configurations.

## What It Checks

### 1. Terraform Installation
- Terraform binary detection
- Version and EOL status
- Command availability

### 2. Configuration Security
- Credentials file (`~/.terraform.d/credentials.tfrc.json`)
- Credentials file permissions (must be 600)
- Terraform RC configuration
- Configuration file permissions

### 3. State File Security (CRITICAL)
- **Local state file detection** (should use remote backend)
- State file permissions (must be 600)
- **Sensitive data in state** (passwords, secrets, keys)
- State file size (performance)
- .terraform directories
- Dependency lock files (.terraform.lock.hcl)

### 4. Backend Configuration
- Remote backend usage (S3, Azure, GCS, Terraform Cloud)
- State encryption enabled
- Backend type validation
- KMS key configuration

### 5. Variable & Secret Management
- .tfvars file security
- .tfvars file permissions (should be 600)
- **Hardcoded secrets detection** (passwords in .tfvars)
- Environment variable usage (TF_VAR_*)
- Sensitive environment variables

### 6. Provider Security
- Provider credential management
- Hardcoded credentials in provider blocks
- Variable usage for credentials
- Provider version constraints
- required_providers configuration

### 7. Module Security
- Module source validation
- Untrusted module sources
- Module version pinning
- Registry vs direct Git sources

### 8. Git Integration
- .gitignore validation
- .terraform directory exclusion
- **State file exclusion** (CRITICAL - may contain secrets)
- .tfvars exclusion (if using secrets)
- Lock file inclusion (for reproducibility)

### 9. Plan File Security
- Plan file detection
- Plan file permissions (must be 600)
- Plan file cleanup after apply

### 10. Terraform Cloud Integration
- Terraform Cloud credentials
- Cloud backend configuration
- Organization and workspace settings

### 11. Workspace Security
- Current workspace detection
- Production workspace warnings
- Workspace naming conventions

## Critical Security Issues

### 🔴 State Files Contain Secrets
**Risk:** CRITICAL  
**Issue:** Local terraform.tfstate files may contain:
- Passwords in plain text
- API keys and tokens
- Private keys
- Database connection strings
- Cloud provider credentials

**Detection:** Audits state files for sensitive patterns  
**Remediation:** Use remote backend with encryption

### 🔴 State Files in Git
**Risk:** CRITICAL  
**Issue:** Committing state files to git exposes all infrastructure secrets  
**Detection:** Checks .gitignore for *.tfstate exclusion  
**Remediation:** Add to .gitignore immediately

### 🔴 Hardcoded Credentials
**Risk:** HIGH  
**Issue:** Credentials in .tf or .tfvars files  
**Detection:** Scans for password/secret/key patterns  
**Remediation:** Use variables and environment variables

### 🔴 World-Readable State Files
**Risk:** HIGH  
**Issue:** State files with 644 or 666 permissions  
**Detection:** Checks file permissions  
**Remediation:** chmod 600 *.tfstate

## Usage

```bash
# Run Terraform security audit
bash audits/linux/automation/iac/terraform-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain automation --match terraform
```

## Requirements

- Terraform CLI installed
- Access to Terraform working directories
- Permissions to read state files and configurations

## Remediation

### Use Remote Backend (Critical Priority)

#### S3 Backend with Encryption

```hcl
# backend.tf
terraform {
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "prod/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    kms_key_id     = "arn:aws:kms:us-east-1:ACCOUNT:key/KEY-ID"
    dynamodb_table = "terraform-state-lock"
  }
}
```

#### Azure Backend with Encryption

```hcl
terraform {
  backend "azurerm" {
    resource_group_name  = "terraform-state-rg"
    storage_account_name = "tfstatestorage"
    container_name       = "tfstate"
    key                  = "prod.terraform.tfstate"
    
    # Encryption enabled by default in Azure Storage
  }
}
```

#### Terraform Cloud

```hcl
terraform {
  cloud {
    organization = "my-org"
    
    workspaces {
      name = "production"
    }
  }
}
```

### Secure .gitignore

```gitignore
# Terraform files
.terraform/
.terraform.lock.hcl  # DON'T exclude - needed for reproducibility
*.tfstate
*.tfstate.*
*.tfplan
*.tfplan.*

# Variable files with secrets
terraform.tfvars
*.auto.tfvars
secrets.tfvars

# Crash log files
crash.log

# Exclude .terraform directories
**/.terraform/*

# Keep lock file (DO NOT add to gitignore)
# .terraform.lock.hcl
```

### Secure Variable Management

```hcl
# variables.tf - Define variables
variable "db_password" {
  description = "Database password"
  type        = string
  sensitive   = true  # Marks as sensitive in output
}

# DON'T DO THIS (hardcoded)
resource "aws_db_instance" "db" {
  password = "my-password-123"  # ❌ NEVER
}

# DO THIS (variable)
resource "aws_db_instance" "db" {
  password = var.db_password  # ✅ GOOD
}
```

Set variables via environment:

```bash
# Export as environment variable
export TF_VAR_db_password="SecurePassword123"

terraform apply
```

Or use .tfvars file (NOT committed to git):

```hcl
# secrets.tfvars (in .gitignore)
db_password = "SecurePassword123"
```

```bash
terraform apply -var-file="secrets.tfvars"
```

### Provider Credential Management

```hcl
# ❌ WRONG - Hardcoded credentials
provider "aws" {
  region     = "us-east-1"
  access_key = "AKIAIOSFODNN7EXAMPLE"
  secret_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
}

# ✅ CORRECT - Use environment variables or ~/.aws/credentials
provider "aws" {
  region = "us-east-1"
  # Credentials from:
  # - AWS_ACCESS_KEY_ID env var
  # - AWS_SECRET_ACCESS_KEY env var
  # - ~/.aws/credentials
  # - EC2 instance profile
}

# ✅ ALSO CORRECT - Use variables
provider "aws" {
  region     = var.aws_region
  access_key = var.aws_access_key
  secret_key = var.aws_secret_key
}
```

### Module Security

```hcl
# ❌ RISKY - Unverified source
module "vpc" {
  source = "git::http://github.com/random-user/terraform-vpc.git"
}

# ✅ SECURE - Terraform Registry with version
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "3.14.2"  # Pin version
}

# ✅ SECURE - Private registry
module "internal" {
  source  = "app.terraform.io/my-org/vpc/aws"
  version = "~> 1.0"
}
```

### Secure File Permissions

```bash
# State files (if local - should use remote backend)
chmod 600 terraform.tfstate
chmod 600 terraform.tfstate.backup

# Variable files with secrets
chmod 600 secrets.tfvars
chmod 600 terraform.tfvars

# Credentials
chmod 600 ~/.terraform.d/credentials.tfrc.json
chmod 600 ~/.terraformrc

# Plan files (delete after apply)
chmod 600 tfplan
rm tfplan  # Delete after apply
```

### Provider Version Locking

```hcl
terraform {
  required_version = ">= 1.0"
  
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 4.0"
    }
    
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
}
```

### Workspace Best Practices

```bash
# List workspaces
terraform workspace list

# Create workspace
terraform workspace new production

# Switch to workspace
terraform workspace select production

# Use different backends per workspace
terraform {
  backend "s3" {
    bucket = "terraform-state-${terraform.workspace}"
    key    = "terraform.tfstate"
  }
}
```

## Security Best Practices

1. **Never commit state files** - Always use remote backend
2. **Enable state encryption** - Use KMS/Azure Key Vault
3. **Use strong permissions** - 600 for sensitive files
4. **No hardcoded secrets** - Use variables and env vars
5. **Pin module versions** - Prevent supply chain attacks
6. **Verified module sources** - Use Terraform Registry
7. **Lock file in git** - Commit .terraform.lock.hcl
8. **Delete plan files** - After apply, remove tfplan files
9. **Separate workspaces** - Dev/staging/prod isolation
10. **Review state regularly** - Check for sensitive data leakage

## Common Vulnerabilities

| Vulnerability | Risk | Detection | Remediation |
|--------------|------|-----------|-------------|
| State in Git | CRITICAL | Check .gitignore | Add *.tfstate to .gitignore |
| Local state with secrets | CRITICAL | Scan state files | Use remote backend |
| Hardcoded credentials | HIGH | Grep for password/key | Use variables |
| World-readable state | HIGH | Check permissions | chmod 600 |
| No backend encryption | HIGH | Check backend config | Enable KMS |
| Unpinned modules | MEDIUM | Check version = | Add version constraints |
| Plaintext tfvars in git | MEDIUM | Check .gitignore | Exclude secrets.tfvars |

## Terraform Cloud Security

### Enable 2FA
```bash
# Login to Terraform Cloud
terraform login

# Enable 2FA in UI: Settings > Security > Two-Factor Authentication
```

### Workspace Variables

Mark sensitive variables:
- ✅ Sensitive: Hidden in UI and logs
- ✅ HCL: Parse as Terraform code
- ✅ Environment variables: TF_VAR_ prefix

### RBAC

Configure team access:
- **Read**: View workspace and state
- **Plan**: Run plans
- **Write**: Apply changes
- **Admin**: Manage workspace settings

## References

- [Terraform Security Best Practices](https://www.terraform.io/docs/cloud/guides/recommended-practices/index.html)
- [Backend Configuration](https://www.terraform.io/docs/language/settings/backends/configuration.html)
- [Sensitive Data in State](https://www.terraform.io/docs/language/state/sensitive-data.html)
- [Terraform Cloud Security](https://www.terraform.io/docs/cloud/architectural-details/security-model.html)
