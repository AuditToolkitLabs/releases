#!/usr/bin/env bash
# Terraform Infrastructure as Code Security Audit
# Validates Terraform installation, state file security, and configuration best practices

# @elevation: none
# @elevation-reason: File and state file checks only
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"

# === Configuration ===
TERRAFORM_DIRS=(
  "/root/.terraform.d"
  "$HOME/.terraform.d"
  "/var/terraform"
  "/opt/terraform"
  "/etc/terraform"
)

STATE_SEARCH_PATHS=(
  "$HOME"
  "/var/terraform"
  "/opt/terraform"
  "/srv/terraform"
  "/root"
)

# === Performance: Cache variables ===
TERRAFORM_VERSION=""
TERRAFORM_FOUND=""

# === Helper Functions ===

# Check if Terraform is installed
is_terraform_installed() {
  if [[ -n "$TERRAFORM_FOUND" ]]; then
    [[ "$TERRAFORM_FOUND" == "true" ]] && return 0 || return 1
  fi

  if command -v terraform >/dev/null 2>&1; then
    TERRAFORM_FOUND="true"
    return 0
  fi

  TERRAFORM_FOUND="false"
  return 1
}

# Get Terraform version
get_terraform_version() {
  if [[ -n "$TERRAFORM_VERSION" ]]; then
    echo "$TERRAFORM_VERSION"
    return 0
  fi

  if command -v terraform >/dev/null 2>&1; then
    version=$(terraform version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    TERRAFORM_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Find Terraform state files
find_state_files() {
  local paths=("$@")
  for path in "${paths[@]}"; do
    if [[ -d "$path" ]]; then
      find "$path" -maxdepth 5 -name "terraform.tfstate" -o -name "*.tfstate" 2>/dev/null || true
    fi
  done
}

# Check if state file contains sensitive data
check_state_sensitivity() {
  local state_file="$1"

  # Check for common sensitive patterns
  if grep -qiE "password|secret|api_key|private_key|access_key|token" "$state_file" 2>/dev/null; then
    return 0  # Contains sensitive data
  fi

  return 1  # No obvious sensitive data
}

# === MAIN AUDIT ===

section "Terraform Detection"

if ! is_terraform_installed; then
  register_check "Terraform Installed" SKIP "Terraform not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Terraform Installed" PASS "Terraform detected"

# Get Terraform version
tf_version=$(get_terraform_version)
if [[ "$tf_version" != "unknown" ]]; then
  register_check "Terraform Version" PASS "Terraform $tf_version"

  # Check for old versions (< 1.0)
  major=$(echo "$tf_version" | cut -d. -f1)
  if [[ "$major" -lt 1 ]]; then
    register_check "Version Status" WARN "Terraform $tf_version is pre-1.0 (consider upgrading)"
  else
    register_check "Version Status" PASS "Terraform $major.x (current)"
  fi
else
  register_check "Terraform Version" WARN "Unable to determine version"
fi

# === Terraform Configuration ===
section "Terraform Configuration"

# Check for credentials file
for tf_dir in "${TERRAFORM_DIRS[@]}"; do
  if [[ -f "$tf_dir/credentials.tfrc.json" ]]; then
    register_check "Credentials File" PASS "Found at $tf_dir/credentials.tfrc.json"

    # Check file permissions
    cred_perms=$(stat -c '%a' "$tf_dir/credentials.tfrc.json" 2>/dev/null || stat -f '%Lp' "$tf_dir/credentials.tfrc.json" 2>/dev/null || echo "000")
    if [[ "$cred_perms" == "600" ]]; then
      register_check "Credentials Permissions" PASS "permissions $cred_perms (secure)"
    else
      register_check "Credentials Permissions" FAIL "permissions $cred_perms (should be 600)"
    fi
    break
  fi
done

# Check for terraform.rc or .terraformrc
terraformrc_found=false
for rc_file in "$HOME/.terraformrc" "/etc/terraform/terraformrc" "$HOME/.terraform.d/terraform.rc"; do
  if [[ -f "$rc_file" ]]; then
    register_check "Terraform RC" PASS "Found at $rc_file"
    terraformrc_found=true

    # Check permissions
    rc_perms=$(stat -c '%a' "$rc_file" 2>/dev/null || stat -f '%Lp' "$rc_file" 2>/dev/null || echo "000")
    if [[ "$rc_perms" == "644" || "$rc_perms" == "600" ]]; then
      register_check "RC Permissions" PASS "permissions $rc_perms"
    else
      register_check "RC Permissions" WARN "permissions $rc_perms (should be 644 or 600)"
    fi
    break
  fi
done

# === State File Security ===
section "Terraform State Files"

# Find state files
state_files=$(find_state_files "${STATE_SEARCH_PATHS[@]}")

if [[ -z "$state_files" ]]; then
  register_check "State Files" PASS "No local state files found (likely using remote backend)"
else
  state_count=$(echo "$state_files" | wc -l)
  register_check "State Files Found" WARN "$state_count state file(s) found locally"

  # Check each state file
  while IFS= read -r state_file; do
    if [[ -f "$state_file" ]]; then
      # Check file permissions
      state_perms=$(stat -c '%a' "$state_file" 2>/dev/null || stat -f '%Lp' "$state_file" 2>/dev/null || echo "000")

      if [[ "$state_perms" == "600" ]]; then
        register_check "State Permissions" PASS "$state_file: $state_perms (secure)"
      elif [[ "$state_perms" =~ ^6[0-4][0-4]$ ]]; then
        register_check "State Permissions" WARN "$state_file: $state_perms (should be 600)"
      else
        register_check "State Permissions" FAIL "$state_file: $state_perms (world-readable - major risk)"
      fi

      # Check if state contains sensitive data
      if check_state_sensitivity "$state_file"; then
        register_check "Sensitive Data" FAIL "$state_file: Contains passwords/secrets (use remote encrypted backend)"
      fi

      # Check file size (large states may have performance issues)
      state_size=$(stat -c '%s' "$state_file" 2>/dev/null || stat -f '%z' "$state_file" 2>/dev/null || echo "0")
      state_size_mb=$((state_size / 1024 / 1024))

      if [[ "$state_size_mb" -gt 10 ]]; then
        register_check "State Size" WARN "$state_file: ${state_size_mb}MB (consider splitting workspaces)"
      fi
    fi
  done <<< "$state_files"
fi

# Check for .terraform directories
terraform_dirs=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -type d -name ".terraform" 2>/dev/null | head -n 10 || echo "")

if [[ -n "$terraform_dirs" ]]; then
  tf_dir_count=$(echo "$terraform_dirs" | wc -l)
  register_check ".terraform Directories" PASS "$tf_dir_count Terraform workspace(s) found"

  # Check for .terraform.lock.hcl files
  while IFS= read -r tf_dir; do
    lock_file="$(dirname "$tf_dir")/.terraform.lock.hcl"
    if [[ -f "$lock_file" ]]; then
      register_check "Dependency Lock" PASS "Lock file exists: $lock_file"
    else
      register_check "Dependency Lock" WARN "No lock file: $(dirname "$tf_dir") (run terraform init)"
    fi
  done <<< "$terraform_dirs"
fi

# === Backend Configuration ===
section "Backend Configuration"

# Check for backend configurations in .tf files
backend_configs=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -name "*.tf" -exec grep -l "backend" {} \; 2>/dev/null || echo "")

if [[ -n "$backend_configs" ]]; then
  register_check "Backend Config" PASS "Backend configuration found in .tf files"

  # Check for remote backends (S3, Azure, GCS, Terraform Cloud)
  remote_backend=false

  if echo "$backend_configs" | xargs grep -qE "backend.*\"s3\"|backend.*\"azurerm\"|backend.*\"gcs\"|backend.*\"remote\"" 2>/dev/null; then
    register_check "Remote Backend" PASS "Remote backend configured (S3/Azure/GCS/Cloud)"
    remote_backend=true
  else
    register_check "Remote Backend" WARN "No remote backend detected (consider S3/Azure/GCS)"
  fi

  # Check for encryption settings
  if echo "$backend_configs" | xargs grep -qE "encrypt.*=.*true|kms_key_id" 2>/dev/null; then
    register_check "State Encryption" PASS "Backend encryption enabled"
  else
    if [[ "$remote_backend" == "true" ]]; then
      register_check "State Encryption" WARN "Encryption not explicitly configured (verify backend settings)"
    fi
  fi
fi

# === Variable Security ===
section "Variable & Secret Management"

# Find .tfvars files
tfvars_files=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -name "*.tfvars" -o -name "*.auto.tfvars" 2>/dev/null || echo "")

if [[ -n "$tfvars_files" ]]; then
  tfvars_count=$(echo "$tfvars_files" | wc -l)
  register_check ".tfvars Files" PASS "$tfvars_count variable file(s) found"

  # Check permissions on .tfvars files
  while IFS= read -r tfvars_file; do
    if [[ -f "$tfvars_file" ]]; then
      tfvars_perms=$(stat -c '%a' "$tfvars_file" 2>/dev/null || stat -f '%Lp' "$tfvars_file" 2>/dev/null || echo "000")

      if [[ "$tfvars_perms" == "600" ]]; then
        register_check "tfvars Permissions" PASS "$tfvars_file: $tfvars_perms"
      else
        register_check "tfvars Permissions" WARN "$tfvars_file: $tfvars_perms (should be 600)"
      fi

      # Check for hardcoded secrets
      if grep -qiE "password.*=.*\"|secret.*=.*\"|api_key.*=.*\"" "$tfvars_file" 2>/dev/null; then
        register_check "Hardcoded Secrets" FAIL "$tfvars_file: Contains hardcoded secrets (use env vars or vault)"
      fi
    fi
  done <<< "$tfvars_files"
fi

# Check for environment variables
if env | grep -qE "^TF_VAR_|^AWS_|^AZURE_|^GOOGLE_"; then
  register_check "Environment Variables" PASS "Terraform variables set via environment"

  # Check for sensitive env vars
  if env | grep -qE "^TF_VAR_.*password|^TF_VAR_.*secret|^TF_VAR_.*key"; then
    register_check "Sensitive Env Vars" WARN "Sensitive variables in environment (ensure proper scoping)"
  fi
fi

# === Provider Security ===
section "Provider Configuration"

# Find provider configurations
provider_files=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -name "*.tf" -exec grep -l "provider" {} \; 2>/dev/null | head -n 20 || echo "")

if [[ -n "$provider_files" ]]; then
  register_check "Provider Config" PASS "Provider configuration found"

  # Check for hardcoded credentials in providers
  if echo "$provider_files" | xargs grep -qE "access_key.*=|secret_key.*=|client_secret.*=|password.*=" 2>/dev/null; then
    if echo "$provider_files" | xargs grep -qE "access_key.*=.*var\.|secret_key.*=.*var\.|client_secret.*=.*var\." 2>/dev/null; then
      register_check "Provider Credentials" PASS "Using variables (not hardcoded)"
    else
      register_check "Provider Credentials" FAIL "Hardcoded credentials in provider blocks (use variables/env vars)"
    fi
  fi

  # Check for provider version constraints
  if echo "$provider_files" | xargs grep -q "required_providers" 2>/dev/null; then
    register_check "Provider Versions" PASS "Provider version constraints defined"
  else
    register_check "Provider Versions" WARN "No provider version constraints (use required_providers)"
  fi
fi

# === Module Security ===
section "Module Configuration"

# Find module sources
module_files=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -name "*.tf" -exec grep -l "module" {} \; 2>/dev/null | head -n 20 || echo "")

if [[ -n "$module_files" ]]; then
  register_check "Modules Used" PASS "Terraform modules detected"

  # Check for untrusted sources
  if echo "$module_files" | xargs grep -E "source.*=.*\"http://|source.*=.*\"git::" 2>/dev/null | grep -qv "github.com\|gitlab.com\|registry.terraform.io"; then
    register_check "Module Sources" WARN "Untrusted module sources detected (verify origins)"
  else
    register_check "Module Sources" PASS "Using trusted module sources"
  fi

  # Check for version pinning
  if echo "$module_files" | xargs grep -E "module.*\{" -A 10 2>/dev/null | grep -q "version.*="; then
    register_check "Module Versions" PASS "Module versions pinned"
  else
    register_check "Module Versions" WARN "Module versions not pinned (use version constraints)"
  fi
fi

# === .gitignore Security ===
section "Git Integration"

# Find .gitignore files in Terraform directories
while IFS= read -r tf_dir; do
  repo_root=$(dirname "$tf_dir")
  gitignore="$repo_root/.gitignore"

  if [[ -f "$gitignore" ]]; then
    register_check ".gitignore Found" PASS "$gitignore"

    # Check for critical exclusions
    if grep -qE "^\.terraform$|^\.terraform/$" "$gitignore"; then
      register_check "Ignore .terraform" PASS ".terraform directory excluded"
    else
      register_check "Ignore .terraform" WARN ".terraform not in .gitignore (add it)"
    fi

    if grep -qE "^\*\.tfstate$|^terraform\.tfstate$" "$gitignore"; then
      register_check "Ignore .tfstate" PASS "State files excluded from git"
    else
      register_check "Ignore .tfstate" FAIL "*.tfstate not in .gitignore (CRITICAL - state may contain secrets)"
    fi

    if grep -qE "^\*\.tfvars$|^terraform\.tfvars$" "$gitignore"; then
      register_check "Ignore .tfvars" PASS "Variable files excluded (if using secrets)"
    else
      register_check "Ignore .tfvars" WARN "*.tfvars not in .gitignore (consider adding if using secrets)"
    fi

    if grep -qE "^\.terraform\.lock\.hcl$" "$gitignore"; then
      register_check "Lock File in Git" WARN ".terraform.lock.hcl excluded (should be committed for reproducibility)"
    else
      register_check "Lock File in Git" PASS "Dependency lock file not excluded (good practice)"
    fi

    break  # Only check first gitignore found
  fi
done <<< "$terraform_dirs"

# === Plan Files ===
section "Plan File Security"

# Find plan files
plan_files=$(find "${STATE_SEARCH_PATHS[@]}" -maxdepth 5 -name "*.tfplan" -o -name "tfplan" 2>/dev/null || echo "")

if [[ -n "$plan_files" ]]; then
  plan_count=$(echo "$plan_files" | wc -l)
  register_check "Plan Files" WARN "$plan_count plan file(s) found (should be deleted after apply)"

  # Check permissions
  while IFS= read -r plan_file; do
    if [[ -f "$plan_file" ]]; then
      plan_perms=$(stat -c '%a' "$plan_file" 2>/dev/null || stat -f '%Lp' "$plan_file" 2>/dev/null || echo "000")

      if [[ "$plan_perms" == "600" ]]; then
        register_check "Plan Permissions" PASS "$plan_file: $plan_perms"
      else
        register_check "Plan Permissions" FAIL "$plan_file: $plan_perms (contains sensitive data, should be 600)"
      fi
    fi
  done <<< "$plan_files"
else
  register_check "Plan Files" PASS "No plan files found (cleanup after apply)"
fi

# === Terraform Cloud/Enterprise ===
section "Terraform Cloud Integration"

# Check for Terraform Cloud credentials
if [[ -f "$HOME/.terraform.d/credentials.tfrc.json" ]]; then
  register_check "TF Cloud Config" PASS "Terraform Cloud credentials configured"

  # Check if it contains tokens
  if grep -q "token" "$HOME/.terraform.d/credentials.tfrc.json" 2>/dev/null; then
    register_check "TF Cloud Token" PASS "API token found (ensure secure permissions)"
  fi
fi

# Check for cloud backend in configs
if [[ -n "$backend_configs" ]]; then
  if echo "$backend_configs" | xargs grep -qE "organization.*=|workspaces.*=" 2>/dev/null; then
    register_check "TF Cloud Backend" PASS "Using Terraform Cloud/Enterprise backend"
  fi
fi

# === Workspace Security ===
section "Workspace Configuration"

# Check current workspace
if [[ -n "$terraform_dirs" ]]; then
  current_workspace=$(head -n1 <<< "$terraform_dirs" | xargs dirname 2>/dev/null)

  if [[ -f "$current_workspace/.terraform/environment" ]]; then
    workspace_name=$(cat "$current_workspace/.terraform/environment" 2>/dev/null || echo "default")

    if [[ "$workspace_name" == "production" || "$workspace_name" == "prod" ]]; then
      register_check "Production Workspace" WARN "Production workspace detected (ensure extra caution)"
    else
      register_check "Workspace Name" PASS "Workspace: $workspace_name"
    fi
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
