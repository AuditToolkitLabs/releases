#!/usr/bin/env bash
# Laravel Forge Provisioning Readiness Audit (portable)

# @elevation: partial
# @elevation-reason: May invoke service checks and system config access
#
set -euo pipefail

# Load shared helpers (portable.sh). If not present, we still try to proceed gracefully.
# shellcheck source=../_lib/portable.sh
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../_lib" && pwd)/portable.sh" 2>/dev/null || true

# Fallbacks if portable.sh didn't define these helpers
command -v svc_is_active  >/dev/null 2>&1 || svc_is_active(){ systemctl is-active  --quiet "$1"; }
command -v svc_is_enabled >/dev/null 2>&1 || svc_is_enabled(){ systemctl is-enabled --quiet "$1"; }

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0

setup_colors(){
  if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then
    RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""
  else
    RED=$'\e[0;31m'; GREEN=$'\e[0;32m'; YELLOW=$'\e[0;33m'; BLUE=$'\e[0;34m'
    CYAN=$'\e[0;36m'; BOLD=$'\e[1m'; NC=$'\e[0m'
  fi
}
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }

_log(){
  local level="$1"; shift || true
  local msg="$*"; local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ "$QUIET" != "true" ]] && echo "$line"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }
}

# Optional verbose logger
# shellcheck disable=SC2329
_debug(){ [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*"; }

TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){
  local n="$1" r="$2" m="${3:-}"
  ((++TOTAL_CHECKS))
  case "$r" in
    PASS) ((++PASSED_CHECKS));  echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}" ;;
    FAIL) ((++FAILED_CHECKS));  EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}" ;;
    WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}" ;;
    SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}" ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true
}

section(){
  local t="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $t${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :
}

check_privs(){
  section "Privileges"
  if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
    register_check "Root privileges" PASS "running as root"
  else
    register_check "Root privileges" WARN "sudo recommended"
  fi
}

check_os(){
  section "Operating System"
  if [[ -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release || true
    register_check "Distribution" PASS "${NAME:-unknown} ${VERSION_ID:-}"
    case "${ID:-}" in
      ubuntu)
        case "${VERSION_ID:-}" in
          20.04|22.04|24.04) register_check "Ubuntu version" PASS "supported LTS" ;;
          *)                  register_check "Ubuntu version" WARN "${VERSION_ID:-unknown} (Forge expects LTS)" ;;
        esac
        ;;
      *)
        register_check "Distribution note" WARN "Forge targets Ubuntu; other distros may work with tweaks"
        ;;
    esac
  else
    register_check "Distribution" SKIP "unknown"
  fi
}

check_commands(){
  section "Required Commands"
  local req=(curl git openssl)
  local m=0 c
  for c in "${req[@]}"; do
    if command -v "$c" >/dev/null 2>&1; then
      register_check "$c" PASS "present"
    else
      register_check "$c" FAIL "missing"; ((m++))
    fi
  done
  [[ $m -eq 0 ]] || true
}

check_ssh(){
  section "SSH Configuration"
  local cfg=/etc/ssh/sshd_config
  if [[ -f "$cfg" ]]; then
    register_check "sshd_config" PASS "$cfg"
  else
    register_check "sshd_config" FAIL "missing"
    return 0
  fi

  if svc_is_active ssh || svc_is_active sshd; then
    register_check "SSH service" PASS "active"
  else
    register_check "SSH service" FAIL "inactive"
  fi

  if svc_is_enabled ssh || svc_is_enabled sshd; then
    register_check "SSH enabled at boot" PASS "yes"
  else
    register_check "SSH enabled at boot" WARN "no"
  fi

  local port
  port=$(awk '/^\s*Port\s+/{print $2;exit}' "$cfg" 2>/dev/null || true)
  if [[ -z "$port" ]]; then
    register_check "SSH port" PASS "22 (default)"
  elif [[ "$port" =~ ^[0-9]+$ ]] && (( port == 22 )); then
    register_check "SSH port" PASS "22"
  else
    register_check "SSH port" WARN "$port (ensure Forge configured)"
  fi

  local prl
  prl=$(awk '/^\s*PermitRootLogin\s+/{print $2;exit}' "$cfg" 2>/dev/null || true)
  if [[ -z "$prl" ]]; then
    register_check "PermitRootLogin" PASS "default (key-only)"
  else
    case "$prl" in
      no)                                 register_check "PermitRootLogin" FAIL "no (Forge may need initial root)";;
      prohibit-password|without-password|yes)
                                          register_check "PermitRootLogin" PASS "$prl";;
      *)                                  register_check "PermitRootLogin" WARN "$prl";;
    esac
  fi

  local pa
  pa=$(awk '/^\s*PasswordAuthentication\s+/{print $2;exit}' "$cfg" 2>/dev/null || true)
  if [[ -z "$pa" ]]; then
    register_check "PasswordAuthentication" WARN "not set"
  else
    if [[ "$pa" =~ ^[Nn][Oo]$ ]]; then
      register_check "PasswordAuthentication" PASS "no"
    else
      register_check "PasswordAuthentication" WARN "$pa"
    fi
  fi

  local pka
  pka=$(awk '/^\s*PubkeyAuthentication\s+/{print $2;exit}' "$cfg" 2>/dev/null || true)
  if [[ -z "$pka" ]]; then
    register_check "PubkeyAuthentication" PASS "default yes"
  else
    if [[ "$pka" =~ ^[Yy][Ee][Ss]$ ]]; then
      register_check "PubkeyAuthentication" PASS "yes"
    else
      register_check "PubkeyAuthentication" FAIL "$pka"
    fi
  fi
}

check_firewall(){
  section "Firewall"
  if command -v ufw >/dev/null 2>&1; then
    if ufw status 2>/dev/null | grep -q "Status: active"; then
      register_check "UFW active" PASS "yes"
    else
      register_check "UFW active" WARN "no"
    fi

    if ufw status 2>/dev/null | grep -Eq '(^|\s)(OpenSSH|22/tcp)(\s|$)'; then
      register_check "UFW allows SSH" PASS "yes"
    else
      register_check "UFW allows SSH" FAIL "rule missing"
    fi

  elif command -v firewall-cmd >/dev/null 2>&1; then
    if firewall-cmd --state >/dev/null 2>&1; then
      register_check "firewalld" PASS "running"
    else
      register_check "firewalld" WARN "not running"
    fi

    if firewall-cmd --list-services 2>/dev/null | grep -qw ssh; then
      register_check "firewalld allows SSH" PASS "yes"
    else
      register_check "firewalld allows SSH" FAIL "no"
    fi

  elif command -v nft >/dev/null 2>&1 || command -v iptables >/dev/null 2>&1; then
    register_check "Firewall" PASS "present (nft/iptables)"
  else
    register_check "Firewall" WARN "none detected"
  fi
}

check_outbound(){
  section "Outbound Connectivity"

  if command -v host >/dev/null 2>&1; then
    if host github.com >/dev/null 2>&1; then
      register_check "DNS github.com" PASS "ok"
    else
      register_check "DNS github.com" WARN "fail"
    fi
  elif command -v nslookup >/dev/null 2>&1; then
    if nslookup github.com >/dev/null 2>&1; then
      register_check "DNS github.com" PASS "ok"
    else
      register_check "DNS github.com" WARN "fail"
    fi
  else
    register_check "DNS tool" SKIP "host/nslookup absent"
  fi

  if command -v curl >/dev/null 2>&1; then
    local url
    for url in https://github.com https://packagist.org https://getcomposer.org; do
      if curl -s --connect-timeout 5 -o /dev/null -w '%{http_code}' "$url" | grep -qE '^(200|301|302)$'; then
        register_check "Reach $url" PASS "ok"
      else
        register_check "Reach $url" WARN "blocked"
      fi
    done
  else
    register_check "curl" FAIL "required"
  fi
}

check_resources(){
  section "Resources"

  local ram
  ram=$( (free -m || true) | awk '/^Mem:/{print $2}' )
  if [[ -n "$ram" ]]; then
    if (( ram < 512 )); then
      register_check "RAM" WARN "${ram}MB (<1GB)"
    else
      register_check "RAM" PASS "${ram}MB"
    fi
  else
    register_check "RAM" SKIP "unknown"
  fi

  local pct
  pct=$(df -h / 2>/dev/null | awk 'NR==2{gsub("%","");print $5}')
  if [[ -n "$pct" ]]; then
    if   (( pct > 90 )); then
      register_check "Disk usage" FAIL ">$pct%"
    elif (( pct > 80 )); then
      register_check "Disk usage" WARN ">$pct%"
    else
      register_check "Disk usage" PASS "$pct%"
    fi
  else
    register_check "Disk usage" SKIP "unknown"
  fi

  local cores
  cores=$(nproc 2>/dev/null || echo 1)
  if (( cores < 2 )); then
    register_check "CPU cores" WARN "$cores"
  else
    register_check "CPU cores" PASS "$cores"
  fi
}

check_conflicts(){
  section "Potential Conflicts"
  local s d
  for s in apache2 nginx httpd; do
    svc_is_active "$s" && register_check "Web server running" WARN "$s"
  done
  for d in mysql mariadb postgresql; do
    svc_is_active "$d" && register_check "Database running" WARN "$d"
  done

  if command -v php >/dev/null 2>&1; then
    register_check "PHP present" WARN "$(php -v 2>/dev/null | head -n1)"
  else
    register_check "PHP present" PASS "not installed"
  fi
}

usage(){
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable Forge provisioning readiness audit
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug
      --no-color         Disable color
  -h, --help             Help
      --version          Version

Exit codes: 0=OK, 1=Warnings present, 2=Failures present
EOF
}

version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary(){
  echo
  echo -e "${BOLD}FORGE PROVISIONING AUDIT SUMMARY${NC}"
  printf ' PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d\n' \
    "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
}

main(){
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;;
      -q|--quiet) QUIET=true; shift;;
      -v|--verbose) VERBOSE=true; shift;;
      --no-color) NO_COLOR=true; shift;;
      -h|--help) usage; exit 0;;
      --version) version; exit 0;;
      *) echo "Unknown option: $1" >&2; usage >&2; exit 1;;
    esac
  done

  setup_colors

  if [[ -n "$LOG_FILE" ]]; then
    # Create log path with restrictive permissions
    umask 077
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    : > "$LOG_FILE" 2>/dev/null || true
  fi

  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"

  check_privs
  check_os
  check_commands
  check_ssh
  check_firewall
  check_outbound
  check_resources
  check_conflicts

  print_summary
  exit "$EXIT_CODE"
}

main "$@"
