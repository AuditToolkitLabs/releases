#!/usr/bin/env bash
# Git Deployment Security Audit (portable)

# @elevation: partial
# @elevation-reason: Git repository and deployment directory access
#
set -euo pipefail

# Load shared helpers (portable.sh). If not present, proceed gracefully.
# shellcheck shell=bash source-path=SCRIPTDIR/../_lib
# shellcheck source=portable.sh
# shellcheck disable=SC1091
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../_lib" && pwd)/portable.sh" 2>/dev/null || true

# Fallbacks if portable.sh didn't define these helpers (no-ops if already present)
# shellcheck disable=SC2329
command -v svc_is_active  >/dev/null 2>&1 || svc_is_active(){ systemctl is-active  --quiet "$1"; }
# shellcheck disable=SC2329
command -v svc_is_enabled >/dev/null 2>&1 || svc_is_enabled(){ systemctl is-enabled --quiet "$1"; }

SCRIPT_NAME="${0##*/}"
SCRIPT_VERSION="4.0.0"

LOG_FILE="${LOG_FILE:-/var/log/git-deploy-audit.log}"
APP_PATH="${APP_PATH:-/var/www/html}"

QUIET=false
# shellcheck disable=SC2034   # Referenced by _debug (and may be toggled via CLI)
VERBOSE=false
NO_COLOR=false
EXIT_CODE=0

setup_colors(){
  if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then
    RED="" YELLOW="" GREEN="" BLUE="" CYAN="" MAGENTA="" BOLD="" NC=""
  else
    RED=$'\e[0;31m';   YELLOW=$'\e[1;33m'; GREEN=$'\e[0;32m'; BLUE=$'\e[0;34m'
    CYAN=$'\e[0;36m'
    # shellcheck disable=SC2034   # Reserved for future highlighting; harmless if unused
    MAGENTA=$'\e[0;35m'
    BOLD=$'\e[1m';     NC=$'\e[0m'
  fi
}

_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }

_log(){
  local lvl="$1"; shift || true
  local msg="$*"

local ln
ln="[$(_timestamp)] [$lvl] $msg"
  [[ "$QUIET" != "true" ]] && echo "$ln"
  if [[ -n "$LOG_FILE" ]]; then
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || :
    echo "$ln" >> "$LOG_FILE" 2>/dev/null || :
  fi
}

# Tiny verbose logger so VERBOSE is a real read-usage
_debug(){ [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*"; }

section(){
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $1${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
}

TOTAL=0; PASS=0; FAIL=0; WARN=0; SKIP=0
mark(){
  local n="$1" r="$2" m="${3:-}"
  ((++TOTAL))
  case "$r" in
    PASS) ((++PASS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}" ;;
    FAIL) ((++FAIL)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC} $n${m:+: $m}" ;;
    WARN) ((++WARN)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}" ;;
    SKIP) ((++SKIP)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}" ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || :
}

check_privs(){
  section "Privilege Check"
  if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
    mark "Root privileges" PASS "running as root"
  else
    mark "Root privileges" WARN "sudo recommended"
    _log INFO "Current user: $(whoami)"
  fi
}

check_git(){
  section "Git Installation"
  if ! command -v git >/dev/null 2>&1; then
    mark "git installed" FAIL "not found"
    return 1
  fi
  mark "git installed" PASS "$(git --version 2>/dev/null | head -n1)"
}

validate_repo(){
  section "Repository Validation"
  _debug "APP_PATH=$APP_PATH"

  if [[ ! -d "$APP_PATH" ]]; then
    mark "App path" FAIL "$APP_PATH not found"
    return 1
  fi
  mark "App path" PASS "$APP_PATH"

  if [[ ! -d "$APP_PATH/.git" ]]; then
    mark ".git present" FAIL "missing"
    return 1
  fi
  mark ".git present" PASS "$APP_PATH/.git"

  if ( cd "$APP_PATH" && git status >/dev/null 2>&1 ); then
    mark "Repo health" PASS "git status ok"
  else
    mark "Repo health" FAIL "git status failed"
  fi
}

remotes(){
  section "Remote Configuration"

  if [[ ! -d "$APP_PATH/.git" ]]; then
    mark "Remotes" SKIP "not a repo"
    return
  fi

  local out
  out="$(cd "$APP_PATH" && git remote -v 2>/dev/null || true)"

  if [[ -n "$out" ]]; then
    mark "Remotes configured" PASS "yes"
  else
    mark "Remotes configured" WARN "none"
    return
  fi

  local https=0 ssh=0 http=0 other=0
  local line url
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    [[ "$line" == *"(fetch)"* ]] && continue   # consider push lines primarily
    url="$(printf '%s\n' "$line" | awk '{print $2}')"
    case "$url" in
      https://*) ((https++)) ;;
      git@*|ssh://*) ((ssh++)) ;;
      http://*) ((http++)) ;;
      *) ((other++)) ;;
    esac
  done <<< "$out"

  if (( ssh   > 0 )); then mark "SSH remotes"       PASS "$ssh";   fi
  if (( https > 0 )); then mark "HTTPS remotes"     WARN "$https"; fi
  if (( http  > 0 )); then mark "HTTP remotes"      FAIL "$http (insecure)"; fi
  if (( other > 0 )); then mark "Other protocols"   WARN "$other"; fi

  _debug "Remote counts: ssh=$ssh https=$https http=$http other=$other"

  local helper
  helper="$(cd "$APP_PATH" && git config --get credential.helper 2>/dev/null || true)"
  if [[ -n "$helper" ]]; then
    case "$helper" in
      store) mark "Credential helper" FAIL "store (plaintext)" ;;
      cache) mark "Credential helper" WARN "cache" ;;
      *)     mark "Credential helper" PASS "$helper" ;;
    esac
  else
    mark "Credential helper" PASS "none"
  fi
}

ssh_keys(){
  section "SSH Deploy Keys"
  local d="$HOME/.ssh"

  if [[ -d "$d" ]]; then
    mark "$HOME/.ssh" PASS "$d"
  else
    mark "$HOME/.ssh" WARN "missing"
    return
  fi

  local perms
  perms="$(stat -c %a "$d" 2>/dev/null || echo "")"
  if [[ "$perms" == "700" ]]; then
    mark "$HOME/.ssh perms" PASS "$perms"
  else
    mark "$HOME/.ssh perms" WARN "$perms (expect 700)"
  fi

  local files
  files="$(find "$d" -maxdepth 1 -type f \( -name 'id_*' -o -name '*_ed25519' -o -name '*_rsa' \) ! -name '*.pub' 2>/dev/null || true)"

  if [[ -n "$files" ]]; then
    mark "Private keys" PASS "found"
    while IFS= read -r f; do
      [[ -z "$f" ]] && continue
      local kp
      kp="$(stat -c %a "$f" 2>/dev/null || echo "")"
      if [[ "$kp" == "600" || "$kp" == "400" ]]; then
        mark "key perms $(basename "$f")" PASS "$kp"
      else
        mark "key perms $(basename "$f")" WARN "$kp (expect 600/400)"
      fi
    done <<< "$files"
  else
    mark "Private keys" WARN "none"
  fi
}

gitignore(){
  section ".gitignore & Sensitive Files"

  # Must be a Git repo
  if [[ ! -d "$APP_PATH/.git" ]]; then
    mark ".gitignore" SKIP "not a repo"
    return
  fi

  local gi="$APP_PATH/.gitignore"

  # .gitignore present?
  if [[ -f "$gi" ]]; then
    mark ".gitignore present" PASS "$gi"
  else
    mark ".gitignore present" WARN "missing"
    return
  fi

  # Essential patterns present?
  local need=( ".env" "vendor/" "node_modules/" "*.log" "*.sqlite" )
  local miss=0 p
  for p in "${need[@]}"; do
    if ! grep -qF "$p" "$gi" 2>/dev/null; then
      ((miss++))
    fi
  done

  if (( miss > 0 )); then
    mark ".gitignore essentials" WARN "$miss missing"
  else
    mark ".gitignore essentials" PASS "ok"
  fi

  # Are any .env* files tracked?
  local tracked
  tracked="$(cd "$APP_PATH" && git ls-files | grep -E '^\.env(\.|$)' || true)"

  if [[ -n "$tracked" ]]; then
    mark "Sensitive files tracked" FAIL ".env files present"
  else
    mark "Sensitive files tracked" PASS "none"
  fi
}

summary(){
  echo
  echo -e "${BOLD}GIT DEPLOYMENT AUDIT SUMMARY${NC}"
  printf ' PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d\n' "$PASS" "$WARN" "$FAIL" "$SKIP" "$TOTAL"
}

usage(){
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
  -l, --log FILE         Log file (default: $LOG_FILE)
  -a, --app-path DIR     Application path (default: $APP_PATH)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}

version(){ echo "$SCRIPT_NAME v$SCRIPT_VERSION"; }

main(){
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -l|--log)       LOG_FILE="$2"; shift 2;;
      -a|--app-path)  APP_PATH="$2"; shift 2;;
      -q|--quiet)     QUIET=true; shift;;
      -v|--verbose)   VERBOSE=true; shift;;
      --no-color)     NO_COLOR=true; shift;;
      -h|--help)      usage; exit 0;;
      --version)      version; exit 0;;
      *) echo "Unknown option: $1" >&2; usage >&2; exit 1;;
    esac
  done

  setup_colors

  if [[ -n "$LOG_FILE" ]]; then
    umask 077
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    : > "$LOG_FILE" 2>/dev/null || true
  fi

  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"

  check_privs
  check_git
  validate_repo
  remotes
  ssh_keys
  gitignore
  summary
  exit "$EXIT_CODE"
}

main "$@"
