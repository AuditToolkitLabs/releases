#!/usr/bin/env bash
# Orchestrator: run all available audits

# @elevation: partial
# @elevation-reason: Invokes child scripts that may require elevated access
#
set -euo pipefail
LOG_DIR=""; URL=""; APP_PATH=""; QUIET=false; VERBOSE=false
usage(){ cat <<EOF
Usage: ${0##*/} [--log-dir DIR] [--url URL] [--app-path DIR] [--quiet] [--verbose]
Runs all portable audits found under audits/linux/.
EOF
}
while [[ $# -gt 0 ]]; do case "$1" in
  --log-dir) LOG_DIR="$2"; shift 2;;
  --url) URL="$2"; shift 2;;
  --app-path) APP_PATH="$2"; shift 2;;
  --quiet) QUIET=true; shift;;
  --verbose) VERBOSE=true; shift;;
  -h|--help) usage; exit 0;;
  *) shift;; esac; done
[[ -n "$LOG_DIR" ]] && mkdir -p "$LOG_DIR"
run(){ local s="$1"; shift || true; echo -e "
=== RUN: $s ==="; chmod +x "$s" || true; "$s" "$@" || true; }
BASE="$(cd "$(dirname "$0")/../../.." && pwd)"
# Run all audits under audits/linux/ recursively
find "$BASE/audits/linux" -type f -name '*.sh' | sort | while read -r script; do
  run "$script" ${LOG_DIR:+--log "$LOG_DIR/$(basename "$script" .sh)-audit.log"} ${QUIET:+--quiet} ${VERBOSE:+--verbose}
done
