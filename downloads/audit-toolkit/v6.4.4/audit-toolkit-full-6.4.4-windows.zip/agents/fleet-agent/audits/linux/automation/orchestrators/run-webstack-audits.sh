#!/usr/bin/env bash
# Orchestrator: common web-stack audits

# @elevation: partial
# @elevation-reason: Invokes child scripts that may require elevated access
#
set -euo pipefail
LOG_DIR=""; URL=""; APP_PATH=""
usage(){ echo "Usage: ${0##*/} --url URL [--app-path DIR] [--log-dir DIR]"; }
while [[ $# -gt 0 ]]; do case "$1" in
  --url) URL="$2"; shift 2;;
  --app-path) APP_PATH="$2"; shift 2;;
  --log-dir) LOG_DIR="$2"; shift 2;;
  -h|--help) usage; exit 0;;
  *) shift;; esac; done
[[ -z "$URL" ]] && { echo "--url required" >&2; exit 1; }
[[ -n "$LOG_DIR" ]] && mkdir -p "$LOG_DIR"
BASE="$(cd "$(dirname "$0")" && pwd)"
run(){ local s="$1"; shift || true; echo -e "
=== RUN: $s ==="; chmod +x "$s" || true; "$s" "$@" || true; }
[[ -x "$BASE/nginx-security-audit.sh"  ]] && run "$BASE/nginx-security-audit.sh"  ${LOG_DIR:+--log "$LOG_DIR/nginx-audit.log"}
[[ -x "$BASE/apache-security-audit.sh" ]] && run "$BASE/apache-security-audit.sh" ${LOG_DIR:+--log "$LOG_DIR/apache-audit.log"}
[[ -x "$BASE/php-fpm-audit.sh" ]] && run "$BASE/php-fpm-audit.sh" ${LOG_DIR:+--log "$LOG_DIR/php-fpm-audit.log"}
[[ -x "$BASE/cdn-headers-audit.sh" ]] && run "$BASE/cdn-headers-audit.sh" --url "$URL"
[[ -x "$BASE/git-deploy-audit.sh" && -n "$APP_PATH" ]] && run "$BASE/git-deploy-audit.sh" --app-path "$APP_PATH"
[[ -x "$BASE/archive-storage-audit.sh" ]] && run "$BASE/archive-storage-audit.sh" ${LOG_DIR:+--log "$LOG_DIR/archive-audit.log"}
