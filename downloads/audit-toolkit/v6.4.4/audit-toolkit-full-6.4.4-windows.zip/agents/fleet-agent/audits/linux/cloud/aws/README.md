# AWS Cloud Audits

This folder contains audits for AWS services and agents running on Linux systems.

## Planned Audits (from TODO-LINUX-COMMERCIAL-ENHANCEMENTS.md)

| Script | Description | Status |
|--------|-------------|--------|
| `aws-ssm-audit.sh` | Amazon SSM Agent audit - checks agent installation, service status, instance registration | TODO |
| `aws-cloudwatch-audit.sh` | CloudWatch Agent audit - checks agent installation, metric collection, log forwarding | TODO |
| `cloud-init-audit.sh` | Cloud-init configuration and security audit | TODO |

## Key Checks for AWS SSM Agent

- `amazon-ssm-agent` package installed
- Service running and enabled
- Instance registered with SSM
- Agent version current
- Hybrid activation status (for on-prem)
- `/var/lib/amazon/ssm/` directory permissions

## Key Checks for CloudWatch Agent

- `amazon-cloudwatch-agent` package installed
- Service running
- Configuration file (`/opt/aws/amazon-cloudwatch-agent/etc/`)
- Log sources configured
- Metrics collection active
- IAM role/credentials configured

## Usage

```bash
bash audits/linux/cloud/aws/aws-ssm-audit.sh
bash audits/linux/cloud/aws/aws-cloudwatch-audit.sh
```

## References

- [AWS SSM Agent](https://docs.aws.amazon.com/systems-manager/latest/userguide/ssm-agent.html)
- [CloudWatch Agent](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Install-CloudWatch-Agent.html)
