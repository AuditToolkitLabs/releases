#!/usr/bin/env bash
# aws-cloudwatch-audit.sh — AWS CloudWatch Agent Security Audit
#
# Compliance Mapping:
# - AWS Well-Architected (Operational Excellence): OPS 04, OPS 08
# - AWS Security Best Practices (Logging & Monitoring)
# - CIS AWS Foundations Benchmark: 3.x (Monitoring)
#
# Checks:
# - CloudWatch Agent installation and version
# - Service status
# - Configuration validation
# - Log groups configured
# - Metrics collection
#
# @elevation: partial
# @elevation-reason: Reads CloudWatch agent config files which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "AWS CloudWatch Agent Audit"

# Check if CloudWatch Agent is installed
CW_AGENT_DIR="/opt/aws/amazon-cloudwatch-agent"
CW_BINARY="$CW_AGENT_DIR/bin/amazon-cloudwatch-agent"

if [[ ! -d "$CW_AGENT_DIR" ]] && [[ ! -f "$CW_BINARY" ]]; then
  register_check "CloudWatch Agent installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "CloudWatch Agent installed" PASS "found in $CW_AGENT_DIR"

section "CloudWatch Agent Service Status"

# Determine service name
cw_service=""
for svc in amazon-cloudwatch-agent amazon-cloudwatch-agent.service; do
  if systemctl list-unit-files 2>/dev/null | grep -q "^${svc}"; then
    cw_service="$svc"
    break
  fi
done

if [[ -n "$cw_service" ]]; then
  if systemctl is-active "$cw_service" >/dev/null 2>&1; then
    register_check "Service running" PASS "active"
  else
    register_check "Service running" FAIL "inactive"
  fi

  if systemctl is-enabled "$cw_service" >/dev/null 2>&1; then
    register_check "Service enabled" PASS "starts on boot"
  else
    register_check "Service enabled" WARN "not enabled"
  fi
else
  register_check "Service status" WARN "could not find service"
fi

section "CloudWatch Agent Version"

# Get agent version
if [[ -x "$CW_BINARY" ]]; then
  version=$("$CW_BINARY" --version 2>/dev/null || echo "")
  if [[ -n "$version" ]]; then
    register_check "Agent version" PASS "$version"
  else
    register_check "Agent version" WARN "could not determine"
  fi
elif [[ -f "$CW_AGENT_DIR/RELEASE" ]]; then
  version=$(cat "$CW_AGENT_DIR/RELEASE" 2>/dev/null || echo "")
  if [[ -n "$version" ]]; then
    register_check "Agent version" PASS "$version"
  fi
fi

section "Agent Configuration"

# Configuration file locations
config_file="$CW_AGENT_DIR/etc/amazon-cloudwatch-agent.json"
toml_config="$CW_AGENT_DIR/etc/amazon-cloudwatch-agent.toml"

# Check for JSON config (primary)
if [[ -f "$config_file" ]]; then
  register_check "JSON config" PASS "exists"

  # Check permissions
  perms=$(stat -c "%a" "$config_file" 2>/dev/null || echo "unknown")
  owner=$(stat -c "%U:%G" "$config_file" 2>/dev/null || echo "unknown")

  if [[ "${perms: -1}" == "0" ]]; then
    register_check "Config permissions" PASS "$perms $owner"
  else
    register_check "Config permissions" WARN "world-readable ($perms)"
  fi

  # Parse configuration for key settings
  if command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1; then
    python_cmd=$(command -v python3 || command -v python)

    # Check for logs configuration
    has_logs=$($python_cmd -c "import json; c=json.load(open('$config_file')); print('logs' in c)" 2>/dev/null || echo "false")
    if [[ "$has_logs" == "True" ]]; then
      register_check "Logs collection" PASS "configured"
    else
      register_check "Logs collection" WARN "not configured"
    fi

    # Check for metrics configuration
    has_metrics=$($python_cmd -c "import json; c=json.load(open('$config_file')); print('metrics' in c)" 2>/dev/null || echo "false")
    if [[ "$has_metrics" == "True" ]]; then
      register_check "Metrics collection" PASS "configured"
    else
      register_check "Metrics collection" WARN "not configured"
    fi
  else
    # Fallback to grep
    if grep -q '"logs"' "$config_file" 2>/dev/null; then
      register_check "Logs collection" PASS "configured"
    else
      register_check "Logs collection" WARN "not found in config"
    fi

    if grep -q '"metrics"' "$config_file" 2>/dev/null; then
      register_check "Metrics collection" PASS "configured"
    else
      register_check "Metrics collection" WARN "not found in config"
    fi
  fi
else
  register_check "JSON config" WARN "not found"
fi

# Check TOML config (generated/runtime)
if [[ -f "$toml_config" ]]; then
  register_check "TOML config" PASS "exists (runtime config)"
fi

section "Log Group Configuration"

# Check for log groups in config
if [[ -f "$config_file" ]]; then
  # Extract log group names
  log_groups=$(grep -oP '"log_group_name"\s*:\s*"\K[^"]+' "$config_file" 2>/dev/null | sort -u)
  log_count=$(echo "$log_groups" | grep -c "." || echo "0")

  if [[ "$log_count" -gt 0 ]]; then
    register_check "Log groups defined" PASS "$log_count groups"
  else
    register_check "Log groups defined" WARN "none found"
  fi

  # Check for log stream name patterns
  if grep -q "log_stream_name" "$config_file" 2>/dev/null; then
    register_check "Log streams configured" PASS "yes"
  fi
fi

section "Credentials Configuration"

# Check credentials configuration
# CloudWatch Agent should use IAM role (EC2) or shared credentials

# Check for common config
common_config="$CW_AGENT_DIR/etc/common-config.toml"
if [[ -f "$common_config" ]]; then
  register_check "Common config" PASS "exists"

  # Check for credentials configuration
  if grep -q "shared_credential_file" "$common_config" 2>/dev/null; then
    register_check "Credentials source" PASS "shared credentials file"
  elif grep -q "role_arn" "$common_config" 2>/dev/null; then
    register_check "Credentials source" PASS "assume role configured"
  else
    register_check "Credentials source" PASS "using default (IAM role)"
  fi

  # Check proxy configuration
  if grep -q "http_proxy\|https_proxy" "$common_config" 2>/dev/null; then
    register_check "Proxy configured" PASS "yes"
  fi
fi

# Check for instance profile (EC2)
ec2_metadata="http://169.254.169.254/latest"
if timeout 1 curl -s -o /dev/null "$ec2_metadata/meta-data/" 2>/dev/null; then
  iam_role=$(timeout 2 curl -s "$ec2_metadata/meta-data/iam/security-credentials/" 2>/dev/null || echo "")
  if [[ -n "$iam_role" ]] && [[ "$iam_role" != "404"* ]]; then
    register_check "IAM role (EC2)" PASS "$iam_role"
  fi
fi

section "Agent Logs"

# Check agent logs
log_dir="$CW_AGENT_DIR/logs"
if [[ -d "$log_dir" ]]; then
  register_check "Agent log directory" PASS "exists"

  # Check for recent agent log
  if [[ -f "$log_dir/amazon-cloudwatch-agent.log" ]]; then
    # Check log size
    log_size=$(stat -c "%s" "$log_dir/amazon-cloudwatch-agent.log" 2>/dev/null || echo "0")
    log_size_mb=$((log_size / 1024 / 1024))

    if [[ "$log_size_mb" -gt 100 ]]; then
      register_check "Agent log size" WARN "${log_size_mb}MB (consider rotation)"
    else
      register_check "Agent log size" PASS "${log_size_mb}MB"
    fi

    # Check for recent errors
    error_count=$(grep -c "ERROR\|WARN" "$log_dir/amazon-cloudwatch-agent.log" 2>/dev/null | tail -1 || echo "0")
    if [[ "$error_count" -gt 100 ]]; then
      register_check "Recent errors/warnings" WARN "$error_count entries"
    else
      register_check "Recent errors/warnings" PASS "$error_count entries"
    fi
  fi
fi

section "State Files"

# Check state directory
state_dir="/opt/aws/amazon-cloudwatch-agent/var"
if [[ -d "$state_dir" ]]; then
  register_check "State directory" PASS "exists"

  # Check permissions
  perms=$(stat -c "%a" "$state_dir" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "755" ]] || [[ "$perms" == "750" ]]; then
    register_check "State dir permissions" PASS "$perms"
  else
    register_check "State dir permissions" WARN "$perms"
  fi
fi

section "Monitored Log Files"

# Check if configured log files exist
if [[ -f "$config_file" ]]; then
  log_files=$(grep -oP '"file_path"\s*:\s*"\K[^"]+' "$config_file" 2>/dev/null | sort -u)

  missing=0
  found=0
  for log_file in $log_files; do
    # Handle glob patterns
    if [[ "$log_file" == *"*"* ]]; then
      if ls $log_file >/dev/null 2>&1; then
        ((found++)) || true
      else
        ((missing++)) || true
      fi
    elif [[ -f "$log_file" ]]; then
      ((found++)) || true
    else
      ((missing++)) || true
    fi
  done

  if [[ "$missing" -gt 0 ]]; then
    register_check "Monitored log files" WARN "$found found, $missing missing"
  elif [[ "$found" -gt 0 ]]; then
    register_check "Monitored log files" PASS "$found files"
  fi
fi

section "Process Check"

# Verify agent processes
agent_procs=$(pgrep -f "amazon-cloudwatch-agent" 2>/dev/null | wc -l || echo "0")
if [[ "$agent_procs" -gt 0 ]]; then
  register_check "Agent processes" PASS "$agent_procs running"
else
  register_check "Agent processes" FAIL "no processes found"
fi

print_summary
exit "$EXIT_CODE"
