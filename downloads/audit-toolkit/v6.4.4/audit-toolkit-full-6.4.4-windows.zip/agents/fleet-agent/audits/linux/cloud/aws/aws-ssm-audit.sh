#!/usr/bin/env bash
# aws-ssm-audit.sh — AWS Systems Manager Agent Security Audit
#
# Compliance Mapping:
# - AWS Well-Architected (Operational Excellence): OPS 06
# - AWS Security Best Practices
# - CIS AWS Foundations Benchmark
#
# Checks:
# - SSM Agent installation and version
# - Service status
# - Instance registration
# - Hybrid activation (for on-premises)
# - IAM instance profile (EC2)
# - Configuration validation
#
# @elevation: partial
# @elevation-reason: Reads SSM agent config and registration files which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "AWS Systems Manager Agent Audit"

# Check if SSM Agent is installed
SSM_AGENT=""
for agent in amazon-ssm-agent snap.amazon-ssm-agent; do
  if command -v "$agent" >/dev/null 2>&1 || systemctl list-unit-files 2>/dev/null | grep -q "$agent"; then
    SSM_AGENT="$agent"
    break
  fi
done

# Alternative check via package
if [[ -z "$SSM_AGENT" ]]; then
  if [[ -f "/usr/bin/amazon-ssm-agent" ]] || [[ -f "/snap/amazon-ssm-agent/current/amazon-ssm-agent" ]]; then
    SSM_AGENT="amazon-ssm-agent"
  fi
fi

if [[ -z "$SSM_AGENT" ]]; then
  register_check "SSM Agent installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "SSM Agent installed" PASS "found"

section "SSM Agent Service Status"

# Check service status (handle both systemd and snap variants)
ssm_service=""
for svc in amazon-ssm-agent snap.amazon-ssm-agent.amazon-ssm-agent; do
  if systemctl list-unit-files 2>/dev/null | grep -q "^${svc}"; then
    ssm_service="$svc"
    break
  fi
done

if [[ -n "$ssm_service" ]]; then
  if systemctl is-active "$ssm_service" >/dev/null 2>&1; then
    register_check "Service running" PASS "$ssm_service active"
  else
    register_check "Service running" FAIL "$ssm_service inactive"
  fi

  if systemctl is-enabled "$ssm_service" >/dev/null 2>&1; then
    register_check "Service enabled" PASS "starts on boot"
  else
    register_check "Service enabled" WARN "not enabled"
  fi
else
  register_check "Service status" WARN "could not determine service name"
fi

section "SSM Agent Version"

# Get agent version
version=""
if [[ -f "/usr/bin/amazon-ssm-agent" ]]; then
  version=$(/usr/bin/amazon-ssm-agent --version 2>/dev/null || echo "")
elif [[ -f "/snap/amazon-ssm-agent/current/amazon-ssm-agent" ]]; then
  version=$(/snap/amazon-ssm-agent/current/amazon-ssm-agent --version 2>/dev/null || echo "")
fi

if [[ -n "$version" ]]; then
  # Extract version number
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" | head -1)
  if [[ -n "$ver_num" ]]; then
    # Check if version is reasonably recent (3.x is current as of 2024)
    major=$(echo "$ver_num" | cut -d. -f1)
    if [[ "$major" -ge 3 ]]; then
      register_check "Agent version" PASS "$ver_num"
    else
      register_check "Agent version" WARN "$ver_num (consider upgrading)"
    fi
  else
    register_check "Agent version" PASS "$version"
  fi
else
  register_check "Agent version" WARN "could not determine"
fi

section "Instance Registration"

# Check registration file
reg_file="/var/lib/amazon/ssm/registration"
if [[ -f "$reg_file" ]]; then
  register_check "Registration file" PASS "exists"

  # Check file permissions (should be restricted)
  perms=$(stat -c "%a" "$reg_file" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
    register_check "Registration permissions" PASS "$perms"
  else
    register_check "Registration permissions" WARN "$perms (should be 600)"
  fi
else
  register_check "Registration file" WARN "not found"
fi

# Check for Vault directory (used with hybrid activations)
vault_dir="/var/lib/amazon/ssm/Vault"
if [[ -d "$vault_dir" ]]; then
  register_check "Vault directory" PASS "exists"
else
  register_check "Vault directory" WARN "not found (OK for EC2, needed for hybrid)"
fi

section "Hybrid Activation"

# Check for hybrid activation (on-premises servers)
activation_file="/var/lib/amazon/ssm/i-*"
if ls $activation_file >/dev/null 2>&1; then
  # Instance ID pattern indicates registration
  instance_id=$(ls -d /var/lib/amazon/ssm/i-* 2>/dev/null | head -1 | xargs basename)
  if [[ "$instance_id" =~ ^mi- ]]; then
    register_check "Registration type" PASS "hybrid (managed instance: $instance_id)"
  elif [[ "$instance_id" =~ ^i- ]]; then
    register_check "Registration type" PASS "EC2 ($instance_id)"
  fi
fi

# Check for activation credentials
if [[ -f "/var/lib/amazon/ssm/Vault/Store/RegistrationKey" ]]; then
  register_check "Activation key" PASS "stored in vault"
fi

section "EC2 Instance Profile"

# Check if running on EC2 and has instance profile
ec2_metadata="http://169.254.169.254/latest"
is_ec2=false

# Try to detect if this is EC2 (timeout quickly if not)
if timeout 1 curl -s -o /dev/null -w "%{http_code}" "$ec2_metadata/meta-data/" 2>/dev/null | grep -q "200"; then
  is_ec2=true
  register_check "Running on EC2" PASS "yes"

  # Check for instance profile
  iam_role=$(timeout 2 curl -s "$ec2_metadata/meta-data/iam/security-credentials/" 2>/dev/null || echo "")
  if [[ -n "$iam_role" ]] && [[ "$iam_role" != "404"* ]]; then
    register_check "IAM instance profile" PASS "$iam_role"
  else
    register_check "IAM instance profile" WARN "not attached"
  fi

  # Get instance ID from metadata
  instance_id=$(timeout 2 curl -s "$ec2_metadata/meta-data/instance-id" 2>/dev/null || echo "")
  if [[ -n "$instance_id" ]]; then
    register_check "EC2 Instance ID" PASS "$instance_id"
  fi

  # Check region
  az=$(timeout 2 curl -s "$ec2_metadata/meta-data/placement/availability-zone" 2>/dev/null || echo "")
  if [[ -n "$az" ]]; then
    region="${az%[a-z]}"
    register_check "AWS Region" PASS "$region ($az)"
  fi
else
  register_check "Running on EC2" SKIP "metadata not available"
fi

section "SSM Agent Configuration"

# Check configuration files
config_locations=(
  "/etc/amazon/ssm/seelog.xml"
  "/etc/amazon/ssm/amazon-ssm-agent.json"
)

for config in "${config_locations[@]}"; do
  if [[ -f "$config" ]]; then
    perms=$(stat -c "%a" "$config" 2>/dev/null || echo "unknown")
    if [[ "${perms: -1}" == "0" ]] || [[ "${perms: -1}" == "4" ]]; then
      register_check "$(basename "$config")" PASS "exists ($perms)"
    else
      register_check "$(basename "$config")" WARN "world-accessible ($perms)"
    fi
  fi
done

# Check log configuration
if [[ -f "/etc/amazon/ssm/seelog.xml" ]]; then
  log_level=$(grep -oP 'minlevel="\K[^"]+' /etc/amazon/ssm/seelog.xml 2>/dev/null | head -1)
  if [[ -n "$log_level" ]]; then
    if [[ "$log_level" == "debug" ]]; then
      register_check "Log level" WARN "debug (verbose logging)"
    else
      register_check "Log level" PASS "$log_level"
    fi
  fi
fi

section "SSM Agent Logs"

# Check log directory
log_dir="/var/log/amazon/ssm"
if [[ -d "$log_dir" ]]; then
  register_check "Log directory" PASS "exists"

  # Check for recent errors
  if [[ -f "$log_dir/errors.log" ]]; then
    error_count=$(wc -l < "$log_dir/errors.log" 2>/dev/null || echo "0")
    if [[ "$error_count" -gt 100 ]]; then
      register_check "Error log" WARN "$error_count lines"
    else
      register_check "Error log" PASS "$error_count lines"
    fi
  fi

  # Check log permissions
  log_perms=$(stat -c "%a" "$log_dir" 2>/dev/null || echo "unknown")
  if [[ "$log_perms" == "750" ]] || [[ "$log_perms" == "755" ]]; then
    register_check "Log dir permissions" PASS "$log_perms"
  else
    register_check "Log dir permissions" WARN "$log_perms"
  fi
else
  register_check "Log directory" WARN "not found"
fi

section "Document/Session Worker"

# Check for session worker (SSM Session Manager)
if pgrep -f "ssm-session-worker" >/dev/null 2>&1; then
  register_check "Session worker" PASS "process running"
fi

# Check for document worker
if pgrep -f "ssm-document-worker" >/dev/null 2>&1; then
  register_check "Document worker" PASS "process running"
fi

section "Network Connectivity"

# Check if endpoints are reachable (region-specific)
# Note: This requires network access, skip if blocked
if command -v curl >/dev/null 2>&1; then
  # Try to detect region
  region=""
  if [[ -f "/var/lib/amazon/ssm/ipcTempCredentials" ]]; then
    region=$(grep -oP '"region"\s*:\s*"\K[^"]+' /var/lib/amazon/ssm/ipcTempCredentials 2>/dev/null || echo "")
  fi

  if [[ -z "$region" ]] && $is_ec2; then
    az=$(timeout 2 curl -s "$ec2_metadata/meta-data/placement/availability-zone" 2>/dev/null || echo "")
    region="${az%[a-z]}"
  fi

  if [[ -n "$region" ]]; then
    ssm_endpoint="ssm.$region.amazonaws.com"
    if timeout 3 curl -s -o /dev/null "https://$ssm_endpoint" 2>/dev/null; then
      register_check "SSM endpoint" PASS "reachable ($ssm_endpoint)"
    else
      register_check "SSM endpoint" WARN "not reachable"
    fi
  else
    register_check "SSM endpoint" SKIP "region not detected"
  fi
fi

print_summary
exit "$EXIT_CODE"
