# Azure Cloud Audits

This folder contains audits for Azure services and agents running on Linux systems.

## Planned Audits (from TODO-LINUX-COMMERCIAL-ENHANCEMENTS.md)

| Script | Description | Status |
|--------|-------------|--------|
| `azure-arc-audit.sh` | Azure Arc agent audit - checks azcmagent, connection status, extensions | TODO |
| `azure-guest-agent-audit.sh` | Azure Linux Guest Agent (walinuxagent) audit | TODO |
| `azure-monitor-audit.sh` | Azure Monitor Agent audit | TODO |

## Key Checks for Azure Arc

- `azcmagent` binary installed
- `azcmagent show` connection status
- `himds` service running (Hybrid Instance Metadata Service)
- `gc_linux_service` (Guest Configuration)
- Arc extensions installed
- Managed identity configured
- Certificate validity

## Key Checks for Azure Guest Agent

- `walinuxagent` package installed
- `waagent` service running
- Configuration (`/etc/waagent.conf`)
- Extension handling enabled
- Provisioning status
- Log file permissions

## Usage

```bash
bash audits/linux/cloud/azure/azure-arc-audit.sh
bash audits/linux/cloud/azure/azure-guest-agent-audit.sh
```

## References

- [Azure Arc Agent](https://docs.microsoft.com/en-us/azure/azure-arc/servers/agent-overview)
- [Azure Linux Agent](https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/agent-linux)
