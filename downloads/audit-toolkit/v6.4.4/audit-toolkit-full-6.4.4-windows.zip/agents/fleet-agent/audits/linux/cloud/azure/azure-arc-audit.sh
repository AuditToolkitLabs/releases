#!/usr/bin/env bash
# azure-arc-audit.sh — Azure Arc Agent Security Audit
#
# Compliance Mapping:
# - Azure Well-Architected Framework (Security Pillar)
# - Microsoft Cloud Security Benchmark
# - Azure Security Best Practices
#
# Checks:
# - Arc agent (azcmagent) installation
# - Connection status
# - Managed identity
# - Extensions
# - Guest Configuration
# - Service status
#
# @elevation: partial
# @elevation-reason: Reads Azure Arc agent config and certificates which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "Azure Arc Agent Audit"

# Check if azcmagent is installed
if ! command -v azcmagent >/dev/null 2>&1; then
  register_check "Azure Arc Agent installed" SKIP "azcmagent not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Azure Arc Agent installed" PASS "found"

section "Arc Agent Version"

# Get agent version
version=$(azcmagent version 2>/dev/null || echo "")
if [[ -n "$version" ]]; then
  # Extract version number
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" | head -1)
  if [[ -n "$ver_num" ]]; then
    register_check "Agent version" PASS "$ver_num"
  else
    register_check "Agent version" PASS "$version"
  fi
else
  register_check "Agent version" WARN "could not determine"
fi

section "Connection Status"

# Get connection status
status_output=$(azcmagent show 2>/dev/null || echo "")

if [[ -z "$status_output" ]]; then
  register_check "Agent status" FAIL "could not get status (run as root?)"
else
  # Parse connection status
  connection_status=$(echo "$status_output" | grep -i "Agent Status" | awk -F: '{print $2}' | tr -d ' ')

  case "${connection_status,,}" in
    connected)
      register_check "Connection status" PASS "Connected"
      ;;
    disconnected)
      register_check "Connection status" FAIL "Disconnected"
      ;;
    expired)
      register_check "Connection status" FAIL "Certificate expired"
      ;;
    *)
      register_check "Connection status" WARN "$connection_status"
      ;;
  esac

  # Extract subscription and resource group
  subscription=$(echo "$status_output" | grep -i "Subscription ID" | awk -F: '{print $2}' | tr -d ' ')
  if [[ -n "$subscription" ]]; then
    register_check "Azure Subscription" PASS "${subscription:0:36}..."
  fi

  resource_group=$(echo "$status_output" | grep -i "Resource Group" | awk -F: '{print $2}' | tr -d ' ')
  if [[ -n "$resource_group" ]]; then
    register_check "Resource Group" PASS "$resource_group"
  fi

  # Extract region
  region=$(echo "$status_output" | grep -i "Region" | awk -F: '{print $2}' | tr -d ' ')
  if [[ -n "$region" ]]; then
    register_check "Azure Region" PASS "$region"
  fi

  # Extract machine name
  machine_name=$(echo "$status_output" | grep -i "Machine Name" | awk -F: '{print $2}' | tr -d ' ')
  if [[ -n "$machine_name" ]]; then
    register_check "Machine Name" PASS "$machine_name"
  fi
fi

section "Service Status"

# Check himds service (Hybrid Instance Metadata Service)
if systemctl is-active himdsd >/dev/null 2>&1; then
  register_check "HIMDS service" PASS "running"
else
  register_check "HIMDS service" FAIL "not running"
fi

if systemctl is-enabled himdsd >/dev/null 2>&1; then
  register_check "HIMDS enabled" PASS "yes"
else
  register_check "HIMDS enabled" WARN "not enabled"
fi

# Check Guest Configuration service
if systemctl is-active gcad >/dev/null 2>&1 || systemctl is-active gc_linux_service >/dev/null 2>&1; then
  register_check "Guest Config service" PASS "running"
else
  register_check "Guest Config service" WARN "not running"
fi

# Check Extension Manager
if systemctl is-active extd >/dev/null 2>&1; then
  register_check "Extension Manager" PASS "running"
else
  register_check "Extension Manager" WARN "not running"
fi

section "Managed Identity"

# Check managed identity availability
identity_endpoint="http://localhost:40342/metadata/identity/oauth2/token?api-version=2020-06-01"
if command -v curl >/dev/null 2>&1; then
  if timeout 3 curl -s -o /dev/null -w "%{http_code}" -H "Metadata: true" "$identity_endpoint" 2>/dev/null | grep -qE "200|401|400"; then
    register_check "Managed Identity endpoint" PASS "available"
  else
    register_check "Managed Identity endpoint" WARN "not responding"
  fi
fi

section "Extensions"

# List installed extensions
if azcmagent extension list >/dev/null 2>&1; then
  ext_output=$(azcmagent extension list 2>/dev/null)
  ext_count=$(echo "$ext_output" | grep -c "Name:" || echo "0")

  if [[ "$ext_count" -gt 0 ]]; then
    register_check "Installed extensions" PASS "$ext_count extensions"

    # Check for common security extensions
    if echo "$ext_output" | grep -qi "MicrosoftDefender\|AzureSecurityPack"; then
      register_check "Defender extension" PASS "installed"
    fi

    if echo "$ext_output" | grep -qi "Log Analytics\|OmsAgent\|AzureMonitor"; then
      register_check "Monitoring extension" PASS "installed"
    fi

    if echo "$ext_output" | grep -qi "GuestConfiguration\|AzurePolicy"; then
      register_check "Guest Configuration ext" PASS "installed"
    fi
  else
    register_check "Installed extensions" WARN "none"
  fi
else
  register_check "Extensions" SKIP "could not list"
fi

section "Network Connectivity"

# Check connectivity to Azure endpoints
if command -v azcmagent >/dev/null 2>&1; then
  # Try connectivity check (may require root)
  if timeout 30 azcmagent check 2>/dev/null | grep -qi "succeeded\|passed"; then
    register_check "Azure connectivity" PASS "endpoints reachable"
  else
    register_check "Azure connectivity" WARN "check failed or timeout"
  fi
fi

section "Certificate Status"

# Check certificate expiration
if [[ -n "$status_output" ]]; then
  cert_expiry=$(echo "$status_output" | grep -i "Certificate Expiration" | awk -F: '{print $2}' | tr -d ' ')
  if [[ -n "$cert_expiry" ]]; then
    register_check "Certificate expiration" PASS "$cert_expiry"

    # Check if expiring soon (within 30 days)
    if echo "$cert_expiry" | grep -qiE "day|hour|minute"; then
      register_check "Certificate renewal" WARN "expires soon: $cert_expiry"
    fi
  fi
fi

section "Configuration Files"

# Check Arc agent config directory
arc_config_dir="/etc/azcmagent"
if [[ -d "$arc_config_dir" ]]; then
  register_check "Config directory" PASS "exists"

  # Check permissions
  perms=$(stat -c "%a" "$arc_config_dir" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "755" ]] || [[ "$perms" == "700" ]]; then
    register_check "Config dir permissions" PASS "$perms"
  else
    register_check "Config dir permissions" WARN "$perms"
  fi
fi

# Check for local config
local_config="$arc_config_dir/local.properties"
if [[ -f "$local_config" ]]; then
  perms=$(stat -c "%a" "$local_config" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" == "0" ]]; then
    register_check "Local config" PASS "exists ($perms)"
  else
    register_check "Local config" WARN "world-readable ($perms)"
  fi
fi

section "Agent State"

# Check agent state directory
state_dir="/var/lib/waagent"
if [[ -d "$state_dir" ]]; then
  register_check "State directory" PASS "exists"

  # Check for goal state
  if [[ -f "$state_dir/GoalState.xml" ]] || [[ -f "$state_dir/GoalState.*.xml" ]]; then
    register_check "Goal state" PASS "present"
  fi
fi

# Arc specific state
arc_state="/var/lib/GuestConfig"
if [[ -d "$arc_state" ]]; then
  register_check "Guest Config state" PASS "exists"
fi

section "Process Check"

# Verify key processes
processes=(
  "himds:Hybrid Instance Metadata"
  "gcad:Guest Configuration Agent"
  "extd:Extension Manager"
)

for entry in "${processes[@]}"; do
  proc="${entry%%:*}"
  desc="${entry##*:}"

  if pgrep -f "$proc" >/dev/null 2>&1; then
    register_check "Process: $desc" PASS "running"
  else
    register_check "Process: $desc" WARN "not running"
  fi
done

section "Security Configuration"

# Check if agent is running as non-root (where applicable)
agent_user=$(ps -eo user,cmd 2>/dev/null | grep -E "himds|azcmagent" | head -1 | awk '{print $1}')
if [[ -n "$agent_user" ]]; then
  if [[ "$agent_user" == "root" ]]; then
    register_check "Agent user" PASS "root (required)"
  else
    register_check "Agent user" PASS "$agent_user"
  fi
fi

# Check for proxy configuration
if [[ -f "/etc/azcmagent/proxy.conf" ]]; then
  register_check "Proxy configured" PASS "yes"
fi

print_summary
exit "$EXIT_CODE"
