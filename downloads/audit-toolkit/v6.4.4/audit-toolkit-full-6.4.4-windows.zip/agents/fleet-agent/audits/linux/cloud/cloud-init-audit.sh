#!/usr/bin/env bash
# cloud-init-audit.sh — Cloud-Init Security Audit
#
# Compliance Mapping:
# - Cloud Security Alliance Guidelines
# - CIS Cloud Provider Benchmarks
# - General Cloud Security Best Practices
#
# Checks:
# - Cloud-init installation and version
# - Status and errors
# - Datasource validation
# - User-data security
# - Credentials handling
#
# @elevation: partial
# @elevation-reason: Reads cloud-init config files which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../lib/common.sh"

setup_colors

section "Cloud-Init Audit"

# Check if cloud-init is installed
if ! command -v cloud-init >/dev/null 2>&1; then
  register_check "Cloud-init installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Cloud-init installed" PASS "found"

section "Cloud-Init Version"

# Get version
version=$(cloud-init --version 2>&1 | head -1 || echo "")
if [[ -n "$version" ]]; then
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+(\.[0-9]+)?" || echo "$version")
  register_check "Version" PASS "$ver_num"
fi

section "Cloud-Init Status"

# Get detailed status
status_output=$(cloud-init status --long 2>/dev/null || cloud-init status 2>/dev/null || echo "")

if [[ -n "$status_output" ]]; then
  # Parse status
  status_value=$(echo "$status_output" | grep -i "^status:" | awk '{print $2}' || echo "")

  case "${status_value,,}" in
    done)
      register_check "Status" PASS "done"
      ;;
    running)
      register_check "Status" WARN "still running"
      ;;
    error|errors)
      register_check "Status" FAIL "errors occurred"
      ;;
    disabled)
      register_check "Status" WARN "disabled"
      ;;
    *)
      # Try simpler status check
      simple_status=$(cloud-init status 2>/dev/null | head -1)
      if echo "$simple_status" | grep -qi "done"; then
        register_check "Status" PASS "done"
      elif echo "$simple_status" | grep -qi "error"; then
        register_check "Status" FAIL "errors"
      else
        register_check "Status" WARN "$simple_status"
      fi
      ;;
  esac

  # Check for boot time
  boot_time=$(echo "$status_output" | grep -i "boot_status_code\|time:" | head -1 || echo "")
  if [[ -n "$boot_time" ]]; then
    register_check "Boot info" PASS "$boot_time"
  fi
fi

section "Cloud-Init Stages"

# Check individual stages
stages=("init" "config" "final")
for stage in "${stages[@]}"; do
  log_file="/var/log/cloud-init-$stage.log"
  if [[ -f "$log_file" ]]; then
    if grep -qi "error\|traceback\|failed" "$log_file" 2>/dev/null; then
      error_count=$(grep -ci "error\|traceback" "$log_file" 2>/dev/null || echo "0")
      register_check "Stage: $stage" WARN "$error_count errors"
    else
      register_check "Stage: $stage" PASS "completed"
    fi
  fi
done

section "Datasource"

# Get datasource information
datasource=$(cloud-init query ds 2>/dev/null || echo "")
if [[ -n "$datasource" ]]; then
  register_check "Datasource" PASS "$datasource"
else
  # Try alternative method
  datasource=$(grep -i "datasource" /var/log/cloud-init.log 2>/dev/null | head -1 | grep -oP "DataSource\w+" | head -1 || echo "")
  if [[ -n "$datasource" ]]; then
    register_check "Datasource" PASS "$datasource"
  else
    register_check "Datasource" WARN "could not determine"
  fi
fi

# Check datasource list (configured)
if [[ -f "/etc/cloud/cloud.cfg" ]]; then
  ds_list=$(grep -A5 "datasource_list" /etc/cloud/cloud.cfg 2>/dev/null | head -6 || echo "")
  if [[ -n "$ds_list" ]]; then
    register_check "Datasource config" PASS "configured"
  fi
fi

section "User-Data Security"

# Check user-data permissions
userdata_locations=(
  "/var/lib/cloud/instance/user-data.txt"
  "/var/lib/cloud/instance/user-data.txt.i"
  "/var/lib/cloud/instances/*/user-data.txt"
)

for pattern in "${userdata_locations[@]}"; do
  for file in $pattern; do
    if [[ -f "$file" ]]; then
      perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")
      owner=$(stat -c "%U:%G" "$file" 2>/dev/null || echo "unknown")

      # User-data should NOT be world-readable (may contain secrets)
      if [[ "${perms: -1}" == "0" ]]; then
        register_check "User-data perms" PASS "$perms"
      else
        register_check "User-data perms" WARN "world-readable ($perms)"
      fi

      # Check if user-data contains potential secrets
      if grep -qiE "password|secret|key|token|credential" "$file" 2>/dev/null; then
        register_check "User-data secrets" WARN "may contain sensitive data"
      else
        register_check "User-data secrets" PASS "no obvious secrets"
      fi

      break 2
    fi
  done
done

# Check for scripts in user-data that run as root
scripts_dir="/var/lib/cloud/instance/scripts"
if [[ -d "$scripts_dir" ]]; then
  script_count=$(find "$scripts_dir" -type f -executable 2>/dev/null | wc -l || echo "0")
  if [[ "$script_count" -gt 0 ]]; then
    register_check "Executable scripts" WARN "$script_count scripts (run as root)"
  else
    register_check "Executable scripts" PASS "none"
  fi

  # Check script permissions
  world_exec=$(find "$scripts_dir" -type f -perm -o+x 2>/dev/null | wc -l || echo "0")
  if [[ "$world_exec" -gt 0 ]]; then
    register_check "World-executable scripts" WARN "$world_exec files"
  fi
fi

section "Sensitive Data Handling"

# Check vendor-data
vendor_data="/var/lib/cloud/instance/vendor-data.txt"
if [[ -f "$vendor_data" ]]; then
  perms=$(stat -c "%a" "$vendor_data" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" == "0" ]]; then
    register_check "Vendor-data perms" PASS "$perms"
  else
    register_check "Vendor-data perms" WARN "world-readable ($perms)"
  fi
fi

# Check for sensitive data in cloud-init output
output_log="/var/log/cloud-init-output.log"
if [[ -f "$output_log" ]]; then
  if grep -qiE "password|secret|private.key|BEGIN.*PRIVATE" "$output_log" 2>/dev/null; then
    register_check "Output log secrets" WARN "may contain sensitive data"
  else
    register_check "Output log secrets" PASS "no obvious secrets"
  fi

  # Check permissions on output log
  perms=$(stat -c "%a" "$output_log" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" -le 4 ]]; then
    register_check "Output log perms" PASS "$perms"
  else
    register_check "Output log perms" WARN "world-readable ($perms)"
  fi
fi

section "Configuration"

# Check main config
main_config="/etc/cloud/cloud.cfg"
if [[ -f "$main_config" ]]; then
  register_check "Main config" PASS "exists"

  perms=$(stat -c "%a" "$main_config" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "644" ]] || [[ "$perms" == "600" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi

  # Check for security-relevant settings
  if grep -q "disable_root:" "$main_config" 2>/dev/null; then
    disable_root=$(grep "disable_root:" "$main_config" | awk '{print $2}')
    if [[ "${disable_root,,}" == "true" ]]; then
      register_check "Root disabled" PASS "yes"
    else
      register_check "Root disabled" WARN "no"
    fi
  fi

  if grep -q "ssh_pwauth:" "$main_config" 2>/dev/null; then
    ssh_pwauth=$(grep "ssh_pwauth:" "$main_config" | awk '{print $2}')
    if [[ "${ssh_pwauth,,}" == "false" ]] || [[ "${ssh_pwauth,,}" == "no" ]]; then
      register_check "SSH password auth" PASS "disabled"
    else
      register_check "SSH password auth" WARN "enabled"
    fi
  fi
fi

# Check cloud.cfg.d directory
cfg_d="/etc/cloud/cloud.cfg.d"
if [[ -d "$cfg_d" ]]; then
  cfg_count=$(find "$cfg_d" -name "*.cfg" -type f 2>/dev/null | wc -l || echo "0")
  register_check "Config.d files" PASS "$cfg_count files"
fi

section "Cloud-Init Logs"

# Check main log
main_log="/var/log/cloud-init.log"
if [[ -f "$main_log" ]]; then
  # Count errors
  error_count=$(grep -ci "error\|warning\|traceback" "$main_log" 2>/dev/null || echo "0")
  if [[ "$error_count" -gt 50 ]]; then
    register_check "Log errors/warnings" WARN "$error_count entries"
  else
    register_check "Log errors/warnings" PASS "$error_count entries"
  fi

  # Check log permissions
  perms=$(stat -c "%a" "$main_log" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" -le 4 ]]; then
    register_check "Log permissions" PASS "$perms"
  else
    register_check "Log permissions" WARN "world-readable ($perms)"
  fi
fi

section "Instance Data"

# Check instance identity data
instance_data="/run/cloud-init/instance-data.json"
if [[ -f "$instance_data" ]]; then
  perms=$(stat -c "%a" "$instance_data" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" == "0" ]]; then
    register_check "Instance data perms" PASS "$perms"
  else
    register_check "Instance data perms" WARN "world-readable ($perms)"
  fi
fi

# Check sensitive instance data
sensitive_data="/run/cloud-init/instance-data-sensitive.json"
if [[ -f "$sensitive_data" ]]; then
  perms=$(stat -c "%a" "$sensitive_data" 2>/dev/null || echo "unknown")
  if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
    register_check "Sensitive data perms" PASS "$perms"
  else
    register_check "Sensitive data perms" FAIL "too permissive ($perms)"
  fi
fi

section "Network Configuration"

# Check if cloud-init manages network
netplan_cfg="/etc/netplan/50-cloud-init.yaml"
if [[ -f "$netplan_cfg" ]]; then
  register_check "Network: Netplan" PASS "managed"
fi

network_cfg="/etc/network/interfaces.d/50-cloud-init.cfg"
if [[ -f "$network_cfg" ]]; then
  register_check "Network: interfaces" PASS "managed"
fi

print_summary
exit "$EXIT_CODE"
