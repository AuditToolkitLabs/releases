# GCP Cloud Audits

This folder contains audits for Google Cloud Platform services and agents running on Linux systems.

## Planned Audits (from TODO-LINUX-COMMERCIAL-ENHANCEMENTS.md)

| Script | Description | Status |
|--------|-------------|--------|
| `gcp-guest-agent-audit.sh` | Google Guest Agent audit - checks agent status, metadata access | TODO |
| `gcp-ops-agent-audit.sh` | Google Cloud Ops Agent (unified logging/monitoring) audit | TODO |
| `gcp-osconfig-audit.sh` | OS Config agent audit for patch management | TODO |

## Key Checks for GCP Guest Agent

- `google-guest-agent` package installed
- `google-guest-agent` service running
- `google-compute-engine` package status
- Metadata server accessibility
- Instance identity configuration
- SSH key management settings

## Key Checks for Ops Agent

- `google-cloud-ops-agent` installed
- Service running
- Configuration (`/etc/google-cloud-ops-agent/config.yaml`)
- Log collection configured
- Metrics collection active
- Credentials/service account

## Usage

```bash
bash audits/linux/cloud/gcp/gcp-guest-agent-audit.sh
bash audits/linux/cloud/gcp/gcp-ops-agent-audit.sh
```

## References

- [GCP Guest Agent](https://cloud.google.com/compute/docs/images/guest-agents)
- [Ops Agent](https://cloud.google.com/stackdriver/docs/solutions/agents/ops-agent)
