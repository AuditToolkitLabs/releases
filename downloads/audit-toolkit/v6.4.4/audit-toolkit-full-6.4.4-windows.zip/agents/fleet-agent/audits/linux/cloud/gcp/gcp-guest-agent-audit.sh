#!/usr/bin/env bash
# gcp-guest-agent-audit.sh — GCP Guest Agent Security Audit
#
# Compliance Mapping:
# - Google Cloud Security Best Practices
# - CIS Google Cloud Platform Foundation Benchmark
# - GCP Well-Architected Framework
#
# Checks:
# - Guest agent installation and version
# - Service status
# - Metadata server connectivity
# - OS Login configuration
# - OS Config agent
# - SSH key management
#
# @elevation: partial
# @elevation-reason: Reads GCP guest agent config files which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "GCP Guest Agent Audit"

# Check if running on GCP
GCP_METADATA="http://metadata.google.internal/computeMetadata/v1"
is_gcp=false

if command -v curl >/dev/null 2>&1; then
  if timeout 2 curl -s -o /dev/null -H "Metadata-Flavor: Google" "$GCP_METADATA/" 2>/dev/null; then
    is_gcp=true
    register_check "Running on GCP" PASS "yes"
  else
    register_check "Running on GCP" SKIP "metadata not available"
  fi
fi

# Check if google-guest-agent is installed
GUEST_AGENT=""
if command -v google_guest_agent >/dev/null 2>&1; then
  GUEST_AGENT="google_guest_agent"
elif [[ -f "/usr/bin/google_guest_agent" ]]; then
  GUEST_AGENT="/usr/bin/google_guest_agent"
fi

if [[ -z "$GUEST_AGENT" ]] && ! systemctl list-unit-files 2>/dev/null | grep -q "google-guest-agent"; then
  if ! $is_gcp; then
    register_check "GCP Guest Agent" SKIP "not on GCP"
    print_summary
    exit "$EXIT_CODE"
  fi
  register_check "GCP Guest Agent installed" WARN "not found"
else
  register_check "GCP Guest Agent installed" PASS "found"
fi

section "Guest Agent Service Status"

# Check google-guest-agent service
if systemctl is-active google-guest-agent >/dev/null 2>&1; then
  register_check "Guest Agent service" PASS "running"
else
  register_check "Guest Agent service" FAIL "not running"
fi

if systemctl is-enabled google-guest-agent >/dev/null 2>&1; then
  register_check "Guest Agent enabled" PASS "yes"
else
  register_check "Guest Agent enabled" WARN "not enabled"
fi

section "Guest Agent Version"

# Get agent version
if [[ -n "$GUEST_AGENT" ]]; then
  version=$("$GUEST_AGENT" --version 2>/dev/null || echo "")
  if [[ -n "$version" ]]; then
    register_check "Agent version" PASS "$version"
  fi
fi

# Alternative: check package version
if command -v dpkg >/dev/null 2>&1; then
  pkg_ver=$(dpkg -l 2>/dev/null | grep google-guest-agent | awk '{print $3}' | head -1)
  if [[ -n "$pkg_ver" ]]; then
    register_check "Package version" PASS "$pkg_ver"
  fi
elif command -v rpm >/dev/null 2>&1; then
  pkg_ver=$(rpm -q google-guest-agent 2>/dev/null | grep -v "not installed")
  if [[ -n "$pkg_ver" ]]; then
    register_check "Package version" PASS "$pkg_ver"
  fi
fi

section "Metadata Server Connectivity"

if $is_gcp && command -v curl >/dev/null 2>&1; then
  # Get instance information
  instance_name=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/name" 2>/dev/null || echo "")
  if [[ -n "$instance_name" ]]; then
    register_check "Instance name" PASS "$instance_name"
  fi

  # Get zone
  zone=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/zone" 2>/dev/null | awk -F/ '{print $NF}' || echo "")
  if [[ -n "$zone" ]]; then
    register_check "Zone" PASS "$zone"
  fi

  # Get project
  project=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/project/project-id" 2>/dev/null || echo "")
  if [[ -n "$project" ]]; then
    register_check "Project ID" PASS "$project"
  fi

  # Check service account
  service_account=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/service-accounts/default/email" 2>/dev/null || echo "")
  if [[ -n "$service_account" ]]; then
    register_check "Service account" PASS "$service_account"
  else
    register_check "Service account" WARN "none attached"
  fi
fi

section "OS Login Configuration"

if $is_gcp && command -v curl >/dev/null 2>&1; then
  # Check if OS Login is enabled
  oslogin_enabled=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/attributes/enable-oslogin" 2>/dev/null || echo "false")

  if [[ "${oslogin_enabled,,}" == "true" ]]; then
    register_check "OS Login enabled" PASS "yes"

    # Check OS Login 2FA
    oslogin_2fa=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/attributes/enable-oslogin-2fa" 2>/dev/null || echo "false")
    if [[ "${oslogin_2fa,,}" == "true" ]]; then
      register_check "OS Login 2FA" PASS "enabled"
    else
      register_check "OS Login 2FA" WARN "not enabled"
    fi
  else
    register_check "OS Login enabled" WARN "not enabled (SSH keys in metadata)"
  fi
fi

# Check OS Login PAM configuration
if [[ -f "/etc/pam.d/sshd" ]]; then
  if grep -q "pam_oslogin" /etc/pam.d/sshd 2>/dev/null; then
    register_check "OS Login PAM" PASS "configured"
  fi
fi

# Check NSS configuration
if [[ -f "/etc/nsswitch.conf" ]]; then
  if grep -q "oslogin" /etc/nsswitch.conf 2>/dev/null; then
    register_check "OS Login NSS" PASS "configured"
  fi
fi

section "OS Config Agent"

# Check google-osconfig-agent (for patch management, policies)
if systemctl is-active google-osconfig-agent >/dev/null 2>&1; then
  register_check "OS Config Agent" PASS "running"
elif systemctl list-unit-files 2>/dev/null | grep -q "google-osconfig-agent"; then
  register_check "OS Config Agent" WARN "installed but not running"
else
  register_check "OS Config Agent" WARN "not installed"
fi

section "Additional Google Services"

# Check google-shutdown-scripts
if systemctl is-active google-shutdown-scripts >/dev/null 2>&1; then
  register_check "Shutdown scripts" PASS "enabled"
fi

# Check google-startup-scripts
if systemctl is-active google-startup-scripts >/dev/null 2>&1; then
  register_check "Startup scripts" PASS "enabled"
fi

# Check google-compute-engine (metadata script runner)
if systemctl is-active google-compute-engine >/dev/null 2>&1 || systemctl is-active google-compute-engine-run-startup-scripts >/dev/null 2>&1; then
  register_check "Compute Engine service" PASS "running"
fi

section "SSH Key Configuration"

if $is_gcp && command -v curl >/dev/null 2>&1; then
  # Check for project-level SSH keys
  project_keys=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/project/attributes/ssh-keys" 2>/dev/null || echo "")
  if [[ -n "$project_keys" ]] && [[ "$project_keys" != *"404"* ]]; then
    key_count=$(echo "$project_keys" | grep -c "ssh-" || echo "0")
    register_check "Project SSH keys" WARN "$key_count keys (consider OS Login)"
  else
    register_check "Project SSH keys" PASS "none (good)"
  fi

  # Check for instance-level SSH keys
  instance_keys=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/attributes/ssh-keys" 2>/dev/null || echo "")
  if [[ -n "$instance_keys" ]] && [[ "$instance_keys" != *"404"* ]]; then
    key_count=$(echo "$instance_keys" | grep -c "ssh-" || echo "0")
    register_check "Instance SSH keys" WARN "$key_count keys"
  else
    register_check "Instance SSH keys" PASS "none"
  fi

  # Check block-project-ssh-keys
  block_keys=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/attributes/block-project-ssh-keys" 2>/dev/null || echo "false")
  if [[ "${block_keys,,}" == "true" ]]; then
    register_check "Block project SSH keys" PASS "yes"
  else
    register_check "Block project SSH keys" WARN "not blocked"
  fi
fi

section "Serial Port Configuration"

if $is_gcp && command -v curl >/dev/null 2>&1; then
  # Check if serial port access is enabled
  serial_enabled=$(timeout 3 curl -s -H "Metadata-Flavor: Google" "$GCP_METADATA/instance/attributes/serial-port-enable" 2>/dev/null || echo "")
  if [[ "${serial_enabled,,}" == "true" ]]; then
    register_check "Serial port access" WARN "enabled (security risk)"
  else
    register_check "Serial port access" PASS "disabled"
  fi
fi

section "Guest Agent Configuration"

# Check configuration file
config_file="/etc/default/instance_configs.cfg"
if [[ -f "$config_file" ]]; then
  register_check "Config file" PASS "exists"

  perms=$(stat -c "%a" "$config_file" 2>/dev/null || echo "unknown")
  if [[ "${perms: -1}" == "0" ]] || [[ "$perms" == "644" ]]; then
    register_check "Config permissions" PASS "$perms"
  else
    register_check "Config permissions" WARN "$perms"
  fi
fi

section "Logs"

# Check guest agent logs
log_file="/var/log/google-guest-agent.log"
if [[ -f "$log_file" ]]; then
  register_check "Agent log" PASS "exists"

  # Check for recent errors
  error_count=$(grep -c "ERROR\|error" "$log_file" 2>/dev/null || echo "0")
  if [[ "$error_count" -gt 50 ]]; then
    register_check "Log errors" WARN "$error_count errors"
  else
    register_check "Log errors" PASS "$error_count errors"
  fi
fi

print_summary
exit "$EXIT_CODE"
