# Oracle Cloud Infrastructure (OCI) Audits

This directory contains security audits for Oracle Cloud Infrastructure guest agents and services.

## Audits

| Script | Description | Compliance |
|--------|-------------|------------|
| `oci-agent-audit.sh` | Oracle Cloud Agent installation, plugins, and configuration | CIS OCI Benchmark, Oracle Security Best Practices |

## OCI Agent Components

The Oracle Cloud Agent runs as a lightweight daemon on compute instances and includes:

- **Compute Instance OCID Verification** - Instance identity
- **Oracle Cloud Agent Daemon** - Main agent service
- **Plugin Management** - OS Management, Monitoring, Compute Instance Run Command
- **Bastion Service Integration** - Secure shell access
- **OS Management** - Patch compliance and management

## Reference Documentation

- [Oracle Cloud Agent Documentation](https://docs.oracle.com/en-us/iaas/Content/Compute/Tasks/manage-plugins.htm)
- [CIS Oracle Cloud Infrastructure Benchmark](https://www.cisecurity.org/benchmark/oracle_cloud)
- [OCI Security Best Practices](https://docs.oracle.com/en-us/iaas/Content/Security/Concepts/security_overview.htm)
