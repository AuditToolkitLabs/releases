#!/usr/bin/env bash
# oci-agent-audit.sh — Oracle Cloud Infrastructure Agent Security Audit
#
# Compliance Mapping:
# - CIS Oracle Cloud Infrastructure Benchmark
# - Oracle Security Best Practices
# - OCI Well-Architected Framework
#
# Checks:
# - Oracle Cloud Agent installation and version
# - Service status (oracle-cloud-agent, oracle-cloud-agent-updater)
# - Agent plugins (OS Management, Monitoring, etc.)
# - Metadata service connectivity
# - Instance OCID verification
# - Bastion service integration
# - OS Management configuration
#
# @elevation: partial
# @elevation-reason: Reads OCI agent config and plugin files which may be root-owned
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"

setup_colors

section "Oracle Cloud Infrastructure Agent Audit"

# ============================================================================
# OCI ENVIRONMENT DETECTION
# ============================================================================

OCI_METADATA="http://169.254.169.254/opc/v2"
is_oci=false

if command -v curl >/dev/null 2>&1; then
  # OCI uses Authorization header for v2 metadata
  if timeout 2 curl -s -o /dev/null -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/" 2>/dev/null; then
    is_oci=true
    register_check "Running on OCI" PASS "yes"
  else
    # Try v1 metadata (no auth required)
    if timeout 2 curl -s -o /dev/null "http://169.254.169.254/opc/v1/instance/" 2>/dev/null; then
      is_oci=true
      register_check "Running on OCI" PASS "yes (v1 metadata)"
    else
      register_check "Running on OCI" SKIP "metadata not available"
    fi
  fi
fi

# ============================================================================
# ORACLE CLOUD AGENT INSTALLATION
# ============================================================================

section "Oracle Cloud Agent Installation"

# Check if Oracle Cloud Agent is installed
OCI_AGENT=""
if [[ -f "/usr/libexec/oracle-cloud-agent/agent" ]]; then
  OCI_AGENT="/usr/libexec/oracle-cloud-agent/agent"
elif [[ -f "/usr/bin/oracle-cloud-agent" ]]; then
  OCI_AGENT="/usr/bin/oracle-cloud-agent"
fi

# Also check via systemd
oci_agent_found=false
if systemctl list-unit-files 2>/dev/null | grep -q "oracle-cloud-agent"; then
  oci_agent_found=true
fi

if [[ -z "$OCI_AGENT" ]] && ! $oci_agent_found; then
  if ! $is_oci; then
    register_check "OCI Agent" SKIP "not on OCI"
    print_summary
    exit "$EXIT_CODE"
  fi
  register_check "OCI Agent installed" WARN "not found"
else
  register_check "OCI Agent installed" PASS "found"
fi

# ============================================================================
# SERVICE STATUS
# ============================================================================

section "Agent Service Status"

# Check oracle-cloud-agent service
if systemctl is-active oracle-cloud-agent >/dev/null 2>&1; then
  register_check "Oracle Cloud Agent service" PASS "running"
else
  if $is_oci || $oci_agent_found; then
    register_check "Oracle Cloud Agent service" FAIL "not running"
  else
    register_check "Oracle Cloud Agent service" SKIP "not installed"
  fi
fi

if systemctl is-enabled oracle-cloud-agent >/dev/null 2>&1; then
  register_check "Oracle Cloud Agent enabled" PASS "yes"
else
  if $is_oci || $oci_agent_found; then
    register_check "Oracle Cloud Agent enabled" WARN "not enabled"
  fi
fi

# Check oracle-cloud-agent-updater (auto-updates the agent)
if systemctl is-active oracle-cloud-agent-updater >/dev/null 2>&1; then
  register_check "Agent Updater service" PASS "running"
elif systemctl list-unit-files 2>/dev/null | grep -q "oracle-cloud-agent-updater"; then
  register_check "Agent Updater service" WARN "installed but not running"
fi

if systemctl is-enabled oracle-cloud-agent-updater >/dev/null 2>&1; then
  register_check "Agent Updater enabled" PASS "yes"
fi

# ============================================================================
# AGENT VERSION
# ============================================================================

section "Agent Version"

# Get agent version from package
version=""
if command -v rpm >/dev/null 2>&1; then
  version=$(rpm -q oracle-cloud-agent 2>/dev/null | grep -v "not installed" || echo "")
elif command -v dpkg >/dev/null 2>&1; then
  version=$(dpkg -l 2>/dev/null | grep oracle-cloud-agent | awk '{print $3}' | head -1)
fi

if [[ -n "$version" ]]; then
  # Extract version number
  ver_num=$(echo "$version" | grep -oE "[0-9]+\.[0-9]+\.[0-9]+" | head -1)
  if [[ -n "$ver_num" ]]; then
    # Current major version is 1.x as of 2026
    major=$(echo "$ver_num" | cut -d. -f1)
    minor=$(echo "$ver_num" | cut -d. -f2)
    if [[ "$major" -ge 1 ]] && [[ "$minor" -ge 30 ]]; then
      register_check "Agent version" PASS "$ver_num (current)"
    else
      register_check "Agent version" WARN "$ver_num (consider updating)"
    fi
  else
    register_check "Agent version" PASS "$version"
  fi
fi

# ============================================================================
# AGENT PLUGINS
# ============================================================================

section "Agent Plugins"

# List plugin status from config if available
PLUGIN_CONFIG="/etc/oracle-cloud-agent/plugins.json"
if [[ -f "$PLUGIN_CONFIG" ]]; then
  # Check key plugins
  for plugin in "OS Management Service Agent" "Compute Instance Monitoring" "Custom Logs Monitoring" "Compute Instance Run Command"; do
    if grep -q "\"$plugin\"" "$PLUGIN_CONFIG"; then
      if grep -A2 "\"$plugin\"" "$PLUGIN_CONFIG" | grep -q '"disabled"\s*:\s*false'; then
        register_check "Plugin: $plugin" PASS "enabled"
      else
        register_check "Plugin: $plugin" INFO "disabled"
      fi
    fi
  done
else
  register_check "Plugin configuration" INFO "plugins.json not found"
fi

# Check if OS Management plugin is running
if pgrep -f "osms-agent" >/dev/null 2>&1; then
  register_check "OS Management plugin" PASS "running"
elif $is_oci; then
  register_check "OS Management plugin" INFO "not running"
fi

# ============================================================================
# METADATA SERVICE
# ============================================================================

section "Metadata Service Connectivity"

if $is_oci && command -v curl >/dev/null 2>&1; then
  # Get instance information using v2 API
  instance_id=$(timeout 2 curl -s -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/id" 2>/dev/null || echo "")
  if [[ -n "$instance_id" ]]; then
    # Truncate OCID for display (format: ocid1.instance.oc1.xxx...)
    short_id=$(echo "$instance_id" | cut -c1-35)
    register_check "Instance OCID" PASS "${short_id}..."
  else
    # Try v1 API
    instance_id=$(timeout 2 curl -s "http://169.254.169.254/opc/v1/instance/id" 2>/dev/null || echo "")
    if [[ -n "$instance_id" ]]; then
      short_id=$(echo "$instance_id" | cut -c1-35)
      register_check "Instance OCID" PASS "${short_id}..."
    else
      register_check "Instance OCID" WARN "unable to retrieve"
    fi
  fi

  # Get compartment
  compartment=$(timeout 2 curl -s -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/compartmentId" 2>/dev/null || echo "")
  if [[ -n "$compartment" ]]; then
    short_comp=$(echo "$compartment" | cut -c1-35)
    register_check "Compartment OCID" PASS "${short_comp}..."
  fi

  # Get region
  region=$(timeout 2 curl -s -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/region" 2>/dev/null || echo "")
  if [[ -n "$region" ]]; then
    register_check "OCI Region" PASS "$region"
  fi

  # Get availability domain
  ad=$(timeout 2 curl -s -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/availabilityDomain" 2>/dev/null || echo "")
  if [[ -n "$ad" ]]; then
    register_check "Availability Domain" PASS "$ad"
  fi
fi

# ============================================================================
# BASTION SERVICE INTEGRATION
# ============================================================================

section "Bastion Service"

# Check if Bastion plugin is configured
if [[ -f "$PLUGIN_CONFIG" ]]; then
  if grep -q '"Bastion"' "$PLUGIN_CONFIG"; then
    if grep -A2 '"Bastion"' "$PLUGIN_CONFIG" | grep -q '"disabled"\s*:\s*false'; then
      register_check "Bastion plugin" PASS "enabled"
    else
      register_check "Bastion plugin" INFO "disabled"
    fi
  else
    register_check "Bastion plugin" INFO "not configured"
  fi
fi

# Check for Bastion session port (22 for SSH)
if ss -tln 2>/dev/null | grep -q ":22 "; then
  register_check "SSH port (22)" PASS "listening"
else
  register_check "SSH port (22)" WARN "not listening"
fi

# ============================================================================
# OS MANAGEMENT SERVICE CONFIGURATION
# ============================================================================

section "OS Management Service"

# Check OSMS config directory
OSMS_CONFIG_DIR="/var/lib/oracle-cloud-agent/plugins/osms"
if [[ -d "$OSMS_CONFIG_DIR" ]]; then
  register_check "OSMS data directory" PASS "exists"

  # Check for registration
  if [[ -f "$OSMS_CONFIG_DIR/registration" ]] || [[ -f "$OSMS_CONFIG_DIR/.registered" ]]; then
    register_check "OSMS registration" PASS "registered"
  elif $is_oci; then
    register_check "OSMS registration" INFO "status unknown"
  fi
else
  if $is_oci; then
    register_check "OSMS data directory" INFO "not found"
  fi
fi

# Check for OS Management Hub integration (newer)
if [[ -d "/var/lib/oracle-cloud-agent/plugins/osmh" ]]; then
  register_check "OS Management Hub" PASS "configured"
fi

# ============================================================================
# SECURITY CONFIGURATION
# ============================================================================

section "Security Configuration"

# Check agent runs as dedicated user
agent_user=$(ps -eo user,comm 2>/dev/null | grep oracle-cloud-agent | awk '{print $1}' | head -1)
if [[ -n "$agent_user" ]]; then
  if [[ "$agent_user" == "root" ]]; then
    register_check "Agent user" INFO "running as root"
  else
    register_check "Agent user" PASS "running as $agent_user"
  fi
fi

# Check agent config permissions
AGENT_CONFIG="/etc/oracle-cloud-agent"
if [[ -d "$AGENT_CONFIG" ]]; then
  config_perms=$(stat -c "%a" "$AGENT_CONFIG" 2>/dev/null || echo "")
  if [[ "$config_perms" == "755" ]] || [[ "$config_perms" == "750" ]]; then
    register_check "Config directory permissions" PASS "$config_perms"
  elif [[ -n "$config_perms" ]]; then
    register_check "Config directory permissions" INFO "$config_perms"
  fi
fi

# Check log directory
AGENT_LOGS="/var/log/oracle-cloud-agent"
if [[ -d "$AGENT_LOGS" ]]; then
  register_check "Log directory" PASS "exists"

  # Check for recent logs
  if find "$AGENT_LOGS" -name "*.log" -mmin -60 2>/dev/null | grep -q .; then
    register_check "Recent agent activity" PASS "logs within 60 min"
  else
    register_check "Recent agent activity" WARN "no recent logs"
  fi
else
  if $oci_agent_found; then
    register_check "Log directory" WARN "not found"
  fi
fi

# ============================================================================
# INSTANCE PRINCIPAL AUTHENTICATION
# ============================================================================

section "Instance Principal Authentication"

# Check if instance principal is available (for OCI SDK/CLI usage)
if $is_oci; then
  # Instance principals use the metadata service for auth
  identity=$(timeout 2 curl -s -H "Authorization: Bearer Oracle" "$OCI_METADATA/instance/identity/cert.pem" 2>/dev/null || echo "")
  if [[ -n "$identity" ]]; then
    register_check "Instance principal cert" PASS "available"
  else
    register_check "Instance principal cert" INFO "not retrieved"
  fi
fi

# Check for OCI CLI with instance principal config
if command -v oci >/dev/null 2>&1; then
  register_check "OCI CLI" PASS "installed"

  # Check for instance principal profile
  if [[ -f "$HOME/.oci/config" ]]; then
    if grep -q "auth=instance_principal" "$HOME/.oci/config" 2>/dev/null; then
      register_check "OCI CLI instance principal" PASS "configured"
    fi
  fi
fi

# ============================================================================
# SUMMARY
# ============================================================================

print_summary
exit "$EXIT_CODE"
