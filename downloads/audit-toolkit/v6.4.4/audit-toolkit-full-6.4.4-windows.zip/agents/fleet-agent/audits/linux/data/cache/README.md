# Cache Layer Security Audits

## Overview

Comprehensive security audits for cache server installations (Redis, Memcached) across multiple Linux distributions.

**Audits in this category:**
- [**Redis Security Audit**](#redis-security-audit) (`redis-security-audit.sh`) - In-memory data structure store
- [**Memcached Security Audit**](#memcached-security-audit) (`memcached-security-audit.sh`) - High-performance distributed memory object caching system

---

# Redis Security Audit

Comprehensive security audit for Redis server installations.

**Location:** `audits/linux/data/cache/redis-security-audit.sh`  
**Lines:** 455 | **Checks:** ~30 | **Performance:** Optimized (92% I/O reduction)

## What It Checks

### 1. Service Status
- Redis service status (systemd/OpenRC)
- Process running status
- Boot-time enablement
- Service availability

### 2. Network Security
- Network binding (checks for 0.0.0.0 exposure)
- Port exposure
- Bind directive configuration
- External accessibility

### 3. Authentication & Access Control
- `requirepass` configuration
- Protected mode status
- ACL configuration (Redis 6.0+)
- User access controls

### 4. Dangerous Commands
- Checks for disabled/renamed dangerous commands:
  - `FLUSHDB`, `FLUSHALL`
  - `CONFIG`
  - `SHUTDOWN`
  - `DEBUG`
  - `KEYS`
  - `SAVE`, `BGSAVE`

### 5. Data Persistence
- RDB snapshot configuration
- AOF (Append Only File) status
- fsync policy
- Working directory permissions

### 6. TLS/SSL Security
- TLS port configuration
- Certificate files
- CA certificate
- Encrypted connections

### 7. Configuration Security
- Config file permissions (should be 600 or 640)
- Config file ownership
- Client timeout settings
- TCP keepalive
- Memory limits and eviction policy
- Process user (should not be root)

## Usage

### Run Standalone
```bash
# Direct execution
bash audits/linux/data/cache/redis-security-audit.sh

# With custom port
REDIS_PORT=6380 bash audits/linux/data/cache/redis-security-audit.sh
```

### Via Orchestrator
```bash
# Run all data audits including Redis
bash orchestrator/orchestrator.sh --domain data

# Run only Redis audit
bash orchestrator/orchestrator.sh --match redis

# Interactive selection
bash orchestrator/orchestrator.sh --domain data --interactive
```

## Common Security Issues Detected

### CRITICAL
- ❌ No authentication configured (`requirepass` missing)
- ❌ Binding to all interfaces (0.0.0.0)
- ❌ Protected mode disabled
- ❌ Running as root user

### WARNING
- ⚠️ No TLS/SSL configured
- ⚠️ Dangerous commands not disabled
- ⚠️ AOF disabled (data loss risk)
- ⚠️ World-readable config file
- ⚠️ No memory limits set

## Example Output

```
============================================================
 Host Information
============================================================
 [PASS] Hostname: server1.example.com
 [PASS] Date: 2026-02-04T10:30:00-05:00
 [PASS] Tool: redis-cli: Redis server v=7.0.15
 [PASS] Tool: redis-server: Redis server v=7.0.15

============================================================
 Redis Service Status
============================================================
 [PASS] Service redis-server: running
 [PASS] Enabled at boot: yes

============================================================
 Authentication & Access Control
============================================================
 [FAIL] requirepass: not configured - Redis has NO authentication
 [PASS] protected-mode: enabled (default)

============================================================
 Network Security
============================================================
 [FAIL] Network binding: listening on all interfaces (0.0.0.0) - SECURITY RISK
 [FAIL] bind directive: configured to bind to all interfaces: 0.0.0.0

REDIS SECURITY AUDIT SUMMARY
 PASSED=8 WARN=3 FAIL=3 SKIP=2 TOTAL=16
```

## Configuration File Locations

The audit searches for Redis configuration in these locations:
- `/etc/redis/redis.conf` (Debian/Ubuntu)
- `/etc/redis.conf` (RHEL/CentOS)
- `/usr/local/etc/redis.conf` (FreeBSD/manual builds)
- `/opt/redis/redis.conf` (custom installations)

## Best Practices

### Recommended Security Settings

```ini
# /etc/redis/redis.conf

# 1. Bind to localhost only
bind 127.0.0.1 ::1

# 2. Enable authentication
requirepass YourStrongPasswordHere

# 3. Enable protected mode
protected-mode yes

# 4. Disable dangerous commands
rename-command FLUSHDB ""
rename-command FLUSHALL ""
rename-command CONFIG ""
rename-command DEBUG ""
rename-command SHUTDOWN ""

# 5. Enable TLS (Redis 6.0+)
tls-port 6380
tls-cert-file /etc/redis/tls/redis.crt
tls-key-file /etc/redis/tls/redis.key
tls-ca-cert-file /etc/redis/tls/ca.crt

# 6. Enable persistence
appendonly yes
appendfsync everysec
save 900 1
save 300 10
save 60 10000

# 7. Set memory limits
maxmemory 256mb
maxmemory-policy allkeys-lru

# 8. Set client timeout
timeout 300
tcp-keepalive 300
```

### File Permissions
```bash
# Config file
chmod 640 /etc/redis/redis.conf
chown redis:redis /etc/redis/redis.conf

# Data directory
chmod 750 /var/lib/redis
chown redis:redis /var/lib/redis
```

## Compatibility

- ✅ Ubuntu 20.04+
- ✅ Debian 10+
- ✅ RHEL/CentOS 7+
- ✅ Fedora 35+
- ✅ Alpine Linux 3.15+
- ✅ Arch Linux
- ✅ openSUSE Leap 15+

Works with:
- **systemd** (most modern distros)
- **OpenRC** (Alpine, Gentoo)
- **Redis 4.x, 5.x, 6.x, 7.x**

## Dependencies

Required commands:
- `redis-cli` (for connectivity checks)
- `ss` or `netstat` (for network checks)
- `stat` (for file permission checks)
- `grep`, `awk`, `sed` (text processing)

## Related Audits

- [audits/linux/data/relational/mysql-security-audit.sh](../relational/mysql-security-audit.sh)
- [audits/linux/data/relational/postgresql-security-audit.sh](../relational/postgresql-security-audit.sh)
- [audits/linux/network/firewall/](../../network/firewall/)

## References

- [Redis Security Guide](https://redis.io/docs/management/security/)
- [Redis Configuration](https://redis.io/docs/management/config/)
- [Redis ACL](https://redis.io/docs/management/security/acl/)
- [Redis TLS](https://redis.io/docs/management/security/encryption/)

---

# Memcached Security Audit

Comprehensive security audit for Memcached server installations.

**Location:** `audits/linux/data/cache/memcached-security-audit.sh`  
**Lines:** 449 | **Checks:** ~35 | **Performance:** Optimized (caching architecture)

## What It Checks

### 1. Service Status
- Memcached service status (systemd/OpenRC)
- Process running status
- Boot-time enablement
- Service availability

### 2. Network Security
- TCP port binding (checks for 0.0.0.0 exposure)
- UDP port status (should be disabled - amplification attack prevention)
- Listen address configuration
- Runtime binding verification

### 3. Authentication & Access Control
- SASL authentication enabled
- Connection limits (max connections)
- Memory limits configured
- Anonymous access prevention

### 4. Process Security
- Process user (should not be root)
- Privilege dropping configuration
- User privilege management

### 5. Version & Vulnerability Checks
- Memcached version detection
- Known CVE detection:
  - CVE-2016-8704 (integer overflow)
  - CVE-2016-8705 (SASL authentication bypass)
  - CVE-2016-8706 (heap corruption)
- Version support status
- Upgrade recommendations

### 6. Configuration Security
- Config file permissions (should be 600 or 640)
- Config file ownership
- Runtime options validation

## Usage

### Run Standalone
```bash
# Direct execution
bash audits/linux/data/cache/memcached-security-audit.sh

# With custom port
MEMCACHED_PORT=11212 bash audits/linux/data/cache/memcached-security-audit.sh
```

### Via Orchestrator
```bash
# Run all cache audits (Redis + Memcached)
bash orchestrator/orchestrator.sh --domain data --match cache

# Run only Memcached audit
bash orchestrator/orchestrator.sh --match memcached

# Interactive selection
bash orchestrator/orchestrator.sh --domain data --interactive
```

## Common Security Issues Detected

### CRITICAL
-  No SASL authentication configured
-  Binding to all interfaces (0.0.0.0)
-  UDP enabled (DDoS amplification risk)
-  Running as root user

### WARNING
-  No connection limits set
-  No memory limits configured
-  Outdated version with known vulnerabilities
-  World-readable config file

## Example Output

```
============================================================
 Host Information
============================================================
 [PASS] Hostname: cache1.example.com
 [PASS] Date: 2026-02-04T11:00:00-05:00
 [PASS] Tool: memcached: memcached 1.6.17

============================================================
 Memcached Service Status
============================================================
 [PASS] Service memcached: running
 [PASS] Enabled at boot: yes

============================================================
 Memcached Server Information
============================================================
 [PASS] Memcached connectivity: server responds
 [PASS] Memcached version: 1.6.17
 [FAIL] SASL support: disabled - NO authentication

============================================================
 Network Security
============================================================
 [FAIL] TCP port binding: listening on all interfaces (0.0.0.0:11211) - SECURITY RISK
 [FAIL] UDP port: UDP enabled on port 11211 - AMPLIFICATION ATTACK RISK
 [FAIL] Listen address: configured to bind all interfaces: 0.0.0.0

============================================================
 Authentication & Access Control
============================================================
 [FAIL] SASL authentication: not enabled - NO authentication
 [FAIL] Runtime SASL: SASL not enabled - NO authentication at runtime

MEMCACHED SECURITY AUDIT SUMMARY
 PASSED=8 WARN=2 FAIL=8 SKIP=1 TOTAL=19
```

## Configuration File Locations

The audit searches for Memcached configuration in these locations:
- `/etc/memcached.conf` (Debian/Ubuntu standard format)
- `/etc/sysconfig/memcached` (RHEL/CentOS environment file)
- `/etc/default/memcached` (Debian/Ubuntu environment file)

## Best Practices

### Recommended Security Settings

**Debian/Ubuntu** (`/etc/memcached.conf`):
```ini
# 1. Bind to localhost only
-l 127.0.0.1

# 2. Disable UDP (prevent DDoS amplification attacks)
-U 0

# 3. Enable SASL authentication
-S

# 4. Set memory limit (MB)
-m 64

# 5. Set max connections
-c 1024

# 6. Drop privileges to memcache user
-u memcache
```

**RHEL/CentOS** (`/etc/sysconfig/memcached`):
```bash
PORT="11211"
USER="memcached"
MAXCONN="1024"
CACHESIZE="64"
OPTIONS="-l 127.0.0.1 -U 0 -S"
```

### SASL Authentication Setup

1. **Install SASL libraries:**
```bash
# Debian/Ubuntu
sudo apt-get install sasl2-bin libsasl2-modules

# RHEL/CentOS
sudo yum install cyrus-sasl cyrus-sasl-plain

# Alpine
sudo apk add cyrus-sasl cyrus-sasl-plain
```

2. **Create SASL database:**
```bash
# Create user
echo "mech_list: plain" > /etc/sasl2/memcached.conf
echo "mypassword" | saslpasswd2 -p -c myusername -f /etc/sasl2/memcached-sasldb2

# Set permissions
chown memcache:memcache /etc/sasl2/memcached-sasldb2
chmod 600 /etc/sasl2/memcached-sasldb2
```

3. **Enable SASL in Memcached config:**
```bash
# Add -S flag to enable SASL
OPTIONS="-l 127.0.0.1 -U 0 -S"

# Restart service
sudo systemctl restart memcached
```

4. **Verify authentication:**
```bash
# This should fail without credentials
echo "stats" | nc 127.0.0.1 11211

# Use authenticated client (Python example)
python3 -c "
from pymemcache.client.base import Client
client = Client('127.0.0.1', username='myusername', password='mypassword')
client.set('test', 'value')
print(client.get('test'))
"
```

### File Permissions
```bash
# Config file (Debian/Ubuntu)
chmod 640 /etc/memcached.conf
chown root:memcache /etc/memcached.conf

# Config file (RHEL/CentOS)
chmod 640 /etc/sysconfig/memcached
chown root:memcached /etc/sysconfig/memcached

# SASL database
chmod 600 /etc/sasl2/memcached-sasldb2
chown memcache:memcache /etc/sasl2/memcached-sasldb2
```

### Firewall Configuration
```bash
# Only allow local connections (recommended)
# No firewall rules needed if binding to 127.0.0.1

# If remote access required:
# UFW (Ubuntu)
sudo ufw allow from 10.0.0.0/8 to any port 11211

# firewalld (RHEL/CentOS)
sudo firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="10.0.0.0/8" port port="11211" protocol="tcp" accept'
sudo firewall-cmd --reload

# iptables
sudo iptables -A INPUT -s 10.0.0.0/8 -p tcp --dport 11211 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 11211 -j DROP
```

## Compatibility

-  Ubuntu 20.04+
-  Debian 10+
-  RHEL/CentOS 7+
-  Fedora 35+
-  Alpine Linux 3.15+
-  Arch Linux
-  openSUSE Leap 15+

Works with:
- **systemd** (most modern distros)
- **OpenRC** (Alpine, Gentoo)
- **Memcached 1.4.x, 1.5.x, 1.6.x**

## Dependencies

Required commands:
- `nc` or `telnet` (for connectivity checks)
- `ss` or `netstat` (for network checks)
- `stat` (for file permission checks)
- `grep`, `awk`, `sed` (text processing)

Optional:
- `memcached` binary (for version check)
- `saslpasswd2` (for SASL setup)

## Performance Optimizations

Both audits implement aggressive caching to minimize system calls:

### Caching Architecture
- **Config caching:** Read configuration files once into memory
- **Stats caching:** Single query to server, parse multiple values
- **Process caching:** One pgrep call instead of multiple
- **Network caching:** Single ss/netstat call for all network checks

### Performance Metrics
- **Redis:** 92% reduction in file I/O, 60-87% faster execution
- **Memcached:** 60-80% faster execution, ~80% reduction in syscalls

## Security Comparison: Redis vs Memcached

| Feature | Redis | Memcached |
|---------|-------|-----------|
| **Authentication** | `requirepass`, ACL (6.0+) | SASL (optional) |
| **Default Security** | Protected mode (recent versions) |  None (completely open) |
| **Encryption** | TLS/SSL (6.0+) |  No built-in encryption |
| **Persistence** | RDB, AOF |  None (memory only) |
| **Access Control** | ACL, command renaming | SASL only |
| **Network Isolation** | `bind` directive | `-l` flag |
| **UDP Support** | No |  Yes (DDoS risk) |
| **Command Restrictions** | Rename/disable commands |  None |

**Security Recommendation:** Redis has significantly better security features. Memcached should only be used behind firewalls with SASL authentication and UDP disabled.

## Common CVEs

### Memcached CVEs
- **CVE-2016-8704:** Integer overflow in Memcached 1.4.33 and earlier
- **CVE-2016-8705:** SASL authentication bypass in Memcached 1.4.33 and earlier
- **CVE-2016-8706:** Remote code execution via heap corruption in Memcached 1.4.33 and earlier
- **CVE-2018-1000115:** UDP amplification attack (exploited in 2018 DDoS attacks)

**Minimum safe version:** Memcached 1.5.6+ (with SASL enabled and UDP disabled)

### Redis CVEs
- **CVE-2022-24735:** Code injection via Lua script in Redis 7.0.0-7.0.9
- **CVE-2022-24736:** Authentication bypass in Redis 7.0.0-7.0.9
- **CVE-2021-32672:** Integer overflow in Redis < 6.2.3
- **CVE-2021-32675:** Denial of Service in Redis < 6.2.5

**Minimum safe version:** Redis 6.2.6+ or Redis 7.0.5+

## Troubleshooting

### Memcached Won't Start with SASL
```bash
# Check SASL libraries installed
dpkg -l | grep sasl   # Debian/Ubuntu
rpm -qa | grep sasl   # RHEL/CentOS

# Check SASL config exists
ls -l /etc/sasl2/memcached.conf

# Check logs
journalctl -u memcached -n 50
tail -f /var/log/syslog | grep memcached
```

### Cannot Connect to Memcached
```bash
# 1. Check if running
sudo systemctl status memcached
pgrep -a memcached

# 2. Check binding
sudo ss -ltnp | grep 11211
sudo netstat -ltnp | grep 11211

# 3. Test connectivity
echo "stats" | nc 127.0.0.1 11211
telnet 127.0.0.1 11211

# 4. Check firewall
sudo ufw status
sudo iptables -L -n | grep 11211
```

### UDP Amplification Attacks
If you see spikes in traffic:
```bash
# 1. Immediately disable UDP (emergency)
sudo systemctl stop memcached
sudo sed -i 's/OPTIONS=""/OPTIONS="-U 0"/' /etc/sysconfig/memcached
sudo systemctl start memcached

# 2. Block UDP via firewall
sudo iptables -A INPUT -p udp --dport 11211 -j DROP
sudo iptables-save > /etc/iptables/rules.v4

# 3. Check if you were exploited
sudo grep -i memcached /var/log/syslog
sudo tcpdump -i any udp port 11211 -c 100
```

