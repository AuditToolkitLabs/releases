#!/usr/bin/env bash
# Memcached Security Audit (portable) - Performance Optimized
# Checks Memcached configuration, authentication, network exposure, and security settings
#
# @elevation: partial
# @elevation-reason: Reads Memcached config files and checks service status
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
MEMCACHED_PORT=11211
MEMCACHED_CONFIG_PATHS=(
  "/etc/memcached.conf"
  "/etc/sysconfig/memcached"
  "/etc/default/memcached"
)

# === Performance: Cache variables ===
MEMCACHED_CONFIG_FILE=""
MEMCACHED_CONFIG_CONTENT=""
MEMCACHED_STATS=""
MEMCACHED_PID=""
SS_OUTPUT=""

# Helper function to find Memcached config file (called once)
find_memcached_config() {
  if [[ -n "$MEMCACHED_CONFIG_FILE" ]]; then
    echo "$MEMCACHED_CONFIG_FILE"
    return 0
  fi

  for path in "${MEMCACHED_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      MEMCACHED_CONFIG_FILE="$path"
      # OPTIMIZATION: Read entire config into memory once
      MEMCACHED_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# OPTIMIZED: Get Memcached config value from cached content
get_memcached_config() {
  local key="$1"

  if [[ -n "$MEMCACHED_CONFIG_CONTENT" ]]; then
    # Handle different config formats (key=value or -option value)
    local value
    # Try key=value format first
    value=$(echo "$MEMCACHED_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}[[:space:]]*=" 2>/dev/null | head -n1 | cut -d= -f2- | xargs || echo "")
    if [[ -z "$value" ]]; then
      # Try -option format (for OPTIONS line)
      value=$(echo "$MEMCACHED_CONFIG_CONTENT" | grep -E "(^|[[:space:]])-${key}" 2>/dev/null | head -n1 || echo "")
    fi
    echo "$value"
  fi
}

# OPTIMIZED: Get network listening info (called once)
get_ss_output() {
  if [[ -n "$SS_OUTPUT" ]]; then
    echo "$SS_OUTPUT"
    return 0
  fi

  if command -v ss >/dev/null 2>&1; then
    SS_OUTPUT=$(ss -ltn 2>/dev/null || echo "")
  elif command -v netstat >/dev/null 2>&1; then
    SS_OUTPUT=$(netstat -ltn 2>/dev/null || echo "")
  else
    return 1
  fi

  echo "$SS_OUTPUT"
}

# OPTIMIZED: Get Memcached process info (called once)
get_memcached_pid() {
  if [[ -z "$MEMCACHED_PID" ]]; then
    MEMCACHED_PID=$(pgrep -x memcached | head -n1 || echo "")
  fi
  echo "$MEMCACHED_PID"
}

# OPTIMIZED: Get Memcached stats (called once)
get_memcached_stats() {
  if [[ -n "$MEMCACHED_STATS" ]]; then
    echo "$MEMCACHED_STATS"
    return 0
  fi

  # Try to get stats (will fail if SASL auth is required - which is good)
  if command -v nc >/dev/null 2>&1; then
    MEMCACHED_STATS=$(echo "stats" | timeout 2 nc 127.0.0.1 "$MEMCACHED_PORT" 2>/dev/null || echo "")
  elif command -v telnet >/dev/null 2>&1; then
    MEMCACHED_STATS=$(echo -e "stats\nquit" | timeout 2 telnet 127.0.0.1 "$MEMCACHED_PORT" 2>/dev/null || echo "")
  fi

  echo "$MEMCACHED_STATS"
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for Memcached tools
if command -v memcached >/dev/null 2>&1; then
  version_info=$(memcached -h 2>&1 | grep -i version | head -n1 || echo "unknown")
  register_check "Tool: memcached" PASS "$version_info"
else
  register_check "Tool: memcached" WARN "not found"
fi

# Check for connectivity tools
for tool in nc telnet; do
  if command -v "$tool" >/dev/null 2>&1; then
    register_check "Tool: $tool" PASS "available"
  fi
done

# Check Memcached service status
section "Memcached Service Status"

service_names=("memcached" "memcached.service")
service_found=false
service_active=false
service_enabled=false

for svc_name in "${service_names[@]}"; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Service $svc_name" PASS "running"
    service_active=true
    service_found=true
  fi
  if svc_is_enabled "$svc_name" 2>/dev/null; then
    service_enabled=true
  fi
done

if [[ "$service_found" == false ]]; then
  # Check if Memcached is running as a process
  memcached_pid=$(get_memcached_pid)
  if [[ -n "$memcached_pid" ]]; then
    register_check "Memcached process" PASS "running (PID: $memcached_pid)"
    service_active=true
  else
    register_check "Memcached service" WARN "no running Memcached instance detected"
  fi
fi

if [[ "$service_enabled" == true ]]; then
  register_check "Enabled at boot" PASS "yes"
elif [[ "$service_active" == true ]]; then
  register_check "Enabled at boot" WARN "service running but not enabled"
fi

# Memcached Server Information
section "Memcached Server Information"

# OPTIMIZATION: Get stats once and parse multiple values
memcached_stats=$(get_memcached_stats)

if [[ -n "$memcached_stats" ]] && [[ "$memcached_stats" =~ STAT\ version ]]; then
  register_check "Memcached connectivity" PASS "server responds"

  # Parse version
  version=$(echo "$memcached_stats" | grep "STAT version" | awk '{print $3}' || echo "")
  if [[ -n "$version" ]]; then
    register_check "Memcached version" PASS "$version"

    # Check if version is outdated (< 1.6 has known issues)
    major_version=$(echo "$version" | cut -d. -f1)
    minor_version=$(echo "$version" | cut -d. -f2)
    if [[ "$major_version" -lt 1 ]]; then
      register_check "Memcached version support" FAIL "version $version is very old"
    elif [[ "$major_version" -eq 1 ]] && [[ "$minor_version" -lt 5 ]]; then
      register_check "Memcached version support" WARN "version $version has known vulnerabilities"
    fi
  fi

  # Parse uptime
  uptime=$(echo "$memcached_stats" | grep "STAT uptime" | awk '{print $3}' || echo "")
  if [[ -n "$uptime" ]]; then
    uptime_days=$((uptime / 86400))
    register_check "Memcached uptime" PASS "$uptime_days days"
  fi

  # Parse current connections
  curr_connections=$(echo "$memcached_stats" | grep "STAT curr_connections" | awk '{print $3}' || echo "")
  if [[ -n "$curr_connections" ]]; then
    if [[ "$curr_connections" -lt 100 ]]; then
      register_check "Current connections" PASS "$curr_connections"
    elif [[ "$curr_connections" -lt 500 ]]; then
      register_check "Current connections" WARN "$curr_connections (monitor closely)"
    else
      register_check "Current connections" FAIL "$curr_connections (possible resource exhaustion)"
    fi
  fi

  # Check if SASL is supported
  sasl_enabled=$(echo "$memcached_stats" | grep "STAT sasl_enabled" | awk '{print $3}' || echo "")
  if [[ "$sasl_enabled" == "yes" ]]; then
    register_check "SASL support" PASS "enabled"
  else
    register_check "SASL support" FAIL "disabled - NO authentication"
  fi
else
  # Could not connect - check why
  if [[ -z "$memcached_stats" ]]; then
    register_check "Memcached connectivity" FAIL "cannot connect to Memcached on port $MEMCACHED_PORT"
  else
    # Might require authentication
    register_check "Memcached connectivity" WARN "authentication may be required (check manually)"
  fi
fi

# Configuration file checks
section "Memcached Configuration File"

memcached_config=$(find_memcached_config || echo "")

if [[ -n "$memcached_config" ]]; then
  register_check "Config file" PASS "$memcached_config"

  # Check file permissions
  if [[ -r "$memcached_config" ]]; then
    perms=$(stat -c "%a" "$memcached_config" 2>/dev/null || stat -f "%Lp" "$memcached_config" 2>/dev/null || echo "unknown")
    if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]] || [[ "$perms" == "644" ]]; then
      register_check "Config file permissions" PASS "$perms"
    else
      register_check "Config file permissions" WARN "$perms"
    fi

    # Check ownership
    owner=$(stat -c "%U" "$memcached_config" 2>/dev/null || stat -f "%Su" "$memcached_config" 2>/dev/null || echo "unknown")
    if [[ "$owner" == "memcache" ]] || [[ "$owner" == "memcached" ]] || [[ "$owner" == "root" ]]; then
      register_check "Config file owner" PASS "$owner"
    else
      register_check "Config file owner" WARN "$owner (expected memcache/memcached/root)"
    fi
  else
    register_check "Config file permissions" FAIL "cannot read config file"
  fi
else
  register_check "Config file" WARN "not found in standard locations (may use command-line options)"
fi

# Network Security
section "Network Security"

# OPTIMIZATION: Get ss output once
ss_output=$(get_ss_output || echo "")

if [[ -n "$ss_output" ]]; then
  # Check TCP port
  listen_tcp=$(echo "$ss_output" | grep ":$MEMCACHED_PORT" || echo "")

  if [[ -n "$listen_tcp" ]]; then
    if echo "$listen_tcp" | grep -qE "(0\.0\.0\.0|\*|::|\[::\]):$MEMCACHED_PORT"; then
      register_check "TCP port binding" FAIL "listening on all interfaces (0.0.0.0:$MEMCACHED_PORT) - SECURITY RISK"
    else
      bind_addr=$(echo "$listen_tcp" | awk '{print $4}' | head -n1 | cut -d: -f1)
      register_check "TCP port binding" PASS "bound to specific interface ($bind_addr:$MEMCACHED_PORT)"
    fi
  else
    register_check "TCP port $MEMCACHED_PORT" WARN "not detected in listening ports"
  fi

  # Check UDP port (should be disabled due to amplification attacks)
  listen_udp=$(echo "$ss_output" | grep -E "udp.*:$MEMCACHED_PORT" || echo "")
  if [[ -n "$listen_udp" ]]; then
    register_check "UDP port" FAIL "UDP enabled on port $MEMCACHED_PORT - AMPLIFICATION ATTACK RISK"
  else
    register_check "UDP port" PASS "UDP disabled (recommended)"
  fi
else
  register_check "Network check" SKIP "ss/netstat not available"
fi

# Check configuration for binding
if [[ -n "$MEMCACHED_CONFIG_CONTENT" ]]; then
  # Check listen address (varies by config format)
  listen_addr=$(get_memcached_config "l" || get_memcached_config "listen" || echo "")

  if [[ -n "$listen_addr" ]]; then
    if [[ "$listen_addr" =~ 0\.0\.0\.0 ]] || [[ "$listen_addr" =~ :: ]]; then
      register_check "Listen address" FAIL "configured to bind all interfaces: $listen_addr"
    elif [[ "$listen_addr" =~ 127\.0\.0\.1 ]] || [[ "$listen_addr" =~ localhost ]]; then
      register_check "Listen address" PASS "restricted to localhost: $listen_addr"
    else
      register_check "Listen address" PASS "$listen_addr"
    fi
  else
    # Check OPTIONS line for -l flag
    if echo "$MEMCACHED_CONFIG_CONTENT" | grep -qE 'OPTIONS.*-l[[:space:]]+(127\.0\.0\.1|localhost)'; then
      register_check "Listen address" PASS "restricted to localhost (in OPTIONS)"
    elif echo "$MEMCACHED_CONFIG_CONTENT" | grep -qE 'OPTIONS.*-l'; then
      options_line=$(echo "$MEMCACHED_CONFIG_CONTENT" | grep "OPTIONS" || echo "")
      register_check "Listen address" WARN "configured in OPTIONS: $options_line"
    else
      register_check "Listen address" WARN "not explicitly configured (may bind to all interfaces)"
    fi
  fi

  # Check if UDP is disabled
  if echo "$MEMCACHED_CONFIG_CONTENT" | grep -qE '(^|[[:space:]])-U[[:space:]]+0'; then
    register_check "UDP disabled in config" PASS "explicitly disabled with -U 0"
  else
    register_check "UDP disabled in config" FAIL "UDP not explicitly disabled (add -U 0)"
  fi
fi

# Check process command line for actual binding
memcached_pid=$(get_memcached_pid)
if [[ -n "$memcached_pid" ]]; then
  cmdline=$(ps -o args= -p "$memcached_pid" 2>/dev/null || echo "")
  if [[ -n "$cmdline" ]]; then
    # Check for -l flag in command line
    if echo "$cmdline" | grep -qE '\-l[[:space:]]+(127\.0\.0\.1|localhost|::1)'; then
      register_check "Runtime binding" PASS "bound to localhost"
    elif echo "$cmdline" | grep -qE '\-l'; then
      bind_addr=$(echo "$cmdline" | grep -oP '\-l\s+\K[^\s]+' || echo "unknown")
      if [[ "$bind_addr" == "0.0.0.0" ]] || [[ "$bind_addr" == "::" ]]; then
        register_check "Runtime binding" FAIL "bound to all interfaces: $bind_addr"
      else
        register_check "Runtime binding" PASS "bound to: $bind_addr"
      fi
    fi

    # Check for UDP disabled flag
    if echo "$cmdline" | grep -qE '\-U[[:space:]]+0'; then
      register_check "Runtime UDP" PASS "UDP disabled (-U 0)"
    else
      register_check "Runtime UDP" FAIL "UDP not disabled at runtime"
    fi
  fi
fi

# Authentication & Security
section "Authentication & Access Control"

if [[ -n "$MEMCACHED_CONFIG_CONTENT" ]]; then
  # Check for SASL authentication
  if echo "$MEMCACHED_CONFIG_CONTENT" | grep -qE '(^|[[:space:]])-S'; then
    register_check "SASL authentication" PASS "enabled in config (-S flag)"
  else
    register_check "SASL authentication" FAIL "not enabled - NO authentication"
  fi

  # Check max connections limit
  max_conn=$(echo "$MEMCACHED_CONFIG_CONTENT" | grep -oP '\-c\s+\K[0-9]+' || echo "")
  if [[ -n "$max_conn" ]]; then
    if [[ "$max_conn" -le 1024 ]]; then
      register_check "Max connections" PASS "$max_conn (reasonable limit)"
    elif [[ "$max_conn" -le 4096 ]]; then
      register_check "Max connections" WARN "$max_conn (high but acceptable)"
    else
      register_check "Max connections" FAIL "$max_conn (too high, DoS risk)"
    fi
  else
    register_check "Max connections" WARN "not explicitly configured (uses default)"
  fi

  # Check memory limit
  mem_limit=$(echo "$MEMCACHED_CONFIG_CONTENT" | grep -oP '\-m\s+\K[0-9]+' || echo "")
  if [[ -n "$mem_limit" ]]; then
    register_check "Memory limit" PASS "${mem_limit}MB configured"
  else
    register_check "Memory limit" WARN "not explicitly configured (uses default 64MB)"
  fi
else
  register_check "Authentication check" SKIP "config file not found"
fi

# Check actual runtime authentication
if [[ -n "$memcached_pid" ]]; then
  cmdline=$(ps -o args= -p "$memcached_pid" 2>/dev/null || echo "")
  if echo "$cmdline" | grep -qE '\-S'; then
    register_check "Runtime SASL" PASS "SASL enabled at runtime"
  else
    register_check "Runtime SASL" FAIL "SASL not enabled - NO authentication at runtime"
  fi
fi

# Process Security
section "Process Security"

if [[ -n "$memcached_pid" ]]; then
  # Check process user
  memcached_user=$(ps -o user= -p "$memcached_pid" 2>/dev/null || echo "unknown")
  if [[ "$memcached_user" == "memcache" ]] || [[ "$memcached_user" == "memcached" ]]; then
    register_check "Process user" PASS "$memcached_user"
  elif [[ "$memcached_user" == "root" ]]; then
    register_check "Process user" FAIL "running as root - SECURITY RISK"
  else
    register_check "Process user" WARN "$memcached_user (expected 'memcache' or 'memcached')"
  fi

  # Check if process is dropping privileges
  if echo "$MEMCACHED_CONFIG_CONTENT" | grep -qE '\-u[[:space:]]+(memcache|memcached)'; then
    register_check "User privilege drop" PASS "configured to drop privileges"
  elif [[ "$memcached_user" != "root" ]]; then
    register_check "User privilege drop" PASS "running as non-root user"
  else
    register_check "User privilege drop" FAIL "not configured to drop root privileges"
  fi
fi

# Check for known vulnerabilities
section "Version & Vulnerability Check"

if [[ -n "$version" ]]; then
  # Check for specific CVEs
  major=$(echo "$version" | cut -d. -f1)
  minor=$(echo "$version" | cut -d. -f2)
  patch=$(echo "$version" | cut -d. -f3)

  # CVE-2016-8704, CVE-2016-8705, CVE-2016-8706 affect < 1.4.33
  if [[ "$major" -eq 1 ]] && [[ "$minor" -eq 4 ]] && [[ "${patch:-0}" -lt 33 ]]; then
    register_check "CVE-2016-8704/5/6" FAIL "version $version vulnerable to integer overflow attacks"
  else
    register_check "Known CVEs" PASS "no known critical vulnerabilities in version $version"
  fi

  # Check for recommended version (1.6.x is current stable)
  if [[ "$major" -ge 1 ]] && [[ "$minor" -ge 6 ]]; then
    register_check "Version recommendation" PASS "running modern version ($version)"
  else
    register_check "Version recommendation" WARN "consider upgrading to 1.6.x or later"
  fi
fi

# Package installation check
section "Memcached Package"
if pkg_installed "memcached"; then
  register_check "Memcached package" PASS "installed"
else
  register_check "Memcached package" SKIP "not installed via package manager"
fi

# Print summary
print_summary
exit "$EXIT_CODE"
