#!/usr/bin/env bash
# Redis Security Audit (portable) - PERFORMANCE OPTIMIZED
# Checks Redis configuration, service status, authentication, network exposure, and security settings
#
# @elevation: partial
# @elevation-reason: Reads Redis config files and checks service status
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
REDIS_PORT=6379
REDIS_CONFIG_PATHS=(
  "/etc/redis/redis.conf"
  "/etc/redis.conf"
  "/usr/local/etc/redis.conf"
  "/opt/redis/redis.conf"
)

# === Performance: Cache variables ===
REDIS_CONFIG_FILE=""
REDIS_CONFIG_CONTENT=""
REDIS_INFO_OUTPUT=""
REDIS_PID=""
SS_OUTPUT=""

# Helper function to find Redis config file (called once)
find_redis_config() {
  if [[ -n "$REDIS_CONFIG_FILE" ]]; then
    echo "$REDIS_CONFIG_FILE"
    return 0
  fi

  for path in "${REDIS_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      REDIS_CONFIG_FILE="$path"
      # OPTIMIZATION: Read entire config into memory once
      REDIS_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# OPTIMIZED: Get Redis config value from cached content
get_redis_config() {
  local key="$1"

  # Use cached config content
  if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
    echo "$REDIS_CONFIG_CONTENT" | grep -E "^[[:space:]]*$key\s+" 2>/dev/null | tail -n1 | awk '{$1=""; print substr($0,2)}'
  fi
}

# OPTIMIZED: Get network listening info (called once)
get_ss_output() {
  if [[ -n "$SS_OUTPUT" ]]; then
    echo "$SS_OUTPUT"
    return 0
  fi

  if command -v ss >/dev/null 2>&1; then
    SS_OUTPUT=$(ss -ltn 2>/dev/null || echo "")
  elif command -v netstat >/dev/null 2>&1; then
    SS_OUTPUT=$(netstat -ltn 2>/dev/null || echo "")
  else
    return 1
  fi

  echo "$SS_OUTPUT"
}

# OPTIMIZED: Get Redis process info (called once)
get_redis_pid() {
  if [[ -z "$REDIS_PID" ]]; then
    REDIS_PID=$(pgrep -x redis-server | head -n1 || echo "")
  fi
  echo "$REDIS_PID"
}

# OPTIMIZED: Get Redis INFO output (called once)
get_redis_info() {
  if [[ -n "$REDIS_INFO_OUTPUT" ]]; then
    echo "$REDIS_INFO_OUTPUT"
    return 0
  fi

  if timeout 2 redis-cli -p "$REDIS_PORT" ping >/dev/null 2>&1; then
    REDIS_INFO_OUTPUT=$(redis-cli -p "$REDIS_PORT" INFO server 2>/dev/null || echo "")
    echo "$REDIS_INFO_OUTPUT"
    return 0
  fi
  return 1
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for required tools
tools=("redis-cli" "redis-server")
for tool in "${tools[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    version_info=$("$tool" --version 2>/dev/null | head -n1 || echo "unknown")
    register_check "Tool: $tool" PASS "$version_info"
  else
    register_check "Tool: $tool" WARN "not found"
  fi
done

# Check Redis service status
section "Redis Service Status"

# Try common Redis service names
service_names=("redis" "redis-server" "redis-server@")
service_found=false
service_active=false
service_enabled=false

# OPTIMIZATION: Collect all systemd units once if needed
if is_systemd && [[ " ${service_names[*]} " =~ " redis-server@ " ]]; then
  systemd_units=$(systemctl list-units --type=service --no-legend 2>/dev/null | awk '/redis/ {print $1}' || echo "")
fi

for svc_name in "${service_names[@]}"; do
  if [[ "$svc_name" == *@ ]]; then
    # Handle systemd template units
    if is_systemd && [[ -n "$systemd_units" ]]; then
      while IFS= read -r unit; do
        [[ -z "$unit" || ! "$unit" =~ redis.*@ ]] && continue
        if svc_is_active "$unit"; then
          register_check "Service $unit" PASS "running"
          service_active=true
          service_found=true
        fi
        if svc_is_enabled "$unit" 2>/dev/null; then
          service_enabled=true
        fi
      done <<<"$systemd_units"
    fi
  else
    # Check for specific service name
    if svc_is_active "$svc_name" 2>/dev/null; then
      register_check "Service $svc_name" PASS "running"
      service_active=true
      service_found=true
    fi
    if svc_is_enabled "$svc_name" 2>/dev/null; then
      service_enabled=true
    fi
  fi
done

if [[ "$service_found" == false ]]; then
  # OPTIMIZATION: Use cached PID check
  redis_pid=$(get_redis_pid)
  if [[ -n "$redis_pid" ]]; then
    register_check "Redis process" PASS "running (not managed by service manager)"
    service_active=true
  else
    register_check "Redis service" WARN "no running Redis instance detected"
  fi
fi

if [[ "$service_enabled" == true ]]; then
  register_check "Enabled at boot" PASS "yes"
elif [[ "$service_active" == true ]]; then
  register_check "Enabled at boot" WARN "service running but not enabled"
fi

# Check Redis server info
section "Redis Server Information"

if ! command -v redis-cli >/dev/null 2>&1; then
  register_check "redis-cli" FAIL "not installed"
else
  # OPTIMIZATION: Get INFO output once and parse multiple values
  redis_info=$(get_redis_info || echo "")

  if [[ -n "$redis_info" ]]; then
    register_check "Redis connectivity" PASS "server responds to PING"

    # Parse both version and uptime from single INFO call
    redis_version=$(echo "$redis_info" | grep -E "^redis_version:" | cut -d: -f2 | tr -d '[:space:]' || echo "")
    if [[ -n "$redis_version" ]]; then
      register_check "Redis version" PASS "$redis_version"
    fi

    uptime_days=$(echo "$redis_info" | grep -E "^uptime_in_days:" | cut -d: -f2 | tr -d '[:space:]' || echo "")
    if [[ -n "$uptime_days" ]]; then
      register_check "Redis uptime" PASS "$uptime_days days"
    fi
  elif timeout 2 redis-cli -p "$REDIS_PORT" -a "" ping 2>/dev/null | grep -q "NOAUTH"; then
    register_check "Redis connectivity" WARN "authentication required (good!)"
  else
    register_check "Redis connectivity" FAIL "cannot connect to Redis on port $REDIS_PORT"
  fi
fi

# Configuration file checks
section "Redis Configuration File"

# OPTIMIZATION: Find config and cache content once
redis_config=$(find_redis_config || echo "")

if [[ -n "$redis_config" ]]; then
  register_check "Config file" PASS "$redis_config"

  # Check file permissions
  if [[ -r "$redis_config" ]]; then
    perms=$(stat -c "%a" "$redis_config" 2>/dev/null || stat -f "%Lp" "$redis_config" 2>/dev/null || echo "unknown")
    if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
      register_check "Config file permissions" PASS "$perms"
    elif [[ "$perms" == "644" ]] || [[ "$perms" == "664" ]]; then
      register_check "Config file permissions" WARN "$perms (world-readable)"
    else
      register_check "Config file permissions" WARN "$perms"
    fi

    # Check ownership
    owner=$(stat -c "%U" "$redis_config" 2>/dev/null || stat -f "%Su" "$redis_config" 2>/dev/null || echo "unknown")
    if [[ "$owner" == "redis" ]] || [[ "$owner" == "root" ]]; then
      register_check "Config file owner" PASS "$owner"
    else
      register_check "Config file owner" WARN "$owner (expected redis or root)"
    fi
  else
    register_check "Config file permissions" FAIL "cannot read config file"
  fi
else
  register_check "Config file" WARN "not found in standard locations"
fi

# Network exposure checks
section "Network Security"

# OPTIMIZATION: Get ss output once
ss_output=$(get_ss_output || echo "")

if [[ -n "$ss_output" ]]; then
  listen_output=$(echo "$ss_output" | grep ":$REDIS_PORT" || echo "")

  if [[ -n "$listen_output" ]]; then
    # Check if bound to all interfaces
    if echo "$listen_output" | grep -qE "(0\.0\.0\.0|\*|::|\[::\]):$REDIS_PORT"; then
      register_check "Network binding" FAIL "listening on all interfaces (0.0.0.0) - SECURITY RISK"
    else
      bind_addr=$(echo "$listen_output" | awk '{print $4}' | head -n1 | cut -d: -f1)
      register_check "Network binding" PASS "bound to specific interface ($bind_addr)"
    fi
  else
    register_check "Port $REDIS_PORT" WARN "not detected in listening ports"
  fi
else
  register_check "Network check" SKIP "ss/netstat not available"
fi

# OPTIMIZATION: Use cached config content
if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  bind_config=$(get_redis_config "bind")
  if [[ -n "$bind_config" ]]; then
    if [[ "$bind_config" == *"0.0.0.0"* ]] || [[ "$bind_config" == *"::"* ]]; then
      register_check "bind directive" FAIL "configured to bind to all interfaces: $bind_config"
    elif [[ "$bind_config" == *"127.0.0.1"* ]] || [[ "$bind_config" == *"localhost"* ]]; then
      register_check "bind directive" PASS "restricted to localhost: $bind_config"
    else
      register_check "bind directive" PASS "$bind_config"
    fi
  else
    register_check "bind directive" WARN "not configured (may bind to all interfaces by default)"
  fi
fi

# Authentication checks
section "Authentication & Access Control"

if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  # OPTIMIZATION: All config reads now use cached content
  requirepass=$(get_redis_config "requirepass")
  if [[ -n "$requirepass" ]]; then
    register_check "requirepass" PASS "configured (password authentication enabled)"
  else
    register_check "requirepass" FAIL "not configured - Redis has NO authentication"
  fi

  protected_mode=$(get_redis_config "protected-mode")
  if [[ "$protected_mode" == "yes" ]] || [[ -z "$protected_mode" ]]; then
    register_check "protected-mode" PASS "enabled (default)"
  else
    register_check "protected-mode" FAIL "disabled - allows external connections without auth"
  fi

  # Check for ACL configuration (Redis 6.0+)
  if echo "$REDIS_CONFIG_CONTENT" | grep -qE "^[[:space:]]*user\s+" 2>/dev/null; then
    register_check "ACL configuration" PASS "ACL users defined"
  else
    register_check "ACL configuration" WARN "no ACL users found (consider using Redis 6.0+ ACLs)"
  fi
else
  register_check "Authentication check" SKIP "config file not found"
fi

# Dangerous commands check
section "Dangerous Commands"

if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  # OPTIMIZATION: Single grep with alternation instead of loop
  dangerous_commands=("FLUSHDB" "FLUSHALL" "KEYS" "CONFIG" "SHUTDOWN" "DEBUG" "SAVE" "BGSAVE")

  # Build regex pattern for all commands at once
  pattern="^[[:space:]]*rename-command[[:space:]]+("
  first=true
  for cmd in "${dangerous_commands[@]}"; do
    if [[ "$first" == true ]]; then
      pattern+="$cmd"
      first=false
    else
      pattern+="|$cmd"
    fi
  done
  pattern+=")"

  # Single grep call for all dangerous commands
  rename_lines=$(echo "$REDIS_CONFIG_CONTENT" | grep -iE "$pattern" 2>/dev/null || echo "")

  disabled_count=0
  renamed_count=0

  if [[ -n "$rename_lines" ]]; then
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      if echo "$line" | grep -qE '""[[:space:]]*$'; then
        ((disabled_count++))
      else
        ((renamed_count++))
      fi
    done <<<"$rename_lines"
  fi

  if [[ $disabled_count -gt 0 ]] || [[ $renamed_count -gt 0 ]]; then
    register_check "Dangerous commands" PASS "$disabled_count disabled, $renamed_count renamed"
  else
    register_check "Dangerous commands" WARN "no dangerous commands disabled or renamed"
  fi
else
  register_check "Dangerous commands" SKIP "config file not found"
fi

# Persistence & data security
section "Data Persistence & Security"

if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  # Check RDB snapshots
  if echo "$REDIS_CONFIG_CONTENT" | grep -qE "^[[:space:]]*save\s+" 2>/dev/null; then
    register_check "RDB snapshots" PASS "configured"
  else
    register_check "RDB snapshots" WARN "not configured (data loss on crash)"
  fi

  # Check AOF
  appendonly=$(get_redis_config "appendonly")
  if [[ "$appendonly" == "yes" ]]; then
    register_check "AOF (Append Only File)" PASS "enabled"

    # Check AOF fsync policy
    appendfsync=$(get_redis_config "appendfsync")
    if [[ "$appendfsync" == "always" ]]; then
      register_check "AOF fsync policy" PASS "always (safest, slower)"
    elif [[ "$appendfsync" == "everysec" ]]; then
      register_check "AOF fsync policy" PASS "everysec (balanced)"
    else
      register_check "AOF fsync policy" WARN "$appendfsync (may cause data loss)"
    fi
  else
    register_check "AOF (Append Only File)" WARN "disabled (data loss risk)"
  fi

  # Check working directory
  dir=$(get_redis_config "dir")
  if [[ -n "$dir" ]]; then
    if [[ -d "$dir" ]]; then
      dir_perms=$(stat -c "%a" "$dir" 2>/dev/null || stat -f "%Lp" "$dir" 2>/dev/null || echo "unknown")
      if [[ "$dir_perms" == "700" ]] || [[ "$dir_perms" == "750" ]]; then
        register_check "Working directory" PASS "$dir (perms: $dir_perms)"
      else
        register_check "Working directory" WARN "$dir (perms: $dir_perms, should be 700 or 750)"
      fi
    else
      register_check "Working directory" FAIL "$dir does not exist"
    fi
  else
    register_check "Working directory" WARN "not configured"
  fi
else
  register_check "Persistence check" SKIP "config file not found"
fi

# TLS/SSL configuration
section "TLS/SSL Security"

if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  # Check TLS configuration (Redis 6.0+)
  tls_port=$(get_redis_config "tls-port")
  if [[ -n "$tls_port" ]] && [[ "$tls_port" != "0" ]]; then
    register_check "TLS port" PASS "enabled on port $tls_port"

    # Check TLS cert files
    tls_cert=$(get_redis_config "tls-cert-file")
    tls_key=$(get_redis_config "tls-key-file")
    tls_ca=$(get_redis_config "tls-ca-cert-file")

    if [[ -n "$tls_cert" ]] && [[ -f "$tls_cert" ]]; then
      register_check "TLS certificate" PASS "$tls_cert"
    else
      register_check "TLS certificate" WARN "not configured or file missing"
    fi

    if [[ -n "$tls_key" ]] && [[ -f "$tls_key" ]]; then
      register_check "TLS key" PASS "$tls_key"
    else
      register_check "TLS key" WARN "not configured or file missing"
    fi

    if [[ -n "$tls_ca" ]] && [[ -f "$tls_ca" ]]; then
      register_check "TLS CA certificate" PASS "$tls_ca"
    fi
  else
    register_check "TLS/SSL" WARN "not configured (unencrypted connections)"
  fi
else
  register_check "TLS check" SKIP "config file not found"
fi

# Additional security checks
section "Additional Security Settings"

if [[ -n "$REDIS_CONFIG_CONTENT" ]]; then
  # Check timeout
  timeout_val=$(get_redis_config "timeout")
  if [[ -n "$timeout_val" ]] && [[ "$timeout_val" != "0" ]]; then
    register_check "Client timeout" PASS "${timeout_val}s"
  else
    register_check "Client timeout" WARN "disabled (idle clients never closed)"
  fi

  # Check tcp-keepalive
  tcp_keepalive=$(get_redis_config "tcp-keepalive")
  if [[ -n "$tcp_keepalive" ]] && [[ "$tcp_keepalive" != "0" ]]; then
    register_check "TCP keepalive" PASS "${tcp_keepalive}s"
  else
    register_check "TCP keepalive" WARN "disabled"
  fi

  # Check maxmemory policy
  maxmemory=$(get_redis_config "maxmemory")
  if [[ -n "$maxmemory" ]]; then
    maxmemory_policy=$(get_redis_config "maxmemory-policy")
    register_check "Memory limit" PASS "$maxmemory (policy: ${maxmemory_policy:-noeviction})"
  else
    register_check "Memory limit" WARN "not configured (unlimited memory usage)"
  fi

  # OPTIMIZATION: Use cached PID
  redis_pid=$(get_redis_pid)
  if [[ -n "$redis_pid" ]]; then
    redis_user=$(ps -o user= -p "$redis_pid" 2>/dev/null || echo "unknown")
    if [[ "$redis_user" == "redis" ]]; then
      register_check "Process user" PASS "redis"
    elif [[ "$redis_user" == "root" ]]; then
      register_check "Process user" FAIL "running as root - SECURITY RISK"
    else
      register_check "Process user" WARN "$redis_user (expected 'redis')"
    fi
  fi
else
  register_check "Security settings" SKIP "config file not found"
fi

# Package installation check
section "Redis Package"
if pkg_installed "redis" || pkg_installed "redis-server"; then
  register_check "Redis package" PASS "installed"
else
  register_check "Redis package" SKIP "not installed via package manager (may be compiled from source)"
fi

# Print summary
print_summary
exit "$EXIT_CODE"
