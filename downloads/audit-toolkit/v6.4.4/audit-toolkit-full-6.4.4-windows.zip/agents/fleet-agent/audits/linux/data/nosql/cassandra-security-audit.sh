#!/usr/bin/env bash
# Cassandra NoSQL Database Security Audit
# Checks Cassandra authentication, authorization, encryption, and cluster security
#
# @elevation: partial
# @elevation-reason: Reads Cassandra config files and checks service status
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
CASSANDRA_PATHS=(
  "/etc/cassandra"
  "/opt/cassandra/conf"
  "/usr/local/cassandra/conf"
)

CASSANDRA_DATA_PATHS=(
  "/var/lib/cassandra"
  "/opt/cassandra/data"
)

# === Performance: Cache variables ===
CASSANDRA_VERSION=""
CASSANDRA_CONFIG=""
CASSANDRA_HOME=""
CASS_YAML_CONTENT=""

# === Helper Functions ===

# Detect Cassandra installation
detect_cassandra() {
  # Check if Cassandra is installed via package manager
  if pkg_installed cassandra || pkg_installed dse; then
    return 0
  fi

  # Check for Cassandra process
  if pgrep -f "org.apache.cassandra" >/dev/null 2>&1; then
    return 0
  fi

  # Check standard paths
  for path in "${CASSANDRA_PATHS[@]}"; do
    if [[ -d "$path" && -f "$path/cassandra.yaml" ]]; then
      return 0
    fi
  done

  return 1
}

# Find Cassandra configuration
find_cassandra_config() {
  if [[ -n "$CASSANDRA_CONFIG" ]]; then
    echo "$CASSANDRA_CONFIG"
    return 0
  fi

  for path in "${CASSANDRA_PATHS[@]}"; do
    if [[ -f "$path/cassandra.yaml" ]]; then
      CASSANDRA_CONFIG="$path/cassandra.yaml"
      CASS_YAML_CONTENT=$(cat "$path/cassandra.yaml" 2>/dev/null || echo "")
      echo "$path/cassandra.yaml"
      return 0
    fi
  done

  echo ""
}

# Get Cassandra version
get_cassandra_version() {
  if [[ -n "$CASSANDRA_VERSION" ]]; then
    echo "$CASSANDRA_VERSION"
    return 0
  fi

  if command -v nodetool >/dev/null 2>&1; then
    version=$(nodetool version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    CASSANDRA_VERSION="$version"
    echo "$version"
  elif command -v cassandra >/dev/null 2>&1; then
    version=$(cassandra -v 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    CASSANDRA_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Get config value from cassandra.yaml
get_cass_config() {
  local key="$1"
  echo "$CASS_YAML_CONTENT" | grep "^${key}:" | head -n1 | sed "s/^${key}:[[:space:]]*//" || echo ""
}

# === MAIN AUDIT ===

section "Cassandra Detection"

if ! detect_cassandra; then
  register_check "Cassandra Installed" SKIP "Cassandra not detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Cassandra Installed" PASS "Cassandra detected"

# Get Cassandra version
cass_ver=$(get_cassandra_version)
if [[ "$cass_ver" != "unknown" ]]; then
  register_check "Cassandra Version" PASS "Cassandra $cass_ver"

  # Check for old versions
  major=$(echo "$cass_ver" | cut -d. -f1)
  if [[ "$major" -lt 3 ]]; then
    register_check "Version EOL" FAIL "Cassandra $major.x is End-of-Life (upgrade to 3.11+ or 4.x)"
  elif [[ "$major" -eq 3 ]]; then
    register_check "Version EOL" WARN "Cassandra 3.x in maintenance (consider upgrading to 4.x)"
  else
    register_check "Version EOL" PASS "Cassandra version current"
  fi
else
  register_check "Cassandra Version" WARN "Unable to determine Cassandra version"
fi

# === Service Status ===
section "Service Status"

if systemctl is-active cassandra >/dev/null 2>&1; then
  register_check "Cassandra Service" PASS "cassandra service running"
elif pgrep -f "org.apache.cassandra" >/dev/null 2>&1; then
  register_check "Cassandra Service" PASS "Cassandra process running"
else
  register_check "Cassandra Service" WARN "Cassandra service not running"
fi

# Check if nodetool is available
if command -v nodetool >/dev/null 2>&1; then
  register_check "nodetool" PASS "nodetool command available"

  # Check cluster status
  node_status=$(nodetool status 2>/dev/null || echo "")
  if [[ -n "$node_status" ]]; then
    # Count nodes
    node_count=$(echo "$node_status" | grep -c "^UN\|^UJ\|^UM" || echo "0")
    if [[ "$node_count" -gt 0 ]]; then
      register_check "Cluster Nodes" PASS "$node_count node(s) Up Normal"
    fi

    # Check for down nodes
    down_nodes=$(echo "$node_status" | grep -c "^DN" || echo "0")
    if [[ "$down_nodes" -gt 0 ]]; then
      register_check "Down Nodes" WARN "$down_nodes node(s) Down"
    else
      register_check "Down Nodes" PASS "No down nodes"
    fi
  fi
else
  register_check "nodetool" WARN "nodetool command not found"
fi

# === Cassandra Configuration ===
section "Cassandra Configuration"

cass_config=$(find_cassandra_config)
if [[ -z "$cass_config" ]]; then
  register_check "cassandra.yaml" FAIL "Configuration file not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "cassandra.yaml" PASS "found at $cass_config"

# Check config file permissions
config_perms=$(stat -c '%a' "$cass_config" 2>/dev/null || stat -f '%Lp' "$cass_config" 2>/dev/null || echo "000")
if [[ "$config_perms" == "644" || "$config_perms" == "640" || "$config_perms" == "600" ]]; then
  register_check "Config Permissions" PASS "permissions $config_perms"
else
  register_check "Config Permissions" WARN "permissions $config_perms (should be 644 or more restrictive)"
fi

# === Authentication & Authorization ===
section "Authentication & Authorization"

# Check authenticator
authenticator=$(get_cass_config "authenticator")
if [[ -n "$authenticator" ]]; then
  if [[ "$authenticator" == "PasswordAuthenticator" ]]; then
    register_check "Authenticator" PASS "PasswordAuthenticator enabled (authentication required)"
  elif [[ "$authenticator" == "AllowAllAuthenticator" ]]; then
    register_check "Authenticator" FAIL "AllowAllAuthenticator (NO authentication - security risk)"
  else
    register_check "Authenticator" PASS "Custom authenticator: $authenticator"
  fi
else
  register_check "Authenticator" WARN "Authenticator not found in config (check defaults)"
fi

# Check authorizer
authorizer=$(get_cass_config "authorizer")
if [[ -n "$authorizer" ]]; then
  if [[ "$authorizer" == "CassandraAuthorizer" ]]; then
    register_check "Authorizer" PASS "CassandraAuthorizer enabled (RBAC)"
  elif [[ "$authorizer" == "AllowAllAuthorizer" ]]; then
    register_check "Authorizer" FAIL "AllowAllAuthorizer (NO authorization - all users have full access)"
  else
    register_check "Authorizer" PASS "Custom authorizer: $authorizer"
  fi
else
  register_check "Authorizer" WARN "Authorizer not found in config"
fi

# Check role manager
role_manager=$(get_cass_config "role_manager")
if [[ -n "$role_manager" ]]; then
  if [[ "$role_manager" == "CassandraRoleManager" ]]; then
    register_check "Role Manager" PASS "CassandraRoleManager enabled"
  fi
fi

# === Network Security ===
section "Network Configuration"

# Check listen address
listen_address=$(get_cass_config "listen_address")
if [[ -n "$listen_address" ]]; then
  register_check "Listen Address" PASS "listen_address: $listen_address"

  if [[ "$listen_address" == "0.0.0.0" ]]; then
    register_check "Listen Binding" WARN "Listening on 0.0.0.0 (all interfaces - ensure firewall protection)"
  elif [[ "$listen_address" =~ ^127\. ]]; then
    register_check "Listen Binding" PASS "Bound to localhost (secure for single-node)"
  else
    register_check "Listen Binding" PASS "Bound to specific IP"
  fi
fi

# Check RPC address (CQL)
rpc_address=$(get_cass_config "rpc_address")
if [[ -n "$rpc_address" ]]; then
  register_check "RPC Address" PASS "rpc_address: $rpc_address"
fi

# Check native transport port (CQL default 9042)
native_port=$(get_cass_config "native_transport_port")
if [[ -n "$native_port" ]]; then
  if [[ "$native_port" == "9042" ]]; then
    register_check "CQL Port" PASS "default port 9042"
  else
    register_check "CQL Port" PASS "custom port $native_port"
  fi
fi

# === Encryption ===
section "Encryption Configuration"

# Check client-to-node encryption
client_encryption=$(get_cass_config "client_encryption_options")
if echo "$CASS_YAML_CONTENT" | grep -A 10 "^client_encryption_options:" | grep -q "enabled: true"; then
  register_check "Client Encryption" PASS "Client-to-node encryption enabled (TLS/SSL)"

  # Check keystore
  if echo "$CASS_YAML_CONTENT" | grep -A 10 "^client_encryption_options:" | grep -q "keystore:"; then
    keystore=$(echo "$CASS_YAML_CONTENT" | grep -A 10 "^client_encryption_options:" | grep "keystore:" | head -n1 | awk '{print $2}')
    if [[ -f "$keystore" ]]; then
      register_check "Client Keystore" PASS "keystore found at $keystore"

      # Check keystore permissions
      ks_perms=$(stat -c '%a' "$keystore" 2>/dev/null || stat -f '%Lp' "$keystore" 2>/dev/null || echo "000")
      if [[ "$ks_perms" == "600" || "$ks_perms" == "640" ]]; then
        register_check "Keystore Permissions" PASS "permissions $ks_perms"
      else
        register_check "Keystore Permissions" WARN "permissions $ks_perms (should be 600 or 640)"
      fi
    else
      register_check "Client Keystore" WARN "keystore not found at $keystore"
    fi
  fi

  # Check for require_client_auth
  if echo "$CASS_YAML_CONTENT" | grep -A 10 "^client_encryption_options:" | grep -q "require_client_auth: true"; then
    register_check "Client Auth Required" PASS "Mutual TLS enabled (require_client_auth: true)"
  else
    register_check "Client Auth Required" WARN "M Mutual TLS not required (consider enabling)"
  fi
else
  register_check "Client Encryption" FAIL "Client-to-node encryption disabled (data transmitted in plaintext)"
fi

# Check server-to-server encryption (inter-node)
if echo "$CASS_YAML_CONTENT" | grep -A 10 "^server_encryption_options:" | grep -q "internode_encryption: all"; then
  register_check "Inter-node Encryption" PASS "Inter-node encryption: all (most secure)"
elif echo "$CASS_YAML_CONTENT" | grep -A 10 "^server_encryption_options:" | grep -q "internode_encryption: dc"; then
  register_check "Inter-node Encryption" PASS "Inter-node encryption: dc (datacenter traffic encrypted)"
elif echo "$CASS_YAML_CONTENT" | grep -A 10 "^server_encryption_options:" | grep -q "internode_encryption: rack"; then
  register_check "Inter-node Encryption" WARN "Inter-node encryption: rack (consider 'all' or 'dc')"
else
  register_check "Inter-node Encryption" FAIL "Inter-node encryption disabled (cluster traffic in plaintext)"
fi

# Check transparent data encryption (at rest)
if echo "$CASS_YAML_CONTENT" | grep -q "transparent_data_encryption_options"; then
  if echo "$CASS_YAML_CONTENT" | grep -A 5 "transparent_data_encryption_options:" | grep -q "enabled: true"; then
    register_check "Encryption at Rest" PASS "Transparent Data Encryption enabled"
  else
    register_check "Encryption at Rest" WARN "TDE not enabled (data stored unencrypted)"
  fi
else
  register_check "Encryption at Rest" WARN "No TDE configuration (available in DSE/Enterprise)"
fi

# === JMX Security ===
section "JMX Security"

# Check if JMX is configured
jmx_port=7199  # Default Cassandra JMX port

# Check if JMX port is listening
if command -v ss >/dev/null 2>&1; then
  jmx_listening=$(ss -ltn 2>/dev/null | grep -c ":${jmx_port}" || echo "0")
  if [[ "$jmx_listening" -gt 0 ]]; then
    register_check "JMX Port" PASS "JMX listening on port $jmx_port"

    # Check JMX binding address
    jmx_host=$(ss -ltn 2>/dev/null | grep ":${jmx_port}" | awk '{print $4}' | cut -d: -f1 || echo "")
    if [[ "$jmx_host" == "127.0.0.1" || "$jmx_host" == "::1" ]]; then
      register_check "JMX Binding" PASS "JMX bound to localhost (secure)"
    elif [[ "$jmx_host" == "0.0.0.0" || "$jmx_host" == "::" ]]; then
      register_check "JMX Binding" WARN "JMX bound to all interfaces (restrict with firewall or localhost)"
    fi
  else
    register_check "JMX Port" WARN "JMX not listening (may be disabled or on custom port)"
  fi
fi

# Check JMX authentication
if [[ -f "/etc/cassandra/jmxremote.password" ]] || { [[ -n "$CASSANDRA_HOME" ]] && [[ -f "$CASSANDRA_HOME/conf/jmxremote.password" ]]; }; then
  # Search only in valid paths
  search_paths="/etc/cassandra"
  [[ -n "$CASSANDRA_HOME" ]] && search_paths="$search_paths $CASSANDRA_HOME/conf"

  jmx_pass_file=$(find $search_paths -name "jmxremote.password" 2>/dev/null -print -quit)
  register_check "JMX Authentication" PASS "jmxremote.password file found"

  # Check file permissions
  jmx_perms=$(stat -c '%a' "$jmx_pass_file" 2>/dev/null || stat -f '%Lp' "$jmx_pass_file" 2>/dev/null || echo "000")
  if [[ "$jmx_perms" == "600" ]]; then
    register_check "JMX Password Perms" PASS "permissions $jmx_perms (secure)"
  else
    register_check "JMX Password Perms" FAIL "permissions $jmx_perms (must be 600)"
  fi
else
  register_check "JMX Authentication" FAIL "No jmxremote.password file (JMX may be unauthenticated)"
fi

# === Data Directory Security ===
section "Data Directory Security"

# Find data directory
data_dir=$(get_cass_config "data_file_directories")
if [[ -z "$data_dir" ]]; then
  # Try default paths
  for path in "${CASSANDRA_DATA_PATHS[@]}"; do
    if [[ -d "$path/data" ]]; then
      data_dir="$path/data"
      break
    fi
  done
fi

if [[ -n "$data_dir" ]]; then
  data_dir=$(echo "$data_dir" | tr -d '[]' | awk '{print $1}')  # Handle array format

  if [[ -d "$data_dir" ]]; then
    register_check "Data Directory" PASS "$data_dir"

    # Check data directory permissions
    data_perms=$(stat -c '%a' "$data_dir" 2>/dev/null || stat -f '%Lp' "$data_dir" 2>/dev/null || echo "000")
    if [[ "$data_perms" =~ ^7[0-7]0$ ]]; then
      register_check "Data Dir Permissions" PASS "permissions $data_perms"
    else
      register_check "Data Dir Permissions" WARN "permissions $data_perms (ensure only cassandra user can access)"
    fi

    # Check data directory ownership
    data_owner=$(stat -c '%U' "$data_dir" 2>/dev/null || stat -f '%Su' "$data_dir" 2>/dev/null || echo "unknown")
    if [[ "$data_owner" == "cassandra" ]]; then
      register_check "Data Dir Owner" PASS "owned by cassandra user"
    else
      register_check "Data Dir Owner" WARN "owned by $data_owner (should be cassandra)"
    fi
  fi
else
  register_check "Data Directory" WARN "Data directory not found"
fi

# Check commitlog directory
commitlog_dir=$(get_cass_config "commitlog_directory")
if [[ -n "$commitlog_dir" && -d "$commitlog_dir" ]]; then
  register_check "Commitlog Directory" PASS "$commitlog_dir"
fi

# === Compaction & Performance ===
section "Compaction & Performance"

# Check compaction throughput
compaction_throughput=$(get_cass_config "compaction_throughput_mb_per_sec")
if [[ -n "$compaction_throughput" ]]; then
  register_check "Compaction Throughput" PASS "${compaction_throughput} MB/s"
fi

# Check concurrent compactors
concurrent_compactors=$(get_cass_config "concurrent_compactors")
if [[ -n "$concurrent_compactors" ]]; then
  register_check "Concurrent Compactors" PASS "$concurrent_compactors"
fi

# === Tombstone Settings ===
section "Tombstone Configuration"

# Check tombstone_warn_threshold
tombstone_warn=$(get_cass_config "tombstone_warn_threshold")
if [[ -n "$tombstone_warn" ]]; then
  register_check "Tombstone Warning" PASS "threshold: $tombstone_warn"
fi

# Check gc_grace_seconds (should be set)
gc_grace=$(get_cass_config "gc_grace_seconds")
if [[ -n "$gc_grace" ]]; then
  register_check "GC Grace Seconds" PASS "$gc_grace seconds"
fi

# === Backup Configuration ===
section "Backup & Recovery"

# Check for snapshot directory
if [[ -n "$data_dir" ]]; then
  snapshot_dir="$data_dir"
  # Snapshots are typically in keyspace/table/snapshots/
  snapshot_count=$(find "$snapshot_dir" -type d -name "snapshots" 2>/dev/null | wc -l || echo "0")

  if [[ "$snapshot_count" -gt 0 ]]; then
    register_check "Snapshot Capability" PASS "snapshot directories present"

    # Check for recent snapshots
    recent_snapshots=$(find "$snapshot_dir" -type d -name "snapshots" -mtime -7 2>/dev/null | wc -l || echo "0")
    if [[ "$recent_snapshots" -gt 0 ]]; then
      register_check "Recent Snapshots" PASS "$recent_snapshots snapshot(s) from last 7 days"
    else
      register_check "Recent Snapshots" WARN "No snapshots from last 7 days (run nodetool snapshot)"
    fi
  else
    register_check "Snapshots" WARN "No snapshot directories found (run nodetool snapshot for backups)"
  fi
fi

# === Process User ===
section "Process Security"

# Check Cassandra process user
cass_process=$(ps aux 2>/dev/null | grep "[o]rg.apache.cassandra" | head -n1 || echo "")
if [[ -n "$cass_process" ]]; then
  process_user=$(echo "$cass_process" | awk '{print $1}')

  if [[ "$process_user" == "root" ]]; then
    register_check "Process User" FAIL "Cassandra running as root (security risk)"
  elif [[ "$process_user" == "cassandra" ]]; then
    register_check "Process User" PASS "Cassandra running as cassandra user (secure)"
  else
    register_check "Process User" PASS "Cassandra running as $process_user (not root)"
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
