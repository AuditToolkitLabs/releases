#!/usr/bin/env bash
# MongoDB Security Audit (portable) - Performance Optimized
# Checks MongoDB configuration, authentication, authorization, network exposure, and security settings
#
# @elevation: partial
# @elevation-reason: Reads MongoDB config files and checks service status
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
MONGO_PORT=27017
MONGO_CONFIG_PATHS=(
  "/etc/mongod.conf"
  "/etc/mongodb.conf"
  "/usr/local/etc/mongod.conf"
  "/opt/mongodb/mongod.conf"
)

# === Performance: Cache variables ===
MONGO_CONFIG_FILE=""
MONGO_CONFIG_CONTENT=""
MONGO_SERVER_STATUS=""
MONGO_PID=""
SS_OUTPUT=""

# Helper function to find MongoDB config file (called once)
find_mongo_config() {
  if [[ -n "$MONGO_CONFIG_FILE" ]]; then
    echo "$MONGO_CONFIG_FILE"
    return 0
  fi

  for path in "${MONGO_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      MONGO_CONFIG_FILE="$path"
      # OPTIMIZATION: Read entire config into memory once
      MONGO_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# OPTIMIZED: Get MongoDB config value from cached YAML content
get_mongo_config() {
  local key="$1"

  if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
    # Parse YAML-style config (handles both old and new format)
    # Try dotted notation first (e.g., net.bindIp)
    local value
    value=$(echo "$MONGO_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}[[:space:]]*:" 2>/dev/null | head -n1 | sed 's/^[^:]*:[[:space:]]*//' | tr -d '"' || echo "")
    if [[ -z "$value" ]]; then
      # Try old-style key=value
      value=$(echo "$MONGO_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}[[:space:]]*=" 2>/dev/null | head -n1 | cut -d= -f2 | xargs || echo "")
    fi
    echo "$value"
  fi
}

# OPTIMIZED: Get network listening info (called once)
get_ss_output() {
  if [[ -n "$SS_OUTPUT" ]]; then
    echo "$SS_OUTPUT"
    return 0
  fi

  if command -v ss >/dev/null 2>&1; then
    SS_OUTPUT=$(ss -ltn 2>/dev/null || echo "")
  elif command -v netstat >/dev/null 2>&1; then
    SS_OUTPUT=$(netstat -ltn 2>/dev/null || echo "")
  else
    return 1
  fi

  echo "$SS_OUTPUT"
}

# OPTIMIZED: Get MongoDB process info (called once)
get_mongo_pid() {
  if [[ -z "$MONGO_PID" ]]; then
    MONGO_PID=$(pgrep -x mongod | head -n1 || echo "")
  fi
  echo "$MONGO_PID"
}

# OPTIMIZED: Get MongoDB server status (called once)
get_mongo_server_status() {
  if [[ -n "$MONGO_SERVER_STATUS" ]]; then
    echo "$MONGO_SERVER_STATUS"
    return 0
  fi

  # Try without authentication first
  if command -v mongo >/dev/null 2>&1; then
    MONGO_SERVER_STATUS=$(timeout 3 mongo --quiet --port "$MONGO_PORT" --eval "db.serverStatus()" 2>/dev/null || echo "")
  elif command -v mongosh >/dev/null 2>&1; then
    MONGO_SERVER_STATUS=$(timeout 3 mongosh --quiet --port "$MONGO_PORT" --eval "db.serverStatus()" 2>/dev/null || echo "")
  fi

  echo "$MONGO_SERVER_STATUS"
}

# Helper to execute MongoDB commands
mongo_eval() {
  local cmd="$1"
  local output=""

  if command -v mongosh >/dev/null 2>&1; then
    output=$(timeout 3 mongosh --quiet --port "$MONGO_PORT" --eval "$cmd" 2>/dev/null || echo "")
  elif command -v mongo >/dev/null 2>&1; then
    output=$(timeout 3 mongo --quiet --port "$MONGO_PORT" --eval "$cmd" 2>/dev/null || echo "")
  fi

  echo "$output"
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for MongoDB tools
tools=("mongod" "mongo" "mongosh")
for tool in "${tools[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    if [[ "$tool" == "mongod" ]]; then
      version_info=$("$tool" --version 2>/dev/null | head -n1 || echo "unknown")
    else
      version_info=$("$tool" --version 2>/dev/null | grep -E "version|MongoDB" | head -n1 || echo "unknown")
    fi
    register_check "Tool: $tool" PASS "$version_info"
  else
    register_check "Tool: $tool" WARN "not found"
  fi
done

# Check MongoDB service status
section "MongoDB Service Status"

service_names=("mongod" "mongodb")
service_found=false
service_active=false
service_enabled=false

for svc_name in "${service_names[@]}"; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Service $svc_name" PASS "running"
    service_active=true
    service_found=true
  fi
  if svc_is_enabled "$svc_name" 2>/dev/null; then
    service_enabled=true
  fi
done

if [[ "$service_found" == false ]]; then
  # Check if mongod is running as a process
  mongo_pid=$(get_mongo_pid)
  if [[ -n "$mongo_pid" ]]; then
    register_check "MongoDB process" PASS "running (PID: $mongo_pid)"
    service_active=true
  else
    register_check "MongoDB service" WARN "no running MongoDB instance detected"
  fi
fi

if [[ "$service_enabled" == true ]]; then
  register_check "Enabled at boot" PASS "yes"
elif [[ "$service_active" == true ]]; then
  register_check "Enabled at boot" WARN "service running but not enabled"
fi

# MongoDB Server Information
section "MongoDB Server Information"

# OPTIMIZATION: Get server status once and parse multiple values
server_status=$(get_mongo_server_status)

if [[ -n "$server_status" ]]; then
  register_check "MongoDB connectivity" PASS "server responds"

  # Parse version
  version=$(echo "$server_status" | grep -oP '"version"\s*:\s*"\K[^"]+' || echo "")
  if [[ -n "$version" ]]; then
    register_check "MongoDB version" PASS "$version"

    # Check if version is outdated (< 4.4 is EOL)
    major_version=$(echo "$version" | cut -d. -f1)
    if [[ "$major_version" -lt 4 ]]; then
      register_check "MongoDB version support" FAIL "version $version is end-of-life"
    elif [[ "$major_version" -eq 4 ]]; then
      minor_version=$(echo "$version" | cut -d. -f2)
      if [[ "$minor_version" -lt 4 ]]; then
        register_check "MongoDB version support" WARN "version $version approaching EOL"
      fi
    fi
  fi

  # Parse uptime
  uptime=$(echo "$server_status" | grep -oP '"uptime"\s*:\s*\K[0-9]+' | head -n1 || echo "")
  if [[ -n "$uptime" ]]; then
    uptime_days=$((uptime / 86400))
    register_check "MongoDB uptime" PASS "$uptime_days days"
  fi

  # Check connection count
  connections=$(echo "$server_status" | grep -oP '"current"\s*:\s*\K[0-9]+' || echo "")
  if [[ -n "$connections" ]]; then
    if [[ "$connections" -lt 100 ]]; then
      register_check "Active connections" PASS "$connections"
    elif [[ "$connections" -lt 500 ]]; then
      register_check "Active connections" WARN "$connections (monitor closely)"
    else
      register_check "Active connections" FAIL "$connections (possible resource exhaustion)"
    fi
  fi
else
  # Try auth-required check
  auth_check=$(mongo_eval "db.adminCommand({connectionStatus: 1})" | grep -i "authentication\|unauthorized" || echo "")
  if [[ -n "$auth_check" ]]; then
    register_check "MongoDB connectivity" WARN "authentication required (good for security, limits audit)"
  else
    register_check "MongoDB connectivity" FAIL "cannot connect to MongoDB on port $MONGO_PORT"
  fi
fi

# Configuration file checks
section "MongoDB Configuration File"

mongo_config=$(find_mongo_config || echo "")

if [[ -n "$mongo_config" ]]; then
  register_check "Config file" PASS "$mongo_config"

  # Check file permissions
  if [[ -r "$mongo_config" ]]; then
    perms=$(stat -c "%a" "$mongo_config" 2>/dev/null || stat -f "%Lp" "$mongo_config" 2>/dev/null || echo "unknown")
    if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]]; then
      register_check "Config file permissions" PASS "$perms"
    elif [[ "$perms" == "644" ]] || [[ "$perms" == "664" ]]; then
      register_check "Config file permissions" WARN "$perms (world-readable)"
    else
      register_check "Config file permissions" WARN "$perms"
    fi

    # Check ownership
    owner=$(stat -c "%U" "$mongo_config" 2>/dev/null || stat -f "%Su" "$mongo_config" 2>/dev/null || echo "unknown")
    if [[ "$owner" == "mongodb" ]] || [[ "$owner" == "mongod" ]] || [[ "$owner" == "root" ]]; then
      register_check "Config file owner" PASS "$owner"
    else
      register_check "Config file owner" WARN "$owner (expected mongodb/mongod/root)"
    fi
  else
    register_check "Config file permissions" FAIL "cannot read config file"
  fi
else
  register_check "Config file" WARN "not found in standard locations"
fi

# Network Security
section "Network Security"

# OPTIMIZATION: Get ss output once
ss_output=$(get_ss_output || echo "")

if [[ -n "$ss_output" ]]; then
  listen_output=$(echo "$ss_output" | grep ":$MONGO_PORT" || echo "")

  if [[ -n "$listen_output" ]]; then
    # Check if bound to all interfaces
    if echo "$listen_output" | grep -qE "(0\.0\.0\.0|\*|::|\[::\]):$MONGO_PORT"; then
      register_check "Network binding" FAIL "listening on all interfaces (0.0.0.0) - SECURITY RISK"
    else
      bind_addr=$(echo "$listen_output" | awk '{print $4}' | head -n1 | cut -d: -f1)
      register_check "Network binding" PASS "bound to specific interface ($bind_addr)"
    fi
  else
    register_check "Port $MONGO_PORT" WARN "not detected in listening ports"
  fi
else
  register_check "Network check" SKIP "ss/netstat not available"
fi

# Check bindIp in config
if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
  # Check both old and new YAML format
  bind_ip=$(get_mongo_config "bindIp" || get_mongo_config "net.bindIp" || echo "")

  if [[ -n "$bind_ip" ]]; then
    if [[ "$bind_ip" == *"0.0.0.0"* ]] || [[ "$bind_ip" == *"::"* ]]; then
      register_check "bindIp directive" FAIL "configured to bind all interfaces: $bind_ip"
    elif [[ "$bind_ip" == *"127.0.0.1"* ]] || [[ "$bind_ip" == *"localhost"* ]]; then
      register_check "bindIp directive" PASS "restricted to localhost: $bind_ip"
    else
      register_check "bindIp directive" PASS "$bind_ip"
    fi
  else
    register_check "bindIp directive" WARN "not configured (may bind to all interfaces by default)"
  fi

  # Check if TLS/SSL is enabled
  tls_mode=$(get_mongo_config "net.tls.mode" || get_mongo_config "sslMode" || echo "")
  if [[ -n "$tls_mode" ]]; then
    if [[ "$tls_mode" =~ requireSSL|requireTLS ]]; then
      register_check "TLS/SSL mode" PASS "$tls_mode"
    elif [[ "$tls_mode" =~ preferSSL|preferTLS ]]; then
      register_check "TLS/SSL mode" WARN "$tls_mode (not enforced for all connections)"
    else
      register_check "TLS/SSL mode" FAIL "$tls_mode (SSL/TLS not required)"
    fi
  else
    register_check "TLS/SSL" WARN "not configured (unencrypted connections allowed)"
  fi
fi

# Authentication & Authorization
section "Authentication & Authorization"

if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
  # Check security.authorization
  authorization=$(get_mongo_config "security.authorization" || get_mongo_config "authorization" || echo "")

  if [[ "$authorization" == "enabled" ]] || [[ "$authorization" == "true" ]]; then
    register_check "Authorization" PASS "enabled"
  else
    register_check "Authorization" FAIL "disabled - MongoDB has NO authentication/authorization"
  fi

  # Check authentication mechanisms
  auth_mechanisms=$(get_mongo_config "security.authenticationMechanisms" || echo "")
  if [[ -n "$auth_mechanisms" ]]; then
    if [[ "$auth_mechanisms" =~ SCRAM-SHA-256 ]]; then
      register_check "Auth mechanism" PASS "SCRAM-SHA-256 enabled"
    elif [[ "$auth_mechanisms" =~ SCRAM-SHA-1 ]]; then
      register_check "Auth mechanism" WARN "SCRAM-SHA-1 (consider upgrading to SHA-256)"
    else
      register_check "Auth mechanism" WARN "$auth_mechanisms"
    fi
  fi

  # Check keyFile for replica sets
  key_file=$(get_mongo_config "security.keyFile" || get_mongo_config "keyFile" || echo "")
  if [[ -n "$key_file" ]]; then
    if [[ -f "$key_file" ]]; then
      key_perms=$(stat -c "%a" "$key_file" 2>/dev/null || stat -f "%Lp" "$key_file" 2>/dev/null || echo "unknown")
      if [[ "$key_perms" == "400" ]] || [[ "$key_perms" == "600" ]]; then
        register_check "Replica set keyFile" PASS "$key_file (perms: $key_perms)"
      else
        register_check "Replica set keyFile" FAIL "$key_file (perms: $key_perms, must be 400 or 600)"
      fi
    else
      register_check "Replica set keyFile" FAIL "configured but file not found: $key_file"
    fi
  fi
else
  register_check "Authentication check" SKIP "config file not found"
fi

# Try to check users (may require auth)
user_check=$(mongo_eval "db.getUsers()" 2>/dev/null || echo "")
if [[ -n "$user_check" ]] && [[ ! "$user_check" =~ "not authorized" ]]; then
  user_count=$(echo "$user_check" | grep -c "user" || echo "0")
  if [[ "$user_count" -gt 0 ]]; then
    register_check "Database users" PASS "$user_count user(s) defined"
  else
    register_check "Database users" WARN "no users found (authentication may not be properly configured)"
  fi
else
  register_check "Database users" SKIP "cannot query (authentication required or no permission)"
fi

# Logging & Auditing
section "Logging & Auditing"

if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
  # Check log destination
  log_destination=$(get_mongo_config "systemLog.destination" || get_mongo_config "logpath" || echo "")
  if [[ -n "$log_destination" ]]; then
    if [[ "$log_destination" == "file" ]] || [[ -f "$log_destination" ]]; then
      register_check "Logging" PASS "configured"

      # Get log path if destination is file
      log_path=$(get_mongo_config "systemLog.path" || get_mongo_config "logpath" || echo "")
      if [[ -n "$log_path" ]]; then
        if [[ -f "$log_path" ]]; then
          register_check "Log file" PASS "$log_path"
        else
          register_check "Log file" WARN "$log_path (file not found)"
        fi
      fi
    elif [[ "$log_destination" == "syslog" ]]; then
      register_check "Logging" PASS "syslog"
    fi
  else
    register_check "Logging" WARN "not explicitly configured"
  fi

  # Check log verbosity
  verbosity=$(get_mongo_config "systemLog.verbosity" || echo "")
  if [[ -n "$verbosity" ]]; then
    if [[ "$verbosity" -ge 1 ]]; then
      register_check "Log verbosity" PASS "level $verbosity"
    else
      register_check "Log verbosity" WARN "level $verbosity (consider increasing for better visibility)"
    fi
  fi

  # Check if auditing is enabled (Enterprise feature)
  audit_destination=$(get_mongo_config "auditLog.destination" || echo "")
  if [[ -n "$audit_destination" ]]; then
    register_check "Audit logging" PASS "enabled ($audit_destination)"
  else
    register_check "Audit logging" WARN "not configured (Enterprise feature)"
  fi
else
  register_check "Logging check" SKIP "config file not found"
fi

# Data Protection
section "Data Protection & Storage"

if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
  # Check dbPath
  db_path=$(get_mongo_config "storage.dbPath" || get_mongo_config "dbpath" || echo "")
  if [[ -n "$db_path" ]]; then
    if [[ -d "$db_path" ]]; then
      db_perms=$(stat -c "%a" "$db_path" 2>/dev/null || stat -f "%Lp" "$db_path" 2>/dev/null || echo "unknown")
      db_owner=$(stat -c "%U" "$db_path" 2>/dev/null || stat -f "%Su" "$db_path" 2>/dev/null || echo "unknown")

      if [[ "$db_perms" == "700" ]] || [[ "$db_perms" == "750" ]]; then
        register_check "Data directory" PASS "$db_path (perms: $db_perms, owner: $db_owner)"
      else
        register_check "Data directory" WARN "$db_path (perms: $db_perms, should be 700 or 750)"
      fi
    else
      register_check "Data directory" FAIL "$db_path does not exist"
    fi
  else
    register_check "Data directory" WARN "not configured"
  fi

  # Check storage engine
  storage_engine=$(get_mongo_config "storage.engine" || echo "")
  if [[ -n "$storage_engine" ]]; then
    if [[ "$storage_engine" == "wiredTiger" ]]; then
      register_check "Storage engine" PASS "WiredTiger (recommended)"
    else
      register_check "Storage engine" WARN "$storage_engine (WiredTiger is recommended)"
    fi
  fi

  # Check journal
  journal=$(get_mongo_config "storage.journal.enabled" || get_mongo_config "journal" || echo "")
  if [[ "$journal" == "true" ]] || [[ -z "$journal" ]]; then
    register_check "Journaling" PASS "enabled (default)"
  else
    register_check "Journaling" FAIL "disabled (data loss risk)"
  fi

  # Check encryption at rest (Enterprise feature)
  encryption=$(get_mongo_config "security.enableEncryption" || echo "")
  if [[ "$encryption" == "true" ]]; then
    register_check "Encryption at rest" PASS "enabled (Enterprise)"
  else
    register_check "Encryption at rest" WARN "not enabled (Enterprise feature)"
  fi
else
  register_check "Storage check" SKIP "config file not found"
fi

# Security Settings
section "Additional Security Settings"

if [[ -n "$MONGO_CONFIG_CONTENT" ]]; then
  # Check JavaScript execution
  js_enabled=$(get_mongo_config "security.javascriptEnabled" || echo "")
  if [[ "$js_enabled" == "false" ]]; then
    register_check "JavaScript execution" PASS "disabled (more secure)"
  else
    register_check "JavaScript execution" WARN "enabled (potential security risk)"
  fi

  # Check direct shard operations
  direct_shard=$(get_mongo_config "sharding.clusterRole" || echo "")
  if [[ "$direct_shard" == "shardsvr" ]]; then
    register_check "Shard configuration" PASS "configured as shard server"
  fi

  # Check if running in quiet mode (less logging)
  quiet=$(get_mongo_config "systemLog.quiet" || get_mongo_config "quiet" || echo "")
  if [[ "$quiet" == "true" ]]; then
    register_check "Quiet mode" WARN "enabled (reduces logging visibility)"
  else
    register_check "Quiet mode" PASS "disabled (full logging)"
  fi

  # Check process owner
  mongo_pid=$(get_mongo_pid)
  if [[ -n "$mongo_pid" ]]; then
    mongo_user=$(ps -o user= -p "$mongo_pid" 2>/dev/null || echo "unknown")
    if [[ "$mongo_user" == "mongodb" ]] || [[ "$mongo_user" == "mongod" ]]; then
      register_check "Process user" PASS "$mongo_user"
    elif [[ "$mongo_user" == "root" ]]; then
      register_check "Process user" FAIL "running as root - SECURITY RISK"
    else
      register_check "Process user" WARN "$mongo_user (expected 'mongodb' or 'mongod')"
    fi
  fi
else
  register_check "Security settings" SKIP "config file not found"
fi

# Package installation check
section "MongoDB Package"
if pkg_installed "mongodb" || pkg_installed "mongodb-org" || pkg_installed "mongodb-server"; then
  register_check "MongoDB package" PASS "installed"
else
  register_check "MongoDB package" SKIP "not installed via package manager"
fi

# Print summary
print_summary
exit "$EXIT_CODE"
