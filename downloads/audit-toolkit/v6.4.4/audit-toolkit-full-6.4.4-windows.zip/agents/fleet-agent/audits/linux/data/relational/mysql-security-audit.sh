#!/usr/bin/env bash
# MySQL/MariaDB Security Audit (CIS MySQL Benchmark v1.0.0 aligned)
# Coverage: CIS 1.x-9.x, NIST SP 800-53, PCI DSS, ISO 27001
#
# @elevation: root
# @elevation-reason: Reads MySQL config files, data directory permissions
#
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="5.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
MYSQL_PORT=3306
LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED='\e[0;31m'; GREEN='\e[0;32m'; YELLOW='\e[0;33m'; BLUE='\e[0;34m'; CYAN='\e[0;36m'; BOLD='\e[1m'; NC='\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift||true; local msg="$*"; local ts line; ts="$(_timestamp)"; printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"; [[ "$QUIET" != "true" ]] && echo "$line"; [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local n="$1" r="$2" m="${3:-}"; ((++TOTAL_CHECKS)); case "$r" in PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}";; FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}";; WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}";; SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}";; esac; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true; }
check_root_register(){ local msg="${1:-Run as root for complete results}"; if [[ ${EUID:-$(id -u)} -ne 0 ]]; then register_check "Root privileges" WARN "$msg"; return 1; else register_check "Root privileges" PASS "Running as root"; return 0; fi; }
section(){ local t="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}"; echo -e "${BOLD}${CYAN} $t${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}"; [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :; }

run_mysql(){ local q="$1"; mysql -NBe "$q" 2>/dev/null || return 1; }
DATADIR=""
MYSQL_CONFIG_PATHS=(/etc/mysql/my.cnf /etc/my.cnf /etc/mysql/mysql.conf.d/mysqld.cnf /etc/mysql/mariadb.conf.d/50-server.cnf)

# CIS 1.x - Operating System Level Configuration
cis_os_level(){ section "CIS 1.x - Operating System Level Configuration";

  # CIS 1.1 - Dedicated MySQL user
  if id mysql >/dev/null 2>&1; then
    local shell; shell=$(getent passwd mysql 2>/dev/null | cut -d: -f7 || echo "")
    if [[ "$shell" =~ (nologin|false) ]]; then
      register_check "CIS 1.1 - MySQL user shell" PASS "nologin ($shell)"
    else register_check "CIS 1.1 - MySQL user shell" WARN "interactive shell: $shell"; fi
  else register_check "CIS 1.1 - MySQL user" FAIL "user 'mysql' not found"; fi

  # CIS 1.2 - MySQL running as mysql user
  local mysql_proc_user; mysql_proc_user=$(ps -eo user,comm | grep -E 'mysqld|mariadbd' | awk '{print $1}' | head -1 || echo "")
  if [[ "$mysql_proc_user" == "mysql" ]]; then
    register_check "CIS 1.2 - Running as mysql user" PASS "yes"
  elif [[ -n "$mysql_proc_user" ]]; then
    register_check "CIS 1.2 - Running as mysql user" FAIL "running as $mysql_proc_user"
  else register_check "CIS 1.2 - Running as mysql user" SKIP "service not running"; fi

  # CIS 1.3 - MySQL not in PATH for shell users
  local default_path="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
  if echo "$default_path" | grep -qE 'mysql'; then
    register_check "CIS 1.3 - MySQL in default PATH" WARN "may be in PATH"
  else register_check "CIS 1.3 - MySQL in default PATH" PASS "not in default PATH"; fi

  # CIS 1.4 - MYSQL_PWD environment variable not set
  if [[ -n "${MYSQL_PWD:-}" ]]; then
    register_check "CIS 1.4 - MYSQL_PWD env var" FAIL "password exposed in environment"
  else register_check "CIS 1.4 - MYSQL_PWD env var" PASS "not set"; fi

  # CIS 1.5 - Interactive login disabled for mysql user
  if grep -q '^mysql:' /etc/shadow 2>/dev/null; then
    local pw; pw=$(grep '^mysql:' /etc/shadow | cut -d: -f2)
    if [[ "$pw" == "!" || "$pw" == "*" || "$pw" == "!!" ]]; then
      register_check "CIS 1.5 - MySQL account locked" PASS "locked"
    else register_check "CIS 1.5 - MySQL account locked" WARN "may have password"; fi
  else register_check "CIS 1.5 - MySQL account locked" SKIP "cannot read shadow"; fi

  # CIS 1.6 - Verify MySQL is latest version
  local ver; ver=$(run_mysql 'SELECT @@version;' 2>/dev/null || echo "")
  if [[ -n "$ver" ]]; then
    register_check "CIS 1.6 - MySQL version" PASS "$ver (verify latest)"
  else register_check "CIS 1.6 - MySQL version" SKIP "cannot query"; fi
}

# CIS 2.x - Installation and Planning
cis_installation(){ section "CIS 2.x - Installation & Planning";

  # CIS 2.1 - Backup policy (manual check)
  register_check "CIS 2.1 - Backup policy" WARN "verify backup strategy exists (manual)"

  # CIS 2.2 - Dedicated machine for MySQL
  local other_services; other_services=$(systemctl list-units --type=service --state=active 2>/dev/null | grep -vE 'mysql|mariadb|sshd|systemd|dbus|cron|rsyslog|NetworkManager' | wc -l || echo 0)
  if (( other_services > 10 )); then
    register_check "CIS 2.2 - Dedicated machine" WARN "$other_services other services running"
  else register_check "CIS 2.2 - Dedicated machine" PASS "few other services"; fi

  # CIS 2.3 - Test database removed
  local test_db; test_db=$(run_mysql "SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='test';" 2>/dev/null || echo "")
  if [[ -n "$test_db" ]]; then
    register_check "CIS 2.3 - Test database (CIS 1.3)" FAIL "exists - remove with DROP DATABASE test;"
  else register_check "CIS 2.3 - Test database (CIS 1.3)" PASS "not present"; fi

  # CIS 2.4 - Sample databases and users removed
  local sample_users; sample_users=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE user='';" 2>/dev/null || echo "0")
  if (( sample_users > 0 )); then
    register_check "CIS 2.4 - Anonymous users" FAIL "$sample_users anonymous user(s)"
  else register_check "CIS 2.4 - Anonymous users" PASS "none"; fi
}

# CIS 3.x - File System Permissions
cis_filesystem(){ section "CIS 3.x - File System Permissions";

  # Find datadir
  DATADIR=$(run_mysql 'SELECT @@datadir;' 2>/dev/null || echo "")
  [[ -z "$DATADIR" ]] && DATADIR="/var/lib/mysql"

  # CIS 3.1 - datadir ownership
  if [[ -d "$DATADIR" ]]; then
    local owner; owner=$(stat -c %U:%G "$DATADIR" 2>/dev/null || echo "?")
    if [[ "$owner" == "mysql:mysql" ]]; then
      register_check "CIS 3.1 - datadir ownership" PASS "$owner"
    else register_check "CIS 3.1 - datadir ownership" FAIL "$owner (should be mysql:mysql)"; fi
  else register_check "CIS 3.1 - datadir ownership" SKIP "datadir not found"; fi

  # CIS 3.2 - datadir permissions
  if [[ -d "$DATADIR" ]]; then
    local perms; perms=$(stat -c %a "$DATADIR" 2>/dev/null || echo "?")
    if [[ "$perms" == "750" || "$perms" == "700" ]]; then
      register_check "CIS 3.2 - datadir permissions" PASS "$perms"
    else register_check "CIS 3.2 - datadir permissions" WARN "$perms (recommend 750)"; fi
  fi

  # CIS 3.3 - log_bin_basename permissions
  local binlog_base; binlog_base=$(run_mysql 'SELECT @@log_bin_basename;' 2>/dev/null || echo "")
  if [[ -n "$binlog_base" && "$binlog_base" != "NULL" ]]; then
    local binlog_dir; binlog_dir=$(dirname "$binlog_base")
    if [[ -d "$binlog_dir" ]]; then
      local bp; bp=$(stat -c %a "$binlog_dir" 2>/dev/null || echo "?")
      [[ "$bp" =~ ^7[05]0$ ]] && register_check "CIS 3.3 - binlog dir permissions" PASS "$bp" || register_check "CIS 3.3 - binlog dir permissions" WARN "$bp"
    fi
  else register_check "CIS 3.3 - binlog dir permissions" SKIP "binary logs not configured"; fi

  # CIS 3.4 - log_error permissions
  local error_log; error_log=$(run_mysql 'SELECT @@log_error;' 2>/dev/null || echo "")
  if [[ -n "$error_log" && -f "$error_log" ]]; then
    local ep; ep=$(stat -c %a "$error_log" 2>/dev/null || echo "?")
    if [[ "$ep" == "640" || "$ep" == "660" ]]; then
      register_check "CIS 3.4 - log_error permissions" PASS "$ep"
    else register_check "CIS 3.4 - log_error permissions" WARN "$ep (recommend 640)"; fi
  else register_check "CIS 3.4 - log_error permissions" SKIP "error log not found"; fi

  # CIS 3.5 - slow_query_log permissions
  local slow_log; slow_log=$(run_mysql 'SELECT @@slow_query_log_file;' 2>/dev/null || echo "")
  if [[ -n "$slow_log" && -f "$slow_log" ]]; then
    local sp; sp=$(stat -c %a "$slow_log" 2>/dev/null || echo "?")
    if [[ "$sp" == "640" || "$sp" == "660" ]]; then
      register_check "CIS 3.5 - slow_query_log permissions" PASS "$sp"
    else register_check "CIS 3.5 - slow_query_log permissions" WARN "$sp"; fi
  else register_check "CIS 3.5 - slow_query_log permissions" SKIP "slow log not found"; fi

  # CIS 3.6 - relay_log permissions
  local relay_log; relay_log=$(run_mysql 'SELECT @@relay_log_basename;' 2>/dev/null || echo "")
  if [[ -n "$relay_log" && "$relay_log" != "NULL" && -d "$(dirname "$relay_log")" ]]; then
    local rp; rp=$(stat -c %a "$(dirname "$relay_log")" 2>/dev/null || echo "?")
    register_check "CIS 3.6 - relay_log dir permissions" PASS "$rp"
  else register_check "CIS 3.6 - relay_log dir permissions" SKIP "relay logs not configured"; fi

  # CIS 3.7 - general_log permissions
  local gen_log; gen_log=$(run_mysql 'SELECT @@general_log_file;' 2>/dev/null || echo "")
  if [[ -n "$gen_log" && -f "$gen_log" ]]; then
    local gp; gp=$(stat -c %a "$gen_log" 2>/dev/null || echo "?")
    if [[ "$gp" == "640" || "$gp" == "660" ]]; then
      register_check "CIS 3.7 - general_log permissions" PASS "$gp"
    else register_check "CIS 3.7 - general_log permissions" WARN "$gp"; fi
  else register_check "CIS 3.7 - general_log permissions" SKIP "general log not enabled"; fi

  # CIS 3.8 - SSL key file permissions
  local ssl_key; ssl_key=$(run_mysql 'SELECT @@ssl_key;' 2>/dev/null || echo "")
  if [[ -n "$ssl_key" && "$ssl_key" != "NULL" && -f "$ssl_key" ]]; then
    local skp; skp=$(stat -c %a "$ssl_key" 2>/dev/null || echo "?")
    if [[ "$skp" == "400" || "$skp" == "600" ]]; then
      register_check "CIS 3.8 - SSL key permissions" PASS "$skp"
    else register_check "CIS 3.8 - SSL key permissions" FAIL "$skp (require 400/600)"; fi
  else register_check "CIS 3.8 - SSL key permissions" SKIP "SSL key not configured"; fi

  # CIS 3.9 - plugin directory permissions
  local plugin_dir; plugin_dir=$(run_mysql 'SELECT @@plugin_dir;' 2>/dev/null || echo "")
  if [[ -n "$plugin_dir" && -d "$plugin_dir" ]]; then
    local pp; pp=$(stat -c %a "$plugin_dir" 2>/dev/null || echo "?")
    local po; po=$(stat -c %U:%G "$plugin_dir" 2>/dev/null || echo "?")
    if [[ "$po" == "mysql:mysql" || "$po" == "root:root" ]] && [[ "$pp" =~ ^7[05]5$ ]]; then
      register_check "CIS 3.9 - plugin_dir permissions" PASS "$pp ($po)"
    else register_check "CIS 3.9 - plugin_dir permissions" WARN "$pp ($po)"; fi
  else register_check "CIS 3.9 - plugin_dir permissions" SKIP "plugin_dir not found"; fi
}

# CIS 4.x - General
cis_general(){ section "CIS 4.x - General Configuration";

  # CIS 4.1 - latest security patches
  register_check "CIS 4.1 - Security patches" WARN "verify latest patches applied (manual)"

  # CIS 4.2 - dedicated machine for MySQL (already checked)

  # CIS 4.3 - skip-symbolic-links
  local symbolic; symbolic=$(run_mysql 'SELECT @@have_symlink;' 2>/dev/null || echo "")
  if [[ "$symbolic" == "DISABLED" || "$symbolic" == "NO" ]]; then
    register_check "CIS 4.3 - skip-symbolic-links" PASS "symbolic links disabled"
  elif [[ -n "$symbolic" ]]; then
    register_check "CIS 4.3 - skip-symbolic-links" WARN "symbolic links: $symbolic"
  else register_check "CIS 4.3 - skip-symbolic-links" SKIP "cannot check"; fi

  # CIS 4.4 - local_infile disabled
  local linf; linf=$(run_mysql 'SELECT @@local_infile;' 2>/dev/null || echo "")
  if [[ "$linf" == "0" ]]; then
    register_check "CIS 4.4 - local_infile" PASS "disabled"
  elif [[ "$linf" == "1" ]]; then
    register_check "CIS 4.4 - local_infile" FAIL "enabled (CIS: disable)"
  else register_check "CIS 4.4 - local_infile" SKIP "unknown"; fi

  # CIS 4.5 - mysqld not started with --skip-grant-tables
  local skip_grants; skip_grants=$(run_mysql 'SELECT @@skip_grant_tables;' 2>/dev/null || echo "")
  if [[ "$skip_grants" == "0" || "$skip_grants" == "OFF" ]]; then
    register_check "CIS 4.5 - skip-grant-tables" PASS "not used"
  else register_check "CIS 4.5 - skip-grant-tables" FAIL "grant tables skipped!"; fi

  # CIS 4.6 - skip-show-database enabled
  local show_db; show_db=$(run_mysql 'SHOW VARIABLES LIKE "skip_show_database";' 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$show_db" == "ON" ]]; then
    register_check "CIS 4.6 - skip_show_database" PASS "enabled"
  else register_check "CIS 4.6 - skip_show_database" WARN "not enabled"; fi

  # CIS 4.7 - secure_file_priv configured
  local spriv; spriv=$(run_mysql 'SELECT @@secure_file_priv;' 2>/dev/null || echo "")
  if [[ -n "$spriv" && "$spriv" != "NULL" && "$spriv" != "" ]]; then
    register_check "CIS 4.7 - secure_file_priv" PASS "$spriv"
  else register_check "CIS 4.7 - secure_file_priv" WARN "not set or NULL"; fi

  # CIS 4.8 - sql_mode includes STRICT modes
  local sql_mode; sql_mode=$(run_mysql 'SELECT @@sql_mode;' 2>/dev/null || echo "")
  if echo "$sql_mode" | grep -qE 'STRICT_(TRANS|ALL)_TABLES'; then
    register_check "CIS 4.8 - sql_mode STRICT" PASS "strict mode enabled"
  else register_check "CIS 4.8 - sql_mode STRICT" WARN "strict mode not enabled"; fi
}

# CIS 5.x - MySQL Permissions
cis_permissions(){ section "CIS 5.x - MySQL Permissions";

  # CIS 5.1 - Only admin users have full DB access
  local super_users; super_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Super_priv='Y' AND user NOT IN ('root','mysql.sys','mysql.session','mysql.infoschema');" 2>/dev/null || echo "")
  if [[ -z "$super_users" ]]; then
    register_check "CIS 5.1 - Super privilege" PASS "only admin users have SUPER"
  else
    local count; count=$(echo "$super_users" | wc -l)
    register_check "CIS 5.1 - Super privilege" WARN "$count non-admin user(s) have SUPER"
  fi

  # CIS 5.2 - FILE privilege not granted to non-admin users
  local file_users; file_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE File_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$file_users" ]]; then
    register_check "CIS 5.2 - FILE privilege" PASS "restricted to root"
  else register_check "CIS 5.2 - FILE privilege" WARN "granted to non-root users"; fi

  # CIS 5.3 - PROCESS privilege restricted
  local process_users; process_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Process_priv='Y' AND user NOT IN ('root','mysql.sys');" 2>/dev/null || echo "")
  if [[ -z "$process_users" ]]; then
    register_check "CIS 5.3 - PROCESS privilege" PASS "restricted"
  else register_check "CIS 5.3 - PROCESS privilege" WARN "granted broadly"; fi

  # CIS 5.4 - RELOAD privilege restricted
  local reload_users; reload_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Reload_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$reload_users" ]]; then
    register_check "CIS 5.4 - RELOAD privilege" PASS "restricted to root"
  else register_check "CIS 5.4 - RELOAD privilege" WARN "granted to non-root"; fi

  # CIS 5.5 - SHUTDOWN privilege restricted
  local shutdown_users; shutdown_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Shutdown_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$shutdown_users" ]]; then
    register_check "CIS 5.5 - SHUTDOWN privilege" PASS "restricted to root"
  else register_check "CIS 5.5 - SHUTDOWN privilege" WARN "granted to non-root"; fi

  # CIS 5.6 - CREATE USER privilege restricted
  local create_user_users; create_user_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Create_user_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$create_user_users" ]]; then
    register_check "CIS 5.6 - CREATE USER privilege" PASS "restricted to root"
  else register_check "CIS 5.6 - CREATE USER privilege" WARN "granted to non-root"; fi

  # CIS 5.7 - GRANT privilege restricted
  local grant_users; grant_users=$(run_mysql "SELECT user,host FROM mysql.user WHERE Grant_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$grant_users" ]]; then
    register_check "CIS 5.7 - GRANT privilege" PASS "restricted to root"
  else register_check "CIS 5.7 - GRANT privilege" WARN "granted to non-root"; fi

  # CIS 5.8 - REPLICATION SLAVE privilege restricted
  local repl_slave; repl_slave=$(run_mysql "SELECT user,host FROM mysql.user WHERE Repl_slave_priv='Y' AND user NOT IN ('root');" 2>/dev/null || echo "")
  if [[ -z "$repl_slave" ]]; then
    register_check "CIS 5.8 - REPLICATION SLAVE privilege" PASS "restricted"
  else register_check "CIS 5.8 - REPLICATION SLAVE privilege" WARN "granted"; fi

  # CIS 5.9 - DML/DDL grants appropriate
  register_check "CIS 5.9 - DML/DDL grants" WARN "verify least privilege principle (manual)"
}

# CIS 6.x - Auditing and Logging
cis_auditing(){ section "CIS 6.x - Auditing & Logging";

  # CIS 6.1 - log_error configured
  local log_error; log_error=$(run_mysql 'SELECT @@log_error;' 2>/dev/null || echo "")
  if [[ -n "$log_error" && "$log_error" != "stderr" ]]; then
    register_check "CIS 6.1 - log_error enabled" PASS "$log_error"
  else register_check "CIS 6.1 - log_error enabled" WARN "logging to stderr"; fi

  # CIS 6.2 - log_error_verbosity
  local verbosity; verbosity=$(run_mysql 'SELECT @@log_error_verbosity;' 2>/dev/null || echo "")
  if [[ -n "$verbosity" ]]; then
    (( verbosity >= 2 )) && register_check "CIS 6.2 - log_error_verbosity" PASS "$verbosity" || register_check "CIS 6.2 - log_error_verbosity" WARN "$verbosity (recommend 2+)"
  else register_check "CIS 6.2 - log_error_verbosity" SKIP "cannot query"; fi

  # CIS 6.3 - audit plugin loaded (Enterprise)
  local audit_plugin; audit_plugin=$(run_mysql "SELECT PLUGIN_NAME FROM INFORMATION_SCHEMA.PLUGINS WHERE PLUGIN_NAME LIKE '%audit%';" 2>/dev/null || echo "")
  if [[ -n "$audit_plugin" ]]; then
    register_check "CIS 6.3 - Audit plugin" PASS "$audit_plugin"
  else register_check "CIS 6.3 - Audit plugin" WARN "not installed (Enterprise feature or MariaDB audit)"; fi

  # CIS 6.4 - slow_query_log
  local slow_log; slow_log=$(run_mysql 'SELECT @@slow_query_log;' 2>/dev/null || echo "")
  if [[ "$slow_log" == "1" || "$slow_log" == "ON" ]]; then
    register_check "CIS 6.4 - slow_query_log" PASS "enabled"
  else register_check "CIS 6.4 - slow_query_log" WARN "disabled"; fi

  # CIS 6.5 - log_queries_not_using_indexes
  local log_noidx; log_noidx=$(run_mysql 'SELECT @@log_queries_not_using_indexes;' 2>/dev/null || echo "")
  if [[ "$log_noidx" == "1" || "$log_noidx" == "ON" ]]; then
    register_check "CIS 6.5 - log_queries_not_using_indexes" PASS "enabled"
  else register_check "CIS 6.5 - log_queries_not_using_indexes" WARN "disabled"; fi

  # CIS 6.6 - general_log (should be OFF in production)
  local gen_log; gen_log=$(run_mysql 'SELECT @@general_log;' 2>/dev/null || echo "")
  if [[ "$gen_log" == "0" || "$gen_log" == "OFF" ]]; then
    register_check "CIS 6.6 - general_log (production)" PASS "disabled"
  else register_check "CIS 6.6 - general_log (production)" WARN "enabled (performance impact)"; fi

  # CIS 6.7 - Binary logging enabled
  local binlog; binlog=$(run_mysql 'SELECT @@log_bin;' 2>/dev/null || echo "")
  if [[ "$binlog" == "1" || "$binlog" == "ON" ]]; then
    register_check "CIS 6.7 - Binary logging" PASS "enabled"
  else register_check "CIS 6.7 - Binary logging" WARN "disabled (needed for replication/PITR)"; fi
}

# CIS 7.x - Authentication
cis_authentication(){ section "CIS 7.x - Authentication";
  local is_maria=false
  local product; product=$(run_mysql 'SELECT @@version_comment;' 2>/dev/null || echo "")
  [[ "$product" =~ [Mm]aria[Dd][Bb] ]] && is_maria=true

  # CIS 7.1 - default_authentication_plugin
  local auth_plugin; auth_plugin=$(run_mysql 'SELECT @@default_authentication_plugin;' 2>/dev/null || echo "")
  if [[ "$auth_plugin" == "caching_sha2_password" || "$auth_plugin" == "mysql_native_password" ]]; then
    register_check "CIS 7.1 - default_authentication_plugin" PASS "$auth_plugin"
  elif [[ -n "$auth_plugin" ]]; then
    register_check "CIS 7.1 - default_authentication_plugin" WARN "$auth_plugin"
  else register_check "CIS 7.1 - default_authentication_plugin" SKIP "cannot query"; fi

  # CIS 7.2 - Ensure passwords are not stored using old format
  local old_passwords; old_passwords=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE LENGTH(authentication_string) = 16;" 2>/dev/null || echo "0")
  if (( old_passwords > 0 )); then
    register_check "CIS 7.2 - Old password hashes" FAIL "$old_passwords user(s) with old hash"
  else register_check "CIS 7.2 - Old password hashes" PASS "none found"; fi

  # CIS 7.3 - Ensure passwords set for all accounts
  local empty_pass
  if $is_maria; then
    empty_pass=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE (authentication_string IS NULL OR authentication_string='') AND plugin NOT IN ('unix_socket');" 2>/dev/null || echo "0")
  else
    empty_pass=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE (authentication_string IS NULL OR authentication_string='') AND plugin NOT IN ('auth_socket','unix_socket','mysql_native_password');" 2>/dev/null || echo "0")
  fi
  if (( empty_pass > 0 )); then
    register_check "CIS 7.3 - Empty passwords" FAIL "$empty_pass user(s)"
  else register_check "CIS 7.3 - Empty passwords" PASS "none"; fi

  # CIS 7.4 - validate_password plugin
  local validate_pw; validate_pw=$(run_mysql "SELECT PLUGIN_NAME FROM INFORMATION_SCHEMA.PLUGINS WHERE PLUGIN_NAME='validate_password';" 2>/dev/null || echo "")
  if [[ -n "$validate_pw" ]]; then
    register_check "CIS 7.4 - validate_password plugin" PASS "installed"
    # Check password policy
    local policy; policy=$(run_mysql 'SELECT @@validate_password_policy;' 2>/dev/null || echo "")
    if [[ -n "$policy" ]]; then
      register_check "CIS 7.4a - Password policy" PASS "$policy"
    fi
  else register_check "CIS 7.4 - validate_password plugin" WARN "not installed"; fi

  # CIS 7.5 - No wildcard hostnames
  local wildcard_hosts; wildcard_hosts=$(run_mysql "SELECT user,host FROM mysql.user WHERE host='%';" 2>/dev/null || echo "")
  if [[ -n "$wildcard_hosts" ]]; then
    local count; count=$(echo "$wildcard_hosts" | wc -l)
    register_check "CIS 7.5 - Wildcard hostnames" WARN "$count user(s) with host='%'"
  else register_check "CIS 7.5 - Wildcard hostnames" PASS "none"; fi

  # CIS 7.6 - No anonymous accounts
  local anon; anon=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE user='';" 2>/dev/null || echo "0")
  if (( anon > 0 )); then
    register_check "CIS 7.6 - Anonymous accounts" FAIL "$anon account(s)"
  else register_check "CIS 7.6 - Anonymous accounts" PASS "none"; fi

  # CIS 7.7 - Remote root login disabled
  local remote_root; remote_root=$(run_mysql "SELECT COUNT(*) FROM mysql.user WHERE user='root' AND host NOT IN ('localhost','127.0.0.1','::1');" 2>/dev/null || echo "0")
  if (( remote_root > 0 )); then
    register_check "CIS 7.7 - Remote root login" FAIL "$remote_root entry(ies)"
  else register_check "CIS 7.7 - Remote root login" PASS "disabled"; fi
}

# CIS 8.x - Network
cis_network(){ section "CIS 8.x - Network Configuration";

  # CIS 8.1 - require_secure_transport
  local req_ssl; req_ssl=$(run_mysql 'SELECT @@require_secure_transport;' 2>/dev/null || echo "")
  if [[ "$req_ssl" == "1" || "$req_ssl" == "ON" ]]; then
    register_check "CIS 8.1 - require_secure_transport" PASS "enabled"
  else register_check "CIS 8.1 - require_secure_transport" WARN "disabled"; fi

  # CIS 8.2 - SSL/TLS configured
  local ssl_cipher; ssl_cipher=$(run_mysql "SHOW STATUS LIKE 'Ssl_cipher';" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$ssl_cipher" && "$ssl_cipher" != "" ]]; then
    register_check "CIS 8.2 - SSL/TLS active" PASS "cipher: $ssl_cipher"
  else
    local ssl_cert; ssl_cert=$(run_mysql 'SELECT @@ssl_cert;' 2>/dev/null || echo "")
    if [[ -n "$ssl_cert" && "$ssl_cert" != "NULL" ]]; then
      register_check "CIS 8.2 - SSL/TLS configured" PASS "cert: $ssl_cert"
    else register_check "CIS 8.2 - SSL/TLS" WARN "not configured"; fi
  fi

  # CIS 8.3 - bind-address not 0.0.0.0
  local bind_addr; bind_addr=$(run_mysql 'SELECT @@bind_address;' 2>/dev/null || echo "")
  if [[ "$bind_addr" == "127.0.0.1" || "$bind_addr" == "localhost" ]]; then
    register_check "CIS 8.3 - bind_address" PASS "$bind_addr"
  elif [[ "$bind_addr" == "*" || "$bind_addr" == "0.0.0.0" || "$bind_addr" == "::" ]]; then
    register_check "CIS 8.3 - bind_address" WARN "$bind_addr (listening on all interfaces)"
  else register_check "CIS 8.3 - bind_address" PASS "$bind_addr"; fi

  # Network exposure check
  if ! ss_listen >/dev/null 2>&1; then register_check "Network check" SKIP "no ss"; return 0; fi
  local out; out=$(ss -H -ltn "sport = :$MYSQL_PORT" 2>/dev/null || true)
  if [[ -n "$out" ]]; then
    local any=false
    while IFS= read -r line; do
      local addr; addr=$(awk '{print $4}' <<<"$line"); addr="${addr%:*}"
      [[ "$addr" =~ ^(0\.0\.0\.0|\*|::|\[::\])$ ]] && any=true
    done <<<"$out"
    if $any; then
      register_check "CIS 8.3a - Port $MYSQL_PORT binding" WARN "all interfaces"
    else register_check "CIS 8.3a - Port $MYSQL_PORT binding" PASS "specific interface"; fi
  fi
}

# CIS 9.x - Replication
cis_replication(){ section "CIS 9.x - Replication";

  # CIS 9.1 - MASTER_SSL_VERIFY_SERVER_CERT
  local repl_check; repl_check=$(run_mysql "SHOW SLAVE STATUS;" 2>/dev/null || echo "")
  if [[ -n "$repl_check" ]]; then
    if echo "$repl_check" | grep -qiE 'Master_SSL_Allowed.*Yes'; then
      register_check "CIS 9.1 - Replication SSL" PASS "SSL enabled"
    else register_check "CIS 9.1 - Replication SSL" WARN "SSL not enforced"; fi
  else register_check "CIS 9.1 - Replication" SKIP "not a replica"; fi

  # CIS 9.2 - Binary log encryption (8.0+)
  local binlog_enc; binlog_enc=$(run_mysql 'SELECT @@binlog_encryption;' 2>/dev/null || echo "")
  if [[ "$binlog_enc" == "ON" || "$binlog_enc" == "1" ]]; then
    register_check "CIS 9.2 - Binary log encryption" PASS "enabled"
  elif [[ -n "$binlog_enc" ]]; then
    register_check "CIS 9.2 - Binary log encryption" WARN "disabled"
  else register_check "CIS 9.2 - Binary log encryption" SKIP "not available (MySQL 8.0+ feature)"; fi
}

# Service status
service_status(){ section "Service Status";
  local names=(mysql mysqld mariadb mariadbd); local active=0 n
  for n in "${names[@]}"; do
    if svc_is_active "$n"; then register_check "Service $n" PASS "running"; ((active++)); fi
  done
  (( active==0 )) && register_check "Database service" WARN "no running MySQL/MariaDB detected"

  # Check enabled at boot
  local enabled=0
  for n in "${names[@]}"; do svc_is_enabled "$n" && ((enabled++)); done
  (( enabled>0 )) && register_check "Enabled at boot" PASS "yes" || register_check "Enabled at boot" WARN "no"
}

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
MySQL/MariaDB Security Audit - CIS MySQL Benchmark v1.0.0 aligned

Options:
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -p, --port N           Port (default: 3306)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug output
      --no-color         Disable color
  -h, --help             Show this help
      --version          Show version

CIS Sections Covered:
  1.x - Operating System Level Configuration
  2.x - Installation and Planning
  3.x - File System Permissions
  4.x - General Configuration
  5.x - MySQL Permissions
  6.x - Auditing and Logging
  7.x - Authentication
  8.x - Network Configuration
  9.x - Replication
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION (CIS MySQL Benchmark aligned)"; }

print_summary(){ echo; echo -e "${BOLD}MYSQL/MARIADB CIS SECURITY AUDIT SUMMARY${NC}"
  printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d\n" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
  echo; echo "Reference: CIS MySQL Benchmark v1.0.0, CIS MariaDB Benchmark, NIST SP 800-53"
}

main(){
  while [[ $# -gt 0 ]]; do case "$1" in
    -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;;
    -p|--port) MYSQL_PORT="${2:-3306}"; shift 2;;
    -q|--quiet) QUIET=true; shift;;
    -v|--verbose) VERBOSE=true; shift;;
    --no-color) NO_COLOR=true; shift;;
    -h|--help) usage; exit 0;;
    --version) version; exit 0;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 1;;
  esac; done

  setup_colors
  [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"

  check_root_register "Run as root for filesystem checks"
  service_status

  # Check if we can connect
  if ! command -v mysql >/dev/null 2>&1; then
    register_check "MySQL client" FAIL "not installed"
    print_summary; exit "$EXIT_CODE"
  fi

  cis_os_level
  cis_installation
  cis_filesystem
  cis_general
  cis_permissions
  cis_auditing
  cis_authentication
  cis_network
  cis_replication

  print_summary
  exit "$EXIT_CODE"
}
main "$@"
