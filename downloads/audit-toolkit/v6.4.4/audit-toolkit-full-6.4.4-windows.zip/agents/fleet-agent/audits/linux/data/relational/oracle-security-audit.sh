#!/usr/bin/env bash
# Oracle Database Security/Exposure Audit (portable, non-destructive)
#
# @elevation: partial
# @elevation-reason: Reads Oracle config files and checks service status
#
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
ORACLE_PORT=1521
LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED='\e[0;31m'; GREEN='\e[0;32m'; YELLOW='\e[0;33m'; BLUE='\e[0;34m'; CYAN='\e[0;36m'; BOLD='\e[1m'; NC='\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift||true; local msg="$*"; local ts line; ts="$(_timestamp)"; printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"; [[ "$QUIET" != "true" ]] && echo "$line"; [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local n="$1" r="$2" m="${3:-}"; ((++TOTAL_CHECKS)); case "$r" in PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}";; FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}";; WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}";; SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}";; esac; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true; }
check_root_register(){ local msg="${1:-Run as root for complete results}"; if [[ ${EUID:-$(id -u)} -ne 0 ]]; then register_check "Root privileges" WARN "$msg"; return 1; else register_check "Root privileges" PASS "Running as root"; return 0; fi; }
section(){ local t="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}"; echo -e "${BOLD}${CYAN} $t${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}"; [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :; }

# Locate sqlnet.ora
find_sqlnet(){
  local f
  if [[ -n "${TNS_ADMIN:-}" && -f "$TNS_ADMIN/sqlnet.ora" ]]; then echo "$TNS_ADMIN/sqlnet.ora"; return 0; fi
  if [[ -n "${ORACLE_HOME:-}" && -f "$ORACLE_HOME/network/admin/sqlnet.ora" ]]; then echo "$ORACLE_HOME/network/admin/sqlnet.ora"; return 0; fi
  for f in /etc/sqlnet.ora /opt/oracle/network/admin/sqlnet.ora /u01/app/oracle/product/*/network/admin/sqlnet.ora; do [[ -f "$f" ]] && { echo "$f"; return 0; }; done
  return 1
}

host_info(){ section "Host/Tools"; register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"; register_check "Date" PASS "$(date -Iseconds)";
  local tools=(sqlplus lsnrctl ss netstat);
  local t found=0; for t in "${tools[@]}"; do if command -v "$t" >/dev/null 2>&1; then register_check "Tool: $t" PASS "available"; ((found++)); else register_check "Tool: $t" SKIP "not found"; fi; done
  [[ $found -gt 0 ]] || register_check "Oracle tooling" WARN "none of sqlplus/lsnrctl found"; }

service_status(){ section "Oracle Services"; local units=(oracle-listener tnslsnr listener oracle-xe oracle-db); local active=0 enabled=0 u; for u in "${units[@]}"; do if svc_is_active "$u"; then register_check "Service $u" PASS "running"; ((active++)); else register_check "Service $u" SKIP "inactive"; fi; svc_is_enabled "$u" && ((enabled++)) || true; done
  # process heuristics
  pgrep -fa 'tnslsnr|oracle' >/dev/null 2>&1 && { register_check "Oracle processes" PASS "present"; ((active++)); } || register_check "Oracle processes" SKIP "none"
  (( enabled>0 )) && register_check "Enabled at boot" PASS "yes" || register_check "Enabled at boot" WARN "no"
}

listener_status(){ section "Listener Status"; if ! command -v lsnrctl >/dev/null 2>&1; then register_check "lsnrctl" SKIP "not installed"; return 0; fi
  local out; out=$(lsnrctl status 2>/dev/null || true)
  if echo "$out" | grep -qi 'STATUS of the LISTENER'; then register_check "Listener" PASS "running"; else register_check "Listener" WARN "not running"; fi
  # network binding
  if ss_listen >/dev/null; then local outp; outp=$(ss -H -ltn "sport = :$ORACLE_PORT" 2>/dev/null || true); if [[ -n "$outp" ]]; then local any=false; while IFS= read -r line; do local addr; addr=$(awk '{print $4}' <<<"$line"); addr="${addr%:*}"; [[ "$addr" =~ ^(0\.0\.0\.0|\*|::|\[::\])$ ]] && any=true; done <<<"$outp"; $any && register_check "Port $ORACLE_PORT binding" WARN "listening on all interfaces" || register_check "Port $ORACLE_PORT binding" PASS "bound to specific interface"; else register_check "Port $ORACLE_PORT" SKIP "not open"; fi; else register_check "Network check" SKIP "no ss/netstat"; fi
}

sqlnet_checks(){ section "sqlnet.ora (encryption)"; local f; if f=$(find_sqlnet); then register_check "sqlnet.ora" PASS "$f"; local encs encv; encs=$(grep -iE '^\s*SQLNET\.ENCRYPTION_SERVER\s*=\s*' "$f" 2>/dev/null | tail -n1 || true); encv=${encs#*=}; encv=${encv//[() ]/}; encv=${encv,,}; if [[ -n "$encv" ]]; then [[ "$encv" =~ required|requested ]] && register_check "SQLNET.ENCRYPTION_SERVER" PASS "$encv" || register_check "SQLNET.ENCRYPTION_SERVER" WARN "$encv"; else register_check "SQLNET.ENCRYPTION_SERVER" WARN "not set (defaults to ACCEPTED)"; fi
    local encc; encc=$(grep -iE '^\s*SQLNET\.ENCRYPTION_CLIENT\s*=\s*' "$f" 2>/dev/null | tail -n1 || true); local cv=${encc#*=}; cv=${cv//[() ]/}; cv=${cv,,}; if [[ -n "$cv" ]]; then [[ "$cv" =~ required|requested ]] && register_check "SQLNET.ENCRYPTION_CLIENT" PASS "$cv" || register_check "SQLNET.ENCRYPTION_CLIENT" WARN "$cv"; else register_check "SQLNET.ENCRYPTION_CLIENT" SKIP "not set"; fi
  else register_check "sqlnet.ora" SKIP "not found"; fi }

in_database_info(){ section "In-Database Info (best-effort)"; if ! command -v sqlplus >/dev/null 2>&1; then register_check "sqlplus" SKIP "not installed"; return 0; fi
  # Attempt local bequeath SYSDBA; do not fail if not permitted
  local ver; ver=$(echo "set heading off feedback off echo off
select banner from v$version where rownum=1;
exit;" | sqlplus -s / as sysdba 2>/dev/null || true)
  if [[ -n "$ver" ]]; then register_check "Database version" PASS "$(echo "$ver" | head -n1 | xargs)"; else register_check "Database version" SKIP "cannot query (auth required)"; fi
}

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Oracle DB listener/exposure & config audit (portable)
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -p, --port N           Listener port (default: 1521)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug output
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary(){ echo; echo -e "${BOLD}ORACLE DB AUDIT SUMMARY${NC}"; printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"; }

main(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;; -p|--port) ORACLE_PORT="${2:-1521}"; shift 2;; -q|--quiet) QUIET=true; shift;; -v|--verbose) VERBOSE=true; shift;; --no-color) NO_COLOR=true; shift;; -h|--help) usage; exit 0;; --version) version; exit 0;; *) echo "Unknown option: $1" >&2; usage >&2; exit 1;; esac; done
  setup_colors; [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  check_root_register "Run as root for complete results"
  host_info; service_status; listener_status; sqlnet_checks; in_database_info; print_summary; exit "$EXIT_CODE"
}
main "$@"
