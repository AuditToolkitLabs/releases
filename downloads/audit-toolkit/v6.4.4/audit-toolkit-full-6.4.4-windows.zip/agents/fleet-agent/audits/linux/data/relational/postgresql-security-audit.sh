#!/usr/bin/env bash
# PostgreSQL Security Audit (CIS PostgreSQL Benchmark v1.0.0 aligned)
# Coverage: CIS 1.x-8.x, NIST SP 800-53, PCI DSS, ISO 27001
#
# @elevation: root
# @elevation-reason: Reads PostgreSQL config files and data directory
#
set -euo pipefail
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="5.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
PG_PORT=5432
LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED='\e[0;31m'; GREEN='\e[0;32m'; YELLOW='\e[0;33m'; BLUE='\e[0;34m'; CYAN='\e[0;36m'; BOLD='\e[1m'; NC='\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift||true; local msg="$*"; local ts line; ts="$(_timestamp)"; printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"; [[ "$QUIET" != "true" ]] && echo "$line"; [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local n="$1" r="$2" m="${3:-}"; ((++TOTAL_CHECKS)); case "$r" in PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}";; FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}";; WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}";; SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}";; esac; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true; }
check_root_register(){ local msg="${1:-Full results require root}"; if [[ $EUID -ne 0 ]]; then register_check "Root privileges" WARN "$msg"; else register_check "Root privileges" PASS "root"; fi; }
section(){ local t="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}"; echo -e "${BOLD}${CYAN} $t${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}"; [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :; }

run_psql(){ local q="$1"; PSQL_OPTS=( -At -p "$PG_PORT" -c "$q" ); psql "${PSQL_OPTS[@]}" 2>/dev/null || return 1; }

# Find PostgreSQL data directory and config
PGDATA=""
PG_HBA=""
PG_CONF=""

find_pg_paths(){
  PGDATA=$(run_psql 'SHOW data_directory;' 2>/dev/null || echo "")
  [[ -z "$PGDATA" ]] && PGDATA="/var/lib/postgresql/data"
  [[ ! -d "$PGDATA" ]] && PGDATA="/var/lib/pgsql/data"

  PG_CONF=$(run_psql 'SHOW config_file;' 2>/dev/null || echo "")
  [[ -z "$PG_CONF" ]] && PG_CONF="$PGDATA/postgresql.conf"

  PG_HBA=$(run_psql 'SHOW hba_file;' 2>/dev/null || echo "")
  [[ -z "$PG_HBA" ]] && PG_HBA="$PGDATA/pg_hba.conf"
}

# CIS 1.x - Installation and Patches
cis_installation(){ section "CIS 1.x - Installation & Patches";

  # CIS 1.1 - Ensure PostgreSQL installed from trusted source
  if command -v psql >/dev/null 2>&1; then
    local ver; ver=$(psql --version 2>/dev/null | head -n1)
    register_check "CIS 1.1 - PostgreSQL installed" PASS "$ver"
  else
    register_check "CIS 1.1 - PostgreSQL installed" FAIL "psql not found"
    return 1
  fi

  # CIS 1.2 - Server version
  local srv_ver; srv_ver=$(run_psql 'SHOW server_version;' 2>/dev/null || echo "")
  if [[ -n "$srv_ver" ]]; then
    register_check "CIS 1.2 - Server version" PASS "$srv_ver"
  else
    register_check "CIS 1.2 - Server version" SKIP "cannot query (auth required?)"
  fi

  # CIS 1.3 - Ensure latest patches applied
  register_check "CIS 1.3 - Security patches" WARN "verify latest patches applied (manual)"

  # CIS 1.4 - pg_isready check
  if command -v pg_isready >/dev/null 2>&1; then
    if pg_isready -p "$PG_PORT" -q 2>/dev/null; then
      register_check "CIS 1.4 - pg_isready" PASS "server accepts connections"
    else
      register_check "CIS 1.4 - pg_isready" WARN "server not ready"
    fi
  else
    register_check "CIS 1.4 - pg_isready" SKIP "tool not found"
  fi

  # CIS 1.5 - PostgreSQL running as dedicated user
  local pg_proc_user; pg_proc_user=$(ps -eo user,comm | grep -E 'postgres|postmaster' | awk '{print $1}' | head -1 || echo "")
  if [[ "$pg_proc_user" == "postgres" ]]; then
    register_check "CIS 1.5 - Running as postgres user" PASS "yes"
  elif [[ -n "$pg_proc_user" ]]; then
    register_check "CIS 1.5 - Running as postgres user" FAIL "running as $pg_proc_user"
  else
    register_check "CIS 1.5 - Running as postgres user" SKIP "service not running"
  fi

  # CIS 1.6 - postgres user has nologin shell
  if id postgres >/dev/null 2>&1; then
    local shell; shell=$(getent passwd postgres 2>/dev/null | cut -d: -f7 || echo "")
    if [[ "$shell" =~ (nologin|false) ]]; then
      register_check "CIS 1.6 - postgres user shell" PASS "$shell"
    else
      register_check "CIS 1.6 - postgres user shell" WARN "interactive: $shell"
    fi
  else
    register_check "CIS 1.6 - postgres user" SKIP "user not found"
  fi
}

# CIS 2.x - Directory and File Permissions
cis_permissions(){ section "CIS 2.x - Directory & File Permissions";
  find_pg_paths

  # CIS 2.1 - Data directory ownership
  if [[ -d "$PGDATA" ]]; then
    local owner; owner=$(stat -c %U:%G "$PGDATA" 2>/dev/null || echo "?")
    if [[ "$owner" == "postgres:postgres" ]]; then
      register_check "CIS 2.1 - PGDATA ownership" PASS "$owner"
    else
      register_check "CIS 2.1 - PGDATA ownership" FAIL "$owner (should be postgres:postgres)"
    fi
  else
    register_check "CIS 2.1 - PGDATA ownership" SKIP "data directory not found"
  fi

  # CIS 2.2 - Data directory permissions (700)
  if [[ -d "$PGDATA" ]]; then
    local perms; perms=$(stat -c %a "$PGDATA" 2>/dev/null || echo "?")
    if [[ "$perms" == "700" ]]; then
      register_check "CIS 2.2 - PGDATA permissions" PASS "$perms"
    else
      register_check "CIS 2.2 - PGDATA permissions" WARN "$perms (recommend 700)"
    fi
  fi

  # CIS 2.3 - postgresql.conf ownership and permissions
  if [[ -f "$PG_CONF" ]]; then
    local cfowner; cfowner=$(stat -c %U:%G "$PG_CONF" 2>/dev/null || echo "?")
    local cfperms; cfperms=$(stat -c %a "$PG_CONF" 2>/dev/null || echo "?")
    if [[ "$cfowner" == "postgres:postgres" ]]; then
      register_check "CIS 2.3 - postgresql.conf ownership" PASS "$cfowner"
    else
      register_check "CIS 2.3 - postgresql.conf ownership" WARN "$cfowner"
    fi
    if [[ "$cfperms" == "600" || "$cfperms" == "640" ]]; then
      register_check "CIS 2.3a - postgresql.conf permissions" PASS "$cfperms"
    else
      register_check "CIS 2.3a - postgresql.conf permissions" WARN "$cfperms"
    fi
  else
    register_check "CIS 2.3 - postgresql.conf" SKIP "not found"
  fi

  # CIS 2.4 - pg_hba.conf ownership and permissions
  if [[ -f "$PG_HBA" ]]; then
    local hbaowner; hbaowner=$(stat -c %U:%G "$PG_HBA" 2>/dev/null || echo "?")
    local hbaperms; hbaperms=$(stat -c %a "$PG_HBA" 2>/dev/null || echo "?")
    if [[ "$hbaowner" == "postgres:postgres" ]]; then
      register_check "CIS 2.4 - pg_hba.conf ownership" PASS "$hbaowner"
    else
      register_check "CIS 2.4 - pg_hba.conf ownership" WARN "$hbaowner"
    fi
    if [[ "$hbaperms" == "600" || "$hbaperms" == "640" ]]; then
      register_check "CIS 2.4a - pg_hba.conf permissions" PASS "$hbaperms"
    else
      register_check "CIS 2.4a - pg_hba.conf permissions" WARN "$hbaperms"
    fi
  else
    register_check "CIS 2.4 - pg_hba.conf" SKIP "not found"
  fi

  # CIS 2.5 - SSL key file permissions
  local ssl_key; ssl_key=$(run_psql 'SHOW ssl_key_file;' 2>/dev/null || echo "")
  if [[ -n "$ssl_key" && -f "$ssl_key" ]]; then
    local skp; skp=$(stat -c %a "$ssl_key" 2>/dev/null || echo "?")
    if [[ "$skp" == "600" || "$skp" == "400" ]]; then
      register_check "CIS 2.5 - SSL key permissions" PASS "$skp"
    else
      register_check "CIS 2.5 - SSL key permissions" FAIL "$skp (require 600)"
    fi
  else
    register_check "CIS 2.5 - SSL key permissions" SKIP "SSL key not configured"
  fi

  # CIS 2.6 - Log directory permissions
  local log_dir; log_dir=$(run_psql 'SHOW log_directory;' 2>/dev/null || echo "")
  if [[ -n "$log_dir" ]]; then
    # Handle relative paths
    [[ "$log_dir" != /* ]] && log_dir="$PGDATA/$log_dir"
    if [[ -d "$log_dir" ]]; then
      local ldp; ldp=$(stat -c %a "$log_dir" 2>/dev/null || echo "?")
      if [[ "$ldp" == "700" ]]; then
        register_check "CIS 2.6 - Log directory permissions" PASS "$ldp"
      else
        register_check "CIS 2.6 - Log directory permissions" WARN "$ldp"
      fi
    fi
  else
    register_check "CIS 2.6 - Log directory" SKIP "not configured"
  fi
}

# CIS 3.x - Logging
cis_logging(){ section "CIS 3.x - Logging";

  # CIS 3.1 - logging_collector enabled
  local log_coll; log_coll=$(run_psql 'SHOW logging_collector;' 2>/dev/null || echo "")
  if [[ "$log_coll" == "on" ]]; then
    register_check "CIS 3.1 - logging_collector" PASS "enabled"
  elif [[ -n "$log_coll" ]]; then
    register_check "CIS 3.1 - logging_collector" WARN "$log_coll (recommend on)"
  else
    register_check "CIS 3.1 - logging_collector" SKIP "cannot query"
  fi

  # CIS 3.2 - log_destination
  local log_dest; log_dest=$(run_psql 'SHOW log_destination;' 2>/dev/null || echo "")
  if [[ -n "$log_dest" ]]; then
    register_check "CIS 3.2 - log_destination" PASS "$log_dest"
  else
    register_check "CIS 3.2 - log_destination" SKIP "cannot query"
  fi

  # CIS 3.3 - log_connections enabled
  local log_conn; log_conn=$(run_psql 'SHOW log_connections;' 2>/dev/null || echo "")
  if [[ "$log_conn" == "on" ]]; then
    register_check "CIS 3.3 - log_connections" PASS "enabled"
  elif [[ -n "$log_conn" ]]; then
    register_check "CIS 3.3 - log_connections" WARN "disabled"
  else
    register_check "CIS 3.3 - log_connections" SKIP "cannot query"
  fi

  # CIS 3.4 - log_disconnections enabled
  local log_disc; log_disc=$(run_psql 'SHOW log_disconnections;' 2>/dev/null || echo "")
  if [[ "$log_disc" == "on" ]]; then
    register_check "CIS 3.4 - log_disconnections" PASS "enabled"
  elif [[ -n "$log_disc" ]]; then
    register_check "CIS 3.4 - log_disconnections" WARN "disabled"
  else
    register_check "CIS 3.4 - log_disconnections" SKIP "cannot query"
  fi

  # CIS 3.5 - log_error_verbosity
  local log_verb; log_verb=$(run_psql 'SHOW log_error_verbosity;' 2>/dev/null || echo "")
  if [[ "$log_verb" == "verbose" || "$log_verb" == "default" ]]; then
    register_check "CIS 3.5 - log_error_verbosity" PASS "$log_verb"
  elif [[ -n "$log_verb" ]]; then
    register_check "CIS 3.5 - log_error_verbosity" WARN "$log_verb"
  else
    register_check "CIS 3.5 - log_error_verbosity" SKIP "cannot query"
  fi

  # CIS 3.6 - log_hostname
  local log_host; log_host=$(run_psql 'SHOW log_hostname;' 2>/dev/null || echo "")
  if [[ "$log_host" == "on" ]]; then
    register_check "CIS 3.6 - log_hostname" PASS "enabled (DNS overhead)"
  elif [[ -n "$log_host" ]]; then
    register_check "CIS 3.6 - log_hostname" WARN "disabled"
  else
    register_check "CIS 3.6 - log_hostname" SKIP "cannot query"
  fi

  # CIS 3.7 - log_line_prefix configured
  local log_prefix; log_prefix=$(run_psql 'SHOW log_line_prefix;' 2>/dev/null || echo "")
  if [[ -n "$log_prefix" && ${#log_prefix} -gt 5 ]]; then
    register_check "CIS 3.7 - log_line_prefix" PASS "configured"
  else
    register_check "CIS 3.7 - log_line_prefix" WARN "minimal or not configured"
  fi

  # CIS 3.8 - log_statement
  local log_stmt; log_stmt=$(run_psql 'SHOW log_statement;' 2>/dev/null || echo "")
  if [[ "$log_stmt" == "ddl" || "$log_stmt" == "mod" || "$log_stmt" == "all" ]]; then
    register_check "CIS 3.8 - log_statement" PASS "$log_stmt"
  elif [[ -n "$log_stmt" ]]; then
    register_check "CIS 3.8 - log_statement" WARN "$log_stmt (recommend ddl or higher)"
  else
    register_check "CIS 3.8 - log_statement" SKIP "cannot query"
  fi

  # CIS 3.9 - log_timezone
  local log_tz; log_tz=$(run_psql 'SHOW log_timezone;' 2>/dev/null || echo "")
  if [[ -n "$log_tz" ]]; then
    register_check "CIS 3.9 - log_timezone" PASS "$log_tz"
  else
    register_check "CIS 3.9 - log_timezone" SKIP "cannot query"
  fi

  # CIS 3.10 - pgaudit extension
  local pgaudit; pgaudit=$(run_psql "SELECT extname FROM pg_extension WHERE extname='pgaudit';" 2>/dev/null || echo "")
  if [[ -n "$pgaudit" ]]; then
    register_check "CIS 3.10 - pgaudit extension" PASS "installed"
  else
    register_check "CIS 3.10 - pgaudit extension" WARN "not installed (recommended for audit)"
  fi
}

# CIS 4.x - User Access Control
cis_user_access(){ section "CIS 4.x - User Access Control";

  # CIS 4.1 - Ensure superuser privileges are restricted
  local superusers; superusers=$(run_psql "SELECT rolname FROM pg_roles WHERE rolsuper=true;" 2>/dev/null || echo "")
  if [[ -n "$superusers" ]]; then
    local count; count=$(echo "$superusers" | wc -l)
    if (( count <= 2 )); then
      register_check "CIS 4.1 - Superuser count" PASS "$count superuser(s)"
    else
      register_check "CIS 4.1 - Superuser count" WARN "$count superusers (minimize)"
    fi
  else
    register_check "CIS 4.1 - Superuser count" SKIP "cannot query"
  fi

  # CIS 4.2 - Ensure password complexity is enforced
  local pw_enc; pw_enc=$(run_psql 'SHOW password_encryption;' 2>/dev/null || echo "")
  if [[ "$pw_enc" == "scram-sha-256" ]]; then
    register_check "CIS 4.2 - password_encryption" PASS "$pw_enc"
  elif [[ "$pw_enc" == "md5" ]]; then
    register_check "CIS 4.2 - password_encryption" WARN "$pw_enc (upgrade to scram-sha-256)"
  else
    register_check "CIS 4.2 - password_encryption" SKIP "cannot query"
  fi

  # CIS 4.3 - Ensure unnecessary default users removed
  local pub_role; pub_role=$(run_psql "SELECT rolname FROM pg_roles WHERE rolname='PUBLIC';" 2>/dev/null || echo "")
  register_check "CIS 4.3 - PUBLIC role grants" WARN "verify minimal grants to PUBLIC (manual)"

  # CIS 4.4 - Ensure authentication method is secure
  if [[ -f "$PG_HBA" ]]; then
    local trust_lines; trust_lines=$(grep -vE '^#|^$' "$PG_HBA" 2>/dev/null | grep -c 'trust' || echo "0")
    if (( trust_lines > 0 )); then
      register_check "CIS 4.4 - 'trust' auth in pg_hba.conf" FAIL "$trust_lines line(s) using trust"
    else
      register_check "CIS 4.4 - 'trust' auth in pg_hba.conf" PASS "no trust auth"
    fi

    # Check for password vs scram-sha-256
    local pw_auth; pw_auth=$(grep -vE '^#|^$' "$PG_HBA" 2>/dev/null | grep -cE 'md5|password' || echo "0")
    if (( pw_auth > 0 )); then
      register_check "CIS 4.4a - MD5/password auth" WARN "$pw_auth line(s) - upgrade to scram-sha-256"
    fi
  else
    register_check "CIS 4.4 - pg_hba.conf auth" SKIP "file not found"
  fi

  # CIS 4.5 - Ensure appropriate database ownership
  local db_owners; db_owners=$(run_psql "SELECT datname, pg_catalog.pg_get_userbyid(datdba) FROM pg_database WHERE datname NOT IN ('template0','template1');" 2>/dev/null || echo "")
  if [[ -n "$db_owners" ]]; then
    register_check "CIS 4.5 - Database owners" PASS "defined (verify appropriate)"
  else
    register_check "CIS 4.5 - Database owners" SKIP "cannot query"
  fi

  # CIS 4.6 - Ensure row-level security where needed
  register_check "CIS 4.6 - Row-level security" WARN "verify RLS where required (manual)"

  # CIS 4.7 - Ensure default privileges exist only for system objects
  register_check "CIS 4.7 - Default privileges" WARN "audit default privileges (manual)"
}

# CIS 5.x - Connection and Login
cis_connection(){ section "CIS 5.x - Connection & Login";

  # CIS 5.1 - SSL enabled
  local ssl; ssl=$(run_psql 'SHOW ssl;' 2>/dev/null || echo "")
  if [[ "$ssl" == "on" ]]; then
    register_check "CIS 5.1 - SSL enabled" PASS "yes"
  elif [[ -n "$ssl" ]]; then
    register_check "CIS 5.1 - SSL enabled" FAIL "disabled"
  else
    register_check "CIS 5.1 - SSL enabled" SKIP "cannot query"
  fi

  # CIS 5.2 - ssl_cert_file configured
  local ssl_cert; ssl_cert=$(run_psql 'SHOW ssl_cert_file;' 2>/dev/null || echo "")
  if [[ -n "$ssl_cert" && -f "$ssl_cert" ]]; then
    register_check "CIS 5.2 - SSL certificate" PASS "configured"
  elif [[ -n "$ssl_cert" ]]; then
    register_check "CIS 5.2 - SSL certificate" WARN "configured but file not found"
  else
    register_check "CIS 5.2 - SSL certificate" SKIP "not configured"
  fi

  # CIS 5.3 - listen_addresses is restricted
  local listen; listen=$(run_psql 'SHOW listen_addresses;' 2>/dev/null || echo "")
  if [[ "$listen" == "localhost" || "$listen" == "127.0.0.1" ]]; then
    register_check "CIS 5.3 - listen_addresses" PASS "$listen"
  elif [[ "$listen" == "*" ]]; then
    register_check "CIS 5.3 - listen_addresses" WARN "all interfaces ($listen)"
  elif [[ -n "$listen" ]]; then
    register_check "CIS 5.3 - listen_addresses" PASS "$listen"
  else
    register_check "CIS 5.3 - listen_addresses" SKIP "cannot query"
  fi

  # CIS 5.4 - Ensure max_connections is set appropriately
  local max_conn; max_conn=$(run_psql 'SHOW max_connections;' 2>/dev/null || echo "")
  if [[ -n "$max_conn" ]]; then
    if (( max_conn <= 200 )); then
      register_check "CIS 5.4 - max_connections" PASS "$max_conn"
    else
      register_check "CIS 5.4 - max_connections" WARN "$max_conn (consider reducing)"
    fi
  else
    register_check "CIS 5.4 - max_connections" SKIP "cannot query"
  fi

  # CIS 5.5 - connection_timeout (statement_timeout)
  local stmt_timeout; stmt_timeout=$(run_psql 'SHOW statement_timeout;' 2>/dev/null || echo "")
  if [[ -n "$stmt_timeout" && "$stmt_timeout" != "0" ]]; then
    register_check "CIS 5.5 - statement_timeout" PASS "$stmt_timeout"
  elif [[ "$stmt_timeout" == "0" ]]; then
    register_check "CIS 5.5 - statement_timeout" WARN "unlimited (consider setting)"
  else
    register_check "CIS 5.5 - statement_timeout" SKIP "cannot query"
  fi

  # Network exposure check
  if command -v ss >/dev/null 2>&1; then
    local out; out=$(ss -H -ltn "sport = :$PG_PORT" 2>/dev/null || true)
    if [[ -n "$out" ]]; then
      local any=false
      while IFS= read -r line; do
        local addr; addr=$(awk '{print $4}' <<<"$line"); addr="${addr%:*}"
        [[ "$addr" =~ ^(0\.0\.0\.0|\*|::|\[::\])$ ]] && any=true
      done <<<"$out"
      if $any; then
        register_check "CIS 5.3a - Port $PG_PORT binding" WARN "all interfaces"
      else
        register_check "CIS 5.3a - Port $PG_PORT binding" PASS "specific interface"
      fi
    else
      register_check "CIS 5.3a - Port $PG_PORT" PASS "not externally exposed"
    fi
  fi
}

# CIS 6.x - PostgreSQL Settings
cis_settings(){ section "CIS 6.x - PostgreSQL Settings";

  # CIS 6.1 - shared_preload_libraries (for extensions)
  local preload; preload=$(run_psql 'SHOW shared_preload_libraries;' 2>/dev/null || echo "")
  if [[ -n "$preload" ]]; then
    register_check "CIS 6.1 - shared_preload_libraries" PASS "$preload"
  else
    register_check "CIS 6.1 - shared_preload_libraries" WARN "empty"
  fi

  # CIS 6.2 - Ensure PLs are properly authorized
  local pls; pls=$(run_psql "SELECT lanname FROM pg_language WHERE lanpltrusted=false AND lanname != 'internal' AND lanname != 'c';" 2>/dev/null || echo "")
  if [[ -z "$pls" ]]; then
    register_check "CIS 6.2 - Untrusted PLs" PASS "none found"
  else
    register_check "CIS 6.2 - Untrusted PLs" WARN "found: $pls"
  fi

  # CIS 6.3 - Ensure WAL archiving is enabled (for backup)
  local archive_mode; archive_mode=$(run_psql 'SHOW archive_mode;' 2>/dev/null || echo "")
  if [[ "$archive_mode" == "on" || "$archive_mode" == "always" ]]; then
    register_check "CIS 6.3 - archive_mode" PASS "$archive_mode"
  elif [[ -n "$archive_mode" ]]; then
    register_check "CIS 6.3 - archive_mode" WARN "$archive_mode (recommended for PITR)"
  else
    register_check "CIS 6.3 - archive_mode" SKIP "cannot query"
  fi

  # CIS 6.4 - Ensure wal_level is appropriate
  local wal_level; wal_level=$(run_psql 'SHOW wal_level;' 2>/dev/null || echo "")
  if [[ "$wal_level" == "replica" || "$wal_level" == "logical" ]]; then
    register_check "CIS 6.4 - wal_level" PASS "$wal_level"
  elif [[ -n "$wal_level" ]]; then
    register_check "CIS 6.4 - wal_level" WARN "$wal_level"
  else
    register_check "CIS 6.4 - wal_level" SKIP "cannot query"
  fi

  # CIS 6.5 - hot_standby_feedback
  local hsf; hsf=$(run_psql 'SHOW hot_standby_feedback;' 2>/dev/null || echo "")
  if [[ -n "$hsf" ]]; then
    register_check "CIS 6.5 - hot_standby_feedback" PASS "$hsf"
  else
    register_check "CIS 6.5 - hot_standby_feedback" SKIP "cannot query"
  fi

  # CIS 6.6 - Ensure extensions are approved
  local exts; exts=$(run_psql "SELECT extname FROM pg_extension WHERE extname NOT IN ('plpgsql');" 2>/dev/null || echo "")
  if [[ -n "$exts" ]]; then
    register_check "CIS 6.6 - Custom extensions" WARN "verify approved: $exts"
  else
    register_check "CIS 6.6 - Custom extensions" PASS "none beyond plpgsql"
  fi
}

# CIS 7.x - Replication
cis_replication(){ section "CIS 7.x - Replication";

  # CIS 7.1 - Check if replication is enabled
  local repl_users; repl_users=$(run_psql "SELECT rolname FROM pg_roles WHERE rolreplication=true;" 2>/dev/null || echo "")
  if [[ -n "$repl_users" ]]; then
    local count; count=$(echo "$repl_users" | wc -l)
    register_check "CIS 7.1 - Replication users" PASS "$count user(s)"

    # CIS 7.2 - Replication requires SSL
    if [[ -f "$PG_HBA" ]]; then
      local repl_ssl; repl_ssl=$(grep -vE '^#|^$' "$PG_HBA" 2>/dev/null | grep 'replication' | grep -c 'hostssl' || echo "0")
      if (( repl_ssl > 0 )); then
        register_check "CIS 7.2 - Replication SSL" PASS "hostssl configured"
      else
        register_check "CIS 7.2 - Replication SSL" WARN "host (not hostssl) may be in use"
      fi
    fi
  else
    register_check "CIS 7.1 - Replication" SKIP "no replication users"
  fi

  # CIS 7.3 - max_wal_senders
  local max_senders; max_senders=$(run_psql 'SHOW max_wal_senders;' 2>/dev/null || echo "")
  if [[ -n "$max_senders" && "$max_senders" != "0" ]]; then
    register_check "CIS 7.3 - max_wal_senders" PASS "$max_senders"
  elif [[ "$max_senders" == "0" ]]; then
    register_check "CIS 7.3 - max_wal_senders" WARN "disabled"
  else
    register_check "CIS 7.3 - max_wal_senders" SKIP "cannot query"
  fi
}

# CIS 8.x - Special Configuration
cis_special(){ section "CIS 8.x - Special Configuration";

  # CIS 8.1 - Ensure proper version upgrade path
  register_check "CIS 8.1 - Version upgrade path" WARN "verify pg_upgrade tested (manual)"

  # CIS 8.2 - Ensure backups are configured
  local backup_script="/usr/local/bin/pg_backup.sh"
  if crontab -l 2>/dev/null | grep -qE 'pg_dump|pg_basebackup'; then
    register_check "CIS 8.2 - Automated backups" PASS "found in cron"
  else
    register_check "CIS 8.2 - Automated backups" WARN "no backup cron found"
  fi

  # CIS 8.3 - Ensure monitoring configured
  local pg_stat; pg_stat=$(run_psql "SELECT COUNT(*) FROM pg_stat_activity;" 2>/dev/null || echo "")
  if [[ -n "$pg_stat" ]]; then
    register_check "CIS 8.3 - pg_stat_activity accessible" PASS "monitoring possible"
  else
    register_check "CIS 8.3 - pg_stat_activity" SKIP "cannot query"
  fi

  # CIS 8.4 - temp_file_limit set
  local temp_limit; temp_limit=$(run_psql 'SHOW temp_file_limit;' 2>/dev/null || echo "")
  if [[ -n "$temp_limit" && "$temp_limit" != "-1" ]]; then
    register_check "CIS 8.4 - temp_file_limit" PASS "$temp_limit"
  elif [[ "$temp_limit" == "-1" ]]; then
    register_check "CIS 8.4 - temp_file_limit" WARN "unlimited"
  else
    register_check "CIS 8.4 - temp_file_limit" SKIP "cannot query"
  fi
}

# Service status
service_status(){ section "Service Status";
  local names=(postgresql postgresql@ postgresql-14 postgresql-15 postgresql-16 postgres)
  local active=0 enabled_any=0

  for n in "${names[@]}"; do
    if [[ "$n" == postgresql@ ]]; then
      if is_systemd; then
        while IFS= read -r u; do
          [[ -z "$u" ]] && continue
          if svc_is_active "$u"; then
            register_check "Service $u" PASS "running"
            ((active++))
          fi
        done < <(systemctl list-units --type=service --no-legend 2>/dev/null | awk '/postgresql@/ {print $1}')
      fi
    elif svc_is_active "$n"; then
      register_check "Service $n" PASS "running"
      ((active++))
    fi
    svc_is_enabled "$n" 2>/dev/null && ((enabled_any++)) || true
  done

  if (( active == 0 )); then
    register_check "PostgreSQL service" WARN "no running instance detected"
  fi

  if (( enabled_any > 0 )); then
    register_check "Enabled at boot" PASS "yes"
  else
    register_check "Enabled at boot" WARN "no"
  fi
}

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
PostgreSQL Security Audit - CIS PostgreSQL Benchmark v1.0.0 aligned

Options:
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -p, --port N           Port (default: 5432)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug output
      --no-color         Disable color
  -h, --help             Show this help
      --version          Show version

CIS Sections Covered:
  1.x - Installation and Patches
  2.x - Directory and File Permissions
  3.x - Logging
  4.x - User Access Control
  5.x - Connection and Login
  6.x - PostgreSQL Settings
  7.x - Replication
  8.x - Special Configuration
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION (CIS PostgreSQL Benchmark aligned)"; }

print_summary(){ echo; echo -e "${BOLD}POSTGRESQL CIS SECURITY AUDIT SUMMARY${NC}"
  printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d\n" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
  echo; echo "Reference: CIS PostgreSQL Benchmark v1.0.0, NIST SP 800-53"
}

main(){
  while [[ $# -gt 0 ]]; do case "$1" in
    -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;;
    -p|--port) PG_PORT="${2:-5432}"; shift 2;;
    -q|--quiet) QUIET=true; shift;;
    -v|--verbose) VERBOSE=true; shift;;
    --no-color) NO_COLOR=true; shift;;
    -h|--help) usage; exit 0;;
    --version) version; exit 0;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 1;;
  esac; done

  setup_colors
  [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"

  check_root_register "Run as root for filesystem checks"
  service_status

  cis_installation || { print_summary; exit "$EXIT_CODE"; }
  cis_permissions
  cis_logging
  cis_user_access
  cis_connection
  cis_settings
  cis_replication
  cis_special

  print_summary
  exit "$EXIT_CODE"
}
main "$@"
