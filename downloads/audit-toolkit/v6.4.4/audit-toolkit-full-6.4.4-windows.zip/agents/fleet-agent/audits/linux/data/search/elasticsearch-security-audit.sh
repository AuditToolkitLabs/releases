#!/usr/bin/env bash
# Elasticsearch Security Audit (portable) - Performance Optimized
# Checks Elasticsearch configuration, authentication, authorization, network exposure, and security settings
#
# @elevation: partial
# @elevation-reason: Reads Elasticsearch config files and checks service status
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
ES_PORT=9200
ES_CLUSTER_PORT=9300
ES_CONFIG_PATHS=(
  "/etc/elasticsearch/elasticsearch.yml"
  "/usr/share/elasticsearch/config/elasticsearch.yml"
  "/opt/elasticsearch/config/elasticsearch.yml"
)

# === Performance: Cache variables ===
ES_CONFIG_FILE=""
ES_CONFIG_CONTENT=""
ES_CLUSTER_HEALTH=""
ES_NODE_INFO=""
ES_PID=""
SS_OUTPUT=""
ES_VERSION=""

# Helper function to find Elasticsearch config file (called once)
find_es_config() {
  if [[ -n "$ES_CONFIG_FILE" ]]; then
    echo "$ES_CONFIG_FILE"
    return 0
  fi

  for path in "${ES_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      ES_CONFIG_FILE="$path"
      # OPTIMIZATION: Read entire config into memory once
      ES_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# OPTIMIZED: Get Elasticsearch config value from cached YAML content
get_es_config() {
  local key="$1"

  if [[ -n "$ES_CONFIG_CONTENT" ]]; then
    # Parse YAML-style config (handle dotted notation)
    local value
    value=$(echo "$ES_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}[[:space:]]*:" 2>/dev/null | head -n1 | sed 's/^[^:]*:[[:space:]]*//' | tr -d '"' | sed 's/#.*//' | xargs || echo "")
    echo "$value"
  fi
}

# OPTIMIZED: Get network listening info (called once)
get_ss_output() {
  if [[ -n "$SS_OUTPUT" ]]; then
    echo "$SS_OUTPUT"
    return 0
  fi

  if command -v ss >/dev/null 2>&1; then
    SS_OUTPUT=$(ss -ltn 2>/dev/null || echo "")
  elif command -v netstat >/dev/null 2>&1; then
    SS_OUTPUT=$(netstat -ltn 2>/dev/null || echo "")
  else
    return 1
  fi

  echo "$SS_OUTPUT"
}

# OPTIMIZED: Get Elasticsearch process info (called once)
get_es_pid() {
  if [[ -z "$ES_PID" ]]; then
    # Elasticsearch runs as Java process
    ES_PID=$(pgrep -f "org.elasticsearch.bootstrap.Elasticsearch" | head -n1 || echo "")
  fi
  echo "$ES_PID"
}

# OPTIMIZED: Get Elasticsearch cluster health (called once)
get_es_cluster_health() {
  if [[ -n "$ES_CLUSTER_HEALTH" ]]; then
    echo "$ES_CLUSTER_HEALTH"
    return 0
  fi

  # Try without authentication first
  ES_CLUSTER_HEALTH=$(timeout 3 curl -s -XGET "http://localhost:${ES_PORT}/_cluster/health" 2>/dev/null || echo "")
  echo "$ES_CLUSTER_HEALTH"
}

# OPTIMIZED: Get Elasticsearch node info (called once)
get_es_node_info() {
  if [[ -n "$ES_NODE_INFO" ]]; then
    echo "$ES_NODE_INFO"
    return 0
  fi

  ES_NODE_INFO=$(timeout 3 curl -s -XGET "http://localhost:${ES_PORT}/" 2>/dev/null || echo "")
  echo "$ES_NODE_INFO"
}

# Helper to check if X-Pack security is available
check_xpack_available() {
  local xpack_check
  xpack_check=$(timeout 3 curl -s -XGET "http://localhost:${ES_PORT}/_xpack" 2>/dev/null || echo "")
  if [[ -n "$xpack_check" ]] && [[ ! "$xpack_check" =~ "security_exception" ]]; then
    return 0
  fi
  return 1
}

# === AUDIT SECTIONS ===

section "Host Information"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Check for Elasticsearch tools
if command -v elasticsearch >/dev/null 2>&1; then
  version_info=$(elasticsearch --version 2>/dev/null | head -n1 || echo "unknown")
  register_check "Tool: elasticsearch" PASS "$version_info"
elif command -v java >/dev/null 2>&1; then
  java_version=$(java -version 2>&1 | head -n1 || echo "unknown")
  register_check "Tool: java" PASS "$java_version"
fi

# Check curl availability
if command -v curl >/dev/null 2>&1; then
  register_check "Tool: curl" PASS "available"
else
  register_check "Tool: curl" WARN "not found (needed for API checks)"
fi

# Check Elasticsearch service status
section "Elasticsearch Service Status"

service_names=("elasticsearch" "elasticsearch.service")
service_found=false
service_active=false
service_enabled=false

for svc_name in "${service_names[@]}"; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Service $svc_name" PASS "running"
    service_active=true
    service_found=true
  fi
  if svc_is_enabled "$svc_name" 2>/dev/null; then
    service_enabled=true
  fi
done

if [[ "$service_found" == false ]]; then
  # Check if Elasticsearch is running as a process
  es_pid=$(get_es_pid)
  if [[ -n "$es_pid" ]]; then
    register_check "Elasticsearch process" PASS "running (PID: $es_pid)"
    service_active=true
  else
    register_check "Elasticsearch service" WARN "no running Elasticsearch instance detected"
  fi
fi

if [[ "$service_enabled" == true ]]; then
  register_check "Enabled at boot" PASS "yes"
elif [[ "$service_active" == true ]]; then
  register_check "Enabled at boot" WARN "service running but not enabled"
fi

# Elasticsearch Cluster & Node Information
section "Elasticsearch Cluster Information"

# OPTIMIZATION: Get node info once and parse multiple values
node_info=$(get_es_node_info)

if [[ -n "$node_info" ]] && [[ "$node_info" =~ "cluster_name" ]]; then
  register_check "Elasticsearch connectivity" PASS "server responds"

  # Parse version
  ES_VERSION=$(echo "$node_info" | grep -oP '"number"\s*:\s*"\K[^"]+' | head -n1 || echo "")
  if [[ -n "$ES_VERSION" ]]; then
    register_check "Elasticsearch version" PASS "$ES_VERSION"

    # Check if version is outdated (< 7.17 or 8.x < 8.11 have known issues)
    major_version=$(echo "$ES_VERSION" | cut -d. -f1)
    if [[ "$major_version" -lt 7 ]]; then
      register_check "Elasticsearch version support" FAIL "version $ES_VERSION is end-of-life"
    elif [[ "$major_version" -eq 7 ]]; then
      minor_version=$(echo "$ES_VERSION" | cut -d. -f2)
      if [[ "$minor_version" -lt 17 ]]; then
        register_check "Elasticsearch version support" WARN "version $ES_VERSION may have security issues"
      fi
    fi
  fi

  # Parse cluster name
  cluster_name=$(echo "$node_info" | grep -oP '"cluster_name"\s*:\s*"\K[^"]+' || echo "")
  if [[ -n "$cluster_name" ]]; then
    if [[ "$cluster_name" == "elasticsearch" ]]; then
      register_check "Cluster name" WARN "using default cluster name (should be changed)"
    else
      register_check "Cluster name" PASS "$cluster_name"
    fi
  fi

  # Parse tagline to verify it's Elasticsearch
  tagline=$(echo "$node_info" | grep -oP '"tagline"\s*:\s*"\K[^"]+' || echo "")
  if [[ -n "$tagline" ]]; then
    register_check "Service type" PASS "$tagline"
  fi
else
  # Check if authentication is required
  auth_check=$(timeout 3 curl -s -w "%{http_code}" -o /dev/null "http://localhost:${ES_PORT}/" 2>/dev/null || echo "")
  if [[ "$auth_check" == "401" ]]; then
    register_check "Elasticsearch connectivity" WARN "authentication required (good for security, limits audit)"
  else
    register_check "Elasticsearch connectivity" FAIL "cannot connect to Elasticsearch on port $ES_PORT"
  fi
fi

# Cluster health check
if [[ -n "$node_info" ]] && [[ "$node_info" =~ "cluster_name" ]]; then
  cluster_health=$(get_es_cluster_health)
  if [[ -n "$cluster_health" ]] && [[ "$cluster_health" =~ "status" ]]; then
    health_status=$(echo "$cluster_health" | grep -oP '"status"\s*:\s*"\K[^"]+' || echo "")
    if [[ "$health_status" == "green" ]]; then
      register_check "Cluster health" PASS "green"
    elif [[ "$health_status" == "yellow" ]]; then
      register_check "Cluster health" WARN "yellow (replicas not allocated)"
    elif [[ "$health_status" == "red" ]]; then
      register_check "Cluster health" FAIL "red (primary shards unavailable)"
    fi

    # Parse node count
    num_nodes=$(echo "$cluster_health" | grep -oP '"number_of_nodes"\s*:\s*\K[0-9]+' || echo "")
    if [[ -n "$num_nodes" ]]; then
      register_check "Cluster nodes" PASS "$num_nodes node(s)"
    fi
  fi
fi

# Configuration file checks
section "Elasticsearch Configuration File"

es_config=$(find_es_config || echo "")

if [[ -n "$es_config" ]]; then
  register_check "Config file" PASS "$es_config"

  # Check file permissions
  if [[ -r "$es_config" ]]; then
    perms=$(stat -c "%a" "$es_config" 2>/dev/null || stat -f "%Lp" "$es_config" 2>/dev/null || echo "unknown")
    if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]] || [[ "$perms" == "660" ]]; then
      register_check "Config file permissions" PASS "$perms"
    elif [[ "$perms" == "644" ]] || [[ "$perms" == "664" ]]; then
      register_check "Config file permissions" WARN "$perms (world-readable)"
    else
      register_check "Config file permissions" WARN "$perms"
    fi

    # Check ownership
    owner=$(stat -c "%U" "$es_config" 2>/dev/null || stat -f "%Su" "$es_config" 2>/dev/null || echo "unknown")
    if [[ "$owner" == "elasticsearch" ]] || [[ "$owner" == "root" ]]; then
      register_check "Config file owner" PASS "$owner"
    else
      register_check "Config file owner" WARN "$owner (expected elasticsearch or root)"
    fi
  else
    register_check "Config file permissions" FAIL "cannot read config file"
  fi
else
  register_check "Config file" WARN "not found in standard locations"
fi

# Network Security
section "Network Security"

# OPTIMIZATION: Get ss output once
ss_output=$(get_ss_output || echo "")

if [[ -n "$ss_output" ]]; then
  # Check HTTP port
  listen_http=$(echo "$ss_output" | grep ":$ES_PORT" || echo "")
  if [[ -n "$listen_http" ]]; then
    if echo "$listen_http" | grep -qE "(0\.0\.0\.0|\*|::|\[::\]):$ES_PORT"; then
      register_check "HTTP port binding" FAIL "listening on all interfaces (0.0.0.0:$ES_PORT) - SECURITY RISK"
    else
      bind_addr=$(echo "$listen_http" | awk '{print $4}' | head -n1 | cut -d: -f1)
      register_check "HTTP port binding" PASS "bound to specific interface ($bind_addr:$ES_PORT)"
    fi
  else
    register_check "HTTP port $ES_PORT" WARN "not detected in listening ports"
  fi

  # Check transport/cluster port
  listen_cluster=$(echo "$ss_output" | grep ":$ES_CLUSTER_PORT" || echo "")
  if [[ -n "$listen_cluster" ]]; then
    if echo "$listen_cluster" | grep -qE "(0\.0\.0\.0|\*|::|\[::\]):$ES_CLUSTER_PORT"; then
      register_check "Transport port binding" WARN "listening on all interfaces (0.0.0.0:$ES_CLUSTER_PORT)"
    else
      register_check "Transport port binding" PASS "bound to specific interface"
    fi
  fi
else
  register_check "Network check" SKIP "ss/netstat not available"
fi

# Check network.host in config
if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  network_host=$(get_es_config "network.host")

  if [[ -n "$network_host" ]]; then
    if [[ "$network_host" == "0.0.0.0" ]] || [[ "$network_host" == "::" ]]; then
      register_check "network.host directive" FAIL "configured to bind all interfaces: $network_host"
    elif [[ "$network_host" == "localhost" ]] || [[ "$network_host" == "127.0.0.1" ]] || [[ "$network_host" == "_local_" ]]; then
      register_check "network.host directive" PASS "restricted to localhost: $network_host"
    else
      register_check "network.host directive" PASS "$network_host"
    fi
  else
    register_check "network.host directive" WARN "not configured (defaults to localhost in recent versions)"
  fi

  # Check HTTP host
  http_host=$(get_es_config "http.host")
  if [[ -n "$http_host" ]]; then
    if [[ "$http_host" == "0.0.0.0" ]]; then
      register_check "http.host directive" FAIL "bound to all interfaces"
    else
      register_check "http.host directive" PASS "$http_host"
    fi
  fi
fi

# X-Pack Security / Security Settings
section "Authentication & Authorization (X-Pack Security)"

if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  # Check if X-Pack security is enabled
  xpack_security=$(get_es_config "xpack.security.enabled")

  if [[ "$xpack_security" == "true" ]]; then
    register_check "X-Pack Security" PASS "enabled"
  elif [[ "$xpack_security" == "false" ]]; then
    register_check "X-Pack Security" FAIL "disabled - NO authentication/authorization"
  else
    # Try to detect from API
    if check_xpack_available; then
      register_check "X-Pack Security" WARN "X-Pack available but security status unclear"
    else
      register_check "X-Pack Security" FAIL "not configured - NO authentication"
    fi
  fi

  # Check TLS for HTTP
  xpack_http_ssl=$(get_es_config "xpack.security.http.ssl.enabled")
  if [[ "$xpack_http_ssl" == "true" ]]; then
    register_check "HTTP SSL/TLS" PASS "enabled"

    # Check certificate
    http_cert=$(get_es_config "xpack.security.http.ssl.certificate")
    if [[ -n "$http_cert" ]]; then
      if [[ -f "$http_cert" ]]; then
        register_check "HTTP SSL certificate" PASS "$http_cert"
      else
        register_check "HTTP SSL certificate" FAIL "configured but file not found: $http_cert"
      fi
    fi

    # Check key
    http_key=$(get_es_config "xpack.security.http.ssl.key")
    if [[ -n "$http_key" ]]; then
      if [[ -f "$http_key" ]]; then
        key_perms=$(stat -c "%a" "$http_key" 2>/dev/null || stat -f "%Lp" "$http_key" 2>/dev/null || echo "unknown")
        if [[ "$key_perms" == "400" ]] || [[ "$key_perms" == "600" ]]; then
          register_check "HTTP SSL key" PASS "$http_key (perms: $key_perms)"
        else
          register_check "HTTP SSL key" FAIL "$http_key (perms: $key_perms, must be 400 or 600)"
        fi
      fi
    fi
  else
    register_check "HTTP SSL/TLS" FAIL "disabled - unencrypted HTTP traffic"
  fi

  # Check TLS for transport (inter-node)
  xpack_transport_ssl=$(get_es_config "xpack.security.transport.ssl.enabled")
  if [[ "$xpack_transport_ssl" == "true" ]]; then
    register_check "Transport SSL/TLS" PASS "enabled (inter-node encryption)"
  else
    register_check "Transport SSL/TLS" FAIL "disabled - unencrypted cluster communication"
  fi

  # Check authentication realms
  realm_check=$(echo "$ES_CONFIG_CONTENT" | grep -E "xpack.security.authc.realms" || echo "")
  if [[ -n "$realm_check" ]]; then
    register_check "Authentication realms" PASS "configured"
  fi

  # Check anonymous access
  anonymous_enabled=$(get_es_config "xpack.security.authc.anonymous.username")
  if [[ -n "$anonymous_enabled" ]]; then
    register_check "Anonymous access" WARN "enabled (username: $anonymous_enabled)"
  else
    register_check "Anonymous access" PASS "disabled"
  fi

  # Check API key service
  api_key_enabled=$(get_es_config "xpack.security.authc.api_key.enabled")
  if [[ "$api_key_enabled" == "true" ]]; then
    register_check "API key authentication" PASS "enabled"
  elif [[ "$api_key_enabled" == "false" ]]; then
    register_check "API key authentication" WARN "disabled"
  fi
else
  register_check "Authentication check" SKIP "config file not found"
fi

# Audit Logging
section "Audit Logging"

if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  # Check audit logging
  audit_enabled=$(get_es_config "xpack.security.audit.enabled")

  if [[ "$audit_enabled" == "true" ]]; then
    register_check "Audit logging" PASS "enabled"

    # Check audit log outputs
    audit_outputs=$(get_es_config "xpack.security.audit.outputs")
    if [[ -n "$audit_outputs" ]]; then
      register_check "Audit outputs" PASS "$audit_outputs"
    fi
  else
    register_check "Audit logging" WARN "disabled (no audit trail)"
  fi

  # Check logging level
  log_level=$(get_es_config "logger.level" || get_es_config "rootLogger.level")
  if [[ -n "$log_level" ]]; then
    if [[ "$log_level" =~ INFO|WARN ]]; then
      register_check "Logging level" PASS "$log_level"
    elif [[ "$log_level" == "DEBUG" ]]; then
      register_check "Logging level" WARN "$log_level (verbose, may impact performance)"
    else
      register_check "Logging level" WARN "$log_level"
    fi
  fi
else
  register_check "Audit logging check" SKIP "config file not found"
fi

# Data Storage & Paths
section "Data Storage & Security"

if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  # Check path.data
  data_path=$(get_es_config "path.data")
  if [[ -n "$data_path" ]]; then
    if [[ -d "$data_path" ]]; then
      data_perms=$(stat -c "%a" "$data_path" 2>/dev/null || stat -f "%Lp" "$data_path" 2>/dev/null || echo "unknown")
      data_owner=$(stat -c "%U" "$data_path" 2>/dev/null || stat -f "%Su" "$data_path" 2>/dev/null || echo "unknown")

      if [[ "$data_perms" == "700" ]] || [[ "$data_perms" == "750" ]]; then
        register_check "Data directory" PASS "$data_path (perms: $data_perms, owner: $data_owner)"
      else
        register_check "Data directory" WARN "$data_path (perms: $data_perms, should be 700 or 750)"
      fi
    else
      register_check "Data directory" FAIL "$data_path does not exist"
    fi
  else
    register_check "Data directory" WARN "path.data not explicitly configured"
  fi

  # Check path.logs
  logs_path=$(get_es_config "path.logs")
  if [[ -n "$logs_path" ]]; then
    if [[ -d "$logs_path" ]]; then
      register_check "Logs directory" PASS "$logs_path"
    else
      register_check "Logs directory" WARN "$logs_path does not exist"
    fi
  fi

  # Check encryption at rest (requires X-Pack Platinum/Enterprise)
  encryption=$(echo "$ES_CONFIG_CONTENT" | grep -i "encryption" || echo "")
  if [[ -n "$encryption" ]]; then
    register_check "Encryption at rest" PASS "configured (X-Pack feature)"
  else
    register_check "Encryption at rest" WARN "not configured (X-Pack Platinum/Enterprise feature)"
  fi
else
  register_check "Storage check" SKIP "config file not found"
fi

# JVM & Memory Settings
section "JVM Security & Resources"

if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  # Check bootstrap memory lock
  bootstrap_memory=$(get_es_config "bootstrap.memory_lock")
  if [[ "$bootstrap_memory" == "true" ]]; then
    register_check "Memory lock" PASS "enabled (prevents swapping)"
  else
    register_check "Memory lock" WARN "not enabled (may swap to disk)"
  fi
fi

# Check JVM options file
jvm_options="/etc/elasticsearch/jvm.options"
if [[ -f "$jvm_options" ]]; then
  register_check "JVM options file" PASS "$jvm_options"

  # Check heap size
  heap_size=$(grep -E "^-Xms|^-Xmx" "$jvm_options" 2>/dev/null | head -n2 || echo "")
  if [[ -n "$heap_size" ]]; then
    register_check "JVM heap size" PASS "configured"
  else
    register_check "JVM heap size" WARN "not explicitly configured"
  fi

  # Check for security manager (deprecated but worth noting)
  security_manager=$(grep -E "java.security.manager" "$jvm_options" 2>/dev/null || echo "")
  if [[ -n "$security_manager" ]]; then
    register_check "Java Security Manager" WARN "configured (deprecated in Java 17+)"
  fi
else
  register_check "JVM options file" SKIP "not found at $jvm_options"
fi

# Additional Security Settings
section "Additional Security Settings"

if [[ -n "$ES_CONFIG_CONTENT" ]]; then
  # Check script execution settings
  script_allowed=$(get_es_config "script.allowed_types")
  if [[ -n "$script_allowed" ]]; then
    if [[ "$script_allowed" == "none" ]]; then
      register_check "Script execution" PASS "disabled (most secure)"
    else
      register_check "Script execution" WARN "enabled: $script_allowed (potential risk)"
    fi
  fi

  # Check CORS settings
  cors_enabled=$(get_es_config "http.cors.enabled")
  if [[ "$cors_enabled" == "true" ]]; then
    cors_origins=$(get_es_config "http.cors.allow-origin")
    if [[ "$cors_origins" == "*" ]]; then
      register_check "CORS configuration" FAIL "allows all origins (*) - SECURITY RISK"
    else
      register_check "CORS configuration" PASS "restricted origins: $cors_origins"
    fi
  else
    register_check "CORS" PASS "disabled (default)"
  fi

  # Check discovery settings for single node
  discovery_type=$(get_es_config "discovery.type")
  if [[ "$discovery_type" == "single-node" ]]; then
    register_check "Discovery type" PASS "single-node (development)"
  fi

  # Check process owner
  es_pid=$(get_es_pid)
  if [[ -n "$es_pid" ]]; then
    es_user=$(ps -o user= -p "$es_pid" 2>/dev/null || echo "unknown")
    if [[ "$es_user" == "elasticsearch" ]]; then
      register_check "Process user" PASS "elasticsearch"
    elif [[ "$es_user" == "root" ]]; then
      register_check "Process user" FAIL "running as root - SECURITY RISK"
    else
      register_check "Process user" WARN "$es_user (expected 'elasticsearch')"
    fi
  fi
else
  register_check "Security settings" SKIP "config file not found"
fi

# Package installation check
section "Elasticsearch Package"
if pkg_installed "elasticsearch"; then
  register_check "Elasticsearch package" PASS "installed"
else
  register_check "Elasticsearch package" SKIP "not installed via package manager"
fi

# Print summary
print_summary
exit "$EXIT_CODE"
