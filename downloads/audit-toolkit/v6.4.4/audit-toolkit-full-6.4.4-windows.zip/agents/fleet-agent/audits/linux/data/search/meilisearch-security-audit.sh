#!/usr/bin/env bash
# meilisearch-security-audit.sh
# Purpose : Non-destructive security audit for Meilisearch (systemd/Docker/socket discovery, keys, headers)
# Usage   : sudo ./meilisearch-security-audit.sh [--host URL]
# Env     : LOG_FILE=/var/log/meilisearch-audit.log
# Exit    : 0=OK, 1=Errors, 2=Warnings only
#
# @elevation: partial
# @elevation-reason: Reads Meilisearch config and checks service/Docker status
#

set -euo pipefail

# Source multi-OS compatibility shims
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"

MEILI_HOST_OVERRIDE=""
LOG_FILE="${LOG_FILE:-/var/log/meilisearch-audit.log}"

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
OK=0; WARN=0; ERR=0; STEPS=0

log(){ printf '[%(%Y-%m-%d %H:%M:%S)T] [%s] %s\n' -1 "$1" "$2" | tee -a "$LOG_FILE" >/dev/null; }
ok(){   printf '%b[PASS]%b  %s\n'    "$GREEN" "$NC" "$1"; log PASS "$1"; }
warn(){ printf '%b[WARN]%b  %s\n'   "$YELLOW" "$NC" "$1"; log WARN "$1"; WARN=$((WARN+1)); }
fail(){ printf '%b[FAIL]%b  %s\n'   "$RED" "$NC" "$1" 1>&2; log FAIL "$1"; ERR=$((ERR+1)); }
info(){ printf '%b[INFO]%b  %s\n'   "$BLUE" "$NC" "$1"; log INFO "$1"; }
skip(){ printf '%b[SKIP]%b  %s\n'   "$BLUE" "$NC" "$1"; log SKIP "$1"; }
section(){ echo; printf -- '---- %s ----\n' "$1" | tee -a "$LOG_FILE" >/dev/null; STEPS=$((STEPS+1)); }

# --- CLI ---
while [[ $# -gt 0 ]]; do
  case "$1" in
    -H|--host) MEILI_HOST_OVERRIDE="$2"; shift 2;;
    -h|--help) echo "Usage: $0 [--host URL]"; exit 0;;
    *) echo "Unknown option: $1"; exit 1;;
  esac
done

MEILI_HOST=""
SSL_PRESENT=false

# --- Discovery ---
section "Endpoint discovery"
if [[ -n "$MEILI_HOST_OVERRIDE" ]]; then
  MEILI_HOST="$MEILI_HOST_OVERRIDE"
  ok "Using override: $MEILI_HOST"
fi

# systemd
if [[ -z "$MEILI_HOST" ]] && is_systemd; then
  if systemctl list-unit-files 2>/dev/null | grep -q '^meilisearch\.service'; then
    ok "meilisearch.service present"
    envline=$(systemctl show meilisearch -p Environment --value 2>/dev/null || true)
    http_env=$(printf '%s' "$envline" | grep -oE 'MEILI_HTTP_ADDR=[^ ]+' | cut -d= -f2 || true)
    ssl_cert_env=$(printf '%s' "$envline" | grep -oE 'MEILI_SSL_CERT_PATH=[^ ]+' | cut -d= -f2 || true)
    ssl_key_env=$(printf '%s' "$envline" | grep -oE 'MEILI_SSL_KEY_PATH=[^ ]+'  | cut -d= -f2 || true)
    [[ -n "$ssl_cert_env" && -n "$ssl_key_env" ]] && SSL_PRESENT=true
    if [[ -n "$http_env" ]]; then
      scheme=$([[ "$SSL_PRESENT" == true ]] && echo https || echo http)
      MEILI_HOST="$scheme://$http_env"
      info "systemd discovered: $MEILI_HOST"
    fi
  fi
fi

# docker
if [[ -z "$MEILI_HOST" ]] && command -v docker >/dev/null 2>&1; then
  out=$(docker ps --format '{{.Ports}} {{.Image}} {{.Names}}' 2>/dev/null | grep -i meili || true)
  if [[ -n "$out" ]]; then
    hp=$(printf '%s\n' "$out" | grep -oE '[0-9\.]+:([0-9]+)->7700/tcp' | head -n1 | cut -d: -f2)
    if [[ -n "$hp" ]]; then
      MEILI_HOST="http://127.0.0.1:${hp}"
      info "docker discovered: $MEILI_HOST"
    fi
  fi
fi

# sockets
if [[ -z "$MEILI_HOST" ]]; then
  if command -v ss >/dev/null 2>&1; then
    listed=$(ss -tlnp 2>/dev/null | grep -i meilisearch || true)
  elif command -v lsof >/dev/null 2>&1; then
    listed=$(lsof -nP -iTCP -sTCP:LISTEN 2>/dev/null | grep -i meilisearch || true)
  else
    listed=""
  fi
  if [[ -n "$listed" ]]; then
    if echo "$listed" | grep -qE '127\.0\.0\.1:7700'; then
      MEILI_HOST="http://127.0.0.1:7700"
    elif echo "$listed" | grep -qE '0\.0\.0\.0:7700|\[::\]:7700'; then
      MEILI_HOST="http://0.0.0.0:7700"; warn "Bound to all interfaces; restrict or firewall"
    fi
    info "socket discovered: $MEILI_HOST"
  fi
fi

[[ -z "$MEILI_HOST" ]] && fail "Unable to locate Meilisearch; pass --host http://127.0.0.1:7700" && exit 1

# --- Service status ---
section "Service status"
if is_systemd && systemctl list-unit-files 2>/dev/null | grep -q '^meilisearch\.service'; then
  svc_is_active meilisearch && ok "service active" || warn "service not active"
  svc_is_enabled meilisearch && ok "service enabled" || warn "service not enabled"
else
  info "No systemd unit detected (possibly docker/manual run)"
fi

# --- Network exposure ---
section "Network exposure"
if command -v ss >/dev/null 2>&1; then
  listed=$(ss -tlnp 2>/dev/null | grep -i meilisearch || true)
elif command -v lsof >/dev/null 2>&1; then
  listed=$(lsof -nP -iTCP -sTCP:LISTEN 2>/dev/null | grep -i meilisearch || true)
else
  listed=""
fi
if [[ -n "$listed" ]]; then
  printf '%s\n' "$listed" | sed 's/^/  /'
  echo "$listed" | grep -qE '0\.0\.0\.0:7700|\[::\]:7700' && warn "Listening on all interfaces" || ok "Not listening on 0.0.0.0/::"
else
  warn "No listening sockets detected (service stopped?)"
fi

# --- HTTP checks ---
section "HTTP endpoints & headers"
if command -v curl >/dev/null 2>&1; then
  base="${MEILI_HOST%/}"
  # /health
  resp=$(curl -sS -w '\nHTTP_CODE:%{http_code}' "$base/health" 2>&1 || true)
  code=$(printf '%s' "$resp" | awk -F: '/HTTP_CODE:/ {print $2}' | tr -d '\r')
  [[ "$code" == 200 ]] && ok "/health 200" || warn "/health HTTP $code"
  # root headers
  headers=$(curl -sS -I "$base/" 2>/dev/null | head -n 20 || true)
  if [[ -n "$headers" ]]; then
    echo "$headers" | sed 's/^/  /'
    echo "$headers" | grep -qi 'X-Content-Type-Options:' && ok "X-Content-Type-Options present" || warn "X-Content-Type-Options missing"
    echo "$headers" | grep -qi 'X-Frame-Options:'        && ok "X-Frame-Options present"        || warn "X-Frame-Options missing"
  fi
  # /keys unauth must be denied if master key is set
  resp=$(curl -sS -w '\nHTTP_CODE:%{http_code}' "$base/keys" 2>&1 || true)
  code=$(printf '%s' "$resp" | awk -F: '/HTTP_CODE:/ {print $2}' | tr -d '\r')
  if [[ "$code" == 401 || "$code" == 403 ]]; then
    ok "Master key protection enforced (/keys -> $code)"
  elif [[ "$code" == 200 ]]; then
    fail "Open instance: /keys returns 200 without auth (set master key)"
  else
    warn "/keys unexpected HTTP $code"
  fi
  # /version
  resp=$(curl -sS -w '\nHTTP_CODE:%{http_code}' "$base/version" 2>&1 || true)
  code=$(printf '%s' "$resp" | awk -F: '/HTTP_CODE:/ {print $2}' | tr -d '\r')
  [[ "$code" == 200 ]] && ok "/version 200" || warn "/version HTTP $code"
else
  warn "curl not installed; skipping HTTP checks"
fi

# --- Firewall posture (UFW) ---
section "Firewall posture"
if command -v ufw >/dev/null 2>&1; then
  if ufw status 2>/dev/null | grep -q 'Status: active'; then
    ok "UFW active"; ufw status 2>/dev/null | grep -E '7700|Anywhere' | sed 's/^/  /' || true
  else
    warn "UFW inactive"
  fi
else
  info "ufw not installed (skipping)"
fi

# --- Summary ---
section "Summary"
printf 'Steps: %d  Errors: %d  Warnings: %d\n' "$STEPS" "$ERR" "$WARN"
if   [[ $ERR -gt 0 ]]; then exit 1
elif [[ $WARN -gt 0 ]]; then exit 2
else exit 0; fi
