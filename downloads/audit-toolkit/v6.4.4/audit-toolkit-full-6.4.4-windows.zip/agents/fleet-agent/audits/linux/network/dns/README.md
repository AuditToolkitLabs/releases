# DNS Security Audits

This directory contains security audits for DNS servers including BIND, Unbound, and dnsmasq.

## Audits

### dns-security-audit.sh

Comprehensive security audit for DNS server configurations with support for multiple DNS implementations.

**Coverage:**
- DNS service status (BIND/named, Unbound, dnsmasq)
- DNSSEC validation configuration
- BIND named.conf security (version hiding, recursion controls, rate limiting)
- Unbound security settings (DNSSEC, access control, minimal responses)
- dnsmasq configuration security
- Zone file permissions and security
- DNS cache poisoning protection
- Query rate limiting
- Split-horizon DNS configuration
- DNS amplification attack prevention

**Usage:**
```bash
# Run standalone
bash audits/linux/network/dns/dns-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain network --match dns
```

**Example Output:**
```
=== DNS Security Audit ===

--- DNS Service Status ---
[PASS] DNS Server Type: BIND (named) detected
[PASS] DNS Service: running
[PASS] Service Enabled: enabled at boot

--- DNSSEC Configuration ---
[PASS] DNSSEC Validation: enabled
[PASS] DNSSEC Trust Anchors: configured
[WARN] DNSSEC Algorithm: using RSASHA256 (consider ECDSAP256SHA256)

--- BIND Security Configuration ---
[PASS] Version Hiding: enabled
[PASS] Recursion Control: restricted to trusted networks only
[PASS] Rate Limiting: configured (responses-per-second 10)
[WARN] TCP Connections: no max-clients limit set
```

## Common Issues & Remediation

### DNSSEC Not Enabled
**Issue:** DNSSEC validation disabled, allowing DNS spoofing attacks.

**Fix (BIND):**
```
# named.conf.options
options {
    dnssec-validation auto;
    dnssec-enable yes;
};
```

**Fix (Unbound):**
```
# unbound.conf
server:
    module-config: "validator iterator"
    auto-trust-anchor-file: "/var/lib/unbound/root.key"
```

### Version Information Exposed
**Issue:** DNS server version revealed in queries, aiding attackers.

**Fix (BIND):**
```
# named.conf.options
options {
    version "Not Available";
};
```

**Fix (Unbound):**
```
# unbound.conf
server:
    hide-version: yes
    hide-identity: yes
```

### Open Recursion
**Issue:** DNS server allows recursion from any source (used in amplification attacks).

**Fix (BIND):**
```
# named.conf.options
acl trusted {
    127.0.0.0/8;
    10.0.0.0/8;
    192.168.0.0/16;
};

options {
    recursion yes;
    allow-recursion { trusted; };
    allow-query { any; };
    allow-query-cache { trusted; };
};
```

**Fix (Unbound):**
```
# unbound.conf
server:
    access-control: 127.0.0.0/8 allow
    access-control: 10.0.0.0/8 allow
    access-control: 192.168.0.0/16 allow
    access-control: 0.0.0.0/0 refuse
```

### No Rate Limiting
**Issue:** No protection against DNS amplification attacks.

**Fix (BIND 9.10+):**
```
# named.conf.options
options {
    rate-limit {
        responses-per-second 10;
        window 5;
        slip 2;
        errors-per-second 5;
        nxdomains-per-second 5;
    };
};
```

**Fix (Unbound):**
```
# unbound.conf
server:
    ratelimit: 1000
    ip-ratelimit: 10
```

### Insecure Zone File Permissions
**Issue:** Zone files readable by non-privileged users.

**Fix:**
```bash
# Set proper ownership and permissions
chown bind:bind /etc/bind/zones/*.zone
chmod 640 /etc/bind/zones/*.zone

# For named configuration
chown bind:bind /etc/bind/named.conf*
chmod 640 /etc/bind/named.conf*
```

### Missing Response Rate Limiting (RRL)
**Issue:** No protection against DNS response flooding.

**Fix (BIND):**
```
# named.conf.options
options {
    rate-limit {
        responses-per-second 10;
        referrals-per-second 10;
        nodata-per-second 10;
        nxdomains-per-second 10;
        errors-per-second 10;
        all-per-second 20;
        window 5;
    };
};
```

## Best Practices

1. **DNSSEC Implementation:**
   - Enable DNSSEC validation on resolvers
   - Sign your authoritative zones with DNSSEC
   - Use automated key rotation (BIND auto-dnssec)
   - Monitor DNSSEC validation failures

2. **Access Control:**
   - Restrict recursion to trusted networks only
   - Separate authoritative and recursive DNS servers
   - Implement split-horizon DNS for internal/external zones
   - Use Access Control Lists (ACLs) for zone transfers

3. **Rate Limiting:**
   - Enable Response Rate Limiting (RRL) on authoritative servers
   - Implement query rate limiting on recursive resolvers
   - Monitor for unusual query patterns
   - Use fail2ban for persistent query floods

4. **Monitoring & Logging:**
   - Enable query logging (with rotation)
   - Monitor for SERVFAIL responses (indicates DNSSEC issues)
   - Track query rates and sources
   - Alert on zone transfer attempts

5. **Software Maintenance:**
   - Keep DNS software updated (BIND/Unbound/dnsmasq)
   - Subscribe to DNS security advisories
   - Test DNSSEC validation regularly
   - Perform regular zone file audits

## References

- [BIND 9 Security Hardening](https://www.isc.org/bind/)
- [Unbound Security Configuration](https://nlnetlabs.nl/documentation/unbound/)
- [DNSSEC Guide (Cloudflare)](https://www.cloudflare.com/dns/dnssec/)
- [DNS Security (OWASP)](https://cheatsheetseries.owasp.org/cheatsheets/DNS_Security_Cheat_Sheet.html)
- [Response Rate Limiting (ISC)](https://www.isc.org/rrl/)
