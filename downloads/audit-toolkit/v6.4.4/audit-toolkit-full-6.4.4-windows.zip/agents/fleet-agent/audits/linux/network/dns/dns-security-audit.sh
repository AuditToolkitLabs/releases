#!/usr/bin/env bash
# DNS Security Audit
# Checks DNS server configuration including DNSSEC, rate limiting, and access controls
#
# @elevation: partial
# @elevation-reason: DNS config files in /etc may require root to read
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
BIND_CONFIG_PATHS=(
  "/etc/bind/named.conf"
  "/etc/named.conf"
  "/var/named/chroot/etc/named.conf"
)
UNBOUND_CONFIG_PATHS=(
  "/etc/unbound/unbound.conf"
  "/usr/local/etc/unbound/unbound.conf"
)
DNSMASQ_CONFIG_PATHS=(
  "/etc/dnsmasq.conf"
  "/etc/dnsmasq.d"
)

# === Performance: Cache variables ===
DNS_SERVER=""
DNS_CONFIG_FILE=""
DNS_CONFIG_CONTENT=""
SERVICE_STATUS=""

# Detect DNS server type
detect_dns_server() {
  if [[ -n "$DNS_SERVER" ]]; then
    echo "$DNS_SERVER"
    return 0
  fi

  if command -v named >/dev/null 2>&1; then
    DNS_SERVER="BIND"
  elif command -v unbound >/dev/null 2>&1; then
    DNS_SERVER="Unbound"
  elif command -v dnsmasq >/dev/null 2>&1; then
    DNS_SERVER="dnsmasq"
  elif systemctl is-active systemd-resolved >/dev/null 2>&1; then
    DNS_SERVER="systemd-resolved"
  else
    DNS_SERVER="none"
  fi

  echo "$DNS_SERVER"
}

# Find DNS config file
find_dns_config() {
  if [[ -n "$DNS_CONFIG_FILE" ]]; then
    echo "$DNS_CONFIG_FILE"
    return 0
  fi

  case "$DNS_SERVER" in
    "BIND")
      for path in "${BIND_CONFIG_PATHS[@]}"; do
        if [[ -f "$path" ]]; then
          DNS_CONFIG_FILE="$path"
          DNS_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
          echo "$path"
          return 0
        fi
      done
      ;;
    "Unbound")
      for path in "${UNBOUND_CONFIG_PATHS[@]}"; do
        if [[ -f "$path" ]]; then
          DNS_CONFIG_FILE="$path"
          DNS_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
          echo "$path"
          return 0
        fi
      done
      ;;
    "dnsmasq")
      for path in "${DNSMASQ_CONFIG_PATHS[@]}"; do
        if [[ -f "$path" ]] || [[ -d "$path" ]]; then
          DNS_CONFIG_FILE="$path"
          if [[ -f "$path" ]]; then
            DNS_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
          fi
          echo "$path"
          return 0
        fi
      done
      ;;
  esac

  return 1
}

# Get DNS config value (BIND format)
get_bind_config() {
  local key="$1"
  echo "$DNS_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}" | head -n1 | sed 's/[;{}."]//g' | awk '{print $2}' || echo ""
}

# Check if listening on interface
check_listening() {
  local port="${1:-53}"
  if command -v ss >/dev/null 2>&1; then
    ss -lun 2>/dev/null | grep -q ":${port}[[:space:]]"
  elif command -v netstat >/dev/null 2>&1; then
    netstat -lun 2>/dev/null | grep -q ":${port}[[:space:]]"
  else
    return 1
  fi
}

# === MAIN AUDIT ===

section "DNS Server Detection"

dns_server=$(detect_dns_server)
if [[ "$dns_server" == "none" ]]; then
  register_check "DNS Server Installed" SKIP "no DNS server detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "DNS Server Type" PASS "$dns_server detected"

# Check service status
case "$dns_server" in
  "BIND")
    if svc_is_active named || svc_is_active bind9; then
      register_check "DNS Service Running" PASS "named/bind9 active"
      SERVICE_STATUS="running"
    else
      register_check "DNS Service Running" FAIL "named/bind9 not running"
      SERVICE_STATUS="stopped"
    fi

    if svc_is_enabled named || svc_is_enabled bind9; then
      register_check "DNS Service Enabled" PASS "enabled at boot"
    else
      register_check "DNS Service Enabled" WARN "not enabled at boot"
    fi
    ;;
  "Unbound")
    if svc_is_active unbound; then
      register_check "DNS Service Running" PASS "unbound active"
      SERVICE_STATUS="running"
    else
      register_check "DNS Service Running" FAIL "unbound not running"
      SERVICE_STATUS="stopped"
    fi
    ;;
  "dnsmasq")
    if svc_is_active dnsmasq; then
      register_check "DNS Service Running" PASS "dnsmasq active"
      SERVICE_STATUS="running"
    else
      register_check "DNS Service Running" FAIL "dnsmasq not running"
      SERVICE_STATUS="stopped"
    fi
    ;;
  "systemd-resolved")
    if svc_is_active systemd-resolved; then
      register_check "DNS Service Running" PASS "systemd-resolved active"
      SERVICE_STATUS="running"
    else
      register_check "DNS Service Running" FAIL "systemd-resolved not running"
      SERVICE_STATUS="stopped"
    fi
    ;;
esac

# If service not running, skip remaining checks
if [[ "$SERVICE_STATUS" != "running" ]]; then
  print_summary
  exit "$EXIT_CODE"
fi

# Check DNS version
case "$dns_server" in
  "BIND")
    if command -v named >/dev/null 2>&1; then
      bind_version=$(named -v 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
      if [[ "$bind_version" != "unknown" ]]; then
        register_check "BIND Version" PASS "version $bind_version"
      else
        register_check "BIND Version" WARN "unable to detect version"
      fi
    fi
    ;;
  "Unbound")
    if command -v unbound >/dev/null 2>&1; then
      unbound_version=$(unbound -V 2>&1 | grep "Version" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
      if [[ "$unbound_version" != "unknown" ]]; then
        register_check "Unbound Version" PASS "version $unbound_version"
      fi
    fi
    ;;
esac

# === Configuration ===
section "Configuration & Security"

config_file=$(find_dns_config)
if [[ -z "$config_file" ]]; then
  register_check "Config File" WARN "config file not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Config File" PASS "found at $config_file"

# Check config file permissions
config_perms=$(stat -c '%a' "$config_file" 2>/dev/null || stat -f '%Lp' "$config_file" 2>/dev/null || echo "000")
config_owner=$(stat -c '%U' "$config_file" 2>/dev/null || stat -f '%Su' "$config_file" 2>/dev/null || echo "unknown")

if [[ "$config_perms" =~ ^[0-9]{3}$ && "${config_perms:2:1}" -le 4 ]]; then
  register_check "Config Permissions" PASS "permissions $config_perms, owner $config_owner"
else
  register_check "Config Permissions" WARN "permissions $config_perms may be too permissive"
fi

# === DNSSEC ===
section "DNSSEC"

case "$dns_server" in
  "BIND")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "dnssec-validation yes\|dnssec-validation auto"; then
      register_check "DNSSEC Validation" PASS "DNSSEC validation enabled"
    else
      register_check "DNSSEC Validation" WARN "DNSSEC validation not enabled (recommend enabling)"
    fi

    if echo "$DNS_CONFIG_CONTENT" | grep -q "dnssec-enable yes"; then
      register_check "DNSSEC Enabled" PASS "DNSSEC enabled"
    fi
    ;;
  "Unbound")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "auto-trust-anchor-file\|trust-anchor-file"; then
      register_check "DNSSEC Trust Anchors" PASS "trust anchors configured"
    else
      register_check "DNSSEC Trust Anchors" WARN "no trust anchors configured"
    fi

    if echo "$DNS_CONFIG_CONTENT" | grep -q "module-config.*validator"; then
      register_check "DNSSEC Validation" PASS "validator module enabled"
    fi
    ;;
esac

# === Recursion & Access Control ===
section "Recursion & Access Control"

case "$dns_server" in
  "BIND")
    # Check recursion setting
    if echo "$DNS_CONFIG_CONTENT" | grep -q "recursion no"; then
      register_check "Recursion Disabled" PASS "recursion disabled (authoritative server)"
    elif echo "$DNS_CONFIG_CONTENT" | grep -q "recursion yes"; then
      register_check "Recursion Enabled" WARN "recursion enabled (ensure ACLs restrict access)"

      # Check allow-recursion ACL
      if echo "$DNS_CONFIG_CONTENT" | grep -q "allow-recursion"; then
        register_check "Allow-Recursion ACL" PASS "allow-recursion configured"
      else
        register_check "Allow-Recursion ACL" FAIL "recursion enabled but no allow-recursion ACL (security risk)"
      fi
    fi

    # Check allow-query
    if echo "$DNS_CONFIG_CONTENT" | grep -q "allow-query"; then
      register_check "Allow-Query ACL" PASS "allow-query configured"
    else
      register_check "Allow-Query ACL" WARN "allow-query not set (accepts queries from anywhere)"
    fi

    # Check allow-transfer (zone transfers)
    if echo "$DNS_CONFIG_CONTENT" | grep -q "allow-transfer.*none\|allow-transfer.*{"; then
      register_check "Zone Transfer ACL" PASS "zone transfers restricted"
    else
      register_check "Zone Transfer ACL" WARN "zone transfers not explicitly restricted"
    fi

    # Check version hiding
    if echo "$DNS_CONFIG_CONTENT" | grep -q 'version "'; then
      version_string=$(echo "$DNS_CONFIG_CONTENT" | grep 'version "' | sed 's/.*version "\([^"]*\)".*/\1/')
      if [[ -z "$version_string" || "$version_string" == "not available" ]]; then
        register_check "Version Hiding" PASS "version string hidden"
      else
        register_check "Version Hiding" WARN "version exposed: $version_string"
      fi
    else
      register_check "Version Hiding" WARN "version not hidden (add: version \"not available\";)"
    fi

    # Check rate limiting (RRL)
    if echo "$DNS_CONFIG_CONTENT" | grep -q "rate-limit"; then
      register_check "Rate Limiting (RRL)" PASS "rate limiting configured"
    else
      register_check "Rate Limiting (RRL)" WARN "no rate limiting (recommend enabling RRL)"
    fi
    ;;

  "Unbound")
    # Check access control
    if echo "$DNS_CONFIG_CONTENT" | grep -q "access-control:"; then
      register_check "Access Control" PASS "access-control configured"

      # Check for overly permissive rules
      if echo "$DNS_CONFIG_CONTENT" | grep "access-control:" | grep -q "0.0.0.0/0 allow"; then
        register_check "Access Control Security" WARN "allows queries from 0.0.0.0/0 (too permissive)"
      else
        register_check "Access Control Security" PASS "access control properly restricted"
      fi
    else
      register_check "Access Control" WARN "no explicit access-control rules"
    fi

    # Check for private addresses
    if echo "$DNS_CONFIG_CONTENT" | grep -q "private-address:"; then
      register_check "Private Address Protection" PASS "private address rebinding protection"
    else
      register_check "Private Address Protection" WARN "no private-address protection (add RFC1918 ranges)"
    fi

    # Check hide-identity
    if echo "$DNS_CONFIG_CONTENT" | grep -q "hide-identity: yes"; then
      register_check "Hide Identity" PASS "server identity hidden"
    else
      register_check "Hide Identity" WARN "server identity not hidden"
    fi

    # Check hide-version
    if echo "$DNS_CONFIG_CONTENT" | grep -q "hide-version: yes"; then
      register_check "Hide Version" PASS "version hidden"
    else
      register_check "Hide Version" WARN "version not hidden"
    fi
    ;;

  "dnsmasq")
    # Check if dnsmasq is configured for local only
    if echo "$DNS_CONFIG_CONTENT" | grep -q "interface=lo\|listen-address=127.0.0.1"; then
      register_check "Network Binding" PASS "bound to localhost (secure for local resolver)"
    elif echo "$DNS_CONFIG_CONTENT" | grep -q "interface=\|listen-address="; then
      register_check "Network Binding" PASS "bound to specific interface"
    else
      register_check "Network Binding" WARN "may be listening on all interfaces"
    fi

    # Check DNSSEC
    if echo "$DNS_CONFIG_CONTENT" | grep -q "dnssec"; then
      register_check "DNSSEC" PASS "DNSSEC support enabled"
    else
      register_check "DNSSEC" WARN "DNSSEC not enabled"
    fi
    ;;
esac

# === Network Security ===
section "Network Security"

# Check listening addresses
if check_listening 53; then
  register_check "DNS Listening" PASS "DNS listening on port 53"

  # Check what interfaces
  if command -v ss >/dev/null 2>&1; then
    listen_addr=$(ss -lun 2>/dev/null | grep ":53[[:space:]]" | awk '{print $5}' | cut -d: -f1 | sort -u)
  elif command -v netstat >/dev/null 2>&1; then
    listen_addr=$(netstat -lun 2>/dev/null | grep ":53[[:space:]]" | awk '{print $4}' | cut -d: -f1 | sort -u)
  fi

  if [[ -n "$listen_addr" ]]; then
    if echo "$listen_addr" | grep -q "0.0.0.0\|::"; then
      register_check "Listening Interfaces" WARN "listening on all interfaces (consider restricting)"
    else
      register_check "Listening Interfaces" PASS "listening on specific interfaces"
    fi
  fi
else
  register_check "DNS Listening" WARN "DNS not listening on port 53"
fi

# Check both TCP and UDP
if check_listening 53 && ss -ltn 2>/dev/null | grep -q ":53[[:space:]]"; then
  register_check "TCP/UDP Support" PASS "both TCP and UDP configured"
elif check_listening 53; then
  register_check "TCP Support" WARN "only UDP detected (TCP needed for large responses)"
fi

# Check source port randomization (harder to verify, check config)
case "$dns_server" in
  "BIND")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "use-v4-udp-ports\|use-v6-udp-ports"; then
      register_check "Source Port Randomization" PASS "custom port ranges configured"
    else
      register_check "Source Port Randomization" PASS "using default randomization"
    fi
    ;;
esac

# === Cache Security ===
section "Cache Security"

case "$dns_server" in
  "BIND")
    # Check max-cache-size
    max_cache=$(get_bind_config "max-cache-size")
    if [[ -n "$max_cache" ]]; then
      register_check "Cache Size Limit" PASS "max-cache-size: $max_cache"
    else
      register_check "Cache Size Limit" WARN "max-cache-size not set (potential DoS risk)"
    fi

    # Check max-ncache-ttl (negative caching)
    if echo "$DNS_CONFIG_CONTENT" | grep -q "max-ncache-ttl"; then
      register_check "Negative Cache TTL" PASS "negative caching configured"
    fi
    ;;

  "Unbound")
    # Check cache sizes
    if echo "$DNS_CONFIG_CONTENT" | grep -q "msg-cache-size\|rrset-cache-size"; then
      register_check "Cache Size Limits" PASS "cache size limits configured"
    else
      register_check "Cache Size Limits" WARN "no explicit cache size limits"
    fi

    # Check prefetch
    if echo "$DNS_CONFIG_CONTENT" | grep -q "prefetch: yes"; then
      register_check "Cache Prefetch" PASS "prefetch enabled (better performance)"
    fi
    ;;
esac

# === Logging ===
section "Logging"

case "$dns_server" in
  "BIND")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "logging {"; then
      register_check "Logging Configured" PASS "logging block found"

      # Check query logging
      if echo "$DNS_CONFIG_CONTENT" | grep -q "category queries"; then
        register_check "Query Logging" PASS "query logging configured"
      else
        register_check "Query Logging" WARN "query logging not enabled (useful for security)"
      fi
    else
      register_check "Logging Configured" WARN "no logging block (using defaults)"
    fi
    ;;

  "Unbound")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "verbosity:"; then
      verbosity=$(echo "$DNS_CONFIG_CONTENT" | grep "verbosity:" | awk '{print $2}' | head -n1)
      if [[ "$verbosity" -ge 1 ]]; then
        register_check "Logging Level" PASS "verbosity: $verbosity"
      else
        register_check "Logging Level" WARN "verbosity 0 (consider level 1 for errors)"
      fi
    fi

    if echo "$DNS_CONFIG_CONTENT" | grep -q "log-queries: yes"; then
      register_check "Query Logging" PASS "query logging enabled"
    else
      register_check "Query Logging" WARN "query logging disabled"
    fi
    ;;
esac

# === Process Security ===
section "Process Security"

# Check DNS process user
case "$dns_server" in
  "BIND")
    dns_process=$(ps aux | grep '[n]amed' || echo "")
    ;;
  "Unbound")
    dns_process=$(ps aux | grep '[u]nbound' || echo "")
    ;;
  "dnsmasq")
    dns_process=$(ps aux | grep '[d]nsmasq' || echo "")
    ;;
esac

if [[ -n "$dns_process" ]]; then
  dns_user=$(echo "$dns_process" | awk '{print $1}' | head -n1)
  if [[ "$dns_user" == "root" ]]; then
    register_check "DNS Process User" WARN "running as root (security risk if compromised)"
  elif [[ "$dns_user" =~ bind|named|unbound|dnsmasq ]]; then
    register_check "DNS Process User" PASS "running as $dns_user (dedicated user)"
  else
    register_check "DNS Process User" PASS "running as $dns_user"
  fi
fi

# Check for chroot
case "$dns_server" in
  "BIND")
    if echo "$DNS_CONFIG_CONTENT" | grep -q "directory.*chroot\|/var/named/chroot"; then
      register_check "Chroot Jail" PASS "BIND running in chroot"
    elif [[ -d "/var/named/chroot" ]]; then
      register_check "Chroot Jail" PASS "chroot directory exists"
    else
      register_check "Chroot Jail" WARN "not running in chroot (recommend for security)"
    fi
    ;;
esac

# === Summary ===
print_summary

exit "$EXIT_CODE"
