#!/usr/bin/env bash
# Firewall state audit - check if firewall is active and configured
#
# @elevation: root
# @elevation-reason: iptables, nftables, ufw commands require root
#
set -euo pipefail

# shellcheck source=../../../lib/common.sh
. "$(dirname "$0")/../../../../lib/common.sh"
# shellcheck source=../../../lib/firewall.sh
. "$(dirname "$0")/../../../../lib/firewall.sh"

section "Firewall Status"

# Check if any firewall is active (return codes: 0=active, 1=inactive, 2=permission denied)
fw_is_active && fw_result=0 || fw_result=$?

if [[ $fw_result -eq 0 ]]; then
  register_check "Firewall active" PASS "firewall is running"

  # Get firewall state details
  state=$(fw_state)
  register_check "Firewall type" PASS "$state"

  # Get rule count
  rules=$(fw_list_rules 2>/dev/null || echo "")
  if [[ "$rules" == "PERMISSION_DENIED" ]]; then
    register_check "Firewall rules" SKIP "requires elevated privileges"
  elif [[ -n "$rules" ]]; then
    rule_count=$(echo "$rules" | wc -l)
    register_check "Firewall rules" PASS "$rule_count rules configured"
  else
    register_check "Firewall rules" WARN "no rules found or unable to list"
  fi
elif [[ $fw_result -eq 2 ]]; then
  # Permission denied - can't determine firewall status
  register_check "Firewall active" SKIP "requires elevated privileges to check"
  register_check "Firewall type" SKIP "requires elevated privileges"
else
  state=$(fw_state)
  register_check "Firewall active" FAIL "no active firewall detected"
  register_check "Firewall type" WARN "$state"
fi

section "Firewall Tools Available"

# Check which firewall tools are installed
fw_tools_found=0

if command -v ufw >/dev/null 2>&1; then
  register_check "ufw" PASS "installed"
  ((fw_tools_found++))
else
  register_check "ufw" SKIP "Not applicable (ufw not installed)"
fi

if command -v firewall-cmd >/dev/null 2>&1; then
  register_check "firewalld" PASS "installed"
  ((fw_tools_found++))
else
  register_check "firewalld" SKIP "Not applicable (firewalld not installed)"
fi

if command -v iptables >/dev/null 2>&1; then
  register_check "iptables" PASS "installed"
  ((fw_tools_found++))
else
  register_check "iptables" SKIP "Not applicable (iptables not installed)"
fi

if command -v nft >/dev/null 2>&1; then
  register_check "nftables" PASS "installed"
  ((fw_tools_found++))
else
  register_check "nftables" SKIP "Not applicable (nftables not installed)"
fi

if [[ $fw_tools_found -eq 0 ]]; then
  register_check "Firewall tooling" FAIL "no firewall tools found on system"
fi

print_summary
exit "$EXIT_CODE"
