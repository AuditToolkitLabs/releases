# Intrusion Prevention Audits

This directory contains security audits for intrusion prevention and detection systems.

## Available Audits

### fail2ban-audit.sh

**Fail2Ban Security Audit** - Comprehensive security assessment of Fail2Ban intrusion prevention system.

#### What it checks:

**Service Status**
- Fail2Ban service running and enabled
- Version information
- Service reliability

**Jail Configuration**
- SSH jail enabled (critical)
- Ban time duration (>= 10 minutes recommended)
- Max retry limits (<= 5 recommended)
- Custom jail configurations
- Active jails and their status

**Ban Statistics**
- Currently banned IPs across all jails
- Recent ban activity (last 24 hours)
- Ban effectiveness metrics

**Action & Notification**
- Default action configuration
- Email notification setup
- IP whitelist (ignoreip) configuration

**Logging & Monitoring**
- Log file existence and permissions
- Recent errors in logs
- Log rotation configuration
- Log file size management

**Firewall Integration**
- iptables/nftables chain presence
- Backend configuration (systemd vs polling)
- Firewall rule validation

**Configuration Security**
- jail.conf/jail.local permissions
- Filter definitions availability
- Configuration file ownership

#### Usage:

```bash
# Direct execution
bash audits/linux/network/intrusion-prevention/fail2ban-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain network
bash orchestrator/orchestrator.sh --match fail2ban
```

#### Example Output:

```
=== Fail2Ban Installation & Service ===
[PASS] Fail2Ban Installed: fail2ban package found
[PASS] Fail2Ban Service Running: service is active
[PASS] Fail2Ban Service Enabled: enabled at boot
[PASS] Fail2Ban Version: version 0.11.2

=== Jail Configuration ===
[PASS] Jail Config File: found jail.local
[PASS] SSH Jail Enabled: SSH jail is active
[PASS] Ban Time Duration: bantime=10m (adequate)
[PASS] Max Retry Limit: maxretry=5 (appropriate)

=== Active Jails ===
[PASS] Active Jail Count: 3 jails active: sshd nginx apache
[PASS] Total Banned IPs: 2 IPs currently banned across all jails

=== Action & Notification ===
[PASS] Default Action: action=%(action_mwl)s
[PASS] Email Notifications: destemail=admin@example.com
[PASS] IP Whitelist: ignoreip configured: 127.0.0.1 192.168.1.0/24

=== Logging & Activity ===
[PASS] Fail2Ban Log File: log file exists: /var/log/fail2ban.log
[PASS] Log File Size: log file size: 5MB
[PASS] Recent Ban Activity (24h): 15 ban actions in last 24 hours

Summary: 16 checks passed, 2 warnings, 0 failed
```

#### Remediation Examples:

**Enable SSH jail if not active:**
```bash
# Edit /etc/fail2ban/jail.local
[sshd]
enabled = true
port = ssh
logpath = /var/log/auth.log
maxretry = 5
bantime = 600

# Restart fail2ban
sudo systemctl restart fail2ban
```

**Increase ban time:**
```bash
# In /etc/fail2ban/jail.local under [DEFAULT]
bantime = 1h  # or 3600 seconds

sudo systemctl reload fail2ban
```

**Add IP whitelist:**
```bash
# In /etc/fail2ban/jail.local under [DEFAULT]
ignoreip = 127.0.0.1/8 ::1 192.168.1.0/24

sudo systemctl reload fail2ban
```

**Enable email notifications:**
```bash
# In /etc/fail2ban/jail.local under [DEFAULT]
destemail = admin@yourdomain.com
sender = fail2ban@yourdomain.com
action = %(action_mwl)s  # mail with log lines
```

#### Required Packages:
- `fail2ban` (main package)
- Optional: `sendmail` or `postfix` (for email notifications)

#### Documentation:
- [Fail2Ban Official Docs](https://www.fail2ban.org/wiki/index.php/Main_Page)
- [Fail2Ban on GitHub](https://github.com/fail2ban/fail2ban)
- [DigitalOcean Fail2Ban Tutorial](https://www.digitalocean.com/community/tutorials/how-to-protect-ssh-with-fail2ban-on-ubuntu)

#### Security Impact:
⭐⭐⭐ **HIGH** - Fail2Ban is a critical defense against brute-force attacks and automated intrusion attempts. Proper configuration can prevent account compromise and resource exhaustion attacks.

---

## Future Audits

Planned additions to this directory:
- **OSSEC/Wazuh audit** - Host-based intrusion detection
- **Snort/Suricata audit** - Network intrusion detection systems
- **ModSecurity audit** - Web application firewall

---

**Last Updated:** February 5, 2026  
**Maintainer:** Security Audit Toolkit Team
