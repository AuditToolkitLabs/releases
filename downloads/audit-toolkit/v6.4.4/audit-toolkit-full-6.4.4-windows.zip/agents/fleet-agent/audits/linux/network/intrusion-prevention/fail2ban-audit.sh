#!/usr/bin/env bash
# Fail2Ban Security Audit
# Checks Fail2Ban configuration, jail status, and intrusion prevention effectiveness
#
# @elevation: partial
# @elevation-reason: fail2ban-client and jail configs may require root
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
FAIL2BAN_LOG="/var/log/fail2ban.log"

# === Performance: Cache variables ===
F2B_CLIENT_STATUS=""
F2B_JAIL_LOCAL=""
SERVICE_STATUS=""

# Helper to check if fail2ban-client is available
have_f2b_client() {
  command -v fail2ban-client >/dev/null 2>&1
}

# OPTIMIZED: Get fail2ban-client status once
get_f2b_status() {
  if [[ -n "$F2B_CLIENT_STATUS" ]]; then
    echo "$F2B_CLIENT_STATUS"
    return 0
  fi

  if have_f2b_client; then
    F2B_CLIENT_STATUS=$(fail2ban-client status 2>/dev/null || echo "")
    echo "$F2B_CLIENT_STATUS"
    return 0
  fi
  return 1
}

# Get jail-specific status
get_jail_status() {
  local jail="$1"
  if have_f2b_client; then
    fail2ban-client status "$jail" 2>/dev/null || echo ""
  fi
}

# shellcheck disable=SC2034  # Variables used for caching

# Read jail config (cached)
get_jail_config() {
  local key="$1"
  local config_content="$2"

  # Look for key in config (format: key = value)
  echo "$config_content" | grep -E "^[[:space:]]*${key}[[:space:]]*=" | tail -n1 | sed 's/^[^=]*=[[:space:]]*//' | xargs || echo ""
}

# Parse log for recent activity
get_recent_bans() {
  local hours="${1:-24}"

  if [[ ! -f "$FAIL2BAN_LOG" ]]; then
    return 1
  fi

  # Count ban actions in last N hours
  local since_time
  since_time=$(date -d "$hours hours ago" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -v -"${hours}H" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "")

  if [[ -n "$since_time" ]]; then
    # Filter log by timestamp, then count bans
    # Fail2ban format: YYYY-MM-DD HH:MM:SS,... so $1 $2 gives timestamp prefix
    awk -v since="$since_time" '$1 " " $2 >= since' "$FAIL2BAN_LOG" 2>/dev/null | grep -c "Ban " || echo "0"
  else
    # Fallback: last 100 lines
    tail -n 100 "$FAIL2BAN_LOG" 2>/dev/null | grep -c "Ban " || echo "0"
  fi
}

# === MAIN AUDIT ===

section "Fail2Ban Installation & Service"

# Check if fail2ban is installed
if ! pkg_installed fail2ban; then
  register_check "Fail2Ban Installed" SKIP "Not applicable (fail2ban not installed)"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Fail2Ban Installed" PASS "fail2ban package found"

# Check service status
if svc_is_active fail2ban-server || svc_is_active fail2ban; then
  register_check "Fail2Ban Service Running" PASS "service is active"
  SERVICE_STATUS="running"
else
  register_check "Fail2Ban Service Running" FAIL "service not running"
  SERVICE_STATUS="stopped"
fi

# Check if enabled at boot
if svc_is_enabled fail2ban-server || svc_is_enabled fail2ban; then
  register_check "Fail2Ban Service Enabled" PASS "enabled at boot"
else
  register_check "Fail2Ban Service Enabled" WARN "not enabled at boot"
fi

# Check fail2ban version
if command -v fail2ban-server >/dev/null 2>&1; then
  f2b_version=$(fail2ban-server --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
  if [[ "$f2b_version" != "unknown" ]]; then
    register_check "Fail2Ban Version" PASS "version $f2b_version"
  else
    register_check "Fail2Ban Version" WARN "unable to detect version"
  fi
fi

# If service not running, skip remaining checks
if [[ "$SERVICE_STATUS" != "running" ]]; then
  print_summary
  exit "$EXIT_CODE"
fi

# === Jail Configuration ===
section "Jail Configuration"

# Load jail configurations
if [[ -f "/etc/fail2ban/jail.local" ]]; then
  F2B_JAIL_LOCAL=$(cat "/etc/fail2ban/jail.local" 2>/dev/null || echo "")
  config_source="jail.local"
elif [[ -f "/etc/fail2ban/jail.conf" ]]; then
  F2B_JAIL_LOCAL=$(cat "/etc/fail2ban/jail.conf" 2>/dev/null || echo "")
  config_source="jail.conf"
else
  register_check "Jail Config File" FAIL "no jail.conf or jail.local found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Jail Config File" PASS "found $config_source"

# Check for jail.d directory
if [[ -d "/etc/fail2ban/jail.d" ]]; then
  jail_d_count=$(find /etc/fail2ban/jail.d -name "*.conf" -o -name "*.local" 2>/dev/null | wc -l)
  if [[ "$jail_d_count" -gt 0 ]]; then
    register_check "Custom Jail Configs" PASS "$jail_d_count custom jail files in jail.d/"
  fi
fi

# Check SSH jail enabled
if get_f2b_status | grep -qE "sshd|ssh"; then
  register_check "SSH Jail Enabled" PASS "SSH jail is active"
else
  register_check "SSH Jail Enabled" FAIL "SSH jail not enabled (critical)"
fi

# Get default jail settings
default_bantime=$(get_jail_config "bantime" "$F2B_JAIL_LOCAL")

default_maxretry=$(get_jail_config "maxretry" "$F2B_JAIL_LOCAL")

# Check bantime (should be >= 600 seconds / 10 minutes)
if [[ -n "$default_bantime" ]]; then
  # Handle various time formats (10m, 600, 1h, etc.)
  bantime_seconds=0
  if [[ "$default_bantime" =~ ^[0-9]+$ ]]; then
    bantime_seconds=$default_bantime
  elif [[ "$default_bantime" =~ ^[0-9]+m$ ]]; then
    bantime_seconds=$(( ${default_bantime%m} * 60 ))
  elif [[ "$default_bantime" =~ ^[0-9]+h$ ]]; then
    bantime_seconds=$(( ${default_bantime%h} * 3600 ))
  fi

  if [[ "$bantime_seconds" -ge 600 ]]; then
    register_check "Ban Time Duration" PASS "bantime=$default_bantime (adequate)"
  else
    register_check "Ban Time Duration" WARN "bantime=$default_bantime (recommend >= 10m)"
  fi
else
  register_check "Ban Time Duration" WARN "bantime not explicitly set (using default)"
fi

# Check maxretry (should be <= 5)
if [[ -n "$default_maxretry" ]]; then
  if [[ "$default_maxretry" -le 5 ]]; then
    register_check "Max Retry Limit" PASS "maxretry=$default_maxretry (appropriate)"
  else
    register_check "Max Retry Limit" WARN "maxretry=$default_maxretry (recommend <= 5)"
  fi
else
  register_check "Max Retry Limit" WARN "maxretry not explicitly set"
fi

# === Active Jails ===
section "Active Jails"

if have_f2b_client; then
  active_jails=$(get_f2b_status | grep "Jail list:" | sed 's/.*Jail list:[[:space:]]*//' | tr ',' '\n' | xargs)

  if [[ -n "$active_jails" ]]; then
    jail_count=$(echo "$active_jails" | wc -w)
    register_check "Active Jail Count" PASS "$jail_count jails active: $active_jails"

    # Check each active jail for banned IPs
    total_banned=0
    for jail in $active_jails; do
      jail_info=$(get_jail_status "$jail")
      currently_banned=$(echo "$jail_info" | grep "Currently banned:" | grep -oE '[0-9]+' || echo "0")
      total_banned=$((total_banned + currently_banned))

      if [[ "$currently_banned" -gt 0 ]]; then
        register_check "Jail $jail" PASS "$currently_banned IPs currently banned"
      fi
    done

    if [[ "$total_banned" -gt 0 ]]; then
      register_check "Total Banned IPs" PASS "$total_banned IPs currently banned across all jails"
    else
      register_check "Total Banned IPs" PASS "0 IPs currently banned (no active threats detected)"
    fi
  else
    register_check "Active Jails" FAIL "no jails are active"
  fi
else
  register_check "Fail2Ban Client" WARN "fail2ban-client not available, cannot query jails"
fi

# === Action Configuration ===
section "Action & Notification"

# Check default action
default_action=$(get_jail_config "action" "$F2B_JAIL_LOCAL")
if [[ -n "$default_action" ]]; then
  register_check "Default Action" PASS "action=$default_action"
else
  register_check "Default Action" WARN "no explicit default action configured"
fi

# Check email notifications
dest_email=$(get_jail_config "destemail" "$F2B_JAIL_LOCAL")

if [[ -n "$dest_email" && "$dest_email" != "root@localhost" ]]; then
  register_check "Email Notifications" PASS "destemail=$dest_email"
else
  register_check "Email Notifications" WARN "no valid email configured (recommend setting destemail)"
fi

# Check ignoreip (whitelist)
ignore_ips=$(get_jail_config "ignoreip" "$F2B_JAIL_LOCAL")
if [[ -n "$ignore_ips" ]]; then
  register_check "IP Whitelist" PASS "ignoreip configured: $ignore_ips"
else
  register_check "IP Whitelist" WARN "no ignoreip whitelist (consider adding trusted IPs)"
fi

# === Log Monitoring ===
section "Logging & Activity"

# Check fail2ban log exists and is writable
if [[ -f "$FAIL2BAN_LOG" ]]; then
  register_check "Fail2Ban Log File" PASS "log file exists: $FAIL2BAN_LOG"

  # Check log file size (warn if > 100MB)
  log_size=$(stat -f%z "$FAIL2BAN_LOG" 2>/dev/null || stat -c%s "$FAIL2BAN_LOG" 2>/dev/null || echo "0")
  log_size_mb=$((log_size / 1024 / 1024))

  if [[ "$log_size_mb" -gt 100 ]]; then
    register_check "Log File Size" WARN "log file is ${log_size_mb}MB (consider log rotation)"
  else
    register_check "Log File Size" PASS "log file size: ${log_size_mb}MB"
  fi

  # Check for recent errors
  if grep -q "ERROR" "$FAIL2BAN_LOG" 2>/dev/null; then
    recent_errors=$(tail -n 100 "$FAIL2BAN_LOG" 2>/dev/null | grep -c "ERROR" || echo "0")
    if [[ "$recent_errors" -gt 5 ]]; then
      register_check "Recent Log Errors" WARN "$recent_errors errors in last 100 log lines"
    else
      register_check "Recent Log Errors" PASS "$recent_errors errors in last 100 log lines"
    fi
  fi

  # Check recent ban activity
  recent_bans=$(get_recent_bans 24)
  if [[ "$recent_bans" -gt 0 ]]; then
    register_check "Recent Ban Activity (24h)" PASS "$recent_bans ban actions in last 24 hours"
  else
    register_check "Recent Ban Activity (24h)" PASS "0 ban actions (no threats detected)"
  fi
else
  register_check "Fail2Ban Log File" WARN "log file not found at $FAIL2BAN_LOG"
fi

# Check log file permissions
if [[ -f "$FAIL2BAN_LOG" ]]; then
  log_perms=$(stat -c '%a' "$FAIL2BAN_LOG" 2>/dev/null || stat -f '%Lp' "$FAIL2BAN_LOG" 2>/dev/null || echo "000")
  log_owner=$(stat -c '%U' "$FAIL2BAN_LOG" 2>/dev/null || stat -f '%Su' "$FAIL2BAN_LOG" 2>/dev/null || echo "unknown")

  if [[ "$log_perms" =~ ^[0-9]{3}$ && "${log_perms:2:1}" -le 4 ]]; then
    register_check "Log File Permissions" PASS "permissions $log_perms, owner $log_owner"
  else
    register_check "Log File Permissions" WARN "permissions $log_perms may be too permissive"
  fi
fi

# === Firewall Integration ===
section "Firewall Integration"

# Check if iptables/nftables has fail2ban chains
if command -v iptables >/dev/null 2>&1; then
  f2b_chains=$(iptables -L 2>/dev/null | grep -c "fail2ban" || echo "0")
  if [[ "$f2b_chains" -gt 0 ]]; then
    register_check "Iptables Integration" PASS "$f2b_chains fail2ban chains found"
  else
    register_check "Iptables Integration" WARN "no fail2ban iptables chains found"
  fi
fi

# Check backend (systemd/polling)
backend=$(get_jail_config "backend" "$F2B_JAIL_LOCAL")
if [[ -n "$backend" ]]; then
  if [[ "$backend" == "systemd" ]] && command -v systemctl >/dev/null 2>&1; then
    register_check "Log Backend" PASS "using systemd journal backend (efficient)"
  elif [[ "$backend" == "polling" ]]; then
    register_check "Log Backend" WARN "using polling backend (consider systemd if available)"
  else
    register_check "Log Backend" PASS "backend=$backend"
  fi
fi

# === Configuration File Security ===
section "Configuration Security"

# Check jail.local permissions
if [[ -f "/etc/fail2ban/jail.local" ]]; then
  jail_perms=$(stat -c '%a' /etc/fail2ban/jail.local 2>/dev/null || stat -f '%Lp' /etc/fail2ban/jail.local 2>/dev/null || echo "000")
  if [[ "$jail_perms" =~ ^[0-9]{3}$ && "${jail_perms:1:1}" -le 4 && "${jail_perms:2:1}" -eq 0 ]]; then
    register_check "Jail Config Permissions" PASS "jail.local permissions $jail_perms (secure)"
  else
    register_check "Jail Config Permissions" WARN "jail.local permissions $jail_perms (recommend 640 or 644)"
  fi
fi

# Check for filter files
filter_count=$(find /etc/fail2ban/filter.d -name "*.conf" 2>/dev/null | wc -l || echo "0")
if [[ "$filter_count" -gt 0 ]]; then
  register_check "Filter Definitions" PASS "$filter_count filter definitions available"
fi

# === Summary & Recommendations ===
print_summary

exit "$EXIT_CODE"
