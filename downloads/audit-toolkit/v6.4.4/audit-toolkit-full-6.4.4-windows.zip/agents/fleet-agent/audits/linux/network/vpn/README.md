# VPN Security Audits

This directory contains security audits for VPN servers including OpenVPN and WireGuard.

## Audits

### vpn-security-audit.sh

Comprehensive security audit for VPN server configurations supporting both OpenVPN and WireGuard.

**Coverage:**
- VPN service detection and status (OpenVPN, WireGuard)
- Configuration file security and permissions
- Certificate management and expiration (OpenVPN)
- Private key security (both)
- Encryption algorithms and cipher suites
- TLS configuration and authentication
- Network routing and IP forwarding
- NAT/masquerade configuration
- Firewall rules for VPN traffic
- DNS push configuration (leak prevention)
- Process security (privilege dropping)
- Logging configuration

**Usage:**
```bash
# Run standalone
bash audits/linux/network/vpn/vpn-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain network --match vpn
```

**Example Output:**
```
=== VPN Security Audit ===

--- VPN Detection ---
[PASS] VPN Type: openvpn detected

--- Service Status ---
[PASS] OpenVPN Service (openvpn-server@server): running
[PASS] Service Enabled: enabled at boot
[PASS] OpenVPN Version: version 2.5.5

--- OpenVPN Certificate Security ---
[PASS] CA Certificate: configured
[PASS] CA Certificate Expiry: CA valid for 1825 days
[PASS] CA Key Size: 2048-bit key
[WARN] CRL Verification: CRL not enabled (recommend for production)

--- OpenVPN Encryption & Security ---
[PASS] Cipher: strong cipher: AES-256-GCM
[PASS] HMAC Auth: strong auth: SHA256
[PASS] TLS Crypt: tls-crypt enabled (enhanced security)
[PASS] TLS Version: minimum TLS 1.2

--- Network & Firewall ---
[PASS] IPv4 Forwarding: enabled
[PASS] Firewall Rules: 5 VPN-related iptables rules
[PASS] NAT Configuration: NAT/MASQUERADE configured
[PASS] VPN Port Listening: listening on UDP port 1194
```

## Common Issues & Remediation

### OpenVPN Issues

#### Expired Certificates
**Issue:** CA or server certificates expired, blocking VPN connections.

**Fix:**
```bash
# Check certificate expiration
openssl x509 -enddate -noout -in /etc/openvpn/server/ca.crt
openssl x509 -enddate -noout -in /etc/openvpn/server/server.crt

# Regenerate certificates using Easy-RSA
cd /etc/openvpn/easy-rsa
./easyrsa renew server nopass
./easyrsa gen-crl
cp pki/crl.pem /etc/openvpn/server/
```

#### Weak Encryption
**Issue:** Using deprecated ciphers (BF-CBC, DES) or weak auth (MD5).

**Fix (server.conf):**
```
# Strong cipher and auth
cipher AES-256-GCM
auth SHA256

# Or use data-ciphers for negotiation
data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305

# TLS 1.2 minimum
tls-version-min 1.2
tls-cipher TLS-ECDHE-RSA-WITH-AES-256-GCM-SHA384:TLS-ECDHE-RSA-WITH-AES-128-GCM-SHA256
```

#### No TLS-Auth/TLS-Crypt
**Issue:** Vulnerable to DoS attacks and port scanning.

**Fix:**
```bash
# Generate TLS-crypt key (preferred over tls-auth)
openvpn --genkey secret /etc/openvpn/server/tls-crypt.key

# Add to server.conf
tls-crypt /etc/openvpn/server/tls-crypt.key

# Distribute key to clients
```

#### Running as Root
**Issue:** OpenVPN process runs with elevated privileges unnecessarily.

**Fix (server.conf):**
```
# Drop privileges after startup
user nobody
group nogroup  # or 'nobody' on RHEL/CentOS

# Required when dropping privileges
persist-key
persist-tun
```

#### No CRL Verification
**Issue:** Revoked client certificates can still connect.

**Fix:**
```bash
# Generate CRL with Easy-RSA
cd /etc/openvpn/easy-rsa
./easyrsa gen-crl

# Add to server.conf
crl-verify /etc/openvpn/server/crl.pem

# Revoke a client certificate
./easyrsa revoke client1
./easyrsa gen-crl
```

#### DNS Leaks
**Issue:** Client DNS queries bypass VPN tunnel.

**Fix (server.conf):**
```
# Push DNS servers to clients
push "dhcp-option DNS 1.1.1.1"
push "dhcp-option DNS 1.0.0.1"

# Block DNS on client's original interface (Windows)
push "block-outside-dns"
```

### WireGuard Issues

#### Private Key in Config File
**Issue:** Private key stored directly in configuration file.

**Fix:**
```bash
# Generate keys
umask 077
wg genkey | tee privatekey | wg pubkey > publickey

# Store private key separately
chmod 600 privatekey

# Use PostUp to load key
# /etc/wireguard/wg0.conf
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PostUp = wg set %i private-key /etc/wireguard/privatekey
```

#### Weak Key Permissions
**Issue:** Private keys readable by unprivileged users.

**Fix:**
```bash
chmod 600 /etc/wireguard/*.conf
chmod 600 /etc/wireguard/privatekey
chown root:root /etc/wireguard/*
```

#### No Preshared Keys
**Issue:** Missing additional encryption layer for quantum resistance.

**Fix:**
```bash
# Generate preshared key
wg genpsk > /etc/wireguard/psk-client1

# Add to peer configuration
[Peer]
PublicKey = <client-public-key>
PresharedKey = <preshared-key-content>
AllowedIPs = 10.0.0.2/32
```

#### Missing IP Forwarding
**Issue:** VPN server cannot route traffic between clients and internet.

**Fix:**
```bash
# Enable IP forwarding permanently
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.forwarding=1" >> /etc/sysctl.conf
sysctl -p

# Or via PostUp in WireGuard config
PostUp = sysctl -w net.ipv4.ip_forward=1
```

#### No Firewall Rules
**Issue:** VPN traffic not properly NATed or firewalled.

**Fix (/etc/wireguard/wg0.conf):**
```
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = <server-private-key>

# NAT and firewall rules
PostUp = iptables -A FORWARD -i %i -j ACCEPT
PostUp = iptables -A FORWARD -o %i -j ACCEPT
PostUp = iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT
PostDown = iptables -D FORWARD -o %i -j ACCEPT
PostDown = iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE
```

## Best Practices

### OpenVPN

1. **Certificate Management:**
   - Use 2048-bit or 4096-bit RSA keys
   - Set reasonable certificate lifetimes (1-3 years)
   - Implement CRL for revoked certificates
   - Consider using a proper PKI/CA system
   - Monitor certificate expiration dates

2. **Encryption:**
   - Use AES-256-GCM or ChaCha20-Poly1305
   - Enable tls-crypt for DoS protection
   - Set minimum TLS version to 1.2 or 1.3
   - Use strong HMAC authentication (SHA256+)

3. **Process Security:**
   - Drop privileges with user/group directives
   - Enable persist-key and persist-tun
   - Run in chroot if possible
   - Limit client connections with max-clients

4. **Network Security:**
   - Push DNS servers to prevent leaks
   - Configure appropriate routing
   - Use topology subnet (not net30)
   - Implement client-to-client restrictions if needed

### WireGuard

1. **Key Management:**
   - Generate keys on secure systems only
   - Store private keys with 600 permissions
   - Use separate key files (not in config)
   - Rotate keys periodically
   - Consider preshared keys for quantum resistance

2. **Network Configuration:**
   - Use appropriate AllowedIPs (avoid 0.0.0.0/0 unless full tunnel)
   - Implement PersistentKeepalive for NAT traversal (25s typical)
   - Configure proper routing with PostUp/PostDown
   - Enable IP forwarding on server

3. **Firewall Integration:**
   - Use PostUp/PostDown for atomic rule changes
   - Implement MASQUERADE or SNAT for client internet access
   - Restrict forward rules to WireGuard interface
   - Consider using nftables for modern systems

4. **Monitoring:**
   - Use `wg show` for connection status
   - Monitor handshake failures
   - Track data transfer per peer
   - Implement automated key rotation

## Security Checklist

- [ ] Strong encryption enabled (AES-256-GCM or equivalent)
- [ ] TLS 1.2+ enforced (OpenVPN)
- [ ] Certificates valid and not expiring soon
- [ ] Private keys properly secured (600 permissions)
- [ ] IP forwarding enabled
- [ ] NAT/masquerade configured
- [ ] Firewall rules allow VPN traffic
- [ ] DNS servers pushed to clients (leak prevention)
- [ ] Logging enabled and monitored
- [ ] Process runs with dropped privileges
- [ ] Regular updates applied
- [ ] Unused/revoked clients removed

## References

- [OpenVPN Hardening Guide](https://community.openvpn.net/openvpn/wiki/Hardening)
- [WireGuard Security](https://www.wireguard.com/protocol/)
- [OpenVPN Easy-RSA PKI](https://easy-rsa.readthedocs.io/)
- [WireGuard Firewall Configuration](https://www.wireguard.com/netns/)
- [NIST VPN Security Guidelines](https://csrc.nist.gov/publications/detail/sp/800-77/rev-1/final)
