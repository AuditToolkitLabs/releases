#!/usr/bin/env bash
# Enterprise VPN Client Security Audit (Linux)
# Checks enterprise VPN client configurations for security compliance
#
# Supports:
# - Cisco AnyConnect Secure Mobility Client
# - Palo Alto GlobalProtect
# - Fortinet FortiClient
# - Zscaler Client Connector (ZCC)
# - OpenConnect (open-source AnyConnect-compatible)
# - StrongSwan/IPsec
# - Libreswan
#
# Compliance Mapping:
# - CIS Controls: 12.1, 12.4, 12.6
# - NIST SP 800-53: SC-8, SC-12, SC-13, AC-17
# - ISO 27001: A.10.1, A.13.1, A.13.2
#
# @elevation: partial
# @elevation-reason: VPN client configs in /etc may require root to read
#
set -euo pipefail

# Source libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"

section "Enterprise VPN Client Detection"

# Track detected clients
CLIENTS_FOUND=0

# ============================================================================
# CISCO ANYCONNECT
# ============================================================================
audit_cisco_anyconnect() {
  local install_path="/opt/cisco/anyconnect"
  local vpn_cli="/opt/cisco/anyconnect/bin/vpn"

  if [[ ! -d "$install_path" ]]; then
    register_check "Cisco AnyConnect" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))
  register_check "Cisco AnyConnect" PASS "Installed at $install_path"

  # Check service
  if svc_is_active vpnagentd 2>/dev/null; then
    register_check "AnyConnect Service" PASS "vpnagentd running"
  else
    register_check "AnyConnect Service" WARN "vpnagentd not running"
  fi

  # Check version
  if [[ -x "$vpn_cli" ]]; then
    local version
    version=$("$vpn_cli" -v 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
    register_check "AnyConnect Version" PASS "$version"
  fi

  # Check VPN profile for split tunneling
  local profile="/opt/cisco/anyconnect/profile"
  if [[ -d "$profile" ]]; then
    # shellcheck disable=SC2012
    local profile_count
    profile_count=$(ls "$profile"/*.xml 2>/dev/null | wc -l || echo 0)
    if [[ "$profile_count" -gt 0 ]]; then
      register_check "AnyConnect Profiles" PASS "$profile_count profile(s) configured"

      # Check for split tunneling in profiles
      if grep -rq "AllowLocalLanAccess" "$profile" 2>/dev/null; then
        if grep -rq "<AllowLocalLanAccess>true</AllowLocalLanAccess>" "$profile" 2>/dev/null; then
          register_check "Local LAN Access" WARN "Local LAN access enabled (split tunnel risk)"
        fi
      fi
    fi
  fi

  # Check for ISE Posture module
  if [[ -d "/opt/cisco/hostscan" ]]; then
    if svc_is_active ciscod 2>/dev/null; then
      register_check "ISE Posture Module" PASS "Active"
    else
      register_check "ISE Posture Module" WARN "Installed but not running"
    fi
  fi
}

# ============================================================================
# PALO ALTO GLOBALPROTECT
# ============================================================================
audit_globalprotect() {
  local install_path="/opt/paloaltonetworks/globalprotect"
  local gp_cli="/opt/paloaltonetworks/globalprotect/PanGPS"

  if [[ ! -d "$install_path" ]]; then
    register_check "GlobalProtect" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))
  register_check "GlobalProtect" PASS "Installed at $install_path"

  # Check service
  local gp_service="gpd"
  if svc_is_active "$gp_service" 2>/dev/null || pgrep -x PanGPA >/dev/null 2>&1; then
    register_check "GlobalProtect Service" PASS "Running"
  else
    register_check "GlobalProtect Service" WARN "Not running"
  fi

  # Check config
  local config="/opt/paloaltonetworks/globalprotect/pangps.xml"
  if [[ -f "$config" ]]; then
    # Check HIP (Host Information Profile) collection
    if grep -q "<hip-collection>true</hip-collection>" "$config" 2>/dev/null; then
      register_check "HIP Collection" PASS "Enabled"
    else
      register_check "HIP Collection" WARN "Disabled (no posture assessment)"
    fi

    # Check for portal address
    if grep -q "<portal>" "$config" 2>/dev/null; then
      local portal
      portal=$(grep -oP '(?<=<portal>)[^<]+' "$config" 2>/dev/null | head -1)
      register_check "GP Portal" PASS "Configured: $portal"
    fi
  fi
}

# ============================================================================
# FORTINET FORTICLIENT
# ============================================================================
audit_forticlient() {
  local install_paths=(
    "/opt/forticlient"
    "/usr/share/forticlient"
  )
  local found=""

  for path in "${install_paths[@]}"; do
    if [[ -d "$path" ]]; then
      found="$path"
      break
    fi
  done

  if [[ -z "$found" ]]; then
    register_check "FortiClient" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))
  register_check "FortiClient" PASS "Installed at $found"

  # Check service
  if svc_is_active forticlient 2>/dev/null || pgrep -f forticlient >/dev/null 2>&1; then
    register_check "FortiClient Service" PASS "Running"
  else
    register_check "FortiClient Service" WARN "Not running"
  fi

  # Check EMS (Endpoint Management Server) connectivity
  local config_file="/etc/forticlient/forticlient.conf"
  if [[ -f "$config_file" ]]; then
    if grep -q "ems_cloud\|ems_server" "$config_file" 2>/dev/null; then
      register_check "EMS Management" PASS "EMS configured"
    else
      register_check "EMS Management" WARN "No EMS management configured"
    fi
  fi
}

# ============================================================================
# ZSCALER CLIENT CONNECTOR
# ============================================================================
audit_zscaler() {
  local install_path="/opt/zscaler"

  if [[ ! -d "$install_path" ]]; then
    register_check "Zscaler" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))
  register_check "Zscaler Client Connector" PASS "Installed"

  # Check ZPA tunnel service
  if svc_is_active zpa-tunnel 2>/dev/null || pgrep -f zpa-tunnel >/dev/null 2>&1; then
    register_check "ZPA Tunnel" PASS "Active"
  else
    register_check "ZPA Tunnel" WARN "Not active"
  fi

  # Check ZIA (Internet Access) service
  if svc_is_active zscaler-service 2>/dev/null; then
    register_check "ZIA Service" PASS "Running"
  fi

  # Check enrollment
  if [[ -f "/opt/zscaler/var/udid" ]]; then
    register_check "Device Enrollment" PASS "Device enrolled"
  else
    register_check "Device Enrollment" WARN "Device not enrolled"
  fi
}

# ============================================================================
# OPENCONNECT (Cisco AnyConnect-compatible)
# ============================================================================
audit_openconnect() {
  if ! command -v openconnect >/dev/null 2>&1; then
    register_check "OpenConnect" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))

  local version
  version=$(openconnect --version 2>/dev/null | head -1 || echo "unknown")
  register_check "OpenConnect" PASS "Installed: $version"

  # Check for active connections
  if pgrep -x openconnect >/dev/null 2>&1; then
    register_check "OpenConnect Connection" PASS "Active VPN connection"
  else
    register_check "OpenConnect Connection" INFO "No active connection"
  fi

  # Check config directory
  if [[ -d "$HOME/.config/openconnect" || -d "/etc/openconnect" ]]; then
    register_check "OpenConnect Config" PASS "Config directory present"
  fi
}

# ============================================================================
# STRONGSWAN / IPSEC
# ============================================================================
audit_strongswan() {
  local installed="false"

  if command -v ipsec >/dev/null 2>&1 || command -v strongswan >/dev/null 2>&1; then
    installed="true"
  elif [[ -d "/etc/strongswan.d" || -f "/etc/ipsec.conf" ]]; then
    installed="true"
  fi

  if [[ "$installed" != "true" ]]; then
    register_check "StrongSwan/IPsec" SKIP "Not installed"
    return
  fi

  ((CLIENTS_FOUND++))
  register_check "StrongSwan/IPsec" PASS "Installed"

  # Check service
  local services=("strongswan" "strongswan-starter" "ipsec")
  for svc in "${services[@]}"; do
    if svc_is_active "$svc" 2>/dev/null; then
      register_check "IPsec Service" PASS "$svc running"
      break
    fi
  done

  # Check ipsec.conf
  local ipsec_conf="/etc/ipsec.conf"
  if [[ -f "$ipsec_conf" ]]; then
    # Check for IKEv2 (more secure)
    if grep -qE "keyexchange.*=.*ikev2" "$ipsec_conf" 2>/dev/null; then
      register_check "IKE Version" PASS "IKEv2 configured"
    elif grep -qE "keyexchange.*=.*ikev1" "$ipsec_conf" 2>/dev/null; then
      register_check "IKE Version" WARN "IKEv1 in use (prefer IKEv2)"
    fi

    # Check for strong encryption
    if grep -qE "esp.*=.*aes256" "$ipsec_conf" 2>/dev/null; then
      register_check "ESP Encryption" PASS "AES-256 configured"
    fi

    # Check for PFS
    if grep -qE "pfs.*=.*yes" "$ipsec_conf" 2>/dev/null; then
      register_check "Perfect Forward Secrecy" PASS "Enabled"
    fi

    # Check permissions
    local perms
    perms=$(stat -c '%a' "$ipsec_conf" 2>/dev/null || echo "000")
    if [[ "$perms" == "600" || "$perms" == "640" ]]; then
      register_check "ipsec.conf Permissions" PASS "$perms (secure)"
    else
      register_check "ipsec.conf Permissions" WARN "$perms (recommend 600)"
    fi
  fi

  # Check secrets file
  if [[ -f "/etc/ipsec.secrets" ]]; then
    local secrets_perms
    secrets_perms=$(stat -c '%a' "/etc/ipsec.secrets" 2>/dev/null || echo "000")
    if [[ "$secrets_perms" == "600" ]]; then
      register_check "ipsec.secrets Permissions" PASS "600 (secure)"
    else
      register_check "ipsec.secrets Permissions" FAIL "$secrets_perms (must be 600)"
    fi
  fi

  # List active connections
  if command -v ipsec >/dev/null 2>&1; then
    local status
    status=$(ipsec status 2>/dev/null | grep -c "ESTABLISHED" || echo "0")
    if [[ "$status" -gt 0 ]]; then
      register_check "Active Tunnels" PASS "$status tunnel(s) established"
    else
      register_check "Active Tunnels" INFO "No active tunnels"
    fi
  fi
}

# ============================================================================
# LIBRESWAN
# ============================================================================
audit_libreswan() {
  if ! command -v ipsec >/dev/null 2>&1; then
    return  # Already checked in strongswan
  fi

  # Check if it's Libreswan (not StrongSwan)
  if ! ipsec --version 2>&1 | grep -qi "libreswan"; then
    return
  fi

  register_check "Libreswan" PASS "Detected instead of StrongSwan"

  # Libreswan uses /etc/ipsec.d/ for configs
  if [[ -d "/etc/ipsec.d" ]]; then
    # Check for NSS database
    if [[ -f "/etc/ipsec.d/cert9.db" || -f "/etc/ipsec.d/cert8.db" ]]; then
      register_check "NSS Database" PASS "Certificate database present"
    else
      register_check "NSS Database" WARN "No NSS certificate database"
    fi
  fi
}

# ============================================================================
# NETWORK MANAGER VPN PLUGINS
# ============================================================================
audit_nm_vpn() {
  if ! command -v nmcli >/dev/null 2>&1; then
    register_check "NetworkManager VPN" SKIP "nmcli not available"
    return
  fi

  # List VPN connections
  local vpn_connections
  vpn_connections=$(nmcli -t -f TYPE,NAME connection show 2>/dev/null | grep "^vpn:" || echo "")

  if [[ -n "$vpn_connections" ]]; then
    ((CLIENTS_FOUND++))
    local count
    count=$(echo "$vpn_connections" | wc -l)
    register_check "NetworkManager VPN" PASS "$count VPN connection(s) configured"

    # Check for active VPN
    local active
    active=$(nmcli -t -f TYPE,STATE connection show --active 2>/dev/null | grep "^vpn:activated" || echo "")
    if [[ -n "$active" ]]; then
      register_check "Active VPN (NM)" PASS "VPN connection active"
    fi
  else
    register_check "NetworkManager VPN" INFO "No VPN connections configured"
  fi
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

audit_cisco_anyconnect
audit_globalprotect
audit_forticlient
audit_zscaler
audit_openconnect
audit_strongswan
audit_libreswan
audit_nm_vpn

# Summary
section "Summary"
if [[ "$CLIENTS_FOUND" -eq 0 ]]; then
  register_check "Enterprise VPN Clients" INFO "No enterprise VPN clients detected"
else
  register_check "Enterprise VPN Clients" PASS "$CLIENTS_FOUND client(s) detected"
fi

print_summary
exit "$EXIT_CODE"
