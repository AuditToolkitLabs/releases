#!/usr/bin/env bash
# VPN Security Audit (OpenVPN/WireGuard)
# Checks VPN server configuration including encryption, certificates, and network security
#
# @elevation: partial
# @elevation-reason: VPN server configs and keys may require root to read
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
OPENVPN_CONFIG_PATHS=(
  "/etc/openvpn/server"
  "/etc/openvpn"
  "/usr/local/etc/openvpn"
)
WIREGUARD_CONFIG_PATHS=(
  "/etc/wireguard"
  "/usr/local/etc/wireguard"
)

# === Performance: Cache variables ===
VPN_TYPE=""
VPN_CONFIG_FILE=""
VPN_CONFIG_CONTENT=""
SERVICE_STATUS=""

# Detect VPN type
detect_vpn_type() {
  if [[ -n "$VPN_TYPE" ]]; then
    echo "$VPN_TYPE"
    return 0
  fi

  # Check for running services
  if systemctl is-active openvpn-server@* >/dev/null 2>&1 || systemctl is-active openvpn@* >/dev/null 2>&1; then
    VPN_TYPE="openvpn"
  elif systemctl is-active wg-quick@* >/dev/null 2>&1; then
    VPN_TYPE="wireguard"
  elif command -v wg >/dev/null 2>&1 && ip link show | grep -q wg; then
    VPN_TYPE="wireguard"
  elif pkg_installed openvpn; then
    VPN_TYPE="openvpn"
  elif pkg_installed wireguard || pkg_installed wireguard-tools; then
    VPN_TYPE="wireguard"
  else
    VPN_TYPE="none"
  fi

  echo "$VPN_TYPE"
}

# Find VPN config file
find_vpn_config() {
  if [[ -n "$VPN_CONFIG_FILE" ]]; then
    echo "$VPN_CONFIG_FILE"
    return 0
  fi

  case "$VPN_TYPE" in
    "openvpn")
      for base_path in "${OPENVPN_CONFIG_PATHS[@]}"; do
        if [[ -d "$base_path" ]]; then
          # Look for .conf files (using -quit for performance)
          config=$(find "$base_path" -name "*.conf" -print -quit 2>/dev/null)
          if [[ -n "$config" ]]; then
            VPN_CONFIG_FILE="$config"
            VPN_CONFIG_CONTENT=$(cat "$config" 2>/dev/null || echo "")
            echo "$config"
            return 0
          fi
        fi
      done
      ;;
    "wireguard")
      for base_path in "${WIREGUARD_CONFIG_PATHS[@]}"; do
        if [[ -d "$base_path" ]]; then
          # Look for .conf files (typically wg0.conf) - using -quit for performance
          config=$(find "$base_path" -name "*.conf" -print -quit 2>/dev/null)
          if [[ -n "$config" ]]; then
            VPN_CONFIG_FILE="$config"
            VPN_CONFIG_CONTENT=$(cat "$config" 2>/dev/null || echo "")
            echo "$config"
            return 0
          fi
        fi
      done
      ;;
  esac

  return 1
}

# Get config value (generic key=value or key value)
get_config_value() {
  local key="$1"
  echo "$VPN_CONFIG_CONTENT" | grep -E "^[[:space:]]*${key}" | head -n1 | sed 's/^[^=]*=[[:space:]]*//' | awk '{print $NF}' || echo ""
}

# === MAIN AUDIT ===

section "VPN Detection"

vpn_type=$(detect_vpn_type)
if [[ "$vpn_type" == "none" ]]; then
  register_check "VPN Installed" SKIP "no VPN server detected"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "VPN Type" PASS "$vpn_type detected"

# === Service Status ===
section "Service Status"

case "$vpn_type" in
  "openvpn")
    # Check for OpenVPN services
    openvpn_services=$(systemctl list-units --type=service --all 2>/dev/null | grep -E "openvpn-server@|openvpn@" | awk '{print $1}' || echo "")

    if [[ -n "$openvpn_services" ]]; then
      for service in $openvpn_services; do
        if systemctl is-active "$service" >/dev/null 2>&1; then
          register_check "OpenVPN Service ($service)" PASS "running"
          SERVICE_STATUS="running"
        else
          register_check "OpenVPN Service ($service)" WARN "not running"
        fi

        if systemctl is-enabled "$service" >/dev/null 2>&1; then
          register_check "Service Enabled ($service)" PASS "enabled at boot"
        else
          register_check "Service Enabled ($service)" WARN "not enabled at boot"
        fi
      done
    else
      register_check "OpenVPN Service" WARN "no systemd services found"
      # Check for running process
      if pgrep -x openvpn >/dev/null 2>&1; then
        register_check "OpenVPN Process" PASS "openvpn process running"
        SERVICE_STATUS="running"
      else
        SERVICE_STATUS="stopped"
      fi
    fi

    # Check OpenVPN version
    if command -v openvpn >/dev/null 2>&1; then
      openvpn_ver=$(openvpn --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
      if [[ "$openvpn_ver" != "unknown" ]]; then
        register_check "OpenVPN Version" PASS "version $openvpn_ver"
      fi
    fi
    ;;

  "wireguard")
    # Check for WireGuard interfaces
    wg_interfaces=$(ip link show 2>/dev/null | grep -oE 'wg[0-9]+' | sort -u || echo "")

    if [[ -n "$wg_interfaces" ]]; then
      for iface in $wg_interfaces; do
        if ip link show "$iface" 2>/dev/null | grep -q "UP"; then
          register_check "WireGuard Interface ($iface)" PASS "interface up"
          SERVICE_STATUS="running"
        else
          register_check "WireGuard Interface ($iface)" WARN "interface down"
        fi

        # Check for wg-quick service
        if systemctl is-active "wg-quick@${iface}" >/dev/null 2>&1; then
          register_check "WireGuard Service ($iface)" PASS "service active"
        fi

        if systemctl is-enabled "wg-quick@${iface}" >/dev/null 2>&1; then
          register_check "Service Enabled ($iface)" PASS "enabled at boot"
        fi
      done
    else
      register_check "WireGuard Interfaces" WARN "no WireGuard interfaces found"
      SERVICE_STATUS="stopped"
    fi

    # Check WireGuard version
    if command -v wg >/dev/null 2>&1; then
      wg_ver=$(wg --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
      if [[ "$wg_ver" != "unknown" ]]; then
        register_check "WireGuard Version" PASS "version $wg_ver"
      fi
    fi
    ;;
esac

# If VPN not running, skip remaining checks
if [[ "$SERVICE_STATUS" != "running" ]]; then
  print_summary
  exit "$EXIT_CODE"
fi

# === Configuration ===
section "Configuration"

config_file=$(find_vpn_config)
if [[ -z "$config_file" ]]; then
  register_check "Config File" WARN "config file not found in standard locations"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Config File" PASS "found at $config_file"

# Check config file permissions
config_perms=$(stat -c '%a' "$config_file" 2>/dev/null || stat -f '%Lp' "$config_file" 2>/dev/null || echo "000")
config_owner=$(stat -c '%U' "$config_file" 2>/dev/null || stat -f '%Su' "$config_file" 2>/dev/null || echo "unknown")

if [[ "$config_perms" == "600" || "$config_perms" == "640" ]]; then
  register_check "Config Permissions" PASS "permissions $config_perms (secure)"
else
  register_check "Config Permissions" WARN "permissions $config_perms (recommend 600 or 640)"
fi

if [[ "$config_owner" == "root" ]]; then
  register_check "Config Owner" PASS "owned by root"
else
  register_check "Config Owner" WARN "owned by $config_owner (recommend root)"
fi

# === OpenVPN-Specific Checks ===
if [[ "$vpn_type" == "openvpn" ]]; then
  section "OpenVPN Certificate Security"

  # Check for CA certificate
  ca_cert=$(get_config_value "ca")
  if [[ -n "$ca_cert" ]]; then
    register_check "CA Certificate" PASS "CA cert configured: $ca_cert"

    # Check if file exists and is readable
    if [[ -f "$ca_cert" ]]; then
      if command -v openssl >/dev/null 2>&1; then
        # Check certificate expiration
        ca_expiry=$(openssl x509 -enddate -noout -in "$ca_cert" 2>/dev/null | cut -d= -f2)
        if [[ -n "$ca_expiry" ]]; then
          exp_epoch=$(date -d "$ca_expiry" +%s 2>/dev/null || date -j -f "%b %d %T %Y %Z" "$ca_expiry" +%s 2>/dev/null || echo "0")
          now_epoch=$(date +%s)
          days_left=$(( (exp_epoch - now_epoch) / 86400 ))

          if [[ "$days_left" -lt 0 ]]; then
            register_check "CA Certificate Expiry" FAIL "CA certificate expired"
          elif [[ "$days_left" -lt 30 ]]; then
            register_check "CA Certificate Expiry" WARN "CA certificate expires in $days_left days"
          else
            register_check "CA Certificate Expiry" PASS "CA valid for $days_left days"
          fi
        fi

        # Check key size
        key_size=$(openssl x509 -text -noout -in "$ca_cert" 2>/dev/null | grep "Public-Key:" | grep -oE '[0-9]+' | head -n1)
        if [[ -n "$key_size" ]]; then
          if [[ "$key_size" -ge 2048 ]]; then
            register_check "CA Key Size" PASS "${key_size}-bit key"
          else
            register_check "CA Key Size" WARN "${key_size}-bit key (recommend 2048+ bits)"
          fi
        fi
      fi
    else
      register_check "CA Certificate File" WARN "CA cert file not found: $ca_cert"
    fi
  else
    register_check "CA Certificate" WARN "CA certificate not configured"
  fi

  # Check server certificate
  cert_file=$(get_config_value "cert")
  if [[ -n "$cert_file"  ]]; then
    register_check "Server Certificate" PASS "server cert configured: $cert_file"

    if [[ -f "$cert_file" ]] && command -v openssl >/dev/null 2>&1; then
      # Check expiration
      cert_expiry=$(openssl x509 -enddate -noout -in "$cert_file" 2>/dev/null | cut -d= -f2)
      if [[ -n "$cert_expiry" ]]; then
        exp_epoch=$(date -d "$cert_expiry" +%s 2>/dev/null || date -j -f "%b %d %T %Y %Z" "$cert_expiry" +%s 2>/dev/null || echo "0")
        now_epoch=$(date +%s)
        days_left=$(( (exp_epoch - now_epoch) / 86400 ))

        if [[ "$days_left" -lt 0 ]]; then
          register_check "Server Cert Expiry" FAIL "server certificate expired"
        elif [[ "$days_left" -lt 30 ]]; then
          register_check "Server Cert Expiry" WARN "server certificate expires in $days_left days"
        else
          register_check "Server Cert Expiry" PASS "server cert valid for $days_left days"
        fi
      fi
    fi
  fi

  # Check for CRL (Certificate Revocation List)
  crl_verify=$(get_config_value "crl-verify")
  if [[ -n "$crl_verify" ]]; then
    register_check "CRL Verification" PASS "CRL enabled: $crl_verify"
  else
    register_check "CRL Verification" WARN "CRL not enabled (recommend for production)"
  fi

  section "OpenVPN Encryption & Security"

  # Check cipher
  cipher=$(get_config_value "cipher")
  if [[ -n "$cipher" ]]; then
    if [[ "$cipher" =~ AES-256-GCM|AES-256-CBC|AES-128-GCM ]]; then
      register_check "Cipher" PASS "strong cipher: $cipher"
    else
      register_check "Cipher" WARN "cipher: $cipher (recommend AES-256-GCM)"
    fi
  else
    register_check "Cipher" WARN "no explicit cipher (using default)"
  fi

  # Check auth digest
  auth=$(get_config_value "auth")
  if [[ -n "$auth" ]]; then
    if [[ "$auth" =~ SHA256|SHA384|SHA512 ]]; then
      register_check "HMAC Auth" PASS "strong auth: $auth"
    elif [[ "$auth" == "SHA1" ]]; then
      register_check "HMAC Auth" WARN "SHA1 auth (recommend SHA256+)"
    else
      register_check "HMAC Auth" WARN "auth: $auth"
    fi
  else
    register_check "HMAC Auth" WARN "no explicit auth digest"
  fi

  # Check TLS auth/crypt
  if grep -q "^tls-auth" "$config_file" 2>/dev/null; then
    register_check "TLS Auth" PASS "tls-auth enabled (DoS protection)"
  elif grep -q "^tls-crypt" "$config_file" 2>/dev/null; then
    register_check "TLS Crypt" PASS "tls-crypt enabled (enhanced security)"
  else
    register_check "TLS Auth/Crypt" WARN "neither tls-auth nor tls-crypt enabled"
  fi

  # Check TLS version
  tls_version_min=$(get_config_value "tls-version-min")
  if [[ -n "$tls_version_min" ]]; then
    if [[ "$tls_version_min" =~ 1.2|1.3 ]]; then
      register_check "TLS Version" PASS "minimum TLS $tls_version_min"
    else
      register_check "TLS Version" WARN "minimum TLS $tls_version_min (recommend 1.2+)"
    fi
  else
    register_check "TLS Version" WARN "no minimum TLS version set"
  fi

  section "OpenVPN Process Security"

  # Check user/group
  vpn_user=$(get_config_value "user")
  vpn_group=$(get_config_value "group")

  if [[ -n "$vpn_user" && "$vpn_user" != "root" ]]; then
    register_check "Process User" PASS "running as $vpn_user (not root)"
  else
    register_check "Process User" WARN "no user directive (may run as root)"
  fi

  if [[ -n "$vpn_group" ]]; then
    register_check "Process Group" PASS "group: $vpn_group"
  fi

  # Check persist-key and persist-tun
  if grep -q "^persist-key" "$config_file" 2>/dev/null; then
    register_check "Persist Key" PASS "persist-key enabled"
  else
    register_check "Persist Key" WARN "persist-key not set (needed with user/group)"
  fi

  if grep -q "^persist-tun" "$config_file" 2>/dev/null; then
    register_check "Persist TUN" PASS "persist-tun enabled"
  fi

  # Check logging
  log_file=$(get_config_value "log\|log-append")
  if [[ -n "$log_file" ]]; then
    register_check "Logging" PASS "logging to $log_file"

    # Check log file permissions
    if [[ -f "$log_file" ]]; then
      log_perms=$(stat -c '%a' "$log_file" 2>/dev/null || stat -f '%Lp' "$log_file" 2>/dev/null || echo "000")
      if [[ "$log_perms" =~ ^[0-9]{3}$ && "${log_perms:2:1}" -le 4 ]]; then
        register_check "Log File Permissions" PASS "permissions $log_perms"
      else
        register_check "Log File Permissions" WARN "permissions $log_perms"
      fi
    fi
  else
    register_check "Logging" WARN "no log file configured"
  fi

  section "OpenVPN Network Configuration"

  # Check port
  port=$(get_config_value "port")
  if [[ -n "$port" ]]; then
    if [[ "$port" == "1194" ]]; then
      register_check "Port" PASS "default port 1194"
    else
      register_check "Port" PASS "custom port $port"
    fi
  fi

  # Check protocol
  proto=$(get_config_value "proto")
  if [[ -n "$proto" ]]; then
    if [[ "$proto" == "udp" || "$proto" == "udp4" || "$proto" == "udp6" ]]; then
      register_check "Protocol" PASS "UDP (recommended for performance)"
    else
      register_check "Protocol" PASS "protocol: $proto"
    fi
  fi

  # Check pushed routes and DNS
  if grep -q "^push" "$config_file" 2>/dev/null; then
    push_count=$(grep -c "^push" "$config_file" || echo "0")
    register_check "Client Push Directives" PASS "$push_count push directives"

    # Check for DNS push
    if grep "^push" "$config_file" | grep -q "dhcp-option DNS"; then
      register_check "DNS Push" PASS "DNS servers pushed to clients"
    else
      register_check "DNS Push" WARN "no DNS servers pushed (DNS leaks possible)"
    fi
  fi

fi

# === WireGuard-Specific Checks ===
if [[ "$vpn_type" == "wireguard" ]]; then
  section "WireGuard Key Security"

  # Check private key
  private_key=$(get_config_value "PrivateKey")
  if [[ -n "$private_key" ]]; then
    register_check "Private Key" PASS "private key configured"

    # Check if stored in separate file (better practice)
    if echo "$VPN_CONFIG_CONTENT" | grep -q "PostUp.*wg set.*private-key"; then
      register_check "Private Key Storage" PASS "private key loaded from separate file (secure)"
    else
      register_check "Private Key Storage" WARN "private key in config file (consider separate file)"
    fi
  else
    register_check "Private Key" FAIL "no private key configured"
  fi

  # Check if private key file has proper permissions
  if [[ -d "/etc/wireguard" ]]; then
    for key_file in /etc/wireguard/*.key /etc/wireguard/private*; do
      if [[ -f "$key_file" ]]; then
        key_perms=$(stat -c '%a' "$key_file" 2>/dev/null || stat -f '%Lp' "$key_file" 2>/dev/null || echo "000")
        if [[ "$key_perms" == "600" ]]; then
          register_check "Private Key Perms" PASS "$(basename "$key_file"): $key_perms (secure)"
        else
          register_check "Private Key Perms" WARN "$(basename "$key_file"): $key_perms (should be 600)"
        fi
      fi
    done
  fi

  # Check for preshared keys
  if echo "$VPN_CONFIG_CONTENT" | grep -q "PresharedKey"; then
    register_check "Preshared Keys" PASS "preshared keys in use (enhanced security)"
  else
    register_check "Preshared Keys" WARN "no preshared keys (optional but recommended)"
  fi

  section "WireGuard Peer Configuration"

  # Count peers
  peer_count=$(echo "$VPN_CONFIG_CONTENT" | grep -c "\[Peer\]" || echo "0")
  if [[ "$peer_count" -gt 0 ]]; then
    register_check "Peer Count" PASS "$peer_count peer(s) configured"

    # Check AllowedIPs restrictions
    allowed_ips=$(echo "$VPN_CONFIG_CONTENT" | grep "AllowedIPs")
    if echo "$allowed_ips" | grep -q "0.0.0.0/0"; then
      register_check "AllowedIPs Security" WARN "peer allows 0.0.0.0/0 (full tunnel - verify intended)"
    else
      register_check "AllowedIPs Security" PASS "AllowedIPs properly restricted"
    fi

    # Check for PersistentKeepalive
    if echo "$VPN_CONFIG_CONTENT" | grep -q "PersistentKeepalive"; then
      register_check "Persistent Keepalive" PASS "keepalive configured (NAT traversal)"
    fi
  else
    register_check "Peers" WARN "no peers configured"
  fi

  section "WireGuard Network Configuration"

  # Check ListenPort
  listen_port=$(get_config_value "ListenPort")
  if [[ -n "$listen_port" ]]; then
    register_check "Listen Port" PASS "port $listen_port"
  else
    register_check "Listen Port" PASS "using random port (default)"
  fi

  # Check for PostUp/PostDown scripts (firewall rules)
  if echo "$VPN_CONFIG_CONTENT" | grep -q "PostUp"; then
    postup_count=$(echo "$VPN_CONFIG_CONTENT" | grep -c "PostUp" || echo "0")
    register_check "PostUp Scripts" PASS "$postup_count PostUp command(s) (firewall/routing)"
  else
    register_check "PostUp Scripts" WARN "no PostUp scripts (firewall rules may not be configured)"
  fi

  if echo "$VPN_CONFIG_CONTENT" | grep -q "PostDown"; then
    register_check "PostDown Scripts" PASS "PostDown cleanup configured"
  fi

  # Check for IP forwarding (needed for VPN server)
  if sysctl net.ipv4.ip_forward 2>/dev/null | grep -q "= 1"; then
    register_check "IP Forwarding" PASS "IPv4 forwarding enabled"
  else
    register_check "IP Forwarding" WARN "IPv4 forwarding disabled (needed for routing)"
  fi
fi

# === Common Network Checks (Both VPN Types) ===
section "Network & Firewall"

# Check for IP forwarding (critical for VPN server)
if [[ -f "/proc/sys/net/ipv4/ip_forward" ]]; then
  ip_forward=$(cat /proc/sys/net/ipv4/ip_forward)
  if [[ "$ip_forward" == "1" ]]; then
    register_check "IPv4 Forwarding" PASS "enabled"
  else
    register_check "IPv4 Forwarding" FAIL "disabled (required for VPN routing)"
  fi
fi

# Check firewall rules for VPN
if command -v iptables >/dev/null 2>&1; then
  vpn_rules=$(iptables -L -n 2>/dev/null | grep -iE "openvpn|wireguard|wg|tun|1194" | wc -l || echo "0")
  if [[ "$vpn_rules" -gt 0 ]]; then
    register_check "Firewall Rules" PASS "$vpn_rules VPN-related iptables rules"
  else
    register_check "Firewall Rules" WARN "no obvious VPN firewall rules (verify NAT/masquerade)"
  fi

  # Check for MASQUERADE/SNAT
  if iptables -t nat -L POSTROUTING -n 2>/dev/null | grep -qE "MASQUERADE|SNAT"; then
    register_check "NAT Configuration" PASS "NAT/MASQUERADE configured"
  else
    register_check "NAT Configuration" WARN "no NAT rules found (clients may not reach internet)"
  fi
fi

# Check if VPN port is listening
case "$vpn_type" in
  "openvpn")
    vpn_port=$(get_config_value "port" || echo "1194")
    ;;
  "wireguard")
    vpn_port=$(get_config_value "ListenPort" || echo "51820")
    ;;
esac

if [[ -n "$vpn_port" ]]; then
  if command -v ss >/dev/null 2>&1; then
    if ss -lun 2>/dev/null | grep -q ":${vpn_port}[[:space:]]"; then
      register_check "VPN Port Listening" PASS "listening on UDP port $vpn_port"
    else
      register_check "VPN Port Listening" WARN "not listening on expected port $vpn_port"
    fi
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
