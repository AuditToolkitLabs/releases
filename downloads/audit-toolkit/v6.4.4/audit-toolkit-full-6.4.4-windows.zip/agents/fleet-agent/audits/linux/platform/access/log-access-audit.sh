#!/usr/bin/env bash
# Log Access / Hygiene Audit (portable)
#
# @elevation: partial
# @elevation-reason: Log files in /var/log may have restricted permissions
#
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly MAX_DEPTH=2
readonly MAX_FILES_PER_DIR=2000
LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0
LOGS_CSV=""; ERRORS_CSV=""
# default dirs
DIRS=(/var/log /var/log/nginx /var/log/apache2 /var/log/mysql /var/log/mariadb /var/log/postgresql)

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'; GREEN=$'\e[0;32m'; YELLOW=$'\e[0;33m'; BLUE=$'\e[0;34m'; CYAN=$'\e[0;36m'; BOLD=$'\e[1m'; NC=$'\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift||true; local msg="$*"; local ts line; ts="$(_timestamp)"; printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"; [[ "$QUIET" != "true" ]] && echo "$line"; [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local n="$1" r="$2" m="${3:-}"; TOTAL_CHECKS=$((TOTAL_CHECKS+1)); case "$r" in PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}";; FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}";; WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}";; SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}";; esac; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true; }
section(){ local t="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}"; echo -e "${BOLD}${CYAN} $t${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}"; [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :; }

read_dirs_from_config(){ local cfg="$1"; if [[ -f "$cfg" ]]; then while IFS= read -r line; do [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue; DIRS+=("$line"); done < "$cfg"; _log INFO "Loaded directories from $cfg"; else _log WARN "Config not found: $cfg"; fi }

audit_firewalls_quick(){ section "Firewall Snapshot"; if have_ufw; then ufw status verbose 2>/dev/null | grep -qi active && register_check "UFW" PASS "active" || register_check "UFW" WARN "inactive"; else register_check "UFW" SKIP "not installed"; fi
  if have_firewalld; then firewall-cmd --state 2>/dev/null | grep -q running && register_check "firewalld" PASS "running" || register_check "firewalld" WARN "not running"; else register_check "firewalld" SKIP "not installed"; fi
  if have_nft; then local n; n=$(nft list ruleset 2>/dev/null | grep -c '^table' || echo 0); [[ "$n" -gt 0 ]] && register_check "nftables" PASS "$n tables" || register_check "nftables" SKIP "no rules"; else register_check "nftables" SKIP "not installed"; fi }

audit_listeners(){ section "Listening Ports"; if ! ss_listen >/dev/null; then register_check "socket tool" FAIL "no ss/netstat"; return 0; fi
  local out; out=$(ss_listen || true); local tcp udp; tcp=$(echo "$out" | grep -c '^tcp' || echo 0); udp=$(echo "$out" | grep -c '^udp' || echo 0)
  register_check "TCP listening sockets" PASS "$tcp"; register_check "UDP listening sockets" PASS "$udp"; }

audit_log_dirs(){ section "Log Directories Overview"; local d scanned=0 risky=0; for d in "${DIRS[@]}"; do
  if [[ -d "$d" ]]; then scanned=$((scanned+1)); local mode owner size; mode=$(stat -c '%a' "$d" 2>/dev/null || echo "?"); owner=$(stat -c '%U:%G' "$d" 2>/dev/null || echo "?:?"); size=$(du -sh "$d" 2>/dev/null | cut -f1 || echo "?"); local last="${mode: -1}"; if [[ "$last" =~ [2367] ]]; then register_check "Dir perms: $d" WARN "mode=$mode owner=$owner size=$size (world-writable)"; risky=$((risky+1)); else register_check "Dir perms: $d" PASS "mode=$mode owner=$owner size=$size"; fi
  else register_check "Dir present: $d" SKIP "not found"; fi
  done; register_check "Directories scanned" PASS "$scanned"; }

audit_world_access_logs(){ section "World-Accessible Log Files"; local d cnt=0; for d in "${DIRS[@]}"; do [[ -d "$d" ]] || continue; while IFS= read -r -d '' p; do local octal; octal=$(stat -c '%a' -- "$p" 2>/dev/null || echo "?"); local last="${octal: -1}"; if [[ "$last" =~ ^[0-7]$ ]]; then (( last & 2 )) && cnt=$((cnt+1)); (( last & 4 )) && cnt=$((cnt+1)); fi; done < <(find "$d" -mindepth 1 -maxdepth "$MAX_DEPTH" -type f -print0 2>/dev/null | head -z -n "$MAX_FILES_PER_DIR"); done; [[ "$cnt" -gt 0 ]] && register_check "World-accessible log files" WARN "$cnt found" || register_check "World-accessible log files" PASS "none"; }

audit_journald(){ section "Journald Configuration"; local conf="/etc/systemd/journald.conf"; if ! has_systemd; then register_check "journald" SKIP "systemd not present"; return 0; fi
  [[ -f "$conf" ]] && register_check "journald.conf present" PASS "$conf" || register_check "journald.conf present" SKIP "using defaults"; if [[ -d /var/log/journal ]]; then local jsize; jsize=$(du -sh /var/log/journal 2>/dev/null | cut -f1 || echo "?"); register_check "Journal dir size" PASS "$jsize"; fi }

audit_logrotate(){ section "Logrotate"; if ! command -v logrotate >/dev/null 2>&1; then register_check "logrotate" WARN "not installed"; return 0; fi
  register_check "logrotate installed" PASS "$(logrotate --version 2>&1 | head -n1 || echo unknown)"; [[ -f /etc/logrotate.conf ]] && register_check "Main configuration" PASS "/etc/logrotate.conf" || register_check "Main configuration" WARN "Missing /etc/logrotate.conf"; if [[ -d /etc/logrotate.d ]]; then local n; n=$(find /etc/logrotate.d -type f 2>/dev/null | wc -l || echo 0); register_check "/etc/logrotate.d entries" PASS "$n"; else register_check "/etc/logrotate.d" WARN "Directory missing"; fi }

export_logs_csv(){ [[ -n "${LOGS_CSV}" ]] || { register_check "Logs CSV export" SKIP "no path"; return 0; }; section "Logs CSV Export"; local tmp; tmp="$(mktemp)"; printf '%s
' 'directory,path,type,owner,group,perm_symbolic,perm_octal,size,mtime_iso,world_readable,world_writable' > "$tmp"; local d; for d in "${DIRS[@]}"; do [[ -d "$d" ]] || continue; while IFS= read -r -d '' p; do local type owner group octal sym size mtime last wrd='false' wwt='false' mtime_esc; type=$(stat -c '%F' -- "$p" 2>/dev/null || echo '?'); owner=$(stat -c '%U' -- "$p" 2>/dev/null || echo '?'); group=$(stat -c '%G' -- "$p" 2>/dev/null || echo '?'); octal=$(stat -c '%a' -- "$p" 2>/dev/null || echo '?'); sym=$(stat -c '%A' -- "$p" 2>/dev/null || echo '?'); size=$(stat -c '%s' -- "$p" 2>/dev/null || echo '?'); mtime=$(stat -c '%y' -- "$p" 2>/dev/null || echo '?'); last="${octal: -1}"; if [[ "$last" =~ ^[0-7]$ ]]; then (( last & 4 )) && wrd='true'; (( last & 2 )) && wwt='true'; fi; mtime_esc="${mtime//, / }"; printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
' "$d" "$p" "$type" "$owner" "$group" "$sym" "$octal" "$size" "$mtime_esc" "$wrd" "$wwt" >> "$tmp"; done < <(find "$d" -mindepth 1 -maxdepth "$MAX_DEPTH" -print0 2>/dev/null | head -z -n "$MAX_FILES_PER_DIR"); done; if mv -f -- "$tmp" "$LOGS_CSV" 2>/dev/null; then register_check "Logs CSV export" PASS "$LOGS_CSV"; else register_check "Logs CSV export" FAIL "unable to write $LOGS_CSV"; fi }

export_errors_csv(){ [[ -n "${ERRORS_CSV}" ]] || { register_check "Errors CSV export" SKIP "no path"; return 0; }; section "Errors CSV Export"; if ! has_systemd || ! command -v journalctl >/dev/null 2>&1; then register_check "journalctl" SKIP "systemd/journalctl not present"; return 0; fi; local tmp; tmp="$(mktemp)"; printf '%s
' 'unit,priority,timestamp_iso,message' > "$tmp"; local units=(nginx.service apache2.service mysql.service mariadb.service postgresql.service sshd.service); local u; for u in "${units[@]}"; do systemctl cat "$u" >/dev/null 2>&1 || continue; journalctl -u "$u" -p err --no-pager --output=short-iso -n 200 2>/dev/null | while IFS= read -r line; do local ts msg; ts=$(awk '{print $1" "$2}' <<<"$line"); msg=$(echo "$line" | cut -d':' -f4- | sed 's/^\s*//'); msg="${msg//\"/}"; printf '%s,%s,%s,"%s"
' "$u" "err" "$ts" "$msg" >> "$tmp"; done; done; if mv -f -- "$tmp" "$ERRORS_CSV" 2>/dev/null; then register_check "Errors CSV export" PASS "$ERRORS_CSV"; else register_check "Errors CSV export" FAIL "unable to write $ERRORS_CSV"; fi
}

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Log access & hygiene audit (portable)
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug output
      --paths DIRS      Comma-separated list of log directories
      --config FILE     Read directories from file (one per line)
      --logs-csv FILE   Export file metadata CSV
      --errors-csv FILE Export journal error CSV (systemd only)
      --no-color        Disable color
  -h, --help            Help
      --version         Version
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary(){ echo; echo -e "${BOLD}LOG ACCESS / HYGIENE SUMMARY${NC}"; printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"; }

main(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;; -q|--quiet) QUIET=true; shift;; -v|--verbose) VERBOSE=true; shift;; --paths) [[ $# -ge 2 ]] || { echo "ERROR: --paths needs value" >&2; exit 1; }; IFS=',' read -r -a DIRS <<<"$2"; shift 2;; --config) [[ $# -ge 2 ]] || { echo "ERROR: --config needs path" >&2; exit 1; }; read_dirs_from_config "$2"; shift 2;; --logs-csv) LOGS_CSV="${2:-}"; shift 2;; --errors-csv) ERRORS_CSV="${2:-}"; shift 2;; --no-color) NO_COLOR=true; shift;; -h|--help) usage; exit 0;; --version) version; exit 0;; *) echo "Unknown option: $1" >&2; usage >&2; exit 1;; esac; done
  setup_colors; [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  audit_firewalls_quick; audit_listeners; audit_log_dirs; audit_world_access_logs; audit_journald; audit_logrotate; export_logs_csv; export_errors_csv; print_summary; exit "$EXIT_CODE"
}
main "$@"
