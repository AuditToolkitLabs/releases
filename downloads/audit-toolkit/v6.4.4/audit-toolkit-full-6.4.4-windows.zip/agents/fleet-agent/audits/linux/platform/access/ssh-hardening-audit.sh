#!/usr/bin/env bash
#
# SSH Hardening Audit
#
# @elevation: root
# @elevation-reason: Reads /etc/ssh/sshd_config and SSH host keys
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# SSH Hardening Audit (portable)
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly FALLBACK_LOG_FILE="/tmp/security-audit-${SCRIPT_NAME%.sh}.log"
readonly SSHD_CONFIG="${SSHD_CONFIG:-/etc/ssh/sshd_config}"
readonly SSHD_CONFIG_DIR="${SSHD_CONFIG_DIR:-/etc/ssh/sshd_config.d}"

# Use default log if writable, otherwise fall back to /tmp or disable logging
if mkdir -p "$(dirname "$DEFAULT_LOG_FILE")" 2>/dev/null && touch "$DEFAULT_LOG_FILE" 2>/dev/null; then
  LOG_FILE="$DEFAULT_LOG_FILE"
elif touch "$FALLBACK_LOG_FILE" 2>/dev/null; then
  LOG_FILE="$FALLBACK_LOG_FILE"
else
  LOG_FILE=""  # Disable file logging
fi
QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0
AUDIT_PROFILE="baseline"

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'; GREEN=$'\e[0;32m'; YELLOW=$'\e[0;33m'; BLUE=$'\e[0;34m'; CYAN=$'\e[0;36m'; BOLD=$'\e[1m'; NC=$'\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift || true; local msg="$*"; local line; line="[$(_timestamp)] [$level] $msg";
  [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || true; }
  if [[ "$QUIET" != "true" ]]; then case "$level" in ERROR|WARN) echo "$line" >&2 ;; DEBUG) [[ "$VERBOSE" == "true" ]] && echo "$line" ;; *) echo "$line" ;; esac; fi; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local name="$1" result="$2" message="${3:-}"; ((++TOTAL_CHECKS))
  case "$result" in
    PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}" ;;
    FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $name${message:+: $message}" ;;
    WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}" ;;
    SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}" ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$result] $name${message:+: $message}" >> "$LOG_FILE" 2>/dev/null || true
}
section(){ local title="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}";
  echo -e "${BOLD}${CYAN} $title${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}";
  [[ -n "$LOG_FILE" ]] && { echo; echo "=== $title ==="; } >> "$LOG_FILE" 2>/dev/null || true
}

get_sshd_config(){ local key="$1" value=""; [[ -f "$SSHD_CONFIG" ]] && value=$(grep -iE "^[[:space:]]*${key}[[:space:]]+" "$SSHD_CONFIG" 2>/dev/null | tail -1 | awk '{print $2}')
  if [[ -d "$SSHD_CONFIG_DIR" ]]; then local conf dir_value; for conf in "$SSHD_CONFIG_DIR"/*.conf; do [[ -f "$conf" ]] || continue; dir_value=$(grep -iE "^[[:space:]]*${key}[[:space:]]+" "$conf" 2>/dev/null | tail -1 | awk '{print $2}'); [[ -n "$dir_value" ]] && value="$dir_value"; done; fi
  echo "$value"; }

check_ssh_running(){ svc_is_active sshd || svc_is_active ssh; }

audit_ssh_service(){ section "SSH Service Status";
  if ! command -v sshd >/dev/null 2>&1; then register_check "SSH daemon installed" "SKIP" "Not applicable (sshd not installed)"; return 0; fi
  register_check "SSH daemon installed" "PASS" "$(sshd -V 2>&1 | head -1 || echo 'version unknown')"
  if check_ssh_running; then register_check "SSH service active" "PASS" "Running"; else register_check "SSH service active" "WARN" "Not running"; fi
  if svc_is_enabled sshd || svc_is_enabled ssh; then register_check "SSH service enabled" "PASS" "Enabled at boot"; else register_check "SSH service enabled" "WARN" "Not enabled at boot"; fi }

audit_sshd_config_exists(){ section "SSH Configuration Files";
  [[ -f "$SSHD_CONFIG" ]] && register_check "Main config exists" "PASS" "$SSHD_CONFIG" || { register_check "Main config exists" "FAIL" "$SSHD_CONFIG not found"; return 1; }
  if [[ -d "$SSHD_CONFIG_DIR" ]]; then local conf_count; conf_count=$(find "$SSHD_CONFIG_DIR" -name "*.conf" 2>/dev/null | wc -l); register_check "Config.d directory" "PASS" "$conf_count files in $SSHD_CONFIG_DIR"; else register_check "Config.d directory" "SKIP" "Not present"; fi
  if sshd -t -f "$SSHD_CONFIG" 2>/dev/null; then register_check "Config syntax valid" "PASS" "sshd -t passed"; else register_check "Config syntax valid" "WARN" "sshd -t failed or unsupported; review manually"; fi }

audit_protocol_version(){ section "Protocol Security"; local protocol; protocol=$(get_sshd_config "Protocol")
  if [[ -z "$protocol" || "$protocol" == "2" ]]; then register_check "SSH Protocol" "PASS" "Protocol 2 (default)"; else register_check "SSH Protocol" "FAIL" "Protocol $protocol (should be 2)"; fi }

audit_authentication(){ section "Authentication Settings";
  local v; v=$(get_sshd_config "PermitRootLogin"); case "${v,,}" in no|prohibit-password|without-password|forced-commands-only) register_check "PermitRootLogin" PASS "${v:-no}";; yes|"") [[ "$AUDIT_PROFILE" == "baseline" ]] && register_check "PermitRootLogin" WARN "${v:-yes (default)} - consider restricting" || register_check "PermitRootLogin" FAIL "${v:-yes (default)} - should be 'no' or 'prohibit-password'";; *) register_check "PermitRootLogin" WARN "$v (unusual value)";; esac
  v=$(get_sshd_config "PubkeyAuthentication"); [[ -z "$v" || "${v,,}" == "yes" ]] && register_check "PubkeyAuthentication" PASS "${v:-yes (default)}" || register_check "PubkeyAuthentication" WARN "$v - should be 'yes'"
  v=$(get_sshd_config "PasswordAuthentication"); case "${v,,}" in no) register_check "PasswordAuthentication" PASS "Disabled (key-only)";; yes|"") [[ "$AUDIT_PROFILE" == "cis-level2" ]] && register_check "PasswordAuthentication" FAIL "${v:-yes (default)} - should be 'no' for L2" || register_check "PasswordAuthentication" WARN "${v:-yes (default)} - consider 'no' for key-only";; esac
  v=$(get_sshd_config "PermitEmptyPasswords"); [[ -z "$v" || "${v,,}" == "no" ]] && register_check "PermitEmptyPasswords" PASS "${v:-no (default)}" || register_check "PermitEmptyPasswords" FAIL "$v - MUST be 'no'"
  v=$(get_sshd_config "ChallengeResponseAuthentication"); [[ -z "$v" ]] && v=$(get_sshd_config "KbdInteractiveAuthentication"); [[ "${v,,}" == "no" ]] && register_check "ChallengeResponse Auth" PASS "Disabled" || register_check "ChallengeResponse Auth" WARN "${v:-yes (default)} - consider 'no' unless using PAM 2FA"; }

audit_session_settings(){ section "Session Settings";
  local x
  x=$(get_sshd_config "ClientAliveInterval"); if [[ -n "$x" && "$x" -gt 0 ]]; then register_check "ClientAliveInterval" PASS "${x}s"; else register_check "ClientAliveInterval" WARN "${x:-0} - set for idle timeout"; fi
  x=$(get_sshd_config "ClientAliveCountMax"); if [[ -n "$x" && "$x" -le 3 ]]; then register_check "ClientAliveCountMax" PASS "$x"; else register_check "ClientAliveCountMax" WARN "${x:-3 (default)}"; fi
  x=$(get_sshd_config "X11Forwarding"); if [[ "${x,,}" == "no" ]]; then register_check "X11Forwarding" PASS "Disabled"; else [[ "$AUDIT_PROFILE" == "cis-level2" ]] && register_check "X11Forwarding" FAIL "${x:-yes (default)} - should be 'no' for L2" || register_check "X11Forwarding" WARN "${x:-yes (default)} - consider 'no' unless needed"; fi
  x=$(get_sshd_config "AllowTcpForwarding"); if [[ "${x,,}" == "no" ]]; then register_check "AllowTcpForwarding" PASS "Disabled"; else [[ "$AUDIT_PROFILE" == "cis-level2" ]] && register_check "AllowTcpForwarding" WARN "${x:-yes (default)} - consider 'no' for L2" || register_check "AllowTcpForwarding" PASS "${x:-yes (default)}"; fi
  x=$(get_sshd_config "AllowAgentForwarding"); if [[ "${x,,}" == "no" ]]; then register_check "AllowAgentForwarding" PASS "Disabled"; else register_check "AllowAgentForwarding" WARN "${x:-yes (default)} - consider 'no' unless needed"; fi
  x=$(get_sshd_config "PermitUserEnvironment"); if [[ -z "$x" || "${x,,}" == "no" ]]; then register_check "PermitUserEnvironment" PASS "${x:-no (default)}"; else register_check "PermitUserEnvironment" FAIL "$x - should be 'no'"; fi }

audit_access_control(){ section "Access Control";
  local u g; u=$(get_sshd_config "AllowUsers"); g=$(get_sshd_config "AllowGroups")
  if [[ -n "$u" ]]; then register_check "AllowUsers" PASS "Configured: $u"; elif [[ -n "$g" ]]; then register_check "AllowGroups" PASS "Configured: $g"; else [[ "$AUDIT_PROFILE" != "baseline" ]] && register_check "Access whitelist" WARN "No AllowUsers/AllowGroups set - consider restricting" || register_check "Access whitelist" SKIP "Not configured (open to all users)"; fi
  local du dg; du=$(get_sshd_config "DenyUsers"); dg=$(get_sshd_config "DenyGroups"); if [[ -n "$du" || -n "$dg" ]]; then register_check "Deny lists" PASS "DenyUsers=${du:-none} DenyGroups=${dg:-none}"; else register_check "Deny lists" SKIP "Not configured"; fi }

audit_crypto_settings(){ section "Cryptographic Settings";
  local c m k h
  c=$(get_sshd_config "Ciphers"); if [[ -n "$c" ]]; then echo "$c" | grep -qiE '3des|arcfour|blowfish|cast128' && register_check "Ciphers" FAIL "Weak ciphers detected" || register_check "Ciphers" PASS "Custom: ${c:0:50}..."; else register_check "Ciphers" WARN "Using defaults - consider explicit strong list"; fi
  m=$(get_sshd_config "MACs"); if [[ -n "$m" ]]; then echo "$m" | grep -qiE 'md5|96' && register_check "MACs" FAIL "Weak MACs detected" || register_check "MACs" PASS "Custom: ${m:0:50}..."; else register_check "MACs" WARN "Using defaults - consider explicit strong list"; fi
  k=$(get_sshd_config "KexAlgorithms"); if [[ -n "$k" ]]; then echo "$k" | grep -qiE 'diffie-hellman-group1|diffie-hellman-group-exchange-sha1' && register_check "KexAlgorithms" FAIL "Weak key exchange detected" || register_check "KexAlgorithms" PASS "Custom: ${k:0:50}..."; else register_check "KexAlgorithms" WARN "Using defaults"; fi
  h=$(get_sshd_config "HostKeyAlgorithms"); if [[ -n "$h" ]]; then echo "$h" | grep -qi 'ssh-dss' && register_check "HostKeyAlgorithms" FAIL "DSA keys are deprecated" || register_check "HostKeyAlgorithms" PASS "Custom configuration"; else register_check "HostKeyAlgorithms" PASS "Using secure defaults"; fi }

audit_host_keys(){ section "Host Keys"; local key_dir="/etc/ssh" found=0
  if [[ -f "$key_dir/ssh_host_ed25519_key" ]]; then register_check "ED25519 host key" PASS "Present"; ((found++)); else register_check "ED25519 host key" WARN "Not found - recommended"; fi
  if [[ -f "$key_dir/ssh_host_rsa_key" ]]; then local rsa_bits; rsa_bits=$(ssh-keygen -lf "$key_dir/ssh_host_rsa_key" 2>/dev/null | awk '{print $1}'); if [[ -n "$rsa_bits" && "$rsa_bits" -ge 3072 ]]; then register_check "RSA host key" PASS "${rsa_bits} bits"; elif [[ -n "$rsa_bits" && "$rsa_bits" -ge 2048 ]]; then register_check "RSA host key" WARN "${rsa_bits} bits - recommend 3072+"; else register_check "RSA host key" FAIL "${rsa_bits:-unknown} bits - too weak"; fi; ((found++)); fi
  [[ -f "$key_dir/ssh_host_ecdsa_key" ]] && { register_check "ECDSA host key" PASS "Present"; ((found++)); }
  [[ -f "$key_dir/ssh_host_dsa_key" ]] && register_check "DSA host key" FAIL "Present - DSA deprecated, remove"
  [[ $found -eq 0 ]] && register_check "Host keys present" FAIL "No valid host keys found"
  local f; for f in "$key_dir"/ssh_host_*_key; do [[ -f "$f" ]] || continue; local perms; perms=$(stat -c %a "$f" 2>/dev/null || echo "?"); [[ "$perms" == "600" ]] && register_check "Key perms: $(basename "$f")" PASS "600" || register_check "Key perms: $(basename "$f")" FAIL "$perms (should be 600)"; done; }

audit_banner(){ section "Login Banner"; local b; b=$(get_sshd_config "Banner"); if [[ -n "$b" && "$b" != "none" ]]; then [[ -f "$b" ]] && register_check "SSH Banner" PASS "Configured: $b" || register_check "SSH Banner" WARN "File missing: $b"; else [[ "$AUDIT_PROFILE" != "baseline" ]] && register_check "SSH Banner" WARN "No banner configured - recommended for compliance" || register_check "SSH Banner" SKIP "Not configured"; fi; }

audit_logging(){ section "Logging & Auditing"; local l; l=$(get_sshd_config "LogLevel"); case "${l^^}" in VERBOSE|INFO) register_check "LogLevel" PASS "$l";; DEBUG*) register_check "LogLevel" WARN "$l - may be too verbose for production";; ""|QUIET|FATAL|ERROR) register_check "LogLevel" WARN "${l:-INFO (default)} - consider VERBOSE";; *) register_check "LogLevel" PASS "$l";; esac; local sf; sf=$(get_sshd_config "SyslogFacility"); register_check "SyslogFacility" PASS "${sf:-AUTH (default)}"; }

audit_port_and_network(){ section "Network Settings"; local p; p=$(get_sshd_config "Port"); [[ -n "$p" && "$p" != "22" ]] && register_check "SSH Port" PASS "$p (non-standard)" || register_check "SSH Port" WARN "${p:-22} - consider non-standard port"; local af; af=$(get_sshd_config "AddressFamily"); register_check "AddressFamily" PASS "${af:-any (default)}"; local la; la=$(get_sshd_config "ListenAddress"); if [[ -n "$la" && "$la" != "0.0.0.0" && "$la" != "::" ]]; then register_check "ListenAddress" PASS "$la (restricted)"; else register_check "ListenAddress" WARN "${la:-0.0.0.0 (default)} - consider restricting"; fi; }

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable SSH audit (baseline|cis-level1|cis-level2)
  -l, --log FILE       Write to log (default: $DEFAULT_LOG_FILE)
  -q, --quiet          Suppress stdout
  -v, --verbose        Debug
      --no-color       Disable color
      --baseline       Baseline (default)
      --cis-level1     CIS Level 1
      --cis-level2     CIS Level 2
  -h, --help           Help
      --version        Version
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

main(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;; -q|--quiet) QUIET=true; shift;; -v|--verbose) VERBOSE=true; shift;;
  --no-color) NO_COLOR=true; shift;; --baseline) AUDIT_PROFILE="baseline"; shift;; --cis-level1) AUDIT_PROFILE="cis-level1"; shift;; --cis-level2) AUDIT_PROFILE="cis-level2"; shift;;
  -h|--help) usage; exit 0;; --version) version; exit 0;; *) echo "Unknown option: $1" >&2; usage >&2; exit 1;; esac; done
  setup_colors; [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION (profile: $AUDIT_PROFILE)"
  audit_ssh_service; audit_sshd_config_exists || { exit "$EXIT_CODE"; }
  audit_protocol_version; audit_authentication; audit_session_settings; audit_access_control; audit_crypto_settings; audit_host_keys; audit_banner; audit_logging; audit_port_and_network
  exit "$EXIT_CODE"
}
main "$@"
