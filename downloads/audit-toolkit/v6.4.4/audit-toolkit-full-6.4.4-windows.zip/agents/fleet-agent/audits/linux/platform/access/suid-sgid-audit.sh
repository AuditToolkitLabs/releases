#!/usr/bin/env bash
# suid-sgid-audit.sh — SUID/SGID Binary Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.1.13, 6.1.14 (Audit SUID/SGID executables)
# - NIST SP 800-53: CM-6, AC-6 (Least Privilege)
# - PCI DSS: 2.2.4 (Remove unnecessary functionality)
# - DISA STIG: V-38497, V-38498
#
# Checks:
# - SUID binaries against known-good list
# - SGID binaries against known-good list
# - World-writable SUID/SGID files (critical)
# - SUID/SGID in home directories
# - Recently modified SUID/SGID files
#
# @elevation: root
# @elevation-reason: find command across filesystem requires root for complete results
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "SUID/SGID Binary Audit"

# Known legitimate SUID binaries (common across distros)
declare -A KNOWN_SUID=(
  ["/usr/bin/passwd"]=1
  ["/usr/bin/sudo"]=1
  ["/usr/bin/su"]=1
  ["/usr/bin/mount"]=1
  ["/usr/bin/umount"]=1
  ["/usr/bin/newgrp"]=1
  ["/usr/bin/gpasswd"]=1
  ["/usr/bin/chsh"]=1
  ["/usr/bin/chfn"]=1
  ["/usr/bin/pkexec"]=1
  ["/usr/bin/crontab"]=1
  ["/usr/bin/ssh-agent"]=1
  ["/usr/bin/at"]=1
  ["/usr/bin/fusermount"]=1
  ["/usr/bin/fusermount3"]=1
  ["/usr/sbin/pam_timestamp_check"]=1
  ["/usr/sbin/unix_chkpwd"]=1
  ["/usr/lib/polkit-1/polkit-agent-helper-1"]=1
  ["/usr/libexec/polkit-agent-helper-1"]=1
  ["/usr/lib/openssh/ssh-keysign"]=1
  ["/usr/libexec/openssh/ssh-keysign"]=1
  ["/usr/lib/dbus-1.0/dbus-daemon-launch-helper"]=1
  ["/usr/libexec/dbus-1/dbus-daemon-launch-helper"]=1
  # Ping may or may not be SUID depending on capabilities
  ["/usr/bin/ping"]=1
  ["/bin/ping"]=1
  # Legacy paths
  ["/bin/su"]=1
  ["/bin/mount"]=1
  ["/bin/umount"]=1
)

# Known legitimate SGID binaries
declare -A KNOWN_SGID=(
  ["/usr/bin/wall"]=1
  ["/usr/bin/write"]=1
  ["/usr/bin/ssh-agent"]=1
  ["/usr/bin/crontab"]=1
  ["/usr/bin/expiry"]=1
  ["/usr/bin/chage"]=1
  ["/usr/bin/locate"]=1
  ["/usr/bin/mlocate"]=1
  ["/usr/sbin/postdrop"]=1
  ["/usr/sbin/postqueue"]=1
  ["/usr/lib/utempter/utempter"]=1
  ["/usr/libexec/utempter/utempter"]=1
)

# Counters - initialize all count variables to prevent arithmetic errors
unknown_suid=0
unknown_sgid=0
world_writable=0
home_suid_count=0
tmp_suid_count=0
vartmp_suid_count=0
recent_modified=0

section "SUID Binary Scan"

# Find all SUID files
log_info "Scanning for SUID files..."
suid_files=$(find / -xdev -perm -4000 -type f 2>/dev/null || true)
suid_count=$(echo "$suid_files" | grep -c '/' || echo "0")

register_check "Total SUID files" PASS "$suid_count found"

# Check each SUID file
while IFS= read -r file; do
  [[ -z "$file" ]] && continue

  # Check if known
  if [[ -z "${KNOWN_SUID[$file]:-}" ]]; then
    # Unknown SUID binary
    ((unknown_suid++)) || true

    # Get file info
    file_owner=$(stat -c "%U" "$file" 2>/dev/null || echo "unknown")
    file_perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")

    register_check "Unknown SUID: $file" WARN "owner=$file_owner perms=$file_perms"
  fi

  # Check if world-writable (critical vulnerability)
  if [[ -w "$file" ]] 2>/dev/null && stat -c "%a" "$file" 2>/dev/null | grep -qE ".[27]."; then
    ((world_writable++)) || true
    register_check "World-writable SUID: $file" FAIL "CRITICAL"
  fi

done <<< "$suid_files"

if [[ "$unknown_suid" -eq 0 ]]; then
  register_check "Unknown SUID binaries" PASS "none found"
else
  register_check "Unknown SUID summary" WARN "$unknown_suid unknown binaries"
fi

section "SGID Binary Scan"

# Find all SGID files
log_info "Scanning for SGID files..."
sgid_files=$(find / -xdev -perm -2000 -type f 2>/dev/null || true)
sgid_count=$(echo "$sgid_files" | grep -c '/' || echo "0")

register_check "Total SGID files" PASS "$sgid_count found"

# Check each SGID file
while IFS= read -r file; do
  [[ -z "$file" ]] && continue

  # Check if known
  if [[ -z "${KNOWN_SGID[$file]:-}" ]]; then
    # Unknown SGID binary
    ((unknown_sgid++)) || true

    file_group=$(stat -c "%G" "$file" 2>/dev/null || echo "unknown")
    file_perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")

    register_check "Unknown SGID: $file" WARN "group=$file_group perms=$file_perms"
  fi

done <<< "$sgid_files"

if [[ "$unknown_sgid" -eq 0 ]]; then
  register_check "Unknown SGID binaries" PASS "none found"
else
  register_check "Unknown SGID summary" WARN "$unknown_sgid unknown binaries"
fi

section "Home Directory SUID/SGID Check"

# Check for SUID/SGID in home directories (very suspicious)
home_suid_files=$(find /home -perm /6000 -type f 2>/dev/null || true)
home_suid_count=$(echo "$home_suid_files" | grep -c '/' 2>/dev/null || true)
: "${home_suid_count:=0}"

if [[ "$home_suid_count" -gt 0 ]]; then
  register_check "SUID/SGID in /home" FAIL "$home_suid_count files"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    register_check "Home SUID/SGID: $file" FAIL "remove immediately"
  done <<< "$home_suid_files"
else
  register_check "SUID/SGID in /home" PASS "none"
fi

# Check /tmp (should never have SUID/SGID)
tmp_suid_files=$(find /tmp -perm /6000 -type f 2>/dev/null || true)
tmp_suid_count=$(echo "$tmp_suid_files" | grep -c '/' 2>/dev/null || true)
: "${tmp_suid_count:=0}"

if [[ "$tmp_suid_count" -gt 0 ]]; then
  register_check "SUID/SGID in /tmp" FAIL "$tmp_suid_count files"
else
  register_check "SUID/SGID in /tmp" PASS "none"
fi

# Check /var/tmp
vartmp_suid_files=$(find /var/tmp -perm /6000 -type f 2>/dev/null || true)
vartmp_suid_count=$(echo "$vartmp_suid_files" | grep -c '/' 2>/dev/null || true)
: "${vartmp_suid_count:=0}"

if [[ "$vartmp_suid_count" -gt 0 ]]; then
  register_check "SUID/SGID in /var/tmp" FAIL "$vartmp_suid_count files"
else
  register_check "SUID/SGID in /var/tmp" PASS "none"
fi

section "Recently Modified SUID/SGID"

# Find SUID/SGID files modified in last 7 days (suspicious)
recent_suid=$(find / -xdev -perm /6000 -type f -mtime -7 2>/dev/null || true)
recent_count=$(echo "$recent_suid" | grep -c '/' 2>/dev/null || echo "0")

if [[ "$recent_count" -gt 0 ]]; then
  register_check "Recent SUID/SGID changes" WARN "$recent_count files in last 7 days"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    mod_time=$(stat -c "%y" "$file" 2>/dev/null | cut -d' ' -f1 || echo "unknown")
    register_check "Recently modified: $file" WARN "changed $mod_time"
  done <<< "$recent_suid"
else
  register_check "Recent SUID/SGID changes" PASS "none in last 7 days"
fi

section "Critical SUID Binary Status"

# Check critical binaries have correct SUID
critical_suid=(
  "/usr/bin/sudo"
  "/usr/bin/passwd"
  "/usr/bin/su"
)

for binary in "${critical_suid[@]}"; do
  if [[ -f "$binary" ]]; then
    if [[ -u "$binary" ]]; then
      owner=$(stat -c "%U" "$binary" 2>/dev/null || echo "unknown")
      if [[ "$owner" == "root" ]]; then
        register_check "$(basename "$binary") SUID" PASS "correct (root owned)"
      else
        register_check "$(basename "$binary") SUID" FAIL "wrong owner: $owner"
      fi
    else
      register_check "$(basename "$binary") SUID" WARN "not SUID (may use capabilities)"
    fi
  fi
done

section "Capabilities Check"

# Check for files with dangerous capabilities (alternative to SUID)
if command -v getcap >/dev/null 2>&1; then
  caps_files=$(getcap -r / 2>/dev/null | grep -v "^$" || true)
  caps_count=$(echo "$caps_files" | grep -c "=" 2>/dev/null || echo "0")

  register_check "Files with capabilities" PASS "$caps_count found"

  # Check for dangerous capabilities
  dangerous_caps="cap_setuid|cap_setgid|cap_sys_admin|cap_dac_override|cap_fowner"
  dangerous=$(echo "$caps_files" | grep -E "$dangerous_caps" || true)
  dangerous_count=$(echo "$dangerous" | grep -c '/' 2>/dev/null || echo "0")

  if [[ "$dangerous_count" -gt 0 ]]; then
    register_check "Dangerous capabilities" WARN "$dangerous_count files"

    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      file=$(echo "$line" | cut -d' ' -f1)
      caps=$(echo "$line" | cut -d' ' -f2-)
      register_check "Cap: $(basename "$file")" WARN "$caps"
    done <<< "$dangerous"
  else
    register_check "Dangerous capabilities" PASS "none"
  fi
else
  register_check "Capabilities check" SKIP "getcap not available"
fi

section "Summary"

# Overall assessment
total_issues=$((unknown_suid + unknown_sgid + world_writable + home_suid_count + tmp_suid_count))

if [[ "$world_writable" -gt 0 ]] || [[ "$home_suid_count" -gt 0 ]] || [[ "$tmp_suid_count" -gt 0 ]]; then
  register_check "Overall SUID/SGID security" FAIL "critical issues found"
elif [[ "$unknown_suid" -gt 5 ]] || [[ "$unknown_sgid" -gt 5 ]]; then
  register_check "Overall SUID/SGID security" WARN "review unknown binaries"
else
  register_check "Overall SUID/SGID security" PASS "acceptable"
fi

print_summary
exit "$EXIT_CODE"
