#!/usr/bin/env bash
# world-writable-audit.sh — World-Writable Files & Directories Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.1.10, 6.1.11, 6.1.12
# - NIST SP 800-53: AC-6 (Least Privilege), CM-6
# - PCI DSS: 7.1, 7.2 (Access Control)
# - DISA STIG: V-38499
#
# Checks:
# - World-writable files (excluding /tmp, /var/tmp)
# - World-writable directories without sticky bit
# - World-writable config files in /etc
# - Unowned files
# - Nogroup files
#
# @elevation: root
# @elevation-reason: find command across filesystem requires root for complete results
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "World-Writable Audit"

# Initialize counters to prevent arithmetic errors
ww_file_count=0
ww_dir_count=0
etc_ww_count=0
unowned_count=0
nogroup_count=0

# Configuration
MAX_RESULTS=50  # Limit output for large systems

section "World-Writable Files"

# Find world-writable files (excluding temp dirs and special filesystems)
log_info "Scanning for world-writable files..."

ww_files=$(find / -xdev -type f -perm -0002 \
  ! -path "/tmp/*" \
  ! -path "/var/tmp/*" \
  ! -path "/dev/*" \
  ! -path "/proc/*" \
  ! -path "/sys/*" \
  ! -path "/run/*" \
  2>/dev/null | head -n "$MAX_RESULTS" || true)

ww_file_count=$(echo "$ww_files" | grep -c '/' 2>/dev/null || true)
: "${ww_file_count:=0}"

if [[ "$ww_file_count" -eq 0 ]]; then
  register_check "World-writable files" PASS "none found"
else
  register_check "World-writable files" WARN "$ww_file_count found (showing first $MAX_RESULTS)"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue

    perms=$(stat -c "%a" "$file" 2>/dev/null || echo "???")
    owner=$(stat -c "%U:%G" "$file" 2>/dev/null || echo "unknown")

    # Critical if in sensitive paths
    case "$file" in
      /etc/*|/usr/*|/bin/*|/sbin/*)
        register_check "WW file: $file" FAIL "perms=$perms owner=$owner"
        ;;
      *)
        register_check "WW file: $file" WARN "perms=$perms"
        ;;
    esac
  done <<< "$ww_files"
fi

section "World-Writable Directories (No Sticky Bit)"

# Find world-writable directories without sticky bit
log_info "Scanning for world-writable directories without sticky bit..."

ww_dirs=$(find / -xdev -type d -perm -0002 ! -perm -1000 \
  ! -path "/tmp" \
  ! -path "/var/tmp" \
  ! -path "/proc/*" \
  ! -path "/sys/*" \
  2>/dev/null | head -n "$MAX_RESULTS" || true)

ww_dir_count=$(echo "$ww_dirs" | grep -c '/' 2>/dev/null || true)
: "${ww_dir_count:=0}"

if [[ "$ww_dir_count" -eq 0 ]]; then
  register_check "WW dirs (no sticky)" PASS "none found"
else
  register_check "WW dirs (no sticky)" FAIL "$ww_dir_count found"

  while IFS= read -r dir; do
    [[ -z "$dir" ]] && continue

    perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "???")
    register_check "WW dir: $dir" FAIL "perms=$perms (add sticky bit)"
  done <<< "$ww_dirs"
fi

section "Temp Directory Sticky Bit"

# Check that standard temp directories have sticky bit
temp_dirs=("/tmp" "/var/tmp")

for dir in "${temp_dirs[@]}"; do
  if [[ -d "$dir" ]]; then
    perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "???")

    # Should be 1777 (sticky bit set)
    if [[ "$perms" == "1777" ]]; then
      register_check "$dir sticky bit" PASS "1777"
    elif [[ "$perms" =~ ^1 ]]; then
      register_check "$dir sticky bit" PASS "$perms"
    else
      register_check "$dir sticky bit" FAIL "$perms (should be 1777)"
    fi
  fi
done

section "Sensitive Config Files (/etc)"

# Check for world-writable files in /etc (critical)
log_info "Scanning /etc for world-writable files..."

etc_ww=$(find /etc -xdev -type f -perm -0002 2>/dev/null || true)
etc_ww_count=$(echo "$etc_ww" | grep -c '/' 2>/dev/null || true)
: "${etc_ww_count:=0}"

if [[ "$etc_ww_count" -eq 0 ]]; then
  register_check "WW files in /etc" PASS "none"
else
  register_check "WW files in /etc" FAIL "$etc_ww_count files"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    register_check "WW: $file" FAIL "fix immediately"
  done <<< "$etc_ww"
fi

# Check critical config files specifically
critical_files=(
  "/etc/passwd"
  "/etc/shadow"
  "/etc/group"
  "/etc/gshadow"
  "/etc/sudoers"
  "/etc/ssh/sshd_config"
  "/etc/crontab"
)

for file in "${critical_files[@]}"; do
  if [[ -f "$file" ]]; then
    perms=$(stat -c "%a" "$file" 2>/dev/null || echo "???")

    # Check if world-writable or world-readable (for sensitive files)
    case "$file" in
      /etc/shadow|/etc/gshadow)
        # Should be 000 or 640
        if [[ "$perms" =~ ^(0|600|640)$ ]]; then
          register_check "$(basename "$file") perms" PASS "$perms"
        else
          register_check "$(basename "$file") perms" FAIL "$perms (should be 000/640)"
        fi
        ;;
      /etc/sudoers)
        # Should be 440
        if [[ "$perms" == "440" ]]; then
          register_check "$(basename "$file") perms" PASS "$perms"
        else
          register_check "$(basename "$file") perms" WARN "$perms (should be 440)"
        fi
        ;;
      *)
        # Should not be world-writable
        if echo "$perms" | grep -qE ".[27].$"; then
          register_check "$(basename "$file") perms" FAIL "$perms (world-writable)"
        else
          register_check "$(basename "$file") perms" PASS "$perms"
        fi
        ;;
    esac
  fi
done

section "Home Directories"

# Check home directory permissions
if [[ -d /home ]]; then
  for home_dir in /home/*/; do
    [[ ! -d "$home_dir" ]] && continue

    user=$(basename "$home_dir")
    perms=$(stat -c "%a" "$home_dir" 2>/dev/null || echo "???")

    # Home should be 700 or 750, not world-accessible
    case "$perms" in
      700|750)
        register_check "Home: $user" PASS "$perms"
        ;;
      *)
        if echo "$perms" | grep -qE "..[1-7]$"; then
          register_check "Home: $user" WARN "$perms (world-accessible)"
        else
          register_check "Home: $user" PASS "$perms"
        fi
        ;;
    esac
  done
fi

# Check root home
if [[ -d /root ]]; then
  root_perms=$(stat -c "%a" /root 2>/dev/null || echo "???")
  if [[ "$root_perms" == "700" ]] || [[ "$root_perms" == "550" ]]; then
    register_check "/root perms" PASS "$root_perms"
  else
    register_check "/root perms" WARN "$root_perms (should be 700)"
  fi
fi

section "Unowned Files"

# Find files with no valid owner
log_info "Scanning for unowned files..."

unowned=$(find / -xdev -nouser 2>/dev/null | head -n "$MAX_RESULTS" || true)
unowned_count=$(echo "$unowned" | grep -c '/' 2>/dev/null || true)
: "${unowned_count:=0}"

if [[ "$unowned_count" -eq 0 ]]; then
  register_check "Unowned files" PASS "none"
else
  register_check "Unowned files" WARN "$unowned_count found"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    uid=$(stat -c "%u" "$file" 2>/dev/null || echo "???")
    register_check "Unowned: $file" WARN "UID=$uid"
  done <<< "$unowned"
fi

section "Nogroup Files"

# Find files with no valid group
log_info "Scanning for nogroup files..."

nogroup=$(find / -xdev -nogroup 2>/dev/null | head -n "$MAX_RESULTS" || true)
nogroup_count=$(echo "$nogroup" | grep -c '/' 2>/dev/null || true)
: "${nogroup_count:=0}"

if [[ "$nogroup_count" -eq 0 ]]; then
  register_check "Nogroup files" PASS "none"
else
  register_check "Nogroup files" WARN "$nogroup_count found"

  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    gid=$(stat -c "%g" "$file" 2>/dev/null || echo "???")
    register_check "Nogroup: $file" WARN "GID=$gid"
  done <<< "$nogroup"
fi

section "Cron Directories"

# Check cron-related directories
cron_dirs=(
  "/etc/cron.d"
  "/etc/cron.daily"
  "/etc/cron.hourly"
  "/etc/cron.weekly"
  "/etc/cron.monthly"
  "/var/spool/cron"
  "/var/spool/cron/crontabs"
)

for dir in "${cron_dirs[@]}"; do
  if [[ -d "$dir" ]]; then
    perms=$(stat -c "%a" "$dir" 2>/dev/null || echo "???")

    # Should be 700 or 755, not world-writable
    if echo "$perms" | grep -qE ".[27].$"; then
      register_check "Cron dir: $dir" FAIL "perms=$perms"
    else
      register_check "Cron dir: $dir" PASS "perms=$perms"
    fi
  fi
done

section "SSH Directory Permissions"

# Check .ssh directories in home
for home_dir in /home/* /root; do
  [[ ! -d "$home_dir" ]] && continue

  ssh_dir="$home_dir/.ssh"
  if [[ -d "$ssh_dir" ]]; then
    user=$(basename "$home_dir")
    perms=$(stat -c "%a" "$ssh_dir" 2>/dev/null || echo "???")

    if [[ "$perms" == "700" ]]; then
      register_check ".ssh: $user" PASS "700"
    else
      register_check ".ssh: $user" WARN "$perms (should be 700)"
    fi

    # Check authorized_keys
    auth_keys="$ssh_dir/authorized_keys"
    if [[ -f "$auth_keys" ]]; then
      ak_perms=$(stat -c "%a" "$auth_keys" 2>/dev/null || echo "???")
      if [[ "$ak_perms" == "600" ]] || [[ "$ak_perms" == "644" ]]; then
        register_check "authorized_keys: $user" PASS "$ak_perms"
      else
        register_check "authorized_keys: $user" WARN "$ak_perms"
      fi
    fi

    # Check private keys
    for key in "$ssh_dir"/id_*; do
      [[ ! -f "$key" ]] && continue
      [[ "$key" == *".pub" ]] && continue

      key_perms=$(stat -c "%a" "$key" 2>/dev/null || echo "???")
      key_name=$(basename "$key")

      if [[ "$key_perms" == "600" ]]; then
        register_check "SSH key: $key_name" PASS "600"
      else
        register_check "SSH key: $key_name" FAIL "$key_perms (should be 600)"
      fi
    done
  fi
done

section "Summary"

# Overall assessment
critical=$((etc_ww_count + ww_dir_count))

if [[ "$critical" -gt 0 ]]; then
  register_check "Overall file permissions" FAIL "critical issues found"
elif [[ "$ww_file_count" -gt 10 ]] || [[ "$unowned_count" -gt 0 ]]; then
  register_check "Overall file permissions" WARN "review needed"
else
  register_check "Overall file permissions" PASS "acceptable"
fi

print_summary
exit "$EXIT_CODE"
