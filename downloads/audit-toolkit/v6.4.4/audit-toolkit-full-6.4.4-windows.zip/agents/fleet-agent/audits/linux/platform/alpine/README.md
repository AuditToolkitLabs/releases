# Alpine-Specific Audits

This folder contains audits specific to Alpine Linux distributions.

## Implemented Audits

| Script | Description | Status |
|--------|-------------|--------|
| `alpine-specific-audit.sh` | Comprehensive Alpine security audit | ✅ Complete |

### Checks Included

- Alpine version and release tracking
- APK security repository configuration
- OpenRC service hardening
- BusyBox security settings
- musl libc considerations
- Security update status

## Alpine-Specific Paths

- `/etc/apk/repositories` - APK repository sources
- `/etc/apk/world` - Installed packages
- `/etc/runlevels/` - OpenRC runlevel configuration
- `/etc/init.d/` - OpenRC service scripts

## Key Differences from glibc Distros

- Uses musl libc instead of glibc
- Uses OpenRC instead of systemd
- Uses BusyBox for core utilities
- Minimal base system (~5MB)

## Supported Versions

- Alpine 3.18
- Alpine 3.19
- Alpine 3.20
- Alpine Edge

## Usage

```bash
bash audits/linux/platform/alpine/<script>.sh
```

## Notes

- Many standard Linux tools have different behavior on Alpine
- Use `is_openrc()` from `lib/svc.sh` for service checks
- Use `apk` commands via `lib/pkg.sh` shims
