#!/usr/bin/env bash
# alpine-specific-audit.sh — Alpine Linux-Specific Security Audit
#
# Compliance Mapping:
# - CIS Alpine Linux Benchmark (if available)
# - Alpine Security Tracker
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - apk audit
# - OpenRC hardening
# - BusyBox configuration
# - Repository security
# - musl-specific considerations
#
# @elevation: partial
# @elevation-reason: apk audit and some config checks may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on Alpine
distro=$(detect_distro)
if [[ "$distro" != "alpine" ]]; then
  register_check "Alpine detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Alpine Distribution Info"

# Get Alpine version
alpine_version=$(cat /etc/alpine-release 2>/dev/null || echo "unknown")
register_check "Alpine version" PASS "$alpine_version"

# Check release type (edge vs stable)
if grep -qE "edge" /etc/apk/repositories 2>/dev/null; then
  register_check "Release type" WARN "edge (unstable)"
else
  register_check "Release type" PASS "stable"
fi

# Check architecture
arch=$(uname -m)
register_check "Architecture" PASS "$arch"

section "APK Audit"

# Run apk audit for permission issues
if command -v apk >/dev/null 2>&1; then
  register_check "APK installed" PASS "yes"

  # Check permissions audit
  perm_issues=$(apk audit --check-permissions 2>/dev/null | wc -l || echo "0")
  if [[ "$perm_issues" -eq 0 ]]; then
    register_check "Permission audit" PASS "no issues"
  else
    register_check "Permission audit" WARN "$perm_issues issues"
  fi

  # Check file changes
  file_changes=$(apk audit 2>/dev/null | wc -l || echo "0")
  if [[ "$file_changes" -eq 0 ]]; then
    register_check "File integrity audit" PASS "no changes"
  else
    register_check "File integrity audit" WARN "$file_changes changed files"
  fi

  # Check for backup files
  backup_files=$(apk audit --backup 2>/dev/null | wc -l || echo "0")
  if [[ "$backup_files" -eq 0 ]]; then
    register_check "Config backup files" PASS "none"
  else
    register_check "Config backup files" WARN "$backup_files"
  fi
else
  register_check "APK installed" FAIL "not found"
fi

section "Package Updates"

# Check for available upgrades
upgradable=$(apk version -l '<' 2>/dev/null | wc -l || echo "0")
if [[ "$upgradable" -eq 0 ]]; then
  register_check "Pending updates" PASS "none"
else
  register_check "Pending updates" WARN "$upgradable packages"
fi

# Check repository freshness
apk_index_exists=false
for f in /var/cache/apk/APKINDEX.*.tar.gz; do
  [[ -f "$f" ]] && apk_index_exists=true && break
done
if [[ "$apk_index_exists" == "true" ]] || [[ -d /var/cache/apk ]]; then
  cache_age=$(find /var/cache/apk -name "APKINDEX*" -mtime +1 2>/dev/null | wc -l || echo "0")
  if [[ "$cache_age" -gt 0 ]]; then
    register_check "APK cache" WARN "stale (>1 day)"
  else
    register_check "APK cache" PASS "recent"
  fi
fi

section "Repository Security"

# Check repositories
repos_file="/etc/apk/repositories"
if [[ -f "$repos_file" ]]; then
  # Count repos
  repo_count=$(grep -cE "^[^#]" "$repos_file" || echo "0")
  register_check "Configured repos" PASS "$repo_count"

  # Check for HTTPS
  http_repos=$(grep -cE "^http://" "$repos_file" || echo "0")
  https_repos=$(grep -cE "^https://" "$repos_file" || echo "0")

  if [[ "$http_repos" -gt 0 ]]; then
    register_check "HTTP repos" WARN "$http_repos (use HTTPS)"
  fi

  if [[ "$https_repos" -gt 0 ]]; then
    register_check "HTTPS repos" PASS "$https_repos"
  fi

  # Check for main vs community
  if grep -qE "/main$" "$repos_file"; then
    register_check "Main repository" PASS "enabled"
  fi

  if grep -qE "/community$" "$repos_file"; then
    register_check "Community repository" PASS "enabled"
  fi

  # Check for testing (unstable)
  if grep -qE "/testing$" "$repos_file"; then
    register_check "Testing repository" WARN "enabled (unstable)"
  fi

  # Check for edge (rolling release)
  if grep -qE "/edge/" "$repos_file"; then
    register_check "Edge repository" WARN "enabled"
  fi
fi

section "OpenRC Hardening"

# Check OpenRC
if command -v rc-status >/dev/null 2>&1; then
  register_check "OpenRC installed" PASS "yes"

  # Check runlevel
  current_runlevel=$(rc-status -r 2>/dev/null || echo "unknown")
  register_check "Current runlevel" PASS "$current_runlevel"

  # Check for crashed services
  crashed_services=$(rc-status -c 2>/dev/null | wc -l || echo "0")
  if [[ "$crashed_services" -eq 0 ]]; then
    register_check "Crashed services" PASS "none"
  else
    register_check "Crashed services" FAIL "$crashed_services"
  fi

  # Check cgroups support
  if [[ -d /sys/fs/cgroup ]] && rc-status --servicelist 2>/dev/null | grep -q "cgroups"; then
    register_check "Cgroups support" PASS "enabled"
  fi

  # Check important services
  important_services=("sshd" "iptables" "crond" "syslog")
  for svc in "${important_services[@]}"; do
    if rc-service "$svc" status >/dev/null 2>&1; then
      register_check "Service: $svc" PASS "running"
    elif rc-service --list 2>/dev/null | grep -q "^$svc$"; then
      register_check "Service: $svc" WARN "not running"
    fi
  done
fi

# Check /etc/rc.conf security settings
rc_conf="/etc/rc.conf"
if [[ -f "$rc_conf" ]]; then
  # Check for unicode
  if grep -qE '^rc_controller_cgroups="YES"' "$rc_conf" 2>/dev/null; then
    register_check "RC cgroups" PASS "enabled"
  fi
fi

section "BusyBox Security"

# Check BusyBox
if command -v busybox >/dev/null 2>&1; then
  bb_version=$(busybox --help 2>&1 | head -n1 | grep -oP 'v[\d.]+' || echo "unknown")
  register_check "BusyBox version" PASS "$bb_version"

  # Check linked applets
  bb_applets=$(busybox --list 2>/dev/null | wc -l || echo "0")
  register_check "BusyBox applets" PASS "$bb_applets"

  # Check for suid-root busybox (dangerous)
  bb_path=$(command -v busybox)
  if [[ -u "$bb_path" ]]; then
    register_check "BusyBox SUID" FAIL "set (security risk)"
  else
    register_check "BusyBox SUID" PASS "not set"
  fi

  # Check permissions
  bb_perms=$(stat -c "%a" "$bb_path" 2>/dev/null || echo "unknown")
  if [[ "$bb_perms" == "755" ]]; then
    register_check "BusyBox perms" PASS "$bb_perms"
  else
    register_check "BusyBox perms" WARN "$bb_perms"
  fi
fi

section "musl libc Security"

# Check musl
if ldd --version 2>&1 | grep -q "musl"; then
  musl_version=$(ldd --version 2>&1 | head -n1 || echo "unknown")
  register_check "musl libc" PASS "$musl_version"

  # Check for musl-related packages
  if apk info musl 2>/dev/null | grep -q "musl-"; then
    musl_pkg_version=$(apk info musl 2>/dev/null | grep "musl-" | head -n1)
    register_check "musl package" PASS "installed"
  fi
fi

section "Network Security"

# Check iptables/nftables
if command -v iptables >/dev/null 2>&1; then
  iptables_rules=$(iptables -L -n 2>/dev/null | wc -l || echo "0")
  if [[ "$iptables_rules" -gt 5 ]]; then
    register_check "iptables rules" PASS "$iptables_rules lines"
  else
    register_check "iptables rules" WARN "minimal/none"
  fi

  # Check if iptables service is enabled
  if rc-update show 2>/dev/null | grep -q "iptables"; then
    register_check "iptables boot" PASS "enabled"
  else
    register_check "iptables boot" WARN "not enabled"
  fi
fi

if command -v nft >/dev/null 2>&1; then
  register_check "nftables" PASS "installed"
fi

section "SSH Configuration"

# Check OpenSSH
if [[ -f /etc/ssh/sshd_config ]]; then
  register_check "SSH config" PASS "present"

  # Check for password authentication
  if grep -qE "^PasswordAuthentication\s+no" /etc/ssh/sshd_config; then
    register_check "SSH password auth" PASS "disabled"
  else
    register_check "SSH password auth" WARN "enabled"
  fi

  # Check for root login
  if grep -qE "^PermitRootLogin\s+no" /etc/ssh/sshd_config; then
    register_check "SSH root login" PASS "disabled"
  elif grep -qE "^PermitRootLogin\s+prohibit-password" /etc/ssh/sshd_config; then
    register_check "SSH root login" PASS "key only"
  else
    register_check "SSH root login" WARN "may be enabled"
  fi
fi

section "File System Security"

# Check /tmp
if mount | grep -qE "\s/tmp\s.*noexec"; then
  register_check "/tmp noexec" PASS "yes"
else
  register_check "/tmp noexec" WARN "not set"
fi

if mount | grep -qE "\s/tmp\s.*nosuid"; then
  register_check "/tmp nosuid" PASS "yes"
else
  register_check "/tmp nosuid" WARN "not set"
fi

# Check for world-writable files (quick check)
world_writable=$(find /etc -maxdepth 2 -perm -0002 -type f 2>/dev/null | wc -l || echo "0")
if [[ "$world_writable" -eq 0 ]]; then
  register_check "World-writable in /etc" PASS "none"
else
  register_check "World-writable in /etc" WARN "$world_writable files"
fi

section "User/Auth Security"

# Check for empty passwords
empty_passwords=$(awk -F: '($2 == "" ) { print $1 }' /etc/shadow 2>/dev/null | wc -l || echo "0")
if [[ "$empty_passwords" -eq 0 ]]; then
  register_check "Empty passwords" PASS "none"
else
  register_check "Empty passwords" FAIL "$empty_passwords accounts"
fi

# Check for UID 0 accounts (other than root)
uid_zero=$(awk -F: '($3 == 0 && $1 != "root") { print $1 }' /etc/passwd 2>/dev/null | wc -l || echo "0")
if [[ "$uid_zero" -eq 0 ]]; then
  register_check "Extra UID 0 accounts" PASS "none"
else
  register_check "Extra UID 0 accounts" FAIL "$uid_zero"
fi

# Check shadow file permissions
shadow_perms=$(stat -c "%a" /etc/shadow 2>/dev/null || echo "unknown")
if [[ "$shadow_perms" == "640" ]] || [[ "$shadow_perms" == "600" ]]; then
  register_check "Shadow file perms" PASS "$shadow_perms"
else
  register_check "Shadow file perms" WARN "$shadow_perms"
fi

section "Logging"

# Check syslog service
if rc-service syslog status >/dev/null 2>&1; then
  register_check "Syslog service" PASS "running"
else
  # Check for busybox syslogd
  if pgrep -x syslogd >/dev/null 2>&1; then
    register_check "Syslog (busybox)" PASS "running"
  else
    register_check "Syslog service" WARN "not running"
  fi
fi

# Check log files exist
if [[ -f /var/log/messages ]]; then
  log_size=$(stat -c %s /var/log/messages 2>/dev/null || echo "0")
  log_size_kb=$((log_size / 1024))
  register_check "System log" PASS "${log_size_kb}KB"
fi

print_summary
exit "$EXIT_CODE"
