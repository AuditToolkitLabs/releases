# Arch Linux-Specific Audits

Security audit scripts for Arch Linux and derivatives.

## Included Audits

### arch-specific-audit.sh

Comprehensive Arch-specific security checks including:

- **Distribution Info**: Arch or derivative detection
- **Pacman Security**: GPG signatures, parallel downloads
- **Repository Safety**: Testing repos, unofficial repos
- **AUR Helper Security**: yay/paru hardening settings
- **mkinitcpio**: Fallback image, secure hooks
- **Pacman Hooks**: Integrity and permissions
- **Keyring**: Pacman keyring status
- **Rolling Release**: Kernel module compatibility
- **Secure Boot**: UKI and sbctl detection

## Usage

```bash
# Run directly
bash audits/linux/platform/arch/arch-specific-audit.sh

# Via orchestrator
./orchestrator/orchestrator.sh \
  --path audits/linux/platform/arch/arch-specific-audit.sh

# With all platform audits
./orchestrator/orchestrator.sh --domain platform
```

## Supported Distributions

- Arch Linux
- Manjaro
- EndeavourOS
- Garuda Linux
- Artix Linux (with init system variations)
- Other Arch-based distributions

## Compliance Mapping

| Check | NIST SP 800-53 | CIS | Notes |
|-------|----------------|-----|-------|
| Pacman signatures | CM-6, SI-7 | - | Package integrity |
| AUR helper verification | SI-7 | - | Third-party packages |
| Keyring trust | CM-6 | - | Key management |
| Secure Boot | SI-7 | - | Boot integrity |
| Testing repo warning | CM-2 | - | Stability risk |

## Notes

- Script auto-SKIPs on non-Arch systems
- AUR checks only run if yay/paru installed
- Rolling release: stale kernel modules may appear
- No official CIS benchmark exists for Arch
