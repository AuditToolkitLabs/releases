#!/usr/bin/env bash
# arch-specific-audit.sh — Arch Linux-Specific Security Audit
#
# Compliance Mapping:
# - Arch Linux Security Advisories (ASA)
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - Pacman configuration and updates
# - AUR helper security
# - mkinitcpio configuration
# - Arch-specific services
# - Rolling release security considerations
# - Build system security
#
# @elevation: partial
# @elevation-reason: Pacman database and some config checks may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on Arch Linux or derivative
distro=$(detect_distro)
case "$distro" in
    arch|manjaro|endeavouros|garuda|artix)
        ;;
    *)
        register_check "Arch-based detected" SKIP "running on $distro"
        print_summary
        exit "$EXIT_CODE"
        ;;
esac

section "Arch Distribution Info"

# Get version info (Arch uses rolling release date)
if [[ -f /etc/arch-release ]]; then
    register_check "Arch Linux" PASS "detected"
fi

# Check derivative
arch_derivative="$distro"
if [[ "$arch_derivative" != "arch" ]]; then
    register_check "Derivative" PASS "$arch_derivative"
fi

# Check architecture
arch=$(uname -m)
register_check "Architecture" PASS "$arch"

# Get kernel version (important for rolling release)
kernel_version=$(uname -r)
register_check "Kernel version" PASS "$kernel_version"

section "Pacman Package Manager"

# Check Pacman
if command -v pacman >/dev/null 2>&1; then
    register_check "Pacman installed" PASS "yes"

    # Check pacman.conf settings
    if [[ -f /etc/pacman.conf ]]; then
        # Check SigLevel (package signing)
        siglevel=$(grep -E "^SigLevel\s*=" /etc/pacman.conf 2>/dev/null | head -1 | cut -d= -f2 | tr -d ' ' || true)
        : "${siglevel:=Required DatabaseOptional}"

        if echo "$siglevel" | grep -qi "never"; then
            register_check "Package signatures" FAIL "disabled (SigLevel=Never)"
        elif echo "$siglevel" | grep -qi "required"; then
            register_check "Package signatures" PASS "required"
        else
            register_check "Package signatures" WARN "$siglevel"
        fi

        # Check if testing repos are enabled (security risk)
        if grep -qE "^\[testing\]|^\[community-testing\]" /etc/pacman.conf 2>/dev/null; then
            register_check "Testing repos" WARN "enabled (less stable)"
        else
            register_check "Testing repos" PASS "disabled"
        fi

        # Check ParallelDownloads
        parallel=$(grep -E "^ParallelDownloads\s*=" /etc/pacman.conf 2>/dev/null || true)
        if [[ -n "$parallel" ]]; then
            register_check "Parallel downloads" PASS "enabled"
        fi

        # Check Color (just info)
        if grep -qE "^Color" /etc/pacman.conf 2>/dev/null; then
            register_check "Colored output" PASS "enabled"
        fi
    fi

    # Check for pending updates (with timeout)
    if command -v timeout >/dev/null 2>&1; then
        # First sync db
        timeout 15 pacman -Sy >/dev/null 2>&1 || true
        pending=$(timeout 10 pacman -Qu 2>/dev/null | wc -l || true)
    else
        pending=$(pacman -Qu 2>/dev/null | wc -l || true)
    fi
    : "${pending:=0}"

    if [[ "$pending" -eq 0 ]]; then
        register_check "Pending updates" PASS "system up to date"
    elif [[ "$pending" -lt 20 ]]; then
        register_check "Pending updates" WARN "$pending packages"
    else
        register_check "Pending updates" FAIL "$pending packages (update soon)"
    fi

    # Check orphan packages
    orphans=$(pacman -Qtdq 2>/dev/null | wc -l || echo "0")
    if [[ "$orphans" -eq 0 ]]; then
        register_check "Orphan packages" PASS "none"
    else
        register_check "Orphan packages" WARN "$orphans (run: pacman -Rns \$(pacman -Qtdq))"
    fi

    # Check foreign packages (AUR/manual)
    foreign=$(pacman -Qm 2>/dev/null | wc -l || echo "0")
    register_check "Foreign packages (AUR)" PASS "$foreign installed"

else
    register_check "Pacman installed" FAIL "not found"
fi

section "AUR Helper Security"

# Check for AUR helpers
aur_helpers=("yay" "paru" "trizen" "pikaur" "aurman" "pakku")
aur_found=""

for helper in "${aur_helpers[@]}"; do
    if command -v "$helper" >/dev/null 2>&1; then
        aur_found="$helper"
        break
    fi
done

if [[ -n "$aur_found" ]]; then
    register_check "AUR helper" PASS "$aur_found installed"

    # Check if running as root (bad practice)
    if [[ $EUID -eq 0 ]]; then
        register_check "AUR as root" WARN "running as root (use regular user)"
    else
        register_check "AUR as root" PASS "running as user"
    fi

    # Check makepkg.conf
    if [[ -f /etc/makepkg.conf ]]; then
        # Check BUILDDIR (shouldn't be /tmp for security)
        builddir=$(grep -E "^BUILDDIR=" /etc/makepkg.conf 2>/dev/null | cut -d= -f2 || true)
        if [[ "$builddir" == "/tmp" ]] || [[ "$builddir" == *"/tmp/"* ]]; then
            register_check "BUILDDIR location" WARN "using /tmp (consider dedicated dir)"
        else
            register_check "BUILDDIR location" PASS "not /tmp"
        fi

        # Check PKGEXT (compression)
        pkgext=$(grep -E "^PKGEXT=" /etc/makepkg.conf 2>/dev/null | cut -d= -f2 | tr -d "'" || true)
        register_check "Package compression" PASS "${pkgext:-.pkg.tar.zst}"
    fi
else
    register_check "AUR helper" SKIP "none installed"
fi

section "Pacman Hooks & Security"

# Check pacman hooks directory
if [[ -d /etc/pacman.d/hooks ]]; then
    hook_count=$(find /etc/pacman.d/hooks -name "*.hook" 2>/dev/null | wc -l || echo "0")
    register_check "Custom hooks" PASS "$hook_count hooks"
else
    register_check "Custom hooks" PASS "none (using defaults)"
fi

# Check pacman keyring
if [[ -d /etc/pacman.d/gnupg ]]; then
    register_check "Pacman keyring" PASS "initialized"

    # Check keyring freshness
    keyring_age=$(find /etc/pacman.d/gnupg -name "trustdb.gpg" -mtime +90 2>/dev/null | wc -l || echo "0")
    if [[ "$keyring_age" -gt 0 ]]; then
        register_check "Keyring freshness" WARN "older than 90 days (run: pacman-key --refresh-keys)"
    else
        register_check "Keyring freshness" PASS "recent"
    fi
else
    register_check "Pacman keyring" FAIL "not initialized"
fi

section "mkinitcpio Configuration"

# Check mkinitcpio (Arch initramfs)
if [[ -f /etc/mkinitcpio.conf ]]; then
    register_check "mkinitcpio.conf" PASS "exists"

    # Check HOOKS
    hooks=$(grep -E "^HOOKS=" /etc/mkinitcpio.conf 2>/dev/null | cut -d= -f2 || true)

    # Check for encrypt hook (disk encryption)
    if echo "$hooks" | grep -q "encrypt\|sd-encrypt"; then
        register_check "Disk encryption hook" PASS "enabled"
    else
        register_check "Disk encryption hook" SKIP "not configured"
    fi

    # Check for lvm2 hook
    if echo "$hooks" | grep -q "lvm2\|sd-lvm2"; then
        register_check "LVM hook" PASS "enabled"
    fi

    # Check COMPRESSION
    compression=$(grep -E "^COMPRESSION=" /etc/mkinitcpio.conf 2>/dev/null | cut -d= -f2 | tr -d '"' || true)
    register_check "Initramfs compression" PASS "${compression:-zstd (default)}"
else
    register_check "mkinitcpio.conf" WARN "not found"
fi

section "Systemd Services"

# Check for suspicious enabled services
if command -v systemctl >/dev/null 2>&1; then
    # Check if systemd-resolved is active (DNS security)
    if systemctl is-active systemd-resolved >/dev/null 2>&1; then
        register_check "systemd-resolved" PASS "active"
    else
        register_check "systemd-resolved" WARN "not active"
    fi

    # Check if systemd-timesyncd is active (time security)
    if systemctl is-active systemd-timesyncd >/dev/null 2>&1; then
        register_check "Time sync" PASS "systemd-timesyncd active"
    elif systemctl is-active chronyd >/dev/null 2>&1; then
        register_check "Time sync" PASS "chrony active"
    elif systemctl is-active ntpd >/dev/null 2>&1; then
        register_check "Time sync" PASS "ntpd active"
    else
        register_check "Time sync" WARN "no time sync service"
    fi

    # Check reflector (mirror list updates)
    if systemctl is-enabled reflector.timer >/dev/null 2>&1; then
        register_check "Reflector timer" PASS "enabled"
    else
        register_check "Reflector timer" WARN "not enabled (consider enabling)"
    fi
fi

section "Firewall"

# Check for firewall
if command -v ufw >/dev/null 2>&1; then
    if ufw status 2>/dev/null | grep -qi "active"; then
        register_check "Firewall (ufw)" PASS "active"
    else
        register_check "Firewall (ufw)" WARN "installed but inactive"
    fi
elif command -v firewall-cmd >/dev/null 2>&1; then
    if systemctl is-active firewalld >/dev/null 2>&1; then
        register_check "Firewall (firewalld)" PASS "active"
    else
        register_check "Firewall (firewalld)" WARN "installed but inactive"
    fi
elif command -v iptables >/dev/null 2>&1; then
    rules=$(iptables -L -n 2>/dev/null | grep -c "^Chain" || echo "0")
    if [[ "$rules" -gt 3 ]]; then
        register_check "Firewall (iptables)" PASS "configured"
    else
        register_check "Firewall" WARN "iptables minimal rules"
    fi
else
    register_check "Firewall" FAIL "none detected"
fi

section "Secure Boot"

# Check Secure Boot
if [[ -d /sys/firmware/efi ]]; then
    register_check "EFI boot" PASS "UEFI system"

    if command -v mokutil >/dev/null 2>&1; then
        sb_state=$(mokutil --sb-state 2>/dev/null | head -1 || echo "unknown")
        if echo "$sb_state" | grep -qi "enabled"; then
            register_check "Secure Boot" PASS "enabled"
        else
            register_check "Secure Boot" WARN "disabled"
        fi
    elif command -v bootctl >/dev/null 2>&1; then
        sb_status=$(bootctl status 2>/dev/null | grep -i "secure boot" || true)
        if echo "$sb_status" | grep -qi "enabled"; then
            register_check "Secure Boot" PASS "enabled"
        else
            register_check "Secure Boot" WARN "disabled or unknown"
        fi
    else
        register_check "Secure Boot" SKIP "tools not available"
    fi
else
    register_check "EFI boot" SKIP "legacy BIOS"
fi

section "AppArmor/SELinux"

# Check MAC system (Arch doesn't enable by default)
if command -v aa-status >/dev/null 2>&1; then
    if aa-status --enabled 2>/dev/null; then
        enforced=$(aa-status 2>/dev/null | grep -oP '\d+(?= profiles are in enforce mode)' || echo "0")
        register_check "AppArmor" PASS "$enforced profiles enforcing"
    else
        register_check "AppArmor" WARN "installed but not enabled"
    fi
elif command -v getenforce >/dev/null 2>&1; then
    selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
    if [[ "$selinux_mode" == "Enforcing" ]]; then
        register_check "SELinux" PASS "enforcing"
    else
        register_check "SELinux" WARN "$selinux_mode"
    fi
else
    register_check "MAC system" WARN "none (consider AppArmor)"
fi

section "Summary"

# Overall assessment
failed_count=$FAILED_CHECKS
warn_count=$WARNING_CHECKS

if [[ "$failed_count" -eq 0 ]] && [[ "$warn_count" -lt 3 ]]; then
    register_check "Arch security posture" PASS "good"
elif [[ "$failed_count" -eq 0 ]]; then
    register_check "Arch security posture" WARN "review warnings"
else
    register_check "Arch security posture" FAIL "issues detected"
fi

print_summary
exit "$EXIT_CODE"
