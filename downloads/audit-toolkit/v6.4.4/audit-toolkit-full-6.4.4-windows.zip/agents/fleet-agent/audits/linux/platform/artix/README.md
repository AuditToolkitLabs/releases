# Artix Linux Audit Scripts

This directory contains Artix-specific security audits that leverage Artix Linux's
unique features as a systemd-free Arch derivative supporting multiple init systems.

## Scripts

| Script | Description | CIS Reference |
|--------|-------------|---------------|
| `artix-specific-audit.sh` | Core Artix hardening checks | CIS Arch |

## Artix-Specific Considerations

### Init Systems

Artix supports multiple init systems, with each providing distinct
service management:

| Init System | Service Command | Config Location |
|-------------|-----------------|-----------------|
| **OpenRC** | `rc-service`, `rc-update` | `/etc/init.d/`, `/etc/conf.d/` |
| **runit** | `sv`, `vsv` | `/etc/runit/sv/` |
| **s6** | `s6-svc`, `s6-rc` | `/etc/s6/sv/` |
| **dinit** | `dinitctl` | `/etc/dinit.d/` |

The audit automatically detects the active init system and runs appropriate checks.

### Package Management

Artix uses **pacman** with Artix-specific repositories:
- `[system]` - Core Artix packages (init-specific)
- `[world]` - Artix community packages
- `[galaxy]` - Additional Artix packages

Arch Linux repos can be enabled but are filtered for systemd dependencies.

### User Session Management

Without systemd-logind, Artix uses alternatives:
- **elogind** - Standalone logind fork (most common)
- **ConsoleKit2** - Alternative session management

## Running Audits

```bash
# Run Artix-specific audit
sudo bash audits/linux/platform/artix/artix-specific-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --match artix
```

## Init-Specific Notes

### OpenRC

```bash
# Check service status
rc-service sshd status
# List enabled services
rc-update show default
```

### runit

```bash
# Check service status
sv status /var/service/sshd
# List enabled services (symlinked to runsvdir)
ls /var/service/
```

### s6

```bash
# Check service status
s6-svstat /run/service/sshd
# List enabled services
s6-rc -a list
```

### dinit

```bash
# Check service status
dinitctl status sshd
# List enabled services
dinitctl list
```

## References

- [Artix Wiki](https://wiki.artixlinux.org/)
- [Artix Init Systems](https://wiki.artixlinux.org/Main/Init_Systems)
- [CIS Arch Linux Benchmark](https://www.cisecurity.org/benchmark/arch_linux)
- [elogind Project](https://github.com/elogind/elogind)
