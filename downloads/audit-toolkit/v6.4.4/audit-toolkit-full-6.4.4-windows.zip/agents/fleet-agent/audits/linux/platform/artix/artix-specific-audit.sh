#!/usr/bin/env bash
# artix-specific-audit.sh — Artix Linux Security Audit
#
# @elevation: root
# @elevation-reason: Checks system services and configuration files
#
# Artix Linux is Arch-based but uses alternative init systems:
# - OpenRC, runit, s6, or dinit (instead of systemd)
#
# Compliance Mapping:
# - CIS Benchmark: Arch Linux (adapted for non-systemd)
# - NIST SP 800-53: CM-6, CM-7, SI-2
#
# Checks:
# - Init system detection and validation
# - Package manager (pacman) security
# - Service management per init system
# - Artix-specific repositories
# - Boot loader configuration

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../lib/common.sh
. "$SCRIPT_DIR/../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/distro.sh
. "$SCRIPT_DIR/../../../lib/distro.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/svc.sh
. "$SCRIPT_DIR/../../../lib/svc.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/pkg.sh
. "$SCRIPT_DIR/../../../lib/pkg.sh"

setup_colors

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="1.0.0"

section "Artix Linux Security Audit"
echo "Script: $SCRIPT_NAME v$SCRIPT_VERSION"
echo "Artix Linux — Arch-based with alternative init systems"

# ============================================================
# Verify we're on Artix
# ============================================================
section "Distribution Verification"

DISTRO=$(detect_distro)
if [[ "$DISTRO" != "artix" ]]; then
  register_check "Artix Linux" SKIP "Not Artix (detected: $DISTRO)"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Artix Linux" PASS "Confirmed"

# Get Artix version
if [[ -f /etc/artix-release ]]; then
  artix_release=$(cat /etc/artix-release 2>/dev/null || echo "unknown")
  register_check "Artix release" PASS "$artix_release"
elif [[ -f /etc/os-release ]]; then
  version=$(grep "^VERSION=" /etc/os-release 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "rolling")
  register_check "Artix version" PASS "$version"
fi

# ============================================================
# Init System Detection
# ============================================================
section "Init System Configuration"

INIT_SYSTEM=$(detect_init_system)
register_check "Init system" PASS "$INIT_SYSTEM"

case "$INIT_SYSTEM" in
  openrc)
    register_check "Init type" PASS "OpenRC (Gentoo-style)"

    # Check OpenRC specific paths
    if [[ -d /etc/init.d ]]; then
      register_check "/etc/init.d" PASS "exists"
    else
      register_check "/etc/init.d" WARN "missing"
    fi
    if [[ -d /etc/runlevels ]]; then
      register_check "/etc/runlevels" PASS "exists"
    else
      register_check "/etc/runlevels" WARN "missing"
    fi

    # Check rc.conf
    if [[ -f /etc/rc.conf ]]; then
      register_check "rc.conf" PASS "exists"
      # Check for hostname setting
      if grep -q "^hostname=" /etc/rc.conf 2>/dev/null; then
        register_check "Hostname in rc.conf" PASS "configured"
      fi
    fi
    ;;

  runit)
    register_check "Init type" PASS "runit (Void-style)"

    # Check runit service directories
    for dir in /run/runit/supervise /var/service /etc/runit/sv; do
      if [[ -d "$dir" ]]; then
        svc_count=$(find "$dir" -maxdepth 1 -type d 2>/dev/null | wc -l)
        register_check "$dir" PASS "$((svc_count - 1)) services"
      fi
    done

    # Check sv command
    if command -v sv >/dev/null 2>&1; then
      register_check "sv command" PASS "available"
    else
      register_check "sv command" FAIL "not found"
    fi
    ;;

  s6)
    register_check "Init type" PASS "s6 (skarnet)"

    # Check s6 service directories
    for dir in /run/s6/services /var/run/s6/services /etc/s6/sv; do
      if [[ -d "$dir" ]]; then
        svc_count=$(find "$dir" -maxdepth 1 -type d 2>/dev/null | wc -l)
        register_check "$dir" PASS "$((svc_count - 1)) services"
      fi
    done

    # Check s6-rc database
    if command -v s6-rc-db >/dev/null 2>&1; then
      register_check "s6-rc-db" PASS "available"
      db_services=$(s6-rc-db list all 2>/dev/null | wc -l || echo 0)
      register_check "s6 services" PASS "$db_services in database"
    fi
    ;;

  dinit)
    register_check "Init type" PASS "dinit"

    # Check dinit service directory
    if [[ -d /etc/dinit.d ]]; then
      svc_count=$(find /etc/dinit.d -maxdepth 1 -type f -name "*.conf" 2>/dev/null | wc -l || echo 0)
      register_check "/etc/dinit.d" PASS "$svc_count service files"
    fi

    # Check dinitctl
    if command -v dinitctl >/dev/null 2>&1; then
      register_check "dinitctl" PASS "available"
      running=$(dinitctl list 2>/dev/null | grep -c '^\[+\]' || echo 0)
      register_check "Running services" PASS "$running active"
    fi
    ;;

  *)
    register_check "Init system" WARN "Unknown: $INIT_SYSTEM"
    ;;
esac

# ============================================================
# Package Manager Security (pacman)
# ============================================================
section "Package Manager Security"

# Check pacman configuration
if [[ -f /etc/pacman.conf ]]; then
  register_check "pacman.conf" PASS "exists"

  # Check SigLevel (package signing)
  sig_level=$(grep -E "^SigLevel\s*=" /etc/pacman.conf 2>/dev/null | head -1 || echo "")
  if [[ -n "$sig_level" ]]; then
    if echo "$sig_level" | grep -qE "(Required|PackageRequired)"; then
      register_check "Package signing" PASS "Required"
    else
      register_check "Package signing" WARN "$sig_level"
    fi
  else
    register_check "Package signing" WARN "Using default"
  fi

  # Check for Artix repositories
  if grep -q "\[galaxy\]" /etc/pacman.conf 2>/dev/null ||
    grep -q "\[world\]" /etc/pacman.conf 2>/dev/null ||
    grep -q "\[system\]" /etc/pacman.conf 2>/dev/null; then
    register_check "Artix repos" PASS "configured"
  else
    register_check "Artix repos" WARN "standard repos not found"
  fi

  # Check for Arch repos (optional, may be enabled)
  if grep -qE "^\[extra\]|^\[core\]|^\[community\]" /etc/pacman.conf 2>/dev/null; then
    register_check "Arch repos" WARN "enabled (ensure compatibility)"
  fi
else
  register_check "pacman.conf" FAIL "not found"
fi

# Check for pending updates
if command -v pacman >/dev/null 2>&1; then
  updates=$(pacman -Qu 2>/dev/null | wc -l || echo 0)
  if [[ "$updates" -eq 0 ]]; then
    register_check "Pending updates" PASS "system up to date"
  elif [[ "$updates" -lt 10 ]]; then
    register_check "Pending updates" WARN "$updates packages"
  else
    register_check "Pending updates" FAIL "$updates packages need updating"
  fi
fi

# Check pacman keyring
if [[ -d /etc/pacman.d/gnupg ]]; then
  key_count=$(pacman-key --list-keys 2>/dev/null | grep -c "^pub" || echo 0)
  register_check "Pacman keyring" PASS "$key_count keys"
else
  register_check "Pacman keyring" FAIL "not initialized"
fi

# ============================================================
# Essential Services
# ============================================================
section "Essential Services"

# Services to check based on init system
essential_services=("syslog-ng" "cronie" "dbus" "elogind")

for svc in "${essential_services[@]}"; do
  # Service names may vary by init system
  svc_names=("$svc" "${svc}d" "${svc}-daemon")

  found=false
  for name in "${svc_names[@]}"; do
    if svc_is_active "$name" 2>/dev/null; then
      register_check "$svc service" PASS "running ($name)"
      found=true
      break
    fi
  done

  if ! $found; then
    # Check if installed but not running
    if pkg_installed "$svc" 2>/dev/null; then
      register_check "$svc service" WARN "installed but not running"
    else
      register_check "$svc service" SKIP "not installed"
    fi
  fi
done

# elogind vs consolekit2 (seat management without systemd)
if svc_is_active elogind 2>/dev/null; then
  register_check "Seat management" PASS "elogind"
elif svc_is_active consolekit 2>/dev/null; then
  register_check "Seat management" PASS "ConsoleKit"
else
  register_check "Seat management" WARN "none detected"
fi

# ============================================================
# Network Services
# ============================================================
section "Network Configuration"

# Check network manager
network_found=false
for nm in NetworkManager connman dhcpcd networkmanager; do
  if svc_is_active "$nm" 2>/dev/null; then
    register_check "Network management" PASS "$nm active"
    network_found=true
    break
  fi
done

if ! $network_found; then
  # Check for static network config
  if [[ -f /etc/conf.d/net ]] || [[ -d /etc/network ]]; then
    register_check "Network management" PASS "static configuration"
  else
    register_check "Network management" WARN "no manager detected"
  fi
fi

# ============================================================
# Boot Security
# ============================================================
section "Boot Security"

# Check bootloader
if [[ -d /sys/firmware/efi ]]; then
  register_check "Boot mode" PASS "UEFI"

  # Check for Secure Boot
  secureboot_var_found=false
  for secureboot_var in /sys/firmware/efi/efivars/SecureBoot-*; do
    if [[ -e "$secureboot_var" ]]; then
      secureboot_var_found=true
      break
    fi
  done

  if $secureboot_var_found ||
    mokutil --sb-state 2>/dev/null | grep -qi "enabled"; then
    register_check "Secure Boot" PASS "enabled"
  else
    register_check "Secure Boot" WARN "not enabled"
  fi
else
  register_check "Boot mode" PASS "Legacy BIOS"
fi

# Check GRUB config
for grub_cfg in /boot/grub/grub.cfg /boot/grub2/grub.cfg; do
  if [[ -f "$grub_cfg" ]]; then
    grub_perms=$(stat -c "%a" "$grub_cfg" 2>/dev/null || echo "unknown")
    if [[ "$grub_perms" -le 600 ]]; then
      register_check "GRUB config perms" PASS "$grub_perms"
    else
      register_check "GRUB config perms" WARN "$grub_perms (should be 600)"
    fi

    # Check for password protection
    if grep -q "password_pbkdf2\|password " "$grub_cfg" 2>/dev/null; then
      register_check "GRUB password" PASS "configured"
    else
      register_check "GRUB password" WARN "not set"
    fi
    break
  fi
done

# ============================================================
# Artix-Specific Security
# ============================================================
section "Artix-Specific Configuration"

# Check for artix-keyring
if pkg_installed artix-keyring 2>/dev/null; then
  register_check "artix-keyring" PASS "installed"
else
  register_check "artix-keyring" FAIL "not installed"
fi

# Check for base system packages
base_packages=("base" "linux" "linux-firmware")
for pkg in "${base_packages[@]}"; do
  if pkg_installed "$pkg" 2>/dev/null; then
    register_check "Package: $pkg" PASS "installed"
  else
    register_check "Package: $pkg" WARN "not found"
  fi
done

# Init-specific packages
case "$INIT_SYSTEM" in
  openrc)
    if pkg_installed openrc 2>/dev/null; then
      register_check "openrc package" PASS "installed"
    else
      register_check "openrc package" FAIL "missing"
    fi
    ;;
  runit)
    if pkg_installed runit 2>/dev/null; then
      register_check "runit package" PASS "installed"
    else
      register_check "runit package" FAIL "missing"
    fi
    ;;
  s6)
    if pkg_installed s6 2>/dev/null; then
      register_check "s6 package" PASS "installed"
    else
      register_check "s6 package" FAIL "missing"
    fi
    ;;
  dinit)
    if pkg_installed dinit 2>/dev/null; then
      register_check "dinit package" PASS "installed"
    else
      register_check "dinit package" FAIL "missing"
    fi
    ;;
esac

# ============================================================
# User Session Management (without systemd-logind)
# ============================================================
section "User Session Management"

# elogind provides logind functionality without systemd
if command -v loginctl >/dev/null 2>&1; then
  sessions=$(loginctl list-sessions --no-legend 2>/dev/null | wc -l || echo 0)
  register_check "Session tracking" PASS "$sessions active sessions (elogind)"
elif command -v ck-list-sessions >/dev/null 2>&1; then
  sessions=$(ck-list-sessions 2>/dev/null | grep -c "Session" || echo 0)
  register_check "Session tracking" PASS "$sessions sessions (ConsoleKit)"
else
  register_check "Session tracking" WARN "no session manager"
fi

# Check PAM integration
if [[ -f /etc/pam.d/system-login ]]; then
  if grep -q "pam_elogind.so\|pam_ck_connector.so" /etc/pam.d/system-login 2>/dev/null; then
    register_check "PAM session integration" PASS "configured"
  else
    register_check "PAM session integration" WARN "may need configuration"
  fi
fi

print_summary
exit "$EXIT_CODE"
