#!/usr/bin/env bash
#
# Hardware Information & System Inventory Audit
#
# Compliance Mapping:
# - CIS Controls: 1.1, 1.2, 1.3, 16.11
# - NIST SP 800-53: CM-8, SI-4
# - ISO 27001: A.8.1, A.8.2
# - OWASP ASVS: V10
# - UK NCSC: Asset Management
# - PCI DSS: 2.4, 10.2
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Hardware Information & System Inventory Audit (portable)
# Purpose: Non-destructive inventory of system hardware (CPU, RAM, disk, network)
# Exit: 0=OK, 1=Warnings, 2=Failures
#
# @elevation: partial
# @elevation-reason: dmidecode, lshw, and some /sys paths may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/distro.sh
. "$SCRIPT_DIR/../../../../lib/distro.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="1.0.0"

register_check "Audit Script" PASS "$SCRIPT_NAME v$SCRIPT_VERSION"

# Hardware thresholds
readonly CPU_TEMP_WARN=75 # °C
readonly CPU_TEMP_CRIT=85 # °C
readonly MEM_WARN_PERCENT=85
readonly DISK_WARN_PERCENT=80

# --- CPU Information ---
audit_cpu_info() {
  section "CPU Information"

  # CPU model and count
  if [[ -f /proc/cpuinfo ]]; then
    local model cores physical_id
    model=$(grep -m1 "model name" /proc/cpuinfo 2>/dev/null | cut -d: -f2- | xargs || echo "Unknown")
    cores=$(grep -c "^processor" /proc/cpuinfo 2>/dev/null || echo 0)
    physical_id=$(grep "physical id" /proc/cpuinfo 2>/dev/null | sort -u | wc -l || echo 1)

    register_check "CPU Model" PASS "$model"
    register_check "CPU Cores (logical)" PASS "$cores"
    register_check "CPU Sockets (physical)" PASS "$physical_id"

    # CPU architecture
    local arch
    arch=$(uname -m 2>/dev/null || echo "unknown")
    register_check "Architecture" PASS "$arch"
  else
    register_check "/proc/cpuinfo" WARN "not available"
  fi

  # CPU frequency
  if [[ -f /proc/cpuinfo ]]; then
    local freq
    freq=$(grep -m1 "cpu MHz" /proc/cpuinfo 2>/dev/null | awk '{printf "%.2f GHz", $4/1000}' || echo "N/A")
    if [[ "$freq" != "N/A" ]]; then
      register_check "CPU Frequency" PASS "$freq"
    else
      register_check "CPU Frequency" SKIP "unavailable"
    fi
  fi

  # CPU load average
  if [[ -f /proc/loadavg ]]; then
    local load1 load5 load15
    read -r load1 load5 load15 _ </proc/loadavg
    register_check "Load Average (1m/5m/15m)" PASS "$load1 / $load5 / $load15"
  fi

  # CPU temperature (if sensors available)
  if command -v sensors >/dev/null 2>&1; then
    local temp
    temp=$(sensors 2>/dev/null | grep -i "core 0" | awk '{print $3}' | tr -d '+°C' | head -n1 || echo "")
    if [[ -n "$temp" && "$temp" =~ ^[0-9]+\.?[0-9]*$ ]]; then
      local temp_int=${temp%.*}
      if ((temp_int >= CPU_TEMP_CRIT)); then
        register_check "CPU Temperature" FAIL "${temp}°C (>= ${CPU_TEMP_CRIT}°C critical)"
      elif ((temp_int >= CPU_TEMP_WARN)); then
        register_check "CPU Temperature" WARN "${temp}°C (>= ${CPU_TEMP_WARN}°C)"
      else
        register_check "CPU Temperature" PASS "${temp}°C"
      fi
    else
      register_check "CPU Temperature" SKIP "sensors not configured"
    fi
  else
    register_check "CPU Temperature" SKIP "lm-sensors not installed"
  fi

  # Virtualization detection
  local virt=""
  if command -v systemd-detect-virt >/dev/null 2>&1; then
    virt=$(systemd-detect-virt 2>/dev/null || echo "none")
  elif grep -q "hypervisor" /proc/cpuinfo 2>/dev/null; then
    virt="detected (hypervisor flag)"
  elif [[ -d /proc/vz ]] && [[ ! -d /proc/bc ]]; then
    virt="openvz-container"
  elif [[ -f /proc/1/cgroup ]] && grep -q "docker\|lxc" /proc/1/cgroup 2>/dev/null; then
    virt="container (docker/lxc)"
  else
    virt="none"
  fi
  register_check "Virtualization" PASS "$virt"
}

# --- Memory Information ---
audit_memory_info() {
  section "Memory Information"

  if ! command -v free >/dev/null 2>&1; then
    register_check "free command" FAIL "not available"
    return 0
  fi

  # Total RAM
  local mem_total_kb mem_total_gb mem_used_kb mem_avail_kb mem_percent
  mem_total_kb=$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2}' || echo 0)
  mem_total_gb=$(awk "BEGIN {printf \"%.2f\", $mem_total_kb/1024/1024}")
  register_check "Total RAM" PASS "${mem_total_gb} GB"

  # Memory usage
  local mem_line
  mem_line=$(free | grep "^Mem:" || true)
  if [[ -n "$mem_line" ]]; then
    mem_used_kb=$(awk '{print $3}' <<<"$mem_line")
    mem_avail_kb=$(awk '{print $7}' <<<"$mem_line")

    if [[ ${mem_total_kb:-0} -gt 0 ]]; then
      mem_percent=$((mem_used_kb * 100 / mem_total_kb))
      local mem_used_gb mem_avail_gb
      mem_used_gb=$(awk "BEGIN {printf \"%.2f\", $mem_used_kb/1024/1024}")
      mem_avail_gb=$(awk "BEGIN {printf \"%.2f\", $mem_avail_kb/1024/1024}")

      if [[ $mem_percent -ge $MEM_WARN_PERCENT ]]; then
        register_check "Memory Usage" WARN "${mem_percent}% (${mem_used_gb}/${mem_total_gb} GB)"
      else
        register_check "Memory Usage" PASS "${mem_percent}% (${mem_used_gb}/${mem_total_gb} GB)"
      fi
      register_check "Memory Available" PASS "${mem_avail_gb} GB"
    fi
  fi

  # Swap
  local swap_line swap_total swap_used swap_percent
  swap_line=$(free | grep "^Swap:" || true)
  if [[ -n "$swap_line" ]]; then
    swap_total=$(awk '{print $2}' <<<"$swap_line")
    swap_used=$(awk '{print $3}' <<<"$swap_line")

    if [[ ${swap_total:-0} -eq 0 ]]; then
      register_check "Swap" PASS "not configured"
    else
      swap_percent=$((swap_used * 100 / swap_total))
      local swap_total_gb swap_used_gb
      swap_total_gb=$(awk "BEGIN {printf \"%.2f\", $swap_total/1024/1024}")
      swap_used_gb=$(awk "BEGIN {printf \"%.2f\", $swap_used/1024/1024}")
      register_check "Swap Total" PASS "${swap_total_gb} GB"
      register_check "Swap Usage" PASS "${swap_percent}% (${swap_used_gb}/${swap_total_gb} GB)"
    fi
  fi
}

# --- Disk Information ---
audit_disk_info() {
  section "Disk Information"

  # Block devices
  if command -v lsblk >/dev/null 2>&1; then
    local disk_count
    disk_count=$(lsblk -dno NAME,TYPE 2>/dev/null | grep -c "disk" || echo 0)
    register_check "Physical Disks" PASS "$disk_count detected"

    # List disk models and sizes
    while IFS= read -r line; do
      local name size model
      name=$(awk '{print $1}' <<<"$line")
      size=$(awk '{print $2}' <<<"$line")
      model=$(awk '{$1=$2=""; print $0}' <<<"$line" | xargs)
      [[ -z "$model" ]] && model="Unknown"
      register_check "Disk: /dev/$name" PASS "${size} - ${model}"
    done < <(lsblk -dno NAME,SIZE,MODEL 2>/dev/null | grep -v "loop\|sr" || true)
  else
    register_check "lsblk" SKIP "not available"
  fi

  # Filesystem usage
  local fs_output
  fs_output=$(df -PhT 2>/dev/null | awk 'NR==1 || ($2!="tmpfs" && $2!="devtmpfs" && $2!="overlay" && $2!="squashfs")')

  if [[ -n "$fs_output" ]]; then
    local header=true
    while IFS= read -r line; do
      if $header; then
        header=false
        continue
      fi

      local _fs _type size used _avail use_pct mount
      read -r _fs _type size used _avail use_pct mount <<<"$line"
      use_pct=${use_pct%\%}

      if [[ "$use_pct" =~ ^[0-9]+$ ]]; then
        if [[ $use_pct -ge $DISK_WARN_PERCENT ]]; then
          register_check "Filesystem: $mount" WARN "${use_pct}% (${used}/${size})"
        else
          register_check "Filesystem: $mount" PASS "${use_pct}% (${used}/${size})"
        fi
      fi
    done <<<"$fs_output"
  else
    register_check "Filesystem usage" WARN "unable to query"
  fi

  # Disk I/O statistics (if available)
  if [[ -f /proc/diskstats ]]; then
    local disk_io_count
    disk_io_count=$(wc -l </proc/diskstats 2>/dev/null || echo 0)
    register_check "Disk I/O stats" PASS "$disk_io_count devices tracked"
  fi
}

# --- Network Information ---
audit_network_info() {
  section "Network Information"

  # Hostname
  local hostname fqdn
  hostname=$(hostname 2>/dev/null || echo "unknown")
  fqdn=$(hostname -f 2>/dev/null || hostname 2>/dev/null || echo "unknown")
  register_check "Hostname" PASS "$hostname"
  [[ "$fqdn" != "$hostname" ]] && register_check "FQDN" PASS "$fqdn"

  # Network interfaces
  if command -v ip >/dev/null 2>&1; then
    local iface_count
    iface_count=$(ip -o link show 2>/dev/null | grep -vc "lo:" || echo 0)
    register_check "Network Interfaces" PASS "$iface_count (excluding loopback)"

    # List active interfaces with IPs
    while IFS= read -r line; do
      local iface state ip
      iface=$(awk '{print $2}' <<<"$line" | tr -d ':')
      state=$(awk '{print $9}' <<<"$line")

      # Get IP address
      ip=$(ip -4 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n1 || echo "no IP")

      if [[ "$state" == "UP" ]]; then
        register_check "Interface: $iface" PASS "UP - $ip"
      else
        register_check "Interface: $iface" SKIP "DOWN"
      fi
    done < <(ip -o link show 2>/dev/null | grep -v "lo:")
  elif command -v ifconfig >/dev/null 2>&1; then
    local iface_count
    iface_count=$(ifconfig -a 2>/dev/null | grep -c "^[a-z]" || echo 0)
    register_check "Network Interfaces" PASS "$iface_count detected (ifconfig)"
  else
    register_check "Network tools" WARN "neither ip nor ifconfig available"
  fi

  # Default gateway
  if command -v ip >/dev/null 2>&1; then
    local gateway
    gateway=$(ip route show default 2>/dev/null | awk '/default/ {print $3; exit}' || echo "none")
    register_check "Default Gateway" PASS "$gateway"
  fi

  # DNS resolvers
  if [[ -f /etc/resolv.conf ]]; then
    local dns_count
    dns_count=$(grep -c "^nameserver" /etc/resolv.conf 2>/dev/null || echo 0)
    register_check "DNS Resolvers" PASS "$dns_count configured"
  fi
}

# --- System Information ---
audit_system_info() {
  section "System Information"

  # OS details
  local os_name os_version os_id
  if [[ -f /etc/os-release ]]; then
    os_name=$(grep "^PRETTY_NAME=" /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo "Unknown")
    os_version=$(grep "^VERSION=" /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo "Unknown")
    os_id=$(grep "^ID=" /etc/os-release 2>/dev/null | cut -d'=' -f2 | tr -d '"' || echo "unknown")

    register_check "Operating System" PASS "$os_name"
    register_check "OS Version" PASS "$os_version"
    register_check "OS ID" PASS "$os_id"
  else
    register_check "OS Information" WARN "/etc/os-release not found"
  fi

  # Kernel version
  local kernel
  kernel=$(uname -r 2>/dev/null || echo "unknown")
  register_check "Kernel Version" PASS "$kernel"

  # Kernel architecture
  local arch
  arch=$(uname -m 2>/dev/null || echo "unknown")
  register_check "Kernel Architecture" PASS "$arch"

  # System uptime
  if [[ -f /proc/uptime ]]; then
    local uptime_sec uptime_days uptime_hours uptime_mins
    uptime_sec=$(cut -d. -f1 /proc/uptime 2>/dev/null || echo 0)
    uptime_days=$((uptime_sec / 86400))
    uptime_hours=$(((uptime_sec % 86400) / 3600))
    uptime_mins=$(((uptime_sec % 3600) / 60))
    register_check "System Uptime" PASS "${uptime_days}d ${uptime_hours}h ${uptime_mins}m"
  fi

  # Boot time
  if command -v uptime >/dev/null 2>&1; then
    local boot_time
    boot_time=$(uptime -s 2>/dev/null || echo "unknown")
    [[ "$boot_time" != "unknown" ]] && register_check "Last Boot" PASS "$boot_time"
  fi

  # Init system
  local init_system
  if is_systemd; then
    init_system="systemd"
  elif is_openrc; then
    init_system="OpenRC"
  else
    init_system="unknown"
  fi
  register_check "Init System" PASS "$init_system"

  # Timezone
  if [[ -f /etc/timezone ]]; then
    local tz
    tz=$(cat /etc/timezone 2>/dev/null || echo "unknown")
    register_check "Timezone" PASS "$tz"
  elif [[ -L /etc/localtime ]]; then
    local tz
    tz=$(readlink /etc/localtime 2>/dev/null | sed 's|.*/zoneinfo/||' || echo "unknown")
    register_check "Timezone" PASS "$tz"
  fi

  # Date/Time
  local datetime
  datetime=$(date -Iseconds 2>/dev/null || date 2>/dev/null || echo "unknown")
  register_check "Current Time" PASS "$datetime"
}

# --- Main ---
main() {
  audit_system_info
  audit_cpu_info
  audit_memory_info
  audit_disk_info
  audit_network_info
  print_summary
  exit "$EXIT_CODE"
}

main "$@"
