#!/usr/bin/env bash
#
# OS Baseline Security Audit
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# OS Baseline Security Audit (portable)
#
# @elevation: partial
# @elevation-reason: Some system config and security checks may require root
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly WORLD_WRITABLE_LIMIT=50

LOG_FILE="$DEFAULT_LOG_FILE"
QUIET=false
VERBOSE=false
VERY_VERBOSE=false
NO_COLOR=false
EXIT_CODE=0

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  GREEN=$'\e[0;32m'
  YELLOW=$'\e[0;33m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local level="$1"
  shift || true
  local msg="$*"
  local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >>"$LOG_FILE" 2>/dev/null || :; }
  if [[ "$QUIET" != "true" ]]; then case "$level" in ERROR | WARN) echo "$line" >&2 ;; DEBUG) [[ "$VERBOSE" == "true" ]] && echo "$line" ;; TRACE) [[ "$VERY_VERBOSE" == "true" ]] && echo "$line" ;; *) echo "$line" ;; esac fi
}
_dbg() { [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*" || :; }
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0
SKIPPED_CHECKS=0
register_check() {
  local name="$1" result="$2" message="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
  case "$result" in
    PASS)
      PASSED_CHECKS=$((PASSED_CHECKS + 1))
      echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}"
      ;;
    FAIL)
      FAILED_CHECKS=$((FAILED_CHECKS + 1))
      EXIT_CODE=2
      echo -e " ${RED}[FAIL]${NC}  $name${message:+: $message}"
      ;;
    WARN)
      WARNING_CHECKS=$((WARNING_CHECKS + 1))
      [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1
      echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}"
      ;;
    SKIP)
      SKIPPED_CHECKS=$((SKIPPED_CHECKS + 1))
      echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}"
      ;;
  esac
  [[ -n "$LOG_FILE" ]] && { echo "[$(_timestamp)] [$result] $name${message:+: $message}" >>"$LOG_FILE" 2>/dev/null || :; }
}
section() {
  local title="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $title${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && {
    echo
    echo "=== $title ==="
  } >>"$LOG_FILE" 2>/dev/null || :
}
print_summary() {
  echo
  echo -e "${BOLD}+==========================================================+${NC}"
  echo -e "${BOLD}  OS BASELINE AUDIT SUMMARY                                ${NC}"
  echo -e "${BOLD}+==========================================================+${NC}"
  printf "${BOLD} %-12s${NC} %-46s
" "Hostname:" "$(hostname -f 2>/dev/null || hostname)"
  printf "${BOLD} %-12s${NC} %-46s
" "Date:" "$(_timestamp)"
  echo -e "${BOLD}+----------------------+----------------------+-----------+${NC}"
  printf " ${GREEN}✔ PASSED:${NC} %-6d  ${RED}✘ FAILED:${NC} %-6d
" "$PASSED_CHECKS" "$FAILED_CHECKS"
  printf " ${YELLOW}⚠ WARNINGS:${NC} %-4d ${BLUE}◌ SKIPPED:${NC} %-4d
" "$WARNING_CHECKS" "$SKIPPED_CHECKS"
  echo -e "${BOLD}+----------------------+----------------------+-----------+${NC}"
  printf "${BOLD} TOTAL CHECKS: %-37d${NC}
" "$TOTAL_CHECKS"
  echo -e "${BOLD}+==========================================================+${NC}"
}

audit_os_info() {
  section "OS & Package Baseline"
  if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release || true
    register_check "os-release" PASS "ID=${ID:-unknown} ${VERSION_ID:-}"
  else register_check "OS info" WARN "cannot determine distribution"; fi
  local kv arch
  kv=$(uname -r 2>/dev/null || echo unknown)
  arch=$(uname -m 2>/dev/null || echo unknown)
  register_check "Kernel" PASS "version=$kv arch=$arch"
  _dbg "Detected kernel=$kv arch=$arch"
}

audit_security_updates() {
  section "Security & Package Updates"
  IFS='|' read -r sec total < <(pm_updates)
  if [[ "$sec" != "NA" && -n "$sec" ]]; then
    if [[ ${sec:-0} -gt 0 ]]; then
      register_check "Security updates" WARN "${sec} pending"
    else
      register_check "Security updates" PASS "none"
    fi
  else
    register_check "Security updates" SKIP "not available on this distro/tooling"
  fi
  if [[ "$total" != "NA" && -n "$total" ]]; then
    if [[ ${total:-0} -gt 0 ]]; then
      register_check "Upgradable packages" WARN "${total} total"
    else
      register_check "Upgradable packages" PASS "0"
    fi
  else
    register_check "Upgradable packages" SKIP "unknown"
  fi
}

audit_unattended_upgrades() {
  section "Automatic Updates"
  case "$(pm_detect)" in
    apt)
      if dpkg -s unattended-upgrades >/dev/null 2>&1; then
        register_check "unattended-upgrades" PASS "installed"
        if svc_is_enabled unattended-upgrades; then register_check "service enabled" PASS "yes"; else register_check "service enabled" WARN "no"; fi
        if svc_is_active unattended-upgrades; then register_check "service active" PASS "yes"; else register_check "service active" SKIP "inactive (periodic)"; fi
      else
        register_check "unattended-upgrades" WARN "not installed"
      fi
      ;;
    *) register_check "Automatic updates" SKIP "Debian/Ubuntu feature; use distro-native tooling" ;;
  esac
}

audit_time_sync() {
  section "Time Synchronization"
  ntp_synced
  rc=$?
  case "$rc" in 0) register_check "NTP" PASS "synchronized" ;; 1) register_check "NTP" WARN "not synchronized" ;; *) register_check "NTP" SKIP "unknown" ;; esac
}

audit_world_writable() {
  section "World-writable Files/Dirs"
  local ww_files ww_dirs
  ww_files=$(find / -xdev -type f -perm -0002 -not -path "/proc/*" -not -path "/sys/*" -not -path "/dev/*" 2>/dev/null | head -n "$WORLD_WRITABLE_LIMIT" || true)
  if [[ -n "${ww_files:-}" ]]; then
    local c
    c=$(wc -l <<<"$ww_files")
    register_check "World-writable files" WARN "$c shown (limit $WORLD_WRITABLE_LIMIT)"
    [[ "$VERBOSE" == "true" ]] && while read -r f; do _log DEBUG " $f"; done <<<"$ww_files"
  else register_check "World-writable files" PASS "none"; fi
  ww_dirs=$(find / -xdev -type d -perm -0002 ! -perm -1000 -not -path "/proc/*" -not -path "/sys/*" -not -path "/dev/*" 2>/dev/null | head -n 20 || true)
  if [[ -n "${ww_dirs:-}" ]]; then
    register_check "WW dirs (no sticky)" WARN "found"
    [[ "$VERBOSE" == "true" ]] && while read -r d; do _log DEBUG " $d"; done <<<"$ww_dirs"
  else register_check "WW dirs (no sticky)" PASS "none"; fi
}

audit_logrotate() {
  section "Logrotate"
  if ! command -v logrotate >/dev/null 2>&1; then
    register_check "logrotate" WARN "not installed"
    return 0
  fi
  register_check "logrotate installed" PASS "$(logrotate --version 2>&1 | head -n1 || echo unknown)"
  if [[ -f /etc/logrotate.conf ]]; then
    register_check "main config" PASS "/etc/logrotate.conf"
  else
    register_check "main config" WARN "missing"
  fi
  if [[ -d /etc/logrotate.d ]]; then
    local n
    n=$(find /etc/logrotate.d -type f 2>/dev/null | wc -l || echo 0)
    register_check "/etc/logrotate.d entries" PASS "$n"
  else register_check "/etc/logrotate.d" WARN "missing"; fi
}

audit_filesystem_hardening() {
  section "Filesystem Mount Options (CIS 1.1.x)"
  if ! command -v mount >/dev/null 2>&1; then
    register_check "Filesystem checks" SKIP "mount command not available"
    return 0
  fi
  local mount_output
  mount_output=$(mount 2>/dev/null || true)
  # Check /tmp mount options (CIS 1.1.2-1.1.5)
  if echo "$mount_output" | grep -E ' /tmp ' >/dev/null 2>&1; then
    local tmp_opts
    tmp_opts=$(echo "$mount_output" | grep -E ' /tmp ' | awk '{for(i=1;i<=NF;i++) if($i~/^\(/) print $i}')
    if [[ "$tmp_opts" =~ nodev && "$tmp_opts" =~ nosuid && "$tmp_opts" =~ noexec ]]; then
      register_check "/tmp mount (CIS 1.1.2-5)" PASS "nodev,nosuid,noexec set"
    else
      local missing=""
      [[ ! "$tmp_opts" =~ nodev ]] && missing="${missing}nodev "
      [[ ! "$tmp_opts" =~ nosuid ]] && missing="${missing}nosuid "
      [[ ! "$tmp_opts" =~ noexec ]] && missing="${missing}noexec"
      register_check "/tmp mount (CIS 1.1.2-5)" FAIL "Missing: $missing"
    fi
  else
    register_check "/tmp" SKIP "Not a separate filesystem"
  fi
  # Check /var/tmp (CIS 1.1.6-1.1.9)
  if echo "$mount_output" | grep -E ' /var/tmp ' >/dev/null 2>&1; then
    local var_tmp_opts
    var_tmp_opts=$(echo "$mount_output" | grep -E ' /var/tmp ' | awk '{for(i=1;i<=NF;i++) if($i~/^\(/) print $i}')
    if [[ "$var_tmp_opts" =~ nodev && "$var_tmp_opts" =~ nosuid && "$var_tmp_opts" =~ noexec ]]; then
      register_check "/var/tmp mount (CIS 1.1.6-9)" PASS "Hardened"
    else
      register_check "/var/tmp mount (CIS 1.1.6-9)" FAIL "Not hardened"
    fi
  else
    register_check "/var/tmp" SKIP "Not a separate filesystem"
  fi
  # Check /home (CIS 1.1.14)
  if echo "$mount_output" | grep -E ' /home ' >/dev/null 2>&1; then
    local home_opts
    home_opts=$(echo "$mount_output" | grep -E ' /home ' | awk '{for(i=1;i<=NF;i++) if($i~/^\(/) print $i}')
    if [[ "$home_opts" =~ nodev ]]; then
      register_check "/home mount (CIS 1.1.14)" PASS "nodev set"
    else
      register_check "/home mount (CIS 1.1.14)" WARN "nodev not set"
    fi
  else
    register_check "/home" SKIP "Not a separate filesystem"
  fi
  # Check /dev/shm (CIS 1.1.15-1.1.17)
  if echo "$mount_output" | grep -E ' /dev/shm ' >/dev/null 2>&1; then
    local shm_opts
    shm_opts=$(echo "$mount_output" | grep -E ' /dev/shm ' | awk '{for(i=1;i<=NF;i++) if($i~/^\(/) print $i}')
    if [[ "$shm_opts" =~ nodev && "$shm_opts" =~ nosuid && "$shm_opts" =~ noexec ]]; then
      register_check "/dev/shm mount (CIS 1.1.15-17)" PASS "Hardened"
    else
      register_check "/dev/shm mount (CIS 1.1.15-17)" FAIL "Not hardened"
    fi
  else
    register_check "/dev/shm" SKIP "Not found"
  fi
}

audit_kernel_security() {
  section "Kernel Security Settings"
  local params=(
    "kernel.randomize_va_space:2" "kernel.kptr_restrict:1" "kernel.dmesg_restrict:1"
    "net.ipv4.conf.all.rp_filter:1" "net.ipv4.conf.all.accept_redirects:0" "net.ipv4.conf.all.send_redirects:0"
    "net.ipv4.icmp_echo_ignore_broadcasts:1" "net.ipv4.tcp_syncookies:1"
  )
  local p key exp val
  for p in "${params[@]}"; do
    key="${p%%:*}"
    exp="${p##*:}"
    val=$(sysctl -n "$key" 2>/dev/null || echo "unavailable")
    if [[ "$val" == "$exp" ]]; then register_check "$key" PASS "$val"; elif [[ "$val" == "unavailable" ]]; then register_check "$key" SKIP "unavailable"; else register_check "$key" WARN "$val (rec $exp)"; fi
  done
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable OS baseline audit (Debian/Ubuntu, RHEL/Fedora/Alma, SUSE, Arch, Alpine)
  -l, --log FILE         Write log (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          DEBUG
  -vv, --very-verbose    TRACE
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}
version() { echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="${2:-$DEFAULT_LOG_FILE}"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    -vv | --very-verbose)
      VERY_VERBOSE=true
      VERBOSE=true
      shift
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done
  trap ':' EXIT
  setup_colors
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    touch "$LOG_FILE" 2>/dev/null || true
  }
  audit_os_info
  audit_security_updates
  audit_unattended_upgrades
  audit_time_sync
  audit_world_writable
  audit_logrotate
  audit_filesystem_hardening
  audit_kernel_security
  print_summary
  exit "$EXIT_CODE"
}
main "$@"
