#!/usr/bin/env bash
#
# Service Basics Audit
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
# - NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
# - OWASP ASVS: V2, V4, V7, V10
# - UK NCSC: Logging and Monitoring, Secure Configuration, Identity and Access Management
# - PCI DSS: 2.2, 7.1, 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Service basics audit - check common system services (PERFORMANCE OPTIMIZED)
#
# @elevation: partial
# @elevation-reason: systemctl and service status may need root for full details
#
set -euo pipefail

# shellcheck source=../../../lib/common.sh
. "$(dirname "$0")/../../../../lib/common.sh"
# shellcheck source=../../../lib/distro.sh
. "$(dirname "$0")/../../../../lib/distro.sh"
# shellcheck source=../../../lib/svc.sh
. "$(dirname "$0")/../../../../lib/svc.sh"

section "Common System Services"

# OPTIMIZATION: Cache systemctl output to avoid multiple calls
SYSTEMD_UNIT_FILES=""
if is_systemd; then
  SYSTEMD_UNIT_FILES=$(systemctl list-unit-files 2>/dev/null || echo "")
fi

# Check cron/crond (job scheduler)
cron_service=""
if is_systemd; then
  # systemd distros use different names - check cached output
  for name in cron crond; do
    if echo "$SYSTEMD_UNIT_FILES" | grep -q "^${name}.service"; then
      cron_service="$name"
      break
    fi
  done
else
  # OpenRC typically uses crond
  cron_service="crond"
fi

if [[ -n "$cron_service" ]]; then
  if svc_is_active "$cron_service"; then
    register_check "Cron service ($cron_service)" PASS "running"
  else
    register_check "Cron service ($cron_service)" WARN "not running"
  fi

  if svc_is_enabled "$cron_service"; then
    register_check "Cron auto-start ($cron_service)" PASS "enabled"
  else
    register_check "Cron auto-start ($cron_service)" WARN "not enabled"
  fi
else
  register_check "Cron service" SKIP "Not applicable (cron not installed)"
fi

# Check SSH service
ssh_service=""
if is_systemd; then
  # Check cached unit files
  for name in ssh sshd; do
    if echo "$SYSTEMD_UNIT_FILES" | grep -q "^${name}.service"; then
      ssh_service="$name"
      break
    fi
  done
else
  ssh_service="sshd"
fi

if [[ -n "$ssh_service" ]]; then
  if svc_is_active "$ssh_service"; then
    register_check "SSH service ($ssh_service)" PASS "running"
  else
    register_check "SSH service ($ssh_service)" WARN "not running"
  fi

  if svc_is_enabled "$ssh_service"; then
    register_check "SSH auto-start ($ssh_service)" PASS "enabled"
  else
    register_check "SSH auto-start ($ssh_service)" WARN "not enabled"
  fi
else
  register_check "SSH service" SKIP "Not applicable (ssh not installed)"
fi

# Check logging service
log_service=""
if is_systemd; then
  # Modern systemd uses journald - check cached output
  if echo "$SYSTEMD_UNIT_FILES" | grep -q "^systemd-journald.service"; then
    log_service="systemd-journald"
  fi
elif is_openrc; then
  # OpenRC typically uses syslog-ng or rsyslog
  for name in syslog-ng rsyslog sysklogd; do
    if rc-service --exists "$name" 2>/dev/null; then
      log_service="$name"
      break
    fi
  done
fi

if [[ -n "$log_service" ]]; then
  if svc_is_active "$log_service"; then
    register_check "Logging service ($log_service)" PASS "running"
  else
    register_check "Logging service ($log_service)" FAIL "not running (critical)"
  fi
else
  register_check "Logging service" WARN "could not detect logging daemon"
fi

print_summary
exit "$EXIT_CODE"
