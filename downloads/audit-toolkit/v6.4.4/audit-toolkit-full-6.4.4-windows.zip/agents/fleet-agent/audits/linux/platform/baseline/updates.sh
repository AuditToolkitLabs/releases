#!/usr/bin/env bash
#
# OS Package Updates Audit
#
# @elevation: root
# @elevation-reason: Package manager operations require root for cache refresh
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 16.11
# - NIST SP 800-53: SI-2, SI-3, SI-4
# - ISO 27001: A.12.6, A.14.2
# - OWASP ASVS: V10
# - UK NCSC: Secure Configuration, Patch Management
# - PCI DSS: 6.2, 10.2
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Cross-distro OS updates audit
set -euo pipefail

# shellcheck source=../../../lib/common.sh
. "$(dirname "$0")/../../../../lib/common.sh"
# shellcheck source=../../../lib/distro.sh
. "$(dirname "$0")/../../../../lib/distro.sh"
# shellcheck source=../../../lib/pkg.sh
. "$(dirname "$0")/../../../../lib/pkg.sh"

section "OS Package Updates"

if ! pkg_refresh; then
  register_check "package index refresh" WARN "failed"
else
  register_check "package index refresh" PASS "ok"
fi

updates="$(pkg_list_upgrades || true)"
if [[ -n "$updates" ]]; then
  n="$(printf "%s
" "$updates" | wc -l | tr -d ' ')"
  register_check "upgradable packages" WARN "$n pending"
  while IFS= read -r l; do _log DEBUG " $l"; done <<<"$updates"
else
  register_check "upgradable packages" PASS "none"
fi

print_summary
exit "$EXIT_CODE"
