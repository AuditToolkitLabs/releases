# Debian-Specific Audits

This folder contains audits specific to Debian Linux distributions.

## Implemented Audits

| Script | Description | Status |
|--------|-------------|--------|
| `debian-specific-audit.sh` | Comprehensive Debian security audit | ✅ Complete |

### Checks Included

- Debian version and release tracking
- APT security sources validation
- debsecan integration (if available)
- unattended-upgrades configuration
- Repository GPG key verification
- Security update status

## Debian-Specific Paths

- `/etc/apt/sources.list` - Main repository sources
- `/etc/apt/sources.list.d/` - Additional sources
- `/etc/apt/apt.conf.d/` - APT configuration
- `/var/lib/apt/` - APT state
- `/var/log/apt/` - APT logs

## Supported Versions

- Debian 10 (Buster) - oldoldstable
- Debian 11 (Bullseye) - oldstable
- Debian 12 (Bookworm) - stable

## Usage

```bash
bash audits/linux/platform/debian/<script>.sh
```
