#!/usr/bin/env bash
# debian-specific-audit.sh — Debian-Specific Security Audit
#
# Compliance Mapping:
# - CIS Debian Linux Benchmark
# - Debian Security Tracker
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - Debsecan vulnerability scanner
# - Needrestart service checks
# - apt-listbugs
# - Security repository verification
# - Debian-specific hardening
#
# @elevation: partial
# @elevation-reason: debsecan and apt config checks may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/distro.sh
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on Debian
distro=$(detect_distro)
if [[ "$distro" != "debian" ]]; then
  register_check "Debian detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Debian Distribution Info"

# Get Debian version
debian_version=$(cat /etc/debian_version 2>/dev/null || echo "unknown")
register_check "Debian version" PASS "$debian_version"

# Get codename
debian_codename=$(grep -oP 'VERSION_CODENAME=\K.*' /etc/os-release 2>/dev/null || echo "unknown")
register_check "Codename" PASS "$debian_codename"

# Check if stable/testing/unstable
case "$debian_codename" in
  bookworm | bullseye | buster | stretch)
    register_check "Release type" PASS "stable"
    ;;
  trixie)
    register_check "Release type" WARN "testing"
    ;;
  sid)
    register_check "Release type" WARN "unstable"
    ;;
  *)
    register_check "Release type" PASS "$debian_codename"
    ;;
esac

section "Debsecan Vulnerability Scanner"

# Check debsecan
if command -v debsecan >/dev/null 2>&1; then
  register_check "Debsecan installed" PASS "yes"

  # Run debsecan
  debsecan_output=$(debsecan --suite "$debian_codename" 2>/dev/null || echo "")

  if [[ -n "$debsecan_output" ]]; then
    vuln_count=$(echo "$debsecan_output" | wc -l)

    # Count by severity
    high_vulns=$(echo "$debsecan_output" | grep -cE "high urgency|remotely exploitable" || echo "0")
    medium_vulns=$(echo "$debsecan_output" | grep -cE "medium urgency" || echo "0")
    low_vulns=$(echo "$debsecan_output" | grep -cE "low urgency|unimportant" || echo "0")

    if [[ "$high_vulns" -gt 0 ]]; then
      register_check "High severity CVEs" FAIL "$high_vulns"
    else
      register_check "High severity CVEs" PASS "0"
    fi

    if [[ "$medium_vulns" -gt 0 ]]; then
      register_check "Medium severity CVEs" WARN "$medium_vulns"
    else
      register_check "Medium severity CVEs" PASS "0"
    fi

    register_check "Low severity CVEs" PASS "$low_vulns"
    register_check "Total known CVEs" PASS "$vuln_count"
  else
    register_check "Debsecan scan" PASS "no vulnerabilities found"
  fi

  # Check if debsecan is in cron
  if [[ -f /etc/cron.daily/debsecan ]] || [[ -f /etc/cron.d/debsecan ]]; then
    register_check "Debsecan cron" PASS "scheduled"
  else
    register_check "Debsecan cron" WARN "not scheduled"
  fi
else
  register_check "Debsecan installed" WARN "not installed"
fi

section "Needrestart Service Checker"

# Check needrestart
if command -v needrestart >/dev/null 2>&1; then
  register_check "Needrestart installed" PASS "yes"

  # Run needrestart in batch mode
  needrestart_output=$(needrestart -b 2>/dev/null || echo "")

  if [[ -n "$needrestart_output" ]]; then
    # Check for kernel restart needed
    if echo "$needrestart_output" | grep -qE "NEEDRESTART-KSTA:\s*[23]"; then
      register_check "Kernel restart" WARN "needed"
    else
      register_check "Kernel restart" PASS "not needed"
    fi

    # Check for services needing restart
    services_restart=$(echo "$needrestart_output" | grep -c "NEEDRESTART-SVC:" || echo "0")
    if [[ "$services_restart" -gt 0 ]]; then
      register_check "Services need restart" WARN "$services_restart"
    else
      register_check "Services need restart" PASS "none"
    fi

    # Check for session restart needed
    if echo "$needrestart_output" | grep -qE "NEEDRESTART-SESS:"; then
      sessions_restart=$(echo "$needrestart_output" | grep -c "NEEDRESTART-SESS:" || echo "0")
      register_check "Sessions need restart" WARN "$sessions_restart"
    fi
  fi

  # Check needrestart configuration
  needrestart_conf="/etc/needrestart/needrestart.conf"
  if [[ -f "$needrestart_conf" ]]; then
    # Check restart mode
    if grep -qE "^\\\$nrconf\{restart\}[[:space:]]*=[[:space:]]*'a'" "$needrestart_conf"; then
      register_check "Needrestart auto mode" PASS "automatic"
    elif grep -qE "^\\\$nrconf\{restart\}[[:space:]]*=[[:space:]]*'i'" "$needrestart_conf"; then
      register_check "Needrestart auto mode" PASS "interactive"
    else
      register_check "Needrestart auto mode" WARN "manual/unknown"
    fi
  fi
else
  register_check "Needrestart installed" WARN "not installed"
fi

section "Apt-Listbugs"

# Check apt-listbugs
if command -v apt-listbugs >/dev/null 2>&1; then
  register_check "Apt-listbugs installed" PASS "yes"

  # Check configuration
  listbugs_conf="/etc/apt/apt.conf.d/10apt-listbugs"
  if [[ -f "$listbugs_conf" ]]; then
    register_check "Apt-listbugs config" PASS "configured"
  fi
else
  register_check "Apt-listbugs installed" WARN "not installed"
fi

section "Security Repository"

# Check apt sources for security
sources_list="/etc/apt/sources.list"
sources_d="/etc/apt/sources.list.d"

security_found=false

# Check main sources.list
if [[ -f "$sources_list" ]]; then
  if grep -qE "security\.debian\.org|debian-security" "$sources_list" 2>/dev/null; then
    security_found=true
  fi
fi

# Check sources.list.d
if [[ -d "$sources_d" ]]; then
  if grep -rlE "security\.debian\.org|debian-security" "$sources_d" >/dev/null 2>&1; then
    security_found=true
  fi
fi

if $security_found; then
  register_check "Security repository" PASS "configured"
else
  register_check "Security repository" FAIL "not found"
fi

# Check for updates repo
if grep -qE "debian.*-updates" "$sources_list" 2>/dev/null; then
  register_check "Updates repository" PASS "configured"
else
  register_check "Updates repository" WARN "not found"
fi

# Check for backports (might be security consideration)
if grep -qE "debian.*-backports" "$sources_list" 2>/dev/null; then
  register_check "Backports repository" WARN "enabled"
fi

section "Automatic Updates"

# Check unattended-upgrades
if dpkg -l unattended-upgrades 2>/dev/null | grep -q '^ii'; then
  register_check "Unattended-upgrades" PASS "installed"

  auto_conf="/etc/apt/apt.conf.d/20auto-upgrades"
  if [[ -f "$auto_conf" ]]; then
    if grep -qE 'APT::Periodic::Unattended-Upgrade\s+"1"' "$auto_conf"; then
      register_check "Auto upgrades enabled" PASS "yes"
    else
      register_check "Auto upgrades enabled" WARN "disabled"
    fi
  fi

  # Check allowed origins
  origins_conf="/etc/apt/apt.conf.d/50unattended-upgrades"
  if [[ -f "$origins_conf" ]]; then
    if grep -qE "\"\\\${distro_id}:.*-security\"" "$origins_conf"; then
      register_check "Security origin" PASS "enabled"
    fi
  fi
else
  register_check "Unattended-upgrades" WARN "not installed"
fi

# Check apt-daily timer
if systemctl is-active apt-daily.timer >/dev/null 2>&1; then
  register_check "Apt-daily timer" PASS "active"
else
  register_check "Apt-daily timer" WARN "not active"
fi

if systemctl is-active apt-daily-upgrade.timer >/dev/null 2>&1; then
  register_check "Apt-daily-upgrade timer" PASS "active"
else
  register_check "Apt-daily-upgrade timer" WARN "not active"
fi

section "Debian Security Features"

# Check AppArmor
if command -v aa-status >/dev/null 2>&1; then
  register_check "AppArmor installed" PASS "yes"

  if aa-enabled 2>/dev/null; then
    register_check "AppArmor enabled" PASS "yes"
  else
    register_check "AppArmor enabled" WARN "no"
  fi
else
  register_check "AppArmor installed" WARN "not installed"
fi

# Check UFW or nftables
if command -v ufw >/dev/null 2>&1; then
  ufw_status=$(ufw status 2>/dev/null | grep -oP "Status:\s*\K\S+" || echo "unknown")
  if [[ "$ufw_status" == "active" ]]; then
    register_check "UFW firewall" PASS "active"
  else
    register_check "UFW firewall" WARN "inactive"
  fi
elif command -v nft >/dev/null 2>&1; then
  register_check "nftables" PASS "installed"
fi

# Check fail2ban
if systemctl is-active fail2ban >/dev/null 2>&1; then
  register_check "Fail2ban" PASS "active"
elif dpkg -l fail2ban 2>/dev/null | grep -q '^ii'; then
  register_check "Fail2ban" WARN "installed but not running"
fi

# Check AIDE
if dpkg -l aide 2>/dev/null | grep -q '^ii'; then
  register_check "AIDE" PASS "installed"

  if [[ -f /var/lib/aide/aide.db ]]; then
    register_check "AIDE database" PASS "initialized"
  else
    register_check "AIDE database" WARN "not initialized"
  fi
fi

section "Debian Hardening Packages"

# Check for common hardening packages
hardening_packages=(
  "libpam-tmpdir"
  "libpam-umask"
  "apt-listchanges"
  "debsums"
  "checksecurity"
)

for pkg in "${hardening_packages[@]}"; do
  if dpkg -l "$pkg" 2>/dev/null | grep -q '^ii'; then
    register_check "$pkg" PASS "installed"
  fi
done

# Check debsums integrity
if command -v debsums >/dev/null 2>&1; then
  # Quick check for modified config files
  changed_files=$(debsums -c 2>/dev/null | wc -l || echo "0")
  if [[ "$changed_files" -eq 0 ]]; then
    register_check "Debsums integrity" PASS "no changes"
  else
    register_check "Debsums integrity" WARN "$changed_files changed"
  fi
fi

section "Pending Updates"

# Check for pending updates
pending_all=$(apt list --upgradable 2>/dev/null | tail -n +2 | wc -l || echo "0")
if [[ "$pending_all" -gt 0 ]]; then
  register_check "Pending updates" WARN "$pending_all packages"
else
  register_check "Pending updates" PASS "none"
fi

# Check for security updates specifically
pending_security=$(apt list --upgradable 2>/dev/null | grep -ciE "security" || echo "0")
if [[ "$pending_security" -gt 0 ]]; then
  register_check "Pending security updates" WARN "$pending_security"
else
  register_check "Pending security updates" PASS "none"
fi

# Check reboot required
if [[ -f /var/run/reboot-required ]]; then
  register_check "Reboot required" WARN "yes"
else
  register_check "Reboot required" PASS "no"
fi

print_summary
exit "$EXIT_CODE"
