# Devuan Linux Audit Scripts

This directory contains Devuan-specific security audits that leverage Devuan's
unique characteristics as a systemd-free Debian fork using traditional SysVinit.

## Scripts

| Script | Description | CIS Reference |
|--------|-------------|---------------|
| `devuan-specific-audit.sh` | Core Devuan hardening checks | CIS Debian |

## Devuan-Specific Considerations

### Init System

Devuan uses **SysVinit** by default, maintaining traditional Unix-style
service management. The audits verify SysVinit configuration and reject
systemd dependencies.

Supported init alternatives:
- **SysVinit** (default)
- **OpenRC** (optional)
- **runit** (optional)

### Package Management

Devuan uses **APT** with Devuan-specific repositories that filter out
systemd packages. Key security features:
- APT secure transport (HTTPS)
- Repository signature verification
- amprolla (Devuan's repo merging tool) verification

### Systemd-Free Philosophy

Devuan's core principle is freedom from systemd. The audit verifies:
- No systemd binaries installed
- No systemd-related services running
- Pure init alternative configuration

## Running Audits

```bash
# Run Devuan-specific audit
sudo bash audits/linux/platform/devuan/devuan-specific-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --match devuan
```

## References

- [Devuan Documentation](https://www.devuan.org/os/documentation)
- [Devuan Package Search](https://pkginfo.devuan.org/)
- [Init Freedom Campaign](https://www.devuan.org/os/init-freedom)
- [CIS Debian Benchmark](https://www.cisecurity.org/benchmark/debian_linux)
