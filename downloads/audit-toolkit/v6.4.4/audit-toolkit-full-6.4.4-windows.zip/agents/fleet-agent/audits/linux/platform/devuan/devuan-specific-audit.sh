#!/usr/bin/env bash
# devuan-specific-audit.sh — Devuan Linux-Specific Security Audit
#
# @elevation: root
# @elevation-reason: Some system checks require root access
#
# Compliance Mapping:
# - Devuan Best Practices
# - Debian Security Guide (with sysvinit adaptations)
# - NIST SP 800-53: CM-6 (Configuration Settings), SI-2 (Flaw Remediation)
# - CIS Debian/Ubuntu Benchmark (adapted for sysvinit)
#
# Checks:
# - Devuan distribution verification
# - SysVinit configuration and runlevels
# - APT repository security
# - Init freedom verification (no systemd)
# - Eudev vs. udev configuration
# - Critical service hardening (sysvinit)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../../lib/pkg.sh"

setup_colors

# Verify we're on Devuan
distro=$(detect_distro)
if [[ "$distro" != "devuan" ]]; then
  register_check "Devuan detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Devuan Distribution Info"

# Get Devuan version
if [[ -f /etc/devuan_version ]]; then
  devuan_version=$(cat /etc/devuan_version)
  register_check "Devuan version" PASS "$devuan_version"
else
  register_check "Devuan version" WARN "/etc/devuan_version not found"

  # Fallback to os-release
  if [[ -f /etc/os-release ]]; then
    devuan_version=$(grep "VERSION_ID" /etc/os-release | cut -d'"' -f2 || echo "unknown")
    devuan_codename=$(grep "VERSION_CODENAME" /etc/os-release | cut -d'=' -f2 || echo "unknown")
    register_check "Devuan version (os-release)" PASS "$devuan_version ($devuan_codename)"
  fi
fi

# Check architecture
arch=$(uname -m)
register_check "Architecture" PASS "$arch"

section "Init Freedom Verification"

# Verify no systemd
if command -v systemctl >/dev/null 2>&1; then
  # Check if it's a shim or real systemd
  if systemctl --version 2>/dev/null | grep -qi "systemd"; then
    register_check "systemd installed" FAIL "systemd detected on Devuan"
  else
    register_check "systemctl shim" PASS "compatibility shim only"
  fi
else
  register_check "systemd-free" PASS "no systemctl found"
fi

# Verify sysvinit
if [[ -f /sbin/init ]]; then
  init_type=$(file /sbin/init 2>/dev/null || readlink -f /sbin/init)
  if echo "$init_type" | grep -qi "sysvinit\|System V"; then
    register_check "SysVinit" PASS "detected"
  elif [[ -x /sbin/init ]]; then
    init_pid1=$(/sbin/init --version 2>&1 | head -1 || echo "unknown")
    register_check "Init system" PASS "$init_pid1"
  fi
fi

# Check PID 1
pid1_name=$(cat /proc/1/comm 2>/dev/null || echo "unknown")
register_check "PID 1" PASS "$pid1_name"

section "SysVinit Configuration"

# Check default runlevel
if [[ -f /etc/inittab ]]; then
  register_check "/etc/inittab exists" PASS "yes"

  # Get default runlevel
  default_rl=$(grep "^id:" /etc/inittab 2>/dev/null | cut -d':' -f2 || echo "unknown")
  if [[ -n "$default_rl" && "$default_rl" != "unknown" ]]; then
    register_check "Default runlevel" PASS "$default_rl"

    # Runlevel 2-4 are multi-user, 5 is graphical
    case "$default_rl" in
      2|3|4) register_check "Runlevel type" PASS "multi-user" ;;
      5) register_check "Runlevel type" WARN "graphical (consider multi-user for servers)" ;;
      1|S|s) register_check "Runlevel type" WARN "single-user/rescue" ;;
      *) register_check "Runlevel type" WARN "non-standard: $default_rl" ;;
    esac
  fi

  # Check for ctrlaltdel action
  ctrlaltdel=$(grep "ctrlaltdel" /etc/inittab 2>/dev/null || echo "")
  if [[ -n "$ctrlaltdel" ]]; then
    if echo "$ctrlaltdel" | grep -q "shutdown"; then
      register_check "Ctrl-Alt-Del" WARN "reboots system"
    else
      register_check "Ctrl-Alt-Del" PASS "disabled or custom"
    fi
  fi
else
  register_check "/etc/inittab exists" WARN "not found"
fi

# Check current runlevel
current_rl=$(runlevel 2>/dev/null | awk '{print $2}' || echo "unknown")
if [[ "$current_rl" != "unknown" ]]; then
  register_check "Current runlevel" PASS "$current_rl"
fi

section "Init Scripts Security"

# Check /etc/init.d permissions
if [[ -d /etc/init.d ]]; then
  init_scripts=$(find /etc/init.d -type f -executable 2>/dev/null | wc -l)
  register_check "Init scripts" PASS "$init_scripts scripts"

  # Check for world-writable scripts
  world_writable=$(find /etc/init.d -type f -perm -002 2>/dev/null | wc -l)
  if [[ "$world_writable" -eq 0 ]]; then
    register_check "World-writable init scripts" PASS "none"
  else
    register_check "World-writable init scripts" FAIL "$world_writable scripts"
  fi

  # Check ownership
  non_root=$(find /etc/init.d -type f ! -user root 2>/dev/null | wc -l)
  if [[ "$non_root" -eq 0 ]]; then
    register_check "Init scripts ownership" PASS "all root-owned"
  else
    register_check "Init scripts ownership" FAIL "$non_root not root-owned"
  fi
fi

# Check runlevel directories
for rl in 0 1 2 3 4 5 6 S; do
  rl_dir="/etc/rc${rl}.d"
  if [[ -d "$rl_dir" ]]; then
    link_count=$(find "$rl_dir" -type l 2>/dev/null | wc -l)
    if [[ "$link_count" -gt 0 ]]; then
      # Just verify rc directories exist, don't list all
      :
    fi
  fi
done
register_check "Runlevel directories" PASS "present"

section "Critical Services (SysVinit)"

# Check critical services are configured
critical_services="ssh sshd cron rsyslog syslog-ng auditd iptables"

for svc in $critical_services; do
  script="/etc/init.d/$svc"
  if [[ -x "$script" ]]; then
    # Check if enabled in current runlevel
    enabled=false
    for rc_dir in /etc/rc2.d /etc/rc3.d /etc/rc5.d; do
      if ls "$rc_dir"/S*"$svc" >/dev/null 2>&1; then
        enabled=true
        break
      fi
    done

    if $enabled; then
      register_check "Service: $svc" PASS "enabled"
    else
      register_check "Service: $svc" WARN "installed but not enabled"
    fi
  fi
done

section "APT Repository Security"

# Check APT sources
sources_list="/etc/apt/sources.list"
if [[ -f "$sources_list" ]]; then
  register_check "sources.list exists" PASS "$sources_list"

  # Check for HTTPS usage
  https_count=$(grep -c "^deb https://" "$sources_list" 2>/dev/null || echo "0")
  http_count=$(grep -c "^deb http://" "$sources_list" 2>/dev/null || echo "0")

  if [[ "$http_count" -eq 0 && "$https_count" -gt 0 ]]; then
    register_check "APT HTTPS" PASS "all repos use HTTPS"
  elif [[ "$https_count" -gt 0 ]]; then
    register_check "APT HTTPS" WARN "$http_count HTTP, $https_count HTTPS"
  else
    register_check "APT HTTPS" WARN "no HTTPS repositories"
  fi

  # Check for Devuan mirrors
  if grep -q "devuan" "$sources_list" 2>/dev/null; then
    register_check "Devuan repos" PASS "configured"
  else
    register_check "Devuan repos" WARN "no explicit Devuan repos found"
  fi
fi

# Check for additional sources
sources_d="/etc/apt/sources.list.d"
if [[ -d "$sources_d" ]]; then
  extra_sources=$(find "$sources_d" -name "*.list" 2>/dev/null | wc -l)
  if [[ "$extra_sources" -gt 0 ]]; then
    register_check "Additional APT sources" WARN "$extra_sources extra source files"
  else
    register_check "Additional APT sources" PASS "none"
  fi
fi

section "APT Security Configuration"

# Check APT configuration
apt_conf="/etc/apt/apt.conf.d"
if [[ -d "$apt_conf" ]]; then
  # Check for security updates configuration
  auto_upgrades=$(find "$apt_conf" -name "*auto-upgrades*" -o -name "*unattended*" 2>/dev/null | head -1)
  if [[ -n "$auto_upgrades" ]]; then
    register_check "Automatic updates" PASS "configured"
  else
    register_check "Automatic updates" WARN "not configured"
  fi
fi

# Check pending security updates
if command -v apt-get >/dev/null 2>&1; then
  pkg_refresh 2>/dev/null || true

  upgradable=$(apt list --upgradable 2>/dev/null | grep -c "security" || echo "0")
  if [[ "$upgradable" -eq 0 ]]; then
    register_check "Security updates pending" PASS "none"
  else
    register_check "Security updates pending" WARN "$upgradable packages"
  fi
fi

section "Eudev / Device Management"

# Devuan uses eudev instead of systemd-udev
if command -v udevadm >/dev/null 2>&1; then
  udev_version=$(udevadm --version 2>/dev/null || echo "unknown")

  # Check if it's eudev
  if command -v eudevd >/dev/null 2>&1 || [[ -f /lib/udev/eudevd ]]; then
    register_check "Device manager" PASS "eudev ($udev_version)"
  else
    register_check "Device manager" PASS "udev ($udev_version)"
  fi
fi

# Check udev rules directory
if [[ -d /etc/udev/rules.d ]]; then
  rule_count=$(find /etc/udev/rules.d -name "*.rules" 2>/dev/null | wc -l)
  register_check "Custom udev rules" PASS "$rule_count rules"
fi

section "Package Integrity"

# Check for debsums
if command -v debsums >/dev/null 2>&1; then
  register_check "debsums installed" PASS "yes"

  # Quick integrity check (sampled)
  if [[ $EUID -eq 0 ]]; then
    changed=$(debsums -c 2>/dev/null | head -10 | wc -l || echo "unknown")
    if [[ "$changed" == "0" ]]; then
      register_check "Package file integrity" PASS "no changes detected"
    elif [[ "$changed" != "unknown" ]]; then
      register_check "Package file integrity" WARN "$changed+ files changed"
    fi
  else
    register_check "Package file integrity" SKIP "requires root"
  fi
else
  register_check "debsums installed" WARN "not installed (apt install debsums)"
fi

section "Network Services (inetd)"

# Check for inetd (legacy, should generally not be used)
if [[ -f /etc/inetd.conf ]]; then
  active_services=$(grep -v "^#" /etc/inetd.conf 2>/dev/null | grep -v "^$" | wc -l)
  if [[ "$active_services" -eq 0 ]]; then
    register_check "inetd services" PASS "none active"
  else
    register_check "inetd services" WARN "$active_services active services"
  fi
else
  register_check "inetd" PASS "not present"
fi

# Check for xinetd
if [[ -d /etc/xinetd.d ]]; then
  xinetd_services=$(find /etc/xinetd.d -type f 2>/dev/null | wc -l)
  if [[ "$xinetd_services" -gt 0 ]]; then
    enabled=$(grep -r "disable.*=.*no" /etc/xinetd.d 2>/dev/null | wc -l || echo "0")
    register_check "xinetd services" WARN "$enabled enabled services"
  fi
else
  register_check "xinetd" PASS "not present"
fi

section "Logging Configuration"

# Check syslog configuration (rsyslog or syslog-ng)
if [[ -f /etc/rsyslog.conf ]]; then
  register_check "Logging daemon" PASS "rsyslog"

  # Check for remote logging
  remote_log=$(grep -E "^[^#]*@@?[a-zA-Z0-9]" /etc/rsyslog.conf 2>/dev/null || echo "")
  if [[ -n "$remote_log" ]]; then
    register_check "Remote logging" PASS "configured"
  else
    register_check "Remote logging" WARN "not configured"
  fi
elif [[ -f /etc/syslog-ng/syslog-ng.conf ]]; then
  register_check "Logging daemon" PASS "syslog-ng"
elif [[ -f /etc/syslog.conf ]]; then
  register_check "Logging daemon" PASS "traditional syslog"
else
  register_check "Logging daemon" WARN "no syslog config found"
fi

# Check log directory permissions
if [[ -d /var/log ]]; then
  log_perms=$(stat -c "%a" /var/log 2>/dev/null || echo "unknown")
  case "$log_perms" in
    755|750|700) register_check "/var/log permissions" PASS "$log_perms" ;;
    *) register_check "/var/log permissions" WARN "$log_perms (should be 755 or more restrictive)" ;;
  esac
fi

print_summary
exit "$EXIT_CODE"
