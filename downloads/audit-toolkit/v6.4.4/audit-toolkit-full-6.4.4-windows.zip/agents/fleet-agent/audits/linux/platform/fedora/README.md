# Fedora-Specific Audits

This folder contains security audit scripts specifically designed for Fedora Linux.

## Included Audits

### fedora-specific-audit.sh

Comprehensive Fedora-specific security checks including:

- **Distribution Info**: Version, variant (Workstation/Server/CoreOS), immutability detection
- **DNF Package Manager**: DNF5 support, GPG verification, automatic updates
- **Flatpak Security**: Sandbox configuration, remote filtering, outdated packages
- **SELinux**: Enforcement status (Fedora default)
- **Secure Boot**: UEFI/MOK status
- **Firewalld**: Zone configuration and exposed services
- **BTRFS Snapshots**: Snapper/Timeshift integration
- **Kernel Lockdown**: Integrity/confidentiality mode

## Usage

```bash
# Run directly
bash audits/linux/platform/fedora/fedora-specific-audit.sh

# Via orchestrator
./orchestrator/orchestrator.sh --path audits/linux/platform/fedora/fedora-specific-audit.sh

# With all platform audits
./orchestrator/orchestrator.sh --domain platform
```

## Fedora Versions Supported

- Fedora 38+
- Fedora Workstation
- Fedora Server
- Fedora Silverblue/Kinoite (immutable)
- Fedora CoreOS

## Compliance Mapping

| Check | NIST SP 800-53 | Notes |
|-------|----------------|-------|
| DNF GPG verification | CM-6 | Package integrity |
| SELinux enforcing | AC-3, AC-6 | Mandatory access control |
| Automatic updates | SI-2 | Flaw remediation |
| Firewalld active | SC-7 | Boundary protection |
| Secure Boot | SI-7 | Boot integrity |

## Notes

- This script automatically SKIPs on non-Fedora systems
- Flatpak checks only run if Flatpak is installed
- BTRFS snapshot checks only apply to BTRFS root filesystems
- rpm-ostree checks apply to Silverblue/Kinoite variants
