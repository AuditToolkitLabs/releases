#!/usr/bin/env bash
# fedora-specific-audit.sh — Fedora Linux-Specific Security Audit
#
# Compliance Mapping:
# - Fedora Security Advisory (FEDORA-SA)
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - DNF/DNF5 configuration
# - Flatpak sandboxing
# - Fedora variant detection (Workstation/Server/CoreOS)
# - BTRFS snapshot configuration
# - Secure Boot status
# - Silverblue/Kinoite immutability (if applicable)
#
# @elevation: partial
# @elevation-reason: DNF config and Secure Boot checks may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on Fedora
distro=$(detect_distro)
if [[ "$distro" != "fedora" ]]; then
  register_check "Fedora detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Fedora Distribution Info"

# Get Fedora version
fedora_version=$(grep -oP 'VERSION_ID=\K[0-9]+' /etc/os-release 2>/dev/null || echo "unknown")
register_check "Fedora version" PASS "$fedora_version"

# Detect Fedora variant
fedora_variant=$(grep -oP 'VARIANT_ID=\K\w+' /etc/os-release 2>/dev/null || echo "workstation")
register_check "Fedora variant" PASS "$fedora_variant"

# Check if immutable (Silverblue/Kinoite)
if command -v rpm-ostree >/dev/null 2>&1; then
  register_check "Immutable system" PASS "rpm-ostree based"

  # Check pending updates
  pending=$(rpm-ostree status 2>/dev/null | grep -c "pending" || echo "0")
  if [[ "$pending" -gt 0 ]]; then
    register_check "Pending rpm-ostree updates" WARN "reboot required"
  else
    register_check "Pending rpm-ostree updates" PASS "none"
  fi
else
  register_check "Immutable system" PASS "traditional (mutable)"
fi

# Check architecture
arch=$(uname -m)
register_check "Architecture" PASS "$arch"

section "DNF Package Manager"

# Check DNF version (DNF5 in Fedora 39+)
if command -v dnf5 >/dev/null 2>&1; then
  dnf_version=$(dnf5 --version 2>/dev/null | head -1 || echo "unknown")
  register_check "DNF5 installed" PASS "$dnf_version"
elif command -v dnf >/dev/null 2>&1; then
  dnf_version=$(dnf --version 2>/dev/null | head -1 || echo "unknown")
  register_check "DNF installed" PASS "$dnf_version"
else
  register_check "DNF installed" FAIL "not found"
fi

# Check GPG key verification
if [[ -f /etc/dnf/dnf.conf ]]; then
  gpgcheck=$(grep -E "^gpgcheck\s*=" /etc/dnf/dnf.conf 2>/dev/null | tail -1 | cut -d= -f2 | tr -d ' ' || true)
  if [[ "$gpgcheck" == "1" ]] || [[ -z "$gpgcheck" ]]; then
    register_check "DNF GPG check" PASS "enabled"
  else
    register_check "DNF GPG check" FAIL "disabled"
  fi

  # Check skip_if_unavailable
  skip_unavail=$(grep -E "^skip_if_unavailable\s*=" /etc/dnf/dnf.conf 2>/dev/null | tail -1 | cut -d= -f2 | tr -d ' ' || true)
  if [[ "$skip_unavail" == "True" ]]; then
    register_check "DNF skip_if_unavailable" WARN "True (may skip security updates)"
  else
    register_check "DNF skip_if_unavailable" PASS "False"
  fi
fi

# Check automatic updates (dnf-automatic)
if systemctl is-enabled dnf-automatic.timer >/dev/null 2>&1; then
  register_check "DNF automatic updates" PASS "enabled"
else
  register_check "DNF automatic updates" WARN "not enabled"
fi

# Check pending updates (with timeout for offline/container environments)
if command -v timeout >/dev/null 2>&1; then
  pending_updates=$(timeout 10 dnf check-update --quiet 2>/dev/null | grep -c "^\S" || true)
else
  pending_updates=$(dnf check-update --quiet 2>/dev/null | grep -c "^\S" || true)
fi
: "${pending_updates:=0}"
if [[ "$pending_updates" -eq 0 ]]; then
  register_check "Pending updates" PASS "system up to date"
elif [[ "$pending_updates" -lt 10 ]]; then
  register_check "Pending updates" WARN "$pending_updates available"
else
  register_check "Pending updates" FAIL "$pending_updates available"
fi

section "Flatpak Security"

# Check Flatpak
if command -v flatpak >/dev/null 2>&1; then
  register_check "Flatpak installed" PASS "yes"

  flatpak_version=$(flatpak --version 2>/dev/null | awk '{print $2}' || echo "unknown")
  register_check "Flatpak version" PASS "$flatpak_version"

  # Check configured remotes
  remotes=$(flatpak remotes 2>/dev/null | wc -l || echo "0")
  register_check "Flatpak remotes" PASS "$remotes configured"

  # Check if Flathub is configured
  if flatpak remotes 2>/dev/null | grep -q "flathub"; then
    # Check if filtered
    if flatpak remotes -d 2>/dev/null | grep "flathub" | grep -q "filter"; then
      register_check "Flathub filtering" PASS "enabled"
    else
      register_check "Flathub filtering" WARN "not filtered"
    fi
  fi

  # Count installed Flatpaks
  flatpak_count=$(flatpak list 2>/dev/null | wc -l || echo "0")
  register_check "Installed Flatpaks" PASS "$flatpak_count"

  # Check for outdated Flatpaks (with timeout for offline environments)
  if command -v timeout >/dev/null 2>&1; then
    outdated=$(timeout 10 flatpak remote-ls --updates 2>/dev/null | wc -l || echo "0")
  else
    outdated=$(flatpak remote-ls --updates 2>/dev/null | wc -l || echo "0")
  fi
  if [[ "$outdated" -eq 0 ]]; then
    register_check "Flatpak updates" PASS "all current"
  else
    register_check "Flatpak updates" WARN "$outdated pending"
  fi
else
  register_check "Flatpak installed" SKIP "not installed"
fi

section "SELinux Status"

# Check SELinux (Fedora uses SELinux by default)
if command -v getenforce >/dev/null 2>&1; then
  selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
  case "$selinux_mode" in
    Enforcing)
      register_check "SELinux mode" PASS "enforcing"
      ;;
    Permissive)
      register_check "SELinux mode" WARN "permissive"
      ;;
    Disabled)
      register_check "SELinux mode" FAIL "disabled"
      ;;
    *)
      register_check "SELinux mode" WARN "$selinux_mode"
      ;;
  esac
else
  register_check "SELinux" FAIL "not installed"
fi

section "Secure Boot"

# Check Secure Boot status
if [[ -d /sys/firmware/efi ]]; then
  register_check "EFI boot" PASS "UEFI system"

  if command -v mokutil >/dev/null 2>&1; then
    sb_state=$(mokutil --sb-state 2>/dev/null | head -1 || echo "unknown")
    if echo "$sb_state" | grep -qi "enabled"; then
      register_check "Secure Boot" PASS "enabled"
    elif echo "$sb_state" | grep -qi "disabled"; then
      register_check "Secure Boot" WARN "disabled"
    else
      register_check "Secure Boot" WARN "$sb_state"
    fi
  else
    register_check "Secure Boot" SKIP "mokutil not available"
  fi
else
  register_check "EFI boot" SKIP "legacy BIOS"
fi

section "Firewalld"

# Check Firewalld (default on Fedora)
if command -v firewall-cmd >/dev/null 2>&1; then
  if systemctl is-active firewalld >/dev/null 2>&1; then
    register_check "Firewalld" PASS "active"

    # Get default zone
    default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
    register_check "Default zone" PASS "$default_zone"

    # Check if public zone has services
    public_services=$(firewall-cmd --zone=public --list-services 2>/dev/null || echo "")
    service_count=$(echo "$public_services" | wc -w)
    if [[ "$service_count" -gt 5 ]]; then
      register_check "Public zone services" WARN "$service_count services exposed"
    else
      register_check "Public zone services" PASS "$service_count services"
    fi
  else
    register_check "Firewalld" WARN "installed but not active"
  fi
else
  register_check "Firewalld" WARN "not installed"
fi

section "BTRFS Snapshots"

# Check if root is BTRFS
root_fs=$(df -T / | tail -1 | awk '{print $2}')
if [[ "$root_fs" == "btrfs" ]]; then
  register_check "Root filesystem" PASS "BTRFS"

  # Check for snapper or timeshift
  if command -v snapper >/dev/null 2>&1; then
    register_check "Snapper installed" PASS "yes"

    # Check if snapshots exist
    snap_count=$(snapper list 2>/dev/null | grep -c "^\s*[0-9]" || echo "0")
    if [[ "$snap_count" -gt 0 ]]; then
      register_check "BTRFS snapshots" PASS "$snap_count snapshots"
    else
      register_check "BTRFS snapshots" WARN "no snapshots"
    fi
  elif command -v timeshift >/dev/null 2>&1; then
    register_check "Timeshift installed" PASS "yes"
  else
    register_check "Snapshot tool" WARN "no snapper/timeshift"
  fi
else
  register_check "Root filesystem" PASS "$root_fs (not BTRFS)"
fi

section "Kernel Lockdown"

# Check kernel lockdown mode (Fedora enables this)
if [[ -f /sys/kernel/security/lockdown ]]; then
  lockdown=$(cat /sys/kernel/security/lockdown 2>/dev/null | tr -d '[]')
  case "$lockdown" in
    *integrity*)
      register_check "Kernel lockdown" PASS "integrity"
      ;;
    *confidentiality*)
      register_check "Kernel lockdown" PASS "confidentiality"
      ;;
    *none*)
      register_check "Kernel lockdown" WARN "none"
      ;;
    *)
      register_check "Kernel lockdown" WARN "$lockdown"
      ;;
  esac
else
  register_check "Kernel lockdown" SKIP "not available"
fi

section "Summary"

# Overall assessment based on Fedora best practices
failed_count=$FAILED_CHECKS
warn_count=$WARNING_CHECKS

if [[ "$failed_count" -eq 0 ]] && [[ "$warn_count" -lt 3 ]]; then
  register_check "Fedora security posture" PASS "good"
elif [[ "$failed_count" -eq 0 ]]; then
  register_check "Fedora security posture" WARN "review warnings"
else
  register_check "Fedora security posture" FAIL "issues detected"
fi

print_summary
exit "$EXIT_CODE"
