#!/usr/bin/env bash
# Egress / Outbound Allowlist Audit (portable)
#
# @elevation: root
# @elevation-reason: Requires root to query iptables/nftables firewall rules
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly DEFAULT_TIMEOUT=3
LOG_FILE="$DEFAULT_LOG_FILE"
QUIET=false
VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
AUTO_DETECT=false
declare -a EGRESS_TARGETS=()

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  GREEN=$'\e[0;32m'
  YELLOW=$'\e[0;33m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local level="$1"
  shift || true
  local msg="$*"
  local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ "$QUIET" != "true" ]] && echo "$line"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >>"$LOG_FILE" 2>/dev/null || :; }
}
_dbg() { [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*" || :; }
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0
SKIPPED_CHECKS=0
register_check() {
  local n="$1" r="$2" m="${3:-}"
  ((++TOTAL_CHECKS))
  case "$r" in PASS)
    ((++PASSED_CHECKS))
    echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}"
    ;;
  FAIL)
    ((++FAILED_CHECKS))
    EXIT_CODE=2
    echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}"
    ;;
  WARN)
    ((++WARNING_CHECKS))
    [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1
    echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}"
    ;;
  SKIP)
    ((++SKIPPED_CHECKS))
    echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}"
    ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >>"$LOG_FILE" 2>/dev/null || true
}
section() {
  local t="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $t${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && {
    echo
    echo "=== $t ==="
  } >>"$LOG_FILE" 2>/dev/null || :
}

parse_target() {
  local target="$1"
  if [[ "$target" =~ ^\[(.+)\]:(\d+)$ ]]; then echo "${BASH_REMATCH[1]} ${BASH_REMATCH[2]}"; elif [[ "$target" =~ ^([^:]+):(\d+)$ ]]; then echo "${BASH_REMATCH[1]} ${BASH_REMATCH[2]}"; else return 1; fi
}

audit_tools() {
  section "Tools"
  local tools=(nc curl ss netstat nft iptables firewall-cmd ufw)
  local ok=0
  for t in "${tools[@]}"; do if command -v "$t" >/dev/null 2>&1; then
    register_check "Tool: $t" PASS "available"
    ((ok++))
  else register_check "Tool: $t" SKIP "not found"; fi; done
  if [[ $ok -le 0 ]]; then register_check "Tools" WARN "minimal tools present"; fi
}

firewall_posture() {
  section "Outbound Firewall Posture"
  if command -v nft >/dev/null 2>&1; then register_check "nftables" PASS "present"; elif command -v iptables >/dev/null 2>&1; then register_check "iptables" PASS "present"; else register_check "nft/iptables" SKIP "none"; fi
  if command -v ufw >/dev/null 2>&1; then if ufw status 2>/dev/null | grep -qi active; then register_check "UFW status" PASS "active"; else register_check "UFW status" WARN "inactive"; fi; fi
  if command -v firewall-cmd >/dev/null 2>&1; then if firewall-cmd --state >/dev/null 2>&1; then register_check "firewalld" PASS "running"; else register_check "firewalld" WARN "not running"; fi; fi
}

connectivity_tests() {
  section "Connectivity Tests"
  local t
  if [[ ${#EGRESS_TARGETS[@]} -eq 0 && "$AUTO_DETECT" == "true" ]]; then
    EGRESS_TARGETS+=("8.8.8.8:53" "1.1.1.1:53" "github.com:443" "example.com:80")
    register_check "Auto-detected targets" PASS "${#EGRESS_TARGETS[@]}"
  fi
  if [[ ${#EGRESS_TARGETS[@]} -eq 0 ]]; then
    register_check "Targets" SKIP "none (use --target or --auto)"
    return 0
  fi
  for t in "${EGRESS_TARGETS[@]}"; do
    local host port
    if ! read -r host port < <(parse_target "$t"); then
      register_check "Target: $t" WARN "invalid"
      continue
    fi
    if command -v nc >/dev/null 2>&1 && nc -z -w "$DEFAULT_TIMEOUT" "$host" "$port" >/dev/null 2>&1; then register_check "Connectivity: $host:$port" PASS "nc"; elif [[ "$port" == 80 || "$port" == 443 ]] && command -v curl >/dev/null 2>&1; then
      local proto="http"
      [[ "$port" == 443 ]] && proto="https"
      if curl -s --connect-timeout "$DEFAULT_TIMEOUT" -o /dev/null "${proto}://$host:$port/"; then register_check "Connectivity: $host:$port" PASS "curl"; else register_check "Connectivity: $host:$port" FAIL "blocked or unreachable"; fi
    else register_check "Connectivity: $host:$port" FAIL "blocked or unreachable"; fi
  done
}

active_outbound() {
  section "Active Outbound"
  local out
  if command -v ss >/dev/null 2>&1; then out=$(ss -tunp 2>/dev/null | grep -cE 'ESTAB' || echo 0); else out=$(netstat -tunp 2>/dev/null | grep -cE 'ESTABLISHED' || echo 0); fi
  if [[ ${out:-0} -gt 0 ]]; then register_check "Established connections" PASS "$out"; else register_check "Established connections" PASS "none"; fi
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable egress/outbound allowlist audit
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug
      --no-color         Disable color
  -t, --target H:P       Add connectivity target (e.g., 8.8.8.8:53)
  -a, --auto             Add common test targets automatically
  -h, --help             Help
      --version          Version
EOF
}
version() { echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary() {
  echo
  echo -e "${BOLD}EGRESS ALLOWLIST AUDIT SUMMARY${NC}"
  printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
}

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="${2:-$DEFAULT_LOG_FILE}"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -t | --target)
      [[ -n "${2:-}" ]] && EGRESS_TARGETS+=("$2")
      shift 2
      ;;
    -a | --auto)
      AUTO_DETECT=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done
  setup_colors
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    touch "$LOG_FILE" 2>/dev/null || true
  }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  _dbg "CLI parsed. auto_detect=$AUTO_DETECT targets=${#EGRESS_TARGETS[@]} quiet=$QUIET"
  audit_tools
  firewall_posture
  connectivity_tests
  active_outbound
  print_summary
  exit "$EXIT_CODE"
}
main "$@"
