#!/usr/bin/env bash
#
# Firewall / Network Security Audit
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 9.1, 13.1, 16.11
# - NIST SP 800-53: AC-4, SC-7, SC-13, SI-4
# - ISO 27001: A.9.1, A.10.1, A.13.1, A.13.2
# - OWASP ASVS: V10
# - UK NCSC: Network Security, Secure Configuration
# - PCI DSS: 1.1, 1.2, 1.3, 10.2
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Firewall / Network Audit (portable; renamed logic, same file name OK)
#
# @elevation: root
# @elevation-reason: Requires root to query ufw status and firewall rules
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly FALLBACK_LOG_FILE="/tmp/security-audit-${SCRIPT_NAME%.sh}.log"

# Use default log if writable, otherwise fall back to /tmp or disable logging
if mkdir -p "$(dirname "$DEFAULT_LOG_FILE")" 2>/dev/null && touch "$DEFAULT_LOG_FILE" 2>/dev/null; then
  LOG_FILE="$DEFAULT_LOG_FILE"
elif touch "$FALLBACK_LOG_FILE" 2>/dev/null; then
  LOG_FILE="$FALLBACK_LOG_FILE"
else
  LOG_FILE="" # Disable file logging
fi
QUIET=false
VERBOSE=false
VERY_VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
CSV_PATH=""

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  GREEN=$'\e[0;32m'
  YELLOW=$'\e[0;33m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local level="$1"
  shift || true
  local msg="$*"
  local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ "$QUIET" != "true" ]] && echo "$line"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >>"$LOG_FILE" 2>/dev/null || :; }
}
_dbg() { [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*" || :; }
_trace() { [[ "$VERY_VERBOSE" == "true" ]] && _log TRACE "$*"; }
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0
SKIPPED_CHECKS=0
register_check() {
  local name="$1" result="$2" message="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
  case "$result" in
    PASS)
      PASSED_CHECKS=$((PASSED_CHECKS + 1))
      echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}"
      ;;
    FAIL)
      FAILED_CHECKS=$((FAILED_CHECKS + 1))
      EXIT_CODE=2
      echo -e " ${RED}[FAIL]${NC}  $name${message:+: $message}"
      ;;
    WARN)
      WARNING_CHECKS=$((WARNING_CHECKS + 1))
      [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1
      echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}"
      ;;
    SKIP)
      SKIPPED_CHECKS=$((SKIPPED_CHECKS + 1))
      echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}"
      ;;
  esac
  [[ -n "$LOG_FILE" ]] && { echo "[$(_timestamp)] [$result] $name${message:+: $message}" >>"$LOG_FILE" 2>/dev/null || :; }
}
section() {
  local title="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $title${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && {
    echo
    echo "=== $title ==="
  } >>"$LOG_FILE" 2>/dev/null || :
}

# ---- audits ----
audit_ufw() {
  section "UFW Firewall"
  if ! have_ufw; then
    register_check "UFW" SKIP "Not applicable (ufw not installed)"
    return 0
  fi
  register_check "UFW" PASS "installed"
  local s
  s=$(ufw status verbose 2>/dev/null || true)
  if echo "$s" | grep -qi "Status: active"; then register_check "UFW status" PASS "active"; else register_check "UFW status" WARN "inactive"; fi
  if echo "$s" | grep -qi "Default: .*incoming.*(deny|reject)"; then register_check "Default incoming policy" PASS "restrictive"; else register_check "Default incoming policy" WARN "not restrictive"; fi
}

audit_firewalld() {
  section "firewalld"
  if ! have_firewalld; then
    register_check "firewalld" SKIP "Not applicable (firewalld not installed)"
    return 0
  fi
  local state
  state=$(firewall-cmd --state 2>/dev/null || echo unknown)
  if [[ "$state" == "running" ]]; then register_check "firewalld state" PASS "$state"; else register_check "firewalld state" WARN "$state"; fi
  local default_zone
  default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo unknown)
  register_check "default zone" PASS "$default_zone"
}

audit_nftables() {
  section "nftables"
  if ! have_nft; then
    register_check "nft" SKIP "Not applicable (nftables not installed)"
    return 0
  fi
  local out
  out=$(nft list ruleset 2>/dev/null || true)
  if [[ -z "$out" ]]; then register_check "nftables ruleset" SKIP "Requires root (re-run with sudo)"; else
    local tables
    tables=$(echo "$out" | grep -c '^table' || echo 0)
    register_check "nftables tables" PASS "$tables"
    printf '%s
' "$out" | head -n 20 | while read -r l; do _dbg " $l"; done
  fi
}

audit_iptables() {
  section "iptables (legacy)"
  if ! have_iptables; then
    register_check "iptables" SKIP "Not applicable (iptables not installed)"
    return 0
  fi
  local pol
  pol=$(iptables -S 2>/dev/null || true)
  if [[ -z "$pol" ]]; then
    register_check "iptables rules" SKIP "Requires root (re-run with sudo)"
    return 0
  fi
  local inpol
  inpol=$(echo "$pol" | awk '/^-P INPUT/{print $3}' || true)
  if [[ "$inpol" == "DROP" || "$inpol" == "REJECT" ]]; then register_check "INPUT default policy" PASS "$inpol"; elif [[ "$inpol" == "ACCEPT" ]]; then register_check "INPUT default policy" WARN "ACCEPT (consider DROP)"; else register_check "INPUT default policy" SKIP "unknown"; fi
}

audit_listeners() {
  section "Listening Sockets"
  if ! ss_listen >/dev/null; then
    register_check "socket tool" FAIL "no ss/netstat"
    return 0
  fi
  local out
  out=$(ss_listen || true)
  local tcp udp
  tcp=$(echo "$out" | grep -c '^tcp' || echo 0)
  udp=$(echo "$out" | grep -c '^udp' || echo 0)
  register_check "TCP listening sockets" PASS "$tcp"
  register_check "UDP listening sockets" PASS "$udp"
  # any/0.0.0.0/:: bindings
  # Use command substitution to avoid subshell variable loss
  local any
  any=$(echo "$out" | awk '{print $5}' | awk -F: '{print $1}' | grep -Ec '^(\*|0\.0\.0\.0|::|:::)$' 2>/dev/null || echo "0")
  if [[ ${any:-0} -gt 0 ]]; then register_check "Any-bound services" WARN "$any found (consider binding to specific interfaces)"; else register_check "Any-bound services" PASS "none"; fi
  if [[ -n "$CSV_PATH" ]]; then
    section "CSV Export"
    local tmp
    tmp="$(mktemp)"
    printf '%s
' 'protocol,state,local_address,local_port,process,pid,uid' >"$tmp"
    ss_listen | while read -r line; do
      local proto state laddr port proc pid uid
      proto=$(echo "$line" | awk '{print $1}')
      state=$(echo "$line" | awk '{print $2}')
      laddr=$(echo "$line" | awk '{print $5}')
      port="${laddr##*:}"
      laddr="${laddr%:*}"
      proc=$(echo "$line" | grep -oP 'users:\(\("\K[^" ]+' || true)
      pid=$(echo "$line" | grep -oP 'pid=\K[0-9]+' || true)
      uid=$(echo "$line" | grep -oP 'uid:\K[0-9]+' || true)
      printf '%s,%s,%s,%s,%s,%s,%s
' "$proto" "$state" "$laddr" "$port" "$proc" "$pid" "$uid" >>"$tmp"
    done
    if mv -f -- "$tmp" "$CSV_PATH" 2>/dev/null; then register_check "Listening sockets CSV" PASS "$CSV_PATH"; else register_check "Listening sockets CSV" FAIL "unable to write $CSV_PATH"; fi
  fi
}

audit_ip_forward() {
  section "IP Forwarding"
  local v4 v6
  v4=$(sysctl -n net.ipv4.ip_forward 2>/dev/null || echo unknown)
  v6=$(sysctl -n net.ipv6.conf.all.forwarding 2>/dev/null || echo unknown)
  if [[ "$v4" == 0 ]]; then register_check "IPv4 forwarding" PASS "disabled"; elif [[ "$v4" == 1 ]]; then register_check "IPv4 forwarding" PASS "enabled (routers/containers)"; else register_check "IPv4 forwarding" SKIP "$v4"; fi
  if [[ "$v6" == 0 ]]; then register_check "IPv6 forwarding" PASS "disabled"; elif [[ "$v6" == 1 ]]; then register_check "IPv6 forwarding" PASS "enabled"; else register_check "IPv6 forwarding" SKIP "$v6"; fi
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable firewall & network audit (Debian/Ubuntu, RHEL/Fedora/Alma, SUSE, Arch, Alpine)
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug
  -vv, --very-verbose    Trace
      --csv FILE         Export listeners to CSV
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}
version() { echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary() {
  echo
  echo -e "${BOLD}FIREWALL / NETWORK AUDIT SUMMARY${NC}"
  printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
}

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="${2:-$DEFAULT_LOG_FILE}"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    -vv | --very-verbose)
      VERY_VERBOSE=true
      VERBOSE=true
      shift
      ;;
    --csv)
      CSV_PATH="${2:-}"
      shift 2
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done
  setup_colors
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    touch "$LOG_FILE" 2>/dev/null || true
  }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  _trace "CLI parsed. quiet=$QUIET verbose=$VERBOSE very_verbose=$VERY_VERBOSE csv=${CSV_PATH:-none}"
  audit_ufw
  audit_firewalld
  audit_nftables
  audit_iptables
  audit_listeners
  audit_ip_forward
  print_summary
  exit "$EXIT_CODE"
}
main "$@"
