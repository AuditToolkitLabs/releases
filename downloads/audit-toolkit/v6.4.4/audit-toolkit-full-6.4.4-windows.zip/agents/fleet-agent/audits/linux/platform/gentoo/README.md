# Gentoo Linux Audit Scripts

This directory contains Gentoo-specific security audits that leverage Gentoo's unique
features including Portage package management, USE flags, and OpenRC init system.

## Scripts

| Script | Description | CIS Reference |
|--------|-------------|---------------|
| `gentoo-specific-audit.sh` | Core Gentoo hardening checks | N/A |
| `portage-security-audit.sh` | Portage package manager security | CIS 1.2.x |

## Gentoo-Specific Considerations

### Init System
Gentoo traditionally uses **OpenRC**, though systemd is also supported.
The audits detect which init system is in use and adapt accordingly.

### Package Management
Gentoo uses **Portage** with `emerge` for package management. Key security features:
- `FEATURES="userpriv usersandbox"` for build isolation
- `FEATURES="strict"` for additional build checks
- GLSA (Gentoo Linux Security Advisories) for vulnerability tracking

### USE Flags
USE flags control compile-time options. Security-relevant flags include:
- `hardened` - Enable hardened toolchain
- `pie` - Position Independent Executables
- `ssp` - Stack Smashing Protection

## Running Audits

```bash
# Run Gentoo-specific audit
sudo bash audits/linux/platform/gentoo/gentoo-specific-audit.sh

# Run Portage security audit
sudo bash audits/linux/platform/gentoo/portage-security-audit.sh
```

## References

- [Gentoo Security Handbook](https://wiki.gentoo.org/wiki/Security_Handbook)
- [Gentoo Hardened Project](https://wiki.gentoo.org/wiki/Hardened_Gentoo)
- [GLSA Database](https://security.gentoo.org/glsa/)
