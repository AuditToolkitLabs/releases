#!/usr/bin/env bash
# gentoo-specific-audit.sh — Gentoo Linux-Specific Security Audit
#
# @elevation: root
# @elevation-reason: Some Portage and security checks need root access
#
# Compliance Mapping:
# - Gentoo Hardened Project guidelines
# - Gentoo Security Handbook
# - NIST SP 800-53: CM-6 (Configuration Settings), SI-2 (Flaw Remediation)
# - CIS Controls v8: 4.1 (Secure Configuration), 7.1 (Software Updates)
#
# Checks:
# - Portage configuration security
# - USE flags for security
# - GLSA (Gentoo Linux Security Advisories)
# - Hardened profile detection
# - PIE/SSP compiler protections
# - OpenRC hardening (if applicable)
# - Repository verification (GPG)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/distro.sh
. "$SCRIPT_DIR/../../../../lib/distro.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/svc.sh
. "$SCRIPT_DIR/../../../../lib/svc.sh"

setup_colors

# Verify we're on Gentoo
distro=$(detect_distro)
if [[ "$distro" != "gentoo" && "$distro" != "funtoo" ]]; then
  register_check "Gentoo detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Gentoo Distribution Info"

# Get Gentoo profile
if [[ -L /etc/portage/make.profile ]]; then
  profile=$(readlink -f /etc/portage/make.profile 2>/dev/null | sed 's|.*/profiles/||')
  register_check "Portage profile" PASS "$profile"

  # Check for hardened profile
  if echo "$profile" | grep -qi "hardened"; then
    register_check "Hardened profile" PASS "Using hardened profile"
  else
    register_check "Hardened profile" WARN "Not using hardened profile"
  fi
else
  register_check "Portage profile" WARN "Profile symlink not found"
fi

# Get Gentoo version/release
if [[ -f /etc/gentoo-release ]]; then
  gentoo_release=$(cat /etc/gentoo-release)
  register_check "Gentoo release" PASS "$gentoo_release"
fi

# Check architecture
arch=$(uname -m)
register_check "Architecture" PASS "$arch"

section "Init System Detection"

init_sys=$(detect_init_system)
register_check "Init system" PASS "$init_sys"

if is_openrc; then
  register_check "OpenRC detected" PASS "yes"
elif is_systemd; then
  register_check "systemd detected" PASS "yes"
else
  register_check "Init system" WARN "Unknown: $init_sys"
fi

section "Portage Configuration Security"

# Check FEATURES in make.conf
make_conf="/etc/portage/make.conf"
if [[ -f "$make_conf" ]]; then
  register_check "make.conf exists" PASS "$make_conf"

  # Read FEATURES
  features=$(grep -E "^FEATURES=" "$make_conf" 2>/dev/null | cut -d'"' -f2 || echo "")

  # Security-relevant FEATURES
  if echo "$features" | grep -q "sandbox"; then
    register_check "FEATURE: sandbox" PASS "enabled"
  else
    register_check "FEATURE: sandbox" WARN "not explicitly set"
  fi

  if echo "$features" | grep -q "usersandbox"; then
    register_check "FEATURE: usersandbox" PASS "enabled"
  else
    register_check "FEATURE: usersandbox" WARN "not explicitly set"
  fi

  if echo "$features" | grep -q "strict"; then
    register_check "FEATURE: strict" PASS "enabled"
  else
    register_check "FEATURE: strict" WARN "consider enabling"
  fi

  if echo "$features" | grep -q "userpriv"; then
    register_check "FEATURE: userpriv" PASS "enabled"
  else
    register_check "FEATURE: userpriv" WARN "not set"
  fi

  # Check for dangerous FEATURES
  if echo "$features" | grep -q "keepwork"; then
    register_check "FEATURE: keepwork" WARN "enabled (may leak build info)"
  fi

  if echo "$features" | grep -q "noclean"; then
    register_check "FEATURE: noclean" WARN "enabled (leaves build artifacts)"
  fi
else
  register_check "make.conf exists" WARN "Not found at $make_conf"
fi

section "Security USE Flags"

# Check for security-related USE flags
use_flags=$(grep -E "^USE=" "$make_conf" 2>/dev/null | cut -d'"' -f2 || echo "")

security_flags=("hardened" "pie" "ssp" "caps" "seccomp" "selinux" "pam" "ssl" "gnutls")
found_flags=""

for flag in "${security_flags[@]}"; do
  if echo "$use_flags" | grep -qw "$flag"; then
    found_flags+="$flag "
  fi
done

if [[ -n "$found_flags" ]]; then
  register_check "Security USE flags" PASS "$found_flags"
else
  register_check "Security USE flags" WARN "Consider: hardened pie ssp caps"
fi

# Check for anti-security flags
if echo "$use_flags" | grep -qw "\-pie"; then
  register_check "PIE disabled" FAIL "-pie in USE flags"
else
  register_check "PIE not disabled" PASS "OK"
fi

if echo "$use_flags" | grep -qw "\-ssp"; then
  register_check "SSP disabled" FAIL "-ssp in USE flags"
else
  register_check "SSP not disabled" PASS "OK"
fi

section "Compiler Hardening (GCC Specs)"

# Check GCC specs for hardening
if command -v gcc >/dev/null 2>&1; then
  gcc_version=$(gcc --version | head -1)
  register_check "GCC installed" PASS "$gcc_version"

  # Check for hardened specs (PIE, SSP)
  gcc_specs=$(gcc -v 2>&1 | grep "specs" || echo "")
  if echo "$gcc_specs" | grep -qi "hardened"; then
    register_check "Hardened GCC specs" PASS "Using hardened specs"
  else
    register_check "Hardened GCC specs" WARN "Not using hardened specs"
  fi

  # Check default PIE
  if gcc -v 2>&1 | grep -q "enable-default-pie"; then
    register_check "Default PIE" PASS "enabled in GCC"
  else
    register_check "Default PIE" WARN "not default in GCC"
  fi
fi

section "GLSA Security Advisories"

# Check for glsa-check tool
if command -v glsa-check >/dev/null 2>&1; then
  register_check "glsa-check installed" PASS "available"

  # Check for affected GLSAs (requires root and synced portage)
  if [[ $EUID -eq 0 ]]; then
    affected=$(glsa-check -t affected 2>/dev/null | wc -l || echo "unknown")
    if [[ "$affected" == "0" ]]; then
      register_check "Affected GLSAs" PASS "none"
    elif [[ "$affected" != "unknown" ]]; then
      register_check "Affected GLSAs" FAIL "$affected advisories"
      # List first 5
      glsa-check -l affected 2>/dev/null | head -5 || true
    else
      register_check "Affected GLSAs" SKIP "could not check"
    fi
  else
    register_check "Affected GLSAs" SKIP "requires root"
  fi
else
  register_check "glsa-check installed" WARN "not installed (emerge gentoolkit)"
fi

section "Repository Security"

# Check for GPG verification in repos.conf
repos_conf="/etc/portage/repos.conf"
if [[ -d "$repos_conf" ]]; then
  register_check "repos.conf directory" PASS "exists"

  # Check for sync-type and sync-uri
  gpg_verify=$(grep -r "sync-openpgp-key-path" "$repos_conf" 2>/dev/null || echo "")
  if [[ -n "$gpg_verify" ]]; then
    register_check "Repository GPG verification" PASS "configured"
  else
    register_check "Repository GPG verification" WARN "not configured"
  fi
elif [[ -f "$repos_conf" ]]; then
  gpg_verify=$(grep "sync-openpgp-key-path" "$repos_conf" 2>/dev/null || echo "")
  if [[ -n "$gpg_verify" ]]; then
    register_check "Repository GPG verification" PASS "configured"
  else
    register_check "Repository GPG verification" WARN "not configured"
  fi
else
  register_check "repos.conf" WARN "not found"
fi

# Check for Gentoo keys
if [[ -d /usr/share/openpgp-keys ]]; then
  key_count=$(find /usr/share/openpgp-keys -maxdepth 1 -type f -name '*.asc' 2>/dev/null | wc -l || echo "0")
  if [[ "$key_count" -gt 0 ]]; then
    register_check "OpenPGP keys installed" PASS "$key_count keys"
  else
    register_check "OpenPGP keys installed" WARN "none found"
  fi
fi

section "Package Integrity"

# Check for modified config files (if qcheck available)
if command -v qcheck >/dev/null 2>&1; then
  register_check "qcheck (portage-utils)" PASS "available"

  # Quick check for modified files (expensive, limit output)
  modified=$(qcheck -e 2>/dev/null | head -20 | wc -l || echo "unknown")
  if [[ "$modified" == "0" ]]; then
    register_check "Modified package files" PASS "none detected"
  elif [[ "$modified" != "unknown" ]]; then
    register_check "Modified package files" WARN "$modified+ files modified"
  fi
else
  register_check "qcheck (portage-utils)" WARN "not installed"
fi

section "World File Analysis"

# Check world file for security-critical packages
world_file="/var/lib/portage/world"
if [[ -f "$world_file" ]]; then
  pkg_count=$(wc -l <"$world_file")
  register_check "World file packages" PASS "$pkg_count packages"

  # Check for security-critical packages
  if grep -q "app-crypt/gnupg" "$world_file"; then
    register_check "GnuPG in world" PASS "yes"
  fi

  if grep -qE "(net-firewall/iptables|net-firewall/nftables)" "$world_file"; then
    register_check "Firewall in world" PASS "yes"
  else
    register_check "Firewall in world" WARN "not explicitly installed"
  fi
else
  register_check "World file" WARN "not found"
fi

section "OpenRC Security (if applicable)"

if is_openrc; then
  # Check OpenRC security settings
  if [[ -f /etc/rc.conf ]]; then
    # Check for cgroups
    if grep -q "rc_cgroup_mode" /etc/rc.conf 2>/dev/null; then
      cgroup_mode=$(grep "rc_cgroup_mode" /etc/rc.conf | cut -d'"' -f2)
      register_check "OpenRC cgroup mode" PASS "$cgroup_mode"
    else
      register_check "OpenRC cgroup mode" WARN "not configured"
    fi

    # Check for parallel start (can affect audit timing)
    if grep -q "rc_parallel" /etc/rc.conf 2>/dev/null; then
      rc_parallel=$(grep "rc_parallel" /etc/rc.conf | cut -d'"' -f2)
      register_check "OpenRC parallel" PASS "$rc_parallel"
    fi
  fi

  # List critical services
  critical_services="sshd iptables nftables syslog-ng rsyslog auditd"
  for svc in $critical_services; do
    if rc-service --list 2>/dev/null | grep -q "^${svc}$"; then
      if svc_is_enabled "$svc" 2>/dev/null; then
        register_check "Service: $svc" PASS "enabled"
      else
        register_check "Service: $svc" WARN "not enabled"
      fi
    fi
  done
fi

section "Kernel Security"

# Check for hardened kernel sources
if [[ -d /usr/src/linux ]]; then
  kernel_src=$(readlink -f /usr/src/linux 2>/dev/null | xargs basename)
  if echo "$kernel_src" | grep -qi "hardened"; then
    register_check "Hardened kernel sources" PASS "$kernel_src"
  else
    register_check "Kernel sources" WARN "$kernel_src (not hardened)"
  fi
fi

# Check /proc/sys/kernel for hardening (if readable)
if [[ -r /proc/sys/kernel/randomize_va_space ]]; then
  aslr=$(cat /proc/sys/kernel/randomize_va_space)
  case "$aslr" in
    2) register_check "ASLR" PASS "full (level 2)" ;;
    1) register_check "ASLR" WARN "partial (level 1)" ;;
    0) register_check "ASLR" FAIL "disabled" ;;
  esac
fi

print_summary
exit "$EXIT_CODE"
