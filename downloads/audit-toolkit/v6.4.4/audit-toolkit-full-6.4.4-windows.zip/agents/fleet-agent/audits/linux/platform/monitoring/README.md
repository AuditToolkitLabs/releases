# Prometheus & Grafana Monitoring Stack Security Audits

This directory contains security audits for Prometheus and Grafana monitoring infrastructure.

## Audits

### prometheus-grafana-security-audit.sh

Comprehensive security audit for Prometheus metrics collection and Grafana visualization platform.

## Prometheus Security

### What It Checks

#### 1. Service Status
- Prometheus service running
- Service boot enablement

#### 2. Version & Configuration
- Prometheus version (2.x recommended)
- prometheus.yml configuration file
- Configuration file permissions (644 or more restrictive)

#### 3. Scrape Security
- TLS configuration for target scraping
- Basic authentication setup
- Password file usage (vs plaintext passwords)
- Bearer token security
- Bearer token file usage

#### 4. Web Interface Security
- Port 9090 exposure
- Network binding (0.0.0.0 vs localhost)
- Admin API enablement
- Web authentication

#### 5. Data Security
- Data directory location (/var/lib/prometheus)
- Data directory permissions (750)
- Data ownership (prometheus user)
- Process user (should not be root)

#### 6. Metric Exposure
- Metrics endpoint security
- Scrape target authentication
- Remote write security

### Critical Prometheus Risks

1. **No Authentication**: Web UI exposed without auth on port 9090
2. **Plaintext Scraping**: HTTP instead of HTTPS for targets
3. **Admin API Enabled**: Admin API accessible without auth
4. **Running as Root**: Process running with root privileges
5. **World-Readable Data**: Metrics data accessible by all users

## Grafana Security

### What It Checks

#### 1. Service Status
- Grafana service running
- Service boot enablement

#### 2. Version & Configuration
- Grafana version (8.x, 9.x, or 10.x recommended)
- grafana.ini configuration file
- Configuration file permissions (640 or 600)

#### 3. Authentication Security
- **Anonymous access** (must be disabled)
- **Admin password** (default 'admin' detection)
- **Secret key** (session security)
- LDAP authentication
- OAuth integration (Google, GitHub, GitLab)

#### 4. Web Security
- HTTPS protocol enablement
- TLS certificate configuration
- Server binding (all interfaces vs localhost)
- Security headers (X-Frame-Options, etc.)

#### 5. Database Security
- Database type (SQLite vs PostgreSQL/MySQL)
- SQLite file permissions (640 or 600)
- Database password management
- Password in config vs environment variable

#### 6. Plugin Security
- Installed plugins count
- Plugin directory permissions
- Plugin source verification

#### 7. Process Security
- Process user (should not be root)
- File ownership

### Critical Grafana Risks

1. **Default Admin Password**: 'admin/admin' unchanged
2. **Anonymous Access**: Unauthenticated dashboard access
3. **HTTP Only**: No HTTPS encryption
4. **Default Secret Key**: Session hijacking possible
5. **Running as Root**: Privilege escalation risk
6. **Password in Config**: Credentials in grafana.ini

## Usage

```bash
# Run monitoring stack security audit
bash audits/linux/platform/monitoring/prometheus-grafana-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain platform --match monitoring
```

## Requirements

### Prometheus
- Prometheus 2.x or later
- prometheus.yml configuration
- Access to /var/lib/prometheus data directory

### Grafana
- Grafana 8.x or later
- grafana.ini configuration
- Access to Grafana database

## Remediation

### Prometheus Security Hardening

#### Enable Basic Authentication

Create a web configuration file with bcrypt hashed password:

```bash
# Install htpasswd
apt-get install apache2-utils  # Debian/Ubuntu
yum install httpd-tools         # RHEL/CentOS

# Generate password hash
htpasswd -nBC 12 "" | tr -d ':\n'

# Create web-config.yml
cat > /etc/prometheus/web-config.yml <<'EOF'
basic_auth_users:
  admin: $2y$12$hashed_password_here
EOF

chmod 640 /etc/prometheus/web-config.yml
chown prometheus:prometheus /etc/prometheus/web-config.yml
```

Start Prometheus with web config:

```bash
prometheus --web.config.file=/etc/prometheus/web-config.yml
```

#### Enable TLS for Web UI

```yaml
# web-config.yml
tls_server_config:
  cert_file: /etc/prometheus/prometheus.crt
  key_file: /etc/prometheus/prometheus.key
  # Optional: client certificate authentication
  client_auth_type: RequireAndVerifyClientCert
  client_ca_file: /etc/prometheus/ca.crt

basic_auth_users:
  admin: $2y$12$hashed_password_here
```

#### Secure Scrape Targets

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'secure-app'
    scheme: https  # Use HTTPS
    
    tls_config:
      ca_file: /etc/prometheus/ca.crt
      cert_file: /etc/prometheus/client.crt
      key_file: /etc/prometheus/client.key
      insecure_skip_verify: false
    
    basic_auth:
      username: scrape_user
      password_file: /etc/prometheus/scrape_password.txt
    
    static_configs:
      - targets: ['app1.example.com:9100']
```

Password file:

```bash
echo 'SecurePassword123' > /etc/prometheus/scrape_password.txt
chmod 600 /etc/prometheus/scrape_password.txt
chown prometheus:prometheus /etc/prometheus/scrape_password.txt
```

#### Restrict Network Access

Bind to localhost and use reverse proxy:

```bash
# Start Prometheus
prometheus --web.listen-address="127.0.0.1:9090"

# Nginx reverse proxy with authentication
server {
    listen 443 ssl;
    server_name prometheus.example.com;
    
    ssl_certificate /etc/ssl/certs/prometheus.crt;
    ssl_certificate_key /etc/ssl/private/prometheus.key;
    
    auth_basic "Prometheus";
    auth_basic_user_file /etc/nginx/.htpasswd;
    
    location / {
        proxy_pass http://127.0.0.1:9090;
        proxy_set_header Host $host;
    }
}
```

#### Disable Admin API

Don't use `--web.enable-admin-api` in production unless required.

If needed, restrict via firewall or reverse proxy authentication.

### Grafana Security Hardening

#### Change Default Admin Password

```bash
# Via grafana-cli
grafana-cli admin reset-admin-password NewStrongPassword123

# Or via grafana.ini
[security]
admin_user = admin
admin_password = $__env{GF_ADMIN_PASSWORD}

# Set environment variable
export GF_ADMIN_PASSWORD="NewStrongPassword123"
```

#### Disable Anonymous Access

```ini
# /etc/grafana/grafana.ini
[auth.anonymous]
enabled = false
```

#### Generate Strong Secret Key

```bash
# Generate random secret key (32+ characters)
openssl rand -base64 32

# Set in grafana.ini
[security]
secret_key = generated_random_string_here

# Or via environment variable
export GF_SECURITY_SECRET_KEY="generated_random_string_here"
```

#### Enable HTTPS

```ini
# /etc/grafana/grafana.ini
[server]
protocol = https
cert_file = /etc/grafana/grafana.crt
cert_key = /etc/grafana/grafana.key
```

Generate self-signed certificate (for testing):

```bash
openssl req -x509 -newkey rsa:4096 -keyout grafana.key -out grafana.crt -days 365 -nodes \
  -subj "/CN=grafana.example.com"

chmod 600 grafana.key
chown grafana:grafana grafana.key grafana.crt
```

#### Configure LDAP Authentication

```ini
# /etc/grafana/grafana.ini
[auth.ldap]
enabled = true
config_file = /etc/grafana/ldap.toml
allow_sign_up = true
```

```toml
# /etc/grafana/ldap.toml
[[servers]]
host = "ldap.example.com"
port = 389
use_ssl = false
start_tls = true
ssl_skip_verify = false
bind_dn = "cn=admin,dc=example,dc=com"
bind_password = 'admin_password'
search_filter = "(uid=%s)"
search_base_dns = ["ou=people,dc=example,dc=com"]

[servers.attributes]
name = "givenName"
surname = "sn"
username = "uid"
member_of = "memberOf"
email =  "email"

[[servers.group_mappings]]
group_dn = "cn=admins,ou=groups,dc=example,dc=com"
org_role = "Admin"

[[servers.group_mappings]]
group_dn = "cn=editors,ou=groups,dc=example,dc=com"
org_role = "Editor"
```

#### Use External Database

```ini
# /etc/grafana/grafana.ini
[database]
type = postgres
host = postgres.example.com:5432
name = grafana
user = grafana
password = $__env{GF_DATABASE_PASSWORD}

# Set environment variable
export GF_DATABASE_PASSWORD="SecureDatabasePassword"
```

Or use password file:

```ini
[database]
type = postgres
host = postgres.example.com:5432
name = grafana
user = grafana
password = $__file{/etc/grafana/db_password.txt}
```

#### Security Headers

```ini
# /etc/grafana/grafana.ini
[security]
strict_transport_security = true
strict_transport_security_max_age_seconds = 31536000
strict_transport_security_subdomains = true
x_content_type_options = true
x_xss_protection = true
cookie_secure = true
cookie_samesite = lax
```

#### Restrict Plugin Installation

```ini
[plugins]
allow_loading_unsigned_plugins = 
enable_alpha = false
plugin_admin_enabled = false
```

#### Run as Non-Root User

Systemd service file:

```ini
[Unit]
Description=Grafana server
After=network.target

[Service]
Type=notify
User=grafana
Group=grafana
WorkingDirectory=/usr/share/grafana
ExecStart=/usr/sbin/grafana-server \
  --config=/etc/grafana/grafana.ini \
  --homepath=/usr/share/grafana

[Install]
WantedBy=multi-user.target
```

### Prometheus-Grafana Integration Security

#### Secure Datasource Configuration

```yaml
# /etc/grafana/provisioning/datasources/prometheus.yml
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://localhost:9090
    
    # Basic auth for Prometheus
    basicAuth: true
    basicAuthUser: admin
    secureJsonData:
      basicAuthPassword: PrometheusPassword
    
    # Or use Bearer token
    jsonData:
      httpHeaderName1: 'Authorization'
    secureJsonData:
      httpHeaderValue1: 'Bearer YOUR_TOKEN_HERE'
    
    isDefault: true
    editable: false
```

Permissions:

```bash
chmod 640 /etc/grafana/provisioning/datasources/prometheus.yml
chown grafana:grafana /etc/grafana/provisioning/datasources/prometheus.yml
```

## Security Best Practices

### Prometheus
1. **Enable authentication** - Use basic auth or reverse proxy
2. **Use HTTPS** - Encrypt web UI and API traffic
3. **Secure scrape targets** - TLS and authentication for metrics
4. **Restrict network** - Bind to localhost, use firewall
5. **Run as dedicated user** - Never as root
6. **Protect data directory** - 750 permissions, prometheus user
7. **Disable admin API** - Unless required
8. **Use remote write auth** - For federated setups
9. **Regular updates** - Apply security patches
10. **Monitor the monitor** - Alert on Prometheus failures

### Grafana
1. **Change default password** - Never use admin/admin
2. **Disable anonymous access** - Require authentication
3. **Use strong secret key** - 32+ random characters
4. **Enable HTTPS** - Encrypt all traffic
5. **Use external auth** - LDAP, OAuth, SAML
6. **Secure database** - Use PostgreSQL/MySQL, encrypt passwords
7. **Restrict plugins** - Verify sources, disable unsigned
8. **Run as grafana user** - Never as root
9. **Security headers** - HSTS, XSS protection, etc.
10. **Regular backups** - Dashboards and database

## Common Vulnerabilities

| Vulnerability | Severity | Impact | Remediation |
|--------------|----------|--------|-------------|
| Default admin password | CRITICAL | Full account takeover | Change immediately |
| Anonymous access | HIGH | Unauthorized data access | Disable in config |
| No HTTPS | HIGH | Credential interception | Enable TLS |
| Default secret key | HIGH | Session hijacking | Generate random key |
| No Prometheus auth | MEDIUM | Metric data exposure | Enable basic auth |
| Running as root | MEDIUM | Privilege escalation | Use dedicated user |
| Plaintext passwords | MEDIUM | Credential exposure | Use env vars or files |

## Monitoring Best Practices

### Alert on Security Events

```yaml
# prometheus alerts
groups:
  - name: security
    rules:
      - alert: PrometheusDown
        expr: up{job="prometheus"} == 0
        for: 1m
        
      - alert: GrafanaDown
        expr: up{job="grafana"} == 0
        for: 1m
        
      - alert: HighFailedLoginAttempts
        expr: rate(grafana_api_login_failures_total[5m]) > 0.5
        for: 5m
```

### Audit Logging

Enable Grafana audit logging:

```ini
[log]
mode = console file
level = info

[auditing]
enabled = true
log_dashboard_content = true
```

## References

- [Prometheus Security](https://prometheus.io/docs/operating/security/)
- [Prometheus TLS Setup](https://prometheus.io/docs/prometheus/latest/configuration/https/)
- [Grafana Security](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/)
- [Grafana Authentication](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/configure-authentication/)
- [Grafana LDAP](https://grafana.com/docs/grafana/latest/setup-grafana/configure-security/configure-authentication/ldap/)
