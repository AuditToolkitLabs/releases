#!/usr/bin/env bash
#
# Prometheus & Grafana Monitoring Stack Security Audit
#
# Compliance Mapping:
# - CIS Controls: 8.1, 8.2, 16.11
# - NIST SP 800-53: AU-2, AU-6, SI-4
# - ISO 27001: A.12.4, A.13.1
# - OWASP ASVS: V10
# - UK NCSC: Logging and Monitoring, Availability
# - PCI DSS: 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Prometheus & Grafana Monitoring Stack Security Audit
# Validates Prometheus and Grafana installations, authentication, and security configurations
#
# @elevation: partial
# @elevation-reason: Some config files require elevated privileges to read
#
set -euo pipefail

# Source required libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/distro.sh
. "$SCRIPT_DIR/../../../../lib/distro.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/svc.sh
. "$SCRIPT_DIR/../../../../lib/svc.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/pkg.sh
. "$SCRIPT_DIR/../../../../lib/pkg.sh"

# === Configuration ===
PROMETHEUS_CONF="/etc/prometheus/prometheus.yml"
PROMETHEUS_PATHS=(
  "/etc/prometheus"
  "/opt/prometheus"
  "/usr/local/prometheus"
)

GRAFANA_CONF="/etc/grafana/grafana.ini"
GRAFANA_PATHS=(
  "/etc/grafana"
  "/opt/grafana"
  "/usr/share/grafana"
)

# === Performance: Cache variables ===
PROMETHEUS_VERSION=""
GRAFANA_VERSION=""
PROMETHEUS_INSTALLED=""
GRAFANA_INSTALLED=""
PROM_CONFIG=""
GRAFANA_CONFIG=""

# === Helper Functions ===

# Check if Prometheus is installed
is_prometheus_installed() {
  if [[ -n "$PROMETHEUS_INSTALLED" ]]; then
    [[ "$PROMETHEUS_INSTALLED" == "true" ]] && return 0 || return 1
  fi

  if command -v prometheus >/dev/null 2>&1 || pgrep -x prometheus >/dev/null 2>&1 || [[ -f "$PROMETHEUS_CONF" ]]; then
    PROMETHEUS_INSTALLED="true"
    return 0
  fi

  PROMETHEUS_INSTALLED="false"
  return 1
}

# Check if Grafana is installed
is_grafana_installed() {
  if [[ -n "$GRAFANA_INSTALLED" ]]; then
    [[ "$GRAFANA_INSTALLED" == "true" ]] && return 0 || return 1
  fi

  if command -v grafana-server >/dev/null 2>&1 || pgrep -x grafana-server >/dev/null 2>&1 || [[ -f "$GRAFANA_CONF" ]]; then
    GRAFANA_INSTALLED="true"
    return 0
  fi

  GRAFANA_INSTALLED="false"
  return 1
}

# Get Prometheus version
get_prometheus_version() {
  if [[ -n "$PROMETHEUS_VERSION" ]]; then
    echo "$PROMETHEUS_VERSION"
    return 0
  fi

  if command -v prometheus >/dev/null 2>&1; then
    version=$(prometheus --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    PROMETHEUS_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Get Grafana version
get_grafana_version() {
  if [[ -n "$GRAFANA_VERSION" ]]; then
    echo "$GRAFANA_VERSION"
    return 0
  fi

  if command -v grafana-server >/dev/null 2>&1; then
    version=$(grafana-server -v 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
    GRAFANA_VERSION="$version"
    echo "$version"
  else
    echo "unknown"
  fi
}

# Find Prometheus config
find_prometheus_config() {
  if [[ -n "$PROM_CONFIG" ]]; then
    echo "$PROM_CONFIG"
    return 0
  fi

  for path in "${PROMETHEUS_PATHS[@]}"; do
    if [[ -f "$path/prometheus.yml" ]]; then
      PROM_CONFIG="$path/prometheus.yml"
      echo "$path/prometheus.yml"
      return 0
    fi
  done

  echo ""
}

# Find Grafana config
find_grafana_config() {
  if [[ -n "$GRAFANA_CONFIG" ]]; then
    echo "$GRAFANA_CONFIG"
    return 0
  fi

  for path in "${GRAFANA_PATHS[@]}"; do
    if [[ -f "$path/grafana.ini" ]]; then
      GRAFANA_CONFIG="$path/grafana.ini"
      echo "$path/grafana.ini"
      return 0
    fi
  done

  echo ""
}

# Get Grafana config value
get_grafana_config() {
  local key="$1"
  local section="${2:-}"

  if [[ -z "$GRAFANA_CONFIG" ]]; then
    GRAFANA_CONFIG=$(find_grafana_config)
  fi

  if [[ -f "$GRAFANA_CONFIG" ]]; then
    if [[ -n "$section" ]]; then
      awk -v section="$section" -v key="$key" '
        /^\[.*\]$/ { current=$0; gsub(/[\[\]]/, "", current) }
        current == section && $1 == key { sub(/^[^=]*= */, ""); print; exit }
      ' "$GRAFANA_CONFIG" | head -n1
    else
      grep "^${key}[[:space:]]*=" "$GRAFANA_CONFIG" 2>/dev/null | head -n1 | sed "s/^${key}[[:space:]]*=[[:space:]]*//" || echo ""
    fi
  fi
}

# === MAIN AUDIT ===

section "Monitoring Stack Detection"

prometheus_detected=false
grafana_detected=false

if is_prometheus_installed; then
  register_check "Prometheus" PASS "Prometheus detected"
  prometheus_detected=true
else
  register_check "Prometheus" SKIP "Not applicable (Prometheus not installed)"
fi

if is_grafana_installed; then
  register_check "Grafana" PASS "Grafana detected"
  grafana_detected=true
else
  register_check "Grafana" SKIP "Not applicable (Grafana not installed)"
fi

# Exit if neither is installed
if [[ "$prometheus_detected" == "false" && "$grafana_detected" == "false" ]]; then
  register_check "Monitoring Stack" SKIP "No monitoring services detected"
  print_summary
  exit "$EXIT_CODE"
fi

# === PROMETHEUS AUDIT ===
if [[ "$prometheus_detected" == "true" ]]; then

  section "Prometheus Service"

  # Check Prometheus service
  if svc_is_active prometheus; then
    register_check "Prometheus Service" PASS "Prometheus running"
  else
    register_check "Prometheus Service" WARN "Prometheus not running"
  fi

  # Get version
  prom_version=$(get_prometheus_version)
  if [[ "$prom_version" != "unknown" ]]; then
    register_check "Prometheus Version" PASS "Prometheus $prom_version"

    # Check for old versions (< 2.x)
    major=$(echo "$prom_version" | cut -d. -f1)
    if [[ "$major" -lt 2 ]]; then
      register_check "Version Status" WARN "Prometheus $major.x (consider upgrading to 2.x)"
    else
      register_check "Version Status" PASS "Prometheus $major.x (current)"
    fi
  fi

  section "Prometheus Configuration"

  prom_config=$(find_prometheus_config)
  if [[ -z "$prom_config" ]]; then
    register_check "prometheus.yml" FAIL "Configuration file not found"
  else
    register_check "prometheus.yml" PASS "Found at $prom_config"

    # Check file permissions
    prom_perms=$(stat -c '%a' "$prom_config" 2>/dev/null || stat -f '%Lp' "$prom_config" 2>/dev/null || echo "000")
    if [[ "$prom_perms" == "644" || "$prom_perms" == "640" || "$prom_perms" == "600" ]]; then
      register_check "Config Permissions" PASS "permissions $prom_perms"
    else
      register_check "Config Permissions" WARN "permissions $prom_perms (should be 644 or more restrictive)"
    fi

    # Check for TLS configuration
    if grep -qE "tls_config:|scheme: https" "$prom_config" 2>/dev/null; then
      register_check "TLS Configuration" PASS "TLS enabled for scraping"
    else
      register_check "TLS Configuration" WARN "No TLS configuration (targets may be unencrypted)"
    fi

    # Check for basic auth
    if grep -qE "basic_auth:" "$prom_config" 2>/dev/null; then
      register_check "Basic Auth" PASS "Basic authentication configured"

      # Check for plaintext passwords
      if grep -EA 5 "basic_auth:" "$prom_config" 2>/dev/null | grep -qE "password:.*[^_]file"; then
        register_check "Auth Security" WARN "Plaintext passwords in config (use password_file)"
      else
        register_check "Auth Security" PASS "Using password_file (secure)"
      fi
    fi

    # Check for bearer tokens
    if grep -qE "bearer_token:" "$prom_config" 2>/dev/null; then
      if grep -qE "bearer_token_file:" "$prom_config" 2>/dev/null; then
        register_check "Bearer Token" PASS "Using bearer_token_file (secure)"
      else
        register_check "Bearer Token" WARN "Bearer token in config (use bearer_token_file)"
      fi
    fi
  fi

  section "Prometheus Web Interface"

  # Check if Prometheus is listening
  if command -v ss >/dev/null 2>&1; then
    prom_port=$(ss -ln 2>/dev/null | grep -c ":9090" || echo "0")

    if [[ "$prom_port" -gt 0 ]]; then
      register_check "Web UI Port" PASS "Listening on port 9090"

      # Check binding address
      prom_bind=$(ss -ln 2>/dev/null | grep ":9090" | awk '{print $5}' | cut -d: -f1 | head -n1 || echo "")
      if [[ "$prom_bind" == "0.0.0.0" || "$prom_bind" == "*" ]]; then
        register_check "Web UI Binding" WARN "Listening on all interfaces (restrict with --web.listen-address)"
      elif [[ "$prom_bind" =~ ^127\. ]]; then
        register_check "Web UI Binding" PASS "Bound to localhost (secure)"
      else
        register_check "Web UI Binding" PASS "Bound to specific IP"
      fi
    else
      register_check "Web UI Port" WARN "Not listening on port 9090"
    fi
  fi

  # Check for web authentication
  if pgrep -fa prometheus 2>/dev/null | grep -qE "\-\-web\.enable\-admin\-api"; then
    register_check "Admin API" WARN "Admin API enabled (ensure authentication required)"
  fi

  section "Prometheus Data Security"

  # Find data directory
  prom_data_dir="/var/lib/prometheus"
  if [[ ! -d "$prom_data_dir" ]]; then
    # Try to find from process args
    prom_data_dir=$(pgrep -fa prometheus 2>/dev/null | grep -oE "\-\-storage\.tsdb\.path=[^ ]+" | cut -d= -f2 || echo "")
  fi

  if [[ -d "$prom_data_dir" ]]; then
    register_check "Data Directory" PASS "$prom_data_dir"

    # Check permissions
    data_perms=$(stat -c '%a' "$prom_data_dir" 2>/dev/null || stat -f '%Lp' "$prom_data_dir" 2>/dev/null || echo "000")
    if [[ "$data_perms" =~ ^7[0-7]0$ ]]; then
      register_check "Data Permissions" PASS "permissions $data_perms"
    else
      register_check "Data Permissions" WARN "permissions $data_perms (ensure only prometheus user can access)"
    fi

    # Check ownership
    data_owner=$(stat -c '%U' "$prom_data_dir" 2>/dev/null || stat -f '%Su' "$prom_data_dir" 2>/dev/null || echo "unknown")
    if [[ "$data_owner" == "prometheus" ]]; then
      register_check "Data Ownership" PASS "owned by prometheus user"
    else
      register_check "Data Ownership" WARN "owned by $data_owner (should be prometheus)"
    fi
  else
    register_check "Data Directory" WARN "Data directory not found"
  fi

  # Check process user
  prom_pid=$(pgrep -xo prometheus 2>/dev/null || echo "")
  if [[ -n "$prom_pid" ]]; then
    process_user=$(ps -o user= -p "$prom_pid" 2>/dev/null | awk 'NR==1 {print $1}' || echo "")

    if [[ "$process_user" == "root" ]]; then
      register_check "Process User" FAIL "Prometheus running as root (security risk)"
    elif [[ "$process_user" == "prometheus" ]]; then
      register_check "Process User" PASS "Prometheus running as prometheus user"
    else
      register_check "Process User" PASS "Prometheus running as $process_user (not root)"
    fi
  fi

fi

# === GRAFANA AUDIT ===
if [[ "$grafana_detected" == "true" ]]; then

  section "Grafana Service"

  # Check Grafana service
  if svc_is_active grafana-server; then
    register_check "Grafana Service" PASS "Grafana running"
  else
    register_check "Grafana Service" WARN "Grafana not running"
  fi

  # Get version
  grafana_version=$(get_grafana_version)
  if [[ "$grafana_version" != "unknown" ]]; then
    register_check "Grafana Version" PASS "Grafana $grafana_version"

    # Check for very old versions (< 8.x)
    major=$(echo "$grafana_version" | cut -d. -f1)
    if [[ "$major" -lt 8 ]]; then
      register_check "Version Status" WARN "Grafana $major.x (consider upgrading to 9.x or 10.x)"
    else
      register_check "Version Status" PASS "Grafana $major.x (recent)"
    fi
  fi

  section "Grafana Configuration"

  grafana_config=$(find_grafana_config)
  if [[ -z "$grafana_config" ]]; then
    register_check "grafana.ini" FAIL "Configuration file not found"
  else
    register_check "grafana.ini" PASS "Found at $grafana_config"

    # Check file permissions
    grafana_perms=$(stat -c '%a' "$grafana_config" 2>/dev/null || stat -f '%Lp' "$grafana_config" 2>/dev/null || echo "000")
    if [[ "$grafana_perms" == "640" || "$grafana_perms" == "600" ]]; then
      register_check "Config Permissions" PASS "permissions $grafana_perms"
    else
      register_check "Config Permissions" WARN "permissions $grafana_perms (should be 640 or 600)"
    fi
  fi

  section "Grafana Authentication"

  if [[ -n "$grafana_config" ]]; then
    # Check anonymous access
    allow_anon=$(get_grafana_config "enabled" "auth.anonymous")
    if [[ "$allow_anon" == "true" ]]; then
      register_check "Anonymous Access" FAIL "Anonymous access enabled (disable in production)"
    else
      register_check "Anonymous Access" PASS "Anonymous access disabled"
    fi

    # Check admin password
    admin_password=$(get_grafana_config "admin_password" "security")
    if [[ "$admin_password" == "admin" ]]; then
      register_check "Admin Password" FAIL "Default admin password 'admin' (change immediately)"
    elif [[ -n "$admin_password" && "$admin_password" != "" ]]; then
      register_check "Admin Password" WARN "Admin password in config (consider using env var)"
    else
      register_check "Admin Password" PASS "Admin password not in config (set via env)"
    fi

    # Check secret key
    secret_key=$(get_grafana_config "secret_key" "security")
    if [[ "$secret_key" == "SW2YcwTIb9zpOOhoPsMm" ]]; then
      register_check "Secret Key" FAIL "Default secret_key (change for session security)"
    elif [[ -n "$secret_key" ]]; then
      key_length=${#secret_key}
      if [[ "$key_length" -ge 32 ]]; then
        register_check "Secret Key" PASS "Custom secret_key set (${key_length} chars)"
      else
        register_check "Secret Key" WARN "Secret key short (${key_length} chars, use 32+)"
      fi
    fi

    # Check for OAuth/LDAP
    if grep -qE "^\[auth\..*\]" "$grafana_config" 2>/dev/null; then
      if grep -q "^\[auth.ldap\]" "$grafana_config" 2>/dev/null; then
        register_check "LDAP Auth" PASS "LDAP authentication configured"
      fi

      if grep -qE "^\[auth\.google\]|^\[auth\.github\]|^\[auth\.gitlab\]" "$grafana_config" 2>/dev/null; then
        register_check "OAuth" PASS "OAuth authentication configured"
      fi
    fi
  fi

  section "Grafana Web Security"

  if [[ -n "$grafana_config" ]]; then
    # Check protocol
    protocol=$(get_grafana_config "protocol" "server")
    if [[ "$protocol" == "https" ]]; then
      register_check "HTTPS" PASS "HTTPS protocol enabled"

      # Check certificate files
      cert_file=$(get_grafana_config "cert_file" "server")
      if [[ -n "$cert_file" && -f "$cert_file" ]]; then
        register_check "TLS Certificate" PASS "Certificate file exists"
      else
        register_check "TLS Certificate" WARN "Certificate file not found or not configured"
      fi
    else
      register_check "HTTPS" WARN "HTTP protocol (enable HTTPS in production)"
    fi

    # Check HTTP port and binding
    http_port=$(get_grafana_config "http_port" "server")
    http_addr=$(get_grafana_config "http_addr" "server")

    if [[ "$http_addr" == "0.0.0.0" || "$http_addr" == "" ]]; then
      register_check "Server Binding" WARN "Listening on all interfaces on port ${http_port:-3000} (restrict with http_addr)"
    elif [[ "$http_addr" =~ ^127\. ]]; then
      register_check "Server Binding" PASS "Bound to localhost on port ${http_port:-3000} (use reverse proxy)"
    else
      register_check "Server Binding" PASS "Bound to ${http_addr}:${http_port:-3000}"
    fi

    # Check for security headers
    if grep -q "X-Frame-Options" "$grafana_config" 2>/dev/null; then
      register_check "Security Headers" PASS "Custom security headers configured"
    fi
  fi

  section "Grafana Database"

  if [[ -n "$grafana_config" ]]; then
    # Check database type
    db_type=$(get_grafana_config "type" "database")

    if [[ "$db_type" == "sqlite3" ]]; then
      register_check "Database Type" WARN "Using SQLite (consider PostgreSQL/MySQL for production)"

      # Check SQLite file permissions
      db_path=$(get_grafana_config "path" "database")
      if [[ -n "$db_path" && -f "$db_path" ]]; then
        db_perms=$(stat -c '%a' "$db_path" 2>/dev/null || stat -f '%Lp' "$db_path" 2>/dev/null || echo "000")
        if [[ "$db_perms" == "640" || "$db_perms" == "600" ]]; then
          register_check "DB Permissions" PASS "SQLite file: $db_perms"
        else
          register_check "DB Permissions" WARN "SQLite file: $db_perms (should be 640 or 600)"
        fi
      fi
    elif [[ "$db_type" == "postgres" || "$db_type" == "mysql" ]]; then
      register_check "Database Type" PASS "Using $db_type (production-ready)"

      # Check for password in config
      db_password=$(get_grafana_config "password" "database")
      if [[ -n "$db_password" ]]; then
        register_check "DB Password" WARN "Database password in config (consider env var)"
      else
        register_check "DB Password" PASS "No password in config (using env var or file)"
      fi
    fi
  fi

  section "Grafana Plugins"

  # Find plugins directory
  plugins_dir="/var/lib/grafana/plugins"
  if [[ ! -d "$plugins_dir" ]]; then
    plugins_dir=$(get_grafana_config "plugins" "paths")
  fi

  if [[ -d "$plugins_dir" ]]; then
    plugin_count=$(find "$plugins_dir" -maxdepth 1 -type d ! -path "$plugins_dir" 2>/dev/null | wc -l || echo "0")

    if [[ "$plugin_count" -gt 0 ]]; then
      register_check "Installed Plugins" PASS "$plugin_count plugin(s) installed"
    else
      register_check "Installed Plugins" PASS "No additional plugins (using built-in only)"
    fi

    # Check plugins permissions
    plugins_perms=$(stat -c '%a' "$plugins_dir" 2>/dev/null || stat -f '%Lp' "$plugins_dir" 2>/dev/null || echo "000")
    if [[ "$plugins_perms" =~ ^7[0-5][0-5]$ ]]; then
      register_check "Plugins Permissions" PASS "permissions $plugins_perms"
    fi
  fi

  # Check process user
  grafana_pid=$(pgrep -xo grafana-server 2>/dev/null || echo "")
  if [[ -n "$grafana_pid" ]]; then
    process_user=$(ps -o user= -p "$grafana_pid" 2>/dev/null | awk 'NR==1 {print $1}' || echo "")

    if [[ "$process_user" == "root" ]]; then
      register_check "Process User" FAIL "Grafana running as root (security risk)"
    elif [[ "$process_user" == "grafana" ]]; then
      register_check "Process User" PASS "Grafana running as grafana user"
    else
      register_check "Process User" PASS "Grafana running as $process_user (not root)"
    fi
  fi

fi

# === Integration Checks ===
if [[ "$prometheus_detected" == "true" && "$grafana_detected" == "true" ]]; then
  section "Prometheus-Grafana Integration"

  register_check "Stack Integration" PASS "Both Prometheus and Grafana detected"

  # Check if Grafana has Prometheus datasource
  datasources_dir="/etc/grafana/provisioning/datasources"
  if [[ -d "$datasources_dir" ]]; then
    if find "$datasources_dir" \( -name "*.yml" -o -name "*.yaml" \) -exec grep -li "prometheus" {} + >/dev/null 2>&1; then
      register_check "Prometheus Datasource" PASS "Prometheus datasource provisioned"
    fi
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
