# openSUSE/SUSE Linux-Specific Audits

This folder contains security audit scripts specifically designed for openSUSE and SUSE Linux Enterprise.

## Included Audits

### opensuse-specific-audit.sh

Comprehensive openSUSE/SUSE-specific security checks including:

- **Distribution Info**: Version, release type (Leap/Tumbleweed/SLES), transactional system detection
- **Zypper Package Manager**: GPG verification, security patches, minimal install settings
- **SUSEConnect**: Enterprise registration status (SLES only)
- **AppArmor**: Profile enforcement (SUSE default MAC)
- **Snapper BTRFS Snapshots**: Configuration, timeline snapshots, snapshot count
- **Transactional Updates**: MicroOS/transactional system support
- **Firewalld**: Zone configuration
- **YaST Security**: Permission security level
- **Kernel Security**: Lockdown mode, Secure Boot

## Usage

```bash
# Run directly
bash audits/linux/platform/opensuse/opensuse-specific-audit.sh

# Via orchestrator
./orchestrator/orchestrator.sh --path audits/linux/platform/opensuse/opensuse-specific-audit.sh

# With all platform audits
./orchestrator/orchestrator.sh --domain platform
```

## Supported Distributions

- openSUSE Leap 15.x
- openSUSE Tumbleweed
- SUSE Linux Enterprise Server (SLES) 12/15
- openSUSE MicroOS
- SUSE Linux Enterprise Micro

## Compliance Mapping

| Check | NIST SP 800-53 | CIS SLES | Notes |
|-------|----------------|----------|-------|
| Zypper GPG verification | CM-6, SI-7 | 1.2.1 | Package integrity |
| AppArmor enforcing | AC-3, AC-6 | 1.6.1.3 | Mandatory access control |
| Security patches | SI-2 | 1.8 | Flaw remediation |
| Snapper snapshots | CP-9, CP-10 | - | System recovery |
| Firewalld active | SC-7 | 3.5.1.1 | Boundary protection |

## Notes

- This script automatically SKIPs on non-SUSE systems
- Transactional update checks only apply to MicroOS/transactional variants
- SUSEConnect checks only apply to SLES (not openSUSE community)
- Snapper checks require BTRFS root filesystem
