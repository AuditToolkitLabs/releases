#!/usr/bin/env bash
# opensuse-specific-audit.sh — openSUSE/SUSE Linux-Specific Security Audit
#
# Compliance Mapping:
# - SUSE Security Advisories (SUSE-SU)
# - CIS SUSE Linux Enterprise Benchmark
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - Zypper configuration and patches
# - YaST security settings
# - Snapper (BTRFS snapshots)
# - AppArmor status
# - SUSEConnect (SLES)
# - Transactional updates (MicroOS)
#
# @elevation: partial
# @elevation-reason: Zypper patch queries and snapper snapshots may need root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on openSUSE/SUSE
distro=$(detect_distro)
case "$distro" in
    opensuse*|suse|sles)
        ;;
    *)
        register_check "openSUSE/SUSE detected" SKIP "running on $distro"
        print_summary
        exit "$EXIT_CODE"
        ;;
esac

section "SUSE Distribution Info"

# Get version info
suse_version=$(grep -oP 'VERSION_ID="\K[^"]+' /etc/os-release 2>/dev/null || echo "unknown")
suse_name=$(grep -oP 'NAME="\K[^"]+' /etc/os-release 2>/dev/null || echo "unknown")
register_check "Distribution" PASS "$suse_name $suse_version"

# Check if Leap, Tumbleweed, or SLES
if grep -qi "tumbleweed" /etc/os-release 2>/dev/null; then
    register_check "Release type" WARN "Tumbleweed (rolling)"
elif grep -qi "leap" /etc/os-release 2>/dev/null; then
    register_check "Release type" PASS "Leap (stable)"
elif grep -qi "sles\|enterprise" /etc/os-release 2>/dev/null; then
    register_check "Release type" PASS "SLES (enterprise)"
else
    register_check "Release type" PASS "$distro"
fi

# Check if MicroOS/transactional
if [[ -f /etc/transactional-update.conf ]] || command -v transactional-update >/dev/null 2>&1; then
    register_check "System type" PASS "transactional/immutable"
    is_transactional=true
else
    register_check "System type" PASS "traditional (mutable)"
    is_transactional=false
fi

section "Zypper Package Manager"

# Check Zypper
if command -v zypper >/dev/null 2>&1; then
    register_check "Zypper installed" PASS "yes"

    # Check GPG verification
    gpgcheck=$(zypper --non-interactive --gpg-auto-import-keys lr -d 2>/dev/null | grep -c "Yes" || echo "0")
    if [[ "$gpgcheck" -gt 0 ]]; then
        register_check "Zypper GPG check" PASS "enabled on $gpgcheck repos"
    else
        register_check "Zypper GPG check" WARN "check repo settings"
    fi

    # Check for security patches (with timeout)
    if command -v timeout >/dev/null 2>&1; then
        patches=$(timeout 15 zypper --non-interactive list-patches --category security 2>/dev/null | grep -c "needed" || true)
    else
        patches=$(zypper --non-interactive list-patches --category security 2>/dev/null | grep -c "needed" || true)
    fi
    : "${patches:=0}"

    if [[ "$patches" -eq 0 ]]; then
        register_check "Security patches" PASS "system up to date"
    elif [[ "$patches" -lt 5 ]]; then
        register_check "Security patches" WARN "$patches pending"
    else
        register_check "Security patches" FAIL "$patches pending"
    fi

    # Check zypper.conf settings
    if [[ -f /etc/zypp/zypp.conf ]]; then
        # Check solver.onlyRequires
        only_requires=$(grep -E "^solver.onlyRequires\s*=" /etc/zypp/zypp.conf 2>/dev/null | cut -d= -f2 | tr -d ' ' || true)
        if [[ "$only_requires" == "true" ]]; then
            register_check "Minimal installs" PASS "solver.onlyRequires=true"
        else
            register_check "Minimal installs" WARN "recommended packages installed"
        fi
    fi
else
    register_check "Zypper installed" FAIL "not found"
fi

section "SUSEConnect (Enterprise)"

# Check SLES registration
if command -v SUSEConnect >/dev/null 2>&1; then
    register_check "SUSEConnect installed" PASS "yes"

    # Check registration status
    reg_status=$(SUSEConnect --status 2>/dev/null | grep -c "Registered" || echo "0")
    if [[ "$reg_status" -gt 0 ]]; then
        register_check "System registration" PASS "registered"
    else
        register_check "System registration" WARN "not registered"
    fi
else
    register_check "SUSEConnect" SKIP "not installed (not SLES)"
fi

section "AppArmor Status"

# Check AppArmor (SUSE default MAC)
if command -v aa-status >/dev/null 2>&1; then
    register_check "AppArmor installed" PASS "yes"

    # Check if loaded
    if aa-status --enabled 2>/dev/null; then
        register_check "AppArmor enabled" PASS "yes"

        # Count enforced profiles
        enforced=$(aa-status 2>/dev/null | grep -oP '\d+(?= profiles are in enforce mode)' || echo "0")
        complain=$(aa-status 2>/dev/null | grep -oP '\d+(?= profiles are in complain mode)' || echo "0")

        if [[ "$enforced" -gt 0 ]]; then
            register_check "AppArmor enforcing" PASS "$enforced profiles"
        else
            register_check "AppArmor enforcing" WARN "no enforced profiles"
        fi

        if [[ "$complain" -gt 0 ]]; then
            register_check "AppArmor complain" WARN "$complain in complain mode"
        fi
    else
        register_check "AppArmor enabled" FAIL "disabled"
    fi
else
    register_check "AppArmor" WARN "not installed"
fi

section "Snapper BTRFS Snapshots"

# Check Snapper (default on openSUSE with BTRFS)
if command -v snapper >/dev/null 2>&1; then
    register_check "Snapper installed" PASS "yes"

    # Check root config
    if snapper list-configs 2>/dev/null | grep -q "root"; then
        register_check "Snapper root config" PASS "configured"

        # Count snapshots
        snap_count=$(snapper -c root list 2>/dev/null | grep -c "^\s*[0-9]" || echo "0")
        if [[ "$snap_count" -gt 0 ]]; then
            register_check "Root snapshots" PASS "$snap_count snapshots"
        else
            register_check "Root snapshots" WARN "no snapshots"
        fi

        # Check timeline settings
        if [[ -f /etc/snapper/configs/root ]]; then
            timeline=$(grep "TIMELINE_CREATE" /etc/snapper/configs/root 2>/dev/null | grep -c "yes" || echo "0")
            if [[ "$timeline" -gt 0 ]]; then
                register_check "Timeline snapshots" PASS "enabled"
            else
                register_check "Timeline snapshots" WARN "disabled"
            fi
        fi
    else
        register_check "Snapper root config" WARN "not configured"
    fi
else
    register_check "Snapper" SKIP "not installed"
fi

section "Transactional Updates"

# Check transactional-update (MicroOS, SLES transactional)
if [[ "$is_transactional" == "true" ]]; then
    if command -v transactional-update >/dev/null 2>&1; then
        register_check "transactional-update" PASS "installed"

        # Check for pending reboot
        if [[ -f /run/reboot-needed ]] || [[ -f /var/run/reboot-required ]]; then
            register_check "Pending reboot" WARN "reboot required"
        else
            register_check "Pending reboot" PASS "none"
        fi

        # Check automatic updates timer
        if systemctl is-enabled transactional-update.timer >/dev/null 2>&1; then
            register_check "Auto transactional updates" PASS "enabled"
        else
            register_check "Auto transactional updates" WARN "not enabled"
        fi
    fi
fi

section "Firewall (firewalld)"

# Check firewalld (openSUSE default)
if command -v firewall-cmd >/dev/null 2>&1; then
    if systemctl is-active firewalld >/dev/null 2>&1; then
        register_check "Firewalld" PASS "active"

        default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
        register_check "Default zone" PASS "$default_zone"
    else
        register_check "Firewalld" WARN "installed but not active"
    fi
elif command -v iptables >/dev/null 2>&1; then
    rules=$(iptables -L -n 2>/dev/null | grep -c "^Chain" || echo "0")
    if [[ "$rules" -gt 3 ]]; then
        register_check "Firewall (iptables)" PASS "configured"
    else
        register_check "Firewall" WARN "minimal rules"
    fi
else
    register_check "Firewall" FAIL "none detected"
fi

section "YaST Security"

# Check YaST security module settings if available
if command -v yast2 >/dev/null 2>&1; then
    register_check "YaST installed" PASS "yes"

    # Check security settings file
    if [[ -f /etc/sysconfig/security ]]; then
        # Check permission security level
        perm_security=$(grep "PERMISSION_SECURITY" /etc/sysconfig/security 2>/dev/null | cut -d= -f2 | tr -d '"' || true)
        : "${perm_security:=easy}"
        case "$perm_security" in
            paranoid)
                register_check "Permission security" PASS "paranoid"
                ;;
            secure)
                register_check "Permission security" PASS "secure"
                ;;
            easy|"")
                register_check "Permission security" WARN "easy (default)"
                ;;
            *)
                register_check "Permission security" WARN "$perm_security"
                ;;
        esac
    fi
else
    register_check "YaST" SKIP "not installed"
fi

section "Kernel Security"

# Check kernel lockdown
if [[ -f /sys/kernel/security/lockdown ]]; then
    lockdown=$(cat /sys/kernel/security/lockdown 2>/dev/null | tr -d '[]')
    case "$lockdown" in
        *integrity*)
            register_check "Kernel lockdown" PASS "integrity"
            ;;
        *confidentiality*)
            register_check "Kernel lockdown" PASS "confidentiality"
            ;;
        *none*)
            register_check "Kernel lockdown" WARN "none"
            ;;
        *)
            register_check "Kernel lockdown" WARN "$lockdown"
            ;;
    esac
else
    register_check "Kernel lockdown" SKIP "not available"
fi

# Check Secure Boot
if [[ -d /sys/firmware/efi ]]; then
    if command -v mokutil >/dev/null 2>&1; then
        sb_state=$(mokutil --sb-state 2>/dev/null | head -1 || echo "unknown")
        if echo "$sb_state" | grep -qi "enabled"; then
            register_check "Secure Boot" PASS "enabled"
        else
            register_check "Secure Boot" WARN "disabled"
        fi
    else
        register_check "Secure Boot" SKIP "mokutil not available"
    fi
else
    register_check "Secure Boot" SKIP "legacy BIOS"
fi

section "Summary"

# Overall assessment
failed_count=$FAILED_CHECKS
warn_count=$WARNING_CHECKS

if [[ "$failed_count" -eq 0 ]] && [[ "$warn_count" -lt 3 ]]; then
    register_check "openSUSE security posture" PASS "good"
elif [[ "$failed_count" -eq 0 ]]; then
    register_check "openSUSE security posture" WARN "review warnings"
else
    register_check "openSUSE security posture" FAIL "issues detected"
fi

print_summary
exit "$EXIT_CODE"
