# RHEL-Specific Audits

This folder contains audits specific to Red Hat Enterprise Linux distributions.

## Implemented Audits

| Script | Description | Status |
|--------|-------------|--------|
| `rhel-specific-audit.sh` | Comprehensive RHEL security audit | ✅ Complete |

### Checks Included

- RHEL version and subscription status
- SELinux enforcement and policy
- DNF/YUM security configuration
- Red Hat Insights client status
- FIPS mode verification
- RHEL-specific security updates

## Supported Versions

- RHEL 7.x, 8.x, 9.x
- CentOS Stream, Rocky Linux, AlmaLinux, Oracle Linux

## Usage

`bash audits/linux/platform/rhel/rhel-specific-audit.sh`
