#!/usr/bin/env bash
# rhel-specific-audit.sh — RHEL/CentOS-Specific Security Audit
#
# Compliance Mapping:
# - CIS Red Hat Enterprise Linux Benchmark
# - DISA STIG for RHEL
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - SELinux enforcement
# - Subscription status
# - DNF automatic updates
# - Red Hat Insights
# - FIPS mode
# - Cockpit security
#
# @elevation: partial
# @elevation-reason: Subscription status and some dnf queries require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on RHEL/CentOS/Rocky/Alma
distro=$(detect_distro)
case "$distro" in
  rhel|centos|rocky|almalinux|fedora)
    ;;
  *)
    register_check "RHEL-family detected" SKIP "running on $distro"
    print_summary
    exit "$EXIT_CODE"
    ;;
esac

section "RHEL Distribution Info"

# Get version info
rhel_version=$(grep -oP 'VERSION_ID="\K[^"]+' /etc/os-release 2>/dev/null || echo "unknown")
register_check "Version" PASS "$distro $rhel_version"

# Check if on RHEL vs clone
if [[ -f /etc/redhat-release ]]; then
  release_info=$(cat /etc/redhat-release)
  register_check "Release" PASS "$release_info"
fi

# Check major version (7, 8, 9)
major_version=$(echo "$rhel_version" | cut -d. -f1)
register_check "Major version" PASS "$major_version"

section "SELinux Status"

# Check SELinux
if command -v getenforce >/dev/null 2>&1; then
  register_check "SELinux installed" PASS "yes"

  selinux_mode=$(getenforce 2>/dev/null || echo "unknown")
  case "$selinux_mode" in
    Enforcing)
      register_check "SELinux mode" PASS "enforcing"
      ;;
    Permissive)
      register_check "SELinux mode" WARN "permissive"
      ;;
    Disabled)
      register_check "SELinux mode" FAIL "disabled"
      ;;
    *)
      register_check "SELinux mode" WARN "$selinux_mode"
      ;;
  esac

  # Check SELinux config
  if [[ -f /etc/selinux/config ]]; then
    selinux_config=$(grep -E "^SELINUX=" /etc/selinux/config | cut -d= -f2)
    if [[ "$selinux_config" == "enforcing" ]]; then
      register_check "SELinux config" PASS "enforcing"
    elif [[ "$selinux_config" == "permissive" ]]; then
      register_check "SELinux config" WARN "permissive at boot"
    else
      register_check "SELinux config" FAIL "$selinux_config"
    fi

    selinux_type=$(grep -E "^SELINUXTYPE=" /etc/selinux/config | cut -d= -f2)
    register_check "SELinux type" PASS "${selinux_type:-targeted}"
  fi

  # Check for SELinux denials
  if command -v ausearch >/dev/null 2>&1; then
    denials=$(ausearch -m avc --start today 2>/dev/null | grep -c "type=AVC" || echo "0")
    if [[ "$denials" -eq 0 ]]; then
      register_check "SELinux denials (today)" PASS "none"
    else
      register_check "SELinux denials (today)" WARN "$denials"
    fi
  fi

  # Check for permissive domains
  if command -v semanage >/dev/null 2>&1; then
    permissive_domains=$(semanage permissive -l 2>/dev/null | grep -v "^Builtin" | wc -l || echo "0")
    if [[ "$permissive_domains" -eq 0 ]]; then
      register_check "Permissive domains" PASS "none"
    else
      register_check "Permissive domains" WARN "$permissive_domains"
    fi
  fi
else
  register_check "SELinux installed" FAIL "not found"
fi

section "Subscription Status"

# Check subscription-manager
if command -v subscription-manager >/dev/null 2>&1; then
  register_check "Subscription-manager" PASS "installed"

  # Check subscription status
  sub_status=$(subscription-manager status 2>/dev/null || echo "")
  if echo "$sub_status" | grep -qE "Overall Status: Current"; then
    register_check "Subscription" PASS "current"
  elif echo "$sub_status" | grep -qE "Overall Status:"; then
    status=$(echo "$sub_status" | grep -oP "Overall Status:\s*\K.*")
    register_check "Subscription" WARN "$status"
  else
    register_check "Subscription" WARN "unknown"
  fi

  # Check for repos
  enabled_repos=$(subscription-manager repos --list-enabled 2>/dev/null | grep -c "Repo ID:" || echo "0")
  register_check "Enabled repos" PASS "$enabled_repos"

  # Check for EUS (Extended Update Support)
  if subscription-manager repos --list 2>/dev/null | grep -qE "eus"; then
    register_check "EUS repos" PASS "available"
  fi
else
  # May be CentOS/Rocky/Alma without subscription-manager
  register_check "Subscription-manager" WARN "not installed (clone?)"
fi

section "Automatic Updates"

# Check dnf-automatic (RHEL 8+) or yum-cron (RHEL 7)
if [[ "$major_version" -ge 8 ]]; then
  # DNF automatic
  if rpm -q dnf-automatic >/dev/null 2>&1; then
    register_check "dnf-automatic" PASS "installed"

    # Check timer
    if systemctl is-enabled dnf-automatic.timer >/dev/null 2>&1; then
      register_check "dnf-automatic timer" PASS "enabled"

      if systemctl is-active dnf-automatic.timer >/dev/null 2>&1; then
        register_check "dnf-automatic timer" PASS "active"
      else
        register_check "dnf-automatic timer" WARN "not running"
      fi
    else
      register_check "dnf-automatic timer" WARN "not enabled"
    fi

    # Check configuration
    dnf_auto_conf="/etc/dnf/automatic.conf"
    if [[ -f "$dnf_auto_conf" ]]; then
      apply_updates=$(grep -E "^apply_updates" "$dnf_auto_conf" | cut -d= -f2 | tr -d ' ')
      if [[ "$apply_updates" == "yes" ]]; then
        register_check "Auto apply updates" PASS "yes"
      else
        register_check "Auto apply updates" WARN "no"
      fi

      upgrade_type=$(grep -E "^upgrade_type" "$dnf_auto_conf" | cut -d= -f2 | tr -d ' ')
      register_check "Upgrade type" PASS "${upgrade_type:-default}"
    fi
  else
    register_check "dnf-automatic" WARN "not installed"
  fi
else
  # yum-cron for RHEL 7
  if rpm -q yum-cron >/dev/null 2>&1; then
    register_check "yum-cron" PASS "installed"

    if systemctl is-enabled yum-cron >/dev/null 2>&1; then
      register_check "yum-cron service" PASS "enabled"
    else
      register_check "yum-cron service" WARN "not enabled"
    fi
  else
    register_check "yum-cron" WARN "not installed"
  fi
fi

section "Red Hat Insights"

# Check Insights client
if command -v insights-client >/dev/null 2>&1; then
  register_check "Insights client" PASS "installed"

  # Check registration
  insights_status=$(insights-client --status 2>/dev/null || echo "")
  if echo "$insights_status" | grep -qE "registered"; then
    register_check "Insights registered" PASS "yes"
  else
    register_check "Insights registered" WARN "not registered"
  fi

  # Check last check-in
  if [[ -f /etc/insights-client/.lastupload ]]; then
    last_upload=$(cat /etc/insights-client/.lastupload 2>/dev/null || echo "unknown")
    register_check "Last Insights upload" PASS "$last_upload"
  fi
else
  register_check "Insights client" WARN "not installed"
fi

section "FIPS Mode"

# Check FIPS
fips_enabled=$(cat /proc/sys/crypto/fips_enabled 2>/dev/null || echo "0")
if [[ "$fips_enabled" == "1" ]]; then
  register_check "FIPS mode" PASS "enabled"

  # Check FIPS packages
  if rpm -q fips-mode-setup >/dev/null 2>&1 || rpm -q dracut-fips >/dev/null 2>&1; then
    register_check "FIPS packages" PASS "installed"
  fi
else
  register_check "FIPS mode" WARN "disabled"
fi

# Check crypto policies (RHEL 8+)
if [[ "$major_version" -ge 8 ]]; then
  if command -v update-crypto-policies >/dev/null 2>&1; then
    crypto_policy=$(update-crypto-policies --show 2>/dev/null || echo "unknown")
    case "$crypto_policy" in
      FIPS)
        register_check "Crypto policy" PASS "FIPS"
        ;;
      FUTURE)
        register_check "Crypto policy" PASS "FUTURE"
        ;;
      DEFAULT)
        register_check "Crypto policy" PASS "DEFAULT"
        ;;
      LEGACY)
        register_check "Crypto policy" WARN "LEGACY"
        ;;
      *)
        register_check "Crypto policy" PASS "$crypto_policy"
        ;;
    esac
  fi
fi

section "Cockpit Security"

# Check Cockpit
if rpm -q cockpit >/dev/null 2>&1; then
  register_check "Cockpit installed" PASS "yes"

  # Check service status
  if systemctl is-active cockpit.socket >/dev/null 2>&1; then
    register_check "Cockpit socket" WARN "active (review access)"
  else
    register_check "Cockpit socket" PASS "not active"
  fi

  # Check TLS configuration
  cockpit_conf="/etc/cockpit/cockpit.conf"
  if [[ -f "$cockpit_conf" ]]; then
    # Check for AllowUnencrypted
    if grep -qE "AllowUnencrypted\s*=\s*true" "$cockpit_conf"; then
      register_check "Cockpit TLS" FAIL "allows unencrypted"
    else
      register_check "Cockpit TLS" PASS "required"
    fi

    # Check origins
    if grep -qE "Origins" "$cockpit_conf"; then
      register_check "Cockpit Origins" PASS "configured"
    fi
  fi

  # Check certificate
  cockpit_cert="/etc/cockpit/ws-certs.d"
  if [[ -d "$cockpit_cert" ]] && ls "$cockpit_cert"/*.cert >/dev/null 2>&1; then
    register_check "Cockpit certificate" PASS "configured"
  fi
else
  register_check "Cockpit installed" PASS "not installed"
fi

section "Security Features"

# Check firewalld
if systemctl is-active firewalld >/dev/null 2>&1; then
  register_check "Firewalld" PASS "active"

  default_zone=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
  register_check "Default zone" PASS "$default_zone"
else
  register_check "Firewalld" WARN "not active"
fi

# Check fail2ban
if systemctl is-active fail2ban >/dev/null 2>&1; then
  register_check "Fail2ban" PASS "active"
elif rpm -q fail2ban >/dev/null 2>&1; then
  register_check "Fail2ban" WARN "installed but not running"
fi

# Check AIDE
if rpm -q aide >/dev/null 2>&1; then
  register_check "AIDE" PASS "installed"

  if [[ -f /var/lib/aide/aide.db.gz ]]; then
    register_check "AIDE database" PASS "initialized"
  else
    register_check "AIDE database" WARN "not initialized"
  fi
fi

section "Pending Updates"

# Check for pending updates
if [[ "$major_version" -ge 8 ]]; then
  pending_security=$(dnf updateinfo list security 2>/dev/null | wc -l || echo "0")
else
  pending_security=$(yum updateinfo list security 2>/dev/null | wc -l || echo "0")
fi

if [[ "$pending_security" -gt 0 ]]; then
  register_check "Pending security updates" WARN "$pending_security"
else
  register_check "Pending security updates" PASS "none"
fi

# Check for reboot required (kexec/systemd)
if [[ -f /var/run/reboot-required ]] || needs-restarting -r >/dev/null 2>&1; then
  register_check "Reboot required" WARN "yes"
else
  register_check "Reboot required" PASS "no"
fi

print_summary
exit "$EXIT_CODE"
