#!/usr/bin/env bash
# Install simple cron entries when systemd is unavailable
#
# @elevation: root
# @elevation-reason: Requires root to install cron jobs in /etc/cron.*
#
set -euo pipefail
LOG_DIR="/var/log/security-audit"
usage(){ echo "Usage: ${0##*/} [--log-dir DIR]"; }
while [[ $# -gt 0 ]]; do case "$1" in --log-dir) LOG_DIR="$2"; shift 2;; -h|--help) usage; exit 0;; *) shift;; esac; done
mkdir -p "$LOG_DIR"
BASE="$(cd "$(dirname "$0")" && pwd)"
install_job(){ local name="$1" cmd="$2" when="$3"; local f="/etc/cron.${when}/${name}"; printf '#!/bin/sh
%s >> %s/%s.log 2>&1
' "$cmd" "$LOG_DIR" "$name" > "$f"; chmod +x "$f"; echo "Installed $f"; }
install_job nginx-security-audit  "${BASE}/nginx-security-audit.sh"   daily
install_job apache-security-audit "${BASE}/apache-security-audit.sh"  daily
install_job php-fpm-audit        "${BASE}/php-fpm-audit.sh"          daily
install_job archive-storage-audit "${BASE}/archive-storage-audit.sh" weekly
# Note: cdn-headers-audit requires URL; create a placeholder in cron.weekly
printf '#!/bin/sh
# Edit to add --url
%s --url https://example.com >> %s/cdn-headers-audit.log 2>&1
' "${BASE}/cdn-headers-audit.sh" "$LOG_DIR" > /etc/cron.weekly/cdn-headers-audit
chmod +x /etc/cron.weekly/cdn-headers-audit
