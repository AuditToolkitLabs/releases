#!/usr/bin/env bash
# Install systemd services & timers for periodic audits
#
# @elevation: root
# @elevation-reason: Requires root to install systemd units and enable timers
#
set -euo pipefail
LOG_DIR="/var/log/security-audit"
usage() { echo "Usage: ${0##*/} [--log-dir DIR]"; }
while [[ $# -gt 0 ]]; do case "$1" in --log-dir)
  LOG_DIR="$2"
  shift 2
  ;;
-h | --help)
  usage
  exit 0
  ;;
*) shift ;; esac done
mkdir -p "$LOG_DIR"
BASE="$(cd "$(dirname "$0")" && pwd)"
install_unit() {
  local name="$1"
  local cmd="$2"
  local cal="$3"
  cat >"/etc/systemd/system/${name}.service" <<UNIT
[Unit]
Description=${name}

[Service]
Type=oneshot
ExecStart=${cmd}
StandardOutput=append:${LOG_DIR}/${name}.log
StandardError=append:${LOG_DIR}/${name}.log
UNIT
  cat >"/etc/systemd/system/${name}.timer" <<TIMER
[Unit]
Description=Timer for ${name}

[Timer]
OnCalendar=${cal}
Persistent=true

[Install]
WantedBy=timers.target
TIMER
  systemctl daemon-reload
  systemctl enable --now "${name}.timer"
}
# Create timers (daily by default)
[[ -x "$BASE/nginx-security-audit.sh" ]] && install_unit nginx-security-audit "${BASE}/nginx-security-audit.sh --log ${LOG_DIR}/nginx-audit.log" 'daily'
[[ -x "$BASE/apache-security-audit.sh" ]] && install_unit apache-security-audit "${BASE}/apache-security-audit.sh --log ${LOG_DIR}/apache-audit.log" 'daily'
[[ -x "$BASE/php-fpm-audit.sh" ]] && install_unit php-fpm-audit "${BASE}/php-fpm-audit.sh --log ${LOG_DIR}/php-fpm-audit.log" 'daily'
[[ -x "$BASE/archive-storage-audit.sh" ]] && install_unit archive-storage-audit "${BASE}/archive-storage-audit.sh --log ${LOG_DIR}/archive-audit.log" 'weekly'
# CDN headers: requires URL; create a template example
if [[ -x "$BASE/cdn-headers-audit.sh" ]]; then
  echo "# Edit ExecStart to add --url before enabling:" >/etc/systemd/system/cdn-headers-audit.service
  cat >>/etc/systemd/system/cdn-headers-audit.service <<UNIT
[Unit]
Description=cdn-headers-audit

[Service]
Type=oneshot
ExecStart=${BASE}/cdn-headers-audit.sh --url https://example.com
StandardOutput=append:${LOG_DIR}/cdn-audit.log
StandardError=append:${LOG_DIR}/cdn-audit.log
UNIT
  cat >/etc/systemd/system/cdn-headers-audit.timer <<TIMER
[Unit]
Description=Timer for cdn-headers-audit

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
TIMER
  systemctl daemon-reload
  echo "Timer created: edit service ExecStart to set your --url, then: systemctl enable --now cdn-headers-audit.timer"
fi
