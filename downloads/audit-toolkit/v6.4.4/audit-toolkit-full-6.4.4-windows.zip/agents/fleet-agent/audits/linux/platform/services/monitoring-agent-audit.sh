#
# Monitoring Agent & Resource Audit
#
# Compliance Mapping:
# - CIS Controls: 8.1, 8.2, 16.11
# - NIST SP 800-53: AU-2, AU-6, SI-4
# - ISO 27001: A.12.4, A.13.1
# - OWASP ASVS: V10
# - UK NCSC: Logging and Monitoring, Availability
# - PCI DSS: 10.2, 10.3
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# Monitoring Agent & Resource Audit (portable)
#
# @elevation: partial
# @elevation-reason: Agent service status checks may require elevated privileges
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly DISK_WARN_PERCENT=80
readonly DISK_CRIT_PERCENT=90
readonly MEM_WARN_PERCENT=85
LOG_FILE="$DEFAULT_LOG_FILE"
QUIET=false
VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
MOUNTS_CSV=""

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  GREEN=$'\e[0;32m'
  YELLOW=$'\e[0;33m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local level="$1"
  shift || true
  local msg="$*"
  local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ "$QUIET" != "true" ]] && echo "$line"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >>"$LOG_FILE" 2>/dev/null || :; }
}
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0
SKIPPED_CHECKS=0
register_check() {
  local n="$1" r="$2" m="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
  case "$r" in PASS)
    ((++PASSED_CHECKS))
    echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}"
    ;;
  FAIL)
    ((++FAILED_CHECKS))
    EXIT_CODE=2
    echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}"
    ;;
  WARN)
    ((++WARNING_CHECKS))
    [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1
    echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}"
    ;;
  SKIP)
    ((++SKIPPED_CHECKS))
    echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}"
    ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >>"$LOG_FILE" 2>/dev/null || true
}
section() {
  local t="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $t${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && {
    echo
    echo "=== $t ==="
  } >>"$LOG_FILE" 2>/dev/null || :
}

# --- audits ---
audit_agents() {
  section "Monitoring Agents"
  local -a agents=(
    'prometheus-node-exporter:Prometheus Node Exporter'
    'telegraf:Telegraf'
    'datadog-agent:Datadog Agent'
    'collectd:collectd'
    'netdata:Netdata'
    'zabbix-agent:Zabbix Agent'
    'zabbix-agent2:Zabbix Agent 2'
    'newrelic-infra:New Relic Infrastructure'
    'filebeat:Filebeat'
    'metricbeat:Metricbeat'
    'nrpe:Nagios NRPE'
    'nagios-nrpe-server:Nagios NRPE Server'
    'icinga2:Icinga 2'
    'centreon-engine:Centreon Engine'
    'centengine:Centreon Engine (alt)'
  )
  local found=0
  local item name disp
  for item in "${agents[@]}"; do
    name="${item%%:*}"
    disp="${item#*:}"
    if svc_is_enabled "$name"; then
      if svc_is_active "$name"; then
        register_check "Agent: $disp ($name)" PASS "enabled & running"
        ((found++))
      else register_check "Agent: $disp ($name)" WARN "enabled but not running"; fi
    elif svc_is_active "$name"; then
      register_check "Agent: $disp ($name)" PASS "running (not enabled)"
      ((found++))
    else
      # heuristic: try process name
      if pgrep -af "$name" >/dev/null 2>&1; then
        register_check "Agent: $disp ($name)" PASS "process present"
        ((found++))
      else register_check "Agent: $disp ($name)" SKIP "not present/inactive"; fi
    fi
  done
  if [[ "$found" -gt 0 ]]; then
    register_check "Agents detected" PASS "$found"
  else
    register_check "Agents detected" WARN "none"
  fi
}

audit_memory() {
  section "Memory"
  if ! command -v free >/dev/null 2>&1; then register_check "free tool" FAIL "not available"; else
    local line total used percent
    line=$(free | grep Mem || true)
    if [[ -n "$line" ]]; then
      total=$(awk '{print $2}' <<<"$line")
      used=$(awk '{print $3}' <<<"$line")
      if [[ ${total:-0} -gt 0 ]]; then
        percent=$((used * 100 / total))
        if [[ $percent -ge $MEM_WARN_PERCENT ]]; then register_check "Memory usage" WARN "${percent}% (>= ${MEM_WARN_PERCENT}%)"; else register_check "Memory usage" PASS "${percent}%"; fi
      else register_check "Memory usage" SKIP "unknown"; fi
    else register_check "Memory usage" SKIP "unable to query"; fi
  fi
  local sline stotal sused
  sline=$(free | grep Swap || true)
  if [[ -n "$sline" ]]; then
    stotal=$(awk '{print $2}' <<<"$sline")
    sused=$(awk '{print $3}' <<<"$sline")
    if [[ ${stotal:-0} -eq 0 ]]; then register_check "Swap" PASS "not configured"; elif [[ ${sused:-0} -gt 0 ]]; then
      local sperc=$((sused * 100 / stotal))
      register_check "Swap" PASS "in use: ${sperc}%"
    else register_check "Swap" PASS "configured, not in use"; fi
  fi
}

audit_cpu() {
  section "CPU Load"
  if [[ ! -f /proc/loadavg ]]; then
    register_check "/proc/loadavg" FAIL "not available"
    return 0
  fi
  local load1 cores
  load1=$(awk '{print $1}' /proc/loadavg 2>/dev/null || echo 0)
  cores=$(nproc 2>/dev/null || echo 1)
  local lint="${load1%%.*}"
  if [[ ${lint:-0} -ge ${cores:-1} ]]; then register_check "Load (1m)" WARN "$load1 >= $cores cores"; else register_check "Load (1m)" PASS "$load1 < $cores cores"; fi
  [[ "$VERBOSE" == "true" ]] && {
    _log DEBUG "Top 5 CPU consumers:"
    ps aux --sort=-%cpu 2>/dev/null | head -n 6 | while read -r l; do _log DEBUG " $l"; done
  }
}

audit_disk() {
  section "Disk Usage"
  local out
  out=$(df -PhT 2>/dev/null | awk 'NR==1 || ($2!="tmpfs" && $2!="devtmpfs" && $2!="overlay" && $2!="squashfs")')
  if [[ -z "$out" ]]; then
    register_check "Filesystem usage" WARN "unable to query"
    return 0
  fi
  local header=true anyw=0 anyc=0 line
  while read -r line; do
    if $header; then
      header=false
      continue
    fi
    local use mp
    use=$(awk '{print $6}' <<<"$line" | tr -d '%')
    mp=$(awk '{print $7}' <<<"$line")
    [[ "$use" =~ ^[0-9]+$ ]] || continue
    if [[ $use -ge $DISK_CRIT_PERCENT ]]; then
      register_check "FS usage: $mp" FAIL "${use}% (>= ${DISK_CRIT_PERCENT}%)"
      anyc=$((anyc + 1))
    elif [[ $use -ge $DISK_WARN_PERCENT ]]; then
      register_check "FS usage: $mp" WARN "${use}% (>= ${DISK_WARN_PERCENT}%)"
      anyw=$((anyw + 1))
    else register_check "FS usage: $mp" PASS "${use}%"; fi
  done <<<"$out"
  if [[ $anyc -eq 0 && $anyw -eq 0 ]]; then register_check "Filesystems over threshold" PASS "none"; elif [[ $anyc -gt 0 ]]; then register_check "Filesystems over threshold" FAIL "$anyw warn / $anyc crit"; else register_check "Filesystems over threshold" WARN "$anyw warn"; fi
}

audit_inodes() {
  section "Inode Usage"
  local out
  out=$(df -Pi 2>/dev/null | awk 'NR==1 || ($1!="tmpfs" && $1!="devtmpfs" && $1!="overlay" && $1!="squashfs")')
  if [[ -z "$out" ]]; then
    register_check "Inode usage" SKIP "unable to query"
    return 0
  fi
  local header=true cnt=0 line
  while read -r line; do
    if $header; then
      header=false
      continue
    fi
    local iuse mp
    iuse=$(awk '{print $5}' <<<"$line" | tr -d '%')
    mp=$(awk '{print $6}' <<<"$line")
    [[ "$iuse" =~ ^[0-9]+$ ]] && [[ $iuse -ge 80 ]] && {
      register_check "Inodes: $mp" WARN "${iuse}%"
      cnt=$((cnt + 1))
    }
  done <<<"$out"
  if [[ $cnt -eq 0 ]]; then
    register_check "Inodes over threshold" PASS "none"
  else
    register_check "Inodes over threshold" WARN "$cnt FS >= 80%"
  fi
}

export_mounts_csv() {
  [[ -n "$MOUNTS_CSV" ]] || {
    register_check "Mounts CSV export" SKIP "no path"
    return 0
  }
  section "Mounts CSV Export"
  local tmp
  tmp="$(mktemp)"
  printf '%s
' 'timestamp_iso,device,device_uuid,mountpoint,fstype,mount_opts,used_percent,size_total_bytes,size_used_bytes,size_avail_bytes,size_total_hr,size_used_hr,size_avail_hr,inodes_total,inodes_used,inodes_avail,inodes_used_percent' >"$tmp"
  local TS
  TS="$(date -Iseconds)"
  declare -A USEMAP_HR SIZETOTAL_HR SIZEUSED_HR SIZEAVAIL_HR
  declare -A SIZETOTAL_B SIZEUSED_B SIZEAVAIL_B
  declare -A ITOTAL IUSED IAVAIL IUSEP
  while read -r _ _ sz used avail usep mnt; do
    USEMAP_HR["$mnt"]="$usep"
    SIZETOTAL_HR["$mnt"]="$sz"
    SIZEUSED_HR["$mnt"]="$used"
    SIZEAVAIL_HR["$mnt"]="$avail"
  done < <(df -PhT 2>/dev/null | awk 'NR>1 {print $1, $2, $3, $4, $5, $6, $7}')
  while read -r _ blocks used avail _ mnt; do
    SIZETOTAL_B["$mnt"]="$blocks"
    SIZEUSED_B["$mnt"]="$used"
    SIZEAVAIL_B["$mnt"]="$avail"
  done < <(df -P -B1 2>/dev/null | awk 'NR>1 {print $1, $2, $3, $4, $5, $6}')
  while read -r _ itotal iused iavail iusep mnt; do
    ITOTAL["$mnt"]="$itotal"
    IUSED["$mnt"]="$iused"
    IAVAIL["$mnt"]="$iavail"
    IUSEP["$mnt"]="$iusep"
  done < <(df -Pi 2>/dev/null | awk 'NR>1 {print $1, $2, $3, $4, $5, $6}')
  while IFS= read -r line; do
    line="${line//\040/ }"
    read -r filesystem mountpoint fstype opts _ <<<"$line"
    case "$fstype" in proc | sysfs | devtmpfs | devpts | cgroup* | pstore | efivarfs | tmpfs | overlay | squashfs | ramfs) continue ;; esac
    local used="${USEMAP_HR[$mountpoint]:---}" stotal_hr="${SIZETOTAL_HR[$mountpoint]:---}" sused_hr="${SIZEUSED_HR[$mountpoint]:---}" savail_hr="${SIZEAVAIL_HR[$mountpoint]:---}" stotal_b="${SIZETOTAL_B[$mountpoint]:---}" sused_b="${SIZEUSED_B[$mountpoint]:---}" savail_b="${SIZEAVAIL_B[$mountpoint]:---}" itotal="${ITOTAL[$mountpoint]:---}" iused="${IUSED[$mountpoint]:---}" iavail="${IAVAIL[$mountpoint]:---}" iusep="${IUSEP[$mountpoint]:---}" dev_uuid='-'
    if [[ $filesystem == /dev/* ]]; then dev_uuid=$(blkid -s UUID -o value -- "$filesystem" 2>/dev/null || echo '-'); fi
    opts_esc="${opts//\"/}"
    printf '%s,%s,%s,%s,%s,"%s",%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
' "$TS" "$filesystem" "$dev_uuid" "$mountpoint" "$fstype" "$opts_esc" "$used" "$stotal_b" "$sused_b" "$savail_b" "$stotal_hr" "$sused_hr" "$savail_hr" "$itotal" "$iused" "$iavail" "$iusep" >>"$tmp"
  done </proc/mounts
  if mv -f -- "$tmp" "$MOUNTS_CSV" 2>/dev/null; then register_check "Mounts CSV export" PASS "$MOUNTS_CSV"; else register_check "Mounts CSV export" FAIL "unable to write $MOUNTS_CSV"; fi
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Monitoring & resources audit (portable)
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug output
      --mounts-csv FILE  Export mounted filesystem summary to CSV
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}
version() { echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary() {
  echo
  echo -e "${BOLD}MONITORING / RESOURCES SUMMARY${NC}"
  printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"
}

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="${2:-$DEFAULT_LOG_FILE}"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    --mounts-csv)
      MOUNTS_CSV="${2:-}"
      shift 2
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done
  setup_colors
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    touch "$LOG_FILE" 2>/dev/null || true
  }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  audit_agents
  audit_memory
  audit_cpu
  audit_disk
  audit_inodes
  export_mounts_csv
  print_summary
  exit "$EXIT_CODE"
}
main "$@"
