# Slackware Linux Audit Scripts

This directory contains Slackware-specific security audits that leverage
Slackware's unique features including pkgtools package management, BSD-style
init system, and manual configuration philosophy.

## Scripts

| Script | Description | CIS Reference |
|--------|-------------|---------------|
| `slackware-specific-audit.sh` | Core Slackware hardening checks | Custom |

## Slackware-Specific Considerations

### Package Management

Slackware uses **pkgtools** for package management with no automatic dependency
resolution by design. Additional tools:

- **pkgtools** - Core tools: `installpkg`, `removepkg`, `upgradepkg`
- **slackpkg** - Official mirror sync and updates
- **sbopkg** - SlackBuilds.org package builder
- **slapt-get** - APT-like frontend (optional)

Security features checked:

- GPG signature verification (`CHECKGPG=on`)
- MD5 checksum verification (`CHECKMD5=on`)
- HTTPS mirror usage
- Package database freshness

### Init System

Slackware uses **BSD-style init** with rc scripts:

| Script | Purpose |
|--------|---------|
| `/etc/rc.d/rc.S` | System initialization |
| `/etc/rc.d/rc.M` | Multi-user mode |
| `/etc/rc.d/rc.K` | Single-user mode |
| `/etc/rc.d/rc.local` | Local customizations |
| `/etc/rc.d/rc.inet1` | Network interfaces |
| `/etc/rc.d/rc.inet2` | Network services |

Services are enabled/disabled by setting the executable bit:

```bash
# Enable a service
chmod +x /etc/rc.d/rc.sshd

# Disable a service
chmod -x /etc/rc.d/rc.httpd
```

### Network Configuration

Network settings in Slackware:

- `/etc/rc.d/rc.inet1.conf` - Interface configuration (IP, netmask, gateway)
- `/etc/rc.d/rc.inet2` - Network daemon startup
- `/etc/rc.d/rc.firewall` - Custom firewall rules (create if needed)
- `/etc/hosts.allow`, `/etc/hosts.deny` - TCP Wrappers

### Bootloader

Slackware traditionally uses **LILO**, though GRUB is also supported:

```bash
# LILO password protection (in /etc/lilo.conf)
password=yourpassword
restricted
```

## Running Audits

```bash
# Run Slackware-specific audit
sudo bash audits/linux/platform/slackware/slackware-specific-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --match slackware
```

## Security Recommendations

1. **Enable slackpkg GPG verification** in `/etc/slackpkg/slackpkg.conf`
2. **Use HTTPS mirrors** for package downloads
3. **Disable unnecessary rc.d services** with `chmod -x`
4. **Create /etc/rc.d/rc.firewall** with iptables rules
5. **Configure TCP Wrappers** with default deny in hosts.deny
6. **Protect LILO/GRUB** with password
7. **Install security tools**: tripwire/aide, fail2ban, rkhunter

## References

- [Slackware Documentation](https://docs.slackware.com/)
- [Slackware Security](https://www.slackware.com/security/)
- [SlackBuilds.org](https://slackbuilds.org/)
- [Slackware Package Browser](https://packages.slackware.com/)
