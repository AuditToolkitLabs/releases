#!/usr/bin/env bash
# =============================================================================
# Slackware Linux Specific Security Audit
# =============================================================================
# CIS Reference: Custom (no official CIS Slackware benchmark)
# NIST SP 800-53: CM-6, CM-7, SI-2, AC-3
#
# Audits Slackware-specific security configurations:
# - pkgtools and slackpkg configuration
# - BSD-style init system (rc.d scripts)
# - Network configuration (rc.inet1, rc.inet2)
# - Slackware security hardening
# - Kernel and boot security
# =============================================================================
#
# @elevation: partial
# @elevation-reason: Package database and some security config checks need root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../../../lib/common.sh
. "${SCRIPT_DIR}/../../../../lib/common.sh"
# shellcheck source=../../../../lib/distro.sh
. "${SCRIPT_DIR}/../../../../lib/distro.sh"
# shellcheck source=../../../../lib/pkg.sh
. "${SCRIPT_DIR}/../../../../lib/pkg.sh"

# =============================================================================
# Slackware Detection
# =============================================================================

check_slackware() {
    local distro
    distro=$(detect_distro)

    if [[ "$distro" != "slackware" ]]; then
        echo "[SKIP] This audit is for Slackware Linux only (detected: $distro)"
        exit 0
    fi

    # Get Slackware version
    if [[ -f /etc/slackware-version ]]; then
        SLACKWARE_VERSION=$(cat /etc/slackware-version)
        echo "[INFO] Detected: $SLACKWARE_VERSION"
    fi
}

# =============================================================================
# Package Management Security (pkgtools, slackpkg)
# =============================================================================

section "Slackware Package Management Security"

audit_pkgtools() {
    # Check pkgtools availability
    if command -v installpkg >/dev/null 2>&1; then
        register_check "pkgtools_available" PASS "pkgtools (installpkg/removepkg) available"
    else
        register_check "pkgtools_available" FAIL "pkgtools not found"
        return
    fi

    # Check slackpkg configuration
    local slackpkg_conf="/etc/slackpkg/slackpkg.conf"
    if [[ -f "$slackpkg_conf" ]]; then
        register_check "slackpkg_installed" PASS "slackpkg configuration found"

        # Check if GPG verification is enabled
        if grep -q "^CHECKGPG=on" "$slackpkg_conf" 2>/dev/null; then
            register_check "slackpkg_gpg" PASS "GPG signature verification enabled"
        else
            register_check "slackpkg_gpg" WARN "GPG signature verification not enabled (CHECKGPG=on)"
        fi

        # Check if MD5 verification is enabled
        if grep -q "^CHECKMD5=on" "$slackpkg_conf" 2>/dev/null; then
            register_check "slackpkg_md5" PASS "MD5 checksum verification enabled"
        else
            register_check "slackpkg_md5" WARN "MD5 checksum verification not enabled"
        fi

        # Check mirror configuration (should use HTTPS)
        local mirrors_file="/etc/slackpkg/mirrors"
        if [[ -f "$mirrors_file" ]]; then
            local active_mirror
            active_mirror=$(grep -v '^#' "$mirrors_file" | grep -v '^$' | head -1)
            if [[ -n "$active_mirror" ]]; then
                if [[ "$active_mirror" =~ ^https:// ]]; then
                    register_check "slackpkg_https" PASS "Mirror uses HTTPS: $active_mirror"
                elif [[ "$active_mirror" =~ ^http:// ]]; then
                    register_check "slackpkg_https" WARN "Mirror uses HTTP (recommend HTTPS): $active_mirror"
                elif [[ "$active_mirror" =~ ^ftp:// ]]; then
                    register_check "slackpkg_https" WARN "Mirror uses FTP (recommend HTTPS): $active_mirror"
                fi
            else
                register_check "slackpkg_mirror" WARN "No active mirror configured in /etc/slackpkg/mirrors"
            fi
        fi

        # Check blacklist configuration
        local blacklist="/etc/slackpkg/blacklist"
        if [[ -f "$blacklist" ]]; then
            local blacklist_count
            blacklist_count=$(grep -cv '^#\|^$' "$blacklist" 2>/dev/null || echo "0")
            register_check "slackpkg_blacklist" INFO "Package blacklist has $blacklist_count entries"
        fi
    else
        register_check "slackpkg_installed" WARN "slackpkg not configured (manual package management only)"
    fi

    # Check for sbopkg (SlackBuilds.org package tool)
    if command -v sbopkg >/dev/null 2>&1; then
        register_check "sbopkg_installed" INFO "sbopkg (SlackBuilds.org tool) installed"

        # Check sbopkg configuration
        if [[ -f /etc/sbopkg/sbopkg.conf ]]; then
            # Check if using current branch
            if grep -q "REPO_BRANCH=" /etc/sbopkg/sbopkg.conf 2>/dev/null; then
                local branch
                branch=$(grep "^REPO_BRANCH=" /etc/sbopkg/sbopkg.conf | cut -d= -f2 | tr -d '"')
                register_check "sbopkg_branch" INFO "sbopkg repo branch: $branch"
            fi
        fi
    fi

    # Check for slapt-get (alternative package manager)
    if command -v slapt-get >/dev/null 2>&1; then
        register_check "slapt_get" INFO "slapt-get (APT-like tool) installed"

        # Check slapt-get GPG configuration
        if [[ -f /etc/slapt-get/slapt-getrc ]]; then
            if grep -q "GPGME=TRUE" /etc/slapt-get/slapt-getrc 2>/dev/null; then
                register_check "slapt_get_gpg" PASS "slapt-get GPG verification enabled"
            else
                register_check "slapt_get_gpg" WARN "slapt-get GPG verification not enabled"
            fi
        fi
    fi
}

# Check for pending updates
audit_pending_updates() {
    if command -v slackpkg >/dev/null 2>&1; then
        # Note: slackpkg update must be run first, we check CHECKSUMS.md5 age
        local checksums="/var/lib/slackpkg/CHECKSUMS.md5"
        if [[ -f "$checksums" ]]; then
            local age_days
            age_days=$(( ($(date +%s) - $(stat -c %Y "$checksums")) / 86400 ))
            if [[ $age_days -gt 7 ]]; then
                register_check "slackpkg_db_age" WARN "Package database $age_days days old (run: slackpkg update)"
            else
                register_check "slackpkg_db_age" PASS "Package database updated $age_days days ago"
            fi
        else
            register_check "slackpkg_db_age" WARN "slackpkg database not initialized (run: slackpkg update)"
        fi
    fi
}

# =============================================================================
# BSD-Style Init System (rc.d)
# =============================================================================

section "Slackware Init System (rc.d)"

audit_init_system() {
    # Verify BSD-style init
    if [[ -f /etc/rc.d/rc.M ]]; then
        register_check "rc_init" PASS "BSD-style init system detected (rc.M)"
    else
        register_check "rc_init" WARN "Standard Slackware init not detected"
        return
    fi

    # Check rc.local permissions
    local rc_local="/etc/rc.d/rc.local"
    if [[ -f "$rc_local" ]]; then
        local perms
        perms=$(stat -c "%a" "$rc_local")
        if [[ "$perms" == "755" ]] || [[ "$perms" == "700" ]]; then
            register_check "rc_local_perms" PASS "rc.local permissions: $perms"
        else
            register_check "rc_local_perms" WARN "rc.local permissions $perms (recommend 755 or 700)"
        fi

        # Check if rc.local is executable
        if [[ -x "$rc_local" ]]; then
            register_check "rc_local_exec" PASS "rc.local is executable"
        else
            register_check "rc_local_exec" INFO "rc.local is not executable (disabled)"
        fi
    fi

    # Audit critical rc.d scripts
    local critical_scripts=(
        "rc.S:System initialization"
        "rc.M:Multi-user mode"
        "rc.K:Single-user mode"
        "rc.0:Halt/shutdown"
        "rc.6:Reboot"
        "rc.sysvinit:SysVinit compatibility"
    )

    for entry in "${critical_scripts[@]}"; do
        local script="${entry%%:*}"
        local desc="${entry#*:}"
        local script_path="/etc/rc.d/$script"

        if [[ -f "$script_path" ]]; then
            local owner
            owner=$(stat -c "%U" "$script_path")
            if [[ "$owner" == "root" ]]; then
                register_check "rc_${script}_owner" PASS "$script owned by root"
            else
                register_check "rc_${script}_owner" FAIL "$script owned by $owner (should be root)"
            fi
        fi
    done

    # Check for insecure rc.d scripts (world-writable)
    local insecure_scripts
    insecure_scripts=$(find /etc/rc.d -type f -perm -002 2>/dev/null | head -5)
    if [[ -n "$insecure_scripts" ]]; then
        register_check "rc_world_writable" FAIL "World-writable rc.d scripts found"
        echo "$insecure_scripts" | while read -r script; do
            echo "  - $script"
        done
    else
        register_check "rc_world_writable" PASS "No world-writable rc.d scripts"
    fi
}

# Audit specific services via rc.d
audit_rc_services() {
    # Services to check (script:description:should_be_disabled)
    local services=(
        "rc.sshd:SSH daemon:0"
        "rc.httpd:HTTP server:1"
        "rc.cups:CUPS printing:1"
        "rc.samba:Samba file sharing:1"
        "rc.nfsd:NFS server:1"
        "rc.rpc:RPC services:1"
        "rc.inetd:inetd super-server:1"
        "rc.telnetd:Telnet daemon:1"
        "rc.atalk:AppleTalk:1"
        "rc.ip_forward:IP forwarding:1"
    )

    for entry in "${services[@]}"; do
        local script="${entry%%:*}"
        local desc
        desc=$(echo "$entry" | cut -d: -f2)
        local should_disable
        should_disable=$(echo "$entry" | cut -d: -f3)
        local script_path="/etc/rc.d/$script"

        if [[ -f "$script_path" ]]; then
            if [[ -x "$script_path" ]]; then
                if [[ "$should_disable" == "1" ]]; then
                    register_check "svc_${script}" WARN "$desc ($script) is enabled - verify if needed"
                else
                    register_check "svc_${script}" PASS "$desc ($script) is enabled"
                fi
            else
                if [[ "$should_disable" == "1" ]]; then
                    register_check "svc_${script}" PASS "$desc ($script) is disabled"
                else
                    register_check "svc_${script}" INFO "$desc ($script) is disabled"
                fi
            fi
        fi
    done

    # Check inetd configuration if enabled
    if [[ -x /etc/rc.d/rc.inetd ]]; then
        local inetd_conf="/etc/inetd.conf"
        if [[ -f "$inetd_conf" ]]; then
            # Check for dangerous services
            local dangerous_services="telnet|rsh|rlogin|rexec|finger|talk|ntalk"
            local dangerous_found
            dangerous_found=$(grep -v '^#' "$inetd_conf" | grep -E "$dangerous_services" || true)
            if [[ -n "$dangerous_found" ]]; then
                register_check "inetd_dangerous" FAIL "Dangerous inetd services enabled"
                echo "$dangerous_found" | head -5
            else
                register_check "inetd_dangerous" PASS "No dangerous inetd services enabled"
            fi
        fi
    fi
}

# =============================================================================
# Network Configuration
# =============================================================================

section "Slackware Network Configuration"

audit_network_config() {
    # Check rc.inet1.conf (network interface configuration)
    local inet1_conf="/etc/rc.d/rc.inet1.conf"
    if [[ -f "$inet1_conf" ]]; then
        register_check "inet1_conf" PASS "Network configuration found: rc.inet1.conf"

        # Check permissions
        local perms
        perms=$(stat -c "%a" "$inet1_conf")
        if [[ "$perms" == "600" ]] || [[ "$perms" == "640" ]] || [[ "$perms" == "644" ]]; then
            register_check "inet1_conf_perms" PASS "rc.inet1.conf permissions: $perms"
        else
            register_check "inet1_conf_perms" WARN "rc.inet1.conf permissions: $perms (recommend 600 or 644)"
        fi
    fi

    # Check rc.inet2 (network services startup)
    local inet2="/etc/rc.d/rc.inet2"
    if [[ -f "$inet2" ]]; then
        if [[ -x "$inet2" ]]; then
            register_check "inet2_enabled" PASS "Network services script (rc.inet2) enabled"
        else
            register_check "inet2_enabled" INFO "Network services script (rc.inet2) disabled"
        fi
    fi

    # Check rc.ip_forward
    local ip_forward="/etc/rc.d/rc.ip_forward"
    if [[ -f "$ip_forward" ]] && [[ -x "$ip_forward" ]]; then
        register_check "ip_forward" WARN "IP forwarding enabled via rc.ip_forward"
    else
        register_check "ip_forward" PASS "IP forwarding script disabled"
    fi

    # Check firewall (rc.firewall or custom iptables)
    local rc_firewall="/etc/rc.d/rc.firewall"
    if [[ -f "$rc_firewall" ]]; then
        if [[ -x "$rc_firewall" ]]; then
            register_check "firewall_script" PASS "Firewall script enabled: rc.firewall"
        else
            register_check "firewall_script" WARN "Firewall script exists but disabled"
        fi
    else
        # Check for iptables rules
        if command -v iptables >/dev/null 2>&1; then
            local rule_count
            rule_count=$(iptables -L -n 2>/dev/null | grep -c -v '^Chain\|^target\|^$' || echo "0")
            if [[ "$rule_count" -gt 0 ]]; then
                register_check "iptables_rules" PASS "iptables has $rule_count rules"
            else
                register_check "iptables_rules" WARN "No iptables rules configured"
            fi
        fi
    fi

    # Check hosts.allow and hosts.deny (TCP Wrappers)
    if [[ -f /etc/hosts.deny ]]; then
        if grep -q "^ALL:ALL" /etc/hosts.deny 2>/dev/null; then
            register_check "tcpwrappers_deny" PASS "hosts.deny configured with default deny"
        else
            register_check "tcpwrappers_deny" WARN "hosts.deny should have 'ALL:ALL' default deny"
        fi
    fi
}

# =============================================================================
# Security Configuration
# =============================================================================

section "Slackware Security Hardening"

audit_security_config() {
    # Check /etc/securetty (root login terminals)
    local securetty="/etc/securetty"
    if [[ -f "$securetty" ]]; then
        local tty_count
        tty_count=$(grep -cv '^#\|^$' "$securetty" 2>/dev/null || echo "0")
        if [[ "$tty_count" -le 6 ]]; then
            register_check "securetty" PASS "Root login restricted to $tty_count terminals"
        else
            register_check "securetty" WARN "Root login allowed on $tty_count terminals (recommend limiting)"
        fi
    fi

    # Check /etc/shutdown.allow
    local shutdown_allow="/etc/shutdown.allow"
    if [[ -f "$shutdown_allow" ]]; then
        register_check "shutdown_allow" PASS "Shutdown restricted to users in shutdown.allow"
    else
        register_check "shutdown_allow" INFO "No shutdown.allow - console users can shutdown"
    fi

    # Check for LILO vs GRUB and password protection
    if [[ -f /etc/lilo.conf ]]; then
        register_check "bootloader" INFO "LILO bootloader detected"

        # Check for LILO password
        if grep -q "^password=" /etc/lilo.conf 2>/dev/null; then
            register_check "lilo_password" PASS "LILO password protection enabled"
        else
            register_check "lilo_password" WARN "LILO password not set (recommend adding password=)"
        fi

        # Check restricted option
        if grep -q "^restricted" /etc/lilo.conf 2>/dev/null; then
            register_check "lilo_restricted" PASS "LILO boot parameter restriction enabled"
        fi
    elif [[ -d /boot/grub ]] || [[ -d /boot/grub2 ]]; then
        register_check "bootloader" INFO "GRUB bootloader detected"

        # Check for GRUB password
        local grub_cfg
        for cfg in /boot/grub/grub.cfg /boot/grub2/grub.cfg /etc/grub.d/40_custom; do
            if [[ -f "$cfg" ]] && grep -q "password" "$cfg" 2>/dev/null; then
                register_check "grub_password" PASS "GRUB password protection configured"
                break
            fi
        done
    fi

    # Check login.defs
    local login_defs="/etc/login.defs"
    if [[ -f "$login_defs" ]]; then
        # Check PASS_MAX_DAYS
        local max_days
        max_days=$(grep "^PASS_MAX_DAYS" "$login_defs" | awk '{print $2}')
        if [[ -n "$max_days" ]] && [[ "$max_days" -le 90 ]]; then
            register_check "pass_max_days" PASS "Password max age: $max_days days"
        elif [[ -n "$max_days" ]]; then
            register_check "pass_max_days" WARN "Password max age: $max_days days (recommend ≤90)"
        fi

        # Check PASS_MIN_DAYS
        local min_days
        min_days=$(grep "^PASS_MIN_DAYS" "$login_defs" | awk '{print $2}')
        if [[ -n "$min_days" ]] && [[ "$min_days" -ge 1 ]]; then
            register_check "pass_min_days" PASS "Password min age: $min_days days"
        else
            register_check "pass_min_days" WARN "Password min age not set (recommend ≥1)"
        fi

        # Check UMASK
        local umask_val
        umask_val=$(grep "^UMASK" "$login_defs" | awk '{print $2}')
        if [[ "$umask_val" == "027" ]] || [[ "$umask_val" == "077" ]]; then
            register_check "login_umask" PASS "Default umask: $umask_val"
        elif [[ -n "$umask_val" ]]; then
            register_check "login_umask" WARN "Default umask: $umask_val (recommend 027 or 077)"
        fi
    fi

    # Check for shadow passwords
    if [[ -f /etc/shadow ]]; then
        local shadow_perms
        shadow_perms=$(stat -c "%a" /etc/shadow)
        if [[ "$shadow_perms" == "000" ]] || [[ "$shadow_perms" == "400" ]] || [[ "$shadow_perms" == "600" ]]; then
            register_check "shadow_perms" PASS "/etc/shadow permissions: $shadow_perms"
        else
            register_check "shadow_perms" FAIL "/etc/shadow permissions: $shadow_perms (should be 000 or 400)"
        fi
    fi

    # Check for accounts with empty passwords
    local empty_pass
    empty_pass=$(awk -F: '($2 == "" || $2 == "!") && $1 != "root" {print $1}' /etc/shadow 2>/dev/null | head -5)
    if [[ -n "$empty_pass" ]]; then
        register_check "empty_passwords" FAIL "Accounts with empty/no password found"
        echo "$empty_pass"
    else
        register_check "empty_passwords" PASS "No accounts with empty passwords"
    fi
}

# Check for common security tools
audit_security_tools() {
    # Check for tripwire or aide
    if command -v tripwire >/dev/null 2>&1; then
        register_check "integrity_monitor" PASS "Tripwire file integrity monitoring installed"
    elif command -v aide >/dev/null 2>&1; then
        register_check "integrity_monitor" PASS "AIDE file integrity monitoring installed"
    else
        register_check "integrity_monitor" WARN "No file integrity monitoring (tripwire/aide) installed"
    fi

    # Check for fail2ban or similar
    if command -v fail2ban-client >/dev/null 2>&1; then
        if [[ -x /etc/rc.d/rc.fail2ban ]] 2>/dev/null; then
            register_check "fail2ban" PASS "fail2ban installed and enabled"
        else
            register_check "fail2ban" WARN "fail2ban installed but not enabled"
        fi
    else
        register_check "fail2ban" WARN "fail2ban not installed (recommend for brute-force protection)"
    fi

    # Check for ClamAV
    if command -v clamscan >/dev/null 2>&1; then
        register_check "antivirus" PASS "ClamAV antivirus installed"
    fi

    # Check for rkhunter or chkrootkit
    if command -v rkhunter >/dev/null 2>&1; then
        register_check "rootkit_scanner" PASS "rkhunter rootkit scanner installed"
    elif command -v chkrootkit >/dev/null 2>&1; then
        register_check "rootkit_scanner" PASS "chkrootkit rootkit scanner installed"
    else
        register_check "rootkit_scanner" WARN "No rootkit scanner (rkhunter/chkrootkit) installed"
    fi
}

# =============================================================================
# Kernel and Boot Security
# =============================================================================

section "Slackware Kernel Security"

audit_kernel_security() {
    # Check kernel version
    local kernel_ver
    kernel_ver=$(uname -r)
    register_check "kernel_version" INFO "Kernel version: $kernel_ver"

    # Check for hardened kernel options
    local sysctl_conf="/etc/sysctl.conf"
    if [[ -f "$sysctl_conf" ]]; then
        # Check for key hardening options
        local hardening_opts=(
            "net.ipv4.tcp_syncookies"
            "net.ipv4.conf.all.rp_filter"
            "net.ipv4.conf.all.accept_redirects"
            "net.ipv4.conf.all.send_redirects"
            "kernel.randomize_va_space"
        )

        for opt in "${hardening_opts[@]}"; do
            if grep -q "^${opt}" "$sysctl_conf" 2>/dev/null; then
                local val
                val=$(grep "^${opt}" "$sysctl_conf" | tail -1 | cut -d= -f2 | tr -d ' ')
                register_check "sysctl_${opt##*.}" INFO "$opt = $val"
            fi
        done
    fi

    # Check current sysctl values
    local current_syncookies
    current_syncookies=$(cat /proc/sys/net/ipv4/tcp_syncookies 2>/dev/null)
    if [[ "$current_syncookies" == "1" ]]; then
        register_check "syncookies_active" PASS "TCP syncookies enabled"
    else
        register_check "syncookies_active" WARN "TCP syncookies disabled"
    fi

    local aslr
    aslr=$(cat /proc/sys/kernel/randomize_va_space 2>/dev/null)
    if [[ "$aslr" == "2" ]]; then
        register_check "aslr_active" PASS "ASLR fully enabled (randomize_va_space=2)"
    elif [[ "$aslr" == "1" ]]; then
        register_check "aslr_active" WARN "ASLR partially enabled (randomize_va_space=1)"
    else
        register_check "aslr_active" FAIL "ASLR disabled"
    fi

    # Check for kernel modules loading
    if [[ -f /proc/sys/kernel/modules_disabled ]]; then
        local modules_disabled
        modules_disabled=$(cat /proc/sys/kernel/modules_disabled)
        if [[ "$modules_disabled" == "1" ]]; then
            register_check "modules_disabled" PASS "Kernel module loading disabled"
        else
            register_check "modules_disabled" INFO "Kernel module loading enabled"
        fi
    fi
}

# =============================================================================
# SSH Configuration
# =============================================================================

section "Slackware SSH Configuration"

audit_ssh_config() {
    # Check if SSH is enabled
    if [[ -x /etc/rc.d/rc.sshd ]]; then
        register_check "sshd_enabled" PASS "SSH daemon enabled"

        local sshd_config="/etc/ssh/sshd_config"
        if [[ -f "$sshd_config" ]]; then
            # Check PermitRootLogin
            local root_login
            root_login=$(grep -i "^PermitRootLogin" "$sshd_config" | awk '{print $2}' | head -1)
            case "$root_login" in
                no)
                    register_check "ssh_root_login" PASS "Root login disabled"
                    ;;
                prohibit-password|without-password)
                    register_check "ssh_root_login" PASS "Root login: key-only"
                    ;;
                yes|"")
                    register_check "ssh_root_login" WARN "Root login enabled (recommend: no or prohibit-password)"
                    ;;
            esac

            # Check PasswordAuthentication
            local pass_auth
            pass_auth=$(grep -i "^PasswordAuthentication" "$sshd_config" | awk '{print $2}' | head -1)
            if [[ "$pass_auth" == "no" ]]; then
                register_check "ssh_pass_auth" PASS "Password authentication disabled (key-only)"
            else
                register_check "ssh_pass_auth" INFO "Password authentication enabled"
            fi

            # Check Protocol
            local protocol
            protocol=$(grep -i "^Protocol" "$sshd_config" | awk '{print $2}' | head -1)
            if [[ -z "$protocol" ]] || [[ "$protocol" == "2" ]]; then
                register_check "ssh_protocol" PASS "SSH Protocol 2 only"
            else
                register_check "ssh_protocol" FAIL "SSH Protocol 1 enabled (insecure)"
            fi
        fi
    else
        register_check "sshd_enabled" INFO "SSH daemon not enabled"
    fi
}

# =============================================================================
# Main Execution
# =============================================================================

main() {
    echo "============================================================"
    echo "Slackware Linux Security Audit"
    echo "============================================================"
    echo ""

    # Verify we're on Slackware
    check_slackware

    # Run all audits
    audit_pkgtools
    audit_pending_updates
    audit_init_system
    audit_rc_services
    audit_network_config
    audit_security_config
    audit_security_tools
    audit_kernel_security
    audit_ssh_config

    # Print summary
    print_summary
    exit "$EXIT_CODE"
}

main "$@"
