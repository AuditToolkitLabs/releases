# Ubuntu-Specific Audits

This folder contains audits specific to Ubuntu Linux distributions.

## Planned Audits

| Script | Description | Status |
|--------|-------------|--------|
| `apt-security.sh` | APT security configuration and unattended-upgrades | TODO |
| `snap-audit.sh` | Snap package security and confinement audit | TODO |
| `livepatch-audit.sh` | Ubuntu Livepatch status and configuration | TODO |
| `ufw-audit.sh` | UFW firewall configuration and rules | TODO |

## Ubuntu-Specific Paths

- `/etc/apt/apt.conf.d/` - APT configuration
- `/etc/apt/sources.list` - Package sources
- `/var/lib/snapd/` - Snap data
- `/var/cache/apt/` - APT cache

## Supported Versions

- Ubuntu 20.04 LTS (Focal Fossa)
- Ubuntu 22.04 LTS (Jammy Jellyfish)
- Ubuntu 24.04 LTS (Noble Numbat)

## Usage

```bash
bash audits/linux/platform/ubuntu/<script>.sh
```
