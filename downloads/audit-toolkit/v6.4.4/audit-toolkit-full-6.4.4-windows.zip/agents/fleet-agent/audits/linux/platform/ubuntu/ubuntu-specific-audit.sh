#!/usr/bin/env bash
# ubuntu-specific-audit.sh — Ubuntu-Specific Security Audit
#
# Compliance Mapping:
# - CIS Ubuntu Linux Benchmark
# - Ubuntu Security Guide (USG)
# - NIST SP 800-53: CM-6, SI-2
#
# Checks:
# - AppArmor enforcement
# - Snap confinement
# - Unattended upgrades
# - Canonical Livepatch
# - Ubuntu Pro / ESM
# - Security repositories
#
# @elevation: partial
# @elevation-reason: APT cache and some snap queries may require elevated access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/distro.sh
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Verify we're on Ubuntu
distro=$(detect_distro)
if [[ "$distro" != "ubuntu" ]]; then
  register_check "Ubuntu detected" SKIP "running on $distro"
  print_summary
  exit "$EXIT_CODE"
fi

section "Ubuntu Distribution Info"

# Get Ubuntu version
ubuntu_version=$(lsb_release -rs 2>/dev/null || grep -oP 'VERSION_ID="\K[^"]+' /etc/os-release || echo "unknown")
register_check "Ubuntu version" PASS "$ubuntu_version"

ubuntu_codename=$(lsb_release -cs 2>/dev/null || grep -oP 'VERSION_CODENAME=\K.*' /etc/os-release || echo "unknown")
register_check "Ubuntu codename" PASS "$ubuntu_codename"

# Check if LTS
case "$ubuntu_version" in
  14.04 | 16.04 | 18.04 | 20.04 | 22.04 | 24.04)
    register_check "LTS release" PASS "yes"
    ;;
  *)
    register_check "LTS release" WARN "non-LTS"
    ;;
esac

section "AppArmor Status"

# Check AppArmor
if command -v aa-status >/dev/null 2>&1; then
  register_check "AppArmor installed" PASS "yes"

  # Check if AppArmor is enabled
  if aa-enabled 2>/dev/null; then
    register_check "AppArmor enabled" PASS "yes"
  else
    register_check "AppArmor enabled" FAIL "no"
  fi

  # Get profile status
  if [[ -r /sys/kernel/security/apparmor/profiles ]] || sudo -n aa-status >/dev/null 2>&1; then
    aa_output=$(sudo -n aa-status 2>/dev/null || aa-status 2>/dev/null || echo "")

    if [[ -n "$aa_output" ]]; then
      enforce_count=$(echo "$aa_output" | grep -oP '\d+(?= profiles are in enforce mode)' || echo "0")
      complain_count=$(echo "$aa_output" | grep -oP '\d+(?= profiles are in complain mode)' || echo "0")

      if [[ "$enforce_count" -gt 0 ]]; then
        register_check "Enforcing profiles" PASS "$enforce_count"
      else
        register_check "Enforcing profiles" WARN "none"
      fi

      if [[ "$complain_count" -gt 0 ]]; then
        register_check "Complaining profiles" WARN "$complain_count"
      fi
    fi
  fi

  # Check for unconfined processes
  aa_unconfined=$(sudo -n aa-unconfined 2>/dev/null | grep -vc "not confined" || echo "0")
  if [[ "$aa_unconfined" -eq 0 ]]; then
    register_check "Unconfined processes" PASS "none with profiles"
  else
    register_check "Unconfined processes" WARN "$aa_unconfined"
  fi
else
  register_check "AppArmor installed" FAIL "not found"
fi

section "Snap Security"

# Check Snap
if command -v snap >/dev/null 2>&1; then
  register_check "Snap installed" PASS "yes"

  # Check snapd version
  snap_version=$(snap version 2>/dev/null | grep "snapd" | awk '{print $2}' || echo "unknown")
  register_check "Snapd version" PASS "$snap_version"

  # Count snaps by confinement
  snap_list=$(snap list 2>/dev/null || echo "")
  if [[ -n "$snap_list" ]]; then
    total_snaps=$(echo "$snap_list" | tail -n +2 | wc -l || echo "0")
    register_check "Installed snaps" PASS "$total_snaps"

    # Check for classic confinement (less secure)
    classic_snaps=$(snap list 2>/dev/null | awk '$4=="classic" {print $1}' | wc -l || echo "0")
    if [[ "$classic_snaps" -gt 0 ]]; then
      register_check "Classic confinement" WARN "$classic_snaps snaps"
      # List classic snaps
      classic_list=$(snap list 2>/dev/null | awk '$4=="classic" {print $1}' | tr '\n' ',' | sed 's/,$//')
      if [[ -n "$classic_list" ]]; then
        register_check "Classic snaps" WARN "$classic_list"
      fi
    else
      register_check "Classic confinement" PASS "none"
    fi

    # Check for devmode (development mode, insecure)
    devmode_snaps=$(snap list 2>/dev/null | awk '$4=="devmode" {print $1}' | wc -l || echo "0")
    if [[ "$devmode_snaps" -gt 0 ]]; then
      register_check "Devmode snaps" FAIL "$devmode_snaps snaps"
    else
      register_check "Devmode snaps" PASS "none"
    fi
  fi

  # Check snap refresh timer
  if systemctl is-active snapd.refresh.timer >/dev/null 2>&1; then
    register_check "Snap refresh timer" PASS "active"
  else
    register_check "Snap refresh timer" WARN "not active"
  fi
else
  register_check "Snap installed" PASS "not installed"
fi

section "Automatic Updates"

# Check unattended-upgrades
if dpkg -l unattended-upgrades 2>/dev/null | grep -q '^ii'; then
  register_check "Unattended-upgrades" PASS "installed"

  # Check if enabled
  unattended_conf="/etc/apt/apt.conf.d/20auto-upgrades"
  if [[ -f "$unattended_conf" ]]; then
    if grep -qE 'APT::Periodic::Unattended-Upgrade\s+"1"' "$unattended_conf"; then
      register_check "Auto upgrades enabled" PASS "yes"
    else
      register_check "Auto upgrades enabled" WARN "disabled"
    fi

    if grep -qE 'APT::Periodic::Update-Package-Lists\s+"1"' "$unattended_conf"; then
      register_check "Auto update lists" PASS "yes"
    fi
  fi

  # Check allowed origins
  origins_conf="/etc/apt/apt.conf.d/50unattended-upgrades"
  if [[ -f "$origins_conf" ]]; then
    if grep -qE "\"\\\${distro_id}:\\\${distro_codename}-security\"" "$origins_conf"; then
      register_check "Security updates" PASS "enabled"
    fi

    # Check for automatic reboot
    if grep -qE '^Unattended-Upgrade::Automatic-Reboot\s+"true"' "$origins_conf"; then
      register_check "Auto reboot" WARN "enabled"
    else
      register_check "Auto reboot" PASS "disabled"
    fi
  fi
else
  register_check "Unattended-upgrades" WARN "not installed"
fi

section "Canonical Livepatch"

# Check Livepatch
if command -v canonical-livepatch >/dev/null 2>&1; then
  register_check "Livepatch installed" PASS "yes"

  # Check status
  livepatch_status=$(canonical-livepatch status 2>/dev/null || echo "")
  if [[ -n "$livepatch_status" ]]; then
    if echo "$livepatch_status" | grep -qE "running: true"; then
      register_check "Livepatch running" PASS "yes"
    else
      register_check "Livepatch running" WARN "not running"
    fi

    # Check patch state
    patch_state=$(echo "$livepatch_status" | grep -oP 'patchState:\s*\K\S+' || echo "")
    if [[ -n "$patch_state" ]]; then
      if [[ "$patch_state" == "applied" ]] || [[ "$patch_state" == "nothing-to-apply" ]]; then
        register_check "Livepatch state" PASS "$patch_state"
      else
        register_check "Livepatch state" WARN "$patch_state"
      fi
    fi
  fi
else
  register_check "Livepatch installed" WARN "not found"
fi

section "Ubuntu Pro / Advantage"

# Check Ubuntu Pro (formerly Ubuntu Advantage)
if command -v pro >/dev/null 2>&1; then
  register_check "Ubuntu Pro CLI" PASS "installed"

  pro_status=$(pro status 2>/dev/null || echo "")
  if [[ -n "$pro_status" ]]; then
    # Check subscription
    if echo "$pro_status" | grep -qE "^Account:"; then
      account=$(echo "$pro_status" | grep -oP '^Account:\s*\K.*' || echo "")
      register_check "Pro subscription" PASS "$account"
    else
      register_check "Pro subscription" WARN "not attached"
    fi

    # Check ESM
    if echo "$pro_status" | grep -qE "esm-infra.*enabled"; then
      register_check "ESM-Infra" PASS "enabled"
    elif echo "$pro_status" | grep -qE "esm-infra.*disabled"; then
      register_check "ESM-Infra" WARN "disabled"
    fi

    if echo "$pro_status" | grep -qE "esm-apps.*enabled"; then
      register_check "ESM-Apps" PASS "enabled"
    fi

    # Check USG (Ubuntu Security Guide)
    if echo "$pro_status" | grep -qE "usg.*enabled"; then
      register_check "USG" PASS "enabled"
    fi

    # Check FIPS
    if echo "$pro_status" | grep -qE "fips.*enabled"; then
      register_check "FIPS" PASS "enabled"
    fi
  fi
elif command -v ua >/dev/null 2>&1; then
  # Older ubuntu-advantage-tools
  register_check "Ubuntu Advantage CLI" PASS "installed"
else
  register_check "Ubuntu Pro CLI" WARN "not installed"
fi

section "Security Repositories"

# Check apt sources
sources_list="/etc/apt/sources.list"
sources_d="/etc/apt/sources.list.d"

security_repos=0

# Check main sources.list
if [[ -f "$sources_list" ]]; then
  if grep -qE "security\.ubuntu\.com|CODENAME-security" "$sources_list" 2>/dev/null; then
    ((security_repos++)) || true
  fi
fi

# Check sources.list.d
if [[ -d "$sources_d" ]]; then
  security_files=$(grep -rlE "security\.ubuntu\.com|CODENAME-security" "$sources_d" 2>/dev/null | wc -l || echo "0")
  ((security_repos += security_files)) || true
fi

if [[ "$security_repos" -gt 0 ]]; then
  register_check "Security repository" PASS "configured"
else
  register_check "Security repository" FAIL "not found"
fi

# Check for ESM repos
esm_repos=$(grep -rlE "esm\.ubuntu\.com" "$sources_d" 2>/dev/null | wc -l || echo "0")
if [[ "$esm_repos" -gt 0 ]]; then
  register_check "ESM repositories" PASS "$esm_repos configured"
fi

section "Ubuntu Security Features"

# Check UFW (Ubuntu's firewall frontend)
if command -v ufw >/dev/null 2>&1; then
  register_check "UFW installed" PASS "yes"

  ufw_status=$(sudo -n ufw status 2>/dev/null || ufw status 2>/dev/null || echo "")
  if echo "$ufw_status" | grep -qE "Status: active"; then
    register_check "UFW enabled" PASS "active"
  else
    register_check "UFW enabled" WARN "inactive"
  fi
fi

# Check fail2ban
if systemctl is-active fail2ban >/dev/null 2>&1; then
  register_check "Fail2ban" PASS "running"
elif dpkg -l fail2ban 2>/dev/null | grep -q '^ii'; then
  register_check "Fail2ban" WARN "installed but not running"
else
  register_check "Fail2ban" WARN "not installed"
fi

# Check for needrestart
if dpkg -l needrestart 2>/dev/null | grep -q '^ii'; then
  register_check "Needrestart" PASS "installed"
else
  register_check "Needrestart" WARN "not installed"
fi

section "Pending Updates"

# Check for pending security updates
pending=$(apt list --upgradable 2>/dev/null | grep -ciE "security" || echo "0")
if [[ "$pending" -eq 0 ]]; then
  register_check "Pending security updates" PASS "none"
else
  register_check "Pending security updates" WARN "$pending packages"
fi

# Check reboot required
if [[ -f /var/run/reboot-required ]]; then
  register_check "Reboot required" WARN "yes"
  if [[ -f /var/run/reboot-required.pkgs ]]; then
    reboot_pkgs=$(wc -l </var/run/reboot-required.pkgs)
    register_check "Reboot packages" WARN "$reboot_pkgs"
  fi
else
  register_check "Reboot required" PASS "no"
fi

print_summary
exit "$EXIT_CODE"
