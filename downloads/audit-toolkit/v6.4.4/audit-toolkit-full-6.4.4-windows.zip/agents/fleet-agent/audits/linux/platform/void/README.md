# Void Linux Security Audits

This directory contains security audits specific to Void Linux systems.

## Overview

Void Linux is an independent Linux distribution featuring:
- **runit init system** (not systemd)
- **XBPS package manager**
- **musl libc** (optional) or glibc
- Rolling release model

## Key Differences from systemd-based Distros

| Feature | Void Linux | systemd Distros |
|---------|------------|-----------------|
| Init System | runit | systemd |
| Service Control | `sv` | `systemctl` |
| Service Directory | `/var/service/` | N/A |
| Available Services | `/etc/sv/` | `/etc/systemd/system/` |
| Package Manager | xbps | apt/dnf/zypper |
| Logging | socklog (optional) | journald |

## Audits Included

| Script | Description |
|--------|-------------|
| [void-specific-audit.sh](void-specific-audit.sh) | General Void Linux security checks (init, logging, kernel hardening, SSH, firewall) |
| [runit-services-audit.sh](runit-services-audit.sh) | runit service supervision, scripts, logging, and security |
| [xbps-package-audit.sh](xbps-package-audit.sh) | XBPS package manager, updates, integrity, and security tools |

## Usage

```bash
# Run all Void Linux audits
bash audits/linux/platform/void/void-specific-audit.sh
bash audits/linux/platform/void/runit-services-audit.sh
bash audits/linux/platform/void/xbps-package-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --match void
```

## Compatibility

These audits automatically skip on non-Void systems with a clear `SKIP` status.
The shim layer in `lib/svc.sh` provides runit support for cross-platform audits.

## Init System Support

The framework's `lib/distro.sh` and `lib/svc.sh` provide these detection functions:

```bash
# Init system detection
is_runit()    # Returns true on Void Linux
is_systemd()  # Returns true on systemd-based distros
is_openrc()   # Returns true on Alpine, Gentoo
is_s6()       # Returns true on Artix with s6
is_dinit()    # Returns true on Chimera, Artix with dinit

# Cross-platform service management
svc_is_active "sshd"    # Works on all init systems
svc_is_enabled "crond"  # Works on all init systems
```

## See Also

- [Alpine audits](../alpine/) - OpenRC-based distribution
- [Arch audits](../arch/) - Similar rolling release model
- [Library API Reference](../../../../docs/06-library-api-reference.md) - Full shim documentation
