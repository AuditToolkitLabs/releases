#!/usr/bin/env bash
# Void Linux runit Services Security Audit
# Checks runit service configuration, supervision, and security settings
#
# @elevation: partial
# @elevation-reason: Some runit service directories require root to inspect
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../../lib/svc.sh"

section "Void Linux runit Services Security Audit"

# Verify we're on Void Linux (or another runit-based system)
if ! is_runit; then
    register_check "runit Detection" SKIP "runit init system not detected - this audit requires runit"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "runit Detection" PASS "runit init system detected"

# Determine service directories
SV_DIR=""
SVC_DIR=""

# Find available services directory
for dir in /etc/sv /etc/runit/sv; do
    if [[ -d "$dir" ]]; then
        SV_DIR="$dir"
        break
    fi
done

# Find enabled services directory
for dir in /var/service /run/runit/service /service; do
    if [[ -d "$dir" ]]; then
        SVC_DIR="$dir"
        break
    fi
done

if [[ -z "$SV_DIR" ]]; then
    register_check "Service Definition Dir" FAIL "Cannot find /etc/sv or equivalent"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "Service Definition Dir" PASS "$SV_DIR"
register_check "Enabled Services Dir" PASS "$SVC_DIR"

# ============================================================================
# Service Supervision Status
# ============================================================================
section "Service Supervision"

# Check runsvdir process
runsvdir_pid=$(pgrep -x runsvdir 2>/dev/null || echo "")
if [[ -n "$runsvdir_pid" ]]; then
    register_check "runsvdir Process" PASS "PID $runsvdir_pid"
else
    register_check "runsvdir Process" FAIL "runsvdir not running"
fi

# Count running services
enabled_count=0
running_count=0
failed_count=0

if [[ -d "$SVC_DIR" ]]; then
    for svc in "$SVC_DIR"/*; do
        [[ -L "$svc" ]] || continue
        svc_name=$(basename "$svc")
        ((enabled_count++))

        status_output=$(sv status "$svc_name" 2>/dev/null || echo "")
        if echo "$status_output" | grep -q '^run:'; then
            ((running_count++))
        else
            ((failed_count++))
        fi
    done
fi

register_check "Enabled Services" INFO "$enabled_count services enabled"
register_check "Running Services" PASS "$running_count services running"
if [[ $failed_count -gt 0 ]]; then
    register_check "Failed Services" WARN "$failed_count services not running"
else
    register_check "Failed Services" PASS "No failed services"
fi

# ============================================================================
# Critical Services Check
# ============================================================================
section "Critical Services Status"

# Define critical services to check
critical_services=(
    "sshd:SSH daemon"
    "crond:Cron scheduler (dcron)"
    "socklog-unix:System logging"
    "nanoklogd:Kernel logging"
    "dhcpcd:DHCP client"
    "udevd:Device manager"
)

for entry in "${critical_services[@]}"; do
    svc="${entry%%:*}"
    desc="${entry##*:}"

    if [[ -L "$SVC_DIR/$svc" ]]; then
        if sv status "$svc" 2>/dev/null | grep -q '^run:'; then
            uptime=$(sv status "$svc" 2>/dev/null | grep -oE '[0-9]+s' | head -1 || echo "")
            register_check "Service: $svc" PASS "running${uptime:+ ($uptime)}"
        else
            register_check "Service: $svc" WARN "enabled but not running"
        fi
    else
        # Check if available but not enabled
        if [[ -d "$SV_DIR/$svc" ]]; then
            register_check "Service: $svc" INFO "Available but not enabled"
        fi
    fi
done

# ============================================================================
# Service Script Security
# ============================================================================
section "Service Script Security"

# Check run script permissions in /etc/sv
insecure_scripts=0
world_writable=0

if [[ -d "$SV_DIR" ]]; then
    while IFS= read -r run_script; do
        if [[ -f "$run_script" ]]; then
            perms=$(stat -c '%a' "$run_script" 2>/dev/null)
            owner=$(stat -c '%U' "$run_script" 2>/dev/null)

            # Check owner
            if [[ "$owner" != "root" ]]; then
                ((insecure_scripts++))
            fi

            # Check world-writable
            if [[ $((perms & 2)) -ne 0 ]]; then
                ((world_writable++))
            fi

            # Check executable
            if [[ ! -x "$run_script" ]]; then
                svc_name=$(basename "$(dirname "$run_script")")
                register_check "Script: $svc_name/run" WARN "Not executable"
            fi
        fi
    done < <(find "$SV_DIR" -name "run" -type f 2>/dev/null | head -100)
fi

if [[ $insecure_scripts -eq 0 ]]; then
    register_check "Run Script Ownership" PASS "All run scripts owned by root"
else
    register_check "Run Script Ownership" WARN "$insecure_scripts scripts not owned by root"
fi

if [[ $world_writable -eq 0 ]]; then
    register_check "Run Script Permissions" PASS "No world-writable run scripts"
else
    register_check "Run Script Permissions" FAIL "$world_writable world-writable run scripts"
fi

# ============================================================================
# Logging Configuration
# ============================================================================
section "Service Logging"

# Check for log directories in services
services_with_logging=0
services_without_logging=0

if [[ -d "$SV_DIR" ]]; then
    for svc_dir in "$SV_DIR"/*/; do
        [[ -d "$svc_dir" ]] || continue
        svc_name=$(basename "$svc_dir")

        if [[ -d "${svc_dir}log" ]] && [[ -f "${svc_dir}log/run" ]]; then
            ((services_with_logging++))
        else
            ((services_without_logging++))
        fi
    done
fi

register_check "Services with Logging" INFO "$services_with_logging services have dedicated logging"
if [[ $services_without_logging -gt 10 ]]; then
    register_check "Services without Logging" INFO "$services_without_logging services use system logging"
fi

# Check svlogd (runit's log daemon)
if command -v svlogd >/dev/null 2>&1; then
    register_check "svlogd Available" PASS "runit log daemon available"
else
    register_check "svlogd Available" INFO "svlogd not installed"
fi

# ============================================================================
# Down Files (Disabled Services)
# ============================================================================
section "Service Control Files"

# Check for services with 'down' files (disabled on boot)
down_count=0
if [[ -d "$SVC_DIR" ]]; then
    for svc in "$SVC_DIR"/*; do
        [[ -L "$svc" ]] || continue
        target=$(readlink -f "$svc" 2>/dev/null || echo "")
        if [[ -f "${target}/down" ]]; then
            ((down_count++))
            svc_name=$(basename "$svc")
            register_check "Down: $svc_name" INFO "Service has 'down' file (won't auto-start)"
        fi
    done
fi

if [[ $down_count -eq 0 ]]; then
    register_check "Down Files" PASS "No services have 'down' files"
fi

# ============================================================================
# Finish Scripts
# ============================================================================
section "Finish Scripts"

# Check for finish scripts (run after service exits)
finish_scripts=0
if [[ -d "$SV_DIR" ]]; then
    for svc_dir in "$SV_DIR"/*/; do
        [[ -d "$svc_dir" ]] || continue
        if [[ -f "${svc_dir}finish" ]]; then
            ((finish_scripts++))
            # Check if executable
            if [[ ! -x "${svc_dir}finish" ]]; then
                svc_name=$(basename "$svc_dir")
                register_check "Finish: $svc_name" WARN "finish script not executable"
            fi
        fi
    done
fi

register_check "Finish Scripts" INFO "$finish_scripts services have finish scripts"

# ============================================================================
# Check Scripts
# ============================================================================
section "Check Scripts"

# Check for check scripts (run before service marked as up)
check_scripts=0
if [[ -d "$SV_DIR" ]]; then
    for svc_dir in "$SV_DIR"/*/; do
        [[ -d "$svc_dir" ]] || continue
        if [[ -f "${svc_dir}check" ]]; then
            ((check_scripts++))
        fi
    done
fi

register_check "Check Scripts" INFO "$check_scripts services have health check scripts"

# ============================================================================
# Control Directory Permissions
# ============================================================================
section "Control Directory Permissions"

# Check supervise directory permissions
for svc in "$SVC_DIR"/*; do
    [[ -L "$svc" ]] || continue
    svc_name=$(basename "$svc")
    supervise_dir="$svc/supervise"

    if [[ -d "$supervise_dir" ]]; then
        perms=$(stat -c '%a' "$supervise_dir" 2>/dev/null)
        owner=$(stat -c '%U' "$supervise_dir" 2>/dev/null)

        if [[ "$owner" != "root" ]]; then
            register_check "Supervise: $svc_name" WARN "supervise dir owned by $owner"
        fi

        if [[ $((perms & 7)) -gt 0 ]]; then
            register_check "Supervise: $svc_name" WARN "supervise dir is world-accessible ($perms)"
        fi
    fi
done 2>/dev/null | head -20  # Limit output

register_check "Supervise Directories" INFO "Checked supervise directory permissions"

# ============================================================================
# Environment Variables
# ============================================================================
section "Service Environment"

# Check for services with custom environment
env_count=0
if [[ -d "$SV_DIR" ]]; then
    for svc_dir in "$SV_DIR"/*/; do
        [[ -d "$svc_dir" ]] || continue
        if [[ -d "${svc_dir}env" ]] || [[ -f "${svc_dir}conf" ]]; then
            ((env_count++))
        fi
    done
fi

register_check "Custom Environments" INFO "$env_count services have custom environment/config"

# Check for sensitive info in env files
sensitive_patterns=("PASSWORD" "SECRET" "KEY" "TOKEN" "CREDENTIAL")
sensitive_found=0

if [[ -d "$SV_DIR" ]]; then
    for svc_dir in "$SV_DIR"/*/; do
        [[ -d "${svc_dir}env" ]] || continue
        for pattern in "${sensitive_patterns[@]}"; do
            if grep -rlq "$pattern" "${svc_dir}env" 2>/dev/null; then
                ((sensitive_found++))
                break
            fi
        done
    done
fi

if [[ $sensitive_found -gt 0 ]]; then
    register_check "Sensitive Env Vars" WARN "$sensitive_found services may have credentials in env (check permissions)"
else
    register_check "Sensitive Env Vars" INFO "No obvious credential patterns in env directories"
fi

# ============================================================================
# Final Summary
# ============================================================================
print_summary
exit "$EXIT_CODE"
