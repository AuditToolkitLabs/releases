#!/usr/bin/env bash
# Void Linux Specific Security Audit
# Checks Void Linux-specific security configurations and best practices
#
# @elevation: partial
# @elevation-reason: Some XBPS and system config checks require elevated access
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../../lib/svc.sh"

section "Void Linux Security Audit"

# Verify we're on Void Linux
if [[ "$(detect_distro)" != "void" ]]; then
    register_check "Void Detection" SKIP "Not running on Void Linux - this audit is Void-specific"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "Void Detection" PASS "Running on Void Linux"

# ============================================================================
# System Information
# ============================================================================
section "System Information"

# Get Void version info
if [[ -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    register_check "Void Version" INFO "${PRETTY_NAME:-Void Linux}"
fi

# Check if using musl or glibc
if ldd --version 2>&1 | head -1 | grep -qi 'musl'; then
    register_check "C Library" INFO "musl libc (security-hardened, smaller attack surface)"
else
    register_check "C Library" INFO "glibc (full compatibility)"
fi

# Check kernel version
kernel_ver=$(uname -r)
register_check "Kernel Version" INFO "$kernel_ver"

# ============================================================================
# Init System (runit)
# ============================================================================
section "runit Init System"

# Verify runit is in use
if is_runit; then
    register_check "runit Active" PASS "runit init system detected"
else
    register_check "runit Active" WARN "runit not detected - unexpected for Void Linux"
fi

# Check runit-init
if [[ -x /sbin/runit-init ]]; then
    register_check "runit-init" PASS "/sbin/runit-init exists"
else
    register_check "runit-init" WARN "runit-init not found at expected location"
fi

# Check runsvdir process
if pgrep -x runsvdir >/dev/null 2>&1; then
    register_check "runsvdir" PASS "runsvdir process running"
else
    register_check "runsvdir" FAIL "runsvdir not running"
fi

# Check service directories
for svc_dir in /var/service /run/runit/service /service; do
    if [[ -d "$svc_dir" ]]; then
        svc_count=$(find "$svc_dir" -maxdepth 1 -type l 2>/dev/null | wc -l)
        register_check "Service Dir: $svc_dir" PASS "$svc_count services enabled"
        break
    fi
done

# ============================================================================
# Logging Configuration
# ============================================================================
section "Logging Configuration"

# Check socklog (Void's default logging)
if command -v socklog >/dev/null 2>&1; then
    register_check "socklog Installed" PASS "socklog logging daemon available"

    # Check if socklog service is running
    if sv status socklog-unix >/dev/null 2>&1; then
        register_check "socklog Service" PASS "socklog-unix service running"
    else
        register_check "socklog Service" WARN "socklog-unix not running"
    fi

    # Check nanoklogd (kernel log)
    if sv status nanoklogd >/dev/null 2>&1; then
        register_check "Kernel Logging" PASS "nanoklogd running"
    else
        register_check "Kernel Logging" INFO "nanoklogd not running"
    fi
else
    register_check "socklog Installed" INFO "socklog not installed (consider installing for logging)"
fi

# Check log directory permissions
if [[ -d /var/log ]]; then
    log_perms=$(stat -c '%a' /var/log 2>/dev/null)
    if [[ "$log_perms" == "755" ]] || [[ "$log_perms" == "750" ]]; then
        register_check "/var/log Permissions" PASS "$log_perms"
    else
        register_check "/var/log Permissions" WARN "Permissions: $log_perms (expected 755 or 750)"
    fi
fi

# ============================================================================
# Security Features
# ============================================================================
section "Security Features"

# Check kernel hardening parameters
declare -A kernel_params=(
    ["kernel.kptr_restrict"]="1:2"
    ["kernel.dmesg_restrict"]="1"
    ["kernel.unprivileged_bpf_disabled"]="1"
    ["net.core.bpf_jit_harden"]="2"
    ["kernel.yama.ptrace_scope"]="1:2:3"
)

for param in "${!kernel_params[@]}"; do
    expected="${kernel_params[$param]}"
    current=$(sysctl -n "$param" 2>/dev/null || echo "N/A")

    if [[ "$current" == "N/A" ]]; then
        register_check "Sysctl: $param" SKIP "Parameter not available"
    elif [[ "$expected" == *":"* ]]; then
        # Multiple acceptable values
        if echo "$expected" | tr ':' '\n' | grep -qx "$current"; then
            register_check "Sysctl: $param" PASS "$current"
        else
            register_check "Sysctl: $param" WARN "$current (expected: $expected)"
        fi
    elif [[ "$current" == "$expected" ]]; then
        register_check "Sysctl: $param" PASS "$current"
    else
        register_check "Sysctl: $param" WARN "$current (expected: $expected)"
    fi
done

# Check for dracut security modules
if command -v dracut >/dev/null 2>&1; then
    register_check "Dracut Available" PASS "dracut initramfs generator installed"

    # Check dracut configuration
    if [[ -d /etc/dracut.conf.d ]]; then
        dracut_confs=$(find /etc/dracut.conf.d -name '*.conf' 2>/dev/null | wc -l)
        register_check "Dracut Config" INFO "$dracut_confs custom configurations"
    fi
fi

# ============================================================================
# User & Authentication Security
# ============================================================================
section "User & Authentication"

# Check root account status
root_shell=$(getent passwd root | cut -d: -f7)
if [[ "$root_shell" == "/sbin/nologin" ]] || [[ "$root_shell" == "/usr/sbin/nologin" ]]; then
    register_check "Root Shell" PASS "Root login disabled"
else
    register_check "Root Shell" INFO "Root uses $root_shell"
fi

# Check for sudo
if command -v sudo >/dev/null 2>&1; then
    register_check "sudo Installed" PASS "sudo available"

    # Check sudoers syntax
    if visudo -c >/dev/null 2>&1; then
        register_check "Sudoers Syntax" PASS "sudoers file valid"
    else
        register_check "Sudoers Syntax" FAIL "sudoers has syntax errors"
    fi
else
    register_check "sudo Installed" WARN "sudo not installed"
fi

# Check for opendoas (alternative to sudo)
if command -v doas >/dev/null 2>&1; then
    register_check "doas Installed" PASS "doas (lightweight sudo alternative) available"

    if [[ -f /etc/doas.conf ]]; then
        doas_perms=$(stat -c '%a' /etc/doas.conf 2>/dev/null)
        if [[ "$doas_perms" == "600" ]] || [[ "$doas_perms" == "400" ]]; then
            register_check "doas.conf Perms" PASS "$doas_perms"
        else
            register_check "doas.conf Perms" WARN "$doas_perms (should be 600 or 400)"
        fi
    fi
fi

# ============================================================================
# SSH Configuration
# ============================================================================
section "SSH Configuration"

sshd_config="/etc/ssh/sshd_config"
if [[ -f "$sshd_config" ]]; then
    register_check "SSHD Config" PASS "sshd_config exists"

    # Check PermitRootLogin
    root_login=$(grep -E "^\s*PermitRootLogin" "$sshd_config" 2>/dev/null | awk '{print $2}' | tail -1)
    case "${root_login,,}" in
        no|prohibit-password)
            register_check "SSH Root Login" PASS "${root_login}"
            ;;
        yes|"")
            register_check "SSH Root Login" WARN "Root login may be allowed (default or yes)"
            ;;
        *)
            register_check "SSH Root Login" INFO "$root_login"
            ;;
    esac

    # Check PasswordAuthentication
    pass_auth=$(grep -E "^\s*PasswordAuthentication" "$sshd_config" 2>/dev/null | awk '{print $2}' | tail -1)
    if [[ "${pass_auth,,}" == "no" ]]; then
        register_check "SSH Password Auth" PASS "Disabled (key-only)"
    else
        register_check "SSH Password Auth" INFO "Enabled (consider key-only auth)"
    fi

    # Check for SSH service
    if sv status sshd >/dev/null 2>&1; then
        register_check "SSH Service" PASS "sshd running"
    else
        register_check "SSH Service" INFO "sshd not running"
    fi
else
    register_check "SSHD Config" INFO "OpenSSH not configured"
fi

# ============================================================================
# Firewall
# ============================================================================
section "Firewall Configuration"

# Check iptables/nftables
if command -v nft >/dev/null 2>&1; then
    rule_count=$(nft list ruleset 2>/dev/null | grep -c 'rule' || echo "0")
    if [[ $rule_count -gt 0 ]]; then
        register_check "nftables" PASS "$rule_count rules defined"
    else
        register_check "nftables" WARN "nftables available but no rules"
    fi
elif command -v iptables >/dev/null 2>&1; then
    rule_count=$(iptables -L -n 2>/dev/null | grep -c '^' || echo "0")
    if [[ $rule_count -gt 10 ]]; then
        register_check "iptables" PASS "iptables rules present"
    else
        register_check "iptables" WARN "iptables has minimal rules"
    fi
else
    register_check "Firewall" WARN "No firewall tools found"
fi

# ============================================================================
# Package Security
# ============================================================================
section "Package Security"

# Quick check for outdated critical packages
if command -v xbps-install >/dev/null 2>&1; then
    pending=$(xbps-install -un 2>/dev/null | wc -l || echo "0")
    if [[ $pending -eq 0 ]]; then
        register_check "Package Updates" PASS "All packages up to date"
    elif [[ $pending -lt 10 ]]; then
        register_check "Package Updates" WARN "$pending packages have updates"
    else
        register_check "Package Updates" FAIL "$pending packages need updating"
    fi
fi

# ============================================================================
# Final Summary
# ============================================================================
print_summary
exit "$EXIT_CODE"
