#!/usr/bin/env bash
# Void Linux XBPS Package Security Audit
# Checks for outdated packages, security updates, and package integrity
#
# @elevation: root
# @elevation-reason: XBPS package queries and integrity checks require root
#
set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

section "Void Linux XBPS Package Security Audit"

# Verify we're on Void Linux
if [[ "$(detect_distro)" != "void" ]]; then
    register_check "Void Detection" SKIP "Not running on Void Linux - this audit is Void-specific"
    print_summary
    exit "$EXIT_CODE"
fi

# Check if XBPS is available
if ! command -v xbps-install >/dev/null 2>&1; then
    register_check "XBPS Available" FAIL "XBPS package manager not found"
    print_summary
    exit "$EXIT_CODE"
fi

register_check "XBPS Available" PASS "XBPS package manager found"

# ============================================================================
# Repository Configuration
# ============================================================================
section "Repository Configuration"

# Check repository configuration
repo_conf="/etc/xbps.d"
if [[ -d "$repo_conf" ]]; then
    register_check "XBPS Config Dir" PASS "/etc/xbps.d exists"

    # Count config files
    conf_count=$(find "$repo_conf" -name '*.conf' 2>/dev/null | wc -l)
    register_check "Config Files" INFO "$conf_count configuration files"
else
    register_check "XBPS Config Dir" INFO "Using default configuration"
fi

# List configured repositories
repos=$(xbps-query -L 2>/dev/null || echo "")
if [[ -n "$repos" ]]; then
    repo_count=$(echo "$repos" | wc -l)
    register_check "Repositories" INFO "$repo_count repositories configured"

    # Check for HTTPS repositories
    https_repos=$(echo "$repos" | grep -c 'https://' || echo 0)
    http_repos=$(echo "$repos" | grep -c 'http://' | head -1 || echo 0)

    if [[ $http_repos -gt 0 ]] && [[ $https_repos -eq 0 ]]; then
        register_check "Repository Security" WARN "Using HTTP repositories - consider HTTPS mirrors"
    elif [[ $https_repos -gt 0 ]]; then
        register_check "Repository Security" PASS "Using HTTPS repositories"
    fi
else
    register_check "Repositories" WARN "Could not query repositories"
fi

# Check for custom mirrors
custom_repo_found=false
for repo_conf in /etc/xbps.d/*-repository*.conf; do
    if [[ -e "$repo_conf" ]]; then
        custom_repo_found=true
        break
    fi
done

if $custom_repo_found; then
    register_check "Custom Mirrors" INFO "Custom repository mirrors configured"
fi

# ============================================================================
# Package Index
# ============================================================================
section "Package Index"

# Sync repository index
if xbps-install -S >/dev/null 2>&1; then
    register_check "Repository Sync" PASS "Successfully synced package index"
else
    register_check "Repository Sync" WARN "Failed to sync package index (network issue?)"
fi

# ============================================================================
# Package Updates
# ============================================================================
section "Package Updates"

# Check for available updates
update_output=$(xbps-install -un 2>/dev/null || echo "")
update_count=$(echo "$update_output" | grep -c '^' | head -1 || echo 0)
# Filter empty lines
update_count=$(echo "$update_output" | grep -v '^$' | wc -l)

if [[ $update_count -eq 0 ]] || [[ -z "$update_output" ]]; then
    register_check "Pending Updates" PASS "All packages are up to date"
elif [[ $update_count -lt 10 ]]; then
    register_check "Pending Updates" WARN "$update_count packages have updates available"
else
    register_check "Pending Updates" FAIL "$update_count packages need updating - review for security patches"
fi

# Check critical packages for updates
critical_packages=(
    "openssl"
    "openssh"
    "curl"
    "wget"
    "sudo"
    "linux"
    "musl"
    "glibc"
    "bash"
    "xbps"
)

for pkg in "${critical_packages[@]}"; do
    if xbps-query "$pkg" >/dev/null 2>&1; then
        installed_ver=$(xbps-query "$pkg" 2>/dev/null | grep "pkgver:" | awk '{print $2}')

        # Check if update available
        if echo "$update_output" | grep -q "^$pkg-"; then
            register_check "Update: $pkg" WARN "Update available for $pkg"
        elif [[ -n "$installed_ver" ]]; then
            register_check "Package: $pkg" PASS "$installed_ver"
        fi
    fi
done

# ============================================================================
# Package Integrity
# ============================================================================
section "Package Integrity"

# Check for packages with modified files
if command -v xbps-pkgdb >/dev/null 2>&1; then
    # Quick integrity check on critical packages
    integrity_issues=0
    check_packages=("xbps" "bash" "coreutils")

    for pkg in "${check_packages[@]}"; do
        if xbps-query "$pkg" >/dev/null 2>&1; then
            check_output=$(xbps-pkgdb -m "$pkg" 2>&1 || echo "")
            if [[ -n "$check_output" ]] && [[ "$check_output" != *"OK"* ]]; then
                ((integrity_issues++))
                register_check "Integrity: $pkg" WARN "Package may have modified files"
            else
                register_check "Integrity: $pkg" PASS "Package integrity OK"
            fi
        fi
    done

    if [[ $integrity_issues -eq 0 ]]; then
        register_check "Package Integrity" PASS "Checked packages have good integrity"
    fi
fi

# ============================================================================
# Orphaned Packages
# ============================================================================
section "Orphaned Packages"

# Check for orphaned packages
orphans=$(xbps-query -O 2>/dev/null || echo "")
orphan_count=$(echo "$orphans" | grep -v '^$' | wc -l)

if [[ $orphan_count -eq 0 ]] || [[ -z "$orphans" ]]; then
    register_check "Orphaned Packages" PASS "No orphaned packages"
elif [[ $orphan_count -lt 5 ]]; then
    register_check "Orphaned Packages" INFO "$orphan_count orphaned packages (consider removal)"
else
    register_check "Orphaned Packages" WARN "$orphan_count orphaned packages - run 'xbps-remove -o'"
fi

# ============================================================================
# Hold/Ignored Packages
# ============================================================================
section "Package Holds"

# Check for held packages
held=$(xbps-query -H 2>/dev/null || echo "")
held_count=$(echo "$held" | grep -v '^$' | wc -l)

if [[ $held_count -eq 0 ]] || [[ -z "$held" ]]; then
    register_check "Held Packages" PASS "No packages on hold"
else
    register_check "Held Packages" INFO "$held_count packages held from updates"
    # Warn about held security packages
    security_held=0
    for pkg in openssl openssh linux sudo; do
        if echo "$held" | grep -q "^$pkg"; then
            ((security_held++))
            register_check "Held: $pkg" WARN "$pkg is held - may miss security updates"
        fi
    done
fi

# ============================================================================
# Package Sources
# ============================================================================
section "Build Configuration"

# Check if void-packages is present (source building)
if [[ -d /void-packages ]] || [[ -d ~/void-packages ]]; then
    register_check "void-packages" INFO "Source package tree present"

    # Check for local builds
    local_repo=""
    for dir in /void-packages/hostdir/binpkgs ~/void-packages/hostdir/binpkgs; do
        if [[ -d "$dir" ]]; then
            local_repo="$dir"
            break
        fi
    done

    if [[ -n "$local_repo" ]]; then
        local_pkgs=$(find "$local_repo" -name '*.xbps' 2>/dev/null | wc -l)
        register_check "Local Packages" INFO "$local_pkgs locally-built packages"
    fi
fi

# ============================================================================
# Security Packages
# ============================================================================
section "Security Tools"

# Check for recommended security packages
security_packages=(
    "fail2ban:Intrusion prevention"
    "rkhunter:Rootkit hunter"
    "lynis:Security auditing"
    "audit:Linux audit framework"
    "firejail:Application sandbox"
    "apparmor:Mandatory access control"
)

for entry in "${security_packages[@]}"; do
    pkg="${entry%%:*}"
    desc="${entry##*:}"

    if xbps-query "$pkg" >/dev/null 2>&1; then
        register_check "Tool: $pkg" PASS "Installed - $desc"
    else
        register_check "Tool: $pkg" INFO "Not installed - $desc"
    fi
done

# ============================================================================
# Cache Management
# ============================================================================
section "Package Cache"

# Check package cache size
cache_dir="/var/cache/xbps"
if [[ -d "$cache_dir" ]]; then
    cache_size=$(du -sh "$cache_dir" 2>/dev/null | cut -f1)
    cache_files=$(find "$cache_dir" -name '*.xbps' 2>/dev/null | wc -l)

    register_check "Cache Size" INFO "$cache_size (${cache_files} packages)"

    # Recommend cleanup if large
    cache_bytes=$(du -sb "$cache_dir" 2>/dev/null | cut -f1 || echo 0)
    if [[ $cache_bytes -gt 1073741824 ]]; then  # > 1GB
        register_check "Cache Cleanup" WARN "Cache > 1GB - consider 'xbps-remove -O'"
    fi
fi

# ============================================================================
# Broken Packages
# ============================================================================
section "Package Health"

# Check for broken packages
broken_output=$(xbps-pkgdb 2>&1 || echo "")
if echo "$broken_output" | grep -qiE "error|broken|missing"; then
    register_check "Package Database" WARN "Package database may have issues"
else
    register_check "Package Database" PASS "Package database healthy"
fi

# ============================================================================
# Installed Package Count
# ============================================================================
section "Package Statistics"

# Count installed packages
total_packages=$(xbps-query -l 2>/dev/null | wc -l)
register_check "Total Packages" INFO "$total_packages packages installed"

# Count manual vs auto-installed
manual_pkgs=$(xbps-query -m 2>/dev/null | wc -l)
register_check "Manual Packages" INFO "$manual_pkgs manually installed packages"

# ============================================================================
# Final Summary
# ============================================================================
print_summary
exit "$EXIT_CODE"
