#!/usr/bin/env bash
# _edr-common.sh — Shared functions for EDR agent audits
#
# @elevation: none
# @elevation-reason: Library file sourced by EDR audits; does not require elevation itself
#
# Source this file from EDR audit scripts to get common check functions.
# This library provides standardized checks for EDR agent validation.
#
# Usage in EDR scripts:
#   . "$(dirname "$0")/_edr-common.sh"

# Prevent direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  echo "This script is meant to be sourced, not executed directly." >&2
  exit 1
fi

# Check if an EDR agent directory exists
# Usage: edr_dir_exists "/opt/CrowdStrike" "CrowdStrike"
edr_dir_exists() {
  local path="$1"
  local name="$2"
  if [[ -d "$path" ]]; then
    register_check "$name installation directory" PASS "$path exists"
    return 0
  else
    register_check "$name installation directory" FAIL "$path not found"
    return 1
  fi
}

# Check if an EDR binary exists and is executable
# Usage: edr_binary_exists "/opt/CrowdStrike/falconctl" "falconctl"
edr_binary_exists() {
  local path="$1"
  local name="$2"
  if [[ -x "$path" ]]; then
    register_check "$name binary" PASS "$path executable"
    return 0
  elif [[ -f "$path" ]]; then
    register_check "$name binary" WARN "$path exists but not executable"
    return 1
  else
    register_check "$name binary" FAIL "$path not found"
    return 1
  fi
}

# Check if EDR service is running using multiple methods
# Usage: edr_service_check "falcon-sensor" "Falcon Sensor"
edr_service_check() {
  local service_name="$1"
  local display_name="$2"

  # Try systemctl first
  if command -v systemctl >/dev/null 2>&1 && pidof systemd >/dev/null 2>&1; then
    if systemctl is-active --quiet "$service_name" 2>/dev/null; then
      register_check "$display_name service" PASS "running (systemd)"
      return 0
    fi
  fi

  # Try rc-service (OpenRC)
  if command -v rc-service >/dev/null 2>&1; then
    if rc-service "$service_name" status >/dev/null 2>&1; then
      register_check "$display_name service" PASS "running (OpenRC)"
      return 0
    fi
  fi

  # Try runit (Void Linux, Artix)
  if command -v sv >/dev/null 2>&1; then
    if sv status "$service_name" 2>/dev/null | grep -q '^run:'; then
      register_check "$display_name service" PASS "running (runit)"
      return 0
    fi
  fi

  # Try s6 (Artix, Obarun)
  if command -v s6-svstat >/dev/null 2>&1; then
    if s6-svstat "/run/s6/services/$service_name" 2>/dev/null | grep -q 'up'; then
      register_check "$display_name service" PASS "running (s6)"
      return 0
    fi
  fi

  # Try dinit (Artix, Chimera)
  if command -v dinitctl >/dev/null 2>&1; then
    if dinitctl status "$service_name" 2>/dev/null | grep -qiE 'STARTED|running'; then
      register_check "$display_name service" PASS "running (dinit)"
      return 0
    fi
  fi

  # Fallback to process check
  if pgrep -f "$service_name" >/dev/null 2>&1; then
    register_check "$display_name service" PASS "process running"
    return 0
  fi

  register_check "$display_name service" FAIL "not running"
  return 1
}

# Check if EDR service is enabled at boot
# Usage: edr_service_enabled "falcon-sensor" "Falcon Sensor"
edr_service_enabled() {
  local service_name="$1"
  local display_name="$2"

  if command -v systemctl >/dev/null 2>&1 && pidof systemd >/dev/null 2>&1; then
    if systemctl is-enabled --quiet "$service_name" 2>/dev/null; then
      register_check "$display_name boot enabled" PASS "enabled"
      return 0
    fi
  fi

  if command -v rc-update >/dev/null 2>&1; then
    if rc-update show 2>/dev/null | grep -q "$service_name"; then
      register_check "$display_name boot enabled" PASS "enabled (OpenRC)"
      return 0
    fi
  fi

  # runit: service is enabled if symlinked
  if command -v sv >/dev/null 2>&1; then
    if [[ -L "/var/service/$service_name" ]] || [[ -L "/service/$service_name" ]]; then
      register_check "$display_name boot enabled" PASS "enabled (runit)"
      return 0
    fi
  fi

  # s6: check service directory
  if command -v s6-rc-db >/dev/null 2>&1; then
    if s6-rc-db list all 2>/dev/null | grep -qF "$service_name"; then
      register_check "$display_name boot enabled" PASS "enabled (s6)"
      return 0
    fi
  fi

  # dinit: check service list
  if command -v dinitctl >/dev/null 2>&1; then
    if dinitctl list 2>/dev/null | grep -qE "^\[\+\].*$service_name"; then
      register_check "$display_name boot enabled" PASS "enabled (dinit)"
      return 0
    fi
  fi

  register_check "$display_name boot enabled" WARN "not enabled at boot"
  return 1
}

# Generic command execution with output capture
# Usage: edr_command_check "falconctl -g --aid" "Agent ID" "CrowdStrike"
edr_command_check() {
  local cmd="$1"
  local check_name="$2"
  local agent_name="$3"
  local output

  if output=$(eval "$cmd" 2>/dev/null); then
    if [[ -n "$output" ]]; then
      # Truncate long output for display
      local display_output="${output:0:80}"
      [[ ${#output} -gt 80 ]] && display_output="${display_output}..."
      register_check "$agent_name $check_name" PASS "$display_output"
      return 0
    else
      register_check "$agent_name $check_name" WARN "command succeeded but no output"
      return 1
    fi
  else
    register_check "$agent_name $check_name" FAIL "command failed"
    return 1
  fi
}

# Check file permissions (for config files)
# Usage: edr_file_perms "/etc/crowdstrike/falconctl.conf" "600" "CrowdStrike config"
edr_file_perms() {
  local path="$1"
  local expected_perms="$2"
  local name="$3"

  if [[ ! -f "$path" ]]; then
    register_check "$name permissions" SKIP "file not found"
    return 1
  fi

  local actual_perms
  actual_perms=$(stat -c '%a' "$path" 2>/dev/null || stat -f '%Lp' "$path" 2>/dev/null)

  if [[ "$actual_perms" == "$expected_perms" ]]; then
    register_check "$name permissions" PASS "$actual_perms"
    return 0
  else
    register_check "$name permissions" WARN "expected $expected_perms, got $actual_perms"
    return 1
  fi
}

# Check connectivity to management server (generic ping/health check)
# Usage: edr_connectivity_check "hostname:port" "CrowdStrike cloud"
edr_connectivity_check() {
  local endpoint="$1"
  local name="$2"
  local host="${endpoint%%:*}"
  local port="${endpoint##*:}"

  # Default port if not specified
  [[ "$port" == "$host" ]] && port=443

  if command -v nc >/dev/null 2>&1; then
    if nc -z -w 5 "$host" "$port" 2>/dev/null; then
      register_check "$name connectivity" PASS "$endpoint reachable"
      return 0
    fi
  elif command -v timeout >/dev/null 2>&1; then
    if timeout 5 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
      register_check "$name connectivity" PASS "$endpoint reachable"
      return 0
    fi
  fi

  register_check "$name connectivity" WARN "cannot verify connectivity to $endpoint"
  return 1
}

# Print EDR agent not installed message and exit gracefully
# Usage: edr_not_installed "CrowdStrike Falcon"
edr_not_installed() {
  local agent_name="$1"
  register_check "$agent_name" SKIP "not installed on this system"
  print_summary
  exit "$EXIT_CODE"
}
