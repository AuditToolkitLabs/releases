#!/usr/bin/env bash
# carbon-black-audit.sh — VMware Carbon Black EDR/Cloud Agent Security Audit
#
# Compliance Mapping:
# - CIS Controls: 10.1, 10.2 (Malware Defenses)
# - NIST SP 800-53: SI-3 (Malicious Code Protection)
# - ISO 27001: A.12.2.1 (Controls against malware)
# - PCI DSS: 5.1, 5.2, 5.3 (Anti-malware)
#
# Checks:
# - Carbon Black agent installation
# - cbagentd service running and enabled
# - Sensor registration status
# - Backend connectivity
# - Policy status
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# Carbon Black paths
readonly CB_DIR="/var/opt/carbonblack"
readonly CB_BIN_DIR="/opt/carbonblack"
readonly CB_SERVICE="cbagentd"
readonly CBAGENTD="$CB_BIN_DIR/bin/cbagentd"

section "Carbon Black Agent Audit"

# Check if Carbon Black is installed
if [[ ! -d "$CB_DIR" ]] && [[ ! -d "$CB_BIN_DIR" ]]; then
  edr_not_installed "VMware Carbon Black"
fi

# Check installation directories
if [[ -d "$CB_DIR" ]]; then
  register_check "Carbon Black data directory" PASS "$CB_DIR"
else
  register_check "Carbon Black data directory" WARN "$CB_DIR not found"
fi

if [[ -d "$CB_BIN_DIR" ]]; then
  register_check "Carbon Black install directory" PASS "$CB_BIN_DIR"
else
  register_check "Carbon Black install directory" WARN "$CB_BIN_DIR not found"
fi

# Check cbagentd binary
if [[ -x "$CBAGENTD" ]]; then
  register_check "cbagentd binary" PASS "$CBAGENTD"
elif command -v cbagentd >/dev/null 2>&1; then
  register_check "cbagentd binary" PASS "$(command -v cbagentd)"
else
  register_check "cbagentd binary" FAIL "cbagentd not found"
fi

# Check service status
edr_service_check "$CB_SERVICE" "Carbon Black Agent"
edr_service_enabled "$CB_SERVICE" "Carbon Black Agent"

section "Carbon Black Registration & Status"

# Check sensor status via cfg.ini or status command
readonly CB_CFG="$CB_DIR/cfg.ini"
if [[ -f "$CB_CFG" ]]; then
  register_check "Carbon Black config" PASS "$CB_CFG exists"

  # Check if sensor ID is present
  if grep -qi "SensorId" "$CB_CFG" 2>/dev/null; then
    sensor_id=$(grep -i "SensorId" "$CB_CFG" 2>/dev/null | head -1 | cut -d'=' -f2 | tr -d ' ' || echo "")
    if [[ -n "$sensor_id" && "$sensor_id" != "0" ]]; then
      register_check "Sensor ID" PASS "registered"
    else
      register_check "Sensor ID" WARN "not registered"
    fi
  else
    register_check "Sensor ID" WARN "not found in config"
  fi

  # Check backend server configuration
  if grep -qi "BackendServer\|ServerUrl" "$CB_CFG" 2>/dev/null; then
    register_check "Backend server configured" PASS
  else
    register_check "Backend server configured" WARN "not found in config"
  fi
else
  register_check "Carbon Black config" WARN "$CB_CFG not found"
fi

# Check for sensor.pid file (indicates running process)
readonly CB_PID_FILE="$CB_DIR/sensor.pid"
if [[ -f "$CB_PID_FILE" ]]; then
  pid=$(cat "$CB_PID_FILE" 2>/dev/null || echo "")
  if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
    register_check "Sensor process" PASS "PID $pid running"
  else
    register_check "Sensor process" WARN "PID file exists but process not running"
  fi
else
  # Fallback to pgrep
  if pgrep -f cbagentd >/dev/null 2>&1; then
    register_check "Sensor process" PASS "running"
  else
    register_check "Sensor process" FAIL "not running"
  fi
fi

section "Carbon Black Protection Status"

# Check for event data directory
readonly CB_EVENT_DIR="$CB_DIR/eventdata"
if [[ -d "$CB_EVENT_DIR" ]]; then
  event_count=$(find "$CB_EVENT_DIR" -type f 2>/dev/null | wc -l)
  register_check "Event data directory" PASS "$event_count event files"
else
  register_check "Event data directory" SKIP "not found"
fi

# Check log directory for recent activity
readonly CB_LOG_DIR="/var/log/carbonblack"
if [[ -d "$CB_LOG_DIR" ]]; then
  recent_logs=$(find "$CB_LOG_DIR" -type f -mmin -60 2>/dev/null | wc -l)
  if [[ "$recent_logs" -gt 0 ]]; then
    register_check "Recent log activity" PASS "$recent_logs files updated in last hour"
  else
    register_check "Recent log activity" WARN "no recent log updates"
  fi
else
  register_check "Recent log activity" SKIP "log directory not found"
fi

# Check kernel module
if lsmod 2>/dev/null | grep -qi "cbsensor\|carbonblack"; then
  register_check "Carbon Black kernel module" PASS "loaded"
else
  register_check "Carbon Black kernel module" WARN "not detected"
fi

print_summary
exit "$EXIT_CODE"
