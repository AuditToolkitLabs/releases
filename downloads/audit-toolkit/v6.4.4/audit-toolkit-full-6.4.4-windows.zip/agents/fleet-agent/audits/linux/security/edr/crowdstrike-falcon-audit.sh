#!/usr/bin/env bash
# crowdstrike-falcon-audit.sh — CrowdStrike Falcon Sensor Security Audit
#
# Compliance Mapping:
# - CIS Controls: 10.1, 10.2 (Malware Defenses)
# - NIST SP 800-53: SI-3 (Malicious Code Protection)
# - ISO 27001: A.12.2.1 (Controls against malware)
# - PCI DSS: 5.1, 5.2, 5.3 (Anti-malware)
#
# Checks:
# - Falcon sensor installation and directory structure
# - falcon-sensor service running and enabled
# - Agent ID (AID) registered
# - Customer ID (CID) configured
# - Sensor version
# - RFM (Reduced Functionality Mode) state
# - Protection status
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# CrowdStrike paths and binaries
readonly CS_DIR="/opt/CrowdStrike"
readonly FALCONCTL="$CS_DIR/falconctl"
readonly CS_SERVICE="falcon-sensor"

section "CrowdStrike Falcon Sensor Audit"

# Check if CrowdStrike is installed
if [[ ! -d "$CS_DIR" ]] && ! command -v falconctl >/dev/null 2>&1; then
  edr_not_installed "CrowdStrike Falcon"
fi

# Check installation directory
edr_dir_exists "$CS_DIR" "CrowdStrike"

# Check falconctl binary
if [[ -x "$FALCONCTL" ]]; then
  register_check "falconctl binary" PASS "$FALCONCTL"
elif command -v falconctl >/dev/null 2>&1; then
  register_check "falconctl binary" PASS "$(command -v falconctl)"
else
  register_check "falconctl binary" FAIL "falconctl not found"
fi

# Check service status
edr_service_check "$CS_SERVICE" "Falcon Sensor"
edr_service_enabled "$CS_SERVICE" "Falcon Sensor"

section "CrowdStrike Agent Configuration"

# Get Agent ID (AID)
if aid_output=$(sudo "$FALCONCTL" -g --aid 2>/dev/null || "$FALCONCTL" -g --aid 2>/dev/null); then
  aid=$(echo "$aid_output" | grep -oE '[a-f0-9]{32}' | head -1 || echo "")
  if [[ -n "$aid" ]]; then
    register_check "Agent ID (AID)" PASS "${aid:0:8}...${aid: -8}"
  else
    register_check "Agent ID (AID)" WARN "not registered or empty"
  fi
else
  register_check "Agent ID (AID)" FAIL "unable to retrieve"
fi

# Get Customer ID (CID)
if cid_output=$(sudo "$FALCONCTL" -g --cid 2>/dev/null || "$FALCONCTL" -g --cid 2>/dev/null); then
  cid=$(echo "$cid_output" | grep -oE '[a-f0-9-]{32,36}' | head -1 || echo "")
  if [[ -n "$cid" ]]; then
    register_check "Customer ID (CID)" PASS "configured"
  else
    register_check "Customer ID (CID)" WARN "not configured"
  fi
else
  register_check "Customer ID (CID)" FAIL "unable to retrieve"
fi

# Get sensor version
if version_output=$(sudo "$FALCONCTL" -g --version 2>/dev/null || "$FALCONCTL" -g --version 2>/dev/null); then
  version=$(echo "$version_output" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
  register_check "Sensor version" PASS "$version"
else
  register_check "Sensor version" WARN "unable to retrieve"
fi

section "CrowdStrike Protection Status"

# Check RFM (Reduced Functionality Mode)
if rfm_output=$(sudo "$FALCONCTL" -g --rfm-state 2>/dev/null || "$FALCONCTL" -g --rfm-state 2>/dev/null); then
  if echo "$rfm_output" | grep -qi "false\|disabled\|0"; then
    register_check "Reduced Functionality Mode (RFM)" PASS "disabled (full protection)"
  elif echo "$rfm_output" | grep -qi "true\|enabled\|1"; then
    register_check "Reduced Functionality Mode (RFM)" FAIL "enabled (reduced protection)"
  else
    register_check "Reduced Functionality Mode (RFM)" WARN "unknown state: $rfm_output"
  fi
else
  register_check "Reduced Functionality Mode (RFM)" SKIP "unable to check"
fi

# Check provisioning token (optional but indicates proper deployment)
if token_output=$(sudo "$FALCONCTL" -g --provisioning-token 2>/dev/null || "$FALCONCTL" -g --provisioning-token 2>/dev/null); then
  if [[ -n "$token_output" ]] && ! echo "$token_output" | grep -qi "not set\|none"; then
    register_check "Provisioning token" PASS "configured"
  else
    register_check "Provisioning token" SKIP "not set (optional)"
  fi
else
  register_check "Provisioning token" SKIP "not available"
fi

# Check proxy settings (if configured)
if proxy_output=$(sudo "$FALCONCTL" -g --apd 2>/dev/null || "$FALCONCTL" -g --apd 2>/dev/null); then
  if echo "$proxy_output" | grep -qi "true\|enabled"; then
    register_check "Proxy detection" PASS "enabled"
  else
    register_check "Proxy detection" PASS "disabled (direct connection)"
  fi
else
  register_check "Proxy detection" SKIP "not available"
fi

# Check kernel module loaded
if lsmod 2>/dev/null | grep -qi "falcon"; then
  register_check "Falcon kernel module" PASS "loaded"
else
  # Some versions use eBPF instead of kernel module
  if [[ -d "/sys/fs/bpf" ]] && ls /sys/fs/bpf 2>/dev/null | grep -qi falcon; then
    register_check "Falcon kernel module" PASS "using eBPF"
  else
    register_check "Falcon kernel module" WARN "not detected (may use eBPF)"
  fi
fi

# Check sensor communication (look for recent log activity)
if [[ -d "/var/log/falcon" ]]; then
  recent_logs=$(find /var/log/falcon -type f -mmin -60 2>/dev/null | wc -l)
  if [[ "$recent_logs" -gt 0 ]]; then
    register_check "Recent sensor activity" PASS "$recent_logs log files updated in last hour"
  else
    register_check "Recent sensor activity" WARN "no recent log activity"
  fi
else
  register_check "Recent sensor activity" SKIP "/var/log/falcon not found"
fi

print_summary
exit "$EXIT_CODE"
