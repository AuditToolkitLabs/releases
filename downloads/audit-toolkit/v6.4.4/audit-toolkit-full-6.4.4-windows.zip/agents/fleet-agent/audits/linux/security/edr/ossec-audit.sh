#!/usr/bin/env bash
# ossec-audit.sh — OSSEC HIDS Agent Security Audit
#
# Compliance Mapping:
# - CIS Controls: 8.5, 8.6 (Log Management)
# - NIST SP 800-53: AU-2, AU-6, SI-4 (Monitoring)
# - ISO 27001: A.12.4 (Logging and Monitoring)
# - PCI DSS: 10.2, 10.5, 10.6 (Log Management)
#
# OSSEC is the predecessor to Wazuh and provides:
# - Host-based intrusion detection
# - Log analysis
# - File integrity monitoring
# - Rootkit detection
#
# Checks:
# - OSSEC installation
# - ossec-hids service status
# - Agent registration
# - Active modules
#
# @elevation: partial
# @elevation-reason: OSSEC/HIDS service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# OSSEC paths (can vary by installation method)
readonly OSSEC_DIR="/var/ossec"
readonly OSSEC_BIN="$OSSEC_DIR/bin"
readonly OSSEC_CONF="$OSSEC_DIR/etc/ossec.conf"

section "OSSEC HIDS Agent Audit"

# Check if OSSEC is installed
if [[ ! -d "$OSSEC_DIR" ]]; then
  edr_not_installed "OSSEC HIDS"
fi

# Distinguish between OSSEC and Wazuh (Wazuh has wazuh-control)
if [[ -x "$OSSEC_BIN/wazuh-control" ]]; then
  register_check "OSSEC type" SKIP "This is Wazuh, not OSSEC - use wazuh-agent-audit.sh"
  print_summary
  exit "$EXIT_CODE"
fi

# Check installation directory
edr_dir_exists "$OSSEC_DIR" "OSSEC"
edr_dir_exists "$OSSEC_BIN" "OSSEC binaries"

# Check key binaries
for bin in "ossec-control" "agent-auth" "ossec-agentd"; do
  if [[ -x "$OSSEC_BIN/$bin" ]]; then
    register_check "$bin binary" PASS
  else
    register_check "$bin binary" WARN "not found"
  fi
done

# Check service status
edr_service_check "ossec-hids" "OSSEC HIDS"
edr_service_check "ossec" "OSSEC"

section "OSSEC Agent Status"

# Check agent status via ossec-control
if [[ -x "$OSSEC_BIN/ossec-control" ]]; then
  control_status=$(sudo "$OSSEC_BIN/ossec-control" status 2>/dev/null || "$OSSEC_BIN/ossec-control" status 2>/dev/null || echo "")
  if echo "$control_status" | grep -qi "running"; then
    running_count=$(echo "$control_status" | grep -ci "running" || echo "0")
    register_check "OSSEC processes" PASS "$running_count running"
  else
    register_check "OSSEC processes" WARN "no processes running"
  fi
fi

# Check client.keys for registration
readonly CLIENT_KEYS="$OSSEC_DIR/etc/client.keys"
if [[ -f "$CLIENT_KEYS" ]]; then
  if [[ -s "$CLIENT_KEYS" ]]; then
    agent_id=$(awk '{print $1}' "$CLIENT_KEYS" 2>/dev/null | head -1 || echo "")
    if [[ -n "$agent_id" ]]; then
      register_check "Agent registration" PASS "Agent ID: $agent_id"
    else
      register_check "Agent registration" WARN "client.keys exists but empty"
    fi
  else
    register_check "Agent registration" FAIL "not registered"
  fi
else
  register_check "Agent registration" FAIL "client.keys not found"
fi

section "OSSEC Configuration"

if [[ -f "$OSSEC_CONF" ]]; then
  register_check "Configuration file" PASS

  # Check server/manager address
  server_ip=$(grep -oP '(?<=<server-ip>)[^<]+' "$OSSEC_CONF" 2>/dev/null || \
              grep -oP '(?<=<address>)[^<]+' "$OSSEC_CONF" 2>/dev/null || echo "")
  if [[ -n "$server_ip" ]]; then
    register_check "Server address" PASS "$server_ip"
  else
    register_check "Server address" WARN "not configured"
  fi

  # Check syscheck
  if grep -q "<syscheck>" "$OSSEC_CONF" 2>/dev/null; then
    register_check "Syscheck (FIM)" PASS "configured"
  else
    register_check "Syscheck (FIM)" WARN "not configured"
  fi

  # Check rootcheck
  if grep -q "<rootcheck>" "$OSSEC_CONF" 2>/dev/null; then
    register_check "Rootcheck" PASS "configured"
  else
    register_check "Rootcheck" SKIP "not configured"
  fi

  # Check log files
  log_count=$(grep -c "<localfile>" "$OSSEC_CONF" 2>/dev/null || echo "0")
  if [[ "$log_count" -gt 0 ]]; then
    register_check "Log monitoring" PASS "$log_count sources"
  else
    register_check "Log monitoring" WARN "no log sources"
  fi
else
  register_check "Configuration file" FAIL "ossec.conf not found"
fi

section "OSSEC Health"

# Check logs
readonly OSSEC_LOGS="$OSSEC_DIR/logs"
if [[ -d "$OSSEC_LOGS" ]]; then
  if [[ -f "$OSSEC_LOGS/ossec.log" ]]; then
    log_size=$(stat -c %s "$OSSEC_LOGS/ossec.log" 2>/dev/null || echo "0")
    recent=$(tail -50 "$OSSEC_LOGS/ossec.log" 2>/dev/null | grep -c "$(date +%Y/%m/%d)" || echo "0")
    if [[ "$recent" -gt 0 ]]; then
      register_check "Recent activity" PASS "$recent log entries today"
    else
      register_check "Recent activity" WARN "no entries today"
    fi
  else
    register_check "Recent activity" WARN "ossec.log not found"
  fi
fi

# Check version
version_file="$OSSEC_DIR/etc/internal_options.conf"
if [[ -f "$version_file" ]]; then
  register_check "OSSEC installed" PASS
fi

print_summary
exit "$EXIT_CODE"
