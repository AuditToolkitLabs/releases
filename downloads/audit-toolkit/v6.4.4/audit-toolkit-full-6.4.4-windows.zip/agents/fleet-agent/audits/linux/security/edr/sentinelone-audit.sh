#!/usr/bin/env bash
# sentinelone-audit.sh — SentinelOne Agent Security Audit
#
# Compliance Mapping:
# - CIS Controls: 10.1, 10.2 (Malware Defenses)
# - NIST SP 800-53: SI-3 (Malicious Code Protection)
# - ISO 27001: A.12.2.1 (Controls against malware)
# - PCI DSS: 5.1, 5.2, 5.3 (Anti-malware)
#
# Checks:
# - SentinelOne agent installation
# - sentinelone service running and enabled
# - Agent registration and connectivity
# - Protection policy status
# - Real-time protection status
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# SentinelOne paths
readonly S1_DIR="/opt/sentinelone"
readonly SENTINELCTL="$S1_DIR/bin/sentinelctl"
readonly S1_SERVICE="sentinelone"

section "SentinelOne Agent Audit"

# Check if SentinelOne is installed
if [[ ! -d "$S1_DIR" ]] && ! command -v sentinelctl >/dev/null 2>&1; then
  edr_not_installed "SentinelOne"
fi

# Check installation directory
edr_dir_exists "$S1_DIR" "SentinelOne"

# Check sentinelctl binary
if [[ -x "$SENTINELCTL" ]]; then
  register_check "sentinelctl binary" PASS "$SENTINELCTL"
elif command -v sentinelctl >/dev/null 2>&1; then
  register_check "sentinelctl binary" PASS "$(command -v sentinelctl)"
else
  register_check "sentinelctl binary" FAIL "sentinelctl not found"
fi

# Check service status
edr_service_check "$S1_SERVICE" "SentinelOne Agent"
edr_service_enabled "$S1_SERVICE" "SentinelOne Agent"

section "SentinelOne Agent Status"

# Get agent status using sentinelctl
get_ctl() {
  sudo "$SENTINELCTL" "$@" 2>/dev/null || "$SENTINELCTL" "$@" 2>/dev/null || echo ""
}

# Check agent overall status
status_output=$(get_ctl status)
if [[ -n "$status_output" ]]; then
  # Parse key status fields
  if echo "$status_output" | grep -qi "running\|active\|connected"; then
    register_check "Agent status" PASS "running"
  else
    register_check "Agent status" WARN "status unclear"
  fi
else
  register_check "Agent status" WARN "unable to get status"
fi

# Check agent ID
agent_id=$(get_ctl management status 2>/dev/null | grep -i "agent.id\|uuid" | head -1 || echo "")
if [[ -n "$agent_id" ]]; then
  register_check "Agent ID" PASS "registered"
else
  # Try alternative method
  agent_id=$(get_ctl version-info 2>/dev/null | grep -i "agent.*id" | head -1 || echo "")
  if [[ -n "$agent_id" ]]; then
    register_check "Agent ID" PASS "registered"
  else
    register_check "Agent ID" WARN "unable to verify registration"
  fi
fi

# Check management connectivity
mgmt_status=$(get_ctl management status 2>/dev/null)
if echo "$mgmt_status" | grep -qi "connected\|online"; then
  register_check "Management connectivity" PASS "connected"
elif echo "$mgmt_status" | grep -qi "disconnected\|offline"; then
  register_check "Management connectivity" FAIL "disconnected"
else
  register_check "Management connectivity" WARN "status unknown"
fi

section "SentinelOne Protection Status"

# Check protection status
protection=$(get_ctl control status 2>/dev/null)
if echo "$protection" | grep -qi "enabled\|active\|on"; then
  register_check "Protection enabled" PASS
elif echo "$protection" | grep -qi "disabled\|off"; then
  register_check "Protection enabled" FAIL "protection disabled"
else
  register_check "Protection enabled" WARN "status unknown"
fi

# Check policy
policy_info=$(get_ctl management policy 2>/dev/null | head -3)
if [[ -n "$policy_info" ]]; then
  register_check "Policy configured" PASS
else
  register_check "Policy configured" WARN "unable to verify"
fi

# Check anti-tamper
tamper_status=$(get_ctl control anti-tamper status 2>/dev/null || echo "")
if echo "$tamper_status" | grep -qi "enabled\|on\|true"; then
  register_check "Anti-tamper protection" PASS "enabled"
elif echo "$tamper_status" | grep -qi "disabled\|off\|false"; then
  register_check "Anti-tamper protection" WARN "disabled"
else
  register_check "Anti-tamper protection" SKIP "status unknown"
fi

# Check version
version=$(get_ctl version-info 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
if [[ "$version" != "unknown" ]]; then
  register_check "Agent version" PASS "$version"
else
  register_check "Agent version" WARN "unable to determine"
fi

# Check kernel module/eBPF
if lsmod 2>/dev/null | grep -qi "sentinel"; then
  register_check "Kernel module" PASS "loaded"
else
  register_check "Kernel module" WARN "not detected (may use eBPF)"
fi

# Check for recent scan activity
scan_status=$(get_ctl scan status 2>/dev/null || echo "")
if [[ -n "$scan_status" ]]; then
  if echo "$scan_status" | grep -qi "idle\|completed"; then
    register_check "Scan status" PASS "ready/idle"
  elif echo "$scan_status" | grep -qi "running\|in.progress"; then
    register_check "Scan status" PASS "scan in progress"
  else
    register_check "Scan status" PASS "$scan_status"
  fi
else
  register_check "Scan status" SKIP "unable to check"
fi

print_summary
exit "$EXIT_CODE"
