#!/usr/bin/env bash
# sophos-audit.sh — Sophos Endpoint Protection Security Audit
#
# Compliance Mapping:
# - CIS Controls: 10.1, 10.2 (Malware Defenses)
# - NIST SP 800-53: SI-3 (Malicious Code Protection)
# - ISO 27001: A.12.2.1 (Controls against malware)
# - PCI DSS: 5.1, 5.2, 5.3 (Anti-malware)
#
# Checks:
# - Sophos installation (SPL or SAV)
# - Service status (mcs_agent, savd, etc.)
# - Update status
# - On-access scanning status
# - Threat detection capability
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=_edr-common.sh
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# Sophos paths (SPL - Sophos Protection Linux, and legacy SAV)
readonly SPL_DIR="/opt/sophos-spl"
readonly SAV_DIR="/opt/sophos-av"
readonly SAVSCAN="/opt/sophos-av/bin/savscan"

section "Sophos Endpoint Protection Audit"

# Detect which Sophos product is installed
SOPHOS_TYPE=""
if [[ -d "$SPL_DIR" ]]; then
  SOPHOS_TYPE="SPL"
  register_check "Sophos installation" PASS "Sophos Protection Linux (SPL)"
elif [[ -d "$SAV_DIR" ]]; then
  SOPHOS_TYPE="SAV"
  register_check "Sophos installation" PASS "Sophos Anti-Virus (SAV)"
else
  edr_not_installed "Sophos Endpoint Protection"
fi

# Check installation directories
if [[ "$SOPHOS_TYPE" == "SPL" ]]; then
  edr_dir_exists "$SPL_DIR" "Sophos SPL"

  # Check SPL components
  if [[ -d "$SPL_DIR/base" ]]; then
    register_check "SPL base component" PASS
  else
    register_check "SPL base component" WARN "not found"
  fi
  if [[ -d "$SPL_DIR/plugins" ]]; then
    register_check "SPL plugins" PASS
  else
    register_check "SPL plugins" WARN "not found"
  fi
else
  edr_dir_exists "$SAV_DIR" "Sophos SAV"
fi

section "Sophos Services"

if [[ "$SOPHOS_TYPE" == "SPL" ]]; then
  # SPL services
  spl_services=(
    "sophos-spl:Sophos SPL Management"
    "sophos-spl-av:Sophos Anti-Virus"
    "sophos-spl-mcs:Sophos Management Communication"
    "sophos-spl-update:Sophos Update Service"
  )

  for svc_entry in "${spl_services[@]}"; do
    svc_name="${svc_entry%%:*}"
    svc_display="${svc_entry#*:}"
    edr_service_check "$svc_name" "Sophos $svc_display"
  done
else
  # SAV services
  edr_service_check "sav-protect" "Sophos On-Access"
  edr_service_check "savd" "Sophos AV Daemon"
fi

section "Sophos Configuration & Status"

if [[ "$SOPHOS_TYPE" == "SPL" ]]; then
  # Check SPL status via CLI
  readonly SPL_CLI="$SPL_DIR/bin/sophos_spl"
  if [[ -x "$SPL_CLI" ]]; then
    # Check management status
    mgmt_status=$(sudo "$SPL_CLI" management status 2>/dev/null || "$SPL_CLI" management status 2>/dev/null || echo "")
    if echo "$mgmt_status" | grep -qi "connected\|registered"; then
      register_check "Management connection" PASS "connected"
    elif [[ -n "$mgmt_status" ]]; then
      register_check "Management connection" WARN "$mgmt_status"
    else
      register_check "Management connection" WARN "unable to determine"
    fi
  fi

  # Check SPL version
  if [[ -f "$SPL_DIR/base/VERSION.ini" ]]; then
    version=$(grep -i "PRODUCT_VERSION" "$SPL_DIR/base/VERSION.ini" 2>/dev/null | cut -d'=' -f2 | tr -d ' "' || echo "unknown")
    register_check "SPL version" PASS "$version"
  else
    register_check "SPL version" WARN "unable to determine"
  fi

else
  # SAV status checks
  if [[ -x "$SAVSCAN" ]]; then
    register_check "savscan binary" PASS

    # Get version
    version=$("$SAVSCAN" --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "unknown")
    register_check "SAV version" PASS "$version"
  else
    register_check "savscan binary" FAIL "not found"
  fi

  # Check savconfig for on-access status
  if command -v savconfig >/dev/null 2>&1; then
    onaccess=$(savconfig query OnAccessScanEnabled 2>/dev/null || echo "")
    if [[ "$onaccess" == "true" ]]; then
      register_check "On-access scanning" PASS "enabled"
    elif [[ "$onaccess" == "false" ]]; then
      register_check "On-access scanning" FAIL "disabled"
    else
      register_check "On-access scanning" WARN "status unknown"
    fi
  fi
fi

section "Sophos Update & Definition Status"

if [[ "$SOPHOS_TYPE" == "SPL" ]]; then
  # Check update status
  update_status_file="$SPL_DIR/base/update/cache/status.json"
  if [[ -f "$update_status_file" ]]; then
    # Check if recently updated (within 24 hours)
    update_age=$((($(date +%s) - $(stat -c %Y "$update_status_file" 2>/dev/null || echo 0)) / 3600))
    if [[ "$update_age" -lt 24 ]]; then
      register_check "Update status" PASS "updated ${update_age}h ago"
    elif [[ "$update_age" -lt 72 ]]; then
      register_check "Update status" WARN "last update ${update_age}h ago"
    else
      register_check "Update status" FAIL "stale (${update_age}h ago)"
    fi
  else
    register_check "Update status" WARN "unable to determine"
  fi
else
  # SAV update check
  sav_data_dir="$SAV_DIR/lib/sav"
  if [[ -d "$sav_data_dir" ]]; then
    vdl_files=$(find "$sav_data_dir" -name "*.vdl" -mtime -1 2>/dev/null | wc -l)
    if [[ "$vdl_files" -gt 0 ]]; then
      register_check "Virus definitions" PASS "updated within 24h"
    else
      register_check "Virus definitions" WARN "may be outdated"
    fi
  fi
fi

# Check log activity
log_dirs=("$SPL_DIR/logs" "$SAV_DIR/log" "/var/log/sophos")
for log_dir in "${log_dirs[@]}"; do
  if [[ -d "$log_dir" ]]; then
    recent_logs=$(find "$log_dir" -type f -mmin -60 2>/dev/null | wc -l)
    if [[ "$recent_logs" -gt 0 ]]; then
      register_check "Recent log activity" PASS "$recent_logs files in last hour"
      break
    fi
  fi
done

print_summary
exit "$EXIT_CODE"
