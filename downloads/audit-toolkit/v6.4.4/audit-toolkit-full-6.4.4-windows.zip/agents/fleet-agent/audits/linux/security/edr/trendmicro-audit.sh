#!/usr/bin/env bash
# trendmicro-audit.sh — Trend Micro Deep Security Agent Audit
#
# Compliance Mapping:
# - CIS Controls: 10.1, 10.2 (Malware Defenses)
# - NIST SP 800-53: SI-3, SI-4 (Malicious Code Protection)
# - ISO 27001: A.12.2.1 (Controls against malware)
# - PCI DSS: 5.1, 5.2, 5.3, 11.4 (Anti-malware, IDS)
#
# Trend Micro Deep Security provides:
# - Anti-malware
# - Intrusion Prevention (IPS)
# - Firewall
# - Integrity Monitoring
# - Log Inspection
#
# Checks:
# - ds_agent installation
# - Service status
# - Agent registration
# - Module status (AM, FW, IPS, IM, LI)
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# Trend Micro paths
readonly TM_DIR="/opt/ds_agent"
readonly TM_BIN="$TM_DIR"
readonly DSA_CONTROL="$TM_BIN/dsa_control"
readonly DSA_QUERY="$TM_BIN/dsa_query"
readonly TM_SERVICE="ds_agent"

section "Trend Micro Deep Security Agent Audit"

# Check if Trend Micro is installed
if [[ ! -d "$TM_DIR" ]] && ! command -v dsa_control >/dev/null 2>&1; then
  edr_not_installed "Trend Micro Deep Security"
fi

# Check installation directory
edr_dir_exists "$TM_DIR" "Deep Security Agent"

# Check binaries
if [[ -x "$DSA_CONTROL" ]]; then
  register_check "dsa_control binary" PASS
elif command -v dsa_control >/dev/null 2>&1; then
  register_check "dsa_control binary" PASS "$(command -v dsa_control)"
else
  register_check "dsa_control binary" FAIL "not found"
fi

if [[ -x "$DSA_QUERY" ]]; then
  register_check "dsa_query binary" PASS
else
  register_check "dsa_query binary" WARN "not found"
fi

# Check service status
edr_service_check "$TM_SERVICE" "Deep Security Agent"
edr_service_enabled "$TM_SERVICE" "Deep Security Agent"

section "Deep Security Agent Status"

# Helper function to run dsa_control
run_dsa_control() {
  sudo "$DSA_CONTROL" "$@" 2>/dev/null || "$DSA_CONTROL" "$@" 2>/dev/null || echo ""
}

# Helper function to run dsa_query
run_dsa_query() {
  sudo "$DSA_QUERY" "$@" 2>/dev/null || "$DSA_QUERY" "$@" 2>/dev/null || echo ""
}

# Check agent status
agent_status=$(run_dsa_control -s)
if [[ -n "$agent_status" ]]; then
  if echo "$agent_status" | grep -qi "running"; then
    register_check "Agent status" PASS "running"
  else
    register_check "Agent status" WARN "$agent_status"
  fi
else
  register_check "Agent status" WARN "unable to get status"
fi

# Check manager connectivity
manager_status=$(run_dsa_control -m)
if echo "$manager_status" | grep -qi "managed\|activated\|online"; then
  register_check "Manager connection" PASS "managed"
elif echo "$manager_status" | grep -qi "unmanaged\|offline"; then
  register_check "Manager connection" FAIL "not managed"
else
  register_check "Manager connection" WARN "status unknown"
fi

section "Deep Security Protection Modules"

# Query module status using dsa_query
# Anti-Malware
am_status=$(run_dsa_query -c GetComponentInfo -c "Anti-Malware" 2>/dev/null || echo "")
if echo "$am_status" | grep -qi "enabled\|on\|active"; then
  register_check "Anti-Malware module" PASS "enabled"
elif echo "$am_status" | grep -qi "disabled\|off"; then
  register_check "Anti-Malware module" WARN "disabled"
else
  # Try alternative check
  if run_dsa_control -s 2>/dev/null | grep -qi "Anti-Malware.*On"; then
    register_check "Anti-Malware module" PASS "enabled"
  else
    register_check "Anti-Malware module" SKIP "status unknown"
  fi
fi

# Intrusion Prevention (IPS)
ips_check=$(run_dsa_control -s 2>/dev/null | grep -i "Intrusion Prevention\|IPS" || echo "")
if echo "$ips_check" | grep -qi "on\|enabled\|active"; then
  register_check "Intrusion Prevention (IPS)" PASS "enabled"
elif echo "$ips_check" | grep -qi "off\|disabled"; then
  register_check "Intrusion Prevention (IPS)" WARN "disabled"
else
  register_check "Intrusion Prevention (IPS)" SKIP "status unknown"
fi

# Firewall
fw_check=$(run_dsa_control -s 2>/dev/null | grep -i "Firewall" || echo "")
if echo "$fw_check" | grep -qi "on\|enabled\|active"; then
  register_check "Firewall module" PASS "enabled"
elif echo "$fw_check" | grep -qi "off\|disabled"; then
  register_check "Firewall module" WARN "disabled"
else
  register_check "Firewall module" SKIP "status unknown"
fi

# Integrity Monitoring
im_check=$(run_dsa_control -s 2>/dev/null | grep -i "Integrity Monitoring\|IM" || echo "")
if echo "$im_check" | grep -qi "on\|enabled\|active"; then
  register_check "Integrity Monitoring" PASS "enabled"
elif echo "$im_check" | grep -qi "off\|disabled"; then
  register_check "Integrity Monitoring" WARN "disabled"
else
  register_check "Integrity Monitoring" SKIP "status unknown"
fi

# Log Inspection
li_check=$(run_dsa_control -s 2>/dev/null | grep -i "Log Inspection\|LI" || echo "")
if echo "$li_check" | grep -qi "on\|enabled\|active"; then
  register_check "Log Inspection" PASS "enabled"
elif echo "$li_check" | grep -qi "off\|disabled"; then
  register_check "Log Inspection" WARN "disabled"
else
  register_check "Log Inspection" SKIP "status unknown"
fi

section "Deep Security Agent Health"

# Check agent version
version=$(run_dsa_query -c GetAgentVersion 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
if [[ -n "$version" ]]; then
  register_check "Agent version" PASS "$version"
else
  # Try from package
  if command -v rpm >/dev/null 2>&1; then
    version=$(rpm -q ds_agent 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
  elif command -v dpkg >/dev/null 2>&1; then
    version=$(dpkg -l ds-agent 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
  fi
  if [[ -n "$version" ]]; then
    register_check "Agent version" PASS "$version"
  else
    register_check "Agent version" WARN "unable to determine"
  fi
fi

# Check last security update
update_status=$(run_dsa_query -c GetSecurityUpdateStatus 2>/dev/null || echo "")
if [[ -n "$update_status" ]]; then
  register_check "Security updates" PASS "configured"
else
  register_check "Security updates" SKIP "status unknown"
fi

# Check logs
readonly TM_LOG_DIR="/var/opt/ds_agent/log"
if [[ -d "$TM_LOG_DIR" ]]; then
  recent_logs=$(find "$TM_LOG_DIR" -type f -mmin -60 2>/dev/null | wc -l)
  if [[ "$recent_logs" -gt 0 ]]; then
    register_check "Recent log activity" PASS "$recent_logs files in last hour"
  else
    register_check "Recent log activity" WARN "no recent log activity"
  fi
else
  register_check "Recent log activity" SKIP "log directory not found"
fi

# Check kernel module
if lsmod 2>/dev/null | grep -qi "tmcomm\|ds_am"; then
  register_check "Kernel module" PASS "loaded"
else
  register_check "Kernel module" WARN "not detected"
fi

print_summary
exit "$EXIT_CODE"
