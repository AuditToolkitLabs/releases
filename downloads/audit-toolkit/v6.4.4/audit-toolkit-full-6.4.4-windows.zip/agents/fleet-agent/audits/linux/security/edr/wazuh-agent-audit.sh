#!/usr/bin/env bash
# wazuh-agent-audit.sh — Wazuh Agent Security Audit
#
# Compliance Mapping:
# - CIS Controls: 8.5, 8.6 (Log Management)
# - NIST SP 800-53: AU-2, AU-6, SI-4 (Monitoring)
# - ISO 27001: A.12.4 (Logging and Monitoring)
# - PCI DSS: 10.2, 10.5, 10.6 (Log Management)
#
# Wazuh is an open-source SIEM/XDR platform that provides:
# - Intrusion detection
# - Log analysis
# - File integrity monitoring
# - Vulnerability detection
# - Configuration assessment
#
# Checks:
# - Wazuh agent installation
# - wazuh-agent service running and enabled
# - Agent registration with manager
# - Manager connectivity
# - Active modules (syscheck, rootcheck, etc.)
#
# @elevation: partial
# @elevation-reason: Agent service checks may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_edr-common.sh"

setup_colors

# Wazuh paths
readonly WAZUH_DIR="/var/ossec"
readonly WAZUH_BIN="$WAZUH_DIR/bin"
readonly WAZUH_CONF="$WAZUH_DIR/etc/ossec.conf"
readonly WAZUH_SERVICE="wazuh-agent"

section "Wazuh Agent Audit"

# Check if Wazuh is installed
if [[ ! -d "$WAZUH_DIR" ]]; then
  edr_not_installed "Wazuh Agent"
fi

# Check installation directory
edr_dir_exists "$WAZUH_DIR" "Wazuh"
edr_dir_exists "$WAZUH_BIN" "Wazuh binaries"

# Check key binaries
for bin in "wazuh-control" "agent-auth" "wazuh-agentd"; do
  if [[ -x "$WAZUH_BIN/$bin" ]]; then
    register_check "$bin binary" PASS
  else
    register_check "$bin binary" WARN "not found"
  fi
done

# Check service status
edr_service_check "$WAZUH_SERVICE" "Wazuh Agent"
edr_service_enabled "$WAZUH_SERVICE" "Wazuh Agent"

section "Wazuh Agent Registration"

# Check agent status via wazuh-control
if [[ -x "$WAZUH_BIN/wazuh-control" ]]; then
  control_status=$(sudo "$WAZUH_BIN/wazuh-control" status 2>/dev/null || "$WAZUH_BIN/wazuh-control" status 2>/dev/null || echo "")
  if echo "$control_status" | grep -qi "running"; then
    register_check "Wazuh control status" PASS "services running"
  else
    register_check "Wazuh control status" WARN "some services may be stopped"
  fi
fi

# Check agent client.keys (registration file)
readonly CLIENT_KEYS="$WAZUH_DIR/etc/client.keys"
if [[ -f "$CLIENT_KEYS" ]]; then
  if [[ -s "$CLIENT_KEYS" ]]; then
    # Get agent ID from client.keys
    agent_id=$(awk '{print $1}' "$CLIENT_KEYS" 2>/dev/null | head -1 || echo "")
    agent_name=$(awk '{print $2}' "$CLIENT_KEYS" 2>/dev/null | head -1 || echo "")
    if [[ -n "$agent_id" && "$agent_id" != "000" ]]; then
      register_check "Agent registration" PASS "ID: $agent_id, Name: $agent_name"
    else
      register_check "Agent registration" WARN "registered but ID is 000 (manager mode)"
    fi
  else
    register_check "Agent registration" FAIL "client.keys is empty (not registered)"
  fi
else
  register_check "Agent registration" FAIL "client.keys not found"
fi

section "Wazuh Manager Connection"

# Parse manager address from ossec.conf
if [[ -f "$WAZUH_CONF" ]]; then
  register_check "Configuration file" PASS "$WAZUH_CONF"

  # Extract manager address
  manager_addr=$(grep -oP '(?<=<address>)[^<]+' "$WAZUH_CONF" 2>/dev/null | head -1 || echo "")
  if [[ -n "$manager_addr" ]]; then
    register_check "Manager address" PASS "$manager_addr"

    # Test connectivity to manager (default port 1514)
    if command -v nc >/dev/null 2>&1; then
      if nc -z -w 5 "$manager_addr" 1514 2>/dev/null; then
        register_check "Manager connectivity" PASS "port 1514 reachable"
      else
        register_check "Manager connectivity" WARN "cannot reach $manager_addr:1514"
      fi
    else
      register_check "Manager connectivity" SKIP "nc not available for connectivity test"
    fi
  else
    register_check "Manager address" WARN "not found in config"
  fi

  # Check enrollment settings
  if grep -q "<enrollment>" "$WAZUH_CONF" 2>/dev/null; then
    register_check "Auto-enrollment configured" PASS
  else
    register_check "Auto-enrollment configured" SKIP "not configured"
  fi
else
  register_check "Configuration file" FAIL "ossec.conf not found"
fi

section "Wazuh Active Modules"

# Check which modules are enabled in config
if [[ -f "$WAZUH_CONF" ]]; then
  # Syscheck (file integrity monitoring)
  if grep -q "<syscheck>" "$WAZUH_CONF" 2>/dev/null; then
    if grep -q "<disabled>no</disabled>" "$WAZUH_CONF" 2>/dev/null || ! grep -q "<disabled>yes</disabled>" "$WAZUH_CONF" 2>/dev/null; then
      register_check "Syscheck (FIM)" PASS "enabled"
    else
      register_check "Syscheck (FIM)" WARN "disabled in config"
    fi
  else
    register_check "Syscheck (FIM)" WARN "not configured"
  fi

  # Rootcheck
  if grep -q "<rootcheck>" "$WAZUH_CONF" 2>/dev/null; then
    register_check "Rootcheck" PASS "configured"
  else
    register_check "Rootcheck" SKIP "not configured"
  fi

  # Log collection
  log_collectors=$(grep -c "<localfile>" "$WAZUH_CONF" 2>/dev/null || echo "0")
  if [[ "$log_collectors" -gt 0 ]]; then
    register_check "Log collection" PASS "$log_collectors sources configured"
  else
    register_check "Log collection" WARN "no local files configured"
  fi

  # Vulnerability detection
  if grep -q "<vulnerability-detection>" "$WAZUH_CONF" 2>/dev/null; then
    register_check "Vulnerability detection" PASS "configured"
  else
    register_check "Vulnerability detection" SKIP "not configured"
  fi

  # Active response
  if grep -q "<active-response>" "$WAZUH_CONF" 2>/dev/null; then
    register_check "Active response" PASS "configured"
  else
    register_check "Active response" SKIP "not configured"
  fi
fi

section "Wazuh Agent Health"

# Check agent version
if [[ -x "$WAZUH_BIN/wazuh-control" ]]; then
  version=$(sudo "$WAZUH_BIN/wazuh-control" info 2>/dev/null | grep -i version | head -1 || echo "")
  if [[ -n "$version" ]]; then
    register_check "Agent version" PASS "$version"
  else
    version_file="$WAZUH_DIR/etc/internal_options.conf"
    if [[ -f "$version_file" ]]; then
      register_check "Agent version" PASS "installed"
    fi
  fi
fi

# Check log directory and recent activity
readonly WAZUH_LOGS="$WAZUH_DIR/logs"
if [[ -d "$WAZUH_LOGS" ]]; then
  # Check ossec.log for recent activity
  if [[ -f "$WAZUH_LOGS/ossec.log" ]]; then
    recent_entries=$(tail -100 "$WAZUH_LOGS/ossec.log" 2>/dev/null | grep -c "$(date +%Y/%m/%d)" || echo "0")
    if [[ "$recent_entries" -gt 0 ]]; then
      register_check "Recent log activity" PASS "$recent_entries entries today"
    else
      register_check "Recent log activity" WARN "no entries today"
    fi
  fi

  # Check for alerts
  if [[ -f "$WAZUH_LOGS/alerts/alerts.log" ]]; then
    register_check "Alerts log" PASS "exists"
  else
    register_check "Alerts log" SKIP "not found (normal for agent-only)"
  fi
fi

# Check queue status
readonly WAZUH_QUEUE="$WAZUH_DIR/queue"
if [[ -d "$WAZUH_QUEUE" ]]; then
  queue_files=$(find "$WAZUH_QUEUE" -type f 2>/dev/null | wc -l)
  register_check "Queue directory" PASS "$queue_files files"
fi

print_summary
exit "$EXIT_CODE"
