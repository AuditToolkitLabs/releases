#!/usr/bin/env bash
# suid-sgid-audit.sh — SUID/SGID File Permissions Audit
#
# Compliance Mapping:
# - CIS Benchmark: 6.1.13-6.1.14 (SUID/SGID Programs)
# - NIST SP 800-53: AC-6 (Least Privilege)
# - ISO 27001: A.9.4.4 (Privilege Access Rights)
# - PCI DSS: 7.1-7.2 (Access Control)
# - DISA STIG: V-204402 (SUID/SGID Files)
#
# Checks:
# - Identifies all SUID/SGID files
# - Compares against known-good baseline
# - Flags unexpected SUID/SGID binaries
# - Checks for world-writable SUID/SGID files
#
# @elevation: root
# @elevation-reason: Finding SUID/SGID files across all volumes requires root
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

# Known legitimate SUID binaries (common across distros)
# This list should be customized per organization
KNOWN_SUID_BINARIES=(
  /usr/bin/passwd
  /usr/bin/chfn
  /usr/bin/chsh
  /usr/bin/gpasswd
  /usr/bin/newgrp
  /usr/bin/su
  /usr/bin/sudo
  /usr/bin/mount
  /usr/bin/umount
  /usr/bin/crontab
  /usr/bin/at
  /usr/bin/fusermount
  /usr/bin/fusermount3
  /usr/bin/pkexec
  /usr/bin/ssh-agent
  /usr/bin/expiry
  /usr/bin/chage
  /usr/bin/wall
  /usr/bin/write
  /usr/bin/ssh-keysign
  /usr/lib/dbus-1.0/dbus-daemon-launch-helper
  /usr/lib/openssh/ssh-keysign
  /usr/lib/polkit-1/polkit-agent-helper-1
  /usr/libexec/polkit-agent-helper-1
  /usr/libexec/dbus-daemon-launch-helper
  /usr/libexec/openssh/ssh-keysign
  /usr/sbin/pam_timestamp_check
  /usr/sbin/unix_chkpwd
  /usr/sbin/usernetctl
  /bin/ping
  /bin/ping6
  /bin/su
  /bin/mount
  /bin/umount
  /sbin/mount.nfs
  /sbin/unix_chkpwd
  /sbin/pam_timestamp_check
)

# Create associative array for fast lookup
declare -A KNOWN_SUID_MAP
for binary in "${KNOWN_SUID_BINARIES[@]}"; do
  KNOWN_SUID_MAP["$binary"]=1
done

section "SUID Binary Audit"

# Find all SUID files
suid_count=0
unexpected_suid=0
suid_worldwrite=0

log_info "Scanning filesystem for SUID files..."

while IFS= read -r -d '' file; do
  ((suid_count++)) || true

  # Check if on known list
  if [[ -z "${KNOWN_SUID_MAP[$file]:-}" ]]; then
    # Not on known list - check if it's a symlink to known
    real_path=$(readlink -f "$file" 2>/dev/null || echo "$file")
    if [[ -z "${KNOWN_SUID_MAP[$real_path]:-}" ]]; then
      ((unexpected_suid++)) || true
      register_check "SUID: $file" WARN "not on known list"
    fi
  fi

  # Check for world-writable SUID
  if [[ -w "$file" ]] 2>/dev/null; then
    perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")
    if [[ "${perms: -1}" =~ [2367] ]]; then
      ((suid_worldwrite++)) || true
      register_check "SUID world-writable: $file" FAIL "perms=$perms"
    fi
  fi

done < <(find / -xdev -type f -perm -4000 -print0 2>/dev/null)

register_check "Total SUID files" PASS "$suid_count found"

if [[ "$unexpected_suid" -eq 0 ]]; then
  register_check "Unexpected SUID files" PASS "none"
else
  register_check "Unexpected SUID files" WARN "$unexpected_suid (review needed)"
fi

if [[ "$suid_worldwrite" -eq 0 ]]; then
  register_check "World-writable SUID" PASS "none"
else
  register_check "World-writable SUID" FAIL "$suid_worldwrite files"
fi

section "SGID Binary Audit"

# Find all SGID files
sgid_count=0
unexpected_sgid=0
sgid_worldwrite=0

# Known legitimate SGID binaries
KNOWN_SGID_BINARIES=(
  /usr/bin/wall
  /usr/bin/write
  /usr/bin/chage
  /usr/bin/expiry
  /usr/bin/crontab
  /usr/bin/ssh-agent
  /usr/bin/locate
  /usr/bin/mlocate
  /usr/sbin/netreport
  /usr/sbin/postdrop
  /usr/sbin/postqueue
)

declare -A KNOWN_SGID_MAP
for binary in "${KNOWN_SGID_BINARIES[@]}"; do
  KNOWN_SGID_MAP["$binary"]=1
done

log_info "Scanning filesystem for SGID files..."

while IFS= read -r -d '' file; do
  ((sgid_count++)) || true

  # Check if on known list
  if [[ -z "${KNOWN_SGID_MAP[$file]:-}" ]]; then
    real_path=$(readlink -f "$file" 2>/dev/null || echo "$file")
    if [[ -z "${KNOWN_SGID_MAP[$real_path]:-}" ]]; then
      ((unexpected_sgid++)) || true
      register_check "SGID: $file" WARN "not on known list"
    fi
  fi

  # Check for world-writable SGID
  perms=$(stat -c "%a" "$file" 2>/dev/null || echo "000")
  if [[ "${perms: -1}" =~ [2367] ]]; then
    ((sgid_worldwrite++)) || true
    register_check "SGID world-writable: $file" FAIL "perms=$perms"
  fi

done < <(find / -xdev -type f -perm -2000 -print0 2>/dev/null)

register_check "Total SGID files" PASS "$sgid_count found"

if [[ "$unexpected_sgid" -eq 0 ]]; then
  register_check "Unexpected SGID files" PASS "none"
else
  register_check "Unexpected SGID files" WARN "$unexpected_sgid (review needed)"
fi

if [[ "$sgid_worldwrite" -eq 0 ]]; then
  register_check "World-writable SGID" PASS "none"
else
  register_check "World-writable SGID" FAIL "$sgid_worldwrite files"
fi

section "SUID/SGID Directories"

# Find SGID directories (common for shared directories)
sgid_dirs=$(find / -xdev -type d -perm -2000 2>/dev/null | wc -l || echo "0")
register_check "SGID directories" PASS "$sgid_dirs found"

# Find sticky bit directories
sticky_dirs=$(find / -xdev -type d -perm -1000 2>/dev/null | wc -l || echo "0")
register_check "Sticky bit directories" PASS "$sticky_dirs found"

section "Critical SUID/SGID Checks"

# Check for SUID root shells (very dangerous)
dangerous_shells=("/bin/sh" "/bin/bash" "/bin/dash" "/bin/zsh" "/bin/ksh" "/bin/csh" "/bin/tcsh")
for shell in "${dangerous_shells[@]}"; do
  if [[ -f "$shell" ]]; then
    perms=$(stat -c "%a" "$shell" 2>/dev/null || echo "")
    if [[ "$perms" =~ ^[4567] ]]; then
      register_check "SUID shell: $shell" FAIL "CRITICAL: perms=$perms"
    else
      register_check "Shell: $shell" PASS "no SUID"
    fi
  fi
done

# Check for SUID interpreters (dangerous)
interpreters=("/usr/bin/python" "/usr/bin/python3" "/usr/bin/perl" "/usr/bin/ruby" "/usr/bin/php")
for interp in "${interpreters[@]}"; do
  if [[ -f "$interp" ]]; then
    if [[ -u "$interp" ]]; then
      register_check "SUID interpreter: $interp" FAIL "CRITICAL"
    fi
  fi
done

# Check nmap (if installed, should not be SUID)
if command -v nmap >/dev/null 2>&1; then
  nmap_path=$(command -v nmap)
  if [[ -u "$nmap_path" ]]; then
    register_check "SUID nmap" FAIL "security risk"
  else
    register_check "nmap" PASS "no SUID"
  fi
fi

section "Recent SUID/SGID Changes"

# Check for recently modified SUID/SGID files (last 7 days)
recent_suid=$(find / -xdev -type f \( -perm -4000 -o -perm -2000 \) -mtime -7 2>/dev/null | wc -l || echo "0")
if [[ "$recent_suid" -eq 0 ]]; then
  register_check "Recent SUID/SGID changes (7d)" PASS "none"
else
  register_check "Recent SUID/SGID changes (7d)" WARN "$recent_suid files"

  # List them
  while IFS= read -r file; do
    mod_time=$(stat -c "%y" "$file" 2>/dev/null | cut -d. -f1)
    register_check "Recently modified: $file" WARN "changed: $mod_time"
  done < <(find / -xdev -type f \( -perm -4000 -o -perm -2000 \) -mtime -7 2>/dev/null)
fi

section "Orphaned SUID/SGID Files"

# Find SUID/SGID files with no valid owner or group
orphan_count=0

while IFS= read -r -d '' file; do
  owner=$(stat -c "%U" "$file" 2>/dev/null || echo "UNKNOWN")
  group=$(stat -c "%G" "$file" 2>/dev/null || echo "UNKNOWN")

  if [[ "$owner" == "UNKNOWN" ]] || [[ "$group" == "UNKNOWN" ]]; then
    ((orphan_count++)) || true
    register_check "Orphaned: $file" WARN "owner=$owner group=$group"
  fi
done < <(find / -xdev -type f \( -perm -4000 -o -perm -2000 \) -print0 2>/dev/null)

if [[ "$orphan_count" -eq 0 ]]; then
  register_check "Orphaned SUID/SGID files" PASS "none"
else
  register_check "Orphaned SUID/SGID files" WARN "$orphan_count files"
fi

print_summary
exit "$EXIT_CODE"
