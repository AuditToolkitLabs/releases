#!/usr/bin/env bash
# vault-agent-audit.sh — HashiCorp Vault Agent Security Audit
#
# Compliance Mapping:
# - CIS Benchmark: Custom (Secrets Management)
# - NIST SP 800-53: SC-12, SC-13, SC-28, IA-5
# - SOC 2: CC6.1, CC6.6, CC6.7
# - PCI DSS: 3.5, 3.6, 8.2.1
# - HIPAA: 164.312(a)(2)(iv), 164.312(e)(2)(ii)
#
# Checks:
# - Vault Agent installation and version
# - Auto-auth configuration and method
# - TLS/mTLS configuration
# - Token handling and caching
# - Template rendering security
# - Sink file permissions
# - Connection to Vault server
#
# @elevation: partial
# @elevation-reason: Vault agent config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"
. "$SCRIPT_DIR/../../../../lib/svc.sh"

setup_colors

# Common paths for Vault Agent
readonly VAULT_AGENT_CONFIG_PATHS=(
  "/etc/vault-agent.d"
  "/etc/vault-agent"
  "/opt/vault/agent"
  "/etc/vault.d/agent"
)

readonly VAULT_AGENT_SERVICE_NAMES=(
  "vault-agent"
  "vault-agent.service"
)

section "HashiCorp Vault Agent Security Audit"

# Check if Vault Agent is installed
VAULT_BIN=""
if command -v vault >/dev/null 2>&1; then
  VAULT_BIN="vault"
elif command -v vault-agent >/dev/null 2>&1; then
  VAULT_BIN="vault-agent"
elif [[ -x /usr/local/bin/vault ]]; then
  VAULT_BIN="/usr/local/bin/vault"
elif [[ -x /opt/vault/bin/vault ]]; then
  VAULT_BIN="/opt/vault/bin/vault"
fi

if [[ -z "$VAULT_BIN" ]]; then
  register_check "Vault Agent binary" SKIP "not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Vault Agent binary" PASS "found at $VAULT_BIN"

# Check Vault version
vault_version=$("$VAULT_BIN" version 2>/dev/null | head -1 || echo "unknown")
if [[ "$vault_version" != "unknown" ]]; then
  register_check "Vault version" PASS "$vault_version"
else
  register_check "Vault version" WARN "unable to determine"
fi

section "Service Status"

# Check for Vault Agent service
agent_service_active=false
for svc_name in "${VAULT_AGENT_SERVICE_NAMES[@]}"; do
  if svc_is_active "$svc_name" 2>/dev/null; then
    register_check "Vault Agent service" PASS "$svc_name is running"
    agent_service_active=true
    break
  fi
done

if [[ "$agent_service_active" == "false" ]]; then
  # Check if running as process
  if pgrep -f "vault agent" >/dev/null 2>&1; then
    register_check "Vault Agent process" PASS "running (not as service)"
  else
    register_check "Vault Agent service" WARN "not running"
  fi
fi

section "Configuration Discovery"

# Find configuration files
VAULT_AGENT_CONFIG=""
for config_path in "${VAULT_AGENT_CONFIG_PATHS[@]}"; do
  if [[ -d "$config_path" ]]; then
    config_file=$(find "$config_path" -name "*.hcl" -o -name "*.json" 2>/dev/null | head -1 || echo "")
    if [[ -n "$config_file" ]]; then
      VAULT_AGENT_CONFIG="$config_file"
      break
    fi
  fi

  # Check for single file configs
  for ext in hcl json; do
    if [[ -f "${config_path}.${ext}" ]]; then
      VAULT_AGENT_CONFIG="${config_path}.${ext}"
      break 2
    fi
  done
done

if [[ -n "$VAULT_AGENT_CONFIG" ]]; then
  register_check "Configuration file" PASS "$VAULT_AGENT_CONFIG"
else
  register_check "Configuration file" WARN "no config file found in standard paths"
  print_summary
  exit "$EXIT_CODE"
fi

section "Auto-Auth Configuration"

# Parse config for auto_auth settings
if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  config_content=$(cat "$VAULT_AGENT_CONFIG" 2>/dev/null || echo "")

  # Check if auto_auth is configured
  if echo "$config_content" | grep -qiE "auto_auth|auto-auth"; then
    register_check_tagged "Auto-auth enabled" PASS "configured" '"NIST:IA-5","SOC2:CC6.1"'

    # Check auth method
    auth_method=""
    if echo "$config_content" | grep -qiE "method.*kubernetes|kubernetes.*method"; then
      auth_method="kubernetes"
    elif echo "$config_content" | grep -qiE "method.*aws|aws.*method"; then
      auth_method="aws"
    elif echo "$config_content" | grep -qiE "method.*gcp|gcp.*method"; then
      auth_method="gcp"
    elif echo "$config_content" | grep -qiE "method.*azure|azure.*method"; then
      auth_method="azure"
    elif echo "$config_content" | grep -qiE "method.*approle|approle.*method"; then
      auth_method="approle"
    elif echo "$config_content" | grep -qiE "method.*cert|cert.*method"; then
      auth_method="cert"
    elif echo "$config_content" | grep -qiE "method.*token_file|token_file.*method"; then
      auth_method="token_file"
    fi

    if [[ -n "$auth_method" ]]; then
      case "$auth_method" in
        kubernetes|aws|gcp|azure|cert)
          register_check_tagged "Auto-auth method" PASS "$auth_method (recommended)" '"NIST:IA-5","SOC2:CC6.6"'
          ;;
        approle)
          register_check_tagged "Auto-auth method" PASS "$auth_method (ensure secret_id is protected)" '"NIST:IA-5","SOC2:CC6.6"'
          ;;
        token_file)
          register_check_tagged "Auto-auth method" WARN "token_file (less secure than platform auth)" '"NIST:IA-5","SOC2:CC6.6"'
          ;;
        *)
          register_check "Auto-auth method" WARN "unknown method"
          ;;
      esac
    else
      register_check "Auto-auth method" WARN "unable to determine auth method"
    fi
  else
    register_check "Auto-auth" WARN "not configured"
  fi
fi

section "TLS Configuration"

if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  # Check TLS settings
  if echo "$config_content" | grep -qiE "tls_skip_verify\s*=\s*true"; then
    register_check_tagged "TLS verification" FAIL "tls_skip_verify=true - insecure" '"NIST:SC-13","PCI:3.6"'
  else
    register_check_tagged "TLS verification" PASS "enabled (default)" '"NIST:SC-13","PCI:3.6"'
  fi

  # Check for client certificate (mTLS)
  if echo "$config_content" | grep -qiE "client_cert|tls_cert_file"; then
    register_check_tagged "mTLS (client cert)" PASS "configured" '"NIST:SC-13","SOC2:CC6.7"'
  else
    register_check "mTLS (client cert)" SKIP "not configured"
  fi

  # Check CA cert
  if echo "$config_content" | grep -qiE "ca_cert|tls_ca_cert|ca_path"; then
    register_check "CA certificate" PASS "configured"
  else
    register_check "CA certificate" WARN "not explicitly configured (using system CA)"
  fi
fi

section "Token Caching & Persistence"

if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  # Check for cache configuration
  if echo "$config_content" | grep -qiE "cache\s*{|cache.*="; then
    register_check "Token caching" PASS "configured"

    # Check cache persistence
    if echo "$config_content" | grep -qiE "persist\s*=\s*true|persistent\s*=\s*true"; then
      register_check "Cache persistence" WARN "enabled - tokens persisted to disk"
    else
      register_check "Cache persistence" PASS "disabled (in-memory only)"
    fi

    # Check cache encryption
    if echo "$config_content" | grep -qiE "use_auto_auth_token\s*=\s*true"; then
      register_check "Auto-auth token for cache" PASS "using auto-auth token"
    fi
  else
    register_check "Token caching" SKIP "not configured"
  fi

  # Check for listener (API proxy mode)
  if echo "$config_content" | grep -qiE "listener\s*{|listener.*tcp"; then
    listener_addr=$(echo "$config_content" | grep -oE "address\s*=\s*\"[^\"]+\"" | head -1 | cut -d'"' -f2 || echo "")
    if [[ -n "$listener_addr" ]]; then
      register_check "API listener" PASS "$listener_addr"

      # Check if TLS is enabled for listener
      if echo "$config_content" | grep -qiE "tls_disable\s*=\s*true"; then
        register_check "Listener TLS" FAIL "disabled"
      else
        register_check "Listener TLS" PASS "enabled"
      fi
    fi
  fi
fi

section "Sink Configuration"

if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  # Check sink configuration
  if echo "$config_content" | grep -qiE "sink\s*{|sink.*file"; then
    register_check "Token sink" PASS "configured"

    # Look for sink file path
    sink_path=$(echo "$config_content" | grep -oE "path\s*=\s*\"[^\"]+\"" | head -1 | cut -d'"' -f2 || echo "")
    if [[ -n "$sink_path" && -f "$sink_path" ]]; then
      # Check sink file permissions
      sink_perms=$(stat -c "%a" "$sink_path" 2>/dev/null || echo "")
      sink_owner=$(stat -c "%U:%G" "$sink_path" 2>/dev/null || echo "")

      case "$sink_perms" in
        400|600)
          register_check_tagged "Sink file permissions" PASS "$sink_perms owner-only" '"NIST:SC-28","PCI:3.5"'
          ;;
        640|440)
          register_check_tagged "Sink file permissions" WARN "$sink_perms (group readable)" '"NIST:SC-28","PCI:3.5"'
          ;;
        *)
          register_check_tagged "Sink file permissions" FAIL "$sink_perms (too permissive)" '"NIST:SC-28","PCI:3.5"'
          ;;
      esac

      register_check "Sink file owner" PASS "$sink_owner"
    elif [[ -n "$sink_path" ]]; then
      register_check "Sink file" WARN "path configured but file not found: $sink_path"
    fi

    # Check for wrap_ttl (response wrapping)
    if echo "$config_content" | grep -qiE "wrap_ttl"; then
      register_check "Response wrapping" PASS "enabled"
    fi
  else
    register_check "Token sink" SKIP "not configured"
  fi
fi

section "Template Configuration"

if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  # Check template configuration
  template_count=$(echo "$config_content" | grep -ciE "template\s*{" || echo "0")
  if [[ "$template_count" -gt 0 ]]; then
    register_check "Secret templates" PASS "$template_count template(s) configured"

    # Check template destinations
    while IFS= read -r dest_line; do
      dest_path=$(echo "$dest_line" | grep -oE "destination\s*=\s*\"[^\"]+\"" | cut -d'"' -f2 || echo "")
      if [[ -n "$dest_path" && -f "$dest_path" ]]; then
        dest_perms=$(stat -c "%a" "$dest_path" 2>/dev/null || echo "")
        case "$dest_perms" in
          400|600|440|640)
            register_check "Template dest: $(basename "$dest_path")" PASS "perms $dest_perms"
            ;;
          *)
            register_check "Template dest: $(basename "$dest_path")" WARN "perms $dest_perms (may be too open)"
            ;;
        esac
      fi
    done < <(echo "$config_content" | grep -iE "destination")

    # Check for error_on_missing_key
    if echo "$config_content" | grep -qiE "error_on_missing_key\s*=\s*true"; then
      register_check "Error on missing key" PASS "enabled (fail-safe)"
    else
      register_check "Error on missing key" WARN "disabled (may render empty values)"
    fi
  else
    register_check "Secret templates" SKIP "not configured"
  fi
fi

section "Vault Server Connection"

# Check if we can connect to Vault
vault_addr="${VAULT_ADDR:-}"
if [[ -z "$vault_addr" ]]; then
  # Try to extract from config
  if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
    vault_addr=$(echo "$config_content" | grep -oE "address\s*=\s*\"https?://[^\"]+\"" | head -1 | cut -d'"' -f2 || echo "")
  fi
fi

if [[ -n "$vault_addr" ]]; then
  register_check "Vault address" PASS "$vault_addr"

  # Check if HTTPS
  if [[ "$vault_addr" == https://* ]]; then
    register_check_tagged "Vault connection TLS" PASS "HTTPS" '"NIST:SC-13","PCI:3.6"'
  else
    register_check_tagged "Vault connection TLS" FAIL "HTTP (insecure)" '"NIST:SC-13","PCI:3.6"'
  fi

  # Try to check Vault status
  if [[ -n "$VAULT_BIN" ]]; then
    export VAULT_ADDR="$vault_addr"
    if vault_status=$("$VAULT_BIN" status -format=json 2>/dev/null); then
      sealed=$(echo "$vault_status" | grep -oE '"sealed":\s*(true|false)' | cut -d: -f2 | tr -d ' ' || echo "unknown")
      if [[ "$sealed" == "false" ]]; then
        register_check "Vault seal status" PASS "unsealed"
      elif [[ "$sealed" == "true" ]]; then
        register_check "Vault seal status" WARN "sealed (agent may not function)"
      fi
    else
      register_check "Vault status" WARN "unable to connect (may need token)"
    fi
  fi
else
  register_check "Vault address" WARN "not found in config or VAULT_ADDR"
fi

section "Security Best Practices"

# Check config file permissions
if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  config_perms=$(stat -c "%a" "$VAULT_AGENT_CONFIG" 2>/dev/null || echo "")
  config_owner=$(stat -c "%U:%G" "$VAULT_AGENT_CONFIG" 2>/dev/null || echo "")

  case "$config_perms" in
    400|600|640)
      register_check "Config file permissions" PASS "$config_perms"
      ;;
    *)
      register_check "Config file permissions" WARN "$config_perms (recommended: 600)"
      ;;
  esac
fi

# Check for secrets in environment
if env | grep -qiE "VAULT_TOKEN|VAULT_SECRET"; then
  register_check_tagged "Secrets in environment" WARN "VAULT_TOKEN or similar found in env" '"NIST:SC-28"'
else
  register_check_tagged "Secrets in environment" PASS "no sensitive vars exposed" '"NIST:SC-28"'
fi

# Check log level (should not be trace in production)
if [[ -f "$VAULT_AGENT_CONFIG" ]]; then
  log_level=$(echo "$config_content" | grep -oE "log_level\s*=\s*\"[^\"]+\"" | cut -d'"' -f2 || echo "")
  case "${log_level,,}" in
    trace)
      register_check "Log level" FAIL "trace (may expose secrets)"
      ;;
    debug)
      register_check "Log level" WARN "debug (consider 'info' for production)"
      ;;
    info|warn|error|"")
      register_check "Log level" PASS "${log_level:-info (default)}"
      ;;
  esac
fi

print_summary
exit "$EXIT_CODE"
