#!/usr/bin/env bash
# _siem-common.sh — Shared functions for SIEM/Log Forwarder audits
#
# @elevation: none
# @elevation-reason: Library file sourced by SIEM audits; does not require elevation itself
#
# This library provides common helper functions for auditing
# log forwarders and SIEM agents (Splunk, Elastic, Datadog, etc.)
#
# Source this file after common.sh in SIEM audit scripts:
#   . "$SCRIPT_DIR/../../../../lib/common.sh"
#   . "$SCRIPT_DIR/_siem-common.sh"

# Ensure common.sh has been sourced
if ! declare -f register_check >/dev/null 2>&1; then
  echo "ERROR: common.sh must be sourced before _siem-common.sh" >&2
  exit 1
fi

# Check if a directory exists
# Usage: siem_dir_exists "/path/to/dir" "Component Name"
siem_dir_exists() {
  local dir="${1:-}"
  local name="${2:-Directory}"

  if [[ -d "$dir" ]]; then
    register_check "$name directory" PASS "$dir"
    return 0
  else
    register_check "$name directory" FAIL "not found: $dir"
    return 1
  fi
}

# Check if a binary exists and is executable
# Usage: siem_binary_exists "/path/to/bin" "Binary Name"
siem_binary_exists() {
  local bin="${1:-}"
  local name="${2:-Binary}"

  if [[ -x "$bin" ]]; then
    register_check "$name binary" PASS "$bin"
    return 0
  elif command -v "$bin" >/dev/null 2>&1; then
    register_check "$name binary" PASS "$(command -v "$bin")"
    return 0
  else
    register_check "$name binary" FAIL "not found: $bin"
    return 1
  fi
}

# Check service is running (portable across init systems)
# Usage: siem_service_check "service_name" "Service Label"
siem_service_check() {
  local service="${1:-}"
  local name="${2:-Service}"

  # Try systemd first
  if command -v systemctl >/dev/null 2>&1 && pidof systemd >/dev/null 2>&1; then
    if systemctl is-active --quiet "$service" 2>/dev/null; then
      register_check "$name service" PASS "running (systemd)"
      return 0
    fi
  fi

  # Try OpenRC
  if command -v rc-service >/dev/null 2>&1; then
    if rc-service "$service" status 2>/dev/null | grep -qi "started\|running"; then
      register_check "$name service" PASS "running (OpenRC)"
      return 0
    fi
  fi

  # Try runit (Void Linux, Artix)
  if command -v sv >/dev/null 2>&1; then
    if sv status "$service" 2>/dev/null | grep -q '^run:'; then
      register_check "$name service" PASS "running (runit)"
      return 0
    fi
  fi

  # Try s6 (Artix, Obarun)
  if command -v s6-svstat >/dev/null 2>&1; then
    if s6-svstat "/run/s6/services/$service" 2>/dev/null | grep -q 'up'; then
      register_check "$name service" PASS "running (s6)"
      return 0
    fi
  fi

  # Try dinit (Artix, Chimera)
  if command -v dinitctl >/dev/null 2>&1; then
    if dinitctl status "$service" 2>/dev/null | grep -qiE 'STARTED|running'; then
      register_check "$name service" PASS "running (dinit)"
      return 0
    fi
  fi

  # Try SysV init
  if [[ -x "/etc/init.d/$service" ]]; then
    if "/etc/init.d/$service" status 2>/dev/null | grep -qi "running"; then
      register_check "$name service" PASS "running (init.d)"
      return 0
    fi
  fi

  # Try pgrep as fallback
  local proc_name
  proc_name=$(basename "$service")
  if pgrep -x "$proc_name" >/dev/null 2>&1 || pgrep -f "$proc_name" >/dev/null 2>&1; then
    register_check "$name service" WARN "process running but service status unknown"
    return 0
  fi

  register_check "$name service" FAIL "not running"
  return 1
}

# Check service is enabled at boot
# Usage: siem_service_enabled "service_name" "Service Label"
siem_service_enabled() {
  local service="${1:-}"
  local name="${2:-Service}"

  if command -v systemctl >/dev/null 2>&1 && pidof systemd >/dev/null 2>&1; then
    if systemctl is-enabled --quiet "$service" 2>/dev/null; then
      register_check "$name boot" PASS "enabled"
      return 0
    fi
  fi

  if command -v rc-update >/dev/null 2>&1; then
    if rc-update show 2>/dev/null | grep -q "\\b${service}\\b"; then
      register_check "$name boot" PASS "enabled (OpenRC)"
      return 0
    fi
  fi

  # runit: service is enabled if symlinked in service directory
  if command -v sv >/dev/null 2>&1; then
    if [[ -L "/var/service/$service" ]] || [[ -L "/service/$service" ]] || [[ -L "/run/runit/service/$service" ]]; then
      register_check "$name boot" PASS "enabled (runit)"
      return 0
    fi
  fi

  # s6: check if service directory exists
  if command -v s6-rc-db >/dev/null 2>&1; then
    if s6-rc-db list all 2>/dev/null | grep -qF "$service"; then
      register_check "$name boot" PASS "enabled (s6)"
      return 0
    fi
  fi

  # dinit: check service status
  if command -v dinitctl >/dev/null 2>&1; then
    if dinitctl list 2>/dev/null | grep -qE "^\[\+\].*$service"; then
      register_check "$name boot" PASS "enabled (dinit)"
      return 0
    fi
  fi

  if command -v chkconfig >/dev/null 2>&1; then
    if chkconfig --list "$service" 2>/dev/null | grep -q ":on"; then
      register_check "$name boot" PASS "enabled (chkconfig)"
      return 0
    fi
  fi

  register_check "$name boot" WARN "not enabled at boot or unknown"
  return 1
}

# Check config file exists and is readable
# Usage: siem_config_check "/path/to/config" "Config Name"
siem_config_check() {
  local config="${1:-}"
  local name="${2:-Config}"

  if [[ -f "$config" ]]; then
    if [[ -r "$config" ]]; then
      register_check "$name config" PASS "$config"
      return 0
    else
      register_check "$name config" WARN "exists but not readable: $config"
      return 1
    fi
  else
    register_check "$name config" FAIL "not found: $config"
    return 1
  fi
}

# Check file permissions (expects numeric mode like 600, 640)
# Usage: siem_file_perms "/path/to/file" "600|640" "File Name"
siem_file_perms() {
  local file="${1:-}"
  local expected="${2:-600}"
  local name="${3:-File}"

  if [[ ! -f "$file" ]]; then
    register_check "$name permissions" SKIP "file not found"
    return 1
  fi

  local actual
  actual=$(stat -c "%a" "$file" 2>/dev/null || stat -f "%Lp" "$file" 2>/dev/null) || {
    register_check "$name permissions" SKIP "unable to check"
    return 1
  }

  # Check if actual matches expected pattern (supports multiple with |)
  if echo "$expected" | grep -qE "(^|\\|)${actual}(\\||$)"; then
    register_check "$name permissions" PASS "$actual"
    return 0
  else
    register_check "$name permissions" WARN "actual $actual, expected $expected"
    return 1
  fi
}

# Test network connectivity to a host:port
# Usage: siem_connectivity_check "hostname:port" "Connection Name"
siem_connectivity_check() {
  local target="${1:-}"
  local name="${2:-Connectivity}"

  local host port
  host=$(echo "$target" | cut -d: -f1)
  port=$(echo "$target" | cut -d: -f2)

  if [[ -z "$host" ]] || [[ -z "$port" ]]; then
    register_check "$name" SKIP "invalid host:port format"
    return 1
  fi

  # Try nc (netcat) first
  if command -v nc >/dev/null 2>&1; then
    if nc -z -w 3 "$host" "$port" 2>/dev/null; then
      register_check "$name" PASS "$target reachable"
      return 0
    fi
  fi

  # Try timeout + bash /dev/tcp
  if command -v timeout >/dev/null 2>&1; then
    if timeout 3 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
      register_check "$name" PASS "$target reachable"
      return 0
    fi
  fi

  # Try curl for https endpoints
  if command -v curl >/dev/null 2>&1; then
    if [[ "$port" == "443" ]] || [[ "$port" == "8088" ]]; then
      if curl -sf --connect-timeout 3 "https://$host:$port" >/dev/null 2>&1; then
        register_check "$name" PASS "$target reachable"
        return 0
      fi
    fi
  fi

  register_check "$name" WARN "unable to verify connectivity to $target"
  return 1
}

# Check if log forwarding is active by examining recent logs
# Usage: siem_log_activity "/var/log/siem/*.log" "SIEM Name" minutes
siem_log_activity() {
  local log_pattern="${1:-}"
  local name="${2:-Forwarder}"
  local minutes="${3:-60}"
  local recent_count
  local -a matched_files=()

  while IFS= read -r file; do
    matched_files+=("$file")
  done < <(compgen -G "$log_pattern" || true)

  if [[ ${#matched_files[@]} -eq 0 ]]; then
    register_check "$name log activity" WARN "no matching log files for pattern $log_pattern"
    return 1
  fi

  recent_count=$(find "${matched_files[@]}" -type f -mmin "-${minutes}" 2>/dev/null | wc -l) || {
    register_check "$name log activity" SKIP "unable to check logs"
    return 1
  }

  if [[ "$recent_count" -gt 0 ]]; then
    register_check "$name log activity" PASS "$recent_count active log files"
    return 0
  else
    register_check "$name log activity" WARN "no recent log activity (last $minutes min)"
    return 1
  fi
}

# Check certificate expiration
# Usage: siem_cert_expiry "/path/to/cert.pem" "Certificate Name" days_threshold
siem_cert_expiry() {
  local cert="${1:-}"
  local name="${2:-Certificate}"
  local threshold="${3:-30}"

  if [[ ! -f "$cert" ]]; then
    register_check "$name expiry" SKIP "certificate not found"
    return 1
  fi

  if ! command -v openssl >/dev/null 2>&1; then
    register_check "$name expiry" SKIP "openssl not available"
    return 1
  fi

  local end_date days_left
  end_date=$(openssl x509 -enddate -noout -in "$cert" 2>/dev/null | cut -d= -f2) || {
    register_check "$name expiry" SKIP "unable to read certificate"
    return 1
  }

  local end_epoch now_epoch
  end_epoch=$(date -d "$end_date" +%s 2>/dev/null) || {
    register_check "$name expiry" SKIP "unable to parse date"
    return 1
  }
  now_epoch=$(date +%s)
  days_left=$(((end_epoch - now_epoch) / 86400))

  if [[ "$days_left" -lt 0 ]]; then
    register_check "$name expiry" FAIL "expired ${days_left#-} days ago"
    return 1
  elif [[ "$days_left" -lt "$threshold" ]]; then
    register_check "$name expiry" WARN "expires in $days_left days"
    return 1
  else
    register_check "$name expiry" PASS "$days_left days remaining"
    return 0
  fi
}

# Output SIEM not installed message and exit with SKIP for all checks
# Usage: siem_not_installed "SIEM Name"
siem_not_installed() {
  local name="${1:-SIEM Agent}"
  echo "${YELLOW:-}[SKIP]${RESET:-} $name is not installed on this system"
  register_check "$name installed" SKIP "not installed"
  print_summary
  exit "$EXIT_CODE"
}

# Check disk space for log directories
# Usage: siem_disk_space "/var/log/siem" 10 "SIEM Logs"
siem_disk_space() {
  local path="${1:-/var/log}"
  local threshold="${2:-10}" # percent free threshold
  local name="${3:-Log directory}"

  if [[ ! -d "$path" ]]; then
    register_check "$name disk space" SKIP "directory not found"
    return 1
  fi

  local pct_used pct_free
  pct_used=$(df -h "$path" 2>/dev/null | tail -1 | awk '{print $5}' | tr -d '%') || {
    register_check "$name disk space" SKIP "unable to check"
    return 1
  }
  pct_free=$((100 - pct_used))

  if [[ "$pct_free" -lt "$threshold" ]]; then
    register_check "$name disk space" WARN "${pct_free}% free (threshold: ${threshold}%)"
    return 1
  else
    register_check "$name disk space" PASS "${pct_free}% free"
    return 0
  fi
}

# Check queue depth / backpressure metrics
# Usage: siem_queue_files "/var/lib/siem/queue" threshold "Queue Name"
siem_queue_files() {
  local queue_dir="${1:-}"
  local threshold="${2:-1000}"
  local name="${3:-Queue}"

  if [[ ! -d "$queue_dir" ]]; then
    register_check "$name backlog" SKIP "queue directory not found"
    return 1
  fi

  local count
  count=$(find "$queue_dir" -type f 2>/dev/null | wc -l)

  if [[ "$count" -gt "$threshold" ]]; then
    register_check "$name backlog" WARN "$count files (threshold: $threshold)"
    return 1
  else
    register_check "$name backlog" PASS "$count files"
    return 0
  fi
}
