#!/usr/bin/env bash
# datadog-agent-audit.sh — Datadog Agent Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.9 (Log Collection, Central Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6, SI-4 (Audit & Monitoring)
# - ISO 27001: A.12.4.1, A.12.4.2 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security and Retention)
#
# Datadog Agent provides:
# - Metrics collection (APM, infrastructure)
# - Log forwarding
# - Security monitoring (Cloud Security Management)
# - Network monitoring
#
# Checks:
# - Agent installation
# - Service status
# - API key configuration (no exposure)
# - Datadog connectivity
# - Enabled integrations
# - Log collection status
#
# @elevation: partial
# @elevation-reason: Agent config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# Datadog paths
readonly DD_DIR="/opt/datadog-agent"
readonly DD_BIN="/opt/datadog-agent/bin/agent/agent"
readonly DD_CONFIG_DIR="/etc/datadog-agent"
readonly DD_CONFIG="$DD_CONFIG_DIR/datadog.yaml"
readonly DD_SERVICE="datadog-agent"

section "Datadog Agent Audit"

# Check if Datadog is installed
if [[ ! -d "$DD_DIR" ]] && ! command -v datadog-agent >/dev/null 2>&1; then
  siem_not_installed "Datadog Agent"
fi

# Check installation
siem_dir_exists "$DD_DIR" "Datadog Agent"
siem_dir_exists "$DD_CONFIG_DIR" "Datadog config"

# Check binary
if [[ -x "$DD_BIN" ]]; then
  siem_binary_exists "$DD_BIN" "datadog-agent"
elif command -v datadog-agent >/dev/null 2>&1; then
  register_check "datadog-agent binary" PASS "$(command -v datadog-agent)"
else
  register_check "datadog-agent binary" FAIL "not found"
fi

# Check service status
siem_service_check "$DD_SERVICE" "Datadog Agent"
siem_service_enabled "$DD_SERVICE" "Datadog Agent"

section "Datadog Agent Status"

# Helper to run datadog-agent
run_dd() {
  local cmd="${1:-status}"
  if [[ -x "$DD_BIN" ]]; then
    sudo "$DD_BIN" "$cmd" 2>/dev/null || "$DD_BIN" "$cmd" 2>/dev/null || echo ""
  elif command -v datadog-agent >/dev/null 2>&1; then
    sudo datadog-agent "$cmd" 2>/dev/null || datadog-agent "$cmd" 2>/dev/null || echo ""
  fi
}

# Get agent status
agent_status=$(run_dd status | head -50)
if echo "$agent_status" | grep -qi "running\|agent.*ok\|status.*ok"; then
  register_check "Agent status" PASS "running"
else
  register_check "Agent status" WARN "check status manually"
fi

# Check agent version
agent_version=$(run_dd version || echo "")
if [[ -n "$agent_version" ]]; then
  register_check "Agent version" PASS "$agent_version"
else
  register_check "Agent version" WARN "unable to determine"
fi

section "Datadog Configuration"

# Check main config
siem_config_check "$DD_CONFIG" "Main config"

if [[ -f "$DD_CONFIG" ]]; then
  # Check API key configuration (should reference env var or secret, not plaintext)
  if grep -qE "^api_key:\s+['\"]?[a-f0-9]{32}" "$DD_CONFIG" 2>/dev/null; then
    register_check "API key exposure" WARN "plaintext API key in config file"
  elif grep -qE "^api_key:" "$DD_CONFIG" 2>/dev/null; then
    register_check "API key exposure" PASS "API key configured (check if using secrets)"
  else
    register_check "API key exposure" FAIL "no API key configured"
  fi

  # Check site configuration (datadoghq.com vs datadoghq.eu)
  dd_site=$(grep "^site:" "$DD_CONFIG" 2>/dev/null | awk '{print $2}' || echo "datadoghq.com")
  register_check "Datadog site" PASS "${dd_site:-datadoghq.com}"

  # Check if logs are enabled
  if grep -qE "^logs_enabled:\s*(true|yes)" "$DD_CONFIG" 2>/dev/null; then
    register_check "Log collection" PASS "enabled"
  else
    register_check "Log collection" WARN "not enabled"
  fi

  # Check if APM is enabled
  if grep -qE "^apm_config:" "$DD_CONFIG" 2>/dev/null; then
    if grep -A5 "^apm_config:" "$DD_CONFIG" | grep -qE "enabled:\s*(true|yes)"; then
      register_check "APM tracing" PASS "enabled"
    else
      register_check "APM tracing" WARN "configured but not enabled"
    fi
  else
    register_check "APM tracing" SKIP "not configured"
  fi

  # Check if process monitoring is enabled
  if grep -qE "^process_config:" "$DD_CONFIG" 2>/dev/null; then
    register_check "Process monitoring" PASS "configured"
  else
    register_check "Process monitoring" SKIP "not configured"
  fi
fi

section "Datadog Integrations"

# Check conf.d directory for enabled integrations
readonly DD_CONFD="$DD_CONFIG_DIR/conf.d"
if [[ -d "$DD_CONFD" ]]; then
  enabled_integrations=$(find "$DD_CONFD" -name "*.yaml" ! -name "*.example" 2>/dev/null | wc -l)
  register_check "Enabled integrations" PASS "$enabled_integrations"

  # List key integrations
  for integration in docker system-probe http_check tcp_check; do
    int_config="$DD_CONFD/${integration}.d/conf.yaml"
    if [[ -f "$int_config" ]]; then
      register_check "$integration integration" PASS "configured"
    fi
  done
else
  register_check "Integrations dir" WARN "conf.d not found"
fi

section "Datadog Connectivity"

# Test connectivity to Datadog
dd_site=$(grep "^site:" "$DD_CONFIG" 2>/dev/null | awk '{print $2}' || echo "datadoghq.com")
siem_connectivity_check "app.${dd_site:-datadoghq.com}:443" "Datadog API"
siem_connectivity_check "intake.logs.${dd_site:-datadoghq.com}:443" "Datadog Logs Intake"

# Check flare/diagnostic capability
flare_test=$(run_dd diagnose 2>&1 | head -10 || echo "")
if echo "$flare_test" | grep -qi "pass\|success\|connectivity.*ok"; then
  register_check "Agent diagnostics" PASS "connectivity OK"
elif [[ -n "$flare_test" ]]; then
  register_check "Agent diagnostics" WARN "check 'datadog-agent diagnose'"
else
  register_check "Agent diagnostics" SKIP "unable to run"
fi

section "Datadog Security"

# Check config file permissions
siem_file_perms "$DD_CONFIG" "600|640|644" "datadog.yaml"

# Check if secrets backend is configured
if grep -qE "secret_backend_command:" "$DD_CONFIG" 2>/dev/null; then
  register_check "Secrets backend" PASS "configured"
else
  register_check "Secrets backend" WARN "not using secrets management"
fi

# Check security agent (Cloud Security Management)
readonly SECURITY_AGENT_CONFIG="$DD_CONFIG_DIR/security-agent.yaml"
if [[ -f "$SECURITY_AGENT_CONFIG" ]]; then
  register_check "Security agent" PASS "configured"

  # Check compliance/CSPM
  if grep -qE "compliance_config:" "$SECURITY_AGENT_CONFIG" 2>/dev/null; then
    register_check "Compliance monitoring" PASS "configured"
  fi

  # Check runtime security
  if grep -qE "runtime_security_config:" "$SECURITY_AGENT_CONFIG" 2>/dev/null; then
    register_check "Runtime security" PASS "configured"
  fi
else
  register_check "Security agent" SKIP "not configured"
fi

section "Datadog Health"

# Check disk space
siem_disk_space "/var/log/datadog" 10 "Datadog logs"

# Check agent log activity
siem_log_activity "/var/log/datadog/*.log" "Datadog" 60

# Check for recent errors in logs
readonly DD_AGENT_LOG="/var/log/datadog/agent.log"
if [[ -f "$DD_AGENT_LOG" ]]; then
  recent_errors=$(tail -500 "$DD_AGENT_LOG" 2>/dev/null | grep -ci "error\|warning" || echo 0)
  if [[ "$recent_errors" -gt 50 ]]; then
    register_check "Recent log issues" WARN "$recent_errors errors/warnings"
  else
    register_check "Recent log issues" PASS "$recent_errors issues"
  fi
fi

# Check JMX integration if Java present
if command -v java >/dev/null 2>&1; then
  if [[ -f "$DD_CONFD/jmx.d/conf.yaml" ]]; then
    register_check "JMX integration" PASS "configured"
  else
    register_check "JMX integration" SKIP "Java present but JMX not configured"
  fi
fi

print_summary
exit "$EXIT_CODE"
