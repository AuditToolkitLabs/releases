#!/usr/bin/env bash
# elastic-agent-audit.sh — Elastic Agent / Filebeat Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.9 (Log Collection, Central Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6 (Audit Events, Storage, Review)
# - ISO 27001: A.12.4.1, A.12.4.2 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security and Retention)
#
# Elastic Agent provides unified collection for:
# - Logs (replaces Filebeat)
# - Metrics (replaces Metricbeat)
# - Security telemetry (Endpoint Security)
#
# Checks:
# - Elastic Agent or Filebeat installation
# - Service status
# - Fleet enrollment
# - Elasticsearch/Logstash connectivity
# - TLS configuration
# - Input modules
#
# @elevation: partial
# @elevation-reason: Agent config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# Elastic paths
readonly ELASTIC_AGENT_DIR="/opt/Elastic/Agent"
readonly ELASTIC_AGENT_BIN="/opt/Elastic/Agent/elastic-agent"
readonly FILEBEAT_DIR="/etc/filebeat"
readonly FILEBEAT_BIN="/usr/share/filebeat/bin/filebeat"
readonly METRICBEAT_DIR="/etc/metricbeat"

section "Elastic Agent/Beats Audit"

# Determine which product is installed
PRODUCT_TYPE=""
if [[ -d "$ELASTIC_AGENT_DIR" ]] && [[ -x "$ELASTIC_AGENT_BIN" ]]; then
  PRODUCT_TYPE="elastic-agent"
elif [[ -d "$FILEBEAT_DIR" ]] || command -v filebeat >/dev/null 2>&1; then
  PRODUCT_TYPE="filebeat"
else
  siem_not_installed "Elastic Agent/Filebeat"
fi

register_check "Product detected" PASS "$PRODUCT_TYPE"

# Branch based on product type
if [[ "$PRODUCT_TYPE" == "elastic-agent" ]]; then
  #
  # Elastic Agent Checks
  #
  section "Elastic Agent Installation"

  siem_dir_exists "$ELASTIC_AGENT_DIR" "Elastic Agent"
  siem_binary_exists "$ELASTIC_AGENT_BIN" "elastic-agent"

  # Check service status
  siem_service_check "elastic-agent" "Elastic Agent"
  siem_service_enabled "elastic-agent" "Elastic Agent"

  section "Elastic Agent Status"

  # Helper to run elastic-agent
  run_agent() {
    sudo "$ELASTIC_AGENT_BIN" "$@" 2>/dev/null || "$ELASTIC_AGENT_BIN" "$@" 2>/dev/null || echo ""
  }

  # Check agent status
  agent_status=$(run_agent status)
  if echo "$agent_status" | grep -qi "running\|healthy"; then
    register_check "Agent status" PASS "running"
  else
    register_check "Agent status" WARN "status: $agent_status"
  fi

  # Check Fleet enrollment
  if echo "$agent_status" | grep -qi "fleet\|enrolled"; then
    register_check "Fleet enrollment" PASS "enrolled"
  elif [[ -f "/opt/Elastic/Agent/fleet.yml" ]]; then
    register_check "Fleet enrollment" PASS "configured"
  else
    register_check "Fleet enrollment" WARN "not enrolled or standalone"
  fi

  # Check version
  agent_version=$(run_agent version 2>/dev/null | head -1)
  if [[ -n "$agent_version" ]]; then
    register_check "Agent version" PASS "$agent_version"
  else
    register_check "Agent version" WARN "unable to determine"
  fi

  # Check enrolled integrations/inputs
  integration_count=$(run_agent status 2>/dev/null | grep -ci "input\|component" || echo "0")
  register_check "Active components" PASS "$integration_count"

  section "Elastic Agent Config"

  readonly AGENT_CONFIG="/opt/Elastic/Agent/elastic-agent.yml"
  siem_config_check "$AGENT_CONFIG" "Agent config"

  # Check Fleet server URL
  if [[ -f "$AGENT_CONFIG" ]]; then
    fleet_url=$(grep -i "fleet.*url\|host:" "$AGENT_CONFIG" 2>/dev/null | head -1 | awk '{print $NF}')
    if [[ -n "$fleet_url" ]]; then
      register_check "Fleet URL" PASS "$fleet_url"
    fi
  fi

  # Data directory
  readonly AGENT_DATA="/opt/Elastic/Agent/data"
  siem_disk_space "$AGENT_DATA" 10 "Agent data"

else
  #
  # Filebeat Checks
  #
  section "Filebeat Installation"

  siem_dir_exists "$FILEBEAT_DIR" "Filebeat config"

  if [[ -x "$FILEBEAT_BIN" ]]; then
    siem_binary_exists "$FILEBEAT_BIN" "filebeat"
  elif command -v filebeat >/dev/null 2>&1; then
    register_check "filebeat binary" PASS "$(command -v filebeat)"
  else
    register_check "filebeat binary" FAIL "not found"
  fi

  # Check service status
  siem_service_check "filebeat" "Filebeat"
  siem_service_enabled "filebeat" "Filebeat"

  section "Filebeat Status"

  # Check version
  fb_version=$(filebeat version 2>/dev/null | head -1 || echo "")
  if [[ -n "$fb_version" ]]; then
    register_check "Filebeat version" PASS "$fb_version"
  else
    register_check "Filebeat version" WARN "unable to determine"
  fi

  section "Filebeat Configuration"

  readonly FB_CONFIG="$FILEBEAT_DIR/filebeat.yml"
  siem_config_check "$FB_CONFIG" "Filebeat config"

  if [[ -f "$FB_CONFIG" ]]; then
    # Check Elasticsearch output
    if grep -qi "output.elasticsearch" "$FB_CONFIG" 2>/dev/null; then
      es_hosts=$(grep -A5 "output.elasticsearch" "$FB_CONFIG" | grep "hosts:" | head -1)
      register_check "Elasticsearch output" PASS "configured"

      # Check SSL for ES
      if grep -A10 "output.elasticsearch" "$FB_CONFIG" | grep -qi "ssl\|protocol:\s*https"; then
        register_check "ES TLS" PASS "enabled"
      else
        register_check "ES TLS" WARN "not detected"
      fi
    fi

    # Check Logstash output
    if grep -qi "output.logstash" "$FB_CONFIG" 2>/dev/null; then
      register_check "Logstash output" PASS "configured"

      # Check SSL for Logstash
      if grep -A10 "output.logstash" "$FB_CONFIG" | grep -qi "ssl"; then
        register_check "Logstash TLS" PASS "enabled"
      else
        register_check "Logstash TLS" WARN "not detected"
      fi
    fi

    # Check enabled inputs
    input_count=$(grep -c "^\\s*- type:" "$FB_CONFIG" 2>/dev/null || echo "0")
    register_check "Configured inputs" PASS "$input_count"
  fi

  # Check enabled modules
  readonly FB_MODULES="$FILEBEAT_DIR/modules.d"
  if [[ -d "$FB_MODULES" ]]; then
    enabled_modules=$(find "$FB_MODULES" -name "*.yml" ! -name "*.disabled" 2>/dev/null | wc -l)
    register_check "Enabled modules" PASS "$enabled_modules"
  fi
fi

section "Connectivity & Health"

# Test Elasticsearch connectivity (find ES host from config)
es_host=""
if [[ -f "${FB_CONFIG:-}" ]]; then
  es_host=$(grep -A5 "output.elasticsearch" "$FB_CONFIG" 2>/dev/null | grep -oE 'https?://[^"]+' | head -1 | sed 's|https\?://||;s|/.*||')
fi
if [[ -z "$es_host" ]] && [[ -f "${AGENT_CONFIG:-}" ]]; then
  es_host=$(grep -oE 'https?://[^"]+' "$AGENT_CONFIG" 2>/dev/null | head -1 | sed 's|https\?://||;s|/.*||')
fi
if [[ -n "$es_host" ]]; then
  siem_connectivity_check "$es_host" "Elasticsearch"
fi

# Check log activity
if [[ "$PRODUCT_TYPE" == "elastic-agent" ]]; then
  siem_log_activity "/opt/Elastic/Agent/data/elastic-agent-*/logs/*.log" "Elastic Agent" 60
else
  siem_log_activity "/var/log/filebeat/*.log" "Filebeat" 60
fi

# Check registry file (prevents duplicate events)
if [[ "$PRODUCT_TYPE" == "filebeat" ]]; then
  readonly FB_REGISTRY="/var/lib/filebeat/registry"
  if [[ -d "$FB_REGISTRY" ]]; then
    register_check "Registry directory" PASS "$FB_REGISTRY"
    siem_disk_space "/var/lib/filebeat" 10 "Filebeat data"
  else
    register_check "Registry directory" WARN "not found"
  fi
fi

section "Security Configuration"

# Check file permissions on config
if [[ -f "${FB_CONFIG:-}" ]]; then
  siem_file_perms "$FB_CONFIG" "600|640|644" "filebeat.yml"
fi
if [[ -f "${AGENT_CONFIG:-}" ]]; then
  siem_file_perms "$AGENT_CONFIG" "600|640|644" "elastic-agent.yml"
fi

# Check for API key / enrollment token exposure
config_file="${AGENT_CONFIG:-${FB_CONFIG:-}}"
if [[ -f "$config_file" ]]; then
  if grep -qiE "(api_key|password|token):\s+['\"]?[^$]" "$config_file" 2>/dev/null; then
    register_check "Credential exposure" WARN "plaintext credentials in config"
  else
    register_check "Credential exposure" PASS "no plaintext detected"
  fi
fi

# Also check Metricbeat if present
if [[ -d "$METRICBEAT_DIR" ]]; then
  section "Metricbeat (Bonus)"
  siem_service_check "metricbeat" "Metricbeat"
  siem_config_check "$METRICBEAT_DIR/metricbeat.yml" "Metricbeat config"
fi

print_summary
exit "$EXIT_CODE"
