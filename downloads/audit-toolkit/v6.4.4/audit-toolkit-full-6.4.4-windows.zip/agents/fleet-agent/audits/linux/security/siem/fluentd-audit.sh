#!/usr/bin/env bash
# fluentd-audit.sh — Fluentd / Fluent Bit Log Forwarder Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.9 (Log Collection, Central Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6 (Audit Events, Storage, Review)
# - ISO 27001: A.12.4.1, A.12.4.2 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security and Retention)
#
# Fluentd/Fluent Bit provides:
# - Log collection and forwarding
# - Data transformation and filtering
# - Multiple output destinations (Elasticsearch, Splunk, S3, etc.)
#
# Checks:
# - Installation (td-agent, fluentd gem, fluent-bit)
# - Service status
# - Configuration validity
# - Output targets
# - TLS configuration
# - Buffer health
#
# @elevation: partial
# @elevation-reason: Fluentd config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# Fluentd paths (td-agent is the packaged version)
readonly TD_AGENT_DIR="/opt/td-agent"
readonly TD_AGENT_CONFIG="/etc/td-agent/td-agent.conf"
readonly FLUENTD_CONFIG="/etc/fluent/fluent.conf"
readonly FLUENT_BIT_CONFIG="/etc/fluent-bit/fluent-bit.conf"
readonly FLUENT_BIT_CONFIG_ALT="/etc/td-agent-bit/td-agent-bit.conf"

section "Fluentd/Fluent Bit Audit"

# Detect which variant is installed
FLUENT_TYPE=""
FLUENT_CONFIG=""
FLUENT_SERVICE=""
FLUENT_BIN=""

if [[ -d "$TD_AGENT_DIR" ]] || [[ -f "$TD_AGENT_CONFIG" ]]; then
  FLUENT_TYPE="td-agent (Fluentd)"
  FLUENT_CONFIG="$TD_AGENT_CONFIG"
  FLUENT_SERVICE="td-agent"
  FLUENT_BIN="/opt/td-agent/bin/fluentd"
elif command -v fluentd >/dev/null 2>&1; then
  FLUENT_TYPE="fluentd (gem)"
  FLUENT_CONFIG="$FLUENTD_CONFIG"
  FLUENT_SERVICE="fluentd"
  FLUENT_BIN="$(command -v fluentd)"
elif [[ -f "$FLUENT_BIT_CONFIG" ]] || command -v fluent-bit >/dev/null 2>&1; then
  FLUENT_TYPE="fluent-bit"
  FLUENT_CONFIG="$FLUENT_BIT_CONFIG"
  FLUENT_SERVICE="fluent-bit"
  FLUENT_BIN="$(command -v fluent-bit)"
elif [[ -f "$FLUENT_BIT_CONFIG_ALT" ]]; then
  FLUENT_TYPE="td-agent-bit (Fluent Bit)"
  FLUENT_CONFIG="$FLUENT_BIT_CONFIG_ALT"
  FLUENT_SERVICE="td-agent-bit"
  FLUENT_BIN="$(command -v td-agent-bit)"
fi

if [[ -z "$FLUENT_TYPE" ]]; then
  siem_not_installed "Fluentd/Fluent Bit"
fi

register_check "Product detected" PASS "$FLUENT_TYPE"

# Check binary
if [[ -n "$FLUENT_BIN" ]] && [[ -x "$FLUENT_BIN" ]]; then
  register_check "Binary" PASS "$FLUENT_BIN"
else
  register_check "Binary" WARN "not found in expected location"
fi

# Check service status
siem_service_check "$FLUENT_SERVICE" "$FLUENT_TYPE"
siem_service_enabled "$FLUENT_SERVICE" "$FLUENT_TYPE"

section "Version & Status"

# Get version
if [[ "$FLUENT_TYPE" == "fluent-bit"* ]] || [[ "$FLUENT_TYPE" == "td-agent-bit"* ]]; then
  version=$(fluent-bit --version 2>/dev/null | head -1 || td-agent-bit --version 2>/dev/null | head -1 || echo "")
else
  version=$(fluentd --version 2>/dev/null || td-agent --version 2>/dev/null | head -1 || echo "")
fi
if [[ -n "$version" ]]; then
  register_check "Version" PASS "$version"
else
  register_check "Version" WARN "unable to determine"
fi

section "Configuration"

# Check main config
siem_config_check "$FLUENT_CONFIG" "Main config"

if [[ -f "$FLUENT_CONFIG" ]]; then
  # Config validation
  if [[ "$FLUENT_TYPE" == "fluent-bit"* ]] || [[ "$FLUENT_TYPE" == "td-agent-bit"* ]]; then
    # Fluent Bit doesn't have a dry-run, check syntax manually
    if fluent-bit -c "$FLUENT_CONFIG" --dry-run 2>/dev/null; then
      register_check "Config syntax" PASS
    else
      # Fluent Bit 2.x may not support dry-run
      register_check "Config syntax" SKIP "manual validation needed"
    fi
  else
    # Fluentd has --dry-run
    if sudo fluentd -c "$FLUENT_CONFIG" --dry-run 2>/dev/null; then
      register_check "Config syntax" PASS "valid"
    elif fluentd -c "$FLUENT_CONFIG" --dry-run 2>/dev/null; then
      register_check "Config syntax" PASS "valid"
    else
      register_check "Config syntax" WARN "syntax check failed or requires root"
    fi
  fi

  # Count sources and outputs
  if [[ "$FLUENT_TYPE" == "fluent-bit"* ]] || [[ "$FLUENT_TYPE" == "td-agent-bit"* ]]; then
    # Fluent Bit uses [INPUT] and [OUTPUT] sections
    input_count=$(grep -c "^\[INPUT\]" "$FLUENT_CONFIG" 2>/dev/null || echo "0")
    output_count=$(grep -c "^\[OUTPUT\]" "$FLUENT_CONFIG" 2>/dev/null || echo "0")
  else
    # Fluentd uses <source> and <match> tags
    input_count=$(grep -c "<source>" "$FLUENT_CONFIG" 2>/dev/null || echo "0")
    output_count=$(grep -c "<match" "$FLUENT_CONFIG" 2>/dev/null || echo "0")
  fi
  register_check "Input sources" PASS "$input_count"
  register_check "Output targets" PASS "$output_count"

  # Check for common secure outputs
  if grep -qiE "(elasticsearch|opensearch|splunk|s3|kafka|forward.*ssl)" "$FLUENT_CONFIG" 2>/dev/null; then
    register_check "Output destination" PASS "enterprise output configured"
  fi

  # Check TLS configuration
  if grep -qiE "tls\s*(on|true|enable)|ssl_verify|ca_cert" "$FLUENT_CONFIG" 2>/dev/null; then
    register_check "TLS encryption" PASS "configured"
  else
    register_check "TLS encryption" WARN "TLS not detected in config"
  fi
fi

section "Plugins & Extensions"

# Check installed plugins (Fluentd gem-based)
if [[ "$FLUENT_TYPE" != "fluent-bit"* ]]; then
  plugin_list=$(td-agent-gem list 2>/dev/null || gem list fluent 2>/dev/null | head -20 || echo "")
  if [[ -n "$plugin_list" ]]; then
    plugin_count=$(echo "$plugin_list" | grep -c "fluent" || echo "0")
    register_check "Installed plugins" PASS "$plugin_count plugins"
  else
    register_check "Installed plugins" SKIP "unable to list"
  fi
fi

# Check for Fluent Bit built-in plugins
if [[ "$FLUENT_TYPE" == "fluent-bit"* ]]; then
  if fluent-bit -h 2>/dev/null | grep -qi "available plugins"; then
    register_check "Built-in plugins" PASS "available"
  fi
fi

section "Buffer & Storage"

# Check buffer directories
buffer_dirs=("/var/log/td-agent/buffer" "/var/log/fluent/buffer" "/var/lib/fluent-bit")
for buf_dir in "${buffer_dirs[@]}"; do
  if [[ -d "$buf_dir" ]]; then
    siem_queue_files "$buf_dir" 10000 "Buffer queue"
    siem_disk_space "$buf_dir" 10 "Buffer directory"
    break
  fi
done

# Check position file (prevents duplicate reads)
pos_file=""
if [[ -f "$FLUENT_CONFIG" ]]; then
  pos_file=$(grep -oE "pos_file\s+\S+" "$FLUENT_CONFIG" 2>/dev/null | head -1 | awk '{print $2}')
  if [[ -n "$pos_file" ]] && [[ -f "$pos_file" ]]; then
    register_check "Position file" PASS "$pos_file"
  elif grep -q "pos_file\|Offset_Key" "$FLUENT_CONFIG" 2>/dev/null; then
    register_check "Position tracking" PASS "configured"
  else
    register_check "Position tracking" WARN "not detected"
  fi
fi

section "Security"

# Check config file permissions
siem_file_perms "$FLUENT_CONFIG" "600|640|644" "Main config"

# Check for credential exposure
if [[ -f "$FLUENT_CONFIG" ]]; then
  if grep -qiE "(password|api_key|secret):\s+['\"]?[^$#{]" "$FLUENT_CONFIG" 2>/dev/null; then
    register_check "Credential exposure" WARN "plaintext credentials in config"
  else
    register_check "Credential exposure" PASS "no obvious plaintext secrets"
  fi
fi

# Check if running as root
fluent_user=""
if command -v systemctl >/dev/null 2>&1; then
  fluent_user=$(systemctl show -p User "$FLUENT_SERVICE" 2>/dev/null | cut -d= -f2)
fi
if [[ "$fluent_user" == "root" ]]; then
  register_check "Service user" WARN "running as root"
elif [[ -n "$fluent_user" ]]; then
  register_check "Service user" PASS "$fluent_user"
else
  # Check process
  fluent_user=$(ps -eo user,comm 2>/dev/null | grep -E "fluentd|fluent-bit|td-agent" | head -1 | awk '{print $1}')
  if [[ "$fluent_user" == "root" ]]; then
    register_check "Service user" WARN "running as root"
  elif [[ -n "$fluent_user" ]]; then
    register_check "Service user" PASS "$fluent_user"
  else
    register_check "Service user" SKIP "process not running"
  fi
fi

section "Health"

# Check log activity
log_dirs=("/var/log/td-agent" "/var/log/fluent" "/var/log/fluent-bit")
for log_dir in "${log_dirs[@]}"; do
  if [[ -d "$log_dir" ]]; then
    siem_log_activity "$log_dir/*.log" "Fluentd/Bit" 60
    break
  fi
done

# Check for errors in logs
main_log="/var/log/td-agent/td-agent.log"
[[ ! -f "$main_log" ]] && main_log="/var/log/fluent-bit.log"
if [[ -f "$main_log" ]]; then
  recent_errors=$(tail -500 "$main_log" 2>/dev/null | grep -ci "error\|warn" || echo "0")
  if [[ "$recent_errors" -gt 50 ]]; then
    register_check "Recent errors" WARN "$recent_errors errors/warnings"
  else
    register_check "Recent errors" PASS "$recent_errors issues"
  fi
fi

# Check systemd resource limits
if command -v systemctl >/dev/null 2>&1; then
  mem_limit=$(systemctl show -p MemoryLimit "$FLUENT_SERVICE" 2>/dev/null | cut -d= -f2)
  if [[ -n "$mem_limit" ]] && [[ "$mem_limit" != "infinity" ]]; then
    register_check "Memory limit" PASS "$mem_limit"
  fi
fi

print_summary
exit "$EXIT_CODE"
