#!/usr/bin/env bash
# rsyslog-forwarding-audit.sh — rsyslog Log Forwarding Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.6, 8.9 (Log Collection, Centralized Log Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6, AU-9 (Audit Events, Protection)
# - ISO 27001: A.12.4.1, A.12.4.2, A.12.4.3 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security, Retention, Monitoring)
# - CIS Benchmark: 4.2.1.x (rsyslog Configuration)
#
# rsyslog checks:
# - Installation and service status
# - Remote forwarding configuration (@@host for TCP, @host for UDP)
# - TLS encryption for remote logging
# - Queue configuration for reliability
# - File permissions and ownership
# - Rate limiting configuration
#
# @elevation: partial
# @elevation-reason: rsyslog config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=_siem-common.sh
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# rsyslog paths
readonly RSYSLOG_CONF="/etc/rsyslog.conf"
readonly RSYSLOG_D="/etc/rsyslog.d"
readonly RSYSLOG_SERVICE="rsyslog"
readonly RSYSLOG_SPOOL="/var/spool/rsyslog"

section "rsyslog Log Forwarding Audit"

# Check if rsyslog is installed
if ! command -v rsyslogd >/dev/null 2>&1 && [[ ! -f "$RSYSLOG_CONF" ]]; then
  siem_not_installed "rsyslog"
fi

# Check binary
if command -v rsyslogd >/dev/null 2>&1; then
  register_check "rsyslogd binary" PASS "$(command -v rsyslogd)"
else
  register_check "rsyslogd binary" WARN "not in PATH"
fi

# Check service status
siem_service_check "$RSYSLOG_SERVICE" "rsyslog"
siem_service_enabled "$RSYSLOG_SERVICE" "rsyslog"

section "rsyslog Version & Status"

# Get version
rsyslog_version=$(rsyslogd -v 2>/dev/null | head -1 || echo "")
if [[ -n "$rsyslog_version" ]]; then
  register_check "Version" PASS "$rsyslog_version"
else
  register_check "Version" WARN "unable to determine"
fi

# Check config syntax
config_check=$(rsyslogd -N1 2>&1 || echo "")
if echo "$config_check" | grep -qi "no error\|syntax ok\|configuration valid"; then
  register_check "Config syntax" PASS "valid"
elif echo "$config_check" | grep -qi "error"; then
  register_check "Config syntax" FAIL "syntax errors found"
else
  register_check "Config syntax" SKIP "unable to validate"
fi

section "rsyslog Remote Forwarding"

# Check main config
siem_config_check "$RSYSLOG_CONF" "Main config"

# Read all config files for analysis
all_configs=""
if [[ -f "$RSYSLOG_CONF" ]]; then
  all_configs=$(cat "$RSYSLOG_CONF")
fi
if [[ -d "$RSYSLOG_D" ]]; then
  all_configs+=$(cat "$RSYSLOG_D"/*.conf 2>/dev/null || echo "")
fi

# Check for remote forwarding (CIS 4.2.1.5)
# @@ = TCP, @ = UDP
if echo "$all_configs" | grep -qE "^\s*[*!a-z]+\.[*!a-z]+\s+@@"; then
  tcp_target=$(echo "$all_configs" | grep -oE "@@[a-zA-Z0-9._:-]+" | head -1)
  register_check "Remote TCP forwarding" PASS "$tcp_target"
elif echo "$all_configs" | grep -qE "^\s*[*!a-z]+\.[*!a-z]+\s+@[^@]"; then
  udp_target=$(echo "$all_configs" | grep -oE "@[a-zA-Z0-9._:-]+" | head -1)
  register_check "Remote UDP forwarding" WARN "$udp_target (UDP, prefer TCP)"
else
  # Check for omfwd action module
  if echo "$all_configs" | grep -qE "action\s*\(.*type=\"omfwd\""; then
    register_check "Remote forwarding" PASS "omfwd action configured"
  elif echo "$all_configs" | grep -qE "target=.*port="; then
    register_check "Remote forwarding" PASS "action target configured"
  else
    register_check "Remote forwarding" WARN "no remote forwarding detected"
  fi
fi

# Check for TLS/SSL configuration (CIS recommendation)
if echo "$all_configs" | grep -qiE "StreamDriver.*gtls\|StreamDriver.*ossl\|defaultNetstreamDriver.*gtls\|tls\.[a-z]+"; then
  register_check "TLS encryption" PASS "configured"

  # Check for certificate configuration
  if echo "$all_configs" | grep -qiE "DefaultNetstreamDriverCAFile\|tls\.cacert"; then
    register_check "TLS CA certificate" PASS "configured"
  else
    register_check "TLS CA certificate" WARN "CA cert not found"
  fi

  # Check for client cert (mutual TLS)
  if echo "$all_configs" | grep -qiE "DefaultNetstreamDriverCertFile\|tls\.mycert"; then
    register_check "TLS client cert" PASS "mutual TLS configured"
  else
    register_check "TLS client cert" SKIP "single-direction TLS"
  fi
else
  register_check "TLS encryption" WARN "TLS not configured for remote logging"
fi

# Check for RELP protocol (reliable delivery)
if echo "$all_configs" | grep -qiE "omrelp\|module.*load.*relp\|:omrelp:"; then
  register_check "RELP protocol" PASS "reliable delivery enabled"
else
  register_check "RELP protocol" SKIP "not using RELP"
fi

section "rsyslog Queue Configuration"

# Check for queue configuration (prevents log loss during network issues)
if echo "$all_configs" | grep -qiE "queue\.type\s*=\s*\"LinkedList\"\|queue\.type\s*=\s*\"Disk\""; then
  register_check "Action queue" PASS "disk/linked queue configured"

  # Check queue disk path
  if echo "$all_configs" | grep -qiE "queue\.filename\|queue\.spoolDirectory"; then
    register_check "Queue spool" PASS "spool directory configured"
  fi

  # Check queue size
  queue_size=$(echo "$all_configs" | grep -oE "queue\.size\s*=\s*\"[0-9]+\"" | head -1 | grep -oE "[0-9]+")
  if [[ -n "$queue_size" ]]; then
    register_check "Queue size" PASS "$queue_size messages"
  fi
else
  register_check "Action queue" WARN "no dedicated queue (may lose logs during outage)"
fi

# Check spool directory
if [[ -d "$RSYSLOG_SPOOL" ]]; then
  siem_dir_exists "$RSYSLOG_SPOOL" "Spool directory"
  siem_disk_space "$RSYSLOG_SPOOL" 10 "Spool directory"
  siem_queue_files "$RSYSLOG_SPOOL" 10000 "Queue files"
else
  register_check "Spool directory" SKIP "not present"
fi

section "rsyslog Security Configuration"

# Check file permissions on config (CIS 4.2.1.3)
siem_file_perms "$RSYSLOG_CONF" "640|644" "rsyslog.conf"

# Check ownership (CIS 4.2.1.2)
if [[ -f "$RSYSLOG_CONF" ]]; then
  owner=$(stat -c "%U:%G" "$RSYSLOG_CONF" 2>/dev/null || stat -f "%Su:%Sg" "$RSYSLOG_CONF" 2>/dev/null)
  if [[ "$owner" == "root:root" ]] || [[ "$owner" == "root:syslog" ]]; then
    register_check "Config ownership" PASS "$owner"
  else
    register_check "Config ownership" WARN "$owner (should be root:root)"
  fi
fi

# Check default file permissions for log files (CIS 4.2.1.4)
if echo "$all_configs" | grep -qE "^\\\$FileCreateMode\\s+0[0-6][0-4][0-4]"; then
  fcm=$(echo "$all_configs" | grep -oE "^\\\$FileCreateMode\\s+[0-9]+" | head -1)
  register_check "FileCreateMode" PASS "$fcm"
elif echo "$all_configs" | grep -qE '^template.*FileCreateMode.*0[0-6][0-4]'; then
  register_check "FileCreateMode" PASS "secure template"
else
  register_check "FileCreateMode" WARN "not explicitly set (check defaults)"
fi

# Check for rate limiting (prevents DoS)
if echo "$all_configs" | grep -qiE "ratelimit\|imuxsock.*SysSock.RateLimit"; then
  register_check "Rate limiting" PASS "configured"
else
  register_check "Rate limiting" WARN "not explicitly configured"
fi

section "rsyslog Modules"

# Check loaded modules
if echo "$all_configs" | grep -qE "module.*load.*imuxsock\|^\$ModLoad imuxsock"; then
  register_check "imuxsock module" PASS "local logging"
fi

if echo "$all_configs" | grep -qE "module.*load.*imjournal\|^\$ModLoad imjournal"; then
  register_check "imjournal module" PASS "journald integration"
fi

if echo "$all_configs" | grep -qE "module.*load.*imklog\|^\$ModLoad imklog"; then
  register_check "imklog module" PASS "kernel logging"
fi

if echo "$all_configs" | grep -qE "module.*load.*imtcp\|^\$ModLoad imtcp\|^\$InputTCPServerRun"; then
  register_check "imtcp module" PASS "TCP receiver"
fi

if echo "$all_configs" | grep -qE "module.*load.*imudp\|^\$ModLoad imudp\|^\$UDPServerRun"; then
  register_check "imudp module" WARN "UDP receiver (prefer TCP)"
fi

section "rsyslog Include Configuration"

# Check rsyslog.d directory inclusion
if [[ -d "$RSYSLOG_D" ]]; then
  register_check "rsyslog.d directory" PASS "present"

  include_count=$(find "$RSYSLOG_D" -maxdepth 1 -type f -name '*.conf' 2>/dev/null | wc -l)
  register_check "Drop-in configs" PASS "$include_count files"

  # List key configs
  for conf in "$RSYSLOG_D"/*.conf; do
    [[ -f "$conf" ]] || continue
    conf_name=$(basename "$conf")
    # Look for forwarding in each file
    if grep -qE "@[^@]|@@" "$conf" 2>/dev/null; then
      register_check "Forwarding in $conf_name" PASS
    fi
  done 2>/dev/null
fi

section "rsyslog Health"

# Check log activity
siem_log_activity "/var/log/syslog" "syslog" 60 ||
  siem_log_activity "/var/log/messages" "messages" 60

# Check for errors in rsyslog's own logs
rsyslog_log="/var/log/rsyslog.log"
if [[ ! -f "$rsyslog_log" ]]; then
  # Check syslog for rsyslog errors
  rsyslog_log="/var/log/syslog"
fi
if [[ -f "$rsyslog_log" ]]; then
  recent_errors=$(grep -i "rsyslog" "$rsyslog_log" 2>/dev/null | tail -100 | grep -ci "error\|fail" || echo "0")
  if [[ "$recent_errors" -gt 10 ]]; then
    register_check "Recent rsyslog errors" WARN "$recent_errors errors"
  else
    register_check "Recent rsyslog errors" PASS "$recent_errors errors"
  fi
fi

# Check if impstats is enabled (internal metrics)
if echo "$all_configs" | grep -qiE "module.*load.*impstats\|^\$ModLoad impstats"; then
  register_check "Statistics logging" PASS "impstats enabled"
else
  register_check "Statistics logging" SKIP "impstats not loaded"
fi

# Check working directory permissions
readonly RSYSLOG_WORK="/var/lib/rsyslog"
if [[ -d "$RSYSLOG_WORK" ]]; then
  siem_file_perms "$RSYSLOG_WORK" "700|750|755" "Work directory"
fi

print_summary
exit "$EXIT_CODE"
