#!/usr/bin/env bash
# splunk-forwarder-audit.sh — Splunk Universal Forwarder Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.9 (Log Collection, Central Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6 (Audit Events, Storage, Review)
# - ISO 27001: A.12.4.1, A.12.4.2 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security and Retention)
#
# Splunk Universal Forwarder/Heavy Forwarder checks:
# - Installation and binary verification
# - Service status (splunkd)
# - Deployment server connectivity
# - Indexer connectivity
# - Input configuration
# - TLS/SSL certificate status
# - Disk space for queue/fish bucket
# - Forwarder license
#
# @elevation: partial
# @elevation-reason: Forwarder config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# Common Splunk paths
SPLUNK_HOME="${SPLUNK_HOME:-}"
SPLUNK_DIRS=("/opt/splunkforwarder" "/opt/splunk" "/opt/SplunkForwarder" "/opt/Splunk")

# Find Splunk installation
for dir in "${SPLUNK_DIRS[@]}"; do
  if [[ -d "$dir" ]]; then
    SPLUNK_HOME="$dir"
    break
  fi
done

section "Splunk Forwarder Audit"

# Check if Splunk is installed
if [[ -z "$SPLUNK_HOME" ]] || [[ ! -d "$SPLUNK_HOME" ]]; then
  siem_not_installed "Splunk Forwarder"
fi

readonly SPLUNK_BIN="$SPLUNK_HOME/bin/splunk"
readonly SPLUNK_ETC="$SPLUNK_HOME/etc"
readonly SPLUNK_VAR="$SPLUNK_HOME/var"

# Check installation directory
siem_dir_exists "$SPLUNK_HOME" "Splunk home"

# Check splunk binary
siem_binary_exists "$SPLUNK_BIN" "splunk"

# Determine forwarder type
if [[ "$SPLUNK_HOME" == *"forwarder"* ]] || [[ "$SPLUNK_HOME" == *"Forwarder"* ]]; then
  FORWARDER_TYPE="Universal Forwarder"
else
  FORWARDER_TYPE="Heavy Forwarder/Enterprise"
fi
register_check "Forwarder type" PASS "$FORWARDER_TYPE"

# Check service status
siem_service_check "SplunkForwarder" "Splunk Forwarder"
siem_service_enabled "SplunkForwarder" "Splunk Forwarder"

# Alternative service names
if ! systemctl is-active --quiet SplunkForwarder 2>/dev/null; then
  siem_service_check "splunk" "Splunk"
fi

section "Splunk Daemon Status"

# Helper to run splunk CLI
run_splunk() {
  sudo "$SPLUNK_BIN" "$@" 2>/dev/null || "$SPLUNK_BIN" "$@" 2>/dev/null || echo ""
}

# Check splunkd status
splunk_status=$(run_splunk status)
if echo "$splunk_status" | grep -qi "running"; then
  register_check "splunkd status" PASS "running"
else
  register_check "splunkd status" FAIL "not running"
fi

# Check Splunk version
splunk_version=$("$SPLUNK_BIN" version 2>/dev/null | head -1 || echo "")
if [[ -n "$splunk_version" ]]; then
  register_check "Splunk version" PASS "$splunk_version"
else
  register_check "Splunk version" WARN "unable to determine"
fi

section "Splunk Configuration"

# Check local inputs.conf
readonly INPUTS_CONF="$SPLUNK_ETC/system/local/inputs.conf"
readonly INPUTS_DEFAULT="$SPLUNK_ETC/system/default/inputs.conf"
readonly INPUTS_APP="$SPLUNK_ETC/apps/*/local/inputs.conf"

inputs_found=false
# shellcheck disable=SC2086
for conf in "$INPUTS_CONF" "$INPUTS_DEFAULT" $INPUTS_APP; do
  if [[ -f "$conf" ]]; then
    inputs_found=true
    register_check "inputs.conf" PASS "$(basename "$(dirname "$conf")")/$(basename "$conf")"
    break
  fi
done
if ! $inputs_found; then
  register_check "inputs.conf" WARN "no inputs.conf found"
fi

# Check outputs.conf for indexer configuration
readonly OUTPUTS_CONF="$SPLUNK_ETC/system/local/outputs.conf"
if [[ -f "$OUTPUTS_CONF" ]]; then
  register_check "outputs.conf" PASS "configured"

  # Check if indexers are configured
  if grep -q "server\s*=" "$OUTPUTS_CONF" 2>/dev/null; then
    indexer=$(grep "server\s*=" "$OUTPUTS_CONF" | head -1 | cut -d= -f2 | tr -d ' ')
    register_check "Indexer target" PASS "$indexer"
  else
    register_check "Indexer target" WARN "no server defined"
  fi

  # Check if SSL is configured
  if grep -qi "sslCertPath\|useSSL\s*=\s*true" "$OUTPUTS_CONF" 2>/dev/null; then
    register_check "Output SSL" PASS "enabled"
  else
    register_check "Output SSL" WARN "not detected"
  fi
else
  register_check "outputs.conf" FAIL "not found"
fi

# Check deploymentclient.conf
readonly DEPLOY_CONF="$SPLUNK_ETC/system/local/deploymentclient.conf"
if [[ -f "$DEPLOY_CONF" ]]; then
  register_check "Deployment client" PASS "configured"

  # Check deployment server
  if grep -q "targetUri" "$DEPLOY_CONF" 2>/dev/null; then
    ds=$(grep "targetUri" "$DEPLOY_CONF" | head -1 | cut -d= -f2 | tr -d ' ')
    register_check "Deployment server" PASS "$ds"
  fi
else
  register_check "Deployment client" SKIP "not configured"
fi

section "Splunk Connectivity"

# Test deployment server connectivity (if configured)
if [[ -f "$DEPLOY_CONF" ]]; then
  ds_uri=$(grep "targetUri" "$DEPLOY_CONF" 2>/dev/null | head -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$ds_uri" ]]; then
    ds_host=$(echo "$ds_uri" | sed 's|https\?://||' | cut -d: -f1)
    ds_port=$(echo "$ds_uri" | sed 's|https\?://||' | cut -d: -f2 | cut -d/ -f1)
    ds_port="${ds_port:-8089}"
    siem_connectivity_check "${ds_host}:${ds_port}" "Deployment server"
  fi
fi

# Test indexer connectivity (if outputs.conf exists)
if [[ -f "$OUTPUTS_CONF" ]]; then
  indexer_server=$(grep "server\s*=" "$OUTPUTS_CONF" 2>/dev/null | head -1 | cut -d= -f2 | tr -d ' ')
  if [[ -n "$indexer_server" ]]; then
    siem_connectivity_check "$indexer_server" "Indexer"
  fi
fi

# Check splunk btool for configuration issues
btool_output=$(run_splunk btool check 2>&1 || echo "")
if [[ -z "$btool_output" ]] || echo "$btool_output" | grep -qi "no errors"; then
  register_check "Configuration check" PASS "no errors"
elif [[ -n "$btool_output" ]]; then
  error_count=$(echo "$btool_output" | wc -l)
  register_check "Configuration check" WARN "$error_count issues found"
else
  register_check "Configuration check" SKIP "unable to run btool"
fi

section "Splunk Security"

# Check for certificate files
readonly CERT_DIR="$SPLUNK_ETC/auth"
if [[ -d "$CERT_DIR" ]]; then
  register_check "Auth directory" PASS "$CERT_DIR"

  # Check server.pem
  readonly SERVER_CERT="$CERT_DIR/server.pem"
  if [[ -f "$SERVER_CERT" ]]; then
    siem_cert_expiry "$SERVER_CERT" "Server certificate" 30
  fi

  # Check CA certificates
  if [[ -d "$CERT_DIR/cacerts" ]]; then
    register_check "CA certs directory" PASS
  fi
else
  register_check "Auth directory" WARN "not found"
fi

# Check password policy in server.conf
readonly SERVER_CONF="$SPLUNK_ETC/system/local/server.conf"
if [[ -f "$SERVER_CONF" ]]; then
  if grep -qi "minPasswordLength\|requireSpecialChar" "$SERVER_CONF" 2>/dev/null; then
    register_check "Password policy" PASS "configured"
  else
    register_check "Password policy" WARN "not hardened"
  fi
fi

# Check config file permissions
siem_file_perms "$OUTPUTS_CONF" "600|640|644" "outputs.conf"

section "Splunk Health"

# Check disk space for Splunk directories
siem_disk_space "$SPLUNK_VAR" 10 "Splunk var"

# Check fish bucket / persistent queue
readonly FISH_BUCKET="$SPLUNK_VAR/run/fishbucket"
readonly PERSIST_QUEUE="$SPLUNK_VAR/run/dispatch"

if [[ -d "$FISH_BUCKET" ]]; then
  siem_queue_files "$FISH_BUCKET" 50000 "Fish bucket"
fi

# Check internal logs for errors
readonly SPLUNK_LOG="$SPLUNK_VAR/log/splunk/splunkd.log"
if [[ -f "$SPLUNK_LOG" ]]; then
  recent_errors=$(tail -500 "$SPLUNK_LOG" 2>/dev/null | grep -ci "error\|exception" || echo 0)
  if [[ "$recent_errors" -gt 50 ]]; then
    register_check "Recent log errors" WARN "$recent_errors errors in last 500 lines"
  else
    register_check "Recent log errors" PASS "$recent_errors errors"
  fi
else
  register_check "Recent log errors" SKIP "log not found"
fi

# Check metrics log activity
siem_log_activity "$SPLUNK_VAR/log/splunk/*.log" "Splunk" 60

# Check license type
license_info=$("$SPLUNK_BIN" show licenser-stacks 2>/dev/null || echo "")
if [[ -n "$license_info" ]]; then
  register_check "License info" PASS "configured"
else
  register_check "License info" SKIP "unable to determine"
fi

print_summary
exit "$EXIT_CODE"
