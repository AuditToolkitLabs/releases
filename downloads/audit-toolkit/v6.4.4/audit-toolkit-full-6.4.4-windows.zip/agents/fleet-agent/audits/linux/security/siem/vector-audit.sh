#!/usr/bin/env bash
# vector-audit.sh — Vector Observability Pipeline Audit
#
# Compliance Mapping:
# - CIS Controls: 8.2, 8.9 (Log Collection, Central Management)
# - NIST SP 800-53: AU-2, AU-4, AU-6 (Audit Events, Storage, Review)
# - ISO 27001: A.12.4.1, A.12.4.2 (Event Logging)
# - PCI DSS: 10.5, 10.6, 10.7 (Log Security and Retention)
#
# Vector is a high-performance observability data pipeline
# supporting logs, metrics, and traces.
#
# Checks:
# - Installation and binary
# - Service status
# - Configuration validation
# - Sources and sinks
# - TLS configuration
# - Buffer/disk queue health
# - API/healthcheck endpoint
#
# @elevation: partial
# @elevation-reason: Vector config files may require elevated access
#

set -euo pipefail

# Source common libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../../lib/common.sh
. "$SCRIPT_DIR/../../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=_siem-common.sh
. "$SCRIPT_DIR/_siem-common.sh"

setup_colors

# Vector paths
readonly VECTOR_BIN="/usr/bin/vector"
readonly VECTOR_CONFIG="/etc/vector/vector.toml"
readonly VECTOR_CONFIG_YAML="/etc/vector/vector.yaml"
readonly VECTOR_CONFIG_DIR="/etc/vector"
readonly VECTOR_DATA_DIR="/var/lib/vector"
readonly VECTOR_SERVICE="vector"

section "Vector Pipeline Audit"

# Check if Vector is installed
if ! command -v vector >/dev/null 2>&1 && [[ ! -x "$VECTOR_BIN" ]]; then
  siem_not_installed "Vector"
fi

# Check binary
if [[ -x "$VECTOR_BIN" ]]; then
  siem_binary_exists "$VECTOR_BIN" "vector"
elif command -v vector >/dev/null 2>&1; then
  register_check "vector binary" PASS "$(command -v vector)"
fi

# Check service status
siem_service_check "$VECTOR_SERVICE" "Vector"
siem_service_enabled "$VECTOR_SERVICE" "Vector"

section "Vector Status"

# Get version
vector_version=$(vector --version 2>/dev/null | head -1 || echo "")
if [[ -n "$vector_version" ]]; then
  register_check "Version" PASS "$vector_version"
else
  register_check "Version" WARN "unable to determine"
fi

# Check graph/topology
topology=$(vector graph 2>/dev/null || echo "")
if [[ -n "$topology" ]]; then
  component_count=$(echo "$topology" | grep -c "^\s*\[" || echo "0")
  register_check "Pipeline components" PASS "$component_count"
else
  register_check "Pipeline components" SKIP "unable to query graph"
fi

section "Vector Configuration"

# Find config file
CONFIG_FILE=""
if [[ -f "$VECTOR_CONFIG" ]]; then
  CONFIG_FILE="$VECTOR_CONFIG"
elif [[ -f "$VECTOR_CONFIG_YAML" ]]; then
  CONFIG_FILE="$VECTOR_CONFIG_YAML"
fi

if [[ -n "$CONFIG_FILE" ]]; then
  siem_config_check "$CONFIG_FILE" "Main config"

  # Validate configuration
  validate_output=$(vector validate "$CONFIG_FILE" 2>&1 || echo "")
  if echo "$validate_output" | grep -qi "validated\|success\|ok"; then
    register_check "Config validation" PASS "valid"
  elif [[ -z "$validate_output" ]]; then
    register_check "Config validation" PASS "no errors"
  else
    register_check "Config validation" WARN "validation issues found"
  fi

  # Count sources
  source_count=$(grep -cE "^\[sources\." "$CONFIG_FILE" 2>/dev/null ||
    grep -cE "^sources:" "$CONFIG_FILE" 2>/dev/null || echo "0")
  register_check "Configured sources" PASS "$source_count"

  # Count transforms
  transform_count=$(grep -cE "^\[transforms\." "$CONFIG_FILE" 2>/dev/null || echo "0")
  if [[ "$transform_count" -gt 0 ]]; then
    register_check "Transforms" PASS "$transform_count"
  fi

  # Count sinks
  sink_count=$(grep -cE "^\[sinks\." "$CONFIG_FILE" 2>/dev/null ||
    grep -cE "^sinks:" "$CONFIG_FILE" 2>/dev/null || echo "0")
  register_check "Configured sinks" PASS "$sink_count"

  # Check for enterprise sinks
  if grep -qiE "(elasticsearch|clickhouse|datadog|splunk|kafka|loki|s3|gcs|azure)" "$CONFIG_FILE" 2>/dev/null; then
    register_check "Enterprise sinks" PASS "detected"
  fi

  # Check TLS configuration
  if grep -qiE "tls\.|ssl\s*=|ca_file|crt_file|key_file" "$CONFIG_FILE" 2>/dev/null; then
    register_check "TLS encryption" PASS "configured"
  else
    register_check "TLS encryption" WARN "not detected"
  fi

  # Check acknowledgements (prevents data loss)
  if grep -qiE "acknowledgements\s*=\s*true\|acknowledgements:\s*true" "$CONFIG_FILE" 2>/dev/null; then
    register_check "End-to-end acks" PASS "enabled"
  else
    register_check "End-to-end acks" WARN "not explicitly enabled"
  fi
else
  register_check "Main config" FAIL "no config file found"
fi

# Check config directory
siem_dir_exists "$VECTOR_CONFIG_DIR" "Config directory"

section "Vector API & Health"

# Check if API is enabled
api_enabled=false
if [[ -n "$CONFIG_FILE" ]] && grep -qiE "^\[api\]|api.*enabled\s*=\s*true" "$CONFIG_FILE" 2>/dev/null; then
  api_enabled=true
  register_check "API endpoint" PASS "enabled"

  # Try to query health endpoint
  api_addr=$(grep -oE "address\s*=\s*\"[^\"]+\"" "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*"\([^"]*\)".*/\1/' || echo "127.0.0.1:8686")
  if curl -sf "http://${api_addr}/health" >/dev/null 2>&1; then
    register_check "Health endpoint" PASS "responding"
  else
    register_check "Health endpoint" WARN "not responding at $api_addr"
  fi

  # Check GraphQL API
  if curl -sf "http://${api_addr}/graphql" -X POST -H "Content-Type: application/json" \
    -d '{"query": "{ health }"}' >/dev/null 2>&1; then
    register_check "GraphQL API" PASS "available"
  fi
else
  register_check "API endpoint" SKIP "not enabled"
fi

section "Vector Buffer & Storage"

# Check data directory
siem_dir_exists "$VECTOR_DATA_DIR" "Data directory"
siem_disk_space "$VECTOR_DATA_DIR" 10 "Data directory"

# Check buffer configuration
if [[ -n "$CONFIG_FILE" ]]; then
  if grep -qiE "buffer.*type\s*=\s*\"disk\"" "$CONFIG_FILE" 2>/dev/null; then
    register_check "Disk buffers" PASS "enabled"
    siem_queue_files "$VECTOR_DATA_DIR" 50000 "Disk buffer"
  else
    register_check "Disk buffers" WARN "using memory buffers (data loss risk)"
  fi
fi

section "Vector Security"

# Check config file permissions
if [[ -n "$CONFIG_FILE" ]]; then
  siem_file_perms "$CONFIG_FILE" "600|640|644" "Config file"
fi

# Check for credential exposure
if [[ -n "$CONFIG_FILE" ]]; then
  if grep -qiE "(password|api_key|secret|token)\s*=\s*\"[^$]" "$CONFIG_FILE" 2>/dev/null; then
    register_check "Credential exposure" WARN "plaintext credentials in config"
  else
    register_check "Credential exposure" PASS "no obvious plaintext secrets"
  fi

  # Check for environment variable usage
  if grep -qE "\\\$\{[A-Z_]+\}" "$CONFIG_FILE" 2>/dev/null; then
    register_check "Environment secrets" PASS "using env vars for secrets"
  fi
fi

# Check service user
vector_pid=$(pgrep -xo vector 2>/dev/null || echo "")
vector_user=""
if [[ -n "$vector_pid" ]]; then
  vector_user=$(ps -o user= -p "$vector_pid" 2>/dev/null | awk 'NR==1 {print $1}' || echo "")
fi
if [[ "$vector_user" == "root" ]]; then
  register_check "Service user" WARN "running as root"
elif [[ -n "$vector_user" ]]; then
  register_check "Service user" PASS "$vector_user"
fi

section "Vector Health"

# Check logs
readonly VECTOR_LOG="/var/log/vector.log"
if [[ -f "$VECTOR_LOG" ]]; then
  siem_log_activity "/var/log/vector*.log" "Vector" 60

  recent_errors=$(tail -500 "$VECTOR_LOG" 2>/dev/null | grep -ci "error\|warn" || echo "0")
  if [[ "$recent_errors" -gt 50 ]]; then
    register_check "Recent errors" WARN "$recent_errors errors/warnings"
  else
    register_check "Recent errors" PASS "$recent_errors issues"
  fi
else
  # Check journald
  if command -v journalctl >/dev/null 2>&1; then
    recent_errors=$(journalctl -u vector --since "1 hour ago" 2>/dev/null | grep -ci "error\|warn" || echo "0")
    register_check "Recent errors (journal)" PASS "$recent_errors issues"
  fi
fi

# Check internal metrics if API is available
if $api_enabled && command -v curl >/dev/null 2>&1; then
  metrics=$(curl -sf "http://${api_addr:-127.0.0.1:8686}/metrics" 2>/dev/null | head -20 || echo "")
  if [[ -n "$metrics" ]]; then
    register_check "Internal metrics" PASS "available"

    # Check for backpressure
    if echo "$metrics" | grep -q "events_discarded_total"; then
      discarded=$(echo "$metrics" | grep "events_discarded_total" | grep -oE "[0-9]+" | tail -1)
      if [[ "${discarded:-0}" -gt 1000 ]]; then
        register_check "Events discarded" WARN "$discarded events lost"
      else
        register_check "Events discarded" PASS "${discarded:-0}"
      fi
    fi
  fi
fi

# Check systemd integration
if command -v systemctl >/dev/null 2>&1; then
  restart_count=$(systemctl show -p NRestarts vector 2>/dev/null | cut -d= -f2 || echo "0")
  if [[ "${restart_count:-0}" -gt 5 ]]; then
    register_check "Service restarts" WARN "$restart_count restarts"
  else
    register_check "Service restarts" PASS "${restart_count:-0}"
  fi
fi

print_summary
exit "$EXIT_CODE"
