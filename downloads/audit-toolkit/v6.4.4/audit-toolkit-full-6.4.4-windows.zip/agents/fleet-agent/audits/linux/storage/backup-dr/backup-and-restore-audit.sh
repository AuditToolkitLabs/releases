#!/usr/bin/env bash
# Backup & Restore Security Audit (portable)
#
# @elevation: partial
# @elevation-reason: Backup config and directory permissions need root for full checks
#
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly BACKUP_DAYS=14
readonly MAX_FILES_DISPLAY=100
readonly RESTORE_STALE_DAYS=90

LOG_FILE="$DEFAULT_LOG_FILE"; QUIET=false; VERBOSE=false; VERY_VERBOSE=false; NO_COLOR=false; EXIT_CODE=0
BACKUP_DIRS=(/var/backups /backup /opt/backup /srv/backup)

setup_colors(){ if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'; GREEN=$'\e[0;32m'; YELLOW=$'\e[0;33m'; BLUE=$'\e[0;34m'; CYAN=$'\e[0;36m'; BOLD=$'\e[1m'; NC=$'\e[0m'; fi; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
_log(){ local level="$1"; shift||true; local msg="$*"; local ts line; ts="$(_timestamp)"; printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"; [[ "$QUIET" != "true" ]] && echo "$line"; [[ -n "$LOG_FILE" ]] && { echo "$line" >> "$LOG_FILE" 2>/dev/null || :; }; }
_dbg(){ [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*" || :; }
_trace(){ [[ "$VERY_VERBOSE" == "true" ]] && _log TRACE "$*"; }
TOTAL_CHECKS=0; PASSED_CHECKS=0; FAILED_CHECKS=0; WARNING_CHECKS=0; SKIPPED_CHECKS=0
register_check(){ local n="$1" r="$2" m="${3:-}"; ((++TOTAL_CHECKS)); case "$r" in PASS) ((++PASSED_CHECKS)); echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}";; FAIL) ((++FAILED_CHECKS)); EXIT_CODE=2; echo -e " ${RED}[FAIL]${NC}  $n${m:+: $m}";; WARN) ((++WARNING_CHECKS)); [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1; echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}";; SKIP) ((++SKIPPED_CHECKS)); echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}";; esac; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >> "$LOG_FILE" 2>/dev/null || true; }
check_root_register(){ local msg="${1:-Run as root for complete results}"; if [[ ${EUID:-$(id -u)} -ne 0 ]]; then register_check "Root privileges" WARN "$msg"; return 1; else register_check "Root privileges" PASS "Running as root"; return 0; fi; }
section(){ local t="$1"; echo; echo -e "${BOLD}${CYAN}============================================================${NC}"; echo -e "${BOLD}${CYAN} $t${NC}"; echo -e "${BOLD}${CYAN}============================================================${NC}"; [[ -n "$LOG_FILE" ]] && { echo; echo "=== $t ==="; } >> "$LOG_FILE" 2>/dev/null || :; }

audit_backup_dirs(){ section "Backup Directories"; local found=0 total=0; local p; for p in "${BACKUP_DIRS[@]}"; do
  if [[ -d "$p" ]]; then ((found++)); local mode owner count; mode=$(stat -c '%a' "$p" 2>/dev/null || echo '?'); owner=$(stat -c '%U:%G' "$p" 2>/dev/null || echo '?:?'); count=$(find "$p" -type f -mtime -$BACKUP_DAYS 2>/dev/null | wc -l || echo 0); total=$((total+count)); local last="${mode: -1}"; if [[ "$last" =~ [2367] ]]; then register_check "Backup dir: $p" WARN "world-writable (mode=$mode, recent=$count)"; elif [[ ${count:-0} -gt 0 ]]; then register_check "Backup dir: $p" PASS "mode=$mode owner=$owner recent=$count (last ${BACKUP_DAYS}d)"; else register_check "Backup dir: $p" WARN "no recent files (mode=$mode)"; fi; if [[ "$VERBOSE" == "true" && ${count:-0} -gt 0 ]]; then _log DEBUG "Recent files in $p (max $MAX_FILES_DISPLAY):"; find "$p" -type f -mtime -$BACKUP_DAYS -printf ' %TY-%Tm-%Td %TH:%TM %p
' 2>/dev/null | head -n "$MAX_FILES_DISPLAY" | while read -r l; do _log DEBUG "$l"; done; fi
  else register_check "Backup dir: $p" SKIP "not present"; fi; done; [[ $found -eq 0 ]] && register_check "Standard backup dirs" WARN "none found (checked: ${BACKUP_DIRS[*]})" || register_check "Backup dirs found" PASS "$found with $total recent files"; }

audit_backup_tools(){ section "Backup Tools"; local tools=(restic duplicity borg rclone rsync tarsnap bacula amanda); local found=0 t; for t in "${tools[@]}"; do if command -v "$t" >/dev/null 2>&1; then local ver; ver=$("$t" --version 2>&1 | head -n1 || echo "unknown"); register_check "Tool: $t" PASS "$ver"; ((found++)); else register_check "Tool: $t" SKIP "not installed"; fi; done; [[ $found -eq 0 ]] && register_check "Backup tools installed" WARN "none (consider restic/borg/duplicity)" || register_check "Backup tools installed" PASS "$found"; }

audit_schedules(){ section "Backup Schedules"; local sched; if sched=$(has_timer_or_cron 'backup\|restic\|borg\|duplicity\|rclone\|borgmatic'); then register_check "Automated backups" PASS "$sched found"; else register_check "Automated backups" WARN "no timer/cron detected"; fi
  # common service names
  local services=(borgmatic restic-backup duplicity-backup rsync-backup backup); local s any=0; for s in "${services[@]}"; do if svc_is_active "$s"; then register_check "Service: $s" PASS "active"; ((any++)); elif svc_is_enabled "$s"; then register_check "Service: $s" WARN "enabled but inactive"; ((any++)); fi; done; [[ $any -eq 0 ]] && register_check "Backup services" SKIP "none detected"; }

audit_restore_marker(){ section "Restore Test Verification"; local marker="/var/backups/.last_restore_test"; if [[ -f "$marker" ]]; then local mdate mepoch now days content; content=$(cat "$marker" 2>/dev/null || echo '<unreadable>'); mepoch=$(stat -c '%Y' "$marker" 2>/dev/null || echo 0); now=$(date +%s); days=$(( (now - mepoch) / 86400 )); if (( days > RESTORE_STALE_DAYS )); then register_check "Restore test marker" WARN "stale (${days} days old)"; elif (( days > 30 )); then register_check "Restore test marker" PASS "performed ${days} days ago"; else register_check "Restore test marker" PASS "recent (${days} days ago)"; fi; [[ "$VERBOSE" == "true" ]] && { _log DEBUG " Marker content: $content"; } else register_check "Restore test marker" WARN "not found ($marker)"; _log INFO "Recommendation: echo "$(date -Iseconds) - Restore test successful" | sudo tee $marker >/dev/null"; fi }

audit_encryption(){ section "Backup Encryption"; local enc=0
  if command -v gpg >/dev/null 2>&1; then local cnt; cnt=$(gpg --list-keys 2>/dev/null | grep -c '^pub' || echo 0); [[ $cnt -gt 0 ]] && { register_check "GPG keys" PASS "$cnt configured"; ((enc++)); } || register_check "GPG keys" SKIP "none configured"; else register_check "GPG" SKIP "not installed"; fi
  [[ -f /etc/restic-backup/repository || -d /var/backups/restic ]] && { register_check "Restic repository" PASS "detected (encrypted by default)"; ((enc++)); }
  local p; for p in "${BACKUP_DIRS[@]}"; do [[ -d "$p" ]] || continue; local repo; repo=$(find "$p" -maxdepth 2 -name config -exec grep -l 'BORG' {} \; 2>/dev/null | head -n1 || true); [[ -n "$repo" ]] && { register_check "Borg repository" PASS "detected in $p"; ((enc++)); break; }; done
  if [[ -f /etc/borgmatic/config.yaml ]] || compgen -G "/etc/borgmatic.d/*.yaml" > /dev/null; then register_check "Borgmatic config" PASS "found"; ((enc++)); fi
  [[ $enc -eq 0 ]] && register_check "Encrypted backup setup" WARN "none detected (consider restic/borg/GPG)" || register_check "Encrypted backup indicators" PASS "$enc"; }

audit_cloud_configs(){ section "Cloud/Remote Backup Configuration"; local n=0; [[ -f ~/.config/rclone/rclone.conf || -f /root/.config/rclone/rclone.conf ]] && { register_check "rclone config" PASS "found"; ((n++)); }
  [[ -f ~/.aws/credentials || -f /root/.aws/credentials ]] && { register_check "AWS credentials" PASS "found (potential S3 backups)"; ((n++)); }
  [[ -f /etc/restic-backup/env || -f /etc/default/restic ]] && { register_check "Restic env config" PASS "found"; ((n++)); }
  [[ $n -eq 0 ]] && register_check "Cloud/remote backup configs" SKIP "none detected" || register_check "Cloud/remote backup configs" PASS "$n"; }

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
Portable backup & restore audit
  -l, --log FILE         Log file (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout
  -v, --verbose          Debug
  -vv, --very-verbose    Trace
      --no-color         Disable color
  -h, --help             Help
      --version          Version
EOF
}
version(){ echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

print_summary(){ echo; echo -e "${BOLD}BACKUP & RESTORE AUDIT SUMMARY${NC}"; printf " PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d
" "$PASSED_CHECKS" "$WARNING_CHECKS" "$FAILED_CHECKS" "$SKIPPED_CHECKS" "$TOTAL_CHECKS"; }

main(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-$DEFAULT_LOG_FILE}"; shift 2;; -q|--quiet) QUIET=true; shift;; -v|--verbose) VERBOSE=true; shift;; -vv|--very-verbose) VERY_VERBOSE=true; VERBOSE=true; shift;; --no-color) NO_COLOR=true; shift;; -h|--help) usage; exit 0;; --version) version; exit 0;; *) echo "Unknown option: $1" >&2; usage >&2; exit 1;; esac; done
  setup_colors; [[ -n "$LOG_FILE" ]] && { mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true; touch "$LOG_FILE" 2>/dev/null || true; }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  check_root_register "Run as root for complete results"
  audit_backup_dirs; audit_backup_tools; audit_schedules; audit_restore_marker; audit_encryption; audit_cloud_configs; print_summary; exit "$EXIT_CODE";
}
main "$@"
