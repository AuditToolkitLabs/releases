#!/usr/bin/env bash
# bacula-audit.sh — Bacula Backup Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Bacula File Daemon (FD) installation
# - Service status
# - Configuration security
# - TLS/encryption
# - Director connection
# - Password security
#
# @elevation: partial
# @elevation-reason: Bacula configs in /etc/bacula require root for full access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Bacula Installation"

# Check for Bacula components
bacula_fd=false
bacula_dir=false
bacula_sd=false

if command -v bacula-fd >/dev/null 2>&1 || [[ -f "/usr/sbin/bacula-fd" ]]; then
  bacula_fd=true
  register_check "Bacula File Daemon" PASS "installed"
fi

if command -v bacula-dir >/dev/null 2>&1 || [[ -f "/usr/sbin/bacula-dir" ]]; then
  bacula_dir=true
  register_check "Bacula Director" PASS "installed"
fi

if command -v bacula-sd >/dev/null 2>&1 || [[ -f "/usr/sbin/bacula-sd" ]]; then
  bacula_sd=true
  register_check "Bacula Storage Daemon" PASS "installed"
fi

if ! $bacula_fd && ! $bacula_dir && ! $bacula_sd; then
  register_check "Bacula installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

# Get version
bacula_version=$(bacula-fd -v 2>&1 | grep -iE "version" | head -n1 || echo "unknown")
register_check "Bacula version" PASS "$bacula_version"

section "Service Status"

# Check File Daemon service
if is_systemd; then
  if $bacula_fd; then
    if systemctl is-active bacula-fd >/dev/null 2>&1; then
      register_check "FD service" PASS "running"
    else
      register_check "FD service" WARN "not running"
    fi

    if systemctl is-enabled bacula-fd >/dev/null 2>&1; then
      register_check "FD enabled" PASS "yes"
    else
      register_check "FD enabled" WARN "no"
    fi
  fi

  if $bacula_dir; then
    if systemctl is-active bacula-dir >/dev/null 2>&1; then
      register_check "Director service" PASS "running"
    else
      register_check "Director service" WARN "not running"
    fi
  fi

  if $bacula_sd; then
    if systemctl is-active bacula-sd >/dev/null 2>&1; then
      register_check "SD service" PASS "running"
    else
      register_check "SD service" WARN "not running"
    fi
  fi
elif is_openrc; then
  if $bacula_fd && rc-service bacula-fd status >/dev/null 2>&1; then
    register_check "FD service" PASS "running"
  fi
else
  if pgrep -x bacula-fd >/dev/null 2>&1; then
    register_check "FD service" PASS "running"
  fi
fi

section "File Daemon Configuration"

fd_conf="/etc/bacula/bacula-fd.conf"
if [[ ! -f "$fd_conf" ]]; then
  fd_conf="/etc/bacula-fd.conf"
fi

if [[ -f "$fd_conf" ]]; then
  register_check "FD config" PASS "exists"

  # Check file permissions
  conf_perms=$(stat -c "%a" "$fd_conf" 2>/dev/null || echo "unknown")
  if [[ "$conf_perms" == "640" ]] || [[ "$conf_perms" == "600" ]]; then
    register_check "FD config perms" PASS "$conf_perms"
  else
    register_check "FD config perms" FAIL "$conf_perms (should be 640)"
  fi

  conf_owner=$(stat -c "%U:%G" "$fd_conf" 2>/dev/null || echo "unknown")
  register_check "FD config owner" PASS "$conf_owner"

  # Check for TLS configuration
  if grep -qE "^\s*TLS\s*Enable\s*=\s*yes" "$fd_conf" 2>/dev/null; then
    register_check "FD TLS enabled" PASS "yes"

    # Check TLS certificate
    if grep -qE "^\s*TLS\s*Certificate\s*=" "$fd_conf" 2>/dev/null; then
      tls_cert=$(grep -E "^\s*TLS\s*Certificate\s*=" "$fd_conf" | awk -F= '{print $2}' | tr -d ' "' | head -n1)
      if [[ -f "$tls_cert" ]]; then
        register_check "FD TLS cert" PASS "exists"
      else
        register_check "FD TLS cert" WARN "not found at $tls_cert"
      fi
    fi

    # Check TLS key
    if grep -qE "^\s*TLS\s*Key\s*=" "$fd_conf" 2>/dev/null; then
      tls_key=$(grep -E "^\s*TLS\s*Key\s*=" "$fd_conf" | awk -F= '{print $2}' | tr -d ' "' | head -n1)
      if [[ -f "$tls_key" ]]; then
        key_perms=$(stat -c "%a" "$tls_key" 2>/dev/null || echo "unknown")
        if [[ "$key_perms" == "600" ]] || [[ "$key_perms" == "400" ]]; then
          register_check "FD TLS key perms" PASS "$key_perms"
        else
          register_check "FD TLS key perms" FAIL "$key_perms (should be 600)"
        fi
      fi
    fi

    # Check TLS Require
    if grep -qE "^\s*TLS\s*Require\s*=\s*yes" "$fd_conf" 2>/dev/null; then
      register_check "FD TLS required" PASS "yes"
    else
      register_check "FD TLS required" WARN "no (optional)"
    fi
  else
    register_check "FD TLS enabled" FAIL "no"
  fi

  # Check for MaximumConcurrentJobs
  max_jobs=$(grep -E "^\s*Maximum\s*Concurrent\s*Jobs\s*=" "$fd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' ' | head -n1)
  if [[ -n "$max_jobs" ]]; then
    register_check "Max concurrent jobs" PASS "$max_jobs"
  fi
else
  register_check "FD config" WARN "not found"
fi

section "Director Configuration"

dir_conf="/etc/bacula/bacula-dir.conf"
if [[ -f "$dir_conf" ]] && $bacula_dir; then
  register_check "Director config" PASS "exists"

  # Check permissions
  dir_perms=$(stat -c "%a" "$dir_conf" 2>/dev/null || echo "unknown")
  if [[ "$dir_perms" == "640" ]] || [[ "$dir_perms" == "600" ]]; then
    register_check "Dir config perms" PASS "$dir_perms"
  else
    register_check "Dir config perms" FAIL "$dir_perms (should be 640)"
  fi

  # Check catalog database
  catalog=$(grep -E "^\s*dbname\s*=" "$dir_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' "' | head -n1)
  if [[ -n "$catalog" ]]; then
    register_check "Catalog database" PASS "$catalog"
  fi

  # Check for TLS
  if grep -qE "^\s*TLS\s*Enable\s*=\s*yes" "$dir_conf" 2>/dev/null; then
    register_check "Director TLS" PASS "enabled"
  else
    register_check "Director TLS" WARN "not enabled"
  fi
fi

section "Password Security"

# Check for plaintext passwords in config
if [[ -f "$fd_conf" ]]; then
  # Count password entries
  pwd_count=$(grep -cE "^\s*Password\s*=" "$fd_conf" 2>/dev/null || echo "0")
  if [[ "$pwd_count" -gt 0 ]]; then
    register_check "Password entries" PASS "$pwd_count configured"

    # Check password length (simple heuristic)
    short_pwd=0
    while IFS= read -r pwd_line; do
      pwd_val=$(echo "$pwd_line" | awk -F= '{print $2}' | tr -d ' "' | head -n1)
      if [[ ${#pwd_val} -lt 16 ]]; then
        ((short_pwd++)) || true
      fi
    done < <(grep -E "^\s*Password\s*=" "$fd_conf" 2>/dev/null)

    if [[ "$short_pwd" -eq 0 ]]; then
      register_check "Password length" PASS "adequate"
    else
      register_check "Password length" WARN "$short_pwd short passwords"
    fi
  fi
fi

section "Storage Daemon Configuration"

sd_conf="/etc/bacula/bacula-sd.conf"
if [[ -f "$sd_conf" ]] && $bacula_sd; then
  register_check "SD config" PASS "exists"

  # Check permissions
  sd_perms=$(stat -c "%a" "$sd_conf" 2>/dev/null || echo "unknown")
  if [[ "$sd_perms" == "640" ]] || [[ "$sd_perms" == "600" ]]; then
    register_check "SD config perms" PASS "$sd_perms"
  else
    register_check "SD config perms" FAIL "$sd_perms"
  fi

  # Check for TLS
  if grep -qE "^\s*TLS\s*Enable\s*=\s*yes" "$sd_conf" 2>/dev/null; then
    register_check "SD TLS" PASS "enabled"
  else
    register_check "SD TLS" WARN "not enabled"
  fi

  # Check storage paths
  archive_device=$(grep -E "^\s*Archive\s*Device\s*=" "$sd_conf" 2>/dev/null | awk -F= '{print $2}' | tr -d ' "' | head -n1)
  if [[ -n "$archive_device" ]] && [[ -d "$archive_device" ]]; then
    register_check "Archive device" PASS "$archive_device"

    arch_perms=$(stat -c "%a" "$archive_device" 2>/dev/null || echo "unknown")
    if [[ "$arch_perms" == "700" ]] || [[ "$arch_perms" == "750" ]]; then
      register_check "Archive perms" PASS "$arch_perms"
    else
      register_check "Archive perms" WARN "$arch_perms"
    fi
  fi
fi

section "bconsole Access"

# Check bconsole config
bconsole_conf="/etc/bacula/bconsole.conf"
if [[ -f "$bconsole_conf" ]]; then
  register_check "bconsole config" PASS "exists"

  bc_perms=$(stat -c "%a" "$bconsole_conf" 2>/dev/null || echo "unknown")
  if [[ "$bc_perms" == "640" ]] || [[ "$bc_perms" == "600" ]]; then
    register_check "bconsole perms" PASS "$bc_perms"
  else
    register_check "bconsole perms" WARN "$bc_perms"
  fi
fi

section "Network Security"

# Check listening ports
if command -v ss >/dev/null 2>&1; then
  # FD port (default 9102)
  if ss -tlnp 2>/dev/null | grep -q ":9102"; then
    fd_bind=$(ss -tlnp 2>/dev/null | grep ":9102" | awk '{print $4}' | head -n1)
    if echo "$fd_bind" | grep -qE "^127\.|^::1|^\[::1\]"; then
      register_check "FD port binding" WARN "localhost only"
    else
      register_check "FD port binding" PASS "$fd_bind"
    fi
  fi

  # Director port (default 9101)
  if ss -tlnp 2>/dev/null | grep -q ":9101"; then
    register_check "Director port" PASS "listening"
  fi

  # SD port (default 9103)
  if ss -tlnp 2>/dev/null | grep -q ":9103"; then
    register_check "SD port" PASS "listening"
  fi
fi

section "Log Security"

# Check log file security
bacula_log="/var/log/bacula"
if [[ -d "$bacula_log" ]]; then
  log_perms=$(stat -c "%a" "$bacula_log" 2>/dev/null || echo "unknown")
  if [[ "$log_perms" == "750" ]] || [[ "$log_perms" == "700" ]]; then
    register_check "Log dir perms" PASS "$log_perms"
  else
    register_check "Log dir perms" WARN "$log_perms"
  fi
fi

print_summary
exit "$EXIT_CODE"
