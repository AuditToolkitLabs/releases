#!/usr/bin/env bash
# borg-backup-audit.sh — BorgBackup Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Borg installation and version
# - Repository configuration
# - Encryption status
# - Backup recency
# - Prune/retention policy
# - Repository integrity
#
# @elevation: partial
# @elevation-reason: Borg repo configs and keyfiles may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "BorgBackup Installation"

# Check if borg is installed
if ! command -v borg >/dev/null 2>&1; then
  register_check "Borg installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Borg installed" PASS "found"

# Get version
borg_version=$(borg --version 2>/dev/null | head -n1 || echo "unknown")
register_check "Borg version" PASS "$borg_version"

# Check for minimum secure version
version_num=$(echo "$borg_version" | grep -oE '[0-9]+\.[0-9]+' | head -n1)
if [[ -n "$version_num" ]]; then
  major=$(echo "$version_num" | cut -d. -f1)
  minor=$(echo "$version_num" | cut -d. -f2)
  if [[ "$major" -ge 1 ]] && [[ "$minor" -ge 2 ]]; then
    register_check "Borg version security" PASS "recent version"
  else
    register_check "Borg version security" WARN "consider upgrade"
  fi
fi

section "Repository Discovery"

# Common repository locations
repo_paths=(
  "/backup/borg"
  "/var/backup/borg"
  "/mnt/backup/borg"
  "$HOME/.borg"
  "$HOME/backup"
)

# Check BORG_REPO environment variable
if [[ -n "${BORG_REPO:-}" ]]; then
  register_check "BORG_REPO env" PASS "$BORG_REPO"
  repo_paths=("$BORG_REPO" "${repo_paths[@]}")
fi

# Check for borgmatic config
borgmatic_conf=""
if [[ -f "/etc/borgmatic/config.yaml" ]]; then
  borgmatic_conf="/etc/borgmatic/config.yaml"
elif [[ -f "$HOME/.config/borgmatic/config.yaml" ]]; then
  borgmatic_conf="$HOME/.config/borgmatic/config.yaml"
fi

if [[ -n "$borgmatic_conf" ]]; then
  register_check "Borgmatic config" PASS "found"

  # Check borgmatic config permissions
  conf_perms=$(stat -c "%a" "$borgmatic_conf" 2>/dev/null || echo "unknown")
  if [[ "$conf_perms" == "600" ]] || [[ "$conf_perms" == "640" ]]; then
    register_check "Borgmatic config perms" PASS "$conf_perms"
  else
    register_check "Borgmatic config perms" WARN "$conf_perms (should be 600)"
  fi

  # Extract repositories from borgmatic
  if command -v borgmatic >/dev/null 2>&1; then
    borgmatic_repos=$(borgmatic list --json 2>/dev/null | grep -oE '"repository":\s*"[^"]+"' | head -n3 || echo "")
    if [[ -n "$borgmatic_repos" ]]; then
      register_check "Borgmatic repos" PASS "configured"
    fi
  fi
fi

# Find accessible repositories
found_repos=0
for repo in "${repo_paths[@]}"; do
  if [[ -d "$repo" ]] || [[ -f "$repo/config" ]] || [[ -f "$repo/README" ]]; then
    ((found_repos++)) || true

    # Check if it's a valid borg repo
    if [[ -f "$repo/config" ]]; then
      register_check "Repository $repo" PASS "valid"
    fi
  fi
done

if [[ "$found_repos" -eq 0 ]]; then
  register_check "Repositories" WARN "none found locally"
fi

section "Repository Security"

# Function to check a repository
check_repository() {
  local repo="$1"

  # Check encryption
  if [[ -n "${BORG_PASSPHRASE:-}" ]] || [[ -n "${BORG_PASSCOMMAND:-}" ]]; then
    register_check "Passphrase method" PASS "environment/command"
  fi

  # Try to get repository info (requires passphrase)
  repo_info=$(borg info "$repo" 2>/dev/null || echo "")

  if [[ -n "$repo_info" ]]; then
    # Check encryption mode
    encryption=$(echo "$repo_info" | grep -E "^Encrypted:" | awk '{print $2}' || echo "")
    if [[ "$encryption" == "Yes" ]]; then
      register_check "Encryption" PASS "enabled"

      # Check encryption mode
      enc_mode=$(echo "$repo_info" | grep -E "^Encryption:" | awk '{print $2}' || echo "")
      if echo "$enc_mode" | grep -qiE "repokey|keyfile"; then
        register_check "Encryption mode" PASS "$enc_mode"
      fi
    else
      register_check "Encryption" FAIL "not encrypted"
    fi

    # Check repository ID (unique identifier)
    repo_id=$(echo "$repo_info" | grep -E "^Repository ID:" | awk '{print $3}' || echo "")
    if [[ -n "$repo_id" ]]; then
      register_check "Repository ID" PASS "verified"
    fi
  fi
}

# Check BORG_REPO if set
if [[ -n "${BORG_REPO:-}" ]] && [[ -n "${BORG_PASSPHRASE:-}" ]]; then
  check_repository "$BORG_REPO"
fi

section "Backup Recency"

# Check last backup via borgmatic or borg directly
last_backup_check() {
  local repo="$1"

  # Get last archive
  last_archive=$(borg list --last 1 --short "$repo" 2>/dev/null || echo "")

  if [[ -n "$last_archive" ]]; then
    register_check "Last archive" PASS "$last_archive"

    # Try to get archive date
    archive_info=$(borg info "${repo}::${last_archive}" 2>/dev/null || echo "")
    if [[ -n "$archive_info" ]]; then
      archive_time=$(echo "$archive_info" | grep -E "^Time \(start\):" | awk -F': ' '{print $2}' || echo "")
      if [[ -n "$archive_time" ]]; then
        archive_epoch=$(date -d "$archive_time" +%s 2>/dev/null || echo "0")
        now_epoch=$(date +%s)
        hours_ago=$(( (now_epoch - archive_epoch) / 3600 ))

        if [[ "$hours_ago" -lt 24 ]]; then
          register_check "Backup age" PASS "${hours_ago}h ago"
        elif [[ "$hours_ago" -lt 168 ]]; then
          days=$((hours_ago / 24))
          register_check "Backup age" WARN "${days}d ago"
        else
          days=$((hours_ago / 24))
          register_check "Backup age" FAIL "${days}d ago"
        fi
      fi
    fi
  else
    register_check "Last archive" WARN "none found or access denied"
  fi
}

# Use borgmatic if available
if command -v borgmatic >/dev/null 2>&1; then
  borgmatic_list=$(borgmatic list --last 1 2>/dev/null || echo "")
  if [[ -n "$borgmatic_list" ]]; then
    last_backup=$(echo "$borgmatic_list" | tail -n1)
    register_check "Borgmatic last backup" PASS "$last_backup"
  fi
elif [[ -n "${BORG_REPO:-}" ]]; then
  last_backup_check "$BORG_REPO"
fi

section "Backup Schedule"

# Check systemd timers
if is_systemd; then
  borg_timer=$(systemctl list-timers --all 2>/dev/null | grep -iE "borg|borgmatic" || echo "")
  if [[ -n "$borg_timer" ]]; then
    register_check "Systemd timer" PASS "configured"

    # Check if timer is enabled
    if systemctl is-enabled borgmatic.timer >/dev/null 2>&1 || systemctl is-enabled borg-backup.timer >/dev/null 2>&1; then
      register_check "Timer enabled" PASS "yes"
    fi
  else
    register_check "Systemd timer" WARN "not found"
  fi
fi

# Check cron jobs
cron_jobs=$(crontab -l 2>/dev/null | grep -iE "borg|borgmatic" || echo "")
if [[ -n "$cron_jobs" ]]; then
  register_check "Cron job" PASS "configured"
fi

# Check /etc/cron.d
if [[ -d "/etc/cron.d" ]]; then
  cron_d_jobs=$(grep -rliE "borg|borgmatic" /etc/cron.d/ 2>/dev/null | wc -l || echo "0")
  if [[ "$cron_d_jobs" -gt 0 ]]; then
    register_check "Cron.d jobs" PASS "$cron_d_jobs files"
  fi
fi

section "Prune/Retention Policy"

# Check borgmatic for retention settings
if [[ -n "$borgmatic_conf" ]]; then
  if grep -qE "keep_daily:|keep_weekly:|keep_monthly:" "$borgmatic_conf" 2>/dev/null; then
    register_check "Retention policy" PASS "configured"

    # Extract retention values
    keep_daily=$(grep -E "keep_daily:" "$borgmatic_conf" 2>/dev/null | awk '{print $2}' || echo "")
    keep_weekly=$(grep -E "keep_weekly:" "$borgmatic_conf" 2>/dev/null | awk '{print $2}' || echo "")
    keep_monthly=$(grep -E "keep_monthly:" "$borgmatic_conf" 2>/dev/null | awk '{print $2}' || echo "")

    if [[ -n "$keep_daily" ]]; then
      register_check "Keep daily" PASS "$keep_daily"
    fi
    if [[ -n "$keep_weekly" ]]; then
      register_check "Keep weekly" PASS "$keep_weekly"
    fi
    if [[ -n "$keep_monthly" ]]; then
      register_check "Keep monthly" PASS "$keep_monthly"
    fi
  else
    register_check "Retention policy" WARN "not configured"
  fi
fi

section "Security Configuration"

# Check for passphrase file security
if [[ -n "${BORG_PASSCOMMAND:-}" ]]; then
  register_check "Passphrase method" PASS "command-based"
elif [[ -n "${BORG_PASSPHRASE:-}" ]]; then
  register_check "Passphrase method" WARN "environment variable"
elif [[ -f "$HOME/.borg-passphrase" ]]; then
  pass_perms=$(stat -c "%a" "$HOME/.borg-passphrase" 2>/dev/null || echo "unknown")
  if [[ "$pass_perms" == "600" ]] || [[ "$pass_perms" == "400" ]]; then
    register_check "Passphrase file perms" PASS "$pass_perms"
  else
    register_check "Passphrase file perms" FAIL "$pass_perms (should be 600)"
  fi
fi

# Check for key export security
key_export_dir="$HOME/.config/borg/keys"
if [[ -d "$key_export_dir" ]]; then
  key_perms=$(stat -c "%a" "$key_export_dir" 2>/dev/null || echo "unknown")
  if [[ "$key_perms" == "700" ]]; then
    register_check "Keys dir perms" PASS "$key_perms"
  else
    register_check "Keys dir perms" WARN "$key_perms (should be 700)"
  fi
fi

# Check SSH key for remote repos
if [[ -n "${BORG_RSH:-}" ]]; then
  register_check "Custom SSH" PASS "configured"
fi

section "Repository Integrity"

# Check for integrity verification schedule
if [[ -n "$borgmatic_conf" ]]; then
  if grep -qE "check|verify" "$borgmatic_conf" 2>/dev/null; then
    register_check "Integrity checks" PASS "configured"
  else
    register_check "Integrity checks" WARN "not configured"
  fi
fi

# Check last check timestamp (if available)
borg_cache="$HOME/.cache/borg"
if [[ -d "$borg_cache" ]]; then
  register_check "Borg cache" PASS "exists"

  cache_perms=$(stat -c "%a" "$borg_cache" 2>/dev/null || echo "unknown")
  if [[ "$cache_perms" == "700" ]]; then
    register_check "Cache perms" PASS "$cache_perms"
  else
    register_check "Cache perms" WARN "$cache_perms"
  fi
fi

section "Compression & Deduplication"

# Check borgmatic for compression settings
if [[ -n "$borgmatic_conf" ]]; then
  compression=$(grep -E "compression:" "$borgmatic_conf" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ -n "$compression" ]]; then
    register_check "Compression" PASS "$compression"
  else
    register_check "Compression" WARN "default (lz4)"
  fi
fi

print_summary
exit "$EXIT_CODE"
