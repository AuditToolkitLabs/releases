#!/usr/bin/env bash
# duplicity-audit.sh — Duplicity Backup Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Duplicity installation
# - GPG encryption configuration
# - Backup schedule
# - Backend security
# - Retention policy
#
# @elevation: partial
# @elevation-reason: Duplicity configs and GPG keyrings may need root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Duplicity Installation"

# Check if duplicity is installed
if ! command -v duplicity >/dev/null 2>&1; then
  register_check "Duplicity installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Duplicity installed" PASS "found"

# Get version
dup_version=$(duplicity --version 2>/dev/null | head -n1 || echo "unknown")
register_check "Duplicity version" PASS "$dup_version"

# Check Python version (duplicity 0.8+ requires Python 3)
python_version=$(python3 --version 2>/dev/null || python --version 2>/dev/null || echo "unknown")
register_check "Python version" PASS "$python_version"

section "GPG/Encryption Configuration"

# Check for GPG
if command -v gpg >/dev/null 2>&1; then
  register_check "GPG installed" PASS "found"

  gpg_version=$(gpg --version 2>/dev/null | head -n1 || echo "unknown")
  register_check "GPG version" PASS "$gpg_version"

  # Check for GPG keys
  gpg_keys=$(gpg --list-keys 2>/dev/null | grep -c "^pub" || echo "0")
  if [[ "$gpg_keys" -gt 0 ]]; then
    register_check "GPG keys" PASS "$gpg_keys keys"
  else
    register_check "GPG keys" WARN "no keys found"
  fi

  # Check GPG agent
  if pgrep -x gpg-agent >/dev/null 2>&1; then
    register_check "GPG agent" PASS "running"
  else
    register_check "GPG agent" WARN "not running"
  fi
else
  register_check "GPG installed" WARN "not found"
fi

# Check PASSPHRASE environment variable
if [[ -n "${PASSPHRASE:-}" ]]; then
  register_check "Passphrase method" WARN "environment variable"
elif [[ -n "${GPG_KEY:-}" ]]; then
  register_check "GPG key ID" PASS "configured"
fi

section "Backend Configuration"

# Check for common backend URLs in environment
backends_found=0

if [[ -n "${FTP_PASSWORD:-}" ]]; then
  ((backends_found++)) || true
  register_check "FTP backend" WARN "credentials in env"
fi

if [[ -n "${AWS_ACCESS_KEY_ID:-}" ]]; then
  ((backends_found++)) || true
  register_check "S3 backend" PASS "credentials found"

  # Check for S3 encryption
  if [[ -n "${S3_USE_SSE:-}" ]]; then
    register_check "S3 SSE encryption" PASS "enabled"
  fi
fi

if [[ -n "${SWIFT_USERNAME:-}" ]]; then
  ((backends_found++)) || true
  register_check "Swift backend" PASS "credentials found"
fi

if [[ -n "${AZURE_ACCOUNT_NAME:-}" ]]; then
  ((backends_found++)) || true
  register_check "Azure backend" PASS "credentials found"
fi

if [[ -n "${GS_ACCESS_KEY_ID:-}" ]] || [[ -n "${GOOGLE_APPLICATION_CREDENTIALS:-}" ]]; then
  ((backends_found++)) || true
  register_check "GCS backend" PASS "credentials found"
fi

if [[ "$backends_found" -eq 0 ]]; then
  register_check "Backend config" WARN "no backends detected in env"
fi

section "Backup Scripts"

# Look for duplicity backup scripts
script_locations=(
  "/root/backup.sh"
  "/root/duplicity-backup.sh"
  "/usr/local/bin/backup.sh"
  "/usr/local/bin/duplicity-backup"
  "/opt/backup/duplicity.sh"
)

backup_script=""
for script in "${script_locations[@]}"; do
  if [[ -f "$script" ]]; then
    backup_script="$script"
    register_check "Backup script" PASS "$script"

    # Check script permissions
    script_perms=$(stat -c "%a" "$script" 2>/dev/null || echo "unknown")
    if [[ "$script_perms" == "700" ]] || [[ "$script_perms" == "750" ]]; then
      register_check "Script perms" PASS "$script_perms"
    else
      register_check "Script perms" WARN "$script_perms"
    fi

    # Check for encryption flag
    if grep -qE "\-\-encrypt-key|\-\-encrypt-sign-key|GPG_KEY" "$script" 2>/dev/null; then
      register_check "Script encryption" PASS "uses GPG"
    elif grep -qE "\-\-no-encryption" "$script" 2>/dev/null; then
      register_check "Script encryption" FAIL "no encryption"
    else
      register_check "Script encryption" WARN "check encryption config"
    fi

    # Check for full backup interval
    if grep -qE "full-if-older-than" "$script" 2>/dev/null; then
      full_interval=$(grep -oE "full-if-older-than\s+[0-9]+[DWM]" "$script" | head -n1 || echo "")
      if [[ -n "$full_interval" ]]; then
        register_check "Full backup interval" PASS "$full_interval"
      fi
    fi

    break
  fi
done

if [[ -z "$backup_script" ]]; then
  register_check "Backup script" WARN "not found in common locations"
fi

section "Backup Schedule"

# Check cron jobs
cron_jobs=$(crontab -l 2>/dev/null | grep -iE "duplicity" || echo "")
if [[ -n "$cron_jobs" ]]; then
  register_check "Cron job" PASS "configured"
fi

# Check /etc/cron.d
if [[ -d "/etc/cron.d" ]]; then
  cron_d_jobs=$(grep -rliE "duplicity" /etc/cron.d/ 2>/dev/null | wc -l || echo "0")
  if [[ "$cron_d_jobs" -gt 0 ]]; then
    register_check "Cron.d jobs" PASS "$cron_d_jobs files"
  fi
fi

# Check systemd timers
if is_systemd; then
  dup_timer=$(systemctl list-timers --all 2>/dev/null | grep -iE "duplicity|backup" || echo "")
  if [[ -n "$dup_timer" ]]; then
    register_check "Systemd timer" PASS "configured"
  fi
fi

section "Retention Policy"

# Check for remove-older-than in scripts
if [[ -n "$backup_script" ]]; then
  if grep -qE "remove-older-than|remove-all-but-n-full" "$backup_script" 2>/dev/null; then
    retention=$(grep -oE "(remove-older-than|remove-all-but-n-full)\s+[0-9]+[DWMY]?" "$backup_script" | head -n1 || echo "")
    if [[ -n "$retention" ]]; then
      register_check "Retention policy" PASS "$retention"
    else
      register_check "Retention policy" PASS "configured"
    fi
  else
    register_check "Retention policy" WARN "not found in script"
  fi
fi

section "Cache & Temp Security"

# Check duplicity cache
dup_cache="$HOME/.cache/duplicity"
if [[ -d "$dup_cache" ]]; then
  register_check "Cache directory" PASS "exists"

  cache_perms=$(stat -c "%a" "$dup_cache" 2>/dev/null || echo "unknown")
  if [[ "$cache_perms" == "700" ]]; then
    register_check "Cache perms" PASS "$cache_perms"
  else
    register_check "Cache perms" WARN "$cache_perms (should be 700)"
  fi

  # Check cache size
  cache_size=$(du -sh "$dup_cache" 2>/dev/null | awk '{print $1}' || echo "unknown")
  register_check "Cache size" PASS "$cache_size"
fi

# Check temp directory
temp_dir="${TMPDIR:-/tmp}"
if [[ -n "${TMPDIR:-}" ]]; then
  register_check "Custom TMPDIR" PASS "$TMPDIR"
fi

section "Connection Security"

# Check for SSH configuration
ssh_config="$HOME/.ssh/config"
if [[ -f "$ssh_config" ]] && grep -qE "duplicity|backup" "$ssh_config" 2>/dev/null; then
  register_check "SSH config" PASS "backup host configured"
fi

# Check for RSYNC configuration
if [[ -n "${RSYNC_RSH:-}" ]]; then
  register_check "RSYNC_RSH" PASS "custom SSH configured"
fi

section "Duply Wrapper"

# Check for duply (popular duplicity wrapper)
if command -v duply >/dev/null 2>&1; then
  register_check "Duply installed" PASS "found"

  duply_version=$(duply --version 2>/dev/null | head -n1 || echo "")
  if [[ -n "$duply_version" ]]; then
    register_check "Duply version" PASS "$duply_version"
  fi

  # Check for duply profiles
  duply_profiles="/etc/duply"
  user_profiles="$HOME/.duply"

  profiles_found=0
  for profile_dir in "$duply_profiles" "$user_profiles"; do
    if [[ -d "$profile_dir" ]]; then
      profile_count=$(find "$profile_dir" -maxdepth 1 -type d 2>/dev/null | wc -l || echo "1")
      ((profiles_found += profile_count - 1)) || true
    fi
  done

  if [[ "$profiles_found" -gt 0 ]]; then
    register_check "Duply profiles" PASS "$profiles_found profiles"

    # Check first profile for encryption
    first_profile=$(find "$duply_profiles" "$user_profiles" -maxdepth 1 -type d 2>/dev/null | head -n2 | tail -n1)
    if [[ -n "$first_profile" ]] && [[ -f "$first_profile/conf" ]]; then
      if grep -qE "^GPG_KEY=" "$first_profile/conf" 2>/dev/null; then
        register_check "Profile encryption" PASS "GPG key configured"
      fi
    fi
  fi
fi

section "Deja Dup Integration"

# Check for Deja Dup (GNOME duplicity frontend)
if command -v deja-dup >/dev/null 2>&1; then
  register_check "Deja Dup" PASS "installed"

  # Check gsettings for deja-dup config
  if command -v gsettings >/dev/null 2>&1; then
    dd_backend=$(gsettings get org.gnome.DejaDup backend 2>/dev/null | tr -d "'" || echo "")
    if [[ -n "$dd_backend" ]]; then
      register_check "Deja Dup backend" PASS "$dd_backend"
    fi

    dd_encrypt=$(gsettings get org.gnome.DejaDup include-list 2>/dev/null || echo "")
    if [[ -n "$dd_encrypt" ]]; then
      register_check "Deja Dup config" PASS "configured"
    fi
  fi
fi

section "Log Files"

# Check for duplicity logs
log_locations=(
  "/var/log/duplicity.log"
  "/var/log/backup.log"
  "$HOME/duplicity.log"
)

for log_file in "${log_locations[@]}"; do
  if [[ -f "$log_file" ]]; then
    register_check "Log file" PASS "$log_file"

    log_perms=$(stat -c "%a" "$log_file" 2>/dev/null || echo "unknown")
    if [[ "$log_perms" == "600" ]] || [[ "$log_perms" == "640" ]]; then
      register_check "Log perms" PASS "$log_perms"
    else
      register_check "Log perms" WARN "$log_perms"
    fi

    break
  fi
done

print_summary
exit "$EXIT_CODE"
