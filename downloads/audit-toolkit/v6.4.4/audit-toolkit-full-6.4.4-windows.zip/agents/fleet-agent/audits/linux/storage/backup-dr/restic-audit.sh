#!/usr/bin/env bash
# restic-audit.sh — Restic Backup Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Restic installation and version
# - Repository configuration
# - Encryption (always on)
# - Snapshot recency
# - Forget/retention policy
# - Backend security
#
# @elevation: partial
# @elevation-reason: Restic repo configs and password files may require root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Restic Installation"

# Check if restic is installed
if ! command -v restic >/dev/null 2>&1; then
  register_check "Restic installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Restic installed" PASS "found"

# Get version
restic_version=$(restic version 2>/dev/null | head -n1 || echo "unknown")
register_check "Restic version" PASS "$restic_version"

# Check for minimum secure version
version_num=$(echo "$restic_version" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
if [[ -n "$version_num" ]]; then
  major=$(echo "$version_num" | cut -d. -f1)
  minor=$(echo "$version_num" | cut -d. -f2)
  if [[ "$major" -ge 0 ]] && [[ "$minor" -ge 14 ]]; then
    register_check "Version security" PASS "recent version"
  else
    register_check "Version security" WARN "consider upgrade"
  fi
fi

section "Repository Configuration"

# Check RESTIC_REPOSITORY environment variable
if [[ -n "${RESTIC_REPOSITORY:-}" ]]; then
  register_check "RESTIC_REPOSITORY" PASS "configured"

  # Determine backend type
  repo="$RESTIC_REPOSITORY"
  if echo "$repo" | grep -q "^s3:"; then
    register_check "Backend type" PASS "S3"
  elif echo "$repo" | grep -q "^b2:"; then
    register_check "Backend type" PASS "Backblaze B2"
  elif echo "$repo" | grep -q "^azure:"; then
    register_check "Backend type" PASS "Azure Blob"
  elif echo "$repo" | grep -q "^gs:"; then
    register_check "Backend type" PASS "Google Cloud"
  elif echo "$repo" | grep -q "^sftp:"; then
    register_check "Backend type" PASS "SFTP"
  elif echo "$repo" | grep -q "^rest:"; then
    register_check "Backend type" PASS "REST server"
  elif echo "$repo" | grep -q "^rclone:"; then
    register_check "Backend type" PASS "rclone"
  else
    register_check "Backend type" PASS "local"
  fi
else
  register_check "RESTIC_REPOSITORY" WARN "not set"
fi

# Check for restic config files
restic_conf_locations=(
  "/etc/restic"
  "$HOME/.restic"
  "$HOME/.config/restic"
)

for conf_dir in "${restic_conf_locations[@]}"; do
  if [[ -d "$conf_dir" ]]; then
    register_check "Config dir" PASS "$conf_dir"

    conf_perms=$(stat -c "%a" "$conf_dir" 2>/dev/null || echo "unknown")
    if [[ "$conf_perms" == "700" ]] || [[ "$conf_perms" == "750" ]]; then
      register_check "Config dir perms" PASS "$conf_perms"
    else
      register_check "Config dir perms" WARN "$conf_perms"
    fi
  fi
done

section "Password Security"

# Check password configuration method
if [[ -n "${RESTIC_PASSWORD:-}" ]]; then
  register_check "Password method" WARN "environment variable"
elif [[ -n "${RESTIC_PASSWORD_FILE:-}" ]]; then
  register_check "Password method" PASS "file-based"

  if [[ -f "$RESTIC_PASSWORD_FILE" ]]; then
    pass_perms=$(stat -c "%a" "$RESTIC_PASSWORD_FILE" 2>/dev/null || echo "unknown")
    if [[ "$pass_perms" == "600" ]] || [[ "$pass_perms" == "400" ]]; then
      register_check "Password file perms" PASS "$pass_perms"
    else
      register_check "Password file perms" FAIL "$pass_perms (should be 600)"
    fi
  fi
elif [[ -n "${RESTIC_PASSWORD_COMMAND:-}" ]]; then
  register_check "Password method" PASS "command-based (most secure)"
else
  register_check "Password method" WARN "not configured"
fi

section "Encryption Status"

# Restic always encrypts - verify repository is accessible
if [[ -n "${RESTIC_REPOSITORY:-}" ]] && [[ -n "${RESTIC_PASSWORD:-}${RESTIC_PASSWORD_FILE:-}${RESTIC_PASSWORD_COMMAND:-}" ]]; then
  # Try to get repository stats
  repo_stats=$(restic stats --mode raw-data 2>/dev/null | head -n5 || echo "")

  if [[ -n "$repo_stats" ]]; then
    register_check "Encryption" PASS "verified (AES-256-CTR + Poly1305)"
    register_check "Repository access" PASS "authenticated"
  else
    register_check "Encryption" PASS "enabled (default)"
    register_check "Repository access" WARN "check credentials"
  fi
else
  register_check "Encryption" PASS "always enabled"
fi

section "Snapshot Status"

# Check snapshots if repository is accessible
if [[ -n "${RESTIC_REPOSITORY:-}" ]] && [[ -n "${RESTIC_PASSWORD:-}${RESTIC_PASSWORD_FILE:-}${RESTIC_PASSWORD_COMMAND:-}" ]]; then
  # Get latest snapshot
  latest_snapshot=$(restic snapshots --latest 1 --json 2>/dev/null || echo "")

  if [[ -n "$latest_snapshot" ]] && echo "$latest_snapshot" | grep -q "time"; then
    register_check "Snapshots" PASS "found"

    # Parse snapshot time (requires jq for proper parsing)
    if command -v jq >/dev/null 2>&1; then
      snap_time=$(echo "$latest_snapshot" | jq -r '.[0].time // empty' 2>/dev/null || echo "")
      if [[ -n "$snap_time" ]]; then
        snap_epoch=$(date -d "$snap_time" +%s 2>/dev/null || echo "0")
        now_epoch=$(date +%s)
        hours_ago=$(( (now_epoch - snap_epoch) / 3600 ))

        if [[ "$hours_ago" -lt 24 ]]; then
          register_check "Latest snapshot" PASS "${hours_ago}h ago"
        elif [[ "$hours_ago" -lt 168 ]]; then
          days=$((hours_ago / 24))
          register_check "Latest snapshot" WARN "${days}d ago"
        else
          days=$((hours_ago / 24))
          register_check "Latest snapshot" FAIL "${days}d ago"
        fi

        # Get snapshot hostname
        snap_host=$(echo "$latest_snapshot" | jq -r '.[0].hostname // empty' 2>/dev/null || echo "")
        if [[ -n "$snap_host" ]]; then
          register_check "Snapshot host" PASS "$snap_host"
        fi
      fi
    else
      register_check "Latest snapshot" PASS "exists (install jq for details)"
    fi

    # Count total snapshots
    snap_count=$(restic snapshots --json 2>/dev/null | jq 'length' 2>/dev/null || echo "unknown")
    if [[ "$snap_count" != "unknown" ]]; then
      register_check "Total snapshots" PASS "$snap_count"
    fi
  else
    register_check "Snapshots" WARN "none found or access denied"
  fi
fi

section "Backup Schedule"

# Check systemd timers
if is_systemd; then
  restic_timer=$(systemctl list-timers --all 2>/dev/null | grep -iE "restic" || echo "")
  if [[ -n "$restic_timer" ]]; then
    register_check "Systemd timer" PASS "configured"
  else
    register_check "Systemd timer" WARN "not found"
  fi
fi

# Check cron jobs
cron_jobs=$(crontab -l 2>/dev/null | grep -iE "restic" || echo "")
if [[ -n "$cron_jobs" ]]; then
  register_check "Cron job" PASS "configured"
fi

# Check /etc/cron.d
if [[ -d "/etc/cron.d" ]]; then
  cron_d_jobs=$(grep -rliE "restic" /etc/cron.d/ 2>/dev/null | wc -l || echo "0")
  if [[ "$cron_d_jobs" -gt 0 ]]; then
    register_check "Cron.d jobs" PASS "$cron_d_jobs files"
  fi
fi

# Check for resticprofile
if command -v resticprofile >/dev/null 2>&1; then
  register_check "Resticprofile" PASS "installed"

  if [[ -f "/etc/resticprofile/profiles.yaml" ]] || [[ -f "$HOME/.config/resticprofile/profiles.yaml" ]]; then
    register_check "Resticprofile config" PASS "configured"
  fi
fi

section "Retention Policy (Forget)"

# Check for forget flags in scripts/cron
forget_policy=""
for script in /etc/cron.daily/restic* /usr/local/bin/restic* /opt/restic*; do
  [[ -f "$script" ]] || continue
  if grep -qE "forget|keep-" "$script" 2>/dev/null; then
    forget_policy="found"
    break
  fi
done

if [[ -n "$forget_policy" ]]; then
  register_check "Forget policy" PASS "configured in scripts"
else
  register_check "Forget policy" WARN "not detected"
fi

section "Backend Security"

# Check cloud credentials security
if [[ -n "${AWS_ACCESS_KEY_ID:-}" ]]; then
  register_check "AWS credentials" WARN "in environment"
elif [[ -f "$HOME/.aws/credentials" ]]; then
  aws_perms=$(stat -c "%a" "$HOME/.aws/credentials" 2>/dev/null || echo "unknown")
  if [[ "$aws_perms" == "600" ]]; then
    register_check "AWS credentials" PASS "file permissions OK"
  else
    register_check "AWS credentials" WARN "$aws_perms (should be 600)"
  fi
fi

if [[ -n "${AZURE_ACCOUNT_NAME:-}" ]]; then
  register_check "Azure credentials" WARN "in environment"
fi

if [[ -n "${B2_ACCOUNT_ID:-}" ]]; then
  register_check "B2 credentials" WARN "in environment"
fi

# Check for REST server TLS
if [[ -n "${RESTIC_REPOSITORY:-}" ]]; then
  if echo "$RESTIC_REPOSITORY" | grep -q "^rest:https://"; then
    register_check "REST server TLS" PASS "HTTPS"
  elif echo "$RESTIC_REPOSITORY" | grep -q "^rest:http://"; then
    register_check "REST server TLS" FAIL "HTTP (insecure)"
  fi
fi

section "Repository Integrity"

# Check for check schedule
check_configured=false

# Look in systemd timers
if is_systemd && systemctl list-timers --all 2>/dev/null | grep -qiE "restic.*check"; then
  check_configured=true
fi

# Look in cron
if crontab -l 2>/dev/null | grep -qE "restic.*check"; then
  check_configured=true
fi

if $check_configured; then
  register_check "Integrity checks" PASS "scheduled"
else
  register_check "Integrity checks" WARN "not detected"
fi

section "Cache Configuration"

# Check cache directory
cache_dir="${XDG_CACHE_HOME:-$HOME/.cache}/restic"
if [[ -d "$cache_dir" ]]; then
  register_check "Cache directory" PASS "exists"

  cache_perms=$(stat -c "%a" "$cache_dir" 2>/dev/null || echo "unknown")
  if [[ "$cache_perms" == "700" ]]; then
    register_check "Cache perms" PASS "$cache_perms"
  else
    register_check "Cache perms" WARN "$cache_perms"
  fi

  # Check cache size
  cache_size=$(du -sh "$cache_dir" 2>/dev/null | awk '{print $1}' || echo "unknown")
  register_check "Cache size" PASS "$cache_size"
fi

section "Lock Status"

# Check for stale locks
if [[ -n "${RESTIC_REPOSITORY:-}" ]] && [[ -n "${RESTIC_PASSWORD:-}${RESTIC_PASSWORD_FILE:-}${RESTIC_PASSWORD_COMMAND:-}" ]]; then
  locks=$(restic list locks 2>/dev/null | wc -l || echo "0")
  if [[ "$locks" -eq 0 ]]; then
    register_check "Repository locks" PASS "none"
  else
    register_check "Repository locks" WARN "$locks locks (may need unlock)"
  fi
fi

print_summary
exit "$EXIT_CODE"
