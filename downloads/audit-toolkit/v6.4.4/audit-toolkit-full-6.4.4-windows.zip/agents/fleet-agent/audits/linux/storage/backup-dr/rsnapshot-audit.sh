#!/usr/bin/env bash
# rsnapshot-audit.sh — Rsnapshot Backup Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Rsnapshot installation
# - Configuration security
# - Backup intervals
# - Last backup timestamps
# - Storage security
#
# @elevation: partial
# @elevation-reason: Rsnapshot config in /etc may need root for full access
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Rsnapshot Installation"

# Check if rsnapshot is installed
if ! command -v rsnapshot >/dev/null 2>&1; then
  register_check "Rsnapshot installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Rsnapshot installed" PASS "found"

# Get version
rsnapshot_version=$(rsnapshot -V 2>&1 | head -n1 || echo "unknown")
register_check "Rsnapshot version" PASS "$rsnapshot_version"

# Check for rsync (required)
if command -v rsync >/dev/null 2>&1; then
  rsync_version=$(rsync --version 2>/dev/null | head -n1 || echo "unknown")
  register_check "rsync installed" PASS "$rsync_version"
else
  register_check "rsync installed" FAIL "not found"
fi

section "Configuration File"

# Find rsnapshot config
rsnapshot_conf=""
if [[ -f "/etc/rsnapshot.conf" ]]; then
  rsnapshot_conf="/etc/rsnapshot.conf"
elif [[ -f "/usr/local/etc/rsnapshot.conf" ]]; then
  rsnapshot_conf="/usr/local/etc/rsnapshot.conf"
elif [[ -f "$HOME/.rsnapshot.conf" ]]; then
  rsnapshot_conf="$HOME/.rsnapshot.conf"
fi

if [[ -n "$rsnapshot_conf" ]]; then
  register_check "Config file" PASS "$rsnapshot_conf"

  # Check file permissions
  conf_perms=$(stat -c "%a" "$rsnapshot_conf" 2>/dev/null || echo "unknown")
  if [[ "$conf_perms" == "644" ]] || [[ "$conf_perms" == "640" ]] || [[ "$conf_perms" == "600" ]]; then
    register_check "Config perms" PASS "$conf_perms"
  else
    register_check "Config perms" WARN "$conf_perms"
  fi

  conf_owner=$(stat -c "%U:%G" "$rsnapshot_conf" 2>/dev/null || echo "unknown")
  register_check "Config owner" PASS "$conf_owner"

  # Validate configuration
  if rsnapshot configtest >/dev/null 2>&1; then
    register_check "Config syntax" PASS "valid"
  else
    register_check "Config syntax" FAIL "invalid"
  fi
else
  register_check "Config file" FAIL "not found"
  print_summary
  exit "$EXIT_CODE"
fi

section "Snapshot Root"

# Get snapshot_root
snapshot_root=$(grep -E "^snapshot_root" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$snapshot_root" ]]; then
  register_check "Snapshot root" PASS "$snapshot_root"

  if [[ -d "$snapshot_root" ]]; then
    register_check "Snapshot dir exists" PASS "yes"

    # Check permissions
    root_perms=$(stat -c "%a" "$snapshot_root" 2>/dev/null || echo "unknown")
    if [[ "$root_perms" == "700" ]] || [[ "$root_perms" == "750" ]]; then
      register_check "Snapshot perms" PASS "$root_perms"
    else
      register_check "Snapshot perms" WARN "$root_perms (consider 700)"
    fi

    root_owner=$(stat -c "%U:%G" "$snapshot_root" 2>/dev/null || echo "unknown")
    register_check "Snapshot owner" PASS "$root_owner"

    # Check disk usage
    disk_usage=$(df -h "$snapshot_root" 2>/dev/null | tail -n1 | awk '{print $5}' || echo "unknown")
    register_check "Disk usage" PASS "$disk_usage"
  else
    register_check "Snapshot dir exists" WARN "not found"
  fi
else
  register_check "Snapshot root" WARN "not configured"
fi

section "Backup Intervals (Retain)"

# Get retain intervals
retain_intervals=(
  "hourly"
  "daily"
  "weekly"
  "monthly"
)

intervals_configured=0
for interval in "${retain_intervals[@]}"; do
  retain_count=$(grep -E "^retain\s+$interval" "$rsnapshot_conf" 2>/dev/null | awk '{print $3}' || echo "")
  if [[ -n "$retain_count" ]]; then
    ((intervals_configured++)) || true
    register_check "Retain $interval" PASS "$retain_count"
  fi
done

if [[ "$intervals_configured" -eq 0 ]]; then
  # Check for alpha/beta/gamma/delta (legacy naming)
  for interval in "alpha" "beta" "gamma" "delta"; do
    retain_count=$(grep -E "^retain\s+$interval" "$rsnapshot_conf" 2>/dev/null | awk '{print $3}' || echo "")
    if [[ -n "$retain_count" ]]; then
      ((intervals_configured++)) || true
      register_check "Retain $interval" PASS "$retain_count"
    fi
  done
fi

if [[ "$intervals_configured" -eq 0 ]]; then
  register_check "Retain intervals" WARN "none configured"
fi

section "Backup Sources"

# Get backup points
backup_points=$(grep -Ec "^backup" "$rsnapshot_conf" 2>/dev/null || echo "0")
register_check "Backup points" PASS "$backup_points configured"

# Check for local vs remote backups
local_backups=$(grep -Ec "^backup\s+/" "$rsnapshot_conf" 2>/dev/null || echo "0")
remote_backups=$(grep -Ec "^backup\s+[^/].*:" "$rsnapshot_conf" 2>/dev/null || echo "0")

if [[ "$local_backups" -gt 0 ]]; then
  register_check "Local backups" PASS "$local_backups sources"
fi

if [[ "$remote_backups" -gt 0 ]]; then
  register_check "Remote backups" PASS "$remote_backups sources"
fi

section "Last Backup Status"

# Check for existing snapshots
if [[ -n "$snapshot_root" ]] && [[ -d "$snapshot_root" ]]; then
  # Look for interval directories
  for interval in "hourly" "daily" "weekly" "monthly" "alpha" "beta" "gamma" "delta"; do
    interval_dir="$snapshot_root/${interval}.0"
    if [[ -d "$interval_dir" ]]; then
      # Get modification time
      mod_time=$(stat -c %Y "$interval_dir" 2>/dev/null || echo "0")
      now=$(date +%s)
      hours_ago=$(( (now - mod_time) / 3600 ))

      if [[ "$hours_ago" -lt 24 ]]; then
        register_check "Last $interval" PASS "${hours_ago}h ago"
      elif [[ "$hours_ago" -lt 168 ]]; then
        days=$((hours_ago / 24))
        register_check "Last $interval" WARN "${days}d ago"
      else
        days=$((hours_ago / 24))
        register_check "Last $interval" FAIL "${days}d ago"
      fi
    fi
  done

  # Count total snapshots
  snapshot_count=$(find "$snapshot_root" -maxdepth 1 -type d -name "*.*" 2>/dev/null | wc -l || echo "0")
  register_check "Total snapshots" PASS "$snapshot_count"
fi

section "Schedule Configuration"

# Check cron jobs
cron_entries=0

# Check root crontab
root_cron=$(crontab -l 2>/dev/null | grep -iE "rsnapshot" || echo "")
if [[ -n "$root_cron" ]]; then
  cron_count=$(echo "$root_cron" | wc -l)
  ((cron_entries += cron_count)) || true
fi

# Check /etc/cron.d
if [[ -d "/etc/cron.d" ]]; then
  cron_d=$(grep -rlE "rsnapshot" /etc/cron.d/ 2>/dev/null | wc -l || echo "0")
  ((cron_entries += cron_d)) || true
fi

# Check /etc/cron.hourly, daily, weekly, monthly
for cron_dir in /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly; do
  if [[ -d "$cron_dir" ]]; then
    cron_scripts=$(find "$cron_dir" -maxdepth 1 -type f -iname '*rsnapshot*' | wc -l || echo "0")
    ((cron_entries += cron_scripts)) || true
  fi
done

if [[ "$cron_entries" -gt 0 ]]; then
  register_check "Cron jobs" PASS "$cron_entries entries"
else
  register_check "Cron jobs" WARN "none found"
fi

# Check systemd timers
if is_systemd; then
  rsnapshot_timer=$(systemctl list-timers --all 2>/dev/null | grep -iE "rsnapshot" || echo "")
  if [[ -n "$rsnapshot_timer" ]]; then
    register_check "Systemd timer" PASS "configured"
  fi
fi

section "Security Configuration"

# Check cmd_ssh setting
cmd_ssh=$(grep -E "^cmd_ssh" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$cmd_ssh" ]]; then
  register_check "SSH command" PASS "$cmd_ssh"

  if [[ -x "$cmd_ssh" ]]; then
    register_check "SSH executable" PASS "yes"
  else
    register_check "SSH executable" WARN "not found"
  fi
fi

# Check for ssh_args (custom SSH options)
ssh_args=$(grep -E "^ssh_args" "$rsnapshot_conf" 2>/dev/null || echo "")
if [[ -n "$ssh_args" ]]; then
  register_check "SSH args" PASS "custom options set"
fi

# Check lockfile
lockfile=$(grep -E "^lockfile" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$lockfile" ]]; then
  register_check "Lockfile" PASS "$lockfile"

  lockfile_dir=$(dirname "$lockfile")
  if [[ -d "$lockfile_dir" ]]; then
    lock_dir_perms=$(stat -c "%a" "$lockfile_dir" 2>/dev/null || echo "unknown")
    register_check "Lock dir perms" PASS "$lock_dir_perms"
  fi
fi

section "Rsync Options"

# Check rsync options
rsync_short=$(grep -E "^rsync_short_args" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
rsync_long=$(grep -E "^rsync_long_args" "$rsnapshot_conf" 2>/dev/null | awk '{$1=""; print}' || echo "")

if [[ -n "$rsync_short" ]]; then
  register_check "rsync short args" PASS "$rsync_short"
fi

if [[ -n "$rsync_long" ]]; then
  register_check "rsync long args" PASS "configured"
fi

# Check for --delete flag (important for proper sync)
if echo "$rsync_long" | grep -q "\-\-delete"; then
  register_check "rsync --delete" PASS "enabled"
else
  register_check "rsync --delete" WARN "not set"
fi

section "Log Configuration"

# Check logfile
logfile=$(grep -E "^logfile" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$logfile" ]]; then
  register_check "Logfile" PASS "$logfile"

  if [[ -f "$logfile" ]]; then
    log_perms=$(stat -c "%a" "$logfile" 2>/dev/null || echo "unknown")
    if [[ "$log_perms" == "600" ]] || [[ "$log_perms" == "640" ]]; then
      register_check "Log perms" PASS "$log_perms"
    else
      register_check "Log perms" WARN "$log_perms"
    fi

    # Check log size
    log_size=$(stat -c %s "$logfile" 2>/dev/null || echo "0")
    log_size_mb=$((log_size / 1024 / 1024))
    if [[ "$log_size_mb" -lt 100 ]]; then
      register_check "Log size" PASS "${log_size_mb}MB"
    else
      register_check "Log size" WARN "${log_size_mb}MB (consider rotation)"
    fi
  fi
else
  register_check "Logfile" WARN "not configured"
fi

# Check loglevel
loglevel=$(grep -E "^loglevel" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$loglevel" ]]; then
  register_check "Loglevel" PASS "$loglevel"
fi

section "Exclusions"

# Check exclude patterns
excludes=$(grep -Ec "^exclude" "$rsnapshot_conf" 2>/dev/null || echo "0")
if [[ "$excludes" -gt 0 ]]; then
  register_check "Exclude patterns" PASS "$excludes patterns"
fi

# Check exclude_file
exclude_file=$(grep -E "^exclude_file" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
if [[ -n "$exclude_file" ]] && [[ -f "$exclude_file" ]]; then
  register_check "Exclude file" PASS "$exclude_file"

  exclude_count=$(wc -l < "$exclude_file" 2>/dev/null || echo "0")
  register_check "Exclude entries" PASS "$exclude_count"
fi

section "Pre/Post Scripts"

# Check for pre-exec and post-exec
pre_exec=$(grep -E "^cmd_preexec" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")
post_exec=$(grep -E "^cmd_postexec" "$rsnapshot_conf" 2>/dev/null | awk '{print $2}' || echo "")

if [[ -n "$pre_exec" ]]; then
  register_check "Pre-exec script" PASS "$pre_exec"

  if [[ -x "$pre_exec" ]]; then
    pre_perms=$(stat -c "%a" "$pre_exec" 2>/dev/null || echo "unknown")
    if [[ "$pre_perms" == "700" ]] || [[ "$pre_perms" == "750" ]]; then
      register_check "Pre-exec perms" PASS "$pre_perms"
    else
      register_check "Pre-exec perms" WARN "$pre_perms"
    fi
  fi
fi

if [[ -n "$post_exec" ]]; then
  register_check "Post-exec script" PASS "$post_exec"

  if [[ -x "$post_exec" ]]; then
    post_perms=$(stat -c "%a" "$post_exec" 2>/dev/null || echo "unknown")
    if [[ "$post_perms" == "700" ]] || [[ "$post_perms" == "750" ]]; then
      register_check "Post-exec perms" PASS "$post_perms"
    else
      register_check "Post-exec perms" WARN "$post_perms"
    fi
  fi
fi

print_summary
exit "$EXIT_CODE"
