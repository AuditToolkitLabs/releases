#!/usr/bin/env bash
# veeam-linux-audit.sh — Veeam Agent for Linux Security Audit
#
# Compliance Mapping:
# - NIST SP 800-53: CP-9, CP-10 (Backup & Recovery)
# - ISO 27001: A.12.3 (Information Backup)
# - PCI DSS: 9.5, 12.10.1 (Backup Security)
# - CIS Controls: 11 (Data Recovery)
#
# Checks:
# - Veeam Agent installation
# - Service status
# - Job configuration
# - Encryption status
# - Backup recency
# - Repository security
#
# @elevation: partial
# @elevation-reason: Veeam configs and veeamconfig commands may need root
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/../../../../lib/common.sh"
. "$SCRIPT_DIR/../../../../lib/distro.sh"

setup_colors

section "Veeam Agent Installation"

# Check if Veeam is installed
veeam_cmd=""
if command -v veeamconfig >/dev/null 2>&1; then
  veeam_cmd="veeamconfig"
elif command -v veeam >/dev/null 2>&1; then
  veeam_cmd="veeam"
fi

if [[ -z "$veeam_cmd" ]]; then
  register_check "Veeam Agent installed" SKIP "not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Veeam Agent installed" PASS "found"

# Get version
veeam_version=$($veeam_cmd --help 2>&1 | grep -iE "version|veeam" | head -n1 || echo "unknown")
if [[ -n "$veeam_version" ]]; then
  register_check "Veeam version" PASS "$veeam_version"
fi

# Check edition
if [[ -f "/etc/veeam/veeam.lic" ]]; then
  register_check "License" PASS "licensed"
else
  register_check "License" WARN "free edition or unlicensed"
fi

section "Veeam Service Status"

# Check veeamservice
if is_systemd; then
  if systemctl is-active veeamservice >/dev/null 2>&1; then
    register_check "Veeam service" PASS "running"
  else
    register_check "Veeam service" FAIL "not running"
  fi

  if systemctl is-enabled veeamservice >/dev/null 2>&1; then
    register_check "Service enabled" PASS "yes"
  else
    register_check "Service enabled" WARN "no"
  fi
else
  if pgrep -f veeam >/dev/null 2>&1; then
    register_check "Veeam service" PASS "running"
  else
    register_check "Veeam service" WARN "check status"
  fi
fi

# Check for veeamtransport
if pgrep -f veeamtransport >/dev/null 2>&1; then
  register_check "Transport service" PASS "running"
fi

section "Job Configuration"

# List backup jobs
jobs=$($veeam_cmd job list 2>/dev/null || echo "")
if [[ -n "$jobs" ]]; then
  job_count=$(echo "$jobs" | grep -c "Job" || echo "0")
  register_check "Backup jobs" PASS "$job_count jobs"

  # Check each job
  while IFS= read -r job_line; do
    [[ -z "$job_line" ]] && continue
    job_name=$(echo "$job_line" | awk '{print $1}' || echo "")
    [[ -z "$job_name" ]] && continue

    # Get job info
    job_info=$($veeam_cmd job info --name "$job_name" 2>/dev/null || echo "")

    if [[ -n "$job_info" ]]; then
      # Check job status
      job_status=$(echo "$job_info" | grep -iE "status|state" | head -n1 || echo "")
      if echo "$job_status" | grep -qiE "success|idle|running"; then
        register_check "Job $job_name" PASS "OK"
      elif echo "$job_status" | grep -qiE "fail|error"; then
        register_check "Job $job_name" FAIL "failed"
      else
        register_check "Job $job_name" WARN "check status"
      fi

      # Check encryption
      if echo "$job_info" | grep -qiE "encryption.*enabled\|encrypt.*true"; then
        register_check "Job $job_name encryption" PASS "enabled"
      fi
    fi
  done <<< "$jobs"
else
  register_check "Backup jobs" WARN "none configured"
fi

section "Repository Configuration"

# List repositories
repos=$($veeam_cmd repository list 2>/dev/null || echo "")
if [[ -n "$repos" ]]; then
  repo_count=$(echo "$repos" | grep -c "Repository\|Name" || echo "0")
  register_check "Repositories" PASS "$repo_count configured"

  # Check repository types
  if echo "$repos" | grep -qiE "veeam backup"; then
    register_check "Veeam B&R repo" PASS "connected"
  fi

  if echo "$repos" | grep -qiE "local\|folder"; then
    register_check "Local repo" PASS "configured"
  fi

  if echo "$repos" | grep -qiE "nfs\|cifs\|smb"; then
    register_check "Network repo" PASS "configured"
  fi
else
  register_check "Repositories" WARN "none configured"
fi

section "Backup Status"

# Check session/backup history
sessions=$($veeam_cmd session list 2>/dev/null | tail -n5 || echo "")
if [[ -n "$sessions" ]]; then
  register_check "Backup sessions" PASS "found"

  # Get last session
  last_session=$(echo "$sessions" | tail -n1)
  if [[ -n "$last_session" ]]; then
    # Check if recent
    if echo "$last_session" | grep -qiE "success"; then
      register_check "Last backup" PASS "successful"
    elif echo "$last_session" | grep -qiE "fail|error"; then
      register_check "Last backup" FAIL "failed"
    else
      register_check "Last backup" WARN "$last_session"
    fi
  fi
else
  register_check "Backup sessions" WARN "no history"
fi

section "Encryption Configuration"

# Check global encryption settings
veeam_conf="/etc/veeam"
if [[ -d "$veeam_conf" ]]; then
  register_check "Config directory" PASS "exists"

  # Check directory permissions
  conf_perms=$(stat -c "%a" "$veeam_conf" 2>/dev/null || echo "unknown")
  if [[ "$conf_perms" == "700" ]] || [[ "$conf_perms" == "750" ]] || [[ "$conf_perms" == "755" ]]; then
    register_check "Config dir perms" PASS "$conf_perms"
  else
    register_check "Config dir perms" WARN "$conf_perms"
  fi
fi

# Check for encryption in jobs
job_list=$($veeam_cmd job list 2>/dev/null || echo "")
encrypted_jobs=0
total_jobs=0

while IFS= read -r line; do
  [[ -z "$line" ]] && continue
  ((total_jobs++)) || true
  job_name=$(echo "$line" | awk '{print $1}')

  job_detail=$($veeam_cmd job info --name "$job_name" 2>/dev/null || echo "")
  if echo "$job_detail" | grep -qiE "encryption.*enabled"; then
    ((encrypted_jobs++)) || true
  fi
done <<< "$job_list"

if [[ "$total_jobs" -gt 0 ]]; then
  if [[ "$encrypted_jobs" -eq "$total_jobs" ]]; then
    register_check "Job encryption" PASS "all jobs encrypted"
  elif [[ "$encrypted_jobs" -gt 0 ]]; then
    register_check "Job encryption" WARN "$encrypted_jobs/$total_jobs encrypted"
  else
    register_check "Job encryption" WARN "no jobs encrypted"
  fi
fi

section "Schedule Configuration"

# Check for scheduled jobs
scheduled=0
while IFS= read -r line; do
  [[ -z "$line" ]] && continue
  job_name=$(echo "$line" | awk '{print $1}')
  [[ -z "$job_name" ]] && continue

  schedule=$($veeam_cmd schedule show --jobName "$job_name" 2>/dev/null || echo "")
  if [[ -n "$schedule" ]] && echo "$schedule" | grep -qiE "daily\|weekly\|monthly\|enabled"; then
    ((scheduled++)) || true
  fi
done <<< "$job_list"

if [[ "$scheduled" -gt 0 ]]; then
  register_check "Scheduled jobs" PASS "$scheduled jobs"
else
  register_check "Scheduled jobs" WARN "none scheduled"
fi

section "Security Configuration"

# Check for service account
veeam_pid=$(pgrep -f veeam 2>/dev/null | head -n1 || true)
veeam_user=""
if [[ -n "$veeam_pid" ]]; then
  veeam_user=$(ps -o user= -p "$veeam_pid" 2>/dev/null | head -n1 | xargs || true)
fi
if [[ -n "$veeam_user" ]]; then
  if [[ "$veeam_user" == "root" ]]; then
    register_check "Service user" WARN "running as root"
  else
    register_check "Service user" PASS "$veeam_user"
  fi
fi

# Check log permissions
veeam_log="/var/log/veeam"
if [[ -d "$veeam_log" ]]; then
  log_perms=$(stat -c "%a" "$veeam_log" 2>/dev/null || echo "unknown")
  if [[ "$log_perms" == "750" ]] || [[ "$log_perms" == "700" ]]; then
    register_check "Log dir perms" PASS "$log_perms"
  else
    register_check "Log dir perms" WARN "$log_perms"
  fi
fi

section "Restore Points"

# Check available restore points
restore_points=$($veeam_cmd point list 2>/dev/null || echo "")
if [[ -n "$restore_points" ]]; then
  point_count=$(echo "$restore_points" | grep -c "Point\|restore" || echo "0")
  register_check "Restore points" PASS "$point_count available"
else
  register_check "Restore points" WARN "none or access denied"
fi

print_summary
exit "$EXIT_CODE"
