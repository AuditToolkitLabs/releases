#!/usr/bin/env bash
# multi-s3-object-storage-audit.sh
# Purpose : Cross-provider, multi-target, multi-OS audit for S3/Object Storage
# Supports: AWS S3, Hetzner (S3-compatible), Google Cloud Storage (via XML API/HMAC),
#           Azure Blob (via native Azure CLI or S3-compatible gateway),
#           OpenStack/Ceph RGW (S3-compatible), plus generic S3 endpoints.
# OS      : Linux and macOS (portable stat/grep usage)
# Usage   : sudo ./multi-s3-object-storage-audit.sh \\
#            [--target PROVIDER,BUCKET,ENDPOINT,PROFILE,REGION]... \\
#            [--targets-file PATH] [--log FILE] [--quiet] [--verbose] [--no-color]
#            [--aws-extra "<args>"]  # extra args appended to aws s3api calls
# Notes   : - PROVIDER one of: aws|hetzner|gcs|azure|ceph|generic (auto-detected if blank)
#           - ENDPOINT can be blank for AWS. For S3-compatible, pass https://host
#           - For GCS XML API use endpoint=https://storage.googleapis.com and HMAC keys
#           - For Azure native (blob.core.windows.net), az CLI is used for extra checks
# Exit    : 0=OK, 1=Warnings, 2=Failures (any target)
#
# @elevation: partial
# @elevation-reason: S3/MinIO credential files and service configs may need root
#
set -euo pipefail
IFS=$'\n\t'

VERSION="1.0.0"

# -------------------- Runtime options --------------------
LOG_FILE="${LOG_FILE:-/var/log/multi-s3-audit.log}"
QUIET=false; VERBOSE=false; NO_COLOR=false
AWS_EXTRA_ARGS="${AWS_EXTRA_ARGS:-}"

# targets array of lines: PROVIDER,BUCKET,ENDPOINT,PROFILE,REGION
declare -a TARGETS=()

# -------------------- Colors & logging -------------------
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
if [ "$NO_COLOR" = "true" ] || [ ! -t 1 ]; then RED=''; YELLOW=''; GREEN=''; BLUE=''; CYAN=''; BOLD=''; NC=''; fi

log(){ printf '[%(%Y-%m-%d %H:%M:%S)T] [%s] %s\n' -1 "$1" "$2" | tee -a "$LOG_FILE" >/dev/null || true; }
info(){ $QUIET || { printf '%b[INFO]%b  %s\n' "$BLUE" "$NC" "$1"; }; log INFO "$1"; }
ok(){   $QUIET || { printf '%b[PASS]%b  %s\n' "$GREEN" "$NC" "$1"; }; log PASS "$1"; }
warn(){ $QUIET || { printf '%b[WARN]%b  %s\n' "$YELLOW" "$NC" "$1"; }; log WARN "$1"; WARN=$((WARN+1)); }
fail(){ printf '%b[FAIL]%b  %s\n' "$RED" "$NC" "$1" 1>&2; log FAIL "$1"; ERR=$((ERR+1)); }
skip(){ $QUIET || { printf '%b[SKIP]%b  %s\n' "$BLUE" "$NC" "$1"; }; log SKIP "$1"; }
section(){ echo; printf '%s\n' "${BOLD}${CYAN}──────────────── ${1} ────────────────${NC}" | tee -a "$LOG_FILE" >/dev/null; }

# -------------------- CLI parsing ------------------------
usage(){ cat <<'EOF'
Usage: multi-s3-object-storage-audit.sh [OPTIONS]
  --target "PROVIDER,BUCKET,ENDPOINT,PROFILE,REGION"  Add a target (can repeat)
  --targets-file FILE                                 Load targets from file (one per line)
  --aws-extra "ARGS"                                   Extra args appended to aws s3api calls
  -l, --log FILE                                       Log file path (default: /var/log/multi-s3-audit.log)
  -q, --quiet                                          Suppress stdout (errors still on stderr)
  -v, --verbose                                        Verbose logs
      --no-color                                       Disable colored output
  -h, --help                                           Show help
      --version                                        Show version

Target notes:
- PROVIDER: aws|hetzner|gcs|azure|ceph|generic (auto-detected if blank)
- BUCKET:   bucket or container name (Azure uses container name)
- ENDPOINT: https://host  (AWS can leave blank; GCS: https://storage.googleapis.com)
- PROFILE/REGION: AWS CLI profile and region hints; for S3-compatible, region can be any token

Examples:
  # Audit two targets (AWS + Hetzner)
  ./multi-s3-object-storage-audit.sh \
    --target "aws,my-logs,,prod,eu-west-1" \
    --target "hetzner,hz-assets,https://fsn1.your-objectstorage.com,hz,fsn1"

  # From a file
  cat targets.txt
  hetzner,hz-assets,https://nbg1.your-objectstorage.com,hz,nbg1
  gcs,my-gcs-bucket,https://storage.googleapis.com,gcs-hmac,auto
  generic,backup-bucket,https://s3.mycompany.example,backup,auto
  ./multi-s3-object-storage-audit.sh --targets-file targets.txt
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --target) TARGETS+=("$2"); shift 2;;
    --targets-file) mapfile -t lines < "$2"; TARGETS+=("${lines[@]}"); shift 2;;
    --aws-extra) AWS_EXTRA_ARGS="$2"; shift 2;;
    -l|--log) LOG_FILE="$2"; shift 2;;
    -q|--quiet) QUIET=true; shift;;
    -v|--verbose) VERBOSE=true; shift;;
    --no-color) NO_COLOR=true; RED=''; YELLOW=''; GREEN=''; BLUE=''; CYAN=''; BOLD=''; NC=''; shift;;
    -h|--help) usage; exit 0;;
    --version) printf '%s\n' "$VERSION"; exit 0;;
    *) printf 'Unknown option: %s\n' "$1" 1>&2; usage; exit 1;;
  esac
done

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
: >"$LOG_FILE" 2>/dev/null || true

if [ "$VERBOSE" = "true" ]; then
  info "Verbose mode enabled"
fi

if [ ${#TARGETS[@]} -eq 0 ]; then
  skip "No targets provided - use --target or --targets-file"
  exit 1
fi

have(){ command -v "$1" >/dev/null 2>&1; }

# -------------------- Provider detection ----------------
# Input: provider,bucket,endpoint,profile,region
# Output variables: P_PROVIDER P_BUCKET P_ENDPOINT P_PROFILE P_REGION
parse_target(){
  local line="$1"
  P_PROVIDER=""; P_BUCKET=""; P_ENDPOINT=""; P_PROFILE=""; P_REGION=""
  IFS=',' read -r P_PROVIDER P_BUCKET P_ENDPOINT P_PROFILE P_REGION <<<"$line"
  P_PROVIDER="${P_PROVIDER,,}"
  P_ENDPOINT="${P_ENDPOINT:-}"
  # Auto-detect provider by endpoint hostname when not specified
  if [ -z "$P_PROVIDER" ] || [ "$P_PROVIDER" = "auto" ]; then
    case "$P_ENDPOINT" in
      *amazonaws.com*) P_PROVIDER="aws";;
      *your-objectstorage.com*) P_PROVIDER="hetzner";;
      *storage.googleapis.com*) P_PROVIDER="gcs";;
      *blob.core.windows.net*) P_PROVIDER="azure";;
      *) P_PROVIDER="generic";;
    esac
  fi
  # Normalize empty items
  P_PROFILE="${P_PROFILE:-}"
  P_REGION="${P_REGION:-}"
}

# -------------------- S3 checks (generic via AWS CLI) ----
# Common function to call aws s3api with endpoint/profile/region extras
aws_call(){
  local subcmd="$1"; shift
  local args=("$subcmd" "$@")
  [ -n "$P_PROFILE" ] && args=(--profile "$P_PROFILE" "${args[@]}")
  [ -n "$P_REGION" ]  && args=(--region "$P_REGION" "${args[@]}")
  if [ -n "$P_ENDPOINT" ]; then
    args=(--endpoint-url "$P_ENDPOINT" "${args[@]}")
  fi
  local extra=()
  if [ -n "$AWS_EXTRA_ARGS" ]; then
    read -r -a extra <<< "$AWS_EXTRA_ARGS"
  fi
  aws "${args[@]}" "${extra[@]}"
}

s3_check_bucket_policy(){
  local out rc=0
  out=$(aws_call s3api get-bucket-policy --bucket "$P_BUCKET" --output json 2>/dev/null) || rc=$?
  if [ "$rc" -eq 0 ] && printf '%s' "$out" | grep -qi '"Principal"\s*:\s*"\*"'; then
    warn "Bucket policy may allow public access (Principal: *)"
  elif [ $rc -eq 0 ]; then
    ok "Bucket policy present (no wildcard Principal)"
  else
    info "No bucket policy or not retrievable"
  fi
}

s3_check_bucket_acl(){
  local out rc=0
  out=$(aws_call s3api get-bucket-acl --bucket "$P_BUCKET" --output json 2>/dev/null) || rc=$?
  if [ $rc -eq 0 ] && printf '%s' "$out" | grep -qiE 'AllUsers|AuthenticatedUsers'; then
    warn "Public ACL grants detected"
  elif [ $rc -eq 0 ]; then
    ok "No public ACL grants"
  else
    info "Bucket ACL not retrievable"
  fi
}

s3_check_cors(){
  local out rc=0
  out=$(aws_call s3api get-bucket-cors --bucket "$P_BUCKET" 2>/dev/null) || rc=$?
  if [ $rc -eq 0 ] && printf '%s' "$out" | grep -qi '"\*"'; then
    warn "CORS allows wildcard origins (*)"
  elif [ $rc -eq 0 ]; then
    ok "CORS configured without wildcard"
  else
    info "No CORS configured or not retrievable"
  fi
}

s3_check_versioning(){
  local out rc=0 status
  out=$(aws_call s3api get-bucket-versioning --bucket "$P_BUCKET" 2>/dev/null) || rc=$?
  if [ $rc -eq 0 ]; then
    status=$(printf '%s' "$out" | grep -o '"Status"\s*:\s*"[^"]*"' | cut -d'"' -f4)
    if [ "$status" = "Enabled" ]; then ok "Versioning: Enabled"; else warn "Versioning: Not enabled"; fi
  else
    warn "Versioning status unknown (cannot query)"
  fi
}

s3_check_encryption(){
  local rc=0
  aws_call s3api get-bucket-encryption --bucket "$P_BUCKET" >/dev/null 2>&1 || rc=$?
  if [ $rc -eq 0 ]; then ok "Default encryption configured"; else info "Default encryption not configured or unsupported"; fi
}

s3_check_ownership(){
  local out rc=0
  out=$(aws_call s3api get-bucket-ownership-controls --bucket "$P_BUCKET" 2>/dev/null) || rc=$?
  if [ $rc -eq 0 ] && printf '%s' "$out" | grep -qi 'BucketOwnerEnforced'; then
    ok "Object Ownership: BucketOwnerEnforced"
  elif [ $rc -eq 0 ]; then
    info "Object Ownership present (not BucketOwnerEnforced)"
  else
    info "Object Ownership not configured or unsupported"
  fi
}

# -------------------- Provider-specific extras -----------
aws_bpa_checks(){
  local rc=0
  # Bucket-level BPA
  aws_call s3api get-public-access-block --bucket "$P_BUCKET" >/dev/null 2>&1 || rc=$?
  if [ $rc -eq 0 ]; then ok "S3 Block Public Access (bucket) present"; else warn "Bucket-level BPA not set"; fi
}

# GCS-specific checks via gsutil if available (uniform bucket-level access, PAP)
gcs_checks_gsutil(){
  if ! have gsutil; then info "gsutil not available; skipping GCS-native checks"; return; fi
  local rc=0 out
  gsutil ls -b "gs://$P_BUCKET" >/dev/null 2>&1 || { warn "gs://$P_BUCKET not accessible via gsutil"; return; }
  out=$(gsutil iam get "gs://$P_BUCKET" 2>/dev/null || true)
  if printf '%s' "$out" | grep -q 'allUsers'; then
    warn "GCS IAM grants to allUsers"
  else
    ok "No allUsers IAM grant"
  fi
  if printf '%s' "$out" | grep -q 'allAuthenticatedUsers'; then
    warn "GCS IAM grants to allAuthenticatedUsers"
  else
    ok "No allAuthenticatedUsers IAM grant"
  fi
  if gsutil uniformbucketlevelaccess get "gs://$P_BUCKET" >/dev/null 2>&1; then
    ok "UBLA enabled"
  else
    warn "UBLA not enabled"
  fi
  if gsutil versioning get "gs://$P_BUCKET" 2>/dev/null | grep -qi enabled; then
    ok "Versioning enabled (GCS)"
  else
    warn "Versioning disabled (GCS)"
  fi
}

# Azure native checks via az CLI when endpoint indicates blob.core.windows.net
azure_checks_az(){
  if ! have az; then info "Azure CLI (az) not available; skipping Azure-native checks"; return; fi
  # Derive account from endpoint: https://<account>.blob.core.windows.net
  local host account
  host=${P_ENDPOINT#*://}; host=${host%%/*}
  account=${host%%.blob.core.windows.net}
  if [ -z "$account" ]; then info "Cannot derive Azure account from endpoint"; return; fi
  # Container public access
  if az storage container show --name "$P_BUCKET" --account-name "$account" --auth-mode login >/dev/null 2>&1; then
    ok "Azure container reachable"
  else
    warn "Azure container not reachable (login/permissions?)"
    return
  fi
  local access
  access=$(az storage container show --name "$P_BUCKET" --account-name "$account" --auth-mode login --query properties.publicAccess -o tsv 2>/dev/null || echo "")
  if [ "$access" = "" ] || [ "$access" = "None" ]; then ok "Container public access: None"; else warn "Container public access: $access"; fi
  # Account-level blob versioning
  local ver
  ver=$(az storage account blob-service-properties show --account-name "$account" --query isVersioningEnabled -o tsv 2>/dev/null || echo "")
  if [ "$ver" = "true" ]; then
    ok "Blob versioning enabled"
  else
    warn "Blob versioning disabled"
  fi
}

# -------------------- Per-target audit -------------------
run_checks_for_target(){
  WARN=0; ERR=0
  section "Target: provider=$P_PROVIDER bucket=$P_BUCKET endpoint=${P_ENDPOINT:-<default>} profile=${P_PROFILE:-} region=${P_REGION:-}"

  case "$P_PROVIDER" in
    aws)
      have aws || { fail "AWS CLI not installed"; return; }
      s3_check_bucket_policy
      s3_check_bucket_acl
      s3_check_cors
      s3_check_versioning
      s3_check_encryption
      s3_check_ownership
      aws_bpa_checks
      ;;
    hetzner|generic|ceph)
      have aws || { fail "AWS CLI not installed (used with --endpoint-url for $P_PROVIDER)"; return; }
      s3_check_bucket_policy
      s3_check_bucket_acl
      s3_check_cors
      s3_check_versioning
      s3_check_encryption
      s3_check_ownership
      info "Note: Account/Bucket-level Block Public Access not applicable to $P_PROVIDER"
      ;;
    gcs)
      if have aws; then
        info "Attempting generic S3 checks against GCS XML API via aws CLI"
        s3_check_bucket_policy
        s3_check_bucket_acl
        s3_check_cors
        s3_check_versioning
        s3_check_encryption
        s3_check_ownership
      else
        warn "AWS CLI not installed; skipping generic S3 checks for GCS"
      fi
      gcs_checks_gsutil
      ;;
    azure)
      # If endpoint is a gateway (non-blob.core.windows.net), treat as generic S3
      if printf '%s' "$P_ENDPOINT" | grep -q 'blob.core.windows.net'; then
        info "Azure native endpoint detected; running Azure checks"
        azure_checks_az
      else
        info "Azure via S3-compatible gateway detected; running generic S3 checks"
        have aws || { fail "AWS CLI not installed (for gateway)"; return; }
        s3_check_bucket_policy
        s3_check_bucket_acl
        s3_check_cors
        s3_check_versioning
        s3_check_encryption
        s3_check_ownership
      fi
      ;;
    *)
      warn "Unknown provider '$P_PROVIDER' — treating as generic S3"
      have aws || { fail "AWS CLI not installed"; return; }
      s3_check_bucket_policy
      s3_check_bucket_acl
      s3_check_cors
      s3_check_versioning
      s3_check_encryption
      s3_check_ownership
      ;;
  esac

  printf 'Result for %s/%s: Errors=%d Warnings=%d\n' "$P_PROVIDER" "$P_BUCKET" "$ERR" "$WARN" | tee -a "$LOG_FILE" >/dev/null
  if   [ "$ERR" -gt 0 ]; then return 2
  elif [ "$WARN" -gt 0 ]; then return 1
  else return 0; fi
}

# -------------------- Main loop --------------------------
OVERALL=0
printf '\n%s\n' "${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
printf '%s\n'   "${BOLD}║ MULTI S3/OBJECT STORAGE AUDIT — ${VERSION} ║${NC}"
printf '%s\n\n' "${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
log INFO "Starting multi-s3-object-storage-audit v$VERSION"

for line in "${TARGETS[@]}"; do
  parse_target "$line"
  run_checks_for_target || rc=$?
  rc=${rc:-0}
  if [ "$rc" -gt "$OVERALL" ]; then OVERALL=$rc; fi
  unset rc
  echo
done

exit "$OVERALL"
