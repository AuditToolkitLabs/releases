# Network File Sharing Security Audits

This directory contains security audits for network file sharing protocols (NFS and SMB/CIFS).

## Audits

### nfs-smb-security-audit.sh

Comprehensive security audit for NFS (Network File System) and Samba/SMB (Server Message Block) file sharing services.

## NFS (Network File System) Security

### What It Checks

#### 1. NFS Service Status
- NFS server service (nfs-server, nfs-kernel-server)
- RPC bind service (required for NFS)
- Service enablement at boot

#### 2. NFS Configuration
- `/etc/exports` file existence and permissions
- Active export count
- Configuration file ownership

#### 3. NFS Export Security
- **no_root_squash** detection (CRITICAL - allows root access)
- **all_squash** usage (recommended - maps all users to anonymous)
- Wildcard exports (*) - allows any host
- Read-write vs read-only exports
- Sync option (data consistency)
- Subtree check configuration
- Secure ports enforcement

#### 4. NFS Version & Security
- NFSv2 detection (obsolete, should be disabled)
- NFSv3 availability
- NFSv4 support (better security with Kerberos)
- Kerberos configuration (authentication)

#### 5. NFS Network Security
- Port 2049 (NFS) exposure
- Port 111 (RPC) exposure
- Network interface binding
- Firewall restrictions

#### 6. NFS Client Mounts
- Active NFS mounts (as client)
- Insecure mount options (nolock)

### NFS Security Levels

| Configuration | Security Level | Notes |
|--------------|----------------|-------|
| `root_squash,all_squash,ro,sync,secure` | HIGH | Best practice |
| `all_squash,rw,sync,secure` | MEDIUM | Secure write access |
| `rw,sync` | LOW | No user mapping |
| `no_root_squash,rw,*` | CRITICAL | Maximum risk |

### Critical NFS Risks

1. **no_root_squash**: Remote root can access files as local root
2. **Wildcard exports (*)**: Any host can mount the share
3. **NFSv2**: Obsolete protocol with security vulnerabilities
4. **No network restrictions**: Exposed to entire network

## SMB/Samba (CIFS) Security

### What It Checks

#### 1. Samba Service Status
- smbd service (SMB file sharing)
- nmbd service (NetBIOS name resolution)

#### 2. Samba Configuration
- `/etc/samba/smb.conf` file existence and permissions
- Configuration syntax
- Global settings

#### 3. SMB Protocol Security
- **SMBv1 detection** (CRITICAL - vulnerable to WannaCry, EternalBlue)
- Minimum protocol version (should be SMB2 or SMB3)
- Maximum protocol version
- Server signing (authentication integrity)
- SMB encryption (data confidentiality)

#### 4. Authentication Security
- Encrypted passwords (must be enabled)
- Guest access (should be disabled)
- Map to guest settings
- Null passwords (must be disabled)
- Security mode (user-level recommended)

#### 5. Samba Shares
- Share count and configuration
- [homes] share exposure
- Browseable shares
- Writable shares
- Access control (valid users directive)

#### 6. Network Security
- Port 445 (SMB) exposure
- Port 139 (NetBIOS) exposure
- Network interface binding
- Firewall configuration

#### 7. User Management
- Samba user database (pdbedit)
- User count
- Process owner

### SMB Security Levels

| Configuration | Security Level | Notes |
|--------------|----------------|-------|
| `min protocol = SMB3, server signing = mandatory, smb encrypt = required` | HIGH | Best practice |
| `min protocol = SMB2, server signing = auto` | MEDIUM | Good baseline |
| `guest ok = yes, server signing = disabled` | LOW | Not recommended |
| `min protocol = SMB1, null passwords = yes` | CRITICAL | Extremely vulnerable |

### Critical SMB Risks

1. **SMBv1 enabled**: Vulnerable to EternalBlue, WannaCry, NotPetya
2. **Guest access**: Unauthenticated access to shares
3. **Null passwords**: Accounts without passwords
4. **No signing**: Man-in-the-middle attacks
5. **Unencrypted traffic**: Data interception

## Usage

```bash
# Run NFS/SMB security audit
bash audits/linux/storage/shares/nfs-smb-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain storage --match shares
```

## Requirements

### NFS
- nfs-kernel-server (Debian/Ubuntu) or nfs-utils (RHEL/Fedora)
- `/etc/exports` configuration file
- rpcbind service

### Samba
- samba package
- `/etc/samba/smb.conf` configuration file
- pdbedit utility (included with samba)

## Remediation

### NFS Security Hardening

#### Disable NFSv2 (High Priority)

Edit `/etc/nfs.conf` or `/etc/sysconfig/nfs`:

```ini
[nfsd]
vers2=n
vers3=n
vers4=y
vers4.0=y
vers4.1=y
vers4.2=y
```

Or in `/etc/default/nfs-kernel-server`:

```bash
RPCNFSDOPTS="--no-nfs-version 2 --no-nfs-version 3"
```

#### Secure /etc/exports

```bash
# ❌ DANGEROUS - Don't do this
/data *(rw,no_root_squash,no_subtree_check)

# ✅ SECURE - Do this
/data 192.168.1.0/24(ro,root_squash,all_squash,sync,no_subtree_check,secure,anonuid=65534,anongid=65534)

# Best practices:
# - Specify IP ranges, not wildcards (*)
# - Use root_squash (default, but be explicit)
# - Use all_squash to map all users to nobody
# - Use ro for read-only access when possible
# - Use sync to ensure data consistency
# - Use secure to require privileged ports
# - Specify anonuid/anongid to control anonymous user
```

Common export options:

```bash
# Read-only export to specific subnet
/exports/public 10.0.1.0/24(ro,sync,no_subtree_check)

# Read-write export to single host with user squashing
/exports/data 192.168.1.10(rw,sync,all_squash,anonuid=1001,anongid=1001)

# Secure home directories
/home 192.168.1.0/24(rw,sync,root_squash,no_subtree_check)
```

Apply changes:

```bash
# Reload exports
exportfs -ra

# Verify exports
exportfs -v
```

#### Enable NFSv4 with Kerberos

```bash
# Install Kerberos
apt-get install krb5-user nfs-common  # Debian/Ubuntu
yum install krb5-workstation nfs-utils  # RHEL/CentOS

# Configure /etc/idmapd.conf
[General]
Domain = example.com

# Use Kerberos in /etc/exports
/exports/secure gss/krb5(rw,sync,no_subtree_check)
```

#### Firewall Configuration

```bash
# Allow NFS only from trusted network
ufw allow from 192.168.1.0/24 to any port 2049 proto tcp
ufw allow from 192.168.1.0/24 to any port 111 proto tcp

# Or with iptables
iptables -A INPUT -p tcp -s 192.168.1.0/24 --dport 2049 -j ACCEPT
iptables -A INPUT -p tcp -s 192.168.1.0/24 --dport 111 -j ACCEPT
iptables -A INPUT -p tcp --dport 2049 -j DROP
iptables -A INPUT -p tcp --dport 111 -j DROP
```

### Samba/SMB Security Hardening

#### Disable SMBv1 (Critical Priority)

Edit `/etc/samba/smb.conf`:

```ini
[global]
# Disable SMBv1 (vulnerable to EternalBlue/WannaCry)
min protocol = SMB2

# Best practice: Use SMB3 minimum
min protocol = SMB3

# Enable server signing (prevent MITM)
server signing = mandatory

# Enable encryption (SMB3+)
smb encrypt = required
```

#### Secure Authentication

```ini
[global]
# Encrypted passwords (should be default)
encrypt passwords = yes

# Disable guest access globally
map to guest = never
guest account = nobody

# Disable null passwords
null passwords = no

# Use user-level security
security = user

# Restrict NetBIOS (legacy)
disable netbios = yes
smb ports = 445
```

#### Secure Share Configuration

```ini
# ❌ INSECURE SHARE - Don't do this
[public]
path = /srv/public
public = yes
writable = yes
browseable = yes
guest ok = yes

# ✅ SECURE SHARE - Do this
[secure-data]
path = /srv/data
valid users = @datagroup
read only = yes
browseable = no
create mask = 0644
directory mask = 0755
force user = nobody
force group = nogroup

# Secure writable share
[team-share]
path = /srv/team
valid users = user1, user2, @teamgroup
writable = yes
browseable = no
create mask = 0660
directory mask = 0770
inherit permissions = yes

# Disable [homes] if not needed
[homes]
browseable = no
read only = yes
valid users = %S
```

#### Manage Samba Users

```bash
# Add Samba user (must be existing system user)
useradd -M -s /sbin/nologin smbuser
smbpasswd -a smbuser

# List Samba users
pdbedit -L

# Disable Samba user
smbpasswd -d username

# Remove Samba user
smbpasswd -x username

# Never use null passwords
smbpasswd -n username  # ❌ Don't do this
```

#### Firewall Configuration

```bash
# Allow SMB only from trusted network
ufw allow from 192.168.1.0/24 to any port 445 proto tcp

# Block SMB from internet
ufw deny 445/tcp
ufw deny 139/tcp

# Or with iptables
iptables -A INPUT -p tcp -s 192.168.1.0/24 --dport 445 -j ACCEPT
iptables -A INPUT -p tcp --dport 445 -j DROP
iptables -A INPUT -p tcp --dport 139 -j DROP
```

#### SELinux/AppArmor Configuration

For SELinux:

```bash
# Set Samba booleans
setsebool -P samba_enable_home_dirs on
setsebool -P samba_export_all_rw on

# Label Samba share directories
semanage fcontext -a -t samba_share_t "/srv/samba(/.*)?"
restorecon -R /srv/samba
```

For AppArmor:

```bash
# Edit Samba profile
nano /etc/apparmor.d/usr.sbin.smbd

# Reload profile
apparmor_parser -r /etc/apparmor.d/usr.sbin.smbd
```

#### Test Samba Configuration

```bash
# Test configuration syntax
testparm

# Test configuration with verbose output
testparm -v

# Connect to local share
smbclient -L localhost -U username

# Test from Windows
# Open: \\server-ip\share
```

## Security Best Practices

### NFS
1. **Disable NFSv2**: Use NFSv4 only
2. **No wildcards**: Specify exact IP ranges
3. **Use root_squash**: Never use no_root_squash
4. **Prefer read-only**: Use ro unless write access is required
5. **Use Kerberos**: For NFSv4 authentication
6. **Firewall rules**: Restrict NFS ports to trusted networks
7. **Regular audits**: Review /etc/exports regularly
8. **Monitor access**: Use `nfsstat` and `showmount -a`

### Samba/SMB
1. **Disable SMBv1**: Minimum SMB2, prefer SMB3
2. **Enable signing**: Server signing = mandatory
3. **Enable encryption**: SMB encrypt = required (SMB3+)
4. **No guest access**: Disable guest ok globally
5. **Strong passwords**: Use smbpasswd, enforce complexity
6. **Access control**: Use valid users on all shares
7. **Firewall rules**: Restrict SMB ports to trusted networks
8. **Regular updates**: Keep Samba updated for security patches
9. **Disable [homes]**: Unless specifically needed
10. **Monitor access**: Use Samba logs and audit

## Common Vulnerabilities

### NFS
- **no_root_squash**: CVE-2018-1000001 (privilege escalation)
- **NFSv2/v3**: Multiple protocol vulnerabilities
- **Wildcard exports**: Unauthorized access

### SMB
- **SMBv1**: EternalBlue (MS17-010), WannaCry, NotPetya
- **Guest access**: Unauth access to sensitive data
- **Null sessions**: Information disclosure

## Monitoring & Logging

### NFS Monitoring

```bash
# Show NFS statistics
nfsstat

# Show current mounts to server
showmount -a

# Monitor NFS activity
watch -n 1 'nfsstat -s'

# Check logs
tail -f /var/log/syslog | grep nfs
```

### Samba Monitoring

```bash
# Show current connections
smbstatus

# Show locked files
smbstatus --locks

# Monitor Samba logs
tail -f /var/log/samba/log.smbd

# Detailed logging in smb.conf
[global]
log level = 3
log file = /var/log/samba/log.%m
max log size = 5000
```

## References

- [NFS Security Best Practices](https://www.kernel.org/doc/Documentation/filesystems/nfs/nfs.txt)
- [Samba Security Documentation](https://www.samba.org/samba/docs/current/man-html/smb.conf.5.html)
- [NFSv4 Security](https://tools.ietf.org/html/rfc7530)
- [MS17-010 (EternalBlue)](https://docs.microsoft.com/en-us/security-updates/securitybulletins/2017/ms17-010)
- [CIS Samba Benchmark](https://www.cisecurity.org/)
