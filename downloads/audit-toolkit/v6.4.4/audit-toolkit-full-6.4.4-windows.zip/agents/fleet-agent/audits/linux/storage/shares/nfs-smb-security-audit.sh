#!/usr/bin/env bash
#
# NFS/SMB File Sharing Security Audit
#
# Compliance Mapping:
# - CIS Controls: 4.1, 4.2, 9.1, 13.1, 16.11
# - NIST SP 800-53: AC-3, AC-6, SC-7, SC-13, SI-2
# - ISO 27001: A.9.1, A.10.1, A.13.1, A.13.2
# - OWASP ASVS: V10
# - UK NCSC: Secure Configuration, Data at Rest
# - PCI DSS: 1.1, 1.2, 1.3, 10.2
#
# Each check in this script is annotated in comments with relevant compliance mappings.
# NFS/SMB File Sharing Security Audit
# Validates NFS and Samba/CIFS share security configurations
#
# @elevation: partial
# @elevation-reason: NFS exports and Samba configs may need root for full access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
NFS_EXPORTS="/etc/exports"
SAMBA_CONF="/etc/samba/smb.conf"

# === Performance: Cache variables ===
NFS_INSTALLED=""
SAMBA_INSTALLED=""
EXPORTS_CONTENT=""
SMB_CONF_CONTENT=""

# === Helper Functions ===

# Check if NFS is installed
is_nfs_installed() {
  if [[ -n "$NFS_INSTALLED" ]]; then
    [[ "$NFS_INSTALLED" == "true" ]] && return 0 || return 1
  fi

  # Check for NFS server packages
  if pkg_installed nfs-kernel-server || pkg_installed nfs-utils || pkg_installed nfs-server; then
    NFS_INSTALLED="true"
    return 0
  fi

  # Check for NFS processes
  if pgrep -x nfsd >/dev/null 2>&1 || pgrep -x rpc.nfsd >/dev/null 2>&1; then
    NFS_INSTALLED="true"
    return 0
  fi

  # Check for /etc/exports
  if [[ -f "$NFS_EXPORTS" ]]; then
    NFS_INSTALLED="true"
    return 0
  fi

  NFS_INSTALLED="false"
  return 1
}

# Check if Samba is installed
is_samba_installed() {
  if [[ -n "$SAMBA_INSTALLED" ]]; then
    [[ "$SAMBA_INSTALLED" == "true" ]] && return 0 || return 1
  fi

  # Check for Samba packages
  if pkg_installed samba || pkg_installed samba-common; then
    SAMBA_INSTALLED="true"
    return 0
  fi

  # Check for Samba processes
  if pgrep -x smbd >/dev/null 2>&1 || pgrep -x nmbd >/dev/null 2>&1; then
    SAMBA_INSTALLED="true"
    return 0
  fi

  # Check for smb.conf
  if [[ -f "$SAMBA_CONF" ]]; then
    SAMBA_INSTALLED="true"
    return 0
  fi

  SAMBA_INSTALLED="false"
  return 1
}

# Get SMB config value
get_smb_config() {
  local key="$1"
  local section="${2:-global}"

  if [[ -z "$SMB_CONF_CONTENT" && -f "$SAMBA_CONF" ]]; then
    SMB_CONF_CONTENT=$(cat "$SAMBA_CONF" 2>/dev/null || echo "")
  fi

  # Extract value from specific section
  # Handle multi-word values by printing from field 3 onwards
  echo "$SMB_CONF_CONTENT" | awk -v section="$section" -v key="$key" '
    /^\[.*\]$/ { current=$0; gsub(/[\[\]]/, "", current) }
    current == section && $1 == key {
      for(i=3; i<=NF; i++) printf "%s%s", $i, (i<NF?" ":"")
      print ""
      exit
    }
  ' | head -n1
}

# === MAIN AUDIT ===

section "File Sharing Detection"

nfs_detected=false
samba_detected=false

if is_nfs_installed; then
  register_check "NFS Server" PASS "NFS detected"
  nfs_detected=true
else
  register_check "NFS Server" SKIP "Not applicable (NFS not installed)"
fi

if is_samba_installed; then
  register_check "Samba/SMB" PASS "Samba detected"
  samba_detected=true
else
  register_check "Samba/SMB" SKIP "Not applicable (Samba not installed)"
fi

# Exit if neither is installed
if [[ "$nfs_detected" == "false" && "$samba_detected" == "false" ]]; then
  register_check "File Sharing" SKIP "No file sharing services detected"
  print_summary
  exit "$EXIT_CODE"
fi

# === NFS SECURITY AUDIT ===
if [[ "$nfs_detected" == "true" ]]; then

  section "NFS Service Status"

  # Check NFS service
  if svc_is_active nfs-server || svc_is_active nfs-kernel-server || svc_is_active nfsd; then
    register_check "NFS Service" PASS "NFS server running"
  else
    register_check "NFS Service" WARN "NFS server not running"
  fi

  # Check rpcbind (required for NFS)
  if svc_is_active rpcbind || svc_is_active rpcbind.service; then
    register_check "RPC Bind" PASS "rpcbind running"
  else
    register_check "RPC Bind" WARN "rpcbind not running (required for NFS)"
  fi

  section "NFS Configuration"

  # Check /etc/exports exists
  if [[ ! -f "$NFS_EXPORTS" ]]; then
    register_check "/etc/exports" WARN "File not found"
  else
    register_check "/etc/exports" PASS "Configuration file exists"

    # Cache exports content
    EXPORTS_CONTENT=$(grep -v "^#" "$NFS_EXPORTS" | grep -v "^$" || echo "")

    # Check file permissions
    exports_perms=$(stat -c '%a' "$NFS_EXPORTS" 2>/dev/null || stat -f '%Lp' "$NFS_EXPORTS" 2>/dev/null || echo "000")
    if [[ "$exports_perms" == "644" || "$exports_perms" == "640" || "$exports_perms" == "600" ]]; then
      register_check "Exports Permissions" PASS "permissions $exports_perms"
    else
      register_check "Exports Permissions" WARN "permissions $exports_perms (should be 644 or more restrictive)"
    fi

    # Count active exports
    export_count=$(echo "$EXPORTS_CONTENT" | grep -c "^/" || echo "0")
    if [[ "$export_count" -gt 0 ]]; then
      register_check "Active Exports" PASS "$export_count export(s) configured"
    else
      register_check "Active Exports" WARN "No active exports found"
    fi
  fi

  section "NFS Export Security"

  if [[ -n "$EXPORTS_CONTENT" ]]; then
    # Check for no_root_squash (dangerous)
    if echo "$EXPORTS_CONTENT" | grep -q "no_root_squash"; then
      dangerous_exports=$(echo "$EXPORTS_CONTENT" | grep -c "no_root_squash" || echo "0")
      register_check "no_root_squash" FAIL "$dangerous_exports export(s) with no_root_squash (root can access as root)"
    else
      register_check "no_root_squash" PASS "no_root_squash not used (secure)"
    fi

    # Check for all_squash (recommended)
    if echo "$EXPORTS_CONTENT" | grep -q "all_squash"; then
      secure_exports=$(echo "$EXPORTS_CONTENT" | grep -c "all_squash" || echo "0")
      register_check "all_squash" PASS "$secure_exports export(s) using all_squash (recommended)"
    else
      register_check "all_squash" WARN "Consider using all_squash for better security"
    fi

    # Check for wildcard exports (*)
    if echo "$EXPORTS_CONTENT" | grep -qE '\*\(|^[^#]*\s+\*'; then
      wildcard_count=$(echo "$EXPORTS_CONTENT" | grep -cE '\*\(' || echo "0")
      register_check "Wildcard Exports" FAIL "$wildcard_count export(s) allow access from any host (*)"
    else
      register_check "Wildcard Exports" PASS "No wildcard exports (secure)"
    fi

    # Check for read-write exports
    rw_count=$(echo "$EXPORTS_CONTENT" | grep -c "(rw" || echo "0")
    ro_count=$(echo "$EXPORTS_CONTENT" | grep -c "(ro" || echo "0")

    if [[ "$rw_count" -gt 0 ]]; then
      register_check "Read-Write Exports" WARN "$rw_count export(s) are read-write (ensure necessary)"
    fi

    if [[ "$ro_count" -gt 0 ]]; then
      register_check "Read-Only Exports" PASS "$ro_count export(s) are read-only"
    fi

    # Check for sync option (recommended)
    # Use word boundary to avoid matching 'async' when looking for 'sync'
    if echo "$EXPORTS_CONTENT" | grep -qw "sync"; then
      sync_count=$(echo "$EXPORTS_CONTENT" | grep -cw "sync" || echo "0")
      register_check "Sync Option" PASS "$sync_count export(s) using sync (data consistency)"
    else
      register_check "Sync Option" WARN "Consider using 'sync' option for data integrity"
    fi

    # Check for subtree_check
    if echo "$EXPORTS_CONTENT" | grep -q "no_subtree_check"; then
      register_check "Subtree Check" PASS "no_subtree_check used (recommended for performance)"
    fi

    # Check for secure option
    if echo "$EXPORTS_CONTENT" | grep -q "secure"; then
      register_check "Secure Ports" PASS "secure option enforces privileged ports"
    else
      register_check "Secure Ports" WARN "Consider using 'secure' option (require privileged ports)"
    fi
  fi

  section "NFS Version & Security"

  # Check NFS version support
  if command -v rpcinfo >/dev/null 2>&1; then
    nfs_versions=$(rpcinfo -p 2>/dev/null | grep nfs | awk '{print $2}' | sort -u || echo "")

    if echo "$nfs_versions" | grep -q "^4$"; then
      register_check "NFSv4 Support" PASS "NFSv4 available (better security)"
    else
      register_check "NFSv4 Support" WARN "NFSv4 not detected (consider enabling)"
    fi

    if echo "$nfs_versions" | grep -q "^2$"; then
      register_check "NFSv2 Enabled" FAIL "NFSv2 enabled (obsolete, disable it)"
    else
      register_check "NFSv2 Disabled" PASS "NFSv2 not enabled (secure)"
    fi

    if echo "$nfs_versions" | grep -q "^3$"; then
      register_check "NFSv3 Enabled" WARN "NFSv3 enabled (consider NFSv4 only)"
    fi
  fi

  # Check for Kerberos support (NFSv4)
  if [[ -f "/etc/krb5.conf" ]]; then
    register_check "Kerberos Config" PASS "krb5.conf found (NFSv4 security)"
  else
    register_check "Kerberos Config" WARN "No krb5.conf (consider Kerberos for NFSv4)"
  fi

  section "NFS Firewall & Ports"

  # Check if NFS ports are open
  if command -v ss >/dev/null 2>&1; then
    # NFS ports: 2049 (nfsd), 111 (rpcbind)
    nfs_port=$(ss -ln 2>/dev/null | grep -c ":2049" || echo "0")
    rpc_port=$(ss -ln 2>/dev/null | grep -c ":111" || echo "0")

    if [[ "$nfs_port" -gt 0 ]]; then
      register_check "NFS Port 2049" PASS "NFS port listening"

      # Check binding address
      nfs_bind=$(ss -ln 2>/dev/null | grep ":2049" | awk '{print $5}' | cut -d: -f1 | head -n1 || echo "")
      if [[ "$nfs_bind" == "0.0.0.0" || "$nfs_bind" == "*" ]]; then
        register_check "NFS Binding" WARN "Listening on all interfaces (restrict with firewall)"
      else
        register_check "NFS Binding" PASS "Bound to specific interface"
      fi
    fi

    if [[ "$rpc_port" -gt 0 ]]; then
      register_check "RPC Port 111" PASS "RPC port listening"
    fi
  fi

  section "NFS Mounted Shares"

  # Check for active NFS mounts (as client)
  nfs_mounts=$(mount | grep -c "type nfs" || echo "0")
  if [[ "$nfs_mounts" -gt 0 ]]; then
    register_check "NFS Client Mounts" PASS "$nfs_mounts NFS share(s) mounted"

    # Check for insecure mount options
    if mount | grep "type nfs" | grep -qi "nolock"; then
      register_check "NFS Mount Options" WARN "nolock option used (potential security risk)"
    fi
  else
    register_check "NFS Client Mounts" PASS "No NFS mounts (server only)"
  fi

fi

# === SAMBA/SMB SECURITY AUDIT ===
if [[ "$samba_detected" == "true" ]]; then

  section "Samba Service Status"

  # Check smbd service
  if svc_is_active smbd || svc_is_active smb; then
    register_check "Samba Service (smbd)" PASS "smbd running"
  else
    register_check "Samba Service (smbd)" WARN "smbd not running"
  fi

  # Check nmbd service (NetBIOS)
  if svc_is_active nmbd || svc_is_active nmb; then
    register_check "NetBIOS Service (nmbd)" PASS "nmbd running"
  else
    register_check "NetBIOS Service (nmbd)" PASS "nmbd not running (NetBIOS optional)"
  fi

  section "Samba Configuration"

  # Check smb.conf exists
  if [[ ! -f "$SAMBA_CONF" ]]; then
    register_check "smb.conf" FAIL "Configuration file not found"
  else
    register_check "smb.conf" PASS "Configuration file exists"

    # Cache SMB config
    SMB_CONF_CONTENT=$(cat "$SAMBA_CONF" 2>/dev/null || echo "")

    # Check file permissions
    smb_perms=$(stat -c '%a' "$SAMBA_CONF" 2>/dev/null || stat -f '%Lp' "$SAMBA_CONF" 2>/dev/null || echo "000")
    if [[ "$smb_perms" == "644" || "$smb_perms" == "640" || "$smb_perms" == "600" ]]; then
      register_check "smb.conf Permissions" PASS "permissions $smb_perms"
    else
      register_check "smb.conf Permissions" WARN "permissions $smb_perms (should be 644 or more restrictive)"
    fi
  fi

  section "SMB Protocol Security"

  if [[ -n "$SMB_CONF_CONTENT" ]]; then
    # Check for SMBv1 (vulnerable - should be disabled)
    min_protocol=$(get_smb_config "min protocol" "global")
    if [[ -n "$min_protocol" ]]; then
      if echo "$min_protocol" | grep -qiE "smb1|nt1"; then
        register_check "Minimum Protocol" FAIL "SMBv1 allowed (vulnerable, disable it)"
      elif echo "$min_protocol" | grep -qiE "smb2|smb3"; then
        register_check "Minimum Protocol" PASS "Minimum protocol: $min_protocol (secure)"
      else
        register_check "Minimum Protocol" WARN "Minimum protocol: $min_protocol"
      fi
    else
      register_check "Minimum Protocol" WARN "min protocol not set (explicitly set to SMB2 or SMB3)"
    fi

    # Check for max protocol
    max_protocol=$(get_smb_config "max protocol" "global")
    if [[ -n "$max_protocol" ]]; then
      register_check "Maximum Protocol" PASS "Max protocol: $max_protocol"
    fi

    # Check for server signing (important for security)
    server_signing=$(get_smb_config "server signing" "global")
    if [[ "$server_signing" == "mandatory" ]]; then
      register_check "Server Signing" PASS "mandatory (best security)"
    elif [[ "$server_signing" == "auto" || "$server_signing" == "enabled" ]]; then
      register_check "Server Signing" WARN "signing not mandatory (consider 'mandatory')"
    else
      register_check "Server Signing" FAIL "signing not enabled (security risk)"
    fi

    # Check for SMB encryption
    if echo "$SMB_CONF_CONTENT" | grep -q "smb encrypt"; then
      smb_encrypt=$(get_smb_config "smb encrypt" "global")
      if [[ "$smb_encrypt" == "required" || "$smb_encrypt" == "mandatory" ]]; then
        register_check "SMB Encryption" PASS "encryption required (secure)"
      elif [[ "$smb_encrypt" == "desired" || "$smb_encrypt" == "auto" ]]; then
        register_check "SMB Encryption" WARN "encryption optional (consider 'required')"
      fi
    else
      register_check "SMB Encryption" WARN "SMB encryption not configured"
    fi
  fi

  section "Samba Authentication"

  if [[ -n "$SMB_CONF_CONTENT" ]]; then
    # Check for encrypted passwords (should be yes)
    encrypt_passwords=$(get_smb_config "encrypt passwords" "global")
    if [[ "$encrypt_passwords" == "yes" || -z "$encrypt_passwords" ]]; then
      register_check "Encrypted Passwords" PASS "encrypted passwords enabled (default)"
    else
      register_check "Encrypted Passwords" FAIL "encrypted passwords disabled (major security risk)"
    fi

    # Check for guest access
    if echo "$SMB_CONF_CONTENT" | grep -qi "guest ok.*yes\|public.*yes"; then
      guest_shares=$(echo "$SMB_CONF_CONTENT" | grep -ci "guest ok.*yes\|public.*yes" || echo "0")
      register_check "Guest Access" WARN "$guest_shares share(s) allow guest access"
    else
      register_check "Guest Access" PASS "No guest access (secure)"
    fi

    # Check for map to guest
    map_to_guest=$(get_smb_config "map to guest" "global")
    if [[ "$map_to_guest" == "bad user" ]]; then
      register_check "Map to Guest" WARN "bad user mapped to guest (security concern)"
    elif [[ -z "$map_to_guest" ]]; then
      register_check "Map to Guest" PASS "map to guest not enabled"
    fi

    # Check for null passwords
    if echo "$SMB_CONF_CONTENT" | grep -qi "null passwords.*yes"; then
      register_check "Null Passwords" FAIL "null passwords allowed (critical security risk)"
    else
      register_check "Null Passwords" PASS "null passwords not allowed"
    fi

    # Check security mode
    security=$(get_smb_config "security" "global")
    if [[ -n "$security" ]]; then
      if [[ "$security" == "user" ]]; then
        register_check "Security Mode" PASS "user-level security (recommended)"
      else
        register_check "Security Mode" WARN "security mode: $security"
      fi
    fi
  fi

  section "Samba Shares"

  if [[ -n "$SMB_CONF_CONTENT" ]]; then
    # Count shares (excluding [global], [homes], [printers])
    share_count=$(echo "$SMB_CONF_CONTENT" | grep -c "^\[" || echo "0")
    share_count=$((share_count - 1))  # Subtract [global]

    if [[ "$share_count" -gt 0 ]]; then
      register_check "Configured Shares" PASS "$share_count share(s) configured"
    else
      register_check "Configured Shares" WARN "No shares configured"
    fi

    # Check for [homes] share
    if echo "$SMB_CONF_CONTENT" | grep -q "^\[homes\]"; then
      register_check "Homes Share" WARN "[homes] share enabled (check if needed)"

      # Check if browseable
      if echo "$SMB_CONF_CONTENT" | sed -n '/^\[homes\]/,/^\[/p' | grep -qi "browseable.*no\|browsable.*no"; then
        register_check "Homes Browseable" PASS "[homes] not browseable (secure)"
      else
        register_check "Homes Browseable" WARN "[homes] is browseable (security risk)"
      fi
    else
      register_check "Homes Share" PASS "[homes] share not enabled"
    fi

    # Check for writable shares
    writable_count=$(echo "$SMB_CONF_CONTENT" | grep -ci "writable.*yes\|writeable.*yes\|read only.*no" || echo "0")
    if [[ "$writable_count" -gt 0 ]]; then
      register_check "Writable Shares" WARN "$writable_count share(s) are writable"
    fi

    # Check valid users directive
    if echo "$SMB_CONF_CONTENT" | grep -q "valid users"; then
      register_check "Access Control" PASS "valid users directive used (access control)"
    else
      register_check "Access Control" WARN "No 'valid users' restrictions found"
    fi
  fi

  section "Samba Firewall & Ports"

  # Check if SMB ports are open
  if command -v ss >/dev/null 2>&1; then
    # SMB ports: 445 (SMB), 139 (NetBIOS)
    smb_port=$(ss -ln 2>/dev/null | grep -c ":445" || echo "0")
    netbios_port=$(ss -ln 2>/dev/null | grep -c ":139" || echo "0")

    if [[ "$smb_port" -gt 0 ]]; then
      register_check "SMB Port 445" PASS "SMB port listening"

      # Check binding
      smb_bind=$(ss -ln 2>/dev/null | grep ":445" | awk '{print $5}' | cut -d: -f1 | head -n1 || echo "")
      if [[ "$smb_bind" == "0.0.0.0" || "$smb_bind" == "*" ]]; then
        register_check "SMB Binding" WARN "Listening on all interfaces (restrict with firewall)"
      else
        register_check "SMB Binding" PASS "Bound to specific interface"
      fi
    fi

    if [[ "$netbios_port" -gt 0 ]]; then
      register_check "NetBIOS Port 139" WARN "NetBIOS port listening (consider disabling)"
    else
      register_check "NetBIOS Port 139" PASS "NetBIOS not listening (modern SMB)"
    fi
  fi

  section "Samba Users & Permissions"

  # Check Samba user database
  if command -v pdbedit >/dev/null 2>&1; then
    smb_users=$(pdbedit -L 2>/dev/null | wc -l || echo "0")
    if [[ "$smb_users" -gt 0 ]]; then
      register_check "Samba Users" PASS "$smb_users Samba user(s) configured"
    else
      register_check "Samba Users" WARN "No Samba users configured"
    fi
  fi

  # Check Samba process user
  smb_pid=$(pgrep -x smbd 2>/dev/null | head -n1 || true)
  if [[ -n "$smb_pid" ]]; then
    process_user=$(ps -o user= -p "$smb_pid" 2>/dev/null | head -n1 | xargs || true)

    if [[ "$process_user" == "root" ]]; then
      register_check "Process User" PASS "smbd runs as root (normal for binding privileged ports)"
    else
      register_check "Process User" PASS "smbd runs as $process_user"
    fi
  fi

fi

# === Cross-Service Checks ===
if [[ "$nfs_detected" == "true" && "$samba_detected" == "true" ]]; then
  section "Multi-Protocol Security"

  register_check "Both Services" WARN "Both NFS and SMB running (ensure both are secured)"

  # Check if same directories are exported via both protocols
  if [[ -f "$NFS_EXPORTS" && -f "$SAMBA_CONF" ]]; then
    register_check "Shared Paths" WARN "Review if same paths exported via NFS and SMB"
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
