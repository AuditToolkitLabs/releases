# Virtualization Audits

> **Note:** Hypervisor-specific audits have been moved to `audits/hypervisors/` for better organization.

## Moved Scripts

| Script | New Location |
|--------|--------------|
| KVM/QEMU | [audits/hypervisors/kvm/](../../hypervisors/kvm/) |
| Proxmox VE | [audits/hypervisors/proxmox/](../../hypervisors/proxmox/) |
| VMware ESXi | [audits/hypervisors/esxi/](../../hypervisors/esxi/) |
| XenServer/Xen | [audits/hypervisors/xen/](../../hypervisors/xen/) |

## Rationale

Hypervisor platforms are treated as independent systems with their own:
- Custom CLIs (`virsh`, `esxcli`, `pvesh`, `xe`)
- Platform-specific security controls
- Dedicated compliance benchmarks (CIS, STIG)

See `audits/hypervisors/README.md` for full documentation.
