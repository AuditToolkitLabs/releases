# Web Cache Audits

This directory contains security audits for HTTP caching and acceleration systems.

## Available Audits

### varnish-security-audit.sh

**Varnish Cache Security Audit** - Comprehensive security assessment of Varnish HTTP accelerator.

#### What it checks:

**Service Status**
- Varnish service running and enabled
- Version information (checks for EOL versions)
- Service health

**VCL Configuration**
- VCL file existence and syntax validation
- Backend configuration
- Purge ACL restrictions (critical for security)
- Security rules in vcl_recv
- Cookie/authentication header handling
- X-Forwarded-For configuration

**Admin Interface Security**
- Secret file existence and permissions (600/640)
- Secret file ownership (varnish/root)
- Admin interface binding (should be localhost only)
- varnishadm authentication requirements

**Cache & Storage**
- Storage configuration (malloc/file)
- Cache size settings
- TTL (Time-To-Live) configuration
- Grace mode (resilient backend failures)

**Network Security**
- HTTP listening addresses
- Backend communication ports
- PROXY protocol support

**Process Security**
- Process user (should not be root)
- Thread pool configuration
- Worker limits

**Logging & Monitoring**
- varnishlog availability
- varnishncsa (Apache-format logging)
- Logging service status
- varnishstat monitoring
- Cache hit rate metrics

**Configuration Security**
- VCL file permissions
- Parameters file permissions
- Configuration file ownership

#### Usage:

```bash
# Direct execution
bash audits/linux/web/cache/varnish-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain web
bash orchestrator/orchestrator.sh --match varnish
```

#### Example Output:

```
=== Varnish Installation & Service ===
[PASS] Varnish Installed: varnish package found
[PASS] Varnish Service Running: service is active
[PASS] Varnish Service Enabled: enabled at boot
[PASS] Varnish Version: version 6.5.2

=== VCL Configuration ===
[PASS] VCL Config File: found VCL at /etc/varnish/default.vcl
[PASS] VCL Syntax Valid: VCL syntax check passed
[PASS] Backend Configuration: 2 backend(s) configured
[PASS] Purge ACL: purge ACL defined (access restricted)
[PASS] Purge ACL Security: purge ACL properly restricted
[PASS] Cookie Handling: VCL handles cookies/auth headers

=== Admin Interface Security ===
[PASS] Secret File: secret file found at /etc/varnish/secret
[PASS] Secret File Permissions: permissions 600 (secure)
[PASS] Secret File Owner: owner: varnish
[PASS] Admin Interface Binding: bound to 127.0.0.1:6082 (localhost only)

=== Cache & Storage ===
[PASS] Storage Configuration: VARNISH_STORAGE="malloc,256M"
[PASS] Cache Size: malloc storage: 256M
[PASS] Grace Mode: grace mode configured (resilient to backend failures)

=== Logging & Monitoring ===
[PASS] Varnishstat Available: varnishstat monitoring tool available
[PASS] Cache Hit Rate: 87.3% hit rate (8234 hits, 1201 misses)

Summary: 18 checks passed, 2 warnings, 0 failed
```

#### Remediation Examples:

**Restrict purge access (VCL):**
```vcl
# In /etc/varnish/default.vcl
acl purge {
    "127.0.0.1";
    "localhost";
    "192.168.1.0"/24;  # Your admin network
}

sub vcl_recv {
    if (req.method == "PURGE") {
        if (!client.ip ~ purge) {
            return (synth(405, "Method not allowed"));
        }
        return (purge);
    }
}
```

**Secure admin interface:**
```bash
# Bind to localhost only
# In /etc/default/varnish or systemd override
DAEMON_OPTS="-T 127.0.0.1:6082"

# Secure secret file
sudo chmod 600 /etc/varnish/secret
sudo chown varnish:varnish /etc/varnish/secret
```

**Configure grace mode:**
```vcl
# In /etc/varnish/default.vcl
sub vcl_backend_response {
    set beresp.grace = 1h;  # Serve stale for 1 hour if backend fails
}
```

**Handle sensitive headers:**
```vcl
sub vcl_recv {
    # Don't cache authenticated requests
    if (req.http.Authorization || req.http.Cookie) {
        return (pass);
    }
}

sub vcl_backend_response {
    # Don't cache responses with Set-Cookie
    if (beresp.http.Set-Cookie) {
        return (pass);
    }
}
```

**Enable logging:**
```bash
# Enable varnishncsa for Apache-format logs
sudo systemctl enable varnishncsa
sudo systemctl start varnishncsa

# Or use varnishlog for detailed logging
sudo systemctl enable varnishlog
sudo systemctl start varnishlog
```

**Optimize cache size:**
```bash
# In /etc/default/varnish or systemd override
VARNISH_STORAGE="malloc,1G"  # Allocate 1GB for cache

# Or use file-based storage for persistence
VARNISH_STORAGE="file,/var/lib/varnish/varnish_storage.bin,2G"
```

#### Required Packages:
- `varnish` (main package, version 6.x+ recommended)
- Optional: `varnish-modules` (additional VCL modules)

#### Common Pitfalls:

1. **Purge ACL too permissive** - Attackers can clear your cache
2. **Admin interface on 0.0.0.0** - Remote access to management interface
3. **No grace mode** - Site goes down when backend fails
4. **Caching sensitive data** - User data leakage
5. **No secret file** - Unprotected admin access

#### Documentation:
- [Varnish Official Docs](https://varnish-cache.org/docs/index.html)
- [Varnish Security](https://varnish-cache.org/docs/trunk/users-guide/vcl-example-websec.html)
- [VCL Reference](https://varnish-cache.org/docs/trunk/reference/vcl.html)

#### Performance Tips:
- **Hit rate > 80%** = Good caching strategy
- **Hit rate < 50%** = Review cache rules and TTLs
- Monitor memory usage with `varnishstat`
- Use `varnishtop` to identify uncacheable requests

#### Security Impact:
⭐⭐ **MEDIUM** - Varnish often runs as the public-facing reverse proxy. Misconfigurations can lead to cache poisoning, sensitive data exposure, or DoS attacks. Proper VCL rules and admin interface protection are critical.

---

## Planned Audits

Future additions to this directory:
- **Squid audit** - Forward/reverse proxy cache
- **nginx cache audit** - nginx fastcgi/proxy cache
- **Redis cache audit** - Moved to `audits/linux/data/cache/` ✅ (already exists)
- **Memcached audit** - Moved to `audits/linux/data/cache/` ✅ (already exists)

---

**Last Updated:** February 5, 2026  
**Maintainer:** Security Audit Toolkit Team
