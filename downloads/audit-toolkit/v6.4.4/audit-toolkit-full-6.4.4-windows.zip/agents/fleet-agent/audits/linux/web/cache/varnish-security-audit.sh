#!/usr/bin/env bash
# Varnish Cache Security Audit
# Checks Varnish HTTP accelerator configuration, VCL security, and admin interface protection
#
# @elevation: partial
# @elevation-reason: Varnish VCL and secret files may need root for access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
VARNISH_CONFIG_PATHS=(
  "/etc/varnish/default.vcl"
  "/etc/varnish/varnish.vcl"
  "/usr/local/etc/varnish/default.vcl"
)
VARNISH_SECRET_PATHS=(
  "/etc/varnish/secret"
  "/usr/local/etc/varnish/secret"
)
VARNISH_PARAMS_PATHS=(
  "/etc/default/varnish"
  "/etc/sysconfig/varnish"
  "/etc/varnish/varnish.params"
)

# === Performance: Cache variables ===
VARNISH_VCL_FILE=""
VARNISH_VCL_CONTENT=""
VARNISH_SECRET_FILE=""
VARNISH_PARAMS_FILE=""
VARNISH_PARAMS_CONTENT=""
VARNISH_PROCESS_INFO=""
SERVICE_STATUS=""

# Helper: Find Varnish VCL file
find_varnish_vcl() {
  if [[ -n "$VARNISH_VCL_FILE" ]]; then
    echo "$VARNISH_VCL_FILE"
    return 0
  fi

  for path in "${VARNISH_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      VARNISH_VCL_FILE="$path"
      VARNISH_VCL_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# Helper: Find Varnish secret file
find_varnish_secret() {
  if [[ -n "$VARNISH_SECRET_FILE" ]]; then
    echo "$VARNISH_SECRET_FILE"
    return 0
  fi

  for path in "${VARNISH_SECRET_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      VARNISH_SECRET_FILE="$path"
      echo "$path"
      return 0
    fi
  done
  return 1
}

# Helper: Find Varnish params file
find_varnish_params() {
  if [[ -n "$VARNISH_PARAMS_FILE" ]]; then
    echo "$VARNISH_PARAMS_FILE"
    return 0
  fi

  for path in "${VARNISH_PARAMS_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      VARNISH_PARAMS_FILE="$path"
      VARNISH_PARAMS_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# Get Varnish process info
get_varnish_process() {
  if [[ -n "$VARNISH_PROCESS_INFO" ]]; then
    echo "$VARNISH_PROCESS_INFO"
    return 0
  fi

  if command -v varnishd >/dev/null 2>&1; then
    # shellcheck disable=SC2009  # ps + grep is portable across all Unix
    VARNISH_PROCESS_INFO=$(ps aux | grep '[v]arnishd' || echo "")
    echo "$VARNISH_PROCESS_INFO"
    return 0
  fi
  return 1
}

# Check if varnishadm is available and working
check_varnishadm() {
  if command -v varnishadm >/dev/null 2>&1; then
    # Try to connect (may require secret)
    if varnishadm status >/dev/null 2>&1; then
      return 0
    fi
  fi
  return 1
}

# === MAIN AUDIT ===

section "Varnish Installation & Service"

# Check if Varnish is installed
if ! pkg_installed varnish; then
  register_check "Varnish Installed" SKIP "Not applicable (varnish not installed)"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Varnish Installed" PASS "varnish package found"

# Check service status
if svc_is_active varnish || svc_is_active varnishd; then
  register_check "Varnish Service Running" PASS "service is active"
  SERVICE_STATUS="running"
else
  register_check "Varnish Service Running" FAIL "service not running"
  SERVICE_STATUS="stopped"
fi

# Check if enabled at boot
if svc_is_enabled varnish || svc_is_enabled varnishd; then
  register_check "Varnish Service Enabled" PASS "enabled at boot"
else
  register_check "Varnish Service Enabled" WARN "not enabled at boot"
fi

# Check Varnish version
if command -v varnishd >/dev/null 2>&1; then
  varnish_version=$(varnishd -V 2>&1 | grep -oE 'varnish-[0-9]+\.[0-9]+\.[0-9]+' | head -n1 | sed 's/varnish-//' || echo "unknown")
  if [[ "$varnish_version" != "unknown" ]]; then
    # Check for known vulnerable versions (example: < 6.0 has various CVEs)
    version_major=$(echo "$varnish_version" | cut -d. -f1)
    if [[ "$version_major" -ge 6 ]]; then
      register_check "Varnish Version" PASS "version $varnish_version"
    else
      register_check "Varnish Version" WARN "version $varnish_version (consider upgrading to 6.x+)"
    fi
  else
    register_check "Varnish Version" WARN "unable to detect version"
  fi
fi

# If service not running, skip remaining checks
if [[ "$SERVICE_STATUS" != "running" ]]; then
  print_summary
  exit "$EXIT_CODE"
fi

# === VCL Configuration ===
section "VCL Configuration"

# Find VCL file
vcl_file=$(find_varnish_vcl)
if [[ -n "$vcl_file" ]]; then
  register_check "VCL Config File" PASS "found VCL at $vcl_file"
else
  register_check "VCL Config File" FAIL "no VCL configuration file found"
  print_summary
  exit "$EXIT_CODE"
fi

# Check VCL syntax validity
if command -v varnishd >/dev/null 2>&1; then
  if varnishd -C -f "$vcl_file" >/dev/null 2>&1; then
    register_check "VCL Syntax Valid" PASS "VCL syntax check passed"
  else
    register_check "VCL Syntax Valid" FAIL "VCL syntax errors found"
  fi
fi

# Check for backend configuration
if echo "$VARNISH_VCL_CONTENT" | grep -q "backend.*{"; then
  backend_count=$(echo "$VARNISH_VCL_CONTENT" | grep -c "backend.*{" || echo "0")
  register_check "Backend Configuration" PASS "$backend_count backend(s) configured"
else
  register_check "Backend Configuration" FAIL "no backend configuration found"
fi

# Check for purge ACL restrictions
if echo "$VARNISH_VCL_CONTENT" | grep -q "acl purge"; then
  register_check "Purge ACL" PASS "purge ACL defined (access restricted)"

  # Check if localhost is allowed
  if echo "$VARNISH_VCL_CONTENT" | grep -A10 "acl purge" | grep -q "127.0.0.1\|localhost"; then
    register_check "Purge Localhost" PASS "localhost can purge cache"
  fi

  # Warn if 0.0.0.0 is in purge ACL (too permissive)
  if echo "$VARNISH_VCL_CONTENT" | grep -A10 "acl purge" | grep -q "0.0.0.0"; then
    register_check "Purge ACL Security" WARN "purge ACL allows 0.0.0.0 (too permissive)"
  else
    register_check "Purge ACL Security" PASS "purge ACL properly restricted"
  fi
else
  register_check "Purge ACL" WARN "no purge ACL defined (recommend restricting purge access)"
fi

# Check for banned patterns or security rules
if echo "$VARNISH_VCL_CONTENT" | grep -q "vcl_recv.*ban\|vcl_recv.*return.*pass"; then
  register_check "VCL Security Rules" PASS "custom security rules in vcl_recv"
fi

# Check for sensitive data caching protection
if echo "$VARNISH_VCL_CONTENT" | grep -qi "cookie\|authorization\|set-cookie"; then
  register_check "Cookie Handling" PASS "VCL handles cookies/auth headers"
else
  register_check "Cookie Handling" WARN "no explicit cookie/auth handling (may cache sensitive data)"
fi

# Check for X-Forwarded-For header handling
if echo "$VARNISH_VCL_CONTENT" | grep -q "X-Forwarded-For"; then
  register_check "X-Forwarded-For" PASS "X-Forwarded-For header handling configured"
else
  register_check "X-Forwarded-For" WARN "no X-Forwarded-For handling (backend won't see real client IP)"
fi

# === Admin Interface Security ===
section "Admin Interface Security"

# Find secret file
secret_file=$(find_varnish_secret)
if [[ -n "$secret_file" ]]; then
  register_check "Secret File" PASS "secret file found at $secret_file"

  # Check secret file permissions (should be 600 or 640)
  secret_perms=$(stat -c '%a' "$secret_file" 2>/dev/null || stat -f '%Lp' "$secret_file" 2>/dev/null || echo "000")
  secret_owner=$(stat -c '%U' "$secret_file" 2>/dev/null || stat -f '%Su' "$secret_file" 2>/dev/null || echo "unknown")

  if [[ "$secret_perms" == "600" || "$secret_perms" == "640" ]]; then
    register_check "Secret File Permissions" PASS "permissions $secret_perms (secure)"
  else
    register_check "Secret File Permissions" WARN "permissions $secret_perms (recommend 600 or 640)"
  fi

  # Check secret file owner
  if [[ "$secret_owner" == "varnish" || "$secret_owner" == "root" ]]; then
    register_check "Secret File Owner" PASS "owner: $secret_owner"
  else
    register_check "Secret File Owner" WARN "owner: $secret_owner (recommend varnish or root)"
  fi

  # Check secret file size (should not be empty, but not too long)
  secret_size=$(stat -c%s "$secret_file" 2>/dev/null || stat -f%z "$secret_file" 2>/dev/null || echo "0")
  if [[ "$secret_size" -ge 16 && "$secret_size" -le 256 ]]; then
    register_check "Secret File Size" PASS "secret size: $secret_size bytes"
  elif [[ "$secret_size" -eq 0 ]]; then
    register_check "Secret File Size" FAIL "secret file is empty"
  else
    register_check "Secret File Size" WARN "unusual secret size: $secret_size bytes"
  fi
else
  register_check "Secret File" WARN "no secret file found (admin interface may be unprotected)"
fi

# Check admin interface binding
if [[ -z "$VARNISH_PROCESS_INFO" ]]; then
  VARNISH_PROCESS_INFO=$(get_varnish_process)
fi
if [[ -n "$VARNISH_PROCESS_INFO" ]]; then
  # Look for -T parameter (admin interface)
  admin_listen=$(echo "$VARNISH_PROCESS_INFO" | grep -oE '\-T [^ ]+' | awk '{print $2}' || echo "")

  if [[ -n "$admin_listen" ]]; then
    if [[ "$admin_listen" =~ ^127\.0\.0\.1:|^localhost: ]]; then
      register_check "Admin Interface Binding" PASS "bound to $admin_listen (localhost only)"
    elif [[ "$admin_listen" =~ ^0\.0\.0\.0:|^\[?::\]?: ]]; then
      register_check "Admin Interface Binding" WARN "bound to $admin_listen (publicly accessible - SECURITY RISK)"
    else
      register_check "Admin Interface Binding" PASS "bound to $admin_listen"
    fi
  else
    register_check "Admin Interface" PASS "admin interface not exposed (secure)"
  fi
fi

# Check if varnishadm requires authentication
if check_varnishadm; then
  register_check "Varnishadm Access" WARN "varnishadm accessible without explicit secret"
else
  register_check "Varnishadm Access" PASS "varnishadm requires authentication"
fi

# === Cache Configuration ===
section "Cache & Storage"

# Check cache size configuration
params_file=$(find_varnish_params)
if [[ -n "$params_file" ]]; then
  register_check "Parameters File" PASS "found params at $params_file"

  # Check malloc/file storage
  storage_config=$(echo "$VARNISH_PARAMS_CONTENT" | grep -E 'VARNISH_STORAGE=|storage=' | head -n1)
  if [[ -n "$storage_config" ]]; then
    register_check "Storage Configuration" PASS "$storage_config"

    # Check for appropriate cache size
    if echo "$storage_config" | grep -qE "malloc,[0-9]+[MGmg]"; then
      cache_size=$(echo "$storage_config" | grep -oE '[0-9]+[MGmg]' | head -n1)
      register_check "Cache Size" PASS "malloc storage: $cache_size"
    elif echo "$storage_config" | grep -qE "file"; then
      register_check "Cache Type" PASS "using file-based storage"
    fi
  fi

  # Check for TTL settings
  if echo "$VARNISH_PARAMS_CONTENT" | grep -q "default_ttl\|default_grace"; then
    register_check "TTL Configuration" PASS "TTL/grace settings configured"
  fi
fi

# Check for VCL-level TTL configuration
if echo "$VARNISH_VCL_CONTENT" | grep -q "set beresp.ttl\|set obj.ttl"; then
  register_check "VCL TTL Settings" PASS "TTL configured in VCL"
fi

# Check grace mode (serve stale content if backend fails)
if echo "$VARNISH_VCL_CONTENT" | grep -q "set beresp.grace"; then
  register_check "Grace Mode" PASS "grace mode configured (resilient to backend failures)"
else
  register_check "Grace Mode" WARN "no grace mode configured (recommend setting beresp.grace)"
fi

# === Network Security ===
section "Network Security"

# Check listening addresses
if command -v ss >/dev/null 2>&1; then
  varnish_listen=$(ss -tlnp 2>/dev/null | grep varnish || echo "")
elif command -v netstat >/dev/null 2>&1; then
  varnish_listen=$(netstat -tlnp 2>/dev/null | grep varnish || echo "")
fi

if [[ -n "$varnish_listen" ]]; then
  # Check if listening on all interfaces
  if echo "$varnish_listen" | grep -q "0.0.0.0:80\|:::80"; then
    register_check "HTTP Listening" PASS "listening on standard HTTP port (expected for cache)"
  fi

  # Check if listening on non-standard ports
  if echo "$varnish_listen" | grep -qE ":[0-9]{5,}"; then
    register_check "Backend Port" PASS "backend communication on high port (secure)"
  fi
fi

# Check for PROXY protocol support
if echo "$VARNISH_PARAMS_CONTENT" | grep -q "PROXY"; then
  register_check "PROXY Protocol" PASS "PROXY protocol support detected"
fi

# === Process Security ===
section "Process Security"

# Check Varnish user/group
VARNISH_PROCESS_INFO=$(get_varnish_process)
if [[ -n "$VARNISH_PROCESS_INFO" ]]; then
  varnish_user=$(echo "$VARNISH_PROCESS_INFO" | awk '{print $1}' | head -n1)

  if [[ "$varnish_user" == "varnish" || "$varnish_user" == "vcache" ]]; then
    register_check "Process User" PASS "running as $varnish_user (not root)"
  elif [[ "$varnish_user" == "root" ]]; then
    register_check "Process User" WARN "running as root (security risk, recommend varnish user)"
  else
    register_check "Process User" PASS "running as $varnish_user"
  fi
fi

# Check for worker process limits
if echo "$VARNISH_PARAMS_CONTENT" | grep -q "thread_pool"; then
  register_check "Thread Pool Config" PASS "thread pool limits configured"
fi

# === Logging & Monitoring ===
section "Logging & Monitoring"

# Check varnishlog/varnishncsa
if command -v varnishlog >/dev/null 2>&1; then
  register_check "Varnishlog Available" PASS "varnishlog tool available"
fi

if command -v varnishncsa >/dev/null 2>&1; then
  register_check "Varnishncsa Available" PASS "varnishncsa (Apache-format logging) available"
fi

# Check if logging service is running
if svc_is_active varnishlog || svc_is_active varnishncsa; then
  register_check "Logging Service" PASS "varnish logging service active"
else
  register_check "Logging Service" WARN "no varnish logging service active (recommend enabling)"
fi

# Check varnishstat availability
if command -v varnishstat >/dev/null 2>&1; then
  register_check "Varnishstat Available" PASS "varnishstat monitoring tool available"

  # Try to get basic stats
  if varnishstat -1 -f MAIN.cache_hit -f MAIN.cache_miss >/dev/null 2>&1; then
    cache_hits=$(varnishstat -1 -f MAIN.cache_hit 2>/dev/null | awk '{print $2}' || echo "0")
    cache_misses=$(varnishstat -1 -f MAIN.cache_miss 2>/dev/null | awk '{print $2}' || echo "0")

    if [[ "$cache_hits" -gt 0 || "$cache_misses" -gt 0 ]]; then
      total_requests=$((cache_hits + cache_misses))
      if [[ "$total_requests" -gt 0 ]]; then
        hit_rate=$(awk "BEGIN {printf \"%.1f\", ($cache_hits / $total_requests) * 100}")
        register_check "Cache Hit Rate" PASS "${hit_rate}% hit rate ($cache_hits hits, $cache_misses misses)"
      fi
    fi
  fi
fi

# === Configuration File Security ===
section "Configuration File Security"

# Check VCL file permissions
if [[ -n "$vcl_file" ]]; then
  vcl_perms=$(stat -c '%a' "$vcl_file" 2>/dev/null || stat -f '%Lp' "$vcl_file" 2>/dev/null || echo "000")
  vcl_owner=$(stat -c '%U' "$vcl_file" 2>/dev/null || stat -f '%Su' "$vcl_file" 2>/dev/null || echo "unknown")

  if [[ "$vcl_perms" =~ ^[0-9]{3}$ && "${vcl_perms:2:1}" -le 4 ]]; then
    register_check "VCL File Permissions" PASS "permissions $vcl_perms, owner $vcl_owner"
  else
    register_check "VCL File Permissions" WARN "permissions $vcl_perms (recommend 644 or more restrictive)"
  fi
fi

# Check params file permissions
if [[ -n "$params_file" ]]; then
  params_perms=$(stat -c '%a' "$params_file" 2>/dev/null || stat -f '%Lp' "$params_file" 2>/dev/null || echo "000")
  if [[ "$params_perms" =~ ^[0-9]{3}$ && "${params_perms:2:1}" -eq 0 ]]; then
    register_check "Params File Permissions" PASS "permissions $params_perms (restricted)"
  else
    register_check "Params File Permissions" WARN "permissions $params_perms (recommend 640 or 600)"
  fi
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
