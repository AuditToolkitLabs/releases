#!/usr/bin/env bash
# Portable CDN Headers & Cache Audit (Cloudflare-aware)
#
# @elevation: none
# @elevation-reason: HTTP header checks only, no local file access needed
#
set -euo pipefail
SCRIPT_NAME="${0##*/}"
SCRIPT_VERSION="4.2.1"
ORIGIN_URL="${ORIGIN_URL:-}"
QUIET=false
VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
have() { command -v "$1" >/dev/null 2>&1; }
timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
log() { [[ "$QUIET" == false ]] && echo "[$(timestamp)] $*"; }
safe_curl() {
  have curl || {
    echo ""
    return 1
  }
  curl -sSI --connect-timeout 3 --max-time 10 "$1" 2>/dev/null
  echo ""
}

CHECK_NAMES=()
CHECK_RESULTS=()
CHECK_MESSAGES=()
TOTAL=0
PASS=0
FAIL=0
WARN=0
SKIP=0
reg() {
  local n="$1" r="$2" m="${3:-}"
  CHECK_NAMES+=("$n")
  CHECK_RESULTS+=("$r")
  CHECK_MESSAGES+=("$m")
  ((++TOTAL))
  case "$r" in PASS) ((++PASS)) ;; FAIL)
    ((++FAIL))
    EXIT_CODE=2
    ;;
  WARN)
    ((++WARN))
    [[ $EXIT_CODE -eq 0 ]] && EXIT_CODE=1
    ;;
  SKIP) ((++SKIP)) ;; esac
  log "[$r] $n${m:+: $m}"
}

usage() { echo "Usage: $SCRIPT_NAME --url <URL> [--verbose] [--quiet]"; }

parse() { while [[ $# -gt 0 ]]; do case "$1" in
  -u | --url)
    ORIGIN_URL="$2"
    shift 2
    ;;
  --verbose)
    VERBOSE=true
    shift
    ;;
  --quiet)
    QUIET=true
    shift
    ;;
  --no-color)
    NO_COLOR=true
    shift
    ;;
  --help)
    usage
    exit 0
    ;;
  --version)
    echo "$SCRIPT_NAME $SCRIPT_VERSION"
    exit 0
    ;;
  *) shift ;; esac done }

cloudflare_map() {
  case "$1" in
    LHR) echo "London, UK (LHR)" ;; AMS) echo "Amsterdam, NL (AMS)" ;; FRA) echo "Frankfurt, DE (FRA)" ;;
    CDG) echo "Paris, FR (CDG)" ;; MAD) echo "Madrid, ES (MAD)" ;; DUB) echo "Dublin, IE (DUB)" ;;
    *) echo "$1" ;;
  esac
}

audit() {
  if [[ -z "$ORIGIN_URL" ]]; then
    reg "URL provided" SKIP "No URL supplied"
    return
  fi
  local h
  h="$(safe_curl "$ORIGIN_URL")"
  if [[ -z "$h" ]]; then
    reg "URL reachable" FAIL "No response"
    return
  else reg "URL reachable" PASS "Response received"; fi
  local status
  status="$(echo "$h" | grep -iE '^HTTP/' | head -1)"
  [[ -n "$status" ]] && reg "HTTP status" PASS "$status"
  local cc
  cc="$(echo "$h" | grep -i '^cache-control:' | head -1)"
  if [[ -n "$cc" ]]; then reg "Cache-Control" PASS "$cc"; else reg "Cache-Control" WARN "Missing"; fi
  local cors
  cors="$(echo "$h" | grep -i '^access-control-allow-origin:' | head -1)"
  if [[ -n "$cors" ]]; then
    if echo "$cors" | grep -Fq '*'; then reg "CORS Allow-Origin" WARN "Wildcard (*)"; else reg "CORS Allow-Origin" PASS "$cors"; fi
  else reg "CORS Allow-Origin" PASS "Not present"; fi
  # Cloudflare detection
  if echo "$h" | grep -qiE '^cf-ray:|^cf-cache-status:|^cf-request-id:|^cf-worker:|^server: *cloudflare'; then
    reg "CDN Provider" PASS "Cloudflare detected"
    # POP
    local ray pop
    ray="$(echo "$h" | grep -i '^cf-ray:' | head -1 | awk '{print $2}')"
    pop="${ray##*-}"
    if [[ -n "$pop" ]]; then reg "Cloudflare POP" PASS "$(cloudflare_map "$pop")"; else reg "Cloudflare POP" WARN "Unknown"; fi
    # Cache status
    local cfs
    cfs="$(echo "$h" | grep -i '^cf-cache-status:' | head -1 | cut -d: -f2- | xargs)"
    if [[ -n "$cfs" ]]; then
      case "$cfs" in HIT) reg "Cloudflare Cache" PASS "HIT at edge" ;; REVALIDATED) reg "Cloudflare Cache" PASS "Revalidated" ;; MISS | EXPIRED) reg "Cloudflare Cache" WARN "$cfs (origin fetch)" ;; DYNAMIC | BYPASS) reg "Cloudflare Cache" WARN "$cfs (not cacheable)" ;; *) reg "Cloudflare Cache" WARN "Unknown: $cfs" ;; esac
    else reg "Cloudflare Cache" WARN "CF-Cache-Status missing"; fi
    # HTTP/3
    local altsvc
    altsvc="$(echo "$h" | grep -i '^alt-svc:' | head -1 | tr -d '
  ')"
    if echo "$altsvc" | grep -qi 'h3'; then reg "HTTP/3 availability" PASS "alt-svc advertises h3"; else reg "HTTP/3 availability" WARN "No h3 advertised"; fi
  else
    reg "CDN Provider" WARN "Cloudflare not detected"
  fi
}

summary() {
  echo
  echo "== CDN AUDIT SUMMARY =="
  echo " URL: ${ORIGIN_URL:-n/a}"
  echo " Checks: $TOTAL | Passed: $PASS | Failed: $FAIL | Warnings: $WARN | Skipped: $SKIP"
  if ((FAIL > 0)); then echo " Status: FAILED"; elif ((WARN > 0)); then echo " Status: PASSED WITH WARNINGS"; else echo " Status: PASSED"; fi
}

parse "$@"
[[ "$VERBOSE" == true ]] && log "Verbose mode enabled"
[[ "$NO_COLOR" == true ]] && log "Color output is already plain text"
audit
summary
exit "$EXIT_CODE"
