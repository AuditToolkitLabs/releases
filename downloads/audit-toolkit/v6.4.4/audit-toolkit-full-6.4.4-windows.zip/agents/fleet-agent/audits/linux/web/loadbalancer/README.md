# Load Balancer Security Audits

This directory contains security audits for load balancers and reverse proxies, with primary focus on HAProxy.

## Audits

### haproxy-security-audit.sh

Comprehensive security audit for HAProxy load balancer configurations.

**Coverage:**
- HAProxy service status and version
- Global SSL/TLS security settings
- Frontend TLS configuration (protocols, cipher suites)
- Backend security configuration
- Access Control List (ACL) security
- Rate limiting and DDoS protection (stick-tables)
- HTTP security headers (HSTS, CSP, X-Frame-Options)
- Stats interface security
- Connection limits and timeouts
- Backend health checks
- Certificate validation

**Usage:**
```bash
# Run standalone
bash audits/linux/web/loadbalancer/haproxy-security-audit.sh

# Via orchestrator
bash orchestrator/orchestrator.sh --domain web --match haproxy
```

**Example Output:**
```
=== HAProxy Security Audit ===

--- Service Status ---
[PASS] HAProxy Service: running
[PASS] HAProxy Version: 2.6.6

--- TLS/SSL Configuration ---
[PASS] Min TLS Version: TLSv1.2
[WARN] Cipher Suites: includes weak ciphers (3DES)
[PASS] SSL Protocols: no SSLv3/TLSv1.0
[FAIL] HSTS Header: not configured

--- Access Control ---
[PASS] ACL Rules: 12 ACL rules configured
[PASS] Rate Limiting: stick-table configured for rate limiting
[WARN] Connection Limits: no maxconn set on frontend

--- Backend Security ---
[PASS] Health Checks: enabled on all backends
[WARN] Backend Timeout: 50s (consider reducing)
```

## Common Issues & Remediation

### Weak TLS Configuration
**Issue:** Allows TLSv1.0/TLSv1.1 or weak cipher suites.

**Fix:**
```
# haproxy.cfg - Global section
global
    ssl-default-bind-ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384
    ssl-default-bind-options ssl-min-ver TLSv1.2 no-tls-tickets
    ssl-default-server-ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256
    ssl-default-server-options ssl-min-ver TLSv1.2

# Frontend
frontend https-in
    bind :443 ssl crt /etc/ssl/certs/site.pem alpn h2,http/1.1
    http-response set-header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
```

### Missing Security Headers
**Issue:** No HSTS, CSP, X-Frame-Options headers.

**Fix:**
```
frontend web
    http-response set-header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
    http-response set-header X-Frame-Options "DENY"
    http-response set-header X-Content-Type-Options "nosniff"
    http-response set-header Content-Security-Policy "default-src 'self'"
    http-response set-header X-XSS-Protection "1; mode=block"
    http-response set-header Referrer-Policy "strict-origin-when-cross-origin"
```

### No Rate Limiting
**Issue:** Vulnerable to application-layer DDoS attacks.

**Fix:**
```
# Stick table for rate limiting
backend be_app
    stick-table type ip size 100k expire 30s store http_req_rate(10s)
    http-request track-sc0 src
    http-request deny deny_status 429 if { sc_http_req_rate(0) gt 100 }

# Frontend connection limiting
frontend fe_app
    maxconn 10000
    rate-limit sessions 1000
```

### Insecure Stats Interface
**Issue:** Stats page accessible without authentication or over HTTP.

**Fix:**
```
# Secure stats with authentication and restricted access
listen stats
    bind 127.0.0.1:8404
    stats enable
    stats uri /haproxy?stats
    stats realm HAProxy\ Statistics
    stats auth admin:$(openssl rand -base64 32)
    stats refresh 30s
    # Or use socket-level stats
    # stats socket /run/haproxy/admin.sock mode 660 level admin
```

### No Backend Health Checks
**Issue:** Dead backends receive traffic causing service failures.

**Fix:**
```
backend app_servers
    option httpchk GET /healthz
    http-check expect status 200
    
    server app1 10.0.1.10:8080 check inter 5s fall 3 rise 2
    server app2 10.0.1.11:8080 check inter 5s fall 3 rise 2
    server app3 10.0.1.12:8080 check inter 5s fall 3 rise 2
```

### Timeout Configuration
**Issue:** Excessively long timeouts enable resource exhaustion.

**Fix:**
```
defaults
    timeout connect 5s
    timeout client 30s
    timeout server 30s
    timeout http-request 10s
    timeout http-keep-alive 2s
```

## Best Practices

1. **TLS/SSL Hardening:**
   - Enforce TLSv1.2 minimum (TLSv1.3 preferred)
   - Use strong cipher suites (ECDHE with AES-GCM)
   - Enable OCSP stapling for certificate validation
   - Implement HSTS with long max-age
   - Use HTTP/2 or HTTP/3 where supported

2. **DDoS Protection:**
   - Implement stick-tables for rate limiting by IP
   - Set frontend connection limits (maxconn)
   - Configure rate-limit sessions
   - Use ACLs to block malicious patterns
   - Enable syn-flood protection at OS level

3. **Access Control:**
   - Use ACLs for path-based access control
   - Implement IP whitelisting for admin interfaces
   - Validate HTTP methods (deny dangerous methods)
   - Strip sensitive headers from responses
   - Use http-request deny for blocking

4. **Backend Security:**
   - Always enable health checks on backends
   - Use check-ssl for HTTPS backends
   - Implement circuit breakers (observe/fastinter)
   - Set appropriate backup servers
   - Use server templates for dynamic scaling

5. **Monitoring & Logging:**
   - Enable detailed logging with custom log formats
   - Monitor stick-table entries for attacks
   - Track backend response times
   - Alert on health check failures
   - Use stats socket for runtime queries

## Configuration Example

```
global
    log /dev/log local0
    chroot /var/lib/haproxy
    user haproxy
    group haproxy
    daemon
    
    # TLS hardening
    ssl-default-bind-ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384
    ssl-default-bind-options ssl-min-ver TLSv1.2 no-tls-tickets
    tune.ssl.default-dh-param 2048

defaults
    log global
    option httplog
    option dontlognull
    timeout connect 5s
    timeout client 30s
    timeout server 30s

frontend https-in
    bind :443 ssl crt /etc/ssl/certs/site.pem alpn h2,http/1.1
    maxconn 10000
    
    # Security headers
    http-response set-header Strict-Transport-Security "max-age=31536000; includeSubDomains"
    http-response set-header X-Frame-Options "SAMEORIGIN"
    http-response set-header X-Content-Type-Options "nosniff"
    
    # Rate limiting
    stick-table type ip size 100k expire 30s store http_req_rate(10s)
    http-request track-sc0 src
    http-request deny deny_status 429 if { sc_http_req_rate(0) gt 100 }
    
    # ACLs
    acl is_api path_beg /api/
    use_backend be_api if is_api
    default_backend be_web

backend be_web
    balance roundrobin
    option httpchk GET /health
    server web1 10.0.1.10:80 check
    server web2 10.0.1.11:80 check
```

## References

- [HAProxy Configuration Manual](https://www.haproxy.org/download/2.6/doc/configuration.txt)
- [HAProxy Best Practices (Cloudflare)](https://www.cloudflare.com/learning/performance/what-is-haproxy/)
- [SSL/TLS Configuration Best Practices](https://ssl-config.mozilla.org/)
- [HAProxy Rate Limiting](https://www.haproxy.com/blog/four-examples-of-haproxy-rate-limiting/)
- [OWASP Load Balancer Security](https://cheatsheetseries.owasp.org/cheatsheets/Infrastructure_Security_Cheat_Sheet.html)
