#!/usr/bin/env bash
# HAProxy Security Audit
# Checks HAProxy load balancer configuration including TLS, ACLs, rate limiting, and backend security
#
# @elevation: partial
# @elevation-reason: HAProxy config files may need root for access
#
set -euo pipefail

# Source required libraries
. "$(dirname "$0")/../../../../lib/common.sh"
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"
. "$(dirname "$0")/../../../../lib/pkg.sh"

# === Configuration ===
HAPROXY_CONFIG_PATHS=(
  "/etc/haproxy/haproxy.cfg"
  "/usr/local/etc/haproxy/haproxy.cfg"
)

# === Performance: Cache variables ===
HAPROXY_CONFIG_FILE=""
HAPROXY_CONFIG_CONTENT=""
SERVICE_STATUS=""

# Find HAProxy config file
find_haproxy_config() {
  if [[ -n "$HAPROXY_CONFIG_FILE" ]]; then
    echo "$HAPROXY_CONFIG_FILE"
    return 0
  fi

  for path in "${HAPROXY_CONFIG_PATHS[@]}"; do
    if [[ -f "$path" ]]; then
      HAPROXY_CONFIG_FILE="$path"
      HAPROXY_CONFIG_CONTENT=$(cat "$path" 2>/dev/null || echo "")
      echo "$path"
      return 0
    fi
  done
  return 1
}

# Get config section
get_config_section() {
  local section="$1"
  echo "$HAPROXY_CONFIG_CONTENT" | sed -n "/${section}/,/^[a-z]/p" | head -n -1
}

# === MAIN AUDIT ===

section "HAProxy Installation & Service"

# Check if HAProxy is installed
if ! pkg_installed haproxy; then
  register_check "HAProxy Installed" SKIP "Not applicable (haproxy not installed)"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "HAProxy Installed" PASS "haproxy package found"

# Check service status
if svc_is_active haproxy; then
  register_check "HAProxy Service Running" PASS "service is active"
  SERVICE_STATUS="running"
else
  register_check "HAProxy Service Running" FAIL "service not running"
  SERVICE_STATUS="stopped"
fi

# Check if enabled at boot
if svc_is_enabled haproxy; then
  register_check "HAProxy Service Enabled" PASS "enabled at boot"
else
  register_check "HAProxy Service Enabled" WARN "not enabled at boot"
fi

# Check HAProxy version
if command -v haproxy >/dev/null 2>&1; then
  haproxy_version=$(haproxy -v 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || echo "unknown")
  if [[ "$haproxy_version" != "unknown" ]]; then
    version_major=$(echo "$haproxy_version" | cut -d. -f1)
    version_minor=$(echo "$haproxy_version" | cut -d. -f2)

    # HAProxy 2.4+ recommended for security features
    if [[ "$version_major" -ge 2 && "$version_minor" -ge 4 ]]; then
      register_check "HAProxy Version" PASS "version $haproxy_version"
    elif [[ "$version_major" -ge 2 ]]; then
      register_check "HAProxy Version" PASS "version $haproxy_version (consider 2.4+)"
    else
      register_check "HAProxy Version" WARN "version $haproxy_version (upgrade to 2.x recommended)"
    fi
  else
    register_check "HAProxy Version" WARN "unable to detect version"
  fi
fi

# If service not running, skip remaining checks
if [[ "$SERVICE_STATUS" != "running" ]]; then
  print_summary
  exit "$EXIT_CODE"
fi

# === Configuration ===
section "Configuration"

config_file=$(find_haproxy_config)
if [[ -z "$config_file" ]]; then
  register_check "Config File" FAIL "config file not found"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Config File" PASS "found at $config_file"

# Check config syntax
if haproxy -c -f "$config_file" >/dev/null 2>&1; then
  register_check "Config Syntax" PASS "configuration valid"
else
  register_check "Config Syntax" FAIL "configuration has errors"
fi

# Check config file permissions
config_perms=$(stat -c '%a' "$config_file" 2>/dev/null || stat -f '%Lp' "$config_file" 2>/dev/null || echo "000")
config_owner=$(stat -c '%U' "$config_file" 2>/dev/null || stat -f '%Su' "$config_file" 2>/dev/null || echo "unknown")

if [[ "$config_perms" =~ ^[0-9]{3}$ && "${config_perms:2:1}" -le 4 ]]; then
  register_check "Config Permissions" PASS "permissions $config_perms, owner $config_owner"
else
  register_check "Config Permissions" WARN "permissions $config_perms may be too permissive"
fi

# === TLS/SSL Configuration ===
section "TLS/SSL Security"

# Check if SSL is configured
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "bind.*ssl"; then
  register_check "SSL/TLS Configured" PASS "SSL binding found"

  # Check TLS version
  if echo "$HAPROXY_CONFIG_CONTENT" | grep "bind.*ssl" | grep -q "ssl-min-ver TLSv1.2\|ssl-min-ver TLSv1.3"; then
    min_tls=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "ssl-min-ver" | grep -oE "TLSv[0-9.]+"|head -n1)
    register_check "TLS Minimum Version" PASS "minimum TLS version: $min_tls"
  else
    register_check "TLS Minimum Version" WARN "TLS minimum version not set (recommend TLSv1.2+)"
  fi

  # Check cipher suites
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "ssl-default-bind-ciphers\|ciphers"; then
    register_check "Cipher Suites" PASS "custom cipher suites configured"

    # Check for weak ciphers
    if echo "$HAPROXY_CONFIG_CONTENT" | grep -iE "DES|RC4|MD5|NULL|EXPORT|anon" | grep -v "^[[:space:]]*#"; then
      register_check "Weak Ciphers" WARN "weak ciphers may be enabled"
    else
      register_check "Weak Ciphers" PASS "no obvious weak ciphers"
    fi
  else
    register_check "Cipher Suites" WARN "using default cipher suites (recommend explicit configuration)"
  fi

  # Check for SSL certificate paths
  cert_count=$(echo "$HAPROXY_CONFIG_CONTENT" | grep -c "bind.*ssl.*crt" || echo "0")
  if [[ "$cert_count" -gt 0 ]]; then
    register_check "SSL Certificates" PASS "$cert_count SSL certificate(s) configured"

    # Extract certificate paths and check expiration
    cert_paths=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "bind.*ssl.*crt" | grep -oE "crt [^ ]+" | awk '{print $2}' | sort -u)
    for cert_path in $cert_paths; do
      if [[ -f "$cert_path" ]]; then
        # Check if it's a directory (multi-cert)
        if [[ -d "$cert_path" ]]; then
          cert_files=$(find "$cert_path" -name "*.pem" 2>/dev/null | wc -l)
          register_check "Certificate Path" PASS "$cert_files certificates in $cert_path"
        else
          # Check expiration
          if command -v openssl >/dev/null 2>&1; then
            exp_date=$(openssl x509 -enddate -noout -in "$cert_path" 2>/dev/null | cut -d= -f2)
            if [[ -n "$exp_date" ]]; then
              exp_epoch=$(date -d "$exp_date" +%s 2>/dev/null || date -j -f "%b %d %T %Y %Z" "$exp_date" +%s 2>/dev/null || echo "0")
              now_epoch=$(date +%s)
              days_left=$(( (exp_epoch - now_epoch) / 86400 ))

              if [[ "$days_left" -lt 0 ]]; then
                register_check "Certificate Expiration" FAIL "$(basename "$cert_path") expired"
              elif [[ "$days_left" -lt 30 ]]; then
                register_check "Certificate Expiration" WARN "$(basename "$cert_path") expires in $days_left days"
              else
                register_check "Certificate Expiration" PASS "$(basename "$cert_path") valid for $days_left days"
              fi
            fi
          fi
        fi
      else
        register_check "Certificate Path" WARN "$cert_path not found"
      fi
    done
  fi

  # Check HSTS header
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -iq "Strict-Transport-Security"; then
    register_check "HSTS Header" PASS "HSTS configured"
  else
    register_check "HSTS Header" WARN "HSTS not configured (recommend for HTTPS)"
  fi
else
  register_check "SSL/TLS Configured" WARN "no SSL binding found (HTTP only?)"
fi

# === Backend Configuration ===
section "Backend Security"

# Check backend definitions
backend_count=$(echo "$HAPROXY_CONFIG_CONTENT" | grep -c "^backend " || echo "0")
if [[ "$backend_count" -gt 0 ]]; then
  register_check "Backend Definitions" PASS "$backend_count backend(s) defined"

  # Check health checks
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "option httpchk\|http-check"; then
    register_check "Backend Health Checks" PASS "health checks configured"
  else
    register_check "Backend Health Checks" WARN "no health checks found (recommend enabling)"
  fi

  # Check backend timeouts
  backend_section=$(get_config_section "^backend ")
  if echo "$backend_section" | grep -q "timeout connect\|timeout server"; then
    register_check "Backend Timeouts" PASS "backend timeouts configured"
  else
    register_check "Backend Timeouts" WARN "no explicit backend timeouts"
  fi

  # Check for encrypted backend communication
  if echo "$HAPROXY_CONFIG_CONTENT" | grep "^backend " -A 20 | grep -q "ssl\|check-ssl"; then
    register_check "Backend Encryption" PASS "encrypted backend communication detected"
  else
    register_check "Backend Encryption" WARN "backends may not use encryption (consider for sensitive data)"
  fi
else
  register_check "Backend Configuration" FAIL "no backends defined"
fi

# Check frontend definitions
frontend_count=$(echo "$HAPROXY_CONFIG_CONTENT" | grep -c "^frontend " || echo "0")
if [[ "$frontend_count" -gt 0 ]]; then
  register_check "Frontend Definitions" PASS "$frontend_count frontend(s) defined"
else
  register_check "Frontend Definitions" WARN "no frontends defined (using listen sections?)"
fi

# === Access Control ===
section "Access Control Lists (ACLs)"

# Check for ACL definitions
acl_count=$(echo "$HAPROXY_CONFIG_CONTENT" | grep -c "^[[:space:]]*acl " || echo "0")
if [[ "$acl_count" -gt 0 ]]; then
  register_check "ACL Definitions" PASS "$acl_count ACL(s) defined"

  # Check for common security ACLs
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "acl.*src\|acl.*src_ip"; then
    register_check "Source IP ACLs" PASS "source IP filtering configured"
  fi

  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "acl.*hdr\|acl.*path"; then
    register_check "Header/Path ACLs" PASS "request filtering configured"
  fi
else
  register_check "ACL Configuration" WARN "no ACLs defined (consider adding security rules)"
fi

# Check for IP whitelisting/blacklisting
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "tcp-request connection reject\|http-request deny"; then
  register_check "Request Filtering" PASS "request filtering rules configured"
else
  register_check "Request Filtering" WARN "no request filtering (consider ACL-based protection)"
fi

# === Rate Limiting ===
section "Rate Limiting & DoS Protection"

# Check stick tables (for rate limiting)
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "stick-table\|stick table"; then
  register_check "Stick Tables" PASS "stick tables configured (enables rate limiting)"

  # Check for rate limiting rules
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "sc-inc-gpc0\|track-sc"; then
    register_check "Rate Limiting Rules" PASS "rate limiting tracking configured"
  fi
else
  register_check "Rate Limiting" WARN "no stick tables (rate limiting unavailable)"
fi

# Check connection limits
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "maxconn"; then
  max_conn=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "maxconn" | head -n1 | awk '{print $2}')
  register_check "Connection Limits" PASS "maxconn: $max_conn"
else
  register_check "Connection Limits" WARN "no connection limits set"
fi

# Check timeout settings
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "timeout client\|timeout http-request"; then
  register_check "Client Timeouts" PASS "client timeouts configured"
else
  register_check "Client Timeouts" WARN "no client timeouts (potential slowloris risk)"
fi

# === Logging & Monitoring ===
section "Logging & Monitoring"

# Check logging configuration
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "^[[:space:]]*log "; then
  log_count=$(echo "$HAPROXY_CONFIG_CONTENT" | grep -c "^[[:space:]]*log " || echo "0")
  register_check "Logging Configured" PASS "$log_count log destination(s)"
else
  register_check "Logging Configured" WARN "no logging configured"
fi

# Check log level
if echo "$HAPROXY_CONFIG_CONTENT" | grep "^[[:space:]]*log " | grep -qE "local[0-9]|syslog"; then
  register_check "Log Destination" PASS "syslog destination configured"
fi

# Check stats page
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "stats enable\|stats uri"; then
  register_check "Stats Page Enabled" PASS "statistics page enabled"

  # Check stats authentication
  if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "stats auth"; then
    register_check "Stats Authentication" PASS "stats page requires authentication"
  else
    register_check "Stats Authentication" FAIL "stats page has no authentication (security risk)"
  fi

  # Check if stats are over HTTPS
  stats_section=$(get_config_section "listen.*stats\|frontend.*stats")
  if echo "$stats_section" | grep -q "bind.*ssl"; then
    register_check "Stats HTTPS" PASS "stats page over HTTPS"
  else
    register_check "Stats HTTPS" WARN "stats page not over HTTPS (credentials exposed)"
  fi
else
  register_check "Stats Page" PASS "stats page disabled (secure default)"
fi

# === HTTP Headers ===
section "HTTP Security Headers"

# Check for security headers
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "http-response set-header X-Frame-Options"; then
  register_check "X-Frame-Options" PASS "X-Frame-Options header set"
else
  register_check "X-Frame-Options" WARN "X-Frame-Options not set (clickjacking risk)"
fi

if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "http-response set-header X-Content-Type-Options"; then
  register_check "X-Content-Type-Options" PASS "X-Content-Type-Options header set"
else
  register_check "X-Content-Type-Options" WARN "X-Content-Type-Options not set (MIME sniffing risk)"
fi

if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "http-response set-header.*Content-Security-Policy"; then
  register_check "Content-Security-Policy" PASS "CSP header configured"
else
  register_check "Content-Security-Policy" WARN "CSP not configured (XSS risk)"
fi

if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "http-response set-header Referrer-Policy"; then
  register_check "Referrer-Policy" PASS "Referrer-Policy header set"
else
  register_check "Referrer-Policy" WARN "Referrer-Policy not set"
fi

# Check if Server header is removed/obfuscated
if echo "$HAPROXY_CONFIG_CONTENT" | grep -qE "http-response del-header Server|http-response set-header Server"; then
  register_check "Server Header" PASS "Server header modified (obfuscation)"
else
  register_check "Server Header" WARN "Server header not modified (version disclosure)"
fi

# === Process Security ===
section "Process Security"

# Check HAProxy user
haproxy_pid=$(pgrep -x haproxy 2>/dev/null | head -n1 || true)
if [[ -n "$haproxy_pid" ]]; then
  haproxy_user=$(ps -o user= -p "$haproxy_pid" 2>/dev/null | head -n1 | xargs || true)

  if [[ "$haproxy_user" == "root" ]]; then
    register_check "Process User" WARN "running as root (drops privileges at runtime)"
  elif [[ "$haproxy_user" == "haproxy" ]]; then
    register_check "Process User" PASS "running as haproxy user"
  else
    register_check "Process User" PASS "running as $haproxy_user"
  fi
fi

# Check user/group in config
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "^[[:space:]]*user "; then
  config_user=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "^[[:space:]]*user " | awk '{print $2}' | head -n1)
  if [[ "$config_user" != "root" ]]; then
    register_check "Config User" PASS "configured user: $config_user"
  else
    register_check "Config User" WARN "configured to run as root"
  fi
fi

if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "^[[:space:]]*group "; then
  config_group=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "^[[:space:]]*group " | awk '{print $2}' | head -n1)
  register_check "Config Group" PASS "configured group: $config_group"
fi

# Check chroot
if echo "$HAPROXY_CONFIG_CONTENT" | grep -q "^[[:space:]]*chroot "; then
  chroot_path=$(echo "$HAPROXY_CONFIG_CONTENT" | grep "^[[:space:]]*chroot " | awk '{print $2}' | head -n1)
  register_check "Chroot Jail" PASS "chroot configured: $chroot_path"
else
  register_check "Chroot Jail" WARN "chroot not configured (recommend for security)"
fi

# === Network Security ===
section "Network Configuration"

# Check listening addresses
if command -v ss >/dev/null 2>&1; then
  haproxy_listen=$(ss -tlnp 2>/dev/null | grep haproxy || echo "")
elif command -v netstat >/dev/null 2>&1; then
  haproxy_listen=$(netstat -tlnp 2>/dev/null | grep haproxy || echo "")
fi

if [[ -n "$haproxy_listen" ]]; then
  # Check for common ports
  if echo "$haproxy_listen" | grep -q ":80[[:space:]]\|:443[[:space:]]"; then
    register_check "Standard Ports" PASS "listening on HTTP/HTTPS ports"
  fi

  # Count listening ports
  port_count=$(echo "$haproxy_listen" | awk '{print $4}' | cut -d: -f2 | sort -u | wc -l)
  register_check "Listening Ports" PASS "$port_count unique port(s)"
fi

# === Summary ===
print_summary

exit "$EXIT_CODE"
