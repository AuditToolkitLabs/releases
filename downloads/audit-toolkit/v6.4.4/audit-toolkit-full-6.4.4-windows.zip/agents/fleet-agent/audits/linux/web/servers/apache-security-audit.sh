#!/usr/bin/env bash
# =============================================================================
# Apache HTTP Server Security Audit - CIS Apache Benchmark v2.4 Aligned
# =============================================================================
# Version: 5.0.0
# Compliance: CIS Apache HTTP Server v2.4 Benchmark, NIST SP 800-53, PCI DSS
#
# CIS Apache HTTP Server Benchmark Sections Covered:
#   1.x  - Planning and Installation
#   2.x  - Minimize Apache Modules
#   3.x  - Principles, Permissions, and Ownership
#   4.x  - Apache Access Control
#   5.x  - Minimize Features, Content, and Options
#   6.x  - Operations - Logging, Monitoring, and Maintenance
#   7.x  - Request Limits
#   8.x  - SSL/TLS Configuration
#   9.x  - Information Leakage
#  10.x  - Denial of Service Mitigations
# =============================================================================
#
# @elevation: partial
# @elevation-reason: Apache configs and SSL keys may need root for access
#
set -euo pipefail

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source libraries
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../../lib/common.sh
. "$SCRIPT_DIR/../../../lib/common.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/distro.sh
. "$SCRIPT_DIR/../../../lib/distro.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/svc.sh
. "$SCRIPT_DIR/../../../lib/svc.sh"
# shellcheck disable=SC1091
# shellcheck source=../../../lib/pkg.sh
. "$SCRIPT_DIR/../../../lib/pkg.sh"

# Apache paths (distro-agnostic)
APACHE_CONF_DIR=""
APACHE_BIN=""
APACHE_SVC=""
APACHE_USER=""
APACHE_GROUP=""
APACHE_LOG_DIR=""
APACHE_DOC_ROOT=""

# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------
detect_apache() {
  # Detect Apache binary
  if command -v apache2 >/dev/null 2>&1; then
    APACHE_BIN="apache2"
    APACHE_SVC="apache2"
  elif command -v httpd >/dev/null 2>&1; then
    APACHE_BIN="httpd"
    APACHE_SVC="httpd"
  else
    return 1
  fi

  # Detect config directory
  if [[ -d /etc/apache2 ]]; then
    APACHE_CONF_DIR="/etc/apache2"
    APACHE_USER="www-data"
    APACHE_GROUP="www-data"
    APACHE_LOG_DIR="/var/log/apache2"
  elif [[ -d /etc/httpd ]]; then
    APACHE_CONF_DIR="/etc/httpd"
    APACHE_USER="apache"
    APACHE_GROUP="apache"
    APACHE_LOG_DIR="/var/log/httpd"
  else
    return 1
  fi

  # Try to find actual user from config
  local envvars="/etc/apache2/envvars"
  if [[ -f "$envvars" ]]; then
    local conf_user
    conf_user=$(grep -E "^export APACHE_RUN_USER=" "$envvars" 2>/dev/null | cut -d= -f2 || echo "")
    [[ -n "$conf_user" ]] && APACHE_USER="$conf_user"
  fi

  # Detect document root
  APACHE_DOC_ROOT="/var/www/html"
  [[ ! -d "$APACHE_DOC_ROOT" ]] && APACHE_DOC_ROOT="/var/www"
  [[ ! -d "$APACHE_DOC_ROOT" ]] && APACHE_DOC_ROOT="/srv/http"

  return 0
}

get_apache_version() {
  "$APACHE_BIN" -v 2>&1 | head -n1 | grep -oP 'Apache/\K[0-9.]+'
}

apache_config_test() {
  if command -v apache2ctl >/dev/null 2>&1; then
    apache2ctl configtest 2>&1
  elif command -v apachectl >/dev/null 2>&1; then
    apachectl configtest 2>&1
  else
    "$APACHE_BIN" -t 2>&1
  fi
}

grep_apache_config() {
  local pattern="$1"
  grep -RIhE "$pattern" "$APACHE_CONF_DIR" 2>/dev/null || echo ""
}

check_module_enabled() {
  local module="$1"

  # Debian/Ubuntu style
  if [[ -d "$APACHE_CONF_DIR/mods-enabled" ]]; then
    [[ -f "$APACHE_CONF_DIR/mods-enabled/${module}.load" ]] && return 0
  fi

  # RHEL/CentOS style
  if [[ -d "$APACHE_CONF_DIR/conf.modules.d" ]]; then
    grep -rqE "^\s*LoadModule\s+${module}_module" "$APACHE_CONF_DIR/conf.modules.d" 2>/dev/null && return 0
  fi

  # Generic check in main config
  grep -rqE "^\s*LoadModule\s+${module}_module" "$APACHE_CONF_DIR" 2>/dev/null && return 0

  return 1
}

check_directive() {
  local directive="$1"
  local pattern="^\s*${directive}\s+"
  grep_apache_config "$pattern" | grep -v "^\s*#" | tail -1
}

# -----------------------------------------------------------------------------
# Usage
# -----------------------------------------------------------------------------
usage() {
  cat <<EOF
Apache HTTP Server Security Audit - CIS Apache Benchmark v2.4 Aligned

Usage: $(basename "$0") [OPTIONS]

Options:
  -h, --help     Show this help message
  -v, --verbose  Enable verbose output

CIS Apache HTTP Server 2.4 Benchmark Sections:
  1.x  Planning and Installation
       - Dedicated user account (non-root)
       - Apache package from vendor
       - Version currency

  2.x  Minimize Apache Modules
       - Disable unnecessary modules
       - Required modules only
       - No deprecated modules

  3.x  Principles, Permissions, and Ownership
       - Root ownership of directories
       - Web content ownership
       - Restrict configuration access
       - Lock down core directories

  4.x  Apache Access Control
       - Deny access by default
       - Restrict root directory access
       - Override restrictions (AllowOverride)
       - Options restrictions

  5.x  Minimize Features, Content, and Options
       - Restrict HTTP methods
       - Disable TRACE method
       - Limit request body size
       - Disable CGI where not needed

  6.x  Operations - Logging, Monitoring, and Maintenance
       - Error log configuration
       - Access log configuration
       - Log level settings
       - LogFormat directive

  7.x  Request Limits
       - LimitRequestLine
       - LimitRequestFields
       - LimitRequestFieldSize
       - LimitRequestBody

  8.x  SSL/TLS Configuration
       - SSL module enabled
       - Strong protocols only (TLS 1.2+)
       - Strong cipher suites
       - HSTS header
       - Certificate validation

  9.x  Information Leakage Prevention
       - ServerTokens Prod
       - ServerSignature Off
       - Disable Server header leakage
       - Error document customization

 10.x  Denial of Service Mitigations
       - Timeout settings
       - KeepAlive configuration
       - MaxRequestWorkers limit
       - mod_reqtimeout

Compliance: NIST SP 800-53, PCI DSS v4.0, OWASP
Reference: CIS Apache HTTP Server v2.4 Benchmark
EOF
  exit 0
}

# Parse arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    -h | --help) usage ;;
    -v | --verbose)
      VERBOSE=1
      shift
      ;;
    *) shift ;;
  esac
done

if [[ "${VERBOSE:-0}" -eq 1 ]]; then
  echo "[INFO] Verbose mode enabled" >&2
fi

# -----------------------------------------------------------------------------
# Audit Start
# -----------------------------------------------------------------------------
section "System Information"
register_check "Audit Version" PASS "5.0.0 (CIS Apache v2.4 Benchmark)"
register_check "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
register_check "Date" PASS "$(date -Iseconds)"

# Detect Apache
if ! detect_apache; then
  register_check "Apache Installation" FAIL "Apache not installed"
  print_summary
  exit "$EXIT_CODE"
fi

register_check "Apache Binary" PASS "$APACHE_BIN"
register_check "Config Directory" PASS "$APACHE_CONF_DIR"
[[ -n "$APACHE_GROUP" ]] && register_check "Apache Group" PASS "$APACHE_GROUP"

apache_version=$(get_apache_version)
register_check "Apache Version" PASS "$apache_version"

# =============================================================================
# CIS 1.x - Planning and Installation
# =============================================================================
section "CIS 1.x - Planning and Installation"

# CIS 1.1 - Ensure the pre-installation planning checklist has been implemented
# (Manual - informational)
register_check "CIS 1.1: Pre-install planning" PASS "Apache installed and configured"

# CIS 1.2 - Ensure the server is not a multi-use system
# Check for common non-web services
multi_use=false
for svc in mysql mariadb postgresql mongod redis-server memcached; do
  if svc_is_active "$svc" 2>/dev/null; then
    register_check "CIS 1.2: Multi-use ($svc)" WARN "$svc running on web server"
    multi_use=true
  fi
done
if ! $multi_use; then
  register_check "CIS 1.2: Dedicated server" PASS "No database services detected"
fi

# CIS 1.3 - Ensure Apache is installed from appropriate binaries
if pkg_installed "apache2" || pkg_installed "httpd" || pkg_installed "apache"; then
  register_check "CIS 1.3: Package installation" PASS "Installed via package manager"
else
  register_check "CIS 1.3: Package installation" WARN "Not detected in package manager"
fi

# CIS 1.4 - Ensure the Apache service account is locked
if [[ -n "$APACHE_USER" ]]; then
  user_shell=$(getent passwd "$APACHE_USER" 2>/dev/null | cut -d: -f7 || echo "")
  if [[ "$user_shell" == "/usr/sbin/nologin" ]] || [[ "$user_shell" == "/bin/false" ]] || [[ "$user_shell" == "/sbin/nologin" ]]; then
    register_check "CIS 1.4: Service account shell" PASS "$APACHE_USER has $user_shell"
  else
    register_check "CIS 1.4: Service account shell" FAIL "$APACHE_USER has $user_shell (should be nologin)"
  fi

  # Check account is locked
  passwd_status=$(passwd -S "$APACHE_USER" 2>/dev/null | awk '{print $2}' || echo "")
  if [[ "$passwd_status" == "L" ]] || [[ "$passwd_status" == "LK" ]]; then
    register_check "CIS 1.4: Service account locked" PASS "Password locked"
  else
    register_check "CIS 1.4: Service account locked" WARN "Account may not be locked"
  fi
else
  register_check "CIS 1.4: Service account" SKIP "Cannot determine Apache user"
fi

# CIS 1.5 - Ensure separate partition for Apache
apache_root=$(dirname "$APACHE_DOC_ROOT")
if mount | grep -q " $apache_root "; then
  register_check "CIS 1.5: Separate partition" PASS "$apache_root on separate partition"
elif mount | grep -q " $APACHE_DOC_ROOT "; then
  register_check "CIS 1.5: Separate partition" PASS "$APACHE_DOC_ROOT on separate partition"
else
  register_check "CIS 1.5: Separate partition" WARN "Web root not on separate partition"
fi

# =============================================================================
# CIS 2.x - Minimize Apache Modules
# =============================================================================
section "CIS 2.x - Minimize Apache Modules"

# CIS 2.1 - Ensure only necessary authentication modules are enabled
auth_modules=(authn_file authn_dbm authn_anon authn_dbd authn_socache authn_core)
for mod in "${auth_modules[@]}"; do
  if check_module_enabled "$mod"; then
    if [[ "$mod" == "authn_core" ]]; then
      register_check "CIS 2.1: Module $mod" PASS "Required module"
    else
      register_check "CIS 2.1: Module $mod" WARN "Enabled - verify if needed"
    fi
  fi
done

# CIS 2.2 - Ensure the log_config module is enabled
if check_module_enabled "log_config"; then
  register_check "CIS 2.2: log_config module" PASS "Enabled"
else
  register_check "CIS 2.2: log_config module" FAIL "Not enabled - logging required"
fi

# CIS 2.3 - Ensure the WebDAV modules are disabled
for mod in dav dav_fs dav_lock; do
  if check_module_enabled "$mod"; then
    register_check "CIS 2.3: Module $mod" FAIL "WebDAV enabled - disable if not needed"
  else
    register_check "CIS 2.3: Module $mod" PASS "Disabled"
  fi
done

# CIS 2.4 - Ensure status module is disabled
if check_module_enabled "status"; then
  register_check "CIS 2.4: status module" WARN "Enabled - exposes server information"
else
  register_check "CIS 2.4: status module" PASS "Disabled"
fi

# CIS 2.5 - Ensure autoindex module is disabled
if check_module_enabled "autoindex"; then
  register_check "CIS 2.5: autoindex module" WARN "Enabled - allows directory listing"
else
  register_check "CIS 2.5: autoindex module" PASS "Disabled"
fi

# CIS 2.6 - Ensure proxy modules are disabled if not used
proxy_disabled=true
for mod in proxy proxy_connect proxy_ftp proxy_http proxy_fcgi proxy_scgi proxy_ajp proxy_balancer proxy_express proxy_hcheck proxy_html proxy_wstunnel; do
  if check_module_enabled "$mod"; then
    register_check "CIS 2.6: Module $mod" WARN "Proxy module enabled - verify if needed"
    proxy_disabled=false
  fi
done
if $proxy_disabled; then
  register_check "CIS 2.6: Proxy modules" PASS "No proxy modules enabled"
fi

# CIS 2.7 - Ensure the userdir module is disabled
if check_module_enabled "userdir"; then
  register_check "CIS 2.7: userdir module" FAIL "Enabled - user directories exposed"
else
  register_check "CIS 2.7: userdir module" PASS "Disabled"
fi

# CIS 2.8 - Ensure the info module is disabled
if check_module_enabled "info"; then
  register_check "CIS 2.8: info module" FAIL "Enabled - server info exposed"
else
  register_check "CIS 2.8: info module" PASS "Disabled"
fi

# CIS 2.9 - Ensure basic and digest authentication modules are disabled if not needed
for mod in auth_basic auth_digest; do
  if check_module_enabled "$mod"; then
    register_check "CIS 2.9: Module $mod" WARN "Enabled - verify if needed"
  fi
done

# =============================================================================
# CIS 3.x - Principles, Permissions, and Ownership
# =============================================================================
section "CIS 3.x - Permissions and Ownership"

# CIS 3.1 - Ensure Apache document root does not exist on system partition
# (Covered in 1.5)

# CIS 3.2 - Ensure the Apache user has a valid login but invalid shell
# (Covered in 1.4)

# CIS 3.3 - Ensure Apache user account is locked
# (Covered in 1.4)

# CIS 3.4 - Ensure Apache directories and files are owned by root
if [[ -d "$APACHE_CONF_DIR" ]]; then
  conf_owner=$(stat -c "%U" "$APACHE_CONF_DIR" 2>/dev/null || echo "")
  if [[ "$conf_owner" == "root" ]]; then
    register_check "CIS 3.4: Config dir owner" PASS "root"
  else
    register_check "CIS 3.4: Config dir owner" FAIL "$conf_owner (should be root)"
  fi
fi

# CIS 3.5 - Ensure the group is set correctly on Apache directories
if [[ -d "$APACHE_CONF_DIR" ]]; then
  conf_group=$(stat -c "%G" "$APACHE_CONF_DIR" 2>/dev/null || echo "")
  if [[ "$conf_group" == "root" ]]; then
    register_check "CIS 3.5: Config dir group" PASS "root"
  else
    register_check "CIS 3.5: Config dir group" WARN "$conf_group (consider root)"
  fi
fi

# CIS 3.6 - Ensure other write access on Apache directories is restricted
if [[ -d "$APACHE_CONF_DIR" ]]; then
  conf_perms=$(stat -c "%a" "$APACHE_CONF_DIR" 2>/dev/null || echo "")
  if [[ "${conf_perms: -1}" =~ [0-5] ]]; then
    register_check "CIS 3.6: Config dir permissions" PASS "$conf_perms"
  else
    register_check "CIS 3.6: Config dir permissions" FAIL "$conf_perms (world-writable)"
  fi
fi

# CIS 3.7 - Ensure the core dump directory is secured
core_dump_dir=$(check_directive "CoreDumpDirectory")
if [[ -n "$core_dump_dir" ]]; then
  dump_dir=$(echo "$core_dump_dir" | awk '{print $2}')
  if [[ -d "$dump_dir" ]]; then
    dump_perms=$(stat -c "%a" "$dump_dir" 2>/dev/null || echo "")
    if [[ "$dump_perms" == "700" ]]; then
      register_check "CIS 3.7: CoreDumpDirectory" PASS "Secure: $dump_perms"
    else
      register_check "CIS 3.7: CoreDumpDirectory" WARN "Permissions: $dump_perms (should be 700)"
    fi
  fi
else
  register_check "CIS 3.7: CoreDumpDirectory" PASS "Not configured (default)"
fi

# CIS 3.8 - Ensure lock file is secured
lock_dir="/var/lock/apache2"
[[ ! -d "$lock_dir" ]] && lock_dir="/var/run/httpd"
if [[ -d "$lock_dir" ]]; then
  lock_owner=$(stat -c "%U" "$lock_dir" 2>/dev/null || echo "")
  if [[ "$lock_owner" == "root" ]]; then
    register_check "CIS 3.8: Lock file directory" PASS "Owned by root"
  else
    register_check "CIS 3.8: Lock file directory" WARN "Owned by $lock_owner"
  fi
fi

# CIS 3.9 - Ensure the PID file is secured
pid_file="/var/run/apache2/apache2.pid"
[[ ! -f "$pid_file" ]] && pid_file="/var/run/httpd/httpd.pid"
[[ ! -f "$pid_file" ]] && pid_file="/run/apache2/apache2.pid"
if [[ -f "$pid_file" ]]; then
  pid_perms=$(stat -c "%a" "$pid_file" 2>/dev/null || echo "")
  if [[ "$pid_perms" -le 644 ]]; then
    register_check "CIS 3.9: PID file permissions" PASS "$pid_perms"
  else
    register_check "CIS 3.9: PID file permissions" WARN "$pid_perms (should be 644 or less)"
  fi
fi

# CIS 3.10 - Ensure the ScoreBoard local-only
score_board=$(check_directive "ScoreBoardFile")
if [[ -n "$score_board" ]]; then
  register_check "CIS 3.10: ScoreBoardFile" WARN "Custom location configured"
fi

# CIS 3.11-3.12 - Ensure Group and User directives are correct
user_directive=$(check_directive "User")
group_directive=$(check_directive "Group")
if [[ -n "$user_directive" ]]; then
  configured_user=$(echo "$user_directive" | awk '{print $2}')
  if [[ "$configured_user" != "root" ]]; then
    register_check "CIS 3.11: User directive" PASS "$configured_user"
  else
    register_check "CIS 3.11: User directive" FAIL "Running as root"
  fi
fi
if [[ -n "$group_directive" ]]; then
  configured_group=$(echo "$group_directive" | awk '{print $2}')
  if [[ "$configured_group" != "root" ]]; then
    register_check "CIS 3.12: Group directive" PASS "$configured_group"
  else
    register_check "CIS 3.12: Group directive" FAIL "Running as root group"
  fi
fi

# Web content permissions
if [[ -d "$APACHE_DOC_ROOT" ]]; then
  docroot_perms=$(stat -c "%a" "$APACHE_DOC_ROOT" 2>/dev/null || echo "")
  docroot_owner=$(stat -c "%U:%G" "$APACHE_DOC_ROOT" 2>/dev/null || echo "")
  if [[ "${docroot_perms: -1}" =~ [0-5] ]]; then
    register_check "CIS 3.x: Document root permissions" PASS "$docroot_perms ($docroot_owner)"
  else
    register_check "CIS 3.x: Document root permissions" FAIL "$docroot_perms - world-writable"
  fi
fi

# =============================================================================
# CIS 4.x - Apache Access Control
# =============================================================================
section "CIS 4.x - Apache Access Control"

# CIS 4.1 - Ensure access to root directory is denied
root_dir_config=$(grep_apache_config "<Directory\s+/\s*>" | head -1)
if [[ -n "$root_dir_config" ]]; then
  # Check for Require all denied
  root_deny=$(grep_apache_config "Require\s+all\s+denied")
  if [[ -n "$root_deny" ]]; then
    register_check "CIS 4.1: Root directory access" PASS "Require all denied configured"
  else
    register_check "CIS 4.1: Root directory access" WARN "Check root directory restrictions"
  fi
else
  register_check "CIS 4.1: Root directory" WARN "No explicit root directory configuration"
fi

# CIS 4.2 - Ensure appropriate access to web content is allowed
# Check that document root has appropriate access
if grep_apache_config "<Directory\s+$APACHE_DOC_ROOT" | grep -q .; then
  register_check "CIS 4.2: Document root config" PASS "Configuration exists"
else
  register_check "CIS 4.2: Document root config" WARN "No explicit document root configuration"
fi

# CIS 4.3 - Ensure OverRide is disabled for root directory
override_root=$(grep_apache_config "AllowOverride" | head -1)
if [[ -n "$override_root" ]]; then
  if echo "$override_root" | grep -qi "None"; then
    register_check "CIS 4.3: AllowOverride (root)" PASS "AllowOverride None configured"
  else
    register_check "CIS 4.3: AllowOverride (root)" WARN "AllowOverride not set to None"
  fi
else
  register_check "CIS 4.3: AllowOverride" WARN "Not explicitly configured"
fi

# CIS 4.4 - Ensure OverRide is disabled for OS root directory
# (Covered in 4.3)

# =============================================================================
# CIS 5.x - Minimize Features, Content, and Options
# =============================================================================
section "CIS 5.x - Minimize Features and Options"

# CIS 5.1 - Ensure Options for OS root directory are restricted
options_config=$(grep_apache_config "^\s*Options\s+" | grep -v "^\s*#")
if [[ -n "$options_config" ]]; then
  if echo "$options_config" | grep -qE "Options\s+None"; then
    register_check "CIS 5.1: Options directive" PASS "Options None found"
  elif echo "$options_config" | grep -qE "Options\s+-"; then
    register_check "CIS 5.1: Options directive" PASS "Restrictive options configured"
  else
    register_check "CIS 5.1: Options directive" WARN "Review Options directives"
  fi
fi

# CIS 5.2 - Ensure Options for web root are restricted
# Check for Indexes
if echo "$options_config" | grep -qiE "Indexes"; then
  if echo "$options_config" | grep -qE "\-Indexes"; then
    register_check "CIS 5.2: Directory Indexes" PASS "Indexes disabled (-Indexes)"
  else
    register_check "CIS 5.2: Directory Indexes" FAIL "Indexes enabled - directory listing possible"
  fi
else
  register_check "CIS 5.2: Directory Indexes" PASS "Indexes not explicitly enabled"
fi

# CIS 5.3 - Ensure Options for other directories are minimized
if echo "$options_config" | grep -qiE "FollowSymLinks|ExecCGI|Includes"; then
  if echo "$options_config" | grep -qE "\-FollowSymLinks"; then
    register_check "CIS 5.3: FollowSymLinks" PASS "Disabled"
  else
    register_check "CIS 5.3: FollowSymLinks" WARN "May be enabled - review"
  fi
fi

# CIS 5.4-5.6 - Ensure default HTML content is removed
default_files=("/var/www/html/index.html" "/srv/http/index.html" "/var/www/html/icons")
for file in "${default_files[@]}"; do
  if [[ -e "$file" ]]; then
    if [[ -f "$file" ]] && grep -qiE "apache|ubuntu|debian|works|testing" "$file" 2>/dev/null; then
      register_check "CIS 5.4-5.6: Default content" WARN "Default content at $file"
    fi
  fi
done

# CIS 5.7 - Ensure HTTP request methods are restricted
limit_config=$(grep_apache_config "<Limit\|<LimitExcept")
if [[ -n "$limit_config" ]]; then
  register_check "CIS 5.7: HTTP methods restriction" PASS "Limit/LimitExcept configured"
else
  register_check "CIS 5.7: HTTP methods restriction" WARN "No HTTP method restrictions"
fi

# CIS 5.8 - Ensure TRACE method is disabled
trace_config=$(check_directive "TraceEnable")
if [[ -n "$trace_config" ]]; then
  if echo "$trace_config" | grep -qi "Off"; then
    register_check "CIS 5.8: TRACE method" PASS "TraceEnable Off"
  else
    register_check "CIS 5.8: TRACE method" FAIL "TRACE method enabled"
  fi
else
  register_check "CIS 5.8: TRACE method" WARN "TraceEnable not configured (enabled by default)"
fi

# CIS 5.9 - Ensure old HTTP protocol versions are disallowed
http_protocol=$(check_directive "Protocols")
if [[ -n "$http_protocol" ]]; then
  register_check "CIS 5.9: HTTP protocols" PASS "Protocols configured: $http_protocol"
else
  register_check "CIS 5.9: HTTP protocols" WARN "Protocols not explicitly configured"
fi

# CIS 5.10-5.13 - Remove default error documents and icons
if [[ -d "$APACHE_CONF_DIR/conf-enabled" ]]; then
  if [[ -f "$APACHE_CONF_DIR/conf-enabled/serve-cgi-bin.conf" ]]; then
    register_check "CIS 5.10: CGI bin" WARN "serve-cgi-bin.conf enabled"
  fi
fi

# =============================================================================
# CIS 6.x - Logging and Monitoring
# =============================================================================
section "CIS 6.x - Logging and Monitoring"

# CIS 6.1 - Ensure the error log is correctly configured
error_log=$(check_directive "ErrorLog")
if [[ -n "$error_log" ]]; then
  log_path=$(echo "$error_log" | awk '{print $2}')
  register_check "CIS 6.1: ErrorLog" PASS "Configured: $log_path"
else
  register_check "CIS 6.1: ErrorLog" WARN "Not explicitly configured"
fi

# CIS 6.2 - Ensure log level is set correctly
log_level=$(check_directive "LogLevel")
if [[ -n "$log_level" ]]; then
  level=$(echo "$log_level" | awk '{print $2}')
  case "$level" in
    warn | notice | info)
      register_check "CIS 6.2: LogLevel" PASS "$level"
      ;;
    debug | trace*)
      register_check "CIS 6.2: LogLevel" WARN "$level (verbose - production concern)"
      ;;
    error | crit | alert | emerg)
      register_check "CIS 6.2: LogLevel" WARN "$level (may miss important warnings)"
      ;;
    *)
      register_check "CIS 6.2: LogLevel" PASS "$level"
      ;;
  esac
else
  register_check "CIS 6.2: LogLevel" WARN "Not configured (default: warn)"
fi

# CIS 6.3 - Ensure access log is correctly configured
custom_log=$(check_directive "CustomLog")
if [[ -n "$custom_log" ]]; then
  register_check "CIS 6.3: CustomLog" PASS "Configured"
else
  register_check "CIS 6.3: CustomLog" WARN "Not configured"
fi

# CIS 6.4 - Ensure log storage and rotation are configured
if [[ -d "$APACHE_LOG_DIR" ]]; then
  register_check "CIS 6.4: Log directory" PASS "$APACHE_LOG_DIR exists"

  # Check for logrotate
  if [[ -f "/etc/logrotate.d/apache2" ]] || [[ -f "/etc/logrotate.d/httpd" ]]; then
    register_check "CIS 6.4: Log rotation" PASS "logrotate configured"
  else
    register_check "CIS 6.4: Log rotation" WARN "No logrotate configuration found"
  fi
fi

# CIS 6.5 - Ensure log files permissions are correct
if [[ -d "$APACHE_LOG_DIR" ]]; then
  log_perms=$(stat -c "%a" "$APACHE_LOG_DIR" 2>/dev/null || echo "")
  if [[ "$log_perms" -le 750 ]]; then
    register_check "CIS 6.5: Log dir permissions" PASS "$log_perms"
  else
    register_check "CIS 6.5: Log dir permissions" WARN "$log_perms (should be 750 or less)"
  fi
fi

# CIS 6.6 - Ensure LogFormat contains required fields
log_format=$(grep_apache_config "^\s*LogFormat\s+" | head -1)
if [[ -n "$log_format" ]]; then
  has_required=true
  for field in "%h" "%l" "%u" "%t" "%r" "%s" "%b"; do
    if ! echo "$log_format" | grep -q "$field"; then
      has_required=false
      break
    fi
  done
  if $has_required; then
    register_check "CIS 6.6: LogFormat" PASS "Contains required fields"
  else
    register_check "CIS 6.6: LogFormat" WARN "May be missing required fields"
  fi
else
  register_check "CIS 6.6: LogFormat" WARN "Custom LogFormat not found"
fi

# CIS 6.7 - Ensure module logging is enabled
if check_module_enabled "log_config"; then
  register_check "CIS 6.7: log_config module" PASS "Enabled"
fi
if check_module_enabled "logio"; then
  register_check "CIS 6.7: logio module" PASS "Enabled (I/O logging)"
fi

# =============================================================================
# CIS 7.x - Request Limits
# =============================================================================
section "CIS 7.x - Request Limits"

# CIS 7.1 - Ensure LimitRequestLine is set
limit_request_line=$(check_directive "LimitRequestLine")
if [[ -n "$limit_request_line" ]]; then
  value=$(echo "$limit_request_line" | awk '{print $2}')
  if [[ "$value" -le 8190 ]]; then
    register_check "CIS 7.1: LimitRequestLine" PASS "$value"
  else
    register_check "CIS 7.1: LimitRequestLine" WARN "$value (consider <= 8190)"
  fi
else
  register_check "CIS 7.1: LimitRequestLine" WARN "Not set (default: 8190)"
fi

# CIS 7.2 - Ensure LimitRequestFields is set
limit_request_fields=$(check_directive "LimitRequestFields")
if [[ -n "$limit_request_fields" ]]; then
  value=$(echo "$limit_request_fields" | awk '{print $2}')
  if [[ "$value" -le 100 ]]; then
    register_check "CIS 7.2: LimitRequestFields" PASS "$value"
  else
    register_check "CIS 7.2: LimitRequestFields" WARN "$value (consider <= 100)"
  fi
else
  register_check "CIS 7.2: LimitRequestFields" WARN "Not set (default: 100)"
fi

# CIS 7.3 - Ensure LimitRequestFieldSize is set
limit_field_size=$(check_directive "LimitRequestFieldSize")
if [[ -n "$limit_field_size" ]]; then
  value=$(echo "$limit_field_size" | awk '{print $2}')
  if [[ "$value" -le 8190 ]]; then
    register_check "CIS 7.3: LimitRequestFieldSize" PASS "$value"
  else
    register_check "CIS 7.3: LimitRequestFieldSize" WARN "$value (consider <= 8190)"
  fi
else
  register_check "CIS 7.3: LimitRequestFieldSize" WARN "Not set (default: 8190)"
fi

# CIS 7.4 - Ensure LimitRequestBody is set
limit_request_body=$(check_directive "LimitRequestBody")
if [[ -n "$limit_request_body" ]]; then
  value=$(echo "$limit_request_body" | awk '{print $2}')
  register_check "CIS 7.4: LimitRequestBody" PASS "$value"
else
  register_check "CIS 7.4: LimitRequestBody" WARN "Not set (default: unlimited)"
fi

# =============================================================================
# CIS 8.x - SSL/TLS Configuration
# =============================================================================
section "CIS 8.x - SSL/TLS Configuration"

# CIS 8.1 - Ensure SSL module is enabled
if check_module_enabled "ssl"; then
  register_check "CIS 8.1: SSL module" PASS "Enabled"

  # CIS 8.2 - Ensure SSLProtocol is set correctly
  ssl_protocol=$(check_directive "SSLProtocol")
  if [[ -n "$ssl_protocol" ]]; then
    if echo "$ssl_protocol" | grep -qiE "SSLv2|SSLv3|TLSv1[^.2-3]"; then
      register_check "CIS 8.2: SSLProtocol" FAIL "Legacy protocols enabled"
    elif echo "$ssl_protocol" | grep -qiE "TLSv1\.[23]|all.*-SSL"; then
      register_check "CIS 8.2: SSLProtocol" PASS "Modern protocols only"
    else
      register_check "CIS 8.2: SSLProtocol" WARN "$ssl_protocol - review"
    fi
  else
    register_check "CIS 8.2: SSLProtocol" WARN "Not configured"
  fi

  # CIS 8.3 - Ensure SSLHonorCipherOrder is enabled
  cipher_order=$(check_directive "SSLHonorCipherOrder")
  if [[ -n "$cipher_order" ]]; then
    if echo "$cipher_order" | grep -qi "On"; then
      register_check "CIS 8.3: SSLHonorCipherOrder" PASS "On"
    else
      register_check "CIS 8.3: SSLHonorCipherOrder" WARN "Off"
    fi
  else
    register_check "CIS 8.3: SSLHonorCipherOrder" WARN "Not configured"
  fi

  # CIS 8.4 - Ensure SSLCompression is disabled
  ssl_compression=$(check_directive "SSLCompression")
  if [[ -n "$ssl_compression" ]]; then
    if echo "$ssl_compression" | grep -qi "Off"; then
      register_check "CIS 8.4: SSLCompression" PASS "Off"
    else
      register_check "CIS 8.4: SSLCompression" FAIL "On (CRIME attack vector)"
    fi
  else
    register_check "CIS 8.4: SSLCompression" PASS "Off (default in modern Apache)"
  fi

  # CIS 8.5 - Ensure cipher suite is properly configured
  ssl_cipher_suite=$(check_directive "SSLCipherSuite")
  if [[ -n "$ssl_cipher_suite" ]]; then
    if echo "$ssl_cipher_suite" | grep -qiE "NULL|EXPORT|DES|RC4|MD5|PSK|aNULL"; then
      register_check "CIS 8.5: SSLCipherSuite" FAIL "Weak ciphers included"
    else
      register_check "CIS 8.5: SSLCipherSuite" PASS "Configured"
    fi
  else
    register_check "CIS 8.5: SSLCipherSuite" WARN "Not explicitly configured"
  fi

  # CIS 8.6 - Ensure OCSP Stapling is enabled
  ssl_stapling=$(check_directive "SSLUseStapling")
  if [[ -n "$ssl_stapling" ]]; then
    if echo "$ssl_stapling" | grep -qi "On"; then
      register_check "CIS 8.6: OCSP Stapling" PASS "Enabled"
    else
      register_check "CIS 8.6: OCSP Stapling" WARN "Disabled"
    fi
  else
    register_check "CIS 8.6: OCSP Stapling" WARN "Not configured"
  fi

  # Check certificates
  ssl_certs=$(grep_apache_config "^\s*SSLCertificateFile\s+" | awk '{print $2}' | sort -u)
  if [[ -n "$ssl_certs" ]]; then
    while read -r cert; do
      [[ -z "$cert" ]] && continue
      if [[ -f "$cert" ]]; then
        if command -v openssl >/dev/null 2>&1; then
          end_date=$(openssl x509 -in "$cert" -noout -enddate 2>/dev/null | cut -d= -f2 || echo "")
          if [[ -n "$end_date" ]]; then
            exp_epoch=$(date -d "$end_date" +%s 2>/dev/null || echo "0")
            now_epoch=$(date +%s)
            days_left=$(((exp_epoch - now_epoch) / 86400))

            if [[ $days_left -lt 0 ]]; then
              register_check "CIS 8.x: Cert $cert" FAIL "EXPIRED"
            elif [[ $days_left -lt 14 ]]; then
              register_check "CIS 8.x: Cert $cert" FAIL "Expires in $days_left days"
            elif [[ $days_left -lt 30 ]]; then
              register_check "CIS 8.x: Cert $cert" WARN "Expires in $days_left days"
            else
              register_check "CIS 8.x: Cert $cert" PASS "$days_left days until expiry"
            fi
          fi
        fi
      else
        register_check "CIS 8.x: Cert $cert" FAIL "File not found"
      fi
    done <<<"$ssl_certs"
  fi

  # Check key file permissions
  ssl_keys=$(grep_apache_config "^\s*SSLCertificateKeyFile\s+" | awk '{print $2}' | sort -u)
  if [[ -n "$ssl_keys" ]]; then
    while read -r key; do
      [[ -z "$key" ]] && continue
      if [[ -f "$key" ]]; then
        key_perms=$(stat -c "%a" "$key" 2>/dev/null || echo "")
        if [[ "$key_perms" == "600" ]] || [[ "$key_perms" == "400" ]]; then
          register_check "CIS 8.x: Key $key" PASS "Permissions: $key_perms"
        else
          register_check "CIS 8.x: Key $key" FAIL "Permissions: $key_perms (should be 600 or 400)"
        fi
      fi
    done <<<"$ssl_keys"
  fi
else
  register_check "CIS 8.1: SSL module" WARN "Not enabled - HTTPS not configured"
fi

# =============================================================================
# CIS 9.x - Information Leakage Prevention
# =============================================================================
section "CIS 9.x - Information Leakage Prevention"

# CIS 9.1 - Ensure ServerTokens is set to Prod
server_tokens=$(check_directive "ServerTokens")
if [[ -n "$server_tokens" ]]; then
  if echo "$server_tokens" | grep -qiE "Prod|ProductOnly"; then
    register_check "CIS 9.1: ServerTokens" PASS "Minimal disclosure"
  else
    register_check "CIS 9.1: ServerTokens" FAIL "$(echo "$server_tokens" | awk '{print $2}') - information disclosure"
  fi
else
  register_check "CIS 9.1: ServerTokens" FAIL "Not set (default: Full)"
fi

# CIS 9.2 - Ensure ServerSignature is set to Off
server_signature=$(check_directive "ServerSignature")
if [[ -n "$server_signature" ]]; then
  if echo "$server_signature" | grep -qi "Off"; then
    register_check "CIS 9.2: ServerSignature" PASS "Off"
  else
    register_check "CIS 9.2: ServerSignature" FAIL "$(echo "$server_signature" | awk '{print $2}')"
  fi
else
  register_check "CIS 9.2: ServerSignature" FAIL "Not set (default: On)"
fi

# CIS 9.3 - Ensure Server header is removed if possible
# Check for headers module
if check_module_enabled "headers"; then
  header_unset=$(grep_apache_config "Header\s+(always\s+)?unset\s+Server")
  if [[ -n "$header_unset" ]]; then
    register_check "CIS 9.3: Server header" PASS "Unset configured"
  else
    register_check "CIS 9.3: Server header" WARN "Header not unset (consider: Header always unset Server)"
  fi
fi

# CIS 9.4 - Ensure ETag header is configured
fileetag=$(check_directive "FileETag")
if [[ -n "$fileetag" ]]; then
  if echo "$fileetag" | grep -qiE "None|MTime|Size"; then
    register_check "CIS 9.4: FileETag" PASS "$(echo "$fileetag" | awk '{print $2}')"
  else
    register_check "CIS 9.4: FileETag" WARN "Review ETag configuration"
  fi
else
  register_check "CIS 9.4: FileETag" WARN "Not configured (may expose inode)"
fi

# =============================================================================
# CIS 10.x - Denial of Service Mitigations
# =============================================================================
section "CIS 10.x - DoS Mitigations"

# CIS 10.1 - Ensure Timeout is set appropriately
timeout_dir=$(check_directive "Timeout")
if [[ -n "$timeout_dir" ]]; then
  value=$(echo "$timeout_dir" | awk '{print $2}')
  if [[ "$value" -le 60 ]]; then
    register_check "CIS 10.1: Timeout" PASS "$value seconds"
  else
    register_check "CIS 10.1: Timeout" WARN "$value seconds (consider <= 60)"
  fi
else
  register_check "CIS 10.1: Timeout" WARN "Not set (default: 60)"
fi

# CIS 10.2 - Ensure KeepAlive is enabled
keepalive=$(check_directive "KeepAlive")
if [[ -n "$keepalive" ]]; then
  if echo "$keepalive" | grep -qi "On"; then
    register_check "CIS 10.2: KeepAlive" PASS "On"
  else
    register_check "CIS 10.2: KeepAlive" WARN "Off (performance impact)"
  fi
fi

# CIS 10.3 - Ensure MaxKeepAliveRequests is set
max_keepalive=$(check_directive "MaxKeepAliveRequests")
if [[ -n "$max_keepalive" ]]; then
  value=$(echo "$max_keepalive" | awk '{print $2}')
  if [[ "$value" -ge 100 ]] && [[ "$value" -le 500 ]]; then
    register_check "CIS 10.3: MaxKeepAliveRequests" PASS "$value"
  else
    register_check "CIS 10.3: MaxKeepAliveRequests" WARN "$value (recommend 100-500)"
  fi
else
  register_check "CIS 10.3: MaxKeepAliveRequests" WARN "Not set (default: 100)"
fi

# CIS 10.4 - Ensure KeepAliveTimeout is set
keepalive_timeout=$(check_directive "KeepAliveTimeout")
if [[ -n "$keepalive_timeout" ]]; then
  value=$(echo "$keepalive_timeout" | awk '{print $2}')
  if [[ "$value" -le 15 ]]; then
    register_check "CIS 10.4: KeepAliveTimeout" PASS "$value seconds"
  else
    register_check "CIS 10.4: KeepAliveTimeout" WARN "$value seconds (consider <= 15)"
  fi
else
  register_check "CIS 10.4: KeepAliveTimeout" WARN "Not set (default: 5)"
fi

# CIS 10.5 - Ensure reqtimeout module is enabled
if check_module_enabled "reqtimeout"; then
  register_check "CIS 10.5: reqtimeout module" PASS "Enabled (slowloris protection)"
else
  register_check "CIS 10.5: reqtimeout module" WARN "Not enabled (slowloris vulnerability)"
fi

# =============================================================================
# Security Headers
# =============================================================================
section "Security Headers (OWASP)"

if check_module_enabled "headers"; then
  register_check "Headers module" PASS "Enabled"

  # Check security headers
  declare -A headers_check=(
    ["Strict-Transport-Security"]="HSTS"
    ["X-Frame-Options"]="Clickjacking protection"
    ["X-Content-Type-Options"]="MIME sniffing protection"
    ["Content-Security-Policy"]="XSS protection"
    ["X-XSS-Protection"]="Legacy XSS filter"
    ["Referrer-Policy"]="Referrer control"
    ["Permissions-Policy"]="Feature policy"
  )

  for header in "${!headers_check[@]}"; do
    if grep_apache_config "Header\s+(always\s+)?(set|append)\s+$header" | grep -qv "^\s*#"; then
      register_check "Header: $header" PASS "${headers_check[$header]}"
    else
      register_check "Header: $header" WARN "Not configured"
    fi
  done
else
  register_check "Security headers" WARN "headers module not enabled"
fi

# =============================================================================
# Service Status
# =============================================================================
section "Service Status"

if svc_is_active "$APACHE_SVC"; then
  register_check "Apache service" PASS "Running"
else
  register_check "Apache service" FAIL "Not running"
fi

if svc_is_enabled "$APACHE_SVC"; then
  register_check "Enabled at boot" PASS "Yes"
else
  register_check "Enabled at boot" WARN "No"
fi

# Configuration syntax check
if apache_config_test 2>&1 | grep -qi "Syntax OK"; then
  register_check "Configuration syntax" PASS "OK"
else
  register_check "Configuration syntax" FAIL "Errors detected"
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo "Reference: CIS Apache HTTP Server v2.4 Benchmark"
echo "Additional: NIST SP 800-53, PCI DSS v4.0, OWASP"

print_summary
exit "$EXIT_CODE"
