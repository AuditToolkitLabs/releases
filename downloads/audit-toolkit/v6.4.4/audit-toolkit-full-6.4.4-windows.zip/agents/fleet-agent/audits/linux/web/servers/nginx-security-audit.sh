#!/usr/bin/env bash
# NGINX Security Audit (CIS NGINX Benchmark v2.1.0 aligned)
# Coverage: CIS 1.x-5.x, NIST SP 800-53, PCI DSS, ISO 27001
#
# @elevation: root
# @elevation-reason: Reads /etc/nginx config files and checks SSL certificates
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

SCRIPT_NAME="${0##*/}"
SCRIPT_VERSION="5.0.0"
LOG_FILE="${LOG_FILE:-/var/log/nginx-security-audit.log}"
QUIET=false
VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
CFG=""

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" YELLOW="" GREEN="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  YELLOW=$'\e[0;33m'
  GREEN=$'\e[0;32m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local lvl="$1"
  shift || true
  local msg="$*"
  local ln
  ln="[$(_timestamp)] [$lvl] $msg"
  [[ "$QUIET" != "true" ]] && echo "$ln"
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || :
    echo "$ln" >>"$LOG_FILE" 2>/dev/null || :
  }
}
section() {
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $1${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
}
TOTAL=0
PASS=0
FAIL=0
WARN=0
SKIP=0
mark() {
  local n="$1" r="$2" m="${3:-}"
  ((++TOTAL))
  case "$r" in PASS)
    ((++PASS))
    echo -e " ${GREEN}[PASS]${NC} $n${m:+: $m}"
    ;;
  FAIL)
    ((++FAIL))
    EXIT_CODE=2
    echo -e " ${RED}[FAIL]${NC} $n${m:+: $m}"
    ;;
  WARN)
    ((++WARN))
    [[ $EXIT_CODE -lt 1 ]] && EXIT_CODE=1
    echo -e " ${YELLOW}[WARN]${NC} $n${m:+: $m}"
    ;;
  SKIP)
    ((++SKIP))
    echo -e " ${BLUE}[SKIP]${NC} $n${m:+: $m}"
    ;;
  esac
  [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] [$r] $n${m:+: $m}" >>"$LOG_FILE" 2>/dev/null || :
}

nginx_bin() { command -v nginx >/dev/null 2>&1; }
nginx_conf_dir() { if nginx -V 2>&1 | sed -n 's/.*--conf-path=\([^ ]*\).*/\1/p' | grep -q '/'; then dirname "$(nginx -V 2>&1 | sed -n 's/.*--conf-path=\([^ ]*\).*/\1/p' | head -n1)"; else echo /etc/nginx; fi; }
NGINX_CONF_DIR=""

# CIS 1.x - Initial Setup
cis_initial_setup() {
  section "CIS 1.x - Initial Setup"
  # CIS 1.1.1 - NGINX installed from trusted source
  if nginx_bin; then
    local ver
    ver=$(nginx -v 2>&1 | head -n1)
    mark "CIS 1.1.1 - NGINX installed" PASS "$ver"
    # Check if from package manager
    if pkg_installed nginx || pkg_installed nginx-full || pkg_installed nginx-common; then
      mark "CIS 1.1.2 - From package manager" PASS "system package"
    else mark "CIS 1.1.2 - From package manager" WARN "may be compiled"; fi
  else
    mark "CIS 1.1.1 - NGINX not installed" FAIL "missing"
    return 1
  fi

  # CIS 1.2.1 - Ensure NGINX runs as unprivileged user
  NGINX_CONF_DIR=$(nginx_conf_dir)
  local user
  user=$(grep -E '^\s*user\s+' "$NGINX_CONF_DIR/nginx.conf" 2>/dev/null | awk '{print $2}' | tr -d ';' || echo "")
  if [[ -n "$user" && "$user" != "root" ]]; then
    mark "CIS 1.2.1 - Run as non-root user" PASS "$user"
  else mark "CIS 1.2.1 - Run as non-root user" FAIL "user=$user (should not be root)"; fi

  # CIS 1.2.2 - NGINX user account locked
  if [[ -n "$user" ]] && id "$user" >/dev/null 2>&1; then
    local shell
    shell=$(getent passwd "$user" 2>/dev/null | cut -d: -f7 || echo "")
    if [[ "$shell" =~ (nologin|false) ]]; then
      mark "CIS 1.2.2 - User account locked" PASS "shell=$shell"
    else mark "CIS 1.2.2 - User account locked" WARN "shell=$shell"; fi
  else mark "CIS 1.2.2 - User account locked" SKIP "user not found"; fi

  # CIS 1.3.1 - Autoindex module disabled globally
  local autoindex_mod
  autoindex_mod=$(nginx -V 2>&1 | grep -c 'without-http_autoindex_module' || echo 0)
  if ((autoindex_mod > 0)); then
    mark "CIS 1.3.1 - Autoindex module" PASS "compiled out"
  else mark "CIS 1.3.1 - Autoindex module" WARN "enabled (check config)"; fi

  # CIS 1.4.1 - Config test passes
  if nginx -t 2>&1 | grep -q "syntax is ok"; then
    mark "CIS 1.4.1 - Config syntax valid" PASS "ok"
  else mark "CIS 1.4.1 - Config syntax valid" FAIL "errors"; fi
}

# CIS 2.x - Basic Configuration
cis_basic_config() {
  section "CIS 2.x - Basic Configuration"
  if nginx -T >/dev/null 2>&1; then CFG=$(nginx -T 2>/dev/null); else
    mark "Config dump" WARN "need root"
    return
  fi

  # CIS 2.1.1 - worker_processes set appropriately
  if echo "$CFG" | grep -qE 'worker_processes\s+(auto|[0-9]+)'; then
    local wp
    wp=$(echo "$CFG" | grep -oE 'worker_processes\s+(auto|[0-9]+)' | awk '{print $2}')
    mark "CIS 2.1.1 - worker_processes" PASS "$wp"
  else mark "CIS 2.1.1 - worker_processes" WARN "not set"; fi

  # CIS 2.1.2 - worker_connections reasonable
  if echo "$CFG" | grep -qE 'worker_connections\s+[0-9]+'; then
    local wc
    wc=$(echo "$CFG" | grep -oE 'worker_connections\s+[0-9]+' | awk '{print $2}' | head -1)
    if ((wc <= 65535)); then
      mark "CIS 2.1.2 - worker_connections" PASS "$wc"
    else
      mark "CIS 2.1.2 - worker_connections" WARN "high: $wc"
    fi
  else mark "CIS 2.1.2 - worker_connections" WARN "not set"; fi

  # CIS 2.2.1 - keepalive_timeout configured
  if echo "$CFG" | grep -qE 'keepalive_timeout\s+[0-9]+'; then
    local kt
    kt=$(echo "$CFG" | grep -oE 'keepalive_timeout\s+[0-9]+' | awk '{print $2}' | head -1)
    if ((kt <= 65)); then
      mark "CIS 2.2.1 - keepalive_timeout" PASS "${kt}s"
    else
      mark "CIS 2.2.1 - keepalive_timeout" WARN "high: ${kt}s"
    fi
  else mark "CIS 2.2.1 - keepalive_timeout" WARN "using default"; fi

  # CIS 2.2.2 - send_timeout configured
  if echo "$CFG" | grep -qE 'send_timeout\s+[0-9]+'; then
    mark "CIS 2.2.2 - send_timeout" PASS "configured"
  else mark "CIS 2.2.2 - send_timeout" WARN "using default"; fi

  # CIS 2.3.1 - client_body_timeout
  if echo "$CFG" | grep -qE 'client_body_timeout\s+[0-9]+'; then
    mark "CIS 2.3.1 - client_body_timeout" PASS "configured"
  else mark "CIS 2.3.1 - client_body_timeout" WARN "default (60s)"; fi

  # CIS 2.3.2 - client_header_timeout
  if echo "$CFG" | grep -qE 'client_header_timeout\s+[0-9]+'; then
    mark "CIS 2.3.2 - client_header_timeout" PASS "configured"
  else mark "CIS 2.3.2 - client_header_timeout" WARN "default (60s)"; fi

  # CIS 2.4.1 - Large client buffers
  if echo "$CFG" | grep -qE 'large_client_header_buffers\s+'; then
    local buf
    buf=$(echo "$CFG" | grep -oE 'large_client_header_buffers\s+[0-9]+\s+[0-9]+[kKmM]?' | head -1)
    mark "CIS 2.4.1 - large_client_header_buffers" PASS "${buf#large_client_header_buffers }"
  else mark "CIS 2.4.1 - large_client_header_buffers" WARN "default"; fi

  # CIS 2.4.2 - client_max_body_size
  if echo "$CFG" | grep -qE 'client_max_body_size\s+'; then
    local cms
    cms=$(echo "$CFG" | grep -oE 'client_max_body_size\s+[^;]+' | awk '{print $2}' | head -1)
    mark "CIS 2.4.2 - client_max_body_size" PASS "$cms"
  else mark "CIS 2.4.2 - client_max_body_size" WARN "default (1m)"; fi

  # CIS 2.5.1 - proxy_hide_header for sensitive headers
  if echo "$CFG" | grep -qE 'proxy_hide_header\s+(X-Powered-By|Server)'; then
    mark "CIS 2.5.1 - Hide backend headers" PASS "configured"
  else mark "CIS 2.5.1 - Hide backend headers" WARN "not set"; fi
}

# CIS 3.x - Logging
cis_logging() {
  section "CIS 3.x - Logging & Monitoring"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")

  # CIS 3.1 - access_log enabled
  if echo "$CFG" | grep -qE 'access_log\s+[^o]' && ! echo "$CFG" | grep -qE 'access_log\s+off'; then
    mark "CIS 3.1 - Access logging enabled" PASS "yes"
  else mark "CIS 3.1 - Access logging enabled" FAIL "disabled or off"; fi

  # CIS 3.2 - error_log configured
  if echo "$CFG" | grep -qE 'error_log\s+[^;]+'; then
    local el
    el=$(echo "$CFG" | grep -oE 'error_log\s+[^;]+' | awk '{print $2}' | head -1)
    mark "CIS 3.2 - Error log configured" PASS "$el"
  else mark "CIS 3.2 - Error log configured" WARN "not explicit"; fi

  # CIS 3.3 - error_log level appropriate
  local err_level
  err_level=$(echo "$CFG" | grep -oE 'error_log\s+[^ ]+\s+(debug|info|notice|warn|error|crit|alert|emerg)' | awk '{print $3}' | head -1 || echo "")
  if [[ -n "$err_level" ]]; then
    if [[ "$err_level" =~ ^(warn|error|crit|alert|emerg)$ ]]; then
      mark "CIS 3.3 - Error log level" PASS "$err_level"
    else mark "CIS 3.3 - Error log level" WARN "$err_level (verbose)"; fi
  else mark "CIS 3.3 - Error log level" PASS "default (error)"; fi

  # CIS 3.4 - log_format includes essential fields
  if echo "$CFG" | grep -qE 'log_format\s+'; then
    local has_fields=0
    echo "$CFG" | grep -qE 'remote_addr' && ((has_fields++)) || true
    echo "$CFG" | grep -qE 'request' && ((has_fields++)) || true
    echo "$CFG" | grep -qE 'status' && ((has_fields++)) || true
    echo "$CFG" | grep -qE 'http_user_agent' && ((has_fields++)) || true
    if ((has_fields >= 3)); then
      mark "CIS 3.4 - Custom log_format" PASS "essential fields present"
    else mark "CIS 3.4 - Custom log_format" WARN "missing essential fields"; fi
  else mark "CIS 3.4 - Custom log_format" WARN "using default combined"; fi

  # CIS 3.5 - Log file permissions
  local log_path
  log_path=$(echo "$CFG" | grep -oE 'access_log\s+/[^;]+' | awk '{print $2}' | head -1 || echo "")
  if [[ -n "$log_path" && -f "$log_path" ]]; then
    local perms
    perms=$(stat -c %a "$log_path" 2>/dev/null || echo "?")
    if [[ "$perms" == "640" || "$perms" == "600" ]]; then
      mark "CIS 3.5 - Log file permissions" PASS "$perms"
    else mark "CIS 3.5 - Log file permissions" WARN "$perms (recommend 640)"; fi
  else mark "CIS 3.5 - Log file permissions" SKIP "log file not found"; fi
}

# CIS 4.x - Information Disclosure
cis_info_disclosure() {
  section "CIS 4.x - Information Disclosure"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")

  # CIS 4.1.1 - server_tokens off
  if echo "$CFG" | grep -qE 'server_tokens\s+off'; then
    mark "CIS 4.1.1 - server_tokens off" PASS "set"
  else mark "CIS 4.1.1 - server_tokens off" FAIL "not set (version exposed)"; fi

  # CIS 4.1.2 - Remove Server header entirely (if possible)
  if echo "$CFG" | grep -qiE 'more_clear_headers.*Server' || echo "$CFG" | grep -qiE 'proxy_hide_header.*Server'; then
    mark "CIS 4.1.2 - Server header hidden" PASS "yes"
  else mark "CIS 4.1.2 - Server header hidden" WARN "still present"; fi

  # CIS 4.1.3 - X-Powered-By header removed
  if echo "$CFG" | grep -qiE 'proxy_hide_header.*X-Powered-By' || echo "$CFG" | grep -qiE 'fastcgi_hide_header.*X-Powered-By'; then
    mark "CIS 4.1.3 - X-Powered-By hidden" PASS "yes"
  else mark "CIS 4.1.3 - X-Powered-By hidden" WARN "may be exposed by backend"; fi

  # CIS 4.2.1 - autoindex off
  if echo "$CFG" | grep -qE 'autoindex\s+on'; then
    mark "CIS 4.2.1 - Directory listing (autoindex)" FAIL "enabled"
  else mark "CIS 4.2.1 - Directory listing (autoindex)" PASS "off"; fi

  # CIS 4.2.2 - Default error pages customized
  if echo "$CFG" | grep -qE 'error_page\s+[45][0-9][0-9]'; then
    mark "CIS 4.2.2 - Custom error pages" PASS "configured"
  else mark "CIS 4.2.2 - Custom error pages" WARN "using defaults"; fi

  # CIS 4.3.1 - Disable TRACE/TRACK methods
  if echo "$CFG" | grep -qiE 'limit_except.*GET.*POST.*HEAD' || echo "$CFG" | grep -qiE 'if.*request_method.*(TRACE|TRACK).*return'; then
    mark "CIS 4.3.1 - TRACE/TRACK disabled" PASS "blocked"
  else mark "CIS 4.3.1 - TRACE/TRACK disabled" WARN "not explicitly blocked"; fi
}

# CIS 5.x - Request Filtering & TLS
cis_request_filtering() {
  section "CIS 5.x - Request Filtering & TLS"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")

  # CIS 5.1.1 - limit_req_zone defined
  if echo "$CFG" | grep -qE 'limit_req_zone\s+'; then
    mark "CIS 5.1.1 - Rate limiting zone" PASS "configured"
  else mark "CIS 5.1.1 - Rate limiting zone" WARN "not set"; fi

  # CIS 5.1.2 - limit_req applied
  if echo "$CFG" | grep -qE 'limit_req\s+zone='; then
    mark "CIS 5.1.2 - Rate limiting applied" PASS "yes"
  else mark "CIS 5.1.2 - Rate limiting applied" WARN "not applied"; fi

  # CIS 5.1.3 - limit_conn_zone for connection limiting
  if echo "$CFG" | grep -qE 'limit_conn_zone\s+'; then
    mark "CIS 5.1.3 - Connection limiting zone" PASS "configured"
  else mark "CIS 5.1.3 - Connection limiting zone" WARN "not set"; fi

  # CIS 5.2.1 - SSL/TLS configured
  if echo "$CFG" | grep -qiE 'ssl_protocols'; then
    mark "CIS 5.2.1 - SSL directives" PASS "present"
  else mark "CIS 5.2.1 - SSL directives" WARN "not configured"; fi

  # CIS 5.2.2 - SSLv2/v3 disabled
  if echo "$CFG" | grep -qiE 'ssl_protocols.*(SSLv2|SSLv3)'; then
    mark "CIS 5.2.2 - SSLv2/v3 disabled" FAIL "legacy protocol enabled"
  else mark "CIS 5.2.2 - SSLv2/v3 disabled" PASS "ok"; fi

  # CIS 5.2.3 - TLSv1.0/1.1 deprecated
  if echo "$CFG" | grep -qiE 'ssl_protocols.*TLSv1[^.]'; then
    mark "CIS 5.2.3 - TLSv1.0/1.1 disabled" WARN "deprecated protocol may be enabled"
  else mark "CIS 5.2.3 - TLSv1.0/1.1 disabled" PASS "ok"; fi

  # CIS 5.2.4 - TLSv1.2+ required
  if echo "$CFG" | grep -qiE 'ssl_protocols.*(TLSv1\.2|TLSv1\.3)'; then
    mark "CIS 5.2.4 - TLSv1.2+ enabled" PASS "modern protocols"
  else mark "CIS 5.2.4 - TLSv1.2+ enabled" WARN "not explicitly set"; fi

  # CIS 5.2.5 - ssl_prefer_server_ciphers on
  if echo "$CFG" | grep -qiE 'ssl_prefer_server_ciphers\s+on'; then
    mark "CIS 5.2.5 - Server cipher preference" PASS "on"
  else mark "CIS 5.2.5 - Server cipher preference" WARN "off"; fi

  # CIS 5.2.6 - Strong cipher suites
  if echo "$CFG" | grep -qE 'ssl_ciphers\s+'; then
    local ciphers
    ciphers=$(echo "$CFG" | grep -oE "ssl_ciphers\s+'?[^;']+" | head -1)
    if echo "$ciphers" | grep -qiE '(ECDHE|DHE).*AES.*GCM'; then
      mark "CIS 5.2.6 - Strong cipher suites" PASS "AEAD ciphers"
    elif echo "$ciphers" | grep -qiE '(MD5|RC4|DES|EXPORT|NULL)'; then
      mark "CIS 5.2.6 - Strong cipher suites" FAIL "weak ciphers present"
    else mark "CIS 5.2.6 - Strong cipher suites" WARN "verify cipher strength"; fi
  else mark "CIS 5.2.6 - Strong cipher suites" WARN "using defaults"; fi

  # CIS 5.2.7 - OCSP stapling
  if echo "$CFG" | grep -qiE 'ssl_stapling\s+on'; then
    mark "CIS 5.2.7 - OCSP stapling" PASS "enabled"
  else mark "CIS 5.2.7 - OCSP stapling" WARN "disabled"; fi

  # CIS 5.2.8 - ssl_session_tickets off (for PFS)
  if echo "$CFG" | grep -qiE 'ssl_session_tickets\s+off'; then
    mark "CIS 5.2.8 - Session tickets disabled" PASS "PFS maintained"
  else mark "CIS 5.2.8 - Session tickets disabled" WARN "may affect PFS"; fi

  # CIS 5.2.9 - HSTS enabled
  if echo "$CFG" | grep -qiE 'Strict-Transport-Security'; then
    mark "CIS 5.2.9 - HSTS header" PASS "configured"
  else mark "CIS 5.2.9 - HSTS header" WARN "missing"; fi
}

# Security Headers Check
security_headers() {
  section "Security Headers (OWASP)"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")
  local headers=(
    "X-Frame-Options:CLICKJACKING"
    "X-Content-Type-Options:MIME-sniffing"
    "Content-Security-Policy:XSS/injection"
    "Referrer-Policy:Info leakage"
    "Permissions-Policy:Browser features"
    "X-XSS-Protection:Legacy XSS (deprecated)"
  )
  for h in "${headers[@]}"; do
    local name="${h%%:*}" desc="${h#*:}"
    if echo "$CFG" | grep -qi "$name"; then
      mark "Header: $name ($desc)" PASS "configured"
    else mark "Header: $name ($desc)" WARN "missing"; fi
  done
}

# File & Directory Permissions
file_permissions() {
  section "File & Directory Permissions (CIS 1.5)"
  local conf_dir
  conf_dir=$(nginx_conf_dir)

  # CIS 1.5.1 - Config directory permissions
  if [[ -d "$conf_dir" ]]; then
    local perms owner
    perms=$(stat -c %a "$conf_dir" 2>/dev/null || echo "?")
    owner=$(stat -c %U:%G "$conf_dir" 2>/dev/null || echo "?")
    if [[ "$perms" =~ ^[0-7][0-5][0-5]$ ]]; then
      mark "CIS 1.5.1 - Config dir permissions" PASS "$perms ($owner)"
    else mark "CIS 1.5.1 - Config dir permissions" WARN "$perms (recommend 755)"; fi
  fi

  # CIS 1.5.2 - nginx.conf permissions
  local main_conf="$conf_dir/nginx.conf"
  if [[ -f "$main_conf" ]]; then
    local perms
    perms=$(stat -c %a "$main_conf" 2>/dev/null || echo "?")
    if [[ "$perms" == "644" || "$perms" == "640" || "$perms" == "600" ]]; then
      mark "CIS 1.5.2 - nginx.conf permissions" PASS "$perms"
    else mark "CIS 1.5.2 - nginx.conf permissions" WARN "$perms (recommend 644)"; fi
  fi

  # CIS 1.5.3 - SSL key permissions
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")
  local keys
  keys=$(echo "$CFG" | grep -oE 'ssl_certificate_key\s+[^;]+' | awk '{print $2}' | sort -u || echo "")
  while IFS= read -r k; do
    [[ -z "$k" ]] && continue
    if [[ -f "$k" ]]; then
      local p
      p=$(stat -c %a "$k" 2>/dev/null || echo "?")
      if [[ "$p" == "600" || "$p" == "400" ]]; then
        mark "CIS 1.5.3 - Key $(basename "$k")" PASS "perms $p"
      else mark "CIS 1.5.3 - Key $(basename "$k")" FAIL "perms $p (require 600)"; fi
    else mark "CIS 1.5.3 - Key $(basename "$k")" FAIL "not found"; fi
  done <<<"$keys"
}

# Certificate expiry check
cert_check() {
  section "Certificate Validity"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")
  if ! command -v openssl >/dev/null 2>&1; then
    mark "Certificates" SKIP "no openssl"
    return
  fi

  local certs
  certs=$(echo "$CFG" | grep -oE 'ssl_certificate\s+[^;]+' | awk '{print $2}' | grep -v '_key' | sort -u)
  if [[ -z "$certs" ]]; then
    mark "SSL Certificates" WARN "none found"
    return
  fi

  while IFS= read -r c; do
    [[ -z "$c" ]] && continue
    if [[ ! -f "$c" ]]; then
      mark "Cert $(basename "$c")" FAIL "file not found"
      continue
    fi
    local end
    end=$(openssl x509 -in "$c" -noout -enddate 2>/dev/null | cut -d= -f2 || true)
    if [[ -n "$end" ]]; then
      local exp now days
      exp=$(date -d "$end" +%s 2>/dev/null || echo 0)
      now=$(date +%s)
      days=$(((exp - now) / 86400))
      if ((days < 0)); then
        mark "Cert $(basename "$c")" FAIL "EXPIRED"
      elif ((days < 14)); then
        mark "Cert $(basename "$c")" FAIL "expires in $days days"
      elif ((days < 30)); then
        mark "Cert $(basename "$c")" WARN "expires in $days days"
      else mark "Cert $(basename "$c")" PASS "$days days remaining"; fi
    fi
    # Check key strength
    local key_bits
    key_bits=$(openssl x509 -in "$c" -noout -text 2>/dev/null | grep -oE 'RSA Public-Key: \([0-9]+' | grep -oE '[0-9]+' || echo "0")
    if ((key_bits >= 2048)); then
      mark "Cert $(basename "$c") key strength" PASS "${key_bits} bits"
    elif ((key_bits > 0)); then
      mark "Cert $(basename "$c") key strength" FAIL "${key_bits} bits (require 2048+)"
    fi
  done <<<"$certs"
}

# Service status
service_status() {
  section "Service Status"
  if svc_is_active nginx; then
    mark "NGINX service" PASS "running"
  else mark "NGINX service" FAIL "not running"; fi

  if svc_is_enabled nginx; then
    mark "Enabled at boot" PASS "yes"
  else mark "Enabled at boot" WARN "no"; fi

  if command -v ss >/dev/null 2>&1; then
    local ports
    ports=$(ss -tlnp 2>/dev/null | grep nginx | awk '{print $4}' | grep -oE ':[0-9]+$' | tr '\n' ' ' || echo "")
    if [[ -n "$ports" ]]; then
      mark "Listening ports" PASS "$ports"
    else mark "Listening ports" WARN "none detected"; fi
  fi
}

# Virtual hosts summary
vhosts() {
  section "Virtual Hosts Summary"
  [[ -z "${CFG:-}" ]] && CFG=$(nginx -T 2>/dev/null || echo "")
  if [[ -n "$CFG" ]]; then
    local count
    count=$(echo "$CFG" | grep -cE '^\s*server\s*\{' || echo 0)
    mark "Server blocks" PASS "$count"
    local ssl_count
    ssl_count=$(echo "$CFG" | grep -cE 'listen.*ssl' || echo 0)
    mark "SSL-enabled blocks" PASS "$ssl_count"
  else
    if [[ -d /etc/nginx/sites-enabled ]]; then
      local c
      c=$(find /etc/nginx/sites-enabled -type f -o -type l 2>/dev/null | wc -l)
      mark "Enabled sites" PASS "$c"
    else mark "Virtual hosts" SKIP "cannot determine"; fi
  fi
}

summary() {
  echo
  echo -e "${BOLD}NGINX CIS SECURITY AUDIT SUMMARY${NC}"
  printf ' PASSED=%d WARN=%d FAIL=%d SKIP=%d TOTAL=%d\n' "$PASS" "$WARN" "$FAIL" "$SKIP" "$TOTAL"
  echo
  echo "Reference: CIS NGINX Benchmark v2.1.0, NIST SP 800-53, OWASP"
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
NGINX Security Audit - CIS NGINX Benchmark v2.1.0 aligned

Options:
  -l, --log FILE     Log file (default: $LOG_FILE)
  -q, --quiet        Suppress stdout
  -v, --verbose      Debug output
      --no-color     Disable color output
  -h, --help         Show this help
      --version      Show version

CIS Sections Covered:
  1.x - Initial Setup (install, user, modules)
  2.x - Basic Configuration (workers, timeouts, buffers)
  3.x - Logging (access/error logs, formats)
  4.x - Information Disclosure (tokens, headers, errors)
  5.x - Request Filtering & TLS (rate limits, SSL/TLS config)
EOF
}
version() { echo "$SCRIPT_NAME v$SCRIPT_VERSION (CIS NGINX Benchmark aligned)"; }

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="$2"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done

  setup_colors
  [[ "$VERBOSE" == "true" ]] && _log INFO "Verbose mode enabled"
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"

  cis_initial_setup || {
    summary
    exit "$EXIT_CODE"
  }
  cis_basic_config
  cis_logging
  cis_info_disclosure
  cis_request_filtering
  security_headers
  file_permissions
  cert_check
  service_status
  vhosts
  summary
  exit "$EXIT_CODE"
}
main "$@"
