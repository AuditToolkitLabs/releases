#!/usr/bin/env bash
# Portable PHP / PHP-FPM Security Audit (multi-OS)
# Runs on Debian/Ubuntu, RHEL/CentOS/Alma/Rocky, Amazon Linux, SUSE.
#
# @elevation: partial
# @elevation-reason: PHP-FPM pool configs and php.ini may need root for access
#
set -euo pipefail

# Source standard library shims
. "$(dirname "$0")/../../../../lib/distro.sh"
. "$(dirname "$0")/../../../../lib/svc.sh"

SCRIPT_NAME="${0##*/}"; SCRIPT_VERSION="3.1.0"
LOG_FILE=""; QUIET=false; VERBOSE=false; NO_COLOR=false; EXIT_CODE=0
have() { command -v "$1" >/dev/null 2>&1; }
_timestamp(){ date '+%Y-%m-%d %H:%M:%S'; }
log(){ [[ "$QUIET" == "false" ]] && echo "[$(_timestamp)] $*"; [[ -n "$LOG_FILE" ]] && echo "[$(_timestamp)] $*" >>"$LOG_FILE" || true; }
section(){ echo; echo "================== $1 =================="; [[ -n "$LOG_FILE" ]] && { echo >>"$LOG_FILE"; echo "==== $1 ==== " >>"$LOG_FILE"; } || :; }

# Check registry
CHECK_NAMES=(); CHECK_RESULTS=(); CHECK_MESSAGES=(); TOTAL_CHECKS=0; PASSED=0; FAILED=0; WARN=0; SKIPPED=0
_register(){
  local n="$1" r="$2" m="${3:-}"; CHECK_NAMES+=("$n"); CHECK_RESULTS+=("$r"); CHECK_MESSAGES+=("$m"); ((++TOTAL_CHECKS))
  case "$r" in PASS) ((++PASSED));; FAIL) ((++FAILED)); EXIT_CODE=2;; WARN) ((++WARN)); [[ $EXIT_CODE -eq 0 ]] && EXIT_CODE=1;; SKIP) ((++SKIPPED));; esac
  log "[$r] $n${m:+: $m}"
}
check_root_register(){ local msg="${1:-Full results require root}"; if [[ $EUID -ne 0 ]]; then _register "Root privileges" WARN "$msg"; else _register "Root privileges" PASS "root"; fi; }

usage(){ cat <<EOF
Usage: $SCRIPT_NAME [--log FILE] [--quiet] [--verbose] [--no-color]
EOF
}

parse_cli(){ while [[ $# -gt 0 ]]; do case "$1" in
  -l|--log) LOG_FILE="${2:-}"; shift 2;;
  -q|--quiet) QUIET=true; shift;;
  -v|--verbose) VERBOSE=true; shift;;
  --no-color) NO_COLOR=true; shift;;
  -h|--help) usage; exit 0;;
  --version) echo "$SCRIPT_NAME $SCRIPT_VERSION"; exit 0;;
  *) echo "Unknown option: $1" >&2; usage; exit 1;; esac; done }

# OS-aware paths
detect_php_conf_roots(){
  # Debian/Ubuntu: /etc/php/<ver>/{cli,fpm}
  # RHEL-like: /etc/php-fpm.d (pools), /etc/php.ini
  PHP_CONF_BASES=(
    /etc/php
    /etc
  )
}

find_fpm_pool_confs(){
  # Print pool config files
  local bases=(/etc/php /etc)
  for b in "${bases[@]}"; do
    if [[ -d "$b" ]]; then
      find "$b" -type f \( -path "*/fpm/pool.d/*.conf" -o -path "*/php-fpm.d/*.conf" \) 2>/dev/null || true
    fi
  done | sort -u
}

list_php_fpm_services(){
  if is_systemd; then
    systemctl list-units --type=service --all 2>/dev/null | awk '{print $1}' | grep -E '(^|-)php.*fpm(\.service)?$|^php-fpm(\.service)?$' || true
  elif is_openrc; then
    rc-status --all 2>/dev/null | grep -E 'php.*fpm|php-fpm' | awk '{print $1}' || printf "php-fpm\n"
  else
    printf "php-fpm\nphp-fpm.service"
  fi
}

audit_host(){
  section "Host"
  _register "Hostname" PASS "$(hostname -f 2>/dev/null || hostname)"
  check_root_register "Run as root for full results"
  for t in php systemctl grep awk find stat; do
    if have "$t"; then _register "Tool: $t" PASS "Available"; else _register "Tool: $t" WARN "Not found"; fi
  done
}

audit_php_cli(){
  section "PHP CLI"
  if ! have php; then _register "PHP installed" FAIL "php binary not found"; return; fi
  _register "PHP installed" PASS "$(php -v | head -1)"
  local ini; ini=$(php --ini 2>/dev/null | awk -F': ' '/Loaded Configuration/{print $2}')
  if [[ -n "$ini" && "$ini" != "(none)" ]]; then _register "CLI php.ini" PASS "Loaded: $ini"; else _register "CLI php.ini" WARN "No php.ini loaded"; fi
  # selected security settings (CLI context)
  local kv v
  for kv in expose_php display_errors allow_url_include allow_url_fopen log_errors; do
    v=$(php -r "echo ini_get('$kv');" 2>/dev/null || true)
    case "$kv:$v" in
      expose_php:1|expose_php:On) _register "expose_php" WARN "Enabled";;
      display_errors:1|display_errors:On) _register "display_errors" WARN "Enabled";;
      allow_url_include:1|allow_url_include:On) _register "allow_url_include" FAIL "ENABLED";;
      allow_url_fopen:1|allow_url_fopen:On) _register "allow_url_fopen" WARN "Enabled";;
      log_errors:1|log_errors:On) _register "log_errors" PASS "Enabled";;
      *) _register "$kv" PASS "${v:-Off}";;
    esac
  done
}

audit_fpm_services(){
  section "PHP-FPM Services"
  local any=false
  while read -r svc; do [[ -z "$svc" ]] && continue; any=true
    if svc_is_active "$svc"; then _register "Service: $svc" PASS "Running"; else _register "Service: $svc" WARN "Not running"; fi
    if svc_is_enabled "$svc"; then _register "Enabled: $svc" PASS "At boot"; else _register "Enabled: $svc" WARN "Not enabled"; fi
  done < <(list_php_fpm_services)
  [[ "$any" == false ]] && _register "PHP-FPM services" WARN "No services detected"
}

audit_fpm_pools(){
  section "PHP-FPM Pools"
  local pools; pools=$(find_fpm_pool_confs)
  if [[ -z "$pools" ]]; then _register "FPM pools" WARN "No pool configs found"; return; fi
  local count=0
  while read -r conf; do [[ -z "$conf" ]] && continue; ((count++))
    local name; name=$(grep -E '^\s*\[.+\]' "$conf" 2>/dev/null | head -1 | tr -d '[]' || echo unknown)
    # user/group
    local user group; user=$(awk -F= '/^\s*user\s*=/{print $2}' "$conf" | tail -1 | xargs);
    group=$(awk -F= '/^\s*group\s*=/{print $2}' "$conf" | tail -1 | xargs)
    if [[ "$user" == "root" ]]; then _register "Pool $name user" FAIL "root"; elif [[ -n "$user" ]]; then _register "Pool $name user" PASS "user=$user"; fi
    # socket mode
    local lmode; lmode=$(awk -F= '/^\s*listen\.mode\s*=/{print $2}' "$conf" | tail -1 | xargs)
    if [[ -n "$lmode" ]]; then
      case "$lmode" in 0777|0666) _register "Pool $name socket" WARN "Mode $lmode (permissive)";; *) _register "Pool $name socket" PASS "Mode $lmode";; esac
    fi
    # dangerous overrides
    local val
    val=$(grep -E '^\s*php_(admin_)?(value|flag)\[allow_url_include\]' "$conf" 2>/dev/null | tail -1 | cut -d= -f2 | xargs || true)
    [[ -n "$val" && "$val" =~ ^(1|on|true)$ ]] && _register "Pool $name allow_url_include" FAIL "Enabled in pool"
    val=$(grep -E '^\s*php_(admin_)?(value|flag)\[display_errors\]' "$conf" 2>/dev/null | tail -1 | cut -d= -f2 | xargs || true)
    [[ -n "$val" && "$val" =~ ^(1|on|true)$ ]] && _register "Pool $name display_errors" WARN "Enabled in pool"
  done < <(echo "$pools")
  _register "FPM pool count" PASS "$count pool(s)"
}

audit_fpm_php_ini(){
  section "FPM php.ini"
  local inis
  inis=$(find /etc -type f \( -path '*/fpm/php.ini' -o -name 'php.ini' \) 2>/dev/null | sort -u)
  if [[ -z "$inis" ]]; then _register "FPM php.ini" WARN "No php.ini files located"; return; fi
  while read -r ini; do [[ -z "$ini" ]] && continue
    local expose display
    expose=$(awk -F= '/^\s*expose_php\s*=/{print $2}' "$ini" | tail -1 | xargs)
    display=$(awk -F= '/^\s*display_errors\s*=/{print $2}' "$ini" | tail -1 | xargs)
    if echo "${expose,,}" | grep -qE 'off|0'; then _register "expose_php ($ini)" PASS "Disabled"; else _register "expose_php ($ini)" WARN "May be enabled"; fi
    if echo "${display,,}" | grep -qE 'off|0'; then _register "display_errors ($ini)" PASS "Disabled"; else _register "display_errors ($ini)" WARN "May be enabled"; fi
  done < <(echo "$inis")
}

audit_sockets(){
  section "FPM Sockets"
  local dirs=(/run/php /var/run/php /var/run/php-fpm /run/php-fpm /tmp)
  local found=false
  for d in "${dirs[@]}"; do
    [[ -d "$d" ]] || continue
    while read -r s; do [[ -z "$s" ]] && continue; found=true
      local perms owner; perms=$(stat -c '%a' "$s" 2>/dev/null || stat -f '%Lp' "$s" 2>/dev/null || echo unknown)
      owner=$(stat -c '%U:%G' "$s" 2>/dev/null || echo unknown)
      case "$perms" in 777|666) _register "Socket $(basename "$s")" WARN "Perms $perms (too open)";; *) _register "Socket $(basename "$s")" PASS "Perms $perms ($owner)";; esac
    done < <(find "$d" -maxdepth 1 -type s -name '*.sock' -o -name 'php*fpm*.sock' 2>/dev/null || true)
  done
  [[ "$found" == false ]] && _register "PHP-FPM sockets" WARN "No sockets found (may use TCP)"
}

audit_opcache(){
  section "OPcache"
  if ! have php; then _register "OPcache" SKIP "php not present"; return; fi
  if php -m 2>/dev/null | grep -qi 'Zend OPcache'; then
    _register "OPcache loaded" PASS "Active"
    local vts; vts=$(php -r "echo ini_get('opcache.validate_timestamps');" 2>/dev/null || true)
    if [[ "$vts" == "0" ]]; then
      _register "opcache.validate_timestamps" PASS "Disabled (prod)"
    else
      _register "opcache.validate_timestamps" WARN "Enabled (dev)"
    fi
  else
    _register "OPcache loaded" WARN "Not loaded"
  fi
}

print_summary(){
  echo; echo "==== PHP / PHP-FPM AUDIT SUMMARY ===="
  echo " Host: $(hostname -f 2>/dev/null || hostname)"
  echo " Checks: $TOTAL_CHECKS | Passed: $PASSED | Failed: $FAILED | Warnings: $WARN | Skipped: $SKIPPED"
  if (( FAILED>0 )); then echo " Status: FAILED"; elif (( WARN>0 )); then echo " Status: PASSED WITH WARNINGS"; elif (( PASSED==0 )); then echo " Status: SKIPPED"; else echo " Status: PASSED"; fi
}

main(){ parse_cli "$@"; section "START"; log "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  audit_host
  audit_php_cli
  audit_fpm_services
  audit_fpm_pools
  audit_fpm_php_ini
  audit_sockets
  audit_opcache
  print_summary; exit "$EXIT_CODE"; }
main "$@"
