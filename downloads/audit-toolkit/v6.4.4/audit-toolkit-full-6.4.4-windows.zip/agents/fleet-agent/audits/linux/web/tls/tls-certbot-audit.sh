#!/usr/bin/env bash
# TLS/Certbot Audit (portable)
#
# @elevation: partial
# @elevation-reason: Let's Encrypt certs in /etc/letsencrypt need root
#
set -euo pipefail
# shellcheck source-path=SCRIPTDIR
# shellcheck disable=SC1091
# shellcheck source=../../_lib/portable.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/../../_lib" && pwd)/portable.sh"

readonly SCRIPT_NAME="${0##*/}"
readonly SCRIPT_VERSION="4.0.0"
readonly DEFAULT_LOG_FILE="/var/log/security-audit/${SCRIPT_NAME%.sh}.log"
readonly LETSENCRYPT_DIR="/etc/letsencrypt"
readonly CERT_WARN_DAYS=30
readonly CERT_CRIT_DAYS=7

LOG_FILE="$DEFAULT_LOG_FILE"
QUIET=false
VERBOSE=false
VERY_VERBOSE=false
NO_COLOR=false
EXIT_CODE=0
SITE_DOMAIN="${SITE_DOMAIN:-}"

setup_colors() { if [[ "$NO_COLOR" == "true" || ! -t 1 ]]; then RED="" GREEN="" YELLOW="" BLUE="" CYAN="" BOLD="" NC=""; else
  RED=$'\e[0;31m'
  GREEN=$'\e[0;32m'
  YELLOW=$'\e[0;33m'
  BLUE=$'\e[0;34m'
  CYAN=$'\e[0;36m'
  BOLD=$'\e[1m'
  NC=$'\e[0m'
fi; }
_timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
_log() {
  local level="$1"
  shift || true
  local msg="$*"
  local ts line
  ts="$(_timestamp)"
  printf -v line '[%s] [%s] %s' "$ts" "$level" "$msg"
  [[ -n "$LOG_FILE" ]] && { echo "$line" >>"$LOG_FILE" 2>/dev/null || :; }
  if [[ "$QUIET" != "true" ]]; then case "$level" in ERROR | WARN) echo "$line" >&2 ;; DEBUG) [[ "$VERBOSE" == "true" ]] && echo "$line" ;; TRACE) [[ "$VERY_VERBOSE" == "true" ]] && echo "$line" ;; *) echo "$line" ;; esac fi
}
_dbg() { [[ "$VERBOSE" == "true" ]] && _log DEBUG "$*" || :; }
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0
SKIPPED_CHECKS=0
register_check() {
  local name="$1" result="$2" message="${3:-}"
  TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
  case "$result" in
    PASS)
      PASSED_CHECKS=$((PASSED_CHECKS + 1))
      echo -e " ${GREEN}[PASS]${NC} $name${message:+: $message}"
      ;;
    FAIL)
      FAILED_CHECKS=$((FAILED_CHECKS + 1))
      EXIT_CODE=2
      echo -e " ${RED}[FAIL]${NC}  $name${message:+: $message}"
      ;;
    WARN)
      WARNING_CHECKS=$((WARNING_CHECKS + 1))
      [[ "$EXIT_CODE" -lt 1 ]] && EXIT_CODE=1
      echo -e " ${YELLOW}[WARN]${NC} $name${message:+: $message}"
      ;;
    SKIP)
      SKIPPED_CHECKS=$((SKIPPED_CHECKS + 1))
      echo -e " ${BLUE}[SKIP]${NC} $name${message:+: $message}"
      ;;
  esac
  [[ -n "$LOG_FILE" ]] && { echo "[$(_timestamp)] [$result] $name${message:+: $message}" >>"$LOG_FILE" 2>/dev/null || :; }
}
section() {
  local title="$1"
  echo
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  echo -e "${BOLD}${CYAN} $title${NC}"
  echo -e "${BOLD}${CYAN}============================================================${NC}"
  [[ -n "$LOG_FILE" ]] && {
    echo
    echo "=== $title ==="
  } >>"$LOG_FILE" 2>/dev/null || :
  _dbg "section: $title"
}

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]
TLS/SSL and ACME audit (portable). Use --domain or SITE_DOMAIN to check a live cert.
  -l, --log FILE         Write log (default: $DEFAULT_LOG_FILE)
  -q, --quiet            Suppress stdout (log only)
  -v, --verbose          DEBUG
  -vv, --very-verbose    TRACE
  -d, --domain DOMAIN    Check live certificate for DOMAIN (443)
      --no-color         Disable ANSI colors
  -h, --help             Help
      --version          Version
EOF
}
version() { echo "$SCRIPT_NAME version $SCRIPT_VERSION"; }

audit_cert_client() {
  section "ACME Client"
  if command -v certbot >/dev/null 2>&1; then
    register_check "Certbot" PASS "$(certbot --version 2>&1 || echo unknown)"
  elif command -v acme.sh >/dev/null 2>&1; then
    register_check "acme.sh" PASS "$(acme.sh --version 2>&1 | head -1 || echo unknown)"
  else register_check "ACME client" WARN "not installed (install via your distro)"; fi
}

audit_managed_certs() {
  section "Managed Certificates"
  if command -v certbot >/dev/null 2>&1; then
    local out
    if out=$(certbot certificates 2>&1); then
      local count
      count=$(grep -c "Certificate Name" <<<"$out" || echo 0)
      if [[ "$count" -gt 0 ]]; then
        register_check "Managed certificates" PASS "$count found"
      else
        register_check "Managed certificates" SKIP "none found"
      fi
      [[ "$VERBOSE" == "true" ]] && while IFS= read -r l; do _log DEBUG " $l"; done <<<"$out"
    else register_check "certbot certificates" WARN "unable to list (maybe require root)"; fi
  elif command -v acme.sh >/dev/null 2>&1; then
    local home_dir
    home_dir=$(getent passwd root 2>/dev/null | cut -d: -f6 || echo /root)
    local acme_dir="${home_dir}/.acme.sh"
    if [[ -d "$acme_dir" ]]; then
      local n
      n=$(find "$acme_dir" -maxdepth 1 -type d -name "*.*" 2>/dev/null | wc -l || echo 0)
      if [[ "$n" -gt 0 ]]; then
        register_check "acme.sh certs" PASS "$n found"
      else
        register_check "acme.sh certs" SKIP "none found"
      fi
    else register_check "acme.sh certs" SKIP "not found"; fi
  else register_check "Managed certificates" SKIP "no ACME client"; fi
}

audit_renewal_schedule() {
  section "Certificate Renewal Schedule"
  local sched
  if sched=$(has_timer_or_cron certbot) || sched=$(has_timer_or_cron "acme.sh"); then
    if [[ "$sched" == "systemd" ]]; then
      register_check "auto renewal" PASS "systemd timer present"
    else
      register_check "auto renewal" PASS "cron present"
    fi
  else register_check "auto renewal" WARN "no timer/cron found"; fi
}

audit_letsencrypt_perms() {
  section "Let's Encrypt Directory Permissions"
  if [[ ! -d "$LETSENCRYPT_DIR" ]]; then
    register_check "Let's Encrypt dir" SKIP "not found ($LETSENCRYPT_DIR)"
    return 0
  fi
  local mode owner
  mode=$(stat -c '%a' "$LETSENCRYPT_DIR" 2>/dev/null || echo "?")
  owner=$(stat -c '%U:%G' "$LETSENCRYPT_DIR" 2>/dev/null || echo "?:?")
  register_check "dir perms" PASS "mode=$mode owner=$owner"
  local subs=(live archive renewal accounts)
  local s sm
  for s in "${subs[@]}"; do [[ -d "$LETSENCRYPT_DIR/$s" ]] && {
    sm=$(stat -c '%a' "$LETSENCRYPT_DIR/$s" 2>/dev/null || echo "?")
    register_check "$s/ perms" PASS "$sm"
  }; done
  local pem
  while IFS= read -r -d '' pem; do
    local pm fn
    pm=$(stat -c '%a' "$pem" 2>/dev/null || echo "?")
    fn=$(basename "$pem")
    if [[ "$fn" == privkey* ]]; then
      if [[ "$pm" == "600" ]]; then
        register_check "privkey perms" PASS "$pm"
      else
        register_check "privkey perms" WARN "$pm (should be 600)"
      fi
    fi
  done < <(find "$LETSENCRYPT_DIR" -maxdepth 3 -type f -name "*.pem" -print0 2>/dev/null | head -z -n 20)
}

audit_local_certs_expiry() {
  section "Local Certificate Files Expiry"
  if [[ -d "$LETSENCRYPT_DIR/live" ]]; then
    while IFS= read -r -d '' d; do
      local cert_file="$d/cert.pem" domain
      domain=$(basename "$d")
      if [[ -f "$cert_file" ]]; then
        local days
        days=$(days_until_expiry_pem "$cert_file")
        if [[ "$days" == "unknown" ]]; then register_check "$domain expiry" WARN "unknown"; elif ((days < 0)); then
          register_check "$domain expiry" FAIL "EXPIRED"
        elif ((days < CERT_CRIT_DAYS)); then register_check "$domain expiry" FAIL "$days days (CRITICAL)"; elif ((days < CERT_WARN_DAYS)); then register_check "$domain expiry" WARN "$days days"; else register_check "$domain expiry" PASS "$days days"; fi
      fi
    done < <(find "$LETSENCRYPT_DIR/live" -mindepth 1 -maxdepth 1 -type d -print0 2>/dev/null)
  else register_check "Let's Encrypt live" SKIP "not present"; fi
}

audit_live_certificate() {
  section "Live Certificate Check"
  [[ -z "$SITE_DOMAIN" ]] && {
    register_check "live cert" SKIP "no domain (use --domain or SITE_DOMAIN)"
    return 0
  }
  if ! command -v openssl >/dev/null 2>&1; then
    register_check "openssl" FAIL "not available"
    return 0
  fi
  local info not_after expiry_epoch current_epoch days_left
  info=$(echo | openssl s_client -servername "$SITE_DOMAIN" -connect "${SITE_DOMAIN}:443" 2>/dev/null | openssl x509 -noout -dates -issuer -subject 2>/dev/null || true)
  [[ -z "$info" ]] && {
    register_check "fetch cert ($SITE_DOMAIN)" WARN "unable to fetch"
    return 0
  }
  not_after=$(grep "notAfter" <<<"$info" | cut -d= -f2 || true)
  if [[ -n "$not_after" ]]; then
    expiry_epoch=$(date -d "$not_after" +%s 2>/dev/null || echo 0)
    current_epoch=$(date +%s)
    days_left=$(((expiry_epoch - current_epoch) / 86400))
    if ((days_left < 0)); then register_check "$SITE_DOMAIN live" FAIL "EXPIRED"; elif ((days_left < CERT_CRIT_DAYS)); then
      register_check "$SITE_DOMAIN live" FAIL "$days_left days (CRITICAL)"
    elif ((days_left < CERT_WARN_DAYS)); then register_check "$SITE_DOMAIN live" WARN "$days_left days"; else register_check "$SITE_DOMAIN live" PASS "$days_left days"; fi
  else register_check "$SITE_DOMAIN live" WARN "no notAfter"; fi
}

main() {
  while [[ $# -gt 0 ]]; do case "$1" in
    -l | --log)
      LOG_FILE="${2:-$DEFAULT_LOG_FILE}"
      shift 2
      ;;
    -q | --quiet)
      QUIET=true
      shift
      ;;
    -v | --verbose)
      VERBOSE=true
      shift
      ;;
    -vv | --very-verbose)
      VERY_VERBOSE=true
      VERBOSE=true
      shift
      ;;
    -d | --domain)
      SITE_DOMAIN="${2:-}"
      shift 2
      ;;
    --no-color)
      NO_COLOR=true
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --version)
      version
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac done
  trap ':' EXIT
  setup_colors
  [[ -n "$LOG_FILE" ]] && {
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    touch "$LOG_FILE" 2>/dev/null || true
  }
  _log INFO "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
  audit_cert_client
  audit_managed_certs
  audit_renewal_schedule
  audit_letsencrypt_perms
  audit_local_certs_expiry
  audit_live_certificate
  exit "$EXIT_CODE"
}
main "$@"
