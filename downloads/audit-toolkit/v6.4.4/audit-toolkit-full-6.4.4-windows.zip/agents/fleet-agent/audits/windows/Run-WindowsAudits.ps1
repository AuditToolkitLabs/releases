#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Security Audit Orchestrator.
.DESCRIPTION
    Discovers and executes Windows audits, aggregates findings, and exports reports.
#>

[CmdletBinding()]
param(
    [ValidateSet('Identity', 'Endpoint', 'Network', 'Data', 'Compliance', 'Enterprise', 'All')]
    [string[]]$Domain = @('All'),
    [string[]]$Include,
    [string[]]$Exclude,
    [string]$OutputPath = '.\audit-results',
    [ValidateSet('JSON', 'CSV', 'HTML', 'XML', 'SIEM', 'All')]
    [string[]]$Format = @('HTML', 'JSON'),
    [switch]$Interactive,
    [switch]$DryRun,
    [switch]$Parallel,
    [switch]$SendToSIEM,
    [ValidateSet('Splunk', 'AzureSentinel', 'Elastic', 'Syslog', 'All')]
    [string]$SIEMTarget = 'All',
    [switch]$Quiet,
    [Alias('Admin')]
    [switch]$RequireAdmin,
    [switch]$Elevate,
    [Alias('Batch')]
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'
$script:StartTime = Get-Date
$script:ScriptPath = $PSScriptRoot

$commonPath = Join-Path $script:ScriptPath 'common\common-audit.psm1'
if (Test-Path -LiteralPath $commonPath) {
    Import-Module $commonPath -Force
}

$libPath = Join-Path $script:ScriptPath '_lib'
Get-ChildItem -Path $libPath -Filter '*.ps1' -ErrorAction SilentlyContinue | ForEach-Object { . $_.FullName }

$script:AuditDomainMap = @{
    Identity = @{
        Description = 'Identity and Access Management'
        Scripts = @('ad_health.ps1', 'gpo_audit.ps1', 'gpo_security_settings.ps1', 'gpo_detailed.ps1', 'laps.ps1', 'user_rights.ps1', 'kerberos_policy.ps1', 'ntlm_restrictions.ps1', 'credential_guard.ps1')
    }
    Endpoint = @{
        Description = 'Endpoint Protection and Hardening'
        Scripts = @('defender_configuration.ps1', 'applocker.ps1', 'powershell_logging.ps1', 'security_options.ps1', 'system_services.ps1', 'bitlocker.ps1', 'usb_storage.ps1', 'edr_audit.ps1', 'mdm_enrollment.ps1')
    }
    Network = @{
        Description = 'Network and Firewall Security'
        Scripts = @('firewall_advanced.ps1', 'smb_hardening.ps1', 'rdp_configuration.ps1', 'network_settings.ps1', 'vpn_audit.ps1', 'remote_access_tools.ps1')
    }
    Data = @{
        Description = 'Data Protection and Encryption'
        Scripts = @('bitlocker.ps1', 'backup_audit.ps1', 'adcs.ps1')
    }
    Compliance = @{
        Description = 'Compliance and Audit Settings'
        Scripts = @('audit_policy.ps1', 'security_options.ps1', 'control_panel.ps1', 'mss_legacy.ps1', 'system_settings.ps1')
    }
    Enterprise = @{
        Description = 'Enterprise Software and Cloud'
        Scripts = @('wsus_sccm.ps1', 'siem_agents.ps1', 'cloud_agents.ps1', 'chrome_browser.ps1', 'firefox_browser.ps1', 'dev_tools_audit.ps1')
    }
}

function Write-Banner {
    [CmdletBinding()]
    param()

    $text = @"
==============================================================================
     Security Audit Toolkit - Windows Orchestrator
     Version 5.0.0
==============================================================================
  Computer:     $env:COMPUTERNAME
  Domain:       $env:USERDOMAIN
  User:         $env:USERNAME
  Date:         $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
==============================================================================
"@

    if (-not $Quiet) {
        Write-Output $text
    }
}

$null = $Parallel, $RequireAdmin, $Elevate, $NonInteractive

function Get-AuditScriptList {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string[]]$Domains,
        [string[]]$IncludePatterns,
        [string[]]$ExcludePatterns
    )

    $selectedDomainList = if ($Domains -contains 'All') { @($script:AuditDomainMap.Keys) } else { @($Domains) }

    $nameAllowList = @()
    foreach ($domainName in $selectedDomainList) {
        if ($script:AuditDomainMap.ContainsKey($domainName)) {
            $nameAllowList += $script:AuditDomainMap[$domainName].Scripts
        }
    }

    $scriptFileList = @()
    foreach ($folderName in @('common', 'server')) {
        $folderPath = Join-Path $script:ScriptPath $folderName
        $scriptFileList += Get-ChildItem -Path $folderPath -Filter '*.ps1' -ErrorAction SilentlyContinue
    }

    $result = foreach ($scriptFile in $scriptFileList) {
        if ($scriptFile.Name -eq 'common-audit.psm1') { continue }
        if ($nameAllowList.Count -gt 0 -and $scriptFile.Name -notin $nameAllowList) { continue }

        if ($IncludePatterns) {
            $includeHit = $false
            foreach ($pattern in $IncludePatterns) {
                if ($scriptFile.Name -like $pattern) { $includeHit = $true; break }
            }
            if (-not $includeHit) { continue }
        }

        if ($ExcludePatterns) {
            $excludeHit = $false
            foreach ($pattern in $ExcludePatterns) {
                if ($scriptFile.Name -like $pattern) { $excludeHit = $true; break }
            }
            if ($excludeHit) { continue }
        }

        $scriptFile
    }

    return @($result | Sort-Object Name -Unique)
}

function Invoke-AuditScriptFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.IO.FileInfo]$Script
    )

    $result = [ordered]@{
        Script = $Script.Name
        Path = $Script.FullName
        StartTime = Get-Date
        EndTime = $null
        Duration = 0
        ExitCode = 0
        Output = ''
        Checks = @()
        Error = $null
    }

    try {
        $outputList = & $Script.FullName 2>&1
        $result.Output = ($outputList -join "`n")
        $result.ExitCode = $LASTEXITCODE

        $checkPattern = '\[(PASS|FAIL|WARN|INFO|SKIP)\]\s+(.+?)(?:\s+-\s+(.*))?$'
        $currentSection = 'General'

        foreach ($lineValue in $outputList) {
            $lineText = [string]$lineValue
            if ($lineText -match '^[=\-]+\s*(.+?)\s*[=\-]+$' -or $lineText -match '^#+\s*(.+)$') {
                $currentSection = $Matches[1].Trim()
            }

            if ($lineText -match $checkPattern) {
                $result.Checks += [ordered]@{
                    Status = $Matches[1]
                    Name = $Matches[2].Trim()
                    Message = if ($Matches[3]) { $Matches[3].Trim() } else { '' }
                    Section = $currentSection
                    Script = $Script.Name
                }
            }
        }
    }
    catch {
        $result.Error = $_.Exception.Message
        $result.ExitCode = 1
    }

    $result.EndTime = Get-Date
    $result.Duration = ($result.EndTime - $result.StartTime).TotalSeconds

    return [pscustomobject]$result
}

function Show-InteractiveMenu {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.IO.FileInfo[]]$Scripts
    )

    Write-Output ''
    Write-Output 'Available Audit Scripts:'
    Write-Output ('-' * 50)

    for ($i = 0; $i -lt $Scripts.Count; $i++) {
        Write-Output ("  [{0}] {1}" -f ($i + 1), $Scripts[$i].Name)
    }

    Write-Output ''
    Write-Output '  [A] Run All'
    Write-Output '  [Q] Quit'
    Write-Output ''

    $selection = Read-Host 'Enter selection (comma-separated numbers, A, or Q)'
    if ($selection -match '^[Qq]$') { return @() }
    if ($selection -match '^[Aa]$') { return $Scripts }

    $selectedIndexList = @()
    foreach ($token in ($selection -split ',')) {
        $text = $token.Trim()
        if (-not $text) { continue }
        $index = 0
        if ([int]::TryParse($text, [ref]$index)) {
            $selectedIndexList += ($index - 1)
        }
    }

    return @($selectedIndexList | Where-Object { $_ -ge 0 -and $_ -lt $Scripts.Count } | ForEach-Object { $Scripts[$_] })
}

function Show-RunProgress {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [int]$Current,
        [Parameter(Mandatory)]
        [int]$Total,
        [Parameter(Mandatory)]
        [string]$ScriptName
    )

    if ($Quiet) { return }

    $percent = if ($Total -gt 0) { [math]::Round(($Current / $Total) * 100) } else { 0 }
    $fill = [math]::Floor($percent / 5)
    $bar = '[' + ('=' * $fill) + (' ' * (20 - $fill)) + ']'
    Write-Output ("{0} {1}% - {2}" -f $bar, $percent, $ScriptName)
}

function Get-SummaryObject {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [array]$Results,
        [Parameter(Mandatory)]
        [array]$Checks
    )

    $obj = [ordered]@{
        TotalScripts = $Results.Count
        TotalChecks = $Checks.Count
        PassedChecks = @($Checks | Where-Object Status -eq 'PASS').Count
        FailedChecks = @($Checks | Where-Object Status -eq 'FAIL').Count
        WarningChecks = @($Checks | Where-Object Status -eq 'WARN').Count
        InfoChecks = @($Checks | Where-Object Status -eq 'INFO').Count
        SkippedChecks = @($Checks | Where-Object Status -eq 'SKIP').Count
        TotalDuration = ($Results | Measure-Object -Property Duration -Sum).Sum
        Timestamp = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssZ')
        ComputerName = $env:COMPUTERNAME
    }

    $obj.ComplianceScore = if ($obj.TotalChecks -gt 0) { [math]::Round(($obj.PassedChecks / $obj.TotalChecks) * 100, 1) } else { 0 }

    if (Get-Command Get-RiskScore -ErrorAction SilentlyContinue) {
        $obj.RiskScore = Get-RiskScore -Results $Checks
    }

    return [pscustomobject]$obj
}

function Write-Summary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [pscustomobject]$Summary
    )

    if ($Quiet) { return }

    Write-Output ('=' * 70)
    Write-Output '                    AUDIT SUMMARY'
    Write-Output ('=' * 70)
    Write-Output ("Compliance Score: {0}%" -f $Summary.ComplianceScore)
    Write-Output ("Total Checks: {0}" -f $Summary.TotalChecks)
    Write-Output ("Passed: {0}" -f $Summary.PassedChecks)
    Write-Output ("Failed: {0}" -f $Summary.FailedChecks)
    Write-Output ("Warnings: {0}" -f $Summary.WarningChecks)
    Write-Output ("Info: {0}" -f $Summary.InfoChecks)
    Write-Output ("Skipped: {0}" -f $Summary.SkippedChecks)
    Write-Output ("Duration: {0} seconds" -f [math]::Round($Summary.TotalDuration, 1))
    Write-Output ('=' * 70)
}

function Export-ResultSet {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [pscustomobject]$Summary,
        [Parameter(Mandatory)]
        [array]$Results,
        [Parameter(Mandatory)]
        [array]$Checks,
        [Parameter(Mandatory)]
        [string]$OutPath,
        [Parameter(Mandatory)]
        [string[]]$OutFormats
    )

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $basePath = Join-Path $OutPath ("audit-{0}-{1}" -f $env:COMPUTERNAME, $stamp)

    $payload = [ordered]@{
        metadata = $Summary
        scripts = @($Results | ForEach-Object {
                [ordered]@{
                    name = $_.Script
                    duration = $_.Duration
                    exitCode = $_.ExitCode
                    checksCount = @($_.Checks).Count
                }
            })
        results = $Checks
    }

    $formatList = if ($OutFormats -contains 'All') { @('JSON', 'CSV', 'HTML', 'XML') } else { @($OutFormats) }
    $written = New-Object System.Collections.Generic.List[string]

    foreach ($item in $formatList) {
        switch ($item) {
            'JSON' {
                $path = "$basePath.json"
                $payload | ConvertTo-Json -Depth 10 | Set-Content -Path $path -Encoding UTF8
                $written.Add($path)
            }
            'CSV' {
                $path = "$basePath.csv"
                $Checks |
                    Select-Object @{ Name = 'Timestamp'; Expression = { $Summary.Timestamp } }, @{ Name = 'Computer'; Expression = { $Summary.ComputerName } }, Script, Section, Name, Status, Message |
                    Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
                $written.Add($path)
            }
            'HTML' {
                $path = "$basePath.html"
                if (Get-Command Export-ToHtmlReport -ErrorAction SilentlyContinue) {
                    $html = Export-ToHtmlReport -Result $Checks -Metadata $Summary
                    $html | Set-Content -Path $path -Encoding UTF8
                    $written.Add($path)
                }
            }
            'XML' {
                $path = "$basePath.xml"
                $payload | ConvertTo-Xml -Depth 10 -As String | Set-Content -Path $path -Encoding UTF8
                $written.Add($path)
            }
        }
    }

    return @($written)
}

function Assert-ExecutionMode {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [bool]$IsAdmin
    )

    if ($Elevate -and -not $IsAdmin) {
        Write-Output '[INFO] Elevating to administrator...'
        $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")

        foreach ($entry in $PSBoundParameters.GetEnumerator() | Where-Object Key -ne 'Elevate') {
            if ($entry.Value -is [switch]) {
                if ($entry.Value) { $argList += ('-' + $entry.Key) }
                continue
            }

            $argList += ('-' + $entry.Key)
            $argList += "`"$($entry.Value)`""
        }

        Start-Process -FilePath 'pwsh.exe' -ArgumentList $argList -Verb RunAs -Wait
        exit $LASTEXITCODE
    }

    if ($RequireAdmin -and -not $IsAdmin) {
        Write-Output '[ERROR] This audit requires administrator privileges'
        Write-Output '        Use -Elevate to auto-elevate, or run PowerShell as Administrator'
        exit 1
    }

    if ($NonInteractive) {
        if ($Interactive) {
            Write-Output '[ERROR] -Interactive conflicts with -NonInteractive'
            exit 1
        }

        if ($Elevate -and -not $IsAdmin) {
            Write-Output '[ERROR] -Elevate cannot be used with -NonInteractive'
            exit 1
        }

        $env:AUDIT_NON_INTERACTIVE = '1'
    }
}

Write-Banner

$isAdmin = Test-IsAdmin
Assert-ExecutionMode -IsAdmin $isAdmin

if (-not $Quiet) {
    if ($isAdmin) {
        Write-Output '[INFO] Running as Administrator - full audit coverage'
    }
    else {
        Write-Output '[WARN] Running as standard user - some checks may be skipped'
    }
}

if (-not (Test-Path -LiteralPath $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
}

if (-not $Quiet) { Write-Output 'Discovering audit scripts...' }
$scriptList = Get-AuditScriptList -Domains $Domain -IncludePatterns $Include -ExcludePatterns $Exclude

if ($scriptList.Count -eq 0) {
    Write-Output '[WARN] No audit scripts found matching criteria'
    exit 1
}

if ($Interactive) {
    $scriptList = Show-InteractiveMenu -Scripts $scriptList
    if ($scriptList.Count -eq 0) {
        Write-Output 'No scripts selected. Exiting.'
        exit 0
    }
}

if ($DryRun) {
    Write-Output 'Dry Run - Scripts that would be executed:'
    foreach ($item in $scriptList) { Write-Output ("  - {0}" -f $item.Name) }
    exit 0
}

if (-not $Quiet) {
    Write-Output ''
    Write-Output 'Executing audits...'
}

$resultList = @()
$checkList = @()
$counter = 0

foreach ($item in $scriptList) {
    $counter++
    Show-RunProgress -Current $counter -Total $scriptList.Count -ScriptName $item.Name

    $result = Invoke-AuditScriptFile -Script $item
    $resultList += $result
    $checkList += $result.Checks
}

$summary = Get-SummaryObject -Results $resultList -Checks $checkList
Write-Summary -Summary $summary

if (-not $Quiet) { Write-Output 'Exporting results...' }
$fileList = Export-ResultSet -Summary $summary -Results $resultList -Checks $checkList -OutPath $OutputPath -OutFormats $Format

if ($SendToSIEM) {
    if (Get-Command Send-AuditToSIEM -ErrorAction SilentlyContinue) {
        Send-AuditToSIEM -Results $checkList -Target $SIEMTarget | Out-Null
        if (-not $Quiet) { Write-Output 'SIEM transmission complete' }
    }
    else {
        Write-Output '[WARN] SIEM integration module not available'
    }
}

if (-not $Quiet) {
    Write-Output 'Exported files:'
    foreach ($path in $fileList) {
        Write-Output ("  - {0}" -f $path)
    }

    $elapsed = (Get-Date) - $script:StartTime
    Write-Output ("Audit completed in {0} seconds" -f [math]::Round($elapsed.TotalSeconds, 1))
}

if ($summary.FailedChecks -gt 0) { exit 2 }
if ($summary.WarningChecks -gt 0) { exit 1 }
exit 0
