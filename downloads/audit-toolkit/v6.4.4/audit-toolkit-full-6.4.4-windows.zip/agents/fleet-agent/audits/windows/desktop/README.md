# Windows Desktop-Only Audit Scripts

This folder contains PowerShell audit scripts for Windows settings that apply only to desktop environments, as per CIS and the provided checklist.

## Scripts to implement (examples):
- onedrive.ps1
- teams.ps1
- edge_browser.ps1

These scripts check for OneDrive sync restrictions, Teams telemetry, and Edge browser security policies. See each script for details.