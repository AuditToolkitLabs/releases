<#
.SYNOPSIS
    Adobe Acrobat Reader Security Audit

.DESCRIPTION
    Comprehensive security audit for Adobe Acrobat Reader DC:
    - Installation and version
    - Update configuration
    - JavaScript settings
    - Protected Mode/View
    - Trust Manager settings
    - Attachment handling
    - Network settings
    - Cloud services

.NOTES
    @elevation: partial
    @elevation-reason: HKLM FeatureLockDown policies require admin; user settings work without elevation
    Requires: Adobe Acrobat Reader or Acrobat Pro

Compliance Mapping:
- CIS Controls: 7.4 (Maintain Endpoint Security Configuration)
- NIST SP 800-53: SI-3 (Malicious Code Protection), CM-7 (Least Functionality)
- Adobe Security Bulletins (APSB)
- MITRE ATT&CK: T1203 (Exploitation for Client Execution), T1204.002 (Malicious File)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Adobe Acrobat Reader Security Audit"

# ============================================================================
# ADOBE READER INSTALLATION CHECK
# ============================================================================
Write-Section "Installation Status"

$adobeInstalled = $false
$adobeVersion = $null
$adobeProduct = $null

# Check for Adobe Reader/Acrobat via registry
$adobePaths = @(
    "HKLM:\SOFTWARE\Adobe\Acrobat Reader",
    "HKLM:\SOFTWARE\WOW6432Node\Adobe\Acrobat Reader",
    "HKLM:\SOFTWARE\Adobe\Adobe Acrobat",
    "HKLM:\SOFTWARE\WOW6432Node\Adobe\Adobe Acrobat"
)

foreach ($regPath in $adobePaths) {
    if (Test-Path $regPath) {
        $versions = Get-ChildItem -Path $regPath -ErrorAction SilentlyContinue
        foreach ($ver in $versions) {
            $installPath = Get-ItemProperty -Path "$($ver.PSPath)\Installer" -Name "Path" -ErrorAction SilentlyContinue
            if ($installPath) {
                $adobeInstalled = $true
                $adobeVersion = $ver.PSChildName
                if ($regPath -match "Acrobat Reader") {
                    $adobeProduct = "Acrobat Reader DC"
                } else {
                    $adobeProduct = "Acrobat Pro"
                }
                break
            }
        }
    }
    if ($adobeInstalled) { break }
}

if ($adobeInstalled) {
    Register-Check -Name "Adobe Installation" -Status PASS -Message "$adobeProduct $adobeVersion"

    # Check version currency (Adobe releases monthly updates)
    $majorVer = $adobeVersion -replace '\..*',''
    if ([int]$majorVer -ge 2024) {
        Register-Check -Name "Version Currency" -Status PASS -Message "Current release track"
    } elseif ([int]$majorVer -ge 2020) {
        Register-Check -Name "Version Currency" -Status INFO -Message "Recent version"
    } else {
        Register-Check -Name "Version Currency" -Status WARN -Message "May be outdated"
    }
} else {
    Register-Check -Name "Adobe Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# FEATURE LOCKDOWN (GPO/Registry)
# ============================================================================
Write-Section "Security Feature Lockdown"

# Determine policy path based on version
$featurePath = "HKLM:\SOFTWARE\Policies\Adobe\Acrobat Reader\DC\FeatureLockDown"
$featurePathWow = "HKLM:\SOFTWARE\WOW6432Node\Policies\Adobe\Acrobat Reader\DC\FeatureLockDown"

$activePath = if (Test-Path $featurePath) { $featurePath } elseif (Test-Path $featurePathWow) { $featurePathWow } else { $null }

if ($activePath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "Configured"

    # Protected Mode
    try {
        $protectedMode = Get-ItemProperty -Path $activePath -Name "bProtectedMode" -ErrorAction SilentlyContinue
        if ($protectedMode -and $protectedMode.bProtectedMode -eq 1) {
            Register-Check -Name "Protected Mode" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Protected Mode" -Status FAIL -Message "Disabled or not set"
        }
    } catch {
        Register-Check -Name "Protected Mode" -Status INFO -Message "Default (enabled)"
    }

    # Protected View
    try {
        $protectedView = Get-ItemProperty -Path $activePath -Name "iProtectedView" -ErrorAction SilentlyContinue
        if ($protectedView) {
            switch ($protectedView.iProtectedView) {
                0 { Register-Check -Name "Protected View" -Status FAIL -Message "Disabled" }
                1 { Register-Check -Name "Protected View" -Status INFO -Message "Unsafe locations only" }
                2 { Register-Check -Name "Protected View" -Status PASS -Message "All files" }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Enhanced Security
    try {
        $enhancedSec = Get-ItemProperty -Path $activePath -Name "bEnhancedSecurityInBrowser" -ErrorAction SilentlyContinue
        if ($enhancedSec -and $enhancedSec.bEnhancedSecurityInBrowser -eq 1) {
            Register-Check -Name "Enhanced Security (Browser)" -Status PASS -Message "Enabled"
        }

        $enhancedSecStandalone = Get-ItemProperty -Path $activePath -Name "bEnhancedSecurityStandalone" -ErrorAction SilentlyContinue
        if ($enhancedSecStandalone -and $enhancedSecStandalone.bEnhancedSecurityStandalone -eq 1) {
            Register-Check -Name "Enhanced Security (Standalone)" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

} else {
    Register-Check -Name "Enterprise Policies" -Status WARN -Message "Not configured via GPO"
}

# ============================================================================
# JAVASCRIPT SECURITY
# ============================================================================
Write-Section "JavaScript Security"

# JavaScript enabled
try {
    $jsEnabled = Get-ItemProperty -Path $activePath -Name "bDisableJavaScript" -ErrorAction SilentlyContinue
    if ($jsEnabled -and $jsEnabled.bDisableJavaScript -eq 1) {
        Register-Check -Name "JavaScript" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "JavaScript" -Status WARN -Message "Enabled (review if needed)"
    }
} catch {
    Register-Check -Name "JavaScript" -Status WARN -Message "Enabled by default"
}

# Privileged JavaScript
try {
    $jsPriv = Get-ItemProperty -Path "$activePath\cJavaScript" -Name "bEnableMenuItems" -ErrorAction SilentlyContinue
    if ($jsPriv -and $jsPriv.bEnableMenuItems -eq 0) {
        Register-Check -Name "JS Menu Items" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# JavaScript blacklist
try {
    $jsBlacklist = Get-ItemProperty -Path "$activePath\cJavaScript" -Name "bEnableGlobalSecurity" -ErrorAction SilentlyContinue
    if ($jsBlacklist -and $jsBlacklist.bEnableGlobalSecurity -eq 1) {
        Register-Check -Name "Global JS Security" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ATTACHMENT HANDLING
# ============================================================================
Write-Section "Attachment Security"

# Default attachment permissions
try {
    $attachPerm = Get-ItemProperty -Path "$activePath\cDefaultLaunchAttachmentPerms" -Name "iUnknownURLPerms" -ErrorAction SilentlyContinue
    if ($attachPerm) {
        switch ($attachPerm.iUnknownURLPerms) {
            0 { Register-Check -Name "Unknown Attachments" -Status PASS -Message "Always block" }
            1 { Register-Check -Name "Unknown Attachments" -Status INFO -Message "Prompt user" }
            2 { Register-Check -Name "Unknown Attachments" -Status FAIL -Message "Always allow" }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# File attachment blacklist
try {
    $blacklist = Get-ItemProperty -Path "$activePath\cDefaultLaunchAttachmentPerms" -Name "tBuiltInPermList" -ErrorAction SilentlyContinue
    if ($blacklist) {
        Register-Check -Name "Attachment Blacklist" -Status PASS -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# TRUST MANAGER
# ============================================================================
Write-Section "Trust Manager"

$trustPath = "$activePath\cTrustManager"

if (Test-Path $trustPath -ErrorAction SilentlyContinue) {
    # Certified documents
    try {
        $certDocs = Get-ItemProperty -Path $trustPath -Name "bEnableCertificateBasedTrust" -ErrorAction SilentlyContinue
        if ($certDocs -and $certDocs.bEnableCertificateBasedTrust -eq 1) {
            Register-Check -Name "Certificate Trust" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Trusted sites
    try {
        $trustedSites = Get-ItemProperty -Path $trustPath -Name "bTrustOSTrustedSites" -ErrorAction SilentlyContinue
        if ($trustedSites -and $trustedSites.bTrustOSTrustedSites -eq 0) {
            Register-Check -Name "OS Trusted Sites" -Status PASS -Message "Not automatically trusted"
        } else {
            Register-Check -Name "OS Trusted Sites" -Status INFO -Message "Inherited from OS"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Certified plugins
    try {
        $certPlugins = Get-ItemProperty -Path $trustPath -Name "bTrustCertifiedPlugins" -ErrorAction SilentlyContinue
        if ($certPlugins -and $certPlugins.bTrustCertifiedPlugins -eq 0) {
            Register-Check -Name "Certified Plugins Only" -Status INFO -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# NETWORK/WEB SERVICES
# ============================================================================
Write-Section "Network Settings"

# Cloud services
try {
    $cloudServices = Get-ItemProperty -Path "$activePath\cCloud" -Name "bDisableADCFileStore" -ErrorAction SilentlyContinue
    if ($cloudServices -and $cloudServices.bDisableADCFileStore -eq 1) {
        Register-Check -Name "Adobe Cloud Storage" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Adobe Cloud Storage" -Status INFO -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# SharePoint integration
try {
    $sharepoint = Get-ItemProperty -Path "$activePath\cSharePoint" -Name "bDisableSharePointFeatures" -ErrorAction SilentlyContinue
    if ($sharepoint -and $sharepoint.bDisableSharePointFeatures -eq 1) {
        Register-Check -Name "SharePoint Features" -Status INFO -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Webmail
try {
    $webmail = Get-ItemProperty -Path "$activePath\cWebmailProfiles" -Name "bDisableWebmail" -ErrorAction SilentlyContinue
    if ($webmail -and $webmail.bDisableWebmail -eq 1) {
        Register-Check -Name "Webmail Integration" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# UPDATE SETTINGS
# ============================================================================
Write-Section "Update Configuration"

$updatePath = "HKLM:\SOFTWARE\Policies\Adobe\Acrobat Reader\DC\FeatureLockDown"

try {
    $updateMode = Get-ItemProperty -Path $updatePath -Name "bUpdater" -ErrorAction SilentlyContinue
    if ($updateMode -and $updateMode.bUpdater -eq 0) {
        Register-Check -Name "Auto Updates" -Status WARN -Message "Disabled (ensure managed externally)"
    } else {
        Register-Check -Name "Auto Updates" -Status PASS -Message "Enabled"
    }
} catch {
    Register-Check -Name "Auto Updates" -Status INFO -Message "Default (enabled)"
}

# Check Adobe Acrobat Update Service
try {
    $updateSvc = Get-Service -Name "AdobeARMservice" -ErrorAction SilentlyContinue
    if ($updateSvc) {
        if ($updateSvc.Status -eq 'Running') {
            Register-Check -Name "Update Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Update Service" -Status WARN -Message $updateSvc.Status
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DIGITAL SIGNATURES
# ============================================================================
Write-Section "Digital Signatures"

try {
    $sigPath = "$activePath\cDigSig"

    # Signature validation
    $sigValidation = Get-ItemProperty -Path $sigPath -Name "bEnableSigningVerification" -ErrorAction SilentlyContinue
    if ($sigValidation -and $sigValidation.bEnableSigningVerification -eq 1) {
        Register-Check -Name "Signature Verification" -Status PASS -Message "Enabled"
    }

    # Require AATL
    $aatl = Get-ItemProperty -Path "$sigPath\cAATL" -Name "bLoadDefaultAATL" -ErrorAction SilentlyContinue
    if ($aatl -and $aatl.bLoadDefaultAATL -eq 1) {
        Register-Check -Name "Adobe Approved Trust List" -Status PASS -Message "Loaded"
    }

    # Require EUTL
    $eutl = Get-ItemProperty -Path "$sigPath\cEUTL" -Name "bLoadDefaultEUTL" -ErrorAction SilentlyContinue
    if ($eutl -and $eutl.bLoadDefaultEUTL -eq 1) {
        Register-Check -Name "European Trust List" -Status PASS -Message "Loaded"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# 3D AND MULTIMEDIA
# ============================================================================
Write-Section "Multimedia Content"

try {
    $multimedia = Get-ItemProperty -Path "$activePath\c3D" -Name "bEnable3D" -ErrorAction SilentlyContinue
    if ($multimedia -and $multimedia.bEnable3D -eq 0) {
        Register-Check -Name "3D Content" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "3D Content" -Status WARN -Message "Enabled (potential attack vector)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

try {
    $flash = Get-ItemProperty -Path "$activePath\cFlashPDF" -Name "bEnableFlash" -ErrorAction SilentlyContinue
    if ($flash -and $flash.bEnableFlash -eq 0) {
        Register-Check -Name "Flash in PDF" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Flash in PDF" -Status FAIL -Message "Enabled (Flash is EOL)"
    }
} catch {
    Register-Check -Name "Flash in PDF" -Status PASS -Message "Not configured (Flash EOL)"
}

# ============================================================================
# SECURITY SUMMARY
# ============================================================================
Write-Section "Additional Security Checks"

# Check for Adobe Reader running in sandbox
try {
    $adobeProc = Get-Process -Name "AcroRd32", "Acrobat" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($adobeProc) {
        Register-Check -Name "Adobe Process" -Status INFO -Message "Running (PID: $($adobeProc.Id))"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Usage rights
try {
    $usageRights = Get-ItemProperty -Path $activePath -Name "bDisableUsageRights" -ErrorAction SilentlyContinue
    if ($usageRights -and $usageRights.bDisableUsageRights -eq 1) {
        Register-Check -Name "Usage Rights" -Status INFO -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
