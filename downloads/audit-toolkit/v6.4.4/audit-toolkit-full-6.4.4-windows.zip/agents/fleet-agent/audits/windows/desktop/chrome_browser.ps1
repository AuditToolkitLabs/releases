<#
.SYNOPSIS
    Google Chrome Browser Security Audit

.DESCRIPTION
    Comprehensive security audit for Google Chrome:
    - Installation and version
    - Update configuration
    - Extension security
    - Privacy settings
    - Safe Browsing
    - Password manager settings
    - Certificate handling
    - Policy enforcement (GPO/Registry)

.NOTES
    @elevation: partial
    @elevation-reason: HKLM registry policies require admin; HKCU and file checks work without elevation
    Requires: Chrome installed

Compliance Mapping:
- CIS Controls: 7.1 (Browser Configuration), 9.1 (Limit Use of Browser)
- NIST SP 800-53: CM-7 (Least Functionality), SC-18 (Mobile Code)
- CIS Google Chrome Benchmark v2.x
- MITRE ATT&CK: T1189 (Drive-by Compromise), T1185 (Browser Session Hijacking)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Google Chrome Browser Security Audit"

# ============================================================================
# CHROME INSTALLATION CHECK
# ============================================================================
Write-Section "Chrome Installation"

$chromeInstalled = $false
$chromePath = $null
$chromeVersion = $null

# Check common installation paths
$chromePaths = @(
    "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "${env:LocalAppData}\Google\Chrome\Application\chrome.exe"
)

foreach ($path in $chromePaths) {
    if (Test-Path $path) {
        $chromeInstalled = $true
        $chromePath = $path
        break
    }
}

if ($chromeInstalled) {
    Register-Check -Name "Chrome Installation" -Status PASS -Message "Found at $chromePath"

    # Get version
    try {
        $chromeVersion = (Get-Item $chromePath).VersionInfo.ProductVersion
        Register-Check -Name "Chrome Version" -Status INFO -Message $chromeVersion

        # Check if version is recent (Chrome updates frequently)
        $majorVersion = [int]($chromeVersion.Split('.')[0])
        if ($majorVersion -ge 120) {
            Register-Check -Name "Chrome Currency" -Status PASS -Message "Recent major version"
        } else {
            Register-Check -Name "Chrome Currency" -Status WARN -Message "May be outdated (v$majorVersion)"
        }
    } catch {
        Register-Check -Name "Chrome Version" -Status WARN -Message "Cannot determine"
    }
} else {
    Register-Check -Name "Chrome Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# UPDATE CONFIGURATION
# ============================================================================
Write-Section "Update Configuration"

$updatePolicyPath = "HKLM:\SOFTWARE\Policies\Google\Update"

# Auto-update enabled
try {
    $autoUpdate = Get-ItemProperty -Path $updatePolicyPath -Name "AutoUpdateCheckPeriodMinutes" -ErrorAction SilentlyContinue
    if ($autoUpdate -and $autoUpdate.AutoUpdateCheckPeriodMinutes -eq 0) {
        Register-Check -Name "Auto-Update Check" -Status FAIL -Message "Disabled by policy"
    } elseif ($autoUpdate) {
        Register-Check -Name "Auto-Update Check" -Status PASS -Message "Every $($autoUpdate.AutoUpdateCheckPeriodMinutes) minutes"
    } else {
        Register-Check -Name "Auto-Update Check" -Status PASS -Message "Default (enabled)"
    }
} catch {
    Register-Check -Name "Auto-Update Check" -Status INFO -Message "Default configuration"
}

# Update policy
try {
    $updateDefault = Get-ItemProperty -Path $updatePolicyPath -Name "UpdateDefault" -ErrorAction SilentlyContinue
    if ($updateDefault) {
        switch ($updateDefault.UpdateDefault) {
            0 { Register-Check -Name "Update Policy" -Status FAIL -Message "Updates disabled" }
            1 { Register-Check -Name "Update Policy" -Status PASS -Message "Always allow updates" }
            2 { Register-Check -Name "Update Policy" -Status INFO -Message "Manual updates only" }
            3 { Register-Check -Name "Update Policy" -Status PASS -Message "Automatic silent updates" }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CHROME POLICIES (GPO/Registry)
# ============================================================================
Write-Section "Chrome Security Policies"

$chromePolicyPath = "HKLM:\SOFTWARE\Policies\Google\Chrome"

# Safe Browsing (CIS Chrome 1.1.1)
try {
    $safeBrowsing = Get-ItemProperty -Path $chromePolicyPath -Name "SafeBrowsingProtectionLevel" -ErrorAction SilentlyContinue
    if ($safeBrowsing) {
        switch ($safeBrowsing.SafeBrowsingProtectionLevel) {
            0 { Register-Check -Name "Safe Browsing" -Status FAIL -Message "Disabled" }
            1 { Register-Check -Name "Safe Browsing" -Status PASS -Message "Standard protection" }
            2 { Register-Check -Name "Safe Browsing" -Status PASS -Message "Enhanced protection" }
        }
    } else {
        # Check legacy setting
        $legacySafeBrowsing = Get-ItemProperty -Path $chromePolicyPath -Name "SafeBrowsingEnabled" -ErrorAction SilentlyContinue
        if ($legacySafeBrowsing -and $legacySafeBrowsing.SafeBrowsingEnabled -eq 0) {
            Register-Check -Name "Safe Browsing" -Status FAIL -Message "Disabled"
        } else {
            Register-Check -Name "Safe Browsing" -Status INFO -Message "User controlled"
        }
    }
} catch {
    Register-Check -Name "Safe Browsing" -Status INFO -Message "User controlled"
}

# Password Manager (CIS Chrome 1.1.4)
try {
    $passwordManager = Get-ItemProperty -Path $chromePolicyPath -Name "PasswordManagerEnabled" -ErrorAction SilentlyContinue
    if ($passwordManager -and $passwordManager.PasswordManagerEnabled -eq 0) {
        Register-Check -Name "Password Manager" -Status PASS -Message "Disabled (use external)"
    } elseif ($passwordManager) {
        Register-Check -Name "Password Manager" -Status INFO -Message "Enabled"
    } else {
        Register-Check -Name "Password Manager" -Status INFO -Message "User controlled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Incognito Mode (CIS Chrome 1.1.7)
try {
    $incognito = Get-ItemProperty -Path $chromePolicyPath -Name "IncognitoModeAvailability" -ErrorAction SilentlyContinue
    if ($incognito) {
        switch ($incognito.IncognitoModeAvailability) {
            0 { Register-Check -Name "Incognito Mode" -Status INFO -Message "Available" }
            1 { Register-Check -Name "Incognito Mode" -Status INFO -Message "Disabled" }
            2 { Register-Check -Name "Incognito Mode" -Status INFO -Message "Forced" }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Guest Mode
try {
    $guestMode = Get-ItemProperty -Path $chromePolicyPath -Name "BrowserGuestModeEnabled" -ErrorAction SilentlyContinue
    if ($guestMode -and $guestMode.BrowserGuestModeEnabled -eq 0) {
        Register-Check -Name "Guest Mode" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Guest Mode" -Status INFO -Message "Enabled or user controlled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Third-party cookies (CIS Chrome 1.1.10)
try {
    $cookies = Get-ItemProperty -Path $chromePolicyPath -Name "BlockThirdPartyCookies" -ErrorAction SilentlyContinue
    if ($cookies -and $cookies.BlockThirdPartyCookies -eq 1) {
        Register-Check -Name "Third-Party Cookies" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "Third-Party Cookies" -Status WARN -Message "Allowed or user controlled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Site isolation
try {
    $siteIsolation = Get-ItemProperty -Path $chromePolicyPath -Name "SitePerProcess" -ErrorAction SilentlyContinue
    if ($siteIsolation -and $siteIsolation.SitePerProcess -eq 1) {
        Register-Check -Name "Site Isolation" -Status PASS -Message "Enforced"
    } else {
        Register-Check -Name "Site Isolation" -Status INFO -Message "Default (enabled)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# DNS over HTTPS
try {
    $dnsOverHttps = Get-ItemProperty -Path $chromePolicyPath -Name "DnsOverHttpsMode" -ErrorAction SilentlyContinue
    if ($dnsOverHttps) {
        switch ($dnsOverHttps.DnsOverHttpsMode) {
            "off" { Register-Check -Name "DNS over HTTPS" -Status WARN -Message "Disabled" }
            "automatic" { Register-Check -Name "DNS over HTTPS" -Status INFO -Message "Automatic (opportunistic)" }
            "secure" { Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Secure (required)" }
        }
    } else {
        Register-Check -Name "DNS over HTTPS" -Status INFO -Message "User controlled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# EXTENSION POLICIES
# ============================================================================
Write-Section "Extension Security"

# Extension install blocklist
try {
    $extBlocklist = Get-ItemProperty -Path "$chromePolicyPath\ExtensionInstallBlocklist" -ErrorAction SilentlyContinue
    if ($extBlocklist) {
        $blockedCount = ($extBlocklist.PSObject.Properties | Where-Object { $_.Name -match '^\d+$' }).Count
        if ($blockedCount -gt 0) {
            Register-Check -Name "Extension Blocklist" -Status PASS -Message "$blockedCount extension(s) blocked"
        }
        if ($extBlocklist.'*' -or ($extBlocklist.PSObject.Properties | Where-Object { $_.Value -eq '*' })) {
            Register-Check -Name "Extension Install" -Status PASS -Message "All blocked by default"
        }
    } else {
        Register-Check -Name "Extension Blocklist" -Status INFO -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Extension install allowlist
try {
    $extAllowlist = Get-ItemProperty -Path "$chromePolicyPath\ExtensionInstallAllowlist" -ErrorAction SilentlyContinue
    if ($extAllowlist) {
        $allowedCount = ($extAllowlist.PSObject.Properties | Where-Object { $_.Name -match '^\d+$' }).Count
        Register-Check -Name "Extension Allowlist" -Status INFO -Message "$allowedCount extension(s) allowed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Force installed extensions
try {
    $forceInstall = Get-ItemProperty -Path "$chromePolicyPath\ExtensionInstallForcelist" -ErrorAction SilentlyContinue
    if ($forceInstall) {
        $forcedCount = ($forceInstall.PSObject.Properties | Where-Object { $_.Name -match '^\d+$' }).Count
        Register-Check -Name "Force Installed Extensions" -Status INFO -Message "$forcedCount extension(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# External extensions blocked
try {
    $blockExternal = Get-ItemProperty -Path $chromePolicyPath -Name "BlockExternalExtensions" -ErrorAction SilentlyContinue
    if ($blockExternal -and $blockExternal.BlockExternalExtensions -eq 1) {
        Register-Check -Name "External Extensions" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "External Extensions" -Status WARN -Message "Allowed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DOWNLOAD AND FILE HANDLING
# ============================================================================
Write-Section "Download Security"

# Download restrictions
try {
    $downloadRestrictions = Get-ItemProperty -Path $chromePolicyPath -Name "DownloadRestrictions" -ErrorAction SilentlyContinue
    if ($downloadRestrictions) {
        switch ($downloadRestrictions.DownloadRestrictions) {
            0 { Register-Check -Name "Download Restrictions" -Status INFO -Message "No restrictions" }
            1 { Register-Check -Name "Download Restrictions" -Status WARN -Message "Block dangerous downloads" }
            2 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block dangerous + uncommon" }
            3 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block all downloads" }
            4 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block malicious downloads" }
        }
    } else {
        Register-Check -Name "Download Restrictions" -Status INFO -Message "Default (block dangerous)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Default download directory
try {
    $downloadDir = Get-ItemProperty -Path $chromePolicyPath -Name "DownloadDirectory" -ErrorAction SilentlyContinue
    if ($downloadDir) {
        Register-Check -Name "Download Directory" -Status INFO -Message "Enforced: $($downloadDir.DownloadDirectory)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Prompt for download location
try {
    $promptDownload = Get-ItemProperty -Path $chromePolicyPath -Name "PromptForDownloadLocation" -ErrorAction SilentlyContinue
    if ($promptDownload -and $promptDownload.PromptForDownloadLocation -eq 1) {
        Register-Check -Name "Download Prompt" -Status INFO -Message "Always prompt for location"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# PRIVACY AND TRACKING
# ============================================================================
Write-Section "Privacy Settings"

# Sync disabled
try {
    $syncDisabled = Get-ItemProperty -Path $chromePolicyPath -Name "SyncDisabled" -ErrorAction SilentlyContinue
    if ($syncDisabled -and $syncDisabled.SyncDisabled -eq 1) {
        Register-Check -Name "Chrome Sync" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Chrome Sync" -Status INFO -Message "Enabled or user controlled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Search suggestions
try {
    $searchSuggest = Get-ItemProperty -Path $chromePolicyPath -Name "SearchSuggestEnabled" -ErrorAction SilentlyContinue
    if ($searchSuggest -and $searchSuggest.SearchSuggestEnabled -eq 0) {
        Register-Check -Name "Search Suggestions" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Spell check service
try {
    $spellCheck = Get-ItemProperty -Path $chromePolicyPath -Name "SpellCheckServiceEnabled" -ErrorAction SilentlyContinue
    if ($spellCheck -and $spellCheck.SpellCheckServiceEnabled -eq 0) {
        Register-Check -Name "Spell Check Service" -Status INFO -Message "Disabled (privacy)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Metrics reporting
try {
    $metrics = Get-ItemProperty -Path $chromePolicyPath -Name "MetricsReportingEnabled" -ErrorAction SilentlyContinue
    if ($metrics -and $metrics.MetricsReportingEnabled -eq 0) {
        Register-Check -Name "Metrics Reporting" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# URL tracking
try {
    $urlKeyedAnon = Get-ItemProperty -Path $chromePolicyPath -Name "UrlKeyedAnonymizedDataCollectionEnabled" -ErrorAction SilentlyContinue
    if ($urlKeyedAnon -and $urlKeyedAnon.UrlKeyedAnonymizedDataCollectionEnabled -eq 0) {
        Register-Check -Name "URL Data Collection" -Status PASS -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# NETWORK AND SSL
# ============================================================================
Write-Section "Network Security"

# SSL minimum version
try {
    $sslMin = Get-ItemProperty -Path $chromePolicyPath -Name "SSLVersionMin" -ErrorAction SilentlyContinue
    if ($sslMin) {
        switch ($sslMin.SSLVersionMin) {
            "tls1.2" { Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.2" }
            "tls1.3" { Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.3" }
            "tls1.1" { Register-Check -Name "Minimum TLS Version" -Status WARN -Message "TLS 1.1" }
            "tls1" { Register-Check -Name "Minimum TLS Version" -Status FAIL -Message "TLS 1.0" }
        }
    } else {
        Register-Check -Name "Minimum TLS Version" -Status INFO -Message "Default (TLS 1.2)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Certificate transparency
try {
    $certTransparency = Get-ItemProperty -Path $chromePolicyPath -Name "CertificateTransparencyEnforcementDisabledForUrls" -ErrorAction SilentlyContinue
    if ($certTransparency) {
        Register-Check -Name "Cert Transparency" -Status WARN -Message "Disabled for some URLs"
    } else {
        Register-Check -Name "Cert Transparency" -Status PASS -Message "Enforced"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# QUIC protocol
try {
    $quicAllowed = Get-ItemProperty -Path $chromePolicyPath -Name "QuicAllowed" -ErrorAction SilentlyContinue
    if ($quicAllowed -and $quicAllowed.QuicAllowed -eq 0) {
        Register-Check -Name "QUIC Protocol" -Status INFO -Message "Disabled"
    } else {
        Register-Check -Name "QUIC Protocol" -Status INFO -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DEVELOPER AND DEBUG SETTINGS
# ============================================================================
Write-Section "Developer Settings"

# Developer tools
try {
    $devTools = Get-ItemProperty -Path $chromePolicyPath -Name "DeveloperToolsAvailability" -ErrorAction SilentlyContinue
    if ($devTools) {
        switch ($devTools.DeveloperToolsAvailability) {
            0 { Register-Check -Name "Developer Tools" -Status INFO -Message "Disabled for enterprise extensions" }
            1 { Register-Check -Name "Developer Tools" -Status INFO -Message "Always allowed" }
            2 { Register-Check -Name "Developer Tools" -Status PASS -Message "Always disabled" }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Command line flags
try {
    $cmdFlags = Get-ItemProperty -Path $chromePolicyPath -Name "CommandLineFlagSecurityWarningsEnabled" -ErrorAction SilentlyContinue
    if ($cmdFlags -and $cmdFlags.CommandLineFlagSecurityWarningsEnabled -eq 1) {
        Register-Check -Name "CLI Flag Warnings" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# INSTALLED EXTENSIONS AUDIT
# ============================================================================
Write-Section "Installed Extensions"

$userExtensionsPath = "$env:LocalAppData\Google\Chrome\User Data\Default\Extensions"
if (Test-Path $userExtensionsPath) {
    try {
        $extensions = Get-ChildItem -Path $userExtensionsPath -Directory -ErrorAction SilentlyContinue
        if ($extensions) {
            $extCount = $extensions.Count
            Register-Check -Name "User Extensions" -Status INFO -Message "$extCount extension(s) installed"

            if ($extCount -gt 20) {
                Register-Check -Name "Extension Count" -Status WARN -Message "High number of extensions ($extCount)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

Print-Summary
Exit-Audit
