<#
.SYNOPSIS
    Microsoft Edge Browser Security Audit Script

.DESCRIPTION
    Comprehensive security audit for Microsoft Edge enterprise deployments.
    Checks browser policies, extension controls, security features, and hardening.
    This script is read-only and does not modify system state.

.NOTES
    @elevation: partial
    @elevation-reason: HKLM registry policies require admin; HKCU works without elevation
    Compliance Mapping:
    - CIS Controls: 4.1, 4.2, 7.1, 8.1, 16.11
    - NIST SP 800-53: AC-2, AC-6, SC-7, SC-13, SI-2
    - ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1
    - OWASP ASVS: V4, V10
    - UK NCSC: Secure Configuration, Logging and Monitoring
    - PCI DSS: 2.2, 7.1, 10.2
    - Microsoft Edge Security Baseline
#>

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

# ============================================================================
# EDGE INSTALLATION CHECK
# ============================================================================
Write-Output "=== Microsoft Edge Installation ==="

$edgePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$edgePath64 = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"

$edgeInstalled = $false
if (Test-Path $edgePath) {
    $edgeInstalled = $true
    $edgeExe = $edgePath
} elseif (Test-Path $edgePath64) {
    $edgeInstalled = $true
    $edgeExe = $edgePath64
}

if ($edgeInstalled) {
    $edgeVersion = (Get-Item $edgeExe).VersionInfo.FileVersion
    Register-Check -Name "Microsoft Edge" -Status PASS -Message "Version $edgeVersion"

    # Check for outdated version (Edge auto-updates, but check anyway)
    $versionNum = [version]$edgeVersion
    $currentYear = (Get-Date).Year
    if ($versionNum.Major -lt ($currentYear - 2020 + 88)) {
        Register-Check -Name "Edge Version Check" -Status WARN -Message "May be outdated - ensure auto-update is working"
    } else {
        Register-Check -Name "Edge Version Check" -Status PASS -Message "Recent version"
    }
} else {
    Register-Check -Name "Microsoft Edge" -Status INFO -Message "Not installed (or using legacy Edge)"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# EDGE UPDATE SERVICE
# ============================================================================
Write-Output ""
Write-Output "=== Edge Update Service ==="

# CIS Control 4.1 - Ensure software is up to date
$edgeUpdate = Get-Service -Name "edgeupdate" -ErrorAction SilentlyContinue
if ($edgeUpdate) {
    if ($edgeUpdate.StartType -eq "Automatic" -or $edgeUpdate.StartType -eq "Delayed") {
        Register-Check -Name "Edge Update Service" -Status PASS -Message "Auto-update enabled"
    } else {
        Register-Check -Name "Edge Update Service" -Status WARN -Message "Start type: $($edgeUpdate.StartType)"
    }
} else {
    Register-Check -Name "Edge Update Service" -Status WARN -Message "Not found"
}

# Check update policy
$updatePolicy = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\EdgeUpdate" -Name "UpdateDefault" -ErrorAction SilentlyContinue
if ($updatePolicy) {
    switch ($updatePolicy.UpdateDefault) {
        0 { Register-Check -Name "Edge Update Policy" -Status FAIL -Message "Updates disabled" }
        1 { Register-Check -Name "Edge Update Policy" -Status PASS -Message "Always allow updates" }
        2 { Register-Check -Name "Edge Update Policy" -Status INFO -Message "Manual updates only" }
        3 { Register-Check -Name "Edge Update Policy" -Status PASS -Message "Auto updates only" }
    }
}

# ============================================================================
# SECURITY POLICIES (GPO/MDM)
# ============================================================================
Write-Output ""
Write-Output "=== Security Policies ==="

$edgePolicies = "HKLM:\SOFTWARE\Policies\Microsoft\Edge"

# SmartScreen (CIS 7.1 - Malware Protection)
$smartScreen = Get-ItemProperty $edgePolicies -Name "SmartScreenEnabled" -ErrorAction SilentlyContinue
if ($smartScreen -and $smartScreen.SmartScreenEnabled -eq 1) {
    Register-Check -Name "SmartScreen" -Status PASS -Message "Enabled"
} elseif ($smartScreen -and $smartScreen.SmartScreenEnabled -eq 0) {
    Register-Check -Name "SmartScreen" -Status FAIL -Message "Disabled - enable for malware protection"
} else {
    Register-Check -Name "SmartScreen" -Status INFO -Message "Not configured (default: enabled)"
}

# SmartScreen for downloads
$smartScreenPUA = Get-ItemProperty $edgePolicies -Name "SmartScreenPuaEnabled" -ErrorAction SilentlyContinue
if ($smartScreenPUA -and $smartScreenPUA.SmartScreenPuaEnabled -eq 1) {
    Register-Check -Name "SmartScreen PUA Protection" -Status PASS -Message "Enabled"
} else {
    Register-Check -Name "SmartScreen PUA Protection" -Status INFO -Message "Not explicitly enabled"
}

# Password Manager (SC-13 - Cryptography)
$passwordManager = Get-ItemProperty $edgePolicies -Name "PasswordManagerEnabled" -ErrorAction SilentlyContinue
if ($passwordManager) {
    if ($passwordManager.PasswordManagerEnabled -eq 1) {
        Register-Check -Name "Password Manager" -Status INFO -Message "Enabled"

        # Check if password leak detection is enabled
        $leakDetection = Get-ItemProperty $edgePolicies -Name "PasswordLeakDetectionEnabled" -ErrorAction SilentlyContinue
        if ($leakDetection -and $leakDetection.PasswordLeakDetectionEnabled -eq 1) {
            Register-Check -Name "Password Leak Detection" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Password Leak Detection" -Status WARN -Message "Not enabled"
        }
    } else {
        Register-Check -Name "Password Manager" -Status INFO -Message "Disabled by policy"
    }
}

# Safe Browsing / Enhanced Security Mode
$enhancedSecurity = Get-ItemProperty $edgePolicies -Name "EnhanceSecurityMode" -ErrorAction SilentlyContinue
if ($enhancedSecurity) {
    switch ($enhancedSecurity.EnhanceSecurityMode) {
        0 { Register-Check -Name "Enhanced Security Mode" -Status WARN -Message "Disabled" }
        1 { Register-Check -Name "Enhanced Security Mode" -Status INFO -Message "Basic mode" }
        2 { Register-Check -Name "Enhanced Security Mode" -Status PASS -Message "Strict mode" }
    }
}

# HTTPS-Only Mode
$httpsOnly = Get-ItemProperty $edgePolicies -Name "AutomaticHttpsDefault" -ErrorAction SilentlyContinue
if ($httpsOnly) {
    switch ($httpsOnly.AutomaticHttpsDefault) {
        0 { Register-Check -Name "Automatic HTTPS" -Status WARN -Message "Disabled" }
        1 { Register-Check -Name "Automatic HTTPS" -Status PASS -Message "Enabled for likely HTTPS sites" }
        2 { Register-Check -Name "Automatic HTTPS" -Status PASS -Message "Always upgrade to HTTPS" }
    }
} else {
    Register-Check -Name "Automatic HTTPS" -Status INFO -Message "Not configured"
}

# Site Isolation
$siteIsolation = Get-ItemProperty $edgePolicies -Name "SitePerProcess" -ErrorAction SilentlyContinue
if ($siteIsolation -and $siteIsolation.SitePerProcess -eq 1) {
    Register-Check -Name "Site Isolation" -Status PASS -Message "Enforced"
} else {
    Register-Check -Name "Site Isolation" -Status INFO -Message "Default (enabled for high-value sites)"
}

# Tracking Prevention
$trackingPrevention = Get-ItemProperty $edgePolicies -Name "TrackingPrevention" -ErrorAction SilentlyContinue
if ($trackingPrevention) {
    switch ($trackingPrevention.TrackingPrevention) {
        0 { Register-Check -Name "Tracking Prevention" -Status WARN -Message "Off" }
        1 { Register-Check -Name "Tracking Prevention" -Status INFO -Message "Basic" }
        2 { Register-Check -Name "Tracking Prevention" -Status PASS -Message "Balanced" }
        3 { Register-Check -Name "Tracking Prevention" -Status PASS -Message "Strict" }
    }
}

# ============================================================================
# EXTENSION POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Extension Policies ==="

# Extension installation blocklist (AC-6 - Least Privilege)
$extBlocklist = Get-ItemProperty $edgePolicies -Name "ExtensionInstallBlocklist" -ErrorAction SilentlyContinue
if ($extBlocklist) {
    Register-Check -Name "Extension Blocklist" -Status PASS -Message "Configured"
} else {
    Register-Check -Name "Extension Blocklist" -Status INFO -Message "Not configured"
}

# Extension installation allowlist
$extAllowlist = Get-ItemProperty $edgePolicies -Name "ExtensionInstallAllowlist" -ErrorAction SilentlyContinue
if ($extAllowlist) {
    Register-Check -Name "Extension Allowlist" -Status PASS -Message "Configured (whitelist mode)"
}

# Force-installed extensions (managed extensions)
$forcedExt = Get-ItemProperty $edgePolicies -Name "ExtensionInstallForcelist" -ErrorAction SilentlyContinue
if ($forcedExt) {
    Register-Check -Name "Force-Installed Extensions" -Status INFO -Message "Configured"
}

# Block external extensions
$blockExternal = Get-ItemProperty $edgePolicies -Name "BlockExternalExtensions" -ErrorAction SilentlyContinue
if ($blockExternal -and $blockExternal.BlockExternalExtensions -eq 1) {
    Register-Check -Name "Block External Extensions" -Status PASS -Message "Enabled"
} else {
    Register-Check -Name "Block External Extensions" -Status WARN -Message "Not enforced"
}

# Developer mode extensions
$devModeBlock = Get-ItemProperty $edgePolicies -Name "DeveloperToolsAvailability" -ErrorAction SilentlyContinue
if ($devModeBlock) {
    switch ($devModeBlock.DeveloperToolsAvailability) {
        0 { Register-Check -Name "Developer Tools" -Status PASS -Message "Disabled" }
        1 { Register-Check -Name "Developer Tools" -Status INFO -Message "Allowed on enterprise policy installed" }
        2 { Register-Check -Name "Developer Tools" -Status INFO -Message "Always allowed" }
    }
}

# ============================================================================
# PRIVACY AND DATA POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Privacy and Data Policies ==="

# Sync disabled (data protection)
$syncDisabled = Get-ItemProperty $edgePolicies -Name "SyncDisabled" -ErrorAction SilentlyContinue
if ($syncDisabled -and $syncDisabled.SyncDisabled -eq 1) {
    Register-Check -Name "Browser Sync" -Status PASS -Message "Disabled (data protection)"
} else {
    Register-Check -Name "Browser Sync" -Status INFO -Message "Enabled or not configured"
}

# Browser sign-in
$browserSignin = Get-ItemProperty $edgePolicies -Name "BrowserSignin" -ErrorAction SilentlyContinue
if ($browserSignin) {
    switch ($browserSignin.BrowserSignin) {
        0 { Register-Check -Name "Browser Sign-in" -Status PASS -Message "Disabled" }
        1 { Register-Check -Name "Browser Sign-in" -Status INFO -Message "Enabled" }
        2 { Register-Check -Name "Browser Sign-in" -Status INFO -Message "Forced" }
    }
}

# Guest mode
$guestMode = Get-ItemProperty $edgePolicies -Name "BrowserGuestModeEnabled" -ErrorAction SilentlyContinue
if ($guestMode -and $guestMode.BrowserGuestModeEnabled -eq 0) {
    Register-Check -Name "Guest Mode" -Status PASS -Message "Disabled"
} else {
    Register-Check -Name "Guest Mode" -Status INFO -Message "Enabled or not configured"
}

# InPrivate mode
$inPrivate = Get-ItemProperty $edgePolicies -Name "InPrivateModeAvailability" -ErrorAction SilentlyContinue
if ($inPrivate) {
    switch ($inPrivate.InPrivateModeAvailability) {
        0 { Register-Check -Name "InPrivate Mode" -Status INFO -Message "Enabled" }
        1 { Register-Check -Name "InPrivate Mode" -Status PASS -Message "Disabled" }
        2 { Register-Check -Name "InPrivate Mode" -Status INFO -Message "Forced" }
    }
}

# Autofill (PCI DSS consideration)
Get-ItemProperty $edgePolicies -Name "AutofillAddressEnabled" -ErrorAction SilentlyContinue | Out-Null
$autofillCredit = Get-ItemProperty $edgePolicies -Name "AutofillCreditCardEnabled" -ErrorAction SilentlyContinue

if ($autofillCredit -and $autofillCredit.AutofillCreditCardEnabled -eq 0) {
    Register-Check -Name "Credit Card Autofill" -Status PASS -Message "Disabled"
} else {
    Register-Check -Name "Credit Card Autofill" -Status WARN -Message "Enabled - consider disabling for PCI compliance"
}

# ============================================================================
# DOWNLOAD AND FILE POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Download Policies ==="

# Download restrictions
$downloadRestrictions = Get-ItemProperty $edgePolicies -Name "DownloadRestrictions" -ErrorAction SilentlyContinue
if ($downloadRestrictions) {
    switch ($downloadRestrictions.DownloadRestrictions) {
        0 { Register-Check -Name "Download Restrictions" -Status INFO -Message "No restrictions" }
        1 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block dangerous downloads" }
        2 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block dangerous and unwanted" }
        3 { Register-Check -Name "Download Restrictions" -Status PASS -Message "Block all downloads" }
    }
}

# Default download directory
$downloadDir = Get-ItemProperty $edgePolicies -Name "DownloadDirectory" -ErrorAction SilentlyContinue
if ($downloadDir) {
    Register-Check -Name "Default Download Directory" -Status INFO -Message "Configured: $($downloadDir.DownloadDirectory)"
}

# Prompt for download location
$downloadPrompt = Get-ItemProperty $edgePolicies -Name "PromptForDownloadLocation" -ErrorAction SilentlyContinue
if ($downloadPrompt -and $downloadPrompt.PromptForDownloadLocation -eq 1) {
    Register-Check -Name "Download Location Prompt" -Status INFO -Message "Enabled"
}

# ============================================================================
# NETWORK AND PROXY POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Network Policies ==="

# Proxy settings
$proxyMode = Get-ItemProperty $edgePolicies -Name "ProxyMode" -ErrorAction SilentlyContinue
if ($proxyMode) {
    Register-Check -Name "Proxy Mode" -Status INFO -Message $proxyMode.ProxyMode
}

# DNS over HTTPS
$dnsOverHttps = Get-ItemProperty $edgePolicies -Name "DnsOverHttpsMode" -ErrorAction SilentlyContinue
if ($dnsOverHttps) {
    switch ($dnsOverHttps.DnsOverHttpsMode) {
        "off" { Register-Check -Name "DNS over HTTPS" -Status INFO -Message "Disabled" }
        "automatic" { Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Automatic" }
        "secure" { Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Secure (enforced)" }
    }
}

# QUIC protocol
$quicAllowed = Get-ItemProperty $edgePolicies -Name "QuicAllowed" -ErrorAction SilentlyContinue
if ($quicAllowed -and $quicAllowed.QuicAllowed -eq 0) {
    Register-Check -Name "QUIC Protocol" -Status INFO -Message "Disabled"
} else {
    Register-Check -Name "QUIC Protocol" -Status INFO -Message "Enabled"
}

# ============================================================================
# AUTHENTICATION POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Authentication Policies ==="

# Windows Hello for web auth
$webAuthn = Get-ItemProperty $edgePolicies -Name "WebAuthenticationEnabled" -ErrorAction SilentlyContinue
if ($webAuthn -and $webAuthn.WebAuthenticationEnabled -eq 1) {
    Register-Check -Name "Web Authentication (FIDO2)" -Status PASS -Message "Enabled"
}

# HTTP authentication
$httpAuth = Get-ItemProperty $edgePolicies -Name "AuthSchemes" -ErrorAction SilentlyContinue
if ($httpAuth) {
    Register-Check -Name "HTTP Auth Schemes" -Status INFO -Message $httpAuth.AuthSchemes
}

# NTLM authentication
$ntlmAuth = Get-ItemProperty $edgePolicies -Name "NtlmV2Enabled" -ErrorAction SilentlyContinue
if ($ntlmAuth -and $ntlmAuth.NtlmV2Enabled -eq 1) {
    Register-Check -Name "NTLMv2" -Status PASS -Message "Enforced"
}

# ============================================================================
# CONTENT SETTINGS
# ============================================================================
Write-Output ""
Write-Output "=== Content Settings ==="

# JavaScript
$jsBlocked = Get-ItemProperty $edgePolicies -Name "DefaultJavaScriptSetting" -ErrorAction SilentlyContinue
if ($jsBlocked) {
    switch ($jsBlocked.DefaultJavaScriptSetting) {
        1 { Register-Check -Name "JavaScript" -Status INFO -Message "Allowed" }
        2 { Register-Check -Name "JavaScript" -Status WARN -Message "Blocked (may break sites)" }
    }
}

# Pop-ups
$popupsBlocked = Get-ItemProperty $edgePolicies -Name "DefaultPopupsSetting" -ErrorAction SilentlyContinue
if ($popupsBlocked -and $popupsBlocked.DefaultPopupsSetting -eq 2) {
    Register-Check -Name "Pop-ups" -Status PASS -Message "Blocked"
} else {
    Register-Check -Name "Pop-ups" -Status INFO -Message "Allowed"
}

# Geolocation
$geoBlocked = Get-ItemProperty $edgePolicies -Name "DefaultGeolocationSetting" -ErrorAction SilentlyContinue
if ($geoBlocked -and $geoBlocked.DefaultGeolocationSetting -eq 2) {
    Register-Check -Name "Geolocation" -Status PASS -Message "Blocked by default"
}

# Notifications
$notifBlocked = Get-ItemProperty $edgePolicies -Name "DefaultNotificationsSetting" -ErrorAction SilentlyContinue
if ($notifBlocked -and $notifBlocked.DefaultNotificationsSetting -eq 2) {
    Register-Check -Name "Notifications" -Status PASS -Message "Blocked by default"
}

# Clipboard access
$clipboardBlocked = Get-ItemProperty $edgePolicies -Name "DefaultClipboardSetting" -ErrorAction SilentlyContinue
if ($clipboardBlocked -and $clipboardBlocked.DefaultClipboardSetting -eq 2) {
    Register-Check -Name "Clipboard Access" -Status PASS -Message "Blocked by default"
}

# ============================================================================
# TLS/SSL SETTINGS
# ============================================================================
Write-Output ""
Write-Output "=== TLS/SSL Settings ==="

# Minimum TLS version
$sslVersionMin = Get-ItemProperty $edgePolicies -Name "SSLVersionMin" -ErrorAction SilentlyContinue
if ($sslVersionMin) {
    if ($sslVersionMin.SSLVersionMin -eq "tls1.2") {
        Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.2"
    } elseif ($sslVersionMin.SSLVersionMin -eq "tls1.3") {
        Register-Check -Name "Minimum TLS Version" -Status PASS -Message "TLS 1.3"
    } else {
        Register-Check -Name "Minimum TLS Version" -Status WARN -Message $sslVersionMin.SSLVersionMin
    }
} else {
    Register-Check -Name "Minimum TLS Version" -Status INFO -Message "Not configured (default)"
}

# SSL error override
$sslErrorOverride = Get-ItemProperty $edgePolicies -Name "SSLErrorOverrideAllowed" -ErrorAction SilentlyContinue
if ($sslErrorOverride -and $sslErrorOverride.SSLErrorOverrideAllowed -eq 0) {
    Register-Check -Name "SSL Error Override" -Status PASS -Message "Blocked"
} else {
    Register-Check -Name "SSL Error Override" -Status WARN -Message "Users can bypass SSL errors"
}

# ============================================================================
# ENTERPRISE FEATURES
# ============================================================================
Write-Output ""
Write-Output "=== Enterprise Features ==="

# IE Mode
$ieMode = Get-ItemProperty $edgePolicies -Name "InternetExplorerIntegrationLevel" -ErrorAction SilentlyContinue
if ($ieMode) {
    switch ($ieMode.InternetExplorerIntegrationLevel) {
        0 { Register-Check -Name "IE Mode" -Status PASS -Message "Disabled" }
        1 { Register-Check -Name "IE Mode" -Status INFO -Message "IE Mode enabled" }
        2 { Register-Check -Name "IE Mode" -Status WARN -Message "IE11 (legacy)" }
    }
}

# Edge Collections
$collections = Get-ItemProperty $edgePolicies -Name "EdgeCollectionsEnabled" -ErrorAction SilentlyContinue
if ($collections -and $collections.EdgeCollectionsEnabled -eq 0) {
    Register-Check -Name "Edge Collections" -Status INFO -Message "Disabled"
}

# Bing Chat / Copilot
$copilot = Get-ItemProperty $edgePolicies -Name "HubsSidebarEnabled" -ErrorAction SilentlyContinue
if ($copilot -and $copilot.HubsSidebarEnabled -eq 0) {
    Register-Check -Name "Edge Sidebar/Copilot" -Status INFO -Message "Disabled"
} else {
    Register-Check -Name "Edge Sidebar/Copilot" -Status INFO -Message "Enabled"
}

# ============================================================================
# AUDIT LOGGING
# ============================================================================
Write-Output ""
Write-Output "=== Audit and Logging ==="

# Check if Edge browsing data is being logged/forwarded
$auditMode = Get-ItemProperty $edgePolicies -Name "AuditReportingEnabled" -ErrorAction SilentlyContinue
if ($auditMode -and $auditMode.AuditReportingEnabled -eq 1) {
    Register-Check -Name "Edge Audit Reporting" -Status PASS -Message "Enabled"
}

# URL Logging
$urlLogging = Get-ItemProperty $edgePolicies -Name "UrlLogsEnabled" -ErrorAction SilentlyContinue
if ($urlLogging -and $urlLogging.UrlLogsEnabled -eq 1) {
    Register-Check -Name "URL Logging" -Status INFO -Message "Enabled"
}

# Clear browsing data on exit
$clearOnExit = Get-ItemProperty $edgePolicies -Name "ClearBrowsingDataOnExit" -ErrorAction SilentlyContinue
if ($clearOnExit -and $clearOnExit.ClearBrowsingDataOnExit -eq 1) {
    Register-Check -Name "Clear Data on Exit" -Status INFO -Message "Enabled"
}

# Check policy application
$policyCount = (Get-ItemProperty $edgePolicies -ErrorAction SilentlyContinue).PSObject.Properties.Count
if ($policyCount -gt 2) {
    Register-Check -Name "Edge Policy Summary" -Status PASS -Message "$policyCount policies configured via GPO/MDM"
} else {
    Register-Check -Name "Edge Policy Summary" -Status WARN -Message "Few or no policies configured - apply security baseline"
}

Print-Summary
Exit-Audit
