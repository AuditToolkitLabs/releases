# Check Edge Browser Download Policy
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge" -Name "DownloadRestrictions" -ErrorAction SilentlyContinue
    if ($reg.DownloadRestrictions -eq 3) {
        Register-Check -Name "Edge Download Restrictions" -Status PASS -Message "Block all downloads."
    } else {
        Register-Check -Name "Edge Download Restrictions" -Status FAIL -Message "Not set to block all downloads."
    }
} catch {
    Register-Check -Name "Edge Download Restrictions" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit