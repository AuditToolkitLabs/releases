<#
.SYNOPSIS
    Mozilla Firefox Browser Security Audit

.DESCRIPTION
    Comprehensive security audit for Mozilla Firefox:
    - Installation and version
    - Update configuration
    - Extension/add-on security
    - Privacy settings
    - Certificate handling
    - Policy enforcement
    - Telemetry settings

.NOTES
    @elevation: partial
    @elevation-reason: HKLM registry policies require admin; user profile and policies.json work without elevation
    Requires: Firefox installed

Compliance Mapping:
- CIS Controls: 7.1 (Browser Configuration), 9.1 (Limit Use of Browser)
- NIST SP 800-53: CM-7 (Least Functionality), SC-18 (Mobile Code)
- Mozilla Enterprise Policy Documentation
- MITRE ATT&CK: T1189 (Drive-by Compromise), T1185 (Browser Session Hijacking)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Mozilla Firefox Browser Security Audit"

# ============================================================================
# FIREFOX INSTALLATION CHECK
# ============================================================================
Write-Section "Firefox Installation"

$firefoxInstalled = $false
$firefoxPath = $null
$firefoxVersion = $null

# Check common installation paths
$firefoxPaths = @(
    "${env:ProgramFiles}\Mozilla Firefox\firefox.exe",
    "${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe",
    "${env:LocalAppData}\Mozilla Firefox\firefox.exe"
)

foreach ($path in $firefoxPaths) {
    if (Test-Path $path) {
        $firefoxInstalled = $true
        $firefoxPath = $path
        break
    }
}

if ($firefoxInstalled) {
    Register-Check -Name "Firefox Installation" -Status PASS -Message "Found at $firefoxPath"

    # Get version
    try {
        $firefoxVersion = (Get-Item $firefoxPath).VersionInfo.ProductVersion
        Register-Check -Name "Firefox Version" -Status INFO -Message $firefoxVersion

        # Check if version is recent (Firefox ESR or regular)
        $majorVersion = [int]($firefoxVersion.Split('.')[0])
        if ($majorVersion -ge 115) {
            Register-Check -Name "Firefox Currency" -Status PASS -Message "Recent version"
        } else {
            Register-Check -Name "Firefox Currency" -Status WARN -Message "May be outdated"
        }
    } catch {
        Register-Check -Name "Firefox Version" -Status WARN -Message "Cannot determine"
    }
} else {
    Register-Check -Name "Firefox Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# Check for ESR version
if ($firefoxVersion -and $firefoxVersion -match 'esr') {
    Register-Check -Name "Firefox Edition" -Status INFO -Message "ESR (Extended Support Release)"
} else {
    Register-Check -Name "Firefox Edition" -Status INFO -Message "Standard release"
}

# ============================================================================
# FIREFOX POLICIES
# ============================================================================
Write-Section "Firefox Enterprise Policies"

$policyPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"
$policyPathWow = "HKLM:\SOFTWARE\WOW6432Node\Policies\Mozilla\Firefox"

# Determine which policy path exists
$activePolicyPath = if (Test-Path $policyPath) { $policyPath } elseif (Test-Path $policyPathWow) { $policyPathWow } else { $null }

if ($activePolicyPath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "Configured"

    # Disable telemetry
    try {
        $telemetry = Get-ItemProperty -Path $activePolicyPath -Name "DisableTelemetry" -ErrorAction SilentlyContinue
        if ($telemetry -and $telemetry.DisableTelemetry -eq 1) {
            Register-Check -Name "Telemetry" -Status PASS -Message "Disabled"
        } else {
            Register-Check -Name "Telemetry" -Status WARN -Message "Enabled or user controlled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # App update
    try {
        $appUpdate = Get-ItemProperty -Path $activePolicyPath -Name "DisableAppUpdate" -ErrorAction SilentlyContinue
        if ($appUpdate -and $appUpdate.DisableAppUpdate -eq 1) {
            Register-Check -Name "App Updates" -Status WARN -Message "Disabled (managed externally?)"
        } else {
            Register-Check -Name "App Updates" -Status PASS -Message "Enabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Firefox accounts
    try {
        $ffAccounts = Get-ItemProperty -Path $activePolicyPath -Name "DisableFirefoxAccounts" -ErrorAction SilentlyContinue
        if ($ffAccounts -and $ffAccounts.DisableFirefoxAccounts -eq 1) {
            Register-Check -Name "Firefox Accounts" -Status PASS -Message "Disabled (enterprise)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Pocket
    try {
        $pocket = Get-ItemProperty -Path $activePolicyPath -Name "DisablePocket" -ErrorAction SilentlyContinue
        if ($pocket -and $pocket.DisablePocket -eq 1) {
            Register-Check -Name "Pocket Integration" -Status PASS -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Password manager
    try {
        $pwdMgr = Get-ItemProperty -Path "$activePolicyPath" -Name "PasswordManagerEnabled" -ErrorAction SilentlyContinue
        if ($pwdMgr -and $pwdMgr.PasswordManagerEnabled -eq 0) {
            Register-Check -Name "Password Manager" -Status PASS -Message "Disabled (use external)"
        } else {
            Register-Check -Name "Password Manager" -Status INFO -Message "Enabled or user controlled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Private browsing
    try {
        $privateBrowsing = Get-ItemProperty -Path $activePolicyPath -Name "DisablePrivateBrowsing" -ErrorAction SilentlyContinue
        if ($privateBrowsing -and $privateBrowsing.DisablePrivateBrowsing -eq 1) {
            Register-Check -Name "Private Browsing" -Status INFO -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Developer tools
    try {
        $devTools = Get-ItemProperty -Path $activePolicyPath -Name "DisableDeveloperTools" -ErrorAction SilentlyContinue
        if ($devTools -and $devTools.DisableDeveloperTools -eq 1) {
            Register-Check -Name "Developer Tools" -Status INFO -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Safe mode
    try {
        $safeMode = Get-ItemProperty -Path $activePolicyPath -Name "DisableSafeMode" -ErrorAction SilentlyContinue
        if ($safeMode -and $safeMode.DisableSafeMode -eq 1) {
            Register-Check -Name "Safe Mode" -Status INFO -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

} else {
    Register-Check -Name "Enterprise Policies" -Status INFO -Message "Not configured via GPO"
}

# ============================================================================
# EXTENSION POLICIES
# ============================================================================
Write-Section "Extension Security"

if ($activePolicyPath) {
    # Extension installation blocked
    try {
        $extInstall = Get-ItemProperty -Path $activePolicyPath -Name "BlockAboutAddons" -ErrorAction SilentlyContinue
        if ($extInstall -and $extInstall.BlockAboutAddons -eq 1) {
            Register-Check -Name "Add-ons Page" -Status PASS -Message "Blocked"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Extension install sources
    try {
        $extSources = Get-ItemProperty -Path "$activePolicyPath\InstallAddonsPermission" -Name "Default" -ErrorAction SilentlyContinue
        if ($extSources -and $extSources.Default -eq 0) {
            Register-Check -Name "Addon Install" -Status PASS -Message "Blocked by default"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Check blocked extensions
    try {
        $blockedExt = Get-ChildItem -Path "$activePolicyPath\Extensions\Uninstall" -ErrorAction SilentlyContinue
        if ($blockedExt) {
            Register-Check -Name "Blocked Extensions" -Status INFO -Message "$($blockedExt.Count) extension(s)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# CERTIFICATES
# ============================================================================
Write-Section "Certificate Settings"

if ($activePolicyPath) {
    # Import enterprise roots
    try {
        $certImport = Get-ItemProperty -Path "$activePolicyPath\Certificates" -Name "ImportEnterpriseRoots" -ErrorAction SilentlyContinue
        if ($certImport -and $certImport.ImportEnterpriseRoots -eq 1) {
            Register-Check -Name "Enterprise Root Certs" -Status PASS -Message "Imported from Windows"
        } else {
            Register-Check -Name "Enterprise Root Certs" -Status INFO -Message "Firefox cert store only"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# SECURITY PREFERENCES
# ============================================================================
Write-Section "Security Preferences"

if ($activePolicyPath) {
    # Check Preferences subkey
    $prefsPath = "$activePolicyPath\Preferences"

    if (Test-Path $prefsPath) {
        # Enhanced Tracking Protection
        try {
            $etp = Get-ItemProperty -Path $prefsPath -Name "privacy.trackingprotection.enabled" -ErrorAction SilentlyContinue
            if ($etp -and $etp.'privacy.trackingprotection.enabled' -eq 1) {
                Register-Check -Name "Tracking Protection" -Status PASS -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Cryptomining protection
        try {
            $cryptomining = Get-ItemProperty -Path $prefsPath -Name "privacy.trackingprotection.cryptomining.enabled" -ErrorAction SilentlyContinue
            if ($cryptomining -and $cryptomining.'privacy.trackingprotection.cryptomining.enabled' -eq 1) {
                Register-Check -Name "Cryptomining Protection" -Status PASS -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Fingerprinting protection
        try {
            $fingerprinting = Get-ItemProperty -Path $prefsPath -Name "privacy.trackingprotection.fingerprinting.enabled" -ErrorAction SilentlyContinue
            if ($fingerprinting -and $fingerprinting.'privacy.trackingprotection.fingerprinting.enabled' -eq 1) {
                Register-Check -Name "Fingerprinting Protection" -Status PASS -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # DoH
        try {
            $dohMode = Get-ItemProperty -Path $prefsPath -Name "network.trr.mode" -ErrorAction SilentlyContinue
            if ($dohMode) {
                switch ($dohMode.'network.trr.mode') {
                    0 { Register-Check -Name "DNS over HTTPS" -Status INFO -Message "Disabled" }
                    2 { Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Enabled (fallback)" }
                    3 { Register-Check -Name "DNS over HTTPS" -Status PASS -Message "Enabled (required)" }
                    5 { Register-Check -Name "DNS over HTTPS" -Status INFO -Message "Off by choice" }
                }
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # HTTPS-Only Mode
        try {
            $httpsOnly = Get-ItemProperty -Path $prefsPath -Name "dom.security.https_only_mode" -ErrorAction SilentlyContinue
            if ($httpsOnly -and $httpsOnly.'dom.security.https_only_mode' -eq 1) {
                Register-Check -Name "HTTPS-Only Mode" -Status PASS -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# PROXY SETTINGS
# ============================================================================
Write-Section "Proxy Configuration"

if ($activePolicyPath) {
    try {
        $proxy = Get-ItemProperty -Path "$activePolicyPath\Proxy" -ErrorAction SilentlyContinue
        if ($proxy) {
            if ($proxy.Mode -eq 'system') {
                Register-Check -Name "Proxy Configuration" -Status INFO -Message "Uses system proxy"
            } elseif ($proxy.Mode -eq 'manual') {
                Register-Check -Name "Proxy Configuration" -Status INFO -Message "Manual proxy configured"
            } elseif ($proxy.Mode -eq 'none') {
                Register-Check -Name "Proxy Configuration" -Status INFO -Message "No proxy"
            } elseif ($proxy.Locked -eq 1) {
                Register-Check -Name "Proxy Locked" -Status PASS -Message "User cannot change"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# USER PROFILE CHECK
# ============================================================================
Write-Section "User Profile"

$firefoxProfilePath = "$env:AppData\Mozilla\Firefox\Profiles"
if (Test-Path $firefoxProfilePath) {
    try {
        $profiles = Get-ChildItem -Path $firefoxProfilePath -Directory -ErrorAction SilentlyContinue
        if ($profiles) {
            Register-Check -Name "Firefox Profiles" -Status INFO -Message "$($profiles.Count) profile(s)"

            # Check for extensions in profile
            foreach ($firefoxProfile in $profiles | Select-Object -First 1) {
                $extPath = Join-Path $firefoxProfile.FullName "extensions"
                if (Test-Path $extPath) {
                    $userExts = Get-ChildItem -Path $extPath -ErrorAction SilentlyContinue
                    if ($userExts) {
                        Register-Check -Name "User Extensions" -Status INFO -Message "$($userExts.Count) extension(s)"
                    }
                }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# POLICIES.JSON CHECK
# ============================================================================
Write-Section "Policies File"

$policiesJsonPath = Split-Path $firefoxPath -Parent
$policiesJson = Join-Path $policiesJsonPath "distribution\policies.json"

if (Test-Path $policiesJson) {
    Register-Check -Name "Policies.json" -Status PASS -Message "Found"

    try {
        $policies = Get-Content $policiesJson -Raw | ConvertFrom-Json

        if ($policies.policies) {
            $policyCount = ($policies.policies | Get-Member -MemberType NoteProperty).Count
            Register-Check -Name "JSON Policies" -Status INFO -Message "$policyCount policy/policies defined"
        }
    } catch {
        Register-Check -Name "Policies.json" -Status WARN -Message "Cannot parse"
    }
} else {
    Register-Check -Name "Policies.json" -Status INFO -Message "Not present"
}

Print-Summary
Exit-Audit
