<#
OneDrive Sync Restrictions Audit (Manual Review)

Compliance Mapping:
- CIS Controls: 4.1, 4.2, 13.1, 16.11
- NIST SP 800-53: AC-3, AC-6, SC-7, SC-13, SI-2
- ISO 27001: A.9.1, A.10.1, A.13.1, A.13.2
- OWASP ASVS: V10
- UK NCSC: Secure Configuration, Data at Rest
- PCI DSS: 1.1, 1.2, 1.3, 10.2

Each check in this script is annotated in comments with relevant compliance mappings.
#>
# Check OneDrive Sync Restrictions (Manual Review)
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
Register-Check -Name "OneDrive Sync Restrictions (Manual)" -Status WARN -Message "Review OneDrive sync restrictions and policy settings manually."
Print-Summary
Exit-Audit
