# Check OneDrive Sync Restrictions
Import-Module "$PSScriptRoot/../common/common-audit.psm1"
try {
    $reg = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\OneDrive" -Name "DisableFileSync" -ErrorAction SilentlyContinue
    if ($reg.DisableFileSync -eq 1) {
        Register-Check -Name "OneDrive Sync Restrictions" -Status PASS -Message "File sync is disabled by policy."
    } else {
        Register-Check -Name "OneDrive Sync Restrictions" -Status FAIL -Message "File sync is not disabled by policy."
    }
} catch {
    Register-Check -Name "OneDrive Sync Restrictions" -Status WARN -Message $_.Exception.Message
}
Print-Summary
Exit-Audit