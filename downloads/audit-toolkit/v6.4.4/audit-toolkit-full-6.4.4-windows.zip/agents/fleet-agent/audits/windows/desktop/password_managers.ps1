<#
.SYNOPSIS
    Password Manager Security Audit

.DESCRIPTION
    Security audit for common password managers:
    - LastPass
    - 1Password
    - Bitwarden
    - KeePass/KeePassXC
    - Dashlane
    Installation verification and configuration audit

.NOTES
    @elevation: partial
    @elevation-reason: HKLM policy paths require admin; user-level configs and app detection work without elevation
    Checks for multiple password managers

Compliance Mapping:
- CIS Controls: 5.2 (Use Unique Passwords), 5.3 (Disable Dormant Accounts)
- NIST SP 800-53: IA-5 (Authenticator Management)
- NIST SP 800-63B: Digital Identity Guidelines
- MITRE ATT&CK: T1555 (Credentials from Password Stores)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Password Manager Security Audit"

$passwordManagerFound = $false

# ============================================================================
# LASTPASS
# ============================================================================
Write-Section "LastPass"

$lastPassPaths = @(
    "${env:ProgramFiles}\LastPass\lastpass.exe",
    "${env:ProgramFiles(x86)}\LastPass\lastpass.exe",
    "${env:LocalAppData}\LastPass\lastpass.exe"
)

$lastPassInstalled = $false
foreach ($path in $lastPassPaths) {
    if (Test-Path $path) {
        $lastPassInstalled = $true
        $passwordManagerFound = $true
        Register-Check -Name "LastPass" -Status PASS -Message "Installed"

        # Get version
        try {
            $lpVersion = (Get-Item $path).VersionInfo.ProductVersion
            Register-Check -Name "LastPass Version" -Status INFO -Message $lpVersion
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

# Check for LastPass browser extension
$lpBrowserExt = Get-ChildItem -Path "${env:LocalAppData}\Google\Chrome\User Data\Default\Extensions" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq 'hdokiejnpimakedhajhdlcegeplioahd' }
if ($lpBrowserExt) {
    Register-Check -Name "LastPass Chrome Extension" -Status INFO -Message "Installed"
    $passwordManagerFound = $true
}

if ($lastPassInstalled) {
    # Check LastPass policies
    $lpPolicyPath = "HKLM:\SOFTWARE\Policies\LastPass"
    if (Test-Path $lpPolicyPath) {
        Register-Check -Name "LastPass Policies" -Status PASS -Message "GPO configured"

        # MFA enforcement
        try {
            $mfa = Get-ItemProperty -Path $lpPolicyPath -Name "RequireMFA" -ErrorAction SilentlyContinue
            if ($mfa -and $mfa.RequireMFA -eq 1) {
                Register-Check -Name "LastPass MFA" -Status PASS -Message "Required"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    # Local cache (security consideration)
    $lpCachePath = "${env:LocalAppData}\LastPass"
    if (Test-Path $lpCachePath) {
        Register-Check -Name "LastPass Cache" -Status INFO -Message "Local vault cache present"
    }
}

# ============================================================================
# 1PASSWORD
# ============================================================================
Write-Section "1Password"

$onePasswordPaths = @(
    "${env:ProgramFiles}\1Password\app\1Password.exe",
    "${env:LocalAppData}\1Password\app\1Password.exe"
)

$onePasswordInstalled = $false
foreach ($path in $onePasswordPaths) {
    if (Test-Path $path) {
        $onePasswordInstalled = $true
        $passwordManagerFound = $true
        Register-Check -Name "1Password" -Status PASS -Message "Installed"

        try {
            $opVersion = (Get-Item $path).VersionInfo.ProductVersion
            Register-Check -Name "1Password Version" -Status INFO -Message $opVersion

            # 1Password 8+ has improved security features
            if (($opVersion -split '\.')[0] -ge 8) {
                Register-Check -Name "1Password Version" -Status PASS -Message "Version 8+ (current architecture)"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

if ($onePasswordInstalled) {
    # Check for 1Password CLI
    $opCli = Get-Command "op.exe" -ErrorAction SilentlyContinue
    if ($opCli) {
        Register-Check -Name "1Password CLI" -Status INFO -Message "Installed"
    }

    # Check lock settings
    $opConfigPath = "${env:LocalAppData}\1Password\settings\settings.json"
    if (Test-Path $opConfigPath) {
        try {
            $opConfig = Get-Content $opConfigPath -Raw | ConvertFrom-Json

            # Auto-lock timeout
            if ($opConfig.security.autoLock) {
                Register-Check -Name "1Password Auto-Lock" -Status PASS -Message "Configured"
            }

            # Clipboard clearing
            if ($opConfig.security.clearClipboard) {
                Register-Check -Name "1Password Clipboard Clear" -Status PASS -Message "Enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    # Check for browser integration
    Register-Check -Name "1Password Browser Integration" -Status INFO -Message "Verify browser extension is from official source"
}

# ============================================================================
# BITWARDEN
# ============================================================================
Write-Section "Bitwarden"

$bitwardenPaths = @(
    "${env:ProgramFiles}\Bitwarden\Bitwarden.exe",
    "${env:LocalAppData}\Programs\Bitwarden\Bitwarden.exe",
    "${env:AppData}\Bitwarden\Bitwarden.exe"
)

$bitwardenInstalled = $false
foreach ($path in $bitwardenPaths) {
    if (Test-Path $path) {
        $bitwardenInstalled = $true
        $passwordManagerFound = $true
        Register-Check -Name "Bitwarden" -Status PASS -Message "Installed"

        try {
            $bwVersion = (Get-Item $path).VersionInfo.ProductVersion
            Register-Check -Name "Bitwarden Version" -Status INFO -Message $bwVersion
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

if ($bitwardenInstalled) {
    # Check Bitwarden CLI
    $bwCli = Get-Command "bw.exe" -ErrorAction SilentlyContinue
    if ($bwCli) {
        Register-Check -Name "Bitwarden CLI" -Status INFO -Message "Installed"
    }

    # Config path
    $bwConfigPath = "${env:AppData}\Bitwarden"
    if (Test-Path $bwConfigPath) {
        # Check for self-hosted configuration
        $bwDataPath = Join-Path $bwConfigPath "data.json"
        if (Test-Path $bwDataPath) {
            try {
                $bwData = Get-Content $bwDataPath -Raw | ConvertFrom-Json
                if ($bwData.environmentUrls -and $bwData.environmentUrls.base) {
                    if ($bwData.environmentUrls.base -notmatch "bitwarden.com") {
                        Register-Check -Name "Bitwarden Server" -Status INFO -Message "Self-hosted: $($bwData.environmentUrls.base)"
                    } else {
                        Register-Check -Name "Bitwarden Server" -Status INFO -Message "Bitwarden cloud"
                    }
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }
    }
}

# ============================================================================
# KEEPASS / KEEPASSXC
# ============================================================================
Write-Section "KeePass / KeePassXC"

$keepassPaths = @(
    "${env:ProgramFiles}\KeePass Password Safe 2\KeePass.exe",
    "${env:ProgramFiles(x86)}\KeePass Password Safe 2\KeePass.exe",
    "${env:ProgramFiles}\KeePassXC\KeePassXC.exe",
    "${env:LocalAppData}\KeePassXC\KeePassXC.exe"
)

$keepassInstalled = $false
$keepassType = $null
foreach ($path in $keepassPaths) {
    if (Test-Path $path) {
        $keepassInstalled = $true
        $passwordManagerFound = $true
        $keepassType = if ($path -match "KeePassXC") { "KeePassXC" } else { "KeePass" }
        Register-Check -Name $keepassType -Status PASS -Message "Installed"

        try {
            $kpVersion = (Get-Item $path).VersionInfo.ProductVersion
            Register-Check -Name "$keepassType Version" -Status INFO -Message $kpVersion
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        break
    }
}

if ($keepassInstalled) {
    if ($keepassType -eq "KeePass") {
        # Check KeePass config
        $kpConfigPath = "${env:AppData}\KeePass\KeePass.config.xml"
        if (Test-Path $kpConfigPath) {
            try {
                [xml]$kpConfig = Get-Content $kpConfigPath

                # Check security settings
                $security = $kpConfig.Configuration.Security
                if ($security) {
                    # Master key on secure desktop
                    if ($security.MasterKeyOnSecureDesktop -eq 'true') {
                        Register-Check -Name "KeePass Secure Desktop" -Status PASS -Message "Enabled"
                    } else {
                        Register-Check -Name "KeePass Secure Desktop" -Status WARN -Message "Disabled"
                    }

                    # Lock workspace on timeout
                    if ($security.WorkspaceLocking.LockAfterTime -gt 0) {
                        Register-Check -Name "KeePass Auto-Lock" -Status PASS -Message "$($security.WorkspaceLocking.LockAfterTime) seconds"
                    }

                    # Clipboard clear
                    if ($security.ClipboardClearAfterSeconds -gt 0) {
                        Register-Check -Name "KeePass Clipboard Clear" -Status PASS -Message "$($security.ClipboardClearAfterSeconds) seconds"
                    }
                }
            } catch { Write-Verbose 'Suppressed non-fatal error.' }
        }

        # Check for plugins (security consideration)
        $kpPluginPath = "${env:ProgramFiles}\KeePass Password Safe 2\Plugins"
        if (Test-Path $kpPluginPath) {
            $plugins = Get-ChildItem -Path $kpPluginPath -Filter "*.plgx" -ErrorAction SilentlyContinue
            if ($plugins) {
                Register-Check -Name "KeePass Plugins" -Status INFO -Message "$($plugins.Count) plugin(s) - verify trusted sources"
            }
        }
    }

    if ($keepassType -eq "KeePassXC") {
        # KeePassXC config
        $kpxcConfigPath = "${env:AppData}\KeePassXC\keepassxc.ini"
        if (Test-Path $kpxcConfigPath) {
            Register-Check -Name "KeePassXC Config" -Status INFO -Message "Configuration present"
        }

        # Browser integration
        $kpxcBrowserPath = "${env:AppData}\KeePassXC\keepassxc-browser"
        if (Test-Path $kpxcBrowserPath) {
            Register-Check -Name "KeePassXC Browser" -Status INFO -Message "Browser integration configured"
        }
    }

    # Check for database files
    $kdbxFiles = Get-ChildItem -Path $env:UserProfile -Filter "*.kdbx" -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 5
    if ($kdbxFiles) {
        Register-Check -Name "KeePass Databases" -Status INFO -Message "$($kdbxFiles.Count) .kdbx file(s) found in profile"
    }
}

# ============================================================================
# DASHLANE
# ============================================================================
Write-Section "Dashlane"

$dashlanePaths = @(
    "${env:ProgramFiles}\Dashlane\Dashlane.exe",
    "${env:LocalAppData}\Dashlane\Dashlane.exe",
    "${env:AppData}\Dashlane\Dashlane.exe"
)

$dashlaneInstalled = $false
foreach ($path in $dashlanePaths) {
    if (Test-Path $path) {
        $dashlaneInstalled = $true
        $passwordManagerFound = $true
        Register-Check -Name "Dashlane" -Status PASS -Message "Installed"
        break
    }
}

# Check Dashlane browser extension
$dashlaneBrowserExt = Get-ChildItem -Path "${env:LocalAppData}\Google\Chrome\User Data\Default\Extensions" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq 'fdjamakpfbbddfjaooikfcpapjohcfmg' }
if ($dashlaneBrowserExt) {
    Register-Check -Name "Dashlane Chrome Extension" -Status INFO -Message "Installed"
    $passwordManagerFound = $true
}

# ============================================================================
# GENERAL PASSWORD MANAGER SECURITY
# ============================================================================
Write-Section "General Security"

if (-not $passwordManagerFound) {
    Register-Check -Name "Password Manager" -Status WARN -Message "None detected - recommend deploying one"
    Print-Summary
    Exit-Audit
}

# Multiple password managers (potential issue)
$pmCount = @($lastPassInstalled, $onePasswordInstalled, $bitwardenInstalled, $keepassInstalled, $dashlaneInstalled) | Where-Object { $_ } | Measure-Object | Select-Object -ExpandProperty Count
if ($pmCount -gt 1) {
    Register-Check -Name "Multiple Managers" -Status WARN -Message "$pmCount password managers installed - consider consolidating"
}

# Check Windows Credential Manager (should not store primary passwords)
try {
    $cmdkeyOutput = cmdkey /list 2>&1
    $genericCreds = ($cmdkeyOutput | Select-String "Type: Generic" | Measure-Object).Count
    if ($genericCreds -gt 10) {
        Register-Check -Name "Windows Credentials" -Status INFO -Message "$genericCreds generic credentials stored"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Browser password storage (recommend disabling if using dedicated manager)
$chromePasswords = "${env:LocalAppData}\Google\Chrome\User Data\Default\Login Data"
if (Test-Path $chromePasswords) {
    Register-Check -Name "Chrome Password Store" -Status INFO -Message "Present - consider disabling if using dedicated manager"
}

$edgePasswords = "${env:LocalAppData}\Microsoft\Edge\User Data\Default\Login Data"
if (Test-Path $edgePasswords) {
    Register-Check -Name "Edge Password Store" -Status INFO -Message "Present - consider disabling if using dedicated manager"
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

Register-Check -Name "Recommendation" -Status INFO -Message "Ensure emergency access is configured"
Register-Check -Name "Recommendation" -Status INFO -Message "Enable 2FA/MFA on password manager account"
Register-Check -Name "Recommendation" -Status INFO -Message "Review shared vault/folder access regularly"

Print-Summary
Exit-Audit
