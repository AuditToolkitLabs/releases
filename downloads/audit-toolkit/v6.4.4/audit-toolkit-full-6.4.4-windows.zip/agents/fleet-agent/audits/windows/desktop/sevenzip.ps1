<#
.SYNOPSIS
    7-Zip Security Audit

.DESCRIPTION
    Security audit for 7-Zip archive utility:
    - Installation and version
    - File associations
    - Context menu integration
    - Archive handling security

.NOTES
    @elevation: partial
    @elevation-reason: Defender preference checks require admin; file and registry reads work without elevation
    Requires: 7-Zip installed

Compliance Mapping:
- CIS Controls: 7.1 (Endpoint Configuration), 10.1 (Deploy Malware Defense)
- NIST SP 800-53: SI-3 (Malicious Code Protection)
- MITRE ATT&CK: T1560 (Archive Collected Data), T1204.002 (Malicious File)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "7-Zip Security Audit"

# ============================================================================
# 7-ZIP INSTALLATION CHECK
# ============================================================================
Write-Section "7-Zip Installation"

$sevenZipInstalled = $false
$sevenZipPath = $null
$sevenZipVersion = $null

# Check common installation paths
$sevenZipPaths = @(
    "${env:ProgramFiles}\7-Zip\7z.exe",
    "${env:ProgramFiles(x86)}\7-Zip\7z.exe"
)

foreach ($path in $sevenZipPaths) {
    if (Test-Path $path) {
        $sevenZipInstalled = $true
        $sevenZipPath = $path
        break
    }
}

if ($sevenZipInstalled) {
    Register-Check -Name "7-Zip Installation" -Status PASS -Message "Found at $sevenZipPath"

    # Get version
    try {
        $sevenZipVersion = (Get-Item $sevenZipPath).VersionInfo.ProductVersion
        Register-Check -Name "7-Zip Version" -Status INFO -Message $sevenZipVersion

        # Check version currency (7-Zip has had critical CVEs)
        $majorVer = [decimal]($sevenZipVersion -replace '\..*','.' + ($sevenZipVersion -split '\.')[1])

        # 7-Zip 23.01 and later includes important security fixes
        if ($majorVer -ge 23.01) {
            Register-Check -Name "Version Currency" -Status PASS -Message "Current (includes recent security fixes)"
        } elseif ($majorVer -ge 21.0) {
            Register-Check -Name "Version Currency" -Status WARN -Message "Consider upgrading to 23.01+"
        } else {
            Register-Check -Name "Version Currency" -Status FAIL -Message "Outdated - upgrade for security fixes"
        }
    } catch {
        Register-Check -Name "7-Zip Version" -Status WARN -Message "Cannot determine"
    }
} else {
    Register-Check -Name "7-Zip Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# 7-ZIP CONFIGURATION
# ============================================================================
Write-Section "7-Zip Configuration"

# 7-Zip registry settings
$sevenZipRegPath = "HKCU:\SOFTWARE\7-Zip"

if (Test-Path $sevenZipRegPath) {
    Register-Check -Name "User Config" -Status INFO -Message "Present"

    # Check path setting (security consideration - ensures legitimate binary)
    try {
        $pathSetting = Get-ItemProperty -Path $sevenZipRegPath -Name "Path" -ErrorAction SilentlyContinue
        if ($pathSetting) {
            if ($pathSetting.Path -like "${env:ProgramFiles}*") {
                Register-Check -Name "Install Path" -Status PASS -Message "Standard location"
            } else {
                Register-Check -Name "Install Path" -Status WARN -Message "Non-standard: $($pathSetting.Path)"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# FILE ASSOCIATIONS
# ============================================================================
Write-Section "File Associations"

# Check which extensions are associated with 7-Zip
$archiveExtensions = @('.7z', '.zip', '.rar', '.tar', '.gz', '.bz2', '.xz', '.cab', '.iso')
$associatedExtensions = @()

foreach ($ext in $archiveExtensions) {
    try {
        $assoc = (cmd /c "assoc $ext" 2>$null)
        cmd /c "ftype 7-Zip*" 2>$null | Out-Null

        if ($assoc -match "7-Zip" -or $assoc -match "7z") {
            $associatedExtensions += $ext
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if ($associatedExtensions.Count -gt 0) {
    Register-Check -Name "Associated Extensions" -Status INFO -Message "$($associatedExtensions.Count): $($associatedExtensions -join ', ')"
} else {
    Register-Check -Name "Associated Extensions" -Status INFO -Message "None detected (or using shell integration)"
}

# Check context menu integration
try {
    $contextMenu = Get-ItemProperty -Path "HKCR:\*\shellex\ContextMenuHandlers\7-Zip" -ErrorAction SilentlyContinue
    if ($contextMenu) {
        Register-Check -Name "Context Menu" -Status INFO -Message "Shell integration enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# 7-ZIP OPTIONS
# ============================================================================
Write-Section "7-Zip Options"

$optionsPath = "$sevenZipRegPath\Options"

if (Test-Path $optionsPath -ErrorAction SilentlyContinue) {
    # Large pages (performance feature)
    try {
        $largePages = Get-ItemProperty -Path $optionsPath -Name "LargePages" -ErrorAction SilentlyContinue
        if ($largePages) {
            Register-Check -Name "Large Pages" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# ARCHIVE SECURITY CONSIDERATIONS
# ============================================================================
Write-Section "Archive Security"

# Check Windows SmartScreen settings (affects downloaded archives)
try {
    $smartScreen = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -ErrorAction SilentlyContinue
    if ($smartScreen -and $smartScreen.SmartScreenEnabled -eq 'Off') {
        Register-Check -Name "SmartScreen" -Status WARN -Message "Disabled - archives not scanned"
    } else {
        Register-Check -Name "SmartScreen" -Status PASS -Message "Enabled for downloads"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check AV real-time scanning for archive types
try {
    $defenderPrefs = Get-MpPreference -ErrorAction SilentlyContinue
    if ($defenderPrefs) {
        $excludedExtensions = $defenderPrefs.ExclusionExtension
        $excludedArchives = $excludedExtensions | Where-Object { $_ -in @('.7z', '.zip', '.rar', '.tar', '.gz') }

        if ($excludedArchives) {
            Register-Check -Name "Defender Exclusions" -Status WARN -Message "Archive types excluded: $($excludedArchives -join ', ')"
        } else {
            Register-Check -Name "Defender Exclusions" -Status PASS -Message "Archive types scanned"
        }

        # Check archive scanning
        if ($defenderPrefs.DisableArchiveScanning -eq $true) {
            Register-Check -Name "Archive Scanning" -Status FAIL -Message "Disabled in Defender"
        } else {
            Register-Check -Name "Archive Scanning" -Status PASS -Message "Enabled in Defender"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# TEMP FILE HANDLING
# ============================================================================
Write-Section "Temp File Handling"

# 7-Zip uses temp for extraction
$tempPath = [System.IO.Path]::GetTempPath()
$sevenZipTempPath = Join-Path $tempPath "7z*"

$tempFiles = Get-ChildItem -Path $sevenZipTempPath -ErrorAction SilentlyContinue
if ($tempFiles) {
    Register-Check -Name "7-Zip Temp Files" -Status INFO -Message "$($tempFiles.Count) temp item(s)"

    # Check for old temp files (cleanup concern)
    $oldTemp = $tempFiles | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) }
    if ($oldTemp) {
        Register-Check -Name "Old Temp Files" -Status WARN -Message "$($oldTemp.Count) file(s) older than 7 days"
    }
} else {
    Register-Check -Name "7-Zip Temp Files" -Status PASS -Message "None found"
}

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Mark of the Web on extracted files
Register-Check -Name "Zone.Identifier" -Status INFO -Message "7-Zip preserves MOTW on extraction (19.00+)"

# Check if alternative archivers exist (potential DLL hijacking)
$alternativeArchivers = @(
    "${env:ProgramFiles}\WinRAR\WinRAR.exe",
    "${env:ProgramFiles(x86)}\WinRAR\WinRAR.exe",
    "${env:ProgramFiles}\WinZip\winzip*.exe"
)

$foundAlternatives = @()
foreach ($alt in $alternativeArchivers) {
    if (Test-Path $alt -ErrorAction SilentlyContinue) {
        $foundAlternatives += Split-Path $alt -Leaf
    }
}

if ($foundAlternatives.Count -gt 0) {
    Register-Check -Name "Other Archivers" -Status INFO -Message "Found: $($foundAlternatives -join ', ')"
}

# DLL search path considerations
$sevenZipDir = Split-Path $sevenZipPath -Parent
$dlls = Get-ChildItem -Path $sevenZipDir -Filter "*.dll" -ErrorAction SilentlyContinue
if ($dlls) {
    Register-Check -Name "7-Zip DLLs" -Status INFO -Message "$($dlls.Count) DLL(s) in install directory"
}

# ============================================================================
# RECENT KNOWN VULNERABILITIES
# ============================================================================
Write-Section "Security Advisories"

# CVE history for version guidance
# CVE-2022-29072: Heap buffer overflow (fixed in 21.07)
# CVE-2023-31102: Remote code execution (fixed in 23.01)

if ($sevenZipVersion) {
    $verNum = [version]($sevenZipVersion -replace ' .*','')

    if ($verNum -lt [version]"21.07") {
        Register-Check -Name "CVE-2022-29072" -Status FAIL -Message "Vulnerable - heap buffer overflow"
    } else {
        Register-Check -Name "CVE-2022-29072" -Status PASS -Message "Patched"
    }

    if ($verNum -lt [version]"23.01") {
        Register-Check -Name "CVE-2023-31102" -Status WARN -Message "May be vulnerable - upgrade recommended"
    } else {
        Register-Check -Name "CVE-2023-31102" -Status PASS -Message "Patched"
    }
}

Print-Summary
Exit-Audit
