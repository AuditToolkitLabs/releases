<#
.SYNOPSIS
    Slack Desktop Security Audit

.DESCRIPTION
    Comprehensive security audit for Slack Desktop client:
    - Installation and version
    - Update configuration
    - Authentication settings
    - Data storage security
    - Network settings
    - Privacy settings

.NOTES
    @elevation: none
    @elevation-reason: All checks use user-level registry and AppData locations; no admin required
    Requires: Slack Desktop installed

Compliance Mapping:
- CIS Controls: 7.1 (Endpoint Configuration), 13.1 (Centralize Security Event Alerting)
- NIST SP 800-53: SC-8 (Transmission Confidentiality), AC-3 (Access Enforcement)
- Slack Enterprise Security Guidelines
- MITRE ATT&CK: T1102 (Web Service), T1213 (Data from Information Repositories)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Slack Desktop Security Audit"

# ============================================================================
# SLACK INSTALLATION CHECK
# ============================================================================
Write-Section "Slack Installation"

$slackInstalled = $false
$slackVersion = $null

# Check common installation paths
$slackPaths = @(
    "${env:LocalAppData}\slack\slack.exe",
    "${env:ProgramFiles}\Slack\slack.exe",
    "${env:ProgramFiles(x86)}\Slack\slack.exe"
)

foreach ($path in $slackPaths) {
    if (Test-Path $path) {
        $slackInstalled = $true
        break
    }
}

# Check via registry
$slackRegPaths = @(
    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

foreach ($regPath in $slackRegPaths) {
    $slackReg = Get-ItemProperty $regPath -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like "*Slack*" }
    if ($slackReg) {
        $slackInstalled = $true
        $slackVersion = $slackReg.DisplayVersion | Select-Object -First 1
        break
    }
}

if ($slackInstalled) {
    Register-Check -Name "Slack Installation" -Status PASS -Message "Found"

    if ($slackVersion) {
        Register-Check -Name "Slack Version" -Status INFO -Message $slackVersion

        # Check if recent version (Slack updates frequently)
        $majorVer = ($slackVersion -split '\.')[0]
        if ([int]$majorVer -ge 4) {
            Register-Check -Name "Version Currency" -Status PASS -Message "Recent major version"
        } else {
            Register-Check -Name "Version Currency" -Status WARN -Message "May be outdated"
        }
    }
} else {
    Register-Check -Name "Slack Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# SLACK CONFIGURATION
# ============================================================================
Write-Section "Slack Configuration"

# Slack stores config in various locations
$slackConfigPath = "${env:AppData}\Slack"

if (Test-Path $slackConfigPath) {
    Register-Check -Name "Slack Config Directory" -Status INFO -Message "Present"

    # Check for local storage
    $storagePath = Join-Path $slackConfigPath "storage"
    if (Test-Path $storagePath) {
        Register-Check -Name "Local Storage" -Status INFO -Message "Data cached locally"

        # Check storage size (potential data retention concern)
        try {
            $storageSize = (Get-ChildItem -Path $storagePath -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1MB
            if ($storageSize -gt 500) {
                Register-Check -Name "Storage Size" -Status WARN -Message "$([math]::Round($storageSize, 2)) MB (consider cleanup)"
            } else {
                Register-Check -Name "Storage Size" -Status INFO -Message "$([math]::Round($storageSize, 2)) MB"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    # Check for downloads
    $downloadsPath = Join-Path $slackConfigPath "downloads"
    if (Test-Path $downloadsPath) {
        $downloads = Get-ChildItem -Path $downloadsPath -ErrorAction SilentlyContinue
        if ($downloads) {
            Register-Check -Name "Downloaded Files" -Status INFO -Message "$($downloads.Count) file(s) in downloads"
        }
    }
}

# ============================================================================
# SLACK POLICIES (MSI Deployment)
# ============================================================================
Write-Section "Enterprise Configuration"

# Check for MSI deployment
$slackMsiPath = "HKLM:\SOFTWARE\Slack Technologies Inc.\Slack"

if (Test-Path $slackMsiPath) {
    Register-Check -Name "Enterprise Deployment" -Status PASS -Message "MSI/GPO managed"

    # Check for policy settings
    try {
        $defaultSignIn = Get-ItemProperty -Path $slackMsiPath -Name "DefaultSignInTeam" -ErrorAction SilentlyContinue
        if ($defaultSignIn) {
            Register-Check -Name "Default Workspace" -Status PASS -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "Enterprise Deployment" -Status INFO -Message "User installation"
}

# Check for Slack Enterprise Grid settings
$gridConfigPath = "${env:AppData}\Slack\local-settings.json"
if (Test-Path $gridConfigPath) {
    try {
        $gridConfig = Get-Content $gridConfigPath -Raw | ConvertFrom-Json -ErrorAction SilentlyContinue
        if ($gridConfig) {
            Register-Check -Name "Local Settings" -Status INFO -Message "Configuration file present"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# AUTO-UPDATE SETTINGS
# ============================================================================
Write-Section "Update Configuration"

# Slack auto-updates by default via Squirrel
$squirrelPath = "${env:LocalAppData}\slack"

if (Test-Path $squirrelPath) {
    $updateExe = Join-Path $squirrelPath "Update.exe"
    if (Test-Path $updateExe) {
        Register-Check -Name "Auto-Update System" -Status PASS -Message "Squirrel updater present"
    }

    # Check for pending updates
    $packages = Get-ChildItem -Path $squirrelPath -Filter "app-*" -Directory -ErrorAction SilentlyContinue
    if ($packages.Count -gt 1) {
        Register-Check -Name "Update Status" -Status INFO -Message "Multiple versions present (update pending?)"
    }
}

# ============================================================================
# SECURITY SETTINGS
# ============================================================================
Write-Section "Security Settings"

# Check if Slack stores credentials
$credentialPath = "${env:AppData}\Slack\Cookies"
if (Test-Path $credentialPath) {
    Register-Check -Name "Local Credentials" -Status INFO -Message "Session data stored locally"
}

# Check for keychain/credential usage
$secureStorage = "${env:AppData}\Slack\Local Storage\leveldb"
if (Test-Path $secureStorage) {
    Register-Check -Name "Local Storage DB" -Status INFO -Message "LevelDB storage present"

    # Check permissions on sensitive directories
    try {
        $acl = Get-Acl $secureStorage -ErrorAction SilentlyContinue
        $hasEveryoneAccess = $acl.Access | Where-Object {
            $_.IdentityReference.Value -eq 'Everyone' -and
            $_.FileSystemRights -match 'FullControl|Modify|Write'
        }

        if (-not $hasEveryoneAccess) {
            Register-Check -Name "Storage Permissions" -Status PASS -Message "Restricted"
        } else {
            Register-Check -Name "Storage Permissions" -Status WARN -Message "Broad access"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================
Write-Section "Network Settings"

# Proxy configuration
try {
    $slackProxy = Get-ItemProperty -Path "HKCU:\Software\Slack" -Name "ProxyServer" -ErrorAction SilentlyContinue
    if ($slackProxy) {
        Register-Check -Name "Proxy Server" -Status INFO -Message "Configured"
    } else {
        Register-Check -Name "Proxy Server" -Status INFO -Message "System default"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SLACK WORKSPACES
# ============================================================================
Write-Section "Workspace Information"

# Check for logged-in workspaces
$teamsPath = "${env:AppData}\Slack\storage\slack-teams"
if (Test-Path $teamsPath) {
    try {
        $teamFiles = Get-ChildItem -Path $teamsPath -ErrorAction SilentlyContinue
        if ($teamFiles) {
            Register-Check -Name "Connected Workspaces" -Status INFO -Message "$($teamFiles.Count) workspace(s)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Check for workspace cache
$cachePath = "${env:AppData}\Slack\Cache"
if (Test-Path $cachePath) {
    try {
        $cacheSize = (Get-ChildItem -Path $cachePath -Recurse -ErrorAction SilentlyContinue |
            Measure-Object -Property Length -Sum).Sum / 1MB

        if ($cacheSize -gt 1000) {
            Register-Check -Name "Cache Size" -Status WARN -Message "$([math]::Round($cacheSize, 2)) MB (large cache)"
        } else {
            Register-Check -Name "Cache Size" -Status INFO -Message "$([math]::Round($cacheSize, 2)) MB"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# DATA PROTECTION
# ============================================================================
Write-Section "Data Protection"

# Check for logs
$logsPath = "${env:AppData}\Slack\logs"
if (Test-Path $logsPath) {
    $logFiles = Get-ChildItem -Path $logsPath -Filter "*.log" -ErrorAction SilentlyContinue
    if ($logFiles) {
        Register-Check -Name "Log Files" -Status INFO -Message "$($logFiles.Count) log file(s)"

        # Check log age
        $oldestLog = $logFiles | Sort-Object LastWriteTime | Select-Object -First 1
        $logAge = ((Get-Date) - $oldestLog.LastWriteTime).Days
        if ($logAge -gt 30) {
            Register-Check -Name "Log Retention" -Status INFO -Message "Logs older than 30 days present"
        }
    }
}

# GPU cache (may contain rendered content)
$gpuCachePath = "${env:AppData}\Slack\GPUCache"
if (Test-Path $gpuCachePath) {
    Register-Check -Name "GPU Cache" -Status INFO -Message "Present (rendered content may be cached)"
}

# ============================================================================
# RUNNING PROCESS CHECK
# ============================================================================
Write-Section "Process Information"

$slackProcesses = Get-Process -Name "slack*" -ErrorAction SilentlyContinue

if ($slackProcesses) {
    Register-Check -Name "Slack Running" -Status INFO -Message "$($slackProcesses.Count) process(es)"

    # Check for multiple instances
    $mainProcess = $slackProcesses | Where-Object { $_.MainWindowHandle -ne 0 }
    if ($mainProcess) {
        # Check memory usage
        $totalMem = ($slackProcesses | Measure-Object -Property WorkingSet64 -Sum).Sum / 1MB
        if ($totalMem -gt 1000) {
            Register-Check -Name "Memory Usage" -Status WARN -Message "$([math]::Round($totalMem, 0)) MB (high)"
        } else {
            Register-Check -Name "Memory Usage" -Status INFO -Message "$([math]::Round($totalMem, 0)) MB"
        }
    }
} else {
    Register-Check -Name "Slack Running" -Status INFO -Message "Not running"
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

# Check Slack startup
try {
    $startupReg = Get-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "slack" -ErrorAction SilentlyContinue
    if ($startupReg) {
        Register-Check -Name "Auto-Start" -Status INFO -Message "Enabled at login"
    } else {
        Register-Check -Name "Auto-Start" -Status INFO -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for Slack Connect (external orgs)
Register-Check -Name "Slack Connect" -Status INFO -Message "Review external channel connections in admin"

Print-Summary
Exit-Audit
