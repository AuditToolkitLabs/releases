<#
.SYNOPSIS
    Microsoft Teams Security Audit Script

.DESCRIPTION
    Comprehensive security audit for Microsoft Teams enterprise deployments.
    Checks client installation, policies, data handling, and security settings.
    This script is read-only and does not modify system state.

.NOTES
    Compliance Mapping:
    - CIS Controls: 4.1, 4.2, 13.1, 16.11
    - NIST SP 800-53: AC-3, AC-6, SC-7, SC-13, SI-2
    - ISO 27001: A.9.1, A.10.1, A.13.1, A.13.2
    - OWASP ASVS: V10
    - UK NCSC: Secure Configuration, Data at Rest
    - PCI DSS: 1.1, 1.2, 1.3, 10.2
    - Microsoft 365 Security Baseline
#>

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

# ============================================================================
# TEAMS INSTALLATION CHECK
# ============================================================================
Write-Output "=== Microsoft Teams Installation ==="

# Check for Teams (New) - Microsoft Teams v2
$teamsNew = Get-AppxPackage -Name "MSTeams" -ErrorAction SilentlyContinue
$teamsNewAllUsers = Get-AppxPackage -Name "MSTeams" -AllUsers -ErrorAction SilentlyContinue

# Check for Classic Teams
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -match "Microsoft Teams" } | Out-Null
Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -match "Microsoft Teams" } | Out-Null

# Check Teams paths
$teamsClassicPath = "$env:LOCALAPPDATA\Microsoft\Teams\current\Teams.exe"
$teamsMachineWide = "C:\Program Files (x86)\Microsoft\Teams\current\Teams.exe"

if ($teamsNew -or $teamsNewAllUsers) {
    $version = if ($teamsNew) { $teamsNew.Version } else { $teamsNewAllUsers.Version }
    Register-Check -Name "Microsoft Teams (New)" -Status PASS -Message "Version $version"
    $teamsInstalled = $true
    $teamsType = "New"
} elseif (Test-Path $teamsClassicPath) {
    $version = (Get-Item $teamsClassicPath).VersionInfo.FileVersion
    Register-Check -Name "Microsoft Teams Classic" -Status INFO -Message "Version $version (consider upgrading to new Teams)"
    $teamsInstalled = $true
    $teamsType = "Classic"
} elseif (Test-Path $teamsMachineWide) {
    $version = (Get-Item $teamsMachineWide).VersionInfo.FileVersion
    Register-Check -Name "Microsoft Teams (Machine-Wide)" -Status INFO -Message "Version $version"
    $teamsInstalled = $true
    $teamsType = "MachineWide"
} else {
    Register-Check -Name "Microsoft Teams" -Status INFO -Message "Not installed on this device"
    $teamsInstalled = $false
    # Continue to check policies that may still apply
}

# ============================================================================
# TEAMS UPDATE POLICIES
# ============================================================================
Write-Output ""
Write-Output "=== Teams Update and Deployment ==="

if ($teamsInstalled) {
    # Check Teams auto-start (startup impact)
    $teamsAutoStart = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "com.squirrel.Teams.Teams" -ErrorAction SilentlyContinue
    if ($teamsAutoStart) {
        Register-Check -Name "Teams Auto-Start" -Status INFO -Message "Enabled"
    } else {
        Register-Check -Name "Teams Auto-Start" -Status INFO -Message "Disabled"
    }

    # Check Teams machine-wide installer
    $machineWideInstaller = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -match "Teams Machine-Wide Installer" }
    if ($machineWideInstaller) {
        Register-Check -Name "Machine-Wide Installer" -Status INFO -Message "Installed (for VDI/shared devices)"
    }

    # Check update ring (if configured)
    $updateRing = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Teams" -Name "UpdateRing" -ErrorAction SilentlyContinue
    if ($updateRing) {
        switch ($updateRing.UpdateRing) {
            0 { Register-Check -Name "Teams Update Ring" -Status INFO -Message "General Availability" }
            1 { Register-Check -Name "Teams Update Ring" -Status INFO -Message "Preview" }
            2 { Register-Check -Name "Teams Update Ring" -Status INFO -Message "TAP" }
        }
    }
}

# ============================================================================
# TEAMS CLIENT POLICIES (LOCAL)
# ============================================================================
Write-Output ""
Write-Output "=== Teams Client Policies ==="

$teamsPolicies = "HKLM:\SOFTWARE\Policies\Microsoft\Teams"
# GPU Hardware Acceleration
$gpuDisabled = Get-ItemProperty $teamsPolicies -Name "DisableGpu" -ErrorAction SilentlyContinue
if ($gpuDisabled -and $gpuDisabled.DisableGpu -eq 1) {
    Register-Check -Name "GPU Acceleration" -Status INFO -Message "Disabled"
}

# Background blur/effects
$backgroundEffects = Get-ItemProperty $teamsPolicies -Name "DisableBackgroundBlur" -ErrorAction SilentlyContinue
if ($backgroundEffects -and $backgroundEffects.DisableBackgroundBlur -eq 1) {
    Register-Check -Name "Background Effects" -Status INFO -Message "Disabled"
}

# Screen sharing policy
$screenShare = Get-ItemProperty $teamsPolicies -Name "AllowScreenShare" -ErrorAction SilentlyContinue
if ($screenShare -and $screenShare.AllowScreenShare -eq 0) {
    Register-Check -Name "Screen Sharing" -Status INFO -Message "Disabled by policy"
}

# ============================================================================
# TEAMS ADMIN POLICIES (CLOUD - Local Registry Cache)
# ============================================================================
Write-Output ""
Write-Output "=== Teams Admin Policies (Cached) ==="

# Note: Most Teams policies are managed in Microsoft 365 Admin Center
# These checks look for locally cached policy settings

# Check for Teams Rooms if applicable
$teamsRooms = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Skype Room System" -ErrorAction SilentlyContinue
if ($teamsRooms) {
    Register-Check -Name "Teams Rooms Device" -Status INFO -Message "Teams Rooms configuration detected"
}

# Check External Access settings (if cached)
$externalAccess = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "ExternalAccessEnabled" -ErrorAction SilentlyContinue
if ($externalAccess) {
    if ($externalAccess.ExternalAccessEnabled -eq 1) {
        Register-Check -Name "External Access (cached)" -Status INFO -Message "Enabled"
    } else {
        Register-Check -Name "External Access (cached)" -Status PASS -Message "Disabled"
    }
}

# Check Guest Access settings (if cached)
$guestAccess = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "GuestAccessEnabled" -ErrorAction SilentlyContinue
if ($guestAccess) {
    if ($guestAccess.GuestAccessEnabled -eq 1) {
        Register-Check -Name "Guest Access (cached)" -Status WARN -Message "Enabled - review guest permissions"
    } else {
        Register-Check -Name "Guest Access (cached)" -Status PASS -Message "Disabled"
    }
}

# ============================================================================
# TEAMS DATA AND STORAGE
# ============================================================================
Write-Output ""
Write-Output "=== Teams Data and Storage ==="

if ($teamsInstalled) {
    # Check Teams cache location
    if ($teamsType -eq "Classic") {
        $teamsDataPath = "$env:APPDATA\Microsoft\Teams"
    } else {
        # New Teams stores data differently
        $teamsDataPath = "$env:LOCALAPPDATA\Packages\MSTeams*\LocalCache\Microsoft\MSTeams"
    }

    if (Test-Path $teamsDataPath) {
        # Check cache size
        $cacheSize = (Get-ChildItem $teamsDataPath -Recurse -ErrorAction SilentlyContinue |
            Measure-Object -Property Length -Sum).Sum / 1MB
        $cacheSizeMB = [math]::Round($cacheSize, 2)

        if ($cacheSizeMB -gt 2000) {
            Register-Check -Name "Teams Cache Size" -Status WARN -Message "${cacheSizeMB}MB - consider clearing"
        } else {
            Register-Check -Name "Teams Cache Size" -Status INFO -Message "${cacheSizeMB}MB"
        }

        # Check for logs that might contain sensitive data
        $logsPath = "$teamsDataPath\logs*.txt"
        $logFiles = Get-ChildItem $logsPath -ErrorAction SilentlyContinue
        if ($logFiles -and $logFiles.Count -gt 0) {
            $logSize = ($logFiles | Measure-Object -Property Length -Sum).Sum / 1MB
            Register-Check -Name "Teams Log Files" -Status INFO -Message "$($logFiles.Count) files, $([math]::Round($logSize, 2))MB"
        }
    }

    # Check Downloads folder in Teams
    $teamsDownloads = "$env:USERPROFILE\Downloads\Microsoft Teams Chat Files"
    if (Test-Path $teamsDownloads) {
        $downloadCount = (Get-ChildItem $teamsDownloads -Recurse -File -ErrorAction SilentlyContinue).Count
        if ($downloadCount -gt 0) {
            Register-Check -Name "Teams Downloaded Files" -Status INFO -Message "$downloadCount file(s) in chat downloads"
        }
    }
}

# ============================================================================
# TEAMS SECURITY FEATURES
# ============================================================================
Write-Output ""
Write-Output "=== Teams Security Features ==="

# Check for Conditional Access policy application
$caPolicy = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\16.0\Common\Identity" -Name "EnableADAL" -ErrorAction SilentlyContinue
if ($caPolicy -and $caPolicy.EnableADAL -eq 1) {
    Register-Check -Name "Modern Auth (ADAL)" -Status PASS -Message "Enabled"
}

# Check WAM (Web Account Manager) for SSO
$wamEnabled = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\16.0\Common\Identity" -Name "EnableWAM" -ErrorAction SilentlyContinue
if ($wamEnabled -and $wamEnabled.EnableWAM -eq 1) {
    Register-Check -Name "Web Account Manager" -Status PASS -Message "Enabled for SSO"
}

# Check for Intune/MDM enrollment (affects Teams policies)
$mdmEnrollment = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Enrollments\*" -Name "ProviderId" -ErrorAction SilentlyContinue
if ($mdmEnrollment) {
    Register-Check -Name "MDM Enrollment" -Status PASS -Message "Device is MDM managed"
} else {
    Register-Check -Name "MDM Enrollment" -Status INFO -Message "Not MDM enrolled"
}

# Check for Windows Information Protection (WIP)
$wipPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\AppLocker" -ErrorAction SilentlyContinue
if ($wipPolicy) {
    Register-Check -Name "WIP/AIP Policy" -Status INFO -Message "AppLocker/WIP policies detected"
}

# ============================================================================
# TEAMS NETWORK CONFIGURATION
# ============================================================================
Write-Output ""
Write-Output "=== Teams Network Configuration ==="

# Check proxy settings that affect Teams
$proxyEnabled = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyEnable" -ErrorAction SilentlyContinue
if ($proxyEnabled -and $proxyEnabled.ProxyEnable -eq 1) {
    $proxyServer = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyServer" -ErrorAction SilentlyContinue
    Register-Check -Name "Proxy Configuration" -Status INFO -Message "Proxy enabled: $($proxyServer.ProxyServer)"
} else {
    Register-Check -Name "Proxy Configuration" -Status INFO -Message "Direct connection"
}

# Check if Teams media optimization is available (for VDI)
$mediaOptimization = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Teams" -Name "IsWVDEnvironment" -ErrorAction SilentlyContinue
if ($mediaOptimization) {
    Register-Check -Name "VDI Media Optimization" -Status INFO -Message "VDI environment detected"

    # Check Azure Virtual Desktop optimization
    $avdOptimization = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Teams" -Name "DisableFallback" -ErrorAction SilentlyContinue
    if ($avdOptimization -and $avdOptimization.DisableFallback -eq 0) {
        Register-Check -Name "AVD Teams Optimization" -Status PASS -Message "Configured"
    }
}

# ============================================================================
# TEAMS MEETING SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Teams Meeting Security (Note: Cloud Policies) ==="

# Note: Meeting policies are primarily configured in Teams Admin Center
# These are informational checks about local settings

Register-Check -Name "Meeting Policies" -Status INFO -Message "Managed via Microsoft 365 Admin Center"

# Check for lobby bypass indicators
$lobbySettings = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "LobbyBypass" -ErrorAction SilentlyContinue
if ($lobbySettings) {
    Register-Check -Name "Lobby Bypass (cached)" -Status INFO -Message "Setting cached locally"
}

# Check recording policies
$recordingPolicy = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "AllowCloudRecording" -ErrorAction SilentlyContinue
if ($recordingPolicy) {
    if ($recordingPolicy.AllowCloudRecording -eq 1) {
        Register-Check -Name "Cloud Recording (cached)" -Status INFO -Message "Allowed"
    } else {
        Register-Check -Name "Cloud Recording (cached)" -Status INFO -Message "Disabled"
    }
}

# Check transcription settings
$transcription = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "AllowTranscription" -ErrorAction SilentlyContinue
if ($transcription -and $transcription.AllowTranscription -eq 1) {
    Register-Check -Name "Transcription (cached)" -Status INFO -Message "Enabled"
}

# ============================================================================
# TEAMS APP SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Teams App Security ==="

# Check for third-party app policies
$appPolicy = Get-ItemProperty $teamsPolicies -Name "AllowThirdPartyApps" -ErrorAction SilentlyContinue
if ($appPolicy) {
    if ($appPolicy.AllowThirdPartyApps -eq 0) {
        Register-Check -Name "Third-Party Apps" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "Third-Party Apps" -Status INFO -Message "Allowed"
    }
}

# Check for sideloading policy
$sideload = Get-ItemProperty $teamsPolicies -Name "AllowSideloading" -ErrorAction SilentlyContinue
if ($sideload) {
    if ($sideload.AllowSideloading -eq 0) {
        Register-Check -Name "App Sideloading" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "App Sideloading" -Status WARN -Message "Allowed - review for security"
    }
}

# Check custom apps policy
$customApps = Get-ItemProperty $teamsPolicies -Name "AllowCustomApps" -ErrorAction SilentlyContinue
if ($customApps) {
    if ($customApps.AllowCustomApps -eq 0) {
        Register-Check -Name "Custom Apps" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "Custom Apps" -Status INFO -Message "Allowed"
    }
}

# ============================================================================
# TEAMS COMPLIANCE FEATURES
# ============================================================================
Write-Output ""
Write-Output "=== Teams Compliance Features ==="

# Check for eDiscovery/Legal Hold indicators
$legalHold = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "LegalHoldEnabled" -ErrorAction SilentlyContinue
if ($legalHold -and $legalHold.LegalHoldEnabled -eq 1) {
    Register-Check -Name "Legal Hold" -Status INFO -Message "Enabled for this user"
}

# Check DLP policy indicators
$dlpEnabled = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\DLP" -ErrorAction SilentlyContinue
if ($dlpEnabled) {
    Register-Check -Name "DLP Policies" -Status PASS -Message "DLP policies configured"
}

# Check retention policy indicators
$retention = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Teams" -Name "RetentionPolicy" -ErrorAction SilentlyContinue
if ($retention) {
    Register-Check -Name "Retention Policy" -Status INFO -Message "Retention policy applied"
}

# ============================================================================
# TEAMS DIAGNOSTIC DATA
# ============================================================================
Write-Output ""
Write-Output "=== Teams Telemetry and Diagnostics ==="

# Check Office telemetry level
$telemetryLevel = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Office\Common\ClientTelemetry" -Name "SendTelemetry" -ErrorAction SilentlyContinue
if ($telemetryLevel) {
    switch ($telemetryLevel.SendTelemetry) {
        0 { Register-Check -Name "Office Telemetry" -Status INFO -Message "None" }
        1 { Register-Check -Name "Office Telemetry" -Status INFO -Message "Required only" }
        2 { Register-Check -Name "Office Telemetry" -Status INFO -Message "Required + Optional" }
        3 { Register-Check -Name "Office Telemetry" -Status INFO -Message "Full diagnostic data" }
    }
}

# Check feedback policies
$feedback = Get-ItemProperty $teamsPolicies -Name "AllowFeedback" -ErrorAction SilentlyContinue
if ($feedback -and $feedback.AllowFeedback -eq 0) {
    Register-Check -Name "User Feedback" -Status INFO -Message "Disabled"
}

# Check survey prompts
$surveys = Get-ItemProperty $teamsPolicies -Name "AllowSurveys" -ErrorAction SilentlyContinue
if ($surveys -and $surveys.AllowSurveys -eq 0) {
    Register-Check -Name "Survey Prompts" -Status INFO -Message "Disabled"
}

# ============================================================================
# TEAMS FILE HANDLING
# ============================================================================
Write-Output ""
Write-Output "=== Teams File Handling ==="

# Check for OneDrive integration (affects file sharing)
$oneDriveIntegration = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\OneDrive" -Name "UserFolder" -ErrorAction SilentlyContinue
if ($oneDriveIntegration) {
    Register-Check -Name "OneDrive Integration" -Status INFO -Message "OneDrive configured"
}

# Check SharePoint sync client
$spSync = Get-Service -Name "OneDrive*" -ErrorAction SilentlyContinue
if ($spSync) {
    Register-Check -Name "OneDrive Sync" -Status INFO -Message "OneDrive/SharePoint sync service present"
}

# Check for external file sharing restrictions
$externalShare = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\OneDrive" -Name "BlockExternalSync" -ErrorAction SilentlyContinue
if ($externalShare -and $externalShare.BlockExternalSync -eq 1) {
    Register-Check -Name "External Sync Block" -Status PASS -Message "External org sync blocked"
}

# ============================================================================
# POLICY SUMMARY
# ============================================================================
Write-Output ""

# Count configured Teams policies
$policyCount = 0
if (Test-Path $teamsPolicies) {
    $policyCount = (Get-ItemProperty $teamsPolicies -ErrorAction SilentlyContinue).PSObject.Properties.Count
}

if ($policyCount -gt 2) {
    Register-Check -Name "Teams Policy Summary" -Status PASS -Message "$policyCount local policies configured"
} elseif ($teamsInstalled) {
    Register-Check -Name "Teams Policy Summary" -Status INFO -Message "Policies managed via cloud (M365 Admin Center)"
} else {
    Register-Check -Name "Teams Policy Summary" -Status INFO -Message "Teams not installed - policies still apply to web client"
}

Print-Summary
Exit-Audit
