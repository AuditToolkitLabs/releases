<#
.SYNOPSIS
    Zoom Client Security Audit

.DESCRIPTION
    Comprehensive security audit for Zoom Meetings client:
    - Installation and version
    - Update configuration
    - Meeting security settings
    - Privacy settings
    - Authentication settings
    - Recording policies
    - Network settings

.NOTES
    @elevation: partial
    @elevation-reason: HKLM enterprise policies require admin; HKCU settings work without elevation
    Requires: Zoom client installed

Compliance Mapping:
- CIS Controls: 7.1 (Endpoint Configuration), 13.6 (Encrypt Mobile Devices)
- NIST SP 800-53: SC-8 (Transmission Confidentiality), AC-3 (Access Enforcement)
- Zoom Enterprise Security Guidelines
- MITRE ATT&CK: T1102 (Web Service), T1040 (Network Sniffing)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Zoom Client Security Audit"

# ============================================================================
# ZOOM INSTALLATION CHECK
# ============================================================================
Write-Section "Zoom Installation"

$zoomInstalled = $false
$zoomPath = $null
$zoomVersion = $null

# Check common installation paths
$zoomPaths = @(
    "${env:ProgramFiles}\Zoom\bin\Zoom.exe",
    "${env:ProgramFiles(x86)}\Zoom\bin\Zoom.exe",
    "${env:AppData}\Zoom\bin\Zoom.exe",
    "${env:LocalAppData}\Zoom\bin\Zoom.exe"
)

foreach ($path in $zoomPaths) {
    if (Test-Path $path) {
        $zoomInstalled = $true
        $zoomPath = $path
        break
    }
}

# Also check via registry
$zoomRegPaths = @(
    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

foreach ($regPath in $zoomRegPaths) {
    $zoomReg = Get-ItemProperty $regPath -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like "*Zoom*" }
    if ($zoomReg) {
        $zoomInstalled = $true
        $zoomVersion = $zoomReg.DisplayVersion | Select-Object -First 1
        if (-not $zoomPath -and $zoomReg.InstallLocation) {
            $zoomPath = Join-Path $zoomReg.InstallLocation "bin\Zoom.exe" | Select-Object -First 1
        }
        break
    }
}

if ($zoomInstalled) {
    Register-Check -Name "Zoom Installation" -Status PASS -Message "Found"

    if ($zoomVersion) {
        Register-Check -Name "Zoom Version" -Status INFO -Message $zoomVersion

        # Parse version for currency check
        $majorVer = ($zoomVersion -split '\.')[0]
        if ([int]$majorVer -ge 5) {
            Register-Check -Name "Zoom Version Currency" -Status PASS -Message "Version 5.x+ (current)"
        } else {
            Register-Check -Name "Zoom Version Currency" -Status FAIL -Message "Outdated - upgrade immediately"
        }
    }
} else {
    Register-Check -Name "Zoom Installation" -Status SKIP -Message "Not installed"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# ZOOM POLICIES (MSI/GPO)
# ============================================================================
Write-Section "Zoom Enterprise Policies"

$zoomPolicyPath = "HKLM:\SOFTWARE\Policies\Zoom\Zoom Meetings"
$zoomPolicyPathWow = "HKLM:\SOFTWARE\WOW6432Node\Policies\Zoom\Zoom Meetings"

$activePolicyPath = if (Test-Path $zoomPolicyPath) { $zoomPolicyPath } elseif (Test-Path $zoomPolicyPathWow) { $zoomPolicyPathWow } else { $null }

if ($activePolicyPath) {
    Register-Check -Name "Enterprise Policies" -Status PASS -Message "Configured"

    # Auto-update
    try {
        $autoUpdate = Get-ItemProperty -Path "$activePolicyPath\General" -Name "EnableAutoUpdate" -ErrorAction SilentlyContinue
        if ($autoUpdate -and $autoUpdate.EnableAutoUpdate -eq 1) {
            Register-Check -Name "Auto Updates" -Status PASS -Message "Enabled"
        } elseif ($autoUpdate -and $autoUpdate.EnableAutoUpdate -eq 0) {
            Register-Check -Name "Auto Updates" -Status WARN -Message "Disabled (ensure managed updates)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # SSO enforcement
    try {
        $ssoOnly = Get-ItemProperty -Path "$activePolicyPath\SSO" -Name "ForceSSOUrl" -ErrorAction SilentlyContinue
        if ($ssoOnly) {
            Register-Check -Name "SSO Enforcement" -Status PASS -Message "Configured: $($ssoOnly.ForceSSOUrl)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

} else {
    Register-Check -Name "Enterprise Policies" -Status INFO -Message "Not configured via GPO"
}

# ============================================================================
# MEETING SECURITY SETTINGS
# ============================================================================
Write-Section "Meeting Security"

# Check Zoom settings from registry
$zoomSettingsPath = "HKCU:\SOFTWARE\Zoom\Zoom Desktop Client"

if (Test-Path $zoomSettingsPath) {
    # Waiting room
    try {
        $waitingRoom = Get-ItemProperty -Path $zoomSettingsPath -Name "WaitingRoom" -ErrorAction SilentlyContinue
        if ($waitingRoom -and $waitingRoom.WaitingRoom -eq 1) {
            Register-Check -Name "Waiting Room Default" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "Waiting Room Default" -Status WARN -Message "Not enforced locally"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Meeting password
    try {
        $meetingPwd = Get-ItemProperty -Path $zoomSettingsPath -Name "RequireMeetingPassword" -ErrorAction SilentlyContinue
        if ($meetingPwd -and $meetingPwd.RequireMeetingPassword -eq 1) {
            Register-Check -Name "Meeting Password" -Status PASS -Message "Required"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Screen sharing
    try {
        $screenShare = Get-ItemProperty -Path $zoomSettingsPath -Name "ShareScreen" -ErrorAction SilentlyContinue
        if ($screenShare) {
            Register-Check -Name "Screen Sharing" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Policy-enforced settings
if ($activePolicyPath) {
    # Require encryption
    try {
        $encryption = Get-ItemProperty -Path "$activePolicyPath\Meetings" -Name "RequireEncryption" -ErrorAction SilentlyContinue
        if ($encryption -and $encryption.RequireEncryption -eq 1) {
            Register-Check -Name "Encryption Required" -Status PASS -Message "Enforced"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # E2E encryption
    try {
        $e2e = Get-ItemProperty -Path "$activePolicyPath\Meetings" -Name "EnableE2EE" -ErrorAction SilentlyContinue
        if ($e2e -and $e2e.EnableE2EE -eq 1) {
            Register-Check -Name "End-to-End Encryption" -Status PASS -Message "Available"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Disable join before host
    try {
        $joinBeforeHost = Get-ItemProperty -Path "$activePolicyPath\Meetings" -Name "DisableJoinBeforeHost" -ErrorAction SilentlyContinue
        if ($joinBeforeHost -and $joinBeforeHost.DisableJoinBeforeHost -eq 1) {
            Register-Check -Name "Join Before Host" -Status PASS -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# PRIVACY SETTINGS
# ============================================================================
Write-Section "Privacy Settings"

if ($activePolicyPath) {
    # Attention tracking (deprecated)
    try {
        $attentionTracking = Get-ItemProperty -Path "$activePolicyPath\Privacy" -Name "DisableAttentionTracking" -ErrorAction SilentlyContinue
        if ($attentionTracking -and $attentionTracking.DisableAttentionTracking -eq 1) {
            Register-Check -Name "Attention Tracking" -Status PASS -Message "Disabled"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Virtual background
    try {
        $virtualBg = Get-ItemProperty -Path "$activePolicyPath\Meetings" -Name "EnableVirtualBackground" -ErrorAction SilentlyContinue
        if ($virtualBg) {
            Register-Check -Name "Virtual Background" -Status INFO -Message "Configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# Local recording policy
try {
    $localRecording = Get-ItemProperty -Path "$activePolicyPath\Recording" -Name "DisableLocalRecording" -ErrorAction SilentlyContinue
    if ($localRecording -and $localRecording.DisableLocalRecording -eq 1) {
        Register-Check -Name "Local Recording" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "Local Recording" -Status INFO -Message "Allowed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Cloud recording
try {
    $cloudRecording = Get-ItemProperty -Path "$activePolicyPath\Recording" -Name "DisableCloudRecording" -ErrorAction SilentlyContinue
    if ($cloudRecording -and $cloudRecording.DisableCloudRecording -eq 1) {
        Register-Check -Name "Cloud Recording" -Status INFO -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# AUTHENTICATION
# ============================================================================
Write-Section "Authentication"

if ($activePolicyPath) {
    # Login domain restriction
    try {
        $loginDomain = Get-ItemProperty -Path "$activePolicyPath\SSO" -Name "LoginDomain" -ErrorAction SilentlyContinue
        if ($loginDomain) {
            Register-Check -Name "Login Domain" -Status PASS -Message "Restricted: $($loginDomain.LoginDomain)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Disable email login
    try {
        $disableEmail = Get-ItemProperty -Path "$activePolicyPath\SSO" -Name "DisableEmailLogin" -ErrorAction SilentlyContinue
        if ($disableEmail -and $disableEmail.DisableEmailLogin -eq 1) {
            Register-Check -Name "Email Login" -Status PASS -Message "Disabled (SSO only)"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# NETWORK AND CONNECTIVITY
# ============================================================================
Write-Section "Network Settings"

# Proxy settings
try {
    $proxy = Get-ItemProperty -Path $zoomSettingsPath -Name "UseProxy" -ErrorAction SilentlyContinue
    if ($proxy -and $proxy.UseProxy -eq 1) {
        Register-Check -Name "Proxy Configuration" -Status INFO -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Bandwidth limit
try {
    $bandwidthLimit = Get-ItemProperty -Path "$activePolicyPath\Network" -Name "BandwidthLimitUp" -ErrorAction SilentlyContinue
    if ($bandwidthLimit) {
        Register-Check -Name "Bandwidth Limit" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ZOOM SERVICES
# ============================================================================
Write-Section "Zoom Services"

# Zoom Outlook Plugin
$outlookPlugin = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Office\Outlook\Addins\ZoomOutlookPlugin*" -ErrorAction SilentlyContinue
if ($outlookPlugin) {
    Register-Check -Name "Outlook Plugin" -Status INFO -Message "Installed"
}

# Zoom Rooms (if applicable)
$zoomRooms = Get-Service -Name "ZoomRoomsService" -ErrorAction SilentlyContinue
if ($zoomRooms) {
    Register-Check -Name "Zoom Rooms Service" -Status INFO -Message $zoomRooms.Status
}

# ============================================================================
# FILE LOCATIONS
# ============================================================================
Write-Section "Data Storage"

# Recording location
$recordingPath = "$env:UserProfile\Documents\Zoom"
if (Test-Path $recordingPath) {
    Register-Check -Name "Local Recordings" -Status INFO -Message "Directory exists"

    # Check for recordings
    $recordings = Get-ChildItem -Path $recordingPath -Recurse -Include "*.mp4","*.m4a" -ErrorAction SilentlyContinue
    if ($recordings) {
        Register-Check -Name "Recording Files" -Status INFO -Message "$($recordings.Count) recording file(s)"
    }
}

# Cache location
$cachePath = "$env:AppData\Zoom\data"
if (Test-Path $cachePath) {
    Register-Check -Name "Cache Data" -Status INFO -Message "Present at $cachePath"
}

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

# Check if running latest
if ($zoomVersion) {
    $minorParts = $zoomVersion -split '\.'
    if ($minorParts.Count -ge 3) {
        [int]$minorParts[2] | Out-Null
        # Zoom regularly releases security patches
        Register-Check -Name "Security Patches" -Status INFO -Message "Verify latest patch level"
    }
}

# Check Zoom process
$zoomProcess = Get-Process -Name "Zoom*" -ErrorAction SilentlyContinue
if ($zoomProcess) {
    Register-Check -Name "Zoom Running" -Status INFO -Message "$($zoomProcess.Count) process(es)"
}

Print-Summary
Exit-Audit
