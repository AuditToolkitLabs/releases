#Requires -Version 5.1
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Windows Certificate Store Security Audit.
.DESCRIPTION
    Read-only certificate hygiene checks for local machine and user stores.
.NOTES
    Uses shared Windows audit helpers from lib/common.ps1.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

function Get-CertificateInStore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$StorePath,
        [switch]$Recurse
    )

    if (-not (Test-Path -LiteralPath $StorePath)) {
        return @()
    }

    if ($Recurse) {
        return @(Get-ChildItem -LiteralPath $StorePath -Recurse -ErrorAction SilentlyContinue)
    }

    return @(Get-ChildItem -LiteralPath $StorePath -ErrorAction SilentlyContinue)
}

function Register-CertificateSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name,
        [array]$CertificateList,
        [string]$PassMessage,
        [string]$WarnMessage,
        [string]$FailMessage,
        [ValidateSet('PASS', 'WARN', 'FAIL')]
        [string]$Severity = 'WARN',
        [int]$SampleCount = 0
    )

    $count = @($CertificateList).Count
    if ($count -eq 0) {
        Register-Check -Name $Name -Status PASS -Message $PassMessage
        return
    }

    $status = if ($Severity -eq 'FAIL') { 'FAIL' } elseif ($Severity -eq 'WARN') { 'WARN' } else { 'PASS' }
    $message = $WarnMessage
    if ($status -eq 'FAIL') {
        $message = $FailMessage
    }

    Register-Check -Name $Name -Status $status -Message ("{0} ({1})" -f $message, $count)

    if ($SampleCount -gt 0) {
        foreach ($cert in @($CertificateList | Select-Object -First $SampleCount)) {
            Register-Check -Name ("{0} Sample" -f $Name) -Status INFO -Message $cert.Subject
        }
    }
}

Write-Section 'Windows Certificate Store Security Audit'

if (-not (Test-IsAdminMode)) {
    Register-Check 'Administrator Privileges' 'SKIP' 'This audit requires Administrator privileges'
    Print-Summary
    exit 0
}

$osInfo = Get-WindowsVersion
Register-Check 'Operating System' 'INFO' ("{0} (Build {1})" -f $osInfo.ProductName, $osInfo.Build)
Register-Check 'Server OS' 'INFO' ([string](Test-IsServerOS))

Write-Section 'Certificate Store Inventory'
$storeMatrix = @(
    @{ Location = 'LocalMachine'; Name = 'My' }
    @{ Location = 'LocalMachine'; Name = 'Root' }
    @{ Location = 'LocalMachine'; Name = 'CA' }
    @{ Location = 'LocalMachine'; Name = 'TrustedPublisher' }
    @{ Location = 'LocalMachine'; Name = 'Disallowed' }
    @{ Location = 'CurrentUser'; Name = 'My' }
    @{ Location = 'CurrentUser'; Name = 'Root' }
    @{ Location = 'CurrentUser'; Name = 'CA' }
    @{ Location = 'CurrentUser'; Name = 'TrustedPublisher' }
    @{ Location = 'CurrentUser'; Name = 'Disallowed' }
)

$totalCount = 0
foreach ($item in $storeMatrix) {
    $path = "Cert:\{0}\{1}" -f $item.Location, $item.Name
    $certList = Get-CertificateInStore -StorePath $path
    if ($certList.Count -gt 0) {
        Register-Check -Name ("{0}\\{1} store" -f $item.Location, $item.Name) -Status PASS -Message ("{0} certificate(s)" -f $certList.Count)
        $totalCount += $certList.Count
    }
}
Register-Check -Name 'Total certificates' -Status PASS -Message ("{0} certificate(s) across reviewed stores" -f $totalCount)

Write-Section 'Certificate Expiration and Signing Health'
$personalList = @()
$personalList += Get-CertificateInStore -StorePath 'Cert:\LocalMachine\My' -Recurse
$personalList += Get-CertificateInStore -StorePath 'Cert:\CurrentUser\My' -Recurse

$currentTime = Get-Date
$expiredList = $personalList | Where-Object { $_.NotAfter -lt $currentTime }
$soonList = $personalList | Where-Object { $_.NotAfter -gt $currentTime -and $_.NotAfter -lt $currentTime.AddDays(30) }
$selfSignedList = $personalList | Where-Object { $_.Subject -eq $_.Issuer }

Register-CertificateSummary -Name 'Expired certificates' -CertificateList $expiredList -PassMessage 'No expired certificates in Personal stores' -WarnMessage 'Expired certificates detected' -FailMessage 'Expired certificates detected' -Severity WARN -SampleCount 3
Register-CertificateSummary -Name 'Certificates expiring soon (30 days)' -CertificateList $soonList -PassMessage 'No certificate expires in next 30 days' -WarnMessage 'Certificates expiring soon' -FailMessage 'Certificates expiring soon' -Severity WARN -SampleCount 3
Register-CertificateSummary -Name 'Self-signed certificates in Personal stores' -CertificateList $selfSignedList -PassMessage 'No self-signed certificates in Personal stores' -WarnMessage 'Self-signed certificates detected' -FailMessage 'Self-signed certificates detected' -Severity WARN -SampleCount 3

$md5List = $personalList | Where-Object { $_.SignatureAlgorithm.FriendlyName -match 'md5' }
$sha1List = $personalList | Where-Object { $_.SignatureAlgorithm.FriendlyName -match 'sha1' }
$keyWeakList = $personalList | Where-Object {
    $keySize = 0
    try {
        $keySize = $_.PublicKey.Key.KeySize
    }
    catch {
        $keySize = 0
    }
    $keySize -gt 0 -and $keySize -lt 2048
}

Register-CertificateSummary -Name 'Certificates with MD5' -CertificateList $md5List -PassMessage 'No certificates use MD5' -WarnMessage 'Certificates use MD5' -FailMessage 'Certificates use MD5' -Severity FAIL -SampleCount 3
Register-CertificateSummary -Name 'Certificates with SHA1' -CertificateList $sha1List -PassMessage 'No certificates use SHA1' -WarnMessage 'Certificates use SHA1' -FailMessage 'Certificates use SHA1' -Severity WARN -SampleCount 3
Register-CertificateSummary -Name 'Certificates with weak key size (<2048)' -CertificateList $keyWeakList -PassMessage 'No weak key sizes detected' -WarnMessage 'Weak key sizes detected' -FailMessage 'Weak key sizes detected' -Severity FAIL -SampleCount 3

Write-Section 'Root and Intermediate Trust Store Health'
$rootList = Get-CertificateInStore -StorePath 'Cert:\LocalMachine\Root'
$intermediateList = Get-CertificateInStore -StorePath 'Cert:\LocalMachine\CA'
$trustedPublisherList = Get-CertificateInStore -StorePath 'Cert:\LocalMachine\TrustedPublisher'
$disallowedList = Get-CertificateInStore -StorePath 'Cert:\LocalMachine\Disallowed'

if ($rootList.Count -eq 0) {
    Register-Check -Name 'Root CA certificates' -Status FAIL -Message 'No root CA certificates found'
}
else {
    Register-Check -Name 'Root CA certificates' -Status PASS -Message ("{0} root CA certificate(s)" -f $rootList.Count)
    $expiredRootList = $rootList | Where-Object { $_.NotAfter -lt $currentTime }
    Register-CertificateSummary -Name 'Expired root CAs' -CertificateList $expiredRootList -PassMessage 'No expired root CAs' -WarnMessage 'Expired root CAs found' -FailMessage 'Expired root CAs found' -Severity WARN -SampleCount 3
}

if ($intermediateList.Count -eq 0) {
    Register-Check -Name 'Intermediate CA certificates' -Status PASS -Message 'No intermediate CAs present (may be normal)'
}
else {
    Register-Check -Name 'Intermediate CA certificates' -Status PASS -Message ("{0} intermediate CA certificate(s)" -f $intermediateList.Count)
}

Register-Check -Name 'Trusted Publishers' -Status PASS -Message ("{0} trusted publisher certificate(s)" -f $trustedPublisherList.Count)
Register-Check -Name 'Disallowed certificates' -Status PASS -Message ("{0} explicitly untrusted certificate(s)" -f $disallowedList.Count)

Write-Section 'Certificate Revocation and Enrollment Configuration'
$revocationKey = 'HKLM:\SOFTWARE\Microsoft\Cryptography\OID\EncodingType 0\CertDllVerifyRevocation\DEFAULT'
$revocationConfig = Get-ItemProperty -Path $revocationKey -Name 'DefaultUrlRetrievalTimeoutMilliseconds' -ErrorAction SilentlyContinue
if ($revocationConfig) {
    Register-Check -Name 'CRL timeout configuration' -Status PASS -Message ("Configured ({0} ms)" -f $revocationConfig.DefaultUrlRetrievalTimeoutMilliseconds)
}
else {
    Register-Check -Name 'CRL timeout configuration' -Status PASS -Message 'Using platform default timeout'
}

$userEnrollment = Get-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Cryptography\AutoEnrollment' -Name 'AEPolicy' -ErrorAction SilentlyContinue
$machineEnrollment = Get-ItemProperty -Path 'HKLM:\Software\Policies\Microsoft\Cryptography\AutoEnrollment' -Name 'AEPolicy' -ErrorAction SilentlyContinue

if ($userEnrollment) {
    Register-Check -Name 'User certificate auto-enrollment' -Status PASS -Message ("Policy value: 0x{0}" -f $userEnrollment.AEPolicy.ToString('X'))
}
else {
    Register-Check -Name 'User certificate auto-enrollment' -Status PASS -Message 'Not configured (manual enrollment)'
}

if ($machineEnrollment) {
    Register-Check -Name 'Machine certificate auto-enrollment' -Status PASS -Message ("Policy value: 0x{0}" -f $machineEnrollment.AEPolicy.ToString('X'))
}
else {
    Register-Check -Name 'Machine certificate auto-enrollment' -Status PASS -Message 'Not configured (manual enrollment)'
}

Write-Section 'Certificate Services (AD CS)'
$certService = Get-Service -Name 'CertSvc' -ErrorAction SilentlyContinue
if ($certService) {
    if ($certService.Status -eq 'Running') {
        Register-Check -Name 'Certificate Services' -Status PASS -Message 'Installed and running'
    }
    else {
        Register-Check -Name 'Certificate Services' -Status WARN -Message 'Installed but not running'
    }
}
else {
    Register-Check -Name 'Certificate Services' -Status PASS -Message 'Not installed (standalone endpoint)'
}

Print-Summary
if ($script:FailedChecks -gt 0) {
    exit 2
}
if ($script:WarnedChecks -gt 0) {
    exit 1
}
exit 0
