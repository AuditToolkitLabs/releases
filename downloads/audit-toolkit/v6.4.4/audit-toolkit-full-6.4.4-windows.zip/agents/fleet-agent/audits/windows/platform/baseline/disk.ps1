#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Disk and Storage Security Audit

.DESCRIPTION
    Comprehensive security audit of disk and storage configuration including:
    - Disk space monitoring and thresholds
    - BitLocker encryption status
    - Volume configuration and health
    - Disk quotas and permissions
    - Mount points and symbolic links
    - Storage pools and virtual disks
    - NTFS permissions on system directories
    - Backup volume detection

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Disk and Storage Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: DISK SPACE MONITORING
#==============================================================================

Write-Section "Disk Space Monitoring"

try {
    $volumes = Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' }

    foreach ($volume in $volumes) {
        $driveLetter = $volume.DriveLetter
        $sizeGB = [math]::Round($volume.Size / 1GB, 2)
        $freeGB = [math]::Round($volume.SizeRemaining / 1GB, 2)
        $percentFree = [math]::Round(($volume.SizeRemaining / $volume.Size) * 100, 1)

        if ($percentFree -lt 10) {
            Register-Check "Drive ${driveLetter}: space" "FAIL" "Only $percentFree% free ($freeGB GB of $sizeGB GB)"
        } elseif ($percentFree -lt 20) {
            Register-Check "Drive ${driveLetter}: space" "WARN" "$percentFree% free ($freeGB GB of $sizeGB GB)"
        } else {
            Register-Check "Drive ${driveLetter}: space" "PASS" "$percentFree% free ($freeGB GB of $sizeGB GB)"
        }
    }

    # Check total number of volumes
    $totalVolumes = ($volumes | Measure-Object).Count
    Register-Check "Fixed volumes detected" "PASS" "$totalVolumes volumes"

} catch {
    Register-Check "Disk space check" "WARN" "Unable to check disk space: $($_.Exception.Message)"
}

#==============================================================================
# SECTION 2: BITLOCKER ENCRYPTION STATUS
#==============================================================================

Write-Section "BitLocker Encryption Status"

try {
    # Check if BitLocker feature is available
    $bitlockerFeature = Get-WindowsOptionalFeature -Online -FeatureName BitLocker -ErrorAction SilentlyContinue

    if ($bitlockerFeature) {
        Register-Check "BitLocker feature" "PASS" "Available"

        # Get BitLocker volumes
        $bitlockerVolumes = Get-BitLockerVolume -ErrorAction SilentlyContinue

        if ($bitlockerVolumes) {
            foreach ($volume in $bitlockerVolumes) {
                $mountPoint = $volume.MountPoint
                $protectionStatus = $volume.ProtectionStatus
                $encryptionPercentage = $volume.EncryptionPercentage

                if ($protectionStatus -eq 'On') {
                    if ($encryptionPercentage -eq 100) {
                        Register-Check "BitLocker on $mountPoint" "PASS" "Fully encrypted (100%)"
                    } else {
                        Register-Check "BitLocker on $mountPoint" "WARN" "Encryption in progress ($encryptionPercentage%)"
                    }
                } else {
                    # System/boot drives should be encrypted
                    if ($mountPoint -match '^[C-D]:\\$') {
                        Register-Check "BitLocker on $mountPoint" "FAIL" "Not encrypted (system drive)"
                    } else {
                        Register-Check "BitLocker on $mountPoint" "WARN" "Not encrypted"
                    }
                }
            }
        } else {
            Register-Check "BitLocker volumes" "WARN" "No BitLocker volumes configured"
        }

    } else {
        Register-Check "BitLocker feature" "WARN" "Not available (Enterprise/Pro required)"
    }

} catch {
    Register-Check "BitLocker check" "WARN" "Unable to check BitLocker: $($_.Exception.Message)"
}

#==============================================================================
# SECTION 3: VOLUME HEALTH STATUS
#==============================================================================

Write-Section "Volume Health Status"

try {
    $volumes = Get-Volume

    foreach ($volume in $volumes | Where-Object { $_.HealthStatus }) {
        $label = if ($volume.DriveLetter) {
            "Volume $($volume.DriveLetter):"
        } else {
            "Volume '$($volume.FileSystemLabel)'"
        }

        switch ($volume.HealthStatus) {
            'Healthy' {
                Register-Check "$label health" "PASS" "Healthy"
            }
            'Warning' {
                Register-Check "$label health" "WARN" "Warning state"
            }
            'Unhealthy' {
                Register-Check "$label health" "FAIL" "Unhealthy - requires attention"
            }
            default {
                Register-Check "$label health" "WARN" "Unknown status: $($volume.HealthStatus)"
            }
        }
    }

    # Check for volumes with non-NTFS filesystem
    $nonNTFS = $volumes | Where-Object {
        $_.DriveLetter -and
        $_.FileSystem -ne 'NTFS' -and
        $_.DriveType -eq 'Fixed'
    }

    if ($nonNTFS) {
        foreach ($vol in $nonNTFS) {
            Register-Check "Volume $($vol.DriveLetter): filesystem" "WARN" "$($vol.FileSystem) (NTFS recommended for security)"
        }
    }

} catch {
    Register-Check "Volume health check" "WARN" "Unable to check volume health"
}

#==============================================================================
# SECTION 4: DISK CONFIGURATION
#==============================================================================

Write-Section "Disk Configuration"

try {
    $disks = Get-Disk

    # Check disk health
    foreach ($disk in $disks) {
        $diskLabel = "Disk $($disk.Number) ($($disk.FriendlyName))"

        if ($disk.HealthStatus -eq 'Healthy') {
            Register-Check "$diskLabel health" "PASS" "Healthy"
        } else {
            Register-Check "$diskLabel health" "FAIL" "Status: $($disk.HealthStatus)"
        }

        # Check if disk is offline
        if ($disk.IsOffline) {
            Register-Check "$diskLabel status" "WARN" "Disk is offline"
        }

        # Check if disk is read-only
        if ($disk.IsReadOnly) {
            Register-Check "$diskLabel permissions" "WARN" "Disk is read-only"
        }
    }

    # Check for uninitialized disks
    $uninitializedDisks = $disks | Where-Object { $_.PartitionStyle -eq 'RAW' }

    if ($uninitializedDisks) {
        $count = ($uninitializedDisks | Measure-Object).Count
        Register-Check "Uninitialized disks" "WARN" "$count disk(s) not initialized (potential security risk)"
    } else {
        Register-Check "Uninitialized disks" "PASS" "All disks initialized"
    }

} catch {
    Register-Check "Disk configuration check" "WARN" "Unable to check disk configuration"
}

#==============================================================================
# SECTION 5: NTFS PERMISSIONS ON SYSTEM DIRECTORIES
#==============================================================================

Write-Section "NTFS Permissions on System Directories"

try {
    $systemDirs = @(
        @{ Path = "$env:SystemRoot"; Name = "Windows directory" },
        @{ Path = "$env:SystemRoot\System32"; Name = "System32 directory" },
        @{ Path = "$env:ProgramFiles"; Name = "Program Files" },
        @{ Path = "$env:ProgramData"; Name = "ProgramData" }
    )

    foreach ($dir in $systemDirs) {
        if (Test-Path $dir.Path) {
            $acl = Get-Acl -Path $dir.Path -ErrorAction SilentlyContinue

            if ($acl) {
                # Check if Users have write access (security risk)
                $usersWriteAccess = $acl.Access | Where-Object {
                    $_.IdentityReference -match "Users" -and
                    ($_.FileSystemRights -match "FullControl|Modify|Write")
                }

                if ($usersWriteAccess) {
                    Register-Check "$($dir.Name) permissions" "FAIL" "Users have write access (security risk)"
                } else {
                    Register-Check "$($dir.Name) permissions" "PASS" "Properly restricted"
                }
            }
        }
    }

} catch {
    Register-Check "NTFS permissions check" "WARN" "Unable to check NTFS permissions"
}

#==============================================================================
# SECTION 6: STORAGE SPACES / STORAGE POOLS
#==============================================================================

Write-Section "Storage Spaces and Pools"

try {
    $storagePools = Get-StoragePool -ErrorAction SilentlyContinue | Where-Object { $_.IsPrimordial -eq $false }

    if ($storagePools) {
        foreach ($pool in $storagePools) {
            if ($pool.HealthStatus -eq 'Healthy') {
                Register-Check "Storage pool '$($pool.FriendlyName)'" "PASS" "Healthy"
            } else {
                Register-Check "Storage pool '$($pool.FriendlyName)'" "WARN" "Status: $($pool.HealthStatus)"
            }
        }

        # Check virtual disks
        $virtualDisks = Get-VirtualDisk -ErrorAction SilentlyContinue

        foreach ($vdisk in $virtualDisks) {
            if ($vdisk.HealthStatus -eq 'Healthy') {
                Register-Check "Virtual disk '$($vdisk.FriendlyName)'" "PASS" "Healthy"
            } else {
                Register-Check "Virtual disk '$($vdisk.FriendlyName)'" "FAIL" "Status: $($vdisk.HealthStatus)"
            }
        }

    } else {
        Register-Check "Storage pools" "PASS" "No custom storage pools (default configuration)"
    }

} catch {
    Register-Check "Storage spaces check" "WARN" "Unable to check storage spaces"
}

#==============================================================================
# SECTION 7: DISK QUOTAS
#==============================================================================

Write-Section "Disk Quotas"

try {
    # Check if disk quotas are enabled on any volume
    $volumes = Get-CimInstance -ClassName Win32_Volume | Where-Object { $_.DriveLetter -ne $null }

    $quotasEnabled = $false

    foreach ($volume in $volumes) {
        if ($volume.QuotasEnabled) {
            $quotasEnabled = $true
            Register-Check "Quotas on $($volume.DriveLetter)" "PASS" "Enabled"
        }
    }

    if (-not $quotasEnabled) {
        Register-Check "Disk quotas" "WARN" "Not enabled on any volume (consider for multi-user systems)"
    }

} catch {
    Register-Check "Disk quotas check" "WARN" "Unable to check disk quotas"
}

#==============================================================================
# SECTION 8: MOUNT POINTS AND SYMBOLIC LINKS
#==============================================================================

Write-Section "Mount Points and Symbolic Links"

try {
    # Check for mount points
    $mountPoints = Get-Volume | Where-Object { $_.Path -and -not $_.DriveLetter }

    if ($mountPoints) {
        $count = ($mountPoints | Measure-Object).Count
        Register-Check "Volume mount points" "PASS" "$count mount point(s) configured"

        # List them for visibility
        foreach ($mp in $mountPoints | Select-Object -First 3) {
            Write-Output "  Mount: $($mp.Path) - $($mp.FileSystemLabel)"
        }
    } else {
        Register-Check "Volume mount points" "PASS" "No mount points (standard configuration)"
    }

    # Check system directory for suspicious symbolic links
    $systemRoot = $env:SystemRoot
    $suspiciousLinks = Get-ChildItem -Path $systemRoot -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Attributes -match "ReparsePoint" } |
        Where-Object { $_.Name -notmatch "^(AppCompat|Logs|WinSxS|servicing)$" }

    if ($suspiciousLinks) {
        $count = ($suspiciousLinks | Measure-Object).Count
        Register-Check "Symbolic links in system directory" "WARN" "$count unexpected link(s) (review required)"
    } else {
        Register-Check "Symbolic links in system directory" "PASS" "No unexpected symbolic links"
    }

} catch {
    Register-Check "Mount points check" "WARN" "Unable to check mount points"
}

#==============================================================================
# SECTION 9: PAGING FILE CONFIGURATION
#==============================================================================

Write-Section "Paging File Configuration"

try {
    $pagingFiles = Get-CimInstance -ClassName Win32_PageFileUsage

    if ($pagingFiles) {
        foreach ($pf in $pagingFiles) {
            $drive = $pf.Name.Substring(0, 2)
            $currentSizeMB = $pf.AllocatedBaseSize
            $peakUsageMB = $pf.PeakUsage

            Register-Check "Paging file on $drive" "PASS" "Allocated: $currentSizeMB MB, Peak: $peakUsageMB MB"
        }
    } else {
        Register-Check "Paging file" "WARN" "No paging file configured (may impact performance)"
    }

    # Check if paging file is on system drive
    $systemDrive = $env:SystemDrive
    $pagingOnSystemDrive = $pagingFiles | Where-Object { $_.Name -like "${systemDrive}*" }

    if ($pagingOnSystemDrive) {
        Register-Check "Paging file location" "PASS" "On system drive (standard)"
    }

} catch {
    Register-Check "Paging file check" "WARN" "Unable to check paging file configuration"
}

#==============================================================================
# SECTION 10: BACKUP VOLUMES
#==============================================================================

Write-Section "Backup Volumes"

try {
    # Check for volumes that might be backup drives
    $volumes = Get-Volume | Where-Object {
        $_.FileSystemLabel -match "backup|bak|recovery|restore" -and
        $_.DriveLetter
    }

    if ($volumes) {
        foreach ($vol in $volumes) {
            $label = "$($vol.DriveLetter): ($($vol.FileSystemLabel))"
            Register-Check "Backup volume $label" "PASS" "Detected"
        }
    } else {
        Register-Check "Backup volumes" "WARN" "No dedicated backup volumes detected (verify backup strategy)"
    }

    # Check Windows Server Backup status (if available)
    if (Test-IsServerOS) {
        $wsbService = Get-Service -Name wbengine -ErrorAction SilentlyContinue

        if ($wsbService) {
            if ($wsbService.Status -eq 'Running') {
                Register-Check "Windows Server Backup service" "PASS" "Running"
            } else {
                Register-Check "Windows Server Backup service" "WARN" "Not running"
            }
        }
    }

} catch {
    Register-Check "Backup volumes check" "WARN" "Unable to check backup configuration"
}

#==============================================================================
# SECTION 11: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
