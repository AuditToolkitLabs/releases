﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Event Logs Security Audit

.DESCRIPTION
    Comprehensive security audit of Windows Event Logs including:
    - Event Log service status and configuration
    - Security log size and retention policies
    - Critical security events detection
    - Failed logon attempts and account lockouts
    - Privilege escalation events
    - Audit policy configuration
    - Event log forwarding and collection
    - Log tampering detection
    - Event log archival and backup
    - Critical system events

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Event Logs Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: EVENT LOG SERVICE STATUS
#==============================================================================

Write-Section "Event Log Service Status"

try {
    $eventLogService = Get-Service -Name "EventLog" -ErrorAction SilentlyContinue

    if ($eventLogService) {
        if ($eventLogService.Status -eq 'Running') {
            Register-Check "Event Log service" "PASS" "Running"
        } else {
            Register-Check "Event Log service" "FAIL" "Not running (Status: $($eventLogService.Status))"
        }

        if ($eventLogService.StartType -eq 'Automatic') {
            Register-Check "Event Log startup type" "PASS" "Automatic"
        } else {
            Register-Check "Event Log startup type" "FAIL" "Not automatic (Type: $($eventLogService.StartType))"
        }
    } else {
        Register-Check "Event Log service" "FAIL" "Service not found"
    }

} catch {
    Register-Check "Event Log service check" "WARN" "Unable to check service: $($_.Exception.Message)"
}

#==============================================================================
# SECTION 2: SECURITY LOG CONFIGURATION
#==============================================================================

Write-Section "Security Log Configuration"

try {
    $securityLog = Get-WinEvent -ListLog Security -ErrorAction SilentlyContinue

    if ($securityLog) {
        # Log size
        $logSizeMB = [math]::Round($securityLog.MaximumSizeInBytes / 1MB, 2)

        if ($logSizeMB -ge 1024) {
            Register-Check "Security log size" "PASS" "$logSizeMB MB (adequate for enterprise)"
        } elseif ($logSizeMB -ge 512) {
            Register-Check "Security log size" "WARN" "$logSizeMB MB (increase for better retention)"
        } else {
            Register-Check "Security log size" "FAIL" "$logSizeMB MB (too small, increase to ≥512 MB)"
        }

        # Log retention
        if ($securityLog.LogMode -eq 'Circular') {
            Register-Check "Security log retention" "WARN" "Circular (overwrites old events)"
        } elseif ($securityLog.LogMode -eq 'AutoBackup') {
            Register-Check "Security log retention" "PASS" "Auto-backup enabled"
        } else {
            Register-Check "Security log retention" "PASS" "Mode: $($securityLog.LogMode)"
        }

        # Log enabled
        if ($securityLog.IsEnabled) {
            Register-Check "Security log enabled" "PASS" "Enabled"
        } else {
            Register-Check "Security log enabled" "FAIL" "Disabled (critical security risk)"
        }

    } else {
        Register-Check "Security log" "FAIL" "Unable to access Security log"
    }

} catch {
    Register-Check "Security log configuration" "WARN" "Unable to check log configuration"
}

#==============================================================================
# SECTION 3: SYSTEM LOG CONFIGURATION
#==============================================================================

Write-Section "System Log Configuration"

try {
    $systemLog = Get-WinEvent -ListLog System -ErrorAction SilentlyContinue

    if ($systemLog) {
        $logSizeMB = [math]::Round($systemLog.MaximumSizeInBytes / 1MB, 2)

        if ($logSizeMB -ge 512) {
            Register-Check "System log size" "PASS" "$logSizeMB MB"
        } elseif ($logSizeMB -ge 100) {
            Register-Check "System log size" "WARN" "$logSizeMB MB (increase for better diagnostics)"
        } else {
            Register-Check "System log size" "FAIL" "$logSizeMB MB (too small)"
        }

        if ($systemLog.IsEnabled) {
            Register-Check "System log enabled" "PASS" "Enabled"
        } else {
            Register-Check "System log enabled" "FAIL" "Disabled"
        }
    }

} catch {
    Register-Check "System log configuration" "WARN" "Unable to check System log"
}

#==============================================================================
# SECTION 4: APPLICATION LOG CONFIGURATION
#==============================================================================

Write-Section "Application Log Configuration"

try {
    $applicationLog = Get-WinEvent -ListLog Application -ErrorAction SilentlyContinue

    if ($applicationLog) {
        $logSizeMB = [math]::Round($applicationLog.MaximumSizeInBytes / 1MB, 2)

        if ($logSizeMB -ge 256) {
            Register-Check "Application log size" "PASS" "$logSizeMB MB"
        } elseif ($logSizeMB -ge 100) {
            Register-Check "Application log size" "WARN" "$logSizeMB MB (increase recommended)"
        } else {
            Register-Check "Application log size" "FAIL" "$logSizeMB MB (too small)"
        }

        if ($applicationLog.IsEnabled) {
            Register-Check "Application log enabled" "PASS" "Enabled"
        } else {
            Register-Check "Application log enabled" "WARN" "Disabled"
        }
    }

} catch {
    Register-Check "Application log configuration" "WARN" "Unable to check Application log"
}

#==============================================================================
# SECTION 5: FAILED LOGON ATTEMPTS
#==============================================================================

Write-Section "Failed Logon Attempts (Last 24 Hours)"

try {
    # Event ID 4625 = Failed logon
    $failedLogons = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        ID = 4625
        StartTime = (Get-Date).AddDays(-1)
    } -MaxEvents 100 -ErrorAction SilentlyContinue

    if ($failedLogons) {
        $count = ($failedLogons | Measure-Object).Count

        if ($count -gt 50) {
            Register-Check "Failed logon attempts" "FAIL" "$count failed logons (possible brute force attack)"
        } elseif ($count -gt 20) {
            Register-Check "Failed logon attempts" "WARN" "$count failed logons (investigate)"
        } else {
            Register-Check "Failed logon attempts" "PASS" "$count failed logons (normal activity)"
        }

        # Check for specific high-value accounts
        $adminFailures = $failedLogons | Where-Object {
            $_.Properties[5].Value -match "Administrator|admin|root"
        }

        if ($adminFailures) {
            $adminCount = ($adminFailures | Measure-Object).Count
            Register-Check "Failed admin logons" "WARN" "$adminCount failed attempts on privileged accounts"
        }

    } else {
        Register-Check "Failed logon attempts" "PASS" "No failed logons in last 24 hours"
    }

} catch {
    Register-Check "Failed logon check" "WARN" "Unable to query failed logon events"
}

#==============================================================================
# SECTION 6: ACCOUNT LOCKOUT EVENTS
#==============================================================================

Write-Section "Account Lockout Events (Last 7 Days)"

try {
    # Event ID 4740 = Account lockout
    $lockouts = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        ID = 4740
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 50 -ErrorAction SilentlyContinue

    if ($lockouts) {
        $count = ($lockouts | Measure-Object).Count

        if ($count -gt 10) {
            Register-Check "Account lockouts" "WARN" "$count account lockouts (high rate)"
        } else {
            Register-Check "Account lockouts" "PASS" "$count account lockouts"
        }

        # List first 3 locked accounts
        foreach ($lockout in $lockouts | Select-Object -First 3) {
            $accountName = $lockout.Properties[0].Value
            $time = $lockout.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
            Write-Output "  Locked: $accountName at $time"
        }

    } else {
        Register-Check "Account lockouts" "PASS" "No account lockouts in last 7 days"
    }

} catch {
    Register-Check "Account lockout check" "WARN" "Unable to query lockout events"
}

#==============================================================================
# SECTION 7: PRIVILEGE ESCALATION EVENTS
#==============================================================================

Write-Section "Privilege Escalation Events (Last 24 Hours)"

try {
    # Event ID 4672 = Special privileges assigned to new logon
    $privEscalation = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        ID = 4672
        StartTime = (Get-Date).AddDays(-1)
    } -MaxEvents 50 -ErrorAction SilentlyContinue

    if ($privEscalation) {
        $count = ($privEscalation | Measure-Object).Count
        Register-Check "Privilege escalation events" "PASS" "$count events in last 24 hours"

        # Filter for non-system accounts
        $userPrivEsc = $privEscalation | Where-Object {
            $_.Properties[1].Value -notmatch "SYSTEM|LOCAL SERVICE|NETWORK SERVICE"
        }

        if ($userPrivEsc) {
            $userCount = ($userPrivEsc | Measure-Object).Count
            if ($userCount -gt 10) {
                Register-Check "User privilege escalations" "WARN" "$userCount user privilege escalations (review)"
            } else {
                Register-Check "User privilege escalations" "PASS" "$userCount user privilege escalations"
            }
        }

    } else {
        Register-Check "Privilege escalation events" "PASS" "No privilege escalation events"
    }

} catch {
    Register-Check "Privilege escalation check" "WARN" "Unable to query privilege escalation events"
}

#==============================================================================
# SECTION 8: AUDIT POLICY CONFIGURATION
#==============================================================================

Write-Section "Audit Policy Configuration"

try {
    # Check key audit policies using auditpol
    $auditCategories = @(
        @{ Name = "Logon/Logoff"; SubCategory = "Logon" },
        @{ Name = "Logon/Logoff"; SubCategory = "Logoff" },
        @{ Name = "Account Logon"; SubCategory = "Credential Validation" },
        @{ Name = "Account Management"; SubCategory = "User Account Management" },
        @{ Name = "Privilege Use"; SubCategory = "Sensitive Privilege Use" }
    )

    foreach ($category in $auditCategories) {
        $result = auditpol /get /subcategory:"$($category.SubCategory)" 2>&1

        if ($result -match "Success and Failure") {
            Register-Check "Audit: $($category.SubCategory)" "PASS" "Success and Failure"
        } elseif ($result -match "Success|Failure") {
            Register-Check "Audit: $($category.SubCategory)" "WARN" "Partial auditing (enable both)"
        } else {
            Register-Check "Audit: $($category.SubCategory)" "FAIL" "Not enabled"
        }
    }

} catch {
    Register-Check "Audit policy check" "WARN" "Unable to check audit policies"
}

#==============================================================================
# SECTION 9: CRITICAL SYSTEM EVENTS
#==============================================================================

Write-Section "Critical System Events (Last 7 Days)"

try {
    # Check for critical system errors
    $criticalEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'System'
        Level = 1  # Critical
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 20 -ErrorAction SilentlyContinue

    if ($criticalEvents) {
        $count = ($criticalEvents | Measure-Object).Count

        if ($count -gt 10) {
            Register-Check "Critical system events" "FAIL" "$count critical events (investigate immediately)"
        } elseif ($count -gt 3) {
            Register-Check "Critical system events" "WARN" "$count critical events (review required)"
        } else {
            Register-Check "Critical system events" "PASS" "$count critical events"
        }

        # List first 3 critical events
        foreach ($criticalEvent in $criticalEvents | Select-Object -First 3) {
            $time = $criticalEvent.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
            $message = $criticalEvent.Message.Substring(0, [Math]::Min(80, $criticalEvent.Message.Length))
            Write-Output "  Critical: ID $($criticalEvent.Id) at $time - $message..."
        }

    } else {
        Register-Check "Critical system events" "PASS" "No critical system events in last 7 days"
    }

} catch {
    Register-Check "Critical events check" "WARN" "Unable to query critical events"
}

#==============================================================================
# SECTION 10: EVENT LOG CLEARING DETECTION
#==============================================================================

Write-Section "Event Log Clearing Detection (Last 30 Days)"

try {
    # Event ID 1102 = Security log cleared
    # Event ID 104 = System log cleared
    $logClearingEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Security', 'System'
        ID = 1102, 104
        StartTime = (Get-Date).AddDays(-30)
    } -MaxEvents 10 -ErrorAction SilentlyContinue

    if ($logClearingEvents) {
        $count = ($logClearingEvents | Measure-Object).Count
        Register-Check "Event log clearing detected" "FAIL" "$count log clearing event(s) (investigate for tampering)"

        foreach ($logClearingEvent in $logClearingEvents | Select-Object -First 3) {
            $time = $logClearingEvent.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
            $log = $logClearingEvent.LogName
            Write-Output "  Log cleared: $log at $time"
        }

    } else {
        Register-Check "Event log clearing" "PASS" "No log clearing events in last 30 days"
    }

} catch {
    Register-Check "Log clearing detection" "WARN" "Unable to check for log clearing events"
}

#==============================================================================
# SECTION 11: WINDOWS FIREWALL EVENTS
#==============================================================================

Write-Section "Windows Firewall Events (Last 24 Hours)"

try {
    # Check Windows Firewall log for dropped connections
    $firewallLog = Get-WinEvent -FilterHashtable @{
        LogName = 'Microsoft-Windows-Windows Firewall With Advanced Security/Firewall'
        StartTime = (Get-Date).AddDays(-1)
    } -MaxEvents 100 -ErrorAction SilentlyContinue

    if ($firewallLog) {
        $count = ($firewallLog | Measure-Object).Count

        # Event ID 2004 = Firewall rule added
        $ruleChanges = $firewallLog | Where-Object { $_.Id -eq 2004 }

        if ($ruleChanges) {
            $ruleCount = ($ruleChanges | Measure-Object).Count
            if ($ruleCount -gt 5) {
                Register-Check "Firewall rule changes" "WARN" "$ruleCount rule changes (review for unauthorized changes)"
            } else {
                Register-Check "Firewall rule changes" "PASS" "$ruleCount rule changes"
            }
        } else {
            Register-Check "Firewall rule changes" "PASS" "No firewall rule changes"
        }

    } else {
        Register-Check "Firewall events" "PASS" "No firewall events or logging disabled"
    }

} catch {
    Register-Check "Firewall events check" "WARN" "Unable to query firewall events"
}

#==============================================================================
# SECTION 12: POWERSHELL EXECUTION EVENTS
#==============================================================================

Write-Section "PowerShell Execution Events (Last 24 Hours)"

try {
    # Event ID 4104 = PowerShell script block logging
    $psEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Microsoft-Windows-PowerShell/Operational'
        ID = 4104
        StartTime = (Get-Date).AddDays(-1)
    } -MaxEvents 50 -ErrorAction SilentlyContinue

    if ($psEvents) {
        $count = ($psEvents | Measure-Object).Count
        Register-Check "PowerShell script executions" "PASS" "$count script blocks executed"

        # Check for suspicious PowerShell patterns
        $suspiciousPS = $psEvents | Where-Object {
            $_.Message -match "-enc|-encodedcommand|invoke-expression|iex|downloadstring|downloadfile"
        }

        if ($suspiciousPS) {
            $suspCount = ($suspiciousPS | Measure-Object).Count
            Register-Check "Suspicious PowerShell patterns" "WARN" "$suspCount suspicious script executions (review)"
        } else {
            Register-Check "Suspicious PowerShell patterns" "PASS" "No suspicious patterns detected"
        }

    } else {
        Register-Check "PowerShell script logging" "WARN" "No PowerShell events (logging may be disabled)"
    }

} catch {
    Register-Check "PowerShell events check" "WARN" "Unable to query PowerShell events"
}

#==============================================================================
# SECTION 13: EVENT FORWARDING CONFIGURATION
#==============================================================================

Write-Section "Event Forwarding Configuration"

try {
    # Check if Windows Event Collector service exists (for event forwarding)
    $wecSvc = Get-Service -Name "Wecsvc" -ErrorAction SilentlyContinue

    if ($wecSvc) {
        if ($wecSvc.Status -eq 'Running') {
            Register-Check "Event Collector service" "PASS" "Running (centralized logging enabled)"
        } else {
            Register-Check "Event Collector service" "WARN" "Installed but not running"
        }
    } else {
        Register-Check "Event Collector service" "PASS" "Not installed (standalone configuration)"
    }

    # Check Event Forwarding subscriptions
    $subscriptions = wecutil es 2>&1

    if ($subscriptions -and $subscriptions -notmatch "Error|failed") {
        Register-Check "Event forwarding subscriptions" "PASS" "Configured"
    } else {
        Register-Check "Event forwarding subscriptions" "WARN" "No subscriptions (consider centralized logging)"
    }

} catch {
    Register-Check "Event forwarding check" "WARN" "Unable to check event forwarding"
}

#==============================================================================
# SECTION 14: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}

