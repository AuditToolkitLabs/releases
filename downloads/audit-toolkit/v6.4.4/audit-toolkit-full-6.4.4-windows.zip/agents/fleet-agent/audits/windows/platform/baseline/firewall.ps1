#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Firewall Security Audit

.DESCRIPTION
    Comprehensive security audit of Windows Defender Firewall including:
    - Firewall service status
    - Profile configurations (Domain, Private, Public)
    - Inbound/outbound rule analysis
    - Default deny policies
    - Risky port exposures
    - Rule consistency and conflicts
    - Logging configuration

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Firewall Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: FIREWALL SERVICE STATUS
#==============================================================================

Write-Section "Firewall Service Status"

# Check if Windows Firewall service is running
if (Test-ServiceRunning 'mpssvc') {
    Register-Check "Windows Firewall service" "PASS" "Running"
} else {
    Register-Check "Windows Firewall service" "FAIL" "Not running - Critical security issue!"
    Print-Summary
    exit 2
}

# Check firewall driver status
$fwDriver = Get-Service -Name 'mpsdrv' -ErrorAction SilentlyContinue
if ($null -ne $fwDriver -and $fwDriver.Status -eq 'Running') {
    Register-Check "Firewall driver (mpsdrv)" "PASS" "Running"
} else {
    Register-Check "Firewall driver (mpsdrv)" "WARN" "Not running properly"
}

#==============================================================================
# SECTION 2: FIREWALL PROFILES CONFIGURATION
#==============================================================================

Write-Section "Firewall Profiles Configuration"

# Get firewall profile information
try {
    $domainProfile = Get-NetFirewallProfile -Name Domain -ErrorAction Stop
    $privateProfile = Get-NetFirewallProfile -Name Private -ErrorAction Stop
    $publicProfile = Get-NetFirewallProfile -Name Public -ErrorAction Stop

    # Check Domain profile
    if ($domainProfile.Enabled) {
        Register-Check "Domain profile" "PASS" "Enabled"
    } else {
        Register-Check "Domain profile" "FAIL" "Disabled - Major security risk!"
    }

    # Check Private profile
    if ($privateProfile.Enabled) {
        Register-Check "Private profile" "PASS" "Enabled"
    } else {
        Register-Check "Private profile" "FAIL" "Disabled - Security risk!"
    }

    # Check Public profile (most restrictive, should always be enabled)
    if ($publicProfile.Enabled) {
        Register-Check "Public profile" "PASS" "Enabled"
    } else {
        Register-Check "Public profile" "FAIL" "Disabled - Critical security risk!"
    }

} catch {
    Register-Check "Firewall profiles" "FAIL" "Unable to retrieve profile information"
}

#==============================================================================
# SECTION 3: PROFILE DEFAULT ACTIONS
#==============================================================================

Write-Section "Default Firewall Actions"

# Check default inbound/outbound actions for each profile
try {
    # Domain profile default actions
    if ($domainProfile.DefaultInboundAction -eq 'Block') {
        Register-Check "Domain: Default inbound" "PASS" "Block (secure)"
    } else {
        Register-Check "Domain: Default inbound" "FAIL" "Allow (insecure) - Should be Block"
    }

    if ($domainProfile.DefaultOutboundAction -eq 'Allow') {
        Register-Check "Domain: Default outbound" "PASS" "Allow (standard)"
    } else {
        Register-Check "Domain: Default outbound" "WARN" "Block (very restrictive)"
    }

    # Private profile default actions
    if ($privateProfile.DefaultInboundAction -eq 'Block') {
        Register-Check "Private: Default inbound" "PASS" "Block (secure)"
    } else {
        Register-Check "Private: Default inbound" "FAIL" "Allow (insecure) - Should be Block"
    }

    if ($privateProfile.DefaultOutboundAction -eq 'Allow') {
        Register-Check "Private: Default outbound" "PASS" "Allow (standard)"
    } else {
        Register-Check "Private: Default outbound" "WARN" "Block (very restrictive)"
    }

    # Public profile default actions (should be most restrictive)
    if ($publicProfile.DefaultInboundAction -eq 'Block') {
        Register-Check "Public: Default inbound" "PASS" "Block (secure)"
    } else {
        Register-Check "Public: Default inbound" "FAIL" "Allow (very insecure!) - Should be Block"
    }

    if ($publicProfile.DefaultOutboundAction -eq 'Allow') {
        Register-Check "Public: Default outbound" "PASS" "Allow (standard)"
    } else {
        Register-Check "Public: Default outbound" "WARN" "Block (very restrictive)"
    }

} catch {
    Register-Check "Profile default actions" "FAIL" "Unable to check default actions"
}

#==============================================================================
# SECTION 4: INBOUND RULES ANALYSIS
#==============================================================================

Write-Section "Inbound Rules Analysis"

try {
    $inboundRules = Get-NetFirewallRule -Direction Inbound -ErrorAction Stop

    # Count enabled inbound Allow rules
    $enabledAllowRules = ($inboundRules | Where-Object { $_.Enabled -eq $true -and $_.Action -eq 'Allow' }).Count

    if ($enabledAllowRules -le 10) {
        Register-Check "Inbound Allow rules" "PASS" "$enabledAllowRules rules (minimal attack surface)"
    } elseif ($enabledAllowRules -le 30) {
        Register-Check "Inbound Allow rules" "WARN" "$enabledAllowRules rules (review recommended)"
    } else {
        Register-Check "Inbound Allow rules" "FAIL" "$enabledAllowRules rules (excessive, review required)"
    }

    # Check for rules allowing ANY source
    $anySourceRules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow -ErrorAction SilentlyContinue | Get-NetFirewallAddressFilter | Where-Object { $_.RemoteAddress -contains 'Any' }

    if ($null -eq $anySourceRules -or $anySourceRules.Count -le 5) {
        Register-Check "Rules allowing any source" "PASS" "Limited rules with 'Any' source"
    } elseif ($anySourceRules.Count -le 15) {
        Register-Check "Rules allowing any source" "WARN" "$($anySourceRules.Count) rules allow any source IP"
    } else {
        Register-Check "Rules allowing any source" "FAIL" "$($anySourceRules.Count) rules allow any source IP (security risk)"
    }

} catch {
    Register-Check "Inbound rules analysis" "WARN" "Unable to fully analyze inbound rules"
}

#==============================================================================
# SECTION 5: RISKY PORT EXPOSURES
#==============================================================================

Write-Section "Risky Port Exposures"

# Define risky ports that should not be exposed
$riskyPorts = @{
    '21' = 'FTP (unencrypted)'
    '23' = 'Telnet (unencrypted)'
    '25' = 'SMTP (relay abuse risk)'
    '135' = 'RPC (Windows exploit target)'
    '139' = 'NetBIOS (legacy, insecure)'
    '445' = 'SMB (ransomware target)'
    '1433' = 'SQL Server (database exposure)'
    '3306' = 'MySQL (database exposure)'
    '3389' = 'RDP (brute force target)'
    '5900' = 'VNC (weak authentication)'
    '8080' = 'HTTP Proxy (often misconfigured)'
}

try {
    $exposedPorts = @()

    foreach ($port in $riskyPorts.Keys) {
        $rules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow -ErrorAction SilentlyContinue |
            Get-NetFirewallPortFilter -ErrorAction SilentlyContinue |
            Where-Object { $_.LocalPort -eq $port }

        if ($rules) {
            $exposedPorts += "$port ($($riskyPorts[$port]))"
        }
    }

    if ($exposedPorts.Count -eq 0) {
        Register-Check "Risky ports exposed" "PASS" "No high-risk ports exposed"
    } elseif ($exposedPorts.Count -le 2) {
        $portList = $exposedPorts -join ', '
        Register-Check "Risky ports exposed" "WARN" "$($exposedPorts.Count) risky ports: $portList"
    } else {
        $portList = ($exposedPorts | Select-Object -First 3) -join ', '
        Register-Check "Risky ports exposed" "FAIL" "$($exposedPorts.Count) risky ports exposed: $portList..."
    }

} catch {
    Register-Check "Risky port check" "WARN" "Unable to check port exposures"
}

#==============================================================================
# SECTION 6: SPECIFIC PROTOCOL CHECKS
#==============================================================================

Write-Section "Protocol-Specific Security"

# Check RDP (3389) exposure
try {
    $rdpRules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow -ErrorAction SilentlyContinue |
        Get-NetFirewallPortFilter -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -eq '3389' }

    if ($rdpRules) {
        # Check if restricted to specific IPs
        $rdpAddressFilter = $rdpRules | Get-NetFirewallAddressFilter -ErrorAction SilentlyContinue

        if ($rdpAddressFilter.RemoteAddress -contains 'Any') {
            Register-Check "RDP firewall rule" "FAIL" "RDP exposed to any IP (major security risk)"
        } else {
            Register-Check "RDP firewall rule" "WARN" "RDP enabled with IP restrictions (ensure strong passwords)"
        }
    } else {
        Register-Check "RDP firewall rule" "PASS" "RDP not exposed via firewall"
    }
} catch {
    Register-Check "RDP firewall rule" "WARN" "Unable to check RDP rules"
}

# Check SMB (445) exposure
try {
    $smbRules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow -ErrorAction SilentlyContinue |
        Get-NetFirewallPortFilter -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -eq '445' }

    if ($smbRules) {
        $smbAddressFilter = $smbRules | Get-NetFirewallAddressFilter -ErrorAction SilentlyContinue

        if ($smbAddressFilter.RemoteAddress -contains 'Any') {
            Register-Check "SMB firewall rule" "FAIL" "SMB exposed to any IP (ransomware risk)"
        } else {
            Register-Check "SMB firewall rule" "WARN" "SMB enabled with restrictions (ensure SMB signing)"
        }
    } else {
        Register-Check "SMB firewall rule" "PASS" "SMB not exposed externally"
    }
} catch {
    Register-Check "SMB firewall rule" "WARN" "Unable to check SMB rules"
}

# Check WinRM (5985/5986)
try {
    $winrmRules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow -ErrorAction SilentlyContinue |
        Get-NetFirewallPortFilter -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -in @('5985', '5986') }

    if ($winrmRules) {
        Register-Check "WinRM firewall rule" "WARN" "PowerShell Remoting exposed (ensure proper authentication)"
    } else {
        Register-Check "WinRM firewall rule" "PASS" "WinRM not exposed via firewall"
    }
} catch {
    Register-Check "WinRM firewall rule" "WARN" "Unable to check WinRM rules"
}

#==============================================================================
# SECTION 7: OUTBOUND RULES
#==============================================================================

Write-Section "Outbound Rules"

try {
    $outboundRules = Get-NetFirewallRule -Direction Outbound -ErrorAction Stop

    # Count enabled outbound Block rules
    $enabledBlockRules = ($outboundRules | Where-Object { $_.Enabled -eq $true -and $_.Action -eq 'Block' }).Count

    if ($enabledBlockRules -eq 0) {
        Register-Check "Outbound Block rules" "WARN" "No outbound blocking rules (consider data exfiltration controls)"
    } elseif ($enabledBlockRules -le 10) {
        Register-Check "Outbound Block rules" "PASS" "$enabledBlockRules outbound blocking rules"
    } else {
        Register-Check "Outbound Block rules" "PASS" "$enabledBlockRules outbound blocking rules (strict)"
    }

} catch {
    Register-Check "Outbound rules" "WARN" "Unable to check outbound rules"
}

#==============================================================================
# SECTION 8: FIREWALL LOGGING
#==============================================================================

Write-Section "Firewall Logging"

try {
    # Check Domain profile logging
    if ($domainProfile.LogAllowed -eq $true -or $domainProfile.LogBlocked -eq $true) {
        Register-Check "Domain profile logging" "PASS" "Enabled"
    } else {
        Register-Check "Domain profile logging" "WARN" "Disabled (no audit trail)"
    }

    # Check Private profile logging
    if ($privateProfile.LogAllowed -eq $true -or $privateProfile.LogBlocked -eq $true) {
        Register-Check "Private profile logging" "PASS" "Enabled"
    } else {
        Register-Check "Private profile logging" "WARN" "Disabled (no audit trail)"
    }

    # Check Public profile logging (should definitely be enabled)
    if ($publicProfile.LogAllowed -eq $true -or $publicProfile.LogBlocked -eq $true) {
        Register-Check "Public profile logging" "PASS" "Enabled"
    } else {
        Register-Check "Public profile logging" "FAIL" "Disabled (critical for security monitoring)"
    }

    # Check log file size limits
    $maxLogSize = [Math]::Max([Math]::Max($domainProfile.LogMaxSizeKilobytes, $privateProfile.LogMaxSizeKilobytes), $publicProfile.LogMaxSizeKilobytes)

    if ($maxLogSize -ge 16384) {  # 16 MB
        Register-Check "Firewall log size" "PASS" "$maxLogSize KB (adequate)"
    } elseif ($maxLogSize -ge 4096) {  # 4 MB
        Register-Check "Firewall log size" "WARN" "$maxLogSize KB (consider increasing)"
    } else {
        Register-Check "Firewall log size" "FAIL" "$maxLogSize KB (too small, logs will rotate quickly)"
    }

} catch {
    Register-Check "Firewall logging" "WARN" "Unable to check logging configuration"
}

#==============================================================================
# SECTION 9: RULE GROUP ANALYSIS
#==============================================================================

Write-Section "Rule Groups and Built-in Rules"

try {
    # Check for disabled built-in rule groups that should be enabled
    $coreNetworkingGroup = Get-NetFirewallRule -Group "@FirewallAPI.dll,-28502" -ErrorAction SilentlyContinue
    $coreNetworkingEnabled = ($coreNetworkingGroup | Where-Object { $_.Enabled -eq $true }).Count

    if ($coreNetworkingEnabled -gt 0) {
        Register-Check "Core Networking rules" "PASS" "$coreNetworkingEnabled rules enabled"
    } else {
        Register-Check "Core Networking rules" "WARN" "Core networking rules may be disabled"
    }

    # Check Windows Defender rules
    $defenderGroup = Get-NetFirewallRule | Where-Object { $_.DisplayName -like "*Defender*" -and $_.Enabled -eq $true }

    if ($defenderGroup.Count -gt 0) {
        Register-Check "Windows Defender rules" "PASS" "$($defenderGroup.Count) Defender rules active"
    } else {
        Register-Check "Windows Defender rules" "WARN" "No Defender firewall rules enabled"
    }

} catch {
    Register-Check "Rule groups" "WARN" "Unable to analyze rule groups"
}

#==============================================================================
# SECTION 10: FIREWALL NOTIFICATIONS
#==============================================================================

Write-Section "Firewall Notifications"

try {
    # Check if users are notified when firewall blocks apps
    if ($domainProfile.NotifyOnListen -eq $true) {
        Register-Check "Domain: Block notifications" "PASS" "Users are notified"
    } else {
        Register-Check "Domain: Block notifications" "WARN" "Silent blocking (users not notified)"
    }

    if ($publicProfile.NotifyOnListen -eq $true) {
        Register-Check "Public: Block notifications" "PASS" "Users are notified"
    } else {
        Register-Check "Public: Block notifications" "WARN" "Silent blocking (users not notified)"
    }

} catch {
    Register-Check "Notification settings" "WARN" "Unable to check notification settings"
}

#==============================================================================
# SECTION 11: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
