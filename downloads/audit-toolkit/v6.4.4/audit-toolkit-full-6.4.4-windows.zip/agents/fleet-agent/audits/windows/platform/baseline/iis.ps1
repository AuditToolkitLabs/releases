#Requires -Version 5.1
<#
.SYNOPSIS
    IIS (Internet Information Services) Security Audit

.DESCRIPTION
    Comprehensive IIS web server security audit including:
    - IIS installation and version detection
    - Application pool security configuration
    - SSL/TLS protocol and cipher configuration
    - Authentication methods and security
    - HTTP headers and security settings
    - Request filtering and validation
    - Logging and monitoring configuration
    - Directory browsing and default documents
    - ISAPI filters and extensions
    - FTP service security (if installed)

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges, IIS installed
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "IIS Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: IIS INSTALLATION AND VERSION
#==============================================================================

Write-Section "IIS Installation and Version"

try {
    # Check if IIS is installed
    $iisService = Get-Service -Name "W3SVC" -ErrorAction SilentlyContinue

    if (-not $iisService) {
        Write-Output "[SKIP] IIS is not installed on this system"
        Print-Summary
        exit 0
    }

    # Get IIS version
    $iisVersion = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp\" -ErrorAction SilentlyContinue

    if ($iisVersion) {
        $majorVersion = $iisVersion.MajorVersion
        $minorVersion = $iisVersion.MinorVersion
        $version = "$majorVersion.$minorVersion"

        Write-Output "IIS Version: $version"

        # IIS 10.0 = Windows Server 2016/Windows 10
        # IIS 8.5 = Windows Server 2012 R2
        if ($majorVersion -ge 10) {
            Register-Check "IIS version" "PASS" "Version $version (current)"
        } elseif ($majorVersion -ge 8) {
            Register-Check "IIS version" "WARN" "Version $version (consider upgrade)"
        } else {
            Register-Check "IIS version" "FAIL" "Version $version (outdated, upgrade required)"
        }
    }

    # Check IIS service status
    if ($iisService.Status -eq 'Running') {
        Register-Check "IIS service" "PASS" "Running"
    } else {
        Register-Check "IIS service" "WARN" "Not running (Status: $($iisService.Status))"
    }

    # Import WebAdministration module
    Import-Module WebAdministration -ErrorAction SilentlyContinue

    if (-not (Get-Module -Name WebAdministration)) {
        Write-Output "[WARN] WebAdministration module not available, some checks will be limited"
    }

} catch {
    Register-Check "IIS detection" "WARN" "Unable to detect IIS: $($_.Exception.Message)"
    Print-Summary
    exit 0
}

#==============================================================================
# SECTION 2: APPLICATION POOL CONFIGURATION
#==============================================================================

Write-Section "Application Pool Configuration"

try {
    Import-Module WebAdministration -ErrorAction SilentlyContinue

    $appPools = Get-ChildItem "IIS:\AppPools" -ErrorAction SilentlyContinue

    if ($appPools) {
        Write-Output "Found $($appPools.Count) application pool(s)"

        foreach ($pool in $appPools) {
            $poolName = $pool.Name

            # Check if app pool is running as ApplicationPoolIdentity or custom account
            $identityType = $pool.processModel.identityType

            if ($identityType -eq "ApplicationPoolIdentity") {
                Register-Check "AppPool: $poolName identity" "PASS" "ApplicationPoolIdentity (least privilege)"
            } elseif ($identityType -eq "NetworkService" -or $identityType -eq "LocalService") {
                Register-Check "AppPool: $poolName identity" "WARN" "$identityType (consider ApplicationPoolIdentity)"
            } elseif ($identityType -eq "LocalSystem") {
                Register-Check "AppPool: $poolName identity" "FAIL" "LocalSystem (excessive privileges)"
            } else {
                Register-Check "AppPool: $poolName identity" "PASS" "$identityType (custom account)"
            }

            # Check .NET CLR version
            $managedRuntimeVersion = $pool.managedRuntimeVersion

            if ([string]::IsNullOrEmpty($managedRuntimeVersion)) {
                Register-Check "AppPool: $poolName runtime" "PASS" "No Managed Code"
            } elseif ($managedRuntimeVersion -match "v4\.0") {
                Register-Check "AppPool: $poolName runtime" "PASS" ".NET 4.x"
            } else {
                Register-Check "AppPool: $poolName runtime" "WARN" "$managedRuntimeVersion (outdated)"
            }
        }

    } else {
        Register-Check "Application pools" "WARN" "No application pools found"
    }

} catch {
    Register-Check "Application pool check" "WARN" "Unable to check app pools: $($_.Exception.Message)"
}

#==============================================================================
# SECTION 3: SSL/TLS CONFIGURATION
#==============================================================================

Write-Section "SSL/TLS Configuration"

try {
    # Check for HTTPS bindings
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites) {
            $siteName = $site.Name
            $bindings = $site.bindings.Collection

            $httpsBindings = $bindings | Where-Object { $_.protocol -eq 'https' }
            $httpBindings = $bindings | Where-Object { $_.protocol -eq 'http' }

            if ($httpsBindings) {
                Register-Check "Site: $siteName HTTPS" "PASS" "$($httpsBindings.Count) HTTPS binding(s)"

                # Check certificate binding
                foreach ($binding in $httpsBindings) {
                    $certHash = $binding.certificateHash

                    if ($certHash) {
                        # Find certificate in store
                        $cert = Get-ChildItem -Path "Cert:\LocalMachine\My" | Where-Object { $_.Thumbprint -eq $certHash }

                        if ($cert) {
                            $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days

                            if ($daysUntilExpiry -lt 0) {
                                Register-Check "Site: $siteName certificate" "FAIL" "Certificate expired"
                            } elseif ($daysUntilExpiry -lt 30) {
                                Register-Check "Site: $siteName certificate" "WARN" "Expires in $daysUntilExpiry days"
                            } else {
                                Register-Check "Site: $siteName certificate" "PASS" "Valid for $daysUntilExpiry days"
                            }
                        }
                    } else {
                        Register-Check "Site: $siteName certificate" "WARN" "No certificate bound"
                    }
                }

            } else {
                Register-Check "Site: $siteName HTTPS" "WARN" "No HTTPS bindings configured"
            }

            if ($httpBindings -and -not $httpsBindings) {
                Register-Check "Site: $siteName HTTP-only" "FAIL" "Site uses HTTP without HTTPS"
            }
        }
    }

    # Check SSL/TLS protocols (registry-based)
    $tlsProtocols = @(
        @{ Name = "TLS 1.2"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server"; Expected = $true },
        @{ Name = "TLS 1.3"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.3\Server"; Expected = $true },
        @{ Name = "TLS 1.1"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server"; Expected = $false },
        @{ Name = "TLS 1.0"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server"; Expected = $false },
        @{ Name = "SSL 3.0"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server"; Expected = $false },
        @{ Name = "SSL 2.0"; Path = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server"; Expected = $false }
    )

    foreach ($protocol in $tlsProtocols) {
        $regPath = $protocol.Path
        $enabled = $null

        if (Test-Path $regPath) {
            $enabledValue = (Get-ItemProperty -Path $regPath -Name "Enabled" -ErrorAction SilentlyContinue).Enabled
            $enabled = $enabledValue -eq 1
        }

        if ($protocol.Expected) {
            # Should be enabled
            if ($enabled -eq $true) {
                Register-Check "$($protocol.Name) protocol" "PASS" "Enabled"
            } elseif ($enabled -eq $false) {
                Register-Check "$($protocol.Name) protocol" "WARN" "Disabled (should be enabled)"
            } else {
                Register-Check "$($protocol.Name) protocol" "PASS" "Default (enabled)"
            }
        } else {
            # Should be disabled
            if ($enabled -eq $false) {
                Register-Check "$($protocol.Name) protocol" "PASS" "Disabled"
            } elseif ($enabled -eq $true) {
                Register-Check "$($protocol.Name) protocol" "FAIL" "Enabled (should be disabled)"
            } else {
                Register-Check "$($protocol.Name) protocol" "WARN" "Not explicitly disabled"
            }
        }
    }

} catch {
    Register-Check "SSL/TLS check" "WARN" "Unable to check SSL/TLS configuration"
}

#==============================================================================
# SECTION 4: AUTHENTICATION CONFIGURATION
#==============================================================================

Write-Section "Authentication Configuration"

try {
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites) {
            $siteName = $site.Name
            $sitePath = "IIS:\Sites\$siteName"

            # Check authentication methods
            $anonymousAuth = (Get-WebConfigurationProperty -Filter "/system.webServer/security/authentication/anonymousAuthentication" -Name "enabled" -PSPath $sitePath -ErrorAction SilentlyContinue).Value
            $basicAuth = (Get-WebConfigurationProperty -Filter "/system.webServer/security/authentication/basicAuthentication" -Name "enabled" -PSPath $sitePath -ErrorAction SilentlyContinue).Value
            $windowsAuth = (Get-WebConfigurationProperty -Filter "/system.webServer/security/authentication/windowsAuthentication" -Name "enabled" -PSPath $sitePath -ErrorAction SilentlyContinue).Value

            if ($anonymousAuth) {
                Register-Check "Site: $siteName anonymous auth" "WARN" "Enabled (ensure this is intentional)"
            } else {
                Register-Check "Site: $siteName anonymous auth" "PASS" "Disabled"
            }

            if ($basicAuth) {
                Register-Check "Site: $siteName basic auth" "FAIL" "Enabled (sends credentials in clear text)"
            } else {
                Register-Check "Site: $siteName basic auth" "PASS" "Disabled"
            }

            if ($windowsAuth) {
                Register-Check "Site: $siteName Windows auth" "PASS" "Enabled (secure)"
            }
        }
    }

} catch {
    Register-Check "Authentication check" "WARN" "Unable to check authentication methods"
}

#==============================================================================
# SECTION 5: HTTP SECURITY HEADERS
#==============================================================================

Write-Section "HTTP Security Headers"

try {
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites | Select-Object -First 3) {
            $siteName = $site.Name
            $sitePath = "IIS:\Sites\$siteName"

            # Check X-Frame-Options
            $xFrameOptions = Get-WebConfigurationProperty -Filter "/system.webServer/httpProtocol/customHeaders/add[@name='X-Frame-Options']" -Name "value" -PSPath $sitePath -ErrorAction SilentlyContinue

            if ($xFrameOptions) {
                Register-Check "Site: $siteName X-Frame-Options" "PASS" "Configured ($($xFrameOptions.Value))"
            } else {
                Register-Check "Site: $siteName X-Frame-Options" "WARN" "Not configured (clickjacking risk)"
            }

            # Check X-Content-Type-Options
            $xContentType = Get-WebConfigurationProperty -Filter "/system.webServer/httpProtocol/customHeaders/add[@name='X-Content-Type-Options']" -Name "value" -PSPath $sitePath -ErrorAction SilentlyContinue

            if ($xContentType) {
                Register-Check "Site: $siteName X-Content-Type-Options" "PASS" "Configured"
            } else {
                Register-Check "Site: $siteName X-Content-Type-Options" "WARN" "Not configured (MIME sniffing risk)"
            }

            # Check HTTP Strict Transport Security (HSTS)
            $hsts = Get-WebConfigurationProperty -Filter "/system.webServer/httpProtocol/customHeaders/add[@name='Strict-Transport-Security']" -Name "value" -PSPath $sitePath -ErrorAction SilentlyContinue

            if ($hsts) {
                Register-Check "Site: $siteName HSTS" "PASS" "Configured"
            } else {
                Register-Check "Site: $siteName HSTS" "WARN" "Not configured (HTTPS downgrade risk)"
            }
        }
    }

} catch {
    Register-Check "Security headers check" "WARN" "Unable to check HTTP security headers"
}

#==============================================================================
# SECTION 6: REQUEST FILTERING
#==============================================================================

Write-Section "Request Filtering"

try {
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites | Select-Object -First 3) {
            $siteName = $site.Name
            $sitePath = "IIS:\Sites\$siteName"

            # Check request filtering settings
            $maxAllowedContentLength = (Get-WebConfigurationProperty -Filter "/system.webServer/security/requestFiltering/requestLimits" -Name "maxAllowedContentLength" -PSPath $sitePath -ErrorAction SilentlyContinue).Value
            $maxUrl = (Get-WebConfigurationProperty -Filter "/system.webServer/security/requestFiltering/requestLimits" -Name "maxUrl" -PSPath $sitePath -ErrorAction SilentlyContinue).Value

            if ($maxAllowedContentLength) {
                $maxMB = [math]::Round($maxAllowedContentLength / 1MB, 2)

                if ($maxMB -le 100) {
                    Register-Check "Site: $siteName max request size" "PASS" "$maxMB MB"
                } else {
                    Register-Check "Site: $siteName max request size" "WARN" "$maxMB MB (large uploads allowed)"
                }
            }

            if ($maxUrl) {
                if ($maxUrl -le 4096) {
                    Register-Check "Site: $siteName max URL length" "PASS" "$maxUrl bytes"
                } else {
                    Register-Check "Site: $siteName max URL length" "WARN" "$maxUrl bytes (excessively long URLs allowed)"
                }
            }

            # Check for dangerous file extensions filtering
            $denyStrings = Get-WebConfigurationProperty -Filter "/system.webServer/security/requestFiltering/denyUrlSequences" -Name "Collection" -PSPath $sitePath -ErrorAction SilentlyContinue

            if ($denyStrings) {
                Register-Check "Site: $siteName URL filtering" "PASS" "Configured"
            } else {
                Register-Check "Site: $siteName URL filtering" "WARN" "No URL sequence filtering"
            }
        }
    }

} catch {
    Register-Check "Request filtering check" "WARN" "Unable to check request filtering"
}

#==============================================================================
# SECTION 7: DIRECTORY BROWSING AND DEFAULT DOCUMENTS
#==============================================================================

Write-Section "Directory Browsing and Default Documents"

try {
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites) {
            $siteName = $site.Name
            $sitePath = "IIS:\Sites\$siteName"

            # Check directory browsing
            $dirBrowsing = (Get-WebConfigurationProperty -Filter "/system.webServer/directoryBrowse" -Name "enabled" -PSPath $sitePath -ErrorAction SilentlyContinue).Value

            if ($dirBrowsing) {
                Register-Check "Site: $siteName directory browsing" "FAIL" "Enabled (information disclosure)"
            } else {
                Register-Check "Site: $siteName directory browsing" "PASS" "Disabled"
            }

            # Check default documents
            $defaultDocs = Get-WebConfigurationProperty -Filter "/system.webServer/defaultDocument/files" -Name "Collection" -PSPath $sitePath -ErrorAction SilentlyContinue

            if ($defaultDocs) {
                $docCount = $defaultDocs.Count
                Register-Check "Site: $siteName default documents" "PASS" "$docCount configured"
            }
        }
    }

} catch {
    Register-Check "Directory browsing check" "WARN" "Unable to check directory browsing"
}

#==============================================================================
# SECTION 8: IIS LOGGING CONFIGURATION
#==============================================================================

Write-Section "IIS Logging Configuration"

try {
    $sites = Get-ChildItem "IIS:\Sites" -ErrorAction SilentlyContinue

    if ($sites) {
        foreach ($site in $sites) {
            $siteName = $site.Name
            $logEnabled = $site.logFile.enabled
            $logFormat = $site.logFile.logFormat
            $logDirectory = $site.logFile.directory

            if ($logEnabled) {
                Register-Check "Site: $siteName logging" "PASS" "Enabled (Format: $logFormat)"
            } else {
                Register-Check "Site: $siteName logging" "FAIL" "Disabled (required for audit trail)"
            }

            # Check log directory exists
            if ($logDirectory) {
                # Expand environment variables
                $expandedPath = [Environment]::ExpandEnvironmentVariables($logDirectory)

                if (Test-Path $expandedPath) {
                    Register-Check "Site: $siteName log directory" "PASS" "Exists"
                } else {
                    Register-Check "Site: $siteName log directory" "WARN" "Directory not found"
                }
            }
        }
    }

    # Check global IIS logging options
    $globalLogging = Get-WebConfigurationProperty -Filter "/system.applicationHost/sites/siteDefaults/logFile" -Name "enabled" -ErrorAction SilentlyContinue

    if ($globalLogging.Value) {
        Register-Check "Global IIS logging" "PASS" "Enabled by default"
    } else {
        Register-Check "Global IIS logging" "WARN" "Not enabled by default"
    }

} catch {
    Register-Check "Logging check" "WARN" "Unable to check IIS logging configuration"
}

#==============================================================================
# SECTION 9: ISAPI FILTERS AND EXTENSIONS
#==============================================================================

Write-Section "ISAPI Filters and Extensions"

try {
    # Check ISAPI filters
    $isapiFilters = Get-WebConfiguration -Filter "/system.webServer/isapiFilters" -ErrorAction SilentlyContinue

    if ($isapiFilters -and $isapiFilters.Collection) {
        $filterCount = $isapiFilters.Collection.Count

        if ($filterCount -gt 0) {
            Register-Check "ISAPI filters" "WARN" "$filterCount filter(s) installed (review for necessity)"

            foreach ($filter in $isapiFilters.Collection | Select-Object -First 3) {
                Write-Output "  Filter: $($filter.name) - $($filter.path)"
            }
        } else {
            Register-Check "ISAPI filters" "PASS" "None installed"
        }
    }

    # Check ISAPI/CGI restrictions
    $isapiRestrictions = Get-WebConfiguration -Filter "/system.webServer/security/isapiCgiRestriction" -ErrorAction SilentlyContinue

    if ($isapiRestrictions) {
        $notAllowed = $isapiRestrictions.Collection | Where-Object { $_.allowed -eq $false }

        if ($notAllowed) {
            Register-Check "ISAPI/CGI restrictions" "PASS" "Restrictions configured"
        } else {
            Register-Check "ISAPI/CGI restrictions" "WARN" "No restrictions (review security)"
        }
    }

} catch {
    Register-Check "ISAPI check" "WARN" "Unable to check ISAPI configuration"
}

#==============================================================================
# SECTION 10: FTP SERVICE (IF INSTALLED)
#==============================================================================

Write-Section "FTP Service (If Installed)"

try {
    # Check if FTP service is installed
    $ftpService = Get-Service -Name "FTPSVC" -ErrorAction SilentlyContinue

    if ($ftpService) {
        if ($ftpService.Status -eq 'Running') {
            Register-Check "FTP service" "WARN" "Running (FTP is insecure, use FTPS/SFTP)"
        } else {
            Register-Check "FTP service" "PASS" "Installed but not running"
        }

        # Check FTP SSL settings
        $ftpSites = Get-ChildItem "IIS:\Sites" | Where-Object { $_.ftpServer -ne $null }

        if ($ftpSites) {
            foreach ($ftpSite in $ftpSites) {
                $siteName = $ftpSite.Name
                $sslPolicy = $ftpSite.ftpServer.security.ssl.controlChannelPolicy

                if ($sslPolicy -eq "SslRequire") {
                    Register-Check "FTP: $siteName SSL" "PASS" "SSL required"
                } else {
                    Register-Check "FTP: $siteName SSL" "FAIL" "SSL not required (unencrypted connections allowed)"
                }
            }
        }

    } else {
        Register-Check "FTP service" "PASS" "Not installed"
    }

} catch {
    Register-Check "FTP check" "WARN" "Unable to check FTP configuration"
}

#==============================================================================
# SECTION 11: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
