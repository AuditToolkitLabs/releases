#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Performance and Resource Monitoring Audit

.DESCRIPTION
    Comprehensive performance audit including:
    - CPU utilization and performance
    - Memory usage and available capacity
    - Disk I/O performance and latency
    - Network bandwidth utilization
    - Process resource consumption
    - System uptime and reliability
    - Performance counters configuration
    - Resource exhaustion detection
    - Bottleneck identification
    - Performance baselines validation

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Performance and Resource Monitoring Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: CPU UTILIZATION
#==============================================================================

Write-Section "CPU Utilization"

try {
    # Get processor information
    $processors = Get-CimInstance -ClassName Win32_Processor
    $processorCount = ($processors | Measure-Object).Count
    $totalCores = ($processors | Measure-Object -Property NumberOfCores -Sum).Sum
    $totalLogicalProcessors = ($processors | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum

    Write-Output "Processors: $processorCount"
    Write-Output "Total Cores: $totalCores"
    Write-Output "Logical Processors: $totalLogicalProcessors"

    # Get current CPU usage
    $cpuLoad = (Get-CimInstance -ClassName Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average

    if ($cpuLoad -ge 90) {
        Register-Check "CPU utilization" "FAIL" "$cpuLoad% (critical - system overloaded)"
    } elseif ($cpuLoad -ge 75) {
        Register-Check "CPU utilization" "WARN" "$cpuLoad% (high - investigate workload)"
    } elseif ($cpuLoad -ge 50) {
        Register-Check "CPU utilization" "WARN" "$cpuLoad% (moderate)"
    } else {
        Register-Check "CPU utilization" "PASS" "$cpuLoad% (normal)"
    }

    # Check processor queue length
    $queueLength = (Get-Counter -Counter "\System\Processor Queue Length" -ErrorAction SilentlyContinue).CounterSamples.CookedValue

    if ($queueLength -gt $totalLogicalProcessors * 2) {
        Register-Check "Processor queue length" "WARN" "$queueLength (CPU bottleneck detected)"
    } else {
        Register-Check "Processor queue length" "PASS" "$queueLength (normal)"
    }

} catch {
    Register-Check "CPU utilization check" "WARN" "Unable to check CPU utilization"
}

#==============================================================================
# SECTION 2: MEMORY USAGE
#==============================================================================

Write-Section "Memory Usage"

try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $totalMemoryGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
    $freeMemoryGB = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
    $usedMemoryGB = $totalMemoryGB - $freeMemoryGB
    $memoryUsedPercent = [math]::Round(($usedMemoryGB / $totalMemoryGB) * 100, 1)

    Write-Output "Total Memory: $totalMemoryGB GB"
    Write-Output "Used Memory: $usedMemoryGB GB ($memoryUsedPercent%)"
    Write-Output "Free Memory: $freeMemoryGB GB"

    if ($memoryUsedPercent -ge 95) {
        Register-Check "Memory usage" "FAIL" "$memoryUsedPercent% used (critical - add more RAM)"
    } elseif ($memoryUsedPercent -ge 85) {
        Register-Check "Memory usage" "WARN" "$memoryUsedPercent% used (high - consider upgrade)"
    } elseif ($memoryUsedPercent -ge 70) {
        Register-Check "Memory usage" "WARN" "$memoryUsedPercent% used (moderate)"
    } else {
        Register-Check "Memory usage" "PASS" "$memoryUsedPercent% used (normal)"
    }

    # Check available memory
    if ($freeMemoryGB -lt 0.5) {
        Register-Check "Available memory" "FAIL" "$freeMemoryGB GB (critically low)"
    } elseif ($freeMemoryGB -lt 2) {
        Register-Check "Available memory" "WARN" "$freeMemoryGB GB (low)"
    } else {
        Register-Check "Available memory" "PASS" "$freeMemoryGB GB"
    }

    # Check page faults
    $pageFaults = (Get-Counter -Counter "\Memory\Page Faults/sec" -ErrorAction SilentlyContinue).CounterSamples.CookedValue

    if ($pageFaults -gt 1000) {
        Register-Check "Page faults" "WARN" "$([math]::Round($pageFaults, 0))/sec (high - memory pressure)"
    } else {
        Register-Check "Page faults" "PASS" "$([math]::Round($pageFaults, 0))/sec"
    }

} catch {
    Register-Check "Memory usage check" "WARN" "Unable to check memory usage"
}

#==============================================================================
# SECTION 3: DISK I/O PERFORMANCE
#==============================================================================

Write-Section "Disk I/O Performance"

try {
    $volumes = Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter }

    foreach ($volume in $volumes) {
        $driveLetter = $volume.DriveLetter

        # Get disk I/O metrics
        $diskReadBytes = Get-Counter -Counter "\LogicalDisk($driveLetter`:)\Disk Read Bytes/sec" -ErrorAction SilentlyContinue
        $diskWriteBytes = Get-Counter -Counter "\LogicalDisk($driveLetter`:)\Disk Write Bytes/sec" -ErrorAction SilentlyContinue
        $diskQueue = Get-Counter -Counter "\LogicalDisk($driveLetter`:)\Current Disk Queue Length" -ErrorAction SilentlyContinue

        if ($diskReadBytes -and $diskWriteBytes) {
            $readMBps = [math]::Round($diskReadBytes.CounterSamples.CookedValue / 1MB, 2)
            $writeMBps = [math]::Round($diskWriteBytes.CounterSamples.CookedValue / 1MB, 2)
            $totalMBps = $readMBps + $writeMBps

            Write-Output "Drive $driveLetter`: Read $readMBps MB/s, Write $writeMBps MB/s"

            if ($diskQueue) {
                $queueLength = [math]::Round($diskQueue.CounterSamples.CookedValue, 1)

                if ($queueLength -gt 10) {
                    Register-Check "Disk $driveLetter`: I/O queue" "WARN" "$queueLength (high - disk bottleneck)"
                } else {
                    Register-Check "Disk $driveLetter`: I/O queue" "PASS" "$queueLength"
                }
            }
        }
    }

    # Check disk time percentage
    $disks = Get-PhysicalDisk | Where-Object { $_.BusType -ne 'Unknown' }

    foreach ($disk in $disks | Select-Object -First 3) {
        $diskNumber = $disk.DeviceId
        $diskTimeCounter = "\PhysicalDisk($diskNumber)\% Disk Time"

        $diskTime = Get-Counter -Counter $diskTimeCounter -ErrorAction SilentlyContinue

        if ($diskTime) {
            $diskTimePercent = [math]::Round($diskTime.CounterSamples.CookedValue, 1)

            if ($diskTimePercent -ge 90) {
                Register-Check "Physical disk $diskNumber activity" "WARN" "$diskTimePercent% (very busy)"
            } elseif ($diskTimePercent -ge 70) {
                Register-Check "Physical disk $diskNumber activity" "PASS" "$diskTimePercent% (moderate)"
            } else {
                Register-Check "Physical disk $diskNumber activity" "PASS" "$diskTimePercent%"
            }
        }
    }

} catch {
    Register-Check "Disk I/O check" "WARN" "Unable to check disk I/O performance"
}

#==============================================================================
# SECTION 4: NETWORK BANDWIDTH UTILIZATION
#==============================================================================

Write-Section "Network Bandwidth Utilization"

try {
    $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.Virtual -eq $false }

    foreach ($adapter in $adapters) {
        $adapterName = $adapter.Name
        $linkSpeed = $adapter.LinkSpeed

        # Get network throughput
        $bytesReceivedCounter = "\Network Interface($adapterName)\Bytes Received/sec"
        $bytesSentCounter = "\Network Interface($adapterName)\Bytes Sent/sec"

        $bytesReceived = Get-Counter -Counter $bytesReceivedCounter -ErrorAction SilentlyContinue
        $bytesSent = Get-Counter -Counter $bytesSentCounter -ErrorAction SilentlyContinue

        if ($bytesReceived -and $bytesSent) {
            $receivedMbps = [math]::Round($bytesReceived.CounterSamples.CookedValue * 8 / 1MB, 2)
            $sentMbps = [math]::Round($bytesSent.CounterSamples.CookedValue * 8 / 1MB, 2)
            $totalMbps = $receivedMbps + $sentMbps

            Write-Output "$adapterName`: $linkSpeed, Rx: $receivedMbps Mbps, Tx: $sentMbps Mbps"

            # Convert link speed to Mbps for comparison
            if ($linkSpeed -match "(\d+)\s*(Gbps|Mbps)") {
                $speedValue = [int]$matches[1]
                $speedUnit = $matches[2]

                if ($speedUnit -eq "Gbps") {
                    $linkSpeedMbps = $speedValue * 1000
                } else {
                    $linkSpeedMbps = $speedValue
                }

                $utilizationPercent = [math]::Round(($totalMbps / $linkSpeedMbps) * 100, 1)

                if ($utilizationPercent -ge 80) {
                    Register-Check "$adapterName utilization" "WARN" "$utilizationPercent% (high - consider upgrade)"
                } elseif ($utilizationPercent -ge 50) {
                    Register-Check "$adapterName utilization" "PASS" "$utilizationPercent% (moderate)"
                } else {
                    Register-Check "$adapterName utilization" "PASS" "$utilizationPercent%"
                }
            }
        }
    }

} catch {
    Register-Check "Network utilization check" "WARN" "Unable to check network utilization"
}

#==============================================================================
# SECTION 5: TOP RESOURCE-CONSUMING PROCESSES
#==============================================================================

Write-Section "Top Resource-Consuming Processes"

try {
    # Get top CPU processes
    $topCPU = Get-Process | Sort-Object -Property CPU -Descending | Select-Object -First 5

    Write-Output "Top CPU-consuming processes:"
    foreach ($proc in $topCPU) {
        $cpuTime = [math]::Round($proc.CPU, 2)
        Write-Output "  $($proc.ProcessName) (PID $($proc.Id)): $cpuTime seconds"
    }

    # Get top memory processes
    $topMemory = Get-Process | Sort-Object -Property WorkingSet -Descending | Select-Object -First 5

    Write-Output "Top memory-consuming processes:"
    foreach ($proc in $topMemory) {
        $memoryMB = [math]::Round($proc.WorkingSet / 1MB, 2)
        Write-Output "  $($proc.ProcessName) (PID $($proc.Id)): $memoryMB MB"
    }

    # Check for processes using excessive resources
    $highCPU = Get-Process | Where-Object { $_.CPU -gt 1000 }

    if ($highCPU) {
        $count = ($highCPU | Measure-Object).Count
        Register-Check "High CPU processes" "WARN" "$count process(es) using >1000 CPU seconds"
    } else {
        Register-Check "High CPU processes" "PASS" "No processes using excessive CPU"
    }

    # Check for high memory processes (>2GB)
    $highMemory = Get-Process | Where-Object { $_.WorkingSet -gt 2GB }

    if ($highMemory) {
        $count = ($highMemory | Measure-Object).Count
        Register-Check "High memory processes" "WARN" "$count process(es) using >2 GB RAM"
    } else {
        Register-Check "High memory processes" "PASS" "No processes using excessive memory"
    }

} catch {
    Register-Check "Process resource check" "WARN" "Unable to check process resources"
}

#==============================================================================
# SECTION 6: SYSTEM UPTIME
#==============================================================================

Write-Section "System Uptime and Reliability"

try {
    $lastBoot = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime
    $uptime = (Get-Date) - $lastBoot

    $days = $uptime.Days
    $hours = $uptime.Hours

    Write-Output "Last boot: $($lastBoot.ToString('yyyy-MM-dd HH:mm:ss'))"
    Write-Output "Uptime: $days days, $hours hours"

    if ($days -gt 90) {
        Register-Check "System uptime" "WARN" "$days days (consider reboot for updates)"
    } elseif ($days -gt 30) {
        Register-Check "System uptime" "PASS" "$days days (check for pending updates)"
    } else {
        Register-Check "System uptime" "PASS" "$days days"
    }

    # Check for unexpected reboots in last 7 days
    $rebootEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'System'
        ID = 1074, 6008  # System shutdown, unexpected shutdown
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 10 -ErrorAction SilentlyContinue

    if ($rebootEvents) {
        $count = ($rebootEvents | Measure-Object).Count

        $unexpectedReboots = $rebootEvents | Where-Object { $_.Id -eq 6008 }

        if ($unexpectedReboots) {
            $unexpectedCount = ($unexpectedReboots | Measure-Object).Count
            Register-Check "Unexpected reboots" "WARN" "$unexpectedCount unexpected reboot(s) in last 7 days"
        } else {
            Register-Check "Unexpected reboots" "PASS" "No unexpected reboots"
        }
    } else {
        Register-Check "System reboots" "PASS" "No reboots in last 7 days"
    }

} catch {
    Register-Check "Uptime check" "WARN" "Unable to check system uptime"
}

#==============================================================================
# SECTION 7: PERFORMANCE COUNTER CONFIGURATION
#==============================================================================

Write-Section "Performance Counter Configuration"

try {
    # Check if performance counter service is running
    $perfSvc = Get-Service -Name "PerfHost" -ErrorAction SilentlyContinue

    if ($perfSvc) {
        if ($perfSvc.Status -eq 'Running') {
            Register-Check "Performance Counter Host" "PASS" "Running"
        } else {
            Register-Check "Performance Counter Host" "WARN" "Not running (performance monitoring limited)"
        }
    } else {
        Register-Check "Performance Counter Host" "PASS" "Not installed (optional)"
    }

    # Check for Data Collector Sets
    $dcs = Get-CimInstance -Namespace "root\cimv2" -ClassName Win32_PerfRawData_PerfProc_Process -ErrorAction SilentlyContinue

    if ($dcs) {
        Register-Check "Performance data collection" "PASS" "Available"
    } else {
        Register-Check "Performance data collection" "WARN" "Limited or unavailable"
    }

} catch {
    Register-Check "Performance counter check" "WARN" "Unable to check performance counters"
}

#==============================================================================
# SECTION 8: PAGING FILE CONFIGURATION
#==============================================================================

Write-Section "Paging File Configuration"

try {
    $pageFiles = Get-CimInstance -ClassName Win32_PageFileUsage

    if ($pageFiles) {
        foreach ($pageFile in $pageFiles) {
            $name = $pageFile.Name
            $sizeMB = $pageFile.AllocatedBaseSize
            $currentUsageMB = $pageFile.CurrentUsage
            $usagePercent = [math]::Round(($currentUsageMB / $sizeMB) * 100, 1)

            Write-Output "Paging file: $name ($sizeMB MB allocated, $currentUsageMB MB used)"

            if ($usagePercent -ge 80) {
                Register-Check "Paging file usage" "WARN" "$usagePercent% (increase paging file size)"
            } else {
                Register-Check "Paging file usage" "PASS" "$usagePercent%"
            }
        }

        # Check if page file is system-managed
        $pageFileSettings = Get-CimInstance -ClassName Win32_PageFileSetting

        if (-not $pageFileSettings) {
            Register-Check "Paging file configuration" "PASS" "System-managed"
        } else {
            Register-Check "Paging file configuration" "PASS" "Manually configured"
        }

    } else {
        Register-Check "Paging file" "WARN" "No paging file configured"
    }

} catch {
    Register-Check "Paging file check" "WARN" "Unable to check paging file"
}

#==============================================================================
# SECTION 9: HANDLE AND THREAD COUNTS
#==============================================================================

Write-Section "Handle and Thread Counts"

try {
    $processes = Get-Process
    $totalHandles = ($processes | Measure-Object -Property HandleCount -Sum).Sum
    $totalThreads = ($processes | Measure-Object -Property Threads -Sum).Sum

    Write-Output "Total handles: $totalHandles"
    Write-Output "Total threads: $totalThreads"

    # Check for excessive handles (potential leak)
    if ($totalHandles -gt 100000) {
        Register-Check "System handles" "WARN" "$totalHandles handles (possible handle leak)"
    } else {
        Register-Check "System handles" "PASS" "$totalHandles handles"
    }

    # Check for excessive threads
    if ($totalThreads -gt 5000) {
        Register-Check "System threads" "WARN" "$totalThreads threads (high thread count)"
    } else {
        Register-Check "System threads" "PASS" "$totalThreads threads"
    }

    # Find processes with excessive handles
    $highHandles = $processes | Where-Object { $_.HandleCount -gt 10000 }

    if ($highHandles) {
        foreach ($proc in $highHandles | Select-Object -First 3) {
            Write-Output "  High handles: $($proc.ProcessName) (PID $($proc.Id), $($proc.HandleCount) handles)"
        }
        Register-Check "High handle processes" "WARN" "$($highHandles.Count) process(es) with >10k handles"
    }

} catch {
    Register-Check "Handle/thread check" "WARN" "Unable to check handles and threads"
}

#==============================================================================
# SECTION 10: RESOURCE EXHAUSTION DETECTION
#==============================================================================

Write-Section "Resource Exhaustion Detection"

try {
    # Check for low disk space (covered in disk audit, but worth checking here)
    $lowSpaceVolumes = Get-Volume | Where-Object {
        $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.SizeRemaining -gt 0
    } | Where-Object {
        ($_.SizeRemaining / $_.Size) -lt 0.1
    }

    if ($lowSpaceVolumes) {
        $count = ($lowSpaceVolumes | Measure-Object).Count
        Register-Check "Low disk space volumes" "WARN" "$count volume(s) with <10% free space"
    } else {
        Register-Check "Low disk space" "PASS" "All volumes have adequate space"
    }

    # Check for memory pressure (commit charge)
    $commitLimit = (Get-Counter -Counter "\Memory\Commit Limit" -ErrorAction SilentlyContinue).CounterSamples.CookedValue
    $commitCurrent = (Get-Counter -Counter "\Memory\Committed Bytes" -ErrorAction SilentlyContinue).CounterSamples.CookedValue

    if ($commitLimit -and $commitCurrent) {
        $commitPercent = [math]::Round(($commitCurrent / $commitLimit) * 100, 1)

        if ($commitPercent -ge 90) {
            Register-Check "Memory commit charge" "WARN" "$commitPercent% (approaching limit)"
        } else {
            Register-Check "Memory commit charge" "PASS" "$commitPercent%"
        }
    }

    # Check for CPU context switching rate
    $contextSwitches = (Get-Counter -Counter "\System\Context Switches/sec" -ErrorAction SilentlyContinue).CounterSamples.CookedValue

    if ($contextSwitches -gt 50000) {
        Register-Check "Context switches" "WARN" "$([math]::Round($contextSwitches, 0))/sec (high - CPU contention)"
    } else {
        Register-Check "Context switches" "PASS" "$([math]::Round($contextSwitches, 0))/sec"
    }

} catch {
    Register-Check "Resource exhaustion check" "WARN" "Unable to check for resource exhaustion"
}

#==============================================================================
# SECTION 11: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
