#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Remote Desktop Protocol (RDP) Security Audit

.DESCRIPTION
    Comprehensive security audit of Remote Desktop configuration including:
    - RDP service status
    - Network Level Authentication (NLA)
    - Encryption level
    - Port configuration
    - Certificate validation
    - Session timeouts
    - Access control lists
    - RDP firewall rules
    - Connection history
    - Deprecated protocol versions

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Remote Desktop Protocol (RDP) Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"

$domainInfo = Get-DomainInfo
if ($domainInfo.IsDomainJoined) {
    Write-Output "Domain: $($domainInfo.DomainName)"
}
Write-Output ""

#==============================================================================
# SECTION 1: RDP SERVICE STATUS
#==============================================================================

Write-Section "RDP Service Status"

# Check TermService (Remote Desktop Services)
$termService = Get-Service -Name TermService -ErrorAction SilentlyContinue

if ($termService) {
    if ($termService.Status -eq 'Running') {
        Register-Check "TermService (RDP)" "PASS" "Running"
    } else {
        Register-Check "TermService (RDP)" "WARN" "$($termService.Status) (RDP not available)"
    }

    if ($termService.StartType -eq 'Automatic') {
        Register-Check "TermService startup" "PASS" "Automatic"
    } else {
        Register-Check "TermService startup" "WARN" "$($termService.StartType)"
    }

} else {
    Register-Check "TermService" "WARN" "Not found (RDP may not be installed)"
}

# Check if RDP is enabled via registry
$rdpEnabled = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -ErrorAction SilentlyContinue

if ($rdpEnabled) {
    if ($rdpEnabled.fDenyTSConnections -eq 0) {
        Register-Check "RDP enabled" "PASS" "Remote Desktop is enabled"
    } else {
        Register-Check "RDP enabled" "PASS" "Remote Desktop is disabled (secure if not needed)"
    }
}

#==============================================================================
# SECTION 2: NETWORK LEVEL AUTHENTICATION (NLA)
#==============================================================================

Write-Section "Network Level Authentication (NLA)"

try {
    $nlaEnabled = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "UserAuthentication" -ErrorAction Stop

    if ($nlaEnabled.UserAuthentication -eq 1) {
        Register-Check "NLA requirement" "PASS" "Enabled (authentication before session)"
    } else {
        Register-Check "NLA requirement" "FAIL" "Disabled (allows unauthenticated connections)"
    }

    # Check if NLA allows only TLS 1.2+
    $securityLayer = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "SecurityLayer" -ErrorAction SilentlyContinue

    if ($securityLayer) {
        switch ($securityLayer.SecurityLayer) {
            0 { Register-Check "RDP security layer" "FAIL" "RDP (legacy, no encryption)" }
            1 { Register-Check "RDP security layer" "WARN" "Negotiate (may fall back to weak)" }
            2 { Register-Check "RDP security layer" "PASS" "SSL/TLS required" }
            default { Register-Check "RDP security layer" "WARN" "Unknown value: $($securityLayer.SecurityLayer)" }
        }
    }

} catch {
    Register-Check "NLA configuration" "WARN" "Unable to check NLA settings"
}

#==============================================================================
# SECTION 3: ENCRYPTION LEVEL
#==============================================================================

Write-Section "RDP Encryption Level"

try {
    $encryptionLevel = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "MinEncryptionLevel" -ErrorAction Stop

    switch ($encryptionLevel.MinEncryptionLevel) {
        1 { Register-Check "RDP encryption level" "FAIL" "Low (40-bit)" }
        2 { Register-Check "RDP encryption level" "WARN" "Client Compatible (varies)" }
        3 { Register-Check "RDP encryption level" "PASS" "High (128-bit)" }
        4 { Register-Check "RDP encryption level" "PASS" "FIPS 140-1 Compliant" }
        default { Register-Check "RDP encryption level" "WARN" "Unknown: $($encryptionLevel.MinEncryptionLevel)" }
    }

} catch {
    Register-Check "RDP encryption level" "WARN" "Unable to check encryption level"
}

#==============================================================================
# SECTION 4: RDP PORT CONFIGURATION
#==============================================================================

Write-Section "RDP Port Configuration"

try {
    $rdpPort = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "PortNumber" -ErrorAction Stop

    if ($rdpPort.PortNumber -eq 3389) {
        Register-Check "RDP port" "WARN" "3389 (default, commonly scanned - consider changing)"
    } else {
        Register-Check "RDP port" "PASS" "Custom port $($rdpPort.PortNumber) (security through obscurity)"
    }

    # Check if firewall allows the RDP port
    $firewallRules = Get-NetFirewallRule -DisplayName "*Remote Desktop*" -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -eq $true }

    if ($firewallRules) {
        $allowRules = $firewallRules | Where-Object { $_.Action -eq 'Allow' }
        if ($allowRules.Count -gt 0) {
            Register-Check "RDP firewall rules" "PASS" "$($allowRules.Count) allow rules enabled"
        } else {
            Register-Check "RDP firewall rules" "WARN" "No allow rules found (RDP may be blocked)"
        }
    } else {
        Register-Check "RDP firewall rules" "WARN" "No RDP firewall rules found"
    }

} catch {
    Register-Check "RDP port configuration" "WARN" "Unable to check port settings"
}

#==============================================================================
# SECTION 5: RDP CERTIFICATE CONFIGURATION
#==============================================================================

Write-Section "RDP Certificate"

try {
    # Get the certificate thumbprint used by RDP
    $certThumbprint = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "SSLCertificateSHA1Hash" -ErrorAction SilentlyContinue

    if ($certThumbprint -and $certThumbprint.SSLCertificateSHA1Hash) {
        # Convert byte array to hex string
        $thumbprintHex = ($certThumbprint.SSLCertificateSHA1Hash | ForEach-Object { $_.ToString("X2") }) -join ''

        # Try to find the certificate
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $thumbprintHex }

        if ($cert) {
            Register-Check "RDP certificate" "PASS" "Configured"

            # Check certificate expiration
            $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days

            if ($daysUntilExpiry -lt 0) {
                Register-Check "RDP certificate validity" "FAIL" "Expired $(-$daysUntilExpiry) days ago"
            } elseif ($daysUntilExpiry -lt 30) {
                Register-Check "RDP certificate validity" "WARN" "Expires in $daysUntilExpiry days"
            } elseif ($daysUntilExpiry -lt 90) {
                Register-Check "RDP certificate validity" "WARN" "Expires in $daysUntilExpiry days (renew soon)"
            } else {
                Register-Check "RDP certificate validity" "PASS" "Valid for $daysUntilExpiry days"
            }

            # Check if certificate is self-signed
            if ($cert.Subject -eq $cert.Issuer) {
                Register-Check "RDP certificate type" "WARN" "Self-signed (consider CA-issued cert)"
            } else {
                Register-Check "RDP certificate type" "PASS" "CA-issued certificate"
            }

        } else {
            Register-Check "RDP certificate" "WARN" "Certificate not found in store"
        }
    } else {
        Register-Check "RDP certificate" "WARN" "No certificate configured (using default/auto-generated)"
    }

} catch {
    Register-Check "RDP certificate" "WARN" "Unable to check certificate"
}

#==============================================================================
# SECTION 6: SESSION TIMEOUT CONFIGURATION
#==============================================================================

Write-Section "RDP Session Timeouts"

try {
    # Check idle session timeout
    $maxIdleTime = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "MaxIdleTime" -ErrorAction SilentlyContinue

    if ($maxIdleTime) {
        $minutes = $maxIdleTime.MaxIdleTime / 60000
        if ($minutes -le 15) {
            Register-Check "Idle session timeout" "PASS" "$minutes minutes"
        } elseif ($minutes -le 30) {
            Register-Check "Idle session timeout" "WARN" "$minutes minutes (15 recommended)"
        } else {
            Register-Check "Idle session timeout" "FAIL" "$minutes minutes (too long, use 15)"
        }
    } else {
        Register-Check "Idle session timeout" "WARN" "Not configured (no automatic disconnect)"
    }

    # Check disconnected session timeout
    $maxDisconnectionTime = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "MaxDisconnectionTime" -ErrorAction SilentlyContinue

    if ($maxDisconnectionTime) {
        $minutes = $maxDisconnectionTime.MaxDisconnectionTime / 60000
        Register-Check "Disconnected session timeout" "PASS" "$minutes minutes configured"
    } else {
        Register-Check "Disconnected session timeout" "WARN" "Not configured (sessions persist indefinitely)"
    }

    # Check session time limit
    $maxConnectionTime = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "MaxConnectionTime" -ErrorAction SilentlyContinue

    if ($maxConnectionTime -and $maxConnectionTime.MaxConnectionTime -ne 0) {
        $minutes = $maxConnectionTime.MaxConnectionTime / 60000
        Register-Check "Max session duration" "PASS" "$minutes minutes configured"
    } else {
        Register-Check "Max session duration" "WARN" "Not configured (unlimited session duration)"
    }

} catch {
    Register-Check "Session timeouts" "WARN" "Unable to check timeout settings"
}

#==============================================================================
# SECTION 7: RDP ACCESS CONTROL
#==============================================================================

Write-Section "RDP Access Control"

# Check who can connect via RDP
try {
    $rdpUsers = Get-LocalGroupMember -Group "Remote Desktop Users" -ErrorAction SilentlyContinue

    if ($rdpUsers) {
        if ($rdpUsers.Count -le 5) {
            $userList = ($rdpUsers | Select-Object -ExpandProperty Name) -join ', '
            Register-Check "Remote Desktop Users" "PASS" "$($rdpUsers.Count) users/groups: $userList"
        } else {
            $userList = ($rdpUsers | Select-Object -First 5 -ExpandProperty Name) -join ', '
            Register-Check "Remote Desktop Users" "WARN" "$($rdpUsers.Count) users/groups (review): $userList..."
        }
    } else {
        Register-Check "Remote Desktop Users" "PASS" "No explicit RDP users (Administrators only)"
    }

    # Check if "Everyone" or "Authenticated Users" can RDP (major risk)
    $riskyGroups = $rdpUsers | Where-Object { $_.Name -match "Everyone|Authenticated Users" }

    if ($riskyGroups) {
        Register-Check "Overly permissive RDP access" "FAIL" "Everyone or Authenticated Users can RDP (major risk)"
    } else {
        Register-Check "Overly permissive RDP access" "PASS" "No overly permissive groups detected"
    }

} catch {
    Register-Check "RDP access control" "WARN" "Unable to check RDP access"
}

#==============================================================================
# SECTION 8: ACCOUNT LOCKOUT FOR RDP
#==============================================================================

Write-Section "RDP Brute Force Protection"

try {
    # Check account lockout policy (applies to RDP)
    $netAccounts = net accounts
    $lockoutLine = ($netAccounts | Select-String "Lockout threshold").ToString()

    if ($lockoutLine -match "Never") {
        Register-Check "Account lockout (RDP protection)" "FAIL" "No lockout policy (vulnerable to brute force)"
    } elseif ($lockoutLine -match "(\d+)") {
        $threshold = [int]$matches[1]
        if ($threshold -le 5) {
            Register-Check "Account lockout (RDP protection)" "PASS" "$threshold failed attempts"
        } elseif ($threshold -le 10) {
            Register-Check "Account lockout (RDP protection)" "WARN" "$threshold attempts (5 or less recommended)"
        } else {
            Register-Check "Account lockout (RDP protection)" "FAIL" "$threshold attempts (too high)"
        }
    }

} catch {
    Register-Check "Account lockout policy" "WARN" "Unable to check lockout policy"
}

# Check for RDP Guardian or similar brute-force protection tools
$rdpGuardService = Get-Service -Name "RDPGuard" -ErrorAction SilentlyContinue

if ($rdpGuardService) {
    if ($rdpGuardService.Status -eq 'Running') {
        Register-Check "RDP brute-force protection tool" "PASS" "RDPGuard running"
    } else {
        Register-Check "RDP brute-force protection tool" "WARN" "RDPGuard installed but not running"
    }
} else {
    Register-Check "RDP brute-force protection tool" "WARN" "No third-party RDP protection detected (consider RDPGuard/Fail2ban)"
}

#==============================================================================
# SECTION 9: RESTRICTED ADMIN MODE
#==============================================================================

Write-Section "Restricted Admin Mode"

try {
    # Restricted Admin mode prevents credential exposure
    $restrictedAdmin = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa" -Name "DisableRestrictedAdmin" -ErrorAction SilentlyContinue

    if ($restrictedAdmin) {
        if ($restrictedAdmin.DisableRestrictedAdmin -eq 0) {
            Register-Check "Restricted Admin mode" "PASS" "Enabled (credentials not cached)"
        } else {
            Register-Check "Restricted Admin mode" "WARN" "Disabled (credentials may be exposed)"
        }
    } else {
        # If not set, default is enabled on newer Windows versions
        if ($osInfo.Build -ge 9600) {  # Windows 8.1/Server 2012 R2+
            Register-Check "Restricted Admin mode" "PASS" "Default enabled (Build $($osInfo.Build))"
        } else {
            Register-Check "Restricted Admin mode" "WARN" "Not supported on this OS version"
        }
    }

} catch {
    Register-Check "Restricted Admin mode" "WARN" "Unable to check Restricted Admin setting"
}

#==============================================================================
# SECTION 10: REMOTE CREDENTIAL GUARD
#==============================================================================

Write-Section "Remote Credential Guard"

# Remote Credential Guard available on Windows 10 1607+ / Server 2016+
if ($osInfo.Build -ge 14393) {
    try {
        $credGuard = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa" -Name "DisableRestrictedAdminOutboundCreds" -ErrorAction SilentlyContinue

        if ($credGuard -and $credGuard.DisableRestrictedAdminOutboundCreds -eq 1) {
            Register-Check "Remote Credential Guard" "PASS" "Enabled (maximum credential protection)"
        } else {
            Register-Check "Remote Credential Guard" "WARN" "Not enabled (consider enabling for high-security environments)"
        }

    } catch {
        Register-Check "Remote Credential Guard" "WARN" "Unable to check setting"
    }
} else {
    Register-Check "Remote Credential Guard" "SKIP" "Not supported on this OS version (requires Build 14393+)"
}

#==============================================================================
# SECTION 11: RDP CONNECTION HISTORY
#==============================================================================

Write-Section "Recent RDP Connection Activity"

try {
    # Check Security event log for RDP logons (Event ID 4624 Type 10)
    $rdpLogons = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        ID = 4624
    } -MaxEvents 1000 -ErrorAction SilentlyContinue | Where-Object {
        $_.Message -match "Logon Type:\s+10"  # RDP logon
    }

    if ($rdpLogons) {
        $uniqueUsers = $rdpLogons | ForEach-Object {
            if ($_.Message -match "Account Name:\s+(\S+)") {
                $matches[1]
            }
        } | Select-Object -Unique

        $recentCount = ($rdpLogons | Where-Object { $_.TimeCreated -gt (Get-Date).AddDays(-7) }).Count

        Register-Check "RDP logons (last 7 days)" "PASS" "$recentCount connections from $($uniqueUsers.Count) unique users"

        # Check for failed RDP attempts (Event ID 4625)
        $failedRDP = Get-WinEvent -FilterHashtable @{
            LogName = 'Security'
            ID = 4625
        } -MaxEvents 1000 -ErrorAction SilentlyContinue | Where-Object {
            $_.Message -match "Logon Type:\s+10"
        }

        if ($failedRDP) {
            $failedRecent = ($failedRDP | Where-Object { $_.TimeCreated -gt (Get-Date).AddDays(-7) }).Count

            if ($failedRecent -eq 0) {
                Register-Check "Failed RDP attempts (last 7 days)" "PASS" "No failed attempts"
            } elseif ($failedRecent -le 10) {
                Register-Check "Failed RDP attempts (last 7 days)" "WARN" "$failedRecent failed attempts (monitor)"
            } else {
                Register-Check "Failed RDP attempts (last 7 days)" "FAIL" "$failedRecent failed attempts (possible brute force)"
            }
        }

    } else {
        Register-Check "RDP connection history" "PASS" "No recent RDP connections"
    }

} catch {
    Register-Check "RDP connection history" "WARN" "Unable to check event logs"
}

#==============================================================================
# SECTION 12: DEPRECATED PROTOCOLS
#==============================================================================

Write-Section "Deprecated RDP Features"

# Check if CredSSP is vulnerable (CVE-2018-0886)
try {
    $credssp = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\CredSSP\Parameters" -Name "AllowEncryptionOracle" -ErrorAction SilentlyContinue

    if ($credssp) {
        switch ($credssp.AllowEncryptionOracle) {
            0 { Register-Check "CredSSP encryption oracle" "PASS" "Force Updated Clients (most secure)" }
            1 { Register-Check "CredSSP encryption oracle" "WARN" "Mitigated (allows fallback)" }
            2 { Register-Check "CredSSP encryption oracle" "FAIL" "Vulnerable (allows unpatched clients)" }
            default { Register-Check "CredSSP encryption oracle" "WARN" "Unknown value: $($credssp.AllowEncryptionOracle)" }
        }
    } else {
        # If not set, default is secure on patched systems
        Register-Check "CredSSP encryption oracle" "PASS" "Default (requires patched clients)"
    }

} catch {
    Register-Check "CredSSP configuration" "WARN" "Unable to check CredSSP settings"
}

# Check if legacy RDP client connections are allowed
try {
    $legacyRDP = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "fAllowSecProtocolNegotiation" -ErrorAction SilentlyContinue

    if ($legacyRDP) {
        if ($legacyRDP.fAllowSecProtocolNegotiation -eq 1) {
            Register-Check "Legacy RDP protocol negotiation" "WARN" "Enabled (may allow weak protocols)"
        } else {
            Register-Check "Legacy RDP protocol negotiation" "PASS" "Disabled (TLS only)"
        }
    }

} catch {
    Register-Check "Legacy RDP protocols" "WARN" "Unable to check legacy protocol settings"
}

#==============================================================================
# SECTION 13: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
