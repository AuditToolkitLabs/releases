﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Registry Security Audit

.DESCRIPTION
    Comprehensive security audit of critical registry settings including:
    - LSA protection and credential storage
    - User Account Control (UAC) settings
    - Windows Defender and antivirus policies
    - Remote Desktop and remote access policies
    - Network security settings (SMB, LLMNR, NetBIOS)
    - PowerShell logging and execution policies
    - AutoRun and AutoPlay settings
    - Windows Update configuration
    - Screen saver and lock screen policies
    - Audit policy configuration

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Registry Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# HELPER FUNCTIONS
#==============================================================================

function Get-RegistryValue {
    param(
        [string]$Path,
        [string]$Name,
        [object]$DefaultValue = $null
    )

    try {
        if (Test-Path $Path) {
            $value = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
            if ($null -ne $value) {
                return $value.$Name
            }
        }
        return $DefaultValue
    } catch {
        return $DefaultValue
    }
}

#==============================================================================
# SECTION 1: LSA PROTECTION
#==============================================================================

Write-Section "LSA Protection and Credential Storage"

try {
    # RunAsPPL (LSA Protection)
    $lsaRunAsPPL = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RunAsPPL"

    if ($lsaRunAsPPL -eq 1) {
        Register-Check "LSA Protection (RunAsPPL)" "PASS" "Enabled (protects against credential theft)"
    } else {
        Register-Check "LSA Protection (RunAsPPL)" "WARN" "Not enabled (enable to protect LSASS)"
    }

    # Credential Guard (if supported)
    $credGuard = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -Name "EnableVirtualizationBasedSecurity"
    $credGuardEnabled = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LsaCfgFlags"

    if ($credGuard -eq 1 -and $credGuardEnabled -gt 0) {
        Register-Check "Credential Guard" "PASS" "Enabled (virtualization-based security)"
    } else {
        Register-Check "Credential Guard" "WARN" "Not enabled (requires UEFI and Hyper-V)"
    }

    # WDigest authentication disabled
    $wdigest = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential"

    if ($wdigest -eq 0) {
        Register-Check "WDigest credential caching" "PASS" "Disabled (prevents plaintext password storage)"
    } else {
        Register-Check "WDigest credential caching" "FAIL" "Enabled (plaintext passwords in memory)"
    }

} catch {
    Register-Check "LSA protection check" "WARN" "Unable to check LSA settings"
}

#==============================================================================
# SECTION 2: USER ACCOUNT CONTROL (UAC)
#==============================================================================

Write-Section "User Account Control (UAC)"

try {
    # UAC enabled
    $uacEnabled = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA"

    if ($uacEnabled -eq 1) {
        Register-Check "UAC" "PASS" "Enabled"
    } else {
        Register-Check "UAC" "FAIL" "Disabled (enable to prevent privilege escalation)"
    }

    # Admin approval mode
    $adminApproval = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "FilterAdministratorToken"

    if ($adminApproval -eq 1) {
        Register-Check "Admin Approval Mode" "PASS" "Enabled for built-in admin"
    } else {
        Register-Check "Admin Approval Mode" "WARN" "Not enabled for built-in admin"
    }

    # Consent prompt behavior for admins
    $consentPrompt = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin"

    switch ($consentPrompt) {
        0 { Register-Check "UAC prompt for admins" "FAIL" "No prompt (elevate without consent)" }
        1 { Register-Check "UAC prompt for admins" "WARN" "Prompt on secure desktop (credentials required)" }
        2 { Register-Check "UAC prompt for admins" "PASS" "Prompt on secure desktop (always)" }
        3 { Register-Check "UAC prompt for admins" "WARN" "Prompt for credentials" }
        4 { Register-Check "UAC prompt for admins" "WARN" "Prompt for consent" }
        5 { Register-Check "UAC prompt for admins" "PASS" "Prompt for consent (non-Windows binaries)" }
        default { Register-Check "UAC prompt for admins" "WARN" "Unknown setting: $consentPrompt" }
    }

} catch {
    Register-Check "UAC check" "WARN" "Unable to check UAC settings"
}

#==============================================================================
# SECTION 3: WINDOWS DEFENDER
#==============================================================================

Write-Section "Windows Defender Registry Settings"

try {
    # Real-time protection
    $realtimeProtection = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "DisableRealtimeMonitoring"

    if ($realtimeProtection -eq 0 -or $null -eq $realtimeProtection) {
        Register-Check "Defender Real-time Protection" "PASS" "Not disabled by policy"
    } else {
        Register-Check "Defender Real-time Protection" "FAIL" "Disabled by policy"
    }

    # Behavior monitoring
    $behaviorMonitoring = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" -Name "DisableBehaviorMonitoring"

    if ($behaviorMonitoring -eq 0 -or $null -eq $behaviorMonitoring) {
        Register-Check "Defender Behavior Monitoring" "PASS" "Not disabled"
    } else {
        Register-Check "Defender Behavior Monitoring" "FAIL" "Disabled by policy"
    }

    # Cloud-delivered protection
    $cloudProtection = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" -Name "SpynetReporting"

    if ($cloudProtection -ge 1) {
        Register-Check "Defender Cloud Protection" "PASS" "Enabled (level: $cloudProtection)"
    } else {
        Register-Check "Defender Cloud Protection" "WARN" "Disabled (reduces threat detection)"
    }

} catch {
    Register-Check "Windows Defender check" "WARN" "Unable to check Defender settings"
}

#==============================================================================
# SECTION 4: REMOTE DESKTOP SETTINGS
#==============================================================================

Write-Section "Remote Desktop Registry Settings"

try {
    # RDP enabled/disabled
    $rdpEnabled = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections"

    if ($rdpEnabled -eq 0) {
        Register-Check "RDP" "PASS" "Enabled"

        # Check NLA requirement
        $nlaRequired = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "UserAuthentication"

        if ($nlaRequired -eq 1) {
            Register-Check "RDP NLA requirement" "PASS" "Required (secure)"
        } else {
            Register-Check "RDP NLA requirement" "FAIL" "Not required (security risk)"
        }

        # Check security layer
        $securityLayer = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name "SecurityLayer"

        switch ($securityLayer) {
            0 { Register-Check "RDP Security Layer" "FAIL" "RDP (insecure)" }
            1 { Register-Check "RDP Security Layer" "PASS" "Negotiate (recommended)" }
            2 { Register-Check "RDP Security Layer" "PASS" "SSL/TLS (recommended)" }
            default { Register-Check "RDP Security Layer" "WARN" "Unknown: $securityLayer" }
        }

    } else {
        Register-Check "RDP" "PASS" "Disabled (not needed)"
    }

} catch {
    Register-Check "RDP settings check" "WARN" "Unable to check RDP settings"
}

#==============================================================================
# SECTION 5: SMB AND NETWORK PROTOCOLS
#==============================================================================

Write-Section "SMB and Network Protocol Settings"

try {
    # SMBv1 disabled
    $smbv1 = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB1"

    if ($smbv1 -eq 0) {
        Register-Check "SMBv1" "PASS" "Disabled (secure)"
    } else {
        Register-Check "SMBv1" "FAIL" "Enabled or not configured (security risk)"
    }

    # LLMNR disabled
    $llmnr = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast"

    if ($llmnr -eq 0) {
        Register-Check "LLMNR" "PASS" "Disabled (prevents LLMNR poisoning)"
    } else {
        Register-Check "LLMNR" "WARN" "Not disabled (vulnerable to poisoning attacks)"
    }

    # NetBIOS over TCP/IP
    $netbios = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NodeType"

    if ($netbios -eq 2) {
        Register-Check "NetBIOS" "PASS" "P-node (WINS only)"
    } else {
        Register-Check "NetBIOS" "WARN" "Broadcast enabled (consider disabling)"
    }

} catch {
    Register-Check "Network protocols check" "WARN" "Unable to check network settings"
}

#==============================================================================
# SECTION 6: POWERSHELL LOGGING
#==============================================================================

Write-Section "PowerShell Logging and Security"

try {
    # Module logging
    $moduleLogging = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging" -Name "EnableModuleLogging"

    if ($moduleLogging -eq 1) {
        Register-Check "PowerShell Module Logging" "PASS" "Enabled (tracks module usage)"
    } else {
        Register-Check "PowerShell Module Logging" "WARN" "Not enabled (enable for auditing)"
    }

    # Script block logging
    $scriptBlockLogging = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name "EnableScriptBlockLogging"

    if ($scriptBlockLogging -eq 1) {
        Register-Check "PowerShell Script Block Logging" "PASS" "Enabled (captures script content)"
    } else {
        Register-Check "PowerShell Script Block Logging" "WARN" "Not enabled (enable for forensics)"
    }

    # Transcription
    $transcription = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" -Name "EnableTranscripting"

    if ($transcription -eq 1) {
        Register-Check "PowerShell Transcription" "PASS" "Enabled (records all activity)"
    } else {
        Register-Check "PowerShell Transcription" "WARN" "Not enabled (enable for full auditing)"
    }

    # Execution policy (HKLM)
    $execPolicy = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell" -Name "ExecutionPolicy"

    if ($execPolicy) {
        switch ($execPolicy) {
            "Restricted" { Register-Check "PowerShell Execution Policy" "PASS" "Restricted (most secure)" }
            "AllSigned" { Register-Check "PowerShell Execution Policy" "PASS" "AllSigned (signed scripts only)" }
            "RemoteSigned" { Register-Check "PowerShell Execution Policy" "WARN" "RemoteSigned (local scripts unrestricted)" }
            "Unrestricted" { Register-Check "PowerShell Execution Policy" "FAIL" "Unrestricted (insecure)" }
            "Bypass" { Register-Check "PowerShell Execution Policy" "FAIL" "Bypass (no restrictions)" }
            default { Register-Check "PowerShell Execution Policy" "WARN" "Unknown: $execPolicy" }
        }
    } else {
        Register-Check "PowerShell Execution Policy" "WARN" "Not configured via registry (check Get-ExecutionPolicy)"
    }

} catch {
    Register-Check "PowerShell settings check" "WARN" "Unable to check PowerShell settings"
}

#==============================================================================
# SECTION 7: AUTORUN AND AUTOPLAY
#==============================================================================

Write-Section "AutoRun and AutoPlay Settings"

try {
    # AutoRun disabled
    $autoRun = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun"

    # Bitwise: 0xFF disables all drives
    if ($autoRun -eq 255) {
        Register-Check "AutoRun" "PASS" "Disabled for all drives"
    } elseif ($autoRun -ge 4) {
        Register-Check "AutoRun" "WARN" "Partially disabled (value: $autoRun)"
    } else {
        Register-Check "AutoRun" "FAIL" "Not properly disabled (malware vector)"
    }

    # AutoPlay disabled
    $autoPlay = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoAutorun"

    if ($autoPlay -eq 1) {
        Register-Check "AutoPlay" "PASS" "Disabled"
    } else {
        Register-Check "AutoPlay" "WARN" "Not disabled (security risk)"
    }

} catch {
    Register-Check "AutoRun/AutoPlay check" "WARN" "Unable to check AutoRun settings"
}

#==============================================================================
# SECTION 8: WINDOWS UPDATE
#==============================================================================

Write-Section "Windows Update Settings"

try {
    # Automatic updates
    $autoUpdate = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoUpdate"

    if ($autoUpdate -eq 0 -or $null -eq $autoUpdate) {
        Register-Check "Automatic Updates" "PASS" "Not disabled"
    } else {
        Register-Check "Automatic Updates" "FAIL" "Disabled by policy (security risk)"
    }

    # Auto update configuration
    $auConfig = Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions"

    switch ($auConfig) {
        2 { Register-Check "Update Installation" "WARN" "Notify before download" }
        3 { Register-Check "Update Installation" "WARN" "Download but notify before install" }
        4 { Register-Check "Update Installation" "PASS" "Auto download and schedule install" }
        5 { Register-Check "Update Installation" "PASS" "Automatic with local admin choice" }
        default { Register-Check "Update Installation" "PASS" "Not configured (default behavior)" }
    }

} catch {
    Register-Check "Windows Update check" "WARN" "Unable to check Windows Update settings"
}

#==============================================================================
# SECTION 9: SCREEN SAVER AND LOCK SCREEN
#==============================================================================

Write-Section "Screen Saver and Lock Screen Policies"

try {
    # Screen saver timeout (system-wide policy)
    $ssTimeout = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "InactivityTimeoutSecs"

    if ($ssTimeout -and $ssTimeout -le 900) {
        Register-Check "Inactivity timeout" "PASS" "$ssTimeout seconds (≤15 minutes)"
    } elseif ($ssTimeout) {
        Register-Check "Inactivity timeout" "WARN" "$ssTimeout seconds (>15 minutes)"
    } else {
        Register-Check "Inactivity timeout" "WARN" "Not configured (set ≤900 seconds)"
    }

    # Machine inactivity limit
    $machineInactivity = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "MaxInactivity"

    if ($machineInactivity -and $machineInactivity -le 900000) {
        Register-Check "Machine inactivity limit" "PASS" "$([int]($machineInactivity / 1000)) seconds"
    } else {
        Register-Check "Machine inactivity limit" "WARN" "Not configured or >15 minutes"
    }

} catch {
    Register-Check "Screen saver check" "WARN" "Unable to check screen saver settings"
}

#==============================================================================
# SECTION 10: AUDIT POLICY CONFIGURATION
#==============================================================================

Write-Section "Audit Policy Configuration"

try {
    # Advanced Audit Policy enabled
    $advancedAudit = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SCENoApplyLegacyAuditPolicy"

    if ($advancedAudit -eq 1) {
        Register-Check "Advanced Audit Policy" "PASS" "Enabled (overrides legacy)"
    } else {
        Register-Check "Advanced Audit Policy" "WARN" "Not enabled (legacy audit may be used)"
    }

    # Audit process creation command line
    $auditCmdLine = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" -Name "ProcessCreationIncludeCmdLine_Enabled"

    if ($auditCmdLine -eq 1) {
        Register-Check "Process command line auditing" "PASS" "Enabled (forensics/IR)"
    } else {
        Register-Check "Process command line auditing" "WARN" "Not enabled (enable for forensics)"
    }

} catch {
    Register-Check "Audit policy check" "WARN" "Unable to check audit policy settings"
}

#==============================================================================
# SECTION 11: ANONYMOUS ACCESS
#==============================================================================

Write-Section "Anonymous Access and Guest Settings"

try {
    # Restrict anonymous access to shares
    $restrictAnonymous = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RestrictAnonymous"

    if ($restrictAnonymous -eq 2) {
        Register-Check "Restrict anonymous access" "PASS" "Enabled (no enumeration)"
    } elseif ($restrictAnonymous -eq 1) {
        Register-Check "Restrict anonymous access" "WARN" "Partial (no SAM enumeration only)"
    } else {
        Register-Check "Restrict anonymous access" "FAIL" "Not restricted (information disclosure)"
    }

    # Let Everyone permissions apply to anonymous users
    $everyoneIncludesAnonymous = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "EveryoneIncludesAnonymous"

    if ($everyoneIncludesAnonymous -eq 0 -or $null -eq $everyoneIncludesAnonymous) {
        Register-Check "Everyone includes Anonymous" "PASS" "Disabled (secure)"
    } else {
        Register-Check "Everyone includes Anonymous" "FAIL" "Enabled (security risk)"
    }

} catch {
    Register-Check "Anonymous access check" "WARN" "Unable to check anonymous access settings"
}

#==============================================================================
# SECTION 12: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}

