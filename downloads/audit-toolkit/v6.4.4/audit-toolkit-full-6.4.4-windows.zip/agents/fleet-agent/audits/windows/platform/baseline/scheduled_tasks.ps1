#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Task Scheduler Security Audit

.DESCRIPTION
    Comprehensive security audit of Task Scheduler configuration including:
    - Task Scheduler service status
    - Tasks running with elevated privileges
    - Tasks with weak permissions
    - Hidden tasks detection
    - Tasks running as SYSTEM or Administrator
    - Tasks with suspicious actions
    - Tasks accessing network resources
    - Disabled/failed tasks
    - Task history and logging
    - Tasks executing scripts or binaries

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows Task Scheduler Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: TASK SCHEDULER SERVICE STATUS
#==============================================================================

Write-Section "Task Scheduler Service Status"

try {
    $taskSchedulerService = Get-Service -Name "Schedule" -ErrorAction SilentlyContinue

    if ($taskSchedulerService) {
        if ($taskSchedulerService.Status -eq 'Running') {
            Register-Check "Task Scheduler service" "PASS" "Running"
        } else {
            Register-Check "Task Scheduler service" "FAIL" "Not running (Status: $($taskSchedulerService.Status))"
        }

        if ($taskSchedulerService.StartType -eq 'Automatic') {
            Register-Check "Task Scheduler startup" "PASS" "Automatic"
        } else {
            Register-Check "Task Scheduler startup" "WARN" "Not automatic (Type: $($taskSchedulerService.StartType))"
        }
    } else {
        Register-Check "Task Scheduler service" "FAIL" "Service not found"
    }

} catch {
    Register-Check "Task Scheduler service check" "WARN" "Unable to check service: $($_.Exception.Message)"
}

#==============================================================================
# SECTION 2: TASKS WITH ELEVATED PRIVILEGES
#==============================================================================

Write-Section "Tasks with Elevated Privileges"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    # Tasks running as SYSTEM
    $systemTasks = $allTasks | Where-Object {
        $_.Principal.UserId -eq 'SYSTEM' -or
        $_.Principal.UserId -eq 'NT AUTHORITY\SYSTEM'
    }

    if ($systemTasks) {
        $count = ($systemTasks | Measure-Object).Count
        Register-Check "Tasks running as SYSTEM" "WARN" "$count task(s) with SYSTEM privileges"

        # List first 3 for visibility
        foreach ($task in $systemTasks | Select-Object -First 3) {
            Write-Output "  - $($task.TaskPath)$($task.TaskName)"
        }
    } else {
        Register-Check "Tasks running as SYSTEM" "PASS" "No tasks with SYSTEM privileges"
    }

    # Tasks with RunLevel = Highest
    $highestTasks = $allTasks | Where-Object { $_.Principal.RunLevel -eq 'Highest' }

    if ($highestTasks) {
        $count = ($highestTasks | Measure-Object).Count
        Register-Check "Tasks with 'Run with highest privileges'" "WARN" "$count task(s) require review"
    } else {
        Register-Check "Tasks with 'Run with highest privileges'" "PASS" "No tasks with elevated RunLevel"
    }

} catch {
    Register-Check "Elevated privileges check" "WARN" "Unable to check task privileges"
}

#==============================================================================
# SECTION 3: HIDDEN TASKS
#==============================================================================

Write-Section "Hidden Tasks"

try {
    $hiddenTasks = Get-ScheduledTask | Where-Object {
        $_.Settings.Hidden -eq $true -and
        $_.State -ne 'Disabled'
    }

    if ($hiddenTasks) {
        $count = ($hiddenTasks | Measure-Object).Count
        Register-Check "Hidden tasks" "WARN" "$count hidden task(s) detected (review required)"

        # List first 5 for visibility
        foreach ($task in $hiddenTasks | Select-Object -First 5) {
            Write-Output "  Hidden: $($task.TaskPath)$($task.TaskName)"
        }
    } else {
        Register-Check "Hidden tasks" "PASS" "No hidden tasks"
    }

} catch {
    Register-Check "Hidden tasks check" "WARN" "Unable to check for hidden tasks"
}

#==============================================================================
# SECTION 4: TASKS WITH SUSPICIOUS ACTIONS
#==============================================================================

Write-Section "Tasks with Suspicious Actions"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    $suspiciousPatterns = @(
        @{ Pattern = "powershell.*-enc"; Name = "Encoded PowerShell" },
        @{ Pattern = "cmd.*/c.*curl|wget|bitsadmin"; Name = "Download tools" },
        @{ Pattern = "mshta|regsvr32|rundll32"; Name = "LOLBins" },
        @{ Pattern = "net user|net localgroup"; Name = "User/Group manipulation" },
        @{ Pattern = "\\\\.*\\.*"; Name = "Network paths" }
    )

    $suspiciousCount = 0

    foreach ($task in $allTasks) {
        Get-ScheduledTaskInfo -TaskPath $task.TaskPath -TaskName $task.TaskName -ErrorAction SilentlyContinue | Out-Null
        $actions = $task.Actions

        foreach ($action in $actions) {
            if ($action.Execute) {
                $commandLine = "$($action.Execute) $($action.Arguments)"

                foreach ($pattern in $suspiciousPatterns) {
                    if ($commandLine -match $pattern.Pattern) {
                        Register-Check "Suspicious task: $($task.TaskName)" "FAIL" "$($pattern.Name) detected"
                        Write-Output "    Command: $commandLine"
                        $suspiciousCount++
                        break
                    }
                }
            }
        }
    }

    if ($suspiciousCount -eq 0) {
        Register-Check "Suspicious task actions" "PASS" "No suspicious patterns detected"
    }

} catch {
    Register-Check "Suspicious actions check" "WARN" "Unable to check task actions"
}

#==============================================================================
# SECTION 5: TASKS RUNNING SCRIPTS
#==============================================================================

Write-Section "Tasks Running Scripts"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    $scriptExtensions = @('.ps1', '.vbs', '.js', '.bat', '.cmd')
    $scriptTasks = @()

    foreach ($task in $allTasks) {
        foreach ($action in $task.Actions) {
            if ($action.Execute) {
                $exec = $action.Execute.ToLower()

                # Check if executing a script
                $isScript = $scriptExtensions | Where-Object { $exec.Contains($_) }

                # Or if powershell/cscript/wscript are used
                if ($isScript -or $exec -match "powershell|cscript|wscript") {
                    $scriptTasks += $task
                    break
                }
            }
        }
    }

    if ($scriptTasks) {
        $count = ($scriptTasks | Measure-Object).Count
        Register-Check "Tasks executing scripts" "WARN" "$count task(s) execute scripts (verify legitimacy)"

        # List first 5
        foreach ($task in $scriptTasks | Select-Object -First 5) {
            Write-Output "  - $($task.TaskPath)$($task.TaskName)"
        }
    } else {
        Register-Check "Tasks executing scripts" "PASS" "No tasks executing scripts directly"
    }

} catch {
    Register-Check "Script execution check" "WARN" "Unable to check for script tasks"
}

#==============================================================================
# SECTION 6: TASKS WITH NETWORK ACTIONS
#==============================================================================

Write-Section "Tasks with Network Actions"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    $networkTasks = @()

    foreach ($task in $allTasks) {
        foreach ($action in $task.Actions) {
            if ($action.Execute) {
                $commandLine = "$($action.Execute) $($action.Arguments)"

                # Check for UNC paths or URLs
                if ($commandLine -match "\\\\[a-zA-Z0-9]|https?://|ftp://") {
                    $networkTasks += [PSCustomObject]@{
                        Task = "$($task.TaskPath)$($task.TaskName)"
                        Command = $commandLine
                    }
                    break
                }
            }
        }
    }

    if ($networkTasks) {
        $count = ($networkTasks | Measure-Object).Count
        Register-Check "Tasks accessing network resources" "WARN" "$count task(s) access network (review required)"

        foreach ($nt in $networkTasks | Select-Object -First 3) {
            Write-Output "  - $($nt.Task)"
            Write-Output "    $($nt.Command)"
        }
    } else {
        Register-Check "Tasks accessing network resources" "PASS" "No tasks with network actions"
    }

} catch {
    Register-Check "Network actions check" "WARN" "Unable to check network tasks"
}

#==============================================================================
# SECTION 7: DISABLED AND FAILED TASKS
#==============================================================================

Write-Section "Disabled and Failed Tasks"

try {
    # Count disabled tasks
    $disabledTasks = Get-ScheduledTask | Where-Object { $_.State -eq 'Disabled' }

    if ($disabledTasks) {
        $count = ($disabledTasks | Measure-Object).Count
        Register-Check "Disabled tasks" "PASS" "$count task(s) disabled"
    } else {
        Register-Check "Disabled tasks" "PASS" "No disabled tasks"
    }

    # Check for tasks in failed state
    $failedTasks = Get-ScheduledTask | Where-Object {
        $info = Get-ScheduledTaskInfo -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue
        $info -and $info.LastTaskResult -ne 0
    }

    if ($failedTasks) {
        $count = ($failedTasks | Measure-Object).Count
        Register-Check "Failed tasks" "WARN" "$count task(s) with non-zero exit codes"

        foreach ($task in $failedTasks | Select-Object -First 5) {
            $info = Get-ScheduledTaskInfo -TaskName $task.TaskName -TaskPath $task.TaskPath
            Write-Output "  Failed: $($task.TaskPath)$($task.TaskName) (Code: $($info.LastTaskResult))"
        }
    } else {
        Register-Check "Failed tasks" "PASS" "No tasks with failure codes"
    }

} catch {
    Register-Check "Disabled/failed tasks check" "WARN" "Unable to check task status"
}

#==============================================================================
# SECTION 8: TASK TRIGGERS
#==============================================================================

Write-Section "Task Triggers"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    # Tasks with startup triggers
    $startupTasks = $allTasks | Where-Object {
        $_.Triggers | Where-Object { $_.CimClass.CimClassName -eq 'MSFT_TaskBootTrigger' }
    }

    if ($startupTasks) {
        $count = ($startupTasks | Measure-Object).Count
        Register-Check "Tasks with boot/startup triggers" "PASS" "$count task(s) run at startup"
    }

    # Tasks with logon triggers
    $logonTasks = $allTasks | Where-Object {
        $_.Triggers | Where-Object { $_.CimClass.CimClassName -eq 'MSFT_TaskLogonTrigger' }
    }

    if ($logonTasks) {
        $count = ($logonTasks | Measure-Object).Count
        Register-Check "Tasks with logon triggers" "WARN" "$count task(s) run at user logon (review persistence)"
    }

    # Tasks with no triggers
    $noTriggerTasks = $allTasks | Where-Object { -not $_.Triggers }

    if ($noTriggerTasks) {
        $count = ($noTriggerTasks | Measure-Object).Count
        Register-Check "Tasks with no triggers" "WARN" "$count task(s) have no triggers (manual only?)"
    } else {
        Register-Check "Tasks with no triggers" "PASS" "All tasks have triggers"
    }

} catch {
    Register-Check "Task triggers check" "WARN" "Unable to check task triggers"
}

#==============================================================================
# SECTION 9: TASK HISTORY AND LOGGING
#==============================================================================

Write-Section "Task History and Logging"

try {
    # Check if task history is enabled
    $taskSchedulerKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance"

    if (Test-Path $taskSchedulerKey) {
        $historyEnabled = Get-ItemProperty -Path $taskSchedulerKey -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue

        if ($historyEnabled -and $historyEnabled.MaintenanceDisabled -eq 1) {
            Register-Check "Task history" "WARN" "Task history disabled (enable for auditing)"
        } else {
            Register-Check "Task history" "PASS" "Task history enabled"
        }
    }

    # Check Event Log for recent task failures
    $recentFailures = Get-WinEvent -FilterHashtable @{
        LogName = 'Microsoft-Windows-TaskScheduler/Operational'
        Level = 2  # Error
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 10 -ErrorAction SilentlyContinue

    if ($recentFailures) {
        $count = ($recentFailures | Measure-Object).Count
        Register-Check "Recent task failures (7 days)" "WARN" "$count error(s) in Task Scheduler logs"
    } else {
        Register-Check "Recent task failures (7 days)" "PASS" "No recent errors"
    }

} catch {
    Register-Check "Task history check" "WARN" "Unable to check task history"
}

#==============================================================================
# SECTION 10: TASKS RUNNING AS SPECIFIC USERS
#==============================================================================

Write-Section "Tasks Running as Specific Users"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    # Group tasks by user account
    $tasksByUser = $allTasks | Group-Object { $_.Principal.UserId } | Sort-Object Count -Descending

    foreach ($group in $tasksByUser | Select-Object -First 5) {
        $user = $group.Name
        $count = $group.Count

        if ($user -match "SYSTEM|LOCAL SERVICE|NETWORK SERVICE") {
            Register-Check "Tasks as '$user'" "PASS" "$count task(s)"
        } elseif ($user -match "Administrator") {
            Register-Check "Tasks as '$user'" "WARN" "$count task(s) with admin privileges"
        } else {
            Register-Check "Tasks as '$user'" "PASS" "$count task(s)"
        }
    }

} catch {
    Register-Check "Task user accounts check" "WARN" "Unable to check task users"
}

#==============================================================================
# SECTION 11: TASKS WITH WEAK SECURITY SETTINGS
#==============================================================================

Write-Section "Tasks with Weak Security Settings"

try {
    $allTasks = Get-ScheduledTask | Where-Object { $_.State -ne 'Disabled' }

    # Tasks allowing stop if going on batteries
    $batterySensitiveTasks = $allTasks | Where-Object {
        $_.Settings.StopIfGoingOnBatteries -eq $false
    }

    if ($batterySensitiveTasks) {
        $count = ($batterySensitiveTasks | Measure-Object).Count
        Register-Check "Tasks ignoring battery state" "PASS" "$count task(s) run on battery"
    }

    # Tasks with AllowStartOnDemand disabled
    $noOnDemandTasks = $allTasks | Where-Object {
        $_.Settings.AllowStartOnDemand -eq $false
    }

    if ($noOnDemandTasks) {
        $count = ($noOnDemandTasks | Measure-Object).Count
        Register-Check "Tasks blocking on-demand start" "WARN" "$count task(s) cannot be started manually"
    } else {
        Register-Check "Tasks blocking on-demand start" "PASS" "All tasks allow manual start"
    }

    # Tasks with multiple instances allowed
    $multiInstanceTasks = $allTasks | Where-Object {
        $_.Settings.MultipleInstances -ne 'IgnoreNew'
    }

    if ($multiInstanceTasks) {
        $count = ($multiInstanceTasks | Measure-Object).Count
        Register-Check "Tasks allowing multiple instances" "WARN" "$count task(s) allow parallel execution"
    } else {
        Register-Check "Tasks allowing multiple instances" "PASS" "All tasks ignore new instances"
    }

} catch {
    Register-Check "Weak security settings check" "WARN" "Unable to check task security settings"
}

#==============================================================================
# SECTION 12: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
