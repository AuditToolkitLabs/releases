#Requires -Version 5.1
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Windows Services Security Audit.
.DESCRIPTION
    Read-only audit for critical service health and risky service posture.
.NOTES
    Uses shared Windows audit helpers from lib/common.ps1.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

function Get-ServiceSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )

    return Get-Service -Name $Name -ErrorAction SilentlyContinue
}

function Get-ServiceWmiSafe {
    [CmdletBinding()]
    param()

    return Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue
}

function Add-ServiceDefinition {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Collections.Generic.List[object]]$List,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [bool]$Required = $true
    )

    $List.Add([pscustomobject]@{
            Name = $Name
            DisplayName = $DisplayName
            Required = $Required
        })
}

Write-Section 'Windows Services Security Audit'

if (-not (Test-IsAdminMode)) {
    Register-Check 'Administrator Privileges' 'SKIP' 'This audit requires Administrator privileges'
    Print-Summary
    exit 0
}

$osInfo = Get-WindowsVersion
$isServer = Test-IsServerOS
Register-Check 'Operating System' 'INFO' ("{0} (Build {1})" -f $osInfo.ProductName, $osInfo.Build)
Register-Check 'Server OS' 'INFO' ([string]$isServer)

Write-Section 'Critical Services Status'
$criticalList = New-Object System.Collections.Generic.List[object]
Add-ServiceDefinition -List $criticalList -Name 'wuauserv' -DisplayName 'Windows Update' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'mpssvc' -DisplayName 'Windows Defender Firewall' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'WinDefend' -DisplayName 'Windows Defender Antivirus' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'EventLog' -DisplayName 'Windows Event Log' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'CryptSvc' -DisplayName 'Cryptographic Services' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'TrustedInstaller' -DisplayName 'Windows Modules Installer' -Required $false
Add-ServiceDefinition -List $criticalList -Name 'wscsvc' -DisplayName 'Security Center' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'Dhcp' -DisplayName 'DHCP Client' -Required $false
Add-ServiceDefinition -List $criticalList -Name 'Dnscache' -DisplayName 'DNS Client' -Required $true
Add-ServiceDefinition -List $criticalList -Name 'LanmanServer' -DisplayName 'Server (SMB)' -Required $false
Add-ServiceDefinition -List $criticalList -Name 'LanmanWorkstation' -DisplayName 'Workstation (SMB Client)' -Required $true

if ($isServer) {
    Add-ServiceDefinition -List $criticalList -Name 'W3SVC' -DisplayName 'IIS Admin Service' -Required $false
    Add-ServiceDefinition -List $criticalList -Name 'MSSQLSERVER' -DisplayName 'SQL Server' -Required $false
}

foreach ($item in $criticalList) {
    $service = Get-ServiceSafe -Name $item.Name
    if ($null -eq $service) {
        if ($item.Required) {
            Register-Check ("Service: {0}" -f $item.DisplayName) 'WARN' 'Service not found (may not be installed)'
        }
        else {
            Register-Check ("Service: {0}" -f $item.DisplayName) 'SKIP' 'Optional service not installed'
        }
        continue
    }

    if ($service.Status -eq 'Running') {
        Register-Check ("Service: {0}" -f $item.DisplayName) 'PASS' ("Running ({0})" -f $service.StartType)
    }
    elseif ($item.Required) {
        Register-Check ("Service: {0}" -f $item.DisplayName) 'FAIL' ("Not running (Status: {0})" -f $service.Status)
    }
    else {
        Register-Check ("Service: {0}" -f $item.DisplayName) 'WARN' ("Not running (Status: {0})" -f $service.Status)
    }
}

Write-Section 'Unnecessary and Risky Services'
$riskyList = @(
    @{ Name = 'RemoteRegistry'; Reason = 'Allows remote registry access' }
    @{ Name = 'Telnet'; Reason = 'Insecure remote access protocol' }
    @{ Name = 'SSDPSRV'; Reason = 'UPnP discovery attack surface' }
    @{ Name = 'upnphost'; Reason = 'UPnP host attack surface' }
    @{ Name = 'RemoteAccess'; Reason = 'Rarely needed on hardened hosts' }
    @{ Name = 'XblAuthManager'; Reason = 'Consumer service not needed on servers' }
    @{ Name = 'XblGameSave'; Reason = 'Consumer service not needed on servers' }
    @{ Name = 'XboxGipSvc'; Reason = 'Consumer service not needed on servers' }
    @{ Name = 'XboxNetApiSvc'; Reason = 'Consumer service not needed on servers' }
)

foreach ($riskItem in $riskyList) {
    $service = Get-ServiceSafe -Name $riskItem.Name
    if ($null -eq $service) {
        Register-Check ("Risky Service: {0}" -f $riskItem.Name) 'PASS' 'Not installed'
        continue
    }

    if ($service.StartType -eq 'Disabled' -or $service.Status -ne 'Running') {
        Register-Check ("Risky Service: {0}" -f $riskItem.Name) 'PASS' 'Disabled or not running'
    }
    else {
        Register-Check ("Risky Service: {0}" -f $riskItem.Name) 'FAIL' ("{0} - Currently {1}" -f $riskItem.Reason, $service.Status)
    }
}

Write-Section 'Service Startup Configuration'
$autoStopped = Get-Service | Where-Object { $_.StartType -eq 'Automatic' -and $_.Status -ne 'Running' }
if ($autoStopped.Count -eq 0) {
    Register-Check 'Auto-start service state' 'PASS' 'All automatic services are running'
}
elseif ($autoStopped.Count -le 3) {
    Register-Check 'Auto-start service state' 'WARN' ("{0} automatic service(s) are not running" -f $autoStopped.Count)
}
else {
    $sampleName = ($autoStopped | Select-Object -First 5 -ExpandProperty Name) -join ', '
    Register-Check 'Auto-start service state' 'FAIL' ("{0} automatic service(s) are not running ({1})" -f $autoStopped.Count, $sampleName)
}

$autoCount = (Get-Service | Where-Object { $_.StartType -eq 'Automatic' -or $_.StartType -eq 'AutomaticDelayedStart' }).Count
if ($autoCount -lt 50) {
    Register-Check 'Auto-start service count' 'PASS' ("{0} service(s)" -f $autoCount)
}
elseif ($autoCount -lt 75) {
    Register-Check 'Auto-start service count' 'WARN' ("{0} service(s) - consider optimization" -f $autoCount)
}
else {
    Register-Check 'Auto-start service count' 'FAIL' ("{0} service(s) - likely performance impact" -f $autoCount)
}

Write-Section 'Service Account Security'
$runningWmiService = Get-ServiceWmiSafe | Where-Object { $_.State -eq 'Running' }
$localSystemService = $runningWmiService |
    Where-Object { $_.StartName -eq 'LocalSystem' } |
    Where-Object { $_.Name -notin @('EventLog', 'CryptSvc', 'TrustedInstaller', 'WinDefend') }

if ($localSystemService.Count -le 10) {
    Register-Check 'LocalSystem service count' 'PASS' ("{0} service(s)" -f $localSystemService.Count)
}
elseif ($localSystemService.Count -le 20) {
    Register-Check 'LocalSystem service count' 'WARN' ("{0} service(s) - review recommended" -f $localSystemService.Count)
}
else {
    Register-Check 'LocalSystem service count' 'FAIL' ("{0} service(s) - excessive privilege" -f $localSystemService.Count)
}

$domainInfo = Get-DomainInfo
if ($domainInfo.IsDomainJoined) {
    $adminService = $runningWmiService | Where-Object { $_.StartName -like '*Administrator*' -or $_.StartName -like '*Admin*' }
    if ($adminService.Count -eq 0) {
        Register-Check 'Admin account service use' 'PASS' 'No running service uses admin account names'
    }
    else {
        $sampleName = ($adminService | Select-Object -First 3 -ExpandProperty Name) -join ', '
        Register-Check 'Admin account service use' 'FAIL' ("{0} service(s) use admin account names ({1})" -f $adminService.Count, $sampleName)
    }
}

Write-Section 'Service Recovery Configuration'
$criticalNameList = @('wuauserv', 'mpssvc', 'WinDefend', 'EventLog')
$missingRecovery = @()
foreach ($serviceName in $criticalNameList) {
    if (-not (Get-ServiceSafe -Name $serviceName)) {
        continue
    }

    $recoveryInfo = sc.exe qfailure $serviceName 2>$null
    if ($recoveryInfo -notmatch 'RESTART') {
        $missingRecovery += $serviceName
    }
}

if ($missingRecovery.Count -eq 0) {
    Register-Check 'Critical service recovery' 'PASS' 'Recovery action configured'
}
else {
    Register-Check 'Critical service recovery' 'WARN' ("Missing restart recovery for: {0}" -f ($missingRecovery -join ', '))
}

Write-Section 'Third-Party and Remote Access Service'
$thirdPartyService = Get-ServiceWmiSafe |
    Where-Object { $_.State -eq 'Running' } |
    Where-Object { $_.PathName -and $_.PathName -notmatch 'Windows\\System32|Windows\\SysWOW64' }

if ($thirdPartyService.Count -eq 0) {
    Register-Check 'Third-party running service count' 'PASS' 'No third-party running services detected'
}
elseif ($thirdPartyService.Count -le 10) {
    Register-Check 'Third-party running service count' 'PASS' ("{0} service(s)" -f $thirdPartyService.Count)
}
elseif ($thirdPartyService.Count -le 20) {
    Register-Check 'Third-party running service count' 'WARN' ("{0} service(s) - review recommended" -f $thirdPartyService.Count)
}
else {
    Register-Check 'Third-party running service count' 'FAIL' ("{0} service(s) - security review required" -f $thirdPartyService.Count)
}

$rdp = Get-ServiceSafe -Name 'TermService'
if ($null -eq $rdp) {
    Register-Check 'Remote Desktop service' 'PASS' 'RDP not installed'
}
elseif ($rdp.Status -eq 'Running') {
    Register-Check 'Remote Desktop service' 'WARN' 'RDP enabled (verify NLA and access controls)'
}
else {
    Register-Check 'Remote Desktop service' 'PASS' 'RDP disabled'
}

$winrm = Get-ServiceSafe -Name 'WinRM'
if ($winrm -and $winrm.Status -eq 'Running') {
    Register-Check 'WinRM service' 'WARN' 'PowerShell remoting enabled (verify authentication hardening)'
}
else {
    Register-Check 'WinRM service' 'PASS' 'PowerShell remoting disabled or service missing'
}

$sshd = Get-ServiceSafe -Name 'sshd'
if ($sshd -and $sshd.Status -eq 'Running') {
    Register-Check 'SSH server service' 'WARN' 'OpenSSH server enabled (verify key-based auth and policy)'
}
else {
    Register-Check 'SSH server service' 'PASS' 'SSH server disabled or service missing'
}

Print-Summary

if ($script:FailedChecks -gt 0) {
    exit 2
}
if ($script:WarnedChecks -gt 0) {
    exit 1
}
exit 0
