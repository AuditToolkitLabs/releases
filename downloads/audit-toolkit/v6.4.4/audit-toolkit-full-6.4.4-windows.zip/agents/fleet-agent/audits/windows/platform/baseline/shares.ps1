#Requires -Version 5.1
<#
.SYNOPSIS
    Windows SMB Shares and Permissions Security Audit

.DESCRIPTION
    Comprehensive security audit of SMB shares and file permissions including:
    - SMB share enumeration and configuration
    - Share permissions and ACLs
    - Administrative shares (C$, ADMIN$, IPC$)
    - Hidden shares detection
    - Guest access and null sessions
    - SMB protocol versions and signing
    - Share access auditing
    - NTFS permissions on shared folders
    - Share inheritance and security descriptors
    - SMB encryption configuration

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows SMB Shares and Permissions Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: SMB SERVICE STATUS
#==============================================================================

Write-Section "SMB Service Status"

try {
    $smbServices = @(
        @{ Name = "LanmanServer"; DisplayName = "Server (SMB)" },
        @{ Name = "LanmanWorkstation"; DisplayName = "Workstation (SMB client)" }
    )

    foreach ($svcInfo in $smbServices) {
        $svc = Get-Service -Name $svcInfo.Name -ErrorAction SilentlyContinue

        if ($svc) {
            if ($svc.Status -eq 'Running') {
                Register-Check "$($svcInfo.DisplayName) service" "PASS" "Running"
            } else {
                Register-Check "$($svcInfo.DisplayName) service" "WARN" "Not running (Status: $($svc.Status))"
            }
        } else {
            Register-Check "$($svcInfo.DisplayName) service" "WARN" "Service not found"
        }
    }

} catch {
    Register-Check "SMB service check" "WARN" "Unable to check SMB services"
}

#==============================================================================
# SECTION 2: SMB SHARE ENUMERATION
#==============================================================================

Write-Section "SMB Share Enumeration"

try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue

    if ($shares) {
        $totalShares = ($shares | Measure-Object).Count
        Register-Check "Total SMB shares" "PASS" "$totalShares share(s) configured"

        # Count non-administrative shares
        $userShares = $shares | Where-Object {
            $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
        }

        if ($userShares) {
            $userShareCount = ($userShares | Measure-Object).Count
            Register-Check "User-created shares" "PASS" "$userShareCount share(s)"
        } else {
            Register-Check "User-created shares" "PASS" "No custom shares (administrative only)"
        }

    } else {
        Register-Check "SMB shares" "WARN" "Unable to enumerate shares"
    }

} catch {
    Register-Check "Share enumeration" "WARN" "Unable to enumerate shares"
}

#==============================================================================
# SECTION 3: ADMINISTRATIVE SHARES
#==============================================================================

Write-Section "Administrative Shares"

try {
    $adminShares = @("ADMIN$", "C$", "IPC$")

    foreach ($shareName in $adminShares) {
        $share = Get-SmbShare -Name $shareName -ErrorAction SilentlyContinue

        if ($share) {
            Register-Check "Administrative share $shareName" "PASS" "Present"
        } else {
            Register-Check "Administrative share $shareName" "WARN" "Not found (may be disabled)"
        }
    }

    # Check if admin shares are disabled
    $adminSharesDisabled = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AutoShareWks" -ErrorAction SilentlyContinue

    if ($adminSharesDisabled -and $adminSharesDisabled.AutoShareWks -eq 0) {
        Register-Check "AutoShareWks" "WARN" "Administrative shares disabled (AutoShareWks=0)"
    } else {
        Register-Check "AutoShareWks" "PASS" "Enabled (default for workstations)"
    }

    # Server OS check
    $autoShareServer = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AutoShareServer" -ErrorAction SilentlyContinue

    if ($autoShareServer -and $autoShareServer.AutoShareServer -eq 0) {
        Register-Check "AutoShareServer" "WARN" "Administrative shares disabled (AutoShareServer=0)"
    } else {
        Register-Check "AutoShareServer" "PASS" "Enabled (default for servers)"
    }

} catch {
    Register-Check "Administrative shares check" "WARN" "Unable to check administrative shares"
}

#==============================================================================
# SECTION 4: HIDDEN SHARES
#==============================================================================

Write-Section "Hidden Shares"

try {
    $allShares = Get-SmbShare -ErrorAction SilentlyContinue
    $hiddenShares = $allShares | Where-Object { $_.Name -match '\$$' }

    if ($hiddenShares) {
        $count = ($hiddenShares | Measure-Object).Count
        Register-Check "Hidden shares" "PASS" "$count hidden share(s) (ending with \$)"

        # List non-administrative hidden shares
        $customHiddenShares = $hiddenShares | Where-Object {
            $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
        }

        if ($customHiddenShares) {
            foreach ($share in $customHiddenShares | Select-Object -First 5) {
                Write-Output "  Hidden: $($share.Name) -> $($share.Path)"
            }
        }
    } else {
        Register-Check "Hidden shares" "PASS" "No hidden shares configured"
    }

} catch {
    Register-Check "Hidden shares check" "WARN" "Unable to check for hidden shares"
}

#==============================================================================
# SECTION 5: SHARE PERMISSIONS
#==============================================================================

Write-Section "Share Permissions"

try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
    }

    foreach ($share in $shares) {
        $shareAccess = Get-SmbShareAccess -Name $share.Name -ErrorAction SilentlyContinue

        # Check for Everyone with Full Control
        $everyoneFull = $shareAccess | Where-Object {
            $_.AccountName -eq "Everyone" -and
            $_.AccessRight -eq "Full"
        }

        if ($everyoneFull) {
            Register-Check "Share '$($share.Name)' permissions" "FAIL" "Everyone has Full Control (security risk)"
        }
        # Check for Everyone with write access
        elseif ($shareAccess | Where-Object { $_.AccountName -eq "Everyone" }) {
            $everyoneRight = ($shareAccess | Where-Object { $_.AccountName -eq "Everyone" }).AccessRight
            Register-Check "Share '$($share.Name)' permissions" "WARN" "Everyone has $everyoneRight access"
        }
        # Check for Guest access
        elseif ($shareAccess | Where-Object { $_.AccountName -match "Guest" }) {
            Register-Check "Share '$($share.Name)' permissions" "FAIL" "Guest account has access"
        }
        # Authenticated Users
        elseif ($shareAccess | Where-Object { $_.AccountName -match "Authenticated Users" }) {
            $authRight = ($shareAccess | Where-Object { $_.AccountName -match "Authenticated Users" }).AccessRight
            Register-Check "Share '$($share.Name)' permissions" "PASS" "Authenticated Users: $authRight"
        }
        else {
            Register-Check "Share '$($share.Name)' permissions" "PASS" "Restricted access"
        }
    }

} catch {
    Register-Check "Share permissions check" "WARN" "Unable to check share permissions"
}

#==============================================================================
# SECTION 6: NTFS PERMISSIONS ON SHARED FOLDERS
#==============================================================================

Write-Section "NTFS Permissions on Shared Folders"

try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object {
        $_.Path -and
        $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
    }

    foreach ($share in $shares | Select-Object -First 5) {
        if (Test-Path $share.Path) {
            $acl = Get-Acl -Path $share.Path -ErrorAction SilentlyContinue

            if ($acl) {
                # Check for Everyone with write access
                $everyoneWrite = $acl.Access | Where-Object {
                    $_.IdentityReference -eq "Everyone" -and
                    ($_.FileSystemRights -match "FullControl|Modify|Write")
                }

                if ($everyoneWrite) {
                    Register-Check "NTFS on '$($share.Name)'" "FAIL" "Everyone has write access to $($share.Path)"
                }
                # Check for Users with write access
                elseif ($acl.Access | Where-Object {
                    $_.IdentityReference -match "Users" -and
                    ($_.FileSystemRights -match "FullControl|Modify")
                }) {
                    Register-Check "NTFS on '$($share.Name)'" "WARN" "Users group has modify access to $($share.Path)"
                }
                else {
                    Register-Check "NTFS on '$($share.Name)'" "PASS" "Properly restricted"
                }
            }
        }
    }

} catch {
    Register-Check "NTFS permissions check" "WARN" "Unable to check NTFS permissions"
}

#==============================================================================
# SECTION 7: GUEST ACCESS AND NULL SESSIONS
#==============================================================================

Write-Section "Guest Access and Null Sessions"

try {
    # Restrict null sessions
    $restrictNullSessions = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RestrictNullSessAccess" -ErrorAction SilentlyContinue

    if ($restrictNullSessions -and $restrictNullSessions.RestrictNullSessAccess -eq 1) {
        Register-Check "Restrict null session access" "PASS" "Enabled (secure)"
    } else {
        Register-Check "Restrict null session access" "FAIL" "Not enabled (anonymous enumeration risk)"
    }

    # Guest account enabled on shares
    Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "EnableForcedLogoff" -ErrorAction SilentlyContinue | Out-Null

    # AllowInsecureGuestAuth (SMB client setting)
    $insecureGuestAuth = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "AllowInsecureGuestAuth" -ErrorAction SilentlyContinue

    if ($insecureGuestAuth -and $insecureGuestAuth.AllowInsecureGuestAuth -eq 1) {
        Register-Check "Insecure guest authentication" "FAIL" "Enabled (allows guest fallback)"
    } else {
        Register-Check "Insecure guest authentication" "PASS" "Disabled (default for Windows 10 1709+)"
    }

} catch {
    Register-Check "Guest access check" "WARN" "Unable to check guest access settings"
}

#==============================================================================
# SECTION 8: SMB PROTOCOL VERSIONS
#==============================================================================

Write-Section "SMB Protocol Versions"

try {
    # SMB1 protocol
    $smb1 = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol -ErrorAction SilentlyContinue

    if ($smb1 -eq $false) {
        Register-Check "SMBv1 protocol" "PASS" "Disabled (secure)"
    } else {
        Register-Check "SMBv1 protocol" "FAIL" "Enabled (WannaCry/NotPetya vulnerability)"
    }

    # SMB2/3 protocol
    $smb2 = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB2Protocol -ErrorAction SilentlyContinue

    if ($smb2 -eq $true) {
        Register-Check "SMBv2/v3 protocol" "PASS" "Enabled (recommended)"
    } else {
        Register-Check "SMBv2/v3 protocol" "WARN" "Disabled (enable for better security)"
    }

} catch {
    Register-Check "SMB protocol versions check" "WARN" "Unable to check SMB protocol versions"
}

#==============================================================================
# SECTION 9: SMB SIGNING
#==============================================================================

Write-Section "SMB Signing Configuration"

try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        # Server-side signing required
        if ($smbConfig.RequireSecuritySignature) {
            Register-Check "SMB signing (server)" "PASS" "Required (prevents man-in-the-middle)"
        } elseif ($smbConfig.EnableSecuritySignature) {
            Register-Check "SMB signing (server)" "WARN" "Enabled but not required (enforce it)"
        } else {
            Register-Check "SMB signing (server)" "FAIL" "Not enabled (relay attack risk)"
        }
    }

    # Client-side signing
    $clientSigning = Get-SmbClientConfiguration -ErrorAction SilentlyContinue

    if ($clientSigning) {
        if ($clientSigning.RequireSecuritySignature) {
            Register-Check "SMB signing (client)" "PASS" "Required"
        } elseif ($clientSigning.EnableSecuritySignature) {
            Register-Check "SMB signing (client)" "WARN" "Enabled but not required"
        } else {
            Register-Check "SMB signing (client)" "FAIL" "Not enabled"
        }
    }

} catch {
    Register-Check "SMB signing check" "WARN" "Unable to check SMB signing"
}

#==============================================================================
# SECTION 10: SMB ENCRYPTION
#==============================================================================

Write-Section "SMB Encryption"

try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        # Global encryption setting
        if ($smbConfig.EncryptData) {
            Register-Check "SMB encryption (global)" "PASS" "Enabled (all shares encrypted)"
        } elseif ($smbConfig.RejectUnencryptedAccess) {
            Register-Check "SMB encryption (global)" "PASS" "Rejects unencrypted access"
        } else {
            Register-Check "SMB encryption (global)" "WARN" "Not enforced globally (enable per-share or globally)"
        }
    }

    # Per-share encryption
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
    }

    $encryptedShares = $shares | Where-Object { $_.EncryptData -eq $true }

    if ($encryptedShares) {
        $count = ($encryptedShares | Measure-Object).Count
        Register-Check "Shares with encryption" "PASS" "$count share(s) require encryption"
    } else {
        Register-Check "Shares with encryption" "WARN" "No shares require encryption (consider enabling)"
    }

} catch {
    Register-Check "SMB encryption check" "WARN" "Unable to check SMB encryption"
}

#==============================================================================
# SECTION 11: SHARE ACCESS AUDITING
#==============================================================================

Write-Section "Share Access Auditing"

try {
    # Check audit policy for object access
    $auditPolicy = auditpol /get /subcategory:"File Share" 2>&1

    if ($auditPolicy -match "Success and Failure") {
        Register-Check "File share auditing" "PASS" "Success and Failure auditing enabled"
    } elseif ($auditPolicy -match "Success|Failure") {
        Register-Check "File share auditing" "WARN" "Partial auditing enabled (enable both)"
    } else {
        Register-Check "File share auditing" "FAIL" "Not enabled (enable for forensics)"
    }

    # Check for shares with access-based enumeration
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -notmatch "^(ADMIN\$|C\$|D\$|E\$|IPC\$|print\$)$"
    }

    $abeShares = $shares | Where-Object { $_.FolderEnumerationMode -eq 'AccessBased' }

    if ($abeShares) {
        $count = ($abeShares | Measure-Object).Count
        Register-Check "Access-based enumeration" "PASS" "$count share(s) use ABE (hides unauthorized files)"
    } else {
        Register-Check "Access-based enumeration" "WARN" "No shares use ABE (consider enabling)"
    }

} catch {
    Register-Check "Share access auditing check" "WARN" "Unable to check auditing configuration"
}

#==============================================================================
# SECTION 12: SMB SERVER CONFIGURATION
#==============================================================================

Write-Section "SMB Server Configuration"

try {
    $smbConfig = Get-SmbServerConfiguration -ErrorAction SilentlyContinue

    if ($smbConfig) {
        # Auto-disconnect timeout
        $autoDisconnect = $smbConfig.AutoDisconnectTimeout

        if ($autoDisconnect -le 15) {
            Register-Check "Auto-disconnect timeout" "PASS" "$autoDisconnect minutes (secure)"
        } else {
            Register-Check "Auto-disconnect timeout" "WARN" "$autoDisconnect minutes (consider reducing)"
        }

        # Durable handles
        if ($smbConfig.DurableHandleV2TimeoutInSeconds -le 180) {
            Register-Check "Durable handle timeout" "PASS" "$($smbConfig.DurableHandleV2TimeoutInSeconds) seconds"
        } else {
            Register-Check "Durable handle timeout" "WARN" "$($smbConfig.DurableHandleV2TimeoutInSeconds) seconds (high)"
        }

        # Anonymous access to named pipes and shares
        if ($smbConfig.RestrictNamedpipeAccessViaQuic -eq $true) {
            Register-Check "Named pipe access via QUIC" "PASS" "Restricted"
        }
    }

} catch {
    Register-Check "SMB server config check" "WARN" "Unable to check SMB server configuration"
}

#==============================================================================
# SECTION 13: OPEN SMB SESSIONS
#==============================================================================

Write-Section "Open SMB Sessions"

try {
    $smbSessions = Get-SmbSession -ErrorAction SilentlyContinue

    if ($smbSessions) {
        $sessionCount = ($smbSessions | Measure-Object).Count
        Register-Check "Active SMB sessions" "PASS" "$sessionCount active session(s)"

        # List first 5 sessions
        foreach ($session in $smbSessions | Select-Object -First 5) {
            $client = $session.ClientComputerName
            $user = $session.ClientUserName
            Write-Output "  Session: $user from $client"
        }
    } else {
        Register-Check "Active SMB sessions" "PASS" "No active sessions"
    }

} catch {
    Register-Check "SMB sessions check" "WARN" "Unable to check active sessions"
}

#==============================================================================
# SECTION 14: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
