#Requires -Version 5.1
<#
.SYNOPSIS
    SQL Server Security Audit

.DESCRIPTION
    Comprehensive SQL Server security audit including:
    - SQL Server instance detection and version
    - Authentication mode configuration
    - SQL Server service account security
    - Database encryption (TDE) status
    - SQL Server audit configuration
    - Login security and password policies
    - Database permissions and roles
    - Network protocol configuration
    - SQL Server Agent security
    - Backup and recovery configuration

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges, SQL Server installed
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "SQL Server Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"
Write-Output ""

#==============================================================================
# SECTION 1: SQL SERVER INSTANCE DETECTION
#==============================================================================

Write-Section "SQL Server Instance Detection"

try {
    # Check for SQL Server services
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    if (-not $sqlServices) {
        Write-Output "[SKIP] SQL Server is not installed on this system"
        Print-Summary
        exit 0
    }

    Write-Output "Found $($sqlServices.Count) SQL Server instance(s)"

    foreach ($service in $sqlServices) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "Default" } else { $service.Name -replace "MSSQL\$", "" }

        if ($service.Status -eq 'Running') {
            Register-Check "SQL Server instance: $instanceName" "PASS" "Running"
        } else {
            Register-Check "SQL Server instance: $instanceName" "WARN" "Not running (Status: $($service.Status))"
        }

        # Check service startup type
        if ($service.StartType -eq 'Automatic') {
            Register-Check "SQL Server $instanceName startup" "PASS" "Automatic"
        } else {
            Register-Check "SQL Server $instanceName startup" "WARN" "Not automatic (Type: $($service.StartType))"
        }
    }

    # Get SQL Server version from registry
    $sqlInstancePaths = @(
        "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"
    )

    foreach ($path in $sqlInstancePaths) {
        if (Test-Path $path) {
            $instances = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue

            if ($instances) {
                foreach ($prop in $instances.PSObject.Properties) {
                    if ($prop.Name -notmatch "^PS") {
                        $instanceKey = $prop.Value
                        $setupPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\Setup"

                        if (Test-Path $setupPath) {
                            $setupInfo = Get-ItemProperty -Path $setupPath -ErrorAction SilentlyContinue
                            $version = $setupInfo.Version
                            $edition = $setupInfo.Edition

                            if ($version) {
                                $majorVersion = [int]($version.Split('.')[0])

                                # SQL Server 2019 = 15.x, 2017 = 14.x, 2016 = 13.x, 2014 = 12.x
                                if ($majorVersion -ge 15) {
                                    Register-Check "SQL Server $($prop.Name) version" "PASS" "$version ($edition, current)"
                                } elseif ($majorVersion -ge 13) {
                                    Register-Check "SQL Server $($prop.Name) version" "WARN" "$version ($edition, consider upgrade)"
                                } else {
                                    Register-Check "SQL Server $($prop.Name) version" "FAIL" "$version ($edition, outdated)"
                                }
                            }
                        }
                    }
                }
            }
        }
    }

} catch {
    Register-Check "SQL Server detection" "WARN" "Unable to detect SQL Server: $($_.Exception.Message)"
    Print-Summary
    exit 0
}

#==============================================================================
# SECTION 2: SQL SERVER AUTHENTICATION MODE
#==============================================================================

Write-Section "SQL Server Authentication Mode"

try {
    # Check authentication mode from registry
    $sqlInstances = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlInstances) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get instance registry path
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $authPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\MSSQLServer"

                if (Test-Path $authPath) {
                    $loginMode = (Get-ItemProperty -Path $authPath -Name "LoginMode" -ErrorAction SilentlyContinue).LoginMode

                    # LoginMode: 1 = Windows Authentication, 2 = Mixed Mode
                    if ($loginMode -eq 1) {
                        Register-Check "SQL Server $instanceName auth mode" "PASS" "Windows Authentication (most secure)"
                    } elseif ($loginMode -eq 2) {
                        Register-Check "SQL Server $instanceName auth mode" "WARN" "Mixed Mode (SQL + Windows, review necessity)"
                    } else {
                        Register-Check "SQL Server $instanceName auth mode" "WARN" "Unable to determine authentication mode"
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Authentication mode check" "WARN" "Unable to check authentication mode"
}

#==============================================================================
# SECTION 3: SQL SERVER SERVICE ACCOUNT
#==============================================================================

Write-Section "SQL Server Service Account"

try {
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlServices) {
        $serviceName = $service.Name
        $instanceName = if ($serviceName -eq "MSSQLSERVER") { "Default" } else { $serviceName -replace "MSSQL\$", "" }

        # Get service account
        $serviceAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='$serviceName'").StartName

        if ($serviceAccount) {
            if ($serviceAccount -match "LocalSystem") {
                Register-Check "SQL Server $instanceName service account" "FAIL" "LocalSystem (excessive privileges)"
            } elseif ($serviceAccount -match "NetworkService|LocalService") {
                Register-Check "SQL Server $instanceName service account" "WARN" "$serviceAccount (consider dedicated service account)"
            } elseif ($serviceAccount -match "NT Service\\") {
                Register-Check "SQL Server $instanceName service account" "PASS" "Virtual service account (secure)"
            } else {
                Register-Check "SQL Server $instanceName service account" "PASS" "Custom account: $serviceAccount"
            }
        }
    }

    # Check SQL Server Agent service
    $agentServices = Get-Service | Where-Object {
        $_.Name -match "^SQLAgent\$" -or $_.Name -eq "SQLSERVERAGENT"
    }

    foreach ($agentService in $agentServices) {
        $instanceName = if ($agentService.Name -eq "SQLSERVERAGENT") { "Default" } else { $agentService.Name -replace "SQLAgent\$", "" }

        if ($agentService.Status -eq 'Running') {
            Register-Check "SQL Agent $instanceName" "PASS" "Running"
        } else {
            Register-Check "SQL Agent $instanceName" "WARN" "Not running (jobs won't execute)"
        }

        # Check Agent service account
        $agentAccount = (Get-CimInstance -ClassName Win32_Service -Filter "Name='$($agentService.Name)'").StartName

        if ($agentAccount -match "LocalSystem") {
            Register-Check "SQL Agent $instanceName account" "FAIL" "LocalSystem (excessive privileges)"
        } elseif ($agentAccount -match "NT Service\\") {
            Register-Check "SQL Agent $instanceName account" "PASS" "Virtual service account"
        }
    }

} catch {
    Register-Check "Service account check" "WARN" "Unable to check service accounts"
}

#==============================================================================
# SECTION 4: SQL SERVER NETWORK PROTOCOLS
#==============================================================================

Write-Section "SQL Server Network Protocols"

try {
    # Check for SQL Server Configuration Manager registry paths
    $sqlInstances = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlInstances) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get instance registry key
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $protocolsPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\MSSQLServer\SuperSocketNetLib"

                if (Test-Path $protocolsPath) {
                    # Check TCP/IP protocol
                    $tcpPath = Join-Path $protocolsPath "Tcp"

                    if (Test-Path $tcpPath) {
                        $tcpEnabled = (Get-ItemProperty -Path $tcpPath -Name "Enabled" -ErrorAction SilentlyContinue).Enabled

                        if ($tcpEnabled -eq 1) {
                            Register-Check "SQL Server $instanceName TCP/IP" "PASS" "Enabled"
                        } else {
                            Register-Check "SQL Server $instanceName TCP/IP" "WARN" "Disabled (remote connections not possible)"
                        }
                    }

                    # Check Named Pipes protocol
                    $npPath = Join-Path $protocolsPath "Np"

                    if (Test-Path $npPath) {
                        $npEnabled = (Get-ItemProperty -Path $npPath -Name "Enabled" -ErrorAction SilentlyContinue).Enabled

                        if ($npEnabled -eq 1) {
                            Register-Check "SQL Server $instanceName Named Pipes" "WARN" "Enabled (disable if not needed)"
                        } else {
                            Register-Check "SQL Server $instanceName Named Pipes" "PASS" "Disabled"
                        }
                    }

                    # Check Shared Memory protocol (local only)
                    $smPath = Join-Path $protocolsPath "Sm"

                    if (Test-Path $smPath) {
                        $smEnabled = (Get-ItemProperty -Path $smPath -Name "Enabled" -ErrorAction SilentlyContinue).Enabled

                        if ($smEnabled -eq 1) {
                            Register-Check "SQL Server $instanceName Shared Memory" "PASS" "Enabled (local connections)"
                        }
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Network protocols check" "WARN" "Unable to check network protocols"
}

#==============================================================================
# SECTION 5: SQL SERVER PORT CONFIGURATION
#==============================================================================

Write-Section "SQL Server Port Configuration"

try {
    $sqlInstances = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlInstances) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get instance registry path
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $tcpIpPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\MSSQLServer\SuperSocketNetLib\Tcp\IPAll"

                if (Test-Path $tcpIpPath) {
                    $tcpPort = (Get-ItemProperty -Path $tcpIpPath -Name "TcpPort" -ErrorAction SilentlyContinue).TcpPort
                    $dynamicPorts = (Get-ItemProperty -Path $tcpIpPath -Name "TcpDynamicPorts" -ErrorAction SilentlyContinue).TcpDynamicPorts

                    if ($tcpPort) {
                        if ($tcpPort -eq "1433") {
                            Register-Check "SQL Server $instanceName port" "WARN" "Default port 1433 (consider non-standard port)"
                        } else {
                            Register-Check "SQL Server $instanceName port" "PASS" "Custom port $tcpPort (security by obscurity)"
                        }
                    } elseif ($dynamicPorts) {
                        Register-Check "SQL Server $instanceName port" "WARN" "Dynamic port $dynamicPorts (use static port)"
                    } else {
                        Register-Check "SQL Server $instanceName port" "WARN" "No port configured"
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Port configuration check" "WARN" "Unable to check port configuration"
}

#==============================================================================
# SECTION 6: SQL SERVER BROWSER SERVICE
#==============================================================================

Write-Section "SQL Server Browser Service"

try {
    # Check SQL Server Browser service
    $browserService = Get-Service -Name "SQLBrowser" -ErrorAction SilentlyContinue

    if ($browserService) {
        if ($browserService.Status -eq 'Running') {
            Register-Check "SQL Browser service" "WARN" "Running (exposes instance information, disable if not needed)"
        } else {
            Register-Check "SQL Browser service" "PASS" "Installed but not running"
        }

        if ($browserService.StartType -eq 'Disabled') {
            Register-Check "SQL Browser startup" "PASS" "Disabled"
        } else {
            Register-Check "SQL Browser startup" "WARN" "Not disabled (consider disabling)"
        }
    } else {
        Register-Check "SQL Browser service" "PASS" "Not installed"
    }

} catch {
    Register-Check "Browser service check" "WARN" "Unable to check Browser service"
}

#==============================================================================
# SECTION 7: SQL SERVER ENCRYPTION STATUS
#==============================================================================

Write-Section "SQL Server Encryption Status"

try {
    # Note: This check requires SQL Server PowerShell module or direct SQL queries
    # For this audit, we'll check for TDE-related registry indicators

    Write-Output "Note: Full TDE status requires SQL query access"

    # Check if SQL Server supports encryption (version check)
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    if ($sqlServices) {
        Register-Check "SQL Server encryption support" "PASS" "SQL Server installed (TDE available in Enterprise/Developer editions)"
    }

    # Check for certificate store access (required for TDE)
    $certStore = Get-ChildItem -Path "Cert:\LocalMachine\My" -ErrorAction SilentlyContinue

    if ($certStore) {
        $sqlCerts = $certStore | Where-Object { $_.Subject -match "SQL Server" }

        if ($sqlCerts) {
            Register-Check "SQL Server certificates" "PASS" "$($sqlCerts.Count) SQL-related certificate(s) found"
        } else {
            Register-Check "SQL Server certificates" "WARN" "No SQL Server certificates found (TDE may not be configured)"
        }
    }

} catch {
    Register-Check "Encryption check" "WARN" "Unable to check encryption status"
}

#==============================================================================
# SECTION 8: SQL SERVER AUDIT CONFIGURATION
#==============================================================================

Write-Section "SQL Server Audit Configuration"

try {
    # Check for SQL Server audit logs directory
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlServices) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get instance data path
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $setupPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\Setup"

                if (Test-Path $setupPath) {
                    $dataPath = (Get-ItemProperty -Path $setupPath -Name "SQLDataRoot" -ErrorAction SilentlyContinue).SQLDataRoot

                    if ($dataPath) {
                        # Check for audit directory
                        $auditPath = Join-Path $dataPath "Audit"

                        if (Test-Path $auditPath) {
                            $auditFiles = Get-ChildItem -Path $auditPath -Filter "*.sqlaudit" -ErrorAction SilentlyContinue

                            if ($auditFiles) {
                                Register-Check "SQL Server $instanceName auditing" "PASS" "Audit files found ($(($auditFiles | Measure-Object).Count) files)"
                            } else {
                                Register-Check "SQL Server $instanceName auditing" "WARN" "Audit directory exists but no audit files"
                            }
                        } else {
                            Register-Check "SQL Server $instanceName auditing" "WARN" "No audit directory found (auditing may not be configured)"
                        }
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Audit configuration check" "WARN" "Unable to check audit configuration"
}

#==============================================================================
# SECTION 9: SQL SERVER BACKUP CONFIGURATION
#==============================================================================

Write-Section "SQL Server Backup Configuration"

try {
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlServices) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get backup directory
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $setupPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\MSSQLServer"

                if (Test-Path $setupPath) {
                    $backupPath = (Get-ItemProperty -Path $setupPath -Name "BackupDirectory" -ErrorAction SilentlyContinue).BackupDirectory

                    if ($backupPath) {
                        if (Test-Path $backupPath) {
                            # Check for recent backup files
                            $backupFiles = Get-ChildItem -Path $backupPath -Filter "*.bak" -ErrorAction SilentlyContinue

                            if ($backupFiles) {
                                $recentBackups = $backupFiles | Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) }

                                if ($recentBackups) {
                                    Register-Check "SQL Server $instanceName backups" "PASS" "Recent backup files found ($(($recentBackups | Measure-Object).Count) in last 7 days)"
                                } else {
                                    Register-Check "SQL Server $instanceName backups" "WARN" "No recent backups (last 7 days)"
                                }
                            } else {
                                Register-Check "SQL Server $instanceName backups" "WARN" "No backup files found in backup directory"
                            }

                            Register-Check "SQL Server $instanceName backup directory" "PASS" "Configured: $backupPath"
                        } else {
                            Register-Check "SQL Server $instanceName backup directory" "WARN" "Directory not found: $backupPath"
                        }
                    } else {
                        Register-Check "SQL Server $instanceName backup directory" "WARN" "No backup directory configured"
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Backup configuration check" "WARN" "Unable to check backup configuration"
}

#==============================================================================
# SECTION 10: SQL SERVER ERROR LOG CONFIGURATION
#==============================================================================

Write-Section "SQL Server Error Log Configuration"

try {
    $sqlServices = Get-Service | Where-Object {
        $_.Name -match "^MSSQL\$" -or $_.Name -eq "MSSQLSERVER"
    }

    foreach ($service in $sqlServices) {
        $instanceName = if ($service.Name -eq "MSSQLSERVER") { "MSSQLSERVER" } else { $service.Name -replace "MSSQL\$", "" }

        # Get error log path
        $instanceRegPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL"

        if (Test-Path $instanceRegPath) {
            $instanceKey = (Get-ItemProperty -Path $instanceRegPath -Name $instanceName -ErrorAction SilentlyContinue).$instanceName

            if ($instanceKey) {
                $setupPath = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceKey\Setup"

                if (Test-Path $setupPath) {
                    $dataPath = (Get-ItemProperty -Path $setupPath -Name "SQLDataRoot" -ErrorAction SilentlyContinue).SQLDataRoot

                    if ($dataPath) {
                        $errorLogPath = Join-Path (Join-Path $dataPath "Log") "ERRORLOG"

                        if (Test-Path $errorLogPath) {
                            $errorLog = Get-Item $errorLogPath
                            $sizeMB = [math]::Round($errorLog.Length / 1MB, 2)
                            $lastModified = $errorLog.LastWriteTime

                            Register-Check "SQL Server $instanceName error log" "PASS" "Exists ($sizeMB MB, last modified: $($lastModified.ToString('yyyy-MM-dd HH:mm')))"

                            # Check log size
                            if ($sizeMB -gt 100) {
                                Register-Check "SQL Server $instanceName error log size" "WARN" "$sizeMB MB (large, consider archiving)"
                            }
                        } else {
                            Register-Check "SQL Server $instanceName error log" "WARN" "Error log not found at expected location"
                        }
                    }
                }
            }
        }
    }

} catch {
    Register-Check "Error log check" "WARN" "Unable to check error log configuration"
}

#==============================================================================
# SECTION 11: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
