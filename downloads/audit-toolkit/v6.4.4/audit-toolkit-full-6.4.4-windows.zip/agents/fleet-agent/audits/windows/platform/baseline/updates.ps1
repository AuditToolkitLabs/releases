#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Updates Security Audit

.DESCRIPTION
    Audits Windows Update status including:
    - Pending updates count
    - Last update installation time
    - Windows Update service status
    - Automatic update configuration
    - Update history

.NOTES
    Equivalent to: audits/platform/baseline/updates.sh (Linux version)
    Author: Multi-Server Audit Dashboard Team
    Version: 1.0.0
    Created: February 2026

.EXAMPLE
    .\updates.ps1
    Runs the Windows updates audit and outputs results in standard format.
#>

# Strict mode
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Source common library (equivalent to Bash lib/common.sh)
. "$PSScriptRoot\..\..\..\lib\common.ps1"

# Main audit execution
try {
    Write-Section "Windows Updates Audit"

    # Check 1: Administrator privileges required
    if (Test-IsAdminMode) {
        Register-Check "Administrator Mode" "PASS" "Running with admin privileges"
    } else {
        Register-Check "Administrator Mode" "FAIL" "Admin rights required for full audit"
        Print-Summary
        exit $script:ExitCode
    }

    # Check 2: Windows Update service status
    $wuauservService = Get-Service -Name wuauserv -ErrorAction SilentlyContinue
    if ($wuauservService) {
        if ($wuauservService.Status -eq 'Running') {
            Register-Check "Windows Update Service" "PASS" "Service is running"
        } else {
            Register-Check "Windows Update Service" "WARN" "Service is $($wuauservService.Status)"
        }
    } else {
        Register-Check "Windows Update Service" "FAIL" "Service not found"
    }

    # Check 3: Pending updates count
    $updateCount = Get-PendingUpdateCount
    if ($updateCount -eq -1) {
        Register-Check "Pending Updates" "WARN" "Unable to query Windows Update"
    }
    elseif ($updateCount -eq 0) {
        Register-Check "Pending Updates" "PASS" "No updates pending"
    }
    elseif ($updateCount -le 5) {
        Register-Check "Pending Updates" "WARN" "$updateCount updates available"
    }
    else {
        Register-Check "Pending Updates" "FAIL" "$updateCount updates available (high count)"
    }

    # Check 4: Automatic updates configuration
    try {
        $auKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'

        if (Test-Path $auKey) {
            $noAutoUpdate = (Get-ItemProperty $auKey -Name NoAutoUpdate -ErrorAction SilentlyContinue).NoAutoUpdate

            if ($noAutoUpdate -eq 0 -or $null -eq $noAutoUpdate) {
                Register-Check "Automatic Updates" "PASS" "Enabled via Group Policy"
            } else {
                Register-Check "Automatic Updates" "WARN" "Disabled via Group Policy"
            }
        } else {
            # Check default location
            $wuKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update'
            if (Test-Path $wuKey) {
                Register-Check "Automatic Updates" "PASS" "Using default settings"
            } else {
                Register-Check "Automatic Updates" "SKIP" "Cannot determine configuration"
            }
        }
    }
    catch {
        Register-Check "Automatic Updates" "SKIP" "Unable to query registry"
    }

    # Check 5: Last successful update
    try {
        $session = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $historyCount = $searcher.GetTotalHistoryCount()

        if ($historyCount -gt 0) {
            $history = $searcher.QueryHistory(0, 1) | Select-Object -First 1
            $lastUpdate = $history.Date
            $daysSinceUpdate = (Get-Date) - $lastUpdate

            if ($daysSinceUpdate.Days -le 7) {
                Register-Check "Last Update" "PASS" "Updated $($daysSinceUpdate.Days) days ago"
            }
            elseif ($daysSinceUpdate.Days -le 30) {
                Register-Check "Last Update" "WARN" "Updated $($daysSinceUpdate.Days) days ago"
            }
            else {
                Register-Check "Last Update" "FAIL" "Updated $($daysSinceUpdate.Days) days ago (outdated)"
            }
        } else {
            Register-Check "Last Update" "WARN" "No update history found"
        }
    }
    catch {
        Register-Check "Last Update" "SKIP" "Unable to query update history"
    }

    # Check 6: Windows version (end-of-life check)
    $version = Get-WindowsVersion
    $build = [int]$version.Build

    # Known end-of-life builds
    $eolBuilds = @{
        7601  = 'Windows 7 (EOL Jan 2020)'
        9200  = 'Windows Server 2012 (EOL Oct 2023)'
        9600  = 'Windows 8.1/Server 2012 R2 (EOL Jan 2023)'
        10240 = 'Windows 10 1507 (EOL May 2017)'
        10586 = 'Windows 10 1511 (EOL Oct 2017)'
    }

    if ($eolBuilds.ContainsKey($build)) {
        Register-Check "Windows Version" "FAIL" "$($eolBuilds[$build]) - End of Life"
    }
    elseif ($build -ge 17763) {
        Register-Check "Windows Version" "PASS" "$($version.Caption) Build $build (Supported)"
    }
    else {
        Register-Check "Windows Version" "WARN" "Build $build may be nearing end-of-life"
    }

    # Check 7: WSUS server configuration (enterprise environments)
    if (Test-IsDomainJoined) {
        try {
            $wsusKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
            if (Test-Path $wsusKey) {
                $wsusServer = (Get-ItemProperty $wsusKey -Name WUServer -ErrorAction SilentlyContinue).WUServer

                if ($wsusServer) {
                    Register-Check "WSUS Configuration" "PASS" "Configured: $wsusServer"
                } else {
                    Register-Check "WSUS Configuration" "SKIP" "Not configured (using Windows Update)"
                }
            } else {
                Register-Check "WSUS Configuration" "SKIP" "Not configured"
            }
        }
        catch {
            Register-Check "WSUS Configuration" "SKIP" "Unable to query"
        }
    } else {
        Register-Check "WSUS Configuration" "SKIP" "Not domain-joined"
    }

    # Check 8: Delivery Optimization (P2P updates)
    try {
        $doKey = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'
        if (Test-Path $doKey) {
            $doMode = (Get-ItemProperty $doKey -Name DODownloadMode -ErrorAction SilentlyContinue).DODownloadMode

            # DODownloadMode values:
            # 0 = HTTP only, 1 = LAN, 2 = LAN + Internet, 3 = LAN + Internet + Peering
            if ($null -ne $doMode) {
                if ($doMode -eq 0) {
                    Register-Check "Delivery Optimization" "PASS" "Disabled (HTTP only)"
                } else {
                    Register-Check "Delivery Optimization" "PASS" "Configured (Mode: $doMode)"
                }
            } else {
                Register-Check "Delivery Optimization" "SKIP" "Using default settings"
            }
        } else {
            Register-Check "Delivery Optimization" "SKIP" "Policy not configured"
        }
    }
    catch {
        Register-Check "Delivery Optimization" "SKIP" "Unable to query"
    }

    # Print final summary
    Print-Summary

    # Exit with appropriate code (0=PASS, 1=WARN, 2=FAIL)
    exit $script:ExitCode
}
catch {
    Write-Output ""
    Write-Output "ERROR: Audit failed with exception"
    Write-Output "Message: $($_.Exception.Message)"
    Write-Output "Line: $($_.InvocationInfo.ScriptLineNumber)"
    Write-Output ""

    # Exit with FAIL code on exception
    exit 2
}
