#Requires -Version 5.1
<#
.SYNOPSIS
    Windows User and Group Security Audit

.DESCRIPTION
    Comprehensive security audit of local user accounts and groups including:
    - Administrator account security
    - Guest account status
    - Password policies
    - Inactive and locked accounts
    - Group membership (especially Administrators)
    - User rights assignments
    - Account lockout policies
    - Domain vs. local account configuration

.NOTES
    Author: Security Audit Toolkit
    Version: 1.0
    Requires: Administrator privileges
    OS: Windows Server 2016+, Windows 10+
#>

#Requires -RunAsAdministrator

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# Source common functions
. "$PSScriptRoot\..\..\..\..\lib\common.ps1"

# Initialize audit
Write-Section "Windows User and Group Security Audit"

# Verify prerequisites
if (-not (Test-IsAdminMode)) {
    Write-Output "[SKIP] This audit requires Administrator privileges"
    exit 0
}

# Get OS version information
$osInfo = Get-WindowsVersion
Write-Output "OS: $($osInfo.ProductName) (Build $($osInfo.Build))"
Write-Output "Server OS: $(Test-IsServerOS)"

$domainInfo = Get-DomainInfo
if ($domainInfo.IsDomainJoined) {
    Write-Output "Domain: $($domainInfo.DomainName)"
}
Write-Output ""

#==============================================================================
# SECTION 1: ADMINISTRATOR ACCOUNT SECURITY
#==============================================================================

Write-Section "Administrator Account Security"

# Check built-in Administrator account
try {
    $adminAccount = Get-LocalUser -Name "Administrator" -ErrorAction Stop

    # Check if Administrator account is disabled (best practice)
    if ($adminAccount.Enabled -eq $false) {
        Register-Check "Built-in Administrator account" "PASS" "Disabled (best practice)"
    } else {
        Register-Check "Built-in Administrator account" "FAIL" "Enabled (should be disabled)"
    }

    # Check if Administrator account is renamed
    $adminSID = "S-1-5-21-*-500"
    $actualAdmin = Get-LocalUser | Where-Object { $_.SID -like $adminSID }

    if ($actualAdmin.Name -ne "Administrator") {
        Register-Check "Administrator account renamed" "PASS" "Renamed to '$($actualAdmin.Name)'"
    } else {
        Register-Check "Administrator account renamed" "WARN" "Still named 'Administrator' (consider renaming)"
    }

    # Check password age
    if ($adminAccount.Enabled) {
        $passwordAge = (Get-Date) - $adminAccount.PasswordLastSet

        if ($passwordAge.Days -le 90) {
            Register-Check "Administrator password age" "PASS" "$($passwordAge.Days) days old"
        } elseif ($passwordAge.Days -le 180) {



            Register-Check "Administrator password age" "WARN" "$($passwordAge.Days) days old (consider rotating)"
        } else {
            Register-Check "Administrator password age" "FAIL" "$($passwordAge.Days) days old (must rotate)"
        }
    }

} catch {
    Register-Check "Administrator account check" "WARN" "Unable to check Administrator account"
}

#==============================================================================
# SECTION 2: GUEST ACCOUNT STATUS
#==============================================================================

Write-Section "Guest Account Status"

try {
    $guestAccount = Get-LocalUser -Name "Guest" -ErrorAction Stop

    if ($guestAccount.Enabled -eq $false) {
        Register-Check "Guest account" "PASS" "Disabled"
    } else {
        Register-Check "Guest account" "FAIL" "Enabled (major security risk)"
    }

} catch {
    Register-Check "Guest account" "PASS" "Not found or already removed"
}

#==============================================================================
# SECTION 3: LOCAL USER ACCOUNTS
#==============================================================================

Write-Section "Local User Accounts"

try {
    $localUsers = Get-LocalUser
    $enabledUsers = $localUsers | Where-Object { $_.Enabled -eq $true }

    # Count enabled accounts
    Register-Check "Total local users" "PASS" "$($localUsers.Count) total, $($enabledUsers.Count) enabled"

    # Check for accounts without passwords
    $noPasswordUsers = $localUsers | Where-Object { $_.PasswordRequired -eq $false -and $_.Enabled -eq $true }

    if ($noPasswordUsers.Count -eq 0) {
        Register-Check "Users without passwords" "PASS" "All enabled users require passwords"
    } else {
        $userList = ($noPasswordUsers | Select-Object -First 3 -ExpandProperty Name) -join ', '
        Register-Check "Users without passwords" "FAIL" "$($noPasswordUsers.Count) users without passwords: $userList"
    }

    # Check for users with passwords that never expire
    $noExpireUsers = $localUsers | Where-Object { $_.PasswordNeverExpires -eq $true -and $_.Enabled -eq $true -and $_.Name -ne "DefaultAccount" }

    if ($noExpireUsers.Count -eq 0) {
        Register-Check "Passwords that never expire" "PASS" "All user passwords can expire"
    } elseif ($noExpireUsers.Count -le 2) {
        $userList = ($noExpireUsers | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Passwords that never expire" "WARN" "$($noExpireUsers.Count) users: $userList (review if appropriate)"
    } else {
        $userList = ($noExpireUsers | Select-Object -First 3 -ExpandProperty Name) -join ', '
        Register-Check "Passwords that never expire" "FAIL" "$($noExpireUsers.Count) users: $userList..."
    }

    # Check for accounts that haven't changed password in 180+ days
    $stalePasswordUsers = $localUsers | Where-Object {
        $_.Enabled -eq $true -and
        $_.PasswordLastSet -ne $null -and
        ((Get-Date) - $_.PasswordLastSet).Days -gt 180
    }

    if ($stalePasswordUsers.Count -eq 0) {
        Register-Check "Stale passwords (180+ days)" "PASS" "No accounts with very old passwords"
    } else {
        $userList = ($stalePasswordUsers | Select-Object -First 3 -ExpandProperty Name) -join ', '
        Register-Check "Stale passwords (180+ days)" "WARN" "$($stalePasswordUsers.Count) users need password rotation: $userList"
    }

    # Check for accounts that have never logged on
    $neverLoggedOn = $localUsers | Where-Object { $_.Enabled -eq $true -and $_.LastLogon -eq $null }

    if ($neverLoggedOn.Count -eq 0) {
        Register-Check "Accounts never used" "PASS" "All enabled accounts have been used"
    } elseif ($neverLoggedOn.Count -le 2) {
        $userList = ($neverLoggedOn | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Accounts never used" "WARN" "$($neverLoggedOn.Count) accounts never logged on: $userList"
    } else {
        $userList = ($neverLoggedOn | Select-Object -First 3 -ExpandProperty Name) -join ', '
        Register-Check "Accounts never used" "FAIL" "$($neverLoggedOn.Count) unused accounts: $userList (consider disabling)"
    }

} catch {
    Register-Check "Local users check" "WARN" "Unable to enumerate local users"
}

#==============================================================================
# SECTION 4: ADMINISTRATORS GROUP
#==============================================================================

Write-Section "Administrators Group Membership"

try {
    $adminsGroup = Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop
    $adminCount = $adminsGroup.Count

    # Check number of administrators (should be minimal)
    if ($adminCount -eq 1) {
        Register-Check "Administrator count" "PASS" "1 administrator (optimal)"
    } elseif ($adminCount -le 3) {
        Register-Check "Administrator count" "PASS" "$adminCount administrators (acceptable)"
    } elseif ($adminCount -le 5) {
        Register-Check "Administrator count" "WARN" "$adminCount administrators (review if all needed)"
    } else {
        Register-Check "Administrator count" "FAIL" "$adminCount administrators (excessive, review required)"
    }

    # List administrator accounts
    $adminNames = $adminsGroup | ForEach-Object {
        if ($_.ObjectClass -eq 'User') {
            $_.Name
        } elseif ($_.ObjectClass -eq 'Group') {
            "$($_.Name) (Group)"
        }
    }

    Write-Output "  Administrators: $($adminNames -join ', ')"

    # Check for domain admins in local admin group (if domain-joined)
    if ($domainInfo.IsDomainJoined) {
        $domainAdmins = $adminsGroup | Where-Object { $_.PrincipalSource -eq 'ActiveDirectory' -and $_.Name -like "*Domain Admins*" }

        if ($domainAdmins) {
            Register-Check "Domain Admins in local Admins" "WARN" "Domain Admins group is local admin (standard but review)"
        }
    }

} catch {
    Register-Check "Administrators group" "WARN" "Unable to enumerate Administrators group"
}

#==============================================================================
# SECTION 5: REMOTE DESKTOP USERS GROUP
#==============================================================================

Write-Section "Remote Desktop Users Group"

try {
    $rdpUsers = Get-LocalGroupMember -Group "Remote Desktop Users" -ErrorAction Stop

    if ($rdpUsers.Count -eq 0) {
        Register-Check "Remote Desktop Users" "PASS" "No users in RDP group (RDP disabled or admins-only)"
    } elseif ($rdpUsers.Count -le 5) {
        $userList = ($rdpUsers | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Remote Desktop Users" "PASS" "$($rdpUsers.Count) users: $userList"
    } else {
        $userList = ($rdpUsers | Select-Object -First 5 -ExpandProperty Name) -join ', '
        Register-Check "Remote Desktop Users" "WARN" "$($rdpUsers.Count) users (review if all need RDP): $userList..."
    }

} catch {
    Register-Check "Remote Desktop Users" "PASS" "Group not found or no members"
}

#==============================================================================
# SECTION 6: OTHER PRIVILEGED GROUPS
#==============================================================================

Write-Section "Other Privileged Groups"

# Check Backup Operators group
try {
    $backupOps = Get-LocalGroupMember -Group "Backup Operators" -ErrorAction Stop

    if ($backupOps.Count -eq 0) {
        Register-Check "Backup Operators group" "PASS" "Empty (no special backup privileges)"
    } else {
        $userList = ($backupOps | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Backup Operators group" "WARN" "$($backupOps.Count) members: $userList (review if appropriate)"
    }
} catch {
    Register-Check "Backup Operators group" "PASS" "Empty or not configured"
}

# Check Power Users group (legacy, should not be used)
try {
    $powerUsers = Get-LocalGroupMember -Group "Power Users" -ErrorAction Stop

    if ($powerUsers.Count -eq 0) {
        Register-Check "Power Users group" "PASS" "Empty (legacy group, should not be used)"
    } else {
        $userList = ($powerUsers | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Power Users group" "WARN" "$($powerUsers.Count) members in legacy group: $userList"
    }
} catch {
    Register-Check "Power Users group" "PASS" "Empty or not configured"
}

# Check Replicator group
try {
    $replicators = Get-LocalGroupMember -Group "Replicator" -ErrorAction Stop

    if ($replicators.Count -eq 0) {
        Register-Check "Replicator group" "PASS" "Empty"
    } else {
        Register-Check "Replicator group" "WARN" "$($replicators.Count) members (review if appropriate)"
    }
} catch {
    Register-Check "Replicator group" "PASS" "Empty or not configured"
}

#==============================================================================
# SECTION 7: PASSWORD POLICY
#==============================================================================

Write-Section "Password Policy"

try {
    # Get password policy via net accounts
    $netAccounts = net accounts

    # Parse minimum password length
    $minLength = ($netAccounts | Select-String "Minimum password length").ToString() -replace '.*:\s*', ''
    $minLengthValue = [int]$minLength

    if ($minLengthValue -ge 14) {
        Register-Check "Minimum password length" "PASS" "$minLength characters"
    } elseif ($minLengthValue -ge 8) {
        Register-Check "Minimum password length" "WARN" "$minLength characters (14+ recommended)"
    } else {
        Register-Check "Minimum password length" "FAIL" "$minLength characters (too short, use 14+)"
    }

    # Parse maximum password age
    $maxAge = ($netAccounts | Select-String "Maximum password age").ToString() -replace '.*:\s*', ''

    if ($maxAge -match "Unlimited") {
        Register-Check "Maximum password age" "FAIL" "Unlimited (passwords never expire)"
    } elseif ($maxAge -match "(\d+)") {
        $days = [int]$matches[1]
        if ($days -le 90) {
            Register-Check "Maximum password age" "PASS" "$days days"
        } elseif ($days -le 180) {
            Register-Check "Maximum password age" "WARN" "$days days (90 recommended)"
        } else {
            Register-Check "Maximum password age" "FAIL" "$days days (too long)"
        }
    }

    # Parse minimum password age
    $minAge = ($netAccounts | Select-String "Minimum password age").ToString() -replace '.*:\s*', ''

    if ($minAge -match "(\d+)") {
        $days = [int]$matches[1]
        if ($days -ge 1) {
            Register-Check "Minimum password age" "PASS" "$days days (prevents rapid changes)"
        } else {
            Register-Check "Minimum password age" "WARN" "$days days (consider setting to 1+)"
        }
    }

    # Parse password history
    $history = ($netAccounts | Select-String "Length of password history maintained").ToString() -replace '.*:\s*', ''

    if ($history -match "(\d+)") {
        $count = [int]$matches[1]
        if ($count -ge 24) {
            Register-Check "Password history" "PASS" "$count passwords remembered"
        } elseif ($count -ge 12) {
            Register-Check "Password history" "WARN" "$count passwords (24 recommended)"
        } else {
            Register-Check "Password history" "FAIL" "$count passwords (too few, use 24)"
        }
    }

} catch {
    Register-Check "Password policy" "WARN" "Unable to check password policy"
}

#==============================================================================
# SECTION 8: ACCOUNT LOCKOUT POLICY
#==============================================================================

Write-Section "Account Lockout Policy"

try {
    $netAccounts = net accounts

    # Parse lockout threshold
    $lockoutLine = ($netAccounts | Select-String "Lockout threshold").ToString()

    if ($lockoutLine -match "Never") {
        Register-Check "Account lockout threshold" "FAIL" "Never (no protection against brute force)"
    } elseif ($lockoutLine -match "(\d+)") {
        $threshold = [int]$matches[1]
        if ($threshold -le 5) {
            Register-Check "Account lockout threshold" "PASS" "$threshold invalid attempts"
        } elseif ($threshold -le 10) {
            Register-Check "Account lockout threshold" "WARN" "$threshold attempts (5 or less recommended)"
        } else {
            Register-Check "Account lockout threshold" "FAIL" "$threshold attempts (too high, use 5 or less)"
        }
    }

    # Parse lockout duration
    $durationLine = ($netAccounts | Select-String "Lockout duration").ToString()

    if ($durationLine -match "(\d+)") {
        $minutes = [int]$matches[1]
        if ($minutes -ge 15) {
            Register-Check "Lockout duration" "PASS" "$minutes minutes"
        } else {
            Register-Check "Lockout duration" "WARN" "$minutes minutes (15+ recommended)"
        }
    }

} catch {
    Register-Check "Account lockout policy" "WARN" "Unable to check lockout policy"
}

#==============================================================================
# SECTION 9: LOCKED AND DISABLED ACCOUNTS
#==============================================================================

Write-Section "Locked and Disabled Accounts"

try {
    $lockedUsers = Get-LocalUser | Where-Object { $_.LockoutTime -ne $null -and $_.LockoutTime -gt (Get-Date).AddDays(-30) }

    if ($lockedUsers.Count -eq 0) {
        Register-Check "Locked accounts (last 30 days)" "PASS" "No recently locked accounts"
    } else {
        $userList = ($lockedUsers | Select-Object -ExpandProperty Name) -join ', '
        Register-Check "Locked accounts (last 30 days)" "WARN" "$($lockedUsers.Count) accounts locked: $userList (investigate)"
    }

    $disabledUsers = Get-LocalUser | Where-Object { $_.Enabled -eq $false }
    Register-Check "Disabled accounts" "PASS" "$($disabledUsers.Count) accounts disabled"

} catch {
    Register-Check "Locked accounts check" "WARN" "Unable to check locked accounts"
}

#==============================================================================
# SECTION 10: SUMMARY
#==============================================================================

Print-Summary

# Set exit code based on results
if ($script:FailedChecks -gt 0) {
    exit 2  # FAIL
} elseif ($script:WarnedChecks -gt 0) {
    exit 1  # WARN
} else {
    exit 0  # PASS
}
