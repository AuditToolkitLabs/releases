# Windows Server-Only Audit Scripts

This folder contains PowerShell audit scripts for Windows settings that apply only to server roles, as per CIS and the provided checklist.

## Scripts to implement (examples):
- active_directory.ps1
- file_server.ps1
- hyperv.ps1
- iis_hardening.ps1

These scripts check for domain controller hardening, file server ACLs, Hyper-V security, and IIS configuration. See each script for details.