<#
.SYNOPSIS
    Active Directory Domain Controller Security Audit

.DESCRIPTION
    Comprehensive security audit for Active Directory environments.
    Checks privileged groups, stale accounts, delegation, password policies,
    and DC hardening settings.

.NOTES
    @elevation: admin
    @elevation-reason: Requires AD PowerShell module and domain admin rights
    Requires: ActiveDirectory PowerShell module (RSAT)
    Run on: Domain Controller or domain-joined workstation with RSAT

Compliance Mapping:
- CIS Controls: 4.1, 4.2, 5.1, 6.2, 8.1, 8.2, 16.11
- NIST SP 800-53: AC-2, AC-6, AU-2, AU-6, SC-7, SC-13, SI-2
- ISO 27001: A.9.2, A.10.1, A.12.4, A.13.1, A.14.2
- PCI DSS: 2.2, 7.1, 10.2, 10.3
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

# Check if AD module is available
function Test-ADModule {
    try {
        Import-Module ActiveDirectory -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

# Section header helper
function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

# Main audit execution
Write-Section "Active Directory Security Audit"

if (-not (Test-ADModule)) {
    Register-Check -Name "AD Module" -Status SKIP -Message "ActiveDirectory module not available. Install RSAT."
    Print-Summary
    Exit-Audit
}

Register-Check -Name "AD Module" -Status PASS -Message "ActiveDirectory module loaded"

# Get domain info
try {
    $domain = Get-ADDomain
    Register-Check -Name "Domain Connection" -Status PASS -Message $domain.DNSRoot
} catch {
    Register-Check -Name "Domain Connection" -Status FAIL -Message "Cannot connect to domain: $_"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# PRIVILEGED GROUP MEMBERSHIP (CIS, NIST AC-6)
# ============================================================================
Write-Section "Privileged Group Membership"

$privilegedGroups = @(
    @{Name = "Domain Admins"; SID = "S-1-5-21-*-512"; MaxMembers = 5},
    @{Name = "Enterprise Admins"; SID = "S-1-5-21-*-519"; MaxMembers = 3},
    @{Name = "Schema Admins"; SID = "S-1-5-21-*-518"; MaxMembers = 2},
    @{Name = "Administrators"; SID = "S-1-5-32-544"; MaxMembers = 10},
    @{Name = "Account Operators"; SID = "S-1-5-32-548"; MaxMembers = 0},
    @{Name = "Backup Operators"; SID = "S-1-5-32-551"; MaxMembers = 3},
    @{Name = "Server Operators"; SID = "S-1-5-32-549"; MaxMembers = 0},
    @{Name = "Print Operators"; SID = "S-1-5-32-550"; MaxMembers = 0}
)

foreach ($group in $privilegedGroups) {
    try {
        $members = Get-ADGroupMember -Identity $group.Name -ErrorAction SilentlyContinue
        $memberCount = if ($members) { @($members).Count } else { 0 }

        if ($memberCount -eq 0 -and $group.MaxMembers -eq 0) {
            Register-Check -Name "$($group.Name)" -Status PASS -Message "Empty (expected)"
        } elseif ($memberCount -le $group.MaxMembers) {
            Register-Check -Name "$($group.Name)" -Status PASS -Message "$memberCount member(s)"
        } else {
            Register-Check -Name "$($group.Name)" -Status WARN -Message "$memberCount members (recommend <= $($group.MaxMembers))"
        }
    } catch {
        Register-Check -Name "$($group.Name)" -Status SKIP -Message "Cannot enumerate"
    }
}

# Protected Users group - should have privileged accounts
try {
    $protectedUsers = Get-ADGroupMember -Identity "Protected Users" -ErrorAction SilentlyContinue
    $protectedCount = if ($protectedUsers) { @($protectedUsers).Count } else { 0 }

    if ($protectedCount -ge 1) {
        Register-Check -Name "Protected Users Group" -Status PASS -Message "$protectedCount member(s)"
    } else {
        Register-Check -Name "Protected Users Group" -Status WARN -Message "Empty - add privileged accounts for protection"
    }
} catch {
    Register-Check -Name "Protected Users Group" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# STALE ACCOUNTS (NIST AC-2, PCI 8.1)
# ============================================================================
Write-Section "Account Hygiene"

$staleThreshold = (Get-Date).AddDays(-90)

try {
    # Stale user accounts
    $staleUsers = Get-ADUser -Filter {
        Enabled -eq $true -and LastLogonDate -lt $staleThreshold
    } -Properties LastLogonDate | Where-Object { $_.LastLogonDate }

    $staleCount = @($staleUsers).Count
    if ($staleCount -eq 0) {
        Register-Check -Name "Stale User Accounts (90+ days)" -Status PASS -Message "None found"
    } elseif ($staleCount -le 10) {
        Register-Check -Name "Stale User Accounts (90+ days)" -Status WARN -Message "$staleCount account(s) - review and disable"
    } else {
        Register-Check -Name "Stale User Accounts (90+ days)" -Status FAIL -Message "$staleCount accounts - immediate cleanup needed"
    }
} catch {
    Register-Check -Name "Stale User Accounts" -Status SKIP -Message "Query failed"
}

try {
    # Stale computer accounts
    $staleComputers = Get-ADComputer -Filter {
        Enabled -eq $true -and LastLogonDate -lt $staleThreshold
    } -Properties LastLogonDate | Where-Object { $_.LastLogonDate }

    $staleComputerCount = @($staleComputers).Count
    if ($staleComputerCount -eq 0) {
        Register-Check -Name "Stale Computer Accounts (90+ days)" -Status PASS -Message "None found"
    } elseif ($staleComputerCount -le 20) {
        Register-Check -Name "Stale Computer Accounts (90+ days)" -Status WARN -Message "$staleComputerCount account(s)"
    } else {
        Register-Check -Name "Stale Computer Accounts (90+ days)" -Status FAIL -Message "$staleComputerCount accounts"
    }
} catch {
    Register-Check -Name "Stale Computer Accounts" -Status SKIP -Message "Query failed"
}

# ============================================================================
# PASSWORD POLICY ISSUES (CIS 1.1, NIST IA-5)
# ============================================================================
Write-Section "Password Policy Issues"

try {
    # Accounts with non-expiring passwords
    $nonExpiringPwd = Get-ADUser -Filter {
        Enabled -eq $true -and PasswordNeverExpires -eq $true
    } -Properties PasswordNeverExpires

    $nonExpiringCount = @($nonExpiringPwd).Count
    if ($nonExpiringCount -eq 0) {
        Register-Check -Name "Non-Expiring Passwords" -Status PASS -Message "None found"
    } elseif ($nonExpiringCount -le 5) {
        Register-Check -Name "Non-Expiring Passwords" -Status WARN -Message "$nonExpiringCount account(s) - review service accounts"
    } else {
        Register-Check -Name "Non-Expiring Passwords" -Status FAIL -Message "$nonExpiringCount accounts with non-expiring passwords"
    }
} catch {
    Register-Check -Name "Non-Expiring Passwords" -Status SKIP -Message "Query failed"
}

try {
    # Accounts with password not required
    $noPwdRequired = Get-ADUser -Filter {
        Enabled -eq $true -and PasswordNotRequired -eq $true
    } -Properties PasswordNotRequired

    $noPwdCount = @($noPwdRequired).Count
    if ($noPwdCount -eq 0) {
        Register-Check -Name "Password Not Required" -Status PASS -Message "None found"
    } else {
        Register-Check -Name "Password Not Required" -Status FAIL -Message "$noPwdCount account(s) - critical security issue"
    }
} catch {
    Register-Check -Name "Password Not Required" -Status SKIP -Message "Query failed"
}

try {
    # Reversible encryption
    $reversibleEnc = Get-ADUser -Filter {
        Enabled -eq $true -and AllowReversiblePasswordEncryption -eq $true
    } -Properties AllowReversiblePasswordEncryption

    $reversibleCount = @($reversibleEnc).Count
    if ($reversibleCount -eq 0) {
        Register-Check -Name "Reversible Encryption" -Status PASS -Message "None found"
    } else {
        Register-Check -Name "Reversible Encryption" -Status FAIL -Message "$reversibleCount account(s) with reversible encryption"
    }
} catch {
    Register-Check -Name "Reversible Encryption" -Status SKIP -Message "Query failed"
}

# ============================================================================
# KERBEROS DELEGATION (T1558, T1187)
# ============================================================================
Write-Section "Kerberos Security"

try {
    # Unconstrained delegation (dangerous)
    $unconstrainedDeleg = Get-ADComputer -Filter {
        TrustedForDelegation -eq $true
    } -Properties TrustedForDelegation | Where-Object { $_.Name -notlike "*DC*" }

    $unconstrainedCount = @($unconstrainedDeleg).Count
    if ($unconstrainedCount -eq 0) {
        Register-Check -Name "Unconstrained Delegation (Computers)" -Status PASS -Message "None found (excluding DCs)"
    } else {
        Register-Check -Name "Unconstrained Delegation (Computers)" -Status FAIL -Message "$unconstrainedCount non-DC computer(s) - high risk"
    }
} catch {
    Register-Check -Name "Unconstrained Delegation" -Status SKIP -Message "Query failed"
}

try {
    # Users with unconstrained delegation
    $unconstrainedUsers = Get-ADUser -Filter {
        TrustedForDelegation -eq $true
    } -Properties TrustedForDelegation

    $unconstrainedUserCount = @($unconstrainedUsers).Count
    if ($unconstrainedUserCount -eq 0) {
        Register-Check -Name "Unconstrained Delegation (Users)" -Status PASS -Message "None found"
    } else {
        Register-Check -Name "Unconstrained Delegation (Users)" -Status FAIL -Message "$unconstrainedUserCount user(s) - high risk"
    }
} catch {
    Register-Check -Name "Unconstrained Delegation (Users)" -Status SKIP -Message "Query failed"
}

try {
    # Kerberoastable accounts (users with SPNs)
    $kerberoastable = Get-ADUser -Filter {
        ServicePrincipalName -like "*" -and Enabled -eq $true
    } -Properties ServicePrincipalName | Where-Object { $_.ServicePrincipalName }

    $kerberoastCount = @($kerberoastable).Count
    if ($kerberoastCount -eq 0) {
        Register-Check -Name "Kerberoastable Accounts" -Status PASS -Message "No user accounts with SPNs"
    } elseif ($kerberoastCount -le 5) {
        Register-Check -Name "Kerberoastable Accounts" -Status WARN -Message "$kerberoastCount account(s) - ensure strong passwords"
    } else {
        Register-Check -Name "Kerberoastable Accounts" -Status WARN -Message "$kerberoastCount accounts with SPNs - review necessity"
    }
} catch {
    Register-Check -Name "Kerberoastable Accounts" -Status SKIP -Message "Query failed"
}

# KRBTGT password age
try {
    $krbtgt = Get-ADUser -Identity "krbtgt" -Properties PasswordLastSet
    $krbtgtAge = ((Get-Date) - $krbtgt.PasswordLastSet).Days

    if ($krbtgtAge -le 180) {
        Register-Check -Name "KRBTGT Password Age" -Status PASS -Message "$krbtgtAge days old"
    } elseif ($krbtgtAge -le 365) {
        Register-Check -Name "KRBTGT Password Age" -Status WARN -Message "$krbtgtAge days - consider rotation"
    } else {
        Register-Check -Name "KRBTGT Password Age" -Status FAIL -Message "$krbtgtAge days - immediate rotation recommended"
    }
} catch {
    Register-Check -Name "KRBTGT Password Age" -Status SKIP -Message "Cannot query krbtgt"
}

# ============================================================================
# ADMINSDHOLDER PROTECTION (Privilege Escalation)
# ============================================================================
Write-Section "AdminSDHolder Security"

try {
    # Check for accounts with modified AdminCount (potential tampering)
    $adminCountUsers = Get-ADUser -Filter {
        AdminCount -eq 1
    } -Properties AdminCount, MemberOf

    # Get actual privileged group members for comparison
    $actualPrivileged = @()
    foreach ($group in @("Domain Admins", "Enterprise Admins", "Schema Admins", "Administrators")) {
        try {
            $members = Get-ADGroupMember -Identity $group -Recursive -ErrorAction SilentlyContinue
            $actualPrivileged += $members.SamAccountName
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
    $actualPrivileged = $actualPrivileged | Select-Object -Unique

    $orphanedAdminCount = @($adminCountUsers | Where-Object {
        $_.SamAccountName -notin $actualPrivileged
    }).Count

    if ($orphanedAdminCount -eq 0) {
        Register-Check -Name "Orphaned AdminCount" -Status PASS -Message "No orphaned accounts"
    } else {
        Register-Check -Name "Orphaned AdminCount" -Status WARN -Message "$orphanedAdminCount account(s) with AdminCount=1 not in privileged groups"
    }
} catch {
    Register-Check -Name "AdminSDHolder" -Status SKIP -Message "Query failed"
}

# ============================================================================
# DC SECURITY SETTINGS
# ============================================================================
Write-Section "Domain Controller Settings"

# Check if running on DC
$isDC = (Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue).DomainRole -ge 4

if ($isDC) {
    # LDAP Signing
    try {
        $ldapSigning = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -Name "LDAPServerIntegrity" -ErrorAction SilentlyContinue
        $ldapValue = $ldapSigning.LDAPServerIntegrity

        if ($ldapValue -eq 2) {
            Register-Check -Name "LDAP Server Signing" -Status PASS -Message "Required"
        } elseif ($ldapValue -eq 1) {
            Register-Check -Name "LDAP Server Signing" -Status WARN -Message "Negotiated (should be Required)"
        } else {
            Register-Check -Name "LDAP Server Signing" -Status FAIL -Message "Not configured"
        }
    } catch {
        Register-Check -Name "LDAP Server Signing" -Status WARN -Message "Not configured (default: Negotiate)"
    }

    # LDAP Channel Binding
    try {
        $channelBinding = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -Name "LdapEnforceChannelBinding" -ErrorAction SilentlyContinue
        $cbValue = $channelBinding.LdapEnforceChannelBinding

        if ($cbValue -eq 2) {
            Register-Check -Name "LDAP Channel Binding" -Status PASS -Message "Always"
        } elseif ($cbValue -eq 1) {
            Register-Check -Name "LDAP Channel Binding" -Status WARN -Message "When Supported"
        } else {
            Register-Check -Name "LDAP Channel Binding" -Status FAIL -Message "Never (vulnerable to relay)"
        }
    } catch {
        Register-Check -Name "LDAP Channel Binding" -Status WARN -Message "Not configured"
    }

    # SMB Signing on DC
    try {
        $smbSigning = Get-SmbServerConfiguration | Select-Object -ExpandProperty RequireSecuritySignature
        if ($smbSigning) {
            Register-Check -Name "SMB Signing (DC)" -Status PASS -Message "Required"
        } else {
            Register-Check -Name "SMB Signing (DC)" -Status FAIL -Message "Not required"
        }
    } catch {
        Register-Check -Name "SMB Signing (DC)" -Status SKIP -Message "Cannot query"
    }
} else {
    Register-Check -Name "DC Security Settings" -Status SKIP -Message "Not running on Domain Controller"
}

# ============================================================================
# DOMAIN FUNCTIONAL LEVEL
# ============================================================================
Write-Section "Domain Configuration"

try {
    $forestLevel = (Get-ADForest).ForestMode
    $domainLevel = $domain.DomainMode

    $modernLevels = @("Windows2016Domain", "Windows2016Forest", "Windows2019Domain", "Windows2019Forest",
                      "Windows2022Domain", "Windows2022Forest", "Windows2025Domain", "Windows2025Forest")

    if ($domainLevel -in $modernLevels) {
        Register-Check -Name "Domain Functional Level" -Status PASS -Message $domainLevel
    } else {
        Register-Check -Name "Domain Functional Level" -Status WARN -Message "$domainLevel - consider upgrade"
    }

    if ($forestLevel -in $modernLevels) {
        Register-Check -Name "Forest Functional Level" -Status PASS -Message $forestLevel
    } else {
        Register-Check -Name "Forest Functional Level" -Status WARN -Message "$forestLevel - consider upgrade"
    }
} catch {
    Register-Check -Name "Functional Levels" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# GPO SECURITY
# ============================================================================
Write-Section "GPO Security (Basic)"

try {
    $gpos = Get-GPO -All -ErrorAction Stop
    $gpoCount = @($gpos).Count
    Register-Check -Name "Total GPOs" -Status PASS -Message "$gpoCount GPO(s)"

    # Check for unlinked GPOs
    $unlinkedCount = 0
    foreach ($gpo in $gpos) {
        try {
            $report = Get-GPOReport -Guid $gpo.Id -ReportType XML
            if ($report -notmatch "<LinksTo>") {
                $unlinkedCount++
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    if ($unlinkedCount -eq 0) {
        Register-Check -Name "Unlinked GPOs" -Status PASS -Message "None found"
    } else {
        Register-Check -Name "Unlinked GPOs" -Status WARN -Message "$unlinkedCount GPO(s) not linked - consider cleanup"
    }
} catch {
    Register-Check -Name "GPO Enumeration" -Status SKIP -Message "Cannot enumerate GPOs (GPMC not available or not DC)"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit

