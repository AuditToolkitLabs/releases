<#
.SYNOPSIS
    Active Directory Certificate Services (AD CS) Security Audit

.DESCRIPTION
    Audits AD CS for common misconfigurations and vulnerabilities:
    - ESC1-ESC8 vulnerability patterns
    - Certificate template permissions
    - CA configuration hardening
    - Enrollment agent restrictions
    - Web enrollment security

.NOTES
    Requires: PSPKI module or RSAT AD CS tools for full checks
    Run on: CA server or domain-joined machine with CA access

Compliance Mapping:
- CIS Controls: 3.10 (Encrypt Sensitive Data in Transit)
- NIST SP 800-53: IA-5 (Authenticator Management), SC-17 (PKI Certificates)
- MITRE ATT&CK: T1649 (Steal or Forge Authentication Certificates)

References:
- SpecterOps "Certified Pre-Owned" whitepaper
- Microsoft PKI hardening guidance
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "AD CS Security Audit"

# ============================================================================
# CA SERVICE STATUS
# ============================================================================
Write-Section "Certificate Authority Service"

$isCAServer = $false

try {
    $caSvc = Get-Service -Name CertSvc -ErrorAction SilentlyContinue
    if ($caSvc) {
        $isCAServer = $true
        if ($caSvc.Status -eq 'Running') {
            Register-Check -Name "CA Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "CA Service" -Status WARN -Message "Status: $($caSvc.Status)"
        }
    } else {
        Register-Check -Name "CA Service" -Status SKIP -Message "Not a CA server"
    }
} catch {
    Register-Check -Name "CA Service" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# CA CONFIGURATION (if CA server)
# ============================================================================
if ($isCAServer) {
    Write-Section "CA Configuration"

    try {
        # Get CA configuration from registry
        $caRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\CertSvc\Configuration"
        $caConfig = Get-ChildItem $caRegPath -ErrorAction SilentlyContinue | Select-Object -First 1

        if ($caConfig) {
            $caName = $caConfig.PSChildName
            $caSettings = Get-ItemProperty $caConfig.PSPath -ErrorAction SilentlyContinue

            Register-Check -Name "CA Name" -Status INFO -Message $caName

            # Check CA type
            $caType = $caSettings.CAType
            switch ($caType) {
                0 { Register-Check -Name "CA Type" -Status PASS -Message "Enterprise Root CA" }
                1 { Register-Check -Name "CA Type" -Status PASS -Message "Enterprise Subordinate CA" }
                3 { Register-Check -Name "CA Type" -Status WARN -Message "Standalone Root CA" }
                4 { Register-Check -Name "CA Type" -Status WARN -Message "Standalone Subordinate CA" }
                default { Register-Check -Name "CA Type" -Status INFO -Message "Type: $caType" }
            }

            # Check if EDITF_ATTRIBUTESUBJECTALTNAME2 is enabled (ESC6)
            $editFlags = $caSettings.EditFlags
            if ($editFlags -band 0x00040000) {
                Register-Check -Name "ESC6 - SAN in Requests" -Status FAIL -Message "EDITF_ATTRIBUTESUBJECTALTNAME2 enabled - allows SAN spoofing"
            } else {
                Register-Check -Name "ESC6 - SAN in Requests" -Status PASS -Message "SAN in requests not enabled"
            }

            # Check certificate validity
            $validityPeriod = $caSettings.ValidityPeriod
            $validityUnits = $caSettings.ValidityPeriodUnits
            Register-Check -Name "Cert Validity" -Status INFO -Message "$validityUnits $validityPeriod"

            # Audit settings
            $auditFilter = $caSettings.AuditFilter
            if ($auditFilter -ge 127) {
                Register-Check -Name "CA Auditing" -Status PASS -Message "Full auditing enabled"
            } elseif ($auditFilter -gt 0) {
                Register-Check -Name "CA Auditing" -Status WARN -Message "Partial auditing (filter: $auditFilter)"
            } else {
                Register-Check -Name "CA Auditing" -Status FAIL -Message "No auditing configured"
            }
        }
    } catch {
        Register-Check -Name "CA Configuration" -Status SKIP -Message "Cannot read CA config"
    }

    # Check CA security settings
    try {
        $securityPath = "$($caConfig.PSPath)\Security"
        if (Test-Path $securityPath) {
            Register-Check -Name "CA Security Config" -Status PASS -Message "Security configuration present"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# CERTIFICATE TEMPLATES (ESC1-ESC4)
# ============================================================================
Write-Section "Certificate Templates"

$templateVulnerabilities = @()

try {
    # Try to enumerate templates via AD
    $configNC = ([ADSI]"LDAP://RootDSE").configurationNamingContext
    $templatesPath = "LDAP://CN=Certificate Templates,CN=Public Key Services,CN=Services,$configNC"
    $templates = ([ADSI]$templatesPath).Children

    $templateCount = 0
    $riskyTemplates = 0

    foreach ($template in $templates) {
        $templateCount++
        $templateName = $template.cn
        $flags = $template."msPKI-Certificate-Name-Flag"
        $ekus = $template."pKIExtendedKeyUsage"

        $isRisky = $false
        $riskReasons = @()

        # ESC1: Enrollee supplies subject (ENROLLEE_SUPPLIES_SUBJECT)
        if ($flags -band 1) {
            # Check if template allows client auth or smart card logon
            $hasAuthEku = $false
            if ($ekus) {
                $authOids = @(
                    "1.3.6.1.5.5.7.3.2",   # Client Authentication
                    "1.3.6.1.4.1.311.20.2.2", # Smart Card Logon
                    "1.3.6.1.5.2.3.4"      # PKINIT Client Authentication
                )
                foreach ($eku in $ekus) {
                    if ($eku -in $authOids) {
                        $hasAuthEku = $true
                        break
                    }
                }
            }

            if ($hasAuthEku) {
                $isRisky = $true
                $riskReasons += "ESC1:Enrollee supplies subject with auth EKU"
            }
        }

        # ESC2: Any Purpose EKU or no EKU restrictions
        if ($ekus -contains "2.5.29.37.0" -or -not $ekus) {
            $isRisky = $true
            $riskReasons += "ESC2:Any Purpose or unrestricted EKU"
        }

        # ESC3: Certificate Request Agent
        if ($ekus -contains "1.3.6.1.4.1.311.20.2.1") {
            $isRisky = $true
            $riskReasons += "ESC3:Certificate Request Agent"
        }

        if ($isRisky) {
            $riskyTemplates++
            $templateVulnerabilities += [PSCustomObject]@{
                Name = $templateName
                Risks = $riskReasons -join "; "
            }
        }
    }

    Register-Check -Name "Templates Enumerated" -Status PASS -Message "$templateCount templates found"

    if ($riskyTemplates -gt 0) {
        Register-Check -Name "Risky Templates" -Status FAIL -Message "$riskyTemplates template(s) with ESC vulnerabilities"
        foreach ($vuln in $templateVulnerabilities | Select-Object -First 5) {
            Write-Output "    - $($vuln.Name): $($vuln.Risks)"
        }
    } else {
        Register-Check -Name "Risky Templates" -Status PASS -Message "No obvious ESC1-3 vulnerabilities"
    }

} catch {
    Register-Check -Name "Template Enumeration" -Status SKIP -Message "Cannot enumerate (need AD access)"
}

# ============================================================================
# ENROLLMENT SERVICES (ESC8)
# ============================================================================
Write-Section "Web Enrollment (ESC8)"

# Check if web enrollment is installed
try {
    $webEnrollment = Get-WindowsFeature -Name ADCS-Web-Enrollment -ErrorAction SilentlyContinue
    if ($webEnrollment -and $webEnrollment.Installed) {
        Register-Check -Name "Web Enrollment" -Status WARN -Message "Installed - check for NTLM relay risks"

        # Check if HTTPS is enforced
        try {
            $certsrvPath = "$env:SystemRoot\System32\certsrv"
            if (Test-Path $certsrvPath) {
                Register-Check -Name "CertSrv Path" -Status INFO -Message "Web enrollment files present"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

        # Check for EPA (Extended Protection for Authentication)
        try {
            Import-Module WebAdministration -ErrorAction SilentlyContinue
            $certSrvSite = Get-WebConfiguration -Filter "/system.webServer/security/authentication/windowsAuthentication" -PSPath "IIS:\Sites\Default Web Site\CertSrv" -ErrorAction SilentlyContinue

            if ($certSrvSite) {
                $extendedProtection = $certSrvSite.extendedProtection.tokenChecking
                if ($extendedProtection -eq "Require") {
                    Register-Check -Name "EPA on Web Enrollment" -Status PASS -Message "Extended Protection required"
                } elseif ($extendedProtection -eq "Allow") {
                    Register-Check -Name "EPA on Web Enrollment" -Status WARN -Message "Extended Protection optional"
                } else {
                    Register-Check -Name "EPA on Web Enrollment" -Status FAIL -Message "No Extended Protection - NTLM relay risk"
                }
            }
        } catch {
            Register-Check -Name "EPA Check" -Status SKIP -Message "Cannot check IIS configuration"
        }
    } else {
        Register-Check -Name "Web Enrollment" -Status PASS -Message "Not installed (reduces attack surface)"
    }
} catch {
    # Not a server with RSAT
    Register-Check -Name "Web Enrollment" -Status SKIP -Message "Cannot determine"
}

# ============================================================================
# CA PERMISSIONS (ESC7)
# ============================================================================
Write-Section "CA Permissions"

try {
    # Check CA permissions via certutil
    $certutilOutput = & certutil -getreg CA\Security 2>&1

    if ($certutilOutput -match "ManageCA") {
        Register-Check -Name "CA Permissions" -Status INFO -Message "ManageCA permissions found"

        # Look for non-admin principals with ManageCA
        if ($certutilOutput -match "Authenticated Users.*ManageCA|Everyone.*ManageCA|Domain Users.*ManageCA") {
            Register-Check -Name "ESC7 - ManageCA" -Status FAIL -Message "Low-privilege users have ManageCA rights"
        } else {
            Register-Check -Name "ESC7 - ManageCA" -Status PASS -Message "ManageCA restricted to admins"
        }
    }
} catch {
    Register-Check -Name "CA Permissions" -Status SKIP -Message "Cannot query (run certutil manually)"
}

# ============================================================================
# ENROLLMENT AGENT RESTRICTIONS (ESC3)
# ============================================================================
Write-Section "Enrollment Agent Restrictions"

if ($isCAServer) {
    try {
        $eaPath = "HKLM:\SYSTEM\CurrentControlSet\Services\CertSvc\Configuration\*\EnrollmentAgentRights"
        $eaConfig = Get-ItemProperty $eaPath -ErrorAction SilentlyContinue

        if ($eaConfig) {
            Register-Check -Name "Enrollment Agent Restrictions" -Status PASS -Message "Restrictions configured"
        } else {
            Register-Check -Name "Enrollment Agent Restrictions" -Status WARN -Message "No restrictions - agents can enroll for any user"
        }
    } catch {
        Register-Check -Name "Enrollment Agent Restrictions" -Status WARN -Message "Cannot determine"
    }
}

# ============================================================================
# PUBLISHED TEMPLATES CHECK
# ============================================================================
Write-Section "Published Templates"

try {
    # Use certutil to list published templates
    $publishedOutput = & certutil -catemplates 2>&1

    $publishedCount = ($publishedOutput | Where-Object { $_ -match ":" }).Count
    Register-Check -Name "Published Templates" -Status INFO -Message "$publishedCount template(s) published"

    # Check for SubCA template (very dangerous)
    if ($publishedOutput -match "SubCA") {
        Register-Check -Name "SubCA Template" -Status FAIL -Message "Published - can create rogue CAs"
    }

} catch {
    Register-Check -Name "Published Templates" -Status SKIP -Message "Cannot enumerate"
}

# ============================================================================
# CERTIFICATE STORES
# ============================================================================
Write-Section "Certificate Stores"

try {
    # Check machine personal store for unusual certs
    $machineCerts = Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue
    $certCount = @($machineCerts).Count
    Register-Check -Name "Machine Certificates" -Status INFO -Message "$certCount certificate(s) in personal store"

    # Check for expired certs
    $expiredCerts = $machineCerts | Where-Object { $_.NotAfter -lt (Get-Date) }
    if ($expiredCerts) {
        Register-Check -Name "Expired Certificates" -Status WARN -Message "$(@($expiredCerts).Count) expired cert(s)"
    } else {
        Register-Check -Name "Expired Certificates" -Status PASS -Message "None"
    }

    # Check for certs expiring soon (30 days)
    $expiringSoon = $machineCerts | Where-Object {
        $_.NotAfter -gt (Get-Date) -and $_.NotAfter -lt (Get-Date).AddDays(30)
    }
    if ($expiringSoon) {
        Register-Check -Name "Expiring Soon" -Status WARN -Message "$(@($expiringSoon).Count) cert(s) expiring in 30 days"
    }

    # Check trusted root store for non-Microsoft roots
    $rootCerts = Get-ChildItem Cert:\LocalMachine\Root -ErrorAction SilentlyContinue
    $nonMsRoots = $rootCerts | Where-Object { $_.Issuer -notmatch "Microsoft|Windows|DigiCert|VeriSign|GlobalSign|Comodo|GoDaddy|Entrust|Symantec" }
    if (@($nonMsRoots).Count -gt 10) {
        Register-Check -Name "Custom Root CAs" -Status WARN -Message "$(@($nonMsRoots).Count) non-standard root CAs"
    } else {
        Register-Check -Name "Custom Root CAs" -Status PASS -Message "$(@($nonMsRoots).Count) custom root(s)"
    }

} catch {
    Register-Check -Name "Certificate Stores" -Status SKIP -Message "Cannot access"
}

# ============================================================================
# SUMMARY
# ============================================================================
Print-Summary
Exit-Audit
