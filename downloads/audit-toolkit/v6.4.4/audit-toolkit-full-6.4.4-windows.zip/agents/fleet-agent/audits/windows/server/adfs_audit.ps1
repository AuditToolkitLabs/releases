<#
.SYNOPSIS
    Active Directory Federation Services (ADFS) Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows ADFS:
    - ADFS service configuration
    - Certificate security
    - Token and claims security
    - Endpoint security
    - Extranet lockout
    - Logging and monitoring
    - Authentication policies

.NOTES
    @elevation: admin
    @elevation-reason: ADFS cmdlets require Administrator privileges
    Requires: ADFS role installed

Compliance Mapping:
- CIS Controls: 6.3 (MFA), 16.8 (Secure Identity Infrastructure)
- NIST SP 800-53: IA-2 (Identification and Authentication), IA-5 (Authenticator Management)
- NIST SP 800-63: Digital Identity Guidelines
- Microsoft Security Baseline for ADFS
- MITRE ATT&CK: T1606 (Forge Web Credentials), T1558 (Steal or Forge Kerberos Tickets)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Active Directory Federation Services Security Audit"

# ============================================================================
# ADFS ROLE CHECK
# ============================================================================
Write-Section "ADFS Role Status"

try {
    $adfsFeature = Get-WindowsFeature -Name ADFS-Federation -ErrorAction Stop
    if ($adfsFeature.Installed) {
        Register-Check -Name "ADFS Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "ADFS Role" -Status SKIP -Message "Not installed - skipping ADFS checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    Register-Check -Name "ADFS Role" -Status SKIP -Message "Cannot determine role status"
    Print-Summary
    Exit-Audit
}

# Check ADFS service
try {
    $adfsSvc = Get-Service -Name adfssrv -ErrorAction Stop
    if ($adfsSvc.Status -eq 'Running') {
        Register-Check -Name "ADFS Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "ADFS Service" -Status FAIL -Message "Status: $($adfsSvc.Status)"
    }
} catch {
    Register-Check -Name "ADFS Service" -Status FAIL -Message "Cannot query"
}

# Import ADFS module
try {
    Import-Module ADFS -ErrorAction Stop
    Register-Check -Name "ADFS Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "ADFS Module" -Status FAIL -Message "Cannot load module"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# ADFS PROPERTIES
# ============================================================================
Write-Section "ADFS Farm Properties"

try {
    $adfsProps = Get-AdfsProperties -ErrorAction Stop

    Register-Check -Name "Federation Service" -Status INFO -Message $adfsProps.HostName
    Register-Check -Name "Federation Identifier" -Status INFO -Message $adfsProps.Identifier

    # Auto certificate rollover
    if ($adfsProps.AutoCertificateRollover -eq $true) {
        Register-Check -Name "Auto Certificate Rollover" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Auto Certificate Rollover" -Status INFO -Message "Manual certificate management"
    }

    # Certificate lifetime
    if ($adfsProps.CertificateDuration -le 365) {
        Register-Check -Name "Certificate Duration" -Status PASS -Message "$($adfsProps.CertificateDuration) days"
    } else {
        Register-Check -Name "Certificate Duration" -Status INFO -Message "$($adfsProps.CertificateDuration) days"
    }

} catch {
    Register-Check -Name "ADFS Properties" -Status WARN -Message "Cannot query"
}

# ============================================================================
# CERTIFICATE SECURITY
# ============================================================================
Write-Section "Certificate Security"

try {
    # Token signing certificate
    $signingCert = Get-AdfsCertificate -CertificateType Token-Signing -ErrorAction Stop
    if ($signingCert) {
        $primarySigning = $signingCert | Where-Object { $_.IsPrimary -eq $true }
        if ($primarySigning) {
            $daysUntilExpiry = ($primarySigning.Certificate.NotAfter - (Get-Date)).Days

            if ($daysUntilExpiry -gt 90) {
                Register-Check -Name "Token Signing Cert" -Status PASS -Message "Valid, expires in $daysUntilExpiry days"
            } elseif ($daysUntilExpiry -gt 30) {
                Register-Check -Name "Token Signing Cert" -Status WARN -Message "Expires in $daysUntilExpiry days"
            } else {
                Register-Check -Name "Token Signing Cert" -Status FAIL -Message "Expires in $daysUntilExpiry days - renew immediately"
            }

            # Key size
            $keySize = $primarySigning.Certificate.PublicKey.Key.KeySize
            if ($keySize -ge 2048) {
                Register-Check -Name "Token Signing Key Size" -Status PASS -Message "$keySize bits"
            } else {
                Register-Check -Name "Token Signing Key Size" -Status FAIL -Message "$keySize bits (minimum 2048)"
            }
        }
    }

    # Token decryption certificate
    $decryptCert = Get-AdfsCertificate -CertificateType Token-Decrypting -ErrorAction SilentlyContinue
    if ($decryptCert) {
        $primaryDecrypt = $decryptCert | Where-Object { $_.IsPrimary -eq $true }
        if ($primaryDecrypt) {
            $daysUntilExpiry = ($primaryDecrypt.Certificate.NotAfter - (Get-Date)).Days

            if ($daysUntilExpiry -gt 90) {
                Register-Check -Name "Token Decryption Cert" -Status PASS -Message "Valid, expires in $daysUntilExpiry days"
            } elseif ($daysUntilExpiry -gt 30) {
                Register-Check -Name "Token Decryption Cert" -Status WARN -Message "Expires in $daysUntilExpiry days"
            } else {
                Register-Check -Name "Token Decryption Cert" -Status FAIL -Message "Expires in $daysUntilExpiry days"
            }
        }
    }

    # Service communications certificate (SSL)
    $sslCert = Get-AdfsSslCertificate -ErrorAction SilentlyContinue
    if ($sslCert) {
        $certThumb = $sslCert.CertificateHash
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $certThumb }
        if ($cert) {
            $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days
            if ($daysUntilExpiry -gt 30) {
                Register-Check -Name "SSL Certificate" -Status PASS -Message "Valid, expires in $daysUntilExpiry days"
            } else {
                Register-Check -Name "SSL Certificate" -Status WARN -Message "Expires in $daysUntilExpiry days"
            }
        }
    }

} catch {
    Register-Check -Name "Certificate Security" -Status WARN -Message "Cannot query certificates"
}

# ============================================================================
# ENDPOINT SECURITY
# ============================================================================
Write-Section "Endpoint Security"

try {
    $endpoints = Get-AdfsEndpoint -ErrorAction Stop

    # Check sensitive endpoints
    $sensitiveEndpoints = @(
        @{Path = '/adfs/services/trust/2005/windowstransport'; Name = 'WS-Trust Windows Transport'},
        @{Path = '/adfs/services/trust/mex'; Name = 'MEX Endpoint'},
        @{Path = '/adfs/services/trust/2005/usernamemixed'; Name = 'Username/Password Mixed'}
    )

    foreach ($se in $sensitiveEndpoints) {
        $endpoint = $endpoints | Where-Object { $_.FullUrl.AbsolutePath -eq $se.Path }
        if ($endpoint) {
            if ($endpoint.Enabled -eq $true) {
                if ($endpoint.Proxy -eq $true) {
                    Register-Check -Name "Endpoint: $($se.Name)" -Status WARN -Message "Enabled for proxy - review necessity"
                } else {
                    Register-Check -Name "Endpoint: $($se.Name)" -Status INFO -Message "Enabled (intranet only)"
                }
            } else {
                Register-Check -Name "Endpoint: $($se.Name)" -Status PASS -Message "Disabled"
            }
        }
    }

    # Count enabled endpoints
    $enabledCount = ($endpoints | Where-Object { $_.Enabled -eq $true }).Count
    Register-Check -Name "Enabled Endpoints" -Status INFO -Message "$enabledCount endpoints enabled"

} catch {
    Register-Check -Name "Endpoints" -Status WARN -Message "Cannot query"
}

# ============================================================================
# EXTRANET LOCKOUT
# ============================================================================
Write-Section "Extranet Lockout Protection"

try {
    $lockout = Get-AdfsProperties -ErrorAction Stop

    # Extranet lockout enabled
    if ($lockout.ExtranetLockoutEnabled -eq $true) {
        Register-Check -Name "Extranet Lockout" -Status PASS -Message "Enabled"

        # Lockout threshold
        if ($lockout.ExtranetLockoutThreshold -le 15) {
            Register-Check -Name "Lockout Threshold" -Status PASS -Message "$($lockout.ExtranetLockoutThreshold) attempts"
        } else {
            Register-Check -Name "Lockout Threshold" -Status WARN -Message "$($lockout.ExtranetLockoutThreshold) attempts (recommend <=15)"
        }

        # Observation window
        $observationMinutes = $lockout.ExtranetObservationWindow.TotalMinutes
        if ($observationMinutes -ge 30) {
            Register-Check -Name "Observation Window" -Status PASS -Message "$observationMinutes minutes"
        } else {
            Register-Check -Name "Observation Window" -Status WARN -Message "$observationMinutes minutes (recommend >=30)"
        }

        # Extranet lockout mode (Server 2016+)
        if ($lockout.ExtranetLockoutMode) {
            Register-Check -Name "Lockout Mode" -Status INFO -Message $lockout.ExtranetLockoutMode
        }

    } else {
        Register-Check -Name "Extranet Lockout" -Status FAIL -Message "Disabled - vulnerable to password spray attacks"
    }

    # Smart lockout (Server 2019+)
    if ($null -ne $lockout.ExtranetLockoutRequirePDC) {
        if ($lockout.ExtranetLockoutRequirePDC -eq $false) {
            Register-Check -Name "Smart Lockout PDC" -Status PASS -Message "Not requiring PDC (resilient)"
        }
    }

} catch {
    Register-Check -Name "Extranet Lockout" -Status WARN -Message "Cannot query settings"
}

# ============================================================================
# AUTHENTICATION POLICIES
# ============================================================================
Write-Section "Authentication Policies"

try {
    $globalAuthPolicy = Get-AdfsGlobalAuthenticationPolicy -ErrorAction Stop

    # Primary authentication methods
    $primaryIntranet = $globalAuthPolicy.PrimaryIntranetAuthenticationProvider
    $primaryExtranet = $globalAuthPolicy.PrimaryExtranetAuthenticationProvider

    Register-Check -Name "Intranet Auth" -Status INFO -Message ($primaryIntranet -join ', ')
    Register-Check -Name "Extranet Auth" -Status INFO -Message ($primaryExtranet -join ', ')

    # MFA for extranet
    $mfaExtranet = $globalAuthPolicy.AdditionalAuthenticationProvider
    if ($mfaExtranet) {
        Register-Check -Name "Additional Auth Providers" -Status PASS -Message "MFA available"
    } else {
        Register-Check -Name "Additional Auth Providers" -Status INFO -Message "None configured"
    }

    # Device authentication
    if ($globalAuthPolicy.DeviceAuthenticationEnabled -eq $true) {
        Register-Check -Name "Device Authentication" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Device Authentication" -Status INFO -Message "Disabled"
    }

    # Windows Integrated Auth on extranet
    if ($primaryExtranet -contains 'WindowsAuthentication') {
        Register-Check -Name "Windows Auth on Extranet" -Status WARN -Message "Enabled - consider security implications"
    }

} catch {
    Register-Check -Name "Authentication Policy" -Status WARN -Message "Cannot query"
}

# Access control policies
try {
    $accessPolicies = Get-AdfsAccessControlPolicy -ErrorAction SilentlyContinue
    if ($accessPolicies) {
        Register-Check -Name "Access Control Policies" -Status INFO -Message "$($accessPolicies.Count) policies defined"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# RELYING PARTY TRUSTS
# ============================================================================
Write-Section "Relying Party Trusts"

try {
    $rpTrusts = Get-AdfsRelyingPartyTrust -ErrorAction Stop

    if ($rpTrusts) {
        Register-Check -Name "Relying Party Trusts" -Status INFO -Message "$($rpTrusts.Count) trust(s) configured"

        $enabledRPs = ($rpTrusts | Where-Object { $_.Enabled -eq $true }).Count
        $disabledRPs = $rpTrusts.Count - $enabledRPs
        Register-Check -Name "Enabled RPs" -Status INFO -Message "$enabledRPs enabled, $disabledRPs disabled"

        # Check for weak encryption
        $weakEncryption = $rpTrusts | Where-Object { $_.EncryptionCertificate -eq $null -and $_.EncryptClaims -eq $true }
        if ($weakEncryption) {
            Register-Check -Name "RP Encryption Config" -Status WARN -Message "$($weakEncryption.Count) RP(s) with encryption issues"
        }

        # Check for signature requirements
        foreach ($rp in $rpTrusts | Select-Object -First 5) {
            if ($rp.SignedSamlRequestsRequired -eq $true) {
                Register-Check -Name "Signed Requests: $($rp.Name.Substring(0, [Math]::Min(20, $rp.Name.Length)))" -Status PASS -Message "Required"
            }
        }
    }

} catch {
    Register-Check -Name "Relying Party Trusts" -Status WARN -Message "Cannot query"
}

# ============================================================================
# CLAIMS PROVIDER TRUSTS
# ============================================================================
Write-Section "Claims Provider Trusts"

try {
    $cpTrusts = Get-AdfsClaimsProviderTrust -ErrorAction SilentlyContinue
    if ($cpTrusts) {
        Register-Check -Name "Claims Provider Trusts" -Status INFO -Message "$($cpTrusts.Count) trust(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# LOGGING AND AUDITING
# ============================================================================
Write-Section "Logging and Auditing"

try {
    $adfsProps = Get-AdfsProperties -ErrorAction Stop

    # Audit level
    $auditLevel = $adfsProps.AuditLevel
    if ($auditLevel -eq 'Verbose') {
        Register-Check -Name "Audit Level" -Status PASS -Message "Verbose"
    } elseif ($auditLevel -eq 'Basic') {
        Register-Check -Name "Audit Level" -Status INFO -Message "Basic"
    } else {
        Register-Check -Name "Audit Level" -Status WARN -Message "None"
    }

    # Security audit events
    if ($adfsProps.LogLevel -contains 'Successes' -and $adfsProps.LogLevel -contains 'Failures') {
        Register-Check -Name "Security Logging" -Status PASS -Message "Success and failure events"
    } elseif ($adfsProps.LogLevel -contains 'Failures') {
        Register-Check -Name "Security Logging" -Status INFO -Message "Failure events only"
    } else {
        Register-Check -Name "Security Logging" -Status WARN -Message "Limited logging"
    }

} catch {
    Register-Check -Name "Audit Settings" -Status WARN -Message "Cannot query"
}

# Check ADFS event logs
try {
    $adfsAdminLog = Get-WinEvent -ListLog "AD FS/Admin" -ErrorAction SilentlyContinue
    if ($adfsAdminLog -and $adfsAdminLog.IsEnabled) {
        Register-Check -Name "ADFS Admin Log" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

try {
    $adfsProps = Get-AdfsProperties -ErrorAction Stop

    # Keep-me-signed-in (KMSI)
    if ($adfsProps.EnableKmsi -eq $true) {
        Register-Check -Name "Keep Me Signed In" -Status INFO -Message "Enabled - review for security"
    } else {
        Register-Check -Name "Keep Me Signed In" -Status PASS -Message "Disabled"
    }

    # Persistent SSO
    if ($adfsProps.EnablePersistentSso -eq $true) {
        Register-Check -Name "Persistent SSO" -Status INFO -Message "Enabled"
    }

    # Browser SSO
    $ssoLifetime = $adfsProps.SsoLifetime.TotalHours
    if ($ssoLifetime -le 8) {
        Register-Check -Name "SSO Lifetime" -Status PASS -Message "$ssoLifetime hours"
    } else {
        Register-Check -Name "SSO Lifetime" -Status WARN -Message "$ssoLifetime hours (recommend <=8)"
    }

    # Web application proxy connection string protection
    if ($adfsProps.WIASupportedUserAgents) {
        Register-Check -Name "WIA User Agents" -Status INFO -Message "$($adfsProps.WIASupportedUserAgents.Count) agents configured"
    }

} catch {
    Register-Check -Name "Security Settings" -Status WARN -Message "Cannot query"
}

# Check for IdP-Initiated Sign-On
try {
    $idpSignOn = Get-AdfsProperties | Select-Object -ExpandProperty EnableIdPInitiatedSignonPage
    if ($idpSignOn -eq $false) {
        Register-Check -Name "IdP Sign-On Page" -Status PASS -Message "Disabled"
    } else {
        Register-Check -Name "IdP Sign-On Page" -Status INFO -Message "Enabled at /adfs/ls/idpinitiatedsignon"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Token lifetime
try {
    $tokenLifetime = (Get-AdfsRelyingPartyTrust | Select-Object -First 1).TokenLifetime
    if ($tokenLifetime -and $tokenLifetime -le 60) {
        Register-Check -Name "Default Token Lifetime" -Status PASS -Message "$tokenLifetime minutes"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
