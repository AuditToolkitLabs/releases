<#
.SYNOPSIS
    Windows DHCP Server Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows DHCP Server role:
    - DHCP service configuration
    - Scope security and options
    - Lease management
    - Failover configuration
    - DHCP logging and audit
    - Rogue DHCP detection
    - DNS integration security

.NOTES
    @elevation: admin
    @elevation-reason: DHCP Server cmdlets require Administrator privileges
    Requires: DHCP Server role installed, RSAT DHCP tools

Compliance Mapping:
- CIS Controls: 1.4 (Use DHCP Logging), 12.1 (Network Segmentation)
- CIS Windows Server 2022: 5.x (System Services - DHCP)
- NIST SP 800-53: SC-7 (Boundary Protection), AU-2 (Audit Events)
- MITRE ATT&CK: T1557 (Man-in-the-Middle), T1583.006 (Acquire Infrastructure)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows DHCP Server Security Audit"

# ============================================================================
# DHCP SERVER ROLE CHECK
# ============================================================================
Write-Section "DHCP Server Role Status"

try {
    $dhcpFeature = Get-WindowsFeature -Name DHCP -ErrorAction Stop
    if ($dhcpFeature.Installed) {
        Register-Check -Name "DHCP Server Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "DHCP Server Role" -Status SKIP -Message "Not installed - skipping DHCP checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    Register-Check -Name "DHCP Server Role" -Status SKIP -Message "Cannot determine role status"
    Print-Summary
    Exit-Audit
}

# Check DHCP Server service
try {
    $dhcpSvc = Get-Service -Name DHCPServer -ErrorAction Stop
    if ($dhcpSvc.Status -eq 'Running') {
        Register-Check -Name "DHCP Server Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "DHCP Server Service" -Status FAIL -Message "Status: $($dhcpSvc.Status)"
    }

    if ($dhcpSvc.StartType -eq 'Automatic') {
        Register-Check -Name "DHCP Service Startup" -Status PASS -Message "Automatic"
    } else {
        Register-Check -Name "DHCP Service Startup" -Status WARN -Message $dhcpSvc.StartType
    }
} catch {
    Register-Check -Name "DHCP Server Service" -Status FAIL -Message "Cannot query"
}

# Import DHCP Server module
try {
    Import-Module DhcpServer -ErrorAction Stop
    Register-Check -Name "DhcpServer Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "DhcpServer Module" -Status FAIL -Message "Cannot load module"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# DHCP SERVER AUTHORIZATION
# ============================================================================
Write-Section "DHCP Authorization and Database"

try {
    # Check if authorized in AD
    $authorized = Get-DhcpServerInDC -ErrorAction SilentlyContinue
    $serverName = $env:COMPUTERNAME

    if ($authorized | Where-Object { $_.DnsName -like "*$serverName*" }) {
        Register-Check -Name "AD Authorization" -Status PASS -Message "Server authorized in Active Directory"
    } else {
        Register-Check -Name "AD Authorization" -Status WARN -Message "May not be authorized in AD"
    }
} catch {
    Register-Check -Name "AD Authorization" -Status INFO -Message "Cannot verify (may not be domain-joined)"
}

# Database configuration
try {
    $database = Get-DhcpServerDatabase -ErrorAction SilentlyContinue
    if ($database) {
        Register-Check -Name "Database Path" -Status INFO -Message $database.FileName

        # Check backup interval
        if ($database.BackupInterval -le 60) {
            Register-Check -Name "Database Backup" -Status PASS -Message "Every $($database.BackupInterval) minutes"
        } else {
            Register-Check -Name "Database Backup" -Status WARN -Message "Every $($database.BackupInterval) minutes (recommend <=60)"
        }

        # Cleanup interval
        if ($database.CleanupInterval) {
            Register-Check -Name "Database Cleanup" -Status INFO -Message "Every $($database.CleanupInterval) minutes"
        }
    }
} catch {
    Register-Check -Name "Database Config" -Status WARN -Message "Cannot query"
}

# ============================================================================
# SCOPE CONFIGURATION
# ============================================================================
Write-Section "DHCP Scopes"

try {
    $scopes = Get-DhcpServerv4Scope -ErrorAction Stop

    if ($scopes) {
        Register-Check -Name "IPv4 Scopes" -Status INFO -Message "$($scopes.Count) scope(s) configured"

        foreach ($scope in $scopes) {
            $scopeId = $scope.ScopeId
            $scopeName = $scope.Name

            # Scope state
            if ($scope.State -eq 'Active') {
                Register-Check -Name "Scope $scopeId" -Status INFO -Message "Active: $scopeName"
            } else {
                Register-Check -Name "Scope $scopeId" -Status INFO -Message "Inactive: $scopeName"
            }

            # Lease duration (best practice: not too long)
            $leaseDays = $scope.LeaseDuration.TotalDays
            if ($leaseDays -le 8) {
                Register-Check -Name "Lease Duration: $scopeId" -Status PASS -Message "$leaseDays days"
            } elseif ($leaseDays -le 30) {
                Register-Check -Name "Lease Duration: $scopeId" -Status INFO -Message "$leaseDays days"
            } else {
                Register-Check -Name "Lease Duration: $scopeId" -Status WARN -Message "$leaseDays days (consider shorter)"
            }

            # Check exclusion ranges
            $exclusions = Get-DhcpServerv4ExclusionRange -ScopeId $scopeId -ErrorAction SilentlyContinue
            if ($exclusions) {
                Register-Check -Name "Exclusions: $scopeId" -Status PASS -Message "$($exclusions.Count) range(s) excluded"
            }

            # Check reservations
            $reservations = Get-DhcpServerv4Reservation -ScopeId $scopeId -ErrorAction SilentlyContinue
            if ($reservations) {
                Register-Check -Name "Reservations: $scopeId" -Status INFO -Message "$($reservations.Count) reservation(s)"
            }
        }
    } else {
        Register-Check -Name "IPv4 Scopes" -Status INFO -Message "No scopes configured"
    }

} catch {
    Register-Check -Name "Scope Configuration" -Status WARN -Message "Cannot query scopes"
}

# IPv6 Scopes
try {
    $scopesV6 = Get-DhcpServerv6Scope -ErrorAction SilentlyContinue
    if ($scopesV6) {
        Register-Check -Name "IPv6 Scopes" -Status INFO -Message "$($scopesV6.Count) IPv6 scope(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# DHCP OPTIONS SECURITY
# ============================================================================
Write-Section "DHCP Options Security"

try {
    # Server-level options
    $serverOptions = Get-DhcpServerv4OptionValue -ErrorAction SilentlyContinue

    if ($serverOptions) {
        # DNS Server options (Option 6)
        $dnsOption = $serverOptions | Where-Object { $_.OptionId -eq 6 }
        if ($dnsOption) {
            Register-Check -Name "DNS Server Option" -Status INFO -Message "Configured: $($dnsOption.Value -join ', ')"
        }

        # Router/Gateway (Option 3)
        $routerOption = $serverOptions | Where-Object { $_.OptionId -eq 3 }
        if ($routerOption) {
            Register-Check -Name "Router Option" -Status INFO -Message "Configured: $($routerOption.Value -join ', ')"
        }

        # Domain Name (Option 15)
        $domainOption = $serverOptions | Where-Object { $_.OptionId -eq 15 }
        if ($domainOption) {
            Register-Check -Name "Domain Name Option" -Status INFO -Message $domainOption.Value
        }

        # WPAD/PAC (Option 252) - security concern
        $wpadOption = $serverOptions | Where-Object { $_.OptionId -eq 252 }
        if ($wpadOption) {
            Register-Check -Name "WPAD Option 252" -Status WARN -Message "Configured - review for security"
        } else {
            Register-Check -Name "WPAD Option 252" -Status PASS -Message "Not configured"
        }
    }

} catch {
    Register-Check -Name "DHCP Options" -Status WARN -Message "Cannot query"
}

# ============================================================================
# DNS INTEGRATION
# ============================================================================
Write-Section "DNS Integration"

try {
    $dnsCreds = Get-DhcpServerDnsCredential -ErrorAction SilentlyContinue
    if ($dnsCreds) {
        Register-Check -Name "DNS Credentials" -Status PASS -Message "Configured for secure DNS updates"
    } else {
        Register-Check -Name "DNS Credentials" -Status INFO -Message "Using server account for DNS updates"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

try {
    # DNS update settings
    $dnsSettings = Get-DhcpServerv4DnsSetting -ErrorAction SilentlyContinue
    if ($dnsSettings) {
        if ($dnsSettings.DynamicUpdates -eq 'Always') {
            Register-Check -Name "DNS Dynamic Updates" -Status INFO -Message "Always perform updates"
        } elseif ($dnsSettings.DynamicUpdates -eq 'OnClientRequest') {
            Register-Check -Name "DNS Dynamic Updates" -Status PASS -Message "On client request only"
        } else {
            Register-Check -Name "DNS Dynamic Updates" -Status INFO -Message $dnsSettings.DynamicUpdates
        }

        if ($dnsSettings.DeleteDnsRROnLeaseExpiry -eq $true) {
            Register-Check -Name "DNS Cleanup on Expiry" -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name "DNS Cleanup on Expiry" -Status WARN -Message "Disabled - stale records may accumulate"
        }

        # Name protection
        if ($dnsSettings.NameProtection -eq $true) {
            Register-Check -Name "Name Protection" -Status PASS -Message "Enabled (prevents name squatting)"
        } else {
            Register-Check -Name "Name Protection" -Status WARN -Message "Disabled"
        }
    }
} catch {
    Register-Check -Name "DNS Settings" -Status WARN -Message "Cannot query"
}

# ============================================================================
# FAILOVER CONFIGURATION
# ============================================================================
Write-Section "Failover Configuration"

try {
    $failover = Get-DhcpServerv4Failover -ErrorAction SilentlyContinue

    if ($failover) {
        foreach ($fo in $failover) {
            Register-Check -Name "Failover: $($fo.Name)" -Status PASS -Message "Partner: $($fo.PartnerServer)"
            Register-Check -Name "Failover Mode" -Status INFO -Message $fo.Mode
            Register-Check -Name "Failover State" -Status INFO -Message $fo.State

            # Check shared secret
            if ($fo.SharedSecret) {
                Register-Check -Name "Failover Authentication" -Status PASS -Message "Shared secret configured"
            } else {
                Register-Check -Name "Failover Authentication" -Status WARN -Message "No shared secret"
            }
        }
    } else {
        Register-Check -Name "DHCP Failover" -Status INFO -Message "Not configured"
    }

} catch {
    Register-Check -Name "Failover" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# AUDIT AND LOGGING
# ============================================================================
Write-Section "DHCP Audit and Logging"

try {
    $auditLog = Get-DhcpServerAuditLog -ErrorAction Stop

    if ($auditLog.Enable -eq $true) {
        Register-Check -Name "Audit Logging" -Status PASS -Message "Enabled"
        Register-Check -Name "Audit Log Path" -Status INFO -Message $auditLog.Path

        # Disk check interval
        if ($auditLog.DiskCheckInterval -le 60) {
            Register-Check -Name "Disk Check Interval" -Status PASS -Message "$($auditLog.DiskCheckInterval) minutes"
        }

        # Max log file size
        if ($auditLog.MaxMBFileSize -ge 20) {
            Register-Check -Name "Max Log Size" -Status PASS -Message "$($auditLog.MaxMBFileSize) MB"
        } else {
            Register-Check -Name "Max Log Size" -Status WARN -Message "$($auditLog.MaxMBFileSize) MB (recommend 20+ MB)"
        }

        # Min disk space
        if ($auditLog.MinMBDiskSpace -ge 10) {
            Register-Check -Name "Min Disk Space" -Status PASS -Message "$($auditLog.MinMBDiskSpace) MB reserved"
        }
    } else {
        Register-Check -Name "Audit Logging" -Status FAIL -Message "Disabled - enable for compliance"
    }

} catch {
    Register-Check -Name "Audit Logging" -Status WARN -Message "Cannot query"
}

# Check Windows Event logging
try {
    $dhcpLog = Get-WinEvent -ListLog "Microsoft-Windows-Dhcp-Server/Operational" -ErrorAction SilentlyContinue
    if ($dhcpLog -and $dhcpLog.IsEnabled) {
        Register-Check -Name "Operational Event Log" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Operational Event Log" -Status WARN -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for MAC address filtering (policies)
try {
    $policies = Get-DhcpServerv4Policy -ErrorAction SilentlyContinue
    if ($policies) {
        Register-Check -Name "DHCP Policies" -Status PASS -Message "$($policies.Count) policy/policies configured"
        foreach ($policy in $policies) {
            if ($policy.Enabled) {
                Register-Check -Name "Policy: $($policy.Name)" -Status INFO -Message "Enabled"
            }
        }
    } else {
        Register-Check -Name "DHCP Policies" -Status INFO -Message "None configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for filters (allow/deny lists)
try {
    $filterStatus = Get-DhcpServerv4FilterList -ErrorAction SilentlyContinue

    if ($filterStatus.Allow -eq $true) {
        $allowList = Get-DhcpServerv4Filter -List Allow -ErrorAction SilentlyContinue
        if ($allowList) {
            Register-Check -Name "MAC Allow List" -Status PASS -Message "Enabled with $($allowList.Count) entries"
        } else {
            Register-Check -Name "MAC Allow List" -Status WARN -Message "Enabled but empty"
        }
    }

    if ($filterStatus.Deny -eq $true) {
        $denyList = Get-DhcpServerv4Filter -List Deny -ErrorAction SilentlyContinue
        if ($denyList) {
            Register-Check -Name "MAC Deny List" -Status PASS -Message "Enabled with $($denyList.Count) entries"
        }
    }

    if (-not $filterStatus.Allow -and -not $filterStatus.Deny) {
        Register-Check -Name "MAC Filtering" -Status INFO -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check conflict detection
try {
    $setting = Get-DhcpServerSetting -ErrorAction SilentlyContinue
    if ($setting.ConflictDetectionAttempts -gt 0) {
        Register-Check -Name "Conflict Detection" -Status PASS -Message "$($setting.ConflictDetectionAttempts) ping attempts"
    } else {
        Register-Check -Name "Conflict Detection" -Status INFO -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Network Access Protection (deprecated but check)
try {
    $nap = Get-DhcpServerv4Class -Type Vendor -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*NAP*' }
    if ($nap) {
        Register-Check -Name "NAP Classes" -Status INFO -Message "NAP vendor classes present (deprecated)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# IPv6 Stateless configuration
try {
    $v6Setting = Get-DhcpServerv6Setting -ErrorAction SilentlyContinue
    if ($v6Setting) {
        Register-Check -Name "IPv6 DHCP" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
