<#
.SYNOPSIS
    Windows DNS Server Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows DNS Server role:
    - DNS service configuration
    - Zone security and transfers
    - DNSSEC configuration
    - DNS logging and diagnostics
    - Socket pool and cache security
    - Forwarder configuration
    - Response Rate Limiting (RRL)

.NOTES
    @elevation: admin
    @elevation-reason: DNS Server cmdlets require Administrator privileges
    Requires: DNS Server role installed, RSAT DNS tools

Compliance Mapping:
- CIS Controls: 4.9 (Configure DNS Logging), 9.2 (DNS Security)
- CIS Windows Server 2022: 5.x (System Services - DNS)
- NIST SP 800-53: SC-20 (Secure Name/Address Resolution), SC-21 (Secure Name/Address Auth)
- NIST SP 800-81: Secure DNS Deployment Guide
- MITRE ATT&CK: T1071.004 (DNS Protocol), T1568 (Dynamic Resolution)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows DNS Server Security Audit"

# ============================================================================
# DNS SERVER ROLE CHECK
# ============================================================================
Write-Section "DNS Server Role Status"

try {
    $dnsFeature = Get-WindowsFeature -Name DNS -ErrorAction Stop
    if ($dnsFeature.Installed) {
        Register-Check -Name "DNS Server Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "DNS Server Role" -Status SKIP -Message "Not installed - skipping DNS checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    Register-Check -Name "DNS Server Role" -Status SKIP -Message "Cannot determine role status"
    Print-Summary
    Exit-Audit
}

# Check DNS Server service
try {
    $dnsSvc = Get-Service -Name DNS -ErrorAction Stop
    if ($dnsSvc.Status -eq 'Running') {
        Register-Check -Name "DNS Server Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "DNS Server Service" -Status FAIL -Message "Status: $($dnsSvc.Status)"
    }

    if ($dnsSvc.StartType -eq 'Automatic') {
        Register-Check -Name "DNS Service Startup" -Status PASS -Message "Automatic"
    } else {
        Register-Check -Name "DNS Service Startup" -Status WARN -Message $dnsSvc.StartType
    }
} catch {
    Register-Check -Name "DNS Server Service" -Status FAIL -Message "Cannot query"
}

# Import DNS Server module
try {
    Import-Module DnsServer -ErrorAction Stop
    Register-Check -Name "DnsServer Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "DnsServer Module" -Status FAIL -Message "Cannot load module"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# DNS SERVER CONFIGURATION
# ============================================================================
Write-Section "DNS Server Configuration"

try {
    Get-DnsServer -ErrorAction Stop | Out-Null
    $dnsServerSetting = Get-DnsServerSetting -ErrorAction Stop

    # Listening addresses
    $listenAddresses = $dnsServerSetting.ListeningIPAddress
    if ($listenAddresses -and $listenAddresses.Count -gt 0 -and $listenAddresses -notcontains "0.0.0.0") {
        Register-Check -Name "Listening IP Addresses" -Status PASS -Message "Restricted: $($listenAddresses -join ', ')"
    } else {
        Register-Check -Name "Listening IP Addresses" -Status INFO -Message "Listening on all interfaces"
    }

    # Recursion settings (CIS recommendation: disable if authoritative only)
    $recursion = Get-DnsServerRecursion -ErrorAction SilentlyContinue
    if ($recursion.Enable -eq $false) {
        Register-Check -Name "Recursion" -Status PASS -Message "Disabled (authoritative only)"
    } else {
        Register-Check -Name "Recursion" -Status INFO -Message "Enabled - ensure restricted if not needed"
    }

    # Root hints
    $rootHints = Get-DnsServerRootHint -ErrorAction SilentlyContinue
    if ($rootHints) {
        Register-Check -Name "Root Hints" -Status INFO -Message "$($rootHints.Count) root servers configured"
    }

} catch {
    Register-Check -Name "DNS Server Config" -Status WARN -Message "Cannot query configuration"
}

# ============================================================================
# SOCKET POOL AND CACHE SECURITY
# ============================================================================
Write-Section "Socket Pool and Cache Security"

try {
    # Socket pool size (NIST 800-81: larger pool = harder to predict)
    $socketPool = (Get-DnsServerSetting).SocketPoolSize
    if ($socketPool -ge 2500) {
        Register-Check -Name "Socket Pool Size" -Status PASS -Message "$socketPool (recommended 2500+)"
    } else {
        Register-Check -Name "Socket Pool Size" -Status WARN -Message "$socketPool (recommend 2500+)"
    }

    # Socket pool exclusion ranges
    $exclusions = (Get-DnsServerSetting).SocketPoolExcludedPortRanges
    if ($exclusions) {
        Register-Check -Name "Socket Pool Exclusions" -Status INFO -Message "Configured"
    }

    # Cache locking (prevents cache poisoning)
    $cacheLocking = Get-DnsServerCache -ErrorAction SilentlyContinue
    if ($cacheLocking.LockingPercent -ge 100) {
        Register-Check -Name "Cache Locking" -Status PASS -Message "$($cacheLocking.LockingPercent)% (fully locked)"
    } elseif ($cacheLocking.LockingPercent -ge 75) {
        Register-Check -Name "Cache Locking" -Status INFO -Message "$($cacheLocking.LockingPercent)%"
    } else {
        Register-Check -Name "Cache Locking" -Status WARN -Message "$($cacheLocking.LockingPercent)% (recommend 100%)"
    }

    # Max cache TTL
    if ($cacheLocking.MaxTTL) {
        $maxTTLHours = $cacheLocking.MaxTTL.TotalHours
        if ($maxTTLHours -le 24) {
            Register-Check -Name "Max Cache TTL" -Status PASS -Message "$maxTTLHours hours"
        } else {
            Register-Check -Name "Max Cache TTL" -Status INFO -Message "$maxTTLHours hours"
        }
    }

} catch {
    Register-Check -Name "Socket/Cache Security" -Status WARN -Message "Cannot query"
}

# ============================================================================
# ZONE TRANSFER SECURITY
# ============================================================================
Write-Section "Zone Transfer Security"

try {
    $zones = Get-DnsServerZone -ErrorAction Stop | Where-Object { $_.ZoneType -ne 'Forwarder' }

    Register-Check -Name "DNS Zones" -Status INFO -Message "$($zones.Count) zones configured"

    $secureZones = 0
    $insecureZones = 0

    foreach ($zone in $zones) {
        $zoneName = $zone.ZoneName

        # Check zone transfer settings
        switch ($zone.SecureSecondaries) {
            'NoTransfer' {
                $secureZones++
            }
            'TransferToZoneNameServer' {
                $secureZones++
            }
            'TransferToSecureServers' {
                $secureZones++
            }
            'TransferAnyServer' {
                $insecureZones++
                Register-Check -Name "Zone Transfer: $zoneName" -Status FAIL -Message "Allows transfer to ANY server"
            }
        }

        # Check dynamic update settings
        if ($zone.DynamicUpdate -eq 'Secure') {
            Register-Check -Name "Dynamic Update: $zoneName" -Status PASS -Message "Secure only"
        } elseif ($zone.DynamicUpdate -eq 'NonsecureAndSecure') {
            Register-Check -Name "Dynamic Update: $zoneName" -Status WARN -Message "Nonsecure allowed"
        } elseif ($zone.DynamicUpdate -eq 'None') {
            Register-Check -Name "Dynamic Update: $zoneName" -Status INFO -Message "Disabled"
        }
    }

    if ($insecureZones -eq 0 -and $secureZones -gt 0) {
        Register-Check -Name "Zone Transfer Summary" -Status PASS -Message "All $secureZones zones secured"
    } elseif ($insecureZones -gt 0) {
        Register-Check -Name "Zone Transfer Summary" -Status FAIL -Message "$insecureZones zone(s) allow unrestricted transfers"
    }

} catch {
    Register-Check -Name "Zone Security" -Status WARN -Message "Cannot query zones"
}

# ============================================================================
# DNSSEC CONFIGURATION
# ============================================================================
Write-Section "DNSSEC Configuration"

try {
    $dnssecZones = Get-DnsServerZone | Where-Object { $_.IsSigned -eq $true }

    if ($dnssecZones) {
        Register-Check -Name "DNSSEC Signed Zones" -Status PASS -Message "$($dnssecZones.Count) zone(s) signed"

        foreach ($zone in $dnssecZones) {
            $dnskey = Get-DnsServerDnsSecZoneSetting -ZoneName $zone.ZoneName -ErrorAction SilentlyContinue
            if ($dnskey) {
                Register-Check -Name "DNSSEC: $($zone.ZoneName)" -Status PASS -Message "Signed and configured"
            }
        }
    } else {
        Register-Check -Name "DNSSEC" -Status INFO -Message "No zones signed with DNSSEC"
    }

    # Trust anchors
    $trustAnchors = Get-DnsServerTrustAnchor -ErrorAction SilentlyContinue
    if ($trustAnchors) {
        Register-Check -Name "DNSSEC Trust Anchors" -Status PASS -Message "$($trustAnchors.Count) trust anchor(s)"
    } else {
        Register-Check -Name "DNSSEC Trust Anchors" -Status INFO -Message "None configured"
    }

} catch {
    Register-Check -Name "DNSSEC" -Status SKIP -Message "Cannot query DNSSEC configuration"
}

# ============================================================================
# FORWARDERS AND CONDITIONAL FORWARDERS
# ============================================================================
Write-Section "Forwarders Configuration"

try {
    $forwarders = Get-DnsServerForwarder -ErrorAction SilentlyContinue

    if ($forwarders -and $forwarders.IPAddress) {
        Register-Check -Name "Forwarders" -Status INFO -Message "$($forwarders.IPAddress.Count) forwarder(s) configured"

        # Check for well-known secure DNS providers
        $secureDNS = @('8.8.8.8', '8.8.4.4', '1.1.1.1', '1.0.0.1', '9.9.9.9', '149.112.112.112')
        $hasSecureDNS = $forwarders.IPAddress | Where-Object { $_ -in $secureDNS }

        if ($hasSecureDNS) {
            Register-Check -Name "Secure DNS Forwarders" -Status PASS -Message "Using known secure DNS providers"
        }

        # Check use root hints if forwarders unavailable
        if ($forwarders.UseRootHint -eq $true) {
            Register-Check -Name "Forwarder Fallback" -Status INFO -Message "Falls back to root hints"
        }
    } else {
        Register-Check -Name "Forwarders" -Status INFO -Message "Not configured (using root hints)"
    }

    # Conditional forwarders
    $conditionalForwarders = Get-DnsServerZone | Where-Object { $_.ZoneType -eq 'Forwarder' }
    if ($conditionalForwarders) {
        Register-Check -Name "Conditional Forwarders" -Status INFO -Message "$($conditionalForwarders.Count) configured"
    }

} catch {
    Register-Check -Name "Forwarders" -Status WARN -Message "Cannot query"
}

# ============================================================================
# RESPONSE RATE LIMITING (RRL)
# ============================================================================
Write-Section "Response Rate Limiting (RRL)"

try {
    $rrl = Get-DnsServerResponseRateLimiting -ErrorAction SilentlyContinue

    if ($rrl) {
        if ($rrl.Mode -eq 'Enable') {
            Register-Check -Name "RRL Status" -Status PASS -Message "Enabled"
            Register-Check -Name "RRL Responses/Sec" -Status INFO -Message "Limit: $($rrl.ResponsesPerSec)"
            Register-Check -Name "RRL Errors/Sec" -Status INFO -Message "Limit: $($rrl.ErrorsPerSec)"
        } elseif ($rrl.Mode -eq 'LogOnly') {
            Register-Check -Name "RRL Status" -Status WARN -Message "LogOnly mode (not enforcing)"
        } else {
            Register-Check -Name "RRL Status" -Status FAIL -Message "Disabled - vulnerable to amplification attacks"
        }
    } else {
        Register-Check -Name "RRL Status" -Status WARN -Message "Not configured"
    }

} catch {
    Register-Check -Name "RRL" -Status SKIP -Message "Cannot query (may require newer Windows Server)"
}

# ============================================================================
# DNS LOGGING AND DIAGNOSTICS
# ============================================================================
Write-Section "DNS Logging and Diagnostics"

try {
    $diagnostics = Get-DnsServerDiagnostics -ErrorAction Stop

    # Query logging
    if ($diagnostics.Queries -eq $true) {
        Register-Check -Name "Query Logging" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Query Logging" -Status WARN -Message "Disabled - limited visibility"
    }

    # Answer logging
    if ($diagnostics.Answers -eq $true) {
        Register-Check -Name "Answer Logging" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Answer Logging" -Status INFO -Message "Disabled"
    }

    # Notification logging
    if ($diagnostics.Notifications -eq $true) {
        Register-Check -Name "Notification Logging" -Status PASS -Message "Enabled"
    }

    # Update logging
    if ($diagnostics.Update -eq $true) {
        Register-Check -Name "Update Logging" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Update Logging" -Status WARN -Message "Disabled"
    }

    # Audit logging
    if ($diagnostics.EnableLoggingToFile -eq $true) {
        Register-Check -Name "File Logging" -Status PASS -Message "Enabled: $($diagnostics.LogFilePath)"

        # Log file size
        if ($diagnostics.MaxMBFileSize -ge 50) {
            Register-Check -Name "Log File Size" -Status PASS -Message "$($diagnostics.MaxMBFileSize) MB"
        } else {
            Register-Check -Name "Log File Size" -Status WARN -Message "$($diagnostics.MaxMBFileSize) MB (recommend 50+ MB)"
        }
    } else {
        Register-Check -Name "File Logging" -Status WARN -Message "Disabled"
    }

} catch {
    Register-Check -Name "DNS Diagnostics" -Status WARN -Message "Cannot query"
}

# Check DNS Analytical logging via Event Log
try {
    $analyticalLog = Get-WinEvent -ListLog "Microsoft-Windows-DNS-Server/Analytical" -ErrorAction SilentlyContinue
    if ($analyticalLog -and $analyticalLog.IsEnabled) {
        Register-Check -Name "DNS Analytical Log" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "DNS Analytical Log" -Status INFO -Message "Not enabled (high volume)"
    }
} catch {
    Register-Check -Name "DNS Analytical Log" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for GlobalNames zone (potential security concern)
try {
    $globalNames = Get-DnsServerGlobalNameZone -ErrorAction SilentlyContinue
    if ($globalNames.Enable -eq $true) {
        Register-Check -Name "GlobalNames Zone" -Status WARN -Message "Enabled - review if needed"
    } else {
        Register-Check -Name "GlobalNames Zone" -Status PASS -Message "Disabled"
    }
} catch {
    Register-Check -Name "GlobalNames Zone" -Status INFO -Message "Not configured"
}

# Check scavenging settings
try {
    $scavenging = Get-DnsServerScavenging -ErrorAction SilentlyContinue
    if ($scavenging.ScavengingState -eq $true) {
        Register-Check -Name "Scavenging" -Status PASS -Message "Enabled (removes stale records)"
        Register-Check -Name "Scavenging Interval" -Status INFO -Message "$($scavenging.ScavengingInterval.Days) days"
    } else {
        Register-Check -Name "Scavenging" -Status WARN -Message "Disabled - stale records may accumulate"
    }
} catch {
    Register-Check -Name "Scavenging" -Status SKIP -Message "Cannot query"
}

# Check for DNS server on domain controller
try {
    $domainRole = (Get-CimInstance -ClassName Win32_ComputerSystem).DomainRole
    if ($domainRole -ge 4) {
        Register-Check -Name "DNS on DC" -Status INFO -Message "Running on Domain Controller (common for AD-integrated)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# EDns settings
try {
    $edns = (Get-DnsServerSetting).EnableEDnsProbes
    if ($edns -eq $true) {
        Register-Check -Name "EDNS Probes" -Status PASS -Message "Enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
