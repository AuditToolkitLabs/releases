<#
.SYNOPSIS
    Windows Failover Clustering Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows Failover Clustering:
    - Cluster service configuration
    - Quorum configuration
    - Cluster network security
    - Cluster Shared Volumes (CSV)
    - Witness configuration
    - Cluster roles security
    - Cluster authentication
    - Logging and monitoring

.NOTES
    @elevation: admin
    @elevation-reason: Failover Cluster cmdlets require Administrator privileges
    Requires: Failover Clustering feature installed

Compliance Mapping:
- CIS Controls: 11.1 (Secure Configuration for Network Devices)
- CIS Windows Server 2022: Section 5 (System Services)
- NIST SP 800-53: SC-7 (Boundary Protection), SC-24 (Fail in Known State)
- Microsoft Security Baseline for Failover Clustering
- MITRE ATT&CK: T1489 (Service Stop), T1499 (Endpoint Denial of Service)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows Failover Clustering Security Audit"

# ============================================================================
# CLUSTERING FEATURE CHECK
# ============================================================================
Write-Section "Failover Clustering Status"

$isClusterNode = $false

try {
    $clusterFeature = Get-WindowsFeature -Name Failover-Clustering -ErrorAction Stop
    if ($clusterFeature.Installed) {
        Register-Check -Name "Failover Clustering" -Status PASS -Message "Feature installed"
    } else {
        Register-Check -Name "Failover Clustering" -Status SKIP -Message "Not installed"
        Print-Summary
        Exit-Audit
    }
} catch {
    Register-Check -Name "Failover Clustering" -Status SKIP -Message "Cannot determine feature status"
    Print-Summary
    Exit-Audit
}

# Check cluster service
try {
    $clusterSvc = Get-Service -Name ClusSvc -ErrorAction Stop
    if ($clusterSvc.Status -eq 'Running') {
        $isClusterNode = $true
        Register-Check -Name "Cluster Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "Cluster Service" -Status INFO -Message "Status: $($clusterSvc.Status)"
    }
} catch {
    Register-Check -Name "Cluster Service" -Status INFO -Message "Not configured on this node"
}

# Import module
try {
    Import-Module FailoverClusters -ErrorAction Stop
    Register-Check -Name "FailoverClusters Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "FailoverClusters Module" -Status WARN -Message "Cannot load module"
}

if (-not $isClusterNode) {
    Register-Check -Name "Cluster Membership" -Status INFO -Message "Node is not part of a cluster"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# CLUSTER CONFIGURATION
# ============================================================================
Write-Section "Cluster Configuration"

try {
    $cluster = Get-Cluster -ErrorAction Stop

    Register-Check -Name "Cluster Name" -Status INFO -Message $cluster.Name
    Register-Check -Name "Cluster Domain" -Status INFO -Message $cluster.Domain

    # Cluster functional level
    $functionalLevel = $cluster.ClusterFunctionalLevel
    Register-Check -Name "Functional Level" -Status INFO -Message $functionalLevel

    # Admin access point (affects security)
    if ($cluster.AdministrativeAccessPoint -eq 'Dns') {
        Register-Check -Name "Admin Access Point" -Status INFO -Message "DNS (distributed)"
    } else {
        Register-Check -Name "Admin Access Point" -Status INFO -Message $cluster.AdministrativeAccessPoint
    }

} catch {
    Register-Check -Name "Cluster Config" -Status WARN -Message "Cannot query cluster"
}

# ============================================================================
# CLUSTER NODES
# ============================================================================
Write-Section "Cluster Nodes"

try {
    $nodes = Get-ClusterNode -ErrorAction Stop

    Register-Check -Name "Cluster Nodes" -Status INFO -Message "$($nodes.Count) node(s)"

    $onlineNodes = ($nodes | Where-Object { $_.State -eq 'Up' }).Count
    $offlineNodes = $nodes.Count - $onlineNodes

    if ($offlineNodes -eq 0) {
        Register-Check -Name "Node Status" -Status PASS -Message "All $($nodes.Count) nodes up"
    } elseif ($offlineNodes -lt $nodes.Count / 2) {
        Register-Check -Name "Node Status" -Status WARN -Message "$onlineNodes up, $offlineNodes down"
    } else {
        Register-Check -Name "Node Status" -Status FAIL -Message "$onlineNodes up, $offlineNodes down"
    }

    # Check for paused nodes
    $pausedNodes = ($nodes | Where-Object { $_.State -eq 'Paused' }).Count
    if ($pausedNodes -gt 0) {
        Register-Check -Name "Paused Nodes" -Status INFO -Message "$pausedNodes node(s) paused"
    }

    # Check node build versions match
    $versions = $nodes | Select-Object -ExpandProperty BuildNumber -Unique
    if ($versions.Count -eq 1) {
        Register-Check -Name "Node Versions" -Status PASS -Message "Consistent across cluster"
    } else {
        Register-Check -Name "Node Versions" -Status WARN -Message "Mixed versions detected"
    }

} catch {
    Register-Check -Name "Cluster Nodes" -Status WARN -Message "Cannot query nodes"
}

# ============================================================================
# QUORUM CONFIGURATION
# ============================================================================
Write-Section "Quorum Configuration"

try {
    $quorum = Get-ClusterQuorum -ErrorAction Stop

    # Quorum type
    $quorumType = $quorum.QuorumType
    Register-Check -Name "Quorum Type" -Status INFO -Message $quorumType

    # Quorum resource
    if ($quorum.QuorumResource) {
        Register-Check -Name "Quorum Resource" -Status INFO -Message $quorum.QuorumResource.Name
    }

    # Check if witness configured (required for even node count)
    $nodeCount = (Get-ClusterNode -ErrorAction SilentlyContinue).Count
    $hasWitness = $quorumType -match 'Witness|File|Cloud|Disk'

    if ($nodeCount % 2 -eq 0) {
        # Even node count - witness recommended
        if ($hasWitness) {
            Register-Check -Name "Witness Configuration" -Status PASS -Message "Configured for even node count"
        } else {
            Register-Check -Name "Witness Configuration" -Status WARN -Message "Recommended for even node count"
        }
    } else {
        # Odd node count
        if ($hasWitness) {
            Register-Check -Name "Witness Configuration" -Status PASS -Message "Additional witness configured"
        } else {
            Register-Check -Name "Witness Configuration" -Status INFO -Message "Not required for odd node count"
        }
    }

    # Check witness type security
    if ($quorumType -match 'FileShareWitness') {
        Register-Check -Name "File Share Witness" -Status INFO -Message "Ensure SMB signing enabled"
    } elseif ($quorumType -match 'CloudWitness') {
        Register-Check -Name "Cloud Witness" -Status PASS -Message "Azure blob storage (secure)"
    } elseif ($quorumType -match 'DiskWitness') {
        Register-Check -Name "Disk Witness" -Status INFO -Message "Shared storage witness"
    }

} catch {
    Register-Check -Name "Quorum" -Status WARN -Message "Cannot query quorum configuration"
}

# ============================================================================
# CLUSTER NETWORKS
# ============================================================================
Write-Section "Cluster Networks"

try {
    $networks = Get-ClusterNetwork -ErrorAction Stop

    Register-Check -Name "Cluster Networks" -Status INFO -Message "$($networks.Count) network(s)"

    foreach ($network in $networks) {
        $netName = $network.Name
        $role = $network.Role

        switch ($role) {
            0 { # None
                Register-Check -Name "Network: $netName" -Status INFO -Message "Not used by cluster"
            }
            1 { # Cluster only
                Register-Check -Name "Network: $netName" -Status PASS -Message "Cluster-only (internal)"
            }
            3 { # Cluster and client
                Register-Check -Name "Network: $netName" -Status INFO -Message "Cluster and client"
            }
        }

        # Network state
        if ($network.State -ne 'Up') {
            Register-Check -Name "Network State: $netName" -Status WARN -Message $network.State
        }
    }

    # Check for dedicated cluster network (best practice)
    $clusterOnlyNetworks = $networks | Where-Object { $_.Role -eq 1 }
    if ($clusterOnlyNetworks) {
        Register-Check -Name "Dedicated Cluster Network" -Status PASS -Message "Present"
    } else {
        Register-Check -Name "Dedicated Cluster Network" -Status WARN -Message "Consider dedicated heartbeat network"
    }

} catch {
    Register-Check -Name "Cluster Networks" -Status WARN -Message "Cannot query"
}

# ============================================================================
# CLUSTER SHARED VOLUMES (CSV)
# ============================================================================
Write-Section "Cluster Shared Volumes"

try {
    $csvs = Get-ClusterSharedVolume -ErrorAction SilentlyContinue

    if ($csvs) {
        Register-Check -Name "Cluster Shared Volumes" -Status INFO -Message "$($csvs.Count) CSV(s)"

        foreach ($csv in $csvs) {
            $csvName = $csv.Name
            $state = $csv.State

            if ($state -eq 'Online') {
                Register-Check -Name "CSV: $csvName" -Status PASS -Message "Online"
            } else {
                Register-Check -Name "CSV: $csvName" -Status WARN -Message $state
            }

            # Check CSV state details
            $csvStateInfo = $csv.SharedVolumeInfo | Select-Object -First 1
            if ($csvStateInfo) {
                $faultState = $csvStateInfo.FaultState
                if ($faultState -ne 'NoFaults') {
                    Register-Check -Name "CSV Fault: $csvName" -Status WARN -Message $faultState
                }

                # Redirected access (performance concern)
                if ($csvStateInfo.Redirected -eq $true) {
                    Register-Check -Name "CSV Redirected: $csvName" -Status WARN -Message "Direct I/O not available"
                }
            }
        }

        # Check CSV encryption (Server 2019+)
        try {
            $csvEncryption = Get-ClusterSharedVolumeState -ErrorAction SilentlyContinue |
                Where-Object { $_.FileSystemRedirectedIOReason -eq 'EncryptionRequired' }
            if ($csvEncryption) {
                Register-Check -Name "CSV Encryption" -Status PASS -Message "In-transit encryption enabled"
            }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }

    } else {
        Register-Check -Name "Cluster Shared Volumes" -Status INFO -Message "None configured"
    }

} catch {
    Register-Check -Name "CSV" -Status SKIP -Message "Cannot query"
}

# ============================================================================
# CLUSTER ROLES (RESOURCES)
# ============================================================================
Write-Section "Cluster Roles"

try {
    $roles = Get-ClusterGroup -ErrorAction Stop

    if ($roles) {
        ($roles | Where-Object { $_.State -eq 'Online' }).Count | Out-Null
        $offlineRoles = ($roles | Where-Object { $_.State -eq 'Offline' }).Count
        $failedRoles = ($roles | Where-Object { $_.State -eq 'Failed' }).Count

        Register-Check -Name "Cluster Roles" -Status INFO -Message "$($roles.Count) total"

        if ($failedRoles -gt 0) {
            Register-Check -Name "Failed Roles" -Status FAIL -Message "$failedRoles role(s) failed"
        }

        if ($offlineRoles -gt 0) {
            Register-Check -Name "Offline Roles" -Status INFO -Message "$offlineRoles role(s) offline"
        }

        # Check for single point of failure
        $nodeOwnership = $roles | Group-Object OwnerNode
        $maxOnOneNode = ($nodeOwnership | Measure-Object -Property Count -Maximum).Maximum

        if ($maxOnOneNode -eq $roles.Count -and $roles.Count -gt 1) {
            Register-Check -Name "Role Distribution" -Status WARN -Message "All roles on single node"
        } else {
            Register-Check -Name "Role Distribution" -Status INFO -Message "Distributed across nodes"
        }
    }

} catch {
    Register-Check -Name "Cluster Roles" -Status WARN -Message "Cannot query"
}

# ============================================================================
# CLUSTER AUTHENTICATION AND ACCESS
# ============================================================================
Write-Section "Cluster Security"

# Cluster access permissions
try {
    $clusterAccess = Get-ClusterAccess -ErrorAction SilentlyContinue
    if ($clusterAccess) {
        Register-Check -Name "Cluster Access" -Status INFO -Message "$($clusterAccess.Count) principal(s) with access"

        # Check for broad access
        $everyoneAccess = $clusterAccess | Where-Object { $_.Identity -match 'Everyone|Authenticated Users' }
        if ($everyoneAccess) {
            Register-Check -Name "Broad Cluster Access" -Status WARN -Message "Everyone/Authenticated Users has access"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Kerberos authentication
try {
    $cluster = Get-Cluster -ErrorAction SilentlyContinue
    if ($cluster.EnableSharedVolumes -eq 1) {
        Register-Check -Name "Kerberos for CSV" -Status INFO -Message "Cluster uses Kerberos for CSV authentication"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Cluster account (CNO)
try {
    $clusterName = (Get-Cluster).Name
    $cno = Get-ADComputer -Identity $clusterName -ErrorAction SilentlyContinue
    if ($cno) {
        if ($cno.Enabled -eq $true) {
            Register-Check -Name "Cluster Name Object" -Status PASS -Message "Active in AD"
        } else {
            Register-Check -Name "Cluster Name Object" -Status FAIL -Message "Disabled in AD"
        }
    }
} catch {
    Register-Check -Name "Cluster Name Object" -Status INFO -Message "Cannot verify AD status"
}

# ============================================================================
# LOGGING AND MONITORING
# ============================================================================
Write-Section "Logging and Monitoring"

# Cluster log
try {
    $clusterLogPath = "$env:SystemRoot\Cluster\Reports"
    if (Test-Path $clusterLogPath) {
        $recentLogs = Get-ChildItem -Path $clusterLogPath -Filter "*.log" -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1

        if ($recentLogs) {
            $logAge = ((Get-Date) - $recentLogs.LastWriteTime).Days
            if ($logAge -lt 7) {
                Register-Check -Name "Cluster Logs" -Status PASS -Message "Recent logs available"
            } else {
                Register-Check -Name "Cluster Logs" -Status INFO -Message "Last log $logAge days ago"
            }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Event log
try {
    $clusterLog = Get-WinEvent -ListLog "Microsoft-Windows-FailoverClustering/Operational" -ErrorAction SilentlyContinue
    if ($clusterLog -and $clusterLog.IsEnabled) {
        Register-Check -Name "Cluster Event Log" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "Cluster Event Log" -Status WARN -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Diagnostic log
try {
    $diagLog = Get-WinEvent -ListLog "Microsoft-Windows-FailoverClustering/Diagnostic" -ErrorAction SilentlyContinue
    if ($diagLog -and $diagLog.IsEnabled) {
        Register-Check -Name "Diagnostic Log" -Status INFO -Message "Enabled (verbose)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# BEST PRACTICES
# ============================================================================
Write-Section "Best Practices"

# Anti-affinity
try {
    $antiAffinity = Get-ClusterGroup | Where-Object { $_.AntiAffinityClassNames -ne $null }
    if ($antiAffinity) {
        Register-Check -Name "Anti-Affinity Rules" -Status PASS -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Preferred owners
try {
    $preferredOwners = Get-ClusterGroup | Where-Object { $_.PreferredOwner -ne $null }
    if ($preferredOwners) {
        Register-Check -Name "Preferred Owners" -Status INFO -Message "Configured for some roles"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Failover threshold
try {
    $cluster = Get-Cluster -ErrorAction SilentlyContinue
    if ($cluster.FailoverThreshold) {
        Register-Check -Name "Failover Threshold" -Status INFO -Message "$($cluster.FailoverThreshold) in $($cluster.FailoverPeriod) seconds"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Witness file share permissions (if applicable)
try {
    $quorum = Get-ClusterQuorum -ErrorAction SilentlyContinue
    if ($quorum.QuorumResource.ResourceType.Name -eq 'File Share Witness') {
        Register-Check -Name "File Share Witness" -Status INFO -Message "Verify NTFS and share permissions are restricted"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# CAU (Cluster-Aware Updating)
try {
    $cauStatus = Get-CauClusterRole -ErrorAction SilentlyContinue
    if ($cauStatus) {
        if ($cauStatus.Status -eq 'Installed') {
            Register-Check -Name "Cluster-Aware Updating" -Status PASS -Message "Configured"
        }
    } else {
        Register-Check -Name "Cluster-Aware Updating" -Status INFO -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
