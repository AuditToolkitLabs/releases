# Check File Server SMB and Share Permissions
Import-Module "$PSScriptRoot/../common/common-audit.psm1"

try {
    $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin 'ADMIN$', 'C$', 'IPC$' }
    if (-not $shares -or $shares.Count -eq 0) {
        Register-Check -Name "File Server Shares" -Status PASS -Message "No non-default file shares found."
    } else {
        foreach ($share in $shares) {
            try {
                $acl = Get-SmbShareAccess -Name $share.Name
                $bad = $acl | Where-Object { $_.AccountName -eq 'Everyone' -and $_.AccessControlType -eq 'Allow' }
                if ($bad) {
                    Register-Check -Name "Share $($share.Name)" -Status FAIL -Message "Share $($share.Name) allows Everyone access."
                } else {
                    Register-Check -Name "Share $($share.Name)" -Status PASS -Message "Share $($share.Name) does not allow Everyone access."
                }
            } catch {
                Register-Check -Name "Share $($share.Name)" -Status WARN -Message $_.Exception.Message
            }
        }
    }
} catch {
    Register-Check -Name "File Server Shares" -Status WARN -Message "Unable to enumerate file shares: $($_.Exception.Message)"
}

Print-Summary
Exit-Audit