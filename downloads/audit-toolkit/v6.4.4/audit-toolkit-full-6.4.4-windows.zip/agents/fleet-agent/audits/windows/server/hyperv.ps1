# Hyper-V Security Audit Script (PowerShell)
# Comprehensive security checks for Hyper-V hosts and VMs
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft Hyper-V Benchmark
# - Microsoft Hyper-V Security Best Practices
# - NIST SP 800-125: Guide to Security for Full Virtualization Technologies

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

# ============================================================================
# HYPER-V ROLE AND FEATURE CHECK
# ============================================================================
Write-Output "=== Hyper-V Role Status ==="

# Check if Hyper-V is installed
try {
    $hyperv = Get-WindowsFeature -Name Hyper-V -ErrorAction Stop
    if ($hyperv.Installed) {
        Register-Check -Name "Hyper-V Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "Hyper-V Role" -Status SKIP -Message "Not installed - skipping Hyper-V checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    # Try Windows 10/11 method
    $hyperv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -ErrorAction SilentlyContinue
    if ($hyperv -and $hyperv.State -eq "Enabled") {
        Register-Check -Name "Hyper-V Feature" -Status PASS -Message "Enabled (Client OS)"
    } else {
        Register-Check -Name "Hyper-V Feature" -Status SKIP -Message "Not enabled - skipping Hyper-V checks"
        Print-Summary
        Exit-Audit
    }
}

# Check Hyper-V Management Tools
$mgmtTools = Get-WindowsFeature -Name Hyper-V-Tools -ErrorAction SilentlyContinue
if ($mgmtTools -and $mgmtTools.Installed) {
    Register-Check -Name "Hyper-V Management Tools" -Status PASS -Message "Installed"
} else {
    Register-Check -Name "Hyper-V Management Tools" -Status INFO -Message "Not installed on this host"
}

# ============================================================================
# HOST SECURITY CONFIGURATION
# ============================================================================
Write-Output ""
Write-Output "=== Host Security Configuration ==="

# Check Enhanced Session Mode Policy (CIS 18.9.44.1)
try {
    $vmHost = Get-VMHost -ErrorAction Stop

    # Enhanced Session Mode
    if ($vmHost.EnableEnhancedSessionMode -eq $false) {
        Register-Check -Name "Enhanced Session Mode" -Status PASS -Message "Disabled (more secure)"
    } else {
        Register-Check -Name "Enhanced Session Mode" -Status WARN -Message "Enabled - may expose clipboard/drive redirection"
    }

    # NUMA Spanning
    if ($vmHost.NumaSpanningEnabled -eq $false) {
        Register-Check -Name "NUMA Spanning" -Status PASS -Message "Disabled (better performance isolation)"
    } else {
        Register-Check -Name "NUMA Spanning" -Status INFO -Message "Enabled"
    }

    # Virtual Hard Disk Path
    $vhdPath = $vmHost.VirtualHardDiskPath
    if ($vhdPath -and (Test-Path $vhdPath)) {
        $acl = Get-Acl $vhdPath -ErrorAction SilentlyContinue
        $everyone = $acl.Access | Where-Object { $_.IdentityReference -match "Everyone|Authenticated Users" }
        if ($everyone) {
            Register-Check -Name "VHD Storage ACL" -Status WARN -Message "Broad permissions on $vhdPath"
        } else {
            Register-Check -Name "VHD Storage ACL" -Status PASS -Message "Restricted access"
        }
    }

    # Virtual Machine Path
    $vmPath = $vmHost.VirtualMachinePath
    if ($vmPath -and (Test-Path $vmPath)) {
        $acl = Get-Acl $vmPath -ErrorAction SilentlyContinue
        $everyone = $acl.Access | Where-Object { $_.IdentityReference -match "Everyone|Authenticated Users" }
        if ($everyone) {
            Register-Check -Name "VM Config Storage ACL" -Status WARN -Message "Broad permissions on $vmPath"
        } else {
            Register-Check -Name "VM Config Storage ACL" -Status PASS -Message "Restricted access"
        }
    }
} catch {
    Register-Check -Name "VMHost Configuration" -Status FAIL -Message "Cannot query: $_"
}

# ============================================================================
# VIRTUAL SWITCH SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Virtual Switch Security ==="

try {
    $switches = Get-VMSwitch -ErrorAction Stop

    if ($switches.Count -eq 0) {
        Register-Check -Name "Virtual Switches" -Status INFO -Message "None configured"
    } else {
        foreach ($switch in $switches) {
            # Check switch type
            $switchType = $switch.SwitchType
            Register-Check -Name "Switch: $($switch.Name)" -Status INFO -Message "Type: $switchType"

            # Check for MAC address spoofing protection at switch level
            if ($switch.SwitchType -eq "External") {
                # External switches need extra security
                $adapters = Get-VMNetworkAdapter -SwitchName $switch.Name -ManagementOS -ErrorAction SilentlyContinue
                if ($adapters) {
                    Register-Check -Name "Management OS Adapter ($($switch.Name))" -Status INFO -Message "Present"
                }
            }
        }

        # Count switch types
        $external = ($switches | Where-Object SwitchType -eq "External").Count
        $internal = ($switches | Where-Object SwitchType -eq "Internal").Count
        $private = ($switches | Where-Object SwitchType -eq "Private").Count

        Register-Check -Name "Switch Summary" -Status INFO -Message "External=$external Internal=$internal Private=$private"
    }
} catch {
    Register-Check -Name "Virtual Switches" -Status FAIL -Message "Cannot query: $_"
}

# ============================================================================
# VIRTUAL MACHINE SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Virtual Machine Security ==="

try {
    $vms = Get-VM -ErrorAction Stop

    if ($vms.Count -eq 0) {
        Register-Check -Name "Virtual Machines" -Status INFO -Message "None configured"
    } else {
        Register-Check -Name "VM Count" -Status INFO -Message "$($vms.Count) VMs found"

        $secureBootEnabled = 0
        $secureBootDisabled = 0
        $tpmEnabled = 0
        $tpmDisabled = 0
        $shieldedCount = 0
        $encryptionEnabled = 0
        $guestServicesEnabled = 0
        $gen1Count = 0
        $gen2Count = 0

        foreach ($vm in $vms) {
            # Generation check
            if ($vm.Generation -eq 2) {
                $gen2Count++

                # Secure Boot (Gen 2 only)
                $firmwareSec = Get-VMFirmware -VMName $vm.Name -ErrorAction SilentlyContinue
                if ($firmwareSec.SecureBoot -eq "On") {
                    $secureBootEnabled++
                } else {
                    $secureBootDisabled++
                    Register-Check -Name "VM $($vm.Name) Secure Boot" -Status WARN -Message "Disabled"
                }
            } else {
                $gen1Count++
            }

            # TPM Check
            $tpm = Get-VMSecurity -VMName $vm.Name -ErrorAction SilentlyContinue
            if ($tpm.TpmEnabled) {
                $tpmEnabled++
            } else {
                $tpmDisabled++
            }

            # Shielding Check
            if ($tpm.Shielded) {
                $shieldedCount++
            }

            # State Encryption
            if ($tpm.EncryptStateAndVmMigrationTraffic) {
                $encryptionEnabled++
            }

            # Guest Services
            $guestSvc = Get-VMIntegrationService -VMName $vm.Name -Name "Guest Service Interface" -ErrorAction SilentlyContinue
            if ($guestSvc -and $guestSvc.Enabled) {
                $guestServicesEnabled++
            }

            # Check for checkpoints (snapshots) - security concern
            $checkpoints = Get-VMSnapshot -VMName $vm.Name -ErrorAction SilentlyContinue
            if ($checkpoints -and $checkpoints.Count -gt 0) {
                Register-Check -Name "VM $($vm.Name) Checkpoints" -Status WARN -Message "$($checkpoints.Count) checkpoint(s) - may contain sensitive state"
            }
        }

        # Summary checks
        Register-Check -Name "VM Generation Summary" -Status INFO -Message "Gen1=$gen1Count Gen2=$gen2Count"

        if ($gen1Count -gt 0) {
            Register-Check -Name "Generation 1 VMs" -Status WARN -Message "$gen1Count Gen1 VMs cannot use Secure Boot/TPM"
        }

        if ($secureBootEnabled -gt 0 -or $gen2Count -gt 0) {
            if ($secureBootDisabled -eq 0 -and $gen2Count -gt 0) {
                Register-Check -Name "Secure Boot" -Status PASS -Message "All Gen2 VMs have Secure Boot enabled ($secureBootEnabled)"
            } elseif ($secureBootDisabled -gt 0) {
                Register-Check -Name "Secure Boot" -Status WARN -Message "$secureBootDisabled Gen2 VM(s) without Secure Boot"
            }
        }

        if ($tpmEnabled -gt 0) {
            Register-Check -Name "Virtual TPM" -Status PASS -Message "$tpmEnabled VM(s) with vTPM"
        }
        if ($tpmDisabled -gt 0) {
            Register-Check -Name "Virtual TPM Missing" -Status WARN -Message "$tpmDisabled VM(s) without vTPM"
        }

        if ($shieldedCount -gt 0) {
            Register-Check -Name "Shielded VMs" -Status PASS -Message "$shieldedCount shielded VM(s)"
        } else {
            Register-Check -Name "Shielded VMs" -Status INFO -Message "No shielded VMs configured"
        }

        if ($encryptionEnabled -gt 0) {
            Register-Check -Name "State Encryption" -Status PASS -Message "$encryptionEnabled VM(s) with state encryption"
        }
    }
} catch {
    Register-Check -Name "Virtual Machines" -Status FAIL -Message "Cannot query: $_"
}

# ============================================================================
# NETWORK ADAPTER SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Network Adapter Security ==="

try {
    $adapters = Get-VMNetworkAdapter -VMName * -ErrorAction Stop

    $macSpoofEnabled = 0
    $dhcpGuardEnabled = 0
    $routerGuardEnabled = 0
    $portsecurityEnabled = 0

    foreach ($adapter in $adapters) {
        # MAC Address Spoofing
        if ($adapter.MacAddressSpoofing -eq "On") {
            $macSpoofEnabled++
            Register-Check -Name "MAC Spoofing ($($adapter.VMName))" -Status WARN -Message "Enabled on $($adapter.Name)"
        }

        # DHCP Guard
        if ($adapter.DhcpGuard -eq "On") {
            $dhcpGuardEnabled++
        }

        # Router Guard
        if ($adapter.RouterGuard -eq "On") {
            $routerGuardEnabled++
        }

        # Port ACLs
        $acls = Get-VMNetworkAdapterAcl -VMNetworkAdapter $adapter -ErrorAction SilentlyContinue
        if ($acls -and $acls.Count -gt 0) {
            $portsecurityEnabled++
        }
    }

    if ($macSpoofEnabled -eq 0) {
        Register-Check -Name "MAC Address Spoofing" -Status PASS -Message "Disabled on all adapters"
    } else {
        Register-Check -Name "MAC Address Spoofing" -Status WARN -Message "$macSpoofEnabled adapter(s) allow spoofing"
    }

    Register-Check -Name "DHCP Guard" -Status INFO -Message "$dhcpGuardEnabled adapter(s) with DHCP Guard"
    Register-Check -Name "Router Guard" -Status INFO -Message "$routerGuardEnabled adapter(s) with Router Guard"

    if ($portsecurityEnabled -gt 0) {
        Register-Check -Name "Port ACLs" -Status PASS -Message "$portsecurityEnabled adapter(s) with ACLs"
    }
} catch {
    Register-Check -Name "Network Adapters" -Status WARN -Message "Cannot query: $_"
}

# ============================================================================
# INTEGRATION SERVICES SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Integration Services ==="

try {
    $vms = Get-VM -ErrorAction Stop

    $dataExchangeEnabled = 0
    $heartbeatEnabled = 0
    $shutdownEnabled = 0
    $timeSyncEnabled = 0
    $vssEnabled = 0

    foreach ($vm in $vms) {
        $services = Get-VMIntegrationService -VMName $vm.Name -ErrorAction SilentlyContinue

        foreach ($svc in $services) {
            if ($svc.Name -eq "Key-Value Pair Exchange" -and $svc.Enabled) { $dataExchangeEnabled++ }
            if ($svc.Name -eq "Heartbeat" -and $svc.Enabled) { $heartbeatEnabled++ }
            if ($svc.Name -eq "Shutdown" -and $svc.Enabled) { $shutdownEnabled++ }
            if ($svc.Name -eq "Time Synchronization" -and $svc.Enabled) { $timeSyncEnabled++ }
            if ($svc.Name -eq "VSS" -and $svc.Enabled) { $vssEnabled++ }
        }
    }

    Register-Check -Name "Data Exchange (KVP)" -Status INFO -Message "$dataExchangeEnabled VMs"
    Register-Check -Name "Time Sync" -Status INFO -Message "$timeSyncEnabled VMs"
    Register-Check -Name "Guest Shutdown" -Status INFO -Message "$shutdownEnabled VMs"
    Register-Check -Name "VSS Backup" -Status INFO -Message "$vssEnabled VMs"
} catch {
    Register-Check -Name "Integration Services" -Status WARN -Message "Cannot query"
}

# ============================================================================
# RESOURCE CONTROLS
# ============================================================================
Write-Output ""
Write-Output "=== Resource Controls ==="

try {
    $vms = Get-VM -ErrorAction Stop

    $memoryOvercommit = 0
    $cpuLimited = 0
    $iopsLimited = 0

    foreach ($vm in $vms) {
        # Dynamic Memory check
        if ($vm.DynamicMemoryEnabled) {
            $totalDynamic = ($vms | Where-Object DynamicMemoryEnabled | Measure-Object -Property MemoryMaximum -Sum).Sum
            $physicalMem = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
            if ($totalDynamic -gt $physicalMem) {
                $memoryOvercommit++
            }
        }

        # CPU Weight/Limit
        $proc = Get-VMProcessor -VMName $vm.Name -ErrorAction SilentlyContinue
        if ($proc.Maximum -lt 100) {
            $cpuLimited++
        }

        # Storage QoS
        $vhds = Get-VMHardDiskDrive -VMName $vm.Name -ErrorAction SilentlyContinue
        foreach ($vhd in $vhds) {
            $qos = Get-VMHardDiskDrive -VMName $vm.Name | Where-Object { $_.MaximumIOPS -gt 0 }
            if ($qos) {
                $iopsLimited++
                break
            }
        }
    }

    if ($memoryOvercommit -gt 0) {
        Register-Check -Name "Memory Overcommit" -Status WARN -Message "Dynamic memory may exceed physical RAM"
    } else {
        Register-Check -Name "Memory Overcommit" -Status PASS -Message "No overcommit detected"
    }

    Register-Check -Name "CPU Limits" -Status INFO -Message "$cpuLimited VM(s) with CPU limits"
    Register-Check -Name "Storage QoS" -Status INFO -Message "$iopsLimited VM(s) with IOPS limits"
} catch {
    Register-Check -Name "Resource Controls" -Status WARN -Message "Cannot query"
}

# ============================================================================
# REPLICA AND BACKUP SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Replica and Backup Security ==="

# Check Hyper-V Replica configuration
try {
    $replicaServer = Get-VMReplicationServer -ErrorAction SilentlyContinue

    if ($replicaServer -and $replicaServer.ReplicationEnabled) {
        Register-Check -Name "Hyper-V Replica" -Status INFO -Message "Enabled"

        # Check authentication type
        $authType = $replicaServer.AuthenticationType
        if ($authType -eq "Certificate") {
            Register-Check -Name "Replica Authentication" -Status PASS -Message "Certificate-based"
        } elseif ($authType -eq "Kerberos") {
            Register-Check -Name "Replica Authentication" -Status WARN -Message "Kerberos - consider certificates"
        }

        # Check for HTTPS
        if ($replicaServer.HttpsPort) {
            Register-Check -Name "Replica HTTPS" -Status PASS -Message "Port $($replicaServer.HttpsPort)"
        }
        if ($replicaServer.HttpPort -and -not $replicaServer.HttpsPort) {
            Register-Check -Name "Replica HTTP" -Status FAIL -Message "Unencrypted replication on port $($replicaServer.HttpPort)"
        }
    } else {
        Register-Check -Name "Hyper-V Replica" -Status INFO -Message "Not configured"
    }
} catch {
    Register-Check -Name "Hyper-V Replica" -Status INFO -Message "Not available"
}

# ============================================================================
# LIVE MIGRATION SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Live Migration Security ==="

try {
    $vmHost = Get-VMHost -ErrorAction Stop

    if ($vmHost.VirtualMachineMigrationEnabled) {
        Register-Check -Name "Live Migration" -Status INFO -Message "Enabled"

        # Check authentication type
        $migrationAuth = $vmHost.VirtualMachineMigrationAuthenticationType
        if ($migrationAuth -eq "CredSSP") {
            Register-Check -Name "Migration Auth" -Status WARN -Message "CredSSP - vulnerable to relay attacks"
        } elseif ($migrationAuth -eq "Kerberos") {
            Register-Check -Name "Migration Auth" -Status PASS -Message "Kerberos constrained delegation"
        }

        # Check performance option (encryption)
        $perfOption = $vmHost.VirtualMachineMigrationPerformanceOption
        if ($perfOption -eq "SMBTransport") {
            Register-Check -Name "Migration Transport" -Status PASS -Message "SMB with encryption"
        } elseif ($perfOption -eq "Compression") {
            Register-Check -Name "Migration Transport" -Status INFO -Message "Compression (no encryption)"
        } else {
            Register-Check -Name "Migration Transport" -Status WARN -Message "TCP (no encryption)"
        }

        # Check allowed networks
        $migrationNetworks = $vmHost.VirtualMachineMigrationSubnets
        if ($migrationNetworks -and $migrationNetworks.Count -gt 0) {
            Register-Check -Name "Migration Networks" -Status PASS -Message "Restricted to specific subnets"
        } else {
            Register-Check -Name "Migration Networks" -Status WARN -Message "Any network allowed"
        }
    } else {
        Register-Check -Name "Live Migration" -Status INFO -Message "Disabled"
    }
} catch {
    Register-Check -Name "Live Migration" -Status WARN -Message "Cannot query"
}

# ============================================================================
# HOST GUARDIAN SERVICE (HGS) CHECK
# ============================================================================
Write-Output ""
Write-Output "=== Host Guardian Service ==="

try {
    # Check if HGS client is configured
    $hgsClient = Get-HgsClientConfiguration -ErrorAction SilentlyContinue

    if ($hgsClient -and $hgsClient.IsHostGuarded) {
        Register-Check -Name "HGS Status" -Status PASS -Message "Host is guarded"

        if ($hgsClient.Mode -eq "HostGuardianService") {
            Register-Check -Name "HGS Mode" -Status INFO -Message "HGS attestation"
        } elseif ($hgsClient.Mode -eq "Local") {
            Register-Check -Name "HGS Mode" -Status WARN -Message "Local mode - no remote attestation"
        }

        # Check attestation URL
        if ($hgsClient.AttestationServerUrl) {
            Register-Check -Name "Attestation URL" -Status INFO -Message $hgsClient.AttestationServerUrl
        }

        # Check Key Protection URL
        if ($hgsClient.KeyProtectionServerUrl) {
            Register-Check -Name "Key Protection URL" -Status INFO -Message $hgsClient.KeyProtectionServerUrl
        }
    } else {
        Register-Check -Name "HGS Status" -Status INFO -Message "Not configured (required for shielded VMs)"
    }
} catch {
    Register-Check -Name "HGS Status" -Status INFO -Message "HGS not available on this edition"
}

# ============================================================================
# AUDIT AND LOGGING
# ============================================================================
Write-Output ""
Write-Output "=== Audit and Logging ==="

# Check Hyper-V event log size
try {
    $hvLog = Get-WinEvent -ListLog "Microsoft-Windows-Hyper-V-Worker-Admin" -ErrorAction SilentlyContinue
    if ($hvLog) {
        $sizeMB = [math]::Round($hvLog.MaximumSizeInBytes / 1MB, 2)
        if ($sizeMB -ge 64) {
            Register-Check -Name "Hyper-V Worker Log Size" -Status PASS -Message "${sizeMB}MB"
        } else {
            Register-Check -Name "Hyper-V Worker Log Size" -Status WARN -Message "${sizeMB}MB - recommend 64MB+"
        }
    }

    $hvVMMSLog = Get-WinEvent -ListLog "Microsoft-Windows-Hyper-V-VMMS-Admin" -ErrorAction SilentlyContinue
    if ($hvVMMSLog) {
        $sizeMB = [math]::Round($hvVMMSLog.MaximumSizeInBytes / 1MB, 2)
        if ($sizeMB -ge 64) {
            Register-Check -Name "Hyper-V VMMS Log Size" -Status PASS -Message "${sizeMB}MB"
        } else {
            Register-Check -Name "Hyper-V VMMS Log Size" -Status WARN -Message "${sizeMB}MB - recommend 64MB+"
        }
    }
} catch {
    Register-Check -Name "Hyper-V Logging" -Status WARN -Message "Cannot query event logs"
}

# Check for Hyper-V Administrators group membership
try {
    $hvAdmins = Get-LocalGroupMember -Group "Hyper-V Administrators" -ErrorAction SilentlyContinue
    if ($hvAdmins) {
        Register-Check -Name "Hyper-V Administrators" -Status INFO -Message "$($hvAdmins.Count) member(s)"
        foreach ($member in $hvAdmins) {
            if ($member.ObjectClass -eq "User" -and $member.Name -notmatch "Administrator") {
                Register-Check -Name "HV Admin: $($member.Name)" -Status INFO -Message $member.ObjectClass
            }
        }
    }
} catch {
    Register-Check -Name "Hyper-V Administrators" -Status WARN -Message "Cannot query group"
}

Print-Summary
Exit-Audit
