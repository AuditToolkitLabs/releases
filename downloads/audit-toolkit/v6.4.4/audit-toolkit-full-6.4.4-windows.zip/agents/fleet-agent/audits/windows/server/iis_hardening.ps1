# IIS Hardening Security Audit Script (PowerShell)
# Comprehensive security checks based on CIS IIS Benchmark and best practices
# This script is read-only and does not modify system state.
#
# References:
# - CIS Microsoft IIS 10 Benchmark
# - OWASP Secure Headers Project
# - Microsoft IIS Security Best Practices

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

# ============================================================================
# IIS ROLE CHECK
# ============================================================================
Write-Output "=== IIS Role Status ==="

# Check if IIS is installed
try {
    $iis = Get-WindowsFeature -Name Web-Server -ErrorAction Stop
    if ($iis.Installed) {
        Register-Check -Name "IIS Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "IIS Role" -Status SKIP -Message "Not installed - skipping IIS checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    # Try import for IIS cmdlets directly
    try {
        Import-Module WebAdministration -ErrorAction Stop
        Register-Check -Name "IIS Role" -Status PASS -Message "WebAdministration module loaded"
    } catch {
        Register-Check -Name "IIS Role" -Status SKIP -Message "IIS not available"
        Print-Summary
        Exit-Audit
    }
}

# Import WebAdministration
try {
    Import-Module WebAdministration -ErrorAction Stop
} catch {
    Register-Check -Name "WebAdministration Module" -Status FAIL -Message "Cannot load module"
    Print-Summary
    Exit-Audit
}

# ============================================================================
# IIS VERSION AND FEATURES
# ============================================================================
Write-Output ""
Write-Output "=== IIS Version and Features ==="

# Get IIS version
try {
    $iisVersion = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\InetStp" -ErrorAction Stop
    Register-Check -Name "IIS Version" -Status INFO -Message "$($iisVersion.MajorVersion).$($iisVersion.MinorVersion)"
} catch {
    Register-Check -Name "IIS Version" -Status WARN -Message "Cannot determine"
}

# Check minimal feature installation (CIS 1.1)
$features = @(
    @{Name="Web-DAV-Publishing"; Recommended=$false; Desc="WebDAV"},
    @{Name="Web-Ftp-Server"; Recommended=$false; Desc="FTP Server"},
    @{Name="Web-Dir-Browsing"; Recommended=$false; Desc="Directory Browsing"},
    @{Name="Web-CGI"; Recommended=$false; Desc="CGI"}
)

foreach ($feat in $features) {
    $installed = Get-WindowsFeature -Name $feat.Name -ErrorAction SilentlyContinue
    if ($installed -and $installed.Installed) {
        Register-Check -Name "$($feat.Desc) Feature" -Status WARN -Message "Installed - remove if not needed"
    } else {
        Register-Check -Name "$($feat.Desc) Feature" -Status PASS -Message "Not installed"
    }
}

# ============================================================================
# APPLICATION POOL SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Application Pool Security ==="

try {
    $appPools = Get-ChildItem IIS:\AppPools -ErrorAction Stop

    Register-Check -Name "Application Pools" -Status INFO -Message "$($appPools.Count) pools configured"

    foreach ($pool in $appPools) {
        $poolName = $pool.Name

        # Check identity (CIS 2.2) - should not be LocalSystem
        $identity = $pool.processModel.identityType
        if ($identity -eq "LocalSystem") {
            Register-Check -Name "Pool $poolName Identity" -Status FAIL -Message "LocalSystem - use lower privilege"
        } elseif ($identity -eq "ApplicationPoolIdentity") {
            Register-Check -Name "Pool $poolName Identity" -Status PASS -Message "ApplicationPoolIdentity"
        } elseif ($identity -eq "NetworkService") {
            Register-Check -Name "Pool $poolName Identity" -Status WARN -Message "NetworkService - consider AppPoolIdentity"
        }

        # Check .NET CLR version
        $clrVersion = $pool.managedRuntimeVersion
        if ($clrVersion -eq "" -or $clrVersion -eq "No Managed Code") {
            Register-Check -Name "Pool $poolName Runtime" -Status INFO -Message "No Managed Code"
        } elseif ($clrVersion -eq "v4.0") {
            Register-Check -Name "Pool $poolName Runtime" -Status PASS -Message ".NET 4.x"
        } elseif ($clrVersion -eq "v2.0") {
            Register-Check -Name "Pool $poolName Runtime" -Status WARN -Message ".NET 2.0 - consider upgrading"
        }

        # Check 32-bit mode (CIS 2.4)
        if ($pool.enable32BitAppOnWin64 -eq $true) {
            Register-Check -Name "Pool $poolName 32-bit" -Status INFO -Message "32-bit mode enabled"
        }

        # Check rapid fail protection (CIS 2.7)
        if ($pool.failure.rapidFailProtection -eq $false) {
            Register-Check -Name "Pool $poolName Rapid Fail" -Status WARN -Message "Protection disabled"
        }

        # Idle timeout (CIS 2.5)
        $idleTimeout = $pool.processModel.idleTimeout.TotalMinutes
        if ($idleTimeout -gt 20) {
            Register-Check -Name "Pool $poolName Idle Timeout" -Status WARN -Message "${idleTimeout}min - recommend 20min or less"
        }
    }
} catch {
    Register-Check -Name "Application Pools" -Status FAIL -Message "Cannot query: $_"
}

# ============================================================================
# WEBSITE SECURITY
# ============================================================================
Write-Output ""
Write-Output "=== Website Security ==="

try {
    $sites = Get-ChildItem IIS:\Sites -ErrorAction Stop

    Register-Check -Name "Websites" -Status INFO -Message "$($sites.Count) sites configured"

    foreach ($site in $sites) {
        $siteName = $site.Name

        # Check bindings for HTTPS
        $bindings = Get-WebBinding -Name $siteName
        $hasHttps = $bindings | Where-Object { $_.protocol -eq "https" }
        $hasHttp = $bindings | Where-Object { $_.protocol -eq "http" }

        if ($hasHttps -and -not $hasHttp) {
            Register-Check -Name "Site $siteName HTTPS Only" -Status PASS -Message "HTTPS only"
        } elseif ($hasHttps -and $hasHttp) {
            Register-Check -Name "Site $siteName Protocol" -Status WARN -Message "Both HTTP and HTTPS - redirect HTTP to HTTPS"
        } elseif ($hasHttp -and -not $hasHttps) {
            Register-Check -Name "Site $siteName Protocol" -Status FAIL -Message "HTTP only - enable HTTPS"
        }

        # Check HTTPS binding details
        foreach ($binding in $hasHttps) {
            $certHash = $binding.certificateHash
            if ($certHash) {
                $cert = Get-ChildItem "Cert:\LocalMachine\My\$certHash" -ErrorAction SilentlyContinue
                if ($cert) {
                    $daysToExpiry = ($cert.NotAfter - (Get-Date)).Days
                    if ($daysToExpiry -lt 0) {
                        Register-Check -Name "Site $siteName Cert" -Status FAIL -Message "EXPIRED"
                    } elseif ($daysToExpiry -lt 30) {
                        Register-Check -Name "Site $siteName Cert" -Status WARN -Message "Expires in $daysToExpiry days"
                    } else {
                        Register-Check -Name "Site $siteName Cert" -Status PASS -Message "Valid ($daysToExpiry days)"
                    }
                }
            }
        }

        # Check directory browsing (CIS 3.4)
        $dirBrowse = Get-WebConfigurationProperty -Filter /system.webServer/directoryBrowse -Name enabled -PSPath "IIS:\Sites\$siteName" -ErrorAction SilentlyContinue
        if ($dirBrowse.Value -eq $true) {
            Register-Check -Name "Site $siteName Dir Browsing" -Status FAIL -Message "Enabled - disable it"
        } else {
            Register-Check -Name "Site $siteName Dir Browsing" -Status PASS -Message "Disabled"
        }

        # Check anonymous authentication (CIS 3.1)
        $anonAuth = Get-WebConfigurationProperty -Filter /system.webServer/security/authentication/anonymousAuthentication -Name enabled -PSPath "IIS:\Sites\$siteName" -ErrorAction SilentlyContinue
        if ($anonAuth.Value -eq $true) {
            Register-Check -Name "Site $siteName Anon Auth" -Status INFO -Message "Enabled"
        }
    }
} catch {
    Register-Check -Name "Websites" -Status FAIL -Message "Cannot query: $_"
}

# ============================================================================
# SSL/TLS CONFIGURATION
# ============================================================================
Write-Output ""
Write-Output "=== SSL/TLS Configuration ==="

# Check SSL/TLS protocols in registry
$protocols = @(
    @{Name="SSL 2.0"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server"; ShouldBeDisabled=$true},
    @{Name="SSL 3.0"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server"; ShouldBeDisabled=$true},
    @{Name="TLS 1.0"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server"; ShouldBeDisabled=$true},
    @{Name="TLS 1.1"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server"; ShouldBeDisabled=$true},
    @{Name="TLS 1.2"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server"; ShouldBeDisabled=$false},
    @{Name="TLS 1.3"; Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.3\Server"; ShouldBeDisabled=$false}
)

foreach ($proto in $protocols) {
    $enabled = Get-ItemProperty -Path $proto.Path -Name "Enabled" -ErrorAction SilentlyContinue
    $disabledByDefault = Get-ItemProperty -Path $proto.Path -Name "DisabledByDefault" -ErrorAction SilentlyContinue

    $isEnabled = ($enabled.Enabled -ne 0) -and ($disabledByDefault.DisabledByDefault -ne 1)

    if ($proto.ShouldBeDisabled) {
        if ($isEnabled -or $null -eq $enabled) {
            # If not explicitly disabled, may be enabled by default
            if ($proto.Name -match "SSL|TLS 1\.0|TLS 1\.1") {
                Register-Check -Name $proto.Name -Status WARN -Message "Not explicitly disabled"
            }
        } else {
            Register-Check -Name $proto.Name -Status PASS -Message "Disabled"
        }
    } else {
        if ($enabled -and $enabled.Enabled -eq 1) {
            Register-Check -Name $proto.Name -Status PASS -Message "Enabled"
        } else {
            Register-Check -Name $proto.Name -Status INFO -Message "Default (should be enabled)"
        }
    }
}

# Check for weak cipher suites
$weakCiphers = @("RC4", "DES", "3DES", "NULL", "MD5")
foreach ($cipher in $weakCiphers) {
    $cipherPath = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\$cipher"
    $enabled = Get-ItemProperty -Path "$cipherPath*" -Name "Enabled" -ErrorAction SilentlyContinue
    if ($enabled -and $enabled.Enabled -eq 1) {
        Register-Check -Name "Cipher $cipher" -Status FAIL -Message "Enabled - disable it"
    } elseif (-not $enabled) {
        Register-Check -Name "Cipher $cipher" -Status WARN -Message "Not explicitly disabled"
    } else {
        Register-Check -Name "Cipher $cipher" -Status PASS -Message "Disabled"
    }
}

# ============================================================================
# SECURITY HEADERS
# ============================================================================
Write-Output ""
Write-Output "=== Security Headers (Global) ==="

try {
    # Check custom headers at server level
    $customHeaders = Get-WebConfiguration -Filter /system.webServer/httpProtocol/customHeaders -PSPath "IIS:\" -ErrorAction SilentlyContinue

    $requiredHeaders = @(
        @{Name="X-Frame-Options"; Expected="DENY|SAMEORIGIN"},
        @{Name="X-Content-Type-Options"; Expected="nosniff"},
        @{Name="X-XSS-Protection"; Expected="1; mode=block"},
        @{Name="Strict-Transport-Security"; Expected="max-age"},
        @{Name="Content-Security-Policy"; Expected=".+"}
    )

    foreach ($header in $requiredHeaders) {
        $found = $customHeaders.Collection | Where-Object { $_.name -eq $header.Name }
        if ($found) {
            if ($found.value -match $header.Expected) {
                Register-Check -Name "Header $($header.Name)" -Status PASS -Message $found.value
            } else {
                Register-Check -Name "Header $($header.Name)" -Status WARN -Message "Value: $($found.value)"
            }
        } else {
            Register-Check -Name "Header $($header.Name)" -Status WARN -Message "Not configured"
        }
    }

    # Check for information disclosure headers to remove
    $badHeaders = @("X-Powered-By", "X-AspNet-Version", "Server")
    foreach ($bh in $badHeaders) {
        $found = $customHeaders.Collection | Where-Object { $_.name -eq $bh }
        # These should be in removeServerHeader config
        $serverHeader = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering -Name removeServerHeader -ErrorAction SilentlyContinue
        if ($bh -eq "Server" -and $serverHeader -eq $true) {
            Register-Check -Name "Remove Server Header" -Status PASS -Message "Removed"
        } elseif ($bh -eq "Server") {
            Register-Check -Name "Remove Server Header" -Status WARN -Message "Not removed - reveals IIS version"
        }
    }
} catch {
    Register-Check -Name "Security Headers" -Status WARN -Message "Cannot query"
}

# ============================================================================
# REQUEST FILTERING
# ============================================================================
Write-Output ""
Write-Output "=== Request Filtering ==="

try {
    # Max URL length (CIS 4.4)
    $maxUrl = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering/requestLimits -Name maxUrl -ErrorAction SilentlyContinue
    if ($maxUrl -and $maxUrl.Value -le 4096) {
        Register-Check -Name "Max URL Length" -Status PASS -Message "$($maxUrl.Value) bytes"
    } elseif ($maxUrl) {
        Register-Check -Name "Max URL Length" -Status WARN -Message "$($maxUrl.Value) bytes - recommend 4096 or less"
    }

    # Max Query String (CIS 4.5)
    $maxQuery = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering/requestLimits -Name maxQueryString -ErrorAction SilentlyContinue
    if ($maxQuery -and $maxQuery.Value -le 2048) {
        Register-Check -Name "Max Query String" -Status PASS -Message "$($maxQuery.Value) bytes"
    } elseif ($maxQuery) {
        Register-Check -Name "Max Query String" -Status WARN -Message "$($maxQuery.Value) bytes - recommend 2048 or less"
    }

    # Max Content Length (CIS 4.6)
    $maxContent = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering/requestLimits -Name maxAllowedContentLength -ErrorAction SilentlyContinue
    if ($maxContent) {
        $maxMB = [math]::Round($maxContent.Value / 1MB, 2)
        if ($maxMB -le 30) {
            Register-Check -Name "Max Content Length" -Status PASS -Message "${maxMB}MB"
        } else {
            Register-Check -Name "Max Content Length" -Status WARN -Message "${maxMB}MB - consider reducing"
        }
    }

    # Double escaping (CIS 4.7)
    $doubleEscape = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering -Name allowDoubleEscaping -ErrorAction SilentlyContinue
    if ($doubleEscape.Value -eq $false) {
        Register-Check -Name "Double Escaping" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "Double Escaping" -Status WARN -Message "Allowed"
    }

    # High bit characters (CIS 4.8)
    $highBit = Get-WebConfigurationProperty -Filter /system.webServer/security/requestFiltering -Name allowHighBitCharacters -ErrorAction SilentlyContinue
    if ($highBit.Value -eq $false) {
        Register-Check -Name "High Bit Characters" -Status PASS -Message "Blocked"
    } else {
        Register-Check -Name "High Bit Characters" -Status INFO -Message "Allowed (may be needed for i18n)"
    }

    # File extensions - check for dangerous ones blocked
    $blockedExt = Get-WebConfiguration -Filter /system.webServer/security/requestFiltering/fileExtensions -ErrorAction SilentlyContinue
    $dangerousExt = @(".exe", ".dll", ".com", ".bat", ".cmd", ".vbs", ".ps1", ".config", ".mdb")
    $blocked = 0
    foreach ($ext in $dangerousExt) {
        $found = $blockedExt.Collection | Where-Object { $_.fileExtension -eq $ext -and $_.allowed -eq $false }
        if ($found) { $blocked++ }
    }
    if ($blocked -ge 5) {
        Register-Check -Name "Dangerous Extensions" -Status PASS -Message "$blocked/9 blocked"
    } else {
        Register-Check -Name "Dangerous Extensions" -Status WARN -Message "Only $blocked/9 dangerous extensions blocked"
    }
} catch {
    Register-Check -Name "Request Filtering" -Status WARN -Message "Cannot query"
}

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================
Write-Output ""
Write-Output "=== Logging Configuration ==="

try {
    $sites = Get-ChildItem IIS:\Sites -ErrorAction Stop

    foreach ($site in $sites) {
        $siteName = $site.Name
        $logFile = $site.logFile

        # Check if logging is enabled (CIS 6.1)
        if ($logFile.enabled -eq $false) {
            Register-Check -Name "Site $siteName Logging" -Status FAIL -Message "Disabled"
        } else {
            Register-Check -Name "Site $siteName Logging" -Status PASS -Message "Enabled"

            # Log format (CIS 6.2)
            if ($logFile.logFormat -ne "W3C") {
                Register-Check -Name "Site $siteName Log Format" -Status WARN -Message "$($logFile.logFormat) - recommend W3C"
            }

            # Log fields - check for important ones
            $fields = $logFile.logExtFileFlags
            $requiredFlags = @("Date", "Time", "ClientIP", "UserName", "Method", "UriStem", "HttpStatus", "Win32Status", "TimeTaken")
            $hasRequired = $true
            foreach ($flag in $requiredFlags) {
                if ($fields -notmatch $flag) {
                    $hasRequired = $false
                }
            }

            if ($hasRequired) {
                Register-Check -Name "Site $siteName Log Fields" -Status PASS -Message "All required fields"
            } else {
                Register-Check -Name "Site $siteName Log Fields" -Status WARN -Message "Missing some log fields"
            }

            # ETW logging (CIS 6.4)
            if ($logFile.logTargetW3C -match "ETW") {
                Register-Check -Name "Site $siteName ETW" -Status INFO -Message "ETW logging enabled"
            }
        }
    }
} catch {
    Register-Check -Name "Logging" -Status WARN -Message "Cannot query"
}

# ============================================================================
# HANDLER MAPPINGS
# ============================================================================
Write-Output ""
Write-Output "=== Handler Mappings ==="

try {
    $handlers = Get-WebConfiguration -Filter /system.webServer/handlers -ErrorAction SilentlyContinue

    # Check for CGI-exe handler (should be restricted)
    $cgiExe = $handlers.Collection | Where-Object { $_.name -match "CGI-exe" }
    if ($cgiExe) {
        Register-Check -Name "CGI-exe Handler" -Status WARN -Message "Enabled - remove if not needed"
    } else {
        Register-Check -Name "CGI-exe Handler" -Status PASS -Message "Not configured"
    }

    # Check for ISAPI handlers
    $isapi = $handlers.Collection | Where-Object { $_.name -match "ISAPI" }
    if ($isapi -and $isapi.Count -gt 2) {
        Register-Check -Name "ISAPI Handlers" -Status INFO -Message "$($isapi.Count) ISAPI handlers"
    }

    # Check for WebDAV
    $webdav = $handlers.Collection | Where-Object { $_.name -match "WebDAV" }
    if ($webdav) {
        Register-Check -Name "WebDAV Handler" -Status WARN -Message "Enabled - remove if not needed"
    } else {
        Register-Check -Name "WebDAV Handler" -Status PASS -Message "Not configured"
    }
} catch {
    Register-Check -Name "Handlers" -Status WARN -Message "Cannot query"
}

# ============================================================================
# ASP.NET SECURITY (if applicable)
# ============================================================================
Write-Output ""
Write-Output "=== ASP.NET Security ==="

try {
    # Check compilation debug mode
    $debug = Get-WebConfigurationProperty -Filter /system.web/compilation -Name debug -ErrorAction SilentlyContinue
    if ($debug.Value -eq $true) {
        Register-Check -Name "ASP.NET Debug Mode" -Status FAIL -Message "Enabled - disable in production"
    } else {
        Register-Check -Name "ASP.NET Debug Mode" -Status PASS -Message "Disabled"
    }

    # Check custom errors (CIS 7.3)
    $customErrors = Get-WebConfigurationProperty -Filter /system.web/customErrors -Name mode -ErrorAction SilentlyContinue
    if ($customErrors -and $customErrors -eq "Off") {
        Register-Check -Name "Custom Errors" -Status FAIL -Message "Off - enable RemoteOnly or On"
    } elseif ($customErrors) {
        Register-Check -Name "Custom Errors" -Status PASS -Message $customErrors
    }

    # Check HTTP cookies httpOnly
    $httpOnlyCookies = Get-WebConfigurationProperty -Filter /system.web/httpCookies -Name httpOnlyCookies -ErrorAction SilentlyContinue
    if ($httpOnlyCookies.Value -eq $true) {
        Register-Check -Name "HttpOnly Cookies" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "HttpOnly Cookies" -Status WARN -Message "Not enforced"
    }

    # Check requireSSL for cookies
    $requireSSL = Get-WebConfigurationProperty -Filter /system.web/httpCookies -Name requireSSL -ErrorAction SilentlyContinue
    if ($requireSSL.Value -eq $true) {
        Register-Check -Name "Secure Cookies" -Status PASS -Message "RequireSSL enabled"
    } else {
        Register-Check -Name "Secure Cookies" -Status WARN -Message "RequireSSL not enforced"
    }

    # Check session state cookie settings
    $sessionCookie = Get-WebConfigurationProperty -Filter /system.web/sessionState -Name cookieless -ErrorAction SilentlyContinue
    if ($sessionCookie -and $sessionCookie -ne "UseCookies") {
        Register-Check -Name "Session State" -Status WARN -Message "Cookieless=$sessionCookie - recommend UseCookies"
    }

    # Machine key validation
    $machineKey = Get-WebConfiguration -Filter /system.web/machineKey -ErrorAction SilentlyContinue
    if ($machineKey -and $machineKey.validation -match "SHA|AES") {
        Register-Check -Name "Machine Key Validation" -Status PASS -Message $machineKey.validation
    } elseif ($machineKey -and $machineKey.validation -eq "MD5") {
        Register-Check -Name "Machine Key Validation" -Status FAIL -Message "MD5 - upgrade to SHA256 or higher"
    }
} catch {
    Register-Check -Name "ASP.NET Security" -Status INFO -Message "Not applicable or cannot query"
}

# ============================================================================
# IIS SERVICE ACCOUNT
# ============================================================================
Write-Output ""
Write-Output "=== IIS Service Account ==="

try {
    $w3svc = Get-CimInstance Win32_Service -Filter "Name='W3SVC'" -ErrorAction Stop
    Register-Check -Name "W3SVC Service" -Status INFO -Message "Account: $($w3svc.StartName)"

    $iisAdmin = Get-CimInstance Win32_Service -Filter "Name='IISADMIN'" -ErrorAction SilentlyContinue
    if ($iisAdmin) {
        Register-Check -Name "IISADMIN Service" -Status INFO -Message "Account: $($iisAdmin.StartName)"
    }

    # Check WAS
    $was = Get-CimInstance Win32_Service -Filter "Name='WAS'" -ErrorAction SilentlyContinue
    if ($was) {
        Register-Check -Name "WAS Service" -Status INFO -Message "Status: $($was.State)"
    }
} catch {
    Register-Check -Name "IIS Services" -Status WARN -Message "Cannot query"
}

# ============================================================================
# ISAPI FILTERS
# ============================================================================
Write-Output ""
Write-Output "=== ISAPI Filters ==="

try {
    $filters = Get-WebConfiguration -Filter /system.webServer/isapiFilters -ErrorAction SilentlyContinue
    if ($filters.Collection.Count -eq 0) {
        Register-Check -Name "ISAPI Filters" -Status PASS -Message "None configured"
    } else {
        Register-Check -Name "ISAPI Filters" -Status INFO -Message "$($filters.Collection.Count) filter(s)"
        foreach ($filter in $filters.Collection) {
            Register-Check -Name "ISAPI: $($filter.name)" -Status INFO -Message $filter.path
        }
    }
} catch {
    Register-Check -Name "ISAPI Filters" -Status INFO -Message "Cannot query"
}

Print-Summary
Exit-Audit
