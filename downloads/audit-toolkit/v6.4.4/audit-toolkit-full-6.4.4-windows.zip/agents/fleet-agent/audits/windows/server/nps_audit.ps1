<#
.SYNOPSIS
    Windows Network Policy Server (NPS/RADIUS) Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows NPS (RADIUS):
    - NPS service configuration
    - RADIUS client security
    - Network policies
    - Connection request policies
    - Authentication methods
    - Accounting and logging
    - Certificate security

.NOTES
    @elevation: admin
    @elevation-reason: NPS cmdlets require Administrator privileges
    Requires: NPS role installed

Compliance Mapping:
- CIS Controls: 6.5 (Centralized AAA), 13.5 (Wireless Security)
- CIS Windows Server 2022: Section 5 (System Services)
- NIST SP 800-53: IA-2 (Identification and Authentication), AC-2 (Account Management)
- NIST SP 800-153: Wireless Network Security
- MITRE ATT&CK: T1110 (Brute Force), T1556 (Modify Authentication Process)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Network Policy Server (NPS/RADIUS) Security Audit"

# ============================================================================
# NPS ROLE CHECK
# ============================================================================
Write-Section "NPS Role Status"

try {
    $npsFeature = Get-WindowsFeature -Name NPAS -ErrorAction Stop
    if ($npsFeature.Installed) {
        Register-Check -Name "NPS Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "NPS Role" -Status SKIP -Message "Not installed - skipping NPS checks"
        Print-Summary
        Exit-Audit
    }
} catch {
    Register-Check -Name "NPS Role" -Status SKIP -Message "Cannot determine role status"
    Print-Summary
    Exit-Audit
}

# Check NPS service
try {
    $npsSvc = Get-Service -Name IAS -ErrorAction Stop
    if ($npsSvc.Status -eq 'Running') {
        Register-Check -Name "NPS Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "NPS Service" -Status FAIL -Message "Status: $($npsSvc.Status)"
    }

    if ($npsSvc.StartType -eq 'Automatic') {
        Register-Check -Name "NPS Service Startup" -Status PASS -Message "Automatic"
    } else {
        Register-Check -Name "NPS Service Startup" -Status WARN -Message $npsSvc.StartType
    }
} catch {
    Register-Check -Name "NPS Service" -Status FAIL -Message "Cannot query"
}

# Import NPS module
try {
    Import-Module NPS -ErrorAction Stop
    Register-Check -Name "NPS Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "NPS Module" -Status WARN -Message "Cannot load module - using netsh"
}

# ============================================================================
# NPS CONFIGURATION FILE
# ============================================================================
Write-Section "NPS Configuration"

$npsConfigPath = "$env:SystemRoot\System32\ias\ias.xml"

if (Test-Path $npsConfigPath) {
    Register-Check -Name "NPS Config File" -Status INFO -Message $npsConfigPath

    # Check file permissions
    try {
        $acl = Get-Acl $npsConfigPath -ErrorAction Stop
        $hasEveryoneAccess = $acl.Access | Where-Object {
            $_.IdentityReference.Value -eq 'Everyone' -or
            $_.IdentityReference.Value -eq 'BUILTIN\Users'
        }

        if (-not $hasEveryoneAccess) {
            Register-Check -Name "Config File Permissions" -Status PASS -Message "Restricted access"
        } else {
            Register-Check -Name "Config File Permissions" -Status WARN -Message "Broad access permissions"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
} else {
    Register-Check -Name "NPS Config File" -Status WARN -Message "Not found at expected location"
}

# ============================================================================
# RADIUS CLIENTS
# ============================================================================
Write-Section "RADIUS Clients"

try {
    # Use netsh to query RADIUS clients
    $clientOutput = netsh nps show client 2>&1

    if ($clientOutput -match "Client Name") {
        # Count clients
        $clientLines = $clientOutput | Where-Object { $_ -match "Client Name" }
        Register-Check -Name "RADIUS Clients" -Status INFO -Message "$($clientLines.Count) client(s) configured"
    } else {
        Register-Check -Name "RADIUS Clients" -Status INFO -Message "No clients configured or unable to query"
    }
} catch {
    Register-Check -Name "RADIUS Clients" -Status WARN -Message "Cannot query"
}

# Best practice: Check for weak shared secrets
# Note: We can't read the actual secrets, but we can recommend strong ones
Register-Check -Name "Shared Secret Policy" -Status INFO -Message "Verify all shared secrets are 22+ characters"

# ============================================================================
# RADIUS SERVER GROUPS
# ============================================================================
Write-Section "RADIUS Server Groups"

try {
    $serverOutput = netsh nps show remoteserver 2>&1

    if ($serverOutput -match "Server Group") {
        Register-Check -Name "Remote RADIUS Servers" -Status INFO -Message "Server groups configured for proxy scenarios"
    } else {
        Register-Check -Name "Remote RADIUS Servers" -Status INFO -Message "No remote servers (local authentication)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# NETWORK POLICIES
# ============================================================================
Write-Section "Network Policies"

try {
    $policyOutput = netsh nps show np all 2>&1

    # Parse policy information
    $policies = @()
    $currentPolicy = $null

    foreach ($line in $policyOutput) {
        if ($line -match "Policy Name:(.+)") {
            if ($currentPolicy) { $policies += $currentPolicy }
            $currentPolicy = @{ Name = $matches[1].Trim() }
        }
        elseif ($line -match "State:(.+)" -and $currentPolicy) {
            $currentPolicy.State = $matches[1].Trim()
        }
        elseif ($line -match "Processing Order:(.+)" -and $currentPolicy) {
            $currentPolicy.Order = $matches[1].Trim()
        }
    }
    if ($currentPolicy) { $policies += $currentPolicy }

    if ($policies.Count -gt 0) {
        Register-Check -Name "Network Policies" -Status INFO -Message "$($policies.Count) policy/policies configured"

        $enabledPolicies = ($policies | Where-Object { $_.State -eq 'Enable' }).Count
        $disabledPolicies = $policies.Count - $enabledPolicies
        Register-Check -Name "Policy Status" -Status INFO -Message "$enabledPolicies enabled, $disabledPolicies disabled"

        # Check for default deny policy
        $hasDenyPolicy = $policies | Where-Object { $_.Name -match 'deny|block|reject' }
        if ($hasDenyPolicy) {
            Register-Check -Name "Explicit Deny Policy" -Status PASS -Message "Present"
        } else {
            Register-Check -Name "Explicit Deny Policy" -Status INFO -Message "Consider adding explicit deny"
        }
    } else {
        Register-Check -Name "Network Policies" -Status WARN -Message "No policies found"
    }

} catch {
    Register-Check -Name "Network Policies" -Status WARN -Message "Cannot query"
}

# ============================================================================
# CONNECTION REQUEST POLICIES
# ============================================================================
Write-Section "Connection Request Policies"

try {
    $crpOutput = netsh nps show crp all 2>&1

    $crpPolicies = @()
    $currentCRP = $null

    foreach ($line in $crpOutput) {
        if ($line -match "Policy Name:(.+)") {
            if ($currentCRP) { $crpPolicies += $currentCRP }
            $currentCRP = @{ Name = $matches[1].Trim() }
        }
        elseif ($line -match "State:(.+)" -and $currentCRP) {
            $currentCRP.State = $matches[1].Trim()
        }
    }
    if ($currentCRP) { $crpPolicies += $currentCRP }

    if ($crpPolicies.Count -gt 0) {
        Register-Check -Name "Connection Request Policies" -Status INFO -Message "$($crpPolicies.Count) CRP(s) configured"
    }

} catch {
    Register-Check -Name "Connection Request Policies" -Status WARN -Message "Cannot query"
}

# ============================================================================
# AUTHENTICATION METHODS
# ============================================================================
Write-Section "Authentication Methods"

# Check for EAP types (certificate-based is more secure)
$secureEAP = @('PEAP', 'EAP-TLS', 'EAP-TTLS')
$weakEAP = @('PAP', 'CHAP', 'MS-CHAPv1')

try {
    $authOutput = netsh nps show np all 2>&1

    # Check for weak authentication
    $hasWeakAuth = $false
    $hasStrongAuth = $false

    foreach ($weak in $weakEAP) {
        if ($authOutput -match $weak) {
            $hasWeakAuth = $true
            Register-Check -Name "Weak Auth: $weak" -Status WARN -Message "Detected in policies"
        }
    }

    foreach ($strong in $secureEAP) {
        if ($authOutput -match $strong) {
            $hasStrongAuth = $true
        }
    }

    if ($hasStrongAuth) {
        Register-Check -Name "EAP-TLS/PEAP" -Status PASS -Message "Strong authentication available"
    }

    if (-not $hasWeakAuth) {
        Register-Check -Name "Weak Authentication" -Status PASS -Message "No weak methods detected"
    }

    # MS-CHAPv2 is acceptable but note it
    if ($authOutput -match "MS-CHAPv2|MS-CHAP v2") {
        Register-Check -Name "MS-CHAPv2" -Status INFO -Message "In use - ensure strong passwords"
    }

} catch {
    Register-Check -Name "Authentication Methods" -Status WARN -Message "Cannot fully verify"
}

# ============================================================================
# CERTIFICATE CONFIGURATION
# ============================================================================
Write-Section "Certificate Configuration"

# Check for NPS server certificate
try {
    $npsCerts = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
        Where-Object { $_.EnhancedKeyUsageList.FriendlyName -contains 'Server Authentication' }

    if ($npsCerts) {
        foreach ($cert in $npsCerts | Select-Object -First 3) {
            $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days

            if ($daysUntilExpiry -gt 90) {
                Register-Check -Name "Server Cert: $($cert.Subject.Substring(0, [Math]::Min(30, $cert.Subject.Length)))" -Status PASS -Message "Valid ($daysUntilExpiry days)"
            } elseif ($daysUntilExpiry -gt 30) {
                Register-Check -Name "Server Cert: $($cert.Subject.Substring(0, [Math]::Min(30, $cert.Subject.Length)))" -Status WARN -Message "Expires in $daysUntilExpiry days"
            } else {
                Register-Check -Name "Server Cert: $($cert.Subject.Substring(0, [Math]::Min(30, $cert.Subject.Length)))" -Status FAIL -Message "Expires in $daysUntilExpiry days"
            }

            # Key size
            if ($cert.PublicKey.Key.KeySize -ge 2048) {
                Register-Check -Name "Cert Key Size" -Status PASS -Message "$($cert.PublicKey.Key.KeySize) bits"
            } else {
                Register-Check -Name "Cert Key Size" -Status FAIL -Message "$($cert.PublicKey.Key.KeySize) bits (minimum 2048)"
            }
        }
    } else {
        Register-Check -Name "Server Certificate" -Status INFO -Message "No server auth certificates found"
    }
} catch {
    Register-Check -Name "Certificate Check" -Status WARN -Message "Cannot query"
}

# ============================================================================
# ACCOUNTING AND LOGGING
# ============================================================================
Write-Section "Accounting and Logging"

try {
    # Check accounting configuration
    $accountingOutput = netsh nps show accountingconfig 2>&1

    if ($accountingOutput -match "SQL") {
        Register-Check -Name "SQL Logging" -Status PASS -Message "Configured"
    }

    if ($accountingOutput -match "Local file") {
        Register-Check -Name "Local File Logging" -Status PASS -Message "Enabled"
    }

} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check NPS log files
$npsLogPath = "$env:SystemRoot\System32\LogFiles\IN*.log"
$npsLogs = Get-ChildItem -Path $npsLogPath -ErrorAction SilentlyContinue

if ($npsLogs) {
    Register-Check -Name "IAS Log Files" -Status PASS -Message "$($npsLogs.Count) log file(s)"

    $latestLog = $npsLogs | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $logAge = ((Get-Date) - $latestLog.LastWriteTime).Days

    if ($logAge -lt 1) {
        Register-Check -Name "Recent Logging" -Status PASS -Message "Active (updated today)"
    } elseif ($logAge -lt 7) {
        Register-Check -Name "Recent Logging" -Status INFO -Message "Last update $logAge days ago"
    } else {
        Register-Check -Name "Recent Logging" -Status WARN -Message "Last update $logAge days ago"
    }
} else {
    Register-Check -Name "IAS Log Files" -Status WARN -Message "No logs found"
}

# Event logging
try {
    # Check Security event log for NPS events
    $npsEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        Id = @(6272, 6273, 6274, 6275, 6276, 6277, 6278, 6279, 6280)
    } -MaxEvents 1 -ErrorAction SilentlyContinue

    if ($npsEvents) {
        Register-Check -Name "Security Event Logging" -Status PASS -Message "NPS events in Security log"
    } else {
        Register-Check -Name "Security Event Logging" -Status INFO -Message "No recent NPS events"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check if NPS is a member of RAS and IAS Servers group in AD
try {
    $adGroups = Get-ADComputer -Identity $env:COMPUTERNAME -Properties MemberOf -ErrorAction SilentlyContinue

    if ($adGroups.MemberOf -match "RAS and IAS Servers") {
        Register-Check -Name "RAS and IAS Servers Group" -Status PASS -Message "Computer is member"
    }
} catch {
    Register-Check -Name "AD Group Membership" -Status INFO -Message "Cannot verify (may not be domain-joined)"
}

# Check Network Policy and Access Services event log
try {
    $npasLog = Get-WinEvent -ListLog "Microsoft-Windows-NetworkPolicy/Operational" -ErrorAction SilentlyContinue
    if ($npasLog -and $npasLog.IsEnabled) {
        Register-Check -Name "NPAS Operational Log" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "NPAS Operational Log" -Status WARN -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for RADIUS ports
try {
    $radiusAuth = Get-NetTCPConnection -LocalPort 1812 -ErrorAction SilentlyContinue
    $radiusAcct = Get-NetTCPConnection -LocalPort 1813 -ErrorAction SilentlyContinue

    if ($radiusAuth) {
        Register-Check -Name "RADIUS Auth Port (1812)" -Status PASS -Message "Listening"
    }
    if ($radiusAcct) {
        Register-Check -Name "RADIUS Acct Port (1813)" -Status PASS -Message "Listening"
    }

    # Legacy ports (1645/1646) - should be disabled
    $legacyAuth = Get-NetTCPConnection -LocalPort 1645 -ErrorAction SilentlyContinue
    $legacyAcct = Get-NetTCPConnection -LocalPort 1646 -ErrorAction SilentlyContinue

    if ($legacyAuth -or $legacyAcct) {
        Register-Check -Name "Legacy RADIUS Ports" -Status INFO -Message "1645/1646 in use (legacy)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# NAP (Network Access Protection) - deprecated but check
try {
    $napFeature = Get-WindowsFeature -Name NPAS-Health -ErrorAction SilentlyContinue
    if ($napFeature -and $napFeature.Installed) {
        Register-Check -Name "NAP (Deprecated)" -Status WARN -Message "NAP is deprecated - plan migration"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Remediation server groups (NAP)
try {
    $remOutput = netsh nps show remediationservergroup 2>&1
    if ($remOutput -match "Server Group Name") {
        Register-Check -Name "Remediation Servers" -Status INFO -Message "Configured (NAP)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
