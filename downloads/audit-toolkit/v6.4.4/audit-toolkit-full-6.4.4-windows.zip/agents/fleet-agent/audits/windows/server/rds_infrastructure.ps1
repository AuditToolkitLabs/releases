<#
.SYNOPSIS
    Remote Desktop Services Infrastructure Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows RDS Infrastructure:
    - RD Gateway configuration
    - RD Connection Broker
    - RD Web Access
    - RD Licensing
    - RD Session Host
    - Connection policies (CAP/RAP)
    - Certificate security
    - Session security

.NOTES
    @elevation: admin
    @elevation-reason: RDS cmdlets require Administrator privileges
    Requires: Remote Desktop Services role installed

Compliance Mapping:
- CIS Controls: 4.2 (Secure Configuration), 12.6 (Network Traffic Security)
- CIS Windows Server 2022: 18.9.60.x (Remote Desktop Services)
- NIST SP 800-53: AC-17 (Remote Access), SC-8 (Transmission Confidentiality)
- Microsoft Security Baseline for RDS
- MITRE ATT&CK: T1021.001 (Remote Desktop Protocol), T1563 (Remote Service Session Hijacking)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Remote Desktop Services Infrastructure Security Audit"

# ============================================================================
# RDS ROLE CHECK
# ============================================================================
Write-Section "RDS Role Status"

$hasRdsGateway = $false
$hasRdsBroker = $false
$hasRdsWeb = $false
$hasRdsHost = $false
$hasRdsLicensing = $false

try {
    $rdsFeatures = Get-WindowsFeature -Name RDS-* -ErrorAction Stop

    foreach ($feature in $rdsFeatures | Where-Object { $_.Installed }) {
        switch ($feature.Name) {
            'RDS-Gateway' {
                $hasRdsGateway = $true
                Register-Check -Name "RD Gateway" -Status PASS -Message "Installed"
            }
            'RDS-Connection-Broker' {
                $hasRdsBroker = $true
                Register-Check -Name "RD Connection Broker" -Status PASS -Message "Installed"
            }
            'RDS-Web-Access' {
                $hasRdsWeb = $true
                Register-Check -Name "RD Web Access" -Status PASS -Message "Installed"
            }
            'RDS-RD-Server' {
                $hasRdsHost = $true
                Register-Check -Name "RD Session Host" -Status PASS -Message "Installed"
            }
            'RDS-Licensing' {
                $hasRdsLicensing = $true
                Register-Check -Name "RD Licensing" -Status PASS -Message "Installed"
            }
        }
    }

    $totalRoles = @($hasRdsGateway, $hasRdsBroker, $hasRdsWeb, $hasRdsHost, $hasRdsLicensing) | Where-Object { $_ } | Measure-Object | Select-Object -ExpandProperty Count

    if ($totalRoles -eq 0) {
        Register-Check -Name "RDS Roles" -Status SKIP -Message "No RDS roles installed"
        Print-Summary
        Exit-Audit
    }

} catch {
    Register-Check -Name "RDS Roles" -Status WARN -Message "Cannot determine role status"
}

# ============================================================================
# RD GATEWAY SECURITY
# ============================================================================
if ($hasRdsGateway) {
    Write-Section "RD Gateway Security"

    try {
        Import-Module RemoteDesktopServices -ErrorAction Stop

        # Check RD Gateway service
        $rdgSvc = Get-Service -Name TSGateway -ErrorAction SilentlyContinue
        if ($rdgSvc -and $rdgSvc.Status -eq 'Running') {
            Register-Check -Name "RD Gateway Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "RD Gateway Service" -Status WARN -Message "Not running"
        }

    } catch {
        Register-Check -Name "RDS Module" -Status WARN -Message "Cannot load module"
    }

    # Gateway SSL Certificate
    try {
        $rdgConfig = Get-Item -Path RDS:\GatewayServer\SSLCertificate -ErrorAction SilentlyContinue
        if ($rdgConfig) {
            $certThumb = $rdgConfig.CurrentValue
            $cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $certThumb }

            if ($cert) {
                $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days

                if ($daysUntilExpiry -gt 90) {
                    Register-Check -Name "Gateway SSL Cert" -Status PASS -Message "Valid ($daysUntilExpiry days)"
                } elseif ($daysUntilExpiry -gt 30) {
                    Register-Check -Name "Gateway SSL Cert" -Status WARN -Message "Expires in $daysUntilExpiry days"
                } else {
                    Register-Check -Name "Gateway SSL Cert" -Status FAIL -Message "Expires in $daysUntilExpiry days"
                }

                # Key size
                if ($cert.PublicKey.Key.KeySize -ge 2048) {
                    Register-Check -Name "SSL Key Size" -Status PASS -Message "$($cert.PublicKey.Key.KeySize) bits"
                } else {
                    Register-Check -Name "SSL Key Size" -Status FAIL -Message "$($cert.PublicKey.Key.KeySize) bits (min 2048)"
                }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Connection Authorization Policies (CAP)
    try {
        $caps = Get-Item -Path "RDS:\GatewayServer\CAP" -ErrorAction SilentlyContinue
        if ($caps) {
            $capList = Get-ChildItem -Path "RDS:\GatewayServer\CAP" -ErrorAction SilentlyContinue
            if ($capList) {
                Register-Check -Name "CAP Policies" -Status INFO -Message "$($capList.Count) policy/policies"

                foreach ($cap in $capList) {
                    $capEnabled = Get-ItemProperty -Path "RDS:\GatewayServer\CAP\$($cap.Name)" -Name Status -ErrorAction SilentlyContinue
                    if ($capEnabled.CurrentValue -eq 1) {
                        Register-Check -Name "CAP: $($cap.Name)" -Status INFO -Message "Enabled"
                    }
                }
            }
        }
    } catch {
        Register-Check -Name "CAP Policies" -Status WARN -Message "Cannot query"
    }

    # Resource Authorization Policies (RAP)
    try {
        $raps = Get-ChildItem -Path "RDS:\GatewayServer\RAP" -ErrorAction SilentlyContinue
        if ($raps) {
            Register-Check -Name "RAP Policies" -Status INFO -Message "$($raps.Count) policy/policies"

            foreach ($rap in $raps) {
                $rapEnabled = Get-ItemProperty -Path "RDS:\GatewayServer\RAP\$($rap.Name)" -Name Status -ErrorAction SilentlyContinue
                if ($rapEnabled.CurrentValue -eq 1) {
                    # Check if allows all computers
                    $resourceGroup = Get-ItemProperty -Path "RDS:\GatewayServer\RAP\$($rap.Name)" -Name ResourceGroupType -ErrorAction SilentlyContinue
                    if ($resourceGroup.CurrentValue -eq 0) {
                        Register-Check -Name "RAP: $($rap.Name)" -Status WARN -Message "Allows ALL computers"
                    } else {
                        Register-Check -Name "RAP: $($rap.Name)" -Status PASS -Message "Resource group restricted"
                    }
                }
            }
        }
    } catch {
        Register-Check -Name "RAP Policies" -Status WARN -Message "Cannot query"
    }

    # Gateway authentication
    try {
        $authMethod = Get-ItemProperty -Path "RDS:\GatewayServer\AuthMethod" -ErrorAction SilentlyContinue
        if ($authMethod) {
            switch ($authMethod.CurrentValue) {
                1 { Register-Check -Name "Gateway Auth" -Status INFO -Message "Password only" }
                2 { Register-Check -Name "Gateway Auth" -Status PASS -Message "Smartcard only" }
                3 { Register-Check -Name "Gateway Auth" -Status INFO -Message "Password or Smartcard" }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # UDP transport
    try {
        $udpEnabled = Get-ItemProperty -Path "RDS:\GatewayServer\TransportHttp" -ErrorAction SilentlyContinue
        if ($udpEnabled) {
            Register-Check -Name "UDP Transport" -Status INFO -Message "HTTP tunneling configured"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Max connections
    try {
        $maxConn = Get-ItemProperty -Path "RDS:\GatewayServer\MaxConnections" -ErrorAction SilentlyContinue
        if ($maxConn -and $maxConn.CurrentValue -gt 0) {
            Register-Check -Name "Max Connections" -Status PASS -Message "Limited to $($maxConn.CurrentValue)"
        } else {
            Register-Check -Name "Max Connections" -Status INFO -Message "Unlimited"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# RD CONNECTION BROKER
# ============================================================================
if ($hasRdsBroker) {
    Write-Section "RD Connection Broker"

    try {
        $brokerSvc = Get-Service -Name Tssdis -ErrorAction SilentlyContinue
        if ($brokerSvc -and $brokerSvc.Status -eq 'Running') {
            Register-Check -Name "Connection Broker Service" -Status PASS -Message "Running"
        } else {
            Register-Check -Name "Connection Broker Service" -Status WARN -Message "Not running"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # High availability
    try {
        $haConfig = Get-RDConnectionBrokerHighAvailability -ErrorAction SilentlyContinue
        if ($haConfig) {
            Register-Check -Name "Broker HA" -Status PASS -Message "High availability configured"
            Register-Check -Name "Broker Database" -Status INFO -Message $haConfig.DatabaseConnectionString
        } else {
            Register-Check -Name "Broker HA" -Status INFO -Message "Single broker deployment"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# RD WEB ACCESS
# ============================================================================
if ($hasRdsWeb) {
    Write-Section "RD Web Access"

    # Check IIS configuration for RDWeb
    try {
        Import-Module WebAdministration -ErrorAction Stop

        $rdwebSite = Get-WebSite | Where-Object { $_.Name -eq 'Default Web Site' }
        if ($rdwebSite) {
            $rdwebApp = Get-WebApplication -Site 'Default Web Site' -Name 'RDWeb' -ErrorAction SilentlyContinue
            if ($rdwebApp) {
                Register-Check -Name "RDWeb Application" -Status PASS -Message "Configured in IIS"

                # SSL requirement
                $sslConfig = Get-WebConfigurationProperty -Filter system.webServer/security/access -PSPath "IIS:\Sites\Default Web Site\RDWeb" -Name sslFlags -ErrorAction SilentlyContinue
                if ($sslConfig -and $sslConfig -match 'Ssl') {
                    Register-Check -Name "RDWeb SSL" -Status PASS -Message "Required"
                } else {
                    Register-Check -Name "RDWeb SSL" -Status FAIL -Message "Not required"
                }
            }
        }
    } catch {
        Register-Check -Name "RDWeb" -Status WARN -Message "Cannot query IIS configuration"
    }
}

# ============================================================================
# RD SESSION HOST
# ============================================================================
if ($hasRdsHost) {
    Write-Section "RD Session Host Security"

    try {
        $termSvc = Get-Service -Name TermService -ErrorAction Stop
        if ($termSvc.Status -eq 'Running') {
            Register-Check -Name "Terminal Services" -Status PASS -Message "Running"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Check session security via registry
    $rdpPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"

    try {
        # Security layer
        $securityLayer = Get-ItemProperty -Path $rdpPath -Name SecurityLayer -ErrorAction SilentlyContinue
        if ($securityLayer) {
            switch ($securityLayer.SecurityLayer) {
                0 { Register-Check -Name "RDP Security Layer" -Status FAIL -Message "RDP (legacy)" }
                1 { Register-Check -Name "RDP Security Layer" -Status INFO -Message "Negotiate" }
                2 { Register-Check -Name "RDP Security Layer" -Status PASS -Message "SSL/TLS" }
            }
        }

        # User authentication (NLA)
        $nla = Get-ItemProperty -Path $rdpPath -Name UserAuthentication -ErrorAction SilentlyContinue
        if ($nla -and $nla.UserAuthentication -eq 1) {
            Register-Check -Name "Network Level Auth (NLA)" -Status PASS -Message "Required"
        } else {
            Register-Check -Name "Network Level Auth (NLA)" -Status FAIL -Message "Not required"
        }

        # Minimum encryption level
        $encLevel = Get-ItemProperty -Path $rdpPath -Name MinEncryptionLevel -ErrorAction SilentlyContinue
        if ($encLevel) {
            switch ($encLevel.MinEncryptionLevel) {
                1 { Register-Check -Name "RDP Encryption" -Status WARN -Message "Low" }
                2 { Register-Check -Name "RDP Encryption" -Status INFO -Message "Negotiated" }
                3 { Register-Check -Name "RDP Encryption" -Status PASS -Message "High" }
                4 { Register-Check -Name "RDP Encryption" -Status PASS -Message "FIPS Compliant" }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # GPO Settings
    $rdpGPOPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"

    if (Test-Path $rdpGPOPath) {
        try {
            # Disable clipboard
            $clipboard = Get-ItemProperty -Path $rdpGPOPath -Name fDisableClip -ErrorAction SilentlyContinue
            if ($clipboard -and $clipboard.fDisableClip -eq 1) {
                Register-Check -Name "Clipboard Redirection" -Status PASS -Message "Disabled"
            } else {
                Register-Check -Name "Clipboard Redirection" -Status INFO -Message "Enabled"
            }

            # Disable drive redirection
            $drives = Get-ItemProperty -Path $rdpGPOPath -Name fDisableCdm -ErrorAction SilentlyContinue
            if ($drives -and $drives.fDisableCdm -eq 1) {
                Register-Check -Name "Drive Redirection" -Status PASS -Message "Disabled"
            } else {
                Register-Check -Name "Drive Redirection" -Status WARN -Message "Enabled"
            }

            # Disable printer redirection
            $printer = Get-ItemProperty -Path $rdpGPOPath -Name fDisableCpm -ErrorAction SilentlyContinue
            if ($printer -and $printer.fDisableCpm -eq 1) {
                Register-Check -Name "Printer Redirection" -Status PASS -Message "Disabled"
            }

            # Session idle timeout
            $idleTimeout = Get-ItemProperty -Path $rdpGPOPath -Name MaxIdleTime -ErrorAction SilentlyContinue
            if ($idleTimeout -and $idleTimeout.MaxIdleTime -gt 0) {
                $minutes = $idleTimeout.MaxIdleTime / 60000
                Register-Check -Name "Idle Timeout" -Status PASS -Message "$minutes minutes"
            } else {
                Register-Check -Name "Idle Timeout" -Status WARN -Message "Not configured"
            }

            # Session disconnect timeout
            $disconnectTimeout = Get-ItemProperty -Path $rdpGPOPath -Name MaxDisconnectionTime -ErrorAction SilentlyContinue
            if ($disconnectTimeout -and $disconnectTimeout.MaxDisconnectionTime -gt 0) {
                $minutes = $disconnectTimeout.MaxDisconnectionTime / 60000
                Register-Check -Name "Disconnect Timeout" -Status PASS -Message "$minutes minutes"
            }

            # Remote control/shadowing
            $shadow = Get-ItemProperty -Path $rdpGPOPath -Name Shadow -ErrorAction SilentlyContinue
            if ($shadow) {
                switch ($shadow.Shadow) {
                    0 { Register-Check -Name "Remote Control" -Status PASS -Message "Disabled" }
                    1 { Register-Check -Name "Remote Control" -Status INFO -Message "Full control with permission" }
                    2 { Register-Check -Name "Remote Control" -Status WARN -Message "Full control without permission" }
                    3 { Register-Check -Name "Remote Control" -Status INFO -Message "View with permission" }
                    4 { Register-Check -Name "Remote Control" -Status WARN -Message "View without permission" }
                }
            }

        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
}

# ============================================================================
# RD LICENSING
# ============================================================================
if ($hasRdsLicensing) {
    Write-Section "RD Licensing"

    try {
        $licSvc = Get-Service -Name TermServLicensing -ErrorAction SilentlyContinue
        if ($licSvc -and $licSvc.Status -eq 'Running') {
            Register-Check -Name "Licensing Service" -Status PASS -Message "Running"
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    # Check license server activation
    try {
        $licServer = Get-CimInstance -ClassName Win32_TSLicenseServer -ErrorAction SilentlyContinue
        if ($licServer) {
            if ($licServer.GetIsActivated()) {
                Register-Check -Name "License Server" -Status PASS -Message "Activated"
            } else {
                Register-Check -Name "License Server" -Status WARN -Message "Not activated"
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

# ============================================================================
# GENERAL RDS SECURITY
# ============================================================================
Write-Section "General RDS Security"

# Check RDP port
try {
    $rdpPort = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name PortNumber -ErrorAction SilentlyContinue
    if ($rdpPort) {
        if ($rdpPort.PortNumber -eq 3389) {
            Register-Check -Name "RDP Port" -Status INFO -Message "Default (3389)"
        } else {
            Register-Check -Name "RDP Port" -Status PASS -Message "Custom ($($rdpPort.PortNumber))"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# RDP firewall rules restricted to specific IPs?
try {
    $rdpRules = Get-NetFirewallRule -DisplayName "*Remote Desktop*" -ErrorAction SilentlyContinue |
        Where-Object { $_.Enabled -eq $true }

    if ($rdpRules) {
        foreach ($rule in $rdpRules | Select-Object -First 2) {
            $addressFilter = Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $rule
            if ($addressFilter.RemoteAddress -ne 'Any') {
                Register-Check -Name "RDP FW: $($rule.DisplayName.Substring(0,30))" -Status PASS -Message "IP restricted"
            } else {
                Register-Check -Name "RDP FW: $($rule.DisplayName.Substring(0,30))" -Status WARN -Message "Allows any IP"
            }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for RemoteFX (GPU)
try {
    $remoteFX = Get-WindowsFeature -Name RDS-Virtualization -ErrorAction SilentlyContinue
    if ($remoteFX -and $remoteFX.Installed) {
        Register-Check -Name "RemoteFX" -Status INFO -Message "Installed - review CVE-2020-1036 mitigations"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
