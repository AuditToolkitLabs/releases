<#
.SYNOPSIS
    Windows RRAS VPN Server Security Audit

.DESCRIPTION
    Comprehensive security audit for Windows RRAS VPN:
    - RRAS service configuration
    - VPN protocols (IKEv2, SSTP, L2TP, PPTP)
    - IPsec policies
    - Authentication methods
    - Encryption settings
    - Routing configuration
    - NAT configuration
    - Logging and monitoring

.NOTES
    @elevation: admin
    @elevation-reason: RRAS cmdlets require Administrator privileges
    Requires: Remote Access role installed

Compliance Mapping:
- CIS Controls: 12.6 (Deploy Network-Based IPS), 13.2 (Deploy Control Port Access)
- NIST SP 800-53: AC-17 (Remote Access), SC-8 (Transmission Confidentiality)
- NIST SP 800-77: Guide to IPsec VPNs
- Microsoft Security Baseline for VPN
- MITRE ATT&CK: T1133 (External Remote Services), T1071 (Application Layer Protocol)
#>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

Import-Module "$PSScriptRoot/../common/common-audit.psm1"

function Write-Section {
    param([string]$Title)
    Write-Output ""
    Write-Output "=== $Title ==="
    Write-Output ""
}

Write-Section "Windows RRAS VPN Server Security Audit"

# ============================================================================
# RRAS ROLE CHECK
# ============================================================================
Write-Section "RRAS Role Status"

$isRras = $false

try {
    $rrasFeature = Get-WindowsFeature -Name RemoteAccess -ErrorAction Stop
    if ($rrasFeature.Installed) {
        Register-Check -Name "Remote Access Role" -Status PASS -Message "Installed"
    } else {
        Register-Check -Name "Remote Access Role" -Status SKIP -Message "Not installed"
        Print-Summary
        Exit-Audit
    }

    # Check sub-features
    $vpnFeature = Get-WindowsFeature -Name DirectAccess-VPN -ErrorAction SilentlyContinue
    if ($vpnFeature -and $vpnFeature.Installed) {
        Register-Check -Name "DirectAccess and VPN" -Status PASS -Message "Installed"
    }

    $routingFeature = Get-WindowsFeature -Name Routing -ErrorAction SilentlyContinue
    if ($routingFeature -and $routingFeature.Installed) {
        Register-Check -Name "Routing" -Status PASS -Message "Installed"
    }

} catch {
    Register-Check -Name "Remote Access Role" -Status SKIP -Message "Cannot determine role status"
    Print-Summary
    Exit-Audit
}

# Check RRAS service
try {
    $rrasSvc = Get-Service -Name RemoteAccess -ErrorAction Stop
    if ($rrasSvc.Status -eq 'Running') {
        $isRras = $true
        Register-Check -Name "RRAS Service" -Status PASS -Message "Running"
    } else {
        Register-Check -Name "RRAS Service" -Status INFO -Message "Status: $($rrasSvc.Status)"
    }

    if ($rrasSvc.StartType -eq 'Automatic') {
        Register-Check -Name "RRAS Service Startup" -Status PASS -Message "Automatic"
    } else {
        Register-Check -Name "RRAS Service Startup" -Status INFO -Message $rrasSvc.StartType
    }
} catch {
    Register-Check -Name "RRAS Service" -Status WARN -Message "Cannot query"
}

# Import RemoteAccess module
try {
    Import-Module RemoteAccess -ErrorAction Stop
    Register-Check -Name "RemoteAccess Module" -Status PASS -Message "Loaded"
} catch {
    Register-Check -Name "RemoteAccess Module" -Status WARN -Message "Cannot load module"
}

if (-not $isRras) {
    Register-Check -Name "RRAS Configuration" -Status INFO -Message "RRAS not running - limited checks available"
}

# ============================================================================
# VPN CONFIGURATION
# ============================================================================
Write-Section "VPN Configuration"

try {
    $vpnConfig = Get-RemoteAccess -ErrorAction SilentlyContinue

    if ($vpnConfig) {
        # VPN Status
        if ($vpnConfig.VpnStatus -eq 'Installed') {
            Register-Check -Name "VPN Status" -Status PASS -Message "Installed and configured"
        }

        # DirectAccess status
        if ($vpnConfig.DAStatus -eq 'Installed') {
            Register-Check -Name "DirectAccess" -Status INFO -Message "Configured"
        }

        # Routing status
        if ($vpnConfig.RoutingStatus -eq 'Installed') {
            Register-Check -Name "Routing Status" -Status INFO -Message "Configured"
        }

    }
} catch {
    Register-Check -Name "VPN Config" -Status WARN -Message "Cannot query via RemoteAccess module"
}

# ============================================================================
# VPN PROTOCOLS
# ============================================================================
Write-Section "VPN Protocols"

# Check protocol security via registry
# IKEv2 (recommended)
try {
    $ikev2Settings = Get-VpnServerIPsecConfiguration -ErrorAction SilentlyContinue
    if ($ikev2Settings) {
        Register-Check -Name "IKEv2" -Status PASS -Message "Configured"

        # Encryption algorithm
        $encAlgo = $ikev2Settings.EncryptionMethod
        if ($encAlgo -match 'AES.*256|AES.*GCM') {
            Register-Check -Name "IKEv2 Encryption" -Status PASS -Message $encAlgo
        } elseif ($encAlgo -match 'AES.*128') {
            Register-Check -Name "IKEv2 Encryption" -Status INFO -Message $encAlgo
        } elseif ($encAlgo -match '3DES|DES') {
            Register-Check -Name "IKEv2 Encryption" -Status FAIL -Message "$encAlgo (weak)"
        }

        # Integrity algorithm
        $intAlgo = $ikev2Settings.IntegrityCheckMethod
        if ($intAlgo -match 'SHA256|SHA384|SHA512') {
            Register-Check -Name "IKEv2 Integrity" -Status PASS -Message $intAlgo
        } elseif ($intAlgo -match 'SHA1') {
            Register-Check -Name "IKEv2 Integrity" -Status WARN -Message "$intAlgo (recommend SHA256+)"
        } elseif ($intAlgo -match 'MD5') {
            Register-Check -Name "IKEv2 Integrity" -Status FAIL -Message "$intAlgo (insecure)"
        }

        # DH Group
        $dhGroup = $ikev2Settings.DHGroup
        if ($dhGroup -match 'Group14|Group24|ECP|Group19|Group20') {
            Register-Check -Name "IKEv2 DH Group" -Status PASS -Message $dhGroup
        } elseif ($dhGroup -match 'Group2') {
            Register-Check -Name "IKEv2 DH Group" -Status FAIL -Message "$dhGroup (weak)"
        }

        # SA Lifetime
        $saLifetime = $ikev2Settings.SALifeTime
        if ($saLifetime.TotalHours -le 8) {
            Register-Check -Name "IKEv2 SA Lifetime" -Status PASS -Message "$($saLifetime.TotalHours) hours"
        } else {
            Register-Check -Name "IKEv2 SA Lifetime" -Status INFO -Message "$($saLifetime.TotalHours) hours"
        }
    }
} catch {
    Register-Check -Name "IKEv2" -Status INFO -Message "Cannot verify configuration"
}

# SSTP (Secure Socket Tunneling Protocol)
try {
    $sstpConfig = Get-VpnServerConfiguration -ErrorAction SilentlyContinue
    if ($sstpConfig) {
        Register-Check -Name "SSTP" -Status PASS -Message "Available"
    }

    # Check SSTP certificate
    $sstpCert = Get-RemoteAccessSstpCertificate -ErrorAction SilentlyContinue
    if ($sstpCert) {
        $cert = Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $sstpCert.CertificateHash }
        if ($cert) {
            $daysUntilExpiry = ($cert.NotAfter - (Get-Date)).Days

            if ($daysUntilExpiry -gt 90) {
                Register-Check -Name "SSTP Certificate" -Status PASS -Message "Valid ($daysUntilExpiry days)"
            } elseif ($daysUntilExpiry -gt 30) {
                Register-Check -Name "SSTP Certificate" -Status WARN -Message "Expires in $daysUntilExpiry days"
            } else {
                Register-Check -Name "SSTP Certificate" -Status FAIL -Message "Expires in $daysUntilExpiry days"
            }

            if ($cert.PublicKey.Key.KeySize -ge 2048) {
                Register-Check -Name "SSTP Cert Key Size" -Status PASS -Message "$($cert.PublicKey.Key.KeySize) bits"
            }
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# L2TP/IPsec
try {
    $l2tpPath = "HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Parameters"
    $l2tpPsk = Get-ItemProperty -Path $l2tpPath -Name "ProhibitIPsec" -ErrorAction SilentlyContinue

    if ($l2tpPsk -and $l2tpPsk.ProhibitIPsec -eq 1) {
        Register-Check -Name "L2TP IPsec" -Status FAIL -Message "IPsec disabled for L2TP"
    } else {
        Register-Check -Name "L2TP/IPsec" -Status INFO -Message "Available"
    }

    # Check for PSK vs certificate
    $l2tpCert = Get-ItemProperty -Path $l2tpPath -Name "AllowL2TPWeakCrypto" -ErrorAction SilentlyContinue
    if ($l2tpCert -and $l2tpCert.AllowL2TPWeakCrypto -eq 1) {
        Register-Check -Name "L2TP Weak Crypto" -Status FAIL -Message "Weak encryption allowed"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# PPTP (should be disabled)
try {
    $pptpEnabled = Get-VpnPptpConfiguration -ErrorAction SilentlyContinue
    if ($pptpEnabled) {
        Register-Check -Name "PPTP" -Status FAIL -Message "Enabled - disable this insecure protocol"
    }
} catch {
    # Try via netsh
    $pptpCheck = netsh ras show conf 2>&1
    if ($pptpCheck -match "PPTP.*enabled") {
        Register-Check -Name "PPTP" -Status FAIL -Message "Enabled - insecure protocol"
    } else {
        Register-Check -Name "PPTP" -Status PASS -Message "Not enabled or disabled"
    }
}

# ============================================================================
# AUTHENTICATION
# ============================================================================
Write-Section "Authentication Configuration"

try {
    $authConfig = Get-VpnAuthProtocol -ErrorAction SilentlyContinue

    if ($authConfig) {
        # User authentication
        $userAuth = $authConfig.UserAuthProtocolAccepted
        Register-Check -Name "User Auth Methods" -Status INFO -Message ($userAuth -join ', ')

        # Check for weak auth (PAP/CHAP)
        if ($userAuth -contains 'Pap') {
            Register-Check -Name "PAP Authentication" -Status FAIL -Message "Enabled - passwords sent in clear text"
        }

        if ($userAuth -contains 'Chap') {
            Register-Check -Name "CHAP Authentication" -Status WARN -Message "Enabled - consider stronger methods"
        }

        if ($userAuth -contains 'Eap') {
            Register-Check -Name "EAP Authentication" -Status PASS -Message "Enabled"
        }

        if ($userAuth -contains 'MSChapv2') {
            Register-Check -Name "MS-CHAPv2" -Status INFO -Message "Enabled - ensure enforced complexity"
        }

        # Root certificate required
        if ($authConfig.RootCertificateNameToAccept) {
            Register-Check -Name "Certificate Auth" -Status PASS -Message "Client cert verification configured"
        }
    }

} catch {
    Register-Check -Name "Authentication" -Status WARN -Message "Cannot query"
}

# RADIUS authentication
try {
    $radius = Get-RemoteAccessRadius -ErrorAction SilentlyContinue

    if ($radius) {
        Register-Check -Name "RADIUS Authentication" -Status INFO -Message "Configured"

        foreach ($server in $radius | Select-Object -First 2) {
            # Check if accounting enabled
            if ($server.AccountingOnOffMsg) {
                Register-Check -Name "RADIUS Server: $($server.ServerName)" -Status PASS -Message "With accounting"
            }
        }
    } else {
        Register-Check -Name "RADIUS" -Status INFO -Message "Local authentication in use"
    }

} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# IP ADDRESS POOLS
# ============================================================================
Write-Section "IP Address Configuration"

try {
    Get-RemoteAccessIPFilter -ErrorAction SilentlyContinue | Out-Null

    # Check address pool
    $addrPool = Get-RemoteAccessAddress -ErrorAction SilentlyContinue
    if ($addrPool) {
        Register-Check -Name "IP Address Pool" -Status INFO -Message "Configured"
    }

} catch { Write-Verbose 'Suppressed non-fatal error.' }

# DHCP relay
try {
    $vpnConfig = Get-RemoteAccess -ErrorAction SilentlyContinue
    if ($vpnConfig.IPAddressAssignment -eq 'Dhcp') {
        Register-Check -Name "IP Assignment" -Status INFO -Message "DHCP relay"
    } elseif ($vpnConfig.IPAddressAssignment -eq 'StaticPool') {
        Register-Check -Name "IP Assignment" -Status INFO -Message "Static pool"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# ROUTING AND NAT
# ============================================================================
Write-Section "Routing and NAT"

# Check if IP routing enabled
try {
    $ipRouting = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "IPEnableRouter" -ErrorAction SilentlyContinue

    if ($ipRouting -and $ipRouting.IPEnableRouter -eq 1) {
        Register-Check -Name "IP Routing" -Status INFO -Message "Enabled"
    } else {
        Register-Check -Name "IP Routing" -Status INFO -Message "Disabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# NAT configuration
try {
    $natConfig = Get-NetNat -ErrorAction SilentlyContinue

    if ($natConfig) {
        foreach ($nat in $natConfig) {
            Register-Check -Name "NAT: $($nat.Name)" -Status INFO -Message "Prefix: $($nat.InternalIPInterfaceAddressPrefix)"
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Static routes
try {
    $staticRoutes = netsh ras show conf 2>&1
    if ($staticRoutes -match "static route") {
        Register-Check -Name "Static Routes" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# CONNECTION LIMITS
# ============================================================================
Write-Section "Connection Limits"

try {
    $vpnConfig = Get-RemoteAccess -ErrorAction SilentlyContinue

    # Max VPN connections
    if ($vpnConfig.MaxVpnConnections) {
        Register-Check -Name "Max VPN Connections" -Status INFO -Message $vpnConfig.MaxVpnConnections
    }

} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Idle timeout
try {
    $idleTimeout = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RemoteAccess\Parameters" -Name "IdleDisconnectTime" -ErrorAction SilentlyContinue

    if ($idleTimeout -and $idleTimeout.IdleDisconnectTime -gt 0) {
        $minutes = $idleTimeout.IdleDisconnectTime
        Register-Check -Name "Idle Disconnect" -Status PASS -Message "$minutes minutes"
    } else {
        Register-Check -Name "Idle Disconnect" -Status WARN -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# LOGGING AND MONITORING
# ============================================================================
Write-Section "Logging and Monitoring"

# VPN logging
try {
    $accountingConfig = Get-RemoteAccessAccounting -ErrorAction SilentlyContinue

    if ($accountingConfig) {
        if ($accountingConfig.AccountingStore -eq 'InboxAccounting') {
            Register-Check -Name "VPN Accounting" -Status PASS -Message "Inbox accounting enabled"
        } elseif ($accountingConfig.AccountingStore -eq 'Radius') {
            Register-Check -Name "VPN Accounting" -Status PASS -Message "RADIUS accounting"
        } else {
            Register-Check -Name "VPN Accounting" -Status WARN -Message $accountingConfig.AccountingStore
        }
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Event logging
try {
    $rrasLog = Get-WinEvent -ListLog "Microsoft-Windows-RemoteAccess/Operational" -ErrorAction SilentlyContinue
    if ($rrasLog -and $rrasLog.IsEnabled) {
        Register-Check -Name "RRAS Operational Log" -Status PASS -Message "Enabled"
    } else {
        Register-Check -Name "RRAS Operational Log" -Status WARN -Message "Not enabled"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Security log events for VPN
try {
    $vpnEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Security'
        Id = @(6272, 6273, 20250, 20255)
    } -MaxEvents 1 -ErrorAction SilentlyContinue

    if ($vpnEvents) {
        Register-Check -Name "VPN Security Events" -Status PASS -Message "Logging to Security log"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# ============================================================================
# SECURITY BEST PRACTICES
# ============================================================================
Write-Section "Security Best Practices"

# Check for split tunneling
try {
    $splitTunnel = Get-VpnConnection -ErrorAction SilentlyContinue | Where-Object { $_.SplitTunneling -eq $true }
    if ($splitTunnel) {
        Register-Check -Name "Split Tunneling" -Status INFO -Message "Enabled on some connections"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Firewall rules for VPN
try {
    $vpnRules = Get-NetFirewallRule -DisplayGroup "*VPN*" -ErrorAction SilentlyContinue |
        Where-Object { $_.Enabled -eq $true }

    if ($vpnRules) {
        Register-Check -Name "VPN Firewall Rules" -Status INFO -Message "$($vpnRules.Count) rules enabled"
    }

    # IKEv2 ports (500, 4500)
    $ikeRules = Get-NetFirewallPortFilter -Protocol UDP | Where-Object { $_.LocalPort -in @('500', '4500') }
    if ($ikeRules) {
        Register-Check -Name "IKE Ports" -Status INFO -Message "UDP 500/4500 rules present"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Check for Always On VPN configuration
try {
    $alwaysOn = Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match 'Always On|AlwaysOn' }

    if ($alwaysOn) {
        Register-Check -Name "Always On VPN" -Status INFO -Message "Configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Connection Security Rules (IPsec)
try {
    $csrRules = Get-NetIPsecRule -ErrorAction SilentlyContinue
    if ($csrRules) {
        Register-Check -Name "IPsec Rules" -Status INFO -Message "$($csrRules.Count) connection security rule(s)"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

# Perfect Forward Secrecy
try {
    $pfs = Get-VpnServerIPsecConfiguration -ErrorAction SilentlyContinue
    if ($pfs -and $pfs.PfsGroup -ne 'None') {
        Register-Check -Name "Perfect Forward Secrecy" -Status PASS -Message $pfs.PfsGroup
    } else {
        Register-Check -Name "Perfect Forward Secrecy" -Status WARN -Message "Not configured"
    }
} catch { Write-Verbose 'Suppressed non-fatal error.' }

Print-Summary
Exit-Audit
