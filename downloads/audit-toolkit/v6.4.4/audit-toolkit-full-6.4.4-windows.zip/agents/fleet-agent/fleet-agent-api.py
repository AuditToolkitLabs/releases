#!/usr/bin/env python3
"""
Fleet Agent HTTPS API scaffold.

This service is intended for fleet-agent mode where the core server performs
structured, authenticated HTTPS queries against the installed target-host agent.

Scope (scaffold):
- health/status
- system information
- capabilities
- audit execution job submission and retrieval

Security model:
- bearer token auth via X-Agent-Token
- HTTPS required by policy (except localhost fallback when explicitly allowed)
- no arbitrary shell endpoint exposure
"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any

from flask import Flask, jsonify, request

app = Flask(__name__)

AGENT_ROOT = Path(os.environ.get("FLEET_AGENT_ROOT", Path(__file__).resolve().parent))
FLEET_AGENT_SCRIPT = os.environ.get("FLEET_AGENT_SCRIPT", str(AGENT_ROOT / "fleet-agent.sh"))
API_TOKEN = os.environ.get("FLEET_AGENT_API_TOKEN", "")
REQUIRE_HTTPS = os.environ.get("FLEET_AGENT_API_REQUIRE_HTTPS", "true").lower() in ("1", "true", "yes")
ALLOW_LOCAL_HTTP = os.environ.get("FLEET_AGENT_API_ALLOW_LOCAL_HTTP", "true").lower() in ("1", "true", "yes")
AUDIT_TIMEOUT_SECONDS = int(os.environ.get("FLEET_AGENT_API_AUDIT_TIMEOUT_SECONDS", "3600"))

_jobs: Dict[str, Dict[str, Any]] = {}
_jobs_lock = threading.Lock()


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _is_local_request() -> bool:
    host = request.host.split(":", 1)[0].lower()
    return host in {"127.0.0.1", "localhost", "::1"}


def _request_is_https() -> bool:
    if request.is_secure:
        return True
    proto = request.headers.get("X-Forwarded-Proto", "").lower()
    return proto == "https"


def _enforce_transport_policy() -> tuple[bool, tuple[Dict[str, Any], int] | None]:
    if not REQUIRE_HTTPS:
        return True, None
    if _request_is_https():
        return True, None
    if ALLOW_LOCAL_HTTP and _is_local_request():
        return True, None
    return False, ({
        "success": False,
        "error": "HTTPS required",
        "details": "Managed agent API rejects non-HTTPS transport by policy."
    }, 403)


def _authorize() -> tuple[bool, tuple[Dict[str, Any], int] | None]:
    if not API_TOKEN:
        return False, ({
            "success": False,
            "error": "Server misconfiguration",
            "details": "FLEET_AGENT_API_TOKEN is not configured."
        }, 500)

    supplied = request.headers.get("X-Agent-Token", "")
    if supplied != API_TOKEN:
        return False, ({"success": False, "error": "Unauthorized"}, 401)

    return True, None


def _guard_request() -> tuple[bool, tuple[Dict[str, Any], int] | None]:
    transport_ok, transport_error = _enforce_transport_policy()
    if not transport_ok:
        return False, transport_error
    return _authorize()


def _run_job(job_id: str, audit_path: str) -> None:
    with _jobs_lock:
        _jobs[job_id]["status"] = "running"
        _jobs[job_id]["started_at"] = _utc_now()

    command = [FLEET_AGENT_SCRIPT, "run", audit_path]

    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=AUDIT_TIMEOUT_SECONDS,
            cwd=str(AGENT_ROOT),
            check=False,
        )

        result = {
            "exit_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }

        with _jobs_lock:
            _jobs[job_id]["status"] = "completed" if proc.returncode == 0 else "failed"
            _jobs[job_id]["completed_at"] = _utc_now()
            _jobs[job_id]["result"] = result

    except subprocess.TimeoutExpired as exc:
        with _jobs_lock:
            _jobs[job_id]["status"] = "failed"
            _jobs[job_id]["completed_at"] = _utc_now()
            _jobs[job_id]["result"] = {
                "exit_code": 124,
                "stdout": exc.stdout or "",
                "stderr": exc.stderr or "Audit execution timed out",
            }

    except Exception as exc:  # pragma: no cover - defensive
        with _jobs_lock:
            _jobs[job_id]["status"] = "failed"
            _jobs[job_id]["completed_at"] = _utc_now()
            _jobs[job_id]["result"] = {
                "exit_code": 1,
                "stdout": "",
                "stderr": str(exc),
            }


@app.route("/api/v1/agent/health", methods=["GET"])
def health() -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    return jsonify({
        "success": True,
        "status": "ok",
        "time": _utc_now(),
        "https_required": REQUIRE_HTTPS,
    })


@app.route("/api/v1/agent/system-info", methods=["GET"])
def system_info() -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    return jsonify({
        "success": True,
        "system": {
            "hostname": platform.node(),
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
        },
    })


@app.route("/api/v1/agent/capabilities", methods=["GET"])
def capabilities() -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    return jsonify({
        "success": True,
        "capabilities": [
            "health",
            "system-info",
            "audit-run",
            "audit-job-status",
            "audit-job-result",
        ],
    })


@app.route("/api/v1/agent/audits/run", methods=["POST"])
def run_audit() -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    data = request.get_json(silent=True) or {}
    audit_path = str(data.get("audit_path", "")).strip()
    if not audit_path:
        return jsonify({"success": False, "error": "audit_path is required"}), 400

    job_id = str(uuid.uuid4())
    with _jobs_lock:
        _jobs[job_id] = {
            "job_id": job_id,
            "audit_path": audit_path,
            "status": "queued",
            "queued_at": _utc_now(),
            "started_at": None,
            "completed_at": None,
            "result": None,
        }

    thread = threading.Thread(target=_run_job, args=(job_id, audit_path), daemon=True)
    thread.start()

    return jsonify({"success": True, "job_id": job_id, "status": "queued"}), 202


@app.route("/api/v1/agent/audits/jobs/<job_id>", methods=["GET"])
def get_job(job_id: str) -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    with _jobs_lock:
        job = _jobs.get(job_id)

    if not job:
        return jsonify({"success": False, "error": "Job not found"}), 404

    return jsonify({
        "success": True,
        "job": {
            "job_id": job["job_id"],
            "audit_path": job["audit_path"],
            "status": job["status"],
            "queued_at": job["queued_at"],
            "started_at": job["started_at"],
            "completed_at": job["completed_at"],
        },
    })


@app.route("/api/v1/agent/audits/jobs/<job_id>/result", methods=["GET"])
def get_job_result(job_id: str) -> Any:
    ok, err = _guard_request()
    if not ok:
        payload, code = err
        return jsonify(payload), code

    with _jobs_lock:
        job = _jobs.get(job_id)

    if not job:
        return jsonify({"success": False, "error": "Job not found"}), 404

    if job["status"] in {"queued", "running"}:
        return jsonify({"success": False, "error": "Job is not finished", "status": job["status"]}), 409

    return jsonify({"success": True, "job_id": job_id, "status": job["status"], "result": job["result"]})


if __name__ == "__main__":
    host = os.environ.get("FLEET_AGENT_API_HOST", "127.0.0.1")
    port = int(os.environ.get("FLEET_AGENT_API_PORT", "8443"))

    cert_file = os.environ.get("FLEET_AGENT_API_CERT")
    key_file = os.environ.get("FLEET_AGENT_API_KEY")

    ssl_context = None
    if cert_file and key_file:
        ssl_context = (cert_file, key_file)

    app.run(host=host, port=port, ssl_context=ssl_context)
