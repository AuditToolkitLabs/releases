#!/usr/bin/env bash
# =============================================================================
# Managed Security Audit Agent - Linux Installation Script
# =============================================================================
# Installs the fleet agent with proper privilege escalation:
# - Creates dedicated service user (audit-agent)
# - Configures passwordless sudo for audit scripts ONLY
# - Sets up systemd service for daemon mode
# - Configures secure API key storage
#
# Run as: sudo ./install-linux.sh [OPTIONS]
#
# Author: Security Audit Toolkit Team
# Date: February 18, 2026
# Version: 6.2.1
# =============================================================================

set -euo pipefail

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION_FILE="${SCRIPT_DIR}/VERSION"
if [[ -f "$VERSION_FILE" ]]; then
    AGENT_VERSION="$(tr -d '\r\n' < "$VERSION_FILE")"
else
    AGENT_VERSION="${AUDIT_AGENT_VERSION:-6.2.1}"
fi
INSTALL_DIR="${AUDIT_INSTALL_DIR:-/opt/audit-agent}"
SERVICE_USER="${AUDIT_SERVICE_USER:-audit-agent}"
SERVICE_GROUP="${AUDIT_SERVICE_GROUP:-audit-agent}"
SERVICE_NAME="audit-fleet-agent"
LOG_DIR="/var/log/audit-agent"
CONFIG_DIR="/etc/audit-agent"
SUDOERS_FILE="/etc/sudoers.d/audit-agent-${SERVICE_USER}"
USE_SUDO_DEFAULT="true"

# Server configuration (can be passed as arguments)
SERVER_URL="${AUDIT_SERVER_URL:-}"
API_KEY="${AUDIT_API_KEY:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# =============================================================================
# Helper Functions
# =============================================================================
log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

detect_init_system() {
    if command -v systemctl &>/dev/null && systemctl --version &>/dev/null 2>&1; then
        echo "systemd"
    elif command -v rc-service &>/dev/null; then
        echo "openrc"
    elif [[ -f /etc/init.d/functions ]]; then
        echo "sysvinit"
    else
        echo "unknown"
    fi
}

# =============================================================================
# Installation Steps
# =============================================================================

create_service_user() {
    log_info "Creating service user: $SERVICE_USER"

    # Create group if not exists
    if ! getent group "$SERVICE_GROUP" &>/dev/null; then
        groupadd --system "$SERVICE_GROUP"
    fi

    # Create user if not exists
    if ! getent passwd "$SERVICE_USER" &>/dev/null; then
        useradd --system \
            --gid "$SERVICE_GROUP" \
            --home-dir "$INSTALL_DIR" \
            --shell /usr/sbin/nologin \
            --comment "Audit Agent Service Account" \
            "$SERVICE_USER"
    fi

    log_info "Service user created: $SERVICE_USER"
}

create_directories() {
    log_info "Creating directories..."

    mkdir -p "$INSTALL_DIR"/{audits,lib,results,.cache}
    mkdir -p "$LOG_DIR"
    mkdir -p "$CONFIG_DIR"

    # Set ownership
    chown -R "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR"
    chown -R "$SERVICE_USER:$SERVICE_GROUP" "$LOG_DIR"
    chmod 750 "$INSTALL_DIR" "$LOG_DIR"
    chmod 700 "$INSTALL_DIR/.cache"

    log_info "Directories created at $INSTALL_DIR"
}

install_agent_files() {
    log_info "Installing agent files..."

    # Copy main agent script
    if [[ -f "${SCRIPT_DIR}/fleet-agent.sh" ]]; then
        cp "${SCRIPT_DIR}/fleet-agent.sh" "$INSTALL_DIR/"
        chmod 750 "$INSTALL_DIR/fleet-agent.sh"
    else
        log_error "fleet-agent.sh not found in $SCRIPT_DIR"
        exit 1
    fi

    # Copy lib files if available
    if [[ -d "${SCRIPT_DIR}/lib" ]]; then
        cp -r "${SCRIPT_DIR}/lib/"*.sh "$INSTALL_DIR/lib/" 2>/dev/null || true
    fi

    # Copy scoped sudoers helper if available
    if [[ -f "${SCRIPT_DIR}/setup-sudoers.sh" ]]; then
        cp "${SCRIPT_DIR}/setup-sudoers.sh" "$INSTALL_DIR/setup-sudoers.sh"
        chmod 750 "$INSTALL_DIR/setup-sudoers.sh"
    fi

    # Copy bundled audit scripts — required for sudoers grant to be effective
    if [[ -d "${SCRIPT_DIR}/audits" ]]; then
        cp -r "${SCRIPT_DIR}/audits/." "$INSTALL_DIR/audits/"
        find "$INSTALL_DIR/audits" -name '*.sh' -exec chmod 750 {} +
        log_info "Audit scripts installed to $INSTALL_DIR/audits"
    else
        log_warn "audits/ not found in $SCRIPT_DIR — sudoers grant will be inert until audits are deployed"
    fi

    chown -R "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR"

    log_info "Agent files installed"
}

configure_sudoers() {
    log_info "Configuring passwordless sudo for audit scripts..."

    SUDOERS_FILE="/etc/sudoers.d/audit-agent-${SERVICE_USER}"

    # Prefer the shared least-privilege helper when available.
    local setup_helper="${SCRIPT_DIR}/setup-sudoers.sh"
    if [[ -f "$setup_helper" ]]; then
        if bash "$setup_helper" --agent-user "$SERVICE_USER" --install-dir "$INSTALL_DIR" --yes; then
            log_info "Sudoers configured via helper: $SUDOERS_FILE"
            return
        fi
        log_warn "setup-sudoers.sh failed, falling back to inline sudoers template"
    fi

    # Create sudoers file with strict permissions
    cat > "$SUDOERS_FILE" << EOF
# =============================================================================
# Audit Agent Sudoers Configuration
# =============================================================================
# Allows the service user to run scoped audit/discovery scripts only.
# This intentionally does not grant root shell or broad command access.
#
# WARNING: Do not modify this file directly. It was generated by the
# audit agent installer.
# =============================================================================

$SERVICE_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*/*/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*/*/*.sh
$SERVICE_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/fleet-agent.sh discovery
$SERVICE_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/fleet-agent.sh discovery
$SERVICE_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/fleet-agent.sh --discovery
$SERVICE_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/fleet-agent.sh --discovery

# Explicitly deny broad shell escalation paths.
$SERVICE_USER ALL=(root) NOPASSWD: !/bin/sh
$SERVICE_USER ALL=(root) NOPASSWD: !/usr/bin/su
$SERVICE_USER ALL=(root) NOPASSWD: !/usr/bin/sudoedit

# Prevent privilege escalation attempts
Defaults:$SERVICE_USER !requiretty
Defaults:$SERVICE_USER env_reset
Defaults:$SERVICE_USER secure_path="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
EOF

    # Set strict permissions on sudoers file
    chmod 440 "$SUDOERS_FILE"
    chown root:root "$SUDOERS_FILE"

    # Validate sudoers file
    if ! visudo -c -f "$SUDOERS_FILE" &>/dev/null; then
        log_error "Invalid sudoers configuration!"
        rm -f "$SUDOERS_FILE"
        exit 1
    fi

    log_info "Sudoers configured: $SUDOERS_FILE"
}

create_config_file() {
    log_info "Creating configuration file..."

    local config_file="$CONFIG_DIR/agent.config.json"

    # Prompt for server URL if not provided
    if [[ -z "$SERVER_URL" ]]; then
        read -rp "Enter Audit Server URL (e.g., https://audit.example.com:5000): " SERVER_URL
    fi

    # Prompt for API key if not provided
    if [[ -z "$API_KEY" ]]; then
        read -rsp "Enter API Key: " API_KEY
        echo
    fi

    # Generate agent ID from machine-id
    local agent_id
    if [[ -f /etc/machine-id ]]; then
        agent_id=$(cat /etc/machine-id | sha256sum | cut -c1-16)
    else
        agent_id=$(hostname | sha256sum | cut -c1-16)
    fi

    cat > "$config_file" << EOF
{
    "server_url": "$SERVER_URL",
    "agent_id": "$agent_id",
    "config_version": 0,
    "poll_interval": 60,
    "discovery_interval": 3600,
    "use_sudo": ${USE_SUDO_DEFAULT},
    "auto_discovery": true,
    "auto_sync": true,
    "created_at": "$(date -Iseconds)"
}
EOF

    chmod 640 "$config_file"
    chown "$SERVICE_USER:$SERVICE_GROUP" "$config_file"

    # Store API key securely (encrypted with machine key)
    local cred_file="$INSTALL_DIR/.credentials.enc"
    if command -v openssl &>/dev/null; then
        local machine_key
        machine_key=$(cat /etc/machine-id 2>/dev/null || hostname)$(hostname)audit-agent-key
        machine_key=$(echo -n "$machine_key" | sha256sum | cut -d' ' -f1)

        echo -n "$API_KEY" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
            -pass "pass:${machine_key}" -base64 > "$cred_file"
        chmod 600 "$cred_file"
        chown "$SERVICE_USER:$SERVICE_GROUP" "$cred_file"
    else
        log_warn "OpenSSL not available - storing API key in config file (less secure)"
        # Update config with API key
        jq --arg key "$API_KEY" '. + {api_key: $key}' "$config_file" > "$config_file.tmp"
        mv "$config_file.tmp" "$config_file"
    fi

    # Create symlink for agent to find config
    ln -sf "$config_file" "$INSTALL_DIR/agent.config.json"

    log_info "Configuration created"
}

install_systemd_service() {
    log_info "Installing systemd service..."

    cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=Managed Security Audit Agent
Documentation=https://github.com/security-audit-toolkit
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_GROUP
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/fleet-agent.sh daemon
Restart=always
RestartSec=30

# Security hardening
NoNewPrivileges=false
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$INSTALL_DIR $LOG_DIR
PrivateTmp=true
ProtectKernelTunables=true
ProtectControlGroups=true

# Environment
Environment="AUDIT_USE_SUDO=${USE_SUDO_DEFAULT}"
Environment="AUDIT_LOG_DIR=$LOG_DIR"
Environment="AUDIT_CONFIG_DIR=$CONFIG_DIR"

# Logging
StandardOutput=append:$LOG_DIR/agent.log
StandardError=append:$LOG_DIR/agent-error.log

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable "$SERVICE_NAME"

    log_info "Systemd service installed: $SERVICE_NAME"
}

install_openrc_service() {
    log_info "Installing OpenRC service..."

    cat > "/etc/init.d/${SERVICE_NAME}" << EOF
#!/sbin/openrc-run

name="audit-fleet-agent"
description="Managed Security Audit Agent"
command="$INSTALL_DIR/fleet-agent.sh"
command_args="daemon"
command_user="$SERVICE_USER:$SERVICE_GROUP"
command_background="yes"
pidfile="/run/\${RC_SVCNAME}.pid"
start_stop_daemon_args="--make-pidfile"
output_log="$LOG_DIR/agent.log"
error_log="$LOG_DIR/agent-error.log"

depend() {
    need net
    after firewall
}
EOF

    chmod 755 "/etc/init.d/${SERVICE_NAME}"
    rc-update add "$SERVICE_NAME" default 2>/dev/null || true

    log_info "OpenRC service installed: $SERVICE_NAME"
}

# =============================================================================
# Main Installation
# =============================================================================

show_usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Install the Managed Security Audit Agent with proper privilege escalation.

OPTIONS:
    -s, --server URL     Audit server URL (e.g., https://audit.example.com:5000)
    -k, --api-key KEY    API key for authentication
    -d, --install-dir    Installation directory (default: /opt/audit-agent)
    -u, --user NAME      Service user name (default: audit-agent)
    --no-sudoers        Skip sudoers configuration (run as root instead)
    --no-service        Skip service installation
    -h, --help          Show this help message

EXAMPLES:
    # Interactive installation
    sudo ./install-linux.sh

    # Automated installation
    sudo ./install-linux.sh -s https://audit.example.com:5000 -k your-api-key

    # Custom installation directory
    sudo ./install-linux.sh -d /usr/local/audit-agent

EOF
}

main() {
    local skip_sudoers=false
    local skip_service=false

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -s|--server)
                SERVER_URL="$2"
                shift 2
                ;;
            -k|--api-key)
                API_KEY="$2"
                shift 2
                ;;
            -d|--install-dir)
                INSTALL_DIR="$2"
                shift 2
                ;;
            -u|--user)
                SERVICE_USER="$2"
                SERVICE_GROUP="$2"
                shift 2
                ;;
            --no-sudoers)
                skip_sudoers=true
                shift
                ;;
            --no-service)
                skip_service=true
                shift
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done

    echo ""
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║     Managed Security Audit Agent - Linux Installer v${AGENT_VERSION}       ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo ""

    check_root

    log_info "Starting installation..."
    log_info "Install directory: $INSTALL_DIR"
    log_info "Service user: $SERVICE_USER"

    # Detect init system
    local init_system
    init_system=$(detect_init_system)
    log_info "Init system: $init_system"

    # Run installation steps
    create_service_user
    create_directories
    install_agent_files

    if [[ "$skip_sudoers" != "true" ]]; then
        configure_sudoers
        USE_SUDO_DEFAULT="true"
    else
        log_warn "Skipping sudoers configuration - agent will need to run as root"
        USE_SUDO_DEFAULT="false"
    fi

    create_config_file

    if [[ "$skip_service" != "true" ]]; then
        case "$init_system" in
            systemd)
                install_systemd_service
                ;;
            openrc)
                install_openrc_service
                ;;
            *)
                log_warn "Unknown init system - skipping service installation"
                log_warn "Start agent manually: $INSTALL_DIR/fleet-agent.sh daemon"
                ;;
        esac
    fi

    echo ""
    log_info "Installation complete!"
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo " Next Steps:"
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    echo " 1. Start the agent service:"
    if [[ "$init_system" == "systemd" ]]; then
        echo "    sudo systemctl start $SERVICE_NAME"
        echo ""
        echo " 2. Check status:"
        echo "    sudo systemctl status $SERVICE_NAME"
    elif [[ "$init_system" == "openrc" ]]; then
        echo "    sudo rc-service $SERVICE_NAME start"
        echo ""
        echo " 2. Check status:"
        echo "    sudo rc-service $SERVICE_NAME status"
    else
        echo "    $INSTALL_DIR/fleet-agent.sh daemon &"
    fi
    echo ""
    echo " 3. View logs:"
    echo "    tail -f $LOG_DIR/agent.log"
    echo ""
    local agent_id_display
    agent_id_display="$(grep -oE '"agent_id"[[:space:]]*:[[:space:]]*"[^"]+"' "$CONFIG_DIR/agent.config.json" | sed -E 's/.*"([^"]+)"/\1/' | head -n 1 || true)"
    echo " 4. Agent ID: ${agent_id_display:-unknown}"
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
}

main "$@"
