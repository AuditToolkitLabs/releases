#!/usr/bin/env python3
"""Fleet isolation guard.

Detects direct references to Fleet runtime files from paths outside allowed
integration surfaces.
"""

from __future__ import annotations

import os
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[3]

ALLOWED_PREFIXES = (
    ".github/",
    ".vscode/",
    "agents/fleet-agent/",
    "agents/html-standalone/",
    "deployment/agents/_build/",
    "deployment/windows/",
    "docs/",
    "internal-docs/",
    "plans/",
    "preview-site/",
    "site/preview-site/",
    "scripts/",
    "tests/",
    "tools/",
    "web/api/",
    "web/tests/",
)

WATCHED_PATTERNS = (
    "agents/fleet-agent/",
    "fleet-agent.sh",
    "fleet-agent.ps1",
    "fleet-agent-api.py",
)

SCANNED_SUFFIXES = {".py", ".md", ".sh", ".ps1", ".yml", ".yaml", ".wxs", ".json"}
SKIP_DIR_NAMES = {
    ".git",
    "__pycache__",
    ".venv",
    "node_modules",
    "archive",
    "dist",
    "artifacts",
    "deployment/linux/build",
    "deployment/windows/web-harvest-stage",
    "deployment/windows/asset-discovery-harvest-stage",
    "unified-jre-agent-build-5.6.2",
    "unified-jre-agent-build-6.2.1",
}


def is_allowed_path(rel_path: str) -> bool:
    rel_norm = rel_path.replace("\\", "/")
    return rel_norm.startswith(ALLOWED_PREFIXES)


def main() -> int:
    violations: list[tuple[str, str]] = []

    for root, dirs, files in os.walk(REPO_ROOT, topdown=True, onerror=lambda _err: None):
        root_path = Path(root)
        root_rel = root_path.relative_to(REPO_ROOT).as_posix() if root_path != REPO_ROOT else ""

        dirs[:] = [
            name
            for name in dirs
            if not any(
                part == name or (root_rel and f"{root_rel}/{name}" == part)
                for part in SKIP_DIR_NAMES
            )
        ]

        for file_name in files:
            path = root_path / file_name
            rel = path.relative_to(REPO_ROOT).as_posix()

            if any(rel == skip or rel.startswith(f"{skip}/") for skip in SKIP_DIR_NAMES):
                continue

            if path.suffix.lower() not in SCANNED_SUFFIXES:
                continue

            if is_allowed_path(rel):
                continue

            try:
                if path.stat().st_size > 1_000_000:
                    continue
                content = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue

            for pattern in WATCHED_PATTERNS:
                if pattern in content:
                    violations.append((rel, pattern))

    if violations:
        print("FAIL: fleet runtime reference leakage detected:")
        for rel, pattern in violations:
            print(f"  - {rel}: {pattern}")
        return 1

    print("PASS: no fleet runtime reference leakage detected.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
