# Standalone Isolation Manifest

This file defines the isolation boundary for the standalone agent while it
remains in the main repository.

## Goal

Keep standalone logic self-contained so moving to a separate repository later is
mostly a packaging operation, not a code rewrite.

## Current Boundary

Standalone implementation roots:
- agents/html-standalone/
- agents/html_standalone/ (compatibility import path)

Main tool integration points (must remain stable):
- deployment scripts that package agents/html-standalone/
- web/api pathing helpers that locate agents/html-standalone/
- documentation references

## Guardrails

1. Do not move files out of agents/html-standalone/ when extracting shared code.
2. Add compatibility shims under agents/html_standalone/ for any new standalone
   modules that may be imported by underscore path.
3. Keep standalone policy and path resolution inside standalone modules.
4. Validate no leakage with:

```powershell
python agents/html-standalone/tools/check-isolation.py
```

## Extraction Readiness Checklist

1. Keep audits referenced through policy-based path resolution.
2. Keep runtime imports local to standalone package/module roots.
3. Preserve compatibility shims during transition.
4. Verify packaging scripts still collect standalone assets.
5. Run standalone API smoke check after any move.
