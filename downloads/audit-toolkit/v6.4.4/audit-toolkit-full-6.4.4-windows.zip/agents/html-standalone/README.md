# Lightweight Security Audit Agent

> **Deprecated for new deployments:** Use the JRE agent in standalone mode via `/api/deploy/jre-agent`.
> This lightweight path remains for backward compatibility of existing installs.

A minimal, standalone agent for discovering installed software, suggesting relevant security audits, and running them on demand.

**Available for both Linux (Bash) and Windows (PowerShell).**

## Isolation Guardrails

The standalone agent remains in this repository for now, but is maintained with
split-ready boundaries.

- Boundary and extraction checklist: `agents/html-standalone/ISOLATION-MANIFEST.md`
- Isolation leakage check:

```powershell
python agents/html-standalone/tools/check-isolation.py
```

## Overview

The Standalone Agent is designed for scenarios where you can't or don't want to use WinRM/SSH:

- **Security restrictions** prevent enabling remote management protocols
- **Desktop workstations** without WinRM enabled (default on Windows Desktop)
- **Air-gapped environments** where you want local scanning with upload capability
- **Minimal footprint** - no services, no daemons, runs on-demand

## Platform Support

### CLI Agents (Interactive Command-Line)

| Platform | Agent | Requirements | Status |
|----------|-------|--------------|--------|
| Linux (all distros) | `agent.sh` | Bash 4+, coreutils | ✅ Full support |
| Windows Server | `agent.ps1` | PowerShell 5.1+ | ✅ Full support |
| Windows Desktop | `agent.ps1` | PowerShell 5.1+ | ✅ Full support |

### Web Interface (Browser-Based Management)

| Platform | Support | Notes |
|----------|---------|-------|
| Linux | ✅ Full | Docker/systemd deployment, cron scheduling |
| Windows | ✅ Full | Native or Docker Desktop, Task Scheduler |
| macOS | ✅ Full | Native Python, launchd scheduling |

**NEW: The web interface is now fully cross-platform!** It automatically detects your OS and uses:
- **Windows**: PowerShell scripts, Task Scheduler, WMI system info
- **Linux**: Bash scripts, cron jobs, /proc system info
- **macOS**: Bash/zsh scripts, launchd, sysctl system info

## Features

| Feature | Description |
|---------|-------------|
| Software Discovery | Detects web servers, databases, containers, security tools, languages |
| Smart Suggestions | Recommends audits based on what's installed |
| Individual Execution | Run specific audits one at a time |
| Group Execution | Run all audits for a category (platform, web, data, etc.) |
| Local Reporting | Save results to local JSON files |
| Remote Reporting | Send results to central server via API |
| Interactive Mode | Menu-driven interface for easy use |
| CLI Mode | Run specific operations non-interactively |

## Detected Software

### Linux Agent (`agent.sh`)

| Category | Software |
|----------|----------|
| **Package Managers** | apt, dnf/yum, apk |
| **Web Servers** | nginx, apache/httpd |
| **Databases** | MySQL/MariaDB, PostgreSQL, MongoDB, Redis |
| **Containers** | Docker, Podman, Kubernetes |
| **Security Tools** | fail2ban, ufw, firewalld |
| **Services** | SSH, systemd, OpenRC |
| **Languages** | PHP, Node.js, Python |

### Windows Agent (`agent.ps1`)

| Category | Software |
|----------|----------|
| **Windows Roles** | IIS, Hyper-V, AD DS, DNS, DHCP, File Server |
| **Security** | Windows Defender, BitLocker, Windows Firewall |
| **Databases** | SQL Server, MySQL, PostgreSQL, MongoDB |
| **Containers** | Docker, Windows Containers |
| **Services** | OpenSSH, RDP, WSUS |
| **Runtimes** | PowerShell, .NET Framework |

## Installation

### Via Deploy Panel (Legacy)

1. Go to the **Deploy** tab in the web interface
2. Prefer **"JRE Agent (Standalone)"** for new deployments
3. Select target servers
4. Click **"Deploy to Selected"**

### Manual Installation - Linux

```bash
# Copy the html-standalone folder to target server
scp -r agents/html-standalone/ user@server:/opt/

# Make executable
chmod +x /opt/html-standalone/agent.sh
```

### Manual Installation - Windows

```powershell
# Copy agent to target (via USB, network share, etc.)
Copy-Item -Path "agents\html-standalone" -Destination "C:\audit-agent" -Recurse

# Run (no installation required)
cd C:\audit-agent
.\agent.ps1
```

### Docker Deployment

The standalone agent includes a web interface for browser-based management. **Fully cross-platform** - runs on both Linux and Windows hosts.

**Linux Docker:**
```bash
# Basic deployment
docker run -d -p 8088:5000 --name audit-agent audit-lightweight:latest

# With environment variables for headless configuration
docker run -d -p 8088:5000 \
  -e CORE_SERVER_URL=https://audit-server:5000 \
  -e API_KEY=your-secret-key \
  -e AGENT_ID=server-prod-01 \
  -e AUTO_EXPORT=true \
  --name audit-agent audit-lightweight:latest

# Access web interface from any browser
# http://server-ip:8088
```

**Windows (Native or Docker Desktop with Windows Containers):**
```powershell
# Run directly on Windows (no Docker needed)
cd C:\audit-agent\web
python app.py

# Or using Docker Desktop with Windows containers
docker run -d -p 8088:5000 --name audit-agent audit-lightweight:latest

# Access via browser at http://localhost:8088
```

**Cross-Platform Features:**
- ✅ **OS Detection**: Automatically detects Windows, Linux, macOS
- ✅ **Scheduling**: Uses Task Scheduler (Windows) or cron (Linux/macOS)
- ✅ **Audit Execution**: PowerShell scripts on Windows, Bash scripts on Linux
- ✅ **System Info**: Platform-specific uptime, container detection, OS details

#### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `CORE_SERVER_URL` | URL of main audit server | (empty) |
| `API_KEY` | Authentication key | (empty) |
| `AGENT_ID` | Unique identifier for this agent | auto-generated |
| `AUTO_EXPORT` | Auto-export results to server | `false` |
| `EXPORT_ON_COMPLETE` | Export when audit completes | `true` |

### Headless CLI Setup

For servers without any GUI access, use the CLI setup script:

```bash
# Inside running container
docker exec -it audit-agent python3 /app/setup-cli.py

# Non-interactive setup
docker exec audit-agent python3 /app/setup-cli.py \
  --server https://audit-server:5000 \
  --api-key secret123 \
  --agent-id prod-server-01

# Configure from environment variables
docker exec audit-agent python3 /app/setup-cli.py --from-env

# Show current configuration
docker exec audit-agent python3 /app/setup-cli.py --show

# Test connection to core server
docker exec audit-agent python3 /app/setup-cli.py --test
```

### SSH Session Handling (Important!)

When running on remote Linux servers via SSH, you need to handle session persistence:

**Problem:** If your SSH session disconnects, the web server process dies.

**Solutions:**

#### Option 1: Daemon Mode (Recommended)
```bash
# Start as background daemon (survives SSH disconnect)
./start-web.sh --daemon

# Check status
./start-web.sh --status

# Stop daemon
./start-web.sh --stop

# Restart daemon
./start-web.sh --restart

# View logs
tail -f logs/agent.log
```

#### Option 2: Systemd Service (Production)
```bash
# Copy service file
sudo cp audit-agent.service /etc/systemd/system/

# Edit configuration
sudo nano /etc/systemd/system/audit-agent.service

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable audit-agent
sudo systemctl start audit-agent

# Check status
sudo systemctl status audit-agent
```

#### Option 3: Screen/Tmux
```bash
# Using screen
screen -S audit-agent
./start-web.sh
# Detach: Ctrl+A, D
# Reattach later: screen -r audit-agent

# Using tmux
tmux new -s audit-agent
./start-web.sh
# Detach: Ctrl+B, D
# Reattach later: tmux attach -t audit-agent
```

#### Option 4: OpenRC (Alpine Linux)
```bash
# Copy init script
sudo cp audit-agent.openrc /etc/init.d/audit-agent
sudo chmod +x /etc/init.d/audit-agent

# Add to default runlevel
sudo rc-update add audit-agent default

# Start service
sudo rc-service audit-agent start
```

---

## Fleet Agent (Enterprise)

The **Fleet Agent** (`fleet-agent.sh` / `fleet-agent.ps1`) provides:
- Two-way API communication with central server
- Remote configuration and audit synchronization
- Support for non-root operation with secure privilege escalation
- JEA (Windows) and sudoers (Linux) integration

### Installation Modes

| Mode | Root/Admin Required | Privileges | Use Case |
|------|---------------------|------------|----------|
| **User** | No | Limited | Workstations, quick deployment |
| **Service** | Yes | Full | Servers, persistent monitoring |
| **Full + JEA** | Yes (setup) | Elevated via JEA | AD/Entra environments |

### Linux Installation Options

#### Option A: User Mode (No Root Required)

```bash
# Install as current user
./install-user.sh

# Agent installs to ~/.audit-agent
# Creates systemd user service
```

**What gets installed:**
- Agent files in `~/.audit-agent/`
- Systemd user service (auto-start on login)
- `setup-sudoers.sh` script for optional admin setup

#### Option B: Enable Full Audits (Admin Task)

After user-mode install, an admin can optionally enable privileged audits:

```bash
# Admin runs the generated script
sudo ~/.audit-agent/setup-sudoers.sh

# Or manually configure
sudo visudo -f /etc/sudoers.d/audit-agent
```

This grants passwordless sudo for specific audit commands only.

### Windows Installation Options

#### Option A: User Mode (No Admin Required)

```powershell
.\install-windows.ps1 -Mode User
```

**What gets installed:**
- Agent files in `%LOCALAPPDATA%\AuditAgent`
- Scheduled task running as current user
- Limited audit capabilities (no admin access)

#### Option B: Service Mode (Admin Required)

```powershell
.\install-windows.ps1 -Mode Service
```

**What gets installed:**
- Agent files in `C:\ProgramData\AuditAgent`
- Scheduled task running as SYSTEM
- Full audit capabilities

#### Option C: Full + JEA (Enterprise/AD)

```powershell
.\install-windows.ps1 -Mode Full -SetupJea `
  -JeaAdminGroup "YOURDOMAIN\SecurityTeam" `
  -JeaReadOnlyGroup "YOURDOMAIN\HelpDesk"
```

**What gets installed:**
- Agent files in `C:\ProgramData\AuditAgent`
- JEA endpoint (`AuditAgent.JEA`)
- Users in specified AD groups can run elevated audits
- Full audit capabilities via constrained endpoint

### JEA (Just Enough Administration)

JEA allows non-admin users to run elevated audit commands through a constrained
PowerShell endpoint. No admin credentials are exposed.

```powershell
# Setup JEA endpoint (run as admin)
cd agents\html-standalone\jea
.\setup-jea.ps1 -AdminGroup "IT-Security" -ReadOnlyGroup "HelpDesk"

# Test connection (as non-admin user)
Enter-PSSession -ComputerName localhost -ConfigurationName AuditAgent.JEA
Get-Service  # Works
Stop-Service # Blocked
```

**JEA Security Features:**
- Constrained Language Mode
- Transcript logging for compliance
- Role-based access (Full vs Read-Only)
- Virtual accounts (no exposed credentials)

### Linux Sudoers Configuration

The agent detects available sudo access and adjusts capabilities:

| Sudo Mode | Detected When | Capabilities |
|-----------|---------------|--------------|
| `root` | Running as UID 0 | Full |
| `sudo_nopasswd` | `sudo -n` works | Full |
| `sudo_password` | sudo available, needs password | Limited |
| `none` | No sudo access | Basic only |

**Recommended sudoers configuration:**

```sudoers
# /etc/sudoers.d/audit-agent
audituser ALL=(ALL) NOPASSWD: \
  /usr/bin/ss, \
  /bin/netstat, \
  /usr/bin/last, \
  /usr/bin/lastlog, \
  /usr/sbin/iptables -L -n, \
  /usr/bin/systemctl status *, \
  /usr/bin/journalctl *
```

### Testing Installation

See [TESTING-GUIDE.md](TESTING-GUIDE.md) for comprehensive test procedures.

Quick validation:

```bash
# Linux: Check capabilities
./fleet-agent.sh -m discovery | grep -A10 '"elevation"'

# Windows: Check elevation status
.\fleet-agent.ps1 -Mode discovery | Select-String "elevation"
```

---

## Usage

### Linux Agent - Interactive Mode

```bash
./agent.sh
```

This opens a menu-driven interface:

```
=== Lightweight Security Audit Agent v1.0.0 ===

OS: Ubuntu 22.04.3 LTS
Detected software: 8 components
Suggested audits: 12 checks

Options:
  1) Show detected software
  2) Show suggested audits
  3) Run a specific audit
  4) Run all platform audits
  5) Run all suggested audits
  6) View local results
  7) Rescan software
  8) Configure server reporting
  q) Quit
```

### Windows Agent - Interactive Mode

```powershell
.\agent.ps1
```

```
╔════════════════════════════════════════════════════════════════╗
║     Lightweight Security Audit Agent for Windows v1.0.0        ║
╚════════════════════════════════════════════════════════════════╝

  Computer: WORKSTATION-01
  OS:       Windows 11 Pro
  Type:     Desktop
  Software: 12 components
  Audits:   15 suggested

───────────────────────────────────────────────────────────────────

  1) Show detected software
  2) Show suggested audits
  3) Run a specific audit
  ...
```

### CLI Mode - Linux

```bash
# Scan and show detected software
./agent.sh --scan

# List suggested audits
./agent.sh --suggest

# Run a specific audit
./agent.sh --run platform/baseline/ssh

# Run all audits in a group
./agent.sh --group platform

# Run all suggested audits
./agent.sh --all

# Send results to server
./agent.sh --report-to https://audit-server.example.com
```

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SERVER_URL` | (empty) | Central server URL for reporting |
| `REPORT_LOCAL` | `true` | Save results to local files |
| `REPORT_REMOTE` | `false` | Send results to central server |
| `RESULTS_DIR` | `./results` | Directory for local results |

### Example Configuration

```bash
export SERVER_URL="https://audit-server.example.com"
export REPORT_REMOTE="true"
./agent.sh --all
```

## Results

Results are stored in the `results/` directory:

```
results/
├── platform_baseline_ssh_20260213_143022.log
├── platform_baseline_updates_20260213_143025.log
├── web_nginx_nginx-security_20260213_143030.log
└── ...
```

## Remote Reporting

When `REPORT_REMOTE=true` and `SERVER_URL` is set, the agent sends results to:

```
POST ${SERVER_URL}/api/agent/results
Content-Type: application/json

{
  "hostname": "web-server-01",
  "os": "Ubuntu 22.04.3 LTS",
  "results": "<base64-encoded results>"
}
```

## Comparison: Full Toolkit vs Standalone Agent

| Feature | Full Toolkit | Standalone Agent |
|---------|--------------|-------------------|
| Size | ~5 MB | ~500 KB |
| Orchestrator | ✅ Yes | ❌ No |
| All audit scripts | ✅ Yes | ✅ Yes (with sync) |
| Documentation | ✅ Yes | ❌ No |
| CI scripts | ✅ Yes | ❌ No |
| Software discovery | ❌ No | ✅ Yes |
| Audit suggestions | ❌ No | ✅ Yes |
| Interactive menu | ❌ No | ✅ Yes |
| Remote reporting | Via web | Built-in |

## Syncing Full Audit Suite

The agent includes basic audits (OS version, updates, defender, firewall), but you can sync the **full audit suite** (~147 Windows, ~138 Linux scripts) from the main repository:

### Windows - Sync Audits

```powershell
# From the audit-tool repository
.\agents\html-standalone\tools\Sync-Audits.ps1

# Or specify repository path
.\agents\html-standalone\tools\Sync-Audits.ps1 -SourcePath "C:\path\to\Audit-Tool"
```

This copies:
- `audits/windows/common/*.ps1` → `agent/audits/windows/common/`
- `audits/windows/server/*.ps1` → `agent/audits/windows/server/`
- `audits/windows/desktop/*.ps1` → `agent/audits/windows/desktop/`
- `common-audit.psm1` → `agent/audits/_lib/`

### Linux - Sync Audits

```bash
# From the audit-tool repository
./agents/html-standalone/tools/sync-audits.sh

# Or specify repository path
./agents/html-standalone/tools/sync-audits.sh /path/to/Audit-Tool
```

This copies:
- `audits/linux/platform/**/*.sh` → `agent/audits/linux/platform/`
- `audits/linux/network/*.sh` → `agent/audits/linux/network/`
- `lib/*.sh` → `agent/audits/_lib/`

### Available Audits After Sync

**Windows (75+ audits):**
- Account lockout, audit policy, BitLocker, credential guard
- Defender, EDR, firewall, GPO analysis
- LAPS, LSASS protection, NTLM restrictions
- Password policy, RDP, SMB security, TLS versions
- UAC, USB restrictions, WinRM, and more

**Linux (50+ audits):**
- SSH hardening, SELinux/AppArmor
- File permissions, SUID/SGID binaries
- Network services, firewall rules
- Package updates, kernel parameters
- Service hardening, user accounts

**Use Standalone Agent when:**
- You only need to scan specific servers
- You want automatic audit suggestions
- You don't need the orchestrator
- You want minimal footprint

**Use Full Toolkit when:**
- You need batch execution across many servers
- You want the orchestrator for complex workflows
- You need all documentation included
- You're setting up a permanent audit infrastructure

## Requirements

- Bash 4.0+
- Standard Unix utilities (grep, sed, awk)
- curl (for remote reporting)

## Uninstallation

Remove the agent directory:

```bash
rm -rf /opt/html-standalone
```

Or use the Deploy panel's **"Full Cleanup"** option to remove all artifacts.

## Related Documentation

- [Deploy Panel Guide](../docs/16-deploy-panel-guide.md)
- [Audit Authoring](../docs/04-audit-authoring.md)
- [Cleanup Guide](../web/CLEANUP-GUIDE.md)

---

*Security Audit Toolkit | Licensed under BSL 1.1*
