#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Register lightweight audit agent as a Windows Scheduled Task for invisible background execution.
.DESCRIPTION
    Creates a Windows Scheduled Task that runs the audit agent completely invisibly in the background.
    No console window appears during scheduled execution.
.PARAMETER TaskName
    Name of the scheduled task (default: "Security Audit Agent")
.PARAMETER Schedule
    When to run: Daily, Weekly, Monthly, OnLogon, OnStartup (default: Daily)
.PARAMETER Time
    Time to run (default: "02:00")
.PARAMETER DayOfWeek
    For Weekly schedule (default: Monday)
.PARAMETER Mode
    Agent mode: runall, run, scan (default: runall)
.PARAMETER Audit
    Specific audit to run (for -Mode run)
.PARAMETER ServerUrl
    Core server URL for result export
.PARAMETER ApiKey
    API key for server authentication
.PARAMETER AgentId
    Agent identifier for server communication
.PARAMETER Force
    Overwrite existing task
.PARAMETER Remove
    Remove the scheduled task
.EXAMPLE
    .\Register-ScheduledTask.ps1 -Schedule Daily -Time "03:00"
    Run all audits daily at 3 AM invisibly
.EXAMPLE
    .\Register-ScheduledTask.ps1 -Schedule Weekly -DayOfWeek Sunday -ServerUrl https://audit.example.com -ApiKey abc123
    Run weekly on Sundays and export to server
.EXAMPLE
    .\Register-ScheduledTask.ps1 -Remove
    Remove the scheduled task
#>

[CmdletBinding()]
param(
    [string]$TaskName = "Security Audit Agent - Lightweight",

    [ValidateSet('Daily', 'Weekly', 'Monthly', 'OnLogon', 'OnStartup')]
    [string]$Schedule = "Daily",

    [string]$Time = "02:00",

    [ValidateSet('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')]
    [string]$DayOfWeek = "Monday",

    [ValidateSet('runall', 'run', 'scan', 'daemon')]
    [string]$Mode = "runall",

    [string]$Audit,

    [string]$ServerUrl,

    [string]$ApiKey,

    [string]$AgentId = $env:COMPUTERNAME,

    [switch]$Force,

    [switch]$Remove
)

# ============================================================================
# SCRIPT DISCOVERY
# ============================================================================

$AgentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AgentScript = Join-Path $AgentDir "agent.ps1"
$LogsDir = Join-Path $AgentDir "logs"

if (-not (Test-Path $AgentScript)) {
    Write-Error "Agent script not found at: $AgentScript"
    exit 1
}

# Ensure logs directory exists
if (-not (Test-Path $LogsDir)) {
    New-Item -ItemType Directory -Path $LogsDir -Force | Out-Null
}

Write-Output -InputObject "Security Audit Agent - Scheduled Task Registration"
Write-Output -InputObject "=" * 50

# ============================================================================
# REMOVE TASK
# ============================================================================

if ($Remove) {
    $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($existing) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
        Write-Output -InputObject "[OK] Scheduled task '$TaskName' removed."
    } else {
        Write-Output -InputObject "[INFO] Task '$TaskName' does not exist."
    }
    exit 0
}

# ============================================================================
# CHECK EXISTING TASK
# ============================================================================

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    if ($Force) {
        Write-Output -InputObject "[INFO] Removing existing task..."
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    } else {
        Write-Error "Task '$TaskName' already exists. Use -Force to overwrite or -Remove to delete."
        exit 1
    }
}

# ============================================================================
# BUILD COMMAND ARGUMENTS
# ============================================================================

$arguments = @(
    "-NoProfile",
    "-NonInteractive",
    "-WindowStyle", "Hidden",
    "-ExecutionPolicy", "Bypass",
    "-File", "`"$AgentScript`"",
    "-Mode", $Mode,
    "-Silent"
)

if ($Audit -and $Mode -eq "run") {
    $arguments += "-Audit", "`"$Audit`""
}

if ($ServerUrl) {
    $arguments += "-ServerUrl", "`"$ServerUrl`""
}

if ($ApiKey) {
    $arguments += "-ApiKey", "`"$ApiKey`""
}

if ($AgentId) {
    $arguments += "-AgentId", "`"$AgentId`""
}

$argumentString = $arguments -join " "

Write-Output -InputObject "[INFO] Command: powershell.exe $argumentString"

# ============================================================================
# CREATE TRIGGER
# ============================================================================

$triggerParams = @{}
if ($Schedule -notin @('OnLogon', 'OnStartup')) {
    $triggerParams['At'] = $Time
}

switch ($Schedule) {
    "Daily" {
        $trigger = New-ScheduledTaskTrigger -Daily @triggerParams
    }
    "Weekly" {
        $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $DayOfWeek @triggerParams
    }
    "Monthly" {
        $trigger = New-ScheduledTaskTrigger -Weekly -WeeksInterval 4 -DaysOfWeek $DayOfWeek @triggerParams
    }
    "OnLogon" {
        $trigger = New-ScheduledTaskTrigger -AtLogon
    }
    "OnStartup" {
        $trigger = New-ScheduledTaskTrigger -AtStartup
    }
}

# ============================================================================
# CREATE ACTION (COMPLETELY HIDDEN)
# ============================================================================

$action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument $argumentString `
    -WorkingDirectory $AgentDir

# ============================================================================
# CREATE PRINCIPAL (RUN AS SYSTEM FOR INVISIBLE EXECUTION)
# ============================================================================

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

# ============================================================================
# CREATE SETTINGS (OPTIMIZED FOR BACKGROUND OPERATION)
# ============================================================================

$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable:$false `
    -ExecutionTimeLimit (New-TimeSpan -Hours 4) `
    -Priority 7 `
    -MultipleInstances IgnoreNew `
    -Hidden

# ============================================================================
# REGISTER TASK
# ============================================================================

try {
    $taskParams = @{
        TaskName    = $TaskName
        Description = "Lightweight Security Audit Agent - Automated invisible background scanning"
        Action      = $action
        Trigger     = $trigger
        Principal   = $principal
        Settings    = $settings
    }

    Register-ScheduledTask @taskParams | Out-Null

    Write-Output -InputObject ""
    Write-Output -InputObject "[SUCCESS] Scheduled task created: $TaskName"
    Write-Output -InputObject ""
    Write-Output -InputObject "Task Details:"
    Write-Output -InputObject "  Schedule:    $Schedule $(if ($Schedule -notin @('OnLogon', 'OnStartup')) { "at $Time" })"
    Write-Output -InputObject "  Mode:        $Mode"
    Write-Output -InputObject "  Run As:      SYSTEM (completely hidden)"
    Write-Output -InputObject "  Agent Dir:   $AgentDir"
    Write-Output -InputObject "  Log File:    $LogsDir\agent-*.log"
    if ($ServerUrl) {
        Write-Output -InputObject "  Server URL:  $ServerUrl"
    }
    Write-Output -InputObject ""
    Write-Output -InputObject "Commands:"
    Write-Output -InputObject "  Run now:     Start-ScheduledTask -TaskName '$TaskName'"
    Write-Output -InputObject "  View status: Get-ScheduledTask -TaskName '$TaskName' | Get-ScheduledTaskInfo"
    Write-Output -InputObject "  View logs:   Get-Content '$LogsDir\agent-*.log' -Tail 50"
    Write-Output -InputObject "  Remove:      .\Register-ScheduledTask.ps1 -Remove"
}
catch {
    Write-Output -InputObject "[ERROR] Failed to create scheduled task: $($_.Exception.Message)"
    exit 1
}

