# Testing Guide: Agent Privilege Escalation (JEA & Sudoers)

This guide covers testing the fleet agent's privilege escalation features on both Windows (JEA) and Linux (sudoers).

---

## Quick Test Reference

| Platform | Test Type | Command |
|----------|-----------|---------|
| Windows | JEA Endpoint | `.\test-jea.ps1` |
| Windows | User Mode Install | `.\install-windows.ps1 -Mode User` |
| Windows | Full + JEA | `.\install-windows.ps1 -Mode Full -SetupJea` |
| Linux | User Mode | `./install-user.sh` |
| Linux | With Sudo | `./fleet-agent.sh -m discovery` |

---

## Windows JEA Testing

### Prerequisites

1. Windows Server 2016+ or Windows 10/11
2. PowerShell 5.1+
3. Administrator access for JEA setup
4. Active Directory (optional, for group-based access)

### Test 1: JEA Endpoint Setup

```powershell
# Navigate to JEA directory
cd agents\html-standalone\jea

# Run setup as Administrator
.\setup-jea.ps1

# With custom AD groups
.\setup-jea.ps1 -AdminGroup "YOURDOMAIN\SecurityTeam" -ReadOnlyGroup "YOURDOMAIN\HelpDesk"

# Verify endpoint was created
Get-PSSessionConfiguration | Where-Object { $_.Name -like '*AuditAgent*' }
```

**Expected output:**
```
Name          : AuditAgent.JEA
RunAsUser     :
Permission    : NT AUTHORITY\SYSTEM AccessAllowed, BUILTIN\Administrators AccessAllowed, ...
```

### Test 2: Connect to JEA Endpoint

```powershell
# Connect as non-admin user
Enter-PSSession -ComputerName localhost -ConfigurationName AuditAgent.JEA

# Inside JEA session, verify ConstrainedLanguage mode
$ExecutionContext.SessionState.LanguageMode
# Expected: ConstrainedLanguage

# List available commands
Get-Command

# Test allowed command
Get-Service | Select-Object -First 5

# Test blocked command (should fail)
Stop-Service -Name Spooler
# Expected: Error - cmdlet not available

# Exit session
Exit-PSSession
```

### Test 3: Agent Auto-Detection

```powershell
# Run agent in interactive mode (as non-admin)
.\fleet-agent.ps1 -Mode interactive

# Agent should detect JEA and show:
# [INFO] Auto-detected JEA endpoint: AuditAgent.JEA

# Or run discovery to verify elevation status
.\fleet-agent.ps1 -Mode discovery
```

**Expected discovery output includes:**
```json
{
  "elevation": {
    "mode": "JEA",
    "is_admin": false,
    "jea_available": true,
    "jea_endpoint": "AuditAgent.JEA",
    "reduced_mode": false
  }
}
```

### Test 4: Privileged Commands via JEA

```powershell
# Test running audit that requires elevation
.\fleet-agent.ps1 -Mode run -AuditPath windows\security\baseline

# Agent should use JEA session for privileged operations
# Look for: [DEBUG] Using JEA endpoint for elevated access
```

### Test 5: Transcript Verification

```powershell
# Check JEA transcripts are being created
Get-ChildItem C:\ProgramData\AuditAgent\logs\jea-transcripts -Recurse

# View recent transcript
Get-Content (Get-ChildItem C:\ProgramData\AuditAgent\logs\jea-transcripts -Recurse | Select-Object -Last 1).FullName
```

### Test 6: Uninstall JEA

```powershell
# Remove JEA endpoint
.\setup-jea.ps1 -Uninstall

# Verify removal
Get-PSSessionConfiguration | Where-Object { $_.Name -like '*AuditAgent*' }
# Expected: No results
```

---

## Linux Sudoers Testing

### Prerequisites

1. Linux system with sudo installed
2. Non-root user account
3. Bash 4+

### Test 1: User Mode Installation

```bash
# Install as non-root user
cd agents/html-standalone
./install-user.sh

# Verify installation
ls -la ~/.audit-agent/

# Check service status (user service)
systemctl --user status audit-agent
```

**Expected output:**
- Agent installed to `~/.audit-agent/`
- Systemd user service created
- `setup-sudoers.sh` script generated

### Test 2: Capability Detection (No Sudo)

```bash
# Run discovery without sudo configured
./fleet-agent.sh -m discovery

# Should report reduced mode
# Look for: "sudo_mode": "none"
```

**Expected output includes:**
```json
{
  "elevation": {
    "sudo_mode": "none",
    "reduced_mode": true,
    "capabilities": ["audit_unprivileged", "discovery_basic", "result_upload"]
  }
}
```

### Test 3: Configure Sudoers (Admin Task)

```bash
# Generate sudoers setup script (non-root)
cat ~/.audit-agent/setup-sudoers.sh

# Admin runs the setup script as root
sudo ~/.audit-agent/setup-sudoers.sh

# Or manually add sudoers rule
sudo visudo -f /etc/sudoers.d/audit-agent
# Add: yourusername ALL=(ALL) NOPASSWD: /usr/bin/ss, /usr/bin/netstat, ...
```

### Test 4: Verify Sudo Access

```bash
# Test passwordless sudo for allowed commands
sudo -n ss -tlnp
# Should work without password prompt

# Test blocked command (should require password)
sudo -n apt update
# Should fail or prompt for password
```

### Test 5: Full Capability Discovery

```bash
# Re-run discovery after sudoers configured
./fleet-agent.sh -m discovery

# Should now show full capabilities
# Look for: "sudo_mode": "sudo_nopasswd"
```

**Expected output includes:**
```json
{
  "elevation": {
    "sudo_mode": "sudo_nopasswd",
    "reduced_mode": false,
    "capabilities": ["audit_privileged", "discovery_full", "port_scan_full", ...]
  }
}
```

### Test 6: Run Privileged Audit

```bash
# Run audit that requires privileges
./fleet-agent.sh -m run -a platform/baseline/updates

# Should use sudo for privileged commands
# Look for: [DEBUG] Running with sudo: ...
```

---

## Integration Testing

### Test Server Connection

```bash
# Linux
./fleet-agent.sh -m register \
  --server https://your-audit-server \
  --api-key your-key

# Windows
.\fleet-agent.ps1 -Mode register `
  -ServerUrl https://your-audit-server `
  -ApiKey your-key
```

### Test Auto-Discovery with Elevation

```bash
# Linux
./fleet-agent.sh -m daemon --auto-discovery

# Windows
.\fleet-agent.ps1 -Mode daemon -AutoDiscovery
```

### Verify Server Receives Correct Capabilities

1. Register agent with server
2. Check agent details in web console
3. Verify capabilities match elevation level

---

## Troubleshooting

### Windows JEA Issues

| Issue | Solution |
|-------|----------|
| "Cannot find session configuration" | Restart WinRM: `Restart-Service WinRM` |
| "Access denied" | Check user is in allowed AD group |
| Commands not available | Verify .psrc file has cmdlet listed |
| Transcripts not created | Check transcript directory permissions |

```powershell
# Debug JEA configuration
Get-PSSessionConfiguration -Name AuditAgent.JEA | Format-List *

# Test configuration file
Test-PSSessionConfigurationFile -Path C:\ProgramData\AuditAgent\jea\AuditAgent.pssc
```

### Linux Sudoers Issues

| Issue | Solution |
|-------|----------|
| "sudo: a password is required" | Sudoers file not configured correctly |
| "command not found" | Full path needed in sudoers file |
| Agent shows reduced mode | Run `sudo -n -l` to check allowed commands |

```bash
# Check sudoers syntax
sudo visudo -cf /etc/sudoers.d/audit-agent

# List allowed sudo commands
sudo -l

# Test specific command
sudo -n /usr/bin/ss -tlnp
echo $?  # Should be 0
```

---

## Test Matrix

### Windows

| Scenario | Expected Elevation | Capabilities |
|----------|-------------------|--------------|
| Admin + No JEA | Admin | Full |
| Admin + JEA | Admin (ignores JEA) | Full |
| User + JEA | JEA | Full (via endpoint) |
| User + No JEA | None | Limited |

### Linux

| Scenario | Expected Mode | Capabilities |
|----------|--------------|--------------|
| Root | root | Full |
| User + NOPASSWD sudo | sudo_nopasswd | Full |
| User + password sudo | sudo_password | Limited |
| User + no sudo | none | Basic only |

---

## Automated Test Script

### Windows

```powershell
# Save as test-jea.ps1
# Run as: .\test-jea.ps1

$tests = @(
    @{ Name = "JEA endpoint exists"; Script = { (Get-PSSessionConfiguration -Name 'AuditAgent.JEA' -ErrorAction SilentlyContinue) -ne $null } }
    @{ Name = "Can connect to endpoint"; Script = {
        try {
            $s = New-PSSession -ComputerName localhost -ConfigurationName AuditAgent.JEA -ErrorAction Stop
            Remove-PSSession $s
            $true
        } catch { $false }
    }}
    @{ Name = "Get-Service works in JEA"; Script = {
        try {
            Invoke-Command -ComputerName localhost -ConfigurationName AuditAgent.JEA -ScriptBlock { Get-Service | Select-Object -First 1 }
            $true
        } catch { $false }
    }}
)

foreach ($test in $tests) {
    $result = & $test.Script
    $status = if ($result) { "[PASS]" } else { "[FAIL]" }
    Write-Host "$status $($test.Name)"
}
```

### Linux

```bash
#!/bin/bash
# Save as test-sudo.sh
# Run as: ./test-sudo.sh

echo "=== Fleet Agent Sudo Tests ==="

# Test 1: Check if sudo exists
if command -v sudo &>/dev/null; then
    echo "[PASS] sudo is installed"
else
    echo "[FAIL] sudo not found"
    exit 1
fi

# Test 2: Check passwordless sudo for specific commands
test_commands=("/usr/bin/ss" "/bin/netstat" "/usr/bin/last")
for cmd in "${test_commands[@]}"; do
    if sudo -n "$cmd" &>/dev/null 2>&1; then
        echo "[PASS] Can run $cmd with sudo (no password)"
    else
        echo "[WARN] Cannot run $cmd with passwordless sudo"
    fi
done

# Test 3: Run agent capability detection
if [ -f "./fleet-agent.sh" ]; then
    mode=$(./fleet-agent.sh -m discovery 2>/dev/null | grep -o '"sudo_mode"[^,]*' | cut -d'"' -f4)
    echo "[INFO] Detected sudo mode: $mode"
fi

echo "=== Tests Complete ==="
```

---

## Next Steps After Testing

1. **If tests pass:** Document capabilities in asset inventory
2. **If JEA tests fail:** Check AD group membership and endpoint registration
3. **If sudoers tests fail:** Verify sudoers file syntax and command paths
4. **For production:** Enable transcript logging and periodic audit of access
