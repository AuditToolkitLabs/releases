#Requires -Version 5.1
<#
.SYNOPSIS
    Lightweight Security Audit Agent for Windows
.DESCRIPTION
    Scans for installed software, suggests security audits, runs them on demand,
    and reports results locally or to a central server.

    Designed for environments where WinRM/SSH is disabled for security reasons.
    Includes resource throttling to minimize impact on target systems.
.PARAMETER Mode
    interactive (default), scan, suggest, run, runall, upload, discover, status, self-update
.PARAMETER Audit
    Specific audit path to run (e.g., platform/baseline/updates)
.PARAMETER ServerUrl
    Central server URL for reporting results
.PARAMETER ApiKey
    API key for server authentication
.PARAMETER AgentId
    Unique agent identifier for server communication
.PARAMETER PollInterval
    Seconds between polling for server commands (default: 60)
.PARAMETER ProcessPriority
    CPU priority for audit processes: Idle, BelowNormal, Normal, AboveNormal, High (default: Idle)
.PARAMETER MinFreeMemoryPct
    Minimum free memory percentage to start audits (default: 10)
.PARAMETER MaxCpuPct
    Maximum CPU usage percentage to start audits, 0 = disabled (default: 0)
.PARAMETER UploadRateLimit
    Upload bandwidth limit in bytes/sec, 0 = unlimited (default: 0)
.PARAMETER DownloadRateLimit
    Download bandwidth limit in bytes/sec, 0 = unlimited (default: 0)
.PARAMETER CommandBatchSize
    Maximum commands to process per poll cycle (default: 5)
.PARAMETER BatchDelay
    Seconds between processing commands (default: 5)
.PARAMETER AuditTimeout
    Maximum seconds per audit execution (default: 3600)
.EXAMPLE
    .\agent.ps1
    Runs in interactive menu mode
.EXAMPLE
    .\agent.ps1 -Mode scan
    Scans and displays detected software
.EXAMPLE
    .\agent.ps1 -Mode run -Audit platform/baseline/updates
    Runs a specific audit
.EXAMPLE
    .\agent.ps1 -Mode upload -ServerUrl https://audit.company.com -ApiKey abc123
    Uploads all pending results to server
.EXAMPLE
    .\agent.ps1 -Mode discover -ServerUrl https://audit.company.com -ApiKey abc123
    Runs local discovery and uploads the payload to the core server
#>

[CmdletBinding()]
param(
    [ValidateSet('interactive', 'scan', 'suggest', 'run', 'runall', 'upload', 'discover', 'status', 'poll', 'daemon', 'sync', 'self-update')]
    [string]$Mode = 'interactive',

    [string]$Audit,

    [string]$ServerUrl = $env:AUDIT_SERVER_URL,

    [string]$ApiKey = $env:AUDIT_API_KEY,

    [string]$AgentId = $env:AUDIT_AGENT_ID,

    [int]$PollInterval = 60,

    # Silent mode - no console output, log to file only
    [switch]$Silent,

    # Log file path for silent mode
    [string]$LogFile,

    # Resource Throttling Parameters
    [ValidateSet('Idle', 'BelowNormal', 'Normal', 'AboveNormal', 'High', 'Realtime')]
    [string]$ProcessPriority = 'Idle',

    [ValidateRange(5, 95)]
    [int]$MinFreeMemoryPct = 10,

    [ValidateRange(1, 95)]
    [int]$PauseMemoryPct = 5,

    [ValidateRange(0, 100)]
    [int]$MaxCpuPct = 0,  # 0 = disabled

    [int]$UploadRateLimit = 0,  # bytes/sec, 0 = unlimited

    [int]$DownloadRateLimit = 0,  # bytes/sec, 0 = unlimited

    [ValidateRange(1, 100)]
    [int]$CommandBatchSize = 5,

    [ValidateRange(0, 300)]
    [int]$BatchDelay = 5,  # seconds between commands

    [int]$AuditTimeout = 3600,  # seconds

    [int]$HeartbeatMinInterval = 30,  # minimum seconds between heartbeats

    [switch]$NoColor
)

# ============================================================================
# Configuration
# ============================================================================
$script:AgentVersion = "6.2.1"
$script:AgentScriptPath = $MyInvocation.MyCommand.Path
$script:AgentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ResultsDir = Join-Path $AgentDir "results"
$script:AuditsDir = Join-Path $AgentDir "audits"
$script:ConfigFile = Join-Path $AgentDir "agent.config.json"
$script:CoreAttestationRequired = (($env:AUDIT_CORE_ATTESTATION_REQUIRED ?? 'true').ToLower() -eq 'true')
$script:TlsSkipVerify = (($env:AUDIT_TLS_SKIP_VERIFY ?? 'false').ToLower() -eq 'true')
$script:AgentEnvironment = ($env:AUDIT_ENVIRONMENT ?? 'production').ToLower()
$script:AllowInsecureTlsInNonProd = (($env:AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD ?? 'false').ToLower() -eq 'true')
$script:ManagedRequireHttps = (($env:AUDIT_MANAGED_REQUIRE_HTTPS ?? 'true').ToLower() -eq 'true')
$script:ManagedAllowPrivateHosts = (($env:AUDIT_MANAGED_ALLOW_PRIVATE_HOSTS ?? 'true').ToLower() -eq 'true')
$script:ManagedAllowedServerDomains = ($env:AUDIT_MANAGED_ALLOWED_SERVER_DOMAINS ?? '')
$script:ManagedBlockedServerKeywords = ($env:AUDIT_MANAGED_BLOCKED_SERVER_KEYWORDS ?? 'wazuh,splunk,elastic,datadog,newrelic')
$script:DebugUrlPolicy = (($env:AUDIT_DEBUG_URL_POLICY ?? 'false').ToLower() -eq 'true')
$script:ManagedRequireRequestSignatures = (($env:AUDIT_MANAGED_REQUIRE_REQUEST_SIGNATURES ?? 'false').ToLower() -eq 'true')
$script:ManagedRequestSigningKey = ($env:AUDIT_MANAGED_REQUEST_SIGNING_KEY ?? '')
$script:ManagedRequestSignatureUseEcdsa = (($env:AUDIT_MANAGED_REQUEST_SIGNATURE_USE_ECDSA ?? 'false').ToLower() -eq 'true')
$script:ManagedRequestSignatureEcdsaPrivateKeyPath = ($env:AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE ?? '')

# Detected software and suggested audits
$script:DetectedSoftware = @{}
$script:SuggestedAudits = @{}

# Throttling state
$script:LastHeartbeatTime = [DateTime]::MinValue

# ============================================================================
# Resource Throttling Configuration (from environment if not set via params)
# ============================================================================
if (-not $ProcessPriority) { $ProcessPriority = $env:AUDIT_PROCESS_PRIORITY ?? 'Idle' }
if (-not $MinFreeMemoryPct) { $MinFreeMemoryPct = [int]($env:AUDIT_MIN_FREE_MEMORY_PCT ?? 10) }
if (-not $MaxCpuPct) { $MaxCpuPct = [int]($env:AUDIT_MAX_CPU_PCT ?? 0) }
if (-not $UploadRateLimit) { $UploadRateLimit = [int]($env:AUDIT_UPLOAD_RATE_LIMIT ?? 0) }
if (-not $DownloadRateLimit) { $DownloadRateLimit = [int]($env:AUDIT_DOWNLOAD_RATE_LIMIT ?? 0) }
if (-not $CommandBatchSize) { $CommandBatchSize = [int]($env:AUDIT_COMMAND_BATCH_SIZE ?? 5) }
if (-not $BatchDelay) { $BatchDelay = [int]($env:AUDIT_BATCH_DELAY ?? 5) }
if (-not $AuditTimeout) { $AuditTimeout = [int]($env:AUDIT_TIMEOUT ?? 3600) }

# ============================================================================
# Resource Checking Functions
# ============================================================================
function Get-MemoryInfo {
    <#
    .SYNOPSIS
        Get current memory usage information
    .OUTPUTS
        Hashtable with TotalMB, FreeMB, FreePct
    #>
    try {
        $os = Get-CimInstance -ClassName Win32_OperatingSystem
        $totalMB = [math]::Round($os.TotalVisibleMemorySize / 1024, 0)
        $freeMB = [math]::Round($os.FreePhysicalMemory / 1024, 0)
        $freePct = [math]::Round(($freeMB / $totalMB) * 100, 0)

        return @{
            TotalMB = $totalMB
            FreeMB = $freeMB
            FreePct = $freePct
        }
    }
    catch {
        # Fallback: assume plenty of memory
        return @{ TotalMB = 8192; FreeMB = 4096; FreePct = 50 }
    }
}

function Get-CpuUsage {
    <#
    .SYNOPSIS
        Get current CPU usage percentage
    #>
    try {
        $cpuCounter = Get-Counter '\Processor(_Total)\% Processor Time' -ErrorAction Stop
        return [math]::Round($cpuCounter.CounterSamples[0].CookedValue, 0)
    }
    catch {
        return 0
    }
}

function Add-ManagedRequestSignatureHeaders {
    param(
        [string]$Method,
        [string]$Uri,
        [hashtable]$Headers,
        $Body
    )

    if (-not $script:ManagedRequireRequestSignatures) {
        return $Headers
    }

    if (-not $script:ManagedRequestSigningKey) {
        throw 'Managed request-signature enforcement enabled but AUDIT_MANAGED_REQUEST_SIGNING_KEY is not set.'
    }

    if (-not $Headers) {
        $Headers = @{}
    }

    $requestMethod = ($Method ?? 'GET').ToUpperInvariant()
    $parsedUri = [System.Uri]$Uri
    $requestPath = $parsedUri.AbsolutePath
    if (-not $requestPath) { $requestPath = '/' }

    $requestBody = ''
    if ($null -ne $Body) {
        if ($Body -is [hashtable]) {
            $requestBody = $Body | ConvertTo-Json -Depth 10 -Compress
        }
        else {
            $requestBody = [string]$Body
        }
    }

    $requestTimestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString()
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($requestBody)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $payloadHashBytes = $sha256.ComputeHash($bodyBytes)
    }
    finally {
        $sha256.Dispose()
    }
    $payloadHash = [System.BitConverter]::ToString($payloadHashBytes).Replace('-', '').ToLowerInvariant()

    $agentIdForSignature = ''
    if ($Headers.ContainsKey('X-Agent-ID')) {
        $agentIdForSignature = [string]$Headers['X-Agent-ID']
    }
    elseif ($script:AgentId) {
        $agentIdForSignature = [string]$script:AgentId
    }

    $signatureMessage = "$requestMethod`:$requestPath`:$agentIdForSignature`:$requestTimestamp`:$payloadHash"
    if ($script:ManagedRequestSignatureUseEcdsa) {
        if (-not $script:ManagedRequestSignatureEcdsaPrivateKeyPath) {
            throw 'ECDSA request-signature mode enabled but AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE is not set.'
        }
        if (-not (Test-Path $script:ManagedRequestSignatureEcdsaPrivateKeyPath)) {
            throw "ECDSA private key file not found: $($script:ManagedRequestSignatureEcdsaPrivateKeyPath)"
        }
        $openssl = Get-Command openssl -ErrorAction SilentlyContinue
        if (-not $openssl) { throw 'ECDSA request-signature mode requires openssl in PATH.' }

        $tmpFile = Join-Path $env:TEMP ("agent_sig_{0}.txt" -f [Guid]::NewGuid().ToString('N'))
        try {
            [System.IO.File]::WriteAllText($tmpFile, $signatureMessage, [System.Text.Encoding]::UTF8)
            $ecdsaB64 = & openssl dgst -sha256 -sign "$($script:ManagedRequestSignatureEcdsaPrivateKeyPath)" "$tmpFile" 2>$null | & openssl base64 -A 2>$null
            if (-not $ecdsaB64) { throw 'Failed to compute ECDSA request signature.' }
            $signature = "ecdsa:$ecdsaB64"
        }
        finally {
            Remove-Item $tmpFile -ErrorAction SilentlyContinue
        }
    }
    else {
        $hmac = [System.Security.Cryptography.HMACSHA256]::new([System.Text.Encoding]::UTF8.GetBytes($script:ManagedRequestSigningKey))
        try {
            $signatureBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($signatureMessage))
        }
        finally {
            $hmac.Dispose()
        }
        $signature = [System.BitConverter]::ToString($signatureBytes).Replace('-', '').ToLowerInvariant()
    }

    $Headers['X-Agent-Timestamp'] = $requestTimestamp
    $Headers['X-Agent-Content-SHA256'] = $payloadHash
    $Headers['X-Agent-Signature'] = $signature
    return $Headers
}

function Invoke-ThrottledWebRequest {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [string]$Method = 'GET',
        [hashtable]$Headers = @{},
        [object]$Body = $null,
        [string]$OutFile = $null,
        [ValidateSet('Upload', 'Download')][string]$Direction = 'Upload'
    )

    $rateLimit = if ($Direction -eq 'Upload') { $UploadRateLimit } else { $DownloadRateLimit }
    $skipCertificateCheck = $script:TlsSkipVerify -and $script:AllowInsecureTlsInNonProd -and ($script:AgentEnvironment -ne 'production')

    $params = @{
        Uri = $Uri
        Method = $Method
        Headers = $Headers
        ContentType = 'application/json'
        UseBasicParsing = $true
    }

    if ($Body) {
        if ($Body -is [hashtable]) {
            $params.Body = $Body | ConvertTo-Json -Depth 10
        }
        else {
            $params.Body = $Body
        }
    }

    # If rate limiting is enabled and we have a body, add artificial delay
    if ($rateLimit -gt 0 -and $Body) {
        $bodySize = if ($params.Body) { $params.Body.Length } else { 0 }
        if ($bodySize -gt 0) {
            $delaySeconds = [math]::Ceiling($bodySize / $rateLimit)
            if ($delaySeconds -gt 0) {
                Write-Info "Throttling: ${delaySeconds}s delay for ${bodySize} bytes at ${rateLimit} bytes/sec"
                Start-Sleep -Seconds $delaySeconds
            }
        }
    }

    if ($skipCertificateCheck) {
        if ((Get-Command Invoke-RestMethod).Parameters.ContainsKey('SkipCertificateCheck')) {
            $params.SkipCertificateCheck = $true
        }
        elseif ((Get-Command Invoke-WebRequest).Parameters.ContainsKey('SkipCertificateCheck')) {
            $params.SkipCertificateCheck = $true
        }
        else {
            throw "Insecure TLS bypass is not supported by this PowerShell runtime"
        }
    }

    $params.Headers = Add-ManagedRequestSignatureHeaders -Method $Method -Uri $Uri -Headers $params.Headers -Body $params.Body

    if ($OutFile) {
        return Invoke-WebRequest @params
    }

    return Invoke-RestMethod @params
}

# ============================================================================
# Silent Mode & Logging Setup
# ============================================================================
$script:SilentMode = $Silent.IsPresent
$script:LogsDir = Join-Path $AgentDir "logs"
if (-not (Test-Path $script:LogsDir)) {
    New-Item -ItemType Directory -Path $script:LogsDir -Force | Out-Null
}
if ($script:SilentMode -and -not $LogFile) {
    $LogFile = Join-Path $script:LogsDir "agent-$(Get-Date -Format 'yyyyMMdd').log"
}
$script:LogFilePath = $LogFile

function Write-AgentLog {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] [$Level] $Message"
    if ($script:LogFilePath) {
        Add-Content -Path $script:LogFilePath -Value $logLine
    }
}

function Write-Info {
    param([string]$Message)
    Write-AgentLog -Message $Message -Level "INFO"
    if (-not $script:SilentMode) {
        if ($NoColor) { Write-Host "[INFO] $Message" }
        else { Write-Host "[INFO] $Message" -ForegroundColor Cyan }
    }
}

function Write-Ok {
    param([string]$Message)
    Write-AgentLog -Message $Message -Level "OK"
    if (-not $script:SilentMode) {
        if ($NoColor) { Write-Host "[OK] $Message" }
        else { Write-Host "[OK] $Message" -ForegroundColor Green }
    }
}

function Write-Warn {
    param([string]$Message)
    Write-AgentLog -Message $Message -Level "WARN"
    if (-not $script:SilentMode) {
        if ($NoColor) { Write-Host "[WARN] $Message" }
        else { Write-Host "[WARN] $Message" -ForegroundColor Yellow }
    }
}

function Write-Err {
    param([string]$Message)
    Write-AgentLog -Message $Message -Level "ERROR"
    if (-not $script:SilentMode) {
        if ($NoColor) { Write-Host "[ERROR] $Message" }
        else { Write-Host "[ERROR] $Message" -ForegroundColor Red }
    }
}

# ============================================================================
# OS Detection
# ============================================================================
function Get-OSInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem

    $script:OSInfo = @{
        Name = $os.Caption
        Version = $os.Version
        Build = $os.BuildNumber
        Hostname = $env:COMPUTERNAME
        Domain = $cs.Domain
        IsServer = $os.Caption -match 'Server'
        IsDesktop = $os.Caption -notmatch 'Server'
        Is64Bit = [Environment]::Is64BitOperatingSystem
        Architecture = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
    }

    return $script:OSInfo
}

# ============================================================================
# Software Detection
# ============================================================================
function Find-InstalledSoftware {
    Write-Info "Scanning installed software and features..."
    $script:DetectedSoftware = @{}

    # Windows Features/Roles
    try {
        $features = Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue
        if ($features) {
            # Check for specific features
            if ($features | Where-Object { $_.FeatureName -like '*IIS*' -and $_.State -eq 'Enabled' }) {
                $script:DetectedSoftware['iis'] = "Internet Information Services (IIS)"
            }
            if ($features | Where-Object { $_.FeatureName -eq 'OpenSSH.Server' -and $_.State -eq 'Enabled' }) {
                $script:DetectedSoftware['openssh'] = "OpenSSH Server"
            }
            if ($features | Where-Object { $_.FeatureName -like '*Hyper-V*' -and $_.State -eq 'Enabled' }) {
                $script:DetectedSoftware['hyperv'] = "Hyper-V Virtualization"
            }
            if ($features | Where-Object { $_.FeatureName -like '*Containers*' -and $_.State -eq 'Enabled' }) {
                $script:DetectedSoftware['containers'] = "Windows Containers"
            }
        }
    } catch {
        # Try server cmdlet if client fails
        try {
            $roles = Get-WindowsFeature -ErrorAction SilentlyContinue | Where-Object { $_.Installed }
            if ($roles | Where-Object { $_.Name -like '*Web-Server*' }) {
                $script:DetectedSoftware['iis'] = "Internet Information Services (IIS)"
            }
            if ($roles | Where-Object { $_.Name -like '*Hyper-V*' }) {
                $script:DetectedSoftware['hyperv'] = "Hyper-V Virtualization"
            }
            if ($roles | Where-Object { $_.Name -like '*AD-Domain-Services*' }) {
                $script:DetectedSoftware['adds'] = "Active Directory Domain Services"
            }
            if ($roles | Where-Object { $_.Name -like '*DNS*' }) {
                $script:DetectedSoftware['dns'] = "DNS Server"
            }
            if ($roles | Where-Object { $_.Name -like '*DHCP*' }) {
                $script:DetectedSoftware['dhcp'] = "DHCP Server"
            }
            if ($roles | Where-Object { $_.Name -like '*FS-FileServer*' }) {
                $script:DetectedSoftware['fileserver'] = "File Server"
            }
        } catch {
            Write-Warn "Could not enumerate Windows features (requires elevation)"
        }
    }

    # Check for common installed applications
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    $installedApps = $regPaths | ForEach-Object {
        Get-ItemProperty $_ -ErrorAction SilentlyContinue
    } | Where-Object { $_.DisplayName } | Select-Object DisplayName, DisplayVersion

    # SQL Server
    if ($installedApps | Where-Object { $_.DisplayName -like '*SQL Server*' }) {
        $script:DetectedSoftware['sqlserver'] = "Microsoft SQL Server"
    }

    # MySQL
    if ($installedApps | Where-Object { $_.DisplayName -like '*MySQL*' }) {
        $script:DetectedSoftware['mysql'] = "MySQL Database"
    }

    # PostgreSQL
    if ($installedApps | Where-Object { $_.DisplayName -like '*PostgreSQL*' }) {
        $script:DetectedSoftware['postgresql'] = "PostgreSQL Database"
    }

    # MongoDB
    if ($installedApps | Where-Object { $_.DisplayName -like '*MongoDB*' }) {
        $script:DetectedSoftware['mongodb'] = "MongoDB Database"
    }

    # Docker
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        $script:DetectedSoftware['docker'] = "Docker Container Runtime"
    }

    # Check for specific services
    $services = Get-Service -ErrorAction SilentlyContinue

    # Windows Defender
    if ($services | Where-Object { $_.Name -eq 'WinDefend' -and $_.Status -eq 'Running' }) {
        $script:DetectedSoftware['defender'] = "Windows Defender Antivirus"
    }

    # Windows Firewall
    if ($services | Where-Object { $_.Name -eq 'MpsSvc' -and $_.Status -eq 'Running' }) {
        $script:DetectedSoftware['firewall'] = "Windows Firewall"
    }

    # WSUS
    if ($services | Where-Object { $_.Name -eq 'WsusService' }) {
        $script:DetectedSoftware['wsus'] = "Windows Server Update Services"
    }

    # Remote Desktop
    $rdpEnabled = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -ErrorAction SilentlyContinue).fDenyTSConnections -eq 0
    if ($rdpEnabled) {
        $script:DetectedSoftware['rdp'] = "Remote Desktop Services"
    }

    # BitLocker
    try {
        $bitlocker = Get-BitLockerVolume -MountPoint "C:" -ErrorAction SilentlyContinue
        if ($bitlocker -and $bitlocker.ProtectionStatus -eq 'On') {
            $script:DetectedSoftware['bitlocker'] = "BitLocker Drive Encryption (Active)"
        } elseif ($bitlocker) {
            $script:DetectedSoftware['bitlocker'] = "BitLocker Drive Encryption (Available)"
        }
    } catch {}

    # Check PowerShell version
    $script:DetectedSoftware['powershell'] = "PowerShell $($PSVersionTable.PSVersion.Major).$($PSVersionTable.PSVersion.Minor)"

    # .NET Framework
    $dotnet = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue
    if ($dotnet) {
        $script:DetectedSoftware['dotnet'] = ".NET Framework $($dotnet.Release)"
    }

    Write-Ok "Detected $($script:DetectedSoftware.Count) software components"
    return $script:DetectedSoftware
}

# ============================================================================
# Audit Suggestions
# ============================================================================
function Get-SuggestedAudits {
    Write-Info "Generating audit suggestions..."
    $script:SuggestedAudits = @{}

    # Platform audits (always suggested)
    $script:SuggestedAudits['platform/baseline/updates'] = "Check for pending Windows updates"
    $script:SuggestedAudits['platform/baseline/users'] = "Audit user accounts and privileges"
    $script:SuggestedAudits['platform/baseline/services'] = "Review running services"
    $script:SuggestedAudits['platform/baseline/audit-policy'] = "Check Windows audit policy settings"
    $script:SuggestedAudits['platform/baseline/security-policy'] = "Review local security policy"

    # Windows Defender
    if ($script:DetectedSoftware.ContainsKey('defender')) {
        $script:SuggestedAudits['platform/security/defender'] = "Windows Defender configuration"
        $script:SuggestedAudits['platform/security/defender-exclusions'] = "Review Defender exclusions"
    }

    # Firewall
    if ($script:DetectedSoftware.ContainsKey('firewall')) {
        $script:SuggestedAudits['network/firewall/windows-firewall'] = "Windows Firewall rules audit"
    }

    # BitLocker
    if ($script:DetectedSoftware.ContainsKey('bitlocker')) {
        $script:SuggestedAudits['storage/encryption/bitlocker'] = "BitLocker encryption audit"
    }

    # IIS
    if ($script:DetectedSoftware.ContainsKey('iis')) {
        $script:SuggestedAudits['web/iis/iis-security'] = "IIS security configuration"
        $script:SuggestedAudits['web/iis/iis-tls'] = "IIS TLS/SSL configuration"
    }

    # SQL Server
    if ($script:DetectedSoftware.ContainsKey('sqlserver')) {
        $script:SuggestedAudits['data/sqlserver/sqlserver-security'] = "SQL Server security audit"
        $script:SuggestedAudits['data/sqlserver/sqlserver-permissions'] = "SQL Server permissions audit"
    }

    # MySQL
    if ($script:DetectedSoftware.ContainsKey('mysql')) {
        $script:SuggestedAudits['data/mysql/mysql-security'] = "MySQL security audit"
    }

    # PostgreSQL
    if ($script:DetectedSoftware.ContainsKey('postgresql')) {
        $script:SuggestedAudits['data/postgres/postgres-security'] = "PostgreSQL security audit"
    }

    # Docker
    if ($script:DetectedSoftware.ContainsKey('docker')) {
        $script:SuggestedAudits['apps/docker/docker-security'] = "Docker security audit"
    }

    # Hyper-V
    if ($script:DetectedSoftware.ContainsKey('hyperv')) {
        $script:SuggestedAudits['hypervisors/hyperv/hyperv-security'] = "Hyper-V security configuration"
    }

    # Active Directory
    if ($script:DetectedSoftware.ContainsKey('adds')) {
        $script:SuggestedAudits['platform/ad/ad-security'] = "Active Directory security audit"
        $script:SuggestedAudits['platform/ad/ad-gpo'] = "Group Policy audit"
    }

    # Remote Desktop
    if ($script:DetectedSoftware.ContainsKey('rdp')) {
        $script:SuggestedAudits['network/rdp/rdp-security'] = "Remote Desktop security settings"
    }

    Write-Ok "Generated $($script:SuggestedAudits.Count) audit suggestions"
    return $script:SuggestedAudits
}

# ============================================================================
# Audit Execution
# ============================================================================
function Invoke-Audit {
    param(
        [Parameter(Mandatory)]
        [string]$AuditPath
    )

    $auditScript = Join-Path $script:AuditsDir "$AuditPath.ps1"

    if (-not (Test-Path $auditScript)) {
        Write-Warn "Audit not found: $AuditPath"
        Write-Info "Checking for embedded audit or downloading from server..."

        # Try to download from server
        if ($script:ServerUrl) {
            $downloaded = Get-AuditFromServer -AuditPath $AuditPath
            if (-not $downloaded) {
                return $false
            }
        } else {
            Write-Err "Audit script not available. Configure server URL to download audits."
            return $false
        }
    }

    Write-Info "Running audit: $AuditPath"

    # Ensure results directory exists
    if (-not (Test-Path $script:ResultsDir)) {
        New-Item -ItemType Directory -Path $script:ResultsDir -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $resultFile = Join-Path $script:ResultsDir "$($AuditPath.Replace('/', '_'))_$timestamp.json"

    try {
        # Execute audit and capture output
        $startTime = Get-Date
        $output = & $auditScript 2>&1
        $endTime = Get-Date

        # Parse results
        $result = @{
            audit = $AuditPath
            hostname = $env:COMPUTERNAME
            os = $script:OSInfo.Name
            timestamp = $startTime.ToString("o")
            duration_ms = ($endTime - $startTime).TotalMilliseconds
            checks = @()
            summary = @{
                total = 0
                passed = 0
                failed = 0
                warnings = 0
                skipped = 0
            }
        }

        # Parse [PASS], [FAIL], [WARN], [SKIP] markers from output
        $output | ForEach-Object {
            if ($_ -match '\[(PASS|FAIL|WARN|SKIP)\]\s*(.+)') {
                $status = $Matches[1]
                $message = $Matches[2]
                $result.checks += @{
                    status = $status
                    message = $message
                }
                $result.summary.total++
                switch ($status) {
                    'PASS' { $result.summary.passed++ }
                    'FAIL' { $result.summary.failed++ }
                    'WARN' { $result.summary.warnings++ }
                    'SKIP' { $result.summary.skipped++ }
                }
            }
        }

        # Save results
        $result | ConvertTo-Json -Depth 10 | Out-File -FilePath $resultFile -Encoding UTF8
        Write-Ok "Audit completed: $resultFile"

        # Show summary
        Write-Host ""
        Write-Host "Summary: " -NoNewline
        Write-Host "$($result.summary.passed) Passed" -ForegroundColor Green -NoNewline
        Write-Host ", $($result.summary.failed) Failed" -ForegroundColor Red -NoNewline
        Write-Host ", $($result.summary.warnings) Warnings" -ForegroundColor Yellow -NoNewline
        Write-Host ", $($result.summary.skipped) Skipped" -ForegroundColor Gray

        return $true
    }
    catch {
        Write-Err "Audit failed: $_"
        return $false
    }
}

function Invoke-AllSuggestedAudits {
    Write-Info "Running all suggested audits..."
    $completed = 0
    $failed = 0

    foreach ($audit in $script:SuggestedAudits.Keys) {
        Write-Host ""
        Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray
        if (Invoke-Audit -AuditPath $audit) {
            $completed++
        } else {
            $failed++
        }
    }

    Write-Host ""
    Write-Ok "Completed $completed audits ($failed failed)"
}

# ============================================================================
# Server Communication
# ============================================================================
function Get-AuditFromServer {
    param([string]$AuditPath)

    if (-not $script:ServerUrl) {
        Write-Warn "No server URL configured"
        return $false
    }

    Write-Info "Downloading audit from server: $AuditPath"

    try {
        $url = "$($script:ServerUrl)/api/agent/audits/$($AuditPath.Replace('/', '/'))"
        $headers = @{}
        if ($script:ApiKey) {
            $headers['X-API-Key'] = $script:ApiKey
        }

        $response = Invoke-ThrottledWebRequest -Uri $url -Headers $headers -Method Get -Direction Download

        # Save audit script
        $localPath = Join-Path $script:AuditsDir "$AuditPath.ps1"
        $localDir = Split-Path -Parent $localPath
        if (-not (Test-Path $localDir)) {
            New-Item -ItemType Directory -Path $localDir -Force | Out-Null
        }

        $response.script | Out-File -FilePath $localPath -Encoding UTF8
        Write-Ok "Downloaded: $localPath"
        return $true
    }
    catch {
        Write-Err "Failed to download audit: $_"
        return $false
    }
}

function Send-Results {
    param(
        [string]$ResultFile,
        [switch]$All
    )

    if (-not $script:ServerUrl) {
        Write-Warn "No server URL configured"
        return $false
    }

    $files = @()
    if ($All) {
        $files = Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -ErrorAction SilentlyContinue
    } elseif ($ResultFile) {
        $files = @(Get-Item $ResultFile)
    }

    if ($files.Count -eq 0) {
        Write-Info "No results to upload"
        return $true
    }

    Write-Info "Uploading $($files.Count) result(s) to server..."

    $headers = @{
        'Content-Type' = 'application/json'
    }
    if ($script:ApiKey) {
        $headers['X-API-Key'] = $script:ApiKey
    }
    if ($AgentId) {
        $headers['X-Agent-ID'] = $AgentId
    }

    $attestationToken = Get-CoreAttestationToken
    if ($script:CoreAttestationRequired -and -not $attestationToken) {
        Write-Err "Blocking upload: core attestation required"
        return $false
    }
    if ($attestationToken) {
        $headers['X-Core-Attestation'] = $attestationToken
    }

    $uploaded = 0
    foreach ($file in $files) {
        try {
            $content = Get-Content $file.FullName -Raw
            $body = @{
                hostname = $env:COMPUTERNAME
                os = $script:OSInfo.Name
                agent_version = $script:AgentVersion
                results = ($content | ConvertFrom-Json)
            } | ConvertTo-Json -Depth 10

            $url = "$($script:ServerUrl)/api/agent/results"
                Invoke-ThrottledWebRequest -Uri $url -Headers $headers -Method Post -Body $body -Direction Upload | Out-Null

            # Move to uploaded folder
            $uploadedDir = Join-Path $script:ResultsDir "uploaded"
            if (-not (Test-Path $uploadedDir)) {
                New-Item -ItemType Directory -Path $uploadedDir -Force | Out-Null
            }
            Move-Item $file.FullName -Destination $uploadedDir -Force
            $uploaded++
        }
        catch {
            Write-Err "Failed to upload $($file.Name): $_"
        }
    }

    Write-Ok "Uploaded $uploaded of $($files.Count) results"
    return $uploaded -eq $files.Count
}

function Get-CoreAttestationToken {
    if (-not $script:CoreAttestationRequired) {
        return $null
    }

    if (-not $script:ServerUrl) {
        Write-Err "Cannot request core attestation: server URL not configured"
        return $null
    }

    $headers = @{
        'Content-Type' = 'application/json'
    }
    if ($script:ApiKey) {
        $headers['X-API-Key'] = $script:ApiKey
    }
    if ($AgentId) {
        $headers['X-Agent-ID'] = $AgentId
    }

    $body = @{
        nonce = [Guid]::NewGuid().ToString()
        hostname = $env:COMPUTERNAME
    } | ConvertTo-Json

    try {
        $url = "$($script:ServerUrl)/api/agent/core-attestation"
        $response = Invoke-ThrottledWebRequest -Uri $url -Headers $headers -Method Post -Body $body -Direction Upload

        if ($response -and $response.success -and $response.token) {
            return [string]$response.token
        }

        Write-Err "Core attestation failed: invalid response"
        return $null
    }
    catch {
        Write-Err "Core attestation failed: $_"
        return $null
    }
}

function Invoke-SelfUpdate {
    if (-not $script:ServerUrl) {
        Write-Err "Please specify server URL with -ServerUrl parameter"
        return $false
    }

    $headers = @{ 'Content-Type' = 'application/json' }
    if ($script:ApiKey) { $headers['X-API-Key'] = $script:ApiKey }
    if ($AgentId) { $headers['X-Agent-ID'] = $AgentId }

    $manifestUrl = "$($script:ServerUrl)/api/agent/update/manifest?agent_type=standalone&os_type=windows&current_version=$($script:AgentVersion)"

    try {
        $manifest = Invoke-ThrottledWebRequest -Uri $manifestUrl -Headers $headers -Method Get -Direction Download
    }
    catch {
        Write-Err "Failed to fetch update manifest: $_"
        return $false
    }

    if (-not $manifest.success) {
        Write-Err "Update manifest error: $($manifest.error)"
        return $false
    }

    if (-not $manifest.update_available) {
        Write-Ok "Agent is up to date (current: $($script:AgentVersion), latest: $($manifest.latest_version))"
        return $true
    }

    if (-not $manifest.download_url -or -not $manifest.verify_url -or -not $manifest.signature -or -not $manifest.sha256) {
        Write-Err "Invalid update manifest: missing download/verify/signature/sha256"
        return $false
    }

    $tempFile = Join-Path $env:TEMP ("agent_update_{0}.ps1" -f [Guid]::NewGuid().ToString('N'))
    try {
        Invoke-ThrottledWebRequest -Uri $manifest.download_url -Headers $headers -Method Get -OutFile $tempFile -Direction Download
    }
    catch {
        Write-Err "Failed to download update artifact: $_"
        return $false
    }

    $downloadHash = (Get-FileHash -Path $tempFile -Algorithm SHA256).Hash.ToLower()
    if ($downloadHash -ne ([string]$manifest.sha256).ToLower()) {
        Write-Err "Update checksum mismatch"
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    $verifyBody = @{
        signature = [string]$manifest.signature
        file_sha256 = $downloadHash
        agent_type = 'standalone'
        os_type = 'windows'
        version = [string]$manifest.latest_version
    } | ConvertTo-Json

    try {
        $verify = Invoke-ThrottledWebRequest -Uri $manifest.verify_url -Headers $headers -Method Post -Body $verifyBody -Direction Upload
    }
    catch {
        Write-Err "Signed update verification request failed: $_"
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    if (-not $verify.success) {
        Write-Err "Signed update verification failed: $($verify.error)"
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        return $false
    }

    $scriptPath = $script:AgentScriptPath
    $backupPath = "$scriptPath.bak.$(Get-Date -Format 'yyyyMMdd_HHmmss')"

    try {
        Copy-Item -Path $scriptPath -Destination $backupPath -Force
        Copy-Item -Path $tempFile -Destination $scriptPath -Force
        Write-Ok "Updated standalone agent $($script:AgentVersion) -> $($manifest.latest_version)"
        Write-Info "Backup saved to: $backupPath"
        Write-Info "Restart the agent to run the new version"
        return $true
    }
    catch {
        Write-Err "Failed to install update: $_"
        return $false
    }
    finally {
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    }
}

function Register-Agent {
    if (-not $script:ServerUrl) {
        Write-Warn "No server URL configured"
        return $false
    }

    Write-Info "Registering agent with server..."

    $osInfo = Get-OSInfo
    $body = @{
        hostname = $osInfo.Hostname
        os_name = $osInfo.Name
        os_version = $osInfo.Version
        os_type = if ($osInfo.IsServer) { "windows-server" } else { "windows-desktop" }
        architecture = $osInfo.Architecture
        agent_version = $script:AgentVersion
        detected_software = $script:DetectedSoftware.Keys
    } | ConvertTo-Json

    $headers = @{
        'Content-Type' = 'application/json'
    }
    if ($script:ApiKey) {
        $headers['X-API-Key'] = $script:ApiKey
    }

    try {
        $url = "$($script:ServerUrl)/api/agent/register"
        $response = Invoke-ThrottledWebRequest -Uri $url -Headers $headers -Method Post -Body $body -Direction Upload
        Write-Ok "Agent registered: $($response.agent_id)"

        # Save agent ID
        @{ agent_id = $response.agent_id } | ConvertTo-Json | Out-File $script:ConfigFile -Encoding UTF8
        return $true
    }
    catch {
        Write-Err "Failed to register agent: $_"
        return $false
    }
}

# ============================================================================
# Asset Discovery
# ============================================================================
function Get-FullSystemInfo {
    <#
    .SYNOPSIS
        Collects comprehensive system information for discovery
    #>
    $osInfo = Get-OSInfo
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    $disk = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue
    $memory = Get-CimInstance -ClassName Win32_PhysicalMemory -ErrorAction SilentlyContinue

    return @{
        cpu = $cpu.Name
        memory_gb = [math]::Round(($memory | Measure-Object -Property Capacity -Sum).Sum / 1GB, 2)
        disk_total_gb = [math]::Round($disk.Size / 1GB, 2)
        disk_free_gb = [math]::Round($disk.FreeSpace / 1GB, 2)
        manufacturer = $cs.Manufacturer
        model = $cs.Model
        serial = (Get-CimInstance -ClassName Win32_BIOS -ErrorAction SilentlyContinue).SerialNumber
    }
}

function Get-NetworkInterfaces {
    <#
    .SYNOPSIS
        Gets network interface information
    #>
    $interfaces = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4Address }
    $result = @{
        ip_addresses = @()
        mac_addresses = @()
        default_gateway = ""
        dns_servers = @()
    }

    foreach ($iface in $interfaces) {
        if ($iface.IPv4Address) {
            $result.ip_addresses += $iface.IPv4Address.IPAddress
        }
        if ($iface.IPv4DefaultGateway) {
            $result.default_gateway = $iface.IPv4DefaultGateway.NextHop
        }

        # Get MAC address
        $adapter = Get-NetAdapter -InterfaceIndex $iface.InterfaceIndex -ErrorAction SilentlyContinue
        if ($adapter -and $adapter.MacAddress) {
            $result.mac_addresses += $adapter.MacAddress
        }
    }

    # DNS servers
    $dns = Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
           Where-Object { $_.ServerAddresses } | Select-Object -First 1
    if ($dns) {
        $result.dns_servers = $dns.ServerAddresses
    }

    return $result
}

function Get-SecurityStatus {
    <#
    .SYNOPSIS
        Gets security-related status information
    #>
    $security = @{
        firewall_enabled = $false
        antivirus_enabled = $false
        antivirus_name = ""
        disk_encrypted = $false
        secure_boot = $false
        tpm_version = $null
    }

    # Windows Firewall
    try {
        $fwProfile = Get-NetFirewallProfile -ErrorAction SilentlyContinue
        $security.firewall_enabled = ($fwProfile | Where-Object { $_.Enabled }).Count -gt 0
    } catch {}

    # Antivirus (Defender or other)
    try {
        $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($defender) {
            $security.antivirus_enabled = $defender.RealTimeProtectionEnabled
            $security.antivirus_name = "Windows Defender"
        }
    } catch {}

    # BitLocker
    try {
        $bitlocker = Get-BitLockerVolume -MountPoint "C:" -ErrorAction SilentlyContinue
        $security.disk_encrypted = $bitlocker -and $bitlocker.ProtectionStatus -eq 'On'
    } catch {}

    # Secure Boot
    try {
        $security.secure_boot = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
    } catch {}

    # TPM
    try {
        $tpm = Get-Tpm -ErrorAction SilentlyContinue
        if ($tpm -and $tpm.TpmPresent) {
            $security.tpm_version = $tpm.ManufacturerVersion
        }
    } catch {}

    return $security
}

function Get-InstalledPackages {
    <#
    .SYNOPSIS
        Gets list of installed packages/applications with version info
    #>
    $packages = @()

    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    $regPaths | ForEach-Object {
        Get-ItemProperty $_ -ErrorAction SilentlyContinue
    } | Where-Object { $_.DisplayName } | ForEach-Object {
        $packages += @{
            name = $_.DisplayName
            version = $_.DisplayVersion
            publisher = $_.Publisher
        }
    }

    return $packages | Sort-Object -Property name -Unique
}

function Get-RunningServices {
    <#
    .SYNOPSIS
        Gets list of running services
    #>
    $services = Get-Service -ErrorAction SilentlyContinue |
                Where-Object { $_.Status -eq 'Running' } |
                ForEach-Object {
                    @{
                        name = $_.DisplayName
                        service_name = $_.Name
                        status = $_.Status.ToString()
                        startup = $_.StartType.ToString()
                    }
                }
    return $services
}

function Find-NetworkNeighbors {
    <#
    .SYNOPSIS
        Discovers neighboring hosts on the network
    #>
    Write-Info "Discovering network neighbors..."
    $neighbors = @()

    # Get ARP cache
    try {
        $arpEntries = Get-NetNeighbor -State Reachable, Permanent -ErrorAction SilentlyContinue |
                      Where-Object { $_.IPAddress -notmatch '^(fe80|::1|224\.|239\.|255\.255\.255\.255)' }

        foreach ($entry in $arpEntries) {
            $hostInfo = @{
                ip = $entry.IPAddress
                mac = $entry.LinkLayerAddress
                hostname = ""
                type = "unknown"
                ports = @()
            }

            # Try DNS lookup
            try {
                $dns = [System.Net.Dns]::GetHostEntry($entry.IPAddress)
                $hostInfo.hostname = $dns.HostName
            } catch {}

            # Quick port scan for common ports (with short timeout)
            $commonPorts = @(22, 80, 443, 445, 3389, 5985)
            foreach ($port in $commonPorts) {
                try {
                    $tcp = New-Object System.Net.Sockets.TcpClient
                    $connection = $tcp.BeginConnect($entry.IPAddress, $port, $null, $null)
                    $wait = $connection.AsyncWaitHandle.WaitOne(100, $false)
                    if ($wait -and $tcp.Connected) {
                        $hostInfo.ports += $port
                    }
                    $tcp.Close()
                } catch {}
            }

            # Guess type based on ports
            if ($hostInfo.ports -contains 3389 -or $hostInfo.ports -contains 5985) {
                $hostInfo.type = "windows"
            } elseif ($hostInfo.ports -contains 22) {
                $hostInfo.type = "linux"
            } elseif ($hostInfo.ports -contains 80 -or $hostInfo.ports -contains 443) {
                $hostInfo.type = "webserver"
            }

            $neighbors += $hostInfo
        }
    } catch {
        Write-Warn "Could not enumerate network neighbors: $_"
    }

    Write-Ok "Found $($neighbors.Count) network neighbors"
    return $neighbors
}

function Send-Discovery {
    <#
    .SYNOPSIS
        Performs full discovery and uploads to server
    #>
    if (-not $script:ServerUrl) {
        Write-Err "No server URL configured. Use -ServerUrl parameter or set AUDIT_SERVER_URL"
        return $false
    }

    Write-Info "Performing asset discovery..."

    # Collect all discovery data
    $osInfo = Get-OSInfo
    $networkInfo = Get-NetworkInterfaces
    $sysInfo = Get-FullSystemInfo
    $security = Get-SecurityStatus
    $packages = Get-InstalledPackages
    $services = Get-RunningServices

    Write-Info "Scanning network neighbors..."
    $neighbors = Find-NetworkNeighbors

    # Build discovery payload
    $discovery = @{
        hostname = $osInfo.Hostname
        os_type = if ($osInfo.IsServer) { "windows-server" } else { "windows-desktop" }
        os_name = $osInfo.Name
        os_version = $osInfo.Version
        architecture = $osInfo.Architecture
        domain = $osInfo.Domain
        ip_addresses = $networkInfo.ip_addresses
        mac_addresses = $networkInfo.mac_addresses
        system_info = $sysInfo
        packages = $packages
        services = $services
        security = $security
        discovered_hosts = $neighbors
        network_info = @{
            default_gateway = $networkInfo.default_gateway
            dns_servers = $networkInfo.dns_servers
            domain_joined = ($osInfo.Domain -and $osInfo.Domain -ne $osInfo.Hostname)
        }
    }

    # Upload to server
    Write-Info "Uploading discovery data to server..."
    $body = $discovery | ConvertTo-Json -Depth 10
    $headers = @{ 'Content-Type' = 'application/json' }
    if ($script:ApiKey) {
        $headers['X-API-Key'] = $script:ApiKey
    }

    try {
        $url = "$($script:ServerUrl)/api/agent/discovery"
        $response = Invoke-ThrottledWebRequest -Uri $url -Headers $headers -Method Post -Body $body -Direction Upload
        Write-Ok "Discovery uploaded successfully"
        if ($response.new_hosts_discovered -gt 0) {
            Write-Info "$($response.new_hosts_discovered) new hosts discovered on network"
        }
        return $true
    }
    catch {
        Write-Err "Failed to upload discovery: $_"

        # Save locally for later upload
        $discoveryDir = Join-Path $script:ResultsDir "discovery"
        if (-not (Test-Path $discoveryDir)) {
            New-Item -ItemType Directory -Path $discoveryDir -Force | Out-Null
        }
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $discoveryFile = Join-Path $discoveryDir "discovery_$timestamp.json"
        $body | Out-File $discoveryFile -Encoding UTF8
        Write-Info "Discovery saved locally: $discoveryFile"
        return $false
    }
}

# Lightweight mode intentionally excludes central command-orchestration
# functions (poll/daemon/sync). Managed orchestration is handled by
# fleet-agent.ps1.

# ============================================================================
# Interactive Menu
# ============================================================================
function Show-Menu {
    Clear-Host
    $osInfo = Get-OSInfo

    Write-Host ""
    Write-Host "ΓòöΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòù" -ForegroundColor Cyan
    Write-Host "Γòæ     Lightweight Security Audit Agent for Windows v$($script:AgentVersion)       Γòæ" -ForegroundColor Cyan
    Write-Host "ΓòÜΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓòÉΓò¥" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Computer: " -NoNewline; Write-Host $osInfo.Hostname -ForegroundColor Yellow
    Write-Host "  OS:       " -NoNewline; Write-Host $osInfo.Name -ForegroundColor Yellow
    Write-Host "  Type:     " -NoNewline; Write-Host $(if ($osInfo.IsServer) { "Server" } else { "Desktop" }) -ForegroundColor Yellow
    Write-Host "  Software: " -NoNewline; Write-Host "$($script:DetectedSoftware.Count) components" -ForegroundColor Green
    Write-Host "  Audits:   " -NoNewline; Write-Host "$($script:SuggestedAudits.Count) suggested" -ForegroundColor Green
    Write-Host ""
    Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  1) Show detected software"
    Write-Host "  2) Show suggested audits"
    Write-Host "  3) Run a specific audit"
    Write-Host "  4) Run all platform audits"
    Write-Host "  5) Run all suggested audits"
    Write-Host "  6) View local results"
    Write-Host "  7) Rescan software"
    Write-Host "  8) Configure server reporting"
    Write-Host "  9) Upload results to server"
    Write-Host "  D) Run asset discovery (scan network)"
    Write-Host "  Q) Quit"
    Write-Host ""
}

function Show-DetectedSoftware {
    Write-Host ""
    Write-Host "Detected Software:" -ForegroundColor Cyan
    Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray
    foreach ($key in $script:DetectedSoftware.Keys | Sort-Object) {
        Write-Host "  Γ£ô " -ForegroundColor Green -NoNewline
        Write-Host "$key" -ForegroundColor White -NoNewline
        Write-Host " - $($script:DetectedSoftware[$key])" -ForegroundColor Gray
    }
    Write-Host ""
}

function Show-SuggestedAudits {
    Write-Host ""
    Write-Host "Suggested Audits:" -ForegroundColor Cyan
    Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray
    $i = 1
    foreach ($key in $script:SuggestedAudits.Keys | Sort-Object) {
        Write-Host "  [$i] " -ForegroundColor Yellow -NoNewline
        Write-Host "$key" -ForegroundColor White
        Write-Host "      $($script:SuggestedAudits[$key])" -ForegroundColor Gray
        $i++
    }
    Write-Host ""
}

function Show-LocalResults {
    Write-Host ""
    Write-Host "Local Audit Results:" -ForegroundColor Cyan
    Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray

    if (-not (Test-Path $script:ResultsDir)) {
        Write-Host "  No results found" -ForegroundColor Gray
        return
    }

    $results = Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 20

    if ($results.Count -eq 0) {
        Write-Host "  No results found" -ForegroundColor Gray
        return
    }

    foreach ($file in $results) {
        $content = Get-Content $file.FullName -Raw | ConvertFrom-Json -ErrorAction SilentlyContinue
        if ($content) {
            Write-Host "  " -NoNewline
            Write-Host $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm") -ForegroundColor Gray -NoNewline
            Write-Host " | " -NoNewline
            Write-Host "$($content.summary.passed)P" -ForegroundColor Green -NoNewline
            Write-Host "/$($content.summary.failed)F" -ForegroundColor Red -NoNewline
            Write-Host "/$($content.summary.warnings)W" -ForegroundColor Yellow -NoNewline
            Write-Host " | $($content.audit)" -ForegroundColor White
        }
    }
    Write-Host ""
}

function Set-ServerConfiguration {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    if (-not $PSCmdlet.ShouldProcess('server configuration', 'Configure server URL, API key, and optional registration')) {
        return
    }

    Write-Host ""
    Write-Host "Server Configuration:" -ForegroundColor Cyan
    Write-Host "ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ" -ForegroundColor DarkGray
    Write-Host "  Current URL: " -NoNewline
    if ($script:ServerUrl) {
        Write-Host $script:ServerUrl -ForegroundColor Green
    } else {
        Write-Host "(not configured)" -ForegroundColor Gray
    }
    Write-Host ""

    $newUrl = Read-Host "  Enter server URL (blank to keep)"
    if ($newUrl) {
        try {
            Set-ValidatedServerUrl -Url $newUrl
            $env:AUDIT_SERVER_URL = $newUrl
        }
        catch {
            Write-Err $_
        }
    }

    $newKey = Read-Host "  Enter API key (blank to keep)"
    if ($newKey) {
        $script:ApiKey = $newKey
        $env:AUDIT_API_KEY = $newKey
    }

    if ($script:ServerUrl) {
        $register = Read-Host "  Register agent with server? (y/n)"
        if ($register -eq 'y') {
            Register-Agent
        }
    }
}

function Start-InteractiveMode {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    if (-not $PSCmdlet.ShouldProcess('interactive menu', 'Start interactive agent mode')) {
        return
    }

    # Initial scan
    Get-OSInfo | Out-Null
    Find-InstalledSoftware | Out-Null
    Get-SuggestedAudits | Out-Null

    while ($true) {
        Show-Menu
        $choice = Read-Host "Select option"

        switch ($choice.ToLower()) {
            '1' { Show-DetectedSoftware; Read-Host "Press Enter to continue" }
            '2' { Show-SuggestedAudits; Read-Host "Press Enter to continue" }
            '3' {
                Show-SuggestedAudits
                $auditNum = Read-Host "Enter audit number or path"
                $keys = @($script:SuggestedAudits.Keys | Sort-Object)
                if ($auditNum -match '^\d+$' -and [int]$auditNum -le $keys.Count) {
                    $audit = $keys[[int]$auditNum - 1]
                } else {
                    $audit = $auditNum
                }
                Invoke-Audit -AuditPath $audit
                Read-Host "Press Enter to continue"
            }
            '4' {
                $script:SuggestedAudits.Keys | Where-Object { $_ -like 'platform/*' } | ForEach-Object {
                    Invoke-Audit -AuditPath $_
                }
                Read-Host "Press Enter to continue"
            }
            '5' { Invoke-AllSuggestedAudits; Read-Host "Press Enter to continue" }
            '6' { Show-LocalResults; Read-Host "Press Enter to continue" }
            '7' {
                Find-InstalledSoftware | Out-Null
                Get-SuggestedAudits | Out-Null
                Write-Ok "Rescan complete"
                Read-Host "Press Enter to continue"
            }
            '8' { Set-ServerConfiguration; Read-Host "Press Enter to continue" }
            '9' { Send-Results -All; Read-Host "Press Enter to continue" }
            'd' {
                if (-not $script:ServerUrl) {
                    Write-Warn "Server not configured. Configure server first (option 8) or run in CLI mode."
                } else {
                    Send-Discovery
                }
                Read-Host "Press Enter to continue"
            }
            'q' { return }
            default { Write-Warn "Invalid option" }
        }
    }
}

# ============================================================================
# Main Entry Point
# ============================================================================
function Main {
    # Load config if exists
    if (Test-Path $script:ConfigFile) {
        $config = Get-Content $script:ConfigFile -Raw | ConvertFrom-Json
        if ($config.server_url -and -not $script:ServerUrl) {
            try {
                Set-ValidatedServerUrl -Url $config.server_url
            }
            catch {
                if ($script:DebugUrlPolicy) {
                    Write-Err $_
                }
                else {
                    Write-Err "Server URL rejected by destination controls. Please verify the scheme/host and allowed domains."
                }
                exit 1
            }
        }
        if ($config.api_key -and -not $script:ApiKey) {
            $script:ApiKey = $config.api_key
        }
    }

    if ($ServerUrl) {
        try {
            Set-ValidatedServerUrl -Url $ServerUrl
        }
        catch {
            if ($script:DebugUrlPolicy) {
                Write-Err $_
            }
            else {
                Write-Err "Server URL rejected by destination controls. Please verify the scheme/host and allowed domains."
            }
            exit 1
        }
    }

    # Always get OS info
    Get-OSInfo | Out-Null

    switch ($Mode) {
        'interactive' {
            Start-InteractiveMode
        }
        'scan' {
            Find-InstalledSoftware | Out-Null
            Show-DetectedSoftware
        }
        'suggest' {
            Find-InstalledSoftware | Out-Null
            Get-SuggestedAudits | Out-Null
            Show-SuggestedAudits
        }
        'run' {
            if (-not $Audit) {
                Write-Err "Please specify an audit with -Audit parameter"
                exit 1
            }
            Find-InstalledSoftware | Out-Null
            if (-not (Invoke-Audit -AuditPath $Audit)) {
                exit 1
            }
        }
        'runall' {
            Find-InstalledSoftware | Out-Null
            Get-SuggestedAudits | Out-Null
            Invoke-AllSuggestedAudits
        }
        'upload' {
            if (-not $ServerUrl) {
                Write-Err "Please specify server URL with -ServerUrl parameter"
                exit 1
            }
            Set-ValidatedServerUrl -Url $ServerUrl
            $script:ApiKey = $ApiKey
            if (-not (Send-Results -All)) {
                exit 1
            }
        }
        'discover' {
            if (-not $ServerUrl) {
                Write-Err "Please specify server URL with -ServerUrl parameter"
                exit 1
            }
            Set-ValidatedServerUrl -Url $ServerUrl
            $script:ApiKey = $ApiKey
            if (-not (Send-Discovery)) {
                exit 1
            }
        }
        'status' {
            Find-InstalledSoftware | Out-Null
            Get-SuggestedAudits | Out-Null
            Write-Host ""
            Write-Host "Agent Status:" -ForegroundColor Cyan
            Write-Host "  Version:  $script:AgentVersion"
            Write-Host "  Hostname: $($script:OSInfo.Hostname)"
            Write-Host "  OS:       $($script:OSInfo.Name)"
            Write-Host "  Type:     $(if ($script:OSInfo.IsServer) { 'Server' } else { 'Desktop' })"
            Write-Host "  Software: $($script:DetectedSoftware.Count) detected"
            Write-Host "  Audits:   $($script:SuggestedAudits.Count) suggested"
            Write-Host "  Server:   $(if ($script:ServerUrl) { $script:ServerUrl } else { '(not configured)' })"
            Write-Host "  Agent ID: $(if ($AgentId) { $AgentId } else { '(not configured)' })"

            $pending = (Get-ChildItem -Path $script:ResultsDir -Filter "*.json" -ErrorAction SilentlyContinue).Count
            Write-Host "  Pending:  $pending results to upload"
        }
        'poll' {
            Write-Err "The standalone agent no longer supports command polling. Use fleet-agent.ps1 for centrally orchestrated execution."
            exit 2
        }
        'daemon' {
            Write-Err "The standalone agent no longer supports daemon polling mode. Use fleet-agent.ps1 for centrally orchestrated execution."
            exit 2
        }
        'sync' {
            Write-Err "The standalone agent no longer supports audit sync from the server. Use fleet-agent.ps1 for centrally orchestrated execution."
            exit 2
        }
        'self-update' {
            if (-not $ServerUrl) {
                Write-Err "Please specify server URL with -ServerUrl parameter"
                exit 1
            }
            Set-ValidatedServerUrl -Url $ServerUrl
            $script:ApiKey = $ApiKey
            if (-not (Invoke-SelfUpdate)) {
                exit 1
            }
        }
    }
}

# Run
Main
