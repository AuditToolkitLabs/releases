#!/usr/bin/env bash
# Lightweight Security Audit Agent
# Scans for installed software, suggests audits, runs them on demand
set -euo pipefail

AGENT_VERSION="6.2.1"
AGENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configuration
SERVER_URL="${SERVER_URL:-}"
REPORT_LOCAL="${REPORT_LOCAL:-true}"
REPORT_REMOTE="${REPORT_REMOTE:-false}"
CORE_ATTESTATION_REQUIRED="${AUDIT_CORE_ATTESTATION_REQUIRED:-true}"
TLS_SKIP_VERIFY="${AUDIT_TLS_SKIP_VERIFY:-false}"
AGENT_ENVIRONMENT="${AUDIT_ENVIRONMENT:-production}"
ALLOW_INSECURE_TLS_IN_NONPROD="${AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD:-false}"
MANAGED_REQUIRE_HTTPS="${AUDIT_MANAGED_REQUIRE_HTTPS:-true}"
MANAGED_ALLOW_PRIVATE_HOSTS="${AUDIT_MANAGED_ALLOW_PRIVATE_HOSTS:-true}"
MANAGED_ALLOWED_SERVER_DOMAINS="${AUDIT_MANAGED_ALLOWED_SERVER_DOMAINS:-}"
MANAGED_BLOCKED_SERVER_KEYWORDS="${AUDIT_MANAGED_BLOCKED_SERVER_KEYWORDS:-wazuh,splunk,elastic,datadog,newrelic}"
DEBUG_URL_POLICY="${AUDIT_DEBUG_URL_POLICY:-false}"
MANAGED_REQUIRE_REQUEST_SIGNATURES="${AUDIT_MANAGED_REQUIRE_REQUEST_SIGNATURES:-false}"
MANAGED_REQUEST_SIGNING_KEY="${AUDIT_MANAGED_REQUEST_SIGNING_KEY:-}"
MANAGED_REQUEST_SIGNATURE_USE_ECDSA="${AUDIT_MANAGED_REQUEST_SIGNATURE_USE_ECDSA:-false}"
MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE="${AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE:-}"
RESULTS_DIR="${AGENT_DIR}/results"
SILENT_MODE="${SILENT_MODE:-false}"
LOG_FILE="${AGENT_DIR}/logs/agent.log"

# Parse early flags (before main parsing)
for arg in "$@"; do
    case "$arg" in
        --silent|-s) SILENT_MODE="true"; export NO_COLOR=1 ;;
        --log=*) LOG_FILE="${arg#*=}" ;;
    esac
done

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true

# Silent mode: redirect all output to log file
if [[ "$SILENT_MODE" == "true" ]]; then
    exec >> "$LOG_FILE" 2>&1
fi

# Colors
if [[ -t 1 ]] && [[ -z "${NO_COLOR:-}" ]]; then
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'
    BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
else
    RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; BOLD=''; NC=''
fi

# Logging
log_info()  { echo -e "${BLUE}[INFO]${NC} $*"; }
log_ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

log_url_policy_error() {
    local reason="$1"
    if [[ "${DEBUG_URL_POLICY,,}" == "true" ]]; then
        log_error "Server URL validation failed: ${reason}"
    else
        log_error "Server URL rejected by destination controls. Please verify the scheme/host and allowed domains."
    fi
}

is_non_production_environment() {
    case "${AGENT_ENVIRONMENT,,}" in
        dev|development|test|testing|beta|staging)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

to_lower() {
    echo "$1" | tr '[:upper:]' '[:lower:]'
}

extract_url_parts() {
    local url="$1"
    local scheme host

    scheme=$(echo "$url" | sed -E 's|^([a-zA-Z][a-zA-Z0-9+.-]*)://.*|\1|')
    host=$(echo "$url" | sed -E 's|^[a-zA-Z][a-zA-Z0-9+.-]*://([^/:]+).*|\1|')

    if [[ -z "$scheme" || -z "$host" || "$scheme" == "$url" || "$host" == "$url" ]]; then
        return 1
    fi

    echo "$(to_lower "$scheme")|$(to_lower "$host")"
}

is_private_or_local_host() {
    local host="$1"

    [[ -z "$host" ]] && return 0
    [[ "$host" == "localhost" || "$host" == "127.0.0.1" || "$host" == "::1" ]] && return 0

    if [[ "$host" =~ ^10\. ]] || [[ "$host" =~ ^192\.168\. ]]; then
        return 0
    fi

    if [[ "$host" =~ ^172\.([1][6-9]|2[0-9]|3[0-1])\. ]]; then
        return 0
    fi

    return 1
}

host_matches_allowed_domains() {
    local host="$1"
    local allowed_csv="$2"

    [[ -z "$allowed_csv" ]] && return 0

    local IFS=','
    local domain
    for domain in $allowed_csv; do
        domain=$(to_lower "${domain//[[:space:]]/}")
        [[ -z "$domain" ]] && continue
        if [[ "$host" == "$domain" || "$host" == *".$domain" ]]; then
            return 0
        fi
    done

    return 1
}

validate_server_url() {
    local url="$1"

    if [[ -z "$url" ]]; then
        log_url_policy_error "URL is empty"
        return 1
    fi

    local parsed scheme host
    parsed=$(extract_url_parts "$url") || {
        log_url_policy_error "invalid URL format"
        return 1
    }

    scheme="${parsed%%|*}"
    host="${parsed##*|}"

    if [[ "$MANAGED_REQUIRE_HTTPS" == "true" && "$scheme" != "https" ]]; then
        log_url_policy_error "HTTPS is required"
        return 1
    fi

    local blocked
    local IFS=','
    for blocked in $MANAGED_BLOCKED_SERVER_KEYWORDS; do
        blocked=$(to_lower "${blocked//[[:space:]]/}")
        [[ -z "$blocked" ]] && continue
        if [[ "$host" == *"$blocked"* ]]; then
            log_url_policy_error "blocked destination keyword '$blocked'"
            return 1
        fi
    done

    if [[ "$MANAGED_ALLOW_PRIVATE_HOSTS" != "true" ]] && is_private_or_local_host "$host"; then
        log_url_policy_error "private/localhost destinations are not allowed"
        return 1
    fi

    if ! host_matches_allowed_domains "$host" "$MANAGED_ALLOWED_SERVER_DOMAINS"; then
        log_url_policy_error "destination not in allowed domains"
        return 1
    fi

    return 0
}

# ============================================================================
# OS Detection
# ============================================================================
detect_os() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck source=/dev/null
        . /etc/os-release
        OS_ID="${ID:-unknown}"
        OS_VERSION="${VERSION_ID:-}"
        OS_NAME="${PRETTY_NAME:-$ID}"
    elif [[ -f /etc/redhat-release ]]; then
        OS_ID="rhel"
        OS_NAME="$(cat /etc/redhat-release)"
    else
        OS_ID="unknown"
        OS_NAME="Unknown Linux"
    fi
    export OS_ID OS_VERSION OS_NAME
}

# ============================================================================
# Software Detection
# ============================================================================
declare -A DETECTED_SOFTWARE
declare -A SUGGESTED_AUDITS

detect_software() {
    log_info "Scanning installed software..."
    DETECTED_SOFTWARE=()

    # Package managers
    if command -v apt >/dev/null 2>&1; then
        DETECTED_SOFTWARE[apt]="Debian-based package manager"
    fi
    if command -v dnf >/dev/null 2>&1 || command -v yum >/dev/null 2>&1; then
        DETECTED_SOFTWARE[rpm]="RPM-based package manager"
    fi
    if command -v apk >/dev/null 2>&1; then
        DETECTED_SOFTWARE[apk]="Alpine package manager"
    fi

    # Web servers
    if command -v nginx >/dev/null 2>&1; then
        DETECTED_SOFTWARE[nginx]="Nginx web server"
    fi
    if command -v apache2 >/dev/null 2>&1 || command -v httpd >/dev/null 2>&1; then
        DETECTED_SOFTWARE[apache]="Apache web server"
    fi

    # Databases
    if command -v mysql >/dev/null 2>&1 || command -v mariadb >/dev/null 2>&1; then
        DETECTED_SOFTWARE[mysql]="MySQL/MariaDB database"
    fi
    if command -v psql >/dev/null 2>&1; then
        DETECTED_SOFTWARE[postgresql]="PostgreSQL database"
    fi
    if command -v mongod >/dev/null 2>&1 || command -v mongo >/dev/null 2>&1; then
        DETECTED_SOFTWARE[mongodb]="MongoDB database"
    fi
    if command -v redis-cli >/dev/null 2>&1 || command -v redis-server >/dev/null 2>&1; then
        DETECTED_SOFTWARE[redis]="Redis cache/database"
    fi

    # Containers
    if command -v docker >/dev/null 2>&1; then
        DETECTED_SOFTWARE[docker]="Docker container runtime"
    fi
    if command -v podman >/dev/null 2>&1; then
        DETECTED_SOFTWARE[podman]="Podman container runtime"
    fi
    if command -v kubectl >/dev/null 2>&1; then
        DETECTED_SOFTWARE[kubernetes]="Kubernetes CLI"
    fi

    # Security tools
    if command -v fail2ban-client >/dev/null 2>&1; then
        DETECTED_SOFTWARE[fail2ban]="Fail2ban IDS/IPS"
    fi
    if command -v ufw >/dev/null 2>&1; then
        DETECTED_SOFTWARE[ufw]="UFW firewall"
    fi
    if command -v firewall-cmd >/dev/null 2>&1; then
        DETECTED_SOFTWARE[firewalld]="FirewallD"
    fi

    # SSH/Auth
    if [[ -f /etc/ssh/sshd_config ]] || pgrep -x sshd >/dev/null 2>&1; then
        DETECTED_SOFTWARE[ssh]="OpenSSH server"
    fi

    # Service managers
    if command -v systemctl >/dev/null 2>&1; then
        DETECTED_SOFTWARE[systemd]="Systemd init system"
    fi
    if [[ -x /sbin/openrc ]] || command -v rc-service >/dev/null 2>&1; then
        DETECTED_SOFTWARE[openrc]="OpenRC init system"
    fi

    # PHP
    if command -v php >/dev/null 2>&1; then
        DETECTED_SOFTWARE[php]="PHP runtime"
    fi

    # Node.js
    if command -v node >/dev/null 2>&1 || command -v nodejs >/dev/null 2>&1; then
        DETECTED_SOFTWARE[nodejs]="Node.js runtime"
    fi

    # Python
    if command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1; then
        DETECTED_SOFTWARE[python]="Python runtime"
    fi

    log_ok "Detected ${#DETECTED_SOFTWARE[@]} software components"
}

# ============================================================================
# Audit Suggestions
# ============================================================================
suggest_audits() {
    log_info "Generating audit suggestions..."
    SUGGESTED_AUDITS=()

    # Platform audits (always suggested)
    SUGGESTED_AUDITS[platform/baseline/updates]="Check for pending system updates"
    SUGGESTED_AUDITS[platform/baseline/users]="Audit user accounts and privileges"
    SUGGESTED_AUDITS[platform/baseline/permissions]="Check file permissions"

    # SSH
    if [[ -v DETECTED_SOFTWARE[ssh] ]]; then
        SUGGESTED_AUDITS[platform/baseline/ssh]="SSH configuration security"
    fi

    # Web servers
    if [[ -v DETECTED_SOFTWARE[nginx] ]]; then
        SUGGESTED_AUDITS[web/nginx/nginx-security]="Nginx security configuration"
    fi
    if [[ -v DETECTED_SOFTWARE[apache] ]]; then
        SUGGESTED_AUDITS[web/apache/apache-security]="Apache security configuration"
    fi

    # Databases
    if [[ -v DETECTED_SOFTWARE[mysql] ]]; then
        SUGGESTED_AUDITS[data/mysql/mysql-security]="MySQL/MariaDB security audit"
    fi
    if [[ -v DETECTED_SOFTWARE[postgresql] ]]; then
        SUGGESTED_AUDITS[data/postgres/postgres-security]="PostgreSQL security audit"
    fi
    if [[ -v DETECTED_SOFTWARE[mongodb] ]]; then
        SUGGESTED_AUDITS[data/mongo/mongo-security]="MongoDB security audit"
    fi
    if [[ -v DETECTED_SOFTWARE[redis] ]]; then
        SUGGESTED_AUDITS[data/redis/redis-security]="Redis security audit"
    fi

    # Containers
    if [[ -v DETECTED_SOFTWARE[docker] ]]; then
        SUGGESTED_AUDITS[apps/docker/docker-security]="Docker security audit"
    fi
    if [[ -v DETECTED_SOFTWARE[kubernetes] ]]; then
        SUGGESTED_AUDITS[apps/kubernetes/k8s-security]="Kubernetes security audit"
    fi

    # Network/Firewall
    if [[ -v DETECTED_SOFTWARE[ufw] ]] || [[ -v DETECTED_SOFTWARE[firewalld] ]]; then
        SUGGESTED_AUDITS[network/firewall/firewall-rules]="Firewall configuration audit"
    fi

    # PHP
    if [[ -v DETECTED_SOFTWARE[php] ]]; then
        SUGGESTED_AUDITS[web/php/php-security]="PHP security configuration"
    fi

    log_ok "Generated ${#SUGGESTED_AUDITS[@]} audit suggestions"
}

# ============================================================================
# Audit Execution
# ============================================================================
run_audit() {
    local audit_path="$1"
    local audit_script="${AGENT_DIR}/audits/${audit_path}.sh"

    if [[ ! -f "$audit_script" ]]; then
        log_warn "Audit not found: $audit_path"
        log_info "You may need to download this audit from the server"
        return 1
    fi

    log_info "Running audit: $audit_path"
    mkdir -p "$RESULTS_DIR"

    local result_file
    result_file="${RESULTS_DIR}/$(echo "$audit_path" | tr '/' '_')_$(date +%Y%m%d_%H%M%S).log"
    local start_epoch_ms end_epoch_ms duration_ms
    start_epoch_ms=$(date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)")

    local output
    output=$(bash "$audit_script" 2>&1)
    local audit_exit_code=$?
    echo "$output" > "$result_file"
    echo "$output"
    if (( audit_exit_code == 0 )); then
        log_ok "Audit completed: $result_file"
    else
        log_warn "Audit completed with warnings or errors"
    fi

    end_epoch_ms=$(date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)")
    duration_ms=$((end_epoch_ms - start_epoch_ms))
    if (( duration_ms < 0 )); then
        duration_ms=0
    fi

    # Report if configured
    if [[ "$REPORT_REMOTE" == "true" ]] && [[ -n "$SERVER_URL" ]]; then
        send_results "$result_file" "$audit_path" "$duration_ms"
    fi

    return 0
}

run_audit_group() {
    local group="$1"  # platform, web, data, network, etc.
    local count=0

    log_info "Running all ${group} audits..."

    for audit in "${!SUGGESTED_AUDITS[@]}"; do
        if [[ "$audit" == "${group}/"* ]]; then
            if run_audit "$audit"; then
                ((count++))
            fi
        fi
    done

    log_ok "Completed $count ${group} audits"
}

run_all_suggested() {
    log_info "Running all suggested audits..."
    local count=0

    for audit in "${!SUGGESTED_AUDITS[@]}"; do
        if run_audit "$audit"; then
            ((count++))
        fi
    done

    log_ok "Completed $count audits"
}

run_scripts_from_file() {
    # Run specific scripts listed in a file (one path per line)
    local scripts_file="$1"
    local count=0

    if [[ ! -f "$scripts_file" ]]; then
        log_error "Scripts file not found: $scripts_file"
        return 1
    fi

    log_info "Running scripts from: $scripts_file"

    while IFS= read -r script_path || [[ -n "$script_path" ]]; do
        # Skip empty lines and comments
        [[ -z "$script_path" || "$script_path" == \#* ]] && continue

        # Trim whitespace
        script_path="$(echo "$script_path" | xargs)"

        if [[ -f "$script_path" ]]; then
            log_info "Running: $script_path"
            if bash "$script_path"; then
                ((count++))
            else
                log_warn "Script returned non-zero: $script_path"
            fi
        elif [[ -f "${AGENT_DIR}/${script_path}" ]]; then
            log_info "Running: ${AGENT_DIR}/${script_path}"
            if bash "${AGENT_DIR}/${script_path}"; then
                ((count++))
            else
                log_warn "Script returned non-zero: $script_path"
            fi
        else
            log_warn "Script not found: $script_path"
        fi
    done < "$scripts_file"

    log_ok "Completed $count scripts from file"
}

# ============================================================================
# Asset Discovery
# ============================================================================
collect_system_info() {
    local cpu mem_total disk_total disk_free

    cpu=$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | xargs || echo "Unknown")
    mem_total=$(awk '/MemTotal/ {printf "%.2f", $2/1024/1024}' /proc/meminfo 2>/dev/null || echo "0")
    disk_total=$(df -BG / 2>/dev/null | awk 'NR==2 {gsub("G",""); print $2}' || echo "0")
    disk_free=$(df -BG / 2>/dev/null | awk 'NR==2 {gsub("G",""); print $4}' || echo "0")

    cat << EOF
{
  "cpu": "$cpu",
  "memory_gb": $mem_total,
  "disk_total_gb": $disk_total,
  "disk_free_gb": $disk_free
}
EOF
}

collect_network_info() {
    local ips macs gateway dns_servers

    # Get IP addresses
    ips=$(ip -4 addr show 2>/dev/null | grep -oP 'inet \K[\d.]+' | grep -v '^127\.' | tr '\n' ',' | sed 's/,$//')
    [[ -z "$ips" ]] && ips=$(hostname -I 2>/dev/null | tr ' ' ',' | sed 's/,$//')

    # Get MAC addresses
    macs=$(ip link show 2>/dev/null | grep -oP 'link/ether \K[\da-f:]+' | tr '\n' ',' | sed 's/,$//')

    # Default gateway
    gateway=$(ip route 2>/dev/null | grep '^default' | awk '{print $3}' | head -1)
    [[ -z "$gateway" ]] && gateway=$(route -n 2>/dev/null | grep '^0\.0\.0\.0' | awk '{print $2}' | head -1)

    # DNS servers
    dns_servers=$(grep '^nameserver' /etc/resolv.conf 2>/dev/null | awk '{print $2}' | tr '\n' ',' | sed 's/,$//')

    echo "{\"ip_addresses\": [\"${ips//,/\",\"}\"], \"mac_addresses\": [\"${macs//,/\",\"}\"], \"default_gateway\": \"$gateway\", \"dns_servers\": [\"${dns_servers//,/\",\"}\"]}"
}

collect_security_info() {
    local firewall_enabled antivirus_enabled selinux apparmor disk_encrypted

    # Firewall
    firewall_enabled="false"
    if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
        firewall_enabled="true"
    elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state 2>/dev/null | grep -q "running"; then
        firewall_enabled="true"
    elif iptables -L -n 2>/dev/null | wc -l | grep -q '^[3-9]\|^[0-9][0-9]'; then
        firewall_enabled="true"
    fi

    # Antivirus (clamav, etc)
    antivirus_enabled="false"
    local antivirus_name=""
    if command -v clamscan >/dev/null 2>&1; then
        antivirus_enabled="true"
        antivirus_name="ClamAV"
    fi

    # SELinux
    selinux="disabled"
    if command -v getenforce >/dev/null 2>&1; then
        selinux=$(getenforce 2>/dev/null | tr '[:upper:]' '[:lower:]')
    fi

    # AppArmor
    apparmor="disabled"
    if command -v aa-status >/dev/null 2>&1 && aa-status --enabled 2>/dev/null; then
        apparmor="enabled"
    fi

    # Disk encryption (LUKS)
    disk_encrypted="false"
    if command -v lsblk >/dev/null 2>&1 && lsblk 2>/dev/null | grep -q 'crypt'; then
        disk_encrypted="true"
    fi

    cat << EOF
{
  "firewall_enabled": $firewall_enabled,
  "antivirus_enabled": $antivirus_enabled,
  "antivirus_name": "$antivirus_name",
  "selinux": "$selinux",
  "apparmor": "$apparmor",
  "disk_encrypted": $disk_encrypted
}
EOF
}

collect_packages() {
    local packages=()

    # Detect package manager and list packages
    if command -v dpkg >/dev/null 2>&1; then
        while IFS='|' read -r name version; do
            packages+=("{\"name\": \"$name\", \"version\": \"$version\", \"publisher\": \"\"}")
        done < <(dpkg-query -W -f='${Package}|${Version}\n' 2>/dev/null | head -200)
    elif command -v rpm >/dev/null 2>&1; then
        while IFS='|' read -r name version; do
            packages+=("{\"name\": \"$name\", \"version\": \"$version\", \"publisher\": \"\"}")
        done < <(rpm -qa --qf '%{NAME}|%{VERSION}\n' 2>/dev/null | head -200)
    elif command -v apk >/dev/null 2>&1; then
        while read -r line; do
            local name version
            name="${line%%-[0-9]*}"
            version=$(echo "$line" | grep -oP '\d+[\d.-]+' | head -1)
            packages+=("{\"name\": \"$name\", \"version\": \"$version\", \"publisher\": \"\"}")
        done < <(apk info -v 2>/dev/null | head -200)
    fi

    # Output as JSON array
    local output="["
    local first=true
    for pkg in "${packages[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            output+=","
        fi
        output+="$pkg"
    done
    output+="]"
    echo "$output"
}

collect_services() {
    local services=()

    if command -v systemctl >/dev/null 2>&1; then
        while read -r name state; do
            services+=("{\"name\": \"$name\", \"status\": \"running\", \"startup\": \"$state\"}")
        done < <(systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk '{print $1, $2}' | head -50)
    elif command -v rc-service >/dev/null 2>&1; then
        while read -r name; do
            services+=("{\"name\": \"$name\", \"status\": \"started\", \"startup\": \"default\"}")
        done < <(rc-status 2>/dev/null | grep '\[.*started' | awk '{print $1}' | head -50)
    fi

    # Output as JSON array
    local output="["
    local first=true
    for svc in "${services[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            output+=","
        fi
        output+="$svc"
    done
    output+="]"
    echo "$output"
}

discover_network_neighbors() {
    log_info "Discovering network neighbors..."
    local neighbors=()

    # Get ARP cache
    if command -v ip >/dev/null 2>&1; then
        while read -r ip mac; do
            [[ -z "$ip" ]] && continue
            [[ "$ip" == "fe80"* ]] && continue  # Skip IPv6 link-local

            local hostname=""
            hostname=$(getent hosts "$ip" 2>/dev/null | awk '{print $2}')

            # Quick port scan
            local ports=()
            for port in 22 80 443 3306 5432; do
                if timeout 0.1 bash -c "echo >/dev/tcp/$ip/$port" 2>/dev/null; then
                    ports+=("$port")
                fi
            done

            local port_json
            port_json=$(printf '%s\n' "${ports[@]}" | jq -R . | jq -s . 2>/dev/null || echo "[]")

            local type="unknown"
            if [[ " ${ports[*]} " =~ " 22 " ]]; then
                type="linux"
            elif [[ " ${ports[*]} " =~ " 3389 " ]] || [[ " ${ports[*]} " =~ " 5985 " ]]; then
                type="windows"
            fi

            neighbors+=("{\"ip\": \"$ip\", \"mac\": \"$mac\", \"hostname\": \"$hostname\", \"type\": \"$type\", \"ports\": $port_json}")
        done < <(ip neigh 2>/dev/null | grep -E 'REACHABLE|PERMANENT|STALE' | awk '{print $1, $5}')
    elif command -v arp >/dev/null 2>&1; then
        while read -r ip mac; do
            [[ -z "$ip" ]] && continue
            neighbors+=("{\"ip\": \"$ip\", \"mac\": \"$mac\", \"hostname\": \"\", \"type\": \"unknown\", \"ports\": []}")
        done < <(arp -n 2>/dev/null | tail -n +2 | awk '{print $1, $3}')
    fi

    log_ok "Found ${#neighbors[@]} network neighbors"

    # Output as JSON array
    local output="["
    local first=true
    for neighbor in "${neighbors[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            output+=","
        fi
        output+="$neighbor"
    done
    output+="]"
    echo "$output"
}

send_discovery() {
    if [[ -z "$SERVER_URL" ]]; then
        log_error "No server URL configured. Use --server URL or set SERVER_URL env var"
        return 1
    fi

    log_info "Performing asset discovery..."

    local hostname os_type
    hostname=$(hostname -f 2>/dev/null || hostname)

    # Determine OS type
    os_type="linux"
    if uname -r 2>/dev/null | grep -qi 'microsoft\|wsl'; then
        os_type="wsl"
    fi

    log_info "Collecting system information..."
    local system_info network_info security_info packages services neighbors
    system_info=$(collect_system_info)
    network_info=$(collect_network_info)
    security_info=$(collect_security_info)

    log_info "Collecting installed packages..."
    packages=$(collect_packages)

    log_info "Collecting running services..."
    services=$(collect_services)

    log_info "Scanning network neighbors..."
    neighbors=$(discover_network_neighbors)

    if ! command -v jq >/dev/null 2>&1; then
        log_error "jq is required to send discovery data"
        return 1
    fi

    # Build discovery payload with proper JSON escaping/typing
    local ip_addresses_json mac_addresses_json dns_servers_json
    local system_info_json packages_json services_json security_info_json neighbors_json
    local default_gateway domain_name discovery_json

    ip_addresses_json=$(echo "$network_info" | jq -c '.ip_addresses // []' 2>/dev/null || echo '[]')
    mac_addresses_json=$(echo "$network_info" | jq -c '.mac_addresses // []' 2>/dev/null || echo '[]')
    dns_servers_json=$(echo "$network_info" | jq -c '.dns_servers // []' 2>/dev/null || echo '[]')
    default_gateway=$(echo "$network_info" | jq -r '.default_gateway // ""' 2>/dev/null || echo '')
    domain_name=$(hostname -d 2>/dev/null || echo '')

    system_info_json=$(echo "$system_info" | jq -c '.' 2>/dev/null || echo '{}')
    packages_json=$(echo "$packages" | jq -c '.' 2>/dev/null || echo '[]')
    services_json=$(echo "$services" | jq -c '.' 2>/dev/null || echo '[]')
    security_info_json=$(echo "$security_info" | jq -c '.' 2>/dev/null || echo '{}')
    neighbors_json=$(echo "$neighbors" | jq -c '.' 2>/dev/null || echo '[]')

    discovery_json=$(jq -n \
        --arg hostname "$hostname" \
        --arg os_type "$os_type" \
        --arg os_name "$OS_NAME" \
        --arg os_version "${OS_VERSION:-}" \
        --arg architecture "$(uname -m)" \
        --arg domain "$domain_name" \
        --arg default_gateway "$default_gateway" \
        --argjson ip_addresses "$ip_addresses_json" \
        --argjson mac_addresses "$mac_addresses_json" \
        --argjson system_info "$system_info_json" \
        --argjson packages "$packages_json" \
        --argjson services "$services_json" \
        --argjson security "$security_info_json" \
        --argjson discovered_hosts "$neighbors_json" \
        --argjson dns_servers "$dns_servers_json" \
        '{
          hostname: $hostname,
          os_type: $os_type,
          os_name: $os_name,
          os_version: $os_version,
          architecture: $architecture,
          domain: $domain,
          ip_addresses: $ip_addresses,
          mac_addresses: $mac_addresses,
          system_info: $system_info,
          packages: $packages,
          services: $services,
          security: $security,
          discovered_hosts: $discovered_hosts,
          network_info: {
            default_gateway: $default_gateway,
            dns_servers: $dns_servers,
            domain_joined: false
          }
        }')

    # Upload to server
    log_info "Uploading discovery data to server..."

    if command -v curl >/dev/null 2>&1; then
        local response
        response=$(throttled_curl upload -s -X POST \
            -H "Content-Type: application/json" \
            ${API_KEY:+-H "X-API-Key: $API_KEY"} \
            -d "$discovery_json" \
            "${SERVER_URL}/api/agent/discovery")

        if echo "$response" | jq -e '.success == true' >/dev/null 2>&1; then
            log_ok "Discovery uploaded successfully"
            local new_hosts
            new_hosts=$(echo "$response" | jq -r '.new_hosts_discovered // 0' 2>/dev/null || echo "0")
            if [[ "$new_hosts" -gt 0 ]]; then
                log_info "$new_hosts new hosts discovered on network"
            fi
            return 0
        else
            log_error "Failed to upload discovery: $(echo "$response" | jq -r '.error // .details // "unknown error"' 2>/dev/null || echo "$response")"
        fi
    else
        log_error "curl not available, cannot send discovery data"
    fi

    # Save locally if upload fails
    local discovery_dir="$RESULTS_DIR/discovery"
    mkdir -p "$discovery_dir"
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    echo "$discovery_json" > "$discovery_dir/discovery_$timestamp.json"
    log_info "Discovery saved locally: $discovery_dir/discovery_$timestamp.json"
    return 1
}

# ============================================================================
# Results Reporting
# ============================================================================
request_core_attestation_token() {
    if [[ "${CORE_ATTESTATION_REQUIRED,,}" != "true" ]]; then
        echo ""
        return 0
    fi

    if [[ -z "$SERVER_URL" ]]; then
        log_error "Cannot request core attestation: SERVER_URL is not configured"
        return 1
    fi

    if ! command -v curl >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
        log_error "Cannot request core attestation: curl and jq are required"
        return 1
    fi

    local nonce response token
    nonce="$(date +%s)-$$-$RANDOM"

    response=$(throttled_curl upload -s -X POST \
        -H "Content-Type: application/json" \
        ${API_KEY:+-H "X-API-Key: $API_KEY"} \
        ${AGENT_ID:+-H "X-Agent-ID: $AGENT_ID"} \
        -d "{\"nonce\":\"${nonce}\",\"hostname\":\"$(hostname)\"}" \
        "${SERVER_URL}/api/agent/core-attestation")

    if ! echo "$response" | jq -e '.success == true' >/dev/null 2>&1; then
        log_error "Core attestation failed: $(echo "$response" | jq -r '.error // .details // "unknown error"' 2>/dev/null || echo "unknown error")"
        return 1
    fi

    token=$(echo "$response" | jq -r '.token // empty')
    if [[ -z "$token" ]]; then
        log_error "Core attestation failed: missing token in response"
        return 1
    fi

    echo "$token"
    return 0
}

send_results() {
    local result_file="$1"
    local audit_name="${2:-$(basename "$result_file")}"
    local duration_ms="${3:-0}"

    if [[ -z "$SERVER_URL" ]]; then
        log_warn "No server URL configured, skipping remote report"
        return 1
    fi

    if [[ ! -f "$result_file" ]]; then
        log_error "Result file not found: $result_file"
        return 1
    fi

    if ! command -v jq >/dev/null 2>&1; then
        log_error "jq is required to send results"
        return 1
    fi

    log_info "Sending results to server: $SERVER_URL"

    local attestation_token=""
    if [[ "${CORE_ATTESTATION_REQUIRED,,}" == "true" ]]; then
        attestation_token="$(request_core_attestation_token)" || {
            log_error "Blocking upload: core attestation required"
            return 1
        }
    fi

    local output pass_count warn_count fail_count skip_count total_count checks_json payload response
    output=$(cat "$result_file")
    pass_count=$(grep -c '\[PASS\]' "$result_file" || true)
    warn_count=$(grep -c '\[WARN\]' "$result_file" || true)
    fail_count=$(grep -c '\[FAIL\]' "$result_file" || true)
    skip_count=$(grep -c '\[SKIP\]' "$result_file" || true)

    pass_count="${pass_count:-0}"
    warn_count="${warn_count:-0}"
    fail_count="${fail_count:-0}"
    skip_count="${skip_count:-0}"
    total_count=$((pass_count + warn_count + fail_count + skip_count))

    checks_json=$(awk '
        match($0, /\[(PASS|FAIL|WARN|SKIP)\][[:space:]]*(.*)/, m) {
            status = m[1]
            message = m[2]
            gsub(/\\/, "\\\\", message)
            gsub(/"/, "\\\"", message)
            printf("{\"status\":\"%s\",\"message\":\"%s\"}\n", status, message)
        }
    ' "$result_file" | jq -cs '.')

    payload=$(jq -n \
        --arg hostname "$(hostname)" \
        --arg os "$OS_NAME" \
        --arg agent_version "$AGENT_VERSION" \
        --arg audit "$audit_name" \
        --arg timestamp "$(date -Iseconds)" \
        --arg output "$output" \
        --argjson duration_ms "$duration_ms" \
        --argjson checks "$checks_json" \
        --argjson total "$total_count" \
        --argjson passed "$pass_count" \
        --argjson failed "$fail_count" \
        --argjson warnings "$warn_count" \
        --argjson skipped "$skip_count" \
        '{
          hostname: $hostname,
          os: $os,
          agent_version: $agent_version,
          results: {
            audit: $audit,
            timestamp: $timestamp,
            duration_ms: $duration_ms,
            output: $output,
            checks: $checks,
            summary: {
              total: $total,
              passed: $passed,
              failed: $failed,
              warnings: $warnings,
              skipped: $skipped
            }
          }
        }')

    if command -v curl >/dev/null 2>&1; then
        response=$(throttled_curl upload -s -X POST \
            -H "Content-Type: application/json" \
            ${API_KEY:+-H "X-API-Key: $API_KEY"} \
            ${AGENT_ID:+-H "X-Agent-ID: $AGENT_ID"} \
            ${attestation_token:+-H "X-Core-Attestation: $attestation_token"} \
            -d "$payload" \
            "${SERVER_URL}/api/agent/results")

        if echo "$response" | jq -e '.success == true' >/dev/null 2>&1; then
            log_ok "Results sent successfully"
            return 0
        fi

        log_error "Failed to send results: $(echo "$response" | jq -r '.error // .details // "unknown error"' 2>/dev/null || echo "$response")"
        return 1
    else
        log_warn "curl not available, cannot send results"
        return 1
    fi
}

version_gt() {
    local left="$1"
    local right="$2"
    [[ "$left" != "$right" ]] && [[ "$(printf '%s\n%s\n' "$left" "$right" | sort -V | tail -n1)" == "$left" ]]
}

self_update() {
    if [[ -z "$SERVER_URL" ]]; then
        log_error "No server URL configured. Use --server URL"
        return 1
    fi

    if ! command -v curl >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1; then
        log_error "self-update requires curl and jq"
        return 1
    fi

    local manifest_url response success update_available latest_version download_url verify_url signature expected_sha tmp_file actual_sha backup_file script_path
    manifest_url="${SERVER_URL}/api/agent/update/manifest?agent_type=standalone&os_type=linux&current_version=${AGENT_VERSION}"

    response=$(throttled_curl download -s -X GET \
        -H "Content-Type: application/json" \
        ${API_KEY:+-H "X-API-Key: $API_KEY"} \
        ${AGENT_ID:+-H "X-Agent-ID: $AGENT_ID"} \
        "$manifest_url")

    success=$(echo "$response" | jq -r '.success // false' 2>/dev/null || echo "false")
    if [[ "$success" != "true" ]]; then
        log_error "Update manifest request failed: $(echo "$response" | jq -r '.error // "unknown error"' 2>/dev/null || echo "unknown error")"
        return 1
    fi

    update_available=$(echo "$response" | jq -r '.update_available // false')
    latest_version=$(echo "$response" | jq -r '.latest_version // ""')
    download_url=$(echo "$response" | jq -r '.download_url // ""')
    verify_url=$(echo "$response" | jq -r '.verify_url // ""')
    signature=$(echo "$response" | jq -r '.signature // ""')
    expected_sha=$(echo "$response" | jq -r '.sha256 // ""')

    if [[ "$update_available" != "true" ]]; then
        log_ok "Agent is up to date (current: ${AGENT_VERSION}, latest: ${latest_version})"
        return 0
    fi

    if [[ -z "$download_url" || -z "$verify_url" || -z "$signature" || -z "$expected_sha" ]]; then
        log_error "Invalid update manifest: missing download/verify/signature/sha256"
        return 1
    fi

    tmp_file=$(mktemp)
    if ! throttled_curl download -s -S -L \
        ${API_KEY:+-H "X-API-Key: $API_KEY"} \
        ${AGENT_ID:+-H "X-Agent-ID: $AGENT_ID"} \
        -o "$tmp_file" \
        "$download_url"; then
        log_error "Failed to download update artifact"
        rm -f "$tmp_file"
        return 1
    fi

    actual_sha=$(sha256sum "$tmp_file" | awk '{print $1}')
    if [[ "$actual_sha" != "$expected_sha" ]]; then
        log_error "Update checksum mismatch"
        rm -f "$tmp_file"
        return 1
    fi

    local verify_payload verify_response verify_success
    verify_payload=$(jq -n \
        --arg signature "$signature" \
        --arg file_sha256 "$actual_sha" \
        --arg agent_type "standalone" \
        --arg os_type "linux" \
        --arg version "$latest_version" \
        '{signature: $signature, file_sha256: $file_sha256, agent_type: $agent_type, os_type: $os_type, version: $version}')

    verify_response=$(throttled_curl upload -s -X POST \
        -H "Content-Type: application/json" \
        ${API_KEY:+-H "X-API-Key: $API_KEY"} \
        ${AGENT_ID:+-H "X-Agent-ID: $AGENT_ID"} \
        -d "$verify_payload" \
        "$verify_url")

    verify_success=$(echo "$verify_response" | jq -r '.success // false' 2>/dev/null || echo "false")
    if [[ "$verify_success" != "true" ]]; then
        log_error "Signed update verification failed: $(echo "$verify_response" | jq -r '.error // "unknown error"' 2>/dev/null || echo "unknown error")"
        rm -f "$tmp_file"
        return 1
    fi

    script_path="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
    backup_file="${script_path}.bak.$(date +%Y%m%d_%H%M%S)"

    cp "$script_path" "$backup_file"
    cp "$tmp_file" "$script_path"
    chmod +x "$script_path"
    rm -f "$tmp_file"

    log_ok "Updated standalone agent ${AGENT_VERSION} -> ${latest_version}"
    log_info "Backup saved to: $backup_file"
    log_info "Restart the agent to run the new version"
    return 0
}

list_results() {
    if [[ ! -d "$RESULTS_DIR" ]]; then
        log_info "No results directory found"
        return 0
    fi

    echo ""
    echo -e "${BOLD}Local Audit Results:${NC}"
    echo "======================================"
    find "$RESULTS_DIR" -name "*.log" -type f -printf "%T+ %p\n" 2>/dev/null | sort -r | head -20 | while read -r line; do
        echo "  $line"
    done
    echo ""
}

# ============================================================================
# Command Polling and Execution (Server-Initiated Audits)
# ============================================================================
AGENT_ID="${AGENT_ID:-}"
POLL_INTERVAL="${POLL_INTERVAL:-60}"  # Seconds between polls

# ============================================================================
# Resource Throttling Configuration
# ============================================================================
# CPU throttling (ionice/nice levels)
CPU_NICE_LEVEL="${CPU_NICE_LEVEL:-19}"           # Nice level: -20 (highest) to 19 (lowest priority)
IO_CLASS="${IO_CLASS:-idle}"                      # ionice class: realtime, best-effort, idle

# Memory thresholds (percentage of total RAM)
MIN_FREE_MEMORY_PCT="${MIN_FREE_MEMORY_PCT:-10}" # Don't run audits if free memory below this %
PAUSE_MEMORY_PCT="${PAUSE_MEMORY_PCT:-5}"        # Pause execution if memory drops below this %

# Network throttling (bytes per second, 0 = unlimited)
UPLOAD_RATE_LIMIT="${UPLOAD_RATE_LIMIT:-0}"      # Upload bandwidth limit (0 = unlimited)
DOWNLOAD_RATE_LIMIT="${DOWNLOAD_RATE_LIMIT:-0}" # Download bandwidth limit (0 = unlimited)

# Execution limits
MAX_CONCURRENT_AUDITS="${MAX_CONCURRENT_AUDITS:-1}"  # Max audits running at once
AUDIT_TIMEOUT="${AUDIT_TIMEOUT:-3600}"               # Max seconds per audit (1 hour default)
COMMAND_BATCH_SIZE="${COMMAND_BATCH_SIZE:-5}"        # Max commands to process per poll cycle
BATCH_DELAY="${BATCH_DELAY:-5}"                      # Seconds between processing commands

# Load thresholds (CPU load average)
MAX_LOAD_AVERAGE="${MAX_LOAD_AVERAGE:-0}"        # Don't start if load above this (0 = disable)
LOAD_CHECK_INTERVAL="${LOAD_CHECK_INTERVAL:-5}"  # Seconds between load checks when waiting

# ============================================================================
# Resource Checking Functions
# ============================================================================
get_memory_info() {
    # Returns: total_mb free_mb free_pct
    if [[ -f /proc/meminfo ]]; then
        local total_kb available_kb
        total_kb=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)
        available_kb=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo 2>/dev/null || awk '/^MemFree:/ {print $2}' /proc/meminfo)

        local total_mb=$((total_kb / 1024))
        local free_mb=$((available_kb / 1024))
        local free_pct=$((available_kb * 100 / total_kb))

        echo "$total_mb $free_mb $free_pct"
    else
        # Fallback: assume plenty of memory
        echo "8192 4096 50"
    fi
}

get_load_average() {
    # Returns 1-minute load average
    if [[ -f /proc/loadavg ]]; then
        awk '{print $1}' /proc/loadavg
    else
        echo "0"
    fi
}

get_cpu_count() {
    if [[ -f /proc/cpuinfo ]]; then
        grep -c ^processor /proc/cpuinfo
    else
        echo "1"
    fi
}

check_resources_available() {
    # Check if system has enough resources to run an audit
    # Returns 0 if OK, 1 if should wait/skip

    # Check memory
    local total_mb free_mb free_pct
    read -r total_mb free_mb free_pct <<< "$(get_memory_info)"

    if [[ "$free_pct" -lt "$MIN_FREE_MEMORY_PCT" ]]; then
        log_warn "Low memory: ${free_pct}% free (${free_mb}MB), threshold: ${MIN_FREE_MEMORY_PCT}%"
        return 1
    fi

    # Check load average
    if [[ "$MAX_LOAD_AVERAGE" != "0" ]]; then
        local load_avg cpu_count max_load
        load_avg=$(get_load_average)
        cpu_count=$(get_cpu_count)

        # If MAX_LOAD_AVERAGE is a percentage (e.g., "80"), convert to absolute
        if [[ "$MAX_LOAD_AVERAGE" -gt 0 && "$MAX_LOAD_AVERAGE" -le 100 ]]; then
            max_load=$(awk "BEGIN {printf \"%.2f\", $cpu_count * $MAX_LOAD_AVERAGE / 100}")
        else
            max_load="$MAX_LOAD_AVERAGE"
        fi

        if awk "BEGIN {exit !($load_avg > $max_load)}"; then
            log_warn "High system load: $load_avg (threshold: $max_load)"
            return 1
        fi
    fi

    return 0
}

wait_for_resources() {
    # Wait until resources are available, with timeout
    local timeout="${1:-300}"  # Default 5 minutes
    local start_time elapsed

    start_time=$(date +%s)

    while ! check_resources_available; do
        elapsed=$(($(date +%s) - start_time))
        if [[ "$elapsed" -ge "$timeout" ]]; then
            log_error "Timeout waiting for resources after ${elapsed}s"
            return 1
        fi

        log_info "Waiting for resources... (${elapsed}s/${timeout}s)"
        sleep "$LOAD_CHECK_INTERVAL"
    done

    return 0
}

# ============================================================================
# Throttled Execution Functions
# ============================================================================
run_throttled() {
    # Run a command with CPU/IO priority limits
    local cmd=("$@")

    # Build prefix command for throttling
    local prefix=()

    # Add nice for CPU priority
    if [[ "$CPU_NICE_LEVEL" != "0" ]] && command -v nice >/dev/null 2>&1; then
        prefix+=(nice -n "$CPU_NICE_LEVEL")
    fi

    # Add ionice for IO priority
    if [[ "$IO_CLASS" != "none" ]] && command -v ionice >/dev/null 2>&1; then
        case "$IO_CLASS" in
            realtime)  prefix+=(ionice -c 1) ;;
            best-effort) prefix+=(ionice -c 2) ;;
            idle)      prefix+=(ionice -c 3) ;;
        esac
    fi

    # Add timeout if specified
    if [[ "$AUDIT_TIMEOUT" -gt 0 ]] && command -v timeout >/dev/null 2>&1; then
        prefix+=(timeout "$AUDIT_TIMEOUT")
    fi

    # Execute with prefix
    if [[ ${#prefix[@]} -gt 0 ]]; then
        "${prefix[@]}" "${cmd[@]}"
    else
        "${cmd[@]}"
    fi
}

throttled_curl() {
    # Run curl with bandwidth limits
    local rate_arg=""
    local mode="$1"
    shift

    case "$mode" in
        upload)
            if [[ "$UPLOAD_RATE_LIMIT" -gt 0 ]]; then
                rate_arg="--limit-rate ${UPLOAD_RATE_LIMIT}"
            fi
            ;;
        download)
            if [[ "$DOWNLOAD_RATE_LIMIT" -gt 0 ]]; then
                rate_arg="--limit-rate ${DOWNLOAD_RATE_LIMIT}"
            fi
            ;;
    esac

    local request_url=""
    local request_method="GET"
    local request_body=""
    local request_agent_id="${AGENT_ID:-}"

    local -a curl_args
    curl_args=("$@")

    local arg i
    for ((i=0; i<${#curl_args[@]}; i++)); do
        arg="${curl_args[i]}"
        case "$arg" in
            -X|--request)
                if (( i + 1 < ${#curl_args[@]} )); then
                    request_method="${curl_args[i+1]}"
                    ((i++))
                fi
                ;;
            -d|--data|--data-raw|--data-binary|--data-ascii|--data-urlencode)
                if (( i + 1 < ${#curl_args[@]} )); then
                    request_body="${curl_args[i+1]}"
                    ((i++))
                fi
                ;;
            -H|--header)
                if (( i + 1 < ${#curl_args[@]} )); then
                    local hdr
                    hdr="${curl_args[i+1]}"
                    if [[ "$hdr" =~ ^X-Agent-ID:[[:space:]]*(.+)$ ]]; then
                        request_agent_id="${BASH_REMATCH[1]}"
                    fi
                    ((i++))
                fi
                ;;
            http://*|https://*)
                request_url="$arg"
                ;;
        esac
    done

    if [[ $# -gt 0 ]]; then
        request_url="${!#}"
    fi

    if [[ -n "$request_url" && "$request_url" =~ ^https?:// ]]; then
        if ! validate_server_url "$request_url"; then
            log_error "HTTP request blocked due to URL policy"
            return 1
        fi
    fi

    local tls_args=()
    if [[ "$TLS_SKIP_VERIFY" == "true" ]]; then
        if [[ "$ALLOW_INSECURE_TLS_IN_NONPROD" == "true" ]] && is_non_production_environment; then
            log_warn "TLS certificate verification bypass enabled for non-production environment: ${AGENT_ENVIRONMENT}" >&2
            tls_args+=(-k)
        else
            log_error "Blocked insecure TLS bypass. Set AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD=true and AUDIT_ENVIRONMENT=dev|test|beta|staging for explicit non-production use."
            return 1
        fi
    fi

    local signature_args=()
    if [[ "${MANAGED_REQUIRE_REQUEST_SIGNATURES,,}" == "true" ]]; then
        if [[ -z "$request_url" ]]; then
            log_error "Managed request-signature enforcement enabled but request URL could not be determined"
            return 1
        fi

        local request_path request_timestamp payload_hash signature_message request_signature
        request_path=$(echo "$request_url" | sed -E 's|^[a-zA-Z][a-zA-Z0-9+.-]*://[^/]+||')
        [[ -z "$request_path" ]] && request_path="/"

        request_timestamp=$(date +%s)
        payload_hash=$(printf '%s' "$request_body" | sha256sum | awk '{print $1}')
        signature_message="${request_method^^}:${request_path}:${request_agent_id}:${request_timestamp}:${payload_hash}"

        if command -v openssl >/dev/null 2>&1; then
            if [[ "${MANAGED_REQUEST_SIGNATURE_USE_ECDSA,,}" == "true" ]]; then
                if [[ -z "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" ]]; then
                    log_error "ECDSA request-signature mode enabled but AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE is not set"
                    return 1
                fi
                if [[ ! -f "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" ]]; then
                    log_error "ECDSA private key file not found: $MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE"
                    return 1
                fi
                request_signature=$(printf '%s' "$signature_message" | openssl dgst -sha256 -sign "$MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_FILE" 2>/dev/null | openssl base64 -A 2>/dev/null)
                request_signature="ecdsa:${request_signature}"
            else
                if [[ -z "$MANAGED_REQUEST_SIGNING_KEY" ]]; then
                    log_error "Managed request-signature enforcement enabled but AUDIT_MANAGED_REQUEST_SIGNING_KEY is not set"
                    return 1
                fi
                request_signature=$(printf '%s' "$signature_message" | openssl dgst -sha256 -hmac "$MANAGED_REQUEST_SIGNING_KEY" 2>/dev/null | awk '{print $2}')
            fi
        else
            log_error "Managed request-signature enforcement requires openssl"
            return 1
        fi

        if [[ -z "$request_signature" ]]; then
            log_error "Failed to compute managed request signature"
            return 1
        fi

        signature_args+=(
            -H "X-Agent-Timestamp: ${request_timestamp}"
            -H "X-Agent-Content-SHA256: ${payload_hash}"
            -H "X-Agent-Signature: ${request_signature}"
        )
    fi

    # shellcheck disable=SC2086
    curl $rate_arg "${tls_args[@]}" "${signature_args[@]}" "$@"
}

# Lightweight mode intentionally excludes central command-orchestration
# functions (poll/daemon/sync). Managed orchestration is handled by
# fleet-agent.sh.

# ============================================================================
# Interactive Menu
# ============================================================================
show_menu() {
    echo ""
    echo -e "${BOLD}=== Lightweight Security Audit Agent v${AGENT_VERSION} ===${NC}"
    echo ""
    echo -e "OS: ${CYAN}${OS_NAME}${NC}"
    echo -e "Detected software: ${GREEN}${#DETECTED_SOFTWARE[@]}${NC} components"
    echo -e "Suggested audits: ${YELLOW}${#SUGGESTED_AUDITS[@]}${NC} checks"
    echo ""
    echo "Options:"
    echo "  1) Show detected software"
    echo "  2) Show suggested audits"
    echo "  3) Run a specific audit"
    echo "  4) Run all platform audits"
    echo "  5) Run all suggested audits"
    echo "  6) View local results"
    echo "  7) Rescan software"
    echo "  8) Configure server reporting"
    echo "  d) Run asset discovery (scan network)"
    echo "  q) Quit"
    echo ""
}

interactive_mode() {
    while true; do
        show_menu
        read -rp "Select option: " choice

        case "$choice" in
            1)
                echo ""
                echo -e "${BOLD}Detected Software:${NC}"
                for sw in "${!DETECTED_SOFTWARE[@]}"; do
                    echo -e "  ${GREEN}✓${NC} $sw - ${DETECTED_SOFTWARE[$sw]}"
                done
                ;;
            2)
                echo ""
                echo -e "${BOLD}Suggested Audits:${NC}"
                local i=1
                for audit in "${!SUGGESTED_AUDITS[@]}"; do
                    echo -e "  $i) $audit"
                    echo -e "     ${CYAN}${SUGGESTED_AUDITS[$audit]}${NC}"
                    ((i++))
                done
                ;;
            3)
                echo ""
                echo "Available audits:"
                local i=1
                local audit_list=()
                for audit in "${!SUGGESTED_AUDITS[@]}"; do
                    echo "  $i) $audit"
                    audit_list+=("$audit")
                    ((i++))
                done
                read -rp "Enter number: " num
                if [[ "$num" =~ ^[0-9]+$ ]] && (( num > 0 && num <= ${#audit_list[@]} )); then
                    run_audit "${audit_list[$((num-1))]}"
                else
                    log_error "Invalid selection"
                fi
                ;;
            4)
                run_audit_group "platform"
                ;;
            5)
                run_all_suggested
                ;;
            6)
                list_results
                ;;
            7)
                detect_software
                suggest_audits
                ;;
            8)
                read -rp "Server URL (empty to disable): " new_url
                if [[ -n "$new_url" ]] && ! validate_server_url "$new_url"; then
                    log_error "Server URL rejected by destination controls. Please verify the scheme/host and allowed domains."
                    continue
                fi

                SERVER_URL="$new_url"
                if [[ -n "$SERVER_URL" ]]; then
                    REPORT_REMOTE="true"
                    log_ok "Server reporting enabled: $SERVER_URL"
                else
                    REPORT_REMOTE="false"
                    log_info "Server reporting disabled"
                fi
                ;;
            d|D)
                if [[ -z "$SERVER_URL" ]]; then
                    log_warn "Server not configured. Configure server first (option 8)"
                else
                    send_discovery
                fi
                ;;
            q|Q)
                log_info "Goodbye!"
                exit 0
                ;;
            *)
                log_error "Invalid option"
                ;;
        esac

        echo ""
        read -rp "Press Enter to continue..."
    done
}

# ============================================================================
# Command Line Interface
# ============================================================================
show_help() {
    cat << EOF
Lightweight Security Audit Agent v${AGENT_VERSION}

Usage: $0 [command] [options]

Commands:
  scan            Scan for installed software
  suggest         Show suggested audits based on detected software
  run <audit>     Run a specific audit (e.g., platform/baseline/updates)
  run-group <g>   Run all audits in a group (platform, web, data, network)
  run-scripts <f> Run scripts listed in a file (one path per line)
  run-all         Run all suggested audits
  discover        Run asset discovery and upload to server
    self-update     Update this agent script from core server
  results         List local results
  interactive     Start interactive menu mode
  help            Show this help message

Connection Options:
  --server URL          Set server URL for remote reporting
  --agent-id ID         Set agent ID for server communication
  --api-key KEY         Set API key for authentication

Resource Throttling Options:
  --cpu-nice N          CPU priority (nice level: -20 to 19, default: 19 = lowest)
  --io-class CLASS      I/O priority class: realtime, best-effort, idle (default: idle)
  --min-memory PCT      Minimum free memory % to start audits (default: 10)
  --max-load N          Maximum load average to start audits (0 = disable, default: 0)
  --upload-limit N      Upload bandwidth limit in bytes/sec (0 = unlimited, default: 0)
  --download-limit N    Download bandwidth limit in bytes/sec (0 = unlimited, default: 0)
  --audit-timeout N     Max seconds per audit (default: 3600)

Output Options:
  --no-color            Disable colored output
  --json                Output in JSON format

Environment Variables:
  SERVER_URL            Server URL (alternative to --server)
  AGENT_ID              Agent ID (alternative to --agent-id)
  API_KEY               API key (alternative to --api-key)
  CPU_NICE_LEVEL        CPU priority level (-20 to 19)
  IO_CLASS              I/O class (realtime, best-effort, idle)
  MIN_FREE_MEMORY_PCT   Minimum free memory percentage
  MAX_LOAD_AVERAGE      Maximum load average
  UPLOAD_RATE_LIMIT     Upload bandwidth limit (bytes/sec)
  DOWNLOAD_RATE_LIMIT   Download bandwidth limit (bytes/sec)
  AUDIT_TIMEOUT         Maximum audit duration

Examples:
  $0 scan                                     # Scan for software
  $0 suggest                                  # Show suggested audits
  $0 run platform/baseline/ssh                # Run SSH audit
  $0 run-group platform                       # Run all platform audits
  $0 interactive                              # Start interactive mode
    $0 discover --server https://x.x.x          # Run discovery and report
    $0 run-all --server https://x.x.x           # Run all and report to server

EOF
}

# ============================================================================
# Main
# ============================================================================
main() {
    # Parse global options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --server)
                if ! validate_server_url "$2"; then
                    log_error "Invalid --server URL"
                    exit 1
                fi
                SERVER_URL="$2"
                REPORT_REMOTE="true"
                shift 2
                ;;
            --agent-id)
                AGENT_ID="$2"
                shift 2
                ;;
            --api-key)
                API_KEY="$2"
                shift 2
                ;;
            --poll-interval)
                POLL_INTERVAL="$2"
                shift 2
                ;;
            --no-color)
                NO_COLOR="true"
                RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; BOLD=''; NC=''
                shift
                ;;
            --json)
                # shellcheck disable=SC2034  # Reserved for future JSON output mode
                JSON_OUTPUT="true"
                shift
                ;;
            # Resource throttling options
            --cpu-nice)
                CPU_NICE_LEVEL="$2"
                shift 2
                ;;
            --io-class)
                IO_CLASS="$2"
                shift 2
                ;;
            --min-memory)
                MIN_FREE_MEMORY_PCT="$2"
                shift 2
                ;;
            --max-load)
                MAX_LOAD_AVERAGE="$2"
                shift 2
                ;;
            --upload-limit)
                UPLOAD_RATE_LIMIT="$2"
                shift 2
                ;;
            --download-limit)
                DOWNLOAD_RATE_LIMIT="$2"
                shift 2
                ;;
            --batch-size)
                COMMAND_BATCH_SIZE="$2"
                shift 2
                ;;
            --batch-delay)
                BATCH_DELAY="$2"
                shift 2
                ;;
            --audit-timeout)
                AUDIT_TIMEOUT="$2"
                shift 2
                ;;
            *)
                break
                ;;
        esac
    done

    # Detect OS first
    detect_os

    if [[ -n "$SERVER_URL" ]] && ! validate_server_url "$SERVER_URL"; then
        log_error "Server URL rejected by destination controls. Please verify the scheme/host and allowed domains."
        exit 1
    fi

    # Handle commands
    local command_name="${1:-interactive}"
    shift || true

    case "$command_name" in
        scan)
            detect_software
            for sw in "${!DETECTED_SOFTWARE[@]}"; do
                echo "$sw: ${DETECTED_SOFTWARE[$sw]}"
            done
            ;;
        suggest)
            detect_software
            suggest_audits
            for audit in "${!SUGGESTED_AUDITS[@]}"; do
                echo "$audit: ${SUGGESTED_AUDITS[$audit]}"
            done
            ;;
        run)
            detect_software
            suggest_audits
            run_audit "$1"
            ;;
        run-group)
            detect_software
            suggest_audits
            run_audit_group "$1"
            ;;
        run-all|runall)
            detect_software
            suggest_audits
            run_all_suggested
            ;;
        run-scripts)
            # Run scripts from a file (used by scheduled custom scans)
            if [[ -z "${1:-}" ]]; then
                log_error "Usage: $0 run-scripts <scripts-file>"
                exit 1
            fi
            run_scripts_from_file "$1"
            ;;
        discover)
            send_discovery
            ;;
        poll)
            log_error "The standalone agent no longer supports command polling. Use fleet-agent.sh for centrally orchestrated execution."
            exit 2
            ;;
        daemon)
            log_error "The standalone agent no longer supports daemon polling mode. Use fleet-agent.sh for centrally orchestrated execution."
            exit 2
            ;;
        sync)
            log_error "The standalone agent no longer supports audit sync from the server. Use fleet-agent.sh for centrally orchestrated execution."
            exit 2
            ;;
        self-update)
            self_update
            ;;
        results)
            list_results
            ;;
        interactive)
            detect_software
            suggest_audits
            interactive_mode
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $command_name"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
