# Windows Defender Security Audit (Standalone Agent)
# Checks Windows Defender/Security status and configuration
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

try {
    # Check if Windows Defender is available
    $defenderStatus = $null
    try {
        $defenderStatus = Get-MpComputerStatus -ErrorAction Stop
    } catch {
        Write-Output "[SKIP] Windows Defender not available - Third-party AV may be installed"
        exit 0
    }

    # Real-time protection
    if ($defenderStatus.RealTimeProtectionEnabled) {
        Write-Output "[PASS] Real-time protection is enabled"
    } else {
        Write-Output "[FAIL] Real-time protection is DISABLED - Enable immediately"
    }

    # Cloud-delivered protection
    if ($defenderStatus.IsTamperProtected) {
        Write-Output "[PASS] Tamper protection is enabled"
    } else {
        Write-Output "[WARN] Tamper protection is disabled - Enable for better security"
    }

    # Signature updates
    $sigAge = $defenderStatus.AntivirusSignatureAge
    if ($sigAge -le 1) {
        Write-Output "[PASS] Antivirus signatures are up to date (Age: $sigAge days)"
    } elseif ($sigAge -le 3) {
        Write-Output "[WARN] Antivirus signatures are $sigAge days old - Update recommended"
    } else {
        Write-Output "[FAIL] Antivirus signatures are $sigAge days old - Update immediately"
    }

    # Antispyware status
    if ($defenderStatus.AntispywareEnabled) {
        Write-Output "[PASS] Antispyware protection is enabled"
    } else {
        Write-Output "[WARN] Antispyware protection is disabled"
    }

    # Behavior monitoring
    if ($defenderStatus.BehaviorMonitorEnabled) {
        Write-Output "[PASS] Behavior monitoring is enabled"
    } else {
        Write-Output "[WARN] Behavior monitoring is disabled - Enable for better protection"
    }

    # IOAV (IE/Office downloads) protection
    if ($defenderStatus.IoavProtectionEnabled) {
        Write-Output "[PASS] Download scanning (IOAV) is enabled"
    } else {
        Write-Output "[WARN] Download scanning (IOAV) is disabled"
    }

    # Network inspection
    if ($defenderStatus.NISEnabled) {
        Write-Output "[PASS] Network inspection service is enabled"
    } else {
        Write-Output "[WARN] Network inspection service is disabled"
    }

    # Check for recent full scan
    try {
        $lastFullScan = $defenderStatus.FullScanEndTime
        if ($lastFullScan) {
            $daysSinceFullScan = (New-TimeSpan -Start $lastFullScan -End (Get-Date)).Days
            if ($daysSinceFullScan -le 7) {
                Write-Output "[PASS] Full scan completed within last 7 days (${daysSinceFullScan}d ago)"
            } elseif ($daysSinceFullScan -le 30) {
                Write-Output "[WARN] Last full scan was $daysSinceFullScan days ago - Run a scan"
            } else {
                Write-Output "[FAIL] No full scan in over 30 days - Run immediately"
            }
        } else {
            Write-Output "[WARN] No full scan history found - Run a full system scan"
        }
    } catch {
        Write-Output "[SKIP] Could not determine last scan date"
    }

    # Check if any threats were detected recently
    try {
        $threats = Get-MpThreatDetection -ErrorAction SilentlyContinue |
            Where-Object { $_.InitialDetectionTime -gt (Get-Date).AddDays(-7) }
        if ($threats) {
            $count = ($threats | Measure-Object).Count
            Write-Output "[WARN] $count threat(s) detected in last 7 days - Review and remediate"
        } else {
            Write-Output "[PASS] No threats detected in last 7 days"
        }
    } catch {
        Write-Output "[SKIP] Could not check recent threat detections"
    }

} catch {
    Write-Output "[FAIL] Error checking Windows Defender status: $($_.Exception.Message)"
}
