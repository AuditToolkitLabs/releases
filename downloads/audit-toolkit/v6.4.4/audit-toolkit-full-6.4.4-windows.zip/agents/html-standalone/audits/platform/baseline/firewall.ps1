# Windows Firewall Security Audit (Standalone Agent)
# Checks Windows Firewall status and configuration
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

try {
    # Check each firewall profile
    $profiles = Get-NetFirewallProfile -ErrorAction Stop

    foreach ($fwProfile in $profiles) {
        $name = $fwProfile.Name
        $enabled = $fwProfile.Enabled
        $defaultIn = $fwProfile.DefaultInboundAction
        $defaultOut = $fwProfile.DefaultOutboundAction

        if ($enabled) {
            Write-Output "[PASS] Firewall $name profile: Enabled"
        } else {
            Write-Output "[FAIL] Firewall $name profile: DISABLED - Enable immediately"
        }

        # Check default actions
        if ($defaultIn -eq "Block") {
            Write-Output "[PASS] $name inbound default: Block (secure)"
        } else {
            Write-Output "[WARN] $name inbound default: $defaultIn (should be Block)"
        }

        if ($defaultOut -eq "Allow") {
            Write-Output "[PASS] $name outbound default: Allow (typical)"
        } elseif ($defaultOut -eq "Block") {
            Write-Output "[PASS] $name outbound default: Block (restrictive)"
        }
    }

    # Check for common risky rules
    $riskyRules = Get-NetFirewallRule -Enabled True -Direction Inbound -Action Allow |
        Where-Object {
            $_.LocalPort -in @("3389", "22", "445", "135", "139") -or
            $_.Program -eq "Any"
        } -ErrorAction SilentlyContinue

    if ($riskyRules) {
        $ruleCount = ($riskyRules | Measure-Object).Count
        Write-Output "[WARN] Found $ruleCount inbound rules for sensitive ports - review these rules"

        # Check RDP specifically
        $rdpRule = $riskyRules | Where-Object { $_.LocalPort -eq "3389" }
        if ($rdpRule) {
            Write-Output "[WARN] RDP (3389) allowed inbound - ensure NLA is enabled and access is restricted"
        }

        # Check SMB
        $smbRule = $riskyRules | Where-Object { $_.LocalPort -eq "445" }
        if ($smbRule) {
            Write-Output "[WARN] SMB (445) allowed inbound - verify this is required"
        }
    } else {
        Write-Output "[PASS] No common risky port rules found (3389, 22, 445, 135, 139)"
    }

    # Check if logging is enabled
    $domainProfile = Get-NetFirewallProfile -Name Domain
    if ($domainProfile.LogFileName -and $domainProfile.LogAllowed) {
        Write-Output "[PASS] Firewall logging is configured"
    } else {
        Write-Output "[WARN] Firewall logging may not be fully configured"
    }

    # Count total rules
    $allRules = Get-NetFirewallRule -Enabled True
    $inboundAllow = ($allRules | Where-Object { $_.Direction -eq "Inbound" -and $_.Action -eq "Allow" } | Measure-Object).Count
    $outboundBlock = ($allRules | Where-Object { $_.Direction -eq "Outbound" -and $_.Action -eq "Block" } | Measure-Object).Count

    Write-Output "[PASS] Active rules: $inboundAllow inbound allow, $outboundBlock outbound block"

} catch {
    Write-Output "[FAIL] Error checking Windows Firewall: $($_.Exception.Message)"
}
