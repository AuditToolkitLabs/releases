#!/usr/bin/env bash
# Linux Firewall Security Audit (Standalone Agent)
# Checks firewall status (ufw, firewalld, iptables, nftables)
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

set -euo pipefail

FIREWALL_FOUND=false

# Check UFW (Ubuntu/Debian)
check_ufw() {
    if command -v ufw >/dev/null 2>&1; then
        FIREWALL_FOUND=true
        STATUS=$(ufw status 2>/dev/null | head -1 || echo "unknown")

        if echo "$STATUS" | grep -q "active"; then
            echo "[PASS] UFW firewall is active"

            # Check default policies
            DEFAULT_IN=$(ufw status verbose 2>/dev/null | grep "Default:" | grep -o "incoming.*" | awk '{print $2}')

            if [[ "$DEFAULT_IN" == "(deny)" || "$DEFAULT_IN" == "deny" ]]; then
                echo "[PASS] UFW default incoming: deny (secure)"
            else
                echo "[WARN] UFW default incoming: $DEFAULT_IN (should be deny)"
            fi

            # Count rules
            RULES=$(ufw status numbered 2>/dev/null | grep -c "^\[" || echo "0")
            echo "[PASS] UFW has $RULES active rules"

            # Check for SSH rule
            if ufw status 2>/dev/null | grep -q "22/tcp"; then
                echo "[PASS] SSH (22/tcp) rule configured"
            fi

            return 0
        else
            echo "[FAIL] UFW is installed but INACTIVE - enable with: sudo ufw enable"
            return 1
        fi
    fi
    return 1
}

# Check firewalld (RHEL/CentOS/Fedora)
check_firewalld() {
    if command -v firewall-cmd >/dev/null 2>&1; then
        FIREWALL_FOUND=true

        if systemctl is-active firewalld >/dev/null 2>&1; then
            echo "[PASS] firewalld is active"

            # Get default zone
            ZONE=$(firewall-cmd --get-default-zone 2>/dev/null || echo "unknown")
            echo "[PASS] Default zone: $ZONE"

            # Check zone target
            TARGET=$(firewall-cmd --zone="$ZONE" --list-all 2>/dev/null | grep "target:" | awk '{print $2}')
            if [[ "$TARGET" == "default" || "$TARGET" == "DROP" || "$TARGET" == "REJECT" ]]; then
                echo "[PASS] Zone target: $TARGET (secure)"
            else
                echo "[WARN] Zone target: $TARGET"
            fi

            # List services
            SERVICES=$(firewall-cmd --zone="$ZONE" --list-services 2>/dev/null || echo "")
            if [[ -n "$SERVICES" ]]; then
                echo "[PASS] Allowed services: $SERVICES"
            fi

            return 0
        else
            echo "[FAIL] firewalld is installed but NOT RUNNING"
            return 1
        fi
    fi
    return 1
}

# Check iptables/nftables
check_iptables() {
    # Check nftables first (modern)
    if command -v nft >/dev/null 2>&1; then
        RULES=$(nft list ruleset 2>/dev/null | grep -c "chain" || echo "0")
        if [[ "$RULES" -gt 0 ]]; then
            FIREWALL_FOUND=true
            echo "[PASS] nftables is active with $RULES chains"
            return 0
        fi
    fi

    # Check iptables
    if command -v iptables >/dev/null 2>&1; then
        INPUT_RULES=$(iptables -L INPUT 2>/dev/null | grep -c -v "^Chain\|^target" || echo "0")
        if [[ "$INPUT_RULES" -gt 0 ]]; then
            FIREWALL_FOUND=true
            echo "[PASS] iptables INPUT chain has $INPUT_RULES rules"

            # Check default policy
            POLICY=$(iptables -L INPUT 2>/dev/null | head -1 | grep -o "policy [A-Z]*" | awk '{print $2}')
            if [[ "$POLICY" == "DROP" || "$POLICY" == "REJECT" ]]; then
                echo "[PASS] iptables INPUT default policy: $POLICY (secure)"
            elif [[ "$POLICY" == "ACCEPT" ]]; then
                echo "[WARN] iptables INPUT default policy: ACCEPT (consider DROP with explicit allows)"
            fi
            return 0
        fi
    fi
    return 1
}

# Run checks
check_ufw || true
check_firewalld || true
check_iptables || true

# Final verdict
if [[ "$FIREWALL_FOUND" == "false" ]]; then
    echo "[FAIL] No active firewall detected - install and configure ufw or firewalld"
fi

# Check for common dangerous open ports (if we can)
if command -v ss >/dev/null 2>&1; then
    # Check for services listening on all interfaces
    DANGEROUS=$(ss -tlnp 2>/dev/null | grep -E "0\.0\.0\.0:(22|3306|5432|6379|27017)" || true)
    if [[ -n "$DANGEROUS" ]]; then
        echo "[WARN] Services listening on all interfaces: $(echo "$DANGEROUS" | wc -l) found"
        echo "[WARN] Consider binding services to localhost or specific IPs"
    else
        echo "[PASS] No common database ports exposed on all interfaces"
    fi
fi
