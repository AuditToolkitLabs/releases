# Windows OS Version Audit (Standalone Agent)
# Checks OS version, build number, and support status
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $caption = $os.Caption
    $build = [int]$os.BuildNumber

    Write-Output "[PASS] OS Detected: $caption (Build $build)"

    # Determine if this is a Server or Desktop edition
    $isServer = $caption -match "Server"

    # Check support status based on build numbers
    # Server 2019 = 17763, Server 2022 = 20348, Server 2025 = 26100
    # Windows 10 21H2 = 19044, Windows 11 21H2 = 22000, Windows 11 23H2 = 22631
    if ($isServer) {
        if ($build -ge 26100) {
            Write-Output "[PASS] Windows Server 2025 - Fully supported and current"
        } elseif ($build -ge 20348) {
            Write-Output "[PASS] Windows Server 2022 - Fully supported"
        } elseif ($build -ge 17763) {
            Write-Output "[WARN] Windows Server 2019 - In extended support (ends Jan 2029)"
        } elseif ($build -ge 14393) {
            Write-Output "[FAIL] Windows Server 2016 - Consider upgrade to Server 2022/2025"
        } else {
            Write-Output "[FAIL] Windows Server version is end-of-life - Upgrade required"
        }
    } else {
        # Desktop Windows
        if ($build -ge 26100) {
            Write-Output "[PASS] Windows 11 24H2 - Fully supported and current"
        } elseif ($build -ge 22631) {
            Write-Output "[PASS] Windows 11 23H2 - Fully supported"
        } elseif ($build -ge 22621) {
            Write-Output "[PASS] Windows 11 22H2 - Supported"
        } elseif ($build -ge 22000) {
            Write-Output "[WARN] Windows 11 21H2 - Check support status"
        } elseif ($build -ge 19045) {
            Write-Output "[WARN] Windows 10 22H2 - In extended support (ends Oct 2025)"
        } elseif ($build -ge 19044) {
            Write-Output "[FAIL] Windows 10 21H2 - End of support. Upgrade to 22H2 or Windows 11"
        } else {
            Write-Output "[FAIL] Windows 10 version is end-of-life - Upgrade required"
        }
    }

    # Check architecture
    if ([Environment]::Is64BitOperatingSystem) {
        Write-Output "[PASS] 64-bit operating system"
    } else {
        Write-Output "[WARN] 32-bit operating system - Limited security features"
    }

    # Check Secure Boot (if available)
    try {
        $secureBoot = Confirm-SecureBootUEFI -ErrorAction SilentlyContinue
        if ($secureBoot) {
            Write-Output "[PASS] Secure Boot is enabled"
        } else {
            Write-Output "[WARN] Secure Boot is disabled - Enable for better security"
        }
    } catch {
        Write-Output "[SKIP] Secure Boot check - Not supported on this system"
    }

} catch {
    Write-Output "[FAIL] Could not determine OS version: $($_.Exception.Message)"
}
