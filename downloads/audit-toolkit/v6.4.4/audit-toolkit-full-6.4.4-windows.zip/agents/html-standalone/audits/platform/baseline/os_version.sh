#!/usr/bin/env bash
# Linux OS Version Audit (Standalone Agent)
# Checks OS version, kernel, and support status
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

set -euo pipefail

# Detect OS
if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    . /etc/os-release
    OS_ID="${ID:-unknown}"
    OS_VERSION="${VERSION_ID:-}"
    OS_NAME="${PRETTY_NAME:-$ID}"
else
    OS_ID="unknown"
    OS_NAME="Unknown Linux"
    OS_VERSION=""
fi

echo "[PASS] OS Detected: $OS_NAME"

# Check kernel version
KERNEL_VERSION=$(uname -r)
KERNEL_MAJOR=$(echo "$KERNEL_VERSION" | cut -d. -f1)
KERNEL_MINOR=$(echo "$KERNEL_VERSION" | cut -d. -f2)

echo "[PASS] Kernel version: $KERNEL_VERSION"

# Check kernel support status
if [[ "$KERNEL_MAJOR" -ge 6 ]]; then
    echo "[PASS] Kernel 6.x - Current mainline version"
elif [[ "$KERNEL_MAJOR" -eq 5 && "$KERNEL_MINOR" -ge 15 ]]; then
    echo "[PASS] Kernel 5.15+ - LTS supported"
elif [[ "$KERNEL_MAJOR" -eq 5 ]]; then
    echo "[WARN] Kernel 5.x < 5.15 - Consider upgrading to LTS kernel"
elif [[ "$KERNEL_MAJOR" -eq 4 ]]; then
    echo "[WARN] Kernel 4.x - May be out of support, consider upgrade"
else
    echo "[FAIL] Very old kernel version - Security risk, upgrade recommended"
fi

# Check distro-specific support status
case "$OS_ID" in
    ubuntu)
        case "$OS_VERSION" in
            24.04*) echo "[PASS] Ubuntu 24.04 LTS - Supported until 2029" ;;
            22.04*) echo "[PASS] Ubuntu 22.04 LTS - Supported until 2027" ;;
            20.04*) echo "[WARN] Ubuntu 20.04 LTS - Standard support ends 2025, consider upgrade" ;;
            18.04*) echo "[FAIL] Ubuntu 18.04 LTS - End of standard support, upgrade required" ;;
            *) echo "[WARN] Ubuntu version $OS_VERSION - Check support status" ;;
        esac
        ;;
    debian)
        case "$OS_VERSION" in
            12*) echo "[PASS] Debian 12 (Bookworm) - Current stable" ;;
            11*) echo "[PASS] Debian 11 (Bullseye) - Oldstable, still supported" ;;
            10*) echo "[WARN] Debian 10 (Buster) - LTS only, consider upgrade" ;;
            *) echo "[WARN] Debian version $OS_VERSION - Check support status" ;;
        esac
        ;;
    rhel|centos|rocky|almalinux)
        case "$OS_VERSION" in
            9*) echo "[PASS] RHEL/Rocky/Alma 9.x - Supported until 2032" ;;
            8*) echo "[PASS] RHEL/Rocky/Alma 8.x - Supported until 2029" ;;
            7*) echo "[WARN] RHEL/CentOS 7.x - Maintenance support, plan upgrade" ;;
            *) echo "[WARN] Version $OS_VERSION - Check support status" ;;
        esac
        ;;
    fedora)
        echo "[WARN] Fedora $OS_VERSION - Short support cycle, stays current or upgrade"
        ;;
    alpine)
        case "$OS_VERSION" in
            3.2*|3.19*|3.18*) echo "[PASS] Alpine $OS_VERSION - Supported" ;;
            *) echo "[WARN] Alpine $OS_VERSION - Check support status" ;;
        esac
        ;;
    *)
        echo "[WARN] Unknown distribution: $OS_ID $OS_VERSION - Verify support status"
        ;;
esac

# Check architecture
ARCH=$(uname -m)
if [[ "$ARCH" == "x86_64" || "$ARCH" == "aarch64" ]]; then
    echo "[PASS] 64-bit architecture: $ARCH"
elif [[ "$ARCH" == "i686" || "$ARCH" == "i386" ]]; then
    echo "[WARN] 32-bit architecture - Limited security features and support"
else
    echo "[PASS] Architecture: $ARCH"
fi

# Check if running in a container
if [[ -f /.dockerenv ]] || grep -q 'docker\|lxc\|containerd' /proc/1/cgroup 2>/dev/null; then
    echo "[PASS] Running in container environment"
fi

# Check virtualization
if command -v systemd-detect-virt >/dev/null 2>&1; then
    VIRT=$(systemd-detect-virt 2>/dev/null || echo "none")
    if [[ "$VIRT" != "none" ]]; then
        echo "[PASS] Virtualization detected: $VIRT"
    fi
fi
