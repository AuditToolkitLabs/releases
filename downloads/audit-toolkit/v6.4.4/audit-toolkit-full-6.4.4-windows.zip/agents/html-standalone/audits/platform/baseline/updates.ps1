# Windows Update Security Audit (Standalone Agent)
# Checks Windows Update status and pending updates
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

try {
    # Check Windows Update service status
    $wuService = Get-Service -Name wuauserv -ErrorAction SilentlyContinue
    if ($wuService) {
        if ($wuService.Status -eq 'Running') {
            Write-Output "[PASS] Windows Update service is running"
        } elseif ($wuService.StartType -eq 'Manual') {
            Write-Output "[PASS] Windows Update service is set to manual (normal)"
        } else {
            Write-Output "[WARN] Windows Update service is not running (Status: $($wuService.Status))"
        }
    } else {
        Write-Output "[FAIL] Windows Update service not found"
    }

    # Check automatic updates configuration
    try {
        $auKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update"
        $auOptions = Get-ItemProperty -Path $auKey -Name AUOptions -ErrorAction SilentlyContinue

        if ($auOptions.AUOptions -eq 4) {
            Write-Output "[PASS] Automatic updates enabled (auto download and install)"
        } elseif ($auOptions.AUOptions -eq 3) {
            Write-Output "[WARN] Auto download enabled but manual install required"
        } elseif ($auOptions.AUOptions -eq 2) {
            Write-Output "[WARN] Only notification of updates enabled - Enable auto updates"
        } else {
            Write-Output "[WARN] Automatic updates may not be configured"
        }
    } catch {
        Write-Output "[SKIP] Could not determine automatic update settings"
    }

    # Check for pending updates using COM object
    try {
        $updateSession = New-Object -ComObject Microsoft.Update.Session
        $updateSearcher = $updateSession.CreateUpdateSearcher()
        $searchResult = $updateSearcher.Search("IsInstalled=0 and Type='Software'")

        $pendingCount = $searchResult.Updates.Count
        $criticalCount = 0
        $securityCount = 0

        foreach ($update in $searchResult.Updates) {
            foreach ($category in $update.Categories) {
                if ($category.Name -eq "Security Updates") {
                    $securityCount++
                    break
                }
                if ($category.Name -eq "Critical Updates") {
                    $criticalCount++
                    break
                }
            }
        }

        if ($pendingCount -eq 0) {
            Write-Output "[PASS] No pending Windows updates"
        } else {
            if ($securityCount -gt 0 -or $criticalCount -gt 0) {
                Write-Output "[FAIL] $pendingCount pending updates ($securityCount security, $criticalCount critical) - Install immediately"
            } else {
                Write-Output "[WARN] $pendingCount pending updates available"
            }
        }
    } catch {
        Write-Output "[SKIP] Could not check pending updates (may require elevation)"
    }

    # Check last update installation time
    try {
        $hotfixes = Get-HotFix | Sort-Object InstalledOn -Descending -ErrorAction SilentlyContinue
        if ($hotfixes -and $hotfixes[0].InstalledOn) {
            $lastUpdate = $hotfixes[0].InstalledOn
            $daysSinceUpdate = (New-TimeSpan -Start $lastUpdate -End (Get-Date)).Days

            if ($daysSinceUpdate -le 30) {
                Write-Output "[PASS] Last update installed $daysSinceUpdate days ago"
            } elseif ($daysSinceUpdate -le 60) {
                Write-Output "[WARN] Last update was $daysSinceUpdate days ago - Check for updates"
            } else {
                Write-Output "[FAIL] No updates installed in $daysSinceUpdate days - Update immediately"
            }
        }
    } catch {
        Write-Output "[SKIP] Could not determine last update date"
    }

    # Check if system is pending reboot for updates
    $rebootPending = $false
    try {
        $rebootKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
        if (Test-Path $rebootKey) {
            $rebootPending = $true
        }
        $cbsKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
        if (Test-Path $cbsKey) {
            $rebootPending = $true
        }

        if ($rebootPending) {
            Write-Output "[WARN] System pending reboot to complete updates"
        } else {
            Write-Output "[PASS] No reboot pending for updates"
        }
    } catch {
        Write-Output "[SKIP] Could not check reboot status"
    }

} catch {
    Write-Output "[FAIL] Error checking Windows Update status: $($_.Exception.Message)"
}
