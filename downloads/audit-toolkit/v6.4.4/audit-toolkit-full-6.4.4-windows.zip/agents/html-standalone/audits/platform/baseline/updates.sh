#!/usr/bin/env bash
# Linux Updates Security Audit (Standalone Agent)
# Checks for pending system updates
# Output: [PASS|FAIL|WARN|SKIP] messages for agent parsing

set -euo pipefail

# Detect package manager
detect_pkg_manager() {
    if command -v apt >/dev/null 2>&1; then
        echo "apt"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v apk >/dev/null 2>&1; then
        echo "apk"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    elif command -v pacman >/dev/null 2>&1; then
        echo "pacman"
    else
        echo "unknown"
    fi
}

PKG_MANAGER=$(detect_pkg_manager)
echo "[PASS] Package manager detected: $PKG_MANAGER"

# Check for pending updates
check_updates() {
    case "$PKG_MANAGER" in
        apt)
            # Update package lists
            if apt-get update -qq 2>/dev/null; then
                echo "[PASS] Package lists updated successfully"
            else
                echo "[WARN] Could not update package lists (may need root)"
            fi

            # Check for upgrades
            UPGRADES=$(apt list --upgradable 2>/dev/null | grep -c upgradable || echo "0")
            SECURITY=$(apt list --upgradable 2>/dev/null | grep -c -i security || echo "0")
            ;;
        dnf|yum)
            UPGRADES=$($PKG_MANAGER check-update 2>/dev/null | grep -c "^\S" || echo "0")
            SECURITY=$($PKG_MANAGER updateinfo list security 2>/dev/null | wc -l || echo "0")
            ;;
        apk)
            apk update -q 2>/dev/null || true
            UPGRADES=$(apk version -l '<' 2>/dev/null | wc -l || echo "0")
            SECURITY="0"  # Alpine doesn't have security-specific tracking
            ;;
        zypper)
            zypper refresh -q 2>/dev/null || true
            UPGRADES=$(zypper list-updates 2>/dev/null | grep -c "^v" || echo "0")
            SECURITY=$(zypper list-patches --category security 2>/dev/null | grep -c "needed" || echo "0")
            ;;
        pacman)
            pacman -Sy --noconfirm 2>/dev/null || true
            UPGRADES=$(pacman -Qu 2>/dev/null | wc -l || echo "0")
            SECURITY="0"  # Arch doesn't track security updates separately
            ;;
        *)
            echo "[SKIP] Unknown package manager - cannot check updates"
            return
            ;;
    esac

    # Report findings
    if [[ "$UPGRADES" -eq 0 ]]; then
        echo "[PASS] System is up to date - no pending updates"
    elif [[ "$SECURITY" -gt 0 ]]; then
        echo "[FAIL] $UPGRADES pending updates ($SECURITY security) - update immediately"
    elif [[ "$UPGRADES" -gt 10 ]]; then
        echo "[WARN] $UPGRADES pending updates - schedule update soon"
    else
        echo "[WARN] $UPGRADES pending updates available"
    fi
}

check_updates

# Check automatic updates configuration
check_auto_updates() {
    case "$PKG_MANAGER" in
        apt)
            if [[ -f /etc/apt/apt.conf.d/20auto-upgrades ]]; then
                if grep -q 'APT::Periodic::Unattended-Upgrade "1"' /etc/apt/apt.conf.d/20auto-upgrades 2>/dev/null; then
                    echo "[PASS] Unattended upgrades enabled"
                else
                    echo "[WARN] Unattended upgrades not configured"
                fi
            else
                echo "[WARN] Automatic updates not configured - consider enabling unattended-upgrades"
            fi
            ;;
        dnf)
            if systemctl is-enabled dnf-automatic.timer 2>/dev/null | grep -q enabled; then
                echo "[PASS] dnf-automatic is enabled"
            else
                echo "[WARN] Automatic updates not configured - consider dnf-automatic"
            fi
            ;;
        *)
            echo "[SKIP] Automatic update check not implemented for $PKG_MANAGER"
            ;;
    esac
}

check_auto_updates

# Check last update time
check_last_update() {
    case "$PKG_MANAGER" in
        apt)
            if [[ -f /var/log/apt/history.log ]]; then
                LAST_UPDATE=$(grep "Start-Date:" /var/log/apt/history.log | tail -1 | cut -d' ' -f2)
                if [[ -n "$LAST_UPDATE" ]]; then
                    DAYS_AGO=$(( ($(date +%s) - $(date -d "$LAST_UPDATE" +%s)) / 86400 ))
                    if [[ "$DAYS_AGO" -le 30 ]]; then
                        echo "[PASS] Last package change was $DAYS_AGO days ago"
                    elif [[ "$DAYS_AGO" -le 60 ]]; then
                        echo "[WARN] Last package change was $DAYS_AGO days ago"
                    else
                        echo "[FAIL] No package changes in $DAYS_AGO days - check update schedule"
                    fi
                fi
            fi
            ;;
        dnf|yum)
            if [[ -f /var/log/dnf.log ]]; then
                LAST_UPDATE=$(grep -E "COMMAND|Upgrade" /var/log/dnf.log | tail -1 | head -c 10)
                if [[ -n "$LAST_UPDATE" ]]; then
                    echo "[PASS] Recent dnf activity found"
                fi
            fi
            ;;
        *)
            echo "[SKIP] Last update check not implemented for $PKG_MANAGER"
            ;;
    esac
}

check_last_update

# Check if reboot is required
if [[ -f /var/run/reboot-required ]]; then
    echo "[WARN] System reboot required to complete updates"
elif [[ -f /var/run/reboot-required.pkgs ]]; then
    PKGS=$(cat /var/run/reboot-required.pkgs 2>/dev/null | wc -l)
    echo "[WARN] Reboot required for $PKGS package(s)"
else
    echo "[PASS] No reboot required"
fi
