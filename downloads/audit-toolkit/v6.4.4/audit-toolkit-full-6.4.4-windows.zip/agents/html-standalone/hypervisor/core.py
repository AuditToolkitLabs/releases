#!/usr/bin/env python3
"""
Hypervisor Fleet Agent - Core Framework

Base classes and utilities for hypervisor-specific security audit agents.
Designed for API-only communication with the central Security Audit Toolkit server.

Supported Platforms:
- VMware ESXi
- Proxmox VE
- XCP-ng / Citrix Hypervisor
- KVM/libvirt
- Nutanix AHV

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import hashlib
import json
import logging
import os
import socket
import subprocess
import sys
import time
import uuid
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger('hypervisor-agent')

DEFAULT_MIN_FREE_DISK_MB = int(os.environ.get('AUDIT_MIN_FREE_DISK_MB', '512'))
DEFAULT_MIN_FREE_DISK_PCT = int(os.environ.get('AUDIT_MIN_FREE_DISK_PCT', '3'))


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class CheckResult:
    """Single audit check result"""
    name: str
    status: str  # PASS, FAIL, WARN, SKIP
    message: str = ""
    category: str = ""
    severity: str = "medium"  # low, medium, high, critical
    remediation: str = ""
    compliance: List[str] = field(default_factory=list)


@dataclass
class AuditResults:
    """Collection of audit check results"""
    checks: List[CheckResult] = field(default_factory=list)
    started_at: datetime = None
    completed_at: datetime = None
    platform: str = ""
    platform_version: str = ""
    agent_id: str = ""

    def __post_init__(self):
        if self.started_at is None:
            self.started_at = datetime.now()

    def register(self, name: str, status: str, message: str = "",
                 category: str = "", severity: str = "medium",
                 remediation: str = "", compliance: List[str] = None):
        """Register a check result"""
        check = CheckResult(
            name=name,
            status=status,
            message=message,
            category=category,
            severity=severity,
            remediation=remediation,
            compliance=compliance or []
        )
        self.checks.append(check)

        # Log with color
        colors = {
            "PASS": "\033[92m",
            "WARN": "\033[93m",
            "FAIL": "\033[91m",
            "SKIP": "\033[90m",
        }
        reset = "\033[0m"
        color = colors.get(status, "")
        log_msg = f"{color}[{status}]{reset} {name}"
        if message:
            log_msg += f" - {message}"
        print(log_msg)

    def section(self, title: str):
        """Print section header"""
        print(f"\n\033[96m=== {title} ===\033[0m\n")

    @property
    def summary(self) -> Dict[str, int]:
        """Get summary counts"""
        counts = {"passed": 0, "failed": 0, "warnings": 0, "skipped": 0}
        for check in self.checks:
            if check.status == "PASS":
                counts["passed"] += 1
            elif check.status == "FAIL":
                counts["failed"] += 1
            elif check.status == "WARN":
                counts["warnings"] += 1
            else:
                counts["skipped"] += 1
        counts["total"] = len(self.checks)
        return counts

    def finalize(self):
        """Mark audit as complete"""
        self.completed_at = datetime.now()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API submission"""
        return {
            "agent_id": self.agent_id,
            "platform": self.platform,
            "platform_version": self.platform_version,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "checks": [
                {
                    "name": c.name,
                    "status": c.status,
                    "message": c.message,
                    "category": c.category,
                    "severity": c.severity,
                    "remediation": c.remediation,
                    "compliance": c.compliance
                }
                for c in self.checks
            ],
            "summary": self.summary
        }

    def to_json(self) -> str:
        """Export as JSON string"""
        return json.dumps(self.to_dict(), indent=2)

    def print_summary(self):
        """Print summary to console"""
        s = self.summary
        print("\n=== Audit Summary ===")
        print(f"Total Checks: {s['total']}")
        print(f"\033[92mPassed: {s['passed']}\033[0m")
        print(f"\033[93mWarnings: {s['warnings']}\033[0m")
        print(f"\033[91mFailed: {s['failed']}\033[0m")
        print(f"\033[90mSkipped: {s['skipped']}\033[0m")


@dataclass
class Command:
    """Command from server"""
    id: int
    type: str  # run_audit, update_config, key_rotation, shutdown
    params: Dict[str, Any] = field(default_factory=dict)
    priority: str = "normal"
    created_at: datetime = None


# =============================================================================
# API Client
# =============================================================================

class APIClient:
    """HTTP client for server communication with optional mTLS support"""

    def __init__(self, server_url: str, api_key: str, verify_ssl: bool = True,
                 timeout: int = 30, client_cert: str = None, client_key: str = None,
                 ca_bundle: str = None):
        """
        Initialize API client.

        Args:
            server_url: Server base URL
            api_key: Bearer token for API auth
            verify_ssl: Verify server certificate (True, False, or path to CA bundle)
            timeout: Request timeout in seconds
            client_cert: Path to client certificate (PEM) for mTLS
            client_key: Path to client private key (PEM) for mTLS
            ca_bundle: Path to CA certificate bundle for server verification
        """
        self.server_url = server_url.rstrip('/')
        self.api_key = api_key
        self.timeout = timeout

        # TLS configuration
        self.client_cert = client_cert
        self.client_key = client_key
        self.ca_bundle = ca_bundle

        # Determine SSL verification setting
        if ca_bundle and os.path.exists(ca_bundle):
            self.verify_ssl = ca_bundle
        else:
            self.verify_ssl = verify_ssl

        # Client certificate tuple for requests library
        self.cert = None
        if client_cert and client_key:
            if os.path.exists(client_cert) and os.path.exists(client_key):
                self.cert = (client_cert, client_key)
                logger.info("mTLS enabled with client certificate")
            else:
                logger.warning("Client cert/key specified but files not found - mTLS disabled")

        # Import requests here to allow agent to work without it initially
        try:
            import requests
            self.requests = requests
            if not verify_ssl:
                import urllib3
                urllib3.disable_warnings()
        except ImportError:
            self.requests = None
            logger.warning("requests module not available - API communication disabled")

    def _headers(self) -> Dict[str, str]:
        """Get request headers"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "HypervisorAgent/1.0"
        }

    def get(self, endpoint: str) -> Optional[Dict[str, Any]]:
        """Make GET request"""
        if not self.requests:
            return None

        url = f"{self.server_url}{endpoint}"
        try:
            response = self.requests.get(
                url,
                headers=self._headers(),
                verify=self.verify_ssl,
                cert=self.cert,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"GET {endpoint} failed: {e}")
            return None

    def post(self, endpoint: str, data: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """Make POST request"""
        if not self.requests:
            return None

        url = f"{self.server_url}{endpoint}"
        try:
            response = self.requests.post(
                url,
                headers=self._headers(),
                json=data or {},
                verify=self.verify_ssl,
                cert=self.cert,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"POST {endpoint} failed: {e}")
            return None


# =============================================================================
# Base Hypervisor Agent
# =============================================================================

class HypervisorAgent(ABC):
    """
    Abstract base class for hypervisor-specific agents.

    Each platform (ESXi, Proxmox, XCP-ng, etc.) implements this class
    with platform-specific audit logic.
    """

    # Class-level platform identifier
    PLATFORM = "unknown"
    PLATFORM_NAME = "Unknown Hypervisor"

    def __init__(self, server_url: str = None, api_key: str = None,
                 agent_id: str = None, config_path: str = None,
                 client_cert: str = None, client_key: str = None,
                 ca_bundle: str = None):
        """
        Initialize hypervisor agent.

        Args:
            server_url: Central server URL (e.g., https://audit.example.com)
            api_key: API key for authentication
            agent_id: Unique agent identifier (auto-generated if not provided)
            config_path: Path to configuration file
            client_cert: Path to client certificate for mTLS
            client_key: Path to client private key for mTLS
            ca_bundle: Path to CA bundle for server verification
        """
        self.config_path = Path(config_path) if config_path else self._default_config_path()
        self.config = self._load_config()

        # Override config with explicit parameters
        self.server_url = server_url or self.config.get('server_url') or os.environ.get('AUDIT_SERVER_URL')
        self.api_key = api_key or self.config.get('api_key') or os.environ.get('AUDIT_API_KEY')
        self.agent_id = agent_id or self.config.get('agent_id') or self._generate_agent_id()

        # TLS configuration (args > config > env vars)
        tls_config = self.config.get('tls', {})
        self.client_cert = client_cert or tls_config.get('client_cert') or os.environ.get('AUDIT_CLIENT_CERT')
        self.client_key = client_key or tls_config.get('client_key') or os.environ.get('AUDIT_CLIENT_KEY')
        self.ca_bundle = ca_bundle or tls_config.get('ca_bundle') or os.environ.get('AUDIT_CA_BUNDLE')

        # Initialize API client with TLS support
        verify_ssl = self.config.get('verify_ssl', True)
        self.api = APIClient(
            self.server_url,
            self.api_key,
            verify_ssl,
            client_cert=self.client_cert,
            client_key=self.client_key,
            ca_bundle=self.ca_bundle
        ) if self.server_url else None

        # Detect platform
        self.platform_version = self._detect_platform_version()

        # State
        self.registered = False
        self.last_heartbeat = None
        self.pending_commands: List[Command] = []

    def _default_config_path(self) -> Path:
        """Get default configuration file path"""
        # Check common locations
        locations = [
            Path('/opt/audit-agent/config.json'),
            Path('/etc/audit-agent/config.json'),
            Path.home() / '.audit-agent' / 'config.json',
            Path(__file__).parent / 'config.json'
        ]
        for loc in locations:
            if loc.exists():
                return loc
        return locations[0]  # Default to /opt/audit-agent/config.json

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load config: {e}")
        return {}

    def _save_config(self):
        """Save configuration to file"""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump({
                'server_url': self.server_url,
                'agent_id': self.agent_id,
                'verify_ssl': self.config.get('verify_ssl', True),
                'min_free_disk_mb': self.config.get('min_free_disk_mb', DEFAULT_MIN_FREE_DISK_MB),
                'min_free_disk_pct': self.config.get('min_free_disk_pct', DEFAULT_MIN_FREE_DISK_PCT),
                # Note: API key stored separately (encrypted)
            }, f, indent=2)

    def _save_api_key(self, api_key: str):
        """
        Save API key to secure storage.

        In production, this should use OS-specific secure storage:
        - Linux: libsecret, keyring, or encrypted file
        - Windows: Windows Credential Manager

        For now, stores in a separate file with restricted permissions.
        """
        key_path = self.config_path.parent / '.api_key'
        key_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            # Write key file
            with open(key_path, 'w') as f:
                f.write(api_key)

            # Restrict permissions (Unix only)
            try:
                key_path.chmod(0o600)
            except (OSError, AttributeError):
                pass  # Windows doesn't support chmod

            logger.info(f"API key saved to {key_path}")
        except Exception as e:
            logger.error(f"Failed to save API key: {e}")

    def _generate_agent_id(self) -> str:
        """Generate unique agent ID based on system characteristics"""
        hostname = socket.gethostname()
        # Create deterministic ID from hostname + platform
        unique = f"{hostname}-{self.PLATFORM}-{uuid.getnode()}"
        return hashlib.sha256(unique.encode()).hexdigest()[:16]

    @abstractmethod
    def _detect_platform_version(self) -> str:
        """
        Detect hypervisor platform and version.

        Returns:
            Version string (e.g., "8.0 Update 2" for ESXi)
        """
        pass

    @abstractmethod
    def run_audit(self, categories: List[str] = None) -> AuditResults:
        """
        Run security audit using native hypervisor tools.

        Args:
            categories: List of audit categories to run (None = all)
                       Common categories: security, network, storage, compute

        Returns:
            AuditResults object with all check results
        """
        pass

    @abstractmethod
    def get_system_info(self) -> Dict[str, Any]:
        """
        Get hypervisor system information for discovery.

        Returns:
            Dictionary with hostname, version, hardware info, VM counts, etc.
        """
        pass

    def run_command(self, cmd: List[str], timeout: int = 60) -> subprocess.CompletedProcess:
        """
        Run a shell command safely.

        Args:
            cmd: Command as list of arguments
            timeout: Timeout in seconds

        Returns:
            CompletedProcess with stdout, stderr, returncode
        """
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result
        except subprocess.TimeoutExpired:
            logger.error(f"Command timed out: {' '.join(cmd)}")
            raise
        except Exception as e:
            logger.error(f"Command failed: {e}")
            raise

    def _min_free_disk_mb(self) -> int:
        """Resolve minimum free disk MB threshold from config/env."""
        try:
            value = int(self.config.get('min_free_disk_mb', DEFAULT_MIN_FREE_DISK_MB))
        except (TypeError, ValueError):
            value = DEFAULT_MIN_FREE_DISK_MB
        return max(64, value)

    def _min_free_disk_pct(self) -> int:
        """Resolve minimum free disk percent threshold from config/env."""
        try:
            value = int(self.config.get('min_free_disk_pct', DEFAULT_MIN_FREE_DISK_PCT))
        except (TypeError, ValueError):
            value = DEFAULT_MIN_FREE_DISK_PCT
        return max(1, min(95, value))

    def _has_disk_headroom(self, path: Path, context: str = "local storage") -> bool:
        """Check whether local path has enough free disk for writes."""
        try:
            path.mkdir(parents=True, exist_ok=True)
            usage = shutil.disk_usage(path)
            free_mb = int(usage.free / (1024 * 1024))
            total_mb = int(usage.total / (1024 * 1024))
            free_pct = int(round((free_mb / total_mb) * 100)) if total_mb > 0 else 0

            min_free_mb = self._min_free_disk_mb()
            min_free_pct = self._min_free_disk_pct()

            if free_mb < min_free_mb or free_pct < min_free_pct:
                logger.warning(
                    "Low disk space for %s: %sMB/%s%% free (min: %sMB/%s%%)",
                    context,
                    free_mb,
                    free_pct,
                    min_free_mb,
                    min_free_pct,
                )
                return False
            return True
        except Exception as exc:
            logger.warning(f"Disk headroom check failed for {context}: {exc}")
            return False

    # =========================================================================
    # Server Communication
    # =========================================================================

    def register(self) -> bool:
        """
        Register agent with central server.

        Returns:
            True if registration successful
        """
        if not self.api:
            logger.warning("No server configured - running in standalone mode")
            return False

        system_info = self.get_system_info()

        payload = {
            "agent_id": self.agent_id,
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": "1.0.0",
            "hostname": socket.gethostname(),
            "platform_version": self.platform_version,
            "capabilities": ["audit", "discovery"],
            "system_info": system_info
        }

        response = self.api.post('/api/hypervisor-agent/register', payload)

        if response and response.get('success'):
            self.registered = True
            # Apply any server-provided configuration
            config = response.get('config', {})
            self.config.update(config)
            logger.info(f"Agent registered successfully: {self.agent_id}")
            return True

        logger.error("Agent registration failed")
        return False

    def heartbeat(self) -> List[Command]:
        """
        Send heartbeat and receive pending commands.

        Returns:
            List of commands to execute
        """
        if not self.api:
            return []

        payload = {
            "status": "idle",
            "timestamp": datetime.now().isoformat(),
            "platform_version": self.platform_version
        }

        response = self.api.post(f'/api/hypervisor-agent/{self.agent_id}/heartbeat', payload)

        if response and response.get('success'):
            self.last_heartbeat = datetime.now()

            # Parse commands
            commands = []
            for cmd_data in response.get('commands', []):
                cmd = Command(
                    id=cmd_data.get('id'),
                    type=cmd_data.get('type'),
                    params=cmd_data.get('params', {}),
                    priority=cmd_data.get('priority', 'normal')
                )
                commands.append(cmd)

            return commands

        return []

    def submit_results(self, results: AuditResults) -> bool:
        """
        Push audit results to server.

        Args:
            results: AuditResults to submit

        Returns:
            True if submission successful
        """
        if not self.api:
            # Save locally if no server
            results_path = Path('/opt/audit-agent/results')
            results_path.mkdir(parents=True, exist_ok=True)
            filename = f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            output_file = results_path / filename
            if self._has_disk_headroom(results_path, 'hypervisor local fallback result storage'):
                with open(output_file, 'w') as f:
                    f.write(results.to_json())
                logger.info(f"Results saved locally: {output_file}")
            else:
                logger.error("Skipped local fallback result write due to low disk headroom")
                return False
            return True

        results.agent_id = self.agent_id
        results.platform = self.PLATFORM
        results.platform_version = self.platform_version

        response = self.api.post(
            f'/api/hypervisor-agent/{self.agent_id}/results',
            results.to_dict()
        )

        if response and response.get('success'):
            logger.info("Audit results submitted successfully")
            return True

        logger.error("Failed to submit audit results")
        return False

    def acknowledge_command(self, command_id: int, status: str, message: str = "") -> bool:
        """Acknowledge command execution status"""
        if not self.api:
            return False

        response = self.api.post(
            f'/api/hypervisor-agent/{self.agent_id}/commands/{command_id}/ack',
            {"status": status, "message": message}
        )
        return response and response.get('success', False)

    # =========================================================================
    # Daemon Mode
    # =========================================================================

    def run_daemon(self, poll_interval: int = 60):
        """
        Run agent in daemon mode, polling server for commands.

        Args:
            poll_interval: Seconds between polls
        """
        logger.info(f"Starting daemon mode (poll interval: {poll_interval}s)")

        # Initial registration
        if self.server_url and not self.registered:
            self.register()

        while True:
            try:
                # Send heartbeat and get commands
                commands = self.heartbeat()

                # Process commands
                for cmd in commands:
                    self._handle_command(cmd)

            except KeyboardInterrupt:
                logger.info("Daemon stopped by user")
                break
            except Exception as e:
                logger.error(f"Daemon error: {e}")

            time.sleep(poll_interval)

    def _handle_command(self, cmd: Command):
        """Handle a command from the server"""
        logger.info(f"Processing command: {cmd.type} (id={cmd.id})")

        try:
            if cmd.type == 'run_audit':
                self.acknowledge_command(cmd.id, 'started')
                categories = cmd.params.get('categories')
                results = self.run_audit(categories)
                results.finalize()
                self.submit_results(results)
                self.acknowledge_command(cmd.id, 'completed',
                                        f"Checks: {results.summary['total']}")

            elif cmd.type == 'discovery':
                self.acknowledge_command(cmd.id, 'started')
                info = self.get_system_info()
                self.api.post(f'/api/hypervisor-agent/{self.agent_id}/discovery', info)
                self.acknowledge_command(cmd.id, 'completed')

            elif cmd.type == 'update_config':
                self.config.update(cmd.params)
                self._save_config()
                self.acknowledge_command(cmd.id, 'completed', 'Config updated')

            elif cmd.type == 'key_rotation':
                self.acknowledge_command(cmd.id, 'started')
                new_token = cmd.params.get('new_token')
                if new_token:
                    # Update API key while preserving TLS settings
                    self.api_key = new_token
                    self.api = APIClient(
                        self.server_url,
                        self.api_key,
                        self.config.get('verify_ssl', True),
                        client_cert=self.client_cert,
                        client_key=self.client_key,
                        ca_bundle=self.ca_bundle
                    )
                    # Save to secure storage
                    self._save_api_key(new_token)
                    # Confirm rotation with server
                    self.api.post(f'/api/hypervisor-agent/{self.agent_id}/rotate-key/confirm', {})
                    self.acknowledge_command(cmd.id, 'completed', 'Key rotated')
                    logger.info("API key rotation completed successfully")
                else:
                    self.acknowledge_command(cmd.id, 'failed', 'No new token provided')

            else:
                logger.warning(f"Unknown command type: {cmd.type}")
                self.acknowledge_command(cmd.id, 'failed', f"Unknown command: {cmd.type}")

        except Exception as e:
            logger.error(f"Command {cmd.id} failed: {e}")
            self.acknowledge_command(cmd.id, 'failed', str(e))

    # =========================================================================
    # CLI Interface
    # =========================================================================

    def run_interactive(self):
        """Run in interactive mode with menu"""
        print(f"\n{'='*60}")
        print(f"  {self.PLATFORM_NAME} Security Audit Agent")
        print(f"  Agent ID: {self.agent_id}")
        print(f"  Platform Version: {self.platform_version}")
        print(f"{'='*60}\n")

        while True:
            print("\nOptions:")
            print("  1. Run full audit")
            print("  2. Run security audit only")
            print("  3. Show system info")
            print("  4. Register with server")
            print("  5. Start daemon mode")
            print("  6. Exit")

            choice = input("\nSelect option: ").strip()

            if choice == '1':
                results = self.run_audit()
                results.finalize()
                results.print_summary()
                self.submit_results(results)

            elif choice == '2':
                results = self.run_audit(categories=['security'])
                results.finalize()
                results.print_summary()

            elif choice == '3':
                info = self.get_system_info()
                print(json.dumps(info, indent=2))

            elif choice == '4':
                if self.register():
                    print("Registration successful!")
                else:
                    print("Registration failed.")

            elif choice == '5':
                interval = input("Poll interval (seconds) [60]: ").strip() or "60"
                self.run_daemon(int(interval))

            elif choice == '6':
                print("Goodbye!")
                break


# =============================================================================
# Utility Functions
# =============================================================================

def detect_hypervisor_platform() -> Optional[str]:
    """
    Auto-detect which hypervisor platform we're running on.

    Returns:
        Platform identifier (esxi, proxmox, xen, kvm, nutanix) or None
    """
    # Check for ESXi
    if os.path.exists('/etc/vmware/esx.conf'):
        return 'esxi'

    # Check for Proxmox
    if os.path.exists('/etc/pve') or os.path.exists('/usr/bin/pvesh'):
        return 'proxmox'

    # Check for XCP-ng / XenServer
    if os.path.exists('/etc/xensource') or os.path.exists('/opt/xensource'):
        return 'xen'

    # Check for Nutanix
    if os.path.exists('/home/nutanix') or os.path.exists('/usr/local/nutanix'):
        return 'nutanix'

    # Check for KVM/libvirt
    if os.path.exists('/var/lib/libvirt') or os.path.exists('/etc/libvirt'):
        return 'kvm'

    return None


def get_agent_class(platform: str):
    """
    Get the agent class for a specific platform.

    Args:
        platform: Platform identifier

    Returns:
        Agent class or None if not found
    """
    # Platform-specific imports (lazy loading)
    if platform == 'esxi':
        from .platforms.esxi import ESXiAgent
        return ESXiAgent
    elif platform == 'vcenter':
        from .platforms.vcenter import VCenterAgent
        return VCenterAgent
    elif platform == 'proxmox':
        from .platforms.proxmox import ProxmoxAgent
        return ProxmoxAgent
    elif platform == 'xen':
        from .platforms.xen import XenAgent
        return XenAgent
    elif platform == 'kvm':
        from .platforms.kvm import KVMAgent
        return KVMAgent
    elif platform == 'nutanix':
        from .platforms.nutanix import NutanixAgent
        return NutanixAgent

    return None


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for hypervisor agent"""
    import argparse

    parser = argparse.ArgumentParser(
        description='Hypervisor Security Audit Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('--mode', '-m',
                       choices=['interactive', 'daemon', 'audit', 'register', 'info'],
                       default='interactive',
                       help='Operation mode')
    parser.add_argument('--server', '-s', help='Server URL')
    parser.add_argument('--api-key', '-k', help='API key')
    parser.add_argument('--agent-id', help='Agent ID (auto-generated if not provided)')
    parser.add_argument('--platform', '-p',
                       choices=['esxi', 'vcenter', 'proxmox', 'xen', 'kvm', 'nutanix', 'auto'],
                       default='auto',
                       help='Hypervisor platform')
    parser.add_argument('--categories', '-c', nargs='+',
                       help='Audit categories to run')
    parser.add_argument('--poll-interval', type=int, default=60,
                       help='Daemon poll interval (seconds)')
    parser.add_argument('--output', '-o', help='Output file for results')
    parser.add_argument('--json', action='store_true', help='Output as JSON')

    # TLS/mTLS options for high-security environments
    tls_group = parser.add_argument_group('TLS Options (High Security)')
    tls_group.add_argument('--client-cert',
                          help='Path to client certificate (PEM) for mTLS')
    tls_group.add_argument('--client-key',
                          help='Path to client private key (PEM) for mTLS')
    tls_group.add_argument('--ca-bundle',
                          help='Path to CA certificate bundle for server verification')
    tls_group.add_argument('--no-verify-ssl', action='store_true',
                          help='Disable SSL verification (NOT recommended for production)')

    args = parser.parse_args()

    # Detect or use specified platform
    platform = args.platform
    if platform == 'auto':
        platform = detect_hypervisor_platform()
        if not platform:
            print("ERROR: Could not detect hypervisor platform")
            print("Please specify with --platform")
            sys.exit(1)

    # Get agent class
    AgentClass = get_agent_class(platform)
    if not AgentClass:
        print(f"ERROR: No agent available for platform: {platform}")
        sys.exit(1)

    # Create agent instance with TLS configuration
    agent = AgentClass(
        server_url=args.server,
        api_key=args.api_key,
        agent_id=args.agent_id,
        client_cert=args.client_cert,
        client_key=args.client_key,
        ca_bundle=args.ca_bundle
    )

    # Override SSL verification if explicitly disabled
    if args.no_verify_ssl and agent.api:
        agent.api.verify_ssl = False
        logger.warning("SSL verification disabled - NOT recommended for production")

    # Execute based on mode
    if args.mode == 'interactive':
        agent.run_interactive()

    elif args.mode == 'daemon':
        agent.run_daemon(args.poll_interval)

    elif args.mode == 'audit':
        results = agent.run_audit(args.categories)
        results.finalize()

        if args.json or args.output:
            output = results.to_json()
            if args.output:
                output_path = Path(args.output)
                output_dir = output_path.parent if output_path.parent != Path('') else Path.cwd()
                if agent._has_disk_headroom(output_dir, 'hypervisor CLI output storage'):
                    with open(output_path, 'w') as f:
                        f.write(output)
                    print(f"Results saved to {args.output}")
                else:
                    print("ERROR: Insufficient local disk headroom for output write")
                    sys.exit(1)
            else:
                print(output)
        else:
            results.print_summary()

        agent.submit_results(results)

    elif args.mode == 'register':
        if agent.register():
            print("Registration successful!")
        else:
            print("Registration failed.")
            sys.exit(1)

    elif args.mode == 'info':
        info = agent.get_system_info()
        print(json.dumps(info, indent=2))


if __name__ == '__main__':
    main()
