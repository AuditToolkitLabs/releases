"""
Hypervisor Fleet Agent - Platforms Package

Platform-specific agent implementations for various hypervisors:
- VMware ESXi
- VMware vCenter
- Proxmox VE
- XCP-ng / Citrix Hypervisor
- KVM/libvirt
- Nutanix AHV
"""

# Lazy imports to avoid loading unused platforms
_PLATFORM_CLASSES = {
    'esxi': ('.esxi', 'ESXiAgent'),
    'vcenter': ('.vcenter', 'VCenterAgent'),
    'proxmox': ('.proxmox', 'ProxmoxAgent'),
    'xen': ('.xen', 'XenAgent'),
    'kvm': ('.kvm', 'KVMAgent'),
    'nutanix': ('.nutanix', 'NutanixAgent'),
}


# Exported constant for discovered/supported platforms
SUPPORTED_PLATFORMS = {
    'esxi': 'VMware ESXi',
    'vcenter': 'VMware vCenter Server',
    'proxmox': 'Proxmox VE',
    'xen': 'XCP-ng / Citrix Hypervisor',
    'kvm': 'KVM/libvirt',
    'nutanix': 'Nutanix AHV',
}


def get_agent_class(platform: str):
    """
    Get the agent class for a specific platform.

    Args:
        platform: Platform identifier (esxi, vcenter, proxmox, xen, kvm, nutanix)

    Returns:
        Agent class or None if not found
    """
    if platform not in _PLATFORM_CLASSES:
        return None

    module_path, class_name = _PLATFORM_CLASSES[platform]

    try:
        import importlib
        module = importlib.import_module(module_path, package=__name__)
        return getattr(module, class_name)
    except (ImportError, AttributeError) as e:
        print(f"Warning: Could not load {platform} agent: {e}")
        return None


def get_agent(platform: str, **kwargs):
    """
    Get an instantiated agent for a specific platform.

    Args:
        platform: Platform identifier (esxi, vcenter, proxmox, xen, kvm, nutanix)
        **kwargs: Arguments to pass to agent constructor (server_url, api_key, etc.)

    Returns:
        Instantiated agent or None if platform not found
    """
    agent_class = get_agent_class(platform)
    if agent_class:
        return agent_class(**kwargs)
    return None


__all__ = ['get_agent_class', 'get_agent', 'SUPPORTED_PLATFORMS']
