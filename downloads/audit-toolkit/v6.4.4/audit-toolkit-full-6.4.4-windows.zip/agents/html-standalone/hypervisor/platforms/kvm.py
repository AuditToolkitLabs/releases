#!/usr/bin/env python3
"""
KVM/libvirt Fleet Agent

Security audit agent for KVM hypervisor using virsh and libvirt.
Communicates with central server via REST API only.

Supports:
- KVM on RHEL/CentOS, Ubuntu, Debian, Fedora
- libvirt 4.x, 5.x, 6.x, 7.x, 8.x, 9.x
- virsh CLI commands

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from ..core import AuditResults, HypervisorAgent, logger
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from core import AuditResults, HypervisorAgent, logger


class KVMAgent(HypervisorAgent):
    """
    KVM/libvirt Security Audit Agent

    Uses virsh CLI for security audits on KVM hypervisors.
    """

    PLATFORM = "kvm"
    PLATFORM_NAME = "KVM/libvirt"

    def __init__(self, connect_uri: str = "qemu:///system", **kwargs):
        """
        Initialize KVM agent.

        Args:
            connect_uri: libvirt connection URI (default: qemu:///system)
        """
        super().__init__(**kwargs)
        self.connect_uri = connect_uri
        self._virsh_available = self._check_virsh()

    def _check_virsh(self) -> bool:
        """Check if virsh is available"""
        try:
            result = subprocess.run(
                ['virsh', '--version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _virsh(self, *args: str) -> Optional[str]:
        """
        Execute virsh command.

        Returns:
            Command output or None on error
        """
        if not self._virsh_available:
            return None

        cmd = ['virsh', '-c', self.connect_uri] + list(args)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                return result.stdout.strip()
            logger.debug(f"virsh command failed: {result.stderr}")
        except subprocess.TimeoutExpired:
            logger.warning(f"virsh command timed out: {' '.join(cmd)}")
        except Exception as e:
            logger.debug(f"virsh command error: {e}")
        return None

    def _virsh_list(self, list_type: str = 'list', *extra_args: str) -> List[Dict[str, str]]:
        """
        Execute virsh list-type command and parse output.

        Args:
            list_type: virsh command (list, pool-list, net-list, etc.)
            *extra_args: Additional arguments

        Returns:
            List of parsed items
        """
        output = self._virsh(list_type, '--all', *extra_args)
        if not output:
            return []

        items = []
        lines = output.strip().split('\n')

        # Skip header lines (usually first 2 lines with dashes)
        # Note: Parsing happens below using header_found logic

        # Find actual data (skip header row)
        header_found = False
        for line in lines:
            if '---' in line or '===' in line:
                header_found = True
                continue
            if header_found and line.strip():
                parts = line.split()
                if parts:
                    items.append(parts)

        return items

    def _virsh_xml(self, obj_type: str, name: str) -> Optional[ET.Element]:
        """
        Get XML definition for virsh object.

        Args:
            obj_type: Object type (dumpxml, pool-dumpxml, net-dumpxml)
            name: Object name

        Returns:
            Parsed XML Element or None
        """
        output = self._virsh(obj_type, name)
        if not output:
            return None

        try:
            return ET.fromstring(output)  # nosec B314 - libvirt XML comes from trusted local virsh output
        except ET.ParseError as e:
            logger.debug(f"XML parse error for {obj_type} {name}: {e}")
            return None

    def _detect_platform_version(self) -> str:
        """Detect libvirt/KVM version"""
        if not self._virsh_available:
            return "unknown"

        # Get virsh version
        version_output = self._virsh('version')
        if version_output:
            for line in version_output.split('\n'):
                if 'libvirt' in line.lower():
                    parts = line.split()
                    if parts:
                        return parts[-1]

        # Fallback to virsh --version
        try:
            result = subprocess.run(
                ['virsh', '--version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass

        return "unknown"

    def get_system_info(self) -> Dict[str, Any]:
        """Get system information for discovery"""
        info = {
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": self.platform_version,
            "connect_uri": self.connect_uri,
            "hypervisor": None,
            "vms": {"total": 0, "running": 0},
            "storage_pools": [],
            "networks": []
        }

        if not self._virsh_available:
            return info

        # Get hypervisor info
        nodeinfo = self._virsh('nodeinfo')
        if nodeinfo:
            for line in nodeinfo.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    if 'CPU model' in key:
                        info["cpu_model"] = value.strip()
                    elif 'CPU(s)' == key.strip():
                        info["cpus"] = int(value.strip())
                    elif 'Memory size' in key:
                        info["memory_mb"] = int(value.strip().split()[0])

        # Get hypervisor type
        caps_output = self._virsh('capabilities')
        if caps_output:
            try:
                caps = ET.fromstring(caps_output)  # nosec B314 - capabilities XML is from local libvirt daemon
                guest = caps.find('.//guest/arch/domain[@type]')
                if guest is not None:
                    info["hypervisor"] = guest.get('type')
            except Exception:
                pass

        # List VMs
        vm_list = self._virsh('list', '--all')
        if vm_list:
            for line in vm_list.split('\n'):
                parts = line.split()
                if parts and parts[0].isdigit():
                    info["vms"]["total"] += 1
                    if len(parts) >= 3 and parts[2] == 'running':
                        info["vms"]["running"] += 1
                elif parts and parts[0] == '-':
                    info["vms"]["total"] += 1

        # Storage pools
        pool_list = self._virsh('pool-list', '--all')
        if pool_list:
            for line in pool_list.split('\n'):
                parts = line.split()
                if parts and parts[0] not in ('Name', '---', ''):
                    if len(parts) >= 2:
                        info["storage_pools"].append({
                            "name": parts[0],
                            "state": parts[1] if len(parts) > 1 else "unknown"
                        })

        # Networks
        net_list = self._virsh('net-list', '--all')
        if net_list:
            for line in net_list.split('\n'):
                parts = line.split()
                if parts and parts[0] not in ('Name', '---', ''):
                    if len(parts) >= 2:
                        info["networks"].append({
                            "name": parts[0],
                            "state": parts[1] if len(parts) > 1 else "unknown"
                        })

        return info

    # =========================================================================
    # Audit Implementation
    # =========================================================================

    def run_audit(self, categories: Optional[List[str]] = None) -> AuditResults:
        """
        Run KVM/libvirt security audit.

        Categories:
        - security: libvirtd config, SELinux/AppArmor, QEMU settings
        - network: Virtual networks, bridges, firewall rules
        - storage: Storage pools, volume encryption
        - compute: VM security settings, resource limits
        """
        results = AuditResults(
            platform=self.PLATFORM,
            platform_version=self.platform_version,
            agent_id=self.agent_id
        )

        if not self._virsh_available:
            results.register(
                "virsh CLI",
                "FAIL",
                "virsh command not available - libvirt not installed",
                category="security",
                severity="critical"
            )
            results.finalize()
            return results

        results.register("virsh CLI", "PASS", f"virsh available (libvirt {self.platform_version})", category="security")

        all_categories = ['security', 'network', 'storage', 'compute']
        run_categories = categories or all_categories

        if 'security' in run_categories:
            self._audit_security(results)

        if 'network' in run_categories:
            self._audit_network(results)

        if 'storage' in run_categories:
            self._audit_storage(results)

        if 'compute' in run_categories:
            self._audit_compute(results)

        results.finalize()
        results.print_summary()
        return results

    def _audit_security(self, results: AuditResults):
        """Security configuration audits"""
        results.section("Security Configuration")

        # Check libvirtd configuration
        libvirtd_conf = Path('/etc/libvirt/libvirtd.conf')
        if libvirtd_conf.exists():
            try:
                conf_content = libvirtd_conf.read_text()

                # Check for TLS
                if 'tls' in conf_content.lower() and 'listen_tls = 1' in conf_content:
                    results.register(
                        "TLS Listener",
                        "PASS",
                        "TLS listener enabled for remote connections",
                        category="security"
                    )
                else:
                    results.register(
                        "TLS Listener",
                        "WARN",
                        "TLS listener not explicitly enabled",
                        category="security",
                        severity="low"
                    )

                # Check for TCP without TLS
                if 'listen_tcp = 1' in conf_content:
                    if 'auth_tcp' not in conf_content or 'auth_tcp = "none"' in conf_content:
                        results.register(
                            "TCP Authentication",
                            "FAIL",
                            "Unauthenticated TCP listener enabled",
                            category="security",
                            severity="critical"
                        )
                    else:
                        results.register(
                            "TCP Authentication",
                            "WARN",
                            "TCP listener enabled - ensure proper authentication",
                            category="security",
                            severity="medium"
                        )

                # Check unix socket permissions
                if 'unix_sock_rw_perms' in conf_content:
                    results.register(
                        "Unix Socket Permissions",
                        "PASS",
                        "Custom socket permissions configured",
                        category="security"
                    )

            except Exception as e:
                logger.debug(f"Error reading libvirtd.conf: {e}")

        # Check QEMU configuration
        qemu_conf = Path('/etc/libvirt/qemu.conf')
        if qemu_conf.exists():
            try:
                qemu_content = qemu_conf.read_text()

                # Check for user/group settings
                if 'user = "root"' in qemu_content or '#user = "' in qemu_content:
                    results.register(
                        "QEMU User",
                        "WARN",
                        "QEMU may run as root - consider using qemu/libvirt-qemu user",
                        category="security",
                        severity="medium"
                    )
                else:
                    results.register(
                        "QEMU User",
                        "PASS",
                        "QEMU configured with non-root user",
                        category="security"
                    )

                # Check SELinux/AppArmor
                if 'security_driver' in qemu_content:
                    if 'selinux' in qemu_content.lower():
                        results.register(
                            "Security Driver",
                            "PASS",
                            "SELinux security driver configured",
                            category="security"
                        )
                    elif 'apparmor' in qemu_content.lower():
                        results.register(
                            "Security Driver",
                            "PASS",
                            "AppArmor security driver configured",
                            category="security"
                        )

            except Exception:
                pass

        # Check SELinux/AppArmor on host
        selinux_mode = None
        try:
            result = subprocess.run(['getenforce'], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                selinux_mode = result.stdout.strip()
        except Exception:
            pass

        if selinux_mode:
            if selinux_mode == 'Enforcing':
                results.register(
                    "SELinux",
                    "PASS",
                    "SELinux is enforcing",
                    category="security"
                )
            elif selinux_mode == 'Permissive':
                results.register(
                    "SELinux",
                    "WARN",
                    "SELinux is permissive - consider enforcing mode",
                    category="security",
                    severity="medium"
                )
            else:
                results.register(
                    "SELinux",
                    "FAIL",
                    "SELinux is disabled",
                    category="security",
                    severity="high"
                )
        else:
            # Check AppArmor
            apparmor_status = None
            try:
                result = subprocess.run(['aa-status', '--enabled'], capture_output=True, text=True, timeout=5)
                apparmor_status = result.returncode == 0
            except Exception:
                pass

            if apparmor_status:
                results.register(
                    "AppArmor",
                    "PASS",
                    "AppArmor is enabled",
                    category="security"
                )
            else:
                results.register(
                    "MAC Security",
                    "WARN",
                    "No SELinux or AppArmor detected",
                    category="security",
                    severity="medium"
                )

        # Check sVirt labeling
        svirt_enabled = False
        vm_list = self._virsh('list', '--all', '--name')
        if vm_list:
            for vm_name in vm_list.split('\n'):
                if vm_name.strip():
                    xml = self._virsh_xml('dumpxml', vm_name.strip())
                    if xml is not None:
                        seclabel = xml.find('.//seclabel')
                        if seclabel is not None and seclabel.get('type') == 'dynamic':
                            svirt_enabled = True
                            break

        if svirt_enabled:
            results.register(
                "sVirt Labeling",
                "PASS",
                "sVirt dynamic labeling in use",
                category="security"
            )

    def _audit_network(self, results: AuditResults):
        """Network configuration audits"""
        results.section("Network Configuration")

        # List virtual networks
        net_list = self._virsh('net-list', '--all')
        networks = []
        if net_list:
            for line in net_list.split('\n'):
                parts = line.split()
                if parts and parts[0] not in ('Name', '---', ''):
                    networks.append({'name': parts[0], 'active': len(parts) > 1 and parts[1] == 'active'})

        results.register(
            "Virtual Networks",
            "PASS",
            f"{len(networks)} virtual network(s) configured",
            category="network"
        )

        # Check network configurations
        for net in networks:
            net_xml = self._virsh_xml('net-dumpxml', net['name'])
            if net_xml is not None:
                # Check for NAT vs isolated
                forward = net_xml.find('.//forward')
                if forward is not None:
                    mode = forward.get('mode', 'nat')
                    if mode == 'nat':
                        results.register(
                            f"Network {net['name']}",
                            "PASS",
                            "NAT network - provides isolation",
                            category="network"
                        )
                    elif mode == 'bridge':
                        results.register(
                            f"Network {net['name']}",
                            "WARN",
                            "Bridge mode - VMs exposed to physical network",
                            category="network",
                            severity="low"
                        )
                else:
                    results.register(
                        f"Network {net['name']}",
                        "PASS",
                        "Isolated network (no forwarding)",
                        category="network"
                    )

                # Check for DHCP
                dhcp = net_xml.find('.//dhcp')
                if dhcp is not None:
                    results.register(
                        f"DHCP on {net['name']}",
                        "PASS",
                        "DHCP server configured",
                        category="network"
                    )

        # Check nwfilter rules
        nwfilter_list = self._virsh('nwfilter-list')
        if nwfilter_list:
            filters = [line for line in nwfilter_list.split('\n') if line.strip() and 'UUID' not in line and '---' not in line]
            if filters:
                results.register(
                    "Network Filters",
                    "PASS",
                    f"{len(filters)} nwfilter rule(s) available",
                    category="network"
                )

    def _audit_storage(self, results: AuditResults):
        """Storage configuration audits"""
        results.section("Storage Configuration")

        # List storage pools
        pool_list = self._virsh('pool-list', '--all')
        pools = []
        if pool_list:
            for line in pool_list.split('\n'):
                parts = line.split()
                if parts and parts[0] not in ('Name', '---', ''):
                    pools.append({
                        'name': parts[0],
                        'active': len(parts) > 1 and parts[1] == 'active'
                    })

        results.register(
            "Storage Pools",
            "PASS",
            f"{len(pools)} storage pool(s) configured",
            category="storage"
        )

        for pool in pools:
            pool_xml = self._virsh_xml('pool-dumpxml', pool['name'])
            if pool_xml is not None:
                pool_type = pool_xml.get('type', 'unknown')

                # Check pool type
                if pool_type == 'rbd':
                    results.register(
                        f"Pool {pool['name']}",
                        "PASS",
                        "Ceph RBD storage with redundancy",
                        category="storage"
                    )
                elif pool_type == 'iscsi':
                    results.register(
                        f"Pool {pool['name']}",
                        "WARN",
                        "iSCSI storage - verify CHAP authentication",
                        category="storage",
                        severity="low"
                    )
                elif pool_type == 'dir':
                    target = pool_xml.find('.//target/path')
                    if target is not None:
                        path = target.text
                        # Check permissions on directory
                        try:
                            dir_path = Path(path)
                            if dir_path.exists():
                                mode = dir_path.stat().st_mode & 0o777
                                if mode & 0o007:
                                    results.register(
                                        f"Pool {pool['name']}",
                                        "WARN",
                                        f"World-readable/writable permissions ({oct(mode)})",
                                        category="storage",
                                        severity="medium"
                                    )
                        except Exception:
                            pass

        # Check for encryption support
        secrets = self._virsh('secret-list')
        if secrets:
            secret_count = len([line for line in secrets.split('\n') if line.strip() and 'UUID' not in line and '---' not in line])
            if secret_count > 0:
                results.register(
                    "Secrets Manager",
                    "PASS",
                    f"{secret_count} secret(s) defined for encryption",
                    category="storage"
                )

    def _audit_compute(self, results: AuditResults):
        """Compute configuration audits"""
        results.section("Compute Configuration")

        # Get VM list
        vm_list = self._virsh('list', '--all', '--name')
        vms = [v.strip() for v in vm_list.split('\n') if v.strip()] if vm_list else []

        running_count = 0
        for vm in vms:
            state = self._virsh('domstate', vm)
            if state and 'running' in state:
                running_count += 1

        results.register(
            "Virtual Machines",
            "PASS",
            f"{len(vms)} VM(s), {running_count} running",
            category="compute"
        )

        # Check VM security settings
        for vm in vms[:10]:  # Sample first 10 VMs
            xml = self._virsh_xml('dumpxml', vm)
            if xml is None:
                continue

            issues = []

            # Check for UEFI/Secure Boot
            os_elem = xml.find('.//os')
            if os_elem is not None:
                loader = os_elem.find('loader')
                if loader is not None and 'OVMF' in (loader.text or ''):
                    pass  # UEFI enabled
                else:
                    issues.append("No UEFI")

            # Check for memory balloon disabled
            memballoon = xml.find('.//memballoon')
            if memballoon is not None and memballoon.get('model') == 'none':
                issues.append("Memory balloon disabled")

            # Check for CPU pinning
            vcpu = xml.find('.//vcpu')
            if vcpu is not None and vcpu.get('cpuset'):
                pass  # CPU pinning in place

            # Check for secure video
            video = xml.find('.//video/model')
            if video is not None and video.get('type') == 'virtio':
                pass  # Virtio video (more secure)

            if issues:
                results.register(
                    f"VM {vm[:20]}",
                    "WARN",
                    f"Security considerations: {', '.join(issues)}",
                    category="compute",
                    severity="low"
                )

        # Check resource limits
        for vm in vms[:5]:
            memtune = self._virsh('memtune', vm)
            if memtune and 'unlimited' in memtune.lower():
                results.register(
                    f"Memory Limits {vm[:15]}",
                    "WARN",
                    "No memory limits configured",
                    category="compute",
                    severity="low"
                )


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for standalone execution"""
    import argparse

    parser = argparse.ArgumentParser(description="KVM/libvirt Security Audit Agent")
    parser.add_argument('--connect', '-c', default='qemu:///system',
                        help='libvirt connection URI (default: qemu:///system)')
    parser.add_argument('--server', help='Central audit server URL')
    parser.add_argument('--api-key', help='API key for audit server')
    parser.add_argument('--categories', nargs='+', help='Categories to audit')
    parser.add_argument('--output', '-o', help='Output file for results (JSON)')

    args = parser.parse_args()

    agent = KVMAgent(
        connect_uri=args.connect,
        server_url=args.server,
        api_key=args.api_key
    )

    print("KVM/libvirt Agent v1.0.0")
    print(f"Platform: {agent.PLATFORM_NAME}")
    print(f"Version: {agent.platform_version}")
    print(f"Connection: {agent.connect_uri}")
    print(f"Agent ID: {agent.agent_id}")
    print()

    # Run audit
    results = agent.run_audit(categories=args.categories)

    # Output results
    if args.output:
        with open(args.output, 'w') as f:
            f.write(results.to_json())
        print(f"\nResults written to {args.output}")

    # Submit to server if connected
    if agent.api and agent.registered:
        agent.submit_results(results)


if __name__ == '__main__':
    main()
