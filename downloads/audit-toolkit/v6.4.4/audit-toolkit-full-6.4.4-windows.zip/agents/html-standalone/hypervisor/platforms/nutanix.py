#!/usr/bin/env python3
"""
Nutanix AHV Fleet Agent

Security audit agent for Nutanix AHV using acli and Prism REST API.
Communicates with central server via REST API only.

Supports:
- Nutanix AHV (Acropolis Hypervisor)
- Prism Element and Prism Central
- acli CLI (on CVM) and REST API (remote)

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import json
import ssl
import subprocess
import urllib.request
import urllib.error
from base64 import b64encode
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from ..core import AuditResults, HypervisorAgent, logger
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from core import AuditResults, HypervisorAgent, logger


class NutanixAgent(HypervisorAgent):
    """
    Nutanix AHV Security Audit Agent

    Uses acli CLI on CVM or Prism REST API for security audits.
    """

    PLATFORM = "nutanix"
    PLATFORM_NAME = "Nutanix AHV"

    def __init__(self, prism_host: Optional[str] = None, prism_user: Optional[str] = None,
                 prism_password: Optional[str] = None, verify_ssl: bool = True, **kwargs):
        """
        Initialize Nutanix agent.

        Args:
            prism_host: Prism Element/Central hostname/IP
            prism_user: Prism username
            prism_password: Prism password
            verify_ssl: Verify SSL certificates
        """
        super().__init__(**kwargs)

        # Prism API settings
        self.prism_host = prism_host or self.config.get('prism_host')
        self.prism_user = prism_user or self.config.get('prism_user')
        self.prism_password = prism_password or self.config.get('prism_password')
        self.verify_ssl = verify_ssl

        # API base URL
        self.api_v2_base = f"https://{self.prism_host}:9440/api/nutanix/v2.0" if self.prism_host else None
        self.api_v3_base = f"https://{self.prism_host}:9440/api/nutanix/v3" if self.prism_host else None

        # SSL context
        self.ssl_context = ssl.create_default_context()
        if not verify_ssl:
            self.ssl_context.check_hostname = False
            self.ssl_context.verify_mode = ssl.CERT_NONE

        # Check available methods
        self._acli_available = self._check_acli()
        self._api_available = self._check_api()

    def _check_acli(self) -> bool:
        """Check if acli is available (running on CVM)"""
        try:
            result = subprocess.run(
                ['acli', '--version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _check_api(self) -> bool:
        """Check if Prism API is accessible"""
        if not self.prism_host or not self.prism_user:
            return False

        try:
            self._api_get('/cluster', api_version=2)
            return True
        except Exception:
            return False

    def _acli(self, *args: str) -> Optional[str]:
        """Execute acli command"""
        if not self._acli_available:
            return None

        cmd = ['acli'] + list(args)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                return result.stdout.strip()
            logger.debug(f"acli command failed: {result.stderr}")
        except subprocess.TimeoutExpired:
            logger.warning(f"acli command timed out: {' '.join(cmd)}")
        except Exception as e:
            logger.debug(f"acli command error: {e}")
        return None

    def _api_get(self, endpoint: str, api_version: int = 2) -> Optional[Dict]:
        """Make authenticated GET request to Prism API"""
        if not self.prism_host:
            return None

        base = self.api_v2_base if api_version == 2 else self.api_v3_base
        url = f"{base}{endpoint}"
        auth_str = b64encode(f"{self.prism_user}:{self.prism_password}".encode()).decode()

        try:
            req = urllib.request.Request(url)
            req.add_header('Authorization', f'Basic {auth_str}')
            req.add_header('Content-Type', 'application/json')

            with urllib.request.urlopen(req, context=self.ssl_context, timeout=30) as response:  # nosec B310 - URL is restricted to configured Prism endpoint
                return json.loads(response.read().decode())
        except Exception as e:
            logger.debug(f"API GET {endpoint} failed: {e}")
        return None

    def _api_post(self, endpoint: str, data: Optional[Dict] = None, api_version: int = 3) -> Optional[Dict]:
        """Make authenticated POST request to Prism API"""
        if not self.prism_host:
            return None

        base = self.api_v2_base if api_version == 2 else self.api_v3_base
        url = f"{base}{endpoint}"
        auth_str = b64encode(f"{self.prism_user}:{self.prism_password}".encode()).decode()

        try:
            body = json.dumps(data or {}).encode()
            req = urllib.request.Request(url, data=body, method='POST')
            req.add_header('Authorization', f'Basic {auth_str}')
            req.add_header('Content-Type', 'application/json')

            with urllib.request.urlopen(req, context=self.ssl_context, timeout=30) as response:  # nosec B310 - URL is restricted to configured Prism endpoint
                return json.loads(response.read().decode())
        except Exception as e:
            logger.debug(f"API POST {endpoint} failed: {e}")
        return None

    def _detect_platform_version(self) -> str:
        """Detect Nutanix AOS version"""
        # Try acli first
        if self._acli_available:
            version_output = self._acli('version')
            if version_output:
                return version_output.strip()

        # Try API
        if self._api_available:
            cluster = self._api_get('/cluster', api_version=2)
            if cluster:
                return cluster.get('version', 'unknown')

        return "unknown"

    def get_system_info(self) -> Dict[str, Any]:
        """Get system information for discovery"""
        info = {
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": self.platform_version,
            "cluster_name": None,
            "hosts": [],
            "vms": {"total": 0, "powered_on": 0},
            "storage_containers": [],
            "networks": []
        }

        if self._api_available:
            # Cluster info
            cluster = self._api_get('/cluster', api_version=2)
            if cluster:
                info["cluster_name"] = cluster.get('name')
                info["cluster_uuid"] = cluster.get('uuid')

            # Hosts
            hosts = self._api_get('/hosts', api_version=2)
            if hosts and 'entities' in hosts:
                info["hosts"] = [
                    {
                        "name": h.get('name'),
                        "uuid": h.get('uuid'),
                        "serial": h.get('serial')
                    }
                    for h in hosts['entities']
                ]

            # VMs
            vms = self._api_get('/vms', api_version=2)
            if vms and 'entities' in vms:
                info["vms"]["total"] = len(vms['entities'])
                info["vms"]["powered_on"] = len([v for v in vms['entities'] if v.get('power_state') == 'on'])

            # Storage containers
            containers = self._api_get('/storage_containers', api_version=2)
            if containers and 'entities' in containers:
                info["storage_containers"] = [
                    {
                        "name": c.get('name'),
                        "uuid": c.get('storage_container_uuid')
                    }
                    for c in containers['entities']
                ]

            # Networks
            networks = self._api_get('/networks', api_version=2)
            if networks and 'entities' in networks:
                info["networks"] = [
                    {
                        "name": n.get('name'),
                        "uuid": n.get('uuid'),
                        "vlan_id": n.get('vlan_id')
                    }
                    for n in networks['entities']
                ]

        elif self._acli_available:
            # Use acli commands
            cluster_info = self._acli('cluster.get')
            if cluster_info:
                for line in cluster_info.split('\n'):
                    if 'name:' in line.lower():
                        info["cluster_name"] = line.split(':')[1].strip()

            host_list = self._acli('host.list')
            if host_list:
                info["hosts"] = [{"name": h.strip()} for h in host_list.split('\n') if h.strip()]

            vm_list = self._acli('vm.list')
            if vm_list:
                vms = [line.strip() for line in vm_list.split('\n') if line.strip()]
                info["vms"]["total"] = len(vms)

        return info

    # =========================================================================
    # Audit Implementation
    # =========================================================================

    def run_audit(self, categories: Optional[List[str]] = None) -> AuditResults:
        """
        Run Nutanix security audit.

        Categories:
        - security: Cluster authentication, encryption, STIG compliance
        - network: AHV networking, VLAN security, Flow
        - storage: Storage containers, encryption, deduplication
        - compute: VM security settings, resource policies
        """
        results = AuditResults(
            platform=self.PLATFORM,
            platform_version=self.platform_version,
            agent_id=self.agent_id
        )

        if not self._acli_available and not self._api_available:
            results.register(
                "Nutanix Connection",
                "FAIL",
                "Cannot connect to Nutanix - no acli or API access",
                category="security",
                severity="critical"
            )
            results.finalize()
            return results

        if self._api_available:
            results.register("Prism API", "PASS", f"Connected to {self.prism_host}", category="security")
        if self._acli_available:
            results.register("acli CLI", "PASS", "acli available on CVM", category="security")

        all_categories = ['security', 'network', 'storage', 'compute']
        run_categories = categories or all_categories

        if 'security' in run_categories:
            self._audit_security(results)

        if 'network' in run_categories:
            self._audit_network(results)

        if 'storage' in run_categories:
            self._audit_storage(results)

        if 'compute' in run_categories:
            self._audit_compute(results)

        results.finalize()
        results.print_summary()
        return results

    def _audit_security(self, results: AuditResults):
        """Security configuration audits"""
        results.section("Security Configuration")

        if self._api_available:
            # Cluster configuration
            cluster = self._api_get('/cluster', api_version=2)
            if cluster:
                # Check encryption at rest
                if cluster.get('cluster_encryption_status', {}).get('software_encryption_enabled'):
                    results.register(
                        "Encryption at Rest",
                        "PASS",
                        "Software encryption enabled",
                        category="security"
                    )
                else:
                    results.register(
                        "Encryption at Rest",
                        "WARN",
                        "Software encryption not enabled - consider enabling",
                        category="security",
                        severity="medium",
                        compliance=["Nutanix Security Guide"]
                    )

                # Check external authentication
                auth_config = cluster.get('external_authentication_config', {})
                if auth_config.get('auth_type'):
                    results.register(
                        "External Auth",
                        "PASS",
                        f"External authentication configured: {auth_config.get('auth_type')}",
                        category="security"
                    )
                else:
                    results.register(
                        "External Auth",
                        "WARN",
                        "No external authentication (AD/LDAP) configured",
                        category="security",
                        severity="low"
                    )

            # Check users and roles
            users = self._api_get('/users', api_version=2)
            if users and 'entities' in users:
                admin_users = [u for u in users['entities'] if u.get('role') == 'ROLE_CLUSTER_ADMIN']
                results.register(
                    "Admin Users",
                    "PASS" if len(admin_users) <= 5 else "WARN",
                    f"{len(admin_users)} cluster admin(s) configured",
                    category="security",
                    severity="low" if len(admin_users) > 5 else "low"
                )

            # Check certificate configuration
            certs = self._api_get('/cluster/certificate', api_version=2)
            if certs:
                results.register(
                    "SSL Certificate",
                    "PASS",
                    "Custom SSL certificate configured",
                    category="security"
                )
            else:
                results.register(
                    "SSL Certificate",
                    "WARN",
                    "Using self-signed certificate - consider installing CA-signed cert",
                    category="security",
                    severity="low"
                )

            # Check SNMP configuration
            snmp = self._api_get('/cluster/snmp', api_version=2)
            if snmp and snmp.get('enabled'):
                if snmp.get('snmp_users'):
                    results.register(
                        "SNMP",
                        "PASS",
                        "SNMPv3 configured",
                        category="security"
                    )
                else:
                    results.register(
                        "SNMP",
                        "WARN",
                        "SNMP enabled but not using v3 - consider SNMPv3",
                        category="security",
                        severity="medium"
                    )

        # CVM SSH check (if on CVM)
        if self._acli_available:
            try:
                ssh_config = Path('/etc/ssh/sshd_config')
                if ssh_config.exists():
                    content = ssh_config.read_text()
                    if 'PermitRootLogin yes' in content:
                        results.register(
                            "CVM SSH Root",
                            "WARN",
                            "Root SSH login permitted on CVM",
                            category="security",
                            severity="medium"
                        )
            except Exception:
                pass

    def _audit_network(self, results: AuditResults):
        """Network configuration audits"""
        results.section("Network Configuration")

        if self._api_available:
            # Networks
            networks = self._api_get('/networks', api_version=2)
            if networks and 'entities' in networks:
                nets = networks['entities']
                results.register(
                    "Virtual Networks",
                    "PASS",
                    f"{len(nets)} virtual network(s) configured",
                    category="network"
                )

                # Check VLAN configuration
                vlan_nets = [n for n in nets if n.get('vlan_id')]
                if vlan_nets:
                    results.register(
                        "VLAN Segmentation",
                        "PASS",
                        f"{len(vlan_nets)} network(s) using VLAN segmentation",
                        category="network"
                    )

                # Check for IP address management
                ipam_nets = [n for n in nets if n.get('ip_config')]
                if ipam_nets:
                    results.register(
                        "IPAM",
                        "PASS",
                        f"{len(ipam_nets)} network(s) using Nutanix IPAM",
                        category="network"
                    )

            # Check Flow (microsegmentation) if available
            # Note: Flow requires Prism Central v3 API
            if self.api_v3_base:
                flow_rules = self._api_post('/security_rules/list', {"kind": "security_rule"}, api_version=3)
                if flow_rules and flow_rules.get('entities'):
                    rules = flow_rules['entities']
                    results.register(
                        "Flow Security Rules",
                        "PASS",
                        f"{len(rules)} microsegmentation rule(s) configured",
                        category="network"
                    )
                else:
                    results.register(
                        "Flow Microsegmentation",
                        "SKIP",
                        "Flow not configured or not accessible",
                        category="network"
                    )

        elif self._acli_available:
            net_list = self._acli('net.list')
            if net_list:
                nets = [line.strip() for line in net_list.split('\n') if line.strip()]
                results.register(
                    "Virtual Networks",
                    "PASS",
                    f"{len(nets)} virtual network(s) configured",
                    category="network"
                )

    def _audit_storage(self, results: AuditResults):
        """Storage configuration audits"""
        results.section("Storage Configuration")

        if self._api_available:
            # Storage containers
            containers = self._api_get('/storage_containers', api_version=2)
            if containers and 'entities' in containers:
                sc_list = containers['entities']
                results.register(
                    "Storage Containers",
                    "PASS",
                    f"{len(sc_list)} storage container(s) configured",
                    category="storage"
                )

                for sc in sc_list[:5]:
                    # Check compression/deduplication
                    features = []
                    if sc.get('compression_enabled'):
                        features.append("Compression")
                    if sc.get('on_disk_dedup') == 'POST_PROCESS':
                        features.append("Deduplication")
                    if sc.get('erasure_code') == 'ON':
                        features.append("EC-X")

                    if features:
                        results.register(
                            f"Container {sc.get('name', 'unnamed')[:20]}",
                            "PASS",
                            f"Features: {', '.join(features)}",
                            category="storage"
                        )

            # Storage pools
            pools = self._api_get('/storage_pools', api_version=2)
            if pools and 'entities' in pools:
                results.register(
                    "Storage Pools",
                    "PASS",
                    f"{len(pools['entities'])} storage pool(s)",
                    category="storage"
                )

            # Check disk status
            disks = self._api_get('/disks', api_version=2)
            if disks and 'entities' in disks:
                failed = [d for d in disks['entities'] if d.get('disk_status') != 'NORMAL']
                if failed:
                    results.register(
                        "Disk Health",
                        "WARN",
                        f"{len(failed)} disk(s) not in normal state",
                        category="storage",
                        severity="high"
                    )
                else:
                    results.register(
                        "Disk Health",
                        "PASS",
                        f"All {len(disks['entities'])} disk(s) healthy",
                        category="storage"
                    )

        elif self._acli_available:
            # Use acli commands
            container_list = self._acli('container.list')
            if container_list:
                containers = [line.strip() for line in container_list.split('\n') if line.strip()]
                results.register(
                    "Storage Containers",
                    "PASS",
                    f"{len(containers)} storage container(s)",
                    category="storage"
                )

    def _audit_compute(self, results: AuditResults):
        """Compute configuration audits"""
        results.section("Compute Configuration")

        if self._api_available:
            # VMs
            vms = self._api_get('/vms', api_version=2)
            if vms and 'entities' in vms:
                vm_list = vms['entities']
                powered_on = len([v for v in vm_list if v.get('power_state') == 'on'])
                results.register(
                    "Virtual Machines",
                    "PASS",
                    f"{len(vm_list)} VM(s), {powered_on} powered on",
                    category="compute"
                )

                # Check for VMs without NGT
                no_ngt = [v for v in vm_list if not v.get('nutanix_guest_tools', {}).get('enabled')]
                if no_ngt and len(no_ngt) <= len(vm_list):
                    results.register(
                        "Nutanix Guest Tools",
                        "WARN" if no_ngt else "PASS",
                        f"{len(vm_list) - len(no_ngt)}/{len(vm_list)} VM(s) have NGT enabled",
                        category="compute",
                        severity="low"
                    )

            # Hosts
            hosts = self._api_get('/hosts', api_version=2)
            if hosts and 'entities' in hosts:
                host_list = hosts['entities']
                degraded = [h for h in host_list if h.get('state') != 'NORMAL']
                if degraded:
                    results.register(
                        "Host Health",
                        "WARN",
                        f"{len(degraded)} host(s) not in normal state",
                        category="compute",
                        severity="high"
                    )
                else:
                    results.register(
                        "Host Health",
                        "PASS",
                        f"All {len(host_list)} host(s) healthy",
                        category="compute"
                    )

            # Check cluster data resiliency
            cluster = self._api_get('/cluster', api_version=2)
            if cluster:
                rf = cluster.get('cluster_redundancy_state', {}).get('desired_redundancy_factor')
                if rf and rf >= 2:
                    results.register(
                        "Data Resiliency",
                        "PASS",
                        f"Replication factor: {rf}",
                        category="compute"
                    )
                else:
                    results.register(
                        "Data Resiliency",
                        "WARN",
                        f"Replication factor should be 2 or higher (current: {rf})",
                        category="compute",
                        severity="high"
                    )

            # Protection domains
            pds = self._api_get('/protection_domains', api_version=2)
            if pds and 'entities' in pds:
                active = [p for p in pds['entities'] if p.get('active')]
                results.register(
                    "Protection Domains",
                    "PASS",
                    f"{len(active)} active protection domain(s)",
                    category="compute"
                )

        elif self._acli_available:
            vm_list = self._acli('vm.list')
            if vm_list:
                vms = [line.strip() for line in vm_list.split('\n') if line.strip()]
                results.register(
                    "Virtual Machines",
                    "PASS",
                    f"{len(vms)} VM(s) found",
                    category="compute"
                )

            host_list = self._acli('host.list')
            if host_list:
                hosts = [line.strip() for line in host_list.split('\n') if line.strip()]
                results.register(
                    "Hosts",
                    "PASS",
                    f"{len(hosts)} host(s) in cluster",
                    category="compute"
                )


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for standalone execution"""
    import argparse
    import getpass

    parser = argparse.ArgumentParser(description="Nutanix Security Audit Agent")
    parser.add_argument('--prism', help='Prism Element/Central hostname/IP')
    parser.add_argument('--user', help='Prism username')
    parser.add_argument('--password', help='Prism password (prompted if not provided)')
    parser.add_argument('--no-verify-ssl', action='store_true', help='Skip SSL verification')
    parser.add_argument('--server', help='Central audit server URL')
    parser.add_argument('--api-key', help='API key for audit server')
    parser.add_argument('--categories', nargs='+', help='Categories to audit')
    parser.add_argument('--output', '-o', help='Output file for results (JSON)')

    args = parser.parse_args()

    password = None
    if args.prism and args.user:
        password = args.password or getpass.getpass('Prism Password: ')

    agent = NutanixAgent(
        prism_host=args.prism,
        prism_user=args.user,
        prism_password=password,
        verify_ssl=not args.no_verify_ssl,
        server_url=args.server,
        api_key=args.api_key
    )

    print("Nutanix Agent v1.0.0")
    print(f"Platform: {agent.PLATFORM_NAME}")
    print(f"Version: {agent.platform_version}")
    if agent.prism_host:
        print(f"Prism: {agent.prism_host}")
    print(f"Agent ID: {agent.agent_id}")
    print()

    # Run audit
    results = agent.run_audit(categories=args.categories)

    # Output results
    if args.output:
        with open(args.output, 'w') as f:
            f.write(results.to_json())
        print(f"\nResults written to {args.output}")

    # Submit to server if connected
    if agent.api and agent.registered:
        agent.submit_results(results)


if __name__ == '__main__':
    main()
