#!/usr/bin/env python3
"""
Proxmox VE Fleet Agent

Security audit agent for Proxmox VE hypervisors using native API and CLI tools.
Communicates with central server via REST API only.

Supports:
- Proxmox VE 7.x and 8.x
- Cluster and standalone configurations
- Security, network, storage, and compute audits

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import json
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

# Import from parent - handle both package and direct execution
try:
    from ..core import AuditResults, HypervisorAgent, logger
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from core import AuditResults, HypervisorAgent, logger


class ProxmoxAgent(HypervisorAgent):
    """
    Proxmox VE Security Audit Agent

    Uses native Proxmox tools (pvesm, pvesh, qm, pct, etc.) for security audits.
    Communicates with central server via API only.
    """

    PLATFORM = "proxmox"
    PLATFORM_NAME = "Proxmox VE"

    def __init__(self, **kwargs):
        """Initialize Proxmox agent"""
        super().__init__(**kwargs)

        # Proxmox-specific paths
        self.pve_config_path = Path("/etc/pve")
        self.storage_config = self.pve_config_path / "storage.cfg"
        self.user_config = self.pve_config_path / "user.cfg"
        self.datacenter_config = self.pve_config_path / "datacenter.cfg"

        # Detect Proxmox API availability
        self.api_available = self._check_api_available()

    def _check_api_available(self) -> bool:
        """Check if Proxmox API tools are available"""
        try:
            result = subprocess.run(['pvesh', '--version'], capture_output=True)
            return result.returncode == 0
        except FileNotFoundError:
            return False

    def _detect_platform_version(self) -> str:
        """Detect Proxmox VE version"""
        try:
            result = self.run_command(['pveversion'])
            # Format: pve-manager/8.1.3/ec5affc9e41f1d31 (running kernel: 6.5.11-4-pve)
            if result.returncode == 0:
                match = re.search(r'pve-manager/(\d+\.\d+(?:\.\d+)?)', result.stdout)
                if match:
                    return match.group(1)
        except Exception as e:
            logger.warning(f"Failed to detect Proxmox version: {e}")
        return "unknown"

    def _pvesh_get(self, path: str) -> Optional[Dict]:
        """Execute pvesh get command and return JSON"""
        try:
            result = self.run_command(['pvesh', 'get', path, '--output-format', 'json'])
            if result.returncode == 0:
                return json.loads(result.stdout)
        except Exception as e:
            logger.debug(f"pvesh get {path} failed: {e}")
        return None

    def _read_config_file(self, path: Path) -> str:
        """Safely read a config file"""
        try:
            if path.exists():
                return path.read_text()
        except PermissionError:
            logger.warning(f"Permission denied: {path}")
        except Exception as e:
            logger.warning(f"Failed to read {path}: {e}")
        return ""

    def get_system_info(self) -> Dict[str, Any]:
        """Get Proxmox system information for discovery"""
        info = {
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": self.platform_version,
            "hostname": self._get_hostname(),
            "cluster": self._get_cluster_info(),
            "nodes": [],
            "vms": {"qemu": 0, "lxc": 0},
            "storage": [],
            "network": [],
            "cpu": {},
            "memory": {}
        }

        # Get node info
        nodes = self._pvesh_get('/nodes') or []
        info["nodes"] = [n.get('node') for n in nodes if n.get('node')]

        # Get VM counts
        for node in info["nodes"]:
            qemu = self._pvesh_get(f'/nodes/{node}/qemu') or []
            lxc = self._pvesh_get(f'/nodes/{node}/lxc') or []
            info["vms"]["qemu"] += len(qemu)
            info["vms"]["lxc"] += len(lxc)

        # Storage info
        storage = self._pvesh_get('/storage') or []
        info["storage"] = [{"id": s.get('storage'), "type": s.get('type')} for s in storage]

        # Hardware info from /proc
        info["cpu"] = self._get_cpu_info()
        info["memory"] = self._get_memory_info()

        return info

    def _get_hostname(self) -> str:
        """Get system hostname"""
        try:
            result = self.run_command(['hostname'])
            return result.stdout.strip() if result.returncode == 0 else "unknown"
        except Exception:
            return "unknown"

    def _get_cluster_info(self) -> Optional[Dict]:
        """Get cluster information if in cluster mode"""
        cluster = self._pvesh_get('/cluster/status')
        if cluster:
            for item in cluster:
                if item.get('type') == 'cluster':
                    return {
                        "name": item.get('name'),
                        "nodes": item.get('nodes'),
                        "quorate": item.get('quorate')
                    }
        return None

    def _get_cpu_info(self) -> Dict:
        """Get CPU information"""
        info = {"cores": 0, "model": ""}
        try:
            cpuinfo = Path("/proc/cpuinfo").read_text()
            cores = len(re.findall(r'^processor\s+:', cpuinfo, re.MULTILINE))
            model = ""
            model_match = re.search(r'model name\s+:\s+(.+)', cpuinfo)
            if model_match:
                model = model_match.group(1)
            info = {"cores": cores, "model": model}
        except Exception:
            pass
        return info

    def _get_memory_info(self) -> Dict:
        """Get memory information"""
        info = {"total_mb": 0, "free_mb": 0}
        try:
            meminfo = Path("/proc/meminfo").read_text()
            total = re.search(r'MemTotal:\s+(\d+)', meminfo)
            free = re.search(r'MemAvailable:\s+(\d+)', meminfo)
            if total:
                info["total_mb"] = int(total.group(1)) // 1024
            if free:
                info["free_mb"] = int(free.group(1)) // 1024
        except Exception:
            pass
        return info

    # =========================================================================
    # Audit Implementation
    # =========================================================================

    def run_audit(self, categories: List[str] = None) -> AuditResults:
        """
        Run Proxmox security audit.

        Categories:
        - security: Authentication, permissions, API security
        - network: Firewall, bridges, VLANs
        - storage: Storage security, backups
        - compute: VM/CT security configurations
        """
        results = AuditResults(
            platform=self.PLATFORM,
            platform_version=self.platform_version,
            agent_id=self.agent_id
        )

        all_categories = ['security', 'network', 'storage', 'compute']
        selected = categories if categories else all_categories

        if 'security' in selected:
            self._audit_security(results)

        if 'network' in selected:
            self._audit_network(results)

        if 'storage' in selected:
            self._audit_storage(results)

        if 'compute' in selected:
            self._audit_compute(results)

        results.finalize()
        return results

    # =========================================================================
    # Security Audits
    # =========================================================================

    def _audit_security(self, results: AuditResults):
        """Run security-related audits"""
        results.section("Security Configuration")

        # Check root SSH access
        self._check_root_ssh(results)

        # Check two-factor authentication
        self._check_2fa(results)

        # Check API token security
        self._check_api_tokens(results)

        # Check user permissions
        self._check_user_permissions(results)

        # Check cluster communication encryption
        self._check_cluster_encryption(results)

        # Check certificate validity
        self._check_certificates(results)

        # Check PVE updates
        self._check_updates(results)

    def _check_root_ssh(self, results: AuditResults):
        """Check if root SSH login is allowed"""
        sshd_config = Path("/etc/ssh/sshd_config")
        try:
            content = sshd_config.read_text()
            # Check PermitRootLogin
            permit_root = re.search(r'^PermitRootLogin\s+(\S+)', content, re.MULTILINE)

            if permit_root:
                value = permit_root.group(1).lower()
                if value == 'no':
                    results.register("Root SSH Access", "PASS",
                                   "Root SSH login is disabled",
                                   category="security", severity="high",
                                   compliance=["CIS", "PCI-DSS"])
                elif value == 'prohibit-password':
                    results.register("Root SSH Access", "PASS",
                                   "Root SSH limited to key-based auth only",
                                   category="security", severity="medium",
                                   compliance=["CIS"])
                else:
                    results.register("Root SSH Access", "FAIL",
                                   f"Root SSH login is enabled ({value})",
                                   category="security", severity="high",
                                   remediation="Set 'PermitRootLogin no' in /etc/ssh/sshd_config",
                                   compliance=["CIS", "PCI-DSS"])
            else:
                results.register("Root SSH Access", "WARN",
                               "PermitRootLogin not explicitly configured",
                               category="security", severity="medium",
                               remediation="Explicitly set 'PermitRootLogin no' in /etc/ssh/sshd_config")
        except Exception as e:
            results.register("Root SSH Access", "SKIP", f"Could not check: {e}",
                           category="security")

    def _check_2fa(self, results: AuditResults):
        """Check if 2FA is enabled for users"""
        user_cfg = self._read_config_file(self.user_config)

        # Check for TFA realm configuration
        tfa_users = []
        users_without_tfa = []

        for line in user_cfg.splitlines():
            if line.startswith('user:'):
                # Format: user:username@realm:enable:...
                parts = line.split(':')
                if len(parts) >= 2:
                    username = parts[1]
                    # Check if user has TFA configured (would have tfa: entry)
                    if '@pve' in username or '@pam' in username:
                        users_without_tfa.append(username)

        # Check TFA entries
        for line in user_cfg.splitlines():
            if line.startswith('user:') and 'tfa' in line.lower():
                tfa_users.append(line.split(':')[1])

        admin_users = [u for u in users_without_tfa if 'admin' in u.lower() or u.startswith('root@')]

        if not admin_users or all(u in tfa_users for u in admin_users):
            results.register("Two-Factor Authentication", "PASS",
                           "Admin users have 2FA configured",
                           category="security", severity="high",
                           compliance=["CIS", "PCI-DSS", "NIST"])
        else:
            no_tfa = [u for u in admin_users if u not in tfa_users]
            results.register("Two-Factor Authentication", "FAIL",
                           f"Admin users without 2FA: {', '.join(no_tfa)}",
                           category="security", severity="high",
                           remediation="Enable TOTP or WebAuthn 2FA for all admin accounts",
                           compliance=["CIS", "PCI-DSS", "NIST"])

    def _check_api_tokens(self, results: AuditResults):
        """Check API token security"""
        user_cfg = self._read_config_file(self.user_config)

        # Count API tokens and check for privilege separation
        tokens = []
        privileged_tokens = []

        for line in user_cfg.splitlines():
            if line.startswith('token:'):
                tokens.append(line)
                # Check if token has admin privileges
                if 'Administrator' in line or 'PVEAdmin' in line:
                    privileged_tokens.append(line.split(':')[1] if ':' in line else line)

        if not tokens:
            results.register("API Token Security", "PASS",
                           "No API tokens configured",
                           category="security", severity="low")
        elif privileged_tokens:
            results.register("API Token Security", "WARN",
                           f"{len(privileged_tokens)} token(s) with admin privileges",
                           category="security", severity="medium",
                           remediation="Use least-privilege tokens with specific permissions")
        else:
            results.register("API Token Security", "PASS",
                           f"{len(tokens)} API tokens configured with limited privileges",
                           category="security", severity="low")

    def _check_user_permissions(self, results: AuditResults):
        """Check for overly permissive user configurations"""
        user_cfg = self._read_config_file(self.user_config)

        # Check for dangerous ACL patterns
        dangerous_patterns = [
            (r'acl:1:/.*:.*@.*:Administrator', "Full Administrator access at root"),
            (r'acl:1:/.*:.*@.*:PVEAdmin', "PVE Admin access"),
        ]

        issues = []
        for pattern, desc in dangerous_patterns:
            if re.search(pattern, user_cfg):
                # Check if it's for root@pam (expected)
                match = re.search(pattern, user_cfg)
                if match and 'root@pam' not in match.group(0):
                    issues.append(desc)

        if issues:
            results.register("User Permissions", "WARN",
                           f"Found: {'; '.join(issues)}",
                           category="security", severity="medium",
                           remediation="Review and restrict user permissions to least privilege")
        else:
            results.register("User Permissions", "PASS",
                           "No overly permissive user configurations found",
                           category="security", severity="medium")

    def _check_cluster_encryption(self, results: AuditResults):
        """Check cluster communication encryption"""
        # Check if in cluster mode
        cluster_info = self._get_cluster_info()

        if not cluster_info:
            results.register("Cluster Encryption", "SKIP",
                           "Not in cluster mode",
                           category="security")
            return

        # Check corosync encryption
        corosync_conf = Path("/etc/pve/corosync.conf")
        if corosync_conf.exists():
            content = self._read_config_file(corosync_conf)

            if 'secauth: on' in content or 'crypto_cipher:' in content:
                results.register("Cluster Encryption", "PASS",
                               "Corosync authentication/encryption enabled",
                               category="security", severity="high",
                               compliance=["CIS", "PCI-DSS"])
            else:
                results.register("Cluster Encryption", "FAIL",
                               "Corosync encryption not enabled",
                               category="security", severity="high",
                               remediation="Enable corosync crypto in cluster configuration",
                               compliance=["CIS", "PCI-DSS"])
        else:
            results.register("Cluster Encryption", "SKIP",
                           "Corosync config not found",
                           category="security")

    def _check_certificates(self, results: AuditResults):
        """Check SSL certificate validity"""
        cert_path = Path("/etc/pve/local/pve-ssl.pem")

        if cert_path.exists():
            try:
                # Use openssl to check certificate
                result = self.run_command([
                    'openssl', 'x509', '-in', str(cert_path),
                    '-noout', '-dates', '-subject'
                ])

                if result.returncode == 0:
                    output = result.stdout

                    # Check expiry
                    not_after = re.search(r'notAfter=(.+)', output)
                    if not_after:
                        from datetime import datetime
                        expiry_str = not_after.group(1).strip()
                        # Parse date (format: Mar 15 12:00:00 2025 GMT)
                        try:
                            expiry = datetime.strptime(expiry_str, '%b %d %H:%M:%S %Y %Z')
                            days_left = (expiry - datetime.now()).days

                            if days_left < 0:
                                results.register("SSL Certificate", "FAIL",
                                               f"Certificate expired {abs(days_left)} days ago",
                                               category="security", severity="critical",
                                               remediation="Renew the PVE SSL certificate")
                            elif days_left < 30:
                                results.register("SSL Certificate", "WARN",
                                               f"Certificate expires in {days_left} days",
                                               category="security", severity="high",
                                               remediation="Renew certificate before expiry")
                            else:
                                results.register("SSL Certificate", "PASS",
                                               f"Certificate valid for {days_left} days",
                                               category="security", severity="medium")
                        except ValueError:
                            results.register("SSL Certificate", "WARN",
                                           "Could not parse certificate expiry date",
                                           category="security")

                    # Check for self-signed
                    if 'CN=Proxmox Virtual Environment' in output:
                        results.register("SSL Certificate Type", "WARN",
                                       "Using default self-signed certificate",
                                       category="security", severity="low",
                                       remediation="Consider using a trusted CA certificate")
                    else:
                        results.register("SSL Certificate Type", "PASS",
                                       "Custom certificate configured",
                                       category="security", severity="low")
                else:
                    results.register("SSL Certificate", "SKIP",
                                   "Could not read certificate",
                                   category="security")
            except Exception as e:
                results.register("SSL Certificate", "SKIP", f"Error: {e}",
                               category="security")
        else:
            results.register("SSL Certificate", "SKIP",
                           "Certificate file not found",
                           category="security")

    def _check_updates(self, results: AuditResults):
        """Check for available Proxmox updates"""
        try:
            # Check subscription status
            result = self.run_command(['pvesubscription', 'get'])
            has_subscription = result.returncode == 0 and 'Active' in result.stdout

            # Check for updates
            result = self.run_command(['apt', 'list', '--upgradable'], timeout=120)

            if result.returncode == 0:
                lines = [line for line in result.stdout.splitlines() if 'pve' in line.lower() or 'proxmox' in line.lower()]

                if lines:
                    results.register("Proxmox Updates", "WARN",
                                   f"{len(lines)} Proxmox package(s) have updates available",
                                   category="security", severity="medium",
                                   remediation="Run 'apt update && apt upgrade' to apply updates",
                                   compliance=["CIS", "NIST"])
                else:
                    results.register("Proxmox Updates", "PASS",
                                   "All Proxmox packages are up to date",
                                   category="security", severity="medium",
                                   compliance=["CIS", "NIST"])

            if not has_subscription:
                results.register("Subscription Status", "WARN",
                               "No active Proxmox subscription",
                               category="security", severity="low",
                               remediation="Consider a subscription for enterprise support and stable updates")
            else:
                results.register("Subscription Status", "PASS",
                               "Active Proxmox subscription",
                               category="security", severity="low")

        except Exception as e:
            results.register("Proxmox Updates", "SKIP", f"Could not check: {e}",
                           category="security")

    # =========================================================================
    # Network Audits
    # =========================================================================

    def _audit_network(self, results: AuditResults):
        """Run network-related audits"""
        results.section("Network Configuration")

        # Check firewall status
        self._check_firewall(results)

        # Check network bridges
        self._check_bridges(results)

        # Check VLAN configuration
        self._check_vlans(results)

        # Check SDN if enabled
        self._check_sdn(results)

    def _check_firewall(self, results: AuditResults):
        """Check Proxmox firewall status"""
        # Check if cluster firewall is enabled
        dc_cfg = self._read_config_file(self.datacenter_config)

        cluster_fw_enabled = 'enable: 1' in dc_cfg or 'enable:1' in dc_cfg

        # Check if firewall service is active
        result = self.run_command(['pve-firewall', 'status'])
        fw_running = result.returncode == 0 and 'running' in result.stdout.lower()

        if cluster_fw_enabled and fw_running:
            results.register("Proxmox Firewall", "PASS",
                           "Datacenter firewall is enabled and running",
                           category="network", severity="high",
                           compliance=["CIS", "PCI-DSS", "NIST"])
        elif fw_running:
            results.register("Proxmox Firewall", "WARN",
                           "Firewall service running but datacenter policy not enabled",
                           category="network", severity="medium",
                           remediation="Enable datacenter firewall in GUI or datacenter.cfg")
        else:
            results.register("Proxmox Firewall", "FAIL",
                           "Proxmox firewall is not enabled",
                           category="network", severity="high",
                           remediation="Enable and configure pve-firewall",
                           compliance=["CIS", "PCI-DSS", "NIST"])

        # Check for default deny policy
        cluster_fw_path = self.pve_config_path / "firewall" / "cluster.fw"
        if cluster_fw_path.exists():
            fw_content = self._read_config_file(cluster_fw_path)
            if 'policy_in: DROP' in fw_content or 'policy_in: REJECT' in fw_content:
                results.register("Firewall Default Policy", "PASS",
                               "Default inbound policy is DROP/REJECT",
                               category="network", severity="high")
            else:
                results.register("Firewall Default Policy", "WARN",
                               "Default inbound policy may be ACCEPT",
                               category="network", severity="medium",
                               remediation="Set policy_in: DROP in cluster firewall rules")

    def _check_bridges(self, results: AuditResults):
        """Check network bridge configurations"""
        interfaces_cfg = Path("/etc/network/interfaces")

        if interfaces_cfg.exists():
            content = self._read_config_file(interfaces_cfg)

            # Count bridges
            bridges = re.findall(r'iface\s+(\S+)\s+inet\s+\S+\s*\n(?:.*?\n)*?\s+bridge-ports', content, re.MULTILINE)

            # Check for bridge isolation
            bridge_vids = re.findall(r'bridge-vids\s+(.+)', content)

            if bridges:
                results.register("Network Bridges", "PASS",
                               f"Found {len(bridges)} configured bridge(s): {', '.join(bridges)}",
                               category="network", severity="low")

                if bridge_vids:
                    results.register("VLAN Bridge Filtering", "PASS",
                                   "VLAN filtering configured on bridge(s)",
                                   category="network", severity="medium")
                else:
                    results.register("VLAN Bridge Filtering", "WARN",
                                   "No VLAN filtering on bridges - all VLANs may be accessible",
                                   category="network", severity="medium",
                                   remediation="Configure bridge-vids to limit VLAN access")
            else:
                results.register("Network Bridges", "WARN",
                               "No bridges found - VMs may not have network connectivity",
                               category="network", severity="medium")

    def _check_vlans(self, results: AuditResults):
        """Check VLAN security configuration"""
        # Check if VLANs are used for management separation
        # This is a common security best practice

        interfaces_cfg = Path("/etc/network/interfaces")
        content = self._read_config_file(interfaces_cfg)

        vlans = re.findall(r'vlan-raw-device|iface\s+\S+\.\d+', content)

        if vlans:
            results.register("VLAN Segmentation", "PASS",
                           "VLAN segmentation is configured",
                           category="network", severity="medium",
                           compliance=["CIS", "PCI-DSS"])
        else:
            results.register("VLAN Segmentation", "WARN",
                           "No VLAN segmentation detected",
                           category="network", severity="medium",
                           remediation="Consider using VLANs to segment management and VM traffic",
                           compliance=["CIS", "PCI-DSS"])

    def _check_sdn(self, results: AuditResults):
        """Check SDN configuration if enabled"""
        sdn_path = self.pve_config_path / "sdn"

        if sdn_path.exists() and sdn_path.is_dir():
            zones = list(sdn_path.glob("zones.cfg"))
            vnets = list(sdn_path.glob("vnets.cfg"))

            if zones or vnets:
                results.register("Software Defined Networking", "PASS",
                               "SDN is configured for advanced network isolation",
                               category="network", severity="medium")
            else:
                results.register("Software Defined Networking", "SKIP",
                               "SDN directory exists but not configured",
                               category="network")
        else:
            results.register("Software Defined Networking", "SKIP",
                           "SDN not enabled",
                           category="network")

    # =========================================================================
    # Storage Audits
    # =========================================================================

    def _audit_storage(self, results: AuditResults):
        """Run storage-related audits"""
        results.section("Storage Configuration")

        # Check storage encryption
        self._check_storage_encryption(results)

        # Check backup configuration
        self._check_backups(results)

        # Check storage permissions
        self._check_storage_permissions(results)

    def _check_storage_encryption(self, results: AuditResults):
        """Check if storage encryption is configured"""
        # Note: storage_cfg used for future LUKS detection
        _ = self._read_config_file(self.storage_config)

        # Check for ZFS encryption
        zfs_encrypted = False
        try:
            result = self.run_command(['zfs', 'get', '-H', 'encryption', '-t', 'filesystem'])
            if result.returncode == 0:
                # Check if any pool has encryption enabled
                for line in result.stdout.splitlines():
                    if '\ton\t' in line or '\taes-' in line:
                        zfs_encrypted = True
                        break
        except Exception:
            pass

        # Check for LUKS
        luks_present = False
        try:
            result = self.run_command(['lsblk', '-o', 'NAME,TYPE'])
            if 'crypt' in result.stdout:
                luks_present = True
        except Exception:
            pass

        if zfs_encrypted or luks_present:
            method = []
            if zfs_encrypted:
                method.append("ZFS encryption")
            if luks_present:
                method.append("LUKS")
            results.register("Storage Encryption", "PASS",
                           f"Storage encryption enabled: {', '.join(method)}",
                           category="storage", severity="high",
                           compliance=["CIS", "PCI-DSS", "HIPAA"])
        else:
            results.register("Storage Encryption", "WARN",
                           "No storage encryption detected",
                           category="storage", severity="high",
                           remediation="Enable ZFS native encryption or LUKS for sensitive data",
                           compliance=["CIS", "PCI-DSS", "HIPAA"])

    def _check_backups(self, results: AuditResults):
        """Check backup configuration"""
        # Check vzdump jobs
        jobs_path = self.pve_config_path / "jobs.cfg"

        backup_jobs = []
        if jobs_path.exists():
            content = self._read_config_file(jobs_path)
            backup_jobs = re.findall(r'vzdump:', content)

        # Check for backup storage
        storage_cfg = self._read_config_file(self.storage_config)
        backup_storage = 'content backup' in storage_cfg or 'content vzdump' in storage_cfg

        if backup_jobs:
            results.register("Backup Jobs", "PASS",
                           f"{len(backup_jobs)} backup job(s) configured",
                           category="storage", severity="high",
                           compliance=["CIS", "NIST"])

            # Check backup encryption
            if 'encrypt' in self._read_config_file(jobs_path):
                results.register("Backup Encryption", "PASS",
                               "Backup encryption is enabled",
                               category="storage", severity="high",
                               compliance=["PCI-DSS", "HIPAA"])
            else:
                results.register("Backup Encryption", "WARN",
                               "Backup encryption not detected",
                               category="storage", severity="medium",
                               remediation="Enable encryption for vzdump backups")
        else:
            results.register("Backup Jobs", "FAIL",
                           "No automated backup jobs configured",
                           category="storage", severity="high",
                           remediation="Configure scheduled backup jobs in Datacenter > Backup",
                           compliance=["CIS", "NIST"])

        if backup_storage:
            results.register("Backup Storage", "PASS",
                           "Dedicated backup storage configured",
                           category="storage", severity="medium")
        else:
            results.register("Backup Storage", "WARN",
                           "No dedicated backup storage found",
                           category="storage", severity="medium",
                           remediation="Add dedicated storage with 'backup' content type")

    def _check_storage_permissions(self, results: AuditResults):
        """Check storage configuration permissions"""
        storage_files = [
            self.storage_config,
            self.pve_config_path / "priv" / "storage"
        ]

        for storage_file in storage_files:
            if storage_file.exists():
                try:
                    stat = storage_file.stat()
                    mode = oct(stat.st_mode)[-3:]

                    if mode in ['600', '640', '400']:
                        results.register(f"Storage Config Permissions ({storage_file.name})", "PASS",
                                       f"Permissions: {mode}",
                                       category="storage", severity="medium")
                    else:
                        results.register(f"Storage Config Permissions ({storage_file.name})", "WARN",
                                       f"Permissions too open: {mode}",
                                       category="storage", severity="medium",
                                       remediation=f"chmod 640 {storage_file}")
                except Exception:
                    pass

    # =========================================================================
    # Compute/VM Audits
    # =========================================================================

    def _audit_compute(self, results: AuditResults):
        """Run compute/VM-related audits"""
        results.section("Compute/VM Configuration")

        # Check VM security configurations
        self._check_vm_security(results)

        # Check container security
        self._check_container_security(results)

        # Check resource limits
        self._check_resource_limits(results)

    def _check_vm_security(self, results: AuditResults):
        """Check QEMU VM security configurations"""
        hostname = self._get_hostname()

        # Get all VMs on this node
        vms = self._pvesh_get(f'/nodes/{hostname}/qemu') or []

        if not vms:
            results.register("VM Security", "SKIP",
                           "No QEMU VMs on this node",
                           category="compute")
            return

        issues = []
        total_vms = len(vms)

        for vm in vms:
            vmid = vm.get('vmid')
            config = self._pvesh_get(f'/nodes/{hostname}/qemu/{vmid}/config') or {}

            # Check for insecure serial console
            if config.get('serial0') or config.get('serial1'):
                issues.append(f"VM {vmid}: Serial console enabled")

            # Check for unsafe CPU flags
            cpu = config.get('cpu', '')
            if '+pcid' in cpu or '+spec-ctrl' not in cpu:
                # Spectre/Meltdown mitigations
                pass  # Complex check, skip for now

        if not issues:
            results.register("VM Security Config", "PASS",
                           f"Checked {total_vms} VMs - no obvious security issues",
                           category="compute", severity="medium")
        else:
            results.register("VM Security Config", "WARN",
                           f"Found {len(issues)} potential issue(s)",
                           category="compute", severity="medium",
                           remediation="; ".join(issues[:3]))  # Show first 3

    def _check_container_security(self, results: AuditResults):
        """Check LXC container security"""
        hostname = self._get_hostname()

        # Get all containers on this node
        cts = self._pvesh_get(f'/nodes/{hostname}/lxc') or []

        if not cts:
            results.register("Container Security", "SKIP",
                           "No LXC containers on this node",
                           category="compute")
            return

        privileged_cts = []
        nesting_cts = []

        for ct in cts:
            ctid = ct.get('vmid')
            config = self._pvesh_get(f'/nodes/{hostname}/lxc/{ctid}/config') or {}

            # Check if unprivileged
            if config.get('unprivileged', 0) == 0:
                privileged_cts.append(str(ctid))

            # Check for nesting (can be security concern)
            features = config.get('features', '')
            if 'nesting=1' in features:
                nesting_cts.append(str(ctid))

        if privileged_cts:
            results.register("Privileged Containers", "WARN",
                           f"Privileged containers: {', '.join(privileged_cts)}",
                           category="compute", severity="high",
                           remediation="Convert to unprivileged containers where possible",
                           compliance=["CIS"])
        else:
            results.register("Privileged Containers", "PASS",
                           "All containers are unprivileged",
                           category="compute", severity="high",
                           compliance=["CIS"])

        if nesting_cts:
            results.register("Container Nesting", "WARN",
                           f"Containers with nesting enabled: {', '.join(nesting_cts)}",
                           category="compute", severity="medium",
                           remediation="Disable nesting unless required for Docker-in-LXC")

    def _check_resource_limits(self, results: AuditResults):
        """Check if resource limits are properly configured"""
        hostname = self._get_hostname()

        # Check VMs
        vms = self._pvesh_get(f'/nodes/{hostname}/qemu') or []
        vms_without_limits = []

        for vm in vms:
            vmid = vm.get('vmid')
            config = self._pvesh_get(f'/nodes/{hostname}/qemu/{vmid}/config') or {}

            # Check for CPU and memory limits
            if not config.get('cpulimit') and not config.get('cpuunits'):
                vms_without_limits.append(f"VM {vmid}")

        # Check containers
        cts = self._pvesh_get(f'/nodes/{hostname}/lxc') or []
        cts_without_limits = []

        for ct in cts:
            ctid = ct.get('vmid')
            config = self._pvesh_get(f'/nodes/{hostname}/lxc/{ctid}/config') or {}

            if not config.get('cpulimit') and not config.get('cpuunits'):
                cts_without_limits.append(f"CT {ctid}")

        total_without = len(vms_without_limits) + len(cts_without_limits)
        total = len(vms) + len(cts)

        if total == 0:
            results.register("Resource Limits", "SKIP",
                           "No VMs or containers to check",
                           category="compute")
        elif total_without == 0:
            results.register("Resource Limits", "PASS",
                           f"All {total} VMs/containers have resource limits",
                           category="compute", severity="medium")
        else:
            results.register("Resource Limits", "WARN",
                           f"{total_without}/{total} VMs/containers without CPU limits",
                           category="compute", severity="low",
                           remediation="Set cpulimit and memory limits to prevent resource exhaustion")


# =============================================================================
# CLI Entry Point
# =============================================================================

def main():
    """CLI entry point for Proxmox agent"""
    import argparse

    parser = argparse.ArgumentParser(
        description='Proxmox VE Security Audit Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s audit                    Run full security audit
  %(prog)s audit --categories security network
  %(prog)s register --server https://audit.example.com --key YOUR_API_KEY
  %(prog)s daemon --interval 300    Run in daemon mode
        """
    )

    parser.add_argument('command', choices=['audit', 'register', 'daemon', 'info'],
                       help='Command to execute')
    parser.add_argument('--server', '-s', help='Central server URL')
    parser.add_argument('--key', '-k', help='API key')
    parser.add_argument('--categories', '-c', nargs='+',
                       choices=['security', 'network', 'storage', 'compute'],
                       help='Audit categories to run')
    parser.add_argument('--interval', '-i', type=int, default=60,
                       help='Poll interval in seconds (daemon mode)')
    parser.add_argument('--output', '-o', help='Output file for results (JSON)')
    parser.add_argument('--config', help='Path to config file')

    args = parser.parse_args()

    # Initialize agent
    agent = ProxmoxAgent(
        server_url=args.server,
        api_key=args.key,
        config_path=args.config
    )

    if args.command == 'info':
        info = agent.get_system_info()
        print(json.dumps(info, indent=2))

    elif args.command == 'audit':
        results = agent.run_audit(args.categories)
        results.print_summary()

        if args.output:
            with open(args.output, 'w') as f:
                f.write(results.to_json())
            print(f"\nResults saved to: {args.output}")

        # Submit to server if configured
        if agent.server_url:
            agent.submit_results(results)

    elif args.command == 'register':
        if not args.server or not args.key:
            print("Error: --server and --key required for registration")
            return 1

        if agent.register():
            print("Registration successful!")
        else:
            print("Registration failed")
            return 1

    elif args.command == 'daemon':
        agent.run_daemon(args.interval)

    return 0


if __name__ == '__main__':
    exit(main())
