#!/usr/bin/env python3
"""
XCP-ng / Citrix Hypervisor Fleet Agent

Security audit agent for XCP-ng and Citrix Hypervisor (XenServer) using xe CLI.
Communicates with central server via REST API only.

Supports:
- XCP-ng 7.x, 8.x
- Citrix Hypervisor (XenServer) 7.x, 8.x
- xe CLI commands

Author: Security Audit Toolkit Team
Version: 1.0.0
"""

import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from ..core import AuditResults, HypervisorAgent, logger
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from core import AuditResults, HypervisorAgent, logger


class XenAgent(HypervisorAgent):
    """
    XCP-ng / Citrix Hypervisor Security Audit Agent

    Uses xe CLI for security audits across the pool/host.
    """

    PLATFORM = "xen"
    PLATFORM_NAME = "XCP-ng / Citrix Hypervisor"

    def __init__(self, **kwargs):
        """Initialize Xen agent"""
        super().__init__(**kwargs)
        self._xe_available = self._check_xe()

    def _check_xe(self) -> bool:
        """Check if xe CLI is available"""
        try:
            result = subprocess.run(
                ['xe', 'version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _xe(self, *args: str, parse: bool = False) -> Optional[str]:
        """
        Execute xe command.

        Args:
            *args: Command arguments
            parse: If True, try to parse key=value output

        Returns:
            Command output or None on error
        """
        if not self._xe_available:
            return None

        cmd = ['xe'] + list(args)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode == 0:
                return result.stdout.strip()
            logger.debug(f"xe command failed: {result.stderr}")
        except subprocess.TimeoutExpired:
            logger.warning(f"xe command timed out: {' '.join(cmd)}")
        except Exception as e:
            logger.debug(f"xe command error: {e}")
        return None

    def _xe_params(self, output: str) -> Dict[str, str]:
        """Parse xe output with key ( RO) / key ( RW): value format"""
        params = {}
        if not output:
            return params

        for line in output.split('\n'):
            if ':' in line:
                # Handle format: "key ( RO): value" or "key: value"
                parts = line.split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    # Remove ( RO) or ( RW) suffixes
                    key = key.replace(' ( RO)', '').replace(' ( RW)', '')
                    params[key] = parts[1].strip()
        return params

    def _xe_list(self, obj_type: str, params: str = 'all') -> List[Dict[str, str]]:
        """
        List objects with xe command.

        Returns list of parameter dictionaries.
        """
        output = self._xe(f'{obj_type}-list', f'params={params}')
        if not output:
            return []

        objects = []
        current_obj = {}

        for line in output.split('\n'):
            if line.startswith('uuid'):
                if current_obj:
                    objects.append(current_obj)
                current_obj = {}
            if ':' in line:
                parts = line.split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip().replace(' ( RO)', '').replace(' ( RW)', '')
                    current_obj[key] = parts[1].strip()

        if current_obj:
            objects.append(current_obj)

        return objects

    def _detect_platform_version(self) -> str:
        """Detect XCP-ng/Xen version"""
        if not self._xe_available:
            return "unknown"

        # Get host list and check software version
        hosts = self._xe_list('host', 'uuid,software-version')
        if hosts:
            for host in hosts:
                sw_version = host.get('software-version', '')
                if 'product_version:' in sw_version:
                    # Parse the embedded version string
                    for part in sw_version.split(';'):
                        if 'product_version:' in part:
                            return part.split(':')[1].strip()
                if 'xcp' in sw_version.lower() or 'xenserver' in sw_version.lower():
                    return sw_version

        # Fallback: try to read version file
        try:
            version_file = Path('/etc/xensource-inventory')
            if version_file.exists():
                content = version_file.read_text()
                for line in content.split('\n'):
                    if line.startswith('PRODUCT_VERSION='):
                        return line.split('=')[1].strip().strip("'\"")
        except Exception:
            pass

        return "unknown"

    def get_system_info(self) -> Dict[str, Any]:
        """Get system information for discovery"""
        info = {
            "platform": self.PLATFORM,
            "platform_name": self.PLATFORM_NAME,
            "version": self.platform_version,
            "pool": None,
            "hosts": [],
            "vms": {"total": 0, "running": 0},
            "storage": [],
            "networks": []
        }

        if not self._xe_available:
            return info

        # Pool info
        pools = self._xe_list('pool', 'uuid,name-label,master')
        if pools:
            info["pool"] = {
                "name": pools[0].get('name-label', 'Default'),
                "uuid": pools[0].get('uuid'),
                "master": pools[0].get('master')
            }

        # Hosts
        hosts = self._xe_list('host', 'uuid,name-label,enabled,hostname')
        info["hosts"] = [
            {
                "name": h.get('name-label'),
                "hostname": h.get('hostname'),
                "enabled": h.get('enabled') == 'true'
            }
            for h in hosts
        ]

        # VMs
        vms = self._xe_list('vm', 'uuid,name-label,power-state,is-control-domain')
        real_vms = [v for v in vms if v.get('is-control-domain') != 'true']
        info["vms"]["total"] = len(real_vms)
        info["vms"]["running"] = len([v for v in real_vms if v.get('power-state') == 'running'])

        # Storage repositories
        srs = self._xe_list('sr', 'uuid,name-label,type,physical-size')
        info["storage"] = [
            {
                "name": sr.get('name-label'),
                "type": sr.get('type'),
                "uuid": sr.get('uuid')
            }
            for sr in srs
        ]

        # Networks
        networks = self._xe_list('network', 'uuid,name-label,bridge')
        info["networks"] = [
            {
                "name": n.get('name-label'),
                "bridge": n.get('bridge'),
                "uuid": n.get('uuid')
            }
            for n in networks
        ]

        return info

    # =========================================================================
    # Audit Implementation
    # =========================================================================

    def run_audit(self, categories: Optional[List[str]] = None) -> AuditResults:
        """
        Run XCP-ng/Xen security audit.

        Categories:
        - security: Authentication, SSH, TLS, patches
        - network: Network security, VLANs, bonds
        - storage: SR security, thin provisioning
        - compute: VM settings, resource limits
        """
        results = AuditResults(
            platform=self.PLATFORM,
            platform_version=self.platform_version,
            agent_id=self.agent_id
        )

        if not self._xe_available:
            results.register(
                "xe CLI",
                "FAIL",
                "xe command not available - not running on XCP-ng/Xen host",
                category="security",
                severity="critical"
            )
            results.finalize()
            return results

        results.register("xe CLI", "PASS", "xe command available", category="security")

        all_categories = ['security', 'network', 'storage', 'compute']
        run_categories = categories or all_categories

        if 'security' in run_categories:
            self._audit_security(results)

        if 'network' in run_categories:
            self._audit_network(results)

        if 'storage' in run_categories:
            self._audit_storage(results)

        if 'compute' in run_categories:
            self._audit_compute(results)

        results.finalize()
        results.print_summary()
        return results

    def _audit_security(self, results: AuditResults):
        """Security configuration audits"""
        results.section("Security Configuration")

        # Check SSH service
        try:
            ssh_status = subprocess.run(
                ['systemctl', 'is-active', 'sshd'],
                capture_output=True,
                text=True,
                timeout=10
            )
            ssh_active = ssh_status.returncode == 0
        except Exception:
            ssh_active = False

        if ssh_active:
            results.register(
                "SSH Service",
                "WARN",
                "SSH is enabled - ensure access is properly restricted",
                category="security",
                severity="low"
            )

            # Check SSH config
            try:
                ssh_config = Path('/etc/ssh/sshd_config').read_text()
                if 'PermitRootLogin yes' in ssh_config:
                    results.register(
                        "SSH Root Login",
                        "WARN",
                        "Root login via SSH is permitted",
                        category="security",
                        severity="medium"
                    )
                else:
                    results.register("SSH Root Login", "PASS", "Root SSH login restricted", category="security")

                if 'PasswordAuthentication yes' in ssh_config:
                    results.register(
                        "SSH Password Auth",
                        "WARN",
                        "Password authentication enabled - consider key-only",
                        category="security",
                        severity="low"
                    )
            except Exception:
                pass
        else:
            results.register("SSH Service", "PASS", "SSH service not active", category="security")

        # Check TLS certificates
        cert_path = Path('/etc/xensource/xapi-ssl.pem')
        if cert_path.exists():
            results.register(
                "TLS Certificate",
                "PASS",
                "XAPI TLS certificate present",
                category="security"
            )
        else:
            results.register(
                "TLS Certificate",
                "WARN",
                "XAPI TLS certificate not found in expected location",
                category="security",
                severity="medium"
            )

        # Check for pending patches/updates
        patches = self._xe_list('patch', 'uuid,name-label,applied')
        if patches:
            unapplied = [p for p in patches if p.get('applied') != 'true']
            if unapplied:
                results.register(
                    "Pending Patches",
                    "WARN",
                    f"{len(unapplied)} unapplied patch(es) found",
                    category="security",
                    severity="high"
                )
            else:
                results.register(
                    "Patches",
                    "PASS",
                    "All patches applied",
                    category="security"
                )

        # Check pool authentication
        _pools = self._xe_list('pool', 'uuid,other-config')  # noqa: F841
        # Pool external auth would be in other-config

        # Check host enabled status
        hosts = self._xe_list('host', 'uuid,name-label,enabled')
        disabled_hosts = [h for h in hosts if h.get('enabled') != 'true']
        if disabled_hosts:
            results.register(
                "Disabled Hosts",
                "WARN",
                f"{len(disabled_hosts)} host(s) are disabled",
                category="security",
                severity="medium"
            )
        else:
            results.register(
                "Host Status",
                "PASS",
                f"All {len(hosts)} host(s) enabled",
                category="security"
            )

    def _audit_network(self, results: AuditResults):
        """Network configuration audits"""
        results.section("Network Configuration")

        # List networks
        networks = self._xe_list('network', 'uuid,name-label,bridge,other-config')
        results.register(
            "Networks",
            "PASS",
            f"{len(networks)} network(s) configured",
            category="network"
        )

        # Check for VLANs
        vlans = self._xe_list('vlan', 'uuid,tag,tagged-PIF')
        if vlans:
            results.register(
                "VLANs",
                "PASS",
                f"{len(vlans)} VLAN(s) configured for network segmentation",
                category="network"
            )

        # Check bonded interfaces
        bonds = self._xe_list('bond', 'uuid,master,slaves')
        if bonds:
            results.register(
                "Network Bonds",
                "PASS",
                f"{len(bonds)} bond(s) configured for redundancy",
                category="network"
            )

        # Check PIFs
        pifs = self._xe_list('pif', 'uuid,device,IP,management')
        management_pifs = [p for p in pifs if p.get('management') == 'true']
        if len(management_pifs) > 0:
            results.register(
                "Management Network",
                "PASS",
                f"{len(management_pifs)} management interface(s) configured",
                category="network"
            )

    def _audit_storage(self, results: AuditResults):
        """Storage configuration audits"""
        results.section("Storage Configuration")

        # Storage repositories
        srs = self._xe_list('sr', 'uuid,name-label,type,physical-size,physical-utilisation,shared')
        results.register(
            "Storage Repositories",
            "PASS",
            f"{len(srs)} SR(s) configured",
            category="storage"
        )

        # Check SR types
        sr_types = {}
        for sr in srs:
            sr_type = sr.get('type', 'unknown')
            sr_types[sr_type] = sr_types.get(sr_type, 0) + 1

        for sr_type, count in sr_types.items():
            if sr_type == 'nfs':
                results.register(
                    "NFS Storage",
                    "WARN",
                    f"{count} NFS SR(s) - verify mount security",
                    category="storage",
                    severity="low"
                )
            elif sr_type == 'iscsi' or sr_type == 'lvmoiscsi':
                results.register(
                    "iSCSI Storage",
                    "PASS",
                    f"{count} iSCSI SR(s) configured",
                    category="storage"
                )

        # Check shared storage
        shared_srs = [sr for sr in srs if sr.get('shared') == 'true']
        if shared_srs:
            results.register(
                "Shared Storage",
                "PASS",
                f"{len(shared_srs)} shared SR(s) for HA/migration",
                category="storage"
            )

        # Check for local storage only warning
        local_only = [sr for sr in srs if sr.get('shared') != 'true' and sr.get('type') not in ('udev', 'iso', 'dummy')]
        if local_only and not shared_srs:
            results.register(
                "Storage Redundancy",
                "WARN",
                "Only local storage detected - no shared storage for HA",
                category="storage",
                severity="medium"
            )

    def _audit_compute(self, results: AuditResults):
        """Compute configuration audits"""
        results.section("Compute Configuration")

        # VMs (excluding dom0)
        vms = self._xe_list('vm', 'uuid,name-label,power-state,is-control-domain,memory-static-max,VCPUs-max')
        real_vms = [v for v in vms if v.get('is-control-domain') != 'true']

        running = [v for v in real_vms if v.get('power-state') == 'running']
        results.register(
            "Virtual Machines",
            "PASS",
            f"{len(real_vms)} VM(s), {len(running)} running",
            category="compute"
        )

        # Check for VMs without resource limits
        no_limits = []
        for vm in real_vms:
            vcpus = vm.get('VCPUs-max', '0')
            if vcpus == '0':
                no_limits.append(vm.get('name-label', 'unnamed'))

        if no_limits and len(no_limits) <= 5:
            results.register(
                "VM Resource Limits",
                "WARN",
                f"{len(no_limits)} VM(s) may lack resource limits",
                category="compute",
                severity="low"
            )

        # Check pool HA status
        pools = self._xe_list('pool', 'uuid,ha-enabled,ha-configuration')
        for pool in pools:
            if pool.get('ha-enabled') == 'true':
                results.register(
                    "High Availability",
                    "PASS",
                    "Pool HA is enabled",
                    category="compute"
                )
            else:
                results.register(
                    "High Availability",
                    "WARN",
                    "Pool HA is not enabled",
                    category="compute",
                    severity="medium"
                )

        # Templates
        templates = self._xe_list('template', 'uuid,name-label,is-a-snapshot')
        custom_templates = [t for t in templates if 'XCP' not in t.get('name-label', '') and 'CentOS' not in t.get('name-label', '')]
        if custom_templates:
            results.register(
                "Custom Templates",
                "PASS",
                f"{len(custom_templates)} custom template(s) available",
                category="compute"
            )


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for standalone execution"""
    import argparse

    parser = argparse.ArgumentParser(description="XCP-ng/Xen Security Audit Agent")
    parser.add_argument('--server', help='Central audit server URL')
    parser.add_argument('--api-key', help='API key for audit server')
    parser.add_argument('--categories', nargs='+', help='Categories to audit')
    parser.add_argument('--output', '-o', help='Output file for results (JSON)')

    args = parser.parse_args()

    agent = XenAgent(
        server_url=args.server,
        api_key=args.api_key
    )

    print("XCP-ng/Xen Agent v1.0.0")
    print(f"Platform: {agent.PLATFORM_NAME}")
    print(f"Version: {agent.platform_version}")
    print(f"Agent ID: {agent.agent_id}")
    print()

    # Run audit
    results = agent.run_audit(categories=args.categories)

    # Output results
    if args.output:
        with open(args.output, 'w') as f:
            f.write(results.to_json())
        print(f"\nResults written to {args.output}")

    # Submit to server if connected
    if agent.api and agent.registered:
        agent.submit_results(results)


if __name__ == '__main__':
    main()
