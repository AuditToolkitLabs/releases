#!/usr/bin/env bash
# =============================================================================
# Security Audit Toolkit - Standalone Standalone Agent Installer (Linux)
# =============================================================================
#
# Installs the lightweight standalone audit agent with its embedded web UI.
# Runs entirely independently of the central server — no server URL required.
#
# The agent can:
#   - Run audit scripts locally and write results to disk
#   - Optionally push results to a central server (configured later)
#   - Expose a local web UI for browsing results and triggering audits
#
# Requirements: bash 4+, python3 (>=3.9), pip3
# Supported:    Debian/Ubuntu, RHEL/Fedora/CentOS, Alpine, Arch, openSUSE
#
# Usage:
#   sudo ./install-standalone-linux.sh [OPTIONS]
#   ./install-standalone-linux.sh --user-mode   # No root required
#
# OPTIONS:
#   --user-mode             Install into ~/.audit-agent (no root)
#   --install-dir PATH      Override installation directory
#   --port PORT             Web UI port (default: 8088)
#   --bind HOST             Web UI bind address (default: 127.0.0.1)
#   --core-server URL       Optional central server URL
#   --api-key KEY           API key for central server
#   --enable-auth           Enable password auth on web UI
#   --auth-password PASS    Web UI password (prompted if --enable-auth and omitted)
#   --no-service            Skip service installation
#   --no-python-check       Skip Python version check
#   --uninstall             Remove the agent
#   -h, --help              Show this help
#
# EXAMPLES:
#   # Root install with service
#   sudo ./install-standalone-linux.sh
#
#   # User-mode (no root) — scheduled via cron
#   ./install-standalone-linux.sh --user-mode
#
#   # Pre-configured with central server
#   sudo ./install-standalone-linux.sh \
#     --core-server https://audit.example.com:5000 \
#     --api-key mykey
#
# Author: Security Audit Toolkit Team
# =============================================================================

set -euo pipefail

# =============================================================================
# Resolve version from the bundle's own VERSION file (works from any path)
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_resolve_version() {
    # 1. Explicit env override
    [[ -n "${AUDIT_AGENT_VERSION:-}" ]] && { echo "${AUDIT_AGENT_VERSION}"; return; }
    # 2. VERSION file sitting next to this script (injected by sync-agent-builds.sh)
    local f="${SCRIPT_DIR}/VERSION"
    [[ -f "$f" ]] && { tr -d '\r\n' < "$f"; return; }
    # 3. Last-resort hardcoded fallback
    echo "6.2.1"
}
AGENT_VERSION="$(_resolve_version)"

# =============================================================================
# Defaults (overridden by flags below)
# =============================================================================
USER_MODE=false
INSTALL_DIR="/opt/audit-agent-standalone"
SERVICE_USER="audit-agent"
SERVICE_GROUP="audit-agent"
SERVICE_NAME="audit-standalone-agent"
LOG_DIR="/var/log/audit-agent"
WEB_PORT=8088
WEB_BIND="127.0.0.1"
CORE_SERVER_URL=""
API_KEY=""
ENABLE_AUTH=false
AUTH_PASSWORD=""
SKIP_SERVICE=false
SKIP_PYTHON_CHECK=false
DO_UNINSTALL=false
PYTHON_MIN_MAJOR=3
PYTHON_MIN_MINOR=9

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

log_info()  { echo -e "${BLUE}[INFO]${NC} $*"; }
log_ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

banner() {
    echo ""
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   Security Audit Toolkit - Standalone Agent Installer v${AGENT_VERSION}${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# =============================================================================
# Argument parsing
# =============================================================================
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --user-mode)    USER_MODE=true; shift ;;
            --install-dir)  INSTALL_DIR="$2"; shift 2 ;;
            --port)         WEB_PORT="$2"; shift 2 ;;
            --bind)         WEB_BIND="$2"; shift 2 ;;
            --core-server)  CORE_SERVER_URL="$2"; shift 2 ;;
            --api-key)      API_KEY="$2"; shift 2 ;;
            --enable-auth)  ENABLE_AUTH=true; shift ;;
            --auth-password) AUTH_PASSWORD="$2"; shift 2 ;;
            --no-service)   SKIP_SERVICE=true; shift ;;
            --no-python-check) SKIP_PYTHON_CHECK=true; shift ;;
            --uninstall)    DO_UNINSTALL=true; shift ;;
            -h|--help)      show_usage; exit 0 ;;
            *)
                log_error "Unknown option: $1"
                echo "Run with --help for usage." >&2
                exit 1
                ;;
        esac
    done

    # User-mode: redirect paths to home directory
    if [[ "$USER_MODE" == "true" ]]; then
        INSTALL_DIR="${AUDIT_INSTALL_DIR:-$HOME/.audit-agent}"
        LOG_DIR="${INSTALL_DIR}/logs"
        SERVICE_USER="$(id -un)"
        SERVICE_GROUP="$(id -gn)"
    fi
}

show_usage() {
    sed -n '/^# Usage:/,/^# Author:/{ /^# Author:/d; s/^# \{0,1\}//; p }' "$0"
}

# =============================================================================
# Pre-flight checks
# =============================================================================
check_privileges() {
    if [[ "$USER_MODE" == "false" ]] && [[ $EUID -ne 0 ]]; then
        log_error "Root is required for system-wide install. Use --user-mode or run with sudo."
        exit 1
    fi
}

detect_init_system() {
    if command -v systemctl &>/dev/null && systemctl --version &>/dev/null 2>&1; then
        echo "systemd"
    elif command -v rc-service &>/dev/null; then
        echo "openrc"
    else
        echo "none"
    fi
}

detect_python() {
    local py
    for cmd in python3 python; do
        if command -v "$cmd" &>/dev/null; then
            local ver
            ver=$("$cmd" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)
            local major minor
            major="${ver%%.*}"
            minor="${ver##*.}"
            if [[ "$major" -ge "$PYTHON_MIN_MAJOR" && "$minor" -ge "$PYTHON_MIN_MINOR" ]] 2>/dev/null; then
                echo "$cmd"
                return 0
            fi
        fi
    done
    return 1
}

check_python() {
    [[ "$SKIP_PYTHON_CHECK" == "true" ]] && return 0

    local py
    if ! py=$(detect_python); then
        log_error "Python ${PYTHON_MIN_MAJOR}.${PYTHON_MIN_MINOR}+ is required but not found."
        log_error "Install Python 3 with your package manager and re-run this installer."
        exit 1
    fi
    log_ok "Python found: $py ($("$py" --version 2>&1))"
    echo "$py"
}

# =============================================================================
# Installation
# =============================================================================
create_directories() {
    log_info "Creating directories under ${INSTALL_DIR}..."
    mkdir -p "${INSTALL_DIR}"/{audits,lib,results,logs,web}
    mkdir -p "${LOG_DIR}"

    if [[ "$USER_MODE" == "false" ]]; then
        chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}" "${LOG_DIR}" 2>/dev/null || true
        chmod 750 "${INSTALL_DIR}" "${LOG_DIR}"
    fi
}

install_agent_files() {
    log_info "Copying agent files..."

    # Core entry-points
    for f in agent.sh run-silent.sh start-web.sh; do
        [[ -f "${SCRIPT_DIR}/${f}" ]] && { cp "${SCRIPT_DIR}/${f}" "${INSTALL_DIR}/"; chmod 750 "${INSTALL_DIR}/${f}"; }
    done

    # VERSION file (so resolve_agent_version() always has a live source)
    echo "${AGENT_VERSION}" > "${INSTALL_DIR}/VERSION"

    # Web UI
    if [[ -d "${SCRIPT_DIR}/web" ]]; then
        cp -r "${SCRIPT_DIR}/web/." "${INSTALL_DIR}/web/"
        log_ok "  web/"
    else
        log_error "web/ directory not found in ${SCRIPT_DIR} — cannot proceed."
        exit 1
    fi

    # Audit library
    if [[ -d "${SCRIPT_DIR}/lib" ]]; then
        cp -r "${SCRIPT_DIR}/lib/." "${INSTALL_DIR}/lib/"
        log_ok "  lib/"
    fi

    # Bundled audit scripts
    if [[ -d "${SCRIPT_DIR}/audits" ]]; then
        cp -r "${SCRIPT_DIR}/audits/." "${INSTALL_DIR}/audits/"
        log_ok "  audits/"
    fi

    # Templates
    if [[ -d "${SCRIPT_DIR}/templates" ]]; then
        cp -r "${SCRIPT_DIR}/templates/." "${INSTALL_DIR}/templates/"
        log_ok "  templates/"
    fi

    # Tools helpers
    if [[ -d "${SCRIPT_DIR}/tools" ]]; then
        cp -r "${SCRIPT_DIR}/tools/." "${INSTALL_DIR}/tools/"
        log_ok "  tools/"
    fi

    # requirements.txt
    if [[ -f "${SCRIPT_DIR}/requirements.txt" ]]; then
        cp "${SCRIPT_DIR}/requirements.txt" "${INSTALL_DIR}/"
    else
        log_warn "requirements.txt not found — Python web UI will not be set up"
    fi

    if [[ "$USER_MODE" == "false" ]]; then
        chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}" 2>/dev/null || true
    fi

    log_ok "Agent files installed to ${INSTALL_DIR}"
}

setup_python_venv() {
    local py="$1"
    log_info "Setting up Python virtual environment..."

    local venv_dir="${INSTALL_DIR}/.venv"

    if ! "$py" -m venv --help &>/dev/null 2>&1; then
        log_warn "python3-venv not available — installing into system Python (--user if user-mode)"
    fi

    # Create venv
    "$py" -m venv "${venv_dir}" 2>/dev/null \
        || { log_warn "venv creation failed, falling back to pip --user"; venv_dir=""; }

    local pip_cmd
    if [[ -n "$venv_dir" ]]; then
        pip_cmd="${venv_dir}/bin/pip"
    elif [[ "$USER_MODE" == "true" ]]; then
        pip_cmd="pip3 --user"
    else
        pip_cmd="pip3"
    fi

    log_info "Installing Python dependencies..."
    "$pip_cmd" install --quiet --upgrade pip
    "$pip_cmd" install --quiet -r "${INSTALL_DIR}/requirements.txt"

    if [[ -n "$venv_dir" ]]; then
        # Write an activation wrapper so start-web.sh and the service can activate
        cat > "${INSTALL_DIR}/activate-venv.sh" << EOF
#!/usr/bin/env bash
# Source this file to activate the agent's virtual environment
# shellcheck disable=SC1091
. "${venv_dir}/bin/activate"
EOF
        chmod 644 "${INSTALL_DIR}/activate-venv.sh"
        log_ok "Virtual environment: ${venv_dir}"
    fi
}

write_env_config() {
    log_info "Writing environment configuration..."

    local config_file="${INSTALL_DIR}/.env"
    local agent_id
    if [[ -f /etc/machine-id ]]; then
        agent_id="$(sha256sum /etc/machine-id | cut -c1-16)"
    else
        agent_id="$(hostname | sha256sum | cut -c1-16)"
    fi

    cat > "$config_file" << EOF
# Standalone Audit Agent — runtime configuration
# Generated by install-standalone-linux.sh v${AGENT_VERSION}

AGENT_VERSION=${AGENT_VERSION}
AGENT_ID=${agent_id}
WEB_PORT=${WEB_PORT}
WEB_BIND=${WEB_BIND}
EOF

    if [[ -n "$CORE_SERVER_URL" ]]; then
        printf 'SERVER_URL=%s\n' "$CORE_SERVER_URL" >> "$config_file"
    fi

    if [[ "$ENABLE_AUTH" == "true" ]]; then
        if [[ -z "$AUTH_PASSWORD" ]]; then
            read -rsp "Web UI password: " AUTH_PASSWORD; echo
        fi
        # Store as a bcrypt hash when cryptography/passlib is available;
        # otherwise store plaintext with a warning.  The agent reads AGENT_WEB_PASSWORD.
        printf 'AGENT_WEB_PASSWORD=%s\n' "$AUTH_PASSWORD" >> "$config_file"
        printf 'AGENT_ENABLE_AUTH=true\n' >> "$config_file"
        log_warn "Password stored in ${config_file} — ensure file permissions are 600"
    fi

    chmod 600 "$config_file"
    [[ "$USER_MODE" == "false" ]] && chown "${SERVICE_USER}:${SERVICE_GROUP}" "$config_file" 2>/dev/null || true

    log_ok "Configuration: ${config_file}"
}

# Optionally encrypt the API key with the machine key if openssl is present
store_api_key() {
    [[ -z "$API_KEY" ]] && return 0

    local cred_file="${INSTALL_DIR}/.credentials.enc"
    if command -v openssl &>/dev/null; then
        local machine_key
        machine_key="$(cat /etc/machine-id 2>/dev/null || hostname)$(hostname)audit-standalone-key"
        machine_key="$(echo -n "$machine_key" | sha256sum | cut -d' ' -f1)"
        echo -n "$API_KEY" | openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
            -pass "pass:${machine_key}" -base64 > "$cred_file"
        chmod 600 "$cred_file"
        [[ "$USER_MODE" == "false" ]] && chown "${SERVICE_USER}:${SERVICE_GROUP}" "$cred_file" 2>/dev/null || true
        log_ok "API key stored encrypted: ${cred_file}"
    else
        printf 'API_KEY=%s\n' "$API_KEY" >> "${INSTALL_DIR}/.env"
        log_warn "OpenSSL not found — API key written to .env (ensure 600 permissions)"
    fi
}

install_service() {
    local init="$1"

    if [[ "$SKIP_SERVICE" == "true" ]]; then
        log_info "Skipping service installation (--no-service)"
        return 0
    fi

    if [[ "$init" == "systemd" ]] && [[ "$USER_MODE" == "false" ]]; then
        log_info "Installing systemd service: ${SERVICE_NAME}..."

        cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=Security Audit Toolkit - Standalone Standalone Agent
Documentation=https://github.com/AuditToolkitLabs/Audit-Tool-
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_GROUP}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=-${INSTALL_DIR}/.env
ExecStart=${INSTALL_DIR}/start-web.sh --port ${WEB_PORT} --bind ${WEB_BIND} --log=${LOG_DIR}/agent.log
Restart=on-failure
RestartSec=10

NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${INSTALL_DIR} ${LOG_DIR}
PrivateTmp=true

StandardOutput=append:${LOG_DIR}/agent.log
StandardError=append:${LOG_DIR}/agent-error.log

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable "${SERVICE_NAME}"
        log_ok "Systemd service enabled: ${SERVICE_NAME}"

    elif [[ "$init" == "openrc" ]] && [[ "$USER_MODE" == "false" ]]; then
        log_info "Installing OpenRC service: ${SERVICE_NAME}..."

        cat > "/etc/init.d/${SERVICE_NAME}" << EOF
#!/sbin/openrc-run

name="audit-standalone-agent"
description="Security Audit Toolkit - Standalone Standalone Agent"
command="${INSTALL_DIR}/start-web.sh"
command_args="--port ${WEB_PORT} --bind ${WEB_BIND} --log=${LOG_DIR}/agent.log"
command_user="${SERVICE_USER}:${SERVICE_GROUP}"
command_background="yes"
pidfile="/run/\${RC_SVCNAME}.pid"
start_stop_daemon_args="--make-pidfile"
output_log="${LOG_DIR}/agent.log"
error_log="${LOG_DIR}/agent-error.log"

depend() {
    need net
}
EOF
        chmod 755 "/etc/init.d/${SERVICE_NAME}"
        rc-update add "${SERVICE_NAME}" default 2>/dev/null || true
        log_ok "OpenRC service enabled: ${SERVICE_NAME}"

    elif [[ "$USER_MODE" == "true" ]]; then
        # Systemd user unit
        local user_unit_dir="${HOME}/.config/systemd/user"
        mkdir -p "$user_unit_dir"

        cat > "${user_unit_dir}/${SERVICE_NAME}.service" << EOF
[Unit]
Description=Security Audit Toolkit - Standalone Agent (user mode)
After=default.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=-${INSTALL_DIR}/.env
ExecStart=${INSTALL_DIR}/start-web.sh --port ${WEB_PORT} --bind ${WEB_BIND}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
EOF
        systemctl --user daemon-reload 2>/dev/null || true
        if systemctl --user enable "${SERVICE_NAME}" 2>/dev/null; then
            log_ok "User systemd service enabled: ${SERVICE_NAME}"
        else
            log_warn "Could not enable user service — start manually: ${INSTALL_DIR}/start-web.sh"
        fi
    else
        log_warn "Unknown init system — skipping service install"
        log_warn "Start manually: ${INSTALL_DIR}/start-web.sh --port ${WEB_PORT}"
    fi
}

do_uninstall() {
    log_info "Uninstalling standalone agent..."

    for init in systemd openrc; do
        if command -v systemctl &>/dev/null; then
            systemctl stop "${SERVICE_NAME}" 2>/dev/null || true
            systemctl disable "${SERVICE_NAME}" 2>/dev/null || true
            rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
            systemctl daemon-reload 2>/dev/null || true
        fi
        if command -v rc-update &>/dev/null; then
            rc-update del "${SERVICE_NAME}" 2>/dev/null || true
            rm -f "/etc/init.d/${SERVICE_NAME}"
        fi
    done

    rm -rf "${INSTALL_DIR}"
    log_ok "Uninstalled from ${INSTALL_DIR}"
    exit 0
}

print_next_steps() {
    local init="$1"
    local start_cmd=""

    if [[ "$USER_MODE" == "false" ]]; then
        case "$init" in
            systemd) start_cmd="sudo systemctl start ${SERVICE_NAME}" ;;
            openrc)  start_cmd="sudo rc-service ${SERVICE_NAME} start" ;;
            *)       start_cmd="${INSTALL_DIR}/start-web.sh --port ${WEB_PORT} &" ;;
        esac
    else
        start_cmd="systemctl --user start ${SERVICE_NAME}  # or: ${INSTALL_DIR}/start-web.sh"
    fi

    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo " Installation complete — v${AGENT_VERSION}"
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    echo " Start the agent:"
    echo "   ${start_cmd}"
    echo ""
    echo " Web UI:  http://${WEB_BIND}:${WEB_PORT}"
    echo " Logs:    ${LOG_DIR}/agent.log"
    echo " Config:  ${INSTALL_DIR}/.env"
    echo ""
    if [[ -n "$CORE_SERVER_URL" ]]; then
        echo " Central server: ${CORE_SERVER_URL}"
        echo ""
    fi
    echo " Run audit manually:"
    echo "   cd ${INSTALL_DIR} && bash agent.sh scan"
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
}

# =============================================================================
# Entry point
# =============================================================================
main() {
    parse_args "$@"
    banner

    if [[ "$DO_UNINSTALL" == "true" ]]; then
        do_uninstall
    fi

    check_privileges
    local py init
    py=$(check_python)
    init=$(detect_init_system)

    log_info "Install directory:  ${INSTALL_DIR}"
    log_info "Mode:               $([ "$USER_MODE" == "true" ] && echo user || echo system)"
    log_info "Init system:        ${init}"
    log_info "Web UI:             http://${WEB_BIND}:${WEB_PORT}"
    [[ -n "$CORE_SERVER_URL" ]] && log_info "Central server:     ${CORE_SERVER_URL}"
    echo ""

    if [[ "$USER_MODE" == "false" ]]; then
        # Ensure service user exists
        if ! getent group "$SERVICE_GROUP" &>/dev/null; then
            groupadd --system "$SERVICE_GROUP"
        fi
        if ! getent passwd "$SERVICE_USER" &>/dev/null; then
            useradd --system \
                --gid "$SERVICE_GROUP" \
                --home-dir "$INSTALL_DIR" \
                --shell /usr/sbin/nologin \
                --comment "Audit Agent" \
                "$SERVICE_USER"
        fi
    fi

    create_directories
    install_agent_files
    setup_python_venv "$py"
    write_env_config
    store_api_key
    install_service "$init"
    print_next_steps "$init"
}

main "$@"
