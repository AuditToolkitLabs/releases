<#
.SYNOPSIS
    Security Audit Toolkit - Standalone Standalone Agent Installer (Windows)

.DESCRIPTION
    Installs the standalone lightweight audit agent with its embedded web UI.
    Runs entirely independently of the central server — no server URL required.

    The agent can:
      - Run audit scripts locally and write results to disk
      - Optionally push results to a central server (configured later)
      - Expose a local web UI for browsing results and triggering audits

    Requires: PowerShell 5.1+, Python 3.9+

.PARAMETER InstallDir
    Installation directory. Default: C:\AuditAgent

.PARAMETER Port
    Web UI port. Default: 8088

.PARAMETER BindHost
    Web UI bind address. Default: 127.0.0.1

.PARAMETER CoreServerUrl
    Optional URL of the central audit server.

.PARAMETER ApiKey
    API key for the central server (stored encrypted with DPAPI).

.PARAMETER EnableAuth
    Enable password authentication on the web UI.

.PARAMETER AuthPassword
    Web UI password (prompted if -EnableAuth and omitted).

.PARAMETER InstallMode
    How to install the scheduler: Service (Windows Service) or Task
    (Scheduled Task, default). Task does not require admin rights.

.PARAMETER UserMode
    Install into the current user's profile directory without admin rights.
    Uses a Scheduled Task that runs at logon.

.PARAMETER NoService
    Skip service/task installation. Agent can be started manually.

.PARAMETER NoPythonCheck
    Skip Python version check.

.PARAMETER Uninstall
    Remove the agent and its service/task.

.EXAMPLE
    .\install-standalone-windows.ps1
    System-wide install with a Scheduled Task, web UI on localhost:8088.

.EXAMPLE
    .\install-standalone-windows.ps1 -UserMode
    User-profile install — no admin required.

.EXAMPLE
    .\install-standalone-windows.ps1 -CoreServerUrl "https://audit.example.com:5000" -ApiKey "s3cr3t"
    Install pre-configured to push results to a central server.

.EXAMPLE
    .\install-standalone-windows.ps1 -EnableAuth -AuthPassword "MyPass1!"
    Install with web UI login enabled.

.NOTES
    Author:  Security Audit Toolkit Team
    Version: Resolved at runtime from VERSION file in the same directory
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$InstallDir    = 'C:\AuditAgent',
    [int]   $Port          = 8088,
    [string]$BindHost      = '127.0.0.1',
    [string]$CoreServerUrl = '',
    [System.Security.SecureString]$ApiKey,
    [switch]$EnableAuth,
    [System.Security.SecureString]$AuthPassword,
    [ValidateSet('Service', 'Task')]
    [string]$InstallMode   = 'Task',
    [switch]$UserMode,
    [switch]$NoService,
    [switch]$NoPythonCheck,
    [switch]$Uninstall
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =============================================================================
# Version resolution — reads from the VERSION file co-packaged in the same
# directory as this script. Falls back to the environment variable, then a
# hardcoded string. This works after extraction to any path on a target machine.
# =============================================================================
function Resolve-AgentVersion {
    # 1. Explicit env override
    if ($env:AUDIT_AGENT_VERSION) { return $env:AUDIT_AGENT_VERSION }
    # 2. VERSION file sitting next to this script
    $vFile = Join-Path $PSScriptRoot 'VERSION'
    if (Test-Path $vFile) {
        return ((Get-Content $vFile -Raw).Trim())
    }
    # 3. Hardcoded fallback
    return '6.2.1'
}

$script:AgentVersion    = Resolve-AgentVersion
$script:ScriptDir       = $PSScriptRoot
$script:ServiceName     = 'AuditStandaloneAgent'
$script:TaskName        = 'Audit Standalone Agent'
$script:ServiceUser     = 'NT AUTHORITY\NetworkService'

# Redirect install dir for user-mode
if ($UserMode) {
    if ($InstallDir -eq 'C:\AuditAgent') {
        $InstallDir = Join-Path $env:LOCALAPPDATA 'AuditAgent'
    }
    $InstallMode = 'Task'
}

# =============================================================================
# Helpers
# =============================================================================
function Write-Banner {
    Write-Host ''
    Write-Host '╔══════════════════════════════════════════════════════════════════╗' -ForegroundColor Cyan
    Write-Host ("║   Security Audit Toolkit - Standalone Agent Installer v{0,-12}║" -f ($script:AgentVersion + ' ')) -ForegroundColor Cyan
    Write-Host '╚══════════════════════════════════════════════════════════════════╝' -ForegroundColor Cyan
    Write-Host ''
}

function Write-Info  { param([string]$m) Write-Host "[INFO]  $m" -ForegroundColor Cyan   }
function Write-OK    { param([string]$m) Write-Host "[OK]    $m" -ForegroundColor Green  }
function Write-Warn  { param([string]$m) Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Write-Fail  { param([string]$m) Write-Host "[ERROR] $m" -ForegroundColor Red    }

function Test-AdminRights {
    $cur = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    return $cur.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# =============================================================================
# Python detection
# =============================================================================
function Find-Python {
    $candidates = @('python', 'python3', 'py')
    foreach ($cmd in $candidates) {
        try {
            $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            if ($ver -match '^(\d+)\.(\d+)$') {
                $major = [int]$Matches[1]; $minor = [int]$Matches[2]
                if ($major -ge 3 -and $minor -ge 9) {
                    return $cmd
                }
            }
        } catch { }
    }
    return $null
}

function Assert-Python {
    if ($NoPythonCheck) { return 'python' }
    $py = Find-Python
    if (-not $py) {
        Write-Fail 'Python 3.9+ is required but not found.'
        Write-Fail 'Download from https://www.python.org/ or install via winget: winget install Python.Python.3'
        throw 'Python not found'
    }
    Write-OK "Python found: $py ($( & $py --version 2>&1 ))"
    return $py
}

# =============================================================================
# File installation
# =============================================================================
function Install-AgentFiles {
    Write-Info "Creating directory structure under $InstallDir ..."
    $subdirs = @('audits', 'lib', 'results', 'logs', 'web', 'tools', 'templates')
    foreach ($d in $subdirs) {
        $null = New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir $d)
    }

    Write-Info 'Copying agent files...'

    # Core entry-points
    foreach ($f in @('agent.ps1', 'agent.sh', 'start-web.ps1', 'start-web.sh')) {
        $src = Join-Path $script:ScriptDir $f
        if (Test-Path $src) {
            Copy-Item $src -Destination $InstallDir -Force
            Write-OK "  $f"
        }
    }

    # VERSION file (so the web UI resolve_agent_version() finds a live source)
    Set-Content -Path (Join-Path $InstallDir 'VERSION') -Value $script:AgentVersion -NoNewline

    # Web UI
    $webSrc = Join-Path $script:ScriptDir 'web'
    if (Test-Path $webSrc) {
        Copy-Item $webSrc -Destination $InstallDir -Recurse -Force
        Write-OK '  web\'
    } else {
        Write-Fail "web\ not found in $($script:ScriptDir) — cannot proceed."
        throw 'Missing web directory'
    }

    foreach ($d in @('lib', 'audits', 'templates', 'tools')) {
        $src = Join-Path $script:ScriptDir $d
        if (Test-Path $src) {
            Copy-Item $src -Destination $InstallDir -Recurse -Force
            Write-OK "  $d\"
        }
    }

    # requirements.txt
    $reqSrc = Join-Path $script:ScriptDir 'requirements.txt'
    if (Test-Path $reqSrc) {
        Copy-Item $reqSrc -Destination $InstallDir -Force
    } else {
        Write-Warn 'requirements.txt not found — Python web UI will not be set up'
    }

    Write-OK "Agent files installed to $InstallDir"
}

# =============================================================================
# Python virtual environment + dependencies
# =============================================================================
function Install-PythonDeps {
    param([string]$PythonCmd)

    Write-Info 'Setting up Python virtual environment...'
    $venvDir = Join-Path $InstallDir '.venv'

    try {
        & $PythonCmd -m venv $venvDir
        $pip = Join-Path $venvDir 'Scripts\pip.exe'
        & $pip install --quiet --upgrade pip
        & $pip install --quiet -r (Join-Path $InstallDir 'requirements.txt')
        Write-OK "Virtual environment: $venvDir"

        # Write an activation marker used by the service/task launcher
        Set-Content -Path (Join-Path $InstallDir 'venv-activate.txt') -Value $venvDir
    } catch {
        Write-Warn "venv setup failed ($_) — falling back to --user install"
        & $PythonCmd -m pip install --user --quiet -r (Join-Path $InstallDir 'requirements.txt')
    }
}

# =============================================================================
# Configuration
# =============================================================================
function New-AgentConfig {
    Write-Info 'Writing agent configuration...'

    # Generate a stable agent ID from the machine SID
    $agentId = try {
        $sid = (Get-CimInstance Win32_ComputerSystemProduct).UUID
        [System.BitConverter]::ToString(
            [System.Security.Cryptography.SHA256]::Create().ComputeHash(
                [System.Text.Encoding]::UTF8.GetBytes($sid)
            )
        ).Replace('-','').Substring(0,16).ToLower()
    } catch {
        [System.Guid]::NewGuid().ToString('N').Substring(0,16)
    }

    $envFile = Join-Path $InstallDir '.env'
    $lines = @(
        "# Standalone Audit Agent - runtime configuration",
        "# Generated by install-standalone-windows.ps1 v$($script:AgentVersion)",
        "",
        "AGENT_VERSION=$($script:AgentVersion)",
        "AGENT_ID=$agentId",
        "WEB_PORT=$Port",
        "WEB_BIND=$BindHost"
    )

    if ($CoreServerUrl) {
        $lines += "SERVER_URL=$CoreServerUrl"
    }

    if ($EnableAuth) {
        $secPass = if ($AuthPassword -and $AuthPassword.Length -gt 0) {
            $AuthPassword
        } else {
            Read-Host -Prompt 'Web UI password' -AsSecureString
        }
        $pass = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPass)
        )
        $lines += "AGENT_WEB_PASSWORD=$pass"
        $lines += "AGENT_ENABLE_AUTH=true"
        Write-Warn "Password stored in $envFile — ensure this file has restricted ACLs"
    }

    $lines | Set-Content -Path $envFile
    Write-OK "Configuration: $envFile"

    # Restrict ACL on .env
    try {
        $acl = Get-Acl $envFile
        $acl.SetAccessRuleProtection($true, $false)
        $owner = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $rule  = [Security.AccessControl.FileSystemAccessRule]::new(
            $owner,
            [Security.AccessControl.FileSystemRights]::FullControl,
            [Security.AccessControl.AccessControlType]::Allow
        )
        $acl.AddAccessRule($rule)
        Set-Acl $envFile $acl
    } catch {
        Write-Warn "Could not restrict .env ACL: $_"
    }
}

function Save-ApiKey {
    if (-not $ApiKey -or $ApiKey.Length -eq 0) { return }

    Write-Info 'Encrypting API key with DPAPI...'
    $credFile = Join-Path $InstallDir '.credentials.enc'
    try {
        $plainKey  = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [Runtime.InteropServices.Marshal]::SecureStringToBSTR($ApiKey)
        )
        $bytes     = [System.Text.Encoding]::UTF8.GetBytes($plainKey)
        $scope     = if ($UserMode) {
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        } else {
            [System.Security.Cryptography.DataProtectionScope]::LocalMachine
        }
        $encrypted = [System.Security.Cryptography.ProtectedData]::Protect(
            $bytes, $null, $scope
        )
        [System.IO.File]::WriteAllBytes($credFile, $encrypted)
        Write-OK "API key stored encrypted: $credFile"
    } catch {
        Write-Warn "DPAPI unavailable ($_) — API key written to .env as fallback"
        Add-Content -Path (Join-Path $InstallDir '.env') -Value "API_KEY=$plainKey"
    }
}

# =============================================================================
# Service / task registration
# =============================================================================
function Get-PythonExe {
    $venvFile = Join-Path $InstallDir 'venv-activate.txt'
    if (Test-Path $venvFile) {
        $venvDir = (Get-Content $venvFile).Trim()
        $py = Join-Path $venvDir 'Scripts\python.exe'
        if (Test-Path $py) { return $py }
    }
    $found = Find-Python
    return $found ?? 'python'
}

function Register-ScheduledTask-Agent {
    Write-Info 'Registering Scheduled Task...'

    $appPy  = Join-Path $InstallDir 'web\app.py'
    $pyExe  = Get-PythonExe
    $action = New-ScheduledTaskAction -Execute $pyExe `
                  -Argument "$appPy --port $Port --bind $BindHost" `
                  -WorkingDirectory $InstallDir

    $trigger = if ($UserMode) {
        New-ScheduledTaskTrigger -AtLogOn
    } else {
        New-ScheduledTaskTrigger -AtStartup
    }

    $settings = New-ScheduledTaskSettingsSet `
        -ExecutionTimeLimit ([TimeSpan]::Zero) `
        -RestartCount 3 `
        -RestartInterval (New-TimeSpan -Minutes 1)

    $principal = if ($UserMode) {
        New-ScheduledTaskPrincipal -UserId $env:USERNAME -RunLevel Limited
    } else {
        New-ScheduledTaskPrincipal -UserId $script:ServiceUser -RunLevel Highest
    }

    $params = @{
        TaskName    = $script:TaskName
        Action      = $action
        Trigger     = $trigger
        Settings    = $settings
        Principal   = $principal
        Description = "Security Audit Toolkit - Standalone Agent v$($script:AgentVersion)"
        Force       = $true
    }

    Register-ScheduledTask @params | Out-Null
    Write-OK "Scheduled Task registered: '$($script:TaskName)'"
}

function Install-AsWindowsService {
    Write-Info 'Installing Windows Service...'

    if (-not (Test-AdminRights)) {
        Write-Warn 'Admin rights required for Windows Service — falling back to Scheduled Task'
        Register-ScheduledTask-Agent
        return
    }

    $pyExe = Get-PythonExe
    $appPy = Join-Path $InstallDir 'web\app.py'

    # Use NSSM if available, otherwise sc.exe
    $nssm = Get-Command nssm -ErrorAction SilentlyContinue
    if ($nssm) {
        & nssm install $script:ServiceName $pyExe "$appPy --port $Port --bind $BindHost"
        & nssm set $script:ServiceName AppDirectory $InstallDir
        & nssm set $script:ServiceName DisplayName  'Security Audit Toolkit - Standalone Agent'
        & nssm set $script:ServiceName Start        SERVICE_AUTO_START
        Write-OK "Windows Service installed via NSSM: $($script:ServiceName)"
    } else {
        Write-Warn 'NSSM not found — falling back to Scheduled Task (recommended for Python services)'
        Register-ScheduledTask-Agent
    }
}

function Install-AgentService {
    if ($NoService) {
        Write-Info 'Skipping service/task installation (--NoService)'
        return
    }

    if ($InstallMode -eq 'Service') {
        Install-AsWindowsService
    } else {
        Register-ScheduledTask-Agent
    }
}

# =============================================================================
# Uninstall
# =============================================================================
function Remove-Agent {
    Write-Info 'Uninstalling standalone agent...'

    # Stop and remove scheduled task
    try {
        $t = Get-ScheduledTask -TaskName $script:TaskName -ErrorAction SilentlyContinue
        if ($t) {
            Stop-ScheduledTask  -TaskName $script:TaskName -ErrorAction SilentlyContinue
            Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false
            Write-OK 'Scheduled Task removed'
        }
    } catch { Write-Warn "Task removal: $_" }

    # Stop and remove service
    try {
        $svc = Get-Service -Name $script:ServiceName -ErrorAction SilentlyContinue
        if ($svc) {
            Stop-Service $script:ServiceName -Force -ErrorAction SilentlyContinue
            & sc.exe delete $script:ServiceName | Out-Null
            Write-OK 'Windows Service removed'
        }
    } catch { Write-Warn "Service removal: $_" }

    # Remove files
    if (Test-Path $InstallDir) {
        Remove-Item $InstallDir -Recurse -Force
        Write-OK "Removed: $InstallDir"
    }

    Write-OK 'Uninstall complete'
    exit 0
}

# =============================================================================
# Post-install summary
# =============================================================================
function Show-NextSteps {
    $startCmd = if ($InstallMode -eq 'Service') {
        "Start-Service $($script:ServiceName)"
    } else {
        "Start-ScheduledTask '$($script:TaskName)'"
    }
    if ($NoService) {
        $startCmd = "& `"$InstallDir\start-web.ps1`" -Port $Port"
    }

    Write-Host ''
    Write-Host '═══════════════════════════════════════════════════════════════════'
    Write-Host " Installation complete — v$($script:AgentVersion)"
    Write-Host '═══════════════════════════════════════════════════════════════════'
    Write-Host ''
    Write-Host ' Start the agent:'
    Write-Host "   $startCmd"
    Write-Host ''
    Write-Host " Web UI:  http://${BindHost}:${Port}"
    Write-Host " Logs:    $InstallDir\logs\agent.log"
    Write-Host " Config:  $InstallDir\.env"
    if ($CoreServerUrl) {
        Write-Host ''
        Write-Host " Central server: $CoreServerUrl"
    }
    Write-Host ''
    Write-Host ' Run audit manually:'
    Write-Host "   Set-Location '$InstallDir'; .\agent.ps1 scan"
    Write-Host ''
    Write-Host '═══════════════════════════════════════════════════════════════════'
}

# =============================================================================
# Entry point
# =============================================================================
Write-Banner

if ($Uninstall) { Remove-Agent }

if (-not $UserMode -and -not (Test-AdminRights)) {
    Write-Fail 'Administrator rights required for a system-wide install. Re-run as admin, or use -UserMode.'
    exit 1
}

$py = Assert-Python

Write-Info "Install directory:  $InstallDir"
Write-Info "Mode:               $(if ($UserMode) { 'user' } else { 'system' })"
Write-Info "Install type:       $(if ($NoService) { 'manual' } else { $InstallMode })"
Write-Info "Web UI:             http://${BindHost}:${Port}"
if ($CoreServerUrl) { Write-Info "Central server:     $CoreServerUrl" }
Write-Host ''

Install-AgentFiles
Install-PythonDeps -PythonCmd $py
New-AgentConfig
Save-ApiKey
Install-AgentService
Show-NextSteps
