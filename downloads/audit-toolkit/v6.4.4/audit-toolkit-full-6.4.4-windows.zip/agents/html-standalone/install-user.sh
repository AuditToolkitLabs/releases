#!/usr/bin/env bash
# =============================================================================
# Managed Security Audit Agent - User-Mode Installation Script
# =============================================================================
# Installs the fleet agent WITHOUT requiring root access:
# - Installs to user's home directory (~/.audit-agent)
# - Creates a systemd user service (runs as current user)
# - Works with or without sudo access
# - If sudo is available, audit scripts can use it for privileged checks
#
# Run as regular user: ./install-user.sh [OPTIONS]
#
# For enhanced auditing capabilities, an admin can optionally configure
# sudoers rules by running: sudo ./setup-sudoers.sh
#
# Author: Security Audit Toolkit Team
# Version: 6.2.1
# =============================================================================

set -euo pipefail

# =============================================================================
# Configuration
# =============================================================================
# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION_FILE="${SCRIPT_DIR}/VERSION"
if [[ -f "$VERSION_FILE" ]]; then
    AGENT_VERSION="$(tr -d '\r\n' < "$VERSION_FILE")"
else
    AGENT_VERSION="${AUDIT_AGENT_VERSION:-6.2.1}"
fi
INSTALL_DIR="${AUDIT_INSTALL_DIR:-$HOME/.audit-agent}"
SERVICE_NAME="audit-fleet-agent"
SYSTEMD_USER_DIR="$HOME/.config/systemd/user"
LOG_FILE="$INSTALL_DIR/logs/agent.log"

# Server configuration
SERVER_URL="${AUDIT_SERVER_URL:-}"
API_KEY="${AUDIT_API_KEY:-}"
AGENT_ID="${AUDIT_AGENT_ID:-}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# =============================================================================
# Helper Functions
# =============================================================================
log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_header() { echo -e "\n${BLUE}═══════════════════════════════════════════════════════════════${NC}"; echo -e "${BLUE}  $*${NC}"; echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}\n"; }

show_usage() {
    cat << EOF
Usage: $(basename "$0") [OPTIONS]

Install the Managed Security Audit Agent as a user service.
Does NOT require root access.

Options:
  -s, --server URL     Server URL (e.g., https://audit.company.com)
  -k, --api-key KEY    API key for authentication
  -i, --agent-id ID    Agent ID (auto-generated if not provided)
  -d, --install-dir    Installation directory (default: ~/.audit-agent)
  -u, --uninstall      Uninstall the agent
  -h, --help           Show this help message

Environment Variables:
  AUDIT_SERVER_URL     Server URL
  AUDIT_API_KEY        API key
  AUDIT_AGENT_ID       Agent ID
  AUDIT_INSTALL_DIR    Installation directory

Examples:
  # Interactive installation
  ./install-user.sh

  # Non-interactive installation
  ./install-user.sh -s https://audit.company.com -k your-api-key

  # Uninstall
  ./install-user.sh --uninstall

EOF
    exit 0
}

check_dependencies() {
    log_info "Checking dependencies..."

    local missing=()

    # Required commands
    for cmd in bash curl jq; do
        if ! command -v "$cmd" &>/dev/null; then
            missing+=("$cmd")
        fi
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        log_error "Missing required commands: ${missing[*]}"
        log_error "Please install them first:"

        # Detect package manager and suggest install command
        if command -v apt &>/dev/null; then
            log_info "  sudo apt install ${missing[*]}"
        elif command -v dnf &>/dev/null; then
            log_info "  sudo dnf install ${missing[*]}"
        elif command -v yum &>/dev/null; then
            log_info "  sudo yum install ${missing[*]}"
        elif command -v apk &>/dev/null; then
            log_info "  sudo apk add ${missing[*]}"
        elif command -v pacman &>/dev/null; then
            log_info "  sudo pacman -S ${missing[*]}"
        fi

        exit 1
    fi

    log_info "All dependencies satisfied"
}

check_sudo_status() {
    log_info "Checking sudo availability..." >&2

    # Check if sudo exists
    if ! command -v sudo &>/dev/null; then
        log_warn "sudo not installed - agent will run with reduced capabilities"
        echo "none"
        return
    fi

    # Check if user can use sudo without password
    if sudo -n true 2>/dev/null; then
        log_info "Passwordless sudo available - full audit capabilities" >&2
        echo "nopasswd"
        return
    fi

    # Check if user is in sudo group
    if groups 2>/dev/null | grep -qE '\b(sudo|wheel|admin)\b'; then
        log_warn "User can use sudo but password required"
        log_warn "For unattended operation, ask admin to run setup-sudoers.sh"
        echo "password"
        return
    fi

    log_warn "No sudo access - agent will run with reduced capabilities"
    echo "none"
}

# =============================================================================
# Installation Steps
# =============================================================================

create_directories() {
    log_info "Creating directories in $INSTALL_DIR..."

    mkdir -p "$INSTALL_DIR"/{audits,lib,results,logs,.cache}

    # Secure permissions (user-only access)
    chmod 700 "$INSTALL_DIR"
    chmod 700 "$INSTALL_DIR/.cache"

    log_info "Directories created"
}

copy_agent_files() {
    log_info "Copying agent files..."

    # Copy main agent script
    if [[ -f "$SCRIPT_DIR/fleet-agent.sh" ]]; then
        cp "$SCRIPT_DIR/fleet-agent.sh" "$INSTALL_DIR/"
        chmod 755 "$INSTALL_DIR/fleet-agent.sh"
    else
        log_error "fleet-agent.sh not found in $SCRIPT_DIR"
        exit 1
    fi

    # Copy lib files if present
    if [[ -d "$SCRIPT_DIR/lib" ]]; then
        cp -r "$SCRIPT_DIR/lib/"* "$INSTALL_DIR/lib/" 2>/dev/null || true
    fi

    # Copy audit scripts if present
    if [[ -d "$SCRIPT_DIR/audits" ]]; then
        cp -r "$SCRIPT_DIR/audits/"* "$INSTALL_DIR/audits/" 2>/dev/null || true
    fi

    log_info "Agent files copied"
}

generate_agent_id() {
    # Generate a unique agent ID based on hostname and a random component
    local hostname
    hostname=$(hostname -s 2>/dev/null || echo "unknown")
    local random_part
    random_part=$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n' | head -c 8)
    echo "${hostname}-${random_part}"
}

create_config() {
    log_info "Creating configuration..."

    local config_file="$INSTALL_DIR/agent.config.json"
    local sudo_status
    sudo_status=$(check_sudo_status)

    # Generate agent ID if not provided
    if [[ -z "$AGENT_ID" ]]; then
        AGENT_ID=$(generate_agent_id)
        log_info "Generated agent ID: $AGENT_ID"
    fi

    # Create config file
    cat > "$config_file" << EOF
{
    "agent_id": "$AGENT_ID",
    "server_url": "$SERVER_URL",
    "poll_interval": 60,
    "auto_discovery": true,
    "discovery_interval": 3600,
    "use_sudo": $([ "$sudo_status" = "nopasswd" ] && echo "true" || echo "false"),
    "sudo_mode": "$sudo_status",
    "reduced_capability_mode": $([ "$sudo_status" = "none" ] && echo "true" || echo "false"),
    "log_level": "INFO",
    "log_file": "$LOG_FILE",
    "install_dir": "$INSTALL_DIR",
    "version": "$AGENT_VERSION",
    "installed_at": "$(date -Iseconds)",
    "installed_by": "$(whoami)"
}
EOF

    chmod 600 "$config_file"

    # Store API key securely (encrypted with user's own key)
    if [[ -n "$API_KEY" ]]; then
        local cred_file="$INSTALL_DIR/.credentials"
        # Simple obfuscation - in production, use proper encryption
        echo "$API_KEY" | base64 > "$cred_file"
        chmod 600 "$cred_file"
    fi

    log_info "Configuration created"
}

create_environment_file() {
    log_info "Creating environment file..."

    local env_file="$INSTALL_DIR/.env"

    cat > "$env_file" << EOF
# Audit Agent Environment Configuration
# Generated on $(date)

AUDIT_SERVER_URL=$SERVER_URL
AUDIT_AGENT_ID=$AGENT_ID
AUDIT_INSTALL_DIR=$INSTALL_DIR
AUDIT_LOG_FILE=$LOG_FILE

# Sudo handling
# Set to 'true' if passwordless sudo is configured
AUDIT_USE_SUDO=$(check_sudo_status | grep -q 'nopasswd' && echo "true" || echo "false")

# Auto-discovery
AUDIT_AUTO_DISCOVERY=true
AUDIT_DISCOVERY_INTERVAL=3600

# Asset Discovery URL (if separate from main server)
# AUDIT_ASSET_DISCOVERY_URL=
EOF

    chmod 600 "$env_file"
    log_info "Environment file created at $env_file"
}

create_systemd_user_service() {
    log_info "Creating systemd user service..."

    # Create systemd user directory
    mkdir -p "$SYSTEMD_USER_DIR"

    local service_file="$SYSTEMD_USER_DIR/${SERVICE_NAME}.service"

    cat > "$service_file" << EOF
[Unit]
Description=Managed Security Audit Agent
Documentation=https://github.com/yourorg/audit-toolkit
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/bash $INSTALL_DIR/fleet-agent.sh daemon
WorkingDirectory=$INSTALL_DIR
Environment="AUDIT_SERVER_URL=$SERVER_URL"
Environment="AUDIT_AGENT_ID=$AGENT_ID"
Environment="AUDIT_INSTALL_DIR=$INSTALL_DIR"
EnvironmentFile=-$INSTALL_DIR/.env

# Restart on failure
Restart=on-failure
RestartSec=30

# Resource limits (agent should be lightweight)
MemoryMax=512M
CPUQuota=25%

# Logging
StandardOutput=append:$LOG_FILE
StandardError=append:$LOG_FILE

[Install]
WantedBy=default.target
EOF

    log_info "Systemd user service created"

    # Reload systemd user daemon
    if command -v systemctl &>/dev/null; then
        systemctl --user daemon-reload 2>/dev/null || true
    fi
}

create_launcher_script() {
    log_info "Creating launcher script..."

    local launcher="$INSTALL_DIR/audit-agent"

    cat > "$launcher" << 'LAUNCHER'
#!/usr/bin/env bash
# Audit Agent Launcher
# Loads environment and runs the agent

SOURCE="${BASH_SOURCE[0]}"
while [[ -L "$SOURCE" ]]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ "$SOURCE" != /* ]] && SOURCE="$DIR/$SOURCE"
done
INSTALL_DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"

# Load environment
if [[ -f "$INSTALL_DIR/.env" ]]; then
    set -a
    # shellcheck disable=SC1091
    source "$INSTALL_DIR/.env"
    set +a
fi

# Load API key
if [[ -f "$INSTALL_DIR/.credentials" ]]; then
    export AUDIT_API_KEY=$(base64 -d "$INSTALL_DIR/.credentials" 2>/dev/null)
fi

# Run agent
exec bash "$INSTALL_DIR/fleet-agent.sh" "$@"
LAUNCHER

    chmod 755 "$launcher"

    # Create symlink in user's bin directory
    mkdir -p "$HOME/.local/bin"
    ln -sf "$launcher" "$HOME/.local/bin/audit-agent"

    log_info "Launcher script created"
    log_info "You can run the agent with: ~/.local/bin/audit-agent"
}

enable_service() {
    log_info "Enabling service..."

    if command -v systemctl &>/dev/null; then
        # Enable lingering for the user (allows service to run without login)
        # This requires admin permissions, so we'll just try it
        if command -v loginctl &>/dev/null; then
            loginctl enable-linger "$(whoami)" 2>/dev/null || log_warn "Could not enable linger - service may stop on logout"
        fi

        # Enable and start the user service
        systemctl --user enable "$SERVICE_NAME" 2>/dev/null || log_warn "Could not enable service"
        systemctl --user start "$SERVICE_NAME" 2>/dev/null || log_warn "Could not start service"

        # Check status
        if systemctl --user is-active "$SERVICE_NAME" &>/dev/null; then
            log_info "Service started successfully"
        else
            log_warn "Service may not have started - check: systemctl --user status $SERVICE_NAME"
        fi
    else
        log_warn "systemd not available - you'll need to run the agent manually"
        log_info "Run: $INSTALL_DIR/audit-agent daemon"
    fi
}

create_sudoers_setup_script() {
    log_info "Preparing sudoers helper for administrators..."

    local source_helper="$SCRIPT_DIR/setup-sudoers.sh"
    local helper_file="$INSTALL_DIR/setup-sudoers.sh"

    if [[ ! -f "$source_helper" ]]; then
        log_warn "setup-sudoers.sh not found in $SCRIPT_DIR - skipping helper creation"
        return
    fi

    cp "$source_helper" "$helper_file"
    chmod 755 "$helper_file"

    log_info "Scoped sudoers helper available: $helper_file"
    log_info "Administrator command:"
    log_info "  sudo $helper_file --agent-user $(whoami) --install-dir $INSTALL_DIR --yes"
}

uninstall() {
    log_header "Uninstalling Audit Agent"

    # Stop service
    if command -v systemctl &>/dev/null; then
        systemctl --user stop "$SERVICE_NAME" 2>/dev/null || true
        systemctl --user disable "$SERVICE_NAME" 2>/dev/null || true
        rm -f "$SYSTEMD_USER_DIR/${SERVICE_NAME}.service"
        systemctl --user daemon-reload 2>/dev/null || true
    fi

    # Remove symlink
    rm -f "$HOME/.local/bin/audit-agent"

    # Remove installation directory
    if [[ -d "$INSTALL_DIR" ]]; then
        echo -n "Remove $INSTALL_DIR and all data? [y/N] "
        read -r confirm
        if [[ "$confirm" =~ ^[Yy] ]]; then
            rm -rf "$INSTALL_DIR"
            log_info "Installation directory removed"
        else
            log_info "Installation directory kept"
        fi
    fi

    log_info "Uninstallation complete"
    exit 0
}

show_completion_message() {
    local sudo_status
    sudo_status=$(check_sudo_status)

    log_header "Installation Complete"

    cat << EOF
The Audit Agent has been installed to: $INSTALL_DIR

Agent ID:      $AGENT_ID
Server URL:    ${SERVER_URL:-"(not configured)"}
Sudo Status:   $sudo_status

EOF

    if [[ "$sudo_status" == "none" ]] || [[ "$sudo_status" == "password" ]]; then
        cat << EOF
${YELLOW}NOTE: Running with reduced capabilities${NC}
Some audit checks that require root access will be skipped.
To enable full auditing, ask your administrator to run:

    sudo $INSTALL_DIR/setup-sudoers.sh --agent-user $(whoami) --install-dir $INSTALL_DIR --yes

This adds passwordless sudo rules ONLY for scoped audit/discovery commands.

EOF
    fi

    cat << EOF
Commands:
  Start service:    systemctl --user start $SERVICE_NAME
  Stop service:     systemctl --user stop $SERVICE_NAME
  View logs:        journalctl --user -u $SERVICE_NAME -f
  Run manually:     ~/.local/bin/audit-agent daemon
  Run discovery:    ~/.local/bin/audit-agent discovery

The agent is now running and will:
  - Poll the server every 60 seconds for commands
  - Run system discovery every hour
  - Execute scheduled audits automatically
  - Upload results to the central server

EOF
}

# =============================================================================
# Parse Arguments
# =============================================================================
UNINSTALL=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        -s|--server)
            SERVER_URL="$2"
            shift 2
            ;;
        -k|--api-key)
            API_KEY="$2"
            shift 2
            ;;
        -i|--agent-id)
            AGENT_ID="$2"
            shift 2
            ;;
        -d|--install-dir)
            INSTALL_DIR="$2"
            shift 2
            ;;
        -u|--uninstall)
            UNINSTALL=true
            shift
            ;;
        -h|--help)
            show_usage
            ;;
        *)
            log_error "Unknown option: $1"
            show_usage
            ;;
    esac
done

# =============================================================================
# Main Installation
# =============================================================================

if [[ "$UNINSTALL" == "true" ]]; then
    uninstall
fi

log_header "Installing Audit Agent v$AGENT_VERSION"

# Check if running as root (warn - this installer is for non-root)
if [[ $EUID -eq 0 ]]; then
    log_warn "Running as root is not recommended for this installer"
    log_warn "This installer is designed for non-root user installation"
    log_warn "For system-wide installation, use install-linux.sh instead"
    echo -n "Continue anyway? [y/N] "
    read -r confirm
    if [[ ! "$confirm" =~ ^[Yy] ]]; then
        exit 1
    fi
fi

# Interactive mode if server URL not provided
if [[ -z "$SERVER_URL" ]]; then
    echo ""
    echo "Enter the audit server URL (e.g., https://audit.company.com):"
    read -r SERVER_URL
fi

if [[ -z "$API_KEY" ]]; then
    echo ""
    echo "Enter your API key (or press Enter to configure later):"
    read -rs API_KEY
    echo ""
fi

check_dependencies
create_directories
copy_agent_files
create_config
create_environment_file
create_systemd_user_service
create_launcher_script
enable_service

# Create the sudoers setup script for admins
create_sudoers_setup_script

show_completion_message
