<#
.SYNOPSIS
    Windows Installer for Audit Agent with JEA Support

.DESCRIPTION
    Installs the Audit Agent on Windows with optional JEA (Just Enough Administration)
    configuration for secure privilege escalation in AD/Entra ID environments.

    Installation Options:
    - User Mode: Installs for current user (no admin required)
    - Service Mode: Installs as Windows service (requires admin)
    - JEA Mode: Configures JEA endpoint for AD/Entra integration (requires admin)

.PARAMETER InstallPath
    Installation directory. Default: C:\ProgramData\AuditAgent

.PARAMETER Mode
    Installation mode:
    - User: Install for current user only (scheduled task, no admin needed)
    - Service: Install as Windows service (requires admin)
    - Full: Install with JEA support (requires admin + AD)

.PARAMETER ServerUrl
    Central audit server URL

.PARAMETER ApiKey
    API key for server authentication

.PARAMETER SetupJea
    Configure JEA endpoint during installation (requires admin)

.PARAMETER JeaAdminGroup
    AD group for full audit access via JEA. Default: IT-Security

.PARAMETER JeaReadOnlyGroup
    AD group for read-only access via JEA. Default: HelpDesk

.PARAMETER CreateScheduledTask
    Create a scheduled task for periodic audits

.PARAMETER Schedule
    Task schedule: Daily, Weekly, OnStartup. Default: Daily

.PARAMETER TaskTime
    Time to run scheduled task. Default: 02:00

.PARAMETER Uninstall
    Remove the audit agent

.EXAMPLE
    .\install-windows.ps1 -Mode User
    Installs for current user with scheduled task (no admin required)

.EXAMPLE
    .\install-windows.ps1 -Mode Service -SetupJea -JeaAdminGroup "DOMAIN\SecurityTeam"
    Installs as service with JEA for the specified AD group

.EXAMPLE
    .\install-windows.ps1 -Mode Full -ServerUrl https://audit.company.com -ApiKey abc123
    Full installation with server connectivity

.EXAMPLE
    .\install-windows.ps1 -Uninstall
    Removes the audit agent

.NOTES
    Author: Audit Tool
    Version: 6.2.1
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Installer intentionally uses colorized host output for interactive operator guidance')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification='Installer function behavior is intentionally deterministic for automation; ShouldProcess prompts would alter current execution contracts')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Legacy installer function naming is preserved for compatibility with existing deployment workflows')]
[CmdletBinding(DefaultParameterSetName = 'Install')]
param(
    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Uninstall')]
    [string]$InstallPath,

    [Parameter(ParameterSetName = 'Install')]
    [ValidateSet('User', 'Service', 'Full')]
    [string]$Mode = 'User',

    [Parameter(ParameterSetName = 'Install')]
    [string]$ServerUrl,

    [Parameter(ParameterSetName = 'Install')]
    [string]$ApiKey,

    [Parameter(ParameterSetName = 'Install')]
    [switch]$SetupJea,

    [Parameter(ParameterSetName = 'Install')]
    [string]$JeaAdminGroup = 'IT-Security',

    [Parameter(ParameterSetName = 'Install')]
    [string]$JeaReadOnlyGroup = 'HelpDesk',

    [Parameter(ParameterSetName = 'Install')]
    [switch]$CreateScheduledTask,

    [Parameter(ParameterSetName = 'Install')]
    [ValidateSet('Daily', 'Weekly', 'OnStartup')]
    [string]$Schedule = 'Daily',

    [Parameter(ParameterSetName = 'Install')]
    [string]$TaskTime = '02:00',

    [Parameter(ParameterSetName = 'Uninstall', Mandatory)]
    [switch]$Uninstall
)

#Requires -Version 5.1

$ErrorActionPreference = 'Stop'
$script:SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Resolve version from co-packaged VERSION file (works from any extraction path)
$script:AgentVersion = if ($env:AUDIT_AGENT_VERSION) {
    $env:AUDIT_AGENT_VERSION
} elseif (Test-Path (Join-Path $script:SourceDir 'VERSION')) {
    ((Get-Content (Join-Path $script:SourceDir 'VERSION') -Raw).Trim())
} else {
    '6.2.1'
}

if (-not $PSBoundParameters.ContainsKey('CreateScheduledTask')) {
    $CreateScheduledTask = $true
}

# =============================================================================
# Helpers
# =============================================================================

function Write-Status {
    param(
        [string]$Message,
        [ValidateSet('Info', 'Success', 'Warning', 'Error')]
        [string]$Level = 'Info'
    )

    $prefix = @{
        Info    = '[*]'
        Success = '[+]'
        Warning = '[!]'
        Error   = '[X]'
    }

    Write-Output "$($prefix[$Level]) $Message"
}

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]$identity
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-DefaultInstallPath {
    if ($Mode -eq 'User') {
        return Join-Path $env:LOCALAPPDATA 'AuditAgent'
    }
    else {
        return 'C:\ProgramData\AuditAgent'
    }
}

# =============================================================================
# Installation Functions
# =============================================================================

function Install-AgentFiles {
    param([string]$DestPath)

    Write-Status "Installing agent files to $DestPath"

    # Create directories
    $dirs = @(
        $DestPath,
        (Join-Path $DestPath 'audits'),
        (Join-Path $DestPath 'logs'),
        (Join-Path $DestPath 'results'),
        (Join-Path $DestPath 'lib'),
        (Join-Path $DestPath 'jea')
    )

    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir)) {
            New-Item -Path $dir -ItemType Directory -Force | Out-Null
        }
    }

    # Copy agent files
    $filesToCopy = @(
        'fleet-agent.ps1',
        'agent.ps1',
        'README.md'
    )

    foreach ($file in $filesToCopy) {
        $src = Join-Path $script:SourceDir $file
        if (Test-Path $src) {
            Copy-Item -Path $src -Destination $DestPath -Force
            Write-Status "Copied $file" -Level Info
        }
    }

    # Copy lib directory
    $libSrc = Join-Path $script:SourceDir 'lib'
    if (Test-Path $libSrc) {
        Copy-Item -Path "$libSrc\*" -Destination (Join-Path $DestPath 'lib') -Recurse -Force
        Write-Status "Copied lib/" -Level Info
    }

    # Copy audits
    $auditsSrc = Join-Path $script:SourceDir 'audits'
    if (Test-Path $auditsSrc) {
        Copy-Item -Path "$auditsSrc\*" -Destination (Join-Path $DestPath 'audits') -Recurse -Force
        Write-Status "Copied audits/" -Level Info
    }

    # Copy JEA files
    $jeaSrc = Join-Path $script:SourceDir 'jea'
    if (Test-Path $jeaSrc) {
        Copy-Item -Path "$jeaSrc\*" -Destination (Join-Path $DestPath 'jea') -Recurse -Force
        Write-Status "Copied jea/" -Level Info
    }

    return $DestPath
}

function New-AgentConfig {
    param(
        [string]$InstallPath,
        [string]$ServerUrl,
        [string]$ApiKey
    )

    $configPath = Join-Path $InstallPath 'agent.config.json'

    $config = @{
        agent_id         = $env:COMPUTERNAME
        install_path     = $InstallPath
        installed_at     = (Get-Date -Format 'o')
        installed_by     = $env:USERNAME
        version          = $script:AgentVersion
        mode             = $Mode
        elevation_method = if ($SetupJea) { 'JEA' } else { 'Auto' }
    }

    if ($ServerUrl) {
        $config.server_url = $ServerUrl
    }

    if ($ApiKey) {
        # Encrypt API key using DPAPI
        $secureKey = ConvertTo-InMemorySecureString -Value $ApiKey
        $config.api_key_encrypted = ConvertFrom-SecureString $secureKey
    }

    if ($SetupJea) {
        $config.jea_endpoint = 'AuditAgent.JEA'
    }

    $config | ConvertTo-Json -Depth 10 | Set-Content -Path $configPath -Encoding UTF8
    Write-Status "Created configuration file" -Level Success

    return $configPath
}

function Register-AgentTask {
    param(
        [string]$InstallPath,
        [string]$TaskName = 'Audit Agent',
        [string]$Schedule,
        [string]$Time
    )

    Write-Status "Creating scheduled task: $TaskName"

    $agentPath = Join-Path $InstallPath 'fleet-agent.ps1'

    # Build command arguments
    $arguments = "-ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File `"$agentPath`" -Mode daemon"

    if ($ServerUrl) {
        $arguments += " -ServerUrl `"$ServerUrl`""
    }

    # Create action
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arguments

    # Create trigger based on schedule
    $trigger = switch ($Schedule) {
        'Daily'     { New-ScheduledTaskTrigger -Daily -At $Time }
        'Weekly'    { New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At $Time }
        'OnStartup' { New-ScheduledTaskTrigger -AtStartup }
    }

    # Create settings
    $settings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -StartWhenAvailable `
        -RunOnlyIfNetworkAvailable:$false `
        -ExecutionTimeLimit (New-TimeSpan -Hours 4)

    # Determine principal based on mode
    if ($Mode -eq 'User') {
        $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
    }
    else {
        $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    }

    # Register task
    $existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($existingTask) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    }

    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -Principal $principal `
        -Description "Audit Agent - Security audit data collection" | Out-Null

    Write-Status "Scheduled task created: $TaskName" -Level Success
}

function Install-JeaEndpoint {
    param([string]$InstallPath)

    if (-not (Test-IsAdmin)) {
        Write-Status "JEA setup requires administrator privileges" -Level Error
        return $false
    }

    Write-Status "Configuring JEA endpoint..."

    $jeaSetupScript = Join-Path $InstallPath 'jea\setup-jea.ps1'

    if (-not (Test-Path $jeaSetupScript)) {
        Write-Status "JEA setup script not found at $jeaSetupScript" -Level Error
        return $false
    }

    try {
        & $jeaSetupScript `
            -AdminGroup $JeaAdminGroup `
            -ReadOnlyGroup $JeaReadOnlyGroup `
            -InstallPath (Join-Path $InstallPath 'jea')

        Write-Status "JEA endpoint configured successfully" -Level Success
        return $true
    }
    catch {
        Write-Status "JEA setup failed: $_" -Level Error
        return $false
    }
}

function Install-AsService {
    param([string]$InstallPath)

    if (-not (Test-IsAdmin)) {
        Write-Status "Service installation requires administrator privileges" -Level Error
        return $false
    }

    Write-Status "Installing as Windows service..."

    $serviceName = 'AuditAgent'
    $agentPath = Join-Path $InstallPath 'fleet-agent.ps1'

    # Build service command
    $binPath = "powershell.exe -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File `"$agentPath`" -Mode daemon"

    if ($ServerUrl) {
        $binPath += " -ServerUrl `"$ServerUrl`""
    }

    # Remove existing service
    $existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($existing) {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        & sc.exe delete $serviceName | Out-Null
        Start-Sleep -Seconds 2
    }

    # Create new service using nssm (if available) or sc.exe wrapper
    # For PowerShell scripts, we typically use a scheduled task with SYSTEM account instead
    # of a true Windows service since PowerShell doesn't natively support service hosting

    Write-Status "Note: PowerShell agents run best as scheduled tasks with SYSTEM account" -Level Warning
    Write-Status "Creating SYSTEM-level scheduled task instead of service" -Level Info

    Register-AgentTask `
        -InstallPath $InstallPath `
        -TaskName 'Audit Agent Service' `
        -Schedule 'OnStartup' `
        -Time '00:00'

    # Also create a periodic task
    Register-AgentTask `
        -InstallPath $InstallPath `
        -TaskName 'Audit Agent - Periodic' `
        -Schedule $Schedule `
        -Time $TaskTime

    return $true
}

# =============================================================================
# Uninstall
# =============================================================================

function Uninstall-Agent {
    param([string]$Path)

    Write-Status "Uninstalling Audit Agent..."

    # Remove scheduled tasks
    $tasks = @('Audit Agent', 'Audit Agent Service', 'Audit Agent - Periodic', 'Security Audit Agent - Lightweight')
    foreach ($task in $tasks) {
        $existing = Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
        if ($existing) {
            Unregister-ScheduledTask -TaskName $task -Confirm:$false
            Write-Status "Removed scheduled task: $task" -Level Info
        }
    }

    # Remove JEA endpoint
    if (Test-IsAdmin) {
        $jeaEndpoint = Get-PSSessionConfiguration -Name 'AuditAgent.JEA' -ErrorAction SilentlyContinue
        if ($jeaEndpoint) {
            Unregister-PSSessionConfiguration -Name 'AuditAgent.JEA' -Force
            Write-Status "Removed JEA endpoint" -Level Info
        }
    }

    # Remove files
    $systemPath = 'C:\ProgramData\AuditAgent'
    $userPath = Join-Path $env:LOCALAPPDATA 'AuditAgent'

    $pathsToRemove = @()
    if (-not [string]::IsNullOrWhiteSpace($Path)) {
        $pathsToRemove += $Path
    }
    $pathsToRemove += @($systemPath, $userPath)
    $pathsToRemove = $pathsToRemove | Select-Object -Unique

    foreach ($dir in $pathsToRemove) {
        if (Test-Path $dir) {
            $confirm = Read-Host "Remove $dir and all contents? [y/N]"
            if ($confirm -eq 'y') {
                Remove-Item -Path $dir -Recurse -Force
                Write-Status "Removed $dir" -Level Success
            }
        }
    }

    Write-Status "Uninstall complete" -Level Success
}

# =============================================================================
# Main
# =============================================================================

Write-Output ""
Write-Output "============================================================"
Write-Output "       Audit Agent - Windows Installer                      "
Write-Output "============================================================"
Write-Output ""

# Handle uninstall
if ($Uninstall) {
    $path = if ($InstallPath) { $InstallPath } else { Get-DefaultInstallPath }
    Uninstall-Agent -Path $path
    exit 0
}

# Validate admin requirements
if ($Mode -ne 'User' -and -not (Test-IsAdmin)) {
    Write-Status "Installation mode '$Mode' requires administrator privileges" -Level Error
    Write-Status "Run PowerShell as Administrator or use -Mode User" -Level Info
    exit 1
}

if ($SetupJea -and -not (Test-IsAdmin)) {
    Write-Status "JEA setup requires administrator privileges" -Level Error
    exit 1
}

# Set default install path if not specified
if ([string]::IsNullOrEmpty($InstallPath)) {
    $InstallPath = Get-DefaultInstallPath
}

Write-Status "Installation Mode: $Mode"
Write-Status "Install Path: $InstallPath"
if ($SetupJea) {
    Write-Status "JEA: Enabled (Admin: $JeaAdminGroup, ReadOnly: $JeaReadOnlyGroup)"
}

# Install files
Install-AgentFiles -DestPath $InstallPath | Out-Null

# Create configuration
New-AgentConfig -InstallPath $InstallPath -ServerUrl $ServerUrl -ApiKey $ApiKey

# Mode-specific setup
switch ($Mode) {
    'User' {
        if ($CreateScheduledTask) {
            Register-AgentTask -InstallPath $InstallPath -Schedule $Schedule -Time $TaskTime
        }
    }

    'Service' {
        Install-AsService -InstallPath $InstallPath
    }

    'Full' {
        Install-AsService -InstallPath $InstallPath
        if ($SetupJea) {
            Install-JeaEndpoint -InstallPath $InstallPath
        }
    }
}

# Setup JEA if requested
if ($SetupJea -and $Mode -ne 'Full') {
    Install-JeaEndpoint -InstallPath $InstallPath
}

Write-Output ""
Write-Output "============================================================"
Write-Output "       Installation Complete                                "
Write-Output "============================================================"
Write-Output ""
Write-Status "Agent installed to: $InstallPath" -Level Success

if ($Mode -eq 'User') {
    Write-Output ""
    Write-Output "User-mode installation (no admin required):"
    Write-Output "  - Scheduled task runs as current user"
    Write-Output "  - Some audits may have limited access"
    Write-Output "  - To enable full audits, ask admin to run:"
    Write-Output "    .\jea\setup-jea.ps1 -JeaEndpoint AuditAgent.JEA"
}

if ($SetupJea) {
    Write-Output ""
    Write-Output "JEA endpoint configured. To use:"
    Write-Output "  Add users to '$JeaAdminGroup' for full access"
    Write-Output "  Add users to '$JeaReadOnlyGroup' for read-only access"
}

Write-Output ""
Write-Output "To run manually:"
Write-Output "  cd $InstallPath"
Write-Output "  .\fleet-agent.ps1 -Mode interactive"
Write-Output ""
