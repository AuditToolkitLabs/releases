#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding(DefaultParameterSetName = 'Install', SupportsShouldProcess = $true)]
param(
    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$InstallPath = 'C:\ProgramData\AuditAgent\jea',

    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$EndpointName = 'AuditAgent.JEA',

    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$AdminGroup = 'IT-Security',

    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$ReadOnlyGroup = 'HelpDesk',

    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$AgentRootPath,

    [Parameter(ParameterSetName = 'Gmsa', Mandatory)]
    [switch]$UseGmsa,

    [Parameter(ParameterSetName = 'Gmsa', Mandatory)]
    [string]$GmsaAccount,

    [Parameter(ParameterSetName = 'Install')]
    [Parameter(ParameterSetName = 'Gmsa')]
    [string]$TranscriptPath = 'C:\ProgramData\AuditAgent\logs\jea-transcripts',

    [Parameter(ParameterSetName = 'Uninstall', Mandatory)]
    [switch]$Uninstall,

    [Parameter(ParameterSetName = 'Uninstall')]
    [switch]$RemoveInstallPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-LogEntry {
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'PASS')]
        [string]$Level = 'INFO'
    )

    Write-Output ("[{0}] {1}" -f $Level, $Message)
}

function Test-GroupExistence {
    param([Parameter(Mandatory)][string]$GroupName)

    if ($GroupName -match '\\') {
        $parts = $GroupName -split '\\', 2
        if ($parts.Count -ne 2) {
            return $false
        }

        try {
            $domainName = $parts[0]
            $simpleName = $parts[1]
            $group = [ADSI]("WinNT://{0}/{1},group" -f $domainName, $simpleName)
            return [bool]$group.Path
        }
        catch {
            return $false
        }
    }

    try {
        return [bool](Get-LocalGroup -Name $GroupName -ErrorAction Stop)
    }
    catch {
        return $false
    }
}

function New-JeaDirectory {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([Parameter(Mandatory)][string]$Path)

    if ((-not (Test-Path -Path $Path)) -and $PSCmdlet.ShouldProcess($Path, 'Create directory')) {
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

function Update-RoleCapabilityScope {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$RoleCapabilityPath,
        [Parameter(Mandatory)][string]$RootPath
    )

    if (-not (Test-Path -Path $RoleCapabilityPath)) {
        return
    }

    $raw = Get-Content -Path $RoleCapabilityPath -Raw -ErrorAction Stop
    $escapedRoot = $RootPath.TrimEnd('\\').Replace("'", "''")
    $updated = $raw.Replace('__AUDIT_AGENT_ROOT__', $escapedRoot)

    if ($PSCmdlet.ShouldProcess($RoleCapabilityPath, 'Update role capability scope placeholders')) {
        Set-Content -Path $RoleCapabilityPath -Value $updated -Encoding UTF8
    }
}

function Copy-RoleCapabilityFile {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$SourceDirectory,
        [Parameter(Mandatory)][string]$InstallDirectory,
        [Parameter(Mandatory)][string]$RootPath
    )

    $roleDirectory = Join-Path -Path $InstallDirectory -ChildPath 'RoleCapabilities'
    New-JeaDirectory -Path $roleDirectory

    foreach ($fileName in @('AuditAgent.Full.psrc', 'AuditAgent.ReadOnly.psrc')) {
        $sourcePath = Join-Path -Path $SourceDirectory -ChildPath $fileName
        $targetPath = Join-Path -Path $roleDirectory -ChildPath $fileName

        if (Test-Path -Path $sourcePath) {
            if ($PSCmdlet.ShouldProcess($targetPath, 'Copy role capability file')) {
                Copy-Item -Path $sourcePath -Destination $targetPath -Force
                Write-LogEntry -Level INFO -Message ("Copied role capability file: {0}" -f $fileName)
            }
        }
        else {
            $description = if ($fileName -eq 'AuditAgent.Full.psrc') {
                'Full audit capability for privileged operators.'
            }
            else {
                'Read-only audit capability for support operators.'
            }

            if ($PSCmdlet.ShouldProcess($targetPath, 'Create default role capability file')) {
                New-PSRoleCapabilityFile -Path $targetPath -Description $description | Out-Null
                Write-LogEntry -Level WARN -Message ("Source missing. Created default role capability file: {0}" -f $fileName)
            }
        }

        Update-RoleCapabilityScope -RoleCapabilityPath $targetPath -RootPath $RootPath
    }
}

function New-SessionConfigFile {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$InstallDirectory,
        [Parameter(Mandatory)][string]$AdminGroupName,
        [Parameter(Mandatory)][string]$ReadOnlyGroupName,
        [Parameter(Mandatory)][string]$TranscriptDirectory,
        [Parameter(Mandatory)][bool]$UseGmsaAuth,
        [string]$GmsaName
    )

    $configPath = Join-Path -Path $InstallDirectory -ChildPath 'AuditAgent.pssc'

    $roleMap = @{
        $AdminGroupName = @{ RoleCapabilities = 'AuditAgent.Full' }
        $ReadOnlyGroupName = @{ RoleCapabilities = 'AuditAgent.ReadOnly' }
        'BUILTIN\Administrators' = @{ RoleCapabilities = 'AuditAgent.Full' }
        'NT AUTHORITY\SYSTEM' = @{ RoleCapabilities = 'AuditAgent.Full' }
    }

    $configParams = @{
        Path = $configPath
        SessionType = 'RestrictedRemoteServer'
        LanguageMode = 'ConstrainedLanguage'
        ExecutionPolicy = 'RemoteSigned'
        TranscriptDirectory = $TranscriptDirectory
        ModulesToImport = @('Microsoft.PowerShell.Management', 'Microsoft.PowerShell.Utility')
        VisibleProviders = @('Environment', 'FileSystem', 'Registry')
        MountUserDrive = $false
        RoleDefinitions = $roleMap
        Description = 'Audit Agent JEA endpoint for controlled elevated execution.'
        Author = 'Audit Tool'
        CompanyName = 'Audit Tool'
        GUID = [guid]::NewGuid()
    }

    if ($UseGmsaAuth) {
        $configParams.GroupManagedServiceAccount = ("{0}\{1}$" -f $env:USERDOMAIN, $GmsaName)
    }
    else {
        $configParams.RunAsVirtualAccount = $true
        $configParams.RunAsVirtualAccountGroups = @('Administrators', 'Event Log Readers', 'Performance Monitor Users')
    }

    if ($PSCmdlet.ShouldProcess($configPath, 'Create session configuration file')) {
        New-PSSessionConfigurationFile @configParams
        Write-LogEntry -Level INFO -Message ("Created session configuration file: {0}" -f $configPath)
    }

    return $configPath
}

function Register-JeaSession {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$ConfigPath
    )

    $existing = Get-PSSessionConfiguration -Name $Name -ErrorAction SilentlyContinue
    if ($existing) {
        if ($PSCmdlet.ShouldProcess($Name, 'Unregister existing endpoint for re-registration')) {
            Unregister-PSSessionConfiguration -Name $Name -Force -NoServiceRestart
            Write-LogEntry -Level WARN -Message ("Existing endpoint removed for re-registration: {0}" -f $Name)
        }
    }

    if ($PSCmdlet.ShouldProcess($Name, 'Register JEA endpoint')) {
        Register-PSSessionConfiguration -Name $Name -Path $ConfigPath -Force -NoServiceRestart
        Write-LogEntry -Level PASS -Message ("Registered JEA endpoint: {0}" -f $Name)
    }
}

function Test-JeaSession {
    param([Parameter(Mandatory)][string]$Name)

    try {
        $session = New-PSSession -ConfigurationName $Name -ComputerName localhost -ErrorAction Stop
        $result = Invoke-Command -Session $session -ScriptBlock {
            [pscustomobject]@{
                HostName = [Environment]::MachineName
                Identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
            }
        }

        Remove-PSSession -Session $session

        Write-LogEntry -Level PASS -Message ("Endpoint test passed as identity: {0}" -f $result.Identity)
        return $true
    }
    catch {
        Write-LogEntry -Level ERROR -Message ("Endpoint test failed: {0}" -f $_.Exception.Message)
        return $false
    }
}

function Remove-JeaSession {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][bool]$RemovePath
    )

    $existing = Get-PSSessionConfiguration -Name $Name -ErrorAction SilentlyContinue
    if ($existing) {
        if ($PSCmdlet.ShouldProcess($Name, 'Unregister endpoint')) {
            Unregister-PSSessionConfiguration -Name $Name -Force
            Write-LogEntry -Level PASS -Message ("Unregistered endpoint: {0}" -f $Name)
        }
    }
    else {
        Write-LogEntry -Level WARN -Message ("Endpoint not found: {0}" -f $Name)
    }

    if ($RemovePath -and (Test-Path -Path $Path) -and $PSCmdlet.ShouldProcess($Path, 'Remove install directory')) {
        Remove-Item -Path $Path -Recurse -Force
        Write-LogEntry -Level PASS -Message ("Removed install directory: {0}" -f $Path)
    }
}

if ($Uninstall) {
    if ($PSCmdlet.ShouldProcess($EndpointName, 'Uninstall JEA endpoint')) {
        Remove-JeaSession -Name $EndpointName -Path $InstallPath -RemovePath ([bool]$RemoveInstallPath)
        Write-LogEntry -Level PASS -Message 'Uninstall completed.'
    }

    return
}

Write-LogEntry -Level INFO -Message 'Starting JEA setup.'

if (-not (Test-GroupExistence -GroupName $AdminGroup)) {
    Write-LogEntry -Level WARN -Message ("Admin group not found: {0}" -f $AdminGroup)
}

if (-not (Test-GroupExistence -GroupName $ReadOnlyGroup)) {
    Write-LogEntry -Level WARN -Message ("Read-only group not found: {0}" -f $ReadOnlyGroup)
}

if ($UseGmsa -and [string]::IsNullOrWhiteSpace($GmsaAccount)) {
    throw 'GmsaAccount is required when UseGmsa is enabled.'
}

$resolvedAgentRoot = if ([string]::IsNullOrWhiteSpace($AgentRootPath)) {
    Split-Path -Path $InstallPath -Parent
}
else {
    $AgentRootPath
}

if ($PSCmdlet.ShouldProcess($InstallPath, 'Create JEA install directories and files')) {
    $scriptDirectory = Split-Path -Path $PSCommandPath -Parent

    New-JeaDirectory -Path $InstallPath
    New-JeaDirectory -Path $TranscriptPath

    Copy-RoleCapabilityFile -SourceDirectory $scriptDirectory -InstallDirectory $InstallPath -RootPath $resolvedAgentRoot

    $configPath = New-SessionConfigFile `
        -InstallDirectory $InstallPath `
        -AdminGroupName $AdminGroup `
        -ReadOnlyGroupName $ReadOnlyGroup `
        -TranscriptDirectory $TranscriptPath `
        -UseGmsaAuth ([bool]$UseGmsa) `
        -GmsaName $GmsaAccount

    Register-JeaSession -Name $EndpointName -ConfigPath $configPath

    if (-not (Test-JeaSession -Name $EndpointName)) {
        throw 'JEA endpoint test failed after registration.'
    }

    Write-LogEntry -Level PASS -Message 'JEA setup completed successfully.'
}
