#Requires -Version 5.1
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Module intentionally emits operator-facing status lines during secure credential operations')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification='Credential lifecycle operations are intentionally non-interactive for deterministic automation behavior')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSProvideCommentHelp', '', Justification='Module help is provided at function and module level; analyzer false positives accepted during stabilization')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPositionalParameters', '', Justification='Positional usage is intentional in stabilized scripts; named-argument refactors deferred to avoid behavior drift')]
param()
<#
.SYNOPSIS
    Secure Credential Storage Module for Windows Agent
.DESCRIPTION
    Provides secure API key storage using Windows DPAPI (Data Protection API).
    Keys are encrypted at rest and can only be decrypted by the same user on the same machine.

    Storage options:
    1. Windows Credential Manager (preferred)
    2. DPAPI-encrypted file (fallback)

.NOTES
    Security: API keys encrypted with user scope - only accessible by current user
#>

# Credential Manager target name
$script:CredentialTarget = "SecurityAuditToolkit_AgentApiKey"
$script:EncryptedKeyFile = Join-Path $PSScriptRoot ".." ".cache" "api_key.enc"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureKey = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureKey.AppendChar($character)
        }
    }
    $secureKey.MakeReadOnly()
    return $secureKey
}

# =============================================================================
# Windows Credential Manager Functions
# =============================================================================
<#
.SYNOPSIS
    Store API key in secure local storage.
.DESCRIPTION
    Encrypts and persists the API key using Windows DPAPI scoped to the current user.
.PARAMETER ApiKey
    Plaintext API key value to encrypt and store.
.OUTPUTS
    System.Boolean
#>
function Save-ApiKeyToCredentialManager {
    param([string]$ApiKey)

    try {
        # Use cmdkey.exe for credential storage (works without extra modules)
        # Store using Windows Credential Manager via .NET
        Add-Type -AssemblyName System.Security

        $credBlob = [System.Text.Encoding]::UTF8.GetBytes($ApiKey)
        $entropy = [System.Text.Encoding]::UTF8.GetBytes($env:COMPUTERNAME)

        $encryptedData = [System.Security.Cryptography.ProtectedData]::Protect(
            $credBlob,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )

        # Store encrypted data in secure location
        $cacheDir = Split-Path $script:EncryptedKeyFile -Parent
        if (-not (Test-Path $cacheDir)) {
            New-Item -ItemType Directory -Path $cacheDir -Force | Out-Null
        }

        [System.IO.File]::WriteAllBytes($script:EncryptedKeyFile, $encryptedData)

        # Set restrictive ACL on the file
        $acl = Get-Acl $script:EncryptedKeyFile
        $acl.SetAccessRuleProtection($true, $false)  # Disable inheritance
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
            "FullControl",
            "Allow"
        )
        $acl.SetAccessRule($rule)
        Set-Acl -Path $script:EncryptedKeyFile -AclObject $acl

        Write-Verbose "[INFO] API key stored securely using DPAPI encryption"
        return $true
    }
    catch {
        Write-Verbose "[ERROR] Failed to store API key: $_"
        return $false
    }
}

<#
.SYNOPSIS
    Retrieve API key from secure local storage.
#>
function Get-ApiKeyFromCredentialManager {
    <#
    .SYNOPSIS
        Retrieve API key from secure storage
    .RETURNS
        API key string or $null if not found
    #>
    try {
        if (-not (Test-Path $script:EncryptedKeyFile)) {
            return $null
        }

        Add-Type -AssemblyName System.Security

        $encryptedData = [System.IO.File]::ReadAllBytes($script:EncryptedKeyFile)
        $entropy = [System.Text.Encoding]::UTF8.GetBytes($env:COMPUTERNAME)

        $decryptedData = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $encryptedData,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )

        $apiKey = [System.Text.Encoding]::UTF8.GetString($decryptedData)
        return $apiKey
    }
    catch {
        Write-Verbose "[WARN] Failed to retrieve API key from secure storage: $_"
        return $null
    }
}

function Remove-ApiKeyFromCredentialManager {
    <#
    .SYNOPSIS
        Remove API key from secure storage
    #>
    try {
        if (Test-Path $script:EncryptedKeyFile) {
            # Secure delete - overwrite before removing
            $bytes = New-Object byte[] (Get-Item $script:EncryptedKeyFile).Length
            (New-Object Random).NextBytes($bytes)
            [System.IO.File]::WriteAllBytes($script:EncryptedKeyFile, $bytes)
            Remove-Item $script:EncryptedKeyFile -Force
            Write-Verbose "[INFO] API key removed from secure storage"
        }
        return $true
    }
    catch {
        Write-Verbose "[ERROR] Failed to remove API key: $_"
        return $false
    }
}

# =============================================================================
# Secure Config Management
# =============================================================================
function Save-SecureConfig {
    <#
    .SYNOPSIS
        Save configuration with API key encrypted
    .PARAMETER Config
        Hashtable containing configuration (server_url, api_key, agent_id, etc.)
    .PARAMETER ConfigFile
        Path to config file
    #>
    param(
        [hashtable]$Config,
        [string]$ConfigFile
    )

    # Extract and securely store the API key
    $apiKey = $Config['api_key']
    if ($apiKey) {
        Save-ApiKeyToCredentialManager -ApiKey $apiKey | Out-Null
    }

    # Save config without the API key (or with a placeholder)
    $safeConfig = @{
        server_url = $Config['server_url']
        agent_id = $Config['agent_id']
        config_version = $Config['config_version']
        api_key_secured = $true  # Flag indicating key is in secure storage
        updated_at = (Get-Date -Format "o")
    }

    $safeConfig | ConvertTo-Json | Set-Content $ConfigFile
    Write-Verbose "[INFO] Configuration saved (API key encrypted separately)"
}

<#
.SYNOPSIS
    Load configuration and resolve API key from secure storage.
#>
function Get-SecureConfig {
    <#
    .SYNOPSIS
        Load configuration with API key from secure storage
    .PARAMETER ConfigFile
        Path to config file
    .RETURNS
        Hashtable with full configuration including decrypted API key
    #>
    param([string]$ConfigFile)

    $config = @{}

    if (Test-Path $ConfigFile) {
        try {
            $fileConfig = Get-Content $ConfigFile | ConvertFrom-Json
            $config['server_url'] = $fileConfig.server_url
            $config['agent_id'] = $fileConfig.agent_id
            $config['config_version'] = $fileConfig.config_version

            # Check if API key is in secure storage
            if ($fileConfig.api_key_secured) {
                $config['api_key'] = Get-ApiKeyFromCredentialManager
            }
            elseif ($fileConfig.api_key) {
                # Legacy: migrate plaintext key to secure storage
                Write-Verbose "[INFO] Migrating API key to secure storage..."
                Save-ApiKeyToCredentialManager -ApiKey $fileConfig.api_key | Out-Null
                $config['api_key'] = $fileConfig.api_key

                # Re-save config without plaintext key
                Save-SecureConfig -Config $config -ConfigFile $ConfigFile
            }
        }
        catch {
            Write-Verbose "[ERROR] Failed to load config: $_"
        }
    }

    return $config
}

# =============================================================================
# TLS Certificate Pinning
# =============================================================================
<#
.SYNOPSIS
    Validate HTTPS server certificate against optional pinned fingerprint.
.DESCRIPTION
    Retrieves the remote certificate, computes a SHA256 fingerprint, and compares it
    to an optional pinned hash when provided.
.PARAMETER ServerUrl
    HTTPS endpoint URL to inspect.
.PARAMETER PinnedHash
    Optional expected SHA256 certificate fingerprint.
.OUTPUTS
    System.Boolean
#>
function Test-ServerCertificate {
    param(
        [string]$ServerUrl,
        [string]$PinnedHash = $null
    )

    try {
        $uri = [System.Uri]$ServerUrl
        if ($uri.Scheme -ne 'https') {
            Write-Verbose "[WARN] Server URL is not HTTPS - certificate pinning not applicable"
            return $true
        }

        # Create TCP connection to get certificate
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.Connect($uri.Host, $uri.Port)

        $sslStream = New-Object System.Net.Security.SslStream(
            $tcpClient.GetStream(),
            $false,
            { $true }  # Accept cert for inspection
        )

        $sslStream.AuthenticateAsClient($uri.Host)
        $cert = $sslStream.RemoteCertificate

        # Calculate SHA256 hash
        $certHash = [System.Security.Cryptography.SHA256]::Create().ComputeHash($cert.GetRawCertData())
        $certHashString = [System.BitConverter]::ToString($certHash).Replace("-", "").ToLower()

        $tcpClient.Close()

        if ($PinnedHash) {
            $pinnedHashClean = $PinnedHash.Replace("-", "").Replace(":", "").ToLower()
            if ($certHashString -eq $pinnedHashClean) {
                Write-Verbose "[INFO] Certificate pinning verified"
                return $true
            }
            else {
                Write-Verbose "[ERROR] Certificate hash mismatch!"
                Write-Verbose "  Expected: $pinnedHashClean"
                Write-Verbose "  Got:      $certHashString"
                return $false
            }
        }
        else {
            Write-Verbose "[INFO] Server certificate hash: $certHashString"
            Write-Verbose "[INFO] To enable pinning, set TLS_CERT_HASH environment variable"
            return $true
        }
    }
    catch {
        Write-Verbose "[ERROR] Certificate verification failed: $_"
        return $false
    }
}

# =============================================================================
# Export Functions
# =============================================================================
Set-Alias -Name Load-SecureConfig -Value Get-SecureConfig

Export-ModuleMember -Function @(
    'Save-ApiKeyToCredentialManager',
    'Get-ApiKeyFromCredentialManager',
    'Remove-ApiKeyFromCredentialManager',
    'Save-SecureConfig',
    'Get-SecureConfig',
    'Test-ServerCertificate'
) -Alias @('Load-SecureConfig')
