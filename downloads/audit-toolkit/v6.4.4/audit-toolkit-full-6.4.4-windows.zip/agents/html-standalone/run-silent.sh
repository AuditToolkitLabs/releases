#!/usr/bin/env bash
# run-silent.sh - Wrapper for completely silent background audit execution
# Usage: ./run-silent.sh [command] [args...]
#
# This wrapper ensures:
# - No terminal attachment
# - Output redirected to log file
# - Runs detached from session
# - Process group isolation

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGS_DIR="${SCRIPT_DIR}/logs"
LOG_FILE="${LOGS_DIR}/silent-$(date +%Y%m%d).log"

# Ensure logs directory exists
mkdir -p "$LOGS_DIR"

# Default command is runall
CMD="${1:-runall}"
shift 2>/dev/null || true

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

log_msg "=== Starting silent execution: $CMD $* ==="

# Run completely detached from terminal
(
    # Close stdin, redirect stdout/stderr to log
    exec </dev/null
    exec >> "$LOG_FILE" 2>&1

    # Set process group leader
    setsid "${SCRIPT_DIR}/agent.sh" --silent "$CMD" "$@" || true

    log_msg "=== Execution completed ==="
) &

# Disown the background process so it survives shell exit
disown 2>/dev/null || true

# Exit immediately - backgrounded process continues
exit 0
