#!/usr/bin/env python3
"""
CLI Setup for Lightweight Audit Agent
======================================
Headless configuration tool for servers without GUI access.

Usage:
    # Interactive mode
    python3 setup-cli.py

    # Non-interactive (command line args)
    python3 setup-cli.py --server https://audit-server:5000 --api-key secret123

    # Using environment variables
    CORE_SERVER_URL=https://audit-server:5000 API_KEY=secret python3 setup-cli.py --from-env

This script can be run:
1. Inside the Docker container: docker exec -it audit-agent python3 /app/setup-cli.py
2. Directly on the host: python3 setup-cli.py
"""

import os
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime

try:
    import requests
except ImportError:
    requests = None

# Configuration paths
CONFIG_DIR = Path(os.environ.get('CONFIG_DIR', '/app/config'))
CONFIG_FILE = CONFIG_DIR / 'agent-config.json'
SCHEDULE_FILE = CONFIG_DIR / 'schedules.json'


def load_config() -> dict:
    """Load existing configuration."""
    default_config = {
        'core_server_url': '',
        'api_key': '',
        'agent_id': '',
        'auto_export': False,
        'export_on_complete': True,
        'keep_local_results': True,
        'setup_complete': False,
        'created_at': None,
        'updated_at': None
    }

    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                return config
        except Exception:
            pass

    return default_config


def save_config(config: dict) -> None:
    """Save configuration."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config['updated_at'] = datetime.now().isoformat()
    if not config.get('created_at'):
        config['created_at'] = config['updated_at']

    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def get_hostname() -> str:
    """Get system hostname."""
    import subprocess
    try:
        return subprocess.check_output(['hostname'], text=True).strip()
    except Exception:
        return 'unknown'


def test_connection(server_url: str, api_key: str = '') -> bool:
    """Test connection to core server."""
    if not requests:
        print("Warning: 'requests' not installed, skipping connection test")
        return True

    try:
        headers = {}
        if api_key:
            headers['Authorization'] = f'Bearer {api_key}'
            headers['X-API-Key'] = api_key

        response = requests.get(f"{server_url.rstrip('/')}/health", headers=headers, timeout=10)
        return response.status_code == 200
    except Exception as e:
        print(f"Connection test failed: {e}")
        return False


def interactive_setup() -> dict:
    """Run interactive setup wizard."""
    print("\n" + "=" * 60)
    print("  Lightweight Audit Agent - Setup Wizard")
    print("=" * 60)

    config = load_config()
    hostname = get_hostname()

    # Core server URL
    print("\n[1/5] Core Server URL")
    print("Enter the URL of your main audit server (leave empty to skip)")
    default = config.get('core_server_url', '')
    prompt = f"Server URL [{default}]: " if default else "Server URL: "
    server_url = input(prompt).strip() or default

    # API Key
    api_key = ''
    if server_url:
        print("\n[2/5] API Key (for authentication)")
        default = config.get('api_key', '')
        if default:
            print(f"Current: {'*' * len(default)}")
        api_key = input("API Key (leave empty to keep current): ").strip() or default

    # Agent ID
    print("\n[3/5] Agent Identifier")
    default = config.get('agent_id', '') or f"lightweight-{hostname}"
    agent_id = input(f"Agent ID [{default}]: ").strip() or default

    # Auto export
    print("\n[4/5] Auto Export")
    default = 'y' if config.get('auto_export') else 'n'
    auto_export = input(f"Auto-export results to server? (y/n) [{default}]: ").strip().lower()
    auto_export = (auto_export or default) in ('y', 'yes', 'true', '1')

    # Export on complete
    print("\n[5/5] Export on Complete")
    default = 'y' if config.get('export_on_complete', True) else 'n'
    export_on_complete = input(f"Export immediately when audit completes? (y/n) [{default}]: ").strip().lower()
    export_on_complete = (export_on_complete or default) in ('y', 'yes', 'true', '1')

    # Test connection if server URL provided
    if server_url:
        print("\nTesting connection to core server...")
        if test_connection(server_url, api_key):
            print("✓ Connection successful!")
        else:
            print("✗ Connection failed. Configuration will still be saved.")
            if input("Continue anyway? (y/n) [y]: ").strip().lower() in ('n', 'no'):
                print("Setup cancelled.")
                sys.exit(1)

    return {
        'core_server_url': server_url,
        'api_key': api_key,
        'agent_id': agent_id,
        'auto_export': auto_export,
        'export_on_complete': export_on_complete,
        'keep_local_results': True,
        'setup_complete': True
    }


def main():
    parser = argparse.ArgumentParser(
        description='CLI Setup for Lightweight Audit Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Interactive mode:
    python3 setup-cli.py

  Non-interactive:
    python3 setup-cli.py --server https://audit-server:5000 --api-key secret123

  From environment variables:
    CORE_SERVER_URL=https://audit-server:5000 API_KEY=secret python3 setup-cli.py --from-env

  Show current config:
    python3 setup-cli.py --show

  Reset configuration:
    python3 setup-cli.py --reset
"""
    )

    parser.add_argument('--server', '-s', help='Core server URL')
    parser.add_argument('--api-key', '-k', help='API key for authentication')
    parser.add_argument('--agent-id', '-i', help='Agent identifier')
    parser.add_argument('--auto-export', action='store_true', help='Enable auto-export')
    parser.add_argument('--from-env', action='store_true', help='Read config from environment variables')
    parser.add_argument('--show', action='store_true', help='Show current configuration')
    parser.add_argument('--reset', action='store_true', help='Reset configuration to defaults')
    parser.add_argument('--test', action='store_true', help='Test connection to core server')

    args = parser.parse_args()

    # Show current config
    if args.show:
        config = load_config()
        print("\nCurrent Configuration:")
        print("-" * 40)
        for key, value in config.items():
            if key == 'api_key' and value:
                print(f"  {key}: {'*' * len(value)}")
            else:
                print(f"  {key}: {value}")
        sys.exit(0)

    # Reset config
    if args.reset:
        if CONFIG_FILE.exists():
            CONFIG_FILE.unlink()
            print("Configuration reset.")
        else:
            print("No configuration to reset.")
        sys.exit(0)

    # Test connection
    if args.test:
        config = load_config()
        server_url = config.get('core_server_url')
        if not server_url:
            print("No server URL configured. Use --server or configure via setup.")
            sys.exit(1)
        print(f"Testing connection to {server_url}...")
        if test_connection(server_url, config.get('api_key', '')):
            print("✓ Connection successful!")
            sys.exit(0)
        else:
            print("✗ Connection failed.")
            sys.exit(1)

    # From environment variables
    if args.from_env:
        print("Reading configuration from environment variables...")
        config = load_config()
        config['core_server_url'] = os.environ.get('CORE_SERVER_URL', config.get('core_server_url', ''))
        config['api_key'] = os.environ.get('API_KEY', config.get('api_key', ''))
        config['agent_id'] = os.environ.get('AGENT_ID', config.get('agent_id', '') or f"lightweight-{get_hostname()}")
        config['auto_export'] = os.environ.get('AUTO_EXPORT', 'false').lower() in ('true', '1', 'yes')
        config['export_on_complete'] = os.environ.get('EXPORT_ON_COMPLETE', 'true').lower() in ('true', '1', 'yes')
        config['setup_complete'] = bool(config['core_server_url'])

        save_config(config)
        print("Configuration saved from environment variables.")
        print(f"  Server: {config['core_server_url'] or '(not set)'}")
        print(f"  Agent ID: {config['agent_id']}")
        print(f"  Auto Export: {config['auto_export']}")
        sys.exit(0)

    # Non-interactive with command line args
    if args.server or args.api_key or args.agent_id:
        config = load_config()

        if args.server:
            config['core_server_url'] = args.server
        if args.api_key:
            config['api_key'] = args.api_key
        if args.agent_id:
            config['agent_id'] = args.agent_id
        else:
            config['agent_id'] = config.get('agent_id') or f"lightweight-{get_hostname()}"

        if args.auto_export:
            config['auto_export'] = True

        config['setup_complete'] = True
        save_config(config)

        print("Configuration updated:")
        print(f"  Server: {config['core_server_url']}")
        print(f"  Agent ID: {config['agent_id']}")
        print(f"  Auto Export: {config['auto_export']}")

        if config['core_server_url']:
            print("\nTesting connection...")
            if test_connection(config['core_server_url'], config.get('api_key', '')):
                print("✓ Connection successful!")
            else:
                print("✗ Connection failed (configuration saved anyway)")
        sys.exit(0)

    # Interactive mode
    config = interactive_setup()
    save_config(config)

    print("\n" + "=" * 60)
    print("  Setup Complete!")
    print("=" * 60)
    print(f"\n  Agent ID: {config['agent_id']}")
    print(f"  Server: {config['core_server_url'] or '(not connected)'}")
    print(f"  Auto Export: {config['auto_export']}")
    print("\n  Access web interface at: http://localhost:8088")
    print("=" * 60)


if __name__ == '__main__':
    main()
