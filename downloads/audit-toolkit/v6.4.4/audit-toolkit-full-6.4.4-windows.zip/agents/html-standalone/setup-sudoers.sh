#!/usr/bin/env bash
# =============================================================================
# Audit Agent - Linux Least-Privilege Sudoers Setup
# =============================================================================
# Configures scoped NOPASSWD sudo rules for an existing non-root agent user.
# This is the Linux equivalent pattern to JEA-style constrained elevation.
#
# Usage (as root):
#   sudo ./setup-sudoers.sh --agent-user audit-agent --install-dir /opt/audit-agent
#
# Notes:
# - Does NOT grant full root/admin shell.
# - Grants elevation only for toolkit audit/discovery scripts by path.
# - Validates syntax with visudo before enabling.
# =============================================================================

set -euo pipefail

AGENT_USER="${AUDIT_AGENT_USER:-audit-agent}"
INSTALL_DIR="${AUDIT_INSTALL_DIR:-/opt/audit-agent}"
SUDOERS_FILE=""
CREATE_USER_IF_MISSING=false
USER_HOME=""
USER_SHELL=""
SELF_TEST=false
SELF_TEST_ONLY=false

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

show_usage() {
    cat << EOF
Usage: $(basename "$0") [OPTIONS]

Configure scoped sudoers rules for an existing audit agent user.

Options:
  --agent-user USER   Target non-root user (default: audit-agent)
  --install-dir DIR   Agent install directory (default: /opt/audit-agent)
    --create-user       Create the user if it does not exist
    --user-home DIR     Home directory for created user (default: /var/lib/<user>)
    --user-shell PATH   Login shell for created user (default: nologin/false)
    --self-test         Run explicit PASS/FAIL association checks after setup
    --self-test-only    Run PASS/FAIL checks only (no user/sudoers changes)
  --yes               Non-interactive mode (skip confirmation)
  -h, --help          Show this help message

Environment Variables:
  AUDIT_AGENT_USER    Target user
  AUDIT_INSTALL_DIR   Agent install directory

Examples:
  sudo ./setup-sudoers.sh --agent-user audit-agent --install-dir /opt/audit-agent
    sudo ./setup-sudoers.sh --agent-user audit-agent --create-user --yes
    sudo ./setup-sudoers.sh --agent-user audit-agent --create-user --yes --self-test
    sudo ./setup-sudoers.sh --agent-user audit-agent --self-test-only
  sudo AUDIT_AGENT_USER=svc-audit ./setup-sudoers.sh --yes
EOF
}

ASSUME_YES=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --agent-user)
            AGENT_USER="$2"
            shift 2
            ;;
        --install-dir)
            INSTALL_DIR="$2"
            shift 2
            ;;
        --create-user)
            CREATE_USER_IF_MISSING=true
            shift
            ;;
        --user-home)
            USER_HOME="$2"
            shift 2
            ;;
        --user-shell)
            USER_SHELL="$2"
            shift 2
            ;;
        --self-test)
            SELF_TEST=true
            shift
            ;;
        --self-test-only)
            SELF_TEST_ONLY=true
            shift
            ;;
        --yes)
            ASSUME_YES=true
            shift
            ;;
        -h)
            show_usage
            exit 0
            ;;
        --help)
            show_usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            show_usage
            exit 1
            ;;
    esac
done

if [[ ${EUID} -ne 0 ]]; then
    log_error "This script must be run as root (use sudo)"
    exit 1
fi

if ! command -v visudo > /dev/null 2>&1; then
    log_error "visudo is required but not found"
    exit 1
fi

if [[ -z "$USER_HOME" ]]; then
    USER_HOME="/var/lib/${AGENT_USER}"
fi

if [[ -z "$USER_SHELL" ]]; then
    for candidate in /usr/sbin/nologin /sbin/nologin /bin/false; do
        if [[ -x "$candidate" ]]; then
            USER_SHELL="$candidate"
            break
        fi
    done
    if [[ -z "$USER_SHELL" ]]; then
        USER_SHELL="/bin/sh"
    fi
fi

create_service_user_if_needed() {
    if id "$AGENT_USER" > /dev/null 2>&1; then
        log_info "User '$AGENT_USER' already exists"
        return
    fi

    if [[ "$CREATE_USER_IF_MISSING" != "true" ]]; then
        log_error "User '$AGENT_USER' does not exist (pass --create-user to create it automatically)"
        exit 1
    fi

    log_info "Creating service user '$AGENT_USER'..."
    if ! command -v useradd > /dev/null 2>&1; then
        log_error "useradd not found on host, cannot create user automatically"
        exit 1
    fi

    mkdir -p "$USER_HOME"

    useradd --system --create-home --home-dir "$USER_HOME" --shell "$USER_SHELL" "$AGENT_USER"
    if ! id "$AGENT_USER" > /dev/null 2>&1; then
        log_error "Failed to create user '$AGENT_USER'"
        exit 1
    fi

    log_info "Created user '$AGENT_USER' with home '$USER_HOME' and shell '$USER_SHELL'"
}
SUDOERS_FILE="/etc/sudoers.d/audit-agent-${AGENT_USER}"

if [[ "$SELF_TEST_ONLY" != "true" ]]; then
    create_service_user_if_needed

    if [[ ! -d "$INSTALL_DIR" ]]; then
        log_warn "Install directory '$INSTALL_DIR' does not exist yet; proceeding with configured path"
    fi

    cat << EOF

Configuring least-privilege sudoers:
  User:        $AGENT_USER
  Install Dir: $INSTALL_DIR
  File:        $SUDOERS_FILE

This grants path-scoped script elevation only (not full root shell).
EOF

    if [[ "$ASSUME_YES" != "true" ]]; then
        read -r -p "Proceed? [y/N] " confirm
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            log_info "Cancelled"
            exit 0
        fi
    fi

    tmp_file="$(mktemp)"
    trap 'rm -f "$tmp_file"' EXIT

    cat > "$tmp_file" << EOF
# Audit Agent Sudoers Configuration
# Generated: $(date)
# User: $AGENT_USER
# Install Dir: $INSTALL_DIR

Defaults:$AGENT_USER !requiretty
Defaults:$AGENT_USER env_reset
Defaults:$AGENT_USER secure_path="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Script-only elevation scoped to toolkit paths
$AGENT_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/audits/*/*/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/audits/*/*/*.sh
$AGENT_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/fleet-agent.sh discovery
$AGENT_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/fleet-agent.sh discovery
$AGENT_USER ALL=(root) NOPASSWD: /usr/bin/bash $INSTALL_DIR/fleet-agent.sh --discovery
$AGENT_USER ALL=(root) NOPASSWD: /bin/bash $INSTALL_DIR/fleet-agent.sh --discovery

# Explicit deny of shell escalation as root
$AGENT_USER ALL=(root) NOPASSWD: !/bin/sh
$AGENT_USER ALL=(root) NOPASSWD: !/usr/bin/su
$AGENT_USER ALL=(root) NOPASSWD: !/usr/bin/sudoedit
EOF

    if ! visudo -cf "$tmp_file" > /dev/null 2>&1; then
        log_error "Generated sudoers content failed validation"
        exit 1
    fi

    install -m 0440 -o root -g root "$tmp_file" "$SUDOERS_FILE"

    if visudo -cf "$SUDOERS_FILE" > /dev/null 2>&1; then
        log_info "Sudoers file installed: $SUDOERS_FILE"
    else
        log_error "Installed sudoers file failed validation; removing"
        rm -f "$SUDOERS_FILE"
        exit 1
    fi

    verify_association() {
        log_info "Verifying user and sudo association..."

        local sudo_list
        sudo_list="$(sudo -n -u "$AGENT_USER" sudo -n -l 2> /dev/null || true)"

        local uid
        uid="$(id -u "$AGENT_USER")"
        local gid
        gid="$(id -g "$AGENT_USER")"
        local file_mode
        file_mode="$(stat -c '%a' "$SUDOERS_FILE")"

        if [[ "$file_mode" != "440" ]]; then
            log_error "Unexpected sudoers mode: $file_mode (expected 440)"
            exit 1
        fi

        if echo "$sudo_list" | grep -F "$INSTALL_DIR/audits" > /dev/null; then
            log_info "Path-scoped audit elevation check passed for user '$AGENT_USER'"
        else
            log_error "Path-scoped audit elevation check failed for user '$AGENT_USER'"
            exit 1
        fi

        if echo "$sudo_list" | grep -F "$INSTALL_DIR/fleet-agent.sh" > /dev/null; then
            log_info "Path-scoped discovery elevation check passed for user '$AGENT_USER'"
        else
            log_error "Path-scoped discovery elevation check failed for user '$AGENT_USER'"
            exit 1
        fi

        if sudo -n -u "$AGENT_USER" sudo -n /bin/bash -lc 'id -u' > /dev/null 2>&1; then
            log_warn "Shell escalation appears allowed; review sudoers restrictions"
        else
            log_info "Shell escalation deny check passed"
        fi

        log_info "Verification summary: user=$AGENT_USER uid=$uid gid=$gid sudoers=$SUDOERS_FILE mode=$file_mode"
    }

    verify_association
fi

run_self_test_summary() {
    log_info "Running self-test summary..."

    local failures=0
    local sudo_list
    sudo_list="$(sudo -n -u "$AGENT_USER" sudo -n -l 2> /dev/null || true)"

    report_check() {
        local name="$1"
        local status="$2"
        echo "SELF_TEST:${name}=${status}"
        if [[ "$status" != "PASS" ]]; then
            failures=$((failures + 1))
        fi
    }

    if id "$AGENT_USER" > /dev/null 2>&1; then
        report_check "user_exists" "PASS"
    else
        report_check "user_exists" "FAIL"
    fi

    if [[ -f "$SUDOERS_FILE" ]]; then
        report_check "sudoers_file_exists" "PASS"
    else
        report_check "sudoers_file_exists" "FAIL"
    fi

    if [[ -f "$SUDOERS_FILE" ]]; then
        local mode
        mode="$(stat -c '%a' "$SUDOERS_FILE")"
        if [[ "$mode" == "440" ]]; then
            report_check "sudoers_mode_440" "PASS"
        else
            report_check "sudoers_mode_440" "FAIL"
        fi
    else
        report_check "sudoers_mode_440" "FAIL"
    fi

    if visudo -cf "$SUDOERS_FILE" > /dev/null 2>&1; then
        report_check "sudoers_syntax" "PASS"
    else
        report_check "sudoers_syntax" "FAIL"
    fi

    if echo "$sudo_list" | grep -F "$INSTALL_DIR/audits" > /dev/null; then
        report_check "audit_path_scope" "PASS"
    else
        report_check "audit_path_scope" "FAIL"
    fi

    if echo "$sudo_list" | grep -F "$INSTALL_DIR/fleet-agent.sh" > /dev/null; then
        report_check "discovery_path_scope" "PASS"
    else
        report_check "discovery_path_scope" "FAIL"
    fi

    if sudo -n -u "$AGENT_USER" sudo -n /bin/bash -lc 'id -u' > /dev/null 2>&1; then
        report_check "shell_escalation_blocked" "FAIL"
    else
        report_check "shell_escalation_blocked" "PASS"
    fi

    if [[ "$failures" -eq 0 ]]; then
        echo "SELF_TEST:RESULT=PASS"
        return 0
    fi

    echo "SELF_TEST:RESULT=FAIL"
    return 1
}

if [[ "$SELF_TEST" == "true" ]]; then
    run_self_test_summary
fi

if [[ "$SELF_TEST_ONLY" == "true" ]]; then
    cat << EOF

Self-test completed.
No configuration changes were made.
EOF
    exit 0
fi

cat << EOF

Least-privilege setup complete.
Verify with:
  sudo -u $AGENT_USER sudo -n /usr/bin/systemctl status sshd

Hardening baseline:
    1) Use a dedicated service account for audits only (no interactive login).
    2) Keep sudoers scoped to toolkit audit/discovery script paths only.
    3) Review $SUDOERS_FILE after toolkit updates and at regular intervals.
    4) Monitor sudo logs for this account and alert on unexpected commands.
    5) Remove unused rules immediately when audits are retired.

To remove:
  sudo rm -f $SUDOERS_FILE
EOF
