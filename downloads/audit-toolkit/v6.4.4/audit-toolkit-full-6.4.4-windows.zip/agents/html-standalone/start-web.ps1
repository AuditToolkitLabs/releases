<#
.SYNOPSIS
    Start the Lightweight Audit Agent Web Interface on Windows
.DESCRIPTION
    Runs the Flask-based web interface for the lightweight audit agent.
    No Docker required - runs directly with Python.
.PARAMETER Port
    Port to listen on (default: 8088)
.PARAMETER Host
    Host/IP to bind to (default: 127.0.0.1 for local only, use 0.0.0.0 for all interfaces)
.PARAMETER CoreServerUrl
    URL of the main audit server (optional)
.PARAMETER ApiKey
    API key for authentication with core server (optional)
.PARAMETER AgentId
    Unique identifier for this agent (optional, auto-generated if not provided)
.PARAMETER EnableAuth
    Enable login authentication (default: false)
.PARAMETER AuthPassword
    Password for web interface authentication (required if EnableAuth is true)
.PARAMETER Background
    Run as a background job (survives terminal close)
.PARAMETER Stop
    Stop a running background job
.PARAMETER Status
    Check if background job is running
.EXAMPLE
    .\start-web.ps1
    Starts on localhost:8088 (local access only)
.EXAMPLE
    .\start-web.ps1 -Port 8080 -BindHost 0.0.0.0
    Starts on all interfaces, port 8080
.EXAMPLE
    .\start-web.ps1 -CoreServerUrl "https://audit-server:5000" -ApiKey "secret"
    Starts with pre-configured core server connection
.EXAMPLE
    .\start-web.ps1 -EnableAuth -AuthPassword "MySecurePass123"
    Starts with login authentication enabled
.EXAMPLE
    .\start-web.ps1 -Background
    Starts in background (survives terminal close)
.EXAMPLE
    .\start-web.ps1 -Stop
    Stops the background job
#>

[CmdletBinding()]
param(
    [int]$Port = 8088,
    [string]$BindHost = "127.0.0.1",
    [string]$CoreServerUrl = "",
    [string]$ApiKey = "",
    [string]$AgentId = "",
    [switch]$EnableAuth,
    [System.Security.SecureString]$AuthPassword,
    [string]$AuthPasswordHint = "",
    [switch]$RequirePasswordChange,
    [int]$MinPasswordLength = 12,
    [switch]$RequireSpecialOnChange,
    [switch]$Debug,
    [switch]$Background,
    [switch]$Stop,
    [switch]$Status
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$JobName = "AuditAgentWeb"
$PidFile = Join-Path $ScriptDir "agent.pid"

function Convert-SecureStringToPlainText {
    param([System.Security.SecureString]$Value)

    if (-not $Value) {
        return ""
    }

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

# ============================================================================
# Background Job Management
# ============================================================================

function Get-AgentJob {
    Get-Job -Name $JobName -ErrorAction SilentlyContinue
}

function Stop-AgentJob {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param()

    $job = Get-AgentJob
    if ($job) {
        if (-not $PSCmdlet.ShouldProcess($JobName, 'Stop and remove background agent job')) {
            return
        }

        Write-Output "[INFO] Stopping background job..."
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        if (Test-Path $PidFile) { Remove-Item $PidFile -Force }
        Write-Output "[OK] Background job stopped"
    } else {
        Write-Output "[WARN] No background job found"
    }
}

function Get-AgentStatus {
    $job = Get-AgentJob
    if ($job -and $job.State -eq 'Running') {
        Write-Output "[RUNNING] Agent is running as background job"
        Write-Output "  Job Name:  $JobName"
        Write-Output "  State:     $($job.State)"
        Write-Output "  Started:   $($job.PSBeginTime)"

        # Check health endpoint
        try {
            $response = Invoke-WebRequest -Uri "http://${BindHost}:${Port}/health" -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
            if ($response.StatusCode -eq 200) {
                Write-Output "  Health:    OK"
            }
        } catch {
            Write-Output "  Health:    Not responding"
        }
        return $true
    } else {
        Write-Output "[STOPPED] Agent is not running"
        return $false
    }
}

# Handle -Stop
if ($Stop) {
    Stop-AgentJob
    exit 0
}

# Handle -Status
if ($Status) {
    if (Get-AgentStatus) { exit 0 } else { exit 1 }
}

# Banner
Write-Output ""
Write-Output "============================================="
Write-Output "  Lightweight Audit Agent - Web Interface"
Write-Output "  Windows Portable Edition"
Write-Output "============================================="
Write-Output ""

# Check Python
$python = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python 3") {
            $python = $cmd
            Write-Output "[OK] Found $ver"
            break
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }
}

if (-not $python) {
    Write-Output "[ERROR] Python 3 is required but not found."
    Write-Output "        Install from: https://www.python.org/downloads/"
    exit 1
}

# Check/Install Flask
Write-Output "[INFO] Checking dependencies..."
& $python -c "import flask; print(flask.__version__)" 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Output "[INFO] Installing Flask..."
    & $python -m pip install flask --quiet
}

# Set environment variables
$env:FLASK_APP = "web.app"
$env:FLASK_ENV = if ($Debug) { "development" } else { "production" }
$env:PYTHONUNBUFFERED = "1"

$auditDirCandidates = @(
    (Join-Path $ScriptDir "audits\windows"),
    (Join-Path $ScriptDir "..\audits\windows"),
    (Join-Path $ScriptDir "..\..\audits\windows")
)
$resolvedAuditDir = $auditDirCandidates[0]
foreach ($candidate in $auditDirCandidates) {
    if (Test-Path $candidate) {
        $resolvedAuditDir = $candidate
        break
    }
}

# Platform-specific paths
$env:APP_DIR = $ScriptDir
$env:AUDIT_DIR = $resolvedAuditDir
$env:AUDIT_RESULTS_DIR = Join-Path $ScriptDir "results"
$env:CONFIG_DIR = Join-Path $ScriptDir "config"
$env:LOGS_DIR = Join-Path $ScriptDir "logs"
$env:ORCHESTRATOR_PATH = ""  # Not used on Windows
$env:AGENT_PATH = Join-Path $ScriptDir "agent.ps1"
$env:PLATFORM = "windows"

# Core server configuration
if ($CoreServerUrl) {
    $env:CORE_SERVER_URL = $CoreServerUrl
}
if ($ApiKey) {
    $env:API_KEY = $ApiKey
}
if ($AgentId) {
    $env:AGENT_ID = $AgentId
}

# Authentication configuration
if ($EnableAuth) {
    if (-not $AuthPassword) {
        $AuthPassword = Read-Host "Enter web auth password" -AsSecureString
    }
    $env:AUTH_ENABLED = "true"
    $env:AUTH_PASSWORD = Convert-SecureStringToPlainText -Value $AuthPassword
    if ($AuthPasswordHint) { $env:AUTH_PASSWORD_HINT = $AuthPasswordHint }
    $env:AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN = if ($RequirePasswordChange) { "true" } else { "false" }
    $env:AUTH_MIN_PASSWORD_LENGTH = $MinPasswordLength.ToString()
    $env:AUTH_REQUIRE_SPECIAL_ON_CHANGE = if ($RequireSpecialOnChange) { "true" } else { "false" }
    Write-Output "[INFO] Authentication ENABLED (first-login change: $(if ($RequirePasswordChange) { 'yes' } else { 'no' }))"
} else {
    $env:AUTH_ENABLED = "false"
    Write-Output "[INFO] Authentication disabled (local access assumed)"
}

# Create directories
$dirs = @($env:AUDIT_RESULTS_DIR, $env:CONFIG_DIR, $env:LOGS_DIR)
foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

# Summary
Write-Output ""
Write-Output "Configuration:"
Write-Output "  Bind Address: $BindHost`:$Port"
Write-Output "  Audit Dir:    $($env:AUDIT_DIR)"
Write-Output "  Results Dir:  $($env:AUDIT_RESULTS_DIR)"
Write-Output "  Core Server:  $(if ($CoreServerUrl) { $CoreServerUrl } else { '(not configured)' })"
Write-Output "  Auth Enabled: $(if ($EnableAuth) { 'Yes' } else { 'No' })"
Write-Output "  Background:   $(if ($Background) { 'Yes' } else { 'No (foreground)' })"
Write-Output ""

# ============================================================================
# Start Server
# ============================================================================

if ($Background) {
    # Check if already running
    $existingJob = Get-AgentJob
    if ($existingJob -and $existingJob.State -eq 'Running') {
        Write-Output "[WARN] Agent is already running in background"
        Write-Output "  Use -Stop to stop it, or -Status to check status"
        exit 1
    }

    Write-Output "Starting web server in background..."
    Write-Output "Access at: http://$BindHost`:$Port"
    Write-Output ""
    Write-Output "Commands:"
    Write-Output "  .\start-web.ps1 -Status   # Check status"
    Write-Output "  .\start-web.ps1 -Stop     # Stop background job"
    Write-Output ""

    # Create script block with all environment variables
    $scriptBlock = {
        param($ScriptDir, $BindHost, $Port, $Python, $EnvVars)

        # Set environment variables
        foreach ($key in $EnvVars.Keys) {
            Set-Item -Path "env:$key" -Value $EnvVars[$key]
        }

        Set-Location $ScriptDir

        # Check for waitress
        & $Python -c "import waitress" 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            & $Python -c "from waitress import serve; from web.app import app; serve(app, host='$BindHost', port=$Port)"
        } else {
            & $Python -m flask run --host $BindHost --port $Port
        }
    }

    # Collect environment variables to pass to job
    $envVars = @{
        'FLASK_APP' = $env:FLASK_APP
        'FLASK_ENV' = $env:FLASK_ENV
        'PYTHONUNBUFFERED' = $env:PYTHONUNBUFFERED
        'APP_DIR' = $env:APP_DIR
        'AUDIT_DIR' = $env:AUDIT_DIR
        'AUDIT_RESULTS_DIR' = $env:AUDIT_RESULTS_DIR
        'CONFIG_DIR' = $env:CONFIG_DIR
        'LOGS_DIR' = $env:LOGS_DIR
        'AGENT_PATH' = $env:AGENT_PATH
        'PLATFORM' = $env:PLATFORM
        'AUTH_ENABLED' = $env:AUTH_ENABLED
    }
    if ($CoreServerUrl) { $envVars['CORE_SERVER_URL'] = $CoreServerUrl }
    if ($ApiKey) { $envVars['API_KEY'] = $ApiKey }
    if ($AgentId) { $envVars['AGENT_ID'] = $AgentId }
    if ($AuthPassword) { $envVars['AUTH_PASSWORD'] = Convert-SecureStringToPlainText -Value $AuthPassword }
    if ($AuthPasswordHint) { $envVars['AUTH_PASSWORD_HINT'] = $AuthPasswordHint }
    if ($EnableAuth) {
        $envVars['AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN'] = $env:AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN
        $envVars['AUTH_MIN_PASSWORD_LENGTH'] = $env:AUTH_MIN_PASSWORD_LENGTH
        $envVars['AUTH_REQUIRE_SPECIAL_ON_CHANGE'] = $env:AUTH_REQUIRE_SPECIAL_ON_CHANGE
    }

    # Start background job
    $job = Start-Job -Name $JobName -ScriptBlock $scriptBlock -ArgumentList $ScriptDir, $BindHost, $Port, $python, $envVars

    # Save PID
    $job.Id | Out-File -FilePath $PidFile -Force

    # Wait briefly and check if started
    Start-Sleep -Seconds 3
    $job = Get-AgentJob
    if ($job.State -eq 'Running') {
        Write-Output "[OK] Background job started successfully (Job ID: $($job.Id))"
    } else {
        Write-Output "[ERROR] Background job failed to start"
        Write-Output "Error: $($job.ChildJobs[0].JobStateInfo.Reason)"
        Remove-Job -Job $job -Force
        exit 1
    }
} else {
    # Foreground mode
    Write-Output "Starting web server..."
    Write-Output "Access at: http://$BindHost`:$Port"
    Write-Output "Press Ctrl+C to stop"
    Write-Output ""
    Write-Output "TIP: Use -Background to run in background (survives terminal close)"
    Write-Output ""

    Push-Location $ScriptDir

    try {
        if ($Debug) {
            # Development mode with auto-reload
            & $python -m flask run --host $BindHost --port $Port --reload
        } else {
            # Production mode (waitress on Windows since gunicorn is Linux-only)
            & $python -c "import waitress" 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) {
                Write-Output "[INFO] Installing waitress (production WSGI server)..."
                & $python -m pip install waitress --quiet
            }
            & $python -c "from waitress import serve; from web.app import app; serve(app, host='$BindHost', port=$Port)"
        }
    } finally {
        Pop-Location
    }
}
