#!/usr/bin/env bash
# Start the Lightweight Audit Agent Web Interface on Linux
# No Docker required - runs directly with Python
#
# Usage:
#   ./start-web.sh                              # Local access only on port 8088
#   ./start-web.sh --port 8080 --host 0.0.0.0   # All interfaces
#   ./start-web.sh --core-server https://audit-server:5000 --api-key secret
#   ./start-web.sh --enable-auth --auth-password MySecurePass123
#   ./start-web.sh --daemon                     # Run in background (survives SSH disconnect)
#   ./start-web.sh --stop                       # Stop background daemon
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="${SCRIPT_DIR}/agent.pid"
LOG_FILE="${SCRIPT_DIR}/logs/agent.log"

# Defaults
PORT=8088
HOST="127.0.0.1"
CORE_SERVER_URL=""
API_KEY=""
AGENT_ID=""
ENABLE_AUTH="false"
AUTH_PASSWORD=""
AUTH_PASSWORD_HINT=""
AUTH_REQUIRE_PASSWORD_CHANGE="false"
AUTH_MIN_PASSWORD_LENGTH="12"
AUTH_REQUIRE_SPECIAL="true"
DEBUG_MODE=false
DAEMON_MODE=false
STOP_DAEMON=false
STATUS_CHECK=false

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

usage() {
    cat << EOF
Lightweight Audit Agent - Web Interface (Linux Portable Edition)

Usage: $(basename "$0") [OPTIONS]

Options:
    -p, --port PORT           Port to listen on (default: 8088)
    -H, --host HOST           Host/IP to bind to (default: 127.0.0.1)
    -s, --core-server URL     URL of the main audit server
    -k, --api-key KEY         API key for core server authentication
    -i, --agent-id ID         Unique identifier for this agent
    -a, --enable-auth         Enable login authentication
    -P, --auth-password PASS  Password for web interface (required if --enable-auth)
    --auth-hint TEXT          Human-readable password hint shown on login page
    --require-pw-change       Force password change on first login (default: false)
    --min-pw-length N         Minimum new password length (default: 12)
    --no-special-char         Do not require special character in new password
    -d, --debug               Run in debug mode with auto-reload
    -D, --daemon              Run in background (survives SSH disconnect)
    --stop                    Stop the background daemon
    --status                  Check if daemon is running
    --restart                 Restart the daemon
    -h, --help                Show this help

Examples:
    $(basename "$0")
        Start on localhost:8088 (local access only, foreground)

    $(basename "$0") --daemon
        Start in background (survives SSH disconnect)

    $(basename "$0") --daemon --host 0.0.0.0 --port 8080
        Start daemon on all interfaces, port 8080

    $(basename "$0") --stop
        Stop the background daemon

    $(basename "$0") --status
        Check if daemon is running

SSH Session Tips:
    # Use screen/tmux for long sessions
    screen -S audit-agent
    ./start-web.sh
    # Detach: Ctrl+A, D
    # Reattach: screen -r audit-agent

    # Or use --daemon flag (recommended)
    ./start-web.sh --daemon
    # Logs: tail -f logs/agent.log
EOF
    exit 0
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -p|--port)
            PORT="$2"
            shift 2
            ;;
        -H|--host)
            HOST="$2"
            shift 2
            ;;
        -s|--core-server)
            CORE_SERVER_URL="$2"
            shift 2
            ;;
        -k|--api-key)
            API_KEY="$2"
            shift 2
            ;;
        -i|--agent-id)
            AGENT_ID="$2"
            shift 2
            ;;
        -a|--enable-auth)
            ENABLE_AUTH="true"
            shift
            ;;
        -P|--auth-password)
            AUTH_PASSWORD="$2"
            shift 2
            ;;
        --auth-hint)
            AUTH_PASSWORD_HINT="$2"
            shift 2
            ;;
        --require-pw-change)
            AUTH_REQUIRE_PASSWORD_CHANGE="true"
            shift
            ;;
        --min-pw-length)
            AUTH_MIN_PASSWORD_LENGTH="$2"
            shift 2
            ;;
        --no-special-char)
            AUTH_REQUIRE_SPECIAL="false"
            shift
            ;;
        -d|--debug)
            DEBUG_MODE=true
            shift
            ;;
        -D|--daemon)
            DAEMON_MODE=true
            shift
            ;;
        --stop)
            STOP_DAEMON=true
            shift
            ;;
        --status)
            STATUS_CHECK=true
            shift
            ;;
        --restart)
            STOP_DAEMON=true
            DAEMON_MODE=true
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            usage
            ;;
    esac
done

# ============================================================================
# Daemon Management Functions
# ============================================================================

is_running() {
    if [[ -f "$PID_FILE" ]]; then
        local pid
        pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

stop_daemon() {
    if [[ -f "$PID_FILE" ]]; then
        local pid
        pid=$(cat "$PID_FILE")
        echo -e "${BLUE}[INFO]${NC} Stopping daemon (PID: $pid)..."
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            # Wait for graceful shutdown
            for _ in {1..10}; do
                if ! kill -0 "$pid" 2>/dev/null; then
                    break
                fi
                sleep 1
            done
            # Force kill if still running
            if kill -0 "$pid" 2>/dev/null; then
                echo -e "${YELLOW}[WARN]${NC} Forcing kill..."
                kill -9 "$pid" 2>/dev/null || true
            fi
        fi
        rm -f "$PID_FILE"
        echo -e "${GREEN}[OK]${NC} Daemon stopped"
    else
        echo -e "${YELLOW}[WARN]${NC} No PID file found. Daemon may not be running."
    fi
}

check_status() {
    if is_running; then
        local pid
        pid=$(cat "$PID_FILE")
        echo -e "${GREEN}[RUNNING]${NC} Daemon is running (PID: $pid)"
        echo -e "  Log file: $LOG_FILE"
        echo -e "  PID file: $PID_FILE"
        # Check if web server is responding
        if command -v curl &>/dev/null; then
            if curl -s -o /dev/null -w "%{http_code}" "http://${HOST}:${PORT}/health" | grep -q "200"; then
                echo -e "  Health:   ${GREEN}OK${NC}"
            else
                echo -e "  Health:   ${YELLOW}Not responding${NC}"
            fi
        fi
        return 0
    else
        echo -e "${RED}[STOPPED]${NC} Daemon is not running"
        return 1
    fi
}

# Handle --stop
if [[ "$STOP_DAEMON" == "true" && "$DAEMON_MODE" == "false" ]]; then
    stop_daemon
    exit 0
fi

# Handle --status
if [[ "$STATUS_CHECK" == "true" ]]; then
    check_status
    exit $?
fi

# Handle --restart (stop first if running)
if [[ "$STOP_DAEMON" == "true" && "$DAEMON_MODE" == "true" ]]; then
    if is_running; then
        stop_daemon
        sleep 1
    fi
fi

# Check if already running when starting daemon
if [[ "$DAEMON_MODE" == "true" ]] && is_running; then
    pid=$(cat "$PID_FILE")
    echo -e "${YELLOW}[WARN]${NC} Daemon already running (PID: $pid)"
    echo -e "  Use --stop to stop it, or --restart to restart"
    exit 1
fi

# Banner
echo -e ""
echo -e "${CYAN}=============================================${NC}"
echo -e "${CYAN}  Lightweight Audit Agent - Web Interface${NC}"
echo -e "${CYAN}  Linux Portable Edition${NC}"
echo -e "${CYAN}=============================================${NC}"
echo -e ""

# Check Python
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        ver=$("$cmd" --version 2>&1)
        if [[ "$ver" == *"Python 3"* ]]; then
            PYTHON="$cmd"
            echo -e "${GREEN}[OK]${NC} Found $ver"
            break
        fi
    fi
done

if [[ -z "$PYTHON" ]]; then
    echo -e "${RED}[ERROR]${NC} Python 3 is required but not found."
    echo -e "        Install: apt install python3 / dnf install python3 / apk add python3"
    exit 1
fi

# Check/Install Flask
echo -e "${BLUE}[INFO]${NC} Checking dependencies..."
if ! "$PYTHON" -c "import flask" 2>/dev/null; then
    echo -e "${YELLOW}[INFO]${NC} Installing Flask..."
    "$PYTHON" -m pip install flask --quiet --user 2>/dev/null || \
    "$PYTHON" -m pip install flask --quiet 2>/dev/null || \
    { echo -e "${RED}[ERROR]${NC} Failed to install Flask"; exit 1; }
fi

# Validate auth settings
if [[ "$ENABLE_AUTH" == "true" && -z "$AUTH_PASSWORD" ]]; then
    echo -e "${RED}[ERROR]${NC} --auth-password is required when --enable-auth is specified"
    exit 1
fi

# Set environment variables
export FLASK_APP="web.app"
export FLASK_ENV="${DEBUG_MODE:+development}"
export FLASK_ENV="${FLASK_ENV:-production}"
export PYTHONUNBUFFERED="1"

# Resolve audit directory for both installed and source-repo layouts.
AUDIT_DIR_CANDIDATES=(
    "${SCRIPT_DIR}/audits/linux"
    "${SCRIPT_DIR}/../audits/linux"
    "${SCRIPT_DIR}/../../audits/linux"
)
AUDIT_DIR_RESOLVED="${AUDIT_DIR_CANDIDATES[0]}"
for candidate in "${AUDIT_DIR_CANDIDATES[@]}"; do
    if [[ -d "$candidate" ]]; then
        AUDIT_DIR_RESOLVED="$candidate"
        break
    fi
done

# Platform-specific paths
export APP_DIR="$SCRIPT_DIR"
export AUDIT_DIR="$AUDIT_DIR_RESOLVED"
export AUDIT_RESULTS_DIR="${SCRIPT_DIR}/results"
export CONFIG_DIR="${SCRIPT_DIR}/config"
export LOGS_DIR="${SCRIPT_DIR}/logs"
export ORCHESTRATOR_PATH="${SCRIPT_DIR}/../orchestrator/orchestrator.sh"
export AGENT_PATH="${SCRIPT_DIR}/agent.sh"
export PLATFORM="linux"

# Core server configuration
[[ -n "$CORE_SERVER_URL" ]] && export CORE_SERVER_URL
[[ -n "$API_KEY" ]] && export API_KEY
[[ -n "$AGENT_ID" ]] && export AGENT_ID

# Authentication configuration
export AUTH_ENABLED="$ENABLE_AUTH"
if [[ "$ENABLE_AUTH" == "true" ]]; then
    export AUTH_PASSWORD
    [[ -n "$AUTH_PASSWORD_HINT" ]] && export AUTH_PASSWORD_HINT
    export AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN="$AUTH_REQUIRE_PASSWORD_CHANGE"
    export AUTH_MIN_PASSWORD_LENGTH
    export AUTH_REQUIRE_SPECIAL_ON_CHANGE="$AUTH_REQUIRE_SPECIAL"
    echo -e "${YELLOW}[INFO]${NC} Authentication ENABLED (first-login change: ${AUTH_REQUIRE_PASSWORD_CHANGE})"
else
    echo -e "${BLUE}[INFO]${NC} Authentication disabled (local access assumed)"
fi

# Create directories
mkdir -p "$AUDIT_RESULTS_DIR" "$CONFIG_DIR" "$LOGS_DIR"

# Summary
echo -e ""
echo -e "${CYAN}Configuration:${NC}"
echo -e "  Bind Address: ${HOST}:${PORT}"
echo -e "  Audit Dir:    ${AUDIT_DIR}"
echo -e "  Results Dir:  ${AUDIT_RESULTS_DIR}"
echo -e "  Core Server:  ${CORE_SERVER_URL:-'(not configured)'}"
echo -e "  Auth Enabled: $(if [[ "$ENABLE_AUTH" == "true" ]]; then echo "Yes"; else echo "No"; fi)"
echo -e "  Daemon Mode:  $(if [[ "$DAEMON_MODE" == "true" ]]; then echo "Yes"; else echo "No (foreground)"; fi)"
echo -e ""

# Change to script directory
cd "$SCRIPT_DIR"

# ============================================================================
# Start Server
# ============================================================================

start_server() {
    if [[ "$DEBUG_MODE" == "true" ]]; then
        # Development mode with auto-reload
        "$PYTHON" -m flask run --host "$HOST" --port "$PORT" --reload
    else
        # Production mode - try gunicorn first, fall back to flask
        if "$PYTHON" -c "import gunicorn" 2>/dev/null; then
            gunicorn --bind "${HOST}:${PORT}" --workers 2 --timeout 300 web.app:app
        else
            echo -e "${YELLOW}[WARN]${NC} gunicorn not installed, using Flask development server"
            echo -e "       For production, install: pip install gunicorn"
            "$PYTHON" -m flask run --host "$HOST" --port "$PORT"
        fi
    fi
}

if [[ "$DAEMON_MODE" == "true" ]]; then
    echo -e "${GREEN}Starting web server in daemon mode...${NC}"
    echo -e "${CYAN}Access at: http://${HOST}:${PORT}${NC}"
    echo -e "Logs:    $LOG_FILE"
    echo -e "PID:     $PID_FILE"
    echo -e ""
    echo -e "Commands:"
    echo -e "  ./start-web.sh --status   # Check status"
    echo -e "  ./start-web.sh --stop     # Stop daemon"
    echo -e "  tail -f $LOG_FILE         # View logs"
    echo -e ""

    # Use nohup to survive SSH disconnect
    nohup bash -c "
        cd '$SCRIPT_DIR'
        export FLASK_APP='web.app'
        export FLASK_ENV='production'
        export PYTHONUNBUFFERED='1'
        export APP_DIR='$SCRIPT_DIR'
        export AUDIT_DIR='${AUDIT_DIR}'
        export AUDIT_RESULTS_DIR='${SCRIPT_DIR}/results'
        export CONFIG_DIR='${SCRIPT_DIR}/config'
        export LOGS_DIR='${SCRIPT_DIR}/logs'
        export ORCHESTRATOR_PATH='${SCRIPT_DIR}/../orchestrator/orchestrator.sh'
        export AGENT_PATH='${SCRIPT_DIR}/agent.sh'
        export PLATFORM='linux'
        export AUTH_ENABLED='$ENABLE_AUTH'
        export AUTH_PASSWORD='$AUTH_PASSWORD'
        [[ -n '$AUTH_PASSWORD_HINT' ]] && export AUTH_PASSWORD_HINT='$AUTH_PASSWORD_HINT'
        export AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN='$AUTH_REQUIRE_PASSWORD_CHANGE'
        export AUTH_MIN_PASSWORD_LENGTH='$AUTH_MIN_PASSWORD_LENGTH'
        export AUTH_REQUIRE_SPECIAL_ON_CHANGE='$AUTH_REQUIRE_SPECIAL'
        [[ -n '$CORE_SERVER_URL' ]] && export CORE_SERVER_URL='$CORE_SERVER_URL'
        [[ -n '$API_KEY' ]] && export API_KEY='$API_KEY'
        [[ -n '$AGENT_ID' ]] && export AGENT_ID='$AGENT_ID'

        if '$PYTHON' -c 'import gunicorn' 2>/dev/null; then
            exec gunicorn --bind '${HOST}:${PORT}' --workers 2 --timeout 300 web.app:app
        else
            exec '$PYTHON' -m flask run --host '$HOST' --port '$PORT'
        fi
    " >> "$LOG_FILE" 2>&1 &

    # Save PID
    echo $! > "$PID_FILE"

    # Wait briefly and check if started
    sleep 2
    if is_running; then
        echo -e "${GREEN}[OK]${NC} Daemon started successfully (PID: $(cat "$PID_FILE"))"
    else
        echo -e "${RED}[ERROR]${NC} Daemon failed to start. Check logs: $LOG_FILE"
        rm -f "$PID_FILE"
        exit 1
    fi
else
    # Foreground mode
    echo -e "${GREEN}Starting web server...${NC}"
    echo -e "${CYAN}Access at: http://${HOST}:${PORT}${NC}"
    echo -e "Press Ctrl+C to stop"
    echo -e ""
    echo -e "${YELLOW}TIP:${NC} Use --daemon to run in background (survives SSH disconnect)"
    echo -e ""

    start_server
fi
