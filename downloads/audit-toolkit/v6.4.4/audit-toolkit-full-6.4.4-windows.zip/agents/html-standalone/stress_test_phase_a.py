#!/usr/bin/env python3
"""
Phase A4 - Conflict Verification & Stress Testing
Validates that A1, A2, and A3 work together without conflicts under load
"""

import sys
import os
import time
import requests
import json
import threading
from datetime import datetime
from collections import defaultdict
from statistics import mean, stdev
from urllib3.exceptions import InsecureRequestWarning

# Suppress SSL warnings for testing
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Configuration
BASE_URL = os.environ.get('APP_URL', 'http://localhost:8088')
NUM_WORKERS = 4
REQUESTS_PER_WORKER = 50
TEST_TIMEOUT = 30

# Results collection
results = {
    'headers_valid': 0,
    'headers_invalid': 0,
    'csrf_token_found': 0,
    'csrf_token_missing': 0,
    'rate_limit_enforced': 0,
    'rate_limit_bypass': 0,
    'requests_successful': 0,
    'requests_failed': 0,
    'response_times': [],
    'errors': []
}
results_lock = threading.Lock()

# Expected security headers
REQUIRED_HEADERS = {
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': None,  # Any value acceptable
    'Content-Security-Policy': None,
    'Strict-Transport-Security': None
}


def print_header(title):
    """Print section header"""
    print(f"\n{'=' * 70}")
    print(f"  {title}")
    print(f"{'=' * 70}\n")


def validate_security_headers(headers):
    """Validate that all required security headers are present"""
    valid = True
    missing = []

    for header_name, expected_value in REQUIRED_HEADERS.items():
        if header_name not in headers:
            valid = False
            missing.append(header_name)
        elif expected_value is not None and headers[header_name] != expected_value:
            # Log but don't fail if value is different (may be environment-specific)
            pass

    return valid, missing


def extract_csrf_token(html):
    """Extract CSRF token from HTML form"""
    import re
    match = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
    if match:
        return match.group(1)
    return None


def test_headers_present():
    """Test A1: Verify security headers are present on all endpoints"""
    print_header("Phase A1: HTTP Security Headers Validation")

    endpoints = [
        '/health',
        '/api/system-info',
        '/login'
    ]

    all_valid = True

    for endpoint in endpoints:
        try:
            response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target
            valid, missing = validate_security_headers(response.headers)

            status = "✅ PASS" if valid else "⚠️ WARNING"
            print(f"{status}: {endpoint}")

            if not valid:
                all_valid = False
                print(f"        Missing headers: {', '.join(missing)}")

            # Show sample headers
            for header in ['X-Frame-Options', 'Content-Security-Policy']:
                if header in response.headers:
                    print(f"        {header}: {response.headers[header][:50]}...")

        except Exception as e:
            print(f"❌ FAIL: {endpoint} - {str(e)}")
            all_valid = False

    return all_valid


def test_csrf_protection():
    """Test A2: Verify CSRF token generation and form embedding"""
    print_header("Phase A2: CSRF Token Protection Validation")

    print("Testing CSRF token generation on login form...")

    try:
        response = requests.get(f'{BASE_URL}/login', verify=False, timeout=5)  # nosec B501 - local lab stress test target

        if response.status_code != 200:
            print(f"❌ FAIL: Could not retrieve login form (status {response.status_code})")
            return False

        token = extract_csrf_token(response.text)

        if token:
            print(f"✅ PASS: CSRF token found in form")
            print(f"        Token (first 20 chars): {token[:20]}...")
            return True
        else:
            print(f"❌ FAIL: CSRF token not found in form")
            return False

    except Exception as e:
        print(f"❌ FAIL: Could not test CSRF token - {str(e)}")
        return False


def test_rate_limiting():
    """Test A3: Verify rate limiting is enforced"""
    print_header("Phase A3: Rate Limiting Validation")

    # Test endpoint with lower rate limit (login: 5/minute)
    endpoint = '/login'
    max_requests = 6

    print(f"Testing rate limiting on {endpoint} (limit: 5/minute)...")
    print(f"Making {max_requests} requests...")

    rate_limit_hit = False
    responses_codes = []

    for i in range(max_requests):
        try:
            response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target
            responses_codes.append(response.status_code)

            if response.status_code == 429:
                rate_limit_hit = True
                print(f"  Request {i+1}: ❌ 429 (Rate Limited)")
            elif response.status_code == 200:
                print(f"  Request {i+1}: ✅ 200 (OK)")
            else:
                print(f"  Request {i+1}: ⚠️ {response.status_code}")

        except Exception as e:
            print(f"  Request {i+1}: ❌ Error - {str(e)}")

    if rate_limit_hit:
        print(f"\n✅ PASS: Rate limiting is enforced")
        return True
    else:
        print(f"\n⚠️ WARNING: Rate limiting may not have triggered")
        print(f"        Response codes: {responses_codes}")
        return False


def test_headers_with_rate_limit():
    """Test that security headers are present even when rate limited"""
    print_header("Phase A4.1: Headers & Rate Limiting Interaction")

    print("Verifying security headers remain during rate limit responses...")

    endpoint = '/login'

    # Exhaust rate limit
    for i in range(6):
        try:
            response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target
        except:
            pass

    # Next request should be rate limited
    try:
        response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target

        if response.status_code == 429:
            valid, missing = validate_security_headers(response.headers)

            if valid:
                print(f"✅ PASS: Security headers present in 429 response")
                return True
            else:
                print(f"⚠️ WARNING: Some headers missing in 429 response")
                print(f"          Missing: {', '.join(missing)}")
                return False
        else:
            print(f"⚠️ WARNING: Rate limit not triggered (status {response.status_code})")
            return False

    except Exception as e:
        print(f"❌ FAIL: Could not test - {str(e)}")
        return False


def test_csrf_with_rate_limit():
    """Test that CSRF and rate limiting work together"""
    print_header("Phase A4.2: CSRF & Rate Limiting Interaction")

    print("Testing POST without CSRF token (should fail with 400/403, not 429)...")

    try:
        response = requests.post(f'{BASE_URL}/login',
                              data={'username': 'test', 'password': 'test'},
                              verify=False, timeout=5)  # nosec B501 - local lab stress test target

        # Should get CSRF error, not rate limit
        if response.status_code in [400, 401, 403]:
            print(f"✅ PASS: Got expected CSRF error ({response.status_code})")
            print(f"        CSRF protection takes precedence over rate limiting")
            return True
        elif response.status_code == 429:
            print(f"⚠️ WARNING: Got rate limit (429) before CSRF validation")
            return False
        else:
            print(f"⚠️ INFO: Got status {response.status_code}")
            return False

    except Exception as e:
        print(f"❌ FAIL: Could not test - {str(e)}")
        return False


def stress_test_worker(worker_id, endpoint, num_requests):
    """Worker thread for stress testing"""
    local_results = {
        'successful': 0,
        'rate_limited': 0,
        'errors': 0,
        'response_times': []
    }

    for i in range(num_requests):
        try:
            start = time.time()
            response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target
            elapsed = time.time() - start

            local_results['response_times'].append(elapsed)

            if response.status_code == 200:
                local_results['successful'] += 1
            elif response.status_code == 429:
                local_results['rate_limited'] += 1
            else:
                local_results['errors'] += 1

        except Exception as e:
            local_results['errors'] += 1

    # Thread-safe results update
    with results_lock:
        results['requests_successful'] += local_results['successful']
        results['rate_limit_enforced'] += local_results['rate_limited']
        results['requests_failed'] += local_results['errors']
        results['response_times'].extend(local_results['response_times'])


def stress_test_rate_limiting():
    """Stress test: Verify rate limiting under concurrent load"""
    print_header("Phase A4.3: Stress Testing - Rate Limiting Under Load")

    endpoint = '/api/health'  # Unlimited endpoint for baseline

    print(f"Starting stress test with {NUM_WORKERS} workers...")
    print(f"Each worker making {REQUESTS_PER_WORKER} requests")
    print(f"Total requests: {NUM_WORKERS * REQUESTS_PER_WORKER}\n")

    start_time = time.time()

    # Create worker threads
    threads = []
    for worker_id in range(NUM_WORKERS):
        thread = threading.Thread(
            target=stress_test_worker,
            args=(worker_id, endpoint, REQUESTS_PER_WORKER)
        )
        threads.append(thread)
        thread.start()

    # Wait for all threads
    for thread in threads:
        thread.join()

    elapsed = time.time() - start_time

    # Calculate statistics
    total_requests = NUM_WORKERS * REQUESTS_PER_WORKER

    print(f"\n📊 Stress Test Results:")
    print(f"  Total requests: {total_requests}")
    print(f"  Successful: {results['requests_successful']} ({100*results['requests_successful']//total_requests}%)")
    print(f"  Rate limited: {results['rate_limit_enforced']}")
    print(f"  Failed: {results['requests_failed']}")
    print(f"  Total time: {elapsed:.2f}s")
    print(f"  Average RPS: {total_requests/elapsed:.1f}")

    if results['response_times']:
        print(f"\n⏱️ Response Time Statistics:")
        print(f"  Min: {min(results['response_times'])*1000:.2f}ms")
        print(f"  Max: {max(results['response_times'])*1000:.2f}ms")
        print(f"  Mean: {mean(results['response_times'])*1000:.2f}ms")
        if len(results['response_times']) > 1:
            print(f"  Stdev: {stdev(results['response_times'])*1000:.2f}ms")

    return results['requests_failed'] == 0


def test_exempt_endpoints():
    """Test that exempt endpoints are not rate limited"""
    print_header("Phase A4.4: Rate Limit Exemptions")

    exempt_endpoints = [
        '/api/health',
        '/api/system-info'
    ]

    all_working = True

    for endpoint in exempt_endpoints:
        print(f"Testing exemption on {endpoint}...")

        # Make multiple requests
        success_count = 0
        for i in range(10):
            try:
                response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target
                if response.status_code == 200:
                    success_count += 1
            except:
                pass

        if success_count == 10:
            print(f"✅ PASS: {endpoint} is not rate limited")
        else:
            print(f"⚠️ WARNING: {endpoint} may be rate limited ({success_count}/10 succeeded)")
            all_working = False

    return all_working


def test_security_header_consistency():
    """Test that security headers are consistent across endpoints"""
    print_header("Phase A4.5: Security Header Consistency")

    endpoints = ['/login', '/api/health', '/api/system-info']
    headers_across_endpoints = defaultdict(list)

    print("Testing header consistency across endpoints...\n")

    for endpoint in endpoints:
        try:
            response = requests.get(f'{BASE_URL}{endpoint}', verify=False, timeout=5)  # nosec B501 - local lab stress test target

            for header in REQUIRED_HEADERS.keys():
                if header in response.headers:
                    headers_across_endpoints[header].append(endpoint)

        except Exception as e:
            print(f"❌ Error accessing {endpoint}: {str(e)}")

    # Check consistency
    all_consistent = True
    for header, endpoints_with_header in headers_across_endpoints.items():
        if len(endpoints_with_header) == len(endpoints):
            print(f"✅ {header}: Present on all endpoints")
        elif len(endpoints_with_header) > 0:
            print(f"⚠️ {header}: Present on {len(endpoints_with_header)}/{len(endpoints)} endpoints")
            all_consistent = False
        else:
            print(f"❌ {header}: Not found on any endpoint")
            all_consistent = False

    return all_consistent


def main():
    """Run all validation tests"""
    print("\n" + "="*70)
    print("  Phase A4: Security Hardening Integration & Stress Testing")
    print("="*70)
    print(f"\n📍 Target: {BASE_URL}")
    print(f"🕐 Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Wait for service to be ready
    print("\n⏳ Waiting for service to be ready...")
    for attempt in range(10):
        try:
            response = requests.get(f'{BASE_URL}/api/health', verify=False, timeout=2)  # nosec B501 - local lab stress test target
            if response.status_code == 200:
                print("✅ Service is ready\n")
                break
        except:
            pass

        if attempt == 9:
            print(f"❌ Service not responding at {BASE_URL}")
            print("   Make sure the app is running: cd agents/html-standalone && python web/app.py")
            return False

        time.sleep(1)

    # Run all tests
    test_results = {
        "Phase A1 - Headers": test_headers_present(),
        "Phase A2 - CSRF": test_csrf_protection(),
        "Phase A3 - Rate Limiting": test_rate_limiting(),
        "Phase A4.1 - Headers + Rate Limit": test_headers_with_rate_limit(),
        "Phase A4.2 - CSRF + Rate Limit": test_csrf_with_rate_limit(),
        "Phase A4.3 - Stress Testing": stress_test_rate_limiting(),
        "Phase A4.4 - Rate Limit Exemptions": test_exempt_endpoints(),
        "Phase A4.5 - Header Consistency": test_security_header_consistency(),
    }

    # Print summary
    print_header("📊 Summary")

    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")

    passed = sum(1 for v in test_results.values() if v)
    total = len(test_results)

    print(f"\n{'='*70}")
    print(f"  Results: {passed}/{total} tests passed ({100*passed//total}%)")
    print(f"  Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")

    return passed == total


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
