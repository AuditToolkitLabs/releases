#Requires -Version 5.1
<#
.SYNOPSIS
    Sync audit scripts from the main repository to the standalone agent
.DESCRIPTION
    Copies Windows audit scripts and the common module to the agent's audits folder.
    This enables the agent to run the same audits as WinRM/SSH connectivity.
.PARAMETER SourcePath
    Path to the main Audit-Tool repository (default: parent of agent folder)
.PARAMETER AuditsOnly
    Only sync audit scripts, skip lib files
#>
param(
    [string]$SourcePath = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),
    [switch]$AuditsOnly
)

$AgentDir = Split-Path -Parent $PSScriptRoot
$AgentAuditsDir = Join-Path $AgentDir "audits"
$AgentLibDir = Join-Path $AgentAuditsDir "_lib"

# Source paths
$SourceWindowsAudits = Join-Path $SourcePath "audits\windows"
$SourceCommonModule = Join-Path $SourceWindowsAudits "common\common-audit.psm1"

Write-Output "Standalone Agent Audit Sync"
Write-Output "============================"
Write-Output "Source: $SourcePath"
Write-Output "Target: $AgentAuditsDir"
Write-Output ""

# Verify source exists
if (-not (Test-Path $SourceWindowsAudits)) {
    Write-Output "[ERROR] Source audits not found: $SourceWindowsAudits"
    Write-Output "Please specify the path to the Audit-Tool repository with -SourcePath"
    exit 1
}

# Create directories
if (-not (Test-Path $AgentLibDir)) {
    New-Item -ItemType Directory -Path $AgentLibDir -Force | Out-Null
}

# Copy common module (required by all Windows audits)
if (-not $AuditsOnly) {
    Write-Output "Copying common audit module..."
    Copy-Item -Path $SourceCommonModule -Destination $AgentLibDir -Force
    Write-Output "[OK] Copied common-audit.psm1"
}

# Define audit categories to sync
$categories = @(
    @{ Source = "common"; Target = "windows\common"; Include = "*.ps1" }
    @{ Source = "server"; Target = "windows\server"; Include = "*.ps1" }
    @{ Source = "desktop"; Target = "windows\desktop"; Include = "*.ps1" }
    @{ Source = "apps"; Target = "windows\apps"; Include = "*.ps1" }
)

$totalCopied = 0

foreach ($cat in $categories) {
    $sourceCat = Join-Path $SourceWindowsAudits $cat.Source
    $targetCat = Join-Path $AgentAuditsDir $cat.Target

    if (Test-Path $sourceCat) {
        Write-Output "Syncing $($cat.Source) audits..."

        if (-not (Test-Path $targetCat)) {
            New-Item -ItemType Directory -Path $targetCat -Force | Out-Null
        }

        $scripts = Get-ChildItem -Path $sourceCat -Filter $cat.Include -ErrorAction SilentlyContinue
        foreach ($script in $scripts) {
            # Skip the module itself (we put it in _lib)
            if ($script.Name -eq "common-audit.psm1") { continue }

            # Update module import path for agent context
            $content = Get-Content $script.FullName -Raw
            $modifiedContent = $content -replace 'Import-Module "\$PSScriptRoot[/\\]common-audit\.psm1"',
                'Import-Module "$PSScriptRoot\..\..\_lib\common-audit.psm1"'

            $targetPath = Join-Path $targetCat $script.Name
            $modifiedContent | Out-File -FilePath $targetPath -Encoding UTF8 -NoNewline
            $totalCopied++
        }

        Write-Output "[OK] Copied $($scripts.Count) scripts from $($cat.Source)"
    }
}

Write-Output ""
Write-Output "============================"
Write-Output "Sync complete: $totalCopied audit scripts"
Write-Output ""
Write-Output "Available audit categories:"
Get-ChildItem -Path $AgentAuditsDir -Directory | ForEach-Object {
    $count = (Get-ChildItem -Path $_.FullName -Filter "*.ps1" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count
    Write-Output "  - $($_.Name): $count audits"
}
