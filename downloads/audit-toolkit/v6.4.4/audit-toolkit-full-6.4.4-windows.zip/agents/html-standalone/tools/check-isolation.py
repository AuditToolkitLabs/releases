#!/usr/bin/env python3
"""Standalone isolation guard.

Checks that standalone-internal policy modules are not imported from unrelated
main-tool modules. This helps keep future repo extraction low-risk.
"""

from __future__ import annotations

from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[3]

ALLOWED_PREFIXES = (
    "agents/html-standalone/",
    "agents/html_standalone/",
    "deployment/agents/_build/",
    "docs/",
)

WATCHED_IMPORT_PATTERNS = (
    "from web.standalone_policy import",
    "import web.standalone_policy",
    "from agents.html_standalone.web.standalone_policy import",
    "import agents.html_standalone.web.standalone_policy",
)

SCANNED_SUFFIXES = {".py", ".md", ".sh", ".ps1", ".yml", ".yaml"}
SKIP_DIR_NAMES = {".git", "__pycache__", ".venv", "node_modules", "archive"}


def is_allowed_path(rel_path: str) -> bool:
    rel_norm = rel_path.replace("\\", "/")
    return rel_norm.startswith(ALLOWED_PREFIXES)


def main() -> int:
    violations: list[tuple[str, str]] = []

    for path in REPO_ROOT.rglob("*"):
        if path.is_dir():
            if path.name in SKIP_DIR_NAMES:
                continue
            continue

        if path.suffix.lower() not in SCANNED_SUFFIXES:
            continue

        rel = path.relative_to(REPO_ROOT).as_posix()
        if is_allowed_path(rel):
            continue

        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        for pattern in WATCHED_IMPORT_PATTERNS:
            if pattern in content:
                violations.append((rel, pattern))

    if violations:
        print("FAIL: standalone policy import leakage detected:")
        for rel, pattern in violations:
            print(f"  - {rel}: {pattern}")
        return 1

    print("PASS: no standalone policy import leakage detected.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
