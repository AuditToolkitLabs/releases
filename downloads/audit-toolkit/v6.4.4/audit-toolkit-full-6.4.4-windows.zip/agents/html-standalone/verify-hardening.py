#!/usr/bin/env python3
"""
Verification Script for Lightweight Audit Agent Security Hardening

Tests all three phases of security implementation:
- Phase 1: Certificate validation, URL validation, file permissions
- Phase 2: Result encryption, config signing
- Phase 3: Request signing, audit logging
"""

import json
import sys
import ssl
from pathlib import Path
from datetime import datetime

# Color codes for output
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_header(text):
    """Print section header."""
    print(f"\n{BOLD}{BLUE}{'='*70}{RESET}")
    print(f"{BOLD}{BLUE}{text.center(70)}{RESET}")
    print(f"{BOLD}{BLUE}{'='*70}{RESET}\n")

def print_pass(text):
    """Print passing test."""
    print(f"{GREEN}✅ PASS{RESET}: {text}")

def print_fail(text):
    """Print failing test."""
    print(f"{RED}❌ FAIL{RESET}: {text}")

def print_warn(text):
    """Print warning."""
    print(f"{YELLOW}⚠️  WARN{RESET}: {text}")

def print_info(text):
    """Print info message."""
    print(f"{BLUE}ℹ️  INFO{RESET}: {text}")

def test_imports():
    """Test that security module can be imported."""
    print_header("Phase 0: Import Verification")

    try:
        from web.security import (  # noqa: F401 - imports used for verification
            ConfigValidator, FileSecurityManager, ResultsEncryption,
            ConfigSigning, RequestSigning, AuditLogger, setup_security
        )
        print_pass("All security classes imported successfully")
        return True
    except ImportError as e:
        print_fail(f"Failed to import security module: {e}")
        return False

def test_cryptography():
    """Test that cryptography library is available."""
    print_header("Phase 2: Cryptography Library Check")

    try:
        from cryptography.fernet import Fernet  # noqa: F401
        from cryptography.hazmat.primitives import hashes  # noqa: F401
        from cryptography.hazmat.primitives.asymmetric import ec  # noqa: F401
        print_pass("cryptography library is available (Phase 2 enabled)")
        return True
    except ImportError:
        print_warn("cryptography library not installed (Phase 2 disabled)")
        print_info("Install with: pip install cryptography>=41.0.0")
        return False

def test_config_validation():
    """Test Phase 1: Configuration validation."""
    print_header("Phase 1: Configuration Validation")

    from web.security import ConfigValidator

    # Test 1: Valid HTTPS URL
    is_valid, error = ConfigValidator.validate_server_url("https://audit.example.com")
    if is_valid:
        print_pass("Valid HTTPS URL accepted: https://audit.example.com")
    else:
        print_fail(f"Valid URL rejected: {error}")

    # Test 2: HTTP (should fail)
    is_valid, error = ConfigValidator.validate_server_url("http://audit.example.com")
    if not is_valid and "HTTPS" in error:
        print_pass("HTTP URL correctly rejected (HTTPS required)")
    else:
        print_fail("HTTP URL should be rejected")

    # Test 3: Wazuh redirection blocked
    is_valid, error = ConfigValidator.validate_server_url("https://wazuh.internal")
    if not is_valid and "wazuh" in error.lower():
        print_pass("Wazuh redirection correctly blocked")
    else:
        print_fail("Wazuh URL should be blocked")

    # Test 4: Splunk redirection blocked
    is_valid, error = ConfigValidator.validate_server_url("https://splunk.internal")
    if not is_valid and "splunk" in error.lower():
        print_pass("Splunk redirection correctly blocked")
    else:
        print_fail("Splunk URL should be blocked")

def test_file_permissions():
    """Test Phase 1: File permission management."""
    print_header("Phase 1: File Permissions")

    from web.security import FileSecurityManager
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create test file
        test_file = Path(tmpdir) / "test.json"
        test_file.write_text("{}")

        # Test setting permissions
        FileSecurityManager.set_secure_permissions(test_file)

        # Verify permissions
        mode = os.stat(test_file).st_mode & 0o777
        if mode == 0o600:
            print_pass("Config file permissions correctly set to 0o600")
        else:
            print_fail(f"Config file permissions: {oct(mode)}, expected 0o600")

        # Test directory
        test_dir = Path(tmpdir) / "results"
        test_dir.mkdir()
        FileSecurityManager.set_secure_permissions(test_dir)

        mode = os.stat(test_dir).st_mode & 0o777
        if mode == 0o700:
            print_pass("Results directory permissions correctly set to 0o700")
        else:
            print_fail(f"Results directory permissions: {oct(mode)}, expected 0o700")

def test_result_encryption():
    """Test Phase 2: Result encryption."""
    print_header("Phase 2: Result Encryption")

    try:
        from web.security import ResultsEncryption
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            enc = ResultsEncryption(tmpdir)

            if not enc.enabled:
                print_warn("Encryption disabled (cryptography not available)")
                return

            # Test encryption
            test_data = {
                'job_id': 'test_001',
                'output': 'Audit test output with sensitive data',
                'summary': {'passed': 10, 'failed': 0}
            }

            result_file = tmpdir / 'test_result.json'
            success = enc.encrypt_result(test_data, result_file)

            if success:
                print_pass("Result encrypted successfully")
            else:
                print_fail("Failed to encrypt result")
                return

            # Verify file contains marker
            with open(result_file) as f:
                encrypted_json = json.load(f)

            if encrypted_json.get('_encrypted'):
                print_pass("Encrypted file contains '_encrypted' marker")
            else:
                print_fail("Encrypted file missing '_encrypted' marker")

            if 'Audit test output' not in str(encrypted_json):
                print_pass("Plaintext data not visible in encrypted file")
            else:
                print_fail("Plaintext data visible in encrypted file")

            # Test decryption
            decrypted = enc.decrypt_result(result_file)
            if decrypted and decrypted.get('output') == test_data['output']:
                print_pass("Result decrypted successfully")
            else:
                print_fail("Failed to decrypt result correctly")

    except Exception as e:
        print_fail(f"Encryption test error: {e}")

def test_config_signing():
    """Test Phase 2: Configuration signing."""
    print_header("Phase 2: Configuration Signing")

    try:
        from web.security import ConfigSigning
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            signer = ConfigSigning(tmpdir)

            if not signer.enabled:
                print_warn("Config signing disabled (cryptography not available)")
                return

            # Test signing
            test_config = {
                'core_server_url': 'https://audit.example.com',
                'api_key': 'test_key_12345',
                'agent_id': 'test_agent_001'
            }

            signature = signer.sign_config(test_config)
            if signature:
                print_pass("Configuration signed successfully")
            else:
                print_fail("Failed to sign configuration")
                return

            # Add signature and test verification
            test_config['_signature'] = signature
            test_config['_signed_at'] = datetime.now().isoformat()

            is_valid, msg = signer.verify_config(test_config)
            if is_valid:
                print_pass("Configuration signature verified successfully")
            else:
                print_fail(f"Signature verification failed: {msg}")

            # Test tampering detection
            test_config['core_server_url'] = 'https://different.example.com'
            is_valid, msg = signer.verify_config(test_config)
            if not is_valid:
                print_pass("Tampering correctly detected (signature invalid)")
            else:
                print_fail("Tampering not detected")

    except Exception as e:
        print_fail(f"Config signing test error: {e}")

def test_request_signing():
    """Test Phase 3: Request signing."""
    print_header("Phase 3: Request Signing")

    from web.security import RequestSigning

    # Test signature generation
    signature = RequestSigning.generate_signature(
        'POST',
        '/api/agent/results',
        '{"test": "data"}',
        'test_api_key',
        '1234567890'
    )

    if signature and len(signature) == 64:  # SHA256 hex = 64 chars
        print_pass("Request signature generated successfully (64 hex characters)")
    else:
        print_fail(f"Invalid signature format: {signature}")

    # Test signature verification
    is_valid, msg = RequestSigning.verify_signature(
        'POST',
        '/api/agent/results',
        '{"test": "data"}',
        '1234567890',
        signature,
        'test_api_key'
    )

    if is_valid:
        print_pass("Request signature verified successfully")
    else:
        print_fail(f"Signature verification failed: {msg}")

    # Test tampering detection
    is_valid, msg = RequestSigning.verify_signature(
        'POST',
        '/api/agent/results',
        '{"test": "tampered"}',  # Changed payload
        '1234567890',
        signature,
        'test_api_key'
    )

    if not is_valid:
        print_pass("Signature tampering correctly detected")
    else:
        print_fail("Tampering not detected")

    # Test timestamp validation
    old_timestamp = '0'  # Very old
    is_valid, msg = RequestSigning.verify_signature(
        'POST',
        '/api/agent/results',
        '{"test": "data"}',
        old_timestamp,
        signature,
        'test_api_key'
    )

    if not is_valid and "old" in msg.lower():
        print_pass("Old timestamp correctly rejected")
    else:
        print_fail("Old timestamp should be rejected")

def test_audit_logging():
    """Test Phase 3: Audit logging."""
    print_header("Phase 3: Audit Logging")

    from web.security import AuditLogger
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        logger = AuditLogger(tmpdir, use_syslog=False)

        # Test log creation
        logger.log_config_change("TEST_CHANGE", "old_value", "new_value", "test_source")

        log_file = tmpdir / 'audit.log'
        if log_file.exists():
            print_pass("Audit log file created")

            # Verify log contents
            with open(log_file) as f:
                log_content = f.read()

            if 'CONFIG_CHANGE' in log_content and 'TEST_CHANGE' in log_content:
                print_pass("Config change logged correctly")
            else:
                print_fail("Config change not found in log")

            # Verify test source logged
            if 'test_source' in log_content:
                print_pass("Log source tracked correctly")
            else:
                print_fail("Log source not tracked")
        else:
            print_fail("Audit log file not created")

def test_ssl_context():
    """Test Phase 1: SSL context verification."""
    print_header("Phase 1: SSL Context (Certificate Validation)")

    print_info("Testing SSL context for certificate validation requirements...")

    # Create context the way the app does
    ctx = ssl.create_default_context()
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED

    # Verify settings
    if ctx.verify_mode == ssl.CERT_REQUIRED:
        print_pass("SSL verify_mode = CERT_REQUIRED (enforces certificate validation)")
    else:
        print_fail("SSL verify_mode not set to CERT_REQUIRED")

    if ctx.check_hostname:
        print_pass("SSL check_hostname = True (enforces hostname verification)")
    else:
        print_fail("SSL check_hostname not enabled")

def main():
    """Run all verification tests."""
    print(f"\n{BOLD}{BLUE}Lightweight Audit Agent - Security Hardening Verification{RESET}")
    print(f"{BOLD}{BLUE}Time: {datetime.now().isoformat()}{RESET}")

    # Track results
    results = {}

    # Phase 0: Imports
    try:
        results['imports'] = test_imports()
    except Exception as e:
        print_fail(f"Import test error: {e}")
        results['imports'] = False

    if not results['imports']:
        print(f"\n{BOLD}{RED}Cannot proceed without security module.{RESET}")
        return 1

    # Phase 1 tests
    try:
        test_ssl_context()
        test_config_validation()
        test_file_permissions()
        results['phase1'] = True
    except Exception as e:
        print_fail(f"Phase 1 test error: {e}")
        results['phase1'] = False

    # Cryptography check
    crypto_available = test_cryptography()

    # Phase 2 tests (only if cryptography available)
    if crypto_available:
        try:
            test_result_encryption()
            test_config_signing()
            results['phase2'] = True
        except Exception as e:
            print_fail(f"Phase 2 test error: {e}")
            results['phase2'] = False
    else:
        print_warn("Skipping Phase 2 tests (cryptography not available)")
        results['phase2'] = False

    # Phase 3 tests
    try:
        test_request_signing()
        test_audit_logging()
        results['phase3'] = True
    except Exception as e:
        print_fail(f"Phase 3 test error: {e}")
        results['phase3'] = False

    # Summary
    print_header("Verification Summary")

    total_passed = sum(1 for v in results.values() if v)
    total_tests = len(results)

    print(f"Phase 1 (Cert/URL/Permissions):   {'✅ PASS' if results.get('phase1') else '❌ FAIL'}")
    print(f"Phase 2 (Encryption/Signing):     {'✅ PASS' if results.get('phase2') else '⚠️  PARTIAL (needs cryptography)'}")
    print(f"Phase 3 (Request Signing/Audit):  {'✅ PASS' if results.get('phase3') else '❌ FAIL'}")

    print(f"\n{total_passed}/{total_tests} test suites passed\n")

    if all(results.values()):
        print(f"{GREEN}✅ All security hardening phases verified successfully!{RESET}\n")
        return 0
    else:
        print(f"{RED}❌ Some tests failed. Review output above.{RESET}\n")
        return 1

if __name__ == '__main__':
    sys.exit(main())
