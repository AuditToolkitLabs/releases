#!/usr/bin/env python3
"""
Phase B1 & B3 Verification Script
Validates secure cookie configuration and input validation functionality
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from web.app import (
    app, sanitize_input, validate_password, validate_username,
    validate_email, SESSION_TIMEOUT
)


def print_header(title):
    """Print formatted section header"""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")


def verify_b1_secure_cookies():
    """Verify Phase B1: Secure Cookie Configuration"""
    print_header("Phase B1: Secure Cookie Configuration Verification")

    checks = {
        "SESSION_COOKIE_HTTPONLY": app.config.get('SESSION_COOKIE_HTTPONLY') is True,
        "SESSION_COOKIE_SAMESITE": app.config.get('SESSION_COOKIE_SAMESITE') in ['Lax', 'Strict', 'None'],
        "PERMANENT_SESSION_LIFETIME": app.config.get('PERMANENT_SESSION_LIFETIME') > 0,
        "SESSION_REFRESH_EACH_REQUEST": app.config.get('SESSION_REFRESH_EACH_REQUEST') is True,
        "SESSION_COOKIE_NAME": app.config.get('SESSION_COOKIE_NAME') == 'audit_session'
    }

    all_pass = True
    for check_name, result in checks.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {check_name}")
        if not result:
            all_pass = False
            value = app.config.get(check_name)
            print(f"        Current value: {value}")

    print(f"\nConfiguration Details:")
    print(f"  HTTPOnly: {app.config['SESSION_COOKIE_HTTPONLY']}")
    print(f"  Secure: {app.config.get('SESSION_COOKIE_SECURE', 'Not set')}")
    print(f"  SameSite: {app.config['SESSION_COOKIE_SAMESITE']}")
    print(f"  Timeout: {SESSION_TIMEOUT} seconds ({SESSION_TIMEOUT//60} minutes)")
    print(f"  Cookie Name: {app.config['SESSION_COOKIE_NAME']}")

    return all_pass


def verify_b3_input_validation():
    """Verify Phase B3: Input Validation & Sanitization"""
    print_header("Phase B3: Input Validation & Sanitization Verification")

    test_cases = {
        "sanitize_input - removes XSS": (
            lambda: "<script>alert(1)</script>" not in sanitize_input("<script>alert(1)</script>"),
            "HTML script tags should be escaped"
        ),
        "sanitize_input - enforces max_length": (
            lambda: sanitize_input("a" * 2000, max_length=100) == "",
            "Oversized input should return empty string"
        ),
        "sanitize_input - trims whitespace": (
            lambda: sanitize_input("  hello  ") == "hello",
            "Whitespace should be trimmed"
        ),
        "validate_password - accepts valid": (
            lambda: validate_password("SecurePass123")[0] is True,
            "Valid passwords should pass"
        ),
        "validate_password - rejects empty": (
            lambda: validate_password("")[0] is False,
            "Empty password should fail"
        ),
        "validate_password - enforces min length": (
            lambda: validate_password("short")[0] is False,
            "Short passwords should fail"
        ),
        "validate_username - accepts valid": (
            lambda: validate_username("valid_user123")[0] is True,
            "Valid usernames should pass"
        ),
        "validate_username - rejects special chars": (
            lambda: validate_username("user@test")[0] is False,
            "Special characters should be rejected"
        ),
        "validate_username - enforces length": (
            lambda: validate_username("ab")[0] is False,
            "Short usernames should fail"
        ),
        "validate_email - accepts valid": (
            lambda: validate_email("user@example.com")[0] is True,
            "Valid emails should pass"
        ),
        "validate_email - rejects invalid": (
            lambda: validate_email("notanemail")[0] is False,
            "Invalid emails should fail"
        ),
        "sanitize_input - rejects SQL injection": (
            lambda: sanitize_input("admin' OR '1'='1", allowed_chars="a-zA-Z0-9") == "",
            "SQL injection patterns should be rejected"
        ),
    }

    all_pass = True
    passed = 0
    failed = 0

    for test_name, (test_func, description) in test_cases.items():
        try:
            result = test_func()
            if result:
                status = "✅ PASS"
                passed += 1
            else:
                status = "❌ FAIL"
                failed += 1
                all_pass = False

            print(f"{status}: {test_name}")
            print(f"        {description}")
        except Exception as e:
            print(f"❌ ERROR: {test_name}")
            print(f"        Exception: {str(e)}")
            failed += 1
            all_pass = False

    print(f"\nValidation Results:")
    print(f"  Passed: {passed}")
    print(f"  Failed: {failed}")
    print(f"  Total: {passed + failed}")

    return all_pass


def verify_b2_session_config():
    """Verify Phase B2: Session Management Configuration"""
    print_header("Phase B2: Session Management Configuration Verification")

    checks = {
        "Session timeout set": SESSION_TIMEOUT > 0,
        "Reasonable timeout": 300 < SESSION_TIMEOUT < 86400,  # 5min to 24hr
        "Session refresh enabled": app.config.get('SESSION_REFRESH_EACH_REQUEST') is True,
    }

    all_pass = True
    for check_name, result in checks.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {check_name}")
        if not result:
            all_pass = False

    print(f"\nSession Configuration:")
    print(f"  Timeout: {SESSION_TIMEOUT} seconds")
    print(f"  Timeout (minutes): {SESSION_TIMEOUT // 60}")
    print(f"  Timeout (hours): {SESSION_TIMEOUT // 3600}")
    print(f"  Refresh on request: {app.config['SESSION_REFRESH_EACH_REQUEST']}")

    return all_pass


def main():
    """Run all verification checks"""
    print("\n" + "="*70)
    print("  Phase B1 & B3: Secure Cookies & Input Validation Verification")
    print("="*70)

    results = {
        "Phase B1 - Secure Cookies": verify_b1_secure_cookies(),
        "Phase B2 - Session Management": verify_b2_session_config(),
        "Phase B3 - Input Validation": verify_b3_input_validation(),
    }

    # Summary
    print_header("Summary")

    for phase_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {phase_name}")

    all_passed = all(results.values())

    print(f"\n{'='*70}")
    if all_passed:
        print("  ✅ ALL VERIFICATIONS PASSED")
    else:
        print("  ❌ SOME VERIFICATIONS FAILED")
    print(f"{'='*70}\n")

    return 0 if all_passed else 1


if __name__ == '__main__':
    sys.exit(main())
