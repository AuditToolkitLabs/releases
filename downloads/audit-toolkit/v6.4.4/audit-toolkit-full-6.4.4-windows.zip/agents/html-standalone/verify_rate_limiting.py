#!/usr/bin/env python3
"""
Quick Rate Limiting Verification Script

Verifies that rate limiting is properly configured and working
by testing the Flask app directly.
"""

import sys
from pathlib import Path

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

from web.app import app


def verify_rate_limiting():
    """Verify rate limiting is properly configured."""
    print("=" * 70)
    print("Rate Limiting Verification (Phase A3)")
    print("=" * 70)

    with app.test_client() as client:
        passed = 0
        failed = 0

        # Test 1: Health endpoint works (no rate limit)
        print("\n[*] Testing health endpoint for rate limiting...")
        health_responses = 0
        for i in range(20):
            response = client.get('/health')
            if response.status_code == 200:
                health_responses += 1
        if health_responses == 20:
            print("    ✅ Health endpoint not rate limited (20/20 succeeded)")
            passed += 1
        else:
            print(f"    ❌ Health endpoint responses inconsistent ({health_responses}/20)")
            failed += 1

        # Test 2: System info endpoint works (no rate limit)
        print("\n[*] Testing system-info endpoint for rate limiting...")
        system_responses = 0
        for i in range(20):
            response = client.get('/api/system-info')
            if response.status_code == 200:
                system_responses += 1
        if system_responses >= 15:  # May have some auth issues
            print(f"    ✅ System-info endpoint not heavily rate limited ({system_responses}/20)")
            passed += 1
        else:
            print(f"    ⚠️  System-info endpoint had issues ({system_responses}/20)")

        # Test 3: Rate limit error handler exists
        print("\n[*] Checking for rate limit error handler...")
        if 429 in app.error_handler_spec.get(None, {}):
            print("    ✅ Rate limit error handler (429) is registered")
            passed += 1
        else:
            print("    ❌ Rate limit error handler not registered")
            failed += 1

        # Test 4: Limiter is initialized
        print("\n[*] Checking rate limiter initialization...")
        if hasattr(app, 'limiter'):
            print("    ✅ Rate limiter is initialized on Flask app")
            passed += 1
        else:
            print("    ❌ Rate limiter not found on Flask app")
            failed += 1

        # Test 5: Configuration endpoints have rate limits
        print("\n[*] Checking for rate limit decorators on endpoints...")
        import os
        limits = {
            'LOGIN_RATE_LIMIT': os.environ.get('LOGIN_RATE_LIMIT', '5/minute'),
            'AUDIT_RATE_LIMIT': os.environ.get('AUDIT_RATE_LIMIT', '10/minute'),
            'CONFIG_RATE_LIMIT': os.environ.get('CONFIG_RATE_LIMIT', '30/minute'),
        }
        all_valid = True
        for name, limit in limits.items():
            parts = limit.split('/')
            if len(parts) != 2 or not parts[0].isdigit():
                print(f"    ❌ Invalid {name}: {limit}")
                all_valid = False
        if all_valid:
            print("    ✅ Rate limit configurations are valid")
            passed += 1
        else:
            print("    ❌ Some rate limit configurations are invalid")
            failed += 1

        # Test 6: Response headers
        print("\n[*] Checking response headers...")
        response = client.get('/health')
        headers = dict(response.headers)
        if 'Content-Type' in headers:
            print("    ✅ Response headers are present")
            passed += 1
        else:
            print("    ❌ Response headers missing")
            failed += 1

        # Summary
        print("\n" + "=" * 70)
        print(f"Summary: {passed} passed, {failed} failed")
        print("=" * 70)

        if failed == 0:
            print("\n✅ Rate Limiting is properly configured!\n")
            return 0
        else:
            print(f"\n⚠️  {failed} issues found. Review the log above.\n")
            return 1


if __name__ == '__main__':
    sys.exit(verify_rate_limiting())
