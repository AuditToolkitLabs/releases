#!/usr/bin/env python3
"""
Quick verification script for HTTP Security Headers (Phase A1)

This script can be run locally to verify security headers are present:
    python verify_security_headers.py
"""

import sys
from pathlib import Path

# Add path for imports
sys.path.insert(0, str(Path(__file__).parent / 'agents' / 'html-standalone'))

def verify_headers():
    """Verify security headers are set in the Flask app."""
    try:
        from web.app import app

        print("=" * 70)
        print("HTTP Security Headers Verification (Phase A1)")
        print("=" * 70)
        print()

        # Create test client
        with app.test_client() as client:
            # Test GET request to root
            response = client.get('/')

            print(f"Response Status: {response.status_code}")
            print()
            print("Security Headers Found:")
            print("-" * 70)

            # Define expected headers
            expected_headers = [
                ('X-Frame-Options', 'DENY'),
                ('X-Content-Type-Options', 'nosniff'),
                ('X-XSS-Protection', '1; mode=block'),
                ('Referrer-Policy', 'strict-origin-when-cross-origin'),
                ('Permissions-Policy', None),  # Just check presence
                ('Content-Security-Policy', None),  # Just check presence
            ]

            passed = 0
            failed = 0

            for header_name, expected_value in expected_headers:
                value = response.headers.get(header_name)
                if value:
                    if expected_value:
                        if value == expected_value:
                            print(f"✅ {header_name}: {value}")
                            passed += 1
                        else:
                            print(f"⚠️  {header_name}: {value}")
                            print(f"   (expected: {expected_value})")
                            passed += 1
                    else:
                        # Just check if present
                        print(f"✅ {header_name}: {value[:60]}{'...' if len(value) > 60 else ''}")
                        passed += 1
                else:
                    print(f"❌ {header_name}: MISSING")
                    failed += 1

            print()
            print("-" * 70)
            print(f"Summary: {passed} passed, {failed} failed")
            print()

            if failed == 0:
                print("✅ All security headers are present and configured!")
                print()
                print("Environment variables for customization:")
                print("  CSP_POLICY           - Override default Content-Security-Policy")
                print("  X_FRAME_OPTIONS      - Override X-Frame-Options (default: DENY)")
                print("  HSTS_MAX_AGE         - Override HSTS max-age (default: 31536000)")
                print("  ENFORCE_HSTS         - Force HSTS on local-only (default: false)")
                print()
                return 0
            else:
                print(f"❌ {failed} security header(s) missing!")
                return 1

    except Exception as e:
        print(f"❌ Error verifying headers: {e}")
        import traceback
        traceback.print_exc()
        return 2

if __name__ == '__main__':
    sys.exit(verify_headers())
