"""
Standalone Security Audit Toolkit - Web Interface
A minimal Flask application for running security audits via web browser.

Features:
- Run audits individually or by category
- Setup wizard for configuration
- Core server integration for result export
- Schedule management via cron/systemd
- Optional authentication for remote access
- Cross-platform support (Linux/Windows)
- Tiered licensing (Community, Starter, Business, Professional)
"""

import os
import json
import hashlib
import hmac
import base64
import subprocess
import threading
import time
import urllib.request
import urllib.error
import ssl
import secrets
import logging
import shutil
import ipaddress
from functools import wraps
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, jsonify, request, send_file, redirect, url_for, session
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Import platform utilities
from web.platform_utils import (
    is_windows,
    get_os_info, get_system_uptime,
    is_container, get_deployment_type
)

# Import licensing module
from web.licensing import (
    LicenseManager, ScriptUpdateManager,
    TIER_COMMUNITY, TIER_STARTER, TIER_BUSINESS, TIER_PROFESSIONAL,
    COMMUNITY_AUDIT_CATEGORIES,
    STARTER_AUDIT_CATEGORIES,
    BUSINESS_AUDIT_CATEGORIES,
    PROFESSIONAL_AUDIT_CATEGORIES,
    detect_host_distro, get_distro_specific_categories
)

from web.standalone_policy import (
    resolve_standalone_defaults,
    get_script_glob,
    is_category_allowed_for_standalone,
    get_required_tier_for_category,
    resolve_requested_audit_path,
    extract_audit_category,
    is_script_allowed_for_standalone,
    script_stem,
)

# Import security module (PHASE 1, 2, 3 hardening)
from web.security import (
    FileSecurityManager,
    RequestSigning, setup_security
)

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    ECDSA_CRYPTO_AVAILABLE = True
except Exception:
    ECDSA_CRYPTO_AVAILABLE = False

app = Flask(__name__)

# Secret key for sessions (generate random if not provided)
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# ============================================================================
# Phase B1: Secure Cookie Configuration
# ============================================================================
# Configure secure session cookie parameters to protect against session hijacking

# Session timeout in seconds (default: 1 hour)
SESSION_TIMEOUT_MINUTES = int(os.environ.get('SESSION_TIMEOUT_MINUTES', '60'))
SESSION_TIMEOUT = SESSION_TIMEOUT_MINUTES * 60

# Secure cookie configuration
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'true').lower() in ('true', '1', 'yes')
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Prevent JavaScript access (blocks XSS attacks)
app.config['SESSION_COOKIE_SAMESITE'] = os.environ.get('SESSION_COOKIE_SAMESITE', 'Lax')  # CSRF protection
app.config['PERMANENT_SESSION_LIFETIME'] = SESSION_TIMEOUT  # Session expiration timeout
app.config['SESSION_REFRESH_EACH_REQUEST'] = True  # Refresh session timeout on each request
app.config['SESSION_COOKIE_NAME'] = os.environ.get('SESSION_COOKIE_NAME', 'audit_session')  # Custom cookie name

# Initialize CSRF protection (Phase A2)
csrf = CSRFProtect(app)

# Initialize rate limiting (Phase A3)
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=[os.environ.get('RATE_LIMIT', '100/hour')],
    storage_uri="memory://",
    in_memory_fallback_enabled=True
)
app.limiter = limiter

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Log session security configuration (Phase B1)
logger.info(f"Session security configured: HTTPOnly=True, Secure={app.config['SESSION_COOKIE_SECURE']}, "
           f"SameSite={app.config['SESSION_COOKIE_SAMESITE']}, Timeout={SESSION_TIMEOUT}s")

# ============================================================================
# Phase B3: Input Validation & Sanitization Utilities
# ============================================================================
# Provide safe input validation functions to prevent injection attacks

import re
from html import escape as html_escape

def sanitize_input(value, allowed_chars=None, max_length=1000):
    """
    Sanitize user input to prevent injection attacks.

    Args:
        value: Input string to sanitize
        allowed_chars: Regex pattern of allowed characters (None = alphanumeric + common)
        max_length: Maximum allowed length

    Returns:
        Sanitized string or empty string if invalid
    """
    if not isinstance(value, str):
        return ""

    # Enforce max length
    if len(value) > max_length:
        return ""

    # Remove common inline event handler and javascript URI patterns
    value = re.sub(r'(?i)on[a-z]+\s*=', '', value)
    value = re.sub(r'(?i)javascript\s*:', '', value)

    # HTML escape dangerous characters
    value = html_escape(value, quote=True)

    # If specific characters allowed, validate against pattern
    if allowed_chars:
        if not re.match(f"^[{allowed_chars}]*$", value):
            return ""

    return value.strip()


def validate_password(password, min_length=8, max_length=128, require_special=False):
    """
    Validate password meets security requirements.

    Args:
        password: Password string to validate
        min_length: Minimum length required
        max_length: Maximum length allowed
        require_special: Require special characters

    Returns:
        Tuple (is_valid, error_message)
    """
    if not password or not isinstance(password, str):
        return False, "Password required"

    if len(password) < min_length:
        return False, f"Password must be at least {min_length} characters"

    if len(password) > max_length:
        return False, f"Password must not exceed {max_length} characters"

    if require_special:
        if not re.search(r'[!@#$%^&*()_+\-=\[\]{};:,.<>?]', password):
            return False, "Password must contain special characters"

    return True, ""


def validate_username(username, min_length=3, max_length=50):
    """
    Validate username format.

    Args:
        username: Username string to validate
        min_length: Minimum length
        max_length: Maximum length

    Returns:
        Tuple (is_valid, error_message)
    """
    if not username or not isinstance(username, str):
        return False, "Username required"

    if len(username) < min_length or len(username) > max_length:
        return False, f"Username must be {min_length}-{max_length} characters"

    # Allow alphanumeric, underscore, hyphen only
    if not re.match(r'^[a-zA-Z0-9_-]+$', username):
        return False, "Username can only contain letters, numbers, underscore, and hyphen"

    return True, ""


def validate_email(email):
    """
    Validate email format (basic).

    Args:
        email: Email string to validate

    Returns:
        Tuple (is_valid, error_message)
    """
    if not email or not isinstance(email, str):
        return False, "Email required"

    # Basic email validation
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(email_pattern, email):
        return False, "Invalid email format"

    return True, ""


def safe_json_loads(json_str, default=None):
    """
    Safely parse JSON with error handling.

    Args:
        json_str: JSON string to parse
        default: Default value if parsing fails

    Returns:
        Parsed JSON or default value
    """
    try:
        return json.loads(json_str)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default


# ============================================================================
# Security Initialization (Phase 1, 2, 3)
# ============================================================================
# Initialize security components early - these enforce protections

# Platform detection
PLATFORM = 'windows' if is_windows() else 'linux'

_standalone_defaults = resolve_standalone_defaults(Path(__file__).resolve(), is_windows())
_default_app_dir = _standalone_defaults['default_app_dir']
_default_audit_dir = _standalone_defaults['default_audit_dir']
_default_agent = _standalone_defaults['default_agent']
STANDALONE_MODE = _standalone_defaults['standalone_mode']

APP_DIR = Path(os.environ.get('APP_DIR', str(_default_app_dir)))
AUDIT_DIR = os.environ.get('AUDIT_DIR', _default_audit_dir)
RESULTS_DIR = os.environ.get('AUDIT_RESULTS_DIR', str(APP_DIR / 'results'))
CONFIG_DIR = Path(os.environ.get('CONFIG_DIR', str(APP_DIR / 'config')))
LOGS_DIR = Path(os.environ.get('LOGS_DIR', str(APP_DIR / 'logs')))
ORCHESTRATOR_PATH = os.environ.get('ORCHESTRATOR_PATH', str(APP_DIR / 'orchestrator' / 'orchestrator.sh'))
AGENT_PATH = os.environ.get('AGENT_PATH', _default_agent)


def resolve_agent_version() -> str:
    """Resolve agent version from environment or VERSION file."""
    env_version = os.environ.get('AGENT_VERSION', '').strip()
    if env_version:
        return env_version

    possible_version_files = [
        APP_DIR / 'VERSION',
        APP_DIR.parent / 'VERSION',
        Path(__file__).resolve().parents[2] / 'VERSION',
    ]

    for version_file in possible_version_files:
        try:
            if version_file.exists():
                version = version_file.read_text(encoding='utf-8').strip()
                if version:
                    return version
        except Exception:
            continue

    return '6.2.1'


AGENT_VERSION = resolve_agent_version()

# Default port (avoiding 8080/5000 used by core tool)
DEFAULT_PORT = 8088

# Standalone access policy: local-only by default
LOCAL_ONLY_MODE = os.environ.get('LOCAL_ONLY_MODE', 'true').lower() in ('true', '1', 'yes')
ALLOW_REMOTE_UI = os.environ.get('ALLOW_REMOTE_UI', 'false').lower() in ('true', '1', 'yes')
DEFAULT_BIND_HOST = os.environ.get('BIND_HOST', '127.0.0.1')
# Scoped toggle for this html-standalone agent only.
ALLOW_MANUAL_EXECUTION = os.environ.get('HTML_STANDALONE_ALLOW_MANUAL_EXECUTION', 'false').lower() in ('true', '1', 'yes')
MANAGED_AGENT_SETUP_ONLY = not ALLOW_MANUAL_EXECUTION

# Ensure directories exist
Path(RESULTS_DIR).mkdir(parents=True, exist_ok=True)
CONFIG_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# Initialize security context (Phase 1, 2, 3 hardening)
# This must happen AFTER directory creation but BEFORE config loading
security_ctx = setup_security(APP_DIR, CONFIG_DIR, Path(RESULTS_DIR), LOGS_DIR)
config_validator = security_ctx.get('config_validator')
audit_logger = security_ctx.get('audit_logger')
results_encryption = security_ctx.get('results_encryption')
config_signing = security_ctx.get('config_signing')

logger.info("Security initialization complete - Phase 1, 2, 3 active")


def _is_loopback_address(addr: str) -> bool:
    """Return True if addr is loopback/localhost."""
    if not addr:
        return False

    if addr in ('127.0.0.1', '::1', 'localhost'):
        return True

    try:
        return ipaddress.ip_address(addr).is_loopback
    except ValueError:
        return False


@app.before_request
def enforce_local_only_access():
    """Block non-local inbound requests when LOCAL_ONLY_MODE is enabled."""
    if not LOCAL_ONLY_MODE:
        return None

    remote_addr = request.remote_addr
    if _is_loopback_address(remote_addr):
        return None

    if ALLOW_REMOTE_UI and not request.path.startswith('/api/'):
        return None

    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Local access only'}), 403

    return "Local access only", 403


# ============================================================================
# Security Headers Middleware (Phase 1 Enhancement)
# ============================================================================

@app.after_request
def set_security_headers(response):
    """Set HTTP security headers on all responses (Phase 1 Enhancement)."""

    # Prevent clickjacking - don't allow embedding in iframes
    response.headers['X-Frame-Options'] = os.environ.get('X_FRAME_OPTIONS', 'DENY')

    # Prevent MIME type sniffing - force declared content type
    response.headers['X-Content-Type-Options'] = 'nosniff'

    # Enable browser XSS protection (legacy, but still useful)
    response.headers['X-XSS-Protection'] = '1; mode=block'

    # Control referrer information sent to external sites
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'

    # Disable dangerous APIs
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'

    # Content Security Policy - restrict script/style sources
    if LOCAL_ONLY_MODE:
        # Permissive CSP for local-only (allows Bootstrap CDN and inline styles)
        csp = os.environ.get('CSP_POLICY',
            "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net data:; img-src 'self' data:")
    else:
        # Strict CSP for remote access (allows Bootstrap CDN but no inline scripts)
        csp = os.environ.get('CSP_POLICY',
            "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net data:; img-src 'self' data:")

    response.headers['Content-Security-Policy'] = csp

    # HSTS - enforce HTTPS
    # Only set if not local-only (localhost doesn't support HSTS effectively)
    if not LOCAL_ONLY_MODE or os.environ.get('ENFORCE_HSTS') == 'true':
        hsts_max_age = os.environ.get('HSTS_MAX_AGE', '31536000')  # 1 year
        response.headers['Strict-Transport-Security'] = f'max-age={hsts_max_age}; includeSubDomains'

    return response

# Configuration file path
CONFIG_FILE = CONFIG_DIR / 'agent-config.json'
SCHEDULE_FILE = CONFIG_DIR / 'schedules.json'

# Environment variable overrides for headless configuration
# These can be set during deployment to pre-configure the agent
ENV_CORE_SERVER_URL = os.environ.get('CORE_SERVER_URL', '')
ENV_API_KEY = os.environ.get('API_KEY', '')
ENV_AGENT_ID = os.environ.get('AGENT_ID', '')
ENV_AUTO_EXPORT = os.environ.get('AUTO_EXPORT', 'false').lower() in ('true', '1', 'yes')
ENV_EXPORT_ON_COMPLETE = os.environ.get('EXPORT_ON_COMPLETE', 'true').lower() in ('true', '1', 'yes')
ENV_MANAGED_REQUIRE_HTTPS = os.environ.get('AUDIT_MANAGED_REQUIRE_HTTPS', 'true').lower() in ('true', '1', 'yes')
ENV_MANAGED_ALLOW_PRIVATE_HOSTS = os.environ.get('AUDIT_MANAGED_ALLOW_PRIVATE_HOSTS', 'true').lower() in ('true', '1', 'yes')
ENV_MANAGED_ALLOWED_SERVER_DOMAINS = os.environ.get('AUDIT_MANAGED_ALLOWED_SERVER_DOMAINS', '')
ENV_MANAGED_BLOCKED_SERVER_KEYWORDS = os.environ.get(
    'AUDIT_MANAGED_BLOCKED_SERVER_KEYWORDS',
    'wazuh,splunk,elastic,datadog,newrelic'
)
ENV_MANAGED_ENFORCE_SIGNED_CONFIG = os.environ.get('AUDIT_MANAGED_ENFORCE_SIGNED_CONFIG', 'true').lower() in ('true', '1', 'yes')
ENV_MANAGED_CONFIG_SIGNING_KEY = os.environ.get('AUDIT_MANAGED_CONFIG_SIGNING_KEY', '')
ENV_MANAGED_CONFIG_SIGNING_USE_ECDSA = os.environ.get('AUDIT_MANAGED_CONFIG_SIGNING_USE_ECDSA', 'false').lower() in ('true', '1', 'yes')
ENV_MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY = os.environ.get('AUDIT_MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY', '')
ENV_MANAGED_CONFIG_MAX_AGE_SECONDS = int(os.environ.get('AUDIT_MANAGED_CONFIG_MAX_AGE_SECONDS', '900'))
ENV_MANAGED_REQUIRE_REQUEST_SIGNATURES = os.environ.get('AUDIT_MANAGED_REQUIRE_REQUEST_SIGNATURES', 'false').lower() in ('true', '1', 'yes')
ENV_MANAGED_REQUEST_SIGNING_KEY = os.environ.get('AUDIT_MANAGED_REQUEST_SIGNING_KEY', '')
ENV_MANAGED_REQUEST_SIGNATURE_MAX_AGE_SECONDS = int(os.environ.get('AUDIT_MANAGED_REQUEST_SIGNATURE_MAX_AGE_SECONDS', '300'))
ENV_MANAGED_REQUEST_SIGNATURE_USE_ECDSA = os.environ.get('AUDIT_MANAGED_REQUEST_SIGNATURE_USE_ECDSA', 'false').lower() in ('true', '1', 'yes')
ENV_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY = os.environ.get('AUDIT_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY', '')
ENV_DISCOVERY_REQUIRE_API_KEY = os.environ.get('AUDIT_DISCOVERY_REQUIRE_API_KEY', 'true').lower() in ('true', '1', 'yes')
ENV_DISCOVERY_REQUIRE_REQUEST_SIGNATURES = os.environ.get('AUDIT_DISCOVERY_REQUIRE_REQUEST_SIGNATURES', 'true').lower() in ('true', '1', 'yes')
ENV_DISCOVERY_REQUEST_SIGNING_KEY = os.environ.get('AUDIT_DISCOVERY_REQUEST_SIGNING_KEY', '')
ENV_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS = int(os.environ.get('AUDIT_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS', '300'))
ENV_DISCOVERY_REQUIRE_NONCE = os.environ.get('AUDIT_DISCOVERY_REQUIRE_NONCE', 'true').lower() in ('true', '1', 'yes')
ENV_AGENT_POLL_INTERVAL = int(os.environ.get('AUDIT_POLL_INTERVAL', '60'))
ENV_AGENT_HEARTBEAT_TIMEOUT = int(os.environ.get('AUDIT_HEARTBEAT_TIMEOUT', '30'))
ENV_AGENT_MAX_HEARTBEAT_FAILURES = int(os.environ.get('AUDIT_MAX_HEARTBEAT_FAILURES', '3'))
ENV_AGENT_CPU_NICE = int(os.environ.get('AUDIT_CPU_NICE', '19'))
ENV_AGENT_MIN_FREE_MEMORY_PCT = int(os.environ.get('AUDIT_MIN_FREE_MEMORY_PCT', '10'))
ENV_AGENT_MAX_CPU_PCT = int(os.environ.get('AUDIT_MAX_CPU_PCT', '0'))
ENV_AGENT_BATCH_DELAY_SECONDS = int(os.environ.get('AUDIT_AGENT_BATCH_DELAY', '5'))
ENV_AGENT_AUTO_DISCOVERY = os.environ.get('AUDIT_AUTO_DISCOVERY', 'true').lower() in ('true', '1', 'yes')
ENV_AGENT_DISCOVERY_INTERVAL = int(os.environ.get('AUDIT_DISCOVERY_INTERVAL', '3600'))
ENV_AGENT_USE_SUDO = os.environ.get('AUDIT_USE_SUDO', 'false').lower() in ('true', '1', 'yes')
ENV_AGENT_ENVIRONMENT = os.environ.get('AUDIT_ENVIRONMENT', 'production')
ENV_AGENT_ALLOW_INSECURE_TLS_IN_NONPROD = os.environ.get('AUDIT_ALLOW_INSECURE_TLS_IN_NONPROD', 'false').lower() in ('true', '1', 'yes')
ENV_AGENT_MAX_LOCAL_RESULT_FILES = int(os.environ.get('AUDIT_AGENT_MAX_LOCAL_RESULT_FILES', '1000'))
ENV_AGENT_MIN_FREE_DISK_MB = int(os.environ.get('AUDIT_MIN_FREE_DISK_MB', '512'))
ENV_AGENT_MIN_FREE_DISK_PCT = int(os.environ.get('AUDIT_MIN_FREE_DISK_PCT', '3'))

# Authentication configuration
AUTH_ENABLED = os.environ.get('AUTH_ENABLED', 'false').lower() in ('true', '1', 'yes')
AUTH_PASSWORD = os.environ.get('AUTH_PASSWORD', '')
AUTH_USERNAME = os.environ.get('AUTH_USERNAME', 'admin')  # Default username
ENV_AUTH_PASSWORD_HINT = os.environ.get('AUTH_PASSWORD_HINT', '').strip()
AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN = os.environ.get('AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN', 'true').lower() in ('true', '1', 'yes')
AUTH_MIN_PASSWORD_LENGTH = int(os.environ.get('AUTH_MIN_PASSWORD_LENGTH', '12'))
AUTH_REQUIRE_SPECIAL_ON_CHANGE = os.environ.get('AUTH_REQUIRE_SPECIAL_ON_CHANGE', 'true').lower() in ('true', '1', 'yes')

# In-memory job tracking
running_jobs = {}
_discovery_nonce_cache = {}
_discovery_nonce_cache_lock = threading.Lock()

# ============================================================================
# License Management
# ============================================================================

def get_core_server_config() -> dict:
    """
    Get Core Server configuration for license delegation.

    Returns core_server_url and api_key from the agent's config file.
    This is used by LicenseManager to request delegated licenses.

    Checks multiple possible config file locations for flexibility.
    """
    # Check possible config file locations
    possible_configs = [
        CONFIG_DIR / 'agent-config.json',   # Main agent config (preferred)
        CONFIG_DIR / 'config.json',          # Legacy config
        APP_DIR / 'agent.config.json',       # Deployment package config
    ]

    for config_file in possible_configs:
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    # Check if license delegation is enabled
                    if not config.get('enable_license_delegation', True):
                        return {}
                    return {
                        'core_server_url': config.get('core_server_url') or config.get('server_url'),
                        'api_key': config.get('api_key'),
                        'license_refresh_hours': config.get('license_refresh_hours', 1),
                    }
            except Exception:
                pass
    return {}


# Initialize license and script update managers
# Pass the core config getter so LicenseManager can request delegated licenses
license_manager = LicenseManager(CONFIG_DIR, get_core_config=get_core_server_config)
script_update_manager = ScriptUpdateManager(CONFIG_DIR, APP_DIR, license_manager)


def get_license_status():
    """Get current license status for templates."""
    return license_manager.get_license_status()


def is_category_allowed(category: str) -> bool:
    """Check if an audit category is allowed for current license tier."""
    return license_manager.is_audit_category_allowed(category)


@app.context_processor
def inject_license_status():
    """Make license status available to all templates."""
    auth_state = _resolve_auth_state()
    return {
        'license_status': get_license_status(),
        'is_community': license_manager.get_tier() == TIER_COMMUNITY,
        'host_distro': detect_host_distro(),
        'distro_categories': get_distro_specific_categories(),
        'agent_version': AGENT_VERSION,
        'auth_username': auth_state.get('username', AUTH_USERNAME),
        'password_change_required': bool(
            session.get('must_change_password', False) or auth_state.get('password_change_required', False)
        ),
        'managed_agent_setup_only': MANAGED_AGENT_SETUP_ONLY,
    }


def _managed_mode_blocked_response(feature_name: str):
    """Return a consistent response for features disabled in managed setup-only mode."""
    message = f'{feature_name} is disabled in managed setup-only mode. Trigger audits from the main tool.'
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': message}), 403
    return redirect(url_for('setup_wizard'))


# ============================================================================
# Authentication
# ============================================================================

def login_required(f):
    """Decorator to require authentication for routes when AUTH_ENABLED is True."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if AUTH_ENABLED:
            if not session.get('authenticated'):
                # For API endpoints, return 401
                if request.path.startswith('/api/'):
                    return jsonify({'error': 'Authentication required'}), 401
                # For web pages, redirect to login
                return redirect(url_for('login', next=request.url))

            auth_state = _resolve_auth_state()
            must_change_password = bool(
                session.get('must_change_password', False) or auth_state.get('password_change_required', False)
            )
            if must_change_password:
                allowed_endpoints = {'change_password', 'api_auth_status', 'logout', 'login', 'static'}
                if request.path.startswith('/api/'):
                    return jsonify({
                        'error': 'Password change required before running audits',
                        'password_change_required': True,
                    }), 403
                if request.endpoint not in allowed_endpoints:
                    return redirect(url_for('change_password'))
        return f(*args, **kwargs)
    return decorated_function


def verify_password(password, expected_password):
    """Verify the provided password against a configured password value."""
    if not expected_password:
        return False
    # Use constant-time comparison to prevent timing attacks
    return secrets.compare_digest(password.encode(), expected_password.encode())


def _resolve_auth_state() -> dict:
    """Resolve effective auth settings from environment + local config."""
    config = load_config()

    username = str(config.get('auth_username') or AUTH_USERNAME or 'admin').strip() or 'admin'
    password_value = str(config.get('auth_password_override') or AUTH_PASSWORD or '')
    password_hint = str(config.get('auth_password_hint') or ENV_AUTH_PASSWORD_HINT or '').strip()

    password_change_required = bool(
        config.get('auth_password_change_required', AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN)
    )
    if not AUTH_ENABLED or not password_value:
        password_change_required = False

    return {
        'username': username,
        'password': password_value,
        'password_hint': password_hint,
        'password_change_required': password_change_required,
    }


def _validate_discovery_endpoint_auth(config: dict):
    """Validate API key + request signature headers for discovery endpoints."""
    require_api_key = bool(config.get('discovery_require_api_key', ENV_DISCOVERY_REQUIRE_API_KEY))
    require_signatures = bool(config.get('discovery_require_request_signatures', ENV_DISCOVERY_REQUIRE_REQUEST_SIGNATURES))
    require_nonce = bool(config.get('discovery_require_nonce', ENV_DISCOVERY_REQUIRE_NONCE))
    max_age_seconds = int(config.get('discovery_request_signature_max_age_seconds', ENV_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS))

    expected_api_key = str(config.get('api_key') or ENV_API_KEY or '').strip()

    if require_api_key:
        if not expected_api_key:
            return jsonify({'error': 'Discovery API key not configured on agent'}), 503
        provided_api_key = str(request.headers.get('X-API-Key', '') or '').strip()
        if not provided_api_key or not hmac.compare_digest(provided_api_key, expected_api_key):
            return jsonify({'error': 'Invalid API key'}), 401

    if not require_signatures:
        return None

    signing_key = str(config.get('discovery_request_signing_key') or ENV_DISCOVERY_REQUEST_SIGNING_KEY or expected_api_key).strip()
    if not signing_key:
        return jsonify({'error': 'Discovery request signing key not configured on agent'}), 503

    timestamp = str(request.headers.get('X-Agent-Timestamp', '') or '').strip()
    signature = str(request.headers.get('X-Agent-Signature', '') or '').strip()
    content_sha256 = str(request.headers.get('X-Agent-Content-SHA256', '') or '').strip().lower()
    nonce = str(request.headers.get('X-Agent-Nonce', '') or '').strip()

    if not timestamp or not signature or not content_sha256:
        return jsonify({'error': 'Missing request signature headers'}), 401
    if require_nonce and not nonce:
        return jsonify({'error': 'Missing X-Agent-Nonce header'}), 401

    body_raw = request.get_data(cache=True) or b''
    expected_content_hash = hashlib.sha256(body_raw).hexdigest()
    if not hmac.compare_digest(content_sha256, expected_content_hash):
        return jsonify({'error': 'Invalid request content hash'}), 401

    try:
        request_time = int(timestamp)
    except ValueError:
        return jsonify({'error': 'Invalid X-Agent-Timestamp header'}), 401

    current_time = int(time.time())
    if abs(current_time - request_time) > max_age_seconds:
        return jsonify({'error': 'Request signature timestamp expired'}), 401

    if nonce:
        cache_key = f"{timestamp}:{nonce}"
        expiry = current_time + max_age_seconds
        with _discovery_nonce_cache_lock:
            expired_keys = [k for k, v in _discovery_nonce_cache.items() if v < current_time]
            for key in expired_keys:
                _discovery_nonce_cache.pop(key, None)
            if cache_key in _discovery_nonce_cache:
                return jsonify({'error': 'Replay detected'}), 401
            _discovery_nonce_cache[cache_key] = expiry

    signature_message = "\n".join([
        timestamp,
        str(request.method or 'GET').upper(),
        str(request.path or '/'),
        content_sha256,
        nonce,
    ]).encode('utf-8')
    expected_signature = hmac.new(
        signing_key.encode('utf-8'),
        signature_message,
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(signature, expected_signature):
        return jsonify({'error': 'Invalid request signature'}), 401

    return None


# ============================================================================
# Configuration Management
# ============================================================================

def load_config():
    """Load agent configuration with signature verification (Phase 3).

    Priority order:
    1. Existing config file (with signature validation)
    2. Environment variables (for headless deployment)
    3. Defaults
    """
    default_config = {
        'core_server_url': ENV_CORE_SERVER_URL or '',
        'api_key': ENV_API_KEY or '',
        'discovery_require_api_key': ENV_DISCOVERY_REQUIRE_API_KEY,
        'discovery_require_request_signatures': ENV_DISCOVERY_REQUIRE_REQUEST_SIGNATURES,
        'discovery_request_signing_key': ENV_DISCOVERY_REQUEST_SIGNING_KEY,
        'discovery_request_signature_max_age_seconds': ENV_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS,
        'discovery_require_nonce': ENV_DISCOVERY_REQUIRE_NONCE,
        'agent_id': ENV_AGENT_ID or '',
        'auto_export': ENV_AUTO_EXPORT,
        'export_on_complete': ENV_EXPORT_ON_COMPLETE,
        'keep_local_results': True,
        'max_local_result_files': ENV_AGENT_MAX_LOCAL_RESULT_FILES,
        'managed_require_https': ENV_MANAGED_REQUIRE_HTTPS,
        'managed_allow_private_hosts': ENV_MANAGED_ALLOW_PRIVATE_HOSTS,
        'managed_allowed_server_domains': ENV_MANAGED_ALLOWED_SERVER_DOMAINS,
        'managed_blocked_server_keywords': ENV_MANAGED_BLOCKED_SERVER_KEYWORDS,
        'managed_enforce_signed_config': ENV_MANAGED_ENFORCE_SIGNED_CONFIG,
        'managed_config_signing_key': ENV_MANAGED_CONFIG_SIGNING_KEY,
        'managed_config_signing_use_ecdsa': ENV_MANAGED_CONFIG_SIGNING_USE_ECDSA,
        'managed_config_signing_ecdsa_public_key': ENV_MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY,
        'managed_config_max_age_seconds': ENV_MANAGED_CONFIG_MAX_AGE_SECONDS,
        'managed_require_request_signatures': ENV_MANAGED_REQUIRE_REQUEST_SIGNATURES,
        'managed_request_signing_key': ENV_MANAGED_REQUEST_SIGNING_KEY,
        'managed_request_signature_max_age_seconds': ENV_MANAGED_REQUEST_SIGNATURE_MAX_AGE_SECONDS,
        'managed_request_signature_use_ecdsa': ENV_MANAGED_REQUEST_SIGNATURE_USE_ECDSA,
        'managed_request_signature_ecdsa_private_key': ENV_MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY,
        'agent_poll_interval': ENV_AGENT_POLL_INTERVAL,
        'agent_heartbeat_timeout': ENV_AGENT_HEARTBEAT_TIMEOUT,
        'agent_max_heartbeat_failures': ENV_AGENT_MAX_HEARTBEAT_FAILURES,
        'agent_cpu_nice': ENV_AGENT_CPU_NICE,
        'agent_min_free_memory_pct': ENV_AGENT_MIN_FREE_MEMORY_PCT,
        'agent_max_cpu_pct': ENV_AGENT_MAX_CPU_PCT,
        'agent_batch_delay_seconds': ENV_AGENT_BATCH_DELAY_SECONDS,
        'agent_auto_discovery': ENV_AGENT_AUTO_DISCOVERY,
        'agent_discovery_interval': ENV_AGENT_DISCOVERY_INTERVAL,
        'agent_use_sudo': ENV_AGENT_USE_SUDO,
        'agent_environment': ENV_AGENT_ENVIRONMENT,
        'agent_allow_insecure_tls_in_nonprod': ENV_AGENT_ALLOW_INSECURE_TLS_IN_NONPROD,
        'min_free_disk_mb': ENV_AGENT_MIN_FREE_DISK_MB,
        'min_free_disk_pct': ENV_AGENT_MIN_FREE_DISK_PCT,
        'auth_username': AUTH_USERNAME,
        'auth_password_override': '',
        'auth_password_hint': ENV_AUTH_PASSWORD_HINT,
        'auth_password_change_required': AUTH_ENABLED and bool(AUTH_PASSWORD) and AUTH_REQUIRE_PASSWORD_CHANGE_ON_FIRST_LOGIN,
        'auth_password_changed_at': None,
        'setup_complete': False,
        'created_at': None,
        'updated_at': None
    }

    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)

            # Phase 3: Verify signature (if present)
            if config_signing and config_signing.enabled and config.get('_signature'):
                is_valid, msg = config_signing.verify_config(config)
                if not is_valid:
                    logger.warning(f"Config signature verification failed: {msg}")
                    audit_logger.log_security_event("CONFIG_SIGNATURE_INVALID", msg)
                    # Continue loading but flag as unsigned
                else:
                    logger.debug("Config signature verified successfully")

                # Merge with defaults for any missing keys
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                return config
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            audit_logger.log_security_event("CONFIG_LOAD_ERROR", str(e))

    # If env vars are set, auto-configure (headless mode)
    if ENV_CORE_SERVER_URL:
        default_config['setup_complete'] = True
        save_config(default_config)
        logger.info(f"Auto-configured from environment variables. Core server: {ENV_CORE_SERVER_URL}")

    return default_config


def save_config(config):
    """Save agent configuration with validation and signing (Phase 1, 3).

    PHASE 1: Validates config and enforces secure file permissions
    PHASE 3: Signs config with ECDSA, logs changes
    """
    # Phase 1: Validate configuration structure
    is_valid, error_msg = config_validator.validate_config_file(config)
    if not is_valid and config.get('setup_complete'):
        logger.error(f"Config validation failed: {error_msg}")
        raise ValueError(f"Invalid configuration: {error_msg}")

    config['updated_at'] = datetime.now().isoformat()
    if not config.get('created_at'):
        config['created_at'] = config['updated_at']

    # Phase 3: Sign configuration (if signing available)
    if config_signing and config_signing.enabled:
        config['_signed_at'] = datetime.now().isoformat()
        signature = config_signing.sign_config(config)
        if signature:
            config['_signature'] = signature
            audit_logger.log_config_change("SIGNED", source="save_config")

    # Save to file
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

    # Phase 1: Enforce secure file permissions
    FileSecurityManager.set_secure_permissions(CONFIG_FILE)

    # Phase 3: Log config save
    audit_logger.log_config_change("SAVED", source="save_config")

    return config


def _resolve_max_local_result_files(config):
    """Resolve non-negative max local result file cap from config."""
    try:
        value = int(config.get('max_local_result_files', ENV_AGENT_MAX_LOCAL_RESULT_FILES))
    except (TypeError, ValueError):
        value = ENV_AGENT_MAX_LOCAL_RESULT_FILES
    return max(0, value)


def _coerce_non_negative_int(value, default_value):
    """Parse integer input and clamp to a non-negative value."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default_value
    return max(0, parsed)


def _resolve_min_free_disk_mb(config):
    """Resolve minimum free disk MB threshold from config."""
    try:
        value = int(config.get('min_free_disk_mb', ENV_AGENT_MIN_FREE_DISK_MB))
    except (TypeError, ValueError):
        value = ENV_AGENT_MIN_FREE_DISK_MB
    return max(64, value)


def _resolve_min_free_disk_pct(config):
    """Resolve minimum free disk percent threshold from config."""
    try:
        value = int(config.get('min_free_disk_pct', ENV_AGENT_MIN_FREE_DISK_PCT))
    except (TypeError, ValueError):
        value = ENV_AGENT_MIN_FREE_DISK_PCT
    return max(1, min(95, value))


def has_disk_headroom(path, config, context='local storage'):
    """Check whether local path has sufficient free disk headroom."""
    try:
        storage_path = Path(path)
        storage_path.mkdir(parents=True, exist_ok=True)
        usage = shutil.disk_usage(storage_path)
        free_mb = int(usage.free / (1024 * 1024))
        total_mb = int(usage.total / (1024 * 1024))
        free_pct = int(round((free_mb / total_mb) * 100)) if total_mb > 0 else 0

        min_free_mb = _resolve_min_free_disk_mb(config)
        min_free_pct = _resolve_min_free_disk_pct(config)

        if free_mb < min_free_mb or free_pct < min_free_pct:
            logger.warning(
                "Low disk space for %s: %sMB/%s%% free (min: %sMB/%s%%)",
                context,
                free_mb,
                free_pct,
                min_free_mb,
                min_free_pct,
            )
            return False
        return True
    except Exception as exc:
        logger.warning(f"Failed disk headroom check for {context}: {exc}")
        return False


def enforce_local_result_retention(config):
    """Prune oldest local result files to respect max_local_result_files cap."""
    if not config.get('keep_local_results', True):
        return 0

    max_files = _resolve_max_local_result_files(config)
    if max_files <= 0:
        return 0

    results_path = Path(RESULTS_DIR)
    if not results_path.exists():
        return 0

    result_files = sorted(results_path.glob('*.json'), key=os.path.getmtime)
    overflow = len(result_files) - max_files
    if overflow <= 0:
        return 0

    removed = 0
    for result_file in result_files[:overflow]:
        try:
            result_file.unlink()
            removed += 1
        except Exception as exc:
            logger.warning(f"Failed to prune local result file {result_file}: {exc}")

    if removed > 0:
        logger.info(f"Pruned {removed} local result files (max_local_result_files={max_files})")

    return removed


def load_schedules():
    """Load scheduled audits."""
    if SCHEDULE_FILE.exists():
        try:
            with open(SCHEDULE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {'schedules': [], 'last_run': None}


def save_schedules(schedules):
    """Save scheduled audits."""
    with open(SCHEDULE_FILE, 'w') as f:
        json.dump(schedules, f, indent=2)


# ============================================================================
# Core Server Communication
# ============================================================================

def test_core_server_connection(server_url, api_key=None):
    """Test connection to core audit server with proper certificate validation (Phase 1)."""
    try:
        url = f"{server_url.rstrip('/')}/api/health"

        req = urllib.request.Request(url)
        req.add_header('User-Agent', f'AuditAgent/{AGENT_VERSION}')
        if api_key:
            req.add_header('X-API-Key', api_key)

        # PHASE 1: Enable certificate validation (was: CERT_NONE)
        ctx = ssl.create_default_context()
        ctx.check_hostname = True  # Verify hostname matches certificate
        ctx.verify_mode = ssl.CERT_REQUIRED  # Require valid certificate

        with urllib.request.urlopen(req, timeout=10, context=ctx) as response:  # nosec B310 - URL is validated from configured core server endpoint
            if response.status == 200:
                data = json.loads(response.read().decode())
                return {
                    'success': True,
                    'message': 'Connected successfully',
                    'server_version': data.get('version', 'unknown'),
                    'server_status': data.get('status', 'unknown')
                }
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return {'success': False, 'error': 'Authentication failed - check API key'}
        return {'success': False, 'error': f'HTTP error: {e.code}'}
    except urllib.error.URLError as e:
        return {'success': False, 'error': f'Connection failed: {str(e.reason)}'}
    except ssl.SSLError as e:
        return {'success': False, 'error': f'SSL error (certificate issue): {str(e)}'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

    return {'success': False, 'error': 'Unknown error'}


def export_result_to_server(result_data, config=None):
    """
    Export audit result to core server with hardened security (Phase 1, 2, 3).

    PHASE 1: Certificate validation, secure URLs
    PHASE 2: Result data is encrypted before transmission
    PHASE 3: Request is signed with HMAC-SHA256

    Formats payload to match core server's /api/agent/results expected format:
    {
        "hostname": "required",
        "os": "optional",
        "agent_version": "6.2.1",
        "results": {
            "audit": "audit path or name",
            "timestamp": "ISO timestamp",
            "duration_ms": milliseconds,
            "summary": {...},
            "output": "full output text",
            "checks": parsed check results
        }
    }
    """
    if config is None:
        config = load_config()

    if not config.get('core_server_url'):
        audit_logger.log_export('unknown', 'none', 'failed', 'Core server not configured')
        return {'success': False, 'error': 'Core server not configured'}

    try:
        # Phase 1: Validate server URL
        is_valid, error = config_validator.validate_server_url(config['core_server_url'])
        if not is_valid:
            audit_logger.log_security_event("EXPORT_BLOCKED_INVALID_URL", error)
            return {'success': False, 'error': error}

        url = f"{config['core_server_url'].rstrip('/')}/api/agent/results"

        # Get system info
        hostname = 'unknown'
        os_name = 'Unknown'
        try:
            hostname = subprocess.check_output(['hostname'], text=True).strip()
        except Exception:
            pass

        try:
            with open('/etc/os-release') as f:
                for line in f:
                    if line.startswith('PRETTY_NAME='):
                        os_name = line.split('=')[1].strip().strip('"')
                        break
        except Exception:
            pass

        # Parse output for check details
        output = result_data.get('output', '')
        checks = []
        for line in output.split('\n'):
            if '[PASS]' in line:
                checks.append({'status': 'PASS', 'message': line.replace('[PASS]', '').strip()})
            elif '[FAIL]' in line:
                checks.append({'status': 'FAIL', 'message': line.replace('[FAIL]', '').strip()})
            elif '[WARN]' in line:
                checks.append({'status': 'WARN', 'message': line.replace('[WARN]', '').strip()})
            elif '[SKIP]' in line:
                checks.append({'status': 'SKIP', 'message': line.replace('[SKIP]', '').strip()})

        # Calculate duration
        duration_ms = 0
        try:
            started = datetime.fromisoformat(result_data.get('started_at', ''))
            completed = datetime.fromisoformat(result_data.get('completed_at', ''))
            duration_ms = int((completed - started).total_seconds() * 1000)
        except Exception:
            pass

        # Build payload in format expected by core server
        agent_id = config.get('agent_id', f'standalone-{hostname}')
        payload = {
            'hostname': hostname,
            'os': os_name,
            'agent_version': AGENT_VERSION,
            'results': {
                'audit': result_data.get('audit_path', result_data.get('audit_name', 'unknown')),
                'timestamp': result_data.get('completed_at', datetime.now().isoformat()),
                'duration_ms': duration_ms,
                'summary': result_data.get('summary', {}),
                'checks': checks,
                'output': output,
                'exit_code': result_data.get('exit_code', 0),
                'status': result_data.get('status', 'completed')
            }
        }

        data = json.dumps(payload).encode('utf-8')

        # Phase 3: Add HMAC-SHA256 signature for request authentication
        timestamp = str(int(datetime.now().timestamp()))
        signature = RequestSigning.generate_signature(
            'POST', '/api/agent/results',
            data.decode('utf-8'),
            config.get('api_key', ''),
            timestamp
        )

        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/json')
        req.add_header('User-Agent', f'AuditAgent/{AGENT_VERSION}')
        req.add_header('X-Agent-ID', agent_id)
        if config.get('api_key'):
            req.add_header('X-API-Key', config['api_key'])

        # Phase 3: Add request signature headers
        req.add_header('X-Signature', signature)
        req.add_header('X-Timestamp', timestamp)
        _add_managed_request_signature_headers(req, 'POST', '/api/agent/results', data, config)

        # Phase 1: Proper certificate validation (not CERT_NONE)
        ctx = ssl.create_default_context()
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED

        with urllib.request.urlopen(req, timeout=30, context=ctx) as response:  # nosec B310 - URL is validated from configured core server endpoint
            if response.status in (200, 201):
                resp_data = json.loads(response.read().decode())
                audit_logger.log_export(
                    result_data.get('job_id', 'unknown'),
                    config['core_server_url'],
                    'success',
                    resp_data.get('result_id', '')
                )
                return {
                    'success': True,
                    'message': 'Result exported successfully',
                    'result_id': resp_data.get('result_id')
                }
    except urllib.error.HTTPError as e:
        error_body = ''
        try:
            error_body = e.read().decode()
        except Exception:
            pass
        audit_logger.log_export(
            result_data.get('job_id', 'unknown'),
            config.get('core_server_url', 'unknown'),
            'failed',
            f'HTTP {e.code}: {error_body}'
        )
        return {'success': False, 'error': f'Server error {e.code}: {error_body}'}
    except ssl.SSLError as e:
        audit_logger.log_security_event("EXPORT_SSL_ERROR", str(e))
        return {'success': False, 'error': f'SSL error (certificate issue): {str(e)}'}
    except Exception as e:
        audit_logger.log_export(
            result_data.get('job_id', 'unknown'),
            config.get('core_server_url', 'unknown'),
            'failed',
            str(e)
        )
        return {'success': False, 'error': str(e)}

    return {'success': False, 'error': 'Export failed'}


def _add_managed_request_signature_headers(req, method: str, path: str, body_raw: bytes, config: dict):
    """Add managed request-signature headers when enabled in config."""
    if not isinstance(config, dict):
        return

    if not bool(config.get('managed_require_request_signatures', False)):
        return

    use_ecdsa = bool(config.get('managed_request_signature_use_ecdsa', False))

    signing_key = str(config.get('managed_request_signing_key', '') or '').strip()
    ecdsa_private_key_pem = str(config.get('managed_request_signature_ecdsa_private_key', '') or '').strip()
    if use_ecdsa:
        if not ecdsa_private_key_pem or not ECDSA_CRYPTO_AVAILABLE:
            return
    elif not signing_key:
        return

    request_timestamp = str(int(datetime.now().timestamp()))
    payload_hash = hashlib.sha256(body_raw or b'').hexdigest()
    signature_message = "\n".join([
        request_timestamp,
        str(method or 'GET').upper(),
        str(path or '/'),
        payload_hash,
    ]).encode('utf-8')
    if use_ecdsa:
        private_key = load_pem_private_key(ecdsa_private_key_pem.encode('utf-8'), password=None)
        signature_der = private_key.sign(signature_message, ec.ECDSA(hashes.SHA256()))
        request_signature = f"ecdsa:{base64.b64encode(signature_der).decode('ascii')}"
    else:
        request_signature = hmac.new(
            signing_key.encode('utf-8'),
            signature_message,
            hashlib.sha256,
        ).hexdigest()

    req.add_header('X-Agent-Timestamp', request_timestamp)
    req.add_header('X-Agent-Content-SHA256', payload_hash)
    req.add_header('X-Agent-Signature', request_signature)


# ============================================================================
# Schedule Management
# ============================================================================

def get_cron_expression(schedule):
    """Convert schedule to cron expression."""
    frequency = schedule.get('frequency', 'daily')
    time_str = schedule.get('time', '02:00')

    try:
        hour, minute = time_str.split(':')
    except ValueError:
        hour, minute = '2', '0'

    if frequency == 'hourly':
        return f"{minute} * * * *"
    elif frequency == 'daily':
        return f"{minute} {hour} * * *"
    elif frequency == 'weekly':
        day = schedule.get('day_of_week', 0)
        return f"{minute} {hour} * * {day}"
    elif frequency == 'monthly':
        day = schedule.get('day_of_month', 1)
        return f"{minute} {hour} {day} * *"
    else:
        return f"{minute} {hour} * * *"


def install_cron_schedule(schedule):
    """Install a schedule (cron on Linux, Task Scheduler on Windows)."""
    if is_windows():
        return install_windows_task(schedule)
    else:
        return install_unix_cron(schedule)


def install_unix_cron(schedule):
    """Install a cron job for the schedule (Linux/Unix only)."""
    try:
        cron_expr = get_cron_expression(schedule)

        # Determine command based on selection type
        selected_scripts = schedule.get('selected_scripts', [])

        if selected_scripts and len(selected_scripts) > 0:
            # Run specific selected scripts
            scripts_file = LOGS_DIR / f"{schedule.get('id', 'default')}-scripts.txt"
            with open(scripts_file, 'w') as f:
                for script_path in selected_scripts:
                    f.write(f"{script_path}\n")
            cmd = f"{AGENT_PATH} --silent run-scripts {scripts_file}"
        elif schedule.get('audit_path'):
            cmd = f"{AGENT_PATH} --silent run {schedule['audit_path']}"
        elif schedule.get('category'):
            cmd = f"{AGENT_PATH} --silent run-group {schedule['category']}"
        else:
            cmd = f"{AGENT_PATH} --silent runall"

        log_file = LOGS_DIR / 'scheduled-audit.log'
        full_cmd = f"{cmd} >> {log_file} 2>&1"

        cron_line = f"{cron_expr} {full_cmd}"
        cron_id = f"audit-{schedule.get('id', 'default')}"

        cron_file = Path('/etc/cron.d') / cron_id

        if cron_file.parent.exists():
            content = f"# Security Audit Schedule: {schedule.get('name', 'Unnamed')}\n"
            content += "SHELL=/bin/bash\n"
            content += "PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin\n"
            content += "MAILTO=''\n"  # Disable email output
            content += f"{cron_line}\n"

            with open(cron_file, 'w') as f:
                f.write(content)

            os.chmod(cron_file, 0o644)
            return {'success': True, 'message': f'Cron job installed: {cron_file}'}
        else:
            result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
            existing = result.stdout if result.returncode == 0 else ''

            lines = [line for line in existing.split('\n') if cron_id not in line]
            lines.append(f"# {cron_id}: {schedule.get('name', 'Unnamed')}")
            lines.append(cron_line)

            new_crontab = '\n'.join(lines) + '\n'

            proc = subprocess.run(['crontab', '-'], input=new_crontab, capture_output=True, text=True)

            if proc.returncode == 0:
                return {'success': True, 'message': 'Cron job installed via crontab'}
            else:
                return {'success': False, 'error': proc.stderr}

    except Exception as e:
        return {'success': False, 'error': str(e)}


def install_windows_task(schedule):
    """Install a Windows scheduled task."""
    try:
        task_name = f"AuditAgent-{schedule.get('id', 'default')}"

        # Parse schedule time
        time_str = schedule.get('time', '02:00')
        frequency = schedule.get('frequency', 'daily')

        # Build command
        selected_scripts = schedule.get('selected_scripts', [])
        if selected_scripts and len(selected_scripts) > 0:
            scripts_file = LOGS_DIR / f"{schedule.get('id', 'default')}-scripts.txt"
            with open(scripts_file, 'w') as f:
                for script_path in selected_scripts:
                    f.write(f"{script_path}\n")
            arguments = f"-File '{AGENT_PATH}' -Mode run-scripts -ScriptList '{scripts_file}' -Silent"
        elif schedule.get('audit_path'):
            arguments = f"-File '{AGENT_PATH}' -Mode run -Audit '{schedule['audit_path']}' -Silent"
        elif schedule.get('category'):
            arguments = f"-File '{AGENT_PATH}' -Mode run-group -Category '{schedule['category']}' -Silent"
        else:
            arguments = f"-File '{AGENT_PATH}' -Mode runall -Silent"

        # Create scheduled task using schtasks
        if frequency == 'daily':
            result = subprocess.run([
                'schtasks', '/Create', '/TN', task_name,
                '/TR', f'powershell.exe -ExecutionPolicy Bypass {arguments}',
                '/SC', 'DAILY', '/ST', time_str, '/F'
            ], capture_output=True, text=True)
        elif frequency == 'weekly':
            day_map = {'0': 'MON', '1': 'TUE', '2': 'WED', '3': 'THU', '4': 'FRI', '5': 'SAT', '6': 'SUN'}
            day = day_map.get(str(schedule.get('day_of_week', 0)), 'MON')
            result = subprocess.run([
                'schtasks', '/Create', '/TN', task_name,
                '/TR', f'powershell.exe -ExecutionPolicy Bypass {arguments}',
                '/SC', 'WEEKLY', '/D', day, '/ST', time_str, '/F'
            ], capture_output=True, text=True)
        elif frequency == 'monthly':
            day = schedule.get('day_of_month', 1)
            result = subprocess.run([
                'schtasks', '/Create', '/TN', task_name,
                '/TR', f'powershell.exe -ExecutionPolicy Bypass {arguments}',
                '/SC', 'MONTHLY', '/D', str(day), '/ST', time_str, '/F'
            ], capture_output=True, text=True)
        else:
            result = subprocess.run([
                'schtasks', '/Create', '/TN', task_name,
                '/TR', f'powershell.exe -ExecutionPolicy Bypass {arguments}',
                '/SC', 'DAILY', '/ST', time_str, '/F'
            ], capture_output=True, text=True)

        if result.returncode == 0:
            return {'success': True, 'message': f'Task scheduled: {task_name}'}
        else:
            return {'success': False, 'error': result.stderr}

    except Exception as e:
        return {'success': False, 'error': str(e)}


def remove_cron_schedule(schedule_id):
    """Remove a schedule (cron on Linux, Task Scheduler on Windows)."""
    if is_windows():
        return remove_windows_task(schedule_id)
    else:
        return remove_unix_cron(schedule_id)


def remove_unix_cron(schedule_id):
    """Remove a cron job (Linux/Unix only)."""
    try:
        cron_id = f"audit-{schedule_id}"
        cron_file = Path('/etc/cron.d') / cron_id

        if cron_file.exists():
            os.remove(cron_file)
            return {'success': True, 'message': 'Cron job removed'}
        else:
            result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
            if result.returncode == 0:
                lines = [line for line in result.stdout.split('\n') if cron_id not in line]
                new_crontab = '\n'.join(lines) + '\n'
                subprocess.run(['crontab', '-'], input=new_crontab, capture_output=True, text=True)
            return {'success': True, 'message': 'Cron job removed from crontab'}
    except Exception as e:
        return {'success': False, 'error': str(e)}


def remove_windows_task(schedule_id):
    """Remove a Windows scheduled task."""
    try:
        task_name = f"AuditAgent-{schedule_id}"
        result = subprocess.run([
            'schtasks', '/Delete', '/TN', task_name, '/F'
        ], capture_output=True, text=True)

        if result.returncode == 0:
            return {'success': True, 'message': f'Task removed: {task_name}'}
        else:
            # Task might not exist, which is okay
            return {'success': True, 'message': 'Task removed (or did not exist)'}
    except Exception as e:
        return {'success': False, 'error': str(e)}


# ============================================================================
# Audit Discovery & Execution
# ============================================================================

def get_audit_categories(include_locked: bool = True):
    """Discover audit categories and scripts.

    Args:
        include_locked: If True, include locked categories with a 'locked' flag.
                       If False, only return categories allowed by current license.

    Returns categories with license information:
    - 'allowed': True if category is available with current license
    - 'locked': True if category requires upgrade
    - 'required_tier': Minimum tier required for this category
    """
    categories = {}
    audit_path = Path(AUDIT_DIR)
    allowed_categories = set(license_manager.get_allowed_audit_categories())

    if not audit_path.exists():
        return categories

    script_glob = '*.ps1' if PLATFORM == 'windows' else '*.sh'

    def build_category_from_dir(category_name: str, category_dir: Path, globs: list[str]):
        """Build a category entry from a directory using one or more script globs."""
        category_allowed = is_category_allowed_for_standalone(
            category_name,
            list(allowed_categories),
            STANDALONE_MODE,
        )
        required_tier = get_required_tier_for_category(
            category_name,
            COMMUNITY_AUDIT_CATEGORIES,
            STARTER_AUDIT_CATEGORIES,
            BUSINESS_AUDIT_CATEGORIES,
            PROFESSIONAL_AUDIT_CATEGORIES,
            TIER_COMMUNITY,
            TIER_STARTER,
            TIER_BUSINESS,
            TIER_PROFESSIONAL,
            STANDALONE_MODE,
        )

        subcategories = {}

        # First, check for audits directly in the category folder.
        direct_audits = []
        direct_seen = set()
        for glob_pattern in globs:
            for audit_file in sorted(category_dir.glob(glob_pattern)):
                if audit_file.name.startswith('_'):
                    continue
                if audit_file.name in direct_seen:
                    continue

                script_allowed = is_script_allowed_for_standalone(
                    audit_file.name,
                    category_name,
                    STANDALONE_MODE,
                    license_manager,
                )
                if not include_locked and not script_allowed:
                    continue

                direct_seen.add(audit_file.name)
                direct_audits.append({
                    'name': audit_file.stem.replace('-', ' ').replace('_', ' ').title(),
                    'filename': audit_file.name,
                    'path': str(audit_file),
                    'relative': str(audit_file.relative_to(audit_path.parent)),
                    'locked': not script_allowed,
                    'allowed': script_allowed,
                })

        if direct_audits:
            subcategories['_default'] = {
                'name': category_name.replace('-', ' ').title(),
                'audits': direct_audits,
            }

        # Then check for subcategory directories.
        for subcat_dir in sorted(category_dir.iterdir()):
            if not (subcat_dir.is_dir() and not subcat_dir.name.startswith('_')):
                continue

            subcat_name = subcat_dir.name
            audits = []
            subcat_seen = set()

            for glob_pattern in globs:
                for audit_file in sorted(subcat_dir.glob(glob_pattern)):
                    if audit_file.name.startswith('_'):
                        continue
                    if audit_file.name in subcat_seen:
                        continue

                    script_allowed = is_script_allowed_for_standalone(
                        audit_file.name,
                        category_name,
                        STANDALONE_MODE,
                        license_manager,
                    )
                    if not include_locked and not script_allowed:
                        continue

                    subcat_seen.add(audit_file.name)
                    audits.append({
                        'name': audit_file.stem.replace('-', ' ').replace('_', ' ').title(),
                        'filename': audit_file.name,
                        'path': str(audit_file),
                        'relative': str(audit_file.relative_to(audit_path.parent)),
                        'locked': not script_allowed,
                        'allowed': script_allowed,
                    })

            if audits:
                subcategories[subcat_name] = {
                    'name': subcat_name.replace('-', ' ').title(),
                    'audits': audits,
                }

        total_audits = sum(len(subcat.get('audits', [])) for subcat in subcategories.values())

        if total_audits == 0:
            return

        categories[category_name] = {
            'name': category_name.replace('-', ' ').title(),
            'path': str(category_dir),
            'subcategories': subcategories,
            'allowed': category_allowed,
            'locked': not category_allowed,
            'required_tier': required_tier,
            'total_audits': total_audits,
        }

    for category_dir in sorted(audit_path.iterdir()):
        if not (category_dir.is_dir() and not category_dir.name.startswith('_')):
            continue

        category_name = category_dir.name
        build_category_from_dir(category_name, category_dir, [script_glob])

    # Hypervisors are a special Linux/appliance class: include them only on Linux hosts.
    if PLATFORM == 'linux':
        hypervisor_dir = audit_path.parent / 'hypervisors'
        if hypervisor_dir.exists() and hypervisor_dir.is_dir():
            build_category_from_dir('hypervisors', hypervisor_dir, ['*.sh', '*.ps1'])

    return categories


def get_all_audits_flat(include_locked: bool = True):
    """Get all audit scripts as a flat list for script selection UI."""
    all_audits = []
    categories = get_audit_categories(include_locked=include_locked)

    for cat_key, cat_data in categories.items():
        for subcat_key, subcat_data in cat_data.get('subcategories', {}).items():
            for audit in subcat_data.get('audits', []):
                # Create a unique ID and display name
                if subcat_key == '_default':
                    display_name = f"{cat_data['name']}: {audit['name']}"
                    group = cat_data['name']
                else:
                    display_name = f"{cat_data['name']} > {subcat_data['name']}: {audit['name']}"
                    group = f"{cat_data['name']} / {subcat_data['name']}"

                all_audits.append({
                    'id': audit['path'],  # Use path as unique ID
                    'name': audit['name'],
                    'filename': audit['filename'],
                    'path': audit['path'],
                    'relative': audit['relative'],
                    'display_name': display_name,
                    'category': cat_key,
                    'subcategory': subcat_key,
                    'group': group,
                    'allowed': audit.get('allowed', True),
                    'locked': audit.get('locked', False),
                })

    return sorted(all_audits, key=lambda x: x['display_name'])


def get_system_info():
    """Collect basic system information (cross-platform)."""
    # Get platform-specific OS info
    os_data = get_os_info()

    info = {
        'hostname': os_data.get('hostname', 'unknown'),
        'os': os_data.get('os_name', 'unknown'),
        'os_id': os_data.get('os_id', PLATFORM),
        'kernel': os_data.get('platform_version', 'unknown'),
        'uptime': get_system_uptime() or 'unknown',
        'is_alpine': os_data.get('os_id', '').lower() == 'alpine',
        'is_container': is_container(),
        'deployment_type': get_deployment_type(),
        'platform': PLATFORM,
        'timestamp': datetime.now().isoformat()
    }

    return info


def _run_powershell_json(script: str, timeout: int = 30):
    """Execute PowerShell script and parse JSON output safely."""
    if PLATFORM != 'windows':
        return None

    try:
        output = subprocess.check_output(
            ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        ).strip()
        if not output:
            return None
        return json.loads(output)
    except Exception:
        return None


def _ensure_list(value):
    """Normalize JSON value to list."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return [value]
    return []


def _parse_apt_upgrade_output(output: str):
    """Parse apt-get simulated upgrade output into pending update entries."""
    pending_updates = []
    for line in (output or '').split('\n'):
        line = line.strip()
        if not line.startswith('Inst '):
            continue

        full_match = re.match(r'^Inst\s+(\S+)\s+\[([^\]]+)\]\s+\(([^)\s]+)', line)
        if full_match:
            pending_updates.append({
                'name': full_match.group(1),
                'current_version': full_match.group(2),
                'new_version': full_match.group(3),
            })
            continue

        partial_match = re.match(r'^Inst\s+(\S+)\s+\(([^)\s]+)', line)
        if partial_match:
            pending_updates.append({
                'name': partial_match.group(1),
                'current_version': None,
                'new_version': partial_match.group(2),
            })

    return pending_updates


def _parse_yum_dnf_check_update_output(output: str):
    """Parse yum/dnf check-update output."""
    pending_updates = []
    for line in (output or '').split('\n'):
        line = line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith(('loaded plugins:', 'last metadata expiration check:', 'obsoleting packages', 'security:')):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        package_name = parts[0].split('.', 1)[0]
        pending_updates.append({
            'name': package_name,
            'current_version': None,
            'new_version': parts[1],
        })
    return pending_updates


def _parse_zypper_list_updates_output(output: str):
    """Parse zypper list-updates output."""
    pending_updates = []
    for line in (output or '').split('\n'):
        line = line.strip()
        if not line or '|' not in line:
            continue
        parts = [part.strip() for part in line.split('|')]
        if len(parts) < 5:
            continue
        if parts[2].lower() == 'name':
            continue
        pending_updates.append({
            'name': parts[2],
            'current_version': None,
            'new_version': parts[3],
        })
    return pending_updates


def _parse_apk_version_output(output: str):
    """Parse apk version -l '<' output."""
    pending_updates = []
    for line in (output or '').split('\n'):
        line = line.strip()
        if ' < ' not in line:
            continue
        left, right = [part.strip() for part in line.split(' < ', 1)]
        package_name = left.rsplit('-', 1)[0] if '-' in left else left
        pending_updates.append({
            'name': package_name,
            'current_version': left,
            'new_version': right,
        })
    return pending_updates


def _parse_pacman_qu_output(output: str):
    """Parse pacman -Qu output."""
    pending_updates = []
    for line in (output or '').split('\n'):
        line = line.strip()
        match = re.match(r'^(\S+)\s+(\S+)\s+->\s+(\S+)', line)
        if not match:
            continue
        pending_updates.append({
            'name': match.group(1),
            'current_version': match.group(2),
            'new_version': match.group(3),
        })
    return pending_updates


def run_audit_async(job_id, audit_path, audit_name):
    """Run an audit asynchronously and store results with encryption (Phase 2)."""
    running_jobs[job_id]['status'] = 'running'
    running_jobs[job_id]['started_at'] = datetime.now().isoformat()

    config = load_config()

    try:
        # Build platform-specific command
        if is_windows():
            # Windows: Run PowerShell script
            cmd = ['powershell.exe', '-ExecutionPolicy', 'Bypass', '-File', str(audit_path)]
            cwd = str(APP_DIR)
        else:
            # Linux/Unix: Run bash script
            cmd = ['bash', str(audit_path)]
            cwd = str(APP_DIR) if APP_DIR.exists() else '/app'

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=cwd
        )

        output = result.stdout + result.stderr
        exit_code = result.returncode

        passes = output.count('[PASS]')
        fails = output.count('[FAIL]')
        warns = output.count('[WARN]')
        skips = output.count('[SKIP]')

        result_file = Path(RESULTS_DIR) / f"{job_id}.json"
        result_data = {
            'job_id': job_id,
            'audit_name': audit_name,
            'audit_path': audit_path,
            'status': 'completed',
            'exit_code': exit_code,
            'output': output,
            'summary': {
                'passed': passes,
                'failed': fails,
                'warnings': warns,
                'skipped': skips,
                'total': passes + fails + warns + skips
            },
            'started_at': running_jobs[job_id]['started_at'],
            'completed_at': datetime.now().isoformat()
        }

        if config.get('keep_local_results', True):
            # Phase 2: Encrypt result if encryption available
            if has_disk_headroom(Path(RESULTS_DIR), config, 'local audit result storage'):
                if results_encryption and results_encryption.enabled:
                    results_encryption.encrypt_result(result_data, result_file)
                else:
                    with open(result_file, 'w') as f:
                        json.dump(result_data, f, indent=2)
                    # Phase 1: Enforce file permissions
                    FileSecurityManager.set_secure_permissions(result_file)
            else:
                logger.warning('Skipping local audit result persistence due to low disk headroom')

        if config.get('export_on_complete') and config.get('core_server_url'):
            export_result = export_result_to_server(result_data, config)
            result_data['export_status'] = export_result

            # Phase 2: Re-encrypt if updating with export status
            if config.get('keep_local_results', True):
                if has_disk_headroom(Path(RESULTS_DIR), config, 'local audit result update storage'):
                    if results_encryption and results_encryption.enabled:
                        results_encryption.encrypt_result(result_data, result_file)
                    else:
                        with open(result_file, 'w') as f:
                            json.dump(result_data, f, indent=2)
                        FileSecurityManager.set_secure_permissions(result_file)

                    if config.get('keep_local_results', True):
                        enforce_local_result_retention(config)
                else:
                    logger.warning('Skipping local export-status update due to low disk headroom')

        running_jobs[job_id].update({
            'status': 'completed',
            'exit_code': exit_code,
            'summary': result_data['summary'],
            'completed_at': result_data['completed_at']
        })

    except subprocess.TimeoutExpired:
        running_jobs[job_id]['status'] = 'timeout'
        running_jobs[job_id]['completed_at'] = datetime.now().isoformat()
    except Exception as e:
        running_jobs[job_id]['status'] = 'error'
        running_jobs[job_id]['error'] = str(e)
        running_jobs[job_id]['completed_at'] = datetime.now().isoformat()
        audit_logger.log_security_event("AUDIT_EXECUTION_ERROR", str(e))


def load_result_payload(result_file: Path):
    """Load result payload, decrypting when result encryption is enabled."""
    if results_encryption and results_encryption.enabled:
        decrypted = results_encryption.decrypt_result(result_file)
        if isinstance(decrypted, dict):
            return decrypted

    with open(result_file) as f:
        return json.load(f)


def _resolve_discovery_execution_plan(output_format: str = 'json'):
    """Resolve platform-appropriate discovery script and command if present."""
    repo_root = Path(__file__).resolve().parents[3]

    if is_windows():
        candidate_scripts = [
            APP_DIR / 'tools' / 'asset-discovery' / 'scripts' / 'windows-discovery.ps1',
            repo_root / 'tools' / 'asset-discovery' / 'scripts' / 'windows-discovery.ps1',
        ]
        for script_path in candidate_scripts:
            if script_path.exists():
                args = ['powershell.exe', '-ExecutionPolicy', 'Bypass', '-File', str(script_path), '--json']
                if output_format == 'summary':
                    args.append('--summary')
                return script_path, args
    else:
        candidate_scripts = [
            APP_DIR / 'orchestrator' / 'discovery.sh',
            APP_DIR / 'tools' / 'asset-discovery' / 'scripts' / 'linux-discovery.sh',
            repo_root / 'tools' / 'asset-discovery' / 'scripts' / 'linux-discovery.sh',
        ]
        for script_path in candidate_scripts:
            if script_path.exists():
                args = ['bash', str(script_path), '--json']
                if output_format == 'summary':
                    args.append('--summary')
                return script_path, args

    return None, None


def _build_discovery_fallback_response():
    """Return capability-based discovery output when discovery scripts are unavailable."""
    categories = get_audit_categories(include_locked=False)
    recommended_categories = sorted(categories.keys())
    total_audits = sum(
        len(subcat['audits'])
        for cat in categories.values()
        for subcat in cat.get('subcategories', {}).values()
    )

    return {
        'timestamp': datetime.now().isoformat(),
        'from_cache': False,
        'mode': 'fallback',
        'message': 'Discovery script unavailable; returning local capability-based recommendations.',
        'system_info': get_system_info(),
        'recommended_categories': recommended_categories,
        'total_audits_available': total_audits,
    }


# ============================================================================
# Web Routes - Pages
# ============================================================================

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit(os.environ.get('LOGIN_RATE_LIMIT', '5/minute'), methods=['POST'])
def login():
    """Login page for authentication (rate limited)."""
    if not AUTH_ENABLED:
        return render_template(
            'login.html',
            error=None,
            auth_enabled=AUTH_ENABLED,
            password_hint=None,
            password_change_required=False,
        )

    auth_state = _resolve_auth_state()

    error = None
    if request.method == 'POST':
        password = request.form.get('password', '')
        username = request.form.get('username', '')

        # Phase B3: Validate and sanitize input
        is_valid_user, user_error = validate_username(username)
        is_valid_pwd, pwd_error = validate_password(password, min_length=1)  # Login accepts any non-empty password

        if not is_valid_user or not is_valid_pwd:
            error = user_error or pwd_error or 'Invalid input'
        # Verify credentials
        elif username == auth_state['username'] and verify_password(password, auth_state['password']):
            session['authenticated'] = True
            session['username'] = sanitize_input(username, allowed_chars='a-zA-Z0-9_-')
            session['must_change_password'] = bool(auth_state['password_change_required'])
            session.permanent = True  # Use permanent session with timeout

            # Phase B1: Secure session is automatically configured by app.config

            if session['must_change_password']:
                return redirect(url_for('change_password'))

            # Redirect to requested page or index
            next_url = request.args.get('next', url_for('index'))
            return redirect(next_url)
        else:
            error = 'Invalid credentials'

    return render_template(
        'login.html',
        error=error,
        auth_enabled=AUTH_ENABLED,
        password_hint=auth_state['password_hint'] or None,
        password_change_required=bool(auth_state['password_change_required']),
    )


@app.route('/change-password', methods=['GET', 'POST'])
@limiter.limit(os.environ.get('LOGIN_RATE_LIMIT', '5/minute'), methods=['POST'])
def change_password():
    """Require first-login password rotation before allowing other actions."""
    if not AUTH_ENABLED:
        return redirect(url_for('index'))

    if not session.get('authenticated'):
        return redirect(url_for('login', next=request.url))

    auth_state = _resolve_auth_state()
    must_change = bool(session.get('must_change_password', False) or auth_state['password_change_required'])
    if not must_change:
        return redirect(url_for('index'))

    error = None
    success = None

    if request.method == 'POST':
        current_password = request.form.get('current_password', '')
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not verify_password(current_password, auth_state['password']):
            error = 'Current password is incorrect'
        elif new_password != confirm_password:
            error = 'New password and confirmation do not match'
        elif new_password == current_password:
            error = 'New password must be different from current password'
        else:
            is_valid_pwd, pwd_error = validate_password(
                new_password,
                min_length=AUTH_MIN_PASSWORD_LENGTH,
                require_special=AUTH_REQUIRE_SPECIAL_ON_CHANGE,
            )
            if not is_valid_pwd:
                error = pwd_error
            else:
                config = load_config()
                config['auth_password_override'] = new_password
                config['auth_password_change_required'] = False
                config['auth_password_changed_at'] = datetime.now().isoformat()
                save_config(config)

                session['must_change_password'] = False
                success = 'Password updated successfully. You can now use the dashboard.'
                return redirect(url_for('index'))

    return render_template(
        'change_password.html',
        error=error,
        success=success,
        username=auth_state['username'],
        min_password_length=AUTH_MIN_PASSWORD_LENGTH,
        require_special=AUTH_REQUIRE_SPECIAL_ON_CHANGE,
    )


@app.route('/logout')
def logout():
    """Logout and clear session."""
    session.clear()
    return redirect(url_for('login'))


@app.route('/api/auth/status', methods=['GET'])
@login_required
def api_auth_status():
    """Return current auth state for UI indicators and client-side guards."""
    auth_state = _resolve_auth_state()
    return jsonify({
        'authenticated': bool(session.get('authenticated', False)),
        'username': session.get('username') or auth_state.get('username', AUTH_USERNAME),
        'auth_enabled': AUTH_ENABLED,
        'password_change_required': bool(
            session.get('must_change_password', False) or auth_state.get('password_change_required', False)
        ),
    })


@csrf.exempt
@limiter.exempt
@app.route('/health')
def health():
    """Health check endpoint (no auth required)."""
    config = load_config()
    return jsonify({
        'status': 'healthy',
        'version': AGENT_VERSION,
        'auth_enabled': AUTH_ENABLED,
        'platform': PLATFORM,
        'agent_id': config.get('agent_id', ''),
        'core_server_configured': bool(config.get('core_server_url')),
        'timestamp': datetime.now().isoformat()
    })


@csrf.exempt
@app.route('/api/system-info')
def api_system_info():
    """
    System information endpoint for Asset Discovery integration.

    Returns comprehensive system data in the format expected by
    Asset Discovery's AgentExecutor for agent-based discovery scans.

    Requires API key and signed request headers by default.
    """
    config = load_config()
    auth_error = _validate_discovery_endpoint_auth(config)
    if auth_error:
        return auth_error

    info = get_system_info()

    result = {
        'hostname': info.get('hostname', 'unknown'),
        'os_type': 'linux' if PLATFORM == 'linux' else 'windows',
        'os_version': info.get('os', 'Unknown'),
        'kernel': info.get('kernel'),
        'is_container': info.get('is_container', False),
        'agent_version': AGENT_VERSION,
        'timestamp': datetime.now().isoformat(),
        'system': {
            'hostname': info.get('hostname', 'unknown'),
            'os_name': info.get('os', 'Unknown'),
            'os_version': info.get('os', 'Unknown'),
            'kernel_version': info.get('kernel'),
        }
    }

    if PLATFORM == 'windows':
        windows_system = _run_powershell_json(
            """
            $cs = Get-CimInstance Win32_ComputerSystem
            $os = Get-CimInstance Win32_OperatingSystem
            $bios = Get-CimInstance Win32_BIOS
            $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
            $product = Get-CimInstance Win32_ComputerSystemProduct
            $ipv4 = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
                Select-Object -First 1)
            $adapter = $null
            if ($ipv4) {
                $adapter = Get-NetAdapter -InterfaceIndex $ipv4.InterfaceIndex -ErrorAction SilentlyContinue
            }

            [PSCustomObject]@{
                fqdn = [System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName
                domain = $cs.Domain
                os_name = $os.Caption
                os_version = $os.Version
                os_build = $os.BuildNumber
                architecture = $os.OSArchitecture
                manufacturer = $cs.Manufacturer
                model = $cs.Model
                serial_number = $bios.SerialNumber
                product_uuid = $product.UUID
                cpu_name = $cpu.Name
                cpu_cores = [int]$cpu.NumberOfCores
                cpu_logical_processors = [int]$cpu.NumberOfLogicalProcessors
                total_memory_gb = [math]::Round(($cs.TotalPhysicalMemory / 1GB), 2)
                last_boot = $os.LastBootUpTime
                primary_ipv4 = $ipv4.IPAddress
                primary_mac = $adapter.MacAddress
            } | ConvertTo-Json -Compress
            """,
            timeout=25,
        )

        if isinstance(windows_system, dict):
            system_payload = result.get('system', {})
            system_payload.update({
                'fqdn': windows_system.get('fqdn'),
                'domain': windows_system.get('domain'),
                'os_name': windows_system.get('os_name') or system_payload.get('os_name'),
                'os_version': windows_system.get('os_version') or system_payload.get('os_version'),
                'os_build': windows_system.get('os_build'),
                'architecture': windows_system.get('architecture'),
                'manufacturer': windows_system.get('manufacturer'),
                'model': windows_system.get('model'),
                'serial_number': windows_system.get('serial_number'),
                'product_uuid': windows_system.get('product_uuid'),
                'cpu_name': windows_system.get('cpu_name'),
                'cpu_cores': windows_system.get('cpu_cores'),
                'cpu_logical_processors': windows_system.get('cpu_logical_processors'),
                'total_memory_gb': windows_system.get('total_memory_gb'),
                'last_boot': windows_system.get('last_boot'),
                'primary_ipv4': windows_system.get('primary_ipv4'),
                'primary_mac': windows_system.get('primary_mac'),
            })
            manufacturer = str(windows_system.get('manufacturer', '') or '').lower()
            model = str(windows_system.get('model', '') or '').lower()
            system_payload['is_virtual'] = any(
                marker in f"{manufacturer} {model}"
                for marker in ('virtual', 'vmware', 'kvm', 'hyper-v', 'xen')
            )
            result['system'] = system_payload
            result['domain'] = windows_system.get('domain')
            result['os_build'] = windows_system.get('os_build')

    # Collect installed packages
    try:
        packages = []
        if PLATFORM == 'linux':
            # Try dpkg (Debian/Ubuntu)
            try:
                output = subprocess.check_output(
                    ['dpkg-query', '-W', '-f=${Package}|${Version}|${Status}\n'],
                    text=True, stderr=subprocess.DEVNULL, timeout=30
                )
                for line in output.strip().split('\n')[:500]:
                    if 'install ok installed' in line:
                        parts = line.split('|')
                        if len(parts) >= 2:
                            packages.append({'name': parts[0], 'version': parts[1]})
            except Exception:
                pass

            # Try rpm (RHEL/Fedora)
            if not packages:
                try:
                    output = subprocess.check_output(
                        ['rpm', '-qa', '--queryformat', '%{NAME}|%{VERSION}-%{RELEASE}\n'],
                        text=True, stderr=subprocess.DEVNULL, timeout=30
                    )
                    for line in output.strip().split('\n')[:500]:
                        parts = line.split('|')
                        if len(parts) >= 2:
                            packages.append({'name': parts[0], 'version': parts[1]})
                except Exception:
                    pass

            # Try apk (Alpine)
            if not packages:
                try:
                    output = subprocess.check_output(
                        ['apk', 'list', '--installed'],
                        text=True, stderr=subprocess.DEVNULL, timeout=30
                    )
                    for line in output.strip().split('\n')[:500]:
                        # Format: name-version {arch} {repo} [installed]
                        if '[installed]' in line:
                            parts = line.split()
                            if parts:
                                name_ver = parts[0].rsplit('-', 1)
                                if len(name_ver) >= 1:
                                    packages.append({
                                        'name': name_ver[0],
                                        'version': name_ver[1] if len(name_ver) > 1 else 'unknown'
                                    })
                except Exception:
                    pass

            # Try pacman (Arch)
            if not packages:
                try:
                    output = subprocess.check_output(
                        ['pacman', '-Q'],
                        text=True, stderr=subprocess.DEVNULL, timeout=30
                    )
                    for line in output.strip().split('\n')[:500]:
                        if not line.strip():
                            continue
                        parts = line.split(maxsplit=1)
                        if len(parts) == 2:
                            packages.append({'name': parts[0], 'version': parts[1]})
                except Exception:
                    pass
        elif PLATFORM == 'windows':
            installed_apps = _run_powershell_json(
                r"""
                $paths = @(
                    'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
                    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
                )
                Get-ItemProperty $paths -ErrorAction SilentlyContinue |
                    Where-Object { $_.DisplayName } |
                    Select-Object -First 600 DisplayName, DisplayVersion, Publisher, InstallDate |
                    ConvertTo-Json -Compress
                """,
                timeout=40,
            )
            for app in _ensure_list(installed_apps):
                if not isinstance(app, dict):
                    continue
                packages.append({
                    'name': app.get('DisplayName', 'Unknown'),
                    'version': app.get('DisplayVersion') or 'Unknown',
                    'publisher': app.get('Publisher') or '',
                    'install_date': app.get('InstallDate') or '',
                    'source': 'registry',
                })
        result['packages'] = packages
    except Exception:
        result['packages'] = []

    # Collect services
    try:
        services = []
        if PLATFORM == 'linux':
            # Try systemctl
            try:
                output = subprocess.check_output(
                    ['systemctl', 'list-units', '--type=service', '--no-legend', '--no-pager'],
                    text=True, stderr=subprocess.DEVNULL, timeout=30
                )
                for line in output.strip().split('\n')[:200]:
                    parts = line.split()
                    if len(parts) >= 4:
                        services.append({
                            'name': parts[0].replace('.service', ''),
                            'status': parts[3]  # active/inactive
                        })
            except Exception:
                pass

            # Try rc-service (OpenRC/Alpine)
            if not services:
                try:
                    output = subprocess.check_output(
                        ['rc-service', '--list'],
                        text=True, stderr=subprocess.DEVNULL, timeout=30
                    )
                    for line in output.strip().split('\n')[:200]:
                        if line.strip():
                            services.append({'name': line.strip(), 'status': 'unknown'})
                except Exception:
                    pass
        elif PLATFORM == 'windows':
            win_services = _run_powershell_json(
                """
                Get-Service |
                    Select-Object -First 400 Name, DisplayName, Status, StartType |
                    ConvertTo-Json -Compress
                """,
                timeout=25,
            )
            for service in _ensure_list(win_services):
                if not isinstance(service, dict):
                    continue
                services.append({
                    'name': service.get('Name', 'unknown'),
                    'display_name': service.get('DisplayName', ''),
                    'status': str(service.get('Status', 'unknown')).lower(),
                    'start_type': str(service.get('StartType', 'unknown')).lower(),
                })
        result['services'] = services
    except Exception:
        result['services'] = []

    # Collect open ports
    try:
        ports = []
        if PLATFORM == 'linux':
            try:
                output = subprocess.check_output(
                    ['ss', '-tuln'],
                    text=True, stderr=subprocess.DEVNULL, timeout=10
                )
                for line in output.strip().split('\n')[1:100]:  # Skip header
                    parts = line.split()
                    if len(parts) >= 5:
                        # Parse local address:port
                        local = parts[4]
                        if ':' in local:
                            port = local.rsplit(':', 1)[-1]
                            try:
                                ports.append({
                                    'port': int(port),
                                    'protocol': 'tcp' if 'tcp' in parts[0].lower() else 'udp'
                                })
                            except ValueError:
                                pass
            except Exception:
                pass

            # Fallback to netstat
            if not ports:
                try:
                    output = subprocess.check_output(
                        ['netstat', '-tuln'],
                        text=True, stderr=subprocess.DEVNULL, timeout=10
                    )
                    for line in output.strip().split('\n')[2:100]:  # Skip headers
                        parts = line.split()
                        if len(parts) >= 4:
                            local = parts[3]
                            if ':' in local:
                                port = local.rsplit(':', 1)[-1]
                                try:
                                    ports.append({
                                        'port': int(port),
                                        'protocol': 'tcp' if 'tcp' in parts[0].lower() else 'udp'
                                    })
                                except ValueError:
                                    pass
                except Exception:
                    pass
        elif PLATFORM == 'windows':
            tcp_ports = _run_powershell_json(
                """
                Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
                    Select-Object -First 300 LocalPort |
                    ConvertTo-Json -Compress
                """,
                timeout=20,
            )
            udp_ports = _run_powershell_json(
                """
                Get-NetUDPEndpoint -ErrorAction SilentlyContinue |
                    Select-Object -First 200 LocalPort |
                    ConvertTo-Json -Compress
                """,
                timeout=20,
            )
            seen_ports = set()
            for port_entry in _ensure_list(tcp_ports):
                if not isinstance(port_entry, dict):
                    continue
                local_port = port_entry.get('LocalPort')
                try:
                    port_value = int(local_port)
                except (TypeError, ValueError):
                    continue
                seen_ports.add(('tcp', port_value))
                ports.append({'port': port_value, 'protocol': 'tcp'})
            for port_entry in _ensure_list(udp_ports):
                if not isinstance(port_entry, dict):
                    continue
                local_port = port_entry.get('LocalPort')
                try:
                    port_value = int(local_port)
                except (TypeError, ValueError):
                    continue
                if ('udp', port_value) in seen_ports:
                    continue
                seen_ports.add(('udp', port_value))
                ports.append({'port': port_value, 'protocol': 'udp'})
        result['open_ports'] = ports
    except Exception:
        result['open_ports'] = []

    # Count pending updates
    try:
        updates_available = 0
        pending_updates = []
        if PLATFORM == 'linux':
            # Try apt
            try:
                output = subprocess.check_output(
                    ['apt-get', '-s', 'upgrade'],
                    text=True, stderr=subprocess.DEVNULL, timeout=60
                )
                pending_updates = _parse_apt_upgrade_output(output)
                updates_available = len(pending_updates)
            except Exception:
                pass

            # Try yum
            if updates_available == 0:
                try:
                    proc = subprocess.run(
                        ['yum', 'check-update', '--quiet'],
                        capture_output=True,
                        text=True,
                        timeout=60,
                        check=False,
                    )
                    if proc.returncode in (0, 1, 2, 100):
                        pending_updates = _parse_yum_dnf_check_update_output(proc.stdout)
                        updates_available = len(pending_updates)
                except Exception:
                    pass

            # Try dnf
            if updates_available == 0:
                try:
                    proc = subprocess.run(
                        ['dnf', '--refresh', 'check-update', '--quiet'],
                        capture_output=True,
                        text=True,
                        timeout=60,
                        check=False,
                    )
                    if proc.returncode in (0, 1, 2, 100):
                        pending_updates = _parse_yum_dnf_check_update_output(proc.stdout)
                        updates_available = len(pending_updates)
                except Exception:
                    pass

            # Try zypper (openSUSE/SLES)
            if updates_available == 0:
                try:
                    proc = subprocess.run(
                        ['zypper', '--non-interactive', 'list-updates'],
                        capture_output=True,
                        text=True,
                        timeout=60,
                        check=False,
                    )
                    if proc.returncode in (0, 1, 2, 100):
                        pending_updates = _parse_zypper_list_updates_output(proc.stdout)
                        updates_available = len(pending_updates)
                except Exception:
                    pass

            # Try apk
            if updates_available == 0:
                try:
                    output = subprocess.check_output(
                        ['apk', 'version', '-l', '<'],
                        text=True, stderr=subprocess.DEVNULL, timeout=60
                    )
                    pending_updates = _parse_apk_version_output(output)
                    updates_available = len(pending_updates)
                except Exception:
                    pass

            # Try pacman (Arch)
            if updates_available == 0:
                try:
                    proc = subprocess.run(
                        ['pacman', '-Qu'],
                        capture_output=True,
                        text=True,
                        timeout=60,
                        check=False,
                    )
                    if proc.returncode in (0, 1, 2, 100):
                        pending_updates = _parse_pacman_qu_output(proc.stdout)
                        updates_available = len(pending_updates)
                except Exception:
                    pass
        elif PLATFORM == 'windows':
            windows_updates = _run_powershell_json(
                """
                try {
                    $session = New-Object -ComObject Microsoft.Update.Session
                    $searcher = $session.CreateUpdateSearcher()
                    $results = $searcher.Search("IsInstalled=0 and Type='Software'")
                    $updates = @()
                    foreach ($u in ($results.Updates | Select-Object -First 200)) {
                        $kb = $null
                        if ($u.KBArticleIDs -and $u.KBArticleIDs.Count -gt 0) {
                            $kb = 'KB' + ($u.KBArticleIDs -join ',KB')
                        }
                        $updates += [PSCustomObject]@{
                            name = [string]$u.Title
                            current_version = $null
                            new_version = $null
                            kb = $kb
                            update_id = if ($u.Identity) { [string]$u.Identity.UpdateID } else { $null }
                            revision_number = if ($u.Identity) { [string]$u.Identity.RevisionNumber } else { $null }
                        }
                    }
                    [PSCustomObject]@{ count = $results.Updates.Count; pending_updates = $updates } | ConvertTo-Json -Compress -Depth 5
                } catch {
                    [PSCustomObject]@{ count = 0; pending_updates = @() } | ConvertTo-Json -Compress
                }
                """,
                timeout=45,
            )

            if isinstance(windows_updates, dict):
                pending_updates = [item for item in _ensure_list(windows_updates.get('pending_updates')) if isinstance(item, dict)]
                if pending_updates:
                    updates_available = len(pending_updates)
                else:
                    try:
                        updates_available = int(windows_updates.get('count', 0) or 0)
                    except (TypeError, ValueError):
                        updates_available = 0
            elif isinstance(windows_updates, list):
                pending_updates = [item for item in windows_updates if isinstance(item, dict)]
                updates_available = len(pending_updates)
            else:
                try:
                    updates_available = int(windows_updates or 0)
                except (TypeError, ValueError):
                    updates_available = 0
        result['updates_available'] = updates_available
        result['pending_updates'] = pending_updates
    except Exception:
        result['updates_available'] = 0
        result['pending_updates'] = []

    # Add distro detection info
    result['distro'] = detect_host_distro()
    result['distro_categories'] = get_distro_specific_categories()

    return jsonify(result)


@app.route('/api/discovery', methods=['GET', 'POST'])
def api_discovery():
    """
    Run discovery script to analyze the system and recommend audits.

    This endpoint is ALWAYS available regardless of license tier.
    Discovery helps understand what's installed on the server.

    GET: Returns cached discovery results if available
    POST: Runs fresh discovery scan

    Query params:
        format: 'json' (default) or 'summary'
    """
    cache_file = Path(RESULTS_DIR) / 'discovery-cache.json'
    output_format = request.args.get('format', 'json')

    # For GET requests, try to return cached results
    if request.method == 'GET' and cache_file.exists():
        try:
            cache_age = datetime.now().timestamp() - cache_file.stat().st_mtime
            # Return cache if less than 1 hour old
            if cache_age < 3600:
                with open(cache_file) as f:
                    cached = json.load(f)
                cached['from_cache'] = True
                cached['cache_age_seconds'] = int(cache_age)
                return jsonify(cached)
        except Exception:
            pass

    discovery_script, discovery_args = _resolve_discovery_execution_plan(output_format)

    # Fallback: return local capability summary when no discovery script is available.
    if discovery_script is None or discovery_args is None:
        fallback_data = _build_discovery_fallback_response()
        try:
            config = load_config()
            if has_disk_headroom(Path(RESULTS_DIR), config, 'discovery cache storage'):
                with open(cache_file, 'w') as f:
                    json.dump(fallback_data, f, indent=2)
        except Exception:
            pass
        return jsonify(fallback_data)

    try:
        result = subprocess.run(
            discovery_args,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=str(discovery_script.parent)
        )

        if result.returncode != 0:
            return jsonify({
                'error': 'Discovery script failed',
                'stderr': result.stderr,
                'returncode': result.returncode
            }), 500

        # Parse JSON output
        try:
            discovery_data = json.loads(result.stdout)
            discovery_data['timestamp'] = datetime.now().isoformat()
            discovery_data['from_cache'] = False

            # Cache the results
            try:
                config = load_config()
                if has_disk_headroom(Path(RESULTS_DIR), config, 'discovery cache storage'):
                    with open(cache_file, 'w') as f:
                        json.dump(discovery_data, f, indent=2)
                else:
                    logger.warning('Skipping discovery cache write due to low disk headroom')
            except Exception:
                pass  # Caching failure is not critical

            return jsonify(discovery_data)

        except json.JSONDecodeError:
            # Return raw output if not valid JSON
            return jsonify({
                'raw_output': result.stdout,
                'format': 'text',
                'timestamp': datetime.now().isoformat()
            })

    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Discovery script timed out'}), 504
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/')
@login_required
def index():
    """Main dashboard."""
    if MANAGED_AGENT_SETUP_ONLY:
        return redirect(url_for('setup_wizard'))

    config = load_config()

    categories = get_audit_categories(include_locked=False)
    system_info = get_system_info()

    total_audits = sum(
        len(subcat['audits'])
        for cat in categories.values()
        for subcat in cat['subcategories'].values()
    )

    results_path = Path(RESULTS_DIR)
    recent_results = []
    if results_path.exists():
        result_files = sorted(results_path.glob('*.json'), key=os.path.getmtime, reverse=True)[:5]
        for rf in result_files:
            try:
                data = load_result_payload(rf)
                recent_results.append({
                    'job_id': data.get('job_id'),
                    'audit_name': data.get('audit_name'),
                    'status': data.get('status'),
                    'summary': data.get('summary', {}),
                    'completed_at': data.get('completed_at')
                })
            except Exception:
                pass

    schedules = load_schedules()

    return render_template('index.html',
                         categories=categories,
                         system_info=system_info,
                         total_audits=total_audits,
                         recent_results=recent_results,
                         running_jobs=running_jobs,
                         config=config,
                         schedules=schedules.get('schedules', []))


@app.route('/setup')
@login_required
def setup_wizard():
    """Setup wizard for initial configuration."""
    config = load_config()
    system_info = get_system_info()
    categories = get_audit_categories(include_locked=False)

    return render_template('setup.html',
                         config=config,
                         system_info=system_info,
                         categories=categories)


@app.route('/audits')
@login_required
def list_audits():
    """List all available audits."""
    return _managed_mode_blocked_response('Audits page')


@app.route('/results')
@login_required
def list_results():
    """List all saved results."""
    return _managed_mode_blocked_response('Results page')


@app.route('/results/<job_id>')
@login_required
def view_result(job_id):
    """View a specific result."""
    return _managed_mode_blocked_response('Result details page')

    result_file = Path(RESULTS_DIR) / f"{job_id}.json"

    if not result_file.exists():
        return render_template('error.html', message='Result not found'), 404

    result = load_result_payload(result_file)

    return render_template('result_detail.html', result=result)


@app.route('/schedules')
@login_required
def view_schedules():
    """View and manage scheduled audits."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local scheduling')

    schedules = load_schedules()
    categories = get_audit_categories()
    all_audits = get_all_audits_flat()
    return render_template('schedules.html',
                         schedules=schedules.get('schedules', []),
                         categories=categories,
                         all_audits=all_audits)


@app.route('/settings')
@login_required
def view_settings():
    """View and edit settings."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Settings page')

    config = load_config()
    config = dict(config)
    config['has_managed_config_signing_key'] = bool(config.get('managed_config_signing_key'))
    config['has_managed_config_signing_ecdsa_public_key'] = bool(config.get('managed_config_signing_ecdsa_public_key'))
    config['has_managed_request_signing_key'] = bool(config.get('managed_request_signing_key'))
    config['has_managed_request_signature_ecdsa_private_key'] = bool(config.get('managed_request_signature_ecdsa_private_key'))
    config['managed_config_signing_key'] = ''
    config['managed_config_signing_ecdsa_public_key'] = ''
    config['managed_request_signing_key'] = ''
    config['managed_request_signature_ecdsa_private_key'] = ''
    system_info = get_system_info()
    display_agent_id = config.get('agent_id')
    if not display_agent_id:
        hostname = system_info.get('hostname', 'unknown')
        display_agent_id = f"standalone-{hostname}"
    return render_template('settings.html', config=config, display_agent_id=display_agent_id)


# ============================================================================
# Web Routes - API
# ============================================================================

@app.route('/api/setup', methods=['POST'])
@login_required
def api_setup():
    """Complete initial setup with security validation (Phase 1, 3)."""
    try:
        data = request.get_json() or {}
        config = load_config()

        # Phase 1: Validate server URL before accepting
        server_url = data.get('core_server_url', '').strip()
        if server_url:
            is_valid, error = config_validator.validate_server_url(server_url)
            if not is_valid:
                audit_logger.log_security_event("SETUP_INVALID_SERVER", error)
                return jsonify({'success': False, 'error': error}), 400

        config['core_server_url'] = server_url

        # Preserve token-based registration keys when setup UI sends placeholder values.
        incoming_api_key = data.get('api_key')
        if not server_url:
            # Standalone mode: ensure key is cleared.
            config['api_key'] = ''
        elif incoming_api_key is not None:
            api_key_candidate = str(incoming_api_key).strip()
            if api_key_candidate and api_key_candidate != 'auto-configured':
                config['api_key'] = api_key_candidate
            elif api_key_candidate == '' and config.get('registration_method') != 'token':
                # Allow clearing key for non-token methods only.
                config['api_key'] = ''
        config['agent_id'] = data.get('agent_id', '').strip()
        config['auto_export'] = data.get('auto_export', False)
        config['export_on_complete'] = data.get('export_on_complete', True)
        config['keep_local_results'] = data.get('keep_local_results', True)
        config['max_local_result_files'] = _coerce_non_negative_int(
            data.get('max_local_result_files', config.get('max_local_result_files', ENV_AGENT_MAX_LOCAL_RESULT_FILES)),
            ENV_AGENT_MAX_LOCAL_RESULT_FILES
        )
        config['min_free_disk_mb'] = max(64, int(data.get('min_free_disk_mb', config.get('min_free_disk_mb', ENV_AGENT_MIN_FREE_DISK_MB))))
        config['min_free_disk_pct'] = max(1, min(95, int(data.get('min_free_disk_pct', config.get('min_free_disk_pct', ENV_AGENT_MIN_FREE_DISK_PCT)))))
        config['setup_complete'] = True

        if not config['agent_id']:
            hostname = get_system_info().get('hostname', 'unknown')
            config['agent_id'] = f"standalone-{hostname}-{datetime.now().strftime('%Y%m%d')}"

        save_config(config)
        enforce_local_result_retention(config)

        # Phase 3: Log setup completion
        audit_logger.log_config_change("SETUP_COMPLETE", source="api_setup")

        if (not MANAGED_AGENT_SETUP_ONLY) and data.get('schedule'):
            schedule = data['schedule']
            schedule['id'] = f"initial-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            schedule['name'] = schedule.get('name', 'Daily Audit')
            schedule['enabled'] = True
            schedule['created_at'] = datetime.now().isoformat()

            schedules = load_schedules()
            schedules['schedules'].append(schedule)
            save_schedules(schedules)

            install_cron_schedule(schedule)

        return jsonify({'success': True, 'config': {k: v for k, v in config.items() if k != 'api_key'}})
    except ValueError as e:
        audit_logger.log_security_event("SETUP_VALIDATION_ERROR", str(e))
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        audit_logger.log_security_event("SETUP_ERROR", str(e))
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/config', methods=['GET', 'POST'])
@limiter.limit(os.environ.get('CONFIG_RATE_LIMIT', '30/minute'))
@login_required
def api_config():
    """Get or update configuration with security validation (Phase 1, 3, rate limited)."""
    if request.method == 'GET':
        config = load_config()
        safe_config = {k: v for k, v in config.items()
                      if k not in ('api_key', '_signature', 'managed_config_signing_key', 'managed_config_signing_ecdsa_public_key', 'managed_request_signing_key', 'managed_request_signature_ecdsa_private_key')}
        safe_config['has_api_key'] = bool(config.get('api_key'))
        safe_config['has_managed_config_signing_key'] = bool(config.get('managed_config_signing_key'))
        safe_config['has_managed_config_signing_ecdsa_public_key'] = bool(config.get('managed_config_signing_ecdsa_public_key'))
        safe_config['has_managed_request_signing_key'] = bool(config.get('managed_request_signing_key'))
        safe_config['has_managed_request_signature_ecdsa_private_key'] = bool(config.get('managed_request_signature_ecdsa_private_key'))
        return jsonify(safe_config)

    try:
        data = request.get_json() or {}
        config = load_config()

        allowed = [
            'core_server_url', 'api_key', 'agent_id', 'auto_export',
            'export_on_complete', 'keep_local_results', 'max_local_result_files',
            'min_free_disk_mb', 'min_free_disk_pct',
            'managed_require_https', 'managed_allow_private_hosts',
            'managed_allowed_server_domains', 'managed_blocked_server_keywords',
            'managed_enforce_signed_config', 'managed_config_signing_key',
            'managed_config_signing_use_ecdsa', 'managed_config_signing_ecdsa_public_key',
            'managed_config_max_age_seconds', 'managed_require_request_signatures',
            'managed_request_signing_key', 'managed_request_signature_max_age_seconds',
            'managed_request_signature_use_ecdsa', 'managed_request_signature_ecdsa_private_key',
            'agent_poll_interval',
            'agent_heartbeat_timeout', 'agent_max_heartbeat_failures',
            'agent_cpu_nice', 'agent_min_free_memory_pct', 'agent_max_cpu_pct',
            'agent_batch_delay_seconds', 'agent_auto_discovery',
            'agent_discovery_interval', 'agent_use_sudo',
            'agent_environment', 'agent_allow_insecure_tls_in_nonprod'
        ]

        int_ranges = {
            'managed_config_max_age_seconds': (30, 86400),
            'managed_request_signature_max_age_seconds': (30, 3600),
            'agent_poll_interval': (10, 3600),
            'agent_heartbeat_timeout': (5, 300),
            'agent_max_heartbeat_failures': (1, 20),
            'agent_cpu_nice': (-20, 19),
            'agent_min_free_memory_pct': (0, 95),
            'agent_max_cpu_pct': (0, 100),
            'agent_batch_delay_seconds': (0, 300),
            'agent_discovery_interval': (60, 86400),
            'max_local_result_files': (0, 100000),
            'min_free_disk_mb': (64, 1048576),
            'min_free_disk_pct': (1, 95),
        }

        bool_fields = {
            'auto_export', 'export_on_complete', 'keep_local_results',
            'managed_require_https', 'managed_allow_private_hosts',
            'managed_enforce_signed_config', 'managed_require_request_signatures',
            'managed_request_signature_use_ecdsa',
            'agent_auto_discovery',
            'agent_use_sudo', 'agent_allow_insecure_tls_in_nonprod'
        }

        for key in allowed:
            if key in data:
                # Phase 1: Validate server URL if being changed
                if key == 'core_server_url':
                    new_url = data[key].strip()
                    if new_url:
                        is_valid, error = config_validator.validate_server_url(new_url)
                        if not is_valid:
                            audit_logger.log_security_event("CONFIG_UPDATE_INVALID_URL", error)
                            return jsonify({'success': False, 'error': error}), 400
                        config[key] = new_url
                        audit_logger.log_config_change("SERVER_URL_CHANGED", source="api_config")
                    else:
                        config[key] = ''
                elif key == 'api_key':
                    # Phase 3: Log API key changes (without exposing the key)
                    old_has_key = bool(config.get('api_key'))
                    config[key] = data[key].strip()
                    new_has_key = bool(config[key])
                    if old_has_key != new_has_key:
                        audit_logger.log_config_change("API_KEY_CHANGED", source="api_config")
                elif key == 'managed_config_signing_key':
                    incoming = str(data[key]).strip()
                    if incoming and '•' not in incoming:
                        config[key] = incoming
                        audit_logger.log_config_change("MANAGED_CONFIG_SIGNING_KEY_CHANGED", source="api_config")
                elif key == 'managed_config_signing_ecdsa_public_key':
                    incoming = str(data[key]).strip()
                    if incoming and '•' not in incoming:
                        config[key] = incoming
                        audit_logger.log_config_change("MANAGED_CONFIG_SIGNING_ECDSA_PUBLIC_KEY_CHANGED", source="api_config")
                elif key == 'managed_request_signing_key':
                    incoming = str(data[key]).strip()
                    if incoming and '•' not in incoming:
                        config[key] = incoming
                        audit_logger.log_config_change("MANAGED_REQUEST_SIGNING_KEY_CHANGED", source="api_config")
                elif key == 'managed_request_signature_ecdsa_private_key':
                    incoming = str(data[key]).strip()
                    if incoming and '•' not in incoming:
                        config[key] = incoming
                        audit_logger.log_config_change("MANAGED_REQUEST_SIGNATURE_ECDSA_PRIVATE_KEY_CHANGED", source="api_config")
                elif key in int_ranges:
                    minimum, maximum = int_ranges[key]
                    value = int(data[key])
                    config[key] = max(minimum, min(maximum, value))
                elif key in bool_fields:
                    config[key] = bool(data[key])
                elif key == 'agent_environment':
                    env_value = str(data[key]).strip().lower()
                    if env_value not in {'production', 'dev', 'development', 'test', 'testing', 'beta', 'staging'}:
                        return jsonify({'success': False, 'error': 'Invalid agent_environment value'}), 400
                    config[key] = env_value
                else:
                    config[key] = str(data[key]).strip()

        if config.get('managed_enforce_signed_config'):
            if config.get('managed_config_signing_use_ecdsa'):
                if not str(config.get('managed_config_signing_ecdsa_public_key', '')).strip():
                    return jsonify({'success': False, 'error': 'ECDSA public key is required when ECDSA config signing mode is enabled'}), 400
            elif not str(config.get('managed_config_signing_key', '')).strip():
                return jsonify({'success': False, 'error': 'Managed config signing key is required when signed config enforcement is enabled (HMAC mode)'}), 400
        if config.get('managed_require_request_signatures'):
            if config.get('managed_request_signature_use_ecdsa'):
                if not str(config.get('managed_request_signature_ecdsa_private_key', '')).strip():
                    return jsonify({'success': False, 'error': 'ECDSA private key is required when ECDSA request-signature mode is enabled'}), 400
            elif not str(config.get('managed_request_signing_key', '')).strip():
                return jsonify({'success': False, 'error': 'Managed request signing key is required when managed request-signature enforcement is enabled'}), 400

        save_config(config)
        enforce_local_result_retention(config)
        audit_logger.log_config_change("UPDATED", source="api_config")
        return jsonify({'success': True})
    except ValueError as e:
        audit_logger.log_security_event("CONFIG_VALIDATION_ERROR", str(e))
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        audit_logger.log_security_event("CONFIG_UPDATE_ERROR", str(e))
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/config/reset', methods=['POST'])
@login_required
def api_reset_config():
    """Reset configuration to defaults."""
    try:
        # Remove config file
        if CONFIG_FILE.exists():
            CONFIG_FILE.unlink()

        # Remove schedules file
        if SCHEDULE_FILE.exists():
            SCHEDULE_FILE.unlink()

        # Remove any cron jobs
        cron_dir = Path('/etc/cron.d')
        if cron_dir.exists():
            for cron_file in cron_dir.glob('audit-*'):
                try:
                    cron_file.unlink()
                except Exception:
                    pass

        return jsonify({'success': True, 'message': 'Configuration reset. Please reload to run setup wizard.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/results/clear', methods=['POST'])
@login_required
def api_clear_results():
    """Clear all stored results."""
    try:
        results_path = Path(RESULTS_DIR)
        deleted_count = 0

        if results_path.exists():
            for result_file in results_path.glob('*.json'):
                try:
                    result_file.unlink()
                    deleted_count += 1
                except Exception:
                    pass

            for result_file in results_path.glob('*.log'):
                try:
                    result_file.unlink()
                    deleted_count += 1
                except Exception:
                    pass

        # Clear running jobs dict
        running_jobs.clear()

        return jsonify({'success': True, 'message': f'Deleted {deleted_count} result files.', 'deleted': deleted_count})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/audits', methods=['GET'])
@login_required
def api_audits():
    """Get all available audit scripts (flat list for selection UI)."""
    return _managed_mode_blocked_response('Audits API')


@app.route('/api/test-connection', methods=['POST'])
@login_required
def api_test_connection():
    """Test connection to core server."""
    data = request.get_json() or {}
    server_url = data.get('server_url', '')
    api_key = data.get('api_key', '')

    if not server_url:
        return jsonify({'success': False, 'error': 'Server URL required'})

    result = test_core_server_connection(server_url, api_key)
    return jsonify(result)


@app.route('/api/register-with-token', methods=['POST'])
@login_required
def register_with_token():
    """Deprecated: standalone setup no longer proxies managed registration token flows."""
    return jsonify({
        'success': False,
        'error': 'Deprecated endpoint',
        'details': 'Token-based managed registration is disabled for standalone mode. Configure API key push mode in standalone settings, or use the fleet agent install flow.'
    }), 410


@app.route('/api/connection/health', methods=['GET'])
@login_required
def get_connection_health():
    """Get detailed connection health status."""
    config = load_config()

    if not config.get('core_server_url'):
        return jsonify({
            'status': 'offline',
            'mode': 'standalone',
            'message': 'Agent is in standalone mode (not configured to use core server)'
        })

    server_url = config.get('core_server_url', '').rstrip('/')
    api_key = config.get('api_key', '')

    # Get last export info from result files
    last_export = None
    failed_exports = 0
    result_files = sorted(Path(RESULTS_DIR).glob('*.json'), key=os.path.getmtime, reverse=True)

    for result_file in result_files[:20]:  # Check last 20 results
        try:
            with open(result_file) as f:
                data = json.load(f)
                export_status = data.get('export_status', {})

                if export_status.get('success'):
                    if last_export is None:
                        last_export = {
                            'timestamp': data.get('completed_at'),
                            'audit_name': data.get('audit_name'),
                            'result_id': export_status.get('result_id')
                        }
                else:
                    if export_status.get('error'):
                        failed_exports += 1
        except Exception:
            pass

    # Test connection to server
    test_result = test_core_server_connection(server_url, api_key)

    # Determine overall health status
    if test_result.get('success'):
        health_status = 'healthy'
        health_icon = '✅'
        health_message = 'Connected and operational'
    else:
        health_status = 'unhealthy'
        health_icon = '❌'
        health_message = f"Connection error: {test_result.get('error', 'Unknown error')}"

    return jsonify({
        'status': health_status,
        'icon': health_icon,
        'message': health_message,
        'mode': 'connected',
        'server_url': server_url,
        'agent_id': config.get('agent_id'),
        'api_key_configured': bool(api_key),
        'auto_export': config.get('auto_export', False),
        'export_on_complete': config.get('export_on_complete', False),
        'last_export': last_export,
        'failed_exports_count': failed_exports,
        'server_version': test_result.get('server_version'),
        'server_status': test_result.get('status')
    })


@app.route('/api/test-connection/detailed', methods=['POST'])
@login_required
def api_test_connection_detailed():
    """Test connection with detailed diagnostics."""
    import socket
    from urllib.parse import urlparse

    data = request.get_json() or {}
    server_url = data.get('server_url', '').rstrip('/')
    api_key = data.get('api_key', '')

    if not server_url:
        return jsonify({'success': False, 'error': 'Server URL required'})

    diagnostics = {
        'server_url': server_url,
        'tests': [],
        'summary': {}
    }

    # Test 1: DNS Resolution
    try:
        parsed = urlparse(server_url)
        hostname = parsed.hostname
        socket.gethostbyname(hostname)
        diagnostics['tests'].append({
            'name': 'DNS Resolution',
            'status': 'pass',
            'message': f'Hostname resolved: {hostname}'
        })
    except Exception as e:
        diagnostics['tests'].append({
            'name': 'DNS Resolution',
            'status': 'fail',
            'message': f'Could not resolve hostname: {str(e)}'
        })

    # Test 2: Network Connectivity
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(f"{server_url}/health", method='HEAD')
        start_time = time.time()
        with urllib.request.urlopen(req, timeout=10, context=ctx) as _:  # nosec B310 - diagnostics probes configured server URL only
            latency_ms = int((time.time() - start_time) * 1000)
            diagnostics['tests'].append({
                'name': 'Network Connectivity',
                'status': 'pass',
                'message': f'Connected in {latency_ms}ms'
            })
    except urllib.error.HTTPError as e:
        if e.code == 404:
            diagnostics['tests'].append({
                'name': 'Network Connectivity',
                'status': 'pass',
                'message': 'Network accessible (server returned 404)'
            })
        else:
            diagnostics['tests'].append({
                'name': 'Network Connectivity',
                'status': 'warning',
                'message': f'Server returned {e.code}'
            })
    except Exception as e:
        diagnostics['tests'].append({
            'name': 'Network Connectivity',
            'status': 'fail',
            'message': str(e)
        })

    # Test 3: API Authentication
    basic_result = test_core_server_connection(server_url, api_key)
    if basic_result.get('success'):
        diagnostics['tests'].append({
            'name': 'API Authentication',
            'status': 'pass',
            'message': 'API key accepted'
        })

        # Test 4: Get Server Info
        try:
            diagnostics['tests'].append({
                'name': 'Server Information',
                'status': 'pass',
                'message': f"Server version: {basic_result.get('server_version', 'N/A')}"
            })

            if basic_result.get('status'):
                diagnostics['summary']['server_status'] = basic_result['status']
        except Exception as e:
            diagnostics['tests'].append({
                'name': 'Server Information',
                'status': 'warning',
                'message': str(e)
            })
    else:
        diagnostics['tests'].append({
            'name': 'API Authentication',
            'status': 'fail',
            'message': basic_result.get('error', 'Authentication failed')
        })

    # Calculate summary
    passed = sum(1 for t in diagnostics['tests'] if t['status'] == 'pass')
    failed = sum(1 for t in diagnostics['tests'] if t['status'] == 'fail')
    warning = sum(1 for t in diagnostics['tests'] if t['status'] == 'warning')

    diagnostics['summary'] = {
        'total_tests': len(diagnostics['tests']),
        'passed': passed,
        'failed': failed,
        'warning': warning,
        'overall_status': 'healthy' if failed == 0 else ('degraded' if warning > 0 else 'unhealthy')
    }

    return jsonify({'success': True, **diagnostics})


@app.route('/api/run', methods=['POST'])
@limiter.limit(os.environ.get('AUDIT_RATE_LIMIT', '10/minute'))
@login_required
def run_audit():
    """Start an audit run."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Manual audit execution')

    data = request.get_json() or {}
    audit_path = data.get('audit_path')

    if not audit_path:
        return jsonify({'error': 'audit_path required'}), 400

    full_path = resolve_requested_audit_path(audit_path, AUDIT_DIR)
    if not full_path:
        return jsonify({'error': 'Audit not found'}), 404

    # License check: determine category from path and verify it's allowed
    # Path format: windows/<category>/... or linux/<category>/... in standalone mode
    audit_category = extract_audit_category(audit_path)
    audit_filename = full_path.name

    if not is_script_allowed_for_standalone(
        audit_filename,
        audit_category,
        STANDALONE_MODE,
        license_manager,
    ):
        license_status = license_manager.get_license_status()
        return jsonify({
            'error': f'Category "{audit_category}" requires {TIER_PROFESSIONAL} license',
            'license_required': True,
            'current_tier': license_status['tier']
        }), 403

    job_id = f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{full_path.stem}"

    running_jobs[job_id] = {
        'job_id': job_id,
        'audit_path': str(full_path.relative_to(Path(AUDIT_DIR).parent)),
        'audit_name': full_path.stem.replace('-', ' ').replace('_', ' ').title(),
        'status': 'queued',
        'queued_at': datetime.now().isoformat()
    }

    thread = threading.Thread(
        target=run_audit_async,
        args=(job_id, str(full_path), running_jobs[job_id]['audit_name'])
    )
    thread.daemon = True
    thread.start()

    return jsonify({'job_id': job_id, 'status': 'queued'})


@app.route('/api/run-category', methods=['POST'])
@limiter.limit(os.environ.get('AUDIT_RATE_LIMIT', '10/minute'))
@login_required
def run_category():
    """Run all audits in a category (rate limited)."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Manual category execution')

    data = request.get_json() or {}
    category = data.get('category')
    subcategory = data.get('subcategory')

    if not category:
        return jsonify({'error': 'category required'}), 400

    categories = get_audit_categories(include_locked=False)
    if category not in categories:
        return jsonify({'error': 'Category not found'}), 404

    job_ids = []
    audits_to_run = []

    if subcategory:
        if subcategory in categories[category]['subcategories']:
            audits_to_run = categories[category]['subcategories'][subcategory]['audits']
    else:
        for subcat in categories[category]['subcategories'].values():
            audits_to_run.extend(subcat['audits'])

    for audit in audits_to_run:
        if not is_script_allowed_for_standalone(
            audit['filename'],
            category,
            STANDALONE_MODE,
            license_manager,
        ):
            continue

        job_id = f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{script_stem(audit['filename'])}"

        running_jobs[job_id] = {
            'job_id': job_id,
            'audit_path': audit['relative'],
            'audit_name': audit['name'],
            'status': 'queued',
            'queued_at': datetime.now().isoformat()
        }

        thread = threading.Thread(
            target=run_audit_async,
            args=(job_id, audit['path'], audit['name'])
        )
        thread.daemon = True
        thread.start()

        job_ids.append(job_id)
        time.sleep(0.1)

    if not job_ids:
        return jsonify({'error': 'No audits in this category are allowed by the current license'}), 403

    return jsonify({'job_ids': job_ids, 'count': len(job_ids)})


@app.route('/api/run-basic-scan', methods=['POST'])
@login_required
def run_basic_scan():
    """
    Run basic host-only security scan.

    This runs only core host security audits from advanced-controls:
    - User account security
    - Password policies
    - File permissions
    - Logging and auditing
    - Kernel hardening
    - Sudo configuration
    """
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local basic scan execution')

    # Define basic host-only audits (advanced-controls category)
    basic_audit_patterns = [
        'user-account',
        'shadow-password',
        'pam-password',
        'pam-account',
        'file-permissions',
        'logging',
        'auditd',
        'journald',
        'kernel-hardening',
        'sudo',
        'cron-permissions',
    ]

    categories = get_audit_categories(include_locked=False)
    job_ids = []

    # Look for audits matching basic patterns
    for cat_name, cat in categories.items():
        for subcat in cat['subcategories'].values():
            for audit in subcat['audits']:
                filename_lower = audit['filename'].lower()
                # Use comprehensive license check
                is_allowed = is_script_allowed_for_standalone(
                    audit['filename'],
                    cat_name,
                    STANDALONE_MODE,
                    license_manager,
                )

                # Check if this audit matches any basic pattern
                if any(pattern in filename_lower for pattern in basic_audit_patterns):
                    if not is_allowed:
                        continue

                    job_id = f"basic_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{script_stem(audit['filename'])}"

                    running_jobs[job_id] = {
                        'job_id': job_id,
                        'audit_path': audit['relative'],
                        'audit_name': audit['name'],
                        'status': 'queued',
                        'queued_at': datetime.now().isoformat(),
                        'scan_type': 'basic'
                    }

                    thread = threading.Thread(
                        target=run_audit_async,
                        args=(job_id, audit['path'], audit['name'])
                    )
                    thread.daemon = True
                    thread.start()

                    job_ids.append(job_id)
                    time.sleep(0.1)

    if not job_ids:
        return jsonify({'success': False, 'error': 'No basic audits found'}), 404

    return jsonify({'success': True, 'job_ids': job_ids, 'count': len(job_ids)})


@app.route('/api/run-all', methods=['POST'])
@limiter.limit(os.environ.get('AUDIT_RATE_LIMIT', '10/minute'))
@login_required
def run_all_audits():
    """Run ALL available audits (full scan) - respects license restrictions."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local full scan execution')

    categories = get_audit_categories(include_locked=False)
    job_ids = []

    for cat_name, cat in categories.items():
        for subcat in cat['subcategories'].values():
            for audit in subcat['audits']:
                # Use comprehensive license check
                is_allowed = is_script_allowed_for_standalone(
                    audit['filename'],
                    cat_name,
                    STANDALONE_MODE,
                    license_manager,
                )

                if not is_allowed:
                    continue

                job_id = f"full_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{script_stem(audit['filename'])}"

                running_jobs[job_id] = {
                    'job_id': job_id,
                    'audit_path': audit['relative'],
                    'audit_name': audit['name'],
                    'status': 'queued',
                    'queued_at': datetime.now().isoformat(),
                    'scan_type': 'full'
                }

                thread = threading.Thread(
                    target=run_audit_async,
                    args=(job_id, audit['path'], audit['name'])
                )
                thread.daemon = True
                thread.start()

                job_ids.append(job_id)
                time.sleep(0.1)

    if not job_ids:
        return jsonify({'success': False, 'error': 'No audits found'}), 404

    return jsonify({'success': True, 'job_ids': job_ids, 'count': len(job_ids)})


@app.route('/api/jobs')
@login_required
def list_jobs():
    """List all jobs."""
    return jsonify(list(running_jobs.values()))


@app.route('/api/jobs/<job_id>')
@login_required
def get_job(job_id):
    """Get job status."""
    if job_id not in running_jobs:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(running_jobs[job_id])


@app.route('/api/results/<job_id>')
@login_required
def api_result(job_id):
    """Get result as JSON."""
    result_file = Path(RESULTS_DIR) / f"{job_id}.json"

    if not result_file.exists():
        return jsonify({'error': 'Result not found'}), 404

    return jsonify(load_result_payload(result_file))


@app.route('/api/results/<job_id>/export', methods=['POST'])
@login_required
def api_export_result(job_id):
    """Export a result to core server with hardened security (Phase 2, 3)."""
    result_file = Path(RESULTS_DIR) / f"{job_id}.json"

    if not result_file.exists():
        return jsonify({'error': 'Result not found'}), 404

    # Phase 2: Decrypt result if encrypted
    if results_encryption and results_encryption.enabled:
        result_data = results_encryption.decrypt_result(result_file)
        if result_data is None:
            # Try to load as plaintext fallback
            try:
                with open(result_file) as f:
                    result_data = json.load(f)
            except Exception as e:
                audit_logger.log_security_event("RESULT_DECRYPTION_FAILED", str(e))
                return jsonify({'error': 'Could not decrypt result'}), 500
    else:
        with open(result_file) as f:
            result_data = json.load(f)

    export_result = export_result_to_server(result_data)

    # Update result file with export status
    result_data['export_status'] = export_result
    result_data['exported_at'] = datetime.now().isoformat()

    # Phase 2: Re-encrypt result if encryption enabled
    if has_disk_headroom(Path(RESULTS_DIR), load_config(), 'result export-status storage'):
        if results_encryption and results_encryption.enabled:
            results_encryption.encrypt_result(result_data, result_file)
        else:
            with open(result_file, 'w') as f:
                json.dump(result_data, f, indent=2)
            # Phase 1: Enforce file permissions
            FileSecurityManager.set_secure_permissions(result_file)
    else:
        logger.warning('Skipping export-status persistence due to low disk headroom')

    return jsonify(export_result)


@app.route('/api/results/<job_id>/download')
@login_required
def download_result(job_id):
    """Download result file with decryption support (Phase 2)."""
    result_file = Path(RESULTS_DIR) / f"{job_id}.json"

    if not result_file.exists():
        return jsonify({'error': 'Result not found'}), 404

    # Phase 2: Decrypt if encrypted
    if results_encryption and results_encryption.enabled:
        result_data = results_encryption.decrypt_result(result_file)
        if result_data is None:
            return jsonify({'error': 'Could not decrypt result'}), 500

        # Send decrypted data as JSON
        return jsonify(result_data)

    # Plain download
    return send_file(result_file, as_attachment=True)


@app.route('/api/schedules', methods=['GET', 'POST'])
@login_required
def api_schedules():
    """List or create schedules."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local schedule management')

    if request.method == 'GET':
        return jsonify(load_schedules())

    try:
        data = request.get_json() or {}
        schedules = load_schedules()

        schedule = {
            'id': f"schedule-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'name': data.get('name', 'New Schedule'),
            'frequency': data.get('frequency', 'daily'),
            'time': data.get('time', '02:00'),
            'day_of_week': data.get('day_of_week', 0),
            'day_of_month': data.get('day_of_month', 1),
            'category': data.get('category'),
            'audit_path': data.get('audit_path'),
            'selected_scripts': data.get('selected_scripts', []),  # List of script paths
            'selection_mode': data.get('selection_mode', 'all'),  # 'all', 'category', 'custom'
            'enabled': data.get('enabled', True),
            'created_at': datetime.now().isoformat()
        }

        schedules['schedules'].append(schedule)
        save_schedules(schedules)

        if schedule['enabled']:
            install_cron_schedule(schedule)

        return jsonify({'success': True, 'schedule': schedule})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules/<schedule_id>', methods=['GET'])
@login_required
def api_get_schedule(schedule_id):
    """Get a single schedule by ID."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local schedule management')

    try:
        schedules = load_schedules()
        for schedule in schedules['schedules']:
            if schedule.get('id') == schedule_id:
                return jsonify({'success': True, 'schedule': schedule})
        return jsonify({'success': False, 'error': 'Schedule not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules/<schedule_id>', methods=['PUT'])
@login_required
def api_update_schedule(schedule_id):
    """Update an existing schedule."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local schedule management')

    try:
        data = request.get_json() or {}
        schedules = load_schedules()
        updated = False

        for i, schedule in enumerate(schedules['schedules']):
            if schedule.get('id') == schedule_id:
                # Preserve ID and created_at, update everything else
                schedules['schedules'][i] = {
                    'id': schedule_id,
                    'name': data.get('name', schedule.get('name', 'Schedule')),
                    'frequency': data.get('frequency', schedule.get('frequency', 'daily')),
                    'time': data.get('time', schedule.get('time', '02:00')),
                    'day_of_week': data.get('day_of_week', schedule.get('day_of_week', 0)),
                    'day_of_month': data.get('day_of_month', schedule.get('day_of_month', 1)),
                    'category': data.get('category', schedule.get('category')),
                    'audit_path': data.get('audit_path', schedule.get('audit_path')),
                    'selected_scripts': data.get('selected_scripts', schedule.get('selected_scripts', [])),
                    'selection_mode': data.get('selection_mode', schedule.get('selection_mode', 'all')),
                    'enabled': data.get('enabled', schedule.get('enabled', True)),
                    'created_at': schedule.get('created_at', datetime.now().isoformat()),
                    'updated_at': datetime.now().isoformat()
                }
                updated = True

                # Reinstall cron if enabled changed or schedule modified
                if schedules['schedules'][i]['enabled']:
                    remove_cron_schedule(schedule_id)
                    install_cron_schedule(schedules['schedules'][i])
                else:
                    remove_cron_schedule(schedule_id)
                break

        if not updated:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        save_schedules(schedules)
        return jsonify({'success': True, 'schedule': schedules['schedules'][i]})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules/<schedule_id>', methods=['DELETE'])
@login_required
def api_delete_schedule(schedule_id):
    """Delete a schedule."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local schedule management')

    try:
        schedules = load_schedules()
        schedules['schedules'] = [s for s in schedules['schedules'] if s.get('id') != schedule_id]
        save_schedules(schedules)

        remove_cron_schedule(schedule_id)

        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules/<schedule_id>/toggle', methods=['POST'])
@login_required
def api_toggle_schedule(schedule_id):
    """Enable/disable a schedule."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Local schedule management')

    try:
        schedules = load_schedules()

        for schedule in schedules['schedules']:
            if schedule.get('id') == schedule_id:
                schedule['enabled'] = not schedule.get('enabled', True)

                if schedule['enabled']:
                    install_cron_schedule(schedule)
                else:
                    remove_cron_schedule(schedule_id)
                break

        save_schedules(schedules)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/system')
@login_required
def api_system_basic():
    """Get basic system information (authenticated)."""
    return jsonify(get_system_info())


# ============================================================================
# Agent API Endpoints (for core server communication)
# ============================================================================

@app.route('/api/agent/register', methods=['POST'])
def agent_register():
    """Deprecated: standalone agent no longer accepts central orchestration registration."""
    return jsonify({
        'success': False,
        'error': 'Deprecated endpoint',
        'details': 'Standalone agent orchestration endpoints are disabled. Use fleet-agent APIs for central registration and orchestration.'
    }), 410


@app.route('/api/agent/status')
def agent_status():
    """Deprecated: standalone agent no longer exposes central status polling endpoint."""
    return jsonify({
        'success': False,
        'error': 'Deprecated endpoint',
        'details': 'Standalone agent orchestration endpoints are disabled. Use fleet-agent APIs for central status and orchestration.'
    }), 410


@app.route('/api/agent/run', methods=['POST'])
def agent_run_command():
    """Deprecated: standalone agent no longer accepts centrally triggered run commands."""
    return jsonify({
        'success': False,
        'error': 'Deprecated endpoint',
        'details': 'Standalone agent orchestration endpoints are disabled. Use fleet-agent APIs for central execution.'
    }), 410


# ============================================================================
# Setup Script Downloads
# ============================================================================

@app.route('/api/setup-scripts/jea')
@login_required
def download_jea_script():
    """Download JEA setup script for Windows."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Privilege escalation setup scripts')

    try:
        jea_script = APP_DIR / 'jea' / 'setup-jea.ps1'
        if jea_script.exists():
            return send_file(
                jea_script,
                mimetype='text/plain',
                as_attachment=True,
                download_name='setup-jea.ps1'
            )
        else:
            return jsonify({'error': 'JEA setup script not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/setup-scripts/linux-root')
@login_required
def download_linux_root_script():
    """Download root installation script for Linux."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Privilege escalation setup scripts')

    try:
        script = APP_DIR / 'install-linux.sh'
        if script.exists():
            return send_file(
                script,
                mimetype='text/x-shellscript',
                as_attachment=True,
                download_name='install-linux.sh'
            )
        else:
            return jsonify({'error': 'Linux root installer not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/setup-scripts/linux-user')
@login_required
def download_linux_user_script():
    """Download user-mode installation script for Linux."""
    if MANAGED_AGENT_SETUP_ONLY:
        return _managed_mode_blocked_response('Privilege escalation setup scripts')

    try:
        script = APP_DIR / 'install-user.sh'
        if script.exists():
            return send_file(
                script,
                mimetype='text/x-shellscript',
                as_attachment=True,
                download_name='install-user.sh'
            )
        else:
            return jsonify({'error': 'Linux user installer not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/setup-scripts/jea-psrc/<role>')
@login_required
def download_jea_psrc(role):
    """Download JEA Role Capability file."""
    try:
        valid_roles = {
            'full': 'AuditAgent.Full.psrc',
            'readonly': 'AuditAgent.ReadOnly.psrc'
        }

        if role not in valid_roles:
            return jsonify({'error': 'Invalid role. Use: full, readonly'}), 400

        psrc_file = APP_DIR / 'jea' / valid_roles[role]
        if psrc_file.exists():
            return send_file(
                psrc_file,
                mimetype='text/plain',
                as_attachment=True,
                download_name=valid_roles[role]
            )
        else:
            return jsonify({'error': f'Role capability file not found: {role}'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/setup-scripts/jea-pssc')
@login_required
def download_jea_pssc():
    """Download JEA Session Configuration file."""
    try:
        pssc_file = APP_DIR / 'jea' / 'AuditAgent.pssc'
        if pssc_file.exists():
            return send_file(
                pssc_file,
                mimetype='text/plain',
                as_attachment=True,
                download_name='AuditAgent.pssc'
            )
        else:
            return jsonify({'error': 'Session configuration file not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# License Management API
# ============================================================================

@app.route('/api/license')
@login_required
def get_license_api():
    """Get current license status."""
    return jsonify(license_manager.get_license_status())


@app.route('/api/license/activate', methods=['POST'])
@login_required
def activate_license_api():
    """License activation is handled by the Core Server — not available on this agent."""
    return _managed_mode_blocked_response('License activation')


@app.route('/api/license/deactivate', methods=['POST'])
@login_required
def deactivate_license_api():
    """License deactivation is handled by the Core Server — not available on this agent."""
    return _managed_mode_blocked_response('License deactivation')


@app.route('/api/license/refresh', methods=['POST'])
@login_required
def refresh_license_api():
    """
    Refresh license from Core Server.

    If connected to a licensed Core Server, this will request a fresh
    delegated license. Useful when:
    - First connecting to Core Server
    - Core Server license was upgraded
    - Agent slot assignment changed
    """
    try:
        # Force refresh of delegated license
        license_data = license_manager.refresh_delegated_license()

        return jsonify({
            'success': True,
            'license': license_manager.get_license_status(),
            'message': f"License refreshed: {license_data.get('validation_message', '')}",
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
        }), 500


# ============================================================================
# Script Update API (Business+ only)
# ============================================================================

@app.route('/api/updates/settings', methods=['GET', 'POST'])
@login_required
def script_update_settings_api():
    """Get or update script update settings."""
    if request.method == 'GET':
        if not license_manager.is_feature_enabled('script_updates'):
            return jsonify({
                'error': 'Script updates require Business or Professional license',
                'upgrade_required': True,
            }), 403

        settings = script_update_manager.get_update_settings()
        return jsonify(settings)

    else:  # POST
        if not license_manager.is_feature_enabled('script_updates'):
            return jsonify({
                'success': False,
                'error': 'Script updates require Business or Professional license',
                'upgrade_required': True,
            }), 403

        try:
            data = request.get_json() or {}
            settings = script_update_manager.get_update_settings()

            # Update only provided fields
            if 'mode' in data:
                settings['mode'] = data['mode']
            if 'schedule_frequency' in data:
                settings['schedule_frequency'] = data['schedule_frequency']
            if 'schedule_day' in data:
                settings['schedule_day'] = data['schedule_day']
            if 'schedule_time' in data:
                settings['schedule_time'] = data['schedule_time']
            if 'auto_apply' in data:
                settings['auto_apply'] = data['auto_apply']

            if script_update_manager.save_update_settings(settings):
                return jsonify({
                    'success': True,
                    'settings': settings,
                })
            else:
                return jsonify({
                    'success': False,
                    'error': 'Failed to save settings',
                }), 500

        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e),
            }), 500


@app.route('/api/updates/check', methods=['POST'])
@login_required
def check_for_updates_api():
    """Check for available script updates from Core Server."""
    if not license_manager.is_feature_enabled('script_updates'):
        return jsonify({
            'success': False,
            'error': 'Script updates require Business or Professional license',
            'upgrade_required': True,
        }), 403

    try:
        config = load_config()
        server_url = config.get('core_server_url')
        api_key = config.get('api_key')

        if not server_url:
            return jsonify({
                'success': False,
                'error': 'Core Server URL not configured. Configure in Settings.',
            }), 400

        result = script_update_manager.check_for_updates(server_url, api_key)
        return jsonify(result)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
        }), 500


@app.route('/api/updates/download', methods=['POST'])
@login_required
def download_updates_api():
    """Download and apply script updates from Core Server."""
    if not license_manager.is_feature_enabled('script_updates'):
        return jsonify({
            'success': False,
            'error': 'Script updates require Business or Professional license',
            'upgrade_required': True,
        }), 403

    try:
        config = load_config()
        server_url = config.get('core_server_url')
        api_key = config.get('api_key')

        if not server_url:
            return jsonify({
                'success': False,
                'error': 'Core Server URL not configured.',
            }), 400

        result = script_update_manager.download_updates(server_url, api_key)
        return jsonify(result)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
        }), 500


# ============================================================================
# Rate Limiting Error Handler (Phase A3)
# ============================================================================

@app.errorhandler(429)
def ratelimit_handler(e):
    """Handle rate limit exceeded errors."""
    if request.path.startswith('/api/'):
        return jsonify({
            'success': False,
            'error': 'Rate limit exceeded. Please try again later.'
        }), 429
    return "Rate limit exceeded. Please try again later.", 429


if __name__ == '__main__':
    bind_host = DEFAULT_BIND_HOST
    if ALLOW_REMOTE_UI or not LOCAL_ONLY_MODE:
        bind_host = os.environ.get('BIND_HOST', '0.0.0.0')  # nosec B104 - configurable deployment bind host
    debug_mode = os.environ.get('FLASK_DEBUG', 'false').lower() in ('1', 'true', 'yes')
    app.run(host=bind_host, port=DEFAULT_PORT, debug=debug_mode)
