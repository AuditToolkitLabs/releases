"""
Standalone Agent Licensing Module

Implements tiered licensing:
- Community: Free forever, unlimited agents, baseline audits only, HTML output
- Starter: Paid entry tier, core categories, Core Server integration
- Business: Paid mid tier, expanded categories and automation
- Professional: Top tier, full categories and custom audits

License Sources (in priority order):
1. Local license key (activated directly on agent)
2. Core Server delegated license (inherited from Core's license)
3. Default to Community (free forever)

All tiers: HTML output only at agent level. JSON/CSV/PDF via Core Server.
"""

import os
import json
import hashlib
import platform
import shutil
import uuid
import socket
import urllib.request
import urllib.error
import ssl
import hmac
import base64
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any

# License tiers
TIER_COMMUNITY = 'community'
TIER_STARTER = 'starter'
TIER_BUSINESS = 'business'
TIER_PROFESSIONAL = 'professional'

# License source types
LICENSE_SOURCE_LOCAL = 'local'          # Activated directly on agent
LICENSE_SOURCE_CORE = 'core_server'     # Delegated from Core Server
LICENSE_SOURCE_DEFAULT = 'default'       # Community fallback


def detect_host_distro() -> str:
    """
    Detect the host distribution from /etc/os-release.

    Returns lowercase distro ID (e.g., 'alpine', 'ubuntu', 'debian', 'rhel', 'fedora', 'arch').
    Falls back to 'unknown' if detection fails.
    """
    os_release_paths = ['/etc/os-release', '/usr/lib/os-release']

    for path in os_release_paths:
        try:
            with open(path, 'r') as f:
                for line in f:
                    if line.startswith('ID='):
                        distro_id = line.strip().split('=')[1].strip('"\'').lower()
                        return distro_id
        except (FileNotFoundError, PermissionError, IOError):
            continue

    return 'unknown'


def get_distro_specific_categories() -> list:
    """
    Get audit categories specific to the detected host distribution.

    This allows Community tier to run distro-specific baseline audits.
    On Windows, returns the Windows-specific community categories instead
    of reading /etc/os-release (which does not exist on Windows).
    """
    # Windows has its own category layout: common/ server/ desktop/ apps/
    # Detect via platform.system() rather than /etc/os-release.
    if platform.system().lower() == 'windows':
        # 'common' is the Windows equivalent of the Linux baseline category set.
        return ['common']

    distro = detect_host_distro()

    # Map distro IDs to their audit category folder names
    # Some distros may have their own top-level category folder
    distro_categories = []

    # Known distro-specific top-level categories
    known_distro_categories = ['alpine', 'arch', 'debian', 'ubuntu', 'rhel', 'fedora', 'opensuse', 'centos', 'rocky', 'alma']

    if distro in known_distro_categories:
        distro_categories.append(distro)

    # Also include related distros (e.g., Ubuntu is Debian-based)
    distro_families = {
        'ubuntu': ['debian'],
        'linuxmint': ['debian', 'ubuntu'],
        'pop': ['debian', 'ubuntu'],
        'rocky': ['rhel'],
        'alma': ['rhel', 'almalinux'],
        'centos': ['rhel'],
        'fedora': ['rhel'],
        'opensuse-leap': ['opensuse'],
        'opensuse-tumbleweed': ['opensuse'],
    }

    if distro in distro_families:
        distro_categories.extend(distro_families[distro])

    return list(set(distro_categories))  # Remove duplicates


# Base Community audit categories (always available)
BASE_COMMUNITY_AUDIT_CATEGORIES = [
    'platform',     # baseline hardening, users, updates
    'network',      # firewall, SSH, ports
]

# Dynamically add detected distro categories
COMMUNITY_AUDIT_CATEGORIES = BASE_COMMUNITY_AUDIT_CATEGORIES + get_distro_specific_categories()

# Baseline audit script patterns - these are allowed in Community tier even from locked categories
# These patterns match critical security audits that should run on any server
BASELINE_AUDIT_PATTERNS = [
    # User and access security (Linux)
    'user-account', 'shadow-password', 'pam-password', 'pam-account',
    'sudo', 'ssh-', 'sshd-',
    # File system security
    'file-permissions', 'world-writable', 'suid-sgid',
    # Logging and auditing
    'logging', 'auditd', 'journald', 'syslog',
    # Kernel and system hardening
    'kernel-hardening', 'sysctl',
    # Cron security
    'cron-permissions',
    # Basic service security
    'service-accounts',
    # Windows-specific baselines (allows cross-category pass-through on Windows)
    'password_policy', 'account_lockout', 'audit_policy', 'user_rights',
    'firewall_audit', 'windows_firewall', 'defender_av', 'defender_audit',
    'bitlocker', 'secure_boot', 'uac', 'credential_guard',
    'patch_level', 'os_version', 'exploit_guard', 'lsass_protection',
]

# Always-allowed scripts - these run under ANY license including Community
# Discovery/asset management is essential for understanding what needs to be audited
ALWAYS_ALLOWED_SCRIPTS = [
    'discovery',           # System discovery and audit recommendation
    'asset-discovery',     # Asset inventory collection
    'inventory',           # Software/package inventory
    'system-info',         # Basic system information
    'package-list',        # Installed packages
    'service-list',        # Running services
    'port-scan',           # Open ports discovery
    'baseline-check',      # Basic baseline verification
]

# Starter tier - adds web/data (Linux) and server-role/desktop audits (Windows)
STARTER_AUDIT_CATEGORIES = COMMUNITY_AUDIT_CATEGORIES + [
    'web',          # Nginx, Apache (primary web security)
    'data',         # MySQL, PostgreSQL (primary databases)
    'server',       # Windows Server roles (AD, IIS, DHCP, DNS, etc.)
    'desktop',      # Windows desktop/browser application security
]

# Business unlocks expanded standard audit categories.
# Professional extends this with hypervisors, compliance, and custom categories.
BUSINESS_AUDIT_CATEGORIES = list(set(STARTER_AUDIT_CATEGORIES + [
    'apps',                # containers, app-layer services
    'storage',             # file permissions, encryption
    'automation',          # cron, scheduled tasks
    'advanced-controls',   # deeper hardening checks
    'cloud',               # cloud guest/agent checks
    'security',            # EDR/SIEM/secrets integrations
    'virtualization',      # virtualization host checks
    'alpine', 'arch', 'debian', 'ubuntu', 'rhel', 'fedora', 'opensuse', 'centos',
    'rocky', 'alma',
    'linux', 'windows',
]))

PROFESSIONAL_AUDIT_CATEGORIES = list(set(BUSINESS_AUDIT_CATEGORIES + [
    'hypervisors',         # special appliance/linux hypervisor class
    'compliance',   # CIS, NIST, custom frameworks
    'custom',       # user-defined audits
]))


def get_required_tier_for_category(category: str) -> str:
    """Return the minimum license tier required for a category."""
    if category in COMMUNITY_AUDIT_CATEGORIES:
        return TIER_COMMUNITY
    if category in STARTER_AUDIT_CATEGORIES:
        return TIER_STARTER
    if category in BUSINESS_AUDIT_CATEGORIES:
        return TIER_BUSINESS
    if category in PROFESSIONAL_AUDIT_CATEGORIES:
        return TIER_PROFESSIONAL
    # Unknown categories default to Professional requirement.
    return TIER_PROFESSIONAL

# Feature flags by tier
TIER_FEATURES = {
    TIER_COMMUNITY: {
        'audit_categories': COMMUNITY_AUDIT_CATEGORIES,
        'max_agents': float('inf'),  # Unlimited
        'core_server_integration': False,
        'script_updates': False,
        'scheduled_updates': False,
        'html_output': True,
        'json_output': False,
        'csv_output': False,
        'pdf_output': False,
        'api_access': False,
        'scheduling': True,  # Basic scheduling allowed
        'max_schedules': 3,
        'results_retention_days': 30,
        'watermark': True,
        'upgrade_prompts': True,
    },
    TIER_STARTER: {
        'audit_categories': STARTER_AUDIT_CATEGORIES,
        'max_agents': 50,
        'core_server_integration': True,
        'script_updates': True,
        'scheduled_updates': False,
        'html_output': True,
        'json_output': False,
        'csv_output': False,
        'pdf_output': False,
        'api_access': False,
        'scheduling': True,
        'max_schedules': 10,
        'results_retention_days': 90,
        'watermark': True,
        'upgrade_prompts': True,
    },
    TIER_BUSINESS: {
        'audit_categories': BUSINESS_AUDIT_CATEGORIES,
        'max_agents': 150,
        'core_server_integration': True,
        'script_updates': True,
        'scheduled_updates': True,
        'html_output': True,
        'json_output': False,
        'csv_output': False,
        'pdf_output': False,
        'api_access': False,
        'scheduling': True,
        'max_schedules': float('inf'),
        'results_retention_days': float('inf'),
        'watermark': False,
        'upgrade_prompts': False,
    },
    TIER_PROFESSIONAL: {
        'audit_categories': PROFESSIONAL_AUDIT_CATEGORIES,
        'max_agents': float('inf'),
        'core_server_integration': True,
        'script_updates': True,
        'scheduled_updates': True,
        'html_output': True,
        'json_output': False,
        'csv_output': False,
        'pdf_output': False,
        'api_access': True,
        'scheduling': True,
        'max_schedules': float('inf'),
        'results_retention_days': float('inf'),
        'watermark': False,
        'upgrade_prompts': False,
        'custom_audits': True,
    },
}


class LicenseManager:
    """Manages license validation and feature gating."""

    def __init__(self, config_dir: Path, get_core_config: callable = None):
        """
        Initialize LicenseManager.

        Args:
            config_dir: Path to config directory
            get_core_config: Optional callback to get Core Server config.
                             Should return dict with 'core_server_url' and 'api_key'.
        """
        self.config_dir = Path(config_dir)
        self.license_file = self.config_dir / 'license.json'
        self.delegated_license_file = self.config_dir / 'delegated-license.json'
        self._get_core_config = get_core_config
        self._license_cache: Optional[Dict] = None
        self._cache_time: Optional[datetime] = None
        self._cache_duration = timedelta(minutes=5)

    def get_hardware_fingerprint(self) -> str:
        """Generate a hardware fingerprint for license binding."""
        components = []

        # Machine ID / hostname
        components.append(platform.node())

        # Platform info
        components.append(platform.system())
        components.append(platform.machine())

        # Try to get more unique identifiers
        if platform.system().lower() == 'windows':
            # Windows: read the stable MachineGuid from the registry.
            # This is the Windows equivalent of /etc/machine-id and survives reboots.
            try:
                import winreg
                key = winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE,
                    r'SOFTWARE\Microsoft\Cryptography',
                )
                machine_guid, _ = winreg.QueryValueEx(key, 'MachineGuid')
                winreg.CloseKey(key)
                if machine_guid:
                    components.append(str(machine_guid))
            except Exception:
                pass
        else:
            # Linux / macOS: read /etc/machine-id or dbus equivalent.
            try:
                machine_id_paths = [
                    '/etc/machine-id',
                    '/var/lib/dbus/machine-id',
                ]
                for path in machine_id_paths:
                    if os.path.exists(path):
                        with open(path, 'r') as f:
                            components.append(f.read().strip())
                        break
            except Exception:
                pass

        try:
            # MAC address — supplementary identifier on all platforms.
            # uuid.getnode() can return a random value if no real MAC is found;
            # call it twice and only use it when both calls agree.
            mac_a = uuid.getnode()
            mac_b = uuid.getnode()
            if mac_a == mac_b:
                components.append(str(mac_a))
        except Exception:
            pass

        # Create fingerprint hash
        fingerprint_data = '|'.join(components)
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:32]

    def _get_local_ipv4_addresses(self) -> set[str]:
        """Collect local IPv4 addresses for optional license host binding checks."""
        addresses: set[str] = set()

        try:
            hostname = socket.gethostname()
            for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
                ip = info[4][0]
                if ip:
                    addresses.add(ip)
        except Exception:
            pass

        # Loopback is always valid for local-only operation.
        addresses.add('127.0.0.1')
        return addresses

    def _matches_host_binding(self, license_data: Dict[str, Any]) -> bool:
        """Validate optional host-binding attributes when present."""
        bound_hostname = str(license_data.get('bound_hostname') or '').strip().lower()
        if bound_hostname and bound_hostname != platform.node().strip().lower():
            return False

        bound_mac = str(license_data.get('bound_mac') or '').strip().lower()
        if bound_mac:
            current_mac = format(uuid.getnode(), '012x')
            normalized_mac = ''.join(ch for ch in bound_mac if ch.isalnum())
            if normalized_mac != current_mac.lower():
                return False

        bound_ip = str(license_data.get('bound_ip') or '').strip()
        if bound_ip:
            if bound_ip not in self._get_local_ipv4_addresses():
                return False

        return True

    def _validate_delegated_license(self, license_data: Dict[str, Any]) -> bool:
        """Validate delegated license payload from Core Server."""
        if not license_data:
            return False

        tier = str(license_data.get('tier', TIER_COMMUNITY)).lower()
        is_paid_tier = tier in (TIER_STARTER, TIER_BUSINESS, TIER_PROFESSIONAL)

        # Paid delegated licenses must always include explicit expiry.
        if is_paid_tier and not license_data.get('expires_at'):
            return False

        if self._is_license_expired(license_data):
            return False

        # Optional host binding fields from Core-issued delegated licenses.
        if not self._matches_host_binding(license_data):
            return False

        return True

    def get_license(self) -> Dict[str, Any]:
        """
        Get current license information.

        Priority order:
        1. Delegated license from Core Server (when connected)
        2. Local license key (activated directly on agent)
        3. Default Community license
        """
        # Check cache
        if self._license_cache and self._cache_time:
            if datetime.now() - self._cache_time < self._cache_duration:
                return self._license_cache

        # 1. Check delegated license from Core Server first.
        # Standalone is primarily an extension of Core and should inherit
        # Core licensing when connected.
        delegated = self._get_delegated_license()
        if delegated and delegated.get('tier') != TIER_COMMUNITY and self._validate_delegated_license(delegated):
            self._license_cache = delegated
            self._cache_time = datetime.now()
            return delegated

        # 2. Fall back to local license if present.
        if self.license_file.exists():
            try:
                with open(self.license_file, 'r') as f:
                    license_data = json.load(f)
                    # Validate license
                    if self._validate_license(license_data):
                        license_data['license_source'] = LICENSE_SOURCE_LOCAL
                        self._license_cache = license_data
                        self._cache_time = datetime.now()
                        return license_data
            except Exception:
                pass

        # 3. Default to Community
        return self._get_community_license()

    def _get_delegated_license(self) -> Optional[Dict[str, Any]]:
        """
        Request or validate delegated license from Core Server.

        The Core Server tracks which agents are connected and provides
        a delegated license based on the Core's own license tier.
        """
        # Get Core Server config
        if not self._get_core_config:
            return None

        try:
            core_config = self._get_core_config()
        except Exception:
            return None

        if not core_config:
            return None

        server_url = core_config.get('core_server_url')
        api_key = core_config.get('api_key')

        if not server_url:
            return None

        # Check cached delegated license first (reduces API calls)
        cached_license: Optional[Dict[str, Any]] = None
        if self.delegated_license_file.exists():
            try:
                with open(self.delegated_license_file, 'r') as f:
                    cached = json.load(f)
                    # Verify cached license belongs to same core server.
                    if cached.get('core_server_url') == server_url:
                        cached_license = cached

                    # If cached delegated license is fresh and valid, return immediately.
                    if (
                        cached_license
                        and self._validate_delegated_license(cached_license)
                        and self._is_delegated_cache_fresh(cached_license, core_config)
                    ):
                        return cached_license
            except Exception:
                pass

        # Request fresh delegated license from Core Server
        try:
            delegated = self._request_delegated_license(server_url, api_key)
            if delegated and delegated.get('success'):
                license_data = {
                    'tier': delegated.get('tier', TIER_COMMUNITY),
                    'license_source': LICENSE_SOURCE_CORE,
                    'agent_class': delegated.get('agent_class', 'standalone'),
                    'core_server_url': server_url,
                    'delegated_at': datetime.now().isoformat(),
                    'cached_at': datetime.now().isoformat(),
                    'expires_at': delegated.get('expires_at'),
                    'features': TIER_FEATURES.get(delegated.get('tier', TIER_COMMUNITY), {}),
                    'is_valid': True,
                    'validation_message': f"Licensed via Core Server ({delegated.get('tier', 'community').title()})",
                    'core_license_id': delegated.get('license_id'),
                    'agent_slot': delegated.get('agent_slot'),
                    'agent_slot_type': delegated.get('agent_slot_type', 'standalone'),
                    'max_agents': delegated.get('max_agents'),
                    'agents_used': delegated.get('agents_used'),
                }

                # Cache the delegated license
                self.config_dir.mkdir(parents=True, exist_ok=True)
                with open(self.delegated_license_file, 'w') as f:
                    json.dump(license_data, f, indent=2)

                if self._validate_delegated_license(license_data):
                    return license_data
        except Exception:
            pass

        # Core server may be temporarily unreachable. If we have a previously
        # delegated license that is still valid, continue to honor it offline.
        if (
            cached_license
            and self._validate_delegated_license(cached_license)
            and self._is_delegated_cache_usable_offline(cached_license, core_config)
        ):
            cached_license['validation_message'] = (
                'Using cached delegated license while Core Server is unreachable'
            )
            cached_license['offline_cached'] = True
            return cached_license

        return None

    def _is_license_expired(self, license_data: Dict[str, Any]) -> bool:
        """Return True when license_data has an expires_at and is already expired."""
        expires_at = license_data.get('expires_at')
        if not expires_at:
            return False

        try:
            return datetime.now() > datetime.fromisoformat(expires_at)
        except Exception:
            return False

    def _is_delegated_cache_fresh(self, cached: Dict[str, Any], core_config: Dict[str, Any]) -> bool:
        """Return True when cached delegated license is fresh enough to reuse directly."""
        if self._is_license_expired(cached):
            return False

        cached_at = cached.get('cached_at')
        refresh_hours = core_config.get('license_refresh_hours', 1) if core_config else 1
        if not cached_at:
            return False

        try:
            cached_time = datetime.fromisoformat(cached_at)
            return datetime.now() - cached_time < timedelta(hours=refresh_hours)
        except Exception:
            return False

    def _is_delegated_cache_usable_offline(self, cached: Dict[str, Any], core_config: Dict[str, Any]) -> bool:
        """Return True when cached delegated license can be used while offline."""
        if self._is_license_expired(cached):
            return False

        # If delegated license has no explicit expiry, allow a bounded offline
        # grace period from the last successful cache timestamp.
        if not cached.get('expires_at'):
            cached_at = cached.get('cached_at')
            if not cached_at:
                return False

            offline_grace_hours = core_config.get('license_offline_grace_hours', 168)
            try:
                cached_time = datetime.fromisoformat(cached_at)
                return datetime.now() - cached_time < timedelta(hours=offline_grace_hours)
            except Exception:
                return False

        return True

    def _request_delegated_license(self, server_url: str, api_key: str = None) -> Optional[Dict]:
        """Request a delegated license from the Core Server."""
        url = f"{server_url.rstrip('/')}/api/v1/agents/license"

        # Build request with agent identification
        request_data = {
            'hardware_id': self.get_hardware_fingerprint(),
            'hostname': platform.node(),
            'agent_version': '6.2.1',
            'agent_class': 'standalone',
        }

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'AuditToolkit-StandaloneAgent/6.2.1',
        }

        if api_key:
            headers['X-API-Key'] = api_key

        try:
            # Create SSL context with proper certificate validation (Phase 1 hardening)
            ctx = ssl.create_default_context()
            ctx.check_hostname = True
            ctx.verify_mode = ssl.CERT_REQUIRED

            req = urllib.request.Request(
                url,
                data=json.dumps(request_data).encode('utf-8'),
                headers=headers,
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=10, context=ctx) as response:  # nosec B310 - URL is validated core-server endpoint
                return json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            # Core Server might return 402 (Payment Required) if no license
            # or 403 (Forbidden) if agent limit reached
            if e.code == 402:
                return {'success': False, 'error': 'Core Server has no active license'}
            elif e.code == 403:
                return {'success': False, 'error': 'Agent limit reached on Core Server'}
            return None
        except Exception:
            return None

    def refresh_delegated_license(self) -> Dict[str, Any]:
        """Force refresh of delegated license from Core Server."""
        # Clear cached delegated license
        if self.delegated_license_file.exists():
            try:
                self.delegated_license_file.unlink()
            except Exception:
                pass

        # Clear memory cache
        self._license_cache = None
        self._cache_time = None

        # Get fresh license
        return self.get_license()

    def _get_community_license(self) -> Dict[str, Any]:
        """Return default Community license."""
        return {
            'tier': TIER_COMMUNITY,
            'license_source': LICENSE_SOURCE_DEFAULT,
            'license_key': None,
            'activated_at': None,
            'expires_at': None,  # Never expires
            'hardware_fingerprint': None,
            'features': TIER_FEATURES[TIER_COMMUNITY],
            'is_valid': True,
            'validation_message': 'Community Edition - Free forever',
        }

    def _validate_license(self, license_data: Dict) -> bool:
        """Validate a license."""
        if not license_data:
            return False

        tier = license_data.get('tier', TIER_COMMUNITY)
        is_paid_tier = tier in (TIER_STARTER, TIER_BUSINESS, TIER_PROFESSIONAL)

        # Community is always valid
        if tier == TIER_COMMUNITY:
            return True

        # Paid licenses must have explicit expiration.
        if is_paid_tier and not license_data.get('expires_at'):
            return False

        # Check expiration for paid tiers
        expires_at = license_data.get('expires_at')
        if expires_at:
            try:
                expiry = datetime.fromisoformat(expires_at)
                if datetime.now() > expiry:
                    return False
            except Exception:
                pass

        # Enforce hardware fingerprint match for paid tiers.
        stored_fingerprint = license_data.get('hardware_fingerprint')
        if is_paid_tier:
            if not stored_fingerprint:
                return False
            current_fingerprint = self.get_hardware_fingerprint()
            if stored_fingerprint != current_fingerprint:
                return False

        # Optional host binding fields can be set by license generator.
        if not self._matches_host_binding(license_data):
            return False

        return True

    def activate_license(self, license_key: str, server_url: str = None) -> Dict[str, Any]:
        """Activate a license key."""
        if not license_key:
            return {
                'success': False,
                'error': 'License key is required',
            }

        # ── Core-generated pre-signed key (ATKS-* format) ─────────────────
        if license_key.upper().startswith('ATKS-'):
            return self._activate_atks_key(license_key, server_url)

        # ── Legacy local key format: TIER-XXXXXXXX-XXXXXXXX-CHECK ─────────
        parts = license_key.upper().split('-')
        if len(parts) != 4:
            return {
                'success': False,
                'error': 'Invalid license key format. Expected a Core-generated ATKS- key or a TIER-XXXX-XXXX-CHECK local key.',
            }

        tier_code = parts[0]
        tier_map = {
            'COM': TIER_COMMUNITY,
            'STA': TIER_STARTER,
            'BUS': TIER_BUSINESS,
            'PROF': TIER_PROFESSIONAL,
            # Backward compatibility with legacy key prefixes.
            'ENT': TIER_PROFESSIONAL,
        }

        tier = tier_map.get(tier_code)
        if not tier:
            return {
                'success': False,
                'error': 'Invalid license tier',
            }

        # Validate with license server if URL provided
        if server_url:
            validation = self._validate_with_server(license_key, server_url)
            if not validation.get('success'):
                return validation

        # Create license data
        fingerprint = self.get_hardware_fingerprint()
        license_data = {
            'tier': tier,
            'license_key': license_key,
            'activated_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(days=365)).isoformat() if tier != TIER_COMMUNITY else None,
            'hardware_fingerprint': fingerprint,
            'features': TIER_FEATURES[tier],
            'is_valid': True,
            'validation_message': f'{tier.title()} Edition activated',
        }

        # Save license
        self.config_dir.mkdir(parents=True, exist_ok=True)
        with open(self.license_file, 'w') as f:
            json.dump(license_data, f, indent=2)

        # Clear cache
        self._license_cache = None

        return {
            'success': True,
            'license': license_data,
        }

    # ──────────────────────────────────────────────────────────────────────────
    # ATKS pre-signed key handling
    # ──────────────────────────────────────────────────────────────────────────

    def _verify_atks_key_hmac(self, payload_b64: str, provided_sig: str) -> bool:
        """
        Verify the HMAC-SHA256 signature of an ATKS key payload.

        Both Core host and standalone must share the same AUDIT_TOKEN_SIGNING_KEY
        environment variable for offline verification to succeed.
        """
        signing_key = os.environ.get(
            'AUDIT_TOKEN_SIGNING_KEY',
            'audit-toolkit-default-signing-key-change-me'
        )
        combined = f"standalone-key:{signing_key}"
        expected = hmac.new(
            combined.encode('utf-8'),
            payload_b64.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()[:32]
        return hmac.compare_digest(expected, provided_sig)

    def _activate_atks_key(self, key_string: str, server_url: str = None) -> Dict[str, Any]:
        """
        Activate a Core-generated pre-signed ATKS- key.

        Online path (preferred):
            Calls the Core's /api/v1/agents/standalone-key/<kid>/redeem endpoint
            to obtain a full delegated license payload, then stores it as a
            delegated license (same as live-connection path).

        Offline fallback:
            Verifies the HMAC signature locally using AUDIT_TOKEN_SIGNING_KEY.
            Stores the decoded payload as a local license so the agent operates
            at the key's tier without needing a Core connection.
        """
        parts = key_string.split('-', 2)  # ['ATKS', payload_b64, sig]
        if len(parts) != 3:
            return {'success': False, 'error': 'Malformed ATKS key (expected ATKS-<payload>-<sig>)'}

        _, payload_b64, provided_sig = parts

        # Decode JSON payload first (needed for core_host extraction regardless of mode)
        try:
            pad = '=' * (-len(payload_b64) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64 + pad).decode('utf-8'))
        except Exception:
            return {'success': False, 'error': 'ATKS key payload could not be decoded'}

        key_id = payload.get('kid', '')
        tier = str(payload.get('tier', TIER_COMMUNITY)).lower()
        expires_at = payload.get('exp')
        core_host = payload.get('ch') or server_url or ''
        label = payload.get('lbl', '')

        # Check key expiry
        if expires_at:
            try:
                if datetime.utcnow() > datetime.strptime(expires_at, '%Y-%m-%dT%H:%M:%SZ'):
                    return {'success': False, 'error': f'This ATKS key expired on {expires_at[:10]}'}
            except ValueError:
                pass

        # ── Online redemption ──────────────────────────────────────────────
        redeem_url = core_host.rstrip('/') + f'/api/v1/agents/standalone-key/{key_id}/redeem' if core_host else None
        if redeem_url:
            try:
                fingerprint = self.get_hardware_fingerprint()
                body = json.dumps({
                    'key': key_string,
                    'hardware_id': fingerprint,
                    'hostname': socket.gethostname(),
                }).encode('utf-8')
                req = urllib.request.Request(
                    redeem_url, data=body,
                    headers={'Content-Type': 'application/json'},
                    method='POST'
                )
                ctx = ssl.create_default_context()
                ctx.check_hostname = True
                ctx.verify_mode = ssl.CERT_REQUIRED
                with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:  # nosec B310
                    result = json.loads(resp.read().decode('utf-8'))

                if result.get('success'):
                    # Store as a delegated license (highest-trust path)
                    delegated = {
                        'tier': result.get('tier', tier),
                        'license_source': LICENSE_SOURCE_CORE,
                        'agent_class': result.get('agent_class', 'standalone'),
                        'core_server_url': core_host,
                        'delegated_at': datetime.now().isoformat(),
                        'cached_at': datetime.now().isoformat(),
                        'expires_at': result.get('expires_at', expires_at),
                        'features': TIER_FEATURES.get(result.get('tier', tier), {}),
                        'is_valid': True,
                        'validation_message': f'ATKS key redeemed via Core ({result.get("tier", tier).title()})',
                        'core_license_id': result.get('license_id'),
                        'agent_slot': result.get('agent_slot'),
                        'agent_slot_type': result.get('agent_slot_type', 'standalone'),
                        'atks_key_id': key_id,
                        'atks_label': label,
                    }
                    self.config_dir.mkdir(parents=True, exist_ok=True)
                    with open(self.delegated_license_file, 'w') as f:
                        json.dump(delegated, f, indent=2)
                    self._license_cache = None
                    return {
                        'success': True,
                        'key_type': 'core_presigned',
                        'license': delegated,
                    }

                if result.get('error'):
                    # Core explicitly rejected the key — do NOT fall through to offline
                    return {'success': False, 'error': result['error']}

            except urllib.error.HTTPError as exc:
                if exc.code in (403, 404):
                    try:
                        body = json.loads(exc.read().decode('utf-8'))
                        return {'success': False, 'error': body.get('error', f'Core rejected key (HTTP {exc.code})')}
                    except Exception:
                        return {'success': False, 'error': f'Core rejected key (HTTP {exc.code})'}
                # Other HTTP errors fall through to offline path
            except Exception:
                pass  # Core unreachable — try offline path

        # ── Offline HMAC verification ──────────────────────────────────────
        if not self._verify_atks_key_hmac(payload_b64, provided_sig):
            hint = (
                ' Ensure AUDIT_TOKEN_SIGNING_KEY matches the Core host, or connect '
                'to the Core to redeem this key online.'
            ) if not core_host else ' The Core host was unreachable and offline HMAC verification failed.'
            return {
                'success': False,
                'error': 'ATKS key signature is invalid.' + hint,
            }

        # Enforce machine binding offline — the key payload may carry a mid field
        # set by the admin at issuance time to lock the key to one specific machine.
        fingerprint = self.get_hardware_fingerprint()
        bound_mid = payload.get('mid')
        if bound_mid and bound_mid != fingerprint:
            return {
                'success': False,
                'error': (
                    'This key is bound to a different machine and cannot be activated here. '
                    'The hardware fingerprint does not match the one recorded when the key was issued.'
                ),
            }

        # Signature verified offline — store as a local license at the key's tier
        license_data = {
            'tier': tier,
            'license_source': LICENSE_SOURCE_LOCAL,
            'atks_key_id': key_id,
            'atks_label': label,
            'activated_at': datetime.now().isoformat(),
            'expires_at': expires_at,
            'hardware_fingerprint': fingerprint,
            'features': TIER_FEATURES.get(tier, TIER_FEATURES[TIER_COMMUNITY]),
            'is_valid': True,
            'validation_message': (
                f'ATKS key activated offline ({tier.title()} tier). '
                'Connect to Core to fully validate.'
            ),
            'offline_atks': True,
        }
        self.config_dir.mkdir(parents=True, exist_ok=True)
        with open(self.license_file, 'w') as f:
            json.dump(license_data, f, indent=2)
        self._license_cache = None

        return {
            'success': True,
            'key_type': 'core_presigned_offline',
            'warning': (
                'Activated offline using HMAC signature. '
                'Connect this agent to the Core host to fully validate the key.'
            ),
            'license': license_data,
        }

    def _validate_with_server(self, license_key: str, server_url: str) -> Dict[str, Any]:
        """Validate license with remote server."""
        try:
            url = f"{server_url.rstrip('/')}/api/license/validate"
            data = json.dumps({
                'license_key': license_key,
                'hardware_fingerprint': self.get_hardware_fingerprint(),
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )

            # Phase 1 hardening: require valid certificate
            ctx = ssl.create_default_context()
            ctx.check_hostname = True
            ctx.verify_mode = ssl.CERT_REQUIRED

            with urllib.request.urlopen(req, timeout=10, context=ctx) as response:  # nosec B310 - URL is validated license-server endpoint
                result = json.loads(response.read().decode())
                return result

        except urllib.error.HTTPError as e:
            return {
                'success': False,
                'error': f'License server error: {e.code}',
            }
        except Exception:
            # Offline activation - allow for now
            return {'success': True, 'offline': True}

    def deactivate_license(self) -> Dict[str, Any]:
        """Deactivate current license and revert to Community."""
        try:
            if self.license_file.exists():
                self.license_file.unlink()
            self._license_cache = None
            return {
                'success': True,
                'message': 'License deactivated. Reverted to Community Edition.',
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
            }

    def get_tier(self) -> str:
        """Get current license tier."""
        return self.get_license().get('tier', TIER_COMMUNITY)

    def get_features(self) -> Dict[str, Any]:
        """Get features for current tier."""
        tier = self.get_tier()
        return TIER_FEATURES.get(tier, TIER_FEATURES[TIER_COMMUNITY])

    def is_feature_enabled(self, feature: str) -> bool:
        """Check if a feature is enabled for current tier."""
        features = self.get_features()
        return features.get(feature, False)

    def is_audit_category_allowed(self, category: str) -> bool:
        """Check if an audit category is allowed for current tier."""
        features = self.get_features()
        allowed = features.get('audit_categories', COMMUNITY_AUDIT_CATEGORIES)
        return category in allowed

    def get_allowed_audit_categories(self) -> list:
        """Get list of allowed audit categories for current tier."""
        features = self.get_features()
        return features.get('audit_categories', COMMUNITY_AUDIT_CATEGORIES)

    def is_baseline_audit(self, audit_filename: str) -> bool:
        """
        Check if an audit script is considered a baseline audit.

        Baseline audits are critical security checks that should run
        even in Community tier, regardless of category restrictions.

        Args:
            audit_filename: The filename of the audit script (e.g., 'user-account-audit.sh')

        Returns:
            True if the audit matches a baseline pattern
        """
        filename_lower = audit_filename.lower()
        return any(pattern in filename_lower for pattern in BASELINE_AUDIT_PATTERNS)

    def is_always_allowed(self, audit_filename: str) -> bool:
        """
        Check if an audit script is always allowed regardless of license.

        These are typically discovery/asset management scripts that help
        understand what's installed on a server - essential for any audit workflow.

        Args:
            audit_filename: The filename of the audit script (e.g., 'discovery.sh')

        Returns:
            True if the script is always allowed
        """
        filename_lower = audit_filename.lower()
        return any(pattern in filename_lower for pattern in ALWAYS_ALLOWED_SCRIPTS)

    def is_script_allowed(self, audit_filename: str, category: str = None) -> bool:
        """
        Comprehensive check if a script is allowed to run.

        Checks in order:
        1. Always-allowed scripts (discovery, inventory, etc.) - YES
        2. Baseline security audits - YES
        3. Category is in allowed list - YES
        4. Otherwise - NO (requires license upgrade)

        Args:
            audit_filename: The filename of the audit script
            category: The category the script belongs to (optional)

        Returns:
            True if the script can be run with current license
        """
        # Always-allowed scripts can run under any license
        if self.is_always_allowed(audit_filename):
            return True

        # Baseline audits can run under any license
        if self.is_baseline_audit(audit_filename):
            return True

        # Check if category is allowed
        if category:
            allowed_categories = self.get_allowed_audit_categories()
            if category in allowed_categories:
                return True

        # Not allowed
        return False

    def get_detected_distro(self) -> str:
        """Get the detected host distribution."""
        return detect_host_distro()

    def get_distro_categories(self) -> list:
        """Get the distro-specific categories for this host."""
        return get_distro_specific_categories()

    def should_show_upgrade_prompt(self) -> bool:
        """Check if upgrade prompts should be shown."""
        features = self.get_features()
        return features.get('upgrade_prompts', True)

    def get_license_status(self) -> Dict[str, Any]:
        """Get comprehensive license status for UI display."""
        license_data = self.get_license()
        tier = license_data.get('tier', TIER_COMMUNITY)
        features = self.get_features()
        license_source = license_data.get('license_source', LICENSE_SOURCE_DEFAULT)

        # Calculate days remaining for paid tiers
        days_remaining = None
        expires = None
        if tier != TIER_COMMUNITY and license_data.get('expires_at'):
            try:
                expiry = datetime.fromisoformat(license_data['expires_at'])
                delta = expiry - datetime.now()
                days_remaining = max(0, delta.days)
                expires = expiry.strftime('%Y-%m-%d')
            except Exception:
                pass

        # Build human-readable feature list for paid tiers
        feature_list = []
        if tier != TIER_COMMUNITY:
            feature_list.append('All audit categories')
            if features.get('core_server_integration'):
                feature_list.append('Core Server integration')
            if features.get('script_updates'):
                feature_list.append('Automatic script updates')
            if features.get('json_output'):
                feature_list.append('JSON/CSV export')
            if features.get('pdf_output'):
                feature_list.append('PDF reports')
            if tier == TIER_PROFESSIONAL:
                feature_list.append('Custom audit development')
                feature_list.append('Unlimited agents')
                feature_list.append('Priority support')

        # License source display
        source_display = {
            LICENSE_SOURCE_LOCAL: 'Local License Key',
            LICENSE_SOURCE_CORE: 'Core Server',
            LICENSE_SOURCE_DEFAULT: 'Community (Default)',
        }.get(license_source, 'Unknown')

        # For Core Server delegated licenses, include additional info
        core_info = None
        if license_source == LICENSE_SOURCE_CORE:
            core_info = {
                'server_url': license_data.get('core_server_url'),
                'agent_slot': license_data.get('agent_slot'),
                'agent_slot_type': license_data.get('agent_slot_type', 'standalone'),
                'agent_class': license_data.get('agent_class', 'standalone'),
                'max_agents': license_data.get('max_agents'),
                'agents_used': license_data.get('agents_used'),
            }

        return {
            'tier': tier,
            'tier_display': tier.title(),
            'is_community': tier == TIER_COMMUNITY,
            'is_paid': tier in [TIER_STARTER, TIER_BUSINESS, TIER_PROFESSIONAL],
            'license_key': license_data.get('license_key'),
            'license_source': license_source,
            'license_source_display': source_display,
            'is_delegated': license_source == LICENSE_SOURCE_CORE,
            'offline_cached': bool(license_data.get('offline_cached', False)),
            'core_info': core_info,
            'activated_at': license_data.get('activated_at'),
            'expires_at': license_data.get('expires_at'),
            'expires': expires,
            'days_remaining': days_remaining,
            'is_valid': license_data.get('is_valid', True),
            'valid': license_data.get('is_valid', True),
            'validation_message': license_data.get('validation_message', ''),
            'features': feature_list,
            'max_agents': features.get('max_agents'),
            'hardware_id': self.get_hardware_fingerprint(),
            'allowed_categories': self.get_allowed_audit_categories(),
            'show_upgrade_prompt': self.should_show_upgrade_prompt(),
            'core_server_enabled': features.get('core_server_integration', False),
            'script_updates_enabled': features.get('script_updates', False),
        }


# Script update manager for Professional+ tiers
class ScriptUpdateManager:
    """Manages script updates from Core Server (Professional+ only)."""

    def __init__(self, config_dir: Path, app_dir: Path, license_manager: LicenseManager):
        self.config_dir = Path(config_dir)
        self.app_dir = Path(app_dir)
        self.license_manager = license_manager
        self.update_config_file = self.config_dir / 'update-settings.json'

    def get_update_settings(self) -> Dict[str, Any]:
        """Get script update settings."""
        default = {
            'mode': 'manual',  # 'manual' or 'scheduled'
            'schedule_frequency': 'weekly',  # daily, weekly, monthly
            'schedule_day': 'sunday',  # for weekly
            'schedule_time': '03:00',
            'last_check': None,
            'last_update': None,
            'current_version': '6.2.1',
            'auto_apply': False,
        }

        if self.update_config_file.exists():
            try:
                with open(self.update_config_file, 'r') as f:
                    settings = json.load(f)
                    for key, value in default.items():
                        if key not in settings:
                            settings[key] = value
                    return settings
            except Exception:
                pass

        return default

    def save_update_settings(self, settings: Dict[str, Any]) -> bool:
        """Save script update settings."""
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            with open(self.update_config_file, 'w') as f:
                json.dump(settings, f, indent=2)
            return True
        except Exception:
            return False

    def check_for_updates(self, server_url: str, api_key: str = None) -> Dict[str, Any]:
        """Check for script updates from Core Server."""
        if not self.license_manager.is_feature_enabled('script_updates'):
            return {
                'success': False,
                'error': 'Script updates require Business or Professional license',
                'upgrade_required': True,
            }

        if not server_url:
            return {
                'success': False,
                'error': 'Core Server URL not configured',
            }

        try:
            settings = self.get_update_settings()
            current_version = settings.get('current_version', '0.0.0')

            url = f"{server_url.rstrip('/')}/api/scripts/check-updates"
            data = json.dumps({
                'current_version': current_version,
                'agent_type': 'lightweight',
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    'Content-Type': 'application/json',
                    'X-API-Key': api_key or '',
                },
                method='POST'
            )

            # Phase 1 hardening: require valid certificate
            ctx = ssl.create_default_context()
            ctx.check_hostname = True
            ctx.verify_mode = ssl.CERT_REQUIRED

            with urllib.request.urlopen(req, timeout=30, context=ctx) as response:  # nosec B310 - URL is validated update-server endpoint
                result = json.loads(response.read().decode())

                # Update last check time
                settings['last_check'] = datetime.now().isoformat()
                self.save_update_settings(settings)

                return {
                    'success': True,
                    'updates_available': result.get('updates_available', False),
                    'latest_version': result.get('latest_version'),
                    'current_version': current_version,
                    'changelog': result.get('changelog', []),
                    'last_check': settings['last_check'],
                }

        except urllib.error.HTTPError as e:
            return {
                'success': False,
                'error': f'Server error: {e.code}',
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
            }

    def download_updates(self, server_url: str, api_key: str = None,
                          differential: bool = True) -> Dict[str, Any]:
        """
        Download and apply script updates from Core Server.

        Args:
            server_url: Core Server URL
            api_key: Optional API key for authentication
            differential: If True, only download changed scripts (faster)

        Returns:
            Dict with update results
        """
        if not self.license_manager.is_feature_enabled('script_updates'):
            return {
                'success': False,
                'error': 'Script updates require Business or Professional license',
                'upgrade_required': True,
            }

        if not server_url:
            return {
                'success': False,
                'error': 'Core Server URL not configured',
            }

        try:
            audits_dir = self.app_dir / 'audits'
            backup_dir = self.config_dir / 'script-backups'

            if differential:
                return self._download_differential_updates(server_url, api_key, audits_dir, backup_dir)
            else:
                return self._download_full_updates(server_url, api_key, audits_dir, backup_dir)

        except Exception as e:
            return {
                'success': False,
                'error': f'Update failed: {str(e)}',
            }

    def _get_local_script_checksums(self, audits_dir: Path) -> Dict[str, str]:
        """Calculate checksums for all local audit scripts."""
        checksums = {}
        if not audits_dir.exists():
            return checksums

        for script in audits_dir.rglob('*.sh'):
            if script.name.startswith('_'):
                continue
            rel_path = str(script.relative_to(audits_dir))
            checksums[rel_path] = hashlib.sha256(script.read_bytes()).hexdigest()
        return checksums

    def _download_differential_updates(self, server_url: str, api_key: str,
                                        audits_dir: Path, backup_dir: Path) -> Dict[str, Any]:
        """Download only changed scripts."""
        # Get local checksums
        local_checksums = self._get_local_script_checksums(audits_dir)

        # Check which scripts need updates
        check_url = f"{server_url.rstrip('/')}/api/updates/scripts/check"
        check_data = json.dumps({'scripts': local_checksums}).encode()

        headers = {
            'Content-Type': 'application/json',
            'X-API-Key': api_key or '',
        }

        req = urllib.request.Request(check_url, data=check_data, headers=headers, method='POST')
        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, timeout=30, context=ctx) as response:  # nosec B310 - URL is validated update-server endpoint
            check_result = json.loads(response.read().decode())

        if not check_result.get('success'):
            return check_result

        updates_needed = check_result.get('details', {}).get('updates', [])
        new_scripts = check_result.get('details', {}).get('new', [])

        if not updates_needed and not new_scripts:
            return {
                'success': True,
                'message': 'All scripts are up to date',
                'updated': 0,
                'added': 0,
            }

        # Create backup
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = backup_dir / f'backup_{timestamp}'

        # Download and apply updates
        updated_count = 0
        added_count = 0
        errors = []

        all_scripts = [u['path'] for u in updates_needed] + new_scripts

        for script_path in all_scripts:
            try:
                download_url = f"{server_url.rstrip('/')}/api/updates/scripts/download/{script_path}"
                req = urllib.request.Request(download_url, headers=headers)

                with urllib.request.urlopen(req, timeout=30, context=ctx) as response:  # nosec B310 - URL is validated update-server endpoint
                    script_content = response.read()

                target_file = audits_dir / script_path

                # Backup existing file
                if target_file.exists():
                    backup_file = backup_path / script_path
                    backup_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target_file, backup_file)
                    updated_count += 1
                else:
                    added_count += 1

                # Write new content
                target_file.parent.mkdir(parents=True, exist_ok=True)
                target_file.write_bytes(script_content)
                target_file.chmod(0o755)  # Make executable

            except Exception as e:
                errors.append(f'{script_path}: {str(e)}')

        # Update settings
        settings = self.get_update_settings()
        settings['last_update'] = datetime.now().isoformat()
        self.save_update_settings(settings)

        return {
            'success': len(errors) == 0,
            'updated': updated_count,
            'added': added_count,
            'errors': errors if errors else None,
            'backup_path': str(backup_path) if (updated_count > 0 or added_count > 0) else None,
        }

    def _download_full_updates(self, server_url: str, api_key: str,
                               audits_dir: Path, backup_dir: Path) -> Dict[str, Any]:
        """Download complete audit scripts bundle."""
        # Get download URL from manifest
        manifest_url = f"{server_url.rstrip('/')}/api/updates/manifest?component=audits"
        headers = {
            'Content-Type': 'application/json',
            'X-API-Key': api_key or '',
        }

        req = urllib.request.Request(manifest_url, headers=headers)
        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, timeout=30, context=ctx) as response:  # nosec B310 - URL is validated update-server endpoint
            manifest = json.loads(response.read().decode())

        if not manifest.get('success') or not manifest.get('update_available'):
            return {
                'success': True,
                'message': 'No updates available',
            }

        # Download archive
        download_url = manifest.get('download_url')
        expected_sha256 = manifest.get('sha256')

        if not download_url:
            return {
                'success': False,
                'error': 'No download URL in manifest',
            }

        req = urllib.request.Request(download_url, headers=headers)

        with urllib.request.urlopen(req, timeout=120, context=ctx) as response:  # nosec B310 - URL is validated update-server endpoint
            archive_content = response.read()

        # Verify checksum
        actual_sha256 = hashlib.sha256(archive_content).hexdigest()
        if expected_sha256 and actual_sha256 != expected_sha256:
            return {
                'success': False,
                'error': f'Checksum mismatch: expected {expected_sha256}, got {actual_sha256}',
            }

        # Create backup
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = backup_dir / f'backup_{timestamp}'

        if audits_dir.exists():
            shutil.copytree(audits_dir, backup_path)

        # Extract archive
        import tempfile
        import tarfile

        with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp:
            tmp.write(archive_content)
            tmp_path = tmp.name

        try:
            with tarfile.open(tmp_path, 'r:gz') as tar:
                # Security: Check for path traversal
                for member in tar.getmembers():
                    if member.name.startswith('/') or '..' in member.name:
                        return {
                            'success': False,
                            'error': 'Archive contains unsafe paths',
                        }

                # Clear existing and extract
                if audits_dir.exists():
                    shutil.rmtree(audits_dir)
                audits_dir.mkdir(parents=True)

                tar.extractall(audits_dir)  # nosec B202 - members validated above for traversal before extraction
        finally:
            os.unlink(tmp_path)

        # Fix permissions
        for script in audits_dir.rglob('*.sh'):
            script.chmod(0o755)

        # Update settings
        settings = self.get_update_settings()
        settings['last_update'] = datetime.now().isoformat()
        settings['current_version'] = manifest.get('latest_version', settings['current_version'])
        self.save_update_settings(settings)

        return {
            'success': True,
            'version': manifest.get('latest_version'),
            'backup_path': str(backup_path),
        }

    def rollback_updates(self, backup_name: str = None) -> Dict[str, Any]:
        """
        Rollback to a previous script backup.

        Args:
            backup_name: Specific backup to restore (or latest if None)
        """
        backup_dir = self.config_dir / 'script-backups'

        if not backup_dir.exists():
            return {
                'success': False,
                'error': 'No backups available',
            }

        # Find backup to restore
        backups = sorted(backup_dir.iterdir(), reverse=True)
        if not backups:
            return {
                'success': False,
                'error': 'No backups available',
            }

        if backup_name:
            backup_path = backup_dir / backup_name
            if not backup_path.exists():
                return {
                    'success': False,
                    'error': f'Backup not found: {backup_name}',
                }
        else:
            backup_path = backups[0]

        audits_dir = self.app_dir / 'audits'

        try:
            # Restore from backup
            if audits_dir.exists():
                shutil.rmtree(audits_dir)
            shutil.copytree(backup_path, audits_dir)

            return {
                'success': True,
                'restored_from': backup_path.name,
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Rollback failed: {str(e)}',
            }

    def list_backups(self) -> Dict[str, Any]:
        """List available script backups."""
        backup_dir = self.config_dir / 'script-backups'

        if not backup_dir.exists():
            return {
                'success': True,
                'backups': [],
            }

        backups = []
        for backup in sorted(backup_dir.iterdir(), reverse=True):
            if backup.is_dir():
                script_count = len(list(backup.rglob('*.sh')))
                backups.append({
                    'name': backup.name,
                    'created': datetime.fromtimestamp(backup.stat().st_mtime).isoformat(),
                    'script_count': script_count,
                })

        return {
            'success': True,
            'backups': backups,
        }
