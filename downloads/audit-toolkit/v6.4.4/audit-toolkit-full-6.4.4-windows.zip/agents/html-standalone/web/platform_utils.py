#!/usr/bin/env python3
"""
Cross-Platform Utility Functions for Standalone Agent

Provides platform-agnostic helpers for file operations, system detection,
and path handling to ensure the standalone agent works across Windows and Linux.

Author: Security Audit Toolkit Team
Date: February 19, 2026
"""

import os
import platform
from pathlib import Path
from typing import Optional, Union
import logging

logger = logging.getLogger(__name__)


def is_windows() -> bool:
    """Check if running on Windows."""
    return platform.system() == 'Windows'


def is_linux() -> bool:
    """Check if running on Linux."""
    return platform.system() == 'Linux'


def is_macos() -> bool:
    """Check if running on macOS."""
    return platform.system() == 'Darwin'


def is_unix_like() -> bool:
    """Check if running on Unix-like system (Linux or macOS)."""
    return is_linux() or is_macos()


def get_system_root_drive() -> str:
    """
    Get system root drive path in platform-specific way.

    Returns:
        str: '/' for Unix-like, 'C:\\' for Windows (or Python install drive)
    """
    if is_windows():
        import sys
        python_drive = Path(sys.executable).drive or 'C:'
        return python_drive + '\\'
    return '/'


def is_container() -> bool:
    """
    Detect if running in a container (Docker, Podman, LXC, etc.).

    Returns:
        bool: True if running in container
    """
    # Environment variables
    if os.environ.get('DOCKER_CONTAINER') or os.environ.get('container'):
        return True

    # Docker/Podman specific files (Linux only)
    if is_linux():
        if os.path.exists('/.dockerenv'):
            return True

        if os.path.exists('/run/.containerenv'):  # Podman
            return True

        # Check cgroup (older method)
        try:
            if os.path.exists('/proc/1/cgroup'):
                with open('/proc/1/cgroup') as f:
                    content = f.read()
                    if any(marker in content for marker in ['docker', 'lxc', 'kubepods', 'containerd']):
                        return True
        except Exception:
            pass

    return False


def is_kubernetes() -> bool:
    """
    Detect if running in Kubernetes.

    Returns:
        bool: True if running in K8s
    """
    return os.environ.get('KUBERNETES_SERVICE_HOST') is not None


def get_deployment_type() -> str:
    """
    Detect deployment environment.

    Returns:
        str: 'docker', 'kubernetes', or 'standalone'
    """
    if is_kubernetes():
        return 'kubernetes'

    if is_container():
        return 'docker'

    return 'standalone'


def get_os_info() -> dict:
    """
    Get detailed OS information in platform-agnostic way.

    Returns:
        dict: OS details including name, version, architecture
    """
    info = {
        'platform': platform.system(),
        'platform_release': platform.release(),
        'platform_version': platform.version(),
        'architecture': platform.machine(),
        'hostname': platform.node(),
    }

    # Linux-specific
    if is_linux():
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release') as f:
                    for line in f:
                        if line.startswith('PRETTY_NAME='):
                            info['os_name'] = line.split('=')[1].strip().strip('"')
                        elif line.startswith('ID='):
                            info['os_id'] = line.split('=')[1].strip().strip('"')
                        elif line.startswith('VERSION_ID='):
                            info['os_version'] = line.split('=')[1].strip().strip('"')
        except Exception:
            pass

    # Windows-specific
    elif is_windows():
        try:
            import subprocess
            result = subprocess.run(
                ['wmic', 'os', 'get', 'Caption,Version', '/value'],
                capture_output=True, text=True, timeout=10
            )
            for line in result.stdout.split('\n'):
                if 'Caption=' in line:
                    info['os_name'] = line.split('=', 1)[1].strip()
                elif 'Version=' in line:
                    info['os_version'] = line.split('=', 1)[1].strip()
        except Exception:
            info['os_name'] = f"Windows {platform.release()}"

    # macOS-specific
    elif is_macos():
        info['os_name'] = f"macOS {platform.mac_ver()[0]}"

    return info


def get_system_uptime() -> Optional[str]:
    """
    Get system uptime in human-readable format.

    Returns:
        str: Uptime like "5d 3h 20m" or None if unavailable
    """
    try:
        if is_linux():
            with open('/proc/uptime') as f:
                uptime_seconds = float(f.read().split()[0])
        elif is_windows():
            import subprocess
            from datetime import datetime
            result = subprocess.run(
                ['wmic', 'os', 'get', 'lastbootuptime', '/value'],
                capture_output=True, text=True, timeout=5
            )
            boot_line = [l for l in result.stdout.split('\n') if 'LastBootUpTime=' in l]
            if boot_line:
                boot_str = boot_line[0].split('=')[1][:14]
                boot_time = datetime.strptime(boot_str, '%Y%m%d%H%M%S')
                uptime_seconds = (datetime.now() - boot_time).total_seconds()
            else:
                return None
        elif is_macos():
            import subprocess
            result = subprocess.run(
                ['sysctl', '-n', 'kern.boottime'],
                capture_output=True, text=True, timeout=5
            )
            # Parse output like: { sec = 1708320000, usec = 0 }
            from datetime import datetime
            import re
            match = re.search(r'sec = (\d+)', result.stdout)
            if match:
                boot_time = int(match.group(1))
                uptime_seconds = datetime.now().timestamp() - boot_time
            else:
                return None
        else:
            return None

        days = int(uptime_seconds // 86400)
        hours = int((uptime_seconds % 86400) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)
        return f"{days}d {hours}h {minutes}m"

    except Exception as e:
        logger.debug(f"Failed to get uptime: {e}")
        return None


def get_default_shell() -> str:
    """
    Get default shell for current platform.

    Returns:
        str: Shell executable name ('bash', 'sh', 'powershell', 'cmd')
    """
    if is_windows():
        return 'powershell'
    elif is_macos():
        return 'zsh'  # macOS default since Catalina
    return 'bash'
