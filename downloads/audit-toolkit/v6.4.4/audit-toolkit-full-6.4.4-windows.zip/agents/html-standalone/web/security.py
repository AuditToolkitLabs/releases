"""
Security Module for Lightweight Audit Agent

Implements:
- Phase 1: Certificate validation, config validation, file permissions
- Phase 2: Result encryption (Fernet), config signing (ECDSA)
- Phase 3: Request signing (HMAC-SHA256), audit logging
"""

import os
import json
import hmac
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Tuple, Optional, Any

try:
    import syslog
    SYSLOG_AVAILABLE = True
except ImportError:
    syslog = None
    SYSLOG_AVAILABLE = False

# Phase 2 imports: Cryptography
try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.backends import default_backend
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False


class ConfigValidator:
    """Validates and protects agent configuration."""

    # Allowed server URL patterns (prevent redirection to unauthorized services)
    ALLOWED_DOMAINS = []  # Empty = allow all (can be restricted via env var)
    RESTRICTED_DOMAINS = [
        'wazuh',
        'splunk',
        'elastic',
        'sumo',
        'datadog',
        'newrelic'
    ]

    @classmethod
    def validate_server_url(cls, url: str) -> Tuple[bool, Optional[str]]:
        """
        Validate that server URL is legitimate and not redirected to SIEM competitor.

        Returns: (is_valid, error_message)
        """
        if not url:
            return False, "Server URL cannot be empty"

        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse

        parsed = urlparse(url)

        # Check HTTPS requirement
        if parsed.scheme != 'https':
            return False, "Only HTTPS connections are allowed (not {})".format(parsed.scheme)

        # Check against restricted domains
        hostname = parsed.netloc.lower()
        for restricted in cls.RESTRICTED_DOMAINS:
            if restricted in hostname:
                return False, "Redirection to {} services is not permitted".format(restricted)

        # Check against allowlist if configured
        if cls.ALLOWED_DOMAINS:
            allowed = False
            for domain in cls.ALLOWED_DOMAINS:
                if hostname == domain or hostname.endswith('.' + domain):
                    allowed = True
                    break
            if not allowed:
                return False, "Server domain '{}' is not in approved list".format(hostname)

        return True, None

    @classmethod
    def configure_allowlist(cls, domains: list):
        """Set approved server domains (comma-separated env var)."""
        cls.ALLOWED_DOMAINS = [d.strip() for d in domains if d.strip()]

    @classmethod
    def validate_config_file(cls, config: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Validate complete configuration structure.

        Returns: (is_valid, error_message)
        """
        # Validate required fields when setup has completed
        if config.get('setup_complete'):
            if not str(config.get('agent_id', '')).strip():
                return False, "Required field 'agent_id' is empty"

            # Connected mode requires API key; standalone mode does not.
            if str(config.get('core_server_url', '')).strip() and not str(config.get('api_key', '')).strip():
                return False, "Required field 'api_key' is empty"

        # Validate server URL if present
        if config.get('core_server_url'):
            is_valid, error = cls.validate_server_url(config['core_server_url'])
            if not is_valid:
                return False, error

        return True, ""


class FileSecurityManager:
    """Manages secure file permissions and integrity."""

    # Secure permissions
    RESTRICTED_CONFIG_MODE = 0o600  # rw------- (only owner can read/write)
    RESTRICTED_RESULTS_MODE = 0o700  # rwx------ (only owner can access)
    RESTRICTED_FILE_MODE = 0o600    # rw------- (only owner can read/write)

    @classmethod
    def set_secure_permissions(cls, path: Path) -> bool:
        """Set restrictive file permissions."""
        if not path.exists():
            return False

        try:
            if path.is_dir():
                os.chmod(path, cls.RESTRICTED_RESULTS_MODE)
            else:
                os.chmod(path, cls.RESTRICTED_CONFIG_MODE)
            return True
        except Exception as e:
            logging.error(f"Failed to set secure permissions on {path}: {e}")
            return False

    @classmethod
    def verify_permissions(cls, path: Path, expected_mode: int) -> bool:
        """Verify file has expected restrictive permissions."""
        if not path.exists():
            return False

        current_mode = os.stat(path).st_mode & 0o777
        return current_mode == expected_mode

    @classmethod
    def make_immutable_linux(cls, path: Path) -> bool:
        """Make file immutable on Linux using chattr (requires root)."""
        if not path.exists() or path.is_dir():
            return False

        try:
            import subprocess
            result = subprocess.run(['chattr', '+i', str(path)],
                                  capture_output=True, timeout=5)
            return result.returncode == 0
        except Exception as e:
            logging.warning(f"Could not make {path} immutable: {e}")
            return False

    @classmethod
    def remove_immutable_linux(cls, path: Path) -> bool:
        """Remove immutable flag on Linux (requires root)."""
        if not path.exists():
            return False

        try:
            import subprocess
            result = subprocess.run(['chattr', '-i', str(path)],
                                  capture_output=True, timeout=5)
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def enforce_startup_permissions(cls, config_dir: Path, results_dir: Path):
        """Enforce restrictive permissions on startup."""
        # Set config directory permissions
        cls.set_secure_permissions(config_dir)

        # Set results directory permissions
        cls.set_secure_permissions(results_dir)

        # Set permissions on all existing config files
        for config_file in config_dir.glob('*.json'):
            cls.set_secure_permissions(config_file)

        # Set permissions on all result files
        for result_file in results_dir.glob('*'):
            cls.set_secure_permissions(result_file)


class ResultsEncryption:
    """Encrypts and decrypts result files at rest using Fernet."""

    def __init__(self, agent_dir: Path):
        """Initialize encryption with agent-specific key."""
        self.agent_dir = agent_dir
        self.key_file = agent_dir / '.keys' / 'encryption.key'
        self.enabled = CRYPTO_AVAILABLE

        if self.enabled:
            self._ensure_key()

    def _ensure_key(self) -> bool:
        """Create or load encryption key."""
        self.key_file.parent.mkdir(parents=True, exist_ok=True)

        if self.key_file.exists():
            try:
                with open(self.key_file, 'rb') as f:
                    key = f.read()
                    Fernet(key)  # Validate key format
                return True
            except Exception as e:
                logging.error(f"Invalid encryption key: {e}")
                return False

        try:
            # Generate new key
            key = Fernet.generate_key()

            # Save with restricted permissions
            self.key_file.write_bytes(key)
            os.chmod(self.key_file, 0o600)

            return True
        except Exception as e:
            logging.error(f"Failed to generate encryption key: {e}")
            return False

    def _get_cipher(self) -> Optional[Any]:
        """Get Fernet cipher instance."""
        if not self.key_file.exists():
            return None

        try:
            with open(self.key_file, 'rb') as f:
                key = f.read()
            return Fernet(key)
        except Exception as e:
            logging.error(f"Failed to load cipher: {e}")
            return None

    def encrypt_result(self, result_data: Dict[str, Any],
                      result_file: Path) -> bool:
        """
        Encrypt result data and save to file.

        Returns: success bool
        """
        if not self.enabled:
            return False

        cipher = self._get_cipher()
        if not cipher:
            return False

        try:
            # Serialize data
            plaintext = json.dumps(result_data).encode('utf-8')

            # Encrypt
            ciphertext = cipher.encrypt(plaintext)

            # Save encrypted data with metadata
            encrypted_obj = {
                '_encrypted': True,
                '_encryption_method': 'fernet-aes128',
                '_encrypted_at': datetime.now().isoformat(),
                'data': ciphertext.decode('utf-8')
            }

            # Write with restricted permissions
            result_file.write_text(json.dumps(encrypted_obj, indent=2))
            os.chmod(result_file, 0o600)

            return True
        except Exception as e:
            logging.error(f"Failed to encrypt result: {e}")
            return False

    def decrypt_result(self, result_file: Path) -> Optional[Dict[str, Any]]:
        """
        Decrypt result data from file.

        Returns: Decrypted dict or None
        """
        if not self.enabled:
            return None

        cipher = self._get_cipher()
        if not cipher:
            return None

        try:
            # Load file
            with open(result_file, 'r') as f:
                encrypted_obj = json.load(f)

            # Check encryption marker
            if not encrypted_obj.get('_encrypted'):
                logging.warning(f"File {result_file} is not encrypted")
                return None

            # Decrypt
            ciphertext = encrypted_obj['data'].encode('utf-8')
            plaintext = cipher.decrypt(ciphertext)

            # Deserialize
            return json.loads(plaintext.decode('utf-8'))
        except InvalidToken:
            logging.error(f"Failed to decrypt {result_file}: Invalid token (wrong key?)")
            return None
        except Exception as e:
            logging.error(f"Failed to decrypt {result_file}: {e}")
            return None


class ConfigSigning:
    """Signs and verifies configuration files using ECDSA."""

    def __init__(self, config_dir: Path):
        """Initialize signing with agent-specific keys."""
        self.config_dir = config_dir
        self.key_dir = config_dir / '.keys'
        self.private_key_file = self.key_dir / 'config.private.pem'
        self.public_key_file = self.key_dir / 'config.public.pem'
        self.enabled = CRYPTO_AVAILABLE

        if self.enabled:
            self._ensure_keys()

    def _ensure_keys(self) -> bool:
        """Create or load signing key pair."""
        self.key_dir.mkdir(parents=True, exist_ok=True)

        # If both keys exist and are valid, we're done
        if self.private_key_file.exists() and self.public_key_file.exists():
            try:
                self._load_private_key()
                self._load_public_key()
                return True
            except Exception:
                pass

        # Generate new key pair
        try:
            private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
            public_key = private_key.public_key()

            # Save private key
            private_pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            self.private_key_file.write_bytes(private_pem)
            os.chmod(self.private_key_file, 0o600)

            # Save public key
            public_pem = public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            self.public_key_file.write_bytes(public_pem)
            os.chmod(self.public_key_file, 0o600)

            return True
        except Exception as e:
            logging.error(f"Failed to generate signing keys: {e}")
            return False

    def _load_private_key(self):
        """Load private key from file."""
        with open(self.private_key_file, 'rb') as f:
            return serialization.load_pem_private_key(
                f.read(), password=None, backend=default_backend()
            )

    def _load_public_key(self):
        """Load public key from file."""
        with open(self.public_key_file, 'rb') as f:
            return serialization.load_pem_public_key(
                f.read(), backend=default_backend()
            )

    def sign_config(self, config: Dict[str, Any]) -> Optional[str]:
        """
        Sign configuration and return signature.

        Returns: Signature string or None
        """
        if not self.enabled or not self.private_key_file.exists():
            return None

        try:
            # Create canonical JSON for signing (sorted keys, no whitespace)
            config_copy = {k: v for k, v in config.items()
                          if k not in ('_signature', '_signed_at')}
            canonical = json.dumps(config_copy, sort_keys=True, separators=(',', ':'))

            # Sign
            private_key = self._load_private_key()
            signature = private_key.sign(
                canonical.encode('utf-8'),
                ec.ECDSA(hashes.SHA256())
            )

            # Encode signature as hex string
            return signature.hex()
        except Exception as e:
            logging.error(f"Failed to sign config: {e}")
            return None

    def verify_config(self, config: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Verify configuration signature.

        Returns: (is_valid, message)
        """
        if not self.enabled or not self.public_key_file.exists():
            return False, "Signature verification disabled"

        signature_hex = config.get('_signature')
        if not signature_hex:
            return False, "No signature found in config"

        try:
            # Recreate canonical JSON (excluding signature)
            config_copy = {k: v for k, v in config.items()
                          if k not in ('_signature', '_signed_at')}
            canonical = json.dumps(config_copy, sort_keys=True, separators=(',', ':'))

            # Verify
            public_key = self._load_public_key()
            signature = bytes.fromhex(signature_hex)

            public_key.verify(
                signature,
                canonical.encode('utf-8'),
                ec.ECDSA(hashes.SHA256())
            )

            return True, "Signature valid"
        except Exception as e:
            return False, f"Signature verification failed: {e}"


class RequestSigning:
    """Sign and verify HTTP requests using HMAC-SHA256."""

    def __init__(self, api_key: str):
        """Initialize with API key as HMAC secret."""
        self.api_key = api_key or ''

    @staticmethod
    def generate_signature(method: str, path: str, body: str = '',
                          api_key: str = '', timestamp: str = '') -> str:
        """
        Generate HMAC-SHA256 signature for request.

        Signature covers: method + path + body + timestamp
        """
        if not timestamp:
            timestamp = str(int(datetime.now().timestamp()))

        message = f"{method}|{path}|{body}|{timestamp}"
        signature = hmac.new(
            api_key.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

        return signature

    @staticmethod
    def verify_signature(method: str, path: str, body: str,
                        timestamp: str, signature: str, api_key: str,
                        max_age_seconds: int = 300) -> Tuple[bool, str]:
        """
        Verify request signature.

        Returns: (is_valid, message)
        """
        # Check timestamp freshness
        try:
            request_time = int(timestamp)
            current_time = int(datetime.now().timestamp())
            age = abs(current_time - request_time)

            if age > max_age_seconds:
                return False, f"Request timestamp too old ({age}s > {max_age_seconds}s)"
        except ValueError:
            return False, "Invalid timestamp"

        # Verify signature
        expected = RequestSigning.generate_signature(method, path, body, api_key, timestamp)

        # Use constant-time comparison
        if hmac.compare_digest(signature, expected):
            return True, "Signature valid"
        else:
            return False, "Signature mismatch"


class AuditLogger:
    """Logs all configuration changes and exports to syslog and file."""

    def __init__(self, logs_dir: Path, use_syslog: bool = True):
        """Initialize audit logger."""
        self.logs_dir = logs_dir
        self.use_syslog = use_syslog and SYSLOG_AVAILABLE
        self.log_file = logs_dir / 'audit.log'
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        # Set up file logger
        self.logger = logging.getLogger('audit')
        self.logger.setLevel(logging.DEBUG)

        # File handler
        fh = logging.FileHandler(self.log_file)
        fh.setLevel(logging.DEBUG)

        # Formatter includes timestamp
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)

        # Secure log file permissions
        try:
            os.chmod(self.log_file, 0o600)
        except OSError:
            pass

    def log_config_change(self, action: str, old_value: Any = None,
                         new_value: Any = None, source: str = ''):
        """Log configuration change."""
        # Mask sensitive values
        if isinstance(new_value, str) and 'key' in action.lower():
            new_value = '***REDACTED***'

        message = f"CONFIG_CHANGE|{action}|old={old_value}|new={new_value}|source={source}"
        self.logger.info(message)

        if self.use_syslog:
            try:
                syslog.syslog(syslog.LOG_INFO, message)
            except Exception:
                pass

    def log_export(self, job_id: str, destination: str,
                   status: str, message: str = ''):
        """Log result export attempt."""
        msg = f"EXPORT|job_id={job_id}|dest={destination}|status={status}|msg={message}"
        self.logger.info(msg)

        if self.use_syslog:
            try:
                syslog.syslog(syslog.LOG_INFO, msg)
            except Exception:
                pass

    def log_auth_failure(self, reason: str, source_ip: str = ''):
        """Log authentication failure."""
        msg = f"AUTH_FAILURE|reason={reason}|ip={source_ip}"
        self.logger.warning(msg)

        if self.use_syslog:
            try:
                syslog.syslog(syslog.LOG_WARNING, msg)
            except Exception:
                pass

    def log_security_event(self, event_type: str, details: str = ''):
        """Log security-related events."""
        msg = f"SECURITY|{event_type}|{details}"
        self.logger.warning(msg)

        if self.use_syslog:
            try:
                syslog.syslog(syslog.LOG_WARNING, msg)
            except Exception:
                pass


def setup_security(app_dir: Path, config_dir: Path, results_dir: Path,
                   logs_dir: Path) -> Dict[str, Any]:
    """
    Initialize all security components and enforce startup protections.

    Returns: Dictionary with initialized security objects
    """
    security_context = {}

    # Phase 1: File permissions
    FileSecurityManager.enforce_startup_permissions(config_dir, results_dir)

    # Phase 2: Encryption & Signing (if crypto available)
    if CRYPTO_AVAILABLE:
        security_context['results_encryption'] = ResultsEncryption(app_dir)
        security_context['config_signing'] = ConfigSigning(config_dir)
    else:
        logging.warning("cryptography library not available - Phase 2 features disabled")

    # Phase 3: Audit logging (always available)
    security_context['audit_logger'] = AuditLogger(logs_dir)

    # Config validator (always available)
    security_context['config_validator'] = ConfigValidator()

    # Check for allowed domains env var
    allowed_domains = os.environ.get('ALLOWED_SERVER_DOMAINS', '')
    if allowed_domains:
        ConfigValidator.configure_allowlist(allowed_domains.split(','))

    return security_context
