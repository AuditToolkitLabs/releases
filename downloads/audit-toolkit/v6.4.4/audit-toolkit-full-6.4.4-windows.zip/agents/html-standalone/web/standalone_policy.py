"""Standalone policy helpers for audit discovery and category access.

This module keeps standalone-specific decisions out of app.py so behavior
is explicit and easier to evolve without mixing with request handlers.
"""

from pathlib import Path


KNOWN_AUDIT_CATEGORIES = {
    'platform', 'network', 'web', 'data', 'apps', 'storage', 'automation',
    'advanced-controls', 'alpine', 'cloud', 'security', 'virtualization',
    'arch', 'debian', 'ubuntu', 'rhel', 'fedora', 'opensuse', 'centos',
    'common', 'desktop', 'server', 'hypervisors', 'linux', 'windows', 'custom',
}


def resolve_standalone_defaults(current_file: Path, running_on_windows: bool) -> dict:
    """Resolve default paths for standalone runtime.

    Prefers repository audit paths when running from source, and falls back to
    installed appliance defaults when the repo layout is unavailable.
    """
    repo_root = current_file.parent.parent.parent.parent

    if running_on_windows:
        default_app_dir = Path('C:/AuditAgent')
        repo_audit_dir = repo_root / 'audits' / 'windows'
        default_audit_dir = str(
            repo_audit_dir if repo_audit_dir.exists() else default_app_dir / 'audits' / 'windows'
        )
        default_agent = str(default_app_dir / 'agent.ps1')
    else:
        default_app_dir = Path('/app')
        repo_audit_dir = repo_root / 'audits' / 'linux'
        default_audit_dir = str(repo_audit_dir if repo_audit_dir.exists() else '/app/audits/linux')
        default_agent = '/app/agent.sh'

    # Standalone local mode keeps all discovered categories available.
    standalone_mode = True

    return {
        'default_app_dir': default_app_dir,
        'default_audit_dir': default_audit_dir,
        'default_agent': default_agent,
        'standalone_mode': standalone_mode,
    }


def get_script_glob(running_on_windows: bool) -> str:
    """Return file glob for audit scripts on current platform."""
    return '*.ps1' if running_on_windows else '*.sh'


def is_category_allowed_for_standalone(
    category_name: str,
    allowed_categories: list,
    standalone_mode: bool,
) -> bool:
    """Determine whether a category is runnable in current mode."""
    _ = standalone_mode
    return category_name in allowed_categories


def get_required_tier_for_category(
    category_name: str,
    community_categories: list,
    starter_categories: list,
    business_categories: list,
    professional_categories: list,
    tier_community: str,
    tier_starter: str,
    tier_business: str,
    tier_professional: str,
    standalone_mode: bool,
) -> str:
    """Resolve required tier shown in UI metadata."""
    _ = standalone_mode
    if category_name in community_categories:
        return tier_community
    if category_name in starter_categories:
        return tier_starter
    if category_name in business_categories:
        return tier_business
    if category_name in professional_categories:
        return tier_professional
    return tier_professional


def resolve_requested_audit_path(audit_path: str, audit_dir: str) -> Path | None:
    """Resolve user-requested audit path safely against the standalone audit root."""
    if not audit_path:
        return None

    audit_root = Path(audit_dir).parent.resolve()
    normalized = audit_path.replace('\\', '/').lstrip('/').strip()

    candidate = Path(normalized)
    if not candidate.is_absolute():
        candidate = audit_root / candidate

    candidate = candidate.resolve()

    try:
        candidate.relative_to(audit_root)
    except ValueError:
        return None

    return candidate if candidate.exists() else None


def extract_audit_category(audit_path: str) -> str | None:
    """Extract audit category from a relative audit path."""
    if not audit_path:
        return None

    parts = [p for p in audit_path.replace('\\', '/').split('/') if p]
    for part in parts:
        if part.lower() in KNOWN_AUDIT_CATEGORIES:
            return part
    return None


def is_script_allowed_for_standalone(
    filename: str,
    category_name: str | None,
    standalone_mode: bool,
    license_manager,
) -> bool:
    """Evaluate script access for standalone and non-standalone flows."""
    _ = standalone_mode
    return bool(license_manager.is_script_allowed(filename, category_name))


def script_stem(filename: str) -> str:
    """Return filename stem that is stable across .sh and .ps1 scripts."""
    lower = filename.lower()
    if lower.endswith('.ps1'):
        return filename[:-4]
    if lower.endswith('.sh'):
        return filename[:-3]
    return Path(filename).stem
