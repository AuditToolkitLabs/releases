"""Compatibility package for importing html-standalone modules via underscore path."""
