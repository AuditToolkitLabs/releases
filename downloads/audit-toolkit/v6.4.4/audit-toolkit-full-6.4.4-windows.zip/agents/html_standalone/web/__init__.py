"""Compatibility web package for html_standalone import path."""
