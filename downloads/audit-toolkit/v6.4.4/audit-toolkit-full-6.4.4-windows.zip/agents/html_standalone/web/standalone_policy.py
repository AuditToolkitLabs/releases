"""Compatibility module bridging `agents.html_standalone.web.standalone_policy`.

Loads the real module from `agents/html-standalone/web/standalone_policy.py` so
callers can use underscore import paths without depending on dash paths.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

_COMPAT_FILE = Path(__file__).resolve()
_REAL_PACKAGE_ROOT = _COMPAT_FILE.parents[2] / "html-standalone"
_REAL_MODULE_FILE = _REAL_PACKAGE_ROOT / "web" / "standalone_policy.py"

if str(_REAL_PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(_REAL_PACKAGE_ROOT))

_spec = importlib.util.spec_from_file_location("_html_standalone_real_policy", _REAL_MODULE_FILE)
if _spec is None or _spec.loader is None:
    raise ImportError(f"Unable to load standalone policy module from {_REAL_MODULE_FILE}")

_real_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_real_module)

for _name, _value in vars(_real_module).items():
    if _name.startswith("__") and _name not in {"__all__", "__doc__"}:
        continue
    globals()[_name] = _value

if "__all__" not in globals():
    __all__ = [name for name in globals() if not name.startswith("_")]
