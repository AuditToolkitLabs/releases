package com.audittool.agent;

import com.audittool.agent.config.AgentMode;
import java.util.concurrent.CountDownLatch;

public final class Main {
    private Main() {
    }

    public static void main(String[] args) {
        AgentMode mode = resolveMode(args);
        System.out.println("Audit Tool JRE Consolidated Agent");
        System.out.println("Mode: " + mode.name());
        System.out.println("Status: bootstrap initialized");
        System.out.println("Access UI on host:");
        System.out.println("  HTTP : http://<host-or-ip>:5000");
        System.out.println("  HTTPS: https://<host-or-ip> (if TLS/reverse proxy is enabled)");
        System.out.println("Status: agent running (background-capable)");

        Runtime.getRuntime().addShutdownHook(new Thread(() ->
            System.out.println("Status: shutdown signal received")
        ));

        try {
            new CountDownLatch(1).await();
        } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    static AgentMode resolveMode(String[] args) {
        for (String arg : args) {
            if (arg == null || arg.isBlank()) {
                continue;
            }
            if (arg.startsWith("--mode=")) {
                return AgentMode.from(arg.substring("--mode=".length()));
            }
            if (arg.equalsIgnoreCase("--managed")) {
                return AgentMode.MANAGED;
            }
            if (arg.equalsIgnoreCase("--standalone")) {
                return AgentMode.STANDALONE;
            }
        }

        String modeFromEnv = System.getenv("AGENT_MODE");
        return AgentMode.from(modeFromEnv);
    }
}
