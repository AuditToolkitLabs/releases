package com.audittool.agent.config;

public enum AgentMode {
    STANDALONE,
    MANAGED;

    public static AgentMode from(String value) {
        if (value == null) {
            return STANDALONE;
        }
        String normalized = value.trim().toUpperCase();
        if ("MANAGED".equals(normalized)) {
            return MANAGED;
        }
        return STANDALONE;
    }
}
