﻿<#
.SYNOPSIS
    Configure network settings on test VMs after OS installation.

.DESCRIPTION
    This script helps configure static IPs on newly installed test VMs.
    Supports both Windows and Linux VMs via PowerShell remoting and SSH.

.PARAMETER VMName
    Name of the VM to configure.

.PARAMETER IPAddress
    Static IP address to assign.

.PARAMETER Gateway
    Gateway IP address (default: 192.168.100.1).

.PARAMETER DNSServers
    DNS server addresses (default: 8.8.8.8, 8.8.4.4).

.PARAMETER Credential
    Credentials for connecting to the VM.

.EXAMPLE
    .\Configure-VMNetwork.ps1 -VMName "WinServer2019-Test" -IPAddress "192.168.100.10"

.EXAMPLE
    $cred = Get-Credential
    .\Configure-VMNetwork.ps1 -VMName "Ubuntu2204-Test" -IPAddress "192.168.100.20" -Credential $cred

.NOTES
    For Windows VMs: Uses PowerShell remoting (WinRM must be enabled)
    For Linux VMs: Uses SSH (plink from PuTTY or OpenSSH)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')]
    [string]$IPAddress,

    [Parameter(Mandatory = $false)]
    [string]$Gateway = "192.168.100.1",

    [Parameter(Mandatory = $false)]
    [string[]]$DNSServers = @("8.8.8.8", "8.8.4.4"),

    [Parameter(Mandatory = $false)]
    [PSCredential]$Credential
)

function Write-Step {
    param([string]$Message)
    Write-Output "`n===> $Message"
}

function Write-Success {
    param([string]$Message)
    Write-Output "✓ $Message"
}

Write-Step "Configuring Network for VM: $VMName"

# Detect OS type from VM name
$isLinuxTargetVm = $VMName -like "*Ubuntu*" -or $VMName -like "*Linux*"

if ($isLinuxTargetVm) {
    Write-Output "Detected: Linux VM"
    Write-Output "`nFor Ubuntu VMs, please configure manually:"
    Write-Output @"

1. Connect to VM console:
   vmconnect localhost '$VMName'

2. Edit network configuration:
   sudo nano /etc/netplan/00-installer-config.yaml

3. Add this configuration:
   network:
     ethernets:
       eth0:
         addresses: [$IPAddress/24]
         gateway4: $Gateway
         nameservers:
           addresses: [$($DNSServers -join ', ')]
     version: 2

4. Apply configuration:
   sudo netplan apply

5. Verify:
   ip addr show
   ping $Gateway

"@ -ForegroundColor White
} else {
    Write-Output "Detected: Windows VM"

    if (-not $Credential) {
        $Credential = Get-Credential -Message "Enter credentials for $VMName"
    }

    Write-Output "Connecting to $VMName via WinRM..."

    try {
        $session = New-PSSession -VMName $VMName -Credential $Credential -ErrorAction Stop

        Write-Verbose "Session established. Configuring network..."

        Invoke-Command -Session $session -ScriptBlock {

            # Get Ethernet adapter
            $adapter = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.Name -like 'Ethernet*' } | Select-Object -First 1

            if (-not $adapter) {
                throw "No active Ethernet adapter found"
            }

            Write-Output "Configuring adapter: $($adapter.Name)"

            # Remove existing IP configuration
            $existingIP = Get-NetIPAddress -InterfaceAlias $adapter.Name -AddressFamily IPv4 -ErrorAction SilentlyContinue
            if ($existingIP -and $existingIP.IPAddress -ne $using:IPAddress) {
                Remove-NetIPAddress -InterfaceAlias $adapter.Name -AddressFamily IPv4 -Confirm:$false -ErrorAction SilentlyContinue
                Remove-NetRoute -InterfaceAlias $adapter.Name -Confirm:$false -ErrorAction SilentlyContinue
            }

            # Set static IP
            New-NetIPAddress -InterfaceAlias $adapter.Name -IPAddress $using:IPAddress -PrefixLength 24 -DefaultGateway $using:Gateway -ErrorAction Stop

            # Set DNS servers
            Set-DnsClientServerAddress -InterfaceAlias $adapter.Name -ServerAddresses $using:DNSServers -ErrorAction Stop

            # Verify configuration
            $config = Get-NetIPAddress -InterfaceAlias $adapter.Name -AddressFamily IPv4
            return $config

        }

        Remove-PSSession -Session $session

        Write-Success "Network configuration applied successfully"
        Write-Output "  IP Address: $IPAddress"
        Write-Output "  Gateway: $Gateway"
        Write-Output "  DNS: $($DNSServers -join ', ')"

        # Test connectivity
        Write-Step "Testing connectivity"
        Start-Sleep -Seconds 2

        $pingResult = Test-Connection -ComputerName $IPAddress -Count 2 -Quiet
        if ($pingResult) {
            Write-Success "VM is reachable at $IPAddress"
        } else {
            Write-Output "⚠ Cannot ping VM yet. This is normal, may need to wait for network to stabilize"
        }

    } catch {
        Write-Output "✗ Failed to configure network: $_"
        Write-Output "`nManual configuration:"
        Write-Output @"

1. Connect to VM console:
   vmconnect localhost '$VMName'

2. Open PowerShell as Administrator and run:
   `$adapter = Get-NetAdapter | Where-Object Status -eq 'Up' | Select-Object -First 1
   New-NetIPAddress -InterfaceAlias `$adapter.Name -IPAddress $IPAddress -PrefixLength 24 -DefaultGateway $Gateway
   Set-DnsClientServerAddress -InterfaceAlias `$adapter.Name -ServerAddresses '$($DNSServers -join "','")'

"@ -ForegroundColor White
    }
}

