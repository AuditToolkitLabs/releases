﻿<#
.SYNOPSIS
    Configure WinRM on Windows test VMs for remote PowerShell access.

.DESCRIPTION
    This script configures WinRM on Windows VMs including:
    - Enabling PowerShell Remoting
    - Configuring WinRM service
    - Creating HTTP and HTTPS listeners
    - Configuring firewall rules
    - Setting appropriate authentication methods

.PARAMETER VMName
    Name of the VM to configure. If not specified, configures local machine.

.PARAMETER Credential
    Credentials for connecting to the VM (required if VMName is specified).

.PARAMETER EnableHTTPS
    Create HTTPS listener with self-signed certificate (recommended).

.PARAMETER SkipFirewall
    Skip firewall rule configuration (not recommended).

.EXAMPLE
    .\Configure-WinRM.ps1
    # Configures WinRM on local machine

.EXAMPLE
    $cred = Get-Credential
    .\Configure-WinRM.ps1 -VMName "WinServer2019-Test" -Credential $cred -EnableHTTPS

.NOTES
    Must run as Administrator (or with admin credentials for remote VMs)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$VMName,

    [Parameter(Mandatory = $false)]
    [PSCredential]$Credential,

    [Parameter(Mandatory = $false)]
    [switch]$EnableHTTPS,

    [Parameter(Mandatory = $false)]
    [switch]$SkipFirewall
)

function Write-Step {
    param([string]$Message)
    Write-Output "`n===> $Message"
}

function Write-Success {
    param([string]$Message)
    Write-Output "✓ $Message"
}

$configScript = {
    param($EnableHTTPS, $SkipFirewall)

    Write-Output "Configuring WinRM on: $env:COMPUTERNAME"

    # Enable PowerShell Remoting
    Write-Output "`nEnabling PowerShell Remoting..."
    try {
        Enable-PSRemoting -Force -SkipNetworkProfileCheck -ErrorAction Stop
        Write-Output "✓ PowerShell Remoting enabled"
    } catch {
        Write-Output "✗ Failed to enable PS Remoting: $_"
        return $false
    }

    # Configure WinRM service
    Write-Output "`nConfiguring WinRM service..."
    try {
        Set-Service WinRM -StartupType Automatic -ErrorAction Stop
        Start-Service WinRM -ErrorAction Stop
        Write-Output "✓ WinRM service configured and started"
    } catch {
        Write-Output "✗ Failed to configure WinRM service: $_"
        return $false
    }

    # Configure authentication
    Write-Output "`nConfiguring authentication..."
    try {
        Set-Item WSMan:\localhost\Service\Auth\Basic -Value $true -Force
        Set-Item WSMan:\localhost\Service\Auth\CredSSP -Value $false -Force
        Write-Output "✓ Authentication configured (Basic: Enabled, CredSSP: Disabled)"
    } catch {
        Write-Output "⚠ Warning: Could not configure authentication: $_"
    }

    # Configure HTTP listener (port 5985)
    Write-Output "`nConfiguring HTTP listener..."
    $httpListener = Get-ChildItem WSMan:\localhost\Listener | Where-Object { $_.Keys -contains "Transport=HTTP" }
    if ($httpListener) {
        Write-Output "✓ HTTP listener already exists"
    } else {
        try {
            New-Item -Path WSMan:\localhost\Listener -Address * -Transport HTTP -Force | Out-Null
            Write-Output "✓ HTTP listener created (port 5985)"
        } catch {
            Write-Output "⚠ Warning: Could not create HTTP listener: $_"
        }
    }

    # Configure HTTPS listener (port 5986) if requested
    if ($EnableHTTPS) {
        Write-Output "`nConfiguring HTTPS listener..."

        # Check for existing HTTPS listener
        $httpsListener = Get-ChildItem WSMan:\localhost\Listener | Where-Object { $_.Keys -contains "Transport=HTTPS" }

        if ($httpsListener) {
            Write-Output "✓ HTTPS listener already exists"
        } else {
            # Create self-signed certificate
            try {
                $cert = New-SelfSignedCertificate -DnsName $env:COMPUTERNAME -CertStoreLocation Cert:\LocalMachine\My -ErrorAction Stop
                Write-Output "✓ Self-signed certificate created"

                # Create HTTPS listener
                New-Item -Path WSMan:\localhost\Listener -Address * -Transport HTTPS -CertificateThumbPrint $cert.Thumbprint -Force | Out-Null
                Write-Output "✓ HTTPS listener created (port 5986)"
            } catch {
                Write-Output "⚠ Warning: Could not create HTTPS listener: $_"
            }
        }
    }

    # Configure firewall rules
    if (-not $SkipFirewall) {
        Write-Output "`nConfiguring firewall rules..."

        # HTTP rule
        $httpRule = Get-NetFirewallRule -Name "WinRM-HTTP" -ErrorAction SilentlyContinue
        if ($httpRule) {
            Write-Output "✓ Firewall rule for HTTP already exists"
        } else {
            try {
                New-NetFirewallRule -Name "WinRM-HTTP" -DisplayName "Windows Remote Management (HTTP-In)" `
                    -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5985 -ErrorAction Stop | Out-Null
                Write-Output "✓ Firewall rule created for HTTP (port 5985)"
            } catch {
                Write-Output "⚠ Warning: Could not create HTTP firewall rule: $_"
            }
        }

        # HTTPS rule (if HTTPS enabled)
        if ($EnableHTTPS) {
            $httpsRule = Get-NetFirewallRule -Name "WinRM-HTTPS" -ErrorAction SilentlyContinue
            if ($httpsRule) {
                Write-Output "✓ Firewall rule for HTTPS already exists"
            } else {
                try {
                    New-NetFirewallRule -Name "WinRM-HTTPS" -DisplayName "Windows Remote Management (HTTPS-In)" `
                        -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5986 -ErrorAction Stop | Out-Null
                    Write-Output "✓ Firewall rule created for HTTPS (port 5986)"
                } catch {
                    Write-Output "⚠ Warning: Could not create HTTPS firewall rule: $_"
                }
            }
        }
    }

    # Test configuration
    Write-Output "`nTesting WinRM configuration..."
    try {
        Test-WSMan -ComputerName localhost -ErrorAction Stop | Out-Null
        Write-Output "✓ WinRM is working correctly!"
        return $true
    } catch {
        Write-Output "✗ WinRM test failed: $_"
        return $false
    }
}

# Main execution
Write-Output "`n╔════════════════════════════════════════════════════════════════════╗"
Write-Output "║              WinRM Configuration Script                          ║"
Write-Output "╚════════════════════════════════════════════════════════════════════╝`n"

if ($VMName) {
    # Configure remote VM
    Write-Step "Configuring WinRM on VM: $VMName"

    if (-not $Credential) {
        $Credential = Get-Credential -Message "Enter credentials for $VMName"
    }

    try {
        Write-Output "Connecting to $VMName..."
        $session = New-PSSession -VMName $VMName -Credential $Credential -ErrorAction Stop

        $result = Invoke-Command -Session $session -ScriptBlock $configScript -ArgumentList $EnableHTTPS, $SkipFirewall

        Remove-PSSession -Session $session

        if ($result) {
            Write-Success "`nWinRM configuration completed successfully on $VMName"
        } else {
            Write-Output "`n✗ WinRM configuration failed on $VMName"
            exit 1
        }
    } catch {
        Write-Output "`n✗ Failed to connect to VM: $_"
        Write-Output "`nManual configuration required:"
        Write-Output "1. Connect to VM console: vmconnect localhost '$VMName'"
        Write-Output "2. Run this script locally on the VM: .\Configure-WinRM.ps1 -EnableHTTPS"
        exit 1
    }
} else {
    # Configure local machine
    Write-Step "Configuring WinRM on local machine"

    # Check admin privileges
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Output "✗ This script must be run as Administrator"
        exit 1
    }

    $result = & $configScript $EnableHTTPS $SkipFirewall

    if ($result) {
        Write-Success "`nWinRM configuration completed successfully"
    } else {
        Write-Output "`n✗ WinRM configuration failed"
        exit 1
    }
}

# Show configuration summary
Write-Output "`n═══ CONFIGURATION SUMMARY ═══`n"
Write-Output "WinRM HTTP Listener: Port 5985"
if ($EnableHTTPS) {
    Write-Output "WinRM HTTPS Listener: Port 5986"
}
Write-Output "Authentication: Basic (Enabled), CredSSP (Disabled)"
Write-Output "Firewall: Rules configured"

Write-Output "`n═══ NEXT STEPS ═══`n"
Write-Output "1. Configure TrustedHosts on your development machine:"
Write-Output "   Set-Item WSMan:\localhost\Client\TrustedHosts -Value '192.168.100.*' -Force`n"

Write-Output "2. Test remote connection:"
if ($VMName) {
    $vm = Get-VM -Name $VMName -ErrorAction SilentlyContinue
    if ($vm) {
        $ipGuess = "192.168.100.10"  # Default guess
        Write-Output "   Test-WSMan -ComputerName $ipGuess"
        Write-Output "   Enter-PSSession -ComputerName $ipGuess -Credential (Get-Credential)`n"
    }
} else {
    Write-Output "   Test-WSMan -ComputerName localhost"
    Write-Output "   # From another machine:"
    Write-Output "   Test-WSMan -ComputerName <this-machine-ip>`n"
}

Write-Output "3. Run Phase 1 validation tests (see WINDOWS-TEST-ENVIRONMENT-SETUP.md)`n"

Write-Output "✓ WinRM is ready for remote PowerShell access!`n"

