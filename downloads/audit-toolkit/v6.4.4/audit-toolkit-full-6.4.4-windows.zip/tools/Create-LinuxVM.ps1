<#
.SYNOPSIS
    Creates a Linux VM on Hyper-V with proper settings for ISO boot

.DESCRIPTION
    Sets up a Generation 2 VM with Secure Boot disabled (or Microsoft UEFI CA)
    and mounts the ISO for installation. Handles common Linux VM issues.

.PARAMETER VMName
    Name for the new VM (default: TestLab-Ubuntu)

.PARAMETER ISOPath
    Path to the Linux ISO file

.PARAMETER VHDPath
    Path where the virtual hard disk will be created

.PARAMETER MemoryGB
    Memory in GB (default: 2)

.PARAMETER DiskSizeGB
    Disk size in GB (default: 40)

.PARAMETER CPUCount
    Number of virtual CPUs (default: 2)

.PARAMETER SwitchName
    Virtual switch to connect (default: AuditLabSwitch)

.EXAMPLE
    .\Create-LinuxVM.ps1 -VMName "TestLab-Ubuntu" -ISOPath "C:\ISOs\ubuntu-22.04.iso"

.NOTES
    Requires: Hyper-V, Run as Administrator
#>

#Requires -RunAsAdministrator

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPositionalParameters', '', Justification='Positional usage is intentional in stabilized scripts; named-argument refactors deferred to avoid behavior drift')]
param(
    [Parameter()]
    [string]$VMName = "TestLab-Ubuntu",

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path $_ })]
    [string]$ISOPath,

    [Parameter()]
    [string]$VHDPath = "",

    [Parameter()]
    [int]$MemoryGB = 2,

    [Parameter()]
    [int]$DiskSizeGB = 40,

    [Parameter()]
    [int]$CPUCount = 2,

    [Parameter()]
    [string]$SwitchName = "AuditLabSwitch",

    [Parameter()]
    [string]$StaticIP = "192.168.100.50",

    [Parameter()]
    [switch]$UseGeneration1
)

$ErrorActionPreference = "Stop"

function Write-Step { param($msg) Write-Host "`n[*] $msg" -ForegroundColor Cyan }
function Write-Success { param($msg) Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-Warn { param($msg) Write-Host "[!] $msg" -ForegroundColor Yellow }
function Write-Fail { param($msg) Write-Host "[X] $msg" -ForegroundColor Red }

Write-Output -InputObject "=" * 70
Write-Output -InputObject "Linux VM Creator for Hyper-V"
Write-Output -InputObject "=" * 70

# Set default VHD path if not specified
if (-not $VHDPath) {
    $defaultVMPath = (Get-VMHost).VirtualHardDiskPath
    if (-not $defaultVMPath) {
        $defaultVMPath = "C:\Hyper-V\Virtual Hard Disks"
    }
    $VHDPath = Join-Path $defaultVMPath "$VMName.vhdx"
}

Write-Output -InputObject "`nConfiguration:"
Write-Output -InputObject "  VM Name:     $VMName"
Write-Output -InputObject "  ISO:         $ISOPath"
Write-Output -InputObject "  VHD:         $VHDPath"
Write-Output -InputObject "  Memory:      ${MemoryGB}GB"
Write-Output -InputObject "  Disk:        ${DiskSizeGB}GB"
Write-Output -InputObject "  CPUs:        $CPUCount"
Write-Output -InputObject "  Switch:      $SwitchName"
Write-Output -InputObject "  Generation:  $(if($UseGeneration1){'1 (Legacy BIOS)'}else{'2 (UEFI)'})"

# Check if VM already exists
Write-Step "Checking for existing VM..."
$existingVM = Get-VM -Name $VMName -ErrorAction SilentlyContinue
if ($existingVM) {
    Write-Warn "VM '$VMName' already exists"
    $response = Read-Host "Delete and recreate? (y/n)"
    if ($response -eq 'y') {
        if ($existingVM.State -eq 'Running') {
            Stop-VM -Name $VMName -Force -TurnOff
        }
        Remove-VM -Name $VMName -Force
        if (Test-Path $VHDPath) {
            Remove-Item $VHDPath -Force
        }
        Write-Success "Existing VM removed"
    }
    else {
        Write-Output -InputObject "Aborted."
        exit 0
    }
}

# Check/Create virtual switch
Write-Step "Checking virtual switch..."
$switch = Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue
if (-not $switch) {
    Write-Warn "Switch '$SwitchName' not found. Creating internal switch..."
    New-VMSwitch -Name $SwitchName -SwitchType Internal

    # Configure host IP on the switch
    $adapter = Get-NetAdapter | Where-Object { $_.Name -like "*$SwitchName*" }
    if ($adapter) {
        New-NetIPAddress -InterfaceIndex $adapter.ifIndex -IPAddress "192.168.100.1" -PrefixLength 24 -ErrorAction SilentlyContinue
        Write-Success "Switch created with host IP 192.168.100.1/24"
    }
}
else {
    Write-Success "Switch '$SwitchName' found"
}

# Create VHD directory if needed
$vhdDir = Split-Path $VHDPath -Parent
if (-not (Test-Path $vhdDir)) {
    New-Item -Path $vhdDir -ItemType Directory -Force | Out-Null
    Write-Success "Created VHD directory: $vhdDir"
}

# Create the VM
Write-Step "Creating VM..."
$generation = if ($UseGeneration1) { 1 } else { 2 }

$vmParams = @{
    Name               = $VMName
    MemoryStartupBytes = $MemoryGB * 1GB
    Generation         = $generation
    NewVHDPath         = $VHDPath
    NewVHDSizeBytes    = $DiskSizeGB * 1GB
    SwitchName         = $SwitchName
}

New-VM @vmParams | Out-Null
Write-Success "VM created"

# Configure VM settings
Write-Step "Configuring VM settings..."

# Set CPU count
Set-VMProcessor -VMName $VMName -Count $CPUCount

# Enable dynamic memory
Set-VMMemory -VMName $VMName -DynamicMemoryEnabled $true -MinimumBytes 512MB -MaximumBytes ($MemoryGB * 2 * 1GB)

# Disable checkpoints for testing
Set-VM -VMName $VMName -CheckpointType Disabled

Write-Success "CPU: $CPUCount, Dynamic Memory enabled"

# Generation 2 specific settings (UEFI/Secure Boot)
if (-not $UseGeneration1) {
    Write-Step "Configuring Generation 2 settings..."

    # CRITICAL: Disable Secure Boot OR set to Microsoft UEFI Certificate Authority for Linux
    # Most Linux distros need Secure Boot disabled or the Microsoft UEFI CA

    Write-Warn "Disabling Secure Boot for Linux compatibility..."
    Set-VMFirmware -VMName $VMName -EnableSecureBoot Off
    Write-Success "Secure Boot disabled"

    # Alternative: Use Microsoft UEFI CA (works with Ubuntu, Fedora, RHEL)
    # Set-VMFirmware -VMName $VMName -SecureBootTemplate MicrosoftUEFICertificateAuthority
}

# Mount ISO
Write-Step "Mounting ISO..."
if ($UseGeneration1) {
    # Gen 1: Use IDE controller
    Set-VMDvdDrive -VMName $VMName -Path $ISOPath
}
else {
    # Gen 2: Add DVD drive to SCSI controller
    Add-VMDvdDrive -VMName $VMName -Path $ISOPath
}
Write-Success "ISO mounted: $(Split-Path $ISOPath -Leaf)"

# Set boot order (ISO first)
Write-Step "Setting boot order..."
if ($UseGeneration1) {
    # Gen 1: Set boot order via BIOS
    Set-VMBios -VMName $VMName -StartupOrder @("CD", "IDE", "LegacyNetworkAdapter", "Floppy")
}
else {
    # Gen 2: Set firmware boot order
    $dvd = Get-VMDvdDrive -VMName $VMName
    $hdd = Get-VMHardDiskDrive -VMName $VMName
    Set-VMFirmware -VMName $VMName -BootOrder $dvd, $hdd
}
Write-Success "Boot order set: DVD first, then HDD"

# Enable guest services for integration
Write-Step "Enabling integration services..."
Enable-VMIntegrationService -VMName $VMName -Name "Guest Service Interface" -ErrorAction SilentlyContinue
Write-Success "Guest services enabled"

# Summary
Write-Output -InputObject "`n" + "=" * 70
Write-Output -InputObject "VM CREATED SUCCESSFULLY"
Write-Output -InputObject "=" * 70

Write-Output -InputObject @"

VM Details:
  Name:        $VMName
  Generation:  $generation
  Memory:      ${MemoryGB}GB (dynamic)
  Disk:        ${DiskSizeGB}GB
  CPUs:        $CPUCount
  ISO:         $(Split-Path $ISOPath -Leaf)
  Switch:      $SwitchName

Important Notes for Linux Installation:
  1. Secure Boot is DISABLED (required for most Linux distros)
  2. Boot order is set to DVD first
  3. After installation, configure network manually:
     - IP: $StaticIP
     - Gateway: 192.168.100.1
     - DNS: 8.8.8.8

To start the VM:
  Start-VM -Name '$VMName'

To connect to console:
  vmconnect localhost '$VMName'

After Linux is installed, configure SSH:
  sudo apt install openssh-server  # Ubuntu/Debian
  sudo systemctl enable ssh
  sudo systemctl start ssh

Then test from Windows:
  ssh root@$StaticIP

"@

# Ask to start
$startNow = Read-Host "`nStart VM now and open console? (y/n)"
if ($startNow -eq 'y') {
    Write-Step "Starting VM..."
    Start-VM -Name $VMName
    Write-Success "VM started"

    Write-Step "Opening VM console..."
    Start-Process vmconnect -ArgumentList "localhost", $VMName

    Write-Output -InputObject "`nThe VM console should open. Boot from the ISO and complete installation."
    Write-Output -InputObject "Remember to set static IP $StaticIP during or after installation."
}

Write-Output -InputObject "`nDone!"


