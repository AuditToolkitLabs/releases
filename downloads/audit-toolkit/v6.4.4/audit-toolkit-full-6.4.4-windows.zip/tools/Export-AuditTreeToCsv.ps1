[CmdletBinding()]
param(
  [Parameter(Mandatory = $false)]
  [string]$RepoRoot = (Get-Location).Path,

  [Parameter(Mandatory = $false)]
  [string]$AuditsFolder = "audits",

  [Parameter(Mandatory = $false)]
  [string]$OutputCsv = $null,

  [Parameter(Mandatory = $false)]
  [int]$MaxDepth = [int]::MaxValue,

  [switch]$IncludeHash
)

$ErrorActionPreference = "Stop"

# Resolve paths
$RepoRoot   = (Resolve-Path -LiteralPath $RepoRoot).Path
$AuditsRoot = Join-Path $RepoRoot $AuditsFolder

if (-not (Test-Path $AuditsRoot)) {
  throw "Audits folder not found at: $AuditsRoot"
}

if (-not $OutputCsv) {
  $OutputCsv = Join-Path $RepoRoot "audits_inventory_after.csv"
}

function Get-RelativePath([string]$Base, [string]$Path) {
  $uBase = [IO.Path]::GetFullPath($Base)
  $uPath = [IO.Path]::GetFullPath($Path)
  $uriBase = New-Object System.Uri($uBase + [IO.Path]::DirectorySeparatorChar)
  $uriPath = New-Object System.Uri($uPath)
  $rel = $uriBase.MakeRelativeUri($uriPath).ToString()
  return ($rel -replace '/', '\')
}

function Split-DomainSub([string]$RelativePath) {
  $parts = $RelativePath -split '[\\/]'
  $domain = $null; $sub = $null
  if ($parts.Length -ge 2 -and $parts[0] -ieq 'audits') {
    $domain = $parts[1]
    if ($parts.Length -ge 3) {
      $likelySubs = @(
        'baseline','access','firewall','services','servers','tls','headers',
        'relational','search','php','deps','object','archive','backup-dr','orchestrators','_lib'
      )
      if ($likelySubs -contains $parts[2]) { $sub = $parts[2] }
    }
  }
  return @($domain, $sub)
}

function Get-FileSha1([string]$Path) {
  try {
    $sha1 = [System.Security.Cryptography.SHA1]::Create()
    $fs = [System.IO.File]::OpenRead($Path)
    try {
      $hash = $sha1.ComputeHash($fs)
      ($hash | ForEach-Object { $_.ToString("x2") }) -join ''
    } finally { $fs.Dispose(); $sha1.Dispose() }
  } catch { $null }
}

Write-Output "Scanning: $AuditsRoot"

$items = Get-ChildItem -LiteralPath $AuditsRoot -Force -Recurse -ErrorAction Stop

if ($MaxDepth -lt [int]::MaxValue) {
  $items = $items | Where-Object {
    $rel = Get-RelativePath -Base $AuditsRoot -Path $_.FullName
    ($rel -split '[\\/]').Length -le $MaxDepth
  }
}

$result = foreach ($it in $items) {
  $relAudits = Get-RelativePath -Base $RepoRoot -Path $it.FullName
  $depth     = ($relAudits -split '[\\/]').Length
  $pathType  = if ($it.PSIsContainer) { 'Folder' } else { 'File' }
  $name      = $it.Name
  $size      = if ($it.PSIsContainer) { $null } else { $it.Length }
  $modified  = $it.LastWriteTime
  $domain,$sub = Split-DomainSub -RelativePath $relAudits

  $row = [ordered]@{
    PathType       = $pathType
    Domain         = $domain
    Subdomain      = $sub
    RelativePath   = $relAudits
    Name           = $name
    Depth          = $depth
    SizeBytes      = $size
    LastWriteTime  = $modified
  }

  if (-not $it.PSIsContainer -and $IncludeHash) {
    $row['SHA1'] = Get-FileSha1 -Path $it.FullName
  }

  [pscustomobject]$row
}

$csvDir = Split-Path -Path ($OutputCsv) -Parent
if (-not (Test-Path $csvDir)) { New-Item -ItemType Directory -Path $csvDir -Force | Out-Null }

$result | Sort-Object RelativePath, PathType | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $OutputCsv

Write-Output "Done. CSV written to: $OutputCsv"
