# Hyper-V Test Lab Setup Guide

## ISO Storage Location

Place all ISO files in: **`C:\ISO\`**

This is the default path used by `hyperv-lab.ps1`. You can override it with the `-ISOPath` parameter.

```powershell
# Using default path
.\tools\hyperv-lab.ps1 -Action Create -LabProfile Standard

# Using custom ISO path
.\tools\hyperv-lab.ps1 -Action Create -ISOPath "D:\ISOs" -LabProfile Standard
```

---

## Required ISOs by Lab Profile

| Profile | Required ISOs |
|---------|---------------|
| **Minimal** | Windows Server 2022, Ubuntu 22.04 |
| **Standard** | Windows Server 2022, Ubuntu 22.04, CentOS Stream 9 |
| **Full** | Windows Server 2022, Windows 11, Ubuntu 22.04, CentOS Stream 9, Alpine 3.19 |

---

## ISO Download Links (Evaluation/Free Versions)

### Windows Server 2022 (180-day evaluation)

**Filename:** `windows_server_2022.iso`

**Download:** https://www.microsoft.com/en-us/evalcenter/evaluate-windows-server-2022

- Select "ISO" format
- Choose "64-bit edition"
- Registration required (free Microsoft account)
- Evaluation period: 180 days (can extend 3x for 720 days total)

---

### Windows 11 Enterprise (90-day evaluation)

**Filename:** `windows_11_enterprise.iso`

**Download:** https://www.microsoft.com/en-us/evalcenter/evaluate-windows-11-enterprise

- Select "ISO – Enterprise"
- Choose "64-bit edition"
- Registration required
- Evaluation period: 90 days

---

### Ubuntu Server 22.04 LTS (Free)

**Filename:** `ubuntu-22.04-server.iso`

**Download:** https://ubuntu.com/download/server

- Direct link: https://releases.ubuntu.com/22.04/ubuntu-22.04.4-live-server-amd64.iso
- No registration required
- LTS support until April 2027

---

### CentOS Stream 9 (Free)

**Filename:** `CentOS-Stream-9.iso`

**Download:** https://www.centos.org/centos-stream/

- Direct mirror: https://mirrors.centos.org/mirrorlist?path=/9-stream/BaseOS/x86_64/iso/CentOS-Stream-9-latest-x86_64-dvd1.iso
- No registration required
- Rolling release (continuous updates)

---

### Alpine Linux 3.19 (Free)

**Filename:** `alpine-standard-3.19.iso`

**Download:** https://alpinelinux.org/downloads/

- Select "Standard" x86_64
- Direct link: https://dl-cdn.alpinelinux.org/alpine/v3.19/releases/x86_64/alpine-standard-3.19.1-x86_64.iso
- No registration required
- Smallest footprint (~150MB ISO)

---

### Rocky Linux 9 (Free, RHEL-compatible alternative)

**Filename:** `Rocky-9-latest-x86_64.iso`

**Download:** https://rockylinux.org/download

- Alternative to CentOS for RHEL compatibility testing
- No registration required

---

### Fedora Server 41 (Free)

**Filename:** `Fedora-Server-41.iso`

**Download:** https://fedoraproject.org/server/download

- Latest features, shorter support cycle
- Good for testing cutting-edge packages

---

## Quick Setup Commands

```powershell
# 1. Create ISO directory
New-Item -ItemType Directory -Path "C:\ISO" -Force

# 2. Download ISOs (manual - use links above)

# 3. Verify ISOs are in place
Get-ChildItem C:\ISO\*.iso | Select-Object Name, @{N='Size (GB)';E={[math]::Round($_.Length/1GB,2)}}

# 4. Create lab VMs
.\tools\hyperv-lab.ps1 -Action Create -LabProfile Standard

# 5. Start VMs
.\tools\hyperv-lab.ps1 -Action Start
```

---

## Expected Directory Structure

```
C:\ISO\
├── windows_server_2022.iso      (~5.5 GB)
├── windows_11_enterprise.iso    (~5.5 GB)
├── ubuntu-22.04-server.iso      (~2.0 GB)
├── CentOS-Stream-9.iso          (~10 GB, DVD version)
└── alpine-standard-3.19.iso     (~0.2 GB)
```

**Total disk space needed:**
- Minimal profile: ~7.5 GB
- Standard profile: ~17.5 GB
- Full profile: ~23 GB

---

## Hyper-V VM Storage Location

VMs and virtual hard disks are stored in: **`C:\Hyper-V\Virtual Hard Disks\`**

Override with `-VHDPath` parameter:

```powershell
.\tools\hyperv-lab.ps1 -Action Create -VHDPath "D:\VMs" -LabProfile Standard
```

---

## Troubleshooting

### "ISO not found" warning during VM creation

The VM will be created but won't have boot media. Download the ISO and attach it manually:

```powershell
# Attach ISO to existing VM
Add-VMDvdDrive -VMName "AuditLab-Ubuntu" -Path "C:\ISO\ubuntu-22.04-server.iso"
```

### Checksum verification (optional)

Verify ISO integrity after download:

```powershell
# Get file hash
Get-FileHash "C:\ISO\ubuntu-22.04-server.iso" -Algorithm SHA256

# Compare with published checksum from download page
```

### Windows Evaluation Expiration

Extend Windows evaluation period (run in elevated CMD inside VM):

```cmd
slmgr /rearm
```

Can be done up to 3 times for a total of 720 days (Windows Server) or 360 days (Windows 11).

---

## Alternative: Use Vagrant Boxes

For faster setup without ISOs, use pre-built Vagrant boxes with Hyper-V provider:

```powershell
# Install Vagrant
winget install Hashicorp.Vagrant

# Create Ubuntu VM
vagrant init generic/ubuntu2204
vagrant up --provider=hyperv

# Create Windows Server VM
vagrant init gusztavvargadr/windows-server-2022-standard
vagrant up --provider=hyperv
```

Note: Vagrant boxes are pre-configured but may not match exact production scenarios.
