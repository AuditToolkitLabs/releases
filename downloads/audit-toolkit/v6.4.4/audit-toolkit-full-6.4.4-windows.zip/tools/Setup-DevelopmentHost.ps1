#Requires -RunAsAdministrator
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [switch]$InstallOptionalTools,
    [switch]$SkipHyperV,
    [switch]$SkipReboot,
    [string]$WorkspacePath = "C:\workspace",
    [switch]$UseChocolatey
)

$null = $SkipHyperV, $SkipReboot, $WorkspacePath

$ErrorActionPreference = "Stop"
$Script:InstallLog = Join-Path $env:TEMP ("dev-setup-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$Script:FailedInstalls = @()
$Script:SuccessfulInstalls = @()

$RequiredWingetPackages = @(
    @{ Id = "Git.Git"; Name = "Git for Windows" },
    @{ Id = "Microsoft.VisualStudioCode"; Name = "Visual Studio Code" },
    @{ Id = "Microsoft.PowerShell"; Name = "PowerShell 7" },
    @{ Id = "Python.Python.3.12"; Name = "Python" }
)

$OptionalWingetPackages = @(
    @{ Id = "Microsoft.WindowsTerminal"; Name = "Windows Terminal" },
    @{ Id = "Docker.DockerDesktop"; Name = "Docker Desktop" }
)

$VscodeExtensions = @(
    "ms-vscode.powershell",
    "ms-python.python",
    "ms-python.vscode-pylance",
    "timonwong.shellcheck",
    "eamodio.gitlens",
    "GitHub.vscode-pull-request-github",
    "redhat.vscode-yaml",
    "yzhang.markdown-all-in-one"
)

function Write-SetupLog {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARN", "ERROR", "SUCCESS")]
        [string]$Level = "INFO"
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $Script:InstallLog -Value "[$timestamp] [$Level] $Message"

    Write-Output "[$Level] $Message"
}

function Install-WithWinget {
    param([string]$PackageId, [string]$Name)

    Write-SetupLog "Installing $Name via winget"
    & winget install --id $PackageId --exact --silent --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -eq 0) {
        $Script:SuccessfulInstalls += $Name
        Write-SetupLog "$Name installed" "SUCCESS"
    } else {
        $Script:FailedInstalls += $Name
        Write-SetupLog "$Name install failed" "ERROR"
    }
}

function Install-WithChocolatey {
    param([string]$PackageName, [string]$Name)

    Write-SetupLog "Installing $Name via Chocolatey"
    & choco install $PackageName -y
    if ($LASTEXITCODE -eq 0) {
        $Script:SuccessfulInstalls += $Name
        Write-SetupLog "$Name installed" "SUCCESS"
    } else {
        $Script:FailedInstalls += $Name
        Write-SetupLog "$Name install failed" "ERROR"
    }
}

function Enable-HyperVFeature {
    if ($SkipHyperV) {
        Write-SetupLog "Skipping Hyper-V as requested" "WARN"
        return
    }

    $feature = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All
    if ($feature.State -eq "Enabled") {
        Write-SetupLog "Hyper-V already enabled" "SUCCESS"
        return
    }

    Write-SetupLog "Enabling Hyper-V feature"
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All -NoRestart | Out-Null
    Write-SetupLog "Hyper-V enabled (reboot required)" "SUCCESS"

    if (-not $SkipReboot) {
        Write-SetupLog "Rebooting in 15 seconds" "WARN"
        shutdown.exe /r /t 15
    }
}

function Install-VSCodeExtensions {
    if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
        Write-SetupLog "VS Code CLI not found; skipping extension install" "WARN"
        return
    }

    foreach ($extension in $VscodeExtensions) {
        Write-SetupLog "Installing VS Code extension: $extension"
        & code --install-extension $extension --force
        if ($LASTEXITCODE -ne 0) {
            Write-SetupLog "Failed to install extension: $extension" "WARN"
        }
    }
}

function Initialize-Workspace {
    if (-not (Test-Path -LiteralPath $WorkspacePath)) {
        New-Item -ItemType Directory -Path $WorkspacePath -Force | Out-Null
        Write-SetupLog "Created workspace path: $WorkspacePath" "SUCCESS"
    } else {
        Write-SetupLog "Workspace path exists: $WorkspacePath" "SUCCESS"
    }
}

try {
    Write-SetupLog "Starting development host setup"

    if ($UseChocolatey -and -not (Get-Command choco -ErrorAction SilentlyContinue)) {
        throw "Chocolatey is not installed. Remove -UseChocolatey or install choco first."
    }

    if (-not $UseChocolatey -and -not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw "winget is not installed. Install App Installer or use -UseChocolatey."
    }

    Initialize-Workspace
    Enable-HyperVFeature

    foreach ($pkg in $RequiredWingetPackages) {
        if ($UseChocolatey) {
            Install-WithChocolatey -PackageName $pkg.Id.Split('.')[-1].ToLowerInvariant() -Name $pkg.Name
        } else {
            Install-WithWinget -PackageId $pkg.Id -Name $pkg.Name
        }
    }

    if ($InstallOptionalTools) {
        foreach ($pkg in $OptionalWingetPackages) {
            if ($UseChocolatey) {
                Install-WithChocolatey -PackageName $pkg.Id.Split('.')[-1].ToLowerInvariant() -Name $pkg.Name
            } else {
                Install-WithWinget -PackageId $pkg.Id -Name $pkg.Name
            }
        }
    }

    Install-VSCodeExtensions

    Write-Output ""
    Write-Output "Setup summary"
    Write-Output "Successful installs: $($Script:SuccessfulInstalls.Count)"
    Write-Output "Failed installs: $($Script:FailedInstalls.Count)"
    if ($Script:FailedInstalls.Count -gt 0) {
        Write-Output ("Failed: {0}" -f ($Script:FailedInstalls -join ", "))
    }
    Write-Output "Log: $Script:InstallLog"
}
catch {
    Write-SetupLog $_.Exception.Message "ERROR"
    throw
}

