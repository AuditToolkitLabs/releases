﻿<#
.SYNOPSIS
    Automated Hyper-V test environment setup for OS-Independent Security Audit Toolkit.

.DESCRIPTION
    This script automates the complete setup of a local Hyper-V test environment including:
    - Enabling Hyper-V feature
    - Creating virtual switch with NAT
    - Creating VMs: Ubuntu 22.04, Windows 11, Windows Server 2019/2022
    - Configuring VM resources (CPU, RAM, disk)
    - Setting up network configuration
    - Preparing VMs for WinRM configuration

.PARAMETER ISOPath
    Path to directory containing ISO files. Expected ISOs:
    - ubuntu-22.04-live-server-amd64.iso
    - Windows11_EnglishInternational_x64.iso
    - Windows_Server_2019.iso
    - Windows_Server_2022.iso

.PARAMETER VMPath
    Path where VM virtual hard disks will be stored. Default: C:\Hyper-V

.PARAMETER NetworkSubnet
    Subnet for test environment. Default: 192.168.100.0/24

.PARAMETER SkipHyperVInstall
    Skip Hyper-V feature installation (if already installed).

.PARAMETER VMConfiguration
    VM configuration preset: 'Minimal' (2 VMs), 'Standard' (4 VMs), 'Full' (6 VMs). Default: Standard

.EXAMPLE
    .\Setup-TestEnvironment.ps1 -ISOPath "D:\ISOs" -VMPath "E:\VMs"

.EXAMPLE
    .\Setup-TestEnvironment.ps1 -ISOPath "D:\ISOs" -VMConfiguration Full -SkipHyperVInstall

.NOTES
    Requires: Windows 10/11 Pro or Windows Server with Administrator privileges
    Author: Security Audit Toolkit Team
    Version: 1.0.0
    Date: February 6, 2026
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, HelpMessage = "Path to directory containing ISO files")]
    [ValidateScript({Test-Path $_ -PathType Container})]
    [string]$ISOPath,

    [Parameter(Mandatory = $false)]
    [string]$VMPath = "C:\Hyper-V",

    [Parameter(Mandatory = $false)]
    [string]$NetworkSubnet = "192.168.100.0/24",

    [Parameter(Mandatory = $false)]
    [switch]$SkipHyperVInstall,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Minimal', 'Standard', 'Full')]
    [string]$VMConfiguration = 'Standard'
)

$null = $SkipHyperVInstall

#Requires -RunAsAdministrator

# ============================================================
# CONFIGURATION
# ============================================================

$ErrorActionPreference = "Stop"
$VerbosePreference = "Continue"

# VM Configurations
$VMConfigs = @{
    'Ubuntu2204' = @{
        Name = 'Ubuntu2204-Test'
        ISOName = 'ubuntu-22.04-live-server-amd64.iso'
        vCPU = 2
        RAM = 4GB
        DiskSize = 40GB
        IPAddress = '192.168.100.20'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftUEFICertificateAuthority'
        Required = $true
    }
    'Windows11' = @{
        Name = 'Windows11-Test'
        ISOName = 'Windows11_EnglishInternational_x64.iso'
        vCPU = 4
        RAM = 8GB
        DiskSize = 60GB
        IPAddress = '192.168.100.30'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftWindows'
        Required = ($VMConfiguration -in 'Standard', 'Full')
    }
    'WinServer2019' = @{
        Name = 'WinServer2019-Test'
        ISOName = 'Windows_Server_2019.iso'
        vCPU = 4
        RAM = 8GB
        DiskSize = 60GB
        IPAddress = '192.168.100.10'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftWindows'
        Required = $true
    }
    'WinServer2022' = @{
        Name = 'WinServer2022-Test'
        ISOName = 'Windows_Server_2022.iso'
        vCPU = 4
        RAM = 8GB
        DiskSize = 60GB
        IPAddress = '192.168.100.11'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftWindows'
        Required = $true
    }
    'DomainController' = @{
        Name = 'DomainController-Test'
        ISOName = 'Windows_Server_2022.iso'  # Can use 2019 or 2022
        vCPU = 2
        RAM = 4GB
        DiskSize = 40GB
        IPAddress = '192.168.100.12'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftWindows'
        Required = ($VMConfiguration -eq 'Full')
    }
    'AppServer' = @{
        Name = 'AppServer-Test'
        ISOName = 'Windows_Server_2022.iso'  # IIS + SQL Server
        vCPU = 4
        RAM = 8GB
        DiskSize = 80GB
        IPAddress = '192.168.100.13'
        Generation = 2
        SecureBoot = $true
        SecureBootTemplate = 'MicrosoftWindows'
        Required = ($VMConfiguration -eq 'Full')
    }
}

# Network Configuration
$NetworkConfig = @{
    SwitchName = 'TestNetwork'
    SubnetPrefix = $NetworkSubnet.Split('/')[0].Substring(0, $NetworkSubnet.LastIndexOf('.'))
    GatewayIP = ($NetworkSubnet.Split('/')[0].Substring(0, $NetworkSubnet.LastIndexOf('.')) + '.1')
    SubnetMask = '24'
    NATName = 'TestNetworkNAT'
}

# ============================================================
# HELPER FUNCTIONS
# ============================================================

function Write-Step {
    param([string]$Message, [string]$Color = "Cyan")
    $null = $Color
    Write-Output "`n===> $Message"
}

function Write-Success {
    param([string]$Message)
    Write-Output "✓ $Message"
}

function Write-WarnStatus {
    param([string]$Message)
    Write-Output "⚠ $Message"
}

function Write-ErrorMessage {
    param([string]$Message)
    Write-Output "✗ $Message"
}

function Test-Prerequisites {
    Write-Step "Checking Prerequisites" "Cyan"

    # Check Windows version
    $osInfo = Get-CimInstance Win32_OperatingSystem
    $osVersion = $osInfo.Caption
    Write-Verbose "OS: $osVersion"

    if ($osVersion -notmatch "Pro|Enterprise|Server") {
        Write-ErrorMessage "Hyper-V requires Windows 10/11 Pro/Enterprise or Windows Server"
        return $false
    }
    Write-Success "Windows version compatible"

    # Check CPU virtualization support
    $cpu = Get-CimInstance Win32_Processor
    if ($cpu.VirtualizationFirmwareEnabled -eq $false) {
        Write-ErrorMessage "CPU virtualization is disabled in BIOS. Enable Intel VT-x or AMD-V"
        return $false
    }
    Write-Success "CPU virtualization enabled"

    # Check available RAM
    $totalRAM = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 2)
    $requiredRAM = switch ($VMConfiguration) {
        'Minimal' { 16 }
        'Standard' { 24 }
        'Full' { 32 }
    }

    Write-Verbose "Total RAM: ${totalRAM}GB | Required: ${requiredRAM}GB"
    if ($totalRAM -lt $requiredRAM) {
        Write-WarnStatus "RAM is below recommended ${requiredRAM}GB. VMs may run slowly."
    } else {
        Write-Success "Sufficient RAM available (${totalRAM}GB)"
    }

    # Check disk space
    $vmDrive = Split-Path $VMPath -Qualifier
    $disk = Get-PSDrive $vmDrive.TrimEnd(':')
    $freeSpaceGB = [math]::Round($disk.Free / 1GB, 2)
    $requiredSpace = switch ($VMConfiguration) {
        'Minimal' { 200 }
        'Standard' { 300 }
        'Full' { 400 }
    }

    Write-Verbose "Free space on ${vmDrive}: ${freeSpaceGB}GB | Required: ${requiredSpace}GB"
    if ($freeSpaceGB -lt $requiredSpace) {
        Write-ErrorMessage "Insufficient disk space. Need ${requiredSpace}GB, have ${freeSpaceGB}GB"
        return $false
    }
    Write-Success "Sufficient disk space (${freeSpaceGB}GB available)"

    # Check for ISO files
    $missingISOs = @()
    foreach ($vmName in $VMConfigs.Keys) {
        $config = $VMConfigs[$vmName]
        if ($config.Required) {
            $isoPath = Join-Path $ISOPath $config.ISOName
            if (-not (Test-Path $isoPath)) {
                $missingISOs += $config.ISOName
            }
        }
    }

    if ($missingISOs.Count -gt 0) {
        Write-ErrorMessage "Missing required ISO files in ${ISOPath}:"
        $missingISOs | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
        Write-Output "`nDownload locations:"
        Write-Output "  Ubuntu: https://ubuntu.com/download/server"
        Write-Output "  Windows 11: https://www.microsoft.com/software-download/windows11"
        Write-Output "  Windows Server: https://www.microsoft.com/en-us/evalcenter/"
        return $false
    }
    Write-Success "All required ISO files found"

    return $true
}

function Install-HyperVFeature {
    if ($SkipHyperVInstall) {
        Write-Step "Skipping Hyper-V installation (already installed)" "Yellow"
        return
    }

    Write-Step "Installing Hyper-V Feature" "Cyan"

    # Check if Hyper-V is already installed
    $hyperv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All

    if ($hyperv.State -eq "Enabled") {
        Write-Success "Hyper-V is already installed"
        return
    }

    Write-Verbose "Enabling Hyper-V feature..."
    try {
        Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All -NoRestart -ErrorAction Stop
        Write-Success "Hyper-V feature enabled"
        Write-WarnStatus "RESTART REQUIRED! Please restart your computer and re-run this script with -SkipHyperVInstall"
        Write-Output "`nCommand to resume after restart:"
        Write-Output "  .\Setup-TestEnvironment.ps1 -ISOPath '$ISOPath' -VMPath '$VMPath' -VMConfiguration $VMConfiguration -SkipHyperVInstall"
        exit 0
    } catch {
        Write-ErrorMessage "Failed to enable Hyper-V: $_"
        throw
    }
}

function New-TestVirtualSwitch {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param()

    if (-not $PSCmdlet.ShouldProcess($NetworkConfig.SwitchName, 'Create and configure Hyper-V test virtual switch and NAT')) {
        return
    }

    Write-Step "Creating Virtual Network Switch" "Cyan"

    # Check if switch already exists
    $existingSwitch = Get-VMSwitch -Name $NetworkConfig.SwitchName -ErrorAction SilentlyContinue
    if ($existingSwitch) {
        Write-Success "Virtual switch '$($NetworkConfig.SwitchName)' already exists"
        return
    }

    # Create internal virtual switch
    Write-Verbose "Creating internal virtual switch: $($NetworkConfig.SwitchName)"
    try {
        New-VMSwitch -Name $NetworkConfig.SwitchName -SwitchType Internal -ErrorAction Stop | Out-Null
        Write-Success "Virtual switch created"
    } catch {
        Write-ErrorMessage "Failed to create virtual switch: $_"
        throw
    }

    # Get the interface index for the new switch
    Start-Sleep -Seconds 2
    $adapter = Get-NetAdapter | Where-Object { $_.Name -like "vEthernet ($($NetworkConfig.SwitchName))" }

    if (-not $adapter) {
        Write-ErrorMessage "Failed to find virtual adapter for switch"
        throw
    }

    # Configure IP address on host adapter
    Write-Verbose "Configuring IP address on host adapter: $($NetworkConfig.GatewayIP)"
    try {
        New-NetIPAddress -IPAddress $NetworkConfig.GatewayIP -PrefixLength $NetworkConfig.SubnetMask -InterfaceAlias $adapter.Name -ErrorAction Stop | Out-Null
        Write-Success "Host adapter IP configured: $($NetworkConfig.GatewayIP)"
    } catch {
        if ($_.Exception.Message -notmatch "already exists") {
            Write-ErrorMessage "Failed to configure IP: $_"
            throw
        }
        Write-Success "IP address already configured"
    }

    # Configure NAT
    Write-Verbose "Configuring NAT: $($NetworkConfig.NATName)"
    $natSubnet = $NetworkConfig.SubnetPrefix + ".0/$($NetworkConfig.SubnetMask)"

    $existingNAT = Get-NetNat -Name $NetworkConfig.NATName -ErrorAction SilentlyContinue
    if (-not $existingNAT) {
        try {
            New-NetNat -Name $NetworkConfig.NATName -InternalIPInterfaceAddressPrefix $natSubnet -ErrorAction Stop | Out-Null
            Write-Success "NAT configured: $natSubnet"
        } catch {
            Write-ErrorMessage "Failed to configure NAT: $_"
            throw
        }
    } else {
        Write-Success "NAT already configured"
    }
}

function New-TestVM {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory = $true)]
        [string]$VMName,

        [Parameter(Mandatory = $true)]
        [hashtable]$Config
    )

    if (-not $PSCmdlet.ShouldProcess($Config.Name, "Create test VM ($VMName)")) {
        return
    }

    Write-Step "Creating VM: $VMName" "Cyan"

    # Check if VM already exists
    $existingVM = Get-VM -Name $Config.Name -ErrorAction SilentlyContinue
    if ($existingVM) {
        Write-WarnStatus "VM '$($Config.Name)' already exists. Skipping creation."
        return
    }

    # Create VM directory
    $vmDirectory = Join-Path $VMPath $Config.Name
    if (-not (Test-Path $vmDirectory)) {
        New-Item -Path $vmDirectory -ItemType Directory -Force | Out-Null
        Write-Verbose "Created VM directory: $vmDirectory"
    }

    # Create VHD
    $vhdPath = Join-Path $vmDirectory "disk.vhdx"
    Write-Verbose "Creating virtual hard disk: $vhdPath ($(($Config.DiskSize / 1GB))GB)"
    try {
        New-VHD -Path $vhdPath -SizeBytes $Config.DiskSize -Dynamic -ErrorAction Stop | Out-Null
        Write-Success "Virtual hard disk created"
    } catch {
        Write-ErrorMessage "Failed to create VHD: $_"
        throw
    }

    # Create VM
    Write-Verbose "Creating VM with $($Config.vCPU) vCPUs and $(($Config.RAM / 1GB))GB RAM"
    try {
        New-VM -Name $Config.Name `
               -MemoryStartupBytes $Config.RAM `
               -Generation $Config.Generation `
               -SwitchName $NetworkConfig.SwitchName `
               -Path $VMPath `
               -ErrorAction Stop | Out-Null
        Write-Success "VM created"
    } catch {
        Write-ErrorMessage "Failed to create VM: $_"
        throw
    }

    # Configure VM
    Write-Verbose "Configuring VM settings..."
    try {
        Set-VM -Name $Config.Name -ProcessorCount $Config.vCPU -DynamicMemory -ErrorAction Stop
        Set-VM -Name $Config.Name -AutomaticCheckpointsEnabled $false -ErrorAction Stop
        Write-Success "VM configured"
    } catch {
        Write-ErrorMessage "Failed to configure VM: $_"
        throw
    }

    # Attach VHD
    Write-Verbose "Attaching virtual hard disk..."
    try {
        Add-VMHardDiskDrive -VMName $Config.Name -Path $vhdPath -ErrorAction Stop
        Write-Success "Virtual hard disk attached"
    } catch {
        Write-ErrorMessage "Failed to attach VHD: $_"
        throw
    }

    # Configure Secure Boot
    if ($Config.SecureBoot) {
        Write-Verbose "Configuring Secure Boot: $($Config.SecureBootTemplate)"
        try {
            Set-VMFirmware -VMName $Config.Name -EnableSecureBoot On -SecureBootTemplate $Config.SecureBootTemplate -ErrorAction Stop
            Write-Success "Secure Boot configured"
        } catch {
            Write-WarnStatus "Failed to configure Secure Boot: $_"
        }
    }

    # Attach ISO
    $isoPath = Join-Path $ISOPath $Config.ISOName
    Write-Verbose "Attaching installation ISO: $isoPath"
    try {
        Add-VMDvdDrive -VMName $Config.Name -Path $isoPath -ErrorAction Stop

        # Set DVD as first boot device
        $dvd = Get-VMDvdDrive -VMName $Config.Name
        Set-VMFirmware -VMName $Config.Name -FirstBootDevice $dvd -ErrorAction Stop
        Write-Success "Installation ISO attached and set as boot device"
    } catch {
        Write-ErrorMessage "Failed to attach ISO: $_"
        throw
    }

    Write-Success "VM '$($Config.Name)' created successfully"
    Write-Output "  IP Address (to be configured): $($Config.IPAddress)"
}

function Show-Summary {
    param([hashtable]$CreatedVMs)

    Write-Output "`n╔════════════════════════════════════════════════════════════════════╗"
    Write-Output "║          TEST ENVIRONMENT SETUP COMPLETED SUCCESSFULLY           ║"
    Write-Output "╚════════════════════════════════════════════════════════════════════╝`n"

    Write-Output "═══ VIRTUAL MACHINES CREATED ═══`n"

    foreach ($vmName in $CreatedVMs.Keys) {
        $config = $CreatedVMs[$vmName]
        Write-Output "  $($config.Name)"
        Write-Output "    vCPU: $($config.vCPU) | RAM: $(($config.RAM / 1GB))GB | Disk: $(($config.DiskSize / 1GB))GB"
        Write-Output "    IP Address: $($config.IPAddress)"
        Write-Output ""
    }

    Write-Output "═══ NETWORK CONFIGURATION ═══`n"
    Write-Output "  Virtual Switch: $($NetworkConfig.SwitchName)"
    Write-Output "  Network: $NetworkSubnet"
    Write-Output "  Gateway (Host): $($NetworkConfig.GatewayIP)"
    Write-Output "  DNS Servers: 8.8.8.8, 8.8.4.4`n"

    Write-Output "═══ NEXT STEPS ═══`n"

    Write-Output "1. START AND INSTALL VMs"
    Write-Output "   Start each VM and complete OS installation:"
    Write-Output "   Start-VM -Name '<VMName>'"
    Write-Output "   vmconnect localhost '<VMName>'`n"

    Write-Output "2. CONFIGURE STATIC IPs ON GUEST VMs"
    Write-Output "   After OS installation, configure network on each VM:`n"

    Write-Output "   Windows VMs (PowerShell as Administrator):"
    foreach ($vmName in $CreatedVMs.Keys) {
        $config = $CreatedVMs[$vmName]
        if ($vmName -like "Win*") {
            Write-Output "   # $($config.Name)"
            Write-Output "   New-NetIPAddress -InterfaceAlias 'Ethernet' -IPAddress $($config.IPAddress) -PrefixLength 24 -DefaultGateway $($NetworkConfig.GatewayIP)"
            Write-Output "   Set-DnsClientServerAddress -InterfaceAlias 'Ethernet' -ServerAddresses '8.8.8.8','8.8.4.4'`n"
        }
    }

    Write-Output "   Ubuntu VM (edit /etc/netplan/00-installer-config.yaml):"
    $ubuntuConfig = $CreatedVMs['Ubuntu2204']
    if ($ubuntuConfig) {
        Write-Output @"
   network:
     ethernets:
       eth0:
         addresses: [$($ubuntuConfig.IPAddress)/24]
         gateway4: $($NetworkConfig.GatewayIP)
         nameservers:
           addresses: [8.8.8.8, 8.8.4.4]
     version: 2

   sudo netplan apply
"@ -ForegroundColor Yellow
    }

    Write-Output "`n3. CONFIGURE WinRM ON WINDOWS VMs"
    Write-Output "   Run the following on each Windows VM:`n"
    Write-Output @"
   Enable-PSRemoting -Force -SkipNetworkProfileCheck
   Set-Service WinRM -StartupType Automatic
   Start-Service WinRM
   Set-Item WSMan:\localhost\Service\Auth\Basic -Value `$true

   # Create HTTPS listener (optional but recommended)
   `$cert = New-SelfSignedCertificate -DnsName 'TestVM' -CertStoreLocation Cert:\LocalMachine\My
   New-Item WSMan:\localhost\Listener -Address * -Transport HTTPS -CertificateThumbPrint `$cert.Thumbprint -Force

   # Configure firewall
   New-NetFirewallRule -Name 'WinRM-HTTP' -DisplayName 'WinRM HTTP' -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5985
   New-NetFirewallRule -Name 'WinRM-HTTPS' -DisplayName 'WinRM HTTPS' -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5986

   # Test locally
   Test-WSMan -ComputerName localhost
"@ -ForegroundColor Yellow

    Write-Output "`n4. TEST CONNECTIVITY FROM HOST"
    Write-Output "   After configuring all VMs, test from your development machine:`n"
    Write-Output "   # Add VMs to TrustedHosts"
    Write-Output "   Set-Item WSMan:\localhost\Client\TrustedHosts -Value '$($NetworkConfig.SubnetPrefix).*' -Force`n"
    Write-Output "   # Test connectivity"
    foreach ($vmName in $CreatedVMs.Keys) {
        $config = $CreatedVMs[$vmName]
        if ($vmName -like "Win*") {
            Write-Output "   Test-WSMan -ComputerName $($config.IPAddress)"
        }
    }

    Write-Output "`n5. RUN PHASE 1 VALIDATION"
    Write-Output "   See WINDOWS-TEST-ENVIRONMENT-SETUP.md for Phase 1 audit validation steps`n"

    Write-Output "═══ USEFUL COMMANDS ═══`n"
    Write-Output "  # Start all test VMs"
    Write-Output "  Get-VM | Where-Object Name -like '*-Test' | Start-VM`n"
    Write-Output "  # Stop all test VMs"
    Write-Output "  Get-VM | Where-Object Name -like '*-Test' | Stop-VM`n"
    Write-Output "  # Create checkpoint (snapshot) before testing"
    Write-Output "  Get-VM | Where-Object Name -like '*-Test' | Checkpoint-VM -SnapshotName 'Clean-State'`n"
    Write-Output "  # Restore checkpoint"
    Write-Output "  Get-VM | Where-Object Name -like '*-Test' | Restore-VMSnapshot -Name 'Clean-State' -Confirm:`$false`n"

    Write-Output "✓ Setup complete! Ready to install operating systems on VMs`n"
}

# ============================================================
# MAIN EXECUTION
# ============================================================

$startTime = Get-Date

Write-Output "`n╔════════════════════════════════════════════════════════════════════╗"
Write-Output "║        OS-Independent Security Audit Toolkit                     ║"
Write-Output "║        Test Environment Setup (Hyper-V)                          ║"
Write-Output "╚════════════════════════════════════════════════════════════════════╝`n"

Write-Output "Configuration: $VMConfiguration"
Write-Output "VM Path: $VMPath"
Write-Output "ISO Path: $ISOPath"
Write-Output "Network: $NetworkSubnet`n"

# Step 1: Prerequisites
if (-not (Test-Prerequisites)) {
    Write-ErrorMessage "`nPrerequisite checks failed. Please resolve issues and try again."
    exit 1
}

# Step 2: Install Hyper-V (if needed)
Install-HyperVFeature

# Step 3: Create Virtual Switch
New-TestVirtualSwitch

# Step 4: Create VMs
Write-Step "Creating Virtual Machines" "Cyan"

$createdVMs = @{}
foreach ($vmName in $VMConfigs.Keys) {
    $config = $VMConfigs[$vmName]

    if ($config.Required) {
        try {
            New-TestVM -VMName $vmName -Config $config
            $createdVMs[$vmName] = $config
        } catch {
            Write-ErrorMessage "Failed to create VM '$vmName': $_"
            Write-WarnStatus "Continuing with remaining VMs..."
        }
    } else {
        Write-Verbose "Skipping optional VM: $vmName (not included in $VMConfiguration configuration)"
    }
}

$endTime = Get-Date
$duration = $endTime - $startTime

Write-Output "`nSetup completed in $([math]::Round($duration.TotalMinutes, 2)) minutes"

# Step 5: Show Summary
Show-Summary -CreatedVMs $createdVMs


