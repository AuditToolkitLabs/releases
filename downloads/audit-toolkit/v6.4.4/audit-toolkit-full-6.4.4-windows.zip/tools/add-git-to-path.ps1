# PowerShell script to add Git to system PATH if not already present
$gitPath = "C:\Program Files\Git\cmd"

# Get current PATH
$envPath = [System.Environment]::GetEnvironmentVariable("Path", [System.EnvironmentVariableTarget]::Machine)

if ($envPath -notlike "*$gitPath*") {
    Write-Output "Adding Git to system PATH..."
    $newPath = $envPath + ";" + $gitPath
    [System.Environment]::SetEnvironmentVariable("Path", $newPath, [System.EnvironmentVariableTarget]::Machine)
    Write-Output "Git path added. Please restart your terminal or computer for changes to take effect."
} else {
    Write-Output "Git is already in the system PATH."
}

# Test if git is now available
Write-Output "Testing git command..."
$gitVersion = & git --version 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Output "Git is available: $gitVersion"
} else {
    Write-Output "Git is still not available in this terminal. Please restart your terminal or log out and back in."
}
