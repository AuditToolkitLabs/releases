#!/usr/bin/env python3
"""Analyze Bandit security scan results."""

import json
import sys
from collections import defaultdict
from pathlib import Path


def analyze_bandit_results(json_path: str) -> dict:
    """Parse and summarize Bandit scan results."""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    metrics = data.get('metrics', {}).get('_totals', {})
    results = data.get('results', [])

    # Group by severity and test_id
    by_severity = defaultdict(list)
    by_test = defaultdict(list)

    for issue in results:
        severity = issue.get('issue_severity', 'UNKNOWN')
        test_id = issue.get('test_id', 'UNKNOWN')
        by_severity[severity].append(issue)
        by_test[test_id].append(issue)

    summary = {
        'files_scanned': metrics.get('loc', 0),
        'high_severity': len(by_severity.get('HIGH', [])),
        'medium_severity': len(by_severity.get('MEDIUM', [])),
        'low_severity': len(by_severity.get('LOW', [])),
        'total_issues': len(results),
        'issues_by_test': {k: len(v) for k, v in sorted(by_test.items())},
        'high_issues': by_severity.get('HIGH', []),
        'medium_issues': by_severity.get('MEDIUM', []),
    }

    return summary


def print_report(summary: dict):
    """Print formatted security report."""
    print("=" * 60)
    print("BANDIT SECURITY SCAN RESULTS")
    print("=" * 60)
    print(f"Lines of code scanned: {summary['files_scanned']:,}")
    print()
    print("SEVERITY BREAKDOWN:")
    print(f"  HIGH:   {summary['high_severity']}")
    print(f"  MEDIUM: {summary['medium_severity']}")
    print(f"  LOW:    {summary['low_severity']}")
    print(f"  TOTAL:  {summary['total_issues']}")
    print()

    if summary['issues_by_test']:
        print("ISSUES BY TYPE:")
        for test_id, count in sorted(summary['issues_by_test'].items(),
                                     key=lambda x: -x[1]):
            print(f"  {test_id}: {count}")
        print()

    if summary['high_issues']:
        print("HIGH SEVERITY ISSUES (require immediate attention):")
        print("-" * 60)
        for issue in summary['high_issues'][:10]:  # Show first 10
            print(f"  File: {issue['filename']}:{issue['line_number']}")
            print(f"  Issue: {issue['issue_text']}")
            print(f"  Test: {issue['test_id']} - {issue['test_name']}")
            print()

    if summary['medium_issues']:
        print("MEDIUM SEVERITY ISSUES (should be reviewed):")
        print("-" * 60)
        for issue in summary['medium_issues'][:10]:  # Show first 10
            print(f"  File: {issue['filename']}:{issue['line_number']}")
            print(f"  Issue: {issue['issue_text']}")
            print(f"  Test: {issue['test_id']} - {issue['test_name']}")
            print()


if __name__ == '__main__':
    json_file = sys.argv[1] if len(sys.argv) > 1 else 'security_scan_web.json'
    if Path(json_file).exists():
        summary = analyze_bandit_results(json_file)
        print_report(summary)
    else:
        print(f"Error: {json_file} not found")
        sys.exit(1)
