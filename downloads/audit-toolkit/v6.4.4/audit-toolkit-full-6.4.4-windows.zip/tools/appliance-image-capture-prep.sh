#!/bin/bash
###############################################################################
# Security Audit Toolkit — Appliance Image Capture Prep
#
# Run this script ONCE on the base VM immediately before exporting to
# VMDK / OVA.  It removes all lab-specific artefacts and resets the
# appliance to the intended first-boot / first-login state so that every
# deployed image starts cleanly.
#
# What this script does:
#   1.  Reset built-in admin DB row to first-login state (ChangeMe123!,
#       must_change_password=true, disclaimer cleared)
#   2.  Restore env defaults (INITIAL_ADMIN_PASSWORD, ADMIN_PASSWORD,
#       RANDOMIZE=0)
#   3.  Remove netplan static-IP config and reset to DHCP
#   4.  Clear all setup / first-boot markers
#   5.  Remove credential artefact files
#   6.  Remove SSH host keys (regenerated on first boot)
#   7.  Truncate / reset machine-id (regenerated on first boot)
#   8.  Flush application logs, system logs, shell history, temp files
#   9.  Clean apt cache
#  10.  Stop services cleanly (ready for export)
#
# Usage:
#   sudo bash appliance-image-capture-prep.sh
#
# After this script completes, export the VM immediately.  Do NOT reboot
# before export — the machine-id is intentionally empty so systemd will
# regenerate it on the FIRST boot of the deployed image.
###############################################################################
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

ok()   { echo -e "${GREEN}[OK]${NC}  $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
info() { echo -e "${CYAN}[--]${NC}  $1"; }

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[ERROR]${NC} Must be run as root.  Use: sudo bash $0"
    exit 1
fi

echo ""
echo "======================================================================"
echo " Security Audit Toolkit — Appliance Image Capture Prep"
echo "======================================================================"
echo ""

INSTALL_DIR="/opt/audit-toolkit"
WEB_ENV="$INSTALL_DIR/web/.env"
MARKER_DIR="/var/lib/audit-toolkit"
DB_NAME="audit_toolkit"

###############################################################################
# 0. Ensure .venv symlink exists (service units reference .venv; real dir is venv)
###############################################################################
if [[ -d "$INSTALL_DIR/venv" && ! -e "$INSTALL_DIR/.venv" ]]; then
    ln -sfn "$INSTALL_DIR/venv" "$INSTALL_DIR/.venv"
    ok ".venv -> venv symlink created"
elif [[ -L "$INSTALL_DIR/.venv" ]]; then
    ok ".venv symlink already present"
fi

###############################################################################
# 1. Reset built-in admin to first-login state
###############################################################################
info "[1/10] Resetting built-in admin to first-login state..."

if [[ -x "$INSTALL_DIR/venv/bin/python" ]]; then
    set +H
    HASH=$("$INSTALL_DIR/venv/bin/python" -c \
        "from werkzeug.security import generate_password_hash; print(generate_password_hash('ChangeMe123'+chr(33)))")
    if sudo -u postgres psql -d "$DB_NAME" -v ON_ERROR_STOP=1 -c \
        "UPDATE users SET password_hash='${HASH}', must_change_password=true,
         disclaimer_accepted_at=NULL, disclaimer_version=NULL,
         is_active=true, auth_provider='local',
         failed_login_attempts=0, lockout_until=NULL
         WHERE username='admin' AND is_builtin_admin=true;" 2>/dev/null; then
        ok "Admin DB row reset"
    else
        warn "DB update skipped (non-fatal)"
    fi
    set -H
else
    warn "Python venv not found at $INSTALL_DIR/venv — DB reset skipped"
fi

###############################################################################
# 2. Restore env defaults
###############################################################################
info "[2/10] Restoring env default password vars..."

if [[ -f "$WEB_ENV" ]]; then
    sed -i 's/^INITIAL_ADMIN_PASSWORD=.*/INITIAL_ADMIN_PASSWORD=ChangeMe123!/' "$WEB_ENV"
    sed -i 's/^ADMIN_PASSWORD=.*/ADMIN_PASSWORD=ChangeMe123!/' "$WEB_ENV"
    sed -i 's/^AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=.*/AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=0/' "$WEB_ENV"
    # Ensure keys exist if they were absent
    grep -q '^INITIAL_ADMIN_PASSWORD=' "$WEB_ENV" || echo 'INITIAL_ADMIN_PASSWORD=ChangeMe123!' >> "$WEB_ENV"
    grep -q '^ADMIN_PASSWORD=' "$WEB_ENV" || echo 'ADMIN_PASSWORD=ChangeMe123!' >> "$WEB_ENV"
    grep -q '^AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=' "$WEB_ENV" || echo 'AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=0' >> "$WEB_ENV"
    ok "Env defaults restored"
else
    warn "Web .env not found at $WEB_ENV — skipping"
fi

###############################################################################
# 3. Reset netplan to DHCP (remove any lab static IP config)
###############################################################################
info "[3/10] Resetting network to DHCP..."

# Detect primary interface
IFACE=$(ip -o link show | awk -F': ' '$2 !~ /lo|docker|veth|virbr/ {print $2; exit}')
IFACE="${IFACE:-eth0}"

# Remove any existing toolkit netplan overrides
rm -f /etc/netplan/90-audit-toolkit.yaml
rm -f /etc/netplan/99-audit-toolkit.yaml

# Write a clean DHCP baseline
cat > /etc/netplan/90-audit-toolkit.yaml <<NETEOF
# Security Audit Toolkit - First-boot network baseline (DHCP)
# This file is regenerated on first deployment by appliance-image-capture-prep.sh
network:
  version: 2
  ethernets:
    ${IFACE}:
      dhcp4: true
      dhcp6: false
NETEOF
chmod 600 /etc/netplan/90-audit-toolkit.yaml

# Remove any stale gateway4 lines that break modern netplan
sed -i '/gateway4:/d' /etc/netplan/*.yaml 2>/dev/null || true

ok "Netplan reset to DHCP on $IFACE"

###############################################################################
# 4. Remove setup / first-boot markers
###############################################################################
info "[4/10] Removing setup markers..."

rm -f \
    "$MARKER_DIR/.setup-complete" \
    "$MARKER_DIR/.first-boot-complete" \
    "$MARKER_DIR/.first-login-wizard-complete" \
    "$INSTALL_DIR/scripts/.first-boot-complete" 2>/dev/null || true

ok "Setup markers removed"

###############################################################################
# 5. Remove credential artefact files
###############################################################################
info "[5/10] Removing credential artefact files..."

rm -f \
    "$MARKER_DIR/initial-admin-credentials.txt" \
    "$INSTALL_DIR/initial-credentials.txt" \
    "$INSTALL_DIR/web/initial-credentials.txt" \
    /home/auditadmin/initial-credentials.txt 2>/dev/null || true

ok "Credential artefacts removed"

###############################################################################
# 6. Remove SSH host keys
###############################################################################
info "[6/10] Removing SSH host keys (will regenerate on first boot)..."

# Ensure sshd regenerates missing keys on startup in customer deployments.
install -d -m 755 /etc/systemd/system/ssh.service.d
cat > /etc/systemd/system/ssh.service.d/10-audit-toolkit-hostkeys.conf << 'EOF'
[Service]
ExecStartPre=/usr/bin/ssh-keygen -A
EOF
systemctl daemon-reload

rm -f /etc/ssh/ssh_host_*
ok "SSH host keys removed"

###############################################################################
# 7. Reset machine-id
###############################################################################
info "[7/10] Resetting machine-id..."

# Truncate to empty — systemd will regenerate on first boot
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id
# Create a symlink so dbus reads from the same source on regeneration
ln -sf /etc/machine-id /var/lib/dbus/machine-id 2>/dev/null || true
ok "machine-id cleared"

###############################################################################
# 8. Flush logs, history, temp files
###############################################################################
info "[8/10] Flushing logs, history, temp..."

# Application logs
find "$INSTALL_DIR" -name "*.log" -type f -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log/audit-toolkit -type f -exec truncate -s 0 {} \; 2>/dev/null || true

# System logs
find /var/log -type f -name "*.log" -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log -type f -name "syslog" -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log -type f -name "auth.log" -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log -type f -name "*.gz" -delete 2>/dev/null || true
journalctl --rotate 2>/dev/null || true
journalctl --vacuum-time=1s 2>/dev/null || true

# Shell histories
rm -f /root/.bash_history /root/.ash_history
rm -f /home/auditadmin/.bash_history /home/auditadmin/.ash_history
history -c 2>/dev/null || true

# Temp dirs
find /tmp -mindepth 1 -delete 2>/dev/null || true
find /var/tmp -mindepth 1 -delete 2>/dev/null || true

ok "Logs, history, temp cleared"

###############################################################################
# 9. Clean apt / package caches
###############################################################################
info "[9/10] Cleaning package cache..."

apt-get clean -y 2>/dev/null || true
apt-mark manual openssh-server 2>/dev/null || true
apt-get autoremove -y --purge 2>/dev/null || true
ok "Package cache cleaned"

###############################################################################
# 10. Remove build artefacts not needed in the appliance image
###############################################################################
info "[10/12] Removing build artefacts from install directory..."
rm -rf "${INSTALL_DIR}/vm-appliance/output" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/linux/artifacts" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/linux/build" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/windows/bin" 2>/dev/null || true
ok "Build artefacts removed"

###############################################################################
# 11. Grow LVM logical volume to consume all available VG free space
###############################################################################
info "[11/12] Growing LVM logical volume to fill available VG space..."
VG_NAME=$(lvs --noheadings -o vg_name /dev/ubuntu-vg/ubuntu-lv 2>/dev/null | tr -d ' ')
LV_DEV="/dev/mapper/ubuntu--vg-ubuntu--lv"
if [[ -n "$VG_NAME" ]]; then
    FREE_PE=$(vgdisplay "$VG_NAME" 2>/dev/null | awk '/Free  PE/{print $5}')
    if [[ "${FREE_PE:-0}" -gt 0 ]]; then
        if lvextend -l +100%FREE "/dev/${VG_NAME}/ubuntu-lv" 2>/dev/null; then
            ok "LV extended by ${FREE_PE} free PEs"
        else
            warn "lvextend returned non-zero (may already be at max)"
        fi
        if resize2fs "$LV_DEV" 2>/dev/null; then
            ok "Filesystem grown to fill LV"
        else
            warn "resize2fs returned non-zero"
        fi
    else
        ok "LV already uses all available VG space (${FREE_PE} free PEs)"
    fi
else
    warn "Could not detect LVM VG — disk grow skipped (non-LVM setup?)"
fi
df -h / | tail -1 | awk '{printf "  Disk: %s total, %s used, %s avail (%s)\n",$2,$3,$4,$5}'

###############################################################################
# 12. Stop services cleanly
###############################################################################
info "[12/12] Stopping services for clean export..."

if systemctl stop audit-toolkit-web 2>/dev/null; then ok "audit-toolkit-web stopped"; else warn "audit-toolkit-web not running"; fi
if systemctl stop audit-toolkit-discovery 2>/dev/null; then ok "audit-toolkit-discovery stopped"; else warn "audit-toolkit-discovery not running"; fi
if systemctl stop nginx 2>/dev/null; then ok "nginx stopped"; else warn "nginx not running"; fi

###############################################################################
# SUMMARY
###############################################################################
echo ""
echo "======================================================================"
echo " Image Capture Prep — COMPLETE"
echo "======================================================================"
echo ""
echo " State reset:"
echo "  ✓ Admin DB row: ChangeMe123! / must_change_password=true / disclaimer cleared"
echo "  ✓ Env defaults: INITIAL_ADMIN_PASSWORD=ChangeMe123! / RANDOMIZE=0"
echo "  ✓ Netplan: DHCP on $IFACE (no lab static IP)"
echo "  ✓ Setup markers removed (.setup-complete, .first-boot-complete, etc.)"
echo "  ✓ Credential artefact files removed"
echo "  ✓ SSH host keys removed (regenerated on first boot)"
echo "  ✓ machine-id cleared (regenerated on first boot)"
echo "  ✓ Logs / history / temp flushed"
echo "  ✓ Package cache cleaned"
echo "  ✓ Build artefacts removed (vm-appliance/output, deployment bins)"
echo "  ✓ LVM logical volume grown to fill available VG space"
echo "  ✓ Services stopped cleanly"
echo ""
echo " NEXT STEP:"
echo "  Export the VM to VMDK / OVA immediately."
echo "  Do NOT reboot before export."
echo ""
