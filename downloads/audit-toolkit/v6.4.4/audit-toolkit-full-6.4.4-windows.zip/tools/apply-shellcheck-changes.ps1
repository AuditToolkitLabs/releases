﻿<#
.SYNOPSIS
Apply the ShellCheck integration changes to this repo without Git.

.DESCRIPTION
This script writes the new/updated files into place, backing up any existing files with a timestamped `.bak` suffix.

USAGE
powershell -NoProfile -File tools\apply-shellcheck-changes.ps1

Use -WhatIf to do a dry-run.
#>

param(
    [switch]$WhatIf
)

$null = $WhatIf

function Backup-Path {
    param($path)
    if (Test-Path $path) {
        $ts = (Get-Date).ToString('yyyyMMddHHmmss')
        $bak = "${path}.bak.$ts"
        Write-Output "Backing up $path -> $bak"
        if (-not $WhatIf) { Copy-Item -LiteralPath $path -Destination $bak -Recurse -Force }
    }
}

function Write-File {
    param($path, $content)
    $dir = Split-Path -Parent $path
    if (-not (Test-Path $dir)) {
        Write-Output "Creating directory: $dir"
        if (-not $WhatIf) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }
    if (Test-Path $path) { Backup-Path $path }
    Write-Output "Writing $path"
    if (-not $WhatIf) { Set-Content -LiteralPath $path -Value $content -Encoding UTF8 }
}

# Files to write
$files = @{
    ".vscode/tasks.json" = @'
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "ShellCheck (repo)",
      "type": "shell",
      "command": "make",
      "args": ["lint"],
      "group": {
        "kind": "test",
        "isDefault": true
      },
      "presentation": {
        "reveal": "silent"
      },
      "problemMatcher": []
    },
    {
      "label": "ShellCheck (repo) (bash)",
      "type": "shell",
      "command": "bash",
      "args": ["-lc", "shellcheck -s bash -x $(git ls-files '*.sh')"],
      "group": "test",
      "presentation": { "reveal": "silent" },
      "problemMatcher": []
    },
    {
      "label": "ShellCheck (repo) (pwsh)",
      "type": "shell",
      "command": "pwsh",
      "args": ["-NoProfile", "-Command", "shellcheck -s bash -x (git ls-files '*.sh')"],
      "group": "test",
      "presentation": { "reveal": "silent" },
      "problemMatcher": []
    },
    {
      "label": "ShellCheck (repo) (pwsh-wrapper)",
      "type": "shell",
      "command": "pwsh",
      "args": ["-NoProfile", "-File", "${workspaceFolder}\\tools\\run-shellcheck-windows.ps1"],
      "group": "test",
      "presentation": { "reveal": "silent" },
      "problemMatcher": []
    }
  ]
}
'@

    ".vscode/extensions.json" = @'
{
  "recommendations": [
    "timonwong.shellcheck"
  ]
}
'@

    "tools/run-shellcheck-windows.ps1" = @'
<#
.SYNOPSIS
Runs ShellCheck across the repository on Windows.

.DESCRIPTION
Uses `git ls-files` if available; otherwise falls back to a recursive file search. Excludes the `.git` directory. Pass any additional arguments to `shellcheck`.

.EXAMPLE
# Basic usage (runs with -s bash -x):
.    .\tools\run-shellcheck-windows.ps1

# Forward extra args to shellcheck:
.    .\tools\run-shellcheck-windows.ps1 -- --severity=error
#>

param(
    [Parameter(ValueFromRemainingArguments=$true)]
    [string[]]$AdditionalArgs
)

$ErrorActionPreference = 'Stop'

function Write-ErrorAndExit {
    param($msg, $code=1)
    Write-Output $msg
    exit $code
}

$sc = Get-Command shellcheck -ErrorAction SilentlyContinue
if (-not $sc) {
    Write-ErrorAndExit "shellcheck not found on PATH. Install it (https://www.shellcheck.net) or set `shellcheck.executablePath` in VS Code settings." 2
}

# Collect shell scripts using git when possible
$filePaths = @()
$git = Get-Command git -ErrorAction SilentlyContinue
if ($git) {
    try {
        $files = & git ls-files '*.sh' 2>$null
        $filePaths = $files | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path $_) } | ForEach-Object { (Resolve-Path -LiteralPath $_).Path }
    } catch {
        $filePaths = @()
    }
}

# Fallback: enumerate files recursively and exclude .git
if (-not $filePaths -or $filePaths.Count -eq 0) {
    $filePaths = Get-ChildItem -Path . -Recurse -File -Include *.sh | Where-Object { $_.FullName -notmatch "\\.git\\" } | ForEach-Object { $_.FullName }
}

if (-not $filePaths -or $filePaths.Count -eq 0) {
    Write-Output "No shell scripts found to lint."
    exit 0
}

Write-Output "Running ShellCheck on $($filePaths.Count) file(s)..."
$cmd = @('-s','bash','-x') + $AdditionalArgs + $filePaths
& $sc.Path @cmd
exit $LASTEXITCODE
'@

    ".github/workflows/shellcheck.yml" = @'
name: ShellCheck

on:
  push:
    paths:
      - '**/*.sh'
  pull_request:
    paths:
      - '**/*.sh'

jobs:
  shellcheck:
    name: Run ShellCheck
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Run shellcheck action
        uses: koalaman/shellcheck-action@v1
        with:
          shellcheck_version: '0.11.0'
          args: '-s bash -x'
'@

    "docs/03-developer-guide.md" = @'
````markdown


# Developer Guide

## Requirements
- Bash, coreutils, grep, sed
- Optional: shellcheck, shfmt (for lint/format)

## ShellCheck in VS Code
We recommend installing the ShellCheck extension (`timonwong.shellcheck`) for live, in-editor diagnostics and quick fixes. Use the workspace task `ShellCheck (repo)` to run `make lint` (the Makefile uses `git ls-files` so it reliably collects all `.sh` files across platforms).

- Run the task from VS Code: open the Command Palette → Run Task → `ShellCheck (repo)`.
- If the extension cannot find `shellcheck`, set `shellcheck.executablePath` in your workspace settings to the absolute path of the `shellcheck` binary (e.g., `C:\Program Files\ShellCheck\shellcheck.exe`).

> Tip: On Windows, prefer the `make lint` task to avoid PowerShell globbing issues with `**/*.sh`. If you don't have `make` available, ensure `git` is on your PATH so the `ShellCheck (repo) (pwsh)` task can use `git ls-files`, or run the `bash` variant under WSL/Git Bash.

### Windows wrapper (recommended when `make` is not installed)
A PowerShell wrapper is included at `tools/run-shellcheck-windows.ps1`. It will use `git ls-files` when available, or fall back to a recursive search for `*.sh` files while excluding `.git`.

- Run from PowerShell: `pwsh -NoProfile -File .\tools\run-shellcheck-windows.ps1`
- To pass extra arguments to ShellCheck (for example `--severity=error`), add them after `--`:

```powershell
pwsh -NoProfile -File .\tools\run-shellcheck-windows.ps1 -- --severity=error
```

This task is available in the workspace tasks as `ShellCheck (repo) (pwsh-wrapper)`.

## Continuous Integration
A GitHub Actions workflow is included at `.github/workflows/shellcheck.yml` that runs ShellCheck on all `*.sh` files for every push and pull request. This ensures repository-wide linting regardless of developer OS or editor configuration.

---

> Next steps to publish these changes: ensure `git` is available locally, create a branch (for example `ci/shellcheck`), commit the new files, push the branch, and open a pull request against `main` (or your default branch). If you want, I can prepare a patch file you can apply or provide the exact git commands to run locally.

## Run Locally
```bash
bash audits/platform/baseline/updates.sh
bash orchestrator/orchestrator.sh
```

## Coding Standards
- `set -euo pipefail`
- Use `register_check`, `section`, `print_summary`
- Use shims: `pkg_*`, `svc_*`, `fw_*`, `path_*`, `selinux_status`, `apparmor_status`
- Never modify system state in audits

````
'@
}

# Apply all files
foreach ($path in $files.Keys) {
    $content = $files[$path]
    Write-Output "Preparing to write: $path"
    Write-File $path $content
}

Write-Output "\nDone. Files written. Review the changes and run the PowerShell wrapper to test: pwsh -NoProfile -File tools/run-shellcheck-windows.ps1"

