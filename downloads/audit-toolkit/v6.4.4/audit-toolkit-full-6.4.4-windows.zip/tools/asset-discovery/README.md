# Asset Discovery & Vulnerability Management Tool

A lightweight, cross-platform asset discovery and vulnerability management solution integrated with the Security Audit Toolkit.

## Features

- **Asset Discovery**: Automated hardware, OS, software, and service enumeration
- **CVE Tracking**: Automatic sync with NIST NVD API
- **CISA KEV Integration**: Tracks Known Exploited Vulnerabilities
- **Vulnerability Matching**: Correlates installed software with CVEs via CPE
- **Cross-Platform**: Windows (WinRM) and Linux (SSH) support
- **Flexible Database**: SQLite (standalone) or PostgreSQL (enterprise)
- **Enhanced Scan Wizard** (v5.1+): 3-step scan creation with connection testing
- **Navigation Shortcuts** (v5.1+): Quick links to Home, Console, Reports, and Script Studio

## Quick Start

> **Note**: Docker is NOT required. The tool runs natively with Python 3.8+.

### Native Installation (Recommended)

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python -m src.app

# Or with custom config
python -m src.app --config config.yaml
```

### Windows Native

```powershell
# Install dependencies
pip install -r requirements.txt

# Run the application
python -m src.app
```

### Optional: Docker (Development Convenience)

```bash
# SQLite (standalone)
docker-compose up discovery-api

# PostgreSQL (enterprise)
docker-compose --profile enterprise up
```

### API Access

- **API Base URL**: http://localhost:8080/api/v1
- **Health Check**: http://localhost:8080/health
- **Interactive Docs**: Coming soon

## Discovery Scripts

### Windows Discovery

```powershell
# Run locally on target
.\scripts\windows-discovery.ps1 -OutputPath "C:\Temp\asset.json"

# Upload to API
Invoke-RestMethod -Uri "http://discovery-server:8080/api/v1/assets" `
  -Method POST `
  -ContentType "application/json" `
  -Body (Get-Content "C:\Temp\asset.json" -Raw)
```

### Linux Discovery

```bash
# Run locally on target
./scripts/linux-discovery.sh -o /tmp/asset.json

# Upload to API
curl -X POST http://discovery-server:8080/api/v1/assets \
  -H "Content-Type: application/json" \
  -d @/tmp/asset.json
```

## API Endpoints

### Assets
- `GET /api/v1/assets` - List all assets
- `GET /api/v1/assets/{id}` - Get asset details
- `POST /api/v1/assets` - Create/update asset from discovery data
- `DELETE /api/v1/assets/{id}` - Delete asset
- `GET /api/v1/assets/{id}/software` - Get installed software
- `GET /api/v1/assets/{id}/services` - Get running services

### Scans
- `GET /api/v1/scans` - List scan jobs
- `POST /api/v1/scans` - Create scan job (enhanced options in v5.1+)
- `POST /api/v1/scans/{id}/start` - Start scan
- `POST /api/v1/scans/{id}/cancel` - Cancel scan
- `GET /api/v1/scans/{id}/results` - Get scan results
- `POST /api/v1/scans/test-connection` - Test connection to target (v5.1+)

### Configuration (v5.1+)
- `GET /api/v1/config` - Get frontend configuration and navigation URLs

### Vulnerabilities
- `GET /api/v1/vulnerabilities/cves` - List CVEs
- `GET /api/v1/vulnerabilities/cves/{cve_id}` - Get CVE details
- `GET /api/v1/vulnerabilities/assets/{id}` - Get asset vulnerabilities
- `GET /api/v1/vulnerabilities/kev` - List CISA KEV entries
- `POST /api/v1/vulnerabilities/scan/{id}` - Scan asset for vulnerabilities

### Dashboard
- `GET /api/v1/dashboard/summary` - Overall statistics
- `GET /api/v1/dashboard/risk-overview` - Risk breakdown
- `GET /api/v1/dashboard/recent-activity` - Recent scans/discoveries
- `GET /api/v1/dashboard/top-vulnerabilities` - Most common CVEs
- `GET /api/v1/dashboard/compliance-status` - Compliance metrics

## Configuration

Copy `config.example.yaml` to `config.yaml` and customize:

```yaml
database:
  type: sqlite  # or postgresql
  path: ./data/asset_discovery.db

nvd:
  api_key: ''  # Get at https://nvd.nist.gov/developers/request-an-api-key
  sync_interval_hours: 24

api:
  host: 0.0.0.0
  port: 8080
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | Database connection string | `sqlite:///data/asset_discovery.db` |
| `NVD_API_KEY` | NVD API key for faster sync | - |
| `SECRET_KEY` | Flask secret key | Random |
| `LOG_LEVEL` | Logging level | INFO |
| `POSTGRES_PASSWORD` | PostgreSQL password | `discovery_secure_pass` |
| `AGENT_SYNC_API_KEY` | Dedicated agent ingest API key | - |
| `ASSET_DISCOVERY_API_KEY` | Shared API key fallback | - |
| `ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY` | Insecure dev bypass | `false` |
| `ASSET_DISCOVERY_WINRM_INSECURE_TLS` | Allow insecure WinRM TLS | `false` |
| `ASSET_DISCOVERY_NMAP_ENABLED` | Enable nmap-backed deep scanner engine | `false` |
| `ASSET_DISCOVERY_RISK_CRITICAL_SCORE` | Critical risk score threshold | `35` |
| `ASSET_DISCOVERY_RISK_HIGH_SCORE` | High risk score threshold | `20` |
| `ASSET_DISCOVERY_RISK_MEDIUM_SCORE` | Medium risk score threshold | `8` |
| `ASSET_DISCOVERY_RISK_WEIGHT_CRITICAL` | Weight per critical vulnerability | `20` |
| `ASSET_DISCOVERY_RISK_WEIGHT_KEV` | Weight per KEV vulnerability | `25` |
| `ASSET_DISCOVERY_ROUTE_VULNERABILITY_MANAGEMENT_IMMEDIATE_MIN_RATING` | Route immediate cutoff | `high` |
| `ASSET_DISCOVERY_ROUTE_NETWORK_EXPOSURE_REVIEW_IMMEDIATE_MIN_RATING` | Network exposure immediate cutoff | `critical` |
| `ASSET_DISCOVERY_ROUTE_BASELINE_COMPLIANCE_IMMEDIATE_MIN_RATING` | Baseline compliance immediate cutoff | `critical` |

Use `ASSET_DISCOVERY_WINRM_INSECURE_TLS=true` only for temporary lab testing.

Set `ASSET_DISCOVERY_NMAP_ENABLED=true` only when `nmap` is installed on the runtime host (or CI runner).

For all risk-policy knobs, see the complete, commented set in `.env.example`.

## Supported Distributions

### Linux

- Debian/Ubuntu/Mint (apt)
- RHEL/CentOS/Rocky/Fedora (dnf/yum)
- openSUSE/SLES (zypper)
- Arch/Manjaro (pacman)
- Alpine (apk)
- Gentoo (portage)
- Void Linux (xbps)
- NixOS (nix)
- Clear Linux (swupd)
- Solus (eopkg)
- Slackware (slackpkg)

### Windows

- Windows Server 2016+
- Windows 10/11

## Architecture

```text
┌─────────────────┐     ┌──────────────────┐
│  Discovery API  │────▶│  SQLite/PostgreSQL│
└────────┬────────┘     └──────────────────┘
         │
         ▼
┌─────────────────┐     ┌──────────────────┐
│   CVE Sync      │────▶│   NVD API        │
│   Worker        │     │   CISA KEV       │
└─────────────────┘     └──────────────────┘
         │
         ▼
┌─────────────────┐
│  Target Hosts   │
│  (WinRM/SSH)    │
└─────────────────┘
```

## Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run tests
pytest

# Lint
flake8 src/
black src/ --check
```

## License

See main project [LICENSE](../../LICENSE) file.
