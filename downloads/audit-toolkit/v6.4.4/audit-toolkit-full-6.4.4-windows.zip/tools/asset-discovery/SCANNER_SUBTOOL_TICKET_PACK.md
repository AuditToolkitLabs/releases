# Scanner Subtool Ticket Pack

Owner area: Asset Discovery module
Date: 2026-05-07
Status: Ready for implementation

## Goal
Implement Scanner as a first-class internal subtool (not standalone), with clear UI boundaries, versioned contracts, and QA-ready acceptance checks.

## Delivery Definition
- Scanner views are operational/evidence-focused.
- Asset views remain business/risk-focused.
- Reports support Business, Technical, and Combined modes.
- Correlation between findings and assets is deterministic and visible.

## Epic 1: Frontend Information Architecture

### FE-1: Add Scanner primary navigation entry
Type: Frontend
Priority: P0
Estimate: 2 points

Scope
- Add primary nav item `Scanner`.
- Add routes:
  - `/scanner/runs`
  - `/scanner/runs/:runId/findings`
  - `/scanner/runs/:runId/coverage`
  - `/scanner/runs/:runId/execution`

Acceptance Criteria
- Scanner appears in primary nav on desktop and mobile.
- Deep linking to each route renders expected page shell.
- Route guards and auth behavior match existing module rules.

Dependencies
- None

---

### FE-2: Build Scanner page shell and shared header
Type: Frontend
Priority: P0
Estimate: 3 points

Scope
- Create shared `ScannerHeader` component with:
  - Last run timestamp
  - Profile badge (`fast|standard|deep`)
  - Engine badge (`tcp-probe|nmap`)
  - Status badge (`queued|running|completed|failed|partial`)
  - Coverage percentage
- Add KPI row:
  - Hosts scanned
  - Open services
  - Critical findings
  - Coverage gaps

Acceptance Criteria
- Header renders from run summary payload.
- Badge values gracefully handle unknown enums.
- KPI cards show loading and empty states.

Dependencies
- API-1 run summary contract

---

### FE-3: Implement Runs page
Type: Frontend
Priority: P0
Estimate: 5 points

Scope
- Components:
  - `RunFilterBar` (date range, profile, status, tag, engine)
  - `RunTable`
  - action bar (`Re-run`, `Export technical report`, `Compare previous`)
- Columns:
  - runId
  - startedAt
  - durationSec
  - profile
  - engine
  - status
  - coveragePct
  - fallbackTriggered

Acceptance Criteria
- Filters persist in URL query params.
- Sorting by startedAt and duration works.
- Row click navigates to findings route for selected run.

Dependencies
- API-1 runs list contract

---

### FE-4: Implement Findings page + detail drawer
Type: Frontend
Priority: P0
Estimate: 8 points

Scope
- Build summary strip (critical/high/medium/low counts).
- Build `FindingsTable` with columns:
  - severity
  - title
  - assetName
  - ip
  - service
  - port
  - cve
  - confidence
  - firstSeen
  - lastSeen
  - correlationStatus
- Row click opens `FindingDetailDrawer` with sections:
  - Evidence Snapshot
  - Correlated Asset Impact
  - Recommended Action
  - Provenance

Acceptance Criteria
- Drawer opens without route change.
- Every row shows confidence and source engine.
- Asset link in drawer opens asset details page.

Dependencies
- API-2 findings contract
- API-4 correlation fields

---

### FE-5: Implement Coverage page
Type: Frontend
Priority: P1
Estimate: 5 points

Scope
- KPI summary: targetCount, reachedCount, failedCount, skippedCount, coveragePct.
- Coverage matrix columns:
  - target
  - dnsResolved
  - tcpReachable
  - authAttempted
  - serviceIdentified
  - result
  - reasonCode
- Gap reason visualization grouped by reasonCode.

Acceptance Criteria
- Coverage percentages match backend values.
- Reason code groupings are accurate and exportable.
- Empty coverage handles zero-target scans without errors.

Dependencies
- API-3 coverage contract

---

### FE-6: Implement Execution page
Type: Frontend
Priority: P1
Estimate: 5 points

Scope
- Components:
  - `ExecutionTimeline`
  - `EngineMetadataCard`
  - `StructuredLogPanel`
- Show fields:
  - engineName, engineVersion, profile, nmapEnabled
  - fallbackTriggered, runtimeSec, retries, workerNode
- Structured logs fields:
  - ts, stage, level, code, message

Acceptance Criteria
- Timeline reflects stage transitions in order.
- Fallback banner appears when fallbackTriggered=true.
- Logs support filtering by level and stage.

Dependencies
- API-5 execution details contract

---

### FE-7: Asset detail integration card
Type: Frontend
Priority: P0
Estimate: 3 points

Scope
- Add `LatestScanEvidenceCard` to asset detail screen.
- Fields:
  - lastRunId
  - lastScannedAt
  - topOpenServices
  - highestSeverityObserved
  - confidenceDistribution
- CTA to linked scanner findings page.

Acceptance Criteria
- Card appears only when scan evidence exists.
- CTA opens exact run findings for asset context.
- Business-risk cards remain unchanged in structure.

Dependencies
- API-6 asset evidence summary contract

---

### FE-8: Report builder UX
Type: Frontend
Priority: P0
Estimate: 5 points

Scope
- Add report builder controls:
  - Report type: `business|technical|combined`
  - Scope: run/date/tags/asset groups
  - Include sections toggles
  - Output format: HTML/PDF/JSON
- Render generation progress and result links.

Acceptance Criteria
- Default scope uses current page filters when launched from Scanner.
- Selecting `technical` includes scanner sections only.
- Selecting `combined` includes both with cross-reference IDs.

Dependencies
- API-7 report generation contract

## Epic 2: API Contracts and View Models

### API-1: Runs list and run summary contract
Type: Backend API
Priority: P0
Estimate: 3 points

Contract
```json
{
  "runId": "run_1052",
  "startedAt": "2026-05-07T12:14:11Z",
  "durationSec": 438,
  "profile": "deep",
  "engine": "nmap",
  "status": "completed",
  "targetsTotal": 250,
  "targetsReached": 230,
  "coveragePct": 92.0,
  "fallbackTriggered": false
}
```

Acceptance Criteria
- Enum values documented for profile/engine/status.
- Pagination and sort fields documented.

---

### API-2: Findings contract with provenance and confidence
Type: Backend API
Priority: P0
Estimate: 5 points

Contract
```json
{
  "findingId": "f_89211",
  "severity": "critical",
  "title": "Exposed RDP with weak NLA posture",
  "assetId": "asset_441",
  "assetName": "PAYROLL-APP-01",
  "ip": "10.42.8.11",
  "service": "ms-wbt-server",
  "port": 3389,
  "protocol": "tcp",
  "cve": ["CVE-2024-xxxx"],
  "confidence": "high",
  "source": {
    "engine": "nmap",
    "profile": "deep",
    "signature": "rdp-security-check"
  },
  "timestamps": {
    "firstSeen": "2026-05-07T12:16:31Z",
    "lastSeen": "2026-05-07T12:16:31Z"
  }
}
```

Acceptance Criteria
- `confidence` always present.
- `source.engine` and `source.profile` always present.
- CVE can be empty array but never null.

---

### API-3: Coverage contract
Type: Backend API
Priority: P1
Estimate: 3 points

Contract
```json
{
  "target": "10.42.8.11",
  "dnsResolved": true,
  "tcpReachable": true,
  "authAttempted": false,
  "serviceIdentified": true,
  "result": "reached",
  "reasonCode": null
}
```

Acceptance Criteria
- `reasonCode` uses controlled vocabulary.
- Coverage counters equal aggregate of row-level results.

---

### API-4: Correlation block contract
Type: Backend API
Priority: P0
Estimate: 3 points

Contract
```json
{
  "correlation": {
    "riskScoreDelta": 12,
    "priorityRoute": "vulnerability_management_immediate",
    "correlationStatus": "linked"
  }
}
```

Acceptance Criteria
- Correlation is present for all findings (status can be `unlinked`).
- Status enum documented and tested.

---

### API-5: Execution details contract
Type: Backend API
Priority: P1
Estimate: 5 points

Contract
```json
{
  "engine": {
    "name": "nmap",
    "version": "7.95",
    "profile": "deep",
    "nmapEnabled": true,
    "fallbackTriggered": false
  },
  "runtime": {
    "runtimeSec": 438,
    "retries": 1,
    "workerNode": "scanner-worker-02"
  },
  "timeline": [
    {"stage": "queued", "ts": "2026-05-07T12:14:11Z"},
    {"stage": "started", "ts": "2026-05-07T12:14:15Z"},
    {"stage": "deep_scan", "ts": "2026-05-07T12:14:30Z"},
    {"stage": "persisted", "ts": "2026-05-07T12:21:29Z"}
  ]
}
```

Acceptance Criteria
- Timeline stages are ordered and non-duplicative.
- Fallback reason included when fallbackTriggered=true.

---

### API-6: Asset evidence summary contract
Type: Backend API
Priority: P0
Estimate: 2 points

Acceptance Criteria
- Asset detail returns concise latest scan evidence summary.
- Schema stable and independent from raw run logs.

---

### API-7: Report generation contract
Type: Backend API
Priority: P0
Estimate: 3 points

Acceptance Criteria
- Supports `business|technical|combined`.
- Returns job status and artifact links.
- Combined report includes findingId and assetId cross-reference table.

## Epic 3: QA Test Checklist (Exact Assertions)

### QA-1: Navigation and routing
Priority: P0

Assertions
- `Scanner` appears in primary navigation.
- Opening `/scanner/runs` loads run list without console errors.
- Opening `/scanner/runs/{id}/findings` loads selected run context.

---

### QA-2: Boundary separation
Priority: P0

Assertions
- Asset page does not render raw execution logs.
- Scanner findings page renders source engine and confidence for every row.
- Risk score tile values in Asset page are unchanged by scanner log payload shape changes.

---

### QA-3: Findings workflow
Priority: P0

Assertions
- Click finding row opens drawer.
- Drawer contains sections: Evidence, Correlated Impact, Provenance.
- Asset deep-link opens correct asset detail.

---

### QA-4: Coverage accuracy
Priority: P1

Assertions
- Coverage KPI totals match row aggregates.
- Reason codes appear for failed/skipped entries.
- Exported coverage CSV row count equals table row count.

---

### QA-5: Execution diagnostics
Priority: P1

Assertions
- Fallback banner appears when `fallbackTriggered=true`.
- Timeline order is monotonic by timestamp.
- Log filtering by level updates visible rows correctly.

---

### QA-6: Reports
Priority: P0

Assertions
- Business report excludes raw scanner timeline/logs.
- Technical report includes engine profile, coverage, provenance.
- Combined report includes both sections plus cross-reference IDs.
- Generated artifacts are downloadable from report history.

---

### QA-7: Responsiveness and accessibility
Priority: P0

Assertions
- Scanner pages functional at 360px width.
- Keyboard navigation works for table rows and drawer close.
- Badge colors meet contrast requirements.
- Screen reader labels exist for KPI cards and report type selector.

## Non-Functional Requirements
- Performance: runs table first paint under 2s for 500 rows (with pagination).
- Stability: no unhandled errors on empty datasets.
- Security: no raw credential or secret fields in scanner logs exposed to UI.
- Auditability: report generation logs include actor, scope, and timestamp.

## Controlled Vocabularies

Profile
- `fast`
- `standard`
- `deep`

Engine
- `tcp-probe`
- `nmap`

Run Status
- `queued`
- `running`
- `completed`
- `partial`
- `failed`

Confidence
- `high`
- `medium`
- `low`

Coverage Result
- `reached`
- `failed`
- `skipped`

Reason Code
- `timeout`
- `dns_failure`
- `auth_denied`
- `network_blocked`
- `fallback_used`
- `unknown`

## Suggested Sprint Cut
Sprint 1
- FE-1, FE-2, FE-3
- API-1
- QA-1

Sprint 2
- FE-4, FE-7
- API-2, API-4, API-6
- QA-2, QA-3

Sprint 3
- FE-5, FE-6, FE-8
- API-3, API-5, API-7
- QA-4, QA-5, QA-6, QA-7

## Ready-to-Start Definition
A ticket is ready when:
- API schema and enums are attached.
- UX copy for empty/error states is attached.
- Acceptance criteria include measurable behavior.
- QA assertions are linked.

## Done Definition
A ticket is done when:
- Unit and integration tests pass.
- QA assertions pass in staging.
- Accessibility checks pass.
- Release notes include scanner subtool UX/API changes.
