#!/usr/bin/env python3
"""
Fix Asset Discovery CVE database schema.

This script adds missing columns to the cve_records table that were
added to the data model but not created in the database.
"""

import os
import sys
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from sqlalchemy import text
from models.base import get_engine, session_scope

def fix_cve_schema():
    """Add missing columns to cve_records table."""
    engine = get_engine()

    missing_columns = [
        ('attack_vector', "VARCHAR(50)"),
        ('attack_complexity', "VARCHAR(20)"),
        ('privileges_required', "VARCHAR(20)"),
        ('user_interaction', "VARCHAR(20)"),
        ('scope', "VARCHAR(20)"),
        ('cisa_kev', "BOOLEAN DEFAULT FALSE"),
        ('cisa_due_date', "DATE"),
    ]

    with engine.connect() as conn:
        # Check which columns are missing
        result = conn.execute(text("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name='cve_records'
        """))

        existing_columns = {row[0] for row in result}
        print(f"✓ Existing columns: {len(existing_columns)}")
        for col in sorted(existing_columns):
            print(f"  - {col}")

        # Add missing columns
        for col_name, col_type in missing_columns:
            if col_name not in existing_columns:
                sql = f"ALTER TABLE cve_records ADD COLUMN {col_name} {col_type}"
                print(f"\nAdding column: {col_name}")
                try:
                    conn.execute(text(sql))
                    conn.commit()
                    print(f"✓ Added {col_name}")
                except Exception as e:
                    print(f"✗ Failed to add {col_name}: {e}")
                    conn.rollback()
            else:
                print(f"✓ {col_name} already exists")

        # Verify all columns now exist
        print("\nVerifying columns...")
        result = conn.execute(text("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name='cve_records'
            ORDER BY column_name
        """))

        final_columns = {row[0] for row in result}
        print(f"✓ Final column count: {len(final_columns)}")

        # Check if all required columns are present
        required_columns = {col[0] for col in missing_columns}
        if required_columns.issubset(final_columns):
            print("✓ All required columns are present!")
            return True
        else:
            missing = required_columns - final_columns
            print(f"✗ Still missing: {missing}")
            return False

if __name__ == '__main__':
    print("=" * 70)
    print("Asset Discovery CVE Schema Fix")
    print("=" * 70)

    success = fix_cve_schema()

    print("\n" + "=" * 70)
    if success:
        print("SUCCESS: Database schema fixed!")
        sys.exit(0)
    else:
        print("FAILED: Some columns are still missing")
        sys.exit(1)
