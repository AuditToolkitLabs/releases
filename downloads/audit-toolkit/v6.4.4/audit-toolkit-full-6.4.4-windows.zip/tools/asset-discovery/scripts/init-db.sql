-- Asset Discovery Tool - PostgreSQL Initialization Script
-- This script runs automatically when the PostgreSQL container starts

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For text search

-- Grant privileges to the discovery user
GRANT ALL PRIVILEGES ON DATABASE asset_discovery TO discovery_admin;

-- Create indexes for common queries (tables created by SQLAlchemy)
-- These will be created after the application initializes the schema

-- Note: The actual table creation is handled by SQLAlchemy's init_db()
-- This script just sets up PostgreSQL-specific extensions and settings

-- Set up search path
ALTER DATABASE asset_discovery SET search_path TO public;

-- Optimize for write-heavy workloads (asset discovery)
ALTER DATABASE asset_discovery SET synchronous_commit = off;

-- Log statement for verification
DO $$
BEGIN
    RAISE NOTICE 'Asset Discovery database initialized successfully';
END $$;
