#!/usr/bin/env bash
#
# Linux Asset Discovery Script
# Discovers hardware, OS, software, services, and update information from Linux systems.
# Outputs data in JSON format for the Asset Discovery tool.
#
# Supported Distributions:
#   - Debian/Ubuntu/Mint (apt/dpkg)
#   - RHEL/CentOS/Rocky/Alma/Fedora (dnf/yum/rpm)
#   - openSUSE/SLES (zypper/rpm)
#   - Arch/Manjaro (pacman)
#   - Alpine (apk)
#   - Gentoo (emerge/portage)
#   - Void Linux (xbps)
#   - NixOS (nix)
#   - Clear Linux (swupd)
#   - Solus (eopkg)
#   - Slackware (slackpkg)
#
# Usage: ./linux-discovery.sh [options]
#   -o, --output PATH    Output file path (default: ./asset_discovery.json)
#   -s, --software       Include installed software (slower)
#   -S, --services       Include running services
#   -u, --updates        Include pending updates
#   -d, --storage        Include storage/disk information
#   -n, --network        Include network interfaces
#   -a, --all            Include all (default)
#   -l, --lightweight    Lightweight mode: basic info only (fast, ~2s)
#   -L, --limit N        Limit packages/services to N entries (default: 500)
#   -t, --throttle       Use nice/ionice for low-priority execution
#   -q, --quiet          Suppress progress logging
#   -c, --cache PATH     Cache file for delta comparison
#   -D, --delta          Only output changes since last cached scan
#   -T, --timeout N      Timeout for each section in seconds (default: 30)
#   -h, --help           Show this help
#
# Performance Modes:
#   --lightweight        ~2s   - hostname, OS, IPs only (network scanning)
#   --throttle           +20%  - reduces CPU/IO priority
#   --limit 100          -50%  - fewer package entries
#   --delta              -80%  - only changed data (requires --cache)
#

set -euo pipefail

# Defaults
OUTPUT_PATH="./asset_discovery.json"
INCLUDE_SOFTWARE=true
INCLUDE_SERVICES=true
INCLUDE_UPDATES=true
INCLUDE_STORAGE=true
INCLUDE_NETWORK=true
LIGHTWEIGHT_MODE=false
THROTTLE_MODE=false
QUIET_MODE=false
DELTA_MODE=false
CACHE_FILE=""
PKG_LIMIT=500
SVC_LIMIT=200
SECTION_TIMEOUT=30

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -o|--output)
            OUTPUT_PATH="$2"
            shift 2
            ;;
        -s|--software)
            INCLUDE_SOFTWARE=true
            shift
            ;;
        -S|--services)
            INCLUDE_SERVICES=true
            shift
            ;;
        -u|--updates)
            INCLUDE_UPDATES=true
            shift
            ;;
        -d|--storage)
            INCLUDE_STORAGE=true
            shift
            ;;
        -n|--network)
            INCLUDE_NETWORK=true
            shift
            ;;
        -a|--all)
            INCLUDE_SOFTWARE=true
            INCLUDE_SERVICES=true
            INCLUDE_UPDATES=true
            INCLUDE_STORAGE=true
            INCLUDE_NETWORK=true
            shift
            ;;
        -l|--lightweight)
            LIGHTWEIGHT_MODE=true
            INCLUDE_SOFTWARE=false
            INCLUDE_SERVICES=false
            INCLUDE_UPDATES=false
            INCLUDE_STORAGE=false
            shift
            ;;
        -L|--limit)
            PKG_LIMIT="$2"
            SVC_LIMIT="$((PKG_LIMIT / 2))"
            shift 2
            ;;
        -t|--throttle)
            THROTTLE_MODE=true
            shift
            ;;
        -q|--quiet)
            QUIET_MODE=true
            shift
            ;;
        -c|--cache)
            CACHE_FILE="$2"
            shift 2
            ;;
        -D|--delta)
            DELTA_MODE=true
            shift
            ;;
        -T|--timeout)
            SECTION_TIMEOUT="$2"
            shift 2
            ;;
        -h|--help)
            head -35 "$0" | tail -30
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Apply throttling if requested (reduce CPU/IO priority)
if [[ "$THROTTLE_MODE" == "true" ]]; then
    # Renice current process to lower priority
    renice -n 10 $$ >/dev/null 2>&1 || true
    # Apply ionice if available (idle I/O class)
    if command -v ionice >/dev/null 2>&1; then
        ionice -c 3 -p $$ >/dev/null 2>&1 || true
    fi
fi

# Logging (respects quiet mode)
log() {
    [[ "$QUIET_MODE" == "true" ]] && return 0
    local level="${2:-INFO}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $1" >&2
}

# Run command with timeout wrapper
run_with_timeout() {
    local timeout_sec="${SECTION_TIMEOUT:-30}"
    if command -v timeout >/dev/null 2>&1; then
        timeout "$timeout_sec" "$@" 2>/dev/null || true
    else
        "$@" 2>/dev/null || true
    fi
}

# JSON escaping
json_escape() {
    local str="$1"
    str="${str//\\/\\\\}"
    str="${str//\"/\\\"}"
    str="${str//$'\n'/\\n}"
    str="${str//$'\r'/\\r}"
    str="${str//$'\t'/\\t}"
    echo -n "$str"
}

# Safe value getter
get_value() {
    local val="${1:-}"
    if [[ -z "$val" ]]; then
        echo "null"
    else
        echo "\"$(json_escape "$val")\""
    fi
}

# Detect distro
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck source=/dev/null
        . /etc/os-release
        echo "${ID:-unknown}"
    elif [[ -f /etc/redhat-release ]]; then
        echo "rhel"
    elif [[ -f /etc/debian_version ]]; then
        echo "debian"
    elif [[ -f /etc/SuSE-release ]]; then
        echo "suse"
    elif [[ -f /etc/gentoo-release ]]; then
        echo "gentoo"
    elif [[ -f /etc/slackware-version ]]; then
        echo "slackware"
    elif [[ -f /etc/arch-release ]]; then
        echo "arch"
    elif [[ -f /etc/alpine-release ]]; then
        echo "alpine"
    elif [[ -d /etc/nixos ]]; then
        echo "nixos"
    else
        echo "unknown"
    fi
}

# Get distro family for grouping similar distributions
get_distro_family() {
    local distro="$1"
    case "$distro" in
        ubuntu|debian|linuxmint|pop|elementary|zorin|kali|raspbian|parrot)
            echo "debian"
            ;;
        rhel|centos|rocky|almalinux|fedora|oracle|scientific|amzn|eurolinux)
            echo "redhat"
            ;;
        opensuse*|sles|suse)
            echo "suse"
            ;;
        arch|manjaro|endeavouros|garuda|artix)
            echo "arch"
            ;;
        alpine)
            echo "alpine"
            ;;
        gentoo|funtoo|calculate)
            echo "gentoo"
            ;;
        void)
            echo "void"
            ;;
        nixos)
            echo "nixos"
            ;;
        clear-linux-os|clear)
            echo "clearlinux"
            ;;
        solus)
            echo "solus"
            ;;
        slackware|salix)
            echo "slackware"
            ;;
        *)
            echo "unknown"
            ;;
    esac
}

# Detect package manager
detect_pkg_manager() {
    # Check for package managers in order of preference
    if command -v apt-get >/dev/null 2>&1; then
        echo "apt"
    elif command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v yum >/dev/null 2>&1; then
        echo "yum"
    elif command -v zypper >/dev/null 2>&1; then
        echo "zypper"
    elif command -v pacman >/dev/null 2>&1; then
        echo "pacman"
    elif command -v apk >/dev/null 2>&1; then
        echo "apk"
    elif command -v emerge >/dev/null 2>&1; then
        echo "portage"
    elif command -v xbps-query >/dev/null 2>&1; then
        echo "xbps"
    elif command -v nix-env >/dev/null 2>&1; then
        echo "nix"
    elif command -v swupd >/dev/null 2>&1; then
        echo "swupd"
    elif command -v eopkg >/dev/null 2>&1; then
        echo "eopkg"
    elif command -v slackpkg >/dev/null 2>&1; then
        echo "slackpkg"
    elif command -v rpm >/dev/null 2>&1; then
        # Fallback to rpm if available
        echo "rpm"
    elif command -v dpkg >/dev/null 2>&1; then
        # Fallback to dpkg if available
        echo "dpkg"
    else
        echo "unknown"
    fi
}

# Detect init system
detect_init() {
    if [[ -d /run/systemd/system ]]; then
        echo "systemd"
    elif [[ -f /sbin/openrc ]] || [[ -f /usr/sbin/openrc ]]; then
        echo "openrc"
    elif [[ -f /sbin/runit ]] || [[ -d /run/runit ]]; then
        echo "runit"
    elif [[ -f /sbin/s6-svscan ]] || command -v s6-rc >/dev/null 2>&1; then
        echo "s6"
    elif [[ -f /etc/init.d/cron ]] && ! [[ -d /run/systemd/system ]]; then
        echo "sysvinit"
    elif [[ -f /sbin/init ]]; then
        # Try to determine init type
        local init_type
        init_type=$(file -L /sbin/init 2>/dev/null || echo "")
        if [[ "$init_type" == *"systemd"* ]]; then
            echo "systemd"
        else
            echo "sysvinit"
        fi
    else
        echo "unknown"
    fi
}

log "Starting Linux asset discovery on $(hostname)"

# Initialize JSON arrays
ERRORS="[]"
NETWORK_INTERFACES="[]"
STORAGE="[]"
SOFTWARE="[]"
SERVICES="[]"
PENDING_UPDATES="[]"

add_error() {
    if [[ "$ERRORS" == "[]" ]]; then
        ERRORS="[\"$(json_escape "$1")\"]"
    else
        ERRORS="${ERRORS%]}, \"$(json_escape "$1")\"]"
    fi
}

# ========================================
# SYSTEM INFORMATION
# ========================================
log "Gathering system information..."

HOSTNAME=$(hostname 2>/dev/null || echo "unknown")
FQDN=$(hostname -f 2>/dev/null || echo "$HOSTNAME")
DISTRO=$(detect_distro)
DISTRO_FAMILY=$(get_distro_family "$DISTRO")
PKG_MANAGER=$(detect_pkg_manager)
INIT_SYSTEM=$(detect_init)

# OS info from /etc/os-release
OS_NAME="unknown"
OS_VERSION="unknown"
OS_PRETTY_NAME="unknown"
if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    . /etc/os-release
    OS_NAME="${NAME:-unknown}"
    OS_VERSION="${VERSION_ID:-unknown}"
    OS_PRETTY_NAME="${PRETTY_NAME:-unknown}"
fi

# Kernel
KERNEL_VERSION=$(uname -r 2>/dev/null || echo "unknown")
KERNEL_ARCH=$(uname -m 2>/dev/null || echo "unknown")

# CPU info
CPU_NAME=$(grep -m1 "model name" /proc/cpuinfo 2>/dev/null | cut -d: -f2 | sed 's/^ *//' || echo "unknown")
CPU_CORES=$(grep -c "^processor" /proc/cpuinfo 2>/dev/null || echo "0")

# Memory
TOTAL_MEM_KB=$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2}' || echo "0")
FREE_MEM_KB=$(grep MemAvailable /proc/meminfo 2>/dev/null | awk '{print $2}' || echo "0")
TOTAL_MEM_GB=$(echo "scale=2; $TOTAL_MEM_KB / 1024 / 1024" | bc 2>/dev/null || echo "0")
FREE_MEM_GB=$(echo "scale=2; $FREE_MEM_KB / 1024 / 1024" | bc 2>/dev/null || echo "0")

# Hardware (DMI)
MANUFACTURER="unknown"
MODEL="unknown"
SERIAL="unknown"
if [[ -f /sys/class/dmi/id/sys_vendor ]]; then
    MANUFACTURER=$(cat /sys/class/dmi/id/sys_vendor 2>/dev/null || echo "unknown")
fi
if [[ -f /sys/class/dmi/id/product_name ]]; then
    MODEL=$(cat /sys/class/dmi/id/product_name 2>/dev/null || echo "unknown")
fi
if [[ -f /sys/class/dmi/id/product_serial ]] && [[ -r /sys/class/dmi/id/product_serial ]]; then
    SERIAL=$(cat /sys/class/dmi/id/product_serial 2>/dev/null || echo "unknown")
fi

# Virtualization detection (multi-method approach)
IS_VIRTUAL=false
HYPERVISOR="null"

# Method 1: systemd-detect-virt (most reliable when available)
if command -v systemd-detect-virt >/dev/null 2>&1; then
    VIRT_TYPE=$(systemd-detect-virt 2>/dev/null || echo "none")
    if [[ "$VIRT_TYPE" != "none" ]]; then
        IS_VIRTUAL=true
        HYPERVISOR="\"$VIRT_TYPE\""
    fi
fi

# Method 2: Check /sys/class/dmi/id for VMware, VirtualBox, etc.
if [[ "$IS_VIRTUAL" == "false" ]] && [[ -f /sys/class/dmi/id/product_name ]]; then
    PRODUCT=$(cat /sys/class/dmi/id/product_name 2>/dev/null || echo "")
    # Check specific patterns (order matters - more specific first)
    if [[ "$PRODUCT" == *"VirtualBox"* ]] || [[ "$PRODUCT" == *"VMware"* ]] || \
       [[ "$PRODUCT" == *"KVM"* ]] || [[ "$PRODUCT" == *"QEMU"* ]] || \
       [[ "$PRODUCT" == *"Xen"* ]] || [[ "$PRODUCT" == *"Bochs"* ]] || \
       [[ "$PRODUCT" == *"Virtual Machine"* ]] || [[ "$PRODUCT" == *"HVM"* ]]; then
        IS_VIRTUAL=true
        HYPERVISOR="\"$PRODUCT\""
    fi
fi

# Method 3: Check /sys/hypervisor
if [[ "$IS_VIRTUAL" == "false" ]] && [[ -d /sys/hypervisor ]]; then
    if [[ -f /sys/hypervisor/type ]]; then
        VIRT_TYPE=$(cat /sys/hypervisor/type 2>/dev/null || echo "")
        if [[ -n "$VIRT_TYPE" ]]; then
            IS_VIRTUAL=true
            HYPERVISOR="\"$VIRT_TYPE\""
        fi
    fi
fi

# Method 4: Check cpuinfo for hypervisor flag
if [[ "$IS_VIRTUAL" == "false" ]]; then
    if grep -q "^flags.*hypervisor" /proc/cpuinfo 2>/dev/null; then
        IS_VIRTUAL=true
        HYPERVISOR="\"unknown\""
    fi
fi

# Method 5: Check lscpu for virtualization
if [[ "$IS_VIRTUAL" == "false" ]] && command -v lscpu >/dev/null 2>&1; then
    VIRT_TYPE=$(lscpu 2>/dev/null | grep -i "Hypervisor vendor" | cut -d: -f2 | xargs || echo "")
    if [[ -n "$VIRT_TYPE" ]]; then
        IS_VIRTUAL=true
        HYPERVISOR="\"$VIRT_TYPE\""
    fi
fi

# Method 6: Check for container environments
if [[ "$IS_VIRTUAL" == "false" ]]; then
    if [[ -f /.dockerenv ]] || grep -q docker /proc/1/cgroup 2>/dev/null; then
        IS_VIRTUAL=true
        HYPERVISOR="\"docker\""
    elif grep -q lxc /proc/1/cgroup 2>/dev/null || [[ -d /proc/vz ]]; then
        IS_VIRTUAL=true
        HYPERVISOR="\"lxc/openvz\""
    fi
fi

# Last boot
LAST_BOOT=$(who -b 2>/dev/null | awk '{print $3, $4}' || echo "")
if [[ -n "$LAST_BOOT" ]]; then
    # Try to convert to ISO format
    LAST_BOOT_ISO=$(date -d "$LAST_BOOT" -Iseconds 2>/dev/null || echo "$LAST_BOOT")
else
    LAST_BOOT_ISO=""
fi

# ========================================
# NETWORK INTERFACES
# ========================================
if [[ "$INCLUDE_NETWORK" == "true" ]]; then
    log "Gathering network interface information..."

    # Get interfaces with IP addresses
    IFACE_LIST=""
    if command -v ip >/dev/null 2>&1; then
        while IFS= read -r line; do
            IFACE=$(echo "$line" | awk '{print $2}' | tr -d ':')
            [[ "$IFACE" == "lo" ]] && continue

            IP=$(ip -4 addr show "$IFACE" 2>/dev/null | grep -oP 'inet \K[\d.]+' | head -1 || echo "")
            [[ -z "$IP" ]] && continue

            PREFIX=$(ip -4 addr show "$IFACE" 2>/dev/null | grep -oP 'inet [\d.]+/\K\d+' | head -1 || echo "")
            MAC=$(ip link show "$IFACE" 2>/dev/null | grep -oP 'link/ether \K[0-9a-f:]+' || echo "")
            GATEWAY=$(ip route | grep "default.*$IFACE" | awk '{print $3}' | head -1 || echo "")

            DNS_SERVERS="[]"
            if [[ -f /etc/resolv.conf ]]; then
                DNS=$(grep "^nameserver" /etc/resolv.conf | awk '{print $2}' | head -3)
                if [[ -n "$DNS" ]]; then
                    DNS_JSON=""
                    for ns in $DNS; do
                        [[ -n "$DNS_JSON" ]] && DNS_JSON="$DNS_JSON, "
                        DNS_JSON="$DNS_JSON\"$ns\""
                    done
                    DNS_SERVERS="[$DNS_JSON]"
                fi
            fi

            ENTRY=$(cat <<EOF
{
    "name": "$IFACE",
    "mac_address": $(get_value "$MAC"),
    "ip_address": $(get_value "$IP"),
    "subnet_mask": $(get_value "$PREFIX"),
    "gateway": $(get_value "$GATEWAY"),
    "dns_servers": $DNS_SERVERS,
    "is_dhcp": false
}
EOF
)
            [[ -n "$IFACE_LIST" ]] && IFACE_LIST="$IFACE_LIST,"
            IFACE_LIST="$IFACE_LIST$ENTRY"

        done < <(ip link show 2>/dev/null | grep "^[0-9]")
    fi
    NETWORK_INTERFACES="[$IFACE_LIST]"
    log "Found $(echo "$IFACE_LIST" | grep -c '"name"' || echo 0) network interfaces"
fi

# ========================================
# STORAGE / DISK INFORMATION
# ========================================
if [[ "$INCLUDE_STORAGE" == "true" ]]; then
    log "Gathering storage information..."

    STORAGE_LIST=""
    while IFS= read -r line; do
        FS=$(echo "$line" | awk '{print $1}')
        [[ "$FS" == "tmpfs" ]] || [[ "$FS" == "devtmpfs" ]] || [[ "$FS" == "squashfs" ]] && continue

        MOUNT=$(echo "$line" | awk '{print $6}')
        TYPE=$(echo "$line" | awk '{print $2}')
        SIZE=$(echo "$line" | awk '{print $3}' | tr -d 'G')
        AVAIL=$(echo "$line" | awk '{print $5}' | tr -d 'G')
        USE_PCT=$(echo "$line" | awk '{print $6}' | tr -d '%')

        # Convert to GB if needed (df -h may show M or K)
        ENTRY=$(cat <<EOF
{
    "mount_point": "$MOUNT",
    "device": "$FS",
    "file_system": "$TYPE",
    "total_size_gb": $SIZE,
    "free_space_gb": $AVAIL,
    "used_percent": $USE_PCT
}
EOF
)
        [[ -n "$STORAGE_LIST" ]] && STORAGE_LIST="$STORAGE_LIST,"
        STORAGE_LIST="$STORAGE_LIST$ENTRY"

    done < <(df -hT 2>/dev/null | tail -n +2 | awk '{print $1, $2, $3, $4, $5, $6, $7}')
    STORAGE="[$STORAGE_LIST]"
    log "Found $(echo "$STORAGE_LIST" | grep -c '"mount_point"' || echo 0) storage volumes"
fi

# ========================================
# INSTALLED SOFTWARE
# ========================================
if [[ "$INCLUDE_SOFTWARE" == "true" ]]; then
    log "Gathering installed software (this may take a moment)..."

    SOFTWARE_LIST=""
    PKG_COUNT=0

    case "$PKG_MANAGER" in
        apt|dpkg)
            while IFS= read -r line; do
                NAME=$(echo "$line" | cut -d' ' -f1)
                VERSION=$(echo "$line" | cut -d' ' -f2)
                ARCH=$(echo "$line" | cut -d' ' -f3)

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\", \"architecture\": \"$ARCH\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(dpkg-query -W -f='${Package} ${Version} ${Architecture}\n' 2>/dev/null | head -$PKG_LIMIT)
            ;;
        dnf|yum|rpm)
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                VERSION=$(echo "$line" | awk '{print $2}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(rpm -qa --qf '%{NAME} %{VERSION}-%{RELEASE}\n' 2>/dev/null | head -$PKG_LIMIT)
            ;;
        zypper)
            # openSUSE/SLES
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                VERSION=$(echo "$line" | awk '{print $2}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(rpm -qa --qf '%{NAME} %{VERSION}-%{RELEASE}\n' 2>/dev/null | head -$PKG_LIMIT)
            ;;
        pacman)
            # Arch Linux and derivatives
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                VERSION=$(echo "$line" | awk '{print $2}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(pacman -Q 2>/dev/null | head -$PKG_LIMIT)
            ;;
        apk)
            # Alpine Linux
            while IFS= read -r line; do
                # apk info format: name-version
                NAME=$(echo "$line" | sed -E 's/-[0-9]+\..*$//')
                VERSION=$(echo "$line" | sed -E 's/^[^-]*-//')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(apk info -v 2>/dev/null | head -$PKG_LIMIT)
            ;;
        portage)
            # Gentoo Linux
            while IFS= read -r line; do
                # Format: category/name-version
                NAME=$(echo "$line" | sed 's/-[0-9].*//' | sed 's|.*/||')
                VERSION=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+.*' | head -1 || echo "unknown")
                CATEGORY=$(echo "$line" | cut -d'/' -f1)

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\", \"category\": \"$CATEGORY\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(qlist -Iv 2>/dev/null | head -$PKG_LIMIT || find /var/db/pkg -mindepth 2 -maxdepth 2 -type d 2>/dev/null | sed 's|/var/db/pkg/||' | head -$PKG_LIMIT)
            ;;
        xbps)
            # Void Linux
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                VERSION=$(echo "$line" | awk '{print $2}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(xbps-query -l 2>/dev/null | awk '{print $2}' | sed 's/-[0-9].*/ &/' | head -$PKG_LIMIT)
            ;;
        nix)
            # NixOS
            while IFS= read -r line; do
                # Nix store paths: /nix/store/hash-name-version
                NAME=$(echo "$line" | sed 's|.*/||' | sed 's/-[0-9].*//')
                VERSION=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+[^/]*$' | head -1 || echo "unknown")

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(nix-store -q --references /run/current-system/sw 2>/dev/null | head -$PKG_LIMIT || nix-env -q 2>/dev/null | head -$PKG_LIMIT)
            ;;
        swupd)
            # Clear Linux
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"bundle\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(swupd bundle-list 2>/dev/null | tail -n +2 | head -$PKG_LIMIT)
            ;;
        eopkg)
            # Solus
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                VERSION=$(echo "$line" | awk '{print $2}')

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(eopkg list-installed -N 2>/dev/null | head -$PKG_LIMIT)
            ;;
        slackpkg)
            # Slackware
            while IFS= read -r line; do
                # Package name format: name-version-arch-build
                NAME=$(echo "$line" | rev | cut -d- -f4- | rev)
                VERSION=$(echo "$line" | rev | cut -d- -f3 | rev)

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                ((PKG_COUNT++))
            done < <(find /var/log/packages -maxdepth 1 -type f -exec basename {} \; 2>/dev/null | head -$PKG_LIMIT)
            ;;
        *)
            # Try common fallbacks
            if command -v dpkg-query >/dev/null 2>&1; then
                while IFS= read -r line; do
                    NAME=$(echo "$line" | cut -d' ' -f1)
                    VERSION=$(echo "$line" | cut -d' ' -f2)
                    ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                    [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                    SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                    ((PKG_COUNT++))
                done < <(dpkg-query -W -f='${Package} ${Version}\n' 2>/dev/null | head -"$PKG_LIMIT")
            elif command -v rpm >/dev/null 2>&1; then
                while IFS= read -r line; do
                    NAME=$(echo "$line" | awk '{print $1}')
                    VERSION=$(echo "$line" | awk '{print $2}')
                    ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\"}"
                    [[ -n "$SOFTWARE_LIST" ]] && SOFTWARE_LIST="$SOFTWARE_LIST,"
                    SOFTWARE_LIST="$SOFTWARE_LIST$ENTRY"
                    ((PKG_COUNT++))
                done < <(rpm -qa --qf '%{NAME} %{VERSION}-%{RELEASE}\n' 2>/dev/null | head -"$PKG_LIMIT")
            fi
            ;;
    esac

    SOFTWARE="[$SOFTWARE_LIST]"
    log "Found $PKG_COUNT installed packages"
fi

# ========================================
# RUNNING SERVICES
# ========================================
if [[ "$INCLUDE_SERVICES" == "true" ]]; then
    log "Gathering service information..."

    SERVICE_LIST=""
    SVC_COUNT=0

    case "$INIT_SYSTEM" in
        systemd)
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}' | sed 's/.service$//')
                STATE=$(echo "$line" | awk '{print $3}')

                ENTRY="{\"name\": \"$NAME\", \"status\": \"$STATE\", \"init_system\": \"systemd\"}"
                [[ -n "$SERVICE_LIST" ]] && SERVICE_LIST="$SERVICE_LIST,"
                SERVICE_LIST="$SERVICE_LIST$ENTRY"
                ((SVC_COUNT++))
            done < <(systemctl list-units --type=service --state=running --no-legend 2>/dev/null | head -$SVC_LIMIT)
            ;;
        openrc)
            # Alpine, Gentoo (OpenRC), Artix
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                STATE="running"

                ENTRY="{\"name\": \"$NAME\", \"status\": \"$STATE\", \"init_system\": \"openrc\"}"
                [[ -n "$SERVICE_LIST" ]] && SERVICE_LIST="$SERVICE_LIST,"
                SERVICE_LIST="$SERVICE_LIST$ENTRY"
                ((SVC_COUNT++))
            done < <(rc-status -s 2>/dev/null | grep "started" | awk '{print $1}' || rc-service --list 2>/dev/null | head -$SVC_LIMIT)
            ;;
        runit)
            # Void Linux, Artix
            for svc in /var/service/*; do
                [[ -d "$svc" ]] || continue
                NAME=$(basename "$svc")
                STATE="unknown"
                if sv status "$svc" 2>/dev/null | grep -q "^run:"; then
                    STATE="running"
                fi

                ENTRY="{\"name\": \"$NAME\", \"status\": \"$STATE\", \"init_system\": \"runit\"}"
                [[ -n "$SERVICE_LIST" ]] && SERVICE_LIST="$SERVICE_LIST,"
                SERVICE_LIST="$SERVICE_LIST$ENTRY"
                ((SVC_COUNT++))
            done
            ;;
        s6)
            # s6-rc based systems
            if command -v s6-rc >/dev/null 2>&1; then
                while IFS= read -r line; do
                    NAME="$line"
                    STATE="running"

                    ENTRY="{\"name\": \"$NAME\", \"status\": \"$STATE\", \"init_system\": \"s6\"}"
                    [[ -n "$SERVICE_LIST" ]] && SERVICE_LIST="$SERVICE_LIST,"
                    SERVICE_LIST="$SERVICE_LIST$ENTRY"
                    ((SVC_COUNT++))
                done < <(s6-rc -a list 2>/dev/null | head -$SVC_LIMIT)
            fi
            ;;
        sysvinit|*)
            # Traditional SysV init or unknown - list from /etc/init.d
            for svc in /etc/init.d/*; do
                [[ -x "$svc" ]] || continue
                NAME=$(basename "$svc")
                [[ "$NAME" == "functions" ]] || [[ "$NAME" == "rc" ]] || [[ "$NAME" == "rcS" ]] && continue
                STATE="unknown"

                # Try to determine status
                if "$svc" status >/dev/null 2>&1; then
                    STATE="running"
                fi

                ENTRY="{\"name\": \"$NAME\", \"status\": \"$STATE\", \"init_system\": \"sysvinit\"}"
                [[ -n "$SERVICE_LIST" ]] && SERVICE_LIST="$SERVICE_LIST,"
                SERVICE_LIST="$SERVICE_LIST$ENTRY"
                ((SVC_COUNT++))
            done
            ;;
    esac

    SERVICES="[$SERVICE_LIST]"
    log "Found $SVC_COUNT services"
fi

# ========================================
# PENDING UPDATES
# ========================================
if [[ "$INCLUDE_UPDATES" == "true" ]]; then
    log "Checking for pending updates..."

    UPDATE_LIST=""
    UPDATE_COUNT=0

    case "$PKG_MANAGER" in
        apt|dpkg)
            # Debian/Ubuntu - Update package list quietly
            apt-get update -qq 2>/dev/null || true
            while IFS= read -r line; do
                NAME=$(echo "$line" | cut -d'/' -f1)
                [[ -z "$NAME" ]] || [[ "$NAME" == "Listing..." ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(apt list --upgradable 2>/dev/null | tail -n +2 | head -100)
            ;;
        dnf)
            # Fedora/RHEL 8+
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(dnf check-update -q 2>/dev/null | grep -v "^$" | head -100)
            ;;
        yum|rpm)
            # RHEL 7 and older
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(yum check-update -q 2>/dev/null | grep -v "^$" | head -100)
            ;;
        zypper)
            # openSUSE/SLES
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $3}')
                VERSION=$(echo "$line" | awk '{print $5}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"version\": \"$VERSION\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(zypper list-updates 2>/dev/null | grep "^v" | head -100)
            ;;
        pacman)
            # Arch Linux
            # Sync database first
            pacman -Sy --noconfirm >/dev/null 2>&1 || true
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                OLD_VER=$(echo "$line" | awk '{print $2}')
                NEW_VER=$(echo "$line" | awk '{print $4}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"current_version\": \"$OLD_VER\", \"new_version\": \"$NEW_VER\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(pacman -Qu 2>/dev/null | head -100)
            ;;
        apk)
            # Alpine Linux
            apk update >/dev/null 2>&1 || true
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(apk version -l '<' 2>/dev/null | tail -n +2 | awk '{print $1}' | head -100)
            ;;
        portage)
            # Gentoo - this takes a long time, so just check sync status
            if command -v eix >/dev/null 2>&1; then
                while IFS= read -r line; do
                    NAME=$(echo "$line" | awk '{print $1}')
                    [[ -z "$NAME" ]] && continue

                    ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                    [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                    UPDATE_LIST="$UPDATE_LIST$ENTRY"
                    ((UPDATE_COUNT++))
                done < <(eix -u --format '<installedversions:NAMEVERSION>' 2>/dev/null | head -100)
            fi
            ;;
        xbps)
            # Void Linux
            xbps-install -S >/dev/null 2>&1 || true
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(xbps-install -un 2>/dev/null | head -100)
            ;;
        nix)
            # NixOS - check for channel updates
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"derivation\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(nix-channel --update 2>&1 | grep -i "unpacking" | awk '{print $2}' | head -100 || echo "")
            ;;
        swupd)
            # Clear Linux
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"bundle\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(swupd check-update 2>/dev/null | grep -E "^[0-9]" | head -100 || echo "")
            ;;
        eopkg)
            # Solus
            eopkg update-repo >/dev/null 2>&1 || true
            while IFS= read -r line; do
                NAME=$(echo "$line" | awk '{print $1}')
                [[ -z "$NAME" ]] && continue

                ENTRY="{\"name\": \"$NAME\", \"type\": \"package\"}"
                [[ -n "$UPDATE_LIST" ]] && UPDATE_LIST="$UPDATE_LIST,"
                UPDATE_LIST="$UPDATE_LIST$ENTRY"
                ((UPDATE_COUNT++))
            done < <(eopkg list-upgrades -N 2>/dev/null | head -100)
            ;;
        *)
            # Unknown package manager - try common fallbacks
            log "Unknown package manager, skipping update check" "WARN"
            ;;
    esac

    PENDING_UPDATES="[$UPDATE_LIST]"
    log "Found $UPDATE_COUNT pending updates"
fi

# ========================================
# FINALIZE AND OUTPUT
# ========================================

SCAN_TIMESTAMP=$(date -Iseconds)
SUCCESS="true"
[[ "$ERRORS" != "[]" ]] && SUCCESS="false"

# Build final JSON
JSON_OUTPUT=$(cat <<EOF
{
    "scan_timestamp": "$SCAN_TIMESTAMP",
    "hostname": "$HOSTNAME",
    "os_type": "linux",
    "success": $SUCCESS,
    "errors": $ERRORS,
    "data": {
        "system": {
            "hostname": "$HOSTNAME",
            "fqdn": $(get_value "$FQDN"),
            "distro": "$DISTRO",
            "distro_family": "$DISTRO_FAMILY",
            "os_name": $(get_value "$OS_NAME"),
            "os_version": $(get_value "$OS_VERSION"),
            "os_pretty_name": $(get_value "$OS_PRETTY_NAME"),
            "kernel_version": "$KERNEL_VERSION",
            "architecture": "$KERNEL_ARCH",
            "cpu_name": $(get_value "$CPU_NAME"),
            "cpu_cores": $CPU_CORES,
            "total_memory_gb": $TOTAL_MEM_GB,
            "available_memory_gb": $FREE_MEM_GB,
            "manufacturer": $(get_value "$MANUFACTURER"),
            "model": $(get_value "$MODEL"),
            "serial_number": $(get_value "$SERIAL"),
            "is_virtual": $IS_VIRTUAL,
            "hypervisor": $HYPERVISOR,
            "last_boot": $(get_value "$LAST_BOOT_ISO"),
            "package_manager": "$PKG_MANAGER",
            "init_system": "$INIT_SYSTEM"
        },
        "network_interfaces": $NETWORK_INTERFACES,
        "storage": $STORAGE,
        "software": $SOFTWARE,
        "services": $SERVICES,
        "pending_updates": $PENDING_UPDATES
    }
}
EOF
)

# Save to file
OUTPUT_DIR=$(dirname "$OUTPUT_PATH")
if [[ -n "$OUTPUT_DIR" ]] && [[ "$OUTPUT_DIR" != "." ]]; then
    mkdir -p "$OUTPUT_DIR"
fi

# Delta mode: compare with cache and only output if changed
if [[ "$DELTA_MODE" == "true" ]] && [[ -n "$CACHE_FILE" ]] && [[ -f "$CACHE_FILE" ]]; then
    # Generate hash of new data (excluding timestamp)
    NEW_HASH=$(echo "$JSON_OUTPUT" | sed 's/"discovery_time": "[^"]*"/"discovery_time": ""/' | md5sum | cut -d' ' -f1)
    OLD_HASH=$(sed 's/"discovery_time": "[^"]*"/"discovery_time": ""/' "$CACHE_FILE" 2>/dev/null | md5sum | cut -d' ' -f1)

    if [[ "$NEW_HASH" == "$OLD_HASH" ]]; then
        log "No changes detected since last scan (delta mode)"
        # Output minimal JSON indicating no change
        echo "{\"status\": \"unchanged\", \"hostname\": \"$HOSTNAME\", \"cached_at\": \"$(stat -c %y "$CACHE_FILE" 2>/dev/null || stat -f %Sm "$CACHE_FILE" 2>/dev/null)\"}" > "$OUTPUT_PATH"
        exit 0
    fi
    log "Changes detected, outputting full inventory"
fi

# Update cache file if specified
if [[ -n "$CACHE_FILE" ]]; then
    CACHE_DIR=$(dirname "$CACHE_FILE")
    [[ -n "$CACHE_DIR" ]] && [[ "$CACHE_DIR" != "." ]] && mkdir -p "$CACHE_DIR"
    echo "$JSON_OUTPUT" > "$CACHE_FILE"
    log "Cache updated: $CACHE_FILE"
fi

echo "$JSON_OUTPUT" > "$OUTPUT_PATH"
log "Results saved to: $OUTPUT_PATH"
log "Discovery completed"
