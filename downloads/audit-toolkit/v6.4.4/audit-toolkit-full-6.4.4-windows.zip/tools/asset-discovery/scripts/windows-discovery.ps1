[CmdletBinding()]
param(
    [string]$OutputPath = "-",
    [switch]$IncludeNetwork,
    [switch]$IncludeStorage,
    [switch]$IncludeSoftware,
    [switch]$IncludeServices,
    [switch]$IncludeUpdates,
    [int]$Limit = 200,
    [switch]$Throttle
)

$null = $IncludeSoftware, $IncludeUpdates

$ErrorActionPreference = 'Stop'
$ThrottleDelay = if ($Throttle) { 100 } else { 0 }
$ToStdout = ($OutputPath -eq '-')

function Write-DiscoveryLog {
    param([string]$Message, [string]$Level = 'INFO')
    if (-not $ToStdout) {
        $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Write-Information "[$timestamp] [$Level] $Message" -InformationAction Continue
    }
}

function Select-LimitedItem {
    param($Items, [int]$MaxItems)
    if ($MaxItems -gt 0 -and $Items.Count -gt $MaxItems) {
        return $Items | Select-Object -First $MaxItems
    }
    return $Items
}

function Get-SafeValue {
    param($Value, $Default = $null)
    if ($null -eq $Value) { return $Default }
    if ($Value -is [string] -and [string]::IsNullOrWhiteSpace($Value)) { return $Default }
    return $Value
}

$result = @{
    timestamp = (Get-Date).ToString('o')
    source = 'windows-discovery'
    errors = @()
    data = @{
        system = @{}
        network_interfaces = @()
        storage = @()
        software = @()
        services = @()
        windows_updates = @()
        pending_updates = @()
    }
}

Write-DiscoveryLog "Starting Windows asset discovery on $($env:COMPUTERNAME)"

try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    $processor = Get-CimInstance -ClassName Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1

    $fqdn = $env:COMPUTERNAME
    try { $fqdn = [System.Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName } catch { Write-Verbose 'Suppressed non-fatal error.' }

    $result.data.system = @{
        hostname = $env:COMPUTERNAME
        fqdn = $fqdn
        domain = Get-SafeValue $env:USERDOMAIN
        os_name = Get-SafeValue $os.Caption
        os_version = Get-SafeValue $os.Version
        os_architecture = Get-SafeValue $os.OSArchitecture
        cpu_name = Get-SafeValue $processor.Name
        cpu_cores = Get-SafeValue $processor.NumberOfCores 0
        cpu_logical_processors = Get-SafeValue $processor.NumberOfLogicalProcessors 0
        total_memory_gb = [math]::Round(($cs.TotalPhysicalMemory / 1GB), 2)
    }
}
catch {
    $result.errors += "Failed to gather system information: $($_.Exception.Message)"
}

if ($IncludeNetwork) {
    if ($ThrottleDelay -gt 0) { Start-Sleep -Milliseconds $ThrottleDelay }
    try {
        $adapters = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' }
        foreach ($adapter in $adapters) {
            $result.data.network_interfaces += @{
                name = $adapter.Name
                interface_description = $adapter.InterfaceDescription
                mac = $adapter.MacAddress
                speed = $adapter.LinkSpeed
            }
        }
    }
    catch {
        $result.errors += "Failed to gather network information: $($_.Exception.Message)"
    }
}

if ($IncludeStorage) {
    if ($ThrottleDelay -gt 0) { Start-Sleep -Milliseconds $ThrottleDelay }
    try {
        $disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue
        foreach ($disk in $disks) {
            $result.data.storage += @{
                device = $disk.DeviceID
                filesystem = $disk.FileSystem
                size_gb = [math]::Round(($disk.Size / 1GB), 2)
                free_gb = [math]::Round(($disk.FreeSpace / 1GB), 2)
            }
        }
    }
    catch {
        $result.errors += "Failed to gather storage information: $($_.Exception.Message)"
    }
}

if ($IncludeServices) {
    if ($ThrottleDelay -gt 0) { Start-Sleep -Milliseconds $ThrottleDelay }
    try {
        $services = Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Running' }
        foreach ($svc in (Select-LimitedItem -Items $services -MaxItems $Limit)) {
            $result.data.services += @{
                name = $svc.Name
                display_name = $svc.DisplayName
                state = $svc.State
                start_mode = $svc.StartMode
            }
        }
    }
    catch {
        $result.errors += "Failed to gather services: $($_.Exception.Message)"
    }
}

if ($ToStdout) {
    $result | ConvertTo-Json -Depth 8 -Compress | Write-Output
}
else {
    $json = $result | ConvertTo-Json -Depth 8
    $json | Out-File -LiteralPath $OutputPath -Encoding UTF8 -Force
    Write-DiscoveryLog "Results saved to: $OutputPath"
}
