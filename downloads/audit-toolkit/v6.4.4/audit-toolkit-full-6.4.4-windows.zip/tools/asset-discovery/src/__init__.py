# Asset Discovery Tool - Source Package

__version__ = '1.0.0'
__author__ = 'Security Audit Toolkit Team'
