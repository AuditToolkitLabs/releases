# Asset Discovery - Agent API Routes
# Receives discovery data from fleet agents

import logging
import os
import hmac
from datetime import datetime
from flask import Blueprint, request, jsonify

from ..models.base import session_scope
from ..models.asset import Asset
from ..models.software import InstalledSoftware, AssetService
from ..vulnerability_matcher import update_asset_vulnerabilities
from ..security import require_api_key, rate_limit, validate_hostname

logger = logging.getLogger(__name__)

agents_bp = Blueprint('agents', __name__)

MAX_AGENT_IPS = 32
MAX_AGENT_PACKAGES = 500
MAX_AGENT_SERVICES = 300
MAX_AGENT_PORTS = 300
MAX_AGENT_USERS = 200


def _bounded_list(value, max_items: int, field_name: str, agent_id: str) -> tuple[list, int]:
    """Normalize to list and cap oversized payload collections."""
    if not isinstance(value, list):
        return [], 0

    original_count = len(value)
    if original_count > max_items:
        logger.warning(
            "Agent payload truncated for %s (agent_id=%s): %d -> %d",
            field_name,
            agent_id,
            original_count,
            max_items,
        )
        return value[:max_items], original_count

    return value, original_count


def _validate_agent_request(req):
    """Validate agent request headers."""
    agent_id = req.headers.get('X-Agent-ID')
    api_key = req.headers.get('X-API-Key')

    if not agent_id or not api_key:
        return None, {'error': 'Missing agent credentials'}, 401

    expected_key = os.getenv('AGENT_SYNC_API_KEY') or os.getenv('ASSET_DISCOVERY_API_KEY')
    allow_unconfigured = os.getenv('ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY', '').strip().lower()

    if not expected_key:
        if allow_unconfigured in {'1', 'true', 'yes', 'on'}:
            logger.warning(
                "Agent key validation bypass enabled via "
                "ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY"
            )
        else:
            logger.error(
                "Agent sync key is not configured; set AGENT_SYNC_API_KEY "
                "(preferred) or ASSET_DISCOVERY_API_KEY"
            )
            return None, {'error': 'Agent sync key is not configured'}, 503
    elif not hmac.compare_digest(api_key, expected_key):
        logger.warning("Invalid agent API key for agent_id=%s", agent_id)
        return None, {'error': 'Invalid agent credentials'}, 403

    return agent_id, None, None


@agents_bp.route('/discovery/sync', methods=['POST'])
@rate_limit(max_requests=120, window_seconds=60)
@require_api_key
def agent_discovery_sync():
    """
    Receive discovery data from a fleet agent.

    This endpoint is called by fleet-agent.sh to sync discovery results.
    The data includes: hostname, IP addresses, packages, services, ports, etc.
    """
    agent_id, error, status = _validate_agent_request(request)
    if error:
        return jsonify(error), status

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        raw_hostname = data.get('hostname')
        if not raw_hostname:
            return jsonify({'error': 'hostname required'}), 400

        hostname = validate_hostname(str(raw_hostname))
        if not hostname:
            return jsonify({'error': 'invalid hostname format'}), 400

        # Extract and bound data from agent payload
        ip_addresses, ip_count_received = _bounded_list(data.get('ip_addresses', []), MAX_AGENT_IPS, 'ip_addresses', agent_id)
        packages, pkg_count_received = _bounded_list(data.get('packages', []), MAX_AGENT_PACKAGES, 'packages', agent_id)
        services, svc_count_received = _bounded_list(data.get('services', []), MAX_AGENT_SERVICES, 'services', agent_id)
        open_ports, ports_count_received = _bounded_list(data.get('open_ports', []), MAX_AGENT_PORTS, 'open_ports', agent_id)
        users, users_count_received = _bounded_list(data.get('users', []), MAX_AGENT_USERS, 'users', agent_id)
        os_type = data.get('os_type', 'linux')
        os_name = data.get('os_name', 'Unknown')
        architecture = data.get('architecture', 'unknown')
        security_info = data.get('security', {}) if isinstance(data.get('security', {}), dict) else {}
        update_count = data.get('update_count', 0)
        agent_version = data.get('agent_version', 'unknown')

        payload_limited = any([
            ip_count_received > len(ip_addresses),
            pkg_count_received > len(packages),
            svc_count_received > len(services),
            ports_count_received > len(open_ports),
            users_count_received > len(users),
        ])

        asset_id = None
        with session_scope() as session:
            # Find or create asset by hostname
            asset = session.query(Asset).filter(
                Asset.hostname == hostname
            ).first()

            asset_created = False
            if not asset:
                # Determine primary IP
                primary_ip = ip_addresses[0] if ip_addresses else None

                asset = Asset(
                    hostname=hostname,
                    primary_ip=primary_ip,
                    asset_type='server',
                    os_type=os_type,
                    os_name=os_name,
                    architecture=architecture,
                    status='active',
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow()
                )
                session.add(asset)
                session.flush()  # Get ID
                asset_created = True
                logger.info(f"Created new asset from agent: {hostname}")
            else:
                # Update existing asset
                asset.last_seen = datetime.utcnow()
                asset.status = 'active'
                asset.os_type = os_type
                asset.os_name = os_name
                asset.architecture = architecture
                if ip_addresses:
                    asset.primary_ip = ip_addresses[0]
                logger.debug(f"Updated existing asset from agent: {hostname}")

            # Store additional metadata in custom_attributes
            if not asset.custom_attributes:
                asset.custom_attributes = {}

            asset.custom_attributes.update({
                'agent_id': agent_id,
                'agent_version': agent_version,
                'ip_addresses': ip_addresses,
                'security': security_info,
                'users': users,
                'update_count': update_count,
                'last_agent_sync': datetime.utcnow().isoformat()
            })

            # Update services
            _sync_services(session, asset.id, services, open_ports)

            # Update software/packages
            _sync_software(session, asset.id, packages)

            session.commit()
            asset_id = asset.id

            # Trigger vulnerability matching for this asset when package data is present
            if packages:
                try:
                    match_stats = update_asset_vulnerabilities(asset.id, session)
                    logger.info(
                        "Agent sync vulnerability match for %s: %s new, %s updated",
                        hostname,
                        match_stats.get('new_vulnerabilities', 0),
                        match_stats.get('updated_vulnerabilities', 0),
                    )
                except Exception as match_error:
                    logger.warning("Vulnerability matching failed for %s: %s", hostname, match_error)

        logger.info(f"Agent discovery sync completed for {hostname} (agent: {agent_id})")

        return jsonify({
            'success': True,
            'asset_id': asset_id,
            'hostname': hostname,
            'created': asset_created,
            'packages_synced': len(packages),
            'services_synced': len(services) + len(open_ports),
            'payload_limited': payload_limited,
            'message': 'Discovery data synced successfully'
        }), 200

    except Exception as e:
        logger.exception(f"Agent discovery sync failed: {e}")
        return jsonify({'error': str(e)}), 500


def _sync_services(session, asset_id: int, services: list, open_ports: list):
    """Sync services and open ports for an asset."""
    try:
        # Delete existing services from fleet agent (identified by binary_path marker)
        session.query(AssetService).filter(
            AssetService.asset_id == asset_id,
            AssetService.binary_path.like('fleet_agent:%')
        ).delete(synchronize_session=False)

        # Add services
        for svc in services:
            if isinstance(svc, dict):
                name = svc.get('name', 'unknown')
                status = svc.get('status', 'unknown')
            else:
                name = str(svc)
                status = 'running'

            asset_svc = AssetService(
                asset_id=asset_id,
                service_name=name,
                display_name=name,
                status=status,
                binary_path='fleet_agent:service'  # Marker for fleet agent source
            )
            session.add(asset_svc)

        # Add open ports as services
        for port_info in open_ports:
            if isinstance(port_info, dict):
                port = port_info.get('port')
                protocol = port_info.get('protocol', 'tcp')
                process = port_info.get('process', '')

                # Create service entry for port
                asset_svc = AssetService(
                    asset_id=asset_id,
                    service_name=f"port_{port}_{protocol}",
                    display_name=f"{process or 'Unknown'} on port {port}/{protocol}",
                    status='listening',
                    binary_path=f'fleet_agent:port:{port}',
                    description=f"Listening port {port}/{protocol} ({process})"
                )
                session.add(asset_svc)

    except Exception as e:
        logger.warning(f"Error syncing services for asset {asset_id}: {e}")


def _sync_software(session, asset_id: int, packages: list):
    """Sync installed software/packages for an asset."""
    try:
        # Delete existing software from fleet agent (identified by package_type marker)
        session.query(InstalledSoftware).filter(
            InstalledSoftware.asset_id == asset_id,
            InstalledSoftware.package_type.like('fleet_agent:%')
        ).delete(synchronize_session=False)

        # Add packages (limit to 500 to avoid overwhelming)
        for pkg in packages[:500]:
            if isinstance(pkg, dict):
                name = pkg.get('name', '')
                version = pkg.get('version', '')
                pkg_source = pkg.get('source', 'unknown')
            else:
                name = str(pkg)
                version = ''
                pkg_source = 'unknown'

            if not name:
                continue

            asset_sw = InstalledSoftware(
                asset_id=asset_id,
                name=name,
                version=version,
                version_raw=version,
                package_type=f'fleet_agent:{pkg_source}',
                first_detected=datetime.utcnow(),
                last_detected=datetime.utcnow()
            )
            session.add(asset_sw)

    except Exception as e:
        logger.warning(f"Error syncing software for asset {asset_id}: {e}")


@agents_bp.route('/status', methods=['GET'])
@require_api_key
def agent_status():
    """Check if the agent API is available."""
    return jsonify({
        'status': 'available',
        'timestamp': datetime.utcnow().isoformat(),
        'capabilities': ['discovery_sync', 'vulnerability_match']
    }), 200


@agents_bp.route('/heartbeat', methods=['POST'])
@require_api_key
def agent_heartbeat():
    """
    Agent heartbeat endpoint.

    Called periodically by agents to report they're alive,
    even when not sending full discovery data.
    """
    agent_id, error, status = _validate_agent_request(request)
    if error:
        return jsonify(error), status

    try:
        data = request.get_json() or {}
        raw_hostname = data.get('hostname')
        hostname = validate_hostname(str(raw_hostname)) if raw_hostname else None

        if raw_hostname and not hostname:
            return jsonify({'success': False, 'error': 'invalid hostname format'}), 400

        if hostname:
            with session_scope() as session:
                asset = session.query(Asset).filter(
                    Asset.hostname == hostname
                ).first()

                if asset:
                    asset.last_seen = datetime.utcnow()
                    asset.status = 'active'
                    if not asset.custom_attributes:
                        asset.custom_attributes = {}
                    asset.custom_attributes['last_heartbeat'] = datetime.utcnow().isoformat()
                    asset.custom_attributes['agent_id'] = agent_id
                    session.commit()

        return jsonify({
            'success': True,
            'timestamp': datetime.utcnow().isoformat()
        }), 200

    except Exception as e:
        logger.warning(f"Agent heartbeat failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
