# Assets API Blueprint

import logging
from collections import Counter
from datetime import datetime
from html import escape as html_escape
from flask import Blueprint, jsonify, request, Response
from sqlalchemy import or_

from ..models.base import session_scope
from ..models.asset import Asset
from ..models.software import InstalledSoftware, AssetService
from ..models.patch import PendingUpdate
from ..models.vulnerability import SoftwareVulnerability, CVERecord
from ..services.asset_ingestion import upsert_asset_from_discovery
from ..services.risk_policy import (
    compute_risk_rating,
    compute_risk_score,
    get_risk_policy,
    route_priority,
)
from ..security import (
    validate_pagination, get_safe_search_param, sanitize_string,
    rate_limit, MAX_PAGE_SIZE, require_api_key
)

logger = logging.getLogger(__name__)
assets_bp = Blueprint('assets', __name__)


def _compute_asset_risk_summary(vuln_counts: dict | None, *, environment: str | None = None, criticality: str | None = None) -> dict:
    """Build a deterministic asset risk summary from vulnerability counts."""
    counts = vuln_counts if isinstance(vuln_counts, dict) else {}

    critical = int(counts.get('critical', 0) or 0)
    high = int(counts.get('high', 0) or 0)
    medium = int(counts.get('medium', 0) or 0)
    low = int(counts.get('low', 0) or 0)
    kev = int(counts.get('kev', 0) or 0)
    total = critical + high + medium + low

    env = str(environment or '').strip().lower()
    crit = str(criticality or '').strip().lower()
    business_weight = 0

    policy = get_risk_policy()
    business_weight += int(policy.get('weight_production_context', 0)) if env == 'production' else 0
    business_weight += int(policy.get('weight_criticality_context', 0)) if crit in {'critical', 'high'} else 0

    risk_score = compute_risk_score(
        critical=critical,
        high=high,
        medium=medium,
        low=low,
        kev=kev,
        business_weight=business_weight,
        policy=policy,
    )
    risk_rating = compute_risk_rating(
        risk_score=risk_score,
        kev_count=kev,
        critical_count=critical,
        high_count=high,
        policy=policy,
    )

    return {
        'rating': risk_rating,
        'score': risk_score,
        'open_vulnerabilities': {
            'total': total,
            'critical': critical,
            'high': high,
            'medium': medium,
            'low': low,
            'kev': kev,
        },
    }


@assets_bp.route('', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def list_assets():
    """List all assets with optional filtering."""
    os_type = sanitize_string(request.args.get('os_type', ''), max_length=50)
    status = sanitize_string(request.args.get('status', ''), max_length=20)
    search = get_safe_search_param('search')  # Already escaped for LIKE
    tags = [sanitize_string(t, max_length=50) for t in request.args.getlist('tag')[:20]]

    page, per_page = validate_pagination(
        request.args.get('page', 1, type=int),
        request.args.get('per_page', 50, type=int)
    )

    with session_scope() as session:
        query = session.query(Asset)

        if os_type:
            query = query.filter(Asset.os_type == os_type)
        if status:
            query = query.filter(Asset.status == status)
        if search:
            query = query.filter(
                or_(
                    Asset.hostname.ilike(f'%{search}%', escape='\\'),
                    Asset.fqdn.ilike(f'%{search}%', escape='\\'),
                    Asset.primary_ip.ilike(f'%{search}%', escape='\\')
                )
            )
        if tags:
            for tag in tags:
                if tag:
                    query = query.filter(Asset.tags.contains(tag))

        total = query.count()
        assets = query.offset((page - 1) * per_page).limit(per_page).all()

        asset_ids = [asset.id for asset in assets]
        vuln_counts = Counter()
        pending_counts = Counter()
        software_counts = Counter()
        service_counts = Counter()
        risk_counters: dict[int, dict] = {}

        if asset_ids:
            vuln_counts = Counter(
                row[0]
                for row in session.query(SoftwareVulnerability.asset_id).filter(
                    SoftwareVulnerability.asset_id.in_(asset_ids),
                    SoftwareVulnerability.status == 'open'
                ).all()
            )
            vuln_rows = session.query(
                SoftwareVulnerability.asset_id,
                CVERecord.cvss_v3_severity,
                CVERecord.cisa_kev,
            ).join(
                CVERecord,
                SoftwareVulnerability.cve_id == CVERecord.cve_id,
            ).filter(
                SoftwareVulnerability.asset_id.in_(asset_ids),
                SoftwareVulnerability.status == 'open',
            ).all()
            for asset_id, severity, is_kev in vuln_rows:
                entry = risk_counters.setdefault(asset_id, {
                    'critical': 0,
                    'high': 0,
                    'medium': 0,
                    'low': 0,
                    'kev': 0,
                })
                sev_key = str(severity or 'LOW').strip().lower()
                if sev_key not in {'critical', 'high', 'medium', 'low'}:
                    sev_key = 'low'
                entry[sev_key] += 1
                if bool(is_kev):
                    entry['kev'] += 1
            pending_counts = Counter(
                row[0]
                for row in session.query(PendingUpdate.asset_id).filter(
                    PendingUpdate.asset_id.in_(asset_ids)
                ).all()
            )
            software_counts = Counter(
                row[0]
                for row in session.query(InstalledSoftware.asset_id).filter(
                    InstalledSoftware.asset_id.in_(asset_ids)
                ).all()
            )
            service_counts = Counter(
                row[0]
                for row in session.query(AssetService.asset_id).filter(
                    AssetService.asset_id.in_(asset_ids)
                ).all()
            )

        return jsonify({
            'total': total,
            'page': page,
            'per_page': per_page,
            'max_per_page': MAX_PAGE_SIZE,
            'assets': [
                asset_to_dict(
                    a,
                    vulnerability_count=vuln_counts.get(a.id, 0),
                    pending_updates_count=pending_counts.get(a.id, 0),
                    software_count=software_counts.get(a.id, 0),
                    services_count=service_counts.get(a.id, 0),
                    risk_summary=_compute_asset_risk_summary(
                        risk_counters.get(a.id, {}),
                        environment=a.environment,
                        criticality=a.criticality,
                    ),
                )
                for a in assets
            ]
        })


@assets_bp.route('/<int:asset_id>', methods=['GET'])
@require_api_key
def get_asset(asset_id: int):
    """Get detailed information for a specific asset."""
    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        vuln_rows = session.query(
            CVERecord.cvss_v3_severity,
            CVERecord.cisa_kev,
        ).join(
            SoftwareVulnerability,
            SoftwareVulnerability.cve_id == CVERecord.cve_id,
        ).filter(
            SoftwareVulnerability.asset_id == asset.id,
            SoftwareVulnerability.status == 'open',
        ).all()

        risk_counts = {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'kev': 0,
        }
        for severity, is_kev in vuln_rows:
            sev_key = str(severity or 'LOW').strip().lower()
            if sev_key not in {'critical', 'high', 'medium', 'low'}:
                sev_key = 'low'
            risk_counts[sev_key] += 1
            if bool(is_kev):
                risk_counts['kev'] += 1

        return jsonify(asset_to_dict(
            asset,
            detailed=True,
            risk_summary=_compute_asset_risk_summary(
                risk_counts,
                environment=asset.environment,
                criticality=asset.criticality,
            ),
        ))


@assets_bp.route('/<int:asset_id>/metadata', methods=['PATCH'])
@require_api_key
def update_asset_metadata(asset_id: int):
    """Update editable business/system metadata for an asset."""
    data = request.get_json() or {}

    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        owner = sanitize_string(data.get('owner', ''), max_length=255)
        department = sanitize_string(data.get('department', ''), max_length=255)
        location = sanitize_string(data.get('location', ''), max_length=255)
        environment = sanitize_string(data.get('environment', ''), max_length=50)
        criticality = sanitize_string(data.get('criticality', ''), max_length=20)

        asset.owner = owner or None
        asset.business_unit = department or None
        asset.location = location or None
        asset.environment = environment or None
        asset.criticality = criticality or None

        session.commit()

        return jsonify({
            'success': True,
            'message': 'Asset metadata updated successfully',
            'asset': {
                'id': asset.id,
                'owner': asset.owner,
                'department': asset.business_unit,
                'location': asset.location,
                'environment': asset.environment,
                'criticality': asset.criticality,
            }
        })


@assets_bp.route('', methods=['POST'])
@require_api_key
def create_asset():
    """Create a new asset from discovery data."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    with session_scope() as session:
        asset = upsert_asset_from_discovery(session, data)

        session.commit()

        audit_tool_sync = {
            'success': False,
            'synced_count': 0,
            'created_count': 0,
            'updated_count': 0,
            'failed_count': 0,
            'errors': [],
        }

        try:
            from ..sync_service import get_sync_service

            sync_result = get_sync_service().sync_asset_to_server(asset)
            audit_tool_sync = {
                'success': bool(sync_result.success),
                'synced_count': int(sync_result.synced_count or 0),
                'created_count': int(sync_result.created_count or 0),
                'updated_count': int(sync_result.updated_count or 0),
                'failed_count': int(sync_result.failed_count or 0),
                'errors': list(sync_result.errors or [])[:10],
            }
        except Exception as sync_error:
            logger.warning("Asset %s sync to audit tool failed: %s", asset.id, sync_error)
            audit_tool_sync['errors'] = [str(sync_error)]

        return jsonify({
            'id': asset.id,
            'hostname': asset.hostname,
            'message': 'Asset created/updated successfully',
            'audit_tool_sync': audit_tool_sync,
        }), 201


@assets_bp.route('/manual', methods=['POST'])
@require_api_key
def create_asset_manual():
    """Create a new asset manually (simpler endpoint for direct user input)."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    # Validate required fields
    hostname = sanitize_string(data.get('hostname', ''), max_length=255)
    primary_ip = sanitize_string(data.get('primary_ip', ''), max_length=45)

    if not hostname:
        return jsonify({'error': 'Hostname is required'}), 400
    if not primary_ip:
        return jsonify({'error': 'IP address is required'}), 400

    with session_scope() as session:
        # Check for existing asset by hostname or IP
        existing = session.query(Asset).filter(
            (Asset.hostname == hostname) | (Asset.primary_ip == primary_ip)
        ).first()

        if existing:
            # Update existing asset
            asset = existing
            asset.last_seen = datetime.utcnow()
            message = 'Asset updated successfully'
        else:
            # Create new asset
            asset = Asset(hostname=hostname)
            asset.first_seen = datetime.utcnow()
            asset.last_seen = datetime.utcnow()
            session.add(asset)
            message = 'Asset created successfully'

        # Update basic fields
        asset.primary_ip = primary_ip
        asset.fqdn = sanitize_string(data.get('fqdn', ''), max_length=255) or None
        asset.os_type = sanitize_string(data.get('os_type', 'unknown'), max_length=50)
        asset.status = sanitize_string(data.get('status', 'active'), max_length=20)
        asset.owner = sanitize_string(data.get('owner', ''), max_length=255) or asset.owner
        asset.business_unit = sanitize_string(data.get('department', ''), max_length=255) or asset.business_unit

        # Handle tags (store as JSON list)
        tags = data.get('tags', [])
        if isinstance(tags, list):
            asset.tags = [sanitize_string(t, max_length=50) for t in tags[:20] if t]
        elif isinstance(tags, str):
            asset.tags = [sanitize_string(t.strip(), max_length=50) for t in tags.split(',') if t.strip()]

        # Handle elevation settings (for Audit Toolkit integration)
        elevation_method = data.get('elevation_method')
        if elevation_method and elevation_method in ('sudo', 'sudo_nopasswd', 'audit_wrapper', 'runas', 'jea', 'admin', 'none'):
            asset.elevation_method = elevation_method
        elif not asset.elevation_method:
            # Default based on OS type: Linux=sudo, Windows=runas
            asset.elevation_method = 'sudo' if asset.os_type != 'windows' else 'runas'

        jea_endpoint = data.get('jea_endpoint')
        if jea_endpoint and asset.elevation_method == 'jea':
            asset.jea_endpoint = sanitize_string(jea_endpoint, max_length=100)

        execution_mode = data.get('execution_mode')
        if execution_mode and execution_mode in ('stream', 'deployed'):
            asset.execution_mode = execution_mode

        # Store connection method and credentials as metadata (if provided)
        connection_method = data.get('connection_method', 'ssh')

        # Log connection info (credentials not persisted for security)
        logger.info("Asset %s added/updated - method: %s", hostname, connection_method)

        session.commit()

        audit_tool_sync = {
            'success': False,
            'synced_count': 0,
            'created_count': 0,
            'updated_count': 0,
            'failed_count': 0,
            'errors': [],
        }

        try:
            from ..sync_service import get_sync_service

            sync_result = get_sync_service().sync_asset_to_server(asset)
            audit_tool_sync = {
                'success': bool(sync_result.success),
                'synced_count': int(sync_result.synced_count or 0),
                'created_count': int(sync_result.created_count or 0),
                'updated_count': int(sync_result.updated_count or 0),
                'failed_count': int(sync_result.failed_count or 0),
                'errors': list(sync_result.errors or [])[:10],
            }
        except Exception as sync_error:
            logger.warning("Manual asset %s sync to audit tool failed: %s", asset.id, sync_error)
            audit_tool_sync['errors'] = [str(sync_error)]

        return jsonify({
            'id': asset.id,
            'hostname': asset.hostname,
            'primary_ip': asset.primary_ip,
            'connection_method': connection_method,
            'message': message,
            'audit_tool_sync': audit_tool_sync,
        }), 201


@assets_bp.route('/<int:asset_id>', methods=['DELETE'])
@require_api_key
def delete_asset(asset_id: int):
    """Delete an asset and purge mirrored audit-tool server records for that asset."""
    from ..sync_service import get_sync_service

    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        sync_cleanup = get_sync_service().remove_asset_from_audit_tool(asset)
        if not sync_cleanup.success:
            return jsonify({
                'error': 'Failed to remove linked audit-tool data for asset',
                'details': sync_cleanup.errors,
                'asset_id': asset_id,
            }), 500

        session.delete(asset)
        session.commit()

        return jsonify({
            'message': 'Asset deleted successfully',
            'asset_id': asset_id,
            'audit_tool_cleanup': {
                'removed_server_count': sync_cleanup.details.get('removed_server_count', 0),
                'removed_server_ids': sync_cleanup.details.get('removed_server_ids', []),
                'related_rows_deleted': sync_cleanup.details.get('related_rows_deleted', 0),
            }
        })


@assets_bp.route('/<int:asset_id>/software', methods=['GET'])
@require_api_key
def get_asset_software(asset_id: int):
    """Get installed software for an asset."""
    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        software = session.query(InstalledSoftware).filter(
            InstalledSoftware.asset_id == asset_id
        ).all()

        return jsonify({
            'asset_id': asset_id,
            'hostname': asset.hostname,
            'software': [
                {
                    'id': s.id,
                    'name': s.name,
                    'version': s.version,
                    'publisher': s.publisher,
                    'cpe': s.cpe_uri,
                    'vulnerability_count': len(s.vulnerabilities) if hasattr(s, 'vulnerabilities') else 0
                }
                for s in software
            ]
        })


@assets_bp.route('/<int:asset_id>/services', methods=['GET'])
@require_api_key
def get_asset_services(asset_id: int):
    """Get running services for an asset."""
    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        services = session.query(AssetService).filter(
            AssetService.asset_id == asset_id
        ).all()

        return jsonify({
            'asset_id': asset_id,
            'hostname': asset.hostname,
            'services': [
                {
                    'id': s.id,
                    'name': s.service_name,
                    'display_name': s.display_name,
                    'status': s.status,
                    'start_type': s.start_type
                }
                for s in services
            ]
        })


@assets_bp.route('/<int:asset_id>/report/<string:report_type>', methods=['GET'])
@require_api_key
def get_asset_host_report(asset_id: int, report_type: str):
    """Render host-level HTML reports from stored asset/software/CVE state."""
    normalized_report_type = sanitize_string(report_type, max_length=50).lower().strip()
    valid_report_types = {'host-details', 'cves', 'software-summary', 'software-inventory'}
    if normalized_report_type not in valid_report_types:
        return jsonify({'error': 'Invalid report type'}), 400

    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        asset_hostname = str(asset.hostname or 'host')

        pending_updates = session.query(PendingUpdate).filter(
            PendingUpdate.asset_id == asset_id
        ).all()
        installed_software = session.query(InstalledSoftware).filter(
            InstalledSoftware.asset_id == asset_id
        ).all()

        pending_lookup = {}
        for update in pending_updates:
            key = str(update.package_name or '').strip().lower()
            if key:
                pending_lookup[key] = update

        software_rows = []
        seen_names = set()

        for software in installed_software:
            software_name = str(software.name or '').strip()
            if not software_name:
                continue

            current_version = str(software.version or '').strip() or '-'
            pending = pending_lookup.get(software_name.lower())
            latest_version = str(
                (pending.available_version if pending else '')
                or (pending.current_version if pending else '')
                or current_version
                or '-'
            ).strip() or '-'
            update_available = bool(
                pending
                and latest_version not in {'', '-', current_version}
            )

            software_rows.append({
                'software_loaded': software_name,
                'software_type': str(software.package_type or 'Unknown').strip() or 'Unknown',
                'present_version': current_version,
                'update_available': 'Yes' if update_available else 'No',
                'latest_version': latest_version,
            })
            seen_names.add(software_name.lower())

        for update in pending_updates:
            package_name = str(update.package_name or '').strip()
            if not package_name or package_name.lower() in seen_names:
                continue

            software_rows.append({
                'software_loaded': package_name,
                'software_type': 'Unknown',
                'present_version': str(update.current_version or '-').strip() or '-',
                'update_available': 'Yes',
                'latest_version': str(update.available_version or '-').strip() or '-',
            })

        software_rows.sort(key=lambda row: row['software_loaded'].lower())

        cve_rows = session.query(
            SoftwareVulnerability.cve_id,
            SoftwareVulnerability.software_id,
            InstalledSoftware.name,
            InstalledSoftware.version,
            CVERecord.cvss_v3_severity,
            CVERecord.cvss_v3_score,
            CVERecord.published_date,
        ).outerjoin(
            InstalledSoftware,
            InstalledSoftware.id == SoftwareVulnerability.software_id,
        ).outerjoin(
            CVERecord,
            CVERecord.cve_id == SoftwareVulnerability.cve_id,
        ).filter(
            SoftwareVulnerability.asset_id == asset_id,
            SoftwareVulnerability.status == 'open',
        ).order_by(
            CVERecord.cvss_v3_score.desc().nullslast(),
            SoftwareVulnerability.cve_id.asc(),
        ).all()

        title_map = {
            'host-details': 'Host Details Report',
            'cves': 'Host CVE Report',
            'software-summary': 'Software Summary Report',
            'software-inventory': 'Full Software List Report',
        }
        title = title_map[normalized_report_type]

        nav_links = " | ".join([
            f"<a href=\"/api/v1/assets/{asset_id}/report/host-details\">Host Details</a>",
            f"<a href=\"/api/v1/assets/{asset_id}/report/cves\">CVE Report</a>",
            f"<a href=\"/api/v1/assets/{asset_id}/report/software-summary\">Software Summary</a>",
            f"<a href=\"/api/v1/assets/{asset_id}/report/software-inventory\">Full Software List</a>",
        ])

        base_header = (
            f"<h2>{html_escape(title)} (Host: {html_escape(str(asset.hostname or '-'))})</h2>"
            f"<p><strong>Generated:</strong> {html_escape(datetime.utcnow().isoformat())}</p>"
            f"<p><strong>Shortcuts:</strong> {nav_links}</p>"
        )

        if normalized_report_type == 'host-details':
            host_rows = [
                ('Asset ID', asset.id),
                ('Hostname', asset.hostname or '-'),
                ('FQDN', asset.fqdn or '-'),
                ('Primary IP', asset.primary_ip or '-'),
                ('OS Type', asset.os_type or '-'),
                ('OS Name', asset.os_name or '-'),
                ('OS Version', asset.os_version or '-'),
                ('Status', asset.status or '-'),
                ('Owner', asset.owner or '-'),
                ('Department', asset.business_unit or '-'),
                ('Last Seen', asset.last_seen.isoformat() if asset.last_seen else '-'),
            ]
            rows_html = ''.join(
                f"<tr><td>{html_escape(str(label))}</td><td>{html_escape(str(value))}</td></tr>"
                for label, value in host_rows
            )
            content = (
                f"{base_header}"
                "<table id=\"host-details-table\" border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%;\">"
                "<thead><tr><th>Field</th><th>Value</th></tr></thead>"
                f"<tbody>{rows_html}</tbody></table>"
            )
        elif normalized_report_type == 'cves':
            if cve_rows:
                rows_html = ''.join(
                    "<tr>"
                    f"<td>{html_escape(str(cve_id or '-'))}</td>"
                    f"<td>{html_escape(str(severity or '-'))}</td>"
                    f"<td>{html_escape(str(round(float(score), 1)) if score is not None else '-')}</td>"
                    f"<td>{html_escape(str(name or '-'))}</td>"
                    f"<td>{html_escape(str(version or '-'))}</td>"
                    f"<td>{html_escape(published_date.isoformat() if published_date else '-')}</td>"
                    "</tr>"
                    for cve_id, _software_id, name, version, severity, score, published_date in cve_rows
                )
            else:
                rows_html = '<tr><td colspan="6">No open CVEs linked to this host.</td></tr>'

            script = (
                "<script>"
                "(function(){"
                "const inputs=["
                "document.getElementById('cve-filter-1'),"
                "document.getElementById('cve-filter-2'),"
                "document.getElementById('cve-filter-3'),"
                "document.getElementById('cve-filter-4'),"
                "document.getElementById('cve-filter-5'),"
                "document.getElementById('cve-filter-6')"
                "];"
                "const rows=Array.from(document.querySelectorAll('#cve-report-table tbody tr'));"
                "function apply(){"
                "const queries=inputs.map((el)=>(el&&el.value?el.value:'').toLowerCase().trim());"
                "for(const row of rows){"
                "const cells=Array.from(row.querySelectorAll('td')).map((cell)=>String(cell.textContent||'').toLowerCase());"
                "let show=true;"
                "for(let i=0;i<queries.length;i++){if(queries[i]&&!(cells[i]||'').includes(queries[i])){show=false;break;}}"
                "row.style.display=show?'':'none';"
                "}"
                "}"
                "for(const input of inputs){if(input){input.addEventListener('input',apply);}}"
                "})();"
                "</script>"
            )

            content = (
                f"{base_header}"
                f"<p><strong>Total open CVEs:</strong> {len(cve_rows)}</p>"
                "<table id=\"cve-report-table\" border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%;\">"
                "<thead>"
                "<tr><th>CVE</th><th>Severity</th><th>CVSS</th><th>Software</th><th>Version</th><th>Published</th></tr>"
                "<tr>"
                "<th><input id=\"cve-filter-1\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"cve-filter-2\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"cve-filter-3\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"cve-filter-4\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"cve-filter-5\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"cve-filter-6\" type=\"text\" placeholder=\"filter\" style=\"width: 98%; padding: 4px;\"></th>"
                "</tr>"
                "</thead>"
                f"<tbody>{rows_html}</tbody></table>"
                f"{script}"
            )
        elif normalized_report_type == 'software-summary':
            updates_available_count = sum(1 for row in software_rows if row['update_available'] == 'Yes')
            vulnerable_software_count = len({
                str(name or '').strip().lower()
                for _cve_id, _software_id, name, _version, _severity, _score, _published in cve_rows
                if str(name or '').strip()
            })

            top_vuln_counts = Counter(
                str(name or 'unknown')
                for _cve_id, _software_id, name, _version, _severity, _score, _published in cve_rows
            )
            top_rows = ''.join(
                f"<tr><td>{html_escape(name)}</td><td>{count}</td></tr>"
                for name, count in top_vuln_counts.most_common(10)
            ) or '<tr><td colspan="2">No vulnerable software entries.</td></tr>'

            script = (
                "<script>"
                "(function(){"
                "const nameInput=document.getElementById('ss-filter-name');"
                "const countInput=document.getElementById('ss-filter-count');"
                "const rows=Array.from(document.querySelectorAll('#summary-vuln-table tbody tr'));"
                "function apply(){"
                "const nameQ=(nameInput.value||'').toLowerCase().trim();"
                "const minCount=parseInt((countInput.value||'').trim(),10);"
                "for(const row of rows){"
                "const cells=row.querySelectorAll('td');"
                "const nameText=((cells[0]&&cells[0].textContent)||'').toLowerCase();"
                "const countVal=parseInt(((cells[1]&&cells[1].textContent)||'0').trim(),10);"
                "const nameOk=!nameQ||nameText.includes(nameQ);"
                "const countOk=Number.isNaN(minCount)||countVal>=minCount;"
                "row.style.display=(nameOk&&countOk)?'':'none';"
                "}"
                "}"
                "nameInput.addEventListener('input',apply);"
                "countInput.addEventListener('input',apply);"
                "})();"
                "</script>"
            )

            content = (
                f"{base_header}"
                "<ul>"
                f"<li><strong>Total software discovered:</strong> {len(software_rows)}</li>"
                f"<li><strong>Software with updates available:</strong> {updates_available_count}</li>"
                f"<li><strong>Total open CVEs:</strong> {len(cve_rows)}</li>"
                f"<li><strong>Software impacted by CVEs:</strong> {vulnerable_software_count}</li>"
                "</ul>"
                "<h3>Top Vulnerable Software</h3>"
                "<table id=\"summary-vuln-table\" border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%;\">"
                "<thead>"
                "<tr><th>Software</th><th>Open CVE Count</th></tr>"
                "<tr>"
                "<th><input id=\"ss-filter-name\" type=\"text\" placeholder=\"filter software\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"ss-filter-count\" type=\"number\" min=\"0\" placeholder=\"min count\" style=\"width: 98%; padding: 4px;\"></th>"
                "</tr>"
                "</thead>"
                f"<tbody>{top_rows}</tbody></table>"
                f"{script}"
            )
        else:
            if software_rows:
                rows_html = ''.join(
                    "<tr class=\"inventory-row\" "
                    f"data-name=\"{html_escape(str(row['software_loaded']).lower())}\" "
                    f"data-update=\"{html_escape(str(row['update_available']).lower())}\" "
                    f"data-present-version=\"{html_escape(str(row['present_version']).lower())}\" "
                    f"data-latest-version=\"{html_escape(str(row['latest_version']).lower())}\">"
                    f"<td>{html_escape(str(row['software_loaded']))}</td>"
                    f"<td>{html_escape(str(row['present_version']))}</td>"
                    f"<td>{html_escape(str(row['update_available']))}</td>"
                    f"<td>{html_escape(str(row['latest_version']))}</td>"
                    "</tr>"
                    for row in software_rows
                )

                script = (
                    "<script>"
                    "(function(){"
                    "const nameInput=document.getElementById('inv-filter-name');"
                    "const presentInput=document.getElementById('inv-filter-present');"
                    "const updateSelect=document.getElementById('inv-filter-update');"
                    "const latestInput=document.getElementById('inv-filter-latest');"
                    "const sortSelect=document.getElementById('inv-sort');"
                    "const clearButton=document.getElementById('inv-clear');"
                    "const countNode=document.getElementById('inventory-visible-count');"
                    "const tableBody=document.querySelector('#software-inventory-table tbody');"
                    "const rows=Array.from(tableBody.querySelectorAll('tr.inventory-row'));"
                    "const textForSort=(row,attr)=>String(row.getAttribute(attr)||'').toLowerCase();"
                    "const updateRank=(value)=>value==='yes'?1:0;"
                    "const urlParams=new URLSearchParams(window.location.search);"
                    "const presetName=(urlParams.get('name')||'').trim();"
                    "const presetUpdate=(urlParams.get('update')||'all').toLowerCase().trim();"
                    "const presetSort=(urlParams.get('sort')||'name-asc').toLowerCase().trim();"
                    "if(presetName){nameInput.value=presetName;}"
                    "if(['all','yes','no'].includes(presetUpdate)){updateSelect.value=presetUpdate;}"
                    "if(Array.from(sortSelect.options).some((opt)=>opt.value===presetSort)){sortSelect.value=presetSort;}"
                    "function applyFiltersAndSort(){"
                    "const nameFilter=(nameInput.value||'').toLowerCase().trim();"
                    "const presentFilter=(presentInput.value||'').toLowerCase().trim();"
                    "const updateFilter=updateSelect.value;"
                    "const latestFilter=(latestInput.value||'').toLowerCase().trim();"
                    "const sortBy=sortSelect.value;"
                    "const filtered=[];"
                    "for(const row of rows){"
                    "const rowName=textForSort(row,'data-name');"
                    "const rowPresent=textForSort(row,'data-present-version');"
                    "const rowUpdate=textForSort(row,'data-update');"
                    "const rowLatest=textForSort(row,'data-latest-version');"
                    "const nameOk=!nameFilter||rowName.includes(nameFilter);"
                    "const presentOk=!presentFilter||rowPresent.includes(presentFilter);"
                    "const updateOk=updateFilter==='all'||rowUpdate===updateFilter;"
                    "const latestOk=!latestFilter||rowLatest.includes(latestFilter);"
                    "const show=nameOk&&presentOk&&updateOk&&latestOk;"
                    "row.style.display=show?'':'none';"
                    "if(show){filtered.push(row);}"
                    "}"
                    "filtered.sort((a,b)=>{"
                    "if(sortBy==='name-asc'){return textForSort(a,'data-name').localeCompare(textForSort(b,'data-name'));}"
                    "if(sortBy==='name-desc'){return textForSort(b,'data-name').localeCompare(textForSort(a,'data-name'));}"
                    "if(sortBy==='update-desc'){return updateRank(textForSort(b,'data-update'))-updateRank(textForSort(a,'data-update'));}"
                    "if(sortBy==='update-asc'){return updateRank(textForSort(a,'data-update'))-updateRank(textForSort(b,'data-update'));}"
                    "return 0;"
                    "});"
                    "for(const row of filtered){tableBody.appendChild(row);}"
                    "countNode.textContent='Showing '+filtered.length+' of '+rows.length+' software entries';"
                    "}"
                    "nameInput.addEventListener('input',applyFiltersAndSort);"
                    "presentInput.addEventListener('input',applyFiltersAndSort);"
                    "updateSelect.addEventListener('change',applyFiltersAndSort);"
                    "latestInput.addEventListener('input',applyFiltersAndSort);"
                    "sortSelect.addEventListener('change',applyFiltersAndSort);"
                    "clearButton.addEventListener('click',function(){"
                    "nameInput.value='';presentInput.value='';updateSelect.value='all';latestInput.value='';sortSelect.value='name-asc';"
                    "applyFiltersAndSort();"
                    "});"
                    "applyFiltersAndSort();"
                    "})();"
                    "</script>"
                )
            else:
                script = ''
                rows_html = '<tr><td colspan="4">No software inventory found for this host.</td></tr>'

            content = (
                f"{base_header}"
                "<div style=\"margin: 8px 0 10px; display: flex; gap: 10px; align-items: center;\">"
                "<label><strong>Sort:</strong> <select id=\"inv-sort\" style=\"padding: 4px;\"><option value=\"name-asc\">Name (A-Z)</option><option value=\"name-desc\">Name (Z-A)</option><option value=\"update-desc\">Updates First</option><option value=\"update-asc\">No Updates First</option></select></label>"
                "<button id=\"inv-clear\" type=\"button\" style=\"padding: 4px 10px;\">Clear Filters</button>"
                "</div>"
                "<table id=\"software-inventory-table\" border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%;\">"
                "<thead>"
                "<tr><th>Software Loaded</th><th>Present Version</th><th>Update Available</th><th>Latest Version</th></tr>"
                "<tr>"
                "<th><input id=\"inv-filter-name\" type=\"text\" placeholder=\"filter software\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><input id=\"inv-filter-present\" type=\"text\" placeholder=\"filter version\" style=\"width: 98%; padding: 4px;\"></th>"
                "<th><select id=\"inv-filter-update\" style=\"width: 98%; padding: 4px;\"><option value=\"all\">All</option><option value=\"yes\">Yes</option><option value=\"no\">No</option></select></th>"
                "<th><input id=\"inv-filter-latest\" type=\"text\" placeholder=\"filter latest\" style=\"width: 98%; padding: 4px;\"></th>"
                "</tr>"
                "</thead>"
                f"<tbody>{rows_html}</tbody></table>"
                "<div id=\"inventory-visible-count\" style=\"margin-top: 10px; color: #444;\"></div>"
                f"{script}"
            )

        html = (
            '<!doctype html><html><head><meta charset="utf-8">'
            f'<title>{html_escape(title)} - {html_escape(asset_hostname)}</title>'
            '</head><body style="font-family: Arial, sans-serif; margin: 24px;">'
            f'{content}'
            '</body></html>'
        )
        return Response(html, mimetype='text/html; charset=utf-8')


@assets_bp.route('/report/cmdb', methods=['GET'])
@require_api_key
@rate_limit(max_requests=30, window_seconds=60)
def get_cmdb_report():
    """Return a detailed CMDB/asset-management report across all discovered assets."""
    include_raw = request.args.get('include_raw', 'false').lower() == 'true'

    with session_scope() as session:
        assets = session.query(Asset).order_by(Asset.hostname.asc()).all()
        asset_ids = [asset.id for asset in assets]

        risk_counters: dict[int, dict] = {}
        vuln_rows = session.query(
            SoftwareVulnerability.asset_id,
            CVERecord.cvss_v3_severity,
            CVERecord.cisa_kev,
        ).join(
            CVERecord,
            SoftwareVulnerability.cve_id == CVERecord.cve_id,
        ).filter(
            SoftwareVulnerability.asset_id.in_(asset_ids),
            SoftwareVulnerability.status == 'open',
        ).all() if asset_ids else []

        for asset_id, severity, is_kev in vuln_rows:
            entry = risk_counters.setdefault(asset_id, {
                'critical': 0,
                'high': 0,
                'medium': 0,
                'low': 0,
                'kev': 0,
            })
            sev_key = str(severity or 'LOW').strip().lower()
            if sev_key not in {'critical', 'high', 'medium', 'low'}:
                sev_key = 'low'
            entry[sev_key] += 1
            if bool(is_kev):
                entry['kev'] += 1

        report_assets = [
            asset_to_dict(
                asset,
                detailed=True,
                vulnerability_count=len(asset.vulnerabilities),
                pending_updates_count=len(asset.pending_updates),
                software_count=len(asset.software),
                services_count=len(asset.services),
                include_raw=include_raw,
                risk_summary=_compute_asset_risk_summary(
                    risk_counters.get(asset.id, {}),
                    environment=asset.environment,
                    criticality=asset.criticality,
                ),
            )
            for asset in assets
        ]

        top_priority_assets = sorted(
            [asset for asset in report_assets if isinstance(asset.get('risk_summary'), dict)],
            key=lambda item: (
                0 if str(item.get('risk_summary', {}).get('rating')) == 'critical' else 1 if str(item.get('risk_summary', {}).get('rating')) == 'high' else 2,
                -int(item.get('risk_summary', {}).get('score') or 0),
                str(item.get('hostname') or ''),
            )
        )[:10]

        compliance_routing = {
            'vulnerability_management_immediate': 0,
            'vulnerability_management_planned': 0,
        }
        for asset in top_priority_assets:
            rating = str(asset.get('risk_summary', {}).get('rating') or 'low')
            priority = route_priority('vulnerability_management', rating)
            compliance_routing[f'vulnerability_management_{priority}'] += 1

        return jsonify({
            'generated_at': datetime.utcnow().isoformat(),
            'total_assets': len(report_assets),
            'assets': report_assets,
            'top_priority_assets': top_priority_assets,
            'compliance_routing': compliance_routing,
        })


def asset_to_dict(
    asset: Asset,
    detailed: bool = False,
    vulnerability_count: int = 0,
    pending_updates_count: int = 0,
    software_count: int = 0,
    services_count: int = 0,
    include_raw: bool = False,
    risk_summary: dict | None = None,
) -> dict:
    """Convert asset to dictionary."""
    result = {
        'id': asset.id,
        'hostname': asset.hostname,
        'fqdn': asset.fqdn,
        'primary_ip': asset.primary_ip,
        'os_type': asset.os_type,
        'os_name': asset.os_name,
        'os_version': asset.os_version,
        'status': asset.status,
        'vulnerability_count': vulnerability_count,
        'risk_summary': risk_summary if isinstance(risk_summary, dict) else _compute_asset_risk_summary({}, environment=asset.environment, criticality=asset.criticality),
        'vulnerability_details_url': f'/api/v1/vulnerabilities/assets/{asset.id}?status=open',
        'vulnerability_refresh_url': f'/api/v1/vulnerabilities/assets/{asset.id}?status=open&refresh=true',
        'pending_updates_count': pending_updates_count,
        'software_count': software_count,
        'services_count': services_count,
        'last_seen': asset.last_seen.isoformat() if asset.last_seen else None,
        'tags': asset.tags
    }

    if detailed:
        custom_attributes = asset.custom_attributes or {}
        last_scan_data = custom_attributes.get('last_scan_data') if isinstance(custom_attributes, dict) else {}
        cmdb_hardware = custom_attributes.get('cmdb_hardware') if isinstance(custom_attributes, dict) else {}
        if not isinstance(last_scan_data, dict):
            last_scan_data = {}
        if not isinstance(cmdb_hardware, dict):
            cmdb_hardware = {}

        result.update({
            'kernel_version': asset.kernel_version,
            'architecture': asset.architecture,
            'manufacturer': asset.manufacturer,
            'model': asset.model,
            'serial_number': asset.serial_number,
            'cpu_model': asset.cpu_model,
            'cpu_cores': asset.cpu_cores,
            'cpu_threads': asset.cpu_threads,
            'total_memory_gb': asset.total_memory_gb,
            'is_virtual': asset.is_virtual,
            'hypervisor': asset.hypervisor,
            'first_seen': asset.first_seen.isoformat() if asset.first_seen else None,
            'os_build': asset.os_build,
            'domain': asset.domain,
            'owner': asset.owner,
            'department': asset.business_unit,
            'business_unit': asset.business_unit,
            'location': asset.location,
            'environment': asset.environment,
            'criticality': asset.criticality,
            'product_id': cmdb_hardware.get('product_id'),
            'asset_tag': cmdb_hardware.get('asset_tag'),
            'product_uuid': cmdb_hardware.get('product_uuid'),
            'connection_method': last_scan_data.get('connection_method') or last_scan_data.get('discovery_method'),
            'discovery_tool_label': last_scan_data.get('discovery_tool_label') or last_scan_data.get('discovery_label'),
            'elevation_method': asset.elevation_method,
            'execution_mode': asset.execution_mode,
            'jea_endpoint': asset.jea_endpoint,
            'network_interfaces': [
                {
                    'name': ni.interface_name,
                    'ip_address': ni.ip_address,
                    'mac_address': ni.mac_address,
                    'gateway': ni.gateway,
                    'subnet_mask': ni.subnet_mask,
                    'dns_servers': ni.dns_servers,
                    'speed_mbps': ni.speed_mbps,
                    'status': ni.status,
                    'is_primary': ni.is_primary,
                }
                for ni in asset.network_interfaces
            ] if hasattr(asset, 'network_interfaces') else [],
            'storage': [
                {
                    'mount_point': s.mount_point,
                    'drive_letter': s.drive_letter,
                    'filesystem_type': s.filesystem_type,
                    'total_gb': s.total_size_gb,
                    'free_gb': s.free_space_gb,
                    'used_percent': s.used_percent,
                }
                for s in asset.storage
            ] if hasattr(asset, 'storage') else [],
            'software': [
                {
                    'name': sw.name,
                    'version': sw.version,
                    'publisher': sw.publisher,
                    'architecture': sw.architecture,
                    'package_type': sw.package_type,
                    'cpe_uri': sw.cpe_uri,
                }
                for sw in asset.software
            ] if hasattr(asset, 'software') else [],
            'services': [
                {
                    'name': svc.service_name,
                    'display_name': svc.display_name,
                    'status': svc.status,
                    'start_type': svc.start_type,
                    'account': svc.account,
                    'binary_path': svc.binary_path,
                }
                for svc in asset.services
            ] if hasattr(asset, 'services') else [],
            'pending_updates': [
                {
                    'package_name': pu.package_name,
                    'current_version': pu.current_version,
                    'available_version': pu.available_version,
                    'update_type': pu.update_type,
                    'severity': pu.severity,
                    'kb_number': pu.kb_number,
                }
                for pu in asset.pending_updates
            ] if hasattr(asset, 'pending_updates') else []
        })

        if include_raw:
            result['custom_attributes'] = asset.custom_attributes or {}

    return result
