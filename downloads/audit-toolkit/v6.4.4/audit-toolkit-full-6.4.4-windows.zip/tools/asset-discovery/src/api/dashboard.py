# Dashboard API Blueprint

import logging
from datetime import datetime, timedelta
from typing import Any, cast
from flask import Blueprint, jsonify
from sqlalchemy import func

from ..models.base import session_scope
from ..models.asset import Asset
from ..models.software import InstalledSoftware
from ..models.vulnerability import CVERecord, SoftwareVulnerability
from ..models.scan import ScanJob
from ..models.patch import PendingUpdate
from ..services.risk_policy import compute_risk_rating, compute_risk_score, route_priority
from ..security import rate_limit, safe_error_response, require_api_key

logger = logging.getLogger(__name__)
dashboard_bp = Blueprint('dashboard', __name__)
sql_func: Any = cast(Any, func)
@dashboard_bp.route('/summary', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_summary():
    """Get dashboard summary statistics."""
    try:
        with session_scope() as session:
            # Asset counts
            total_assets = session.query(Asset).count()
            active_assets = session.query(Asset).filter(Asset.status == 'active').count()

            # OS breakdown
            windows_count = session.query(Asset).filter(Asset.os_type == 'windows').count()
            linux_count = session.query(Asset).filter(Asset.os_type == 'linux').count()

            # Vulnerability summary
            total_vulns = session.query(SoftwareVulnerability).count()
            open_vulns = session.query(SoftwareVulnerability).filter(
                SoftwareVulnerability.status == 'open'
            ).count()
            critical_vulns = session.query(SoftwareVulnerability).join(CVERecord).filter(
                CVERecord.cvss_v3_severity == 'CRITICAL',
                SoftwareVulnerability.status == 'open'
            ).count()

            # KEV vulnerabilities
            kev_vulns = session.query(SoftwareVulnerability).join(CVERecord).filter(
                CVERecord.cisa_kev.is_(True),
                SoftwareVulnerability.status == 'open'
            ).count()

            # Pending updates
            pending_updates = session.query(PendingUpdate).count()

            # Recent scan activity
            recent_scans = session.query(ScanJob).filter(
                ScanJob.created_at >= datetime.utcnow() - timedelta(days=7)
            ).count()
            active_scans = session.query(ScanJob).filter(
                ScanJob.status == 'running'
            ).count()

            assets_block = {
                'total': total_assets,
                'active': active_assets,
                'by_os': {
                    'windows': windows_count,
                    'linux': linux_count,
                    'other': total_assets - windows_count - linux_count
                }
            }
            vulnerabilities_block = {
                'total': total_vulns,
                'open': open_vulns,
                'critical': critical_vulns,
                'kev': kev_vulns
            }
            patches_block = {
                'pending': pending_updates
            }
            scans_block = {
                'last_7_days': recent_scans,
                'active': active_scans,
            }

            return jsonify({
                'assets': assets_block,
                'vulnerabilities': vulnerabilities_block,
                'patches': patches_block,
                'scans': scans_block,
                'total_assets': assets_block['total'],
                'active_assets': assets_block['active'],
                'critical_vulnerabilities': vulnerabilities_block['critical'],
                'pending_updates': patches_block['pending'],
                'active_scans': scans_block['active'],
                'timestamp': datetime.utcnow().isoformat()
            })
    except Exception as e:
        return safe_error_response(e, 500)


@dashboard_bp.route('/risk-overview', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_risk_overview():
    """Get risk overview with severity distribution."""
    try:
        with session_scope() as session:
            severity_counts = {}
            for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
                count = session.query(SoftwareVulnerability).join(CVERecord).filter(
                    CVERecord.cvss_v3_severity == severity,
                    SoftwareVulnerability.status == 'open'
                ).count()
                severity_counts[severity.lower()] = count

            # Assets at risk (any open vulnerability)
            assets_at_risk = session.query(InstalledSoftware.asset_id).join(
                SoftwareVulnerability
            ).filter(
                SoftwareVulnerability.status == 'open'
            ).distinct().count()

            # Assets with critical vulns
            critical_assets = session.query(InstalledSoftware.asset_id).join(
                SoftwareVulnerability
            ).join(CVERecord).filter(
                CVERecord.cvss_v3_severity == 'CRITICAL',
                SoftwareVulnerability.status == 'open'
            ).distinct().count()

            vuln_rows = session.query(
                SoftwareVulnerability.asset_id,
                CVERecord.cvss_v3_severity,
                CVERecord.cisa_kev,
            ).join(
                CVERecord,
                SoftwareVulnerability.cve_id == CVERecord.cve_id,
            ).filter(
                SoftwareVulnerability.status == 'open'
            ).all()

            asset_rollups: dict[int, dict] = {}
            for asset_id, severity, is_kev in vuln_rows:
                rollup = asset_rollups.setdefault(asset_id, {
                    'critical': 0,
                    'high': 0,
                    'medium': 0,
                    'low': 0,
                    'kev': 0,
                })
                sev_key = str(severity or 'LOW').strip().lower()
                if sev_key not in {'critical', 'high', 'medium', 'low'}:
                    sev_key = 'low'
                rollup[sev_key] += 1
                if bool(is_kev):
                    rollup['kev'] += 1

            asset_ids = sorted(asset_rollups.keys())
            assets_by_id = {
                asset.id: asset
                for asset in session.query(Asset).filter(Asset.id.in_(asset_ids)).all()
            } if asset_ids else {}

            top_priority_assets: list[dict] = []
            route_summary = {
                'vulnerability_management_immediate': 0,
                'vulnerability_management_planned': 0,
            }

            for asset_id, counts in asset_rollups.items():
                asset = assets_by_id.get(asset_id)
                if asset is None:
                    continue

                risk_score = compute_risk_score(
                    critical=counts['critical'],
                    high=counts['high'],
                    medium=counts['medium'],
                    low=counts['low'],
                    kev=counts['kev'],
                )
                risk_rating = compute_risk_rating(
                    risk_score=risk_score,
                    kev_count=counts['kev'],
                    critical_count=counts['critical'],
                    high_count=counts['high'],
                )

                priority = route_priority('vulnerability_management', risk_rating)
                route_summary[f'vulnerability_management_{priority}'] += 1

                total = counts['critical'] + counts['high'] + counts['medium'] + counts['low']
                top_priority_assets.append({
                    'asset_id': asset.id,
                    'hostname': asset.hostname,
                    'primary_ip': asset.primary_ip,
                    'risk_rating': risk_rating,
                    'risk_score': risk_score,
                    'open_vulnerabilities': {
                        'total': total,
                        'critical': counts['critical'],
                        'high': counts['high'],
                        'medium': counts['medium'],
                        'low': counts['low'],
                        'kev': counts['kev'],
                    },
                    'vulnerability_details_url': f'/api/v1/vulnerabilities/assets/{asset.id}?status=open',
                })

            top_priority_assets.sort(
                key=lambda item: (
                    0 if item['risk_rating'] == 'critical' else 1 if item['risk_rating'] == 'high' else 2,
                    -int(item['risk_score']),
                    str(item.get('hostname') or ''),
                )
            )
            top_priority_assets = top_priority_assets[:10]

            return jsonify({
                'severity_distribution': severity_counts,
                'assets_at_risk': {
                    'total': assets_at_risk,
                    'critical': critical_assets
                },
                'top_priority_assets': top_priority_assets,
                'compliance_routing': route_summary,
            })
    except Exception as e:
        return safe_error_response(e, 500)


@dashboard_bp.route('/recent-activity', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_recent_activity():
    """Get recent discovery and scan activity."""
    try:
        with session_scope() as session:
            # Recent scans
            recent_scans = session.query(ScanJob).order_by(
                ScanJob.created_at.desc()
            ).limit(10).all()

            # Recently discovered assets
            recent_assets = session.query(Asset).order_by(
                Asset.first_seen.desc()
            ).limit(10).all()

            # Recent vulnerabilities found
            recent_vulns = session.query(SoftwareVulnerability).order_by(
                SoftwareVulnerability.detected_at.desc()
            ).limit(10).all()

            return jsonify({
                'recent_scans': [
                    {
                        'id': s.id,
                        'type': s.job_type,
                        'status': s.status,
                        'total_targets': s.total_targets,
                        'created_at': s.created_at.isoformat() if s.created_at else None
                    }
                    for s in recent_scans
                ],
                'recent_assets': [
                    {
                        'id': a.id,
                        'hostname': a.hostname,
                        'os_type': a.os_type,
                        'discovered_at': a.first_seen.isoformat() if a.first_seen else None
                    }
                    for a in recent_assets
                ],
                'recent_vulnerabilities': [
                    {
                        'cve_id': v.cve_id,
                        'software_id': v.software_id,
                        'detected_at': v.detected_at.isoformat() if v.detected_at else None
                    }
                    for v in recent_vulns
                ]
            })
    except Exception as e:
        return safe_error_response(e, 500)


@dashboard_bp.route('/top-vulnerabilities', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_top_vulnerabilities():
    """Get top vulnerabilities by occurrence."""
    try:
        with session_scope() as session:
            # Optimized: Single query with JOIN to avoid N+1 problem
            top_vulns = session.query(
                CVERecord.cve_id,
                CVERecord.cvss_v3_severity,
                CVERecord.cvss_v3_score,
                CVERecord.cisa_kev,
                CVERecord.description,
                sql_func.count(SoftwareVulnerability.id).label('affected_count')
            ).join(
                SoftwareVulnerability, SoftwareVulnerability.cve_id == CVERecord.cve_id
            ).filter(
                SoftwareVulnerability.status == 'open'
            ).group_by(
                CVERecord.cve_id,
                CVERecord.cvss_v3_severity,
                CVERecord.cvss_v3_score,
                CVERecord.cisa_kev,
                CVERecord.description
            ).order_by(
                sql_func.count(SoftwareVulnerability.id).desc()
            ).limit(10).all()

            result = []
            for row in top_vulns:
                desc = str(row.description) if row.description else ''
                result.append({
                    'cve_id': row.cve_id,
                    'severity': row.cvss_v3_severity,
                    'cvss_score': float(row.cvss_v3_score) if row.cvss_v3_score else None,
                    'is_kev': bool(row.cisa_kev),
                    'affected_assets': row.affected_count,  # Frontend expects 'affected_assets'
                    'description': desc[:150] + '...' if len(desc) > 150 else desc
                })

            return jsonify({'vulnerabilities': result})
    except Exception as e:
        return safe_error_response(e, 500)


@dashboard_bp.route('/compliance-status', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_compliance_status():
    """Get compliance status overview."""
    try:
        with session_scope() as session:
            total_assets = session.query(Asset).filter(Asset.status == 'active').count()

            if total_assets == 0:
                return jsonify({
                    'total_assets': 0,
                    'scan_coverage': {'scanned_last_30_days': 0, 'percentage': 0},
                    'vulnerability_status': {'clean_assets': 0, 'percentage': 0},
                    'kev_compliance': {'compliant_assets': 0, 'percentage': 0}
                })

            # Assets scanned in last 30 days
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            recently_scanned = session.query(Asset).filter(
                Asset.last_seen >= thirty_days_ago
            ).count()

            # Assets with open vulnerabilities
            vulnerable_asset_ids = session.query(InstalledSoftware.asset_id).join(
                SoftwareVulnerability
            ).filter(
                SoftwareVulnerability.status == 'open'
            ).distinct()

            clean_assets = total_assets - vulnerable_asset_ids.count()

            # KEV compliance (no open KEV vulnerabilities)
            kev_affected = session.query(InstalledSoftware.asset_id).join(
                SoftwareVulnerability
            ).join(CVERecord).filter(
                CVERecord.cisa_kev.is_(True),
                SoftwareVulnerability.status == 'open'
            ).distinct().count()

            kev_compliant = total_assets - kev_affected

            return jsonify({
                'total_assets': total_assets,
                'scan_coverage': {
                    'scanned_last_30_days': recently_scanned,
                    'percentage': round((recently_scanned / total_assets * 100), 1)
                },
                'vulnerability_status': {
                    'clean_assets': clean_assets,
                    'percentage': round((clean_assets / total_assets * 100), 1)
                },
                'kev_compliance': {
                    'compliant_assets': kev_compliant,
                    'percentage': round((kev_compliant / total_assets * 100), 1)
                }
            })
    except Exception as e:
        return safe_error_response(e, 500)
