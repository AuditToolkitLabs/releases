# Scans API Blueprint

import logging
from collections import defaultdict
from datetime import datetime
from html import escape as html_escape
import ipaddress
import uuid
from flask import Blueprint, Response, jsonify, request
from sqlalchemy import func

from ..models.base import session_scope
from ..models.scan import ScanJob, ScanResult, ScanCredential
from ..models.asset import Asset
from ..models.software import InstalledSoftware
from ..models.patch import PendingUpdate
from ..models.vulnerability import CVERecord, SoftwareVulnerability
from ..security import (
    validate_pagination, sanitize_string, validate_targets,
    rate_limit, audit_log, safe_error_response, validate_json_request,
    MAX_PAGE_SIZE, MAX_TARGETS_COUNT, require_api_key,
    validate_scan_target_ssrf
)
from ..services.remote_executor import NMAP_AVAILABLE, PortScanExecutor
from ..services.risk_policy import (
    RISK_RATING_ORDER,
    compute_risk_rating,
    compute_risk_score,
    route_priority,
)

logger = logging.getLogger(__name__)
scans_bp = Blueprint('scans', __name__)

CORRELATION_STATUSES = {'queued', 'in_progress', 'completed', 'failed', 'not_requested'}
POSTURE_STATUSES = {'queued', 'in_progress', 'completed', 'failed', 'not_requested'}
VALID_SCAN_PROFILES = {'fast', 'standard', 'deep'}
RISK_STATUSES = {'queued', 'in_progress', 'completed', 'failed'}
EXTERNALLY_EXPOSED_PORTS = {
    20, 21, 22, 23, 25, 53, 80, 110, 123, 135, 139, 143, 161, 389, 443, 445,
    465, 514, 587, 636, 993, 995, 1433, 1521, 2049, 2375, 3306, 3389, 5432,
    5900, 5985, 5986, 6379, 8080, 8443, 9200,
}
SEVERITY_ORDER = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}


def _normalize_discovery_method(raw_method: str, fallback: str = 'port_scan') -> str:
    method = sanitize_string(raw_method or '', max_length=50).lower()
    aliases = {'fleet-agent': 'managed', 'fleet_agent': 'managed', 'api': 'agent'}
    method = aliases.get(method, method)
    valid_methods = {'port_scan', 'ssh', 'winrm', 'agent', 'managed'}
    return method if method in valid_methods else fallback


def _expand_range_targets(raw_targets: list) -> list[str]:
    """Expand start-end IPv4 ranges into individual targets for validation."""
    expanded, _ = _expand_range_targets_with_metadata(raw_targets)
    return expanded


def _expand_range_targets_with_metadata(raw_targets: list) -> tuple[list[str], dict]:
    """Expand start-end IPv4 ranges and return coverage metadata."""
    expanded: list[str] = []
    total_candidates = 0
    truncation_events: list[dict] = []

    for raw_target in raw_targets:
        target = str(raw_target).strip()
        if not target:
            continue

        if '-' not in target:
            expanded.append(target)
            total_candidates += 1
            continue

        start_str, end_str = (part.strip() for part in target.split('-', 1))
        try:
            start_ip = ipaddress.ip_address(start_str)
            end_ip = ipaddress.ip_address(end_str)
        except ValueError:
            expanded.append(target)
            continue

        if start_ip.version != 4 or end_ip.version != 4:
            expanded.append(target)
            continue

        start_int = int(start_ip)
        end_int = int(end_ip)
        if end_int < start_int:
            expanded.append(target)
            total_candidates += 1
            continue

        range_size = end_int - start_int + 1
        total_candidates += range_size
        max_remaining = max(MAX_TARGETS_COUNT - len(expanded), 0)
        expanded_count = min(range_size, max_remaining)
        for offset in range(expanded_count):
            expanded.append(str(ipaddress.ip_address(start_int + offset)))

        if expanded_count < range_size:
            truncation_events.append({
                'target': target,
                'requested': range_size,
                'included': expanded_count,
            })

        if len(expanded) >= MAX_TARGETS_COUNT:
            break

    metadata = {
        'input_targets_count': len(raw_targets),
        'expanded_candidates_count': total_candidates,
        'expanded_targets_count': len(expanded),
        'max_targets_count': MAX_TARGETS_COUNT,
        'truncated': bool(truncation_events),
        'truncation_events': truncation_events,
    }

    return expanded, metadata


def _normalize_scan_profile(raw_profile: str) -> str:
    profile = sanitize_string(raw_profile or 'standard', max_length=20).lower()
    return profile if profile in VALID_SCAN_PROFILES else 'standard'


def _normalize_scan_overrides(raw_overrides) -> dict:
    if not isinstance(raw_overrides, dict):
        return {}

    normalized: dict = {}
    ports = raw_overrides.get('ports')
    if isinstance(ports, list):
        cleaned_ports: list[int] = []
        for value in ports:
            try:
                port = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= port <= 65535 and port not in cleaned_ports:
                cleaned_ports.append(port)
        if cleaned_ports:
            normalized['ports'] = cleaned_ports[:128]

    probe_ports = raw_overrides.get('reachability_probe_ports')
    if isinstance(probe_ports, list):
        cleaned_probe_ports: list[int] = []
        for value in probe_ports:
            try:
                port = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= port <= 65535 and port not in cleaned_probe_ports:
                cleaned_probe_ports.append(port)
        if cleaned_probe_ports:
            normalized['reachability_probe_ports'] = cleaned_probe_ports[:32]

    for key in ('connect_timeout_seconds', 'max_concurrent_targets'):
        if key in raw_overrides:
            try:
                value = int(raw_overrides.get(key))
            except (TypeError, ValueError):
                continue
            if value > 0:
                normalized[key] = value

    return normalized


# Profile port lists used for tradeoff estimation; mirrors PortScanExecutor._scan_profiles
_PROFILE_PORTS = {
    'fast': [22, 80, 443],
    'standard': [22, 80, 443, 445, 3389, 5985, 5986],
    'deep': [21, 22, 25, 53, 80, 110, 123, 135, 139, 143, 161, 389, 443, 445,
             465, 514, 587, 636, 993, 995, 1433, 1521, 2049, 2375, 3306, 3389,
             5432, 5900, 5985, 5986, 6379, 8080, 8443, 9200],
}
_PROFILE_TIMEOUT = {'fast': 1, 'standard': 2, 'deep': 2}


def _build_engine_tradeoff(scan_profile: str, scan_overrides: dict, target_count: int) -> dict:
    """Return scan engine tradeoff metadata for inclusion in the create-scan API response.

    This lets callers understand *before* the scan runs what engine will be used
    and roughly how long the scan will take, so they can make informed profile choices.
    """
    effective_profile = {
        'name': scan_profile,
        'ports': scan_overrides.get('ports', _PROFILE_PORTS.get(scan_profile, _PROFILE_PORTS['standard'])),
        'connect_timeout_seconds': scan_overrides.get('connect_timeout_seconds', _PROFILE_TIMEOUT.get(scan_profile, 2)),
    }
    engine = PortScanExecutor._engine_for_profile(effective_profile)
    est = PortScanExecutor._scan_duration_estimate_seconds(effective_profile, target_count=target_count)

    return {
        'engine': engine,
        'nmap_available': NMAP_AVAILABLE,
        'estimated_duration_seconds': est,
        'profile': scan_profile,
        'port_count': len(effective_profile['ports']),
        'target_count': target_count,
    }


def _build_correlation_payload(scan: ScanJob) -> dict:
    """Build deterministic vulnerability correlation status payload for scan responses."""
    config = scan.config if isinstance(scan.config, dict) else {}
    scope = config.get('scope') if isinstance(config.get('scope'), dict) else {}
    requested = bool(config.get('auto_vulnerability_rematch', True)) and bool(scope.get('packages', True))

    existing = config.get('vulnerability_correlation')
    payload = dict(existing) if isinstance(existing, dict) else {}

    payload.setdefault('requested', requested)
    payload.setdefault('source', 'scan')
    payload.setdefault('status', 'queued' if payload.get('requested') else 'not_requested')

    if payload.get('status') not in CORRELATION_STATUSES:
        payload['status'] = 'queued' if payload.get('requested') else 'not_requested'

    if scan.status in {'failed', 'cancelled'} and payload.get('status') in {'queued', 'in_progress'}:
        payload['status'] = 'failed'
        payload.setdefault('error', 'scan_terminated_before_correlation')

    if scan.status == 'completed' and payload.get('requested') and payload.get('status') == 'queued':
        payload['status'] = 'completed'
        payload.setdefault('reason', 'no_assets_eligible')

    return payload


def _build_posture_payload(scan: ScanJob) -> dict:
    """Build deterministic posture evaluation status payload for scan responses."""
    config = scan.config if isinstance(scan.config, dict) else {}
    requested = bool(config.get('posture_evaluation_enabled', True))

    existing = config.get('posture_evaluation')
    payload = dict(existing) if isinstance(existing, dict) else {}

    payload.setdefault('requested', requested)
    payload.setdefault('source', 'posture_evaluator_v1')
    payload.setdefault('status', 'queued' if payload.get('requested') else 'not_requested')

    if payload.get('status') not in POSTURE_STATUSES:
        payload['status'] = 'queued' if payload.get('requested') else 'not_requested'

    if scan.status in {'failed', 'cancelled'} and payload.get('status') in {'queued', 'in_progress'}:
        payload['status'] = 'failed'
        payload.setdefault('error', 'scan_terminated_before_posture_evaluation')

    if scan.status == 'completed' and payload.get('requested') and payload.get('status') == 'queued':
        payload['status'] = 'completed'
        payload.setdefault('reason', 'completed_without_summary')
        payload.setdefault('summary', {
            'assets_evaluated': 0,
            'checks_total': 0,
            'pass': 0,  # nosec B105 - posture metric key, not a credential
            'warn': 0,
            'fail': 0,
            'errors': [],
        })

    return payload


def _empty_risk_prioritization(scan: ScanJob) -> dict:
    status = 'completed'
    if scan.status in {'pending'}:
        status = 'queued'
    elif scan.status in {'running'}:
        status = 'in_progress'
    elif scan.status in {'failed', 'cancelled'}:
        status = 'failed'

    return {
        'requested': True,
        'status': status if status in RISK_STATUSES else 'completed',
        'summary': {
            'assets_evaluated': 0,
            'assets_with_open_vulnerabilities': 0,
            'assets_with_external_exposure': 0,
            'assets_with_posture_findings': 0,
            'critical_assets': 0,
            'high_assets': 0,
            'kev_assets': 0,
            'top_priority_count': 0,
        },
        'top_priorities': [],
        'compliance_routes': [],
    }


def _extract_open_port_numbers(raw_output: dict) -> list[int]:
    if not isinstance(raw_output, dict):
        return []

    ports = raw_output.get('ports')
    if not isinstance(ports, list):
        ports = []

    normalized: list[int] = []
    for entry in ports:
        if isinstance(entry, dict):
            value = entry.get('port') or entry.get('local_port')
        else:
            value = entry
        try:
            port = int(value)
        except (TypeError, ValueError):
            continue
        if 1 <= port <= 65535 and port not in normalized:
            normalized.append(port)
    return normalized


def _extract_posture_findings(raw_output: dict) -> list[dict]:
    if not isinstance(raw_output, dict):
        return []

    posture_eval = raw_output.get('posture_evaluation')
    if not isinstance(posture_eval, dict):
        return []

    findings = posture_eval.get('findings')
    return findings if isinstance(findings, list) else []


def _vulnerability_rollups_by_asset(session, asset_ids: list[int]) -> dict[int, dict]:
    if not asset_ids:
        return {}

    rows = session.query(
        SoftwareVulnerability.asset_id,
        CVERecord.cve_id,
        CVERecord.cvss_v3_score,
        CVERecord.cvss_v3_severity,
        CVERecord.cisa_kev,
    ).join(
        CVERecord,
        SoftwareVulnerability.cve_id == CVERecord.cve_id,
    ).filter(
        SoftwareVulnerability.asset_id.in_(asset_ids),
        SoftwareVulnerability.status == 'open',
    ).all()

    rollups: dict[int, dict] = {}
    for asset_id, cve_id, cvss_score, severity, is_kev in rows:
        summary = rollups.setdefault(asset_id, {
            'total': 0,
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'kev': 0,
            'top_cves': [],
        })
        severity_key = str(severity or 'LOW').strip().lower()
        if severity_key not in {'critical', 'high', 'medium', 'low'}:
            severity_key = 'low'

        summary['total'] += 1
        summary[severity_key] += 1
        if bool(is_kev):
            summary['kev'] += 1
        summary['top_cves'].append({
            'cve_id': cve_id,
            'severity': severity_key,
            'cvss_score': float(cvss_score) if cvss_score is not None else 0.0,
            'is_kev': bool(is_kev),
        })

    for summary in rollups.values():
        summary['top_cves'].sort(
            key=lambda item: (
                0 if item.get('is_kev') else 1,
                SEVERITY_ORDER.get(str(item.get('severity')), 99),
                -float(item.get('cvss_score') or 0.0),
                str(item.get('cve_id') or ''),
            )
        )
        summary['top_cves'] = summary['top_cves'][:3]

    return rollups


def _build_scan_risk_prioritization(scan: ScanJob, results: list[ScanResult], session=None) -> dict:
    payload = _empty_risk_prioritization(scan)
    if not results:
        return payload

    asset_ids = sorted({int(result.asset_id) for result in results if result.asset_id is not None})
    vuln_rollups = _vulnerability_rollups_by_asset(session, asset_ids) if session is not None else {}

    top_priorities: list[dict] = []
    route_counts: dict[str, int] = defaultdict(int)

    for result in results:
        raw_output = result.raw_output if isinstance(result.raw_output, dict) else {}
        posture_findings = _extract_posture_findings(raw_output)
        posture_failures = [finding for finding in posture_findings if isinstance(finding, dict) and str(finding.get('status') or '').lower() == 'fail']
        posture_warns = [finding for finding in posture_findings if isinstance(finding, dict) and str(finding.get('status') or '').lower() == 'warn']
        open_ports = _extract_open_port_numbers(raw_output)
        exposed_ports = [port for port in open_ports if port in EXTERNALLY_EXPOSED_PORTS]
        externally_exposed = bool(exposed_ports)

        vuln_summary = vuln_rollups.get(int(result.asset_id), {
            'total': 0,
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'kev': 0,
            'top_cves': [],
        }) if result.asset_id is not None else {
            'total': 0,
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'kev': 0,
            'top_cves': [],
        }

        risk_score = compute_risk_score(
            critical=vuln_summary['critical'],
            high=vuln_summary['high'],
            medium=vuln_summary['medium'],
            low=vuln_summary['low'],
            kev=vuln_summary['kev'],
            externally_exposed=externally_exposed,
            posture_failures=len(posture_failures),
            posture_warns=len(posture_warns),
        )
        risk_rating = compute_risk_rating(
            risk_score=risk_score,
            kev_count=vuln_summary['kev'],
            critical_count=vuln_summary['critical'],
            high_count=vuln_summary['high'],
            externally_exposed=externally_exposed,
            posture_failures=len(posture_failures),
        )

        reasons: list[str] = []
        if vuln_summary['kev']:
            reasons.append(f"{vuln_summary['kev']} known exploited vulnerabilities")
        if vuln_summary['critical']:
            reasons.append(f"{vuln_summary['critical']} critical CVEs")
        if vuln_summary['high']:
            reasons.append(f"{vuln_summary['high']} high CVEs")
        if externally_exposed:
            reasons.append(f"externally exposed ports: {', '.join(str(port) for port in exposed_ports[:5])}")
        if posture_failures:
            reasons.append(f"{len(posture_failures)} failing posture controls")
        if not reasons and posture_warns:
            reasons.append(f"{len(posture_warns)} warning-level posture findings")

        compliance_routes: list[dict] = []
        if vuln_summary['total']:
            priority = route_priority(
                'vulnerability_management',
                risk_rating,
                force_immediate=bool(vuln_summary['kev'] or vuln_summary['critical']),
            )
            compliance_routes.append({'route': 'vulnerability_management', 'priority': priority})
            route_counts['vulnerability_management'] += 1
        if externally_exposed:
            network_priority = route_priority('network_exposure_review', risk_rating)
            compliance_routes.append({'route': 'network_exposure_review', 'priority': network_priority})
            route_counts['network_exposure_review'] += 1
        if posture_failures or posture_warns:
            baseline_priority = route_priority('baseline_compliance', risk_rating)
            compliance_routes.append({'route': 'baseline_compliance', 'priority': baseline_priority})
            route_counts['baseline_compliance'] += 1

        if risk_rating != 'low' or reasons:
            top_priorities.append({
                'asset_id': result.asset_id,
                'target': result.target,
                'hostname': raw_output.get('hostname') or raw_output.get('system', {}).get('hostname') or result.target,
                'risk_rating': risk_rating,
                'risk_score': risk_score,
                'open_vulnerability_summary': {
                    'total': vuln_summary['total'],
                    'critical': vuln_summary['critical'],
                    'high': vuln_summary['high'],
                    'medium': vuln_summary['medium'],
                    'low': vuln_summary['low'],
                    'kev': vuln_summary['kev'],
                },
                'exposure_summary': {
                    'externally_exposed': externally_exposed,
                    'exposed_ports': exposed_ports,
                },
                'posture_summary': {
                    'fail': len(posture_failures),
                    'warn': len(posture_warns),
                },
                'top_cves': vuln_summary['top_cves'],
                'reasons': reasons,
                'compliance_routes': compliance_routes,
                'vulnerability_details_url': f"/api/v1/vulnerabilities/assets/{result.asset_id}?status=open" if result.asset_id is not None else None,
            })

    top_priorities.sort(
        key=lambda item: (
            RISK_RATING_ORDER.get(str(item.get('risk_rating') or '').lower(), 99),
            -int(item.get('risk_score') or 0),
            str(item.get('hostname') or item.get('target') or ''),
        )
    )
    top_priorities = top_priorities[:5]

    payload['status'] = 'completed' if scan.status not in {'pending', 'running'} else payload['status']
    payload['summary'] = {
        'assets_evaluated': len(results),
        'assets_with_open_vulnerabilities': sum(1 for item in top_priorities if item['open_vulnerability_summary']['total'] > 0),
        'assets_with_external_exposure': sum(1 for item in top_priorities if item['exposure_summary']['externally_exposed']),
        'assets_with_posture_findings': sum(1 for item in top_priorities if item['posture_summary']['fail'] > 0 or item['posture_summary']['warn'] > 0),
        'critical_assets': sum(1 for item in top_priorities if item['risk_rating'] == 'critical'),
        'high_assets': sum(1 for item in top_priorities if item['risk_rating'] == 'high'),
        'kev_assets': sum(1 for item in top_priorities if item['open_vulnerability_summary']['kev'] > 0),
        'top_priority_count': len(top_priorities),
    }
    payload['top_priorities'] = top_priorities
    payload['compliance_routes'] = [
        {
            'route': route,
            'asset_count': count,
        }
        for route, count in sorted(route_counts.items(), key=lambda item: (-item[1], item[0]))
    ]
    return payload


def _build_scan_software_update_report(
    scan: ScanJob,
    assets: list[Asset],
    session,
    host_filter: str = '',
    software_filter: str = '',
) -> dict:
    """Build software/update report payload scoped to assets discovered by a scan."""
    asset_ids = [asset.id for asset in assets]
    software_count_rows = session.query(
        InstalledSoftware.asset_id,
        func.count(InstalledSoftware.id)
    ).filter(
        InstalledSoftware.asset_id.in_(asset_ids)
    ).group_by(InstalledSoftware.asset_id).all() if asset_ids else []
    software_counts = {asset_id: int(count or 0) for asset_id, count in software_count_rows}

    installed_rows = session.query(
        InstalledSoftware.asset_id,
        InstalledSoftware.name,
        InstalledSoftware.version,
    ).filter(
        InstalledSoftware.asset_id.in_(asset_ids)
    ).all() if asset_ids else []
    installed_by_asset: dict[int, list[dict]] = defaultdict(list)
    for asset_id, name, version in installed_rows:
        installed_by_asset[int(asset_id)].append({
            'software_name': name,
            'current_version': version,
        })

    pending_rows = session.query(PendingUpdate).filter(
        PendingUpdate.asset_id.in_(asset_ids)
    ).all() if asset_ids else []
    pending_by_asset: dict[int, list[dict]] = defaultdict(list)
    for pending in pending_rows:
        pending_by_asset[int(pending.asset_id)].append({
            'package_name': pending.package_name,
            'current_version': pending.current_version,
            'available_version': pending.available_version,
            'update_type': pending.update_type,
            'severity': pending.severity,
            'kb_number': pending.kb_number,
        })

    vulnerability_rows = session.query(
        SoftwareVulnerability.asset_id,
        InstalledSoftware.name,
        InstalledSoftware.version,
        SoftwareVulnerability.cve_id,
    ).join(
        InstalledSoftware,
        InstalledSoftware.id == SoftwareVulnerability.software_id,
    ).filter(
        SoftwareVulnerability.asset_id.in_(asset_ids),
        SoftwareVulnerability.status == 'open',
    ).all() if asset_ids else []

    vulnerable_packages_by_asset: dict[int, dict[tuple[str, str], set[str]]] = defaultdict(lambda: defaultdict(set))
    for asset_id, software_name, software_version, cve_id in vulnerability_rows:
        package_key = (software_name or 'unknown', software_version or '')
        vulnerable_packages_by_asset[int(asset_id)][package_key].add(cve_id)

    assets_report = []
    os_breakdown: dict[str, int] = defaultdict(int)
    assets_with_pending_updates = 0
    assets_with_vulnerable_software = 0
    total_pending_updates = 0
    total_vulnerable_packages = 0
    total_open_cves = 0
    software_table_rows: list[dict] = []

    normalized_host_filter = (host_filter or '').strip().lower()
    normalized_software_filter = (software_filter or '').strip().lower()

    for asset in sorted(assets, key=lambda item: ((item.hostname or '').lower(), item.id)):
        host_match_text = ' '.join([
            str(asset.hostname or ''),
            str(asset.fqdn or ''),
            str(asset.primary_ip or ''),
        ]).lower()
        if normalized_host_filter and normalized_host_filter not in host_match_text:
            continue

        pending_updates = pending_by_asset.get(asset.id, [])
        vulnerable_package_rows = []
        for (software_name, software_version), cve_ids in vulnerable_packages_by_asset.get(asset.id, {}).items():
            sorted_cves = sorted(cve for cve in cve_ids if cve)
            vulnerable_package_rows.append({
                'software_name': software_name,
                'software_version': software_version,
                'open_cve_count': len(sorted_cves),
                'sample_cves': sorted_cves[:5],
            })
        vulnerable_package_rows.sort(key=lambda item: item['open_cve_count'], reverse=True)

        if normalized_software_filter:
            pending_updates = [
                update for update in pending_updates
                if normalized_software_filter in str(update.get('package_name') or '').lower()
            ]
            vulnerable_package_rows = [
                package for package in vulnerable_package_rows
                if normalized_software_filter in str(package.get('software_name') or '').lower()
            ]
            if not pending_updates and not vulnerable_package_rows:
                continue

        pending_count = len(pending_updates)
        vulnerable_package_count = len(vulnerable_package_rows)
        open_cve_count = sum(item['open_cve_count'] for item in vulnerable_package_rows)

        installed_software = installed_by_asset.get(asset.id, [])
        pending_lookup = {
            str(update.get('package_name') or '').strip().lower(): update
            for update in pending_updates
            if str(update.get('package_name') or '').strip()
        }
        installed_names = set()

        for installed in installed_software:
            software_name = str(installed.get('software_name') or '').strip()
            if not software_name:
                continue

            if normalized_software_filter and normalized_software_filter not in software_name.lower():
                continue

            installed_names.add(software_name.lower())
            present_version = str(installed.get('current_version') or '').strip()
            pending_match = pending_lookup.get(software_name.lower())

            latest_version = str(
                (pending_match or {}).get('available_version')
                or (pending_match or {}).get('current_version')
                or present_version
                or '-'
            ).strip()
            update_available = bool(
                pending_match
                and latest_version
                and latest_version != '-'
                and latest_version != (present_version or latest_version)
            )

            software_table_rows.append({
                'asset_id': asset.id,
                'hostname': asset.hostname,
                'primary_ip': asset.primary_ip,
                'software_loaded': software_name,
                'present_version': present_version or '-',
                'update_available': 'Yes' if update_available else 'No',
                'latest_version': latest_version,
            })

        for pending in pending_updates:
            package_name = str(pending.get('package_name') or '').strip()
            if not package_name:
                continue
            if package_name.lower() in installed_names:
                continue
            if normalized_software_filter and normalized_software_filter not in package_name.lower():
                continue

            software_table_rows.append({
                'asset_id': asset.id,
                'hostname': asset.hostname,
                'primary_ip': asset.primary_ip,
                'software_loaded': package_name,
                'present_version': str(pending.get('current_version') or '-').strip() or '-',
                'update_available': 'Yes',
                'latest_version': str(pending.get('available_version') or '-').strip() or '-',
            })

        if pending_count > 0:
            assets_with_pending_updates += 1
        if vulnerable_package_count > 0:
            assets_with_vulnerable_software += 1

        total_pending_updates += pending_count
        total_vulnerable_packages += vulnerable_package_count
        total_open_cves += open_cve_count
        os_breakdown[(asset.os_type or 'unknown').lower()] += 1

        assets_report.append({
            'asset_id': asset.id,
            'hostname': asset.hostname,
            'primary_ip': asset.primary_ip,
            'os_type': asset.os_type,
            'os_name': asset.os_name,
            'software_inventory_count': software_counts.get(asset.id, 0),
            'pending_updates_count': pending_count,
            'vulnerable_software_count': vulnerable_package_count,
            'open_cve_count': open_cve_count,
            'pending_updates': pending_updates,
            'vulnerable_software': vulnerable_package_rows,
        })

    return {
        'scan_id': scan.id,
        'scan_status': scan.status,
        'generated_at': datetime.utcnow().isoformat(),
        'applied_filters': {
            'host': host_filter or '',
            'software': software_filter or '',
        },
        'assets_in_report': len(assets_report),
        'software_table_rows': software_table_rows,
        'software_table_row_count': len(software_table_rows),
        'summary': {
            'assets_with_pending_updates': assets_with_pending_updates,
            'total_pending_updates': total_pending_updates,
            'assets_with_vulnerable_software': assets_with_vulnerable_software,
            'total_vulnerable_packages': total_vulnerable_packages,
            'total_open_cves': total_open_cves,
            'assets_by_os_type': dict(sorted(os_breakdown.items())),
        },
        'assets': assets_report,
    }


def _scan_software_report_to_html(report: dict) -> str:
    """Render scan software/update report as a simple HTML document for GUI link opening."""
    summary = report.get('summary') or {}
    software_rows = report.get('software_table_rows') or []
    applied_filters = report.get('applied_filters') if isinstance(report.get('applied_filters'), dict) else {}

    summary_html = f"""
    <ul>
    <li><strong>Assets in report:</strong> {report.get('assets_in_report', 0)}</li>
    <li><strong>Software rows:</strong> {report.get('software_table_row_count', 0)}</li>
      <li><strong>Assets with pending package updates:</strong> {summary.get('assets_with_pending_updates', 0)}</li>
      <li><strong>Total pending package updates:</strong> {summary.get('total_pending_updates', 0)}</li>
      <li><strong>Assets with vulnerable software:</strong> {summary.get('assets_with_vulnerable_software', 0)}</li>
      <li><strong>Total vulnerable packages:</strong> {summary.get('total_vulnerable_packages', 0)}</li>
      <li><strong>Total open CVEs:</strong> {summary.get('total_open_cves', 0)}</li>
    </ul>
    """

    rows_html = []
    for row in software_rows:
        host_label = f"{row.get('hostname') or ''} {row.get('primary_ip') or ''}".strip()
        software_label = str(row.get('software_loaded') or '').strip()
        update_value = str(row.get('update_available') or 'No')
        rows_html.append(
            f"<tr class=\"scan-software-row\" "
            f"data-host=\"{html_escape(host_label.lower())}\" "
            f"data-software=\"{html_escape(software_label.lower())}\" "
            f"data-update=\"{html_escape(update_value.lower())}\" "
            f"data-present-version=\"{html_escape(str(row.get('present_version') or '-').lower())}\" "
            f"data-latest-version=\"{html_escape(str(row.get('latest_version') or '-').lower())}\">"
            f"<td>{html_escape(str(row.get('hostname') or '-'))}</td>"
            f"<td>{html_escape(str(row.get('primary_ip') or '-'))}</td>"
            f"<td>{html_escape(software_label or '-')}</td>"
            f"<td>{html_escape(str(row.get('present_version') or '-'))}</td>"
            f"<td>{html_escape(update_value)}</td>"
            f"<td>{html_escape(str(row.get('latest_version') or '-'))}</td>"
            '</tr>'
        )

    no_assets_row = '<tr><td colspan="6">No software rows found for this scan and filter selection.</td></tr>'
    table_body = ''.join(rows_html) if rows_html else no_assets_row

    table_html = (
        '<div style="margin: 8px 0 10px; display: flex; gap: 10px; align-items: center;">'
        '<label><strong>Sort:</strong> <select id="sortBy" style="padding: 4px;">'
        '<option value="software-asc">Software (A-Z)</option><option value="software-desc">Software (Z-A)</option>'
        '<option value="host-asc">Host (A-Z)</option><option value="host-desc">Host (Z-A)</option>'
        '<option value="update-desc">Updates First</option><option value="update-asc">No Updates First</option>'
        '</select></label>'
        '<button id="clearFilters" type="button" style="padding: 4px 10px;">Clear Filters</button>'
        '</div>'
        '<table id="scan-software-table" border="1" cellspacing="0" cellpadding="6" style="border-collapse: collapse; width: 100%;">'
        '<thead>'
        '<tr>'
        '<th>Hostname</th><th>IP</th><th>Software Loaded</th><th>Present Version</th><th>Update Available</th><th>Latest Version</th>'
        '</tr>'
        '<tr>'
        '<th><input id="hostSearch" type="text" placeholder="filter host" style="width: 98%; padding: 4px;"></th>'
        '<th></th>'
        '<th><input id="softwareSearch" type="text" placeholder="filter software" style="width: 98%; padding: 4px;"></th>'
        '<th></th>'
        '<th><select id="updateFilter" style="width: 98%; padding: 4px;"><option value="all">All</option><option value="yes">Yes</option><option value="no">No</option></select></th>'
        '<th></th>'
        '</tr>'
        '</thead>'
        f"<tbody>{table_body}</tbody>"
        '</table>'
    )

    host_filter_label = html_escape(str(applied_filters.get('host') or ''))
    software_filter_label = html_escape(str(applied_filters.get('software') or ''))
    filter_summary = (
        f"<p><strong>Applied Filters:</strong> host='{host_filter_label or '*'}', software='{software_filter_label or '*'}'</p>"
    )

    search_controls = """
    <div id="rowCount" style="margin: 10px 0; color:#444;"></div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const hostInput = document.getElementById('hostSearch');
            const softwareInput = document.getElementById('softwareSearch');
            const updateFilter = document.getElementById('updateFilter');
            const sortBy = document.getElementById('sortBy');
            const clearFilters = document.getElementById('clearFilters');
            const rowCount = document.getElementById('rowCount');
            const tableBody = document.querySelector('#scan-software-table tbody');

            if (!hostInput || !softwareInput || !updateFilter || !sortBy || !clearFilters || !rowCount || !tableBody) {
                return;
            }

            const rows = Array.from(tableBody.querySelectorAll('tr.scan-software-row'));

            const textValue = (row, attr) => String(row.getAttribute(attr) || '').toLowerCase();
            const updateRank = (value) => value === 'yes' ? 1 : 0;
            const urlParams = new URLSearchParams(window.location.search);

            const presetHost = (urlParams.get('host') || '').trim();
            const presetSoftware = (urlParams.get('software') || '').trim();
            const presetUpdate = (urlParams.get('update') || 'all').toLowerCase().trim();
            const presetSort = (urlParams.get('sort') || 'software-asc').toLowerCase().trim();
            if (presetHost) hostInput.value = presetHost;
            if (presetSoftware) softwareInput.value = presetSoftware;
            if (['all', 'yes', 'no'].includes(presetUpdate)) updateFilter.value = presetUpdate;
            if (Array.from(sortBy.options).some((opt) => opt.value === presetSort)) sortBy.value = presetSort;

            function applyFilterAndSort(){
                const hostQ = (hostInput.value || '').toLowerCase().trim();
                const softwareQ = (softwareInput.value || '').toLowerCase().trim();
                const updateQ = updateFilter.value;
                const sortQ = sortBy.value;

                const filtered = [];
                rows.forEach((row) => {
                    const hostText = textValue(row, 'data-host');
                    const softwareText = textValue(row, 'data-software');
                    const updateText = textValue(row, 'data-update');
                    const hostMatch = !hostQ || hostText.includes(hostQ);
                    const softwareMatch = !softwareQ || softwareText.includes(softwareQ);
                    const updateMatch = updateQ === 'all' || updateText === updateQ;
                    const show = hostMatch && softwareMatch && updateMatch;
                    row.style.display = show ? '' : 'none';
                    if (show) {
                        filtered.push(row);
                    }
                });

                filtered.sort((a, b) => {
                    if (sortQ === 'software-asc') return textValue(a, 'data-software').localeCompare(textValue(b, 'data-software'));
                    if (sortQ === 'software-desc') return textValue(b, 'data-software').localeCompare(textValue(a, 'data-software'));
                    if (sortQ === 'host-asc') return textValue(a, 'data-host').localeCompare(textValue(b, 'data-host'));
                    if (sortQ === 'host-desc') return textValue(b, 'data-host').localeCompare(textValue(a, 'data-host'));
                    if (sortQ === 'update-desc') return updateRank(textValue(b, 'data-update')) - updateRank(textValue(a, 'data-update'));
                    if (sortQ === 'update-asc') return updateRank(textValue(a, 'data-update')) - updateRank(textValue(b, 'data-update'));
                    return 0;
                });

                filtered.forEach((row) => tableBody.appendChild(row));
                rowCount.textContent = `Showing ${filtered.length} of ${rows.length} row(s)`;
            }

            hostInput.addEventListener('input', applyFilterAndSort);
            softwareInput.addEventListener('input', applyFilterAndSort);
            updateFilter.addEventListener('change', applyFilterAndSort);
            sortBy.addEventListener('change', applyFilterAndSort);
            clearFilters.addEventListener('click', () => {
                hostInput.value = '';
                softwareInput.value = '';
                updateFilter.value = 'all';
                sortBy.value = 'software-asc';
                applyFilterAndSort();
            });

            applyFilterAndSort();
        });
    </script>
"""

    return f"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Scan {report.get('scan_id')} Software Update Report</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 24px;">
  <h2>Software Update Report (Scan #{report.get('scan_id')})</h2>
  <p><strong>Generated:</strong> {html_escape(str(report.get('generated_at') or '-'))}</p>
    {filter_summary}
    {search_controls}
  {summary_html}
  {table_html}
</body>
</html>
"""


@scans_bp.route('/capabilities', methods=['GET'])
@require_api_key
def get_scan_capabilities():
    """
    Get available scanning capabilities.

    Returns information about supported connection methods,
    their availability, and required dependencies.
    """
    from ..services.remote_executor import RemoteExecutor

    capabilities = RemoteExecutor.get_capabilities()

    return jsonify({
        'methods': capabilities,
        'recommended': 'agent' if capabilities['agent']['available'] else
                       'winrm' if capabilities['winrm']['available'] else 'ssh',
        'message': 'Use the appropriate method based on target OS and network access'
    })


@scans_bp.route('', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def list_scans():
    """List all scan jobs."""
    try:
        # Validate inputs
        status = sanitize_string(request.args.get('status', ''), max_length=20)
        if status and status not in ('pending', 'running', 'completed', 'failed', 'cancelled'):
            status = ''  # Invalid status, ignore

        scan_type = sanitize_string(request.args.get('type', ''), max_length=50)

        page, per_page = validate_pagination(
            request.args.get('page', 1, type=int),
            request.args.get('per_page', 50, type=int)
        )

        with session_scope() as session:
            query = session.query(ScanJob).order_by(ScanJob.created_at.desc())

            if status:
                query = query.filter(ScanJob.status == status)
            if scan_type:
                query = query.filter(ScanJob.job_type == scan_type)

            total = query.count()
            scans = query.offset((page - 1) * per_page).limit(per_page).all()

            return jsonify({
                'total': total,
                'page': page,
                'per_page': per_page,
                'max_per_page': MAX_PAGE_SIZE,
                'scans': [scan_to_dict(s) for s in scans]
            })
    except Exception as e:
        return safe_error_response(e, 500)


@scans_bp.route('/<int:scan_id>', methods=['GET'])
@require_api_key
def get_scan(scan_id: int):
    """Get details of a specific scan job."""
    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        return jsonify(scan_to_dict(scan, detailed=True))


@scans_bp.route('', methods=['POST'])
@require_api_key
@rate_limit(max_requests=20, window_seconds=60)  # Lower limit for writes
def create_scan():
    """Create a new scan job."""
    try:
        # Validate request
        validation_error = validate_json_request()
        if validation_error:
            return validation_error

        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Validate and sanitize targets
        raw_targets = data.get('targets', [])
        if not isinstance(raw_targets, list):
            return jsonify({'error': 'Targets must be a list'}), 400

        raw_targets, target_coverage = _expand_range_targets_with_metadata(raw_targets)
        target_warnings: list[str] = []
        if target_coverage.get('truncated'):
            target_warnings.append(
                f"Target expansion truncated to {MAX_TARGETS_COUNT} entries. Narrow the target scope or split scans for full coverage."
            )

        targets = validate_targets(raw_targets)
        if not targets:
            return jsonify({'error': 'No valid targets specified'}), 400

        if len(targets) > MAX_TARGETS_COUNT:
            return jsonify({'error': f'Maximum {MAX_TARGETS_COUNT} targets allowed'}), 400

        # Sanitize other fields
        job_type = sanitize_string(data.get('job_type', data.get('scan_type', 'discovery')), max_length=50)
        if job_type not in ('discovery', 'software_inventory', 'vulnerability_scan', 'vulnerability', 'compliance', 'full'):
            job_type = 'discovery'

        created_by = sanitize_string(data.get('created_by', 'api'), max_length=255)
        name = sanitize_string(data.get('name', ''), max_length=255) or None

        # Enhanced scan options
        os_type = sanitize_string(data.get('os_type', 'auto'), max_length=50)
        if os_type not in ('auto', 'linux', 'windows'):
            os_type = 'auto'

        # Discovery mode: network (unauthenticated), authenticated (with creds), managed (stored creds)
        discovery_mode = sanitize_string(data.get('discovery_mode', 'network'), max_length=50)
        if discovery_mode not in ('network', 'authenticated', 'managed'):
            discovery_mode = 'network'

        discovery_method = _normalize_discovery_method(
            data.get('discovery_method', 'port_scan'),
            fallback='port_scan' if discovery_mode == 'network' else 'ssh',
        )
        if discovery_mode == 'network':
            discovery_method = 'port_scan'
        elif discovery_mode == 'managed':
            discovery_method = 'managed'

        scan_profile = _normalize_scan_profile(data.get('scan_profile', 'standard'))
        scan_overrides = _normalize_scan_overrides(data.get('scan_overrides', {}))

        # Validate credentials without persisting credential payloads in scan config
        raw_credentials = data.get('credentials', {})
        if not isinstance(raw_credentials, dict):
            raw_credentials = {}

        credential_id = data.get('credential_id', raw_credentials.get('credential_id'))
        if credential_id is not None:
            try:
                credential_id = int(credential_id)
            except (TypeError, ValueError):
                return jsonify({'error': 'credential_id must be an integer'}), 400
            if credential_id <= 0:
                return jsonify({'error': 'credential_id must be a positive integer'}), 400

        auth_method = sanitize_string(raw_credentials.get('auth_method', 'password'), max_length=50)
        if auth_method not in ('password', 'key', 'agent', 'none'):
            auth_method = 'password'

        credential_username = sanitize_string(raw_credentials.get('username', ''), max_length=255)
        credential_domain = sanitize_string(raw_credentials.get('domain', ''), max_length=255)
        credential_key_path = sanitize_string(raw_credentials.get('key_path', ''), max_length=500)
        credential_password = raw_credentials.get('password', '')

        method_default_port = {
            'ssh': 22,
            'winrm': 5985,
            'agent': 8443,
            'managed': 8080,
            'port_scan': 0,
        }.get(discovery_method, 22)
        credential_port = raw_credentials.get('port', data.get('port', method_default_port))
        try:
            credential_port = min(max(int(credential_port), 1), 65535)
        except (TypeError, ValueError):
            credential_port = 22

        credential_metadata = {
            'auth_method': auth_method,
            'port': credential_port,
            'has_password': bool(raw_credentials.get('password')),
            'has_key': bool(raw_credentials.get('key_path') or raw_credentials.get('ssh_key')),
            'has_username': bool(credential_username),
        }

        if discovery_mode == 'authenticated' and discovery_method in ('ssh', 'winrm') and credential_id is None:
            if not credential_username:
                return jsonify({'error': 'Username is required for authenticated scans'}), 400

            if auth_method == 'key':
                if not credential_key_path:
                    return jsonify({'error': 'SSH key path is required when auth_method is key'}), 400
            elif not str(credential_password or '').strip():
                return jsonify({'error': 'Password is required for authenticated scans'}), 400

        # Scope options
        scope = data.get('scope', {})
        if isinstance(scope, dict):
            scope = {
                'packages': bool(scope.get('packages', True)),
                'services': bool(scope.get('services', True)),
                'updates': bool(scope.get('updates', True)),
                'ports': bool(scope.get('ports', True)),
                'users': bool(scope.get('users', False)),
                'security': bool(scope.get('security', False)),
            }
        else:
            scope = {'packages': True, 'services': True, 'updates': True, 'ports': True}

        # Schedule options
        schedule = sanitize_string(data.get('schedule', 'now'), max_length=50)
        if schedule not in ('now', 'once', 'daily', 'weekly', 'monthly'):
            schedule = 'now'

        with session_scope() as session:
            scan = ScanJob(
                uuid=str(uuid.uuid4()),
                job_type=job_type,
                status='pending',
                targets=targets,
                created_by=created_by,
                total_targets=len(targets)
            )

            # Store enhanced options in config field (as JSON) without raw credential payloads
            scan.config = {
                'name': name,
                'os_type': os_type,
                'discovery_mode': discovery_mode,
                'discovery_method': discovery_method,
                'scan_profile': scan_profile,
                'scan_overrides': scan_overrides,
                'target_coverage': target_coverage,
                'credential_id': credential_id,
                'credential_metadata': credential_metadata,
                'posture_evaluation_enabled': bool(data.get('posture_evaluation_enabled', True)),
                'sync_to_audit_tool': bool(data.get('sync_to_audit_tool', True)),
                'scope': scope,
                'schedule': schedule,
                'schedule_time': data.get('schedule_time')
            }

            # Backward-compatible support for wizard-provided authenticated credentials.
            # These are used only by the scan worker at execution time and then scrubbed.
            if discovery_mode == 'authenticated' and discovery_method in ('ssh', 'winrm') and credential_id is None:
                scan.config['runtime_credentials'] = {
                    'username': credential_username,
                    'password': credential_password,
                    'key_path': credential_key_path,
                    'domain': credential_domain,
                    'auth_method': auth_method,
                }

            session.add(scan)
            session.commit()

            audit_log('create', 'scan', scan.id, {'targets_count': len(targets), 'mode': discovery_mode, 'method': discovery_method})

            engine_tradeoff = _build_engine_tradeoff(scan_profile, scan_overrides, len(targets))

            return jsonify({
                'id': scan.id,
                'uuid': scan.uuid,
                'status': scan.status,
                'targets_count': len(targets),
                'discovery_mode': discovery_mode,
                'discovery_method': discovery_method,
                'scan_profile': scan_profile,
                'target_coverage': target_coverage,
                'warnings': target_warnings,
                'scan_engine': engine_tradeoff,
                'schedule': schedule,
                'vulnerability_correlation': _build_correlation_payload(scan),
                'posture_evaluation': _build_posture_payload(scan),
                'message': 'Scan job created'
            }), 201
    except Exception as e:
        return safe_error_response(e, 500)


@scans_bp.route('/assets/<int:asset_id>/rescan', methods=['POST'])
@require_api_key
@rate_limit(max_requests=30, window_seconds=60)
def rescan_asset(asset_id: int):
    """Queue an ad-hoc rescan for one known asset using its stored scan profile."""
    try:
        data = request.get_json(silent=True) or {}
        requested_type = sanitize_string(data.get('job_type', 'full'), max_length=50)
        if requested_type not in ('discovery', 'software_inventory', 'vulnerability_scan', 'vulnerability', 'compliance', 'full'):
            requested_type = 'full'

        with session_scope() as session:
            asset = session.query(Asset).filter(Asset.id == asset_id).first()
            if not asset:
                return jsonify({'error': 'Asset not found'}), 404

            target = (asset.primary_ip or asset.fqdn or asset.hostname or '').strip()
            if not target:
                return jsonify({'error': 'Asset has no resolvable target (IP/FQDN/hostname)'}), 400

            custom_attributes = asset.custom_attributes if isinstance(asset.custom_attributes, dict) else {}
            scan_profile = custom_attributes.get('last_scan_profile') if isinstance(custom_attributes.get('last_scan_profile'), dict) else {}
            last_scan_data = custom_attributes.get('last_scan_data') if isinstance(custom_attributes.get('last_scan_data'), dict) else {}

            method = _normalize_discovery_method(
                scan_profile.get('discovery_method') or last_scan_data.get('connection_method') or 'managed',
                fallback='managed',
            )

            discovery_mode = sanitize_string(scan_profile.get('discovery_mode', ''), max_length=50).lower()
            if discovery_mode not in ('network', 'authenticated', 'managed'):
                discovery_mode = 'network' if method == 'port_scan' else ('managed' if method in ('managed', 'agent') else 'authenticated')

            credential_id = scan_profile.get('credential_id')
            if credential_id is not None:
                try:
                    credential_id = int(credential_id)
                except (TypeError, ValueError):
                    credential_id = None

            if (method in ('ssh', 'winrm') and not credential_id) or not scan_profile:
                recent_results = (
                    session.query(ScanResult)
                    .filter(ScanResult.asset_id == asset.id)
                    .order_by(ScanResult.created_at.desc())
                    .limit(20)
                    .all()
                )
                for recent_result in recent_results:
                    if not recent_result.scan_job or not isinstance(recent_result.scan_job.config, dict):
                        continue

                    recent_config = recent_result.scan_job.config
                    recent_method = _normalize_discovery_method(recent_config.get('discovery_method', ''), fallback='')
                    recent_credential_id = recent_config.get('credential_id')

                    if recent_credential_id is not None:
                        try:
                            recent_credential_id = int(recent_credential_id)
                        except (TypeError, ValueError):
                            recent_credential_id = None

                    if not method and recent_method in ('port_scan', 'ssh', 'winrm', 'agent', 'managed'):
                        method = recent_method

                    if method in ('ssh', 'winrm') and recent_method == method and recent_credential_id:
                        credential_id = recent_credential_id
                        break

            if method in ('ssh', 'winrm') and not credential_id:
                compatible_types = ('ssh_password', 'ssh_key') if method == 'ssh' else ('windows_local', 'windows_domain')
                fallback_credential = (
                    session.query(ScanCredential)
                    .filter(ScanCredential.credential_type.in_(compatible_types))
                    .order_by(ScanCredential.updated_at.desc(), ScanCredential.id.desc())
                    .first()
                )
                if fallback_credential:
                    credential_id = fallback_credential.id

            if method in ('ssh', 'winrm') and not credential_id:
                return jsonify({
                    'error': 'No stored credential is linked to this asset yet. Run one authenticated discovery first or attach a saved credential.'
                }), 409

            scope = scan_profile.get('scope') if isinstance(scan_profile.get('scope'), dict) else {
                'packages': True,
                'services': True,
                'updates': True,
                'ports': True,
                'users': False,
                'security': False,
            }

            port = scan_profile.get('port')
            try:
                port = int(port) if port is not None else None
            except (TypeError, ValueError):
                port = None

            scan = ScanJob(
                uuid=str(uuid.uuid4()),
                job_type=requested_type,
                status='pending',
                targets=[target],
                created_by='asset-shortcut',
                total_targets=1,
            )
            scan.config = {
                'name': sanitize_string(data.get('name', f"Rescan {asset.hostname or target}"), max_length=255),
                'os_type': sanitize_string(scan_profile.get('os_type') or asset.os_type or 'auto', max_length=50),
                'discovery_mode': discovery_mode,
                'discovery_method': method,
                'credential_id': credential_id,
                'credential_metadata': {
                    'port': port,
                },
                'scope': {
                    'packages': bool(scope.get('packages', True)),
                    'services': bool(scope.get('services', True)),
                    'updates': bool(scope.get('updates', True)),
                    'ports': bool(scope.get('ports', True)),
                    'users': bool(scope.get('users', False)),
                    'security': bool(scope.get('security', False)),
                },
                'schedule': 'now',
                'rescan_asset_id': asset.id,
                'rescan_source': 'asset_shortcut',
            }

            session.add(scan)
            session.commit()
            audit_log('create', 'scan', scan.id, {'source': 'asset_shortcut', 'asset_id': asset.id, 'method': method})

            return jsonify({
                'id': scan.id,
                'status': scan.status,
                'asset_id': asset.id,
                'target': target,
                'discovery_mode': discovery_mode,
                'discovery_method': method,
                'message': 'Asset rescan queued'
            }), 201
    except Exception as e:
        return safe_error_response(e, 500)


@scans_bp.route('/<int:scan_id>/start', methods=['POST'])
@require_api_key
def start_scan(scan_id: int):
    """
    Start a pending scan job.

    The scan will be picked up by the background scan worker.
    Use the progress endpoint to monitor scan status.
    """
    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        if scan.status not in ['pending', 'paused']:
            return jsonify({'error': f'Cannot start scan in {scan.status} status'}), 400

        # Ensure status is pending so the worker picks it up
        scan.status = 'pending'
        session.commit()

        return jsonify({
            'id': scan.id,
            'status': scan.status,
            'message': 'Scan queued for execution. Monitor progress at /progress endpoint.',
            'progress_url': f'/api/v1/scans/{scan.id}/progress',
            'vulnerability_correlation': _build_correlation_payload(scan),
            'posture_evaluation': _build_posture_payload(scan)
        })


@scans_bp.route('/<int:scan_id>/progress', methods=['GET'])
@require_api_key
def get_scan_progress(scan_id: int):
    """Get real-time progress of a scan job."""
    from ..services.scan_executor import get_scan_worker

    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        # Get in-memory progress from worker if available
        worker = get_scan_worker()
        live_progress = None
        if worker:
            live_progress = worker.executor.get_scan_progress(scan_id)

        response = {
            'id': scan.id,
            'status': scan.status,
            'total_targets': scan.total_targets or 0,
            'successful_targets': scan.successful_targets or 0,
            'failed_targets': scan.failed_targets or 0,
            'started_at': scan.started_at.isoformat() if scan.started_at else None,
            'completed_at': scan.completed_at.isoformat() if scan.completed_at else None,
            'vulnerability_correlation': _build_correlation_payload(scan),
            'posture_evaluation': _build_posture_payload(scan)
        }

        # Add live progress if scan is running
        if live_progress:
            response['live'] = {
                'completed': live_progress.get('completed', 0),
                'total': live_progress.get('total', 0),
                'successful': live_progress.get('successful', 0),
                'failed': live_progress.get('failed', 0),
                'percent_complete': round(
                    (live_progress.get('completed', 0) / max(live_progress.get('total', 1), 1)) * 100, 1
                )
            }

        return jsonify(response)


@scans_bp.route('/<int:scan_id>/cancel', methods=['POST'])
@require_api_key
def cancel_scan(scan_id: int):
    """Cancel a running scan job."""
    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        if scan.status not in ['pending', 'running']:
            return jsonify({'error': f'Cannot cancel scan in {scan.status} status'}), 400

        scan.status = 'cancelled'
        scan.completed_at = datetime.utcnow()
        session.commit()

        return jsonify({
            'id': scan.id,
            'status': scan.status,
            'message': 'Scan cancelled'
        })


@scans_bp.route('/<int:scan_id>', methods=['DELETE'])
@require_api_key
def delete_scan(scan_id: int):
    """Delete scan report using HTTP DELETE."""
    return _delete_scan_report(scan_id)


@scans_bp.route('/<int:scan_id>/delete', methods=['POST'])
@require_api_key
def delete_scan_compat(scan_id: int):
    """Delete scan report using HTTP POST for proxy/client compatibility."""
    return _delete_scan_report(scan_id)


def _delete_scan_report(scan_id: int):
    """Delete a scan report (scan job + result rows) while preserving discovered assets."""
    from ..services.scan_executor import get_scan_worker

    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        if scan.status == 'running':
            worker = get_scan_worker()
            if worker:
                worker.executor.cancel_scan(scan_id)

        deleted_results = len(scan.results or [])
        session.delete(scan)
        session.commit()

        return jsonify({
            'message': 'Scan report deleted. Discovered assets were not removed.',
            'id': scan_id,
            'deleted_results': deleted_results,
            'assets_affected': 0
        })


@scans_bp.route('/bulk-delete', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)
def bulk_delete_scans():
    """Bulk delete scan reports while preserving discovered assets."""
    data = request.get_json() or {}
    scan_ids = data.get('scan_ids', [])

    if not isinstance(scan_ids, list) or not scan_ids:
        return jsonify({'error': 'scan_ids must be a non-empty list'}), 400

    normalized_ids = []
    for raw_id in scan_ids[:500]:
        try:
            scan_id = int(raw_id)
        except (TypeError, ValueError):
            continue
        if scan_id > 0:
            normalized_ids.append(scan_id)

    if not normalized_ids:
        return jsonify({'error': 'No valid scan IDs provided'}), 400

    deleted = []
    not_found = []

    from ..services.scan_executor import get_scan_worker
    worker = get_scan_worker()

    with session_scope() as session:
        scans = session.query(ScanJob).filter(ScanJob.id.in_(normalized_ids)).all()
        scan_by_id = {scan.id: scan for scan in scans}

        for scan_id in normalized_ids:
            scan = scan_by_id.get(scan_id)
            if not scan:
                not_found.append(scan_id)
                continue

            if scan.status == 'running' and worker:
                worker.executor.cancel_scan(scan_id)

            deleted_results = len(scan.results or [])
            session.delete(scan)
            deleted.append({'id': scan_id, 'deleted_results': deleted_results})

        session.commit()

    return jsonify({
        'message': 'Bulk scan report deletion completed',
        'requested_count': len(normalized_ids),
        'deleted_count': len(deleted),
        'not_found_count': len(not_found),
        'deleted': deleted,
        'not_found': not_found,
        'assets_affected': 0,
    })


@scans_bp.route('/<int:scan_id>/results', methods=['GET'])
@require_api_key
def get_scan_results(scan_id: int):
    """Get results for a scan job."""
    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        scan_config = scan.config if isinstance(scan.config, dict) else {}
        scope_config = scan_config.get('scope') if isinstance(scan_config.get('scope'), dict) else {}
        discovery_method = _normalize_discovery_method(
            scan_config.get('discovery_method', ''),
            fallback='port_scan'
        )
        direct_api_details = {
            'discovery_mode': scan_config.get('discovery_mode') or 'network',
            'discovery_method': discovery_method,
            'is_direct_api_scan': discovery_method == 'agent',
            'posture_evaluation_enabled': bool(scan_config.get('posture_evaluation_enabled', True)),
            'security_scope_enabled': bool(scope_config.get('security', False)),
            'sync_to_audit_tool': bool(scan_config.get('sync_to_audit_tool', True)),
            'destination_policy_enforced': scan_config.get('destination_policy_enforced'),
        }

        results = session.query(ScanResult).filter(
            ScanResult.scan_job_id == scan_id
        ).all()

        posture_top_findings = []
        for result in results:
            raw_output = result.raw_output if isinstance(result.raw_output, dict) else {}
            posture_eval = raw_output.get('posture_evaluation') if isinstance(raw_output.get('posture_evaluation'), dict) else {}
            findings = posture_eval.get('findings') if isinstance(posture_eval.get('findings'), list) else []
            for finding in findings:
                if not isinstance(finding, dict):
                    continue
                status = str(finding.get('status') or '').lower()
                if status not in {'warn', 'fail'}:
                    continue
                posture_top_findings.append({
                    'target': result.target,
                    'control_id': finding.get('control_id'),
                    'title': finding.get('title'),
                    'status': status,
                    'severity': finding.get('severity') or ('high' if status == 'fail' else 'medium'),
                })

        posture_top_findings.sort(
            key=lambda item: (
                0 if str(item.get('status')).lower() == 'fail' else 1,
                str(item.get('severity') or '').lower(),
                str(item.get('control_id') or ''),
            )
        )
        posture_top_findings = posture_top_findings[:5]
        risk_prioritization = _build_scan_risk_prioritization(scan, results, session=session)

        return jsonify({
            'scan_id': scan_id,
            'status': scan.status,
            'direct_api_details': direct_api_details,
            'vulnerability_correlation': _build_correlation_payload(scan),
            'posture_evaluation': _build_posture_payload(scan),
            'risk_prioritization': risk_prioritization,
            'posture_top_findings': posture_top_findings,
            'software_update_report_url': f'/api/v1/scans/{scan_id}/report/software-updates?format=html',
            'results': [
                {
                    'id': r.id,
                    'target': r.target,
                    'success': r.status == 'success',
                    'error_message': r.error_message,
                    'asset_id': r.asset_id,
                    'discovered_at': r.created_at.isoformat() if r.created_at else None
                }
                for r in results
            ]
        })


@scans_bp.route('/<int:scan_id>/report/software-updates', methods=['GET'])
@require_api_key
def get_scan_software_update_report(scan_id: int):
    """Generate a software update/outdated report for assets discovered by a specific scan."""
    output_format = sanitize_string(request.args.get('format', 'json'), max_length=10).lower()
    if output_format not in {'json', 'html'}:
        output_format = 'html'
    host_filter = sanitize_string(request.args.get('host', ''), max_length=255)
    software_filter = sanitize_string(request.args.get('software', ''), max_length=255)

    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        asset_ids = [
            row[0] for row in session.query(ScanResult.asset_id).filter(
                ScanResult.scan_job_id == scan_id,
                ScanResult.asset_id.isnot(None)
            ).all() if row[0] is not None
        ]

        deduped_asset_ids = sorted(set(int(asset_id) for asset_id in asset_ids))
        assets = session.query(Asset).filter(Asset.id.in_(deduped_asset_ids)).all() if deduped_asset_ids else []
        scan_results = session.query(ScanResult).filter(
            ScanResult.scan_job_id == scan_id
        ).all()
        report = _build_scan_software_update_report(
            scan,
            assets,
            session,
            host_filter=host_filter,
            software_filter=software_filter,
        )
        report['risk_prioritization'] = _build_scan_risk_prioritization(scan, scan_results, session=session)

    if output_format == 'html':
        return Response(_scan_software_report_to_html(report), mimetype='text/html; charset=utf-8')

    return jsonify(report)


@scans_bp.route('/<int:scan_id>/results', methods=['POST'])
@require_api_key
def add_scan_result(scan_id: int):
    """Add a result to a scan job (used by discovery agents)."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    with session_scope() as session:
        scan = session.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return jsonify({'error': 'Scan job not found'}), 404

        is_success = data.get('success', True)
        result = ScanResult(
            scan_job_id=scan_id,
            target=data.get('target', data.get('hostname')),
            status='success' if is_success else 'failed',
            error_message=data.get('error'),
            raw_output=data
        )
        session.add(result)

        # Update scan progress
        scan.successful_targets = (scan.successful_targets or 0) + (1 if is_success else 0)
        if not is_success:
            scan.failed_targets = (scan.failed_targets or 0) + 1

        session.commit()

        return jsonify({
            'id': result.id,
            'message': 'Result added'
        }), 201


# Credentials endpoints
@scans_bp.route('/credentials', methods=['GET'])
@require_api_key
def list_credentials():
    """List stored credentials (without sensitive data)."""
    with session_scope() as session:
        creds = session.query(ScanCredential).all()

        return jsonify({
            'credentials': [
                {
                    'id': c.id,
                    'name': c.name,
                    'credential_type': c.credential_type,
                    'username': c.username,
                    'domain': c.domain,
                    'created_at': c.created_at.isoformat() if c.created_at else None
                }
                for c in creds
            ]
        })


@scans_bp.route('/credentials', methods=['POST'])
@require_api_key
def create_credential():
    """Store a new credential for scans."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    required = ['name', 'credential_type', 'username']
    for field in required:
        if field not in data:
            return jsonify({'error': f'Missing required field: {field}'}), 400

    with session_scope() as session:
        cred = ScanCredential(
            name=data['name'],
            credential_type=data['credential_type'],
            username=data['username'],
            domain=data.get('domain')
        )

        # Encrypt password/key
        if data.get('password'):
            cred.set_password(data['password'])
        if data.get('ssh_key'):
            cred.set_ssh_key(data['ssh_key'])

        session.add(cred)
        session.commit()

        return jsonify({
            'id': cred.id,
            'name': cred.name,
            'message': 'Credential stored'
        }), 201


@scans_bp.route('/credentials/<int:cred_id>', methods=['DELETE'])
@require_api_key
def delete_credential(cred_id: int):
    """Delete a stored credential."""
    with session_scope() as session:
        cred = session.query(ScanCredential).filter(ScanCredential.id == cred_id).first()
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404

        session.delete(cred)
        session.commit()

        return jsonify({'message': 'Credential deleted'})


def scan_to_dict(scan: ScanJob, detailed: bool = False) -> dict:
    """Convert scan job to dictionary."""
    scan_config = scan.config if isinstance(scan.config, dict) else {}
    discovery_mode = sanitize_string(scan_config.get('discovery_mode', ''), max_length=50).lower() or 'network'
    discovery_method = _normalize_discovery_method(
        scan_config.get('discovery_method', ''),
        fallback='port_scan' if discovery_mode == 'network' else 'ssh',
    )

    targets_total = len(scan.targets) if scan.targets else 0
    successful = scan.successful_targets or 0
    failed = scan.failed_targets or 0
    completed = successful + failed
    progress = round((completed / max(targets_total, 1)) * 100, 1) if targets_total else 0
    effective_status = scan.status

    # Prefer live in-memory progress while a scan is pending/running.
    if scan.status in {'pending', 'running'}:
        try:
            from ..services.scan_executor import get_scan_worker

            worker = get_scan_worker()
            live_progress = worker.executor.get_scan_progress(scan.id) if worker else None
            if isinstance(live_progress, dict):
                live_total = int(live_progress.get('total') or 0)
                live_completed = int(live_progress.get('completed') or 0)
                live_successful = int(live_progress.get('successful') or 0)
                live_failed = int(live_progress.get('failed') or 0)

                if live_total > 0:
                    targets_total = live_total
                completed = live_completed
                successful = live_successful
                failed = live_failed
                progress = round((completed / max(targets_total, 1)) * 100, 1) if targets_total else 0

                live_status = str(live_progress.get('status') or '').strip().lower()
                if live_status:
                    effective_status = live_status
                elif scan.status == 'pending' and live_completed >= 0:
                    effective_status = 'running'
        except Exception as live_progress_error:  # noqa: BLE001 - best-effort live progress enrichment
            logger.debug("Skipping live progress enrichment for scan %s: %s", scan.id, live_progress_error)

    result = {
        'id': scan.id,
        'job_id': scan.uuid,
        'uuid': scan.uuid,
        'job_type': scan.job_type,
        'scan_type': scan.job_type,
        'discovery_mode': discovery_mode,
        'discovery_method': discovery_method,
        'is_direct_api_scan': discovery_method == 'agent',
        'status': effective_status,
        'scan_profile': sanitize_string(scan_config.get('scan_profile', 'standard'), max_length=20).lower() or 'standard',
        'target_coverage': scan_config.get('target_coverage') if isinstance(scan_config.get('target_coverage'), dict) else {},
        'targets_total': targets_total,
        'targets_completed': completed,
        'targets_failed': failed,
        'successful_targets': successful,
        'failed_targets': failed,
        'progress': progress,
        'created_at': scan.created_at.isoformat() if scan.created_at else None,
        'started_at': scan.started_at.isoformat() if scan.started_at else None,
        'completed_at': scan.completed_at.isoformat() if scan.completed_at else None,
        'vulnerability_correlation': _build_correlation_payload(scan),
        'posture_evaluation': _build_posture_payload(scan),
        'risk_prioritization': _empty_risk_prioritization(scan),
    }

    if detailed:
        result['targets'] = scan.targets
        result['created_by'] = scan.created_by

    return result


@scans_bp.route('/test-connection', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)  # Strict rate limit for connection tests
def test_connection():
    """
    Test connection to a target host using the appropriate method.

    Supports:
    - SSH (Linux/Unix) with password or key authentication
    - WinRM (Windows) with NTLM authentication
    - Agent API (direct lightweight endpoint) with HTTPS health check
    - Fleet Agent endpoint checks
    """
    try:
        validation_error = validate_json_request()
        if validation_error:
            return validation_error

        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        target = sanitize_string(data.get('target', ''), max_length=255)
        method = sanitize_string(data.get('method', 'ssh'), max_length=50)

        # Validate method
        if method not in ('ssh', 'winrm', 'agent', 'api', 'managed', 'fleet-agent', 'fleet_agent'):
            return jsonify({'error': 'Invalid method. Use: ssh, winrm, agent, or fleet-agent', 'success': False}), 400

        # Default ports based on method
        default_ports = {'ssh': 22, 'winrm': 5985, 'agent': 8443, 'api': 8443, 'managed': 8080, 'fleet-agent': 8080, 'fleet_agent': 8080}
        port = data.get('port')
        if port:
            port = min(max(int(port), 1), 65535)
        else:
            port = default_ports.get(method, 22)

        # Get credentials
        username = sanitize_string(data.get('username', ''), max_length=255)
        password = data.get('password', '')  # Don't sanitize password
        key_path = sanitize_string(data.get('key_path', ''), max_length=500)
        domain = sanitize_string(data.get('domain', ''), max_length=255)
        auth_method = sanitize_string(data.get('auth_method', 'password'), max_length=50)

        if not target:
            return jsonify({'error': 'Target is required', 'success': False}), 400

        # Validate target format
        validated = validate_targets([target])
        if not validated:
            return jsonify({'error': 'Invalid target format', 'success': False}), 400

        # SSRF protection: validate and resolve target safely
        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,  # Allow internal network scans by design
        )
        if not is_safe:
            logger.warning(f"SSRF blocked: {target} - {reason}")
            return jsonify({
                'success': False,
                'error': reason,
                'message': f'Target rejected: {reason}'
            }), 400

        # Use RemoteExecutor for actual connection test
        from ..services.remote_executor import RemoteExecutor

        credentials = {
            'username': username,
            'password': password,
            'key_path': key_path,
            'domain': domain,
            'auth_method': auth_method
        }

        result = RemoteExecutor.test_connection(
            target=resolved_ip,
            method=method,
            port=port,
            credentials=credentials,
            timeout=30
        )

        response = {
            'success': result.success,
            'message': result.message,
            'resolved_ip': resolved_ip,
            'method': method,
            'port': port
        }

        if result.details:
            response['details'] = result.details
        if result.os_info:
            response['os_info'] = result.os_info
        if result.error:
            response['error'] = result.error

        return jsonify(response)

    except Exception as e:
        return safe_error_response(e, 500)
