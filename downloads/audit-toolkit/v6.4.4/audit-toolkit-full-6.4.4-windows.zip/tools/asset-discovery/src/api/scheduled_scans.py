# Asset Discovery - Scheduled Scans API
"""
REST API for managing scheduled scans.

Provides endpoints to:
- Create and manage scheduled scan configurations
- View execution history
- Manually trigger scheduled scans
- Configure auto-refresh and sync settings

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import uuid
from datetime import datetime

from flask import Blueprint, request, jsonify

from ..models.base import session_scope
from ..models.asset import Asset
from ..models.scan import ScanJob
from ..models.scheduled_scan import ScheduledScan, ScheduledScanExecution
from ..sync_service import get_sync_service
from ..security import require_api_key, sanitize_string, rate_limit

logger = logging.getLogger(__name__)

scheduled_scans_bp = Blueprint('scheduled_scans', __name__)


# NOTE: sanitize_string is imported from security.py for centralized OWASP-compliant sanitization


def validate_cron(cron_expression: str) -> bool:
    """Validate a cron expression."""
    if not cron_expression:
        return False
    parts = cron_expression.split()
    if len(parts) < 5 or len(parts) > 6:
        return False
    # Basic validation - not exhaustive
    return True


def _normalize_scan_options(raw_scan_options) -> dict:
    """Normalize and sanitize scheduled scan options payload."""
    default_scope = {
        'packages': True,
        'services': True,
        'updates': True,
        'ports': True,
    }

    if not isinstance(raw_scan_options, dict):
        return {}

    credential_id = raw_scan_options.get('credential_id', raw_scan_options.get('credentials_id'))
    if credential_id is not None:
        try:
            credential_id = int(credential_id)
        except (TypeError, ValueError):
            credential_id = None

    discovery_method = sanitize_string(raw_scan_options.get('discovery_method', 'managed'), max_length=50).lower()
    if discovery_method in ('fleet-agent', 'fleet_agent'):
        discovery_method = 'managed'
    elif discovery_method == 'api':
        discovery_method = 'agent'
    elif discovery_method not in ('port_scan', 'ssh', 'winrm', 'agent', 'managed'):
        discovery_method = 'managed'

    normalized = {
        'os_type': sanitize_string(raw_scan_options.get('os_type', 'auto'), max_length=50),
        'discovery_method': discovery_method,
        'discovery_mode': sanitize_string(raw_scan_options.get('discovery_mode', ''), max_length=50) or None,
        'scope': raw_scan_options.get('scope', default_scope),
        'credential_id': credential_id,
    }

    credential_metadata = raw_scan_options.get('credential_metadata')
    if isinstance(credential_metadata, dict):
        normalized_metadata = {}

        port = credential_metadata.get('port')
        if port is not None:
            try:
                normalized_metadata['port'] = int(port)
            except (TypeError, ValueError):
                pass

        auth_method = credential_metadata.get('auth_method')
        if auth_method:
            normalized_metadata['auth_method'] = sanitize_string(auth_method, max_length=50)

        for bool_key in ('has_password', 'has_key', 'has_username', 'auto_saved'):
            if bool_key in credential_metadata:
                normalized_metadata[bool_key] = bool(credential_metadata.get(bool_key))

        if normalized_metadata:
            normalized['credential_metadata'] = normalized_metadata

    runtime_credentials = raw_scan_options.get('runtime_credentials')
    if isinstance(runtime_credentials, dict):
        normalized_runtime = {}
        username = sanitize_string(runtime_credentials.get('username', ''), max_length=255)
        domain = sanitize_string(runtime_credentials.get('domain', ''), max_length=255)
        auth_method = sanitize_string(runtime_credentials.get('auth_method', ''), max_length=50)
        key_path = sanitize_string(runtime_credentials.get('key_path', ''), max_length=512)

        if username:
            normalized_runtime['username'] = username
        if domain:
            normalized_runtime['domain'] = domain
        if auth_method:
            normalized_runtime['auth_method'] = auth_method
        if key_path:
            normalized_runtime['key_path'] = key_path

        if 'password' in runtime_credentials and runtime_credentials.get('password'):
            normalized_runtime['password'] = str(runtime_credentials.get('password'))

        runtime_port = runtime_credentials.get('port')
        if runtime_port is not None:
            try:
                normalized_runtime['port'] = int(runtime_port)
            except (TypeError, ValueError):
                pass

        if normalized_runtime:
            normalized['runtime_credentials'] = normalized_runtime

    return normalized


def _build_target_host_snapshot(asset: Asset) -> dict:
    """Build a reusable host snapshot for scheduled scan persistence."""
    return {
        'asset_id': asset.id,
        'hostname': asset.hostname,
        'fqdn': asset.fqdn,
        'primary_ip': asset.primary_ip,
        'os_type': asset.os_type,
        'updated_at': datetime.utcnow().isoformat(),
    }


def _persist_asset_schedule_profile(asset: Asset, scan_options: dict) -> None:
    """Persist host details and credential linkage for future ad-hoc/scheduled scans."""
    current_attributes = dict(asset.custom_attributes or {})
    credential_metadata = scan_options.get('credential_metadata') if isinstance(scan_options, dict) else {}

    port = None
    if isinstance(credential_metadata, dict):
        port = credential_metadata.get('port')

    if port is None and isinstance(scan_options.get('runtime_credentials'), dict):
        runtime_port = scan_options['runtime_credentials'].get('port')
        if runtime_port is not None:
            try:
                port = int(runtime_port)
            except (TypeError, ValueError):
                port = None

    normalized_method = str(scan_options.get('discovery_method') or 'managed').lower()
    if normalized_method in ('fleet-agent', 'fleet_agent'):
        normalized_method = 'managed'
    elif normalized_method == 'api':
        normalized_method = 'agent'

    current_attributes['last_scan_profile'] = {
        'discovery_method': normalized_method,
        'discovery_mode': str(scan_options.get('discovery_mode') or '').lower() or (
            'network' if normalized_method == 'port_scan' else
            'managed' if normalized_method in ('managed', 'agent') else
            'authenticated'
        ),
        'credential_id': scan_options.get('credential_id'),
        'port': port,
        'os_type': scan_options.get('os_type') or asset.os_type or 'auto',
        'scope': scan_options.get('scope'),
        'updated_at': datetime.utcnow().isoformat(),
    }

    current_attributes['last_scan_data'] = {
        **dict(current_attributes.get('last_scan_data') or {}),
        'target': asset.primary_ip or asset.hostname,
        'hostname': asset.hostname,
        'fqdn': asset.fqdn,
        'primary_ip': asset.primary_ip,
        'os_type': asset.os_type,
        'connection_method': scan_options.get('discovery_method'),
        'credential_id': scan_options.get('credential_id'),
        'updated_at': datetime.utcnow().isoformat(),
    }

    current_attributes['scheduled_scan_host'] = _build_target_host_snapshot(asset)
    asset.custom_attributes = current_attributes


def _requires_linked_credential(scan_options: dict) -> bool:
    """Return True when scheduled scan options require but lack a linked credential."""
    if not isinstance(scan_options, dict):
        return False

    method = str(scan_options.get('discovery_method') or '').lower()
    if method not in ('ssh', 'winrm'):
        return False

    credential_id = scan_options.get('credential_id')
    return credential_id in (None, '', 0)


# Common cron presets
CRON_PRESETS = {
    'every_6_hours': '0 */6 * * *',
    'every_12_hours': '0 */12 * * *',
    'daily_midnight': '0 0 * * *',
    'daily_2am': '0 2 * * *',
    'daily_6am': '0 6 * * *',
    'weekly_sunday': '0 2 * * 0',
    'weekly_monday': '0 2 * * 1',
    'monthly': '0 2 1 * *',
    'quarterly': '0 2 1 1,4,7,10 *'
}


@scheduled_scans_bp.route('', methods=['GET'])
@require_api_key
def list_scheduled_scans():
    """List all scheduled scans."""
    try:
        with session_scope() as session:
            query = session.query(ScheduledScan)

            # Filter by active status
            active_only = request.args.get('active', '').lower() == 'true'
            if active_only:
                query = query.filter(ScheduledScan.is_active.is_(True))

            # Filter by target type
            target_type = request.args.get('target_type')
            if target_type:
                query = query.filter(ScheduledScan.target_type == target_type)

            # Filter by scan type
            scan_type = request.args.get('scan_type')
            if scan_type:
                query = query.filter(ScheduledScan.scan_type == scan_type)

            schedules = query.order_by(ScheduledScan.created_at.desc()).all()

            return jsonify({
                'success': True,
                'schedules': [s.to_dict() for s in schedules],
                'total': len(schedules)
            })
    except Exception as e:
        logger.error(f"Error listing scheduled scans: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>', methods=['GET'])
@require_api_key
def get_scheduled_scan(schedule_id: int):
    """Get a specific scheduled scan."""
    try:
        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            return jsonify({
                'success': True,
                'schedule': schedule.to_dict()
            })
    except Exception as e:
        logger.error(f"Error getting scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('', methods=['POST'])
@require_api_key
@rate_limit(max_requests=30, window_seconds=60)  # Limit creation rate
def create_scheduled_scan():
    """Create a new scheduled scan."""
    try:
        # Handle malformed JSON
        try:
            data = request.get_json(force=True)
        except Exception as json_error:
            return jsonify({'error': 'Invalid JSON in request body', 'details': str(json_error)}), 400

        if not data:
            return jsonify({'error': 'Request body required'}), 400

        # Validate required fields
        name = sanitize_string(data.get('name', ''))
        if not name:
            return jsonify({'error': 'Name is required'}), 400

        # Get cron schedule (support preset or custom)
        cron_preset = data.get('cron_preset')
        cron_schedule = data.get('cron_schedule')

        if cron_preset and cron_preset in CRON_PRESETS:
            cron_schedule = CRON_PRESETS[cron_preset]
        elif not cron_schedule:
            return jsonify({
                'error': 'Either cron_preset or cron_schedule is required',
                'available_presets': list(CRON_PRESETS.keys())
            }), 400

        if not validate_cron(cron_schedule):
            return jsonify({'error': 'Invalid cron expression'}), 400

        # Target configuration
        target_type = sanitize_string(data.get('target_type', 'all'), max_length=50)
        if target_type not in ('asset', 'group', 'subnet', 'all'):
            return jsonify({'error': 'Invalid target_type. Must be: asset, group, subnet, or all'}), 400

        asset_id = None
        target_config = None

        if target_type == 'asset':
            asset_id = data.get('asset_id')
            if not asset_id:
                return jsonify({'error': 'asset_id is required for target_type=asset'}), 400
        elif target_type in ('group', 'subnet'):
            target_config = data.get('target_config')
            if not target_config:
                return jsonify({'error': 'target_config is required for group/subnet targets'}), 400

        # Scan configuration
        scan_type = sanitize_string(data.get('scan_type', 'full'), max_length=50)
        if scan_type not in ('discovery', 'software_inventory', 'vulnerability_scan', 'full'):
            scan_type = 'full'

        scan_options = _normalize_scan_options(data.get('scan_options', {}))

        with session_scope() as session:
            # Validate asset exists if specified
            asset = None
            if asset_id:
                asset = session.query(Asset).filter(Asset.id == asset_id).first()
                if not asset:
                    return jsonify({'error': 'Asset not found'}), 404

            if target_type == 'asset' and asset:
                scan_options = dict(scan_options or {})
                scan_options['target_host'] = _build_target_host_snapshot(asset)
                if _requires_linked_credential(scan_options):
                    return jsonify({
                        'error': 'Credential required for authenticated asset schedules (ssh/winrm). Please link a credential before saving.'
                    }), 400
                _persist_asset_schedule_profile(asset, scan_options)

            schedule = ScheduledScan(
                uuid=str(uuid.uuid4()),
                name=name,
                target_type=target_type,
                asset_id=asset_id,
                target_config=target_config,
                scan_type=scan_type,
                scan_options=scan_options,
                cron_schedule=cron_schedule,
                is_active=data.get('is_active', True),
                timezone=sanitize_string(data.get('timezone', 'UTC'), max_length=50),
                auto_refresh_vulns=data.get('auto_refresh_vulns', True),
                sync_to_audit_tool=data.get('sync_to_audit_tool', True),
                trigger_audit_after=data.get('trigger_audit_after', False),
                notification_enabled=data.get('notification_enabled', False),
                notification_emails=data.get('notification_emails'),
                notification_webhooks=data.get('notification_webhooks'),
                created_by=sanitize_string(data.get('created_by', 'api'), max_length=255)
            )

            # Calculate next run time
            schedule.update_next_run()

            session.add(schedule)
            session.commit()

            logger.info(f"Created scheduled scan {schedule.id}: {schedule.name}")

            return jsonify({
                'success': True,
                'schedule': schedule.to_dict(),
                'message': 'Scheduled scan created'
            }), 201

    except Exception as e:
        logger.error(f"Error creating scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>', methods=['PUT'])
@require_api_key
def update_scheduled_scan(schedule_id: int):
    """Update an existing scheduled scan."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Request body required'}), 400

        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            # Update allowed fields
            if 'target_type' in data:
                incoming_target_type = sanitize_string(data.get('target_type', schedule.target_type), max_length=50)
                if incoming_target_type not in ('asset', 'group', 'subnet', 'all'):
                    return jsonify({'error': 'Invalid target_type. Must be: asset, group, subnet, or all'}), 400
                schedule.target_type = incoming_target_type

            if 'asset_id' in data:
                incoming_asset_id = data.get('asset_id')
                if incoming_asset_id in (None, ''):
                    schedule.asset_id = None
                else:
                    try:
                        incoming_asset_id = int(incoming_asset_id)
                    except (TypeError, ValueError):
                        return jsonify({'error': 'asset_id must be an integer'}), 400

                    existing_asset = session.query(Asset).filter(Asset.id == incoming_asset_id).first()
                    if not existing_asset:
                        return jsonify({'error': 'Asset not found'}), 404
                    schedule.asset_id = incoming_asset_id

            if 'target_config' in data:
                schedule.target_config = data.get('target_config')

            if 'name' in data:
                schedule.name = sanitize_string(data['name'])

            if 'cron_preset' in data:
                preset = data['cron_preset']
                if preset in CRON_PRESETS:
                    schedule.cron_schedule = CRON_PRESETS[preset]
            elif 'cron_schedule' in data:
                if validate_cron(data['cron_schedule']):
                    schedule.cron_schedule = data['cron_schedule']

            if 'is_active' in data:
                schedule.is_active = bool(data['is_active'])

            if 'scan_type' in data:
                scan_type = sanitize_string(data['scan_type'], max_length=50)
                if scan_type in ('discovery', 'software_inventory', 'vulnerability_scan', 'full'):
                    schedule.scan_type = scan_type

            if 'scan_options' in data:
                schedule.scan_options = _normalize_scan_options(data.get('scan_options'))

            if schedule.target_type == 'asset':
                if not schedule.asset_id:
                    return jsonify({'error': 'asset_id is required for target_type=asset'}), 400

                target_asset = session.query(Asset).filter(Asset.id == schedule.asset_id).first()
                if not target_asset:
                    return jsonify({'error': 'Asset not found'}), 404

                updated_scan_options = dict(schedule.scan_options or {})
                updated_scan_options['target_host'] = _build_target_host_snapshot(target_asset)
                if _requires_linked_credential(updated_scan_options):
                    return jsonify({
                        'error': 'Credential required for authenticated asset schedules (ssh/winrm). Please link a credential before saving.'
                    }), 400
                schedule.scan_options = updated_scan_options
                _persist_asset_schedule_profile(target_asset, updated_scan_options)

            if 'auto_refresh_vulns' in data:
                schedule.auto_refresh_vulns = bool(data['auto_refresh_vulns'])

            if 'sync_to_audit_tool' in data:
                schedule.sync_to_audit_tool = bool(data['sync_to_audit_tool'])

            if 'trigger_audit_after' in data:
                schedule.trigger_audit_after = bool(data['trigger_audit_after'])

            if 'notification_enabled' in data:
                schedule.notification_enabled = bool(data['notification_enabled'])

            if 'notification_emails' in data:
                schedule.notification_emails = data['notification_emails']

            if 'notification_webhooks' in data:
                schedule.notification_webhooks = data['notification_webhooks']

            # Recalculate next run if schedule changed
            schedule.update_next_run()

            session.commit()

            logger.info(f"Updated scheduled scan {schedule_id}")

            return jsonify({
                'success': True,
                'schedule': schedule.to_dict(),
                'message': 'Scheduled scan updated'
            })

    except Exception as e:
        logger.error(f"Error updating scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>', methods=['DELETE'])
@require_api_key
def delete_scheduled_scan(schedule_id: int):
    """Delete a scheduled scan."""
    try:
        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            session.delete(schedule)
            session.commit()

            logger.info(f"Deleted scheduled scan {schedule_id}")

            return jsonify({
                'success': True,
                'message': 'Scheduled scan deleted'
            })

    except Exception as e:
        logger.error(f"Error deleting scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>/toggle', methods=['POST'])
@require_api_key
def toggle_scheduled_scan(schedule_id: int):
    """Toggle a scheduled scan's active status."""
    try:
        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            schedule.is_active = not schedule.is_active
            if schedule.is_active:
                schedule.update_next_run()
            else:
                schedule.next_run = None

            session.commit()

            logger.info(f"Toggled scheduled scan {schedule_id} to active={schedule.is_active}")

            return jsonify({
                'success': True,
                'is_active': schedule.is_active,
                'next_run': schedule.next_run.isoformat() if schedule.next_run else None,
                'message': f"Scheduled scan {'enabled' if schedule.is_active else 'disabled'}"
            })

    except Exception as e:
        logger.error(f"Error toggling scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>/run', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)  # Limit expensive scan triggers
def run_scheduled_scan_now(schedule_id: int):
    """Manually trigger a scheduled scan to run immediately."""
    try:
        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            # Create execution record
            execution = ScheduledScanExecution(
                scheduled_scan_id=schedule_id,
                status='started',
                started_at=datetime.utcnow()
            )
            session.add(execution)

            # Determine targets
            targets = []
            if schedule.target_type == 'asset' and schedule.asset_id:
                asset = session.query(Asset).filter(Asset.id == schedule.asset_id).first()
                if asset:
                    targets = [asset.primary_ip or asset.hostname]
            elif schedule.target_type == 'all':
                assets = session.query(Asset).filter(Asset.status == 'active').all()
                targets = [a.primary_ip or a.hostname for a in assets if (a.primary_ip or a.hostname)]
            elif schedule.target_config:
                # Handle group/subnet targets
                if 'ips' in schedule.target_config:
                    targets = schedule.target_config['ips']
                elif 'subnet' in schedule.target_config:
                    targets = [schedule.target_config['subnet']]

            if not targets:
                execution.status = 'failed'
                execution.error_message = 'No valid targets found'
                session.commit()
                return jsonify({'error': 'No valid targets found for scan'}), 400

            scan_options = dict(schedule.scan_options or {})
            if 'credentials_id' in scan_options and 'credential_id' not in scan_options:
                scan_options['credential_id'] = scan_options.get('credentials_id')

            if schedule.target_type == 'asset' and schedule.asset_id:
                asset = session.query(Asset).filter(Asset.id == schedule.asset_id).first()
                if asset and isinstance(asset.custom_attributes, dict):
                    last_scan_profile = asset.custom_attributes.get('last_scan_profile')
                    if isinstance(last_scan_profile, dict):
                        scan_options.setdefault('discovery_method', sanitize_string(last_scan_profile.get('discovery_method', 'managed'), max_length=50))
                        scan_options.setdefault('discovery_mode', sanitize_string(last_scan_profile.get('discovery_mode', 'managed'), max_length=50))
                        scan_options.setdefault('os_type', sanitize_string(last_scan_profile.get('os_type', asset.os_type or 'auto'), max_length=50))
                        if scan_options.get('credential_id') is None and last_scan_profile.get('credential_id') is not None:
                            scan_options['credential_id'] = last_scan_profile.get('credential_id')
                        if not isinstance(scan_options.get('scope'), dict) and isinstance(last_scan_profile.get('scope'), dict):
                            scan_options['scope'] = last_scan_profile.get('scope')
                        port = last_scan_profile.get('port')
                        if port is not None:
                            credential_metadata = scan_options.get('credential_metadata') if isinstance(scan_options.get('credential_metadata'), dict) else {}
                            credential_metadata['port'] = port
                            scan_options['credential_metadata'] = credential_metadata

            # Create scan job
            scan_job = ScanJob(
                uuid=str(uuid.uuid4()),
                job_type=schedule.scan_type,
                status='pending',
                targets=targets,
                total_targets=len(targets),
                config={
                    'scheduled_scan_id': schedule_id,
                    'execution_id': execution.id,
                    'auto_refresh_vulns': schedule.auto_refresh_vulns,
                    'sync_to_audit_tool': schedule.sync_to_audit_tool,
                    'trigger_audit_after': schedule.trigger_audit_after,
                    **scan_options
                },
                created_by=f'scheduled:{schedule.name}'
            )
            session.add(scan_job)
            session.flush()

            execution.scan_job_id = scan_job.id
            execution.targets_scanned = len(targets)

            # Update schedule tracking
            schedule.last_run = datetime.utcnow()
            schedule.last_status = 'running'
            schedule.last_scan_id = scan_job.id
            schedule.run_count += 1

            session.commit()

            logger.info(f"Manually triggered scheduled scan {schedule_id}, created job {scan_job.id}")

            return jsonify({
                'success': True,
                'scan_job_id': scan_job.id,
                'execution_id': execution.id,
                'targets_count': len(targets),
                'message': 'Scheduled scan triggered'
            })

    except Exception as e:
        logger.error(f"Error running scheduled scan: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/<int:schedule_id>/executions', methods=['GET'])
@require_api_key
def get_scan_executions(schedule_id: int):
    """Get execution history for a scheduled scan."""
    try:
        limit = request.args.get('limit', 20, type=int)
        limit = min(max(limit, 1), 100)

        with session_scope() as session:
            schedule = session.query(ScheduledScan).filter(
                ScheduledScan.id == schedule_id
            ).first()

            if not schedule:
                return jsonify({'error': 'Scheduled scan not found'}), 404

            executions = session.query(ScheduledScanExecution).filter(
                ScheduledScanExecution.scheduled_scan_id == schedule_id
            ).order_by(ScheduledScanExecution.started_at.desc()).limit(limit).all()

            return jsonify({
                'success': True,
                'schedule_id': schedule_id,
                'schedule_name': schedule.name,
                'executions': [e.to_dict() for e in executions],
                'total': len(executions)
            })

    except Exception as e:
        logger.error(f"Error getting scan executions: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/presets', methods=['GET'])
@require_api_key
def get_cron_presets():
    """Get available cron presets."""
    presets = []
    for key, cron in CRON_PRESETS.items():
        # Create a temp schedule to get description
        temp = ScheduledScan(cron_schedule=cron)
        presets.append({
            'key': key,
            'cron': cron,
            'description': temp.get_cron_description()
        })

    return jsonify({
        'success': True,
        'presets': presets
    })


@scheduled_scans_bp.route('/sync/status', methods=['GET'])
@require_api_key
def get_sync_status():
    """Get cross-tool sync service status (Direct SQL mode)."""
    try:
        sync_service = get_sync_service()
        connected, message = sync_service.check_connection()

        return jsonify({
            'success': True,
            'sync_enabled': sync_service.config.sync_enabled,
            'sync_mode': 'direct_sql',  # New: indicates direct SQL sync (not HTTP)
            'database_connected': connected,
            'connection_message': message,
            'features': {
                'sync_assets': sync_service.config.sync_assets,
                'sync_vulnerabilities': sync_service.config.sync_vulnerabilities,
                'sync_on_scan_complete': sync_service.config.sync_on_scan_complete,
                'auto_create_servers': sync_service.config.auto_create_servers,
                'trigger_audit_on_new_asset': sync_service.config.trigger_audit_on_new_asset
            },
            'performance_note': 'Direct SQL sync: ~1-5ms per operation (10-40x faster than HTTP)'
        })
    except Exception as e:
        logger.error(f"Error getting sync status: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/sync/assets', methods=['POST'])
@require_api_key
@rate_limit(max_requests=5, window_seconds=60)  # Limit expensive sync operations
def sync_all_assets_to_audit_tool():
    """Manually sync all assets to the main audit tool."""
    try:
        sync_service = get_sync_service()
        result = sync_service.sync_all_assets()

        return jsonify({
            'success': result.success,
            'synced_count': result.synced_count,
            'created_count': result.created_count,
            'updated_count': result.updated_count,
            'failed_count': result.failed_count,
            'errors': result.errors[:10] if result.errors else [],  # Limit error count
            'message': f"Synced {result.synced_count} assets to audit tool"
        })
    except Exception as e:
        logger.error(f"Error syncing assets: {e}")
        return jsonify({'error': str(e)}), 500


@scheduled_scans_bp.route('/due', methods=['GET'])
@require_api_key
def get_due_scans():
    """Get scheduled scans that are due to run."""
    try:
        with session_scope() as session:
            now = datetime.utcnow()
            due_scans = session.query(ScheduledScan).filter(
                ScheduledScan.is_active.is_(True),
                ScheduledScan.next_run <= now
            ).all()

            return jsonify({
                'success': True,
                'due_scans': [s.to_dict() for s in due_scans],
                'count': len(due_scans),
                'checked_at': now.isoformat()
            })
    except Exception as e:
        logger.error(f"Error getting due scans: {e}")
        return jsonify({'error': str(e)}), 500
