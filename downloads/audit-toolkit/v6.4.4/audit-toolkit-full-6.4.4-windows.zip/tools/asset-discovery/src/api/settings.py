# Asset Discovery - Settings API
#
# API endpoints for managing scheduler and sync settings

import logging
import os
from flask import Blueprint, request, jsonify

from ..scheduler import get_scheduler
from ..models.base import session_scope
from ..security import require_api_key, sanitize_string, rate_limit

logger = logging.getLogger('api.settings')

settings_bp = Blueprint('settings', __name__)


# NOTE: sanitize_string is imported from security.py for centralized OWASP-compliant sanitization


@settings_bp.route('/scheduler/status', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_scheduler_status():
    """Get status of all scheduled jobs."""
    try:
        scheduler = get_scheduler()
        status = scheduler.get_job_status()

        return jsonify({
            'success': True,
            'scheduler_running': scheduler.running,
            'jobs': status
        })
    except Exception as e:
        logger.error(f"Failed to get scheduler status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/scheduler/job/<job_id>', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def get_job_status(job_id: str):
    """Get status of a specific job."""
    job_id = sanitize_string(job_id, 50)

    try:
        scheduler = get_scheduler()
        status = scheduler.get_job_status(job_id)

        if not status:
            return jsonify({
                'success': False,
                'error': f"Job '{job_id}' not found"
            }), 404

        return jsonify({
            'success': True,
            'job': status
        })
    except Exception as e:
        logger.error(f"Failed to get job status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/scheduler/job/<job_id>', methods=['PUT', 'PATCH'])
@require_api_key
@rate_limit(max_requests=30, window_seconds=60)
def update_job_settings(job_id: str):
    """Update job settings (interval, enabled)."""
    job_id = sanitize_string(job_id, 50)
    data = request.get_json() or {}

    try:
        scheduler = get_scheduler()

        # Validate inputs
        interval_hours = data.get('interval_hours')
        enabled = data.get('enabled')

        if interval_hours is not None:
            interval_hours = int(interval_hours)
            if interval_hours < 1 or interval_hours > 168:  # 1 hour to 1 week
                return jsonify({
                    'success': False,
                    'error': 'interval_hours must be between 1 and 168'
                }), 400

        if enabled is not None:
            enabled = bool(enabled)

        scheduler.update_job(job_id, interval_hours=interval_hours, enabled=enabled)

        return jsonify({
            'success': True,
            'message': f"Job '{job_id}' updated",
            'job': scheduler.get_job_status(job_id)
        })
    except ValueError as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 404
    except Exception as e:
        logger.error(f"Failed to update job: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/scheduler/job/<job_id>/run', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)
def run_job_now(job_id: str):
    """Manually trigger a job to run immediately."""
    job_id = sanitize_string(job_id, 50)

    try:
        scheduler = get_scheduler()
        scheduler.run_job_now(job_id)

        return jsonify({
            'success': True,
            'message': f"Job '{job_id}' triggered"
        })
    except ValueError as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 404
    except Exception as e:
        logger.error(f"Failed to run job: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/sync/cve', methods=['POST'])
@require_api_key
@rate_limit(max_requests=5, window_seconds=60)
def trigger_cve_sync():
    """Trigger ad-hoc CVE sync (can be disabled via environment policy)."""
    allow_adhoc = os.environ.get('CVE_SYNC_ALLOW_ADHOC', 'true').lower() in ('true', '1', 'yes')

    if not allow_adhoc:
        return jsonify({
            'success': False,
            'error': 'Ad-hoc CVE sync is disabled. Configure nightly schedule time instead.',
            'hint': 'Use Settings → CVE Sync Time (UTC) and enable automatic sync.'
        }), 409

    try:
        scheduler = get_scheduler()
        scheduler.run_job_now('cve_sync')

        return jsonify({
            'success': True,
            'message': 'CVE sync triggered'
        })
    except Exception as e:
        logger.error(f"Failed to trigger CVE sync: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/sync/settings', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_sync_settings():
    """Get current sync settings."""
    try:
        scheduler = get_scheduler()

        cve_sync = scheduler.get_job_status('cve_sync')
        vuln_rematch = scheduler.get_job_status('vulnerability_rematch')

        return jsonify({
            'success': True,
            'settings': {
                'cve_sync': {
                    'enabled': cve_sync.get('enabled', False) if cve_sync else False,
                    'interval_hours': cve_sync.get('interval_hours', 24) if cve_sync else 24,
                    'run_time_utc': cve_sync.get('run_time_utc', '02:00') if cve_sync else '02:00',
                    'last_run': cve_sync.get('last_run') if cve_sync else None,
                    'next_run': cve_sync.get('next_run') if cve_sync else None,
                    'run_count': cve_sync.get('run_count', 0) if cve_sync else 0,
                    'last_error': cve_sync.get('last_error') if cve_sync else None
                },
                'vulnerability_rematch': {
                    'enabled': vuln_rematch.get('enabled', False) if vuln_rematch else False,
                    'interval_hours': vuln_rematch.get('interval_hours', 48) if vuln_rematch else 48,
                    'last_run': vuln_rematch.get('last_run') if vuln_rematch else None,
                    'next_run': vuln_rematch.get('next_run') if vuln_rematch else None
                }
            }
        })
    except Exception as e:
        logger.error(f"Failed to get sync settings: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/sync/settings', methods=['PUT', 'PATCH'])
@require_api_key
@rate_limit(max_requests=20, window_seconds=60)
def update_sync_settings():
    """Update sync settings."""
    data = request.get_json() or {}

    try:
        scheduler = get_scheduler()
        updated = []

        # Update CVE sync settings
        if 'cve_sync' in data:
            cve_settings = data['cve_sync']
            enabled = cve_settings.get('enabled')
            run_time_utc = sanitize_string(cve_settings.get('run_time_utc', ''), max_length=5)

            # Enforce nightly cadence for CVE completeness/alignment workflow.
            interval = 24
            if run_time_utc:
                if len(run_time_utc) != 5 or run_time_utc[2] != ':':
                    return jsonify({
                        'success': False,
                        'error': 'run_time_utc must be in HH:MM format (UTC)'
                    }), 400
                try:
                    hh = int(run_time_utc[0:2])
                    mm = int(run_time_utc[3:5])
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': 'run_time_utc must be numeric HH:MM (UTC)'
                    }), 400
                if hh < 0 or hh > 23 or mm < 0 or mm > 59:
                    return jsonify({
                        'success': False,
                        'error': 'run_time_utc must be a valid 24-hour UTC time'
                    }), 400
            else:
                run_time_utc = '02:00'

            try:
                scheduler.update_job('cve_sync', interval_hours=interval, enabled=enabled, run_time_utc=run_time_utc)
                updated.append('cve_sync')
            except ValueError:
                pass  # Job doesn't exist yet

        # Update vulnerability re-match settings
        if 'vulnerability_rematch' in data:
            vuln_settings = data['vulnerability_rematch']
            interval = vuln_settings.get('interval_hours')
            enabled = vuln_settings.get('enabled')

            if interval is not None:
                interval = int(interval)
                if interval < 1 or interval > 336:  # Up to 2 weeks
                    return jsonify({
                        'success': False,
                        'error': 'Vulnerability re-match interval must be between 1 and 336 hours'
                    }), 400

            try:
                scheduler.update_job('vulnerability_rematch', interval_hours=interval, enabled=enabled)
                updated.append('vulnerability_rematch')
            except ValueError:
                pass

        return jsonify({
            'success': True,
            'message': f"Updated settings: {', '.join(updated)}",
            'updated': updated
        })
    except Exception as e:
        logger.error(f"Failed to update sync settings: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/rematch/trigger', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)
def trigger_vulnerability_rematch():
    """Manually trigger vulnerability re-matching for all assets."""
    try:
        from ..vulnerability_matcher import rematch_all_assets

        # Run asynchronously
        import threading
        thread = threading.Thread(target=rematch_all_assets, daemon=True)
        thread.start()

        return jsonify({
            'success': True,
            'message': 'Vulnerability re-match triggered'
        })
    except Exception as e:
        logger.error(f"Failed to trigger vulnerability re-match: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/rematch/asset/<int:asset_id>', methods=['POST'])
@require_api_key
@rate_limit(max_requests=20, window_seconds=60)
def trigger_asset_rematch(asset_id: int):
    """Trigger vulnerability re-matching for a specific asset."""
    try:
        from ..vulnerability_matcher import update_asset_vulnerabilities

        with session_scope() as session:
            stats = update_asset_vulnerabilities(asset_id, session)

        if 'error' in stats:
            return jsonify({
                'success': False,
                'error': stats['error']
            }), 404

        return jsonify({
            'success': True,
            'message': f"Re-matched vulnerabilities for asset {asset_id}",
            'stats': stats
        })
    except Exception as e:
        logger.error(f"Failed to re-match asset {asset_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==============================================================================
# Bi-Directional Server Sync - Import Servers from Main Tool
# ==============================================================================

@settings_bp.route('/sync/servers', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)
def sync_servers_from_main_tool_endpoint():
    """
    Import servers from the main Security Audit Toolkit into Asset Discovery.

    This provides bi-directional sync - servers created in the main tool
    automatically become assets in Asset Discovery.

    Request Body (optional):
        {
            "connection_method": "ssh",  # Filter: ssh, winrm, api
            "limit": 100                  # Max servers per batch
        }

    Response:
        {
            "success": true,
            "created": 5,
            "updated": 3,
            "failed": 0,
            "errors": []
        }
    """
    try:
        from ..sync_service import sync_servers_from_main_tool

        data = request.get_json() or {}
        connection_method = data.get('connection_method')
        limit = int(data.get('limit', 100))

        # Validate connection_method
        if connection_method and connection_method not in ['ssh', 'winrm', 'api']:
            return jsonify({
                'success': False,
                'error': 'connection_method must be ssh, winrm, or api'
            }), 400

        # Validate limit
        if limit < 1 or limit > 1000:
            return jsonify({
                'success': False,
                'error': 'limit must be between 1 and 1000'
            }), 400

        # Perform sync
        result = sync_servers_from_main_tool(
            connection_method=connection_method,
            limit=limit
        )

        return jsonify({
            'success': result.success,
            'created': result.created_count,
            'updated': result.updated_count,
            'failed': result.failed_count,
            'total': result.synced_count,
            'errors': result.errors
        })

    except Exception as e:
        logger.error(f"Failed to sync servers from main tool: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/sync/credentials/<int:asset_id>', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_asset_credentials(asset_id: int):
    """
    Retrieve credentials for an asset from the main tool's encrypted keystore.

    This allows Asset Discovery to access SSH passwords, API tokens, and
    agent keys stored in the main tool's keystore for connection testing.

    Response:
        {
            "server_id": 1,
            "server_name": "web-01",
            "hostname": "192.168.1.10",
            "credentials": {
                "ssh_password": "encrypted-password",
                "api_token": "api-token-value",
                "agent_key": "agent-key-value"
            },
            "connection_method": "ssh",
            "elevation_method": "sudo",
            "execution_mode": "stream",
            "jea_endpoint": null
        }
    """
    try:
        from ..sync_service import sync_server_credentials

        creds = sync_server_credentials(asset_id)

        if 'error' in creds:
            return jsonify({
                'success': False,
                'error': creds['error']
            }), 404

        return jsonify({
            'success': True,
            **creds
        })

    except Exception as e:
        logger.error(f"Failed to get credentials for asset {asset_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@settings_bp.route('/sync/status', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def get_sync_status():
    """
    Get status of bi-directional sync between Asset Discovery and main tool.

    Response:
        {
            "success": true,
            "main_tool_connected": true,
            "main_tool_url": "http://localhost:5000",
            "total_assets": 50,
            "assets_synced_from_main_tool": 30,
            "keystore_client_enabled": true
        }
    """
    try:
        from ..sync_service import get_sync_service
        from ..keystore_client import get_keystore_client
        from ..models.asset import Asset

        sync_service = get_sync_service()
        keystore_client = get_keystore_client()

        # Check main tool connection
        connected, message = sync_service.check_connection()

        # Count assets
        with session_scope() as session:
            total_assets = session.query(Asset).count()
            synced_assets = session.query(Asset).filter(
                Asset.custom_attributes.op('->>')('synced_from_main_tool') == 'true'
            ).count()

        return jsonify({
            'success': True,
            'main_tool_connected': connected,
            'main_tool_url': keystore_client.main_tool_url,
            'connection_message': message,
            'total_assets': total_assets,
            'assets_synced_from_main_tool': synced_assets,
            'keystore_client_enabled': keystore_client.enabled,
            'keystore_client_stats': keystore_client.get_stats()
        })

    except Exception as e:
        logger.error(f"Failed to get sync status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

