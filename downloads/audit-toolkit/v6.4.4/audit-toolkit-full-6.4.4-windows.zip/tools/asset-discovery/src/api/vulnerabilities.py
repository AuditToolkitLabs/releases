# Vulnerabilities API Blueprint

import logging
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request

from ..models.base import session_scope
from ..models.vulnerability import CVERecord, SoftwareVulnerability
from ..models.software import InstalledSoftware
from ..models.asset import Asset
from ..security import (
    validate_pagination, get_safe_search_param, sanitize_string,
    validate_cve_id, rate_limit, audit_log, safe_error_response,
    MAX_PAGE_SIZE, require_api_key
)
from ..cve_sync import NVDSync

logger = logging.getLogger(__name__)
vulnerabilities_bp = Blueprint('vulnerabilities', __name__)


def _best_cvss_score(cve: CVERecord) -> float:
    """Return the best available CVSS score (v3 preferred, then v2)."""
    if cve.cvss_v3_score is not None:
        return float(cve.cvss_v3_score)
    if cve.cvss_v2_score is not None:
        return float(cve.cvss_v2_score)
    return 0.0


def _is_cve_incomplete(cve: CVERecord) -> bool:
    """Determine whether a CVE record lacks key display fields."""
    return cve.published_date is None or (
        cve.cvss_v3_score is None and cve.cvss_v2_score is None
    )


def _enrich_cve_from_nvd(cve: CVERecord, syncer: NVDSync) -> bool:
    """Fetch and merge missing CVE fields from NVD for a single record."""
    enriched = syncer.fetch_single_cve(cve.cve_id)
    if not enriched:
        return False

    cve.description = enriched.get('description') or cve.description
    cve.cvss_v3_severity = enriched.get('cvss_v3_severity') or cve.cvss_v3_severity
    cve.cvss_v3_score = enriched.get('cvss_v3_score') if enriched.get('cvss_v3_score') is not None else cve.cvss_v3_score
    cve.cvss_v3_vector = enriched.get('cvss_v3_vector') or cve.cvss_v3_vector
    cve.cvss_v2_score = enriched.get('cvss_v2_score') if enriched.get('cvss_v2_score') is not None else cve.cvss_v2_score
    cve.exploitability_score = (
        enriched.get('exploitability_score')
        if enriched.get('exploitability_score') is not None
        else cve.exploitability_score
    )
    cve.impact_score = (
        enriched.get('impact_score')
        if enriched.get('impact_score') is not None
        else cve.impact_score
    )
    cve.attack_vector = enriched.get('attack_vector') or cve.attack_vector
    cve.attack_complexity = enriched.get('attack_complexity') or cve.attack_complexity
    cve.privileges_required = enriched.get('privileges_required') or cve.privileges_required
    cve.user_interaction = enriched.get('user_interaction') or cve.user_interaction
    cve.scope = enriched.get('scope') or cve.scope
    if cve.published_date is None:
        cve.published_date = syncer.parse_nvd_datetime(enriched.get('published_date'))
    cve.last_modified = syncer.parse_nvd_datetime(enriched.get('last_modified')) or cve.last_modified
    cve.references = enriched.get('references') or cve.references or []
    cve.cwe_ids = enriched.get('cwe_ids') or cve.cwe_ids or []

    return True


def _string_or_fallback(value, fallback: str = 'N/A') -> str:
    """Return a non-empty display string for nullable values."""
    if value is None:
        return fallback
    text = str(value).strip()
    return text if text else fallback


def _build_remediation_recommendations(
    *,
    cve: CVERecord,
    software_name: str = None,
    software_version: str = None,
    fixed_version: str = None,
    remediation_notes: str = None,
) -> list[str]:
    """Generate actionable recommendations for a CVE and affected software entry."""
    recommendations = []

    target_name = software_name or 'the affected software'
    if fixed_version:
        recommendations.append(f"Upgrade {target_name} to {fixed_version} or later.")
    elif software_version:
        recommendations.append(f"Update {target_name} from version {software_version} to the latest patched release.")
    else:
        recommendations.append(f"Update {target_name} to the latest patched release.")

    if cve.cisa_kev:
        if cve.cisa_due_date:
            recommendations.append(f"Known Exploited Vulnerability (KEV): remediate by {cve.cisa_due_date.isoformat()}.")
        else:
            recommendations.append("Known Exploited Vulnerability (KEV): prioritize immediate remediation.")

    if (cve.attack_vector or '').upper() == 'NETWORK':
        recommendations.append("Apply temporary network controls (segmentation, ACLs, or firewall restrictions) until patched.")
    elif (cve.attack_vector or '').upper() == 'LOCAL':
        recommendations.append("Limit local access to privileged users until patching is complete.")

    if remediation_notes:
        recommendations.append(_string_or_fallback(remediation_notes, fallback=''))

    deduped = []
    for rec in recommendations:
        clean_rec = rec.strip()
        if clean_rec and clean_rec not in deduped:
            deduped.append(clean_rec)

    return deduped


def _build_sync_correlation_payload(
    *,
    requested: bool,
    status: str,
    started_at: datetime = None,
    completed_at: datetime = None,
    stats: dict = None,
    reason: str = None,
    error: str = None,
) -> dict:
    """Build deterministic vulnerability correlation lifecycle payload for CVE sync responses."""
    payload = {
        'source': 'cve_sync',
        'requested': bool(requested),
        'status': status,
    }
    if started_at:
        payload['started_at'] = started_at.isoformat()
    if completed_at:
        payload['completed_at'] = completed_at.isoformat()
    if stats is not None:
        payload['stats'] = stats
    if reason:
        payload['reason'] = reason
    if error:
        payload['error'] = error
    return payload


@vulnerabilities_bp.route('/cves', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def list_cves():
    """List CVE records with filtering."""
    try:
        # Validate and sanitize inputs
        severity = sanitize_string(request.args.get('severity', ''), max_length=20).upper()
        if severity and severity not in ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'):
            severity = ''  # Invalid severity, ignore

        search = get_safe_search_param('search')
        kev_only = request.args.get('kev_only', 'false').lower() == 'true'
        refresh_incomplete = request.args.get('refresh', 'true').strip().lower() == 'true'

        page, per_page = validate_pagination(
            request.args.get('page', 1, type=int),
            request.args.get('per_page', 50, type=int)
        )

        with session_scope() as session:
            query = session.query(CVERecord).order_by(CVERecord.published_date.desc())

            if severity:
                query = query.filter(CVERecord.cvss_v3_severity == severity)
            if search:
                query = query.filter(CVERecord.cve_id.ilike(f'%{search}%', escape='\\'))
            if kev_only:
                query = query.filter(CVERecord.cisa_kev.is_(True))

            total = query.count()
            cves = query.offset((page - 1) * per_page).limit(per_page).all()

            if refresh_incomplete and cves:
                syncer = NVDSync()
                updated = 0
                refresh_budget = min(25, len(cves))
                for cve in cves:
                    if updated >= refresh_budget:
                        break
                    if not _is_cve_incomplete(cve):
                        continue
                    if _enrich_cve_from_nvd(cve, syncer):
                        updated += 1
                if updated > 0:
                    session.commit()

            return jsonify({
                'total': total,
                'page': page,
                'per_page': per_page,
                'max_per_page': MAX_PAGE_SIZE,
                'cves': [cve_to_dict(c) for c in cves]
            })
    except Exception as e:
        return safe_error_response(e, 500)


@vulnerabilities_bp.route('/cves/<cve_id>', methods=['GET'])
@require_api_key
@rate_limit(max_requests=200, window_seconds=60)
def get_cve(cve_id: str):
    """Get details for a specific CVE."""
    try:
        # Validate CVE ID format
        validated_cve_id = validate_cve_id(cve_id)
        if not validated_cve_id:
            return jsonify({'error': 'Invalid CVE ID format'}), 400

        with session_scope() as session:
            cve = session.query(CVERecord).filter(CVERecord.cve_id == validated_cve_id).first()
            if not cve:
                return jsonify({'error': 'CVE not found'}), 404

            if _is_cve_incomplete(cve):
                syncer = NVDSync()
                if _enrich_cve_from_nvd(cve, syncer):
                    session.commit()

            audit_log('read', 'cve', validated_cve_id)
            return jsonify(cve_to_dict(cve, detailed=True))
    except Exception as e:
        return safe_error_response(e, 500)


@vulnerabilities_bp.route('/cves/<cve_id>/impact', methods=['GET'])
@require_api_key
@rate_limit(max_requests=200, window_seconds=60)
def get_cve_impact(cve_id: str):
    """Get server-level drill-down for a CVE, including recommendations."""
    try:
        validated_cve_id = validate_cve_id(cve_id)
        if not validated_cve_id:
            return jsonify({'error': 'Invalid CVE ID format'}), 400

        refresh = request.args.get('refresh', 'true').strip().lower() == 'true'
        refresh_errors = []

        with session_scope() as session:
            cve = session.query(CVERecord).filter(CVERecord.cve_id == validated_cve_id).first()
            if not cve:
                return jsonify({'error': 'CVE not found'}), 404

            if refresh:
                from ..vulnerability_matcher import update_asset_vulnerabilities

                asset_ids = session.query(SoftwareVulnerability.asset_id).filter(
                    SoftwareVulnerability.cve_id == validated_cve_id
                ).distinct().all()

                for (asset_id,) in asset_ids:
                    try:
                        update_asset_vulnerabilities(asset_id, session)
                    except Exception as refresh_error:
                        refresh_errors.append(f"asset {asset_id}: {refresh_error}")

            rows = session.query(SoftwareVulnerability, InstalledSoftware, Asset).join(
                InstalledSoftware,
                SoftwareVulnerability.software_id == InstalledSoftware.id
            ).join(
                Asset,
                SoftwareVulnerability.asset_id == Asset.id
            ).filter(
                SoftwareVulnerability.cve_id == validated_cve_id
            ).order_by(
                Asset.hostname.asc(),
                InstalledSoftware.name.asc()
            ).all()

            affected_assets = []
            aggregated_recommendations = []
            status_counts = {}

            for vuln, software, asset in rows:
                status_key = (vuln.status or 'unknown').lower()
                status_counts[status_key] = status_counts.get(status_key, 0) + 1

                recommendations = _build_remediation_recommendations(
                    cve=cve,
                    software_name=software.name,
                    software_version=software.version,
                    fixed_version=vuln.fixed_version,
                    remediation_notes=vuln.remediation_notes,
                )
                for rec in recommendations:
                    if rec not in aggregated_recommendations:
                        aggregated_recommendations.append(rec)

                affected_assets.append({
                    'asset_id': asset.id,
                    'hostname': _string_or_fallback(asset.hostname),
                    'primary_ip': _string_or_fallback(asset.primary_ip),
                    'os_name': _string_or_fallback(asset.os_name),
                    'software_id': software.id,
                    'software_name': _string_or_fallback(software.name),
                    'software_version': _string_or_fallback(software.version),
                    'match_confidence': _string_or_fallback(vuln.match_confidence, fallback='unknown'),
                    'status': _string_or_fallback(vuln.status, fallback='unknown'),
                    'detected_at': vuln.detected_at.isoformat() if vuln.detected_at else '',
                    'resolved_at': vuln.resolved_at.isoformat() if vuln.resolved_at else '',
                    'fixed_version': _string_or_fallback(vuln.fixed_version, fallback='N/A'),
                    'remediation_notes': _string_or_fallback(vuln.remediation_notes, fallback=''),
                    'recommendations': recommendations,
                })

            return jsonify({
                'cve_id': validated_cve_id,
                'refresh_requested': refresh,
                'refresh_errors': refresh_errors,
                'affected_asset_count': len({item['asset_id'] for item in affected_assets}),
                'affected_software_count': len(affected_assets),
                'status_counts': status_counts,
                'affected_assets': affected_assets,
                'recommendations': aggregated_recommendations,
            })
    except Exception as e:
        return safe_error_response(e, 500)


@vulnerabilities_bp.route('/affects', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def list_affected_software():
    """List software with known vulnerabilities."""
    severity = sanitize_string(request.args.get('min_severity', ''), max_length=20).upper()
    if severity and severity not in ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'):
        severity = ''  # Invalid severity, ignore

    # SECURITY: Use validate_pagination to prevent DoS via large page sizes
    page, per_page = validate_pagination(
        request.args.get('page', 1, type=int),
        request.args.get('per_page', 50, type=int)
    )

    with session_scope() as session:
        query = session.query(SoftwareVulnerability).join(CVERecord)

        if severity:
            severity_order = {'LOW': 1, 'MEDIUM': 2, 'HIGH': 3, 'CRITICAL': 4}
            min_level = severity_order.get(severity, 1)  # severity already uppercased
            query = query.filter(
                CVERecord.cvss_v3_severity.in_(
                    [s for s, v in severity_order.items() if v >= min_level]
                )
            )

        total = query.count()
        vulns = query.offset((page - 1) * per_page).limit(per_page).all()

        return jsonify({
            'total': total,
            'page': page,
            'per_page': per_page,
            'affected_software': [
                {
                    'software_id': v.software_id,
                    'software_name': v.software.name if v.software else None,
                    'software_version': v.software.version if v.software else None,
                    'cve_id': v.cve_id,
                    'severity': v.cve.cvss_v3_severity if v.cve else None,
                    'cvss_score': float(v.cve.cvss_v3_score) if v.cve and v.cve.cvss_v3_score else None,
                    'status': v.status,
                    'asset_id': v.software.asset_id if v.software else None
                }
                for v in vulns
            ]
        })


@vulnerabilities_bp.route('/assets/<int:asset_id>', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def get_asset_vulnerabilities(asset_id: int):
    """Get vulnerabilities affecting a specific asset with drill-down details.

    Query params:
    - status: open|all (default: open)
    - refresh: true|false (default: false) - recompute correlation before returning
    - page / per_page
    """
    status_filter = sanitize_string(request.args.get('status', 'open'), max_length=20).lower()
    if status_filter not in ('open', 'all'):
        status_filter = 'open'

    refresh = request.args.get('refresh', 'false').strip().lower() == 'true'
    page, per_page = validate_pagination(
        request.args.get('page', 1, type=int),
        request.args.get('per_page', 100, type=int)
    )

    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        if refresh:
            from ..vulnerability_matcher import update_asset_vulnerabilities
            try:
                update_asset_vulnerabilities(asset_id, session)
            except Exception as refresh_error:
                logger.error("Asset vulnerability refresh failed for asset %s: %s", asset_id, refresh_error)

        query = session.query(SoftwareVulnerability, CVERecord, InstalledSoftware).join(
            CVERecord, SoftwareVulnerability.cve_id == CVERecord.cve_id
        ).join(
            InstalledSoftware, SoftwareVulnerability.software_id == InstalledSoftware.id
        ).filter(
            SoftwareVulnerability.asset_id == asset_id
        )

        if status_filter != 'all':
            query = query.filter(SoftwareVulnerability.status == 'open')

        rows = query.all()

        severity_rank = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}
        rows_sorted = sorted(
            rows,
            key=lambda row: (
                severity_rank.get((row[1].cvss_v3_severity or 'LOW').upper(), 4),
                -float(row[1].cvss_v3_score or 0),
                row[1].published_date or datetime.min,
                row[1].cve_id or ''
            ),
            reverse=False
        )

        total = len(rows_sorted)
        start = (page - 1) * per_page
        end = start + per_page
        page_rows = rows_sorted[start:end]

        # Group by severity
        by_severity = {
            'CRITICAL': [],
            'HIGH': [],
            'MEDIUM': [],
            'LOW': []
        }

        for vuln, cve, software in rows_sorted:
            severity = (cve.cvss_v3_severity or 'LOW').upper()
            if severity not in by_severity:
                severity = 'LOW'

            by_severity[severity].append({
                'id': vuln.id,
                'cve_id': cve.cve_id,
                'software': software.name,
                'version': software.version,
                'cvss_score': float(cve.cvss_v3_score) if cve.cvss_v3_score else None,
                'status': vuln.status,
                'published_date': cve.published_date.isoformat() if cve.published_date else None,
                'description': cve.description
            })

        vulnerabilities = []
        for vuln, cve, software in page_rows:
            vulnerabilities.append({
                'id': vuln.id,
                'asset_id': vuln.asset_id,
                'software_id': software.id,
                'software_name': software.name,
                'software_version': software.version,
                'software_publisher': software.publisher,
                'software_package_type': software.package_type,
                'software_architecture': software.architecture,
                'cve_id': cve.cve_id,
                'description': cve.description,
                'published_date': cve.published_date.isoformat() if cve.published_date else None,
                'last_modified': cve.last_modified.isoformat() if cve.last_modified else None,
                'cvss_v3_score': float(cve.cvss_v3_score) if cve.cvss_v3_score else 0.0,
                'cvss_v3_severity': _string_or_fallback(cve.cvss_v3_severity, fallback='UNKNOWN'),
                'cvss_v3_vector': _string_or_fallback(cve.cvss_v3_vector),
                'cvss_v2_score': float(cve.cvss_v2_score) if cve.cvss_v2_score else 0.0,
                'attack_vector': _string_or_fallback(cve.attack_vector),
                'attack_complexity': _string_or_fallback(cve.attack_complexity),
                'privileges_required': _string_or_fallback(cve.privileges_required),
                'user_interaction': _string_or_fallback(cve.user_interaction),
                'scope': _string_or_fallback(cve.scope),
                'exploitability_score': float(cve.exploitability_score) if cve.exploitability_score else 0.0,
                'impact_score': float(cve.impact_score) if cve.impact_score else 0.0,
                'is_kev': bool(cve.cisa_kev),
                'kev_due_date': cve.cisa_due_date.isoformat() if cve.cisa_due_date else None,
                'references': cve.references or [],
                'cwe_ids': cve.cwe_ids or [],
                'match_confidence': vuln.match_confidence,
                'status': vuln.status,
                'detected_at': vuln.detected_at.isoformat() if vuln.detected_at else None,
                'resolved_at': vuln.resolved_at.isoformat() if vuln.resolved_at else None,
                'fixed_version': vuln.fixed_version,
                'remediation_notes': vuln.remediation_notes,
            })

        return jsonify({
            'asset_id': asset_id,
            'hostname': asset.hostname,
            'status_filter': status_filter,
            'refresh_applied': refresh,
            'total_vulnerabilities': total,
            'page': page,
            'per_page': per_page,
            'by_severity': by_severity,
            'vulnerabilities': vulnerabilities,
            'summary': {
                'critical': len(by_severity['CRITICAL']),
                'high': len(by_severity['HIGH']),
                'medium': len(by_severity['MEDIUM']),
                'low': len(by_severity['LOW'])
            }
        })


@vulnerabilities_bp.route('/scan/<int:asset_id>', methods=['POST'])
@require_api_key
@rate_limit(max_requests=20, window_seconds=60)  # Limit expensive vulnerability scans
def scan_asset_vulnerabilities(asset_id: int):
    """Trigger vulnerability scan for an asset's software."""
    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return jsonify({'error': 'Asset not found'}), 404

        # Get installed software with CPE strings
        software = session.query(InstalledSoftware).filter(
            InstalledSoftware.asset_id == asset_id,
            InstalledSoftware.cpe.isnot(None)
        ).all()

        matches_found = 0
        for sw in software:
            # Find matching CVEs
            cves = session.query(CVERecord).filter(
                CVERecord.cpe_matches.any(cpe=sw.cpe)
            ).all()

            for cve in cves:
                # Check if vulnerability already recorded
                existing = session.query(SoftwareVulnerability).filter(
                    SoftwareVulnerability.software_id == sw.id,
                    SoftwareVulnerability.cve_id == cve.cve_id
                ).first()

                if not existing:
                    vuln = SoftwareVulnerability(
                        software_id=sw.id,
                        cve_id=cve.cve_id,
                        status='open',
                        detected_at=datetime.utcnow()
                    )
                    session.add(vuln)
                    matches_found += 1

        session.commit()

        return jsonify({
            'asset_id': asset_id,
            'software_scanned': len(software),
            'new_vulnerabilities_found': matches_found,
            'message': 'Vulnerability scan completed'
        })


@vulnerabilities_bp.route('/kev', methods=['GET'])
@require_api_key
@rate_limit(max_requests=100, window_seconds=60)
def list_kev():
    """List Known Exploited Vulnerabilities (CISA KEV)."""
    # SECURITY: Use validate_pagination to prevent DoS via large page sizes
    page, per_page = validate_pagination(
        request.args.get('page', 1, type=int),
        request.args.get('per_page', 50, type=int)
    )

    with session_scope() as session:
        query = session.query(CVERecord).filter(
            CVERecord.cisa_kev == True  # noqa: E712
        ).order_by(CVERecord.cisa_due_date)

        total = query.count()
        cves = query.offset((page - 1) * per_page).limit(per_page).all()

        return jsonify({
            'total': total,
            'page': page,
            'per_page': per_page,
            'kev_entries': [
                {
                    'cve_id': c.cve_id,
                    'severity': c.cvss_v3_severity,
                    'cvss_score': float(c.cvss_v3_score) if c.cvss_v3_score else None,
                    'kev_due_date': c.cisa_due_date.isoformat() if c.cisa_due_date else None,
                    'description': c.description[:200] + '...' if c.description and len(c.description) > 200 else c.description
                }
                for c in cves
            ]
        })


@vulnerabilities_bp.route('/stats', methods=['GET'])
@require_api_key
@rate_limit(max_requests=60, window_seconds=60)
def vulnerability_stats():
    """Get vulnerability statistics."""
    with session_scope() as session:
        # Total CVEs
        total_cves = session.query(CVERecord).count()

        # By severity
        severity_counts = {}
        for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
            severity_counts[severity.lower()] = session.query(CVERecord).filter(
                CVERecord.cvss_v3_severity == severity
            ).count()

        # KEV count
        kev_count = session.query(CVERecord).filter(CVERecord.cisa_kev == True).count()  # noqa: E712

        # Recent (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_count = session.query(CVERecord).filter(
            CVERecord.published_date >= thirty_days_ago
        ).count()

        # Affected assets
        affected_assets = session.query(InstalledSoftware.asset_id).join(
            SoftwareVulnerability
        ).distinct().count()

        # Open vulnerabilities
        open_vulns = session.query(SoftwareVulnerability).filter(
            SoftwareVulnerability.status == 'open'
        ).count()

        return jsonify({
            'total_cves': total_cves,
            'by_severity': severity_counts,
            'kev_count': kev_count,
            'recent_30_days': recent_count,
            'affected_assets': affected_assets,
            'open_vulnerabilities': open_vulns
        })


@vulnerabilities_bp.route('/sync', methods=['POST'])
@require_api_key
@rate_limit(max_requests=10, window_seconds=60)  # Limit sync requests (increased from 2 for UI usability)
def sync_cves():
    """Trigger CVE database synchronization from NVD."""
    try:
        # Get optional parameters
        data = request.get_json() or {}
        days_back = max(1, min(int(data.get('days_back', 7)), 30))  # Range: 1-30 days
        backfill_limit = max(1, min(int(data.get('backfill_limit', 25)), 100))
        rematch_requested = bool(data.get('rematch_after_sync', True))
        rematch_after_sync = True

        logger.info(
            "CVE sync requested (days_back=%s, rematch_requested=%s, rematch_enforced=%s)",
            days_back,
            rematch_requested,
            rematch_after_sync,
        )
        audit_log(
            'sync',
            'cve_database',
            f'days_back={days_back},rematch_requested={rematch_requested},rematch_enforced={rematch_after_sync}'
        )

        # Initialize syncer and run sync
        syncer = NVDSync()
        rematch_stats = None
        backfill_stats = None
        correlation = _build_sync_correlation_payload(
            requested=True,
            status='queued',
            reason='awaiting_cve_sync_completion'
        )

        # Track sync results
        start_time = datetime.utcnow()

        try:
            syncer.sync_cves(days_back=days_back, full_sync=False)
            syncer.sync_kev()
            backfill_stats = syncer.backfill_incomplete_cves(max_records=backfill_limit)

            if rematch_after_sync:
                from ..vulnerability_matcher import rematch_all_assets
                rematch_started_at = datetime.utcnow()
                correlation = _build_sync_correlation_payload(
                    requested=True,
                    status='in_progress',
                    started_at=rematch_started_at,
                    reason='vulnerability_correlation_running'
                )

                try:
                    rematch_stats = rematch_all_assets()
                    correlation = _build_sync_correlation_payload(
                        requested=True,
                        status='completed',
                        started_at=rematch_started_at,
                        completed_at=datetime.utcnow(),
                        stats=rematch_stats,
                        reason='completed'
                    )
                except Exception as rematch_err:
                    logger.error("Post-sync vulnerability rematch failed: %s", rematch_err)
                    rematch_stats = {
                        'error': str(rematch_err),
                        'assets_processed': 0,
                        'total_new_vulnerabilities': 0,
                        'total_updated_vulnerabilities': 0,
                    }
                    correlation = _build_sync_correlation_payload(
                        requested=True,
                        status='failed',
                        started_at=rematch_started_at,
                        completed_at=datetime.utcnow(),
                        stats=rematch_stats,
                        reason='completed_with_errors',
                        error=str(rematch_err)
                    )
        except Exception as sync_err:
            logger.error("CVE sync failed: %s", sync_err)
            # Graceful degradation: if local CVE data already exists, return it with warning
            # so UI workflows can continue even when NVD is temporarily unavailable.
            with session_scope() as session:
                total_cves = session.query(CVERecord).count()
                kev_count = session.query(CVERecord).filter(CVERecord.cisa_kev == True).count()  # noqa: E712
                last_updated_record = session.query(CVERecord).order_by(CVERecord.updated_at.desc()).first()

            if total_cves > 0:
                if rematch_after_sync:
                    correlation = _build_sync_correlation_payload(
                        requested=True,
                        status='failed',
                        completed_at=datetime.utcnow(),
                        reason='sync_failed_before_correlation',
                        error=str(sync_err)
                    )
                return jsonify({
                    'success': True,
                    'degraded': True,
                    'warning': 'NVD sync unavailable; using cached CVE data',
                    'message': str(sync_err),
                    'total_cves': total_cves,
                    'kev_count': kev_count,
                    'days_requested': days_back,
                    'rematch_requested': rematch_requested,
                    'rematch_enforced': rematch_after_sync,
                    'backfill_stats': backfill_stats,
                    'vulnerability_correlation': correlation,
                    'last_cached_update': (
                        last_updated_record.updated_at.isoformat()
                        if last_updated_record and last_updated_record.updated_at
                        else None
                    )
                }), 200

            return jsonify({
                'success': False,
                'error': 'CVE sync failed - NVD API may be unavailable',
                'message': str(sync_err),
                'hint': 'No cached CVE data is available yet. Retry later or configure NVD API key/network access.'
            }), 503

        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()

        # Get updated counts
        with session_scope() as session:
            total_cves = session.query(CVERecord).count()
            kev_count = session.query(CVERecord).filter(CVERecord.cisa_kev == True).count()  # noqa: E712

        return jsonify({
            'success': True,
            'message': 'CVE sync completed successfully',
            'duration_seconds': round(duration, 2),
            'total_cves': total_cves,
            'kev_count': kev_count,
            'days_synced': days_back,
            'rematch_requested': rematch_requested,
            'rematch_enforced': rematch_after_sync,
            'backfill_stats': backfill_stats,
            'rematch_stats': rematch_stats,
            'vulnerability_correlation': correlation
        })
    except Exception as e:
        return safe_error_response(e, 500)


def cve_to_dict(cve: CVERecord, detailed: bool = False) -> dict:
    """Convert CVE record to dictionary."""
    result = {
        'cve_id': cve.cve_id,
        'description': _string_or_fallback(cve.description, fallback='No description provided by NVD.'),
        'cvss_v3_severity': _string_or_fallback(cve.cvss_v3_severity, fallback='UNKNOWN'),
        'cvss_v3_score': _best_cvss_score(cve),
        'cvss_v2_score': float(cve.cvss_v2_score) if cve.cvss_v2_score is not None else 0.0,
        'is_kev': cve.cisa_kev,
        'published_date': cve.published_date.isoformat() if cve.published_date else ''
    }

    if detailed:
        recommendations = _build_remediation_recommendations(cve=cve)
        result.update({
            'cvss_v3_vector': _string_or_fallback(cve.cvss_v3_vector),
            'attack_vector': _string_or_fallback(cve.attack_vector),
            'attack_complexity': _string_or_fallback(cve.attack_complexity),
            'privileges_required': _string_or_fallback(cve.privileges_required),
            'user_interaction': _string_or_fallback(cve.user_interaction),
            'scope': _string_or_fallback(cve.scope),
            'exploitability_score': float(cve.exploitability_score) if cve.exploitability_score is not None else 0.0,
            'impact_score': float(cve.impact_score) if cve.impact_score is not None else 0.0,
            'kev_due_date': cve.cisa_due_date.isoformat() if cve.cisa_due_date else '',
            'references': cve.references or [],
            'cwe_ids': cve.cwe_ids or [],
            'last_modified': cve.last_modified.isoformat() if cve.last_modified else '',
            'recommendations': recommendations,
        })

    return result
