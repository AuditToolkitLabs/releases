# Asset Discovery API Application

import os
import logging
from datetime import datetime
from urllib.parse import urlparse
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

from .config import get_config, load_config
from .models.base import init_db
from .security import add_security_headers, MAX_REQUEST_SIZE


def create_app(config_path: str | None = None) -> Flask:
    """Create and configure the Flask application."""

    disable_background_jobs = os.environ.get('ASSET_DISCOVERY_DISABLE_BACKGROUND_JOBS', 'false').lower() in ('true', '1', 'yes')

    # Load configuration
    if config_path:
        from .config import set_config
        set_config(load_config(config_path))

    config = get_config()

    # Create Flask app
    app = Flask(__name__)
    app.config['SECRET_KEY'] = config.api.secret_key or os.urandom(32).hex()
    app.config['DEBUG'] = config.api.debug
    app.config['MAX_CONTENT_LENGTH'] = MAX_REQUEST_SIZE  # 10MB max request size

    # Setup CORS with secure defaults
    # In production, replace '*' with specific origins
    cors_origins = config.api.cors_origins
    if cors_origins == ['*'] and not config.api.debug:
        # Warn about permissive CORS in non-debug mode
        logging.warning("CORS allows all origins (*). Configure specific origins in production.")

    CORS(app,
         origins=cors_origins,
         methods=['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
         allow_headers=['Content-Type', 'Authorization'],
         expose_headers=['X-Request-ID'],
         max_age=600)  # Preflight cache for 10 minutes

    # Setup logging
    logging.basicConfig(
        level=getattr(logging, config.logging.level),
        format=config.logging.format
    )

    # Ensure log directory exists
    log_dir = os.path.dirname(config.logging.file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    # Initialize database
    init_db()

    # Initialize background scheduler for automated tasks
    # Only initialize if not in testing mode
    if not app.config.get('TESTING') and not disable_background_jobs:
        try:
            from .scheduler import init_scheduler
            init_scheduler(app)
            logging.info("Background scheduler initialized")
        except Exception as e:
            import traceback
            logging.error(f"Failed to initialize scheduler: {e}")
            logging.error(f"Scheduler init traceback: {traceback.format_exc()}")

        # Initialize scan worker for processing scan jobs
        try:
            from .services.scan_executor import start_scan_worker
            from .models.base import session_scope
            start_scan_worker(session_scope)
            logging.info("Scan worker initialized")
        except Exception as e:
            import traceback
            logging.error(f"Failed to initialize scan worker: {e}")
            logging.error(f"Scan worker init traceback: {traceback.format_exc()}")
    elif disable_background_jobs:
        logging.info("Background scheduler and scan worker disabled by environment")

    # Register security headers middleware
    @app.after_request
    def apply_security_headers(response):
        return add_security_headers(response)

    # Error handlers for secure error responses
    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({'error': 'Bad request', 'status': 400}), 400

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'error': 'Resource not found', 'status': 404}), 404

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({'error': 'Method not allowed', 'status': 405}), 405

    @app.errorhandler(413)
    def request_too_large(e):
        return jsonify({'error': 'Request body too large', 'status': 413}), 413

    @app.errorhandler(429)
    def rate_limited(e):
        return jsonify({'error': 'Too many requests', 'status': 429}), 429

    @app.errorhandler(500)
    def internal_error(e):
        logging.exception("Internal server error")
        return jsonify({'error': 'Internal server error', 'status': 500}), 500

    # Register blueprints
    from .api.assets import assets_bp
    from .api.scans import scans_bp
    from .api.vulnerabilities import vulnerabilities_bp
    from .api.dashboard import dashboard_bp
    from .api.settings import settings_bp
    from .api.scheduled_scans import scheduled_scans_bp
    from .api.agents import agents_bp

    app.register_blueprint(assets_bp, url_prefix='/api/v1/assets')
    app.register_blueprint(scans_bp, url_prefix='/api/v1/scans')
    app.register_blueprint(vulnerabilities_bp, url_prefix='/api/v1/vulnerabilities')
    app.register_blueprint(dashboard_bp, url_prefix='/api/v1/dashboard')
    app.register_blueprint(settings_bp, url_prefix='/api/v1/settings')
    app.register_blueprint(scheduled_scans_bp, url_prefix='/api/v1/scheduled-scans')
    app.register_blueprint(agents_bp, url_prefix='/api/agent')

    # Health check endpoint
    @app.route('/health')
    def health():
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        })

    # Serve dashboard UI
    @app.route('/')
    def index():
        static_dir = os.path.join(os.path.dirname(__file__), 'static')
        return send_from_directory(static_dir, 'index.html')

    @app.route('/static/<path:filename>')
    def serve_static(filename):
        static_dir = os.path.join(os.path.dirname(__file__), 'static')
        return send_from_directory(static_dir, filename)

    # API info endpoint
    @app.route('/api/v1')
    def api_info():
        return jsonify({
            'name': 'Asset Discovery API',
            'version': '1.0.0',
            'endpoints': {
                'assets': '/api/v1/assets',
                'scans': '/api/v1/scans',
                'scheduled_scans': '/api/v1/scheduled-scans',
                'vulnerabilities': '/api/v1/vulnerabilities',
                'dashboard': '/api/v1/dashboard',
                'settings': '/api/v1/settings'
            }
        })

    # Config endpoint for frontend integration
    @app.route('/api/v1/config')
    def get_frontend_config():
        """Return configuration for frontend navigation."""
        configured_toolkit_url = (os.environ.get('MAIN_TOOL_URL') or os.environ.get('AUDIT_TOOLKIT_URL') or '').strip()
        forwarded_proto = (request.headers.get('X-Forwarded-Proto') or request.scheme or 'https').split(',')[0].strip()
        forwarded_host = (request.headers.get('X-Forwarded-Host') or request.host or '').split(',')[0].strip()
        request_hostname = forwarded_host.split(':', 1)[0].strip()

        def _derived_toolkit_url() -> str:
            if not request_hostname:
                return 'http://localhost:5000'
            scheme = 'https' if forwarded_proto == 'https' else (forwarded_proto or 'http')
            return f'{scheme}://{request_hostname}'

        audit_toolkit_url = configured_toolkit_url or _derived_toolkit_url()

        if configured_toolkit_url:
            try:
                parsed = urlparse(configured_toolkit_url)
                configured_host = (parsed.hostname or '').lower()
                current_host = request_hostname.lower()
                if configured_host in {'localhost', '127.0.0.1'} and current_host and current_host not in {'localhost', '127.0.0.1'}:
                    audit_toolkit_url = _derived_toolkit_url()
                elif parsed.scheme and parsed.netloc:
                    audit_toolkit_url = f'{parsed.scheme}://{parsed.netloc}'
            except Exception:
                audit_toolkit_url = _derived_toolkit_url()

        return jsonify({
            'audit_toolkit_url': audit_toolkit_url,
            'main_tool_url': audit_toolkit_url,
            'app_name': 'Asset Discovery',
            'version': '1.0.0',
            'features': {
                'main_console': True,
                'script_studio': True,
                'reports': True,
                'auto_cve_sync': True,
                'auto_vulnerability_rematch': True,
                'scheduled_scans': True,
                'cross_tool_sync': True
            }
        })

    return app


def run_server():
    """Run the development server."""
    config = get_config()
    app = create_app()
    app.run(
        host=config.api.host,
        port=config.api.port,
        debug=config.api.debug
    )


# Module-level WSGI callable for gunicorn:
#   gunicorn --bind 127.0.0.1:18080 src.app:application
application = create_app()


if __name__ == '__main__':
    run_server()
