# Asset Discovery - Configuration Management

import os
from pathlib import Path
from typing import Any, Optional
from dataclasses import dataclass, field

import yaml


@dataclass
class DatabaseConfig:
    """Database configuration."""
    type: str = 'sqlite'  # 'sqlite' or 'postgresql'
    path: str = './data/asset_discovery.db'  # SQLite path
    host: str = 'localhost'
    port: int = 5432
    database: str = 'asset_discovery'
    username: str = 'discovery_admin'
    password: str = ''

    def get_url(self) -> str:
        """Get database URL."""
        if self.type == 'sqlite':
            # Ensure data directory exists
            db_path = Path(self.path)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            return f"sqlite:///{db_path.absolute()}"
        elif self.type == 'postgresql':
            return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        else:
            raise ValueError(f"Unsupported database type: {self.type}")


@dataclass
class NVDConfig:
    """NVD API configuration."""
    api_key: str = ''
    base_url: str = 'https://services.nvd.nist.gov/rest/json/cves/2.0'
    rate_limit_per_30s: int = 5  # 5 without key, 50 with key
    sync_interval_hours: int = 24  # Default: daily sync
    auto_sync_enabled: bool = True  # Enable automated CVE sync
    auto_rematch_enabled: bool = True  # Enable automatic vulnerability re-matching


@dataclass
class DiscoveryConfig:
    """Discovery scan configuration."""
    default_timeout_seconds: int = 300
    max_concurrent_scans: int = 10
    retry_count: int = 3
    ssh_port: int = 22
    winrm_port: int = 5985
    winrm_ssl_port: int = 5986
    scan_profile: str = 'standard'
    scan_profiles: dict[str, dict[str, Any]] = field(default_factory=lambda: {
        'fast': {
            'ports': [22, 80, 443],
            'connect_timeout_seconds': 1,
            'reachability_probe_ports': [80, 443],
            'max_concurrent_targets': 20,
        },
        'standard': {
            'ports': [22, 80, 443, 445, 3389, 5985, 5986],
            'connect_timeout_seconds': 2,
            'reachability_probe_ports': [1, 80, 443],
            'max_concurrent_targets': 10,
        },
        'deep': {
            'ports': [21, 22, 25, 53, 80, 110, 123, 135, 139, 143, 161, 389, 443, 445, 465, 514, 587, 636, 993, 995, 1433, 1521, 2049, 2375, 3306, 3389, 5432, 5900, 5985, 5986, 6379, 8080, 8443, 9200],
            'connect_timeout_seconds': 2,
            'reachability_probe_ports': [1, 22, 80, 443],
            'max_concurrent_targets': 5,
        },
    })


@dataclass
class APIConfig:
    """API server configuration."""
    host: str = '0.0.0.0'  # nosec B104
    port: int = 8080
    debug: bool = False
    secret_key: str = ''
    cors_origins: list = field(default_factory=lambda: ['*'])
    require_api_key: bool = True  # Require API key for all endpoints
    allowed_api_keys: list = field(default_factory=list)  # List of valid API keys
    internal_service_token: str = ''  # Shared token for web<->asset-discovery trust
    rate_limit_bypass_subnets: list = field(default_factory=list)  # Empty by default - secure for Corporate LAN
    # Configurable rate limits (per minute) - can be overridden via SuperAdmin settings
    rate_limit_api: int = 100  # General API browsing
    rate_limit_scan: int = 20  # Scan create/test operations
    rate_limit_cve_sync: int = 10  # CVE sync operations
    rate_limit_dashboard: int = 60  # Dashboard widget requests


@dataclass
class LoggingConfig:
    """Logging configuration."""
    level: str = 'INFO'
    format: str = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    file: str = './logs/asset_discovery.log'


@dataclass
class Config:
    """Main configuration."""
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    nvd: NVDConfig = field(default_factory=NVDConfig)
    discovery: DiscoveryConfig = field(default_factory=DiscoveryConfig)
    api: APIConfig = field(default_factory=APIConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)


def load_config(config_path: Optional[str] = None) -> Config:
    """Load configuration from file and environment variables."""
    config = Config()

    # Try to load from config file
    if config_path is None:
        # Look for config in common locations
        possible_paths = [
            './config.yaml',
            './config.yml',
            './config/config.yaml',
            os.path.expanduser('~/.asset-discovery/config.yaml'),
            '/etc/asset-discovery/config.yaml',
        ]
        for p in possible_paths:
            if os.path.exists(p):
                config_path = p
                break

    if config_path and os.path.exists(config_path):
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f) or {}

        # Database config
        if 'database' in data:
            db = data['database']
            config.database.type = db.get('type', config.database.type)
            config.database.path = db.get('path', config.database.path)
            config.database.host = db.get('host', config.database.host)
            config.database.port = db.get('port', config.database.port)
            config.database.database = db.get('database', config.database.database)
            config.database.username = db.get('username', config.database.username)
            config.database.password = db.get('password', config.database.password)

        # NVD config
        if 'nvd' in data:
            nvd = data['nvd']
            config.nvd.api_key = nvd.get('api_key', config.nvd.api_key)
            config.nvd.sync_interval_hours = nvd.get('sync_interval_hours', config.nvd.sync_interval_hours)

        # Discovery config
        if 'discovery' in data:
            disc = data['discovery']
            config.discovery.default_timeout_seconds = disc.get('timeout', config.discovery.default_timeout_seconds)
            config.discovery.max_concurrent_scans = disc.get('max_concurrent', config.discovery.max_concurrent_scans)
            config.discovery.scan_profile = disc.get('scan_profile', config.discovery.scan_profile)
            profiles = disc.get('scan_profiles')
            if isinstance(profiles, dict):
                config.discovery.scan_profiles = profiles

        # API config
        if 'api' in data:
            api = data['api']
            config.api.host = api.get('host', config.api.host)
            config.api.port = api.get('port', config.api.port)
            config.api.debug = api.get('debug', config.api.debug)
            config.api.secret_key = api.get('secret_key', config.api.secret_key)

        # Logging config
        if 'logging' in data:
            log = data['logging']
            config.logging.level = log.get('level', config.logging.level)
            config.logging.file = log.get('file', config.logging.file)

    # Override with environment variables
    _apply_env_overrides(config)

    return config


def _apply_env_overrides(config: Config) -> None:
    """Apply environment variable overrides."""
    # Database
    if os.environ.get('DATABASE_URL'):
        url = os.environ['DATABASE_URL']
        if url.startswith('sqlite'):
            config.database.type = 'sqlite'
            config.database.path = url.replace('sqlite:///', '')
        elif url.startswith('postgresql'):
            config.database.type = 'postgresql'
            # Parse PostgreSQL URL
            # postgresql://user:pass@host:port/db
            import re
            match = re.match(r'postgresql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', url)
            if match:
                config.database.username = match.group(1)
                config.database.password = match.group(2)
                config.database.host = match.group(3)
                config.database.port = int(match.group(4))
                config.database.database = match.group(5)

    if os.environ.get('POSTGRES_HOST'):
        config.database.type = 'postgresql'
        config.database.host = os.environ['POSTGRES_HOST']
    if os.environ.get('POSTGRES_PORT'):
        config.database.port = int(os.environ['POSTGRES_PORT'])
    if os.environ.get('POSTGRES_DB'):
        config.database.database = os.environ['POSTGRES_DB']
    if os.environ.get('POSTGRES_USER'):
        config.database.username = os.environ['POSTGRES_USER']
    if os.environ.get('POSTGRES_PASSWORD'):
        config.database.password = os.environ['POSTGRES_PASSWORD']

    # NVD
    if os.environ.get('NVD_API_KEY'):
        config.nvd.api_key = os.environ['NVD_API_KEY']
        config.nvd.rate_limit_per_30s = 50  # Higher rate with API key

    # API
    if os.environ.get('API_HOST'):
        config.api.host = os.environ['API_HOST']
    if os.environ.get('API_PORT'):
        config.api.port = int(os.environ['API_PORT'])
    if os.environ.get('SECRET_KEY'):
        config.api.secret_key = os.environ['SECRET_KEY']
    if os.environ.get('DEBUG'):
        config.api.debug = os.environ['DEBUG'].lower() in ('true', '1', 'yes')
    if os.environ.get('REQUIRE_API_KEY'):
        val = os.environ['REQUIRE_API_KEY'].lower()
        # Explicitly handle both true and false values
        if val in ('false', '0', 'no'):
            config.api.require_api_key = False
        elif val in ('true', '1', 'yes'):
            config.api.require_api_key = True
    if os.environ.get('ASSET_DISCOVERY_API_KEY'):
        config.api.allowed_api_keys = [os.environ['ASSET_DISCOVERY_API_KEY']]
    if os.environ.get('INTERNAL_SERVICE_TOKEN'):
        config.api.internal_service_token = os.environ['INTERNAL_SERVICE_TOKEN']
    if os.environ.get('RATE_LIMIT_BYPASS_SUBNETS'):
        config.api.rate_limit_bypass_subnets = os.environ['RATE_LIMIT_BYPASS_SUBNETS'].split(',')

    # Rate limit settings (can be configured via SuperAdmin panel)
    if os.environ.get('ASSET_DISCOVERY_API_RATE_LIMIT_PER_MINUTE'):
        config.api.rate_limit_api = int(os.environ['ASSET_DISCOVERY_API_RATE_LIMIT_PER_MINUTE'])
    if os.environ.get('ASSET_DISCOVERY_SCAN_RATE_LIMIT_PER_MINUTE'):
        config.api.rate_limit_scan = int(os.environ['ASSET_DISCOVERY_SCAN_RATE_LIMIT_PER_MINUTE'])
    if os.environ.get('ASSET_DISCOVERY_CVE_SYNC_RATE_LIMIT_PER_MINUTE'):
        config.api.rate_limit_cve_sync = int(os.environ['ASSET_DISCOVERY_CVE_SYNC_RATE_LIMIT_PER_MINUTE'])
    if os.environ.get('ASSET_DISCOVERY_DASHBOARD_RATE_LIMIT_PER_MINUTE'):
        config.api.rate_limit_dashboard = int(os.environ['ASSET_DISCOVERY_DASHBOARD_RATE_LIMIT_PER_MINUTE'])

    # Discovery
    if os.environ.get('ASSET_DISCOVERY_SCAN_PROFILE'):
        config.discovery.scan_profile = os.environ['ASSET_DISCOVERY_SCAN_PROFILE'].strip().lower()

    # Logging
    if os.environ.get('LOG_LEVEL'):
        config.logging.level = os.environ['LOG_LEVEL'].upper()


def save_config(config: Config, config_path: str) -> None:
    """Save configuration to file."""
    data = {
        'database': {
            'type': config.database.type,
            'path': config.database.path,
            'host': config.database.host,
            'port': config.database.port,
            'database': config.database.database,
            'username': config.database.username,
            # Don't save password to file
        },
        'nvd': {
            'api_key': config.nvd.api_key,
            'sync_interval_hours': config.nvd.sync_interval_hours,
        },
        'discovery': {
            'timeout': config.discovery.default_timeout_seconds,
            'max_concurrent': config.discovery.max_concurrent_scans,
            'scan_profile': config.discovery.scan_profile,
            'scan_profiles': config.discovery.scan_profiles,
        },
        'api': {
            'host': config.api.host,
            'port': config.api.port,
            'debug': config.api.debug,
        },
        'logging': {
            'level': config.logging.level,
            'file': config.logging.file,
        },
    }

    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, 'w') as f:
        yaml.dump(data, f, default_flow_style=False)


# Global config instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration."""
    global _config
    if _config is None:
        _config = load_config()
    return _config


def set_config(config: Config) -> None:
    """Set the global configuration."""
    global _config
    _config = config
