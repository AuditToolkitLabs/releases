# Asset Discovery - CVE Sync Service
#
# Synchronizes CVE data from NIST NVD API and CISA KEV catalog

import os
import re
import time
import logging
import requests
from datetime import datetime, timedelta
from typing import Optional

from .config import get_config
from .models.base import session_scope, init_db
from .models.vulnerability import CVERecord, CVECPEMatch

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('cve_sync')

# Security: CVE ID validation pattern
CVE_ID_PATTERN = re.compile(r'^CVE-\d{4}-\d{4,}$')

# Security: Maximum limits to prevent DoS
MAX_DESCRIPTION_LENGTH = 10000
MAX_REFERENCE_URL_LENGTH = 2048
MAX_CPE_LENGTH = 500


def validate_cve_id(cve_id: str) -> Optional[str]:
    """Validate CVE ID format."""
    if not cve_id or not isinstance(cve_id, str):
        return None
    cve_id = cve_id.strip().upper()
    if len(cve_id) > 20:
        return None
    if not CVE_ID_PATTERN.match(cve_id):
        return None
    return cve_id


def sanitize_string(value: str, max_length: int = 1000) -> str:
    """Sanitize string input."""
    if not value or not isinstance(value, str):
        return ''
    # Remove null bytes and control characters
    value = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)
    return value[:max_length].strip()


def _severity_from_score(cvss_v3_score, cvss_v2_score) -> str:
    """Compute a deterministic severity value from available CVSS scores."""
    score = cvss_v3_score if cvss_v3_score is not None else cvss_v2_score
    try:
        numeric_score = float(score)
    except (TypeError, ValueError):
        return 'UNKNOWN'

    if numeric_score >= 9.0:
        return 'CRITICAL'
    if numeric_score >= 7.0:
        return 'HIGH'
    if numeric_score >= 4.0:
        return 'MEDIUM'
    if numeric_score > 0:
        return 'LOW'
    return 'UNKNOWN'


class NVDSync:
    """Synchronize CVE data from NIST NVD API."""

    NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    CISA_KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

    # Security: Request timeouts
    CONNECT_TIMEOUT = 10
    READ_TIMEOUT = 120

    @staticmethod
    def _parse_nvd_datetime(value: Optional[str]) -> Optional[datetime]:
        """Parse NVD datetime strings safely."""
        if not value:
            return None
        if not isinstance(value, str):
            return None

        normalized = value.strip()
        if not normalized:
            return None

        try:
            return datetime.fromisoformat(normalized.replace('Z', '+00:00'))
        except ValueError:
            pass

        for fmt in ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d'):
            try:
                return datetime.strptime(normalized, fmt)
            except ValueError:
                continue

        return None

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.session = requests.Session()

        # Security: Set secure defaults
        self.session.headers.update({
            'User-Agent': 'AssetDiscovery-CVESync/1.0',
            'Accept': 'application/json'
        })

        if api_key:
            self.session.headers['apiKey'] = api_key
            self.rate_limit_delay = 0.6  # 50 requests per 30 seconds with key
        else:
            self.rate_limit_delay = 6.0  # 5 requests per 30 seconds without key

    def sync_cves(self, days_back: int = 7, full_sync: bool = False):
        """Sync CVEs from NVD."""
        logger.info(f"Starting CVE sync (days_back={days_back}, full_sync={full_sync})")

        if full_sync:
            # Full sync - get all CVEs (will take a long time)
            start_index = 0
            total_fetched = 0

            while True:
                params = {
                    'startIndex': start_index,
                    'resultsPerPage': 2000
                }

                cves, total_results = self._fetch_cves(params)
                if not cves:
                    break

                self._store_cves(cves)
                total_fetched += len(cves)
                logger.info(f"Fetched {total_fetched}/{total_results} CVEs")

                if start_index + len(cves) >= total_results:
                    break

                start_index += len(cves)
                time.sleep(self.rate_limit_delay)
        else:
            # Incremental sync - only recent CVEs
            pub_start = (datetime.utcnow() - timedelta(days=days_back)).strftime('%Y-%m-%dT00:00:00.000')
            pub_end = datetime.utcnow().strftime('%Y-%m-%dT23:59:59.999')

            params = {
                'pubStartDate': pub_start,
                'pubEndDate': pub_end,
                'resultsPerPage': 2000
            }

            cves, total = self._fetch_cves(params)
            if cves:
                self._store_cves(cves)
                logger.info(f"Synced {len(cves)} CVEs from last {days_back} days")

    def _fetch_cves(self, params: dict) -> tuple:
        """Fetch CVEs from NVD API."""
        try:
            response = self.session.get(
                self.NVD_API_URL,
                params=params,
                timeout=(self.CONNECT_TIMEOUT, self.READ_TIMEOUT)
            )
            response.raise_for_status()
            data = response.json()

            vulnerabilities = data.get('vulnerabilities', [])
            total_results = data.get('totalResults', 0)

            cves = []
            for vuln in vulnerabilities:
                cve = vuln.get('cve', {})
                parsed = self._parse_cve(cve)
                if parsed:  # Only add valid CVEs
                    cves.append(parsed)

            return cves, total_results
        except requests.Timeout:
            logger.error("NVD API request timed out")
            return [], 0
        except requests.RequestException as e:
            logger.error(f"Failed to fetch CVEs: {e}")
            return [], 0
        except ValueError as e:
            logger.error(f"Failed to parse NVD response: {e}")
            return [], 0

    def _fetch_single_cve(self, cve_id: str) -> Optional[dict]:
        """Fetch a single CVE by ID from NVD and return parsed payload."""
        validated = validate_cve_id(cve_id)
        if not validated:
            return None

        cves, _ = self._fetch_cves({'cveId': validated, 'resultsPerPage': 1})
        if not cves:
            return None
        return cves[0]

    def fetch_single_cve(self, cve_id: str) -> Optional[dict]:
        """Public wrapper for fetching one CVE."""
        validated = validate_cve_id(cve_id)
        if not validated:
            return None

        cves, _ = self._fetch_cves({'cveId': validated, 'resultsPerPage': 1})
        if not cves:
            return None
        return cves[0]

    @staticmethod
    def parse_nvd_datetime(value: Optional[str]) -> Optional[datetime]:
        """Public wrapper for parsing NVD datetime values."""
        if not value:
            return None
        if not isinstance(value, str):
            return None

        normalized = value.strip()
        if not normalized:
            return None

        try:
            return datetime.fromisoformat(normalized.replace('Z', '+00:00'))
        except ValueError:
            pass

        for fmt in ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d'):
            try:
                return datetime.strptime(normalized, fmt)
            except ValueError:
                continue

        return None

    def _parse_cve(self, cve_data: dict) -> Optional[dict]:
        """Parse CVE data from NVD response with input validation."""
        # Validate CVE ID
        raw_cve_id = cve_data.get('id', '')
        cve_id = validate_cve_id(raw_cve_id)
        if not cve_id:
            logger.warning(f"Invalid CVE ID format: {raw_cve_id[:50]}")
            return None

        # Get description (English) - sanitized
        description = ''
        descriptions = cve_data.get('descriptions', [])
        for desc in descriptions:
            if desc.get('lang') == 'en':
                description = sanitize_string(desc.get('value', ''), MAX_DESCRIPTION_LENGTH)
                break
        if not description and descriptions:
            description = sanitize_string(descriptions[0].get('value', ''), MAX_DESCRIPTION_LENGTH)
        if not description:
            description = 'No description provided by NVD.'

        # Get CVSS scores
        metrics = cve_data.get('metrics', {})

        cvss_v3_score = None
        cvss_v3_vector = None
        cvss_v3_severity = None
        attack_vector = None
        attack_complexity = None
        privileges_required = None
        user_interaction = None
        scope = None
        exploitability_score = None
        impact_score = None

        if 'cvssMetricV31' in metrics:
            metric = metrics['cvssMetricV31'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_v3_score = cvss_data.get('baseScore')
            cvss_v3_vector = cvss_data.get('vectorString')
            cvss_v3_severity = cvss_data.get('baseSeverity') or metric.get('baseSeverity')
            attack_vector = cvss_data.get('attackVector')
            attack_complexity = cvss_data.get('attackComplexity')
            privileges_required = cvss_data.get('privilegesRequired')
            user_interaction = cvss_data.get('userInteraction')
            scope = cvss_data.get('scope')
            exploitability_score = metric.get('exploitabilityScore')
            impact_score = metric.get('impactScore')
        elif 'cvssMetricV30' in metrics:
            metric = metrics['cvssMetricV30'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_v3_score = cvss_data.get('baseScore')
            cvss_v3_vector = cvss_data.get('vectorString')
            cvss_v3_severity = cvss_data.get('baseSeverity') or metric.get('baseSeverity')
            attack_vector = cvss_data.get('attackVector')
            attack_complexity = cvss_data.get('attackComplexity')
            privileges_required = cvss_data.get('privilegesRequired')
            user_interaction = cvss_data.get('userInteraction')
            scope = cvss_data.get('scope')
            exploitability_score = metric.get('exploitabilityScore')
            impact_score = metric.get('impactScore')

        cvss_v2_score = None
        if 'cvssMetricV2' in metrics:
            metric = metrics['cvssMetricV2'][0]
            cvss_data = metric.get('cvssData', {})
            cvss_v2_score = cvss_data.get('baseScore')
            if not exploitability_score:
                exploitability_score = metric.get('exploitabilityScore')
            if not impact_score:
                impact_score = metric.get('impactScore')
            if not attack_vector:
                attack_vector = cvss_data.get('accessVector')
            if not attack_complexity:
                attack_complexity = cvss_data.get('accessComplexity')
            if not user_interaction:
                user_interaction = cvss_data.get('userInteractionRequired')

        # Determine severity
        severity = sanitize_string(str(cvss_v3_severity or ''), 20).upper() or _severity_from_score(cvss_v3_score, cvss_v2_score)

        # Get dates
        published = cve_data.get('published')
        last_modified = cve_data.get('lastModified')

        # Get CPE matches with validation
        cpe_matches = []
        configurations = cve_data.get('configurations', [])
        for config in configurations:
            nodes = config.get('nodes', [])
            for node in nodes:
                cpe_match = node.get('cpeMatch', [])
                for match in cpe_match:
                    if match.get('vulnerable'):
                        cpe = sanitize_string(str(match.get('criteria', '')), MAX_CPE_LENGTH)
                        if cpe:
                            cpe_matches.append({
                                'cpe': cpe,
                                'version_start': sanitize_string(str(match.get('versionStartIncluding', '')), 100),
                                'version_end': sanitize_string(str(match.get('versionEndExcluding', '')), 100)
                            })

        # Get references with URL validation
        references = []
        refs = cve_data.get('references', [])
        for ref in refs[:50]:  # Limit to 50 references
            url = ref.get('url', '')
            if url and isinstance(url, str) and url.startswith(('http://', 'https://')):
                # Sanitize URL
                url = sanitize_string(url, MAX_REFERENCE_URL_LENGTH)
                if url:
                    references.append(url)

        # Get CWE IDs
        cwe_ids = []
        weaknesses = cve_data.get('weaknesses', [])
        for weakness in weaknesses:
            for desc in weakness.get('description', []):
                cwe_value = sanitize_string(str(desc.get('value', '')), 50).upper()
                if cwe_value.startswith('CWE-'):
                    cwe_ids.append(cwe_value)

        cwe_ids = sorted(set(cwe_ids))

        return {
            'cve_id': cve_id,
            'description': description,
            'cvss_v3_severity': severity,
            'cvss_v3_score': cvss_v3_score,
            'cvss_v3_vector': cvss_v3_vector,
            'cvss_v2_score': cvss_v2_score,
            'exploitability_score': exploitability_score,
            'impact_score': impact_score,
            'attack_vector': sanitize_string(str(attack_vector or ''), 50).upper() or None,
            'attack_complexity': sanitize_string(str(attack_complexity or ''), 20).upper() or None,
            'privileges_required': sanitize_string(str(privileges_required or ''), 20).upper() or None,
            'user_interaction': sanitize_string(str(user_interaction or ''), 20).upper() or None,
            'scope': sanitize_string(str(scope or ''), 20).upper() or None,
            'published_date': published,
            'last_modified': last_modified,
            'cpe_matches': cpe_matches,
            'references': references,
            'cwe_ids': cwe_ids
        }

    def _store_cves(self, cves: list):
        """Store CVEs in database."""
        with session_scope() as session:
            for cve_data in cves:
                # Check if CVE exists
                existing = session.query(CVERecord).filter(
                    CVERecord.cve_id == cve_data['cve_id']
                ).first()

                if existing:
                    # Update existing
                    existing.description = cve_data.get('description') or 'No description provided by NVD.'
                    existing.cvss_v3_severity = cve_data.get('cvss_v3_severity') or 'UNKNOWN'
                    existing.cvss_v3_score = cve_data['cvss_v3_score']
                    existing.cvss_v3_vector = cve_data['cvss_v3_vector']
                    existing.cvss_v2_score = cve_data['cvss_v2_score']
                    existing.exploitability_score = cve_data.get('exploitability_score')
                    existing.impact_score = cve_data.get('impact_score')
                    existing.attack_vector = cve_data.get('attack_vector')
                    existing.attack_complexity = cve_data.get('attack_complexity')
                    existing.privileges_required = cve_data.get('privileges_required')
                    existing.user_interaction = cve_data.get('user_interaction')
                    existing.scope = cve_data.get('scope')
                    existing.published_date = self._parse_nvd_datetime(cve_data.get('published_date'))
                    existing.last_modified = self._parse_nvd_datetime(cve_data.get('last_modified'))
                    existing.references = cve_data.get('references', [])
                    existing.cwe_ids = cve_data.get('cwe_ids', [])
                    cve_record = existing
                else:
                    # Create new
                    cve_record = CVERecord(
                        cve_id=cve_data['cve_id'],
                        description=cve_data.get('description') or 'No description provided by NVD.',
                        cvss_v3_severity=cve_data.get('cvss_v3_severity') or 'UNKNOWN',
                        cvss_v3_score=cve_data['cvss_v3_score'],
                        cvss_v3_vector=cve_data['cvss_v3_vector'],
                        cvss_v2_score=cve_data['cvss_v2_score'],
                        exploitability_score=cve_data.get('exploitability_score'),
                        impact_score=cve_data.get('impact_score'),
                        attack_vector=cve_data.get('attack_vector'),
                        attack_complexity=cve_data.get('attack_complexity'),
                        privileges_required=cve_data.get('privileges_required'),
                        user_interaction=cve_data.get('user_interaction'),
                        scope=cve_data.get('scope'),
                        published_date=self._parse_nvd_datetime(cve_data.get('published_date')),
                        last_modified=self._parse_nvd_datetime(cve_data.get('last_modified')),
                        references=cve_data.get('references', []),
                        cwe_ids=cve_data.get('cwe_ids', [])
                    )
                    session.add(cve_record)

                session.flush()

                # Update CPE matches
                session.query(CVECPEMatch).filter(
                    CVECPEMatch.cve_id == cve_data['cve_id']
                ).delete()

                for cpe_match in cve_data['cpe_matches']:
                    # Parse vendor/product from CPE string (cpe:2.3:a:vendor:product:version:...)
                    cpe_str = cpe_match['cpe']
                    vendor = None
                    product = None
                    if cpe_str.startswith('cpe:2.3:'):
                        parts = cpe_str.split(':')
                        if len(parts) >= 5:
                            vendor = parts[3] if parts[3] != '*' else None
                            product = parts[4] if parts[4] != '*' else None

                    match = CVECPEMatch(
                        cve_id=cve_data['cve_id'],
                        cpe23=cpe_str,
                        vendor=vendor,
                        product=product,
                        version_start=cpe_match.get('version_start'),
                        version_end=cpe_match.get('version_end'),
                        vulnerable=True
                    )
                    session.add(match)

            session.commit()

    def sync_kev(self):
        """Sync CISA Known Exploited Vulnerabilities catalog."""
        logger.info("Syncing CISA KEV catalog")

        try:
            response = self.session.get(self.CISA_KEV_URL, timeout=60)
            response.raise_for_status()
            data = response.json()

            vulnerabilities = data.get('vulnerabilities', [])

            with session_scope() as session:
                for vuln in vulnerabilities:
                    cve_id = vuln.get('cveID')
                    if not cve_id:
                        continue

                    cve_id = validate_cve_id(cve_id)
                    if not cve_id:
                        continue

                    # Update existing CVE record with KEV info
                    cve_record = session.query(CVERecord).filter(
                        CVERecord.cve_id == cve_id
                    ).first()

                    needs_enrichment = False

                    if cve_record:
                        cve_record.cisa_kev = True

                        if (
                            not cve_record.description
                            or cve_record.cvss_v3_score is None
                            or cve_record.published_date is None
                        ):
                            needs_enrichment = True

                        due_date = vuln.get('dueDate')
                        if due_date:
                            cve_record.cisa_due_date = datetime.strptime(due_date, '%Y-%m-%d').date()
                    else:
                        needs_enrichment = True

                    enriched = self._fetch_single_cve(cve_id) if needs_enrichment else None
                    if needs_enrichment:
                        time.sleep(self.rate_limit_delay)

                    if cve_record and enriched:
                        cve_record.description = enriched.get('description')
                        cve_record.cvss_v3_severity = enriched.get('cvss_v3_severity')
                        cve_record.cvss_v3_score = enriched.get('cvss_v3_score')
                        cve_record.cvss_v3_vector = enriched.get('cvss_v3_vector')
                        cve_record.cvss_v2_score = enriched.get('cvss_v2_score')
                        cve_record.published_date = self._parse_nvd_datetime(enriched.get('published_date'))
                        cve_record.last_modified = self._parse_nvd_datetime(enriched.get('last_modified'))
                        cve_record.references = enriched.get('references', [])

                    if not cve_record:
                        # Create record for KEV, enriched from NVD when available
                        cve_record = CVERecord(
                            cve_id=cve_id,
                            description=(enriched or {}).get('description') or vuln.get('shortDescription', ''),
                            cvss_v3_severity=(enriched or {}).get('cvss_v3_severity') or 'HIGH',
                            cvss_v3_score=(enriched or {}).get('cvss_v3_score'),
                            cvss_v3_vector=(enriched or {}).get('cvss_v3_vector'),
                            cvss_v2_score=(enriched or {}).get('cvss_v2_score'),
                            published_date=self._parse_nvd_datetime((enriched or {}).get('published_date')),
                            last_modified=self._parse_nvd_datetime((enriched or {}).get('last_modified')),
                            references=(enriched or {}).get('references', []),
                            cisa_kev=True
                        )
                        due_date = vuln.get('dueDate')
                        if due_date:
                            cve_record.cisa_due_date = datetime.strptime(due_date, '%Y-%m-%d').date()
                        session.add(cve_record)

                session.commit()

            logger.info(f"Synced {len(vulnerabilities)} KEV entries")

        except requests.RequestException as e:
            logger.error(f"Failed to sync KEV catalog: {e}")

    def backfill_incomplete_cves(self, max_records: int = 250) -> dict:
        """Backfill CVEs missing key metadata fields (published date / CVSS)."""
        max_records = max(1, min(int(max_records), 1000))
        attempted = 0
        updated = 0

        with session_scope() as session:
            targets = session.query(CVERecord).filter(
                (CVERecord.published_date == None) | (  # noqa: E711
                    (CVERecord.cvss_v3_score == None) & (CVERecord.cvss_v2_score == None)  # noqa: E711
                )
            ).order_by(CVERecord.updated_at.asc()).limit(max_records).all()

            for record in targets:
                attempted += 1
                enriched = self.fetch_single_cve(record.cve_id)
                if not enriched:
                    time.sleep(self.rate_limit_delay)
                    continue

                changed = False

                if enriched.get('description'):
                    if not record.description or record.description == 'No description provided by NVD.':
                        record.description = enriched.get('description')
                        changed = True

                if enriched.get('cvss_v3_severity') and record.cvss_v3_severity != enriched.get('cvss_v3_severity'):
                    record.cvss_v3_severity = enriched.get('cvss_v3_severity')
                    changed = True

                if record.cvss_v3_score is None and enriched.get('cvss_v3_score') is not None:
                    record.cvss_v3_score = enriched.get('cvss_v3_score')
                    changed = True

                if record.cvss_v2_score is None and enriched.get('cvss_v2_score') is not None:
                    record.cvss_v2_score = enriched.get('cvss_v2_score')
                    changed = True

                if enriched.get('cvss_v3_vector') and record.cvss_v3_vector != enriched.get('cvss_v3_vector'):
                    record.cvss_v3_vector = enriched.get('cvss_v3_vector')
                    changed = True

                if record.published_date is None:
                    published = self._parse_nvd_datetime(enriched.get('published_date'))
                    if published is not None:
                        record.published_date = published
                        changed = True

                last_modified = self._parse_nvd_datetime(enriched.get('last_modified'))
                if last_modified is not None:
                    record.last_modified = last_modified
                    changed = True

                if not record.references and enriched.get('references'):
                    record.references = enriched.get('references', [])
                    changed = True

                if not record.cwe_ids and enriched.get('cwe_ids'):
                    record.cwe_ids = enriched.get('cwe_ids', [])
                    changed = True

                if changed:
                    updated += 1

                time.sleep(self.rate_limit_delay)

            if updated > 0:
                session.commit()

        logger.info(
            "Backfill incomplete CVEs finished (attempted=%s, updated=%s, max_records=%s)",
            attempted,
            updated,
            max_records,
        )
        return {
            'attempted': attempted,
            'updated': updated,
            'max_records': max_records,
        }


def run_sync():
    """Run the CVE sync service."""
    config = get_config()

    # Initialize database
    init_db()

    api_key = config.nvd.api_key or os.environ.get('NVD_API_KEY')
    sync_interval = int(os.environ.get('SYNC_INTERVAL_HOURS', config.nvd.sync_interval_hours))

    syncer = NVDSync(api_key=api_key)

    logger.info(f"CVE Sync service started (interval: {sync_interval}h)")

    while True:
        try:
            # Sync recent CVEs
            syncer.sync_cves(days_back=7)

            # Sync KEV catalog
            syncer.sync_kev()

            # Backfill incomplete historical CVEs (nightly/periodic quality pass)
            syncer.backfill_incomplete_cves(max_records=250)

            # Refresh host-to-CVE correlation after CVE metadata refresh completes.
            from .vulnerability_matcher import rematch_all_assets
            rematch_all_assets()

            logger.info(f"Sync complete. Next sync in {sync_interval} hours")
        except Exception as e:
            logger.error(f"Sync failed: {e}")

        # Wait for next sync
        time.sleep(sync_interval * 3600)


if __name__ == '__main__':
    run_sync()
