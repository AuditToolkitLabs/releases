"""
Asset Discovery - Main Tool Keystore Integration

This module provides integration with the main Security Audit Toolkit's
centralized encrypted keystore for API key validation and credential retrieval.

When Asset Discovery runs as a microservice/container, it validates API keys
and retrieves credentials by calling back to the main tool's keystore API.

Architecture:
- Main Tool: Stores all keys in encrypted keystore (AES-256)
- Asset Discovery: Validates keys and retrieves credentials via HTTP API
- Agents: Use same keys whether connecting to main tool or asset discovery

Features:
- API key validation (asset_discovery keys)
- Retrieve ALL key types (agent, ssh_password, api_token, etc.)
- Server list synchronization
- Server credential retrieval

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import logging
from typing import Dict, Any, List, Optional
import time

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)


class KeystoreClient:
    """
    Client for accessing main tool's encrypted keystore.

    This allows Asset Discovery to inherit the main tool's centralized key
    management without duplicating the encrypted keystore.

    Capabilities:
    - Validate API keys
    - List keys of any type (system, agent, ssh_password, api_token, etc.)
    - Retrieve specific key values
    - Get server credentials
    - Sync server inventory
    """

    def __init__(self, main_tool_url: str = None, api_key: str = None, timeout: int = 5):
        """
        Initialize keystore client.

        Args:
            main_tool_url: URL of main Security Audit Toolkit (e.g. http://localhost:5000)
            api_key: Asset Discovery API key for authentication
            timeout: HTTP request timeout in seconds
        """
        self.main_tool_url = main_tool_url or os.getenv(
            'MAIN_TOOL_URL',
            'http://localhost:5000'  # Host-native default; Docker should set MAIN_TOOL_URL explicitly
        )
        self.api_key = api_key or os.getenv('ASSET_DISCOVERY_API_KEY')
        self.timeout = timeout
        self.enabled = REQUESTS_AVAILABLE and self._check_connection()

        # Cache for validated keys (TTL: 5 minutes)
        self._validation_cache = {}
        self._validation_cache_ttl = 300  # 5 minutes

        # Cache for retrieved keys (TTL: 1 minute for security)
        self._key_cache = {}
        self._key_cache_ttl = 60  # 1 minute

        logger.info(f"KeystoreClient initialized (enabled={self.enabled}, url={self.main_tool_url})")

    def _check_connection(self) -> bool:
        """Check if main tool is reachable."""
        try:
            if not REQUESTS_AVAILABLE:
                logger.warning("requests library not available - keystore client disabled")
                return False

            response = requests.get(
                f"{self.main_tool_url}/health",
                timeout=2
            )
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Main tool not reachable at {self.main_tool_url}: {e}")
            return False

    def validate_key(self, api_key: str) -> bool:
        """
        Validate an API key against the main tool's keystore.

        Args:
            api_key: The API key to validate

        Returns:
            True if key is valid, False otherwise
        """
        if not self.enabled:
            # Fall back to environment variable if main tool unavailable
            return self._fallback_validation(api_key)

        # Check cache first
        cache_key = self._hash_key(api_key)
        if cache_key in self._validation_cache:
            cached_time, cached_result = self._validation_cache[cache_key]
            if time.time() - cached_time < self._validation_cache_ttl:
                logger.debug(f"Key validation from cache: {cached_result}")
                return cached_result

        # Validate via API
        try:
            response = requests.post(
                f"{self.main_tool_url}/asset-discovery/api/asset-discovery/keys/validate",
                json={'api_key': api_key},
                timeout=self.timeout
            )

            if response.status_code == 200:
                data = response.json()
                is_valid = data.get('valid', False)

                # Cache the result
                self._validation_cache[cache_key] = (time.time(), is_valid)

                if is_valid:
                    key_id = data.get('key_id', 'unknown')
                    logger.info(f"API key validated successfully (key_id={key_id})")
                else:
                    logger.warning("API key validation failed - invalid key")

                return is_valid
            else:
                logger.warning(f"Key validation request failed: HTTP {response.status_code}")
                return self._fallback_validation(api_key)

        except requests.RequestException as e:
            logger.error(f"Error validating key with main tool: {e}")
            return self._fallback_validation(api_key)
        except Exception as e:
            logger.error(f"Unexpected error during key validation: {e}")
            return False

    def _fallback_validation(self, api_key: str) -> bool:
        """
        Fallback validation using environment variable.

        This allows Asset Discovery to work independently if the main tool
        is unavailable, using a pre-shared key from environment.
        """
        fallback_key = os.getenv('ASSET_DISCOVERY_API_KEY')
        if not fallback_key:
            logger.warning("No fallback API key configured in environment")
            return False

        is_valid = api_key == fallback_key
        if is_valid:
            logger.info("API key validated via fallback (environment variable)")
        else:
            logger.warning("API key validation failed (fallback check)")

        return is_valid

    # ==========================================================================
    # Key Retrieval - Access ALL Key Types from Main Tool Keystore
    # ==========================================================================

    def list_keys(self, key_type: str) -> List[Dict[str, Any]]:
        """
        List all keys of a specific type from the main tool's keystore.

        Args:
            key_type: Type of keys to list (system, agent, hypervisor_agent,
                     asset_discovery, custom, ssh_password, api_token)

        Returns:
            List of key metadata (without values)

        Example:
            keys = client.list_keys('ssh_password')
            # Returns: [{'key_id': 'web-01', 'metadata': {...}}, ...]
        """
        if not self.enabled or not self.api_key:
            logger.warning("Cannot list keys - client not enabled or no API key")
            return []

        try:
            response = requests.get(
                f"{self.main_tool_url}/asset-discovery/api/keystore/keys/{key_type}",
                headers={'X-API-Key': self.api_key},
                timeout=self.timeout
            )

            if response.status_code == 200:
                data = response.json()
                keys = data.get('keys', [])
                logger.info(f"Retrieved {len(keys)} {key_type} keys from keystore")
                return keys
            else:
                logger.error(f"Failed to list {key_type} keys: HTTP {response.status_code}")
                return []

        except Exception as e:
            logger.error(f"Error listing {key_type} keys: {e}")
            return []

    def get_key(self, key_type: str, key_id: str, use_cache: bool = True) -> Optional[str]:
        """
        Get a specific key value from the main tool's keystore.

        Args:
            key_type: Type of key (system, agent, ssh_password, api_token, etc.)
            key_id: Specific key identifier
            use_cache: Whether to use cached values (default: True)

        Returns:
            Key value string or None if not found

        Example:
            # Get SSH password for a server
            password = client.get_key('ssh_password', 'web-01')

            # Get API token for Proxmox
            token = client.get_key('api_token', 'proxmox-prod')
        """
        if not self.enabled or not self.api_key:
            logger.warning("Cannot get key - client not enabled or no API key")
            return None

        # Check cache first
        cache_key = f"{key_type}:{key_id}"
        if use_cache and cache_key in self._key_cache:
            cached_time, cached_value = self._key_cache[cache_key]
            if time.time() - cached_time < self._key_cache_ttl:
                logger.debug(f"Retrieved {key_type}/{key_id} from cache")
                return cached_value

        try:
            response = requests.get(
                f"{self.main_tool_url}/asset-discovery/api/keystore/keys/{key_type}/{key_id}",
                headers={'X-API-Key': self.api_key},
                timeout=self.timeout
            )

            if response.status_code == 200:
                data = response.json()
                value = data.get('value')

                # Cache the value
                if use_cache and value:
                    self._key_cache[cache_key] = (time.time(), value)

                logger.info(f"Retrieved {key_type}/{key_id} from keystore")
                return value
            elif response.status_code == 404:
                logger.debug(f"Key {key_type}/{key_id} not found in keystore")
                return None
            else:
                logger.error(f"Failed to get {key_type}/{key_id}: HTTP {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error getting {key_type}/{key_id}: {e}")
            return None

    def get_server_credentials(self, server_id: str) -> Optional[Dict[str, Any]]:
        """
        Get all credentials for a specific server.

        Args:
            server_id: Server ID, name, or hostname

        Returns:
            Dictionary with credentials and connection details:
            {
                'server_id': 1,
                'server_name': 'web-01',
                'hostname': '192.168.1.10',
                'credentials': {
                    'ssh_password': '...',
                    'api_token': '...',
                    'agent_key': '...'
                },
                'connection_method': 'ssh',
                'elevation_method': 'sudo',
                'execution_mode': 'stream',
                'jea_endpoint': None
            }

        Example:
            creds = client.get_server_credentials('web-01')
            ssh_pass = creds['credentials']['ssh_password']
        """
        if not self.enabled or not self.api_key:
            logger.warning("Cannot get server credentials - client not enabled or no API key")
            return None

        try:
            response = requests.get(
                f"{self.main_tool_url}/asset-discovery/api/keystore/credentials/{server_id}",
                headers={'X-API-Key': self.api_key},
                timeout=self.timeout
            )

            if response.status_code == 200:
                data = response.json()
                logger.info(f"Retrieved credentials for server {server_id}")
                return data
            elif response.status_code == 404:
                logger.debug(f"Server {server_id} not found")
                return None
            else:
                logger.error(f"Failed to get credentials for {server_id}: HTTP {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error getting credentials for {server_id}: {e}")
            return None

    # ==========================================================================
    # Server Synchronization - Import Servers from Main Tool
    # ==========================================================================

    def list_servers(self, limit: int = 100, offset: int = 0,
                    connection_method: str = None) -> Optional[Dict[str, Any]]:
        """
        List all servers from the main tool.

        Args:
            limit: Maximum number of servers to return
            offset: Offset for pagination
            connection_method: Filter by connection method (ssh, winrm, api)

        Returns:
            Dictionary with servers and pagination info:
            {
                'servers': [...],
                'total': 50,
                'limit': 100,
                'offset': 0
            }

        Example:
            # Get all SSH servers
            result = client.list_servers(connection_method='ssh')
            for server in result['servers']:
                print(f"{server['name']}: {server['hostname']}")
        """
        if not self.enabled or not self.api_key:
            logger.warning("Cannot list servers - client not enabled or no API key")
            return None

        try:
            params = {'limit': limit, 'offset': offset}
            if connection_method:
                params['connection_method'] = connection_method

            response = requests.get(
                f"{self.main_tool_url}/asset-discovery/api/servers/list",
                headers={'X-API-Key': self.api_key},
                params=params,
                timeout=self.timeout
            )

            if response.status_code == 200:
                data = response.json()
                server_count = len(data.get('servers', []))
                logger.info(f"Retrieved {server_count} servers from main tool (total: {data.get('total')})")
                return data
            else:
                logger.error(f"Failed to list servers: HTTP {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error listing servers: {e}")
            return None

    # ==========================================================================
    # Cache Management
    # ==========================================================================

    def _hash_key(self, api_key: str) -> str:
        """Create a cache key from API key (hashed for security)."""
        import hashlib
        return hashlib.sha256(api_key.encode()).hexdigest()

    def clear_cache(self):
        """Clear all caches."""
        self._validation_cache.clear()
        self._key_cache.clear()
        logger.info("All caches cleared")

    def clear_validation_cache(self):
        """Clear only the validation cache."""
        self._validation_cache.clear()
        logger.info("Validation cache cleared")

    def clear_key_cache(self):
        """Clear only the key retrieval cache."""
        self._key_cache.clear()
        logger.info("Key retrieval cache cleared")

    def get_stats(self) -> Dict[str, Any]:
        """Get client statistics."""
        return {
            'enabled': self.enabled,
            'main_tool_url': self.main_tool_url,
            'has_api_key': bool(self.api_key),
            'validation_cache_size': len(self._validation_cache),
            'key_cache_size': len(self._key_cache),
            'validation_cache_ttl': self._validation_cache_ttl,
            'key_cache_ttl': self._key_cache_ttl,
            'requests_available': REQUESTS_AVAILABLE
        }


# ==============================================================================
# Module-level singleton instance
# ==============================================================================

_keystore_client_instance = None


def get_keystore_client() -> KeystoreClient:
    """Get the singleton keystore client instance."""
    global _keystore_client_instance
    if _keystore_client_instance is None:
        _keystore_client_instance = KeystoreClient()
    return _keystore_client_instance


# Convenience function (backward compatibility)
def validate_api_key_via_keystore(api_key: str) -> bool:
    """
    Validate an API key using the main tool's keystore.

    Args:
        api_key: The API key to validate

    Returns:
        True if valid, False otherwise
    """
    return get_keystore_client().validate_key(api_key)


__all__ = [
    'KeystoreClient',
    'get_keystore_client',
    'validate_api_key_via_keystore',
]
