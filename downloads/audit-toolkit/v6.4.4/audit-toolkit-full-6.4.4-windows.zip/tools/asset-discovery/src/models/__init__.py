# Asset Discovery - Database Models
# Supports both SQLite (default) and PostgreSQL (enterprise)

from .base import Base, get_engine, get_session, init_db
from .asset import Asset, AssetNetworkInterface, AssetStorage
from .software import InstalledSoftware, WindowsUpdate, AssetService
from .vulnerability import CVERecord, CVECPEMatch, SoftwareVulnerability
from .scan import ScanJob, ScanResult, ScanCredential
from .patch import PendingUpdate, UpdateHistory
from .scheduled_scan import ScheduledScan, ScheduledScanExecution

__all__ = [
    # Base
    'Base', 'get_engine', 'get_session', 'init_db',
    # Assets
    'Asset', 'AssetNetworkInterface', 'AssetStorage',
    # Software
    'InstalledSoftware', 'WindowsUpdate', 'AssetService',
    # Vulnerabilities
    'CVERecord', 'CVECPEMatch', 'SoftwareVulnerability',
    # Scans
    'ScanJob', 'ScanResult', 'ScanCredential',
    # Scheduled Scans
    'ScheduledScan', 'ScheduledScanExecution',
    # Patches
    'PendingUpdate', 'UpdateHistory',
]
