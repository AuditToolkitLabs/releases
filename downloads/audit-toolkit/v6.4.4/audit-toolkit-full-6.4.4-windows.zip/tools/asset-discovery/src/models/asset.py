# Asset Discovery - Asset Models

import uuid
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime,
    ForeignKey, Numeric, JSON
)
from sqlalchemy.orm import relationship

from .base import Base


def generate_uuid() -> str:
    """Generate a UUID string."""
    return str(uuid.uuid4())


class Asset(Base):
    """Represents a discovered server, desktop, VM, or container."""

    __tablename__ = 'assets'

    id = Column(Integer, primary_key=True, autoincrement=True)
    uuid = Column(String(36), unique=True, default=generate_uuid, nullable=False)

    # Identity
    hostname = Column(String(255), nullable=False, index=True)
    fqdn = Column(String(512))
    domain = Column(String(255))

    # Classification
    asset_type = Column(String(50))  # 'server', 'desktop', 'vm', 'container'
    os_type = Column(String(50), index=True)  # 'windows', 'linux', 'macos'
    os_name = Column(String(255))
    os_version = Column(String(100))
    os_build = Column(String(100))
    kernel_version = Column(String(100))
    architecture = Column(String(20))  # 'x64', 'x86', 'arm64'

    # Hardware
    manufacturer = Column(String(255))
    model = Column(String(255))
    serial_number = Column(String(255))
    cpu_model = Column(String(255))
    cpu_cores = Column(Integer)
    cpu_threads = Column(Integer)
    total_memory_gb = Column(Numeric(10, 2))

    # Network (primary)
    primary_ip = Column(String(45))
    mac_address = Column(String(17))

    # Status
    last_boot_time = Column(DateTime)
    is_virtual = Column(Boolean, default=False)
    hypervisor = Column(String(100))  # 'vmware', 'hyper-v', 'kvm', 'virtualbox'
    status = Column(String(50), default='active', index=True)  # 'active', 'offline', 'decommissioned'

    # Organization
    environment = Column(String(50), index=True)  # 'production', 'staging', 'development'
    location = Column(String(255))
    owner = Column(String(255))
    business_unit = Column(String(255))
    criticality = Column(String(20))  # 'critical', 'high', 'medium', 'low'

    # Flexible fields
    tags = Column(JSON, default=list)
    custom_attributes = Column(JSON, default=dict)

    # Audit Execution Settings (for integration with Security Audit Toolkit)
    # Linux: 'sudo', 'sudo_nopasswd', 'audit_wrapper', 'none'
    # Windows: 'runas', 'jea', 'admin', 'none'
    elevation_method = Column(String(30), default='sudo')  # How scripts get elevated privileges
    jea_endpoint = Column(String(100))  # For Windows JEA: PowerShell session configuration name
    execution_mode = Column(String(20), default='stream')  # 'stream' or 'deployed'

    # Timestamps
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    network_interfaces = relationship("AssetNetworkInterface", back_populates="asset", cascade="all, delete-orphan")
    storage = relationship("AssetStorage", back_populates="asset", cascade="all, delete-orphan")
    software = relationship("InstalledSoftware", back_populates="asset", cascade="all, delete-orphan")
    services = relationship("AssetService", back_populates="asset", cascade="all, delete-orphan")
    windows_updates = relationship("WindowsUpdate", back_populates="asset", cascade="all, delete-orphan")
    vulnerabilities = relationship("SoftwareVulnerability", back_populates="asset", cascade="all, delete-orphan")
    pending_updates = relationship("PendingUpdate", back_populates="asset", cascade="all, delete-orphan")
    scan_results = relationship("ScanResult", back_populates="asset", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Asset(id={self.id}, hostname='{self.hostname}', os_type='{self.os_type}')>"

    def to_dict(self) -> dict:
        """Convert asset to dictionary."""
        return {
            'id': self.id,
            'uuid': self.uuid,
            'hostname': self.hostname,
            'fqdn': self.fqdn,
            'domain': self.domain,
            'asset_type': self.asset_type,
            'os_type': self.os_type,
            'os_name': self.os_name,
            'os_version': self.os_version,
            'os_build': self.os_build,
            'kernel_version': self.kernel_version,
            'architecture': self.architecture,
            'manufacturer': self.manufacturer,
            'model': self.model,
            'serial_number': self.serial_number,
            'cpu_model': self.cpu_model,
            'cpu_cores': self.cpu_cores,
            'cpu_threads': self.cpu_threads,
            'total_memory_gb': float(self.total_memory_gb) if self.total_memory_gb else None,
            'primary_ip': self.primary_ip,
            'mac_address': self.mac_address,
            'is_virtual': self.is_virtual,
            'hypervisor': self.hypervisor,
            'status': self.status,
            'environment': self.environment,
            'location': self.location,
            'owner': self.owner,
            'business_unit': self.business_unit,
            'criticality': self.criticality,
            'tags': self.tags or [],
            'custom_attributes': self.custom_attributes or {},
            'first_seen': self.first_seen.isoformat() if self.first_seen else None,
            'last_seen': self.last_seen.isoformat() if self.last_seen else None,
            # Audit execution settings
            'elevation_method': self.elevation_method,
            'jea_endpoint': self.jea_endpoint,
            'execution_mode': self.execution_mode,
        }


class AssetNetworkInterface(Base):
    """Network interfaces for an asset."""

    __tablename__ = 'asset_network_interfaces'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    interface_name = Column(String(100))
    ip_address = Column(String(45), index=True)
    subnet_mask = Column(String(45))
    gateway = Column(String(45))
    dns_servers = Column(JSON)  # List of DNS server IPs
    mac_address = Column(String(17))
    is_primary = Column(Boolean, default=False)
    speed_mbps = Column(Integer)
    status = Column(String(20))

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    asset = relationship("Asset", back_populates="network_interfaces")

    def __repr__(self) -> str:
        return f"<AssetNetworkInterface(id={self.id}, interface='{self.interface_name}', ip='{self.ip_address}')>"


class AssetStorage(Base):
    """Storage/disks for an asset."""

    __tablename__ = 'asset_storage'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    drive_letter = Column(String(10))  # Windows: C:, D:; Linux: /, /home
    mount_point = Column(String(512))
    filesystem_type = Column(String(50))
    total_size_gb = Column(Numeric(10, 2))
    free_space_gb = Column(Numeric(10, 2))
    used_percent = Column(Numeric(5, 2))
    is_system_drive = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    asset = relationship("Asset", back_populates="storage")

    def __repr__(self) -> str:
        return f"<AssetStorage(id={self.id}, mount='{self.mount_point}', size={self.total_size_gb}GB)>"
