# Asset Discovery - Database Base Configuration
# Supports SQLite (default) and PostgreSQL (enterprise)

import os
from contextlib import contextmanager
from typing import Generator, Optional

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import StaticPool

Base = declarative_base()

# Global engine and session factory
_engine: Optional[Engine] = None
_SessionLocal: Optional[sessionmaker] = None


def get_database_url() -> str:
    """Get database URL from environment or config."""
    # Check environment variable first
    db_url = os.environ.get('DATABASE_URL')
    if db_url:
        return db_url

    # Default to PostgreSQL for production scalability
    pg_host = os.environ.get('POSTGRES_HOST', 'localhost')
    pg_port = os.environ.get('POSTGRES_PORT', '5432')
    pg_db = os.environ.get('POSTGRES_DB', 'asset_discovery')
    pg_user = os.environ.get('POSTGRES_USER', 'discovery_admin')
    pg_pass = os.environ.get('POSTGRES_PASSWORD', 'discovery_secure_pass')
    return f"postgresql://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"


def get_engine(database_url: Optional[str] = None) -> Engine:
    """Get or create the database engine."""
    global _engine

    if _engine is not None:
        return _engine

    url = database_url or get_database_url()

    # SQLite-specific configuration
    if url.startswith('sqlite'):
        _engine = create_engine(
            url,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
            echo=os.environ.get('SQL_DEBUG', '').lower() == 'true'
        )

        # Enable foreign keys for SQLite
        @event.listens_for(_engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    else:
        # PostgreSQL configuration
        _engine = create_engine(
            url,
            pool_size=5,
            max_overflow=10,
            pool_pre_ping=True,
            echo=os.environ.get('SQL_DEBUG', '').lower() == 'true'
        )

    return _engine


def get_session_factory() -> sessionmaker:
    """Get the session factory."""
    global _SessionLocal

    if _SessionLocal is not None:
        return _SessionLocal

    engine = get_engine()
    _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    return _SessionLocal


def get_session() -> Session:
    """Get a new database session."""
    SessionLocal = get_session_factory()
    return SessionLocal()


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Provide a transactional scope around a series of operations."""
    session = get_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def init_db(database_url: Optional[str] = None) -> None:
    """Initialize the database, creating all tables."""
    engine = get_engine(database_url)

    # Import all models to ensure they're registered
    from . import asset, software, vulnerability, scan, patch  # noqa

    # Create all tables
    Base.metadata.create_all(bind=engine)

    # Run migrations for new columns (safe to run multiple times)
    _run_schema_migrations(engine)

    print(f"Database initialized: {engine.url}")


def _run_schema_migrations(engine) -> None:
    """
    Apply schema migrations for new columns.

    This function adds columns that may be missing from existing databases.
    Uses raw SQL with IF NOT EXISTS logic for safety.
    """
    from sqlalchemy import text, inspect

    inspector = inspect(engine)
    is_sqlite = 'sqlite' in str(engine.url)

    # Check if assets table exists and has expected columns
    if 'assets' in inspector.get_table_names():
        existing_columns = {col['name'] for col in inspector.get_columns('assets')}

        migrations = []

        # Add elevation_method column if missing
        if 'elevation_method' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE assets ADD COLUMN elevation_method VARCHAR(30) DEFAULT 'sudo'")
            else:  # PostgreSQL
                migrations.append("ALTER TABLE assets ADD COLUMN IF NOT EXISTS elevation_method VARCHAR(30) DEFAULT 'sudo'")

        # Add jea_endpoint column if missing
        if 'jea_endpoint' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE assets ADD COLUMN jea_endpoint VARCHAR(100)")
            else:  # PostgreSQL
                migrations.append("ALTER TABLE assets ADD COLUMN IF NOT EXISTS jea_endpoint VARCHAR(100)")

        # Add execution_mode column if missing
        if 'execution_mode' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE assets ADD COLUMN execution_mode VARCHAR(20) DEFAULT 'stream'")
            else:  # PostgreSQL
                migrations.append("ALTER TABLE assets ADD COLUMN IF NOT EXISTS execution_mode VARCHAR(20) DEFAULT 'stream'")

        # Execute migrations
        if migrations:
            with engine.connect() as conn:
                for migration in migrations:
                    try:
                        conn.execute(text(migration))
                        conn.commit()
                        print(f"Migration applied: {migration[:60]}...")
                    except Exception as e:
                        # Column might already exist (in case of race condition or SQLite quirks)
                        if 'duplicate' not in str(e).lower() and 'already exists' not in str(e).lower():
                            print(f"Migration warning: {e}")

    # Check if cve_records table exists and has expected columns
    if 'cve_records' in inspector.get_table_names():
        existing_columns = {col['name'] for col in inspector.get_columns('cve_records')}

        migrations = []

        if 'attack_vector' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN attack_vector VARCHAR(50)")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS attack_vector VARCHAR(50)")

        if 'attack_complexity' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN attack_complexity VARCHAR(20)")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS attack_complexity VARCHAR(20)")

        if 'privileges_required' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN privileges_required VARCHAR(20)")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS privileges_required VARCHAR(20)")

        if 'user_interaction' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN user_interaction VARCHAR(20)")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS user_interaction VARCHAR(20)")

        if 'scope' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN scope VARCHAR(20)")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS scope VARCHAR(20)")

        if 'cisa_kev' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN cisa_kev BOOLEAN DEFAULT 0")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS cisa_kev BOOLEAN DEFAULT FALSE")

        if 'cisa_due_date' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN cisa_due_date DATE")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS cisa_due_date DATE")

        if 'references' not in existing_columns:
            if is_sqlite:
                migrations.append('ALTER TABLE cve_records ADD COLUMN "references" TEXT')
            else:
                migrations.append('ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS "references" JSON')

        if 'cwe_ids' not in existing_columns:
            if is_sqlite:
                migrations.append("ALTER TABLE cve_records ADD COLUMN cwe_ids TEXT")
            else:
                migrations.append("ALTER TABLE cve_records ADD COLUMN IF NOT EXISTS cwe_ids JSON")

        # Execute migrations
        if migrations:
            with engine.connect() as conn:
                for migration in migrations:
                    try:
                        conn.execute(text(migration))
                        conn.commit()
                        print(f"Migration applied: {migration[:60]}...")
                    except Exception as e:
                        if 'duplicate' not in str(e).lower() and 'already exists' not in str(e).lower():
                            print(f"Migration warning: {e}")


def reset_engine() -> None:
    """Reset the engine (useful for testing)."""
    global _engine, _SessionLocal
    if _engine:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


# ---------------------------------------------------------------------------
# Main Toolkit (cross-tool) database support
# Used by sync_service.py for Direct SQL sync operations against the main
# Security Audit Toolkit database (which may differ from the asset discovery
# database when the two tools use separate PostgreSQL databases on the same
# server).
# ---------------------------------------------------------------------------

_main_toolkit_engine: Optional[Engine] = None
_MainToolkitSessionLocal: Optional[sessionmaker] = None


def get_main_toolkit_db_url() -> str:
    """Return the database URL for the main Security Audit Toolkit.

    Resolution order:
    1. ``MAIN_TOOLKIT_DATABASE_URL`` environment variable (explicit override)
    2. ``AUDIT_TOOLKIT_DATABASE_URL`` environment variable (alias)
    3. Derived from ``MAIN_TOOLKIT_POSTGRES_*`` environment variables
    4. Hardcoded default matching the standard VM appliance deployment
    """
    for env_var in ('MAIN_TOOLKIT_DATABASE_URL', 'AUDIT_TOOLKIT_DATABASE_URL'):
        url = os.environ.get(env_var)
        if url:
            return url

    pg_host = os.environ.get('MAIN_TOOLKIT_POSTGRES_HOST', os.environ.get('POSTGRES_HOST', 'localhost'))
    pg_port = os.environ.get('MAIN_TOOLKIT_POSTGRES_PORT', os.environ.get('POSTGRES_PORT', '5432'))
    pg_user = os.environ.get('MAIN_TOOLKIT_POSTGRES_USER', 'audittoolkit')
    pg_pass = os.environ.get('MAIN_TOOLKIT_POSTGRES_PASSWORD', 'Atk!7Xq3vL9mP2_kZ5nR8')
    pg_db = os.environ.get('MAIN_TOOLKIT_POSTGRES_DB', 'audittoolkit')
    return f"postgresql://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"


def get_main_toolkit_engine(database_url: Optional[str] = None) -> Engine:
    """Get or create the SQLAlchemy engine for the main toolkit database."""
    global _main_toolkit_engine

    if _main_toolkit_engine is not None:
        return _main_toolkit_engine

    url = database_url or get_main_toolkit_db_url()
    _main_toolkit_engine = create_engine(
        url,
        pool_size=3,
        max_overflow=5,
        pool_pre_ping=True,
        echo=os.environ.get('SQL_DEBUG', '').lower() == 'true',
    )
    return _main_toolkit_engine


def get_main_toolkit_session_factory() -> sessionmaker:
    """Get the session factory for the main toolkit database."""
    global _MainToolkitSessionLocal

    if _MainToolkitSessionLocal is not None:
        return _MainToolkitSessionLocal

    engine = get_main_toolkit_engine()
    _MainToolkitSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    return _MainToolkitSessionLocal


@contextmanager
def main_toolkit_session_scope() -> Generator[Session, None, None]:
    """Transactional scope against the main Security Audit Toolkit database.

    Used by ``sync_service.py`` when it needs to read from or write to the
    main toolkit's tables (e.g. ``servers``, ``server_cve_summaries``) which
    live in the ``audittoolkit`` PostgreSQL database rather than the asset
    discovery ``asset_discovery`` database.
    """
    factory = get_main_toolkit_session_factory()
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def reset_main_toolkit_engine() -> None:
    """Reset the main toolkit engine (useful for testing)."""
    global _main_toolkit_engine, _MainToolkitSessionLocal
    if _main_toolkit_engine:
        _main_toolkit_engine.dispose()
    _main_toolkit_engine = None
    _MainToolkitSessionLocal = None
