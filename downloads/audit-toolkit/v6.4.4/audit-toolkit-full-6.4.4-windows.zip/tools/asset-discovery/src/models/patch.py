# Asset Discovery - Patch & Update Models

from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime,
    ForeignKey, Date, JSON
)
from sqlalchemy.orm import relationship

from .base import Base


class PendingUpdate(Base):
    """Available updates (pending patches) for an asset."""

    __tablename__ = 'pending_updates'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    package_name = Column(String(512))
    current_version = Column(String(255))
    available_version = Column(String(255))
    update_type = Column(String(50), index=True)  # 'security', 'bugfix', 'feature', 'critical'
    severity = Column(String(20), index=True)
    kb_number = Column(String(20))  # Windows only
    repository = Column(String(255))  # Linux: repo name
    publish_date = Column(Date)
    cves_fixed = Column(JSON, default=list)  # List of CVE IDs fixed by this update
    requires_reboot = Column(Boolean, default=False)

    detected_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    asset = relationship("Asset", back_populates="pending_updates")

    def __repr__(self) -> str:
        return f"<PendingUpdate(id={self.id}, package='{self.package_name}', available='{self.available_version}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'asset_id': self.asset_id,
            'package_name': self.package_name,
            'current_version': self.current_version,
            'available_version': self.available_version,
            'update_type': self.update_type,
            'severity': self.severity,
            'kb_number': self.kb_number,
            'cves_fixed': self.cves_fixed or [],
            'requires_reboot': self.requires_reboot,
        }


class UpdateHistory(Base):
    """History of applied patches/updates."""

    __tablename__ = 'update_history'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    package_name = Column(String(512))
    from_version = Column(String(255))
    to_version = Column(String(255))
    update_type = Column(String(50))
    kb_number = Column(String(20))

    applied_at = Column(DateTime, index=True)
    applied_by = Column(String(255))  # 'automatic', 'manual', or user ID
    reboot_required = Column(Boolean)
    success = Column(Boolean, default=True)
    error_message = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<UpdateHistory(id={self.id}, package='{self.package_name}', to='{self.to_version}')>"
