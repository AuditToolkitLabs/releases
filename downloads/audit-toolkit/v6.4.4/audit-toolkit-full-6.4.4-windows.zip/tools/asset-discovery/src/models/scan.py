# Asset Discovery - Scan Job Models

import base64
import hashlib
import logging
import os
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, DateTime,
    ForeignKey, JSON, Boolean
)
from sqlalchemy.orm import relationship

from .base import Base

try:
    from cryptography.fernet import Fernet, InvalidToken
    CRYPTO_AVAILABLE = True
except ImportError:
    Fernet = None
    InvalidToken = Exception
    CRYPTO_AVAILABLE = False

logger = logging.getLogger(__name__)


def generate_uuid() -> str:
    """Generate a UUID string."""
    return str(uuid.uuid4())


class ScanJob(Base):
    """Discovery scan job."""

    __tablename__ = 'scan_jobs'

    id = Column(Integer, primary_key=True, autoincrement=True)
    uuid = Column(String(36), unique=True, default=generate_uuid, nullable=False)

    job_type = Column(String(50))  # 'discovery', 'software_inventory', 'vulnerability_scan', 'full'
    status = Column(String(50), default='pending', index=True)  # 'pending', 'running', 'completed', 'failed', 'cancelled'
    target_type = Column(String(50))  # 'single', 'range', 'subnet', 'group', 'all'
    targets = Column(JSON)  # List of target IPs/hostnames
    config = Column(JSON)  # Enhanced scan configuration (os_type, discovery_method, credentials, scope, schedule)

    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    created_by = Column(String(255))

    total_targets = Column(Integer, default=0)
    successful_targets = Column(Integer, default=0)
    failed_targets = Column(Integer, default=0)

    error_message = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    results = relationship("ScanResult", back_populates="scan_job", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<ScanJob(id={self.id}, type='{self.job_type}', status='{self.status}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'uuid': self.uuid,
            'job_type': self.job_type,
            'status': self.status,
            'target_type': self.target_type,
            'targets': self.targets or [],
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'created_by': self.created_by,
            'total_targets': self.total_targets,
            'successful_targets': self.successful_targets,
            'failed_targets': self.failed_targets,
            'error_message': self.error_message,
        }


class ScanResult(Base):
    """Results of scanning a single target."""

    __tablename__ = 'scan_results'

    id = Column(Integer, primary_key=True, autoincrement=True)
    scan_job_id = Column(Integer, ForeignKey('scan_jobs.id', ondelete='CASCADE'), nullable=False, index=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='SET NULL'), index=True)

    target = Column(String(255))  # IP or hostname
    status = Column(String(50))  # 'success', 'failed', 'unreachable', 'auth_failed'

    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)

    error_message = Column(Text)
    raw_output = Column(JSON)  # Full discovery output

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    scan_job = relationship("ScanJob", back_populates="results")
    asset = relationship("Asset", back_populates="scan_results")

    def __repr__(self) -> str:
        return f"<ScanResult(id={self.id}, target='{self.target}', status='{self.status}')>"


class ScanCredential(Base):
    """Encrypted credentials for scanning."""

    __tablename__ = 'scan_credentials'

    id = Column(Integer, primary_key=True, autoincrement=True)

    name = Column(String(255), nullable=False)
    description = Column(Text)
    credential_type = Column(String(50))  # 'windows_local', 'windows_domain', 'ssh_password', 'ssh_key'

    username = Column(String(255))
    encrypted_password = Column(Text)  # AES-256 encrypted (stored as base64)
    encrypted_private_key = Column(Text)  # For SSH key auth
    domain = Column(String(255))  # For Windows domain auth
    port = Column(Integer)

    is_default = Column(Boolean, default=False)
    created_by = Column(String(255))

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    ENCRYPTED_PREFIX = "enc:v1:"
    _cipher = None
    _cipher_loaded = False

    @classmethod
    def _derive_key(cls, secret: str) -> bytes:
        digest = hashlib.sha256(secret.encode('utf-8')).digest()
        return base64.urlsafe_b64encode(digest)

    @classmethod
    def _resolve_encryption_key(cls) -> str | None:
        return (
            os.getenv('ASSET_DISCOVERY_ENCRYPTION_KEY')
            or os.getenv('DB_FIELD_ENCRYPTION_KEY')
            or os.getenv('ENCRYPTION_KEY')
            or os.getenv('SECRET_KEY')
            or os.getenv('FLASK_SECRET_KEY')
        )

    @classmethod
    def _get_cipher(cls):
        if cls._cipher_loaded:
            return cls._cipher

        cls._cipher_loaded = True
        if not CRYPTO_AVAILABLE:
            logger.error("cryptography not installed; ScanCredential encryption unavailable")
            cls._cipher = None
            return None

        raw_key = cls._resolve_encryption_key()
        if not raw_key:
            logger.error("No encryption key configured for ScanCredential encryption")
            cls._cipher = None
            return None

        try:
            key_bytes = raw_key.encode('utf-8')
            if len(key_bytes) != 44:
                key_bytes = cls._derive_key(raw_key)
            cls._cipher = Fernet(key_bytes)
            return cls._cipher
        except Exception as exc:
            logger.error(f"Failed to initialize ScanCredential cipher: {exc}")
            cls._cipher = None
            return None

    @classmethod
    def _encrypt_value(cls, value: str) -> str:
        if not value:
            return value
        if value.startswith(cls.ENCRYPTED_PREFIX):
            return value

        cipher = cls._get_cipher()
        if not cipher:
            raise ValueError("Scan credential encryption key is not configured")

        token = cipher.encrypt(value.encode('utf-8')).decode('utf-8')
        return f"{cls.ENCRYPTED_PREFIX}{token}"

    @classmethod
    def _decrypt_value(cls, value: str | None) -> str | None:
        if not value:
            return value
        if not value.startswith(cls.ENCRYPTED_PREFIX):
            return value

        cipher = cls._get_cipher()
        if not cipher:
            raise ValueError("Scan credential encryption key is not configured")

        token = value[len(cls.ENCRYPTED_PREFIX):]
        try:
            return cipher.decrypt(token.encode('utf-8')).decode('utf-8')
        except InvalidToken as exc:
            raise ValueError("Stored scan credential is invalid or corrupted") from exc

    def set_password(self, password: str) -> None:
        self.encrypted_password = self._encrypt_value(password)

    def get_password(self) -> str | None:
        return self._decrypt_value(self.encrypted_password)

    def set_ssh_key(self, private_key: str) -> None:
        self.encrypted_private_key = self._encrypt_value(private_key)

    def get_ssh_key(self) -> str | None:
        return self._decrypt_value(self.encrypted_private_key)

    def __repr__(self) -> str:
        return f"<ScanCredential(id={self.id}, name='{self.name}', type='{self.credential_type}')>"
