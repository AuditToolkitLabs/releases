# Asset Discovery - Scheduled Scan Model
"""
Scheduled Scan Model for Asset Discovery

Provides ORM model for scheduled asset discovery scans with cron expressions.
Supports automatic vulnerability report refresh after scan completion.

Author: Security Audit Toolkit Team
Date: March 2026
"""

import uuid
import logging
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime,
    ForeignKey, Text, JSON, Index
)
from sqlalchemy.orm import relationship

from .base import Base

logger = logging.getLogger(__name__)

try:
    from croniter import croniter
    HAS_CRONITER = True
except ImportError:
    HAS_CRONITER = False


def generate_uuid() -> str:
    """Generate a UUID string."""
    return str(uuid.uuid4())


class ScheduledScan(Base):
    """
    Scheduled Scan Model

    Represents a recurring scan schedule for asset discovery.
    Similar to ScheduledAudit in main toolkit but for asset scans.

    Attributes:
        id: Unique schedule identifier
        uuid: UUID for external references
        name: Human-readable schedule name
        target_type: Type of target ('asset', 'group', 'subnet', 'all')
        asset_id: Foreign key to assets table (for single asset scans)
        target_config: JSON config for complex targets (subnets, IP ranges, groups)
        scan_type: Type of scan ('discovery', 'software_inventory', 'vulnerability_scan', 'full')
        cron_schedule: Cron expression (e.g., "0 2 * * *")
        is_active: Enable/disable schedule
        auto_refresh_vulns: Automatically refresh vulnerability report after scan
        sync_to_audit_tool: Sync results to main audit tool
        notification_enabled: Send notifications on completion
        notification_emails: Comma-separated email addresses
        notification_webhooks: Comma-separated webhook URLs
        last_run: Timestamp of last execution
        next_run: Calculated next run time
        last_status: Status of last execution
        run_count: Number of successful executions
    """
    __tablename__ = 'scheduled_scans'
    __table_args__ = (
        # Index for scheduler queries: find active schedules due to run
        Index('idx_scheduled_scan_active_next_run', 'is_active', 'next_run'),
        # Index for asset-based lookups
        Index('idx_scheduled_scan_asset_id', 'asset_id'),
        {'extend_existing': True}
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    uuid = Column(String(36), unique=True, default=generate_uuid, nullable=False)
    name = Column(String(255), nullable=False)

    # Target configuration
    target_type = Column(String(50), nullable=False, default='asset')  # 'asset', 'group', 'subnet', 'all'
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='SET NULL'), nullable=True)
    target_config = Column(JSON)  # For complex targets: {'subnet': '192.168.1.0/24', 'ips': [...], 'group_id': 123}

    # Scan configuration
    scan_type = Column(String(50), nullable=False, default='full')  # 'discovery', 'software_inventory', 'vulnerability_scan', 'full'
    scan_options = Column(JSON)  # Additional scan options: {'os_type': 'auto', 'discovery_method': 'ssh', 'scope': {...}}

    # Schedule
    cron_schedule = Column(String(100), nullable=False)  # e.g., "0 2 * * *"
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    timezone = Column(String(50), default='UTC')

    # Post-scan actions
    auto_refresh_vulns = Column(Boolean, default=True, nullable=False)  # Refresh vuln report after scan
    sync_to_audit_tool = Column(Boolean, default=True, nullable=False)  # Sync to main audit tool
    trigger_audit_after = Column(Boolean, default=False, nullable=False)  # Trigger audit after scan

    # Notification settings
    notification_enabled = Column(Boolean, default=False, nullable=False)
    notification_emails = Column(Text)  # Comma-separated
    notification_webhooks = Column(Text)  # Comma-separated

    # Execution tracking
    last_run = Column(DateTime)
    next_run = Column(DateTime)
    last_status = Column(String(50))  # 'success', 'failure', 'error', 'running', 'pending'
    last_error = Column(Text)
    last_scan_id = Column(Integer, ForeignKey('scan_jobs.id', ondelete='SET NULL'))
    run_count = Column(Integer, default=0)
    failure_count = Column(Integer, default=0)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(255))

    # Relationships
    asset = relationship('Asset', backref='scheduled_scans')
    last_scan = relationship('ScanJob', foreign_keys=[last_scan_id])

    def __repr__(self) -> str:
        return f"<ScheduledScan(id={self.id}, name='{self.name}', active={self.is_active})>"

    def to_dict(self, include_relations: bool = True) -> dict:
        """Convert to dictionary representation."""
        data = {
            'id': self.id,
            'uuid': self.uuid,
            'name': self.name,
            'target_type': self.target_type,
            'asset_id': self.asset_id,
            'target_config': self.target_config,
            'scan_type': self.scan_type,
            'scan_options': self.scan_options,
            'cron_schedule': self.cron_schedule,
            'cron_description': self.get_cron_description(),
            'is_active': self.is_active,
            'timezone': self.timezone,
            'auto_refresh_vulns': self.auto_refresh_vulns,
            'sync_to_audit_tool': self.sync_to_audit_tool,
            'trigger_audit_after': self.trigger_audit_after,
            'notification_enabled': self.notification_enabled,
            'notification_emails': self.notification_emails,
            'notification_webhooks': self.notification_webhooks,
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'last_status': self.last_status,
            'last_error': self.last_error,
            'last_scan_id': self.last_scan_id,
            'run_count': self.run_count,
            'failure_count': self.failure_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by
        }

        if include_relations:
            if self.asset:
                data['asset'] = {
                    'id': self.asset.id,
                    'hostname': self.asset.hostname,
                    'primary_ip': self.asset.primary_ip,
                    'os_type': self.asset.os_type
                }

        return data

    def get_cron_description(self) -> str:
        """Get human-readable description of cron schedule."""
        cron = self.cron_schedule
        if not cron:
            return "No schedule"

        # Common patterns
        patterns = {
            '0 * * * *': 'Every hour',
            '*/15 * * * *': 'Every 15 minutes',
            '*/30 * * * *': 'Every 30 minutes',
            '0 0 * * *': 'Daily at midnight',
            '0 2 * * *': 'Daily at 2:00 AM',
            '0 6 * * *': 'Daily at 6:00 AM',
            '0 0 * * 0': 'Weekly on Sunday at midnight',
            '0 2 * * 0': 'Weekly on Sunday at 2:00 AM',
            '0 0 * * 1': 'Weekly on Monday at midnight',
            '0 2 * * 1': 'Weekly on Monday at 2:00 AM',
            '0 0 1 * *': 'Monthly on the 1st at midnight',
            '0 2 1 * *': 'Monthly on the 1st at 2:00 AM',
        }

        if cron in patterns:
            return patterns[cron]

        # Parse cron parts for custom description
        try:
            parts = cron.split()
            if len(parts) >= 5:
                minute, hour, dom, month, dow = parts[:5]

                # Build description
                desc_parts = []

                # Time
                if minute == '0' and hour != '*':
                    desc_parts.append(f"at {hour}:00")
                elif minute != '*' and hour != '*':
                    desc_parts.append(f"at {hour}:{minute.zfill(2)}")
                elif minute == '*':
                    desc_parts.append("every minute")

                # Day of week
                dow_names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
                if dow != '*':
                    try:
                        dow_int = int(dow)
                        if 0 <= dow_int <= 6:
                            desc_parts.append(f"on {dow_names[dow_int]}")
                    except ValueError:
                        desc_parts.append(f"on day {dow}")

                # Day of month
                if dom != '*':
                    desc_parts.append(f"of the {dom}{'st' if dom == '1' else 'th'} day")

                # Month
                if month != '*':
                    desc_parts.append(f"in month {month}")

                return ' '.join(desc_parts) if desc_parts else cron

        except Exception as cron_desc_error:  # noqa: BLE001 - fallback to raw cron expression
            logger.debug("Could not build human-readable cron description for %s: %s", cron, cron_desc_error)

        return cron

    def calculate_next_run(self, from_time: Optional[datetime] = None) -> Optional[datetime]:
        """Calculate the next scheduled run time."""
        if not HAS_CRONITER:
            return None

        if not self.cron_schedule:
            return None

        try:
            base_time = from_time or datetime.utcnow()
            cron = croniter(self.cron_schedule, base_time)
            return cron.get_next(datetime)
        except Exception:
            return None

    def update_next_run(self) -> None:
        """Update the next_run field based on cron schedule."""
        self.next_run = self.calculate_next_run()


class ScheduledScanExecution(Base):
    """
    Execution history for scheduled scans.

    Records each execution of a scheduled scan for auditing and reporting.
    """
    __tablename__ = 'scheduled_scan_executions'
    __table_args__ = (
        Index('idx_sse_scheduled_scan_id', 'scheduled_scan_id'),
        Index('idx_sse_status', 'status'),
        Index('idx_sse_started_at', 'started_at'),
        {'extend_existing': True}
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    scheduled_scan_id = Column(Integer, ForeignKey('scheduled_scans.id', ondelete='CASCADE'), nullable=False)
    scan_job_id = Column(Integer, ForeignKey('scan_jobs.id', ondelete='SET NULL'))

    # Execution details
    status = Column(String(50), nullable=False)  # 'started', 'completed', 'failed', 'cancelled'
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)

    # Results summary
    targets_scanned = Column(Integer, default=0)
    targets_successful = Column(Integer, default=0)
    targets_failed = Column(Integer, default=0)
    vulnerabilities_found = Column(Integer, default=0)
    new_vulnerabilities = Column(Integer, default=0)

    # Post-scan actions
    vuln_refresh_completed = Column(Boolean, default=False)
    audit_tool_synced = Column(Boolean, default=False)
    audit_triggered = Column(Boolean, default=False)

    # Error tracking
    error_message = Column(Text)
    error_details = Column(JSON)

    # Relationships
    scheduled_scan = relationship('ScheduledScan', backref='executions')
    scan_job = relationship('ScanJob')

    def __repr__(self) -> str:
        return f"<ScheduledScanExecution(id={self.id}, scan_id={self.scheduled_scan_id}, status='{self.status}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {
            'id': self.id,
            'scheduled_scan_id': self.scheduled_scan_id,
            'scan_job_id': self.scan_job_id,
            'status': self.status,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_seconds': self.duration_seconds,
            'targets_scanned': self.targets_scanned,
            'targets_successful': self.targets_successful,
            'targets_failed': self.targets_failed,
            'vulnerabilities_found': self.vulnerabilities_found,
            'new_vulnerabilities': self.new_vulnerabilities,
            'vuln_refresh_completed': self.vuln_refresh_completed,
            'audit_tool_synced': self.audit_tool_synced,
            'audit_triggered': self.audit_triggered,
            'error_message': self.error_message
        }
