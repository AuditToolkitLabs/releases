# Asset Discovery - Software & Service Models

from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime,
    ForeignKey, Date
)
from sqlalchemy.orm import relationship

from .base import Base


class InstalledSoftware(Base):
    """Installed software/packages on an asset."""

    __tablename__ = 'installed_software'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    name = Column(String(512), nullable=False, index=True)
    version = Column(String(255))
    version_raw = Column(String(255))  # Original version string
    publisher = Column(String(255))
    install_date = Column(Date)
    install_location = Column(String(1024))
    architecture = Column(String(20))  # 'x64', 'x86', 'noarch'
    package_type = Column(String(50))  # 'msi', 'exe', 'deb', 'rpm', 'snap', 'flatpak'
    is_security_update = Column(Boolean, default=False)
    is_system_component = Column(Boolean, default=False)
    cpe_uri = Column(String(512), index=True)  # CPE identifier for CVE matching

    first_detected = Column(DateTime, default=datetime.utcnow)
    last_detected = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    asset = relationship("Asset", back_populates="software")
    vulnerabilities = relationship("SoftwareVulnerability", back_populates="software", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<InstalledSoftware(id={self.id}, name='{self.name}', version='{self.version}')>"

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'asset_id': self.asset_id,
            'name': self.name,
            'version': self.version,
            'publisher': self.publisher,
            'install_date': self.install_date.isoformat() if self.install_date else None,
            'architecture': self.architecture,
            'package_type': self.package_type,
            'cpe_uri': self.cpe_uri,
        }


class WindowsUpdate(Base):
    """Windows hotfixes/updates installed on an asset."""

    __tablename__ = 'windows_updates'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    kb_number = Column(String(20), index=True)  # KB5034441
    description = Column(Text)
    installed_on = Column(Date)
    installed_by = Column(String(255))
    update_type = Column(String(50))  # 'Security Update', 'Update', 'Hotfix'

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    asset = relationship("Asset", back_populates="windows_updates")

    def __repr__(self) -> str:
        return f"<WindowsUpdate(id={self.id}, kb='{self.kb_number}')>"


class AssetService(Base):
    """Services running on an asset."""

    __tablename__ = 'asset_services'

    id = Column(Integer, primary_key=True, autoincrement=True)
    asset_id = Column(Integer, ForeignKey('assets.id', ondelete='CASCADE'), nullable=False, index=True)

    service_name = Column(String(255), index=True)
    display_name = Column(String(512))
    status = Column(String(50))  # 'running', 'stopped', 'disabled'
    start_type = Column(String(50))  # 'automatic', 'manual', 'disabled'
    account = Column(String(255))  # Service account
    binary_path = Column(String(1024))
    description = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    asset = relationship("Asset", back_populates="services")

    def __repr__(self) -> str:
        return f"<AssetService(id={self.id}, name='{self.service_name}', status='{self.status}')>"
