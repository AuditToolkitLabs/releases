# Asset Discovery - Background Job Scheduler
#
# Provides automated CVE sync and vulnerability re-matching using APScheduler

import os
import logging
import threading
from datetime import datetime, timedelta
from typing import Callable, Optional

logger = logging.getLogger('scheduler')

# Track scheduler state
_scheduler = None
_scheduler_lock = threading.Lock()


class SimpleScheduler:
    """
    Lightweight scheduler for background jobs.
    Uses threading.Timer for scheduled execution.
    """

    def __init__(self):
        self.jobs = {}  # job_id -> job_info
        self.timers = {}  # job_id -> Timer
        self.running = False
        self._lock = threading.Lock()

    def start(self):
        """Start the scheduler."""
        with self._lock:
            if self.running:
                return
            self.running = True
            logger.info("Scheduler started")

            # Start all configured jobs
            for job_id, job_info in self.jobs.items():
                self._schedule_job(job_id)

    def shutdown(self):
        """Shutdown the scheduler."""
        with self._lock:
            self.running = False
            # Cancel all pending timers
            for timer in self.timers.values():
                timer.cancel()
            self.timers.clear()
            logger.info("Scheduler shutdown")

    def add_job(
        self,
        func: Callable,
        job_id: str,
        interval_hours: float = 24,
        run_immediately: bool = False,
        enabled: bool = True,
        run_time_utc: Optional[str] = None,
    ):
        """
        Add a scheduled job.

        Args:
            func: Function to execute
            job_id: Unique job identifier
            interval_hours: Hours between executions (default 24, can be fractional)
            run_immediately: Run once immediately when added
            enabled: Whether job is enabled
        """
        with self._lock:
            self.jobs[job_id] = {
                'func': func,
                'interval_hours': interval_hours,
                'enabled': enabled,
                'run_time_utc': run_time_utc,
                'last_run': None,
                'next_run': None,
                'run_count': 0,
                'last_error': None
            }

            if run_immediately and enabled:
                # Run in a separate thread to not block
                thread = threading.Thread(
                    target=self._run_job,
                    args=(job_id,),
                    daemon=True
                )
                thread.start()

            if self.running and enabled:
                self._schedule_job(job_id)

            logger.info(f"Job '{job_id}' added (interval: {interval_hours}h, enabled: {enabled})")

    def update_job(
        self,
        job_id: str,
        interval_hours: Optional[int] = None,
        enabled: Optional[bool] = None,
        run_time_utc: Optional[str] = None,
    ):
        """Update job configuration."""
        with self._lock:
            if job_id not in self.jobs:
                raise ValueError(f"Job '{job_id}' not found")

            job = self.jobs[job_id]

            if interval_hours is not None:
                job['interval_hours'] = interval_hours

            if enabled is not None:
                job['enabled'] = enabled

            if run_time_utc is not None:
                run_time_utc = str(run_time_utc).strip()
                if run_time_utc:
                    self._validate_run_time_utc(run_time_utc)
                    job['run_time_utc'] = run_time_utc
                else:
                    job['run_time_utc'] = None

            # Cancel existing timer
            if job_id in self.timers:
                self.timers[job_id].cancel()
                del self.timers[job_id]

            # Reschedule if running and enabled
            if self.running and job['enabled']:
                self._schedule_job(job_id)

            logger.info(f"Job '{job_id}' updated (interval: {job['interval_hours']}h, enabled: {job['enabled']})")

    def remove_job(self, job_id: str):
        """Remove a scheduled job."""
        with self._lock:
            if job_id in self.timers:
                self.timers[job_id].cancel()
                del self.timers[job_id]
            if job_id in self.jobs:
                del self.jobs[job_id]
                logger.info(f"Job '{job_id}' removed")

    def run_job_now(self, job_id: str):
        """Manually trigger a job to run immediately."""
        if job_id not in self.jobs:
            raise ValueError(f"Job '{job_id}' not found")

        thread = threading.Thread(
            target=self._run_job,
            args=(job_id,),
            daemon=True
        )
        thread.start()
        return thread

    def get_job_status(self, job_id: Optional[str] = None) -> Optional[dict]:
        """Get status of one or all jobs."""
        with self._lock:
            if job_id:
                if job_id not in self.jobs:
                    return None
                job = self.jobs[job_id]
                return {
                    'job_id': job_id,
                    'interval_hours': job['interval_hours'],
                    'enabled': job['enabled'],
                    'run_time_utc': job.get('run_time_utc'),
                    'last_run': job['last_run'].isoformat() if job['last_run'] else None,
                    'next_run': job['next_run'].isoformat() if job['next_run'] else None,
                    'run_count': job['run_count'],
                    'last_error': job['last_error']
                }
            else:
                # Build status dict for all jobs without recursive lock acquisition
                result = {}
                for jid in self.jobs:
                    job = self.jobs[jid]
                    result[jid] = {
                        'job_id': jid,
                        'interval_hours': job['interval_hours'],
                        'enabled': job['enabled'],
                        'run_time_utc': job.get('run_time_utc'),
                        'last_run': job['last_run'].isoformat() if job['last_run'] else None,
                        'next_run': job['next_run'].isoformat() if job['next_run'] else None,
                        'run_count': job['run_count'],
                        'last_error': job['last_error']
                    }
                return result

    @staticmethod
    def _validate_run_time_utc(run_time_utc: str) -> None:
        """Validate HH:MM 24-hour UTC time value."""
        parts = run_time_utc.split(':')
        if len(parts) != 2:
            raise ValueError("run_time_utc must be in HH:MM format")
        hour = int(parts[0])
        minute = int(parts[1])
        if hour < 0 or hour > 23 or minute < 0 or minute > 59:
            raise ValueError("run_time_utc must be a valid 24-hour UTC time")

    def _compute_next_run(self, job: dict) -> datetime:
        """Compute next run timestamp for interval or fixed daily UTC-time mode."""
        interval_seconds = float(job['interval_hours']) * 3600
        run_time_utc = (job.get('run_time_utc') or '').strip()

        if run_time_utc and float(job['interval_hours']) >= 24:
            self._validate_run_time_utc(run_time_utc)
            hour, minute = (int(p) for p in run_time_utc.split(':'))
            now = datetime.utcnow()

            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=1)

            step_days = max(1, int(round(float(job['interval_hours']) / 24.0)))
            while next_run <= now:
                next_run += timedelta(days=step_days)
            return next_run

        return datetime.utcnow() + timedelta(seconds=interval_seconds)

    def _schedule_job(self, job_id: str):
        """Schedule the next execution of a job."""
        job = self.jobs.get(job_id)
        if not job or not job['enabled']:
            return

        next_run = self._compute_next_run(job)
        delay_seconds = max((next_run - datetime.utcnow()).total_seconds(), 1)
        job['next_run'] = next_run

        def run_and_reschedule():
            self._run_job(job_id)
            with self._lock:
                if self.running and job_id in self.jobs and self.jobs[job_id]['enabled']:
                    self._schedule_job(job_id)

        timer = threading.Timer(delay_seconds, run_and_reschedule)
        timer.daemon = True
        timer.start()

        self.timers[job_id] = timer
        logger.debug(f"Job '{job_id}' scheduled for {next_run}")

    def _run_job(self, job_id: str):
        """Execute a job."""
        job = self.jobs.get(job_id)
        if not job:
            return

        logger.info(f"Running job '{job_id}'")
        start_time = datetime.utcnow()

        try:
            job['func']()
            job['last_error'] = None
            logger.info(f"Job '{job_id}' completed successfully")
        except Exception as e:
            job['last_error'] = str(e)
            logger.error(f"Job '{job_id}' failed: {e}")

        job['last_run'] = start_time
        job['run_count'] += 1


def get_scheduler() -> SimpleScheduler:
    """Get or create the global scheduler instance."""
    global _scheduler
    with _scheduler_lock:
        if _scheduler is None:
            _scheduler = SimpleScheduler()
        return _scheduler


def init_scheduler(app=None):
    """
    Initialize the scheduler with default jobs.

    Jobs:
    - cve_sync: Sync CVEs from NVD (default: daily)
    - vulnerability_rematch: Re-match assets against CVEs (default: after CVE sync)
    - scheduled_scan_runner: Check for and execute due scheduled scans
    """
    logger.info("Starting scheduler initialization...")

    try:
        from .config import get_config
        from .cve_sync import NVDSync
        from .vulnerability_matcher import rematch_all_assets
    except Exception as e:
        logger.error(f"Failed to import scheduler dependencies: {e}")
        raise

    config = get_config()
    scheduler = get_scheduler()

    # Get sync configuration from environment or config
    sync_enabled = os.environ.get('CVE_SYNC_ENABLED', 'true').lower() in ('true', '1', 'yes')
    sync_interval = int(os.environ.get('CVE_SYNC_INTERVAL_HOURS', config.nvd.sync_interval_hours))
    cve_sync_time_utc = os.environ.get('CVE_SYNC_TIME_UTC', '02:00').strip() or '02:00'
    rematch_enabled = os.environ.get('VULN_REMATCH_ENABLED', 'true').lower() in ('true', '1', 'yes')
    scheduled_scan_enabled = os.environ.get('SCHEDULED_SCANS_ENABLED', 'true').lower() in ('true', '1', 'yes')

    logger.info(f"Scheduler config: CVE sync every {sync_interval}h (enabled={sync_enabled}), rematch={rematch_enabled}, scheduled_scans={scheduled_scan_enabled}")

    def cve_sync_job():
        """CVE sync job function."""
        logger.info("Starting scheduled CVE sync")
        try:
            api_key = config.nvd.api_key or os.environ.get('NVD_API_KEY')
            syncer = NVDSync(api_key=api_key)

            # Sync recent CVEs (last 7 days)
            syncer.sync_cves(days_back=7)

            # Sync KEV catalog
            syncer.sync_kev()

            # Backfill incomplete CVEs before matching against host data
            syncer.backfill_incomplete_cves(max_records=250)

            # Always trigger vulnerability re-matching after CVE metadata sync completes.
            logger.info("Triggering vulnerability re-match after CVE sync")
            rematch_all_assets()

            logger.info("Scheduled CVE sync completed")
        except Exception as e:
            logger.error(f"Scheduled CVE sync failed: {e}")
            raise

    def vulnerability_rematch_job():
        """Standalone vulnerability re-match job."""
        logger.info("Starting scheduled vulnerability re-match")
        try:
            rematch_all_assets()
            logger.info("Scheduled vulnerability re-match completed")
        except Exception as e:
            logger.error(f"Scheduled vulnerability re-match failed: {e}")
            raise

    def scheduled_scan_runner_job():
        """Check for and execute due scheduled scans."""
        logger.info("Checking for due scheduled scans")
        try:
            run_due_scheduled_scans()
            logger.info("Scheduled scan check completed")
        except Exception as e:
            logger.error(f"Scheduled scan runner failed: {e}")
            raise

    # Add jobs with individual error handling
    jobs_added = 0

    try:
        scheduler.add_job(
            func=cve_sync_job,
            job_id='cve_sync',
            interval_hours=sync_interval,
            run_immediately=False,
            enabled=sync_enabled,
            run_time_utc=cve_sync_time_utc,
        )
        jobs_added += 1
        logger.info(f"Added job: cve_sync (interval={sync_interval}h, enabled={sync_enabled})")
    except Exception as e:
        logger.error(f"Failed to add cve_sync job: {e}")

    try:
        scheduler.add_job(
            func=vulnerability_rematch_job,
            job_id='vulnerability_rematch',
            interval_hours=sync_interval * 2,
            run_immediately=False,
            enabled=rematch_enabled
        )
        jobs_added += 1
        logger.info(f"Added job: vulnerability_rematch (interval={sync_interval * 2}h, enabled={rematch_enabled})")
    except Exception as e:
        logger.error(f"Failed to add vulnerability_rematch job: {e}")

    try:
        scheduler.add_job(
            func=scheduled_scan_runner_job,
            job_id='scheduled_scan_runner',
            interval_hours=1/12,  # Every 5 minutes
            run_immediately=False,
            enabled=scheduled_scan_enabled
        )
        jobs_added += 1
        logger.info(f"Added job: scheduled_scan_runner (interval=5min, enabled={scheduled_scan_enabled})")
    except Exception as e:
        logger.error(f"Failed to add scheduled_scan_runner job: {e}")

    # Start the scheduler
    scheduler.start()

    logger.info(f"Scheduler initialized with {jobs_added} jobs (CVE sync: {sync_interval}h, enabled: {sync_enabled})")

    return scheduler


def shutdown_scheduler():
    """Shutdown the scheduler."""
    global _scheduler
    with _scheduler_lock:
        if _scheduler:
            _scheduler.shutdown()
            _scheduler = None


def run_due_scheduled_scans():
    """
    Check for and execute scheduled scans that are due.

    This function is called periodically by the scheduler to find
    scheduled scans where next_run <= now and execute them.
    """
    from datetime import datetime
    from .models.base import session_scope
    from .models.asset import Asset
    from .models.scan import ScanJob
    from .models.scheduled_scan import ScheduledScan, ScheduledScanExecution
    import uuid as uuid_module

    now = datetime.utcnow()
    executed_count = 0

    with session_scope() as session:
        # Find scheduled scans that are due
        due_scans = session.query(ScheduledScan).filter(
            ScheduledScan.is_active == True,
            ScheduledScan.next_run <= now
        ).all()

        if not due_scans:
            logger.debug("No scheduled scans due")
            return

        logger.info(f"Found {len(due_scans)} scheduled scans due for execution")

        for schedule in due_scans:
            try:
                logger.info(f"Executing scheduled scan: {schedule.name} (ID: {schedule.id})")

                # Create execution record
                execution = ScheduledScanExecution(
                    scheduled_scan_id=schedule.id,
                    status='started',
                    started_at=now
                )
                session.add(execution)
                session.flush()

                # Determine targets
                targets = []
                if schedule.target_type == 'asset' and schedule.asset_id:
                    asset = session.query(Asset).filter(Asset.id == schedule.asset_id).first()
                    if asset:
                        targets = [asset.primary_ip or asset.hostname]
                elif schedule.target_type == 'all':
                    assets = session.query(Asset).filter(Asset.status == 'active').all()
                    targets = [a.primary_ip or a.hostname for a in assets if (a.primary_ip or a.hostname)]
                elif schedule.target_config:
                    if 'ips' in schedule.target_config:
                        targets = schedule.target_config['ips']
                    elif 'subnet' in schedule.target_config:
                        targets = [schedule.target_config['subnet']]

                if not targets:
                    execution.status = 'failed'
                    execution.error_message = 'No valid targets found'
                    schedule.last_status = 'failed'
                    schedule.failure_count += 1
                    schedule.update_next_run()
                    continue

                # Create scan job
                scan_job = ScanJob(
                    uuid=str(uuid_module.uuid4()),
                    job_type=schedule.scan_type,
                    status='pending',
                    targets=targets,
                    total_targets=len(targets),
                    config={
                        'scheduled_scan_id': schedule.id,
                        'execution_id': execution.id,
                        'auto_refresh_vulns': schedule.auto_refresh_vulns,
                        'sync_to_audit_tool': schedule.sync_to_audit_tool,
                        'trigger_audit_after': schedule.trigger_audit_after,
                        **(schedule.scan_options or {})
                    },
                    created_by=f'scheduled:{schedule.name}'
                )
                session.add(scan_job)
                session.flush()

                # Update execution with scan job reference
                execution.scan_job_id = scan_job.id
                execution.targets_scanned = len(targets)

                # Mark scan as running (actual scan execution would be triggered separately)
                scan_job.status = 'running'
                scan_job.started_at = now

                # Update schedule tracking
                schedule.last_run = now
                schedule.last_status = 'running'
                schedule.last_scan_id = scan_job.id
                schedule.run_count += 1
                schedule.update_next_run()

                executed_count += 1

                # Note: In a production system, the actual scan would be executed
                # asynchronously (e.g., via Celery task). For now, we just create
                # the scan job and mark it as running.

                logger.info(f"Created scan job {scan_job.id} for scheduled scan {schedule.id}")

            except Exception as e:
                logger.error(f"Error executing scheduled scan {schedule.id}: {e}")
                schedule.last_status = 'error'
                schedule.last_error = str(e)
                schedule.failure_count += 1
                schedule.update_next_run()

        session.commit()

    logger.info(f"Executed {executed_count} scheduled scans")
    return executed_count


def complete_scheduled_scan(scan_job_id: int, success: bool = True, error_message: str | None = None):
    """
    Mark a scheduled scan as complete and perform post-scan actions.

    Called when a scan job completes to:
    - Update execution record
    - Refresh vulnerability reports (if configured)
    - Sync to main audit tool (if configured)
    - Send notifications (if configured)
    """
    from datetime import datetime
    from .models.base import session_scope
    from .models.scan import ScanJob, ScanResult
    from .models.scheduled_scan import ScheduledScan, ScheduledScanExecution
    from .sync_service import get_sync_service
    from .vulnerability_matcher import update_asset_vulnerabilities

    with session_scope() as session:
        scan_job = session.query(ScanJob).filter(ScanJob.id == scan_job_id).first()
        if not scan_job:
            logger.error(f"Scan job {scan_job_id} not found")
            return

        config = scan_job.config or {}
        scheduled_scan_id = config.get('scheduled_scan_id')
        execution_id = config.get('execution_id')

        if not scheduled_scan_id:
            # Not a scheduled scan
            return

        schedule = session.query(ScheduledScan).filter(
            ScheduledScan.id == scheduled_scan_id
        ).first()

        if not schedule:
            logger.error(f"Scheduled scan {scheduled_scan_id} not found")
            return

        # Update scan job status
        scan_job.status = 'completed' if success else 'failed'
        scan_job.completed_at = datetime.utcnow()

        # Get execution record
        execution = None
        if execution_id:
            execution = session.query(ScheduledScanExecution).filter(
                ScheduledScanExecution.id == execution_id
            ).first()

        if execution:
            execution.status = 'completed' if success else 'failed'
            execution.completed_at = datetime.utcnow()
            execution.duration_seconds = int(
                (execution.completed_at - execution.started_at).total_seconds()
            ) if execution.started_at else None
            execution.error_message = error_message

            # Get scan results summary
            results = session.query(ScanResult).filter(
                ScanResult.scan_job_id == scan_job_id
            ).all()

            execution.targets_successful = len([r for r in results if r.status == 'success'])
            execution.targets_failed = len([r for r in results if r.status != 'success'])

        # Update schedule status
        schedule.last_status = 'success' if success else 'failed'
        schedule.last_error = error_message

        session.commit()

        # Perform post-scan actions if successful
        if success:
            # Refresh vulnerability reports
            if config.get('auto_refresh_vulns', False):
                logger.info(f"Refreshing vulnerability reports for scan {scan_job_id}")
                try:
                    # Get asset IDs from scan results
                    asset_ids = [r.asset_id for r in results if r.asset_id and r.status == 'success']
                    for asset_id in asset_ids:
                        update_asset_vulnerabilities(asset_id, session)

                    if execution:
                        execution.vuln_refresh_completed = True

                except Exception as e:
                    logger.error(f"Failed to refresh vulnerability reports: {e}")

            # Sync to main audit tool
            if config.get('sync_to_audit_tool', False):
                logger.info(f"Syncing scan {scan_job_id} results to audit tool")
                try:
                    sync_service = get_sync_service()
                    sync_result = sync_service.sync_scan_complete(scan_job_id)

                    if execution:
                        execution.audit_tool_synced = sync_result.success

                except Exception as e:
                    logger.error(f"Failed to sync to audit tool: {e}")

            session.commit()

        logger.info(f"Completed scheduled scan {scheduled_scan_id}, job {scan_job_id}")
