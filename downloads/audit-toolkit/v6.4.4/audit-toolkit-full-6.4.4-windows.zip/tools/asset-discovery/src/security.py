# Asset Discovery - Security Utilities
#
# OWASP-compliant security helpers for input validation, sanitization,
# rate limiting, and secure error handling.

import re
import html
import os
import ipaddress
import hmac
import logging
import functools
from datetime import datetime, timedelta
from typing import Optional, Any, Callable, List
from collections import defaultdict
from threading import Lock

from flask import request, jsonify

logger = logging.getLogger(__name__)

# Import config for API key validation
try:
    from .config import get_config
    CONFIG_AVAILABLE = True
except ImportError:
    CONFIG_AVAILABLE = False


# =============================================================================
# Configurable Rate Limits (from SuperAdmin settings)
# =============================================================================

def get_rate_limit_api() -> tuple[int, int]:
    """Get rate limit for general API endpoints (requests per minute)."""
    if CONFIG_AVAILABLE:
        config = get_config()
        return (config.api.rate_limit_api, 60)
    return (100, 60)


def get_rate_limit_scan() -> tuple[int, int]:
    """Get rate limit for scan operations (requests per minute)."""
    if CONFIG_AVAILABLE:
        config = get_config()
        return (config.api.rate_limit_scan, 60)
    return (20, 60)


def get_rate_limit_cve_sync() -> tuple[int, int]:
    """Get rate limit for CVE sync operations (requests per minute)."""
    if CONFIG_AVAILABLE:
        config = get_config()
        return (config.api.rate_limit_cve_sync, 60)
    return (10, 60)


def get_rate_limit_dashboard() -> tuple[int, int]:
    """Get rate limit for dashboard endpoints (requests per minute)."""
    if CONFIG_AVAILABLE:
        config = get_config()
        return (config.api.rate_limit_dashboard, 60)
    return (60, 60)


# =============================================================================
# Input Validation Constants
# =============================================================================

# Maximum limits to prevent DoS
MAX_PAGE_SIZE = 100
MAX_SEARCH_LENGTH = 255
MAX_HOSTNAME_LENGTH = 253
MAX_CVE_ID_LENGTH = 20
MAX_TAGS_COUNT = 20
MAX_TARGETS_COUNT = 1000
MAX_REQUEST_SIZE = 10 * 1024 * 1024  # 10MB

# Allowed patterns
CVE_ID_PATTERN = re.compile(r'^CVE-\d{4}-\d{4,}$', re.IGNORECASE)
HOSTNAME_PATTERN = re.compile(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$')
IP_PATTERN = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
CIDR_PATTERN = re.compile(r'^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$')

# SQL LIKE special characters that need escaping
SQL_LIKE_ESCAPE_CHARS = {'%': r'\%', '_': r'\_', '\\': r'\\\\'}


# =============================================================================
# Input Validation Functions
# =============================================================================

def sanitize_string(value: str, max_length: int = 255, allow_html: bool = False) -> str:
    """
    Sanitize string input to prevent injection attacks.

    Args:
        value: Input string to sanitize
        max_length: Maximum allowed length
        allow_html: Whether to allow HTML (default False for XSS prevention)

    Returns:
        Sanitized string
    """
    if not isinstance(value, str):
        return ''

    # Truncate to max length
    value = value[:max_length]

    # Strip leading/trailing whitespace
    value = value.strip()

    # Remove null bytes and control characters (except newlines/tabs)
    value = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)

    # Escape HTML if not allowed
    if not allow_html:
        value = html.escape(value)

    return value


def escape_sql_like(value: str) -> str:
    """
    Escape special characters for SQL LIKE queries.
    Prevents SQL injection through LIKE patterns.

    Args:
        value: Search string to escape

    Returns:
        Escaped string safe for LIKE queries
    """
    if not value:
        return value

    for char, escaped in SQL_LIKE_ESCAPE_CHARS.items():
        value = value.replace(char, escaped)

    return value


def validate_pagination(page: int, per_page: int) -> tuple[int, int]:
    """
    Validate and constrain pagination parameters.

    Args:
        page: Page number
        per_page: Items per page

    Returns:
        Tuple of (validated_page, validated_per_page)
    """
    # Ensure positive integers
    page = max(1, int(page) if isinstance(page, (int, str)) and str(page).isdigit() else 1)
    per_page = max(1, int(per_page) if isinstance(per_page, (int, str)) and str(per_page).isdigit() else 50)

    # Constrain per_page to prevent DoS
    per_page = min(per_page, MAX_PAGE_SIZE)

    return page, per_page


def validate_cve_id(cve_id: str) -> Optional[str]:
    """
    Validate CVE ID format.

    Args:
        cve_id: CVE identifier to validate

    Returns:
        Normalized CVE ID or None if invalid
    """
    if not cve_id or not isinstance(cve_id, str):
        return None

    cve_id = cve_id.strip().upper()

    if len(cve_id) > MAX_CVE_ID_LENGTH:
        return None

    if not CVE_ID_PATTERN.match(cve_id):
        return None

    return cve_id


def validate_hostname(hostname: str) -> Optional[str]:
    """
    Validate hostname format.

    Args:
        hostname: Hostname to validate

    Returns:
        Validated hostname or None if invalid
    """
    if not hostname or not isinstance(hostname, str):
        return None

    hostname = hostname.strip().lower()

    if len(hostname) > MAX_HOSTNAME_LENGTH:
        return None

    if not HOSTNAME_PATTERN.match(hostname):
        return None

    return hostname


def validate_ip_or_cidr(target: str) -> Optional[str]:
    """
    Validate IP address or CIDR notation.

    Args:
        target: IP or CIDR to validate

    Returns:
        Validated target or None if invalid
    """
    if not target or not isinstance(target, str):
        return None

    target = target.strip()

    if IP_PATTERN.match(target):
        # Validate IP octets
        octets = target.split('.')
        if all(0 <= int(o) <= 255 for o in octets):
            return target

    if CIDR_PATTERN.match(target):
        ip, prefix = target.rsplit('/', 1)
        octets = ip.split('.')
        if all(0 <= int(o) <= 255 for o in octets) and 0 <= int(prefix) <= 32:
            return target

    # Allow hostnames too
    if HOSTNAME_PATTERN.match(target) and len(target) <= MAX_HOSTNAME_LENGTH:
        return target

    return None


def validate_targets(targets: list) -> list[str]:
    """
    Validate list of scan targets.

    Args:
        targets: List of IP/CIDR/hostname targets

    Returns:
        List of validated targets
    """
    if not isinstance(targets, list):
        return []

    validated = []
    for target in targets[:MAX_TARGETS_COUNT]:
        valid = validate_ip_or_cidr(str(target))
        if valid:
            validated.append(valid)

    return validated


# =============================================================================
# API Key Authentication
# =============================================================================

def _is_truthy_env(var_name: str) -> bool:
    """Return True when an environment variable is set to a truthy value."""
    value = os.getenv(var_name, '').strip().lower()
    return value in {'1', 'true', 'yes', 'on'}


def _get_trusted_proxies() -> List[str]:
    """Get list of trusted proxy subnets/IPs from environment."""
    # SECURITY: Only trust X-Forwarded-For from explicitly configured proxies
    proxies = os.getenv('TRUSTED_PROXY_SUBNETS', '').strip()
    if not proxies or proxies.lower() == 'none':
        return []
    return [s.strip() for s in proxies.split(',') if s.strip() and s.strip().lower() != 'none']


def _is_from_trusted_proxy(remote_ip: str) -> bool:
    """Check if request is from a trusted proxy (for X-Forwarded-For trust)."""
    if not remote_ip:
        return False
    try:
        client = ipaddress.ip_address(remote_ip)
        # Always trust loopback (same-machine proxy)
        if client.is_loopback:
            return True
        for subnet_str in _get_trusted_proxies():
            try:
                subnet = ipaddress.ip_network(subnet_str, strict=False)
                if client in subnet:
                    return True
            except ValueError:
                continue
    except ValueError:
        pass
    return False


def get_client_ip_secure() -> str:
    """
    Securely get client IP address.

    SECURITY: Only trusts X-Forwarded-For/X-Real-IP headers when:
    1. Request comes from a trusted proxy (loopback or configured subnet)
    2. TRUSTED_PROXY_SUBNETS environment variable is set

    This prevents attackers from spoofing their IP via headers.
    """
    direct_ip = request.remote_addr or ''

    # Only trust forwarded headers if request is from a trusted proxy
    if not _is_from_trusted_proxy(direct_ip):
        return direct_ip

    # Trust X-Forwarded-For from trusted proxy
    forwarded_for = request.environ.get('HTTP_X_FORWARDED_FOR')
    if forwarded_for:
        # Take first IP in chain (original client)
        return forwarded_for.split(',')[0].strip()

    # Fallback to X-Real-IP
    real_ip = request.environ.get('HTTP_X_REAL_IP')
    if real_ip:
        return real_ip.strip()

    return direct_ip


def _is_loopback_addr(remote_ip: str) -> bool:
    """Return True when a remote address is loopback/localhost."""
    if not remote_ip:
        return False
    if remote_ip == 'localhost':
        return True
    try:
        return ipaddress.ip_address(remote_ip).is_loopback
    except ValueError:
        return False


def _is_private_addr(remote_ip: str) -> bool:
    """Return True when a remote address is private RFC1918/ULA space."""
    if not remote_ip:
        return False
    try:
        return ipaddress.ip_address(remote_ip).is_private
    except ValueError:
        return False


# =============================================================================
# SSRF Protection
# =============================================================================

# Cloud metadata and internal service IP ranges that should be blocked
# to prevent Server-Side Request Forgery (SSRF) attacks
SSRF_BLOCKED_RANGES = [
    # Cloud metadata services
    ipaddress.ip_network('169.254.169.254/32'),  # AWS/GCP/Azure metadata
    ipaddress.ip_network('100.100.100.200/32'),  # Alibaba Cloud metadata
    ipaddress.ip_network('fd00:ec2::254/128'),   # AWS IPv6 metadata

    # Link-local (can access metadata via gateway)
    ipaddress.ip_network('169.254.0.0/16'),      # IPv4 link-local
    ipaddress.ip_network('fe80::/10'),           # IPv6 link-local

    # Loopback (access to local services)
    ipaddress.ip_network('127.0.0.0/8'),         # IPv4 loopback
    ipaddress.ip_network('::1/128'),             # IPv6 loopback
]

# Private ranges - blocked by default, can be allowed via config
SSRF_PRIVATE_RANGES = [
    ipaddress.ip_network('10.0.0.0/8'),          # Class A private
    ipaddress.ip_network('172.16.0.0/12'),       # Class B private
    ipaddress.ip_network('192.168.0.0/16'),      # Class C private
    ipaddress.ip_network('fc00::/7'),            # IPv6 unique local
]


def is_ssrf_safe_ip(ip_str: str, allow_private: bool = False) -> tuple[bool, str]:
    """
    Check if an IP address is safe for SSRF-sensitive operations.

    Args:
        ip_str: IP address string to check
        allow_private: Whether to allow private RFC1918 addresses (default False)

    Returns:
        Tuple of (is_safe, reason) - is_safe=True means OK to connect
    """
    if not ip_str:
        return False, "Empty IP address"

    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False, f"Invalid IP address: {ip_str}"

    # Check against blocked ranges (always blocked)
    for blocked in SSRF_BLOCKED_RANGES:
        if ip in blocked:
            return False, f"IP {ip_str} is in blocked range {blocked} (cloud metadata/loopback)"

    # Check against private ranges (blocked unless explicitly allowed)
    if not allow_private:
        for private in SSRF_PRIVATE_RANGES:
            if ip in private:
                return False, f"IP {ip_str} is in private range {private}; set allow_private=True to allow internal scans"

    return True, "OK"


def validate_scan_target_ssrf(target: str, allow_private: bool = None) -> tuple[bool, str, str]:
    """
    Validate a scan target for SSRF safety, resolving hostnames if needed.

    Args:
        target: IP address or hostname to validate
        allow_private: Whether to allow private addresses. If None, reads from
                      ASSET_DISCOVERY_ALLOW_PRIVATE_SCAN_TARGETS env var.

    Returns:
        Tuple of (is_safe, resolved_ip, reason)
    """
    import socket

    if allow_private is None:
        allow_private = _is_truthy_env('ASSET_DISCOVERY_ALLOW_PRIVATE_SCAN_TARGETS')

    if not target:
        return False, '', "Empty target"

    target = target.strip()

    # Check if it's already an IP address
    resolved_ip = target
    try:
        ipaddress.ip_address(target)
        # It's an IP, validate directly
        is_safe, reason = is_ssrf_safe_ip(target, allow_private)
        return is_safe, target, reason
    except ValueError:
        # It's a hostname, need to resolve
        pass

    # DNS resolution for hostnames
    try:
        resolved_ip = socket.gethostbyname(target)
    except socket.gaierror as e:
        return False, '', f"DNS resolution failed for {target}: {e}"

    # Validate the resolved IP
    is_safe, reason = is_ssrf_safe_ip(resolved_ip, allow_private)
    if not is_safe:
        return False, resolved_ip, f"Hostname {target} resolves to blocked IP: {reason}"

    return True, resolved_ip, "OK"


def _is_internal_service_request() -> bool:
    """
    Check if request is from a trusted internal service using the shared token.
    Used for web<->asset-discovery secure communication.
    """
    token = request.headers.get('X-Internal-Service-Token')
    if not token:
        return False

    # Check environment variable first (faster)
    env_token = os.getenv('INTERNAL_SERVICE_TOKEN')
    if env_token and hmac.compare_digest(token, env_token):
        return True

    # Check config
    if CONFIG_AVAILABLE:
        try:
            config = get_config()
            if config.api.internal_service_token:
                return hmac.compare_digest(token, config.api.internal_service_token)
        except Exception as config_error:  # noqa: BLE001 - fail closed for service-token trust checks
            logger.debug("Could not evaluate internal service token from config: %s", config_error)

    return False


def _is_rate_limit_bypass_ip(remote_ip: str) -> bool:
    """
    Check if IP should bypass rate limiting.

    SECURE BY DEFAULT: Only loopback bypasses unless explicitly configured.

    To enable subnet bypass (Docker/Kubernetes), explicitly set:
    RATE_LIMIT_BYPASS_SUBNETS=172.18.0.0/16,10.42.0.0/16

    For inter-service communication, use INTERNAL_SERVICE_TOKEN instead.
    """
    if not remote_ip:
        return False

    try:
        ip = ipaddress.ip_address(remote_ip)
    except ValueError:
        return False

    # Always bypass for loopback (localhost) - safe in all environments
    if ip.is_loopback:
        return True

    # ONLY bypass for explicitly configured subnets - no defaults
    # This ensures Corporate LAN deployments are secure by default
    if CONFIG_AVAILABLE:
        try:
            config = get_config()
            if config.api.rate_limit_bypass_subnets:
                for subnet_str in config.api.rate_limit_bypass_subnets:
                    # Skip empty strings and "none" marker
                    if not subnet_str or subnet_str.strip().lower() == 'none':
                        continue
                    try:
                        subnet = ipaddress.ip_network(subnet_str.strip(), strict=False)
                        if ip in subnet:
                            logger.debug(f"Rate limit bypass: {remote_ip} in configured subnet {subnet_str}")
                            return True
                    except ValueError:
                        continue
        except Exception as bypass_config_error:  # noqa: BLE001 - fail secure and continue without bypass
            logger.debug("Could not evaluate rate-limit bypass config: %s", bypass_config_error)

    # Check environment variable directly (for override without config reload)
    env_subnets = os.getenv('RATE_LIMIT_BYPASS_SUBNETS', '').strip()
    if env_subnets and env_subnets.lower() != 'none':
        for subnet_str in env_subnets.split(','):
            if not subnet_str.strip():
                continue
            try:
                subnet = ipaddress.ip_network(subnet_str.strip(), strict=False)
                if ip in subnet:
                    logger.debug(f"Rate limit bypass: {remote_ip} in env subnet {subnet_str}")
                    return True
            except ValueError:
                continue

    # No bypass - all private IPs are rate limited unless explicitly configured
    return False


def require_api_key(f: Callable) -> Callable:
    """
    Decorator to require valid API key for endpoint access.

     API key validation hierarchy:
     1. Loopback requests (no key required)
     2. Optional private-network bypass
         (ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY=true)
    2. Main Tool Keystore (primary) - validates via main tool's encrypted keystore
    3. Local Environment (fallback) - uses ASSET_DISCOVERY_API_KEY
    4. Local Config (legacy) - uses configured allowed_api_keys

    This allows Asset Discovery to inherit the main tool's centralized key
    management while still working standalone if main tool is unavailable.
    """
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        remote_ip = request.remote_addr or ''

        # Priority 1: Internal service token (web<->asset-discovery trust)
        if _is_internal_service_request():
            logger.debug("Request authenticated via internal service token")
            return f(*args, **kwargs)

        if _is_loopback_addr(remote_ip):
            logger.debug("Allowing loopback request from %s without API key", remote_ip)
            return f(*args, **kwargs)

        allow_internal_no_key = _is_truthy_env('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY')
        if allow_internal_no_key and _is_private_addr(remote_ip):
            logger.warning(
                "Allowing private-network request without API key from %s via "
                "ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY",
                remote_ip,
            )
            return f(*args, **kwargs)

        # Check if API key is required by config (early check)
        if CONFIG_AVAILABLE:
            try:
                config = get_config()
                if not config.api.require_api_key:
                    logger.debug("API key not required (REQUIRE_API_KEY=false)")
                    return f(*args, **kwargs)
            except Exception as e:
                logger.debug(f"Config check error: {e}")

        # Get API key from header
        api_key = request.headers.get('X-API-Key')

        if not api_key:
            logger.warning(f"API key missing from {request.remote_addr} for {request.path}")
            return jsonify({
                'error': 'API key required',
                'message': 'Please provide X-API-Key header'
            }), 401

        # Method 1: Validate via main tool's keystore (primary)
        try:
            from .keystore_client import validate_api_key_via_keystore

            if validate_api_key_via_keystore(api_key):
                # Key validated successfully via main tool
                return f(*args, **kwargs)

        except ImportError:
            logger.debug("Keystore client not available, using fallback validation")
        except Exception as e:
            logger.debug(f"Keystore validation error (using fallback): {e}")

        # Method 2: Fallback to local environment variable
        env_key = os.getenv('ASSET_DISCOVERY_API_KEY')
        if env_key and hmac.compare_digest(api_key, env_key):
            logger.debug("API key validated via environment variable")
            return f(*args, **kwargs)

        # Method 3: Fallback to local config (legacy)
        if CONFIG_AVAILABLE:
            try:
                config = get_config()
                if not config.api.require_api_key:
                    # API key not required by config
                    return f(*args, **kwargs)

                allowed_keys = config.api.allowed_api_keys
                if allowed_keys:
                    for allowed_key in allowed_keys:
                        if isinstance(allowed_key, str) and hmac.compare_digest(api_key, allowed_key):
                            logger.debug("API key validated via local config")
                            return f(*args, **kwargs)
            except Exception as e:
                logger.debug(f"Config validation error: {e}")

        # All validation methods failed
        logger.warning(f"Invalid API key attempt from {request.remote_addr} for {request.path}")
        return jsonify({'error': 'Invalid API key'}), 403

        # API key valid - proceed with request
        return f(*args, **kwargs)

    return decorated_function


# =============================================================================
# Rate Limiting
# =============================================================================

class RateLimiter:
    """
    Thread-safe in-memory rate limiter.
    For production, use Redis-based rate limiting.
    """

    def __init__(self):
        self._requests = defaultdict(list)
        self._lock = Lock()

    def is_allowed(self, key: str, max_requests: int = 100, window_seconds: int = 60) -> bool:
        """
        Check if request is allowed under rate limit.

        Args:
            key: Unique identifier (e.g., IP address)
            max_requests: Maximum requests per window
            window_seconds: Time window in seconds

        Returns:
            True if allowed, False if rate limited
        """
        now = datetime.utcnow()
        window_start = now - timedelta(seconds=window_seconds)

        with self._lock:
            # Clean old entries
            self._requests[key] = [
                ts for ts in self._requests[key]
                if ts > window_start
            ]

            # Check limit
            if len(self._requests[key]) >= max_requests:
                return False

            # Record request
            self._requests[key].append(now)
            return True

    def get_remaining(self, key: str, max_requests: int = 100, window_seconds: int = 60) -> int:
        """Get remaining requests in window."""
        now = datetime.utcnow()
        window_start = now - timedelta(seconds=window_seconds)

        with self._lock:
            recent = [ts for ts in self._requests[key] if ts > window_start]
            return max(0, max_requests - len(recent))


# Global rate limiter instance
_rate_limiter = RateLimiter()


def _build_rate_limit_key(client_ip: str) -> str:
    """Build a deterministic rate-limit bucket key scoped to endpoint + client IP."""
    endpoint = (request.endpoint or request.path or '').strip().lower()
    if endpoint:
        return f"{client_ip}:{endpoint}"
    return client_ip


def rate_limit(max_requests: int = 100, window_seconds: int = 60):
    """
    Decorator for rate limiting endpoints.

    Args:
        max_requests: Maximum requests per window
        window_seconds: Time window in seconds

    Rate limiting is bypassed for:
    - Internal service token requests (trusted web<->asset-discovery communication)
    - Requests from Docker/internal network subnets
    - Loopback requests
    """
    def decorator(f: Callable) -> Callable:
        @functools.wraps(f)
        def wrapped(*args, **kwargs):
            # SECURE: Use validated client IP function
            client_ip = get_client_ip_secure()

            # Bypass rate limiting for internal service requests
            if _is_internal_service_request():
                logger.debug("Rate limit bypassed for internal service request")
                return f(*args, **kwargs)

            # Bypass rate limiting for internal Docker/network IPs
            if _is_rate_limit_bypass_ip(client_ip):
                logger.debug(f"Rate limit bypassed for internal IP {client_ip}")
                return f(*args, **kwargs)

            rate_key = _build_rate_limit_key(client_ip)

            if not _rate_limiter.is_allowed(rate_key, max_requests, window_seconds):
                logger.warning(f"Rate limit exceeded for {client_ip} on {request.path}")
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'retry_after': window_seconds
                }), 429

            return f(*args, **kwargs)
        return wrapped
    return decorator


# =============================================================================
# Secure Error Handling
# =============================================================================

def safe_error_response(error: Exception, status_code: int = 500) -> tuple:
    """
    Create a safe error response without leaking internal details.

    Args:
        error: The exception that occurred
        status_code: HTTP status code

    Returns:
        Tuple of (response, status_code)
    """
    # Log full error internally
    logger.exception(f"Error processing request: {error}")

    # Return safe error message
    error_messages = {
        400: 'Invalid request',
        401: 'Authentication required',
        403: 'Access denied',
        404: 'Resource not found',
        409: 'Conflict',
        422: 'Unprocessable entity',
        429: 'Too many requests',
        500: 'Internal server error'
    }

    message = error_messages.get(status_code, 'An error occurred')

    return jsonify({
        'error': message,
        'status': status_code
    }), status_code


# =============================================================================
# Security Headers
# =============================================================================

def add_security_headers(response):
    """
    Add security headers to response.
    Should be registered as after_request handler.
    """
    # Allow embedding from main audit toolkit (different port)
    # Get allowed parent origins from environment or use defaults
    audit_toolkit_url = os.environ.get('AUDIT_TOOLKIT_URL', 'http://localhost:5000')

    # Don't set X-Frame-Options - we use frame-ancestors in CSP instead
    # This allows embedding from the audit toolkit on a different port
    # response.headers['X-Frame-Options'] = 'SAMEORIGIN'  # Removed - conflicts with frame-ancestors

    # Prevent MIME sniffing
    response.headers['X-Content-Type-Options'] = 'nosniff'

    # XSS protection (legacy browsers)
    response.headers['X-XSS-Protection'] = '1; mode=block'

    # Content Security Policy - allow inline styles/scripts for dashboard
    # frame-ancestors allows embedding from main audit toolkit
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        f"frame-ancestors 'self' {audit_toolkit_url}"
    )

    # Referrer policy
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'

    # Remove server header
    response.headers.pop('Server', None)

    return response


# =============================================================================
# Request Validation
# =============================================================================

def validate_json_request() -> Optional[tuple]:
    """
    Validate JSON request body.

    Returns:
        Error response tuple if invalid, None if valid
    """
    if not request.is_json:
        return jsonify({'error': 'Content-Type must be application/json'}), 400

    if request.content_length and request.content_length > MAX_REQUEST_SIZE:
        return jsonify({'error': 'Request body too large'}), 413

    return None


def get_safe_search_param(param_name: str = 'search') -> str:
    """
    Get and sanitize a search parameter.

    Args:
        param_name: Name of the query parameter

    Returns:
        Sanitized and escaped search string
    """
    search = request.args.get(param_name, '')
    if not search:
        return ''

    # Sanitize
    search = sanitize_string(search, max_length=MAX_SEARCH_LENGTH)

    # Escape for SQL LIKE
    search = escape_sql_like(search)

    return search


# =============================================================================
# Audit Logging
# =============================================================================

def audit_log(action: str, resource_type: str, resource_id: Any = None,
              details: dict = None, status: str = 'success'):
    """
    Log security-relevant actions for audit trail.

    Args:
        action: Action performed (create, read, update, delete, etc.)
        resource_type: Type of resource (asset, scan, cve, etc.)
        resource_id: ID of the resource
        details: Additional details
        status: success or failure
    """
    client_ip = request.environ.get('HTTP_X_FORWARDED_FOR',
                request.environ.get('HTTP_X_REAL_IP',
                request.remote_addr))

    log_entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'action': action,
        'resource_type': resource_type,
        'resource_id': resource_id,
        'client_ip': client_ip,
        'user_agent': request.headers.get('User-Agent', '')[:200],
        'status': status
    }

    if details:
        log_entry['details'] = details

    # Use structured logging
    logger.info(f"AUDIT: {log_entry}")
