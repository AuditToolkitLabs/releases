from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Iterable, Optional

from ..models.asset import Asset, AssetNetworkInterface, AssetStorage
from ..models.patch import PendingUpdate
from ..models.software import AssetService, InstalledSoftware, WindowsUpdate
from .update_payload_schema import normalize_update_payload


def _parse_datetime(value: Any) -> Optional[datetime]:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00')).replace(tzinfo=None)
        except ValueError:
            return None
    return None


def _iterable(value: Any) -> Iterable:
    if isinstance(value, list):
        return value
    return []


def _clean_text(value: Any) -> Optional[str]:
    if not isinstance(value, str):
        return None

    cleaned = value.strip()
    if not cleaned:
        return None

    if cleaned.lower() in {'unknown', 'n/a', 'na', 'none', 'null', '-'}:
        return None

    return cleaned


def _resolve_text(incoming: Any, existing: Any, default: Optional[str] = None) -> Optional[str]:
    incoming_clean = _clean_text(incoming)
    if incoming_clean is not None:
        return incoming_clean

    existing_clean = _clean_text(existing)
    if existing_clean is not None:
        return existing_clean

    return default


def _resolve_int(incoming: Any, existing: Any, default: Optional[int] = None) -> Optional[int]:
    try:
        if incoming not in (None, ''):
            return int(float(incoming))
    except (TypeError, ValueError):
        pass

    if existing is not None:
        try:
            return int(existing)
        except (TypeError, ValueError):
            pass

    return default


def _resolve_float(incoming: Any, existing: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if incoming not in (None, ''):
            return float(incoming)
    except (TypeError, ValueError):
        pass

    if existing is not None:
        try:
            return float(existing)
        except (TypeError, ValueError):
            pass

    return default


def _is_credentialed_discovery(payload: Dict[str, Any]) -> bool:
    method = (
        payload.get('connection_method')
        or payload.get('discovery_method')
        or payload.get('method')
    )
    if not isinstance(method, str):
        return False

    normalized = method.strip().lower()
    return normalized in {'ssh', 'winrm', 'managed', 'agent'}


def _to_system_data(payload: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(payload.get('data'), dict) and isinstance(payload['data'].get('system'), dict):
        return payload['data']['system']

    if isinstance(payload.get('system'), dict):
        return payload['system']

    os_version = payload.get('os_version')
    return {
        'hostname': payload.get('hostname'),
        'fqdn': payload.get('fqdn'),
        'domain': payload.get('domain'),
        'os_name': os_version,
        'os_version': os_version,
        'os_build': payload.get('os_build'),
        'kernel_version': payload.get('kernel_version'),
        'architecture': payload.get('architecture') or payload.get('os_architecture'),
        'manufacturer': payload.get('manufacturer'),
        'model': payload.get('model'),
        'serial_number': payload.get('serial_number'),
        'product_id': payload.get('product_id'),
        'asset_tag': payload.get('asset_tag'),
        'product_uuid': payload.get('product_uuid'),
        'cpu_name': payload.get('cpu_name') or payload.get('cpu_model'),
        'cpu_model': payload.get('cpu_model') or payload.get('cpu_name'),
        'cpu_cores': payload.get('cpu_cores'),
        'cpu_logical_processors': payload.get('cpu_logical_processors') or payload.get('cpu_threads'),
        'total_memory_gb': payload.get('total_memory_gb'),
        'is_virtual': payload.get('is_virtual'),
        'hypervisor': payload.get('hypervisor'),
        'last_boot': payload.get('last_boot'),
    }


def upsert_asset_from_discovery(
    session,
    payload: Dict[str, Any],
    *,
    fallback_ip: Optional[str] = None,
    existing_asset: Optional[Asset] = None,
) -> Asset:
    hostname = (
        _clean_text(payload.get('hostname'))
        or _clean_text(payload.get('fqdn'))
        or fallback_ip
        or 'unknown'
    )

    asset = existing_asset
    if not asset and fallback_ip:
        asset = session.query(Asset).filter(Asset.primary_ip == fallback_ip).first()
    if not asset:
        asset = session.query(Asset).filter(Asset.hostname == hostname).first()

    if asset:
        asset.last_seen = datetime.utcnow()
    else:
        asset = Asset(
            hostname=hostname,
            first_seen=datetime.utcnow(),
            last_seen=datetime.utcnow(),
        )
        session.add(asset)

    system_data = _to_system_data(payload)
    data_section = payload.get('data', {}) if isinstance(payload.get('data'), dict) else {}
    preserve_existing_inventory = bool(payload.get('_preserve_existing_inventory', False))
    credentialed_discovery = _is_credentialed_discovery(payload)

    default_text = 'Unknown' if credentialed_discovery else None
    default_numeric = 0 if credentialed_discovery else None

    fqdn_value = _clean_text(system_data.get('fqdn')) or _clean_text(payload.get('fqdn'))
    domain_value = _clean_text(system_data.get('domain')) or _clean_text(payload.get('domain'))

    if not domain_value and fqdn_value and '.' in fqdn_value:
        domain_value = fqdn_value.split('.', 1)[1]

    if not fqdn_value and isinstance(hostname, str) and '.' in hostname:
        fqdn_value = hostname
        if not domain_value:
            domain_value = hostname.split('.', 1)[1]

    if not fqdn_value and domain_value and hostname not in {'unknown', fallback_ip}:
        fqdn_value = f"{hostname}.{domain_value}"

    os_type = _clean_text(payload.get('os_type'))
    os_name = _clean_text(system_data.get('os_name'))
    os_version = _clean_text(system_data.get('os_version')) or _clean_text(payload.get('os_version'))

    if not os_type and os_name:
        os_name_lower = os_name.lower()
        if 'windows' in os_name_lower:
            os_type = 'windows'
        elif any(marker in os_name_lower for marker in ('linux', 'ubuntu', 'debian', 'centos', 'rhel', 'fedora', 'alpine', 'suse')):
            os_type = 'linux'

    if not os_name and os_version:
        os_name = os_version

    if not os_name and os_type == 'windows':
        os_name = 'Windows'
    elif not os_name and os_type == 'linux':
        os_name = 'Linux'

    asset.hostname = hostname
    asset.fqdn = _resolve_text(fqdn_value, asset.fqdn, default_text)
    asset.domain = _resolve_text(domain_value, asset.domain, default_text)
    asset.os_type = os_type or _clean_text(asset.os_type) or 'unknown'
    asset.os_name = os_name or _clean_text(asset.os_name) or 'Unknown'
    asset.os_version = os_version or _clean_text(asset.os_version) or default_text or asset.os_version
    asset.os_build = _resolve_text(system_data.get('os_build') or payload.get('os_build'), asset.os_build, default_text)
    asset.kernel_version = _resolve_text(system_data.get('kernel_version'), asset.kernel_version, default_text)
    asset.architecture = _resolve_text(
        system_data.get('architecture') or system_data.get('os_architecture'),
        asset.architecture,
        default_text,
    )
    asset.manufacturer = _resolve_text(system_data.get('manufacturer'), asset.manufacturer, default_text)
    asset.model = _resolve_text(system_data.get('model'), asset.model, default_text)
    asset.serial_number = _resolve_text(system_data.get('serial_number'), asset.serial_number, default_text)
    asset.cpu_model = _resolve_text(system_data.get('cpu_name') or system_data.get('cpu_model'), asset.cpu_model, default_text)
    asset.cpu_cores = _resolve_int(system_data.get('cpu_cores'), asset.cpu_cores, default_numeric)
    cpu_threads_source = (
        system_data.get('cpu_logical_processors')
        or system_data.get('cpu_threads')
        or system_data.get('cpu_cores')
    )
    asset.cpu_threads = _resolve_int(
        cpu_threads_source,
        asset.cpu_threads,
        default_numeric,
    )
    asset.total_memory_gb = _resolve_float(system_data.get('total_memory_gb'), asset.total_memory_gb, default_numeric)
    if system_data.get('is_virtual') is not None:
        asset.is_virtual = bool(system_data.get('is_virtual'))
    asset.hypervisor = _resolve_text(system_data.get('hypervisor'), asset.hypervisor, 'none' if credentialed_discovery else None)
    asset.last_boot_time = _parse_datetime(system_data.get('last_boot')) or asset.last_boot_time
    asset.status = 'active'
    if fallback_ip and not asset.primary_ip:
        asset.primary_ip = fallback_ip

    session.flush()

    network_interfaces = data_section.get('network_interfaces')
    if network_interfaces is None and payload.get('ip_address'):
        network_interfaces = [
            {
                'name': 'primary',
                'ip_address': payload.get('ip_address'),
            }
        ]

    if isinstance(network_interfaces, list):
        session.query(AssetNetworkInterface).filter(AssetNetworkInterface.asset_id == asset.id).delete()
        for index, iface in enumerate(network_interfaces):
            ip_address = iface.get('ip_address')
            ni = AssetNetworkInterface(
                asset_id=asset.id,
                interface_name=iface.get('name') or iface.get('interface_name'),
                mac_address=iface.get('mac_address'),
                ip_address=ip_address,
                subnet_mask=str(iface.get('subnet_mask', '')) if iface.get('subnet_mask') is not None else None,
                gateway=iface.get('gateway'),
                dns_servers=iface.get('dns_servers') if isinstance(iface.get('dns_servers'), list) else [],
                speed_mbps=int(iface.get('link_speed_mbps')) if str(iface.get('link_speed_mbps', '')).isdigit() else None,
                status=iface.get('status') or 'up',
                is_primary=bool(iface.get('is_primary', index == 0)),
            )
            session.add(ni)
            if ip_address and (ni.is_primary or not asset.primary_ip):
                asset.primary_ip = ip_address
                if iface.get('mac_address'):
                    asset.mac_address = iface.get('mac_address')

    storage_items = data_section.get('storage')
    if isinstance(storage_items, list):
        session.query(AssetStorage).filter(AssetStorage.asset_id == asset.id).delete()
        for item in storage_items:
            storage = AssetStorage(
                asset_id=asset.id,
                drive_letter=item.get('drive_letter'),
                mount_point=item.get('mount_point') or item.get('drive_letter'),
                filesystem_type=item.get('file_system') or item.get('filesystem_type'),
                total_size_gb=item.get('total_size_gb'),
                free_space_gb=item.get('free_space_gb'),
                used_percent=item.get('used_percent'),
                is_system_drive=bool(item.get('is_system_drive', False)),
            )
            session.add(storage)

    software_items = data_section.get('software')
    if software_items is None and isinstance(payload.get('packages'), list):
        software_items = payload.get('packages')
    if isinstance(software_items, list) and (software_items or not preserve_existing_inventory):
        session.query(InstalledSoftware).filter(InstalledSoftware.asset_id == asset.id).delete()
        for sw in software_items:
            software = InstalledSoftware(
                asset_id=asset.id,
                name=sw.get('name') or 'unknown',
                version=sw.get('version'),
                version_raw=sw.get('version_raw') or sw.get('version'),
                publisher=sw.get('publisher'),
                install_date=_parse_datetime(sw.get('install_date')).date() if _parse_datetime(sw.get('install_date')) else None,
                install_location=sw.get('install_location'),
                architecture=sw.get('architecture'),
                package_type=sw.get('package_type'),
                cpe_uri=sw.get('cpe_uri'),
            )
            session.add(software)

    services_items = data_section.get('services')
    if services_items is None and isinstance(payload.get('services'), list):
        services_items = payload.get('services')
    if isinstance(services_items, list) and (services_items or not preserve_existing_inventory):
        session.query(AssetService).filter(AssetService.asset_id == asset.id).delete()
        for svc in services_items:
            service = AssetService(
                asset_id=asset.id,
                service_name=svc.get('service_name') or svc.get('name'),
                display_name=svc.get('display_name'),
                status=svc.get('status'),
                start_type=svc.get('start_type'),
                account=svc.get('account'),
                binary_path=svc.get('path') or svc.get('binary_path'),
                description=svc.get('description'),
            )
            session.add(service)

    pending_updates_items = data_section.get('pending_updates')
    if pending_updates_items is None and isinstance(payload.get('pending_updates'), list):
        pending_updates_items = payload.get('pending_updates')
    if pending_updates_items is None and isinstance(payload.get('updates_available'), list):
        pending_updates_items = payload.get('updates_available')

    normalized_updates_count, normalized_pending_updates = normalize_update_payload(
        payload.get('updates_available'),
        pending_updates_items,
    )

    pending_updates_items = normalized_pending_updates
    if isinstance(pending_updates_items, list) and (pending_updates_items or not preserve_existing_inventory):
        session.query(PendingUpdate).filter(PendingUpdate.asset_id == asset.id).delete()
        for item in pending_updates_items:
            update = PendingUpdate(
                asset_id=asset.id,
                package_name=item.get('name') or item.get('package_name') or item.get('title'),
                current_version=item.get('current_version'),
                available_version=item.get('new_version') or item.get('available_version'),
                update_type=item.get('type') or item.get('update_type'),
                severity=item.get('severity'),
                kb_number=(item.get('kb_article_ids') or [None])[0] if isinstance(item.get('kb_article_ids'), list) else item.get('kb_number'),
                requires_reboot=bool(item.get('requires_reboot', False)),
                cves_fixed=item.get('cves_fixed') if isinstance(item.get('cves_fixed'), list) else [],
            )
            session.add(update)

    windows_updates = data_section.get('windows_updates')
    if isinstance(windows_updates, list) and (windows_updates or not preserve_existing_inventory):
        session.query(WindowsUpdate).filter(WindowsUpdate.asset_id == asset.id).delete()
        for item in windows_updates:
            installed_on_dt = _parse_datetime(item.get('installed_on'))
            entry = WindowsUpdate(
                asset_id=asset.id,
                kb_number=item.get('hotfix_id') or item.get('kb_number'),
                description=item.get('description'),
                installed_on=installed_on_dt.date() if installed_on_dt else None,
                installed_by=item.get('installed_by'),
                update_type=item.get('update_type') or item.get('type'),
            )
            session.add(entry)

    custom_attributes = dict(asset.custom_attributes or {})
    custom_attributes['last_scan_data'] = payload

    cmdb_hardware = {
        'product_id': _clean_text(system_data.get('product_id')),
        'asset_tag': _clean_text(system_data.get('asset_tag')),
        'product_uuid': _clean_text(system_data.get('product_uuid')),
    }
    existing_cmdb_hardware = custom_attributes.get('cmdb_hardware', {}) if isinstance(custom_attributes.get('cmdb_hardware'), dict) else {}
    merged_cmdb_hardware = {
        'product_id': cmdb_hardware['product_id'] or _clean_text(existing_cmdb_hardware.get('product_id')),
        'asset_tag': cmdb_hardware['asset_tag'] or _clean_text(existing_cmdb_hardware.get('asset_tag')),
        'product_uuid': cmdb_hardware['product_uuid'] or _clean_text(existing_cmdb_hardware.get('product_uuid')),
    }
    custom_attributes['cmdb_hardware'] = merged_cmdb_hardware

    ports_payload = payload.get('ports') if isinstance(payload.get('ports'), list) else data_section.get('ports')
    users_payload = payload.get('users') if isinstance(payload.get('users'), list) else data_section.get('users')
    security_payload = payload.get('security_info') if isinstance(payload.get('security_info'), dict) else data_section.get('security_info')

    if isinstance(ports_payload, list):
        custom_attributes['open_ports'] = ports_payload
    if isinstance(users_payload, list):
        custom_attributes['local_users'] = users_payload
    if isinstance(security_payload, dict):
        custom_attributes['security_info'] = security_payload
    if payload.get('updates_available') is not None:
        custom_attributes['updates_available_count'] = normalized_updates_count
    asset.custom_attributes = custom_attributes

    return asset
