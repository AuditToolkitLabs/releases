"""Posture evaluator service.

Provides a separate, transport-agnostic control evaluation step that runs
after discovery collection and emits normalized findings.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List


def _to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _is_port_exposed(port_entry: Any) -> tuple[bool, int | None, str]:
    if not isinstance(port_entry, dict):
        return False, None, ''

    port = _to_int(port_entry.get('port') or port_entry.get('local_port'), default=-1)
    protocol = str(port_entry.get('protocol') or 'tcp').lower()
    state = str(port_entry.get('state') or '').lower()

    if port <= 0:
        return False, None, protocol

    is_listening = state in {'listen', 'listening', 'open', 'up'} or state == ''
    return is_listening, port, protocol


def _to_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {'1', 'true', 'yes', 'on', 'enabled'}:
            return True
        if lowered in {'0', 'false', 'no', 'off', 'disabled'}:
            return False
    return None


def _normalize_ports(value: Any) -> List[Dict[str, Any]]:
    if not isinstance(value, list):
        return []

    normalized: List[Dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            normalized.append(item)
            continue
        if isinstance(item, (int, float)):
            normalized.append({'port': int(item), 'protocol': 'tcp', 'state': 'open'})
            continue
        if isinstance(item, str):
            stripped = item.strip()
            if stripped.isdigit():
                normalized.append({'port': int(stripped), 'protocol': 'tcp', 'state': 'open'})

    return normalized


def _extract_updates_available(payload: Dict[str, Any]) -> int:
    pending_updates = payload.get('pending_updates')
    updates_available = payload.get('updates_available')

    if isinstance(pending_updates, list):
        return len(pending_updates)
    if isinstance(updates_available, list):
        return len(updates_available)

    for key in ('updates_available', 'update_count', 'updates_available_count', 'pending_updates_count'):
        if key in payload:
            return _to_int(payload.get(key), default=0)

    return 0


def _extract_security_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    security_info = payload.get('security_info') if isinstance(payload.get('security_info'), dict) else {}
    nested_security = security_info.get('security') if isinstance(security_info.get('security'), dict) else {}

    if nested_security:
        return nested_security
    if isinstance(payload.get('security'), dict):
        return payload.get('security', {})
    if isinstance(security_info.get('hardening'), dict):
        return security_info.get('hardening', {})

    return {}


def _normalize_posture_payload(discovery_payload: Dict[str, Any]) -> Dict[str, Any]:
    payload = discovery_payload if isinstance(discovery_payload, dict) else {}

    ports = payload.get('ports')
    if not isinstance(ports, list):
        ports = payload.get('open_ports')
    if not isinstance(ports, list):
        network = payload.get('network') if isinstance(payload.get('network'), dict) else {}
        ports = network.get('ports') if isinstance(network.get('ports'), list) else network.get('open_ports')

    return {
        'updates_available': _extract_updates_available(payload),
        'ports': _normalize_ports(ports),
        'security': _extract_security_payload(payload),
    }


def _append_boolean_control(
    findings: List[Dict[str, Any]],
    *,
    control_id: str,
    title: str,
    value: bool | None,
    success_remediation: str,
    failure_remediation: str,
    framework_refs: List[str],
) -> None:
    if value is None:
        return

    findings.append({
        'control_id': control_id,
        'title': title,
        'status': 'pass' if value else 'warn',
        'severity': 'info' if value else 'medium',
        'framework_refs': framework_refs,
        'evidence': {'value': value},
        'remediation': success_remediation if value else failure_remediation,
    })


def evaluate_asset_posture(
    discovery_payload: Dict[str, Any],
    *,
    target: str,
    method: str,
) -> Dict[str, Any]:
    """Evaluate a single discovered asset and return normalized findings.

    Output contract:
    {
      status: completed|failed,
      summary: {checks_total, pass, warn, fail},
      findings: [
        {control_id, title, status, severity, framework_refs, evidence, remediation}
      ]
    }
    """
    findings: List[Dict[str, Any]] = []
    normalized_payload = _normalize_posture_payload(discovery_payload)

    updates_available = _to_int(normalized_payload.get('updates_available'), default=0)
    if updates_available > 0:
        findings.append({
            'control_id': 'PATCH-001',
            'title': 'Pending security/system updates',
            'status': 'warn',
            'severity': 'medium',
            'framework_refs': ['CIS', 'NVD'],
            'evidence': {
                'updates_available': updates_available,
            },
            'remediation': 'Apply pending updates and rescan to confirm patch posture.',
        })
    else:
        findings.append({
            'control_id': 'PATCH-001',
            'title': 'Pending security/system updates',
            'status': 'pass',
            'severity': 'info',
            'framework_refs': ['CIS'],
            'evidence': {
                'updates_available': updates_available,
            },
            'remediation': 'Continue regular patch cadence.',
        })

    insecure_exposed: List[Dict[str, Any]] = []
    for port_entry in normalized_payload.get('ports', []) if isinstance(normalized_payload.get('ports'), list) else []:
        listening, port, protocol = _is_port_exposed(port_entry)
        if not listening or port is None:
            continue
        if port in {21, 23}:
            insecure_exposed.append({'port': port, 'protocol': protocol})

    if insecure_exposed:
        findings.append({
            'control_id': 'NET-LEGACY-001',
            'title': 'Legacy insecure remote services exposed',
            'status': 'fail',
            'severity': 'high',
            'framework_refs': ['CIS', 'OWASP'],
            'evidence': {
                'exposed_services': insecure_exposed,
            },
            'remediation': 'Disable Telnet/FTP listeners or place behind secure transport controls.',
        })
    else:
        findings.append({
            'control_id': 'NET-LEGACY-001',
            'title': 'Legacy insecure remote services exposed',
            'status': 'pass',
            'severity': 'info',
            'framework_refs': ['CIS'],
            'evidence': {
                'exposed_services': [],
            },
            'remediation': 'No action required.',
        })

    security_payload = normalized_payload.get('security') if isinstance(normalized_payload.get('security'), dict) else {}
    if security_payload:
        firewall_enabled = _to_bool(
            security_payload.get('firewall_enabled')
            if security_payload.get('firewall_enabled') is not None
            else security_payload.get('firewall')
        )
        if firewall_enabled is not None:
            findings.append({
                'control_id': 'FW-001',
                'title': 'Host firewall enabled',
                'status': 'pass' if firewall_enabled else 'warn',
                'severity': 'medium' if not firewall_enabled else 'info',
                'framework_refs': ['CIS'],
                'evidence': {'firewall_enabled': firewall_enabled},
                'remediation': 'Enable host firewall policy for baseline hardening.' if not firewall_enabled else 'No action required.',
            })

        ssh_root_disabled = _to_bool(
            security_payload.get('ssh_root_login_disabled')
            if security_payload.get('ssh_root_login_disabled') is not None
            else security_payload.get('permit_root_login_disabled')
        )
        _append_boolean_control(
            findings,
            control_id='CIS-LNX-SSH-ROOT-001',
            title='SSH root login disabled',
            value=ssh_root_disabled,
            success_remediation='No action required.',
            failure_remediation='Set PermitRootLogin to no in sshd_config and reload sshd.',
            framework_refs=['CIS Linux', 'NIST 800-53'],
        )

        ssh_password_auth_disabled = _to_bool(
            security_payload.get('ssh_password_auth_disabled')
            if security_payload.get('ssh_password_auth_disabled') is not None
            else security_payload.get('password_authentication_disabled')
        )
        _append_boolean_control(
            findings,
            control_id='CIS-LNX-SSH-PASSAUTH-001',
            title='SSH password authentication disabled',
            value=ssh_password_auth_disabled,
            success_remediation='No action required.',
            failure_remediation='Set PasswordAuthentication to no and use key-based authentication.',
            framework_refs=['CIS Linux', 'NIST 800-53'],
        )

        auto_updates_enabled = _to_bool(
            security_payload.get('auto_updates_enabled')
            if security_payload.get('auto_updates_enabled') is not None
            else security_payload.get('unattended_upgrades_enabled')
        )
        _append_boolean_control(
            findings,
            control_id='CIS-LNX-PATCH-AUTO-001',
            title='Automatic security updates enabled',
            value=auto_updates_enabled,
            success_remediation='No action required.',
            failure_remediation='Enable unattended security updates for Linux package manager.',
            framework_refs=['CIS Linux'],
        )

        time_sync_enabled = _to_bool(
            security_payload.get('time_sync_enabled')
            if security_payload.get('time_sync_enabled') is not None
            else security_payload.get('ntp_enabled')
        )
        _append_boolean_control(
            findings,
            control_id='CIS-LNX-TIME-001',
            title='Time synchronization service enabled',
            value=time_sync_enabled,
            success_remediation='No action required.',
            failure_remediation='Enable chronyd or systemd-timesyncd to maintain trusted time.',
            framework_refs=['CIS Linux', 'NIST 800-53'],
        )

        mac_enforcement_enabled = _to_bool(
            security_payload.get('mac_enforcement_enabled')
            if security_payload.get('mac_enforcement_enabled') is not None
            else security_payload.get('selinux_enforcing')
        )
        _append_boolean_control(
            findings,
            control_id='CIS-LNX-MAC-001',
            title='Mandatory access control enforcement enabled',
            value=mac_enforcement_enabled,
            success_remediation='No action required.',
            failure_remediation='Enable SELinux/AppArmor enforcement mode on production hosts.',
            framework_refs=['CIS Linux'],
        )

    pass_count = sum(1 for finding in findings if finding.get('status') == 'pass')
    warn_count = sum(1 for finding in findings if finding.get('status') == 'warn')
    fail_count = sum(1 for finding in findings if finding.get('status') == 'fail')

    return {
        'source': 'posture_evaluator_v1',
        'target': target,
        'method': method,
        'evaluated_at': datetime.utcnow().isoformat(),
        'status': 'completed',
        'summary': {
            'checks_total': len(findings),
            'pass': pass_count,
            'warn': warn_count,
            'fail': fail_count,
        },
        'findings': findings,
    }
