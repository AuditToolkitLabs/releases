"""
Remote Executor Module - Cross-Platform Remote Execution

Provides unified remote execution across all server types:
- SSH for Linux/Unix servers
- WinRM for Windows servers
- Agent API for fleet agent servers

This module handles:
- Connection testing with real authentication
- Remote command execution
- Asset discovery and data collection
"""

import os
import logging
import socket
import errno
import ipaddress
import json
import re
import hashlib
import hmac
import time
import secrets
import shutil
import subprocess
from pathlib import Path
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from urllib.parse import quote

from ..security import validate_scan_target_ssrf
from .update_payload_schema import normalize_update_payload

logger = logging.getLogger(__name__)


# Try importing optional dependencies
try:
    import paramiko
    PARAMIKO_AVAILABLE = True
except ImportError:
    PARAMIKO_AVAILABLE = False
    logger.info("paramiko not available - SSH support will be limited")

try:
    import winrm
    WINRM_AVAILABLE = True
except ImportError:
    WINRM_AVAILABLE = False
    logger.info("pywinrm not available - WinRM support will be limited")

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Feature flag: set ASSET_DISCOVERY_NMAP_ENABLED=1 to allow nmap deep scans.
# nmap must also be installed and on PATH; otherwise falls back to TCP probes.
_NMAP_FEATURE_ENABLED = os.environ.get('ASSET_DISCOVERY_NMAP_ENABLED', '').strip() in ('1', 'true', 'yes')
_NMAP_BINARY = shutil.which('nmap')
NMAP_AVAILABLE = _NMAP_FEATURE_ENABLED and bool(_NMAP_BINARY)
if _NMAP_FEATURE_ENABLED and not _NMAP_BINARY:
    logger.warning("ASSET_DISCOVERY_NMAP_ENABLED is set but nmap binary was not found on PATH; falling back to TCP probe engine")


# =============================================================================
# SSH Host Key Policy (Security Hardening)
# =============================================================================

class SecureWarningPolicy:
    """
    SSH host key policy that warns about unknown keys but allows connections.

    This is a security compromise between convenience and strict verification:
    - Logs a warning for every unknown host key (auditable)
    - Allows the connection to proceed (backward compatible)

    For strict mode (recommended in production), set:
    SSH_HOST_KEY_POLICY=strict

    For silent auto-add (legacy, NOT RECOMMENDED), set:
    SSH_HOST_KEY_POLICY=auto
    """

    def missing_host_key(self, client, hostname, key):
        """Called when connecting to a host with unknown key."""
        policy_mode = _get_effective_ssh_host_key_policy_mode()

        key_fingerprint = ':'.join(format(b, '02x') for b in key.get_fingerprint())

        if policy_mode == 'strict':
            logger.warning(
                f"SSH SECURITY: Strict mode - rejecting unknown host key "
                f"for {hostname}. Fingerprint: {key_fingerprint}"
            )
            raise paramiko.AuthenticationException(
                f"Unknown host key for {hostname}. "
                f"Add key to known_hosts or set SSH_HOST_KEY_POLICY=warn"
            )
        elif policy_mode == 'auto':
            logger.info(f"SSH: Auto-accepting host key for {hostname} (legacy mode)")
            # Accept silently (NOT RECOMMENDED but available for legacy compatibility)
            client.get_host_keys().add(hostname, key.get_name(), key)
        else:
            # Default: warn mode - log warning but allow connection
            logger.warning(
                f"SSH SECURITY WARNING: Unknown host key for {hostname}. "
                f"Key type: {key.get_name()}, Fingerprint: {key_fingerprint}. "
                f"Connection allowed but this should be verified in production. "
                f"Set SSH_HOST_KEY_POLICY=strict to enforce key verification."
            )
            client.get_host_keys().add(hostname, key.get_name(), key)


def _get_effective_ssh_host_key_policy_mode() -> str:
    """
    Resolve effective SSH host key policy.

    Priority:
    1. Environment variable `SSH_HOST_KEY_POLICY`
    2. Main toolkit security setting `ssh_host_key_policy`
       from settings/security_settings.json (when accessible)
    3. Fallback: warn
    """
    valid_modes = {'strict', 'warn', 'auto'}

    env_mode = os.getenv('SSH_HOST_KEY_POLICY', '').strip().lower()
    if env_mode in valid_modes:
        return env_mode

    settings_file = os.getenv('SECURITY_SETTINGS_FILE', '').strip()
    if not settings_file:
        try:
            settings_file = str(Path(__file__).resolve().parents[4] / 'settings' / 'security_settings.json')
        except Exception:
            settings_file = ''

    if settings_file and os.path.exists(settings_file):
        try:
            with open(settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            configured_mode = str(settings.get('ssh_host_key_policy', '')).strip().lower()
            if configured_mode in valid_modes:
                return configured_mode
        except Exception as e:
            logger.debug(f"Could not read asset discovery SSH host key policy from settings file: {e}")

    return 'warn'


def _get_ssh_host_key_policy():
    """Get appropriate SSH host key policy based on configuration."""
    if not PARAMIKO_AVAILABLE:
        return None

    policy_mode = _get_effective_ssh_host_key_policy_mode()

    if policy_mode == 'strict':
        # Reject unknown keys (most secure)
        return paramiko.RejectPolicy()
    elif policy_mode == 'auto':
        # Auto-add keys silently (legacy - NOT RECOMMENDED)
        return paramiko.AutoAddPolicy()
    else:
        # Default: Warning policy (balanced security)
        return SecureWarningPolicy()


@dataclass
class ConnectionResult:
    """Result of a connection test."""
    success: bool
    message: str
    details: str = ""
    os_info: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'message': self.message,
            'details': self.details,
            'os_info': self.os_info,
            'error': self.error
        }


@dataclass
class ExecutionResult:
    """Result of remote command execution."""
    success: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int = -1
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'return_code': self.return_code,
            'error': self.error
        }


@dataclass
class Credentials:
    """Credentials for remote connection."""
    username: str = ""
    password: str = ""
    key_path: str = ""
    key_data: str = ""
    domain: str = ""
    auth_method: str = "password"  # password, key, negotiate


@dataclass
class DiscoveryResult:
    """Result of asset discovery scan."""
    success: bool
    hostname: str = ""
    ip_address: str = ""
    os_type: str = ""
    os_version: str = ""
    packages: List[Dict[str, Any]] = field(default_factory=list)
    services: List[Dict[str, Any]] = field(default_factory=list)
    storage: List[Dict[str, Any]] = field(default_factory=list)
    ports: List[Dict[str, Any]] = field(default_factory=list)
    users: List[Dict[str, Any]] = field(default_factory=list)
    updates_available: int = 0
    pending_updates: List[Dict[str, Any]] = field(default_factory=list)
    security_info: Dict[str, Any] = field(default_factory=dict)
    os_build: str = ""
    system: Dict[str, Any] = field(default_factory=dict)
    connection_method: str = ""
    discovery_tool_label: str = ""
    scan_profile: str = "standard"
    os_inference_confidence: float = 0.0
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'hostname': self.hostname,
            'ip_address': self.ip_address,
            'os_type': self.os_type,
            'os_version': self.os_version,
            'packages': self.packages,
            'services': self.services,
            'storage': self.storage,
            'ports': self.ports,
            'users': self.users,
            'updates_available': self.updates_available,
            'pending_updates': self.pending_updates,
            'security_info': self.security_info,
            'os_build': self.os_build,
            'system': self.system,
            'connection_method': self.connection_method,
            'discovery_tool_label': self.discovery_tool_label,
            'scan_profile': self.scan_profile,
            'os_inference_confidence': self.os_inference_confidence,
            'data': {
                'system': self.system,
                'software': self.packages,
                'services': self.services,
                'storage': self.storage,
                'ports': self.ports,
                'users': self.users,
                'pending_updates': self.pending_updates,
                'updates_available': self.updates_available,
                'security_info': self.security_info,
            },
            'error': self.error
        }


class BaseExecutor(ABC):
    """Base class for remote executors."""

    @abstractmethod
    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        """Test connection to the target."""
        raise NotImplementedError

    @abstractmethod
    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        """Execute a command on the target."""
        raise NotImplementedError

    @abstractmethod
    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        """Perform discovery scan on the target."""
        raise NotImplementedError

    def _test_port(self, target: str, port: int, timeout: int = 5) -> bool:
        """Test if a TCP port is open."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((target, port))
            sock.close()
            return result == 0
        except Exception:
            return False


class SSHExecutor(BaseExecutor):
    """SSH executor for Linux/Unix servers."""

    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        """Test SSH connection with authentication."""
        if not PARAMIKO_AVAILABLE:
            # Fallback to port check
            if self._test_port(target, port, timeout):
                return ConnectionResult(
                    success=True,
                    message=f"SSH port {port} is open on {target}",
                    details="Port connectivity verified.\nNote: Full auth test requires paramiko.\nInstall: pip install paramiko"
                )
            return ConnectionResult(
                success=False,
                message=f"Cannot reach SSH port {port} on {target}",
                error="Port not reachable"
            )

        client = paramiko.SSHClient()
        # SECURITY: Use configurable host key policy instead of AutoAddPolicy
        client.set_missing_host_key_policy(_get_ssh_host_key_policy())

        try:
            connect_kwargs = {
                'hostname': target,
                'port': port,
                'username': credentials.username,
                'timeout': timeout,
                'allow_agent': False,
                'look_for_keys': False
            }

            if credentials.auth_method == 'key' and credentials.key_path:
                connect_kwargs['key_filename'] = credentials.key_path
            elif credentials.auth_method == 'key' and credentials.key_data:
                import io
                key_file = io.StringIO(credentials.key_data)
                connect_kwargs['pkey'] = paramiko.RSAKey.from_private_key(key_file)
            else:
                connect_kwargs['password'] = credentials.password

            client.connect(**connect_kwargs)

            # Get OS info
            stdin, stdout, stderr = client.exec_command('uname -a && cat /etc/os-release 2>/dev/null || true', timeout=10)  # nosec B601
            output = stdout.read().decode('utf-8', errors='replace')

            os_info = self._parse_linux_os_info(output)

            client.close()

            return ConnectionResult(
                success=True,
                message=f"SSH connection successful to {target}",
                details=f"Authenticated as {credentials.username}",
                os_info=os_info
            )

        except paramiko.AuthenticationException:
            return ConnectionResult(
                success=False,
                message="SSH authentication failed",
                error="Invalid username or password/key",
                details="Check credentials and ensure the user has SSH access."
            )
        except paramiko.SSHException as e:
            return ConnectionResult(
                success=False,
                message=f"SSH error: {str(e)}",
                error=str(e)
            )
        except socket.timeout:
            return ConnectionResult(
                success=False,
                message=f"Connection timed out to {target}:{port}",
                error="Timeout"
            )
        except Exception as e:
            return ConnectionResult(
                success=False,
                message=f"Connection failed: {str(e)}",
                error=str(e)
            )
        finally:
            try:
                client.close()
            except Exception:  # noqa: BLE001 - Best effort cleanup
                logger.debug("Ignoring SSH client close error during connection test", exc_info=True)

    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        """Execute command via SSH."""
        if not PARAMIKO_AVAILABLE:
            return ExecutionResult(
                success=False,
                error="paramiko not installed. Install: pip install paramiko"
            )

        if not isinstance(command, str) or not command.strip():
            return ExecutionResult(
                success=False,
                error="Command must be a non-empty string"
            )

        if '\x00' in command:
            return ExecutionResult(
                success=False,
                error="Command contains an invalid null byte"
            )

        client = paramiko.SSHClient()
        # SECURITY: Use configurable host key policy instead of AutoAddPolicy
        client.set_missing_host_key_policy(_get_ssh_host_key_policy())

        try:
            connect_kwargs = {
                'hostname': target,
                'port': port,
                'username': credentials.username,
                'timeout': 30,
                'allow_agent': False,
                'look_for_keys': False
            }

            if credentials.auth_method == 'key' and credentials.key_path:
                connect_kwargs['key_filename'] = credentials.key_path
            else:
                connect_kwargs['password'] = credentials.password

            client.connect(**connect_kwargs)
            stdin, stdout, stderr = client.exec_command(command, timeout=timeout)  # nosec B601

            return ExecutionResult(
                success=True,
                stdout=stdout.read().decode('utf-8', errors='replace'),
                stderr=stderr.read().decode('utf-8', errors='replace'),
                return_code=stdout.channel.recv_exit_status()
            )

        except Exception as e:
            return ExecutionResult(
                success=False,
                error=str(e)
            )
        finally:
            try:
                client.close()
            except Exception:  # noqa: BLE001 - Best effort cleanup
                logger.debug("Ignoring SSH client close error during command execution", exc_info=True)

    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        """Perform Linux discovery scan via SSH."""
        result = DiscoveryResult(success=False, ip_address=target)
        result.connection_method = 'ssh'
        result.discovery_tool_label = 'SSH Discovery'

        if not PARAMIKO_AVAILABLE:
            result.error = "paramiko not installed"
            return result

        # Build discovery commands
        commands = []

        # Always get basic OS info
        commands.append("hostname && cat /etc/os-release 2>/dev/null || true")
        commands.append("""
            echo "fqdn=$(hostname -f 2>/dev/null || hostname 2>/dev/null || true)"
            echo "domain=$(hostname -d 2>/dev/null || dnsdomainname 2>/dev/null || true)"
            echo "kernel_version=$(uname -r 2>/dev/null || true)"
            echo "architecture=$(uname -m 2>/dev/null || true)"
            cpu_model=$( (lscpu 2>/dev/null | awk -F: '/Model name/{print $2; exit}') || (grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2) )
            echo "cpu_name=$(echo \"$cpu_model\" | xargs 2>/dev/null || true)"
            echo "cpu_cores=$(nproc 2>/dev/null || true)"
            echo "total_memory_gb=$(awk '/MemTotal/ {printf \"%.2f\", $2/1024/1024}' /proc/meminfo 2>/dev/null)"
            read_dmi() {
                local key="$1"
                local dmi_file="/sys/class/dmi/id/$key"
                local dmidecode_key=""
                if [ -r "$dmi_file" ]; then
                    tr -d '\\000' < "$dmi_file" 2>/dev/null | xargs 2>/dev/null || true
                    return
                fi
                case "$key" in
                    sys_vendor) dmidecode_key="system-manufacturer" ;;
                    product_name) dmidecode_key="system-product-name" ;;
                    product_serial) dmidecode_key="system-serial-number" ;;
                    board_serial) dmidecode_key="baseboard-serial-number" ;;
                    product_uuid) dmidecode_key="system-uuid" ;;
                    chassis_asset_tag) dmidecode_key="chassis-asset-tag" ;;
                    product_sku) dmidecode_key="system-sku-number" ;;
                    *) dmidecode_key="" ;;
                esac
                if command -v dmidecode >/dev/null 2>&1; then
                    if [ -n "$dmidecode_key" ]; then
                        dmidecode -s "$dmidecode_key" 2>/dev/null | head -n1 | xargs 2>/dev/null || true
                    fi
                fi
            }
            manufacturer=$(read_dmi sys_vendor)
                return result

                def _is_host_reachable(self, target: str, profile: Dict[str, Any]) -> bool:
            fi
            product_uuid=$(read_dmi product_uuid)
            asset_tag=$(read_dmi chassis_asset_tag)
            product_id=$(read_dmi product_sku)
            if [ -z "$product_id" ]; then
                product_id="$model"
            fi
            echo "manufacturer=$manufacturer"
            echo "model=$model"
            echo "serial_number=$serial_number"
            echo "product_uuid=$product_uuid"
            echo "asset_tag=$asset_tag"
            echo "product_id=$product_id"
            virt_type=$(systemd-detect-virt 2>/dev/null || true)
            if [ -n "$virt_type" ] && [ "$virt_type" != "none" ]; then
                echo "is_virtual=true"
                echo "hypervisor=$virt_type"
            else
                echo "is_virtual=false"
                echo "hypervisor="
            fi
            echo "last_boot=$(uptime -s 2>/dev/null || true)"
        """)

        if scope.get('packages', True):
            # Try multiple package managers
            commands.append("""
                if command -v dpkg >/dev/null 2>&1; then
                    dpkg-query -W -f='${Package}|${Version}|${Status}\n' 2>/dev/null | grep 'install ok installed' | head -500
                elif command -v rpm >/dev/null 2>&1; then
                    rpm -qa --queryformat '%{NAME}|%{VERSION}-%{RELEASE}|installed\n' 2>/dev/null | head -500
                elif command -v apk >/dev/null 2>&1; then
                    apk list --installed 2>/dev/null | head -500
                fi
            """)

        if scope.get('services', True):
            commands.append("""
                if command -v systemctl >/dev/null 2>&1; then
                    systemctl list-units --type=service --no-legend --no-pager 2>/dev/null | head -200
                elif command -v rc-service >/dev/null 2>&1; then
                    rc-service --list 2>/dev/null | head -200
                fi
            """)

        if scope.get('updates', True):
            commands.append("""
                if command -v apt >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:apt'
                    apt list --upgradable 2>/dev/null | tail -n +2 | head -200
                elif command -v dnf >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:dnf'
                    dnf --refresh check-update --quiet 2>/dev/null | head -200
                elif command -v yum >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:yum'
                    yum check-update --quiet 2>/dev/null | head -200
                elif command -v zypper >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:zypper'
                    zypper --non-interactive list-updates 2>/dev/null | head -200
                elif command -v apk >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:apk'
                    apk version -l '<' 2>/dev/null | head -200
                elif command -v pacman >/dev/null 2>&1; then
                    echo '__UPDATES_FORMAT__:pacman'
                    pacman -Qu 2>/dev/null | head -200
                else
                    echo '__UPDATES_FORMAT__:count'
                    echo 0
                fi
            """)

        if scope.get('ports', True):
            commands.append("ss -tuln 2>/dev/null || netstat -tuln 2>/dev/null | head -100")

        if scope.get('users', False):
            commands.append("cat /etc/passwd | cut -d: -f1,3,6,7 | head -100")

        # Execute all commands with robust separators.
        # Using ';' separators avoids parse/short-circuit issues with multiline
        # command blocks while still allowing section-based parsing.
        normalized_commands = [command.strip() for command in commands if command and command.strip()]
        combined_command = " ; echo '---SEPARATOR---' ; ".join(normalized_commands)
        exec_result = self.execute_command(target, port, credentials, combined_command, timeout=120)

        if not exec_result.success:
            result.error = exec_result.error
            return result

        # Parse results
        sections = exec_result.stdout.split('---SEPARATOR---')

        section_index = 0
        os_info: Dict[str, Any] = {}

        if len(sections) > section_index:
            os_info = self._parse_linux_os_info(sections[0])
            result.hostname = os_info.get('hostname', target)
            result.os_type = 'linux'
            result.os_version = os_info.get('version', 'Unknown')
            section_index += 1

        if len(sections) > section_index:
            system_info = self._parse_key_value_output(sections[section_index])
            result.system = {
                'hostname': result.hostname,
                'fqdn': system_info.get('fqdn'),
                'domain': system_info.get('domain'),
                'os_name': result.os_version,
                'os_version': result.os_version,
                'kernel_version': system_info.get('kernel_version') or os_info.get('kernel'),
                'architecture': system_info.get('architecture'),
                'manufacturer': system_info.get('manufacturer'),
                'model': system_info.get('model'),
                'serial_number': system_info.get('serial_number'),
                'product_id': system_info.get('product_id'),
                'asset_tag': system_info.get('asset_tag'),
                'product_uuid': system_info.get('product_uuid'),
                'cpu_name': system_info.get('cpu_name'),
                'cpu_cores': self._to_int(system_info.get('cpu_cores')),
                'cpu_logical_processors': self._to_int(system_info.get('cpu_cores')),
                'total_memory_gb': self._to_float(system_info.get('total_memory_gb')),
                'is_virtual': self._to_bool(system_info.get('is_virtual')),
                'hypervisor': system_info.get('hypervisor'),
                'last_boot': system_info.get('last_boot'),
            }
            result.hostname = result.system.get('fqdn') or result.hostname
            section_index += 1

        if scope.get('packages', True) and len(sections) > section_index:
            result.packages = self._parse_linux_packages(sections[section_index])
            section_index += 1

        if scope.get('services', True) and len(sections) > section_index:
            result.services = self._parse_linux_services(sections[section_index])
            section_index += 1

        if scope.get('updates', True) and len(sections) > section_index:
            pending_updates, updates_count = self._parse_linux_updates(sections[section_index])
            result.updates_available, result.pending_updates = normalize_update_payload(updates_count, pending_updates)
            section_index += 1

        if scope.get('ports', True) and len(sections) > section_index:
            result.ports = self._parse_linux_ports(sections[section_index])
            section_index += 1

        if scope.get('users', False) and len(sections) > section_index:
            result.users = self._parse_linux_users(sections[section_index])

        result.success = True
        return result

    def _parse_linux_os_info(self, output: str) -> Dict[str, Any]:
        """Parse Linux OS information."""
        info = {}
        lines = output.strip().split('\n')

        if lines:
            # First line is often uname -a or hostname
            first_line = lines[0].strip()
            if ' ' in first_line:  # uname output
                info['kernel'] = first_line
            else:
                info['hostname'] = first_line

        for line in lines:
            if '=' in line:
                key, _, value = line.partition('=')
                value = value.strip('"').strip("'")
                if key == 'PRETTY_NAME':
                    info['version'] = value
                elif key == 'ID':
                    info['distro'] = value
                elif key == 'VERSION_ID':
                    info['version_id'] = value

        return info

    def _parse_linux_packages(self, output: str) -> List[Dict[str, Any]]:
        """Parse Linux package list."""
        packages = []
        for line in output.strip().split('\n'):
            if '|' in line:
                parts = line.split('|')
                if len(parts) >= 2:
                    packages.append({
                        'name': parts[0].strip(),
                        'version': parts[1].strip()
                    })
        return packages[:500]  # Limit

    def _parse_linux_services(self, output: str) -> List[Dict[str, Any]]:
        """Parse Linux service list."""
        services = []
        for line in output.strip().split('\n'):
            parts = line.split()
            if parts:
                name = parts[0].replace('.service', '')
                status = 'running' if 'running' in line.lower() else 'stopped'
                services.append({'name': name, 'status': status})
        return services[:200]

    def _parse_linux_ports(self, output: str) -> List[Dict[str, Any]]:
        """Parse Linux listening ports."""
        ports = []
        for line in output.strip().split('\n'):
            if 'LISTEN' in line or ':' in line:
                parts = line.split()
                for part in parts:
                    if ':' in part:
                        try:
                            port_num = part.split(':')[-1]
                            if port_num.isdigit():
                                proto = 'tcp' if 'tcp' in line.lower() else 'udp'
                                ports.append({'port': int(port_num), 'protocol': proto})
                                break
                        except (ValueError, IndexError):  # Specific parsing exceptions
                            pass
        return list({p['port']: p for p in ports}.values())[:100]

    def _parse_linux_users(self, output: str) -> List[Dict[str, Any]]:
        """Parse Linux user list."""
        users = []
        for line in output.strip().split('\n'):
            parts = line.split(':')
            if len(parts) >= 4:
                users.append({
                    'username': parts[0],
                    'uid': parts[1],
                    'home': parts[2] if len(parts) > 2 else '',
                    'shell': parts[3] if len(parts) > 3 else ''
                })
        return users

    def _parse_linux_updates(self, output: str) -> tuple[List[Dict[str, Any]], int]:
        """Parse Linux pending updates from package-manager specific output."""
        raw_lines = [line.strip() for line in output.strip().split('\n') if line.strip()]
        if not raw_lines:
            return [], 0

        output_format = 'count'
        if raw_lines[0].startswith('__UPDATES_FORMAT__:'):
            output_format = raw_lines[0].split(':', 1)[1].strip().lower()
            raw_lines = raw_lines[1:]

        lines = [
            line for line in raw_lines
            if line and not line.lower().startswith(('warning:', 'listing...', 'last metadata expiration check:'))
        ]
        if not lines:
            return [], 0

        pending_updates: List[Dict[str, Any]] = []

        if output_format == 'apt':
            for line in lines:
                match = re.match(r'^([^/]+)/[^\s]+\s+([^\s]+).+\[upgradable from:\s*([^\]]+)\]', line)
                if not match:
                    continue
                pending_updates.append({
                    'name': match.group(1).strip(),
                    'current_version': match.group(3).strip(),
                    'new_version': match.group(2).strip(),
                })
        elif output_format in {'dnf', 'yum'}:
            for line in lines:
                line_lower = line.lower()
                if line_lower.startswith(('obsoleting packages', 'security:', 'loaded plugins:')):
                    continue
                parts = line.split()
                if len(parts) < 2:
                    continue
                package_name = parts[0].split('.', 1)[0].strip()
                pending_updates.append({
                    'name': package_name,
                    'new_version': parts[1].strip(),
                })
        elif output_format == 'zypper':
            for line in lines:
                if '|' not in line:
                    continue
                parts = [part.strip() for part in line.split('|')]
                if len(parts) < 6 or parts[0].lower() in {'s', 'v'} and parts[2].lower() == 'name':
                    continue
                if parts[2].lower() == 'name':
                    continue
                pending_updates.append({
                    'name': parts[2],
                    'current_version': parts[3],
                    'new_version': parts[4],
                })
        elif output_format == 'apk':
            for line in lines:
                if ' < ' not in line:
                    continue
                left, right = [part.strip() for part in line.split(' < ', 1)]
                package_name = left.rsplit('-', 1)[0].strip() if '-' in left else left
                pending_updates.append({
                    'name': package_name,
                    'current_version': left,
                    'new_version': right,
                })
        elif output_format == 'pacman':
            for line in lines:
                match = re.match(r'^(\S+)\s+(\S+)\s+->\s+(\S+)', line)
                if not match:
                    continue
                pending_updates.append({
                    'name': match.group(1),
                    'current_version': match.group(2),
                    'new_version': match.group(3),
                })

        if pending_updates:
            return pending_updates, len(pending_updates)

        try:
            return [], int(lines[-1])
        except (TypeError, ValueError):
            return [], len(lines)

    def _parse_key_value_output(self, output: str) -> Dict[str, str]:
        """Parse key=value output from shell probes."""
        info: Dict[str, str] = {}
        for line in output.strip().split('\n'):
            if '=' not in line:
                continue
            key, _, value = line.partition('=')
            info[key.strip()] = value.strip()
        return info

    def _to_int(self, value: Any) -> Optional[int]:
        try:
            if value in (None, ''):
                return None
            return int(str(value).strip())
        except (TypeError, ValueError):
            return None

    def _to_float(self, value: Any) -> Optional[float]:
        try:
            if value in (None, ''):
                return None
            return float(str(value).strip())
        except (TypeError, ValueError):
            return None

    def _to_bool(self, value: Any) -> Optional[bool]:
        if value is None:
            return None
        normalized = str(value).strip().lower()
        if normalized in {'true', '1', 'yes', 'on'}:
            return True
        if normalized in {'false', '0', 'no', 'off'}:
            return False
        return None


class WinRMExecutor(BaseExecutor):
    """WinRM executor for Windows servers."""

    @staticmethod
    def _winrm_server_cert_validation(use_ssl: bool) -> str:
        """Return pywinrm certificate validation mode.

        Defaults to strict validation for HTTPS WinRM. Set
        ASSET_DISCOVERY_WINRM_INSECURE_TLS=true to temporarily allow
        self-signed/untrusted certs.
        """
        if not use_ssl:
            return 'validate'

        insecure_tls = os.getenv('ASSET_DISCOVERY_WINRM_INSECURE_TLS', '').strip().lower()
        if insecure_tls in {'1', 'true', 'yes', 'on'}:
            logger.warning(
                "WinRM TLS certificate validation disabled via "
                "ASSET_DISCOVERY_WINRM_INSECURE_TLS; this is insecure for production"
            )
            return 'ignore'

        return 'validate'

    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        """Test WinRM connection with authentication."""
        if not WINRM_AVAILABLE:
            # Fallback to port check
            if self._test_port(target, port, timeout):
                return ConnectionResult(
                    success=True,
                    message=f"WinRM port {port} is open on {target}",
                    details="Port connectivity verified.\nNote: Full auth test requires pywinrm.\nInstall: pip install pywinrm"
                )
            return ConnectionResult(
                success=False,
                message=f"Cannot reach WinRM port {port} on {target}",
                error="Port not reachable"
            )

        # Determine protocol based on port
        use_ssl = port == 5986
        protocol = 'https' if use_ssl else 'http'
        endpoint = f"{protocol}://{target}:{port}/wsman"

        # Build username with domain if provided
        username = credentials.username
        if credentials.domain and '\\' not in username and '@' not in username:
            username = f"{credentials.domain}\\{username}"

        try:
            session = winrm.Session(
                target=endpoint,
                auth=(username, credentials.password),
                transport='ntlm',
                server_cert_validation=self._winrm_server_cert_validation(use_ssl),
                read_timeout_sec=timeout + 5,
                operation_timeout_sec=timeout
            )

            # Test with a simple command
            result = session.run_ps('$env:COMPUTERNAME; [Environment]::OSVersion.VersionString')

            if result.status_code == 0:
                output = result.std_out.decode('utf-8', errors='replace').strip()
                lines = output.split('\n')
                computer_name = lines[0].strip() if lines else target
                os_version = lines[1].strip() if len(lines) > 1 else 'Unknown'

                return ConnectionResult(
                    success=True,
                    message=f"WinRM connection successful to {computer_name}",
                    details=f"Authenticated as {username}",
                    os_info={'hostname': computer_name, 'version': os_version, 'type': 'windows'}
                )
            else:
                error = result.std_err.decode('utf-8', errors='replace')
                return ConnectionResult(
                    success=False,
                    message="WinRM connected but command failed",
                    error=error
                )

        except Exception as e:
            error_str = str(e).lower()
            if 'unauthorized' in error_str or '401' in error_str:
                return ConnectionResult(
                    success=False,
                    message="WinRM authentication failed",
                    error="Invalid username or password",
                    details="Check credentials. For domain accounts use DOMAIN\\user format."
                )
            elif 'refused' in error_str:
                return ConnectionResult(
                    success=False,
                    message=f"WinRM connection refused on port {port}",
                    error="Connection refused",
                    details="Enable WinRM on target: Enable-PSRemoting -Force"
                )
            return ConnectionResult(
                success=False,
                message=f"WinRM connection error: {str(e)}",
                error=str(e)
            )

    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        """Execute PowerShell command via WinRM."""
        if not WINRM_AVAILABLE:
            return ExecutionResult(
                success=False,
                error="pywinrm not installed. Install: pip install pywinrm"
            )

        use_ssl = port == 5986
        protocol = 'https' if use_ssl else 'http'
        endpoint = f"{protocol}://{target}:{port}/wsman"

        username = credentials.username
        if credentials.domain and '\\' not in username and '@' not in username:
            username = f"{credentials.domain}\\{username}"

        try:
            session = winrm.Session(
                target=endpoint,
                auth=(username, credentials.password),
                transport='ntlm',
                server_cert_validation=self._winrm_server_cert_validation(use_ssl),
                read_timeout_sec=timeout + 5,
                operation_timeout_sec=timeout
            )

            result = session.run_ps(command)
            stdout_text = result.std_out.decode('utf-8', errors='replace')
            stderr_text = result.std_err.decode('utf-8', errors='replace')
            command_success = result.status_code == 0

            command_error = None
            if not command_success:
                command_error = stderr_text.strip() or stdout_text.strip()
                if not command_error:
                    command_error = f"WinRM command exited with code {result.status_code}"

            return ExecutionResult(
                success=command_success,
                stdout=stdout_text,
                stderr=stderr_text,
                return_code=result.status_code,
                error=command_error
            )

        except Exception as e:
            return ExecutionResult(
                success=False,
                error=str(e)
            )

    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        """Perform Windows discovery scan via WinRM."""
        result = DiscoveryResult(success=False, ip_address=target)
        result.connection_method = 'winrm'
        result.discovery_tool_label = 'WinRM Discovery'

        if not WINRM_AVAILABLE:
            result.error = "pywinrm not installed"
            return result

        # Build compact PowerShell discovery script to avoid WinRM command-length limits
        ps_script = (
            "$ErrorActionPreference='SilentlyContinue';"
            "$o=@{};"
            "$o.hostname=$env:COMPUTERNAME;"
            "$os=Get-CimInstance Win32_OperatingSystem;"
            "$cs=Get-CimInstance Win32_ComputerSystem;"
            "$cpu=Get-CimInstance Win32_Processor|Select-Object -First 1;"
            "$bios=Get-CimInstance Win32_BIOS;"
            "$csp=Get-CimInstance Win32_ComputerSystemProduct;"
            "$enc=Get-CimInstance Win32_SystemEnclosure|Select-Object -First 1;"
            "$productId=(Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion' -Name ProductId -EA SilentlyContinue).ProductId;"
            "$o.os_version=$os.Caption;"
            "$o.os_build=[Environment]::OSVersion.VersionString;"
            "$o.domain=$cs.Domain;"
            "$o.fqdn=if($cs.Domain -and $cs.Domain -notin @('WORKGROUP','')){"
            "$($env:COMPUTERNAME).$($cs.Domain)"
            "}else{$env:COMPUTERNAME};"
            "$o.kernel_version=$os.Version;"
            "$o.architecture=$os.OSArchitecture;"
            "$o.manufacturer=$cs.Manufacturer;"
            "$o.model=$cs.Model;"
            "$o.serial_number=$bios.SerialNumber;"
            "$o.product_id=if($productId){$productId}else{$csp.IdentifyingNumber};"
            "$o.asset_tag=$enc.SMBIOSAssetTag;"
            "$o.product_uuid=$csp.UUID;"
            "$o.cpu_name=$cpu.Name;"
            "$o.cpu_cores=$cpu.NumberOfCores;"
            "$o.cpu_logical_processors=$cpu.NumberOfLogicalProcessors;"
            "$o.total_memory_gb=[Math]::Round(($cs.TotalPhysicalMemory/1GB),2);"
            "$o.last_boot=$os.LastBootUpTime;"
            "$vh=@('Virtual','VMware','KVM','Hyper-V','VirtualBox','Xen');"
            "$o.is_virtual=[bool]($vh|Where-Object{$cs.Model -like \"*$_*\" -or $cs.Manufacturer -like \"*$_*\"}|Select-Object -First 1);"
            "$o.hypervisor=if($o.is_virtual){$cs.Model}else{$null};"
        )

        if scope.get('packages', True):
            ps_script += (
                "$sw=@();"
                "$seen=@{};"
                "$paths=@('HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',"
                "'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',"
                "'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',"
                "'HKCU:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*');"
                "foreach($p in $paths){"
                "Get-ItemProperty -Path $p -EA SilentlyContinue|Where-Object{$_.DisplayName -and $_.SystemComponent -ne 1}|"
                "ForEach-Object{"
                "$name=[string]$_.DisplayName;"
                "$version=if($_.DisplayVersion){[string]$_.DisplayVersion}else{$null};"
                "$publisher=if($_.Publisher){[string]$_.Publisher}else{$null};"
                "$key=(\"{0}|{1}|{2}\" -f $name,$version,$publisher).ToLowerInvariant();"
                "if(-not $seen.ContainsKey($key)){"
                "$seen[$key]=$true;"
                "$installDate=$null;"
                "if($_.InstallDate -match '^[0-9]{8}$'){$installDate=[datetime]::ParseExact([string]$_.InstallDate,'yyyyMMdd',$null).ToString('yyyy-MM-dd')}"
                "elseif($_.InstallDate){$installDate=[string]$_.InstallDate};"
                "$sw+=@{"
                "name=$name;version=$version;version_raw=$version;publisher=$publisher;install_date=$installDate;"
                "install_location=if($_.InstallLocation){[string]$_.InstallLocation}else{$null};"
                "architecture=if($p -like '*WOW6432Node*'){'x86'}else{'x64'};"
                "package_type='windows-registry'"
                "}"
                "}"
                "}"
                "};"
                "$o.packages=$sw|Sort-Object name|Select-Object -First 2000;"
            )

        if scope.get('services', True):
            ps_script += (
                "$o.services=Get-Service|Select-Object -First 200|ForEach-Object{"
                "@{name=$_.Name;display_name=$_.DisplayName;status=$_.Status.ToString()}"
                "};"
            )

        if scope.get('updates', True):
            ps_script += (
                "$updates=@();"
                "try{"
                "$us=New-Object -ComObject Microsoft.Update.Session;"
                "$sr=$us.CreateUpdateSearcher().Search(\"IsInstalled=0 and Type='Software'\");"
                "$o.updates_available=$sr.Updates.Count;"
                "foreach($u in ($sr.Updates | Select-Object -First 200)){"
                "$kb=$null;"
                "if($u.KBArticleIDs -and $u.KBArticleIDs.Count -gt 0){$kb='KB' + ($u.KBArticleIDs -join ',KB')};"
                "$updates+=@{"
                "name=[string]$u.Title;"
                "current_version=$null;"
                "new_version=$null;"
                "kb=$kb;"
                "update_id=if($u.Identity){[string]$u.Identity.UpdateID}else{$null};"
                "revision_number=if($u.Identity){[string]$u.Identity.RevisionNumber}else{$null}"
                "}"
                "};"
                "$o.pending_updates=$updates"
                "}catch{$o.updates_available=0;$o.pending_updates=@()};"
            )

        if scope.get('ports', True):
            ps_script += (
                "$o.ports=Get-NetTCPConnection -State Listen -EA SilentlyContinue|Select-Object -First 100|"
                "ForEach-Object{@{port=$_.LocalPort;protocol='tcp';process=(Get-Process -Id $_.OwningProcess -EA SilentlyContinue).Name}};"
            )

        if scope.get('users', False):
            ps_script += "$o.users=Get-LocalUser -EA SilentlyContinue|ForEach-Object{@{username=$_.Name;enabled=$_.Enabled;last_logon=$_.LastLogon}};"

        ps_script += "$o|ConvertTo-Json -Depth 4 -Compress"

        exec_result = self.execute_command(target, port, credentials, ps_script, timeout=180)

        command_error = None
        if not exec_result.success:
            command_error = exec_result.error or exec_result.stderr.strip()
            if not str(exec_result.stdout or '').strip():
                result.error = command_error or f"WinRM discovery command failed (exit code {exec_result.return_code})"
                return result

        try:
            data = json.loads(exec_result.stdout)

            result.hostname = data.get('hostname', target)
            result.os_type = 'windows'
            result.os_version = data.get('os_version', 'Unknown')
            result.os_build = data.get('os_build', '')
            result.packages = data.get('packages', [])
            result.services = data.get('services', [])
            result.updates_available, result.pending_updates = normalize_update_payload(
                data.get('updates_available', 0),
                data.get('pending_updates'),
            )
            result.ports = data.get('ports', [])
            result.users = data.get('users', [])
            result.system = {
                'hostname': result.hostname,
                'fqdn': data.get('fqdn'),
                'domain': data.get('domain'),
                'os_name': result.os_version,
                'os_version': result.os_version,
                'os_build': result.os_build,
                'kernel_version': data.get('kernel_version'),
                'architecture': data.get('architecture'),
                'manufacturer': data.get('manufacturer'),
                'model': data.get('model'),
                'serial_number': data.get('serial_number'),
                'product_id': data.get('product_id'),
                'asset_tag': data.get('asset_tag'),
                'product_uuid': data.get('product_uuid'),
                'cpu_name': data.get('cpu_name'),
                'cpu_cores': data.get('cpu_cores'),
                'cpu_logical_processors': data.get('cpu_logical_processors'),
                'total_memory_gb': data.get('total_memory_gb'),
                'is_virtual': data.get('is_virtual'),
                'hypervisor': data.get('hypervisor'),
                'last_boot': data.get('last_boot'),
            }
            result.success = True

            if command_error:
                logger.warning(
                    "WinRM discovery on %s returned non-zero exit code %s but emitted valid JSON output; "
                    "continuing as success. Error: %s",
                    target,
                    exec_result.return_code,
                    command_error,
                )

        except json.JSONDecodeError as e:
            if command_error:
                result.error = f"{command_error}; failed to parse discovery output: {e}"
            else:
                result.error = f"Failed to parse discovery output: {e}"

        return result


class FleetAgentExecutor(BaseExecutor):
    """
    Executor for managed two-way agents.

    Managed agents are registered with the main toolkit and poll for commands.
    This executor reads agent data from the shared data directory, avoiding
    the need for direct HTTP connections to each agent.

    Features:
    - Reads from shared data/agents directory
    - Uses agent's last heartbeat data for discovery
    - Can queue discovery commands for agents to execute
    - Works with both online and recently-seen agents
    """

    AGENTS_DIR = 'data/agents'

    @classmethod
    def _candidate_agent_dirs(cls) -> list[str]:
        """Get prioritized candidate directories for fleet-agent data."""
        repo_relative = os.path.abspath(
            os.path.join(os.path.dirname(__file__), '../../../../data/agents')
        )
        env_dir = os.environ.get('AGENTS_DATA_DIR')

        candidates = [
            env_dir,
            cls.AGENTS_DIR,
            repo_relative,
            '/app/data/agents',
        ]

        return [path for path in candidates if path]

    @classmethod
    def candidate_agent_dirs(cls) -> list[str]:
        """Public accessor for fleet-agent candidate directories."""
        return cls._candidate_agent_dirs()

    def __init__(self):
        """Initialize fleet agent executor."""
        self.agents_dir = self.AGENTS_DIR
        for candidate in self._candidate_agent_dirs():
            if os.path.exists(candidate):
                self.agents_dir = candidate
                break

        self.main_tool_url = (os.getenv('MAIN_TOOL_URL') or os.getenv('AUDIT_TOOLKIT_URL') or 'http://localhost:5000').rstrip('/')
        self.api_key = os.getenv('ASSET_DISCOVERY_API_KEY') or os.getenv('AGENT_SYNC_API_KEY')
        self.api_timeout = max(1, int(os.getenv('FLEET_AGENT_API_TIMEOUT_SEC', '10')))
        self.discovery_timeout = max(5, int(os.getenv('FLEET_AGENT_DISCOVERY_TIMEOUT_SEC', '120')))
        self.poll_interval = max(1, int(os.getenv('FLEET_AGENT_DISCOVERY_POLL_INTERVAL_SEC', '5')))

    def _load_agent_by_hostname(self, hostname: str) -> Optional[Dict[str, Any]]:
        """Load agent data by hostname."""
        if not os.path.exists(self.agents_dir):
            return None

        for filename in os.listdir(self.agents_dir):
            if filename.endswith('.json'):
                try:
                    filepath = os.path.join(self.agents_dir, filename)
                    with open(filepath, 'r') as f:
                        agent = json.load(f)
                        if agent.get('hostname', '').lower() == hostname.lower():
                            return agent
                except Exception as agent_load_error:  # noqa: BLE001 - skip malformed agent entries
                    logger.debug("Skipping malformed fleet-agent file %s: %s", filename, agent_load_error)
        return None

    def _api_headers(self) -> Dict[str, str]:
        """Headers for API calls to main toolkit."""
        headers: Dict[str, str] = {}
        if self.api_key:
            headers['X-API-Key'] = self.api_key
        return headers

    def _queue_discovery_command(self, agent_id: str, target: str, scope: Dict[str, bool]) -> Optional[str]:
        """Queue fleet-agent discovery command via main toolkit API."""
        if not REQUESTS_AVAILABLE:
            return None
        if not self.api_key:
            logger.debug("Managed discovery queue skipped: no API key configured")
            return None

        payload = {
            'agent_id': agent_id,
            'command_type': 'run_discovery',
            'command_data': {
                'target_hostname': target,
                'scope': scope,
            },
            'priority': 3,
            'expires_hours': 1,
        }

        try:
            response = requests.post(
                f"{self.main_tool_url}/api/agent/commands/queue",
                json=payload,
                headers=self._api_headers(),
                timeout=self.api_timeout,
            )
            if response.status_code != 200:
                logger.warning(
                    "Managed discovery queue request failed for %s (HTTP %s)",
                    target,
                    response.status_code,
                )
                return None

            body = response.json() if response.content else {}
            command = body.get('command') if isinstance(body, dict) else {}
            command_id = command.get('id') if isinstance(command, dict) else None
            if not command_id:
                logger.warning("Managed discovery queue response missing command id for %s", target)
                return None
            return command_id
        except Exception as e:  # noqa: BLE001 - queue failures should fall back gracefully
            logger.warning("Managed discovery queue failed for %s: %s", target, e)
            return None

    def _wait_for_command_completion(self, agent_id: str, command_id: str) -> Optional[Dict[str, Any]]:
        """Poll command history until command reaches terminal state or timeout."""
        if not REQUESTS_AVAILABLE or not self.api_key:
            return None

        deadline = time.monotonic() + self.discovery_timeout
        while time.monotonic() < deadline:
            try:
                response = requests.get(
                    f"{self.main_tool_url}/api/agent/commands/history",
                    params={'agent_id': agent_id, 'limit': 100},
                    headers=self._api_headers(),
                    timeout=self.api_timeout,
                )
                if response.status_code == 200:
                    body = response.json() if response.content else {}
                    commands = body.get('commands', []) if isinstance(body, dict) else []
                    for command in commands:
                        if command.get('id') != command_id:
                            continue
                        if command.get('status') in {'completed', 'failed', 'expired'}:
                            return command
                        break
            except Exception as e:  # noqa: BLE001 - non-fatal poll failures
                logger.debug("Managed discovery command poll error for %s: %s", agent_id, e)

            time.sleep(self.poll_interval)

        return None

    def _fetch_discovery_payload(self, hostname: str) -> Optional[Dict[str, Any]]:
        """Fetch latest discovery payload for host from main toolkit API."""
        if not REQUESTS_AVAILABLE or not self.api_key:
            return None

        safe_hostname = quote(hostname, safe='')
        try:
            response = requests.get(
                f"{self.main_tool_url}/api/agent/discovery/{safe_hostname}",
                headers=self._api_headers(),
                timeout=self.api_timeout,
            )
            if response.status_code != 200:
                return None
            body = response.json() if response.content else {}
            if not isinstance(body, dict) or not body.get('success'):
                return None
            payload = body.get('discovery')
            return payload if isinstance(payload, dict) else None
        except Exception as e:  # noqa: BLE001 - fallback to cached record
            logger.debug("Managed discovery payload fetch failed for %s: %s", hostname, e)
            return None

    def _populate_from_agent_record(self, result: DiscoveryResult, target: str, agent: Dict[str, Any], scope: Dict[str, bool]) -> None:
        """Populate discovery result from fleet agent heartbeat record."""
        result.hostname = agent.get('hostname', target)
        result.os_type = 'windows' if 'windows' in agent.get('os_type', '').lower() else 'linux'
        result.os_version = agent.get('os_name', 'Unknown')
        resources = agent.get('resources', {})
        result.system = {
            'hostname': result.hostname,
            'os_name': result.os_version,
            'os_version': result.os_version,
            'cpu_name': resources.get('cpu_name'),
            'cpu_cores': resources.get('cpu_cores'),
            'cpu_logical_processors': resources.get('cpu_logical_processors'),
            'total_memory_gb': resources.get('total_memory_gb'),
        }

        detected_software = agent.get('detected_software', [])
        if detected_software and scope.get('packages', True):
            result.packages = [
                {'name': software_name, 'version': 'detected', 'source': 'agent'}
                for software_name in detected_software
            ]

        result.security_info = {
            'agent_version': agent.get('agent_version'),
            'last_seen': agent.get('last_seen'),
            'cpu_pct': resources.get('cpu_pct'),
            'memory_free_pct': resources.get('memory_free_pct'),
            'agent_id': agent.get('agent_id'),
            'managed_discovery_source': 'agent_record',
        }

        result.success = True

    def _apply_discovery_payload(self, result: DiscoveryResult, payload: Dict[str, Any], scope: Dict[str, bool]) -> None:
        """Map uploaded fleet-agent discovery payload into DiscoveryResult."""
        if not isinstance(payload, dict):
            return

        hostname = payload.get('hostname')
        if hostname:
            result.hostname = hostname

        os_type = str(payload.get('os_type', '')).lower()
        if os_type:
            if 'windows' in os_type:
                result.os_type = 'windows'
            elif 'linux' in os_type:
                result.os_type = 'linux'
            else:
                result.os_type = os_type

        os_name = payload.get('os_name') or payload.get('os_version')
        if os_name:
            result.os_version = os_name

        system_info = payload.get('system_info') if isinstance(payload.get('system_info'), dict) else {}
        result.system = {
            'hostname': result.hostname,
            'fqdn': payload.get('fqdn') or payload.get('domain'),
            'domain': payload.get('domain'),
            'os_name': payload.get('os_name') or result.os_version,
            'os_version': payload.get('os_version') or result.os_version,
            'architecture': payload.get('architecture') or system_info.get('architecture'),
            'cpu_name': system_info.get('cpu') or payload.get('cpu_name'),
            'cpu_cores': system_info.get('cpu_cores') or payload.get('cpu_cores'),
            'cpu_logical_processors': system_info.get('cpu_logical_processors') or payload.get('cpu_logical_processors'),
            'total_memory_gb': system_info.get('memory_gb') or payload.get('total_memory_gb'),
            'disk_total_gb': system_info.get('disk_total_gb') or payload.get('disk_total_gb'),
            'disk_free_gb': system_info.get('disk_free_gb') or payload.get('disk_free_gb'),
        }

        if scope.get('packages', True):
            result.packages = payload.get('packages', []) if isinstance(payload.get('packages'), list) else []
        if scope.get('services', True):
            result.services = payload.get('services', []) if isinstance(payload.get('services'), list) else []
        if scope.get('ports', True):
            result.ports = payload.get('open_ports', []) if isinstance(payload.get('open_ports'), list) else []
        if scope.get('users', False):
            result.users = payload.get('users', []) if isinstance(payload.get('users'), list) else []
        if scope.get('updates', True):
            updates = payload.get('updates_available')
            if isinstance(updates, list):
                result.updates_available, result.pending_updates = normalize_update_payload(updates, updates)
            else:
                pending_updates = payload.get('pending_updates')
                if isinstance(pending_updates, list):
                    result.updates_available, result.pending_updates = normalize_update_payload(None, pending_updates)
                else:
                    result.updates_available, result.pending_updates = normalize_update_payload(payload.get('update_count'), None)

        security = payload.get('security') if isinstance(payload.get('security'), dict) else {}
        security_info = dict(result.security_info or {})
        security_info.update({
            'agent_id': payload.get('agent_id') or security_info.get('agent_id'),
            'agent_version': payload.get('agent_version') or security_info.get('agent_version'),
            'last_seen': payload.get('received_at') or security_info.get('last_seen'),
            'discovered_at': payload.get('discovered_at'),
            'managed_discovery_source': 'agent_discovery_api',
            'security': security,
        })
        result.security_info = security_info

        result.discovery_tool_label = 'Fleet Agent API Discovery'
        result.success = True

    def _is_agent_online(self, agent: Dict[str, Any], max_age_seconds: int = 300) -> bool:
        """Check if agent has been seen recently (within max_age_seconds)."""
        last_seen = agent.get('last_seen')
        if not last_seen:
            return False

        try:
            last_seen_dt = datetime.fromisoformat(last_seen.replace('Z', '+00:00'))
            age = (datetime.now() - last_seen_dt.replace(tzinfo=None)).total_seconds()
            return age < max_age_seconds
        except Exception:
            return False

    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        """Test if fleet agent exists and is online."""
        agent = self._load_agent_by_hostname(target)

        if not agent:
            return ConnectionResult(
                success=False,
                message=f"No fleet agent registered for {target}",
                error="Agent not found",
                details="Register the fleet agent with the main toolkit first."
            )

        is_online = self._is_agent_online(agent)

        return ConnectionResult(
            success=True,  # Agent exists, even if offline data may be useful
            message=f"Managed agent found: {agent.get('agent_id')}",
            details=f"Status: {'online' if is_online else 'offline'}, Last seen: {agent.get('last_seen', 'never')}",
            os_info={
                'hostname': agent.get('hostname', target),
                'os_type': agent.get('os_type', 'unknown'),
                'version': agent.get('os_name', 'unknown')
            }
        )

    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        """Queue command for fleet agent to execute."""
        # Managed agents execute commands via poll mechanism
        # This would queue a command for the agent to pick up
        return ExecutionResult(
            success=False,
            error="Command execution via fleet agent requires queuing. Use the main toolkit's command API."
        )

    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        """
        Discover system info from fleet agent data.

        Uses the heartbeat data that fleet agents send during polling.
        For fresh data, trigger a discovery audit via the command queue.
        """
        result = DiscoveryResult(success=False, ip_address=target)
        result.connection_method = 'managed'
        result.discovery_tool_label = 'Fleet Agent Discovery'

        agent = self._load_agent_by_hostname(target)
        if not agent:
            result.error = f"No fleet agent found for {target}"
            return result

        self._populate_from_agent_record(result, target, agent, scope)

        agent_id = agent.get('agent_id')
        if not agent_id:
            return result

        command_id = self._queue_discovery_command(agent_id, target, scope)
        if not command_id:
            return result

        command = self._wait_for_command_completion(agent_id, command_id)
        if not command:
            result.security_info['managed_discovery_command_id'] = command_id
            result.security_info['managed_discovery_status'] = 'timeout'
            return result

        command_status = command.get('status', 'unknown')
        result.security_info['managed_discovery_command_id'] = command_id
        result.security_info['managed_discovery_status'] = command_status
        if command_status != 'completed':
            return result

        payload = self._fetch_discovery_payload(result.hostname or target)
        if payload:
            self._apply_discovery_payload(result, payload, scope)

        return result

class AgentExecutor(BaseExecutor):
    """Agent API executor for fleet agent servers."""

    _READ_ONLY_COMMAND_MAP = {
        'system-info': 'full',
        'system_info': 'full',
        'hostname': 'hostname',
        'os-type': 'os_type',
        'os_type': 'os_type',
        'os-version': 'os_version',
        'os_version': 'os_version',
        'packages': 'packages',
        'services': 'services',
        'storage': 'storage',
        'ports': 'ports',
        'users': 'users',
        'updates': 'pending_updates',
        'pending-updates': 'pending_updates',
        'pending_updates': 'pending_updates',
        'security': 'security',
    }

    def __init__(self, agent_api_base: Optional[str] = None):
        """
        Initialize Agent executor.

        Args:
            agent_api_base: Base URL for the main audit tool's agent API
        """
        self.agent_api_base = agent_api_base or 'http://localhost:5001/api/v1/agent-managed'
        self.api_key = (os.getenv('ASSET_DISCOVERY_AGENT_API_KEY') or os.getenv('ASSET_DISCOVERY_API_KEY') or '').strip()
        self.request_signing_key = (os.getenv('ASSET_DISCOVERY_AGENT_REQUEST_SIGNING_KEY') or self.api_key or '').strip()
        verify_env = str(os.getenv('ASSET_DISCOVERY_AGENT_TLS_VERIFY', 'true') or '').strip().lower()
        self._tls_verify = verify_env not in {'0', 'false', 'no', 'off'}
        self._allow_http_fallback = str(os.getenv('ASSET_DISCOVERY_AGENT_ALLOW_HTTP', 'false') or '').strip().lower() in {
            '1', 'true', 'yes', 'on'
        }
        self._require_api_key = str(os.getenv('ASSET_DISCOVERY_AGENT_REQUIRE_API_KEY', 'true') or '').strip().lower() in {
            '1', 'true', 'yes', 'on'
        }
        self._require_request_signatures = str(os.getenv('ASSET_DISCOVERY_AGENT_REQUIRE_REQUEST_SIGNATURES', 'true') or '').strip().lower() in {
            '1', 'true', 'yes', 'on'
        }

    def _build_target_urls(self, resolved_ip: str, port: int, path: str) -> List[str]:
        urls = [f"https://{resolved_ip}:{port}{path}"]
        if self._allow_http_fallback:
            urls.append(f"http://{resolved_ip}:{port}{path}")
        return urls

    @staticmethod
    def _is_ip_literal(value: str) -> bool:
        try:
            ipaddress.ip_address(str(value or '').strip())
            return True
        except ValueError:
            return False

    @staticmethod
    def _hostname_resolves_to_ip(hostname: str, expected_ip: str) -> bool:
        try:
            _, _, addresses = socket.gethostbyname_ex(hostname)
            return str(expected_ip) in addresses
        except socket.error:
            return False

    def _build_preferred_target_hosts(self, target: str, resolved_ip: str) -> List[str]:
        hosts: List[str] = []
        normalized_target = str(target or '').strip()
        normalized_ip = str(resolved_ip or '').strip()

        if normalized_target and not self._is_ip_literal(normalized_target):
            hosts.append(normalized_target)

        if self._tls_verify and self._is_ip_literal(normalized_ip):
            try:
                reverse_name = socket.gethostbyaddr(normalized_ip)[0]
                if reverse_name and reverse_name not in hosts and self._hostname_resolves_to_ip(reverse_name, normalized_ip):
                    hosts.append(reverse_name)
            except socket.error:
                pass

        if normalized_ip and normalized_ip not in hosts:
            hosts.append(normalized_ip)

        return hosts

    def _resolve_api_key(self, credentials: Credentials) -> str:
        if credentials and credentials.password:
            return str(credentials.password).strip()
        return self.api_key

    def _build_request_headers(self, credentials: Credentials, path: str, method: str = 'GET', body_raw: bytes = b'') -> Dict[str, str]:
        headers: Dict[str, str] = {'Accept': 'application/json'}
        api_key = self._resolve_api_key(credentials)
        if api_key:
            headers['X-API-Key'] = api_key

        if not self._require_request_signatures:
            return headers

        signing_key = self.request_signing_key or api_key
        if not signing_key:
            return headers

        timestamp = str(int(time.time()))
        nonce = secrets.token_hex(16)
        payload_hash = hashlib.sha256(body_raw or b'').hexdigest()
        signature_message = "\n".join([
            timestamp,
            str(method or 'GET').upper(),
            str(path or '/'),
            payload_hash,
            nonce,
        ]).encode('utf-8')
        signature = hmac.new(
            signing_key.encode('utf-8'),
            signature_message,
            hashlib.sha256,
        ).hexdigest()

        headers['X-Agent-Timestamp'] = timestamp
        headers['X-Agent-Nonce'] = nonce
        headers['X-Agent-Content-SHA256'] = payload_hash
        headers['X-Agent-Signature'] = signature
        return headers

    @staticmethod
    def _normalize_read_only_command(command: str) -> str:
        normalized = str(command or '').strip().lower()
        if normalized.startswith('get '):
            normalized = normalized[4:].strip()
        return normalized

    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        """Test connection to agent API endpoint."""
        if not REQUESTS_AVAILABLE:
            return ConnectionResult(
                success=False,
                message="requests library not available",
                error="Install: pip install requests"
            )

        # SSRF protection: validate target before making request
        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,  # Allow internal network agent connections
        )
        if not is_safe:
            logger.warning(f"SSRF blocked agent connection: {target} - {reason}")
            return ConnectionResult(
                success=False,
                message=f"Target rejected: {reason}",
                error=reason
            )
        api_key = self._resolve_api_key(credentials)
        if self._require_api_key and not api_key:
            return ConnectionResult(
                success=False,
                message="Agent API key is required for direct discovery",
                error="Missing API key",
                details="Provide agent API key in credentials password field or set ASSET_DISCOVERY_AGENT_API_KEY."
            )

        endpoint_path = '/api/system-info'
        last_error = "Connection refused"
        urls: List[str] = []
        for endpoint_host in self._build_preferred_target_hosts(target, resolved_ip):
            urls.extend(self._build_target_urls(endpoint_host, port, endpoint_path))

        for agent_url in urls:
            try:
                headers = self._build_request_headers(credentials, endpoint_path)
                resp = requests.get(agent_url, timeout=timeout, verify=self._tls_verify, headers=headers)

                if resp.status_code == 200:
                    data = resp.json()
                    return ConnectionResult(
                        success=True,
                        message=f"Agent API responding on {target}:{port}",
                        details=f"Agent version: {data.get('version', 'unknown')}",
                        os_info={
                            'hostname': data.get('hostname', target),
                            'os_type': data.get('os_type', 'unknown'),
                            'version': data.get('os_version', 'unknown')
                        }
                    )

                last_error = f"HTTP {resp.status_code}"
            except requests.exceptions.ConnectionError as e:
                last_error = str(e)
                continue
            except requests.exceptions.Timeout:
                last_error = "Timeout"
                continue
            except requests.exceptions.SSLError as e:
                last_error = f"TLS error: {e}"
                continue
            except Exception as e:
                last_error = str(e)
                continue

        return ConnectionResult(
            success=False,
            message=f"Cannot connect to agent on {target}:{port}",
            error=last_error,
            details="Ensure the standalone agent is running with HTTPS enabled and a valid certificate."
        )

    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        """Execute a constrained read-only command via agent API metadata endpoint.

        Security model:
        - No arbitrary shell execution is permitted.
        - Only explicit read-only aliases are accepted.
        - Data is sourced from the existing /api/system-info payload.
        """
        if not REQUESTS_AVAILABLE:
            return ExecutionResult(
                success=False,
                error="requests library not available"
            )

        if not isinstance(command, str) or not command.strip():
            return ExecutionResult(
                success=False,
                error="Command must be a non-empty string"
            )

        if '\x00' in command:
            return ExecutionResult(
                success=False,
                error="Command contains an invalid null byte"
            )

        normalized_command = self._normalize_read_only_command(command)
        field_selector = self._READ_ONLY_COMMAND_MAP.get(normalized_command)
        if not field_selector:
            allowed = ', '.join(sorted(self._READ_ONLY_COMMAND_MAP.keys()))
            return ExecutionResult(
                success=False,
                error=(
                    "Command is not allowed for agent mode. "
                    f"Allowed read-only commands: {allowed}"
                )
            )

        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,
        )
        if not is_safe:
            logger.warning(f"SSRF blocked agent command execution: {target} - {reason}")
            return ExecutionResult(
                success=False,
                error=f"Target rejected: {reason}"
            )

        api_key = self._resolve_api_key(credentials)
        if self._require_api_key and not api_key:
            return ExecutionResult(
                success=False,
                error="Missing API key for direct agent command execution"
            )

        endpoint_path = '/api/system-info'
        urls: List[str] = []
        for endpoint_host in self._build_preferred_target_hosts(target, resolved_ip):
            urls.extend(self._build_target_urls(endpoint_host, port, endpoint_path))

        data = None
        last_error = 'Connection failed'

        for agent_url in urls:
            try:
                headers = self._build_request_headers(credentials, endpoint_path)
                resp = requests.get(agent_url, timeout=timeout, verify=self._tls_verify, headers=headers)

                if resp.status_code != 200:
                    last_error = f"Agent returned HTTP {resp.status_code}"
                    continue

                body = resp.json()
                if isinstance(body, dict):
                    data = body
                    break
                last_error = 'Agent returned invalid JSON payload'
            except requests.exceptions.SSLError as e:
                last_error = f"TLS error: {e}"
                continue
            except requests.exceptions.ConnectionError as e:
                last_error = str(e)
                continue
            except requests.exceptions.Timeout:
                last_error = "Timeout"
                continue
            except Exception as e:
                last_error = str(e)
                continue

        if not isinstance(data, dict):
            return ExecutionResult(success=False, error=last_error)

        if field_selector == 'full':
            selected_payload = data
        elif field_selector == 'hostname':
            selected_payload = data.get('hostname', target)
        else:
            selected_payload = data.get(field_selector)
            if selected_payload is None:
                selected_payload = [] if field_selector in {'packages', 'services', 'storage', 'ports', 'users', 'pending_updates'} else {}

        if isinstance(selected_payload, (dict, list)):
            stdout = json.dumps(selected_payload)
        else:
            stdout = str(selected_payload)

        return ExecutionResult(
            success=True,
            stdout=stdout,
            stderr='',
            return_code=0,
        )

    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        """Perform discovery via agent API."""
        result = DiscoveryResult(success=False, ip_address=target)
        result.connection_method = 'agent'
        result.discovery_tool_label = 'Agent API Discovery'

        if not REQUESTS_AVAILABLE:
            result.error = "requests library not available"
            return result

        # SSRF protection: validate target before making request
        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,  # Allow internal network agent connections
        )
        if not is_safe:
            logger.warning(f"SSRF blocked agent discovery: {target} - {reason}")
            result.error = f"Target rejected: {reason}"
            return result
        api_key = self._resolve_api_key(credentials)
        if self._require_api_key and not api_key:
            result.error = "Missing API key for direct agent discovery"
            return result

        endpoint_path = '/api/system-info'
        urls: List[str] = []
        for endpoint_host in self._build_preferred_target_hosts(target, resolved_ip):
            urls.extend(self._build_target_urls(endpoint_host, port, endpoint_path))
        data = None
        last_error = 'Connection failed'

        for agent_url in urls:
            try:
                headers = self._build_request_headers(credentials, endpoint_path)
                resp = requests.get(agent_url, timeout=60, verify=self._tls_verify, headers=headers)

                if resp.status_code != 200:
                    last_error = f"Agent returned HTTP {resp.status_code}"
                    continue

                data = resp.json()
                break
            except requests.exceptions.SSLError as e:
                last_error = f"TLS error: {e}"
                continue
            except requests.exceptions.ConnectionError as e:
                last_error = str(e)
                continue
            except requests.exceptions.Timeout:
                last_error = "Timeout"
                continue
            except Exception as e:
                last_error = str(e)
                continue

        if not isinstance(data, dict):
            result.error = last_error
            return result

        result.hostname = data.get('hostname', target)
        result.os_type = data.get('os_type', 'unknown')
        result.os_version = data.get('os_version', 'Unknown')
        system_data = data.get('system') if isinstance(data.get('system'), dict) else {}
        result.system = {
            'hostname': result.hostname,
            'fqdn': system_data.get('fqdn') or data.get('fqdn'),
            'domain': system_data.get('domain') or data.get('domain'),
            'os_name': system_data.get('os_name') or result.os_version,
            'os_version': system_data.get('os_version') or result.os_version,
            'os_build': system_data.get('os_build') or data.get('os_build'),
            'kernel_version': system_data.get('kernel_version') or data.get('kernel_version'),
            'architecture': system_data.get('architecture') or data.get('architecture'),
            'manufacturer': system_data.get('manufacturer') or data.get('manufacturer'),
            'model': system_data.get('model') or data.get('model'),
            'serial_number': system_data.get('serial_number') or data.get('serial_number'),
            'product_id': system_data.get('product_id') or data.get('product_id'),
            'asset_tag': system_data.get('asset_tag') or data.get('asset_tag'),
            'product_uuid': system_data.get('product_uuid') or data.get('product_uuid'),
            'cpu_name': system_data.get('cpu_name') or data.get('cpu_name') or data.get('cpu_model'),
            'cpu_cores': system_data.get('cpu_cores') or data.get('cpu_cores'),
            'cpu_logical_processors': system_data.get('cpu_logical_processors') or data.get('cpu_threads'),
            'total_memory_gb': system_data.get('total_memory_gb') or data.get('total_memory_gb'),
            'is_virtual': system_data.get('is_virtual') if 'is_virtual' in system_data else data.get('is_virtual'),
            'hypervisor': system_data.get('hypervisor') or data.get('hypervisor'),
            'last_boot': system_data.get('last_boot') or data.get('last_boot'),
        }
        result.os_build = result.system.get('os_build') or ''

        if scope.get('packages', True):
            result.packages = data.get('packages', [])
        if scope.get('services', True):
            result.services = data.get('services', [])
        if scope.get('storage', True):
            if isinstance(data.get('storage'), list):
                result.storage = data.get('storage', [])
            elif isinstance(data.get('storage'), dict):
                storage_payload = data.get('storage')
                if isinstance(storage_payload.get('drives'), list):
                    result.storage = storage_payload.get('drives', [])
                else:
                    result.storage = [storage_payload]
            elif isinstance(system_data.get('storage'), list):
                result.storage = system_data.get('storage', [])
            elif isinstance(system_data.get('storage'), dict):
                storage_payload = system_data.get('storage')
                if isinstance(storage_payload.get('drives'), list):
                    result.storage = storage_payload.get('drives', [])
                else:
                    result.storage = [storage_payload]
        if scope.get('ports', True):
            result.ports = data.get('open_ports', [])
        if scope.get('updates', True):
            updates_payload = data.get('updates_available')
            result.updates_available, result.pending_updates = normalize_update_payload(
                updates_payload,
                data.get('pending_updates'),
            )
        if scope.get('users', False):
            result.users = data.get('users', [])
        if scope.get('security', True):
            security_payload = data.get('security_info')
            if not isinstance(security_payload, dict):
                security_payload = data.get('security')
            result.security_info = security_payload if isinstance(security_payload, dict) else {}

        result.success = True

        return result


class PortScanExecutor(BaseExecutor):
    """Unauthenticated network discovery using common TCP port probes."""

    _default_scan_ports = [22, 80, 443, 445, 3389, 5985, 5986]
    _default_reachability_probe_ports = [1, 80, 443]
    _scan_profiles = {
        'fast': {
            'ports': [22, 80, 443],
            'connect_timeout_seconds': 1,
            'reachability_probe_ports': [80, 443],
        },
        'standard': {
            'ports': _default_scan_ports,
            'connect_timeout_seconds': 2,
            'reachability_probe_ports': _default_reachability_probe_ports,
        },
        'deep': {
            'ports': [21, 22, 25, 53, 80, 110, 123, 135, 139, 143, 161, 389, 443, 445, 465, 514, 587, 636, 993, 995, 1433, 1521, 2049, 2375, 3306, 3389, 5432, 5900, 5985, 5986, 6379, 8080, 8443, 9200],
            'connect_timeout_seconds': 2,
            'reachability_probe_ports': [1, 22, 80, 443],
        },
    }

    def _resolve_scan_profile(self, scope: Dict[str, bool], preferred_port: Optional[int] = None) -> Dict[str, Any]:
        raw_profile = scope.get('_scan_profile') if isinstance(scope, dict) else {}
        if not isinstance(raw_profile, dict):
            raw_profile = {}

        profile_name = str(raw_profile.get('name', 'standard')).strip().lower() or 'standard'
        base_profile = self._scan_profiles.get(profile_name, self._scan_profiles['standard'])

        ports = raw_profile.get('ports', base_profile.get('ports', self._default_scan_ports))
        if not isinstance(ports, list):
            ports = list(base_profile.get('ports', self._default_scan_ports))

        cleaned_ports: List[int] = []
        for value in ports:
            try:
                port = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= port <= 65535 and port not in cleaned_ports:
                cleaned_ports.append(port)

        if preferred_port and preferred_port > 0 and preferred_port not in cleaned_ports:
            cleaned_ports.insert(0, preferred_port)

        probe_ports = raw_profile.get('reachability_probe_ports', base_profile.get('reachability_probe_ports', self._default_reachability_probe_ports))
        if not isinstance(probe_ports, list):
            probe_ports = list(base_profile.get('reachability_probe_ports', self._default_reachability_probe_ports))

        cleaned_probe_ports: List[int] = []
        for value in probe_ports:
            try:
                port = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= port <= 65535 and port not in cleaned_probe_ports:
                cleaned_probe_ports.append(port)

        timeout_value = raw_profile.get('connect_timeout_seconds', base_profile.get('connect_timeout_seconds', 2))
        try:
            connect_timeout_seconds = max(1, int(timeout_value))
        except (TypeError, ValueError):
            connect_timeout_seconds = 2

        return {
            'name': profile_name if profile_name in self._scan_profiles else 'standard',
            'ports': cleaned_ports or list(self._default_scan_ports),
            'reachability_probe_ports': cleaned_probe_ports or list(self._default_reachability_probe_ports),
            'connect_timeout_seconds': connect_timeout_seconds,
        }

    # ------------------------------------------------------------------
    # Engine selection helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _engine_for_profile(profile: Dict[str, Any]) -> str:
        """Return 'nmap' when nmap is available and the profile requests it,
        otherwise 'tcp_probe'.  The 'deep' profile prefers nmap when available."""
        if not NMAP_AVAILABLE:
            return 'tcp_probe'
        profile_name = profile.get('name', 'standard')
        prefer_nmap = profile.get('use_nmap', profile_name == 'deep')
        return 'nmap' if prefer_nmap else 'tcp_probe'

    @staticmethod
    def _scan_duration_estimate_seconds(profile: Dict[str, Any], target_count: int = 1) -> float:
        """Rough worst-case scan duration estimate in seconds for runtime tradeoff metadata."""
        port_count = len(profile.get('ports', []))
        timeout = profile.get('connect_timeout_seconds', 2)
        engine = PortScanExecutor._engine_for_profile(profile)
        if engine == 'nmap':
            # nmap deep scan: ~0.15 s/port with default timing template T3
            per_port = 0.15
        else:
            per_port = float(timeout)
        return round(per_port * port_count * target_count, 1)

    # ------------------------------------------------------------------
    # Banner capture
    # ------------------------------------------------------------------

    @staticmethod
    def _grab_banner(target: str, port: int, timeout: float = 3.0) -> Optional[str]:
        """Grab a raw service banner by sending an empty byte then reading the
        response.  Returns stripped ASCII text or None on failure.  The banner
        is truncated to 256 characters to prevent memory pressure and log spam."""
        try:
            with socket.create_connection((target, port), timeout=timeout) as sock:
                try:
                    sock.sendall(b"\r\n")
                except OSError:
                    pass
                try:
                    raw = sock.recv(512)
                except OSError:
                    raw = b""
            if not raw:
                return None
            text = raw.decode('ascii', errors='replace').strip()[:256]
            # Strip control characters except tab/newline for safe storage
            text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
            return text or None
        except Exception:
            return None

    # ------------------------------------------------------------------
    # nmap engine
    # ------------------------------------------------------------------

    def _run_nmap(self, target: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Run nmap against *target* using the resolved port list and return a
        dict with keys: open_ports (List[int]), banners (Dict[int,str]),
        engine ('nmap'), nmap_version (str|None), error (str|None).

        Security boundaries preserved:
        - SSRF validation already performed by the caller before this method.
        - Only the port list from the resolved profile is passed to nmap.
        - No shell=True; args are passed as a list to subprocess.
        - stdout/stderr are captured; stdin is devnull.
        - Timeout is enforced at the subprocess level.
        """
        ports_to_scan = profile.get('ports', self._default_scan_ports)
        port_arg = ','.join(str(p) for p in ports_to_scan)
        timeout_ms = int(profile.get('connect_timeout_seconds', 2) * 1000)
        host_timeout_s = max(30, len(ports_to_scan) * 2)

        cmd = [
            _NMAP_BINARY,
            '-sV',                         # service/version detection (banner grab)
            '--version-intensity', '3',    # moderate intensity — not maximum
            '-p', port_arg,
            '--host-timeout', f'{host_timeout_s}s',
            '--open',                       # only show open ports
            '-T4',                          # aggressive timing
            f'--max-rtt-timeout={timeout_ms}ms',
            '-oX', '-',                    # XML output to stdout
            '--', target,                  # explicit end-of-options guard
        ]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                stdin=subprocess.DEVNULL,
                timeout=host_timeout_s + 10,
            )
        except subprocess.TimeoutExpired:
            return {'open_ports': [], 'banners': {}, 'engine': 'nmap', 'nmap_version': None, 'error': 'nmap timed out'}
        except Exception as exc:
            return {'open_ports': [], 'banners': {}, 'engine': 'nmap', 'nmap_version': None, 'error': str(exc)}

        if proc.returncode not in (0, 1):
            # nmap exits 1 when no hosts up — treat as empty result
            err = proc.stderr.decode('ascii', errors='replace')[:256]
            return {'open_ports': [], 'banners': {}, 'engine': 'nmap', 'nmap_version': None, 'error': err or f'nmap rc={proc.returncode}'}

        xml_output = proc.stdout.decode('ascii', errors='replace')
        return self._parse_nmap_xml(xml_output)

    @staticmethod
    def _parse_nmap_xml(xml_text: str) -> Dict[str, Any]:
        """Parse nmap XML output into open_ports + banners dict without an
        external XML library — using regex for lightweight extraction."""
        open_ports: List[int] = []
        banners: Dict[int, str] = []
        nmap_version: Optional[str] = None

        # nmap version from root element
        ver_m = re.search(r'<nmaprun[^>]+version="([^"]+)"', xml_text)
        if ver_m:
            nmap_version = ver_m.group(1)

        # <port protocol="tcp" portid="22"><state state="open"/><service ...product="..." version="..."/>
        port_blocks = re.findall(r'<port\s[^>]*portid="(\d+)"[^>]*>(.*?)</port>', xml_text, re.DOTALL)
        banners_dict: Dict[int, str] = {}
        for portid_str, block in port_blocks:
            state_m = re.search(r'<state\s[^>]*state="([^"]+)"', block)
            if not state_m or state_m.group(1) != 'open':
                continue
            port_num = int(portid_str)
            open_ports.append(port_num)

            svc_m = re.search(r'<service\s([^>]+)>', block)
            if svc_m:
                attrs = svc_m.group(1)
                product = re.search(r'product="([^"]*)"', attrs)
                version = re.search(r'version="([^"]*)"', attrs)
                extra = re.search(r'extrainfo="([^"]*)"', attrs)
                parts = [g.group(1) for g in (product, version, extra) if g and g.group(1)]
                if parts:
                    banners_dict[port_num] = ' '.join(parts)[:256]

        return {
            'open_ports': open_ports,
            'banners': banners_dict,
            'engine': 'nmap',
            'nmap_version': nmap_version,
            'error': None,
        }

    # ------------------------------------------------------------------
    # TCP probe engine with optional banner capture
    # ------------------------------------------------------------------

    def _scan_open_ports(self, target: str, profile: Dict[str, Any]) -> List[int]:
        ports_to_scan = profile.get('ports', self._default_scan_ports)
        timeout_seconds = profile.get('connect_timeout_seconds', 2)
        open_ports: List[int] = []
        for probe_port in ports_to_scan:
            if self._test_port(target, probe_port, timeout=timeout_seconds):
                open_ports.append(probe_port)
        return open_ports

    def _scan_with_banners(self, target: str, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Run the appropriate engine and return open_ports, banners, engine name,
        and scan_engine_metadata for inclusion in the API response."""
        engine = self._engine_for_profile(profile)
        t_start = time.monotonic()

        if engine == 'nmap':
            result = self._run_nmap(target, profile)
        else:
            open_ports = self._scan_open_ports(target, profile)
            timeout = profile.get('connect_timeout_seconds', 2)
            banners: Dict[int, str] = {}
            for p in open_ports:
                banner = self._grab_banner(target, p, timeout=float(timeout))
                if banner:
                    banners[p] = banner
            result = {
                'open_ports': open_ports,
                'banners': banners,
                'engine': 'tcp_probe',
                'nmap_version': None,
                'error': None,
            }

        elapsed = round(time.monotonic() - t_start, 2)
        est = PortScanExecutor._scan_duration_estimate_seconds(profile)
        result['scan_engine_metadata'] = {
            'engine': result.get('engine', engine),
            'nmap_version': result.get('nmap_version'),
            'elapsed_seconds': elapsed,
            'estimated_seconds': est,
            'profile': profile.get('name', 'standard'),
        }
        return result

    def _is_host_reachable(self, target: str, profile: Dict[str, Any]) -> bool:
        """Best-effort host reachability probe without ICMP shell commands."""
        probe_ports = tuple(profile.get('reachability_probe_ports', self._default_reachability_probe_ports))
        timeout_seconds = profile.get('connect_timeout_seconds', 2)
        connection_refused_codes = {errno.ECONNREFUSED, 10061}

        for probe_port in probe_ports:
            try:
                with socket.create_connection((target, probe_port), timeout=timeout_seconds):
                    return True
            except ConnectionRefusedError:
                return True
            except socket.timeout:
                continue
            except OSError as exc:
                if exc.errno in connection_refused_codes:
                    return True
                continue

        return False

    def _reverse_dns(self, target: str) -> str:
        """Return reverse DNS hostname when available, otherwise target."""
        try:
            host, _, _ = socket.gethostbyaddr(target)
            return host or target
        except Exception:
            return target

    def test_connection(self, target: str, port: int, credentials: Credentials, timeout: int = 30) -> ConnectionResult:
        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,
        )
        if not is_safe:
            logger.warning(f"SSRF blocked port_scan connection: {target} - {reason}")
            return ConnectionResult(
                success=False,
                message=f"Target rejected: {reason}",
                error=reason
            )

        profile = self._resolve_scan_profile({}, preferred_port=port)
        open_ports = self._scan_open_ports(resolved_ip, profile)
        if not open_ports and self._is_host_reachable(resolved_ip, profile):
            return ConnectionResult(
                success=True,
                message=f"Host reachable via ICMP: {resolved_ip}",
                details=f"Host responds to ping but no common TCP ports are open on {resolved_ip}"
            )

        if not open_ports:
            return ConnectionResult(
                success=False,
                message=f"No open ports detected on {resolved_ip}",
                error="No open ports detected"
            )

        return ConnectionResult(
            success=True,
            message=f"Host reachable, open ports: {open_ports}",
            details=f"Port scan succeeded for {resolved_ip}"
        )

    def execute_command(self, target: str, port: int, credentials: Credentials,
                       command: str, timeout: int = 60) -> ExecutionResult:
        return ExecutionResult(
            success=False,
            error="Port scan mode does not support remote command execution"
        )

    def discover(self, target: str, port: int, credentials: Credentials,
                 scope: Dict[str, bool]) -> DiscoveryResult:
        result = DiscoveryResult(success=False, ip_address=target)
        result.connection_method = 'port_scan'
        result.discovery_tool_label = 'Network Port Scan'

        is_safe, resolved_ip, reason = validate_scan_target_ssrf(
            target,
            allow_private=True,
        )
        if not is_safe:
            logger.warning(f"SSRF blocked port_scan discovery: {target} - {reason}")
            result.error = f"Target rejected: {reason}"
            return result

        profile = self._resolve_scan_profile(scope, preferred_port=port)
        scan_result = self._scan_with_banners(resolved_ip, profile)
        open_ports = scan_result.get('open_ports', [])
        banners: Dict[int, str] = scan_result.get('banners', {})
        scan_engine_metadata = scan_result.get('scan_engine_metadata', {})
        result.scan_profile = profile.get('name', 'standard')

        host_reachable = self._is_host_reachable(resolved_ip, profile)
        if not open_ports and not host_reachable:
            result.error = "Host unreachable (no ICMP response and no open common TCP ports)"
            return result

        result.success = True
        result.hostname = self._reverse_dns(resolved_ip)
        result.ip_address = resolved_ip
        if any(p in open_ports for p in (3389, 445, 5985, 5986)):
            result.os_type = 'windows'
            result.os_inference_confidence = 0.85
        elif 22 in open_ports:
            result.os_type = 'linux'
            result.os_inference_confidence = 0.75
        else:
            result.os_type = 'unknown'
            result.os_inference_confidence = 0.20 if open_ports else 0.30
        result.os_version = 'Unknown'

        inference_method = 'nmap_service_version' if scan_engine_metadata.get('engine') == 'nmap' else 'port_heuristic'
        result.system = {
            'hostname': result.hostname,
            'os_name': result.os_version,
            'os_version': result.os_version,
            'scan_profile': result.scan_profile,
            'os_inference': {
                'method': inference_method,
                'confidence': result.os_inference_confidence,
                'evidence_ports': open_ports,
            },
            'scan_engine': scan_engine_metadata,
        }

        if scope.get('ports', True):
            result.ports = [
                {
                    'port': p,
                    'protocol': 'tcp',
                    'state': 'open',
                    'banner': banners.get(p),
                }
                for p in open_ports
            ]

        return result


class RemoteExecutor:
    """
    Unified remote executor factory.

    Usage:
        executor = RemoteExecutor.get_executor('ssh')
        result = executor.test_connection(target, port, credentials)
    """

    _executors = {
        'ssh': SSHExecutor,
        'winrm': WinRMExecutor,
        'agent': AgentExecutor,           # Lightweight agent - direct HTTP
        'managed': FleetAgentExecutor,  # Two-way fleet agent - shared data
        'fleet-agent': FleetAgentExecutor,
        'fleet_agent': FleetAgentExecutor,
        'api': AgentExecutor,             # Alias for agent
        'port_scan': PortScanExecutor
    }

    @classmethod
    def get_executor(cls, method: str) -> BaseExecutor:
        """
        Get the appropriate executor for the connection method.

        Args:
            method: Connection method - 'ssh', 'winrm', 'agent', or 'managed'

        Returns:
            Executor instance
        """
        method = method.lower()
        executor_class = cls._executors.get(method)

        if not executor_class:
            raise ValueError(f"Unknown connection method: {method}. Supported: {list(cls._executors.keys())}")

        return executor_class()

    @classmethod
    def test_connection(cls, target: str, method: str, port: Optional[int] = None,
                       credentials: Optional[Dict[str, str]] = None, timeout: int = 30) -> ConnectionResult:
        """
        Convenience method to test connection.

        Args:
            target: Target hostname or IP
            method: Connection method
            port: Port (defaults based on method: SSH=22, WinRM=5985, Agent=8443)
            credentials: Dict with username, password, key_path, domain, auth_method
            timeout: Connection timeout

        Returns:
            ConnectionResult
        """
        # Default ports
        default_ports = {
            'ssh': 22,
            'winrm': 5985,
            'agent': 8443,
            'managed': 8080,
            'fleet-agent': 8080,
            'fleet_agent': 8080,
            'api': 8443,
            'port_scan': 0,
        }
        actual_port = port or default_ports.get(method.lower(), 22)

        # Build credentials
        creds = Credentials(
            username=credentials.get('username', '') if credentials else '',
            password=credentials.get('password', '') if credentials else '',
            key_path=credentials.get('key_path', '') if credentials else '',
            domain=credentials.get('domain', '') if credentials else '',
            auth_method=credentials.get('auth_method', 'password') if credentials else 'password'
        )

        executor = cls.get_executor(method)
        return executor.test_connection(target, actual_port, creds, timeout)

    @classmethod
    def discover(cls, target: str, method: str, port: Optional[int] = None,
                 credentials: Optional[Dict[str, str]] = None,
                 scope: Optional[Dict[str, bool]] = None) -> DiscoveryResult:
        """
        Convenience method to perform discovery.

        Args:
            target: Target hostname or IP
            method: Connection method
            port: Port
            credentials: Connection credentials
            scope: Discovery scope (packages, services, ports, etc.)

        Returns:
            DiscoveryResult
        """
        default_ports = {
            'ssh': 22,
            'winrm': 5985,
            'agent': 8443,
            'managed': 8080,
            'fleet-agent': 8080,
            'fleet_agent': 8080,
            'api': 8443,
            'port_scan': 0,
        }
        actual_port = port or default_ports.get(method.lower(), 22)

        creds = Credentials(
            username=credentials.get('username', '') if credentials else '',
            password=credentials.get('password', '') if credentials else '',
            key_path=credentials.get('key_path', '') if credentials else '',
            domain=credentials.get('domain', '') if credentials else '',
            auth_method=credentials.get('auth_method', 'password') if credentials else 'password'
        )

        default_scope = {
            'packages': True,
            'services': True,
            'ports': True,
            'updates': True,
            'users': False,
            'security': False
        }
        actual_scope = {**default_scope, **(scope or {})}

        executor = cls.get_executor(method)
        return executor.discover(target, actual_port, creds, actual_scope)

    @classmethod
    def get_capabilities(cls) -> Dict[str, Dict[str, Any]]:
        """Get capabilities of each executor."""
        # Check if fleet agents data directory is available
        managed_available = any(os.path.exists(path) for path in FleetAgentExecutor.candidate_agent_dirs())

        return {
            'ssh': {
                'available': PARAMIKO_AVAILABLE,
                'auth_methods': ['password', 'key'],
                'platforms': ['linux', 'unix', 'macos'],
                'default_port': 22,
                'install': 'pip install paramiko',
                'description': 'Direct SSH connection to Linux/Unix servers'
            },
            'winrm': {
                'available': WINRM_AVAILABLE,
                'auth_methods': ['password', 'ntlm', 'kerberos'],
                'platforms': ['windows'],
                'default_port': 5985,
                'install': 'pip install pywinrm',
                'description': 'Direct WinRM connection to Windows servers'
            },
            'agent': {
                'available': REQUESTS_AVAILABLE,
                'auth_methods': ['api_key', 'api_key+signature'],
                'platforms': ['linux', 'windows', 'macos'],
                'default_port': 8443,
                'install': 'pip install requests',
                'description': 'Direct HTTPS to standalone agent /api/system-info endpoint'
            },
            'managed': {
                'available': managed_available,
                'auth_methods': ['none'],
                'platforms': ['linux', 'windows', 'macos'],
                'default_port': 0,  # No direct connection needed
                'install': 'Deploy fleet agent via main toolkit',
                'description': 'Two-way fleet agent - reads from shared agent data'
            },
            'port_scan': {
                'available': True,
                'auth_methods': ['none'],
                'platforms': ['linux', 'windows', 'network-devices'],
                'default_port': 0,
                'install': 'Built-in (socket-based)',
                'description': 'Unauthenticated network discovery using common TCP port probes'
            }
        }
