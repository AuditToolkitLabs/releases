"""Shared risk scoring and routing policy helpers.

Policy is environment-driven so deployments can tune prioritization without code changes.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

RISK_RATING_ORDER = {
    'critical': 0,
    'high': 1,
    'medium': 2,
    'low': 3,
}


def _get_int_env(name: str, default: int, minimum: int = 0) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return max(minimum, int(raw.strip()))
    except (TypeError, ValueError):
        return default


def _get_bool_env(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    value = raw.strip().lower()
    if value in {'1', 'true', 'yes', 'on'}:
        return True
    if value in {'0', 'false', 'no', 'off'}:
        return False
    return default


@lru_cache(maxsize=1)
def get_risk_policy() -> dict[str, Any]:
    """Load deterministic risk policy from environment variables."""
    return {
        # Score thresholds
        'critical_score_threshold': _get_int_env('ASSET_DISCOVERY_RISK_CRITICAL_SCORE', 35, minimum=1),
        'high_score_threshold': _get_int_env('ASSET_DISCOVERY_RISK_HIGH_SCORE', 20, minimum=1),
        'medium_score_threshold': _get_int_env('ASSET_DISCOVERY_RISK_MEDIUM_SCORE', 8, minimum=1),
        # Volume rules
        'critical_count_for_critical': _get_int_env('ASSET_DISCOVERY_RISK_CRITICAL_COUNT_FOR_CRITICAL', 2, minimum=1),
        'high_count_for_high': _get_int_env('ASSET_DISCOVERY_RISK_HIGH_COUNT_FOR_HIGH', 2, minimum=1),
        # Weighting
        'weight_critical': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_CRITICAL', 20, minimum=0),
        'weight_high': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_HIGH', 8, minimum=0),
        'weight_medium': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_MEDIUM', 3, minimum=0),
        'weight_low': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_LOW', 1, minimum=0),
        'weight_kev': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_KEV', 25, minimum=0),
        'weight_external_exposure': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_EXTERNAL_EXPOSURE', 8, minimum=0),
        'weight_posture_fail': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_POSTURE_FAIL', 4, minimum=0),
        'weight_posture_warn': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_POSTURE_WARN', 1, minimum=0),
        # Business context weighting
        'weight_production_context': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_PRODUCTION_CONTEXT', 4, minimum=0),
        'weight_criticality_context': _get_int_env('ASSET_DISCOVERY_RISK_WEIGHT_CRITICALITY_CONTEXT', 4, minimum=0),
        # Rule toggles
        'critical_on_kev': _get_bool_env('ASSET_DISCOVERY_RISK_RULE_CRITICAL_ON_KEV', True),
        'critical_on_exposed_critical': _get_bool_env('ASSET_DISCOVERY_RISK_RULE_CRITICAL_ON_EXPOSED_CRITICAL', True),
        'high_on_exposed_posture': _get_bool_env('ASSET_DISCOVERY_RISK_RULE_HIGH_ON_EXPOSED_POSTURE', True),
        # Routing priorities
        'route_vulnerability_management_immediate_min_rating': os.environ.get(
            'ASSET_DISCOVERY_ROUTE_VULNERABILITY_MANAGEMENT_IMMEDIATE_MIN_RATING',
            'high',
        ).strip().lower(),
        'route_network_exposure_review_immediate_min_rating': os.environ.get(
            'ASSET_DISCOVERY_ROUTE_NETWORK_EXPOSURE_REVIEW_IMMEDIATE_MIN_RATING',
            'critical',
        ).strip().lower(),
        'route_baseline_compliance_immediate_min_rating': os.environ.get(
            'ASSET_DISCOVERY_ROUTE_BASELINE_COMPLIANCE_IMMEDIATE_MIN_RATING',
            'critical',
        ).strip().lower(),
    }


def reset_risk_policy_cache() -> None:
    """Test helper to re-read policy after environment monkeypatching."""
    get_risk_policy.cache_clear()


def rating_meets_or_exceeds(rating: str, minimum_rating: str) -> bool:
    return RISK_RATING_ORDER.get(str(rating or '').lower(), 99) <= RISK_RATING_ORDER.get(str(minimum_rating or '').lower(), 99)


def compute_risk_score(
    *,
    critical: int = 0,
    high: int = 0,
    medium: int = 0,
    low: int = 0,
    kev: int = 0,
    externally_exposed: bool = False,
    posture_failures: int = 0,
    posture_warns: int = 0,
    business_weight: int = 0,
    policy: dict[str, Any] | None = None,
) -> int:
    p = policy or get_risk_policy()
    return (
        int(critical) * int(p['weight_critical'])
        + int(high) * int(p['weight_high'])
        + int(medium) * int(p['weight_medium'])
        + int(low) * int(p['weight_low'])
        + int(kev) * int(p['weight_kev'])
        + (int(p['weight_external_exposure']) if externally_exposed else 0)
        + int(posture_failures) * int(p['weight_posture_fail'])
        + int(posture_warns) * int(p['weight_posture_warn'])
        + int(business_weight)
    )


def compute_risk_rating(
    *,
    risk_score: int,
    kev_count: int,
    critical_count: int,
    high_count: int,
    externally_exposed: bool = False,
    posture_failures: int = 0,
    policy: dict[str, Any] | None = None,
) -> str:
    p = policy or get_risk_policy()

    if (
        (bool(p['critical_on_kev']) and kev_count > 0)
        or (bool(p['critical_on_exposed_critical']) and critical_count > 0 and externally_exposed)
        or risk_score >= int(p['critical_score_threshold'])
        or critical_count >= int(p['critical_count_for_critical'])
    ):
        return 'critical'

    if (
        critical_count > 0
        or high_count >= int(p['high_count_for_high'])
        or (bool(p['high_on_exposed_posture']) and externally_exposed and posture_failures > 0)
        or risk_score >= int(p['high_score_threshold'])
    ):
        return 'high'

    if high_count > 0 or posture_failures > 0 or externally_exposed or risk_score >= int(p['medium_score_threshold']):
        return 'medium'

    return 'low'


def route_priority(route: str, risk_rating: str, *, force_immediate: bool = False, policy: dict[str, Any] | None = None) -> str:
    if force_immediate:
        return 'immediate'

    p = policy or get_risk_policy()
    key = f"route_{route}_immediate_min_rating"
    minimum_rating = str(p.get(key, 'high')).lower()
    return 'immediate' if rating_meets_or_exceeds(risk_rating, minimum_rating) else 'planned'
