"""
Scan Executor Service - Runs discovery scans

Handles:
- Asynchronous scan execution
- Target expansion (CIDR to individual IPs)
- Progress tracking
- Result storage
"""

import logging
import threading
import ipaddress
from datetime import datetime
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from .remote_executor import RemoteExecutor, Credentials
from .posture_evaluator import evaluate_asset_posture

try:
    from .asset_ingestion import upsert_asset_from_discovery
except ImportError as import_error:  # pragma: no cover - defensive runtime fallback
    logger = logging.getLogger(__name__)
    logger.error(f"Asset ingestion module unavailable: {import_error}")

    def upsert_asset_from_discovery(*_args, **_kwargs):
        raise RuntimeError("Asset ingestion module unavailable")

try:
    from ..vulnerability_matcher import update_asset_vulnerabilities
except ImportError as import_error:  # pragma: no cover - defensive runtime fallback
    logger = logging.getLogger(__name__)
    logger.error(f"Vulnerability matcher module unavailable: {import_error}")

    def update_asset_vulnerabilities(*_args, **_kwargs):
        return {'error': 'Vulnerability matcher module unavailable'}

logger = logging.getLogger(__name__)


def normalize_discovery_method(method: str) -> str:
    """Normalize discovery method aliases to canonical values."""
    normalized = str(method or '').strip().lower()
    aliases = {
        'fleet-agent': 'managed',
        'fleet_agent': 'managed',
        'api': 'agent',
    }
    return aliases.get(normalized, normalized)


class ScanExecutor:
    """
    Executes discovery scans across multiple targets.

    Supports concurrent scanning with configurable thread pool.
    """

    def __init__(self, max_workers: int = 10):
        """
        Initialize scan executor.

        Args:
            max_workers: Maximum concurrent scan threads
        """
        self.max_workers = max_workers
        self.active_scans: Dict[int, Dict[str, Any]] = {}

    @staticmethod
    def _normalize_method(method: str) -> str:
        return normalize_discovery_method(method)

    def expand_targets(self, targets: List[str]) -> List[str]:
        """
        Expand CIDR notation to individual IP addresses.

        Args:
            targets: List of targets (hostnames, IPs, or CIDR ranges)

        Returns:
            Expanded list of individual targets
        """
        expanded = []

        for target in targets:
            if '/' in target:
                # Potential CIDR notation
                try:
                    network = ipaddress.ip_network(target, strict=False)
                    # Limit expansion to prevent DoS
                    max_hosts = 256  # /24 equivalent
                    count = 0
                    for ip in network.hosts():
                        if count >= max_hosts:
                            logger.warning(f"CIDR {target} truncated to {max_hosts} hosts")
                            break
                        expanded.append(str(ip))
                        count += 1
                except ValueError:
                    # Not valid CIDR, treat as hostname
                    expanded.append(target)
            else:
                expanded.append(target)

        return list(set(expanded))  # Dedupe

    def execute_scan(
        self,
        scan_id: int,
        targets: List[str],
        method: str,
        credentials: Dict[str, str],
        scope: Dict[str, bool],
        port: int = None,
        scan_profile: Optional[Dict[str, Any]] = None,
        progress_callback=None
    ) -> Dict[str, Any]:
        """
        Execute scan across all targets.

        Args:
            scan_id: Scan job ID
            targets: List of targets to scan
            method: Connection method (ssh, winrm, agent)
            credentials: Connection credentials
            scope: Discovery scope options
            port: Connection port
            progress_callback: Optional callback for progress updates

        Returns:
            Scan results dictionary
        """
        method = self._normalize_method(method)

        # Track active scan
        self.active_scans[scan_id] = {
            'status': 'running',
            'started_at': datetime.utcnow(),
            'total': len(targets),
            'completed': 0,
            'successful': 0,
            'failed': 0,
            'scan_profile': (scan_profile or {}).get('name', 'standard') if isinstance(scan_profile, dict) else 'standard'
        }

        # Expand CIDR ranges
        expanded_targets = self.expand_targets(targets)
        self.active_scans[scan_id]['total'] = len(expanded_targets)

        results = {
            'scan_id': scan_id,
            'targets_scanned': len(expanded_targets),
            'successful': 0,
            'failed': 0,
            'results': []
        }

        # Build credentials object
        creds = Credentials(
            username=credentials.get('username', ''),
            password=credentials.get('password', ''),
            key_path=credentials.get('key_path', ''),
            domain=credentials.get('domain', ''),
            auth_method=credentials.get('auth_method', 'password')
        )

        # Default ports
        default_ports = {'ssh': 22, 'winrm': 5985, 'agent': 8443, 'managed': 8080, 'port_scan': 0}
        actual_port = port or default_ports.get(method, 22)

        def scan_target(target: str) -> Dict[str, Any]:
            """Scan a single target."""
            try:
                executor = RemoteExecutor.get_executor(method)

                # First test connection
                conn_result = executor.test_connection(target, actual_port, creds, timeout=30)

                if not conn_result.success:
                    return {
                        'target': target,
                        'success': False,
                        'error': conn_result.error or conn_result.message,
                        'connection_tested': True
                    }

                # Perform discovery
                effective_scope = dict(scope) if isinstance(scope, dict) else {}
                if isinstance(scan_profile, dict):
                    effective_scope['_scan_profile'] = scan_profile
                discovery_result = executor.discover(target, actual_port, creds, effective_scope)

                return {
                    'target': target,
                    'success': discovery_result.success,
                    'hostname': discovery_result.hostname,
                    'os_type': discovery_result.os_type,
                    'scan_profile': discovery_result.scan_profile,
                    'os_inference_confidence': discovery_result.os_inference_confidence,
                    'os_version': discovery_result.os_version,
                    'packages_count': len(discovery_result.packages),
                    'services_count': len(discovery_result.services),
                    'ports_count': len(discovery_result.ports),
                    'updates_available': discovery_result.updates_available,
                    'error': discovery_result.error,
                    'data': discovery_result.to_dict() if discovery_result.success else None
                }

            except Exception as e:
                logger.error(f"Error scanning {target}: {e}")
                return {
                    'target': target,
                    'success': False,
                    'error': str(e)
                }

        # Execute scans concurrently
        effective_max_workers = self.max_workers
        if isinstance(scan_profile, dict):
            try:
                profile_concurrency = int(scan_profile.get('max_concurrent_targets', 0) or 0)
            except (TypeError, ValueError):
                profile_concurrency = 0
            if profile_concurrency > 0:
                effective_max_workers = min(max(profile_concurrency, 1), 64)

        with ThreadPoolExecutor(max_workers=effective_max_workers) as executor:
            future_to_target = {
                executor.submit(scan_target, target): target
                for target in expanded_targets
            }

            for future in as_completed(future_to_target):
                target = future_to_target[future]
                try:
                    result = future.result(timeout=180)  # 3 min timeout per target
                    results['results'].append(result)

                    if result.get('success'):
                        results['successful'] += 1
                        self.active_scans[scan_id]['successful'] += 1
                    else:
                        results['failed'] += 1
                        self.active_scans[scan_id]['failed'] += 1

                except Exception as e:
                    logger.error(f"Scan future failed for {target}: {e}")
                    results['results'].append({
                        'target': target,
                        'success': False,
                        'error': str(e)
                    })
                    results['failed'] += 1
                    self.active_scans[scan_id]['failed'] += 1

                # Update progress
                self.active_scans[scan_id]['completed'] += 1
                if progress_callback:
                    progress_callback(
                        scan_id,
                        self.active_scans[scan_id]['completed'],
                        self.active_scans[scan_id]['total']
                    )

        # Update status
        self.active_scans[scan_id]['status'] = 'completed'
        self.active_scans[scan_id]['completed_at'] = datetime.utcnow()

        return results

    def get_scan_progress(self, scan_id: int) -> Optional[Dict[str, Any]]:
        """Get progress of an active scan."""
        return self.active_scans.get(scan_id)

    def cancel_scan(self, scan_id: int) -> bool:
        """
        Cancel an active scan.

        Note: This is a soft cancel - already running scans will complete.
        """
        if scan_id in self.active_scans:
            self.active_scans[scan_id]['status'] = 'cancelled'
            return True
        return False


class ScanWorker:
    """
    Background worker for processing scan jobs.

    Runs as a daemon thread, polling for pending scans.
    """

    def __init__(self, db_session_factory, poll_interval: int = 5):
        """
        Initialize scan worker.

        Args:
            db_session_factory: Factory function for database sessions
            poll_interval: Seconds between polling for new scans
        """
        self.db_session_factory = db_session_factory
        self.poll_interval = poll_interval
        self.executor = ScanExecutor()
        self.running = False
        self._thread = None

    def start(self):
        """Start the background worker thread."""
        if self.running:
            return

        self.running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("Scan worker started")

    def stop(self):
        """Stop the background worker."""
        self.running = False
        if self._thread:
            self._thread.join(timeout=10)
        logger.info("Scan worker stopped")

    def _run(self):
        """Main worker loop."""
        import time

        while self.running:
            try:
                self._process_pending_scans()
            except Exception as e:
                logger.error(f"Scan worker error: {e}")

            time.sleep(self.poll_interval)

    def _run_asset_vulnerability_rematch(self, asset_ids: List[int]):
        """Run vulnerability re-match for newly ingested assets."""
        unique_asset_ids = sorted(set(asset_ids))
        if not unique_asset_ids:
            return {
                'assets_total': 0,
                'assets_processed': 0,
                'assets_failed': 0,
                'total_new_vulnerabilities': 0,
                'total_vulnerabilities': 0,
                'errors': []
            }

        summary = {
            'assets_total': len(unique_asset_ids),
            'assets_processed': 0,
            'assets_failed': 0,
            'total_new_vulnerabilities': 0,
            'total_vulnerabilities': 0,
            'errors': []
        }

        for asset_id in unique_asset_ids:
            try:
                with self.db_session_factory() as rematch_session:
                    stats = update_asset_vulnerabilities(asset_id, rematch_session)
                    if isinstance(stats, dict) and stats.get('error'):
                        summary['assets_failed'] += 1
                        summary['errors'].append({'asset_id': asset_id, 'error': stats.get('error')})
                        logger.warning(
                            "Vulnerability rematch skipped for asset %s: %s",
                            asset_id,
                            stats.get('error')
                        )
                    else:
                        summary['assets_processed'] += 1
                        summary['total_new_vulnerabilities'] += int(stats.get('new_vulnerabilities', 0))
                        summary['total_vulnerabilities'] += int(stats.get('total_vulnerabilities', 0))
                        logger.info(
                            "Vulnerability rematch completed for asset %s: %s new, %s total",
                            asset_id,
                            stats.get('new_vulnerabilities', 0),
                            stats.get('total_vulnerabilities', 0)
                        )
            except Exception as rematch_error:
                summary['assets_failed'] += 1
                summary['errors'].append({'asset_id': asset_id, 'error': str(rematch_error)})
                logger.error(
                    "Vulnerability rematch failed for asset %s: %s",
                    asset_id,
                    rematch_error
                )

        return summary

    def _set_scan_correlation_status(
        self,
        scan,
        *,
        status: str,
        requested: bool,
        reason: str = None,
        error: str = None,
        stats: Dict[str, Any] = None,
        started_at: datetime = None,
        completed_at: datetime = None,
    ):
        """Persist vulnerability correlation lifecycle state on scan config."""
        config = dict(scan.config) if isinstance(scan.config, dict) else {}
        existing = config.get('vulnerability_correlation') if isinstance(config.get('vulnerability_correlation'), dict) else {}

        payload = dict(existing)
        payload['source'] = 'scan'
        payload['requested'] = bool(requested)
        payload['status'] = status

        if started_at:
            payload['started_at'] = started_at.isoformat()
        if completed_at:
            payload['completed_at'] = completed_at.isoformat()
        if stats is not None:
            payload['stats'] = stats

        if reason:
            payload['reason'] = reason
        else:
            payload.pop('reason', None)

        if error:
            payload['error'] = error
        else:
            payload.pop('error', None)

        config['vulnerability_correlation'] = payload
        scan.config = config

    def _set_scan_posture_status(
        self,
        scan,
        *,
        status: str,
        requested: bool,
        reason: str = None,
        error: str = None,
        summary: Dict[str, Any] = None,
        started_at: datetime = None,
        completed_at: datetime = None,
    ):
        """Persist posture evaluation lifecycle state on scan config."""
        config = dict(scan.config) if isinstance(scan.config, dict) else {}
        existing = config.get('posture_evaluation') if isinstance(config.get('posture_evaluation'), dict) else {}

        payload = dict(existing)
        payload['source'] = 'posture_evaluator_v1'
        payload['requested'] = bool(requested)
        payload['status'] = status

        if started_at:
            payload['started_at'] = started_at.isoformat()
        if completed_at:
            payload['completed_at'] = completed_at.isoformat()
        if summary is not None:
            payload['summary'] = summary

        if reason:
            payload['reason'] = reason
        else:
            payload.pop('reason', None)

        if error:
            payload['error'] = error
        else:
            payload.pop('error', None)

        config['posture_evaluation'] = payload
        scan.config = config

    def _process_pending_scans(self):
        """Process any pending scan jobs."""
        from ..models.scan import ScanJob, ScanResult, ScanCredential

        try:
            with self.db_session_factory() as session:
                # Find pending scans
                pending = session.query(ScanJob).filter(
                    ScanJob.status == 'pending'
                ).order_by(ScanJob.created_at).first()

                if not pending:
                    return

                logger.info(f"Processing scan job {pending.id}")

                config = pending.config or {}
                scope = config.get('scope', {
                    'packages': True,
                    'services': True,
                    'ports': True,
                    'updates': True
                })
                auto_vulnerability_rematch = bool(config.get('auto_vulnerability_rematch', True))
                posture_requested = bool(config.get('posture_evaluation_enabled', True))
                is_discovery_job = str(pending.job_type or '').lower() in ('discovery', 'full')
                correlation_requested = bool(scope.get('packages', True)) and (
                    auto_vulnerability_rematch or is_discovery_job
                )

                # Mark as running
                pending.status = 'running'
                pending.started_at = datetime.utcnow()
                if correlation_requested:
                    self._set_scan_correlation_status(
                        pending,
                        status='queued',
                        requested=True,
                        reason='awaiting_scan_completion'
                    )
                else:
                    self._set_scan_correlation_status(
                        pending,
                        status='not_requested',
                        requested=False,
                        reason='packages_scope_disabled_or_auto_rematch_off'
                    )

                if posture_requested:
                    self._set_scan_posture_status(
                        pending,
                        status='queued',
                        requested=True,
                        reason='awaiting_scan_completion'
                    )
                else:
                    self._set_scan_posture_status(
                        pending,
                        status='not_requested',
                        requested=False,
                        reason='disabled_by_scan_config'
                    )
                session.commit()

                # Get scan config
                config = pending.config or {}
                method = config.get('discovery_method', 'ssh')
                credential_metadata = config.get('credential_metadata', {})
                credential_id = config.get('credential_id')
                runtime_credentials = config.get('runtime_credentials', {})
                if not isinstance(runtime_credentials, dict):
                    runtime_credentials = {}
                port = credential_metadata.get('port')
                scan_profile_name = str(config.get('scan_profile', 'standard')).strip().lower() or 'standard'
                scan_overrides = config.get('scan_overrides', {}) if isinstance(config.get('scan_overrides'), dict) else {}
                execution_scan_profile = {'name': scan_profile_name, **scan_overrides}

                rematch_asset_ids: List[int] = []

                actual_creds = {
                    'username': runtime_credentials.get('username', ''),
                    'password': runtime_credentials.get('password', ''),
                    'key_path': runtime_credentials.get('key_path', ''),
                    'domain': runtime_credentials.get('domain', ''),
                    'auth_method': runtime_credentials.get('auth_method', credential_metadata.get('auth_method', 'password'))
                }

                if port is None:
                    runtime_port = runtime_credentials.get('port')
                    if runtime_port is not None:
                        try:
                            port = int(runtime_port)
                        except (TypeError, ValueError):
                            port = None

                if credential_id is None and method in ('ssh', 'winrm'):
                    auto_username = str(runtime_credentials.get('username') or '').strip()
                    auto_auth_method = str(runtime_credentials.get('auth_method') or 'password').strip().lower()
                    auto_password = runtime_credentials.get('password')
                    auto_key_path = runtime_credentials.get('key_path')
                    can_store_auto_credential = bool(auto_username) and (
                        (auto_auth_method == 'key' and str(auto_key_path or '').strip()) or
                        (auto_auth_method in ('password', 'kerberos') and str(auto_password or '').strip())
                    )

                    if can_store_auto_credential:
                        try:
                            credential_type = 'ssh_key' if auto_auth_method == 'key' else 'ssh_password'
                            if method == 'winrm':
                                credential_type = 'windows_domain' if str(runtime_credentials.get('domain') or '').strip() else 'windows_local'

                            auto_credential = ScanCredential(
                                name=f"Auto {method.upper()} {auto_username}",
                                description=f"Auto-saved from discovery scan #{pending.id}",
                                credential_type=credential_type,
                                username=auto_username,
                                domain=str(runtime_credentials.get('domain') or '').strip() or None,
                                port=port,
                                is_default=False,
                                created_by=f"scan:{pending.id}",
                            )
                            if auto_auth_method == 'key':
                                auto_credential.set_ssh_key(str(auto_key_path or '').strip())
                            else:
                                auto_credential.set_password(str(auto_password or ''))

                            session.add(auto_credential)
                            session.flush()
                            credential_id = auto_credential.id

                            updated_config = dict(pending.config or {})
                            updated_config['credential_id'] = credential_id
                            updated_config['credential_metadata'] = {
                                **dict(credential_metadata or {}),
                                'auth_method': auto_auth_method,
                                'port': port,
                                'has_password': bool(str(auto_password or '').strip()),
                                'has_key': bool(str(auto_key_path or '').strip()),
                                'has_username': bool(auto_username),
                                'auto_saved': True,
                            }
                            pending.config = updated_config
                            credential_metadata = updated_config.get('credential_metadata', {})
                            session.commit()
                            logger.info("Auto-saved scan credential for scan %s as credential_id=%s", pending.id, credential_id)
                        except Exception as auto_cred_error:
                            logger.warning("Unable to auto-save runtime credential for scan %s: %s", pending.id, auto_cred_error)

                if credential_id is not None:
                    credential = session.query(ScanCredential).filter(ScanCredential.id == credential_id).first()
                    if credential:
                        actual_creds['username'] = credential.username or ''
                        actual_creds['domain'] = credential.domain or ''
                        if credential.port:
                            port = credential.port
                        if credential.credential_type == 'ssh_key':
                            actual_creds['auth_method'] = 'key'
                            actual_creds['key_path'] = credential.get_ssh_key() or ''
                        else:
                            actual_creds['auth_method'] = 'password'
                            actual_creds['password'] = credential.get_password() or ''
                    else:
                        logger.warning(f"Scan job {pending.id} references missing credential_id={credential_id}")

                # Execute scan
                results = self.executor.execute_scan(
                    scan_id=pending.id,
                    targets=pending.targets,
                    method=method,
                    credentials=actual_creds,
                    scope=scope,
                    port=port,
                    scan_profile=execution_scan_profile,
                )

                # Store results
                pending.status = 'completed'
                pending.completed_at = datetime.utcnow()
                pending.total_targets = results['targets_scanned']
                pending.successful_targets = results['successful']
                pending.failed_targets = results['failed']

                # Scrub any runtime credential payload once scan is complete.
                if isinstance(pending.config, dict) and 'runtime_credentials' in pending.config:
                    sanitized_config = dict(pending.config)
                    sanitized_config.pop('runtime_credentials', None)
                    pending.config = sanitized_config

                # Create scan results and update/create assets
                posture_started_at = datetime.utcnow() if posture_requested else None
                posture_summary = {
                    'assets_evaluated': 0,
                    'checks_total': 0,
                    'pass': 0,  # nosec B105 - posture metric key, not a credential
                    'warn': 0,
                    'fail': 0,
                    'errors': [],
                }
                for result_data in results['results']:
                    if posture_requested and result_data.get('success') and isinstance(result_data.get('data'), dict):
                        try:
                            evaluation = evaluate_asset_posture(
                                result_data['data'],
                                target=str(result_data.get('target') or ''),
                                method=normalize_discovery_method(result_data.get('connection_method') or method or ''),
                            )
                            result_data['posture_evaluation'] = evaluation
                            result_data['data']['posture_evaluation'] = evaluation

                            summary = evaluation.get('summary') if isinstance(evaluation.get('summary'), dict) else {}
                            posture_summary['assets_evaluated'] += 1
                            posture_summary['checks_total'] += int(summary.get('checks_total', 0) or 0)
                            posture_summary['pass'] += int(summary.get('pass', 0) or 0)
                            posture_summary['warn'] += int(summary.get('warn', 0) or 0)
                            posture_summary['fail'] += int(summary.get('fail', 0) or 0)
                        except Exception as posture_error:
                            logger.warning(
                                "Posture evaluation failed for scan %s target %s: %s",
                                pending.id,
                                result_data.get('target'),
                                posture_error,
                            )
                            posture_summary['errors'].append({
                                'target': result_data.get('target'),
                                'error': str(posture_error),
                            })

                    # Create scan result
                    scan_result = ScanResult(
                        scan_job_id=pending.id,
                        target=result_data['target'],
                        status='success' if result_data['success'] else 'failed',
                        raw_output=result_data,
                        completed_at=datetime.utcnow()
                    )
                    if not result_data['success']:
                        scan_result.error_message = result_data.get('error')
                    session.add(scan_result)

                    # Create/update asset if scan was successful
                    if result_data.get('success') and result_data.get('data'):
                        data = result_data['data']
                        if isinstance(data, dict):
                            if method == 'port_scan':
                                data['_preserve_existing_inventory'] = True
                            if result_data.get('hostname') and not data.get('hostname'):
                                data['hostname'] = result_data.get('hostname')
                            if result_data.get('os_type') and not data.get('os_type'):
                                data['os_type'] = result_data.get('os_type')
                            if result_data.get('os_version') and not data.get('os_version'):
                                data['os_version'] = result_data.get('os_version')
                        try:
                            asset = upsert_asset_from_discovery(
                                session,
                                data,
                                fallback_ip=result_data.get('target')
                            )
                            current_attributes = dict(asset.custom_attributes or {})
                            persisted_method = normalize_discovery_method(result_data.get('connection_method') or method or '')
                            current_attributes['last_scan_profile'] = {
                                'discovery_method': persisted_method,
                                'discovery_mode': str(config.get('discovery_mode') or '').lower() or (
                                    'network' if persisted_method == 'port_scan' else
                                    'managed' if persisted_method in ('managed', 'agent') else
                                    'authenticated'
                                ),
                                'scan_profile': str(config.get('scan_profile', 'standard')).strip().lower() or 'standard',
                                'credential_id': credential_id,
                                'port': port,
                                'os_type': config.get('os_type') or result_data.get('os_type') or asset.os_type,
                                'scope': scope,
                                'updated_at': datetime.utcnow().isoformat(),
                            }
                            asset.custom_attributes = current_attributes
                            scan_result.asset_id = asset.id
                            if correlation_requested:
                                rematch_asset_ids.append(asset.id)
                        except Exception as ingest_error:
                            logger.error(
                                f"Asset ingestion failed for scan {pending.id} target "
                                f"{result_data.get('target')}: {ingest_error}"
                            )

                session.commit()
                logger.info(f"Scan job {pending.id} completed: {results['successful']} successful, {results['failed']} failed")

                if posture_requested:
                    self._set_scan_posture_status(
                        pending,
                        status='failed' if posture_summary.get('errors') else 'completed',
                        requested=True,
                        started_at=posture_started_at,
                        completed_at=datetime.utcnow(),
                        summary=posture_summary,
                        reason='completed_with_errors' if posture_summary.get('errors') else 'completed',
                        error='; '.join(
                            err.get('error', '')
                            for err in posture_summary.get('errors', [])
                            if err.get('error')
                        ) if posture_summary.get('errors') else None,
                    )
                    session.commit()

                if correlation_requested:
                    if rematch_asset_ids:
                        rematch_started_at = datetime.utcnow()
                        self._set_scan_correlation_status(
                            pending,
                            status='in_progress',
                            requested=True,
                            started_at=rematch_started_at,
                            reason='vulnerability_correlation_running'
                        )
                        session.commit()

                        rematch_summary = self._run_asset_vulnerability_rematch(rematch_asset_ids)
                        rematch_completed_at = datetime.utcnow()
                        rematch_failed = bool(rematch_summary.get('errors'))

                        self._set_scan_correlation_status(
                            pending,
                            status='failed' if rematch_failed else 'completed',
                            requested=True,
                            completed_at=rematch_completed_at,
                            stats=rematch_summary,
                            reason='completed_with_errors' if rematch_failed else 'completed',
                            error='; '.join(
                                err.get('error', '')
                                for err in rematch_summary.get('errors', [])
                                if err.get('error')
                            ) if rematch_failed else None
                        )
                        session.commit()
                    else:
                        self._set_scan_correlation_status(
                            pending,
                            status='completed',
                            requested=True,
                            completed_at=datetime.utcnow(),
                            reason='no_assets_eligible',
                            stats={
                                'assets_total': 0,
                                'assets_processed': 0,
                                'assets_failed': 0,
                                'total_new_vulnerabilities': 0,
                                'total_vulnerabilities': 0,
                                'errors': []
                            }
                        )
                        session.commit()

                sync_to_audit_tool = bool(config.get('sync_to_audit_tool', True))
                if sync_to_audit_tool and pending.status == 'completed':
                    sync_payload = {
                        'requested': True,
                        'status': 'queued',
                        'completed_at': None,
                        'synced_count': 0,
                        'created_count': 0,
                        'updated_count': 0,
                        'failed_count': 0,
                        'errors': [],
                    }

                    try:
                        from ..sync_service import get_sync_service

                        sync_result = get_sync_service().sync_scan_complete(pending.id)
                        sync_payload.update({
                            'status': 'completed' if sync_result.success else 'failed',
                            'completed_at': datetime.utcnow().isoformat(),
                            'synced_count': int(sync_result.synced_count or 0),
                            'created_count': int(sync_result.created_count or 0),
                            'updated_count': int(sync_result.updated_count or 0),
                            'failed_count': int(sync_result.failed_count or 0),
                            'errors': list(sync_result.errors or [])[:10],
                        })
                    except Exception as sync_error:
                        logger.error("Audit tool sync failed for scan %s: %s", pending.id, sync_error)
                        sync_payload.update({
                            'status': 'failed',
                            'completed_at': datetime.utcnow().isoformat(),
                            'errors': [str(sync_error)],
                        })

                    updated_config = dict(pending.config or {})
                    updated_config['audit_tool_sync'] = sync_payload
                    pending.config = updated_config
                    session.commit()

        except Exception as e:
            logger.error(f"Error processing scan: {e}")
            # Try to mark scan as failed
            try:
                with self.db_session_factory() as session:
                    pending_id = pending.id if 'pending' in locals() and pending is not None else None
                    if pending_id is None:
                        return

                    scan = session.query(ScanJob).filter(ScanJob.id == pending_id).first()
                    if scan:
                        scan.status = 'failed'
                        scan.completed_at = datetime.utcnow()
                        self._set_scan_correlation_status(
                            scan,
                            status='failed',
                            requested=True,
                            completed_at=datetime.utcnow(),
                            reason='scan_failed_before_correlation',
                            error=str(e)
                        )
                        if isinstance(scan.config, dict):
                            existing_posture = scan.config.get('posture_evaluation') if isinstance(scan.config.get('posture_evaluation'), dict) else {}
                            if existing_posture.get('requested'):
                                self._set_scan_posture_status(
                                    scan,
                                    status='failed',
                                    requested=True,
                                    completed_at=datetime.utcnow(),
                                    reason='scan_failed_before_posture_completion',
                                    error=str(e)
                                )
                        if isinstance(scan.config, dict) and 'runtime_credentials' in scan.config:
                            sanitized_config = dict(scan.config)
                            sanitized_config.pop('runtime_credentials', None)
                            scan.config = sanitized_config
                        session.commit()
            except Exception as sync_error:  # noqa: BLE001 - Best effort database update
                logger.debug("Best-effort scan finalization update failed for scan %s: %s", scan.id, sync_error)


# Global worker instance
_scan_worker: Optional[ScanWorker] = None


def get_scan_worker() -> Optional[ScanWorker]:
    """Get the global scan worker instance."""
    return _scan_worker


def start_scan_worker(db_session_factory):
    """Start the global scan worker."""
    global _scan_worker
    if _scan_worker is None:
        _scan_worker = ScanWorker(db_session_factory)
        _scan_worker.start()
    return _scan_worker


def stop_scan_worker():
    """Stop the global scan worker."""
    global _scan_worker
    if _scan_worker:
        _scan_worker.stop()
        _scan_worker = None
