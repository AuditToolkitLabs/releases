from __future__ import annotations

from typing import Any, Dict, List, Tuple


def _clean_update_item(raw_item: Any) -> Dict[str, Any] | None:
    """Return sanitized update item dict or None when invalid."""
    if not isinstance(raw_item, dict):
        return None

    name = str(raw_item.get('name') or '').strip()
    if not name:
        return None

    cleaned: Dict[str, Any] = {'name': name}

    for field_name in (
        'current_version',
        'new_version',
        'kb',
        'update_id',
        'revision_number',
        'publisher',
        'source',
    ):
        value = raw_item.get(field_name)
        if value is None:
            continue
        text_value = str(value).strip()
        if text_value:
            cleaned[field_name] = text_value

    return cleaned


def normalize_update_payload(
    updates_available: Any,
    pending_updates: Any,
) -> Tuple[int, List[Dict[str, Any]]]:
    """Normalize update payload into a consistent schema.

    Contract:
    - `updates_available` is always an integer >= 0
    - `pending_updates` is always a list of dicts with at least `name`
    - if `pending_updates` has entries, count equals list length
    """
    normalized_updates: List[Dict[str, Any]] = []

    if isinstance(pending_updates, list):
        for raw_item in pending_updates:
            cleaned = _clean_update_item(raw_item)
            if cleaned is not None:
                normalized_updates.append(cleaned)

    if normalized_updates:
        return len(normalized_updates), normalized_updates

    if isinstance(updates_available, list):
        for raw_item in updates_available:
            cleaned = _clean_update_item(raw_item)
            if cleaned is not None:
                normalized_updates.append(cleaned)
        if normalized_updates:
            return len(normalized_updates), normalized_updates
        return len(updates_available), []

    try:
        normalized_count = int(updates_available or 0)
    except (TypeError, ValueError):
        normalized_count = 0

    return max(0, normalized_count), []
