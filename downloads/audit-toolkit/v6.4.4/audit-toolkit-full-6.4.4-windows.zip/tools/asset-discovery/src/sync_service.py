# Asset Discovery - Cross-Tool Sync Service (Direct SQL)
"""
Cross-Tool Sync Service - Direct SQL Implementation

Synchronizes data between Asset Discovery and the main Security Audit Toolkit
using direct SQL operations since both tools share the same PostgreSQL database.

Features:
- Direct SQL sync of assets to servers table (~10-40x faster than HTTP)
- Sync vulnerability data and scan results
- No network overhead - same database connection
- Atomic transactions for data consistency

Performance Note:
- HTTP sync: ~50-200ms per request
- Direct SQL: ~1-5ms per query

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from urllib.parse import quote

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    requests = None
    REQUESTS_AVAILABLE = False

from sqlalchemy import text, table as sql_table, column, delete, bindparam
from sqlalchemy.exc import IntegrityError

from .models.base import session_scope, main_toolkit_session_scope
from .models.asset import Asset
from .models.scan import ScanJob, ScanResult

logger = logging.getLogger(__name__)


@dataclass
class SyncConfig:
    """Configuration for cross-tool sync."""
    sync_enabled: bool = True
    sync_assets: bool = True
    sync_vulnerabilities: bool = True
    sync_on_scan_complete: bool = True
    trigger_audit_on_new_asset: bool = False
    auto_create_servers: bool = True


@dataclass
class SyncResult:
    """Result of a sync operation."""
    success: bool
    synced_count: int = 0
    failed_count: int = 0
    created_count: int = 0
    updated_count: int = 0
    errors: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)


class AuditToolSyncService:
    """
    Synchronizes Asset Discovery data with the main Security Audit Toolkit.

    Uses direct SQL operations since both tools share the same PostgreSQL database.
    This eliminates HTTP overhead and provides ~10-40x faster sync operations.
    """

    def __init__(self, config: Optional[SyncConfig] = None):
        """Initialize sync service with optional config."""
        self.config = config or self._load_config()

    def _load_config(self) -> SyncConfig:
        """Load sync configuration from environment variables and defaults."""
        import os
        return SyncConfig(
            sync_enabled=os.environ.get('SYNC_ENABLED', 'true').lower() == 'true',
            sync_assets=os.environ.get('SYNC_ASSETS', 'true').lower() == 'true',
            sync_vulnerabilities=os.environ.get('SYNC_VULNERABILITIES', 'true').lower() == 'true',
            sync_on_scan_complete=os.environ.get('SYNC_ON_SCAN_COMPLETE', 'true').lower() == 'true',
            trigger_audit_on_new_asset=os.environ.get('TRIGGER_AUDIT_ON_NEW_ASSET', 'false').lower() == 'true',
            auto_create_servers=os.environ.get('AUTO_CREATE_SERVERS', 'true').lower() == 'true',
        )

    @staticmethod
    def _asset_sync_marker(asset_id: int) -> str:
        """Stable marker embedded in synced server descriptions."""
        return f"[asset-discovery:asset-id={asset_id}]"

    def _build_synced_server_description(self, asset: Asset) -> str:
        """Build canonical description used for synced server records."""
        base = f"Discovered by Asset Discovery on {asset.first_seen}"
        return f"{base} {self._asset_sync_marker(asset.id)}"

    def check_connection(self) -> Tuple[bool, str]:
        """Check if the main toolkit database is reachable (same PostgreSQL server, audittoolkit database)."""
        try:
            with main_toolkit_session_scope() as session:
                # Test query to servers table in the main toolkit database
                result = session.execute(text("SELECT COUNT(*) FROM servers"))
                count = result.scalar()
                return True, f"Connected to shared database ({count} servers)"
        except Exception as e:
            logger.error(f"Database connection check failed: {e}")
            return False, f"Database error: {str(e)}"

    def sync_asset_to_server(self, asset: Asset) -> SyncResult:
        """
        Sync a single asset to the servers table using direct SQL.

        Creates a new server or updates existing one based on hostname/IP.
        ~10-40x faster than HTTP-based sync.
        """
        result = SyncResult(success=False)

        if not self.config.sync_enabled or not self.config.sync_assets:
            result.errors.append("Asset sync is disabled")
            return result

        try:
            with main_toolkit_session_scope() as session:
                # Check if server exists by hostname or name
                server_name = asset.hostname or asset.primary_ip
                existing = session.execute(
                    text("SELECT id FROM servers WHERE hostname = :hostname OR name = :name LIMIT 1"),
                    {"hostname": asset.fqdn or asset.hostname, "name": server_name}
                ).fetchone()

                # Map asset to server fields
                connection_method = 'ssh' if asset.os_type != 'windows' else 'winrm'
                elevation_method = asset.elevation_method or ('sudo' if asset.os_type != 'windows' else 'runas')
                asset_tags = []
                if isinstance(asset.tags, list):
                    asset_tags = [str(t).strip() for t in asset.tags if str(t).strip()]
                elif isinstance(asset.tags, str) and asset.tags.strip():
                    asset_tags = [t.strip() for t in asset.tags.split(',') if t.strip()]

                if 'asset_discovery' not in asset_tags:
                    asset_tags.append('asset_discovery')
                marker_tag = f"asset_discovery_asset_id:{asset.id}"
                if marker_tag not in asset_tags:
                    asset_tags.append(marker_tag)

                tags_json = ','.join(asset_tags)
                synced_description = self._build_synced_server_description(asset)
                now = datetime.utcnow()

                if existing:
                    # Update existing server
                    session.execute(
                        text("""
                            UPDATE servers SET
                                hostname = :hostname,
                                description = :description,
                                tags = :tags,
                                elevation_method = :elevation_method,
                                jea_endpoint = :jea_endpoint,
                                execution_mode = :execution_mode,
                                updated_at = :updated_at
                            WHERE id = :id
                        """),
                        {
                            "id": existing[0],
                            "hostname": asset.fqdn or asset.hostname,
                            "description": synced_description,
                            "tags": tags_json,
                            "elevation_method": elevation_method,
                            "jea_endpoint": asset.jea_endpoint if asset.elevation_method == 'jea' else None,
                            "execution_mode": asset.execution_mode or 'stream',
                            "updated_at": now
                        }
                    )
                    session.commit()
                    result.success = True
                    result.updated_count = 1
                    result.details['server_id'] = existing[0]
                    result.details['action'] = 'updated'
                    logger.info(f"Updated server {existing[0]} from asset {asset.id}")

                elif self.config.auto_create_servers:
                    # Create new server
                    insert_result = session.execute(
                        text("""
                            INSERT INTO servers (
                                name, hostname, port, username, password,
                                connection_method, execution_mode, description, tags,
                                elevation_method, jea_endpoint, created_at, updated_at
                            ) VALUES (
                                :name, :hostname, :port, :username, :password,
                                :connection_method, :execution_mode, :description, :tags,
                                :elevation_method, :jea_endpoint, :created_at, :updated_at
                            ) RETURNING id
                        """),
                        {
                            "name": server_name,
                            "hostname": asset.fqdn or asset.hostname,
                            "port": 22 if connection_method == 'ssh' else 5985,
                            "username": "admin",  # Placeholder - should be configured
                            "password": None,  # nosec B105 - intentionally unset placeholder credential
                            "connection_method": connection_method,
                            "execution_mode": asset.execution_mode or 'stream',
                            "description": synced_description,
                            "tags": tags_json,
                            "elevation_method": elevation_method,
                            "jea_endpoint": asset.jea_endpoint if asset.elevation_method == 'jea' else None,
                            "created_at": now,
                            "updated_at": now
                        }
                    )
                    new_id = insert_result.fetchone()[0]
                    session.commit()
                    result.success = True
                    result.created_count = 1
                    result.details['server_id'] = new_id
                    result.details['action'] = 'created'
                    logger.info(f"Created server {new_id} from asset {asset.id}")
                else:
                    result.errors.append("Server auto-creation is disabled")

        except IntegrityError as e:
            logger.error(f"Integrity error syncing asset {asset.id}: {e}")
            result.errors.append(f"Database constraint error: {str(e)}")
        except Exception as e:
            logger.error(f"Error syncing asset {asset.id}: {e}")
            result.errors.append(f"Sync failed: {str(e)}")

        result.synced_count = result.created_count + result.updated_count
        return result

    def _delete_rows_best_effort(self, session, table_name: str, server_id: int) -> int:
        """Delete dependent rows for a server from an optional table; ignore missing tables."""
        try:
            dynamic_table = sql_table(table_name, column('server_id'))
            delete_stmt = delete(dynamic_table).where(dynamic_table.c.server_id == bindparam('server_id'))
            with session.begin_nested():
                delete_result = session.execute(
                    delete_stmt,
                    {"server_id": server_id}
                )
            return int(delete_result.rowcount or 0)
        except Exception as exc:  # noqa: BLE001 - best effort cleanup across optional schemas
            logger.debug("Skipping cleanup for table %s (server_id=%s): %s", table_name, server_id, exc)
            return 0

    def _remove_server_via_http_fallback(self, asset: Asset, reason: str) -> SyncResult:
        """Fallback cleanup for deployments where Asset Discovery and main tool do not share one database."""
        result = SyncResult(success=True)

        if not REQUESTS_AVAILABLE or requests is None:
            result.success = False
            result.errors.append(f"HTTP fallback unavailable ({reason}): requests module not installed")
            return result

        main_tool_url = (os.environ.get('MAIN_TOOL_URL') or os.environ.get('AUDIT_TOOLKIT_URL') or 'http://localhost:5000').rstrip('/')

        headers = {'Content-Type': 'application/json'}
        api_key = (os.environ.get('ASSET_DISCOVERY_API_KEY') or os.environ.get('AGENT_SYNC_API_KEY') or '').strip()
        internal_service_token = (os.environ.get('INTERNAL_SERVICE_TOKEN') or '').strip()

        if api_key:
            headers['X-API-Key'] = api_key
        if internal_service_token:
            headers['X-Internal-Service-Token'] = internal_service_token

        custom_attributes = asset.custom_attributes if isinstance(asset.custom_attributes, dict) else {}

        identifiers: List[str] = []
        authoritative_identifiers: List[str] = []

        for value in (custom_attributes.get('main_tool_server_id'), custom_attributes.get('audit_tool_server_id')):
            if value is None:
                continue
            text_value = str(value).strip()
            if text_value and text_value not in identifiers:
                identifiers.append(text_value)
                authoritative_identifiers.append(text_value)

        name_identifier = str(custom_attributes.get('main_tool_server_name') or '').strip()
        if name_identifier and name_identifier not in identifiers:
            identifiers.append(name_identifier)

        for value in (asset.fqdn, asset.hostname, asset.primary_ip):
            text_value = str(value or '').strip()
            if text_value and text_value not in identifiers:
                identifiers.append(text_value)

        if not identifiers:
            result.details['removed_server_ids'] = []
            result.details['removed_server_count'] = 0
            result.details['cleanup_mode'] = 'http-fallback'
            result.details['note'] = 'No server identifiers available for HTTP fallback cleanup'
            return result

        removed_server_ids: List[int] = []
        remove_errors: List[str] = []

        for identifier in identifiers:
            try:
                response = requests.delete(
                    f"{main_tool_url}/asset-discovery/api/servers/remove/{quote(identifier, safe='')}",
                    headers=headers,
                    timeout=15,
                )
            except Exception as exc:  # noqa: BLE001 - network failure should surface in response
                remove_errors.append(f"identifier={identifier} request_failed={exc}")
                continue

            if response.status_code == 404:
                continue

            if response.status_code != 200:
                remove_errors.append(
                    f"identifier={identifier} status={response.status_code} details={response.text[:200]}"
                )
                continue

            try:
                payload = response.json()
            except ValueError:
                payload = {}

            removed_server_id = payload.get('server_id') if isinstance(payload, dict) else None
            if removed_server_id is not None:
                try:
                    removed_server_ids.append(int(removed_server_id))
                except (TypeError, ValueError):
                    logger.debug("HTTP fallback returned non-integer server_id=%r", removed_server_id)

        deduplicated_removed_ids = sorted(set(removed_server_ids))

        result.details['cleanup_mode'] = 'http-fallback'
        result.details['cleanup_reason'] = reason
        result.details['attempted_identifiers'] = identifiers
        result.details['removed_server_ids'] = deduplicated_removed_ids
        result.details['removed_server_count'] = len(deduplicated_removed_ids)

        if authoritative_identifiers and not deduplicated_removed_ids and remove_errors:
            result.success = False
            result.errors.extend(remove_errors[:10])
            return result

        if remove_errors and not deduplicated_removed_ids:
            result.details['warnings'] = remove_errors[:10]
            result.details['note'] = (
                'HTTP fallback cleanup could not verify mirrored server deletion '
                '(non-authoritative identifiers only)'
            )
            result.success = True
            return result

        if not deduplicated_removed_ids:
            result.details['note'] = 'No mirrored server records found via HTTP fallback cleanup'

        result.success = True
        return result

    def _delete_dependent_rows_best_effort(self, session, statement: str, server_id: int, table_name: str) -> int:
        """Delete rows that are indirectly linked to server_id via parent tables; ignore missing tables."""
        try:
            with session.begin_nested():
                result = session.execute(text(statement), {"server_id": server_id})
            return int(result.rowcount or 0)
        except Exception as exc:  # noqa: BLE001 - best effort cleanup across optional schemas
            logger.debug("Skipping dependent cleanup for table %s (server_id=%s): %s", table_name, server_id, exc)
            return 0

    def remove_asset_from_audit_tool(self, asset: Asset) -> SyncResult:
        """
        Remove mirrored server records and related audit data for an asset.

        This does NOT modify the asset itself; caller controls asset-table deletion.
        """
        result = SyncResult(success=True)

        if not asset:
            return SyncResult(success=False, errors=["Asset not provided"])  # pragma: no cover - defensive guard

        if not self.config.sync_enabled or not self.config.sync_assets:
            result.details['removed_server_ids'] = []
            result.details['removed_server_count'] = 0
            result.details['note'] = 'Cross-tool sync disabled; mirrored cleanup skipped'
            return result

        try:
            with main_toolkit_session_scope() as session:
                # Standalone deployments may not include the main audit-tool schema.
                try:
                    session.execute(text("SELECT 1 FROM servers LIMIT 1"))
                except Exception as exc:  # noqa: BLE001 - compatibility across optional schemas
                    message = str(exc).lower()
                    if 'no such table' in message or 'does not exist' in message:
                        return self._remove_server_via_http_fallback(
                            asset,
                            reason='servers table not present in Asset Discovery database session',
                        )
                    raise

                marker = self._asset_sync_marker(asset.id)
                hostname = asset.fqdn or asset.hostname
                server_name = asset.hostname or asset.primary_ip

                custom_attributes = asset.custom_attributes if isinstance(asset.custom_attributes, dict) else {}
                linked_server_candidates = set()
                for linked_key in ('main_tool_server_id', 'audit_tool_server_id'):
                    raw_linked_id = custom_attributes.get(linked_key)
                    try:
                        if raw_linked_id is not None and str(raw_linked_id).strip() != '':
                            linked_server_candidates.add(int(raw_linked_id))
                    except (TypeError, ValueError):
                        logger.debug(
                            "Skipping non-integer linked server id %s=%r for asset %s",
                            linked_key,
                            raw_linked_id,
                            asset.id,
                        )

                # Prefer explicit marker-based matches (new sync format).
                marker_matches = session.execute(
                    text("""
                        SELECT id
                        FROM servers
                        WHERE description LIKE :marker_like
                    """),
                    {"marker_like": f"%{marker}%"}
                ).fetchall()

                server_ids = set()

                for linked_server_id in sorted(linked_server_candidates):
                    linked_match = session.execute(
                        text("SELECT id FROM servers WHERE id = :server_id"),
                        {"server_id": linked_server_id},
                    ).fetchone()
                    if linked_match:
                        server_ids.add(int(linked_match[0]))

                server_ids.update(int(row[0]) for row in marker_matches)

                # Backward-compatible fallback for pre-marker synced rows.
                if not server_ids:
                    fallback_matches = session.execute(
                        text("""
                            SELECT id
                            FROM servers
                            WHERE
                                (description LIKE 'Discovered by Asset Discovery%' OR tags LIKE '%asset_discovery%')
                                AND (
                                    hostname = :hostname
                                    OR name = :server_name
                                    OR (:primary_ip IS NOT NULL AND (hostname = :primary_ip OR name = :primary_ip))
                                )
                        """),
                        {
                            "hostname": hostname,
                            "server_name": server_name,
                            "primary_ip": asset.primary_ip,
                        }
                    ).fetchall()
                    server_ids.update(int(row[0]) for row in fallback_matches)

                if not server_ids:
                    linked_server_name = str(custom_attributes.get('main_tool_server_name') or '').strip()
                    if linked_server_name:
                        linked_name_matches = session.execute(
                            text("""
                                SELECT id
                                FROM servers
                                WHERE name = :linked_server_name OR hostname = :linked_server_name
                            """),
                            {"linked_server_name": linked_server_name},
                        ).fetchall()
                        server_ids.update(int(row[0]) for row in linked_name_matches)

                if not server_ids:
                    result.details['removed_server_ids'] = []
                    result.details['removed_server_count'] = 0
                    result.details['note'] = 'No mirrored server records found'
                    return result

                related_tables = [
                    # Current table names
                    'server_group_membership',
                    'server_cve_summaries',
                    'audit_executions',
                    'scheduled_audits',
                    'maintenance_windows',
                    'remediation_executions',
                    'dead_letter_tasks',
                    'task_failure_logs',
                    'audit_history_summaries',
                    'server_compliance_history',
                    'compliance_assessments',
                    'compliance_trends',
                    'differential_comparisons',
                    'remediation_items',
                    'agent_commands',
                    # Legacy aliases kept for backwards compatibility
                    'dead_letter_queue',
                    'dead_letter_archive',
                    'audit_history',
                    'audit_history_details',
                    'compliance_history',
                    'compliance_scan_results',
                    'compliance_scan_history',
                    'differential_changes',
                    'differential_scans',
                ]

                dependent_statements = [
                    (
                        "DELETE FROM remediation_history WHERE remediation_item_id IN (SELECT id FROM remediation_items WHERE server_id = :server_id)",
                        'remediation_history',
                    ),
                    (
                        "DELETE FROM compliance_controls WHERE assessment_id IN (SELECT id FROM compliance_assessments WHERE server_id = :server_id)",
                        'compliance_controls',
                    ),
                ]

                dependency_deletes = 0
                removed_server_ids = []

                for server_id in sorted(server_ids):
                    for statement, table_name in dependent_statements:
                        dependency_deletes += self._delete_dependent_rows_best_effort(
                            session,
                            statement,
                            server_id,
                            table_name,
                        )

                    for table in related_tables:
                        dependency_deletes += self._delete_rows_best_effort(session, table, server_id)

                    delete_server_result = session.execute(
                        text("DELETE FROM servers WHERE id = :server_id"),
                        {"server_id": server_id}
                    )
                    if int(delete_server_result.rowcount or 0) > 0:
                        removed_server_ids.append(server_id)

                session.commit()

                result.synced_count = len(removed_server_ids)
                result.details['removed_server_ids'] = removed_server_ids
                result.details['removed_server_count'] = len(removed_server_ids)
                result.details['related_rows_deleted'] = dependency_deletes
                result.success = True

        except Exception as exc:  # noqa: BLE001 - sync cleanup should surface rich context
            logger.error("Failed to remove mirrored server data for asset %s: %s", getattr(asset, 'id', None), exc)
            result.success = False
            result.errors.append(f"Cross-tool cleanup failed: {exc}")

        return result

    def sync_all_assets(self) -> SyncResult:
        """Sync all active assets to the main audit tool."""
        result = SyncResult(success=True)

        with session_scope() as session:
            assets = session.query(Asset).filter(Asset.status == 'active').all()

            for asset in assets:
                asset_result = self.sync_asset_to_server(asset)
                result.created_count += asset_result.created_count
                result.updated_count += asset_result.updated_count
                result.failed_count += 1 if not asset_result.success else 0
                result.errors.extend(asset_result.errors)

            result.synced_count = result.created_count + result.updated_count
            result.success = result.failed_count == 0

        return result

    def sync_vulnerability_report(self, asset_id: int) -> SyncResult:
        """
        Sync vulnerability report for an asset using direct SQL.

        Reads vulnerability data from the asset discovery database, then
        pushes summary counts to the main toolkit's server_cve_summaries table.
        """
        result = SyncResult(success=False)

        if not self.config.sync_enabled or not self.config.sync_vulnerabilities:
            result.errors.append("Vulnerability sync is disabled")
            return result

        try:
            # Step 1: read asset info and vulnerability counts from the asset discovery DB
            asset_hostname = None
            asset_name = None
            summary = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
            total = 0

            with session_scope() as session:
                asset = session.query(Asset).filter(Asset.id == asset_id).first()
                if not asset:
                    result.errors.append("Asset not found")
                    return result

                asset_hostname = asset.fqdn or asset.hostname
                asset_name = asset.hostname or asset.primary_ip

                # Count vulnerabilities by severity for this asset
                vuln_counts = session.execute(
                    text("""
                        SELECT
                            cr.cvss_v3_severity,
                            COUNT(DISTINCT sv.cve_id) as count
                        FROM software_vulnerabilities sv
                        JOIN installed_software isw ON sv.software_id = isw.id
                        JOIN cve_records cr ON sv.cve_id = cr.cve_id
                        WHERE isw.asset_id = :asset_id
                        GROUP BY cr.cvss_v3_severity
                    """),
                    {"asset_id": asset_id}
                ).fetchall()

                for row in vuln_counts:
                    severity = (row[0] or 'medium').lower()
                    count = row[1]
                    if severity in summary:
                        summary[severity] = count
                    total += count

            # Step 2: update server_cve_summaries in the main toolkit database
            now = datetime.utcnow()

            with main_toolkit_session_scope() as mt_session:
                # Find corresponding server
                server = mt_session.execute(
                    text("SELECT id FROM servers WHERE hostname = :hostname OR name = :name LIMIT 1"),
                    {"hostname": asset_hostname, "name": asset_name}
                ).fetchone()

                if not server:
                    result.errors.append("No server found for asset - sync asset first")
                    return result

                server_id = server[0]

                # Update or insert server_cve_summaries
                existing = mt_session.execute(
                    text("SELECT id FROM server_cve_summaries WHERE server_id = :server_id"),
                    {"server_id": server_id}
                ).fetchone()

                if existing:
                    mt_session.execute(
                        text("""
                            UPDATE server_cve_summaries SET
                                critical_count = :critical,
                                high_count = :high,
                                medium_count = :medium,
                                low_count = :low,
                                total_count = :total,
                                last_scan_at = :last_scan,
                                updated_at = :updated_at
                            WHERE server_id = :server_id
                        """),
                        {
                            "server_id": server_id,
                            "critical": summary['critical'],
                            "high": summary['high'],
                            "medium": summary['medium'],
                            "low": summary['low'],
                            "total": total,
                            "last_scan": now,
                            "updated_at": now
                        }
                    )
                else:
                    mt_session.execute(
                        text("""
                            INSERT INTO server_cve_summaries (
                                server_id, critical_count, high_count, medium_count,
                                low_count, total_count, last_scan_at, created_at, updated_at
                            ) VALUES (
                                :server_id, :critical, :high, :medium,
                                :low, :total, :last_scan, :created_at, :updated_at
                            )
                        """),
                        {
                            "server_id": server_id,
                            "critical": summary['critical'],
                            "high": summary['high'],
                            "medium": summary['medium'],
                            "low": summary['low'],
                            "total": total,
                            "last_scan": now,
                            "created_at": now,
                            "updated_at": now
                        }
                    )

                result.success = True
                result.synced_count = total
                result.details = {'server_id': server_id, 'summary': summary}
                logger.info(f"Synced {total} vulnerability counts for asset {asset_id} -> server {server_id}")

        except Exception as e:
            logger.error(f"Error syncing vulnerabilities for asset {asset_id}: {e}")
            result.errors.append(f"Vulnerability sync failed: {str(e)}")

        return result

    def sync_scan_complete(self, scan_job_id: int) -> SyncResult:
        """
        Handle sync operations when a scan completes.

        - Syncs discovered/updated assets to main tool
        - Updates vulnerability reports
        - Optionally triggers audits on new assets
        """
        result = SyncResult(success=True)

        if not self.config.sync_enabled or not self.config.sync_on_scan_complete:
            result.errors.append("Scan complete sync is disabled")
            return result

        with session_scope() as session:
            scan_job = session.query(ScanJob).filter(ScanJob.id == scan_job_id).first()
            if not scan_job:
                result.errors.append("Scan job not found")
                result.success = False
                return result

            # Get scan results with associated assets
            scan_results = session.query(ScanResult).filter(
                ScanResult.scan_job_id == scan_job_id,
                ScanResult.status == 'success'
            ).all()

            asset_ids = [r.asset_id for r in scan_results if r.asset_id]
            new_server_ids = []

            # Sync each asset
            for asset_id in asset_ids:
                asset = session.query(Asset).filter(Asset.id == asset_id).first()
                if asset:
                    sync_result = self.sync_asset_to_server(asset)
                    result.created_count += sync_result.created_count
                    result.updated_count += sync_result.updated_count
                    result.errors.extend(sync_result.errors)

                    if sync_result.created_count > 0:
                        new_server_ids.append(sync_result.details.get('server_id'))

                    # Sync vulnerabilities
                    if self.config.sync_vulnerabilities:
                        vuln_result = self.sync_vulnerability_report(asset_id)
                        if not vuln_result.success:
                            result.errors.extend(vuln_result.errors)

            # Optionally trigger audits on new assets
            if self.config.trigger_audit_on_new_asset and new_server_ids:
                for server_id in new_server_ids:
                    if server_id:
                        self._trigger_audit_for_server(server_id)

            result.synced_count = result.created_count + result.updated_count
            result.success = len(result.errors) == 0 or result.synced_count > 0

        return result

    def _trigger_audit_for_server(self, server_id: int) -> bool:
        """Trigger a security audit for a server using direct SQL."""
        try:
            with main_toolkit_session_scope() as session:
                now = datetime.utcnow()
                # Create a scheduled audit entry that will be picked up by the scheduler
                session.execute(
                    text("""
                        INSERT INTO scheduled_audits (
                            server_id, audit_type, cron, enabled,
                            created_at, next_run, description
                        ) VALUES (
                            :server_id, 'baseline', '0 0 * * *', true,
                            :created_at, :next_run, :description
                        )
                        ON CONFLICT (server_id, audit_type) DO NOTHING
                    """),
                    {
                        "server_id": server_id,
                        "created_at": now,
                        "next_run": now,
                        "description": "Auto-created by Asset Discovery sync"
                    }
                )
                session.commit()
                logger.info(f"Scheduled audit for server {server_id}")
                return True
        except Exception as e:
            logger.warning(f"Failed to schedule audit for server {server_id}: {e}")
            return False

    def notify_sync_event(
        self,
        event_type: str,
        details: Dict[str, Any],
        webhooks: Optional[List[str]] = None
    ) -> None:
        """Send webhook notifications for sync events."""
        if not webhooks:
            return

        # Import requests only when webhooks are actually used
        try:
            import requests as req
        except ImportError:
            logger.warning("requests module not available for webhook notifications")
            return

        payload = {
            'event_type': event_type,
            'timestamp': datetime.utcnow().isoformat(),
            'source': 'asset_discovery',
            'details': details
        }

        for webhook_url in webhooks:
            try:
                req.post(
                    webhook_url,
                    json=payload,
                    headers={'Content-Type': 'application/json'},
                    timeout=10
                )
            except Exception as e:
                logger.error(f"Failed to send webhook to {webhook_url}: {e}")


# Singleton instance
_sync_service: Optional[AuditToolSyncService] = None


def get_sync_service() -> AuditToolSyncService:
    """Get or create the sync service singleton."""
    global _sync_service
    if _sync_service is None:
        _sync_service = AuditToolSyncService()
    return _sync_service


def sync_asset(asset_id: int) -> SyncResult:
    """Convenience function to sync a single asset."""
    with session_scope() as session:
        asset = session.query(Asset).filter(Asset.id == asset_id).first()
        if not asset:
            return SyncResult(success=False, errors=["Asset not found"])
        return get_sync_service().sync_asset_to_server(asset)


def sync_scan_results(scan_job_id: int) -> SyncResult:
    """Convenience function to sync scan results."""
    return get_sync_service().sync_scan_complete(scan_job_id)


def check_audit_tool_connection() -> Tuple[bool, str]:
    """Check connection to main audit tool."""
    return get_sync_service().check_connection()


# ==============================================================================
# Reverse Sync - Import Servers from Main Tool to Asset Discovery
# ==============================================================================

def sync_servers_from_main_tool(connection_method: str = None,
                                limit: int = 100) -> SyncResult:
    """
    Import servers from the main tool into Asset Discovery as assets.

    This provides bi-directional sync - servers created in the main tool
    automatically become assets in Asset Discovery.

    Args:
        connection_method: Filter servers by connection method (ssh, winrm, api)
        limit: Maximum number of servers to import per batch

    Returns:
        SyncResult with created/updated count

    Example:
        # Import all SSH servers
        result = sync_servers_from_main_tool(connection_method='ssh')
        print(f"Created {result.created_count} assets, updated {result.updated_count}")
    """
    from keystore_client import get_keystore_client

    result = SyncResult(success=True)

    try:
        # Get keystore client to access server list
        keystore_client = get_keystore_client()

        # Retrieve server list from main tool
        server_data = keystore_client.list_servers(
            limit=limit,
            connection_method=connection_method
        )

        if not server_data:
            result.errors.append("Failed to retrieve servers from main tool")
            result.success = False
            return result

        servers = server_data.get('servers', [])
        logger.info(f"Retrieved {len(servers)} servers from main tool")

        with session_scope() as session:
            for server in servers:
                try:
                    # Check if asset already exists for this server
                    hostname = server.get('hostname') or server.get('host')
                    existing_asset = session.query(Asset).filter(
                        (Asset.hostname == hostname) |
                        (Asset.fqdn == hostname)
                    ).first()

                    # Determine OS type from connection method and elevation method
                    os_type = 'linux'  # Default
                    if server.get('connection_method') == 'winrm':
                        os_type = 'windows'
                    elif server.get('elevation_method') in ['runas', 'jea']:
                        os_type = 'windows'

                    if existing_asset:
                        # Update existing asset
                        existing_asset.fqdn = hostname
                        existing_asset.os_type = os_type
                        existing_asset.elevation_method = server.get('elevation_method', 'sudo')
                        existing_asset.jea_endpoint = server.get('jea_endpoint')
                        existing_asset.execution_mode = server.get('execution_mode', 'stream')
                        existing_asset.description = server.get('description', '')
                        existing_asset.status = 'active'
                        existing_asset.updated_at = datetime.utcnow()

                        # Update custom attributes with server metadata
                        custom_attrs = existing_asset.custom_attributes or {}
                        custom_attrs.update({
                            'main_tool_server_id': server.get('id'),
                            'main_tool_server_name': server.get('name'),
                            'connection_method': server.get('connection_method', 'ssh'),
                            'port': server.get('port', 22),
                            'tags': server.get('tags', ''),
                            'synced_from_main_tool': True,
                            'last_sync_at': datetime.utcnow().isoformat()
                        })
                        existing_asset.custom_attributes = custom_attrs

                        result.updated_count += 1
                        logger.info(f"Updated asset {existing_asset.id} from server {server.get('name')}")

                    else:
                        # Create new asset from server
                        new_asset = Asset(
                            hostname=server.get('name'),  # Use server name
                            fqdn=hostname,
                            primary_ip=hostname if _is_ip_address(hostname) else None,
                            os_type=os_type,
                            elevation_method=server.get('elevation_method', 'sudo'),
                            jea_endpoint=server.get('jea_endpoint'),
                            execution_mode=server.get('execution_mode', 'stream'),
                            description=server.get('description', ''),
                            status='active',
                            source='main_tool_sync',
                            custom_attributes={
                                'main_tool_server_id': server.get('id'),
                                'main_tool_server_name': server.get('name'),
                                'connection_method': server.get('connection_method', 'ssh'),
                                'port': server.get('port', 22),
                                'tags': server.get('tags', ''),
                                'synced_from_main_tool': True,
                                'created_from_sync': True,
                                'last_sync_at': datetime.utcnow().isoformat()
                            },
                            created_at=datetime.utcnow(),
                            updated_at=datetime.utcnow()
                        )

                        session.add(new_asset)
                        session.flush()  # Get the ID

                        result.created_count += 1
                        result.details['new_asset_ids'] = result.details.get('new_asset_ids', [])
                        result.details['new_asset_ids'].append(new_asset.id)

                        logger.info(f"Created asset {new_asset.id} from server {server.get('name')}")

                except Exception as e:
                    logger.error(f"Error syncing server {server.get('name')}: {e}")
                    result.failed_count += 1
                    result.errors.append(f"Server {server.get('name')}: {str(e)}")

            session.commit()

        result.synced_count = result.created_count + result.updated_count
        result.success = result.failed_count == 0

        logger.info(
            f"Server sync complete: {result.created_count} created, "
            f"{result.updated_count} updated, {result.failed_count} failed"
        )

    except Exception as e:
        logger.error(f"Error syncing servers from main tool: {e}")
        result.errors.append(f"Sync failed: {str(e)}")
        result.success = False

    return result


def _is_ip_address(value: str) -> bool:
    """Check if string is a valid IP address."""
    import ipaddress
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def sync_server_credentials(asset_id: int) -> Dict[str, Any]:
    """
    Retrieve credentials for an asset from the main tool's keystore.

    This allows Asset Discovery to access SSH passwords, API tokens, and
    agent keys stored in the main tool's encrypted keystore.

    Args:
        asset_id: Asset ID

    Returns:
        Dictionary with credentials:
        {
            'ssh_password': '...',
            'api_token': '...',
            'agent_key': '...',
            'connection_method': 'ssh',
            'elevation_method': 'sudo'
        }
    """
    from keystore_client import get_keystore_client

    try:
        with session_scope() as session:
            asset = session.query(Asset).filter(Asset.id == asset_id).first()
            if not asset:
                return {'error': 'Asset not found'}

            # Get server ID from custom attributes
            custom_attrs = asset.custom_attributes or {}
            server_id = custom_attrs.get('main_tool_server_id')
            server_name = custom_attrs.get('main_tool_server_name')

            if not server_id and not server_name:
                return {'error': 'No linked server found'}

            # Retrieve credentials from main tool
            keystore_client = get_keystore_client()
            creds = keystore_client.get_server_credentials(server_id or server_name)

            if not creds:
                return {'error': 'Failed to retrieve credentials'}

            return creds

    except Exception as e:
        logger.error(f"Error retrieving credentials for asset {asset_id}: {e}")
        return {'error': str(e)}

