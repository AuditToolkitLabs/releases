"""
Pytest configuration and shared fixtures for Asset Discovery Tool tests.
"""
import os
import sys
import pytest
import tempfile
from datetime import datetime
from sqlalchemy.orm import sessionmaker

# Add project root to path so `src` package imports work
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Ensure import-time app initialization starts in isolated test mode.
os.environ['SYNC_ENABLED'] = 'false'
os.environ['ASSET_DISCOVERY_DISABLE_BACKGROUND_JOBS'] = 'true'

from src.app import create_app
from src.models.base import Base, get_engine, reset_engine
from src import sync_service


@pytest.fixture(scope='session')
def app():
    """Create application for testing."""
    # Use temporary SQLite database
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        test_db_path = f.name

    os.environ['DATABASE_URL'] = f'sqlite:///{test_db_path}'
    os.environ['SECRET_KEY'] = 'test-secret-key'
    os.environ['SYNC_ENABLED'] = 'false'
    os.environ['ASSET_DISCOVERY_DISABLE_BACKGROUND_JOBS'] = 'true'

    reset_engine()
    sync_service._sync_service = None
    app = create_app()
    app.config['TESTING'] = True

    with app.app_context():
        engine = get_engine()
        Base.metadata.create_all(engine)

    yield app

    # Cleanup
    try:
        os.unlink(test_db_path)
    except OSError:
        pass
    os.environ.pop('SYNC_ENABLED', None)
    os.environ.pop('ASSET_DISCOVERY_DISABLE_BACKGROUND_JOBS', None)
    sync_service._sync_service = None
    reset_engine()


@pytest.fixture(scope='function')
def client(app):
    """Create test client."""
    return app.test_client()


@pytest.fixture(scope='function')
def db_session(app):
    """Create a database session for testing."""
    with app.app_context():
        engine = get_engine()
        connection = engine.connect()
        transaction = connection.begin()

        # Create a session bound to the connection
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=connection)
        session = SessionLocal()

        yield session

        # Rollback transaction after test
        session.close()
        if transaction.is_active:
            transaction.rollback()
        connection.close()


@pytest.fixture
def sample_asset_data():
    """Sample asset discovery data."""
    return {
        "hostname": "test-server-01",
        "fqdn": "test-server-01.example.com",
        "os_name": "Ubuntu",
        "os_version": "22.04",
        "os_arch": "x86_64",
        "kernel_version": "5.15.0-generic",
        "hardware": {
            "cpu_model": "Intel Xeon E5-2680 v4",
            "cpu_cores": 8,
            "ram_gb": 32,
            "disk_gb": 500
        },
        "network": {
            "interfaces": [
                {
                    "name": "eth0",
                    "ip_address": "192.168.1.100",
                    "mac_address": "00:11:22:33:44:55",
                    "netmask": "255.255.255.0"
                }
            ],
            "dns_servers": ["8.8.8.8", "8.8.4.4"],
            "gateway": "192.168.1.1"
        },
        "software": [
            {
                "name": "nginx",
                "version": "1.22.1",
                "vendor": "nginx.org",
                "cpe": "cpe:2.3:a:f5:nginx:1.22.1:*:*:*:*:*:*:*"
            },
            {
                "name": "openssl",
                "version": "3.0.2",
                "vendor": "OpenSSL",
                "cpe": "cpe:2.3:a:openssl:openssl:3.0.2:*:*:*:*:*:*:*"
            }
        ],
        "services": [
            {
                "name": "nginx",
                "status": "running",
                "port": 80,
                "protocol": "tcp"
            },
            {
                "name": "sshd",
                "status": "running",
                "port": 22,
                "protocol": "tcp"
            }
        ],
        "discovery_timestamp": datetime.utcnow().isoformat()
    }


@pytest.fixture
def sample_cve_data():
    """Sample CVE data."""
    return {
        "cve_id": "CVE-2023-12345",
        "description": "A buffer overflow vulnerability in nginx allows remote code execution.",
        "cvss_score": 9.8,
        "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        "severity": "CRITICAL",
        "published_date": "2023-06-15",
        "last_modified": "2023-06-20",
        "affected_cpe": ["cpe:2.3:a:f5:nginx:1.22.1:*:*:*:*:*:*:*"],
        "references": [
            "https://nvd.nist.gov/vuln/detail/CVE-2023-12345",
            "https://nginx.org/en/security_advisories.html"
        ]
    }


@pytest.fixture
def sample_scan_config():
    """Sample scan configuration."""
    return {
        "name": "Test Network Scan",
        "targets": ["192.168.1.0/24"],
        "scan_type": "discovery",
        "options": {
            "ssh_enabled": True,
            "winrm_enabled": False,
            "timeout": 30
        },
        "credentials": {
            "ssh": {
                "username": "admin",
                "key_path": "/path/to/key"
            }
        }
    }
