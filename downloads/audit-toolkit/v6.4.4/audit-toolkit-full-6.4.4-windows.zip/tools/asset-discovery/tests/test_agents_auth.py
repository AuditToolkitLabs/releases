"""
Tests for fleet-agent ingest authentication validation.
"""

from types import SimpleNamespace

from src.api.agents import _validate_agent_request
import src.security as security_module


def _request(agent_id=None, api_key=None):
    headers = {}
    if agent_id is not None:
        headers['X-Agent-ID'] = agent_id
    if api_key is not None:
        headers['X-API-Key'] = api_key
    return SimpleNamespace(headers=headers)


def test_validate_agent_request_success(monkeypatch):
    monkeypatch.setenv('AGENT_SYNC_API_KEY', 'sync-key-123')
    monkeypatch.delenv('ASSET_DISCOVERY_API_KEY', raising=False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY', raising=False)

    agent_id, error, status = _validate_agent_request(_request('agent-01', 'sync-key-123'))

    assert agent_id == 'agent-01'
    assert error is None
    assert status is None


def test_validate_agent_request_invalid_key(monkeypatch):
    monkeypatch.setenv('AGENT_SYNC_API_KEY', 'sync-key-123')
    monkeypatch.delenv('ASSET_DISCOVERY_API_KEY', raising=False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY', raising=False)

    agent_id, error, status = _validate_agent_request(_request('agent-01', 'wrong-key'))

    assert agent_id is None
    assert status == 403
    assert error == {'error': 'Invalid agent credentials'}


def test_validate_agent_request_unconfigured_key_fail_closed(monkeypatch):
    monkeypatch.delenv('AGENT_SYNC_API_KEY', raising=False)
    monkeypatch.delenv('ASSET_DISCOVERY_API_KEY', raising=False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY', raising=False)

    agent_id, error, status = _validate_agent_request(_request('agent-01', 'some-key'))

    assert agent_id is None
    assert status == 503
    assert error == {'error': 'Agent sync key is not configured'}


def test_validate_agent_request_unconfigured_key_bypass(monkeypatch):
    monkeypatch.delenv('AGENT_SYNC_API_KEY', raising=False)
    monkeypatch.delenv('ASSET_DISCOVERY_API_KEY', raising=False)
    monkeypatch.setenv('ASSET_DISCOVERY_ALLOW_UNCONFIGURED_AGENT_KEY', 'true')

    agent_id, error, status = _validate_agent_request(_request('agent-01', 'some-key'))

    assert agent_id == 'agent-01'
    assert error is None
    assert status is None


def test_agent_sync_rate_limited_returns_429(client, monkeypatch):
    monkeypatch.setattr(security_module._rate_limiter, 'is_allowed', lambda *_args, **_kwargs: False)

    response = client.post(
        '/api/agent/discovery/sync',
        json={'hostname': 'host-01'},
        headers={'X-Agent-ID': 'agent-01', 'X-API-Key': 'key-01'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 429


def test_agent_sync_payload_is_capped(client, monkeypatch):
    monkeypatch.setattr(security_module._rate_limiter, 'is_allowed', lambda *_args, **_kwargs: True)
    monkeypatch.setenv('AGENT_SYNC_API_KEY', 'sync-key-123')
    monkeypatch.setenv('ASSET_DISCOVERY_API_KEY', 'sync-key-123')
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', raising=False)

    payload = {
        'hostname': 'agent-sync-host',
        'ip_addresses': [f'10.0.0.{i % 255}' for i in range(100)],
        'packages': [{'name': f'pkg-{i}', 'version': '1.0'} for i in range(650)],
        'services': [{'name': f'svc-{i}', 'status': 'running'} for i in range(400)],
        'open_ports': [{'port': i, 'protocol': 'tcp'} for i in range(400)],
        'users': [{'username': f'user-{i}'} for i in range(260)],
    }

    response = client.post(
        '/api/agent/discovery/sync',
        json=payload,
        headers={'X-Agent-ID': 'agent-01', 'X-API-Key': 'sync-key-123'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 200
    data = response.get_json()
    assert data['payload_limited'] is True
    assert data['packages_synced'] == 500
    assert data['services_synced'] == 600


def test_agent_sync_invalid_hostname_rejected(client, monkeypatch):
    monkeypatch.setattr(security_module._rate_limiter, 'is_allowed', lambda *_args, **_kwargs: True)
    monkeypatch.setenv('AGENT_SYNC_API_KEY', 'sync-key-123')
    monkeypatch.setenv('ASSET_DISCOVERY_API_KEY', 'sync-key-123')

    response = client.post(
        '/api/agent/discovery/sync',
        json={'hostname': 'bad host name'},
        headers={'X-Agent-ID': 'agent-01', 'X-API-Key': 'sync-key-123'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 400
    data = response.get_json()
    assert data['error'] == 'invalid hostname format'


def test_agent_heartbeat_invalid_hostname_rejected(client, monkeypatch):
    monkeypatch.setenv('AGENT_SYNC_API_KEY', 'sync-key-123')
    monkeypatch.setenv('ASSET_DISCOVERY_API_KEY', 'sync-key-123')

    response = client.post(
        '/api/agent/heartbeat',
        json={'hostname': 'bad host name'},
        headers={'X-Agent-ID': 'agent-01', 'X-API-Key': 'sync-key-123'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 400
    data = response.get_json()
    assert data['error'] == 'invalid hostname format'
