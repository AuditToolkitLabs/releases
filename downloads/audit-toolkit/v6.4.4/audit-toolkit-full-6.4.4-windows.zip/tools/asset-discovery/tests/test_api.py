"""
Tests for Asset Discovery API endpoints.
"""
import pytest
import json

from src.api.scans import _expand_range_targets_with_metadata
from src.services.risk_policy import compute_risk_rating, compute_risk_score, reset_risk_policy_cache


class TestHealthEndpoint:
    """Tests for health check endpoint."""

    def test_health_check_returns_ok(self, client):
        """Health endpoint should return 200 OK."""
        response = client.get('/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'


def test_expand_range_targets_reports_truncation_metadata():
    """Range expansion helper should emit truncation metadata when capped."""
    expanded, metadata = _expand_range_targets_with_metadata([
        '192.168.10.1-192.168.14.255'
    ])

    assert len(expanded) == metadata['expanded_targets_count']
    assert metadata['truncated'] is True
    assert metadata['expanded_targets_count'] == metadata['max_targets_count']
    assert metadata['truncation_events']


class TestAssetsAPI:
    """Tests for /api/v1/assets endpoints."""

    def test_list_assets_empty(self, client):
        """GET /assets should return empty list initially."""
        response = client.get('/api/v1/assets')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data, dict)
        assert 'assets' in data
        assert isinstance(data['assets'], list)

    def test_create_asset(self, client, sample_asset_data):
        """POST /assets should create a new asset."""
        response = client.post(
            '/api/v1/assets',
            data=json.dumps(sample_asset_data),
            content_type='application/json'
        )
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['hostname'] == sample_asset_data['hostname']
        assert 'id' in data

    def test_create_asset_missing_hostname(self, client):
        """POST /assets/manual without hostname should fail validation."""
        response = client.post(
            '/api/v1/assets/manual',
            data=json.dumps({'os_name': 'Ubuntu'}),
            content_type='application/json'
        )
        assert response.status_code == 400

    def test_get_asset_not_found(self, client):
        """GET /assets/{id} for non-existent asset returns 404."""
        response = client.get('/api/v1/assets/99999')
        assert response.status_code == 404

    def test_asset_crud_workflow(self, client, sample_asset_data):
        """Test full Create-Read-Delete workflow."""
        # Create
        create_resp = client.post(
            '/api/v1/assets',
            data=json.dumps(sample_asset_data),
            content_type='application/json'
        )
        assert create_resp.status_code == 201
        asset_id = json.loads(create_resp.data)['id']

        # Read
        get_resp = client.get(f'/api/v1/assets/{asset_id}')
        assert get_resp.status_code == 200
        asset = json.loads(get_resp.data)
        assert asset['hostname'] == sample_asset_data['hostname']

        # Delete
        delete_resp = client.delete(f'/api/v1/assets/{asset_id}')
        assert delete_resp.status_code == 200

        # Verify deleted
        verify_resp = client.get(f'/api/v1/assets/{asset_id}')
        assert verify_resp.status_code == 404

    def test_cmdb_report_includes_priority_and_routing(self, client, db_session):
        """CMDB report should expose top priority assets and compliance routing summary."""
        from src.models.asset import Asset
        from src.models.software import InstalledSoftware
        from src.models.vulnerability import CVERecord, SoftwareVulnerability

        asset = Asset(
            hostname='cmdb-risk-01',
            primary_ip='192.0.2.120',
            os_type='linux',
            os_name='Ubuntu',
            status='active',
            environment='production',
            criticality='critical',
        )
        db_session.add(asset)
        db_session.flush()

        software = InstalledSoftware(asset_id=asset.id, name='nginx', version='1.20.0')
        db_session.add(software)
        db_session.flush()

        cve = CVERecord(
            cve_id='CVE-2026-60001',
            cvss_v3_score=9.4,
            cvss_v3_severity='CRITICAL',
            cisa_kev=True,
        )
        db_session.add(cve)
        db_session.flush()

        db_session.add(SoftwareVulnerability(
            asset_id=asset.id,
            software_id=software.id,
            cve_id=cve.cve_id,
            status='open',
        ))
        db_session.commit()

        response = client.get('/api/v1/assets/report/cmdb')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'top_priority_assets' in data
        assert data['top_priority_assets']
        assert data['top_priority_assets'][0]['hostname'] == 'cmdb-risk-01'
        assert data['top_priority_assets'][0]['risk_summary']['rating'] == 'critical'
        assert 'compliance_routing' in data
        assert data['compliance_routing']['vulnerability_management_immediate'] >= 1

    def test_list_assets_includes_risk_summary(self, client, db_session):
        """GET /assets should include deterministic risk summary for each asset."""
        from src.models.asset import Asset
        from src.models.software import InstalledSoftware
        from src.models.vulnerability import CVERecord, SoftwareVulnerability

        asset = Asset(
            hostname='risk-host-01',
            primary_ip='192.0.2.10',
            os_type='linux',
            os_name='Ubuntu',
            status='active',
            environment='production',
            criticality='critical',
        )
        db_session.add(asset)
        db_session.flush()

        software = InstalledSoftware(asset_id=asset.id, name='openssl', version='3.0.0')
        db_session.add(software)
        db_session.flush()

        cve = CVERecord(
            cve_id='CVE-2026-50001',
            cvss_v3_score=9.8,
            cvss_v3_severity='CRITICAL',
            cisa_kev=True,
        )
        db_session.add(cve)
        db_session.flush()

        db_session.add(SoftwareVulnerability(
            asset_id=asset.id,
            software_id=software.id,
            cve_id=cve.cve_id,
            status='open',
        ))
        db_session.commit()

        response = client.get('/api/v1/assets')
        assert response.status_code == 200
        data = json.loads(response.data)
        matching = [entry for entry in data['assets'] if entry['hostname'] == 'risk-host-01']
        assert matching

        risk = matching[0]['risk_summary']
        assert risk['rating'] == 'critical'
        assert risk['open_vulnerabilities']['critical'] == 1
        assert risk['open_vulnerabilities']['kev'] == 1
        assert risk['score'] >= 35


class TestScansAPI:
    """Tests for /api/v1/scans endpoints."""

    def test_list_scans_empty(self, client):
        """GET /scans should return empty list initially."""
        response = client.get('/api/v1/scans')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data, dict)
        assert 'scans' in data
        assert isinstance(data['scans'], list)

    def test_create_scan(self, client, sample_scan_config):
        """POST /scans should create a new scan job."""
        response = client.post(
            '/api/v1/scans',
            data=json.dumps(sample_scan_config),
            content_type='application/json'
        )
        assert response.status_code == 201
        data = json.loads(response.data)
        assert 'id' in data
        assert data['status'] == 'pending'

    def test_create_scan_accepts_fleet_agent_alias(self, client):
        """POST /scans should accept fleet-agent as a managed discovery alias."""
        payload = {
            'targets': ['192.0.2.10'],
            'job_type': 'full',
            'discovery_mode': 'authenticated',
            'discovery_method': 'fleet-agent',
            'scope': {
                'packages': True,
                'services': True,
                'updates': True,
                'ports': True,
            },
        }

        response = client.post(
            '/api/v1/scans',
            data=json.dumps(payload),
            content_type='application/json'
        )

        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['discovery_method'] == 'managed'

    def test_create_scan_returns_target_coverage_warning(self, client):
        """POST /scans should surface truncation warnings for oversized range expansion."""
        payload = {
            'targets': ['10.0.0.1-10.0.4.255'],
            'scan_type': 'discovery',
            'discovery_mode': 'network',
            'discovery_method': 'port_scan',
            'scan_profile': 'deep',
        }

        response = client.post(
            '/api/v1/scans',
            data=json.dumps(payload),
            content_type='application/json'
        )

        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['scan_profile'] == 'deep'
        assert isinstance(data.get('target_coverage'), dict)
        assert data['target_coverage'].get('truncated') is True
        assert data.get('warnings')

    def test_scan_software_update_report(self, client, db_session):
        """GET /scans/{id}/report/software-updates returns scan-scoped update report."""
        from src.models.asset import Asset
        from src.models.scan import ScanJob, ScanResult
        from src.models.software import InstalledSoftware
        from src.models.patch import PendingUpdate
        from src.models.vulnerability import CVERecord, SoftwareVulnerability

        scan = ScanJob(
            job_type='full',
            status='completed',
            targets=['10.0.0.10'],
            total_targets=1,
            successful_targets=1,
            failed_targets=0,
            created_by='pytest'
        )
        db_session.add(scan)
        db_session.flush()

        asset = Asset(
            hostname='test-win-host',
            os_type='windows',
            os_name='Windows Server 2022',
            primary_ip='10.0.0.10',
            status='active'
        )
        db_session.add(asset)
        db_session.flush()

        software = InstalledSoftware(
            asset_id=asset.id,
            name='git',
            version='2.43.0'
        )
        db_session.add(software)
        db_session.flush()

        cve = CVERecord(cve_id='CVE-2026-00001', cvss_v3_severity='HIGH')
        db_session.add(cve)
        db_session.flush()

        vuln = SoftwareVulnerability(
            asset_id=asset.id,
            software_id=software.id,
            cve_id=cve.cve_id,
            status='open'
        )
        update = PendingUpdate(
            asset_id=asset.id,
            package_name='git',
            current_version='2.43.0',
            available_version='2.44.0',
            update_type='security',
            severity='high'
        )
        result = ScanResult(
            scan_job_id=scan.id,
            asset_id=asset.id,
            target='10.0.0.10',
            status='success'
        )

        db_session.add_all([vuln, update, result])
        db_session.commit()

        response = client.get(f'/api/v1/scans/{scan.id}/report/software-updates')
        assert response.status_code == 200

        data = json.loads(response.data)
        assert data['scan_id'] == scan.id
        assert data['assets_in_report'] == 1
        assert data['summary']['assets_with_pending_updates'] == 1
        assert data['summary']['assets_with_vulnerable_software'] == 1
        assert data['assets'][0]['software_inventory_count'] == 1
        assert 'risk_prioritization' in data
        assert data['risk_prioritization']['summary']['assets_evaluated'] == 1
        assert data['risk_prioritization']['top_priorities']

        host_filtered = client.get(f'/api/v1/scans/{scan.id}/report/software-updates?host=test-win-host')
        assert host_filtered.status_code == 200
        host_data = json.loads(host_filtered.data)
        assert host_data['assets_in_report'] == 1

        host_miss = client.get(f'/api/v1/scans/{scan.id}/report/software-updates?host=non-existent-host')
        assert host_miss.status_code == 200
        host_miss_data = json.loads(host_miss.data)
        assert host_miss_data['assets_in_report'] == 0

        software_filtered = client.get(f'/api/v1/scans/{scan.id}/report/software-updates?software=git')
        assert software_filtered.status_code == 200
        software_data = json.loads(software_filtered.data)
        assert software_data['assets_in_report'] == 1

        software_miss = client.get(f'/api/v1/scans/{scan.id}/report/software-updates?software=openssl')
        assert software_miss.status_code == 200
        software_miss_data = json.loads(software_miss.data)
        assert software_miss_data['assets_in_report'] == 0

    def test_get_scan_results_returns_risk_prioritization(self, client, db_session):
        """GET /scans/{id}/results should prioritize exposed assets with CVEs and posture failures."""
        from src.models.asset import Asset
        from src.models.scan import ScanJob, ScanResult
        from src.models.software import InstalledSoftware
        from src.models.vulnerability import CVERecord, SoftwareVulnerability

        scan = ScanJob(
            job_type='full',
            status='completed',
            targets=['203.0.113.10'],
            total_targets=1,
            successful_targets=1,
            failed_targets=0,
            created_by='pytest',
            config={
                'scope': {
                    'packages': True,
                    'ports': True,
                    'security': True,
                }
            },
        )
        db_session.add(scan)
        db_session.flush()

        asset = Asset(
            hostname='edge-db-01',
            os_type='linux',
            os_name='Ubuntu',
            primary_ip='203.0.113.10',
            status='active',
            environment='production',
            criticality='critical',
        )
        db_session.add(asset)
        db_session.flush()

        software = InstalledSoftware(
            asset_id=asset.id,
            name='postgresql',
            version='15.1',
            publisher='PostgreSQL',
        )
        db_session.add(software)
        db_session.flush()

        kev_cve = CVERecord(
            cve_id='CVE-2026-40001',
            cvss_v3_score=9.8,
            cvss_v3_severity='CRITICAL',
            cisa_kev=True,
            attack_vector='NETWORK',
        )
        high_cve = CVERecord(
            cve_id='CVE-2026-40002',
            cvss_v3_score=8.1,
            cvss_v3_severity='HIGH',
            cisa_kev=False,
            attack_vector='NETWORK',
        )
        db_session.add_all([kev_cve, high_cve])
        db_session.flush()

        db_session.add_all([
            SoftwareVulnerability(
                asset_id=asset.id,
                software_id=software.id,
                cve_id=kev_cve.cve_id,
                status='open',
                match_confidence='exact',
            ),
            SoftwareVulnerability(
                asset_id=asset.id,
                software_id=software.id,
                cve_id=high_cve.cve_id,
                status='open',
                match_confidence='exact',
            ),
        ])

        result = ScanResult(
            scan_job_id=scan.id,
            asset_id=asset.id,
            target='203.0.113.10',
            status='success',
            raw_output={
                'hostname': 'edge-db-01',
                'ports': [
                    {'port': 22, 'protocol': 'tcp', 'state': 'open'},
                    {'port': 5432, 'protocol': 'tcp', 'state': 'open'},
                ],
                'posture_evaluation': {
                    'status': 'completed',
                    'findings': [
                        {
                            'control_id': 'NET-LEGACY-001',
                            'title': 'Legacy insecure remote services exposed',
                            'status': 'fail',
                            'severity': 'high',
                        },
                        {
                            'control_id': 'FW-001',
                            'title': 'Host firewall enabled',
                            'status': 'warn',
                            'severity': 'medium',
                        },
                    ],
                },
            },
        )
        db_session.add(result)
        db_session.commit()

        response = client.get(f'/api/v1/scans/{scan.id}/results')
        assert response.status_code == 200

        data = json.loads(response.data)
        risk = data['risk_prioritization']
        assert risk['status'] == 'completed'
        assert risk['summary']['assets_evaluated'] == 1
        assert risk['summary']['assets_with_open_vulnerabilities'] == 1
        assert risk['summary']['assets_with_external_exposure'] == 1
        assert risk['summary']['critical_assets'] == 1
        assert risk['summary']['kev_assets'] == 1
        assert risk['top_priorities']

        top = risk['top_priorities'][0]
        assert top['hostname'] == 'edge-db-01'
        assert top['risk_rating'] == 'critical'
        assert top['open_vulnerability_summary']['critical'] == 1
        assert top['open_vulnerability_summary']['high'] == 1
        assert top['open_vulnerability_summary']['kev'] == 1
        assert top['exposure_summary']['externally_exposed'] is True
        assert 5432 in top['exposure_summary']['exposed_ports']
        assert top['posture_summary']['fail'] == 1
        assert top['compliance_routes']
        route_names = {entry['route'] for entry in top['compliance_routes']}
        assert 'vulnerability_management' in route_names
        assert 'network_exposure_review' in route_names
        assert 'baseline_compliance' in route_names

        scan_route_names = {entry['route'] for entry in risk['compliance_routes']}
        assert 'vulnerability_management' in scan_route_names
        assert 'network_exposure_review' in scan_route_names

        html_response = client.get(f'/api/v1/scans/{scan.id}/report/software-updates?format=html')
        assert html_response.status_code == 200
        assert 'text/html' in html_response.content_type
        html_text = html_response.data.decode('utf-8')
        assert 'Software Loaded' in html_text
        assert 'Present Version' in html_text
        assert 'Update Available' in html_text
        assert 'Latest Version' in html_text


class TestVulnerabilitiesAPI:
    """Tests for /api/v1/vulnerabilities endpoints."""

    def test_list_cves(self, client):
        """GET /vulnerabilities/cves should return CVE list."""
        response = client.get('/api/v1/vulnerabilities/cves')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data, dict)
        assert 'cves' in data
        assert isinstance(data['cves'], list)

    def test_get_cve_not_found(self, client):
        """GET /vulnerabilities/cves/{id} for non-existent CVE returns 404."""
        response = client.get('/api/v1/vulnerabilities/cves/CVE-9999-99999')
        assert response.status_code == 404


class TestDashboardAPI:
    """Tests for /api/v1/dashboard endpoints."""

    def test_get_summary(self, client):
        """GET /dashboard/summary should return statistics."""
        response = client.get('/api/v1/dashboard/summary')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'assets' in data
        assert 'vulnerabilities' in data
        assert 'total' in data['assets']

    def test_get_risk_overview(self, client):
        """GET /dashboard/risk-overview should return risk breakdown."""
        response = client.get('/api/v1/dashboard/risk-overview')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'severity_distribution' in data
        assert 'assets_at_risk' in data

    def test_get_risk_overview_includes_priority_assets_and_routes(self, client, db_session):
        """Risk overview should include top-priority assets and routing summary."""
        from src.models.asset import Asset
        from src.models.software import InstalledSoftware
        from src.models.vulnerability import CVERecord, SoftwareVulnerability

        asset = Asset(
            hostname='prio-host-01',
            primary_ip='198.51.100.20',
            os_type='linux',
            os_name='Ubuntu',
            status='active',
        )
        db_session.add(asset)
        db_session.flush()

        software = InstalledSoftware(asset_id=asset.id, name='nginx', version='1.20.0')
        db_session.add(software)
        db_session.flush()

        critical_cve = CVERecord(
            cve_id='CVE-2026-51001',
            cvss_v3_score=9.5,
            cvss_v3_severity='CRITICAL',
            cisa_kev=True,
        )
        high_cve = CVERecord(
            cve_id='CVE-2026-51002',
            cvss_v3_score=8.0,
            cvss_v3_severity='HIGH',
            cisa_kev=False,
        )
        db_session.add_all([critical_cve, high_cve])
        db_session.flush()

        db_session.add_all([
            SoftwareVulnerability(
                asset_id=asset.id,
                software_id=software.id,
                cve_id=critical_cve.cve_id,
                status='open',
            ),
            SoftwareVulnerability(
                asset_id=asset.id,
                software_id=software.id,
                cve_id=high_cve.cve_id,
                status='open',
            ),
        ])
        db_session.commit()

        response = client.get('/api/v1/dashboard/risk-overview')
        assert response.status_code == 200
        data = json.loads(response.data)

        assert 'top_priority_assets' in data
        assert data['top_priority_assets']
        top = data['top_priority_assets'][0]
        assert top['hostname'] == 'prio-host-01'
        assert top['risk_rating'] == 'critical'
        assert top['open_vulnerabilities']['critical'] == 1
        assert top['open_vulnerabilities']['high'] == 1
        assert top['open_vulnerabilities']['kev'] == 1

        assert 'compliance_routing' in data
        assert data['compliance_routing']['vulnerability_management_immediate'] >= 1


def test_risk_policy_env_override_changes_rating(monkeypatch):
    """Risk policy thresholds should be configurable via environment variables."""
    reset_risk_policy_cache()
    baseline_score = compute_risk_score(high=1)
    baseline_rating = compute_risk_rating(
        risk_score=baseline_score,
        kev_count=0,
        critical_count=0,
        high_count=1,
    )

    monkeypatch.setenv('ASSET_DISCOVERY_RISK_HIGH_COUNT_FOR_HIGH', '1')
    reset_risk_policy_cache()

    tuned_score = compute_risk_score(high=1)
    tuned_rating = compute_risk_rating(
        risk_score=tuned_score,
        kev_count=0,
        critical_count=0,
        high_count=1,
    )

    assert baseline_rating in {'medium', 'high'}
    assert tuned_rating == 'high'
    reset_risk_policy_cache()
