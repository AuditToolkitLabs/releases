"""Regression tests for asset ingestion field population behavior."""

from src.models.patch import PendingUpdate
from src.services.asset_ingestion import upsert_asset_from_discovery


def test_credentialed_discovery_populates_core_system_fields(db_session):
    payload = {
        'hostname': 'cred-host-01',
        'ip_address': '10.10.10.10',
        'connection_method': 'ssh',
        'data': {
            'system': {
                'fqdn': 'cred-host-01.example.local',
                'domain': '',
                'os_name': 'Ubuntu 24.04 LTS',
                'os_version': 'Ubuntu 24.04 LTS',
                'os_build': '',
                'kernel_version': '',
                'architecture': '',
                'manufacturer': '',
                'model': '',
                'serial_number': '',
                'cpu_name': '',
                'cpu_cores': '',
                'cpu_logical_processors': '',
                'total_memory_gb': '',
                'is_virtual': None,
                'hypervisor': '',
            },
            'software': [
                {'name': 'bash', 'version': '5.2.21'}
            ],
        },
    }

    asset = upsert_asset_from_discovery(db_session, payload, fallback_ip='10.10.10.10')
    db_session.flush()

    assert asset.hostname == 'cred-host-01'
    assert asset.fqdn == 'cred-host-01.example.local'
    assert asset.domain == 'example.local'
    assert asset.os_type == 'linux'
    assert asset.os_name is not None
    assert asset.os_version is not None
    assert asset.os_build is not None
    assert asset.kernel_version is not None
    assert asset.architecture is not None
    assert asset.manufacturer is not None
    assert asset.model is not None
    assert asset.serial_number is not None
    assert asset.cpu_model is not None
    assert asset.cpu_cores is not None
    assert asset.cpu_threads is not None
    assert asset.total_memory_gb is not None
    assert asset.hypervisor is not None


def test_port_scan_discovery_does_not_force_placeholder_system_fields(db_session):
    payload = {
        'hostname': 'port-scan-host',
        'connection_method': 'port_scan',
        'data': {
            'system': {},
        },
    }

    asset = upsert_asset_from_discovery(db_session, payload, fallback_ip='10.10.10.11')
    db_session.flush()

    assert asset.hostname == 'port-scan-host'
    assert asset.manufacturer is None
    assert asset.model is None
    assert asset.serial_number is None
    assert asset.cpu_model is None


def test_cpu_threads_fallbacks_to_cpu_cores_when_logical_processors_missing(db_session):
    payload = {
        'hostname': 'win-fallback-host',
        'connection_method': 'winrm',
        'data': {
            'system': {
                'os_name': 'Windows Server 2022',
                'os_version': 'Windows Server 2022',
                'cpu_name': 'Intel Xeon',
                'cpu_cores': '8',
                'cpu_logical_processors': '',
            },
        },
    }

    asset = upsert_asset_from_discovery(db_session, payload, fallback_ip='10.10.10.12')
    db_session.flush()

    assert asset.cpu_cores == 8
    assert asset.cpu_threads == 8


def test_ingestion_accepts_top_level_pending_updates_list(db_session):
    payload = {
        'hostname': 'updates-host-01',
        'connection_method': 'managed',
        'updates_available': [
            {'name': 'openssl', 'current_version': '3.0.2-1ubuntu1.18', 'new_version': '3.0.2-1ubuntu1.20'},
            {'name': 'curl', 'current_version': '8.5.0-2ubuntu10.2', 'new_version': '8.5.0-2ubuntu10.3'},
        ],
    }

    asset = upsert_asset_from_discovery(db_session, payload, fallback_ip='10.10.10.13')
    db_session.flush()

    updates = db_session.query(PendingUpdate).filter(PendingUpdate.asset_id == asset.id).all()
    assert len(updates) == 2

    attrs = asset.custom_attributes or {}
    assert attrs.get('updates_available_count') == 2
