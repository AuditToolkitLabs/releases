"""
Tests for database models.
"""
import pytest
from datetime import datetime


class TestAssetModel:
    """Tests for Asset model."""

    def test_create_asset(self, app, db_session):
        """Should create an asset with required fields."""
        from src.models.asset import Asset

        asset = Asset(
            hostname='test-server',
            os_name='Ubuntu',
            os_version='22.04'
        )
        db_session.add(asset)
        db_session.commit()

        assert asset.id is not None
        assert asset.hostname == 'test-server'
        assert asset.created_at is not None

    def test_asset_unique_hostname(self, app, db_session):
        """Hostname should be unique per FQDN."""
        from src.models.asset import Asset

        asset1 = Asset(
            hostname='server1',
            fqdn='server1.example.com',
            os_name='Ubuntu'
        )
        db_session.add(asset1)
        db_session.commit()

        # Should allow same hostname with different FQDN
        asset2 = Asset(
            hostname='server1',
            fqdn='server1.other.com',
            os_name='CentOS'
        )
        db_session.add(asset2)
        db_session.commit()
        assert asset2.id is not None

    def test_asset_serialization(self, app, db_session):
        """Asset should serialize to dict correctly."""
        from src.models.asset import Asset

        asset = Asset(
            hostname='test-server',
            os_name='Ubuntu',
            os_version='22.04',
            architecture='x86_64'
        )
        db_session.add(asset)
        db_session.commit()

        data = asset.to_dict()
        assert data['hostname'] == 'test-server'
        assert data['os_name'] == 'Ubuntu'
        assert 'id' in data


class TestSoftwareModel:
    """Tests for InstalledSoftware model."""

    def test_create_software(self, app, db_session):
        """Should create software linked to asset."""
        from src.models.asset import Asset
        from src.models.software import InstalledSoftware

        asset = Asset(hostname='test-server', os_name='Ubuntu')
        db_session.add(asset)
        db_session.commit()

        software = InstalledSoftware(
            asset_id=asset.id,
            name='nginx',
            version='1.22.1',
            cpe_uri='cpe:2.3:a:f5:nginx:1.22.1:*:*:*:*:*:*:*'
        )
        db_session.add(software)
        db_session.commit()

        assert software.id is not None
        assert software.asset_id == asset.id


class TestVulnerabilityModel:
    """Tests for CVERecord model."""

    def test_create_cve(self, app, db_session):
        """Should create CVE entry."""
        from src.models.vulnerability import CVERecord

        cve = CVERecord(
            cve_id='CVE-2023-12345',
            description='Test vulnerability',
            cvss_v3_score=9.8,
            cvss_v3_severity='CRITICAL'
        )
        db_session.add(cve)
        db_session.commit()

        assert cve.id is not None
        assert cve.cve_id == 'CVE-2023-12345'

    def test_cve_unique_id(self, app, db_session):
        """CVE ID should be unique."""
        from src.models.vulnerability import CVERecord
        from sqlalchemy.exc import IntegrityError

        cve1 = CVERecord(cve_id='CVE-2023-99999', description='First')
        db_session.add(cve1)
        db_session.commit()

        cve2 = CVERecord(cve_id='CVE-2023-99999', description='Duplicate')
        db_session.add(cve2)

        with pytest.raises(IntegrityError):
            db_session.commit()


class TestScanModel:
    """Tests for ScanJob model."""

    def test_create_scan(self, app, db_session):
        """Should create scan job."""
        from src.models.scan import ScanJob

        scan = ScanJob(
            job_type='discovery',
            status='pending',
            targets=['192.168.1.0/24']
        )
        db_session.add(scan)
        db_session.commit()

        assert scan.id is not None
        assert scan.status == 'pending'

    def test_scan_status_transitions(self, app, db_session):
        """Scan should track status transitions."""
        from src.models.scan import ScanJob

        scan = ScanJob(
            job_type='discovery',
            status='pending'
        )
        db_session.add(scan)
        db_session.commit()

        # Transition to running
        scan.status = 'running'
        scan.started_at = datetime.utcnow()
        db_session.commit()

        assert scan.status == 'running'
        assert scan.started_at is not None

        # Transition to completed
        scan.status = 'completed'
        scan.completed_at = datetime.utcnow()
        db_session.commit()

        assert scan.status == 'completed'
        assert scan.completed_at >= scan.started_at


class TestPatchModel:
    """Tests for PendingUpdate model."""

    def test_create_patch(self, app, db_session):
        """Should create pending update entry."""
        from src.models.asset import Asset
        from src.models.patch import PendingUpdate

        # First create an asset to link to
        asset = Asset(hostname='patch-test-server', os_name='Windows')
        db_session.add(asset)
        db_session.commit()

        patch = PendingUpdate(
            asset_id=asset.id,
            package_name='KB5028185',
            current_version='1.0.0',
            available_version='1.0.1',
            update_type='security',
            severity='Critical'
        )
        db_session.add(patch)
        db_session.commit()

        assert patch.id is not None
        assert patch.package_name == 'KB5028185'
