from src.services.posture_evaluator import evaluate_asset_posture


def _finding_by_control(findings, control_id):
    for finding in findings:
        if finding.get('control_id') == control_id:
            return finding
    raise AssertionError(f"Control {control_id} not found")


def test_posture_evaluator_uses_direct_payload_shape():
    payload = {
        'updates_available': 2,
        'open_ports': [21, {'port': 22, 'protocol': 'tcp', 'state': 'open'}],
        'security': {'firewall_enabled': True},
    }

    result = evaluate_asset_posture(payload, target='host-1', method='agent')

    assert result['status'] == 'completed'
    assert result['summary']['checks_total'] >= 3

    patch = _finding_by_control(result['findings'], 'PATCH-001')
    assert patch['status'] == 'warn'
    assert patch['evidence']['updates_available'] == 2

    legacy = _finding_by_control(result['findings'], 'NET-LEGACY-001')
    assert legacy['status'] == 'fail'

    firewall = _finding_by_control(result['findings'], 'FW-001')
    assert firewall['status'] == 'pass'


def test_posture_evaluator_uses_managed_network_payload_shape():
    payload = {
        'pending_updates': [
            {'name': 'openssl', 'new_version': '3.0.3'},
            {'name': 'curl', 'new_version': '8.6.0'},
        ],
        'network': {
            'open_ports': [
                {'local_port': 23, 'protocol': 'tcp', 'state': 'listening'},
            ]
        },
        'security_info': {
            'security': {
                'firewall': 'enabled',
            }
        },
    }

    result = evaluate_asset_posture(payload, target='host-2', method='managed')

    patch = _finding_by_control(result['findings'], 'PATCH-001')
    assert patch['status'] == 'warn'
    assert patch['evidence']['updates_available'] == 2

    legacy = _finding_by_control(result['findings'], 'NET-LEGACY-001')
    assert legacy['status'] == 'fail'

    firewall = _finding_by_control(result['findings'], 'FW-001')
    assert firewall['status'] == 'pass'


def test_posture_evaluator_supports_security_hardening_alias_and_disabled_firewall():
    payload = {
        'updates_available_count': 0,
        'ports': [{'port': 443, 'protocol': 'tcp', 'state': 'open'}],
        'security_info': {
            'hardening': {
                'firewall_enabled': 'false',
            }
        },
    }

    result = evaluate_asset_posture(payload, target='host-3', method='ssh')

    patch = _finding_by_control(result['findings'], 'PATCH-001')
    assert patch['status'] == 'pass'

    legacy = _finding_by_control(result['findings'], 'NET-LEGACY-001')
    assert legacy['status'] == 'pass'

    firewall = _finding_by_control(result['findings'], 'FW-001')
    assert firewall['status'] == 'warn'


def test_posture_evaluator_handles_unknown_shapes_without_failure():
    payload = {
        'updates_available': 'not-a-number',
        'ports': ['not-a-port'],
        'security_info': {'security': {'firewall_enabled': 'maybe'}},
    }

    result = evaluate_asset_posture(payload, target='host-4', method='api')

    assert result['status'] == 'completed'
    assert result['summary']['checks_total'] >= 2

    patch = _finding_by_control(result['findings'], 'PATCH-001')
    assert patch['status'] == 'pass'

    legacy = _finding_by_control(result['findings'], 'NET-LEGACY-001')
    assert legacy['status'] == 'pass'
