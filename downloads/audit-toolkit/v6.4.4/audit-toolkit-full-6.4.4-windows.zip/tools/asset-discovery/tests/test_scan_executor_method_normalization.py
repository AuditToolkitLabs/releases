import pytest
import json
from pathlib import Path
from statistics import median

from src.services.scan_executor import normalize_discovery_method
from src.services.remote_executor import Credentials, PortScanExecutor
import socket
import unittest.mock as mock

from src.api.scans import _build_engine_tradeoff


@pytest.mark.parametrize(
    "input_method, expected",
    [
        ("fleet-agent", "managed"),
        ("fleet_agent", "managed"),
        ("api", "agent"),
        ("ssh", "ssh"),
        ("WINRM", "winrm"),
        ("", ""),
        (None, ""),
    ],
)
def test_normalize_discovery_method_aliases(input_method, expected):
    assert normalize_discovery_method(input_method) == expected


def test_port_scan_profile_drives_os_confidence(monkeypatch):
    executor = PortScanExecutor()

    monkeypatch.setattr(
        "src.services.remote_executor.validate_scan_target_ssrf",
        lambda target, allow_private=True: (True, target, ""),
    )
    monkeypatch.setattr(executor, "_reverse_dns", lambda target: target)
    monkeypatch.setattr(
        executor,
        "_test_port",
        lambda target, port, timeout=5: int(port) == 22,
    )

    result = executor.discover(
        "192.0.2.44",
        0,
        Credentials(),
        {
            "ports": True,
            "_scan_profile": {
                "name": "fast",
                "ports": [22, 443],
                "connect_timeout_seconds": 1,
                "reachability_probe_ports": [443],
            },
        },
    )

    assert result.success is True
    assert result.scan_profile == "fast"
    assert result.os_type == "linux"
    assert result.os_inference_confidence >= 0.75
    assert any(entry.get("port") == 22 for entry in result.ports)


def test_parse_nmap_xml_extracts_open_ports_and_banners():
        xml_text = """<?xml version=\"1.0\"?>
        <nmaprun version=\"7.97\">
            <host>
                <ports>
                    <port protocol=\"tcp\" portid=\"22\">
                        <state state=\"open\"/>
                        <service name=\"ssh\" product=\"OpenSSH\" version=\"9.6\" extrainfo=\"Ubuntu\"/>
                    </port>
                    <port protocol=\"tcp\" portid=\"443\">
                        <state state=\"closed\"/>
                    </port>
                </ports>
            </host>
        </nmaprun>
        """

        result = PortScanExecutor._parse_nmap_xml(xml_text)

        assert result["engine"] == "nmap"
        assert result["nmap_version"] == "7.97"
        assert result["open_ports"] == [22]
        assert result["banners"][22] == "OpenSSH 9.6 Ubuntu"


def test_grab_banner_strips_control_characters(monkeypatch):
        executor = PortScanExecutor()

        class FakeSocket:
                def __enter__(self):
                        return self

                def __exit__(self, exc_type, exc, tb):
                        return False

                def sendall(self, payload):
                        return None

                def recv(self, size):
                        return b"SSH-2.0-OpenSSH_9.6\r\n\x00garbage"

        monkeypatch.setattr(socket, "create_connection", lambda *args, **kwargs: FakeSocket())

        banner = executor._grab_banner("192.0.2.55", 22, timeout=1)

        assert banner == "SSH-2.0-OpenSSH_9.6\r\ngarbage"


def test_scan_with_banners_uses_tcp_probe_and_attaches_banners(monkeypatch):
        executor = PortScanExecutor()
        profile = {"name": "fast", "ports": [22, 443], "connect_timeout_seconds": 1}

        monkeypatch.setattr(executor, "_scan_open_ports", lambda target, resolved_profile: [22, 443])
        monkeypatch.setattr(executor, "_grab_banner", lambda target, port, timeout=3.0: {22: "SSH-2.0-OpenSSH_9.6", 443: None}.get(port))
        monkeypatch.setattr("src.services.remote_executor.NMAP_AVAILABLE", False)

        result = executor._scan_with_banners("192.0.2.80", profile)

        assert result["engine"] == "tcp_probe"
        assert result["open_ports"] == [22, 443]
        assert result["banners"] == {22: "SSH-2.0-OpenSSH_9.6"}
        assert result["scan_engine_metadata"]["engine"] == "tcp_probe"
        assert result["scan_engine_metadata"]["profile"] == "fast"


def test_build_engine_tradeoff_reports_estimate():
        tradeoff = _build_engine_tradeoff("deep", {}, 3)

        assert tradeoff["profile"] == "deep"
        assert tradeoff["target_count"] == 3
        assert tradeoff["port_count"] > 20
        assert tradeoff["estimated_duration_seconds"] > 0
        assert tradeoff["engine"] in {"tcp_probe", "nmap"}


def _load_scanner_benchmark_dataset() -> dict:
    fixture_path = Path(__file__).parent / "fixtures" / "scanner_benchmark_dataset.json"
    with fixture_path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _collect_scanner_profile_metrics(dataset: dict, profile: str) -> dict:
    tp = fp = fn = 0
    os_total = os_correct = 0
    runtimes: list[float] = []
    correct_confidences: list[float] = []
    incorrect_confidences: list[float] = []

    for target in dataset.get("targets", []):
        ground_truth = target.get("ground_truth", {})
        profile_data = target.get("profiles", {}).get(profile, {})

        gt_ports = {int(port) for port in ground_truth.get("open_ports", [])}
        obs_ports = {int(port) for port in profile_data.get("open_ports", [])}

        tp += len(gt_ports & obs_ports)
        fp += len(obs_ports - gt_ports)
        fn += len(gt_ports - obs_ports)

        gt_os = str(ground_truth.get("os_type", "unknown")).strip().lower()
        obs_os = str(profile_data.get("os_type", "unknown")).strip().lower()
        confidence = float(profile_data.get("os_inference_confidence", 0.0) or 0.0)

        if gt_os and gt_os != "unknown":
            os_total += 1
            if obs_os == gt_os:
                os_correct += 1
                correct_confidences.append(confidence)
            else:
                incorrect_confidences.append(confidence)

        runtimes.append(float(profile_data.get("runtime_seconds", 0.0) or 0.0))

    recall = tp / (tp + fn) if (tp + fn) else 1.0
    precision = tp / (tp + fp) if (tp + fp) else 1.0
    false_positive_rate = fp / (fp + tp) if (fp + tp) else 0.0
    os_accuracy = os_correct / os_total if os_total else 1.0
    runtime_median = median(runtimes) if runtimes else 0.0

    avg_correct_conf = sum(correct_confidences) / len(correct_confidences) if correct_confidences else 0.0
    avg_incorrect_conf = sum(incorrect_confidences) / len(incorrect_confidences) if incorrect_confidences else 0.0

    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "recall": recall,
        "precision": precision,
        "false_positive_rate": false_positive_rate,
        "os_accuracy": os_accuracy,
        "runtime_median": runtime_median,
        "avg_correct_conf": avg_correct_conf,
        "avg_incorrect_conf": avg_incorrect_conf,
    }


def test_scanner_profiles_meet_quality_and_runtime_gate():
    dataset = _load_scanner_benchmark_dataset()
    thresholds = dataset.get("thresholds", {})

    fast = _collect_scanner_profile_metrics(dataset, "fast")
    standard = _collect_scanner_profile_metrics(dataset, "standard")
    deep = _collect_scanner_profile_metrics(dataset, "deep")

    for profile, metrics in (("fast", fast), ("standard", standard), ("deep", deep)):
        min_recall = float(thresholds.get("min_recall", {}).get(profile, 0.0))
        min_precision = float(thresholds.get("min_precision", {}).get(profile, 0.0))
        max_fpr = float(thresholds.get("max_false_positive_rate", {}).get(profile, 1.0))
        min_os_accuracy = float(thresholds.get("min_os_accuracy", {}).get(profile, 0.0))

        assert metrics["recall"] >= min_recall, (
            f"{profile} recall regression: {metrics['recall']:.3f} < {min_recall:.3f}"
        )
        assert metrics["precision"] >= min_precision, (
            f"{profile} precision regression: {metrics['precision']:.3f} < {min_precision:.3f}"
        )
        assert metrics["false_positive_rate"] <= max_fpr, (
            f"{profile} false-positive-rate regression: {metrics['false_positive_rate']:.3f} > {max_fpr:.3f}"
        )
        assert metrics["os_accuracy"] >= min_os_accuracy, (
            f"{profile} os-accuracy regression: {metrics['os_accuracy']:.3f} < {min_os_accuracy:.3f}"
        )

    max_ratio = float(thresholds.get("max_deep_runtime_ratio_vs_standard", 3.0))
    deep_runtime_ratio = deep["runtime_median"] / max(standard["runtime_median"], 0.001)
    assert deep_runtime_ratio <= max_ratio, (
        f"deep runtime regression: ratio={deep_runtime_ratio:.2f} > {max_ratio:.2f}"
    )

    min_conf_delta = float(thresholds.get("min_confidence_delta_correct_vs_incorrect", 0.0))
    if deep["avg_incorrect_conf"] > 0:
        conf_delta = deep["avg_correct_conf"] - deep["avg_incorrect_conf"]
        assert conf_delta >= min_conf_delta, (
            f"deep confidence calibration regression: delta={conf_delta:.3f} < {min_conf_delta:.3f}"
        )

    assert standard["recall"] >= fast["recall"], "standard recall should be >= fast recall"
    assert deep["recall"] >= standard["recall"], "deep recall should be >= standard recall"
