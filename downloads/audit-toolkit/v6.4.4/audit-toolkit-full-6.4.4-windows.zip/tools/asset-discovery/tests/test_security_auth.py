"""
Tests for API key security behavior.
"""

import os
from flask import Flask, jsonify

from src.security import require_api_key
import src.security as security_module


def _build_test_app() -> Flask:
    app = Flask(__name__)

    @app.route('/protected')
    @require_api_key
    def protected():
        return jsonify({'ok': True})

    return app


def test_loopback_request_allows_no_api_key(monkeypatch):
    app = _build_test_app()
    app.config['TESTING'] = True

    monkeypatch.setattr(security_module, 'CONFIG_AVAILABLE', False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', raising=False)

    client = app.test_client()
    response = client.get('/protected', environ_overrides={'REMOTE_ADDR': '127.0.0.1'})

    assert response.status_code == 200


def test_private_network_request_denied_without_key_by_default(monkeypatch):
    app = _build_test_app()
    app.config['TESTING'] = True

    monkeypatch.setattr(security_module, 'CONFIG_AVAILABLE', False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', raising=False)

    client = app.test_client()
    response = client.get('/protected', environ_overrides={'REMOTE_ADDR': '10.10.10.10'})

    assert response.status_code == 401


def test_private_network_request_allowed_with_explicit_bypass(monkeypatch):
    app = _build_test_app()
    app.config['TESTING'] = True

    monkeypatch.setattr(security_module, 'CONFIG_AVAILABLE', False)
    monkeypatch.setenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', 'true')

    client = app.test_client()
    response = client.get('/protected', environ_overrides={'REMOTE_ADDR': '10.10.10.10'})

    assert response.status_code == 200


def test_env_api_key_allows_public_request(monkeypatch):
    app = _build_test_app()
    app.config['TESTING'] = True

    monkeypatch.setattr(security_module, 'CONFIG_AVAILABLE', False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', raising=False)
    monkeypatch.setenv('ASSET_DISCOVERY_API_KEY', 'test-key-123')

    client = app.test_client()
    response = client.get(
        '/protected',
        headers={'X-API-Key': 'test-key-123'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 200


def test_invalid_api_key_rejected(monkeypatch):
    app = _build_test_app()
    app.config['TESTING'] = True

    monkeypatch.setattr(security_module, 'CONFIG_AVAILABLE', False)
    monkeypatch.delenv('ASSET_DISCOVERY_ALLOW_INTERNAL_NO_API_KEY', raising=False)
    monkeypatch.setenv('ASSET_DISCOVERY_API_KEY', 'test-key-123')

    client = app.test_client()
    response = client.get(
        '/protected',
        headers={'X-API-Key': 'wrong-key'},
        environ_overrides={'REMOTE_ADDR': '8.8.8.8'},
    )

    assert response.status_code == 403
