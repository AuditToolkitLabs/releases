"""
Tests for network-focused security controls (SSRF + client IP trust boundaries).
"""

import json

from flask import Flask

from src import security
from src.services import remote_executor


app = Flask(__name__)


def test_validate_scan_target_ssrf_blocks_metadata_ip_even_when_private_allowed():
    is_safe, resolved_ip, reason = security.validate_scan_target_ssrf(
        '169.254.169.254',
        allow_private=True,
    )

    assert is_safe is False
    assert resolved_ip == '169.254.169.254'
    assert 'blocked range' in reason.lower() or 'metadata' in reason.lower()


def test_validate_scan_target_ssrf_blocks_loopback_ip():
    is_safe, resolved_ip, reason = security.validate_scan_target_ssrf(
        '127.0.0.1',
        allow_private=True,
    )

    assert is_safe is False
    assert resolved_ip == '127.0.0.1'
    assert 'blocked range' in reason.lower() or 'loopback' in reason.lower()


def test_validate_scan_target_ssrf_allows_private_ip_when_explicitly_enabled():
    is_safe, resolved_ip, reason = security.validate_scan_target_ssrf(
        '10.20.30.40',
        allow_private=True,
    )

    assert is_safe is True
    assert resolved_ip == '10.20.30.40'
    assert reason == 'OK'


def test_get_client_ip_secure_ignores_spoofed_forwarded_for_without_trusted_proxy(monkeypatch):
    monkeypatch.delenv('TRUSTED_PROXY_SUBNETS', raising=False)

    with app.test_request_context(
        '/',
        environ_overrides={
            'REMOTE_ADDR': '8.8.8.8',
            'HTTP_X_FORWARDED_FOR': '1.2.3.4',
            'HTTP_X_REAL_IP': '5.6.7.8',
        },
    ):
        client_ip = security.get_client_ip_secure()

    assert client_ip == '8.8.8.8'


def test_get_client_ip_secure_trusts_forwarded_for_from_loopback_proxy(monkeypatch):
    monkeypatch.delenv('TRUSTED_PROXY_SUBNETS', raising=False)

    with app.test_request_context(
        '/',
        environ_overrides={
            'REMOTE_ADDR': '127.0.0.1',
            'HTTP_X_FORWARDED_FOR': '203.0.113.5, 127.0.0.1',
        },
    ):
        client_ip = security.get_client_ip_secure()

    assert client_ip == '203.0.113.5'


def test_get_client_ip_secure_trusts_configured_proxy_subnet(monkeypatch):
    monkeypatch.setenv('TRUSTED_PROXY_SUBNETS', '172.18.0.0/16')

    with app.test_request_context(
        '/',
        environ_overrides={
            'REMOTE_ADDR': '172.18.0.23',
            'HTTP_X_REAL_IP': '203.0.113.77',
        },
    ):
        client_ip = security.get_client_ip_secure()

    assert client_ip == '203.0.113.77'


def test_effective_ssh_policy_prefers_environment_value(monkeypatch):
    monkeypatch.setenv('SSH_HOST_KEY_POLICY', 'strict')
    mode = remote_executor._get_effective_ssh_host_key_policy_mode()
    assert mode == 'strict'


def test_effective_ssh_policy_reads_superadmin_setting_file(monkeypatch, tmp_path):
    monkeypatch.delenv('SSH_HOST_KEY_POLICY', raising=False)

    settings_file = tmp_path / 'security_settings.json'
    settings_file.write_text(
        json.dumps({'ssh_host_key_policy': 'strict'}),
        encoding='utf-8',
    )

    monkeypatch.setenv('SECURITY_SETTINGS_FILE', str(settings_file))

    mode = remote_executor._get_effective_ssh_host_key_policy_mode()
    assert mode == 'strict'


def test_effective_ssh_policy_falls_back_to_warn_on_invalid_value(monkeypatch, tmp_path):
    monkeypatch.delenv('SSH_HOST_KEY_POLICY', raising=False)

    settings_file = tmp_path / 'security_settings.json'
    settings_file.write_text(
        json.dumps({'ssh_host_key_policy': 'invalid-policy'}),
        encoding='utf-8',
    )

    monkeypatch.setenv('SECURITY_SETTINGS_FILE', str(settings_file))

    mode = remote_executor._get_effective_ssh_host_key_policy_mode()
    assert mode == 'warn'


def test_effective_ssh_policy_supports_warn_and_auto_levels(monkeypatch, tmp_path):
    monkeypatch.delenv('SSH_HOST_KEY_POLICY', raising=False)

    settings_file = tmp_path / 'security_settings.json'
    settings_file.write_text(
        json.dumps({'ssh_host_key_policy': 'auto'}),
        encoding='utf-8',
    )

    monkeypatch.setenv('SECURITY_SETTINGS_FILE', str(settings_file))

    mode = remote_executor._get_effective_ssh_host_key_policy_mode()
    assert mode == 'auto'


def test_agent_execute_command_allows_read_only_hostname(monkeypatch):
    executor = remote_executor.AgentExecutor()

    monkeypatch.setattr(remote_executor, 'REQUESTS_AVAILABLE', True)
    monkeypatch.setattr(
        remote_executor,
        'validate_scan_target_ssrf',
        lambda target, allow_private=True: (True, '192.0.2.40', 'OK'),
    )
    monkeypatch.setattr(
        executor,
        '_build_preferred_target_hosts',
        lambda target, resolved_ip: ['agent-host.example'],
    )

    class _Response:
        status_code = 200

        @staticmethod
        def json():
            return {
                'hostname': 'agent-host.example',
                'os_type': 'linux',
                'packages': [],
            }

    monkeypatch.setattr(remote_executor.requests, 'get', lambda *args, **kwargs: _Response())

    result = executor.execute_command(
        'agent-host.example',
        8443,
        remote_executor.Credentials(password='test-api-key'),
        'hostname',
        timeout=5,
    )

    assert result.success is True
    assert result.return_code == 0
    assert result.stdout == 'agent-host.example'


def test_agent_execute_command_blocks_arbitrary_command(monkeypatch):
    executor = remote_executor.AgentExecutor()

    monkeypatch.setattr(remote_executor, 'REQUESTS_AVAILABLE', True)

    called = {'requests': False}

    def _should_not_call(*args, **kwargs):
        called['requests'] = True
        raise AssertionError('requests.get should not be called for blocked command')

    monkeypatch.setattr(remote_executor.requests, 'get', _should_not_call)

    result = executor.execute_command(
        'agent-host.example',
        8443,
        remote_executor.Credentials(password='test-api-key'),
        'uname -a',
        timeout=5,
    )

    assert result.success is False
    assert 'not allowed' in (result.error or '').lower()
    assert called['requests'] is False
