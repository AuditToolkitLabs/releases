"""
Regression tests for endpoint-scoped rate limiting.
"""

from flask import Flask, jsonify

import src.security as security_module


def _reset_limiter_state() -> None:
    with security_module._rate_limiter._lock:
        security_module._rate_limiter._requests.clear()


def test_rate_limit_isolated_per_endpoint():
    _reset_limiter_state()

    app = Flask(__name__)

    @app.route('/browse')
    @security_module.rate_limit(max_requests=100, window_seconds=60)
    def browse():
        return jsonify({'ok': True})

    @app.route('/sync')
    @security_module.rate_limit(max_requests=5, window_seconds=60)
    def sync():
        return jsonify({'ok': True})

    client = app.test_client()
    request_env = {'REMOTE_ADDR': '8.8.8.8'}

    for _ in range(5):
        response = client.get('/browse', environ_overrides=request_env)
        assert response.status_code == 200

    sync_response = client.get('/sync', environ_overrides=request_env)
    assert sync_response.status_code == 200

    _reset_limiter_state()


def test_rate_limit_still_enforced_within_same_endpoint():
    _reset_limiter_state()

    app = Flask(__name__)

    @app.route('/sync')
    @security_module.rate_limit(max_requests=5, window_seconds=60)
    def sync():
        return jsonify({'ok': True})

    client = app.test_client()
    request_env = {'REMOTE_ADDR': '8.8.8.8'}

    for _ in range(5):
        response = client.get('/sync', environ_overrides=request_env)
        assert response.status_code == 200

    blocked_response = client.get('/sync', environ_overrides=request_env)
    assert blocked_response.status_code == 429

    _reset_limiter_state()
