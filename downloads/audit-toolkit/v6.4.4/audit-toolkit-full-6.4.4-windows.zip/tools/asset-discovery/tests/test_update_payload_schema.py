from src.services.update_payload_schema import normalize_update_payload


def test_normalize_update_payload_prefers_pending_updates():
    count, updates = normalize_update_payload(
        updates_available=99,
        pending_updates=[
            {'name': 'openssl', 'current_version': '3.0.2', 'new_version': '3.0.3'},
            {'name': 'curl', 'new_version': '8.5.0'},
        ],
    )

    assert count == 2
    assert len(updates) == 2
    assert updates[0]['name'] == 'openssl'


def test_normalize_update_payload_uses_list_form_updates_available():
    count, updates = normalize_update_payload(
        updates_available=[
            {'name': 'bash', 'current_version': '5.1', 'new_version': '5.2'},
            {'name': 'bad-item-no-name'},
        ],
        pending_updates=None,
    )

    assert count == 2
    assert len(updates) == 2


def test_normalize_update_payload_falls_back_to_numeric_count():
    count, updates = normalize_update_payload(updates_available='7', pending_updates=None)

    assert count == 7
    assert updates == []


def test_normalize_update_payload_handles_invalid_values():
    count, updates = normalize_update_payload(updates_available='not-a-number', pending_updates=[{'foo': 'bar'}])

    assert count == 0
    assert updates == []
