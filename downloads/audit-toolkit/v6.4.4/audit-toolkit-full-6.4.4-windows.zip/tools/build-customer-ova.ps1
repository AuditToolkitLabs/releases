<#
.SYNOPSIS
    Build a customer-ready OVA from an appliance VM.

.DESCRIPTION
    Performs a customer distribution reset on the appliance VM (remove first-boot markers,
    reset network baseline to DHCP, sanitize environment URLs away from lab IPs, and verify
    first-login wizard presence), then packages OVF/OVA via tools/package-ova-from-vmdk.ps1.

.PARAMETER Version
    Toolkit version used for OVA naming. Default: 6.0.0

.PARAMETER VMName
    Hyper-V VM name backing the appliance image. Default: AuditToolkit-Appliance-Base

.PARAMETER HostAlias
    SSH host alias for the appliance VM. Default: audittoolkit-vm

.PARAMETER OutputPath
    Output directory for OVF/OVA artifacts. Default: deployment/vm-appliance/output

.PARAMETER VHDStoragePath
    Hyper-V virtual disk directory. Default: C:\Hyper-V\Virtual Hard Disks

.PARAMETER SshKeyPath
    SSH private key path. Falls back to AUDIT_VM_SSH_KEY_PATH, then common ~/.ssh keys.

.PARAMETER SudoPassword
    Secure string sudo password used for non-interactive remote preparation.
    If omitted, falls back to AUDIT_VM_SUDO_PASSWORD.

.PARAMETER AllowPasswordPrompt
    Allow interactive SSH/sudo prompts instead of fail-fast non-interactive mode.

.PARAMETER SkipRemoteSanitize
    Skip in-guest customer reset/sanitization and package directly from disk.

.PARAMETER SkipVmPowerOff
    Skip host-side VM power-off before packaging.

.PARAMETER SkipPackage
    Run remote sanitization only; do not build OVF/OVA.

.PARAMETER PackageStage
    Packaging stage passed to tools/package-ova-from-vmdk.ps1: All, VmdkOnly, or OvaOnly.

.PARAMETER MinimumInstalledDiskGB
    Minimum expected installed disk size check passed through to packager.

.EXAMPLE
    .\tools\build-customer-ova.ps1 -Version 6.0.0

.EXAMPLE
    .\tools\build-customer-ova.ps1 -HostAlias audittoolkit-vm -AllowPasswordPrompt
#>

[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = "6.0.0",

    [Parameter()]
    [string]$VMName = "AuditToolkit-Appliance-Base",

    [Parameter()]
    [string]$HostAlias = "audittoolkit-vm",

    [Parameter()]
    [string]$OutputPath = "deployment/vm-appliance/output",

    [Parameter()]
    [string]$VHDStoragePath = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [string]$SshKeyPath = $env:AUDIT_VM_SSH_KEY_PATH,

    [Parameter()]
    [SecureString]$SudoPassword,

    [Parameter()]
    [switch]$AllowPasswordPrompt,

    [Parameter()]
    [switch]$SkipRemoteSanitize,

    [Parameter()]
    [switch]$SkipVmPowerOff,

    [Parameter()]
    [switch]$SkipPackage,

    [Parameter()]
    [ValidateSet("All", "VmdkOnly", "OvaOnly")]
    [string]$PackageStage = "All",

    [Parameter()]
    [int]$MinimumInstalledDiskGB = 1,

    [Parameter()]
    [ValidateRange(1, 240)]
    [int]$RemoteSanitizeTimeoutMinutes = 20,

    [Parameter()]
    [switch]$DisableAutoVmRecover,

    [Parameter()]
    [string[]]$ProtectedVmNames = @(
        "AuditToolkit-Appliance-Base"
    ),

    [Parameter()]
    [switch]$DisableProtectedVmRollback,

    [Parameter()]
    [switch]$AllowHostAliasVmMismatch
)

$ErrorActionPreference = "Stop"
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptRoot
$PackageScriptPath = Join-Path $RepoRoot "tools\package-ova-from-vmdk.ps1"

function Write-Step {
    param([string]$Message)
    Write-Output "[*] $Message"
}

function Write-Ok {
    param([string]$Message)
    Write-Output "[OK] $Message"
}

function Write-Warn {
    param([string]$Message)
    Write-Output "[!] $Message"
}

function Resolve-SudoPassword {
    param([SecureString]$RequestedPassword)

    if ($RequestedPassword) {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($RequestedPassword)
        try {
            return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
        }
        finally {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($env:AUDIT_VM_SUDO_PASSWORD)) {
        return $env:AUDIT_VM_SUDO_PASSWORD
    }

    return ""
}

function Resolve-AbsolutePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$PathValue,

        [Parameter(Mandatory = $true)]
        [string]$BasePath
    )

    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return [System.IO.Path]::GetFullPath($PathValue).Replace('/', '\\')
    }

    return [System.IO.Path]::GetFullPath((Join-Path $BasePath $PathValue)).Replace('/', '\\')
}

function Resolve-SshKeyPath {
    param([string]$RequestedPath)

    if (-not [string]::IsNullOrWhiteSpace($RequestedPath)) {
        $expandedPath = [Environment]::ExpandEnvironmentVariables($RequestedPath)
        if (-not (Test-Path $expandedPath)) {
            throw "SSH key not found: $RequestedPath"
        }

        return (Resolve-Path $expandedPath).Path
    }

    $candidatePaths = @(
        (Join-Path $HOME ".ssh\id_ed25519"),
        (Join-Path $HOME ".ssh\id_rsa"),
        (Join-Path $HOME ".ssh\id_ecdsa")
    )

    foreach ($candidatePath in $candidatePaths) {
        if (Test-Path $candidatePath) {
            return (Resolve-Path $candidatePath).Path
        }
    }

    return $null
}

$resolvedOutputPath = Resolve-AbsolutePath -PathValue $OutputPath -BasePath $RepoRoot
$resolvedVhdStoragePath = Resolve-AbsolutePath -PathValue $VHDStoragePath -BasePath $RepoRoot
$resolvedSshKeyPath = Resolve-SshKeyPath -RequestedPath $SshKeyPath
$resolvedSudoPassword = Resolve-SudoPassword -RequestedPassword $SudoPassword

Write-Output ""
Write-Output "=== Customer OVA Build ==="
Write-Output "Version:     $Version"
Write-Output "VM Name:     $VMName"
Write-Output "Host Alias:  $HostAlias"
Write-Output "Output Path: $resolvedOutputPath"
Write-Output "VHD Store:   $resolvedVhdStoragePath"
Write-Output ""

$normalizedVmName = ($VMName ?? "").Trim().ToLowerInvariant()
$normalizedProtectedVmNames = @($ProtectedVmNames | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { $_.Trim().ToLowerInvariant() })
$isProtectedVmTarget = $normalizedProtectedVmNames -contains $normalizedVmName

$checkpointCreated = $false
$checkpointName = $null
$vmWasRunningBeforeCheckpoint = $false

if ($isProtectedVmTarget -and $DisableProtectedVmRollback) {
    Write-Warn "Protected VM rollback explicitly disabled for '$VMName'."
} elseif ($isProtectedVmTarget -and $SkipRemoteSanitize) {
    Write-Warn "Protected VM target detected, but remote sanitization is skipped; no rollback checkpoint will be created."
} elseif ($isProtectedVmTarget) {
    Write-Step "Creating rollback checkpoint for protected VM '$VMName'"
    $checkpointVm = Get-VM -Name $VMName -ErrorAction Stop
    $vmWasRunningBeforeCheckpoint = $checkpointVm.State -ne "Off"
    $checkpointName = "customer-ova-prep-$(Get-Date -Format 'yyyyMMddHHmmss')"
    Checkpoint-VM -Name $VMName -SnapshotName $checkpointName -ErrorAction Stop | Out-Null
    $checkpointCreated = $true
    Write-Ok "Created protected VM checkpoint: $checkpointName"
}

function Get-SshOption {
    param([int]$ConnectTimeout = 15)

    $options = @("-o", "ConnectTimeout=$ConnectTimeout")
    if ($resolvedSshKeyPath) {
        $options += @("-o", "IdentitiesOnly=yes", "-i", $resolvedSshKeyPath)
    }

    if (-not $AllowPasswordPrompt) {
        $options += @("-o", "BatchMode=yes", "-o", "NumberOfPasswordPrompts=0")
    }

    return $options
}

function Get-SshExecTtyOption {
    if ($AllowPasswordPrompt) {
        return @("-tt")
    }

    return @("-T")
}

function Test-SshPreflight {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Target,

        [int]$Attempts = 6,
        [int]$DelaySeconds = 5
    )

    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        & ssh -T @(Get-SshOption -ConnectTimeout 10) $Target "echo '[preflight] ssh-auth-ok'" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            return $true
        }

        if ($attempt -lt $Attempts) {
            Write-Warn "SSH preflight attempt $attempt/$Attempts failed; retrying in ${DelaySeconds}s..."
            Start-Sleep -Seconds $DelaySeconds
        }
    }

    return $false
}

function Invoke-VmSshRecovery {
    param(
        [Parameter(Mandatory = $true)]
        [string]$VmNameToRecover
    )

    try {
        $vmState = (Get-VM -Name $VmNameToRecover -ErrorAction Stop).State
        Write-Warn "Attempting SSH recovery by rebooting VM '$VmNameToRecover'..."

        if ($vmState -ne "Off") {
            Stop-VM -Name $VmNameToRecover -Force -TurnOff -ErrorAction Stop | Out-Null
        }

        Start-Sleep -Seconds 3
        Start-VM -Name $VmNameToRecover -ErrorAction Stop | Out-Null
        Start-Sleep -Seconds 12
        Write-Ok "VM reboot completed for SSH recovery"
        return $true
    }
    catch {
        Write-Warn "VM SSH recovery failed: $($_.Exception.Message)"
        return $false
    }
}

function Resolve-SshHostName {
    param(
        [Parameter(Mandatory = $true)]
        [string]$TargetAlias
    )

    try {
        $sshConfig = & ssh -G $TargetAlias 2>$null
        if ($LASTEXITCODE -eq 0 -and $sshConfig) {
            $hostLine = $sshConfig | Where-Object { $_ -match '^hostname\s+' } | Select-Object -First 1
            if ($hostLine) {
                return ($hostLine -replace '^hostname\s+', '').Trim()
            }
        }
    }
    catch {
        Write-Verbose "Failed to resolve SSH alias host name via 'ssh -G'; falling back to alias value."
    }

    return $TargetAlias
}

function Resolve-HostIPv4Address {
    param([string]$HostValue)

    if ([string]::IsNullOrWhiteSpace($HostValue)) {
        return @()
    }

    $candidate = $HostValue.Trim()
    if ($candidate -match '^(\d{1,3}\.){3}\d{1,3}$') {
        return @($candidate)
    }

    try {
        $resolved = Resolve-DnsName -Name $candidate -Type A -ErrorAction Stop |
            Where-Object { $_.IPAddress } |
            Select-Object -ExpandProperty IPAddress -Unique
        return @($resolved)
    }
    catch {
        return @()
    }
}

function Get-VmIPv4Address {
    param([string]$ExpectedVmName)

    try {
        $rawIps = @(Get-VMNetworkAdapter -VMName $ExpectedVmName -ErrorAction Stop | Select-Object -ExpandProperty IPAddresses)
    }
    catch {
        return @()
    }

    return @(
        $rawIps |
            Where-Object { $_ -match '^(\d{1,3}\.){3}\d{1,3}$' -and -not $_.StartsWith('169.254.') } |
            Select-Object -Unique
    )
}

function Assert-HostAliasMatchesVm {
    param(
        [Parameter(Mandatory = $true)]
        [string]$TargetAlias,

        [Parameter(Mandatory = $true)]
        [string]$ExpectedVmName
    )

    $resolvedHost = Resolve-SshHostName -TargetAlias $TargetAlias
    $aliasIps = Resolve-HostIPv4Address -HostValue $resolvedHost
    $vmIps = Get-VmIPv4Address -ExpectedVmName $ExpectedVmName

    if ($aliasIps.Count -eq 0) {
        Write-Warn "Could not resolve IPv4 for SSH target '$TargetAlias' (resolved host '$resolvedHost'); skipping alias/VM match guard."
        return
    }

    if ($vmIps.Count -eq 0) {
        Write-Warn "Could not read IPv4 addresses from VM '$ExpectedVmName' (KVP may be stale); skipping alias/VM match guard."
        return
    }

    $overlap = @($aliasIps | Where-Object { $vmIps -contains $_ })
    if ($overlap.Count -eq 0) {
        throw "Host alias mismatch: SSH target '$TargetAlias' resolves to [$($aliasIps -join ', ')], but VM '$ExpectedVmName' reports [$($vmIps -join ', ')]. Refusing to sanitize/package potentially different machines."
    }

    Write-Ok "Host alias '$TargetAlias' matches VM '$ExpectedVmName' IP(s): $($overlap -join ', ')"
}

if (-not $SkipRemoteSanitize -and -not $AllowHostAliasVmMismatch) {
    Assert-HostAliasMatchesVm -TargetAlias $HostAlias -ExpectedVmName $VMName
} elseif (-not $SkipRemoteSanitize) {
    Write-Warn "Host alias/VM mismatch guard disabled (-AllowHostAliasVmMismatch)."
}

try {
if (-not $SkipRemoteSanitize) {
    Write-Step "Running in-guest customer sanitization"

    if (-not $AllowPasswordPrompt -and [string]::IsNullOrWhiteSpace($resolvedSshKeyPath)) {
        throw "No SSH key found for non-interactive mode. Provide -SshKeyPath or use -AllowPasswordPrompt."
    }

    if ($resolvedSshKeyPath) {
        Write-Ok "Using SSH key: $resolvedSshKeyPath"
    }

    if (-not $AllowPasswordPrompt) {
        $preflightReady = Test-SshPreflight -Target $HostAlias -Attempts 6 -DelaySeconds 5
        if (-not $preflightReady -and -not $DisableAutoVmRecover) {
            if (Invoke-VmSshRecovery -VmNameToRecover $VMName) {
                $preflightReady = Test-SshPreflight -Target $HostAlias -Attempts 12 -DelaySeconds 5
            }
        }

        if (-not $preflightReady) {
            throw "SSH preflight failed for '$HostAlias' in non-interactive mode."
        }
    }

    $encodedSudoPassword = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($resolvedSudoPassword ?? "")))
    $allowSudoPromptFlag = if ($AllowPasswordPrompt) { "1" } else { "0" }

    $remoteSanitizeScript = @'
set -euo pipefail
SUDO_PW="$(printf '%s' '__SUDO_PW_B64__' | base64 -d 2>/dev/null || true)"
SUDO_INTERACTIVE="__ALLOW_SUDO_PROMPT__"

sudo_validate() {
    if [ -n "$SUDO_PW" ]; then
        printf '%s\n' "$SUDO_PW" | sudo -S -p '' -v
    elif [ "$SUDO_INTERACTIVE" = "1" ]; then
        sudo -v
    else
        sudo -n -v
    fi
}

sudo_cmd() {
    if [ -n "$SUDO_PW" ]; then
        printf '%s\n' "$SUDO_PW" | sudo -S -p '' "$@"
    elif [ "$SUDO_INTERACTIVE" = "1" ]; then
        sudo "$@"
    else
        sudo -n "$@"
    fi
}

set_env_value() {
    local file="$1"
    local key="$2"
    local value="$3"

    if [ ! -f "$file" ]; then
        return 0
    fi

    if sudo_cmd grep -q "^${key}=" "$file"; then
        sudo_cmd sed -i "s|^${key}=.*|${key}=${value}|" "$file"
    else
        sudo_cmd sh -c "printf '%s\\n' '${key}=${value}' >> '$file'"
    fi
}

write_root_file() {
    local target="$1"
    local mode="$2"
    local tmp_file

    tmp_file="$(mktemp)"
    cat > "$tmp_file"
    sudo_cmd install -m "$mode" "$tmp_file" "$target"
    rm -f "$tmp_file"
}

echo "[prep] validating sudo access"
if ! sudo_validate; then
    echo "[error] sudo authentication failed"
    exit 86
fi

echo "[prep] resetting first-boot markers"
sudo_cmd install -d -m 755 /var/lib/audit-toolkit
sudo_cmd rm -f \
    /var/lib/audit-toolkit/.setup-complete \
    /var/lib/audit-toolkit/.first-boot-complete \
    /var/lib/audit-toolkit/.first-login-wizard-complete \
    /var/lib/audit-toolkit/initial-admin-credentials.txt

echo "[prep] removing appliance TLS material so customer first boot gets a fresh certificate"
sudo_cmd install -d -m 755 /etc/nginx/ssl/audit-toolkit
sudo_cmd rm -f \
    /etc/nginx/ssl/audit-toolkit.crt \
    /etc/nginx/ssl/audit-toolkit.key \
    /etc/nginx/ssl/audit-toolkit-chain.crt \
    /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
    /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
    /etc/nginx/ssl/audit-toolkit/audit-toolkit-chain.crt

echo "[prep] resetting auditadmin OS password to appliance default"
printf 'auditadmin:ChangeMe123!\n' | sudo_cmd chpasswd

echo "[prep] resetting hostname to appliance default"
sudo_cmd hostnamectl set-hostname audit-toolkit 2>/dev/null || true
if sudo_cmd grep -q '127\.0\.1\.1' /etc/hosts; then
    sudo_cmd sed -i 's/^127\.0\.1\.1.*/127.0.1.1\taudit-toolkit/' /etc/hosts
else
    sudo_cmd sh -c "printf '127.0.1.1\taudit-toolkit\n' >> /etc/hosts"
fi
sudo_cmd sh -c "printf 'audit-toolkit\n' > /etc/hostname"

echo "[prep] enforcing DHCP network baseline"
PRIMARY_IFACE="$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')"
if [ -z "$PRIMARY_IFACE" ]; then
    PRIMARY_IFACE="$(ip -o link show | awk -F': ' '$2 != "lo" {print $2; exit}')"
fi

if [ -n "$PRIMARY_IFACE" ]; then
    echo "[prep] removing old netplan configs to ensure no static IP is retained"
    sudo_cmd find /etc/netplan -type f -name '*.yaml' -delete 2>/dev/null || true
    write_root_file /etc/netplan/90-audit-toolkit.yaml 600 <<NETEOF
network:
    version: 2
    ethernets:
        ${PRIMARY_IFACE}:
            dhcp4: true
NETEOF
    sudo_cmd netplan generate >/dev/null 2>&1 || true
else
    echo "[warn] no primary interface detected; skipped netplan baseline reset"
fi

echo "[prep] sanitizing app URLs away from lab addresses"
set_env_value "/opt/audit-toolkit/.env" "ASSET_DISCOVERY_EXTERNAL_URL" "/discovery/"
set_env_value "/opt/audit-toolkit/.env" "ASSET_DISCOVERY_URL" "http://127.0.0.1:18080"
set_env_value "/opt/audit-toolkit/.env" "INITIAL_ADMIN_PASSWORD" "ChangeMe123!"
set_env_value "/opt/audit-toolkit/.env" "ADMIN_PASSWORD" "ChangeMe123!"
set_env_value "/opt/audit-toolkit/.env" "INITIAL_ADMIN_CREDENTIALS_FILE" "/var/lib/audit-toolkit/initial-admin-credentials.txt"
set_env_value "/opt/audit-toolkit/.env" "AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD" "0"
set_env_value "/opt/audit-toolkit/tools/asset-discovery/.env" "AUDIT_TOOLKIT_URL" "http://127.0.0.1"

if [ -f /opt/audit-toolkit/.env ]; then
    sudo_cmd sed -E -i 's|https?://192\\.168\\.100\\.[0-9]{1,3}(:[0-9]+)?|http://127.0.0.1|g' /opt/audit-toolkit/.env
    sudo_cmd sed -E -i 's|192\\.168\\.100\\.[0-9]{1,3}|127.0.0.1|g' /opt/audit-toolkit/.env
fi
if [ -f /opt/audit-toolkit/tools/asset-discovery/.env ]; then
    sudo_cmd sed -E -i 's|https?://192\\.168\\.100\\.[0-9]{1,3}(:[0-9]+)?|http://127.0.0.1|g' /opt/audit-toolkit/tools/asset-discovery/.env
    sudo_cmd sed -E -i 's|192\\.168\\.100\\.[0-9]{1,3}|127.0.0.1|g' /opt/audit-toolkit/tools/asset-discovery/.env
fi

echo "[prep] ensuring first-login wizard inclusion"
WIZARD_PATH="/usr/local/bin/audit-toolkit-setup"
FIRST_BOOT_PROFILE="/etc/profile.d/first-boot.sh"
FIRST_BOOT_HINT="/etc/profile.d/first-boot-hint.sh"
WIZARD_REBUILD_REASON=""

if [ ! -f "$WIZARD_PATH" ] || [ ! -x "$WIZARD_PATH" ]; then
    WIZARD_REBUILD_REASON="missing or non-executable wizard"
elif sudo_cmd grep -Eq '192\\.168\\.100\\.' "$WIZARD_PATH"; then
    WIZARD_REBUILD_REASON="wizard still contains lab IP defaults"
elif ! sudo_cmd grep -q 'FIRST_LOGIN_MARKER=' "$WIZARD_PATH"; then
    WIZARD_REBUILD_REASON="wizard missing completion marker logic"
elif ! sudo_cmd grep -q 'Use DHCP\?' "$WIZARD_PATH"; then
    WIZARD_REBUILD_REASON="wizard missing interactive network prompt"
elif [ ! -f "$FIRST_BOOT_PROFILE" ]; then
    WIZARD_REBUILD_REASON="missing first-boot profile hook"
elif ! sudo_cmd grep -q 'first-login-wizard-complete' "$FIRST_BOOT_PROFILE"; then
    WIZARD_REBUILD_REASON="profile hook not marker-aware"
elif ! sudo_cmd grep -q '/usr/local/bin/audit-toolkit-setup' "$FIRST_BOOT_PROFILE"; then
    WIZARD_REBUILD_REASON="profile hook does not invoke wizard"
fi

if [ -n "$WIZARD_REBUILD_REASON" ]; then
    echo "[prep] rebuilding first-login wizard (${WIZARD_REBUILD_REASON})"

    write_root_file "$WIZARD_PATH" 755 <<'WIZARDEOF'
#!/bin/bash
set -euo pipefail

clear
echo "=========================================="
echo "Security Audit Toolkit - First Boot Setup"
echo "=========================================="
echo ""

if ! command -v sudo >/dev/null 2>&1; then
    echo "sudo is required but not installed."
    exit 1
fi

echo "Authenticate to apply system settings..."
if ! sudo -v; then
    echo "Sudo authentication failed."
    exit 1
fi

FIRST_LOGIN_MARKER="/var/lib/audit-toolkit/.first-login-wizard-complete"
if sudo test -f "${FIRST_LOGIN_MARKER}"; then
    echo "First-boot wizard already completed."
    exit 0
fi

detect_primary_iface() {
    local iface
    iface=$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')
    if [[ -z "${iface}" ]]; then
        iface=$(ip -o link show | awk -F': ' '$2 != "lo" {print $2; exit}')
    fi
    echo "${iface:-eth0}"
}

prompt_required() {
    local prompt="$1"
    local user_value=""

    while true; do
        read -r -p "${prompt}: " user_value
        if [[ -n "${user_value}" ]]; then
            echo "${user_value}"
            return 0
        fi
        echo "A value is required."
    done
}

PRIMARY_IFACE=$(detect_primary_iface)

read -r -p "Enter hostname [audit-toolkit]: " NEW_HOSTNAME
NEW_HOSTNAME=${NEW_HOSTNAME:-audit-toolkit}
sudo hostnamectl set-hostname "${NEW_HOSTNAME}"

echo ""
echo "Configure network for interface: ${PRIMARY_IFACE}"
echo "No lab network defaults are pre-populated for customer deployment."
read -r -p "Use DHCP? (Y/n): " USE_DHCP

if [[ ! "${USE_DHCP}" =~ ^[Nn]$ ]]; then
    sudo tee /etc/netplan/90-audit-toolkit.yaml >/dev/null <<NETEOF
network:
    version: 2
    ethernets:
        ${PRIMARY_IFACE}:
            dhcp4: true
NETEOF
else
    STATIC_CIDR=$(prompt_required "Static IP CIDR (example: 192.0.2.10/24)")
    GATEWAY=$(prompt_required "Gateway (example: 192.0.2.1)")
    DNS_SERVER=$(prompt_required "DNS server (example: 192.0.2.53)")
    EXPECTED_IP="${STATIC_CIDR%%/*}"

    sudo tee /etc/netplan/90-audit-toolkit.yaml >/dev/null <<NETEOF
network:
    version: 2
    ethernets:
        ${PRIMARY_IFACE}:
            dhcp4: false
            addresses:
                - ${STATIC_CIDR}
            routes:
                - to: default
                  via: ${GATEWAY}
            nameservers:
                addresses:
                    - ${DNS_SERVER}
NETEOF
fi

sudo sed -i '/gateway4:/d' /etc/netplan/*.yaml 2>/dev/null || true
sudo netplan generate
sudo netplan apply
sudo ip link set "${PRIMARY_IFACE}" up || true
ACTIVE_IP=$(hostname -I | awk '{print $1}')

if [[ -n "${EXPECTED_IP:-}" && "${ACTIVE_IP:-}" != "${EXPECTED_IP}" ]]; then
    echo ""
    echo "ERROR: static IP was not applied as expected."
    echo "Expected: ${EXPECTED_IP}"
    echo "Detected: ${ACTIVE_IP:-not-detected}"
    echo "Interface: ${PRIMARY_IFACE}"
    ip -4 addr show dev "${PRIMARY_IFACE}" || true
    exit 1
fi

TLS_HOSTNAME=$(hostname -f 2>/dev/null || hostname)
TLS_SAN="DNS:${TLS_HOSTNAME},DNS:localhost,IP:127.0.0.1"
if [[ -n "${ACTIVE_IP:-}" ]]; then
    TLS_SAN="${TLS_SAN},IP:${ACTIVE_IP}"
fi

sudo install -d -m 755 /etc/nginx/ssl/audit-toolkit
sudo rm -f /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
           /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
           /etc/nginx/ssl/audit-toolkit.crt \
           /etc/nginx/ssl/audit-toolkit.key
if ! sudo openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
    -keyout /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
    -out /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
    -subj "/CN=${TLS_HOSTNAME}/O=Audit Toolkit/C=US" \
    -addext "subjectAltName=${TLS_SAN}" >/dev/null 2>&1; then
    sudo openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
        -keyout /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
        -out /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
        -subj "/CN=${TLS_HOSTNAME}/O=Audit Toolkit/C=US" >/dev/null 2>&1
fi
sudo chmod 600 /etc/nginx/ssl/audit-toolkit/audit-toolkit.key
sudo chmod 644 /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt
sudo ln -sf /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt /etc/nginx/ssl/audit-toolkit.crt
sudo ln -sf /etc/nginx/ssl/audit-toolkit/audit-toolkit.key /etc/nginx/ssl/audit-toolkit.key

echo ""
echo "Set password for 'auditadmin' user:"
sudo passwd auditadmin

echo ""
read -r -p "Configure SSL with Let's Encrypt? (y/N): " SSL_CHOICE
if [[ "${SSL_CHOICE}" =~ ^[Yy]$ ]]; then
    read -r -p "Enter domain name: " DOMAIN
    if [[ -n "${DOMAIN}" ]]; then
        sudo certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos --email "admin@${DOMAIN}" || echo "SSL setup failed - configure manually"
    fi
fi

sudo nginx -t >/dev/null 2>&1 && sudo systemctl restart nginx || true
ACTIVE_IP=$(hostname -I | awk '{print $1}')

echo ""
echo "=========================================="
echo "Setup Complete!"
echo "=========================================="
echo "Host: ${NEW_HOSTNAME}"
echo "IP:   ${ACTIVE_IP:-not-detected}"
echo "Access the toolkit at: https://${ACTIVE_IP:-localhost}"
echo ""

sudo install -d -m 755 /var/lib/audit-toolkit
printf "completed_at=%s\n" "$(date -Iseconds)" | sudo tee "${FIRST_LOGIN_MARKER}" >/dev/null
echo "First-boot wizard marked complete."
echo "To rerun later: sudo rm -f ${FIRST_LOGIN_MARKER}"
echo ""
echo "Waiting for application services to start (may take 30-60 seconds after a reboot)..."
_svc_ready=0
for _tick in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
    if sudo systemctl is-active --quiet audit-toolkit 2>/dev/null; then
        _svc_ready=1
        break
    fi
    sleep 2
    printf "."
done
echo ""
if [ "${_svc_ready}" = "1" ]; then
    echo "Services are running."
else
    echo "Note: Services are still starting up."
    echo "Please allow 30-60 seconds before accessing the URL below."
fi
echo ""
echo "Access the toolkit at: https://${ACTIVE_IP:-localhost}"
WIZARDEOF

    write_root_file "$FIRST_BOOT_PROFILE" 644 <<'FBEOF'
if [ -f /usr/local/bin/audit-toolkit-setup ] && [ "$USER" = "auditadmin" ] && [ ! -f /var/lib/audit-toolkit/.first-login-wizard-complete ] && [ -t 0 ] && [ -t 1 ] && [ -n "${PS1:-}" ]; then
    /usr/local/bin/audit-toolkit-setup
fi
FBEOF

    write_root_file "$FIRST_BOOT_HINT" 644 <<'HINTEOF'
if [ "$USER" = "auditadmin" ] && [ ! -f /var/lib/audit-toolkit/.first-login-wizard-complete ] && [ -t 1 ]; then
    echo ""
    echo "[Audit Toolkit] First-boot setup is pending."
    echo "Run: /usr/local/bin/audit-toolkit-setup"
    echo ""
fi
HINTEOF
fi

if [ ! -f "$WIZARD_PATH" ]; then
    echo "[error] missing /usr/local/bin/audit-toolkit-setup"
    exit 87
fi
if [ ! -x "$WIZARD_PATH" ]; then
    echo "[error] /usr/local/bin/audit-toolkit-setup is not executable"
    exit 87
fi
if [ ! -f "$FIRST_BOOT_PROFILE" ]; then
    echo "[error] missing /etc/profile.d/first-boot.sh"
    exit 88
fi
if sudo_cmd grep -Eq '192\\.168\\.100\\.' "$WIZARD_PATH"; then
    echo "[error] wizard still contains lab IP defaults (192.168.100.x)"
    exit 89
fi
if ! sudo_cmd grep -q 'first-login-wizard-complete' "$FIRST_BOOT_PROFILE"; then
    echo "[error] first-boot profile hook is not marker-aware"
    exit 90
fi
if ! sudo_cmd grep -q '/usr/local/bin/audit-toolkit-setup' "$FIRST_BOOT_PROFILE"; then
    echo "[error] first-boot profile hook does not invoke audit-toolkit-setup"
    exit 91
fi
if ! sudo_cmd grep -q 'Use DHCP\?' "$WIZARD_PATH"; then
    echo "[error] wizard is missing interactive network onboarding prompts"
    exit 92
fi

echo "[prep] verifying lab IP removal from customer-facing runtime files"
LAB_IP_SCAN_PATHS="/opt/audit-toolkit/.env /opt/audit-toolkit/tools/asset-discovery/.env /usr/local/bin/audit-toolkit-setup /etc/profile.d/first-boot.sh /etc/netplan/90-audit-toolkit.yaml"
for scan_path in $LAB_IP_SCAN_PATHS; do
    if [ -f "$scan_path" ] && sudo_cmd grep -Eq '192\\.168\\.100\\.' "$scan_path"; then
        echo "[error] lab IP residue detected in $scan_path"
        exit 93
    fi
done

if command -v cloud-init >/dev/null 2>&1; then
    sudo_cmd cloud-init clean --logs >/dev/null 2>&1 || true
fi

echo "[prep] customer sanitization complete"
'@

    $remoteSanitizeScript = $remoteSanitizeScript.Replace("__SUDO_PW_B64__", $encodedSudoPassword)
    $remoteSanitizeScript = $remoteSanitizeScript.Replace("__ALLOW_SUDO_PROMPT__", $allowSudoPromptFlag)
    $remoteSanitizeScript = $remoteSanitizeScript -replace "`r`n", "`n"
    $remoteSanitizeScript = $remoteSanitizeScript -replace "`r", ""

    $remoteScriptName = "customer-sanitize-$(Get-Date -Format 'yyyyMMddHHmmss')-$([Guid]::NewGuid().ToString('N').Substring(0,8)).sh"
    $remoteScriptPath = "/tmp/$remoteScriptName"

    $tempScriptPath = Join-Path $env:TEMP $remoteScriptName
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($tempScriptPath, $remoteSanitizeScript, $utf8NoBom)

    try {
        & scp @(Get-SshOption -ConnectTimeout 15) $tempScriptPath "${HostAlias}:${remoteScriptPath}"
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to upload sanitize script to '$HostAlias'"
        }

        $remoteSanitizeTimeoutSeconds = [Math]::Max(60, ($RemoteSanitizeTimeoutMinutes * 60))
        $remoteExecCommand = "if command -v timeout >/dev/null 2>&1; then timeout --signal=TERM $remoteSanitizeTimeoutSeconds bash '$remoteScriptPath'; rc=`$?; else bash '$remoteScriptPath'; rc=`$?; fi; rm -f '$remoteScriptPath' || true; if [ `$rc -eq 124 ]; then echo '[error] remote customer sanitization timed out after $RemoteSanitizeTimeoutMinutes minute(s)'; fi; exit `$rc"
        & ssh @(Get-SshExecTtyOption) @(Get-SshOption -ConnectTimeout 20) $HostAlias $remoteExecCommand
    } finally {
        if (Test-Path $tempScriptPath) {
            Remove-Item -LiteralPath $tempScriptPath -Force -ErrorAction SilentlyContinue
        }
    }

    if ($LASTEXITCODE -ne 0) {
        throw "Remote customer sanitization failed with exit code $LASTEXITCODE"
    }

    Write-Ok "In-guest customer sanitization completed"
} else {
    Write-Warn "Skipping in-guest customer sanitization (-SkipRemoteSanitize)"
}

if ($SkipPackage) {
    Write-Warn "Packaging skipped (-SkipPackage). Remote prep completed."
    return
}

if (-not (Test-Path $PackageScriptPath)) {
    throw "Packager script not found: $PackageScriptPath"
}

if (-not $SkipVmPowerOff) {
    Write-Step "Ensuring VM is powered off for clean disk packaging"
    $vm = Get-VM -Name $VMName -ErrorAction Stop
    if ($vm.State -ne "Off") {
        # Flush pending writes to disk before shutdown so sanitization changes are committed
        Write-Step "Flushing filesystem writes before shutdown"
        try {
            & ssh @(Get-SshOption -ConnectTimeout 10) $HostAlias "sync && echo sync_ok" 2>$null | Out-Null
        }
        catch {
            Write-Verbose "Pre-shutdown sync command failed; continuing with graceful shutdown."
        }

        # Graceful ACPI shutdown - preserves journal commit, no lost writes
        Write-Step "Requesting graceful guest shutdown"
        Stop-VM -Name $VMName -ErrorAction Stop | Out-Null
        $deadline = (Get-Date).AddSeconds(90)
        while ((Get-Date) -lt $deadline) {
            if ((Get-VM -Name $VMName -ErrorAction SilentlyContinue).State -eq "Off") { break }
            Start-Sleep -Seconds 3
        }
        if ((Get-VM -Name $VMName -ErrorAction SilentlyContinue).State -ne "Off") {
            Write-Warn "Graceful shutdown timed out; forcing VM off"
            Stop-VM -Name $VMName -Force -TurnOff -ErrorAction SilentlyContinue | Out-Null
            Start-Sleep -Seconds 5
        }
    }
    Write-Ok "VM is off"
} else {
    Write-Warn "Skipping VM power-off (-SkipVmPowerOff)"
}

if (-not (Test-Path $resolvedOutputPath)) {
    New-Item -ItemType Directory -Path $resolvedOutputPath -Force | Out-Null
}

# Resolve the actual attached VHDX from the VM rather than assuming a fixed name.
# A fixed name like "$VMName.vhdx" would package a stale base disk if the VM is running
# off a renamed/stageprep disk - causing sanitization changes to be silently lost.
$attachedDisks = @(Get-VMHardDiskDrive -VMName $VMName -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path)
if ($attachedDisks.Count -eq 0) {
    Write-Warn "VM '$VMName' has no attached disks; falling back to name convention"
    $sourceVhdxPath = Join-Path $resolvedVhdStoragePath "$VMName.vhdx"
} elseif ($attachedDisks.Count -gt 1) {
    Write-Warn "VM '$VMName' has $($attachedDisks.Count) attached disks; using first: $($attachedDisks[0])"
    $sourceVhdxPath = $attachedDisks[0]
} else {
    $sourceVhdxPath = $attachedDisks[0]
    Write-Ok "Resolved gold VM disk: $sourceVhdxPath"
}

Write-Step "Packaging customer-ready artifacts (stage: $PackageStage)"
& $PackageScriptPath `
    -Version $Version `
    -OutputPath $resolvedOutputPath `
    -VMName $VMName `
    -SourceVhdxName "$VMName.vhdx" `
    -SourceVhdxPath $sourceVhdxPath `
    -MinimumInstalledDiskGB $MinimumInstalledDiskGB `
    -Stage $PackageStage

if ($LASTEXITCODE -ne 0) {
    throw "OVA packaging failed with exit code $LASTEXITCODE"
}

Write-Ok "Customer-ready OVA build complete"
Write-Output "Artifact: $(Join-Path $resolvedOutputPath "security-audit-toolkit-$Version.ova")"
}
finally {
    if ($checkpointCreated -and -not [string]::IsNullOrWhiteSpace($checkpointName)) {
        Write-Step "Reverting protected VM '$VMName' to checkpoint '$checkpointName'"

        try {
            $currentVm = Get-VM -Name $VMName -ErrorAction Stop
            if ($currentVm.State -ne "Off") {
                Stop-VM -Name $VMName -Force -TurnOff -ErrorAction SilentlyContinue | Out-Null
                Start-Sleep -Seconds 3
            }
        }
        catch {
            Write-Warn "Unable to force VM off before rollback: $($_.Exception.Message)"
        }

        try {
            Restore-VMSnapshot -VMName $VMName -Name $checkpointName -Confirm:$false -ErrorAction Stop | Out-Null
            Write-Ok "Protected VM rollback completed"
        }
        catch {
            Write-Warn "Failed to restore checkpoint '$checkpointName': $($_.Exception.Message)"
        }

        try {
            Remove-VMSnapshot -VMName $VMName -Name $checkpointName -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
        }
        catch {
            Write-Warn "Failed to remove checkpoint '$checkpointName': $($_.Exception.Message)"
        }

        if ($vmWasRunningBeforeCheckpoint) {
            try {
                Start-VM -Name $VMName -ErrorAction Stop | Out-Null
                Write-Ok "Restarted protected VM after rollback"
            }
            catch {
                Write-Warn "Failed to restart VM '$VMName' after rollback: $($_.Exception.Message)"
            }
        }
    }
}
