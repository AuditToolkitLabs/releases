<#
.SYNOPSIS
Build complete Security Audit Toolkit package (full or lite).

.DESCRIPTION
Packages all audit scripts, libraries, and agent components into a distributable archive.
Creates .tar.gz for Linux and .zip for Windows.

.PARAMETER Platform
Platform to build for: 'linux' or 'windows'

.PARAMETER Version
Toolkit version (default: read from VERSION file)

.PARAMETER OutputDir
Output directory for built packages (default: deployment/[platform]/artifacts)

.PARAMETER IncludeJRE
Include JRE agent JAR in package (default: $true)

.PARAMETER SplitForGit
Optionally split large output artifact into .partNNN files for Git-safe storage.

.PARAMETER SplitPartSizeMB
Part size (MB) when -SplitForGit is used (default: 1900)

.EXAMPLE
.\tools\build-full-package.ps1 -Platform linux -Version 6.0.0
.\tools\build-full-package.ps1 -Platform windows -Version 6.0.0
#>

[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPositionalParameters', '', Justification='Positional usage is intentional in stabilized scripts; named-argument refactors deferred to avoid behavior drift')]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('linux', 'windows')]
    [string]$Platform,

    [Parameter()]
    [string]$Version = "",

    [Parameter()]
    [string]$OutputDir = "",

    [Parameter()]
    [bool]$IncludeJRE = $true,

    [Parameter()]
    [switch]$SplitForGit,

    [Parameter()]
    [ValidateRange(50, 32768)]
    [int]$SplitPartSizeMB = 1900
)

$ErrorActionPreference = "Stop"
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptRoot

# Get version if not provided
if (-not $Version) {
    $Version = Get-Content (Join-Path $RepoRoot "VERSION") -Raw | ForEach-Object { $_.Trim() }
}

if (-not $OutputDir) {
    $OutputDir = Join-Path $RepoRoot "deployment" $Platform "artifacts"
}

# Create output directory
$null = New-Item -ItemType Directory -Path $OutputDir -Force

Write-Output ""
Write-Output "╔════════════════════════════════════════════════════════════════╗"
Write-Output "║  Building Full Audit Toolkit Package                          ║"
Write-Output "╚════════════════════════════════════════════════════════════════╝"
Write-Output ""
Write-Output "Platform:   $Platform"
Write-Output "Version:    $Version"
Write-Output "Output Dir: $OutputDir"
if ($SplitForGit) {
    Write-Output "Split Mode: Enabled (${SplitPartSizeMB}MB parts)"
}
Write-Output ""

# Verify required directories exist
$requiredDirs = @(
    "audits",
    "lib",
    "orchestrator",
    "docs",
    "tools"
)

foreach ($dir in $requiredDirs) {
    $dirPath = Join-Path $RepoRoot $dir
    if (-not (Test-Path $dirPath)) {
        Write-Output "ERROR: Required directory not found: $dir"
        exit 1
    }
}

Write-Output "✓ All required directories found"
Write-Output ""

# Create package filename
$PackageName = "audit-toolkit-full-${Version}-${Platform}"

if ($Platform -eq "windows") {
    $PackagePath = Join-Path $OutputDir "${PackageName}.zip"

    Write-Output "Creating Windows package: ${PackageName}.zip"

    # Remove existing package if present
    if (Test-Path $PackagePath) {
        Remove-Item $PackagePath -Force
        Write-Output "Removed existing package"
    }

    # Create ZIP
    $null = Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::Open($PackagePath, [System.IO.Compression.ZipArchiveMode]::Create)

    # Add directories
    $dirsToAdd = @("audits", "lib", "orchestrator", "docs", "tools")

    try {
        foreach ($dirName in $dirsToAdd) {
            $dirPath = Join-Path $RepoRoot $dirName
            Write-Output "  Adding $dirName..."

            Get-ChildItem -Path $dirPath -Recurse -File | ForEach-Object {
                $relativePath = $_.FullName.Substring($RepoRoot.Length + 1)
                $normalizedRelativePath = $relativePath -replace '\\', '/'

                if ($normalizedRelativePath -like "tools/tmp/*") {
                    return
                }

                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $relativePath) | Out-Null
            }
        }

        # Add JRE agent if available
        if ($IncludeJRE) {
            $jreJar = Join-Path $RepoRoot "agents\jre\shared\target\unified-jre-agent-shared-0.1.0.jar"
            if (Test-Path $jreJar) {
                Write-Output "  Adding JRE agent..."
                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $jreJar, "agents/jre/shared/unified-jre-agent-shared-0.1.0.jar") | Out-Null
            }
        }

        # Add essential files
        $essentialFiles = @("README.md", "LICENSE", "CHANGELOG.md", "VERSION")
        foreach ($file in $essentialFiles) {
            $filePath = Join-Path $RepoRoot $file
            if (Test-Path $filePath) {
                Write-Output "  Adding $file..."
                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $filePath, $file) | Out-Null
            }
        }
    }
    finally {
        $zip.Dispose()
    }

    $packageSize = (Get-Item $PackagePath).Length
    Write-Output ""
    Write-Output "✓ Windows package created successfully"
    Write-Output "  File: $PackagePath"
    Write-Output "  Size: $([math]::Round($packageSize / 1MB, 1))MB"

} else {
    # Linux TAR.GZ package
    $PackagePath = Join-Path $OutputDir "${PackageName}.tar.gz"

    Write-Output "Creating Linux package: ${PackageName}.tar.gz"

    # Remove existing package if present
    if (Test-Path $PackagePath) {
        Remove-Item $PackagePath -Force
        Write-Output "Removed existing package"
    }

    # Use tar command if available (Git Bash, WSL, etc.)
    $tarCheck = Get-Command tar -ErrorAction SilentlyContinue

    if ($tarCheck) {
        Write-Output "Using native tar command..."

        # Build tar with all components
        $includePaths = @(
            "audits",
            "lib",
            "orchestrator",
            "docs",
            "tools",
            "README.md",
            "LICENSE",
            "CHANGELOG.md",
            "VERSION"
        )

        # Add JRE agent if available
        if ($IncludeJRE -and (Test-Path "agents/jre/shared/target/unified-jre-agent-shared-0.1.0.jar")) {
            $includePaths += "agents/jre/shared/target/unified-jre-agent-shared-0.1.0.jar"
        }

        $excludeArgs = @(
            "--exclude=*.pyc",
            "--exclude=__pycache__",
            "--exclude=.git",
            "--exclude=.git/*",
            "--exclude=.github",
            "--exclude=.github/*",
            "--exclude=.venv",
            "--exclude=.venv/*",
            "--exclude=node_modules",
            "--exclude=node_modules/*",
            "--exclude=logs",
            "--exclude=logs/*",
            "--exclude=*/logs",
            "--exclude=*/logs/*",
            "--exclude=*.log",
            "--exclude=*.db",
            "--exclude=*.sqlite",
            "--exclude=*.sqlite3",
            "--exclude=tools/tmp",
            "--exclude=tools/tmp/*",
            "--exclude=deployment/linux/build",
            "--exclude=deployment/linux/build/*",
            "--exclude=deployment/vm-appliance/output",
            "--exclude=deployment/vm-appliance/output/*"
        )

        Push-Location $RepoRoot
        try {
            $tarOutput = & tar @excludeArgs -czf $PackagePath @includePaths 2>&1
            $tarExit = $LASTEXITCODE

            foreach ($line in $tarOutput) {
                if ($line -match "error|Error|ERROR") {
                    Write-Output $line
                }
            }

            if ($tarExit -ne 0) {
                Write-Output "ERROR: tar command failed with exit code $tarExit"
                exit 1
            }
        }
        finally {
            Pop-Location
        }

        if (Test-Path $PackagePath) {
            $packageSize = (Get-Item $PackagePath).Length
            Write-Output ""
            Write-Output "✓ Linux package created successfully"
            Write-Output "  File: $PackagePath"
            Write-Output "  Size: $([math]::Round($packageSize / 1MB, 1))MB"
        } else {
            Write-Output "ERROR: Failed to create tar package"
            exit 1
        }
    } else {
        Write-Output "ERROR: tar command not found. Cannot create Linux package."
        Write-Output "Install Git Bash or WSL to enable tar support."
        exit 1
    }
}

Write-Output ""
Write-Output "Build complete!"

if ($SplitForGit) {
    $splitScript = Join-Path $ScriptRoot "split-artifact-for-git.ps1"
    if (-not (Test-Path $splitScript)) {
        Write-Output "ERROR: Split helper not found: $splitScript"
        exit 1
    }

    Write-Output ""
    Write-Output "Splitting artifact for Git-safe storage..."
    try {
        & $splitScript -FilePath $PackagePath -PartSizeMB $SplitPartSizeMB -Force
    }
    catch {
        Write-Output "ERROR: Artifact split failed"
        Write-Output $_
        exit 1
    }
}

