import fnmatch
import os
import tarfile

ROOT = r"C:/Github/Audit-Tool-"
OUT = r"C:/Github/Audit-Tool-/vm-sync-latest.tgz"

EXCLUDE_DIRS = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", "node_modules", "backups"}
EXCLUDE_GLOBS = [
    "*.db",
    "*.db.old",
    "*.gz",
    ".env",          # never ship live secrets — VMs configure their own .env at setup time
    "*.env.local",
    "*.env.dev",
    "api-endpoint-validation-*.json",
    "asset-discovery-test-results-*.json",
    "test-results-*.json",
]

if os.path.exists(OUT):
    os.remove(OUT)

with tarfile.open(OUT, "w:gz") as tar:
    for base, dirs, files in os.walk(ROOT):
        rel_base = os.path.relpath(base, ROOT)
        parts = set(rel_base.split(os.sep)) if rel_base != "." else set()
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        if parts & EXCLUDE_DIRS:
            continue

        for filename in files:
            rel = os.path.normpath(os.path.join(rel_base, filename))
            rel_unix = rel.replace("\\", "/")

            skip = any(
                fnmatch.fnmatch(filename, pattern) or fnmatch.fnmatch(rel_unix, pattern)
                for pattern in EXCLUDE_GLOBS
            )
            if skip:
                continue

            tar.add(os.path.join(base, filename), arcname=rel_unix)

print(OUT)
