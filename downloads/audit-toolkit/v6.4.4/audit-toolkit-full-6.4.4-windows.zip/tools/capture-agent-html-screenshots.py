#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import os
from pathlib import Path

from playwright.async_api import async_playwright

MAIN_URL = os.environ.get("APP_URL", "http://localhost:5000")
STANDALONE_URL = os.environ.get("STANDALONE_URL", "http://localhost:8088")
ADMIN_USER = os.environ.get("ADMIN_USER") or os.environ.get("ADMIN_USERNAME") or "admin"
ADMIN_PASS = os.environ.get("ADMIN_PASS") or os.environ.get("ADMIN_PASSWORD") or "admin"
OUT_DIR = Path(__file__).parent.parent / "docs" / "screenshots" / "agent-html"
VIEWPORT = {"width": 1920, "height": 1080}


async def login_main(page, user: str, password: str) -> bool:
    await page.goto(f"{MAIN_URL}/auth/login")
    await page.wait_for_load_state("networkidle")
    await page.fill("#username", user)
    await page.fill("#password", password)
    async with page.expect_navigation(timeout=15000):
        await page.click("#login-btn, button[type='submit']")
    await page.wait_for_load_state("networkidle")
    return "/auth/login" not in page.url and "/login" not in page.url


async def capture(page, name: str) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / f"{name}.png"
    await asyncio.sleep(0.5)
    await page.screenshot(path=str(path), full_page=False)
    print(f"  ✓ {path.name}")


async def main(user: str, password: str, headful: bool) -> int:
    shots = []
    failures = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=not headful)

        try:
            context_main = await browser.new_context(viewport=VIEWPORT)
            page_main = await context_main.new_page()

            print("Logging into main app...")
            ok = await login_main(page_main, user=user, password=password)
            if not ok:
                print("✗ Main app login failed")
                return 1

            print("\nCapturing fleet-agent HTML pages...")
            try:
                await page_main.goto(f"{MAIN_URL}/console")
                await page_main.wait_for_load_state("networkidle")
                await capture(page_main, "managed-01-console-overview")
                shots.append("managed-01-console-overview")
            except Exception as exc:
                failures.append(f"managed-01-console-overview: {exc}")

            try:
                await page_main.goto(f"{MAIN_URL}/api/admin/agent-security")
                await page_main.wait_for_load_state("networkidle")
                await capture(page_main, "managed-02-agent-security")
                shots.append("managed-02-agent-security")
            except Exception as exc:
                failures.append(f"managed-02-agent-security: {exc}")

            try:
                await page_main.goto(f"{MAIN_URL}/api/admin/destination-policy-page")
                await page_main.wait_for_load_state("networkidle")
                await capture(page_main, "managed-03-destination-policy")
                shots.append("managed-03-destination-policy")
            except Exception as exc:
                failures.append(f"managed-03-destination-policy: {exc}")

            print("\nCapturing hypervisor HTML pages...")
            try:
                await page_main.goto(f"{MAIN_URL}/hypervisors")
                await page_main.wait_for_load_state("networkidle")
                await capture(page_main, "hypervisor-01-management-page")
                shots.append("hypervisor-01-management-page")
            except Exception as exc:
                failures.append(f"hypervisor-01-management-page: {exc}")

            try:
                await page_main.goto(f"{MAIN_URL}/console")
                await page_main.wait_for_load_state("networkidle")
                try:
                    await page_main.click('[data-tab="hypervisors"], button[data-tab="hypervisors"]', timeout=2500)
                    await asyncio.sleep(0.8)
                except Exception:
                    pass
                await page_main.evaluate(
                    """
                    () => {
                        const panel = document.getElementById('hypervisors-tab');
                        if (panel) panel.scrollIntoView({behavior:'instant', block:'start'});
                    }
                    """
                )
                await capture(page_main, "hypervisor-02-console-tab")
                shots.append("hypervisor-02-console-tab")
            except Exception as exc:
                failures.append(f"hypervisor-02-console-tab: {exc}")

            await context_main.close()

            context_standalone = await browser.new_context(viewport=VIEWPORT)
            page_standalone = await context_standalone.new_page()

            print("\nCapturing standalone HTML pages...")
            standalone_routes = [
                ("standalone-01-home", "/"),
                ("standalone-02-setup", "/setup"),
                ("standalone-03-audits", "/audits"),
                ("standalone-04-results", "/results"),
                ("standalone-05-schedules", "/schedules"),
                ("standalone-06-settings", "/settings"),
            ]

            for name, route in standalone_routes:
                try:
                    await page_standalone.goto(f"{STANDALONE_URL}{route}")
                    await page_standalone.wait_for_load_state("networkidle")
                    await capture(page_standalone, name)
                    shots.append(name)
                except Exception as exc:
                    failures.append(f"{name}: {exc}")

            await context_standalone.close()
        finally:
            await browser.close()

    print("\n" + "=" * 60)
    print("AGENT HTML SCREENSHOT SUMMARY")
    print("=" * 60)
    print(f"Output folder: {OUT_DIR}")
    print(f"Captured: {len(shots)}")
    for item in shots:
        print(f"  ✓ {item}.png")

    if failures:
        print(f"Failed: {len(failures)}")
        for item in failures:
            print(f"  ✗ {item}")

    return 0 if not failures else 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture standalone/managed/hypervisor HTML screenshots")
    parser.add_argument("--user", default=ADMIN_USER, help="Main app username")
    parser.add_argument("--password", default=ADMIN_PASS, help="Main app password")
    parser.add_argument("--headful", action="store_true", help="Run browser in headed mode")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    raise SystemExit(asyncio.run(main(user=args.user, password=args.password, headful=args.headful)))
