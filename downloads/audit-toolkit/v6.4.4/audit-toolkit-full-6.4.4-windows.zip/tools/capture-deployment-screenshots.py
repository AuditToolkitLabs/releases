#!/usr/bin/env python3
"""
Playwright script to capture comprehensive screenshots across all Audit Toolkit tabs and sections.
Captures Dashboard, Audits, Targets, Console, Reports, Schedules, Settings, Admin, Script Studio,
Deployment, Asset Discovery, and Developer Studio.
"""

import asyncio
import sys
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("ERROR: Playwright not installed. Install with: pip install playwright")
    sys.exit(1)

SCREENSHOTS_DIR = Path(__file__).parent.parent / "docs" / "screenshots"
BASE_URL = "http://localhost:5000"

# Map of tab names to screenshot numbers and paths
TABS = {
    "overview": {"num": "02", "name": "overview"},
    "audits": {"num": "04", "name": "audits"},
    "targets": {"num": "05", "name": "console-targets"},
    "console": {"num": "04", "name": "console-audits"},
    "reports": {"num": "06", "name": "reports"},
    "schedules": {"num": "07", "name": "schedules"},
    "settings": {"num": "08", "name": "settings"},
    "admin": {"num": "09", "name": "admin-users"},
    "script-studio": {"num": "10", "name": "script-studio"},
    "deployment": {"num": "19", "name": "deployment-overview"},
}

async def login_if_needed(page):
    """Check if login is required and login if needed."""
    try:
        login_input = await page.query_selector('input[type="password"]')
        if login_input:
            print("🔐 Login page detected. Attempting login...")
            email_input = await page.query_selector('input[type="email"], input[name="email"], input[name="username"]')
            if email_input:
                await email_input.fill("admin")

            await page.fill('input[type="password"]', "admin")

            login_btn = await page.query_selector('button[type="submit"], button:has-text("Login"), button:has-text("Sign In")')
            if login_btn:
                await login_btn.click()
                await page.wait_for_load_state("networkidle")
                await asyncio.sleep(1)
                print("✅ Logged in successfully")
                return True
    except Exception as e:
        print(f"⚠️  Login attempt error (page may not require login): {e}")

    return False

async def capture_tab_screenshot(page, tab_name, tab_info, screenshot_num):
    """Capture a screenshot of a specific tab."""
    try:
        print(f"\n📍 Capturing {tab_name.upper()} tab...")

        # Try multiple selector patterns
        selectors = [
            f'a:has-text("{tab_name.title()}")',
            f'button:has-text("{tab_name.title()}")',
            f'a[href*="{tab_name}"]',
            f'button[class*="{tab_name}"]',
            'nav a, nav button, [role="navigation"] a, [role="navigation"] button'
        ]

        tab_element = None
        for selector in selectors[:-1]:  # Skip the last broad selector for now
            tab_element = await page.query_selector(selector)
            if tab_element:
                print(f"  Found with selector: {selector}")
                break

        if not tab_element:
            print(f"  ⚠️  Could not find {tab_name} tab, listing available navigation items...")
            nav_items = await page.query_selector_all(selectors[-1])
            for i, item in enumerate(nav_items[:10]):
                try:
                    text = await item.text_content()
                    print(f"    {i+1}. {text.strip()}")
                except Exception:
                    pass
            return False

        # Click and wait
        await tab_element.click()
        await page.wait_for_load_state("networkidle")
        await asyncio.sleep(0.5)

        # Capture screenshot
        screenshot_path = SCREENSHOTS_DIR / f"{screenshot_num}-{tab_info['name']}.png"
        await page.screenshot(path=str(screenshot_path), full_page=True)
        print(f"✅ Saved: {screenshot_path.name}")
        return True

    except Exception as e:
        print(f"❌ Error capturing {tab_name}: {e}")
        return False

async def capture_all_tabs():
    """Capture screenshots from all major tabs and sections."""

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False, args=['--start-maximized'])
        context = await browser.new_context(
            viewport={"width": 1920, "height": 1080}
        )
        page = await context.new_page()

        captured_count = 0

        try:
            print(f"🌐 Navigating to {BASE_URL}...")
            await page.goto(BASE_URL, wait_until="networkidle")
            await asyncio.sleep(1)

            # Handle login if needed
            await login_if_needed(page)

            # Capture Dashboard (initial page)
            print("\n📸 Capturing DASHBOARD...")
            dashboard_path = SCREENSHOTS_DIR / "audit-admin-tools-dashboard.png"
            await page.screenshot(path=str(dashboard_path), full_page=True)
            print(f"✅ Saved: {dashboard_path.name}")
            captured_count += 1

            # Capture each tab
            for tab_name, tab_info in TABS.items():
                if await capture_tab_screenshot(page, tab_name, tab_info, tab_info["num"]):
                    captured_count += 1
                await asyncio.sleep(0.5)

            # Try to navigate to Asset Discovery if available
            print("\n📍 Attempting to access Asset Discovery...")
            try:
                asset_link = await page.query_selector('a[href*="asset"], button:has-text("Asset")')
                if asset_link:
                    await asset_link.click()
                    await page.wait_for_load_state("networkidle")
                    await asyncio.sleep(0.5)

                    asset_path = SCREENSHOTS_DIR / "13-asset-discovery-dashboard.png"
                    await page.screenshot(path=str(asset_path), full_page=True)
                    print(f"✅ Saved Asset Discovery: {asset_path.name}")
                    captured_count += 1
            except Exception as e:
                print(f"⚠️  Asset Discovery not found or inaccessible: {e}")

            # Try to navigate to Developer Studio if available
            print("\n📍 Attempting to access Developer Studio...")
            try:
                dev_link = await page.query_selector('a[href*="developer"], a[href*="studio"], button:has-text("Developer")')
                if dev_link:
                    await dev_link.click()
                    await page.wait_for_load_state("networkidle")
                    await asyncio.sleep(0.5)

                    dev_path = SCREENSHOTS_DIR / "23-developer-studio.png"
                    await page.screenshot(path=str(dev_path), full_page=True)
                    print(f"✅ Saved Developer Studio: {dev_path.name}")
                    captured_count += 1
            except Exception as e:
                print(f"⚠️  Developer Studio not found or inaccessible: {e}")

        except Exception as e:
            print(f"❌ Fatal error: {e}")
            return False, 0

        finally:
            await browser.close()

    return captured_count > 0, captured_count

async def main():
    """Main entry point."""
    print("🚀 Starting comprehensive Audit Toolkit screenshot capture...")
    print(f"📁 Saving to: {SCREENSHOTS_DIR}")
    print(f"🌐 Target URL: {BASE_URL}\n")

    # Ensure screenshots directory exists
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

    success, count = await capture_all_tabs()

    if success:
        print("\n✅ Screenshot capture completed!")
        print(f"📸 Total screenshots captured: {count}")
        print(f"📁 Files saved to: {SCREENSHOTS_DIR}")
        print("\nNext steps:")
        print("1. Review screenshots in docs/screenshots/")
        print("2. Update documentation to reference new screenshots")
        print("3. Commit and push to GitHub")
    else:
        print("\n❌ Screenshot capture failed. Check the app is running and accessible.")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
