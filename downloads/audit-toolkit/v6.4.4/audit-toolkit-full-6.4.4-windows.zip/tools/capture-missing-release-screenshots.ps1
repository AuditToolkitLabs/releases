<#
.SYNOPSIS
    One-command helper to capture only missing v6.0.0 release screenshots.

.EXAMPLE
    .\tools\capture-missing-release-screenshots.ps1

.EXAMPLE
    .\tools\capture-missing-release-screenshots.ps1 -DryRun
#>

param(
    [switch]$DryRun,
    [bool]$StartServer = $true,
    [int]$Port = 5000,
    [string]$AssetDiscoveryUrl = "http://localhost:5000/asset-discovery"
)

$ErrorActionPreference = "Stop"

$params = @{
    MissingOnly = $true
    DryRun = $DryRun
    StartServer = $StartServer
    Port = $Port
    AssetDiscoveryUrl = $AssetDiscoveryUrl
}

& "$PSScriptRoot\capture-screenshots.ps1" @params
