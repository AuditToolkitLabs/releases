#!/usr/bin/env python3
"""
Authenticated Screenshot Capture for Security Audit Toolkit

This script:
1. Resets the admin user with a known password for authentication
2. Uses Playwright to log in with those credentials
3. Captures full-page screenshots across all major UI sections
4. Saves screenshots to docs/screenshots/

Author: Security Audit Toolkit
Date: March 2026
"""

import asyncio
import logging
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

TOOLKIT_URL = "http://localhost:5000"
SCREENSHOT_DIR = project_root / "docs" / "screenshots"
DEMO_ADMIN_USERNAME = "admin"
DEMO_ADMIN_PASSWORD = "DemoScreenshots123!"

# UI sections to capture (describe navigation)
SCREENSHOTS = [
    ("Dashboard", "/", "Dashboard home"),
    ("Overview", "/overview", "System overview"),
    ("Console", "/console", "Audit console"),
    ("Script Studio", "/script-studio", "Script authoring environment"),
    ("Support Tools", "/deploy", "Support Tools page - main tab"),
    ("Windows Helpers", "/deploy", "Support Tools page - Windows Helpers tab"),
    ("Linux Helpers", "/deploy", "Support Tools page - Linux Helpers tab"),
    ("Asset Discovery", "/asset-discovery", "Asset discovery dashboard"),
    ("Admin Users", "/admin/users", "User administration"),
    ("Reports", "/reports", "Audit reports"),
    ("Settings", "/settings", "System settings"),
]


def reset_admin_in_database(password: str):
    """
    Reset admin user with a known password using SQLAlchemy directly.

    This function:
    - Clears existing users if any
    - Creates new admin user with known password
    """
    logger.info("Resetting admin user in database...")
    try:
        from config import SessionLocal
        from models.user import create_initial_admin
        from sqlalchemy import text

        db = SessionLocal()
        try:
            # Clear all existing users
            db.execute(text("DELETE FROM user_session"))
            db.execute(text("DELETE FROM password_history"))
            db.execute(text("DELETE FROM auth_audit_log"))
            db.execute(text("DELETE FROM users"))
            db.commit()
            logger.info("✓ Cleared existing users from database")

            # Create initial admin with our known password
            admin, generated_pw = create_initial_admin(
                db,
                username=DEMO_ADMIN_USERNAME,
                email="admin@demo.local",
                password=password  # Use our known password
            )

            if admin:
                logger.info(f"✓ Created admin user: {DEMO_ADMIN_USERNAME}")
                logger.info(f"✓ Password set to: {password}")
                return True
            else:
                logger.error("Admin user already exists in database")
                return False
        finally:
            db.close()

    except Exception as e:
        logger.error(f"Failed to reset admin: {e}")
        import traceback
        traceback.print_exc()
        return False


async def login_to_app(page, username: str, password: str) -> bool:
    """
    Log in to the Security Audit Toolkit via Playwright.

    Args:
        page: Playwright page object
        username: Username for login
        password: Password for login

    Returns:
        True if login successful, False otherwise
    """
    logger.info(f"Authenticating as {username}...")

    try:
        # Navigate to login page
        await page.goto(f"{TOOLKIT_URL}/login", wait_until="networkidle")

        # Fill username field
        username_selector = "input[name='username']"
        if not await page.query_selector(username_selector):
            # Try alternate selectors
            username_selector = "input[type='text']"

        await page.fill(username_selector, username)
        logger.info("✓ Entered username")

        # Fill password field
        password_selector = "input[name='password']"
        if not await page.query_selector(password_selector):
            # Try alternate selector
            password_selector = "input[type='password']"

        await page.fill(password_selector, password)
        logger.info("✓ Entered password")

        # Click login button
        login_button_selectors = [
            "button:has-text('Login')",
            "button:has-text('Sign In')",
            "button[type='submit']",
        ]

        clicked = False
        for selector in login_button_selectors:
            try:
                button = await page.query_selector(selector)
                if button:
                    await button.click()
                    clicked = True
                    break
            except Exception:
                continue

        if not clicked:
            logger.error("Could not find login button")
            return False

        # Wait for navigation (successful login)
        try:
            await page.wait_for_navigation(wait_until="networkidle", timeout=10000)
        except Exception:
            # Navigation might not trigger, wait for page load instead
            await asyncio.sleep(3)

        # Check if we're logged in (should not be on login page)
        current_url = page.url
        if "/login" in current_url:
            logger.error("Login failed - still on login page")
            return False

        logger.info("✓ Successfully authenticated")
        return True

    except Exception as e:
        logger.error(f"Login error: {e}")
        return False


async def capture_screenshots():
    """
    Main function to capture all UI screenshots with authentication.
    """
    from playwright.async_api import async_playwright

    # Step 1: Reset admin user in database
    logger.info("\n" + "="*70)
    logger.info("PHASE 1: Database Reset")
    logger.info("="*70)

    if not reset_admin_in_database(DEMO_ADMIN_PASSWORD):
        logger.error("Failed to set up admin user. Exiting.")
        return False

    # Step 2: Capture screenshots with Playwright
    logger.info("\n" + "="*70)
    logger.info("PHASE 2: Screenshot Capture")
    logger.info("="*70)

    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    try:
        async with async_playwright() as p:
            # Launch browser (headless for speed, visible if needed for debugging)
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={"width": 1920, "height": 1080},
                ignore_https_errors=True
            )
            page = await context.new_page()

            # Set default timeout
            page.set_default_timeout(30000)

            # Navigate to home and login
            logger.info(f"\nConnecting to {TOOLKIT_URL}...")
            try:
                await page.goto(TOOLKIT_URL, wait_until="networkidle")
            except Exception:
                # Timeout is OK, page may have loaded
                await asyncio.sleep(2)

            # Check if we need to login
            current_url = page.url
            if "/login" in current_url or await page.query_selector("input[type='password']"):
                if not await login_to_app(page, DEMO_ADMIN_USERNAME, DEMO_ADMIN_PASSWORD):
                    await browser.close()
                    return False
            else:
                logger.info("✓ Already authenticated (session exists)")

            # Capture each section
            logger.info("\nCapturing UI screenshots...")
            successful = 0

            for idx, (name, path, description) in enumerate(SCREENSHOTS, 1):
                try:
                    # Navigate to section
                    url = f"{TOOLKIT_URL}{path}"
                    logger.info(f"\n[{idx}/{len(SCREENSHOTS)}] {name}: {path}")

                    await page.goto(url, wait_until="networkidle", timeout=15000)
                    await asyncio.sleep(1.5)  # Wait for dynamic content to load

                    # For Support Tools sub-tabs, click the correct tab before capture
                    if path == "/deploy":
                        tab_map = {
                            "Windows Helpers": "windows",
                            "Linux Helpers": "linux",
                        }
                        if name in tab_map:
                            try:
                                await page.locator(f"button[data-tab='{tab_map[name]}']").click(timeout=2000)
                                await asyncio.sleep(0.8)
                            except Exception:
                                pass

                    # Generate filename
                    safe_name = name.lower().replace(" ", "-")
                    filename = f"{idx:02d}-{safe_name}.png"
                    filepath = SCREENSHOT_DIR / filename

                    # Capture full page screenshot
                    await page.screenshot(path=str(filepath), full_page=True)
                    logger.info(f"  ✓ {filename}")
                    successful += 1

                except Exception as e:
                    logger.warning(f"  ✗ Failed to capture {name}: {e}")
                    continue

            await browser.close()

            # Summary
            logger.info("\n" + "="*70)
            logger.info("Screenshot Capture Complete!")
            logger.info(f"Successful: {successful}/{len(SCREENSHOTS)}")
            logger.info(f"Saved to: {SCREENSHOT_DIR}")
            logger.info("="*70 + "\n")

            return successful == len(SCREENSHOTS)

    except Exception as e:
        logger.error(f"Error during screenshot capture: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("\n" + "="*70)
    print("Security Audit Toolkit - Authenticated Screenshot Capture")
    print("="*70)
    print(f"Target URL: {TOOLKIT_URL}")
    print(f"Admin User: {DEMO_ADMIN_USERNAME}")
    print(f"Screenshot Directory: {SCREENSHOT_DIR}")
    print("="*70 + "\n")

    # Run the async function
    success = asyncio.run(capture_screenshots())

    sys.exit(0 if success else 1)
