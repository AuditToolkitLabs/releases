#!/usr/bin/env python3
"""
Enhanced Playwright screenshot capture for Security Audit Toolkit
Automatically navigates and captures all major UI sections
"""

import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

BASE_URL = "http://localhost:5000"
SCREENSHOTS_DIR = Path("docs/screenshots")
SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

async def capture_screenshots():
    """Capture all UI screenshots using Playwright"""

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(viewport={"width": 1920, "height": 1080})
        page = await context.new_page()

        print("🎬 Starting screenshot capture from http://localhost:5000")
        print(f"📁 Saving to: {SCREENSHOTS_DIR.resolve()}\n")

        try:
            # Navigate to app
            await page.goto(BASE_URL, wait_until="networkidle")
            print("✓ Connected to http://localhost:5000\n")

            # Wait for initial load
            await page.wait_for_timeout(2000)

            # Define screenshots to capture with navigation paths
            screenshots_config = [
                ("01-audit-admin-tools-home.png", "/", "Audit Admin Tools Home"),
                ("02-audit-admin-tools-overview.png", "/overview", "Overview"),
                ("03-audit-admin-tools-console.png", "/console", "Console"),
                ("04-audit-admin-tools-audit-selection.png", "/targets", "Audit Targets"),
                ("06-audit-admin-tools-reports-tab.png", "/reports", "Reports"),
                ("07-audit-admin-tools-schedule-tab.png", "/schedules", "Schedules"),
                ("08-audit-admin-tools-destination-policy-management.png", "/settings", "Settings"),
                ("09-audit-admin-tools-admin-page.png", "/admin", "Admin"),
                ("13-asset-discovery-direct-api-reports-tab.png", "/asset-discovery", "Asset Discovery"),
                ("14-asset-discovery-assets.png", "/asset-discovery/assets", "Assets"),
                ("15-asset-discovery-vulnerabilities.png", "/asset-discovery/vulnerabilities", "Vulnerabilities"),
                ("16-asset-discovery-scans-target.png", "/asset-discovery/scans", "Scans"),
                ("10-audit-admin-tools-script-studio.png", "/script-studio", "Script Studio"),
                ("19-audit-admin-tools-support-tools.png", "/deploy", "Support Tools"),
                ("20-audit-admin-tools-windows-helpers.png", "/deploy", "Windows Helpers"),
                ("21-audit-admin-tools-linux-helpers.png", "/deploy", "Linux Helpers"),
            ]

            captured = 0

            for filename, path, description in screenshots_config:
                try:
                    # Navigate to path
                    url = f"{BASE_URL}{path}"
                    await page.goto(url, wait_until="domcontentloaded")
                    await page.wait_for_timeout(1500)

                    # Click the appropriate Support Tools tab if needed
                    if path == "/deploy":
                        if "windows" in filename:
                            try:
                                await page.locator("button[data-tab='windows']").click(timeout=2000)
                                await page.wait_for_timeout(600)
                            except Exception:
                                pass
                        elif "linux" in filename:
                            try:
                                await page.locator("button[data-tab='linux']").click(timeout=2000)
                                await page.wait_for_timeout(600)
                            except Exception:
                                pass

                    # Capture screenshot
                    filepath = SCREENSHOTS_DIR / filename
                    await page.screenshot(path=str(filepath))
                    print(f"  ✓ {filename:40} - {description}")
                    captured += 1

                except Exception as e:
                    print(f"  ⚠ {filename:40} - Error: {str(e)[:50]}")

            print("\n✅ Screenshot capture complete!")
            print(f"📊 Captured: {captured}/{len(screenshots_config)}")
            print(f"📁 Location: {SCREENSHOTS_DIR.resolve()}")

        except Exception as e:
            print(f"❌ Error: {e}")
        finally:
            await context.close()
            await browser.close()

if __name__ == "__main__":
    print("=" * 70)
    print("Security Audit Toolkit - Playwright Screenshot Capture Tool")
    print("=" * 70)
    print()

    asyncio.run(capture_screenshots())
