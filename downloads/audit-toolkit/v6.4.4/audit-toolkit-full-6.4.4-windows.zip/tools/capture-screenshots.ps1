﻿<#
.SYNOPSIS
    Helper script to capture screenshots for Security Audit Toolkit documentation.

.DESCRIPTION
    This script:
    1. Starts the web application
    2. Opens key pages in your default browser
    3. Provides instructions for capturing screenshots

.EXAMPLE
    .\tools\capture-screenshots.ps1
#>

param(
    [bool]$StartServer = $true,
    [int]$Port = 5000,
    [string]$AssetDiscoveryUrl = "http://localhost:5000/asset-discovery",
    [switch]$MissingOnly,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$BaseUrl = "http://localhost:$Port"

Write-Output @"

============================================================
  📸 Screenshot Capture Helper
============================================================

This script will help you capture screenshots for the README.

REQUIRED TOOLS (pick one):
  • Windows Snipping Tool (Win+Shift+S)
  • Browser DevTools (F12 → Ctrl+Shift+P → "screenshot")
  • GoFullPage browser extension

SAVE LOCATION:
  $PSScriptRoot\..\docs\screenshots\

SCOPE:
    • Core Audit Toolkit (login, overview, dashboard, console, reports, admin)
    • Developer Script Studio
    • Asset Discovery (dashboard/assets/vulns/scans/scheduled/settings)

"@ -ForegroundColor Cyan

# Check if server is running
$serverRunning = $false
try {
    Invoke-WebRequest -Uri $BaseUrl -TimeoutSec 2 -ErrorAction SilentlyContinue | Out-Null
    $serverRunning = $true
    Write-Output "✓ Web server already running at $BaseUrl"
} catch {
    Write-Output "○ Web server not running"
}

if (-not $serverRunning -and $StartServer) {
    Write-Output "`nStarting web server..."
    Write-Output "  cd web && python app.py`n"

    # Start server in background
    Start-Process -FilePath "python" -ArgumentList "app.py" -WorkingDirectory "$PSScriptRoot\..\web" -PassThru -WindowStyle Minimized | Out-Null

    # Wait for server to start
    $attempts = 0
    while ($attempts -lt 10) {
        Start-Sleep -Seconds 1
        try {
            Invoke-WebRequest -Uri $BaseUrl -TimeoutSec 2 -ErrorAction SilentlyContinue | Out-Null
            $serverRunning = $true
            break
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        $attempts++
    }

    if ($serverRunning) {
        Write-Output "✓ Server started successfully"
    } else {
        Write-Output "✗ Could not start server. Start manually: cd web && python app.py"
        exit 1
    }
}

# Define pages to capture
$pages = @(
    @{ Url = "/auth/login"; File = "01-audit-admin-tools-login.png"; Description = "Login" },
    @{ Url = "/overview"; File = "02-audit-admin-tools-overview.png"; Description = "Overview" },
    @{ Url = "/dashboard"; File = "audit-admin-tools-dashboard.png"; Description = "Dashboard" },
    @{ Url = "/console"; File = "05-audit-admin-tools-discovery-tab.png"; Description = "Console - Targets section" },
    @{ Url = "/reports"; File = "06-audit-admin-tools-reports-tab.png"; Description = "Reports" },
    @{ Url = "/console"; File = "07-audit-admin-tools-schedule-tab.png"; Description = "Console - Schedules section" },
    @{ Url = "/console"; File = "08-audit-admin-tools-destination-policy-management.png"; Description = "Console - Settings section" },
    @{ Url = "/admin/users"; File = "09-audit-admin-tools-user-mgmt.png"; Description = "Admin Users" },
    @{ Url = "/script-studio"; File = "10-audit-admin-tools-script-studio.png"; Description = "Script Studio" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "13-asset-discovery-dashboard.png"; Description = "Asset Discovery - Dashboard" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "14-asset-discovery-assets.png"; Description = "Asset Discovery - Assets" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "15-asset-discovery-vulnerabilities.png"; Description = "Asset Discovery - Vulnerabilities" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "16-asset-discovery-scans-target.png"; Description = "Asset Discovery - Scans" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "17-asset-discovery-scheduled.png"; Description = "Asset Discovery - Scheduled Scans" },
    @{ AbsoluteUrl = "$AssetDiscoveryUrl"; File = "18-asset-discovery-settings.png"; Description = "Asset Discovery - Settings" },
    @{ Url = "/deploy"; File = "19-audit-admin-tools-support-tools.png"; Description = "Support Tools - main tab" },
    @{ Url = "/deploy"; File = "20-audit-admin-tools-windows-helpers.png"; Description = "Support Tools - Windows Helpers tab (click tab before capture)" },
    @{ Url = "/deploy"; File = "21-audit-admin-tools-linux-helpers.png"; Description = "Support Tools - Linux Helpers tab (click tab before capture)" }
)

$screenshotDir = "$PSScriptRoot\..\docs\screenshots"
if (-not (Test-Path $screenshotDir)) {
    New-Item -ItemType Directory -Path $screenshotDir -Force | Out-Null
    Write-Output "Created: $screenshotDir"
}

if ($MissingOnly) {
    $pages = $pages | Where-Object {
        -not (Test-Path (Join-Path $screenshotDir $_.File))
    }
}

Write-Output @"

============================================================
  Pages to Capture
============================================================
"@ -ForegroundColor Cyan

if ($MissingOnly) {
    Write-Output "Mode: Missing-only"
}

if ($DryRun) {
    Write-Output "Mode: Dry-run (no browser tabs will open)"
}

if ($pages.Count -eq 0) {
    Write-Output "\n✓ No screenshots pending. Release set is complete."
    exit 0
}

foreach ($page in $pages) {
    $filePath = Join-Path $screenshotDir $page.File
    $exists = Test-Path $filePath
    $status = if ($exists) { "✓" } else { "○" }

    Write-Output "  $status $($page.Description.PadRight(20)) → $($page.File)"
}

Write-Output @"

============================================================
  Ready to Capture!
============================================================

Opening browser pages one at a time.
Press ENTER after capturing each screenshot.

"@ -ForegroundColor Cyan

foreach ($page in $pages) {
    $fullUrl = if ($page.ContainsKey("AbsoluteUrl")) { $page.AbsoluteUrl } else { "$BaseUrl$($page.Url)" }
    $filePath = Join-Path $screenshotDir $page.File

    Write-Output "`n📸 Capture: $($page.Description)"
    Write-Output "   URL: $fullUrl"
    Write-Output "   Save as: $($page.File)"
    Write-Output "   Note: adjust in-page tab/section before capture if needed"

    if ($DryRun) {
        $exists = Test-Path $filePath
        $status = if ($exists) { "✓ already exists" } else { "○ missing" }
        Write-Output "   Status: $status"
    } else {
        # Open in browser
        Start-Process $fullUrl

        Read-Host "   Press ENTER when saved"

        if (Test-Path $filePath) {
            Write-Output "   ✓ Found: $($page.File)"
        } else {
            Write-Output "   ⚠ Not found yet - save to: $screenshotDir\$($page.File)"
        }
    }
}

Write-Output @"

============================================================
  📸 Screenshot Capture Complete
============================================================

Next steps:
1. Review screenshots in: $screenshotDir
2. Commit: git add docs/screenshots/*.png
3. Push: git push origin main

Screenshots will appear in README.md automatically.

"@ -ForegroundColor Green
