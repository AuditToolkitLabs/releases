#!/usr/bin/env python3
"""
Playwright Screenshot Capture Script for v5.1.5 release docs.

Usage:
  python tools/capture-screenshots.py --missing-only
  python tools/capture-screenshots.py --all

Environment variables:
  APP_URL (default: http://localhost:5000)
  ASSET_DISCOVERY_URL (default: http://localhost:5000/asset-discovery)
  ADMIN_USER (default: admin)
  ADMIN_PASS (default: admin)
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("Error: Playwright is not installed.")
    print("Install with: pip install playwright && playwright install chromium")
    sys.exit(1)

BASE_URL = os.environ.get("APP_URL", "http://localhost:5000")
ASSET_DISCOVERY_URL = os.environ.get("ASSET_DISCOVERY_URL", f"{BASE_URL}/asset-discovery")
SCREENSHOT_DIR = Path(__file__).parent.parent / "docs" / "screenshots"
ADMIN_USER = os.environ.get("ADMIN_USER") or os.environ.get("ADMIN_USERNAME") or "admin"
ADMIN_PASS = os.environ.get("ADMIN_PASS") or os.environ.get("ADMIN_PASSWORD") or "admin"
VIEWPORT = {"width": 1920, "height": 1080}

SHOTS = [
    {"name": "01-login", "kind": "page", "url": f"{BASE_URL}/auth/login", "selector": "form"},
    {"name": "02-overview", "kind": "page", "url": f"{BASE_URL}/overview", "selector": "main, body"},
    {"name": "03-dashboard", "kind": "page", "url": f"{BASE_URL}/dashboard", "selector": "main, body"},
    {"name": "04-console-audits", "kind": "console", "section": "audits"},
    {"name": "05-console-targets", "kind": "console", "section": "connect"},
    {"name": "06-reports", "kind": "page", "url": f"{BASE_URL}/reports", "selector": "main, body"},
    {"name": "07-schedules", "kind": "console", "section": "schedule"},
    {"name": "08-settings", "kind": "console", "section": "settings"},
    {"name": "09-admin-users", "kind": "page", "url": f"{BASE_URL}/admin/users", "selector": "main, body"},
    {"name": "10-script-studio", "kind": "page", "url": f"{BASE_URL}/script-studio", "selector": "main, body"},
    {"name": "11-script-templates", "kind": "script_studio", "section": "templates"},
    {"name": "12-script-validation", "kind": "script_studio", "section": "validation"},
    {"name": "13-asset-discovery-dashboard", "kind": "asset", "panel": "dashboard"},
    {"name": "14-asset-discovery-assets", "kind": "asset", "panel": "assets"},
    {"name": "15-asset-discovery-vulnerabilities", "kind": "asset", "panel": "vulnerabilities"},
    {"name": "16-asset-discovery-scans", "kind": "asset", "panel": "scans"},
    {"name": "17-asset-discovery-scheduled", "kind": "asset", "panel": "scheduled-scans"},
    {"name": "18-asset-discovery-settings", "kind": "asset", "panel": "settings"},
    {"name": "19-audit-admin-tools-support-tools", "kind": "deploy", "tab": "support-tools"},
    {"name": "20-audit-admin-tools-windows-helpers", "kind": "deploy", "tab": "windows"},
    {"name": "21-audit-admin-tools-linux-helpers", "kind": "deploy", "tab": "linux"},
]


async def wait_for_any(page, selectors: list[str], timeout: int = 6000) -> None:
    for selector in selectors:
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            return
        except Exception:
            continue


async def login(page, username: str, password: str) -> bool:
    await page.goto(f"{BASE_URL}/auth/login")
    await page.wait_for_load_state("networkidle")

    try:
        await page.fill("#username", username)
        await page.fill("#password", password)
    except Exception:
        return False

    try:
        async with page.expect_navigation(timeout=15000):
            await page.click("#login-btn, button[type='submit']")
    except Exception:
        return False

    await page.wait_for_load_state("networkidle")
    return "/auth/login" not in page.url and "/login" not in page.url


async def capture_png(page, name: str) -> Path:
    path = SCREENSHOT_DIR / f"{name}.png"
    await asyncio.sleep(0.4)
    await page.screenshot(path=str(path), full_page=False)
    return path


async def get_console_frame(page):
    await page.wait_for_selector("iframe", timeout=10000)
    iframe = await page.query_selector("iframe")
    if iframe is None:
        raise RuntimeError("console iframe not found")

    frame = await iframe.content_frame()
    if frame is None:
        raise RuntimeError("console iframe content is unavailable")

    await frame.wait_for_load_state("domcontentloaded")
    await wait_for_any(frame, [".tab-button[data-tab='audits']", "#settings-btn", "body"], timeout=10000)
    return frame


async def get_asset_discovery_frame(page):
    if await page.locator("nav a[data-panel='dashboard']").count() > 0:
        await wait_for_any(page, ["nav a[data-panel='dashboard']", "#dashboard", "body"], timeout=10000)
        return page

    iframe = await page.query_selector("iframe")
    if iframe is None:
        raise RuntimeError("asset discovery navigation surface not found")

    frame = await iframe.content_frame()
    if frame is None:
        raise RuntimeError("asset discovery iframe content is unavailable")

    await frame.wait_for_load_state("domcontentloaded")
    await wait_for_any(frame, ["nav a[data-panel='dashboard']", "#dashboard", "body"], timeout=10000)
    return frame


async def open_console_section(page, section: str) -> None:
    await page.goto(f"{BASE_URL}/console")
    await page.wait_for_load_state("networkidle")
    frame = await get_console_frame(page)

    if section == "settings":
        await frame.locator("#settings-btn").click(timeout=3000)
        await wait_for_any(frame, ["#settings-modal", "#smtp-host", "#email-settings-form"], timeout=7000)
        await frame.evaluate(
            """
            () => {
                const modal = document.getElementById('settings-modal');
                if (modal) {
                    modal.style.display = 'flex';
                }
            }
            """
        )
        await asyncio.sleep(0.6)
        return

    await frame.locator(f".tab-button[data-tab='{section}']").click(timeout=3000)
    await wait_for_any(frame, [f"#{section}-tab.active", f"#{section}-tab", ".tab-content.active"], timeout=7000)
    await asyncio.sleep(0.6)


async def open_script_studio_section(page, section: str) -> None:
    await page.goto(f"{BASE_URL}/script-studio")
    await page.wait_for_load_state("networkidle")
    if section == "templates":
        await page.locator("#btn-new").click(timeout=3000)
        await wait_for_any(page, ["#new-script-modal.active", "#script-template", "#script-name"], timeout=5000)
        await asyncio.sleep(0.5)
        return

    if section == "validation":
        file_path = await page.evaluate(
            """
            async () => {
                const response = await fetch('/api/script-studio/files');
                const data = await response.json();
                const stack = [...(data.tree || [])];

                while (stack.length) {
                    const item = stack.shift();
                    if (item.is_directory) {
                        stack.unshift(...(item.children || []));
                        continue;
                    }
                    if (item.path) {
                        return item.path;
                    }
                }

                return null;
            }
            """
        )

        if not file_path:
            raise RuntimeError("script studio file tree is empty")

        await page.evaluate("(path) => openFile(path)", file_path)
        await wait_for_any(page, ["#file-name", "#btn-validate"], timeout=7000)
        await page.locator("#btn-validate").click(timeout=3000)
        await asyncio.sleep(1.2)
        return

    await asyncio.sleep(0.5)


async def open_deploy_tab(page, tab: str) -> None:
    await page.goto(f"{BASE_URL}/deploy")
    await page.wait_for_load_state("networkidle")

    if tab != "support-tools":
        try:
            await page.locator(f"button[data-tab='{tab}']").click(timeout=3000)
        except Exception:
            pass
        await asyncio.sleep(0.6)


async def open_asset_panel(page, panel: str) -> None:
    await page.goto(ASSET_DISCOVERY_URL)
    await page.wait_for_load_state("networkidle")
    frame = await get_asset_discovery_frame(page)

    if panel != "dashboard":
        await frame.evaluate("(panel) => switchPanel(panel)", panel)
        await wait_for_any(frame, [f"nav a[data-panel='{panel}'].active", f"#{panel}.panel.active", f"#{panel}.active"], timeout=7000)
        await asyncio.sleep(0.8)
        return

    await wait_for_any(frame, ["nav a[data-panel='dashboard'].active", "#dashboard.panel.active", "#dashboard.active"], timeout=7000)


async def run_capture(missing_only: bool, headful: bool, username: str, password: str) -> int:
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    queue = SHOTS
    if missing_only:
        queue = [s for s in SHOTS if not (SCREENSHOT_DIR / f"{s['name']}.png").exists()]

    if not queue:
        print("No screenshots pending. Release set is complete.")
        return 0

    print("=" * 60)
    print("Playwright Screenshot Capture - v5.1.5")
    print("=" * 60)
    print(f"Target: {BASE_URL}")
    print(f"Asset Discovery: {ASSET_DISCOVERY_URL}")
    print(f"Output: {SCREENSHOT_DIR}")
    print(f"Mode: {'missing-only' if missing_only else 'all'}")

    captured: list[str] = []
    failed: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=not headful)
        context = await browser.new_context(viewport=VIEWPORT, device_scale_factor=1)
        page = await context.new_page()

        try:
            needs_auth = any(s["kind"] != "asset" and s["name"] != "01-login" for s in queue)

            for index, shot in enumerate(queue, start=1):
                name = shot["name"]
                print(f"\n[{index}/{len(queue)}] {name}")

                try:
                    if name == "01-login":
                        await page.goto(shot["url"])
                        await page.wait_for_load_state("networkidle")
                        await wait_for_any(page, [shot.get("selector", "body"), "body"])
                    else:
                        if needs_auth and "/auth/login" in page.url:
                            pass

                        if shot["kind"] in {"page", "console", "script_studio", "asset", "deploy"}:
                            if "/auth/login" in page.url or page.url == "about:blank":
                                ok = await login(page, username=username, password=password)
                                if not ok:
                                    raise RuntimeError("login failed (check --user/--password or ADMIN_USERNAME/ADMIN_PASSWORD)")

                        if shot["kind"] == "page":
                            await page.goto(shot["url"])
                            await page.wait_for_load_state("networkidle")
                            await wait_for_any(page, [shot.get("selector", "body"), "body"])
                        elif shot["kind"] == "console":
                            await open_console_section(page, shot["section"])
                        elif shot["kind"] == "script_studio":
                            await open_script_studio_section(page, shot["section"])
                        elif shot["kind"] == "asset":
                            await open_asset_panel(page, shot["panel"])
                        elif shot["kind"] == "deploy":
                            await open_deploy_tab(page, shot["tab"])

                    output = await capture_png(page, name)
                    captured.append(output.name)
                    print(f"  ✓ {output.name}")
                except Exception as exc:
                    failed.append(f"{name}: {exc}")
                    print(f"  ✗ {name}: {exc}")
        finally:
            await browser.close()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Captured: {len(captured)}")
    for item in captured:
        print(f"  ✓ {item}")

    if failed:
        print(f"Failed: {len(failed)}")
        for item in failed:
            print(f"  ✗ {item}")

    return 0 if not failed else 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture v5.1.5 screenshots with Playwright")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--missing-only", action="store_true", help="capture only missing files")
    mode.add_argument("--all", action="store_true", help="capture all files")
    parser.add_argument("--headful", action="store_true", help="run browser in headed mode")
    parser.add_argument("--user", default=None, help="login username")
    parser.add_argument("--password", default=None, help="login password")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    missing_only = not args.all
    username = args.user or ADMIN_USER
    password = args.password or ADMIN_PASS
    return asyncio.run(run_capture(missing_only=missing_only, headful=args.headful, username=username, password=password))


if __name__ == "__main__":
    raise SystemExit(main())
