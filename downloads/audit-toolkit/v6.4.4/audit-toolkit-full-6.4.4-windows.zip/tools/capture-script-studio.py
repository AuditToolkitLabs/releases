#!/usr/bin/env python3
"""
Capture Script Studio screenshot only.
Dedicated script to isolate and debug the login/session issue.
"""

import asyncio
import os
import sys
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("Error: Playwright not installed.")
    print("Run: pip install playwright && playwright install chromium")
    sys.exit(1)

BASE_URL = os.environ.get("APP_URL", "http://localhost:5000")
SCREENSHOT_DIR = Path(__file__).parent.parent / "screenshots"
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "admin")

async def main():
    """Capture Script Studio screenshot with detailed debugging."""
    print("=" * 60)
    print("Script Studio Screenshot Capture")
    print("=" * 60)
    print(f"Target: {BASE_URL}")
    print(f"User: {ADMIN_USER}")
    print()

    SCREENSHOT_DIR.mkdir(exist_ok=True)

    async with async_playwright() as p:
        print("Launching browser (headful for debugging)...")
        browser = await p.chromium.launch(
            headless=False,  # Show browser for debugging
            slow_mo=500,     # Slow down actions
        )
        context = await browser.new_context(
            viewport={"width": 1920, "height": 1080},
        )
        page = await context.new_page()

        # Enable console logging
        page.on("console", lambda msg: print(f"  [Browser] {msg.type}: {msg.text}"))

        try:
            # Step 1: Go to login page
            print("\n[1] Navigating to login page...")
            await page.goto(f"{BASE_URL}/auth/login")
            await page.wait_for_load_state("networkidle")
            print(f"  URL: {page.url}")

            # Check for existing error message (like account locked)
            error = await page.query_selector('.login-alert.error')
            if error:
                text = await error.text_content()
                ascii_text = text.encode('ascii', 'replace').decode()
                print(f"  Pre-existing error: {ascii_text.strip()}")

            # Step 2: Fill form
            print("\n[2] Filling login form...")
            await page.fill('#username', ADMIN_USER)
            await page.fill('#password', ADMIN_PASS)
            print(f"  Filled username: {ADMIN_USER}")
            print(f"  Filled password: {'*' * len(ADMIN_PASS)}")

            # Step 3: Submit and wait
            print("\n[3] Submitting form...")
            await page.click('#login-btn')

            # Wait for response
            await asyncio.sleep(3)
            await page.wait_for_load_state("networkidle")

            print(f"  Post-login URL: {page.url}")

            # Check cookies
            cookies = await context.cookies()
            print(f"  Cookies: {[c['name'] for c in cookies]}")

            # Step 4: Check if we got redirected to Script Studio or stayed on login
            if "/auth/login" in page.url:
                print("\n[!] Still on login page - checking for errors...")

                error = await page.query_selector('.login-alert.error')
                if error:
                    text = await error.text_content()
                    if text:
                        ascii_text = text.encode('ascii', 'replace').decode()
                        print(f"  Error: {ascii_text.strip()}")

                await page.screenshot(path=str(SCREENSHOT_DIR / "debug-login-failed.png"))
                print("  Saved: debug-login-failed.png")

                await browser.close()
                return 1

            # Step 5: Navigate to Script Studio
            print("\n[4] Navigating to Script Studio...")
            await page.goto(f"{BASE_URL}/script-studio")
            await page.wait_for_load_state("networkidle")
            await asyncio.sleep(2)
            print(f"  URL: {page.url}")

            # Check if redirected back to login
            if "/auth/login" in page.url:
                print("\n[!] Redirected to login - session issue!")
                await page.screenshot(path=str(SCREENSHOT_DIR / "debug-session-lost.png"))
                print("  Saved: debug-session-lost.png")
                await browser.close()
                return 1

            # Success! Capture screenshot
            print("\n[5] Capturing Script Studio...")
            await page.screenshot(path=str(SCREENSHOT_DIR / "09-script-studio.png"))
            print("  Saved: 09-script-studio.png")

            # Get file size
            size = (SCREENSHOT_DIR / "09-script-studio.png").stat().st_size / 1024
            print(f"  Size: {size:.1f} KB")

            if size > 500:
                print("  SUCCESS - Screenshot looks good!")
            else:
                print("  WARNING - Screenshot may be incomplete")

            print("\n[6] Keeping browser open for 10 seconds for inspection...")
            await asyncio.sleep(10)

        except Exception as e:
            print(f"\nError: {e}")
            import traceback
            traceback.print_exc()

        finally:
            await browser.close()

    print("\nDone!")
    return 0

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
