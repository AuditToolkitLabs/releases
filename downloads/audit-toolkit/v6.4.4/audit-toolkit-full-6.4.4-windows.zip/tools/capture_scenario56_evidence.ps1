param(
    [string]$CoreUrl = "http://localhost:5000",
    [string]$Username = "admin",
    [SecureString]$Password,
    [string]$Timestamp = ""
)

$ErrorActionPreference = "Stop"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function ConvertTo-PlainText {
    param([SecureString]$SecureValue)

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

if ([string]::IsNullOrWhiteSpace($Timestamp)) {
    $Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
}

if (-not $Password) {
    $Password = ConvertTo-InMemorySecureString -Value "ChangeMe123!"
}
$plainPassword = ConvertTo-PlainText -SecureValue $Password

$loginBody = @{ username = $Username; password = $plainPassword } | ConvertTo-Json
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$null = Invoke-WebRequest -Uri "$CoreUrl/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -WebSession $session -ErrorAction Stop
$key = ((Invoke-WebRequest -Uri "$CoreUrl/api/settings/api-key" -Method GET -WebSession $session -ErrorAction Stop).Content | ConvertFrom-Json).api_key
if ([string]::IsNullOrWhiteSpace($key)) {
    throw "Failed to resolve API key"
}
$headers = @{ "X-API-Key" = $key }

function Save-ProbeArtifacts {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
    param(
        [string]$TaskId,
        [string]$ScenarioPrefix,
        [string]$Timestamp,
        [string]$CoreUrl,
        [hashtable]$Headers
    )

    try {
        $statusRaw = (Invoke-WebRequest -Uri "$CoreUrl/api/batch/status/$TaskId" -Headers $Headers -UseBasicParsing -ErrorAction Stop).Content
    }
    catch {
        $statusRaw = $_.ErrorDetails.Message
        if ([string]::IsNullOrWhiteSpace($statusRaw)) { $statusRaw = $_.Exception.Message }
    }

    @{
        task_id = $TaskId
        captured_at = (Get-Date).ToString("o")
        status_probe = $statusRaw
    } | ConvertTo-Json -Depth 10 | Out-File -FilePath "$ScenarioPrefix-status-$Timestamp.json" -Encoding utf8

    try {
        $resultRaw = (Invoke-WebRequest -Uri "$CoreUrl/api/batch/results/$TaskId" -Headers $Headers -UseBasicParsing -ErrorAction Stop).Content
    }
    catch {
        $resultRaw = $_.ErrorDetails.Message
        if ([string]::IsNullOrWhiteSpace($resultRaw)) { $resultRaw = $_.Exception.Message }
    }

    @{
        task_id = $TaskId
        captured_at = (Get-Date).ToString("o")
        result_probe = $resultRaw
    } | ConvertTo-Json -Depth 10 | Out-File -FilePath "$ScenarioPrefix-result-$Timestamp.json" -Encoding utf8
}

# Scenario 5: Streaming mode (single target)
$payload5 = @{
    server_ids = @(2)
    audit_path = "audits/linux/platform/baseline/updates.sh"
    max_concurrent = 1
    timeout = 180
    stream_mode = $true
} | ConvertTo-Json -Depth 5

$start5 = (Invoke-WebRequest -Uri "$CoreUrl/api/batch/audits/execute" -Method POST -Headers $headers -Body $payload5 -ContentType "application/json" -UseBasicParsing -ErrorAction Stop).Content | ConvertFrom-Json
$start5 | ConvertTo-Json -Depth 20 | Out-File -FilePath "scenario5-stream-start-$Timestamp.json" -Encoding utf8
Save-ProbeArtifacts -TaskId $start5.task_id -ScenarioPrefix "scenario5-stream" -Timestamp $Timestamp -CoreUrl $CoreUrl -Headers $headers

# Scenario 6: Parallel mode (multi-target)
$payload6 = @{
    server_ids = @(1,2,3)
    audit_path = "audits/linux/platform/baseline/updates.sh"
    max_concurrent = 3
    timeout = 180
    stream_mode = $true
} | ConvertTo-Json -Depth 5

$start6 = (Invoke-WebRequest -Uri "$CoreUrl/api/batch/audits/execute" -Method POST -Headers $headers -Body $payload6 -ContentType "application/json" -UseBasicParsing -ErrorAction Stop).Content | ConvertFrom-Json
$start6 | ConvertTo-Json -Depth 20 | Out-File -FilePath "scenario6-parallel-start-$Timestamp.json" -Encoding utf8
Save-ProbeArtifacts -TaskId $start6.task_id -ScenarioPrefix "scenario6-parallel" -Timestamp $Timestamp -CoreUrl $CoreUrl -Headers $headers

# Security hardening evidence: run targeted encryption regression tests
$securityEvidenceFile = "scenario56-security-tests-$Timestamp.txt"
$testCommand = "python tests/test_security_startup_checks.py && python tests/test_encryption_helpers.py && python tests/test_database_encryption_columns.py && python tests/test_encryption_column_coverage_phase2.py"

Write-Output "Running security regression tests for evidence capture..."
& docker compose exec web /bin/sh -lc $testCommand 2>&1 | Tee-Object -FilePath $securityEvidenceFile
if ($LASTEXITCODE -ne 0) {
    throw "Security regression test evidence capture failed (exit code: $LASTEXITCODE). See $securityEvidenceFile"
}

Write-Output "Scenario 5 task: $($start5.task_id)"
Write-Output "Scenario 6 task: $($start6.task_id)"
Write-Output "Security test evidence: $securityEvidenceFile"
Write-Output "Evidence timestamp: $Timestamp"
