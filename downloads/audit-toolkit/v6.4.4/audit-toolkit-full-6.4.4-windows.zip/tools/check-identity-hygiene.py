#!/usr/bin/env python3
"""Fail CI if banned personal identifiers are present in tracked text files."""

from __future__ import annotations

import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Rule:
    name: str
    pattern: re.Pattern[str]


RULES: tuple[Rule, ...] = (
    Rule("direct_gmail_address", re.compile(r"\b[A-Z0-9._%+-]+@gmail\.com\b", re.IGNORECASE)),
    Rule("direct_outlook_address", re.compile(r"\b[A-Z0-9._%+-]+@outlook\.com\b", re.IGNORECASE)),
)

ALLOWLIST_MATCHES: tuple[re.Pattern[str], ...] = (
    re.compile(r"your-email@gmail\.com", re.IGNORECASE),
    re.compile(r"account@gmail\.com", re.IGNORECASE),
)

SKIP_PATH_PREFIXES = (
    ".git/",
)

SKIP_PATHS = {
    "tools/check-identity-hygiene.py",
}

SKIP_SUFFIXES = (
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".ico",
    ".pdf",
    ".zip",
    ".gz",
    ".tar",
    ".7z",
    ".exe",
    ".dll",
    ".so",
    ".dylib",
    ".woff",
    ".woff2",
    ".ttf",
)


def _run_git_ls_files() -> list[Path]:
    result = subprocess.run(
        ["git", "ls-files"],
        capture_output=True,
        text=True,
        check=True,
    )
    paths: list[Path] = []
    for raw in result.stdout.splitlines():
        if not raw.strip():
            continue
        p = Path(raw.strip())
        as_posix = p.as_posix()
        if any(as_posix.startswith(prefix) for prefix in SKIP_PATH_PREFIXES):
            continue
        if as_posix in SKIP_PATHS:
            continue
        if p.suffix.lower() in SKIP_SUFFIXES:
            continue
        paths.append(p)
    return paths


def _is_binary(data: bytes) -> bool:
    return b"\x00" in data


def _scan_file(path: Path) -> list[str]:
    try:
        raw = path.read_bytes()
    except OSError:
        return []

    if _is_binary(raw):
        return []

    text = raw.decode("utf-8", errors="replace")
    findings: list[str] = []

    for line_no, line in enumerate(text.splitlines(), start=1):
        for rule in RULES:
            match = rule.pattern.search(line)
            if not match:
                continue

            matched_value = match.group(0)
            if any(allow.fullmatch(matched_value) for allow in ALLOWLIST_MATCHES):
                continue

            findings.append(f"{path.as_posix()}:{line_no}: {rule.name}: {line.strip()}")

    return findings


def main() -> int:
    try:
        files = _run_git_ls_files()
    except subprocess.CalledProcessError as exc:
        print(f"identity-hygiene: failed to enumerate files: {exc}", file=sys.stderr)
        return 2

    all_findings: list[str] = []
    for file_path in files:
        all_findings.extend(_scan_file(file_path))

    if all_findings:
        print("identity-hygiene: banned personal identifier(s) found:", file=sys.stderr)
        for finding in all_findings:
            print(f"  - {finding}", file=sys.stderr)
        return 1

    print("identity-hygiene: PASS (no banned personal identifiers found)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
