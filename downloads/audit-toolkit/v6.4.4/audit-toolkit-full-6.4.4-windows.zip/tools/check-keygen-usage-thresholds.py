#!/usr/bin/env python3
"""Check Keygen license usage against configurable warning thresholds.

This utility queries Keygen licenses for an account and compares usage against an
ALU limit so teams can get an early warning before hitting hard limits.

Notes:
- ALU billing is based on activity over a 90-day window in Keygen.
- This script uses license counts as a practical proxy for early alerting.

Exit codes:
- 0: OK (below warning thresholds)
- 1: WARN (one or more warning thresholds reached)
- 2: ERROR (configuration or API failure)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence

import requests


DEFAULT_API_URL = "https://api.keygen.sh/v1"
DEFAULT_ALU_LIMIT = 100
DEFAULT_THRESHOLDS = "70,80,90"
REQUEST_TIMEOUT_SECONDS = 20


def normalize_api_key(api_key: str) -> str:
    """Normalize API key input from env/secrets.

    Accepts either raw tokens or values prefixed with "Bearer ".
    """
    token = api_key.strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    return token


@dataclass
class UsageReport:
    account_id: str
    api_url: str
    total_licenses: int
    active_licenses: int
    alu_limit: int
    usage_percent: float
    thresholds: List[int]
    triggered_thresholds: List[int]
    tier_counts: Dict[str, int]
    rate_limit_window: Optional[Dict[str, int]] = None

    @property
    def status(self) -> str:
        if self.triggered_thresholds:
            return "WARN"
        return "OK"


def parse_thresholds(raw_thresholds: str) -> List[int]:
    """Parse comma-separated threshold percentages."""
    values: List[int] = []
    for raw_value in raw_thresholds.split(","):
        stripped_value = raw_value.strip()
        if not stripped_value:
            continue
        parsed_value = int(stripped_value)
        if parsed_value <= 0 or parsed_value >= 100:
            raise ValueError(f"Threshold must be between 1 and 99: {parsed_value}")
        values.append(parsed_value)

    if not values:
        raise ValueError("At least one threshold is required")

    return sorted(set(values))


def get_rate_limit_window(headers: Dict[str, str]) -> Optional[Dict[str, int]]:
    """Extract best-effort rate-limit window from response headers."""
    limit_keys = ("RateLimit-Limit", "X-RateLimit-Limit")
    remaining_keys = ("RateLimit-Remaining", "X-RateLimit-Remaining")

    limit_value: Optional[int] = None
    remaining_value: Optional[int] = None

    for key_name in limit_keys:
        value = headers.get(key_name)
        if value and value.isdigit():
            limit_value = int(value)
            break

    for key_name in remaining_keys:
        value = headers.get(key_name)
        if value and value.isdigit():
            remaining_value = int(value)
            break

    if limit_value is None or remaining_value is None:
        return None

    return {
        "limit": limit_value,
        "remaining": remaining_value,
        "used": max(0, limit_value - remaining_value),
    }


def normalize_api_url(api_url: str) -> str:
    """Normalize a Keygen API URL string."""
    return api_url.rstrip("/")


def iter_licenses(
    session: requests.Session,
    api_url: str,
    account_id: str,
    page_size: int = 100,
) -> Iterable[Dict[str, Any]]:
    """Iterate all licenses from Keygen with pagination."""
    next_url = f"{api_url}/accounts/{account_id}/licenses"
    params: Optional[Dict[str, str]] = {
        "page[size]": str(page_size),
        "page[number]": "1",
    }

    while next_url:
        response = session.get(next_url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
        if response.status_code != 200:
            raise RuntimeError(
                f"Keygen API returned {response.status_code}: {response.text[:500]}"
            )

        payload = response.json()
        for license_resource in payload.get("data", []):
            yield license_resource

        links = payload.get("links") or {}
        next_link = links.get("next")

        if isinstance(next_link, dict):
            next_link = next_link.get("href")

        if isinstance(next_link, str) and next_link:
            if next_link.startswith("http"):
                next_url = next_link
            else:
                next_url = f"{api_url}{next_link}"
            params = None
        else:
            next_url = ""


def build_usage_report(
    api_key: str,
    account_id: str,
    api_url: str,
    alu_limit: int,
    thresholds: Sequence[int],
) -> UsageReport:
    """Build usage report from Keygen account data."""
    if alu_limit <= 0:
        raise ValueError("ALU limit must be greater than 0")

    session = requests.Session()
    normalized_api_key = normalize_api_key(api_key)
    session.headers.update(
        {
            "Authorization": f"Bearer {normalized_api_key}",
            "Accept": "application/vnd.api+json",
            "Content-Type": "application/vnd.api+json",
        }
    )

    total_licenses = 0
    active_licenses = 0
    missing_status_count = 0
    tier_counts: Dict[str, int] = {}

    probe_response = session.get(
        f"{api_url}/accounts/{account_id}/licenses",
        params={
            "page[size]": "1",
            "page[number]": "1",
        },
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    if probe_response.status_code != 200:
        raise RuntimeError(
            f"Keygen API returned {probe_response.status_code}: {probe_response.text[:500]}"
        )

    rate_limit_window = get_rate_limit_window(dict(probe_response.headers))

    for license_resource in iter_licenses(session, api_url, account_id):
        total_licenses += 1
        attributes = license_resource.get("attributes") or {}
        metadata = attributes.get("metadata") or {}

        tier_name = (
            metadata.get("tier")
            or metadata.get("licenseTier")
            or "unknown"
        )
        tier_counts[tier_name] = tier_counts.get(tier_name, 0) + 1

        status = attributes.get("status")
        if status is None:
            missing_status_count += 1
            continue

        if str(status).upper() == "ACTIVE":
            active_licenses += 1

    if total_licenses > 0 and missing_status_count == total_licenses:
        active_licenses = total_licenses

    usage_percent = round((active_licenses / alu_limit) * 100, 2)
    triggered_thresholds = [value for value in thresholds if usage_percent >= value]

    return UsageReport(
        account_id=account_id,
        api_url=api_url,
        total_licenses=total_licenses,
        active_licenses=active_licenses,
        alu_limit=alu_limit,
        usage_percent=usage_percent,
        thresholds=list(thresholds),
        triggered_thresholds=triggered_thresholds,
        tier_counts=dict(sorted(tier_counts.items(), key=lambda item: item[0])),
        rate_limit_window=rate_limit_window,
    )


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Check Keygen usage against warning thresholds",
    )
    parser.add_argument("--api-key", default=os.environ.get("KEYGEN_API_KEY"))
    parser.add_argument("--account-id", default=os.environ.get("KEYGEN_ACCOUNT_ID"))
    parser.add_argument(
        "--api-url",
        default=os.environ.get("KEYGEN_API_URL", DEFAULT_API_URL),
        help=f"Keygen API base URL (default: {DEFAULT_API_URL})",
    )
    parser.add_argument(
        "--alu-limit",
        type=int,
        default=int(os.environ.get("KEYGEN_ALU_LIMIT", DEFAULT_ALU_LIMIT)),
        help=f"ALU limit for threshold calculation (default: {DEFAULT_ALU_LIMIT})",
    )
    parser.add_argument(
        "--thresholds",
        default=os.environ.get("KEYGEN_WARN_THRESHOLDS", DEFAULT_THRESHOLDS),
        help="Comma-separated warning thresholds, e.g. 70,80,90",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print JSON output only",
    )
    return parser.parse_args()


def report_to_dict(report: UsageReport) -> Dict[str, Any]:
    """Serialize report for JSON output."""
    return {
        "status": report.status,
        "account_id": report.account_id,
        "api_url": report.api_url,
        "usage": {
            "active_licenses": report.active_licenses,
            "total_licenses": report.total_licenses,
            "alu_limit": report.alu_limit,
            "percent": report.usage_percent,
            "thresholds": report.thresholds,
            "triggered_thresholds": report.triggered_thresholds,
        },
        "tiers": report.tier_counts,
        "rate_limit_window": report.rate_limit_window,
    }


def print_human_report(report: UsageReport) -> None:
    """Print human-friendly usage report."""
    payload = report_to_dict(report)
    usage = payload["usage"]

    print("KEYGEN USAGE THRESHOLD CHECK")
    print("=" * 32)
    print(f"Status: {payload['status']}")
    print(f"Account: {payload['account_id']}")
    print(f"API URL: {payload['api_url']}")
    print()
    print("Usage")
    print(f"- Active licenses: {usage['active_licenses']}")
    print(f"- Total licenses: {usage['total_licenses']}")
    print(f"- ALU limit: {usage['alu_limit']}")
    print(f"- Usage percent: {usage['percent']}%")
    print(f"- Thresholds: {', '.join(str(value) for value in usage['thresholds'])}%")

    if usage["triggered_thresholds"]:
        reached = ", ".join(f"{value}%" for value in usage["triggered_thresholds"])
        print(f"- Triggered: {reached}")

    if payload["tiers"]:
        print()
        print("Tier counts")
        for tier_name, count in payload["tiers"].items():
            print(f"- {tier_name}: {count}")

    if payload["rate_limit_window"]:
        window = payload["rate_limit_window"]
        print()
        print("Rate-limit window (from response headers)")
        print(f"- Limit: {window['limit']}")
        print(f"- Used: {window['used']}")
        print(f"- Remaining: {window['remaining']}")


def main() -> int:
    """Program entrypoint."""
    args = parse_args()

    if not args.api_key or not args.account_id:
        print(
            "Missing configuration: provide KEYGEN_API_KEY and KEYGEN_ACCOUNT_ID "
            "(or --api-key/--account-id)",
            file=sys.stderr,
        )
        return 2

    try:
        thresholds = parse_thresholds(args.thresholds)
        normalized_api_url = normalize_api_url(args.api_url)

        report = build_usage_report(
            api_key=args.api_key,
            account_id=args.account_id,
            api_url=normalized_api_url,
            alu_limit=args.alu_limit,
            thresholds=thresholds,
        )
    except Exception as error:
        print(f"Usage monitor failed: {error}", file=sys.stderr)
        return 2

    payload = report_to_dict(report)
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print_human_report(report)

    return 1 if report.status == "WARN" else 0


if __name__ == "__main__":
    sys.exit(main())
