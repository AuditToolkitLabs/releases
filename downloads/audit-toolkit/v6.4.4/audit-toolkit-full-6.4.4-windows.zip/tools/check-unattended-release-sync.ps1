[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = '',

    [Parameter()]
    [string]$ReleaseTag = '',

    [Parameter()]
    [string]$Repo = '',

    [Parameter()]
    [string]$StagingDirectory = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-RepoSlug {
    param([string]$ExplicitRepo)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRepo)) {
        return $ExplicitRepo.Trim()
    }

    $origin = (& git config --get remote.origin.url 2>$null)
    if ([string]::IsNullOrWhiteSpace($origin)) {
        throw 'Unable to determine repository slug. Provide -Repo owner/name.'
    }

    $origin = $origin.Trim()
    if ($origin -match 'github\.com[:/](?<slug>[^/]+/[^/.]+)(?:\.git)?$') {
        return $Matches['slug']
    }

    throw "Unsupported remote URL format for GitHub repo detection: $origin"
}

function Resolve-Version {
    param(
        [string]$ExplicitVersion,
        [string]$RepoRoot
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitVersion)) {
        return $ExplicitVersion.Trim()
    }

    $versionFile = Join-Path $RepoRoot 'VERSION'
    if (-not (Test-Path -LiteralPath $versionFile)) {
        throw "VERSION file not found at: $versionFile"
    }

    $detected = (Get-Content -LiteralPath $versionFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($detected)) {
        throw 'VERSION file is empty. Provide -Version explicitly.'
    }

    return $detected
}

function Resolve-FullPath {
    param(
        [Parameter(Mandatory = $true)][string]$PathValue,
        [Parameter(Mandatory = $true)][string]$BasePath
    )

    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return [System.IO.Path]::GetFullPath($PathValue)
    }

    return [System.IO.Path]::GetFullPath((Join-Path $BasePath $PathValue))
}

function Get-UploadFiles {
    param([Parameter(Mandatory = $true)][string]$Directory)

    @(Get-ChildItem -LiteralPath $Directory -File | Where-Object {
        $_.Name -notmatch '^\.upload-state\.txt$|^\.upload\.lock\.json$|^UPLOAD-COMPLETE\.txt$|^unattended-upload.*\.log$|^upload-resume-.*\.log$|^manual-sync-.*\.log$|^\.manual-sync-state\.txt$|^\.gh-.*\.(out|err)$'
    } | Sort-Object Name)
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$resolvedVersion = Resolve-Version -ExplicitVersion $Version -RepoRoot $repoRoot
$resolvedTag = if ([string]::IsNullOrWhiteSpace($ReleaseTag)) { "v$resolvedVersion" } else { $ReleaseTag.Trim() }
$resolvedRepo = Resolve-RepoSlug -ExplicitRepo $Repo

$resolvedStagingRoot = if ([string]::IsNullOrWhiteSpace($StagingDirectory)) {
    Join-Path ([System.IO.Path]::GetTempPath()) 'audittoolkit-vm-release-overnight'
}
else {
    Resolve-FullPath -PathValue $StagingDirectory -BasePath $repoRoot
}

$resolvedStagingDir = Join-Path $resolvedStagingRoot $resolvedVersion
if (-not (Test-Path -LiteralPath $resolvedStagingDir)) {
    throw "Staging directory not found: $resolvedStagingDir"
}

$uploadFiles = Get-UploadFiles -Directory $resolvedStagingDir
if ($uploadFiles.Count -eq 0) {
    throw "No staged files found in: $resolvedStagingDir"
}

$releaseJson = & gh release view $resolvedTag --repo $resolvedRepo --json assets,url,isDraft,name
if (-not $?) {
    throw "Failed to query release: $resolvedTag"
}

$release = $releaseJson | ConvertFrom-Json
$assetMap = @{}
foreach ($asset in $release.assets) {
    $assetMap[$asset.name] = $asset
}

$missing = New-Object System.Collections.Generic.List[string]
$mismatched = New-Object System.Collections.Generic.List[string]
foreach ($file in $uploadFiles) {
    if (-not $assetMap.ContainsKey($file.Name)) {
        [void]$missing.Add($file.Name)
        continue
    }

    $remoteSize = [int64]$assetMap[$file.Name].size
    if ($remoteSize -ne [int64]$file.Length) {
        [void]$mismatched.Add("$($file.Name) local=$($file.Length) remote=$remoteSize")
    }
}

$completeMarkerPath = Join-Path $resolvedStagingDir 'UPLOAD-COMPLETE.txt'
$statePath = Join-Path $resolvedStagingDir '.upload-state.txt'

Write-Output "Release: $($release.name) ($resolvedTag)"
Write-Output "URL: $($release.url)"
Write-Output "Draft: $($release.isDraft)"
Write-Output "Stage directory: $resolvedStagingDir"
Write-Output "Staged file count: $($uploadFiles.Count)"
Write-Output "Missing assets: $($missing.Count)"
Write-Output "Mismatched assets: $($mismatched.Count)"
Write-Output "Completion marker present: $([bool](Test-Path -LiteralPath $completeMarkerPath))"
Write-Output "Checkpoint state present: $([bool](Test-Path -LiteralPath $statePath))"

if ($missing.Count -gt 0) {
    Write-Output ''
    Write-Output 'Missing assets:'
    foreach ($name in $missing) {
        Write-Output "  - $name"
    }
}

if ($mismatched.Count -gt 0) {
    Write-Output ''
    Write-Output 'Mismatched assets:'
    foreach ($line in $mismatched) {
        Write-Output "  - $line"
    }
}

if ($missing.Count -eq 0 -and $mismatched.Count -eq 0) {
    Write-Output ''
    Write-Output 'SYNC_STATUS=PASS'
    exit 0
}

Write-Output ''
Write-Output 'SYNC_STATUS=INCOMPLETE'
exit 1
