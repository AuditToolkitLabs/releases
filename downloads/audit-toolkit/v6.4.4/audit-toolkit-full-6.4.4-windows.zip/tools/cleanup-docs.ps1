﻿# Documentation Cleanup Script
# Consolidates 96 markdown files to 30 essential files
# Run this script after reviewing DOCUMENTATION-CONSOLIDATION-PLAN.md

param(
    [switch]$DryRun = $false,
    [switch]$Force = $false
)

$null = $Force

$ErrorActionPreference = "Stop"

Write-Output "═══════════════════════════════════════════════════════════════"
Write-Output "  Documentation Consolidation Script"
Write-Output "═══════════════════════════════════════════════════════════════"
Write-Output ""

if ($DryRun) {
    Write-Output "  DRY RUN MODE - No files will be modified"
    Write-Output ""
}

# Files to delete (consolidated into DEVELOPMENT-HISTORY.md, SECURITY.md, ROADMAP.md)
$filesToDelete = @(
    # Phase documents (14 files)
    "PHASE-1-FIXES-SUMMARY.md",
    "PHASE-1-OPTIMIZATION-REPORT.md",
    "PHASE-2-COMPLETE.md",
    "PHASE-2-FIXES-SUMMARY.md",
    "PHASE-2-IMPLEMENTATION-PLAN.md",
    "PHASE-2-QUICK-WINS-COMPLETE.md",
    "PHASE-3-EVALUATION.md",
    "PHASE-3-IMPLEMENTATION-COMPLETE.md",

    # Security documents (9 files)
    "SECURITY-AUDIT-ALIGNMENT-REVIEW.md",
    "SECURITY-FIXES-APPLIED.md",
    "SECURITY-IMPLEMENTATION-COMPLETE.md",
    "SECURITY-REVIEW-COMPLETE.md",
    "SECURITY-VALIDATION-CHECKLIST.md",
    "COMPREHENSIVE-SECURITY-REVIEW.md",
    "COMPREHENSIVE-SECURITY-AUDIT-REPORT.md",

    # Implementation documents (6 files)
    "IMPLEMENTATION-COMPLETE.md",
    "IMPLEMENTATION-VALIDATION.md",
    "PROJECT-COMPLETION-SUMMARY.md",
    "HIGH-PRIORITY-GAPS-IMPLEMENTED.md",
    "PERFORMANCE-IMPLEMENTATION-COMPLETE.md",
    "INSTALLATION-SYSTEM-SUMMARY.md",

    # Code review documents (3 files)
    "CODE-REVIEW-COMPARISON.md",
    "CODE-REVIEW-COMPREHENSIVE.md",
    "REVIEW-REPORT.md",

    # Performance documents (2 files)
    "PERFORMANCE-CODE-REVIEW-REPORT.md",

    # Roadmap documents (3 files - keep ROADMAP.md as consolidated)
    "ROADMAP-COMPLETE.md",
    "ROADMAP-GAP-ANALYSIS.md",
    "EXPANSION-ROADMAP.md",

    # Validation documents (2 files)
    "SHELLCHECK-VALIDATION-REPORT.md",
    "TERMINAL-VALIDATION-GUIDE.md",

    # Other candidates (5 files)
    "AUDIT-STATUS-ANALYSIS.md",
    "CRITICAL-FIXES-ACTION-PLAN.md",
    "ORCHESTRATOR-ENHANCEMENT-SUMMARY.md",
    "WEB-GUI-INTEGRATION-SUMMARY.md",
    "AUDIT-DASHBOARD.md",

    # Web documents (4 files)
    "web\CLEANUP-IMPLEMENTATION.md",
    "web\CUSTOM-SSH-PORT-VERIFICATION.md",
    "web\SECURITY-FIXES-APPLIED.md",
    "web\SECURITY-IMPLEMENTATION-GUIDE.md",

    # Cache performance docs (3 files)
    "audits\data\cache\PERFORMANCE-REVIEW-SUMMARY.md",
    "audits\data\cache\PERFORMANCE-ANALYSIS.md",
    "audits\data\cache\OPTIMIZATION-COMPARISON.md"
)

$deletedCount = 0
$skippedCount = 0
$errors = @()

# Get project root (parent of tools directory)
$projectRoot = Split-Path $PSScriptRoot -Parent

Write-Output "Files to remove: $($filesToDelete.Count)"
Write-Output ""

foreach ($file in $filesToDelete) {
    $fullPath = Join-Path $projectRoot $file

    if (Test-Path $fullPath) {
        $fileInfo = Get-Item $fullPath
        $sizeKB = [math]::Round($fileInfo.Length / 1KB, 1)

        Write-Output "  [-] $file "
        Write-Output "($sizeKB KB)"

        if (-not $DryRun) {
            try {
                Remove-Item $fullPath -Force
                $deletedCount++
            } catch {
                $errors += "Failed to delete $file`: $_"
                Write-Output "      ERROR: $_"
            }
        } else {
            $deletedCount++
        }
    } else {
        Write-Output "  [?] $file (not found)"
        $skippedCount++
    }
}

Write-Output ""
Write-Output "═══════════════════════════════════════════════════════════════"

# Summary
Write-Output ""
Write-Output "Summary:"
Write-Output "  Files planned for deletion: $($filesToDelete.Count)"
Write-Output "  Files removed:              $deletedCount"
Write-Output "  Files skipped (not found):  $skippedCount"
Write-Output "  Errors:                     $($errors.Count)"
Write-Output ""

if ($errors.Count -gt 0) {
    Write-Output "Errors encountered:"
    foreach ($err in $errors) {
        Write-Output "  • $err"
    }
    Write-Output ""
}

# Calculate space saved
if ($deletedCount -gt 0) {
    $totalSize = 0
    foreach ($file in $filesToDelete) {
        $fullPath = Join-Path $projectRoot $file
        if (-not $DryRun -and -not (Test-Path $fullPath)) {
            # File was deleted, can't measure
        } elseif (Test-Path $fullPath) {
            $totalSize += (Get-Item $fullPath).Length
        }
    }

    $totalMB = [math]::Round($totalSize / 1MB, 2)
    Write-Output "Estimated space saved: $totalMB MB"
    Write-Output ""
}

# What was created
Write-Output "New consolidated documents created:"
Write-Output "  [+] SECURITY.md"
Write-Output "      Consolidates 9 security-related documents"
Write-Output ""
Write-Output "  [+] DEVELOPMENT-HISTORY.md"
Write-Output "      Consolidates 40+ implementation, phase, and review documents"
Write-Output ""
Write-Output "  [+] ROADMAP.md"
Write-Output "      Consolidates 3 roadmap documents with future vision"
Write-Output ""
Write-Output "  [+] DOCUMENTATION-CONSOLIDATION-PLAN.md"
Write-Output "      Analysis document (can be deleted after review)"
Write-Output ""

# Final instructions
Write-Output "═══════════════════════════════════════════════════════════════"
Write-Output ""

if ($DryRun) {
    Write-Output "  This was a DRY RUN. To actually delete files, run:"
    Write-Output "    .\tools\cleanup-docs.ps1"
    Write-Output ""
} else {
    Write-Output "  Consolidation complete!"
    Write-Output ""
    Write-Output "  Before: 96 markdown files"
    Write-Output "  After:  ~30 essential files (69% reduction)"
    Write-Output ""
    Write-Output "  Next steps:"
    Write-Output "    1. Review consolidated documents (SECURITY.md, DEVELOPMENT-HISTORY.md, ROADMAP.md)"
    Write-Output "    2. Update README.md to reference new structure"
    Write-Output "    3. Update CHANGELOG.md to note consolidation"
    Write-Output "    4. Commit changes: git add -A && git commit -m 'Consolidate documentation (96 -> 30 files)'"
    Write-Output ""
    Write-Output "  All deleted files are preserved in git history if needed."
    Write-Output ""
}

# Git status check
if (-not $DryRun) {
    Write-Output "Git status:"
    git status --short | Select-Object -First 20

    $modifiedCount = (git status --short | Measure-Object).Count
    if ($modifiedCount -gt 20) {
        Write-Output "  ... and $($modifiedCount - 20) more files"
    }
    Write-Output ""
}

Write-Output "═══════════════════════════════════════════════════════════════"

# Exit code
if ($errors.Count -gt 0) {
    exit 1
} else {
    exit 0
}

