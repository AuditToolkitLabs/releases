﻿<#
.SYNOPSIS
    Creates demo recordings (GIF/MP4) of the Security Audit Toolkit in action.

.DESCRIPTION
    This script helps create professional demo recordings for:
    - GitHub README
    - Social media posts
    - Documentation

.NOTES
    Requirements:
    - ScreenToGif (recommended): https://www.screentogif.com/
    - Or OBS Studio: https://obsproject.com/
    - Or Windows built-in: Win+G (Xbox Game Bar)

.EXAMPLE
    .\create-demo-recording.ps1 -Demo CLI
    .\create-demo-recording.ps1 -Demo WebUI
    .\create-demo-recording.ps1 -Demo All
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [ValidateSet("CLI", "WebUI", "API", "All")]
    [string]$Demo = "CLI"
)

$ErrorActionPreference = "Stop"
$OutputPath = Join-Path $PSScriptRoot "..\docs\assets\demos"

# Ensure output directory exists
if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
}

# Check for recording tools
function Test-RecordingTools {
    $tools = @{
        "ScreenToGif" = "C:\Program Files\ScreenToGif\ScreenToGif.exe"
        "ScreenToGifPortable" = "C:\Tools\ScreenToGif\ScreenToGif.exe"
        "OBS" = "C:\Program Files\obs-studio\bin\64bit\obs64.exe"
    }

    foreach ($tool in $tools.GetEnumerator()) {
        if (Test-Path $tool.Value) {
            return @{ Name = $tool.Key; Path = $tool.Value }
        }
    }
    return $null
}

# Demo scripts for different scenarios
$DemoScripts = @{
    CLI = @{
        Name = "CLI Demo"
        Description = "Shows interactive audit selection and execution"
        Duration = "30-45 seconds"
        Script = @"
# ==============================================================
# DEMO SCRIPT: CLI Interactive Mode
# ==============================================================
#
# RECORDING INSTRUCTIONS:
# 1. Open terminal in full screen (F11) or maximize window
# 2. Set font size to 14-16pt for readability
# 3. Use dark theme for contrast
# 4. Start recording, then paste commands below
#
# TARGET SIZE: 1280x720 or 1920x1080
# ==============================================================

# 1. Show version and help (5 seconds)
# Type slowly for demo effect:
./orchestrator/orchestrator.sh --version
./orchestrator/orchestrator.sh --help

# 2. Run interactive mode (15 seconds)
# This shows the menu selection:
./orchestrator/orchestrator.sh --interactive

# 3. Run specific domain (10 seconds)
./orchestrator/orchestrator.sh --domain platform --dry-run

# 4. Show results summary
# Let the output display for 5 seconds

# ==============================================================
# END DEMO
# ==============================================================
"@
    }

    WebUI = @{
        Name = "Web UI Demo"
        Description = "Shows dashboard, audit execution, and results"
        Duration = "45-60 seconds"
        Script = @"
# ==============================================================
# DEMO SCRIPT: Web UI Dashboard
# ==============================================================
#
# RECORDING INSTRUCTIONS:
# 1. Start the web server: cd web && python app.py
# 2. Open browser to http://localhost:5000
# 3. Use browser zoom at 100% or 90%
# 4. Hide browser bookmarks bar for cleaner look
#
# TARGET SIZE: 1280x720 or 1920x1080
# ==============================================================

# DEMO FLOW:

# 1. Dashboard Overview (10 seconds)
#    - Show main dashboard with metrics
#    - Hover over charts briefly

# 2. Server List (10 seconds)
#    - Click 'Servers' in navigation
#    - Show list of registered servers
#    - Click one server to show details

# 3. Run Audit (15 seconds)
#    - Click 'Run Audit' button
#    - Select audit type from dropdown
#    - Show progress indicator

# 4. View Results (15 seconds)
#    - Show audit results table
#    - Expand one finding
#    - Show severity and remediation

# 5. Export Report (10 seconds)
#    - Click 'Export' button
#    - Show PDF/CSV options
#    - Briefly show downloaded report

# ==============================================================
"@
    }

    API = @{
        Name = "API Demo"
        Description = "Shows REST API usage with curl/httpie"
        Duration = "30 seconds"
        Script = @"
# ==============================================================
# DEMO SCRIPT: REST API
# ==============================================================
#
# RECORDING INSTRUCTIONS:
# 1. Have web server running: cd web && python app.py
# 2. Have API token ready (or use demo credentials)
# 3. Use dark terminal theme
#
# ==============================================================

# 1. Authenticate (5 seconds)
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "demo"}' | jq

# 2. List servers (5 seconds)
curl http://localhost:5000/api/servers \
  -H "Authorization: Bearer <token>" | jq

# 3. Get audit results (10 seconds)
curl http://localhost:5000/api/audits/latest \
  -H "Authorization: Bearer <token>" | jq '.results[:3]'

# 4. Trigger new audit (10 seconds)
curl -X POST http://localhost:5000/api/audits/run \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"server_id": 1, "audit_type": "quick"}' | jq

# ==============================================================
"@
    }
}

# Main logic
Write-Output @"

╔══════════════════════════════════════════════════════════════╗
║           Security Audit Toolkit - Demo Generator            ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan

# Check for recording tool
$recorder = Test-RecordingTools
if ($recorder) {
    Write-Output "✓ Found recording tool: $($recorder.Name)"
    Write-Output "  Path: $($recorder.Path)`n"
} else {
    Write-Output @"
⚠ No recording tool found. Recommended options:

  1. ScreenToGif (FREE, best for GIFs):
     https://www.screentogif.com/

  2. OBS Studio (FREE, best for video):
     https://obsproject.com/

  3. Windows Game Bar (built-in):
     Press Win+G to open

  4. LICEcap (FREE, simple GIF):
     https://www.cockos.com/licecap/

"@ -ForegroundColor Yellow
}

# Show demo options
if ($Demo -eq "All") {
    $selectedDemos = $DemoScripts.Keys
} else {
    $selectedDemos = @($Demo)
}

foreach ($demoKey in $selectedDemos) {
    $demo = $DemoScripts[$demoKey]

    Write-Output "═══════════════════════════════════════════════════════════════"
    Write-Output "Demo: $($demo.Name)"
    Write-Output "Duration: $($demo.Duration)"
    Write-Output "Description: $($demo.Description)"
    Write-Output "═══════════════════════════════════════════════════════════════"
    Write-Output ""
    Write-Output $demo.Script
    Write-Output ""

    # Save script to file
    $scriptPath = Join-Path $OutputPath "demo-$demoKey.txt"
    $demo.Script | Out-File -FilePath $scriptPath -Encoding UTF8
    Write-Output "✓ Demo script saved to: $scriptPath"
    Write-Output ""
}

# Recording tips
Write-Output @"
╔══════════════════════════════════════════════════════════════╗
║                     RECORDING TIPS                           ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Resolution:  1280x720 (recommended) or 1920x1080            ║
║  Frame Rate:  15 FPS for GIF, 30 FPS for video               ║
║  Duration:    30-60 seconds (keep it tight)                  ║
║  File Size:   Under 5MB for GitHub README GIF                ║
║                                                              ║
║  For best results:                                           ║
║  • Use dark terminal theme (better contrast)                 ║
║  • Increase font size to 14-16pt                             ║
║  • Type commands slowly for visibility                       ║
║  • Pause 2-3 seconds after each command output               ║
║  • Crop recording to just the relevant area                  ║
║                                                              ║
║  Output location: $OutputPath
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan

# Offer to open recording tool
if ($recorder) {
    $response = Read-Host "Open $($recorder.Name) now? (y/n)"
    if ($response -eq 'y') {
        Start-Process $recorder.Path
    }
}

Write-Output "`nDemo script files created in: $OutputPath"
Write-Output "Record your demo, then save as:"
Write-Output "  - GIF: docs/assets/demos/demo-cli.gif"
Write-Output "  - MP4: docs/assets/demos/demo-webui.mp4"
Write-Output ""

