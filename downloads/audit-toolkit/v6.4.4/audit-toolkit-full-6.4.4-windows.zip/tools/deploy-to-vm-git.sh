#!/bin/bash
# =============================================================================
# SSH Deployment Script - Clean v6.1.0 Install via Git Clone
# All commands in ONE SSH session to avoid multiple password prompts
# Usage: bash deploy-to-vm.sh <vm-ip> <username>
# =============================================================================

set -euo pipefail

VM_IP="${1:-192.168.100.50}"
SSH_USER="${2:-ubuntu}"
TOOLKIT_VERSION="6.1.0"

log() { echo "[$(date '+%H:%M:%S')] $1"; }

log "=== Clean v${TOOLKIT_VERSION} Deployment to ${VM_IP} ==="
log "User: ${SSH_USER}"

# Create single SSH session with all deployment commands
DEPLOY_COMMANDS=$(cat <<'EOF'
#!/bin/bash
set -euo pipefail

log() { echo "[$(date '+%H:%M:%S')] $1"; }
error() { echo "[$(date '+%H:%M:%S')] ERROR: $1" >&2; exit 1; }

# =============================================================================
# PHASE 1: Uninstall old version
# =============================================================================
log "PHASE 1: Uninstalling old version..."
sudo systemctl stop audit-toolkit audit-toolkit-discovery nginx redis-server postgresql 2>/dev/null || true
sudo systemctl disable audit-toolkit audit-toolkit-discovery 2>/dev/null || true
sudo rm -f /etc/systemd/system/audit-toolkit*.service
sudo systemctl daemon-reload
sudo rm -f /etc/nginx/sites-enabled/audit-toolkit* /etc/nginx/sites-available/audit-toolkit*
sudo systemctl reload nginx 2>/dev/null || true

sudo -u postgres psql <<SQL 2>/dev/null || log "PostgreSQL not ready yet"
DROP DATABASE IF EXISTS audit_toolkit;
DROP DATABASE IF EXISTS asset_discovery;
DROP ROLE IF EXISTS auditadmin;
SQL

sudo rm -rf /opt/audit-toolkit /var/lib/audit-toolkit /var/cache/audit-toolkit /var/log/audit-toolkit
log "✓ Uninstall complete"

# =============================================================================
# PHASE 2: System Packages
# =============================================================================
log "PHASE 2: Installing system dependencies..."
sudo apt-get update -qq
sudo apt-get upgrade -y -qq
sudo apt-get install -y -qq \
    python3 python3-venv python3-pip python3-dev \
    postgresql postgresql-contrib libpq-dev \
    redis-server nginx ufw unattended-upgrades apt-listchanges \
    git curl wget openssl build-essential
log "✓ Packages installed"

# =============================================================================
# PHASE 3: Clone Application from GitHub
# =============================================================================
log "PHASE 3: Cloning v6.1.0 from GitHub..."
mkdir -p /opt/audit-toolkit
cd /opt
git clone --branch v6.1.0 --depth 1 https://github.com/AuditToolkitLabs/Audit-Tool-.git audit-toolkit-tmp 2>&1 | grep -v "^Cloning"
sudo mv audit-toolkit-tmp/* /opt/audit-toolkit/
sudo rm -rf audit-toolkit-tmp
sudo chown -R auditadmin:auditadmin /opt/audit-toolkit
cd /opt/audit-toolkit
log "✓ Repository cloned"

# =============================================================================
# PHASE 4: PostgreSQL Setup
# =============================================================================
log "PHASE 4: Configuring PostgreSQL..."
sudo systemctl start postgresql
sudo systemctl enable postgresql

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='auditadmin'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER auditadmin WITH PASSWORD 'ChangeMe123' CREATEDB;"

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='audit_toolkit'" | grep -q 1 || \
    sudo -u postgres createdb -O auditadmin audit_toolkit

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='asset_discovery'" | grep -q 1 || \
    sudo -u postgres createdb -O auditadmin asset_discovery

log "✓ PostgreSQL configured"

# =============================================================================
# PHASE 5: Python Dependencies
# =============================================================================
log "PHASE 5: Installing Python dependencies..."
cd /opt/audit-toolkit
sudo -u auditadmin python3 -m venv venv --system-site-packages 2>/dev/null || true
sudo -u auditadmin /opt/audit-toolkit/venv/bin/pip install --upgrade pip setuptools wheel -q 2>/dev/null || true

if [[ -f requirements_frozen.txt ]]; then
    sudo -u auditadmin /opt/audit-toolkit/venv/bin/pip install -r requirements_frozen.txt -q 2>/dev/null || log "Warning: Some dependencies may not have installed"
fi

log "✓ Python dependencies installed"

# =============================================================================
# PHASE 6: Configure Services
# =============================================================================
log "PHASE 6: Configuring systemd services..."

# Install systemd units
if [[ -d deployment/vm-appliance/systemd ]]; then
    sudo cp deployment/vm-appliance/systemd/*.service /etc/systemd/system/ 2>/dev/null || log "Note: Some systemd units not found"
fi

# Configure nginx
if [[ ! -f /etc/nginx/sites-available/audit-toolkit ]]; then
    cat <<NGINX | sudo tee /etc/nginx/sites-available/audit-toolkit > /dev/null
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name _;
    ssl_certificate /etc/ssl/certs/ssl-cert-snakeoil.pem;
    ssl_certificate_key /etc/ssl/private/ssl-cert-snakeoil.key;

    client_max_body_size 100M;

    location / {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_connect_timeout 300s;
    }
}
server {
    listen 80;
    listen [::]:80;
    return 301 https://\$host\$request_uri;
}
NGINX
fi

sudo ln -sf /etc/nginx/sites-available/audit-toolkit /etc/nginx/sites-enabled/audit-toolkit 2>/dev/null || true
log "✓ Services configured"

# =============================================================================
# PHASE 7: Start Services
# =============================================================================
log "PHASE 7: Starting services..."
sudo systemctl daemon-reload
sudo systemctl enable nginx redis-server postgresql audit-toolkit audit-toolkit-discovery
sudo systemctl start nginx redis-server postgresql
sleep 3
sudo systemctl start audit-toolkit audit-toolkit-discovery 2>/dev/null || log "Note: Toolkit services starting..."

log "✓ Services started"

# =============================================================================
# PHASE 8: Wait for Web Service
# =============================================================================
log "PHASE 8: Waiting for web service to be ready..."
for i in {1..60}; do
    if curl -sk https://localhost/ --connect-timeout 2 >/dev/null 2>&1; then
        log "✓ Web service ready"
        break
    fi
    if [[ $i -eq 60 ]]; then
        log "⚠ Web service timeout after 60 seconds (services may still be initializing)"
    fi
    sleep 1
done

# =============================================================================
# PHASE 9: Verification
# =============================================================================
log "PHASE 9: Verifying installation..."
sudo systemctl is-active audit-toolkit >/dev/null && log "✓ audit-toolkit running" || log "⚠ audit-toolkit status: $(sudo systemctl is-active audit-toolkit)"
sudo systemctl is-active nginx >/dev/null && log "✓ nginx running" || log "⚠ nginx not running"

log ""
log "=== Deployment Complete ==="
log "Initial admin credentials: /var/lib/audit-toolkit/initial-admin-credentials.txt"
EOF
)

log ""
log "Connecting to VM via SSH and running deployment..."
log "(This will take 5-10 minutes...)"
log ""

# Run ALL deployment commands in single SSH session
echo "$DEPLOY_COMMANDS" | ssh -o ConnectTimeout=10 -o BatchMode=no \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    "${SSH_USER}@${VM_IP}" "bash"

log ""
log "=== Deployment Complete ==="
log ""
log "VM Information:"
log "  URL:  https://${VM_IP}"
log "  SSH:  ssh ${SSH_USER}@${VM_IP}"
log ""
log "Next steps:"
log "  1. Monitor admin credentials:"
log "     ssh ${SSH_USER}@${VM_IP} 'sudo cat /var/lib/audit-toolkit/initial-admin-credentials.txt'"
log ""
