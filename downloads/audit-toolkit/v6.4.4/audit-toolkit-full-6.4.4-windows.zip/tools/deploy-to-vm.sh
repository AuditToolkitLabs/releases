#!/bin/bash
# =============================================================================
# SSH Deployment Script - Clean v6.1.0 Install
# All commands in ONE SSH session to avoid multiple password prompts
# Usage: bash deploy-to-vm.sh <vm-ip> <username>
# =============================================================================

set -euo pipefail

VM_IP="${1:-192.168.100.50}"
SSH_USER="${2:-ubuntu}"
TOOLKIT_VERSION="6.1.0"

log() { echo "[$(date '+%H:%M:%S')] $1"; }

log "=== Clean v${TOOLKIT_VERSION} Deployment to ${VM_IP} ==="
log "User: ${SSH_USER}"

# Create single SSH session with all deployment commands
DEPLOY_COMMANDS=$(cat <<'EOF'
#!/bin/bash
set -euo pipefail

log() { echo "[$(date '+%H:%M:%S')] $1"; }
error() { echo "[$(date '+%H:%M:%S')] ERROR: $1" >&2; exit 1; }

# =============================================================================
# PHASE 1: Uninstall
# =============================================================================
log "PHASE 1: Uninstalling old version..."
sudo systemctl stop audit-toolkit audit-toolkit-discovery nginx redis-server postgresql 2>/dev/null || true
sudo systemctl disable audit-toolkit audit-toolkit-discovery 2>/dev/null || true
sudo rm -f /etc/systemd/system/audit-toolkit*.service
sudo systemctl daemon-reload
sudo rm -f /etc/nginx/sites-enabled/audit-toolkit* /etc/nginx/sites-available/audit-toolkit*
sudo systemctl reload nginx 2>/dev/null || true

sudo -u postgres psql <<SQL 2>/dev/null || log "PostgreSQL not ready yet"
DROP DATABASE IF EXISTS audit_toolkit;
DROP DATABASE IF EXISTS asset_discovery;
DROP ROLE IF EXISTS auditadmin;
SQL

sudo rm -rf /opt/audit-toolkit /var/lib/audit-toolkit /var/cache/audit-toolkit /var/log/audit-toolkit
log "✓ Uninstall complete"

# =============================================================================
# PHASE 2: System Packages
# =============================================================================
log "PHASE 2: Installing system packages..."
sudo apt-get update -qq
sudo apt-get upgrade -y -qq
sudo apt-get install -y -qq \
    python3 python3-venv python3-pip python3-dev \
    postgresql postgresql-contrib libpq-dev \
    redis-server nginx ufw unattended-upgrades apt-listchanges \
    git curl wget openssl build-essential
log "✓ Packages installed"

# =============================================================================
# PHASE 3: PostgreSQL Setup
# =============================================================================
log "PHASE 3: Configuring PostgreSQL..."
sudo systemctl start postgresql
sudo systemctl enable postgresql

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='auditadmin'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER auditadmin WITH PASSWORD 'ChangeMe123' CREATEDB;"

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='audit_toolkit'" | grep -q 1 || \
    sudo -u postgres createdb -O auditadmin audit_toolkit

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='asset_discovery'" | grep -q 1 || \
    sudo -u postgres createdb -O auditadmin asset_discovery

log "✓ PostgreSQL configured"

# =============================================================================
# PHASE 4: Wait for tarball
# =============================================================================
log "PHASE 4: Waiting for deployment tarball..."
for i in {1..30}; do
    if [[ -f /tmp/audit-toolkit.tar.gz ]]; then
        log "✓ Tarball found"
        break
    fi
    if [[ $i -eq 30 ]]; then
        error "Tarball not found after 60 seconds"
    fi
    sleep 2
done

# =============================================================================
# PHASE 5: Extract and Deploy
# =============================================================================
log "PHASE 5: Extracting application..."
sudo mkdir -p /opt/audit-toolkit
sudo tar -xzf /tmp/audit-toolkit.tar.gz -C /opt/audit-toolkit --strip-components=1
sudo chown -R auditadmin:auditadmin /opt/audit-toolkit
log "✓ Application extracted"

# =============================================================================
# PHASE 6: Configure Services
# =============================================================================
log "PHASE 6: Configuring systemd services..."
cd /opt/audit-toolkit

# Install systemd units if available
if [[ -d deployment/vm-appliance/systemd ]]; then
    sudo cp deployment/vm-appliance/systemd/*.service /etc/systemd/system/ 2>/dev/null || log "Note: Some systemd units not found"
fi

# Basic nginx config if appliance-specific not available
if [[ ! -f /etc/nginx/sites-available/audit-toolkit ]]; then
    cat <<NGINX | sudo tee /etc/nginx/sites-available/audit-toolkit > /dev/null
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name _;
    ssl_certificate /etc/ssl/certs/ssl-cert-snakeoil.pem;
    ssl_certificate_key /etc/ssl/private/ssl-cert-snakeoil.key;

    location / {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
server {
    listen 80;
    listen [::]:80;
    return 301 https://\$host\$request_uri;
}
NGINX
fi

sudo ln -sf /etc/nginx/sites-available/audit-toolkit /etc/nginx/sites-enabled/audit-toolkit 2>/dev/null || true
log "✓ Services configured"

# =============================================================================
# PHASE 7: Start Services
# =============================================================================
log "PHASE 7: Starting services..."
sudo systemctl daemon-reload
sudo systemctl enable audit-toolkit audit-toolkit-discovery nginx redis-server postgresql
sudo systemctl start nginx redis-server postgresql
sleep 3
sudo systemctl start audit-toolkit audit-toolkit-discovery 2>/dev/null || log "Note: Service startup in progress"

log "✓ Services started"

# =============================================================================
# PHASE 8: Verification
# =============================================================================
log "PHASE 8: Verifying installation..."
sleep 5
sudo systemctl is-active audit-toolkit && log "✓ audit-toolkit running" || log "⚠ audit-toolkit status unknown"
sudo systemctl is-active nginx && log "✓ nginx running" || log "⚠ nginx status unknown"

log "=== Deployment Complete ==="
log "Initial admin credentials: /var/lib/audit-toolkit/initial-admin-credentials.txt"
EOF
)

# Transfer tarball first (no SSH needed, use scp)
if [[ -f "dist/updates/stable/full-${TOOLKIT_VERSION}.tar.gz" ]]; then
    log "Transferring tarball via SCP..."
    scp -o ConnectTimeout=5 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        "dist/updates/stable/full-${TOOLKIT_VERSION}.tar.gz" \
        "${SSH_USER}@${VM_IP}:/tmp/audit-toolkit.tar.gz"
    log "✓ Tarball transferred"
else
    log "ERROR: Local tarball not found at dist/updates/stable/full-${TOOLKIT_VERSION}.tar.gz"
    log "Deployment requires built artifacts. Check GitHub Actions build completion."
    exit 1
fi

# Run ALL deployment commands in single SSH session
log "Executing deployment (this may take 5-10 minutes)..."
echo "$DEPLOY_COMMANDS" | ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    "${SSH_USER}@${VM_IP}" "bash"

log ""
log "=== Deployment Complete ==="
log "VM URL: https://${VM_IP}"
log "SSH: ssh ${SSH_USER}@${VM_IP}"
