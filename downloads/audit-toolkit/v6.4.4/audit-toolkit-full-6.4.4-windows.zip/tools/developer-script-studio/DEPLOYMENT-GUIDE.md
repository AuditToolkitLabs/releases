# Developer Script Studio - Deployment Guide

**Version:** current
**Last Updated:** February 13, 2026

---

## Overview

Developer Script Studio is a desktop application (Electron) for creating and editing security audit scripts. It integrates with the Security Audit Toolkit to provide a complete development environment.

---

## Quick Start

### Prerequisites

- **Node.js 18+** (for building)
- **npm 9+** or **yarn 1.22+**
- **Security Audit Toolkit** installed (for script integration)

### Build from Source

```bash
# Navigate to Developer Script Studio
cd tools/developer-script-studio

# Install dependencies
npm install

# Run in development mode
npm run dev

# Build for your platform
npm run build           # All platforms
npm run build:win       # Windows only
npm run build:mac       # macOS only
npm run build:linux     # Linux only
```

### Output Locations

After build, installers are in `dist/`:

| Platform | Output | Format |
|----------|--------|--------|
| Windows | `dist/Developer Script Studio Setup 1.0.0.exe` | NSIS Installer |
| Windows | `dist/Developer Script Studio 1.0.0.exe` | Portable |
| macOS | `dist/Developer Script Studio-1.0.0.dmg` | DMG |
| macOS | `dist/Developer Script Studio-1.0.0-mac.zip` | ZIP |
| Linux | `dist/Developer Script Studio-1.0.0.AppImage` | AppImage |
| Linux | `dist/developer-script-studio_1.0.0_amd64.deb` | DEB |

---

## Installation by Platform

### Windows

**Option 1: NSIS Installer (Recommended)**
```powershell
# Run installer
.\Developer-Script-Studio-Setup-1.0.0.exe

# Silent install
.\Developer-Script-Studio-Setup-1.0.0.exe /S
```

**Option 2: Portable**
```powershell
# No installation needed - just run
.\Developer-Script-Studio-1.0.0.exe
```

**Installation Location:** `C:\Users\{user}\AppData\Local\Programs\Developer Script Studio`

### macOS

**Option 1: DMG**
1. Double-click `Developer Script Studio-1.0.0.dmg`
2. Drag app to Applications folder
3. First launch: Right-click → Open (bypasses Gatekeeper)

**Option 2: ZIP**
```bash
unzip Developer-Script-Studio-1.0.0-mac.zip -d /Applications
```

### Linux

**Option 1: AppImage (Universal)**
```bash
chmod +x Developer-Script-Studio-1.0.0.AppImage
./Developer-Script-Studio-1.0.0.AppImage
```

**Option 2: DEB (Debian/Ubuntu)**
```bash
sudo dpkg -i developer-script-studio_1.0.0_amd64.deb
sudo apt-get install -f  # Fix dependencies if needed
```

---

## Configuration

### Audit Toolkit Integration

Developer Script Studio automatically detects Security Audit Toolkit installations at:

| Platform | Default Location |
|----------|------------------|
| Linux | `/opt/audit-toolkit` |
| Windows | `C:\Program Files\SecurityAuditToolkit` |
| macOS | `/opt/audit-toolkit` |

**Custom Location:**

Set the environment variable:
```bash
# Linux/macOS
export AUDIT_TOOLKIT_HOME=/custom/path

# Windows (PowerShell)
$env:AUDIT_TOOLKIT_HOME = "C:\custom\path"
```

Or configure in the app: **Settings → Audit Toolkit Path**

### Custom Scripts Directory

Custom scripts are saved to:

| Platform | Location |
|----------|----------|
| Linux | `$AUDIT_TOOLKIT_HOME/audits/custom/` |
| Windows | `%AUDIT_TOOLKIT_HOME%\audits\custom\` |
| macOS | `$AUDIT_TOOLKIT_HOME/audits/custom/` |

---

## License Activation

### License Tiers

| Tier | Price | Features |
|------|-------|----------|
| **Standard** | $99/year | Create custom scripts, read-only access to core scripts |
| **Developer** | $299/year | Full access + edit all scripts + auto-backup |

### Activating a License

1. Launch Developer Script Studio
2. Click **Help → Activate License**
3. Enter your license key
4. Click **Activate**

**License Key Format:** `XXXX-XXXX-XXXX-XXXX`

### Test License Keys (Development Only)

For testing purposes:
- `STANDARD-TEST-KEY` - Activates Standard tier
- `DEVELOPER-TEST-KEY` - Activates Developer tier

⚠️ **Note:** Test keys work only in development builds.

### License File Location

| Platform | Location |
|----------|----------|
| Linux | `~/.config/developer-script-studio/license.json` |
| Windows | `%APPDATA%\developer-script-studio\license.json` |
| macOS | `~/Library/Application Support/developer-script-studio/license.json` |

---

## Enterprise Deployment

### Silent Installation (Windows)

```powershell
# Install silently with license pre-configured
.\Developer-Script-Studio-Setup-1.0.0.exe /S /D=C:\Tools\ScriptStudio

# Pre-deploy license file
Copy-Item license.json "$env:APPDATA\developer-script-studio\"
```

### GPO/SCCM/Intune Deployment

1. Host installer on network share or package server
2. Create deployment package with:
   - Installer executable
   - Pre-configured `license.json` (optional)
3. Deploy via standard software deployment

**Example SCCM Command Line:**
```
Developer-Script-Studio-Setup-1.0.0.exe /S
```

**Detection Rule:** Check for `C:\Users\*\AppData\Local\Programs\Developer Script Studio\Developer Script Studio.exe`

### Linux Mass Deployment

```bash
# Using Ansible
- name: Install Developer Script Studio
  apt:
    deb: /path/to/developer-script-studio_1.0.0_amd64.deb
  when: ansible_os_family == 'Debian'
```

---

## Updating

### Auto-Update (Future)

Auto-update is planned for future releases. Currently, manual update is required.

### Manual Update

1. Download new version
2. Run installer (Windows) or replace app (macOS/Linux)
3. Settings and license are preserved

---

## Uninstallation

### Windows
```powershell
# Via Settings → Apps
# Or using installer
.\Developer-Script-Studio-Setup-1.0.0.exe /S /uninstall
```

### macOS
```bash
rm -rf /Applications/Developer\ Script\ Studio.app
rm -rf ~/Library/Application\ Support/developer-script-studio
```

### Linux (DEB)
```bash
sudo apt remove developer-script-studio
```

### Linux (AppImage)
```bash
rm Developer-Script-Studio-1.0.0.AppImage
rm -rf ~/.config/developer-script-studio
```

---

## Troubleshooting

### App won't start

**Windows:**
- Ensure Visual C++ Redistributable is installed
- Try running as Administrator

**Linux:**
- AppImage: Check `fuse` is installed: `sudo apt install fuse`
- Check executable permission: `chmod +x *.AppImage`

**macOS:**
- First run: Right-click → Open to bypass Gatekeeper
- Check Security & Privacy settings

### Can't find Audit Toolkit

1. Verify Audit Toolkit is installed
2. Set `AUDIT_TOOLKIT_HOME` environment variable
3. Configure path in Settings → Audit Toolkit Path

### License won't activate

1. Check internet connection (license validation requires network)
2. Verify license key format: `XXXX-XXXX-XXXX-XXXX`
3. Check license hasn't expired
4. Contact support with license key and error message

---

## Build Requirements (Contributors)

### Development Environment

```bash
# Install Node.js 18+ (via nvm recommended)
nvm install 18
nvm use 18

# Install dependencies
npm install

# Run in dev mode
npm run dev
```

### Building Installers

**All platforms (on respective OS):**
```bash
npm run build
```

**Cross-compilation:** Not supported. Build on target platform or use CI.

### CI Build (GitHub Actions)

The project includes GitHub Actions workflow for automated builds:

```yaml
# .github/workflows/build-script-studio.yml
name: Build Developer Script Studio
on:
  push:
    tags: ['script-studio-v*']
jobs:
  build:
    strategy:
      matrix:
        os: [windows-latest, macos-latest, ubuntu-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 18
      - run: npm ci
        working-directory: tools/developer-script-studio
      - run: npm run build
        working-directory: tools/developer-script-studio
      - uses: actions/upload-artifact@v4
        with:
          name: installer-${{ matrix.os }}
          path: tools/developer-script-studio/dist/*
```

---

## Related Documentation

- [Product Architecture](../../docs/PRODUCT-ARCHITECTURE.md) - How Audit Tool + Script Studio work together
- [Audit Toolkit Installation](../../docs/DEPLOYMENT-GUIDE.md) - Core toolkit installation
- [Custom Audit Authoring](../../docs/04-audit-authoring.md) - Creating custom scripts

---

*Developer Script Studio - Security Audit Toolkit*

