# Developer Script Studio

A professional Electron-based IDE for creating and managing security audit scripts for the Security Audit Toolkit.

## Two Ways to Use Script Studio

### 1. Web Interface (Integrated - Recommended)

Access Script Studio directly through the Security Audit Toolkit web console:

```
http://your-server:5000/script-studio
```

> ⚠️ **SuperAdmin Only**: Web access is restricted to SuperAdmin users for security.

**Advantages:**
- No separate installation required
- Integrated with the main license system
- Works from any browser

### 2. Desktop Application (Standalone)

Build and install the Electron app for a dedicated development environment. See "Development Setup" below.

## Features

- **Monaco Editor**: Full-featured code editor with syntax highlighting for Bash and PowerShell
- **Script Templates**: Pre-built templates for common audit patterns (basic, compliance, security)
- **Tiered Licensing**: Standard and Developer tiers with different capabilities
- **Auto-Backup**: Automatic backup system for edited scripts (Developer tier)
- **Script Validation**: ShellCheck for Bash, PSScriptAnalyzer for PowerShell
- **File Browser**: Navigate and manage audit scripts

## License Tiers

### Standard ($99/year)
- Create unlimited custom scripts in `audits/custom/`
- Access to all script templates
- View existing audit scripts (read-only)
- Syntax validation

### Developer ($299/year)
- Everything in Standard
- Edit existing audit scripts
- Automatic backup on save
- Backup history and restore
- Full edit access to library scripts

## Development Setup

### Prerequisites
- Node.js 18+
- npm 9+

### Installation

```bash
cd tools/developer-script-studio
npm install
```

### Development Mode

```bash
npm run dev
```

### Building

```bash
# Build for current platform
npm run build

# Build for all platforms
npm run build:all

# Build for specific platform
npm run build:win
npm run build:mac
npm run build:linux
```

## Project Structure

```
developer-script-studio/
├── package.json           # Electron app configuration
├── src/
│   ├── main/
│   │   ├── main.js           # Main process (window, IPC, menus)
│   │   ├── preload.js        # Context bridge (security)
│   │   ├── license-manager.js # License validation & tiers
│   │   └── file-manager.js   # File operations & backups
│   └── renderer/
│       ├── index.html        # UI structure
│       ├── styles.css        # Styling (dark theme)
│       └── renderer.js       # UI logic & Monaco integration
└── templates/
    ├── bash/
    │   ├── basic.sh          # Basic audit template
    │   ├── compliance.sh     # Compliance check template
    │   ├── security.sh       # Security assessment template
    │   └── empty.sh          # Empty starter
    └── powershell/
        ├── basic.ps1         # Basic audit template
        ├── compliance.ps1    # Compliance check template
        ├── security.ps1      # Security assessment template
        └── empty.ps1         # Empty starter
```

## IPC API

The preload script exposes these APIs to the renderer:

### License
- `window.api.license.getInfo()` - Get current license status
- `window.api.license.activate(key)` - Activate a license key
- `window.api.license.canEdit(filePath)` - Check edit permission for file

### Files
- `window.api.files.getTree()` - Get navigable file tree
- `window.api.files.read(path)` - Read file contents
- `window.api.files.save(path, content)` - Save file
- `window.api.files.createCustomScript(name, template, category)` - Create new script
- `window.api.files.getBackups(path)` - List backups for a file
- `window.api.files.restoreBackup(backupPath, targetPath)` - Restore a backup

### Templates
- `window.api.templates.list()` - List available templates
- `window.api.templates.get(name, type)` - Get template content

### Validation
- `window.api.validate(content, language)` - Validate script syntax

## Test License Keys

For development/testing:
- `STANDARD-TEST-KEY` - Activates Standard license
- `DEVELOPER-TEST-KEY` - Activates Developer license

## Integration with Audit Tool

Scripts created in `audits/custom/` are automatically discovered by the main Audit Tool orchestrator. The Studio provides:

1. **Template-based creation**: Start with proven patterns
2. **Library access**: Reference existing audit libraries
3. **Validation**: Ensure scripts follow best practices
4. **Safe editing**: Developer tier can modify core scripts with backup protection

## Security

- Context isolation enabled (preload bridge only)
- No remote content execution
- License validation with signature verification (production)
- File operations restricted to known directories
