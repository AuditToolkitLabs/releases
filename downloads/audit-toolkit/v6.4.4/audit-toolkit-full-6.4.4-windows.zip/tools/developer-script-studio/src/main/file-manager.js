/**
 * File Manager - Script file operations with auto-backup
 * 
 * Handles:
 * - Reading audit scripts from main toolkit
 * - Saving scripts with backup (developer tier only for non-custom)
 * - Managing file tree for navigation
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class FileManager {
    constructor(auditToolPath, customPath, backupPath) {
        this.auditToolPath = auditToolPath;
        this.customPath = customPath;
        this.backupPath = backupPath;
        
        // Ensure directories exist
        this.ensureDirectories();
    }

    ensureDirectories() {
        const dirs = [
            this.customPath,
            this.backupPath,
            path.join(this.backupPath, 'daily'),
            path.join(this.backupPath, 'on-save')
        ];

        for (const dir of dirs) {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        }
    }

    /**
     * Get file tree for sidebar navigation
     */
    getFileTree(rootPath = null, options = {}) {
        const basePath = rootPath || this.auditToolPath;
        const { includeCustom = true, filter = null } = options;

        const tree = [];

        // Custom scripts section (always first)
        if (includeCustom && fs.existsSync(this.customPath)) {
            tree.push({
                name: 'Custom Scripts',
                path: this.customPath,
                type: 'folder',
                editable: true,
                children: this.scanDirectory(this.customPath, { editable: true, filter })
            });
        }

        // Audit Tool scripts (read-only for standard tier)
        const auditsPath = path.join(basePath, 'audits');
        if (fs.existsSync(auditsPath)) {
            tree.push({
                name: 'Audit Scripts',
                path: auditsPath,
                type: 'folder',
                editable: false,
                children: this.scanDirectory(auditsPath, { editable: false, filter })
            });
        }

        // Library scripts
        const libPath = path.join(basePath, 'lib');
        if (fs.existsSync(libPath)) {
            tree.push({
                name: 'Libraries',
                path: libPath,
                type: 'folder',
                editable: false,
                children: this.scanDirectory(libPath, { editable: false, filter })
            });
        }

        return tree;
    }

    /**
     * Recursively scan a directory
     */
    scanDirectory(dirPath, options = {}) {
        const { editable = false, filter = null, maxDepth = 5, currentDepth = 0 } = options;

        if (currentDepth >= maxDepth) return [];

        const items = [];
        
        try {
            const entries = fs.readdirSync(dirPath, { withFileTypes: true });
            
            for (const entry of entries) {
                // Skip hidden files and common excludes
                if (entry.name.startsWith('.') || 
                    entry.name === 'node_modules' ||
                    entry.name === '__pycache__') {
                    continue;
                }

                const fullPath = path.join(dirPath, entry.name);

                if (entry.isDirectory()) {
                    const children = this.scanDirectory(fullPath, {
                        ...options,
                        currentDepth: currentDepth + 1
                    });
                    
                    // Only include folders that have matching children
                    if (!filter || children.length > 0) {
                        items.push({
                            name: entry.name,
                            path: fullPath,
                            type: 'folder',
                            editable,
                            children
                        });
                    }
                } else if (this.isScriptFile(entry.name)) {
                    // Apply filter if specified
                    if (filter && !entry.name.toLowerCase().includes(filter.toLowerCase())) {
                        continue;
                    }

                    items.push({
                        name: entry.name,
                        path: fullPath,
                        type: 'file',
                        editable,
                        language: this.getLanguage(entry.name)
                    });
                }
            }
        } catch (error) {
            console.error(`Error scanning ${dirPath}:`, error.message);
        }

        // Sort folders first, then files
        return items.sort((a, b) => {
            if (a.type === b.type) return a.name.localeCompare(b.name);
            return a.type === 'folder' ? -1 : 1;
        });
    }

    /**
     * Check if file is a script we handle
     */
    isScriptFile(filename) {
        const ext = path.extname(filename).toLowerCase();
        return ['.sh', '.bash', '.ps1', '.psm1'].includes(ext);
    }

    /**
     * Get Monaco language ID for file
     */
    getLanguage(filename) {
        const ext = path.extname(filename).toLowerCase();
        switch (ext) {
            case '.sh':
            case '.bash':
                return 'shell';
            case '.ps1':
            case '.psm1':
                return 'powershell';
            default:
                return 'plaintext';
        }
    }

    /**
     * Read a file's contents
     */
    readFile(filePath) {
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            const stats = fs.statSync(filePath);
            
            return {
                success: true,
                content,
                path: filePath,
                name: path.basename(filePath),
                language: this.getLanguage(filePath),
                modified: stats.mtime,
                size: stats.size
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                path: filePath
            };
        }
    }

    /**
     * Save a file with optional backup
     */
    saveFile(filePath, content, options = {}) {
        const { createBackup = false, isDeveloperTier = false } = options;

        try {
            // Determine if this is a custom script
            const isCustom = filePath.includes('audits/custom') || 
                            filePath.includes('audits\\custom');

            // Create backup for non-custom files (developer tier only)
            if (createBackup && !isCustom && isDeveloperTier) {
                this.createBackup(filePath, 'on-save');
            }

            // Ensure directory exists
            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            // Write file
            fs.writeFileSync(filePath, content, 'utf8');

            return {
                success: true,
                path: filePath,
                message: createBackup && !isCustom ? 'Saved with backup' : 'Saved'
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                path: filePath
            };
        }
    }

    /**
     * Create a backup of a file
     */
    createBackup(filePath, type = 'on-save') {
        try {
            if (!fs.existsSync(filePath)) return null;

            const content = fs.readFileSync(filePath);
            const filename = path.basename(filePath);
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const hash = crypto.createHash('md5').update(content).digest('hex').slice(0, 8);
            
            const backupDir = path.join(this.backupPath, type);
            const backupName = `${filename}.${timestamp}.${hash}`;
            const backupPath = path.join(backupDir, backupName);

            fs.writeFileSync(backupPath, content);
            
            // Clean up old backups based on retention policy
            this.cleanupBackups(backupDir, filename);

            return backupPath;
        } catch (error) {
            console.error('Backup failed:', error.message);
            return null;
        }
    }

    /**
     * Clean up old backups based on retention policy
     * Keep: 30 daily backups per file, unlimited on-save for 7 days
     */
    cleanupBackups(backupDir, originalFilename) {
        try {
            const files = fs.readdirSync(backupDir)
                .filter(f => f.startsWith(originalFilename))
                .map(f => ({
                    name: f,
                    path: path.join(backupDir, f),
                    mtime: fs.statSync(path.join(backupDir, f)).mtime
                }))
                .sort((a, b) => b.mtime - a.mtime);

            const isDailyBackup = backupDir.includes('daily');
            const maxAge = isDailyBackup ? 30 * 24 * 60 * 60 * 1000 : 7 * 24 * 60 * 60 * 1000;
            const cutoffDate = new Date(Date.now() - maxAge);

            for (const file of files) {
                if (file.mtime < cutoffDate) {
                    fs.unlinkSync(file.path);
                }
            }
        } catch (error) {
            console.error('Cleanup error:', error.message);
        }
    }

    /**
     * List backups for a file
     */
    listBackups(filePath) {
        const filename = path.basename(filePath);
        const backups = [];

        for (const type of ['on-save', 'daily']) {
            const backupDir = path.join(this.backupPath, type);
            if (!fs.existsSync(backupDir)) continue;

            const files = fs.readdirSync(backupDir)
                .filter(f => f.startsWith(filename))
                .map(f => {
                    const fullPath = path.join(backupDir, f);
                    const stats = fs.statSync(fullPath);
                    return {
                        name: f,
                        path: fullPath,
                        type,
                        created: stats.mtime,
                        size: stats.size
                    };
                })
                .sort((a, b) => b.created - a.created);

            backups.push(...files);
        }

        return backups;
    }

    /**
     * Restore a backup
     */
    restoreBackup(backupPath, targetPath, createBackupFirst = true) {
        try {
            // Create backup of current file before restore
            if (createBackupFirst && fs.existsSync(targetPath)) {
                this.createBackup(targetPath, 'on-save');
            }

            const content = fs.readFileSync(backupPath);
            fs.writeFileSync(targetPath, content);

            return {
                success: true,
                message: 'Backup restored',
                path: targetPath
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create a new custom script from template
     */
    createCustomScript(name, template, category = 'general') {
        try {
            // Normalize name
            const safeName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
            const ext = template.language === 'powershell' ? '.ps1' : '.sh';
            const filename = safeName.endsWith(ext) ? safeName : `${safeName}${ext}`;

            // Create category folder if specified
            const targetDir = category 
                ? path.join(this.customPath, category)
                : this.customPath;

            if (!fs.existsSync(targetDir)) {
                fs.mkdirSync(targetDir, { recursive: true });
            }

            const targetPath = path.join(targetDir, filename);

            // Check if file already exists
            if (fs.existsSync(targetPath)) {
                return {
                    success: false,
                    error: 'File already exists',
                    path: targetPath
                };
            }

            // Write template content
            fs.writeFileSync(targetPath, template.content, 'utf8');

            return {
                success: true,
                path: targetPath,
                message: 'Script created successfully'
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Delete a custom script (custom folder only)
     */
    deleteScript(filePath) {
        const normalizedPath = filePath.replace(/\\/g, '/');
        
        // Safety check: only allow deleting from custom folder
        if (!normalizedPath.includes('/audits/custom/')) {
            return {
                success: false,
                error: 'Can only delete scripts from custom folder'
            };
        }

        try {
            // Create final backup before delete
            this.createBackup(filePath, 'on-save');
            fs.unlinkSync(filePath);

            return {
                success: true,
                message: 'Script deleted (backup created)'
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
}

module.exports = FileManager;
