/**
 * License Manager - Tiered Access Control
 * 
 * Manages license validation and access levels:
 * - Standard: Create custom scripts + read-only access to existing
 * - Developer: Full edit access to all scripts + auto-backup
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Access levels
const AccessLevel = {
    UNLICENSED: 'unlicensed',
    STANDARD: 'standard',
    DEVELOPER: 'developer'
};

// Public key for license signature verification (replace with real key in production)
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0M7s7K7hZ2x5c8T8xM9v
SAMPLE_KEY_REPLACE_IN_PRODUCTION
-----END PUBLIC KEY-----`;

class LicenseManager {
    constructor(licensePath) {
        this.licensePath = licensePath;
        this.licenseData = null;
        this.accessLevel = AccessLevel.UNLICENSED;
        this.loadLicense();
    }

    /**
     * Load and validate license from file
     */
    loadLicense() {
        try {
            if (fs.existsSync(this.licensePath)) {
                const data = JSON.parse(fs.readFileSync(this.licensePath, 'utf8'));
                
                if (this.validateLicense(data)) {
                    this.licenseData = data;
                    this.accessLevel = data.access_level || AccessLevel.STANDARD;
                    console.log(`License loaded: ${this.accessLevel}`);
                } else {
                    console.warn('License validation failed');
                    this.accessLevel = AccessLevel.UNLICENSED;
                }
            } else {
                console.log('No license file found - running in unlicensed mode');
                this.accessLevel = AccessLevel.UNLICENSED;
            }
        } catch (error) {
            console.error('Error loading license:', error.message);
            this.accessLevel = AccessLevel.UNLICENSED;
        }
    }

    /**
     * Validate license data
     */
    validateLicense(data) {
        // Check required fields
        if (!data.id || !data.email || !data.expires || !data.signature) {
            console.warn('License missing required fields');
            return false;
        }

        // Check expiration
        const expirationDate = new Date(data.expires);
        if (expirationDate < new Date()) {
            console.warn('License has expired');
            return false;
        }

        // In development mode, skip signature verification
        if (process.env.NODE_ENV === 'development' || data.id === 'DEV_LICENSE') {
            return true;
        }

        // Verify signature (production)
        try {
            const dataToVerify = JSON.stringify({
                id: data.id,
                email: data.email,
                access_level: data.access_level,
                expires: data.expires,
                features: data.features
            });

            const verify = crypto.createVerify('SHA256');
            verify.update(dataToVerify);
            return verify.verify(PUBLIC_KEY, data.signature, 'base64');
        } catch (error) {
            console.error('Signature verification failed:', error.message);
            return false;
        }
    }

    /**
     * Activate a new license key
     */
    async activateLicense(licenseKey) {
        try {
            // For demo/development: accept test keys
            if (licenseKey === 'STANDARD-TEST-KEY') {
                const testLicense = this.createTestLicense(AccessLevel.STANDARD);
                fs.writeFileSync(this.licensePath, JSON.stringify(testLicense, null, 2));
                this.loadLicense();
                return { success: true, message: 'Standard license activated' };
            }

            if (licenseKey === 'DEVELOPER-TEST-KEY') {
                const testLicense = this.createTestLicense(AccessLevel.DEVELOPER);
                fs.writeFileSync(this.licensePath, JSON.stringify(testLicense, null, 2));
                this.loadLicense();
                return { success: true, message: 'Developer license activated' };
            }

            // Production: validate with license server
            // TODO: Implement license server validation
            // const response = await fetch('https://license.example.com/activate', {
            //     method: 'POST',
            //     body: JSON.stringify({ key: licenseKey })
            // });

            return { success: false, message: 'Invalid license key' };
        } catch (error) {
            return { success: false, message: error.message };
        }
    }

    /**
     * Create a test license for development
     */
    createTestLicense(accessLevel) {
        const expires = new Date();
        expires.setFullYear(expires.getFullYear() + 1);

        return {
            id: 'DEV_LICENSE',
            email: 'developer@example.com',
            access_level: accessLevel,
            issued: new Date().toISOString(),
            expires: expires.toISOString(),
            features: accessLevel === AccessLevel.DEVELOPER 
                ? ['unlimited_scripts', 'templates', 'edit_existing', 'auto_backup']
                : ['unlimited_scripts', 'templates'],
            signature: 'DEV_MODE_NO_SIGNATURE'
        };
    }

    /**
     * Get current license information
     */
    getLicenseInfo() {
        if (!this.licenseData) {
            return {
                licensed: false,
                accessLevel: AccessLevel.UNLICENSED,
                message: 'No valid license. Custom script creation limited to 5 scripts.'
            };
        }

        return {
            licensed: true,
            accessLevel: this.accessLevel,
            email: this.licenseData.email,
            expires: this.licenseData.expires,
            features: this.licenseData.features || [],
            canEditExisting: this.accessLevel === AccessLevel.DEVELOPER
        };
    }

    /**
     * Check if user can edit a specific file
     */
    canEditFile(filePath) {
        // Normalize path
        const normalizedPath = filePath.replace(/\\/g, '/');

        // Developer license can edit anything
        if (this.accessLevel === AccessLevel.DEVELOPER) {
            return true;
        }

        // Standard license can only edit custom scripts
        if (this.accessLevel === AccessLevel.STANDARD) {
            return normalizedPath.includes('/audits/custom/') || 
                   normalizedPath.includes('\\audits\\custom\\');
        }

        // Unlicensed users can only edit in custom folder (limited)
        if (this.accessLevel === AccessLevel.UNLICENSED) {
            return normalizedPath.includes('/audits/custom/') || 
                   normalizedPath.includes('\\audits\\custom\\');
        }

        return false;
    }

    /**
     * Check if user can view a file (all levels can view)
     */
    canViewFile(filePath) {
        return true; // All license levels can view
    }

    /**
     * Check if backup is required before editing
     */
    requiresBackup(filePath) {
        const normalizedPath = filePath.replace(/\\/g, '/');
        
        // Only require backup for non-custom files
        const isCustom = normalizedPath.includes('/audits/custom/') || 
                         normalizedPath.includes('\\audits\\custom\\');
        
        return !isCustom;
    }

    /**
     * Get current access level
     */
    getAccessLevel() {
        return this.accessLevel;
    }

    /**
     * Check if feature is available
     */
    hasFeature(feature) {
        if (!this.licenseData || !this.licenseData.features) {
            return false;
        }
        return this.licenseData.features.includes(feature);
    }
}

module.exports = LicenseManager;
module.exports.AccessLevel = AccessLevel;
