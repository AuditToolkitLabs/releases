/**
 * Developer Script Studio - Main Process
 * 
 * Electron main process that handles:
 * - Window management
 * - IPC communication with renderer
 * - File system operations
 * - License validation
 */

const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const LicenseManager = require('./license-manager');
const FileManager = require('./file-manager');

// Keep a global reference of the window object
let mainWindow = null;
let licenseManager = null;
let fileManager = null;

// Default audit tool path (can be configured)
const DEFAULT_AUDIT_TOOL_PATH = path.resolve(__dirname, '../../../../');

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1400,
        height: 900,
        minWidth: 1000,
        minHeight: 700,
        title: 'Developer Script Studio',
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js')
        },
        icon: path.join(__dirname, '../../assets/icon.png')
    });

    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));

    // Open DevTools in development
    if (process.argv.includes('--dev')) {
        mainWindow.webContents.openDevTools();
    }

    mainWindow.on('closed', () => {
        mainWindow = null;
    });

    createMenu();
}

function createMenu() {
    const template = [
        {
            label: 'File',
            submenu: [
                {
                    label: 'New Script',
                    accelerator: 'CmdOrCtrl+N',
                    click: () => mainWindow.webContents.send('menu:new-script')
                },
                {
                    label: 'Open Audit Tool Folder',
                    accelerator: 'CmdOrCtrl+O',
                    click: async () => {
                        const result = await dialog.showOpenDialog(mainWindow, {
                            properties: ['openDirectory'],
                            title: 'Select Audit Tool Root Directory'
                        });
                        if (!result.canceled && result.filePaths[0]) {
                            fileManager.setAuditToolPath(result.filePaths[0]);
                            mainWindow.webContents.send('audit-tool-changed', result.filePaths[0]);
                        }
                    }
                },
                { type: 'separator' },
                {
                    label: 'Save',
                    accelerator: 'CmdOrCtrl+S',
                    click: () => mainWindow.webContents.send('menu:save')
                },
                {
                    label: 'Save As...',
                    accelerator: 'CmdOrCtrl+Shift+S',
                    click: () => mainWindow.webContents.send('menu:save-as')
                },
                { type: 'separator' },
                {
                    label: 'Exit',
                    accelerator: 'CmdOrCtrl+Q',
                    click: () => app.quit()
                }
            ]
        },
        {
            label: 'Edit',
            submenu: [
                { role: 'undo' },
                { role: 'redo' },
                { type: 'separator' },
                { role: 'cut' },
                { role: 'copy' },
                { role: 'paste' },
                { role: 'selectAll' }
            ]
        },
        {
            label: 'View',
            submenu: [
                { role: 'reload' },
                { role: 'toggleDevTools' },
                { type: 'separator' },
                { role: 'resetZoom' },
                { role: 'zoomIn' },
                { role: 'zoomOut' },
                { type: 'separator' },
                { role: 'togglefullscreen' }
            ]
        },
        {
            label: 'Help',
            submenu: [
                {
                    label: 'Documentation',
                    click: () => {
                        require('electron').shell.openExternal(
                            'https://github.com/security-audit-toolkit/docs'
                        );
                    }
                },
                {
                    label: 'License Info',
                    click: () => mainWindow.webContents.send('menu:license-info')
                },
                { type: 'separator' },
                {
                    label: 'About',
                    click: () => {
                        dialog.showMessageBox(mainWindow, {
                            type: 'info',
                            title: 'About Developer Script Studio',
                            message: 'Developer Script Studio',
                            detail: `Version: 1.0.0\n\nA companion tool for Security Audit Toolkit.\nCreate and manage custom audit scripts.`
                        });
                    }
                }
            ]
        }
    ];

    const menu = Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(menu);
}

// Initialize managers
function initializeManagers() {
    const licensePath = path.join(app.getPath('userData'), 'license.json');
    licenseManager = new LicenseManager(licensePath);
    fileManager = new FileManager(DEFAULT_AUDIT_TOOL_PATH, licenseManager);
}

// IPC Handlers

// License operations
ipcMain.handle('license:get-info', async () => {
    return licenseManager.getLicenseInfo();
});

ipcMain.handle('license:activate', async (event, licenseKey) => {
    return licenseManager.activateLicense(licenseKey);
});

ipcMain.handle('license:can-edit', async (event, filePath) => {
    return licenseManager.canEditFile(filePath);
});

// File operations
ipcMain.handle('files:get-tree', async () => {
    return fileManager.getFileTree();
});

ipcMain.handle('files:read', async (event, filePath) => {
    return fileManager.readFile(filePath);
});

ipcMain.handle('files:save', async (event, filePath, content) => {
    const canEdit = licenseManager.canEditFile(filePath);
    if (!canEdit) {
        return { success: false, error: 'License does not permit editing this file' };
    }
    return fileManager.saveFile(filePath, content);
});

ipcMain.handle('files:create', async (event, fileName, content, platform) => {
    return fileManager.createCustomScript(fileName, content, platform);
});

ipcMain.handle('files:get-backups', async (event, filePath) => {
    return fileManager.getBackups(filePath);
});

ipcMain.handle('files:restore-backup', async (event, backupPath, originalPath) => {
    return fileManager.restoreBackup(backupPath, originalPath);
});

// Template operations
ipcMain.handle('templates:list', async () => {
    return fileManager.getTemplates();
});

ipcMain.handle('templates:get', async (event, templateName) => {
    return fileManager.getTemplate(templateName);
});

// Validation
ipcMain.handle('validate:syntax', async (event, content, language) => {
    return fileManager.validateSyntax(content, language);
});

// App lifecycle
app.whenReady().then(() => {
    initializeManagers();
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    dialog.showErrorBox('Error', `An unexpected error occurred: ${error.message}`);
});
