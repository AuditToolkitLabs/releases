/**
 * Preload Script - Secure IPC Bridge
 * 
 * Exposes a safe API to the renderer process while keeping
 * Node.js APIs isolated for security.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
    // License operations
    license: {
        getInfo: () => ipcRenderer.invoke('license:get-info'),
        activate: (key) => ipcRenderer.invoke('license:activate', key),
        canEdit: (filePath) => ipcRenderer.invoke('license:can-edit', filePath)
    },

    // File operations
    files: {
        getTree: () => ipcRenderer.invoke('files:get-tree'),
        read: (filePath) => ipcRenderer.invoke('files:read', filePath),
        save: (filePath, content) => ipcRenderer.invoke('files:save', filePath, content),
        create: (fileName, content, platform) => ipcRenderer.invoke('files:create', fileName, content, platform),
        getBackups: (filePath) => ipcRenderer.invoke('files:get-backups', filePath),
        restoreBackup: (backupPath, originalPath) => ipcRenderer.invoke('files:restore-backup', backupPath, originalPath)
    },

    // Template operations
    templates: {
        list: () => ipcRenderer.invoke('templates:list'),
        get: (name) => ipcRenderer.invoke('templates:get', name)
    },

    // Validation
    validate: {
        syntax: (content, language) => ipcRenderer.invoke('validate:syntax', content, language)
    },

    // Menu event listeners
    onMenuEvent: (channel, callback) => {
        const validChannels = [
            'menu:new-script',
            'menu:save',
            'menu:save-as',
            'menu:license-info',
            'audit-tool-changed'
        ];
        if (validChannels.includes(channel)) {
            ipcRenderer.on(channel, (event, ...args) => callback(...args));
        }
    },

    // Remove menu event listener
    removeMenuListener: (channel) => {
        ipcRenderer.removeAllListeners(channel);
    }
});
