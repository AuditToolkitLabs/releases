/**
 * Developer Script Studio - Renderer Process
 * 
 * Handles UI interactions, Monaco editor, and file operations
 */

// Wait for DOM and Monaco to be ready
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

// App state
const state = {
    editor: null,
    currentFile: null,
    isDirty: false,
    licenseInfo: null,
    fileTree: [],
    searchFilter: ''
};

// Initialize application
async function initApp() {
    // Load Monaco editor
    await initMonaco();
    
    // Initialize UI components
    initToolbar();
    initSidebar();
    initModals();
    initResizeHandle();
    initProblemsPanel();
    
    // Load license info
    await loadLicenseInfo();
    
    // Load file tree
    await loadFileTree();
    
    // Set status
    setStatus('Ready');
}

// Initialize Monaco Editor
async function initMonaco() {
    return new Promise((resolve) => {
        require.config({
            paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }
        });

        require(['vs/editor/editor.main'], function() {
            // Define shell language configuration
            monaco.languages.register({ id: 'shell' });
            monaco.languages.setMonarchTokensProvider('shell', getShellLanguage());
            
            // Create editor (hidden until file is opened)
            state.editor = monaco.editor.create(document.getElementById('editor-container'), {
                value: '',
                language: 'shell',
                theme: 'vs-dark',
                automaticLayout: true,
                minimap: { enabled: true },
                fontSize: 14,
                wordWrap: 'on',
                lineNumbers: 'on',
                folding: true,
                scrollBeyondLastLine: false,
                renderWhitespace: 'selection'
            });

            // Track cursor position
            state.editor.onDidChangeCursorPosition((e) => {
                document.getElementById('cursor-position').textContent = 
                    `Ln ${e.position.lineNumber}, Col ${e.position.column}`;
            });

            // Track content changes
            state.editor.onDidChangeModelContent(() => {
                if (state.currentFile) {
                    setDirty(true);
                }
            });

            resolve();
        });
    });
}

// Get shell language definition for Monaco
function getShellLanguage() {
    return {
        tokenizer: {
            root: [
                [/#.*$/, 'comment'],
                [/\$\{[^}]+\}/, 'variable'],
                [/\$[a-zA-Z_][a-zA-Z0-9_]*/, 'variable'],
                [/"([^"\\]|\\.)*"/, 'string'],
                [/'[^']*'/, 'string'],
                [/\b(if|then|else|elif|fi|for|while|do|done|case|esac|function|return|exit|source|export|local|readonly)\b/, 'keyword'],
                [/\b(echo|printf|read|test|true|false|cd|pwd|ls|cat|grep|sed|awk|cut|sort|uniq|wc|head|tail|find|xargs)\b/, 'function'],
                [/[|&;()<>]/, 'delimiter'],
                [/[0-9]+/, 'number']
            ]
        }
    };
}

// Initialize toolbar buttons
function initToolbar() {
    document.getElementById('btn-new').addEventListener('click', showNewScriptModal);
    document.getElementById('btn-save').addEventListener('click', saveFile);
    document.getElementById('btn-validate').addEventListener('click', validateScript);
    document.getElementById('btn-run-test').addEventListener('click', runTestDry);
    document.getElementById('btn-license').addEventListener('click', () => showModal('license-modal'));
    
    // Quick action buttons
    document.getElementById('btn-new-bash')?.addEventListener('click', () => {
        document.getElementById('script-type').value = 'bash';
        showNewScriptModal();
    });
    document.getElementById('btn-new-ps')?.addEventListener('click', () => {
        document.getElementById('script-type').value = 'powershell';
        showNewScriptModal();
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            saveFile();
        }
        if (e.ctrlKey && e.key === 'n') {
            e.preventDefault();
            showNewScriptModal();
        }
    });
}

// Initialize sidebar file tree
function initSidebar() {
    document.getElementById('file-search').addEventListener('input', (e) => {
        state.searchFilter = e.target.value;
        renderFileTree();
    });
}

// Initialize modals
function initModals() {
    // Close buttons
    document.querySelectorAll('.modal-close, [data-modal]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modalId = e.target.dataset.modal || e.target.closest('[data-modal]')?.dataset.modal;
            if (modalId) hideModal(modalId);
        });
    });

    // Modal backdrops
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            if (modal) modal.classList.remove('active');
        });
    });

    // Create script button
    document.getElementById('btn-create-script').addEventListener('click', createNewScript);
    
    // Activate license button
    document.getElementById('btn-activate-license').addEventListener('click', activateLicense);
    
    // View backups button
    document.getElementById('btn-view-backups')?.addEventListener('click', showBackups);
}

// Initialize resize handle
function initResizeHandle() {
    const handle = document.getElementById('resize-handle');
    const sidebar = document.getElementById('sidebar');
    let isResizing = false;

    handle.addEventListener('mousedown', () => {
        isResizing = true;
        handle.classList.add('resizing');
    });

    document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        const newWidth = e.clientX;
        if (newWidth >= 180 && newWidth <= 400) {
            sidebar.style.width = `${newWidth}px`;
        }
    });

    document.addEventListener('mouseup', () => {
        isResizing = false;
        handle.classList.remove('resizing');
    });
}

// Initialize problems panel
function initProblemsPanel() {
    document.getElementById('problems-toggle').addEventListener('click', () => {
        document.getElementById('problems-panel').classList.toggle('collapsed');
    });
}

// Load license information
async function loadLicenseInfo() {
    state.licenseInfo = await window.api.license.getInfo();
    updateLicenseBadge();
}

// Update license badge display
function updateLicenseBadge() {
    const badge = document.getElementById('license-badge');
    const info = state.licenseInfo;

    badge.className = 'license-badge ' + (info.accessLevel || 'unlicensed');
    badge.textContent = info.licensed 
        ? (info.accessLevel === 'developer' ? 'Developer' : 'Standard')
        : 'Unlicensed';
}

// Load file tree from main process
async function loadFileTree() {
    state.fileTree = await window.api.files.getTree();
    renderFileTree();
}

// Render file tree in sidebar
function renderFileTree() {
    const container = document.getElementById('file-tree');
    container.innerHTML = '';

    const filtered = filterTree(state.fileTree, state.searchFilter);
    
    for (const item of filtered) {
        container.appendChild(createTreeItem(item, 0));
    }
}

// Filter tree based on search
function filterTree(items, filter) {
    if (!filter) return items;
    
    return items.map(item => {
        if (item.type === 'folder') {
            const children = filterTree(item.children || [], filter);
            if (children.length > 0 || item.name.toLowerCase().includes(filter.toLowerCase())) {
                return { ...item, children };
            }
            return null;
        }
        return item.name.toLowerCase().includes(filter.toLowerCase()) ? item : null;
    }).filter(Boolean);
}

// Create a tree item element
function createTreeItem(item, depth) {
    const div = document.createElement('div');
    
    if (item.type === 'folder') {
        div.innerHTML = `
            <div class="tree-item folder" style="padding-left: ${8 + depth * 12}px">
                <span class="tree-arrow">▶</span>
                <span class="tree-icon">📁</span>
                <span class="tree-label">${item.name}</span>
            </div>
            <div class="tree-children collapsed"></div>
        `;

        const folderItem = div.querySelector('.tree-item');
        const children = div.querySelector('.tree-children');

        folderItem.addEventListener('click', () => {
            folderItem.classList.toggle('expanded');
            children.classList.toggle('collapsed');
        });

        if (item.children) {
            for (const child of item.children) {
                children.appendChild(createTreeItem(child, depth + 1));
            }
        }
    } else {
        const icon = item.language === 'powershell' ? '📘' : '📄';
        const readonlyClass = item.editable ? '' : 'readonly';
        
        div.innerHTML = `
            <div class="tree-item file ${readonlyClass}" style="padding-left: ${8 + depth * 12}px" data-path="${item.path}">
                <span class="tree-icon">${icon}</span>
                <span class="tree-label">${item.name}</span>
            </div>
        `;

        div.querySelector('.tree-item').addEventListener('click', () => {
            openFile(item.path);
        });
    }

    return div;
}

// Open a file
async function openFile(filePath) {
    // Check for unsaved changes
    if (state.isDirty) {
        if (!confirm('You have unsaved changes. Open a different file?')) {
            return;
        }
    }

    const result = await window.api.files.read(filePath);
    
    if (!result.success) {
        alert('Failed to open file: ' + result.error);
        return;
    }

    state.currentFile = result;
    
    // Hide placeholder, show editor
    document.querySelector('.editor-placeholder')?.remove();
    
    // Check if file is editable
    const canEdit = await window.api.license.canEdit(filePath);
    
    // Update editor
    const language = result.language === 'shell' ? 'shell' : result.language;
    const model = monaco.editor.createModel(result.content, language);
    state.editor.setModel(model);
    state.editor.updateOptions({ readOnly: !canEdit });
    
    // Update UI
    document.getElementById('file-name').textContent = result.name;
    document.getElementById('language-mode').textContent = 
        language === 'shell' ? 'Bash' : 'PowerShell';
    document.getElementById('btn-save').disabled = !canEdit;
    
    // Update properties panel
    updateProperties(result, canEdit);
    
    setDirty(false);
    setStatus('Opened: ' + result.name);
    
    // Highlight in tree
    document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
    document.querySelector(`[data-path="${filePath}"]`)?.classList.add('selected');
}

// Update properties panel
function updateProperties(file, canEdit) {
    document.getElementById('prop-type').textContent = 
        file.language === 'shell' ? 'Bash Script' : 'PowerShell Script';
    document.getElementById('prop-location').textContent = file.path;
    document.getElementById('prop-size').textContent = formatBytes(file.size);
    document.getElementById('prop-modified').textContent = new Date(file.modified).toLocaleString();
    document.getElementById('prop-editable').textContent = canEdit ? 'Yes' : 'Read-only';
    
    // Show backup section for developer tier on non-custom files
    const isCustom = file.path.includes('audits/custom') || file.path.includes('audits\\custom');
    const backupSection = document.getElementById('backup-section');
    if (backupSection) {
        backupSection.style.display = 
            (state.licenseInfo?.accessLevel === 'developer' && !isCustom) ? 'block' : 'none';
    }
}

// Format bytes to human readable
function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Save current file
async function saveFile() {
    if (!state.currentFile || !state.isDirty) return;
    
    const content = state.editor.getValue();
    const canEdit = await window.api.license.canEdit(state.currentFile.path);
    
    if (!canEdit) {
        alert('You do not have permission to edit this file.');
        return;
    }

    const result = await window.api.files.save(state.currentFile.path, content);
    
    if (result.success) {
        setDirty(false);
        setStatus(result.message || 'Saved');
    } else {
        alert('Failed to save: ' + result.error);
    }
}

// Set dirty state
function setDirty(dirty) {
    state.isDirty = dirty;
    document.getElementById('file-status').textContent = dirty ? '● Modified' : '';
}

// Set status message
function setStatus(message) {
    document.getElementById('status-message').textContent = message;
}

// Show modal
function showModal(id) {
    document.getElementById(id).classList.add('active');
}

// Hide modal
function hideModal(id) {
    document.getElementById(id).classList.remove('active');
}

// Show new script modal
function showNewScriptModal() {
    document.getElementById('script-name').value = '';
    document.getElementById('script-category').value = 'general';
    showModal('new-script-modal');
}

// Create new script
async function createNewScript() {
    const name = document.getElementById('script-name').value.trim();
    const type = document.getElementById('script-type').value;
    const templateName = document.getElementById('script-template').value;
    const category = document.getElementById('script-category').value.trim();

    if (!name) {
        alert('Please enter a script name');
        return;
    }

    // Get template content
    const template = await window.api.templates.get(templateName, type);
    
    // Create the script
    const result = await window.api.files.createCustomScript(name, template, category);
    
    if (result.success) {
        hideModal('new-script-modal');
        await loadFileTree();
        openFile(result.path);
        setStatus('Created: ' + name);
    } else {
        alert('Failed to create script: ' + result.error);
    }
}

// Validate current script
async function validateScript() {
    if (!state.currentFile) {
        alert('No file open');
        return;
    }

    setStatus('Validating...');
    
    const content = state.editor.getValue();
    const language = state.currentFile.language;
    
    const result = await window.api.validate(content, language);
    
    // Update problems panel
    const problemsList = document.getElementById('problems-list');
    problemsList.innerHTML = '';
    
    const problems = result.issues || [];
    document.getElementById('problems-count').textContent = problems.length;
    
    if (problems.length === 0) {
        problemsList.innerHTML = '<div class="loading">No problems found ✓</div>';
        setStatus('Validation passed');
    } else {
        for (const issue of problems) {
            const item = document.createElement('div');
            item.className = `problem-item ${issue.severity}`;
            item.innerHTML = `
                <span class="icon">${issue.severity === 'error' ? '⛔' : '⚠️'}</span>
                <span class="message">${issue.message}</span>
                <span class="location">Ln ${issue.line}</span>
            `;
            item.addEventListener('click', () => {
                state.editor.setPosition({ lineNumber: issue.line, column: 1 });
                state.editor.focus();
            });
            problemsList.appendChild(item);
        }
        setStatus(`Validation: ${problems.length} issue(s) found`);
    }

    // Open problems panel
    document.getElementById('problems-panel').classList.remove('collapsed');
}

// Run test (dry run)
async function runTestDry() {
    if (!state.currentFile) {
        alert('No file open');
        return;
    }
    
    alert('Dry run feature coming soon!\n\nThis will execute the script in a sandboxed environment to verify basic functionality.');
}

// Activate license
async function activateLicense() {
    const key = document.getElementById('license-key').value.trim();
    
    if (!key) {
        alert('Please enter a license key');
        return;
    }

    const result = await window.api.license.activate(key);
    
    if (result.success) {
        await loadLicenseInfo();
        hideModal('license-modal');
        alert(result.message);
        await loadFileTree(); // Refresh to show editable status
    } else {
        alert('Activation failed: ' + result.message);
    }
}

// Show backups modal
async function showBackups() {
    if (!state.currentFile) return;
    
    const backups = await window.api.files.getBackups(state.currentFile.path);
    const list = document.getElementById('backups-list');
    list.innerHTML = '';

    if (backups.length === 0) {
        list.innerHTML = '<div class="loading">No backups available</div>';
    } else {
        for (const backup of backups) {
            const item = document.createElement('div');
            item.className = 'backup-item';
            item.innerHTML = `
                <div class="backup-info">
                    <div class="backup-name">${backup.name}</div>
                    <div class="backup-meta">${new Date(backup.created).toLocaleString()} • ${formatBytes(backup.size)}</div>
                </div>
                <div class="backup-actions">
                    <button class="small-btn btn-restore" data-path="${backup.path}">Restore</button>
                </div>
            `;
            
            item.querySelector('.btn-restore').addEventListener('click', async () => {
                if (confirm('Restore this backup? Current content will be backed up first.')) {
                    const result = await window.api.files.restoreBackup(backup.path, state.currentFile.path);
                    if (result.success) {
                        hideModal('backups-modal');
                        openFile(state.currentFile.path);
                        setStatus('Backup restored');
                    } else {
                        alert('Failed to restore: ' + result.error);
                    }
                }
            });
            
            list.appendChild(item);
        }
    }

    showModal('backups-modal');
}

// Update license info display in modal when opened
document.getElementById('btn-license')?.addEventListener('click', () => {
    const info = state.licenseInfo;
    const infoDiv = document.getElementById('license-info');
    
    if (info && info.licensed) {
        infoDiv.innerHTML = `
            <strong>Status:</strong> Active (${info.accessLevel})<br>
            <strong>Email:</strong> ${info.email}<br>
            <strong>Expires:</strong> ${new Date(info.expires).toLocaleDateString()}
        `;
        infoDiv.style.borderLeft = '3px solid var(--success)';
    } else {
        infoDiv.innerHTML = `
            <strong>Status:</strong> Not licensed<br>
            <em>Enter a license key below to activate.</em>
        `;
        infoDiv.style.borderLeft = '3px solid var(--error)';
    }
});
