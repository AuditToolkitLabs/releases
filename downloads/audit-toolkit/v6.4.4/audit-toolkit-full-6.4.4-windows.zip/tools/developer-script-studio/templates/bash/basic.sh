#!/usr/bin/env bash
# =============================================================================
# Basic Audit Script Template
# =============================================================================
# Description: [Brief description of what this audit checks]
# Author:      [Your name]
# Created:     [Date]
# =============================================================================

set -euo pipefail

# Get script directory for relative paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source common library (adjust path based on your location)
# If in audits/custom/, path is: ../../lib/common.sh
if [[ -f "${SCRIPT_DIR}/../../lib/common.sh" ]]; then
    # shellcheck source=/dev/null
    . "${SCRIPT_DIR}/../../lib/common.sh"
else
    # Fallback: define minimal logging functions
    log_info()  { echo "[INFO]  $*"; }
    log_warn()  { echo "[WARN]  $*"; }
    log_error() { echo "[ERROR] $*"; }
    log_pass()  { echo "[PASS]  $*"; }
    log_fail()  { echo "[FAIL]  $*"; }
fi

# =============================================================================
# CONFIGURATION
# =============================================================================

# Define any configurable thresholds or parameters here
readonly CHECK_NAME="Basic Audit Check"

# =============================================================================
# FUNCTIONS
# =============================================================================

check_example() {
    local description="Example check description"
    
    # Perform your check here
    # Return 0 for PASS, 1 for FAIL
    
    if [[ -f "/etc/passwd" ]]; then
        log_pass "$description: /etc/passwd exists"
        return 0
    else
        log_fail "$description: /etc/passwd not found"
        return 1
    fi
}

# =============================================================================
# MAIN
# =============================================================================

main() {
    echo "========================================"
    echo " ${CHECK_NAME}"
    echo "========================================"
    echo ""
    
    local total=0
    local passed=0
    local failed=0
    
    # Run checks
    if check_example; then
        ((passed++))
    else
        ((failed++))
    fi
    ((total++))
    
    # Add more checks here...
    
    # Summary
    echo ""
    echo "========================================"
    echo " Summary: ${passed}/${total} passed, ${failed} failed"
    echo "========================================"
    
    # Exit with appropriate code
    if [[ ${failed} -gt 0 ]]; then
        exit 1
    fi
    exit 0
}

main "$@"
