#!/usr/bin/env bash
# =============================================================================
# Security Assessment Template
# =============================================================================
# Description: Security vulnerability and configuration assessment
# Focus Area:  [e.g., Network, Authentication, File System]
# Author:      [Your name]
# Created:     [Date]
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source libraries
for lib in common.sh distro.sh pkg.sh svc.sh; do
    if [[ -f "${SCRIPT_DIR}/../../lib/${lib}" ]]; then
        # shellcheck source=/dev/null
        . "${SCRIPT_DIR}/../../lib/${lib}"
    fi
done

# =============================================================================
# SECURITY CONFIGURATION
# =============================================================================

readonly ASSESSMENT_NAME="Security Assessment"
readonly SEVERITY_CRITICAL=4
readonly SEVERITY_HIGH=3
readonly SEVERITY_MEDIUM=2
readonly SEVERITY_LOW=1

# Findings array
declare -a FINDINGS=()
declare -A FINDING_SEVERITY=()

# =============================================================================
# SECURITY FUNCTIONS
# =============================================================================

add_finding() {
    local severity="$1"
    local title="$2"
    local description="$3"
    local remediation="${4:-}"
    
    local id="${#FINDINGS[@]}"
    FINDINGS+=("${title}")
    FINDING_SEVERITY["${id}"]="${severity}"
    
    local sev_label
    case "${severity}" in
        4) sev_label="CRITICAL" ;;
        3) sev_label="HIGH" ;;
        2) sev_label="MEDIUM" ;;
        1) sev_label="LOW" ;;
        *) sev_label="INFO" ;;
    esac
    
    echo ""
    echo "[${sev_label}] ${title}"
    echo "  Description: ${description}"
    if [[ -n "${remediation}" ]]; then
        echo "  Remediation: ${remediation}"
    fi
}

# Check for world-writable files
check_world_writable() {
    echo "Checking for world-writable files in sensitive directories..."
    
    local sensitive_dirs=("/etc" "/usr" "/bin" "/sbin")
    local found=0
    
    for dir in "${sensitive_dirs[@]}"; do
        if [[ -d "${dir}" ]]; then
            while IFS= read -r file; do
                add_finding "${SEVERITY_HIGH}" \
                    "World-writable file: ${file}" \
                    "File has world-writable permissions which could allow unauthorized modification" \
                    "chmod o-w '${file}'"
                ((found++))
            done < <(find "${dir}" -type f -perm -o+w 2>/dev/null | head -20)
        fi
    done
    
    if [[ ${found} -eq 0 ]]; then
        echo "[PASS] No world-writable files found in sensitive directories"
    fi
}

# Check for SUID/SGID binaries
check_suid_sgid() {
    echo "Checking for unexpected SUID/SGID binaries..."
    
    # Known safe SUID binaries
    local known_safe=(
        "/usr/bin/passwd"
        "/usr/bin/sudo"
        "/usr/bin/su"
        "/usr/bin/mount"
        "/usr/bin/umount"
        "/usr/bin/ping"
    )
    
    while IFS= read -r binary; do
        local is_safe=false
        for safe in "${known_safe[@]}"; do
            if [[ "${binary}" == "${safe}" ]]; then
                is_safe=true
                break
            fi
        done
        
        if [[ "${is_safe}" == false ]]; then
            add_finding "${SEVERITY_MEDIUM}" \
                "SUID/SGID binary: ${binary}" \
                "Binary has SUID/SGID bit set. Verify this is required." \
                "chmod u-s '${binary}' or chmod g-s '${binary}'"
        fi
    done < <(find /usr/bin /usr/sbin /bin /sbin -type f \( -perm -4000 -o -perm -2000 \) 2>/dev/null | head -50)
}

# Check SSH configuration
check_ssh_config() {
    echo "Checking SSH configuration..."
    
    local ssh_config="/etc/ssh/sshd_config"
    
    if [[ ! -f "${ssh_config}" ]]; then
        echo "[SKIP] SSH not installed or config not found"
        return
    fi
    
    # Check PermitRootLogin
    if grep -qE "^PermitRootLogin\s+(yes|without-password)" "${ssh_config}" 2>/dev/null; then
        add_finding "${SEVERITY_HIGH}" \
            "SSH root login enabled" \
            "Direct root login is permitted via SSH" \
            "Set 'PermitRootLogin no' in ${ssh_config}"
    else
        echo "[PASS] SSH root login is properly restricted"
    fi
    
    # Check PasswordAuthentication
    if grep -qE "^PasswordAuthentication\s+yes" "${ssh_config}" 2>/dev/null; then
        add_finding "${SEVERITY_MEDIUM}" \
            "SSH password authentication enabled" \
            "Password authentication increases brute-force risk" \
            "Consider 'PasswordAuthentication no' and use key-based auth"
    fi
    
    # Check Protocol version (legacy systems)
    if grep -qE "^Protocol\s+1" "${ssh_config}" 2>/dev/null; then
        add_finding "${SEVERITY_CRITICAL}" \
            "SSH Protocol 1 enabled" \
            "SSH Protocol 1 has known vulnerabilities" \
            "Set 'Protocol 2' in ${ssh_config}"
    fi
}

# Check for empty passwords
check_empty_passwords() {
    echo "Checking for accounts with empty passwords..."
    
    if [[ -r /etc/shadow ]]; then
        while IFS=: read -r user pass _; do
            if [[ "${pass}" == "" || "${pass}" == "!" || "${pass}" == "*" ]]; then
                continue  # Locked or no-login accounts
            fi
            # Check for empty password hash
            if [[ "${pass}" == "" ]]; then
                add_finding "${SEVERITY_CRITICAL}" \
                    "Empty password: ${user}" \
                    "Account has no password set" \
                    "passwd ${user}"
            fi
        done < /etc/shadow
        echo "[PASS] No accounts with empty passwords found"
    else
        echo "[SKIP] Cannot read /etc/shadow (need root)"
    fi
}

# Check firewall status
check_firewall() {
    echo "Checking firewall status..."
    
    local fw_active=false
    
    # Check iptables
    if command -v iptables &>/dev/null; then
        local rules
        rules=$(iptables -L -n 2>/dev/null | wc -l || echo "0")
        if [[ ${rules} -gt 8 ]]; then
            fw_active=true
            echo "[PASS] iptables has active rules"
        fi
    fi
    
    # Check firewalld
    if command -v firewall-cmd &>/dev/null; then
        if firewall-cmd --state &>/dev/null; then
            fw_active=true
            echo "[PASS] firewalld is active"
        fi
    fi
    
    # Check ufw
    if command -v ufw &>/dev/null; then
        if ufw status 2>/dev/null | grep -q "Status: active"; then
            fw_active=true
            echo "[PASS] ufw is active"
        fi
    fi
    
    if [[ "${fw_active}" == false ]]; then
        add_finding "${SEVERITY_HIGH}" \
            "No firewall detected" \
            "No active firewall rules found" \
            "Enable firewalld, ufw, or configure iptables"
    fi
}

# =============================================================================
# REPORT GENERATION
# =============================================================================

generate_report() {
    local critical=0
    local high=0
    local medium=0
    local low=0
    
    for id in "${!FINDING_SEVERITY[@]}"; do
        case "${FINDING_SEVERITY[${id}]}" in
            4) ((critical++)) ;;
            3) ((high++)) ;;
            2) ((medium++)) ;;
            1) ((low++)) ;;
        esac
    done
    
    echo ""
    echo "========================================"
    echo " SECURITY ASSESSMENT REPORT"
    echo "========================================"
    echo " Date:     $(date '+%Y-%m-%d %H:%M:%S')"
    echo " Host:     $(hostname)"
    echo "========================================"
    echo ""
    echo " FINDINGS SUMMARY:"
    echo "   Critical: ${critical}"
    echo "   High:     ${high}"
    echo "   Medium:   ${medium}"
    echo "   Low:      ${low}"
    echo "   Total:    ${#FINDINGS[@]}"
    echo ""
    echo "========================================"
    
    # Risk score calculation
    local risk_score=$((critical * 10 + high * 5 + medium * 2 + low))
    echo " RISK SCORE: ${risk_score}"
    if [[ ${risk_score} -ge 50 ]]; then
        echo " RISK LEVEL: CRITICAL - Immediate action required"
    elif [[ ${risk_score} -ge 20 ]]; then
        echo " RISK LEVEL: HIGH - Action required soon"
    elif [[ ${risk_score} -ge 10 ]]; then
        echo " RISK LEVEL: MEDIUM - Address in next maintenance window"
    else
        echo " RISK LEVEL: LOW - Good security posture"
    fi
    echo "========================================"
}

# =============================================================================
# MAIN
# =============================================================================

main() {
    echo "========================================"
    echo " ${ASSESSMENT_NAME}"
    echo " $(date '+%Y-%m-%d %H:%M:%S')"
    echo "========================================"
    echo ""
    
    # Run security checks
    check_world_writable
    check_suid_sgid
    check_ssh_config
    check_empty_passwords
    check_firewall
    
    # Generate report
    generate_report
    
    # Exit code based on findings
    if [[ ${#FINDINGS[@]} -gt 0 ]]; then
        exit 1
    fi
    exit 0
}

main "$@"
