# =============================================================================
# Compliance Check Template (PowerShell)
# =============================================================================
# Description: [Compliance standard being checked, e.g., CIS, PCI-DSS, HIPAA]
# Standard:    [Reference to specific control, e.g., CIS 1.1.1]
# Author:      [Your name]
# Created:     [Date]
# =============================================================================

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# =============================================================================
# COMPLIANCE CONFIGURATION
# =============================================================================

$script:ComplianceStandard = "[CIS/PCI-DSS/HIPAA]"
$script:ControlID = "[Control ID]"
$script:ControlDescription = "[Control description]"
$script:RemediationLevel = "[1 = Scored, 2 = Not Scored]"

$script:Results = [System.Collections.ArrayList]@()

# =============================================================================
# COMPLIANCE CHECK FUNCTIONS
# =============================================================================

function Add-ComplianceResult {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("Pass", "Fail", "Skip", "Manual")]
        [string]$Status,

        [Parameter(Mandatory)]
        [string]$ControlID,

        [Parameter(Mandatory)]
        [string]$Description,

        [string]$Expected,
        [string]$Actual,
        [string]$Remediation
    )

    $result = [PSCustomObject]@{
        Status      = $Status
        ControlID   = $ControlID
        Description = $Description
        Expected    = $Expected
        Actual      = $Actual
        Remediation = $Remediation
        Timestamp   = Get-Date
    }

    [void]$script:Results.Add($result)

    # Output to console
    Write-Output "[$Status] "
    Write-Output "$ControlID - $Description"

    if ($Expected -and $Actual) {
        Write-Output "       Expected: $Expected"
        Write-Output "       Actual:   $Actual"
    }
}

# =============================================================================
# EXAMPLE COMPLIANCE CHECKS
# =============================================================================

function Test-PasswordPolicy {
    <#
    .SYNOPSIS
    Check password policy compliance
    #>

    try {
        $policy = Get-ADDefaultDomainPasswordPolicy -ErrorAction SilentlyContinue

        if ($null -eq $policy) {
            # Try local policy for non-domain systems
            secedit /export /cfg "$env:TEMP\secpol.cfg" 2>$null | Out-Null
            $content = Get-Content "$env:TEMP\secpol.cfg" -ErrorAction SilentlyContinue
            Remove-Item "$env:TEMP\secpol.cfg" -Force -ErrorAction SilentlyContinue

            if ($content) {
                $minLength = ($content | Select-String "MinimumPasswordLength").Line -replace '.*= ',''

                Add-ComplianceResult -Status $(if ([int]$minLength -ge 14) { "Pass" } else { "Fail" }) `
                    -ControlID "1.1.1" `
                    -Description "Minimum password length" `
                    -Expected "14 or greater" `
                    -Actual $minLength `
                    -Remediation "Set 'Minimum password length' to 14 or more in Group Policy"
            } else {
                Add-ComplianceResult -Status "Skip" -ControlID "1.1.1" -Description "Password policy check" -Remediation "Unable to retrieve password policy"
            }
            return
        }

        # Check minimum length
        Add-ComplianceResult -Status $(if ($policy.MinPasswordLength -ge 14) { "Pass" } else { "Fail" }) `
            -ControlID "1.1.1" `
            -Description "Minimum password length" `
            -Expected "14 or greater" `
            -Actual $policy.MinPasswordLength.ToString() `
            -Remediation "Set-ADDefaultDomainPasswordPolicy -MinPasswordLength 14"

        # Check complexity
        Add-ComplianceResult -Status $(if ($policy.ComplexityEnabled) { "Pass" } else { "Fail" }) `
            -ControlID "1.1.2" `
            -Description "Password complexity enabled" `
            -Expected "True" `
            -Actual $policy.ComplexityEnabled.ToString() `
            -Remediation "Set-ADDefaultDomainPasswordPolicy -ComplexityEnabled $true"
    }
    catch {
        Add-ComplianceResult -Status "Skip" -ControlID "1.1.x" -Description "Password policy" -Remediation "Error: $_"
    }
}

function Test-AuditPolicy {
    <#
    .SYNOPSIS
    Check audit policy compliance
    #>

    try {
        $auditPolicy = auditpol /get /category:* 2>$null

        # Check logon events
        $logonAudit = $auditPolicy | Select-String "Logon"
        if ($logonAudit -match "Success and Failure") {
            Add-ComplianceResult -Status "Pass" -ControlID "2.1.1" -Description "Logon events audited" -Expected "Success and Failure" -Actual "Success and Failure"
        } else {
            Add-ComplianceResult -Status "Fail" -ControlID "2.1.1" -Description "Logon events audited" -Expected "Success and Failure" -Actual "Not configured" -Remediation "auditpol /set /subcategory:'Logon' /success:enable /failure:enable"
        }
    }
    catch {
        Add-ComplianceResult -Status "Skip" -ControlID "2.1.x" -Description "Audit policy" -Remediation "Error: $_"
    }
}

function Test-ServiceConfiguration {
    <#
    .SYNOPSIS
    Check for disabled unnecessary services
    #>

    $servicestoDisable = @(
        @{ Name = "RemoteRegistry"; ControlID = "3.1.1"; Description = "Remote Registry service" }
        @{ Name = "Fax"; ControlID = "3.1.2"; Description = "Fax service" }
        @{ Name = "Telnet"; ControlID = "3.1.3"; Description = "Telnet service" }
    )

    foreach ($svc in $servicestoDisable) {
        $service = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue

        if ($null -eq $service) {
            Add-ComplianceResult -Status "Pass" -ControlID $svc.ControlID -Description "$($svc.Description) disabled/not installed" -Expected "Disabled or Not Installed" -Actual "Not Installed"
        }
        elseif ($service.StartType -eq "Disabled") {
            Add-ComplianceResult -Status "Pass" -ControlID $svc.ControlID -Description "$($svc.Description) disabled" -Expected "Disabled" -Actual "Disabled"
        }
        else {
            Add-ComplianceResult -Status "Fail" -ControlID $svc.ControlID -Description "$($svc.Description) should be disabled" -Expected "Disabled" -Actual $service.StartType -Remediation "Set-Service -Name '$($svc.Name)' -StartupType Disabled"
        }
    }
}

# =============================================================================
# REPORT GENERATION
# =============================================================================

function Get-ComplianceReport {
    $passed = ($script:Results | Where-Object { $_.Status -eq "Pass" }).Count
    $failed = ($script:Results | Where-Object { $_.Status -eq "Fail" }).Count
    $skipped = ($script:Results | Where-Object { $_.Status -eq "Skip" }).Count
    $manual = ($script:Results | Where-Object { $_.Status -eq "Manual" }).Count
    $total = $script:Results.Count

    $complianceScore = if ($total -gt 0) { [math]::Round(($passed / ($passed + $failed)) * 100, 1) } else { 0 }

    Write-Output ""
    Write-Output "========================================"
    Write-Output " COMPLIANCE REPORT"
    Write-Output "========================================"
    Write-Output " Standard:    $script:ComplianceStandard"
    Write-Output " Control:     $script:ControlID"
    Write-Output " Date:        $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Output " Host:        $env:COMPUTERNAME"
    Write-Output "========================================"
    Write-Output ""
    Write-Output " RESULTS:"
    Write-Output "   Passed:  $passed"
    Write-Output "   Failed:  $failed"
    Write-Output "   Skipped: $skipped"
    Write-Output "   Manual:  $manual"
    Write-Output "   Total:   $total"
    Write-Output ""
    Write-Output " COMPLIANCE SCORE: $complianceScore%"
    Write-Output "========================================"

    # Export detailed report
    if ($failed -gt 0) {
        Write-Output ""
        Write-Output "FAILED CONTROLS:"
        $script:Results | Where-Object { $_.Status -eq "Fail" } | ForEach-Object {
            Write-Output "  $($_.ControlID): $($_.Description)"
            if ($_.Remediation) {
                Write-Output "    Remediation: $($_.Remediation)"
            }
        }
    }

    return @{
        Score = $complianceScore
        Results = $script:Results
        Summary = @{
            Passed = $passed
            Failed = $failed
            Skipped = $skipped
            Manual = $manual
            Total = $total
        }
    }
}

# =============================================================================
# MAIN
# =============================================================================

function Invoke-ComplianceAudit {
    Write-Output "========================================"
    Write-Output " Compliance Audit: $script:ComplianceStandard"
    Write-Output " $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Output "========================================"
    Write-Output ""

    # Run compliance checks
    Test-PasswordPolicy
    Test-AuditPolicy
    Test-ServiceConfiguration

    # Generate report
    $report = Get-ComplianceReport

    # Exit code
    if ($report.Summary.Failed -gt 0) {
        exit 1
    }
    exit 0
}

# Execute
Invoke-ComplianceAudit
