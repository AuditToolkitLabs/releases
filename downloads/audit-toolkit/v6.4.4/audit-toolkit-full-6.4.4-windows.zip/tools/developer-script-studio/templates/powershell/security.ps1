# =============================================================================
# Security Assessment Template (PowerShell)
# =============================================================================
# Description: Security vulnerability and configuration assessment
# Focus Area:  [e.g., Network, Authentication, File System]
# Author:      [Your name]
# Created:     [Date]
# =============================================================================

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param()
#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# =============================================================================
# SECURITY CONFIGURATION
# =============================================================================

$script:AssessmentName = "Security Assessment"

# Severity levels
$script:Severity = @{
    Critical = 4
    High     = 3
    Medium   = 2
    Low      = 1
    Info     = 0
}

$script:Findings = [System.Collections.ArrayList]@()

# =============================================================================
# FINDING FUNCTIONS
# =============================================================================

function Add-Finding {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("Critical", "High", "Medium", "Low", "Info")]
        [string]$Severity,

        [Parameter(Mandatory)]
        [string]$Title,

        [Parameter(Mandatory)]
        [string]$Description,

        [string]$Remediation,
        [string]$Reference
    )

    $finding = [PSCustomObject]@{
        Severity    = $Severity
        SeverityInt = $script:Severity[$Severity]
        Title       = $Title
        Description = $Description
        Remediation = $Remediation
        Reference   = $Reference
        Timestamp   = Get-Date
    }

    [void]$script:Findings.Add($finding)

    Write-Output ""
    Write-Output "[$Severity] "
    Write-Output $Title
    Write-Output "  Description: $Description"
    if ($Remediation) {
        Write-Output "  Remediation: $Remediation"
    }
}

function Write-CheckPass {
    param([string]$Message)
    Write-Output "[PASS] "
    Write-Output $Message
}

# =============================================================================
# SECURITY CHECKS
# =============================================================================

function Test-WindowsDefender {
    <#
    .SYNOPSIS
    Check Windows Defender configuration and status
    #>

    Write-Output "Checking Windows Defender status..."

    try {
        $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue

        if ($null -eq $defender) {
            Add-Finding -Severity "High" `
                -Title "Windows Defender not available" `
                -Description "Windows Defender is not installed or accessible" `
                -Remediation "Install and enable Windows Defender or alternative AV"
            return
        }

        # Real-time protection
        if (-not $defender.RealTimeProtectionEnabled) {
            Add-Finding -Severity "Critical" `
                -Title "Real-time protection disabled" `
                -Description "Windows Defender real-time protection is not enabled" `
                -Remediation "Set-MpPreference -DisableRealtimeMonitoring $false"
        } else {
            Write-CheckPass "Real-time protection enabled"
        }

        # Signature age
        $signatureAge = (Get-Date) - $defender.AntivirusSignatureLastUpdated
        if ($signatureAge.Days -gt 7) {
            Add-Finding -Severity "High" `
                -Title "Antivirus signatures outdated" `
                -Description "Signatures are $($signatureAge.Days) days old" `
                -Remediation "Update-MpSignature"
        } else {
            Write-CheckPass "Antivirus signatures up to date ($($signatureAge.Days) days old)"
        }

        # Behavior monitoring
        if (-not $defender.BehaviorMonitorEnabled) {
            Add-Finding -Severity "Medium" `
                -Title "Behavior monitoring disabled" `
                -Description "Behavioral analysis of programs is disabled" `
                -Remediation "Set-MpPreference -DisableBehaviorMonitoring $false"
        }
    }
    catch {
        Write-Output "[SKIP] Unable to check Windows Defender: $_"
    }
}

function Test-Firewall {
    <#
    .SYNOPSIS
    Check Windows Firewall configuration
    #>

    Write-Output "Checking Windows Firewall..."

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue

        if ($null -eq $profiles) {
            Add-Finding -Severity "High" `
                -Title "Unable to check firewall" `
                -Description "Windows Firewall service may not be running" `
                -Remediation "Start Windows Firewall service"
            return
        }

        foreach ($fwEntry in $profiles) {
            if (-not $fwEntry.Enabled) {
                Add-Finding -Severity "High" `
                    -Title "Firewall disabled: $($fwEntry.Name)" `
                    -Description "The $($fwEntry.Name) firewall profile is disabled" `
                    -Remediation "Set-NetFirewallProfile -Name '$($fwEntry.Name)' -Enabled True"
            } else {
                Write-CheckPass "$($fwEntry.Name) firewall profile enabled"
            }

            # Check default actions
            if ($fwEntry.DefaultInboundAction -eq "Allow") {
                Add-Finding -Severity "Medium" `
                    -Title "Default inbound: Allow ($($fwEntry.Name))" `
                    -Description "Default inbound action should be Block" `
                    -Remediation "Set-NetFirewallProfile -Name '$($fwEntry.Name)' -DefaultInboundAction Block"
            }
        }
    }
    catch {
        Write-Output "[SKIP] Unable to check firewall: $_"
    }
}

function Test-AdminAccounts {
    <#
    .SYNOPSIS
    Check local administrator accounts
    #>

    Write-Output "Checking local administrator accounts..."

    try {
        $admins = Get-LocalGroupMember -Group "Administrators" -ErrorAction SilentlyContinue

        if ($admins.Count -gt 3) {
            Add-Finding -Severity "Medium" `
                -Title "Multiple admin accounts: $($admins.Count)" `
                -Description "Found $($admins.Count) accounts in Administrators group" `
                -Remediation "Review and remove unnecessary admin accounts"
        } else {
            Write-CheckPass "Administrator account count acceptable ($($admins.Count))"
        }

        # Check for built-in Administrator enabled
        $builtin = Get-LocalUser -Name "Administrator" -ErrorAction SilentlyContinue
        if ($builtin -and $builtin.Enabled) {
            Add-Finding -Severity "Medium" `
                -Title "Built-in Administrator enabled" `
                -Description "The built-in Administrator account is active" `
                -Remediation "Disable-LocalUser -Name 'Administrator'"
        }

        # Check for guest account
        $guest = Get-LocalUser -Name "Guest" -ErrorAction SilentlyContinue
        if ($guest -and $guest.Enabled) {
            Add-Finding -Severity "High" `
                -Title "Guest account enabled" `
                -Description "The Guest account is active and accessible" `
                -Remediation "Disable-LocalUser -Name 'Guest'"
        } else {
            Write-CheckPass "Guest account is disabled"
        }
    }
    catch {
        Write-Output "[SKIP] Unable to check admin accounts: $_"
    }
}

function Test-OpenPorts {
    <#
    .SYNOPSIS
    Check for risky open ports
    #>

    Write-Output "Checking for risky open ports..."

    $riskyPorts = @(
        @{ Port = 21; Service = "FTP"; Severity = "High" }
        @{ Port = 23; Service = "Telnet"; Severity = "Critical" }
        @{ Port = 135; Service = "RPC"; Severity = "Medium" }
        @{ Port = 445; Service = "SMB"; Severity = "Medium" }
        @{ Port = 3389; Service = "RDP"; Severity = "Medium" }
        @{ Port = 5900; Service = "VNC"; Severity = "High" }
    )

    try {
        $listeners = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue

        foreach ($risky in $riskyPorts) {
            $found = $listeners | Where-Object { $_.LocalPort -eq $risky.Port }

            if ($found) {
                Add-Finding -Severity $risky.Severity `
                    -Title "Port $($risky.Port) ($($risky.Service)) is listening" `
                    -Description "Service $($risky.Service) is accepting connections" `
                    -Remediation "Disable if not required, or restrict with firewall rules"
            }
        }

        Write-CheckPass "Risky port scan complete"
    }
    catch {
        Write-Output "[SKIP] Unable to check ports: $_"
    }
}

function Test-SecurityUpdates {
    <#
    .SYNOPSIS
    Check for pending security updates
    #>

    Write-Output "Checking for pending security updates..."

    try {
        $updateSession = New-Object -ComObject Microsoft.Update.Session
        $updateSearcher = $updateSession.CreateUpdateSearcher()
        $pendingUpdates = $updateSearcher.Search("IsInstalled=0 and Type='Software'").Updates

        $securityUpdates = $pendingUpdates | Where-Object {
            $_.Categories | Where-Object { $_.Name -match "Security" }
        }

        if ($securityUpdates.Count -gt 0) {
            Add-Finding -Severity "High" `
                -Title "Pending security updates: $($securityUpdates.Count)" `
                -Description "There are $($securityUpdates.Count) security updates waiting to be installed" `
                -Remediation "Install pending Windows Updates"
        } else {
            Write-CheckPass "No pending security updates"
        }
    }
    catch {
        Write-Output "[SKIP] Unable to check updates: $_"
    }
}

# =============================================================================
# REPORT GENERATION
# =============================================================================

function Get-SecurityReport {
    $critical = ($script:Findings | Where-Object { $_.Severity -eq "Critical" }).Count
    $high = ($script:Findings | Where-Object { $_.Severity -eq "High" }).Count
    $medium = ($script:Findings | Where-Object { $_.Severity -eq "Medium" }).Count
    $low = ($script:Findings | Where-Object { $_.Severity -eq "Low" }).Count

    # Calculate risk score
    $riskScore = ($critical * 10) + ($high * 5) + ($medium * 2) + $low

    $riskLevel = switch ($true) {
        ($riskScore -ge 50) { "CRITICAL"; break }
        ($riskScore -ge 20) { "HIGH"; break }
        ($riskScore -ge 10) { "MEDIUM"; break }
        default { "LOW" }
    }

    Write-Output ""
    Write-Output "========================================"
    Write-Output " SECURITY ASSESSMENT REPORT"
    Write-Output "========================================"
    Write-Output " Date:     $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Output " Host:     $env:COMPUTERNAME"
    Write-Output " User:     $env:USERNAME"
    Write-Output "========================================"
    Write-Output ""
    Write-Output " FINDINGS SUMMARY:"
    Write-Output "   Critical: $critical"
    Write-Output "   High:     $high"
    Write-Output "   Medium:   $medium"
    Write-Output "   Low:      $low"
    Write-Output "   Total:    $($script:Findings.Count)"
    Write-Output ""
    Write-Output " RISK SCORE: $riskScore"
    Write-Output " RISK LEVEL: $riskLevel"
    Write-Output "========================================"

    return @{
        RiskScore = $riskScore
        RiskLevel = $riskLevel
        Findings = $script:Findings
        Summary = @{
            Critical = $critical
            High = $high
            Medium = $medium
            Low = $low
            Total = $script:Findings.Count
        }
    }
}

# =============================================================================
# MAIN
# =============================================================================

function Invoke-SecurityAssessment {
    Write-Output "========================================"
    Write-Output " $script:AssessmentName"
    Write-Output " $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Output "========================================"
    Write-Output ""

    # Run security checks
    Test-WindowsDefender
    Test-Firewall
    Test-AdminAccounts
    Test-OpenPorts
    Test-SecurityUpdates

    # Generate report
    $report = Get-SecurityReport

    # Exit code based on findings
    if ($report.Summary.Critical -gt 0 -or $report.Summary.High -gt 0) {
        exit 2
    }
    elseif ($report.Summary.Medium -gt 0) {
        exit 1
    }
    exit 0
}

# Execute
Invoke-SecurityAssessment
