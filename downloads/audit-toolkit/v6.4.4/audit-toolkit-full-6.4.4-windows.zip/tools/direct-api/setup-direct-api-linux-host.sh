#!/usr/bin/env bash
set -euo pipefail

API_KEY=""
SIGNING_KEY=""
PORT="8443"
INSTALL_DIR="/opt/audit-direct-api"
SERVICE_NAME="audit-direct-api"
CERT_DAYS="825"

usage() {
  cat <<'USAGE'
Usage:
  sudo bash setup-direct-api-linux-host.sh --api-key <key> [options]

Required:
  --api-key <key>

Options:
  --signing-key <key>       Request signing key (defaults to api key)
  --port <port>             HTTPS port (default: 8443)
  --install-dir <path>      Install directory (default: /opt/audit-direct-api)
  --service-name <name>     Service name (default: audit-direct-api)
  --cert-days <days>        Self-signed cert validity days (default: 825)
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --api-key)
      API_KEY="$2"
      shift 2
      ;;
    --signing-key)
      SIGNING_KEY="$2"
      shift 2
      ;;
    --port)
      PORT="$2"
      shift 2
      ;;
    --install-dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --service-name)
      SERVICE_NAME="$2"
      shift 2
      ;;
    --cert-days)
      CERT_DAYS="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ "${EUID}" -ne 0 ]]; then
  echo 'Run as root.' >&2
  exit 1
fi

if [[ -z "${API_KEY}" ]]; then
  echo "--api-key is required." >&2
  usage
  exit 1
fi

if [[ -z "${SIGNING_KEY}" ]]; then
  SIGNING_KEY="${API_KEY}"
fi

for cmd in python3 openssl systemctl; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing required command: $cmd" >&2
    exit 1
  fi
done

mkdir -p "${INSTALL_DIR}"

cat > "${INSTALL_DIR}/server.py" <<'PY'
#!/usr/bin/env python3
import hashlib
import hmac
import json
import os
import datetime
import platform
import socket
import subprocess
import time
import ssl
from http.server import HTTPServer, BaseHTTPRequestHandler

API_KEY = os.getenv('AUDIT_DISCOVERY_API_KEY', '').strip()
SIGNING_KEY = os.getenv('AUDIT_DISCOVERY_REQUEST_SIGNING_KEY', API_KEY).strip()
REQUIRE_API_KEY = os.getenv('AUDIT_DISCOVERY_REQUIRE_API_KEY', 'true').lower() in ('1', 'true', 'yes', 'on')
REQUIRE_SIG = os.getenv('AUDIT_DISCOVERY_REQUIRE_REQUEST_SIGNATURES', 'true').lower() in ('1', 'true', 'yes', 'on')
REQUIRE_NONCE = os.getenv('AUDIT_DISCOVERY_REQUIRE_NONCE', 'true').lower() in ('1', 'true', 'yes', 'on')
MAX_AGE = int(os.getenv('AUDIT_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS', '300'))
NONCE_CACHE = {}


def cmd_out(command, timeout=10):
    try:
        return subprocess.check_output(command, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=timeout).strip()
    except Exception:
        return ''


def cmd_lines(command, timeout=20):
    out = cmd_out(command, timeout=timeout)
    if not out:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()]


def has_cmd(name):
    return bool(cmd_out(f"command -v {name}"))


def os_info():
    name = 'Linux'
    version = 'Unknown'
    try:
        with open('/etc/os-release', 'r', encoding='utf-8') as f:
            data = {}
            for line in f:
                if '=' in line:
                    key, val = line.strip().split('=', 1)
                    data[key] = val.strip('"')
            name = data.get('NAME', name)
            version = data.get('VERSION_ID', data.get('VERSION', version))
    except Exception:
        pass
    return name, version


def collect_packages(limit=500):
    packages = []
    if has_cmd('dpkg-query'):
        lines = cmd_lines("dpkg-query -W -f='${Package}\t${Version}\n' | head -n 2500")
        for line in lines:
            parts = line.split('\t', 1)
            if parts and parts[0].strip():
                packages.append({'name': parts[0].strip(), 'version': parts[1].strip() if len(parts) > 1 else ''})
    elif has_cmd('rpm'):
        lines = cmd_lines("rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\n' | head -n 2500")
        for line in lines:
            parts = line.split('\t', 1)
            if parts and parts[0].strip():
                packages.append({'name': parts[0].strip(), 'version': parts[1].strip() if len(parts) > 1 else ''})
    elif has_cmd('apk'):
        lines = cmd_lines('apk info -v | head -n 2500')
        for line in lines:
            parts = line.rsplit('-', 2)
            name = parts[0].strip() if len(parts) >= 3 else line.strip()
            version = f"{parts[1]}-{parts[2]}" if len(parts) >= 3 else ''
            if name:
                packages.append({'name': name, 'version': version})
    elif has_cmd('pacman'):
        lines = cmd_lines('pacman -Q 2>/dev/null | head -n 2500')
        for line in lines:
            parts = line.split(None, 1)
            if parts and parts[0].strip():
                packages.append({'name': parts[0].strip(), 'version': parts[1].strip() if len(parts) > 1 else ''})
    return packages[:limit]


def collect_pending_updates(limit=300):
    updates = []
    if has_cmd('apt'):
        lines = cmd_lines("apt list --upgradable 2>/dev/null | sed -n '2,350p'")
        for line in lines:
            if '/' not in line:
                continue
            name = line.split('/', 1)[0].strip()
            tokens = line.split()
            available = tokens[1].strip() if len(tokens) > 1 else ''
            current = ''
            marker = '[upgradable from:'
            idx = line.find(marker)
            if idx >= 0:
                current = line[idx + len(marker):].split(']', 1)[0].strip()
            if name:
                updates.append({'name': name, 'current_version': current, 'available_version': available})
    elif has_cmd('dnf'):
        lines = cmd_lines('dnf -q check-update 2>/dev/null | head -n 700')
        for line in lines:
            if line.startswith('Last metadata expiration check') or line.startswith('Obsoleting Packages'):
                continue
            parts = line.split()
            if len(parts) >= 2:
                updates.append({'name': parts[0].strip(), 'current_version': '', 'available_version': parts[1].strip()})
    elif has_cmd('yum'):
        lines = cmd_lines('yum -q check-update 2>/dev/null | head -n 700')
        for line in lines:
            if line.startswith('Obsoleting Packages'):
                continue
            parts = line.split()
            if len(parts) >= 2:
                updates.append({'name': parts[0].strip(), 'current_version': '', 'available_version': parts[1].strip()})
    elif has_cmd('zypper'):
        lines = cmd_lines('zypper --non-interactive list-updates 2>/dev/null | head -n 700')
        for line in lines:
            if '|' not in line:
                continue
            cols = [c.strip() for c in line.split('|')]
            if len(cols) >= 8 and cols[3] and cols[6] and cols[3].lower() != 'name':
                updates.append({'name': cols[3], 'current_version': '', 'available_version': cols[6]})
    elif has_cmd('apk'):
        lines = cmd_lines("apk version -l '<' 2>/dev/null | head -n 350")
        for line in lines:
            name = line.split()[0].split('<', 1)[0].strip()
            if name:
                updates.append({'name': name, 'current_version': '', 'available_version': ''})
    elif has_cmd('pacman'):
        lines = cmd_lines('pacman -Qu 2>/dev/null | head -n 350')
        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                updates.append({'name': parts[0], 'current_version': parts[1], 'available_version': parts[3] if len(parts) > 3 else ''})
    return updates[:limit]


def collect_services(limit=300):
    services = []
    if has_cmd('systemctl'):
        lines = cmd_lines('systemctl list-units --type=service --all --no-legend --no-pager 2>/dev/null | head -n 900')
        for line in lines:
            parts = line.split(None, 4)
            if len(parts) >= 3:
                services.append({'name': parts[0], 'status': parts[2]})
    elif has_cmd('rc-service'):
        names = cmd_lines('rc-service -l 2>/dev/null')
        for name in names[:limit]:
            status_line = cmd_out(f'rc-service {name} status 2>/dev/null | head -n 1')
            status = 'running' if 'started' in status_line.lower() else 'stopped'
            services.append({'name': name, 'status': status})
    return services[:limit]


def collect_open_ports(limit=300):
    ports = []
    lines = cmd_lines('ss -tulnH 2>/dev/null | head -n 900')
    for line in lines:
        parts = line.split()
        if len(parts) < 5:
            continue
        protocol = parts[0]
        state = parts[1].lower()
        local = parts[4]
        port = ''
        if ':' in local:
            port = local.rsplit(':', 1)[-1].strip('[]')
        elif local.isdigit():
            port = local
        if port.isdigit():
            ports.append({'port': int(port), 'protocol': protocol, 'state': state})
    return ports[:limit]


def collect_users(limit=300):
    users = []
    try:
        with open('/etc/passwd', 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split(':')
                if len(parts) >= 7:
                    users.append({
                        'username': parts[0],
                        'uid': int(parts[2]) if parts[2].isdigit() else None,
                        'shell': parts[6],
                    })
    except Exception:
        return []
    return users[:limit]


def collect_storage(limit=200):
    storage = []
    lines = cmd_lines('df -PT -B1 2>/dev/null | tail -n +2')
    skip_fs = {'tmpfs', 'devtmpfs', 'squashfs', 'overlay'}
    for line in lines:
        parts = line.split()
        if len(parts) < 7:
            continue
        fs_type = (parts[1] or '').strip().lower()
        if fs_type in skip_fs:
            continue
        try:
            total_bytes = int(parts[2])
            free_bytes = int(parts[4])
        except Exception:
            continue
        mount = parts[6].strip()
        used_pct = 0.0
        if total_bytes > 0:
            used_pct = round(((total_bytes - free_bytes) / total_bytes) * 100, 2)
        storage.append({
            'drive_letter': mount,
            'mount_point': mount,
            'filesystem_type': parts[1].strip(),
            'total_size_gb': round(total_bytes / (1024 ** 3), 2),
            'free_space_gb': round(free_bytes / (1024 ** 3), 2),
            'used_percent': used_pct,
            'is_system_drive': mount == '/',
        })
    return storage[:limit]


def collect_system_info(hostname, os_name, os_version, kernel_version, architecture):
    fqdn = cmd_out('hostname -f') or hostname
    domain = ''
    if fqdn and '.' in fqdn:
        domain = fqdn.split('.', 1)[1]

    manufacturer = cmd_out('cat /sys/class/dmi/id/sys_vendor 2>/dev/null')
    model = cmd_out('cat /sys/class/dmi/id/product_name 2>/dev/null')
    serial_number = cmd_out('cat /sys/class/dmi/id/product_serial 2>/dev/null')
    product_uuid = cmd_out('cat /sys/class/dmi/id/product_uuid 2>/dev/null')

    cpu_name = cmd_out("awk -F': ' '/model name/{print $2; exit}' /proc/cpuinfo 2>/dev/null")

    logical_cpu_count = None
    try:
        logical_cpu_count = os.cpu_count()
    except Exception:
        logical_cpu_count = None

    physical_cores = cmd_out('nproc --all 2>/dev/null')
    cpu_cores = int(physical_cores) if physical_cores.isdigit() else logical_cpu_count

    mem_kb = cmd_out("awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null")
    total_memory_gb = None
    try:
        if mem_kb:
            total_memory_gb = round(int(mem_kb) / (1024 * 1024), 2)
    except Exception:
        total_memory_gb = None

    virt_type = cmd_out('systemd-detect-virt 2>/dev/null') if has_cmd('systemd-detect-virt') else ''
    is_virtual = bool(virt_type and virt_type not in ('none', ''))
    hypervisor = virt_type if is_virtual else None

    last_boot = None
    boot_str = cmd_out('uptime -s 2>/dev/null')
    if boot_str:
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):
            try:
                dt = datetime.datetime.strptime(boot_str, fmt)
                last_boot = dt.replace(tzinfo=datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
                break
            except Exception:
                continue
        if not last_boot:
            last_boot = boot_str

    return {
        'hostname': hostname,
        'fqdn': fqdn or None,
        'domain': domain or None,
        'os_name': os_name,
        'os_version': os_version,
        'os_build': kernel_version,
        'kernel_version': kernel_version,
        'architecture': architecture,
        'manufacturer': manufacturer or None,
        'model': model or None,
        'serial_number': serial_number or None,
        'product_id': None,
        'asset_tag': None,
        'product_uuid': product_uuid or None,
        'cpu_name': cpu_name or None,
        'cpu_cores': cpu_cores,
        'cpu_logical_processors': logical_cpu_count,
        'total_memory_gb': total_memory_gb,
        'is_virtual': is_virtual,
        'hypervisor': hypervisor,
        'last_boot': last_boot,
    }


def ssh_config_value(option):
    if has_cmd('sshd'):
        value = cmd_out(f"sshd -T 2>/dev/null | awk '/^{option} /{{print $2; exit}}'")
        if value:
            return value.lower()
    lines = cmd_lines("grep -RhiE '^[[:space:]]*" + option + "[[:space:]]+' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null | tail -n 1")
    if lines:
        parts = lines[-1].split()
        if len(parts) >= 2:
            return parts[1].strip().lower()
    return ''


def detect_firewall_enabled():
    if has_cmd('ufw'):
        status = cmd_out('ufw status 2>/dev/null | head -n 1').lower()
        if 'active' in status:
            return True
        if status:
            return False
    if has_cmd('systemctl'):
        for service in ('firewalld', 'nftables', 'ufw'):
            if cmd_out(f'systemctl is-active {service} 2>/dev/null') == 'active':
                return True
    return None


def detect_auto_updates_enabled():
    if has_cmd('systemctl'):
        for unit in ('apt-daily.timer', 'apt-daily-upgrade.timer', 'dnf-automatic.timer', 'yum-cron.service'):
            if cmd_out(f'systemctl is-enabled {unit} 2>/dev/null') in ('enabled', 'static'):
                return True
    if has_cmd('rc-update') and cmd_out('rc-update show 2>/dev/null | grep -E "(crond|anacron)"'):
        return True
    return False


def detect_time_sync_enabled():
    if has_cmd('timedatectl'):
        synced = cmd_out('timedatectl show -p NTPSynchronized --value 2>/dev/null').lower()
        if synced in ('yes', '1', 'true'):
            return True
    if has_cmd('systemctl'):
        for svc in ('chronyd', 'systemd-timesyncd', 'ntpd'):
            if cmd_out(f'systemctl is-active {svc} 2>/dev/null') == 'active':
                return True
    if has_cmd('rc-service') and cmd_out('rc-service chronyd status 2>/dev/null | grep -qi started && echo yes') == 'yes':
        return True
    return False


def detect_mac_enforcement_enabled():
    if has_cmd('getenforce'):
        return cmd_out('getenforce 2>/dev/null').strip().lower() == 'enforcing'
    if has_cmd('aa-status'):
        result = cmd_out('aa-status --enabled 2>/dev/null; echo $?')
        return result.splitlines()[-1].strip() == '0' if result else False
    return False


def collect_security_info():
    permit_root = ssh_config_value('permitrootlogin')
    password_auth = ssh_config_value('passwordauthentication')
    return {
        'hardening': {
            'firewall_enabled': detect_firewall_enabled(),
            'ssh_root_login_disabled': permit_root in ('no', 'prohibit-password', 'forced-commands-only'),
            'ssh_password_auth_disabled': password_auth == 'no',
            'auto_updates_enabled': detect_auto_updates_enabled(),
            'time_sync_enabled': detect_time_sync_enabled(),
            'mac_enforcement_enabled': detect_mac_enforcement_enabled(),
        }
    }


class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _validate(self):
        now = int(time.time())
        for key, expiry in list(NONCE_CACHE.items()):
            if expiry < now:
                NONCE_CACHE.pop(key, None)

        if REQUIRE_API_KEY:
            provided = (self.headers.get('X-API-Key') or '').strip()
            if not API_KEY or not provided or not hmac.compare_digest(provided, API_KEY):
                return False, 'Invalid API key'

        if not REQUIRE_SIG:
            return True, ''

        ts = (self.headers.get('X-Agent-Timestamp') or '').strip()
        nonce = (self.headers.get('X-Agent-Nonce') or '').strip()
        content_sha = (self.headers.get('X-Agent-Content-SHA256') or '').strip().lower()
        signature = (self.headers.get('X-Agent-Signature') or '').strip()

        if not ts or not content_sha or not signature:
            return False, 'Missing request signature headers'
        if REQUIRE_NONCE and not nonce:
            return False, 'Missing X-Agent-Nonce header'

        try:
            ts_i = int(ts)
        except Exception:
            return False, 'Invalid X-Agent-Timestamp header'

        if abs(now - ts_i) > MAX_AGE:
            return False, 'Request signature timestamp expired'

        expected_hash = hashlib.sha256(b'').hexdigest()
        if not hmac.compare_digest(content_sha, expected_hash):
            return False, 'Invalid request content hash'

        if nonce:
            cache_key = f"{ts}:{nonce}"
            if cache_key in NONCE_CACHE:
                return False, 'Replay detected'
            NONCE_CACHE[cache_key] = now + MAX_AGE

        message = '\n'.join([ts, self.command.upper(), self.path, content_sha, nonce]).encode('utf-8')
        expected_sig = hmac.new((SIGNING_KEY or API_KEY).encode('utf-8'), message, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected_sig):
            return False, 'Invalid request signature'

        return True, ''

    def do_GET(self):
        if self.path == '/health':
            self._json(200, {'status': 'ok', 'service': 'direct-api-endpoint'})
            return

        if self.path == '/api/system-info':
            valid, error = self._validate()
            if not valid:
                self._json(401, {'error': error})
                return

            hostname = cmd_out('hostname') or 'unknown'
            os_name, os_version = os_info()
            kernel_version = cmd_out('uname -r')
            architecture = cmd_out('uname -m')
            system_info = collect_system_info(hostname, os_name, os_version, kernel_version, architecture)
            packages = collect_packages()
            services = collect_services()
            storage = collect_storage()
            open_ports = collect_open_ports()
            users = collect_users()
            pending_updates = collect_pending_updates()
            security_info = collect_security_info()

            self._json(200, {
                'hostname': hostname,
                'os_type': 'linux',
                'fqdn': system_info.get('fqdn'),
                'domain': system_info.get('domain'),
                'os_name': os_name,
                'os_version': os_version,
                'os_build': system_info.get('os_build'),
                'kernel_version': kernel_version,
                'architecture': architecture,
                'manufacturer': system_info.get('manufacturer'),
                'model': system_info.get('model'),
                'serial_number': system_info.get('serial_number'),
                'product_id': system_info.get('product_id'),
                'asset_tag': system_info.get('asset_tag'),
                'product_uuid': system_info.get('product_uuid'),
                'cpu_name': system_info.get('cpu_name'),
                'cpu_cores': system_info.get('cpu_cores'),
                'cpu_logical_processors': system_info.get('cpu_logical_processors'),
                'total_memory_gb': system_info.get('total_memory_gb'),
                'is_virtual': system_info.get('is_virtual'),
                'hypervisor': system_info.get('hypervisor'),
                'last_boot': system_info.get('last_boot'),
                'packages': packages,
                'services': services,
                'storage': storage,
                'open_ports': open_ports,
                'users': users,
                'updates_available': len(pending_updates),
                'pending_updates': pending_updates,
                'security_info': security_info,
                'system': system_info,
            })
            return

        self._json(404, {'error': 'not found'})


if __name__ == '__main__':
    cert = os.getenv('AUDIT_DISCOVERY_TLS_CERT_FILE', '/opt/audit-direct-api/cert.pem')
    key = os.getenv('AUDIT_DISCOVERY_TLS_KEY_FILE', '/opt/audit-direct-api/key.pem')
    port = int(os.getenv('AUDIT_DISCOVERY_BIND_PORT', '8443'))

    server = HTTPServer(('0.0.0.0', port), Handler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=cert, keyfile=key)
    server.socket = context.wrap_socket(server.socket, server_side=True)
    server.serve_forever()
PY

chmod 750 "${INSTALL_DIR}/server.py"

cat > "${INSTALL_DIR}/direct-api.env" <<ENV
AUDIT_DISCOVERY_REQUIRE_API_KEY=true
AUDIT_DISCOVERY_REQUIRE_REQUEST_SIGNATURES=true
AUDIT_DISCOVERY_REQUIRE_NONCE=true
AUDIT_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS=300
AUDIT_DISCOVERY_API_KEY=${API_KEY}
AUDIT_DISCOVERY_REQUEST_SIGNING_KEY=${SIGNING_KEY}
AUDIT_DISCOVERY_BIND_PORT=${PORT}
AUDIT_DISCOVERY_TLS_CERT_FILE=${INSTALL_DIR}/cert.pem
AUDIT_DISCOVERY_TLS_KEY_FILE=${INSTALL_DIR}/key.pem
ENV

chmod 600 "${INSTALL_DIR}/direct-api.env"

if [[ ! -f "${INSTALL_DIR}/cert.pem" || ! -f "${INSTALL_DIR}/key.pem" ]]; then
  openssl req -x509 -newkey rsa:2048 -sha256 -days "${CERT_DAYS}" -nodes \
    -keyout "${INSTALL_DIR}/key.pem" \
    -out "${INSTALL_DIR}/cert.pem" \
    -subj "/CN=$(hostname -f 2>/dev/null || hostname)" >/dev/null 2>&1
  chmod 600 "${INSTALL_DIR}/key.pem"
  chmod 644 "${INSTALL_DIR}/cert.pem"
fi

cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<UNIT
[Unit]
Description=Audit Toolkit Direct API Endpoint
After=network.target

[Service]
Type=simple
EnvironmentFile=${INSTALL_DIR}/direct-api.env
ExecStart=/usr/bin/python3 ${INSTALL_DIR}/server.py
Restart=always
RestartSec=2
User=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "${SERVICE_NAME}.service"
systemctl restart "${SERVICE_NAME}.service"

if command -v ufw >/dev/null 2>&1; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
fi
if command -v firewall-cmd >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port="${PORT}/tcp" >/dev/null 2>&1 || true
  firewall-cmd --reload >/dev/null 2>&1 || true
fi

echo "Installed ${SERVICE_NAME} on port ${PORT}"
echo "Health: curl -k https://$(hostname -f 2>/dev/null || hostname):${PORT}/health"
