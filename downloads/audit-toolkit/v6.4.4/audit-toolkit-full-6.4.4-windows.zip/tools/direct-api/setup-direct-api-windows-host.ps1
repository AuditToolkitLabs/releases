param(
    [Parameter(Mandatory = $true)]
    [string]$ApiKey,
    [string]$SigningKey,
    [int]$Port = 8443,
    [string]$InstallPath = 'C:\ProgramData\AuditDirectApi',
    [string]$ServiceName = 'AuditDirectApi',
    [string]$CertThumbprint,
    [switch]$ForceRecreateCert
)

$ErrorActionPreference = 'Stop'

if (-not $SigningKey) {
    $SigningKey = $ApiKey
}

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script in an elevated PowerShell session.'
}

if (-not (Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
}

$configPath = Join-Path $InstallPath 'config.json'
$endpointPath = Join-Path $InstallPath 'direct-api-endpoint.ps1'

if ($ForceRecreateCert -and $CertThumbprint) {
    Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $CertThumbprint } | Remove-Item -Force -ErrorAction SilentlyContinue
    $CertThumbprint = $null
}

if (-not $CertThumbprint) {
    $dnsNames = @($env:COMPUTERNAME, 'localhost') | Where-Object { $_ -and $_.Trim() }
    $newCert = New-SelfSignedCertificate -DnsName $dnsNames -CertStoreLocation 'Cert:\LocalMachine\My' -NotAfter (Get-Date).AddYears(2)
    $CertThumbprint = $newCert.Thumbprint
}

if (-not (Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Thumbprint -eq $CertThumbprint })) {
    throw "Certificate thumbprint not found in LocalMachine\\My: $CertThumbprint"
}

$config = [ordered]@{
    require_api_key = $true
    require_request_signatures = $true
    require_nonce = $true
    max_age_seconds = 300
    api_key = $ApiKey
    signing_key = $SigningKey
    bind_port = $Port
}
$config | ConvertTo-Json -Depth 5 | Set-Content -Path $configPath -Encoding UTF8

$endpointScript = @'
$ErrorActionPreference = 'Stop'

$configPath = Join-Path $PSScriptRoot 'config.json'
if (-not (Test-Path $configPath)) {
    throw "Missing config file: $configPath"
}
$config = Get-Content -Raw -Path $configPath | ConvertFrom-Json

$nonceCache = @{}

function Get-Sha256Hex([byte[]]$Bytes) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLower()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-HmacHex([string]$Key, [string]$Message) {
    $hmac = [System.Security.Cryptography.HMACSHA256]::new([Text.Encoding]::UTF8.GetBytes($Key))
    try {
        return ([BitConverter]::ToString($hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($Message)))).Replace('-', '').ToLower()
    }
    finally {
        $hmac.Dispose()
    }
}

function Resolve-StringBool([object]$Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [bool]) { return $Value }
    $s = [string]$Value
    switch ($s.Trim().ToLower()) {
        '1' { return $true }
        'true' { return $true }
        'yes' { return $true }
        'on' { return $true }
        'enabled' { return $true }
        '0' { return $false }
        'false' { return $false }
        'no' { return $false }
        'off' { return $false }
        'disabled' { return $false }
        default { return $null }
    }
}

function Collect-Packages {
    $items = @()
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($path in $paths) {
        $items += Get-ItemProperty -Path $path -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -and $_.SystemComponent -ne 1 -and $_.ReleaseType -ne 'Update' } |
            Select-Object @{N='name';E={$_.DisplayName}}, @{N='version';E={$_.DisplayVersion}}, @{N='publisher';E={$_.Publisher}}
    }

    try {
        $items += Get-Package -ErrorAction SilentlyContinue |
            Where-Object { $_.Name } |
            Select-Object @{N='name';E={$_.Name}}, @{N='version';E={[string]$_.Version}}, @{N='publisher';E={$_.ProviderName}}
    }
    catch {
        # ignore package provider errors
    }

    return @($items | Sort-Object name -Unique | Select-Object -First 1000)
}

function Collect-Storage {
    try {
        $drives = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction Stop
        $results = @()
        foreach ($drive in $drives) {
            $total = [double]$drive.Size
            $free = [double]$drive.FreeSpace
            $totalGb = if ($total -gt 0) { [math]::Round($total / 1GB, 2) } else { 0 }
            $freeGb = if ($free -ge 0) { [math]::Round($free / 1GB, 2) } else { 0 }
            $usedPct = if ($total -gt 0) { [math]::Round((($total - $free) / $total) * 100, 2) } else { 0 }

            $results += [pscustomobject]@{
                drive_letter = [string]$drive.DeviceID
                mount_point = [string]$drive.DeviceID
                file_system = [string]$drive.FileSystem
                filesystem_type = [string]$drive.FileSystem
                total_size_gb = $totalGb
                free_space_gb = $freeGb
                used_percent = $usedPct
                is_system_drive = ([string]$drive.DeviceID -eq 'C:')
            }
        }
        return @($results | Select-Object -First 128)
    }
    catch {
        return @()
    }
}

function Collect-Services {
    return @(Get-Service | Select-Object -First 1000 @{N='name';E={$_.Name}}, @{N='status';E={$_.Status.ToString().ToLower()}})
}

function Collect-Ports {
    $ports = @()
    try {
        $ports = Get-NetTCPConnection -State Listen -ErrorAction Stop | Select-Object -First 1000 @{N='port';E={$_.LocalPort}}, @{N='protocol';E={'tcp'}}, @{N='state';E={'listen'}}
    }
    catch {
        $ports = @()
    }
    return @($ports)
}

function Collect-Users {
    try {
        return @(Get-LocalUser | Select-Object -First 500 @{N='username';E={$_.Name}}, @{N='enabled';E={$_.Enabled}}, @{N='sid';E={$_.SID.Value}})
    }
    catch {
        return @()
    }
}

function Collect-PendingUpdates {
    $results = @()
    try {
        $session = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $found = $searcher.Search("IsInstalled=0 and Type='Software'")
        for ($i = 0; $i -lt $found.Updates.Count; $i++) {
            $u = $found.Updates.Item($i)
            $results += [pscustomobject]@{
                name = $u.Title
                current_version = $null
                available_version = $null
                kb = @($u.KBArticleIDs) -join ','
                update_id = $u.Identity.UpdateID
                revision_number = $u.Identity.RevisionNumber
            }
        }
    }
    catch {
        $results = @()
    }
    return @($results)
}

function Collect-SecurityInfo {
    $profiles = Get-NetFirewallProfile -ErrorAction SilentlyContinue
    $firewallEnabled = $null
    if ($profiles) {
        $firewallEnabled = @($profiles | Where-Object { $_.Enabled -eq $true }).Count -gt 0
    }

    $rdpNla = $null
    try {
        $nla = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name UserAuthentication -ErrorAction Stop
        $rdpNla = ($nla.UserAuthentication -eq 1)
    }
    catch {
        $rdpNla = $null
    }

    $bitlockerEnabled = $null
    try {
        $vols = Get-BitLockerVolume -ErrorAction Stop
        $bitlockerEnabled = @($vols | Where-Object { $_.ProtectionStatus -eq 'On' }).Count -gt 0
    }
    catch {
        $bitlockerEnabled = $null
    }

    return [ordered]@{
        hardening = [ordered]@{
            firewall_enabled = $firewallEnabled
            rdp_nla_enabled = $rdpNla
            bitlocker_enabled = $bitlockerEnabled
        }
    }
}

function Collect-SystemInfo {
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $cpu = @(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue)
        $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
        $product = Get-CimInstance Win32_ComputerSystemProduct -ErrorAction SilentlyContinue

        $fqdn = $null
        try {
            $fqdn = ([System.Net.Dns]::GetHostEntry($env:COMPUTERNAME)).HostName
        }
        catch {
            $fqdn = $null
        }

        $cpuName = $null
        if ($cpu.Count -gt 0) {
            $cpuName = $cpu[0].Name
        }

        $cpuCores = ($cpu | Measure-Object -Property NumberOfCores -Sum).Sum
        $cpuLogical = ($cpu | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum

        $manufacturer = [string]$cs.Manufacturer
        $model = [string]$cs.Model
        $virtualHints = @('vmware', 'virtual', 'kvm', 'hyper-v', 'xen', 'qemu', 'virtualbox')
        $virtualFingerprint = "$manufacturer $model".ToLower()
        $isVirtual = $false
        foreach ($hint in $virtualHints) {
            if ($virtualFingerprint.Contains($hint)) {
                $isVirtual = $true
                break
            }
        }

        $lastBootIso = $null
        if ($os.LastBootUpTime) {
            if ($os.LastBootUpTime -is [datetime]) {
                $lastBootIso = ([datetime]$os.LastBootUpTime).ToUniversalTime().ToString('o')
            }
            else {
                try {
                    $lastBootIso = ([Management.ManagementDateTimeConverter]::ToDateTime([string]$os.LastBootUpTime)).ToUniversalTime().ToString('o')
                }
                catch {
                    $lastBootIso = [string]$os.LastBootUpTime
                }
            }
        }

        return [ordered]@{
            hostname = $env:COMPUTERNAME
            fqdn = $fqdn
            domain = if ($cs.PartOfDomain) { [string]$cs.Domain } else { $null }
            os_name = [string]$os.Caption
            os_version = [string]$os.Version
            os_build = [string]$os.BuildNumber
            kernel_version = [string]$os.BuildNumber
            architecture = [string]$os.OSArchitecture
            manufacturer = if ($manufacturer) { $manufacturer } else { $null }
            model = if ($model) { $model } else { $null }
            serial_number = if ($bios -and $bios.SerialNumber) { [string]$bios.SerialNumber } else { $null }
            product_id = if ($os -and $os.SerialNumber) { [string]$os.SerialNumber } else { $null }
            asset_tag = if ($bios -and $bios.SMBIOSAssetTag) { [string]$bios.SMBIOSAssetTag } else { $null }
            product_uuid = if ($product -and $product.UUID) { [string]$product.UUID } else { $null }
            cpu_name = if ($cpuName) { [string]$cpuName } else { $null }
            cpu_cores = if ($cpuCores) { [int]$cpuCores } else { $null }
            cpu_logical_processors = if ($cpuLogical) { [int]$cpuLogical } else { $null }
            total_memory_gb = if ($cs.TotalPhysicalMemory) { [math]::Round(([double]$cs.TotalPhysicalMemory / 1GB), 2) } else { $null }
            is_virtual = $isVirtual
            hypervisor = if ($isVirtual) { 'virtual' } else { $null }
            last_boot = $lastBootIso
        }
    }
    catch {
        return [ordered]@{
            hostname = $env:COMPUTERNAME
        }
    }
}

function Send-Json([System.Net.HttpListenerResponse]$Response, [int]$StatusCode, [object]$Body) {
    $json = $Body | ConvertTo-Json -Depth 10 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Response.StatusCode = $StatusCode
    $Response.ContentType = 'application/json'
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.OutputStream.Close()
}

function Validate-Request([System.Net.HttpListenerRequest]$Request) {
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

    foreach ($key in @($nonceCache.Keys)) {
        if ($nonceCache[$key] -lt $now) {
            $nonceCache.Remove($key) | Out-Null
        }
    }

    if ($config.require_api_key) {
        $provided = [string]$Request.Headers['X-API-Key']
        if ([string]::IsNullOrWhiteSpace($provided) -or $provided -ne [string]$config.api_key) {
            return @{ ok = $false; error = 'Invalid API key' }
        }
    }

    if (-not $config.require_request_signatures) {
        return @{ ok = $true }
    }

    $ts = [string]$Request.Headers['X-Agent-Timestamp']
    $nonce = [string]$Request.Headers['X-Agent-Nonce']
    $contentSha = ([string]$Request.Headers['X-Agent-Content-SHA256']).ToLower()
    $signature = ([string]$Request.Headers['X-Agent-Signature']).ToLower()

    if ([string]::IsNullOrWhiteSpace($ts) -or [string]::IsNullOrWhiteSpace($contentSha) -or [string]::IsNullOrWhiteSpace($signature)) {
        return @{ ok = $false; error = 'Missing request signature headers' }
    }
    if ($config.require_nonce -and [string]::IsNullOrWhiteSpace($nonce)) {
        return @{ ok = $false; error = 'Missing X-Agent-Nonce header' }
    }

    $tsInt = 0L
    if (-not [Int64]::TryParse($ts, [ref]$tsInt)) {
        return @{ ok = $false; error = 'Invalid X-Agent-Timestamp header' }
    }

    if ([Math]::Abs($now - $tsInt) -gt [int]$config.max_age_seconds) {
        return @{ ok = $false; error = 'Request signature timestamp expired' }
    }

    $expectedHash = Get-Sha256Hex ([byte[]]@())
    if ($contentSha -ne $expectedHash) {
        return @{ ok = $false; error = 'Invalid request content hash' }
    }

    if (-not [string]::IsNullOrWhiteSpace($nonce)) {
        $cacheKey = "$ts`:$nonce"
        if ($nonceCache.ContainsKey($cacheKey)) {
            return @{ ok = $false; error = 'Replay detected' }
        }
        $nonceCache[$cacheKey] = $now + [int]$config.max_age_seconds
    }

    $path = $Request.Url.AbsolutePath
    $method = $Request.HttpMethod.ToUpperInvariant()
    $msg = "$ts`n$method`n$path`n$contentSha`n$nonce"
    $expectedSig = Get-HmacHex -Key ([string]$config.signing_key) -Message $msg
    if ($signature -ne $expectedSig) {
        return @{ ok = $false; error = 'Invalid request signature' }
    }

    return @{ ok = $true }
}

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("https://+:$($config.bind_port)/")
$listener.Start()

while ($true) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $res = $ctx.Response

    try {
        $path = $req.Url.AbsolutePath
        if ($path -eq '/health') {
            Send-Json -Response $res -StatusCode 200 -Body @{ status = 'ok'; service = 'direct-api-endpoint' }
            continue
        }

        if ($path -eq '/api/system-info') {
            $validation = Validate-Request -Request $req
            if (-not $validation.ok) {
                Send-Json -Response $res -StatusCode 401 -Body @{ error = $validation.error }
                continue
            }

            $packages = Collect-Packages
            $services = Collect-Services
            $storage = Collect-Storage
            $ports = Collect-Ports
            $users = Collect-Users
            $pending = Collect-PendingUpdates
            $securityInfo = Collect-SecurityInfo
            $systemInfo = Collect-SystemInfo

            $payload = [ordered]@{
                hostname = if ($systemInfo.hostname) { $systemInfo.hostname } else { $env:COMPUTERNAME }
                os_type = 'windows'
                fqdn = $systemInfo.fqdn
                domain = $systemInfo.domain
                os_name = $systemInfo.os_name
                os_version = $systemInfo.os_version
                os_build = $systemInfo.os_build
                kernel_version = $systemInfo.kernel_version
                architecture = $systemInfo.architecture
                manufacturer = $systemInfo.manufacturer
                model = $systemInfo.model
                serial_number = $systemInfo.serial_number
                product_id = $systemInfo.product_id
                asset_tag = $systemInfo.asset_tag
                product_uuid = $systemInfo.product_uuid
                cpu_name = $systemInfo.cpu_name
                cpu_cores = $systemInfo.cpu_cores
                cpu_logical_processors = $systemInfo.cpu_logical_processors
                total_memory_gb = $systemInfo.total_memory_gb
                is_virtual = $systemInfo.is_virtual
                hypervisor = $systemInfo.hypervisor
                last_boot = $systemInfo.last_boot
                packages = $packages
                services = $services
                storage = $storage
                open_ports = $ports
                users = $users
                updates_available = @($pending).Count
                pending_updates = $pending
                security_info = $securityInfo
                system = $systemInfo
            }

            Send-Json -Response $res -StatusCode 200 -Body $payload
            continue
        }

        Send-Json -Response $res -StatusCode 404 -Body @{ error = 'not found' }
    }
    catch {
        Send-Json -Response $res -StatusCode 500 -Body @{ error = $_.Exception.Message }
    }
}
'@

Set-Content -Path $endpointPath -Value $endpointScript -Encoding UTF8

$existingBinding = netsh http show sslcert ipport=0.0.0.0:$Port 2>$null
if ($LASTEXITCODE -eq 0 -and $existingBinding) {
    netsh http delete sslcert ipport=0.0.0.0:$Port | Out-Null
}

$appId = '{3F2504E0-4F89-41D3-9A0C-0305E82C3301}'
netsh http add sslcert ipport=0.0.0.0:$Port certhash=$CertThumbprint appid=$appId certstorename=MY | Out-Null

$taskName = "$ServiceName-Task"

if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName | Out-Null
}

$existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}

$action = New-ScheduledTaskAction -Execute "$PSHOME\powershell.exe" -Argument "-NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$endpointPath`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$principalTask = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principalTask -Description 'Audit Toolkit Direct API Endpoint' | Out-Null
Start-ScheduledTask -TaskName $taskName

if (-not (Get-NetFirewallRule -DisplayName "Audit Direct API $Port" -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName "Audit Direct API $Port" -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port | Out-Null
}

Write-Output "Installed $taskName on port $Port"
Write-Output "Certificate thumbprint: $CertThumbprint"
Write-Output "Health: https://$env:COMPUTERNAME`:$Port/health"
