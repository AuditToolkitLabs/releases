# Download Evaluation ISOs for Hyper-V Lab
# This script downloads evaluation ISOs for Windows Server and Ubuntu.
# Windows 11 and Server 2025 require manual download due to Microsoft restrictions.

$DownloadDir = "$HOME\Downloads\VM-ISOs"
New-Item -ItemType Directory -Path $DownloadDir -Force | Out-Null

# Ubuntu 24.04 LTS
$ubuntuUrl = "https://releases.ubuntu.com/24.04/ubuntu-24.04-desktop-amd64.iso"
Invoke-WebRequest -Uri $ubuntuUrl -OutFile "$DownloadDir\ubuntu-24.04-desktop-amd64.iso"

# Windows Server 2019 Evaluation
$ws2019Url = "https://software-download.microsoft.com/download/pr/17763.1.180914-1434.rs5_release_SERVER_EVAL_x64FRE_en-us.iso"
Invoke-WebRequest -Uri $ws2019Url -OutFile "$DownloadDir\Windows_Server_2019_EVAL.iso"

# Windows Server 2022 Evaluation
$ws2022Url = "https://software-download.microsoft.com/download/pr/20348.1.210507-1500.fe_release_SERVER_EVAL_x64FRE_en-us.iso"
Invoke-WebRequest -Uri $ws2022Url -OutFile "$DownloadDir\Windows_Server_2022_EVAL.iso"

# Windows 11 Evaluation (manual)
$win11Url = "https://aka.ms/win11isodownload"
Write-Output "Please download Windows 11 ISO manually from: $win11Url"

# Windows Server 2025 Evaluation (manual)
$ws2025Url = "https://www.microsoft.com/en-us/evalcenter/download-windows-server-2025"
Write-Output "Please download Windows Server 2025 ISO manually from: $ws2025Url"

Write-Output "Download complete. Check $DownloadDir for ISOs."
