[CmdletBinding()]
param(
    [string]$TargetFile = (Join-Path $PSScriptRoot "..\lib\common.sh")
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $TargetFile)) {
    throw "Target file not found: $TargetFile"
}

$rawContent = Get-Content -LiteralPath $TargetFile -Raw -Encoding UTF8

# Normalize non-ASCII glyphs that can be mangled in mixed-encoding environments.
$normalized = $rawContent -replace '[^\x00-\x7F]', ''

Set-Content -LiteralPath $TargetFile -Value $normalized -Encoding UTF8 -NoNewline
Write-Output "Normalized non-ASCII glyphs in $TargetFile"
