#!/usr/bin/env python3
"""Fix corrupted Unicode characters in lib/common.sh"""
import os

script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, '..', 'lib', 'common.sh')

with open(file_path, 'rb') as f:
    content = f.read()

# These are mojibake sequences - UTF-8 interpreted as Windows-1252
# Using bytes to avoid any encoding issues
replacements = [
    (b'\xc3\x83\xc2\xa2\xc3\x85\xe2\x80\x9c\xc3\xa2\xe2\x82\xac', b'[+]'),  # checkmark
    (b'\xc3\x83\xc2\xa2\xc3\x85\xe2\x80\x9c\xc3\x8b\xc5\x93', b'[X]'),      # X mark
    (b'\xc3\x83\xc2\xa2\xc3\x85\xc2\xa1\xc3\x82\xc2\xa0', b'[!]'),           # warning
    (b'\xc3\x83\xc2\xa2\xe2\x82\xac\xe2\x80\x9c\xc3\x85\xe2\x80\x99', b'[-]'), # skip
]

for old, new in replacements:
    content = content.replace(old, new)

with open(file_path, 'wb') as f:
    f.write(content)

print(f"Fixed encoding in {file_path}")
