#!/usr/bin/env bash
# Fix lib path issues in Linux audit scripts
# Depth-4 scripts need ../../lib/ → ../../../lib/
# Depth-5 scripts need ../../../lib/ → ../../../../lib/

set -euo pipefail

cd "$(dirname "$0")/.."

echo "=== Fixing Linux Audit Script Lib Paths ==="
echo ""

# Count before
depth4_wrong=$(grep -rl '/\.\./\.\./lib/' audits/linux/*/*.sh 2>/dev/null | wc -l || echo 0)
depth5_wrong=$(grep -rl '/\.\./\.\./\.\./lib/' audits/linux/*/*/*.sh 2>/dev/null | grep -v '/\.\./\.\./\.\./\.\./lib/' | wc -l || echo 0)

echo "Before fix:"
echo "  Depth-4 scripts with ../../lib/: $depth4_wrong"
echo "  Depth-5 scripts with ../../../lib/ (not ../../../../): $depth5_wrong"
echo ""

# Fix depth-4 scripts (audits/linux/*/*.sh)
# These are at 4 levels deep, need 3 levels up to reach lib/
echo "Fixing depth-4 scripts (../../lib/ → ../../../lib/)..."
for f in audits/linux/*/*.sh; do
    if [[ -f "$f" ]] && grep -q '/\.\./\.\./lib/' "$f" 2>/dev/null; then
        # Make sure we don't have already correct paths
        if ! grep -q '/\.\./\.\./\.\./lib/' "$f" 2>/dev/null; then
            echo "  Fixing: $f"
            sed -i 's|/\.\./\.\./lib/|/../../../lib/|g' "$f"
        fi
    fi
done

# Fix depth-5 scripts (audits/linux/*/*/*.sh)
# These are at 5 levels deep, need 4 levels up to reach lib/
echo ""
echo "Fixing depth-5 scripts (../../../lib/ → ../../../../lib/)..."
for f in audits/linux/*/*/*.sh; do
    if [[ -f "$f" ]]; then
        # Check if file has ../../../lib/ but NOT ../../../../lib/
        if grep -q '/\.\./\.\./\.\./lib/' "$f" 2>/dev/null && \
           ! grep -q '/\.\./\.\./\.\./\.\./lib/' "$f" 2>/dev/null; then
            echo "  Fixing: $f"
            sed -i 's|/\.\./\.\./\.\./lib/|/../../../../lib/|g' "$f"
        fi
    fi
done

echo ""
echo "=== Fix Complete ==="

# Verify
echo ""
echo "Verification:"
depth4_after=$(grep -rl '/\.\./\.\./lib/' audits/linux/*/*.sh 2>/dev/null | grep -v '/\.\./\.\./\.\./lib/' | wc -l || echo 0)
depth5_after=$(grep -rl '/\.\./\.\./\.\./lib/' audits/linux/*/*/*.sh 2>/dev/null | grep -v '/\.\./\.\./\.\./\.\./lib/' | wc -l || echo 0)
echo "  Remaining depth-4 issues: $depth4_after"
echo "  Remaining depth-5 issues: $depth5_after"

# Test one script
echo ""
echo "Testing ssh-hardening-audit.sh..."
if bash -n audits/linux/platform/access/ssh-hardening-audit.sh 2>&1; then
    echo "  Syntax: OK"
else
    echo "  Syntax: FAILED"
fi
