#!/usr/bin/env python3
"""Poll Gumroad sales and fulfill licenses via GitHub Actions.

This script is designed for a GitHub-only licensing model:
- No always-on webhook server required
- Gumroad sales are polled from GitHub Actions
- Keygen license issuance and SMTP delivery run in the workflow context
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import requests

SUPPORTED_TIERS = ("starter", "professional", "business", "enterprise")
EMAIL_PATTERN = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
DEFAULT_API_URL = "https://api.gumroad.com/v2"
DEFAULT_ACTIVATION_URL = (
    "https://github.com/AuditToolkitLabs/Audit-Tool-/blob/main/docs/KEYGEN-QUICK-TEST.md"
)


@dataclass(frozen=True)
class QueuedSale:
    sale_id: str
    product_id: str
    tier: str
    email: str
    created_at: datetime
    created_at_raw: str
    order_ref: str



def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]



def _required_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise ValueError(f"Missing required environment variable: {name}")
    return value



def _parse_bool(raw_value: str | None, default: bool = False) -> bool:
    if raw_value is None or raw_value == "":
        return default

    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False

    raise ValueError(f"Invalid boolean value '{raw_value}'")



def _parse_iso_utc(value: str) -> datetime:
    normalized = (value or "").strip()
    if not normalized:
        raise ValueError("timestamp value is required")

    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"

    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)

    return parsed.astimezone(UTC)



def _format_iso_utc(value: datetime) -> str:
    return value.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")



def _parse_cursor(raw_cursor: str) -> tuple[datetime | None, str]:
    value = (raw_cursor or "").strip()
    if not value:
        return None, ""

    if "|" in value:
        ts_raw, sale_id = value.split("|", 1)
    else:
        ts_raw, sale_id = value, ""

    ts = _parse_iso_utc(ts_raw)
    return ts, sale_id.strip()



def _format_cursor(timestamp: datetime, sale_id: str = "") -> str:
    return f"{_format_iso_utc(timestamp)}|{sale_id.strip()}"



def _sanitize_token(value: str, max_len: int = 80) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9-]", "-", (value or "").strip())
    sanitized = re.sub(r"-+", "-", sanitized).strip("-")
    if not sanitized:
        return "unknown"
    return sanitized[:max_len]



def _is_valid_email(email: str) -> bool:
    return bool(EMAIL_PATTERN.match((email or "").strip()))



def _coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        return normalized in {"1", "true", "yes", "on"}
    if isinstance(value, (int, float)):
        return bool(value)
    return False



def _build_product_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for tier in SUPPORTED_TIERS:
        env_key = f"GUMROAD_{tier.upper()}_PRODUCT_ID"
        product_id = os.environ.get(env_key, "").strip()
        if product_id:
            mapping[product_id] = tier

    if not mapping:
        raise ValueError(
            "No Gumroad product mappings configured. Set at least one of "
            "GUMROAD_STARTER_PRODUCT_ID, GUMROAD_PROFESSIONAL_PRODUCT_ID, "
            "GUMROAD_BUSINESS_PRODUCT_ID, GUMROAD_ENTERPRISE_PRODUCT_ID"
        )

    return mapping



def _fetch_sales(
    api_url: str,
    access_token: str,
    after_date: str,
    max_pages: int,
    max_sales: int,
) -> list[dict[str, Any]]:
    endpoint = f"{api_url.rstrip('/')}/sales"
    page_key = ""
    all_sales: list[dict[str, Any]] = []

    for page in range(1, max_pages + 1):
        params: dict[str, str] = {
            "access_token": access_token,
            "after": after_date,
        }
        if page_key:
            params["page_key"] = page_key

        response = requests.get(endpoint, params=params, timeout=30)
        if response.status_code != 200:
            body_preview = response.text[:500]
            raise RuntimeError(
                f"Gumroad API request failed ({response.status_code}): {body_preview}"
            )

        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError("Gumroad API response root must be an object")
        if not payload.get("success", False):
            raise RuntimeError(
                f"Gumroad API reported failure: {payload.get('message', 'unknown error')}"
            )

        sales = payload.get("sales", [])
        if not isinstance(sales, list):
            raise RuntimeError("Gumroad API response field 'sales' must be a list")

        for sale in sales:
            if isinstance(sale, dict):
                all_sales.append(sale)
                if len(all_sales) >= max_sales:
                    return all_sales

        next_page_key = payload.get("next_page_key")
        if not next_page_key:
            break

        page_key = str(next_page_key).strip()
        if not page_key:
            break

    return all_sales



def _is_sale_new(
    sale_ts: datetime,
    sale_id: str,
    cursor_ts: datetime | None,
    cursor_sale_id: str,
) -> bool:
    if cursor_ts is None:
        return True

    if sale_ts > cursor_ts:
        return True
    if sale_ts < cursor_ts:
        return False

    return sale_id > cursor_sale_id



def _queue_sales(
    sales: list[dict[str, Any]],
    product_map: dict[str, str],
    cursor_ts: datetime | None,
    cursor_sale_id: str,
    allow_test_purchases: bool,
) -> tuple[list[QueuedSale], list[dict[str, str]]]:
    queued: list[QueuedSale] = []
    skipped: list[dict[str, str]] = []
    seen_ids: set[str] = set()

    for sale in sales:
        sale_id = str(sale.get("id", "")).strip()
        if not sale_id:
            skipped.append({"reason": "missing_sale_id"})
            continue

        if sale_id in seen_ids:
            continue
        seen_ids.add(sale_id)

        created_at_raw = str(sale.get("created_at", "")).strip()
        try:
            created_at = _parse_iso_utc(created_at_raw)
        except Exception:
            skipped.append({"sale_id": sale_id, "reason": "invalid_created_at"})
            continue

        if not _is_sale_new(created_at, sale_id, cursor_ts, cursor_sale_id):
            continue

        is_refunded = any(
            _coerce_bool(sale.get(field))
            for field in (
                "refunded",
                "partially_refunded",
                "chargedback",
                "disputed",
                "dispute_won",
            )
        )
        if is_refunded:
            skipped.append({"sale_id": sale_id, "reason": "refunded_or_disputed"})
            continue

        if not _coerce_bool(sale.get("paid", True)):
            skipped.append({"sale_id": sale_id, "reason": "not_paid"})
            continue

        if _coerce_bool(sale.get("test")) and not allow_test_purchases:
            skipped.append({"sale_id": sale_id, "reason": "test_purchase"})
            continue

        product_id = str(sale.get("product_id", "")).strip()
        tier = product_map.get(product_id)
        if not tier:
            skipped.append({"sale_id": sale_id, "reason": "unknown_product_id"})
            continue

        email = str(sale.get("email") or sale.get("purchase_email") or "").strip()
        if not _is_valid_email(email):
            skipped.append({"sale_id": sale_id, "reason": "missing_or_invalid_email"})
            continue

        order_ref = f"GR-{_sanitize_token(sale_id, max_len=64)}"

        queued.append(
            QueuedSale(
                sale_id=sale_id,
                product_id=product_id,
                tier=tier,
                email=email,
                created_at=created_at,
                created_at_raw=created_at_raw,
                order_ref=order_ref,
            )
        )

    queued.sort(key=lambda item: (item.created_at, item.sale_id))
    return queued, skipped



def _run_command(command: list[str]) -> None:
    result = subprocess.run(command, capture_output=True, text=True)

    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()

    if stdout:
        print(stdout)

    if result.returncode != 0:
        error_text = stderr or stdout or f"Command failed with exit code {result.returncode}"
        raise RuntimeError(error_text)



def _fulfill_sale(
    sale: QueuedSale,
    output_dir: Path,
    activation_url: str,
    repo_root: Path,
) -> Path:
    fulfill_script = repo_root / "tools" / "fulfill-keygen-license.py"
    email_script = repo_root / "tools" / "send-fulfilled-license-email.py"

    safe_sale_id = _sanitize_token(sale.sale_id, max_len=80)
    artifact_path = output_dir / f"license-fulfillment-gumroad-{safe_sale_id}.json"

    metadata = {
        "channel": "gumroad",
        "gumroad_sale_id": sale.sale_id,
        "gumroad_product_id": sale.product_id,
        "gumroad_sale_created_at": sale.created_at_raw,
        "support_scope": "basic-email-only",
    }

    _run_command(
        [
            sys.executable,
            str(fulfill_script),
            "--tier",
            sale.tier,
            "--customer-email",
            sale.email,
            "--order-ref",
            sale.order_ref,
            "--source",
            "github-gumroad-poll",
            "--notes",
            "Automatic fulfillment from GitHub Actions Gumroad poller",
            "--metadata-json",
            json.dumps(metadata),
            "--output",
            str(artifact_path),
        ]
    )

    _run_command(
        [
            sys.executable,
            str(email_script),
            "--artifact",
            str(artifact_path),
            "--activation-url",
            activation_url,
        ]
    )

    return artifact_path



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Poll Gumroad sales and fulfill Keygen licenses via GitHub Actions",
    )
    parser.add_argument(
        "--cursor",
        default="",
        help="Processing cursor in format ISO8601|sale_id (example: 2026-03-11T00:00:00Z|abc123)",
    )
    parser.add_argument(
        "--bootstrap-from-now",
        default="false",
        help="When true and cursor is empty, initialize cursor to current UTC and process no sales",
    )
    parser.add_argument(
        "--allow-test-purchases",
        default="false",
        help="Allow Gumroad test purchases to be fulfilled (default: false)",
    )
    parser.add_argument(
        "--api-url",
        default=DEFAULT_API_URL,
        help=f"Gumroad API base URL (default: {DEFAULT_API_URL})",
    )
    parser.add_argument(
        "--max-pages",
        type=int,
        default=20,
        help="Maximum Gumroad sales pages to fetch (default: 20)",
    )
    parser.add_argument(
        "--max-sales",
        type=int,
        default=500,
        help="Maximum sales records to fetch (default: 500)",
    )
    parser.add_argument(
        "--output-dir",
        default="gumroad-fulfillment",
        help="Directory for per-sale fulfillment artifacts",
    )
    parser.add_argument(
        "--state-output",
        default="gumroad-poll-state.json",
        help="Path to write poll/fulfillment state JSON",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Queue sales but do not create licenses or send emails",
    )
    return parser.parse_args()



def main() -> int:
    args = parse_args()

    state_path = Path(args.state_output).resolve()
    output_dir = Path(args.output_dir).resolve()

    state: dict[str, Any] = {
        "generated_at_utc": _format_iso_utc(datetime.now(UTC)),
        "input_cursor": args.cursor.strip(),
        "output_cursor": args.cursor.strip(),
        "bootstrap_mode": False,
        "fetched_sales_count": 0,
        "queued_sales_count": 0,
        "processed_sales_count": 0,
        "skipped_sales": [],
        "failures": [],
        "artifacts": [],
        "dry_run": bool(args.dry_run),
    }

    try:
        bootstrap_from_now = _parse_bool(args.bootstrap_from_now, default=False)
        allow_test_purchases = _parse_bool(args.allow_test_purchases, default=False)

        cursor_ts, cursor_sale_id = _parse_cursor(args.cursor)

        if cursor_ts is None:
            if bootstrap_from_now:
                now = datetime.now(UTC)
                state["bootstrap_mode"] = True
                state["output_cursor"] = _format_cursor(now, "")
                state_path.parent.mkdir(parents=True, exist_ok=True)
                state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
                print("Bootstrap complete: cursor initialized to current UTC time.")
                print(f"New cursor: {state['output_cursor']}")
                return 0

            raise ValueError(
                "Cursor is required. Provide --cursor or run with --bootstrap-from-now true once."
            )

        access_token = _required_env("GUMROAD_ACCESS_TOKEN")
        product_map = _build_product_map()

        after_date = cursor_ts.strftime("%Y-%m-%d")
        fetched_sales = _fetch_sales(
            api_url=args.api_url,
            access_token=access_token,
            after_date=after_date,
            max_pages=max(args.max_pages, 1),
            max_sales=max(args.max_sales, 1),
        )

        queued_sales, skipped_sales = _queue_sales(
            sales=fetched_sales,
            product_map=product_map,
            cursor_ts=cursor_ts,
            cursor_sale_id=cursor_sale_id,
            allow_test_purchases=allow_test_purchases,
        )

        state["fetched_sales_count"] = len(fetched_sales)
        state["queued_sales_count"] = len(queued_sales)
        state["skipped_sales"] = skipped_sales

        current_cursor_ts = cursor_ts
        current_cursor_sale_id = cursor_sale_id

        if not args.dry_run:
            output_dir.mkdir(parents=True, exist_ok=True)

        activation_url = os.environ.get("LICENSE_ACTIVATION_URL", "").strip() or DEFAULT_ACTIVATION_URL
        repo_root = _repo_root()

        for sale in queued_sales:
            if args.dry_run:
                state["processed_sales_count"] += 1
                state["artifacts"].append(
                    {
                        "sale_id": sale.sale_id,
                        "order_ref": sale.order_ref,
                        "tier": sale.tier,
                        "email": sale.email,
                        "dry_run": True,
                    }
                )
                current_cursor_ts = sale.created_at
                current_cursor_sale_id = sale.sale_id
                continue

            try:
                artifact_path = _fulfill_sale(
                    sale=sale,
                    output_dir=output_dir,
                    activation_url=activation_url,
                    repo_root=repo_root,
                )

                state["processed_sales_count"] += 1
                state["artifacts"].append(
                    {
                        "sale_id": sale.sale_id,
                        "order_ref": sale.order_ref,
                        "tier": sale.tier,
                        "email": sale.email,
                        "artifact": str(artifact_path),
                    }
                )

                current_cursor_ts = sale.created_at
                current_cursor_sale_id = sale.sale_id

            except Exception as error:
                state["failures"].append(
                    {
                        "sale_id": sale.sale_id,
                        "order_ref": sale.order_ref,
                        "tier": sale.tier,
                        "email": sale.email,
                        "error": str(error),
                    }
                )
                break

        state["output_cursor"] = _format_cursor(current_cursor_ts, current_cursor_sale_id)

        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")

        print("Gumroad poll summary")
        print(f"- Fetched sales: {state['fetched_sales_count']}")
        print(f"- Queued sales: {state['queued_sales_count']}")
        print(f"- Processed sales: {state['processed_sales_count']}")
        print(f"- Failures: {len(state['failures'])}")
        print(f"- Output cursor: {state['output_cursor']}")
        print(f"- State file: {state_path}")

        return 1 if state["failures"] else 0

    except Exception as error:
        state["failures"].append({"error": str(error)})
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
        print(f"Gumroad fulfillment run failed: {error}", file=sys.stderr)
        print(f"State file: {state_path}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
