#!/usr/bin/env python3
"""Fulfill a Keygen license request for beta and early commercial releases.

This tool is intended for maintainer-operated workflows. It creates licenses in
Keygen and writes a fulfillment artifact to disk for secure delivery.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import sys
from datetime import datetime, UTC
from pathlib import Path
from typing import Any


SUPPORTED_TIERS = (
    "free",
    "beta",
    "starter",
    "professional",
    "business",
    "enterprise",
)

DEFAULT_EXPIRES_BY_TIER = {
    "free": 365,
    "beta": 30,
    "starter": 365,
    "professional": 365,
    "business": 365,
    "enterprise": 365,
}

DEFAULT_MACHINES_BY_TIER = {
    "free": 25,
    "beta": 25,
    "starter": 50,
    "professional": 150,
    "business": 500,
    "enterprise": 1000,
}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _import_keygen_integration() -> Any:
    module_path = _repo_root() / "web" / "services_pkg" / "services" / "keygen_integration.py"
    if not module_path.exists():
        raise ValueError(f"Keygen integration module not found: {module_path}")

    spec = importlib.util.spec_from_file_location("keygen_integration_standalone", module_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Could not load Keygen integration module spec: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    keygen_integration = getattr(module, "KeygenIntegration", None)
    if keygen_integration is None:
        raise ValueError("KeygenIntegration class not found in keygen_integration.py")

    return keygen_integration


def _parse_positive_int(name: str, value: str | None) -> int | None:
    if value is None or value == "":
        return None

    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc

    if parsed < 1:
        raise ValueError(f"{name} must be at least 1")

    return parsed


def _validate_email(email: str) -> str:
    email_value = (email or "").strip()
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    if not re.match(pattern, email_value):
        raise ValueError("customer_email must be a valid email address")
    return email_value


def _validate_tier(tier: str) -> str:
    normalized_tier = (tier or "").strip().lower()
    if normalized_tier not in SUPPORTED_TIERS:
        raise ValueError(f"Unsupported tier '{tier}'. Allowed: {', '.join(SUPPORTED_TIERS)}")
    return normalized_tier


def _redact_key(key: str | None) -> str:
    if not key:
        return "<missing>"
    if len(key) <= 8:
        return "****"
    return f"{key[:6]}...{key[-4:]}"


def _parse_metadata_json(raw_metadata: str | None) -> dict[str, Any]:
    if not raw_metadata:
        return {}

    try:
        metadata = json.loads(raw_metadata)
    except json.JSONDecodeError as exc:
        raise ValueError(f"metadata_json is invalid JSON: {exc}") from exc

    if not isinstance(metadata, dict):
        raise ValueError("metadata_json must decode to an object")

    return metadata


def _required_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise ValueError(f"Missing required environment variable: {name}")
    return value


def _build_metadata(
    tier: str,
    customer_email: str,
    order_ref: str,
    source: str,
    notes: str | None,
    extra: dict[str, Any],
) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "order_ref": order_ref,
        "channel": source,
        "fulfilled_at_utc": datetime.now(UTC).isoformat(),
        "customer_email": customer_email,
        "tier_requested": tier,
    }

    if notes:
        metadata["notes"] = notes

    metadata.update(extra)
    return metadata


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Fulfill a Keygen license request",
    )
    parser.add_argument("--tier", required=True, help="License tier")
    parser.add_argument("--customer-email", required=True, help="Customer email address")
    parser.add_argument("--order-ref", required=True, help="Order/payment reference")
    parser.add_argument(
        "--source",
        default="github-beta",
        help="Sales channel marker for metadata (default: github-beta)",
    )
    parser.add_argument(
        "--expires-in-days",
        help="Optional expiry override in days (beta max: 90)",
    )
    parser.add_argument(
        "--machines-limit",
        help="Optional machine-limit override",
    )
    parser.add_argument(
        "--notes",
        default="",
        help="Optional internal notes",
    )
    parser.add_argument(
        "--metadata-json",
        default="",
        help="Optional extra metadata JSON object",
    )
    parser.add_argument(
        "--output",
        default="license-fulfillment.json",
        help="Output artifact path",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        tier = _validate_tier(args.tier)
        customer_email = _validate_email(args.customer_email)

        expires_in_days = _parse_positive_int("expires_in_days", args.expires_in_days)
        machines_limit = _parse_positive_int("machines_limit", args.machines_limit)

        if expires_in_days is None:
            expires_in_days = DEFAULT_EXPIRES_BY_TIER[tier]
        if machines_limit is None:
            machines_limit = DEFAULT_MACHINES_BY_TIER[tier]

        if tier == "beta" and expires_in_days > 90:
            raise ValueError("beta licenses are limited to a maximum of 90 days")

        extra_metadata = _parse_metadata_json(args.metadata_json)

        api_key = _required_env("KEYGEN_API_KEY")
        account_id = _required_env("KEYGEN_ACCOUNT_ID")
        product_id = _required_env("KEYGEN_PRODUCT_ID")
        api_url = os.environ.get("KEYGEN_API_URL", "https://api.keygen.sh/v1").strip() or "https://api.keygen.sh/v1"

        KeygenIntegration = _import_keygen_integration()
        integration = KeygenIntegration(
            api_key=api_key,
            account_id=account_id,
            product_id=product_id,
            api_url=api_url,
        )

        metadata = _build_metadata(
            tier=tier,
            customer_email=customer_email,
            order_ref=args.order_ref,
            source=args.source,
            notes=args.notes.strip() or None,
            extra=extra_metadata,
        )

        success, result = integration.create_license(
            tier=tier,
            email=customer_email,
            expires_in_days=expires_in_days,
            machines_limit=machines_limit,
            metadata=metadata,
        )

        if not success:
            error_message = result.get("error", "unknown Keygen error")
            raise RuntimeError(f"Keygen license creation failed: {error_message}")

        output_payload = {
            "success": True,
            "request": {
                "tier": tier,
                "customer_email": customer_email,
                "order_ref": args.order_ref,
                "source": args.source,
                "expires_in_days": expires_in_days,
                "machines_limit": machines_limit,
            },
            "license": {
                "id": result.get("id"),
                "key": result.get("key"),
                "tier": result.get("tier", tier),
                "expires_at": result.get("expires_at"),
                "machines_limit": result.get("machines_limit", machines_limit),
                "metadata": result.get("metadata", metadata),
            },
            "delivery": {
                "secure_channel_required": True,
                "guidance": "Deliver license key via support mailbox or encrypted channel only.",
            },
            "generated_at_utc": datetime.now(UTC).isoformat(),
        }

        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(output_payload, indent=2), encoding="utf-8")

        print("License fulfillment completed")
        print(f"- Tier: {tier}")
        print(f"- Customer: {customer_email}")
        print(f"- Order ref: {args.order_ref}")
        print(f"- License id: {result.get('id')}")
        print(f"- License key: {_redact_key(result.get('key'))}")
        print(f"- Artifact: {output_path}")
        return 0

    except Exception as error:
        print(f"License fulfillment failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())