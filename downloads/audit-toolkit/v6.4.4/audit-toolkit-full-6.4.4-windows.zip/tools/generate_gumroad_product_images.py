from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

from PIL import Image, ImageDraw, ImageFilter, ImageFont


@dataclass
class ProductCover:
    filename: str
    tier_name: str
    tagline: str
    price_text: str
    color_start: Tuple[int, int, int]
    color_end: Tuple[int, int, int]
    footer_text: str = "Includes automated license key delivery and setup instructions"


LANDSCAPE_WIDTH = 1600
LANDSCAPE_HEIGHT = 1000
SQUARE_SIZE = 1200


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    font_candidates = [
        "segoeuib.ttf" if bold else "segoeui.ttf",
        "arialbd.ttf" if bold else "arial.ttf",
        "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf",
    ]
    for name in font_candidates:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def lerp(a: int, b: int, t: float) -> int:
    return int(a + (b - a) * t)


def gradient_background(width: int, height: int, c1: Tuple[int, int, int], c2: Tuple[int, int, int]) -> Image.Image:
    img = Image.new("RGB", (width, height), c1)
    draw = ImageDraw.Draw(img)
    for y in range(height):
        t = y / (height - 1)
        color = (
            lerp(c1[0], c2[0], t),
            lerp(c1[1], c2[1], t),
            lerp(c1[2], c2[2], t),
        )
        draw.line([(0, y), (width, y)], fill=color)
    return img


def draw_glow(base: Image.Image, center: Tuple[int, int], radius: int, color: Tuple[int, int, int], alpha: int) -> None:
    glow = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(glow)
    x, y = center
    draw.ellipse([x - radius, y - radius, x + radius, y + radius], fill=(*color, alpha))
    glow = glow.filter(ImageFilter.GaussianBlur(radius=120))
    base.alpha_composite(glow)


def wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont | ImageFont.ImageFont, max_width: int) -> list[str]:
    words = text.split()
    if not words:
        return [""]

    lines: list[str] = []
    current_line = words[0]

    for word in words[1:]:
        candidate = f"{current_line} {word}"
        candidate_bbox = draw.textbbox((0, 0), candidate, font=font)
        candidate_width = candidate_bbox[2] - candidate_bbox[0]
        if candidate_width <= max_width:
            current_line = candidate
        else:
            lines.append(current_line)
            current_line = word

    lines.append(current_line)
    return lines


def create_cover(product: ProductCover, output_path: Path, width: int, height: int) -> None:
    margin_x = int(width * 0.06)
    panel_top = int(height * 0.12)
    panel_bottom = int(height * 0.88)
    panel_radius = int(min(width, height) * 0.035)

    background = gradient_background(width, height, product.color_start, product.color_end).convert("RGBA")

    draw_glow(
        background,
        center=(width - int(width * 0.08), int(height * 0.18)),
        radius=int(min(width, height) * 0.22),
        color=(255, 255, 255),
        alpha=35,
    )
    draw_glow(
        background,
        center=(int(width * 0.14), height - int(height * 0.12)),
        radius=int(min(width, height) * 0.26),
        color=(255, 255, 255),
        alpha=28,
    )

    overlay = Image.new("RGBA", background.size, (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    overlay_draw.rounded_rectangle(
        [margin_x - 20, panel_top, width - margin_x + 20, panel_bottom],
        radius=panel_radius,
        fill=(10, 16, 28, 110),
        outline=(255, 255, 255, 45),
        width=2,
    )
    background.alpha_composite(overlay)

    title_font = load_font(int(height * 0.084), bold=True)
    subtitle_font = load_font(int(height * 0.038), bold=False)
    brand_font = load_font(int(height * 0.034), bold=True)
    price_font = load_font(int(height * 0.058), bold=True)
    footer_font = load_font(int(height * 0.026), bold=False)

    draw = ImageDraw.Draw(background)

    brand_y = int(height * 0.09)
    draw.text((margin_x, brand_y), "Audit Toolkit", font=brand_font, fill=(240, 246, 255, 230))

    badge_text = "Annual License"
    badge_bbox = draw.textbbox((0, 0), badge_text, font=footer_font)
    badge_w = badge_bbox[2] - badge_bbox[0] + 42
    badge_h = badge_bbox[3] - badge_bbox[1] + 20
    badge_x = width - margin_x - badge_w
    badge_y = brand_y
    draw.rounded_rectangle(
        [badge_x, badge_y, badge_x + badge_w, badge_y + badge_h],
        radius=18,
        fill=(255, 255, 255, 45),
        outline=(255, 255, 255, 90),
        width=1,
    )
    draw.text((badge_x + 21, badge_y + 10), badge_text, font=footer_font, fill=(250, 252, 255, 230))

    title_y = int(height * 0.33)
    draw.text((margin_x, title_y), product.tier_name, font=title_font, fill=(255, 255, 255, 255))

    text_max_width = width - (margin_x * 2)
    tagline_y = int(height * 0.44)
    tagline_lines = wrap_text(draw, product.tagline, subtitle_font, text_max_width)
    line_height = int(subtitle_font.size * 1.35) if hasattr(subtitle_font, "size") else 48
    for idx, line in enumerate(tagline_lines):
        draw.text((margin_x, tagline_y + idx * line_height), line, font=subtitle_font, fill=(235, 240, 252, 245))

    price_y = int(height * 0.58)
    draw.text((margin_x, price_y), product.price_text, font=price_font, fill=(255, 255, 255, 250))

    footer = product.footer_text
    footer_y = int(height * 0.82)
    footer_lines = wrap_text(draw, footer, footer_font, text_max_width)
    footer_line_height = int(footer_font.size * 1.35) if hasattr(footer_font, "size") else 34
    for idx, line in enumerate(footer_lines):
        draw.text((margin_x, footer_y + idx * footer_line_height), line, font=footer_font, fill=(240, 245, 255, 215))

    background.convert("RGB").save(output_path, "PNG", optimize=True)


def main() -> None:
    output_dir = Path("docs/assets/gumroad")
    output_dir.mkdir(parents=True, exist_ok=True)

    products = [
        ProductCover(
            filename="gumroad-starter-cover.png",
            tier_name="Starter",
            tagline="For small teams auditing 26–50 servers",
            price_text="£299 / year",
            color_start=(11, 76, 89),
            color_end=(16, 185, 129),
            footer_text="Includes automated license key delivery and best-effort email support",
        ),
        ProductCover(
            filename="gumroad-professional-cover.png",
            tier_name="Professional",
            tagline="For teams auditing 51–150 servers",
            price_text="£499 / year",
            color_start=(17, 45, 92),
            color_end=(17, 112, 184),
            footer_text="Includes automated license key delivery and 48-hour email support",
        ),
        ProductCover(
            filename="gumroad-business-cover.png",
            tier_name="Business",
            tagline="For organizations auditing 151–500 servers",
            price_text="£1,499 / year",
            color_start=(54, 22, 92),
            color_end=(124, 56, 181),
            footer_text="Includes automated license key delivery and priority email support",
        ),
        ProductCover(
            filename="gumroad-enterprise-cover.png",
            tier_name="Enterprise",
            tagline="For large environments with dedicated support",
            price_text="By separate agreement",
            color_start=(45, 32, 15),
            color_end=(132, 96, 33),
            footer_text="Contact licensing@audittoolkitlabs.com for Enterprise terms and support",
        ),
    ]

    for product in products:
        create_cover(
            product,
            output_dir / product.filename,
            width=LANDSCAPE_WIDTH,
            height=LANDSCAPE_HEIGHT,
        )

        square_filename = product.filename.replace(".png", "-square.png")
        create_cover(
            product,
            output_dir / square_filename,
            width=SQUARE_SIZE,
            height=SQUARE_SIZE,
        )

    print(f"Generated {len(products) * 2} Gumroad product images in {output_dir}")


if __name__ == "__main__":
    main()
