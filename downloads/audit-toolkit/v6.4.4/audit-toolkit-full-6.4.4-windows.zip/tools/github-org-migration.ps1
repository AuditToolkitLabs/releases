﻿<#
.SYNOPSIS
    Automates GitHub org migration and identity hardening tasks for this repository.

.DESCRIPTION
    Uses GitHub CLI (gh) to run as much of the owner/identity transition as possible:
      - Optional repository transfer (source owner -> target org)
      - Repository settings hardening (description, homepage, discussions, topics, security features, Pages)
      - Optional branch protection baseline
      - Optional repository variables and secrets sync from local JSON maps
      - Optional local git remote + git identity update

    This script is idempotent for repeated runs where practical and defaults to a safe dry-run mode.

.EXAMPLE
    ./tools/github-org-migration.ps1 -DryRun

.EXAMPLE
    ./tools/github-org-migration.ps1 -Execute \
        -TransferRepo \
        -ConfigureRepository \
        -ConfigureBranchProtection \
        -ConfigureVariables -VariablesJsonPath ./tools/github-org-migration.variables.json \
        -ConfigureSecrets -SecretsMapJsonPath ./tools/github-org-migration.secrets-map.json \
        -UpdateLocalGitRemote -SetLocalGitIdentity

.NOTES
    Requires: gh authenticated with repo/admin scopes and org transfer permissions.
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [string]$SourceOwner = "",
    [string]$TargetOwner = "AuditToolkitLabs",
    [string]$Repo = "Audit-Tool-",
    [string]$DefaultBranch = "main",

    [switch]$Execute,
    [switch]$DryRun,
    [switch]$TransferRepo,
    [switch]$ConfigureRepository,
    [switch]$ConfigureBranchProtection,
    [switch]$ConfigureVariables,
    [switch]$ConfigureSecrets,
    [switch]$UpdateLocalGitRemote,
    [switch]$SetLocalGitIdentity,

    [string]$Description = "🛡️ Security audit toolkit for Linux, Windows & Hypervisors. 255+ scripts, 390+ APIs. Self-hosted, on-premises. Free tier: 25 servers. BSL 1.1 licensed.",
    [string]$Homepage = "https://audittoolkitlabs.github.io/Audit-Tool-/",
    [string[]]$Topics = @(
        "security",
        "audit",
        "linux",
        "windows",
        "hypervisor",
        "compliance",
        "vulnerability-scanner",
        "self-hosted",
        "devops",
        "security-tools",
        "siem",
        "cis-benchmark"
    ),

    [string]$VariablesJsonPath = "",
    [string]$SecretsMapJsonPath = "",

    [string]$GitUserName = "Security Audit Team",
    [string]$GitUserEmail = "admin@audittoolkitlabs.com"
)

$null = $DefaultBranch, $Description, $Homepage, $GitUserName, $GitUserEmail

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ($Execute -and $DryRun) {
    throw "Use either -Execute or -DryRun, not both."
}

if ($Execute) {
    $DryRun = $false
} elseif (-not $DryRun) {
    $DryRun = $true
}

function Write-Section {
    param([string]$Title)
    Write-Output "`n=== $Title ==="
}

function Write-Step {
    param([string]$Message)
    Write-Output "[>] $Message"
}

function Write-Ok {
    param([string]$Message)
    Write-Output "[OK] $Message"
}

function Write-Warn {
    param([string]$Message)
    Write-Output "[WARN] $Message"
}

function Get-SafeCommandDisplay {
    param(
        [string]$FilePath,
        [string[]]$ArgumentList
    )

    $displayArgs = @($ArgumentList)

    if ($FilePath -eq "gh" -and $displayArgs.Count -ge 2 -and $displayArgs[0] -eq "secret" -and $displayArgs[1] -eq "set") {
        for ($i = 0; $i -lt $displayArgs.Count - 1; $i++) {
            if ($displayArgs[$i] -eq "-b") {
                $displayArgs[$i + 1] = "***REDACTED***"
            }
        }
    }

    return "$FilePath " + ($displayArgs -join " ")
}

function Invoke-LocalCommand {
    param(
        [string]$FilePath,
        [string[]]$ArgumentList,
        [switch]$AllowFailure,
        [switch]$Quiet,
        [switch]$AlwaysRun
    )

    $display = Get-SafeCommandDisplay -FilePath $FilePath -ArgumentList $ArgumentList
    if (-not $Quiet) {
        Write-Output "    $display"
    }

    if ($DryRun -and -not $AlwaysRun) {
        if (-not $Quiet) {
            Write-Output "    [DRY RUN]"
        }
        return ""
    }

    $output = & $FilePath @ArgumentList 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0 -and -not $AllowFailure) {
        $text = ($output | Out-String).Trim()
        throw "Command failed ($exitCode): $display`n$text"
    }

    return ($output | Out-String).Trim()
}

function Invoke-Gh {
    param(
        [string[]]$ArgumentList,
        [switch]$AllowFailure,
        [switch]$Quiet,
        [switch]$AlwaysRun
    )

    return Invoke-LocalCommand -FilePath "gh" -ArgumentList $ArgumentList -AllowFailure:$AllowFailure -Quiet:$Quiet -AlwaysRun:$AlwaysRun
}

function Invoke-Git {
    param(
        [string[]]$ArgumentList,
        [switch]$AllowFailure,
        [switch]$Quiet,
        [switch]$AlwaysRun
    )

    return Invoke-LocalCommand -FilePath "git" -ArgumentList $ArgumentList -AllowFailure:$AllowFailure -Quiet:$Quiet -AlwaysRun:$AlwaysRun
}

function Invoke-GhApiJson {
    param(
        [string]$Method,
        [string]$Endpoint,
        [object]$Payload,
        [switch]$AllowFailure
    )

    $json = $Payload | ConvertTo-Json -Depth 20 -Compress
    Write-Output "    gh api -X $Method $Endpoint --input -"

    if ($DryRun) {
        Write-Output "    [DRY RUN] payload: $json"
        return ""
    }

    $output = $json | & gh api -X $Method $Endpoint --input - 2>&1
    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0 -and -not $AllowFailure) {
        $text = ($output | Out-String).Trim()
        throw "gh api failed ($exitCode): $Method $Endpoint`n$text"
    }

    return ($output | Out-String).Trim()
}

function Get-ObjectProperties {
    param([object]$Object)

    if ($null -eq $Object) {
        return @()
    }

    if ($Object -is [System.Collections.IDictionary]) {
        return $Object.GetEnumerator() | ForEach-Object {
            [pscustomobject]@{ Name = [string]$_.Key; Value = $_.Value }
        }
    }

    return $Object.PSObject.Properties | ForEach-Object {
        [pscustomobject]@{ Name = [string]$_.Name; Value = $_.Value }
    }
}

function Test-GitHubReservedName {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return $false
    }

    return $Name -imatch "^GITHUB_"
}

function Resolve-SourceOwnerFromOrigin {
    $originUrl = Invoke-Git -ArgumentList @("remote", "get-url", "origin") -Quiet -AlwaysRun
    if ([string]::IsNullOrWhiteSpace($originUrl)) {
        throw "Could not resolve origin remote URL."
    }

    $pattern = "github\.com[:/](?<owner>[^/]+)/(?<repo>[^/.]+)(?:\.git)?$"
    $match = [regex]::Match($originUrl.Trim(), $pattern)
    if (-not $match.Success) {
        throw "Origin remote is not a GitHub URL: $originUrl"
    }

    return $match.Groups["owner"].Value
}

function Assert-ToolsAndAuth {
    if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
        throw "GitHub CLI (gh) not found. Install with: winget install GitHub.cli"
    }

    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        throw "git command not found in PATH."
    }

    if ($DryRun) {
        Write-Warn "Dry-run mode enabled. No changes will be applied."
    }

    $null = Invoke-Gh -ArgumentList @("auth", "status") -AllowFailure -AlwaysRun
}

function Assert-RepoExists {
    param([string]$RepoFullName)

    $null = Invoke-Gh -ArgumentList @("repo", "view", $RepoFullName, "--json", "nameWithOwner") -AllowFailure -AlwaysRun
}

function Move-Repository {
    param(
        [string]$FromOwner,
        [string]$ToOwner,
        [string]$RepoName
    )

    if ($FromOwner -ieq $ToOwner) {
        Write-Ok "Source owner already matches target owner ($ToOwner). Transfer skipped."
        return
    }

    Write-Step "Transferring repository from $FromOwner to $ToOwner"
    $endpoint = "repos/$FromOwner/$RepoName/transfer"

    $null = Invoke-Gh -ArgumentList @(
        "api", "-X", "POST", $endpoint,
        "-f", "new_owner=$ToOwner",
        "-f", "new_name=$RepoName"
    )

    if ($DryRun) {
        Write-Ok "Transfer command staged (dry-run)."
        return
    }

    $newFull = "$ToOwner/$RepoName"
    Write-Step "Waiting for transfer completion at $newFull"

    $maxAttempts = 24
    for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
        $null = Invoke-Gh -ArgumentList @("repo", "view", $newFull, "--json", "nameWithOwner") -AllowFailure -Quiet
        if ($LASTEXITCODE -eq 0) {
            Write-Ok "Transfer detected on attempt $attempt/$maxAttempts"
            return
        }

        Start-Sleep -Seconds 5
    }

    throw "Transfer request submitted but target repo not visible yet: $newFull"
}

function Set-RepositorySettings {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [string]$RepoFullName,
        [string[]]$TopicList
    )

    if (-not $PSCmdlet.ShouldProcess($RepoFullName, "Apply repository metadata, Pages, and security settings")) {
        return
    }

    Write-Step "Applying repository metadata and feature settings"

    $topicArgs = @()
    foreach ($topic in $TopicList) {
        $topicArgs += "--add-topic"
        $topicArgs += $topic
    }

    $ghArgs = @("repo", "edit", $RepoFullName, "--description", $Description, "--homepage", $Homepage, "--enable-discussions") + $topicArgs
    $null = Invoke-Gh -ArgumentList $ghArgs

    Write-Step "Configuring GitHub Pages source to /$DefaultBranch /site"
    $pagesPayload = @{
        source = @{
            branch = $DefaultBranch
            path = "/site"
        }
    }

    $pagesEndpoint = "repos/$RepoFullName/pages"
    try {
        $null = Invoke-GhApiJson -Method "POST" -Endpoint $pagesEndpoint -Payload $pagesPayload -AllowFailure
        if ($LASTEXITCODE -ne 0 -and -not $DryRun) {
            $null = Invoke-GhApiJson -Method "PUT" -Endpoint $pagesEndpoint -Payload $pagesPayload
        }
    } catch {
        if ($DryRun) {
            Write-Warn "Pages setup dry-run encountered a non-blocking warning: $($_.Exception.Message)"
        } else {
            Write-Warn "Pages may require manual confirmation in repo settings."
        }
    }

    Write-Step "Enabling vulnerability alerts and automated security fixes"
    $null = Invoke-Gh -ArgumentList @("api", "-X", "PUT", "repos/$RepoFullName/vulnerability-alerts") -AllowFailure
    $null = Invoke-Gh -ArgumentList @("api", "-X", "PUT", "repos/$RepoFullName/automated-security-fixes") -AllowFailure

    Write-Ok "Repository settings configured"
}

function Set-BranchProtection {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([string]$RepoFullName)

    if (-not $PSCmdlet.ShouldProcess("$RepoFullName/$DefaultBranch", "Apply branch protection baseline")) {
        return
    }

    Write-Step "Applying branch protection baseline to $DefaultBranch"

    $payload = @{
        required_status_checks = @{
            strict = $true
            contexts = @()
        }
        enforce_admins = $false
        required_pull_request_reviews = $null
        restrictions = $null
        allow_force_pushes = $false
        allow_deletions = $false
    }

    $endpoint = "repos/$RepoFullName/branches/$DefaultBranch/protection"
    $null = Invoke-GhApiJson -Method "PUT" -Endpoint $endpoint -Payload $payload -AllowFailure

    Write-Ok "Branch protection baseline applied (or attempted)"
}

function Set-RepositoryVariables {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [string]$RepoFullName,
        [string]$JsonPath
    )

    if (-not $PSCmdlet.ShouldProcess($RepoFullName, "Set repository variables from $JsonPath")) {
        return
    }

    if (-not (Test-Path -LiteralPath $JsonPath)) {
        throw "Variables JSON file not found: $JsonPath"
    }

    Write-Step "Setting repository variables from $JsonPath"
    $raw = Get-Content -LiteralPath $JsonPath -Raw
    $obj = $raw | ConvertFrom-Json

    foreach ($item in (Get-ObjectProperties -Object $obj)) {
        $name = $item.Name
        $value = [string]$item.Value
        if ([string]::IsNullOrWhiteSpace($name)) {
            continue
        }

        if (Test-GitHubReservedName -Name $name) {
            Write-Warn "Skipped variable '$name' because names starting with 'GITHUB_' are reserved by GitHub Actions."
            continue
        }

        $null = Invoke-Gh -ArgumentList @("variable", "set", $name, "-R", $RepoFullName, "-b", $value)
        Write-Ok "Variable set: $name"
    }
}

function Set-RepositorySecrets {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param(
        [string]$RepoFullName,
        [string]$JsonPath
    )

    if (-not $PSCmdlet.ShouldProcess($RepoFullName, "Set repository secrets from $JsonPath")) {
        return
    }

    if (-not (Test-Path -LiteralPath $JsonPath)) {
        throw "Secrets map JSON file not found: $JsonPath"
    }

    Write-Step "Setting repository secrets from environment mapping in $JsonPath"
    $raw = Get-Content -LiteralPath $JsonPath -Raw
    $obj = $raw | ConvertFrom-Json

    foreach ($item in (Get-ObjectProperties -Object $obj)) {
        $secretName = $item.Name
        $envVarName = [string]$item.Value
        if ([string]::IsNullOrWhiteSpace($secretName) -or [string]::IsNullOrWhiteSpace($envVarName)) {
            continue
        }

        if (Test-GitHubReservedName -Name $secretName) {
            Write-Warn "Skipped secret '$secretName' because names starting with 'GITHUB_' are reserved by GitHub Actions."
            continue
        }

        $secretValue = [Environment]::GetEnvironmentVariable($envVarName)
        if ([string]::IsNullOrWhiteSpace($secretValue)) {
            Write-Warn "Skipped secret '$secretName' because env var '$envVarName' is not set."
            continue
        }

        $null = Invoke-Gh -ArgumentList @("secret", "set", $secretName, "-R", $RepoFullName, "-b", $secretValue)
        Write-Ok "Secret set: $secretName (from $envVarName)"
    }
}

function Update-LocalRemote {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([string]$RepoFullName)

    $targetUrl = "https://github.com/$RepoFullName.git"
    Write-Step "Updating local origin remote to $targetUrl"
    if ($PSCmdlet.ShouldProcess("origin", "Set remote URL to $targetUrl")) {
        $null = Invoke-Git -ArgumentList @("remote", "set-url", "origin", $targetUrl)
        $null = Invoke-Git -ArgumentList @("remote", "set-url", "--push", "origin", $targetUrl) -AllowFailure
        Write-Ok "Local origin remote updated"
    }
}

function Set-LocalIdentity {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    Write-Step "Setting local git identity"
    if ($PSCmdlet.ShouldProcess("local git config", "Set user.name and user.email")) {
        $null = Invoke-Git -ArgumentList @("config", "--local", "user.name", $GitUserName)
        $null = Invoke-Git -ArgumentList @("config", "--local", "user.email", $GitUserEmail)
        Write-Ok "Local git identity set to '$GitUserName <$GitUserEmail>'"
    }
}

Write-Section "GitHub Org Migration Automation"
Assert-ToolsAndAuth

if ([string]::IsNullOrWhiteSpace($SourceOwner)) {
    $SourceOwner = Resolve-SourceOwnerFromOrigin
}

if (-not $TransferRepo -and -not $ConfigureRepository -and -not $ConfigureBranchProtection -and -not $ConfigureVariables -and -not $ConfigureSecrets -and -not $UpdateLocalGitRemote -and -not $SetLocalGitIdentity) {
    Write-Warn "No action switches provided; defaulting to hardening workflow (no transfer)."
    $ConfigureRepository = $true
    $ConfigureBranchProtection = $true
    $UpdateLocalGitRemote = $true
    $SetLocalGitIdentity = $true
}

$sourceFull = "$SourceOwner/$Repo"
$targetFull = "$TargetOwner/$Repo"

Write-Output "Source repo : $sourceFull"
Write-Output "Target repo : $targetFull"
Write-Output "Mode       : $(if ($DryRun) { 'DRY RUN' } else { 'EXECUTE' })"

Write-Section "Preflight"
Assert-RepoExists -RepoFullName $sourceFull
$null = Invoke-Gh -ArgumentList @("api", "orgs/$TargetOwner") -AllowFailure -AlwaysRun
if ($LASTEXITCODE -ne 0 -and -not $DryRun) {
    throw "Target organization not accessible via gh api: $TargetOwner"
}
Write-Ok "Preflight checks complete"

if ($TransferRepo) {
    Write-Section "Transfer"
    Move-Repository -FromOwner $SourceOwner -ToOwner $TargetOwner -RepoName $Repo
}

# After transfer (or if no transfer needed), always operate against target owner.
$activeRepo = if ($SourceOwner -ieq $TargetOwner -or $TransferRepo) { $targetFull } else { $sourceFull }

if ($ConfigureRepository) {
    Write-Section "Repository Settings"
    Set-RepositorySettings -RepoFullName $activeRepo -TopicList $Topics
}

if ($ConfigureBranchProtection) {
    Write-Section "Branch Protection"
    Set-BranchProtection -RepoFullName $activeRepo
}

if ($ConfigureVariables) {
    Write-Section "Variables"
    if ([string]::IsNullOrWhiteSpace($VariablesJsonPath)) {
        throw "-ConfigureVariables requires -VariablesJsonPath"
    }
    Set-RepositoryVariables -RepoFullName $activeRepo -JsonPath $VariablesJsonPath
}

if ($ConfigureSecrets) {
    Write-Section "Secrets"
    if ([string]::IsNullOrWhiteSpace($SecretsMapJsonPath)) {
        throw "-ConfigureSecrets requires -SecretsMapJsonPath"
    }
    Set-RepositorySecrets -RepoFullName $activeRepo -JsonPath $SecretsMapJsonPath
}

if ($UpdateLocalGitRemote) {
    Write-Section "Local Git Remote"
    $remoteRepo = if ($TransferRepo -or $SourceOwner -ieq $TargetOwner) { $targetFull } else { $sourceFull }
    Update-LocalRemote -RepoFullName $remoteRepo
}

if ($SetLocalGitIdentity) {
    Write-Section "Local Git Identity"
    Set-LocalIdentity
}

Write-Section "Validation"
$null = Invoke-Gh -ArgumentList @("repo", "view", $activeRepo, "--json", "nameWithOwner,url,defaultBranchRef,isPrivate") -AllowFailure
$null = Invoke-Git -ArgumentList @("remote", "-v") -AllowFailure
Write-Ok "Validation commands executed"

Write-Section "Manual Follow-Up (Not Fully API-Automatable)"
Write-Output "- Verify user email privacy and no personal public email in GitHub account settings"
Write-Output "- Re-check GitHub Sponsors profile owner and payout identity"
Write-Output "- Confirm any external webhooks/apps outside repo scope now point to $activeRepo"

Write-Output "`nCompleted."

