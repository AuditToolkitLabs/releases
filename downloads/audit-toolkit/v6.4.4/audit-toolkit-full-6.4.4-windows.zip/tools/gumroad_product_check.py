import json
import os
import sys
import urllib.parse
import urllib.request


def main() -> int:
    token = os.environ["GUMROAD_ACCESS_TOKEN"]
    products = {
        "Starter": os.environ.get("STARTER_ID", ""),
        "Professional": os.environ.get("PROFESSIONAL_ID", ""),
        "Business": os.environ.get("BUSINESS_ID", ""),
        "Enterprise": os.environ.get("ENTERPRISE_ID", ""),
    }

    issues = []

    for name, pid in products.items():
        if not pid:
            print(f"[{name}] SKIP - no product ID configured")
            continue

        params = urllib.parse.urlencode({"access_token": token})
        url = f"https://api.gumroad.com/v2/products/{pid}?{params}"
        req = urllib.request.Request(url)

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            body = exc.read().decode()
            print(f"[{name}] ERROR {exc.code}: {body}")
            issues.append(f"{name}: HTTP {exc.code}")
            continue

        product = data.get("product", {}) if isinstance(data, dict) else {}
        published = bool(product.get("published", False))
        short_url = product.get("short_url", "")

        files = product.get("files", [])
        file_info = product.get("file_info", "")
        custom_delivery_url = product.get("custom_delivery_url", "")
        content = product.get("formatted_content", "")
        custom_fields = product.get("custom_fields", [])

        file_count = len(files) if isinstance(files, list) else 0
        has_file_info = bool(file_info)
        has_custom_delivery_url = bool(custom_delivery_url)
        has_content = isinstance(content, str) and len(content) > 0
        custom_field_count = len(custom_fields) if isinstance(custom_fields, list) else 0

        status = "PASS" if published else "WARN"
        print(f"\n[{status}] {name} (ID: {pid})")
        print(f"     Published:  {published}")
        print(f"     Short URL:  {short_url}")
        print(f"     Files:      {file_count} attached")
        print(f"     FileInfo:   {'yes' if has_file_info else 'no'}")
        print(f"     DeliveryURL:{'yes' if has_custom_delivery_url else 'no'}")
        print(f"     ContentLen: {len(content) if isinstance(content, str) else 0}")
        print(f"     CustomFlds: {custom_field_count}")

        if not published:
            issues.append(f"{name}: not published")

        if not (file_count > 0 or has_file_info or has_custom_delivery_url or has_content or custom_field_count > 0):
            print("     INFO: API did not return content/file metadata for this product in this endpoint view")

    print("\n" + "=" * 60)
    if issues:
        print("ISSUES FOUND:")
        for issue in issues:
            print(f"  FAIL {issue}")
        return 1

    print("PASS All products: published")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
