<#
.SYNOPSIS
    Hyper-V Test Lab Manager for Security Audit Toolkit

.DESCRIPTION
    Creates, manages, and tests VMs for validating audit scripts.
    Requires Administrator privileges.

.PARAMETER Action
    Action to perform: List, Create, Start, Stop, Test, Destroy, Snapshot, Restore

.PARAMETER VMName
    Specific VM name to target. Use "All" for all lab VMs.

.PARAMETER LabProfile
    Lab configuration: Minimal, Standard, Full
    - Minimal: 1 Windows Server, 1 Ubuntu
    - Standard: 1 Windows Server, 1 Ubuntu, 1 CentOS
    - Full: 2 Windows (Server + Desktop), Ubuntu, CentOS, Alpine

.EXAMPLE
    .\hyperv-lab.ps1 -Action List
    Lists all lab VMs and their status

.EXAMPLE
    .\hyperv-lab.ps1 -Action Create -LabProfile Standard
    Creates the standard test lab VMs

.EXAMPLE
    .\hyperv-lab.ps1 -Action Test
    Runs audit toolkit tests against all running lab VMs

.NOTES
    Version: 4.3.0
    Requires: Hyper-V, Administrator privileges
#>

#Requires -RunAsAdministrator
#Requires -Version 5.1

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("List", "Create", "Start", "Stop", "Test", "Destroy", "Snapshot", "Restore", "Status")]
    [string]$Action,

    [Parameter()]
    [string]$VMName = "All",

    [Parameter()]
    [ValidateSet("Minimal", "Standard", "Full")]
    [string]$LabProfile = "Standard",

    [Parameter()]
    [string]$ISOPath = "C:\ISO",

    [Parameter()]
    [string]$VHDPath = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [string]$SwitchName = "AuditLabSwitch"
)

$null = $VMName, $LabProfile, $ISOPath, $VHDPath, $SwitchName

$ErrorActionPreference = "Stop"

# Lab VM Definitions
# Updated ISO names to match actual files in C:\ISO (copy from C:\Users\churc\iso)
$LabVMs = @{
    Minimal = @(
        @{ Name = "AuditLab-WinServer"; OS = "Windows"; Memory = 4GB; CPU = 2; Disk = 60GB; ISO = "26100.32230.260111-0550.lt_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso" }
        @{ Name = "AuditLab-Ubuntu"; OS = "Linux"; Memory = 2GB; CPU = 2; Disk = 40GB; ISO = "ubuntu-24.04.3-live-server-amd64.iso" }
    )
    Standard = @(
        @{ Name = "AuditLab-WinServer"; OS = "Windows"; Memory = 4GB; CPU = 2; Disk = 60GB; ISO = "26100.32230.260111-0550.lt_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso" }
        @{ Name = "AuditLab-Ubuntu"; OS = "Linux"; Memory = 2GB; CPU = 2; Disk = 40GB; ISO = "ubuntu-24.04.3-live-server-amd64.iso" }
        @{ Name = "AuditLab-Debian"; OS = "Linux"; Memory = 2GB; CPU = 2; Disk = 40GB; ISO = "debian-edu-testing-amd64-netinst.iso" }
    )
    Full = @(
        @{ Name = "AuditLab-WinServer"; OS = "Windows"; Memory = 4GB; CPU = 2; Disk = 60GB; ISO = "26100.32230.260111-0550.lt_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso" }
        @{ Name = "AuditLab-Win11"; OS = "Windows"; Memory = 4GB; CPU = 2; Disk = 60GB; ISO = "Win11_25H2_English_x64.iso" }
        @{ Name = "AuditLab-Ubuntu"; OS = "Linux"; Memory = 2GB; CPU = 2; Disk = 40GB; ISO = "ubuntu-24.04.3-live-server-amd64.iso" }
        @{ Name = "AuditLab-Debian"; OS = "Linux"; Memory = 2GB; CPU = 2; Disk = 40GB; ISO = "debian-edu-testing-amd64-netinst.iso" }
        @{ Name = "AuditLab-WinServer19"; OS = "Windows"; Memory = 4GB; CPU = 2; Disk = 60GB; ISO = "17763.737.190906-2324.rs5_release_svc_refresh_SERVERESSENTIALS_OEM_x64FRE_en-us_1.iso" }
    )
}

# Color output helpers
function Write-Status { param($msg) Write-Host "[*] $msg" -ForegroundColor Cyan }
function Write-Success { param($msg) Write-Host "[+] $msg" -ForegroundColor Green }
function Write-LabWarning { param($msg) Write-Host "[!] $msg" -ForegroundColor Yellow }
function Write-LabError { param($msg) Write-Host "[-] $msg" -ForegroundColor Red }

function Test-Prerequisites {
    Write-Status "Checking prerequisites..."

    # Check Hyper-V
    $hyperv = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All
    if ($hyperv.State -ne "Enabled") {
        throw "Hyper-V is not enabled. Run: Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All"
    }

    # Check paths
    if (-not (Test-Path $VHDPath)) {
        New-Item -ItemType Directory -Path $VHDPath -Force | Out-Null
        Write-Status "Created VHD directory: $VHDPath"
    }

    Write-Success "Prerequisites OK"
}

function Get-LabVMList {
    param([Alias('Profile')][string]$LabProfileName = $LabProfile)

    if ($VMName -eq "All") {
        return $LabVMs[$LabProfileName]
    }
    else {
        return $LabVMs[$LabProfileName] | Where-Object { $_.Name -eq $VMName }
    }
}

function Show-VMList {
    Write-Status "Lab VMs Status"
    Write-Output ""

    $labVMNames = ($LabVMs.Full | ForEach-Object { $_.Name })
    $vms = Get-VM | Where-Object { $_.Name -in $labVMNames }

    if ($vms.Count -eq 0) {
        Write-LabWarning "No lab VMs found. Use -Action Create to create lab VMs."
        Write-Output ""
        Write-Output "Available profiles:"
        foreach ($labProfileName in $LabVMs.Keys) {
            Write-Output "  $labProfileName`:"
            foreach ($vm in $LabVMs[$labProfileName]) {
                Write-Output "    - $($vm.Name) ($($vm.OS), $($vm.Memory/1GB)GB RAM, $($vm.Disk/1GB)GB disk)"
            }
        }
        return
    }

    $vms | Format-Table @(
        @{L = 'Name'; E = { $_.Name } }
        @{L = 'State'; E = { $_.State } }
        @{L = 'CPU'; E = { $_.ProcessorCount } }
        @{L = 'Memory (GB)'; E = { [math]::Round($_.MemoryAssigned / 1GB, 1) } }
        @{L = 'Uptime'; E = { $_.Uptime } }
        @{L = 'IP Address'; E = { ($_ | Get-VMNetworkAdapter | Select-Object -First 1).IPAddresses -join ", " } }
    ) -AutoSize
}

function New-LabSwitch {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    $switch = Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue
    if (-not $switch) {
        Write-Status "Creating virtual switch: $SwitchName"
        if (-not $PSCmdlet.ShouldProcess($SwitchName, 'Create Hyper-V internal switch and configure NAT')) {
            return
        }

        New-VMSwitch -Name $SwitchName -SwitchType Internal | Out-Null

        # Configure NAT for internet access
        $adapter = Get-NetAdapter | Where-Object { $_.Name -like "*$SwitchName*" }
        if ($adapter) {
            New-NetIPAddress -IPAddress 192.168.100.1 -PrefixLength 24 -InterfaceIndex $adapter.ifIndex -ErrorAction SilentlyContinue
            New-NetNat -Name "AuditLabNAT" -InternalIPInterfaceAddressPrefix 192.168.100.0/24 -ErrorAction SilentlyContinue
        }
        Write-Success "Created switch with NAT (192.168.100.0/24)"
    }
    else {
        Write-Status "Using existing switch: $SwitchName"
    }
}

function New-LabVM {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param($VMDef)

    $name = $VMDef.Name
    $existing = Get-VM -Name $name -ErrorAction SilentlyContinue

    if ($existing) {
        Write-LabWarning "VM '$name' already exists, skipping"
        return
    }

    Write-Status "Creating VM: $name"

    if (-not $PSCmdlet.ShouldProcess($name, 'Create and configure lab VM')) {
        return
    }

    $vhdPath = Join-Path $VHDPath "$name.vhdx"
    $isoPath = Join-Path $ISOPath $VMDef.ISO

    # Create VM
    New-VM -Name $name `
        -MemoryStartupBytes $VMDef.Memory `
        -Generation 2 `
        -NewVHDPath $vhdPath `
        -NewVHDSizeBytes $VMDef.Disk `
        -SwitchName $SwitchName | Out-Null

    # Configure VM
    Set-VM -Name $name `
        -ProcessorCount $VMDef.CPU `
        -DynamicMemory `
        -MemoryMinimumBytes ($VMDef.Memory / 2) `
        -MemoryMaximumBytes ($VMDef.Memory * 2) `
        -AutomaticStartAction Nothing `
        -AutomaticStopAction ShutDown

    # Add DVD drive with ISO if exists
    if (Test-Path $isoPath) {
        Add-VMDvdDrive -VMName $name -Path $isoPath
        $dvd = Get-VMDvdDrive -VMName $name
        Set-VMFirmware -VMName $name -FirstBootDevice $dvd
        Write-Status "  Attached ISO: $($VMDef.ISO)"
    }
    else {
        Write-LabWarning "  ISO not found: $isoPath (VM created without boot media)"
    }

    # Disable Secure Boot for Linux
    if ($VMDef.OS -eq "Linux") {
        Set-VMFirmware -VMName $name -EnableSecureBoot Off
    }

    # Enable guest services
    Enable-VMIntegrationService -VMName $name -Name "Guest Service Interface"

    Write-Success "Created VM: $name"
}

function Start-LabVMs {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    $vms = Get-LabVMList
    foreach ($vmDef in $vms) {
        $vm = Get-VM -Name $vmDef.Name -ErrorAction SilentlyContinue
        if ($vm) {
            if ($vm.State -eq "Off") {
                Write-Status "Starting: $($vmDef.Name)"
                if ($PSCmdlet.ShouldProcess($vmDef.Name, 'Start VM')) {
                    Start-VM -Name $vmDef.Name
                    Write-Success "Started: $($vmDef.Name)"
                }
            }
            else {
                Write-Status "$($vmDef.Name) is already $($vm.State)"
            }
        }
        else {
            Write-LabWarning "VM not found: $($vmDef.Name)"
        }
    }
}

function Stop-LabVMs {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param()

    $vms = Get-LabVMList
    foreach ($vmDef in $vms) {
        $vm = Get-VM -Name $vmDef.Name -ErrorAction SilentlyContinue
        if ($vm -and $vm.State -eq "Running") {
            Write-Status "Stopping: $($vmDef.Name)"
            if ($PSCmdlet.ShouldProcess($vmDef.Name, 'Stop running VM')) {
                Stop-VM -Name $vmDef.Name -Force
                Write-Success "Stopped: $($vmDef.Name)"
            }
        }
    }
}

function Remove-LabVMs {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param()

    $vms = Get-LabVMList
    foreach ($vmDef in $vms) {
        $vm = Get-VM -Name $vmDef.Name -ErrorAction SilentlyContinue
        if ($vm) {
            Write-Status "Removing: $($vmDef.Name)"
            if (-not $PSCmdlet.ShouldProcess($vmDef.Name, 'Stop and remove VM plus VHD')) {
                continue
            }
            if ($vm.State -ne "Off") {
                Stop-VM -Name $vmDef.Name -Force -TurnOff
            }
            Remove-VM -Name $vmDef.Name -Force

            # Remove VHD
            $vhdPath = Join-Path $VHDPath "$($vmDef.Name).vhdx"
            if (Test-Path $vhdPath) {
                Remove-Item $vhdPath -Force
            }
            Write-Success "Removed: $($vmDef.Name)"
        }
    }
}

function New-LabSnapshot {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([string]$SnapshotName = "AuditTest-$(Get-Date -Format 'yyyyMMdd-HHmm')")

    $vms = Get-LabVMList
    foreach ($vmDef in $vms) {
        $vm = Get-VM -Name $vmDef.Name -ErrorAction SilentlyContinue
        if ($vm) {
            Write-Status "Creating snapshot: $($vmDef.Name) -> $SnapshotName"
            if ($PSCmdlet.ShouldProcess($vmDef.Name, "Create snapshot $SnapshotName")) {
                Checkpoint-VM -Name $vmDef.Name -SnapshotName $SnapshotName
                Write-Success "Snapshot created"
            }
        }
    }
}

function Restore-LabSnapshot {
    param([string]$SnapshotName)

    if (-not $SnapshotName) {
        # List available snapshots
        $vms = Get-LabVMList
        foreach ($vmDef in $vms) {
            $snapshots = Get-VMSnapshot -VMName $vmDef.Name -ErrorAction SilentlyContinue
            if ($snapshots) {
                Write-Output "`n$($vmDef.Name) snapshots:"
                $snapshots | Format-Table Name, CreationTime -AutoSize
            }
        }
        return
    }

    $vms = Get-LabVMList
    foreach ($vmDef in $vms) {
        $snapshot = Get-VMSnapshot -VMName $vmDef.Name -Name $SnapshotName -ErrorAction SilentlyContinue
        if ($snapshot) {
            Write-Status "Restoring: $($vmDef.Name) -> $SnapshotName"
            Restore-VMSnapshot -VMName $vmDef.Name -Name $SnapshotName -Confirm:$false
            Write-Success "Restored"
        }
    }
}

function Invoke-AuditTest {
    Write-Status "Running Audit Toolkit tests against lab VMs..."

    $results = @()
    # Get running VMs
    $labVMNames = ($LabVMs.Full | ForEach-Object { $_.Name })
    $runningVMs = Get-VM | Where-Object { $_.Name -in $labVMNames -and $_.State -eq "Running" }

    if ($runningVMs.Count -eq 0) {
        Write-LabWarning "No lab VMs are running. Start VMs first with -Action Start"
        return
    }

    foreach ($vm in $runningVMs) {
        $vmDef = $LabVMs.Full | Where-Object { $_.Name -eq $vm.Name }
        $ip = ($vm | Get-VMNetworkAdapter | Select-Object -First 1).IPAddresses | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' } | Select-Object -First 1

        if (-not $ip) {
            Write-LabWarning "$($vm.Name): No IP address assigned yet"
            continue
        }

        Write-Status "Testing: $($vm.Name) ($ip)"

        $result = @{
            VMName    = $vm.Name
            OS        = $vmDef.OS
            IPAddress = $ip
            Tests     = @()
            Status    = "Unknown"
        }

        # Test connectivity
        if (Test-Connection -ComputerName $ip -Count 1 -Quiet) {
            $result.Tests += @{ Name = "Ping"; Status = "Pass" }

            if ($vmDef.OS -eq "Windows") {
                # Test WinRM
                $winrm = Test-WSMan -ComputerName $ip -ErrorAction SilentlyContinue
                $result.Tests += @{ Name = "WinRM"; Status = if ($winrm) { "Pass" } else { "Fail" } }

                # Run Windows audits if WinRM works
                if ($winrm) {
                    Write-Status "  Running Windows audits..."
                    # TODO: Invoke-Command to run audits
                    $result.Tests += @{ Name = "WindowsAudits"; Status = "Pending" }
                }
            }
            else {
                # Test SSH (Linux)
                $ssh = Test-NetConnection -ComputerName $ip -Port 22 -WarningAction SilentlyContinue
                $result.Tests += @{ Name = "SSH"; Status = if ($ssh.TcpTestSucceeded) { "Pass" } else { "Fail" } }

                if ($ssh.TcpTestSucceeded) {
                    Write-Status "  SSH available - ready for Linux audits"
                    $result.Tests += @{ Name = "LinuxAudits"; Status = "Ready" }
                }
            }

            $result.Status = "Reachable"
        }
        else {
            $result.Tests += @{ Name = "Ping"; Status = "Fail" }
            $result.Status = "Unreachable"
        }

        $results += $result
    }

    # Display results
    Write-Output "`n========== Test Results ==========`n"
    foreach ($r in $results) {
        Write-Output "$($r.VMName) [$($r.OS)]"
        Write-Output "  IP: $($r.IPAddress)"
        foreach ($test in $r.Tests) {
            Write-Output "  - $($test.Name): "
            Write-Output $test.Status
        }
        Write-Output ""
    }
}

# Main execution
try {
    if ($Action -ne "List" -and $Action -ne "Status") {
        Test-Prerequisites
    }

    switch ($Action) {
        "List" { Show-VMList }
        "Status" { Show-VMList }
        "Create" {
            New-LabSwitch
            $vms = Get-LabVMList
            foreach ($vmDef in $vms) {
                New-LabVM -VMDef $vmDef
            }
            Write-Success "`nLab VMs created. Use -Action Start to boot them."
        }
        "Start" { Start-LabVMs }
        "Stop" { Stop-LabVMs }
        "Destroy" {
            $confirm = Read-Host "This will DELETE all lab VMs and their disks. Type 'yes' to confirm"
            if ($confirm -eq "yes") {
                Remove-LabVMs
            }
            else {
                Write-LabWarning "Cancelled"
            }
        }
        "Snapshot" { New-LabSnapshot }
        "Restore" { Restore-LabSnapshot }
        "Test" { Invoke-AuditTest }
    }
}
catch {
    Write-LabError "Error: $_"
    exit 1
}

