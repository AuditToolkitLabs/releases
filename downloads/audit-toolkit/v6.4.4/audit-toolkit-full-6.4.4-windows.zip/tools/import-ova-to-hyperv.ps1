<#
.SYNOPSIS
    Imports an OVA appliance into Hyper-V with automatic sparse/compression remediation.

.DESCRIPTION
    Extracts OVA payload, converts VMDK to VHDX, clears sparse/compression flags that can
    block Hyper-V boot, creates a Generation 2 VM, and optionally starts it.

.PARAMETER OVAPath
    Path to the OVA file.

.PARAMETER VMName
    Target Hyper-V VM name.

.PARAMETER SwitchName
    Hyper-V virtual switch name.

.PARAMETER VHDStoragePath
    Directory where the converted VHDX will be written.

.PARAMETER MemoryGB
    Startup memory for VM in GB.

.PARAMETER CPUCount
    Number of vCPUs.

.PARAMETER TempPath
    Optional extraction directory. If omitted, a temp folder is created.

.PARAMETER Force
    Remove existing VM and target VHDX if present.

.PARAMETER StartVM
    Start the VM after creation. Default: true.

.PARAMETER KeepExtracted
    Keep extracted OVA contents.
#>

#Requires -RunAsAdministrator
#Requires -Version 5.1

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$OVAPath = "deployment/vm-appliance/output/security-audit-toolkit-6.0.0.ova",

    [Parameter()]
    [string]$VMName = "AuditToolkit-OVA-Verify",

    [Parameter()]
    [string]$SwitchName = "AuditLabSwitch",

    [Parameter()]
    [string]$VHDStoragePath = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [int]$MemoryGB = 4,

    [Parameter()]
    [int]$CPUCount = 2,

    [Parameter()]
    [string]$TempPath = "",

    [Parameter()]
    [switch]$Force,

    [Parameter()]
    [bool]$StartVM = $true,

    [Parameter()]
    [switch]$KeepExtracted
)

$ErrorActionPreference = "Stop"

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }

function Resolve-NormalizedPath {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $candidate = $PathValue.Replace('/', '\\')
    return [System.IO.Path]::GetFullPath($candidate)
}

function Get-QemuImgPath {
    foreach ($candidate in @("C:\Program Files\qemu\qemu-img.exe", "C:\Program Files (x86)\qemu\qemu-img.exe")) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    $command = Get-Command qemu-img -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }

    throw "qemu-img executable not found. Install QEMU and retry."
}

function Clear-VhdxFlags {
    param([Parameter(Mandatory = $true)][string]$Path)

    compact /U $Path | Out-Null
    fsutil sparse setflag $Path 0 | Out-Null
}

function Test-VhdxIsHyperVReady {
    param([Parameter(Mandatory = $true)][string]$Path)

    $item = Get-Item -LiteralPath $Path -ErrorAction Stop
    $attributes = $item.Attributes.ToString().Split(',').ForEach({ $_.Trim() })
    $isCompressed = $attributes -contains "Compressed"
    $isSparse = $attributes -contains "SparseFile"

    return (-not $isCompressed) -and (-not $isSparse)
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$resolvedOvaPath = if ([System.IO.Path]::IsPathRooted($OVAPath)) {
    Resolve-NormalizedPath -PathValue $OVAPath
} else {
    Resolve-NormalizedPath -PathValue (Join-Path $repoRoot $OVAPath)
}

if (-not (Test-Path $resolvedOvaPath)) {
    throw "OVA file not found: $resolvedOvaPath"
}

$resolvedVhdStoragePath = Resolve-NormalizedPath -PathValue $VHDStoragePath
if (-not (Test-Path $resolvedVhdStoragePath)) {
    New-Item -ItemType Directory -Path $resolvedVhdStoragePath -Force | Out-Null
}

$resolvedTempPath = if ($TempPath) {
    Resolve-NormalizedPath -PathValue $TempPath
} else {
    Join-Path ([System.IO.Path]::GetTempPath()) ("audittoolkit-ova-import-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
}

if (-not (Test-Path $resolvedTempPath)) {
    New-Item -ItemType Directory -Path $resolvedTempPath -Force | Out-Null
}

$targetVhdxPath = Join-Path $resolvedVhdStoragePath "$VMName.vhdx"

Write-Output ""
Write-Output "=== OVA to Hyper-V Import ==="
Write-Output "OVA:      $resolvedOvaPath"
Write-Output "VM Name:  $VMName"
Write-Output "Switch:   $SwitchName"
Write-Output "VHDX:     $targetVhdxPath"
Write-Output "Temp:     $resolvedTempPath"
Write-Output ""

$existingVm = Get-VM -Name $VMName -ErrorAction SilentlyContinue
if ($existingVm) {
    if (-not $Force) {
        throw "VM '$VMName' already exists. Use -Force to replace it."
    }

    Write-Warn "Removing existing VM: $VMName"
    if ($existingVm.State -ne "Off") {
        Stop-VM -Name $VMName -Force -ErrorAction SilentlyContinue | Out-Null
    }
    Remove-VM -Name $VMName -Force -ErrorAction Stop
}

if ((Test-Path $targetVhdxPath) -and -not $Force) {
    throw "Target VHDX already exists: $targetVhdxPath (use -Force to overwrite)"
}

if (Test-Path $targetVhdxPath) {
    Remove-Item -LiteralPath $targetVhdxPath -Force -ErrorAction SilentlyContinue
}

Write-Step "Extracting OVA"
& C:\Windows\System32\tar.exe -xf $resolvedOvaPath -C $resolvedTempPath

$sourceVmdk = Get-ChildItem -Path $resolvedTempPath -Filter *.vmdk -File -ErrorAction Stop | Select-Object -First 1
if (-not $sourceVmdk) {
    throw "No VMDK found in extracted OVA payload: $resolvedTempPath"
}
Write-Ok "Source VMDK: $($sourceVmdk.FullName)"

$qemuImg = Get-QemuImgPath
Write-Step "Converting VMDK to VHDX"
& $qemuImg convert -f vmdk -O vhdx -o subformat=dynamic $sourceVmdk.FullName $targetVhdxPath
if ($LASTEXITCODE -ne 0) {
    throw "qemu-img conversion failed with exit code $LASTEXITCODE"
}

Write-Step "Clearing sparse/compression flags"
Clear-VhdxFlags -Path $targetVhdxPath

if (-not (Test-VhdxIsHyperVReady -Path $targetVhdxPath)) {
    Write-Warn "VHDX still not Hyper-V ready after initial flag clear; attempting secondary conversion"

    $sanitizedPath = Join-Path $resolvedVhdStoragePath "$VMName-sanitized.vhdx"
    if (Test-Path $sanitizedPath) {
        Remove-Item -LiteralPath $sanitizedPath -Force -ErrorAction SilentlyContinue
    }

    Convert-VHD -Path $targetVhdxPath -DestinationPath $sanitizedPath -VHDType Dynamic -ErrorAction Stop
    Clear-VhdxFlags -Path $sanitizedPath

    if (-not (Test-VhdxIsHyperVReady -Path $sanitizedPath)) {
        throw "Unable to produce a non-sparse, uncompressed VHDX for Hyper-V boot."
    }

    Remove-Item -LiteralPath $targetVhdxPath -Force
    Move-Item -LiteralPath $sanitizedPath -Destination $targetVhdxPath -Force
}

Write-Ok "VHDX ready for Hyper-V: $targetVhdxPath"

Write-Step "Creating Hyper-V VM"
New-VM -Name $VMName -Generation 2 -MemoryStartupBytes ($MemoryGB * 1GB) -VHDPath $targetVhdxPath -SwitchName $SwitchName | Out-Null
Set-VM -Name $VMName -ProcessorCount $CPUCount -AutomaticStartAction Nothing -AutomaticStopAction ShutDown | Out-Null
Set-VMFirmware -VMName $VMName -EnableSecureBoot Off

if ($StartVM) {
    Start-VM -Name $VMName | Out-Null
    Start-Sleep -Seconds 5
}

$vmState = (Get-VM -Name $VMName -ErrorAction Stop).State
Write-Ok "VM created: $VMName (State: $vmState)"

if (-not $KeepExtracted) {
    Remove-Item -LiteralPath $resolvedTempPath -Recurse -Force -ErrorAction SilentlyContinue
    Write-Step "Cleaned extraction directory"
}

Write-Output ""
Write-Output "✅ OVA import completed."


