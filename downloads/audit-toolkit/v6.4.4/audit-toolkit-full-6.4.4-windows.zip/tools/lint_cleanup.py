#!/usr/bin/env python3
"""
Lint Cleanup Script for Security Audit Toolkit

Automatically fixes common lint issues:
- W293: blank line contains whitespace
- W291: trailing whitespace
- W292: no newline at end of file
- E302: expected 2 blank lines, found 1
- E303: too many blank lines
- E301: expected 1 blank line, found 0
- F541: f-string is missing placeholders (converts to regular string)

Usage:
    python tools/lint_cleanup.py [--dry-run] [--path web/]
"""

import re
import sys
import argparse
from pathlib import Path
from typing import Tuple


def fix_trailing_whitespace(content: str) -> Tuple[str, int]:
    """Remove trailing whitespace from all lines."""
    lines = content.split('\n')
    fixed_lines = []
    count = 0

    for line in lines:
        stripped = line.rstrip()
        if stripped != line:
            count += 1
        fixed_lines.append(stripped)

    return '\n'.join(fixed_lines), count


def fix_blank_line_whitespace(content: str) -> Tuple[str, int]:
    """Remove whitespace from blank lines."""
    lines = content.split('\n')
    fixed_lines = []
    count = 0

    for line in lines:
        if line.strip() == '' and line != '':
            count += 1
            fixed_lines.append('')
        else:
            fixed_lines.append(line)

    return '\n'.join(fixed_lines), count


def fix_missing_blank_lines(content: str) -> Tuple[str, int]:
    """Add blank lines before function/class definitions (E302)."""
    lines = content.split('\n')
    fixed_lines = []
    count = 0

    for i, line in enumerate(lines):
        # Check if this is a top-level function or class definition
        stripped = line.lstrip()
        indent = len(line) - len(stripped)

        if stripped.startswith(('def ', 'class ', 'async def ')):
            # Count preceding blank lines
            blank_count = 0
            j = len(fixed_lines) - 1
            while j >= 0 and fixed_lines[j].strip() == '':
                blank_count += 1
                j -= 1

            # Top-level definitions need 2 blank lines
            if indent == 0 and i > 0:
                if blank_count < 2 and j >= 0:
                    # Add missing blank lines
                    needed = 2 - blank_count
                    for _ in range(needed):
                        fixed_lines.append('')
                        count += 1
            # Method definitions inside class need 1 blank line
            elif indent > 0 and stripped.startswith('def '):
                if blank_count < 1 and j >= 0 and not fixed_lines[j].strip().endswith(':'):
                    fixed_lines.append('')
                    count += 1

        fixed_lines.append(line)

    return '\n'.join(fixed_lines), count


def fix_too_many_blank_lines(content: str) -> Tuple[str, int]:
    """Reduce more than 2 consecutive blank lines to 2 (E303)."""
    lines = content.split('\n')
    fixed_lines = []
    blank_count = 0
    count = 0

    for line in lines:
        if line.strip() == '':
            blank_count += 1
            if blank_count <= 2:
                fixed_lines.append(line)
            else:
                count += 1
        else:
            blank_count = 0
            fixed_lines.append(line)

    return '\n'.join(fixed_lines), count


def fix_fstring_no_placeholders(content: str) -> Tuple[str, int]:
    """Convert f-strings without placeholders to regular strings (F541)."""
    # Match f-strings that don't contain { }
    pattern = r'\bf(["\'])([^{}\'"]*)\1'

    def replacer(match):
        quote = match.group(1)
        string_content = match.group(2)
        return f'{quote}{string_content}{quote}'

    new_content, count = re.subn(pattern, replacer, content)
    return new_content, count


def fix_comparison_to_true(content: str) -> Tuple[str, int]:
    """Fix comparisons like '== True' to 'is True' (E712)."""
    count = 0

    # Fix is True
    new_content, n = re.subn(r'\s+==\s+True\b', ' is True', content)
    count += n

    # Fix is False
    new_content, n = re.subn(r'\s+==\s+False\b', ' is False', new_content)
    count += n

    # Fix is not True
    new_content, n = re.subn(r'\s+!=\s+True\b', ' is not True', new_content)
    count += n

    # Fix is not False
    new_content, n = re.subn(r'\s+!=\s+False\b', ' is not False', new_content)
    count += n

    return new_content, count


def fix_newline_at_end(content: str) -> Tuple[str, int]:
    """Ensure file ends with exactly one newline (W292)."""
    if not content.endswith('\n'):
        return content + '\n', 1

    # Remove multiple trailing newlines
    stripped = content.rstrip('\n')
    if stripped != content[:-1]:
        return stripped + '\n', 1

    return content, 0


def process_file(filepath: Path, dry_run: bool = False) -> dict:
    """Process a single file and return fix counts."""
    stats = {
        'trailing_whitespace': 0,
        'blank_line_whitespace': 0,
        'missing_blank_lines': 0,
        'too_many_blank_lines': 0,
        'fstring_no_placeholders': 0,
        'comparison_to_true': 0,
        'newline_at_end': 0,
    }

    try:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
    except Exception as e:
        print(f"  Error reading {filepath}: {e}")
        return stats

    original = content

    # Apply fixes in order
    content, count = fix_blank_line_whitespace(content)
    stats['blank_line_whitespace'] = count

    content, count = fix_trailing_whitespace(content)
    stats['trailing_whitespace'] = count

    content, count = fix_too_many_blank_lines(content)
    stats['too_many_blank_lines'] = count

    content, count = fix_fstring_no_placeholders(content)
    stats['fstring_no_placeholders'] = count

    content, count = fix_comparison_to_true(content)
    stats['comparison_to_true'] = count

    content, count = fix_newline_at_end(content)
    stats['newline_at_end'] = count

    # Write if changed and not dry run
    if content != original:
        if not dry_run:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)

    return stats


def main():
    parser = argparse.ArgumentParser(description='Fix common lint issues')
    parser.add_argument('--dry-run', action='store_true',
                       help='Show what would be fixed without making changes')
    parser.add_argument('--path', default='.',
                       help='Path to process (default: current directory)')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Show per-file details')

    args = parser.parse_args()

    base_path = Path(args.path)
    if not base_path.exists():
        print(f"Error: Path {base_path} does not exist")
        sys.exit(1)

    # Find all Python files
    if base_path.is_file():
        py_files = [base_path]
    else:
        py_files = list(base_path.rglob('*.py'))
        # Exclude common directories
        py_files = [f for f in py_files if not any(
            part in f.parts for part in ['__pycache__', '.venv', 'venv', 'node_modules', '.git']
        )]

    print(f"{'[DRY RUN] ' if args.dry_run else ''}Processing {len(py_files)} Python files...")
    print()

    totals = {
        'trailing_whitespace': 0,
        'blank_line_whitespace': 0,
        'missing_blank_lines': 0,
        'too_many_blank_lines': 0,
        'fstring_no_placeholders': 0,
        'comparison_to_true': 0,
        'newline_at_end': 0,
    }
    files_modified = 0

    for filepath in sorted(py_files):
        stats = process_file(filepath, args.dry_run)

        file_total = sum(stats.values())
        if file_total > 0:
            files_modified += 1
            if args.verbose:
                print(f"  {filepath}: {file_total} fixes")

        for key in totals:
            totals[key] += stats[key]

    print()
    print("=" * 60)
    print("LINT CLEANUP SUMMARY")
    print("=" * 60)
    print(f"Files processed:     {len(py_files)}")
    print(f"Files modified:      {files_modified}")
    print()
    print("Fixes by category:")
    print(f"  Blank line whitespace (W293):  {totals['blank_line_whitespace']:,}")
    print(f"  Trailing whitespace (W291):    {totals['trailing_whitespace']:,}")
    print(f"  Too many blank lines (E303):   {totals['too_many_blank_lines']:,}")
    print(f"  F-string no placeholders:      {totals['fstring_no_placeholders']:,}")
    print(f"  Comparison to True (E712):     {totals['comparison_to_true']:,}")
    print(f"  Newline at end (W292):         {totals['newline_at_end']:,}")
    print()
    print(f"Total fixes: {sum(totals.values()):,}")

    if args.dry_run:
        print()
        print("Run without --dry-run to apply fixes")


if __name__ == '__main__':
    main()
