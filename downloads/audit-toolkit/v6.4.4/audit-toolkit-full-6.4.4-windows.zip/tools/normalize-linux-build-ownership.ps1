[CmdletBinding()]
param(
    [string]$RepoRoot = (Split-Path -Parent $PSScriptRoot),
    [string[]]$RelativePaths = @(
        "deployment/linux/build",
        "deployment/linux/bin",
        "artifacts",
        ".build-tmp"
    )
)

$ErrorActionPreference = 'Stop'

function Write-Info {
    param([string]$Message)
    Write-Output "[INFO] $Message"
}

function Write-Success {
    param([string]$Message)
    Write-Output "[OK] $Message"
}

function ConvertTo-BashLiteral {
    param([Parameter(Mandatory = $true)][string]$Value)
    $parts = $Value -split "'", -1
    if ($parts.Count -le 1) {
        return "'$Value'"
    }

    $delimiter = "'" + '"' + "'" + '"' + "'"
    return "'" + ($parts -join $delimiter) + "'"
}

if (-not (Get-Command wsl -ErrorAction SilentlyContinue)) {
    throw "WSL command not found. Install/enable WSL before running Linux packaging tasks."
}

$resolvedRepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
Write-Info "Repository root: $resolvedRepoRoot"

$repoRootForWslPath = $resolvedRepoRoot -replace '\\', '/'
$repoRootLinuxRaw = & wsl -- wslpath -a $repoRootForWslPath
if ($LASTEXITCODE -ne 0 -or -not $repoRootLinuxRaw) {
    throw "Failed to resolve WSL path for repository root: $resolvedRepoRoot"
}

$repoRootLinux = ($repoRootLinuxRaw | Select-Object -First 1).Trim()
if ([string]::IsNullOrWhiteSpace($repoRootLinux)) {
    throw "Failed to resolve WSL path for repository root: $resolvedRepoRoot"
}

$uid = (& wsl -- id -u).Trim()
$gid = (& wsl -- id -g).Trim()
if ([string]::IsNullOrWhiteSpace($uid) -or [string]::IsNullOrWhiteSpace($gid)) {
    throw "Failed to determine default WSL user uid/gid."
}

$linuxTargets = foreach ($relativePath in $RelativePaths) {
    if ([string]::IsNullOrWhiteSpace($relativePath)) {
        continue
    }

    $normalizedRelativePath = $relativePath.Replace('\\', '/').TrimStart('/')
    "$repoRootLinux/$normalizedRelativePath"
}

if (-not $linuxTargets -or $linuxTargets.Count -eq 0) {
    throw "No target paths were provided for ownership normalization."
}

Write-Info "Normalizing WSL ownership to uid:gid ${uid}:$gid"

foreach ($target in $linuxTargets) {
    $targetLiteral = ConvertTo-BashLiteral $target
    $rootCommand = "set -euo pipefail; mkdir -p $targetLiteral; for _i in 1 2 3; do chown -R ${uid}:$gid $targetLiteral 2>/dev/null && break || true; sleep 0.2; done; chown -R ${uid}:$gid $targetLiteral 2>/dev/null || true; find $targetLiteral -type d -exec chmod u+rwx {} + 2>/dev/null || true; find $targetLiteral -type f -exec chmod u+rw {} + 2>/dev/null || true"
    & wsl -u root -- bash -lc $rootCommand
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to normalize ownership for target path: $target"
    }
}

foreach ($target in $linuxTargets) {
    $targetLiteral = ConvertTo-BashLiteral $target
    & wsl -- bash -lc "set -euo pipefail; mkdir -p $targetLiteral; test -w $targetLiteral"
    if ($LASTEXITCODE -ne 0) {
        throw "Ownership normalization completed, but target path is still not writable: $target"
    }
}

Write-Success "WSL Linux packaging paths are writable for the default user."
foreach ($target in $linuxTargets) {
    Write-Output "  - $target"
}
