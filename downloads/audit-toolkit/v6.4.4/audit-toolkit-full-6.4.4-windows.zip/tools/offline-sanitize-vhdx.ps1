<#
.SYNOPSIS
    Offline disk sanitize for appliance VHDX/OVA artifacts.

.DESCRIPTION
    Mounts the Hyper-V VHDX (or the VHDX inside a freshly-extracted OVA) via WSL --mount,
    then directly edits the Linux filesystem to:
      - Reset hostname to 'audit-toolkit'
      - Clear all first-boot completion markers
      - Replace netplan with a clean DHCP-only baseline (no static IPs)
      - Rebuild the first-login wizard with interactive DHCP/static/hostname/password prompts
      - Install the first-boot profile hook that launches the wizard on first login
      - Scrub all 192.168.x.x lab IP addresses from app env files
      - Cloud-init cache clear
    This approach makes the OVA build independent of the guest OS being reachable via SSH.

.PARAMETER VHDXPath
    Path to the VHDX to sanitize. Mutually exclusive with OVA package path.

.PARAMETER OVAPath
    Path to an OVA file. If specified the script extracts the VMDK, converts to VHDX,
    sanitizes, repacks OVA, and leaves the original untouched.

.PARAMETER MountPoint
    WSL mount-point to use (default: /mnt/offlineaudit).

.PARAMETER ShouldRepackOva
    If -OVAPath was given, repack after sanitization. Default: true.

.EXAMPLE
    # Sanitize a standalone VHDX
    .\tools\offline-sanitize-vhdx.ps1 -VHDXPath 'C:\Hyper-V\Virtual Hard Disks\AuditToolkit-Appliance-Base.vhdx'

.EXAMPLE
    # Sanitize the built OVA end-to-end (extracts, sanitizes, repacks)
    .\tools\offline-sanitize-vhdx.ps1 -OVAPath '.\deployment\vm-appliance\output\security-audit-toolkit-6.0.0.ova'
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [Parameter(ParameterSetName = 'vhdx')]
    [string]$VHDXPath = "",

    [Parameter(ParameterSetName = 'ova')]
    [string]$OVAPath = "",

    [Parameter()]
    [string]$MountPoint = "/mnt/offlineaudit",

    [Parameter()]
    [bool]$ShouldRepackOva = $true,

    [Parameter()]
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot   = Split-Path -Parent $ScriptRoot

function Write-Step { param([string]$m) Write-Host "[*] $m" -ForegroundColor Cyan }
function Write-Ok   { param([string]$m) Write-Host "[OK] $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "[!] $m" -ForegroundColor Yellow }
function Write-Fail { param([string]$m) Write-Host "[-] $m" -ForegroundColor Red }

function Get-QemuImgPath {
    foreach ($c in @("C:\Program Files\qemu\qemu-img.exe","C:\Program Files (x86)\qemu\qemu-img.exe")) {
        if (Test-Path $c) { return $c }
    }
    $cmd = Get-Command qemu-img -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw "qemu-img not found. Install QEMU for Windows."
}

function Invoke-Wsl {
    param([string]$Script)
    wsl.exe -u root -e sh -lc $Script
    if ($LASTEXITCODE -ne 0) {
        throw "WSL command exited $LASTEXITCODE"
    }
}

# ─── resolve VHDX ────────────────────────────────────────────────────────────
$resolvedVhdx = ""
$tempDir      = ""
$sourceOva    = ""

if ($PSCmdlet.ParameterSetName -eq 'ova') {
    if (-not [System.IO.Path]::IsPathRooted($OVAPath)) {
        $OVAPath = [System.IO.Path]::GetFullPath((Join-Path $RepoRoot $OVAPath))
    }
    if (-not (Test-Path $OVAPath)) { throw "OVA not found: $OVAPath" }
    $sourceOva = $OVAPath

    Write-Step "Extracting OVA: $OVAPath"
    $tempDir = Join-Path ([System.IO.Path]::GetTempPath()) "offline-sanitize-$(Get-Date -Format yyyyMMddHHmmss)"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    & tar -xf $OVAPath -C $tempDir
    if ($LASTEXITCODE -ne 0) { throw "OVA extraction failed" }

    $vmdkFile = Get-ChildItem -Path $tempDir -Filter "*.vmdk" | Select-Object -First 1
    if (-not $vmdkFile) { throw "No VMDK found inside OVA" }

    Write-Step "Converting VMDK → VHDX"
    $qemuImg  = Get-QemuImgPath
    $vhdxFile = Join-Path $tempDir "sanitize-work.vhdx"
    & $qemuImg convert -f vmdk -O vhdx $vmdkFile.FullName $vhdxFile
    if ($LASTEXITCODE -ne 0) { throw "VMDK→VHDX conversion failed" }
    $resolvedVhdx = $vhdxFile
} else {
    if (-not [System.IO.Path]::IsPathRooted($VHDXPath)) {
        $VHDXPath = [System.IO.Path]::GetFullPath((Join-Path $RepoRoot $VHDXPath))
    }
    if (-not (Test-Path $VHDXPath)) { throw "VHDX not found: $VHDXPath" }
    $resolvedVhdx = $VHDXPath
}

Write-Step "Mounting VHDX in WSL: $resolvedVhdx"
# WSL --unmount requires the \\?\ UNC-style path for paths that may contain spaces
$wslVhdxPath = "\\?\$resolvedVhdx"
wsl.exe --mount --vhd $wslVhdxPath --bare
if ($LASTEXITCODE -ne 0) {
    # Fallback: try without \\?\ prefix
    wsl.exe --mount --vhd $resolvedVhdx --bare
    if ($LASTEXITCODE -ne 0) { throw "WSL VHD mount failed" }
    $wslVhdxPath = $resolvedVhdx
}
Start-Sleep -Seconds 5

try {
    # identify the LVM volume group and resolve /dev/mapper
    $lv = wsl.exe -u root -e sh -lc "ls /dev/mapper | grep -v 'control' | tail -n 1" 2>$null
    $lv = $lv.Trim()
    if (-not $lv) { throw "No LVM volume found in /dev/mapper" }
    Write-Ok "Resolved LVM volume: /dev/mapper/$lv"

    $mountTarget = $MountPoint
    if ($WhatIf) {
        Write-Warn "(-WhatIf) Would mount /dev/mapper/$lv → $mountTarget and apply sanitization"
    } else {
        Write-Step "Mounting root filesystem"
        Invoke-Wsl "mkdir -p $mountTarget && mount /dev/mapper/$lv $mountTarget"
        Write-Ok "Mounted at $mountTarget"

        # ── Steps 1-8: delegate to external bash helper (avoids PowerShell/WSL heredoc quoting issues) ──
        $helperSrc = Join-Path $ScriptRoot "sanitize-vhdx-helper.sh"
        if (-not (Test-Path $helperSrc)) {
            throw "Helper script not found: $helperSrc`nExpected at tools/sanitize-vhdx-helper.sh"
        }
        # Convert Windows path C:\foo\bar.sh → /mnt/c/foo/bar.sh for WSL
        $driveLetter = $helperSrc[0].ToString().ToLower()
        $helperWsl   = "/mnt/$driveLetter" + ($helperSrc.Substring(2) -replace '\\', '/')

        Write-Step "Running sanitization helper: $helperSrc"
        wsl.exe -u root -e bash -c "sed 's/\r//' '$helperWsl' | MOUNT_TARGET='$mountTarget' bash"
        if ($LASTEXITCODE -ne 0) { throw "Sanitization helper failed (exit $LASTEXITCODE)" }
        Write-Ok "Offline sanitization verified clean"

        # ── Unmount ───────────────────────────────────────────────────────────
        Write-Step "Unmounting filesystem"
        Invoke-Wsl "umount $mountTarget 2>/dev/null || true"
    }
}
finally {
    Write-Step "Detaching VHDX from WSL"
    # WSL detach uses: wsl --unmount <disk-path>
    # The plain Windows path works reliably here even when mount used --vhd.
    wsl.exe --unmount $resolvedVhdx 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "WSL detach reported exit code $LASTEXITCODE for $resolvedVhdx"
    }
    Start-Sleep -Seconds 3
}

# ── Repack to OVA if operating on extracted OVA ──────────────────────────────
if ($PSCmdlet.ParameterSetName -eq 'ova' -and $ShouldRepackOva -and -not $WhatIf) {
    Write-Step "Converting sanitized VHDX back to VMDK"
    $qemuImg     = Get-QemuImgPath
    $ovaDir      = Split-Path -Parent $sourceOva
    $baseOvaName = [System.IO.Path]::GetFileNameWithoutExtension($sourceOva)
    $vmdkOut     = Join-Path $tempDir "$baseOvaName.vmdk"

    & $qemuImg convert -f vhdx -O vmdk -o subformat=streamOptimized $resolvedVhdx $vmdkOut
    if ($LASTEXITCODE -ne 0) { throw "VHDX→VMDK reconversion failed" }

    Write-Step "Repacking OVA"
    Join-Path $tempDir "$baseOvaName.ovf" | Out-Null
    $mfSrc  = Join-Path $tempDir "$baseOvaName.mf"

    # Update manifest SHA256 for repacked VMDK
    $sha256 = (Get-FileHash $vmdkOut -Algorithm SHA256).Hash.ToLower()
    if (Test-Path $mfSrc) {
        (Get-Content $mfSrc) -replace 'SHA256\([^)]+\) = [0-9a-f]+', "SHA256($baseOvaName.vmdk) = $sha256" |
            Set-Content $mfSrc -Encoding UTF8
    }

    $ovaOut    = Join-Path $ovaDir "$baseOvaName.ova"
    $tarArgs   = [System.Collections.Generic.List[string]]@("-cf", $ovaOut, "$baseOvaName.ovf", "$baseOvaName.vmdk")
    if (Test-Path $mfSrc) { $tarArgs.Add("$baseOvaName.mf") }
    Push-Location $tempDir
    & tar @tarArgs
    Pop-Location
    if ($LASTEXITCODE -ne 0) { throw "OVA repack failed" }

    Write-Ok "Sanitized OVA saved: $ovaOut"
}

if ($tempDir -and (Test-Path $tempDir)) {
    Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}

Write-Ok "Offline sanitization complete."


