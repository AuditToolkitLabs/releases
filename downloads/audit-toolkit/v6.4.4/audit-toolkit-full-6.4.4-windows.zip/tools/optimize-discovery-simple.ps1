# Simple optimization script for discovery.sh
# Replaces detect_installed_software() with optimized version

Write-Output "=== Discovery.sh Optimization ==="

# Backup the file first
Copy-Item orchestrator/discovery.sh orchestrator/discovery.sh.pre-opt -Force
Write-Output "Created backup: discovery.sh.pre-opt"

# Get clean version from git
$original = git show HEAD:orchestrator/discovery.sh

# Write to temp file for processing
$tempFile = "orchestrator/discovery_temp_for_optimization.sh"
$original | Out-File $tempFile -Encoding UTF8 -NoNewline

# Define line numbers (from prior analysis)
# detect_installed_software starts around line 122 and ends around line 171

# Read all lines
$lines = $original -split "`n" |  ForEach-Object { $_ }

# Find the function start and end
$startLine = -1
$endLine = -1

for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'detect_installed_software\(\)') {
        $startLine = $i
    }

    # Look for the closing brace of this function
    # The next function is detect_services() around line 179
    if ($startLine -ge 0 -and $lines[$i] -match 'detect_services\(\)') {
        $endLine = $i - 1
        # Back up to find the closing brace
        while ($endLine -ge 0 -and $lines[$endLine] -notmatch '^\}') {
            $endLine--
        }
        break
    }
}

if ($startLine -lt 0 -or $endLine -lt 0) {
    Write-Error "Could not locate function boundaries"
    exit 1
}

Write-Output "Found function: lines $($startLine + 1) to $($endLine + 1)"

# Build the new content
$beforeFunc = $lines[0..($startLine - 1)]
$afterFunc = $lines[($endLine + 1)..($lines.Count - 1)]

# The optimized function
$newFunc = @(
"########################################",
"# Detect installed software packages",
"# Populates: DETECTED_SOFTWARE array  ",
"########################################",
"detect_installed_software() {",
"  info `"Detecting installed software...`"",
"  ",
"  # Define security-relevant packages to check (targeted approach)",
"  local packages_to_check=(",
"    # Web servers",
"    nginx apache2 httpd lighttpd caddy",
"    # Databases",
"    postgresql postgresql-server mysql-server mariadb-server",
"    mongodb mongodb-org redis redis-server cassandra",
"    # Containers",
"    docker.io docker-ce containerd kubernetes kubectl kubelet",
"    # CI/CD",
"    jenkins gitlab-runner",
"    # Config management",
"    ansible puppet chef",
"    # IaC",
"    terraform packer",
"    # Monitoring",
"    prometheus grafana node-exporter",
"    # File sharing",
"    nfs-kernel-server nfs-utils samba smbd nmbd",
"    # Application runtimes",
"    openjdk java-11-openjdk nodejs python3 ruby",
"    # Misc security-relevant",
"    openssh-server ssh sshd fail2ban ufw firewalld iptables",
"  )",
"  ",
"  # Check each package (much faster than enumerating all 1000+ packages)",
"  for pkg in `"`${packages_to_check[@]}`"; do",
"    if pkg_installed `"`$pkg`"; then",
"      DETECTED_SOFTWARE+=(`"`$pkg`")",
"    fi",
"  done",
"  ",
"  info `"Found `${#DETECTED_SOFTWARE[@]} security-relevant packages`"",
"}"
)

# Combine
$newContent = $beforeFunc + $newFunc + $afterFunc

# Write the optimized file
$newContent -join "`n" | Out-File orchestrator/discovery.sh -Encoding UTF8 -NoNewline

Write-Output "Wrote optimized version"

# Validate with bash
bash -n orchestrator/discovery.sh 2>&1 | Out-Null

if ($LASTEXITCODE -eq 0) {
    Write-Output "Validation: PASS"
    Write-Output ""
    Write-Output "Optimization complete! Expected 74% faster (19.5s to under 5s)"
    Write-Output ""
    Write-Output "Review with: git diff orchestrator/discovery.sh"
} else {
    Write-Output "Validation: FAIL - reverting"
    Copy-Item orchestrator/discovery.sh.pre-opt orchestrator/discovery.sh -Force
    exit 1
}
