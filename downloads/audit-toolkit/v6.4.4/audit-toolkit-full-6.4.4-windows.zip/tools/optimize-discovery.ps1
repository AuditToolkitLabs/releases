﻿# optimize-discovery.ps1
# Optimizes discovery.sh detect_installed_software() function
# Replaces full package enumeration with targeted checks

$ErrorActionPreference = "Stop"

Write-Output "=== Discovery.sh Optimization Script ==="
Write-Output ""

# Define the target file
$discoveryFile = "orchestrator/discovery.sh"

# Get the file from git's clean version
Write-Output "1. Extracting clean version from git..."
$content = git show HEAD:$discoveryFile | Out-String

# Check if we got content
if ([string]::IsNullOrWhiteSpace($content)) {
    Write-Error "Failed to read file from git"
    exit 1
}

Write-Output "   Extracted $(($content -split "`n").Count) lines"

# Define the optimized function
$optimizedFunction = @'
########################################
# Detect installed software packages
# Populates: DETECTED_SOFTWARE array
########################################
detect_installed_software() {
  info "Detecting installed software..."

  # Define security-relevant packages to check (targeted approach)
  local packages_to_check=(
    # Web servers
    nginx apache2 httpd lighttpd caddy
    # Databases
    postgresql postgresql-server mysql-server mariadb-server
    mongodb mongodb-org redis redis-server cassandra
    # Containers
    docker.io docker-ce containerd kubernetes kubectl kubelet
    # CI/CD
    jenkins gitlab-runner
    # Config management
    ansible puppet chef
    # IaC
    terraform packer
    # Monitoring
    prometheus grafana node-exporter
    # File sharing
    nfs-kernel-server nfs-utils samba smbd nmbd
    # Application runtimes
    openjdk java-11-openjdk nodejs python3 ruby
    # Misc security-relevant
    openssh-server ssh sshd fail2ban ufw firewalld iptables
  )

  # Check each package (much faster than enumerating all 1000+ packages)
  for pkg in "${packages_to_check[@]}"; do
    if pkg_installed "$pkg"; then
      DETECTED_SOFTWARE+=("$pkg")
    fi
  done

  info "Found ${#DETECTED_SOFTWARE[@]} security-relevant packages"
}
'@

# Find the function in the content
$functionStart = $content | Select-String -Pattern '^detect_installed_software\(\) \{' -Context 0,100

if ($null -eq $functionStart) {
    Write-Error "Could not find detect_installed_software() function"
    exit 1
}

Write-Output "2. Found function at line $($functionStart.LineNumber)"

# Extract everything before the function
$lines = $content -split "`n"
$beforeFunction = $lines[0..($functionStart.LineNumber - 2)] -join "`n"

#Find the end of the function (looking for the closing brace)
$functionEnd = -1
$braceCount = 0
$inFunction = $false

for ($i = $functionStart.LineNumber - 1; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]

    if ($line -match '^detect_installed_software\(\)') {
        $inFunction = $true
    }

    if ($inFunction) {
        # Count braces
        $braceCount +=  ($line.ToCharArray() | Where-Object { $_ -eq '{' }).Count
        $braceCount -= ($line.ToCharArray() | Where-Object { $_ -eq '}' }).Count

        if ($braceCount -eq 0 -and $line -match '\}') {
            $functionEnd = $i
            break
        }
    }
}

if ($functionEnd -eq -1) {
    Write-Error "Could not find end of function"
    exit 1
}

Write-Output "   Function spans lines $($functionStart.LineNumber) to $($functionEnd + 1)"

# Extract everything after the function
$afterFunction = $lines[($functionEnd + 1)..($lines.Count - 1)] -join "`n"

# Combine the parts
$newContent = $beforeFunction + "`n" + $optimizedFunction + "`n" + $afterFunction

# Write to file
Write-Output "3. Writing optimized version..."
$newContent | Set-Content $discoveryFile -NoNewline

Write-Output "4. Validating syntax..."
bash -n $discoveryFile 2>&1 | Out-Null

if ($LASTEXITCODE -eq 0) {
    Write-Output "   ✓ Syntax valid"
} else {
    Write-Output "   ✗ Syntax error - reverting"
    git checkout $discoveryFile
    exit 1
}

Write-Output ""
Write-Output "=== Optimization Complete ==="
Write-Output ""
Write-Output "Summary:"
Write-Output "- Replaced full package enumeration with targeted checks"
Write-Output "- Now checks ~50 security-relevant packages instead of 1000+"
Write-Output "- Expected improvement: 74% faster (19.5s to under 5s)"
Write-Output ""
Write-Output "Next steps:"
Write-Output "  git diff orchestrator/discovery.sh     # Review changes"
Write-Output "  bash orchestrator/discovery.sh --help  # Test execution"
Write-Output "  git add orchestrator/discovery.sh      # Stage changes"
Write-Output "  git commit -m `"Performance: Optimize detect_installed_software()`""

