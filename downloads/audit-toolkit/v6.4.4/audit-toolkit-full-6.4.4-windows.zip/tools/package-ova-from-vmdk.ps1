[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = "6.0.0",

    [Parameter()]
    [string]$OutputPath = "deployment/vm-appliance/output",

    [Parameter()]
    [string]$SourceVmdkName = "",

    [Parameter()]
    [string]$SourceVhdxName = "",

    [Parameter()]
    [string]$SourceVhdxPath = "",

    [Parameter()]
    [string]$VMName = ""
  ,
    [Parameter()]
    [int]$MinimumInstalledDiskGB = 1,

    [Parameter()]
    [ValidateSet("All", "VmdkOnly", "OvaOnly")]
    [string]$Stage = "All"
)

$ErrorActionPreference = "Stop"

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }

$repoRoot = Split-Path -Parent $PSScriptRoot
$out = if ([System.IO.Path]::IsPathRooted($OutputPath)) { $OutputPath } else { Join-Path $repoRoot $OutputPath }
$out = [System.IO.Path]::GetFullPath($out).Replace('/', '\\')

if (-not (Test-Path $out)) {
    throw "Output path not found: $out"
}

if (-not $VMName) {
  $VMName = "AuditToolkit-Appliance-Base"
}

$targetBase = "security-audit-toolkit-$Version"
$targetVmdkName = "$targetBase.vmdk"
$targetVmdk = Join-Path $out $targetVmdkName
$runVmdkPrep = $Stage -ne "OvaOnly"
$runOvaPackage = $Stage -ne "VmdkOnly"
$preferExplicitVhdx = $runVmdkPrep -and (
  -not [string]::IsNullOrWhiteSpace($SourceVhdxPath) -or
  -not [string]::IsNullOrWhiteSpace($SourceVhdxName)
)

Write-Step "Packaging stage: $Stage"

if (-not $runVmdkPrep -and $SourceVhdxPath) {
  Write-Warn "Ignoring -SourceVhdxPath in OvaOnly stage (VHDX conversion is disabled)."
}

$resolvedSourceVmdk = $null
if ($SourceVmdkName) {
    $candidate = Join-Path $out $SourceVmdkName
    if (Test-Path $candidate) {
        $resolvedSourceVmdk = $candidate
    }
}

if (-not $resolvedSourceVmdk -and -not $preferExplicitVhdx) {
    foreach ($candidateName in @("$VMName.vmdk", $targetVmdkName)) {
        $candidate = Join-Path $out $candidateName
        if (Test-Path $candidate) {
            $resolvedSourceVmdk = $candidate
            break
        }
    }
}

if (-not $resolvedSourceVmdk) {
  if (-not $runVmdkPrep) {
    throw "Stage OvaOnly requires an existing VMDK in '$out'. Expected '$targetVmdkName' or set -SourceVmdkName. Run once with -Stage VmdkOnly first."
  }

    $vhdxCandidates = @()

  if ($SourceVhdxPath) {
    $candidate = if ([System.IO.Path]::IsPathRooted($SourceVhdxPath)) {
      $SourceVhdxPath
    }
    else {
      Join-Path $out $SourceVhdxPath
    }

    $candidate = [System.IO.Path]::GetFullPath($candidate).Replace('/', '\\')
    if (Test-Path $candidate) {
      $vhdxCandidates += $candidate
    }
  }

    if ($SourceVhdxName) {
        $candidate = Join-Path $out $SourceVhdxName
        if (Test-Path $candidate) {
            $vhdxCandidates += $candidate
        }
    }

    $defaultVhdx = Join-Path $out "$VMName.vhdx"
    if ((Test-Path $defaultVhdx) -and ($vhdxCandidates -notcontains $defaultVhdx)) {
        $vhdxCandidates += $defaultVhdx
    }

    if (-not $vhdxCandidates) {
        $vhdxCandidates = @(Get-ChildItem -Path $out -Filter "*.vhdx" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName)
    }

    if ($vhdxCandidates.Count -gt 0) {
        $sourceVhdx = $vhdxCandidates[0]
        if ($preferExplicitVhdx) {
          Write-Step "Explicit VHDX source requested; converting VHDX to VMDK"
        }
        else {
          Write-Step "No source VMDK found; converting VHDX to VMDK"
        }

        $qemuImg = $null
        foreach ($candidate in @("C:\Program Files\qemu\qemu-img.exe", "C:\Program Files (x86)\qemu\qemu-img.exe")) {
            if (Test-Path $candidate) { $qemuImg = $candidate; break }
        }
        if (-not $qemuImg) {
            $cmd = Get-Command qemu-img -ErrorAction SilentlyContinue
            if ($cmd) { $qemuImg = $cmd.Source }
        }

        if (-not $qemuImg) {
            throw "Source VHDX found ($sourceVhdx) but qemu-img is not available to convert to VMDK. Install qemu-img and retry."
        }

        $conversionProfiles = @(
          @{ Name = "streamOptimized"; Options = @("-o", "subformat=streamOptimized") },
          @{ Name = "monolithicSparse"; Options = @("-o", "subformat=monolithicSparse") },
          @{ Name = "default"; Options = @() }
        )

        $conversionSucceeded = $false
        $lastFailure = ""

        foreach ($conversionMode in $conversionProfiles) {
          if (Test-Path $targetVmdk) {
            Remove-Item -Path $targetVmdk -Force -ErrorAction SilentlyContinue
          }

          Write-Step "qemu-img conversion attempt: $($conversionMode.Name) (this can take several minutes on large disks)"

          $convertArgs = @("convert", "-p", "-f", "vhdx", "-O", "vmdk")
          if ($conversionMode.Options.Count -gt 0) {
            $convertArgs += $conversionMode.Options
          }
          $convertArgs += @("$sourceVhdx", "$targetVmdk")

          $conversionTimer = [System.Diagnostics.Stopwatch]::StartNew()
          & $qemuImg @convertArgs
          $exitCode = $LASTEXITCODE
          $conversionTimer.Stop()
          Write-Step "qemu-img attempt '$($conversionMode.Name)' finished in $([math]::Round($conversionTimer.Elapsed.TotalSeconds, 1))s"

          if ($exitCode -eq 0 -and (Test-Path $targetVmdk)) {
            $conversionSucceeded = $true
            Write-Ok "Converted VHDX to VMDK using profile '$($conversionMode.Name)': $targetVmdkName"
            break
          }

          $lastFailure = "profile '$($conversionMode.Name)' failed (exit code $exitCode)"
          Write-Warn "qemu-img $lastFailure"
        }

        if (-not $conversionSucceeded) {
          throw "qemu-img conversion failed for: $sourceVhdx ($lastFailure)"
        }

        $resolvedSourceVmdk = $targetVmdk
    }
}

if (-not $resolvedSourceVmdk) {
  throw "No source VMDK or VHDX found. Output path: $out; SourceVhdxPath: $SourceVhdxPath"
}

$minimumBytes = [int64]$MinimumInstalledDiskGB * 1GB
$sourceSizeBytes = (Get-Item $resolvedSourceVmdk).Length
if ($sourceSizeBytes -lt $minimumBytes) {
  $actualMb = [math]::Round($sourceSizeBytes / 1MB, 2)
  throw "Source disk appears uninstalled/empty ($actualMb MB): $resolvedSourceVmdk"
}

$ovfPath = Join-Path $out "$targetBase.ovf"
$mfPath = Join-Path $out "$targetBase.mf"
$ovaPath = Join-Path $out "$targetBase.ova"

$resolvedSourceFull = [System.IO.Path]::GetFullPath($resolvedSourceVmdk)
$targetVmdkFull = [System.IO.Path]::GetFullPath($targetVmdk)

if ($resolvedSourceFull -ne $targetVmdkFull) {
    Write-Step "Copying source VMDK to release naming"
    Copy-Item -Path $resolvedSourceVmdk -Destination $targetVmdk -Force
} elseif (-not (Test-Path $targetVmdk)) {
    Copy-Item -Path $resolvedSourceVmdk -Destination $targetVmdk -Force
}

if (-not (Test-Path $targetVmdk)) {
  throw "Target VMDK not found after copy/convert: $targetVmdk"
}

$targetSizeBytes = (Get-Item $targetVmdk).Length
if ($targetSizeBytes -lt $minimumBytes) {
    $actualMb = [math]::Round($targetSizeBytes / 1MB, 2)
    throw "Target VMDK appears uninstalled/empty ($actualMb MB): $targetVmdk"
}

$vmdkSize = (Get-Item $targetVmdk).Length
Write-Ok "VMDK ready: $targetVmdkName"

if (-not $runOvaPackage) {
  Write-Ok "Stage VmdkOnly complete"
  Get-Item $targetVmdk | Select-Object FullName,Length,LastWriteTime | Format-List
  return
}

Write-Step "Generating OVF descriptor"
$ovfContent = @"
<?xml version="1.0" encoding="UTF-8"?>
<Envelope xmlns="http://schemas.dmtf.org/ovf/envelope/1"
          xmlns:ovf="http://schemas.dmtf.org/ovf/envelope/1"
          xmlns:rasd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData"
          xmlns:vssd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

  <References>
    <File ovf:href="$targetVmdkName" ovf:id="file1" ovf:size="$vmdkSize"/>
  </References>

  <DiskSection>
    <Info>Virtual disk information</Info>
    <Disk ovf:capacity="53687091200" ovf:diskId="vmdisk1" ovf:fileRef="file1" ovf:format="http://www.vmware.com/interfaces/specifications/vmdk.html#streamOptimized"/>
  </DiskSection>

  <NetworkSection>
    <Info>Network configuration</Info>
    <Network ovf:name="NAT">
      <Description>NAT network</Description>
    </Network>
  </NetworkSection>

  <VirtualSystem ovf:id="SecurityAuditToolkit">
    <Info>Security Audit Toolkit Virtual Appliance</Info>
    <Name>Security Audit Toolkit $Version</Name>

    <OperatingSystemSection ovf:id="96">
      <Info>Ubuntu 64-bit</Info>
      <Description>Ubuntu_64</Description>
    </OperatingSystemSection>

    <VirtualHardwareSection>
      <Info>Virtual hardware requirements</Info>
      <System>
        <vssd:ElementName>Virtual Hardware Family</vssd:ElementName>
        <vssd:InstanceID>0</vssd:InstanceID>
        <vssd:VirtualSystemType>vmx-14</vssd:VirtualSystemType>
      </System>

      <Item>
        <rasd:Caption>2 virtual CPUs</rasd:Caption>
        <rasd:Description>Number of virtual CPUs</rasd:Description>
        <rasd:ElementName>2 virtual CPUs</rasd:ElementName>
        <rasd:InstanceID>1</rasd:InstanceID>
        <rasd:ResourceType>3</rasd:ResourceType>
        <rasd:VirtualQuantity>2</rasd:VirtualQuantity>
      </Item>

      <Item>
        <rasd:AllocationUnits>byte * 2^20</rasd:AllocationUnits>
        <rasd:Caption>4096 MB of memory</rasd:Caption>
        <rasd:Description>Memory Size</rasd:Description>
        <rasd:ElementName>4096 MB of memory</rasd:ElementName>
        <rasd:InstanceID>2</rasd:InstanceID>
        <rasd:ResourceType>4</rasd:ResourceType>
        <rasd:VirtualQuantity>4096</rasd:VirtualQuantity>
      </Item>

      <Item>
        <rasd:Address>0</rasd:Address>
        <rasd:Caption>sataController0</rasd:Caption>
        <rasd:Description>SATA Controller</rasd:Description>
        <rasd:ElementName>sataController0</rasd:ElementName>
        <rasd:InstanceID>3</rasd:InstanceID>
        <rasd:ResourceSubType>AHCI</rasd:ResourceSubType>
        <rasd:ResourceType>20</rasd:ResourceType>
      </Item>

      <Item>
        <rasd:AddressOnParent>0</rasd:AddressOnParent>
        <rasd:Caption>disk1</rasd:Caption>
        <rasd:Description>Disk Image</rasd:Description>
        <rasd:ElementName>disk1</rasd:ElementName>
        <rasd:HostResource>/disk/vmdisk1</rasd:HostResource>
        <rasd:InstanceID>4</rasd:InstanceID>
        <rasd:Parent>3</rasd:Parent>
        <rasd:ResourceType>17</rasd:ResourceType>
      </Item>

      <Item>
        <rasd:AutomaticAllocation>true</rasd:AutomaticAllocation>
        <rasd:Caption>Ethernet adapter on 'NAT'</rasd:Caption>
        <rasd:Connection>NAT</rasd:Connection>
        <rasd:ElementName>Ethernet adapter on 'NAT'</rasd:ElementName>
        <rasd:InstanceID>5</rasd:InstanceID>
        <rasd:ResourceSubType>E1000</rasd:ResourceSubType>
        <rasd:ResourceType>10</rasd:ResourceType>
      </Item>
    </VirtualHardwareSection>
  </VirtualSystem>
</Envelope>
"@
$ovfContent | Out-File -FilePath $ovfPath -Encoding UTF8
Write-Ok "OVF ready: $($targetBase).ovf"

Write-Step "Generating manifest"
$ovfHash = (Get-FileHash -Path $ovfPath -Algorithm SHA256).Hash
$vmdkHash = (Get-FileHash -Path $targetVmdk -Algorithm SHA256).Hash
$manifestLines = @(
    "SHA256($($targetBase).ovf)= $ovfHash",
    "SHA256($($targetBase).vmdk)= $vmdkHash"
)
$manifestLines | Out-File -FilePath $mfPath -Encoding ASCII
Write-Ok "Manifest ready: $($targetBase).mf"

Write-Step "Packaging OVA tar archive"
$tarExe = $null
foreach ($candidate in @("C:\Windows\System32\tar.exe", "tar")) {
  if ([System.IO.Path]::IsPathRooted($candidate)) {
    if (Test-Path $candidate) { $tarExe = $candidate; break }
  } else {
    $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
    if ($cmd) { $tarExe = $cmd.Source; break }
  }
}

if (-not $tarExe) {
  throw "No tar executable found (checked C:\\Windows\\System32\\tar.exe and PATH)."
}

Push-Location $out
try {
    if (Test-Path $ovaPath) { Remove-Item $ovaPath -Force }
  & $tarExe -cvf "$($targetBase).ova" "$($targetBase).ovf" "$($targetBase).vmdk" "$($targetBase).mf" | Out-Null
}
finally {
    Pop-Location
}

if (-not (Test-Path $ovaPath)) {
    throw "OVA creation failed: $ovaPath"
}

$ovaSizeGb = [math]::Round((Get-Item $ovaPath).Length / 1GB, 2)
Write-Ok "OVA ready: $($targetBase).ova ($ovaSizeGb GB)"

Get-ChildItem $out | Where-Object { $_.Name -match "^security-audit-toolkit-$([regex]::Escape($Version))\.(ovf|ova|mf|vmdk)$" } |
    Select-Object Name,Length,LastWriteTime |
    Format-Table -AutoSize

