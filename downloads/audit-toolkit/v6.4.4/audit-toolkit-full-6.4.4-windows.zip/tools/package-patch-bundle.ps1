[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$BundleDir,

    [Parameter()]
    [string]$OutputDir = '.',

    [Parameter()]
    [string]$Name,

    [Parameter()]
    [switch]$IncludeTarGz
)

$ErrorActionPreference = 'Stop'

$bundlePath = [System.IO.Path]::GetFullPath($BundleDir)
if (-not (Test-Path $bundlePath)) {
    throw "Bundle directory not found: $bundlePath"
}
if (-not (Test-Path (Join-Path $bundlePath 'patch.json'))) {
    throw "Bundle directory must contain patch.json: $bundlePath"
}

$outputPath = [System.IO.Path]::GetFullPath($OutputDir)
New-Item -ItemType Directory -Path $outputPath -Force | Out-Null

$baseName = if ($Name) { $Name } else { Split-Path $bundlePath -Leaf }
$zipPath = Join-Path $outputPath ("$baseName.zip")
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

Compress-Archive -Path (Join-Path $bundlePath '*') -DestinationPath $zipPath -Force
Write-Output "Created: $zipPath"

if ($IncludeTarGz) {
    $tar = Get-Command tar -ErrorAction SilentlyContinue
    if (-not $tar) {
        throw 'tar command not found; cannot create .tar.gz'
    }

    $tarPath = Join-Path $outputPath ("$baseName.tar.gz")
    if (Test-Path $tarPath) {
        Remove-Item $tarPath -Force
    }

    Push-Location (Split-Path $bundlePath -Parent)
    try {
        & $tar.Path -czf $tarPath (Split-Path $bundlePath -Leaf)
        if ($LASTEXITCODE -ne 0) {
            throw "tar exited with code $LASTEXITCODE"
        }
    }
    finally {
        Pop-Location
    }

    Write-Output "Created: $tarPath"
}
