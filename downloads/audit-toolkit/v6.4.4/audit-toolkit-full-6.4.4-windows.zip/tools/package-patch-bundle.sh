#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: tools/package-patch-bundle.sh <bundle-dir> [output-dir] [name]

Examples:
  tools/package-patch-bundle.sh patches/examples/targeted-patch-template
  tools/package-patch-bundle.sh patches/examples/targeted-patch-template dist fix-20260322-example
EOF
}

BUNDLE_DIR="${1:-}"
OUTPUT_DIR="${2:-.}"
NAME="${3:-}"

if [ -z "$BUNDLE_DIR" ]; then
  usage
  exit 1
fi

if [ ! -d "$BUNDLE_DIR" ]; then
  echo "ERROR: Bundle directory not found: $BUNDLE_DIR" >&2
  exit 1
fi

if [ ! -f "$BUNDLE_DIR/patch.json" ]; then
  echo "ERROR: Bundle directory must contain patch.json" >&2
  exit 1
fi

BUNDLE_DIR="$(cd "$BUNDLE_DIR" && pwd)"
mkdir -p "$OUTPUT_DIR"
OUTPUT_DIR="$(cd "$OUTPUT_DIR" && pwd)"

if [ -z "$NAME" ]; then
  NAME="$(basename "$BUNDLE_DIR")"
fi

ZIP_PATH="$OUTPUT_DIR/$NAME.zip"
TAR_PATH="$OUTPUT_DIR/$NAME.tar.gz"

if command -v zip >/dev/null 2>&1; then
  (
    cd "$BUNDLE_DIR"
    rm -f "$ZIP_PATH"
    zip -rq "$ZIP_PATH" .
  )
  echo "Created: $ZIP_PATH"
else
  echo "WARN: zip command not found; skipping zip build" >&2
fi

(
  cd "$(dirname "$BUNDLE_DIR")"
  rm -f "$TAR_PATH"
  tar -czf "$TAR_PATH" "$(basename "$BUNDLE_DIR")"
)
echo "Created: $TAR_PATH"
