#!/usr/bin/env python3
"""Normalize GitHub Sponsors payload (raw webhook or repository_dispatch wrapper) into a license fulfillment request."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable


SUPPORTED_TIERS = ("starter", "professional", "business")
EMAIL_PATTERN = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
ACTION_ALIAS_MAP = {
    "sponsorship_created": "created",
    "gh_sponsorship_created": "created",
    "github_sponsorship_created": "created",
    "sponsorship_tier_changed": "tier_changed",
    "gh_sponsorship_tier_changed": "tier_changed",
    "github_sponsorship_tier_changed": "tier_changed",
}


@dataclass(frozen=True)
class TierInfo:
    display_name: str
    slug: str
    monthly_price_usd: int | None
    is_one_time: bool | None


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract tier, customer email, and order reference from a sponsorship event payload",
    )
    parser.add_argument(
        "--event-path",
        default=os.environ.get("GITHUB_EVENT_PATH", ""),
        help="Path to GitHub Actions event payload JSON (defaults to GITHUB_EVENT_PATH)",
    )
    parser.add_argument(
        "--output",
        default="sponsorship-fulfillment.json",
        help="Output file path for normalized fulfillment request JSON",
    )
    parser.add_argument(
        "--allow-actions",
        default="created,tier_changed",
        help="Comma-separated sponsorship action values allowed for fulfillment",
    )
    return parser.parse_args()


def _load_payload(event_path: str) -> dict[str, Any]:
    resolved = Path(event_path).resolve()
    if not resolved.exists():
        raise ValueError(f"Event payload file not found: {resolved}")

    try:
        payload = json.loads(resolved.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Event payload is not valid JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError("Event payload root must be an object")

    return payload


def _unwrap_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if isinstance(payload.get("sponsorship"), dict):
        return payload

    client_payload = payload.get("client_payload")
    if isinstance(client_payload, dict):
        if isinstance(client_payload.get("sponsorship"), dict):
            return client_payload

        nested_event = client_payload.get("event")
        if isinstance(nested_event, dict) and isinstance(nested_event.get("sponsorship"), dict):
            return nested_event

        nested_payload = client_payload.get("payload")
        if isinstance(nested_payload, dict) and isinstance(nested_payload.get("sponsorship"), dict):
            return nested_payload

    return payload


def _walk(node: Any, path: tuple[str, ...] = ()) -> Iterable[tuple[tuple[str, ...], Any]]:
    if isinstance(node, dict):
        for key, value in node.items():
            child_path = path + (str(key),)
            yield child_path, value
            yield from _walk(value, child_path)
        return

    if isinstance(node, list):
        for index, value in enumerate(node):
            child_path = path + (f"[{index}]",)
            yield child_path, value
            yield from _walk(value, child_path)


def _dig(payload: dict[str, Any], *keys: str) -> Any:
    current: Any = payload
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _normalize_whitespace(value: str) -> str:
    return " ".join((value or "").strip().split())


def _normalize_action(action: str) -> str:
    normalized = _normalize_whitespace(action).lower().replace("-", "_")
    if not normalized:
        return ""

    if normalized in ACTION_ALIAS_MAP:
        return ACTION_ALIAS_MAP[normalized]

    for suffix in ("created", "tier_changed", "cancelled", "pending_cancellation", "edited"):
        if normalized.endswith(f"_{suffix}"):
            return suffix

    return normalized


def _sanitize_token(value: str, max_len: int = 32) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9-]", "-", (value or "").strip())
    sanitized = re.sub(r"-+", "-", sanitized).strip("-")
    if not sanitized:
        return "unknown"
    return sanitized[:max_len]


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _to_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return None


def _extract_tier_object(payload: dict[str, Any]) -> dict[str, Any] | None:
    direct = _dig(payload, "sponsorship", "tier")
    if isinstance(direct, dict):
        return direct

    for _, value in _walk(payload):
        if not isinstance(value, dict):
            continue
        if "name" in value and (
            "monthly_price_in_dollars" in value
            or "monthlyPriceInDollars" in value
            or "is_one_time" in value
            or "isOneTime" in value
        ):
            return value

    return None


def _map_tier_slug(display_name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", display_name.lower()).strip()

    if re.search(r"\bstarter\b", normalized):
        return "starter"
    if re.search(r"\bprofessional\b", normalized) or re.search(r"\bpro\b", normalized):
        return "professional"
    if re.search(r"\bbusiness\b", normalized):
        return "business"

    raise ValueError(
        "Sponsorship tier is not mapped to a purchasable license tier. "
        f"Allowed mappings: {', '.join(SUPPORTED_TIERS)}"
    )


def _extract_tier_info(payload: dict[str, Any]) -> TierInfo:
    tier_object = _extract_tier_object(payload) or {}

    display_name = _normalize_whitespace(str(tier_object.get("name", "")))
    if not display_name:
        display_name = _normalize_whitespace(str(_dig(payload, "sponsorship", "tier_name") or ""))

    if not display_name:
        raise ValueError("Could not determine sponsorship tier name from webhook payload")

    slug = _map_tier_slug(display_name)
    monthly_price_usd = _to_int(
        tier_object.get("monthly_price_in_dollars")
        if isinstance(tier_object, dict)
        else None
    )
    if monthly_price_usd is None and isinstance(tier_object, dict):
        monthly_price_usd = _to_int(tier_object.get("monthlyPriceInDollars"))

    is_one_time = _to_bool(
        tier_object.get("is_one_time") if isinstance(tier_object, dict) else None
    )
    if is_one_time is None and isinstance(tier_object, dict):
        is_one_time = _to_bool(tier_object.get("isOneTime"))

    return TierInfo(
        display_name=display_name,
        slug=slug,
        monthly_price_usd=monthly_price_usd,
        is_one_time=is_one_time,
    )


def _is_valid_email(value: str) -> bool:
    return bool(EMAIL_PATTERN.match((value or "").strip()))


def _extract_sponsor_login(payload: dict[str, Any]) -> str:
    for path in (
        ("sponsorship", "sponsor", "login"),
        ("sponsorship", "sponsor_node", "login"),
        ("sender", "login"),
    ):
        candidate = _normalize_whitespace(str(_dig(payload, *path) or ""))
        if candidate:
            return candidate

    actor = _normalize_whitespace(os.environ.get("GITHUB_ACTOR", ""))
    if actor:
        return actor

    raise ValueError("Could not determine sponsor login from webhook payload")


def _extract_customer_email(payload: dict[str, Any]) -> str:
    explicit_candidates: list[tuple[int, str, str]] = []
    for path in (
        ("sponsorship", "sponsor", "email"),
        ("sponsorship", "sponsor", "contact_email"),
        ("sponsorship", "sponsor", "billing_email"),
        ("sponsorship", "sponsor_node", "email"),
        ("sender", "email"),
    ):
        candidate = _normalize_whitespace(str(_dig(payload, *path) or ""))
        if _is_valid_email(candidate):
            explicit_candidates.append((0, ".".join(path), candidate))

    fallback_candidates: list[tuple[int, str, str]] = []
    for raw_path, value in _walk(payload):
        if not raw_path:
            continue
        key = raw_path[-1].lower()
        if key not in {"email", "contact_email", "billing_email"}:
            continue
        if not isinstance(value, str):
            continue

        candidate = _normalize_whitespace(value)
        if not _is_valid_email(candidate):
            continue

        path_str = ".".join(raw_path).lower()
        if "sponsor" in path_str and "sponsorable" not in path_str:
            priority = 10
        elif "sender" in path_str:
            priority = 40
        else:
            priority = 80

        fallback_candidates.append((priority, path_str, candidate))

    combined = explicit_candidates + fallback_candidates
    combined.sort(key=lambda item: (item[0], item[1]))

    seen: set[str] = set()
    for _, _, candidate in combined:
        if candidate in seen:
            continue
        seen.add(candidate)
        return candidate

    privacy_level = _normalize_whitespace(str(_dig(payload, "sponsorship", "privacy_level") or ""))
    privacy_hint = f" privacy_level={privacy_level}" if privacy_level else ""
    raise ValueError(
        "No deliverable sponsor email found in sponsorship payload. "
        "Automatic delivery requires sponsor email visibility or explicit contact email."
        f"{privacy_hint}"
    )


def _build_order_ref(payload: dict[str, Any], sponsor_login: str) -> str:
    sponsorship_id = _dig(payload, "sponsorship", "id")
    if sponsorship_id not in (None, ""):
        return f"GHSP-{_sanitize_token(str(sponsorship_id), max_len=40)}"

    node_id = _normalize_whitespace(str(_dig(payload, "sponsorship", "node_id") or ""))
    if node_id:
        return f"GHSP-{_sanitize_token(node_id, max_len=40)}"

    timestamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    return f"GHSP-{_sanitize_token(sponsor_login, max_len=24)}-{timestamp}"


def main() -> int:
    args = _parse_args()

    try:
        event_path = (args.event_path or "").strip()
        if not event_path:
            raise ValueError("Event payload path is required (--event-path or GITHUB_EVENT_PATH)")

        raw_payload = _load_payload(event_path)
        payload = _unwrap_payload(raw_payload)

        action = _normalize_action(str(payload.get("action", "")))
        if not action:
            action = _normalize_action(str(raw_payload.get("action", "")))
        if not action:
            raise ValueError("Event payload missing action")

        allowed_actions = {
            _normalize_whitespace(value).lower()
            for value in str(args.allow_actions).split(",")
            if _normalize_whitespace(value)
        }
        if action not in allowed_actions:
            raise ValueError(
                f"Event action '{action}' is not configured for automatic fulfillment "
                f"(allowed: {', '.join(sorted(allowed_actions))})"
            )

        sponsorship = payload.get("sponsorship")
        if not isinstance(sponsorship, dict):
            raise ValueError("Event payload missing sponsorship object")

        sponsor_login = _extract_sponsor_login(payload)
        customer_email = _extract_customer_email(payload)
        tier = _extract_tier_info(payload)
        order_ref = _build_order_ref(payload, sponsor_login=sponsor_login)

        output = {
            "action": action,
            "tier_name": tier.display_name,
            "tier_slug": tier.slug,
            "monthly_price_usd": tier.monthly_price_usd,
            "is_one_time": tier.is_one_time,
            "customer_email": customer_email,
            "sponsor_login": sponsor_login,
            "sponsorship_id": sponsorship.get("id"),
            "sponsorship_node_id": sponsorship.get("node_id"),
            "privacy_level": sponsorship.get("privacy_level"),
            "order_ref": order_ref,
            "generated_at_utc": datetime.now(UTC).isoformat(),
        }

        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")

        print("Sponsorship payload parsed")
        print(f"- Action: {action}")
        print(f"- Tier: {tier.display_name} -> {tier.slug}")
        print(f"- Sponsor: {sponsor_login}")
        print(f"- Customer email: {customer_email}")
        print(f"- Order ref: {order_ref}")
        print(f"- Output: {output_path}")
        return 0

    except Exception as error:
        print(f"Sponsorship payload parsing failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())