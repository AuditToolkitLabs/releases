[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$TargetIP,
    [int]$Port = 22,
    [string]$Username = "audit_user",
    [string]$SshKeyPath = "",
    [switch]$ApplyExpectedState,
    [string]$RemoteBootstrapPath = "/tmp/prep-linux-target-expected-state.sh",
    [switch]$NonInteractive
)

$null = $SshKeyPath, $NonInteractive

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path $PSScriptRoot -Parent

function Write-Status {
    param(
        [string]$Message,
        [ValidateSet("INFO", "PASS", "WARN", "FAIL")]
        [string]$Level = "INFO"
    )

    Write-Output "[$Level] $Message"
}

function Get-SshBaseArgs {
    param([string]$UserAtHost)

    $baseArgs = @(
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ConnectTimeout=10",
        "-p", "$Port"
    )

    if ($NonInteractive) {
        $baseArgs += @("-o", "BatchMode=yes")
    }

    if ($SshKeyPath) {
        $baseArgs += @("-i", $SshKeyPath)
    }

    $baseArgs += $UserAtHost
    return $baseArgs
}

function Invoke-Ssh {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [switch]$AllowFail
    )

    $userAtHost = "$Username@$TargetIP"
    $sshArgs = Get-SshBaseArgs -UserAtHost $userAtHost
    $sshArgs += $Command

    $output = & ssh @sshArgs 2>&1
    $code = $LASTEXITCODE

    if (-not $AllowFail -and $code -ne 0) {
        throw "SSH command failed ($code): $($output -join ' ')"
    }

    [PSCustomObject]@{
        ExitCode = $code
        Output = ($output -join "`n")
    }
}

function Invoke-ScpToTarget {
    param(
        [Parameter(Mandatory = $true)][string]$LocalFile,
        [Parameter(Mandatory = $true)][string]$RemoteFile
    )

    $scpArgs = @(
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-P", "$Port"
    )

    if ($NonInteractive) {
        $scpArgs += @("-o", "BatchMode=yes")
    }

    if ($SshKeyPath) {
        $scpArgs += @("-i", $SshKeyPath)
    }

    $scpArgs += @($LocalFile, "$Username@$TargetIP`:$RemoteFile")
    & scp @scpArgs 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "SCP upload failed for '$LocalFile'"
    }
}

function Get-SudoCommand {
    param([string]$InnerCommand)
    return "sudo -n bash -lc '$InnerCommand'"
}

try {
    if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
        throw "OpenSSH client is not available in PATH."
    }

    Write-Status "Checking TCP connectivity to ${TargetIP}:$Port"
    $portCheck = Test-NetConnection -ComputerName $TargetIP -Port $Port -WarningAction SilentlyContinue
    if (-not $portCheck.TcpTestSucceeded) {
        throw "TCP connectivity failed on ${TargetIP}:$Port"
    }
    Write-Status "Port is reachable" -Level PASS

    Write-Status "Validating SSH authentication"
    $idResult = Invoke-Ssh -Command "id -un"
    if ($idResult.ExitCode -ne 0) {
        throw "SSH login failed for user '$Username'."
    }
    Write-Status "SSH login succeeded" -Level PASS

    Write-Status "Checking sudo availability"
    $sudoCheck = Invoke-Ssh -Command (Get-SudoCommand -InnerCommand "true") -AllowFail
    if ($sudoCheck.ExitCode -ne 0) {
        throw "Sudo validation failed for '$Username'."
    }
    Write-Status "Sudo check passed" -Level PASS

    if ($ApplyExpectedState) {
        $localBootstrap = Join-Path $ProjectRoot "tools\prep-linux-target-expected-state.sh"
        if (-not (Test-Path -LiteralPath $localBootstrap)) {
            throw "Bootstrap script not found: $localBootstrap"
        }

        Write-Status "Uploading baseline bootstrap script"
        Invoke-ScpToTarget -LocalFile $localBootstrap -RemoteFile $RemoteBootstrapPath

        Write-Status "Applying expected-state baseline"
        $apply = Invoke-Ssh -Command (Get-SudoCommand -InnerCommand "chmod +x $RemoteBootstrapPath && $RemoteBootstrapPath") -AllowFail
        if ($apply.ExitCode -ne 0) {
            throw "Expected-state apply failed: $($apply.Output)"
        }
        Write-Status "Expected-state baseline applied" -Level PASS
    }

    Write-Status "Running final host probe"
    $final = Invoke-Ssh -Command (Get-SudoCommand -InnerCommand "id && uname -a")
    Write-Output $final.Output

    Write-Status "SSH precheck passed" -Level PASS
    exit 0
}
catch {
    Write-Status $_.Exception.Message -Level FAIL
    exit 1
}
