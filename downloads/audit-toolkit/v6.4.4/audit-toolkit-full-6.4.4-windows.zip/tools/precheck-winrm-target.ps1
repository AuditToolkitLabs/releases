[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Precheck utility intentionally uses colorized host output for step-by-step operator guidance')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '', Justification='CLI compatibility for precheck utility; password is converted to SecureString in-memory before use')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$TargetIP,

    [Parameter()]
    [string]$Username = "audit_user",

    [Parameter()]
    [string]$Password = "",

    [Parameter()]
    [switch]$UpdateTrustedHosts,

    [Parameter()]
    [switch]$AllowUnencrypted
)

$ErrorActionPreference = "Stop"

function Write-Status { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Success { param([string]$Message) Write-Host "[+] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }
function Write-Fail { param([string]$Message) Write-Host "[-] $Message" -ForegroundColor Red }

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

try {
    Write-Output "=============================================================="
    Write-Output " WinRM Target Precheck"
    Write-Output "=============================================================="

    if ([string]::IsNullOrWhiteSpace($Password)) {
        if (-not [string]::IsNullOrWhiteSpace($env:WINRM_TEST_PASSWORD)) {
            $Password = $env:WINRM_TEST_PASSWORD
            Write-Status "Using WINRM_TEST_PASSWORD from environment"
        }
        else {
            throw "No password provided. Use -Password or set WINRM_TEST_PASSWORD."
        }
    }

    Write-Status "Ensuring local WinRM service is running"
    Start-Service WinRM -ErrorAction SilentlyContinue
    Set-Service WinRM -StartupType Automatic -ErrorAction SilentlyContinue
    Write-Success "Local WinRM service ready"

    if ($AllowUnencrypted) {
        Write-Status "Enabling local WinRM client AllowUnencrypted"
        Set-Item WSMan:\localhost\Client\AllowUnencrypted -Value $true -Force
    }

    if ($UpdateTrustedHosts) {
        Write-Status "Updating TrustedHosts with target: $TargetIP"
        $current = (Get-Item WSMan:\localhost\Client\TrustedHosts).Value
        if ([string]::IsNullOrWhiteSpace($current)) {
            Set-Item WSMan:\localhost\Client\TrustedHosts -Value $TargetIP -Force
        }
        elseif ($current -notmatch "(^|,)\s*$([regex]::Escape($TargetIP))\s*(,|$)") {
            Set-Item WSMan:\localhost\Client\TrustedHosts -Value ($current + "," + $TargetIP) -Force
        }
        Write-Success "TrustedHosts updated"
    }
    else {
        Write-Warn "TrustedHosts not modified (use -UpdateTrustedHosts if needed)"
    }

    Write-Status "Checking TCP connectivity to ${TargetIP}:5985"
    $portCheck = Test-NetConnection -ComputerName $TargetIP -Port 5985 -WarningAction SilentlyContinue
    if (-not $portCheck.TcpTestSucceeded) {
        throw "TCP connectivity failed on ${TargetIP}:5985"
    }
    Write-Success "Port 5985 reachable"

    $secure = ConvertTo-InMemorySecureString -Value $Password
    $credential = New-Object System.Management.Automation.PSCredential($Username, $secure)

    Write-Status "Testing WSMan handshake"
    $wsman = Test-WSMan -ComputerName $TargetIP -Credential $credential -Authentication Default -ErrorAction Stop
    if (-not $wsman) {
        throw "WSMan handshake failed"
    }
    Write-Success "WSMan handshake succeeded"

    Write-Status "Testing remote command execution"
    $session = New-PSSession -ComputerName $TargetIP -Credential $credential -ErrorAction Stop
    try {
        $result = Invoke-Command -Session $session -ScriptBlock { "$( [System.Environment]::MachineName )|$([Environment]::OSVersion.VersionString)" } -ErrorAction Stop
        Write-Success "Remote command succeeded: $result"
    }
    finally {
        Remove-PSSession -Session $session -ErrorAction SilentlyContinue
    }

    Write-Success "WinRM precheck PASSED"
    exit 0
}
catch {
    Write-Fail $_.Exception.Message
    Write-Output ""
    Write-Output "Troubleshooting quick checks:"
    Write-Output "  1) On target VM: Enable-PSRemoting -Force"
    Write-Output "  2) On target VM: winrm quickconfig -force"
    Write-Output "  3) On target VM: New-NetFirewallRule -Name 'WinRM-HTTP-In' -DisplayName 'WinRM HTTP In' -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5985 -Action Allow"
    Write-Output "  4) Re-run this precheck with -UpdateTrustedHosts"
    exit 1
}
