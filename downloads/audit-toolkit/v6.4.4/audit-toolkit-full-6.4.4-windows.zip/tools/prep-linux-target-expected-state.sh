#!/usr/bin/env bash
set -euo pipefail

AUDIT_USER="${AUDIT_USER:-audit_user}"
AUDIT_USER_PASSWORD="${AUDIT_USER_PASSWORD:-TestPass123!}"
ENABLE_PASSWORDLESS_SUDO="${ENABLE_PASSWORDLESS_SUDO:-0}"

log() { printf '[*] %s\n' "$*"; }
ok() { printf '[+] %s\n' "$*"; }
warn() { printf '[!] %s\n' "$*"; }

if [[ "${EUID}" -ne 0 ]]; then
  if command -v sudo > /dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  else
    printf '[-] This script requires root (or sudo).\n' >&2
    exit 1
  fi
fi

detect_pkg_manager() {
  if command -v apt-get > /dev/null 2>&1; then
    echo apt
    return
  fi

  if command -v dnf > /dev/null 2>&1; then
    echo dnf
    return
  fi

  if command -v yum > /dev/null 2>&1; then
    echo yum
    return
  fi

  if command -v zypper > /dev/null 2>&1; then
    echo zypper
    return
  fi

  if command -v apk > /dev/null 2>&1; then
    echo apk
    return
  fi

  echo unknown
}

install_ssh_server() {
  local pm
  pm="$(detect_pkg_manager)"
  case "$pm" in
    apt)
      log "Installing OpenSSH server via apt"
      apt-get update -y
      DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server sudo
      ;;
    dnf)
      log "Installing OpenSSH server via dnf"
      dnf install -y openssh-server sudo
      ;;
    yum)
      log "Installing OpenSSH server via yum"
      yum install -y openssh-server sudo
      ;;
    zypper)
      log "Installing OpenSSH server via zypper"
      zypper --non-interactive install openssh sudo
      ;;
    apk)
      log "Installing OpenSSH server via apk"
      apk add --no-cache openssh sudo
      ;;
    *)
      warn "Unknown package manager; skipping package install"
      ;;
  esac
}

enable_ssh_service() {
  if command -v systemctl > /dev/null 2>&1; then
    if systemctl list-unit-files | grep -q '^sshd\.service'; then
      systemctl enable --now sshd
    else
      systemctl enable --now ssh || true
    fi
  elif command -v rc-service > /dev/null 2>&1; then
    rc-update add sshd default || true
    rc-service sshd start || true
  else
    warn "No known service manager found; start sshd manually if needed"
  fi
}

set_sshd_option() {
  local key="$1"
  local value="$2"
  local cfg="/etc/ssh/sshd_config"

  if [[ ! -f "$cfg" ]]; then
    warn "sshd_config not found at $cfg"
    return
  fi

  if grep -Eq "^\s*#?\s*${key}\b" "$cfg"; then
    sed -i -E "s|^\s*#?\s*${key}\b.*|${key} ${value}|" "$cfg"
  else
    printf '\n%s %s\n' "$key" "$value" >> "$cfg"
  fi
}

configure_sshd() {
  log "Configuring SSH daemon baseline"
  set_sshd_option "PermitRootLogin" "no"
  set_sshd_option "PubkeyAuthentication" "yes"
  set_sshd_option "PasswordAuthentication" "yes"
  set_sshd_option "ChallengeResponseAuthentication" "no"
  set_sshd_option "UsePAM" "yes"
  ok "SSH config baseline applied"
}

ensure_audit_user() {
  if id "$AUDIT_USER" >/dev/null 2>&1; then
    log "User exists: $AUDIT_USER"
  else
    log "Creating user: $AUDIT_USER"
    useradd -m -s /bin/bash "$AUDIT_USER"
  fi

  echo "${AUDIT_USER}:${AUDIT_USER_PASSWORD}" | chpasswd
  ok "Password set for $AUDIT_USER"

  if getent group sudo > /dev/null 2>&1; then
    usermod -aG sudo "$AUDIT_USER"
  elif getent group wheel > /dev/null 2>&1; then
    usermod -aG wheel "$AUDIT_USER"
  fi

  ok "Sudo group membership ensured for $AUDIT_USER"
}

configure_sudo_policy() {
  local sudo_file="/etc/sudoers.d/${AUDIT_USER}"

  if [[ "$ENABLE_PASSWORDLESS_SUDO" == "1" ]]; then
    printf '%s ALL=(ALL) NOPASSWD:ALL\n' "$AUDIT_USER" > "$sudo_file"
    chmod 440 "$sudo_file"
    ok "Passwordless sudo enabled for $AUDIT_USER"
  else
    if [[ -f "$sudo_file" ]]; then
      rm -f "$sudo_file"
      log "Removed passwordless sudo override for $AUDIT_USER"
    fi
    ok "Sudo remains password-based (customer-like default)"
  fi
}

restart_ssh() {
  if command -v systemctl > /dev/null 2>&1; then
    systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
  elif command -v rc-service > /dev/null 2>&1; then
    rc-service sshd restart || true
  fi
  ok "SSH service restart attempted"
}

main() {
  log "Applying Linux expected state for SSH + sudo (non-root remote ops)"
  install_ssh_server
  configure_sshd
  ensure_audit_user
  configure_sudo_policy
  enable_ssh_service
  restart_ssh

  printf '\n[+] Completed Linux expected-state setup\n'
  printf '    User: %s\n' "$AUDIT_USER"
  printf '    Root SSH login: disabled\n'
  printf '    SSH password auth: enabled\n'
  if [[ "$ENABLE_PASSWORDLESS_SUDO" == "1" ]]; then
    printf '    Sudo mode: passwordless\n'
  else
    printf '    Sudo mode: password required\n'
  fi
}

main "$@"
