[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Proof utility intentionally emits console markers and colorized output for operators and CI logs')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = "6.0.0",

    [Parameter()]
    [string]$OutputPath = "deployment/vm-appliance/output",

    [Parameter()]
    [string]$VMName = "",

    [Parameter()]
    [string]$SourceVmdkName = "",

    [Parameter()]
    [string]$SourceVhdxName = "",

    [Parameter()]
    [string]$VHDStoragePath = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [switch]$SkipPackaging,

    [Parameter()]
    [int]$MinimumInstalledDiskGB = 1
)

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
$out = if ([System.IO.Path]::IsPathRooted($OutputPath)) { $OutputPath } else { Join-Path $repoRoot $OutputPath }
$out = [System.IO.Path]::GetFullPath($out).Replace('/', '\\')
$vhdStore = if ([System.IO.Path]::IsPathRooted($VHDStoragePath)) { $VHDStoragePath } else { Join-Path $repoRoot $VHDStoragePath }
$vhdStore = [System.IO.Path]::GetFullPath($vhdStore).Replace('/', '\\')
$vmNameResolved = if ($VMName) { $VMName } else { "AuditToolkit-Appliance-Base" }
$base = "security-audit-toolkit-$Version"

function Write-ProofMarker {
    param(
        [string]$Name,
        [bool]$Pass,
        [string]$Details = ""
    )

    $state = if ($Pass) { "PASS" } else { "FAIL" }
    if ($Details) {
        Write-Output "PROOF:$Name=$state;$Details"
    } else {
        Write-Output "PROOF:$Name=$state"
    }

    if (-not $Pass) {
        $script:HasFailures = $true
    }
}

$HasFailures = $false
Write-Output "[*] OVA/OVF proof (Hyper-V-first workflow)"
Write-Output "    Version: $Version"
Write-Output "    Output:  $out"
Write-Output "    VHD:     $vhdStore"
Write-Output "    VM Name: $vmNameResolved"

Write-ProofMarker -Name "OUTPUT_DIR" -Pass (Test-Path $out) -Details $out
if (-not (Test-Path $out)) {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

$packageScript = Join-Path $repoRoot "tools\package-ova-from-vmdk.ps1"
Write-ProofMarker -Name "PACKAGE_SCRIPT" -Pass (Test-Path $packageScript) -Details $packageScript

if (-not $SkipPackaging) {
    $sourceVmdk = if ($SourceVmdkName) { $SourceVmdkName } else { "$vmNameResolved.vmdk" }
    $sourceVhdx = if ($SourceVhdxName) { $SourceVhdxName } else { "$vmNameResolved.vhdx" }
    $sourceVhdxPath = Join-Path $vhdStore $sourceVhdx

    try {
        & $packageScript `
            -Version $Version `
            -OutputPath $out `
            -VMName $vmNameResolved `
            -SourceVmdkName $sourceVmdk `
            -SourceVhdxName $sourceVhdx `
            -SourceVhdxPath $sourceVhdxPath `
            -MinimumInstalledDiskGB $MinimumInstalledDiskGB
        Write-ProofMarker -Name "PACKAGE_RUN" -Pass $true
    }
    catch {
        Write-ProofMarker -Name "PACKAGE_RUN" -Pass $false -Details $_.Exception.Message
    }
}

$ovf = Join-Path $out "$base.ovf"
$ova = Join-Path $out "$base.ova"
$mf = Join-Path $out "$base.mf"
$vmdk = Join-Path $out "$base.vmdk"
$sourceVhdxCandidate = if ($SourceVhdxName) { $SourceVhdxName } else { "$vmNameResolved.vhdx" }
$vhdx = Join-Path $vhdStore $sourceVhdxCandidate
if (-not (Test-Path $vhdx)) {
    $vhdx = Join-Path $out $sourceVhdxCandidate
}

$minimumBytes = [int64]$MinimumInstalledDiskGB * 1GB

Write-ProofMarker -Name "OVF_EXISTS" -Pass (Test-Path $ovf) -Details $ovf
Write-ProofMarker -Name "OVA_EXISTS" -Pass (Test-Path $ova) -Details $ova
Write-ProofMarker -Name "MF_EXISTS" -Pass (Test-Path $mf) -Details $mf
Write-ProofMarker -Name "VMDK_EXISTS" -Pass (Test-Path $vmdk) -Details $vmdk

if (Test-Path $vmdk) {
    $vmdkSizeBytes = (Get-Item $vmdk).Length
    $vmdkSizeMb = [math]::Round($vmdkSizeBytes / 1MB, 2)
    Write-ProofMarker -Name "VMDK_MIN_SIZE" -Pass ($vmdkSizeBytes -ge $minimumBytes) -Details "${vmdkSizeMb}MB"
}

if (Test-Path $vhdx) {
    $vhdxSizeBytes = (Get-Item $vhdx).Length
    $vhdxSizeMb = [math]::Round($vhdxSizeBytes / 1MB, 2)
    Write-ProofMarker -Name "VHDX_MIN_SIZE" -Pass ($vhdxSizeBytes -ge $minimumBytes) -Details "${vhdxSizeMb}MB"
}

if (Test-Path $mf) {
    $manifest = Get-Content -Path $mf -Raw
    Write-ProofMarker -Name "MANIFEST_OVF" -Pass ($manifest -match "SHA256\($base\.ovf\)=")
    Write-ProofMarker -Name "MANIFEST_VMDK" -Pass ($manifest -match "SHA256\($base\.vmdk\)=")
}

if (Test-Path $ova) {
    $tarExe = if (Test-Path "C:\Windows\System32\tar.exe") { "C:\Windows\System32\tar.exe" } else { "tar" }
    try {
        $tarList = & $tarExe -tf $ova 2>$null
        Write-ProofMarker -Name "OVA_HAS_OVF" -Pass ($tarList -contains "$base.ovf")
        Write-ProofMarker -Name "OVA_HAS_VMDK" -Pass ($tarList -contains "$base.vmdk")
        Write-ProofMarker -Name "OVA_HAS_MF" -Pass ($tarList -contains "$base.mf")
    }
    catch {
        Write-ProofMarker -Name "OVA_TAR_READ" -Pass $false -Details $_.Exception.Message
    }
}

foreach ($path in @($ovf, $ova, $mf, $vmdk)) {
    if (Test-Path $path) {
        $hash = (Get-FileHash -Path $path -Algorithm SHA256).Hash
        Write-Output "PROOF:SHA256:$([System.IO.Path]::GetFileName($path))=$hash"
    }
}

if ($HasFailures) {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

Write-Output "PROOF:RESULT=PASS"
exit 0
