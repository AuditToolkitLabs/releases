[CmdletBinding()]
param(
    [Parameter()]
    [string]$VMName = "AuditToolkit-Appliance-Base",

    [Parameter()]
    [int]$HealthPort = 443,

    [Parameter()]
    [string]$HealthPath = "/health",

    [Parameter()]
    [int]$WaitForIPSec = 180,

    [Parameter()]
    [switch]$StartIfStopped
)

$ErrorActionPreference = "Stop"
$HasFailures = $false

function Write-Marker {
    param(
        [string]$Name,
        [bool]$Pass,
        [string]$Details = ""
    )

    $state = if ($Pass) { "PASS" } else { "FAIL" }
    if ($Details) {
        Write-Output "PROOF:$Name=$state;$Details"
    } else {
        Write-Output "PROOF:$Name=$state"
    }

    if (-not $Pass) {
        $script:HasFailures = $true
    }
}

function Get-PrimaryIPv4 {
    param([string]$Name)

    $ips = (Get-VMNetworkAdapter -VMName $Name -ErrorAction SilentlyContinue).IPAddresses
    if (-not $ips) { return $null }

    return $ips |
        Where-Object {
            $_ -match '^\d+\.\d+\.\d+\.\d+$' -and
            $_ -notlike '169.254.*' -and
            $_ -ne '127.0.0.1'
        } |
        Select-Object -First 1
}

Write-Output "[*] Hyper-V VM runtime proof"
Write-Output "    VM Name:    $VMName"
Write-Output "    Health URI: https://<ip>:$HealthPort$HealthPath"

$vm = Get-VM -Name $VMName -ErrorAction SilentlyContinue
Write-Marker -Name "VM_EXISTS" -Pass ($null -ne $vm) -Details $VMName
if (-not $vm) {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

if ($vm.State -ne 'Running' -and $StartIfStopped) {
    try {
        Start-VM -Name $VMName -ErrorAction Stop | Out-Null
        Start-Sleep -Seconds 5
        $vm = Get-VM -Name $VMName -ErrorAction SilentlyContinue
    }
    catch {
        Write-Marker -Name "VM_START" -Pass $false -Details $_.Exception.Message
    }
}

Write-Marker -Name "VM_RUNNING" -Pass ($vm.State -eq 'Running') -Details $vm.State
if ($vm.State -ne 'Running') {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

$deadline = (Get-Date).AddSeconds($WaitForIPSec)
$vmIp = $null
while ((Get-Date) -lt $deadline) {
    $vmIp = Get-PrimaryIPv4 -Name $VMName
    if ($vmIp) { break }
    Start-Sleep -Seconds 3
}

Write-Marker -Name "VM_IP" -Pass (-not [string]::IsNullOrWhiteSpace($vmIp)) -Details ($vmIp ?? "none")
if (-not $vmIp) {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

$sshTest = Test-NetConnection -ComputerName $vmIp -Port 22 -WarningAction SilentlyContinue
Write-Marker -Name "SSH_PORT_22" -Pass ($sshTest.TcpTestSucceeded) -Details $vmIp

$healthPortTest = Test-NetConnection -ComputerName $vmIp -Port $HealthPort -WarningAction SilentlyContinue
Write-Marker -Name "HEALTH_PORT" -Pass ($healthPortTest.TcpTestSucceeded) -Details "$vmIp`:$HealthPort"

if ($healthPortTest.TcpTestSucceeded) {
    $uri = "https://$vmIp`:$HealthPort$HealthPath"
    try {
        $resp = Invoke-WebRequest -Uri $uri -TimeoutSec 20 -SkipCertificateCheck -ErrorAction Stop
        Write-Marker -Name "HEALTH_HTTP" -Pass ($resp.StatusCode -ge 200 -and $resp.StatusCode -lt 300) -Details ("Status={0}" -f $resp.StatusCode)
    }
    catch {
        Write-Marker -Name "HEALTH_HTTP" -Pass $false -Details $_.Exception.Message
    }
}

if ($HasFailures) {
    Write-Output "PROOF:RESULT=FAIL"
    exit 1
}

Write-Output "PROOF:RESULT=PASS"
exit 0
