[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = '',

    [Parameter()]
    [string]$ReleaseTag = '',

    [Parameter()]
    [string]$Repo = '',

    [Parameter()]
    [string]$SourceDirectory = 'deployment/vm-appliance/output',

    [Parameter()]
    [string]$StagingDirectory = 'artifacts/vm-release-release-assets',

    [Parameter()]
    [ValidateSet('auto', 'full', 'split')]
    [string]$UploadMode = 'auto',

    [Parameter()]
    [ValidateRange(100, 32768)]
    [int]$SplitPartSizeMB = 1900,

    [Parameter()]
    [ValidateRange(100, 32768)]
    [int]$SingleAssetLimitMB = 2000,

    [Parameter()]
    [switch]$CreateReleaseIfMissing,

    [Parameter()]
    [switch]$SkipUpload
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-WarnLine { param([string]$Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }

function Resolve-RepoSlug {
    param([string]$ExplicitRepo)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRepo)) {
        return $ExplicitRepo.Trim()
    }

    $origin = (& git config --get remote.origin.url 2>$null)
    if ([string]::IsNullOrWhiteSpace($origin)) {
        throw 'Unable to determine repository slug. Provide -Repo owner/name.'
    }

    $origin = $origin.Trim()
    if ($origin -match 'github\.com[:/](?<slug>[^/]+/[^/.]+)(?:\.git)?$') {
        return $Matches['slug']
    }

    throw "Unsupported remote URL format for GitHub repo detection: $origin"
}

function Resolve-Version {
    param(
        [string]$ExplicitVersion,
        [string]$RepoRoot
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitVersion)) {
        return $ExplicitVersion.Trim()
    }

    $versionFile = Join-Path $RepoRoot 'VERSION'
    if (-not (Test-Path -LiteralPath $versionFile)) {
        throw "VERSION file not found at: $versionFile"
    }

    $detected = (Get-Content -LiteralPath $versionFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($detected)) {
        throw 'VERSION file is empty. Provide -Version explicitly.'
    }

    return $detected
}

function Find-ArtifactFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Directory,
        [Parameter(Mandatory = $true)]
        [string]$Extension,
        [string[]]$PreferredNames = @(),
        [string]$VersionHint = ''
    )

    foreach ($name in $PreferredNames) {
        if ([string]::IsNullOrWhiteSpace($name)) {
            continue
        }
        $candidate = Join-Path $Directory $name
        if (Test-Path -LiteralPath $candidate) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    $fallback = @(Get-ChildItem -LiteralPath $Directory -File -Filter "*.$Extension" -ErrorAction SilentlyContinue)
    if (-not [string]::IsNullOrWhiteSpace($VersionHint)) {
        $byVersion = @($fallback | Where-Object { $_.Name -match [regex]::Escape($VersionHint) })
        if ($byVersion.Count -gt 0) {
            return ($byVersion | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
        }
    }

    if ($fallback.Count -gt 0) {
        return ($fallback | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
    }

    return $null
}

function Test-GitHubCliReady {
    Get-Command gh -ErrorAction Stop | Out-Null
    & gh auth status --hostname github.com *> $null
    if (-not $?) {
        throw 'GitHub CLI is not authenticated. Run: gh auth login'
    }
}

function Add-Sha256File {
    param([Parameter(Mandatory = $true)][string]$TargetFile)

    $item = Get-Item -LiteralPath $TargetFile
    if ($item.Extension -ieq '.sha256') {
        return
    }

    $hash = (Get-FileHash -LiteralPath $TargetFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $shaFile = "$TargetFile.sha256"
    Set-Content -LiteralPath $shaFile -Value "$hash  $($item.Name)" -Encoding ascii
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$resolvedVersion = Resolve-Version -ExplicitVersion $Version -RepoRoot $repoRoot
$resolvedTag = if ([string]::IsNullOrWhiteSpace($ReleaseTag)) { "v$resolvedVersion" } else { $ReleaseTag.Trim() }
$resolvedRepo = Resolve-RepoSlug -ExplicitRepo $Repo
$resolvedSourceDir = if ([System.IO.Path]::IsPathRooted($SourceDirectory)) {
    [System.IO.Path]::GetFullPath($SourceDirectory)
}
else {
    [System.IO.Path]::GetFullPath((Join-Path $repoRoot $SourceDirectory))
}
$resolvedStagingRoot = if ([System.IO.Path]::IsPathRooted($StagingDirectory)) {
    [System.IO.Path]::GetFullPath($StagingDirectory)
}
else {
    [System.IO.Path]::GetFullPath((Join-Path $repoRoot $StagingDirectory))
}
$resolvedStagingDir = Join-Path $resolvedStagingRoot $resolvedVersion

$splitScript = Join-Path $repoRoot 'tools/split-artifact-for-git.ps1'
$reassembleScript = Join-Path $repoRoot 'tools/reassemble-split-artifact.ps1'

if (-not (Test-Path -LiteralPath $resolvedSourceDir)) {
    throw "Source directory not found: $resolvedSourceDir"
}
if (-not (Test-Path -LiteralPath $splitScript)) {
    throw "Required split script not found: $splitScript"
}
if (-not (Test-Path -LiteralPath $reassembleScript)) {
    throw "Required reassemble script not found: $reassembleScript"
}

if (-not $SkipUpload) {
    Test-GitHubCliReady
}

Write-Step "Repo: $resolvedRepo"
Write-Step "Version: $resolvedVersion"
Write-Step "Release tag: $resolvedTag"
Write-Step "Source directory: $resolvedSourceDir"
Write-Step "Staging directory: $resolvedStagingDir"
Write-Step "Upload mode: $UploadMode"
if ($SkipUpload) {
    Write-WarnLine 'SkipUpload enabled: staging and metadata will be generated without release upload.'
}

if (Test-Path -LiteralPath $resolvedStagingDir) {
    Remove-Item -LiteralPath $resolvedStagingDir -Recurse -Force
}
$null = New-Item -ItemType Directory -Path $resolvedStagingDir -Force

$baseName = "security-audit-toolkit-$resolvedVersion"
$ovfPath = Find-ArtifactFile -Directory $resolvedSourceDir -Extension 'ovf' -PreferredNames @(
    "$baseName.ovf",
    ("SecurityAuditToolkit-{0}.ovf" -f $resolvedVersion)
) -VersionHint $resolvedVersion
$ovaPath = Find-ArtifactFile -Directory $resolvedSourceDir -Extension 'ova' -PreferredNames @(
    "$baseName.ova",
    ("SecurityAuditToolkit-{0}.ova" -f $resolvedVersion)
) -VersionHint $resolvedVersion
$vmdkPath = Find-ArtifactFile -Directory $resolvedSourceDir -Extension 'vmdk' -PreferredNames @(
    "$baseName.vmdk",
    ("SecurityAuditToolkit-{0}.vmdk" -f $resolvedVersion)
) -VersionHint $resolvedVersion
$mfPath = Find-ArtifactFile -Directory $resolvedSourceDir -Extension 'mf' -PreferredNames @(
    "$baseName.mf"
) -VersionHint $resolvedVersion
$vhdxCandidates = @(Get-ChildItem -LiteralPath $resolvedSourceDir -File -Filter '*.vhdx' -ErrorAction SilentlyContinue)

if ($vhdxCandidates.Count -gt 0) {
    $names = @($vhdxCandidates | Sort-Object Name | ForEach-Object { $_.Name }) -join ', '
    Write-WarnLine "Ignoring VHDX build inputs in source directory: $names"
}

$artifactsFound = @{}
if ($ovfPath) { $artifactsFound.ovf = $ovfPath }
if ($ovaPath) { $artifactsFound.ova = $ovaPath }
if ($vmdkPath) { $artifactsFound.vmdk = $vmdkPath }

if ($artifactsFound.Count -eq 0) {
    throw "No VM artifacts found in $resolvedSourceDir"
}

$singleAssetLimitBytes = [int64]$SingleAssetLimitMB * 1MB
$index = [ordered]@{
    version = $resolvedVersion
    release_tag = $resolvedTag
    repo = $resolvedRepo
    generated_utc = (Get-Date).ToUniversalTime().ToString('o')
    source_directory = $resolvedSourceDir
    upload_mode = $UploadMode
    split_part_size_mb = $SplitPartSizeMB
    single_asset_limit_mb = $SingleAssetLimitMB
    artifacts = [ordered]@{}
    notes = @(
        'Use this index with release assets to deliver VM artifacts without storing binaries in git main.',
        'For split artifacts, download all .partNNN files and the .parts.json manifest, then reassemble with reassemble-split-artifact.ps1.'
    )
}

foreach ($type in @('ovf', 'ova', 'vmdk')) {
    if (-not $artifactsFound.ContainsKey($type)) {
        continue
    }

    $sourcePath = $artifactsFound[$type]
    $sourceItem = Get-Item -LiteralPath $sourcePath
    $deliveryMode = 'full'

    if ($type -ne 'ovf') {
        if ($UploadMode -eq 'split') {
            $deliveryMode = 'split'
        }
        elseif ($UploadMode -eq 'auto' -and $sourceItem.Length -gt $singleAssetLimitBytes) {
            $deliveryMode = 'split'
        }
    }

    Write-Step "Preparing $($sourceItem.Name) as $deliveryMode delivery"

    if ($deliveryMode -eq 'split') {
        & $splitScript -FilePath $sourcePath -PartSizeMB $SplitPartSizeMB -OutputDirectory $resolvedStagingDir -Force
        if (-not $?) {
            throw "Split failed for $($sourceItem.Name)"
        }

        $partPattern = "{0}.part*" -f $sourceItem.Name
        $parts = @(Get-ChildItem -LiteralPath $resolvedStagingDir -File -Filter $partPattern | Sort-Object Name)
        $manifestName = "{0}.parts.json" -f $sourceItem.Name
        $manifestPath = Join-Path $resolvedStagingDir $manifestName
        if (-not (Test-Path -LiteralPath $manifestPath)) {
            throw "Split manifest missing after split: $manifestPath"
        }

        $index.artifacts[$type] = [ordered]@{
            source_file = $sourceItem.Name
            source_size_bytes = [int64]$sourceItem.Length
            delivery = 'split'
            split_parts = $parts.Count
            manifest_asset = $manifestName
            part_assets = @($parts | ForEach-Object { $_.Name })
            release_download_base = "https://github.com/$resolvedRepo/releases/download/$resolvedTag/"
            reassemble_hint_windows = "pwsh -File .\\reassemble-split-artifact.ps1 -InputPath .\\$manifestName"
            reassemble_hint_linux = "pwsh -File ./reassemble-split-artifact.ps1 -InputPath ./$manifestName"
        }
    }
    else {
        $destPath = Join-Path $resolvedStagingDir $sourceItem.Name
        Copy-Item -LiteralPath $sourcePath -Destination $destPath -Force

        $index.artifacts[$type] = [ordered]@{
            source_file = $sourceItem.Name
            source_size_bytes = [int64]$sourceItem.Length
            delivery = 'full'
            asset = $sourceItem.Name
            direct_url = "https://github.com/$resolvedRepo/releases/download/$resolvedTag/$($sourceItem.Name)"
        }
    }
}

if ($mfPath) {
    $mfItem = Get-Item -LiteralPath $mfPath
    Copy-Item -LiteralPath $mfItem.FullName -Destination (Join-Path $resolvedStagingDir $mfItem.Name) -Force
    $index['ovf_manifest_asset'] = $mfItem.Name
}

Copy-Item -LiteralPath $reassembleScript -Destination (Join-Path $resolvedStagingDir 'reassemble-split-artifact.ps1') -Force

$indexPath = Join-Path $resolvedStagingDir "vm-release-index-$resolvedVersion.json"
$index | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $indexPath -Encoding UTF8

$instructionsPath = Join-Path $resolvedStagingDir "VM-RELEASE-ASSETS-$resolvedVersion.md"
$instructions = New-Object System.Collections.Generic.List[string]
$instructions.Add("# VM Release Assets - $resolvedVersion") | Out-Null
$instructions.Add('') | Out-Null
$instructions.Add("Release: $resolvedTag") | Out-Null
$instructions.Add("Repo: $resolvedRepo") | Out-Null
$instructions.Add('') | Out-Null
$instructions.Add('## Quick download') | Out-Null
$instructions.Add('') | Out-Null
$instructions.Add("gh release download $resolvedTag --repo $resolvedRepo -D .") | Out-Null
$instructions.Add('') | Out-Null
$instructions.Add('## Reassemble split artifacts') | Out-Null
$instructions.Add('') | Out-Null
foreach ($type in @('ova', 'vmdk')) {
    if (-not $index.artifacts.Contains($type)) {
        continue
    }
    $entry = $index.artifacts[$type]
    if ($entry.delivery -ne 'split') {
        continue
    }
    $manifestAsset = [string]$entry.manifest_asset
    $instructions.Add(('- {0}: pwsh -File .\\reassemble-split-artifact.ps1 -InputPath .\\{1}' -f $type, $manifestAsset)) | Out-Null
}
$instructions.Add('') | Out-Null
$instructions.Add('## Integrity') | Out-Null
$instructions.Add('') | Out-Null
$instructions.Add('Each uploaded asset includes a `.sha256` sidecar file.') | Out-Null
Set-Content -LiteralPath $instructionsPath -Value ($instructions -join [Environment]::NewLine) -Encoding UTF8

$stagedFiles = @(Get-ChildItem -LiteralPath $resolvedStagingDir -File)
foreach ($file in $stagedFiles) {
    Add-Sha256File -TargetFile $file.FullName
}

$uploadFiles = @(Get-ChildItem -LiteralPath $resolvedStagingDir -File | Sort-Object Name)

if (-not $SkipUpload) {
    Write-Step 'Checking release existence...'
    & gh release view $resolvedTag --repo $resolvedRepo *> $null
    $releaseExists = $?

    if (-not $releaseExists) {
        if (-not $CreateReleaseIfMissing) {
            throw "Release $resolvedTag does not exist. Re-run with -CreateReleaseIfMissing to create it automatically."
        }

        Write-Step "Creating release $resolvedTag"
        & gh release create $resolvedTag --repo $resolvedRepo --title "Security Audit Toolkit $resolvedVersion" --notes "VM appliance artifacts for $resolvedVersion" --draft
        if (-not $?) {
            throw "Failed to create release $resolvedTag"
        }
    }

    Write-Step 'Uploading staged assets to GitHub Release...'
    foreach ($file in $uploadFiles) {
        Write-Step "Uploading $($file.Name)"
        & gh release upload $resolvedTag $file.FullName --repo $resolvedRepo --clobber
        if (-not $?) {
            throw "Failed to upload release asset: $($file.FullName)"
        }
    }
    Write-Ok 'Release upload complete'
}
else {
    Write-Ok 'SkipUpload mode complete (assets staged only)'
}

Write-Ok "Staged files: $($uploadFiles.Count)"
Write-Ok "Index: $indexPath"

if ($index.artifacts.Contains('ovf') -and $index.artifacts.ovf.delivery -eq 'full') {
    Write-Output "ENV:VM_APPLIANCE_OVF_URL=$($index.artifacts.ovf.direct_url)"
}
if ($index.artifacts.Contains('ova') -and $index.artifacts.ova.delivery -eq 'full') {
    Write-Output "ENV:VM_APPLIANCE_OVA_URL=$($index.artifacts.ova.direct_url)"
}
if ($index.artifacts.Contains('vmdk') -and $index.artifacts.vmdk.delivery -eq 'full') {
    Write-Output "ENV:VM_APPLIANCE_VMDK_URL=$($index.artifacts.vmdk.direct_url)"
}

if (($index.artifacts.Contains('ova') -and $index.artifacts.ova.delivery -eq 'split') -or
    ($index.artifacts.Contains('vmdk') -and $index.artifacts.vmdk.delivery -eq 'split')) {
    Write-WarnLine 'OVA/VMDK were uploaded as split assets due size constraints. Use release asset download + reassemble-split-artifact.ps1 for customer delivery.'
}

Write-Output "PUBLISH:RESULT=PASS;VERSION=$resolvedVersion;TAG=$resolvedTag;REPO=$resolvedRepo;STAGING=$resolvedStagingDir"

