[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath,

    [Parameter()]
    [string]$OutputPath = '',

    [Parameter()]
    [switch]$VerifyOnly,

    [Parameter()]
    [switch]$SkipPartHashValidation,

    [Parameter()]
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }

function Resolve-ManifestPath {
    param([string]$PathInput)

    $candidate = $PathInput
    if (-not [System.IO.Path]::IsPathRooted($candidate)) {
        $candidate = [System.IO.Path]::GetFullPath($candidate)
    }

    if ($candidate.EndsWith('.parts.json', [System.StringComparison]::OrdinalIgnoreCase)) {
        if (-not (Test-Path -LiteralPath $candidate)) {
            throw "Manifest not found: $candidate"
        }
        return (Resolve-Path -LiteralPath $candidate).Path
    }

    $manifestCandidate = "$candidate.parts.json"
    if (Test-Path -LiteralPath $manifestCandidate) {
        return (Resolve-Path -LiteralPath $manifestCandidate).Path
    }

    throw "Unable to locate manifest. Provide a .parts.json path or a source artifact path with adjacent .parts.json manifest."
}

function Convert-HashToHexLower {
    param([byte[]]$HashBytes)
    return ([BitConverter]::ToString($HashBytes)).Replace('-', '').ToLowerInvariant()
}

function Get-StreamingCombinedHashAndSize {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$PartPaths,
        [Parameter()]
        [System.IO.FileStream]$OutputStream
    )

    $sha = [System.Security.Cryptography.SHA256]::Create()
    $buffer = New-Object byte[] (4MB)
    $totalBytes = [int64]0

    foreach ($partPath in $PartPaths) {
        $partStream = [System.IO.File]::Open($partPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
        try {
            while (($read = $partStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                $null = $sha.TransformBlock($buffer, 0, $read, $null, 0)
                $totalBytes += $read
                if ($OutputStream) {
                    $OutputStream.Write($buffer, 0, $read)
                }
            }
        }
        finally {
            $partStream.Dispose()
        }
    }

    $null = $sha.TransformFinalBlock([byte[]]::new(0), 0, 0)
    return [PSCustomObject]@{
        Sha256Hex = Convert-HashToHexLower -HashBytes $sha.Hash
        TotalBytes = $totalBytes
    }
}

$manifestPath = Resolve-ManifestPath -PathInput $InputPath
$manifestDir = Split-Path -Parent $manifestPath

$manifestRaw = Get-Content -LiteralPath $manifestPath -Raw
$manifest = $manifestRaw | ConvertFrom-Json

$sourceFileName = [string]$manifest.source_file
if ([string]::IsNullOrWhiteSpace($sourceFileName)) {
    $sourceFileName = [System.IO.Path]::GetFileNameWithoutExtension([System.IO.Path]::GetFileNameWithoutExtension($manifestPath))
}

$expectedSourceHash = [string]$manifest.source_sha256
$expectedSourceHash = if ([string]::IsNullOrWhiteSpace($expectedSourceHash)) { '' } else { $expectedSourceHash.ToLowerInvariant() }

$expectedSourceSize = [int64]0
if ($null -ne $manifest.source_size_bytes) {
    $expectedSourceSize = [int64]$manifest.source_size_bytes
}

$partEntries = @($manifest.parts)
if ($partEntries.Count -eq 0) {
    $partEntries = @(
        Get-ChildItem -LiteralPath $manifestDir -File -ErrorAction Stop |
            Where-Object { $_.Name -match "^$([regex]::Escape($sourceFileName))\.part\d+$" } |
            Sort-Object Name |
            ForEach-Object {
                [PSCustomObject]@{
                    name = $_.Name
                    sha256 = ''
                }
            }
    )
}

if ($partEntries.Count -eq 0) {
    throw "No part entries found in manifest and no fallback part files detected for '$sourceFileName'."
}

$resolvedPartPaths = New-Object System.Collections.Generic.List[string]
foreach ($entry in $partEntries) {
    $partName = [string]$entry.name
    if ([string]::IsNullOrWhiteSpace($partName)) {
        throw "Manifest contains an empty part name entry."
    }

    $partPath = Join-Path $manifestDir $partName
    if (-not (Test-Path -LiteralPath $partPath)) {
        throw "Missing part file referenced by manifest: $partName"
    }
    $resolvedPartPaths.Add((Resolve-Path -LiteralPath $partPath).Path) | Out-Null
}

if (-not $SkipPartHashValidation) {
    Write-Step "Validating per-part hashes from manifest..."
    for ($i = 0; $i -lt $partEntries.Count; $i++) {
        $entry = $partEntries[$i]
        $expectedPartHash = [string]$entry.sha256
        if ([string]::IsNullOrWhiteSpace($expectedPartHash)) {
            continue
        }

        $actualPartHash = (Get-FileHash -LiteralPath $resolvedPartPaths[$i] -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualPartHash -ne $expectedPartHash.ToLowerInvariant()) {
            throw "Part hash mismatch for '$($entry.name)'. Expected $expectedPartHash, got $actualPartHash"
        }
    }
    Write-Ok "Part hashes validated"
}

if ($VerifyOnly) {
    Write-Step "Computing combined source hash (verify-only mode)..."
    $combined = Get-StreamingCombinedHashAndSize -PartPaths $resolvedPartPaths

    if ($expectedSourceSize -gt 0 -and $combined.TotalBytes -ne $expectedSourceSize) {
        throw "Reassembled size mismatch. Expected $expectedSourceSize bytes, got $($combined.TotalBytes) bytes."
    }

    if (-not [string]::IsNullOrWhiteSpace($expectedSourceHash) -and $combined.Sha256Hex -ne $expectedSourceHash) {
        throw "Reassembled hash mismatch. Expected $expectedSourceHash, got $($combined.Sha256Hex)."
    }

    Write-Ok "Verify-only integrity check passed"
    Write-Output "JOIN:RESULT=PASS;MODE=VERIFY_ONLY;FILE=$sourceFileName;PARTS=$($resolvedPartPaths.Count);SHA256=$($combined.Sha256Hex)"
    exit 0
}

$targetPath = if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    Join-Path $manifestDir $sourceFileName
}
else {
    [System.IO.Path]::GetFullPath($OutputPath)
}

$targetDir = Split-Path -Parent $targetPath
if (-not (Test-Path -LiteralPath $targetDir)) {
    $null = New-Item -ItemType Directory -Path $targetDir -Force
}

if ((Test-Path -LiteralPath $targetPath) -and -not $Force) {
    throw "Output file already exists: $targetPath (use -Force to overwrite)"
}

$tmpPath = "$targetPath.reassemble.tmp"
Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue

Write-Step "Reassembling $sourceFileName from $($resolvedPartPaths.Count) parts..."
$outputStream = [System.IO.File]::Open($tmpPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
try {
    $combined = Get-StreamingCombinedHashAndSize -PartPaths $resolvedPartPaths -OutputStream $outputStream
}
finally {
    $outputStream.Dispose()
}

if ($expectedSourceSize -gt 0 -and $combined.TotalBytes -ne $expectedSourceSize) {
    Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
    throw "Reassembled size mismatch. Expected $expectedSourceSize bytes, got $($combined.TotalBytes) bytes."
}

if (-not [string]::IsNullOrWhiteSpace($expectedSourceHash) -and $combined.Sha256Hex -ne $expectedSourceHash) {
    Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
    throw "Reassembled hash mismatch. Expected $expectedSourceHash, got $($combined.Sha256Hex)."
}

if (Test-Path -LiteralPath $targetPath) {
    Remove-Item -LiteralPath $targetPath -Force
}
Move-Item -LiteralPath $tmpPath -Destination $targetPath -Force

Write-Ok "Reassembled artifact written: $targetPath"
Write-Output "JOIN:RESULT=PASS;MODE=REASSEMBLE;FILE=$sourceFileName;PARTS=$($resolvedPartPaths.Count);SHA256=$($combined.Sha256Hex);OUTPUT=$targetPath"

