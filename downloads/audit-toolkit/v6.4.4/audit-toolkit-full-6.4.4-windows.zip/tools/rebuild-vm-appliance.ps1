<#
.SYNOPSIS
    Wrapper to build Security Audit Toolkit VM appliance (VHDX + conversion guidance).

.DESCRIPTION
    Calls deployment/vm-appliance/Build-VMAppliance.ps1 with ExportFormat=All by default.
    Produces VHDX output and automatically packages OVF/OVA from VMDK without VMware OVF Tool.

.PARAMETER Version
    Toolkit version to install (default: value from VERSION file).

.PARAMETER ISOPath
    Path to Ubuntu Server ISO, or directory containing Ubuntu Server ISOs.
    When a directory is provided, the latest ubuntu-*-live-server-amd64.iso is selected.

.PARAMETER OutputPath
    Output directory for artifacts (default: deployment/vm-appliance/output).

.PARAMETER VHDStoragePath
    Directory used for VM virtual hard disk files (default: C:\Hyper-V\Virtual Hard Disks).

.PARAMETER VMName
    Name for the appliance VM (default: AuditToolkit-Appliance-Base).

.PARAMETER MemoryGB
    Memory in GB (default: 4).

.PARAMETER DiskSizeGB
    Disk size in GB (default: 50).

.PARAMETER CPUCount
    Virtual CPU count (default: 2).

.PARAMETER SwitchName
    Hyper-V virtual switch name (default: AuditLabSwitch).

.PARAMETER SkipInstall
    Skip install phase if VM already prepared.

.PARAMETER Force
    Remove and recreate VM if it already exists.

.PARAMETER AutoInstall
    Request unattended Ubuntu installation. This currently requires custom autoinstall
    media and is validated by the underlying builder.

.PARAMETER SplitForGit
    Split large output artifacts into .partNNN chunks for Git-safe commits.

.PARAMETER SplitPartSizeMB
    Target part size in MB when SplitForGit is enabled (default: 1900).

.EXAMPLE
    .\tools\rebuild-vm-appliance.ps1 -Version "6.0.0"
#>

#Requires -RunAsAdministrator
#Requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = "",

    [Parameter()]
    [string]$ISOPath = "D:\ISO",

    [Parameter()]
    [string]$OutputPath = "",

    [Parameter()]
    [string]$VHDStoragePath = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [string]$VMName = "",

    [Parameter()]
    [int]$MemoryGB = 4,

    [Parameter()]
    [int]$DiskSizeGB = 50,

    [Parameter()]
    [int]$CPUCount = 2,

    [Parameter()]
    [string]$SwitchName = "AuditLabSwitch",

    [Parameter()]
    [switch]$SkipInstall,

    [Parameter()]
    [switch]$Force,

    [Parameter()]
    [switch]$AutoInstall,

    [Parameter()]
    [switch]$SplitForGit,

    [Parameter()]
    [int]$SplitPartSizeMB = 1900
)

$ErrorActionPreference = "Stop"
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptRoot
$BuildScript = Join-Path $RepoRoot "deployment\vm-appliance\Build-VMAppliance.ps1"
$PackageScript = Join-Path $RepoRoot "tools\package-ova-from-vmdk.ps1"
$SplitScript = Join-Path $RepoRoot "tools\split-artifact-for-git.ps1"

if (-not $Version) {
    $versionFile = Join-Path $RepoRoot "VERSION"
    if (Test-Path -LiteralPath $versionFile) {
        $Version = (Get-Content -LiteralPath $versionFile -Raw).Trim()
    }

    if (-not $Version) {
        $Version = "6.0.0"
    }
}

function Resolve-NormalizedPath {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $candidate = $PathValue.Replace('/', '\\')
    return [System.IO.Path]::GetFullPath($candidate)
}

function Assert-DriveAccessible {
    param(
        [Parameter(Mandatory = $true)][string]$PathValue,
        [Parameter(Mandatory = $true)][string]$Label
    )

    $qualifier = Split-Path -Path $PathValue -Qualifier
    if ([string]::IsNullOrWhiteSpace($qualifier)) {
        return
    }

    $driveRoot = "$qualifier\\"
    try {
        $null = Get-Item -LiteralPath $driveRoot -ErrorAction Stop
    }
    catch {
        throw "$Label path uses inaccessible drive '$qualifier'. Use a local writable drive path (for example D:\\ISO or C:\\Hyper-V\\Virtual Hard Disks)."
    }
}

function Resolve-LatestUbuntuIso {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $normalizedInput = Resolve-NormalizedPath -PathValue $PathValue

    if (Test-Path -LiteralPath $normalizedInput -PathType Leaf) {
        return [System.IO.Path]::GetFullPath($normalizedInput).Replace('/', '\\')
    }

    $candidateDirs = @()
    if (Test-Path -LiteralPath $normalizedInput -PathType Container) {
        $candidateDirs += $normalizedInput
    }
    else {
        $parentDir = Split-Path -Path $normalizedInput -Parent
        if (-not [string]::IsNullOrWhiteSpace($parentDir) -and (Test-Path -LiteralPath $parentDir -PathType Container)) {
            $candidateDirs += $parentDir
        }
    }

    if ($candidateDirs.Count -eq 0) {
        throw "ISO path not found: $normalizedInput. Provide a valid ISO file path or an ISO directory (for example D:\\ISO)."
    }

    $isoCandidates = @()
    foreach ($dir in $candidateDirs) {
        $isoCandidates += Get-ChildItem -LiteralPath $dir -File -Filter 'ubuntu-*-live-server-amd64.iso' -ErrorAction SilentlyContinue
    }

    if ($isoCandidates.Count -eq 0) {
        foreach ($dir in $candidateDirs) {
            $isoCandidates += Get-ChildItem -LiteralPath $dir -File -Filter 'ubuntu-*.iso' -ErrorAction SilentlyContinue
        }
    }

    if ($isoCandidates.Count -eq 0) {
        throw "No Ubuntu ISO files found in '$($candidateDirs -join ', ')'. Expected names like ubuntu-24.04.3-live-server-amd64.iso."
    }

    $rankedCandidates = foreach ($iso in $isoCandidates) {
        $versionValue = [version]'0.0.0'
        $versionMatch = [regex]::Match($iso.Name, 'ubuntu-(?<ver>\d+\.\d+(?:\.\d+)?)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($versionMatch.Success) {
            $rawVersion = $versionMatch.Groups['ver'].Value
            $parts = $rawVersion.Split('.')
            if ($parts.Count -eq 2) {
                $rawVersion = "$rawVersion.0"
            }
            try {
                $versionValue = [version]$rawVersion
            }
            catch { Write-Verbose 'Suppressed non-fatal error.' }
        }

        [PSCustomObject]@{
            FullName = $iso.FullName
            Version = $versionValue
            LastWriteTimeUtc = $iso.LastWriteTimeUtc
        }
    }

    $selected = $rankedCandidates |
        Sort-Object -Property @{ Expression = { $_.Version }; Descending = $true }, @{ Expression = { $_.LastWriteTimeUtc }; Descending = $true }, @{ Expression = { $_.FullName }; Descending = $false } |
        Select-Object -First 1

    if (-not $selected) {
        throw "Unable to resolve Ubuntu ISO from '$($candidateDirs -join ', ')'."
    }

    return [System.IO.Path]::GetFullPath($selected.FullName).Replace('/', '\\')
}

if (-not (Test-Path $BuildScript)) {
    throw "Build script not found: $BuildScript"
}

if (-not $OutputPath) {
    $OutputPath = Join-Path $RepoRoot "deployment\vm-appliance\output"
}

$ISOPath = Resolve-LatestUbuntuIso -PathValue $ISOPath
$OutputPath = Resolve-NormalizedPath -PathValue $OutputPath
$VHDStoragePath = Resolve-NormalizedPath -PathValue $VHDStoragePath

Assert-DriveAccessible -PathValue $ISOPath -Label "ISO"
Assert-DriveAccessible -PathValue $OutputPath -Label "Output"
Assert-DriveAccessible -PathValue $VHDStoragePath -Label "VHD storage"

$OutputPath = [System.IO.Path]::GetFullPath($OutputPath).Replace('/', '\\')
$VHDStoragePath = [System.IO.Path]::GetFullPath($VHDStoragePath).Replace('/', '\\')
$ISOPath = [System.IO.Path]::GetFullPath($ISOPath).Replace('/', '\\')

$resolvedVMName = if ($VMName) { $VMName } else { "AuditToolkit-Appliance-Base" }

Write-Output ""
Write-Output "=== VM Appliance Rebuild (VHDX + conversion guidance) ==="
Write-Output "Version:     $Version"
Write-Output "ISO Path:    $ISOPath"
Write-Output "Output Path: $OutputPath"
Write-Output "VHD Path:    $VHDStoragePath"
Write-Output "VM Name:     $resolvedVMName"
Write-Output ""

$buildArgs = @{
    Version = $Version
    ISOPath = $ISOPath
    OutputPath = $OutputPath
    VHDStoragePath = $VHDStoragePath
    MemoryGB = $MemoryGB
    DiskSizeGB = $DiskSizeGB
    CPUCount = $CPUCount
    SwitchName = $SwitchName
    ExportFormat = "All"
}

if ($VMName) { $buildArgs.VMName = $VMName }
if ($SkipInstall) { $buildArgs.SkipInstall = $true }
if ($Force) { $buildArgs.Force = $true }
if ($AutoInstall) { $buildArgs.AutoInstall = $true }

try {
    & $BuildScript @buildArgs
}
catch {
    throw "VM appliance build failed: $_"
}

if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) {
    throw "VM appliance build exited with code $LASTEXITCODE"
}

$sourceSetupScript = Join-Path $RepoRoot "deployment\vm-appliance\scripts\appliance-setup.sh"
$outputSetupScript = Join-Path $OutputPath "appliance-setup.sh"
if (Test-Path $sourceSetupScript) {
    Copy-Item -Path $sourceSetupScript -Destination $outputSetupScript -Force
    Write-Output "Refreshed appliance setup artifact from source: $sourceSetupScript"
} else {
    Write-Warning "Canonical appliance setup script not found: $sourceSetupScript"
}

if (Test-Path $PackageScript) {
    try {
        $resolvedSourceVhdxPath = Join-Path $VHDStoragePath "$resolvedVMName.vhdx"

        & $PackageScript `
            -Version $Version `
            -OutputPath $OutputPath `
            -VMName $resolvedVMName `
            -SourceVmdkName "$resolvedVMName.vmdk" `
            -SourceVhdxName "$resolvedVMName.vhdx" `
            -SourceVhdxPath $resolvedSourceVhdxPath
    }
    catch {
        Write-Warning "Build completed, but OVF/OVA packaging failed: $_"
    }
} else {
    Write-Warning "Build completed, but OVF/OVA packager script not found: $PackageScript"
}

if ($SplitForGit) {
    if (-not (Test-Path $SplitScript)) {
        Write-Warning "Split requested, but splitter script not found: $SplitScript"
    }
    else {
        $artifactCandidates = @(
            (Join-Path $OutputPath "security-audit-toolkit-$Version.ova"),
            (Join-Path $OutputPath "security-audit-toolkit-$Version.vmdk"),
            (Join-Path $OutputPath "$resolvedVMName.ova"),
            (Join-Path $OutputPath "$resolvedVMName.vmdk")
        )

        $seen = @{}
        foreach ($artifact in $artifactCandidates) {
            if (-not $artifact) { continue }
            if ($seen.ContainsKey($artifact)) { continue }
            $seen[$artifact] = $true

            if (Test-Path $artifact) {
                & $SplitScript -FilePath $artifact -PartSizeMB $SplitPartSizeMB
            }
        }
    }
}

Write-Output ""
Write-Output "✅ Build complete. Check output artifacts in: $OutputPath"

