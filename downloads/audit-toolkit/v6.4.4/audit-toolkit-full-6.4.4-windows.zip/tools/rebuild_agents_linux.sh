#!/usr/bin/env bash
set -euo pipefail

SPLIT_FOR_GIT="${SPLIT_FOR_GIT:-false}"
SPLIT_PART_SIZE_MB="${SPLIT_PART_SIZE_MB:-1900}"

split_artifact_for_git() {
	local file_path="$1"

	if [[ "$SPLIT_FOR_GIT" != "true" ]]; then
		return 0
	fi

	if [[ ! -f "$file_path" ]]; then
		echo "[WARN] split skipped, missing file: $file_path"
		return 0
	fi

	if ! [[ "$SPLIT_PART_SIZE_MB" =~ ^[0-9]+$ ]] || ((SPLIT_PART_SIZE_MB < 50)); then
		echo "[ERROR] SPLIT_PART_SIZE_MB must be integer >= 50"
		return 1
	fi

	local file_size part_size_bytes
	file_size=$(stat -f%z "$file_path" 2>/dev/null || stat -c%s "$file_path" 2>/dev/null || echo 0)
	part_size_bytes=$((SPLIT_PART_SIZE_MB * 1024 * 1024))

	if ((file_size <= part_size_bytes)); then
		echo "SPLIT:SKIP=TRUE;FILE=$(basename "$file_path");SIZE_BYTES=${file_size}"
		return 0
	fi

	rm -f "${file_path}.part"* "${file_path}.parts.txt"
	split -b "${SPLIT_PART_SIZE_MB}m" -d -a 3 "$file_path" "${file_path}.part"

	local idx=1
	while IFS= read -r part; do
		local renamed
		renamed="${file_path}.part$(printf '%03d' "$idx")"
		mv -f "$part" "$renamed"
		idx=$((idx + 1))
	done < <(find "$(dirname "$file_path")" -maxdepth 1 -type f -name "$(basename "$file_path").part[0-9][0-9][0-9]" | sort)

	local part_count
	part_count=$((idx - 1))
	{
		echo "source=$(basename "$file_path")"
		echo "size_bytes=${file_size}"
		echo "part_size_mb=${SPLIT_PART_SIZE_MB}"
		echo "part_count=${part_count}"
		echo "generated_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
		find "$(dirname "$file_path")" -maxdepth 1 -type f -name "$(basename "$file_path").part[0-9][0-9][0-9]" -print0 | sort -z | xargs -0 sha256sum
	} > "${file_path}.parts.txt"

	echo "SPLIT:RESULT=PASS;FILE=$(basename "$file_path");PARTS=${part_count};PART_SIZE_MB=${SPLIT_PART_SIZE_MB}"
}

cd /mnt/c/Github/Audit-Tool-
version="$(tr -d '\r\n' < VERSION)"
out="deployment/agents"

rm -f "$out/standalone-agent-linux-$version.tar.gz" "$out/fleet-agent-linux-$version.tar.gz" "unified-jre-agent-$version.tar.gz"

tar -czf "$out/standalone-agent-linux-$version.tar.gz" -C "$out/_build/lightweight-linux" .
tar -czf "$out/fleet-agent-linux-$version.tar.gz" -C "$out/_build/managed-linux" .

split_artifact_for_git "$out/standalone-agent-linux-$version.tar.gz"
split_artifact_for_git "$out/fleet-agent-linux-$version.tar.gz"

./build_unified_jre_agent.sh

split_artifact_for_git "unified-jre-agent-$version.tar.gz"

echo "=== linux agent artifacts ==="
ls -lh "$out"/*linux-"$version".tar.gz

echo "=== unified jre bundle ==="
ls -lh "unified-jre-agent-$version.tar.gz"
