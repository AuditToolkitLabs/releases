import argparse
import base64
import os
import secrets
import shlex
import ssl
import sys
import textwrap
import time
import urllib.error
import urllib.request
from pathlib import Path

import paramiko


def env_default(name: str, fallback: str) -> str:
    value = os.environ.get(name)
    return value if value else fallback


def run_remote_script(client: paramiko.SSHClient, sudo_password: str, script: str, timeout: int = 3600) -> tuple[int, str, str]:
    encoded = base64.b64encode(script.encode("utf-8")).decode("ascii")
    password_arg = shlex.quote(sudo_password)
    cmd = f"printf %s {password_arg} | sudo -S -p '' bash -lc \"echo {encoded} | base64 -d | bash\""
    _, stdout, stderr = client.exec_command(cmd, timeout=timeout)  # nosec B601 - command is constructed from controlled local script content
    out = stdout.read().decode("utf-8", "ignore")
    err = stderr.read().decode("utf-8", "ignore")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def run_remote_command(client: paramiko.SSHClient, sudo_password: str, command: str, timeout: int = 120) -> tuple[int, str, str]:
    password_arg = shlex.quote(sudo_password)
    cmd = f"printf %s {password_arg} | sudo -S -p '' bash -lc {shlex.quote(command)}"
    _, stdout, stderr = client.exec_command(cmd, timeout=timeout)  # nosec B601 - command is shell-quoted and used in controlled operator workflow
    out = stdout.read().decode("utf-8", "ignore")
    err = stderr.read().decode("utf-8", "ignore")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def sftp_upload(client: paramiko.SSHClient, local_path: Path, remote_path: str) -> None:
    sftp = client.open_sftp()
    try:
        sftp.put(str(local_path), remote_path)
    finally:
        sftp.close()


def build_redeploy_script(flask_secret: str) -> str:
    script_template = """
        set -euo pipefail
        export DEBIAN_FRONTEND=noninteractive

        APP_USER="auditadmin"
        INSTALL_DIR="/opt/audit-toolkit"
        ARCHIVE_PATH="/tmp/audit-toolkit-src-head.tar.gz"  # nosec B108 - deterministic remote temp path for appliance bootstrap
        DB_USER="audittoolkit"
        DB_PASS="Atk!7Xq3vL9mP2_kZ5nR8"
        DB_NAME="audittoolkit"
        DATABASE_URL="postgresql://${{DB_USER}}:${{DB_PASS}}@localhost:5432/${{DB_NAME}}"
        DISCOVERY_PORT="18080"

        echo "[1/13] Stop existing services"
        systemctl stop audit-toolkit audit-toolkit-celery audit-toolkit-celery-beat audit-toolkit-discovery nginx 2>/dev/null || true
        systemctl disable audit-toolkit audit-toolkit-celery audit-toolkit-celery-beat audit-toolkit-discovery 2>/dev/null || true
                pkill -f "/opt/audit-toolkit/.venv/bin/gunicorn" 2>/dev/null || true
                pkill -f "/opt/audit-toolkit/.venv/bin/python -m src.app" 2>/dev/null || true
                if command -v fuser >/dev/null 2>&1; then
                    fuser -k 8000/tcp 2>/dev/null || true
                    fuser -k 8080/tcp 2>/dev/null || true
                    fuser -k 18080/tcp 2>/dev/null || true
                fi

        echo "[2/13] Remove previous units/config"
        rm -f /etc/systemd/system/audit-toolkit.service
        rm -f /etc/systemd/system/audit-toolkit-celery.service
        rm -f /etc/systemd/system/audit-toolkit-celery-beat.service
        rm -f /etc/systemd/system/audit-toolkit-discovery.service
        rm -f /etc/nginx/sites-enabled/audit-toolkit
        rm -f /etc/nginx/sites-available/audit-toolkit
        systemctl daemon-reload

        echo "[3/13] Remove previous install"
        rm -rf "$INSTALL_DIR"
        mkdir -p "$INSTALL_DIR"

        echo "[4/13] Install dependencies"
        apt-get update -qq
        apt-get install -y -qq \
          python3 python3-pip python3-venv \
          postgresql postgresql-contrib redis-server \
                    nginx ufw fail2ban openssl

        echo "[5/13] Ensure app user"
        if ! id "$APP_USER" >/dev/null 2>&1; then
          useradd -m -s /bin/bash "$APP_USER"
        fi

        echo "[6/13] Deploy source archive"
        tar -xzf "$ARCHIVE_PATH" -C "$INSTALL_DIR"
        rm -f "$INSTALL_DIR/audit_toolkit.db" "$INSTALL_DIR/web/audit_toolkit.db" "$INSTALL_DIR/web/instance/audit_toolkit.db"
        rm -f "$INSTALL_DIR/web/migrations/alembic_version" 2>/dev/null || true

                echo "[7/13] Python environment"
        python3 -m venv "$INSTALL_DIR/.venv"
                if [ ! -x "$INSTALL_DIR/.venv/bin/pip" ]; then
                    "$INSTALL_DIR/.venv/bin/python" -m ensurepip --upgrade || true
                fi
                "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet --upgrade pip setuptools wheel
        if [ -f "$INSTALL_DIR/requirements_frozen.txt" ]; then
                    "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet -r "$INSTALL_DIR/requirements_frozen.txt" || "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet -r "$INSTALL_DIR/requirements.txt"
        else
                    "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet -r "$INSTALL_DIR/requirements.txt"
        fi
                if [ -f "$INSTALL_DIR/tools/asset-discovery/requirements.txt" ]; then
                    "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet -r "$INSTALL_DIR/tools/asset-discovery/requirements.txt"
                fi
                "$INSTALL_DIR/.venv/bin/python" -m pip install --quiet --upgrade gunicorn celery

                echo "[8/13] Start data services"
        systemctl enable --now postgresql redis-server >/dev/null 2>&1
                sudo -u postgres psql -c "CREATE USER ${{DB_USER}} WITH PASSWORD '${{DB_PASS}}';" 2>/dev/null || true
                sudo -u postgres psql -c "CREATE DATABASE audittoolkit OWNER ${{DB_USER}};" 2>/dev/null || true
                sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE audittoolkit TO ${{DB_USER}};" 2>/dev/null || true
                sudo -u postgres psql -c "CREATE DATABASE asset_discovery OWNER ${{DB_USER}};" 2>/dev/null || true

                DISCOVERY_DIR="$INSTALL_DIR/tools/asset-discovery"
                if [ -f "$DISCOVERY_DIR/.env.example" ]; then
                    [ -f "$DISCOVERY_DIR/.env" ] || cp "$DISCOVERY_DIR/.env.example" "$DISCOVERY_DIR/.env"
                      sed -i "s|^DATABASE_URL=.*|DATABASE_URL=postgresql://${{DB_USER}}:${{DB_PASS}}@localhost:5432/asset_discovery|" "$DISCOVERY_DIR/.env" || true
                      grep -q "^DATABASE_URL=" "$DISCOVERY_DIR/.env" || echo "DATABASE_URL=postgresql://${{DB_USER}}:${{DB_PASS}}@localhost:5432/asset_discovery" >> "$DISCOVERY_DIR/.env"
                    grep -q "^AUDIT_TOOLKIT_URL=" "$DISCOVERY_DIR/.env" || echo "AUDIT_TOOLKIT_URL=http://127.0.0.1" >> "$DISCOVERY_DIR/.env"
                                        if grep -q "^API_PORT=" "$DISCOVERY_DIR/.env"; then
                                            sed -i "s|^API_PORT=.*|API_PORT=${{DISCOVERY_PORT}}|" "$DISCOVERY_DIR/.env"
                                        else
                                            echo "API_PORT=${{DISCOVERY_PORT}}" >> "$DISCOVERY_DIR/.env"
                                        fi
                fi

                echo "[9/13] Permissions"
                mkdir -p /var/log/audit-toolkit "$INSTALL_DIR/web/logs"
        chown -R "$APP_USER":"$APP_USER" "$INSTALL_DIR" /var/log/audit-toolkit

                echo "[10/13] Create fixed service units"
        cat > /etc/systemd/system/audit-toolkit.service << 'EOF'
        [Unit]
        Description=Security Audit Toolkit Web Application
        After=network.target postgresql.service redis-server.service

        [Service]
        Type=simple
        User=auditadmin
        Group=auditadmin
        WorkingDirectory=/opt/audit-toolkit/web
        Environment="PATH=/opt/audit-toolkit/.venv/bin:/usr/local/bin:/usr/bin"
        Environment="DATABASE_URL=postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit"
        Environment="FLASK_SECRET_KEY=__FLASK_SECRET__"
        ExecStart=/opt/audit-toolkit/.venv/bin/gunicorn --bind 127.0.0.1:8000 --workers 4 --timeout 300 --access-logfile /var/log/audit-toolkit/access.log --error-logfile /var/log/audit-toolkit/error.log app:app
        Restart=always
        RestartSec=5

        [Install]
        WantedBy=multi-user.target
        EOF

        cat > /etc/systemd/system/audit-toolkit-discovery.service << 'EOF'
        [Unit]
        Description=Security Audit Toolkit Asset Discovery Service
        After=network.target postgresql.service redis-server.service

        [Service]
        Type=simple
        User=auditadmin
        Group=auditadmin
        WorkingDirectory=/opt/audit-toolkit/tools/asset-discovery
        EnvironmentFile=-/opt/audit-toolkit/tools/asset-discovery/.env
        Environment="PATH=/opt/audit-toolkit/.venv/bin:/usr/local/bin:/usr/bin"
        ExecStart=/opt/audit-toolkit/.venv/bin/python -m src.app
        Restart=always
        RestartSec=5

        [Install]
        WantedBy=multi-user.target
        EOF

        cat > /etc/systemd/system/audit-toolkit-celery.service << 'EOF'
        [Unit]
        Description=Security Audit Toolkit Celery Worker
        After=network.target redis-server.service

        [Service]
        Type=simple
        User=auditadmin
        Group=auditadmin
        WorkingDirectory=/opt/audit-toolkit/web
        Environment="PATH=/opt/audit-toolkit/.venv/bin:/usr/local/bin:/usr/bin"
        Environment="DATABASE_URL=postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit"
        Environment="FLASK_SECRET_KEY=__FLASK_SECRET__"
        ExecStart=/opt/audit-toolkit/.venv/bin/celery -A celery_app worker --loglevel=info --logfile=/var/log/audit-toolkit/celery.log
        Restart=always
        RestartSec=10

        [Install]
        WantedBy=multi-user.target
        EOF

        mkdir -p /etc/nginx/ssl
        if [ ! -f /etc/nginx/ssl/audit-toolkit.key ] || [ ! -f /etc/nginx/ssl/audit-toolkit.crt ]; then
            openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
                -keyout /etc/nginx/ssl/audit-toolkit.key \
                -out /etc/nginx/ssl/audit-toolkit.crt \
                -subj "/CN=$(hostname -f 2>/dev/null || hostname)/O=Audit Toolkit/C=US" >/dev/null 2>&1
            chmod 600 /etc/nginx/ssl/audit-toolkit.key
            chmod 644 /etc/nginx/ssl/audit-toolkit.crt
        fi

        cat > /etc/nginx/sites-available/audit-toolkit << 'EOF'
        server {{
            listen 80 default_server;
            listen [::]:80 default_server;
            server_name _;

            client_max_body_size 100M;

            location / {{
                proxy_pass http://127.0.0.1:8000;
                proxy_http_version 1.1;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /api/v1/agents/license {{
                proxy_pass http://127.0.0.1:8000/api/v1/agents/license;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /api/v1/ {{
                proxy_pass http://127.0.0.1:18080/api/v1/;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /discovery/ {{
                proxy_pass http://127.0.0.1:18080/;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /static/ {{
                alias /opt/audit-toolkit/web/static/;
                expires 30d;
            }}
        }}

        server {{
            listen 443 ssl http2 default_server;
            listen [::]:443 ssl http2 default_server;
            server_name _;

            ssl_certificate /etc/nginx/ssl/audit-toolkit.crt;
            ssl_certificate_key /etc/nginx/ssl/audit-toolkit.key;
            ssl_protocols TLSv1.2 TLSv1.3;

            client_max_body_size 100M;

            location / {{
                proxy_pass http://127.0.0.1:8000;
                proxy_http_version 1.1;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /api/v1/agents/license {{
                proxy_pass http://127.0.0.1:8000/api/v1/agents/license;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /api/v1/ {{
                proxy_pass http://127.0.0.1:18080/api/v1/;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /discovery/ {{
                proxy_pass http://127.0.0.1:18080/;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }}

            location /static/ {{
                alias /opt/audit-toolkit/web/static/;
                expires 30d;
            }}
        }}
        EOF
        ln -sf /etc/nginx/sites-available/audit-toolkit /etc/nginx/sites-enabled/audit-toolkit
        rm -f /etc/nginx/sites-enabled/default

        echo "[11/13] Enable services"
        nginx -t
        systemctl daemon-reload
        systemctl enable --now audit-toolkit audit-toolkit-celery audit-toolkit-discovery nginx >/dev/null 2>&1

        echo "[12/13] Apply database migrations and reset admin credentials"
        cd /opt/audit-toolkit
        export DATABASE_URL="$DATABASE_URL"
        PYBIN=python3
        [ -x ./.venv/bin/python ] && PYBIN=./.venv/bin/python
        ALEMBIC_LOG=/tmp/audit-toolkit-alembic.log  # nosec B108 - deterministic remote temp log for bootstrap diagnostics
        if "$PYBIN" -m alembic -c alembic.ini upgrade head >"$ALEMBIC_LOG" 2>&1; then
            echo "[OK] Alembic upgrade head applied"
        else
            if grep -Eqi "DuplicateTable|already exists|relation .* already exists" "$ALEMBIC_LOG"; then
                echo "[INFO] Existing schema detected; stamping Alembic head"
                if "$PYBIN" -m alembic -c alembic.ini stamp head >>"$ALEMBIC_LOG" 2>&1; then
                    echo "[OK] Alembic head stamped for existing schema"
                else
                    echo "[WARN] Alembic stamp failed; continuing with schema bootstrap fallback"
                fi
            else
                echo "[WARN] Alembic upgrade failed; continuing with schema bootstrap fallback"
            fi
            echo "[INFO] Alembic diagnostics (last 20 lines):"
            tail -n 20 "$ALEMBIC_LOG" || true
        fi

        cd /opt/audit-toolkit/web
        [ -x ../.venv/bin/python ] && PYBIN=../.venv/bin/python
        "$PYBIN" - << 'PY'
        from config import SessionLocal, db_engine
        from models import Base
        from models.user import User, create_initial_admin

        if Base is not None and db_engine is not None:
            Base.metadata.create_all(bind=db_engine)

        session = SessionLocal()
        user = session.query(User).filter_by(username='admin').first()
        if user is None:
            user, _ = create_initial_admin(session, username='admin', email='admin@localhost', password='ChangeMe123!')
        else:
            user.auth_provider = 'local'
            user.is_active = True
            user.is_locked = False
            user.failed_login_attempts = 0
            user.lockout_until = None
            user.set_password('ChangeMe123!')
            session.commit()

        user = session.query(User).filter_by(username='admin').first()
        print('ADMIN_READY', bool(user), user.auth_provider if user else None, user.check_password('ChangeMe123!') if user else False)
        PY

        chown -R "$APP_USER":"$APP_USER" "$INSTALL_DIR" /var/log/audit-toolkit

        echo "[13/13] Runtime verification"
        "$INSTALL_DIR/.venv/bin/gunicorn" --version >/dev/null
        "$INSTALL_DIR/.venv/bin/celery" --version >/dev/null

        echo "=== HEALTH ==="
        systemctl is-active audit-toolkit audit-toolkit-celery audit-toolkit-discovery nginx
        if ! systemctl is-active --quiet audit-toolkit; then
            systemctl status audit-toolkit --no-pager | tail -n 60
        fi
        if ! systemctl is-active --quiet audit-toolkit-celery; then
            systemctl status audit-toolkit-celery --no-pager | tail -n 60
        fi
        if ! systemctl is-active --quiet audit-toolkit-discovery; then
            systemctl status audit-toolkit-discovery --no-pager | tail -n 60
        fi
        if ! systemctl is-active --quiet nginx; then
            systemctl status nginx --no-pager | tail -n 60
        fi
        """
    return textwrap.dedent(script_template).replace("{{", "{").replace("}}", "}").replace("__FLASK_SECRET__", flask_secret)


def check_url(url: str, timeout: int = 20) -> tuple[bool, str]:
    try:
        context = ssl._create_unverified_context() if url.startswith("https://") else None  # nosec B323 - post-deploy lab health check supports self-signed certs
        with urllib.request.urlopen(url, timeout=timeout, context=context) as response:  # nosec B310 - operator-provided URL in controlled verification step
            return response.status == 200, f"{url} -> {response.status}"
    except urllib.error.HTTPError as exc:
        return False, f"{url} -> HTTP {exc.code}"
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return False, f"{url} -> ERROR {exc}"


def wait_for_services(client: paramiko.SSHClient, sudo_password: str, timeout_seconds: int = 90) -> tuple[bool, list[str], str]:
    svc_cmd = "systemctl is-active audit-toolkit audit-toolkit-celery audit-toolkit-discovery nginx"
    deadline = time.time() + timeout_seconds
    last_err = ""
    last_states: list[str] = []

    while time.time() < deadline:
        _, svc_out, svc_err = run_remote_command(client, sudo_password, svc_cmd, timeout=120)
        states = [line.strip() for line in svc_out.splitlines() if line.strip()]
        last_states = states
        last_err = svc_err.strip()

        if len(states) == 4:
            web_ok = states[0] == "active"
            celery_ok = states[1] in {"active", "activating"}
            discovery_ok = states[2] == "active"
            nginx_ok = states[3] == "active"
            if web_ok and celery_ok and discovery_ok and nginx_ok:
                return True, states, last_err

        time.sleep(4)

    return False, last_states, last_err


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(errors="replace")

    parser = argparse.ArgumentParser(description="Clean redeploy fixed build to VM target (non-interactive)")
    parser.add_argument("--host", default=env_default("AUDIT_VM_HOST", "192.168.100.50"))
    parser.add_argument("--user", default=env_default("AUDIT_VM_USER", "auditadmin"))
    parser.add_argument("--password", default=os.environ.get("AUDIT_VM_PASSWORD", ""))
    parser.add_argument("--ssh-key", default=os.environ.get("AUDIT_VM_SSH_KEY", ""))
    parser.add_argument(
        "--archive",
        default=env_default("AUDIT_VM_ARCHIVE", "deployment/vm-appliance/output/audit-toolkit-src-head.tar.gz"),
    )
    parser.add_argument("--skip-http-check", action="store_true")
    args = parser.parse_args()

    if not args.password and not args.ssh_key:
        print("ERROR: provide --password or --ssh-key (or set AUDIT_VM_PASSWORD / AUDIT_VM_SSH_KEY)", file=sys.stderr)
        return 2

    archive_path = Path(args.archive).resolve()
    if not archive_path.exists():
        print(f"ERROR: archive not found: {archive_path}", file=sys.stderr)
        return 2

    flask_secret = secrets.token_hex(32)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # nosec B507 - first-connect lab VM bootstrap workflow
    connect_kwargs = {
        "hostname": args.host,
        "username": args.user,
        "look_for_keys": bool(args.ssh_key),
        "allow_agent": bool(args.ssh_key),
        "timeout": 20,
    }
    if args.ssh_key:
        connect_kwargs["key_filename"] = str(Path(args.ssh_key).expanduser())
    else:
        connect_kwargs["password"] = args.password

    client.connect(**connect_kwargs)

    try:
        print(f"Uploading archive to {args.host}...")
        sftp_upload(client, archive_path, "/tmp/audit-toolkit-src-head.tar.gz")  # nosec B108 - deterministic remote temp path for appliance bootstrap

        print("Running clean redeploy script...")
        script = build_redeploy_script(flask_secret)
        sudo_password = args.password or env_default("AUDIT_VM_PASSWORD", "")
        if not sudo_password:
            print("ERROR: sudo password is required for remote install actions", file=sys.stderr)
            return 2

        rc, out, err = run_remote_script(client, sudo_password, script, timeout=5400)
        print("RC=", rc)
        print("---STDOUT---")
        print(out)
        print("---STDERR---")
        print(err)
        print("FLASK_SECRET_KEY_SET=", flask_secret)

        print("Running post-deploy service checks...")
        service_ok, states, svc_err = wait_for_services(client, sudo_password, timeout_seconds=120)
        print("---SERVICE CHECK---")
        print("\n".join(states))
        if svc_err.strip():
            print(svc_err.strip())

        http_ok = True
        if not args.skip_http_check:
            print("Running post-deploy HTTP checks...")
            checks = [
                f"https://{args.host}/",
                f"https://{args.host}/auth/login",
                f"https://{args.host}/discovery/health",
                f"https://{args.host}/api/v1/config",
            ]
            for url in checks:
                ok, message = check_url(url)
                print(message)
                if not ok:
                    http_ok = False

        if not service_ok:
            return 3
        if not http_ok:
            return 4
        if rc != 0:
            print(f"Warning: deploy script returned {rc}, but final health checks passed.")
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())
