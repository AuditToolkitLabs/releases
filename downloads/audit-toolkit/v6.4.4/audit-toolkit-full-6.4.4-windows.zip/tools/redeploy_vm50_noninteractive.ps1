param(
    [string]$HostIp = $(if ($env:AUDIT_VM_HOST) { $env:AUDIT_VM_HOST } else { "192.168.100.50" }),
    [string]$User = $(if ($env:AUDIT_VM_USER) { $env:AUDIT_VM_USER } else { "auditadmin" }),
    [string]$Archive = $(if ($env:AUDIT_VM_ARCHIVE) { $env:AUDIT_VM_ARCHIVE } else { "deployment/vm-appliance/output/audit-toolkit-src-head.tar.gz" }),
    [SecureString]$Password,
    [string]$SshKey = $env:AUDIT_VM_SSH_KEY,
    [switch]$SkipHttpCheck
)

$ErrorActionPreference = "Stop"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function ConvertTo-PlainText {
    param([SecureString]$SecureValue)

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

if (-not $Password -and -not [string]::IsNullOrWhiteSpace($env:AUDIT_VM_PASSWORD)) {
    $Password = ConvertTo-InMemorySecureString -Value $env:AUDIT_VM_PASSWORD
}

if (-not $Password -and -not $SshKey) {
    throw "Set AUDIT_VM_PASSWORD or AUDIT_VM_SSH_KEY (or pass -Password / -SshKey) for non-interactive deploy."
}

$py = "C:/Github/Audit-Tool-/.venv/Scripts/python.exe"
if (-not (Test-Path $py)) {
    throw "Python venv executable not found: $py"
}

$pythonArgs = @(
    "tools/redeploy_vm50_fixed.py",
    "--host", $HostIp,
    "--user", $User,
    "--archive", $Archive
)

if ($Password) {
    $plainPassword = ConvertTo-PlainText -SecureValue $Password
    $pythonArgs += @("--password", $plainPassword)
}
if ($SshKey) {
    $pythonArgs += @("--ssh-key", $SshKey)
}
if ($SkipHttpCheck) {
    $pythonArgs += "--skip-http-check"
}

& $py @pythonArgs
exit $LASTEXITCODE
