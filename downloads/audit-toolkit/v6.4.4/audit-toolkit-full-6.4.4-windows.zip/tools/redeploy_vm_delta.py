#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
import tarfile
import tempfile
import textwrap
import time
from pathlib import Path

import paramiko


def run_cmd(command: list[str]) -> str:
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    return result.stdout.strip()


def collect_changed_files(repo_root: Path) -> list[Path]:
    status_output = run_cmd(["git", "-C", str(repo_root), "status", "--porcelain"])
    if not status_output:
        return []

    files: list[Path] = []
    for line in status_output.splitlines():
        if not line:
            continue

        rel = line[3:]
        if " -> " in rel:
            rel = rel.split(" -> ", 1)[1]
        rel = rel.strip()

        if not rel:
            continue

        full = repo_root / rel
        if full.is_file():
            files.append(full)
    return sorted(set(files))


def expand_web_bundle(repo_root: Path, files: list[Path]) -> list[Path]:
    has_web_change = any(path.relative_to(repo_root).parts[0] == "web" for path in files)
    if not has_web_change:
        return files

    expanded: set[Path] = set(files)

    web_root = repo_root / "web"
    critical_roots = [
        web_root / "templates",
        web_root / "static",
    ]
    critical_files = [
        web_root / "index.html",
        web_root / "app.py",
    ]

    for file_path in critical_files:
        if file_path.is_file():
            expanded.add(file_path)

    for root in critical_roots:
        if root.exists():
            for file_path in root.rglob("*"):
                if file_path.is_file():
                    expanded.add(file_path)

    return sorted(expanded)


def build_archive(repo_root: Path, files: list[Path]) -> Path:
    temp_dir = Path(tempfile.mkdtemp(prefix="vm_delta_"))
    archive_path = temp_dir / "audit-toolkit-delta.tar.gz"

    with tarfile.open(archive_path, "w:gz") as tf:
        for file_path in files:
            arcname = str(file_path.relative_to(repo_root)).replace("\\", "/")
            tf.add(file_path, arcname=arcname)

    return archive_path


def upload_file(client: paramiko.SSHClient, local_path: Path, remote_path: str) -> None:
    sftp = client.open_sftp()
    try:
        sftp.put(str(local_path), remote_path)
    finally:
        sftp.close()


def run_remote(client: paramiko.SSHClient, sudo_password: str, command: str, timeout: int = 600) -> tuple[int, str, str]:
    stdin, stdout, stderr = client.exec_command(f"sudo -S -p '' bash -lc {quote_bash(command)}", timeout=timeout)  # nosec B601 - command is shell-quoted and used in controlled operator workflow
    stdin.write(sudo_password + "\n")
    stdin.flush()
    out = stdout.read().decode("utf-8", "ignore")
    err = stderr.read().decode("utf-8", "ignore")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def quote_bash(text: str) -> str:
    escaped = text.replace("'", "'\"'\"'")
    return f"'{escaped}'"


def make_remote_script(install_dir: str, app_user: str, archive_path: str, services: list[str]) -> str:
    services_str = " ".join(services)
    return textwrap.dedent(
        f"""
        set -euo pipefail
        INSTALL_DIR={quote_bash(install_dir)}
        APP_USER={quote_bash(app_user)}
        ARCHIVE={quote_bash(archive_path)}
        SERVICES={quote_bash(services_str)}

                echo "[preflight] Enforcing OS-native deployment mode (non-Docker)"
                if command -v docker >/dev/null 2>&1; then
                    if docker ps --format '{{{{.Names}}}}' | grep -Eq '^(audit-toolkit-|audit-toolkit_)'; then
                        echo "ERROR: Docker audit-toolkit containers detected on target host."
                        echo "This VM is reserved for OS-native/systemd runtime validation and image baking."
                        echo "Stop/remove Docker runtime before running VM delta deploy."
                        exit 1
                    fi
                fi

        echo "[1/4] Extracting delta archive into $INSTALL_DIR"
        mkdir -p "$INSTALL_DIR"
        tar -xzf "$ARCHIVE" -C "$INSTALL_DIR"

        echo "[2/4] Fixing ownership"
        chown -R "$APP_USER":"$APP_USER" "$INSTALL_DIR/web" "$INSTALL_DIR/deployment" 2>/dev/null || true

        echo "[3/4] Restarting services: $SERVICES"
        systemctl restart $SERVICES

        echo "[4/4] Service health"
        systemctl is-active $SERVICES
        """
    ).strip()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Non-interactive delta redeploy for existing VM")
    parser.add_argument("--host", default=os.environ.get("AUDIT_VM_HOST", "192.168.100.50"))
    parser.add_argument("--user", default=os.environ.get("AUDIT_VM_USER", "auditadmin"))
    parser.add_argument("--password", default=os.environ.get("AUDIT_VM_PASSWORD", ""))
    parser.add_argument("--ssh-key", default=os.environ.get("AUDIT_VM_SSH_KEY", ""))
    parser.add_argument("--install-dir", default="/opt/audit-toolkit")
    parser.add_argument("--app-user", default="auditadmin")
    parser.add_argument(
        "--services",
        nargs="+",
        default=["audit-toolkit", "audit-toolkit-celery", "nginx"],
        help="Systemd services to restart and check",
    )
    parser.add_argument(
        "--files",
        nargs="*",
        default=[],
        help="Optional explicit relative file paths to deploy. Defaults to git diff vs HEAD.",
    )
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parent.parent

    if not args.password and not args.ssh_key and not args.dry_run:
        print("ERROR: provide --password or --ssh-key (or set AUDIT_VM_PASSWORD / AUDIT_VM_SSH_KEY)", file=sys.stderr)
        return 2

    if args.files:
        files = [repo_root / rel for rel in args.files if (repo_root / rel).is_file()]
    else:
        files = collect_changed_files(repo_root)

    files = expand_web_bundle(repo_root, files)

    if not files:
        print("No tracked changed files found to deploy.")
        return 0

    print(f"Preparing delta archive for {len(files)} file(s)...")
    for path in files:
        print(f" - {path.relative_to(repo_root)}")

    if args.dry_run:
        return 0

    archive = build_archive(repo_root, files)
    remote_archive = f"/tmp/audit-toolkit-delta-{int(time.time())}.tar.gz"  # nosec B108 - deterministic remote temp path for delta deployment

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # nosec B507 - first-connect lab VM workflow

    connect_kwargs: dict = {
        "hostname": args.host,
        "username": args.user,
        "look_for_keys": bool(args.ssh_key),
        "allow_agent": bool(args.ssh_key),
        "timeout": 20,
    }
    if args.ssh_key:
        connect_kwargs["key_filename"] = str(Path(args.ssh_key).expanduser())
    else:
        connect_kwargs["password"] = args.password

    try:
        print(f"Connecting to {args.user}@{args.host}...")
        client.connect(**connect_kwargs)

        print(f"Uploading archive to {remote_archive}...")
        upload_file(client, archive, remote_archive)

        script = make_remote_script(args.install_dir, args.app_user, remote_archive, args.services)
        print("Applying delta and restarting services...")
        rc, out, err = run_remote(client, args.password, script, timeout=900)

        if out.strip():
            print(out)
        if err.strip():
            print(err, file=sys.stderr)

        cleanup_cmd = f"rm -f {quote_bash(remote_archive)}"
        run_remote(client, args.password, cleanup_cmd, timeout=60)

        if rc != 0:
            print(f"Delta redeploy failed with exit code {rc}", file=sys.stderr)
            return rc

        print("Delta redeploy completed successfully.")
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())
