param(
    [string]$HostIp = $(if ($env:AUDIT_VM_HOST) { $env:AUDIT_VM_HOST } else { "192.168.100.50" }),
    [string]$User = $(if ($env:AUDIT_VM_USER) { $env:AUDIT_VM_USER } else { "auditadmin" }),
    [securestring]$CredentialSecret,
    [string]$AuthValue = $(if ($env:AUDIT_VM_PASSWORD) { $env:AUDIT_VM_PASSWORD } else { "" }),
    [string]$SshKey = $env:AUDIT_VM_SSH_KEY,
    [string]$InstallDir = "/opt/audit-toolkit",
    [string]$AppUser = "auditadmin",
    [string[]]$Services = @("audit-toolkit", "audit-toolkit-celery", "nginx"),
    [string[]]$Files,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    if (-not $Value) {
        return $null
    }

    $secure = New-Object System.Security.SecureString
    foreach ($ch in $Value.ToCharArray()) {
        $secure.AppendChar($ch)
    }
    $secure.MakeReadOnly()
    return $secure
}

if (-not $SshKey) {
    $candidateKeys = @(
        (Join-Path $HOME ".ssh/id_ed25519"),
        (Join-Path $HOME ".ssh/id_rsa")
    )
    foreach ($candidate in $candidateKeys) {
        if (Test-Path $candidate) {
            $SshKey = $candidate
            Write-Output "Using detected SSH key: $SshKey"
            break
        }
    }
}

if (-not $CredentialSecret -and $AuthValue) {
    $CredentialSecret = ConvertTo-InMemorySecureString -Value $AuthValue
}

if (-not $CredentialSecret -and -not $SshKey -and -not $DryRun) {
    throw "Set AUDIT_VM_PASSWORD or AUDIT_VM_SSH_KEY (or pass -CredentialSecret / -SshKey) for non-interactive delta deploy."
}

$py = Join-Path $PSScriptRoot "..\.venv\Scripts\python.exe"
$py = (Resolve-Path $py).Path
if (-not (Test-Path $py)) {
    throw "Python venv executable not found: $py"
}

$scriptPath = Join-Path $PSScriptRoot "redeploy_vm_delta.py"
$pythonParameters = @(
    $scriptPath,
    "--host", $HostIp,
    "--user", $User,
    "--install-dir", $InstallDir,
    "--app-user", $AppUser,
    "--services"
)
$pythonParameters += $Services

if ($CredentialSecret) {
    $passwordBstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($CredentialSecret)
    try {
        $passwordPlainText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordBstr)
        if ($passwordPlainText) {
            $pythonParameters += @("--password", $passwordPlainText)
        }
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordBstr)
    }
}

if ($SshKey) { $pythonParameters += @("--ssh-key", $SshKey) }
if ($Files -and $Files.Count -gt 0) {
    $pythonParameters += "--files"
    $pythonParameters += $Files
}
if ($DryRun) { $pythonParameters += "--dry-run" }

& $py @pythonParameters
exit $LASTEXITCODE
