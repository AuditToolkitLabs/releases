#!/usr/bin/env bash
# reset-admin-password.sh — Security Audit Toolkit customer admin password reset
#
# Usage (run as root on the appliance):
#   sudo bash reset-admin-password.sh
#   sudo bash reset-admin-password.sh --username admin --password 'NewPass123!'
#
# What this script does:
#   1. Locates the active .env file and verifies PostgreSQL connectivity
#   2. Resets the target admin user's password (hashed via werkzeug)
#   3. Clears must_change_password so the account isn't forced into change-flow
#   4. Removes the stale initial-admin-credentials file so the new password governs
#   5. Restarts the web service so any cached session state is cleared
#
# Safe to run multiple times.  Read-only until the user confirms the change.
set -euo pipefail

# ── configuration ──────────────────────────────────────────────────────────────
APP_DIR="/opt/audit-toolkit"
APP_ENV="${APP_DIR}/.env"
VENV_PYTHON="${APP_DIR}/.venv/bin/python"

CRED_FILE_CANDIDATES=(
  "/var/lib/audit-toolkit/initial-admin-credentials.txt"
  "/etc/audit-toolkit/initial-admin-credentials.txt"
  "${APP_DIR}/.initial-admin-credentials"
)

# ── argument parsing ────────────────────────────────────────────────────────────
TARGET_USERNAME=""
NEW_PASSWORD=""
FORCE=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --username|-u) TARGET_USERNAME="$2"; shift 2 ;;
    --password|-p) NEW_PASSWORD="$2"; shift 2 ;;
    --force|-f)    FORCE=true; shift ;;
    --help|-h)
      sed -n '/^# /p' "$0" | sed 's/^# //'
      exit 0
      ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

# ── helpers ─────────────────────────────────────────────────────────────────────
require_root() {
  if [[ $EUID -ne 0 ]]; then
    echo "Error: this script must be run as root (use: sudo bash $0)" >&2
    exit 1
  fi
}

load_env() {
  if [[ ! -f "$APP_ENV" ]]; then
    echo "Error: app env file not found at $APP_ENV" >&2
    exit 1
  fi
  # shellcheck source=/dev/null
  set -a; source "$APP_ENV"; set +a
}

read_secure() {
  local prompt="$1"
  local var
  read -r -s -p "$prompt" var
  echo
  printf '%s' "$var"
}

# ── main ────────────────────────────────────────────────────────────────────────
require_root
load_env

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "Error: DATABASE_URL is not set in $APP_ENV" >&2
  exit 1
fi

if [[ "${DATABASE_URL}" == sqlite* ]]; then
  echo ""
  echo "WARNING: DATABASE_URL points to SQLite ($DATABASE_URL)."
  echo "This appliance should use PostgreSQL.  Run vm-force-postgres-runtime.sh first."
  echo ""
  if [[ "$FORCE" != true ]]; then
    read -r -p "Continue anyway? [y/N] " yn
    [[ "${yn,,}" == y ]] || { echo "Aborted."; exit 1; }
  fi
fi

# Resolve target username interactively if not supplied
if [[ -z "$TARGET_USERNAME" ]]; then
  read -r -p "Admin username to reset [admin]: " TARGET_USERNAME
  TARGET_USERNAME="${TARGET_USERNAME:-admin}"
fi

# Resolve new password interactively if not supplied
if [[ -z "$NEW_PASSWORD" ]]; then
  while true; do
    NEW_PASSWORD="$(read_secure "New password for '${TARGET_USERNAME}': ")"
    if [[ ${#NEW_PASSWORD} -lt 8 ]]; then
      echo "Password must be at least 8 characters.  Try again."
      continue
    fi
    confirm="$(read_secure "Confirm new password: ")"
    if [[ "$NEW_PASSWORD" != "$confirm" ]]; then
      echo "Passwords do not match.  Try again."
      continue
    fi
    break
  done
fi

if [[ ${#NEW_PASSWORD} -lt 8 ]]; then
  echo "Error: password must be at least 8 characters." >&2
  exit 1
fi

echo ""
echo "Resetting password for user '${TARGET_USERNAME}'..."

# ── perform the reset via Python/SQLAlchemy ─────────────────────────────────────
"$VENV_PYTHON" - <<PYEOF
import os, sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
sys.path.insert(0, "${APP_DIR}/web")
from models.user import User

database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)
Session = sessionmaker(bind=engine)
session = Session()

user = session.query(User).filter_by(username="${TARGET_USERNAME}").first()
if user is None:
    print(f"Error: user '{TARGET_USERNAME}' not found in the database.", file=sys.stderr)
    sys.exit(2)

user.set_password("${NEW_PASSWORD}")
user.must_change_password = False
session.commit()
print(f"Password updated for user '{user.username}' (id={user.id}).")
PYEOF

rc=$?
if [[ $rc -ne 0 ]]; then
  if [[ $rc -eq 2 ]]; then
    echo ""
    echo "Available admin users:"
    "$VENV_PYTHON" - <<PYEOF2
import os, sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
sys.path.insert(0, "${APP_DIR}/web")
from models.user import User

engine = create_engine(os.environ["DATABASE_URL"])
Session = sessionmaker(bind=engine)
for u in Session().query(User).filter(User.role.in_(["admin","superadmin"])).all():
    print(f"  {u.username} ({u.role})")
PYEOF2
  fi
  exit $rc
fi

# Remove stale credentials file so the new password is authoritative
for cpath in "${CRED_FILE_CANDIDATES[@]}"; do
  if [[ -f "$cpath" ]]; then
    rm -f "$cpath"
    echo "Removed stale credentials file: $cpath"
  fi
done

# Restart the web service to clear any cached session state
echo "Restarting audit-toolkit service..."
systemctl restart audit-toolkit 2>/dev/null || true

echo ""
echo "Done.  Log in at https://$(hostname -I | awk '{print $1}') with:"
echo "  Username: ${TARGET_USERNAME}"
echo "  Password: (the password you just set)"
