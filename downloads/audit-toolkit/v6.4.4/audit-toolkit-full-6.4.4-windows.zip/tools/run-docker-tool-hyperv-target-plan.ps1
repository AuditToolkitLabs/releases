[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$WindowsTargetIP,

    [Parameter(Mandatory = $true)]
    [string]$LinuxTargetIP,

    [Parameter()]
    [string]$CoreUrl = "http://localhost:5000",

    [Parameter()]
    [string]$DiscoveryUrl = "http://localhost:8080",

    [Parameter()]
    [switch]$SkipCoreStart,

    [Parameter()]
    [switch]$SkipRebootStability,

    [Parameter()]
    [switch]$SkipTargetPortChecks

    ,[Parameter()]
    [string]$WindowsUsername = "audit_user"

    ,[Parameter()]
    [switch]$HostMode

    ,[Parameter()]
    [switch]$SkipWinRMPrecheck

    ,[Parameter()]
    [switch]$UpdateTrustedHosts

    ,[Parameter()]
    [string]$LinuxUsername = "audit_user"

    ,[Parameter()]
    [string]$LinuxSshKeyPath = ""

    ,[Parameter()]
    [switch]$SkipSSHPrecheck

    ,[Parameter()]
    [switch]$ApplyLinuxExpectedState
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path $PSScriptRoot -Parent

function Write-Status { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Success { param([string]$Message) Write-Host "[+] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }
function Write-Fail { param([string]$Message) Write-Host "[-] $Message" -ForegroundColor Red }

function Get-ComposeCommand {
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        try {
            docker compose version | Out-Null
            return @("docker", "compose")
        }
        catch { Write-Verbose 'Suppressed non-fatal error.' }
    }

    if (Get-Command docker-compose -ErrorAction SilentlyContinue) {
        return @("docker-compose")
    }

    throw "Neither 'docker compose' nor 'docker-compose' is available in PATH."
}

function Invoke-Compose {
    param([string[]]$ComposeParameters)

    $compose = Get-ComposeCommand
    if ($compose.Count -eq 2) {
        & $compose[0] $compose[1] @ComposeParameters
    }
    else {
        & $compose[0] @ComposeParameters
    }

    if ($LASTEXITCODE -ne 0) {
        throw "Compose command failed: $($compose -join ' ') $($ComposeParameters -join ' ')"
    }
}

function Wait-CoreReady {
    param(
        [string]$Url,
        [int]$MaxRetries = 90,
        [int]$SleepSeconds = 2
    )

    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            $resp = Invoke-WebRequest -Uri "$Url/health" -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
            if ($resp.StatusCode -eq 200) {
                return $true
            }
        }
        catch { Write-Verbose 'Suppressed non-fatal error.' }

        Start-Sleep -Seconds $SleepSeconds
    }

    return $false
}

function Test-TargetPorts {
    param(
        [string]$WindowsIP,
        [string]$LinuxIP
    )

    $win = Test-NetConnection -ComputerName $WindowsIP -Port 5985 -WarningAction SilentlyContinue
    $linux = Test-NetConnection -ComputerName $LinuxIP -Port 22 -WarningAction SilentlyContinue

    if (-not $win.TcpTestSucceeded) {
        throw "Windows target port check failed on $WindowsIP:5985"
    }
    if (-not $linux.TcpTestSucceeded) {
        throw "Linux target port check failed on $LinuxIP:22"
    }

    Write-Success "Target port checks passed (WinRM 5985 / SSH 22)."
}

function Invoke-WinRMPrecheck {
    param(
        [string]$TargetIP,
        [string]$Username,
        [switch]$UpdateTrusted
    )

    $scriptPath = Join-Path $ProjectRoot "tools\precheck-winrm-target.ps1"
    if (-not (Test-Path $scriptPath)) {
        throw "WinRM precheck script not found: $scriptPath"
    }

    $precheckParameters = @(
        "-TargetIP", $TargetIP,
        "-Username", $Username
    )

    if ($UpdateTrusted) {
        $precheckParameters += "-UpdateTrustedHosts"
    }

    Write-Status "Running WinRM readiness precheck"
    & pwsh $scriptPath @precheckParameters
    if ($LASTEXITCODE -ne 0) {
        throw "WinRM precheck failed with exit code $LASTEXITCODE"
    }

    Write-Success "WinRM readiness precheck passed"
}

function Invoke-SSHPrecheck {
    param(
        [string]$TargetIP,
        [string]$Username,
        [string]$SshKeyPath,
        [switch]$ApplyExpectedState
    )

    $scriptPath = Join-Path $ProjectRoot "tools\precheck-ssh-target.ps1"
    if (-not (Test-Path $scriptPath)) {
        throw "SSH precheck script not found: $scriptPath"
    }

    $precheckParameters = @(
        "-TargetIP", $TargetIP,
        "-Username", $Username,
        "-NonInteractive"
    )

    if (-not [string]::IsNullOrWhiteSpace($SshKeyPath)) {
        $precheckParameters += @("-SshKeyPath", $SshKeyPath)
    }
    if ($ApplyExpectedState) {
        $precheckParameters += "-ApplyExpectedState"
    }

    Write-Status "Running SSH readiness precheck"
    & pwsh $scriptPath @precheckParameters
    if ($LASTEXITCODE -ne 0) {
        throw "SSH precheck failed with exit code $LASTEXITCODE"
    }

    Write-Success "SSH readiness precheck passed"
}

try {
    Write-Output "================================================================="
    Write-Output " Tool + Hyper-V Targets Validation Runner"
    Write-Output "================================================================="

    Write-Status "Windows target: $WindowsTargetIP"
    Write-Status "Linux target:   $LinuxTargetIP"

    if (-not $SkipCoreStart) {
        if ($HostMode) {
            Write-Status "Host mode enabled; skipping Docker control-plane startup"
        }
        else {
            Write-Status "Starting Docker control-plane services"
            Invoke-Compose -ComposeParameters @("up", "-d")
            if (-not (Wait-CoreReady -Url $CoreUrl)) {
                throw "Core API is not ready at $CoreUrl after readiness wait."
            }
            Write-Success "Docker control-plane is healthy"
        }
    }
    else {
        Write-Warn "Skipping control-plane startup as requested"
    }

    if ($HostMode -or $SkipCoreStart) {
        if (-not (Wait-CoreReady -Url $CoreUrl)) {
            throw "Core API is not ready at $CoreUrl after readiness wait."
        }
        Write-Success "Core API is reachable"
    }

    if (-not $SkipTargetPortChecks) {
        Test-TargetPorts -WindowsIP $WindowsTargetIP -LinuxIP $LinuxTargetIP
    }
    else {
        Write-Warn "Skipping target port checks as requested"
    }

    if (-not $SkipWinRMPrecheck) {
        Invoke-WinRMPrecheck -TargetIP $WindowsTargetIP -Username $WindowsUsername -UpdateTrusted:$UpdateTrustedHosts
    }
    else {
        Write-Warn "Skipping WinRM readiness precheck as requested"
    }

    if (-not $SkipSSHPrecheck) {
        Invoke-SSHPrecheck -TargetIP $LinuxTargetIP -Username $LinuxUsername -SshKeyPath $LinuxSshKeyPath -ApplyExpectedState:$ApplyLinuxExpectedState
    }
    else {
        Write-Warn "Skipping SSH readiness precheck as requested"
    }

    $gateScript = Join-Path $ProjectRoot "run-release-gate.ps1"
    $gateParameters = @(
        "-CoreUrl", $CoreUrl,
        "-DiscoveryUrl", $DiscoveryUrl,
        "-WindowsTarget", $WindowsTargetIP,
        "-LinuxTarget", $LinuxTargetIP,
        "-RequireDiagnosticsApis"
    )
    if ($SkipRebootStability -or $HostMode -or $SkipCoreStart) {
        $gateParameters += "-SkipRebootStability"
    }

    if ($HostMode) {
        Write-Status "Executing consolidated release gate in host-native + Hyper-V-target mode"
    }
    else {
        Write-Status "Executing consolidated release gate in Docker-tool + Hyper-V-target mode"
    }
    & pwsh $gateScript @gateParameters
    $exitCode = [int]$LASTEXITCODE

    if ($exitCode -eq 0) {
        Write-Success "Plan run complete: all gate suites passed"
    }
    elseif ($exitCode -eq 1) {
        Write-Warn "Plan run complete with warnings (review retained artifacts)"
    }
    else {
        Write-Fail "Plan run failed with exit code $exitCode"
    }

    exit $exitCode
}
catch {
    Write-Fail $_.Exception.Message
    exit 1
}

