[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [ValidateSet('Start', 'Worker', 'Status', 'Stop')]
    [string]$Mode = 'Start',

    [Parameter()]
    [string]$RepoRoot = '',

    [Parameter()]
    [string]$Remote = 'origin',

    [Parameter()]
    [string]$Branch = '',

    [Parameter()]
    [ValidateRange(5, 3600)]
    [int]$RetryDelaySeconds = 180,

    [Parameter()]
    [int]$MaxAttempts = 0,

    [Parameter()]
    [ValidateRange(5, 200)]
    [int]$TailLines = 25,

    [Parameter()]
    [switch]$ForceRestart

    ,
    [Parameter()]
    [switch]$VerboseGit
)

$null = $Remote, $RetryDelaySeconds, $TailLines, $ForceRestart, $VerboseGit

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-RepoRootPath {
    param([string]$ExplicitRepoRoot)

    $candidate = if ([string]::IsNullOrWhiteSpace($ExplicitRepoRoot)) {
        Join-Path $PSScriptRoot '..'
    }
    else {
        $ExplicitRepoRoot
    }

    return (Resolve-Path -LiteralPath $candidate).Path
}

function Get-StatePaths {
    param([Parameter(Mandatory = $true)][string]$ResolvedRepoRoot)

    $stateDir = Join-Path $ResolvedRepoRoot '.git\copilot-lfs-push'
    [PSCustomObject]@{
        Dir = $stateDir
        PidFile = Join-Path $stateDir 'worker.pid'
        StateFile = Join-Path $stateDir 'state.json'
        StartFile = Join-Path $stateDir 'worker.start'
        WorkerOutLog = Join-Path $stateDir 'worker.out.log'
        WorkerErrLog = Join-Path $stateDir 'worker.err.log'
        LfsProgressLog = Join-Path $stateDir 'git-lfs.progress.log'
    }
}

function New-StateDirectory {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([Parameter(Mandatory = $true)][object]$Paths)

    if ($PSCmdlet.ShouldProcess($Paths.Dir, 'Ensure detached worker state directory exists')) {
        $null = New-Item -ItemType Directory -Path $Paths.Dir -Force
    }
}

function Get-CurrentBranchName {
    param([Parameter(Mandatory = $true)][string]$ResolvedRepoRoot)

    Push-Location $ResolvedRepoRoot
    try {
        $branchName = (& git branch --show-current 2>$null).Trim()
    }
    finally {
        Pop-Location
    }

    if ([string]::IsNullOrWhiteSpace($branchName)) {
        throw 'Unable to determine current branch name. Specify -Branch explicitly.'
    }

    return $branchName
}

function Get-BranchStatusText {
    param([Parameter(Mandatory = $true)][string]$ResolvedRepoRoot)

    Push-Location $ResolvedRepoRoot
    try {
        return ((& git status --short --branch 2>&1) -join [Environment]::NewLine)
    }
    finally {
        Pop-Location
    }
}

function Read-State {
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not (Test-Path -LiteralPath $Paths.StateFile)) {
        return $null
    }

    return (Get-Content -LiteralPath $Paths.StateFile -Raw | ConvertFrom-Json)
}

function Write-State {
    param(
        [Parameter(Mandatory = $true)][object]$Paths,
        [Parameter(Mandatory = $true)][hashtable]$State
    )

    $State | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Paths.StateFile -Encoding UTF8
}

function Get-RunningProcessFromPidFile {
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not (Test-Path -LiteralPath $Paths.PidFile)) {
        return $null
    }

    $rawPid = (Get-Content -LiteralPath $Paths.PidFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($rawPid)) {
        return $null
    }

    $workerPid = 0
    if (-not [int]::TryParse($rawPid, [ref]$workerPid)) {
        return $null
    }

    return (Get-Process -Id $workerPid -ErrorAction SilentlyContinue)
}

function Show-TailIfPresent {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][int]$LineCount,
        [Parameter(Mandatory = $true)][string]$Title
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    Write-Output "--- $Title ---"
    Get-Content -LiteralPath $Path -Tail $LineCount
}

function Format-ByteSize {
    param([Parameter(Mandatory = $true)][double]$Bytes)

    if ($Bytes -ge 1GB) {
        return ('{0:N3} GiB' -f ($Bytes / 1GB))
    }
    if ($Bytes -ge 1MB) {
        return ('{0:N3} MiB' -f ($Bytes / 1MB))
    }
    if ($Bytes -ge 1KB) {
        return ('{0:N3} KiB' -f ($Bytes / 1KB))
    }
    return ('{0} B' -f [int64]$Bytes)
}

function Get-LfsProgressSummary {
    param([Parameter(Mandatory = $true)][string]$ProgressLogPath)

    if (-not (Test-Path -LiteralPath $ProgressLogPath)) {
        return $null
    }

    $latestByPath = @{}
    $totalByPath = @{}

    foreach ($line in Get-Content -LiteralPath $ProgressLogPath) {
        if ($line -match '^upload\s+\d+/\d+\s+(\d+)/(\d+)\s+(.+)$') {
            $uploadedBytes = [int64]$Matches[1]
            $totalBytes = [int64]$Matches[2]
            $pathText = $Matches[3].Trim()
            $totalByPath[$pathText] = $totalBytes
            if (-not $latestByPath.ContainsKey($pathText) -or $uploadedBytes -gt $latestByPath[$pathText]) {
                $latestByPath[$pathText] = $uploadedBytes
            }
        }
    }

    if ($totalByPath.Count -eq 0) {
        return $null
    }

    $uploadedTotal = [int64]0
    $knownTotal = [int64]0
    $completedParts = 0

    foreach ($key in $totalByPath.Keys) {
        $partTotal = [int64]$totalByPath[$key]
        $partUploaded = if ($latestByPath.ContainsKey($key)) { [int64]$latestByPath[$key] } else { [int64]0 }
        $knownTotal += $partTotal
        $uploadedTotal += $partUploaded
        if ($partUploaded -ge $partTotal -and $partTotal -gt 0) {
            $completedParts++
        }
    }

    $pct = if ($knownTotal -gt 0) { [math]::Round(($uploadedTotal * 100.0) / $knownTotal, 3) } else { 0 }
    return [PSCustomObject]@{
        ObservedParts = $totalByPath.Count
        CompletedParts = $completedParts
        UploadedBytes = $uploadedTotal
        KnownTotalBytes = $knownTotal
        RemainingBytes = if ($knownTotal -gt $uploadedTotal) { [int64]($knownTotal - $uploadedTotal) } else { [int64]0 }
        Percent = $pct
    }
}

function Start-DetachedWorker {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [Parameter(Mandatory = $true)][string]$ResolvedBranch,
        [Parameter(Mandatory = $true)][object]$Paths
    )

    if (-not $PSCmdlet.ShouldProcess($ResolvedRepoRoot, "Start detached Git/LFS push worker for branch $ResolvedBranch")) {
        return
    }

    $running = Get-RunningProcessFromPidFile -Paths $Paths
    if ($running) {
        if (-not $ForceRestart) {
            Write-Output "Detached Git/LFS push worker already running: PID=$($running.Id)"
            Write-Output "Status: pwsh -File tools/run-git-lfs-push-detached.ps1 -Mode Status"
            return
        }

        Stop-Process -Id $running.Id -Force
        Start-Sleep -Seconds 1
    }

    Remove-Item -LiteralPath $Paths.WorkerOutLog, $Paths.WorkerErrLog -Force -ErrorAction SilentlyContinue

    $argumentList = @(
        '-NoLogo',
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        $PSCommandPath,
        '-Mode',
        'Worker',
        '-RepoRoot',
        $ResolvedRepoRoot,
        '-Remote',
        $Remote,
        '-Branch',
        $ResolvedBranch,
        '-RetryDelaySeconds',
        $RetryDelaySeconds.ToString(),
        '-MaxAttempts',
        $MaxAttempts.ToString(),
        '-TailLines',
        $TailLines.ToString()
    )
    if ($VerboseGit) {
        $argumentList += '-VerboseGit'
    }

    $worker = Start-Process -FilePath 'pwsh' -ArgumentList $argumentList -WorkingDirectory $ResolvedRepoRoot -RedirectStandardOutput $Paths.WorkerOutLog -RedirectStandardError $Paths.WorkerErrLog -PassThru -WindowStyle Hidden
    Set-Content -LiteralPath $Paths.PidFile -Value $worker.Id -Encoding ASCII
    Set-Content -LiteralPath $Paths.StartFile -Value ([DateTime]::UtcNow.ToString('o')) -Encoding ASCII

    $initialState = @{
        repo_root = $ResolvedRepoRoot
        remote = $Remote
        branch = $ResolvedBranch
        mode = 'worker'
        status = 'starting'
        worker_pid = $worker.Id
        active_git_pid = $null
        attempt = 0
        start_utc = [DateTime]::UtcNow.ToString('o')
        last_attempt_utc = $null
        retry_delay_seconds = $RetryDelaySeconds
        max_attempts = $MaxAttempts
        latest_attempt_stdout = $null
        latest_attempt_stderr = $null
        last_exit_code = $null
        last_error = $null
        verbose_git = [bool]$VerboseGit
        lfs_progress_log = $Paths.LfsProgressLog
    }
    Write-State -Paths $Paths -State $initialState

    Write-Output "Started detached Git/LFS push worker PID=$($worker.Id)"
    Write-Output "Repo root: $ResolvedRepoRoot"
    Write-Output "Remote/branch: $Remote/$ResolvedBranch"
    Write-Output "Worker stdout: $($Paths.WorkerOutLog)"
    Write-Output "Worker stderr: $($Paths.WorkerErrLog)"
    Write-Output "Status command: pwsh -File tools/run-git-lfs-push-detached.ps1 -Mode Status"
}

function Invoke-WorkerLoop {
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [Parameter(Mandatory = $true)][string]$ResolvedBranch,
        [Parameter(Mandatory = $true)][object]$Paths
    )

    $state = @{
        repo_root = $ResolvedRepoRoot
        remote = $Remote
        branch = $ResolvedBranch
        mode = 'worker'
        status = 'running'
        worker_pid = $PID
        active_git_pid = $null
        attempt = 0
        start_utc = [DateTime]::UtcNow.ToString('o')
        last_attempt_utc = $null
        retry_delay_seconds = $RetryDelaySeconds
        max_attempts = $MaxAttempts
        latest_attempt_stdout = $null
        latest_attempt_stderr = $null
        last_exit_code = $null
        last_error = $null
        verbose_git = [bool]$VerboseGit
        lfs_progress_log = $Paths.LfsProgressLog
    }
    Write-State -Paths $Paths -State $state
    Set-Content -LiteralPath $Paths.PidFile -Value $PID -Encoding ASCII

    while ($true) {
        $state.attempt = [int]$state.attempt + 1
        $state.last_attempt_utc = [DateTime]::UtcNow.ToString('o')
        $state.status = 'running'

        $attemptStdOut = Join-Path $Paths.Dir ("git-push.attempt{0:d4}.out.log" -f $state.attempt)
        $attemptStdErr = Join-Path $Paths.Dir ("git-push.attempt{0:d4}.err.log" -f $state.attempt)
        $state.latest_attempt_stdout = $attemptStdOut
        $state.latest_attempt_stderr = $attemptStdErr
        $state.last_error = $null
        Write-State -Paths $Paths -State $state

        Write-Output ("{0} [INFO] Attempt {1} starting: git push {2} {3}" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'), $state.attempt, $Remote, $ResolvedBranch)
        $branchStatus = Get-BranchStatusText -ResolvedRepoRoot $ResolvedRepoRoot
        if (-not [string]::IsNullOrWhiteSpace($branchStatus)) {
            Write-Output $branchStatus
        }

        $prevGitTrace = $env:GIT_TRACE
        $prevGitTransferTrace = $env:GIT_TRANSFER_TRACE
        $prevGitCurlVerbose = $env:GIT_CURL_VERBOSE
        $prevGitLfsProgress = $env:GIT_LFS_PROGRESS
        if ($VerboseGit) {
            Remove-Item -LiteralPath $Paths.LfsProgressLog -Force -ErrorAction SilentlyContinue
            $env:GIT_TRACE = '1'
            $env:GIT_TRANSFER_TRACE = '1'
            $env:GIT_CURL_VERBOSE = '1'
            $env:GIT_LFS_PROGRESS = $Paths.LfsProgressLog
            Write-Output ("{0} [INFO] Verbose Git/LFS tracing enabled" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'))
        }

        $gitProcess = Start-Process -FilePath 'git' -ArgumentList @('push', $Remote, $ResolvedBranch) -WorkingDirectory $ResolvedRepoRoot -RedirectStandardOutput $attemptStdOut -RedirectStandardError $attemptStdErr -PassThru -WindowStyle Hidden
        $state.active_git_pid = $gitProcess.Id
        Write-State -Paths $Paths -State $state

        $gitProcess.WaitForExit()
        if ($null -eq $prevGitTrace) { Remove-Item Env:\GIT_TRACE -ErrorAction SilentlyContinue } else { $env:GIT_TRACE = $prevGitTrace }
        if ($null -eq $prevGitTransferTrace) { Remove-Item Env:\GIT_TRANSFER_TRACE -ErrorAction SilentlyContinue } else { $env:GIT_TRANSFER_TRACE = $prevGitTransferTrace }
        if ($null -eq $prevGitCurlVerbose) { Remove-Item Env:\GIT_CURL_VERBOSE -ErrorAction SilentlyContinue } else { $env:GIT_CURL_VERBOSE = $prevGitCurlVerbose }
        if ($null -eq $prevGitLfsProgress) { Remove-Item Env:\GIT_LFS_PROGRESS -ErrorAction SilentlyContinue } else { $env:GIT_LFS_PROGRESS = $prevGitLfsProgress }
        $exitCode = $gitProcess.ExitCode
        $state.active_git_pid = $null
        $state.last_exit_code = $exitCode
        Write-State -Paths $Paths -State $state

        if ($exitCode -eq 0) {
            $state.status = 'completed'
            Write-State -Paths $Paths -State $state
            Write-Output ("{0} [OK] git push completed successfully on attempt {1}" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'), $state.attempt)
            return
        }

        $state.status = 'retrying'
        $state.last_error = "git push exit code $exitCode"
        Write-State -Paths $Paths -State $state
        Write-Output ("{0} [WARN] git push failed with exit code {1}" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'), $exitCode)

        if ($MaxAttempts -gt 0 -and [int]$state.attempt -ge $MaxAttempts) {
            $state.status = 'failed'
            Write-State -Paths $Paths -State $state
            Write-Output ("{0} [ERROR] Max attempts reached; worker exiting" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'))
            exit $exitCode
        }

        Write-Output ("{0} [INFO] Sleeping {1} seconds before retry" -f (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'), $RetryDelaySeconds)
        Start-Sleep -Seconds $RetryDelaySeconds
    }
}

function Show-Status {
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [Parameter(Mandatory = $true)][object]$Paths
    )

    $running = Get-RunningProcessFromPidFile -Paths $Paths
    $state = Read-State -Paths $Paths

    Write-Output ("Repo root: {0}" -f $ResolvedRepoRoot)
    Write-Output ("Worker running: {0}" -f [bool]$running)
    if ($running) {
        Write-Output ("Worker PID: {0}" -f $running.Id)
    }

    if ($state) {
        Write-Output ("Status: {0}" -f $state.status)
        Write-Output ("Remote/branch: {0}/{1}" -f $state.remote, $state.branch)
        Write-Output ("Attempts: {0}" -f $state.attempt)
        Write-Output ("Last exit code: {0}" -f $state.last_exit_code)
        if ($state.active_git_pid) {
            Write-Output ("Active git PID: {0}" -f $state.active_git_pid)
        }
        if ($state.last_error) {
            Write-Output ("Last error: {0}" -f $state.last_error)
        }
    }

    Write-Output '--- branch status ---'
    Write-Output (Get-BranchStatusText -ResolvedRepoRoot $ResolvedRepoRoot)

    Show-TailIfPresent -Path $Paths.WorkerOutLog -LineCount $TailLines -Title 'worker stdout'
    Show-TailIfPresent -Path $Paths.WorkerErrLog -LineCount $TailLines -Title 'worker stderr'

    if ($state -and $state.latest_attempt_stdout) {
        Show-TailIfPresent -Path $state.latest_attempt_stdout -LineCount $TailLines -Title 'latest git stdout'
    }
    if ($state -and $state.latest_attempt_stderr) {
        Show-TailIfPresent -Path $state.latest_attempt_stderr -LineCount $TailLines -Title 'latest git stderr'
    }
    if ($state -and $state.lfs_progress_log) {
        $lfsSummary = Get-LfsProgressSummary -ProgressLogPath $state.lfs_progress_log
        if ($lfsSummary) {
            Write-Output '--- lfs progress summary ---'
            Write-Output ("Observed parts: {0}" -f $lfsSummary.ObservedParts)
            Write-Output ("Completed parts: {0}" -f $lfsSummary.CompletedParts)
            Write-Output ("Uploaded: {0} ({1} bytes)" -f (Format-ByteSize -Bytes $lfsSummary.UploadedBytes), $lfsSummary.UploadedBytes)
            Write-Output ("Known total: {0} ({1} bytes)" -f (Format-ByteSize -Bytes $lfsSummary.KnownTotalBytes), $lfsSummary.KnownTotalBytes)
            Write-Output ("Remaining: {0} ({1} bytes)" -f (Format-ByteSize -Bytes $lfsSummary.RemainingBytes), $lfsSummary.RemainingBytes)
            Write-Output ("Progress: {0}%" -f $lfsSummary.Percent)
        }
        Show-TailIfPresent -Path $state.lfs_progress_log -LineCount $TailLines -Title 'git-lfs progress'
    }
}

function Stop-DetachedWorker {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not $PSCmdlet.ShouldProcess('Detached Git/LFS push worker', 'Stop worker and active git process')) {
        return
    }

    $state = Read-State -Paths $Paths
    if ($state -and $state.active_git_pid) {
        Stop-Process -Id ([int]$state.active_git_pid) -Force -ErrorAction SilentlyContinue
    }

    $running = Get-RunningProcessFromPidFile -Paths $Paths
    if ($running) {
        Stop-Process -Id $running.Id -Force -ErrorAction SilentlyContinue
        Write-Output "Stopped detached Git/LFS push worker PID=$($running.Id)"
    }
    else {
        Write-Output 'Detached Git/LFS push worker is not running.'
    }
}

if ($MaxAttempts -lt 0) {
    throw '-MaxAttempts must be zero (unlimited) or a positive integer.'
}

Get-Command git -ErrorAction Stop | Out-Null

$resolvedRepoRoot = Resolve-RepoRootPath -ExplicitRepoRoot $RepoRoot
$resolvedBranch = if ([string]::IsNullOrWhiteSpace($Branch)) {
    Get-CurrentBranchName -ResolvedRepoRoot $resolvedRepoRoot
}
else {
    $Branch.Trim()
}
$statePaths = Get-StatePaths -ResolvedRepoRoot $resolvedRepoRoot
New-StateDirectory -Paths $statePaths

switch ($Mode) {
    'Start' {
        Start-DetachedWorker -ResolvedRepoRoot $resolvedRepoRoot -ResolvedBranch $resolvedBranch -Paths $statePaths
    }
    'Worker' {
        Invoke-WorkerLoop -ResolvedRepoRoot $resolvedRepoRoot -ResolvedBranch $resolvedBranch -Paths $statePaths
    }
    'Status' {
        Show-Status -ResolvedRepoRoot $resolvedRepoRoot -Paths $statePaths
    }
    'Stop' {
        Stop-DetachedWorker -Paths $statePaths
    }
}
