﻿# Trigger License Fulfillment (Gumroad Poll) workflow with bootstrap
# Usage: pwsh -NoLogo -NoProfile -File tools/run-gumroad-bootstrap.ps1

$gh = 'C:\Program Files\GitHub CLI\gh.exe'
$repo = "AuditToolkitLabs/Audit-Tool-"
$workflow = "license-fulfillment-gumroad.yml"

Write-Output "=== Gumroad License Fulfillment Bootstrap ==="
Write-Output ""
Write-Output "Triggering: $workflow"
Write-Output "Repository: $repo"
Write-Output ""
Write-Output "Workflow inputs:"
Write-Output "  - bootstrap_from_now: true"
Write-Output "  - allow_test_purchases: false"
Write-Output "  - dry_run: false"
Write-Output ""

Write-Output "Dispatching workflow..."

& $gh workflow run $workflow `
  --repo $repo `
  -f bootstrap_from_now=true `
  -f allow_test_purchases=false `
  -f dry_run=false

if ($LASTEXITCODE -eq 0) {
    Write-Output "✓ Workflow dispatched successfully!"
    Write-Output ""
    Write-Output "Monitor the workflow at:"
    Write-Output "https://github.com/$repo/actions/workflows/$workflow"
    Write-Output ""
    Write-Output "Expected results:"
    Write-Output "  1. Workflow polls Gumroad sales starting from now"
    Write-Output "  2. Workflow creates GUMROAD_LAST_CURSOR variable"
    Write-Output "  3. Next scheduled run (in 15 min) will use this cursor"
} else {
    Write-Output "✗ Failed to dispatch workflow"
    exit 1
}

