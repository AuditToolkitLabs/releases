[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseOutputTypeCorrectly', '', Justification='Preserve existing return contracts while avoiding risky runtime refactors during stabilization')]
param(
    [string]$Repo = "AuditToolkitLabs/Audit-Tool-",
    [string]$Workflow = "license-fulfillment-gumroad.yml",
    [string]$GhPath = "gh",
    [string]$Cursor = "",
    [switch]$BootstrapIfMissing,
    [switch]$AllowTestPurchases,
    [switch]$DryRun,
    [int]$RunCount = 2,
    [int]$PollSeconds = 5,
    [int]$PollAttempts = 180,
    [string]$OutputPath = "tools/tmp/gumroad-next-steps-summary.json"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$env:GH_PAGER = "cat"
if (Test-Path Env:GH_DEBUG) {
    Remove-Item Env:GH_DEBUG -ErrorAction SilentlyContinue
}

if (-not $PSBoundParameters.ContainsKey("BootstrapIfMissing")) {
    $BootstrapIfMissing = $true
}
if (-not $PSBoundParameters.ContainsKey("AllowTestPurchases")) {
    $AllowTestPurchases = $true
}

function Invoke-Gh {
    param([Parameter(Mandatory = $true)][string[]]$Args)

    & $GhPath @Args 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "gh command failed: $($Args -join ' ')"
    }
}

function Get-RepoVariable {
    param([Parameter(Mandatory = $true)][string]$Name)

    $output = & $GhPath variable get $Name --repo $Repo 2>$null
    if ($LASTEXITCODE -ne 0) {
        return ""
    }

    return (($output | Out-String).Trim())
}

function Get-SecretNames {
    $json = & $GhPath secret list --repo $Repo --json name
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($json)) {
        return @()
    }

    try {
        $rows = $json | ConvertFrom-Json
        return @($rows | ForEach-Object { [string]$_.name })
    }
    catch {
        return @()
    }
}

function Start-Run {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param(
        [Parameter(Mandatory = $true)][string]$CursorValue,
        [Parameter(Mandatory = $true)][bool]$Bootstrap,
        [Parameter(Mandatory = $true)][bool]$AllowTest,
        [Parameter(Mandatory = $true)][bool]$RunDry
    )

    if (-not $PSCmdlet.ShouldProcess($Repo, "Dispatch Gumroad workflow run (workflow=$Workflow, cursor=$CursorValue)")) {
        return 0
    }

    Invoke-Gh -Args @(
        "workflow", "run", $Workflow,
        "--repo", $Repo,
        "-f", "cursor=$CursorValue",
        "-f", "bootstrap_from_now=$($Bootstrap.ToString().ToLowerInvariant())",
        "-f", "allow_test_purchases=$($AllowTest.ToString().ToLowerInvariant())",
        "-f", "dry_run=$($RunDry.ToString().ToLowerInvariant())"
    )

    Start-Sleep -Seconds 4

    $runIdRaw = & $GhPath run list --repo $Repo --workflow $Workflow --limit 1 --json databaseId --jq ".[0].databaseId" 2>$null
    if ($LASTEXITCODE -ne 0 -or $null -eq $runIdRaw) {
        throw "Unable to resolve workflow run id after dispatch."
    }

    $runIdText = ($runIdRaw | Out-String).Trim()
    $match = [regex]::Match($runIdText, "\d{6,}")
    if (-not $match.Success) {
        throw "Unable to parse run id from gh output."
    }

    return [int64]$match.Value
}

function Wait-Run {
    param([Parameter(Mandatory = $true)][int64]$RunId)

    for ($i = 0; $i -lt $PollAttempts; $i++) {
        $raw = & $GhPath run view $RunId --repo $Repo --json status,conclusion,updatedAt 2>$null
        if ($LASTEXITCODE -ne 0) {
            Start-Sleep -Seconds $PollSeconds
            continue
        }

        $state = $raw | ConvertFrom-Json
        if ($state.status -eq "completed") {
            if ($state.conclusion -ne "success") {
                throw "Workflow run $RunId finished with conclusion '$($state.conclusion)'."
            }

            return
        }

        Start-Sleep -Seconds $PollSeconds
    }

    throw "Timed out waiting for run $RunId."
}

function Get-RunSummary {
    param([Parameter(Mandatory = $true)][int64]$RunId)

    $log = & $GhPath run view $RunId --repo $Repo --log 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "Unable to fetch logs for run $RunId"
    }

    $lines = @($log -split "`r?`n")

    $fetched = 0
    $queued = 0
    $processed = 0
    $failures = 0
    $outputCursor = ""

    foreach ($line in $lines) {
        if ($line -match "Fetched sales:\s*(\d+)") { $fetched = [int]$Matches[1] }
        if ($line -match "Queued sales:\s*(\d+)") { $queued = [int]$Matches[1] }
        if ($line -match "Processed sales:\s*(\d+)") { $processed = [int]$Matches[1] }
        if ($line -match "Failures:\s*(\d+)") { $failures = [int]$Matches[1] }
        if ($line -match "Output cursor:\s*(.+)$") { $outputCursor = $Matches[1].Trim() }
    }

    [pscustomobject]@{
        run_id = $RunId
        fetched_sales = $fetched
        queued_sales = $queued
        processed_sales = $processed
        failures = $failures
        output_cursor = $outputCursor
    }
}

function Get-GumroadProductsSnapshot {
    $token = [string]$env:GUMROAD_ACCESS_TOKEN
    if ([string]::IsNullOrWhiteSpace($token)) {
        return [pscustomobject]@{
            checked = $false
            reason = "GUMROAD_ACCESS_TOKEN is not set in local shell"
            total_products = $null
            published_products = $null
        }
    }

    $uri = "https://api.gumroad.com/v2/products?access_token=$([uri]::EscapeDataString($token))"
    try {
        $resp = Invoke-RestMethod -Method Get -Uri $uri -TimeoutSec 30
    }
    catch {
        return [pscustomobject]@{
            checked = $false
            reason = "Failed to query /v2/products with local token"
            total_products = $null
            published_products = $null
        }
    }

    $products = @($resp.products)
    $published = @(
        $products | Where-Object {
            ($_ | Get-Member -Name "published" -MemberType NoteProperty -ErrorAction SilentlyContinue) -and $_.published -eq $true
        }
    )

    [pscustomobject]@{
        checked = $true
        reason = "ok"
        total_products = $products.Count
        published_products = $published.Count
    }
}

Write-Output "=== Gumroad Next Steps Automation ==="
Write-Output "Repo: $Repo"
Write-Output "Workflow: $Workflow"
Write-Output "RunCount: $RunCount | AllowTestPurchases: $AllowTestPurchases | DryRun: $DryRun"

$requiredVars = @(
    "GUMROAD_STARTER_PRODUCT_ID",
    "GUMROAD_PROFESSIONAL_PRODUCT_ID",
    "GUMROAD_BUSINESS_PRODUCT_ID",
    "GUMROAD_ENTERPRISE_PRODUCT_ID"
)
$varsState = foreach ($name in $requiredVars) {
    $value = Get-RepoVariable -Name $name
    [pscustomobject]@{
        name = $name
        configured = -not [string]::IsNullOrWhiteSpace($value)
        value = if ($value) { $value } else { "" }
    }
}
$missingVars = @($varsState | Where-Object { -not $_.configured })

$secretNames = Get-SecretNames
$tokenSecretPresent = $secretNames -contains "GUMROAD_ACCESS_TOKEN"

$productSnapshot = Get-GumroadProductsSnapshot

$startCursor = if ($Cursor) { $Cursor.Trim() } else { Get-RepoVariable -Name "GUMROAD_LAST_CURSOR" }
$bootstrapRun = $null

if ([string]::IsNullOrWhiteSpace($startCursor) -and $BootstrapIfMissing) {
    Write-Output "No stored cursor found. Bootstrapping from now..."
    $bootstrapId = Start-Run -CursorValue "" -Bootstrap $true -AllowTest:$false -RunDry:$false
    Wait-Run -RunId $bootstrapId
    $bootstrapSummary = Get-RunSummary -RunId $bootstrapId
    $startCursor = Get-RepoVariable -Name "GUMROAD_LAST_CURSOR"
    $bootstrapRun = [pscustomobject]@{
        run_id = $bootstrapId
        summary = $bootstrapSummary
    }
}

if ([string]::IsNullOrWhiteSpace($startCursor)) {
    throw "Cursor is empty and bootstrap did not populate GUMROAD_LAST_CURSOR."
}

$runSummaries = @()
$currentCursor = $startCursor
for ($i = 1; $i -le $RunCount; $i++) {
    Write-Output "Dispatching canary run $i/$RunCount with cursor: $currentCursor"
    $runId = Start-Run -CursorValue $currentCursor -Bootstrap $false -AllowTest:$AllowTestPurchases -RunDry:$DryRun
    Wait-Run -RunId $runId
    $summary = Get-RunSummary -RunId $runId
    $runSummaries += [pscustomobject]@{
        ordinal = $i
        input_cursor = $currentCursor
        run = $summary
    }

    $repoCursor = Get-RepoVariable -Name "GUMROAD_LAST_CURSOR"
    if (-not [string]::IsNullOrWhiteSpace($repoCursor)) {
        $currentCursor = $repoCursor
    }
    elseif (-not [string]::IsNullOrWhiteSpace($summary.output_cursor)) {
        $currentCursor = $summary.output_cursor
    }
}

$totalProcessed = 0
$totalFailures = 0
foreach ($entry in $runSummaries) {
    $totalProcessed += [int]$entry.run.processed_sales
    $totalFailures += [int]$entry.run.failures
}

$manualNeeds = @()
if (-not $tokenSecretPresent) {
    $manualNeeds += "Set repository secret GUMROAD_ACCESS_TOKEN."
}
if ($missingVars.Count -gt 0) {
    $manualNeeds += "Set missing repo variables: $(@($missingVars.name) -join ', ')"
}
if ($productSnapshot.checked -and ($productSnapshot.published_products -eq 0)) {
    $manualNeeds += "Publish at least one Gumroad product (local token check found 0 published)."
}
if ($totalProcessed -eq 0) {
    $manualNeeds += "Create one Gumroad purchase (test purchase is fine) after product publish, then rerun this script."
}
if ($totalFailures -gt 0) {
    $manualNeeds += "Investigate fulfillment failures from workflow artifacts before go-live."
}

$result = [pscustomobject]@{
    timestamp_utc = (Get-Date).ToUniversalTime().ToString("o")
    repo = $Repo
    workflow = $Workflow
    token_secret_present = $tokenSecretPresent
    gumroad_products_snapshot = $productSnapshot
    variable_state = $varsState
    start_cursor = $startCursor
    bootstrap_run = $bootstrapRun
    runs = $runSummaries
    totals = [pscustomobject]@{
        run_count = $runSummaries.Count
        processed_sales = [int]$totalProcessed
        failures = [int]$totalFailures
    }
    final_cursor = $currentCursor
    manual_needs = $manualNeeds
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputPath) | Out-Null
$result | ConvertTo-Json -Depth 8 | Out-File -FilePath $OutputPath -Encoding utf8

Write-Output ""
Write-Output "Summary written: $OutputPath"
Write-Output "Processed sales across runs: $totalProcessed"
Write-Output "Failures across runs: $totalFailures"
if ($manualNeeds.Count -gt 0) {
    Write-Output "Manual actions still required:"
    $manualNeeds | ForEach-Object { Write-Host " - $_" -ForegroundColor Yellow }
} else {
    Write-Output "No manual blockers detected from available checks."
}

