param(
    [string]$CoreUrl = 'http://localhost:5000',
    [string]$Username = 'admin',
    [SecureString]$Password,
    [switch]$SkipCertificateCheck
)

if ($SkipCertificateCheck) {
    $PSDefaultParameterValues['Invoke-RestMethod:SkipCertificateCheck'] = $true
    $PSDefaultParameterValues['Invoke-WebRequest:SkipCertificateCheck'] = $true
}

$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$outDir = 'C:\Github\Audit-Tool-\tests\deployment'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$evidence = [ordered]@{
    scenario = 'fleet-agent-targeted'
    timestamp = $ts
    core = $CoreUrl
    checks = @()
}

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function ConvertTo-PlainText {
    param([SecureString]$SecureValue)

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

function Add-Check {
    param(
        [string]$Name,
        [bool]$Success,
        [int]$Status,
        [string]$Detail
    )

    $script:evidence.checks += [ordered]@{
        name = $Name
        success = $Success
        status = $Status
        detail = $Detail
    }
}

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$apiKey = $null
$headers = @{}

if (-not $Password) {
    $Password = ConvertTo-InMemorySecureString -Value 'ChangeMe123!'
}
$plainPassword = ConvertTo-PlainText -SecureValue $Password

try {
    $health = Invoke-RestMethod -Method Get -Uri "$CoreUrl/health" -TimeoutSec 20
    Add-Check -Name 'health' -Success $true -Status 200 -Detail ($health | ConvertTo-Json -Depth 6 -Compress)
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'health' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

try {
    $loginBody = @{ username = $Username; password = $plainPassword } | ConvertTo-Json
    $login = Invoke-RestMethod -Method Post -Uri "$CoreUrl/auth/login" -ContentType 'application/json' -Body $loginBody -WebSession $session -TimeoutSec 20
    Add-Check -Name 'auth-login' -Success $true -Status 200 -Detail ($login | ConvertTo-Json -Depth 4 -Compress)
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'auth-login' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

try {
    $apiKeyResp = Invoke-RestMethod -Method Get -Uri "$CoreUrl/api/settings/api-key" -WebSession $session -TimeoutSec 20
    if ($apiKeyResp.api_key) {
        $apiKey = [string]$apiKeyResp.api_key
        $headers = @{ 'X-API-Key' = $apiKey }
        Add-Check -Name 'api-key-fetch' -Success $true -Status 200 -Detail 'api key retrieved'
    }
    else {
        Add-Check -Name 'api-key-fetch' -Success $false -Status 200 -Detail 'api_key missing in response'
    }
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'api-key-fetch' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

try {
    $linuxInstaller = Invoke-WebRequest -Method Get -Uri "$CoreUrl/api/agent/download/installer/linux" -Headers $headers -WebSession $session -TimeoutSec 20
    $ok = ($linuxInstaller.StatusCode -ge 200 -and $linuxInstaller.StatusCode -lt 300)
    Add-Check -Name 'managed-linux-installer' -Success $ok -Status $linuxInstaller.StatusCode -Detail ("bytes={0}" -f $linuxInstaller.RawContentLength)
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'managed-linux-installer' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

try {
    $windowsInstaller = Invoke-WebRequest -Method Get -Uri "$CoreUrl/api/agent/download/installer/windows" -Headers $headers -WebSession $session -TimeoutSec 20
    $ok = ($windowsInstaller.StatusCode -ge 200 -and $windowsInstaller.StatusCode -lt 300)
    Add-Check -Name 'managed-windows-installer' -Success $ok -Status $windowsInstaller.StatusCode -Detail ("bytes={0}" -f $windowsInstaller.RawContentLength)
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'managed-windows-installer' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

try {
    $body = @{
        agent_id = 'managed-smoke-001'
        hostname = $env:COMPUTERNAME
        results = @(
            @{
                audit_path = 'audits/platform/baseline/updates.ps1'
                executed_at = (Get-Date).AddMinutes(-1).ToString('o')
                completed_at = (Get-Date).ToString('o')
                exit_code = 0
                status = 'success'
                output = 'managed ingest smoke'
                summary = @{
                    total = 1
                    pass = 1
                    warn = 0
                    fail = 0
                    skip = 0
                }
                checks = @(
                    @{
                        name = 'managed-smoke-check'
                        status = 'PASS'
                        message = 'managed ingest smoke'
                    }
                )
            }
        )
    } | ConvertTo-Json -Depth 12

    $ingest = Invoke-RestMethod -Method Post -Uri "$CoreUrl/api/agent/managed/results/ingest" -Headers $headers -WebSession $session -ContentType 'application/json' -Body $body -TimeoutSec 20
    Add-Check -Name 'managed-results-ingest' -Success $true -Status 200 -Detail ($ingest | ConvertTo-Json -Depth 6 -Compress)
}
catch {
    $statusCode = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Add-Check -Name 'managed-results-ingest' -Success $false -Status $statusCode -Detail $_.Exception.Message
}

$passed = @($evidence.checks | Where-Object { $_.success -eq $true }).Count
$failed = @($evidence.checks | Where-Object { $_.success -eq $false }).Count
$evidence.summary = [ordered]@{
    total = @($evidence.checks).Count
    passed = $passed
    failed = $failed
}

$outputPath = Join-Path $outDir ("fleet-agent-targeted-evidence-$ts.json")
($evidence | ConvertTo-Json -Depth 12) | Set-Content -Path $outputPath -Encoding UTF8

Write-Output "Evidence JSON: $outputPath"
Write-Output ($evidence.summary | ConvertTo-Json -Compress)
