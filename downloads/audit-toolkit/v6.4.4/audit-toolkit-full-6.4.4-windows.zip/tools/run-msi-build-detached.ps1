#Requires -Version 5.1
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [ValidateSet('Start', 'Status', 'Stop')]
    [string]$Mode = 'Start',

    [Parameter()]
    [string]$RepoRoot = '',

    [Parameter()]
    [string]$Version = '',

    [Parameter()]
    [string]$OutputDir = '',

    [Parameter()]
    [switch]$Clean,

    [Parameter()]
    [switch]$SkipValidation,

    [Parameter()]
    [switch]$RequireAdmin,

    [Parameter()]
    [ValidateRange(5, 200)]
    [int]$TailLines = 25,

    [Parameter()]
    [switch]$ForceRestart
)

$null = $Clean, $SkipValidation, $TailLines, $ForceRestart

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-RepoRootPath {
    param([string]$ExplicitRepoRoot)

    $candidate = if ([string]::IsNullOrWhiteSpace($ExplicitRepoRoot)) {
        Join-Path $PSScriptRoot '..'
    }
    else {
        $ExplicitRepoRoot
    }

    return (Resolve-Path -LiteralPath $candidate).Path
}

function Get-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Resolve-VersionValue {
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [string]$ExplicitVersion
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitVersion)) {
        return $ExplicitVersion.Trim()
    }

    $versionFile = Join-Path $ResolvedRepoRoot 'VERSION'
    if (Test-Path -LiteralPath $versionFile) {
        $detected = (Get-Content -LiteralPath $versionFile -Raw).Trim()
        if (-not [string]::IsNullOrWhiteSpace($detected)) {
            return $detected
        }
    }

    return '6.0.0'
}

function Resolve-OutputDirectory {
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [string]$ExplicitOutputDir
    )

    if ([string]::IsNullOrWhiteSpace($ExplicitOutputDir)) {
        return (Join-Path $ResolvedRepoRoot 'deployment\windows\bin')
    }

    if ([System.IO.Path]::IsPathRooted($ExplicitOutputDir)) {
        return [System.IO.Path]::GetFullPath($ExplicitOutputDir)
    }

    return [System.IO.Path]::GetFullPath((Join-Path $ResolvedRepoRoot $ExplicitOutputDir))
}

function Get-StatePaths {
    param([Parameter(Mandatory = $true)][string]$ResolvedOutputDir)

    [PSCustomObject]@{
        OutputDir = $ResolvedOutputDir
        StartFile = Join-Path $ResolvedOutputDir 'build-msi-detached.start'
        PidFile = Join-Path $ResolvedOutputDir 'build-msi-detached.pid'
        OutLog = Join-Path $ResolvedOutputDir 'build-msi-detached.out.log'
        ErrLog = Join-Path $ResolvedOutputDir 'build-msi-detached.err.log'
        StateFile = Join-Path $ResolvedOutputDir 'build-msi-detached.state.json'
        RunsDir = Join-Path $ResolvedOutputDir 'runs'
    }
}

function New-OutputDirectory {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param([Parameter(Mandatory = $true)][object]$Paths)

    if ($PSCmdlet.ShouldProcess($Paths.OutputDir, 'Ensure output and runs directories exist')) {
        $null = New-Item -ItemType Directory -Path $Paths.OutputDir -Force
        $null = New-Item -ItemType Directory -Path $Paths.RunsDir -Force
    }
}

function Get-CurrentLogPaths {
    param(
        [Parameter(Mandatory = $true)][object]$Paths,
        $State
    )

    $stdoutPath = $Paths.OutLog
    $stderrPath = $Paths.ErrLog

    if ($State) {
        if ($State.PSObject.Properties.Name -contains 'stdout_log' -and -not [string]::IsNullOrWhiteSpace($State.stdout_log)) {
            $stdoutPath = [string]$State.stdout_log
        }
        if ($State.PSObject.Properties.Name -contains 'stderr_log' -and -not [string]::IsNullOrWhiteSpace($State.stderr_log)) {
            $stderrPath = [string]$State.stderr_log
        }
    }

    return [PSCustomObject]@{
        StdOut = $stdoutPath
        StdErr = $stderrPath
    }
}

function Read-State {
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not (Test-Path -LiteralPath $Paths.StateFile)) {
        return $null
    }

    return (Get-Content -LiteralPath $Paths.StateFile -Raw | ConvertFrom-Json)
}

function Resolve-StatusVersion {
    param(
        [Parameter(Mandatory = $true)][object]$Paths,
        [string]$RequestedVersion,
        [Parameter(Mandatory = $true)][string]$FallbackVersion
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedVersion)) {
        return $RequestedVersion.Trim()
    }

    $state = Read-State -Paths $Paths
    if ($state -and -not [string]::IsNullOrWhiteSpace($state.version)) {
        return [string]$state.version
    }

    return $FallbackVersion
}

function Write-State {
    param(
        [Parameter(Mandatory = $true)][object]$Paths,
        [Parameter(Mandatory = $true)][hashtable]$State
    )

    $State | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Paths.StateFile -Encoding UTF8
}

function Get-RunningProcessFromPidFile {
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not (Test-Path -LiteralPath $Paths.PidFile)) {
        return $null
    }

    $rawPid = (Get-Content -LiteralPath $Paths.PidFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($rawPid)) {
        return $null
    }

    $buildPid = 0
    if (-not [int]::TryParse($rawPid, [ref]$buildPid)) {
        return $null
    }

    return (Get-Process -Id $buildPid -ErrorAction SilentlyContinue)
}

function Show-TailIfPresent {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][int]$LineCount,
        [Parameter(Mandatory = $true)][string]$Title
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    Write-Output "--- $Title ---"
    Get-Content -LiteralPath $Path -Tail $LineCount
}

function Start-MsiBuild {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory = $true)][string]$ResolvedRepoRoot,
        [Parameter(Mandatory = $true)][string]$ResolvedVersion,
        [Parameter(Mandatory = $true)][object]$Paths,
        [Parameter(Mandatory = $true)][string]$BuildScriptPath
    )

    if (-not $PSCmdlet.ShouldProcess($ResolvedRepoRoot, "Start detached MSI build for version $ResolvedVersion")) {
        return
    }

    $running = Get-RunningProcessFromPidFile -Paths $Paths
    if ($running) {
        if (-not $ForceRestart) {
            Write-Output "Detached MSI build already running: PID=$($running.Id)"
            Write-Output "Use -Mode Status to inspect or -Mode Stop to terminate it."
            return
        }

        Stop-Process -Id $running.Id -Force
        Start-Sleep -Seconds 1
    }

    Remove-Item -LiteralPath $Paths.OutLog, $Paths.ErrLog, $Paths.PidFile -Force -ErrorAction SilentlyContinue
    Set-Content -LiteralPath $Paths.StartFile -Value ([DateTime]::UtcNow.ToString('o')) -Encoding ASCII

    $runStamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
    $runStdOutLog = Join-Path $Paths.RunsDir ("build-msi-$runStamp.out.log")
    $runStdErrLog = Join-Path $Paths.RunsDir ("build-msi-$runStamp.err.log")
    $runMetaPath = Join-Path $Paths.RunsDir ("build-msi-$runStamp.meta.json")

    $argumentList = @(
        '-NoLogo',
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        $BuildScriptPath,
        '-Version',
        $ResolvedVersion,
        '-OutputPath',
        $Paths.OutputDir
    )
    if ($Clean) {
        $argumentList += '-Clean'
    }
    if ($SkipValidation) {
        $argumentList += '-SkipValidation'
    }

    $process = Start-Process -FilePath 'pwsh' -ArgumentList $argumentList -WorkingDirectory $ResolvedRepoRoot -RedirectStandardOutput $runStdOutLog -RedirectStandardError $runStdErrLog -PassThru -WindowStyle Hidden
    Set-Content -LiteralPath $Paths.PidFile -Value $process.Id -Encoding ASCII
    Set-Content -LiteralPath $Paths.OutLog -Value $runStdOutLog -Encoding UTF8
    Set-Content -LiteralPath $Paths.ErrLog -Value $runStdErrLog -Encoding UTF8

    $state = @{
        mode = 'detached-msi-build'
        repo_root = $ResolvedRepoRoot
        version = $ResolvedVersion
        output_dir = $Paths.OutputDir
        build_script = $BuildScriptPath
        pid = $process.Id
        start_utc = [DateTime]::UtcNow.ToString('o')
        clean = [bool]$Clean
        skip_validation = [bool]$SkipValidation
        require_admin = [bool]$RequireAdmin
        stdout_log = $runStdOutLog
        stderr_log = $runStdErrLog
        run_stamp = $runStamp
        run_meta = $runMetaPath
    }
    Write-State -Paths $Paths -State $state

    @{
        repo_root = $ResolvedRepoRoot
        version = $ResolvedVersion
        output_dir = $Paths.OutputDir
        pid = $process.Id
        start_utc = [DateTime]::UtcNow.ToString('o')
        clean = [bool]$Clean
        skip_validation = [bool]$SkipValidation
        require_admin = [bool]$RequireAdmin
        stdout_log = $runStdOutLog
        stderr_log = $runStdErrLog
    } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $runMetaPath -Encoding UTF8

    Write-Output "Started detached MSI build PID=$($process.Id) version=$ResolvedVersion"
    Write-Output "Output directory: $($Paths.OutputDir)"
    Write-Output "Start marker: $($Paths.StartFile)"
    Write-Output "StdOut log: $runStdOutLog"
    Write-Output "StdErr log: $runStdErrLog"
    Write-Output "Run metadata: $runMetaPath"
    Write-Output "Status: pwsh -File tools/run-msi-build-detached.ps1 -Mode Status"
}

function Show-MsiStatus {
    param(
        [Parameter(Mandatory = $true)][object]$Paths,
        [Parameter(Mandatory = $true)][string]$ResolvedVersion
    )

    $state = Read-State -Paths $Paths
    $logPaths = Get-CurrentLogPaths -Paths $Paths -State $state
    $running = Get-RunningProcessFromPidFile -Paths $Paths
    $started = $null
    if (Test-Path -LiteralPath $Paths.StartFile) {
        try {
            $started = [datetime](Get-Content -LiteralPath $Paths.StartFile -Raw)
        }
        catch {
            $started = $null
        }
    }

    $msiPath = Join-Path $Paths.OutputDir ("SecurityAuditToolkit-$ResolvedVersion-x64.msi")
    $fallbackArtifact = $null
    $artifactOk = $false

    Write-Output ("Output directory: {0}" -f $Paths.OutputDir)
    Write-Output ("Expected MSI: {0}" -f $msiPath)
    Write-Output ("Build running: {0}" -f [bool]$running)
    if ($running) {
        Write-Output ("Build PID: {0}" -f $running.Id)
    }

    if (Test-Path -LiteralPath $msiPath) {
        $item = Get-Item -LiteralPath $msiPath
        if ((-not $started) -or ($item.LastWriteTimeUtc -gt $started.ToUniversalTime())) {
            $artifactOk = $true
            $item | Select-Object FullName, Length, LastWriteTime | Format-List
        }
        else {
            Write-Output 'MSI exists but predates latest start marker.'
        }
    }
    else {
        Write-Output 'MSI not present yet.'

        $fallbackArtifact = Get-ChildItem -LiteralPath $Paths.OutputDir -Filter 'SecurityAuditToolkit-*-x64.msi' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTimeUtc -Descending |
            Select-Object -First 1

        if ($fallbackArtifact) {
            Write-Output ("Newest available MSI artifact differs from requested version: {0}" -f $fallbackArtifact.Name)
            if ((-not $started) -or ($fallbackArtifact.LastWriteTimeUtc -gt $started.ToUniversalTime())) {
                $artifactOk = $true
                $fallbackArtifact | Select-Object FullName, Length, LastWriteTime | Format-List
            }
        }
    }

    if ($state -and ($state.PSObject.Properties.Name -contains 'run_meta') -and -not [string]::IsNullOrWhiteSpace($state.run_meta)) {
        Write-Output ("Run metadata: {0}" -f $state.run_meta)
    }

    Show-TailIfPresent -Path $logPaths.StdOut -LineCount $TailLines -Title 'tail stdout'
    Show-TailIfPresent -Path $logPaths.StdErr -LineCount $TailLines -Title 'tail stderr'

    if ($artifactOk -or $running) {
        exit 0
    }

    Write-Error 'MSI build is not running and a fresh MSI artifact was not found.'
    exit 1
}

function Stop-MsiBuild {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param([Parameter(Mandatory = $true)][object]$Paths)

    if (-not $PSCmdlet.ShouldProcess('Detached MSI build worker', 'Stop running detached MSI build process')) {
        return
    }

    $running = Get-RunningProcessFromPidFile -Paths $Paths
    if ($running) {
        Stop-Process -Id $running.Id -Force -ErrorAction SilentlyContinue
        Write-Output "Stopped detached MSI build PID=$($running.Id)"
        return
    }

    Write-Output 'Detached MSI build is not running.'
}

$resolvedRepoRoot = Resolve-RepoRootPath -ExplicitRepoRoot $RepoRoot
$resolvedOutputDir = Resolve-OutputDirectory -ResolvedRepoRoot $resolvedRepoRoot -ExplicitOutputDir $OutputDir
$statePaths = Get-StatePaths -ResolvedOutputDir $resolvedOutputDir
New-OutputDirectory -Paths $statePaths
$resolvedVersion = Resolve-StatusVersion -Paths $statePaths -RequestedVersion $Version -FallbackVersion (Resolve-VersionValue -ResolvedRepoRoot $resolvedRepoRoot -ExplicitVersion $Version)

$buildScript = Join-Path $resolvedRepoRoot 'deployment\windows\Build-MSI.ps1'
if (-not (Test-Path -LiteralPath $buildScript)) {
    throw "Missing build script: $buildScript"
}

if ($RequireAdmin -and -not (Get-IsAdministrator)) {
    throw 'This command must be run from an elevated PowerShell session.'
}

if (-not (Get-IsAdministrator)) {
    Write-Output 'Running without elevation. If WiX or file-system permissions fail, rerun from an Administrator PowerShell shell.'
}

switch ($Mode) {
    'Start' {
        Start-MsiBuild -ResolvedRepoRoot $resolvedRepoRoot -ResolvedVersion $resolvedVersion -Paths $statePaths -BuildScriptPath $buildScript
    }
    'Status' {
        Show-MsiStatus -Paths $statePaths -ResolvedVersion $resolvedVersion
    }
    'Stop' {
        Stop-MsiBuild -Paths $statePaths
    }
}
