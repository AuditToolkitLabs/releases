[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Version = '',

    [Parameter()]
    [string]$ReleaseTag = '',

    [Parameter()]
    [string]$Repo = '',

    [Parameter()]
    [string]$SourceDirectory = 'deployment/vm-appliance/output',

    [Parameter()]
    [string]$StagingDirectory = '',

    [Parameter()]
    [ValidateRange(100, 32768)]
    [int]$SplitPartSizeMB = 950,

    [Parameter()]
    [ValidateRange(5, 300)]
    [int]$HeartbeatSeconds = 20,

    [Parameter()]
    [ValidateRange(1, 30)]
    [int]$MaxAttemptsPerFile = 5,

    [Parameter()]
    [ValidateRange(300, 43200)]
    [int]$MaxSecondsPerFile = 14400,

    [Parameter()]
    [ValidateRange(1, 72)]
    [int]$MaxRuntimeHours = 24,

    [Parameter()]
    [ValidateRange(5, 600)]
    [int]$RetryDelaySeconds = 30,

    [Parameter()]
    [bool]$CreateReleaseIfMissing = $true,

    [Parameter()]
    [switch]$ForceRebuildStaging
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-RepoSlug {
    param([string]$ExplicitRepo)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRepo)) {
        return $ExplicitRepo.Trim()
    }

    $origin = (& git config --get remote.origin.url 2>$null)
    if ([string]::IsNullOrWhiteSpace($origin)) {
        throw 'Unable to determine repository slug. Provide -Repo owner/name.'
    }

    $origin = $origin.Trim()
    if ($origin -match 'github\.com[:/](?<slug>[^/]+/[^/.]+)(?:\.git)?$') {
        return $Matches['slug']
    }

    throw "Unsupported remote URL format for GitHub repo detection: $origin"
}

function Resolve-Version {
    param(
        [string]$ExplicitVersion,
        [string]$RepoRoot
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitVersion)) {
        return $ExplicitVersion.Trim()
    }

    $versionFile = Join-Path $RepoRoot 'VERSION'
    if (-not (Test-Path -LiteralPath $versionFile)) {
        throw "VERSION file not found at: $versionFile"
    }

    $detected = (Get-Content -LiteralPath $versionFile -Raw).Trim()
    if ([string]::IsNullOrWhiteSpace($detected)) {
        throw 'VERSION file is empty. Provide -Version explicitly.'
    }

    return $detected
}

function Resolve-FullPath {
    param(
        [Parameter(Mandatory = $true)][string]$PathValue,
        [Parameter(Mandatory = $true)][string]$BasePath
    )

    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return [System.IO.Path]::GetFullPath($PathValue)
    }

    return [System.IO.Path]::GetFullPath((Join-Path $BasePath $PathValue))
}

$script:LogPath = $null
function Write-UploadLog {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'OK')][string]$Level = 'INFO'
    )

    $timestamp = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK')
    $line = "$timestamp [$Level] $Message"

    switch ($Level) {
        'WARN' { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'OK' { Write-Host $line -ForegroundColor Green }
        default { Write-Host $line -ForegroundColor Cyan }
    }

    if (-not [string]::IsNullOrWhiteSpace($script:LogPath)) {
        Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8
    }
}

function Test-GitHubCliReady {
    Get-Command gh -ErrorAction Stop | Out-Null
    & gh auth status --hostname github.com *> $null
    if (-not $?) {
        throw 'GitHub CLI is not authenticated. Run: gh auth login'
    }
}

function Set-ReleaseAvailable {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param(
        [Parameter(Mandatory = $true)][string]$Tag,
        [Parameter(Mandatory = $true)][string]$RepoSlug,
        [Parameter(Mandatory = $true)][string]$VersionText,
        [Parameter(Mandatory = $true)][bool]$CreateIfMissing
    )

    & gh release view $Tag --repo $RepoSlug *> $null
    if ($?) {
        return
    }

    if (-not $CreateIfMissing) {
        throw "Release $Tag does not exist and CreateReleaseIfMissing is false."
    }

    if ($PSCmdlet.ShouldProcess($RepoSlug, "Create draft GitHub release $Tag")) {
        Write-UploadLog -Level INFO -Message "Release $Tag not found; creating draft release"
        & gh release create $Tag --repo $RepoSlug --title "Security Audit Toolkit $VersionText" --notes "VM appliance artifacts for $VersionText" --draft
        if (-not $?) {
            throw "Failed to create release $Tag"
        }
    }
}

function Get-UploadFiles {
    param([Parameter(Mandatory = $true)][string]$Directory)

    @(Get-ChildItem -LiteralPath $Directory -File | Where-Object {
        $_.Name -notmatch '^\.upload-state\.txt$|^\.upload\.lock\.json$|^UPLOAD-COMPLETE\.txt$|^unattended-upload.*\.log$|^upload-resume-.*\.log$|^\.gh-.*\.(out|err)$'
    } | Sort-Object Name)
}

function Get-StateSet {
    param([Parameter(Mandatory = $true)][string]$StatePath)

    $stateSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if (Test-Path -LiteralPath $StatePath) {
        $lines = Get-Content -LiteralPath $StatePath -ErrorAction SilentlyContinue
        foreach ($line in $lines) {
            $trimmed = $line.Trim()
            if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
                [void]$stateSet.Add($trimmed)
            }
        }
    }
    return $stateSet
}

function Save-StateSet {
    param(
        [Parameter(Mandatory = $true)][string]$StatePath,
        [Parameter(Mandatory = $true)][System.Collections.Generic.HashSet[string]]$StateSet
    )

    $ordered = @($StateSet | Sort-Object)
    Set-Content -LiteralPath $StatePath -Value $ordered -Encoding UTF8
}

function Test-ReleaseSync {
    param(
        [Parameter(Mandatory = $true)][string]$Tag,
        [Parameter(Mandatory = $true)][string]$RepoSlug,
        [Parameter(Mandatory = $true)][System.IO.FileInfo[]]$ExpectedFiles
    )

    $releaseJson = & gh release view $Tag --repo $RepoSlug --json assets,url
    if (-not $?) {
        throw "Failed to query release assets for $Tag"
    }

    $release = $releaseJson | ConvertFrom-Json
    $assetMap = @{}
    foreach ($asset in $release.assets) {
        $assetMap[$asset.name] = $asset
    }

    $missing = New-Object System.Collections.Generic.List[string]
    $mismatched = New-Object System.Collections.Generic.List[string]
    foreach ($file in $ExpectedFiles) {
        if (-not $assetMap.ContainsKey($file.Name)) {
            [void]$missing.Add($file.Name)
            continue
        }

        $remoteSize = [int64]$assetMap[$file.Name].size
        if ($remoteSize -ne [int64]$file.Length) {
            [void]$mismatched.Add("$($file.Name)|$($file.Length)|$remoteSize")
        }
    }

    [PSCustomObject]@{
        IsSynchronized = ($missing.Count -eq 0 -and $mismatched.Count -eq 0)
        Missing = $missing
        Mismatched = $mismatched
        ReleaseUrl = $release.url
    }
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$resolvedVersion = Resolve-Version -ExplicitVersion $Version -RepoRoot $repoRoot
$resolvedTag = if ([string]::IsNullOrWhiteSpace($ReleaseTag)) { "v$resolvedVersion" } else { $ReleaseTag.Trim() }
$resolvedRepo = Resolve-RepoSlug -ExplicitRepo $Repo
$resolvedSourceDirectory = Resolve-FullPath -PathValue $SourceDirectory -BasePath $repoRoot

$resolvedStagingRoot = if ([string]::IsNullOrWhiteSpace($StagingDirectory)) {
    Join-Path ([System.IO.Path]::GetTempPath()) 'audittoolkit-vm-release-overnight'
}
else {
    Resolve-FullPath -PathValue $StagingDirectory -BasePath $repoRoot
}

$resolvedStagingDir = Join-Path $resolvedStagingRoot $resolvedVersion
$null = New-Item -ItemType Directory -Path $resolvedStagingDir -Force
$script:LogPath = Join-Path $resolvedStagingDir 'unattended-upload.log'

Write-UploadLog -Level INFO -Message "Repo=$resolvedRepo"
Write-UploadLog -Level INFO -Message "Version=$resolvedVersion"
Write-UploadLog -Level INFO -Message "ReleaseTag=$resolvedTag"
Write-UploadLog -Level INFO -Message "SourceDirectory=$resolvedSourceDirectory"
Write-UploadLog -Level INFO -Message "StagingDirectory=$resolvedStagingDir"
Write-UploadLog -Level INFO -Message "SplitPartSizeMB=$SplitPartSizeMB"

$publishScript = Join-Path $repoRoot 'tools/publish-vm-artifacts-to-github-release.ps1'
if (-not (Test-Path -LiteralPath $publishScript)) {
    throw "Required script not found: $publishScript"
}

$lockPath = Join-Path $resolvedStagingDir '.upload.lock.json'
$statePath = Join-Path $resolvedStagingDir '.upload-state.txt'
$completeMarkerPath = Join-Path $resolvedStagingDir 'UPLOAD-COMPLETE.txt'

if (Test-Path -LiteralPath $lockPath) {
    $existingPid = $null
    try {
        $raw = Get-Content -LiteralPath $lockPath -Raw -ErrorAction Stop
        $parsed = $raw | ConvertFrom-Json
        $existingPid = [int]$parsed.pid
    }
    catch {
        $existingPid = $null
    }

    if ($existingPid) {
        $running = Get-Process -Id $existingPid -ErrorAction SilentlyContinue
        if ($running) {
            throw "Another unattended uploader appears active (pid=$existingPid). Lock file: $lockPath"
        }
    }

    Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
}

$lockInfo = [ordered]@{
    pid = $PID
    created_utc = (Get-Date).ToUniversalTime().ToString('o')
    script = $PSCommandPath
    version = $resolvedVersion
    tag = $resolvedTag
}
$lockInfo | ConvertTo-Json | Set-Content -LiteralPath $lockPath -Encoding UTF8

try {
    $stagedFiles = Get-UploadFiles -Directory $resolvedStagingDir
    if ($ForceRebuildStaging -or $stagedFiles.Count -eq 0) {
        Write-UploadLog -Level INFO -Message 'Preparing staging assets with SkipUpload mode'
        & $publishScript -Version $resolvedVersion -ReleaseTag $resolvedTag -Repo $resolvedRepo -SourceDirectory $resolvedSourceDirectory -StagingDirectory $resolvedStagingRoot -SplitPartSizeMB $SplitPartSizeMB -SkipUpload
        if (-not $?) {
            throw 'Failed preparing staging assets'
        }
    }

    Test-GitHubCliReady
    Set-ReleaseAvailable -Tag $resolvedTag -RepoSlug $resolvedRepo -VersionText $resolvedVersion -CreateIfMissing $CreateReleaseIfMissing

    $runStarted = Get-Date
    while ($true) {
        $elapsedHours = ((Get-Date) - $runStarted).TotalHours
        if ($elapsedHours -gt $MaxRuntimeHours) {
            throw "Exceeded MaxRuntimeHours=$MaxRuntimeHours before synchronization completed."
        }

        $uploadFiles = Get-UploadFiles -Directory $resolvedStagingDir
        if ($uploadFiles.Count -eq 0) {
            throw "No staged files found in: $resolvedStagingDir"
        }

        $stateSet = Get-StateSet -StatePath $statePath
        Write-UploadLog -Level INFO -Message ("LoopStart files={0} done={1}" -f $uploadFiles.Count, $stateSet.Count)

        foreach ($file in $uploadFiles) {
            if ($stateSet.Contains($file.Name)) {
                Write-UploadLog -Level INFO -Message "SKIP already_done $($file.Name)"
                continue
            }

            $uploaded = $false
            for ($attempt = 1; $attempt -le $MaxAttemptsPerFile; $attempt++) {
                Write-UploadLog -Level INFO -Message "UPLOAD start file=$($file.Name) size=$($file.Length) attempt=$attempt"

                $safeBase = ($file.BaseName -replace '[^A-Za-z0-9_.-]', '_')
                $stdout = Join-Path $resolvedStagingDir (".gh-{0}-{1}.out" -f $safeBase, $attempt)
                $stderr = Join-Path $resolvedStagingDir (".gh-{0}-{1}.err" -f $safeBase, $attempt)
                Remove-Item -LiteralPath $stdout -Force -ErrorAction SilentlyContinue
                Remove-Item -LiteralPath $stderr -Force -ErrorAction SilentlyContinue

                $process = Start-Process -FilePath 'gh' -ArgumentList @('release', 'upload', $resolvedTag, $file.FullName, '--repo', $resolvedRepo, '--clobber') -PassThru -NoNewWindow -RedirectStandardOutput $stdout -RedirectStandardError $stderr
                $startTime = Get-Date

                while (-not $process.HasExited) {
                    Start-Sleep -Seconds $HeartbeatSeconds
                    $elapsedSec = [int]((Get-Date) - $startTime).TotalSeconds
                            Write-UploadLog -Level INFO -Message "HEARTBEAT file=$($file.Name) attempt=$attempt elapsed_sec=$elapsedSec"

                    if ($elapsedSec -ge $MaxSecondsPerFile) {
                        try {
                            $process.Kill()
                        }
                        catch { Write-Verbose 'Suppressed non-fatal error.' }
                        break
                    }
                }

                $elapsedDone = [int]((Get-Date) - $startTime).TotalSeconds
                if (-not $process.HasExited) {
                    Write-UploadLog -Level WARN -Message "TIMEOUT file=$($file.Name) elapsed_sec=$elapsedDone"
                    Start-Sleep -Seconds $RetryDelaySeconds
                    continue
                }

                if ($process.ExitCode -eq 0) {
                    Write-UploadLog -Level OK -Message "SUCCESS file=$($file.Name) elapsed_sec=$elapsedDone"
                    [void]$stateSet.Add($file.Name)
                    Save-StateSet -StatePath $statePath -StateSet $stateSet
                    $uploaded = $true
                    break
                }

                $tailErr = ''
                if (Test-Path -LiteralPath $stderr) {
                    $tailErr = ((Get-Content -LiteralPath $stderr -Tail 20) -join ' | ')
                }
                Write-UploadLog -Level WARN -Message "FAIL file=$($file.Name) exit=$($process.ExitCode) elapsed_sec=$elapsedDone err_tail=$tailErr"
                Start-Sleep -Seconds $RetryDelaySeconds
            }

            if (-not $uploaded) {
                throw "Upload failed after retries for $($file.Name)"
            }
        }

        $verification = Test-ReleaseSync -Tag $resolvedTag -RepoSlug $resolvedRepo -ExpectedFiles $uploadFiles
        if ($verification.IsSynchronized) {
            $doneLine = "completed_utc=$((Get-Date).ToUniversalTime().ToString('o'));tag=$resolvedTag;repo=$resolvedRepo;release_url=$($verification.ReleaseUrl)"
            Set-Content -LiteralPath $completeMarkerPath -Value $doneLine -Encoding UTF8
            Write-UploadLog -Level OK -Message "Synchronization complete for $resolvedTag"
            Write-UploadLog -Level OK -Message "Release URL: $($verification.ReleaseUrl)"
            exit 0
        }

        foreach ($name in $verification.Missing) {
                Write-UploadLog -Level WARN -Message "VERIFY missing asset=$name"
        }

        foreach ($mismatch in $verification.Mismatched) {
            $parts = $mismatch -split '\|', 3
            $assetName = $parts[0]
            $localSize = $parts[1]
            $remoteSize = $parts[2]
                Write-UploadLog -Level WARN -Message "VERIFY size_mismatch asset=$assetName local=$localSize remote=$remoteSize"
            if ($stateSet.Remove($assetName)) {
                    Write-UploadLog -Level WARN -Message "Removed mismatched asset from checkpoint: $assetName"
            }
        }

        Save-StateSet -StatePath $statePath -StateSet $stateSet
        Write-UploadLog -Level WARN -Message "Verification incomplete; retrying in $RetryDelaySeconds seconds"
        Start-Sleep -Seconds $RetryDelaySeconds
    }
}
finally {
    if (Test-Path -LiteralPath $lockPath) {
        Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
    }
    Write-UploadLog -Level INFO -Message 'Unattended uploader exit'
}

