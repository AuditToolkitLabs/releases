<#!
.SYNOPSIS
    Starts the local web server if needed and runs the reporting backfill Playwright smoke test.

.DESCRIPTION
    This wrapper provides a single repo-native command for the reporting backfill smoke path.
    It will:
    1. Check whether the toolkit is already reachable on the requested base URL.
    2. Start `web\serve.py` with the repo virtual environment if no server is running.
    3. Run `tools\smoke-reporting-backfill-playwright.py`.
    4. Stop the temporary server process if this script started it.

    Exit behavior:
    - Returns success when the smoke script exits with code 0.
    - Throws and exits non-zero when startup fails or the smoke script returns a non-zero exit code.
    - Reuses an already-running server at the requested base URL and leaves that server running.
    - Always stops only the temporary server process started by this wrapper.

.EXAMPLE
    .\tools\run-reporting-backfill-smoke.ps1

.EXAMPLE
    .\tools\run-reporting-backfill-smoke.ps1 -Headful -ResetAdmin
#>

[CmdletBinding()]
param(
    [string]$BaseUrl = 'http://127.0.0.1:5000',
    [switch]$ResetAdmin,
    [switch]$Headful,
    [string]$Username = 'admin',
    [string]$Password = 'DemoScreenshots123!',
    [string]$SmokeScriptPath = ''
)

$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $PSScriptRoot
$pythonExe = Join-Path $repoRoot '.venv\Scripts\python.exe'
$webDir = Join-Path $repoRoot 'web'
$serveScript = Join-Path $webDir 'serve.py'
$smokeScript = if ([string]::IsNullOrWhiteSpace($SmokeScriptPath)) {
    Join-Path $PSScriptRoot 'smoke-reporting-backfill-playwright.py'
}
elseif ([System.IO.Path]::IsPathRooted($SmokeScriptPath)) {
    $SmokeScriptPath
}
else {
    Join-Path $repoRoot $SmokeScriptPath
}

if (-not (Test-Path $pythonExe)) {
    throw "Python executable not found at $pythonExe"
}

if (-not (Test-Path $serveScript)) {
    throw "Serve script not found at $serveScript"
}

if (-not (Test-Path $smokeScript)) {
    throw "Smoke script not found at $smokeScript"
}

function Test-ToolkitUrl {
    param([string]$Url)

    try {
        $response = Invoke-WebRequest -Uri $Url -TimeoutSec 3 -UseBasicParsing
        return ($response.StatusCode -ge 200 -and $response.StatusCode -lt 500)
    }
    catch {
        return $false
    }
}

$startedServer = $false
$serverProcess = $null

if (-not (Test-ToolkitUrl -Url $BaseUrl)) {
    Write-Output "Starting local web server at $BaseUrl"
    $serverProcess = Start-Process -FilePath $pythonExe `
        -ArgumentList 'serve.py' `
        -WorkingDirectory $webDir `
        -PassThru

    $startedServer = $true

    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Seconds 1
        if (Test-ToolkitUrl -Url $BaseUrl) {
            $ready = $true
            break
        }
        if ($serverProcess.HasExited) {
            break
        }
    }

    if (-not $ready) {
        if ($serverProcess -and -not $serverProcess.HasExited) {
            Stop-Process -Id $serverProcess.Id -Force
        }
        throw "Local web server did not become ready at $BaseUrl"
    }
}
else {
    Write-Output "Using existing web server at $BaseUrl"
}

try {
    $smokeArgs = @($smokeScript, '--base-url', $BaseUrl, '--username', $Username, '--password', $Password)
    if ($ResetAdmin) {
        $smokeArgs += '--reset-admin'
    }
    if ($Headful) {
        $smokeArgs += '--headful'
    }

    & $pythonExe @smokeArgs
    if ($LASTEXITCODE -ne 0) {
        throw "Smoke script exited with code $LASTEXITCODE"
    }
}
finally {
    if ($startedServer -and $serverProcess -and -not $serverProcess.HasExited) {
        Write-Output 'Stopping temporary local web server'
        Stop-Process -Id $serverProcess.Id -Force
    }
}
