<#
.SYNOPSIS
Runs ShellCheck across the repository on Windows.

.DESCRIPTION
Uses `git ls-files` if available; otherwise falls back to a recursive file search. Excludes the `.git` directory. Pass any additional arguments to `shellcheck`.

.EXAMPLE
# Basic usage (runs with -s bash -x):
.	.\tools\run-shellcheck-windows.ps1

# Forward extra args to shellcheck:
.	.\tools\run-shellcheck-windows.ps1 -- --severity=error
#>

param(
    [Parameter(ValueFromRemainingArguments=$true)]
    [string[]]$AdditionalArgs
)

$ErrorActionPreference = 'Stop'

$excludedPathPatterns = @(
    '\\.git\\',
    '\\.venv\\',
    '\\deployment\\agents\\_build\\',
    '\\deployment\\vm-appliance\\output\\',
    '\\deployment\\linux\\least-privilege\\sudoers\\.d\\'
)

function Test-IsExcludedPath {
    param([string]$Path)

    foreach ($pattern in $excludedPathPatterns) {
        if ($Path -match $pattern) {
            return $true
        }
    }

    return $false
}

function Write-ErrorAndExit {
    param($msg, $code=1)
    Write-Output $msg
    exit $code
}

$sc = Get-Command shellcheck -ErrorAction SilentlyContinue
if (-not $sc) {
    Write-ErrorAndExit "shellcheck not found on PATH. Install it (https://www.shellcheck.net) or set `shellcheck.executablePath` in VS Code settings." 2
}

# Collect shell scripts using git when possible
$filePaths = @()
$git = Get-Command git -ErrorAction SilentlyContinue
if ($git) {
    try {
        $files = & git ls-files '*.sh' 2>$null
        $filePaths = $files |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path $_) } |
            ForEach-Object { (Resolve-Path -LiteralPath $_).Path } |
            Where-Object { -not (Test-IsExcludedPath $_) }
    } catch {
        $filePaths = @()
    }
}

# Fallback: enumerate files recursively and exclude .git
if (-not $filePaths -or $filePaths.Count -eq 0) {
    $filePaths = Get-ChildItem -Path . -Recurse -File -Include *.sh |
        ForEach-Object { $_.FullName } |
        Where-Object { -not (Test-IsExcludedPath $_) }
}

if (-not $filePaths -or $filePaths.Count -eq 0) {
    Write-Output "No shell scripts found to lint."
    exit 0
}

Write-Output "Running ShellCheck on $($filePaths.Count) file(s)..."
$defaultArgs = @('-s','bash','-x','-e','SC1091')
$cmd = $defaultArgs + $AdditionalArgs + $filePaths
& $sc.Path @cmd
exit $LASTEXITCODE
