[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [string]$HostAlias = "audittoolkit-vm",
    [string]$LocalSetupScript = "deployment/vm-appliance/output/appliance-setup.sh",
    [ValidateSet("standard", "hardened")]
    [string]$BuildMode = "hardened",
    [string]$SshKeyPath = $env:AUDIT_VM_SSH_KEY_PATH,
    [SecureString]$SudoPassword,
    [string]$LocalToolkitArchivePath = "",
    [string]$LocalWheelhousePath = "",
    [switch]$SkipSystemUpgrade,
    [switch]$SkipDependencyInstall,
    [string[]]$ProtectedGoldTargets = @(
        "audittoolkit-vm",
        "192.168.100.50",
        "audittoolkit-appliance-base"
    ),
    [switch]$ForceGoldVmMutation,
    [switch]$AllowPasswordPrompt
)

$ErrorActionPreference = "Stop"

function ConvertTo-PlainText {
    param([SecureString]$SecureValue)

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

$workspaceRoot = Split-Path -Parent $PSScriptRoot
$resolvedScriptPath = Join-Path $workspaceRoot $LocalSetupScript

$fallbackScriptPath = Join-Path $workspaceRoot "deployment/vm-appliance/scripts/appliance-setup.sh"
$defaultSetupScript = "deployment/vm-appliance/output/appliance-setup.sh"

if (($LocalSetupScript -eq $defaultSetupScript) -and (Test-Path $fallbackScriptPath)) {
    $outputDir = Split-Path -Parent $resolvedScriptPath
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }

    Copy-Item -Path $fallbackScriptPath -Destination $resolvedScriptPath -Force
    Write-Output "Refreshed setup artifact from source script at $fallbackScriptPath"
} elseif ((-not (Test-Path $resolvedScriptPath)) -and (Test-Path $fallbackScriptPath)) {
    $outputDir = Split-Path -Parent $resolvedScriptPath
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }

    Copy-Item -Path $fallbackScriptPath -Destination $resolvedScriptPath -Force
    Write-Output "Setup artifact missing; copied source script from $fallbackScriptPath"
}

if (-not (Test-Path $resolvedScriptPath)) {
    throw "Setup script not found: $resolvedScriptPath"
}

function Resolve-SshHostName {
    param(
        [string]$Target
    )

    try {
        $sshConfigOutput = & ssh -G $Target 2>$null
        if ($LASTEXITCODE -ne 0) {
            return $null
        }

        foreach ($line in $sshConfigOutput) {
            if ($line -match '^\s*hostname\s+(.+)$') {
                $hostName = $Matches[1].Trim()
                if (-not [string]::IsNullOrWhiteSpace($hostName)) {
                    return $hostName
                }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    return $null
}

function Assert-GoldTargetSafety {
    param(
        [string]$TargetAlias,
        [string[]]$ProtectedTargets,
        [switch]$AllowGoldMutation
    )

    if ($AllowGoldMutation) {
        Write-Output "Gold VM protection override enabled (-ForceGoldVmMutation)."
        return
    }

    $normalizedProtectedTargets = @(
        $ProtectedTargets |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.Trim().ToLowerInvariant() }
    )

    $candidateTargets = @($TargetAlias)
    $resolvedHostName = Resolve-SshHostName -Target $TargetAlias
    if (-not [string]::IsNullOrWhiteSpace($resolvedHostName)) {
        $candidateTargets += $resolvedHostName
    }

    foreach ($candidate in $candidateTargets) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }

        $normalizedCandidate = $candidate.Trim().ToLowerInvariant()
        if ($normalizedProtectedTargets -contains $normalizedCandidate) {
            throw "Refusing to run appliance setup against protected target '$candidate'. Re-run with -ForceGoldVmMutation only when you intentionally want to mutate the gold VM."
        }
    }
}

function Resolve-SshKeyPath {
    param(
        [string]$RequestedPath
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedPath)) {
        $expandedPath = [Environment]::ExpandEnvironmentVariables($RequestedPath)
        if (-not (Test-Path $expandedPath)) {
            throw "SSH key not found: $RequestedPath"
        }

        return (Resolve-Path $expandedPath).Path
    }

    $candidatePaths = @(
        (Join-Path $HOME ".ssh\id_ed25519"),
        (Join-Path $HOME ".ssh\id_rsa"),
        (Join-Path $HOME ".ssh\id_ecdsa")
    )

    foreach ($candidatePath in $candidatePaths) {
        if (Test-Path $candidatePath) {
            return (Resolve-Path $candidatePath).Path
        }
    }

    return $null
}

$resolvedSshKeyPath = Resolve-SshKeyPath -RequestedPath $SshKeyPath
Assert-GoldTargetSafety -TargetAlias $HostAlias -ProtectedTargets $ProtectedGoldTargets -AllowGoldMutation:$ForceGoldVmMutation

Write-Output "Starting single-session VM setup on $HostAlias"
Write-Output "Build mode: $BuildMode"
if ($resolvedSshKeyPath) {
    Write-Output "SSH key: $resolvedSshKeyPath"
} elseif (-not $AllowPasswordPrompt) {
    throw "No SSH key found. Configure AUDIT_VM_SSH_KEY_PATH (or pass -SshKeyPath) for non-interactive mode."
} else {
    Write-Output "No SSH key found; SSH may prompt for password."
}

if ($SudoPassword) {
    Write-Output "Sudo password provided via parameter/environment; using non-interactive sudo auth."
}

if ($AllowPasswordPrompt) {
    Write-Output "Interactive SSH mode enabled; password prompts are allowed."
} else {
    Write-Output "Non-interactive SSH mode enabled; password prompts are disabled (fail-fast)."
}

function Get-SshOptions {
    param(
        [int]$ConnectTimeout = 15
    )

    $options = @("-o", "ConnectTimeout=$ConnectTimeout")
    if ($resolvedSshKeyPath) {
        $options += @("-o", "IdentitiesOnly=yes", "-i", $resolvedSshKeyPath)
    }

    if (-not $AllowPasswordPrompt) {
        $options += @("-o", "BatchMode=yes", "-o", "NumberOfPasswordPrompts=0")
    }

    return $options
}

if (-not $AllowPasswordPrompt) {
    & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "echo '[preflight] ssh-auth-ok'" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "SSH preflight failed in non-interactive mode. Configure key-based auth for '$HostAlias' or rerun with -AllowPasswordPrompt."
    }
}

$hardenedModeFlag = if ($BuildMode -eq "hardened") { "true" } else { "false" }
$skipSystemUpgradeFlag = if ($SkipSystemUpgrade) { "true" } else { "false" }
$skipDependencyInstallFlag = if ($SkipDependencyInstall) { "true" } else { "false" }
$plainSudoPassword = if ($SudoPassword) { ConvertTo-PlainText -SecureValue $SudoPassword } else { "" }
$encodedSudoPassword = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($plainSudoPassword))
$allowSudoPromptFlag = if ($AllowPasswordPrompt) { "1" } else { "0" }

Write-Output "Uploading setup script to $HostAlias..."
& scp @(Get-SshOptions -ConnectTimeout 15) $resolvedScriptPath "${HostAlias}:~/appliance-setup.sh"
if ($LASTEXITCODE -ne 0) {
        throw "Failed to upload setup script to '$HostAlias'"
}

$remoteToolkitArchivePath = ""
if (-not [string]::IsNullOrWhiteSpace($LocalToolkitArchivePath)) {
    $expandedArchivePath = [Environment]::ExpandEnvironmentVariables($LocalToolkitArchivePath)
    if (-not (Test-Path $expandedArchivePath)) {
        throw "Local toolkit archive not found: $LocalToolkitArchivePath"
    }

    $resolvedArchivePath = (Resolve-Path $expandedArchivePath).Path
    $remoteToolkitArchivePath = "/tmp/audit-toolkit-local.tar.gz"

    Write-Output "Uploading local toolkit archive to $HostAlias..."
    & scp @(Get-SshOptions -ConnectTimeout 15) $resolvedArchivePath "${HostAlias}:${remoteToolkitArchivePath}"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to upload local toolkit archive to '$HostAlias'"
    }
}

$remoteWheelhousePath = ""
if (-not [string]::IsNullOrWhiteSpace($LocalWheelhousePath)) {
    $expandedWheelhousePath = [Environment]::ExpandEnvironmentVariables($LocalWheelhousePath)
    if (-not (Test-Path $expandedWheelhousePath)) {
        throw "Local wheelhouse path not found: $LocalWheelhousePath"
    }

    $resolvedWheelhousePath = (Resolve-Path $expandedWheelhousePath).Path
    $wheelhouseLeaf = Split-Path $resolvedWheelhousePath -Leaf
    $remoteWheelhousePath = "/tmp/$wheelhouseLeaf"

    Write-Output "Uploading local Python wheelhouse to $HostAlias..."
    & ssh @(Get-SshOptions -ConnectTimeout 15) $HostAlias "rm -rf '$remoteWheelhousePath'"
    & scp "-r" @(Get-SshOptions -ConnectTimeout 30) $resolvedWheelhousePath "${HostAlias}:/tmp/"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to upload local Python wheelhouse to '$HostAlias'"
    }
}

$remoteCommand = @'
set -euo pipefail
chmod +x ~/appliance-setup.sh
SUDO_PW="$(printf '%s' '__SUDO_PW_B64__' | base64 -d 2>/dev/null || true)"
LOCAL_TOOLKIT_ARCHIVE_PATH="__LOCAL_TOOLKIT_ARCHIVE_PATH__"
LOCAL_WHEELHOUSE_DIR_PATH="__LOCAL_WHEELHOUSE_PATH__"
sudo_cmd() {
    if [ -n "$SUDO_PW" ]; then
        printf '%s\n' "$SUDO_PW" | sudo -S -p '' "$@"
    elif [ "__ALLOW_SUDO_PROMPT__" = "1" ]; then
        sudo "$@"
    else
        sudo -n "$@"
    fi
}
echo "[step] requesting sudo credentials"
if ! sudo_cmd -v; then
    echo "[error] sudo authentication failed"
    echo "[hint] rerun with -AllowPasswordPrompt or configure passwordless sudo"
    exit 86
fi
echo "[step] running appliance setup"
if [ -n "$LOCAL_TOOLKIT_ARCHIVE_PATH" ]; then
    sudo_cmd env \
        APPLIANCE_BUILD_MODE="__BUILD_MODE__" \
        APPLIANCE_HARDENED_MODE="__HARDENED_FLAG__" \
        APPLIANCE_SKIP_SYSTEM_UPGRADE="__SKIP_SYSTEM_UPGRADE__" \
        APPLIANCE_SKIP_DEPENDENCY_INSTALL="__SKIP_DEPENDENCY_INSTALL__" \
        LOCAL_WHEELHOUSE_DIR="$LOCAL_WHEELHOUSE_DIR_PATH" \
        LOCAL_TOOLKIT_ARCHIVE="$LOCAL_TOOLKIT_ARCHIVE_PATH" \
        bash ~/appliance-setup.sh 2>&1 | tee ~/appliance-setup.log
else
    sudo_cmd env \
        APPLIANCE_BUILD_MODE="__BUILD_MODE__" \
        APPLIANCE_HARDENED_MODE="__HARDENED_FLAG__" \
        APPLIANCE_SKIP_SYSTEM_UPGRADE="__SKIP_SYSTEM_UPGRADE__" \
        APPLIANCE_SKIP_DEPENDENCY_INSTALL="__SKIP_DEPENDENCY_INSTALL__" \
        LOCAL_WHEELHOUSE_DIR="$LOCAL_WHEELHOUSE_DIR_PATH" \
        bash ~/appliance-setup.sh 2>&1 | tee ~/appliance-setup.log
fi
echo "[step] service health"
systemctl status audit-toolkit audit-toolkit-celery nginx --no-pager || true
'@

$remoteCommand = $remoteCommand.Replace("__BUILD_MODE__", $BuildMode)
$remoteCommand = $remoteCommand.Replace("__HARDENED_FLAG__", $hardenedModeFlag)
$remoteCommand = $remoteCommand.Replace("__SKIP_SYSTEM_UPGRADE__", $skipSystemUpgradeFlag)
$remoteCommand = $remoteCommand.Replace("__SKIP_DEPENDENCY_INSTALL__", $skipDependencyInstallFlag)
$remoteCommand = $remoteCommand.Replace("__SUDO_PW_B64__", $encodedSudoPassword)
$remoteCommand = $remoteCommand.Replace("__ALLOW_SUDO_PROMPT__", $allowSudoPromptFlag)
$remoteCommand = $remoteCommand.Replace("__LOCAL_TOOLKIT_ARCHIVE_PATH__", $remoteToolkitArchivePath)
$remoteCommand = $remoteCommand.Replace("__LOCAL_WHEELHOUSE_PATH__", $remoteWheelhousePath)
$remoteCommand = $remoteCommand -replace "`r`n", "`n"
$remoteCommand = $remoteCommand -replace "`r", ""

$localWrapperPath = [System.IO.Path]::GetTempFileName()
$remoteWrapperPath = "~/run-appliance-setup-wrapper.sh"
$setupExitCode = 1

try {
    [System.IO.File]::WriteAllText($localWrapperPath, $remoteCommand, [System.Text.UTF8Encoding]::new($false))

    & scp @(Get-SshOptions -ConnectTimeout 15) $localWrapperPath "${HostAlias}:${remoteWrapperPath}"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to upload remote setup wrapper to '$HostAlias'"
    }

    & ssh -tt @(Get-SshOptions -ConnectTimeout 15) $HostAlias "chmod +x ${remoteWrapperPath} && bash ${remoteWrapperPath}"
    $setupExitCode = $LASTEXITCODE
}
finally {
    Remove-Item -Path $localWrapperPath -Force -ErrorAction SilentlyContinue
}

if ($setupExitCode -eq 255) {
    Write-Output "SSH session disconnected (exit 255). Attempting reconnect-aware completion checks..."

    $reconnected = $false
    for ($attempt = 1; $attempt -le 18; $attempt++) {
        Start-Sleep -Seconds 5
        Write-Output ("Reconnect attempt {0}/18..." -f $attempt)
        $probeExitCode = 255
        try {
            & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "echo '[probe] ssh-ready'" | Out-Null
            $probeExitCode = $LASTEXITCODE
        } catch {
            if ($LASTEXITCODE -ne 0) {
                $probeExitCode = $LASTEXITCODE
            }
        }

        if ($probeExitCode -eq 0) {
            $reconnected = $true
            break
        }
    }

    if (-not $reconnected) {
        throw "Single-session setup ended with SSH disconnect (255) and host did not reconnect in time."
    }

    Write-Output "SSH reconnected. Polling service health and setup markers to confirm completion..."
    $healthy = $false
    $completedWithTransitions = $false
    $lastSnapshot = ""
    $transitionalStableCount = 0
    $snapshotCommand = @'
app_state=$(systemctl is-active audit-toolkit 2>/dev/null || true); celery_state=$(systemctl is-active audit-toolkit-celery 2>/dev/null || true); nginx_state=$(systemctl is-active nginx 2>/dev/null || true); log_done=no; if [ -f ~/appliance-setup.log ] && grep -q "Installation Complete!" ~/appliance-setup.log; then log_done=yes; fi; printf "APP=%s CELERY=%s NGINX=%s LOG_DONE=%s\n" "$app_state" "$celery_state" "$nginx_state" "$log_done"
'@

    for ($attempt = 1; $attempt -le 60; $attempt++) {
        $snapshotOutput = $null
        $snapshotExitCode = 255
        try {
            $snapshotOutput = & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias $snapshotCommand
            $snapshotExitCode = $LASTEXITCODE
        } catch {
            if ($LASTEXITCODE -ne 0) {
                $snapshotExitCode = $LASTEXITCODE
            }
        }

        if ($snapshotExitCode -ne 0) {
            Start-Sleep -Seconds 5
            continue
        }

        $lastSnapshot = (($snapshotOutput | Select-Object -Last 1) ?? "").Trim()
        if ($lastSnapshot -match 'APP=(\S+)\s+CELERY=(\S+)\s+NGINX=(\S+)\s+LOG_DONE=(\S+)') {
            $appState = $Matches[1]
            $celeryState = $Matches[2]
            $nginxState = $Matches[3]
            $logDone = $Matches[4]

            if (($logDone -eq "yes") -and ($appState -eq "active") -and ($celeryState -eq "active") -and ($nginxState -eq "active")) {
                $healthy = $true
                break
            }

            $noFailedServices = ($appState -ne "failed") -and ($celeryState -ne "failed") -and ($nginxState -ne "failed")
            $appSettling = @("active", "activating") -contains $appState
            $celerySettling = @("active", "activating") -contains $celeryState

            if (($logDone -eq "yes") -and ($nginxState -eq "active") -and $noFailedServices -and $appSettling -and $celerySettling) {
                $transitionalStableCount++
                if ($transitionalStableCount -ge 3) {
                    $completedWithTransitions = $true
                    break
                }
            } else {
                $transitionalStableCount = 0
            }

            if (($attempt % 6) -eq 0) {
                Write-Output ("Health poll {0}/60: {1}" -f $attempt, $lastSnapshot)
            }
        }

        Start-Sleep -Seconds 5
    }

    if (-not $healthy -and -not $completedWithTransitions) {
        Write-Output "Services did not reach a stable healthy state after reconnect; showing diagnostics..."
        try {
            & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "systemctl is-active audit-toolkit audit-toolkit-celery nginx apparmor || true"
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        try {
            & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "tail -n 120 ~/appliance-setup.log || true"
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
        throw "Single-session setup ended with SSH disconnect (255) and services did not become healthy in time. Last snapshot: $lastSnapshot"
    }

    if ($healthy) {
        Write-Output "Recovered from SSH disconnect; setup completed and services are healthy."
    } else {
        Write-Output "Recovered from SSH disconnect; setup completed and core services are still settling. Last snapshot: $lastSnapshot"
    }
} elseif ($setupExitCode -ne 0) {
    throw "Single-session setup failed with exit code $setupExitCode"
}

Write-Output "Single-session setup completed successfully."
