[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [string]$VmHost = "audittoolkit-vm",
    [string]$LocalScriptPath = "tools/vm-force-postgres-runtime.sh",
    [string]$RemoteScriptPath = '$HOME/vm-force-postgres-runtime.sh',
    [string]$SshKeyPath = $env:AUDIT_VM_SSH_KEY_PATH,
    [switch]$BatchMode
)

$ErrorActionPreference = "Stop"

function Get-SshOptions {
    param(
        [string]$KeyPath,
        [switch]$UseBatchMode
    )

    $options = @('-o', 'ConnectTimeout=15')

    if (-not [string]::IsNullOrWhiteSpace($KeyPath)) {
        if (-not (Test-Path $KeyPath)) {
            throw "SSH key not found: $KeyPath"
        }
        $options += @('-i', $KeyPath)
    }

    if ($UseBatchMode) {
        $options += @('-o', 'BatchMode=yes')
    }

    return $options
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$resolvedLocalScriptPath = if ([System.IO.Path]::IsPathRooted($LocalScriptPath)) {
    $LocalScriptPath
} else {
    Join-Path $repoRoot $LocalScriptPath
}

if (-not (Test-Path $resolvedLocalScriptPath)) {
    throw "Local runtime fix script not found: $resolvedLocalScriptPath"
}

$sshOptions = Get-SshOptions -KeyPath $SshKeyPath -UseBatchMode:$BatchMode

Write-Output "[vm] Running PostgreSQL runtime fix"
Write-Output "[vm] Host: $VmHost"
Write-Output "[vm] Local script: $resolvedLocalScriptPath"
Write-Output "[vm] Remote script: $RemoteScriptPath"
if (-not [string]::IsNullOrWhiteSpace($SshKeyPath)) {
    Write-Output "[vm] SSH key: $SshKeyPath"
}

$scriptContent = Get-Content -Raw -Path $resolvedLocalScriptPath
$scriptContent = $scriptContent -replace "`r`n", "`n"
$scriptContent = $scriptContent -replace "`r", "`n"
$encodedScript = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($scriptContent))
$uploadLine = "printf '%s' '$encodedScript' | base64 -d > " + '$target_path'

$remoteLines = @(
    'set -euo pipefail',
    "target_path=$RemoteScriptPath",
    $uploadLine,
    'chmod +x $target_path',
    'echo "[step] requesting sudo credentials"',
    'sudo -v',
    'echo "[step] running runtime fix script"',
    'sed ''1s/^\xEF\xBB\xBF//'' $target_path | tr -d ''\r'' | sudo bash'
)

$remoteScript = (($remoteLines -join "`n") -replace "`r", "") + "`n"
$remoteScript | & ssh @sshOptions -tt $VmHost "bash -s"

if ($LASTEXITCODE -ne 0) {
    throw "VM runtime fix failed with exit code $LASTEXITCODE"
}

Write-Output "[vm] PostgreSQL runtime fix completed successfully."
