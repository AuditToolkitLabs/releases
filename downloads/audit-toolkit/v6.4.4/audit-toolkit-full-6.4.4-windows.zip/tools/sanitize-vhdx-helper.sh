#!/bin/bash
# Applies all offline sanitization steps to a mounted appliance filesystem.
# Called by tools/offline-sanitize-vhdx.ps1 via:
#   wsl -u root -e bash -c "sed 's/\r//' helper.sh | MOUNT_TARGET=/mnt/offlineaudit bash"
#
# Env vars:
#   MOUNT_TARGET  - Path where the root filesystem is mounted (default: /mnt/offlineaudit)

set -euo pipefail
M="${MOUNT_TARGET:-/mnt/offlineaudit}"

# ── Verify mount ──────────────────────────────────────────────────────────────
if ! mountpoint -q "$M"; then
    echo "ERROR: $M is not mounted"
    exit 1
fi

# ── Hostname ──────────────────────────────────────────────────────────────────
echo "audit-toolkit" > "$M/etc/hostname"
sed -i 's/^127\.0\.1\.1.*/127.0.1.1\taudit-toolkit/' "$M/etc/hosts" 2>/dev/null || true
echo "[OK] hostname"

# ── Clear first-boot markers ──────────────────────────────────────────────────
rm -f "$M/var/lib/audit-toolkit/.setup-complete" \
      "$M/var/lib/audit-toolkit/.first-boot-complete" \
      "$M/var/lib/audit-toolkit/.first-login-wizard-complete" \
      "$M/var/lib/audit-toolkit/initial-admin-credentials.txt" 2>/dev/null || true
mkdir -p "$M/var/lib/audit-toolkit"
echo "[OK] markers cleared"

# ── DHCP netplan ──────────────────────────────────────────────────────────────
find "$M/etc/netplan" -type f -name '*.yaml' -delete 2>/dev/null || true
mkdir -p "$M/etc/netplan"
cat > "$M/etc/netplan/90-audit-toolkit.yaml" << 'NETEOF'
network:
    version: 2
    ethernets:
        eth0:
            dhcp4: true
NETEOF
chmod 600 "$M/etc/netplan/90-audit-toolkit.yaml"
echo "[OK] netplan DHCP"

# ── Remove lab TLS material so customer first boot gets a fresh cert ─────────
mkdir -p "$M/etc/nginx/ssl/audit-toolkit"
rm -f "$M/etc/nginx/ssl/audit-toolkit.crt" \
      "$M/etc/nginx/ssl/audit-toolkit.key" \
      "$M/etc/nginx/ssl/audit-toolkit-chain.crt" \
      "$M/etc/nginx/ssl/audit-toolkit/audit-toolkit.crt" \
      "$M/etc/nginx/ssl/audit-toolkit/audit-toolkit.key" \
      "$M/etc/nginx/ssl/audit-toolkit/audit-toolkit-chain.crt" 2>/dev/null || true
echo "[OK] TLS material cleared"

# ── First-login wizard ────────────────────────────────────────────────────────
cat > "$M/usr/local/bin/audit-toolkit-setup" << 'WIZEOF'
#!/bin/bash
set -euo pipefail

clear
echo "=========================================="
echo "Security Audit Toolkit - First Boot Setup"
echo "=========================================="
echo ""

if ! command -v sudo >/dev/null 2>&1; then
    echo "sudo is required but not installed."
    exit 1
fi

echo "Authenticate to apply system settings..."
if ! sudo -v; then
    echo "Sudo authentication failed."
    exit 1
fi

FIRST_LOGIN_MARKER="/var/lib/audit-toolkit/.first-login-wizard-complete"
if sudo test -f "${FIRST_LOGIN_MARKER}"; then
    echo "First-boot wizard already completed."
    exit 0
fi

detect_primary_iface() {
    local iface
    iface=$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')
    if [[ -z "${iface}" ]]; then
        iface=$(ip -o link show | awk -F': ' '$2 != "lo" {print $2; exit}')
    fi
    echo "${iface:-eth0}"
}

prompt_required() {
    local prompt_text="$1"
    local user_value=""
    while true; do
        read -r -p "${prompt_text}: " user_value
        if [[ -n "${user_value}" ]]; then
            echo "${user_value}"
            return 0
        fi
        echo "A value is required."
    done
}

PRIMARY_IFACE=$(detect_primary_iface)

read -r -p "Enter hostname [audit-toolkit]: " NEW_HOSTNAME
NEW_HOSTNAME=${NEW_HOSTNAME:-audit-toolkit}
sudo hostnamectl set-hostname "${NEW_HOSTNAME}"

echo ""
echo "Configure network for interface: ${PRIMARY_IFACE}"
echo "No lab network defaults are pre-populated for customer deployment."
read -r -p "Use DHCP? (Y/n): " USE_DHCP

if [[ ! "${USE_DHCP}" =~ ^[Nn]$ ]]; then
    sudo tee /etc/netplan/90-audit-toolkit.yaml >/dev/null << NETEOF
network:
    version: 2
    ethernets:
        ${PRIMARY_IFACE}:
            dhcp4: true
NETEOF
else
    STATIC_CIDR=$(prompt_required "Static IP CIDR (example: 192.0.2.10/24)")
    GATEWAY=$(prompt_required "Gateway (example: 192.0.2.1)")
    DNS_SERVER=$(prompt_required "DNS server (example: 192.0.2.53)")
    EXPECTED_IP="${STATIC_CIDR%%/*}"
    sudo tee /etc/netplan/90-audit-toolkit.yaml >/dev/null << NETEOF
network:
    version: 2
    ethernets:
        ${PRIMARY_IFACE}:
            dhcp4: false
            addresses:
                - ${STATIC_CIDR}
            routes:
                - to: default
                  via: ${GATEWAY}
            nameservers:
                addresses:
                    - ${DNS_SERVER}
NETEOF
fi

sudo sed -i '/gateway4:/d' /etc/netplan/*.yaml 2>/dev/null || true
sudo netplan generate
sudo netplan apply
sudo ip link set "${PRIMARY_IFACE}" up || true
ACTIVE_IP=$(hostname -I | awk '{print $1}')

if [[ -n "${EXPECTED_IP:-}" && "${ACTIVE_IP:-}" != "${EXPECTED_IP}" ]]; then
    echo ""
    echo "ERROR: static IP was not applied as expected."
    echo "Expected: ${EXPECTED_IP}"
    echo "Detected: ${ACTIVE_IP:-not-detected}"
    echo "Interface: ${PRIMARY_IFACE}"
    ip -4 addr show dev "${PRIMARY_IFACE}" || true
    exit 1
fi

TLS_HOSTNAME=$(hostname -f 2>/dev/null || hostname)
TLS_SAN="DNS:${TLS_HOSTNAME},DNS:localhost,IP:127.0.0.1"
if [[ -n "${ACTIVE_IP:-}" ]]; then
    TLS_SAN="${TLS_SAN},IP:${ACTIVE_IP}"
fi

sudo install -d -m 755 /etc/nginx/ssl/audit-toolkit
sudo rm -f /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
           /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
           /etc/nginx/ssl/audit-toolkit.crt \
           /etc/nginx/ssl/audit-toolkit.key
if ! sudo openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
    -keyout /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
    -out /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
    -subj "/CN=${TLS_HOSTNAME}/O=Audit Toolkit/C=US" \
    -addext "subjectAltName=${TLS_SAN}" >/dev/null 2>&1; then
    sudo openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
        -keyout /etc/nginx/ssl/audit-toolkit/audit-toolkit.key \
        -out /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt \
        -subj "/CN=${TLS_HOSTNAME}/O=Audit Toolkit/C=US" >/dev/null 2>&1
fi
sudo chmod 600 /etc/nginx/ssl/audit-toolkit/audit-toolkit.key
sudo chmod 644 /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt
sudo ln -sf /etc/nginx/ssl/audit-toolkit/audit-toolkit.crt /etc/nginx/ssl/audit-toolkit.crt
sudo ln -sf /etc/nginx/ssl/audit-toolkit/audit-toolkit.key /etc/nginx/ssl/audit-toolkit.key

echo ""
echo "Set new password for 'auditadmin' user:"
sudo passwd auditadmin

echo ""
read -r -p "Configure SSL with Let's Encrypt? (y/N): " SSL_CHOICE
if [[ "${SSL_CHOICE}" =~ ^[Yy]$ ]]; then
    read -r -p "Enter domain name: " DOMAIN
    sudo certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos \
        --email "admin@${DOMAIN}" 2>/dev/null || echo "SSL setup failed - configure manually"
fi

sudo nginx -t >/dev/null 2>&1 && sudo systemctl restart nginx || true
ACTIVE_IP=$(hostname -I | awk '{print $1}')

sudo mkdir -p /var/lib/audit-toolkit
sudo touch "${FIRST_LOGIN_MARKER}"
echo ""
echo "First-boot wizard marked complete."
echo "To re-run later: sudo rm -f ${FIRST_LOGIN_MARKER}"
echo ""
echo "Waiting for application services to start (may take 30-60 seconds after a reboot)..."
_svc_ready=0
for _tick in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
    if sudo systemctl is-active --quiet audit-toolkit 2>/dev/null; then
        _svc_ready=1
        break
    fi
    sleep 2
    printf "."
done
echo ""
if [ "${_svc_ready}" = "1" ]; then
    echo "Services are running."
else
    echo "Note: Services are still starting up."
    echo "Please allow 30-60 seconds before accessing the URL below."
fi
echo ""
echo "Access the toolkit at: https://${ACTIVE_IP:-localhost}"
WIZEOF
chmod 755 "$M/usr/local/bin/audit-toolkit-setup"
echo "[OK] wizard written ($(wc -l < "$M/usr/local/bin/audit-toolkit-setup") lines)"

# ── Profile hook ──────────────────────────────────────────────────────────────
cat > "$M/etc/profile.d/first-boot.sh" << 'HOOKEOF'
if [ -f /usr/local/bin/audit-toolkit-setup ] && \
   [ "${USER:-}" = "auditadmin" ] && \
   [ ! -f /var/lib/audit-toolkit/.first-login-wizard-complete ] && \
   [ -t 0 ] && [ -t 1 ]; then
    exec /usr/local/bin/audit-toolkit-setup
fi
HOOKEOF
chmod 644 "$M/etc/profile.d/first-boot.sh"

cat > "$M/etc/profile.d/first-boot-hint.sh" << 'HINTEOF'
if [ "${USER:-}" = "auditadmin" ] && \
   [ ! -f /var/lib/audit-toolkit/.first-login-wizard-complete ] && \
   [ -t 1 ]; then
    echo "[Audit Toolkit] First-boot setup pending. Re-login to start the wizard."
fi
HINTEOF
chmod 644 "$M/etc/profile.d/first-boot-hint.sh"
echo "[OK] profile hooks written"

# ── Scrub lab IPs from env files ──────────────────────────────────────────────
for envf in \
    "$M/opt/audit-toolkit/.env" \
    "$M/opt/audit-toolkit/tools/asset-discovery/.env"; do
    if [ -f "$envf" ]; then
        # Replace http(s)://192.168.x.x/... with placeholder
        sed -i -E 's|https?://192[.]168[.][0-9]{1,3}[.][0-9]{1,3}(/[^[:space:]]*)?|http://127.0.0.1|g' "$envf"
        # Replace bare 192.168.x.x
        sed -i -E 's|192[.]168[.][0-9]{1,3}[.][0-9]{1,3}|127.0.0.1|g' "$envf"
        echo "[OK] scrubbed: $envf"
    fi
done

# ── Cloud-init clear ──────────────────────────────────────────────────────────
rm -rf "$M/var/lib/cloud" 2>/dev/null || true
echo "[OK] cloud-init cleared"

# ── Verification ──────────────────────────────────────────────────────────────
echo ""
echo "=== VERIFICATION ==="
ERRORS=0

echo "hostname: $(cat "$M/etc/hostname")"

ls -la "$M/etc/profile.d/first-boot.sh" || { echo "FAIL: first-boot hook missing"; ERRORS=$((ERRORS+1)); }
ls -la "$M/usr/local/bin/audit-toolkit-setup" || { echo "FAIL: wizard missing"; ERRORS=$((ERRORS+1)); }

grep -q 'Use DHCP?' "$M/usr/local/bin/audit-toolkit-setup" \
    && echo "OK: wizard has DHCP prompt" \
    || { echo "FAIL: DHCP prompt missing"; ERRORS=$((ERRORS+1)); }

grep -q 'first-login-wizard-complete' "$M/usr/local/bin/audit-toolkit-setup" \
    && echo "OK: wizard has marker logic" \
    || { echo "FAIL: marker logic missing"; ERRORS=$((ERRORS+1)); }

grep -q 'audit-toolkit-setup' "$M/etc/profile.d/first-boot.sh" \
    && echo "OK: hook launches wizard" \
    || { echo "FAIL: hook does not launch wizard"; ERRORS=$((ERRORS+1)); }

echo "netplan:"
cat "$M/etc/netplan/90-audit-toolkit.yaml"
grep -q '192\.168\.' "$M/etc/netplan/90-audit-toolkit.yaml" \
    && { echo "FAIL: lab IP in netplan"; ERRORS=$((ERRORS+1)); } \
    || echo "OK: netplan clean"

echo ""
echo "--- Lab IP scan ---"
for fp in \
    "$M/opt/audit-toolkit/.env" \
    "$M/opt/audit-toolkit/tools/asset-discovery/.env" \
    "$M/usr/local/bin/audit-toolkit-setup" \
    "$M/etc/profile.d/first-boot.sh" \
    "$M/etc/netplan/90-audit-toolkit.yaml"; do
    if [ -f "$fp" ] && grep -qE '192\.168\.' "$fp"; then
        echo "FAIL: lab IP in ${fp#$M}"
        ERRORS=$((ERRORS+1))
    else
        echo "OK: ${fp#$M}"
    fi
done

echo ""
echo "Total errors: $ERRORS"
exit "$ERRORS"
