#!/usr/bin/env python3
"""Send customer delivery email for a fulfilled Keygen license artifact."""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from email.message import EmailMessage
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from mail_delivery import (
    MailDeliveryConfig,
    load_mail_delivery_config,
    resolve_mail_delivery_provider,
    send_email_message,
)


DEFAULT_PRODUCT_NAME = "Security Audit Toolkit"


@dataclass(frozen=True)
class FulfillmentData:
    customer_email: str
    order_ref: str
    tier: str
    license_key: str
    license_id: str | None
    expires_at: str | None
    machines_limit: int | None


def _parse_bool(raw_value: str | None, default: bool) -> bool:
    if raw_value is None or raw_value == "":
        return default

    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False

    raise ValueError(f"Invalid boolean value '{raw_value}'")


def _parse_positive_int(name: str, value: str | None, default: int) -> int:
    if value is None or value == "":
        return default

    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc

    if parsed < 1:
        raise ValueError(f"{name} must be at least 1")

    return parsed


def _read_artifact(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ValueError(f"Artifact file not found: {path}")

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Artifact is not valid JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError("Artifact JSON must be an object")

    return payload


def _extract_fulfillment_data(payload: dict[str, Any]) -> FulfillmentData:
    request = payload.get("request")
    license_obj = payload.get("license")

    if not isinstance(request, dict):
        raise ValueError("Artifact is missing request object")
    if not isinstance(license_obj, dict):
        raise ValueError("Artifact is missing license object")

    customer_email = str(request.get("customer_email", "")).strip()
    order_ref = str(request.get("order_ref", "")).strip()
    tier = str(request.get("tier") or license_obj.get("tier") or "").strip()
    license_key = str(license_obj.get("key", "")).strip()
    license_id = str(license_obj.get("id", "")).strip() or None
    expires_at = str(license_obj.get("expires_at", "")).strip() or None

    machines_limit_raw = license_obj.get("machines_limit")
    machines_limit: int | None
    if machines_limit_raw is None or machines_limit_raw == "":
        machines_limit = None
    else:
        try:
            machines_limit = int(machines_limit_raw)
        except (TypeError, ValueError) as exc:
            raise ValueError("Artifact license.machines_limit must be an integer") from exc

    if not customer_email:
        raise ValueError("Artifact request.customer_email is missing")
    if not order_ref:
        raise ValueError("Artifact request.order_ref is missing")
    if not tier:
        raise ValueError("Artifact tier is missing")
    if not license_key:
        raise ValueError("Artifact license.key is missing")

    return FulfillmentData(
        customer_email=customer_email,
        order_ref=order_ref,
        tier=tier,
        license_key=license_key,
        license_id=license_id,
        expires_at=expires_at,
        machines_limit=machines_limit,
    )


def _build_mail_delivery_config(args: argparse.Namespace) -> MailDeliveryConfig:
    env = dict(os.environ)

    if args.mail_provider:
        env["MAIL_DELIVERY_PROVIDER"] = args.mail_provider
    if args.smtp_host:
        env["SMTP_HOST"] = args.smtp_host
    if args.smtp_port:
        env["SMTP_PORT"] = args.smtp_port
    if args.smtp_user:
        env["SMTP_USER"] = args.smtp_user
    if args.smtp_from:
        env["SMTP_FROM"] = args.smtp_from
    if args.smtp_use_tls:
        env["SMTP_USE_TLS"] = args.smtp_use_tls

    return load_mail_delivery_config(env)


def _build_subject(
    fulfillment: FulfillmentData,
    product_name: str,
    subject_prefix: str,
) -> str:
    prefix = (subject_prefix or "").strip()
    if prefix:
        prefix = f"{prefix} "

    normalized_tier = fulfillment.tier.strip().capitalize()
    return f"{prefix}{product_name} {normalized_tier} license key ({fulfillment.order_ref})"


def _build_body(
    fulfillment: FulfillmentData,
    product_name: str,
    support_email: str | None,
    activation_url: str | None,
) -> str:
    expiry = fulfillment.expires_at or "No fixed expiry"
    machines_limit = str(fulfillment.machines_limit) if fulfillment.machines_limit is not None else "As configured"

    lines = [
        "Hello,",
        "",
        f"Thank you for choosing {product_name}.",
        "Your license has been issued.",
        "",
        "License details:",
        f"- License key: {fulfillment.license_key}",
        f"- Tier: {fulfillment.tier}",
        f"- Machines limit: {machines_limit}",
        f"- Expires at: {expiry}",
        f"- Order reference: {fulfillment.order_ref}",
    ]

    if fulfillment.license_id:
        lines.append(f"- License ID: {fulfillment.license_id}")

    lines.extend(
        [
            "",
            "Activation:",
            "1) Open the Security Audit Toolkit admin interface.",
            "2) Navigate to the License page.",
            "3) Paste the license key and activate.",
        ]
    )

    if activation_url:
        lines.append(f"Activation guide: {activation_url}")

    lines.extend([
        "",
        "Support scope:",
        "- Your purchase covers software usage rights for the selected license tier.",
        "- Included support is limited to basic, best-effort email help for activation and product usage.",
        "- Consulting, custom development, managed services, and scheduled calls are not included.",
    ])

    if support_email:
        lines.extend([
            "",
            f"Need help? Reply to this message or contact {support_email}.",
        ])

    lines.extend([
        "",
        "Please keep this license key private.",
        "",
        "Regards,",
        f"{product_name} Support",
    ])

    return "\n".join(lines)


def _build_email_message(
    delivery_config: MailDeliveryConfig,
    recipient: str,
    subject: str,
    body: str,
    reply_to: str | None,
) -> EmailMessage:
    message = EmailMessage()
    message["Subject"] = subject
    provider = resolve_mail_delivery_provider(delivery_config)
    if provider == "graph" and delivery_config.graph is not None:
        from_address = delivery_config.graph.from_address or delivery_config.graph.sender_user
    elif delivery_config.smtp is not None:
        from_address = delivery_config.smtp.from_address
    else:
        raise ValueError("No mail delivery provider resolved")

    message["From"] = from_address
    message["To"] = recipient
    if reply_to:
        message["Reply-To"] = reply_to
    message.set_content(body)
    return message


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Send customer license email from a fulfillment artifact",
    )
    parser.add_argument(
        "--artifact",
        required=True,
        help="Path to license fulfillment JSON artifact",
    )
    parser.add_argument(
        "--product-name",
        default=DEFAULT_PRODUCT_NAME,
        help=f"Product name used in subject/body (default: {DEFAULT_PRODUCT_NAME})",
    )
    parser.add_argument(
        "--subject-prefix",
        default="",
        help="Optional subject prefix (for example: [BETA])",
    )
    parser.add_argument(
        "--support-email",
        default="",
        help="Support mailbox for reply-to and body (defaults to SUPPORT_EMAIL env)",
    )
    parser.add_argument(
        "--activation-url",
        default="",
        help="Optional activation/help URL included in email body",
    )
    parser.add_argument(
        "--smtp-host",
        default="",
        help="SMTP host (defaults to SMTP_HOST env)",
    )
    parser.add_argument(
        "--smtp-port",
        default="",
        help="SMTP port (defaults to SMTP_PORT env or 587)",
    )
    parser.add_argument(
        "--smtp-user",
        default="",
        help="SMTP username (defaults to SMTP_USER env)",
    )
    parser.add_argument(
        "--smtp-from",
        default="",
        help="SMTP From address (defaults to SMTP_FROM env)",
    )
    parser.add_argument(
        "--smtp-use-tls",
        default="",
        help="Enable STARTTLS: true/false (defaults to SMTP_USE_TLS env or true)",
    )
    parser.add_argument(
        "--mail-provider",
        default="",
        help="Mail transport to use: auto, smtp, or graph (defaults to MAIL_DELIVERY_PROVIDER env)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Build and validate message without sending",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        artifact_path = Path(args.artifact).resolve()
        payload = _read_artifact(artifact_path)
        fulfillment = _extract_fulfillment_data(payload)

        support_email = (args.support_email or os.environ.get("SUPPORT_EMAIL", "")).strip() or None
        activation_url = (args.activation_url or "").strip() or None

        subject = _build_subject(
            fulfillment=fulfillment,
            product_name=args.product_name.strip() or DEFAULT_PRODUCT_NAME,
            subject_prefix=args.subject_prefix,
        )

        body = _build_body(
            fulfillment=fulfillment,
            product_name=args.product_name.strip() or DEFAULT_PRODUCT_NAME,
            support_email=support_email,
            activation_url=activation_url,
        )

        delivery_config = _build_mail_delivery_config(args)
        provider = resolve_mail_delivery_provider(delivery_config)
        message = _build_email_message(
            delivery_config=delivery_config,
            recipient=fulfillment.customer_email,
            subject=subject,
            body=body,
            reply_to=support_email,
        )

        if args.dry_run:
            print("Delivery email dry-run completed")
            print(f"- Artifact: {artifact_path}")
            print(f"- To: {fulfillment.customer_email}")
            print(f"- Subject: {subject}")
            print(f"- Delivery provider: {provider}")
            if provider == "graph" and delivery_config.graph is not None:
                print(f"- Graph sender user: {delivery_config.graph.sender_user}")
                print(f"- Graph from address: {message['From']}")
            elif delivery_config.smtp is not None:
                print(f"- SMTP host: {delivery_config.smtp.host}:{delivery_config.smtp.port}")
                print(f"- STARTTLS: {delivery_config.smtp.use_tls}")
            return 0

        send_email_message(message, delivery_config)

        print("Delivery email sent")
        print(f"- To: {fulfillment.customer_email}")
        print(f"- Subject: {subject}")
        print(f"- Delivery provider: {provider}")
        print(f"- Artifact: {artifact_path}")
        return 0

    except Exception as error:
        print(f"Email delivery failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
