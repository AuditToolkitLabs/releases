[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Bootstrap utility intentionally uses host-formatted status output during multi-host setup')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '', Justification='Bootstrap helper accepts password input for lab automation and immediately converts to SecureString in-memory')]
param(
    [string[]]$Hosts = @('192.168.100.30','192.168.100.31','192.168.100.32'),
    [string]$Username = 'audit_user',
    [securestring]$Password,
    [string]$ApiKey = 'dev-asset-discovery-key-change-in-production'
)

$ErrorActionPreference = 'Stop'
Import-Module Posh-SSH

$cred = if ($Password) {
    New-Object System.Management.Automation.PSCredential($Username, $Password)
} else {
    Get-Credential -UserName $Username -Message 'Enter SSH credentials for Linux hosts'
}

$remoteScript = @'
#!/usr/bin/env bash
set -euo pipefail
install -d -m 755 /opt/audit-direct-api
cat > /opt/audit-direct-api/server.py <<'PY'
#!/usr/bin/env python3
import os, json, hmac, hashlib, time, subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl

API_KEY = os.getenv('AUDIT_DISCOVERY_API_KEY', '').strip()
SIGNING_KEY = os.getenv('AUDIT_DISCOVERY_REQUEST_SIGNING_KEY', API_KEY).strip()
REQUIRE_API_KEY = os.getenv('AUDIT_DISCOVERY_REQUIRE_API_KEY', 'true').lower() in ('1','true','yes','on')
REQUIRE_SIG = os.getenv('AUDIT_DISCOVERY_REQUIRE_REQUEST_SIGNATURES', 'true').lower() in ('1','true','yes','on')
REQUIRE_NONCE = os.getenv('AUDIT_DISCOVERY_REQUIRE_NONCE', 'true').lower() in ('1','true','yes','on')
MAX_AGE = int(os.getenv('AUDIT_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS', '300'))
nonce_cache = {}

def cmd_out(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=10).strip()
    except Exception:
        return ''

def cmd_lines(cmd):
    out = cmd_out(cmd)
    if not out:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()]

def has_cmd(name):
    return bool(cmd_out(f"command -v {name}"))

def os_info():
    name='Linux'; version='Unknown'
    try:
        with open('/etc/os-release','r',encoding='utf-8') as f:
            d={}
            for line in f:
                if '=' in line:
                    k,v=line.strip().split('=',1)
                    d[k]=v.strip('"')
            name=d.get('NAME','Linux')
            version=d.get('VERSION_ID',d.get('VERSION','Unknown'))
    except Exception:
        pass
    return name, version

def collect_packages(limit=400):
    pkgs = []
    if has_cmd('dpkg-query'):
        lines = cmd_lines("dpkg-query -W -f='${Package}\t${Version}\n' | head -n 2000")
        for line in lines:
            parts = line.split('\t', 1)
            name = parts[0].strip() if len(parts) > 0 else ''
            version = parts[1].strip() if len(parts) > 1 else ''
            if name:
                pkgs.append({'name': name, 'version': version})
    elif has_cmd('rpm'):
        lines = cmd_lines("rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\n' | head -n 2000")
        for line in lines:
            parts = line.split('\t', 1)
            name = parts[0].strip() if len(parts) > 0 else ''
            version = parts[1].strip() if len(parts) > 1 else ''
            if name:
                pkgs.append({'name': name, 'version': version})
    elif has_cmd('apk'):
        lines = cmd_lines('apk info -v | head -n 2000')
        for line in lines:
            parts = line.rsplit('-', 2)
            if len(parts) >= 3:
                name = parts[0].strip()
                version = f"{parts[1]}-{parts[2]}"
            else:
                name = line.strip()
                version = ''
            if name:
                pkgs.append({'name': name, 'version': version})
    elif has_cmd('pacman'):
        lines = cmd_lines('pacman -Q 2>/dev/null | head -n 2000')
        for line in lines:
            parts = line.split(None, 1)
            name = parts[0].strip() if len(parts) > 0 else ''
            version = parts[1].strip() if len(parts) > 1 else ''
            if name:
                pkgs.append({'name': name, 'version': version})
    return pkgs[:limit]

def collect_pending_updates(limit=200):
    updates = []
    if has_cmd('apt'):
        lines = cmd_lines("apt list --upgradable 2>/dev/null | sed -n '2,220p'")
        for line in lines:
            if '/' not in line:
                continue
            name = line.split('/', 1)[0].strip()
            tokens = line.split()
            available = tokens[1].strip() if len(tokens) > 1 else ''
            current = ''
            marker = '[upgradable from:'
            idx = line.find(marker)
            if idx >= 0:
                rest = line[idx + len(marker):]
                current = rest.split(']', 1)[0].strip()
            if name:
                updates.append({'name': name, 'current_version': current, 'available_version': available})
    elif has_cmd('dnf'):
        lines = cmd_lines('dnf -q check-update 2>/dev/null | head -n 500')
        for line in lines:
            if line.startswith('Last metadata expiration check') or line.startswith('Obsoleting Packages'):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            name = parts[0].strip()
            available = parts[1].strip()
            if name and available and not name.startswith('Obsoleting'):
                updates.append({'name': name, 'current_version': '', 'available_version': available})
    elif has_cmd('yum'):
        lines = cmd_lines('yum -q check-update 2>/dev/null | head -n 500')
        for line in lines:
            if line.startswith('Obsoleting Packages'):
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            name = parts[0].strip()
            available = parts[1].strip()
            if name and available:
                updates.append({'name': name, 'current_version': '', 'available_version': available})
    elif has_cmd('zypper'):
        lines = cmd_lines('zypper --non-interactive list-updates 2>/dev/null | head -n 500')
        for line in lines:
            if '|' not in line:
                continue
            cols = [c.strip() for c in line.split('|')]
            if len(cols) < 8:
                continue
            name = cols[3]
            available = cols[6]
            if name and available and name.lower() != 'name':
                updates.append({'name': name, 'current_version': '', 'available_version': available})
    elif has_cmd('apk'):
        lines = cmd_lines("apk version -l '<' 2>/dev/null | head -n 220")
        for line in lines:
            name = line.split()[0].split('<', 1)[0].strip()
            if name:
                updates.append({'name': name, 'current_version': '', 'available_version': ''})
    elif has_cmd('pacman'):
        lines = cmd_lines('pacman -Qu 2>/dev/null | head -n 220')
        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                updates.append({'name': parts[0], 'current_version': parts[1], 'available_version': parts[3] if len(parts) > 3 else ''})
    return updates[:limit]

def collect_services(limit=250):
    services = []
    if has_cmd('systemctl'):
        lines = cmd_lines('systemctl list-units --type=service --all --no-legend --no-pager 2>/dev/null | head -n 600')
        for line in lines:
            parts = line.split(None, 4)
            if len(parts) < 3:
                continue
            services.append({'name': parts[0], 'status': parts[2]})
    elif has_cmd('rc-service'):
        names = cmd_lines('rc-service -l 2>/dev/null')
        for name in names[:limit]:
            status_line = cmd_out(f'rc-service {name} status 2>/dev/null | head -n 1')
            status = 'running' if 'started' in status_line.lower() else 'stopped'
            services.append({'name': name, 'status': status})
    return services[:limit]

def collect_open_ports(limit=200):
    ports = []
    lines = cmd_lines("ss -tulnH 2>/dev/null | head -n 500")
    for line in lines:
        parts = line.split()
        if len(parts) < 5:
            continue
        proto = parts[0]
        state = parts[1]
        local = parts[4]
        port = ''
        if ':' in local:
            port = local.rsplit(':', 1)[-1].strip('[]')
        elif local.isdigit():
            port = local
        if port.isdigit():
            ports.append({'port': int(port), 'protocol': proto, 'state': state.lower()})
    return ports[:limit]

def collect_users(limit=200):
    users = []
    try:
        with open('/etc/passwd', 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split(':')
                if len(parts) < 7:
                    continue
                users.append({
                    'username': parts[0],
                    'uid': int(parts[2]) if parts[2].isdigit() else None,
                    'shell': parts[6],
                })
    except Exception:
        return []
    return users[:limit]

def ssh_config_value(option):
    if has_cmd('sshd'):
        value = cmd_out(f"sshd -T 2>/dev/null | awk '/^{option} /{{print $2; exit}}'")
        if value:
            return value.lower()
    lines = cmd_lines("grep -RhiE '^[[:space:]]*" + option + "[[:space:]]+' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null | tail -n 1")
    if lines:
        parts = lines[-1].split()
        if len(parts) >= 2:
            return parts[1].strip().lower()
    return ''

def detect_firewall_enabled():
    if has_cmd('ufw'):
        status = cmd_out('ufw status 2>/dev/null | head -n 1').lower()
        if 'active' in status:
            return True
        if status:
            return False
    if has_cmd('systemctl'):
        for svc in ('firewalld', 'nftables', 'ufw'):
            if cmd_out(f'systemctl is-active {svc} 2>/dev/null') == 'active':
                return True
    return None

def detect_auto_updates_enabled():
    if has_cmd('systemctl'):
        checks = (
            'apt-daily.timer',
            'apt-daily-upgrade.timer',
            'dnf-automatic.timer',
            'yum-cron.service',
        )
        for unit in checks:
            if cmd_out(f'systemctl is-enabled {unit} 2>/dev/null') in ('enabled', 'static'):
                return True
    if has_cmd('rc-update') and cmd_out('rc-update show 2>/dev/null | grep -E "(crond|anacron)"'):
        return True
    return False

def detect_time_sync_enabled():
    if has_cmd('timedatectl'):
        syncd = cmd_out('timedatectl show -p NTPSynchronized --value 2>/dev/null').lower()
        if syncd in ('yes', '1', 'true'):
            return True
    if has_cmd('systemctl'):
        for svc in ('chronyd', 'systemd-timesyncd', 'ntpd'):
            if cmd_out(f'systemctl is-active {svc} 2>/dev/null') == 'active':
                return True
    if has_cmd('rc-service') and cmd_out('rc-service chronyd status 2>/dev/null | grep -qi started && echo yes') == 'yes':
        return True
    return False

def detect_mac_enforcement_enabled():
    if has_cmd('getenforce'):
        return cmd_out('getenforce 2>/dev/null').strip().lower() == 'enforcing'
    if has_cmd('aa-status'):
        out = cmd_out('aa-status --enabled 2>/dev/null; echo $?')
        return out.splitlines()[-1].strip() == '0' if out else False
    return False

def collect_security_info():
    permit_root = ssh_config_value('permitrootlogin')
    password_auth = ssh_config_value('passwordauthentication')
    hardening = {
        'firewall_enabled': detect_firewall_enabled(),
        'ssh_root_login_disabled': permit_root in ('no', 'prohibit-password', 'forced-commands-only'),
        'ssh_password_auth_disabled': password_auth == 'no',
        'auto_updates_enabled': detect_auto_updates_enabled(),
        'time_sync_enabled': detect_time_sync_enabled(),
        'mac_enforcement_enabled': detect_mac_enforcement_enabled(),
    }
    return {'hardening': hardening}

class H(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        b=json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _validate(self):
        now=int(time.time())
        for k,v in list(nonce_cache.items()):
            if v < now:
                nonce_cache.pop(k, None)

        if REQUIRE_API_KEY:
            provided=(self.headers.get('X-API-Key') or '').strip()
            if not API_KEY or not provided or not hmac.compare_digest(provided, API_KEY):
                return False, 'Invalid API key'

        if not REQUIRE_SIG:
            return True, ''

        ts=(self.headers.get('X-Agent-Timestamp') or '').strip()
        nonce=(self.headers.get('X-Agent-Nonce') or '').strip()
        content_sha=(self.headers.get('X-Agent-Content-SHA256') or '').strip().lower()
        sig=(self.headers.get('X-Agent-Signature') or '').strip()
        if not ts or not content_sha or not sig:
            return False, 'Missing request signature headers'
        if REQUIRE_NONCE and not nonce:
            return False, 'Missing X-Agent-Nonce header'
        try:
            ts_i=int(ts)
        except Exception:
            return False, 'Invalid X-Agent-Timestamp header'
        if abs(now - ts_i) > MAX_AGE:
            return False, 'Request signature timestamp expired'

        expected_body_hash=hashlib.sha256(b'').hexdigest()
        if not hmac.compare_digest(content_sha, expected_body_hash):
            return False, 'Invalid request content hash'

        if nonce:
            cache_key=f"{ts}:{nonce}"
            if cache_key in nonce_cache:
                return False, 'Replay detected'
            nonce_cache[cache_key]=now+MAX_AGE

        msg='\n'.join([ts, self.command.upper(), self.path, content_sha, nonce]).encode('utf-8')
        expected=hmac.new((SIGNING_KEY or API_KEY).encode('utf-8'), msg, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return False, 'Invalid request signature'
        return True, ''

    def do_GET(self):
        if self.path == '/health':
            self._json(200, {'status':'ok','service':'direct-api-endpoint'})
            return
        if self.path == '/api/system-info':
            ok, err = self._validate()
            if not ok:
                self._json(401, {'error': err})
                return
            hn = cmd_out('hostname') or 'unknown'
            os_name, os_ver = os_info()
            kernel = cmd_out('uname -r')
            arch = cmd_out('uname -m')
            packages = collect_packages()
            pending_updates = collect_pending_updates()
            services = collect_services()
            open_ports = collect_open_ports()
            users = collect_users()
            security_info = collect_security_info()
            self._json(200, {
                'hostname': hn,
                'os_type': 'linux',
                'os_name': os_name,
                'os_version': os_ver,
                'kernel_version': kernel,
                'architecture': arch,
                'packages': packages,
                'services': services,
                'open_ports': open_ports,
                'updates_available': len(pending_updates),
                'pending_updates': pending_updates,
                'users': users,
                'security_info': security_info
            })
            return
        self._json(404, {'error':'not found'})

if __name__ == '__main__':
    cert='/opt/audit-direct-api/cert.pem'
    key='/opt/audit-direct-api/key.pem'
    httpd=HTTPServer(('0.0.0.0', 8443), H)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=cert, keyfile=key)
    httpd.socket=ctx.wrap_socket(httpd.socket, server_side=True)
    httpd.serve_forever()
PY
chmod 755 /opt/audit-direct-api/server.py

cat > /opt/audit-direct-api/direct-api.env <<'ENV'
AUDIT_DISCOVERY_REQUIRE_API_KEY=true
AUDIT_DISCOVERY_REQUIRE_REQUEST_SIGNATURES=true
AUDIT_DISCOVERY_API_KEY=__API_KEY__
AUDIT_DISCOVERY_REQUEST_SIGNING_KEY=__API_KEY__
AUDIT_DISCOVERY_REQUEST_SIGNATURE_MAX_AGE_SECONDS=300
AUDIT_DISCOVERY_REQUIRE_NONCE=true
ENV
chmod 600 /opt/audit-direct-api/direct-api.env

if [ ! -f /opt/audit-direct-api/cert.pem ] || [ ! -f /opt/audit-direct-api/key.pem ]; then
  openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
    -keyout /opt/audit-direct-api/key.pem \
    -out /opt/audit-direct-api/cert.pem \
    -subj '/CN=direct-api-endpoint' >/dev/null 2>&1
fi

cat > /etc/systemd/system/audit-direct-api.service <<'UNIT'
[Unit]
Description=Audit Toolkit Direct API Endpoint
After=network.target

[Service]
Type=simple
EnvironmentFile=/opt/audit-direct-api/direct-api.env
ExecStart=/usr/bin/python3 /opt/audit-direct-api/server.py
Restart=always
RestartSec=2
User=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable audit-direct-api.service
systemctl restart audit-direct-api.service

if command -v ufw >/dev/null 2>&1; then
  ufw allow 8443/tcp >/dev/null 2>&1 || true
fi
if command -v firewall-cmd >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port=8443/tcp >/dev/null 2>&1 || true
  firewall-cmd --reload >/dev/null 2>&1 || true
fi

echo READY
systemctl is-active audit-direct-api.service
'@

$remoteScript = $remoteScript.Replace('__API_KEY__', $ApiKey)

foreach ($targetHost in $Hosts) {
    Write-Output "==== $targetHost ===="
    $session = New-SSHSession -ComputerName $targetHost -Credential $cred -AcceptKey
    try {
        $tmp = "/tmp/direct-api-setup.sh"
        $remoteScriptB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($remoteScript))
        $cmd = "echo '$remoteScriptB64' | base64 -d > $tmp; sed -i 's/\r$//' $tmp; chmod +x $tmp; sudo -n bash $tmp"
        $result = Invoke-SSHCommand -SSHSession $session -Command $cmd -TimeOut 180
        $result.Output | ForEach-Object { Write-Host $_ }
        if ($result.Error) {
            Write-Output "ERR: $($result.Error -join ' | ')"
        }
    }
    finally {
        Remove-SSHSession -SSHSession $session | Out-Null
    }
}
