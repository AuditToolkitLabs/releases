#Requires -RunAsAdministrator
#Requires -Version 5.1

<#
.SYNOPSIS
    Unified Hyper-V test environment setup for Windows + Linux target validation.

.DESCRIPTION
    Creates/starts a minimal dual-OS Hyper-V lab from ISO media and prints the
    exact post-install guest configuration and validation commands needed to close
    Scenario 1 (WinRM) and Scenario 2 (SSH) in the test checklist.

.EXAMPLE
    .\tools\setup-full-hyperv-test-env.ps1 \
      -WindowsISOPath "C:\ISO\WindowsServer2022.iso" \
      -LinuxISOPath "C:\ISO\ubuntu-24.04.3-live-server-amd64.iso" \
      -CreateVMs -StartVMs

.EXAMPLE
    .\tools\setup-full-hyperv-test-env.ps1 \
      -WindowsTargetIP "192.168.100.20" \
      -LinuxTargetIP "192.168.100.30" \
      -RunValidation
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [Parameter()]
    [string]$WindowsISOPath,

    [Parameter()]
    [string]$LinuxISOPath,

    [Parameter()]
    [string]$SwitchName = "AuditLabSwitch",

    [Parameter()]
    [string]$VhdRoot = "C:\Hyper-V\Virtual Hard Disks",

    [Parameter()]
    [string]$WindowsVMName = "AuditTest-Win2022",

    [Parameter()]
    [string]$LinuxVMName = "AuditTest-Ubuntu2404",

    [Parameter()]
    [int]$WindowsMemoryGB = 4,

    [Parameter()]
    [int]$LinuxMemoryGB = 2,

    [Parameter()]
    [int]$WindowsDiskGB = 60,

    [Parameter()]
    [int]$LinuxDiskGB = 40,

    [Parameter()]
    [int]$WindowsCpu = 2,

    [Parameter()]
    [int]$LinuxCpu = 2,

    [Parameter()]
    [string]$WindowsTargetIP = "",

    [Parameter()]
    [string]$LinuxTargetIP = "",

    [Parameter()]
    [switch]$CreateVMs,

    [Parameter()]
    [switch]$StartVMs,

    [Parameter()]
    [switch]$RunValidation,

    [Parameter()]
    [switch]$ForceRecreate
)

$null = $SwitchName, $VhdRoot, $WindowsTargetIP, $LinuxTargetIP, $ForceRecreate

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path $PSScriptRoot -Parent

function Write-Status { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Success { param([string]$Message) Write-Host "[+] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }
function Write-Fail { param([string]$Message) Write-Host "[-] $Message" -ForegroundColor Red }

function Test-Admin {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-HyperV {
    $hyperV = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -ErrorAction SilentlyContinue
    if (-not $hyperV -or $hyperV.State -ne "Enabled") {
        throw "Hyper-V is not enabled. Run: Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All"
    }

    Get-Command Get-VM -ErrorAction Stop | Out-Null
}

function Initialize-VhdRoot {
    if (-not (Test-Path $VhdRoot)) {
        New-Item -ItemType Directory -Path $VhdRoot -Force | Out-Null
        Write-Success "Created VHD root: $VhdRoot"
    }
}

function Initialize-Switch {
    $switch = Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue
    if ($switch) {
        Write-Status "Using existing switch: $SwitchName"
        return
    }

    Write-Status "Creating internal switch: $SwitchName"
    New-VMSwitch -Name $SwitchName -SwitchType Internal | Out-Null

    $adapter = Get-NetAdapter | Where-Object { $_.Name -like "*$SwitchName*" } | Select-Object -First 1
    if ($adapter) {
        New-NetIPAddress -InterfaceIndex $adapter.ifIndex -IPAddress "192.168.100.1" -PrefixLength 24 -ErrorAction SilentlyContinue | Out-Null
        New-NetNat -Name "AuditLabNAT" -InternalIPInterfaceAddressPrefix "192.168.100.0/24" -ErrorAction SilentlyContinue | Out-Null
    }

    Write-Success "Switch created: $SwitchName"
}

function Remove-ExistingVM {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param([string]$Name, [string]$VhdPath)

    $existing = Get-VM -Name $Name -ErrorAction SilentlyContinue
    if (-not $existing) {
        return
    }

    if (-not $ForceRecreate) {
        throw "VM '$Name' already exists. Re-run with -ForceRecreate to replace it."
    }

    if (-not $PSCmdlet.ShouldProcess($Name, 'Remove existing VM and VHD for recreation')) {
        return
    }

    Write-Warn "Recreating VM: $Name"
    if ($existing.State -ne "Off") {
        Stop-VM -Name $Name -Force -TurnOff
    }
    Remove-VM -Name $Name -Force

    if (Test-Path $VhdPath) {
        Remove-Item -Path $VhdPath -Force
    }
}

function New-TestVm {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [string]$Name,
        [string]$OsType,
        [string]$IsoPath,
        [int]$MemoryGB,
        [int]$DiskGB,
        [int]$CpuCount
    )

    if (-not (Test-Path $IsoPath)) {
        throw "ISO not found for ${Name}: $IsoPath"
    }

    if (-not $PSCmdlet.ShouldProcess($Name, "Create $OsType test VM from ISO")) {
        return
    }

    $vhdPath = Join-Path $VhdRoot "$Name.vhdx"
    Remove-ExistingVM -Name $Name -VhdPath $vhdPath

    Write-Status "Creating $OsType VM: $Name"
    New-VM -Name $Name `
        -Generation 2 `
        -MemoryStartupBytes ($MemoryGB * 1GB) `
        -NewVHDPath $vhdPath `
        -NewVHDSizeBytes ($DiskGB * 1GB) `
        -SwitchName $SwitchName | Out-Null

    Set-VMProcessor -VMName $Name -Count $CpuCount
    Set-VMMemory -VMName $Name -DynamicMemoryEnabled $true -MinimumBytes 1GB -MaximumBytes ($MemoryGB * 2GB)
    Set-VM -VMName $Name -CheckpointType Disabled

    if ($OsType -eq "Linux") {
        Set-VMFirmware -VMName $Name -EnableSecureBoot Off
    }
    else {
        Set-VMFirmware -VMName $Name -EnableSecureBoot On -SecureBootTemplate MicrosoftWindows
    }

    Add-VMDvdDrive -VMName $Name -Path $IsoPath
    $dvd = Get-VMDvdDrive -VMName $Name
    $hdd = Get-VMHardDiskDrive -VMName $Name
    Set-VMFirmware -VMName $Name -BootOrder $dvd, $hdd

    Write-Success "Created VM: $Name ($OsType)"
}

function Start-TestVm {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param([string]$Name)

    $vm = Get-VM -Name $Name -ErrorAction SilentlyContinue
    if (-not $vm) {
        Write-Warn "VM not found: $Name"
        return
    }

    if ($vm.State -eq "Running") {
        Write-Status "$Name is already running"
        return
    }

    if (-not $PSCmdlet.ShouldProcess($Name, 'Start test VM')) {
        return
    }

    Start-VM -Name $Name | Out-Null
    Write-Success "Started VM: $Name"
}

function Show-GuestBootstrapInstructions {
    Write-Output ""
    Write-Output "==================== Post-Install Guest Setup ===================="
    Write-Output "On WINDOWS VM (PowerShell as Administrator):"
    Write-Output '  Enable-PSRemoting -Force'
    Write-Output '  winrm quickconfig -force'
    Write-Output '  Set-Item WSMan:\localhost\Service\AllowUnencrypted -Value $true -Force'
    Write-Output '  New-NetFirewallRule -Name "WinRM-HTTP-In" -DisplayName "WinRM HTTP In" -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5985 -Action Allow'
    Write-Output '  $p = ConvertTo-SecureString "TestPass123!" -AsPlainText -Force'
    Write-Output '  New-LocalUser -Name "audit_user" -Password $p -FullName "Audit Test User" -Description "Audit toolkit testing"'
    Write-Output '  Add-LocalGroupMember -Group "Administrators" -Member "audit_user"'

    Write-Output ""
    Write-Output "On LINUX VM (Ubuntu/Debian shell):"
    Write-Output '  sudo apt update'
    Write-Output '  sudo apt install -y openssh-server curl'
    Write-Output '  sudo systemctl enable ssh'
    Write-Output '  sudo systemctl start ssh'
    Write-Output '  sudo useradd -m -s /bin/bash audit_user || true'
    Write-Output '  echo "audit_user:TestPass123!" | sudo chpasswd'
    Write-Output '  sudo usermod -aG sudo audit_user'
    Write-Output ""
}

function Invoke-FullValidation {
    if ([string]::IsNullOrWhiteSpace($WindowsTargetIP) -or [string]::IsNullOrWhiteSpace($LinuxTargetIP)) {
        throw "-RunValidation requires both -WindowsTargetIP and -LinuxTargetIP."
    }

    $e2eScript = Join-Path $ProjectRoot "tests\e2e_validation.ps1"
    $apiScript = Join-Path $ProjectRoot "tests\api_endpoint_validation.ps1"
    $gateScript = Join-Path $ProjectRoot "run-release-gate.ps1"

    Write-Status "Running full validation with explicit Windows/Linux targets"
    & $e2eScript -WindowsTarget $WindowsTargetIP -LinuxTarget $LinuxTargetIP
    if ($LASTEXITCODE -ne 0) {
        throw "e2e_validation failed with exit code $LASTEXITCODE"
    }

    & $apiScript -RequireDiagnosticsApis
    if ($LASTEXITCODE -ne 0) {
        throw "api_endpoint_validation failed with exit code $LASTEXITCODE"
    }

    & $gateScript -RequireDiagnosticsApis -WindowsTarget $WindowsTargetIP -LinuxTarget $LinuxTargetIP
    if ($LASTEXITCODE -ne 0) {
        throw "run-release-gate failed with exit code $LASTEXITCODE"
    }

    Write-Success "Validation run completed successfully"
}

try {
    Write-Output "================================================================="
    Write-Output " Hyper-V Full Test Environment Setup (Windows + Linux)"
    Write-Output "================================================================="

    if (-not (Test-Admin)) {
        throw "This script must run in an elevated PowerShell session."
    }

    Test-HyperV
    Initialize-VhdRoot
    Initialize-Switch

    if ($CreateVMs) {
        if ([string]::IsNullOrWhiteSpace($WindowsISOPath) -or [string]::IsNullOrWhiteSpace($LinuxISOPath)) {
            throw "-CreateVMs requires both -WindowsISOPath and -LinuxISOPath."
        }

        New-TestVm -Name $WindowsVMName -OsType "Windows" -IsoPath $WindowsISOPath -MemoryGB $WindowsMemoryGB -DiskGB $WindowsDiskGB -CpuCount $WindowsCpu
        New-TestVm -Name $LinuxVMName -OsType "Linux" -IsoPath $LinuxISOPath -MemoryGB $LinuxMemoryGB -DiskGB $LinuxDiskGB -CpuCount $LinuxCpu
    }

    if ($StartVMs) {
        Start-TestVm -Name $WindowsVMName
        Start-TestVm -Name $LinuxVMName
        Write-Status "Open consoles if needed: vmconnect localhost $WindowsVMName ; vmconnect localhost $LinuxVMName"
    }

    Show-GuestBootstrapInstructions

    if ($RunValidation) {
        Invoke-FullValidation
    }
    else {
        Write-Status "Validation not run. Use -RunValidation with -WindowsTargetIP and -LinuxTargetIP after guest setup."
    }

    Write-Success "Environment setup workflow completed."
}
catch {
    Write-Fail $_.Exception.Message
    exit 1
}

