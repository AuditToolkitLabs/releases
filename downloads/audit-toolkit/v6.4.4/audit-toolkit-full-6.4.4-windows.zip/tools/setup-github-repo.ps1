﻿<#
.SYNOPSIS
    Automates GitHub repository setup for public release.

.DESCRIPTION
    Configures:
    - Repository description and topics
    - GitHub Pages
    - Discussions
    - Security features
    - Branch protection
    - Creates v4.3.2 release

.EXAMPLE
    # First install GitHub CLI:
    winget install GitHub.cli

    # Authenticate:
    gh auth login

    # Run this script:
    .\tools\setup-github-repo.ps1

.NOTES
    Requires: GitHub CLI (gh) authenticated with repo access
#>

param(
    [switch]$DryRun = $false,
    [switch]$SkipRelease = $false
)

$ErrorActionPreference = "Stop"

# Configuration
$Owner = "AuditToolkitLabs"
$Repo = "Audit-Tool-"
$FullRepo = "$Owner/$Repo"

$Description = "🛡️ Security audit toolkit for Linux, Windows & Hypervisors. 255+ scripts, 390+ APIs. Self-hosted, on-premises. Free tier: 25 servers. BSL 1.1 licensed."

$Topics = @(
    "security",
    "audit",
    "linux",
    "windows",
    "hypervisor",
    "compliance",
    "vulnerability-scanner",
    "self-hosted",
    "devops",
    "security-tools",
    "siem",
    "cis-benchmark"
)

$ReleaseTag = "v4.3.2"
$ReleaseTitle = "v4.3.2 - Community Beta Release"

# Check for gh CLI
Write-Output "`n"
Write-Output "============================================================"
Write-Output "  GitHub Repository Setup Script"
Write-Output "============================================================"

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Output "`n❌ GitHub CLI (gh) not found!"
    Write-Output @"

Install with:
  winget install GitHub.cli

Then authenticate:
  gh auth login

"@ -ForegroundColor Yellow
    exit 1
}

# Check authentication
Write-Output "`nChecking GitHub CLI authentication..."
gh auth status 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Output "❌ Not authenticated. Run: gh auth login"
    exit 1
}
Write-Output "✓ Authenticated"

# Helper function
function Invoke-GhCommand {
    param([string[]]$CommandArgs, [string]$Description)

    Write-Output "`n→ $Description"
    Write-Output ("  gh {0}" -f ($CommandArgs -join ' '))

    if ($DryRun) {
        Write-Output "  [DRY RUN - skipped]"
        return
    }

    $result = & gh @CommandArgs 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Output "  ✓ Done"
    } else {
        Write-Output "  ⚠ Warning: $result"
    }
}

Write-Output "`n📋 Repository: $FullRepo"
if ($DryRun) {
    Write-Output "🔍 DRY RUN MODE - No changes will be made"
}

# 1. Set description
Invoke-GhCommand `
    -CommandArgs @('repo','edit',$FullRepo,'--description',$Description) `
    -Description "Setting repository description"

# 2. Add topics
Invoke-GhCommand `
    -CommandArgs @('repo','edit',$FullRepo) + ($Topics | ForEach-Object { "--add-topic=$_" }) `
    -Description "Adding repository topics"

# 3. Enable discussions
Invoke-GhCommand `
    -CommandArgs @('repo','edit',$FullRepo,'--enable-discussions') `
    -Description "Enabling Discussions"

# 4. Enable GitHub Pages (via API)
Write-Output "`n→ Enabling GitHub Pages (branch: main, folder: /site)"
if (-not $DryRun) {
    $pagesPayload = @{
        source = @{
            branch = "main"
            path = "/site"
        }
    } | ConvertTo-Json -Compress

    try {
        gh api -X POST "repos/$FullRepo/pages" --input - 2>&1 | Out-Null
        # If pages already exist, try PUT instead
        if ($LASTEXITCODE -ne 0) {
            $pagesPayload | gh api -X PUT "repos/$FullRepo/pages" --input - 2>&1 | Out-Null
        }
        Write-Output "  ✓ GitHub Pages configured"
    } catch {
        Write-Output "  ⚠ Pages may already be configured or need manual setup"
    }
} else {
    Write-Output "  [DRY RUN - skipped]"
}

# 5. Enable security features (via API)
Write-Output "`n→ Enabling security features"
if (-not $DryRun) {
    # Enable vulnerability alerts
    gh api -X PUT "repos/$FullRepo/vulnerability-alerts" 2>&1 | Out-Null
    Write-Output "  ✓ Vulnerability alerts enabled"

    # Enable automated security fixes
    gh api -X PUT "repos/$FullRepo/automated-security-fixes" 2>&1 | Out-Null
    Write-Output "  ✓ Automated security fixes enabled"
} else {
    Write-Output "  [DRY RUN - skipped]"
}

# 6. Set up branch protection for main
Write-Output "`n→ Configuring branch protection for 'main'"
if (-not $DryRun) {
    $branchProtection = @{
        required_status_checks = @{
            strict = $true
            contexts = @()
        }
        enforce_admins = $false
        required_pull_request_reviews = $null
        restrictions = $null
        allow_force_pushes = $false
        allow_deletions = $false
    } | ConvertTo-Json -Depth 5 -Compress

    try {
        $branchProtection | gh api -X PUT "repos/$FullRepo/branches/main/protection" --input - 2>&1 | Out-Null
        Write-Output "  ✓ Branch protection configured"
    } catch {
        Write-Output "  ⚠ Branch protection may need manual configuration"
    }
} else {
    Write-Output "  [DRY RUN - skipped]"
}

# 7. Create release
if (-not $SkipRelease) {
    Write-Output "`n→ Creating release $ReleaseTag"

    # Check if release already exists
    gh release view $ReleaseTag 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Output "  ⚠ Release $ReleaseTag already exists"
    } elseif (-not $DryRun) {
        # Read changelog for release notes
        $changelogPath = Join-Path $PSScriptRoot "..\CHANGELOG.md"
        $releaseNotes = ""
        if (Test-Path $changelogPath) {
            $changelog = Get-Content $changelogPath -Raw
            # Extract v4.3.2 section
            if ($changelog -match "(?s)## \[4\.3\.2\].*?(?=## \[|$)") {
                $releaseNotes = $Matches[0]
            }
        }

        if ($releaseNotes) {
            $releaseNotes | gh release create $ReleaseTag --title "$ReleaseTitle" --notes-file - --latest
        } else {
            gh release create $ReleaseTag --title "$ReleaseTitle" --generate-notes --latest
        }

        if ($LASTEXITCODE -eq 0) {
            Write-Output "  ✓ Release $ReleaseTag created"
        } else {
            Write-Output "  ⚠ Failed to create release"
        }
    } else {
        Write-Output "  [DRY RUN - skipped]"
    }
}

# Summary
Write-Output @"

============================================================
  ✅ Setup Complete!
============================================================

Automated:
  ✓ Description set
  ✓ Topics added (12 topics)
  ✓ Discussions enabled
  ✓ GitHub Pages configured (/site)
  ✓ Security features enabled
  ✓ Branch protection configured
  ✓ Release $ReleaseTag created

Manual steps remaining:
  • Upload social preview image (1280x640)
    → Settings → General → Social preview

  • Change visibility to Public (when ready)
    → Settings → Danger Zone → Change visibility

Links:
  • Settings: https://github.com/$FullRepo/settings
  • Pages: https://github.com/$FullRepo/settings/pages
  • Releases: https://github.com/$FullRepo/releases

"@ -ForegroundColor Cyan
