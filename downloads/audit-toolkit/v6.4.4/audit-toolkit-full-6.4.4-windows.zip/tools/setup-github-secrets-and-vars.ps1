﻿# GitHub Secrets & Variables Setup Script (PowerShell)
# Usage: pwsh -NoLogo -NoProfile -File tools/setup-github-secrets-and-vars.ps1

$gh = 'C:\Program Files\GitHub CLI\gh.exe'

function Read-SecretValue {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Prompt
    )

    $secureValue = Read-Host $Prompt -AsSecureString
    if ($null -eq $secureValue) {
        return ""
    }

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        if ($bstr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
    }
}

Write-Output "=== GitHub Secrets & Variables Setup ==="
Write-Output ""
Write-Output "Setting all required Gumroad license fulfillment secrets and variables."
Write-Output ""

# ==============================================================================
# GUMROAD_ACCESS_TOKEN (Secret)
# ==============================================================================

Write-Output "--- Secret: GUMROAD_ACCESS_TOKEN ---"
Write-Output "Get from: https://app.gumroad.com/account/settings"
Write-Output "  → Click 'OAuth applications' (or 'Applications' section)"
Write-Output "  → Create/select an OAuth app"
Write-Output "  → Click 'Generate access token' button"
Write-Output "  → Select scope: view_sales"
Write-Output "  → Copy the token"
Write-Output "  → If needed, validate it first with: pwsh -NoLogo -NoProfile -File tools/validate-gumroad-token.ps1"
Write-Output ""

$gumroad_token = Read-SecretValue "Enter GUMROAD_ACCESS_TOKEN"

if ([string]::IsNullOrWhiteSpace($gumroad_token)) {
    Write-Output "ERROR: Token cannot be empty"
    exit 1
}

Write-Output "Setting GUMROAD_ACCESS_TOKEN..."
& $gh secret set GUMROAD_ACCESS_TOKEN --body $gumroad_token
if ($LASTEXITCODE -eq 0) {
    Write-Output "✓ GUMROAD_ACCESS_TOKEN set"
} else {
    Write-Output "✗ Failed to set GUMROAD_ACCESS_TOKEN"
    exit 1
}

# ==============================================================================
# Verify Keygen & SMTP Secrets Exist
# ==============================================================================

Write-Output ""
Write-Output "--- Verifying Existing Secrets ---"
Write-Output "The following secrets must already be set in your repository:"
Write-Output "  - KEYGEN_API_KEY"
Write-Output "  - KEYGEN_ACCOUNT_ID"
Write-Output "  - KEYGEN_PRODUCT_ID"
Write-Output "  - FULFILLMENT_SMTP_HOST"
Write-Output "  - FULFILLMENT_SMTP_USER"
Write-Output "  - FULFILLMENT_SMTP_PASSWORD"
Write-Output "  - FULFILLMENT_SMTP_FROM"
Write-Output ""

$verify = Read-Host "Have you verified these secrets exist? (y/n)"
if ($verify -ne "y" -and $verify -ne "Y") {
    Write-Output "Please set these secrets first, then re-run this script."
    Write-Output "You can set them manually at: https://github.com/AuditToolkitLabs/Audit-Tool-/settings/secrets/actions"
    exit 1
}

# ==============================================================================
    # Product IDs (Pre-configured)
# ==============================================================================

Write-Output ""
Write-Output "--- Product IDs (pre-configured) ---"
    Write-Output "Seller ID is not required for the current Gumroad polling workflow."

$products = @{
    "GUMROAD_STARTER_PRODUCT_ID" = "dvqeg"
    "GUMROAD_PROFESSIONAL_PRODUCT_ID" = "oasazq"
    "GUMROAD_BUSINESS_PRODUCT_ID" = "qxwunf"
    "GUMROAD_ENTERPRISE_PRODUCT_ID" = "xvsuc"
}

foreach ($name in $products.Keys) {
    $value = $products[$name]
    Write-Output "Setting $name..."
    & $gh variable set $name --body $value
    if ($LASTEXITCODE -eq 0) {
        Write-Output "✓ $name = $value"
    } else {
        Write-Output "✗ Failed to set $name"
        exit 1
    }
}

# ==============================================================================
# Complete
# ==============================================================================

Write-Output ""
Write-Output "=== Setup Complete ==="
Write-Output ""
Write-Output "Next steps:"
Write-Output "1. Go to: https://github.com/AuditToolkitLabs/Audit-Tool-/actions"
Write-Output "2. Click on 'License Fulfillment (Gumroad Poll)' workflow"
Write-Output "3. Click 'Run workflow' button (top right)"
Write-Output "4. Set inputs:"
Write-Output "   - branch: main"
Write-Output "   - bootstrap_from_now: true"
Write-Output "   - allow_test_purchases: false"
Write-Output "   - dry_run: false"
Write-Output "5. Click 'Run workflow'"
Write-Output "6. Wait for completion and verify GUMROAD_LAST_CURSOR variable is created"
Write-Output ""
Write-Output "After bootstrap, the workflow will run automatically every 15 minutes."

