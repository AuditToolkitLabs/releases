#!/bin/bash
# GitHub Secrets & Variables Setup Script
# Usage: bash tools/setup-github-secrets-and-vars.sh
# Prerequisites: gh CLI installed and authenticated (gh auth login)

set -euo pipefail

echo "=== GitHub Secrets & Variables Setup ==="
echo ""
echo "This script sets up all required Gumroad license fulfillment secrets and variables."
echo "Make sure you have GitHub CLI installed and authenticated:"
echo "  gh auth login"
echo ""

# ==============================================================================
# SECRETS (sensitive values - DO NOT commit these to the repo)
# ==============================================================================

echo "--- Setting Secrets ---"
echo ""

# GUMROAD_ACCESS_TOKEN
# Get from: https://app.gumroad.com/account/settings -> OAuth app settings -> Generate access token
# Scope required: view_sales
echo "Tip: validate a new token first with: pwsh -NoLogo -NoProfile -File tools/validate-gumroad-token.ps1"
read -r -s -p "Enter GUMROAD_ACCESS_TOKEN: " GUMROAD_ACCESS_TOKEN
echo ""
if [[ -z "$GUMROAD_ACCESS_TOKEN" ]]; then
  echo "ERROR: Token cannot be empty"
  exit 1
fi
gh secret set GUMROAD_ACCESS_TOKEN --body "$GUMROAD_ACCESS_TOKEN"
echo "✓ GUMROAD_ACCESS_TOKEN set"

# Verify existing Keygen & SMTP secrets (optional, but recommended)
echo ""
echo "Checking for existing Keygen and SMTP secrets..."
echo "The following must already be in your repo secrets:"
echo "  - KEYGEN_API_KEY"
echo "  - KEYGEN_ACCOUNT_ID"
echo "  - KEYGEN_PRODUCT_ID"
echo "  - FULFILLMENT_SMTP_HOST"
echo "  - FULFILLMENT_SMTP_USER"
echo "  - FULFILLMENT_SMTP_PASSWORD"
echo "  - FULFILLMENT_SMTP_FROM"
echo ""
read -p "Have you verified these secrets exist? (y/n): " verify_secrets
if [[ "$verify_secrets" != "y" ]]; then
  echo "Please set these secrets first, then re-run this script."
  exit 1
fi

# ==============================================================================
# VARIABLES (non-sensitive config)
# ==============================================================================

echo ""
echo "--- Setting Variables ---"
echo ""
echo "Seller ID is not required for the current Gumroad polling workflow."

# GUMROAD_STARTER_PRODUCT_ID
gh variable set GUMROAD_STARTER_PRODUCT_ID --body "dvqeg"
echo "✓ GUMROAD_STARTER_PRODUCT_ID = dvqeg"

# GUMROAD_PROFESSIONAL_PRODUCT_ID
gh variable set GUMROAD_PROFESSIONAL_PRODUCT_ID --body "oasazq"
echo "✓ GUMROAD_PROFESSIONAL_PRODUCT_ID = oasazq"

# GUMROAD_BUSINESS_PRODUCT_ID
gh variable set GUMROAD_BUSINESS_PRODUCT_ID --body "qxwunf"
echo "✓ GUMROAD_BUSINESS_PRODUCT_ID = qxwunf"

# GUMROAD_ENTERPRISE_PRODUCT_ID
gh variable set GUMROAD_ENTERPRISE_PRODUCT_ID --body "xvsuc"
echo "✓ GUMROAD_ENTERPRISE_PRODUCT_ID = xvsuc"

echo ""
echo "=== Setup Complete ==="
echo ""
echo "Next steps:"
echo "1. Go to Actions → License Fulfillment (Gumroad Poll)"
echo "2. Click 'Run workflow'"
echo "3. Set inputs:"
echo "   - bootstrap_from_now: true"
echo "   - allow_test_purchases: false"
echo "   - dry_run: false"
echo "4. Wait for completion"
echo "5. Verify GUMROAD_LAST_CURSOR variable was created"
echo ""
echo "After bootstrap, the workflow will run automatically every 15 minutes."

