#!/usr/bin/env bash
set -euo pipefail

AUDIT_USER="${AUDIT_USER:-audit_user}"
SSH_PUBLIC_KEY="${SSH_PUBLIC_KEY:-}"
SSH_PUBLIC_KEY_FILE="${SSH_PUBLIC_KEY_FILE:-}"
DISABLE_PASSWORD_AUTH="${DISABLE_PASSWORD_AUTH:-1}"
CREATE_USER_IF_MISSING="${CREATE_USER_IF_MISSING:-1}"
RESTART_SSH="${RESTART_SSH:-1}"

log() {
  printf '[*] %s\n' "$*"
}

ok() {
  printf '[+] %s\n' "$*"
}

warn() {
  printf '[!] %s\n' "$*"
}

fail() {
  printf '[-] %s\n' "$*" >&2
  exit 1
}

if [[ "${EUID}" -ne 0 ]]; then
  if command -v sudo > /dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  else
    fail "This script requires root (or sudo)."
  fi
fi

read_public_key() {
  if [[ -n "${SSH_PUBLIC_KEY}" ]]; then
    printf '%s\n' "${SSH_PUBLIC_KEY}"
    return
  fi

  if [[ -n "${SSH_PUBLIC_KEY_FILE}" ]]; then
    [[ -f "${SSH_PUBLIC_KEY_FILE}" ]] || fail "SSH_PUBLIC_KEY_FILE not found: ${SSH_PUBLIC_KEY_FILE}"
    cat "${SSH_PUBLIC_KEY_FILE}"
    return
  fi

  fail "Provide SSH_PUBLIC_KEY or SSH_PUBLIC_KEY_FILE."
}

ensure_user() {
  if id "${AUDIT_USER}" > /dev/null 2>&1; then
    log "User exists: ${AUDIT_USER}"
    return
  fi

  if [[ "${CREATE_USER_IF_MISSING}" != "1" ]]; then
    fail "User '${AUDIT_USER}' does not exist and CREATE_USER_IF_MISSING is disabled."
  fi

  log "Creating user: ${AUDIT_USER}"
  useradd -m -s /bin/bash "${AUDIT_USER}"
  ok "Created user: ${AUDIT_USER}"
}

set_sshd_option() {
  local key="$1"
  local value="$2"
  local cfg="/etc/ssh/sshd_config"

  if [[ ! -f "$cfg" ]]; then
    fail "Missing sshd config: $cfg"
  fi

  if grep -Eq "^\s*#?\s*${key}\b" "$cfg"; then
    sed -i -E "s|^\s*#?\s*${key}\b.*|${key} ${value}|" "$cfg"
  else
    printf '\n%s %s\n' "$key" "$value" >> "$cfg"
  fi
}

configure_sshd() {
  log "Configuring sshd for key-based non-root access"
  set_sshd_option "PermitRootLogin" "no"
  set_sshd_option "PubkeyAuthentication" "yes"
  set_sshd_option "ChallengeResponseAuthentication" "no"

  if [[ "${DISABLE_PASSWORD_AUTH}" == "1" ]]; then
    set_sshd_option "PasswordAuthentication" "no"
    ok "Password SSH auth disabled"
  else
    set_sshd_option "PasswordAuthentication" "yes"
    warn "Password SSH auth remains enabled"
  fi
}

install_authorized_key() {
  local pubkey
  pubkey="$(read_public_key)"

  local home_dir
  home_dir="$(getent passwd "${AUDIT_USER}" | cut -d: -f6)"
  [[ -n "$home_dir" ]] || fail "Unable to resolve home directory for ${AUDIT_USER}"

  local ssh_dir="${home_dir}/.ssh"
  local auth_file="${ssh_dir}/authorized_keys"

  mkdir -p "$ssh_dir"
  chmod 700 "$ssh_dir"

  touch "$auth_file"
  chmod 600 "$auth_file"

  if grep -Fqx "$pubkey" "$auth_file"; then
    log "Public key already present in authorized_keys"
  else
    printf '%s\n' "$pubkey" >> "$auth_file"
    ok "Public key added to authorized_keys"
  fi

  chown -R "${AUDIT_USER}:${AUDIT_USER}" "$ssh_dir"
  ok "SSH permissions fixed for ${AUDIT_USER}"
}

restart_ssh_service() {
  [[ "${RESTART_SSH}" == "1" ]] || { warn "Skipping SSH service restart (RESTART_SSH=0)"; return; }

  if command -v systemctl > /dev/null 2>&1; then
    systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
    ok "SSH service restart attempted via systemd"
    return
  fi

  if command -v rc-service > /dev/null 2>&1; then
    rc-service sshd restart || true
    ok "SSH service restart attempted via OpenRC"
    return
  fi

  warn "No known service manager found; restart sshd manually"
}

main() {
  log "Setting up Linux SSH key access baseline"
  ensure_user
  install_authorized_key
  configure_sshd
  restart_ssh_service

  printf '\n[+] Completed SSH key access setup\n'
  printf '    User: %s\n' "$AUDIT_USER"
  printf '    Root login: disabled\n'
  if [[ "${DISABLE_PASSWORD_AUTH}" == "1" ]]; then
    printf '    PasswordAuthentication: no\n'
  else
    printf '    PasswordAuthentication: yes\n'
  fi
}

main "$@"
