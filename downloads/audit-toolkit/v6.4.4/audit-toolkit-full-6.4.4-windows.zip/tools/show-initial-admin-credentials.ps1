param(
    [string[]]$CandidatePaths = @(
        $env:INITIAL_ADMIN_CREDENTIALS_FILE,
        'C:\ProgramData\SecurityAuditToolkit\runtime\initial-admin-credentials.txt',
        'C:\ProgramData\SecurityAuditToolkit\runtime\FIRST-LOGIN.txt',
        '/var/lib/audit-toolkit/initial-admin-credentials.txt',
        '/etc/audit-toolkit/initial-admin-credentials.txt',
        '/opt/audit-toolkit/data/initial-admin-credentials.txt'
    )
)

$paths = $CandidatePaths | Where-Object { $_ -and $_.Trim() }
foreach ($path in $paths) {
    if (Test-Path $path) {
        Write-Output "FOUND: $path"
        Get-Content -Path $path -TotalCount 120
        exit 0
    }
}

Write-Warning 'No initial admin credentials file was found.'
Write-Output "If the first-login password has already been rotated, recover access with:`n  c:/Github/Audit-Tool-/.venv/Scripts/python.exe reset_admin_password.py --password 'ChangeMe123!' --must-change"
exit 1
