#!/usr/bin/env bash
set -euo pipefail

credential_paths=(
  "${INITIAL_ADMIN_CREDENTIALS_FILE:-}"
  "/var/lib/audit-toolkit/initial-admin-credentials.txt"
  "/etc/audit-toolkit/initial-admin-credentials.txt"
  "/opt/audit-toolkit/data/initial-admin-credentials.txt"
)

guide_paths=(
  "/opt/audit-toolkit/FIRST-LOGIN.txt"
  "/var/lib/audit-toolkit/FIRST-LOGIN.txt"
)

for path in "${credential_paths[@]}"; do
  [[ -n "$path" ]] || continue
  if [[ -f "$path" ]]; then
    echo "CREDENTIALS_FILE=$path"
    cat "$path"
    exit 0
  fi
done

for path in "${guide_paths[@]}"; do
  if [[ -f "$path" ]]; then
    echo "GUIDE_FILE=$path"
    sed -n '1,80p' "$path"
    echo
    echo "Credential file not found. If first-login has already been completed, use:"
    echo "  python3 /opt/audit-toolkit/reset_admin_password.py --password 'ChangeMe123!' --must-change"
    exit 2
  fi
done

echo "No initial admin credentials file was found." >&2
echo "If the first-login password has already been rotated, recover access with:" >&2
echo "  python3 /opt/audit-toolkit/reset_admin_password.py --password 'ChangeMe123!' --must-change" >&2
exit 1
