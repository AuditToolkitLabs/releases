#!/usr/bin/env python3
"""Lightweight Playwright smoke test for the reporting backfill panel."""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

project_root = Path(__file__).parent.parent
web_root = project_root / 'web'
sys.path.insert(0, str(web_root))
sys.path.insert(1, str(project_root))

from reporting_backfill_smoke_support import (
    clear_reporting_backfill_history,
    reset_admin_in_database,
    seed_reporting_backfill_history,
)


logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


def canonicalize_base_url(base_url: str) -> str:
    """Normalize loopback hostnames so browser auth stays on one origin."""
    parts = urlsplit(base_url)
    if parts.hostname != 'localhost':
        return base_url

    netloc = '127.0.0.1'
    if parts.port is not None:
        netloc = f'{netloc}:{parts.port}'
    if parts.username:
        credentials = parts.username
        if parts.password:
            credentials = f'{credentials}:{parts.password}'
        netloc = f'{credentials}@{netloc}'

    return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Run a Playwright smoke test for the reporting backfill panel.')
    parser.add_argument('--base-url', default=os.getenv('TOOLKIT_URL', 'http://localhost:5000'))
    parser.add_argument('--username', default=os.getenv('TOOLKIT_SMOKE_USERNAME', 'admin'))
    parser.add_argument('--password', default=os.getenv('TOOLKIT_SMOKE_PASSWORD', 'DemoScreenshots123!'))
    parser.add_argument(
        '--reset-admin',
        action='store_true',
        default=os.getenv('TOOLKIT_SMOKE_RESET_ADMIN', '').lower() in {'1', 'true', 'yes'},
        help='Reset the local admin account before running the smoke test.',
    )
    parser.add_argument(
        '--headful',
        action='store_true',
        help='Launch Chromium with a visible window for debugging.',
    )
    return parser


async def login_to_app(page, base_url: str, username: str, password: str) -> None:
    await page.goto(f'{base_url}/auth/login?force=1', wait_until='networkidle')

    username_selector = "input[name='username']"
    if not await page.query_selector(username_selector):
        username_selector = "input[type='text']"

    password_selector = "input[name='password']"
    if not await page.query_selector(password_selector):
        password_selector = "input[type='password']"

    await page.fill(username_selector, username)
    await page.fill(password_selector, password)

    for selector in ("button:has-text('Login')", "button:has-text('Sign In')", "button[type='submit']"):
        button = await page.query_selector(selector)
        if button:
            await button.click()
            break
    else:
        raise RuntimeError('Could not find a login button on the authentication page.')

    try:
        await page.wait_for_navigation(wait_until='networkidle', timeout=15000)
    except Exception:
        await page.wait_for_timeout(3000)

    if '/auth/accept-disclaimer' in page.url:
        await page.locator("input[type='checkbox']").check()
        await page.locator("button:has-text('I Accept - Continue to Application')").click()
        try:
            await page.wait_for_navigation(wait_until='networkidle', timeout=15000)
        except Exception:
            await page.wait_for_timeout(3000)

    for _ in range(40):
        if '/auth/login' not in page.url and '/login' not in page.url:
            break
        await page.wait_for_timeout(500)

    if '/auth/login' in page.url or '/login' in page.url:
        raise RuntimeError('Login failed; browser remained on the login page.')


async def ensure_authenticated(page, base_url: str, username: str, password: str) -> None:
    await page.goto(f'{base_url}/console', wait_until='networkidle')
    if '/auth/login' in page.url or '/login' in page.url or await page.query_selector("input[type='password']"):
        await login_to_app(page, base_url, username, password)
        await page.goto(f'{base_url}/console', wait_until='networkidle')


async def wait_for_history_request(page, trigger) -> str:
    async with page.expect_response(
        lambda response: '/api/reporting/backfill/history?' in response.url and response.request.method == 'GET',
        timeout=15000,
    ) as response_info:
        await trigger()
    response = await response_info.value
    return response.url


def console_frame(page):
    return page.frame_locator('iframe')


async def wait_for_console_toast(
    page,
    console_messages: list[tuple[str, str]],
    expected_message: str,
    expected_console_type: str,
    expected_label: str,
    timeout_ms: int = 2000,
) -> None:
    expected_log = f'[{expected_label.upper()}] {expected_message}'
    attempts = max(1, timeout_ms // 100)

    for _ in range(attempts):
        if any(message_type == expected_console_type and text == expected_log for message_type, text in console_messages):
            return
        await page.wait_for_timeout(100)

    raise RuntimeError(
        f'Expected toast console message not observed: type={expected_console_type!r} text={expected_log!r} '
        f'captured={console_messages!r}'
    )


async def verify_reports_backfill_panel(page) -> None:
    frame = console_frame(page)
    await frame.locator("button[data-tab='reports']").click()
    await frame.locator('#reporting-backfill-history').wait_for(timeout=15000)

    header_text = await frame.locator('.reports-backfill-header h3').text_content()
    if header_text != '🧱 Reporting Backfill':
        raise RuntimeError(f'Unexpected reporting backfill header: {header_text!r}')

    status_text = await frame.locator('#reporting-backfill-status').text_content()
    if not status_text:
        raise RuntimeError('Reporting backfill status element was empty.')


async def verify_seeded_history_card(page) -> None:
    frame = console_frame(page)
    card = frame.locator('.reports-backfill-history-card').filter(has_text='Audits: 12 processed').first
    await card.wait_for(timeout=15000)

    history_text = await card.text_content()
    required_fragments = [
        'Success',
        'Unknown time',
        'Audits: 12 processed',
        'Assessments: 4 processed',
        'Commit every: 7',
        'User ID: system',
        'Audit limit: 5',
        'Assessment limit: 3',
    ]

    for fragment in required_fragments:
        if fragment not in (history_text or ''):
            raise RuntimeError(f'Missing seeded history card text: {fragment!r}. Full card text: {history_text!r}')


async def verify_failure_history_card(page) -> None:
    frame = console_frame(page)
    filter_locator = frame.locator('#reporting-backfill-success-filter')
    request_url = await wait_for_history_request(page, lambda: filter_locator.select_option('false'))
    if 'success=false' not in request_url:
        raise RuntimeError(f'Expected failure filter in request URL, received: {request_url}')

    card = frame.locator('.reports-backfill-history-card.failure').first
    await card.wait_for(timeout=15000)
    history_text = await card.text_content()

    required_fragments = [
        'Failed',
        'Unknown time',
        'Audits: 1 processed',
        'Assessments: 0 processed',
        'Commit every: 9',
        'User ID: 41',
        'Audit limit: 2',
        'Assessment limit: 1',
        'seeded reporting backfill failure',
    ]

    for fragment in required_fragments:
        if fragment not in (history_text or ''):
            raise RuntimeError(f'Missing failure history card text: {fragment!r}. Full card text: {history_text!r}')


async def verify_filter_request(page) -> None:
    filter_locator = console_frame(page).locator('#reporting-backfill-success-filter')
    request_url = await wait_for_history_request(page, lambda: filter_locator.select_option('true'))
    if 'success=true' not in request_url:
        raise RuntimeError(f'Expected success filter in request URL, received: {request_url}')

    request_url = await wait_for_history_request(page, lambda: filter_locator.select_option(''))
    if 'success=' in request_url:
        raise RuntimeError(f'Expected cleared success filter in request URL, received: {request_url}')


async def verify_empty_history_state(page) -> None:
    if not clear_reporting_backfill_history(web_root / 'audit_tool.db'):
        raise RuntimeError('Could not clear reporting backfill history for empty-state validation.')

    frame = console_frame(page)
    filter_locator = frame.locator('#reporting-backfill-success-filter')
    await filter_locator.select_option('')

    refresh_button = frame.locator('#refresh-reporting-backfill')
    request_url = await wait_for_history_request(page, lambda: refresh_button.click())
    if 'success=' in request_url:
        raise RuntimeError(f'Expected empty-state refresh without success filter, received: {request_url}')

    empty_state = frame.locator('.reports-empty-state').filter(has_text='No Matching Backfill Runs').first
    await empty_state.wait_for(timeout=15000)
    empty_text = await empty_state.text_content()
    status_text = await frame.locator('#reporting-backfill-status').text_content()

    if 'Adjust the filter or trigger a manual backfill to populate this list.' not in (empty_text or ''):
        raise RuntimeError(f'Unexpected empty-state content: {empty_text!r}')

    expected_status = 'No manual reporting backfill runs found for the current filter.'
    if expected_status not in (status_text or ''):
        raise RuntimeError(f'Unexpected empty-state status text: {status_text!r}')


async def verify_history_unavailable_state(page, console_messages: list[tuple[str, str]]) -> None:
    frame = console_frame(page)
    expected_error = 'seeded reporting history unavailable'
    expected_status = f'Unable to load reporting backfill history: {expected_error}'

    async def fulfill_history_error(route):
        await route.fulfill(
            status=500,
            content_type='application/json',
            body=(
                '{"success":false,'
                '"error":"seeded reporting history unavailable"}'
            ),
        )

    await page.route('**/api/reporting/backfill/history?*', fulfill_history_error)
    try:
        refresh_button = frame.locator('#refresh-reporting-backfill')
        request_url = await wait_for_history_request(page, lambda: refresh_button.click())
        if 'limit=10' not in request_url:
            raise RuntimeError(f'Expected unavailable-state refresh with default limit, received: {request_url}')

        unavailable_state = frame.locator('.reports-empty-state').filter(has_text='History Unavailable').first
        await unavailable_state.wait_for(timeout=15000)
        unavailable_text = await unavailable_state.text_content()
        status_text = await frame.locator('#reporting-backfill-status').text_content()

        if expected_error not in (unavailable_text or ''):
            raise RuntimeError(f'Unexpected unavailable-state content: {unavailable_text!r}')

        if expected_status not in (status_text or ''):
            raise RuntimeError(f'Unexpected unavailable-state status text: {status_text!r}')

        await wait_for_console_toast(page, console_messages, expected_status, 'error', 'error')
    finally:
        await page.unroute('**/api/reporting/backfill/history?*', fulfill_history_error)


async def verify_refresh_request(page) -> None:
    refresh_button = console_frame(page).locator('#refresh-reporting-backfill')
    request_url = await wait_for_history_request(page, lambda: refresh_button.click())
    if 'limit=10' not in request_url:
        raise RuntimeError(f'Expected default limit in refresh request URL, received: {request_url}')


async def verify_cancelled_backfill(page, console_messages: list[tuple[str, str]]) -> None:
    frame = console_frame(page)
    run_button = frame.locator('#run-reporting-backfill')

    async def dismiss_dialog(dialog):
        await dialog.dismiss()

    page.once('dialog', dismiss_dialog)
    await run_button.click()
    await page.wait_for_timeout(300)

    status_text = await frame.locator('#reporting-backfill-status').text_content()
    if 'cancelled' not in (status_text or '').lower():
        raise RuntimeError(f'Expected cancelled backfill status, received: {status_text!r}')

    await wait_for_console_toast(page, console_messages, 'Reporting backfill cancelled.', 'log', 'info')


async def run_smoke_test(args: argparse.Namespace) -> None:
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:
        raise RuntimeError('Playwright is not installed. Install it with: pip install playwright && playwright install chromium') from exc

    if args.reset_admin and not reset_admin_in_database(web_root / 'audit_tool.db', args.username, args.password):
        raise RuntimeError('Admin reset requested but could not be completed.')
    if not seed_reporting_backfill_history(web_root / 'audit_tool.db'):
        raise RuntimeError('Could not seed reporting backfill history for smoke test.')

    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=not args.headful)
        context = await browser.new_context(viewport={'width': 1600, 'height': 1000}, ignore_https_errors=True)
        page = await context.new_page()
        page.set_default_timeout(20000)
        console_messages: list[tuple[str, str]] = []
        page.on('console', lambda message: console_messages.append((message.type, message.text)))

        try:
            await ensure_authenticated(page, args.base_url, args.username, args.password)
            await verify_reports_backfill_panel(page)
            await verify_seeded_history_card(page)
            await verify_failure_history_card(page)
            await verify_filter_request(page)
            await verify_refresh_request(page)
            await verify_empty_history_state(page)
            await verify_history_unavailable_state(page, console_messages)
            await verify_cancelled_backfill(page, console_messages)
            logger.info('Reporting backfill smoke test passed.')
        finally:
            await context.close()
            await browser.close()


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    args.base_url = canonicalize_base_url(args.base_url)

    try:
        asyncio.run(run_smoke_test(args))
        return 0
    except Exception as exc:
        logger.error('Reporting backfill smoke test failed: %s', exc)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
