[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$FilePath,

    [Parameter()]
    [int]$PartSizeMB = 1900,

    [Parameter()]
    [string]$OutputDirectory = '',

    [Parameter()]
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok { param([string]$Message) Write-Host "[OK] $Message" -ForegroundColor Green }

$resolvedPath = Resolve-Path -Path $FilePath -ErrorAction Stop
$fullPath = $resolvedPath.Path
$file = Get-Item -LiteralPath $fullPath

if ($PartSizeMB -lt 50) {
    throw "PartSizeMB must be >= 50"
}

$partSizeBytes = [int64]$PartSizeMB * 1MB
$baseDir = if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    Split-Path -Parent $fullPath
}
else {
    $resolvedOutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
    if (-not (Test-Path -LiteralPath $resolvedOutputDirectory)) {
        $null = New-Item -ItemType Directory -Path $resolvedOutputDirectory -Force
    }
    $resolvedOutputDirectory
}

$baseDir = (Resolve-Path -Path $baseDir).Path
$baseName = $file.Name
$manifestPath = Join-Path $baseDir "$baseName.parts.json"

if ($file.Length -le $partSizeBytes) {
    Write-Ok "File size is <= part size; no split required: $baseName"
    Write-Output "SPLIT:SKIP=TRUE;FILE=$baseName;SIZE_BYTES=$($file.Length)"
    exit 0
}

$existingParts = Get-ChildItem -Path $baseDir -Filter "$baseName.part*" -File -ErrorAction SilentlyContinue
if ($existingParts -and -not $Force) {
    throw "Existing part files found for '$baseName'. Use -Force to overwrite."
}

if ($Force) {
    foreach ($part in $existingParts) {
        Remove-Item -LiteralPath $part.FullName -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path $manifestPath) {
        Remove-Item -LiteralPath $manifestPath -Force -ErrorAction SilentlyContinue
    }
}

Write-Step "Splitting $baseName into ~${PartSizeMB}MB parts"

$bufferSize = 4MB
$buffer = New-Object byte[] $bufferSize
$partIndex = 1
$partNames = New-Object System.Collections.Generic.List[string]

$inputStream = [System.IO.File]::Open($fullPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
try {
    while ($inputStream.Position -lt $inputStream.Length) {
        $partName = "{0}.part{1:D3}" -f $baseName, $partIndex
        $partPath = Join-Path $baseDir $partName
        $partNames.Add($partName) | Out-Null

        $remainingInPart = $partSizeBytes
        $partStream = [System.IO.File]::Open($partPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            while ($remainingInPart -gt 0 -and $inputStream.Position -lt $inputStream.Length) {
                $chunk = [int][Math]::Min($bufferSize, $remainingInPart)
                $read = $inputStream.Read($buffer, 0, $chunk)
                if ($read -le 0) { break }
                $partStream.Write($buffer, 0, $read)
                $remainingInPart -= $read
            }
        }
        finally {
            $partStream.Dispose()
        }

        $partSize = (Get-Item -LiteralPath $partPath).Length
        Write-Ok "Created $partName ($([math]::Round($partSize / 1MB, 2)) MB)"
        $partIndex++
    }
}
finally {
    $inputStream.Dispose()
}

$fileHash = (Get-FileHash -Path $fullPath -Algorithm SHA256).Hash
$partsInfo = foreach ($p in $partNames) {
    $partPath = Join-Path $baseDir $p
    $partItem = Get-Item -LiteralPath $partPath
    [PSCustomObject]@{
        name = $p
        size_bytes = [int64]$partItem.Length
        sha256 = (Get-FileHash -Path $partPath -Algorithm SHA256).Hash
    }
}

$manifest = [PSCustomObject]@{
    source_file = $baseName
    source_size_bytes = [int64]$file.Length
    source_sha256 = $fileHash
    part_size_mb = $PartSizeMB
    total_parts = $partNames.Count
    created_utc = (Get-Date).ToUniversalTime().ToString('o')
    join_hint = "cat '$baseName.part*' > '$baseName'"
    join_hint_windows = "Get-Content '$baseName.part*' -AsByteStream | Set-Content '$baseName' -AsByteStream"
    parts = $partsInfo
}

$manifest | ConvertTo-Json -Depth 6 | Set-Content -Path $manifestPath -Encoding UTF8
Write-Ok "Manifest written: $(Split-Path -Leaf $manifestPath)"
Write-Output "SPLIT:RESULT=PASS;FILE=$baseName;PARTS=$($partNames.Count);MANIFEST=$(Split-Path -Leaf $manifestPath)"

