#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter()]
    [string]$RepoRoot = '',

    [Parameter()]
    [string]$Version = '',

    [Parameter()]
    [string]$OutputDir = '',

    [Parameter()]
    [switch]$Clean,

    [Parameter()]
    [switch]$SkipValidation,

    [Parameter()]
    [switch]$ForceRestart
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

$resolvedRepoRoot = if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
}
else {
    (Resolve-Path -LiteralPath $RepoRoot).Path
}

$workerScript = Join-Path $resolvedRepoRoot 'tools\run-msi-build-detached.ps1'
if (-not (Test-Path -LiteralPath $workerScript)) {
    throw "Missing detached MSI wrapper: $workerScript"
}

$workerArgs = @(
    '-NoLogo',
    '-NoProfile',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    $workerScript,
    '-Mode',
    'Start',
    '-RepoRoot',
    $resolvedRepoRoot,
    '-RequireAdmin'
)

if (-not [string]::IsNullOrWhiteSpace($Version)) {
    $workerArgs += @('-Version', $Version)
}
if (-not [string]::IsNullOrWhiteSpace($OutputDir)) {
    $workerArgs += @('-OutputDir', $OutputDir)
}
if ($Clean) {
    $workerArgs += '-Clean'
}
if ($SkipValidation) {
    $workerArgs += '-SkipValidation'
}
if ($ForceRestart) {
    $workerArgs += '-ForceRestart'
}

if (-not (Get-IsAdministrator)) {
    Write-Output 'Relaunching elevated MSI build starter...'
    $proc = Start-Process -FilePath 'pwsh' -ArgumentList $workerArgs -WorkingDirectory $resolvedRepoRoot -Verb RunAs -PassThru
    Write-Output "Started elevated launcher PID=$($proc.Id)"
    exit 0
}

& 'pwsh' @workerArgs
exit $LASTEXITCODE