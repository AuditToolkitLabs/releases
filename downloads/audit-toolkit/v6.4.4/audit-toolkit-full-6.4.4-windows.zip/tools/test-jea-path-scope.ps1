[CmdletBinding()]
param(
    [string]$SetupScriptPath = "C:\Github\Audit-Tool-\agents\html-standalone\jea\setup-jea.ps1",
    [string]$EndpointName = "AuditAgent.JEA.PathScope.Test",
    [string]$AgentRoot = "C:\ProgramData\AuditAgent\jea-pathscope-test",
    [string]$AdminGroup = "Administrators",
    [string]$ReadOnlyGroup = "Users"
)

$ErrorActionPreference = 'Stop'

function Write-Marker {
    param([string]$Name, [string]$Value)
    Write-Output "$Name=$Value"
}

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Marker -Name 'JEA_TEST' -Value 'SKIP_NOT_ADMIN'
    exit 0
}

if (-not (Test-Path $SetupScriptPath)) {
    Write-Marker -Name 'JEA_TEST' -Value 'FAIL_SETUP_SCRIPT_MISSING'
    exit 1
}

$installPath = Join-Path $AgentRoot 'jea'
$transcriptPath = Join-Path $AgentRoot 'logs\jea-transcripts'
$auditDir = Join-Path $AgentRoot 'audits\platform\baseline'
$fleetAgentPath = Join-Path $AgentRoot 'fleet-agent.ps1'
$testAuditPath = Join-Path $auditDir 'test-jea-audit.ps1'

New-Item -Path $auditDir -ItemType Directory -Force | Out-Null
@'
param()
"TEST_JEA_AUDIT_OK"
'@ | Set-Content -Path $testAuditPath -Encoding UTF8

@'
param(
    [string]$Mode
)
if ($Mode -eq 'discovery' -or $Mode -eq '--discovery') {
    "TEST_JEA_DISCOVERY_OK"
} else {
    "TEST_JEA_DISCOVERY_MODE_INVALID"
}
'@ | Set-Content -Path $fleetAgentPath -Encoding UTF8

$endpointRegistered = $false

try {
    & $SetupScriptPath `
        -InstallPath $installPath `
        -EndpointName $EndpointName `
        -AdminGroup $AdminGroup `
        -ReadOnlyGroup $ReadOnlyGroup `
        -TranscriptPath $transcriptPath `
        -AgentRootPath $AgentRoot

    $endpointRegistered = $true

    $session = New-PSSession -ComputerName localhost -ConfigurationName $EndpointName
    try {
        $scope = Invoke-Command -Session $session -ScriptBlock { Get-AuditAgentScope }
        if ($scope.AgentRoot -eq $AgentRoot) {
            Write-Marker -Name 'JEA_SCOPE_ROOT' -Value 'PASS'
        } else {
            Write-Marker -Name 'JEA_SCOPE_ROOT' -Value 'FAIL'
        }

        $auditResult = Invoke-Command -Session $session -ScriptBlock {
            Invoke-AuditScript -ScriptPath 'audits\platform\baseline\test-jea-audit.ps1'
        }
        if (($auditResult | Out-String) -match 'TEST_JEA_AUDIT_OK') {
            Write-Marker -Name 'JEA_AUDIT_PATH_EXEC' -Value 'PASS'
        } else {
            Write-Marker -Name 'JEA_AUDIT_PATH_EXEC' -Value 'FAIL'
        }

        try {
            Invoke-Command -Session $session -ScriptBlock {
                Invoke-AuditScript -ScriptPath '..\Windows\System32\cmd.exe'
            } | Out-Null
            Write-Marker -Name 'JEA_PATH_ESCAPE_DENY' -Value 'FAIL'
        }
        catch {
            Write-Marker -Name 'JEA_PATH_ESCAPE_DENY' -Value 'PASS'
        }

        try {
            Invoke-Command -Session $session -ScriptBlock { Get-Service | Select-Object -First 1 } | Out-Null
            Write-Marker -Name 'JEA_DIRECT_CMD_DENY' -Value 'FAIL'
        }
        catch {
            Write-Marker -Name 'JEA_DIRECT_CMD_DENY' -Value 'PASS'
        }

        $discResult = Invoke-Command -Session $session -ScriptBlock { Invoke-DiscoveryScript -Mode 'discovery' }
        if (($discResult | Out-String) -match 'TEST_JEA_DISCOVERY_OK') {
            Write-Marker -Name 'JEA_DISCOVERY_PATH_EXEC' -Value 'PASS'
        } else {
            Write-Marker -Name 'JEA_DISCOVERY_PATH_EXEC' -Value 'FAIL'
        }

        Write-Marker -Name 'JEA_TEST_RESULT' -Value 'PASS'
    }
    finally {
        if ($session) {
            Remove-PSSession $session -ErrorAction SilentlyContinue
        }
    }
}
catch {
    Write-Marker -Name 'JEA_TEST_RESULT' -Value 'FAIL'
    Write-Marker -Name 'JEA_TEST_ERROR' -Value ($_.Exception.Message -replace '\s+', ' ')
    exit 1
}
finally {
    if ($endpointRegistered) {
        Unregister-PSSessionConfiguration -Name $EndpointName -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -Path $AgentRoot -Recurse -Force -ErrorAction SilentlyContinue
}
