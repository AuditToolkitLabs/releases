import json
import sys
sys.path.insert(0, r'c:/Github/Audit-Tool-/tools/asset-discovery')
from src.services.remote_executor import SSHExecutor, Credentials

ex = SSHExecutor()
creds = Credentials(username='audit_user', password='TestPass123!', auth_method='password')

commands = []
commands.append("hostname && cat /etc/os-release 2>/dev/null || true")
commands.append("""
    if command -v dpkg >/dev/null 2>&1; then
        dpkg-query -W -f='${Package}|${Version}|${Status}\\n' 2>/dev/null | grep 'install ok installed' | head -100
    elif command -v rpm >/dev/null 2>&1; then
        rpm -qa --queryformat '%{NAME}|%{VERSION}-%{RELEASE}|installed\\n' 2>/dev/null | head -100
    elif command -v apk >/dev/null 2>&1; then
        apk list --installed 2>/dev/null | head -100
    fi
""")
commands.append("""
    if command -v systemctl >/dev/null 2>&1; then
        systemctl list-units --type=service --no-legend --no-pager 2>/dev/null | head -50
    elif command -v rc-service >/dev/null 2>&1; then
        rc-service --list 2>/dev/null | head -50
    fi
""")

combined = " && echo '---SEPARATOR---' && ".join(commands)
exec_result = ex.execute_command('192.168.100.30', 22, creds, combined, timeout=90)
sections = exec_result.stdout.split('---SEPARATOR---') if exec_result.stdout else []
out = {
    'exec_success': exec_result.success,
    'exec_return_code': exec_result.return_code,
    'exec_error': exec_result.error,
    'stderr_head': (exec_result.stderr or '')[:400],
    'section_count': len(sections),
    'section_lengths': [len(s.strip().splitlines()) for s in sections],
    'packages_preview': sections[1].strip().splitlines()[:10] if len(sections) > 1 else [],
    'services_preview': sections[2].strip().splitlines()[:10] if len(sections) > 2 else [],
}
print(json.dumps(out, default=str))