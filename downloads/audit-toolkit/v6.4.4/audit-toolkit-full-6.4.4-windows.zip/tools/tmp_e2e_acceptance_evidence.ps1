[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPositionalParameters', '', Justification='Positional usage is intentional in stabilized scripts; named-argument refactors deferred to avoid behavior drift')]
$ErrorActionPreference='Stop'
$h=@{'X-API-Key'='dev-api-key'}
function Get-Json($u){ Invoke-RestMethod -Method Get -Uri $u -Headers $h }
function Invoke-JsonPost($u,$b){ Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType 'application/json' -Body ($b|ConvertTo-Json -Depth 10) }
function Invoke-JsonPostRetry($u,$b,[int]$max=5){
  for($i=1;$i -le $max;$i++){
    try { return Invoke-JsonPost $u $b }
    catch {
      $msg=$_.Exception.Message
      if($msg -match '429' -and $i -lt $max){ Start-Sleep -Seconds (5*$i); continue }
      throw
    }
  }
}

$beforeStats=Get-Json 'http://localhost:8080/api/v1/vulnerabilities/stats'
$assets=Get-Json 'http://localhost:8080/api/v1/assets?per_page=50'
$target=$assets.assets | Where-Object { $_.vulnerability_details_url } | Select-Object -First 1
if(-not $target){ throw 'No asset with vulnerability drilldown URL found' }
$assetId=$target.id
$beforeHost=Get-Json ("http://localhost:8080/api/v1/vulnerabilities/assets/{0}?status=open&per_page=5" -f $assetId)

$scanPayload=@{
  job_type='discovery'
  name=('copilot-evidence-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  targets=@('127.0.0.1')
  os_type='auto'
  discovery_mode='unauthenticated'
  discovery_method='ssh'
  credentials=@{ username='x'; auth_method='password'; password='x'; port=22 }
  scope=@{ packages=$true; services=$true; updates=$true; ports=$true; users=$false; security=$false }
  schedule='now'
  schedule_time=$null
}
$created=Invoke-JsonPost 'http://localhost:8080/api/v1/scans' $scanPayload
$scanId=$created.id
$started=Invoke-JsonPost ("http://localhost:8080/api/v1/scans/{0}/start" -f $scanId) @{}

$deadline=(Get-Date).AddMinutes(3)
$history=@()
$status='queued'
while((Get-Date) -lt $deadline){
  $p=Get-Json ("http://localhost:8080/api/v1/scans/{0}/progress" -f $scanId)
  $history += [pscustomobject]@{ t=(Get-Date).ToString('s'); status=$p.status; correlation=$p.vulnerability_correlation }
  $status=$p.status
  if($status -in @('completed','failed','cancelled')){ break }
  Start-Sleep -Seconds 2
}
$results=Get-Json ("http://localhost:8080/api/v1/scans/{0}/results" -f $scanId)

$sync=Invoke-JsonPostRetry -u 'http://localhost:8080/api/v1/vulnerabilities/sync' -b @{ days_back=1; rematch_after_sync=$true } -max 6

$afterStats=Get-Json 'http://localhost:8080/api/v1/vulnerabilities/stats'
$afterHost=Get-Json ("http://localhost:8080/api/v1/vulnerabilities/assets/{0}?status=open&refresh=true&per_page=5" -f $assetId)

$sample=$null
if($afterHost.vulnerabilities -and $afterHost.vulnerabilities.Count -gt 0){ $sample=$afterHost.vulnerabilities[0] }

$report=[pscustomobject]@{
  timestamp=(Get-Date).ToString('s')
  asset_id=$assetId
  before=@{
    global_total=$beforeStats.total_open_vulnerabilities
    host_total=$beforeHost.total_vulnerabilities
    host_summary=$beforeHost.summary
  }
  scan=@{
    id=$scanId
    create_status=$created.status
    start_status=$started.status
    final_status=$status
    results_count=(($results.results|Measure-Object).Count)
    progress_correlation_history=$history
    results_correlation=$results.vulnerability_correlation
  }
  sync=@{
    status=$sync.status
    cve_updates=$sync.cve_updates
    vulnerability_correlation=$sync.vulnerability_correlation
    rematch_total_assets=$sync.rematch_total_assets
    rematch_processed_assets=$sync.rematch_processed_assets
    rematch_failed_assets=$sync.rematch_failed_assets
  }
  after=@{
    global_total=$afterStats.total_open_vulnerabilities
    host_total=$afterHost.total_vulnerabilities
    host_summary=$afterHost.summary
    detail_fields_present=@{
      description=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'description')
      published_date=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'published_date')
      cvss_v3_score=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_score')
      cvss_v3_severity=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_severity')
      cvss_v3_vector=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_vector')
    }
    sample=$sample
  }
}
$report | ConvertTo-Json -Depth 12
