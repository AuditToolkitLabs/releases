$ErrorActionPreference='Stop'
$h=@{'X-API-Key'='dev-api-key'}
function Get-Json($u){ Invoke-RestMethod -Method Get -Uri $u -Headers $h }
function Invoke-JsonPost($u,$b){ Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType 'application/json' -Body ($b|ConvertTo-Json -Depth 10) }

$assets=Get-Json 'http://localhost:8080/api/v1/assets?per_page=50'
$pick=$null
foreach($a in $assets.assets){
  try {
    $v=Get-Json ("http://localhost:8080/api/v1/vulnerabilities/assets/{0}?status=open&per_page=1" -f $a.id)
    if([int]$v.total_vulnerabilities -gt 0){ $pick=[pscustomobject]@{id=$a.id; ip=$a.primary_ip; total=$v.total_vulnerabilities; summary=$v.summary}; break }
  } catch { Write-Verbose 'Suppressed non-fatal error.' }
}
if(-not $pick){ throw 'No host with open vulnerabilities found' }

$before=Get-Json ("http://localhost:8080/api/v1/vulnerabilities/assets/{0}?status=open&per_page=5" -f $pick.id)

$sync=$null
for($i=1;$i -le 6;$i++){
  try {
    $sync=Invoke-JsonPost 'http://localhost:8080/api/v1/vulnerabilities/sync' @{ days_back=1; rematch_after_sync=$true }
    break
  } catch {
    if($_.Exception.Message -match '429' -and $i -lt 6){ Start-Sleep -Seconds (5*$i) } else { throw }
  }
}

$after=Get-Json ("http://localhost:8080/api/v1/vulnerabilities/assets/{0}?status=open&refresh=true&per_page=5" -f $pick.id)
$sample=$null
if($after.vulnerabilities -and $after.vulnerabilities.Count -gt 0){ $sample=$after.vulnerabilities[0] }

[pscustomobject]@{
  asset=$pick
  before_total=$before.total_vulnerabilities
  after_total=$after.total_vulnerabilities
  before_summary=$before.summary
  after_summary=$after.summary
  sync_correlation=$sync.vulnerability_correlation
  detail_fields_present=@{
    description=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'description')
    published_date=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'published_date')
    cvss_v3_score=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_score')
    cvss_v3_severity=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_severity')
    cvss_v3_vector=($null -ne $sample -and $sample.PSObject.Properties.Name -contains 'cvss_v3_vector')
  }
  sample=$sample
} | ConvertTo-Json -Depth 10
