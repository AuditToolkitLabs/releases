import json
import time
import requests

base = 'http://localhost:8080'
headers = {}

def req(method, path, body=None, timeout=60):
    global headers
    r = requests.request(method, base + path, headers=headers, json=body, timeout=timeout)
    if r.status_code == 401 and 'X-API-Key' not in headers:
        headers['X-API-Key'] = 'dev-api-key'
        r = requests.request(method, base + path, headers=headers, json=body, timeout=timeout)
    r.raise_for_status()
    return r.json() if r.text.strip() else {}

for _ in range(40):
    try:
        if requests.get(base + '/health', timeout=5).status_code == 200:
            break
    except Exception:
        pass
    time.sleep(1)

payload = {
    'job_type': 'discovery',
    'name': 'copilot-linux-inventory-check-20260301',
    'os_type': 'linux',
    'discovery_mode': 'authenticated',
    'discovery_method': 'ssh',
    'targets': ['192.168.100.30', '192.168.100.31', '192.168.100.32'],
    'credentials': {
        'username': 'audit_user',
        'auth_method': 'password',
        'password': 'TestPass123!',
        'port': 22
    },
    'scope': {
        'packages': True,
        'services': True,
        'updates': True,
        'ports': True,
        'users': False,
        'security': False
    },
    'schedule': 'now',
    'schedule_time': None
}

created = req('POST', '/api/v1/scans', payload)
sid = created['id']
req('POST', f'/api/v1/scans/{sid}/start')

status = 'pending'
for _ in range(200):
    time.sleep(2)
    p = req('GET', f'/api/v1/scans/{sid}/progress')
    status = p.get('status', 'unknown')
    if status in ('completed', 'failed', 'cancelled'):
        break

scan_row = next((s for s in req('GET', '/api/v1/scans').get('scans', []) if s.get('id') == sid), {})
results = req('GET', f'/api/v1/scans/{sid}/results').get('results', [])

assets = req('GET', '/api/v1/assets?per_page=100').get('assets', [])
ips = {'192.168.100.30', '192.168.100.31', '192.168.100.32', '192.168.100.20', '192.168.100.21'}
selected = [a for a in assets if a.get('primary_ip') in ips]

detail = []
for a in selected:
    aid = a['id']
    sw = req('GET', f'/api/v1/assets/{aid}/software').get('software', [])
    vuln = req('GET', f'/api/v1/vulnerabilities/assets/{aid}')
    detail.append({
        'asset_id': aid,
        'hostname': a.get('hostname'),
        'ip': a.get('primary_ip'),
        'os_type': a.get('os_type'),
        'software_count': len(sw),
        'software_sample': sw[:8],
        'total_vulnerabilities': vuln.get('total_vulnerabilities'),
        'vulnerability_summary': vuln.get('summary')
    })

out = {
    'scan_id': sid,
    'scan_status': scan_row.get('status', status),
    'successful_targets': scan_row.get('successful_targets'),
    'failed_targets': scan_row.get('failed_targets'),
    'scan_results': results,
    'assets_snapshot': detail,
    'api_key_used': 'X-API-Key' in headers
}
print(json.dumps(out))