$ErrorActionPreference = 'Stop'

$base = 'http://localhost:8080'
$headers = @{ 'X-API-Key' = 'dev-api-key' }

$health = Invoke-WebRequest -Uri "$base/health" -UseBasicParsing -TimeoutSec 15
if ($health.StatusCode -ne 200) {
    throw "Health check failed: $($health.StatusCode)"
}

$scanName = "copilot-rematch-e2e-" + (Get-Date -Format 'yyyyMMdd-HHmmss')
$payload = @{
    job_type = 'discovery'
    name = $scanName
    os_type = 'linux'
    discovery_mode = 'authenticated'
    discovery_method = 'ssh'
    targets = @('192.168.100.30', '192.168.100.31', '192.168.100.32')
    credentials = @{
        username = 'audit_user'
        auth_method = 'password'
        password = 'TestPass123!'
        port = 22
    }
    scope = @{
        packages = $true
        services = $true
        updates = $true
        ports = $true
        users = $false
        security = $false
    }
    schedule = 'now'
    schedule_time = $null
} | ConvertTo-Json -Depth 8

$created = Invoke-RestMethod -Method Post -Uri "$base/api/v1/scans" -Headers $headers -ContentType 'application/json' -Body $payload
$scanId = $created.id
if (-not $scanId) {
    throw 'Scan creation did not return id'
}

$null = Invoke-RestMethod -Method Post -Uri "$base/api/v1/scans/$scanId/start" -Headers $headers -TimeoutSec 30

$status = 'pending'
$progressSnapshots = @()
for ($i = 0; $i -lt 120; $i++) {
    Start-Sleep -Seconds 2
    $p = Invoke-RestMethod -Method Get -Uri "$base/api/v1/scans/$scanId/progress" -Headers $headers -TimeoutSec 30
    $status = $p.status
    $progressSnapshots += [pscustomobject]@{
        t = (Get-Date).ToString('o')
        status = $p.status
        successful_targets = $p.successful_targets
        failed_targets = $p.failed_targets
        total_targets = $p.total_targets
        percent_complete = if ($p.live) { $p.live.percent_complete } else { $null }
    }
    if ($status -in @('completed', 'failed', 'cancelled')) {
        break
    }
}

$results = Invoke-RestMethod -Method Get -Uri "$base/api/v1/scans/$scanId/results" -Headers $headers -TimeoutSec 60
$assetIds = @($results.results | Where-Object { $_.asset_id } | ForEach-Object { [int]$_.asset_id } | Select-Object -Unique)

$firstRead = @()
foreach ($aid in $assetIds) {
    $v = Invoke-RestMethod -Method Get -Uri "$base/api/v1/vulnerabilities/assets/$aid" -Headers $headers -TimeoutSec 60
    $firstRead += [pscustomobject]@{
        asset_id = $aid
        total_vulnerabilities = $v.total_vulnerabilities
        critical = if ($v.summary) { $v.summary.critical } else { $null }
        high = if ($v.summary) { $v.summary.high } else { $null }
    }
}

$stableRead = $firstRead
for ($j = 0; $j -lt 6; $j++) {
    Start-Sleep -Seconds 5
    $tmp = @()
    foreach ($aid in $assetIds) {
        $v = Invoke-RestMethod -Method Get -Uri "$base/api/v1/vulnerabilities/assets/$aid" -Headers $headers -TimeoutSec 60
        $tmp += [pscustomobject]@{
            asset_id = $aid
            total_vulnerabilities = $v.total_vulnerabilities
            critical = if ($v.summary) { $v.summary.critical } else { $null }
            high = if ($v.summary) { $v.summary.high } else { $null }
        }
    }
    $stableRead = $tmp
}

$summary = [pscustomobject]@{
    scan_name = $scanName
    scan_id = $scanId
    final_status = $status
    target_result_count = @($results.results).Count
    asset_ids = $assetIds
    immediate_vulnerability_read = $firstRead
    post_30s_vulnerability_read = $stableRead
    progress_tail = @($progressSnapshots | Select-Object -Last 5)
}

$summary | ConvertTo-Json -Depth 8
