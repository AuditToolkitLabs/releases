param(
    [string]$CoreUrl = 'http://localhost:5000',
    [switch]$SkipDocker
)

$ErrorActionPreference = 'Stop'

$core = $CoreUrl

function Test-DockerAvailable {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        return $false
    }

    try {
        docker version | Out-Null
        return $true
    } catch {
        return $false
    }
}

function Get-AuthContext {
    $ws = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $maxAttempts = 5

    for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
        try {
            Invoke-WebRequest -Method Post -Uri "$core/auth/login" -WebSession $ws -ContentType 'application/json' -Body (@{username='admin';password='ChangeMe123!'} | ConvertTo-Json) -TimeoutSec 20 | Out-Null
            $apiKey = (Invoke-RestMethod -Method Get -Uri "$core/api/settings/api-key" -WebSession $ws -TimeoutSec 20).api_key
            if (-not $apiKey) { throw 'No API key returned after login' }
            return @{ Session = $ws; Headers = @{ 'X-API-Key' = $apiKey } }
        } catch {
            if ($attempt -eq $maxAttempts) {
                throw
            }

            Start-Sleep -Seconds ([Math]::Min(5 * $attempt, 20))
        }
    }
}

function Test-EndpointHealth {
    param(
        [string]$Url,
        [hashtable]$Headers,
        $Session
    )
    try {
        $r = Invoke-WebRequest -Method Head -Uri $Url -Headers $Headers -WebSession $Session -TimeoutSec 20
        [pscustomobject]@{ url = $Url; code = [int]$r.StatusCode; ok = $true; note = 'HEAD' }
    } catch {
        if ($_.Exception.Response) {
            $code = [int]$_.Exception.Response.StatusCode.value__
            if ($code -eq 405) {
                try {
                    $h = @{}
                    $Headers.GetEnumerator() | ForEach-Object { $h[$_.Key] = $_.Value }
                    $h['Range'] = 'bytes=0-0'
                    $r2 = Invoke-WebRequest -Uri $Url -Headers $h -WebSession $Session -TimeoutSec 20
                    return [pscustomobject]@{ url = $Url; code = [int]$r2.StatusCode; ok = $true; note = 'GET range' }
                } catch {
                    if ($_.Exception.Response) {
                        return [pscustomobject]@{ url = $Url; code = [int]$_.Exception.Response.StatusCode.value__; ok = $false; note = 'GET range failed' }
                    }
                    return [pscustomobject]@{ url = $Url; code = -1; ok = $false; note = 'GET range exception' }
                }
            }
            return [pscustomobject]@{ url = $Url; code = $code; ok = $false; note = 'HEAD failed' }
        }
        return [pscustomobject]@{ url = $Url; code = -1; ok = $false; note = 'No HTTP response' }
    }
}

$ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$results = [ordered]@{}

# MA-01 + MA-03
$ctx = Get-AuthContext
$ws = $ctx.Session
$h = $ctx.Headers
$maUrls = @(
    "$core/api/managed-agent/install.sh",
    "$core/api/managed-agent/install.ps1",
    "$core/api/agents/unified-health",
    "$core/api/agents/stats"
)
$results['MA01'] = foreach ($u in $maUrls) { Test-EndpointHealth -Url $u -Headers $h -Session $ws }

$managedBody = @{
    agent_id = 'managed-smoke-001'
    hostname = 'managed-smoke-host'
    results = @(
        @{
            audit_name = 'smoke-audit'
            status = 'success'
            summary = @{ pass = 1; fail = 0; warn = 0; skip = 0 }
            checks = @(@{ name = 'smoke'; status = 'PASS'; message = 'ok' })
        }
    )
} | ConvertTo-Json -Depth 10
try {
    $ing = Invoke-RestMethod -Method Post -Uri "$core/api/agent/managed/results/ingest" -Headers $h -WebSession $ws -ContentType 'application/json' -Body $managedBody -TimeoutSec 20
    $hist = Invoke-RestMethod -Method Get -Uri "$core/api/audits/history" -Headers $h -WebSession $ws -TimeoutSec 20
    $results['MA03'] = [pscustomobject]@{
        ingest_success = [bool]$ing.success
        history_count = @($hist).Count
    }
} catch {
    $results['MA03'] = [pscustomobject]@{ error = $_.Exception.Message }
}

# MA-02
try {
    pwsh .\tools\capture_scenario56_evidence.ps1 -Timestamp $ts | Out-Null
    $results['MA02'] = [pscustomobject]@{ ran = $true; timestamp = $ts }
} catch {
    $results['MA02'] = [pscustomobject]@{ ran = $false; error = $_.Exception.Message }
}

# SA-01
$ctx2 = Get-AuthContext
$ws2 = $ctx2.Session
$h2 = $ctx2.Headers
$saUrls = @(
    "$core/api/agent/download/linux?format=raw",
    "$core/api/agent/download/windows?format=raw",
    "$core/api/agent/jre/download/linux",
    "$core/api/agent/jre/download/windows"
)
$results['SA01'] = foreach ($u in $saUrls) { Test-EndpointHealth -Url $u -Headers $h2 -Session $ws2 }

# SA-02
try {
    if ($SkipDocker) {
        pwsh .\run-validation.ps1 -CoreUrl $core -SkipDocker | Out-Null
    } else {
        pwsh .\run-validation.ps1 -CoreUrl $core | Out-Null
    }
    $results['SA02'] = [pscustomobject]@{ ran = $true }
} catch {
    $results['SA02'] = [pscustomobject]@{ ran = $false; error = $_.Exception.Message }
}

# INT-01
$intUrls = @(
    "$core/api/agents/stats",
    "$core/api/agents/unified-health",
    "$core/api/agents/unified-health/managed",
    "$core/api/agents/unified-health/standalone"
)
$results['INT01'] = foreach ($u in $intUrls) { Test-EndpointHealth -Url $u -Headers $h2 -Session $ws2 }

# Customer-like target replay
try {
    $replayArgs = @(
        '.\tools\run-docker-tool-hyperv-target-plan.ps1',
        '-WindowsTargetIP', '192.168.100.20',
        '-LinuxTargetIP', '192.168.100.31',
        '-CoreUrl', $core,
        '-SkipWinRMPrecheck',
        '-SkipSSHPrecheck'
    )

    if ($SkipDocker -or -not (Test-DockerAvailable)) {
        $replayArgs += '-SkipCoreStart'
    }

    pwsh @replayArgs | Out-Null
    $results['CUSTOMER_REPLAY'] = [pscustomobject]@{ ran = $true }
} catch {
    $results['CUSTOMER_REPLAY'] = [pscustomobject]@{ ran = $false; error = $_.Exception.Message }
}

$outFile = "tests/deployment/required-tasks-run-20260301-$ts.json"
$results | ConvertTo-Json -Depth 12 | Out-File -FilePath $outFile -Encoding UTF8
Write-Output "RESULT_FILE=$outFile"
$results | ConvertTo-Json -Depth 5
