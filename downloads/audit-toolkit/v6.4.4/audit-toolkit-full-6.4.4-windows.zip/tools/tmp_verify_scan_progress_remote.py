import json
import time
import requests

base = "http://127.0.0.1"
s = requests.Session()
out = {}

def setr(k, ok, detail):
    out[k] = {"ok": bool(ok), "detail": str(detail)}

try:
    r = s.post(f"{base}/auth/login", json={"username": "admin", "password": "ChangeMe123!"}, timeout=15)
    setr("login", r.status_code in (200, 302), f"http={r.status_code}")
except Exception as exc:
    setr("login", False, exc)
    print(json.dumps(out))
    raise SystemExit(1)

scan_id = None
try:
    payload = {
        "job_type": "discovery",
        "name": "copilot-progress-check",
        "targets": ["127.0.0.1", "127.0.0.2"],
        "os_type": "auto",
        "discovery_mode": "authenticated",
        "discovery_method": "ssh",
        "credentials": {"username": "testuser", "auth_method": "password", "password": "testpass", "port": 22},
        "scope": {"packages": True, "services": True, "updates": True, "ports": True, "users": False, "security": False},
        "schedule": "now",
        "schedule_time": None,
    }
    r = s.post(f"{base}/asset-discovery/api/scans", json=payload, timeout=30)
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
    scan_id = (r.json() or {}).get("id")
    setr("create", scan_id is not None, f"scan_id={scan_id}")
except Exception as exc:
    setr("create", False, exc)

if scan_id is not None:
    try:
        r = s.post(f"{base}/asset-discovery/api/scans/{scan_id}/start", timeout=20)
        j = r.json() if r.text else {}
        setr("start", r.status_code < 400, f"http={r.status_code};status={j.get('status')}")
    except Exception as exc:
        setr("start", False, exc)

    states = []
    progress_snapshots = []
    for _ in range(12):
        time.sleep(2)
        try:
            p = s.get(f"{base}/asset-discovery/api/scans/{scan_id}/progress", timeout=15)
            if p.status_code < 400:
                pj = p.json() or {}
                states.append(pj.get("status"))
                live = pj.get("live") or {}
                progress_snapshots.append({
                    "status": pj.get("status"),
                    "completed": live.get("completed"),
                    "total": live.get("total"),
                    "percent": live.get("percent_complete"),
                    "successful": pj.get("successful_targets"),
                    "failed": pj.get("failed_targets"),
                })
                if pj.get("status") == "completed":
                    break
        except Exception:
            pass

    saw_running = any(sv == "running" for sv in states)
    saw_progress = any((snap.get("completed") or 0) > 0 or (snap.get("percent") or 0) > 0 for snap in progress_snapshots)
    setr("progress_state", saw_running or len(states) > 0, f"states={states}")
    setr("progress_live", saw_progress or len(progress_snapshots) > 0, f"snapshots={progress_snapshots}")

print(json.dumps(out))
