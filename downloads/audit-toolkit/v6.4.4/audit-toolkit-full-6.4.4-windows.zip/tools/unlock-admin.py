#!/usr/bin/env python3
"""Reset admin password to 'admin'."""
import sys
import os

# Add web directory to path
script_dir = os.path.dirname(os.path.abspath(__file__))
web_dir = os.path.join(os.path.dirname(script_dir), 'web')
sys.path.insert(0, web_dir)

from werkzeug.security import generate_password_hash

import sqlite3

conn = sqlite3.connect('audit_toolkit.db')
c = conn.cursor()

# Generate new password hash for 'admin'
new_hash = generate_password_hash('admin', method='scrypt')
print(f"New password hash: {new_hash[:50]}...")

# Update admin password
c.execute("UPDATE users SET password_hash=? WHERE username='admin'", (new_hash,))
conn.commit()

# Verify
c.execute("SELECT username, password_hash FROM users WHERE username='admin'")
row = c.fetchone()
print(f"Updated user: {row[0]}")
print(f"New hash starts with: {row[1][:50]}...")

conn.close()
print("\nAdmin password reset to 'admin'")
