[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
[CmdletBinding()]
param(
    [string]$InstallDir = $(if ($env:AUDIT_TOOLKIT_INSTALL_DIR) { $env:AUDIT_TOOLKIT_INSTALL_DIR } else { (Get-Location).Path }),
    [string]$RepoUrl = "https://github.com/AuditToolkitLabs/Audit-Tool-.git",
    [string]$Ref = "",
    [ValidateSet('auto', 'native', 'docker')]
    [string]$Platform = 'auto',
    [switch]$Force,
    [switch]$NoMigrate,
    [switch]$NoRestart
)

$null = $InstallDir, $RepoUrl, $Ref, $Platform, $Force, $NoMigrate, $NoRestart

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Info($Message) { Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Ok($Message) { Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-WarnEx($Message) { Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-ErrEx($Message) { Write-Host "[ERROR] $Message" -ForegroundColor Red }

function Test-CommandExists {
    param([string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Get-ComposeCommand {
    if (Test-CommandExists 'docker') {
        try {
            docker compose version *> $null
            if ($LASTEXITCODE -eq 0) { return 'docker compose' }
        } catch { Write-Verbose 'Suppressed non-fatal error.' }
    }
    if (Test-CommandExists 'docker-compose') { return 'docker-compose' }
    return $null
}

function Test-ComposeFiles {
    return (Test-Path (Join-Path $InstallDir 'docker-compose.yml')) -or
           (Test-Path (Join-Path $InstallDir 'docker-compose.prod.yml')) -or
           (Test-Path (Join-Path $InstallDir 'docker-compose.dev.yml')) -or
           (Test-Path (Join-Path $InstallDir 'docker-compose.https.yml'))
}

function Resolve-Platform {
    if ($Platform -ne 'auto') {
        Write-Info "Platform mode forced: $Platform"
        return $Platform
    }

    if ((Test-ComposeFiles) -and (Get-ComposeCommand)) {
        Write-Info 'Platform mode detected: docker'
        return 'docker'
    }

    Write-Info 'Platform mode detected: native'
    return 'native'
}

function Test-Repo {
    if (-not (Test-Path $InstallDir)) {
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    }

    $gitDir = Join-Path $InstallDir '.git'
    if (Test-Path $gitDir) {
        Write-Info "Using existing git repository: $InstallDir"
        return
    }

    $hasFiles = (Get-ChildItem -Path $InstallDir -Force | Measure-Object).Count -gt 0
    if ($hasFiles) {
        throw "Install directory is not empty and not a git repository: $InstallDir"
    }

    Write-Info "Cloning repository into $InstallDir"
    git clone $RepoUrl $InstallDir
    Write-Ok 'Repository cloned'
}

function Test-Worktree {
    Push-Location $InstallDir
    try {
        $status = git status --porcelain
        if (-not [string]::IsNullOrWhiteSpace($status)) {
            if ($Force) {
                $stamp = "pre-update-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
                Write-WarnEx "Local changes detected; stashing as $stamp"
                git stash push -u -m $stamp | Out-Null
            } else {
                throw 'Local changes detected. Commit/stash them or re-run with -Force.'
            }
        }
    }
    finally {
        Pop-Location
    }
}

function Update-GitRef {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param()

    if (-not $PSCmdlet.ShouldProcess($InstallDir, 'Fetch and update git reference')) {
        return
    }

    Push-Location $InstallDir
    try {
        $before = (git rev-parse --short HEAD).Trim()
        git fetch --all --tags --prune

        if (-not [string]::IsNullOrWhiteSpace($Ref)) {
            Write-Info "Checking out ref: $Ref"
            git checkout $Ref

            git show-ref --verify --quiet "refs/remotes/origin/$Ref"
            if ($LASTEXITCODE -eq 0) {
                git pull --ff-only origin $Ref
            }
        } else {
            $branch = (git rev-parse --abbrev-ref HEAD).Trim()
            if ($branch -eq 'HEAD') {
                Write-WarnEx 'Detached HEAD detected; no branch pull performed (use -Ref to target a branch/tag).'
            } else {
                Write-Info "Pulling latest changes for branch: $branch"
                git pull --ff-only origin $branch
            }
        }

        $after = (git rev-parse --short HEAD).Trim()
        Write-Ok "Updated commit: $before -> $after"
    }
    finally {
        Pop-Location
    }
}

function Get-PythonCommand {
    $venvPython = Join-Path $InstallDir '.venv\Scripts\python.exe'
    if (Test-Path $venvPython) { return $venvPython }

    if (Test-CommandExists 'python') { return 'python' }
    if (Test-CommandExists 'py') { return 'py -3' }

    return $null
}

function Invoke-NativePostUpdate {
    Write-Info 'Running native post-update steps'

    $pythonCmd = Get-PythonCommand
    if (-not $pythonCmd) {
        Write-WarnEx 'Python not found; skipping dependency and migration steps'
        return
    }

    $requirementsCandidates = @(
        (Join-Path $InstallDir 'web\requirements.txt'),
        (Join-Path $InstallDir 'requirements_frozen.txt'),
        (Join-Path $InstallDir 'requirements.txt')
    )

    foreach ($requirementsPath in $requirementsCandidates) {
        if (Test-Path $requirementsPath) {
            $requirementsLabel = Resolve-Path -Relative $requirementsPath
            Write-Info "Updating Python dependencies from $requirementsLabel"
            & ([scriptblock]::Create("$pythonCmd -m pip install -r `"$requirementsPath`" --upgrade"))
            break
        }
    }

    if ($NoMigrate) {
        Write-WarnEx 'Skipping migrations (-NoMigrate)'
        return
    }

    $alembicIni = Join-Path $InstallDir 'alembic.ini'
    if (Test-Path $alembicIni) {
        $runtimeCompatScript = Join-Path $InstallDir 'web\scripts\enforce_postgres_runtime_compat.py'
        Push-Location $InstallDir
        try {
            if (Test-Path $runtimeCompatScript) {
                Write-Info 'Applying database migrations and PostgreSQL runtime compatibility checks'
                & ([scriptblock]::Create("$pythonCmd `"$runtimeCompatScript`""))
                if ($LASTEXITCODE -ne 0) {
                    Write-WarnEx 'PostgreSQL runtime compatibility step failed; please review environment and rerun'
                }
            }
            else {
                Write-Info 'Applying database migrations'
                & ([scriptblock]::Create("$pythonCmd -m alembic upgrade head"))
                if ($LASTEXITCODE -ne 0) {
                    Write-WarnEx 'Migration step failed; please review environment and rerun'
                }
            }
        }
        finally {
            Pop-Location
        }
    }
}

function Get-ComposeFileArg {
    $candidates = @('docker-compose.prod.yml', 'docker-compose.yml', 'docker-compose.dev.yml', 'docker-compose.https.yml')
    foreach ($name in $candidates) {
        $path = Join-Path $InstallDir $name
        if (Test-Path $path) {
            return "-f `"$name`""
        }
    }
    return ''
}

function Invoke-DockerPostUpdate {
    $composeCmd = Get-ComposeCommand
    if (-not $composeCmd) {
        Write-WarnEx 'Docker compose not available; skipping docker update steps'
        return
    }

    $composeFileArg = Get-ComposeFileArg

    Push-Location $InstallDir
    try {
        Write-Info 'Building updated containers'
        & ([scriptblock]::Create("$composeCmd $composeFileArg build"))

        if ($NoRestart) {
            Write-WarnEx 'Skipping container restart (-NoRestart)'
            return
        }

        Write-Info 'Restarting services with updated code'
        & ([scriptblock]::Create("$composeCmd $composeFileArg up -d"))
    }
    finally {
        Pop-Location
    }
}

try {
    Write-Info "Detected OS: $([System.Runtime.InteropServices.RuntimeInformation]::OSDescription)"

    Test-Repo
    Test-Worktree
    Update-GitRef

    $resolvedPlatform = Resolve-Platform
    if ($resolvedPlatform -eq 'native') {
        Invoke-NativePostUpdate
    } elseif ($resolvedPlatform -eq 'docker') {
        Invoke-DockerPostUpdate
    } else {
        throw "Invalid platform mode: $resolvedPlatform"
    }

    Write-Ok 'Toolkit update complete'
}
catch {
    Write-ErrEx $_.Exception.Message
    exit 1
}

