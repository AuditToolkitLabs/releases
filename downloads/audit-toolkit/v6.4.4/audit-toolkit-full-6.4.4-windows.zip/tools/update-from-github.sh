#!/usr/bin/env bash
set -euo pipefail

REPO_URL="https://github.com/AuditToolkitLabs/Audit-Tool-.git"
INSTALL_DIR="${AUDIT_TOOLKIT_INSTALL_DIR:-$(pwd)}"
REF=""
PLATFORM="auto"   # auto|native|docker
FORCE="false"
SKIP_MIGRATIONS="false"
SKIP_RESTART="false"

# State tracked for automatic rollback on failure
BEFORE_SHA=""
STASH_APPLIED="false"

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $*"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_err() { echo -e "${RED}[ERROR]${NC} $*"; }

usage() {
  cat <<EOF
Usage: $0 [options]

Options:
  --install-dir <path>   Toolkit install directory (default: current directory)
  --repo <url>           Git repository URL (default: ${REPO_URL})
  --ref <branch|tag>     Git ref to update to (default: current branch)
  --platform <mode>      auto|native|docker (default: auto)
  --force                Stash local changes before update
  --no-migrate           Skip alembic migrations (native mode)
  --no-restart           Skip docker compose restart (docker mode)
  -h, --help             Show this help

Examples:
  $0 --install-dir /opt/audit-toolkit
  $0 --install-dir /opt/audit-toolkit --ref v6.0.0
  $0 --install-dir /opt/audit-toolkit --platform docker --force
EOF
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install-dir)
        INSTALL_DIR="$2"; shift 2 ;;
      --repo)
        REPO_URL="$2"; shift 2 ;;
      --ref)
        REF="$2"; shift 2 ;;
      --platform)
        PLATFORM="$2"; shift 2 ;;
      --force)
        FORCE="true"; shift ;;
      --no-migrate)
        SKIP_MIGRATIONS="true"; shift ;;
      --no-restart)
        SKIP_RESTART="true"; shift ;;
      -h|--help)
        usage; exit 0 ;;
      *)
        log_err "Unknown argument: $1"
        usage
        exit 1 ;;
    esac
  done
}

detect_os() {
  local os_name
  if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    . /etc/os-release
    os_name="${PRETTY_NAME:-${ID:-unknown}}"
  else
    os_name="$(uname -s)"
  fi
  log_info "Detected OS: ${os_name}"
}

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

detect_compose_cmd() {
  if command_exists docker && docker compose version >/dev/null 2>&1; then
    echo "docker compose"
    return 0
  fi
  if command_exists docker-compose; then
    echo "docker-compose"
    return 0
  fi
  return 1
}

has_compose_files() {
  [[ -f "docker-compose.yml" || -f "docker-compose.prod.yml" || -f "docker-compose.dev.yml" || -f "docker-compose.https.yml" ]]
}

detect_platform() {
  if [[ "$PLATFORM" != "auto" ]]; then
    log_info "Platform mode forced: $PLATFORM"
    return
  fi

  if has_compose_files && detect_compose_cmd >/dev/null 2>&1; then
    PLATFORM="docker"
  else
    PLATFORM="native"
  fi

  log_info "Platform mode detected: $PLATFORM"
}

ensure_repo() {
  mkdir -p "$INSTALL_DIR"

  if [[ -d "$INSTALL_DIR/.git" ]]; then
    log_info "Using existing git repository: $INSTALL_DIR"
    return
  fi

  if [[ -n "$(find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 2>/dev/null)" ]]; then
    log_err "Install directory is not empty and not a git repository: $INSTALL_DIR"
    exit 1
  fi

  log_info "Cloning repository into $INSTALL_DIR"
  git clone "$REPO_URL" "$INSTALL_DIR"
  log_ok "Repository cloned"
}

prepare_worktree() {
  cd "$INSTALL_DIR"

  if [[ "$(git status --porcelain)" != "" ]]; then
    if [[ "$FORCE" == "true" ]]; then
      local stamp
      stamp="pre-update-$(date +%Y%m%d-%H%M%S)"
      log_warn "Local changes detected; stashing as $stamp"
      git stash push -u -m "$stamp" >/dev/null
      STASH_APPLIED="true"
    else
      log_err "Local changes detected. Commit/stash them or re-run with --force."
      exit 1
    fi
  fi
}

update_git_ref() {
  local after current_branch

  git fetch --all --tags --prune

  if [[ -n "$REF" ]]; then
    log_info "Checking out ref: $REF"
    git checkout "$REF"
    if git show-ref --verify --quiet "refs/remotes/origin/$REF"; then
      git pull --ff-only origin "$REF"
    fi
  else
    current_branch="$(git rev-parse --abbrev-ref HEAD)"
    if [[ "$current_branch" == "HEAD" ]]; then
      log_warn "Detached HEAD detected; no branch pull performed (use --ref to target a branch/tag)."
    else
      log_info "Pulling latest changes for branch: $current_branch"
      git pull --ff-only origin "$current_branch"
    fi
  fi

  after="$(git rev-parse --short HEAD)"
  log_ok "Updated commit: $(git rev-parse --short "${BEFORE_SHA:-HEAD}") -> ${after}"
}

rollback_update() {
  local exit_code=$?
  # Only rollback if we actually moved to the new ref
  if [[ -z "$BEFORE_SHA" ]]; then
    log_err "Update failed (no baseline SHA recorded; cannot auto-rollback)."
    exit "${exit_code:-1}"
  fi

  log_warn "Update failed — rolling back to ${BEFORE_SHA}"
  cd "$INSTALL_DIR"

  git reset --hard "$BEFORE_SHA" >/dev/null 2>&1 || \
    log_warn "git reset --hard failed; working tree may be in a mixed state"

  if [[ "$STASH_APPLIED" == "true" ]]; then
    if git stash pop >/dev/null 2>&1; then
      log_info "Local stash restored"
    else
      log_warn "git stash pop failed; run 'git stash list' to recover local changes"
    fi
  fi

  # Restart services if native mode
  if [[ "$PLATFORM" == "native" ]] && command_exists systemctl; then
    for unit in \
      audit-toolkit-web.service \
      audit-toolkit-discovery.service \
      audit-toolkit-celery.service \
      audit-toolkit-celery-beat.service; do
      systemctl start "$unit" >/dev/null 2>&1 || true
    done
    log_info "Attempted to start services with prior code"
  fi

  # Restart docker services if docker mode
  if [[ "$PLATFORM" == "docker" ]]; then
    local compose_cmd compose_file
    compose_cmd="$(detect_compose_cmd || true)"
    compose_file="$(compose_file_arg)"
    if [[ -n "$compose_cmd" ]]; then
      # shellcheck disable=SC2086
      $compose_cmd $compose_file up -d >/dev/null 2>&1 || true
      log_info "Attempted to bring up containers with prior code"
    fi
  fi

  log_err "Rollback complete. Investigate the failure before retrying the update."
  exit "${exit_code:-1}"
}

choose_python() {
  if [[ -x ".venv/bin/python" ]]; then
    echo ".venv/bin/python"
    return
  fi
  if command_exists python3; then
    echo "python3"
    return
  fi
  if command_exists python; then
    echo "python"
    return
  fi
  echo ""
}

run_native_post_update() {
  log_info "Running native post-update steps"

  local py
  py="$(choose_python)"
  if [[ -z "$py" ]]; then
    log_warn "Python not found; skipping dependency and migration steps"
    return
  fi

  local requirements_file
  for requirements_file in web/requirements.txt requirements_frozen.txt requirements.txt; do
    if [[ -f "$requirements_file" ]]; then
      log_info "Updating Python dependencies from $requirements_file"
      "$py" -m pip install -r "$requirements_file" --upgrade || log_warn "Dependency update had warnings"
      break
    fi
  done

  if [[ "$SKIP_MIGRATIONS" == "true" ]]; then
    log_warn "Skipping migrations (--no-migrate)"
    return
  fi

  if [[ -f "alembic.ini" ]]; then
    local runtime_compat_script
    runtime_compat_script="web/scripts/enforce_postgres_runtime_compat.py"

    if [[ -f "$runtime_compat_script" ]]; then
      log_info "Applying database migrations and PostgreSQL runtime compatibility checks"
      "$py" "$runtime_compat_script" || {
        log_err "PostgreSQL runtime compatibility / migration step failed."
        return 1
      }
    else
      log_info "Applying database migrations"
      "$py" -m alembic upgrade head || {
        log_err "Migration step failed."
        return 1
      }
    fi
  fi
}

compose_file_arg() {
  if [[ -f "docker-compose.prod.yml" ]]; then
    echo "-f docker-compose.prod.yml"
  elif [[ -f "docker-compose.yml" ]]; then
    echo "-f docker-compose.yml"
  elif [[ -f "docker-compose.dev.yml" ]]; then
    echo "-f docker-compose.dev.yml"
  elif [[ -f "docker-compose.https.yml" ]]; then
    echo "-f docker-compose.https.yml"
  else
    echo ""
  fi
}

run_docker_post_update() {
  local compose_cmd compose_file
  compose_cmd="$(detect_compose_cmd || true)"
  if [[ -z "$compose_cmd" ]]; then
    log_warn "Docker compose not available; skipping docker update steps"
    return
  fi

  compose_file="$(compose_file_arg)"
  log_info "Building updated containers"
  # shellcheck disable=SC2086
  $compose_cmd $compose_file build

  if [[ "$SKIP_RESTART" == "true" ]]; then
    log_warn "Skipping container restart (--no-restart)"
    return
  fi

  log_info "Restarting services with updated code"
  # shellcheck disable=SC2086
  $compose_cmd $compose_file up -d
}

main() {
  parse_args "$@"
  detect_os
  ensure_repo
  prepare_worktree

  # Capture baseline SHA and arm rollback trap before making any changes
  cd "$INSTALL_DIR"
  BEFORE_SHA="$(git rev-parse HEAD)"
  trap 'rollback_update' ERR

  update_git_ref
  detect_platform

  case "$PLATFORM" in
    native) run_native_post_update ;;
    docker) run_docker_post_update ;;
    *)
      log_err "Invalid platform mode: $PLATFORM"
      exit 1 ;;
  esac

  # Disarm the rollback trap — update succeeded
  trap - ERR

  log_ok "Toolkit update complete"
}

main "$@"
