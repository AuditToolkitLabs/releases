#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$VMHost = '192.168.100.52',
    [string]$VMUser = 'auditadmin',
    [string]$ToolkitRoot = '/opt/audit-toolkit',
    [int]$SSHPort = 22,
    [switch]$SkipShutdown,
    [switch]$SkipCleanup
)

$null = $VMUser, $SSHPort

$ErrorActionPreference = 'Stop'

function Get-SudoCommand {
    param([string]$Inner)
    return "sudo -n bash -lc '$Inner'"
}

function Invoke-Remote {
    param([string]$Command)

    $output = & ssh -n -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p $SSHPort "$VMUser@$VMHost" $Command 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Remote command failed: $($output -join ' ')"
    }
    return ($output -join "`n")
}

try {
    Write-Output "[INFO] Updating appliance on $VMHost"

    Write-Output "[INFO] Updating Python packaging tooling"
    Invoke-Remote (Get-SudoCommand -Inner "$ToolkitRoot/venv/bin/pip install --upgrade pip wheel setuptools") | Out-Host

    Write-Output "[INFO] Updating web dependencies"
    Invoke-Remote (Get-SudoCommand -Inner "$ToolkitRoot/venv/bin/pip install --upgrade -r $ToolkitRoot/web/requirements.txt") | Out-Host

    if (-not $SkipCleanup) {
        Write-Output "[INFO] Removing first-boot markers and transient lab state"
        Invoke-Remote (Get-SudoCommand -Inner "rm -f $ToolkitRoot/.first-boot-complete /root/.first-boot-complete /var/lib/audit-toolkit/.first-boot /etc/audit-toolkit/first-boot-*") | Out-Null
        Invoke-Remote (Get-SudoCommand -Inner "find $ToolkitRoot -name '*.log' -type f -delete") | Out-Null
        Invoke-Remote (Get-SudoCommand -Inner "rm -f $ToolkitRoot/.env.lab $ToolkitRoot/.env.local") | Out-Null
    }

    if (-not $SkipShutdown) {
        Write-Output "[INFO] Powering off VM"
        Invoke-Remote (Get-SudoCommand -Inner "sync && systemctl poweroff") | Out-Null
    }

    Write-Output "[PASS] Appliance update workflow completed"
}
catch {
    Write-Output "[FAIL] $($_.Exception.Message)"
    exit 1
}
