﻿# Validate a Gumroad access token, print user.user_id, and optionally update the repo secret.
# Usage:
#   pwsh -NoLogo -NoProfile -File tools/validate-gumroad-token.ps1
#   pwsh -NoLogo -NoProfile -File tools/validate-gumroad-token.ps1 -SetGitHubSecret

[CmdletBinding()]
param(
    [switch]$SetGitHubSecret,
    [string]$Repo = "AuditToolkitLabs/Audit-Tool-",
    [string]$GhPath = 'C:\Program Files\GitHub CLI\gh.exe'
)

function Read-SecretValue {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Prompt
    )

    $secureValue = Read-Host $Prompt -AsSecureString
    if ($null -eq $secureValue) {
        return ""
    }

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        if ($bstr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
    }
}

Write-Output "=== Gumroad Token Validation ==="
Write-Output ""
Write-Output "This validates a Gumroad token against GET /v2/user and prints user.user_id."
Write-Output ""

$token = $env:GUMROAD_ACCESS_TOKEN
if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Output "Paste a NEW Gumroad access token. The value will not be echoed."
    $token = Read-SecretValue "Enter GUMROAD_ACCESS_TOKEN"
}

if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Output "ERROR: Token cannot be empty."
    exit 1
}

Write-Output "Validating token..."
$uri = "https://api.gumroad.com/v2/user?access_token=$([Uri]::EscapeDataString($token))"

try {
    $response = Invoke-RestMethod -Method Get -Uri $uri -ErrorAction Stop
}
catch {
    $statusCode = $null
    if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
        $statusCode = [int]$_.Exception.Response.StatusCode
    }

    Write-Output "✗ Gumroad token validation failed."
    if ($null -ne $statusCode) {
        Write-Output "Status: $statusCode"
    }
    if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
        Write-Output "Response: $($_.ErrorDetails.Message)"
    }
    Write-Output ""
    Write-Output "Rotate the exposed token and create a new token with at least the 'view_sales' scope."
    exit 1
}

$user = $response.user
if ($null -eq $user) {
    Write-Output "✗ Gumroad response did not include a 'user' object."
    $response | ConvertTo-Json -Depth 6
    exit 1
}

$userId = ""
if ($user.PSObject.Properties.Name -contains 'user_id') {
    $userId = [string]$user.user_id
}

Write-Output "✓ Token is valid."
if ($userId) {
    Write-Output "user.user_id: $userId"
}
if ($user.PSObject.Properties.Name -contains 'name' -and $user.name) {
    Write-Output "name: $($user.name)"
}
if ($user.PSObject.Properties.Name -contains 'url' -and $user.url) {
    Write-Output "url: $($user.url)"
}

if (-not $SetGitHubSecret) {
    Write-Output ""
    Write-Output "To update the repository secret after validation, rerun with:"
    Write-Output "pwsh -NoLogo -NoProfile -File tools/validate-gumroad-token.ps1 -SetGitHubSecret"
    exit 0
}

if (-not (Test-Path $GhPath)) {
    Write-Output "✗ GitHub CLI not found at: $GhPath"
    exit 1
}

Write-Output ""
Write-Output "Updating GitHub secret GUMROAD_ACCESS_TOKEN..."
& $GhPath secret set GUMROAD_ACCESS_TOKEN --repo $Repo --body $token
if ($LASTEXITCODE -ne 0) {
    Write-Output "✗ Failed to set GUMROAD_ACCESS_TOKEN in $Repo"
    exit 1
}

Write-Output "✓ GUMROAD_ACCESS_TOKEN updated in $Repo"
Write-Output "Next: run tools/run-gumroad-bootstrap.ps1 to verify the workflow."
