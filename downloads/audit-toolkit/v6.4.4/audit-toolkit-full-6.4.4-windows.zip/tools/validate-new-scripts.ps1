﻿# validate-new-scripts.ps1
# Run ShellCheck on all new scripts created in current session

$ErrorActionPreference = "Continue"

$scripts = @(
    "audits\storage\shares\nfs-smb-security-audit.sh",
    "audits\automation\iac\terraform-security-audit.sh",
    "audits\platform\monitoring\prometheus-grafana-security-audit.sh",
    "orchestrator\discovery.sh"
)

Write-Output "═══════════════════════════════════════════════════════════════════════════"
Write-Output "  ShellCheck Validation - New Scripts from Current Session"
Write-Output "═══════════════════════════════════════════════════════════════════════════"
Write-Output ""

$totalScripts = $scripts.Count
$passedScripts = 0
$failedScripts = 0

foreach ($script in $scripts) {
    $scriptName = Split-Path $script -Leaf
    Write-Output "─── Validating: $scriptName "

    if (-not (Test-Path $script)) {
        Write-Output "[NOT FOUND]"
        $failedScripts++
        continue
    }

    # Run shellcheck
    $output = & shellcheck -s bash -x $script 2>&1

    if ($LASTEXITCODE -eq 0) {
        Write-Output "[PASS]"
        $passedScripts++
    } else {
        Write-Output "[ISSUES FOUND]"
        Write-Output $output

        # Check if only info-level warnings (SC1091 is acceptable)
        $criticalIssues = $output | Select-String -Pattern "error:|warning:" | Where-Object { $_ -notmatch "SC1091" -and $_ -notmatch "SC2009" }

        if ($criticalIssues) {
            $failedScripts++
        } else {
            Write-Output "    (Only info-level warnings - acceptable)"
            $passedScripts++
        }
    }
    Write-Output ""
}

Write-Output "═══════════════════════════════════════════════════════════════════════════"
Write-Output "  Summary: $passedScripts/$totalScripts scripts passed validation"
Write-Output "═══════════════════════════════════════════════════════════════════════════"

if ($failedScripts -gt 0) {
    exit 1
} else {
    exit 0
}

