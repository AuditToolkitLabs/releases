$ErrorActionPreference = "Stop"

$envLine = (Get-Content .env | Select-String "^ADMIN_PASSWORD=" | Select-Object -First 1)
if (-not $envLine) {
    throw "ADMIN_PASSWORD not found in .env"
}

$pw = $envLine.Line.Substring(15)
$tests = @(
    @{ Name = "ENV"; Password = $pw },
    @{ Name = "DEFAULT"; Password = "ChangeMe123!" }
)

foreach ($t in $tests) {
    $body = @{ username = "admin"; password = $t.Password } | ConvertTo-Json

    try {
        Invoke-WebRequest -Uri "http://localhost:5000/auth/login" -Method POST -Body $body -ContentType "application/json" -UseBasicParsing -SessionVariable s -ErrorAction Stop | Out-Null
        Write-Host ($t.Name + ":LOGIN_OK")
    }
    catch {
        if ($_.Exception.Response) {
            Write-Host ($t.Name + ":STATUS=" + [int]$_.Exception.Response.StatusCode)
        }
        else {
            Write-Host ($t.Name + ":ERROR=" + $_.Exception.Message)
        }
    }
}
