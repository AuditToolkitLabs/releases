$ErrorActionPreference = "Stop"

$script = @"
from app import create_app
from config import get_db_session
from models.user import User

app = create_app()
ctx = app.app_context()
ctx.push()

db = get_db_session()
u = db.query(User).filter(User.is_builtin_admin.is_(True)).order_by(User.id.asc()).first()
print(
    "exists=%s username=%s active=%s locked=%s failed=%s must_change=%s provider=%s"
    % (
        bool(u),
        getattr(u, "username", None),
        getattr(u, "is_active", None),
        getattr(u, "is_locked", None),
        getattr(u, "failed_login_attempts", None),
        getattr(u, "must_change_password", None),
        getattr(u, "auth_provider", None),
    )
)

db.close()
ctx.pop()
"@

& docker exec audit-toolkit-web python -c $script
exit $LASTEXITCODE
