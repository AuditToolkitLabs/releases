$ErrorActionPreference = "Stop"

$envLine = Get-Content .env | Select-String "^ADMIN_PASSWORD=" | Select-Object -First 1
if (-not $envLine) {
    throw "ADMIN_PASSWORD not found in .env"
}

$pw = $envLine.Line.Substring(15)
$env:ADMIN_RESET_PASSWORD = $pw

$script = @"
import os
import subprocess
import sys

reset_script_cands = [
    '/opt/audit-toolkit/reset_admin_password.py',
    '/opt/audit-toolkit/web/reset_admin_password.py',
    '/tmp/reset_admin_password.py',
]
helper_cands = [
    '/tmp/container_admin_auth_helper.py',
    '/opt/audit-toolkit/tools/tmp/container_admin_auth_helper.py',
]

reset_script = next((c for c in reset_script_cands if os.path.isfile(c)), None)
if reset_script is not None:
    print('using=' + reset_script)
    sys.exit(
        subprocess.call([
            'python',
            reset_script,
            '--password',
            os.environ.get('ADMIN_RESET_PASSWORD', ''),
            '--no-must-change',
        ])
    )

helper = next((c for c in helper_cands if os.path.isfile(c)), None)
if helper is not None:
    print('using=' + helper)
    sys.exit(
        subprocess.call([
            'python',
            helper,
            '--reset',
            '--password',
            os.environ.get('ADMIN_RESET_PASSWORD', ''),
            '--no-must-change',
        ])
    )

print('using=None')
sys.exit(1)
"@

& docker exec -e ADMIN_RESET_PASSWORD=$env:ADMIN_RESET_PASSWORD audit-toolkit-web python -c $script
exit $LASTEXITCODE
