$ErrorActionPreference = "Stop"

$envLine = Get-Content .env | Select-String "^ADMIN_PASSWORD=" | Select-Object -First 1
if (-not $envLine) {
    throw "ADMIN_PASSWORD not found in .env"
}

$pw = $envLine.Line.Substring(15)
$env:ADMIN_RESET_PASSWORD = $pw

$script = @"
import os
from app import create_app
from config import get_db_session
from models.user import User

app = create_app()
ctx = app.app_context()
ctx.push()

db = get_db_session()
u = db.query(User).filter(User.is_builtin_admin.is_(True)).order_by(User.id.asc()).first()
assert u is not None, 'builtin admin missing'

u.set_password(os.environ.get('ADMIN_RESET_PASSWORD', ''))
u.is_active = True
u.auth_provider = 'local'
u.is_locked = False
u.failed_login_attempts = 0
u.lockout_until = None
u.must_change_password = False

db.commit()
print('RESET_OK')
print('username=%s locked=%s failed=%s must_change=%s' % (u.username, u.is_locked, u.failed_login_attempts, u.must_change_password))

db.close()
ctx.pop()
"@

& docker exec -e ADMIN_RESET_PASSWORD=$env:ADMIN_RESET_PASSWORD audit-toolkit-web python -c $script
exit $LASTEXITCODE
