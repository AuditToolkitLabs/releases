param(
    [string]$CoreUrl = "http://localhost:5000",
    [string]$DiscoveryUrl = "http://localhost:8080",
    [string]$ApiKey = "",
    [string]$WindowsTarget = "",
    [string]$LinuxTarget = ""
)

$ErrorActionPreference = "Stop"

$startTime = Get-Date
$timestamp = $startTime.ToString("yyyyMMdd-HHmmss")
$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$rootDir = $repoRoot
$diagnosticsRoot = Join-Path $rootDir "diagnostics"
$bundlesRoot = Join-Path $diagnosticsRoot "bundles"
$bundleDir = Join-Path $bundlesRoot $timestamp
$resultsDir = Join-Path $bundleDir "results"

New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null

$gateScript = Join-Path $rootDir "run-release-gate.ps1"
$gateLogPath = Join-Path $bundleDir "gate-output.log"

$gateArgs = @(
    "-CoreUrl", $CoreUrl,
    "-DiscoveryUrl", $DiscoveryUrl
)

if (-not [string]::IsNullOrWhiteSpace($ApiKey)) {
    $gateArgs += @("-ApiKey", $ApiKey)
}
if (-not [string]::IsNullOrWhiteSpace($WindowsTarget)) {
    $gateArgs += @("-WindowsTarget", $WindowsTarget)
}
if (-not [string]::IsNullOrWhiteSpace($LinuxTarget)) {
    $gateArgs += @("-LinuxTarget", $LinuxTarget)
}

Write-Output "========================================"
Write-Output "  Diagnostic Mode"
Write-Output "========================================"
Write-Output "Bundle directory: $bundleDir"

& pwsh -NoProfile -ExecutionPolicy Bypass -File $gateScript @gateArgs 2>&1 | Tee-Object -FilePath $gateLogPath | Out-Host
$gateExitCode = [int]$LASTEXITCODE

$artifactPatterns = @(
    "api-endpoint-validation-*.json",
    "test-results-*.json",
    "asset-discovery-test-results-*.json"
)

$copiedArtifacts = @()
foreach ($pattern in $artifactPatterns) {
    $files = Get-ChildItem -Path $rootDir -Filter $pattern -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -ge $startTime.AddMinutes(-1) }

    foreach ($file in $files) {
        $destination = Join-Path $resultsDir $file.Name
        Copy-Item -Path $file.FullName -Destination $destination -Force
        $copiedArtifacts += $file.Name
    }
}

$summary = [ordered]@{
    timestamp = $timestamp
    started_at = $startTime.ToString("o")
    finished_at = (Get-Date).ToString("o")
    gate_exit_code = $gateExitCode
    gate_status = if ($gateExitCode -eq 0) { "PASS" } elseif ($gateExitCode -eq 1) { "WARN" } else { "FAIL" }
    core_url = $CoreUrl
    discovery_url = $DiscoveryUrl
    windows_target = if ([string]::IsNullOrWhiteSpace($WindowsTarget)) { $null } else { $WindowsTarget }
    linux_target = if ([string]::IsNullOrWhiteSpace($LinuxTarget)) { $null } else { $LinuxTarget }
    artifacts = $copiedArtifacts
    bundle_dir = $bundleDir
}

$summaryPath = Join-Path $bundleDir "summary.json"
$summary | ConvertTo-Json -Depth 8 | Out-File -FilePath $summaryPath -Encoding UTF8

$zipPath = Join-Path $bundlesRoot ("diagnostic-bundle-" + $timestamp + ".zip")
Compress-Archive -Path (Join-Path $bundleDir "*") -DestinationPath $zipPath -Force

Write-Output "Summary: $summaryPath"
Write-Output "Bundle zip: $zipPath"

Write-Output "DIAG_BUNDLE_DIR=$bundleDir"
Write-Output "DIAG_SUMMARY_PATH=$summaryPath"
Write-Output "DIAG_ZIP_PATH=$zipPath"

exit $gateExitCode
