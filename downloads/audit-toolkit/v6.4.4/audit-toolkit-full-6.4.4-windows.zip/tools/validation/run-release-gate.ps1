[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Release gate is an operator-facing console script with intentional colorized status output')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingPlainTextForPassword', '', Justification='CLI compatibility with existing automation contracts; password is immediately converted to SecureString in-memory')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification='Release validation workflow is intentionally non-interactive and deterministic for automation and CI execution')]
param(
    [string]$CoreUrl = "http://localhost:5000",
    [string]$DiscoveryUrl = "http://localhost:8080",
    [string]$ApiKey = "",
    [string]$Username = "admin",
    [string]$Password = "",
    [string]$EnvFilePath = ".env",
    [string]$WindowsTarget = "",
    [string]$WindowsTargetUsername = "",
    [string]$WindowsTargetPassword = "",
    [string]$LinuxTarget = "",
    [string]$LinuxTargetUsername = "",
    [string]$LinuxTargetPassword = "",
    [switch]$RequireDiagnosticsApis,
    [switch]$SkipRebootStability,
    [switch]$StrictCustomerConfidence
)

$ErrorActionPreference = "Stop"

function Get-EnvFromFile {
    param([string]$Path)

    $map = @{}
    if (-not (Test-Path -LiteralPath $Path)) {
        return $map
    }

    Get-Content -LiteralPath $Path | ForEach-Object {
        $line = $_.Trim()
        if (-not $line -or $line.StartsWith('#')) {
            return
        }

        $parts = $line -split '=', 2
        if ($parts.Count -ne 2) {
            return
        }

        $key = $parts[0].Trim()
        $value = $parts[1].Trim()
        if ($key) {
            $map[$key] = $value
        }
    }

    return $map
}

function Resolve-ConfiguredValue {
    param(
        [string[]]$Names,
        [hashtable]$EnvFileMap
    )

    foreach ($name in $Names) {
        $value = [Environment]::GetEnvironmentVariable($name)
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return [pscustomobject]@{ Value = $value; Source = "env:$name" }
        }

        if ($EnvFileMap.ContainsKey($name) -and -not [string]::IsNullOrWhiteSpace($EnvFileMap[$name])) {
            return [pscustomobject]@{ Value = $EnvFileMap[$name]; Source = "${EnvFilePath}:$name" }
        }
    }

    return $null
}

function Resolve-InitialAdminPasswordFromFile {
    param([hashtable]$EnvFileMap)

    $candidatePaths = @(
        [Environment]::GetEnvironmentVariable('INITIAL_ADMIN_CREDENTIALS_FILE'),
        $EnvFileMap['INITIAL_ADMIN_CREDENTIALS_FILE'],
        'C:\ProgramData\SecurityAuditToolkit\runtime\initial-admin-credentials.txt',
        'C:\ProgramData\SecurityAuditToolkit\runtime\FIRST-LOGIN.txt',
        '/var/lib/audit-toolkit/initial-admin-credentials.txt',
        '/etc/audit-toolkit/initial-admin-credentials.txt',
        '/opt/audit-toolkit/data/initial-admin-credentials.txt'
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    foreach ($path in $candidatePaths) {
        if (-not (Test-Path -LiteralPath $path)) {
            continue
        }

        $passwordLine = Get-Content -LiteralPath $path | Where-Object { $_ -match '^Password:\s*(.+)$' } | Select-Object -First 1
        if ($passwordLine -match '^Password:\s*(.+)$') {
            return [pscustomobject]@{ Value = $Matches[1].Trim(); Source = $path }
        }
    }

    return $null
}

$envFromFile = Get-EnvFromFile -Path $EnvFilePath

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    if (-not [string]::IsNullOrWhiteSpace($env:AUDIT_API_KEY)) {
        $ApiKey = $env:AUDIT_API_KEY
    }
}

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    if (-not [string]::IsNullOrWhiteSpace($env:AUDIT_TOOL_API_KEY)) {
        $ApiKey = $env:AUDIT_TOOL_API_KEY
    }
}

if ([string]::IsNullOrWhiteSpace($Password)) {
    $resolvedPassword = Resolve-ConfiguredValue -Names @(
        'AUDIT_TOOL_ADMIN_PASSWORD',
        'AUDIT_ADMIN_PASSWORD',
        'INITIAL_ADMIN_PASSWORD',
        'ADMIN_PASSWORD'
    ) -EnvFileMap $envFromFile

    if (-not $resolvedPassword) {
        $resolvedPassword = Resolve-InitialAdminPasswordFromFile -EnvFileMap $envFromFile
    }

    if ($resolvedPassword) {
        $Password = $resolvedPassword.Value
        Write-Output "[INFO] Resolved admin password from $($resolvedPassword.Source)"
    }
    else {
        $Password = "ChangeMe123!"
        Write-Output "[WARN] Falling back to default admin password; no local password source was found"
    }
}

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function New-CsrfSessionContext {
    param([string]$BaseUrl)

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $csrfResponse = Invoke-WebRequest -Uri "$BaseUrl/auth/csrf-token" -Method GET -WebSession $session -UseBasicParsing -ErrorAction Stop
    $csrfPayload = $csrfResponse.Content | ConvertFrom-Json
    $csrfToken = [string]$csrfPayload.csrf_token

    if ([string]::IsNullOrWhiteSpace($csrfToken)) {
        throw "CSRF token was not returned by $BaseUrl/auth/csrf-token"
    }

    return [pscustomobject]@{
        Session = $session
        CsrfToken = $csrfToken
    }
}

function Write-Header {
    param([string]$Title)
    Write-Output "`n========================================"
    Write-Output "  $Title"
    Write-Output "========================================`n"
}

function Format-ArgumentsForDisplay {
    param(
        [string[]]$Arguments
    )

    $displayArgs = @()
    $index = 0

    while ($index -lt $Arguments.Count) {
        $argument = $Arguments[$index]

        if (
            $argument -eq "-ApiKey" -or $argument -eq "--ApiKey" -or
            $argument -eq "-Password" -or $argument -eq "--Password"
        ) {
            $displayArgs += $argument
            if (($index + 1) -lt $Arguments.Count) {
                $displayArgs += "***REDACTED***"
                $index += 2
                continue
            }
        }

        $displayArgs += $argument
        $index += 1
    }

    return ($displayArgs -join ' ')
}

function Invoke-TestSuite {
    param(
        [string]$Name,
        [string]$ScriptPath,
        [string[]]$Arguments
    )

    Write-Host "[RUN] $Name"
    Write-Host "      pwsh $ScriptPath $(Format-ArgumentsForDisplay -Arguments $Arguments)"

    & pwsh $ScriptPath @Arguments | Out-Host
    $exitCode = [int]$LASTEXITCODE

    if ($exitCode -eq 0) {
        Write-Host "[PASS] $Name`n"
    }
    elseif ($exitCode -eq 1) {
        Write-Host "[WARN] $Name exited with code 1`n"
    }
    else {
        Write-Host "[FAIL] $Name exited with code $exitCode`n"
    }

    return [int]$exitCode
}

function Resolve-ApiKeyFromCore {
    param(
        [string]$BaseUrl,
        [System.Management.Automation.PSCredential]$Credential
    )

    if (-not $Credential) {
        return ""
    }

    $passwordPointer = [IntPtr]::Zero

    try {
        $csrfContext = New-CsrfSessionContext -BaseUrl $BaseUrl
        $passwordPointer = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
        $plainPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
        $loginBody = @{ username = $Credential.UserName; password = $plainPassword; csrf_token = $csrfContext.CsrfToken } | ConvertTo-Json
        $null = Invoke-WebRequest -Uri "$BaseUrl/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -Headers @{ 'X-CSRF-Token' = $csrfContext.CsrfToken } -WebSession $csrfContext.Session -UseBasicParsing -ErrorAction Stop
    }
    catch {
        return ""
    }
    finally {
        if ($passwordPointer -ne [IntPtr]::Zero) {
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
        }
    }

    try {
        $raw = (Invoke-WebRequest -Uri "$BaseUrl/api/settings/api-key" -Method GET -WebSession $csrfContext.Session -UseBasicParsing -ErrorAction Stop).Content
        $parsed = $raw | ConvertFrom-Json
        if ($parsed -and -not [string]::IsNullOrWhiteSpace($parsed.api_key)) {
            return [string]$parsed.api_key
        }
    }
    catch {
        return ""
    }

    return ""
}

function Update-ApiKeyFromSession {
    if ([string]::IsNullOrWhiteSpace($Username) -or [string]::IsNullOrWhiteSpace($Password)) {
        return
    }

    $adminSecurePassword = ConvertTo-InMemorySecureString -Value $Password
    $adminCredential = New-Object System.Management.Automation.PSCredential($Username, $adminSecurePassword)
    $resolvedApiKey = Resolve-ApiKeyFromCore -BaseUrl $CoreUrl -Credential $adminCredential
    if (-not [string]::IsNullOrWhiteSpace($resolvedApiKey)) {
        $script:ApiKey = $resolvedApiKey
        Write-Output "[INFO] Refreshed API key from active session context"
    }
}

Write-Header "Audit Toolkit - Consolidated Release Gate"

if ($StrictCustomerConfidence) {
    Write-Output "[INFO] Strict customer confidence mode enabled (no degraded endpoint acceptance)."
}

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    Write-Output "[INFO] API key not provided; attempting runtime key resolution"
    $adminSecurePassword = ConvertTo-InMemorySecureString -Value $Password
    $adminCredential = New-Object System.Management.Automation.PSCredential($Username, $adminSecurePassword)
    $resolvedApiKey = Resolve-ApiKeyFromCore -BaseUrl $CoreUrl -Credential $adminCredential
    if (-not [string]::IsNullOrWhiteSpace($resolvedApiKey)) {
        $ApiKey = $resolvedApiKey
        $script:ApiKey = $resolvedApiKey
        Write-Output "[INFO] Runtime API key resolution succeeded"
    }
    else {
        Write-Output "[WARN] Runtime API key resolution failed; downstream auth-required suites may fail"
    }
}
else {
    $script:ApiKey = $ApiKey
}

$results = @()
if (-not $SkipRebootStability) {
    $rebootArgs = @(
        "-CoreUrl", $CoreUrl,
        "-Username", $Username,
        "-Password", $Password
    )

    $results += [PSCustomObject]@{
        Name = "Reboot Route Stability"
        ExitCode = Invoke-TestSuite -Name "Reboot Route Stability" -ScriptPath "tests/reboot_route_stability.ps1" -Arguments $rebootArgs
    }

    Update-ApiKeyFromSession
    $ApiKey = $script:ApiKey
}

Update-ApiKeyFromSession
$ApiKey = $script:ApiKey

$apiArgs = @(
    "-CoreUrl", $CoreUrl,
    "-Username", $Username,
    "-Password", $Password,
    "-ApiKey", $ApiKey
)
if ($RequireDiagnosticsApis) {
    $apiArgs += "-RequireDiagnosticsApis"
}
if ($StrictCustomerConfidence) {
    $apiArgs += "-StrictCustomerConfidence"
}

$results += [PSCustomObject]@{
    Name = "API Endpoint Validation"
    ExitCode = Invoke-TestSuite -Name "API Endpoint Validation" -ScriptPath "tests/api_endpoint_validation.ps1" -Arguments $apiArgs
}

Update-ApiKeyFromSession
$ApiKey = $script:ApiKey

$e2eArgs = @("-CoreUrl", $CoreUrl, "-ApiKey", $ApiKey, "-Username", $Username, "-Password", $Password)
if ($WindowsTarget) {
    $e2eArgs += @("-WindowsTarget", $WindowsTarget)
    if (-not [string]::IsNullOrWhiteSpace($WindowsTargetUsername)) {
        $e2eArgs += @("-WindowsTargetUsername", $WindowsTargetUsername)
    }
    if (-not [string]::IsNullOrWhiteSpace($WindowsTargetPassword)) {
        $e2eArgs += @("-WindowsTargetPassword", $WindowsTargetPassword)
    }
}
if ($LinuxTarget) {
    $e2eArgs += @("-LinuxTarget", $LinuxTarget)
    if (-not [string]::IsNullOrWhiteSpace($LinuxTargetUsername)) {
        $e2eArgs += @("-LinuxTargetUsername", $LinuxTargetUsername)
    }
    if (-not [string]::IsNullOrWhiteSpace($LinuxTargetPassword)) {
        $e2eArgs += @("-LinuxTargetPassword", $LinuxTargetPassword)
    }
}
else {
    $e2eArgs += "-SkipLinuxTests"
}
if ($StrictCustomerConfidence) {
    $e2eArgs += "-StrictCustomerConfidence"
}

$results += [PSCustomObject]@{
    Name = "E2E Validation"
    ExitCode = Invoke-TestSuite -Name "E2E Validation" -ScriptPath "tests/e2e_validation.ps1" -Arguments $e2eArgs
}

Update-ApiKeyFromSession
$ApiKey = $script:ApiKey

$assetArgs = @(
    "-CoreUrl", $CoreUrl,
    "-DiscoveryUrl", $DiscoveryUrl,
    "-Username", $Username,
    "-Password", $Password,
    "-ApiKey", $ApiKey
)
if ($StrictCustomerConfidence) {
    $assetArgs += "-StrictCustomerConfidence"
}

$results += [PSCustomObject]@{
    Name = "Asset Discovery Validation"
    ExitCode = Invoke-TestSuite -Name "Asset Discovery Validation" -ScriptPath "tests/asset_discovery_validation.ps1" -Arguments $assetArgs
}

Write-Header "Release Gate Summary"

foreach ($result in $results) {
    $status = if ($result.ExitCode -eq 0) { "PASS" } elseif ($result.ExitCode -eq 1) { "WARN" } else { "FAIL" }
    Write-Output ("{0,-30} {1,-5} (exit {2})" -f $result.Name, $status, $result.ExitCode)
}

$finalExit = if (($results | Where-Object { $_.ExitCode -ge 2 }).Count -gt 0) {
    2
}
elseif (($results | Where-Object { $_.ExitCode -eq 1 }).Count -gt 0) {
    1
}
else {
    0
}

Write-Output ""
if ($finalExit -eq 0) {
    Write-Output "[PASS] RELEASE GATE PASSED"
}
elseif ($finalExit -eq 1) {
    Write-Output "[WARN] RELEASE GATE HAS WARNINGS"
}
else {
    Write-Output "[FAIL] RELEASE GATE FAILED"
}

exit $finalExit
