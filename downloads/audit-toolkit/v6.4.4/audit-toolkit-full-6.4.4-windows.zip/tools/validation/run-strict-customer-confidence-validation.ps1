<#
.SYNOPSIS
    Run the stricter customer-confidence validation profile.

.DESCRIPTION
    This wrapper runs the standard validation entrypoint with
    `-StrictCustomerConfidence`, which also enables the reporting backfill
    smoke validation suite automatically.

.PARAMETER FullTest
    Include Windows VM tests.

.PARAMETER IncludeLinuxTarget
    Include Linux target validation when a target IP is available.

.PARAMETER WindowsIP
    Windows target IP address for full test runs.

.PARAMETER WindowsTargetUsername
    Optional WinRM username for the Windows target used in strict E2E validation.

.PARAMETER WindowsTargetPassword
    Optional WinRM password for the Windows target used in strict E2E validation.

.PARAMETER LinuxIP
    Optional Linux target IP address for strict E2E validation.

.PARAMETER LinuxTargetUsername
    Optional SSH username for the Linux target used in strict E2E validation.

.PARAMETER LinuxTargetPassword
    Optional SSH password for the Linux target used in strict E2E validation.

.PARAMETER CoreUrl
    Base URL for the core web application.

.PARAMETER DiscoveryUrl
    Base URL for the asset discovery service.

.PARAMETER SkipDocker
    Skip Docker startup and validate host-native services instead.

.EXAMPLE
    .\tools\validation\run-strict-customer-confidence-validation.ps1 -SkipDocker
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Validation wrapper intentionally emits clear pass/fail operator output')]
param(
    [switch]$FullTest,
    [switch]$IncludeLinuxTarget,
    [string]$WindowsIP = '192.168.1.100',
    [string]$LinuxIP = '',
    [string]$WindowsTargetUsername = '',
    [string]$WindowsTargetPassword = '',
    [string]$LinuxTargetUsername = '',
    [string]$LinuxTargetPassword = '',
    [string]$CoreUrl = 'http://localhost:5000',
    [string]$DiscoveryUrl = 'http://localhost:8080',
    [switch]$SkipDocker
)

$ErrorActionPreference = 'Stop'

$runnerPath = Join-Path $PSScriptRoot 'run-validation.ps1'
if (-not (Test-Path $runnerPath)) {
    throw "Validation runner not found at $runnerPath"
}

$runnerArgs = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $runnerPath,
    '-StrictCustomerConfidence',
    '-CoreUrl', $CoreUrl,
    '-DiscoveryUrl', $DiscoveryUrl,
    '-WindowsIP', $WindowsIP,
    '-LinuxIP', $LinuxIP
)

if (-not [string]::IsNullOrWhiteSpace($WindowsTargetUsername)) {
    $runnerArgs += @('-WindowsTargetUsername', $WindowsTargetUsername)
}

if (-not [string]::IsNullOrWhiteSpace($WindowsTargetPassword)) {
    $runnerArgs += @('-WindowsTargetPassword', $WindowsTargetPassword)
}

if (-not [string]::IsNullOrWhiteSpace($LinuxTargetUsername)) {
    $runnerArgs += @('-LinuxTargetUsername', $LinuxTargetUsername)
}

if (-not [string]::IsNullOrWhiteSpace($LinuxTargetPassword)) {
    $runnerArgs += @('-LinuxTargetPassword', $LinuxTargetPassword)
}

if ($FullTest) {
    $runnerArgs += '-FullTest'
}

if ($IncludeLinuxTarget) {
    $runnerArgs += '-IncludeLinuxTarget'
}

if ($SkipDocker) {
    $runnerArgs += '-SkipDocker'
}

& pwsh @runnerArgs
exit $LASTEXITCODE
