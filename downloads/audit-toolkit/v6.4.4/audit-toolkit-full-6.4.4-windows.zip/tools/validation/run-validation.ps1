﻿<#
.SYNOPSIS
    Run the pre-release validation workflow for the Audit Toolkit.

.DESCRIPTION
    This script validates the core application and optional target environments.
    It can also run the reporting backfill smoke validation suite when
    `-IncludeReportingBackfillSmoke` is supplied, and strict customer-confidence
    runs enable that suite automatically.

.PARAMETER FullTest
    Include Windows VM tests.

.PARAMETER IncludeLinuxTarget
    Include Linux target validation when a target IP is available.

.PARAMETER IncludeReportingBackfillSmoke
    Run the reporting backfill smoke validation suite after the core API is ready.

.PARAMETER StrictCustomerConfidence
    Enable stricter release-gate behavior. This also enables the reporting
    backfill smoke validation suite.

.PARAMETER WindowsIP
    Windows target IP address for full test runs.

.PARAMETER WindowsTargetUsername
    Optional WinRM username for the Windows target used in E2E validation.

.PARAMETER WindowsTargetPassword
    Optional WinRM password for the Windows target used in E2E validation.

.PARAMETER LinuxIP
    Optional Linux target IP address for host-native or manual strict E2E runs.

.PARAMETER LinuxTargetUsername
    Optional SSH username for the Linux target used in E2E validation.

.PARAMETER LinuxTargetPassword
    Optional SSH password for the Linux target used in E2E validation.

.PARAMETER CoreUrl
    Base URL for the core web application.

.PARAMETER DiscoveryUrl
    Base URL for the asset discovery service.

.PARAMETER SkipDocker
    Skip Docker startup and validate host-native services instead.

.EXAMPLE
    .\tools\validation\run-validation.ps1 -SkipDocker -IncludeReportingBackfillSmoke
#>

# Quick Start: Pre-Release Validation
# Run this single script to validate entire system

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Validation runner intentionally uses Write-Host for colorized status output and release-style operator summaries')]
param(
    [switch]$FullTest,  # Include Windows VM tests
    [switch]$IncludeLinuxTarget,
    [switch]$IncludeReportingBackfillSmoke,
    [switch]$StrictCustomerConfidence,
    [string]$WindowsIP = "192.168.1.100",
    [string]$LinuxIP = "",
    [string]$WindowsTargetUsername = "",
    [string]$WindowsTargetPassword = "",
    [string]$LinuxTargetUsername = "",
    [string]$LinuxTargetPassword = "",
    [string]$CoreUrl = "http://localhost:5000",
    [string]$DiscoveryUrl = "http://localhost:8080",
    [switch]$SkipDocker
)

$ErrorActionPreference = "Stop"
$shouldRunReportingBackfillSmoke = $IncludeReportingBackfillSmoke -or $StrictCustomerConfidence
$validationUsername = if (-not [string]::IsNullOrWhiteSpace($env:TOOLKIT_SMOKE_USERNAME)) { $env:TOOLKIT_SMOKE_USERNAME } else { 'admin' }
$validationPassword = if (-not [string]::IsNullOrWhiteSpace($env:TOOLKIT_SMOKE_PASSWORD)) { $env:TOOLKIT_SMOKE_PASSWORD } else { 'DemoScreenshots123!' }

function Get-ComposeCommand {
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        try {
            docker compose version | Out-Null
            return @("docker", "compose")
        }
        catch {
            # Fall back to docker-compose below
            Write-Verbose 'docker compose unavailable, trying docker-compose fallback.'
        }
    }

    if (Get-Command docker-compose -ErrorAction SilentlyContinue) {
        return @("docker-compose")
    }

    throw "Neither 'docker compose' nor 'docker-compose' is available in PATH."
}

function Invoke-Compose {
    param(
        [string[]]$ComposeArgs
    )

    $composeCmd = Get-ComposeCommand
    if ($composeCmd.Count -eq 2) {
        & $composeCmd[0] $composeCmd[1] @ComposeArgs
    }
    else {
        & $composeCmd[0] @ComposeArgs
    }

    if ($LASTEXITCODE -ne 0) {
        throw "Compose command failed: $($composeCmd -join ' ') $($ComposeArgs -join ' ')"
    }
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Audit Toolkit - Pre-Release Validation" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

if (-not $SkipDocker) {
    # Step 1: Ensure Docker is running
    Write-Host "[1/6] Checking Docker..." -ForegroundColor Yellow
    try {
        docker ps | Out-Null
        Get-ComposeCommand | Out-Null
        Write-Host "✅ Docker is running`n" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Docker is not running. Use -SkipDocker to validate host-native deployment.`n" -ForegroundColor Red
        exit 1
    }

    # Step 2: Start core application
    Write-Host "[2/6] Starting core application..." -ForegroundColor Yellow
    Invoke-Compose -ComposeArgs @("up", "-d")
    Start-Sleep -Seconds 10
    Write-Host "✅ Core application started`n" -ForegroundColor Green

    # Step 3: Start test targets
    Write-Host "[3/6] Starting test targets..." -ForegroundColor Yellow
    $testTargetServices = @(
        "test-ubuntu-22",
        "test-debian-11",
        "test-alma-8",
        "test-alpine",
        "test-network-tools"
    )

    try {
        Invoke-Compose -ComposeArgs (@("-f", "docker-compose.test-targets.yml", "up", "-d") + $testTargetServices)
        Start-Sleep -Seconds 25

        $ubuntuTargetRunning = $false
        try {
            $ubuntuContainerId = (docker compose -f docker-compose.test-targets.yml ps -q test-ubuntu-22 2>$null).Trim()
            if (-not [string]::IsNullOrWhiteSpace($ubuntuContainerId)) {
                $ubuntuTargetRunning = $true
            }
        }
        catch {
            $ubuntuTargetRunning = $false
        }

        if ($ubuntuTargetRunning) {
            Write-Host "✅ Test targets started`n" -ForegroundColor Green
        }
        else {
            Write-Host "⚠️  Test targets command completed, but Linux target container was not detected.`n" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "⚠️  Test targets failed to start: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "    Continuing with core validation only.`n" -ForegroundColor Yellow
    }

    # Step 4: Get Linux target IP
    Write-Host "[4/6] Discovering test target IPs..." -ForegroundColor Yellow
    $resolvedLinuxIP = $LinuxIP
    try {
        if ([string]::IsNullOrWhiteSpace($resolvedLinuxIP)) {
            $ubuntuContainerId = (docker compose -f docker-compose.test-targets.yml ps -q test-ubuntu-22 2>$null).Trim()
            if (-not [string]::IsNullOrWhiteSpace($ubuntuContainerId)) {
                $resolvedLinuxIP = (docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' $ubuntuContainerId 2>$null).Trim()
            }
        }
    }
    catch {
        if ([string]::IsNullOrWhiteSpace($resolvedLinuxIP)) {
            $resolvedLinuxIP = ""
        }
    }

    if ([string]::IsNullOrWhiteSpace($resolvedLinuxIP)) {
        Write-Host "⚠️  Linux target not detected (continuing without -LinuxTarget).`n" -ForegroundColor Yellow
    }
    else {
        Write-Host "✅ Linux Target: $resolvedLinuxIP`n" -ForegroundColor Green
    }
}
else {
    Write-Host "[1/6] Docker startup skipped (-SkipDocker). Using host-native services.`n" -ForegroundColor Yellow
    $resolvedLinuxIP = $LinuxIP
}

if ($FullTest) {
    Write-Host "ℹ️  Windows Target: $WindowsIP (ensure Hyper-V VM is running)`n" -ForegroundColor Cyan
}

# Step 5: Wait for core to be ready
Write-Host "[5/6] Waiting for core API to be ready..." -ForegroundColor Yellow
$MaxRetries = 90
$Retry = 0
$Ready = $false

while ($Retry -lt $MaxRetries -and -not $Ready) {
    $response = $null
    try {
        $response = Invoke-WebRequest -Uri "$CoreUrl/health" -UseBasicParsing -TimeoutSec 20 -ErrorAction SilentlyContinue
    }
    catch {
        $response = $null
    }

    if ($response -and $response.StatusCode -eq 200) {
        $Ready = $true
        break
    }

    if (-not $Ready) {
        Start-Sleep -Seconds 2
        $Retry++
        Write-Host "." -NoNewline
    }
}

if ($Ready) {
    Write-Host "`n✅ Core API is ready`n" -ForegroundColor Green
}
else {
    Write-Host "`n❌ Core API not responding after readiness wait`n" -ForegroundColor Red
    Write-Host "(waited approximately 180 seconds)`n" -ForegroundColor Yellow
    Write-Host "Check logs: docker-compose logs web`n" -ForegroundColor Yellow
    exit 1
}

if ($shouldRunReportingBackfillSmoke) {
    Write-Host "[6/7] Running reporting backfill smoke validation suite...`n" -ForegroundColor Yellow
    $reportingSmokeSuite = Join-Path $PSScriptRoot 'validate-reporting-backfill-smoke-suite.ps1'
    $smokeArgs = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', $reportingSmokeSuite,
        '-BaseUrl', $CoreUrl,
        '-Username', $validationUsername,
        '-Password', $validationPassword
    )

    if (-not (Test-Path $reportingSmokeSuite)) {
        Write-Host "❌ Reporting backfill smoke validation suite not found: $reportingSmokeSuite`n" -ForegroundColor Red
        exit 1
    }

    $smokeArgs += '-ResetAdmin'
    & pwsh @smokeArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Reporting backfill smoke validation suite failed`n" -ForegroundColor Red
        exit 1
    }

    Write-Host "✅ Reporting backfill smoke validation suite passed`n" -ForegroundColor Green
}

# Step 6: Run consolidated release gate
$releaseGateStepLabel = if ($shouldRunReportingBackfillSmoke) { '[7/7]' } else { '[6/6]' }
Write-Host "$releaseGateStepLabel Running consolidated release gate...`n" -ForegroundColor Yellow
Write-Host "========================================`n" -ForegroundColor Cyan

$releaseGateArgs = @("-CoreUrl", $CoreUrl, "-DiscoveryUrl", $DiscoveryUrl, "-RequireDiagnosticsApis")
if ($shouldRunReportingBackfillSmoke) {
    $releaseGateArgs += @('-Username', $validationUsername, '-Password', $validationPassword)
}
if ($StrictCustomerConfidence) {
    $releaseGateArgs += "-StrictCustomerConfidence"
}
if ($SkipDocker) {
    $releaseGateArgs += "-SkipRebootStability"
}
if ($IncludeLinuxTarget -and -not [string]::IsNullOrWhiteSpace($resolvedLinuxIP)) {
    $releaseGateArgs += @("-LinuxTarget", $resolvedLinuxIP)
    if (-not [string]::IsNullOrWhiteSpace($LinuxTargetUsername)) {
        $releaseGateArgs += @("-LinuxTargetUsername", $LinuxTargetUsername)
    }
    if (-not [string]::IsNullOrWhiteSpace($LinuxTargetPassword)) {
        $releaseGateArgs += @("-LinuxTargetPassword", $LinuxTargetPassword)
    }
}
if ($FullTest -or ($StrictCustomerConfidence -and -not [string]::IsNullOrWhiteSpace($WindowsIP))) {
    $releaseGateArgs += @("-WindowsTarget", $WindowsIP)
}
if (-not [string]::IsNullOrWhiteSpace($WindowsTargetUsername)) {
    $releaseGateArgs += @("-WindowsTargetUsername", $WindowsTargetUsername)
}
if (-not [string]::IsNullOrWhiteSpace($WindowsTargetPassword)) {
    $releaseGateArgs += @("-WindowsTargetPassword", $WindowsTargetPassword)
}

if ($IncludeLinuxTarget -and [string]::IsNullOrWhiteSpace($resolvedLinuxIP)) {
    Write-Host "⚠️  -IncludeLinuxTarget was requested, but no Linux target IP was discovered." -ForegroundColor Yellow
}

$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$gateScript = Join-Path $repoRoot "run-release-gate.ps1"
pwsh -NoProfile -ExecutionPolicy Bypass -File $gateScript @releaseGateArgs

$TestExitCode = $LASTEXITCODE

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Validation Complete!" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

if ($TestExitCode -eq 0) {
    Write-Host "✅ System is READY FOR RELEASE!" -ForegroundColor Green
    Write-Host "`nNext steps:" -ForegroundColor Cyan
    Write-Host "  1. Review test results JSON file" -ForegroundColor White
    Write-Host "  2. Complete cleanup tasks (see docs/RELEASE-PREP-ACTION-PLAN.md)" -ForegroundColor White
    Write-Host "  3. Tag release version" -ForegroundColor White
    Write-Host "  4. Push to public GitHub`n" -ForegroundColor White
}
elseif ($TestExitCode -eq 1) {
    Write-Host "⚠️  Some tests failed - review and fix before release`n" -ForegroundColor Yellow
}
else {
    Write-Host "❌ Critical failures detected - DO NOT RELEASE`n" -ForegroundColor Red
}

Write-Host "View logs:" -ForegroundColor Cyan
if (-not $SkipDocker) {
    Write-Host "  docker compose logs web" -ForegroundColor White
    Write-Host "  docker compose -f docker-compose.test-targets.yml logs`n" -ForegroundColor White
}
else {
    Write-Host "  Host-mode logs depend on your local process manager (for example, terminal output, NSSM, or systemd).`n" -ForegroundColor White
}

exit $TestExitCode
