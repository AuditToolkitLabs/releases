[CmdletBinding()]
param(
    [string[]]$Distros = @('Debian', 'FedoraLinux-42'),
    [string]$WindowsTarget,
    [string]$WindowsTargetUsername = '',
    [string]$WindowsTargetPassword = '',
    [string]$LinuxTargetUsername = 'auditadmin',
    [string]$LinuxTargetPassword = 'ChangeMe123!',
    [string]$CoreUrl = 'http://127.0.0.1:5000',
    [string]$Username = 'admin',
    [string]$Password = 'DemoScreenshots123!',
    [string]$ResultsDirectory = '',
    [switch]$StrictCustomerConfidence
)

$ErrorActionPreference = 'Stop'

    function Resolve-DistroList {
        param([string[]]$ConfiguredDistros)

        $resolved = @()
        foreach ($entry in $ConfiguredDistros) {
            if ([string]::IsNullOrWhiteSpace($entry)) {
                continue
            }

            foreach ($candidate in ($entry -split '[,;\r\n]')) {
                $trimmed = $candidate.Trim()
                if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
                    $resolved += $trimmed
                }
            }
        }

        return @($resolved | Select-Object -Unique)
    }

    $Distros = Resolve-DistroList -ConfiguredDistros $Distros
    if ($Distros.Count -eq 0) {
        throw 'At least one WSL distro must be provided.'
    }

$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$e2eScript = Join-Path $repoRoot 'tests\e2e_validation.ps1'

if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
    throw 'wsl.exe is not available in PATH.'
}

if (-not (Test-Path $e2eScript)) {
    throw "E2E validation script not found at $e2eScript"
}

if ([string]::IsNullOrWhiteSpace($WindowsTarget)) {
    throw 'WindowsTarget is required for mixed-host WSL validation.'
}

if ([string]::IsNullOrWhiteSpace($ResultsDirectory)) {
    $ResultsDirectory = Join-Path $repoRoot 'artifacts\validation'
}

New-Item -ItemType Directory -Force -Path $ResultsDirectory | Out-Null

function Invoke-WslBash {
    param(
        [string]$Distro,
        [string]$Command,
        [switch]$AllowFailure,
        [switch]$AsRoot
    )

    $normalizedCommand = ($Command -replace "`r`n", "`n" -replace "`r", "`n").Trim()
    $wslArgs = @('-d', $Distro)
    if ($AsRoot) {
        $wslArgs += @('-u', 'root')
    }
    $wslArgs += @('--', 'bash', '-lc', $normalizedCommand)

    $output = & wsl.exe @wslArgs 2>&1
    $exitCode = $LASTEXITCODE
    $text = ($output | Out-String).Trim()

    if ($exitCode -ne 0 -and -not $AllowFailure) {
        throw "WSL command failed for distro '$Distro' (exit $exitCode): $text"
    }

    return [pscustomobject]@{
        ExitCode = $exitCode
        Output = $text
    }
}

function Stop-WslSshService {
    param([string]$Distro)

    $stopCommand = @'
if systemctl list-unit-files ssh.socket >/dev/null 2>&1; then
    systemctl stop ssh.socket || true
fi
if systemctl list-unit-files sshd.socket >/dev/null 2>&1; then
    systemctl stop sshd.socket || true
fi
if systemctl list-unit-files ssh.service >/dev/null 2>&1; then
    systemctl stop ssh || true
fi
if systemctl list-unit-files sshd.service >/dev/null 2>&1; then
    systemctl stop sshd || true
fi
'@

    Invoke-WslBash -Distro $Distro -Command $stopCommand -AllowFailure -AsRoot | Out-Null
}

function Start-WslSshService {
    param([string]$Distro)

    $startCommand = @'
set -euo pipefail
mkdir -p /run/sshd
if systemctl list-unit-files ssh.service >/dev/null 2>&1; then
    systemctl start ssh
    systemctl is-active ssh
  exit 0
fi
if systemctl list-unit-files sshd.service >/dev/null 2>&1; then
    systemctl start sshd
    systemctl is-active sshd
  exit 0
fi
echo "No ssh or sshd service found" >&2
exit 97
'@

    $result = Invoke-WslBash -Distro $Distro -Command $startCommand -AsRoot
    if ($result.Output -notmatch 'active') {
        throw "SSH service did not report active for distro '$Distro': $($result.Output)"
    }
}

function Get-WslPrettyName {
    param([string]$Distro)

    $prettyNameCommand = @'
grep '^PRETTY_NAME=' /etc/os-release | head -n 1 | cut -d= -f2- | tr -d '"'
'@
    return (Invoke-WslBash -Distro $Distro -Command $prettyNameCommand -AsRoot).Output
}

function Get-WslTargetIp {
    param([string]$Distro)

    $ipCommand = @'
ip -4 -o addr show dev eth0 | sed -n 's/.* inet \([0-9.]*\)\/.*/\1/p' | grep -v '^10\.255\.255\.254$' | head -n 1
'@
    $targetIp = (Invoke-WslBash -Distro $Distro -Command $ipCommand -AsRoot).Output
    if ([string]::IsNullOrWhiteSpace($targetIp)) {
        throw "Could not resolve a reachable IPv4 address for distro '$Distro'."
    }

    return $targetIp.Trim()
}

function Test-SshReachability {
    param([string]$Address)

    $reachable = Test-NetConnection -ComputerName $Address -Port 22 -WarningAction SilentlyContinue
    return [bool]$reachable.TcpTestSucceeded
}

$matrixResults = @()

Write-Host '========================================' -ForegroundColor Cyan
Write-Host '  WSL Distro Validation Matrix' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ("  Distros queued: {0}" -f (($Distros -join ', '))) -ForegroundColor Cyan
Write-Host ''

for ($index = 0; $index -lt $Distros.Count; $index++) {
    $distro = $Distros[$index]
    Write-Host ("[RUN {0}/{1}] Preparing WSL distro: {2}" -f ($index + 1), $Distros.Count, $distro) -ForegroundColor Yellow

    foreach ($otherDistro in $Distros) {
        if ($otherDistro -ne $distro) {
            Stop-WslSshService -Distro $otherDistro
        }
    }

    Start-WslSshService -Distro $distro
    $prettyName = Get-WslPrettyName -Distro $distro
    $linuxTargetIp = Get-WslTargetIp -Distro $distro

    if (-not (Test-SshReachability -Address $linuxTargetIp)) {
        throw "SSH target $linuxTargetIp for distro '$distro' is not reachable from Windows."
    }

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safeDistroName = ($distro -replace '[^A-Za-z0-9._-]', '_')
    $logPath = Join-Path $ResultsDirectory ("wsl-$safeDistroName-$timestamp.log")

    Write-Host "      Distro: $prettyName" -ForegroundColor Cyan
    Write-Host "      Linux Target IP: $linuxTargetIp" -ForegroundColor Cyan
    Write-Host "      Log: $logPath" -ForegroundColor Cyan

    $e2eArgs = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', $e2eScript,
        '-CoreUrl', $CoreUrl,
        '-Username', $Username,
        '-Password', $Password,
        '-WindowsTarget', $WindowsTarget,
        '-WindowsTargetUsername', $WindowsTargetUsername,
        '-WindowsTargetPassword', $WindowsTargetPassword,
        '-LinuxTarget', $linuxTargetIp,
        '-LinuxTargetUsername', $LinuxTargetUsername,
        '-LinuxTargetPassword', $LinuxTargetPassword
    )

    if ($StrictCustomerConfidence) {
        $e2eArgs += '-StrictCustomerConfidence'
    }

    & pwsh @e2eArgs *>&1 | Tee-Object -FilePath $logPath
    $exitCode = $LASTEXITCODE

    $matrixResults += [pscustomobject]@{
        Distro = $distro
        PrettyName = $prettyName
        LinuxTarget = $linuxTargetIp
        ExitCode = $exitCode
        LogPath = $logPath
    }

    if ($exitCode -ne 0) {
        throw "E2E validation failed for distro '$distro'. See $logPath"
    }

    Write-Host "[PASS] $prettyName" -ForegroundColor Green
    Write-Host ''
}

Write-Host '========================================' -ForegroundColor Cyan
Write-Host '  WSL Validation Summary' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
foreach ($result in $matrixResults) {
    Write-Host ("{0} -> PASS ({1})" -f $result.PrettyName, $result.LogPath) -ForegroundColor Green
}

exit 0
