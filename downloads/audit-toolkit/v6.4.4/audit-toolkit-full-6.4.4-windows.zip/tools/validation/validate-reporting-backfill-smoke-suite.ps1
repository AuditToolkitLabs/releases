[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Validation helper intentionally emits clear pass/fail operator output')]
param(
    [string]$BaseUrl = 'http://127.0.0.1:5000',
    [switch]$ResetAdmin,
    [switch]$Headful,
    [string]$Username = 'admin',
    [string]$Password = 'DemoScreenshots123!'
)

$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$wrapperPath = Join-Path $repoRoot 'tools\run-reporting-backfill-smoke.ps1'
$negativeValidationPath = Join-Path $PSScriptRoot 'validate-reporting-backfill-smoke-wrapper.ps1'

if (-not (Test-Path $wrapperPath)) {
    throw "Wrapper script not found at $wrapperPath"
}

if (-not (Test-Path $negativeValidationPath)) {
    throw "Negative-path validation script not found at $negativeValidationPath"
}

Write-Host '========================================' -ForegroundColor Cyan
Write-Host '  Reporting Backfill Smoke Validation' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''

Write-Host '[1/2] Running positive smoke wrapper check...' -ForegroundColor Yellow
$wrapperArgs = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $wrapperPath,
    '-BaseUrl', $BaseUrl,
    '-Username', $Username,
    '-Password', $Password
)
if ($ResetAdmin) {
    $wrapperArgs += '-ResetAdmin'
}
if ($Headful) {
    $wrapperArgs += '-Headful'
}

& pwsh @wrapperArgs
if ($LASTEXITCODE -ne 0) {
    throw "Positive smoke wrapper check failed with exit code $LASTEXITCODE"
}
Write-Host '✅ Positive smoke wrapper check passed.' -ForegroundColor Green
Write-Host ''

Write-Host '[2/2] Running negative wrapper validation...' -ForegroundColor Yellow
& pwsh -NoProfile -ExecutionPolicy Bypass -File $negativeValidationPath
if ($LASTEXITCODE -ne 0) {
    throw "Negative wrapper validation failed with exit code $LASTEXITCODE"
}
Write-Host '✅ Negative wrapper validation passed.' -ForegroundColor Green
Write-Host ''

Write-Host '✅ Reporting backfill smoke validation suite passed.' -ForegroundColor Green
exit 0
