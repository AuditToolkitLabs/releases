[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Validation helper intentionally emits clear pass/fail operator output')]
param(
    [string]$MissingSmokeScriptPath = 'tools\does-not-exist.py'
)

$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$wrapperPath = Join-Path $repoRoot 'tools\run-reporting-backfill-smoke.ps1'

if (-not (Test-Path $wrapperPath)) {
    throw "Wrapper script not found at $wrapperPath"
}

Write-Host '========================================' -ForegroundColor Cyan
Write-Host '  Reporting Backfill Smoke Wrapper Check' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''
Write-Host "Expecting wrapper failure for missing smoke script: $MissingSmokeScriptPath" -ForegroundColor Yellow

$output = & pwsh -NoProfile -ExecutionPolicy Bypass -File $wrapperPath -SmokeScriptPath $MissingSmokeScriptPath 2>&1
$exitCode = $LASTEXITCODE
$outputText = ($output | Out-String)

Write-Host ''
Write-Host 'Wrapper output:' -ForegroundColor Cyan
Write-Host $outputText.TrimEnd()
Write-Host ''

if ($exitCode -eq 0) {
    throw 'Wrapper unexpectedly succeeded for an invalid smoke script path.'
}

if ($outputText -notmatch 'Smoke script not found') {
    throw 'Wrapper failed, but did not report the expected missing smoke script message.'
}

Write-Host '✅ Wrapper negative-path validation passed.' -ForegroundColor Green
exit 0
