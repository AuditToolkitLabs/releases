#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LINUX_DIR="$REPO_ROOT/deployment/linux"

DEB="$LINUX_DIR/bin/audit-toolkit_6.0.0_all.deb"
RPM="$LINUX_DIR/bin/audit-toolkit-5.6.1-0.beta.1.noarch.rpm"

check_contains() {
    local listing="$1"
    local expected="$2"
    if ! grep -Fqx "$expected" <<< "$listing"; then
        echo "MISSING: $expected" >&2
        return 1
    fi
}

echo "Checking DEB payload..."
deb_listing="$(dpkg-deb --contents "$DEB" | awk '{print $NF}')"
check_contains "$deb_listing" "./opt/audit-toolkit/mail_delivery.py"
check_contains "$deb_listing" "./opt/audit-toolkit/VERSION"
check_contains "$deb_listing" "./opt/audit-toolkit/deployment/vm-appliance/appliance-updater.sh"
check_contains "$deb_listing" "./opt/audit-toolkit/deployment/vm-appliance/scripts/first-boot-setup.sh"
check_contains "$deb_listing" "./opt/audit-toolkit/deployment/vm-appliance/scripts/appliance-setup.sh"

echo "Checking RPM payload..."
rpm_listing="$(rpm -qpl "$RPM")"
check_contains "$rpm_listing" "/opt/audit-toolkit/mail_delivery.py"
check_contains "$rpm_listing" "/opt/audit-toolkit/VERSION"
check_contains "$rpm_listing" "/opt/audit-toolkit/deployment/vm-appliance/appliance-updater.sh"
check_contains "$rpm_listing" "/opt/audit-toolkit/deployment/vm-appliance/scripts/first-boot-setup.sh"
check_contains "$rpm_listing" "/opt/audit-toolkit/deployment/vm-appliance/scripts/appliance-setup.sh"

echo "Payload verification passed."
