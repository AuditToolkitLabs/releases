[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [string]$HostAlias = "audittoolkit-vm",
    [switch]$AllowPasswordPrompt
)

$ErrorActionPreference = "Stop"

Write-Output "Running Alembic upgrade/state checks on $HostAlias"

function Get-SshOptions {
    param(
        [int]$ConnectTimeout = 15
    )

    $options = @("-o", "ConnectTimeout=$ConnectTimeout")
    if (-not $AllowPasswordPrompt) {
        $options += @("-o", "BatchMode=yes", "-o", "NumberOfPasswordPrompts=0")
    }

    return $options
}

if (-not $AllowPasswordPrompt) {
    & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "echo '[preflight] ssh-auth-ok'" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "SSH preflight failed in non-interactive mode. Configure key-based auth for '$HostAlias' or rerun with -AllowPasswordPrompt."
    }
}

$remoteScript = @'
set -euo pipefail
cd /opt/audit-toolkit
export DATABASE_URL='postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit'
NEEDS_STAMP="$(/opt/audit-toolkit/.venv/bin/python - <<'PY'
from sqlalchemy import create_engine, inspect, text

engine = create_engine('postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit')

with engine.begin() as conn:
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS alembic_version (
            version_num VARCHAR(255) NOT NULL PRIMARY KEY
        )
    """))

inspector = inspect(engine)
table_names = set(inspector.get_table_names())
with engine.connect() as conn:
    version_rows = conn.execute(text("select count(*) from alembic_version")).scalar() or 0

print(f"schema_tables={len(table_names)}")
print(f"alembic_rows={version_rows}")
print("1" if ("servers" in table_names and version_rows == 0) else "0")
PY
)"

if [[ "$NEEDS_STAMP" == *$'\n1' ]]; then
    echo "alembic_action=stamp_head"
    /opt/audit-toolkit/.venv/bin/python -m alembic stamp head
else
    echo "alembic_action=upgrade_only"
    /opt/audit-toolkit/.venv/bin/python -m alembic upgrade head
fi
/opt/audit-toolkit/.venv/bin/python -m alembic current -v || true
echo "alembic_version_rows"
/opt/audit-toolkit/.venv/bin/python -c "from sqlalchemy import create_engine, text; engine=create_engine('postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit'); rows=engine.connect().execute(text(\"select version_num from alembic_version order by version_num\")).fetchall(); [print(r[0]) for r in rows]"
'@

$remoteScript = $remoteScript -replace "`r`n", "`n"
$remoteScript = $remoteScript -replace "`r", ""
$remoteScript | & ssh -T @(Get-SshOptions -ConnectTimeout 15) $HostAlias "bash --noprofile --norc -se"
$exitCode = $LASTEXITCODE

if ($exitCode -ne 0) {
    throw "VM Alembic upgrade/state failed with exit code $exitCode"
}

Write-Output "Alembic upgrade/state checks completed."
