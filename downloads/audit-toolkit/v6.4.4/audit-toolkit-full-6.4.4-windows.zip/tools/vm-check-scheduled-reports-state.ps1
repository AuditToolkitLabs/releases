[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [string]$HostAlias = "audittoolkit-vm",
    [switch]$AllowPasswordPrompt
)

$ErrorActionPreference = "Stop"

Write-Output "Running scheduled_reports checks on $HostAlias"

function Get-SshOptions {
    param(
        [int]$ConnectTimeout = 15
    )

    $options = @("-o", "ConnectTimeout=$ConnectTimeout")
    if (-not $AllowPasswordPrompt) {
        $options += @("-o", "BatchMode=yes", "-o", "NumberOfPasswordPrompts=0")
    }

    return $options
}

if (-not $AllowPasswordPrompt) {
    & ssh -T @(Get-SshOptions -ConnectTimeout 10) $HostAlias "echo '[preflight] ssh-auth-ok'" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "SSH preflight failed in non-interactive mode. Configure key-based auth for '$HostAlias' or rerun with -AllowPasswordPrompt."
    }
}

$remoteScript = @'
set -euo pipefail
for db in /opt/audit-toolkit/audit_toolkit.db /opt/audit-toolkit/web/audit_toolkit.db; do
    if [[ -f "$db" ]]; then
        echo "db=$db"
        if command -v sqlite3 >/dev/null 2>&1; then
            sqlite3 "$db" "select count(*) from sqlite_master where type='table' and name='scheduled_reports';"
        else
            echo "sqlite3_unavailable"
        fi
    else
        echo "db=$db missing"
    fi
done

echo "runtime_pg_scheduled_reports"
/opt/audit-toolkit/.venv/bin/python -c "from sqlalchemy import create_engine, text; engine=create_engine('postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit'); value=engine.connect().execute(text(\"select to_regclass('public.scheduled_reports')\")).scalar(); print(value or '')"
'@

$remoteScript = $remoteScript -replace "`r`n", "`n"
$remoteScript = $remoteScript -replace "`r", ""
$remoteScript | & ssh -T @(Get-SshOptions -ConnectTimeout 15) $HostAlias "bash --noprofile --norc -se"
$exitCode = $LASTEXITCODE

if ($exitCode -ne 0) {
    throw "VM scheduled_reports checks failed with exit code $exitCode"
}

Write-Output "scheduled_reports checks completed."
