#!/usr/bin/env pwsh
# VM Appliance Cleanup Script - Prepare offline VM for OVA Export
# Purpose: Verify packages, clean lab config, prepare for export (NO network upgrades)
# Target: AuditToolkit-OVA-Verify (192.168.100.52 - OFFLINE)

param(
    [string]$VMHost = "192.168.100.52",
    [string]$VMUser = "auditadmin",
    [string]$ToolkitRoot = "/opt/audit-toolkit"
)

$null = $VMUser

$ErrorActionPreference = "Stop"

# Simple SSH wrapper
function ssh_run {
    param([string]$cmd)
    ssh -n $VMUser@$VMHost $cmd 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "SSH exit code: $LASTEXITCODE"
    }
}

Write-Output "=== VM Cleanup Script (Offline) ==="
Write-Output "Target: $VMHost (NO internet - packages pre-installed)"
Write-Output ""

# Phase 1: Verify current packages
Write-Output "[1] Checking installed packages..."
ssh_run "echo '=== Redis ==='; $ToolkitRoot/.venv/bin/pip show redis | head -3"
ssh_run "echo '=== Flask ==='; $ToolkitRoot/.venv/bin/pip show flask | head -3"
Write-Output "    [OK]"

# Phase 2: Clean first-boot markers
Write-Output "[2] Removing first-boot markers..."
ssh_run "sudo rm -f $ToolkitRoot/.first-boot-complete $ToolkitRoot/.first-boot /root/.first-boot-complete 2>/dev/null; echo 'Cleaned'"
Write-Output "    [OK]"

# Phase 3: Clear logs
Write-Output "[3] Removing build logs..."
ssh_run "find $ToolkitRoot -name '*.log' -type f -delete 2>/dev/null; find /var/log -name '*audit*' -type f -delete 2>/dev/null || true; echo 'Logs cleared'"
Write-Output "    [OK]"

# Phase 4: Remove lab config
Write-Output "[4] Removing lab configuration..."
ssh_run "sudo rm -f $ToolkitRoot/.env.lab $ToolkitRoot/.env.local /root/.env.lab 2>/dev/null; echo 'Lab config removed'"
Write-Output "    [OK]"

# Phase 5: Cloud-init
Write-Output "[5] Clearing cloud-init state..."
ssh_run "sudo cloud-init clean --seed --logs 2>/dev/null || echo 'cloud-init: N/A'"
Write-Output "    [OK]"

# Phase 6: Clear history
Write-Output "[6] Clearing shell history..."
ssh_run "cat /dev/null > ~/.bash_history && sudo cat /dev/null > /root/.bash_history 2>/dev/null; echo 'History cleared'"
Write-Output "    [OK]"

# Phase 7: Shutdown
Write-Output "[7] Initiating graceful shutdown..."
Write-Output "    VM will poweroff in 10 seconds..."
ssh_run "sleep 10; sudo systemctl isolate poweroff"

Write-Output ""
Write-Output "=== VM Cleaned and Shutdown ==="
Write-Output "Next: Export VM as OVA/VMDK via Hyper-V"
