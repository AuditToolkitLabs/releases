#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/audit-toolkit"
APP_ENV="${APP_DIR}/.env"
APP_DB_URL="postgresql://audittoolkit:Atk!7Xq3vL9mP2_kZ5nR8@localhost:5432/audittoolkit"
APP_REDIS_URL="redis://localhost:6379/1"

set_env_var() {
  local key="$1"
  local value="$2"
  local file="$3"

  if grep -q "^${key}=" "$file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    echo "${key}=${value}" >> "$file"
  fi
}

echo "[step] enforce app env PostgreSQL target"
if [[ ! -f "$APP_ENV" ]]; then
  touch "$APP_ENV"
fi
sed -i 's/\r$//' "$APP_ENV"
set_env_var "DATABASE_URL" "$APP_DB_URL" "$APP_ENV"
set_env_var "REDIS_URL" "$APP_REDIS_URL" "$APP_ENV"
set_env_var "REDIS_ENABLED" "true" "$APP_ENV"
chmod 600 "$APP_ENV"

echo "[info] effective env settings"
grep -E '^(DATABASE_URL|REDIS_URL|REDIS_ENABLED)=' "$APP_ENV" || true

echo "[step] ensure systemd units load app env file"
for svc in audit-toolkit audit-toolkit-celery audit-toolkit-celery-beat; do
  unit_file="/etc/systemd/system/${svc}.service"
  if [[ -f "$unit_file" ]] && ! grep -q '^EnvironmentFile=-/opt/audit-toolkit/.env' "$unit_file"; then
    sed -i '/^WorkingDirectory=/a EnvironmentFile=-/opt/audit-toolkit/.env' "$unit_file"
  fi
done

if [[ -f /etc/systemd/system/audit-toolkit-celery.service ]]; then
  sed -i 's|^After=network.target redis-server.service|After=network.target postgresql.service redis-server.service|' /etc/systemd/system/audit-toolkit-celery.service
fi
if [[ -f /etc/systemd/system/audit-toolkit-celery-beat.service ]]; then
  sed -i 's|^After=network.target redis-server.service|After=network.target postgresql.service redis-server.service|' /etc/systemd/system/audit-toolkit-celery-beat.service
fi

echo "[step] run alembic migrations against PostgreSQL"
cd "$APP_DIR"
export DATABASE_URL="$APP_DB_URL"
echo "[step] ensure alembic version column length for PostgreSQL"
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, text


database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)

with engine.begin() as connection:
  connection.execute(
    text(
      """
      CREATE TABLE IF NOT EXISTS alembic_version (
        version_num VARCHAR(255) NOT NULL PRIMARY KEY
      )
      """
    )
  )
  connection.execute(
    text("ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(255)")
  )

print("alembic_version.version_num set to VARCHAR(255)")
PY

echo "[step] normalize legacy alembic revision IDs"
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, text


database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)

with engine.begin() as connection:
  connection.execute(
    text(
      """
      UPDATE alembic_version
      SET version_num = '008_add_hypervisor_conn_method'
      WHERE version_num = '008_add_hypervisor_connection_method'
      """
    )
  )
  connection.execute(
    text(
      """
      UPDATE alembic_version
      SET version_num = '015_merge_windows_support_main'
      WHERE version_num = '015_merge_windows_support_and_main_head'
      """
    )
  )

print("legacy alembic revisions normalized")
PY

echo "[step] ensure users table exists for legacy migration chains"
cd "$APP_DIR/web"
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, inspect

from models.database import Base
from models.user import User


database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)

if "users" not in inspect(engine).get_table_names():
  Base.metadata.create_all(engine, tables=[User.__table__])
  print("created users table")
else:
  print("users table already present")
PY

cd "$APP_DIR"
# If alembic_version is empty but the schema already exists (tables present),
# stamp the DB directly via SQL so alembic doesn't try to re-run all migrations.
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, inspect, text

database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)
with engine.begin() as conn:
  rows = conn.execute(text("SELECT version_num FROM alembic_version")).fetchall()
  if not rows:
    tbl_names = inspect(engine).get_table_names()
    if "servers" in tbl_names:
      # Schema pre-exists; stamp to head so alembic skips initial migrations
      conn.execute(text(
        "INSERT INTO alembic_version (version_num) VALUES ('016_align_scheduled_audits_schema')"
      ))
      print("alembic_version was empty with existing schema — stamped to head")
    else:
      print("alembic_version empty, no existing schema — will run full migration")
  else:
    print(f"alembic_version already set: {rows[0][0]}")
PY
/opt/audit-toolkit/.venv/bin/python -m alembic upgrade head

echo "[step] enforce runtime schema compatibility"
cd "$APP_DIR/web"
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, inspect, text

from models.audit_history import AuditHistorySummary, ServerComplianceHistory
from models.database import Base
from models.maintenance_window import ScheduleExecutionLog
from models.schedule import ScheduledAudit
from models.scheduled_report import ScheduledReport


database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)

Base.metadata.create_all(
  engine,
  tables=[
    ScheduledAudit.__table__,
    ScheduledReport.__table__,
    ScheduleExecutionLog.__table__,
    AuditHistorySummary.__table__,
    ServerComplianceHistory.__table__,
  ],
)

with engine.begin() as connection:
  # Servers schema drift
  connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS connection_method VARCHAR(20) NOT NULL DEFAULT 'ssh'"))
  connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS agent_id VARCHAR(50)"))
  connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_type VARCHAR(50)"))
  connection.execute(text("ALTER TABLE servers ADD COLUMN IF NOT EXISTS hypervisor_endpoint VARCHAR(255)"))

  # Scheduled audits schema drift
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS name VARCHAR(255)"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS cron_schedule VARCHAR(100)"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS is_active BOOLEAN"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_enabled BOOLEAN NOT NULL DEFAULT false"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_emails TEXT"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS notification_webhooks TEXT"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_run TIMESTAMP"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS next_run TIMESTAMP"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS last_status VARCHAR(50)"))
  connection.execute(text("ALTER TABLE scheduled_audits ADD COLUMN IF NOT EXISTS created_by VARCHAR(100)"))

  columns = {column["name"] for column in inspect(connection).get_columns("scheduled_audits")}

  if "schedule_cron" in columns and "cron_schedule" in columns:
    connection.execute(text("UPDATE scheduled_audits SET cron_schedule = schedule_cron WHERE cron_schedule IS NULL"))

  if "enabled" in columns and "is_active" in columns:
    connection.execute(text("UPDATE scheduled_audits SET is_active = enabled WHERE is_active IS NULL"))

  if "last_run_at" in columns and "last_run" in columns:
    connection.execute(text("UPDATE scheduled_audits SET last_run = last_run_at WHERE last_run IS NULL"))

  if "next_run_at" in columns and "next_run" in columns:
    connection.execute(text("UPDATE scheduled_audits SET next_run = next_run_at WHERE next_run IS NULL"))

  connection.execute(text("UPDATE scheduled_audits SET name = 'Schedule #' || id WHERE name IS NULL OR TRIM(name) = ''"))
  connection.execute(text("UPDATE scheduled_audits SET cron_schedule = '0 0 * * *' WHERE cron_schedule IS NULL OR TRIM(cron_schedule) = ''"))
  connection.execute(text("UPDATE scheduled_audits SET is_active = true WHERE is_active IS NULL"))

  connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN name SET NOT NULL"))
  connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN cron_schedule SET NOT NULL"))
  connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET NOT NULL"))
  connection.execute(text("ALTER TABLE scheduled_audits ALTER COLUMN is_active SET DEFAULT true"))

  connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_active_next_run ON scheduled_audits (is_active, next_run)"))
  connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_server_id ON scheduled_audits (server_id)"))
  connection.execute(text("CREATE INDEX IF NOT EXISTS idx_schedule_audit_id ON scheduled_audits (audit_id)"))

  # Mark drift-alignment revision as applied for PostgreSQL
  connection.execute(
    text(
      """
      UPDATE alembic_version
      SET version_num = '016_align_scheduled_audits_schema'
      WHERE version_num = '015_merge_windows_support_main'
      """
    )
  )

print("runtime schema compatibility enforced")
PY

cd "$APP_DIR"

echo '[step] restart services'
systemctl daemon-reload
systemctl restart audit-toolkit audit-toolkit-celery audit-toolkit-celery-beat
sleep 5

echo "[info] service status"
systemctl is-active audit-toolkit audit-toolkit-celery audit-toolkit-celery-beat

echo "[step] runtime verification"
sed -i 's/\r$//' "$APP_ENV"
set -a
# shellcheck disable=SC1090
source "$APP_ENV"
set +a
cd "$APP_DIR"
/opt/audit-toolkit/.venv/bin/python - <<'PY'
import os

from sqlalchemy import create_engine, inspect, text


database_url = os.environ["DATABASE_URL"]
engine = create_engine(database_url)

with engine.connect() as connection:
  connection.execute(text("SELECT 1"))

tables = set(inspect(engine).get_table_names())
required_tables = {"users", "scheduled_reports", "alembic_version"}
missing = sorted(required_tables - tables)

if missing:
  raise SystemExit(f"Missing required PostgreSQL tables: {', '.join(missing)}")

scheduled_audits_columns = {
  column["name"]
  for column in inspect(engine).get_columns("scheduled_audits")
}
required_scheduled_audits_columns = {
  "name",
  "cron_schedule",
  "is_active",
  "next_run",
}
missing_schedule_columns = sorted(required_scheduled_audits_columns - scheduled_audits_columns)

if missing_schedule_columns:
  raise SystemExit(
    "Missing required scheduled_audits columns: " + ", ".join(missing_schedule_columns)
  )

servers_columns = {
  column["name"]
  for column in inspect(engine).get_columns("servers")
}
required_server_columns = {
  "connection_method",
  "execution_mode",
  "elevation_method",
}
missing_server_columns = sorted(required_server_columns - servers_columns)

if missing_server_columns:
  raise SystemExit(
    "Missing required servers columns: " + ", ".join(missing_server_columns)
  )

print("PostgreSQL table verification passed")
PY

cd /opt/audit-toolkit/web
/opt/audit-toolkit/.venv/bin/python -c "from tasks.report_tasks import run_scheduled_reports; print(run_scheduled_reports.run())"

echo "[step] recent celery log check"
journalctl -u audit-toolkit-celery --since '2 minutes ago' --no-pager || true
