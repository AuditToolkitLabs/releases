#!/bin/bash
###############################################################################
# Security Audit Toolkit — VM Health Check + Appliance Image Capture Prep
#
# Run with: sudo bash /tmp/vm-health-and-capture-prep.sh
#
# This script:
#   Phase 1 — Full health check and auto-fix of runtime issues
#   Phase 2 — Image capture prep (resets to first-boot state for VMDK/OVA)
###############################################################################
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

ok()    { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
err()   { echo -e "${RED}[FAIL]${NC}  $1"; }
info()  { echo -e "${CYAN}[--]${NC}   $1"; }
hdr()   { echo -e "\n${BOLD}${CYAN}$1${NC}"; echo "------------------------------------------------------"; }

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[ERROR]${NC} Must be run as root. Use: sudo bash $0"
    exit 1
fi

INSTALL_DIR="/opt/audit-toolkit"
WEB_ENV="$INSTALL_DIR/web/.env"
ROOT_ENV="$INSTALL_DIR/.env"
# Service units reference .venv; the real dir may be 'venv'. Resolve both.
if [[ -d "$INSTALL_DIR/venv" ]]; then
    VENV="$INSTALL_DIR/venv"
elif [[ -d "$INSTALL_DIR/.venv" && ! -L "$INSTALL_DIR/.venv" ]]; then
    VENV="$INSTALL_DIR/.venv"
else
    VENV="$INSTALL_DIR/.venv"
fi
MARKER_DIR="/var/lib/audit-toolkit"
DB_NAME="audit_toolkit"
ISSUES=0

###############################################################################
# PHASE 1 — HEALTH CHECK
###############################################################################
echo ""
echo "======================================================================"
echo " Security Audit Toolkit — VM Health Check"
echo "======================================================================"

hdr "1. System"
uname -a
uptime
df -h / | tail -1 | awk '{print "Disk: "$5" used ("$3" of "$2")"}'
DISK_PCT=$(df / | tail -1 | awk '{print $5}' | tr -d '%')
if [[ "$DISK_PCT" -ge 90 ]]; then
    err "Disk >= 90% — capture prep cleanup should help"
    ISSUES=$((ISSUES+1))
elif [[ "$DISK_PCT" -ge 80 ]]; then
    warn "Disk at ${DISK_PCT}% — borderline"
else
    ok "Disk at ${DISK_PCT}%"
fi

hdr "2. Services"
for svc in audit-toolkit-web audit-toolkit-discovery nginx postgresql audit-toolkit-celery; do
    state=$(systemctl is-active "$svc" 2>/dev/null || true)
    if [[ "$state" == "active" ]]; then
        ok "$svc: $state"
    else
        err "$svc: $state"
        ISSUES=$((ISSUES+1))
    fi
done

hdr "3. Toolkit Version"
grep TOOLKIT_VERSION "$INSTALL_DIR/web/self_audit.py" 2>/dev/null | head -1 || warn "self_audit.py not found"

hdr "4. Python venv"
if [[ -x "$VENV/bin/gunicorn" ]]; then
    ok "gunicorn: $($VENV/bin/gunicorn --version 2>/dev/null)"
else
    err "gunicorn missing at $VENV/bin/gunicorn"
    ISSUES=$((ISSUES+1))
fi
if [[ -x "$VENV/bin/python" ]]; then
    ok "python: $($VENV/bin/python --version 2>/dev/null)"
else
    err "python missing at $VENV/bin/python"
    ISSUES=$((ISSUES+1))
fi

hdr "5. DB_FIELD_ENCRYPTION_KEY"
is_valid_fernet_key() {
    [[ "$1" =~ ^[A-Za-z0-9_-]{43}=$ ]]
}
generate_fernet_key() {
    openssl rand -base64 32 | tr '+/' '-_' | tr -d '\n'
}

WEB_KEY=""
if [[ -f "$WEB_ENV" ]]; then
    WEB_KEY=$(awk -F= '/^DB_FIELD_ENCRYPTION_KEY=/{print substr($0, index($0,$2)); exit}' "$WEB_ENV" | tr -d '"'"'" | tr -d '\n' || true)
fi

if [[ -z "$WEB_KEY" ]]; then
    err "DB_FIELD_ENCRYPTION_KEY missing from web/.env — FIXING..."
    NEW_KEY=$(generate_fernet_key)
    if grep -q '^DB_FIELD_ENCRYPTION_KEY=' "$WEB_ENV" 2>/dev/null; then
        sed -i "s|^DB_FIELD_ENCRYPTION_KEY=.*|DB_FIELD_ENCRYPTION_KEY=${NEW_KEY}|" "$WEB_ENV"
    else
        echo "DB_FIELD_ENCRYPTION_KEY=${NEW_KEY}" >> "$WEB_ENV"
    fi
    ok "Generated and wrote new Fernet key to web/.env"
    ISSUES=$((ISSUES+1))
    WEB_KEY="$NEW_KEY"
    # Restart web service so it picks up the new key
    if systemctl restart audit-toolkit-web; then ok "audit-toolkit-web restarted with new key"; else warn "restart failed"; fi
elif ! is_valid_fernet_key "$WEB_KEY"; then
    err "DB_FIELD_ENCRYPTION_KEY is not a valid Fernet key (found hex/other) — FIXING..."
    NEW_KEY=$(generate_fernet_key)
    sed -i "s|^DB_FIELD_ENCRYPTION_KEY=.*|DB_FIELD_ENCRYPTION_KEY=${NEW_KEY}|" "$WEB_ENV"
    ok "Replaced invalid key with new Fernet key in web/.env"
    ISSUES=$((ISSUES+1))
    if systemctl restart audit-toolkit-web; then ok "audit-toolkit-web restarted with new key"; else warn "restart failed"; fi
else
    ok "DB_FIELD_ENCRYPTION_KEY present and valid Fernet format"
fi

hdr "6. Admin DB Row"
ADMIN_ROW=$(sudo -u postgres psql -d "$DB_NAME" -tAc \
    "SELECT username||'|must_change='||must_change_password||'|disclaimer='||COALESCE(disclaimer_accepted_at::text,'NULL') FROM users WHERE is_builtin_admin=true ORDER BY id LIMIT 1;" \
    2>/dev/null || echo "DB_QUERY_FAILED")
if [[ "$ADMIN_ROW" == "DB_QUERY_FAILED" ]]; then
    err "Could not query admin from DB"
    ISSUES=$((ISSUES+1))
else
    ok "Admin row: $ADMIN_ROW"
fi

hdr "7. First-boot Markers"
if [[ -d "$MARKER_DIR" ]]; then
    ls -la "$MARKER_DIR/" || true
else
    warn "Marker dir $MARKER_DIR missing"
fi

hdr "8. Celery — detailed status"
systemctl status audit-toolkit-celery --no-pager -l 2>/dev/null | head -25 || true

hdr "9. Recent web service logs"
journalctl -u audit-toolkit-web -n 15 --no-pager 2>/dev/null | tail -15 || true

hdr "10. SSH host keys"
find /etc/ssh -maxdepth 1 -name 'ssh_host_*' -printf '%TY-%Tm-%Td %TH:%TM %p\n' 2>/dev/null || echo "None found"

hdr "11. Netplan"
cat /etc/netplan/90-audit-toolkit.yaml 2>/dev/null || (ls /etc/netplan/ 2>/dev/null && cat /etc/netplan/*.yaml 2>/dev/null) || echo "No netplan files readable"

if [[ $ISSUES -gt 0 ]]; then
    echo ""
    warn "Health check found $ISSUES issue(s) — some were auto-fixed above."
else
    echo ""
    ok "Health check passed — no issues."
fi

###############################################################################
# PHASE 2 — IMAGE CAPTURE PREP
###############################################################################
echo ""
echo "======================================================================"
echo " Image Capture Prep — Resetting to First-Boot State"
echo "======================================================================"

hdr "[1/10] Reset built-in admin to first-login state"
if [[ -x "$VENV/bin/python" ]]; then
    set +H
    HASH=$("$VENV/bin/python" -c \
        "from werkzeug.security import generate_password_hash; print(generate_password_hash('ChangeMe123!'))")
    if sudo -u postgres psql -d "$DB_NAME" -v ON_ERROR_STOP=1 -c \
        "UPDATE users SET
            password_hash='${HASH}',
            must_change_password=true,
            disclaimer_accepted_at=NULL,
            disclaimer_version=NULL,
            is_active=true,
            auth_provider='local',
            failed_login_attempts=0,
            lockout_until=NULL
         WHERE is_builtin_admin=true;" 2>/dev/null; then
        ok "Admin DB row reset (ChangeMe123! / must_change_password=true / disclaimer cleared)"
    else
        warn "DB update skipped (non-fatal)"
    fi
    set -H
else
    warn "Python venv missing — DB reset skipped"
fi

hdr "[2/10] Restore env password defaults"
for env_file in "$WEB_ENV" "$ROOT_ENV"; do
    [[ -f "$env_file" ]] || continue
    sed -i 's/^INITIAL_ADMIN_PASSWORD=.*/INITIAL_ADMIN_PASSWORD=ChangeMe123!/' "$env_file"
    sed -i 's/^ADMIN_PASSWORD=.*/ADMIN_PASSWORD=ChangeMe123!/' "$env_file"
    sed -i 's/^AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=.*/AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=0/' "$env_file"
    grep -q '^INITIAL_ADMIN_PASSWORD=' "$env_file" || echo 'INITIAL_ADMIN_PASSWORD=ChangeMe123!' >> "$env_file"
    grep -q '^ADMIN_PASSWORD=' "$env_file" || echo 'ADMIN_PASSWORD=ChangeMe123!' >> "$env_file"
    grep -q '^AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=' "$env_file" || echo 'AUDIT_TOOLKIT_RANDOMIZE_INITIAL_ADMIN_PASSWORD=0' >> "$env_file"
    ok "Env defaults restored in $(basename "$(dirname "$env_file")")/$(basename "$env_file")"
done

hdr "[2b/10] Ensure .venv symlink (service units reference .venv)"
if [[ -d "$INSTALL_DIR/venv" && ! -e "$INSTALL_DIR/.venv" ]]; then
    ln -sfn "$INSTALL_DIR/venv" "$INSTALL_DIR/.venv"
    ok ".venv -> venv symlink created"
elif [[ -L "$INSTALL_DIR/.venv" ]]; then
    ok ".venv symlink already present: $(readlink -f "$INSTALL_DIR/.venv")"
else
    warn ".venv path state unclear — check manually"
fi

hdr "[3/10] Reset netplan to DHCP"
IFACE=$(ip -o link show | awk -F': ' '$2 !~ /lo|docker|veth|virbr/ {print $2; exit}')
IFACE="${IFACE:-eth0}"
rm -f /etc/netplan/90-audit-toolkit.yaml /etc/netplan/99-audit-toolkit.yaml
cat > /etc/netplan/90-audit-toolkit.yaml <<NETEOF
# Security Audit Toolkit - First-boot network baseline (DHCP)
# Regenerated by vm-health-and-capture-prep.sh
network:
  version: 2
  ethernets:
    ${IFACE}:
      dhcp4: true
      dhcp6: false
NETEOF
chmod 600 /etc/netplan/90-audit-toolkit.yaml
sed -i '/gateway4:/d' /etc/netplan/*.yaml 2>/dev/null || true
ok "Netplan reset to DHCP on $IFACE"

hdr "[4/10] Remove setup / first-boot markers"
rm -f \
    "$MARKER_DIR/.setup-complete" \
    "$MARKER_DIR/.first-boot-complete" \
    "$MARKER_DIR/.first-login-wizard-complete" \
    "$INSTALL_DIR/scripts/.first-boot-complete" 2>/dev/null || true
ok "Setup markers removed"

hdr "[5/10] Remove credential artefact files"
rm -f \
    "$MARKER_DIR/initial-admin-credentials.txt" \
    "$INSTALL_DIR/initial-credentials.txt" \
    "$INSTALL_DIR/web/initial-credentials.txt" \
    "$INSTALL_DIR/data/initial-admin-credentials.txt" \
    /home/auditadmin/initial-credentials.txt 2>/dev/null || true
ok "Credential artefacts removed"

hdr "[6/10] Remove SSH host keys (regenerated on first boot)"
rm -f /etc/ssh/ssh_host_*
ok "SSH host keys removed"

hdr "[7/10] Reset machine-id"
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id
ln -sf /etc/machine-id /var/lib/dbus/machine-id 2>/dev/null || true
ok "machine-id cleared"

hdr "[8/10] Flush logs, history, temp"
find "$INSTALL_DIR" -name "*.log" -type f -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log/audit-toolkit -type f -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log -type f \( -name "*.log" -o -name "syslog" -o -name "auth.log" \) -exec truncate -s 0 {} \; 2>/dev/null || true
find /var/log -type f -name "*.gz" -delete 2>/dev/null || true
journalctl --rotate 2>/dev/null || true
journalctl --vacuum-time=1s 2>/dev/null || true
rm -f /root/.bash_history /home/auditadmin/.bash_history 2>/dev/null || true
find /tmp -mindepth 1 -delete 2>/dev/null || true
find /var/tmp -mindepth 1 -delete 2>/dev/null || true
ok "Logs, history, temp cleared"

hdr "[9/10] Clean package cache"
apt-get clean -y 2>/dev/null || true
apt-mark manual openssh-server 2>/dev/null || true
apt-get autoremove -y --purge 2>/dev/null || true
ok "Package cache cleaned"

hdr "[9b/10] Remove build artefacts not needed in appliance image"
rm -rf "${INSTALL_DIR}/vm-appliance/output" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/linux/artifacts" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/linux/build" 2>/dev/null || true
rm -rf "${INSTALL_DIR}/deployment/windows/bin" 2>/dev/null || true
ok "Build artefacts removed"

hdr "[9c/10] Grow LVM logical volume to fill available VG space"
LV_DEV="/dev/mapper/ubuntu--vg-ubuntu--lv"
VG_NAME=$(lvs --noheadings -o vg_name "${LV_DEV}" 2>/dev/null | tr -d ' ')
if [[ -n "$VG_NAME" ]]; then
    FREE_PE=$(vgdisplay "$VG_NAME" 2>/dev/null | awk '/Free  PE/{print $5}')
    if [[ "${FREE_PE:-0}" -gt 0 ]]; then
        if lvextend -l +100%FREE "/dev/${VG_NAME}/ubuntu-lv" 2>/dev/null; then
            ok "LV extended by ${FREE_PE} free PEs"
        else
            warn "lvextend returned non-zero (may already be at max)"
        fi
        if resize2fs "$LV_DEV" 2>/dev/null; then
            ok "Filesystem grown to fill LV"
        else
            warn "resize2fs returned non-zero"
        fi
    else
        ok "LV already uses all available VG space (0 free PEs)"
    fi
else
    warn "Could not detect LVM VG — disk grow skipped (non-LVM setup?)"
fi
df -h / | tail -1 | awk '{printf "  Disk now: %s total / %s used / %s avail (%s)\n",$2,$3,$4,$5}'

hdr "[10/10] Stop services cleanly for export"
if systemctl stop audit-toolkit-web       2>/dev/null; then ok "audit-toolkit-web stopped";       else warn "audit-toolkit-web not running";       fi
if systemctl stop audit-toolkit-discovery 2>/dev/null; then ok "audit-toolkit-discovery stopped"; else warn "audit-toolkit-discovery not running"; fi
if systemctl stop audit-toolkit-celery    2>/dev/null; then ok "audit-toolkit-celery stopped";    else warn "audit-toolkit-celery not running";    fi
if systemctl stop nginx                   2>/dev/null; then ok "nginx stopped";                   else warn "nginx not running";                   fi

###############################################################################
# FINAL SUMMARY
###############################################################################
echo ""
echo "======================================================================"
echo " COMPLETE — VM is ready for VMDK / OVA export"
echo "======================================================================"
echo ""
echo "  State reset:"
echo "  ✓ Admin DB: ChangeMe123! / must_change_password=true / disclaimer cleared"
echo "  ✓ Env defaults: INITIAL_ADMIN_PASSWORD=ChangeMe123! / RANDOMIZE=0"
echo "  ✓ Netplan: DHCP on $IFACE"
echo "  ✓ First-boot markers removed"
echo "  ✓ Credential artefact files removed"
echo "  ✓ SSH host keys removed (regenerated on first boot)"
echo "  ✓ machine-id cleared (regenerated on first boot)"
echo "  ✓ Logs / history / temp flushed"
echo "  ✓ Package cache cleaned"
echo "  ✓ Build artefacts removed (vm-appliance/output, deployment bins)"
echo "  ✓ LVM logical volume grown to fill available VG space"
echo "  ✓ Services stopped"
echo ""
echo "  NEXT STEP:"
echo "  Export the VM to VMDK / OVA immediately."
echo "  Do NOT reboot before export."
echo ""
