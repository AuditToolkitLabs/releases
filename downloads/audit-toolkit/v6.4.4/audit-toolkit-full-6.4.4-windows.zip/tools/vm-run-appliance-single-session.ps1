[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseSingularNouns', '', Justification='Function names use plural nouns matching their collection-oriented operations')]
param(
    [string]$VmHost = "audittoolkit-vm",
    [string]$SetupScriptPath = "",
    [System.Security.SecureString]$SudoPassword,
    [string]$SshKeyPath = $env:AUDIT_VM_SSH_KEY_PATH,
    [string]$SshPublicKeyPath = $env:AUDIT_VM_SSH_PUBLIC_KEY_PATH,
    [string[]]$ProtectedGoldTargets = @(
        "audittoolkit-vm",
        "192.168.100.50",
        "audittoolkit-appliance-base"
    ),
    [switch]$ForceGoldVmMutation,
    [switch]$BatchMode,
    [ValidateSet("setup", "deploy-asset-discovery", "bootstrap-ssh-key")]
    [string]$Mode = "setup",
    [ValidateSet("standard", "hardened")]
    [string]$BuildMode = "hardened"
)

$ErrorActionPreference = "Stop"

function Convert-SecureStringToPlainText {
    param([System.Security.SecureString]$Value)

    if (-not $Value) {
        return ""
    }

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function Resolve-SshHostName {
    param(
        [string]$Target
    )

    try {
        $sshConfigOutput = & ssh -G $Target 2>$null
        if ($LASTEXITCODE -ne 0) {
            return $null
        }

        foreach ($line in $sshConfigOutput) {
            if ($line -match '^\s*hostname\s+(.+)$') {
                $hostName = $Matches[1].Trim()
                if (-not [string]::IsNullOrWhiteSpace($hostName)) {
                    return $hostName
                }
            }
        }
    } catch { Write-Verbose 'Suppressed non-fatal error.' }

    return $null
}

function Assert-GoldTargetSafety {
    param(
        [string]$TargetAlias,
        [string[]]$ProtectedTargets,
        [switch]$AllowGoldMutation
    )

    if ($AllowGoldMutation) {
        Write-Output "Gold VM protection override enabled (-ForceGoldVmMutation)."
        return
    }

    $normalizedProtectedTargets = @(
        $ProtectedTargets |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.Trim().ToLowerInvariant() }
    )

    $candidateTargets = @($TargetAlias)
    $resolvedHostName = Resolve-SshHostName -Target $TargetAlias
    if (-not [string]::IsNullOrWhiteSpace($resolvedHostName)) {
        $candidateTargets += $resolvedHostName
    }

    foreach ($candidate in $candidateTargets) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }

        $normalizedCandidate = $candidate.Trim().ToLowerInvariant()
        if ($normalizedProtectedTargets -contains $normalizedCandidate) {
            throw "Refusing to run mode '$Mode' against protected target '$candidate'. Re-run with -ForceGoldVmMutation only when you intentionally want to mutate the gold VM."
        }
    }
}

function Get-SshOptions {
    param(
        [string]$KeyPath,
        [switch]$UseBatchMode
    )

    $options = @('-o', 'ConnectTimeout=12')

    if (-not [string]::IsNullOrWhiteSpace($KeyPath)) {
        if (-not (Test-Path $KeyPath)) {
            throw "SSH key not found: $KeyPath"
        }
        $options += @('-i', $KeyPath)
    }

    if ($UseBatchMode) {
        $options += @('-o', 'BatchMode=yes')
    }

    return $options
}

function Resolve-PublicKeyPath {
    param(
        [string]$PrivateKeyPath,
        [string]$ExplicitPublicKeyPath
    )

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPublicKeyPath)) {
        return $ExplicitPublicKeyPath
    }

    if (-not [string]::IsNullOrWhiteSpace($PrivateKeyPath)) {
        return "$PrivateKeyPath.pub"
    }

    $candidatePublicKeys = @(
        (Join-Path $HOME ".ssh\id_ed25519.pub"),
        (Join-Path $HOME ".ssh\id_rsa.pub"),
        (Join-Path $HOME ".ssh\id_ecdsa.pub")
    )

    foreach ($candidate in $candidatePublicKeys) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    return $candidatePublicKeys[0]
}

function Invoke-SshKeyBootstrap {
    param(
        [string]$VmTarget,
        [string]$PublicKeyPath,
        [string]$PrivateKeyPath
    )

    if (-not (Test-Path $PublicKeyPath)) {
        throw "Public key not found: $PublicKeyPath"
    }

    $publicKeyRaw = (Get-Content -Raw -Path $PublicKeyPath).Trim()
    if ([string]::IsNullOrWhiteSpace($publicKeyRaw)) {
        throw "Public key file is empty: $PublicKeyPath"
    }

    $encodedKey = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($publicKeyRaw))
    $sshOptions = Get-SshOptions -KeyPath $PrivateKeyPath -UseBatchMode:$false

    Write-Output "[vm] Bootstrapping SSH key on $VmTarget"
    Write-Output "[vm] Public key: $PublicKeyPath"

        $bootstrapLines = @(
                'set -eu',
                ('KEY=$(printf ''%s'' ''{0}'' | base64 -d)' -f $encodedKey),
                'mkdir -p ~/.ssh',
                'chmod 700 ~/.ssh',
                'touch ~/.ssh/authorized_keys',
                'chmod 600 ~/.ssh/authorized_keys',
                'if ! grep -qxF "$KEY" ~/.ssh/authorized_keys; then',
                '  printf ''%s\n'' "$KEY" >> ~/.ssh/authorized_keys',
                'fi',
                'echo "[step] SSH key installed"'
        )

        $bootstrapScript = (($bootstrapLines -join "`n") + "`n").Replace("`r", "")

    $bootstrapScript = $bootstrapScript -replace "`r`n", "`n"
    $bootstrapScript = $bootstrapScript -replace "`r", "`n"

    $bootstrapScript | & ssh @sshOptions $VmTarget "tr -d '\r' | bash -s"

    if ($LASTEXITCODE -ne 0) {
        throw "SSH key bootstrap failed with exit code $LASTEXITCODE"
    }

    Write-Output "[vm] SSH key bootstrap completed."
}

function Invoke-ApplianceSetup {
    param(
        [string]$VmTarget,
        [string]$ScriptPath,
        [System.Security.SecureString]$VmSudoPassword,
        [string]$VmSshKeyPath,
        [switch]$UseBatchMode,
        [ValidateSet("standard", "hardened")]
        [string]$SetupBuildMode = "hardened"
    )

    if (-not (Test-Path $ScriptPath)) {
        throw "Setup script not found: $ScriptPath"
    }

    Write-Output "[vm] Single-session interactive appliance setup"
    Write-Output "[vm] Host: $VmTarget"
    Write-Output "[vm] Script: $ScriptPath"
    Write-Output "[vm] Build mode: $SetupBuildMode"
    if (-not [string]::IsNullOrWhiteSpace($VmSshKeyPath)) {
        Write-Output "[vm] SSH key: $VmSshKeyPath"
    }
    Write-Output ""
    Write-Output "You should be prompted once for SSH and once for sudo."

    $sshOptions = Get-SshOptions -KeyPath $VmSshKeyPath -UseBatchMode:$UseBatchMode

    $setupScript = Get-Content -Raw -Path $ScriptPath
    $setupScript = $setupScript -replace "`r`n", "`n"
    $setupScript = $setupScript -replace "`r", "`n"

    $encodedSetupScript = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($setupScript))
    $plainPassword = Convert-SecureStringToPlainText -Value $VmSudoPassword
    $encodedPassword = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($plainPassword ?? "")))
    $hardenedModeFlag = if ($SetupBuildMode -eq "hardened") { "true" } else { "false" }
    $forceNonInteractiveSudo = if ($UseBatchMode -and [string]::IsNullOrWhiteSpace($plainPassword)) { "1" } else { "0" }

    $remoteLines = @(
        'set -euo pipefail',
        "printf '%s' '$encodedSetupScript' | base64 -d > ~/appliance-setup.sh",
        'chmod +x ~/appliance-setup.sh',
        "SUDO_PW=`$(printf '%s' '$encodedPassword' | base64 -d 2>/dev/null || true)",
        ("SUDO_NONINTERACTIVE={0}" -f $forceNonInteractiveSudo),
        'sudo_cmd() {',
        '  if [ -n "$SUDO_PW" ]; then',
        '    printf ''%s\n'' "$SUDO_PW" | sudo -S -p '''' "$@"',
        '  elif [ "${SUDO_NONINTERACTIVE:-0}" = "1" ]; then',
        '    sudo -n "$@"',
        '  else',
        '    sudo "$@"',
        '  fi',
        '}',
        'echo "[step] requesting sudo credentials"',
        'sudo_cmd -v',
        'echo "[step] running appliance setup"',
        ('export APPLIANCE_BUILD_MODE={0}' -f $SetupBuildMode),
        ('export APPLIANCE_HARDENED_MODE={0}' -f $hardenedModeFlag),
        'sudo_cmd bash ~/appliance-setup.sh 2>&1 | tee ~/appliance-setup.log',
        'echo "[step] service health"',
        'sudo_cmd systemctl status audit-toolkit audit-toolkit-celery nginx --no-pager || true'
    )

    $remoteScript = ((($remoteLines -join "`n") -replace "`r", "") + "`n")
    $remoteScript | & ssh @sshOptions $VmTarget "tr -d '\r' | bash -s"

    if ($LASTEXITCODE -ne 0) {
        throw "Single-session setup failed with exit code $LASTEXITCODE"
    }

    Write-Output "[vm] Setup completed."
}

function Invoke-AssetDiscoveryDeploy {
    param(
        [string]$VmTarget,
        [string]$RepoRoot,
        [System.Security.SecureString]$VmSudoPassword,
        [string]$VmSshKeyPath,
        [switch]$UseBatchMode
    )

    $sshOptions = Get-SshOptions -KeyPath $VmSshKeyPath -UseBatchMode:$UseBatchMode

    $fileMap = @(
        @{ Local = Join-Path $RepoRoot "tools\asset-discovery\src\services\remote_executor.py"; Remote = "/opt/audit-toolkit/tools/asset-discovery/src/services/remote_executor.py"; Temp = "remote_executor.py" },
        @{ Local = Join-Path $RepoRoot "tools\asset-discovery\src\services\asset_ingestion.py"; Remote = "/opt/audit-toolkit/tools/asset-discovery/src/services/asset_ingestion.py"; Temp = "asset_ingestion.py" },
        @{ Local = Join-Path $RepoRoot "tools\asset-discovery\src\api\assets.py"; Remote = "/opt/audit-toolkit/tools/asset-discovery/src/api/assets.py"; Temp = "assets.py" },
        @{ Local = Join-Path $RepoRoot "tools\asset-discovery\src\api\scans.py"; Remote = "/opt/audit-toolkit/tools/asset-discovery/src/api/scans.py"; Temp = "scans.py" },
        @{ Local = Join-Path $RepoRoot "tools\asset-discovery\src\static\index.html"; Remote = "/opt/audit-toolkit/tools/asset-discovery/src/static/index.html"; Temp = "index.html" }
    )

    foreach ($item in $fileMap) {
        if (-not (Test-Path $item.Local)) {
            throw "Local file not found: $($item.Local)"
        }
    }

    Write-Output "[vm] Deploying asset discovery updates to $VmTarget"
    if (-not [string]::IsNullOrWhiteSpace($VmSshKeyPath)) {
        Write-Output "[vm] SSH key: $VmSshKeyPath"
    }
    Write-Output "[vm] Building deployment staging directory..."
    $stagingName = "asset-discovery-deploy-$([Guid]::NewGuid().ToString('N'))"
    $stagingPath = Join-Path $env:TEMP $stagingName

    if (Test-Path $stagingPath) {
        Remove-Item -Recurse -Force $stagingPath
    }
    New-Item -ItemType Directory -Path $stagingPath | Out-Null

    $relativePaths = @()
    foreach ($item in $fileMap) {
        $relativePaths += [System.IO.Path]::GetRelativePath($RepoRoot, $item.Local)
    }

    foreach ($relativePath in $relativePaths) {
        $relativePathWin = $relativePath.Replace('/', '\\')
        $sourcePath = Join-Path $RepoRoot $relativePathWin
        $targetPath = Join-Path $stagingPath $relativePathWin
        $targetDir = Split-Path -Parent $targetPath
        if (-not (Test-Path $targetDir)) {
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }
        Copy-Item -Path $sourcePath -Destination $targetPath -Force
    }

    if (-not (Test-Path $stagingPath)) {
        throw "Failed to build staging directory: $stagingPath"
    }

    Write-Output "[vm] Uploading staged files to remote host..."
    & scp @sshOptions -r $stagingPath "${VmTarget}:~/$stagingName"
    if ($LASTEXITCODE -ne 0) {
        throw "SCP failed for staging upload"
    }

    $plainPassword = Convert-SecureStringToPlainText -Value $VmSudoPassword
    $encodedPassword = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($plainPassword ?? "")))
    $forceNonInteractiveSudo = if ($UseBatchMode -and [string]::IsNullOrWhiteSpace($plainPassword)) { "1" } else { "0" }

    $installLines = @(
        'set -euo pipefail',
        "SUDO_PW=`$(printf '%s' '$encodedPassword' | base64 -d 2>/dev/null || true)",
        ("SUDO_NONINTERACTIVE={0}" -f $forceNonInteractiveSudo),
        'sudo_cmd() {',
        '  if [ -n "$SUDO_PW" ]; then',
        '    printf ''%s\n'' "$SUDO_PW" | sudo -S -p '''' "$@"',
        '  elif [ "${SUDO_NONINTERACTIVE:-0}" = "1" ]; then',
        '    sudo -n "$@"',
        '  else',
        '    sudo "$@"',
        '  fi',
        '}',
        "echo '[step] requesting sudo credentials'",
        'sudo_cmd -v'
    )

    $installLines += ('workdir=~/{0}' -f $stagingName)
    $installLines += ('if [ -d "$workdir/{0}" ]; then workdir="$workdir/{0}"; fi' -f $stagingName)
    $installLines += ('trap ''rm -rf ~/{0}'' EXIT' -f $stagingName)

    foreach ($item in $fileMap) {
        $relativePath = [System.IO.Path]::GetRelativePath($RepoRoot, $item.Local).Replace('\', '/')
        $installLines += ('sudo_cmd install -m 0644 "$workdir/{0}" {1}' -f $relativePath, $item.Remote)
    }

    $installLines += ('rm -rf ~/{0}' -f $stagingName)
    $installLines += "echo '[step] restarting services'"
    $installLines += "sudo_cmd systemctl restart audit-toolkit-discovery audit-toolkit audit-toolkit-celery nginx"
    $installLines += "echo '[step] checking services'"
    $installLines += "sudo_cmd systemctl is-active audit-toolkit-discovery audit-toolkit audit-toolkit-celery nginx"

    $remoteScript = ((($installLines -join "`n") -replace "`r", "") + "`n")
    $remoteScript | & ssh @sshOptions $VmTarget "tr -d '\r' | bash -s"

    if ($LASTEXITCODE -ne 0) {
        throw "Remote deploy failed with exit code $LASTEXITCODE"
    }

    if (Test-Path $stagingPath) {
        Remove-Item -Recurse -Force $stagingPath
    }

    Write-Output "[vm] Asset discovery deployment completed."
}

if ($Mode -eq "setup") {
    Assert-GoldTargetSafety -TargetAlias $VmHost -ProtectedTargets $ProtectedGoldTargets -AllowGoldMutation:$ForceGoldVmMutation

    if ([string]::IsNullOrWhiteSpace($SetupScriptPath)) {
        $repoRoot = Split-Path -Parent $PSScriptRoot
        $SetupScriptPath = Join-Path $repoRoot "deployment\vm-appliance\output\appliance-setup.sh"
    }

    Invoke-ApplianceSetup -VmTarget $VmHost -ScriptPath $SetupScriptPath -VmSudoPassword $SudoPassword -VmSshKeyPath $SshKeyPath -UseBatchMode:$BatchMode -SetupBuildMode $BuildMode
    exit 0
}

if ($Mode -eq "bootstrap-ssh-key") {
    Assert-GoldTargetSafety -TargetAlias $VmHost -ProtectedTargets $ProtectedGoldTargets -AllowGoldMutation:$ForceGoldVmMutation

    $resolvedPublicKeyPath = Resolve-PublicKeyPath -PrivateKeyPath $SshKeyPath -ExplicitPublicKeyPath $SshPublicKeyPath
    Invoke-SshKeyBootstrap -VmTarget $VmHost -PublicKeyPath $resolvedPublicKeyPath -PrivateKeyPath $SshKeyPath
    exit 0
}

$repoRoot = Split-Path -Parent $PSScriptRoot
Assert-GoldTargetSafety -TargetAlias $VmHost -ProtectedTargets $ProtectedGoldTargets -AllowGoldMutation:$ForceGoldVmMutation
Invoke-AssetDiscoveryDeploy -VmTarget $VmHost -RepoRoot $repoRoot -VmSudoPassword $SudoPassword -VmSshKeyPath $SshKeyPath -UseBatchMode:$BatchMode
exit 0
