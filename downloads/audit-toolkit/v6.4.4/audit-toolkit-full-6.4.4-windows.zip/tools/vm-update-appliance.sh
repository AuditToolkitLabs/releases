#!/bin/bash
# VM Update Script: Apply security patches, cleanup, prepare for OVA export
# Usage: ssh auditadmin@192.168.100.52 'bash /tmp/vm-update-appliance.sh'

set -euo pipefail

TOOLKIT_ROOT="/opt/audit-toolkit"
VENV_BIN="${TOOLKIT_ROOT}/.venv/bin"
REQUIREMENTS="${TOOLKIT_ROOT}/web/requirements.txt"

echo "=== Phase 1: Upgrade pip and core tools ==="
${VENV_BIN}/pip install --upgrade pip wheel setuptools 2>&1 | tail -5

echo ""
echo "=== Phase 2: Upgrade web requirements.txt packages ==="
${VENV_BIN}/pip install -r "${REQUIREMENTS}" --upgrade 2>&1 | tail -10

echo ""
echo "=== Phase 3: Verify redis upgrade (5.0.3 -> 7.3.0) ==="
${VENV_BIN}/pip show redis | grep Version

echo ""
echo "=== Phase 4: Clean first-boot markers ==="
sudo rm -f "${TOOLKIT_ROOT}/.first-boot-complete" \
          "${TOOLKIT_ROOT}/.first-boot" \
          /root/.first-boot-complete \
          /var/lib/audit-toolkit/.first-boot
echo "First-boot markers removed"

echo ""
echo "=== Phase 5: Clear build logs and temporary files ==="
find "${TOOLKIT_ROOT}" -name "*.log" -type f -delete 2>/dev/null || true
find "${TOOLKIT_ROOT}" -name "*_temp_*" -type f -delete 2>/dev/null || true
echo "Build logs cleared"

echo ""
echo "=== Phase 6: Remove lab config ==="
sudo rm -f "${TOOLKIT_ROOT}/.env.lab" "${TOOLKIT_ROOT}/.env.local"
echo "Lab config removed"

echo ""
echo "=== Phase 7: Clear cloud-init state ==="
sudo cloud-init clean --seed --logs 2>/dev/null || echo "cloud-init clean skipped (may not be applicable)"

echo ""
echo "=== Phase 8: Clear shell history ==="
cat /dev/null > ~/.bash_history
sudo cat /dev/null > /root/.bash_history 2>/dev/null || true
echo "Shell history cleared"

echo ""
echo "=== Phase 9: VM shutdown ==="
echo "Gracefully shutting down VM in 10 seconds... (Cancel with Ctrl+C)"
sleep 10
sudo systemctl isolate poweroff

echo "VM update complete and shutdown initiated"
