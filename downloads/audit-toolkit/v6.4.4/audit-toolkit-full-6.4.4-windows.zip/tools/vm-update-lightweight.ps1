#!/usr/bin/env pwsh
# VM Appliance Update Script - DNS, security dependency updates, and cleanup

[CmdletBinding()]
param(
    [string]$VMHost = "192.168.100.52",
    [string]$VMUser = "auditadmin",
    [SecureString]$SudoPassword,
    [string]$ToolkitRoot = "/opt/audit-toolkit",
    [switch]$SkipShutdown
)

$ErrorActionPreference = "Stop"

function ConvertTo-InMemorySecureString {
    param([string]$Value)

    $secureValue = New-Object System.Security.SecureString
    if (-not [string]::IsNullOrEmpty($Value)) {
        foreach ($character in $Value.ToCharArray()) {
            $secureValue.AppendChar($character)
        }
    }
    $secureValue.MakeReadOnly()
    return $secureValue
}

function ConvertTo-PlainText {
    param([SecureString]$SecureValue)

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

if (-not $SudoPassword) {
    $SudoPassword = ConvertTo-InMemorySecureString -Value "ChangeMe123!"
}
$plainSudoPassword = ConvertTo-PlainText -SecureValue $SudoPassword

function Invoke-SSH {
    param(
        [string]$Command,
        [switch]$IgnoreErrors
    )

    $output = ssh -o ConnectTimeout=10 -n "$VMUser@$VMHost" $Command 2>&1
    $exitCode = $LASTEXITCODE
    $text = ($output | Out-String).TrimEnd()

    if (-not $IgnoreErrors -and $exitCode -ne 0) {
        throw "Remote command failed (exit $exitCode): $Command`n$text"
    }

    return [PSCustomObject]@{
        ExitCode = $exitCode
        Output   = $text
    }
}

function Invoke-Sudo {
    param(
        [string]$Command,
        [switch]$IgnoreErrors
    )

    $normalized = $Command -replace "`r", ""
    $encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($normalized))
    $sudoCmd = "printf '%s\n' '$plainSudoPassword' | sudo -S bash -lc `"echo $encoded | base64 -d | bash`""
    return Invoke-SSH -Command $sudoCmd -IgnoreErrors:$IgnoreErrors
}

Write-Output "=== VM Update Script ==="
Write-Output "Target: $VMHost"
Write-Output "User:   $VMUser"
Write-Output ""

Write-Output "[1] Checking SSH connectivity..."
$hostInfo = Invoke-SSH -Command "hostname && ip -o -4 addr show eth0 && ip route | head -n 2"
Write-Output $hostInfo.Output

Write-Output "[2] Configuring DNS (8.8.8.8) in network setup..."
$dnsScript = @'
set -euo pipefail

IP_CIDR=$(ip -o -4 addr show eth0 | awk '{print $4}')
GW=$(ip route | awk '/^default/ {print $3; exit}')

cat > /etc/netplan/90-audit-toolkit.yaml <<EOF
network:
    version: 2
    ethernets:
        eth0:
            dhcp4: false
            addresses:
                - ${IP_CIDR}
            routes:
                - to: default
                  via: ${GW}
            nameservers:
                addresses:
                    - 8.8.8.8
                    - 1.1.1.1
                    - ${GW}
EOF

chmod 600 /etc/netplan/90-audit-toolkit.yaml
netplan generate
netplan apply

resolvectl dns eth0 8.8.8.8 1.1.1.1 ${GW}
resolvectl domain eth0 '~.'
resolvectl flush-caches
'@
Invoke-Sudo -Command $dnsScript | Out-Null

Write-Output "[3] Running DNS lookup checks..."
$lookupDefault = Invoke-SSH -Command "timeout 8 getent hosts pypi.org"
Write-Output "Default resolver lookup:"
Write-Output $lookupDefault.Output

$lookupGoogle = Invoke-SSH -Command "nslookup pypi.org 8.8.8.8 | sed -n '1,16p'"
Write-Output "Lookup forced to 8.8.8.8:"
Write-Output $lookupGoogle.Output

$resolver = Invoke-SSH -Command "resolvectl status | sed -n '1,80p'"
Write-Output "Resolver status:"
Write-Output $resolver.Output

Write-Output "[4] Syncing patched requirements.txt from workspace..."
# Brief pause to allow SSH to re-stabilise after 'netplan apply' may have reset the link
Start-Sleep -Seconds 8
$localRequirements = (Resolve-Path (Join-Path $PSScriptRoot "..\web\requirements.txt")).Path
& scp $localRequirements "${VMUser}@${VMHost}:${ToolkitRoot}/web/requirements.txt" | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "Failed to copy requirements.txt to VM"
}

Write-Output "[5] Applying patched package updates..."
$upgradeCmd = "$ToolkitRoot/.venv/bin/pip install --upgrade redis==7.3.0 croniter==6.2.2 msal==1.35.1 SQLAlchemy==2.0.48 Authlib==1.6.9 tornado==6.5.5 pyasn1==0.6.3 --retries 3 --timeout 25"
$upgrade = Invoke-SSH -Command $upgradeCmd
Write-Output $upgrade.Output

$versions = Invoke-SSH -Command "$ToolkitRoot/.venv/bin/pip show redis croniter msal SQLAlchemy Authlib tornado pyasn1 | egrep '^(Name|Version):'"
Write-Output "Patched package versions:"
Write-Output $versions.Output

Write-Output "[6] Cleaning first-boot and lab state..."
$distributionPrep = @'
set -euo pipefail

install -d -m 755 /var/lib/audit-toolkit

# Reset all first-boot markers so customer onboarding runs on first login/boot.
rm -f __TOOLKIT__/.first-boot-complete __TOOLKIT__/.first-boot /root/.first-boot-complete \
      /var/lib/audit-toolkit/.first-boot /var/lib/audit-toolkit/.first-boot-complete \
      /var/lib/audit-toolkit/.first-login-wizard-complete /var/lib/audit-toolkit/.setup-complete 2>/dev/null || true

find __TOOLKIT__ -name '*.log' -type f -delete 2>/dev/null || true
rm -f __TOOLKIT__/.env.lab __TOOLKIT__/.env.local /root/.env.lab 2>/dev/null || true

# Reset network to DHCP so deployments come up in customer environments.
IFACE=$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')
if [[ -z "${IFACE}" ]]; then
    IFACE=$(ip -o link show | awk -F': ' '$2 != "lo" {print $2; exit}')
fi
if [[ -n "${IFACE}" ]]; then
    cat > /etc/netplan/90-audit-toolkit.yaml <<NETEOF
network:
    version: 2
    ethernets:
        ${IFACE}:
            dhcp4: true
NETEOF
    chmod 600 /etc/netplan/90-audit-toolkit.yaml
fi

# Remove per-lab identity artifacts so clones regenerate unique identity.
rm -f /etc/ssh/ssh_host_*
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id

if command -v cloud-init >/dev/null 2>&1; then
    cloud-init clean --seed --logs 2>/dev/null || true
fi

if systemctl list-unit-files | grep -q '^audit-toolkit-first-boot.service'; then
    systemctl enable audit-toolkit-first-boot.service >/dev/null 2>&1 || true
fi
if systemctl list-unit-files | grep -q '^audit-toolkit-firstboot.service'; then
    systemctl enable audit-toolkit-firstboot.service >/dev/null 2>&1 || true
fi

cat /dev/null > /root/.bash_history 2>/dev/null || true
echo "DISTRIBUTION_PREP_READY"
'@
$distributionPrep = $distributionPrep.Replace("__TOOLKIT__", $ToolkitRoot)
Invoke-Sudo -Command $distributionPrep | Out-Null
Invoke-SSH -Command "cat /dev/null > ~/.bash_history 2>/dev/null || true" -IgnoreErrors | Out-Null
Write-Output "Cleanup complete."

if (-not $SkipShutdown) {
    Write-Output "[7] Shutting down VM in 10 seconds..."
    Invoke-Sudo -Command "sleep 10; systemctl isolate poweroff" -IgnoreErrors | Out-Null
    Write-Output "Shutdown command sent."
} else {
    Write-Output "[7] SkipShutdown set; VM left running."
}

Write-Output ""
Write-Output "=== Completed ==="
Write-Output "DNS updates applied, dependencies patched, and first-boot distribution state reset."
