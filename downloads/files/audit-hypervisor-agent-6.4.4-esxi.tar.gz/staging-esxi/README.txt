Security Audit Toolkit - Hypervisor Agent 6.4.4 (ESXi Edition)

Installation:
  sh ./install-esxi.sh -s <server_url> -k <api_key>

IMPORTANT NOTES:
  - Python 3 must be available on the ESXi host (ESXi 7.0+ recommended)
  - The 'requests' library may not be available; the agent will operate in
    local buffer mode and you can retrieve results manually if needed
  - Files do NOT persist across ESXi firmware upgrades — reinstall after upgrade
  - Runs as root (no dedicated service account)

Documentation: https://github.com/AuditToolkitLabs/Audit-Tool-
