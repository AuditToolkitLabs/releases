Security Audit Toolkit - Hypervisor Agent 6.4.4

Supported platforms (this archive):
  - Proxmox VE    : ./install-linux.sh --platform proxmox -s <server> -k <apikey>
  - KVM/libvirt   : ./install-linux.sh --platform kvm -s <server> -k <apikey>
  - XCP-ng / Xen  : ./install-linux.sh --platform xen -s <server> -k <apikey>
  - Nutanix (CVM) : ./install-linux.sh --platform nutanix -s <server> -k <apikey>

For VMware ESXi use the -esxi.tar.gz archive instead.

Documentation: https://github.com/AuditToolkitLabs/Audit-Tool-
