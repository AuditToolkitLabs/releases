# API Security Quick Reference

## 🔐 Authentication

### Get API Key
```bash
# Auto-generated on first run, stored in .api_key
cat .api_key
```

### Use API Key (Option 1: Header)
```bash
curl http://localhost:5000/api/audits \
  -H "X-API-Key: your-api-key-here"
```

### Use API Key (Option 2: Session)
```bash
# Authenticate once
curl -X POST http://localhost:5000/api/auth \
  -H "Content-Type: application/json" \
  -d '{"api_key":"your-api-key-here"}'

# Use session cookie for subsequent requests
curl http://localhost:5000/api/audits \
  --cookie-jar cookies.txt \
  --cookie cookies.txt
```

### JavaScript Integration
```javascript
// Option 1: Header
fetch('/api/audits', {
    headers: {'X-API-Key': 'your-api-key-here'}
});

// Option 2: Session (authenticate once)
await fetch('/api/auth', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({api_key: 'your-api-key-here'})
});

fetch('/api/audits', {
    credentials: 'include'  // Use session
});
```

---

## 🚦 Rate Limits

| Endpoint | Limit | Scope |
|----------|-------|-------|
| **All endpoints** | 200/day, 50/hour | Per IP |
| `/api/auth` | 5/minute | Brute force protection |
| `/api/execute` | 10/hour | Resource intensive |
| `/api/deploy` | 5/hour | Critical operation |
| `/api/servers/add` | 10/hour | Abuse prevention |
| `/api/servers/test` | 10/hour | Connection testing |
| `/api/reports/generate` | 10/hour | Resource intensive |
| `/api/reports/fetch` | 20/hour | Log retrieval |
| `/api/plans/save` | 20/hour | File operations |

**Response when rate limited:**
```json
HTTP 429 Too Many Requests
```

---

## ✅ Input Validation

### Hostnames
- Max 253 characters
- Alphanumeric + dots + hyphens only
- Pattern: `^[a-zA-Z0-9.-]+$`

### Usernames
- Max 32 characters
- Alphanumeric + underscore + hyphen only
- Pattern: `^[a-zA-Z0-9_-]+$`

### Ports
- Range: 1-65535
- Integer only

### Filenames
- Alphanumeric + dots + hyphens + underscores
- No path separators (`/`, `\`)
- No parent directory (`..`)
- Pattern: `^[a-zA-Z0-9._-]+$`

### Paths
- Must resolve within intended directory
- Automatic path traversal prevention

---

## 🌐 CORS Configuration

### Development (Default)
```python
ALLOWED_ORIGINS = "http://localhost:5000"
```

### Production
```bash
export ALLOWED_ORIGINS="https://yourdomain.com,https://admin.yourdomain.com"
```

### JavaScript Requirements
```javascript
// Enable credentials for session-based auth
fetch('/api/endpoint', {
    credentials: 'include'
});
```

---

## 🔒 Production Security Checklist

```bash
# Essential environment variables
export FLASK_ENV=production
export FLASK_SECRET_KEY="$(openssl rand -hex 32)"
export ALLOWED_ORIGINS="https://yourdomain.com"

# Optional: Override auto-generated API key
export API_KEY="your-custom-api-key"
```

### Startup Command
```bash
# Install dependencies
pip install -r web/requirements.txt

# Run in production mode
FLASK_ENV=production python web/app.py
```

---

## 🛡️ Security Headers

Automatically set by the application:

```
SESSION_COOKIE_HTTPONLY = True    # Prevent XSS access
SESSION_COOKIE_SECURE = True      # HTTPS only (production)
SESSION_COOKIE_SAMESITE = 'Lax'   # CSRF protection
```

---

## 📊 Error Responses

| Status | Meaning | Cause |
|--------|---------|-------|
| `400` | Bad Request | Invalid input/malformed JSON |
| `401` | Unauthorized | Missing API key |
| `403` | Forbidden | Invalid API key |
| `404` | Not Found | Resource doesn't exist |
| `429` | Too Many Requests | Rate limit exceeded |
| `500` | Internal Server Error | Server-side error |

---

## 🔍 Security Logging

### Events Logged

✅ **Authentication Events**
- Successful authentication (with IP)
- Failed authentication attempts (with IP)
- Unauthorized access attempts (with IP)

✅ **Security Events**
- Invalid filename attempts (path traversal)
- Invalid hostname/username attempts
- API key generation

✅ **SSH Operations**
- Connection attempts
- Host key scanning
- Deployment operations
- Remote command execution

### Log Location
```
logs/web.log
```

### Example Log Entries
```
2026-02-04 10:30:15 - WARNING - Unauthorized access attempt from 192.168.1.100
2026-02-04 10:30:20 - WARNING - Invalid API key from 192.168.1.100
2026-02-04 10:30:25 - WARNING - Path traversal attempt: ../../../etc/passwd from 192.168.1.100
2026-02-04 10:31:00 - INFO - Successful authentication from 192.168.1.50
```

---

## 🧪 Testing Security Features

### Test Authentication
```bash
# Should fail (401)
curl http://localhost:5000/api/audits

# Should succeed (200)
curl http://localhost:5000/api/audits -H "X-API-Key: $(cat .api_key)"
```

### Test Rate Limiting
```bash
# Trigger rate limit (5/minute for auth)
for i in {1..10}; do
  curl -X POST http://localhost:5000/api/auth \
    -H "Content-Type: application/json" \
    -d '{"api_key":"test"}'
  sleep 0.5
done
# Expected: 429 after 5 requests
```

### Test Input Validation
```bash
API_KEY=$(cat .api_key)

# Invalid hostname (should fail with 400)
curl -X POST http://localhost:5000/api/servers/add \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"test","host":"inv@lid","user":"root","auth_type":"password"}'

# Path traversal (should fail with 400)
curl http://localhost:5000/api/logs/../../../etc/passwd \
  -H "X-API-Key: $API_KEY"

# Invalid port (should fail with 400)
curl -X POST http://localhost:5000/api/servers/add \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"test","host":"example.com","user":"root","port":99999,"auth_type":"password"}'
```

---

## 🔧 Troubleshooting

### Issue: "API key required"
**Solution:** Include API key in request
```bash
curl http://localhost:5000/api/audits -H "X-API-Key: $(cat .api_key)"
```

### Issue: "Invalid API key"
**Solution:** Verify API key matches `.api_key` file
```bash
# Check API key
cat .api_key

# Use exact key
curl http://localhost:5000/api/audits -H "X-API-Key: $(cat .api_key)"
```

### Issue: "429 Too Many Requests"
**Solution:** Wait for rate limit window to reset or adjust limits in code

### Issue: "Invalid hostname/username"
**Solution:** Ensure input matches validation rules (alphanumeric + allowed chars)

### Issue: CORS errors in browser
**Solution:** Configure ALLOWED_ORIGINS
```bash
export ALLOWED_ORIGINS="http://localhost:5000,http://localhost:3000"
```

### Issue: Rate limiting not working
**Solution:** Install Flask-Limiter
```bash
pip install flask-limiter
```

---

## 📚 Related Documentation

- [Security Fixes Applied](SECURITY-FIXES-APPLIED.md) - Detailed fix documentation
- [Security Implementation Guide](SECURITY-IMPLEMENTATION-GUIDE.md) - Implementation details
- [Security Review](README-SECURITY.md) - Security architecture overview

---

## 🚨 Security Contact

For security vulnerabilities or concerns:
1. Review security documentation
2. Check logs in `logs/web.log`
3. Follow responsible disclosure practices
4. Do not expose the API to untrusted networks without additional hardening

**Last Updated:** February 4, 2026
