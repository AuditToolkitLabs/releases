# Remote Cleanup & Uninstallation Guide

Comprehensive guide for remotely removing the Security Audit Toolkit from audited target machines.

---

## Overview

The **Remote Cleanup** feature allows you to safely remove the Security Audit Toolkit from remote servers that were previously audited. This is essential for:

- **Decommissioning** - Removing toolkit after audit completion
- **Security hygiene** - Eliminating unnecessary files from production servers
- **Disk space recovery** - Freeing up storage on target machines
- **Compliance** - Ensuring no audit tools remain on production systems

---

## How It Works

### Cleanup Process

The cleanup operation performs the following steps on each selected server:

1. **🔍 Verification** (if enabled)
   - Checks that the directory exists
   - Verifies it contains `orchestrator/orchestrator.sh` (confirms it's our toolkit)
   - Prevents accidental deletion of wrong directories

2. **⏹️ Stop Running Audits**
   - Terminates any active audit processes
   - Ensures clean removal without file locks

3. **📊 Calculate Disk Usage**
   - Measures directory size before removal
   - Reports how much disk space will be freed

4. **🗑️ Remove Directory**
   - Recursively deletes the entire toolkit directory
   - Uses `rm -rf` on the remote path

5. **✅ Verify Removal**
   - Confirms the directory no longer exists
   - Returns success/failure status

6. **🧹 SSH Cleanup**
   - Closes SSH control master connections
   - Cleans up temporary files

---

## Using the Web Interface

### Step 1: Navigate to Deploy Tab

Click the **"Deploy"** tab in the web management console.

### Step 2: Select Servers

- **Individual Selection**: Click on server cards to select/deselect
- **Multiple Selection**: Hold Ctrl and click multiple servers
- **Selection Count**: Shows "X servers selected" in the action bar

### Step 3: Initiate Cleanup

1. Click the **"🗑️ Cleanup Selected"** button (red button in action bar)
2. A confirmation modal will appear showing:
   - List of selected servers
   - Server hostnames and remote paths
   - Verification checkbox option
   - Full cleanup checkbox option

### Step 4: Confirm Cleanup

**⚠️ Review the Confirmation Modal Carefully!**

- **Server List**: Review all servers that will be cleaned up
- **Verification Option**: 
  - ✅ **Checked (Recommended)**: Verifies toolkit installation before removal
  - ❌ **Unchecked**: Removes directory without verification (dangerous)
- **Full Cleanup Option**:
  - ❌ **Unchecked (Default)**: Removes only the installation directory
  - ✅ **Checked**: Also removes systemd services, cron jobs, config files (`/etc/audit-toolkit`), and logs (`/var/log/audit-toolkit`)

**⚠️ WARNING: This action cannot be undone!**

### Step 5: Monitor Progress

The cleanup progress panel will show:
- Real-time status for each server
- ✅ Success indicators
- ❌ Failure indicators with error details
- Disk space freed per server
- Summary statistics (Total/Successful/Failed)

---

## Using the API

### Endpoint

```http
POST /api/cleanup
Content-Type: application/json
X-API-Key: your-api-key
```

### Request Body

```json
{
  "server_ids": [1, 2, 3],
  "verify": true,
  "full_cleanup": false
}
```

**Parameters:**
- `server_ids` (required): Array of server IDs to clean up
- `verify` (optional): Boolean, default `true`. If `true`, verifies path before deletion
- `full_cleanup` (optional): Boolean, default `false`. If `true`, removes ALL artifacts (see below)

### Standard vs Full Cleanup

| Component | Standard Cleanup | Full Cleanup |
|-----------|-----------------|--------------|
| Installation directory | ✅ Removed | ✅ Removed |
| Running audit processes | ✅ Killed | ✅ Killed |
| Systemd service/timer | ❌ Kept | ✅ Removed |
| Cron job (`/etc/cron.d/audit-toolkit`) | ❌ Kept | ✅ Removed |
| Wrapper script (`/usr/local/bin/audit-toolkit`) | ❌ Kept | ✅ Removed |
| Config directory (`/etc/audit-toolkit`) | ❌ Kept | ✅ Removed |
| Log directory (`/var/log/audit-toolkit`) | ❌ Kept | ✅ Removed |

**When to use Full Cleanup:**
- End of engagement/audit period
- Compliance requirement to remove all traces
- Security policy mandates complete removal
- Preparing system for decommissioning

**When to use Standard Cleanup:**
- Temporary removal with intent to redeploy
- Preserving logs for later analysis
- Keeping configuration for quick reinstall

### Response (Success)

```json
{
  "success": true,
  "summary": {
    "total": 3,
    "successful": 2,
    "failed": 1
  },
  "results": {
    "1": {
      "success": true,
      "server_name": "web-server-01",
      "server_host": "192.168.1.10",
      "message": "Full cleanup completed (toolkit + system files)",
      "disk_freed": "45M",
      "remote_path": "/opt/security-audit-toolkit",
      "extra_cleaned": ["systemd services", "cron job", "wrapper script", "config files", "log files"]
    },
    "2": {
      "success": true,
      "server_name": "db-server-01",
      "server_host": "192.168.1.20",
      "message": "Toolkit not found (already removed or never installed)",
      "skipped": true
    },
    "3": {
      "success": false,
      "server_name": "app-server-01",
      "server_host": "192.168.1.30",
      "error": "Failed to remove toolkit directory",
      "stderr": "Permission denied"
    }
  }
}
```

### Response (Error)

```json
{
  "success": false,
  "error": "No servers specified"
}
```

### Example (curl)

```bash
# Standard cleanup (removes installation directory only)
curl -X POST http://localhost:5000/api/cleanup \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "server_ids": [1, 2, 3],
    "verify": true
  }'

# Full cleanup (removes ALL artifacts including systemd, cron, config, logs)
curl -X POST http://localhost:5000/api/cleanup \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "server_ids": [1, 2, 3],
    "verify": true,
    "full_cleanup": true
  }'
```

### Example (Python)

```python
import requests

# Full cleanup example
response = requests.post(
    'http://localhost:5000/api/cleanup',
    headers={
        'Content-Type': 'application/json',
        'X-API-Key': 'your-api-key'
    },
    json={
        'server_ids': [1, 2, 3],
        'verify': True,
        'full_cleanup': True  # Remove ALL artifacts
    }
)

data = response.json()
print(f"Total: {data['summary']['total']}")
print(f"Successful: {data['summary']['successful']}")
print(f"Failed: {data['summary']['failed']}")

# Show what was cleaned for each server
for server_id, result in data['results'].items():
    if result.get('extra_cleaned'):
        print(f"{result['server_name']}: Also removed {', '.join(result['extra_cleaned'])}")
```

---

## Safety Features

### Verification Mode (Recommended)

When `verify: true` (default):

✅ **Safe**:
- Checks directory exists before removal
- Verifies `orchestrator/orchestrator.sh` file is present
- Ensures you're removing the correct toolkit installation
- Prevents accidental deletion of other directories

❌ **Dangerous** when `verify: false`:
- Removes directory without verification
- Could delete wrong path if misconfigured
- Only use if you're absolutely certain of the path

### Result Codes

| Status | Description | Action |
|--------|-------------|--------|
| **✅ SUCCESS** | Toolkit removed successfully | Directory deleted, disk freed |
| **⏭️ SKIPPED** | Toolkit not found | Already removed or never installed |
| **❌ FAILED** | Cleanup operation failed | Check error details, may require manual cleanup |

### Common Failure Reasons

1. **Permission Denied**
   - **Cause**: User lacks permissions to delete directory
   - **Solution**: Use a user with sudo privileges or chown the directory

2. **Path Verification Failed**
   - **Cause**: Directory doesn't contain `orchestrator/orchestrator.sh`
   - **Solution**: Disable verification or check path configuration

3. **Operation Timed Out**
   - **Cause**: Cleanup took longer than 5 minutes
   - **Solution**: Check server connectivity, try again

4. **Directory Still Exists After Removal**
   - **Cause**: File system lock or permissions issue
   - **Solution**: Manual SSH investigation required

---

## Manual Cleanup (Fallback)

If automated cleanup fails, you can manually remove the toolkit:

### SSH to Target Server

```bash
ssh user@server-hostname
```

### Verify Installation

```bash
# Check if toolkit exists
ls -la /opt/security-audit-toolkit

# Verify it's the toolkit
ls /opt/security-audit-toolkit/orchestrator/orchestrator.sh
```

### Stop Running Audits

```bash
# Find running audit processes
ps aux | grep security-audit-toolkit

# Kill them
pkill -f /opt/security-audit-toolkit
```

### Remove Directory

```bash
# Check disk usage before
du -sh /opt/security-audit-toolkit

# Remove toolkit
sudo rm -rf /opt/security-audit-toolkit

# Verify removal
ls /opt/security-audit-toolkit
# Should show: No such file or directory
```

### Clean Up Logs (Optional)

```bash
# Remove any log files (if stored outside toolkit directory)
sudo rm -rf /var/log/security-audit-toolkit*
```

---

## Bulk Operations

### Cleanup All Servers

```bash
# Get all server IDs
curl http://localhost:5000/api/servers/list \
  -H "X-API-Key: your-api-key" \
  | jq '.servers[].id'

# Cleanup all servers
curl -X POST http://localhost:5000/api/cleanup \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "server_ids": [1, 2, 3, 4, 5],
    "verify": true
  }'
```

### Cleanup by Server Group

```python
import requests

# Get servers
response = requests.get('http://localhost:5000/api/servers/list')
servers = response.json()['servers']

# Filter by criteria (e.g., all production servers)
prod_servers = [s for s in servers if 'prod' in s['name'].lower()]
prod_ids = [s['id'] for s in prod_servers]

# Cleanup production servers
requests.post(
    'http://localhost:5000/api/cleanup',
    json={'server_ids': prod_ids, 'verify': True}
)
```

---

## Best Practices

### 1. Always Enable Verification

```json
{
  "server_ids": [1, 2, 3],
  "verify": true  // ✅ ALWAYS use verification
}
```

### 2. Test on Non-Production First

- Clean up dev/test servers first
- Verify the process works correctly
- Then proceed with production servers

### 3. Backup Important Data

Before cleanup, ensure:
- Audit reports are saved locally
- Log files are archived
- Any custom configurations are documented

For whole-tool coverage (Audit Tool + Asset Discovery), confirm backup policy includes shared service data:
- `backup_include_shared_data`: `true`
- `backup_shared_data_paths` defaults:
  - `/opt/audit-toolkit/data/agents`
  - `/opt/audit-toolkit/shared/asset-discovery-data`
  - `/opt/audit-toolkit/shared/asset-discovery-logs`

Manage these from **SuperAdmin → Security Settings → Critical Hardening Controls**.
Only override paths when your deployment uses different mount points (for example, custom container volume targets).

### 4. Monitor Cleanup Progress

- Watch the cleanup progress panel
- Note any failures
- Investigate errors immediately

### 5. Verify Removal

After cleanup, SSH to servers and verify:
```bash
ls /opt/security-audit-toolkit
# Should return: No such file or directory
```

### 6. Document Cleanup Operations

Maintain a record of:
- Which servers were cleaned
- When cleanup occurred
- Who initiated the cleanup
- Any issues encountered

---

## Troubleshooting

### Issue: "Permission Denied"

**Solution:**
1. Ensure SSH user has sudo privileges
2. Or change ownership of directory before cleanup:
   ```bash
   sudo chown -R $USER:$USER /opt/security-audit-toolkit
   ```

### Issue: "Path Verification Failed"

**Possible Causes:**
- Wrong remote path configured in server settings
- Directory was manually modified
- Toolkit was partially removed

**Solution:**
1. Check server configuration: `/servers/<server-id>.json`
2. Update `remote_path` if incorrect
3. Or disable verification (use with caution)

### Issue: "Operation Timed Out"

**Solution:**
1. Check server connectivity: `ssh user@host "echo ok"`
2. Verify SSH key authentication works
3. Increase timeout in code (modify `cleanup_server_installation()`)

### Issue: "Directory Still Exists After Removal"

**Solution:**
Manual investigation required:
```bash
ssh user@host
ls -la /opt/security-audit-toolkit
lsof +D /opt/security-audit-toolkit  # Check for open files
sudo rm -rf /opt/security-audit-toolkit
```

---

## Security Considerations

### Authentication

Cleanup operations use the same SSH authentication as deployment:
- **Password**: Encrypted at rest using Fernet encryption
- **SSH Key**: Path to private key file
- **Host Key Verification**: Uses `StrictHostKeyChecking=accept-new`

### Audit Trail

All cleanup operations are logged:
- **Location**: `logs/web.log`
- **Details**: Server name, host, operation result, timestamp
- **Format**: Standard Python logging format

**Example Log Entry:**
```
2026-02-04 10:15:30 - INFO - Starting cleanup for web-server-01 at /opt/security-audit-toolkit
2026-02-04 10:15:32 - INFO - Stopped running audits on web-server-01
2026-02-04 10:15:35 - INFO - Successfully cleaned up web-server-01
```

### Permissions Required

**Remote Server:**
- Read permissions on toolkit directory
- Write permissions on parent directory (for deletion)
- Execute permissions on `pkill` and `rm` commands

**Management Host:**
- SSH access to remote servers
- API authentication (X-API-Key header)

---

## Integration Examples

### Ansible Playbook

```yaml
---
- name: Cleanup Security Audit Toolkit
  hosts: localhost
  tasks:
    - name: Get server list
      uri:
        url: "http://localhost:5000/api/servers/list"
        headers:
          X-API-Key: "{{ api_key }}"
        return_content: yes
      register: servers_result

    - name: Extract server IDs
      set_fact:
        server_ids: "{{ servers_result.json.servers | map(attribute='id') | list }}"

    - name: Cleanup all servers
      uri:
        url: "http://localhost:5000/api/cleanup"
        method: POST
        headers:
          Content-Type: "application/json"
          X-API-Key: "{{ api_key }}"
        body_format: json
        body:
          server_ids: "{{ server_ids }}"
          verify: true
      register: cleanup_result

    - name: Display cleanup results
      debug:
        msg: "Cleaned up {{ cleanup_result.json.summary.successful }}/{{ cleanup_result.json.summary.total }} servers"
```

### Terraform (Null Resource)

```hcl
resource "null_resource" "cleanup_audit_toolkit" {
  provisioner "local-exec" {
    command = <<-EOT
      curl -X POST http://localhost:5000/api/cleanup \
        -H "Content-Type: application/json" \
        -H "X-API-Key: ${var.api_key}" \
        -d '{"server_ids": [1,2,3], "verify": true}'
    EOT
  }

  triggers = {
    cleanup_timestamp = timestamp()
  }
}
```

---

## FAQ

### Q: Can I undo a cleanup operation?

**A:** No, cleanup is permanent. The toolkit directory is deleted from the remote server. You would need to redeploy the toolkit if needed again.

### Q: What happens to audit results?

**A:** Audit results are **not** stored on target servers by default. They are returned to the management host. The cleanup only removes the toolkit code, not audit history.

### Q: Will cleanup remove system files?

**A:** No, as long as verification is enabled. Verification ensures the directory contains `orchestrator/orchestrator.sh` before removal.

### Q: Can I cleanup servers that failed deployment?

**A:** Yes, cleanup will skip servers where the toolkit was never successfully deployed (returns "Toolkit not found" message).

### Q: How long does cleanup take?

**A:** Typically 5-15 seconds per server. Maximum timeout is 5 minutes per server.

### Q: Can I cleanup while audits are running?

**A:** Yes, the cleanup process will first stop any running audits before removal.

### Q: Is cleanup parallel or sequential?

**A:** Parallel. Up to 5 servers are cleaned simultaneously using a thread pool.

---

## Related Documentation

- [Deployment Guide](DEPLOYMENT-GUIDE.md)
- [API Reference](API-REFERENCE.md)
- [Security Guide](README-SECURITY.md)
- [Troubleshooting](TROUBLESHOOTING.md)

---

## Support

For issues with cleanup operations:

1. **Check Logs**: `logs/web.log`
2. **Test SSH Connectivity**: `ssh user@host`
3. **Verify Server Configuration**: `/servers/<id>.json`
4. **Try Manual Cleanup**: See "Manual Cleanup" section above

**Still having issues?** Open a GitHub issue with:
- Error message from UI/API
- Relevant log entries
- Server OS and configuration
- Steps to reproduce

---

**Last Updated:** February 12, 2026  
**Version:** 6.4.1-rc1


