# Custom SSH Port Configuration Guide

**Feature Status:** ✅ FULLY IMPLEMENTED  
**Date:** February 4, 2026  

## Overview

The Security Audit Toolkit supports custom SSH port configuration for all remote servers. This aligns with security best practices (CIS Benchmarks, NIST guidelines) which recommend using non-standard SSH ports to reduce automated attack surface.

---

## Why Custom SSH Ports?

### Security Benefits

**Standard Port 22 Issues:**
- 🎯 Most targeted port by automated scanners
- 📊 Generates excessive log noise
- 🔍 Obvious attack vector for reconnaissance

**Custom Port Benefits:**
- ✅ Reduces automated attack attempts (99% of brute force hits port 22)
- ✅ Reduces SSH log noise from scanners
- ✅ Provides defense-in-depth
- ✅ Complies with CIS Benchmarks
- ✅ Aligns with NIST SP 800-53 recommendations

### Real-World Impact
```
Standard Port 22:
  - Receives 1000+ automated login attempts per day
  - Log noise from port scanners constantly
  - Higher resource usage from failed connections

Custom Port 2222:
  - Minimal automated attempts
  - Clean logs focused on legitimate access
  - Better monitoring signal-to-noise ratio
```

---

## Implementation Status

### ✅ What's Already Implemented

| Component | Status | Details |
|-----------|--------|---------|
| Backend support | ✅ DONE | app.py fully supports custom ports |
| HTML form field | ✅ DONE | "SSH Port" field in server configuration |
| JavaScript handling | ✅ DONE | Port value parsed and sent to API |
| SSH integration | ✅ DONE | `-p` flag used in all SSH/SCP commands |
| Host key scanning | ✅ DONE | Port included in `ssh-keyscan` |
| Configuration storage | ✅ DONE | Port value encrypted and saved |
| Documentation | ✅ DONE | Guides provided below |

---

## How to Use Custom SSH Ports

### Adding a Server with Custom Port

#### Via Web Interface

**Step 1: Open Server Configuration**
1. Go to "Servers" tab in web interface
2. Click "Add Server" button

**Step 2: Fill in Server Details**
```
Server Name:        production-web-01
Hostname / IP:      192.168.1.100
SSH Port:           2222              ← Custom port here (not 22)
Username:           deployer
OS Type:            Linux
Authentication:     SSH Key (or Password)
SSH Key Path:       ~/.ssh/audit-toolkit
Remote Path:        /opt/audit-toolkit
```

**Step 3: Test Connection**
- Click "Test Connection"
- System automatically uses port 2222
- Scans host key on port 2222
- Verifies connectivity

**Step 4: Deploy/Run Audits**
- System automatically uses port 2222 for all operations
- No additional configuration needed

#### Via Configuration File

**Manual server configuration (for advanced users):**

```json
{
  "servers": [
    {
      "id": 1,
      "name": "production-web-01",
      "host": "192.168.1.100",
      "port": 2222,                    // Custom port
      "user": "deployer",
      "auth_type": "public_key",
      "key_path": "/home/admin/.ssh/audit-toolkit",
      "remote_path": "/opt/audit-toolkit",
      "added": "2026-02-04T14:32:00"
    }
  ]
}
```

---

## Port Configuration Examples

### Example 1: Standard Port (Legacy System)
```json
{
  "name": "legacy-system-01",
  "host": "10.0.0.50",
  "port": 22,                    // Default SSH port
  "user": "admin",
  "auth_type": "password"
}
```

### Example 2: Hardened Production Server
```json
{
  "name": "prod-web-01",
  "host": "192.168.1.100",
  "port": 2222,                  // Non-standard port
  "user": "deployer",
  "auth_type": "public_key",
  "key_path": "/home/ops/.ssh/prod-key"
}
```

### Example 3: Multiple Servers with Different Ports
```json
{
  "servers": [
    {
      "name": "web-server-01",
      "host": "web01.example.com",
      "port": 2222,               // Custom port
      "user": "deployer",
      "auth_type": "public_key"
    },
    {
      "name": "db-server-01",
      "host": "db01.example.com",
      "port": 2223,               // Different custom port
      "user": "dba_deployer",
      "auth_type": "public_key"
    },
    {
      "name": "legacy-server",
      "host": "legacy.internal.local",
      "port": 22,                 // Can still use standard port if needed
      "user": "root",
      "auth_type": "password"
    }
  ]
}
```

---

## Setting Up Custom SSH Ports on Remote Servers

### For Linux Servers

#### 1. Configure SSH Daemon

```bash
# On the remote server
sudo nano /etc/ssh/sshd_config

# Find the line:
# Port 22

# Change to:
Port 2222

# Save and exit (Ctrl+X, Y, Enter in nano)
```

#### 2. Verify the Configuration

```bash
# Check syntax is correct
sudo sshd -t

# Output should be empty (no errors)
```

#### 3. Restart SSH Service

**Debian/Ubuntu:**
```bash
sudo systemctl restart ssh
```

**RHEL/Fedora:**
```bash
sudo systemctl restart sshd
```

**Alpine/OpenRC:**
```bash
sudo rc-service sshd restart
```

#### 4. Verify SSH is Listening on New Port

```bash
# Check that SSH is listening on port 2222
sudo ss -tulpn | grep :2222

# Output should show:
# tcp  LISTEN  0  128  0.0.0.0:2222  0.0.0.0:*  users:(("sshd",pid=xxxx,fd=xx))
```

#### 5. Test Connection from Management Host

```bash
# Test connection to new port
ssh -p 2222 deployer@192.168.1.100

# Should connect successfully
# Once verified, close the connection
exit
```

#### 6. Update Firewall (if enabled)

```bash
# For ufw (Ubuntu):
sudo ufw allow 2222/tcp

# For firewalld (RHEL/Fedora):
sudo firewall-cmd --add-port=2222/tcp --permanent
sudo firewall-cmd --reload

# For iptables:
sudo iptables -A INPUT -p tcp --dport 2222 -j ACCEPT
# Save with: sudo iptables-save > /etc/iptables/rules.v4
```

#### 7. Close Port 22 (Optional but Recommended)

```bash
# Only after verifying port 2222 works!
# For ufw:
sudo ufw delete allow 22/tcp

# For firewalld:
sudo firewall-cmd --remove-service=ssh --permanent
sudo firewall-cmd --reload
```

---

## Verification Checklist

### Before Adding to Toolkit

- [ ] SSH daemon updated to new port in `/etc/ssh/sshd_config`
- [ ] SSH service restarted and running
- [ ] New port verified with `ss -tulpn` or `netstat -tulpn`
- [ ] Manual SSH connection test successful: `ssh -p 2222 user@host`
- [ ] Firewall rules updated (if applicable)
- [ ] Old port 22 can be closed or disabled
- [ ] No other services using the new port

### In Toolkit

- [ ] Server added with custom port in web interface
- [ ] "Test Connection" button passes
- [ ] Deployment to server succeeds
- [ ] Log retrieval works
- [ ] Audits can be executed on remote server

---

## Troubleshooting

### Issue: "Connection refused" on custom port

**Possible Causes:**
1. SSH daemon not restarted after config change
2. Port blocked by firewall
3. SSH service not listening on new port
4. Typo in port configuration

**Solution:**
```bash
# On remote server:
1. Verify config: sudo sshd -t
2. Restart SSH: sudo systemctl restart sshd
3. Check port: sudo ss -tulpn | grep :2222
4. Check firewall: sudo ufw status (or firewall-cmd --list-all)
5. Test locally: ssh -p 2222 localhost
```

### Issue: "Could not scan SSH host key"

**Possible Causes:**
1. Port number incorrect in toolkit
2. Port not reachable from management host
3. Network firewall blocking port

**Solution:**
```bash
# From management host:
1. Verify port is reachable: nmap -p 2222 192.168.1.100
2. Check toolkit port setting
3. Verify firewall allows traffic from management host
4. Check network routing
```

### Issue: Successful test but deployment fails

**Possible Causes:**
1. Port works for SSH but SCP having issues
2. User permissions differ between interactive and non-interactive SSH

**Solution:**
```bash
# Test SCP explicitly:
scp -P 2222 /tmp/test.txt deployer@192.168.1.100:/tmp/

# Check user permissions:
ssh -p 2222 deployer@192.168.1.100 'id'

# Should show permissions for deployer user
```

---

## Best Practices for Custom SSH Ports

### 1. Port Selection

**✅ Recommended Ports:**
- 2222 (easy to remember)
- 2222-2299 (reserved for SSH alternatives)
- Above 1024 (non-privileged)
- Avoid well-known ports (see `/etc/services`)

**❌ Avoid:**
- 22 (default, too obvious)
- 80, 443 (HTTP/HTTPS)
- 3306 (MySQL)
- 5432 (PostgreSQL)
- Ports < 1024 (require root)

### 2. Port Consistency

```
Best Practice: Use same port across all servers
prod-web-01:   port 2222
prod-web-02:   port 2222
prod-db-01:    port 2222

This simplifies:
- Configuration management
- Network policies
- Monitoring
- Troubleshooting
```

### 3. Documentation

```bash
# Document your port mapping
cat <<EOF > /root/ssh_ports.txt
Server                 Hostname          Port
prod-web-01            192.168.1.100     2222
prod-web-02            192.168.1.101     2222
prod-api-01            192.168.1.102     2222
staging-web-01         192.168.2.100     2222
EOF
```

### 4. Security in Depth

Even with custom ports, apply these additional security measures:

```bash
# In /etc/ssh/sshd_config:
Port 2222
PermitRootLogin no              # Disable root login
PasswordAuthentication no        # Force key-based auth
PubkeyAuthentication yes
StrictModes yes                 # Check key file permissions
MaxAuthTries 3                  # Limit login attempts
LoginGraceTime 30               # Timeout for auth
X11Forwarding no                # Disable X11
AllowUsers deployer             # Restrict to specific user
```

### 5. Monitoring & Logging

```bash
# Monitor for SSH brute force attempts on custom port
grep "Invalid user" /var/log/auth.log | tail -20

# Count failed attempts
grep "Failed password" /var/log/auth.log | wc -l

# See what IPs are trying to connect
grep "sshd" /var/log/auth.log | grep "port 2222" | tail -10
```

---

## Integration with Toolkit Security Features

Custom ports work seamlessly with all security features:

### 1. Host Key Verification
```bash
# ssh-keyscan automatically uses the custom port:
ssh-keyscan -p 2222 192.168.1.100

# Stores in known_hosts as:
# [192.168.1.100]:2222 ssh-rsa AAAAB3...
```

### 2. Password Encryption
```python
# Port stored alongside password in servers.json
{
  "host": "192.168.1.100",
  "port": 2222,
  "password": "gAAAAABl3sXy7K9xV2J..."  # Encrypted
}
```

### 3. Safe Command Execution
```python
# Port included in command list (no shell injection risk)
cmd_parts = ['ssh', '-p', '2222', 'user@host', 'command']
# Safe: Special characters in port won't break syntax
```

### 4. Comprehensive Logging
```
2026-02-04 14:32:15 - INFO - Executing SSH command on prod-web-01: mkdir -p /opt...
  → Uses port 2222 transparently
```

---

## Migration from Port 22 to Custom Port

If converting existing servers from port 22:

### Step 1: Plan the Migration
```bash
# Document current setup
ssh -p 22 deployer@prod-web-01 'hostname'

# Schedule maintenance window
# Notify operations team
```

### Step 2: Update Remote Server
```bash
# On remote server:
sudo nano /etc/ssh/sshd_config
# Change Port 22 to Port 2222

sudo sshd -t        # Verify config
sudo systemctl restart ssh    # Restart
```

### Step 3: Verify New Port
```bash
# From management host:
ssh -p 2222 deployer@prod-web-01 'echo "Connected on 2222"'
```

### Step 4: Update Toolkit
```bash
# In web interface:
1. Edit server configuration
2. Change port from 22 to 2222
3. Click "Test Connection"
4. Verify deployment/audits work
```

### Step 5: Close Port 22 (Optional)
```bash
# On remote server:
sudo ufw delete allow 22/tcp
# Or update firewall rules
```

---

## Port Numbers Reference

| Port Range | Usage | Recommendation |
|-----------|-------|-----------------|
| 1-1023 | Privileged ports | Don't use (needs root) |
| 1024-49151 | Registered ports | ✅ Use 2222-2299 for SSH alternatives |
| 49152-65535 | Dynamic/private | Can use but less conventional |

**Recommended SSH Alternative Ports:**
- 2222 (most common)
- 2223 (for second SSH service)
- 2224 (for third SSH service)
- Etc.

---

## Examples with Real Scenarios

### Scenario 1: Single Production Server

```
Remote Server Setup:
  - /etc/ssh/sshd_config Port 2222
  - Firewall allows 2222 from management host
  
Toolkit Configuration:
  {
    "name": "prod-web-01",
    "host": "prod-web.example.com",
    "port": 2222,                  # Custom port
    "user": "deployer",
    "auth_type": "public_key"
  }
```

### Scenario 2: Multi-Server Environment

```
prod-web-01:    192.168.1.100 port 2222
prod-web-02:    192.168.1.101 port 2222
prod-db-01:     192.168.1.102 port 2222
staging-web-01: 192.168.2.100 port 2222
dev-01:         192.168.3.100 port 22 (dev doesn't need custom port)

All configured in toolkit, all work transparently.
```

### Scenario 3: Legacy Server Still on Port 22

```
If old server can't be updated:

toolkit config:
{
  "name": "legacy-system",
  "host": "192.168.0.50",
  "port": 22,              # Standard port
  "user": "root",
  "auth_type": "password"
}

Works fine alongside custom port servers.
```

---

## Compliance Alignment

Custom SSH port support aligns with:

| Standard | Recommendation | Status |
|----------|-----------------|--------|
| **CIS Benchmark** | Disable SSH on port 22, use alternative port | ✅ Supported |
| **NIST SP 800-53** | SC-7 - Boundary Protection | ✅ Compliant |
| **PCI-DSS** | Requirement 2.2.4 - Security configurations | ✅ Aligned |
| **OWASP** | A06:2021 - Defense in Depth | ✅ Implemented |

---

## Summary

### ✅ Custom SSH Port Support

- **Status:** Fully implemented and ready to use
- **How to use:** Enter custom port when adding server (defaults to 22)
- **Security benefit:** Reduces attack surface, aligns with best practices
- **Configuration:** Happens transparently in all toolkit operations
- **Testing:** Verify with "Test Connection" button

### Quick Start

1. On remote server: Change `/etc/ssh/sshd_config` Port to 2222
2. Restart SSH: `sudo systemctl restart ssh`
3. In toolkit: Add server with Port 2222
4. Click "Test Connection"
5. All operations use custom port automatically

**No additional configuration needed.** The toolkit handles custom ports seamlessly across all operations (deployment, audits, reporting).
