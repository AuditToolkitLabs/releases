# Security Audit Toolkit - Web Management Interface

A cross-platform HTML/browser-based management console for the Security Audit Toolkit.

> **Security Score:** 97.0/100 (A+) - See [Security Scorecard](../dev/code-reviews/SECURITY-SCORECARD.md) for details.
> **✅ Authentication:** Localhost connections (`127.0.0.1`) are auto-authenticated for convenience. For remote access or production use, see [Security Considerations](#security-considerations) section below.

## Features

### Core Functionality
- 🎯 **Audit Selection**: Browse and select from 285+ audits across Linux and Windows
- ⚡ **Quick Presets**: Run predefined audit sets (platform, web, security, minimal)
- 📊 **Real-time Execution**: Live output and progress tracking via WebSocket
- 💾 **Plan Management**: Save and reuse audit selections
- 📁 **Log Viewer**: Browse and view execution logs with syntax highlighting
- 🚀 **Support Tools Page**: Open official release sources and download JRE agent + Windows/Linux helper tooling
- 🌐 **Cross-Platform**: Supports Linux (7+ distros) and Windows Server/Desktop

### Enterprise Features
- 🔐 **RBAC**: Role-based access control with 5 permission levels
- 🔑 **SSO Integration**: SAML 2.0 and OIDC authentication providers
- 🏢 **Multi-Tenancy**: Organization isolation and tenant management
- 📈 **Analytics Dashboard**: 12 widget types with real-time updates
- 🔄 **Differential Auditing**: Compare audit runs over time, track drift
- 👥 **Server Groups**: Fleet management by environment/region

### Security Intelligence
- 🛡️ **CVE Database Integration**: Live vulnerability lookups for detected software
- 🔍 **HaveIBeenPwned Integration**: Credential breach checking
- 📝 **Developer Script Studio**: Create custom audits via web UI
- 📊 **Compliance Mapping**: Map findings to CIS, NIST, PCI-DSS controls

## Requirements

- Python 3.7+
- Bash (for orchestrator execution on Linux)
- PowerShell (for audit execution on Windows)
- Modern web browser (Chrome, Firefox, Edge, Safari)
- SSH client (ssh, scp commands available)
- sshpass (optional, for password-based auth - Linux/macOS only)

## Windows Audit Integration

The toolkit supports running audits on Windows servers using PowerShell scripts, fully integrated with the HTML Management GUI. All output, error handling, and reporting are unified with the Linux workflow.

### Windows Server Requirements

- Windows Server 2019/2022, Windows 10/11
- OpenSSH Server enabled (Settings > Apps > Optional Features > Add a feature > OpenSSH Server)
- PowerShell 5.1+ (default on modern Windows)
- Firewall rule to allow SSH (TCP 22)

### Adding a Windows Server

1. Go to the Deploy tab and click "Add Server".
2. Enter the hostname/IP, port (default 22), username, and authentication method (password or key).
3. Set **OS Type** to `windows`.
4. Set the remote path to where the audit scripts will be deployed (e.g., `C:\Audit-Tool`).

### How Audits Are Run

- The backend will use SSH to run PowerShell scripts on Windows:
   - `powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Audit-Tool\audits\windows\common\<script>.ps1"`
- Output is parsed for `[PASS]`, `[FAIL]`, `[WARN]`, and summary lines, just like Linux audits.
- Results and error handling are displayed in the GUI in the same way for both platforms.

### Notes

- Ensure the user account has permission to run PowerShell scripts and access the audit directory.
- If you encounter execution policy errors, use `Set-ExecutionPolicy RemoteSigned` (as Administrator) on the Windows host.
- All Windows audit scripts are read-only and safe to run on production systems.

For more details, see the main documentation and the Security Considerations section below.

## Quick Start

### 1. Install Dependencies

```bash
# From the web/ directory
pip install -r requirements.txt
```

Or install manually:
```bash
pip install Flask Flask-CORS
```

**For Remote Deployment (optional):**
```bash
# Linux (Debian/Ubuntu)
sudo apt install sshpass

# Linux (RHEL/CentOS/Fedora)
sudo yum install sshpass

# macOS (with Homebrew)
brew install hudochenkov/sshpass/sshpass
```

### 2. Start the Server

**Linux/macOS:**
```bash
cd web
python3 app.py
```

**Windows:**
```powershell
cd web
python app.py
```

### 3. Access the Interface

Open your browser and navigate to:
```
http://localhost:5000
```

## Usage

### Web Console Overview

The web console features a modern dashboard design across all tabs with:
- **Statistics Cards**: Real-time metrics at the top of each tab
- **Search & Filters**: Find items quickly with search bars and category filters
- **Card-Based Layouts**: Clean, responsive grid displays for data
- **Action Buttons**: Contextual actions for each item

### Audit Selection Tab

1. **Stats Dashboard**: View total audits, selected count, and category breakdown
2. **Search & Filter**: Use search box and Linux/Windows/All filter to find audits
3. **Audit Grid**: Card-based display showing audit name, description, and platform
4. **Quick Actions**:
   - Select All / Clear Selection
   - Apply Presets (all, platform, web, security, minimal)
5. **Add to Plan**: Save selection for future use

### Reports Tab

1. **Report Types**: Choose from HTML Summary, PDF, JSON, Executive Summary, or Compliance Report
2. **Server Selection**: Grid-based multi-select with status indicators
3. **Generate**: Click to create report with selected options
4. **Output Panel**: Preview and download generated reports

### Plans Tab

1. **Stats Dashboard**: Total plans and audit counts
2. **Plan Cards**: Each plan shows name, audit count, and action buttons
3. **Actions**: View audits, Run plan, Delete plan
4. **Search**: Filter plans by name

### Schedule Tab

1. **Two-Column Layout**: Schedule list and details side-by-side
2. **Schedule Cards**: Show name, frequency, next run time, and status badge
3. **Status Indicators**: Active (green), Paused (yellow), Error (red)
4. **Actions**: Create, edit, pause/resume, delete schedules

### Deploy Tab (Support Tools)

1. **Release Sources**: Open GitHub Releases and Customer Release Portal for full installers and appliance artifacts
2. **JRE Agent Downloads**: Download Linux/Windows unified JRE agent archives
3. **Windows Helpers**: Download WinRM/JEA precheck, setup, bundle, install, and Direct API scripts
4. **Linux Helpers**: Download SSH/sudo precheck, setup, bundle, install, and Direct API scripts
5. **Tooling**: Download config template and view Intune/SCCM/Ansible rollout script examples
6. **Auth Status**: API session readiness badge shown in page header

### Connect Tab

1. **Stats Dashboard**: Total connections, connected/disconnected counts
2. **Server Grid**: Card-based display with connection status indicators
3. **Add/Edit/Delete**: Manage server definitions
4. **Test Connectivity**: Verify SSH/WinRM connections
5. **OS Detection**: Auto-detect Linux or Windows systems

### Execution Tab

1. **Stats Dashboard**: Running audits, queued jobs, completion stats
2. **Server Selection**: Multi-select from available servers
3. **Audit Selection**: Choose audits or apply presets
4. **Real-Time Output**: Live execution output with progress tracking
5. **Queue Management**: View and manage pending executions

### Discovery Tab

1. **Stats Dashboard**: Discovered hosts, platforms detected
2. **Scan Options**: Network range, discovery methods
3. **Results Grid**: Discovered servers with detected OS types
4. **Import**: Add discovered servers to Connect tab
5. **Update Audits**: Refresh audit scripts from source

### Logs Tab

- **Stats Dashboard**: Total logs, recent logs count
- **Search & Filter**: Find logs by name, date, or content
- **Log Grid**: Card-based display with timestamps and size
- **View Content**: Click to view full log in modal with syntax highlighting
- **Download**: Export logs for external analysis

### History Tab

- **Stats Dashboard**: Total executions, pass/fail rates
- **Search & Filter**: Find by server, date, or audit name
- **Result Cards**: Show execution summary with status badges
- **Details View**: Click to see full audit output and findings

## Support Tools: Release Downloads + Endpoint Helpers

The Support Tools page separates release distribution from endpoint preparation:
- Full toolkit: open official external release sources (GitHub Releases and Customer Release Portal)
- Endpoint preparation: download platform-specific helper scripts and bundles

### Setup

1. Open the Deploy tab and use the **Support Tools** section to choose your release source.
2. Download the required JRE agent archive or helper scripts for your platform.
3. Roll out artifacts through your approved tooling (manual, Intune, SCCM, Ansible, RMM, CI/CD).

### Full Toolkit Downloads

Use Deployment Center package downloads when distributing the full toolkit:
- Linux/Windows full packages
- Linux distro formats (DEB/RPM)
- OVA/OVF artifacts when appliance builds are available

### Endpoint Helper Rollout Process

1. Select platform helper set (Windows or Linux).
2. Run precheck script on target hosts.
3. Apply setup/install scripts or all-in-one bundle.
4. Validate endpoint readiness and start agent/runtime per your operating model.

### Authentication Methods

**SSH Key (Recommended):**
```bash
# Generate key if needed
ssh-keygen -t rsa -b 4096

# Copy to remote server
ssh-copy-id user@remote-host
```

**Password:**
- Requires `sshpass` utility
- Less secure than SSH keys
- Use only for testing/development

## API Endpoints

The backend provides the following REST API:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/audits` | GET | List all available audits |
| `/api/presets` | GET | Get available presets |
| `/api/plans` | GET | List saved plans |
| `/api/plans/save` | POST | Save new plan |
| `/api/execute` | POST | Execute audits (selection/preset/plan) |
| `/api/status` | GET | Get execution status |
| `/api/logs` | GET | List log files |
| `/api/logs/<name>` | GET | Get log file content |
| `/api/servers` | GET | List configured servers |
| `/api/servers/add` | POST | Add new server |
| `/api/servers/remove/<id>` | DELETE | Remove server |
| `/api/servers/test/<id>` | POST | Test server connection |
| `/api/deploy` | POST | Execute remote deployment workflows |
| `/api/deploy/status` | GET | Get deployment status |

## Configuration

### Environment Variables

The web application supports the following environment variables for configuration:

#### Flask Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `FLASK_ENV` | `development` | Set to `production` for production deployments |
| `FLASK_SECRET_KEY` | Auto-generated | Secret key for session management (set manually for production) |
| `DB_FIELD_ENCRYPTION_KEY` | None | Required for production field-level encryption |
| `PRODUCTION_HARDENING_REQUIRED` | `true` in production | Enforce required security config at startup |
| `ALLOWED_ORIGINS` | `http://localhost:5000` | Comma-separated list of allowed CORS origins |
| `REQUIRE_STRICT_AUTH` | `false` | Require API key authentication for all connections (even localhost) |

#### Redis Configuration (NEW - v1.2.0+)

| Variable | Default | Description |
|----------|---------|-------------|
| `REDIS_ENABLED` | `false` | Enable Redis for distributed rate limiting |
| `REDIS_URL` | `redis://localhost:6379/1` | Redis connection URL |

**Example Configuration:**
```bash
# Development (single instance)
export FLASK_ENV=development
python3 app.py

# Production (single instance)
export FLASK_ENV=production
export FLASK_SECRET_KEY=$(openssl rand -hex 32)
export DB_FIELD_ENCRYPTION_KEY=$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')
export PRODUCTION_HARDENING_REQUIRED=true
export ALLOWED_ORIGINS="https://audit.example.com"
python3 app.py

# Production (multi-instance with Redis)
export FLASK_ENV=production
export FLASK_SECRET_KEY=$(openssl rand -hex 32)
export DB_FIELD_ENCRYPTION_KEY=$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')
export PRODUCTION_HARDENING_REQUIRED=true
export ALLOWED_ORIGINS="https://audit.example.com"
export REDIS_ENABLED=true
export REDIS_URL="redis://redis-server:6379/1"
python3 app.py
```

#### Why Redis?

**Without Redis (default):**
- ✅ Works great for single-instance deployments
- ✅ No external dependencies
- ❌ Rate limiting is per-process (doesn't work across multiple Flask instances)
- ❌ Rate limits reset on application restart

**With Redis:**
- ✅ Rate limits shared across all Flask instances (load balancer support)
- ✅ Rate limits persist across application restarts
- ✅ Ready for enterprise scale (100+ servers)
- ❌ Requires Redis server

### Change Port

Edit `app.py` and modify the last line:
```python
app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)
```

Change `port=5000` to your desired port.

### Change Host Binding

Default is `0.0.0.0` (all interfaces). For localhost only:
```python
app.run(host='127.0.0.1', port=5000, debug=True, threaded=True)
```

### Production Deployment (Native - Recommended)

For production without Docker, use a proper WSGI server:

**Using Gunicorn (Linux/macOS):**
```bash
pip install gunicorn
export REDIS_ENABLED=true
export REDIS_URL="redis://localhost:6379/1"
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

**Using Waitress (Windows/Cross-platform):**
```bash
pip install waitress
python -c "from waitress import serve; from app import app; serve(app, host='0.0.0.0', port=5000)"
```

### Docker Deployment (Optional - Development Convenience)

> **Note**: Docker is NOT required. The above native deployment is recommended for production.

The toolkit includes a `docker-compose.yml` file for easy development setup:

```bash
# Start all services (Flask + Redis)
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

**Benefits:**
- ✅ Quick development environment setup
- ✅ Redis automatically configured
- ✅ Persistent data with Docker volumes
- ✅ Health checks included

**Using Waitress (Windows):**
```bash
pip install waitress
set REDIS_ENABLED=true
set REDIS_URL=redis://localhost:6379/1
waitress-serve --host=0.0.0.0 --port=5000 app:app
```

## Security Considerations

### Development vs Production

**Development (Default Behavior):**
1. **Localhost Auto-Authentication**:
   - Accessing from `127.0.0.1` or `localhost` automatically authenticates
   - No manual API key entry required for local access
   - Convenient for development and testing
   - To disable: set environment variable `REQUIRE_STRICT_AUTH=true`

2. **API Key Generation**:
   - API key automatically generated on first run
   - Stored in `.api_key` file (chmod 0600)
   - Displayed in console when server starts
   - Save this key for remote access or API integration

**Production Deployment Best Practices:**

1. **Restrict Network Access**:
   ```python
   # Edit app.py - bind to localhost only
   app.run(host='127.0.0.1', port=5000, ...)
   ```
   - Prevents direct remote access
   - Use nginx/Apache reverse proxy with authentication
   - Enable firewall rules

2. **Enable Strict Authentication**:
   ```bash
   export REQUIRE_STRICT_AUTH=true  # Require API key for all connections
   ```
   - Authenticate programmatically via `/api/auth` endpoint:
     ```bash
     curl -X POST http://localhost:5000/api/auth \
       -H "Content-Type: application/json" \
       -d '{"api_key": "YOUR_API_KEY_FROM_CONSOLE"}'
     ```
   - Or include in all requests:
     ```bash
     curl -H "X-API-Key: YOUR_API_KEY" http://localhost:5000/api/audits
     ```

3. **Set Production Environment Variables**:
   ```bash
   export FLASK_ENV=production
   export FLASK_SECRET_KEY=$(openssl rand -hex 32)
   export ALLOWED_ORIGINS="https://yourdomain.com"
   export REQUIRE_STRICT_AUTH=true
   ```

4. **Use HTTPS with Reverse Proxy**:
   ```nginx
   # nginx example
   server {
       listen 443 ssl;
       server_name audit.yourdomain.com;

       ssl_certificate /path/to/cert.pem;
       ssl_certificate_key /path/to/key.pem;

       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           auth_basic "Audit Toolkit";
           auth_basic_user_file /etc/nginx/.htpasswd;
       }
   }
   ```

5. **Use Production WSGI Server**:
   - Use reverse proxy with TLS/SSL for production
   - Never expose over public internet without HTTPS

4. **Permissions**: Runs with current user permissions
   - Ensure proper file/directory permissions
   - Consider using dedicated service account

## Troubleshooting

### Port Already in Use
```bash
# Check what's using port 5000
netstat -ano | findstr :5000  # Windows
lsof -i :5000                 # Linux/macOS

# Change port in app.py or kill conflicting process
```

### Python Not Found
```bash
# Windows: Use 'python' instead of 'python3'
python --version

# Linux/macOS: Install Python 3
sudo apt install python3 python3-pip  # Debian/Ubuntu
brew install python3                  # macOS
```

### Bash Not Found (Windows)
- Install Git for Windows (includes Git Bash)
- Or use WSL (Windows Subsystem for Linux)
- Or use Cygwin

### Permission Denied
```bash
# Linux/macOS: Ensure scripts are executable
chmod +x orchestrator/orchestrator.sh

# Run with appropriate permissions
# Some audits may require sudo
```

## Development

### File Structure
```
web/
├── app.py              # Flask backend server
├── index.html          # Main UI
├── requirements.txt    # Python dependencies
├── README.md          # This file
└── static/
    ├── style.css      # UI styling
    └── script.js      # Frontend JavaScript
```

### Adding Features

1. **Backend**: Add routes in `app.py`
2. **Frontend**: Modify `index.html`, `script.js`, `style.css`
3. **API**: Follow existing patterns for consistency

### Testing Locally

```bash
# Preferred for host-native strict validation: run the stricter customer-confidence profile from the repo root
../tools/validation/run-strict-customer-confidence-validation.ps1 -SkipDocker

# Optional: run the compact reporting backfill smoke validation suite from the repo root
../tools/validation/validate-reporting-backfill-smoke-suite.ps1 -ResetAdmin

# Preferred: run the full reporting backfill smoke workflow from the repo root
../tools/run-reporting-backfill-smoke.ps1 -ResetAdmin

# Optional: validate the wrapper's documented non-zero path from the repo root
../tools/validation/validate-reporting-backfill-smoke-wrapper.ps1

# Manual alternative: start the local web server from the web/ directory
python serve.py

# Then run the reporting backfill browser smoke test from the repo root
../.venv/Scripts/python.exe ../tools/smoke-reporting-backfill-playwright.py --reset-admin
```

Notes:
- `../tools/validation/run-strict-customer-confidence-validation.ps1` is a named wrapper for the stricter validation profile and automatically includes the reporting backfill smoke suite.
- `../tools/validation/validate-reporting-backfill-smoke-suite.ps1` runs the positive smoke wrapper path and the wrapper negative-path check as a compact two-step validation.
- For broader host-native validation, `../tools/validation/run-validation.ps1 -SkipDocker -IncludeReportingBackfillSmoke` adds the reporting backfill smoke suite to the standard validation runner.
- `../tools/validation/run-validation.ps1 -StrictCustomerConfidence` also enables the reporting backfill smoke suite automatically as part of the stricter validation profile.
- `../tools/run-reporting-backfill-smoke.ps1` starts `serve.py` when needed, runs the Playwright smoke test, exits non-zero if startup or smoke validation fails, and only stops the temporary server process that it started itself.
- `../tools/validation/validate-reporting-backfill-smoke-wrapper.ps1` is a lightweight negative-path check that confirms the wrapper fails cleanly when given an invalid smoke script path.
- If a server is already running at the requested base URL, the wrapper reuses it and leaves that existing server running.
- The smoke test logs in through `/auth/login`, accepts the first-login disclaimer when needed, opens `/console`, switches to the `Reports` tab inside the embedded management iframe, seeds deterministic success and failure backfill-history entries, validates rendered history cards, clears the seeded rows to verify the empty-state surface, forces one history-load failure to verify the `History Unavailable` state, and then checks the filter, refresh, and cancelled-run flow.
- Use `--headful` on the smoke script when you want a visible browser for debugging.
- For live validation on Windows from the repository root, the equivalent startup command is `Set-Location .\web; ..\.venv\Scripts\python.exe serve.py`.

## License

Same as parent project - see LICENSE file in repository root.

## Support

For issues or questions:
1. Check existing issues on GitHub
2. Review parent project documentation
3. Create new issue with details

## Related Documentation

- [Orchestrator README](../orchestrator/README.md)
- [Developer Guide](../docs/03-developer-guide.md)
- [API Reference](../docs/06-library-api-reference.md)
