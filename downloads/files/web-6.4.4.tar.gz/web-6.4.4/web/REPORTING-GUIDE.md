# Audit Reporting Guide

## Overview

The Security Audit Toolkit's reporting system provides comprehensive HTML-based reports that aggregate audit results from multiple remote servers. Reports include detailed metrics, compliance scoring, and export capabilities.

## Report Types

### Evidence Packages and Companion Outputs
Evidence Packages sit alongside the standard report exports when audit evidence needs to be retained or handed to assessors. They are designed for auditor-facing collections rather than narrative presentation alone.

**Evidence Packages can include:**
- Audit outputs from completed executions
- Configuration snapshots and exported settings
- Screenshots, logs, and supporting files
- Policy documents and signed attestations
- API responses and Windows registry exports
- Framework-organised ZIP bundles with manifest and SHA-256 integrity data

**Use alongside:**
- Executive summaries for stakeholder narrative
- Compliance scorecards for framework posture
- JSON exports for integrations and downstream processing
- SARIF exports for pipeline and code-scanning workflows where enabled

### 1. Summary Report
Quick overview of audit status across selected servers.

**Contains:**
- Overall compliance percentage
- Total checks performed
- Pass/Warn/Fail/Skip counts (aggregated)
- Per-server status and metrics
- Error indicators for failed servers

**Best for:** Executive overview, quick compliance check, comparison across servers

### 2. Detailed Report
Extended report with log previews and additional context.

**Contains:**
- All summary information
- Log file preview (first 2000 characters per server)
- Detailed check results
- Audit timestamps

**Best for:** In-depth analysis, troubleshooting, documentation

### 3. Comparison Report
Side-by-side server comparison with performance metrics.

**Contains:**
- All summary and detailed information
- Compliance percentage comparison
- Failure count comparison
- Server rankings by compliance

**Best for:** Multi-server analysis, identifying weak points, trend analysis

## Standard Report Example

Below is an example of what a typical HTML report looks like when generated for 3 servers.

```
═══════════════════════════════════════════════════════════════
           Security Audit Toolkit - Audit Report
═══════════════════════════════════════════════════════════════

Generated: February 4, 2026 at 2:45 PM

┌─────────────────────────────────────────────────────────────┐
│                    COMPLIANCE SUMMARY                        │
├─────────────────────────────────────────────────────────────┤
│  Overall Compliance Rate: 87.5%                              │
│  Total Checks: 480                                           │
│  ✓ Passed: 420        ⚠ Warnings: 35                         │
│  ✗ Failed: 15         ⊘ Skipped: 10                          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                  SERVER DETAILS                              │
├─────────────────────────────────────────────────────────────┤

  🖥️  SERVER 1: production-web-01
      Host: 192.168.1.100
      Status: ✓ SUCCESS
      
      Metrics:
      ├─ Total Checks:     160
      ├─ Passed:           148 (92.5%)
      ├─ Warnings:          8
      ├─ Failed:            2
      ├─ Skipped:           2
      └─ Compliance:       92.5%
      
      Log File: orchestrator-summary-20260204-143052.log

  ─────────────────────────────────────────────────────────────

  🖥️  SERVER 2: production-web-02
      Host: 192.168.1.101
      Status: ✓ SUCCESS
      
      Metrics:
      ├─ Total Checks:     160
      ├─ Passed:           152 (95.0%)
      ├─ Warnings:          5
      ├─ Failed:            1
      ├─ Skipped:           2
      └─ Compliance:       95.0%
      
      Log File: orchestrator-summary-20260204-142018.log

  ─────────────────────────────────────────────────────────────

  🖥️  SERVER 3: production-api-01
      Host: 192.168.1.102
      Status: ✓ SUCCESS
      
      Metrics:
      ├─ Total Checks:     160
      ├─ Passed:           120 (75.0%)
      ├─ Warnings:         22
      ├─ Failed:           12
      ├─ Skipped:           6
      └─ Compliance:       75.0%
      
      Log File: orchestrator-summary-20260203-095611.log

└─────────────────────────────────────────────────────────────┘

Report generated on February 4, 2026 2:45 PM by Security Audit Toolkit
```

## Metrics Explained

### Compliance Percentage
```
Compliance % = (Passed Checks / Total Checks) × 100
```

**Example:**
```
Production-web-01: 148 passed / 160 total = 92.5% compliance
Production-api-01: 120 passed / 160 total = 75.0% compliance
```

### Check Status Breakdown

| Status | Symbol | Color | Meaning |
|--------|--------|-------|---------|
| Passed | ✓ | Green | Check passed successfully |
| Warning | ⚠ | Yellow | Check passed with warnings |
| Failed | ✗ | Red | Check failed |
| Skipped | ⊘ | Gray | Check was skipped (N/A or disabled) |

### Overall Compliance
Aggregate compliance across all servers:
```
Overall % = (Total Passed / Total Checks) × 100
```

## Export Formats

### HTML Export

The generated HTML report includes:
- Full styling and colors
- Professional layout
- Print-friendly design
- All metrics and data
- Navigation and structure

**File naming:** `audit-report-20260204-134523.html`

**Use cases:**
- Sharing via email
- Publishing to intranet
- Archiving reports
- Printing to PDF

**Example structure:**
```html
<!DOCTYPE html>
<html>
<head>
    <title>Security Audit Toolkit - Audit Report</title>
    <style>
        /* Professional styling included */
    </style>
</head>
<body>
    <div class="report">
        <h1>Security Audit Toolkit</h1>
        <p>Generated: February 4, 2026</p>
        
        <div class="report-summary">
            <div class="stat compliance">Compliance: 87.5%</div>
            <div class="stat pass">Passed: 420</div>
            <div class="stat warn">Warnings: 35</div>
            <div class="stat fail">Failed: 15</div>
        </div>
        
        <!-- Server details ... -->
    </div>
</body>
</html>
```

### CSV Export

Simple tabular format for spreadsheet analysis.

**File naming:** `audit-report-20260204-134523.csv`

**Column headers:**
```
Server,Host,Status,Total,Pass,Warn,Fail,Skip,Pass%
```

**Example content:**
```csv
Server,Host,Status,Total,Pass,Warn,Fail,Skip,Pass%
production-web-01,192.168.1.100,success,160,148,8,2,2,92.5
production-web-02,192.168.1.101,success,160,152,5,1,2,95.0
production-api-01,192.168.1.102,success,160,120,22,12,6,75.0
```

**Use cases:**
- Data analysis in Excel/Sheets
- Importing to databases
- Trend tracking
- Comparative analysis
- Building charts/graphs

### JSON Export

Structured data format for programmatic processing.

**File naming:** `audit-report-20260204-134523.json`

**Example structure:**
```json
{
1. **Report Types**: Choose from HTML Summary, PDF, JSON, Executive Summary, or Compliance Report
2. **Evidence Packages**: Build auditor-ready ZIP bundles with manifests, SHA-256 integrity data, and collected artefacts such as configs, logs, screenshots, attestations, API responses, and registry exports
  "generated": "2026-02-04T14:45:23.123456",
  "report_type": "summary",
  "summary": {
3. **Server Selection**: Grid-based multi-select with status indicators
4. **Generate**: Click to create report with selected options
5. **Output Panel**: Preview and download generated reports
    "total_servers": 3,
    "total_checks": 480,
    "total_pass": 420,
    "total_warn": 35,
    "total_fail": 15,
    "total_skip": 10,
    "compliance_percentage": 87.5
  },
  "servers": [
    {
      "name": "production-web-01",
      "host": "192.168.1.100",
      "status": "success",
      "log_file": "orchestrator-summary-20260204-143052.log",
      "metrics": {
        "total": 160,
        "pass": 148,
        "warn": 8,
        "fail": 2,
        "skip": 2
      },
      "pass_percentage": 92.5
    },
    // ... more servers
  ]
}
```

**Use cases:**
- API integration
- Custom processing
- Data migration
- Webhook delivery
- Automation workflows

## Report Interpretation Guide

### What does 92.5% compliance mean?

**Definition:** Out of all security checks performed, 92.5% were successful.

**Interpretation:**
- ✓ **92.5% of checks passed** - Strong security posture
- ⚠ **5% had warnings** - Minor issues that need attention
- ✗ **2.5% failed** - Security issues requiring immediate action

**Action Items:**
1. Address failed checks immediately
2. Investigate warnings within 7 days
3. Plan maintenance for non-critical issues
4. Document any exceptions or known issues

### Comparing Server Compliance

**Scenario:** You have 3 servers with different compliance rates
- Server A: 92.5%
- Server B: 95.0%
- Server C: 75.0%

**Analysis:**
1. **Server A & B:** Good compliance, minor differences
2. **Server C:** Significantly lower compliance
   - Requires investigation
   - May have different configuration
   - Could indicate unpatched system
   - Needs remediation plan

**Recommended Actions:**
1. Investigate why Server C differs
2. Apply Server B's configuration to Server C
3. Escalate if Server C is critical
4. Set compliance threshold (e.g., 85%)

### Reading Failure Patterns

**Pattern 1: High warnings, low failures**
```
Warnings: 22 (13.75%)
Failed: 1 (0.625%)
```
→ System is mostly compliant with minor issues

**Pattern 2: Low warnings, high failures**
```
Warnings: 2 (1.25%)
Failed: 12 (7.5%)
```
→ Critical issues present, needs immediate attention

**Pattern 3: Balanced distribution**
```
Passed: 140 (87.5%)
Warnings: 15 (9.375%)
Failed: 5 (3.125%)
```
→ Typical production system, continuous improvement needed

## Common Report Scenarios

### Scenario 1: New Deployment Baseline

**Report Characteristics:**
- Compliance: 65-75%
- Multiple failed checks
- Known issues documented
- Baseline for improvement

**Action Plan:**
```
Week 1:  Address critical failures (P0)
Week 2:  Fix important issues (P1)
Week 3:  Handle warnings (P2)
Week 4:  Document and verify
Target:  85% compliance
```

### Scenario 2: Post-Patch Report

**Report Characteristics:**
- Compliance increase from previous report
- Specific checks now passing
- New warnings may appear (temporary)
- Overall trend improving

**Verification:**
```
Before patch:  80% compliance
After patch:   88% compliance
Improvement:   +8% (10 additional checks passing)
```

### Scenario 3: Production Baseline

**Report Characteristics:**
- Compliance: 90%+
- Mostly passed checks
- Minimal failures
- Few warnings
- Stable metrics

**Maintenance:**
```
Monthly reviews to maintain compliance
Quarterly trend analysis
Annual security assessment
Alert on compliance drops below 85%
```

### Scenario 4: Compliance Failure

**Report Characteristics:**
- Compliance: <70%
- Multiple critical failures
- High failure count
- System at risk

**Immediate Actions:**
```
1. ALERT: Escalate to management
2. INVESTIGATE: Root cause analysis
3. REMEDIATE: Fix critical issues
4. VERIFY: Re-run audit
5. DOCUMENT: Incident report
6. PREVENT: Add preventive checks
```

## Best Practices

### 1. Report Frequency

```
Development:  Weekly (during active development)
Staging:      Bi-weekly (before releases)
Production:   Daily (automated)
Post-Incident: Immediately
```

### 2. Trend Tracking

```
Track these metrics over time:
├─ Compliance percentage trend
├─ Failure count trend
├─ Warning count trend
├─ Check pass rate trend
└─ Server-by-server comparison
```

### 3. Alerting Thresholds

```
CRITICAL (Alert immediately):
  └─ Compliance drops below 75%
  └─ Critical check fails on production
  └─ Failed checks exceed 5% of total

WARNING (Investigate within 24h):
  └─ Compliance drops below 85%
  └─ Warnings exceed 10% of total
  └─ Server variance > 10%

INFO (Review periodically):
  └─ Skipped checks appear
  └─ Minor variations detected
  └─ Expected changes occur
```

### 4. Report Archive

```
Maintain reports in this structure:
reports/
├── 2026-02/
│   ├── 2026-02-01-summary.html
│   ├── 2026-02-02-summary.html
│   └── 2026-02-04-detailed.html
├── 2026-03/
└── archive/
    └── 2025-*/ (old reports)

Retention: Keep 1 year minimum
Archive: Move reports >3 months to archive/
```

### 5. Stakeholder Communication

**For Executives:**
- Show compliance percentage only
- Highlight trends
- Indicate risk level
- Suggest next steps

**For Security Team:**
- Show detailed failures
- Include log previews
- Provide remediation guide
- List failed check names

**For Operations:**
- Show per-server details
- Include host information
- Provide specific failure details
- Suggest fixes

## Sample Report: Full Example

### Title Page
```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│     SECURITY AUDIT REPORT                               │
│     Production Environment                              │
│                                                         │
│     Generated: February 4, 2026 2:45 PM                │
│     Report Type: Summary                                │
│     Scope: 3 Production Servers                         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Executive Summary
```
OVERALL COMPLIANCE: 87.5% ✓
│
├─ TOTAL AUDITS RUN:     480 checks
├─ PASSED:               420 checks (87.5%)
├─ WARNINGS:              35 checks (7.3%)
├─ FAILED:                15 checks (3.1%)
├─ SKIPPED:               10 checks (2.1%)
│
└─ RECOMMENDATION: GOOD STANDING
   (Target: ≥85%, Current: 87.5%, Delta: +2.5%)
```

### Server Breakdown

**Server 1: production-web-01**
```
Compliance: 92.5% ✓ EXCELLENT
├─ Total Checks: 160
├─ Passed: 148
├─ Warnings: 8 (firewall rules)
├─ Failed: 2 (SSL certificate expiry warning)
└─ Status: PRODUCTION READY
```

**Server 2: production-web-02**
```
Compliance: 95.0% ✓ EXCELLENT
├─ Total Checks: 160
├─ Passed: 152
├─ Warnings: 5 (log rotation)
├─ Failed: 1 (missing backup verification)
└─ Status: PRODUCTION READY
```

**Server 3: production-api-01**
```
Compliance: 75.0% ⚠ ACCEPTABLE (NEEDS ATTENTION)
├─ Total Checks: 160
├─ Passed: 120
├─ Warnings: 22 (permission issues)
├─ Failed: 12 (service vulnerabilities)
└─ Status: REQUIRES REMEDIATION
```

### Recommendations

```
PRIORITY: CRITICAL
│
├─ Investigate production-api-01 failures
│  └─ 12 failed checks need remediation
│
├─ Address SSL certificate expiry on web-01
│  └─ Expires in 30 days
│
└─ Plan maintenance for log rotation on web-02
   └─ Implement within 7 days

TIMELINE:
├─ Days 1-2: Critical issues (12 failures on api-01)
├─ Days 3-5: High priority (certificate renewal)
├─ Days 6-7: Medium priority (warnings)
└─ Verify: Re-run audit after remediation
```

## Exporting and Sharing

### Export HTML Report

```
1. Click "Export HTML" button
2. Browser downloads: audit-report-20260204-134523.html
3. Open in any browser or send via email
4. Print to PDF if needed
```

### Export CSV for Analysis

```
1. Click "Export CSV" button
2. Browser downloads: audit-report-20260204-134523.csv
3. Import to Excel or Google Sheets
4. Create pivot tables, charts, trends
```

### Export JSON for Integration

```
1. Click "Export JSON" button
2. Browser downloads: audit-report-20260204-134523.json
3. Parse programmatically
4. Integrate with SIEM, ticketing, or dashboard systems
```

## Troubleshooting

### Report Generation Fails

**Problem:** "Failed to fetch logs from server"

**Solution:**
1. Verify SSH connectivity: Use Deploy tab's "Test" button
2. Check remote path exists: SSH to server, verify logs directory
3. Ensure server has been deployed: Use Deploy tab first
4. Check server authentication: Verify SSH key or password

### Missing Metrics

**Problem:** Some servers show no metrics

**Solution:**
1. Ensure audits ran on remote server
2. Check if logs exist on remote: SSH and look in `logs/` directory
3. Verify log file format: Ensure audit script output in expected format
4. Check file permissions: Logs must be readable by SSH user

### Export Not Working

**Problem:** Export button doesn't download file

**Solution:**
1. Check browser console for errors (F12 → Console)
2. Verify pop-ups aren't blocked: Allow pop-ups for this site
3. Try different export format (HTML → CSV)
4. Clear browser cache and try again
5. Check disk space for downloaded file

## Additional Resources

- [Audit Authoring Guide](../docs/04-audit-authoring.md)
- [Orchestrator README](../orchestrator/README.md)
- [Developer Guide](../docs/03-developer-guide.md)
- [Web Interface Documentation](README.md)
