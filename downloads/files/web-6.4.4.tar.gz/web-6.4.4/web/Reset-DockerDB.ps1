<#
.SYNOPSIS
    DOCKER-ONLY (optional): Reset Docker containers with fresh database

.DESCRIPTION
    Fixes PostgreSQL password authentication issue by:
    1. Stopping all containers
    2. Removing the postgres volume (fresh database)
    3. Rebuilding and starting containers

.EXAMPLE
    .\Reset-DockerDB.ps1
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification='Intentional colorized output for interactive terminal reporting')]
[CmdletBinding()]
param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# Navigate to repo root
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location (Join-Path $ScriptDir "..")

Write-Output ""
Write-Output "======================================="
Write-Output " Docker Database Reset"
Write-Output "======================================="
Write-Output ""
Write-Output "This will:"
Write-Output "  1. Stop all containers"
Write-Output "  2. Remove PostgreSQL volume (DATA WILL BE LOST)"
Write-Output "  3. Rebuild and start containers"
Write-Output ""

# Check if .env exists
if (-not (Test-Path ".env")) {
    Write-Output "[ERROR] .env file not found!"
    Write-Output "  Copy .env.example to .env and set passwords first:"
    Write-Output "    Copy-Item .env.example .env"
    exit 1
}

# Verify required env vars
$envContent = Get-Content ".env" -Raw
if ($envContent -notmatch "POSTGRES_PASSWORD=.+") {
    Write-Output "[ERROR] POSTGRES_PASSWORD not set in .env"
    exit 1
}
if ($envContent -notmatch "REDIS_PASSWORD=.+") {
    Write-Output "[ERROR] REDIS_PASSWORD not set in .env"
    exit 1
}
if ($envContent -notmatch "FLASK_SECRET_KEY=.+") {
    Write-Output "[ERROR] FLASK_SECRET_KEY not set in .env"
    exit 1
}

Write-Output "[INFO] Environment variables verified"
Write-Output ""

# Confirm
if (-not $Force) {
    $response = Read-Host "Continue with database reset? This will DELETE all data. [y/N]"
    if ($response -notin @("y", "Y", "yes", "Yes")) {
        Write-Output "Aborted."
        exit 0
    }
}

Write-Output ""
Write-Output "[STEP 1/4] Stopping containers..."
docker-compose down --remove-orphans 2>$null
if ($LASTEXITCODE -ne 0) { Write-Host "  No containers running" -ForegroundColor Gray }

Write-Output ""
Write-Output "[STEP 2/4] Removing PostgreSQL volume..."
docker volume rm audit-tool-_postgres-data 2>$null
if ($LASTEXITCODE -ne 0) {
    docker volume rm audit-tool_postgres-data 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Output "  No existing volume to remove"
    }
}

Write-Output ""
Write-Output "[STEP 3/4] Rebuilding containers..."
docker-compose build --no-cache web celery-worker 2>$null
if ($LASTEXITCODE -ne 0) {
    docker-compose build web
}

Write-Output ""
Write-Output "[STEP 4/4] Starting containers..."
docker-compose up -d

Write-Output ""
Write-Output "======================================="
Write-Output " Waiting for services to start..."
Write-Output "======================================="
Start-Sleep -Seconds 5

# Check status
Write-Output ""
docker-compose ps

Write-Output ""
Write-Output "======================================="
Write-Output " Checking logs for errors..."
Write-Output "======================================="

Write-Output ""
Write-Output "--- PostgreSQL ---"
docker-compose logs --tail=10 postgres 2>$null | Select-String -Pattern "ready|listening|error|failed"

Write-Output ""
Write-Output "--- Web App ---"
docker-compose logs --tail=10 web 2>$null | Select-String -Pattern "Running|error|Traceback"

Write-Output ""
Write-Output "======================================="
Write-Output " Reset Complete"
Write-Output "======================================="
Write-Output ""
Write-Output "Web interface: http://localhost:5000"
Write-Output ""
Write-Output "If issues persist, check full logs:"
Write-Output "  docker-compose logs -f"
Write-Output ""

