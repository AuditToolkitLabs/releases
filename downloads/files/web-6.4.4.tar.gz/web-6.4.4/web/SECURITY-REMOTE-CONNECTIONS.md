# Remote Server Connection Security Documentation

## Overview

This document details the security mechanisms, transport layers, and access control methods used when the Security Audit Toolkit's web management interface connects to remote servers for deployment, audit execution, and log retrieval.

## Table of Contents

1. [Transport Layer Security](#transport-layer-security)
2. [Authentication Methods](#authentication-methods)
3. [SSH Configuration](#ssh-configuration)
4. [Current Implementation Status](#current-implementation-status)
5. [Security Issues & Recommendations](#security-issues--recommendations)
6. [Best Practices for Production](#best-practices-for-production)
7. [Configuration Examples](#configuration-examples)

---

## Transport Layer Security

### SSH (Secure Shell)

**Primary Transport Protocol: SSH**

All remote server connections use SSH as the transport layer. SSH provides:

- **Encryption**: Data in-flight encryption using modern ciphers
- **Authentication**: Public key or password-based authentication
- **Integrity**: HMAC-based message authentication
- **Non-repudiation**: Cryptographic verification of commands

**SSH Default Ports:**
- Standard: Port 22
- Custom: Configurable per server (recommended for hardened environments)

**Supported Versions:**
- SSHv2 (required)
- SSHv1 (deprecated, not used)

### Protocol Stack

```
┌─────────────────────────────────────────┐
│   Application Layer (Flask API)         │
│   - Audit execution                     │
│   - File deployment                     │
│   - Log retrieval                       │
└──────────────┬──────────────────────────┘
               │
┌──────────────v──────────────────────────┐
│   SSH Client (subprocess.run + sshpass) │
│   - Command execution                   │
│   - File transfer (SCP)                 │
│   - Authentication                      │
└──────────────┬──────────────────────────┘
               │
┌──────────────v──────────────────────────┐
│   SSH Protocol Layer (TLS/Encrypted)    │
│   - AES-128-CTR/AES-256-CTR encryption  │
│   - SHA-256 integrity                   │
│   - Diffie-Hellman key exchange         │
└──────────────┬──────────────────────────┘
               │
┌──────────────v──────────────────────────┐
│   TCP/IP Transport (Port 22)            │
│   - Network layer                       │
│   - Routable over any network           │
└─────────────────────────────────────────┘
```

---

## Authentication Methods

### Method 1: SSH Public Key Authentication (Recommended)

**Security Level:** ⭐⭐⭐⭐⭐ HIGHEST

**Mechanism:**
```
1. Client generates RSA/ED25519 keypair locally
2. Public key stored on remote server (~/.ssh/authorized_keys)
3. Client connects with private key
4. Server verifies signature using public key
5. No password transmitted over network
```

**Configuration in Toolkit:**
```python
# From web/app.py
if server["auth_type"] == "public_key":
    key_arg = f"-i {server['key_path']}" if server['key_path'] else ""
    ssh_base = f"ssh -o StrictHostKeyChecking=no {key_arg} {server['user']}@{server['host']} -p {server['port']}"
```

**Key Features:**
- ✅ No passwords stored in application
- ✅ Private key stays on management machine
- ✅ Supports key passphrases for additional protection
- ✅ Immune to password sniffing
- ✅ Supports ED25519 (stronger than RSA)

**Setup Example:**
```bash
# On management machine (where toolkit runs)
ssh-keygen -t ed25519 -f ~/.ssh/audit-toolkit -N "passphrase"

# Copy public key to remote server
ssh-copy-id -i ~/.ssh/audit-toolkit.pub user@remote-server

# Configure toolkit with private key path
# In server config: "key_path": "/home/admin/.ssh/audit-toolkit"
```

### Method 2: Password Authentication

**Security Level:** ⭐⭐⭐ MEDIUM (with TLS mitigation)

**Mechanism:**
```
1. User provides password for server
2. sshpass utility sends password to SSH
3. SSH protocol (encrypted tunnel) transmits password
4. Server validates against /etc/shadow
```

**Configuration in Toolkit:**
```python
# From web/app.py
if server["auth_type"] == "password":
    cmd = f"sshpass -p '{server['password']}' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 {server['user']}@{server['host']} -p {server['port']} 'echo Connected'"
```

**Security Properties:**
- ✅ Password encrypted in SSH tunnel
- ✅ Works with any SSH server
- ⚠️ Passwords must be stored securely (see below)
- ⚠️ Vulnerable if management machine is compromised
- ⚠️ No protection against brute force (SSH rate limiting required)

**Storage Security:**
```
Passwords stored in: {ROOT_DIR}/servers/servers.json
Protection mechanism: File permissions (600 - owner read/write only)
Encryption: None (ISSUE - see recommendations)
Access control: Root/admin only
```

**Secure Password Management:**
```json
{
  "servers": [
    {
      "id": 1,
      "name": "production-web-01",
      "host": "192.168.1.100",
      "port": 22,
      "user": "deployer",
      "auth_type": "password",
      "password": "ENCRYPTED_VALUE_HERE",  // Currently stored in plaintext - ISSUE
      "remote_path": "/opt/audit-toolkit"
    }
  ]
}
```

---

## SSH Configuration

### SSH Client Options Used

The toolkit uses these SSH options for all connections:

```bash
ssh -o StrictHostKeyChecking=no \
    -o ConnectTimeout=10 \
    -p {port} \
    {auth_options} \
    user@host
```

**Option Breakdown:**

| Option | Value | Meaning | Security Impact |
|--------|-------|---------|-----------------|
| `StrictHostKeyChecking` | no | Skip host key verification | ⚠️ ISSUE - Man-in-the-middle vulnerability |
| `ConnectTimeout` | 10 | 10-second connection timeout | ✅ Prevents hanging connections |
| `-p {port}` | 22 (default) | Custom SSH port | ✅ Defense in depth |
| `User` | Configurable | SSH user account | ✅ Principle of least privilege |

### **CRITICAL SECURITY ISSUE: StrictHostKeyChecking=no**

**Problem:**
```
-o StrictHostKeyChecking=no disables host key verification
This allows MITM (Man-in-the-Middle) attacks
```

**Attack Scenario:**
```
Attacker on network:
1. ARP spoofs toolkit server's gateway
2. Intercepts SSH connection
3. SSH connects without verifying remote host key
4. Attacker gains access to credentials, commands, audit results
5. Attacker can inject malicious commands on remote servers
```

**Current Risk Level:** 🔴 HIGH

**Impact:**
- Credentials (passwords, keys) potentially exposed
- Audit data integrity compromised
- Remote servers could be compromised
- Compliance violation (audit trail unreliable)

**Recommended Fix:**
```bash
# BEFORE (INSECURE)
ssh -o StrictHostKeyChecking=no user@host

# AFTER (SECURE)
ssh -o StrictHostKeyChecking=accept-new \
    -o UserKnownHostsFile=/opt/audit-toolkit/.ssh/known_hosts \
    user@host
```

See [Security Issues & Recommendations](#security-issues--recommendations) for full fix.

---

## Current Implementation Status

### Web Application (web/app.py)

**File:** `web/app.py`

**Remote Connection Points:**

#### 1. SSH Test Connection
```python
# Lines 377-410
@app.route('/api/deploy/test', methods=['POST'])
def test_ssh_connection(server_id):
    """Test SSH connection to server"""
    # Uses: ssh with StrictHostKeyChecking=no
    # Protocol: SSH
    # Credentials: Password (sshpass) or Key file
    # Timeout: 15 seconds
```

**Executed Command:**
```bash
sshpass -p 'password' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 user@host -p 22 'echo Connected'
```

#### 2. Deployment (Files to Remote Server)
```python
# Lines 470-530
@app.route('/api/deploy', methods=['POST'])
def deploy_to_servers():
    """Deploy toolkit to selected servers"""
    # Uses: SSH for commands + SCP for file transfer
    # Protocol: SSH (encrypted)
    # Operations: mkdir, scp, tar, chmod
    # Timeout: 30-120 seconds per operation
```

**Executed Commands:**
```bash
# SSH command for directory creation
ssh -o StrictHostKeyChecking=no user@host 'mkdir -p /opt/audit-toolkit'

# SCP command for file transfer
scp -o StrictHostKeyChecking=no -P 22 toolkit.tar.gz user@host:/opt/audit-toolkit/

# SSH command for extraction
ssh -o StrictHostKeyChecking=no user@host 'cd /opt/audit-toolkit && tar -xzf toolkit.tar.gz'

# SSH command for permissions
ssh -o StrictHostKeyChecking=no user@host 'find . -name "*.sh" -exec chmod +x {} +'
```

#### 3. Log Retrieval (Remote Audit Reports)
```python
# Lines 600-650
@app.route('/api/reports/fetch/<int:server_id>')
def fetch_remote_logs(server_id):
    """Fetch audit logs from a remote server"""
    # Uses: SSH for command execution
    # Protocol: SSH (encrypted)
    # Operations: find, grep, tail
    # Timeout: 30 seconds
```

**Executed Commands:**
```bash
# Find and list latest log files
ssh -o StrictHostKeyChecking=no user@host 'find /opt/audit-toolkit/logs -name "*.log" -type f -printf "%T@ %p\n" | sort -rn | head -20'

# Fetch last 50KB of each log
ssh -o StrictHostKeyChecking=no user@host 'tail -c 50000 /path/to/logfile.log'
```

### Transport Layer Summary

| Function | Transport | Encryption | Auth | Secure? |
|----------|-----------|-----------|------|---------|
| Test Connection | SSH (Port 22) | AES-256 | Key/Pass | ⚠️ MITM Risk |
| File Deployment | SCP/SSH | AES-256 | Key/Pass | ⚠️ MITM Risk |
| Audit Execution | SSH (Port 22) | AES-256 | Key/Pass | ⚠️ MITM Risk |
| Log Retrieval | SSH (Port 22) | AES-256 | Key/Pass | ⚠️ MITM Risk |

---

## Security Issues & Recommendations

### ISSUE 1: Disabled Host Key Verification (CRITICAL)

**Severity:** 🔴 CRITICAL

**Current Code:**
```python
# Lines 387, 475, 479, 612, 615
ssh -o StrictHostKeyChecking=no ...
```

**Problem:**
- No verification that remote host is who it claims to be
- Enables Man-in-the-Middle attacks
- Attacker could intercept passwords, keys, audit data
- Violates security best practices (CIS, NIST)

**Fix Implementation:**

**Step 1: Create known_hosts management function**
```python
def initialize_known_hosts():
    """Initialize and manage SSH known_hosts file"""
    known_hosts_dir = ROOT_DIR / ".ssh"
    known_hosts_dir.mkdir(exist_ok=True, mode=0o700)
    
    known_hosts_path = known_hosts_dir / "known_hosts"
    if not known_hosts_path.exists():
        known_hosts_path.touch(mode=0o600)
    
    return known_hosts_path

def add_to_known_hosts(host, port, key_data):
    """Add host key to known_hosts file"""
    known_hosts_path = initialize_known_hosts()
    
    # Format: [host]:port ssh-rsa AAAAB3...
    entry = f"[{host}]:{port} {key_data}"
    
    with open(known_hosts_path, 'a') as f:
        f.write(entry + '\n')

def scan_ssh_key(host, port=22):
    """Scan and retrieve SSH host key"""
    try:
        result = subprocess.run(
            [
                'ssh-keyscan',
                '-p', str(port),
                '-t', 'rsa,ed25519',
                host
            ],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.stdout
    except subprocess.TimeoutExpired:
        return None
```

**Step 2: Update SSH connection code**
```python
# BEFORE (INSECURE)
cmd = f"ssh -o StrictHostKeyChecking=no user@host 'echo Connected'"

# AFTER (SECURE)
cmd = f"ssh -o StrictHostKeyChecking=accept-new \
             -o UserKnownHostsFile={known_hosts_path} \
             -o HashKnownHosts=no \
             user@host 'echo Connected'"
```

**Step 3: Scan hosts on server addition**
```python
@app.route('/api/servers', methods=['POST'])
def add_server():
    """Add new server and scan SSH key"""
    # ... existing code ...
    
    # Scan and add SSH key
    key_data = scan_ssh_key(server['host'], server['port'])
    if key_data:
        add_to_known_hosts(server['host'], server['port'], key_data)
    else:
        return jsonify({
            "success": False,
            "error": "Could not scan SSH key from host"
        }), 400
```

**Testing:**
```bash
# After fix, StrictHostKeyChecking=accept-new will:
# 1. Accept unknown hosts on first connection (with user permission)
# 2. Reject MITM attempts if key changes
# 3. Provide stronger security than =no, weaker than =yes (for automation)

# Test:
curl -X POST http://localhost:5000/api/servers \
  -H "Content-Type: application/json" \
  -d '{
    "name": "prod-web-01",
    "host": "192.168.1.100",
    "port": 22,
    "user": "deployer",
    "auth_type": "public_key",
    "key_path": "/home/admin/.ssh/id_ed25519"
  }'
```

---

### ISSUE 2: Password Storage in Plaintext (HIGH)

**Severity:** 🟠 HIGH

**Current Code:**
```json
{
  "password": "MySecurePassword123"  // Plaintext in servers.json
}
```

**Problem:**
- If servers.json is stolen, all passwords are compromised
- No encryption of sensitive data at rest
- Violates principle of defense in depth
- Compliance violation (PCI-DSS, NIST, SOC 2)

**Fix Implementation:**

**Step 1: Add encryption library**
```bash
pip install cryptography
```

**Step 2: Create encryption module (web/crypto.py)**
```python
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2
from pathlib import Path
import os
import base64

class ServerPasswordManager:
    def __init__(self, key_file=None):
        self.key_file = key_file or Path("/opt/audit-toolkit/.crypto/key.bin")
        self.key_file.parent.mkdir(exist_ok=True, mode=0o700)
        self.cipher = self._load_or_create_key()
    
    def _load_or_create_key(self):
        """Load existing key or create new one"""
        if self.key_file.exists():
            with open(self.key_file, 'rb') as f:
                key = f.read()
        else:
            key = Fernet.generate_key()
            self.key_file.write_bytes(key)
            self.key_file.chmod(0o600)
        
        return Fernet(key)
    
    def encrypt_password(self, password):
        """Encrypt password for storage"""
        if isinstance(password, str):
            password = password.encode()
        return self.cipher.encrypt(password).decode()
    
    def decrypt_password(self, encrypted_password):
        """Decrypt password for use"""
        if isinstance(encrypted_password, str):
            encrypted_password = encrypted_password.encode()
        return self.cipher.decrypt(encrypted_password).decode()

# Initialize globally
password_manager = ServerPasswordManager()
```

**Step 3: Update server storage**
```python
# In get_servers_config()
def get_servers_config():
    """Load server configurations"""
    if SERVERS_DIR.exists() and (SERVERS_DIR / 'servers.json').exists():
        with open(SERVERS_DIR / 'servers.json', 'r') as f:
            data = json.load(f)
        
        # Decrypt passwords
        for server in data.get('servers', []):
            if server.get('auth_type') == 'password':
                try:
                    server['password'] = password_manager.decrypt_password(
                        server['password']
                    )
                except Exception as e:
                    logger.error(f"Failed to decrypt password: {e}")
        
        return data.get('servers', [])
    return []

# In add/update server
@app.route('/api/servers', methods=['POST'])
def add_server():
    """Add server with encrypted password"""
    server = request.json
    
    # Encrypt password before storage
    if server.get('auth_type') == 'password':
        server['password'] = password_manager.encrypt_password(
            server['password']
        )
    
    # Save to file...
```

**Step 4: Set file permissions**
```python
# Ensure servers.json is only readable by application user
os.chmod(SERVERS_DIR / 'servers.json', 0o600)
os.chmod(SERVERS_DIR / '.crypto/key.bin', 0o600)
```

---

### ISSUE 3: Command Injection via Shell Execution (MEDIUM)

**Severity:** 🟠 MEDIUM

**Current Code:**
```python
# Lines 483, 509, 516, 621, 629
result = subprocess.run(f"{ssh_base} '{command}'", shell=True, ...)
```

**Problem:**
- Using `shell=True` with f-strings is vulnerable to injection
- If server config contains special characters, they could break out of quotes
- Example: password `pass'word` would break the command string

**Attack Scenario:**
```python
password = "pass'); echo 'hacked'; echo 'pw"
# Results in:
cmd = "sshpass -p 'pass'); echo 'hacked'; echo 'pw' ssh ..."
# Attacker could inject arbitrary commands
```

**Fix Implementation:**

**Step 1: Use list-based subprocess (no shell)**
```python
# BEFORE (VULNERABLE)
result = subprocess.run(
    f"{ssh_base} '{command}'",
    shell=True,
    capture_output=True,
    text=True
)

# AFTER (SAFE)
import shlex

cmd_parts = shlex.split(f"{ssh_base}")
cmd_parts.append(command)

result = subprocess.run(
    cmd_parts,
    capture_output=True,
    text=True
)
```

**Step 2: Create safe execution wrapper**
```python
def safe_ssh_command(server, command, timeout=30):
    """Execute SSH command safely without shell injection"""
    cmd_parts = []
    
    if server["auth_type"] == "password":
        cmd_parts.extend(['sshpass', '-p', server['password']])
    
    cmd_parts.extend(['ssh'])
    cmd_parts.extend(['-o', 'StrictHostKeyChecking=accept-new'])
    cmd_parts.extend(['-o', 'UserKnownHostsFile=/.ssh/known_hosts'])
    cmd_parts.extend(['-p', str(server['port'])])
    
    if server["auth_type"] == "public_key" and server.get('key_path'):
        cmd_parts.extend(['-i', server['key_path']])
    
    cmd_parts.append(f"{server['user']}@{server['host']}")
    cmd_parts.append(command)
    
    return subprocess.run(
        cmd_parts,
        capture_output=True,
        text=True,
        timeout=timeout
    )

# Usage
result = safe_ssh_command(server, "mkdir -p /opt/audit-toolkit")
```

---

### ISSUE 4: No SSH Key Type Enforcement (LOW)

**Severity:** 🟡 LOW

**Recommendation:**
```python
# Only accept strong key types
ALLOWED_KEY_TYPES = {'ed25519', 'rsa-4096'}

def validate_ssh_key(key_path):
    """Validate SSH key strength and type"""
    try:
        result = subprocess.run(
            ['ssh-keygen', '-l', '-f', key_path],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        # Check key size (expect 256 for ed25519, 4096 for RSA)
        if '256 bits' not in result.stdout and '4096 bits' not in result.stdout:
            return False, "Weak SSH key (use ED25519 or RSA-4096)"
        
        return True, "Key is strong"
    except Exception as e:
        return False, str(e)
```

---

## Best Practices for Production

### 1. Network Segmentation

```
┌─────────────────────────┐
│  Management Network     │
│  (Toolkit Server)       │
│  - Hardened             │
│  - VPN only             │
│  - 2FA enabled          │
└────────────┬────────────┘
             │ VPN/SSH
             │ (Encrypted)
┌────────────v────────────┐
│  Audit Network          │
│  (Production Servers)   │
│  - SSH only (port 22)   │
│  - Key-based auth       │
│  - Rate limiting        │
└─────────────────────────┘
```

### 2. SSH Hardening on Remote Servers

```bash
# /etc/ssh/sshd_config on remote servers
Port 22                           # Use non-standard port in production
PermitRootLogin no                # Prevent root login
PasswordAuthentication no          # Force key-based auth
PubkeyAuthentication yes          # Enable public key auth
StrictModes yes                   # Check file permissions
MaxAuthTries 3                    # Limit login attempts
LoginGraceTime 30                 # Timeout for authentication
X11Forwarding no                  # Disable X11
AllowUsers deployer               # Only allow specific user
```

### 3. Audit Toolkit User Permissions

```bash
# On each remote server
sudo useradd -m -s /bin/bash deployer
sudo mkdir -p /opt/audit-toolkit
sudo chown deployer:deployer /opt/audit-toolkit
sudo chmod 755 /opt/audit-toolkit

# Add to sudoers for privileged audits
echo "deployer ALL=(ALL) NOPASSWD: /opt/audit-toolkit/audits/*" | sudo tee /etc/sudoers.d/audit-toolkit
sudo chmod 440 /etc/sudoers.d/audit-toolkit
```

### 4. Logging and Monitoring

```python
# Add logging to app.py
import logging

logging.basicConfig(
    filename='/var/log/audit-toolkit/web.log',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Log all connections
logger.info(f"SSH connection to {server['host']}:{server['port']} via {server['auth_type']}")

# Log all commands
logger.info(f"Command executed: {command[:100]}...")  # First 100 chars
```

### 5. Regular Security Updates

```bash
# Management machine
sudo apt update && sudo apt upgrade -y
pip install --upgrade paramiko cryptography flask

# Remote servers
# Run toolkit's platform/baseline/updates.sh audit
bash audits/platform/baseline/updates.sh
```

### 6. Access Control List

```python
# web/app.py - Add authentication
from functools import wraps
from flask import session

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/api/servers', methods=['GET'])
@require_auth
def get_servers():
    return jsonify(get_servers_config())
```

---

## Configuration Examples

### Example 1: Public Key Authentication (Recommended)

**servers.json:**
```json
{
  "servers": [
    {
      "id": 1,
      "name": "production-web-01",
      "host": "192.168.1.100",
      "port": 22,
      "user": "deployer",
      "auth_type": "public_key",
      "key_path": "/home/admin/.ssh/audit-toolkit-ed25519",
      "key_passphrase": "optional-passphrase",
      "remote_path": "/opt/audit-toolkit"
    }
  ]
}
```

**Setup:**
```bash
# Generate key with passphrase
ssh-keygen -t ed25519 -f ~/.ssh/audit-toolkit-ed25519 -N "secure-passphrase"

# Add to remote server
ssh-copy-id -i ~/.ssh/audit-toolkit-ed25519.pub deployer@192.168.1.100

# Test connection
ssh -i ~/.ssh/audit-toolkit-ed25519 deployer@192.168.1.100 'echo Connected'
```

### Example 2: Password Authentication (For Legacy Systems)

**servers.json (after encryption):**
```json
{
  "servers": [
    {
      "id": 2,
      "name": "legacy-system-01",
      "host": "10.0.1.50",
      "port": 2222,
      "user": "audit_user",
      "auth_type": "password",
      "password": "gAAAAABl3sXy7K9xV2J...",  // Encrypted password
      "remote_path": "/var/audit-toolkit"
    }
  ]
}
```

**File permissions:**
```bash
chmod 600 /opt/audit-toolkit/servers/servers.json
chmod 700 /opt/audit-toolkit/servers/.crypto
chmod 600 /opt/audit-toolkit/servers/.crypto/key.bin
```

### Example 3: Hardened Production Setup

```json
{
  "servers": [
    {
      "id": 3,
      "name": "prod-web-01",
      "host": "10.20.30.40",
      "port": 2222,
      "user": "audit_readonly",
      "auth_type": "public_key",
      "key_path": "/etc/audit-toolkit/.ssh/prod-key",
      "remote_path": "/opt/audit-toolkit",
      "audit_domains": ["platform", "web", "network"],
      "schedule": "daily",
      "timeout": 300
    }
  ]
}
```

---

## Summary

### Current Security Status

| Component | Current | Target | Status |
|-----------|---------|--------|--------|
| Transport Encryption | ✅ SSH/AES-256 | ✅ SSH/AES-256 | ✅ SECURE |
| Host Key Verification | ❌ Disabled | ✅ Enabled | 🔴 ISSUE |
| Password Encryption | ❌ Plaintext | ✅ Fernet/AES | 🔴 ISSUE |
| Command Injection | ❌ Shell=True | ✅ Safe args list | 🟡 ISSUE |
| Key Strength | ⚠️ RSA-2048 | ✅ ED25519 | ⚠️ WEAK |
| Authentication | ✅ Supported | ✅ Both methods | ✅ GOOD |
| Logging | ❌ Minimal | ✅ Comprehensive | 🔴 ISSUE |
| Access Control | ❌ None | ✅ RBAC | 🔴 ISSUE |

### Recommended Implementation Timeline

```
IMMEDIATE (Week 1):
  ☐ Fix StrictHostKeyChecking (Issue #1) - HIGH
  ☐ Add password encryption (Issue #2) - HIGH
  ☐ Fix shell injection (Issue #3) - MEDIUM

SHORT-TERM (Week 2-3):
  ☐ Add comprehensive logging
  ☐ Implement access control
  ☐ Add SSH key validation
  
MEDIUM-TERM (Month 2):
  ☐ Migrate to Paramiko library (replace subprocess.run)
  ☐ Add certificate-based authentication
  ☐ Implement key rotation policy
  
LONG-TERM (Q2 2026):
  ☐ Add HSM support for key storage
  ☐ Implement SSH security audit
  ☐ Add compliance reporting (SOC 2, NIST)
```

---

## References

- [OWASP SSH Best Practices](https://owasp.org/www-community/attacks/Command_Injection)
- [CIS SSH Hardening Benchmark](https://www.cisecurity.org/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework/)
- [SSH Man-in-the-Middle Prevention](https://tools.ietf.org/html/rfc4251)
- [Cryptography Library Documentation](https://cryptography.io/)
- [Python Subprocess Security](https://docs.python.org/3/library/subprocess.html#security-considerations)

