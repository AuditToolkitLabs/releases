"""
API Routes package for Security Audit Toolkit

Provides REST API endpoints organized into blueprints:
- system_routes: Health, status, logs, settings, auth
- server_routes: Server configuration and SSH management
- audit_routes: Discovery, execution, plans (synchronous)
- audit_async_routes: Async execution via Celery task queue
- deploy_routes: Remote deployment operations
- report_routes: Reporting and cleanup
- history_routes: Execution history
- schedule_routes: Scheduled audits
- auth_routes: User authentication and RBAC
"""

from .system_routes import system_bp
from .server_routes import server_bp
from .audit_routes import audit_bp
from .audit_async_routes import async_audit_bp
from .deploy_routes import deploy_bp
from .report_routes import report_bp
from .history_routes import history_bp
from .schedule_routes import schedule_bp
from .backup_routes import backup_bp
from .recovery_routes import recovery_bp
from .dashboard_routes import dashboard_bp
from .monitoring_routes import monitoring_bp
from .discovery_routes import discovery_bp
from .auth_routes import auth_bp
from .hypervisor_routes import hypervisor_bp

__all__ = [
    'system_bp',
    'server_bp',
    'audit_bp',
    'async_audit_bp',
    'deploy_bp',
    'report_bp',
    'history_bp',
    'schedule_bp',
    'backup_bp',
    'recovery_bp',
    'dashboard_bp',
    'monitoring_bp',
    'discovery_bp',
    'auth_bp',
    'hypervisor_bp',
]
