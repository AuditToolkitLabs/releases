"""
Admin Routes for Security Audit Toolkit

Provides:
- User management (CRUD)
- Role assignment
- Account management (lock/unlock)
- Audit log viewing

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import os
import ssl
import json
import secrets
import shutil
import hashlib
import platform
import tempfile
import subprocess  # nosec B404
from datetime import datetime, timedelta
from pathlib import Path

from flask import (
    Blueprint, request, jsonify, render_template, make_response, abort
)
from flask_login import login_required, current_user

from models.user import User, UserSession, AuthAuditLog, Role
from api.auth_routes import require_role, require_permission, require_minimum_role, validate_password_policy
from auth_core import safe_error_response, validate_role_assignment, can_modify_user_role
from logging_utils import log_audit

logger = logging.getLogger(__name__)

# Blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

MASKED_SECRET_VALUE = '••••••••'  # nosec B105


def _env_flag_enabled(name: str) -> bool:
    value = (os.getenv(name, '') or '').strip().lower()
    return value in {'1', 'true', 'yes', 'on'}


def _script_studio_support_ui_enabled() -> bool:
    support_key = os.getenv('SCRIPT_STUDIO_SUPPORT_KEY', '')
    return len(support_key) >= 8 and _env_flag_enabled('SCRIPT_STUDIO_SUPPORT_UI_ENABLED')


def _certificate_store_dir() -> Path:
    from config import ROOT_DIR
    return ROOT_DIR / 'settings' / 'certificates'


def _security_settings_file() -> Path:
    from config import ROOT_DIR
    return ROOT_DIR / 'settings' / 'security_settings.json'


def _load_security_settings_raw() -> dict:
    defaults = get_default_security_settings()
    settings_file = _security_settings_file()
    if settings_file.exists():
        try:
            with open(settings_file, 'r', encoding='utf-8') as handle:
                current = json.load(handle)
            defaults.update(current)
        except (OSError, json.JSONDecodeError):
            logger.warning("Failed to load raw security settings for certificate metadata", exc_info=True)
    return defaults


def _persist_security_settings_raw(updated: dict) -> None:
    settings_file = _security_settings_file()
    settings_file.parent.mkdir(parents=True, exist_ok=True)
    with open(settings_file, 'w', encoding='utf-8') as handle:
        json.dump(updated, handle, indent=2)

    try:
        from security_settings import invalidate_cache
        invalidate_cache()
    except ImportError:
        logger.warning("Failed to invalidate security settings cache", exc_info=True)


def _certificate_paths() -> dict:
    store = _certificate_store_dir()
    return {
        'store': store,
        'cert': store / 'custom_tls_cert.pem',
        'key': store / 'custom_tls_key.pem',
        'chain': store / 'custom_tls_chain.pem',
        'fullchain': store / 'custom_tls_fullchain.pem',
    }


def _runtime_nginx_paths() -> dict:
    ssl_dir = Path('/etc/nginx/ssl')
    return {
        'ssl_dir': ssl_dir,
        'cert': ssl_dir / 'audit-toolkit.crt',
        'key': ssl_dir / 'audit-toolkit.key',
        'chain': ssl_dir / 'audit-toolkit-chain.crt',
    }


def _runtime_windows_paths() -> dict:
    runtime_dir = _certificate_store_dir() / 'runtime' / 'windows-nginx'
    return {
        'runtime_dir': runtime_dir,
        'cert': runtime_dir / 'audit-toolkit.crt',
        'key': runtime_dir / 'audit-toolkit.key',
        'chain': runtime_dir / 'audit-toolkit-chain.crt',
        'fullchain': runtime_dir / 'audit-toolkit-fullchain.crt',
    }


def _resolve_windows_nginx_paths() -> tuple[str | None, dict]:
    nginx_bin = shutil.which('nginx')
    configured_ssl_dir = os.environ.get('NGINX_SSL_DIR', '').strip()

    if configured_ssl_dir:
        ssl_dir = Path(configured_ssl_dir)
        return nginx_bin, {
            'ssl_dir': ssl_dir,
            'cert': ssl_dir / 'audit-toolkit.crt',
            'key': ssl_dir / 'audit-toolkit.key',
            'chain': ssl_dir / 'audit-toolkit-chain.crt',
        }

    candidate_dirs: list[Path] = []
    if nginx_bin:
        nginx_exe = Path(nginx_bin).resolve()
        root = nginx_exe.parent
        candidate_dirs.extend([
            root / 'conf' / 'ssl',
            root / 'ssl',
        ])

    candidate_dirs.extend([
        Path('C:/nginx/conf/ssl'),
        Path('C:/nginx/ssl'),
        Path('C:/ProgramData/nginx/ssl'),
    ])

    for candidate in candidate_dirs:
        if candidate.exists():
            return nginx_bin, {
                'ssl_dir': candidate,
                'cert': candidate / 'audit-toolkit.crt',
                'key': candidate / 'audit-toolkit.key',
                'chain': candidate / 'audit-toolkit-chain.crt',
            }

    fallback = _runtime_windows_paths()
    return nginx_bin, {
        'ssl_dir': fallback['runtime_dir'],
        'cert': fallback['cert'],
        'key': fallback['key'],
        'chain': fallback['chain'],
    }


def _runtime_provider() -> tuple[str, str]:
    system_name = platform.system().lower()
    if system_name == 'linux':
        if shutil.which('nginx') is not None or Path('/etc/nginx').exists():
            return 'linux_nginx', 'Linux nginx runtime detected.'
        return 'manual', 'Linux host detected but nginx runtime was not found. Manual apply required.'

    if system_name == 'windows':
        nginx_bin = shutil.which('nginx')
        if nginx_bin:
            return 'windows_nginx', 'Windows nginx runtime detected.'
        return 'manual', 'Windows host detected but nginx runtime was not found in PATH. Install nginx and set NGINX_SSL_DIR for custom SSL path.'

    return 'manual', f'{platform.system()} host detected. Automatic runtime apply is not available.'


def _runtime_diagnostics() -> dict:
    provider, reason = _runtime_provider()
    system_name = platform.system().lower()
    diagnostics = {
        'provider': provider,
        'platform': platform.system(),
        'reason': reason,
        'nginx_binary': None,
        'nginx_in_path': False,
        'configured_ssl_dir_env': os.environ.get('NGINX_SSL_DIR', '').strip(),
        'resolved_ssl_dir': None,
        'resolved_cert_path': None,
        'resolved_key_path': None,
    }

    if system_name == 'linux':
        nginx_bin = shutil.which('nginx')
        runtime = _runtime_nginx_paths()
        diagnostics['nginx_binary'] = nginx_bin
        diagnostics['nginx_in_path'] = bool(nginx_bin)
        diagnostics['resolved_ssl_dir'] = str(runtime['ssl_dir'])
        diagnostics['resolved_cert_path'] = str(runtime['cert'])
        diagnostics['resolved_key_path'] = str(runtime['key'])
        return diagnostics

    if system_name == 'windows':
        nginx_bin, runtime = _resolve_windows_nginx_paths()
        diagnostics['nginx_binary'] = nginx_bin
        diagnostics['nginx_in_path'] = bool(nginx_bin)
        diagnostics['resolved_ssl_dir'] = str(runtime['ssl_dir'])
        diagnostics['resolved_cert_path'] = str(runtime['cert'])
        diagnostics['resolved_key_path'] = str(runtime['key'])
        return diagnostics

    return diagnostics


def _sha256_fingerprint_from_pem(pem_text: str) -> str:
    der = ssl.PEM_cert_to_DER_cert(pem_text)
    return hashlib.sha256(der).hexdigest().upper()


def _decode_certificate(cert_path: Path) -> dict:
    with open(cert_path, 'r', encoding='utf-8', errors='replace') as cert_file:
        pem_text = cert_file.read()

    subject = ''
    issuer = ''
    not_before = ''
    not_after = ''

    openssl_bin = shutil.which('openssl')
    if openssl_bin:
        proc = subprocess.run(
            [openssl_bin, 'x509', '-in', str(cert_path), '-noout', '-subject', '-issuer', '-startdate', '-enddate'],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec B603
        if proc.returncode == 0:
            for line in proc.stdout.splitlines():
                line = line.strip()
                if line.startswith('subject='):
                    subject = line.split('=', 1)[1].strip()
                elif line.startswith('issuer='):
                    issuer = line.split('=', 1)[1].strip()
                elif line.startswith('notBefore='):
                    not_before = line.split('=', 1)[1].strip()
                elif line.startswith('notAfter='):
                    not_after = line.split('=', 1)[1].strip()

    return {
        'subject': subject,
        'issuer': issuer,
        'not_before': not_before,
        'not_after': not_after,
        'fingerprint_sha256': _sha256_fingerprint_from_pem(pem_text),
    }


def _validate_cert_and_key_pair(cert_pem: str, key_pem: str, chain_pem: str = '') -> None:
    with tempfile.TemporaryDirectory() as tmp:
        cert_path = Path(tmp) / 'cert.pem'
        key_path = Path(tmp) / 'key.pem'

        fullchain_text = cert_pem.strip() + '\n'
        if chain_pem.strip():
            fullchain_text += chain_pem.strip() + '\n'

        cert_path.write_text(fullchain_text, encoding='utf-8')
        key_path.write_text(key_pem.strip() + '\n', encoding='utf-8')

        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))


def _runtime_apply_available() -> tuple[bool, str]:
    provider, reason = _runtime_provider()
    if provider in ('linux_nginx', 'windows_nginx'):
        return True, reason
    return False, reason


def _copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _apply_certificates_to_runtime() -> dict:
    paths = _certificate_paths()

    if not paths['cert'].exists() or not paths['key'].exists():
        return {
            'success': False,
            'applied': False,
            'message': 'No uploaded certificate/key found in settings store.',
            'manual_required': False,
        }

    provider, provider_reason = _runtime_provider()

    if provider == 'windows_nginx':
        nginx_bin, runtime = _resolve_windows_nginx_paths()
        source_cert = paths['fullchain'] if paths['fullchain'].exists() else paths['cert']
        try:
            _copy_file(source_cert, runtime['cert'])
            _copy_file(paths['key'], runtime['key'])
            if paths['chain'].exists():
                _copy_file(paths['chain'], runtime['chain'])

            if runtime['key'].exists():
                os.chmod(runtime['key'], 0o600)
            if runtime['cert'].exists():
                os.chmod(runtime['cert'], 0o644)
            if runtime['chain'].exists():
                os.chmod(runtime['chain'], 0o644)

            if nginx_bin:
                nginx_test = subprocess.run(
                    [nginx_bin, '-t'],
                    capture_output=True,
                    text=True,
                    check=False,
                )  # nosec B603
                if nginx_test.returncode != 0:
                    return {
                        'success': False,
                        'applied': False,
                        'provider': provider,
                        'message': f'Windows nginx config test failed: {nginx_test.stderr.strip() or nginx_test.stdout.strip()}',
                        'manual_required': True,
                    }

                reload_proc = subprocess.run(
                    [nginx_bin, '-s', 'reload'],
                    capture_output=True,
                    text=True,
                    check=False,
                )  # nosec B603
                if reload_proc.returncode != 0:
                    return {
                        'success': False,
                        'applied': False,
                        'provider': provider,
                        'message': f'Windows nginx reload failed: {reload_proc.stderr.strip() or reload_proc.stdout.strip()}',
                        'manual_required': True,
                    }

            return {
                'success': True,
                'applied': True,
                'provider': provider,
                'message': f'Certificate files applied to Windows nginx runtime at {runtime["ssl_dir"]}.',
                'manual_required': False,
            }
        except PermissionError:
            return {
                'success': False,
                'applied': False,
                'provider': provider,
                'message': 'Insufficient permissions to write Windows nginx certificate files.',
                'manual_required': True,
            }
        except (OSError, RuntimeError, ssl.SSLError, ValueError) as exc:
            logger.error('Failed to apply certificates for Windows nginx runtime: %s', exc)
            return {
                'success': False,
                'applied': False,
                'provider': provider,
                'message': f'Windows nginx apply failed: {exc}',
                'manual_required': True,
            }

    if provider != 'linux_nginx':
        return {
            'success': False,
            'applied': False,
            'provider': provider,
            'message': provider_reason,
            'manual_required': True,
        }

    runtime = _runtime_nginx_paths()

    source_cert = paths['fullchain'] if paths['fullchain'].exists() else paths['cert']

    try:
        _copy_file(source_cert, runtime['cert'])
        _copy_file(paths['key'], runtime['key'])
        if paths['chain'].exists():
            _copy_file(paths['chain'], runtime['chain'])

        os.chmod(runtime['key'], 0o600)
        os.chmod(runtime['cert'], 0o644)
        if runtime['chain'].exists():
            os.chmod(runtime['chain'], 0o644)

        test_result = shutil.which('nginx')
        if test_result:
            nginx_test = subprocess.run([test_result, '-t'], capture_output=True, text=True, check=False)  # nosec B603
            if nginx_test.returncode != 0:
                return {
                    'success': False,
                    'applied': False,
                    'message': f'nginx config test failed after certificate update: {nginx_test.stderr.strip() or nginx_test.stdout.strip()}',
                    'manual_required': True,
                }

        systemctl_bin = shutil.which('systemctl')
        if systemctl_bin:
            reload_proc = subprocess.run([systemctl_bin, 'reload', 'nginx'], capture_output=True, text=True, check=False)  # nosec B603
            if reload_proc.returncode != 0:
                reload_proc = subprocess.run([systemctl_bin, 'restart', 'nginx'], capture_output=True, text=True, check=False)  # nosec B603
            if reload_proc.returncode != 0:
                return {
                    'success': False,
                    'applied': False,
                    'message': f'Certificate files updated, but nginx reload/restart failed: {reload_proc.stderr.strip() or reload_proc.stdout.strip()}',
                    'manual_required': True,
                }

        return {
            'success': True,
            'applied': True,
            'provider': provider,
            'message': 'Certificate files applied to nginx runtime successfully.',
            'manual_required': False,
        }

    except PermissionError:
        return {
            'success': False,
            'applied': False,
            'provider': provider,
            'message': 'Insufficient permissions to write runtime certificate files. Run with elevated privileges.',
            'manual_required': True,
        }
    except (OSError, RuntimeError, ssl.SSLError, ValueError) as exc:
        logger.error('Failed to apply certificates to runtime: %s', exc)
        return {
            'success': False,
            'applied': False,
            'provider': provider,
            'message': f'Runtime apply failed: {exc}',
            'manual_required': True,
        }


def _test_nginx_runtime() -> dict:
    provider, reason = _runtime_provider()
    if provider == 'linux_nginx':
        nginx_bin = shutil.which('nginx') or 'nginx'
        command = [nginx_bin, '-t']
    elif provider == 'windows_nginx':
        nginx_bin, _ = _resolve_windows_nginx_paths()
        if not nginx_bin:
            return {
                'success': False,
                'provider': provider,
                'message': 'Windows nginx binary not found in PATH.',
                'output': '',
            }
        command = [nginx_bin, '-t']
    else:
        return {
            'success': False,
            'provider': provider,
            'message': reason,
            'output': '',
        }

    try:
        proc = subprocess.run(command, capture_output=True, text=True, check=False)  # nosec B603
        output = (proc.stderr or proc.stdout or '').strip()
        if proc.returncode == 0:
            return {
                'success': True,
                'provider': provider,
                'message': 'nginx runtime test passed.',
                'output': output,
                'return_code': 0,
            }

        return {
            'success': False,
            'provider': provider,
            'message': 'nginx runtime test failed.',
            'output': output,
            'return_code': proc.returncode,
        }
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        return {
            'success': False,
            'provider': provider,
            'message': f'nginx runtime test error: {exc}',
            'output': '',
        }


def _reload_nginx_runtime() -> dict:
    provider, reason = _runtime_provider()

    if provider == 'linux_nginx':
        nginx_bin = shutil.which('nginx') or 'nginx'
        output_parts: list[str] = []

        systemctl_bin = shutil.which('systemctl')
        if systemctl_bin:
            reload_proc = subprocess.run(
                [systemctl_bin, 'reload', 'nginx'],
                capture_output=True,
                text=True,
                check=False,
            )  # nosec B603
            output_parts.append((reload_proc.stderr or reload_proc.stdout or '').strip())
            if reload_proc.returncode != 0:
                restart_proc = subprocess.run(
                    [systemctl_bin, 'restart', 'nginx'],
                    capture_output=True,
                    text=True,
                    check=False,
                )  # nosec B603
                output_parts.append((restart_proc.stderr or restart_proc.stdout or '').strip())
                if restart_proc.returncode != 0:
                    return {
                        'success': False,
                        'provider': provider,
                        'message': 'Linux nginx reload/restart failed.',
                        'output': '\n'.join(part for part in output_parts if part),
                    }

            return {
                'success': True,
                'provider': provider,
                'message': 'Linux nginx reloaded successfully.',
                'output': '\n'.join(part for part in output_parts if part),
            }

        proc = subprocess.run(
            [nginx_bin, '-s', 'reload'],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec B603
        output = (proc.stderr or proc.stdout or '').strip()
        if proc.returncode == 0:
            return {
                'success': True,
                'provider': provider,
                'message': 'Linux nginx reloaded successfully.',
                'output': output,
            }
        return {
            'success': False,
            'provider': provider,
            'message': 'Linux nginx reload failed.',
            'output': output,
        }

    if provider == 'windows_nginx':
        nginx_bin, _ = _resolve_windows_nginx_paths()
        if not nginx_bin:
            return {
                'success': False,
                'provider': provider,
                'message': 'Windows nginx binary not found in PATH.',
                'output': '',
            }

        proc = subprocess.run(
            [nginx_bin, '-s', 'reload'],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec B603
        output = (proc.stderr or proc.stdout or '').strip()
        if proc.returncode == 0:
            return {
                'success': True,
                'provider': provider,
                'message': 'Windows nginx reloaded successfully.',
                'output': output,
            }
        return {
            'success': False,
            'provider': provider,
            'message': 'Windows nginx reload failed.',
            'output': output,
        }

    return {
        'success': False,
        'provider': provider,
        'message': reason,
        'output': '',
    }


# =============================================================================
# Admin Tools Menu
# =============================================================================

@admin_bp.route('/tools', methods=['GET'])
@login_required
def list_admin_tools():
    """
    List all available admin tools for the current user.

    Returns tools based on user role:
    - Admins: User management, Audit logs
    - SuperAdmins: All tools including Settings, Policy, SSH Keys, API Keys, etc.
    """
    tools = []

    # Destination Policy visibility (SuperAdmin only)
    if getattr(current_user, 'role', '') == 'SuperAdmin':
        tools.append({
            'id': 'destination-policy',
            'name': '🌐 Destination Policy',
            'description': 'View destination controls and enforcement logs',
            'url': '/api/admin/destination-policy-page',
            'icon': '🌐',
            'role_required': 'SuperAdmin',
            'badge': 'READ',
            'order': 2
        })

    # User Management (Admin)
    if hasattr(current_user, 'has_minimum_role'):
        if current_user.has_minimum_role('Admin'):
            tools.append({
                'id': 'users',
                'name': '👥 User Management',
                'description': 'Manage user accounts, roles, and permissions',
                'url': '/api/admin/users-page',
                'icon': '👥',
                'role_required': 'Admin',
                'order': 1
            })

            tools.append({
                'id': 'audit-log',
                'name': '📋 Audit Logs',
                'description': 'View authentication and system audit logs',
                'url': '/api/admin/audit-log',
                'icon': '📋',
                'role_required': 'Admin',
                'order': 2
            })

        # SuperAdmin-only tools
        if current_user.role == 'SuperAdmin':
            if _script_studio_support_ui_enabled():
                tools.append({
                    'id': 'script-studio-support',
                    'name': '🛠 Script Studio Support',
                    'description': 'Internal-only activation surface for time-limited engineering edits in Script Studio',
                    'url': '/api/admin/script-studio-support',
                    'icon': '🛠',
                    'role_required': 'SuperAdmin',
                    'badge': 'INTERNAL',
                    'order': 3
                })

            tools.extend([
                {
                    'id': 'agent-security',
                    'name': '🔐 Agent Security',
                    'description': 'Configure agent authentication and security policies',
                    'url': '/api/admin/agent-security',
                    'icon': '🔐',
                    'role_required': 'SuperAdmin',
                    'order': 4
                },
                {
                    'id': 'certificate-management',
                    'name': '📜 Certificate Management',
                    'description': 'Upload and manage customer TLS certificates across deployments',
                    'url': '/api/admin/certificates-page',
                    'icon': '📜',
                    'role_required': 'SuperAdmin',
                    'order': 5
                },
                {
                    'id': 'ssh-keys',
                    'name': '🔑 SSH Key Management',
                    'description': 'Generate and manage SSH keys for server authentication',
                    'url': '/api/admin/ssh-keys',
                    'icon': '🔑',
                    'role_required': 'SuperAdmin',
                    'order': 6
                },
                {
                    'id': 'security-settings',
                    'name': '⚙️ Security Settings',
                    'description': 'Configure global security policies and constraints',
                    'url': '/api/admin/security-settings',
                    'icon': '⚙️',
                    'role_required': 'SuperAdmin',
                    'order': 7
                },
                {
                    'id': 'api-keys',
                    'name': '🔓 API Key Management',
                    'description': 'Manage API keys for external integrations',
                    'url': '/api/admin/api-keys',
                    'icon': '🔓',
                    'role_required': 'SuperAdmin',
                    'order': 8
                },
                {
                    'id': 'email-settings',
                    'name': '📧 Email Configuration',
                    'description': 'Configure SMTP settings for email notifications',
                    'url': '/api/admin/email/settings',
                    'icon': '📧',
                    'role_required': 'SuperAdmin',
                    'order': 9
                },
                {
                    'id': 'standalone-keys',
                    'name': '🗝️ Standalone Key Management',
                    'description': 'Issue, revoke, and audit machine-bound pre-signed keys for standalone agent deployments',
                    'url': '/admin/agents',
                    'icon': '🗝️',
                    'role_required': 'SuperAdmin',
                    'order': 10
                }
            ])

    # Sort by order
    tools = sorted(tools, key=lambda t: t.get('order', 999))

    return jsonify({
        'success': True,
        'tools': tools,
        'total': len(tools),
        'user_role': current_user.role if hasattr(current_user, 'role') else 'unknown'
    })


# =============================================================================
# User Management Page
# =============================================================================

@admin_bp.route('/users-page', methods=['GET'])
@login_required
@require_permission('manage_users')
def users_page():
    """User management admin page"""
    return render_template('admin/users.html')


@admin_bp.route('/agent-security', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def agent_security_page():
    """Agent security settings page (SuperAdmin only)"""
    return render_template('admin/agent_security.html')


@admin_bp.route('/script-studio-support', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def script_studio_support_page():
    """Internal Script Studio support-mode page (SuperAdmin only, hidden behind env flags)."""
    if not _script_studio_support_ui_enabled():
        abort(404)
    return render_template('admin/script_studio_support.html')


@admin_bp.route('/destination-policy-page', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def destination_policy_page():
    """Destination whitelist/blacklist policy page (SuperAdmin only)."""
    can_edit = True
    return render_template('admin/destination-policy.html', can_edit=can_edit)


@admin_bp.route('/certificates-page', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def certificate_management_page():
    """Certificate management page (SuperAdmin only)"""
    response = make_response(render_template('admin/certificates.html'))
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


@admin_bp.route('/certificates/status', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def certificate_status():
    """Get certificate management status."""
    try:
        paths = _certificate_paths()
        runtime_nginx = _runtime_nginx_paths()
        _, runtime_windows = _resolve_windows_nginx_paths()
        available, apply_reason = _runtime_apply_available()
        provider, _ = _runtime_provider()
        diagnostics = _runtime_diagnostics()

        uploaded = paths['cert'].exists() and paths['key'].exists()
        metadata = None
        if uploaded:
            try:
                metadata = _decode_certificate(paths['cert'])
            except (OSError, ValueError, ssl.SSLError, subprocess.SubprocessError) as exc:
                metadata = {
                    'subject': '',
                    'issuer': '',
                    'not_before': '',
                    'not_after': '',
                    'fingerprint_sha256': '',
                    'decode_error': str(exc),
                }

        runtime_cert_path = runtime_nginx['cert']
        runtime_key_path = runtime_nginx['key']
        runtime_target_path = str(runtime_nginx['ssl_dir'])
        if provider == 'windows_nginx':
            runtime_cert_path = runtime_windows['cert']
            runtime_key_path = runtime_windows['key']
            runtime_target_path = str(runtime_windows['ssl_dir'])

        runtime_present = runtime_cert_path.exists() and runtime_key_path.exists()
        runtime_fingerprint = ''
        if runtime_present:
            try:
                runtime_meta = _decode_certificate(runtime_cert_path)
                runtime_fingerprint = runtime_meta.get('fingerprint_sha256', '')
            except (OSError, ValueError, ssl.SSLError, subprocess.SubprocessError):
                runtime_fingerprint = ''

        settings = _load_security_settings_raw()

        return jsonify({
            'success': True,
            'status': {
                'platform': platform.system(),
                'store_path': str(paths['store']),
                'uploaded_certificate_present': uploaded,
                'uploaded_chain_present': paths['chain'].exists(),
                'certificate_metadata': metadata,
                'runtime_provider': provider,
                'runtime_apply_available': available,
                'runtime_apply_reason': apply_reason,
                'runtime_target_path': runtime_target_path,
                'runtime_diagnostics': diagnostics,
                'runtime_certificate_present': runtime_present,
                'runtime_certificate_fingerprint_sha256': runtime_fingerprint,
                'security_settings': {
                    'source': settings.get('server_tls_certificate_source', 'self_signed'),
                    'last_updated': settings.get('server_tls_certificate_last_updated', ''),
                    'last_apply_status': settings.get('server_tls_runtime_apply_status', ''),
                    'last_apply_message': settings.get('server_tls_runtime_apply_message', ''),
                }
            }
        })
    except (OSError, ValueError, ssl.SSLError, subprocess.SubprocessError) as e:
        logger.error("Error fetching certificate status: %s", e)
        return safe_error_response(e, custom_message="Failed to load certificate status")


@admin_bp.route('/certificates/upload', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def upload_certificate_bundle():
    """Upload customer TLS certificate bundle (PEM)."""
    data = request.get_json() or {}
    cert_pem = str(data.get('certificate_pem', '')).strip()
    key_pem = str(data.get('private_key_pem', '')).strip()
    chain_pem = str(data.get('chain_pem', '')).strip()
    apply_now = bool(data.get('apply_now', False))

    if not cert_pem or not key_pem:
        return jsonify({'success': False, 'error': 'certificate_pem and private_key_pem are required'}), 400

    try:
        _validate_cert_and_key_pair(cert_pem, key_pem, chain_pem)

        paths = _certificate_paths()
        paths['store'].mkdir(parents=True, exist_ok=True)

        fullchain_text = cert_pem + '\n'
        if chain_pem:
            fullchain_text += chain_pem + '\n'

        paths['cert'].write_text(cert_pem + '\n', encoding='utf-8')
        paths['key'].write_text(key_pem + '\n', encoding='utf-8')
        paths['fullchain'].write_text(fullchain_text, encoding='utf-8')

        os.chmod(paths['key'], 0o600)
        os.chmod(paths['cert'], 0o644)
        os.chmod(paths['fullchain'], 0o644)

        if chain_pem:
            paths['chain'].write_text(chain_pem + '\n', encoding='utf-8')
            os.chmod(paths['chain'], 0o644)
        elif paths['chain'].exists():
            paths['chain'].unlink()

        meta = _decode_certificate(paths['cert'])
        settings = _load_security_settings_raw()
        settings['server_tls_certificate_source'] = 'customer_uploaded'
        settings['server_tls_certificate_last_updated'] = datetime.utcnow().isoformat()
        settings['server_tls_certificate_subject'] = meta.get('subject', '')
        settings['server_tls_certificate_issuer'] = meta.get('issuer', '')
        settings['server_tls_certificate_not_before'] = meta.get('not_before', '')
        settings['server_tls_certificate_not_after'] = meta.get('not_after', '')
        settings['server_tls_certificate_fingerprint_sha256'] = meta.get('fingerprint_sha256', '')
        settings['server_tls_certificate_chain_installed'] = bool(chain_pem)
        settings['server_tls_runtime_apply_status'] = 'pending'
        settings['server_tls_runtime_apply_message'] = 'Certificate uploaded. Apply to runtime to activate.'
        _persist_security_settings_raw(settings)

        apply_result = None
        if apply_now:
            apply_result = _apply_certificates_to_runtime()
            settings = _load_security_settings_raw()
            if apply_result.get('applied'):
                settings['server_tls_runtime_apply_status'] = 'applied'
            elif apply_result.get('success') and apply_result.get('staged'):
                settings['server_tls_runtime_apply_status'] = 'staged'
            else:
                settings['server_tls_runtime_apply_status'] = 'failed'
            settings['server_tls_runtime_apply_message'] = apply_result.get('message', '')
            _persist_security_settings_raw(settings)

        log_audit(
            action='upload_tls_certificate',
            resource_type='security_settings',
            details={
                'chain_provided': bool(chain_pem),
                'apply_now': apply_now,
                'fingerprint_sha256': meta.get('fingerprint_sha256', ''),
            },
            success=True,
        )

        return jsonify({
            'success': True,
            'message': 'Certificate bundle uploaded successfully',
            'certificate': meta,
            'apply_result': apply_result,
        })
    except ssl.SSLError as exc:
        return jsonify({'success': False, 'error': f'Invalid certificate/key bundle: {exc}'}), 400
    except (OSError, ValueError, RuntimeError, TypeError) as e:
        log_audit(
            action='upload_tls_certificate',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error("Error uploading certificate bundle: %s", e)
        return safe_error_response(e, custom_message="Failed to upload certificate bundle")


@admin_bp.route('/certificates/apply', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def apply_uploaded_certificate_bundle():
    """Apply uploaded certificate bundle to detected runtime where supported."""
    try:
        result = _apply_certificates_to_runtime()

        settings = _load_security_settings_raw()
        if result.get('applied'):
            settings['server_tls_runtime_apply_status'] = 'applied'
        elif result.get('success') and result.get('staged'):
            settings['server_tls_runtime_apply_status'] = 'staged'
        else:
            settings['server_tls_runtime_apply_status'] = 'failed'
        settings['server_tls_runtime_apply_message'] = result.get('message', '')
        settings['server_tls_runtime_last_attempt_at'] = datetime.utcnow().isoformat()
        _persist_security_settings_raw(settings)

        log_audit(
            action='apply_tls_certificate',
            resource_type='security_settings',
            details={'result': result},
            success=bool(result.get('success')),
        )

        status_code = 200 if result.get('success') else 400
        return jsonify({'success': bool(result.get('success')), 'result': result}), status_code
    except (OSError, ValueError, RuntimeError, TypeError) as e:
        log_audit(
            action='apply_tls_certificate',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error("Error applying certificate bundle: %s", e)
        return safe_error_response(e, custom_message="Failed to apply certificate bundle")


@admin_bp.route('/certificates/runtime-test', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def test_certificate_runtime():
    """Run nginx runtime configuration test for current host/provider."""
    try:
        result = _test_nginx_runtime()
        log_audit(
            action='test_tls_runtime',
            resource_type='security_settings',
            details={'result': result},
            success=bool(result.get('success')),
        )
        status_code = 200 if result.get('success') else 400
        return jsonify({'success': bool(result.get('success')), 'result': result}), status_code
    except (OSError, ValueError, RuntimeError, TypeError) as e:
        log_audit(
            action='test_tls_runtime',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error("Error testing certificate runtime: %s", e)
        return safe_error_response(e, custom_message="Failed to test nginx runtime")


@admin_bp.route('/certificates/runtime-reload', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def reload_certificate_runtime():
    """Reload nginx runtime for the current host/provider."""
    try:
        result = _reload_nginx_runtime()
        log_audit(
            action='reload_tls_runtime',
            resource_type='security_settings',
            details={'result': result},
            success=bool(result.get('success')),
        )
        status_code = 200 if result.get('success') else 400
        return jsonify({'success': bool(result.get('success')), 'result': result}), status_code
    except (OSError, ValueError, RuntimeError, TypeError) as e:
        log_audit(
            action='reload_tls_runtime',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error("Error reloading certificate runtime: %s", e)
        return safe_error_response(e, custom_message="Failed to reload nginx runtime")


# =============================================================================
# User CRUD API
# =============================================================================

@admin_bp.route('/users', methods=['GET'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def list_users():
    """List all users with stats"""
    from config import get_db_session

    db = get_db_session()
    try:
        users = db.query(User).order_by(User.created_at.desc()).all()

        # Count stats
        total = len(users)
        active = sum(1 for u in users if u.is_active and not u.is_locked)
        locked = sum(1 for u in users if u.is_locked)

        # Count active sessions
        sessions = db.query(UserSession).filter(
            UserSession.is_active.is_(True),
            UserSession.expires_at > datetime.utcnow()
        ).count()

        log_audit(
            action='list_users',
            resource_type='user',
            details={
                'total_users': total,
                'active_users': active,
                'locked_users': locked,
                'active_sessions': sessions
            },
            success=True
        )

        return jsonify({
            'success': True,
            'users': [user_to_dict(u) for u in users],
            'stats': {
                'total': total,
                'active': active,
                'locked': locked,
                'sessions': sessions
            }
        })
    except Exception as e:
        log_audit(
            action='list_users',
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error listing users: {e}")
        return safe_error_response(e, custom_message="Failed to list users")
    finally:
        db.close()


@admin_bp.route('/users', methods=['POST'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def create_user():
    """Create a new user (requires Admin+ role)"""
    from config import get_db_session

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'No data provided'}), 400

    username = data.get('username', '').strip()
    password = data.get('password', '')
    email = data.get('email', '').strip()

    # Get default role from security settings if not specified
    if 'role' not in data:
        try:
            from security_settings import get_user_management_settings
            user_settings = get_user_management_settings()
            role = user_settings['default_role']
        except ImportError:
            role = 'Viewer'
    else:
        role = data.get('role', 'Viewer')

    # Validate required fields
    if not username:
        return jsonify({'success': False, 'error': 'Username is required'}), 400

    if not password:
        return jsonify({'success': False, 'error': 'Password is required'}), 400

    # Validate password policy
    password_error = validate_password_policy(password)
    if password_error:
        return jsonify({'success': False, 'error': password_error}), 400

    # Validate role
    if role not in Role.ALL_ROLES:
        return jsonify({'success': False, 'error': f'Invalid role. Must be one of: {", ".join(Role.ALL_ROLES)}'}), 400

    # P1-D: Only SuperAdmin can create other SuperAdmin users (explicit check for clarity)
    if role == 'SuperAdmin' and current_user.role != 'SuperAdmin':
        return jsonify({'success': False, 'error': 'Only SuperAdmin can create SuperAdmin users'}), 403

    # P1-D: General role assignment validation (prevent privilege escalation)
    is_valid, error_msg = validate_role_assignment(current_user.role, role, action='create')
    if not is_valid:
        logger.warning(
            f"P1-D: User {current_user.username} ({current_user.role}) attempted to create "
            f"user with {role} role - blocked by role hierarchy validation"
        )
        return jsonify({'success': False, 'error': error_msg}), 403

    db = get_db_session()
    try:
        # Check for existing username
        existing = db.query(User).filter(User.username == username).first()
        if existing:
            return jsonify({'success': False, 'error': 'Username already exists'}), 400

        # Check for existing email
        if email:
            existing_email = db.query(User).filter(User.email == email).first()
            if existing_email:
                return jsonify({'success': False, 'error': 'Email already in use'}), 400

        # Check max_users limit
        try:
            from security_settings import get_user_management_settings
            user_settings = get_user_management_settings()
            max_users = user_settings.get('max_users', 0)
            if max_users > 0:
                current_count = db.query(User).count()
                if current_count >= max_users:
                    return jsonify({
                        'success': False,
                        'error': f'User limit reached ({max_users} users)'
                    }), 400
        except ImportError:
            pass  # Security settings module not available

        # Create user
        user = User(
            username=username,
            email=email or None,
            display_name=data.get('display_name', '').strip() or None,
            role=role,
            auth_provider=data.get('auth_provider', 'local'),
            is_active=data.get('is_active', True),
            mfa_enabled=data.get('mfa_enabled', False),
            must_change_password=data.get('must_change_password', False)
        )
        user.set_password(password)

        db.add(user)
        db.commit()

        logger.info(f"User created: {username} by {current_user.username}")

        # P1-D: Enhanced audit logging for user creation
        log_audit(
            action='create_user',
            resource_id=str(user.id),
            resource_type='user',
            details={
                'username': username,
                'role': role,
                'auth_provider': data.get('auth_provider', 'local'),
                'by_username': current_user.username,
                'by_role': current_user.role
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'User {username} created successfully',
            'user': user_to_dict(user)
        }), 201

    except Exception as e:
        db.rollback()
        log_audit(
            action='create_user',
            resource_type='user',
            details={'username': username},
            success=False,
            error=str(e)
        )
        logger.error(f"Error creating user: {e}")
        return safe_error_response(e, custom_message="Failed to create user")
    finally:
        db.close()


@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def get_user(user_id):
    """Get a specific user"""
    from config import get_db_session

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        log_audit(
            action='get_user',
            resource_id=str(user_id),
            resource_type='user',
            details={'target_username': user.username},
            success=True
        )

        return jsonify({
            'success': True,
            'user': user_to_dict(user)
        })
    except Exception as e:
        log_audit(
            action='get_user',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error getting user: {e}")
        return safe_error_response(e, custom_message="Failed to get user")
    finally:
        db.close()


@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def update_user(user_id):
    """Update a user"""
    from config import get_db_session

    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'No data provided'}), 400

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        # Capture old role for audit logging (P1-D enhancement)
        old_role = user.role

        # P1-D: Prevent modifying SuperAdmin users unless you are SuperAdmin (explicit check)
        if user.role == 'SuperAdmin' and current_user.role != 'SuperAdmin':
            return jsonify({'success': False, 'error': 'Cannot modify SuperAdmin users'}), 403

        # P1-D: General validation - can current user modify this target user?
        is_valid, error_msg = can_modify_user_role(current_user.role, user.role)
        if not is_valid:
            logger.warning(
                f"P1-D: User {current_user.username} ({current_user.role}) attempted to modify "
                f"user {user.username} ({user.role}) - blocked by role hierarchy validation"
            )
            return jsonify({'success': False, 'error': error_msg}), 403

        # P1-D: Validate new role assignment if role is being changed
        new_role = data.get('role', user.role)
        if 'role' in data and new_role != old_role:
            # Explicit SuperAdmin check (for clear error message)
            if new_role == 'SuperAdmin' and current_user.role != 'SuperAdmin':
                return jsonify({'success': False, 'error': 'Cannot assign SuperAdmin role'}), 403

            # General role assignment validation
            is_valid, error_msg = validate_role_assignment(current_user.role, new_role, action='assign')
            if not is_valid:
                logger.warning(
                    f"P1-D: User {current_user.username} ({current_user.role}) attempted to assign "
                    f"{new_role} role to {user.username} - blocked by role hierarchy validation"
                )
                return jsonify({'success': False, 'error': error_msg}), 403

        # Update fields
        if 'username' in data:
            username = data['username'].strip()
            if username and username != user.username:
                existing = db.query(User).filter(User.username == username).first()
                if existing:
                    return jsonify({'success': False, 'error': 'Username already exists'}), 400
                user.username = username

        if 'email' in data:
            email = data['email'].strip()
            if email and email != user.email:
                existing = db.query(User).filter(User.email == email).first()
                if existing:
                    return jsonify({'success': False, 'error': 'Email already in use'}), 400
            user.email = email or None

        if 'display_name' in data:
            user.display_name = data['display_name'].strip() or None

        if 'role' in data:
            user.role = new_role

        if 'auth_provider' in data:
            user.auth_provider = data['auth_provider']

        if 'is_active' in data:
            user.is_active = data['is_active']

        if 'mfa_enabled' in data:
            user.mfa_enabled = data['mfa_enabled']

        if 'must_change_password' in data:
            user.must_change_password = data['must_change_password']

        # Update password if provided
        if data.get('password'):
            password_error = validate_password_policy(data['password'])
            if password_error:
                return jsonify({'success': False, 'error': password_error}), 400
            user.set_password(data['password'])

        user.updated_at = datetime.utcnow()
        db.commit()

        logger.info(f"User updated: {user.username} by {current_user.username}")

        # P1-D: Enhanced audit logging for role changes
        audit_details = {
            'target_username': user.username,
            'by_username': current_user.username,
            'by_role': current_user.role
        }

        # Include role change details if role was modified
        if 'role' in data:
            audit_details['old_role'] = old_role
            audit_details['new_role'] = user.role
            if old_role != user.role:
                audit_details['role_changed'] = True
                # Special audit for role escalation attempts
                log_audit(
                    action='update_user_role',
                    resource_id=str(user_id),
                    resource_type='user',
                    details=audit_details,
                    success=True
                )
        else:
            audit_details['role'] = user.role
            log_audit(
                action='update_user',
                resource_id=str(user_id),
                resource_type='user',
                details=audit_details,
                success=True
            )

        return jsonify({
            'success': True,
            'message': f'User {user.username} updated successfully',
            'user': user_to_dict(user)
        })

    except Exception as e:
        db.rollback()
        log_audit(
            action='update_user',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error updating user: {e}")
        return safe_error_response(e, custom_message="Failed to update user")
    finally:
        db.close()


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@login_required
@require_permission('manage_users')
@require_role('SuperAdmin')
def delete_user(user_id):
    """Delete a user (requires SuperAdmin role)"""
    from config import get_db_session

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        # Prevent deleting SuperAdmin
        if user.role == 'SuperAdmin':
            return jsonify({'success': False, 'error': 'Cannot delete SuperAdmin users'}), 403

        # Prevent self-deletion
        if user.id == current_user.id:
            return jsonify({'success': False, 'error': 'Cannot delete your own account'}), 400

        username = user.username
        db.delete(user)
        db.commit()

        logger.info(f"User deleted: {username} by {current_user.username}")

        log_audit(
            action='delete_user',
            resource_id=str(user_id),
            resource_type='user',
            details={'deleted_username': username},
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'User {username} deleted successfully'
        })

    except Exception as e:
        db.rollback()
        log_audit(
            action='delete_user',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error deleting user: {e}")
        return safe_error_response(e, custom_message="Failed to delete user")
    finally:
        db.close()


# =============================================================================
# Account Management
# =============================================================================

@admin_bp.route('/users/<int:user_id>/unlock', methods=['POST'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def unlock_user(user_id):
    """Unlock a locked user account"""
    from config import get_db_session

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        if not user.is_locked:
            return jsonify({'success': False, 'error': 'User is not locked'}), 400

        user.unlock_account()
        db.commit()

        logger.info(f"User unlocked: {user.username} by {current_user.username}")

        log_audit(
            action='unlock_user',
            resource_id=str(user_id),
            resource_type='user',
            details={'target_username': user.username},
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'User {user.username} unlocked successfully'
        })

    except Exception as e:
        db.rollback()
        log_audit(
            action='unlock_user',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error unlocking user: {e}")
        return safe_error_response(e, custom_message="Failed to unlock user")
    finally:
        db.close()


@admin_bp.route('/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
@require_permission('manage_users')
def reset_user_password(user_id):
    """Reset a user's password for local accounts

    Restrictions:
    - Only Admin and SuperAdmin roles can reset passwords
    - Only local accounts (auth_provider='local') can be reset
    - Cannot reset SuperAdmin passwords (except by another SuperAdmin)
    - User will be set to must_change_password=True
    - User account will be unlocked if locked
    """
    from config import get_db_session

    # Check if user has appropriate role
    if current_user.role not in ['Admin', 'SuperAdmin']:
        return jsonify({'success': False, 'error': 'Only Admin and SuperAdmin can reset passwords'}), 403

    data = request.get_json()
    new_password = data.get('password', '')

    if not new_password:
        return jsonify({'success': False, 'error': 'New password is required'}), 400

    password_error = validate_password_policy(new_password)
    if password_error:
        return jsonify({'success': False, 'error': password_error}), 400

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        # Only allow resetting local account passwords
        if user.auth_provider != 'local':
            return jsonify({
                'success': False,
                'error': f'Cannot reset password for {user.auth_provider} account. Only local accounts can have passwords reset through admin console.'
            }), 403

        # Only SuperAdmin can reset SuperAdmin passwords
        if user.role == 'SuperAdmin' and current_user.role != 'SuperAdmin':
            return jsonify({'success': False, 'error': 'Cannot reset SuperAdmin password (requires SuperAdmin role)'}), 403

        # Check if admin is trying to reset a higher role
        user_role_level = Role.get_role_level(user.role)
        admin_role_level = Role.get_role_level(current_user.role)

        if user_role_level > admin_role_level:
            return jsonify({
                'success': False,
                'error': f'Cannot reset password for {user.role} (requires higher privilege)'
            }), 403

        user.set_password(new_password)
        user.must_change_password = True
        user.unlock_account()
        db.commit()

        logger.info(f"Password reset for: {user.username} (local auth) by {current_user.username}")

        log_audit(
            action='reset_user_password',
            resource_id=str(user_id),
            resource_type='user',
            details={
                'target_username': user.username,
                'auth_provider': user.auth_provider,
                'admin_user': current_user.username
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'Password reset for {user.username}. User will be required to change password on next login.'
        })

    except Exception as e:
        db.rollback()
        log_audit(
            action='reset_user_password',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        logger.error(f"Error resetting password: {e}")
        return safe_error_response(e, custom_message="Failed to reset password")
    finally:
        db.close()


@admin_bp.route('/users/<int:user_id>/sessions', methods=['DELETE'])
@login_required
@require_permission('manage_users')
@require_role('Admin')
def revoke_all_sessions(user_id):
    """Revoke all sessions for a user"""
    from config import get_db_session

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404

        # Revoke all active sessions
        sessions = db.query(UserSession).filter(
            UserSession.user_id == user_id,
            UserSession.is_active.is_(True)
        ).all()

        count = 0
        for s in sessions:
            s.is_active = False
            count += 1

        db.commit()

        logger.info(f"Revoked {count} sessions for: {user.username} by {current_user.username}")

        log_audit(
            action='revoke_all_sessions',
            resource_id=str(user_id),
            resource_type='session',
            details={
                'target_username': user.username,
                'sessions_revoked': count
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'Revoked {count} sessions for {user.username}'
        })

    except Exception as e:
        db.rollback()
        log_audit(
            action='revoke_all_sessions',
            resource_id=str(user_id),
            resource_type='session',
            success=False,
            error=str(e)
        )
        logger.error(f"Error revoking sessions: {e}")
        return safe_error_response(e, custom_message="Failed to revoke sessions")
    finally:
        db.close()


# =============================================================================
# Audit Log
# =============================================================================

@admin_bp.route('/audit-log', methods=['GET'])
@login_required
@require_permission('view_audit_log')
@require_role('Admin')
def get_audit_log():
    """Get authentication audit log"""
    from config import get_db_session

    limit = request.args.get('limit', 100, type=int)
    offset = request.args.get('offset', 0, type=int)
    event_type = request.args.get('event_type')
    username = request.args.get('username')
    success = request.args.get('success')

    db = get_db_session()
    try:
        query = db.query(AuthAuditLog).order_by(AuthAuditLog.created_at.desc())

        if event_type:
            query = query.filter(AuthAuditLog.event_type == event_type)

        if username:
            query = query.filter(AuthAuditLog.username.ilike(f'%{username}%'))

        if success is not None:
            query = query.filter(AuthAuditLog.success == (success.lower() == 'true'))

        total = query.count()
        logs = query.offset(offset).limit(limit).all()

        log_audit(
            action='view_auth_audit_log',
            resource_type='audit_log',
            details={
                'total_records': total,
                'limit': limit,
                'offset': offset,
                'event_type_filter': event_type,
                'username_filter': username
            },
            success=True
        )

        return jsonify({
            'success': True,
            'logs': [{
                'id': log.id,
                'event_type': log.event_type,
                'username': log.username,
                'user_id': log.user_id,
                'ip_address': log.ip_address,
                'success': log.success,
                'failure_reason': log.failure_reason,
                'created_at': log.created_at.isoformat()
            } for log in logs],
            'total': total,
            'limit': limit,
            'offset': offset
        })

    except Exception as e:
        log_audit(
            action='view_auth_audit_log',
            resource_type='audit_log',
            success=False,
            error=str(e)
        )
        logger.error(f"Error fetching audit log: {e}")
        return safe_error_response(e, custom_message="Failed to fetch audit log")
    finally:
        db.close()


# =============================================================================
# Security Settings (SuperAdmin Only)
# =============================================================================

@admin_bp.route('/security-settings', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_security_settings():
    """Get all security settings (SuperAdmin only)"""
    from config import ROOT_DIR

    settings_file = ROOT_DIR / 'settings' / 'security_settings.json'

    try:
        defaults = get_default_security_settings()
        if settings_file.exists():
            with open(settings_file, 'r') as f:
                file_settings = json.load(f)
            settings = defaults.copy()
            settings.update(file_settings)
        else:
            # Return defaults
            settings = defaults

        log_audit(
            action='get_security_settings',
            resource_type='security_settings',
            details={'settings_count': len(settings)},
            success=True
        )

        return jsonify({
            'success': True,
            'settings': settings
        })
    except Exception as e:
        log_audit(
            action='get_security_settings',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error loading security settings: {e}")
        return safe_error_response(e, custom_message="Failed to load security settings")


@admin_bp.route('/security-settings/diagnostics', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_security_settings_diagnostics():
    """Get effective security diagnostics (SuperAdmin only)."""
    try:
        from api.upload_rate_limits import get_upload_limit_observability_snapshot, get_rate_limit_observability_full
        from security_settings import get_all_security_settings

        settings = get_all_security_settings() or {}

        # Include both legacy snapshot (for backward compat) and full observability
        flask_env = os.environ.get('FLASK_ENV', '').strip().lower()
        runtime_env = os.environ.get('ENVIRONMENT', '').strip().lower()
        is_production = flask_env == 'production' or runtime_env == 'production'

        diagnostics = {
            'effective_upload_limits': get_upload_limit_observability_snapshot(),
            'all_rate_limits': get_rate_limit_observability_full(),
            'secrets': {
                'is_production': is_production,
                'flask_secret_key_set': bool(os.environ.get('FLASK_SECRET_KEY')),
                'db_field_encryption_key_set': bool(
                    os.environ.get('DB_FIELD_ENCRYPTION_KEY') or os.environ.get('ENCRYPTION_KEY')
                ),
                'production_hardening_required': os.environ.get(
                    'PRODUCTION_HARDENING_REQUIRED', 'true'
                ).strip().lower() == 'true'
            },
            'storage_guardrails': {
                'result_retention_days': int(settings.get('result_retention', 90) or 90),
                'result_retention_max_records': int(settings.get('result_retention_max_records', 100000) or 100000),
                'hypervisor_result_retention_days': int(settings.get('hypervisor_result_retention_days', 90) or 90),
                'hypervisor_result_retention_max_records': int(settings.get('hypervisor_result_retention_max_records', 100000) or 100000),
                'report_artifact_retention_days': int(settings.get('report_artifact_retention_days', 90) or 90),
                'report_artifact_max_files': int(settings.get('report_artifact_max_files', 10000) or 10000),
                'history_summary_retention_days': int(settings.get('history_summary_retention_days', 365) or 365),
                'compliance_history_retention_days': int(settings.get('compliance_history_retention_days', 365) or 365),
                'cleanup_old_executions_enabled': bool(settings.get('cleanup_old_executions_enabled', True)),
                'cleanup_old_executions_interval_minutes': int(settings.get('cleanup_old_executions_interval_minutes', 1440) or 1440),
                'cleanup_analytics_history_enabled': bool(settings.get('cleanup_analytics_history_enabled', True)),
                'cleanup_analytics_history_interval_minutes': int(settings.get('cleanup_analytics_history_interval_minutes', 1440) or 1440),
                'postgres_maintenance_enabled': bool(settings.get('postgres_maintenance_enabled', True)),
                'postgres_maintenance_vacuum_analyze_enabled': bool(settings.get('postgres_maintenance_vacuum_analyze_enabled', True)),
                'postgres_maintenance_interval_minutes': int(settings.get('postgres_maintenance_interval_minutes', 360) or 360),
                'postgres_database_size_warn_mb': int(settings.get('postgres_database_size_warn_mb', 10240) or 10240),
                'postgres_database_size_critical_mb': int(settings.get('postgres_database_size_critical_mb', 20480) or 20480),
                'postgres_table_size_warn_mb': int(settings.get('postgres_table_size_warn_mb', 2048) or 2048),
                'agent_local_result_max_files': int(settings.get('agent_local_result_max_files', 1000) or 1000),
                'agent_local_min_free_disk_mb': int(settings.get('agent_local_min_free_disk_mb', 512) or 512),
                'agent_local_min_free_disk_pct': int(settings.get('agent_local_min_free_disk_pct', 3) or 3),
                'standalone_agent_result_max_files_per_host': int(settings.get('standalone_agent_result_max_files_per_host', 5000) or 5000),
                'fleet_agent_result_max_files_per_host': int(settings.get('fleet_agent_result_max_files_per_host', 5000) or 5000),
                'agent_result_ingest_disk_guard_enabled': bool(settings.get('agent_result_ingest_disk_guard_enabled', True)),
                'agent_result_ingest_min_free_disk_mb': int(settings.get('agent_result_ingest_min_free_disk_mb', 1024) or 1024),
                'agent_result_ingest_min_free_disk_pct': int(settings.get('agent_result_ingest_min_free_disk_pct', 5) or 5),
                'backup_retention_days': int(settings.get('backup_retention_days', 30) or 30),
                'backup_keep_count': int(settings.get('backup_keep_count', 10) or 10),
                'backup_max_size_mb': int(settings.get('backup_max_size', 500) or 500),
                'backup_include_shared_data': bool(settings.get('backup_include_shared_data', True)),
                'backup_shared_data_paths': str(settings.get('backup_shared_data_paths', '')),
                'log_max_bytes': int(settings.get('log_max_bytes', 20971520) or 20971520),
                'log_backup_count': int(settings.get('log_backup_count', 14) or 14),
                'log_rotation_when': str(settings.get('log_rotation_when', 'midnight') or 'midnight'),
                'log_rotation_interval': int(settings.get('log_rotation_interval', 1) or 1),
                'execution_log_retention_days': int(settings.get('execution_log_retention_days', 14) or 14),
                'execution_log_max_files': int(settings.get('execution_log_max_files', 14))
                if settings.get('execution_log_max_files', None) is not None
                else 14,
            }
        }

        log_audit(
            action='get_security_settings_diagnostics',
            resource_type='security_settings',
            details={'keys': list(diagnostics.keys())},
            success=True
        )

        return jsonify({
            'success': True,
            'diagnostics': diagnostics
        })
    except Exception as e:
        log_audit(
            action='get_security_settings_diagnostics',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error loading security diagnostics: {e}")
        return safe_error_response(e, custom_message="Failed to load security diagnostics")


@admin_bp.route('/security-settings', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def save_security_settings():
    """Save security settings (SuperAdmin only)"""
    from config import ROOT_DIR

    data = request.get_json()
    if not data or 'settings' not in data:
        return jsonify({'success': False, 'error': 'No settings provided'}), 400

    settings = data['settings']
    settings_dir = ROOT_DIR / 'settings'
    settings_file = settings_dir / 'security_settings.json'

    try:
        # Ensure settings directory exists
        settings_dir.mkdir(parents=True, exist_ok=True)

        existing_settings = _load_security_settings_raw()
        settings, generated_secret_fields = prepare_security_settings_for_save(settings, existing_settings)

        # Validate and sanitize settings
        validated = validate_security_settings(settings)

        # Save settings
        with open(settings_file, 'w') as f:
            json.dump(validated, f, indent=2)

        # Invalidate the settings cache so changes take effect immediately
        try:
            from security_settings import invalidate_cache
            invalidate_cache()
            logger.info("Security settings cache invalidated")
        except ImportError:
            pass

        # Log the change
        logger.info(f"Security settings updated by {current_user.username}")
        if generated_secret_fields:
            logger.info(
                "Auto-generated missing fleet-agent signing key(s) during save: %s",
                ", ".join(generated_secret_fields),
            )

        log_audit(
            action='save_security_settings',
            resource_type='security_settings',
            details={
                'settings_count': len(validated),
                'generated_secret_fields': generated_secret_fields,
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'Security settings saved successfully'
        })
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        log_audit(
            action='save_security_settings',
            resource_type='security_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error saving security settings: {e}")
        return safe_error_response(e, custom_message="Failed to save security settings")


def prepare_security_settings_for_save(settings, existing_settings=None):
    """Normalize incoming settings and preserve/generate required fleet-agent signing keys."""
    prepared = dict(settings or {})
    current = dict(existing_settings or {})
    generated_secret_fields = []

    def resolve_required_signing_key(flag_field, key_field, env_var):
        enabled = bool(prepared.get(flag_field, False))

        incoming_value = prepared.get(key_field, '')
        if incoming_value == MASKED_SECRET_VALUE:
            incoming_value = current.get(key_field, '')

        incoming_key = str(incoming_value or '').strip()
        existing_key = str(current.get(key_field, '') or '').strip()
        env_key = os.environ.get(env_var, '').strip()

        if not enabled:
            prepared[key_field] = incoming_key
            return

        if incoming_key:
            prepared[key_field] = incoming_key
            return

        if existing_key:
            prepared[key_field] = existing_key
            return

        if env_key:
            prepared[key_field] = ''
            return

        prepared[key_field] = secrets.token_urlsafe(48)
        generated_secret_fields.append(key_field)

    resolve_required_signing_key(
        'fleet_agent_enforce_signed_config',
        'fleet_agent_config_signing_key',
        'FLEET_AGENT_CONFIG_SIGNING_KEY',
    )
    resolve_required_signing_key(
        'fleet_agent_require_request_signatures',
        'fleet_agent_request_signing_key',
        'FLEET_AGENT_REQUEST_SIGNING_KEY',
    )

    return prepared, generated_secret_fields


def get_default_security_settings():
    """Return default security settings"""
    return {
        # Authentication & Access
        'session_timeout': 30,
        'max_login_attempts': 5,
        'lockout_duration': 15,
        'enforce_2fa': False,

        # Password Policy
        'password_min_length': 12,  # nosec B105
        'password_uppercase': True,  # nosec B105
        'password_numbers': True,  # nosec B105
        'password_special': True,  # nosec B105
        'password_expiry': 90,  # nosec B105
        'password_history': 5,  # nosec B105

        # Audit Execution
        'audit_timeout': 300,
        'result_retention': 90,
        'result_retention_max_records': 100000,
        'hypervisor_result_retention_days': 90,
        'hypervisor_result_retention_max_records': 100000,
        'report_artifact_retention_days': 90,
        'report_artifact_max_files': 10000,
        'evidence_retention_enabled': True,
        'evidence_retention_days': 30,
        'history_summary_retention_days': 365,
        'compliance_history_retention_days': 365,
        'cleanup_old_executions_enabled': True,
        'cleanup_old_executions_interval_minutes': 1440,
        'cleanup_analytics_history_enabled': True,
        'cleanup_analytics_history_interval_minutes': 1440,
        'postgres_maintenance_enabled': True,
        'postgres_maintenance_vacuum_analyze_enabled': True,
        'postgres_maintenance_interval_minutes': 360,
        'postgres_database_size_warn_mb': 10240,
        'postgres_database_size_critical_mb': 20480,
        'postgres_table_size_warn_mb': 2048,

        # User Management Defaults
        'default_role': 'Viewer',
        'auto_approve_users': False,
        'self_registration': False,
        'max_users': 0,

        # Maintenance
        'maintenance_mode': False,
        'maintenance_message': '',

        # Network & Security
        'ip_whitelist': '',
        'ip_blacklist': '',
        'enforce_https': False,

        # Log Retention
        'log_max_bytes': 20971520,
        'log_backup_count': 14,
        'log_rotation_when': 'midnight',
        'log_rotation_interval': 1,
        'execution_log_retention_days': 14,
        'execution_log_max_files': 14,

        # Advanced (Restart Required)
        'rate_limit': 100,
        'max_concurrent_audits': 5,
        'worker_pool_size': 4,
        'analytics_max_result_set_size': 10000,  # Absolute max records allowed per analytics query window
        'log_level': 'INFO',
        'cors_origins': '',

        # Backup Configuration
        'backup_retention_days': 30,
        'backup_keep_count': 10,
        'backup_compress': True,
        'backup_encrypt': False,  # Encrypt toolkit-managed internal backups
        'backup_include_shared_data': True,  # Include mounted shared service data (asset-discovery/agents) in companion archive
        'backup_shared_data_paths': '/opt/audit-toolkit/data/agents,/opt/audit-toolkit/shared/asset-discovery-data,/opt/audit-toolkit/shared/asset-discovery-logs',
        'backup_auto_enabled': False,
        'backup_schedule': 'daily',
        'backup_max_size': 500,

        # Agent Throttle Configuration (Global Defaults)
        'agent_cpu_nice_level': 19,  # Linux: -20 to 19 (19 = lowest priority)
        'agent_process_priority': 'Idle',  # Windows: Idle, BelowNormal, Normal, AboveNormal, High
        'agent_io_class': 'idle',  # Linux ionice: realtime, best-effort, idle
        'agent_min_free_memory_pct': 10,  # Don't run audits if below this %
        'agent_upload_rate_limit': 0,  # bytes/sec (0 = unlimited)
        'agent_download_rate_limit': 0,  # bytes/sec (0 = unlimited)
        'agent_max_concurrent_audits': 1,  # Max parallel audits on agent
        'agent_audit_timeout': 3600,  # Max seconds per audit
        'agent_command_batch_size': 5,  # Max commands per poll
        'agent_batch_delay': 5,  # Seconds between commands
        'agent_max_load_average': 0,  # 0 = disabled (Linux)
        'agent_max_cpu_pct': 0,  # 0 = disabled (Windows)
        'agent_heartbeat_interval': 30,  # Min seconds between heartbeats
        'agent_poll_interval': 60,  # Seconds between command polls
        'agent_local_result_max_files': 1000,  # Max local result files retained on each fleet agent (0 = unlimited)
        'agent_local_min_free_disk_mb': 512,  # Min free disk MB required for local agent writes
        'agent_local_min_free_disk_pct': 3,  # Min free disk % required for local agent writes

        # Agent Result Storage Limits (Core host)
        'standalone_agent_result_max_files_per_host': 5000,  # Max standalone agent result files per host (0 = unlimited)
        'fleet_agent_result_max_files_per_host': 5000,  # Max fleet-agent fallback result files per host (0 = unlimited)

        # Agent Result Ingestion Capacity Limits
        'agent_result_ingest_max_body_kb': 2048,  # Max request body size in KB for agent result ingestion
        'agent_result_ingest_max_results_per_request': 100,  # Max results[] items per managed ingest request
        'agent_result_ingest_max_checks_per_result': 500,  # Max checks[] items per single result payload
        'agent_result_ingest_max_output_chars': 200000,  # Max output field length per result
        'agent_result_ingest_disk_guard_enabled': True,  # Block ingest when free disk watermark is breached
        'agent_result_ingest_min_free_disk_mb': 1024,  # Minimum required free disk space in MB
        'agent_result_ingest_min_free_disk_pct': 5,  # Minimum required free disk percentage
        'agent_discovery_ingest_max_body_kb': 2048,  # Max request body size in KB for hypervisor discovery ingest
        'agent_discovery_ingest_max_items_per_collection': 5000,  # Max items allowed per discovery collection (vms/containers/storage/networks)
        'agent_discovery_ingest_max_total_items': 20000,  # Max combined items across all discovery collections

        # API Upload Rate Limits (per endpoint, per hour)
        'standalone_agent_results_rate_limit_per_hour': 100,
        'fleet_agent_results_rate_limit_per_hour': 200,
        'hypervisor_agent_results_rate_limit_per_hour': 200,
        'asset_discovery_results_rate_limit_per_hour': 200,

        # Asset Discovery Service Rate Limits (per minute)
        # These control internal asset-discovery API endpoint rate limiting
        'asset_discovery_api_rate_limit_per_minute': 100,  # General API browsing (assets, lists)
        'asset_discovery_scan_rate_limit_per_minute': 20,  # Scan create/test operations
        'asset_discovery_cve_sync_rate_limit_per_minute': 10,  # CVE database sync requests
        'asset_discovery_dashboard_rate_limit_per_minute': 60,  # Dashboard widget requests

        # Authentication Rate Limits (per minute) - Security-Critical
        'auth_login_rate_limit_per_minute': 5,  # Login attempts (prevents brute force)
        'auth_password_reset_rate_limit_per_minute': 3,  # nosec B105
        'auth_registration_rate_limit_per_minute': 5,  # User registration
        'auth_2fa_rate_limit_per_minute': 10,  # 2FA verification attempts

        # API Operation Rate Limits (per minute)
        'api_general_rate_limit_per_minute': 100,  # General read operations
        'api_write_rate_limit_per_minute': 30,  # Create/update/delete operations
        'api_export_rate_limit_per_minute': 10,  # Export (CSV, PDF, etc.)
        'api_import_rate_limit_per_minute': 5,  # Bulk import operations
        'api_search_rate_limit_per_minute': 60,  # Search/filter operations

        # Scheduled Operations Rate Limits (per minute)
        'schedule_list_rate_limit_per_minute': 100,  # Listing schedules
        'schedule_create_rate_limit_per_minute': 20,  # Creating schedules
        'schedule_run_rate_limit_per_minute': 10,  # Manual trigger
        'report_generate_rate_limit_per_minute': 10,  # Report generation

        # Agent Communication Rate Limits (per minute)
        'agent_heartbeat_rate_limit_per_minute': 30,  # Agent heartbeats
        'agent_command_poll_rate_limit_per_minute': 20,  # Command polling
        'agent_registration_rate_limit_per_minute': 5,  # New agent registration

        # Audit Execution Rate Limits (per minute)
        'audit_start_rate_limit_per_minute': 10,  # Starting audits
        'audit_status_rate_limit_per_minute': 60,  # Status checks

        # Agent Security Configuration
        'agent_require_approval': False,  # Require admin approval for new agents
        'agent_auto_approve_known_hosts': True,  # Auto-approve if hostname matches existing
        'agent_tls_verify': True,  # Verify TLS certificates
        'agent_tls_pinning_enabled': False,  # Enable certificate pinning
        'agent_tls_pinned_cert_hash': '',  # SHA256 hash of pinned certificate
        'agent_api_key_rotation_days': 0,  # Days before API key rotation warning (0 = disabled)
        'agent_api_key_grace_period_hours': 24,  # Hours old key remains valid after rotation
        'agent_encrypt_keys_at_rest': True,  # Require encrypted key storage on agents
        'fleet_agent_enforce_signed_config': True,  # Require signed config envelopes for managed config pulls (default-on)
        'fleet_agent_config_max_age_seconds': 900,  # Freshness window for managed config envelope
        'fleet_agent_config_signing_key': '',  # Shared signing key (HMAC compatibility path)
        'fleet_agent_require_request_signatures': False,  # Require signed managed runtime requests (Phase 3)
        'fleet_agent_request_signature_max_age_seconds': 300,  # Freshness window for request signatures
        'fleet_agent_request_signing_key': '',  # HMAC signing key for managed runtime request verification
        'fleet_agent_request_signature_ecdsa_dual_verify_enabled': False,  # Dev-stage dual verify (accept HMAC or ECDSA)
        'fleet_agent_request_signature_ecdsa_public_key': '',  # PEM public key for ECDSA signature verification

        # Fleet Agent Result Encryption (Phase 2)
        'fleet_agent_result_encryption_enabled': False,  # Encrypt results at rest using Fernet AES-128
        'fleet_agent_result_encryption_algorithm': 'fernet-aes128',  # Algorithm (fernet-aes128)
        'fleet_agent_result_encryption_key_derivation': 'agent_id',  # Key derivation: agent_id, shared, custom
        'fleet_agent_results_encryption_key_custom': '',  # Custom key (base64) if using custom derivation

        # Global SSH Host Key Policy
        'ssh_host_key_policy': 'warn',  # strict, warn, auto

        # SSH Key Authentication (Preferred over password)
        'ssh_default_key_name': 'audit-toolkit',  # Default key name to use/generate
        'ssh_prefer_key_auth': True,  # Prefer SSH key auth over password when available
        'ssh_key_deploy_backup': True,  # Backup existing authorized_keys before deploying

        # TLS Configuration (Phase 1 knobs)
        'tls_minimum_version_toolkit': 'TLSv1_3',
        'tls_minimum_version_external': 'TLSv1_2',
        'tls_maximum_version': 'TLSv1_3',
        'tls_cipher_suites': 'ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!DSS:!RC4:!DES',
        'tls_certificate_verification': True,
        'tls_strict_mode': False,
        'tls_log_version': True,

        # Server certificate lifecycle metadata (managed via SuperAdmin Certificate Management)
        'server_tls_certificate_source': 'self_signed',
        'server_tls_certificate_last_updated': '',
        'server_tls_certificate_subject': '',
        'server_tls_certificate_issuer': '',
        'server_tls_certificate_not_before': '',
        'server_tls_certificate_not_after': '',
        'server_tls_certificate_fingerprint_sha256': '',
        'server_tls_certificate_chain_installed': False,
        'server_tls_runtime_apply_status': '',
        'server_tls_runtime_apply_message': '',
        'server_tls_runtime_last_attempt_at': '',
    }


def validate_security_settings(settings):
    """Validate and sanitize security settings"""
    defaults = get_default_security_settings()
    validated = {}

    # Integer fields with min/max bounds
    int_fields = {
        'session_timeout': (5, 1440),
        'max_login_attempts': (3, 20),
        'lockout_duration': (1, 1440),
        'password_min_length': (8, 128),
        'password_expiry': (0, 365),
        'password_history': (0, 24),
        'audit_timeout': (30, 3600),
        'result_retention': (7, 365),
        'result_retention_max_records': (0, 5000000),
        'hypervisor_result_retention_days': (7, 365),
        'hypervisor_result_retention_max_records': (0, 5000000),
        'report_artifact_retention_days': (7, 365),
        'report_artifact_max_files': (0, 1000000),
        'evidence_retention_days': (1, 3650),
        'history_summary_retention_days': (30, 3650),
        'compliance_history_retention_days': (30, 3650),
        'cleanup_old_executions_interval_minutes': (5, 10080),
        'cleanup_analytics_history_interval_minutes': (5, 10080),
        'postgres_maintenance_interval_minutes': (5, 10080),
        'postgres_database_size_warn_mb': (512, 1048576),
        'postgres_database_size_critical_mb': (1024, 2097152),
        'postgres_table_size_warn_mb': (128, 1048576),
        'max_users': (0, 10000),
        # Restart-required settings
        'rate_limit': (10, 1000),
        'max_concurrent_audits': (1, 50),
        'worker_pool_size': (1, 16),
        'analytics_max_result_set_size': (1000, 100000),
        # Backup settings
        'backup_retention_days': (7, 365),
        'backup_keep_count': (1, 100),
        'backup_max_size': (50, 10000),
        # Log retention settings
        'log_max_bytes': (1048576, 524288000),
        'log_backup_count': (1, 365),
        'log_rotation_interval': (1, 365),
        'execution_log_retention_days': (1, 365),
        'execution_log_max_files': (0, 10000),
        # Agent throttle settings
        'agent_cpu_nice_level': (-20, 19),
        'agent_min_free_memory_pct': (0, 50),
        'agent_upload_rate_limit': (0, 1000000000),
        'agent_download_rate_limit': (0, 1000000000),
        'agent_max_concurrent_audits': (1, 10),
        'agent_audit_timeout': (60, 86400),
        'agent_command_batch_size': (1, 50),
        'agent_batch_delay': (0, 300),
        'agent_max_load_average': (0, 100),
        'agent_max_cpu_pct': (0, 100),
        'agent_heartbeat_interval': (10, 3600),
        'agent_poll_interval': (10, 3600),
        'agent_local_result_max_files': (0, 1000000),
        'agent_local_min_free_disk_mb': (64, 1048576),
        'agent_local_min_free_disk_pct': (1, 95),
        'standalone_agent_result_max_files_per_host': (0, 1000000),
        'fleet_agent_result_max_files_per_host': (0, 1000000),
        'agent_result_ingest_max_body_kb': (128, 102400),
        'agent_result_ingest_max_results_per_request': (1, 10000),
        'agent_result_ingest_max_checks_per_result': (1, 10000),
        'agent_result_ingest_max_output_chars': (1000, 5000000),
        'agent_result_ingest_min_free_disk_mb': (128, 1048576),
        'agent_result_ingest_min_free_disk_pct': (1, 50),
        'agent_discovery_ingest_max_body_kb': (128, 102400),
        'agent_discovery_ingest_max_items_per_collection': (10, 500000),
        'agent_discovery_ingest_max_total_items': (100, 1000000),
        # Agent security settings
        'agent_api_key_rotation_days': (0, 365),  # 0 = disabled
        'agent_api_key_grace_period_hours': (0, 168),  # Max 1 week grace period
        'fleet_agent_config_max_age_seconds': (30, 86400),
        'fleet_agent_request_signature_max_age_seconds': (30, 3600),
        # Agent upload endpoint rate limits (per hour)
        'standalone_agent_results_rate_limit_per_hour': (10, 1000000),
        'fleet_agent_results_rate_limit_per_hour': (10, 1000000),
        'hypervisor_agent_results_rate_limit_per_hour': (10, 1000000),
        'asset_discovery_results_rate_limit_per_hour': (10, 1000000),
        # Asset Discovery Service Rate Limits (per minute)
        'asset_discovery_api_rate_limit_per_minute': (10, 10000),
        'asset_discovery_scan_rate_limit_per_minute': (5, 1000),
        'asset_discovery_cve_sync_rate_limit_per_minute': (1, 100),
        'asset_discovery_dashboard_rate_limit_per_minute': (10, 1000),
        # Authentication Rate Limits (per minute) - Security-Critical
        'auth_login_rate_limit_per_minute': (1, 60),
        'auth_password_reset_rate_limit_per_minute': (1, 30),
        'auth_registration_rate_limit_per_minute': (1, 30),
        'auth_2fa_rate_limit_per_minute': (1, 60),
        # API Operation Rate Limits (per minute)
        'api_general_rate_limit_per_minute': (10, 1000),
        'api_write_rate_limit_per_minute': (5, 500),
        'api_export_rate_limit_per_minute': (1, 100),
        'api_import_rate_limit_per_minute': (1, 50),
        'api_search_rate_limit_per_minute': (10, 500),
        # Scheduled Operations Rate Limits (per minute)
        'schedule_list_rate_limit_per_minute': (10, 500),
        'schedule_create_rate_limit_per_minute': (5, 100),
        'schedule_run_rate_limit_per_minute': (1, 60),
        'report_generate_rate_limit_per_minute': (1, 60),
        # Agent Communication Rate Limits (per minute)
        'agent_heartbeat_rate_limit_per_minute': (5, 120),
        'agent_command_poll_rate_limit_per_minute': (5, 120),
        'agent_registration_rate_limit_per_minute': (1, 30),
        # Audit Execution Rate Limits (per minute)
        'audit_start_rate_limit_per_minute': (1, 60),
        'audit_status_rate_limit_per_minute': (10, 300),
    }

    for field, (min_val, max_val) in int_fields.items():
        if field in settings:
            try:
                val = int(settings[field])
                validated[field] = max(min_val, min(max_val, val))
            except (ValueError, TypeError):
                validated[field] = defaults[field]
        else:
            validated[field] = defaults.get(field)

    # Boolean fields
    bool_fields = [
        'enforce_2fa', 'password_uppercase', 'password_numbers',
        'password_special', 'auto_approve_users', 'self_registration',
        'maintenance_mode', 'enforce_https',
        'backup_compress', 'backup_encrypt', 'backup_auto_enabled', 'backup_include_shared_data',
        # Agent security booleans
        'agent_require_approval', 'agent_auto_approve_known_hosts',
        'agent_tls_verify', 'agent_tls_pinning_enabled', 'agent_encrypt_keys_at_rest',
        'fleet_agent_enforce_signed_config',
        'fleet_agent_require_request_signatures',
        'fleet_agent_request_signature_ecdsa_dual_verify_enabled',
        'fleet_agent_result_encryption_enabled',  # Phase 2 encryption-at-rest
        'agent_result_ingest_disk_guard_enabled',
        'evidence_retention_enabled',
        'cleanup_old_executions_enabled', 'cleanup_analytics_history_enabled',
        'postgres_maintenance_enabled', 'postgres_maintenance_vacuum_analyze_enabled',
        # TLS policy booleans
        'tls_certificate_verification', 'tls_strict_mode', 'tls_log_version',
        'server_tls_certificate_chain_installed'
    ]

    for field in bool_fields:
        validated[field] = bool(settings.get(field, defaults.get(field, False)))

    # Enum/choice fields
    if settings.get('default_role') in ['Viewer', 'Operator', 'Analyst']:
        validated['default_role'] = settings['default_role']
    else:
        validated['default_role'] = defaults['default_role']

    if settings.get('log_level') in ['ERROR', 'WARNING', 'INFO', 'DEBUG']:
        validated['log_level'] = settings['log_level']
    else:
        validated['log_level'] = defaults['log_level']

    if settings.get('backup_schedule') in ['daily', 'weekly', 'twice_daily']:
        validated['backup_schedule'] = settings['backup_schedule']
    else:
        validated['backup_schedule'] = defaults['backup_schedule']

    if settings.get('log_rotation_when') in ['midnight', 'h', 'd', 'w0']:
        validated['log_rotation_when'] = settings['log_rotation_when']
    else:
        validated['log_rotation_when'] = defaults['log_rotation_when']

    # Agent priority enum fields
    if settings.get('agent_process_priority') in ['Idle', 'BelowNormal', 'Normal', 'AboveNormal', 'High']:
        validated['agent_process_priority'] = settings['agent_process_priority']
    else:
        validated['agent_process_priority'] = defaults['agent_process_priority']

    # Global SSH host key policy
    if settings.get('ssh_host_key_policy') in ['strict', 'warn', 'auto']:
        validated['ssh_host_key_policy'] = settings['ssh_host_key_policy']
    else:
        validated['ssh_host_key_policy'] = defaults['ssh_host_key_policy']

    if settings.get('agent_io_class') in ['idle', 'best-effort', 'realtime']:
        validated['agent_io_class'] = settings['agent_io_class']
    else:
        validated['agent_io_class'] = defaults['agent_io_class']

    # TLS version enum fields
    if settings.get('tls_minimum_version_toolkit') in ['TLSv1_2', 'TLSv1_3']:
        validated['tls_minimum_version_toolkit'] = settings['tls_minimum_version_toolkit']
    else:
        validated['tls_minimum_version_toolkit'] = defaults['tls_minimum_version_toolkit']

    if settings.get('tls_minimum_version_external') in ['TLSv1_2', 'TLSv1_3']:
        validated['tls_minimum_version_external'] = settings['tls_minimum_version_external']
    else:
        validated['tls_minimum_version_external'] = defaults['tls_minimum_version_external']

    if settings.get('tls_maximum_version') in ['TLSv1_2', 'TLSv1_3']:
        validated['tls_maximum_version'] = settings['tls_maximum_version']
    else:
        validated['tls_maximum_version'] = defaults['tls_maximum_version']

    # Guardrail: min should not exceed max
    tls_order = {'TLSv1_2': 2, 'TLSv1_3': 3}
    if tls_order[validated['tls_minimum_version_toolkit']] > tls_order[validated['tls_maximum_version']]:
        validated['tls_minimum_version_toolkit'] = defaults['tls_minimum_version_toolkit']
    if tls_order[validated['tls_minimum_version_external']] > tls_order[validated['tls_maximum_version']]:
        validated['tls_minimum_version_external'] = defaults['tls_minimum_version_external']

    # String fields (sanitize)
    string_fields = [
        'maintenance_message', 'ip_whitelist', 'ip_blacklist', 'cors_origins',
        'backup_shared_data_paths',
        'agent_tls_pinned_cert_hash', 'tls_cipher_suites', 'fleet_agent_config_signing_key',
        'fleet_agent_request_signing_key', 'fleet_agent_request_signature_ecdsa_public_key',
        'fleet_agent_result_encryption_algorithm', 'fleet_agent_result_encryption_key_derivation',
        'fleet_agent_results_encryption_key_custom',
        'server_tls_certificate_source', 'server_tls_certificate_last_updated',
        'server_tls_certificate_subject', 'server_tls_certificate_issuer',
        'server_tls_certificate_not_before', 'server_tls_certificate_not_after',
        'server_tls_certificate_fingerprint_sha256', 'server_tls_runtime_apply_status',
        'server_tls_runtime_apply_message', 'server_tls_runtime_last_attempt_at'
    ]
    for field in string_fields:
        val = str(settings.get(field, defaults.get(field, '')))
        # SHA256 hash for cert pinning is exactly 64 chars, allow some buffer
        if field == 'agent_tls_pinned_cert_hash':
            max_len = 128
        elif field == 'tls_cipher_suites':
            max_len = 512
        elif field == 'fleet_agent_config_signing_key':
            max_len = 512
        elif field == 'fleet_agent_request_signing_key':
            max_len = 512
        elif field == 'fleet_agent_request_signature_ecdsa_public_key':
            max_len = 8192
        elif field == 'fleet_agent_results_encryption_key_custom':
            max_len = 512  # Base64-encoded key
        elif field == 'server_tls_certificate_fingerprint_sha256':
            max_len = 128
        elif field in ('server_tls_certificate_subject', 'server_tls_certificate_issuer'):
            max_len = 4096
        else:
            max_len = 1000
        validated[field] = val[:max_len]

    # Enum validation for encryption algorithm
    if settings.get('fleet_agent_result_encryption_algorithm') in ['fernet-aes128']:
        validated['fleet_agent_result_encryption_algorithm'] = settings['fleet_agent_result_encryption_algorithm']
    else:
        validated['fleet_agent_result_encryption_algorithm'] = defaults['fleet_agent_result_encryption_algorithm']

    # Enum validation for encryption key derivation
    if settings.get('fleet_agent_result_encryption_key_derivation') in ['agent_id', 'shared', 'custom']:
        validated['fleet_agent_result_encryption_key_derivation'] = settings['fleet_agent_result_encryption_key_derivation']
    else:
        validated['fleet_agent_result_encryption_key_derivation'] = defaults['fleet_agent_result_encryption_key_derivation']

    managed_config_signing_key = str(validated.get('fleet_agent_config_signing_key', '') or '').strip()
    if not managed_config_signing_key:
        managed_config_signing_key = os.environ.get('FLEET_AGENT_CONFIG_SIGNING_KEY', '').strip()

    if validated.get('fleet_agent_enforce_signed_config') and not managed_config_signing_key:
        raise ValueError('fleet_agent_config_signing_key is required when managed signed-config enforcement is enabled')

    managed_request_signing_key = str(validated.get('fleet_agent_request_signing_key', '') or '').strip()
    if not managed_request_signing_key:
        managed_request_signing_key = os.environ.get('FLEET_AGENT_REQUEST_SIGNING_KEY', '').strip()

    if validated.get('fleet_agent_require_request_signatures') and not managed_request_signing_key:
        raise ValueError('fleet_agent_request_signing_key is required when managed request-signature enforcement is enabled')

    if validated.get('fleet_agent_result_encryption_enabled'):
        # Validate encryption key based on derivation method
        if validated['fleet_agent_result_encryption_key_derivation'] == 'custom':
            if not validated.get('fleet_agent_results_encryption_key_custom', '').strip():
                raise ValueError('fleet_agent_results_encryption_key_custom is required when using custom key derivation')
        # For agent_id and shared derivation, we generate/use default keys at runtime
        # so no validation is needed here

    return validated


# =============================================================================
# Helper Functions
# =============================================================================

def user_to_dict(user):
    """Convert user to dictionary for JSON serialization"""
    return {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'display_name': user.display_name,
        'role': user.role,
        'auth_provider': user.auth_provider,
        'is_active': user.is_active,
        'is_locked': user.is_locked,
        'locked_until': user.locked_until.isoformat() if user.locked_until else None,
        'mfa_enabled': user.mfa_enabled,
        'must_change_password': user.must_change_password,
        'last_login': user.last_login.isoformat() if user.last_login else None,
        'created_at': user.created_at.isoformat() if user.created_at else None,
        'updated_at': user.updated_at.isoformat() if user.updated_at else None
    }


# =============================================================================
# Email Settings Management
# =============================================================================

def load_app_settings():
    """Load application settings from settings.json"""
    from config import ROOT_DIR
    settings_file = ROOT_DIR / 'settings.json'
    if settings_file.exists():
        import json
        return json.loads(settings_file.read_text())
    return {}

def save_app_settings(settings):
    """Save application settings to settings.json"""
    from config import ROOT_DIR
    import json
    settings_file = ROOT_DIR / 'settings.json'
    settings_file.parent.mkdir(parents=True, exist_ok=True)
    settings_file.write_text(json.dumps(settings, indent=2))


@admin_bp.route('/email/settings', methods=['GET'])
@login_required
@require_role('Admin', 'SuperAdmin')
def get_email_settings():
    """
    Get current email/SMTP settings.

    Returns all email configurations (passwords masked).
    """
    try:
        settings = load_app_settings()
        email_settings = settings.get('email', {})

        # Mask secrets
        if email_settings.get('smtp_password'):
            email_settings['smtp_password'] = MASKED_SECRET_VALUE
        if email_settings.get('graph_client_secret'):
            email_settings['graph_client_secret'] = MASKED_SECRET_VALUE

        transport = email_settings.get('transport', 'smtp')
        configured = bool(
            email_settings.get('smtp_host') if transport != 'graph'
            else email_settings.get('graph_tenant_id')
        )

        log_audit(
            action='get_email_settings',
            resource_type='email_settings',
            details={'configured': configured, 'transport': transport},
            success=True
        )

        return jsonify({
            'success': True,
            'email': email_settings,
            'configured': configured
        })

    except Exception as e:
        log_audit(
            action='get_email_settings',
            resource_type='email_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error loading email settings: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/email/settings', methods=['POST'])
@login_required
@require_role('Admin', 'SuperAdmin')
def save_email_settings():
    """
    Save email/SMTP settings.

    Request body:
    {
        "enabled": true,
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "smtp_user": "user@example.com",
        "smtp_password": "password",
        "from_address": "alerts@example.com",
        "to_address": "admin@example.com",
        "notify_on": {
            "failures": true,
            "warnings": false,
            "completion": false
        }
    }
    """
    try:
        data = request.get_json() or {}
        settings = load_app_settings()

        saved_email = settings.get('email', {})
        transport = data.get('transport', 'smtp')

        email_config = {
            'enabled': data.get('enabled', False),
            'transport': transport,
            'smtp_host': data.get('smtp_host', ''),
            'smtp_port': int(data.get('smtp_port', 587)),
            'smtp_user': data.get('smtp_user', ''),
            'from_address': data.get('from_address', ''),
            'to_address': data.get('to_address', ''),
            'graph_tenant_id': data.get('graph_tenant_id', ''),
            'graph_client_id': data.get('graph_client_id', ''),
            'graph_sender_user': data.get('graph_sender_user', ''),
            'graph_from_address': data.get('graph_from_address', ''),
            'notify_on': data.get('notify_on', {
                'failures': True,
                'warnings': False,
                'completion': False
            })
        }

        # Handle SMTP password - only update if not masked
        new_smtp_password = data.get('smtp_password', '')
        if new_smtp_password and new_smtp_password != MASKED_SECRET_VALUE:
            email_config['smtp_password'] = new_smtp_password
        else:
            email_config['smtp_password'] = saved_email.get('smtp_password', '')

        # Handle Graph client secret - only update if not masked
        new_graph_secret = data.get('graph_client_secret', '')
        if new_graph_secret and new_graph_secret != MASKED_SECRET_VALUE:
            email_config['graph_client_secret'] = new_graph_secret
        else:
            email_config['graph_client_secret'] = saved_email.get('graph_client_secret', '')

        settings['email'] = email_config
        save_app_settings(settings)

        logger.info(f"Email settings updated by {current_user.username}")

        log_audit(
            action='save_email_settings',
            resource_type='email_settings',
            details={
                'enabled': email_config.get('enabled', False),
                'transport': transport,
                'smtp_host': email_config.get('smtp_host', '')
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'Email settings saved successfully'
        })

    except Exception as e:
        log_audit(
            action='save_email_settings',
            resource_type='email_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error saving email settings: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/email/test', methods=['POST'])
@login_required
@require_role('Admin', 'SuperAdmin')
def test_email_settings():
    """
    Send a test email using current or provided settings.

    If no body provided, uses saved settings.
    Otherwise uses the provided configuration for testing before saving.
    Supports both SMTP and Microsoft 365 (Graph API) transports.
    """
    from email.message import EmailMessage
    from mail_delivery import load_mail_delivery_config_from_settings, send_email_message, MailDeliveryError

    try:
        data = request.get_json() or {}
        saved = load_app_settings().get('email', {})

        transport = data.get('transport') or saved.get('transport', 'smtp')

        # Build test email_settings dict from POST body, falling back to saved values
        email_settings = {
            'transport': transport,
            'smtp_host': data.get('smtp_host') or saved.get('smtp_host', ''),
            'smtp_port': int(data.get('smtp_port') or saved.get('smtp_port', 587)),
            'smtp_user': data.get('smtp_user') or saved.get('smtp_user', ''),
            'from_address': data.get('from_address') or saved.get('from_address', ''),
            'to_address': data.get('to_address') or saved.get('to_address', ''),
            'graph_tenant_id': data.get('graph_tenant_id') or saved.get('graph_tenant_id', ''),
            'graph_client_id': data.get('graph_client_id') or saved.get('graph_client_id', ''),
            'graph_sender_user': data.get('graph_sender_user') or saved.get('graph_sender_user', ''),
            'graph_from_address': data.get('graph_from_address') or saved.get('graph_from_address', ''),
        }

        # Unmask SMTP password
        smtp_password = data.get('smtp_password', '')
        if smtp_password == MASKED_SECRET_VALUE or not smtp_password:
            smtp_password = saved.get('smtp_password', '')
        email_settings['smtp_password'] = smtp_password

        # Unmask Graph client secret
        graph_secret = data.get('graph_client_secret', '')
        if graph_secret == MASKED_SECRET_VALUE or not graph_secret:
            graph_secret = saved.get('graph_client_secret', '')
        email_settings['graph_client_secret'] = graph_secret

        to_addr = email_settings['to_address']
        from_addr = (
            email_settings.get('graph_from_address') if transport == 'graph' else None
        ) or email_settings.get('from_address', '')

        if not to_addr:
            return jsonify({'success': False, 'error': 'No recipient address configured.'}), 400

        # Validate minimum transport requirements
        if transport == 'graph' and not email_settings.get('graph_tenant_id'):
            return jsonify({'success': False, 'error': 'No Microsoft 365 settings configured. Please save settings first.'}), 400
        if transport != 'graph' and not email_settings.get('smtp_host'):
            return jsonify({'success': False, 'error': 'No email settings configured. Please save settings first.'}), 400

        msg = EmailMessage()
        msg['Subject'] = '🔐 Security Audit Toolkit - Test Email'
        msg['From'] = from_addr
        msg['To'] = to_addr
        msg.set_content(f'''This is a test email from Security Audit Toolkit.

If you received this message, your email notification settings are configured correctly.

Transport: {transport.upper()}
From: {from_addr}
To: {to_addr}

Sent at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
''')

        config = load_mail_delivery_config_from_settings(email_settings)
        send_email_message(msg, config)

        logger.info(f"Test email sent successfully by {current_user.username}")

        log_audit(
            action='test_email_settings',
            resource_type='email_settings',
            details={'transport': transport, 'to_address': to_addr},
            success=True
        )

        return jsonify({
            'success': True,
            'message': f'Test email sent to {to_addr}'
        })

    except MailDeliveryError as e:
        log_audit(
            action='test_email_settings',
            resource_type='email_settings',
            success=False,
            error=str(e)
        )
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        log_audit(
            action='test_email_settings',
            resource_type='email_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error sending test email: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/email/delete', methods=['DELETE'])
@login_required
@require_role('Admin', 'SuperAdmin')
def delete_email_settings():
    """
    Remove/clear email settings.
    """
    try:
        settings = load_app_settings()
        settings['email'] = {}
        save_app_settings(settings)

        logger.info(f"Email settings deleted by {current_user.username}")

        log_audit(
            action='delete_email_settings',
            resource_type='email_settings',
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'Email settings removed'
        })

    except Exception as e:
        log_audit(
            action='delete_email_settings',
            resource_type='email_settings',
            success=False,
            error=str(e)
        )
        logger.error(f"Error deleting email settings: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# API Key Management (SuperAdmin)
# =============================================================================

@admin_bp.route('/api-keys/list', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def list_api_keys():
    """
    List all API keys managed by the toolkit.

    Returns all keys from the encrypted keystore (system, agent, custom, hypervisor).
    Falls back to legacy storage for backward compatibility.
    """
    try:
        keys = []

        # Try to load from encrypted keystore first
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            # Get all keys from keystore
            keystore_keys = keystore.list_keys()
            for key_info in keystore_keys:
                key_metadata = key_info.get('metadata', {})
                keys.append({
                    'id': f"{key_info['key_type']}_{key_info['key_id']}",
                    'name': key_metadata.get('name', f"{key_info['key_type_name']}: {key_info['key_id']}"),
                    'type': key_info['key_type'],
                    'type_name': key_info['key_type_name'],
                    'description': key_metadata.get('description', ''),
                    'key_preview': key_info['preview'],
                    'created': key_info.get('created_at'),
                    'updated': key_info.get('updated_at'),
                    'created_by': key_info.get('created_by'),
                    'status': 'expired' if key_metadata.get('expires') and datetime.fromisoformat(key_metadata['expires']) < datetime.now() else 'active',
                    'scope': key_metadata.get('scope', ['all']),
                    'expires': key_metadata.get('expires'),
                    'rate_limit_per_minute': key_metadata.get('rate_limit_per_minute'),
                    'encrypted': True
                })

            # If keystore has keys, return them
            if keys:
                # Also include hypervisor agent keys
                try:
                    from web.api.hypervisor_agent_routes import get_all_hypervisor_agent_keys
                    hypervisor_keys = get_all_hypervisor_agent_keys()
                    keys.extend(hypervisor_keys)
                except Exception as hypervisor_key_error:
                    logger.debug(f"Unable to load hypervisor agent keys from API key view: {hypervisor_key_error}")

                # Also include managed server agent keys
                try:
                    from web.api.agent_fleet_routes import get_all_fleet_agent_keys
                    managed_keys = get_all_fleet_agent_keys()
                    keys.extend(managed_keys)
                except Exception as managed_key_error:
                    logger.debug(f"Unable to load fleet agent keys from API key view: {managed_key_error}")

                # Calculate stats
                total = len(keys)
                active = sum(1 for k in keys if k.get('status') in ('active', 'online'))
                agent_count = sum(1 for k in keys if k.get('type') == 'agent')
                hypervisor_count = sum(1 for k in keys if k.get('type') == 'hypervisor_agent')
                expired = sum(1 for k in keys if k.get('status') == 'expired')
                revoked = sum(1 for k in keys if k.get('status') == 'revoked')

                log_audit(
                    action='list_api_keys',
                    resource_type='api_key',
                    details={
                        'total': total,
                        'active': active,
                        'storage': 'encrypted_keystore'
                    },
                    success=True
                )

                return jsonify({
                    'success': True,
                    'keys': keys,
                    'total': total,
                    'active': active,
                    'agent_keys': agent_count,
                    'hypervisor_keys': hypervisor_count,
                    'expired': expired,
                    'revoked': revoked,
                    'storage': 'encrypted_keystore'
                })

        except ImportError:
            logger.debug("Keystore module not available, using legacy storage")
        except Exception as e:
            logger.warning(f"Could not load from keystore: {e}, falling back to legacy")

        # Fallback to legacy storage (for backward compatibility)
        from config import ROOT_DIR

        # Get system API key info (legacy file)
        api_key_file = ROOT_DIR / 'settings' / 'api_key.txt'
        system_key_info = {
            'id': 'system',
            'name': 'System API Key',
            'type': 'system',
            'description': 'Primary API key for authentication',
            'created': None,
            'expires': None,
            'last_used': None,
            'status': 'active',
            'scope': ['all'],
            'encrypted': False
        }

        if api_key_file.exists():
            stat = api_key_file.stat()
            system_key_info['created'] = datetime.fromtimestamp(stat.st_ctime).isoformat()
            system_key_info['key_preview'] = '****' + api_key_file.read_text().strip()[-4:]

        keys.append(system_key_info)

        # Get agent API keys from security settings
        from security_settings import get_all_security_settings
        settings = get_all_security_settings()
        agent_keys = settings.get('agent_api_keys', [])

        if isinstance(agent_keys, str):
            agent_keys = [k.strip() for k in agent_keys.split(',') if k.strip()]

        for i, key in enumerate(agent_keys):
            keys.append({
                'id': f'agent_{i}',
                'name': f'Agent API Key {i + 1}',
                'type': 'agent',
                'description': 'API key for standalone agents',
                'key_preview': '****' + key[-4:] if len(key) > 4 else '****',
                'status': 'active',
                'scope': ['agent'],
                'encrypted': False
            })

        # Get custom API keys from settings
        custom_keys = settings.get('custom_api_keys', [])
        for key_info in custom_keys:
            keys.append({
                'id': key_info.get('id'),
                'name': key_info.get('name', 'Custom Key'),
                'type': 'custom',
                'description': key_info.get('description', ''),
                'key_preview': '****' + key_info.get('key', '')[-4:] if key_info.get('key') else '****',
                'created': key_info.get('created'),
                'expires': key_info.get('expires'),
                'last_used': key_info.get('last_used'),
                'status': 'expired' if key_info.get('expires') and datetime.fromisoformat(key_info['expires']) < datetime.now() else 'active',
                'scope': key_info.get('scope', ['read']),
                'rate_limit_per_minute': key_info.get('rate_limit_per_minute'),
                'encrypted': False
            })

        # Get hypervisor agent keys (persistent storage)
        try:
            from web.api.hypervisor_agent_routes import get_all_hypervisor_agent_keys
            hypervisor_keys = get_all_hypervisor_agent_keys()
            keys.extend(hypervisor_keys)
        except ImportError:
            logger.debug("Hypervisor agent module not available")
        except Exception as hv_err:
            logger.warning(f"Could not load hypervisor agent keys: {hv_err}")

        # Get managed server agent keys (in-memory registry + keystore-backed tokens)
        try:
            from web.api.agent_fleet_routes import get_all_fleet_agent_keys
            managed_keys = get_all_fleet_agent_keys()
            keys.extend(managed_keys)
        except ImportError:
            logger.debug("Managed agent module not available")
        except Exception as ma_err:
            logger.warning(f"Could not load fleet agent keys: {ma_err}")

        # Calculate stats
        total = len(keys)
        active = sum(1 for k in keys if k.get('status') in ('active', 'online'))
        agent_count = sum(1 for k in keys if k.get('type') == 'agent')
        hypervisor_count = sum(1 for k in keys if k.get('type') == 'hypervisor_agent')
        expired = sum(1 for k in keys if k.get('status') == 'expired')
        revoked = sum(1 for k in keys if k.get('status') == 'revoked')

        log_audit(
            action='list_api_keys',
            resource_type='api_key',
            details={
                'total': total,
                'active': active,
                'storage': 'legacy'
            },
            success=True
        )

        return jsonify({
            'success': True,
            'keys': keys,
            'total': total,
            'active': active,
            'agent_keys': agent_count,
            'hypervisor_keys': hypervisor_count,
            'expired': expired,
            'revoked': revoked,
            'storage': 'legacy'
        })

    except Exception as e:
        log_audit(
            action='list_api_keys',
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error listing API keys: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/create', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def create_api_key():
    """
    Create a new custom API key.

    Stores key in encrypted keystore with fallback to legacy settings.

    Request body:
    {
        "name": "My Integration Key",
        "description": "Key for external monitoring",
        "scope": ["read", "execute"],  // read, write, execute, admin
        "expires_days": 90,  // 0 = no expiration
        "rate_limit_per_minute": 120  // 0/omitted = unlimited
    }
    """
    import secrets
    from security_settings import get_all_security_settings, save_security_settings

    try:
        data = request.get_json() or {}

        name = data.get('name', '').strip()
        if not name:
            return jsonify({'success': False, 'error': 'Key name is required'}), 400

        description = data.get('description', '').strip()
        scope = data.get('scope', ['read'])
        expires_days = int(data.get('expires_days', 0))
        raw_rate_limit = data.get('rate_limit_per_minute', 0)

        try:
            rate_limit_per_minute = int(raw_rate_limit) if raw_rate_limit not in (None, '') else 0
            if rate_limit_per_minute < 0:
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({'success': False, 'error': 'rate_limit_per_minute must be a non-negative integer'}), 400

        # Validate scope
        valid_scopes = ['read', 'write', 'execute', 'admin', 'agent']
        scope = [s for s in scope if s in valid_scopes]
        if not scope:
            scope = ['read']

        # Generate secure API key
        new_key = secrets.token_urlsafe(32)
        key_id = secrets.token_hex(8)

        # Calculate expiration
        expires = None
        if expires_days > 0:
            expires = (datetime.now() + timedelta(days=expires_days)).isoformat()

        storage_method = 'legacy'

        # Try to store in encrypted keystore first
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            keystore.store_key(
                key_type='custom',
                key_id=key_id,
                value=new_key,
                metadata={
                    'name': name,
                    'description': description,
                    'scope': scope,
                    'expires': expires,
                    'rate_limit_per_minute': rate_limit_per_minute or None
                },
                created_by=current_user.username
            )
            storage_method = 'encrypted_keystore'
            logger.info(f"API key '{name}' stored in encrypted keystore by {current_user.username}")

        except ImportError:
            logger.debug("Keystore not available, using legacy storage")
        except Exception as e:
            logger.warning(f"Could not store in keystore: {e}, using legacy storage")

        # Also save to legacy settings for backward compatibility
        if storage_method == 'legacy':
            key_entry = {
                'id': key_id,
                'name': name,
                'description': description,
                'key': new_key,
                'key_hash': secrets.token_hex(16),
                'scope': scope,
                'created': datetime.now().isoformat(),
                'expires': expires,
                'rate_limit_per_minute': rate_limit_per_minute,
                'last_used': None,
                'created_by': current_user.username
            }

            settings = get_all_security_settings()
            custom_keys = settings.get('custom_api_keys', [])
            custom_keys.append(key_entry)
            settings['custom_api_keys'] = custom_keys
            save_security_settings(settings)

        logger.info(f"API key created: {name} by {current_user.username}")

        log_audit(
            action='create_api_key',
            resource_id=str(key_id),
            resource_type='api_key',
            details={
                'name': name,
                'scope': scope,
                'rate_limit_per_minute': rate_limit_per_minute,
                'storage': storage_method
            },
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'API key created successfully',
            'key': {
                'id': key_id,
                'name': name,
                'api_key': new_key,  # Only shown once at creation
                'scope': scope,
                'expires': expires,
                'rate_limit_per_minute': rate_limit_per_minute
            },
            'storage': storage_method,
            'encrypted': storage_method == 'encrypted_keystore',
            'warning': 'Copy this key now - it will not be shown again!'
        })

    except Exception as e:
        log_audit(
            action='create_api_key',
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error creating API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/<key_id>', methods=['DELETE'])
@login_required
@require_role('SuperAdmin')
def revoke_api_key(key_id):
    """
    Revoke (delete) an API key.

    Removes key from encrypted keystore with fallback to legacy storage.
    System key cannot be deleted, only regenerated.
    """
    from security_settings import get_all_security_settings, save_security_settings

    try:
        if key_id == 'system':
            return jsonify({
                'success': False,
                'error': 'System key cannot be deleted. Use regenerate instead.'
            }), 400

        # Try to delete from encrypted keystore first
        keystore_deleted = False
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            # Parse key type from ID format (e.g., "custom_abc123")
            if '_' in key_id and not key_id.startswith('agent_') and not key_id.startswith('hypervisor_'):
                key_type, actual_id = key_id.split('_', 1)
                if keystore.delete_key(key_type, actual_id):
                    keystore_deleted = True
                    logger.info(f"Key {key_id} deleted from encrypted keystore by {current_user.username}")
                    return jsonify({
                        'success': True,
                        'message': 'API key revoked successfully',
                        'storage': 'encrypted_keystore'
                    })
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"Keystore delete attempt: {e}")

        settings = get_all_security_settings()

        # Check if it's an agent key
        if key_id.startswith('agent_'):
            idx = int(key_id.replace('agent_', ''))
            agent_keys = settings.get('agent_api_keys', [])
            if isinstance(agent_keys, str):
                agent_keys = [k.strip() for k in agent_keys.split(',') if k.strip()]

            if idx < len(agent_keys):
                del agent_keys[idx]
                settings['agent_api_keys'] = agent_keys
                save_security_settings(settings)
                logger.info(f"Agent API key {idx} revoked by {current_user.username}")
                return jsonify({'success': True, 'message': 'Agent API key revoked'})
            else:
                return jsonify({'success': False, 'error': 'Agent key not found'}), 404

        # Check if it's a hypervisor agent key
        if key_id.startswith('hypervisor_'):
            agent_id = key_id.replace('hypervisor_', '')
            try:
                from web.api.hypervisor_agent_routes import revoke_hypervisor_agent_key
                result = revoke_hypervisor_agent_key(agent_id, revoked_by=current_user.username)
                if result['success']:
                    logger.info(f"Hypervisor agent key {agent_id} revoked by {current_user.username}")
                    return jsonify({'success': True, 'message': 'Hypervisor agent key revoked'})
                else:
                    return jsonify({'success': False, 'error': result.get('error', 'Unknown error')}), 404
            except ImportError:
                return jsonify({'success': False, 'error': 'Hypervisor agent module not available'}), 500
            except Exception as hv_err:
                logger.error(f"Error revoking hypervisor agent key: {hv_err}")
                return jsonify({'success': False, 'error': str(hv_err)}), 500

        # Check custom keys in legacy storage
        custom_keys = settings.get('custom_api_keys', [])
        key_found = False

        for i, key in enumerate(custom_keys):
            if key.get('id') == key_id:
                del custom_keys[i]
                key_found = True
                break

        if not key_found:
            return jsonify({'success': False, 'error': 'API key not found'}), 404

        settings['custom_api_keys'] = custom_keys
        save_security_settings(settings)

        logger.info(f"Custom API key {key_id} revoked by {current_user.username}")

        log_audit(
            action='revoke_api_key',
            resource_id=str(key_id),
            resource_type='api_key',
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'API key revoked successfully'
        })

    except Exception as e:
        log_audit(
            action='revoke_api_key',
            resource_id=str(key_id),
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error revoking API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/system/regenerate', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def regenerate_system_api_key():
    """
    Regenerate the system API key.

    Stores new key in encrypted keystore with legacy file fallback.
    WARNING: This invalidates all existing sessions using the old key.
    """
    from config import ROOT_DIR

    try:
        api_key_file = ROOT_DIR / 'settings' / 'api_key.txt'

        storage_method = 'legacy'

        # Backup old key
        if api_key_file.exists():
            old_key = api_key_file.read_text().strip()
            backup_file = ROOT_DIR / 'settings' / f'api_key.backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'
            backup_file.write_text(old_key)
            logger.info("Old system API key backed up")

        # Regenerate through auth manager so in-memory validation key is updated immediately
        from auth_core import get_api_key_manager
        api_key_manager = get_api_key_manager()
        new_key = api_key_manager.regenerate_key()

        # Determine storage mode for response visibility
        try:
            from keystore import get_keystore
            keystore = get_keystore()
            if keystore.get_key('system', 'api_key'):
                storage_method = 'encrypted_keystore'
        except Exception:
            storage_method = 'legacy'

        # Always write to legacy file for backward compatibility
        api_key_file.parent.mkdir(parents=True, exist_ok=True)
        api_key_file.write_text(new_key)

        logger.warning(f"System API key regenerated by {current_user.username}")

        log_audit(
            action='regenerate_system_api_key',
            resource_type='api_key',
            details={'storage': storage_method},
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'System API key regenerated',
            'api_key': new_key,
            'storage': storage_method,
            'encrypted': storage_method == 'encrypted_keystore',
            'warning': 'All existing sessions have been invalidated'
        })

    except Exception as e:
        log_audit(
            action='regenerate_system_api_key',
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error regenerating system API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/agent/add', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def add_agent_api_key():
    """
    Add a new agent API key for standalone agents.

    Stores key in encrypted keystore with fallback to legacy settings.

    Request body:
    {
        "key": "optional-custom-key",  // If not provided, generates random key
        "description": "For server group A"
    }
    """
    import secrets
    from security_settings import get_all_security_settings, save_security_settings

    try:
        data = request.get_json() or {}

        custom_key = data.get('key', '').strip()
        description = data.get('description', '').strip()

        if not custom_key:
            custom_key = secrets.token_urlsafe(32)

        # Validate key format
        if len(custom_key) < 16:
            return jsonify({
                'success': False,
                'error': 'API key must be at least 16 characters'
            }), 400

        key_id = secrets.token_hex(8)
        storage_method = 'legacy'

        # Try to store in encrypted keystore first
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            keystore.store_key(
                key_type='agent',
                key_id=key_id,
                value=custom_key,
                metadata={
                    'description': description,
                    'scope': ['agent']
                },
                created_by=current_user.username
            )
            storage_method = 'encrypted_keystore'
            logger.info(f"Agent API key stored in encrypted keystore by {current_user.username}")

        except ImportError:
            logger.debug("Keystore not available, using legacy storage")
        except Exception as e:
            logger.warning(f"Could not store in keystore: {e}, using legacy storage")

        # Also save to legacy storage for backward compatibility
        if storage_method == 'legacy':
            settings = get_all_security_settings()
            agent_keys = settings.get('agent_api_keys', [])

            if isinstance(agent_keys, str):
                agent_keys = [k.strip() for k in agent_keys.split(',') if k.strip()]

            # Check for duplicates
            if custom_key in agent_keys:
                return jsonify({
                    'success': False,
                    'error': 'This API key already exists'
                }), 400

            agent_keys.append(custom_key)
            settings['agent_api_keys'] = agent_keys
            save_security_settings(settings)

        logger.info(f"Agent API key added by {current_user.username}")

        log_audit(
            action='add_agent_api_key',
            resource_id=str(key_id),
            resource_type='api_key',
            details={'storage': storage_method},
            success=True
        )

        return jsonify({
            'success': True,
            'message': 'Agent API key added',
            'api_key': custom_key,
            'key_id': key_id,
            'storage': storage_method,
            'encrypted': storage_method == 'encrypted_keystore'
        })

    except Exception as e:
        log_audit(
            action='add_agent_api_key',
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error adding agent API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/hypervisor/<agent_id>/rotate', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def rotate_hypervisor_agent_key(agent_id):
    """
    Rotate API key for a hypervisor agent.

    Generates a new key and returns it (shown only once).
    The agent must be updated with the new key.
    """
    try:
        from web.api.hypervisor_agent_routes import rotate_hypervisor_agent_key as do_rotation

        result = do_rotation(agent_id, rotated_by=current_user.username)

        if result['success']:
            logger.info(f"Hypervisor agent key rotated for {agent_id} by {current_user.username}")
            log_audit(
                action='rotate_hypervisor_agent_key',
                resource_id=str(agent_id),
                resource_type='api_key',
                success=True
            )
            return jsonify({
                'success': True,
                'message': 'Key rotated successfully',
                'new_key': result.get('new_key'),
                'agent_id': agent_id,
                'warning': 'Copy this key now - it will not be shown again!'
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', 'Unknown error')
            }), 404

    except ImportError:
        log_audit(
            action='rotate_hypervisor_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error='Hypervisor agent module not available'
        )
        return jsonify({
            'success': False,
            'error': 'Hypervisor agent module not available'
        }), 500
    except Exception as e:
        log_audit(
            action='rotate_hypervisor_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error rotating hypervisor agent key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/hypervisor/<agent_id>', methods=['DELETE'])
@login_required
@require_role('SuperAdmin')
def delete_or_revoke_hypervisor_agent(agent_id):
    """
    Delete or revoke hypervisor agent key.

    If request body contains {"permanent": true}, the agent is completely deleted.
    Otherwise, only the key is revoked (agent can be re-keyed later).
    """
    try:
        data = request.get_json() or {}
        permanent = data.get('permanent', False)

        if permanent:
            # Permanently delete the agent
            from web.api.hypervisor_agent_routes import delete_hypervisor_agent as do_delete

            result = do_delete(agent_id, deleted_by=current_user.username)

            if result['success']:
                logger.info(f"Hypervisor agent {agent_id} permanently deleted by {current_user.username}")
                log_audit(
                    action='delete_hypervisor_agent',
                    resource_id=str(agent_id),
                    resource_type='api_key',
                    details={'permanent': True},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'message': result.get('message', 'Agent deleted permanently')
                })
            else:
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Unknown error')
                }), 404
        else:
            # Just revoke the key
            from web.api.hypervisor_agent_routes import revoke_hypervisor_agent_key

            result = revoke_hypervisor_agent_key(agent_id, revoked_by=current_user.username)

            if result['success']:
                logger.info(f"Hypervisor agent key {agent_id} revoked by {current_user.username}")
                log_audit(
                    action='revoke_hypervisor_agent_key',
                    resource_id=str(agent_id),
                    resource_type='api_key',
                    details={'permanent': False},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'message': result.get('message', 'Agent key revoked')
                })
            else:
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Unknown error')
                }), 404

    except ImportError:
        log_audit(
            action='manage_hypervisor_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error='Hypervisor agent module not available'
        )
        return jsonify({
            'success': False,
            'error': 'Hypervisor agent module not available'
        }), 500
    except Exception as e:
        log_audit(
            action='manage_hypervisor_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error managing hypervisor agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Managed Server Agent Key Management (SuperAdmin)
# =============================================================================

@admin_bp.route('/api-keys/fleet-agent/<agent_id>/rotate', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def rotate_fleet_agent_key(agent_id):
    """
    Rotate API key for a managed server agent.

    Generates a new key and returns it (shown only once).
    The agent must be updated with the new key.
    """
    try:
        from web.api.agent_fleet_routes import rotate_fleet_agent_key as do_rotation

        result = do_rotation(agent_id, rotated_by=current_user.username)

        if result['success']:
            logger.info(f"Managed agent key rotated for {agent_id} by {current_user.username}")
            log_audit(
                action='rotate_fleet_agent_key',
                resource_id=str(agent_id),
                resource_type='api_key',
                success=True
            )
            return jsonify({
                'success': True,
                'message': 'Key rotated successfully',
                'new_key': result.get('new_key'),
                'agent_id': agent_id,
                'expires': result.get('expires'),
                'warning': 'Copy this key now - it will not be shown again!'
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', 'Unknown error')
            }), 404

    except ImportError:
        log_audit(
            action='rotate_fleet_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error='Managed agent module not available'
        )
        return jsonify({
            'success': False,
            'error': 'Managed agent module not available'
        }), 500
    except Exception as e:
        log_audit(
            action='rotate_fleet_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error rotating fleet agent key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api-keys/fleet-agent/<agent_id>', methods=['DELETE'])
@login_required
@require_role('SuperAdmin')
def delete_or_revoke_fleet_agent(agent_id):
    """
    Delete or revoke managed server agent key.

    If request body contains {"permanent": true}, the agent is completely deleted.
    Otherwise, only the key is revoked (agent can be re-keyed later).
    """
    try:
        data = request.get_json() or {}
        permanent = data.get('permanent', False)

        if permanent:
            # Permanently delete the agent
            from web.api.agent_fleet_routes import delete_fleet_agent as do_delete

            result = do_delete(agent_id, deleted_by=current_user.username)

            if result['success']:
                logger.info(f"Managed agent {agent_id} permanently deleted by {current_user.username}")
                log_audit(
                    action='delete_fleet_agent',
                    resource_id=str(agent_id),
                    resource_type='api_key',
                    details={'permanent': True},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'message': result.get('message', 'Agent deleted permanently')
                })
            else:
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Unknown error')
                }), 404
        else:
            # Just revoke the key
            from web.api.agent_fleet_routes import revoke_fleet_agent_key

            result = revoke_fleet_agent_key(agent_id, revoked_by=current_user.username)

            if result['success']:
                logger.info(f"Managed agent key {agent_id} revoked by {current_user.username}")
                log_audit(
                    action='revoke_fleet_agent_key',
                    resource_id=str(agent_id),
                    resource_type='api_key',
                    details={'permanent': False},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'message': result.get('message', 'Agent key revoked')
                })
            else:
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Unknown error')
                }), 404

    except ImportError:
        log_audit(
            action='manage_fleet_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error='Managed agent module not available'
        )
        return jsonify({
            'success': False,
            'error': 'Managed agent module not available'
        }), 500
    except Exception as e:
        log_audit(
            action='manage_fleet_agent_key',
            resource_id=str(agent_id),
            resource_type='api_key',
            success=False,
            error=str(e)
        )
        logger.error(f"Error managing fleet agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# SSH Key Management (SuperAdmin)
# =============================================================================

@admin_bp.route('/api-keys', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def api_keys_page():
    """API key management page for SuperAdmin"""
    return render_template('admin/api_keys.html')


@admin_bp.route('/ssh-keys', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def ssh_keys_page():
    """SSH key management page for SuperAdmin"""
    return render_template('admin/ssh_keys.html')


@admin_bp.route('/ssh-keys/list', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def list_ssh_keys():
    """
    List existing SSH keys managed by the audit toolkit
    """
    import platform
    from config import SSH_DIR

    try:
        # Use the configured SSH_DIR from config (ROOT_DIR/.ssh)
        # This works correctly in Docker (/opt/audit-toolkit/.ssh)
        ssh_dir = SSH_DIR

        keys = []

        if ssh_dir.exists():
            # Find all private keys (files without .pub extension, no dots in stem)
            for item in ssh_dir.iterdir():
                if item.is_file() and not item.name.endswith('.pub'):
                    pub_key_path = ssh_dir / f"{item.name}.pub"

                    # Check if corresponding public key exists
                    if pub_key_path.exists():
                        # Determine key type by reading public key
                        key_type = "unknown"
                        try:
                            pub_content = pub_key_path.read_text().strip()
                            if pub_content.startswith('ssh-ed25519'):
                                key_type = 'ed25519'
                            elif pub_content.startswith('ssh-rsa'):
                                key_type = 'rsa'
                            elif pub_content.startswith('ecdsa-'):
                                key_type = 'ecdsa'
                        except Exception as key_read_err:  # noqa: B110 - non-critical
                            logger.debug(f"Could not determine key type for {item.name}: {key_read_err}")

                        # Get file stats
                        stat = item.stat()

                        keys.append({
                            'name': item.name,
                            'type': key_type,
                            'private_path': str(item),
                            'public_path': str(pub_key_path),
                            'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                            'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                            'size': stat.st_size
                        })

        return jsonify({
            'success': True,
            'ssh_dir': str(ssh_dir),
            'platform': platform.system(),
            'keys': keys
        })

    except Exception as e:
        logger.error(f"Error listing SSH keys: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/generate', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def generate_ssh_key():
    """
    Generate a new SSH key pair for the audit toolkit

    This is a SuperAdmin task for initial setup when deploying the tool.
    Works on both Windows and Linux platforms.

    Request body:
    {
        "key_name": "audit-toolkit",  // Name for the key file
        "key_type": "ed25519",  // ed25519 (recommended), rsa, ecdsa
        "key_bits": 4096,  // Only for RSA
        "passphrase": "",  // Optional passphrase (empty for no passphrase)
        "comment": "Audit Toolkit Key"  // Key comment
    }
    """
    import os
    import platform
    import shutil
    from config import SSH_DIR

    try:
        data = request.get_json() or {}

        key_name = data.get('key_name', 'audit-toolkit')
        key_type = data.get('key_type', 'ed25519')
        key_bits = int(data.get('key_bits', 4096))
        passphrase = data.get('passphrase', '')
        comment = data.get('comment', f'Audit Toolkit Key - {datetime.now().strftime("%Y-%m-%d")}')

        # Validate key type
        if key_type not in ['ed25519', 'rsa', 'ecdsa']:
            return jsonify({
                'success': False,
                'error': 'Invalid key_type. Use: ed25519, rsa, or ecdsa'
            }), 400

        # Validate key bits for RSA
        if key_type == 'rsa' and key_bits < 2048:
            return jsonify({
                'success': False,
                'error': 'RSA key must be at least 2048 bits'
            }), 400

        # Sanitize key name
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:50]
        if not key_name:
            key_name = 'audit-toolkit'

        # Use the configured SSH_DIR from config (ROOT_DIR/.ssh)
        # This works correctly in Docker (/opt/audit-toolkit/.ssh)
        # and on Windows/Linux native installs
        ssh_dir = SSH_DIR

        # Create .ssh directory if it doesn't exist
        # Note: mode=0o700 is ignored on Windows (uses ACLs instead)
        try:
            ssh_dir.mkdir(mode=0o700, exist_ok=True)
        except PermissionError:
            return jsonify({
                'success': False,
                'error': f'Permission denied creating SSH directory: {ssh_dir}'
            }), 500

        private_key_path = ssh_dir / key_name
        public_key_path = ssh_dir / f"{key_name}.pub"

        # Check if key already exists
        if private_key_path.exists():
            # Backup existing key
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_private = ssh_dir / f"{key_name}.backup_{timestamp}"
            backup_public = ssh_dir / f"{key_name}.pub.backup_{timestamp}"

            shutil.move(str(private_key_path), str(backup_private))
            if public_key_path.exists():
                shutil.move(str(public_key_path), str(backup_public))

            logger.info(f"Backed up existing key to {backup_private}")

        # Find ssh-keygen
        ssh_keygen = shutil.which('ssh-keygen')
        if not ssh_keygen:
            # Try common locations on Linux and Windows
            common_paths = [
                # Linux/Unix paths
                '/usr/bin/ssh-keygen',
                '/usr/local/bin/ssh-keygen',
                # Windows OpenSSH (built-in feature)
                'C:\\Windows\\System32\\OpenSSH\\ssh-keygen.exe',
                # Windows OpenSSH (optional feature install location)
                os.path.expandvars('%ProgramFiles%\\OpenSSH\\ssh-keygen.exe'),
                # Git for Windows (common install)
                'C:\\Program Files\\Git\\usr\\bin\\ssh-keygen.exe',
                'C:\\Program Files (x86)\\Git\\usr\\bin\\ssh-keygen.exe',
                # Git for Windows (user install)
                os.path.expandvars('%LOCALAPPDATA%\\Programs\\Git\\usr\\bin\\ssh-keygen.exe'),
            ]
            for path in common_paths:
                if os.path.isfile(path):
                    ssh_keygen = path
                    break

        if not ssh_keygen:
            if platform.system() == 'Windows':
                error_msg = (
                    'ssh-keygen not found. Install OpenSSH: '
                    'Settings > Apps > Optional Features > Add a feature > OpenSSH Client. '
                    'Alternatively, install Git for Windows which includes ssh-keygen.'
                )
            else:
                error_msg = 'ssh-keygen not found. Install openssh-client package.'
            return jsonify({
                'success': False,
                'error': error_msg
            }), 500

        # Build ssh-keygen command
        keygen_cmd = [
            ssh_keygen,
            '-t', key_type,
            '-f', str(private_key_path),
            '-N', passphrase,
            '-C', comment,
            '-q'  # Quiet mode
        ]

        # Add bits for RSA
        if key_type == 'rsa':
            keygen_cmd.extend(['-b', str(key_bits)])

        # Run ssh-keygen
        logger.info(f"Generating {key_type} SSH key: {private_key_path}")
        result = subprocess.run(
            keygen_cmd,
            capture_output=True,
            text=True,
            timeout=30,
            check=False
        )  # nosec B603

        if result.returncode != 0:
            error_msg = result.stderr or result.stdout or 'Key generation failed'
            logger.error(f"ssh-keygen failed: {error_msg}")
            return jsonify({
                'success': False,
                'error': f'Key generation failed: {error_msg}'
            }), 500

        # Verify key was created
        if not private_key_path.exists() or not public_key_path.exists():
            return jsonify({
                'success': False,
                'error': 'Key files were not created'
            }), 500

        # Set correct permissions (especially important on Linux)
        if platform.system() != 'Windows':
            os.chmod(str(private_key_path), 0o600)
            os.chmod(str(public_key_path), 0o644)

        # Read public key for display
        public_key_content = public_key_path.read_text().strip()

        # Get key fingerprint
        fingerprint = None
        try:
            fp_result = subprocess.run(
                [ssh_keygen, '-l', '-f', str(public_key_path)],
                capture_output=True,
                text=True,
                timeout=10,
                check=False
            )  # nosec B603
            if fp_result.returncode == 0:
                fingerprint = fp_result.stdout.strip()
        except Exception as fp_err:  # noqa: B110 - intentionally non-critical
            logger.debug(f"Could not get key fingerprint: {fp_err}")

        logger.info(f"SSH key generated successfully: {key_name} ({key_type})")

        return jsonify({
            'success': True,
            'message': 'SSH key pair generated successfully',
            'key': {
                'name': key_name,
                'type': key_type,
                'bits': key_bits if key_type == 'rsa' else None,
                'private_path': str(private_key_path),
                'public_path': str(public_key_path),
                'public_key': public_key_content,
                'fingerprint': fingerprint,
                'has_passphrase': bool(passphrase),
                'comment': comment
            },
            'instructions': {
                'deploy': 'Copy the public key to target servers ~/.ssh/authorized_keys',
                'use_in_toolkit': f'When adding servers, select key authentication and use path: {private_key_path}',
                'command': f'ssh-copy-id -i {public_key_path} user@hostname' if platform.system() != 'Windows' else f'type "{public_key_path}" | ssh user@hostname "cat >> ~/.ssh/authorized_keys"',
                'windows_powershell': f'Get-Content "{public_key_path}" | ssh user@hostname "cat >> ~/.ssh/authorized_keys"' if platform.system() == 'Windows' else None
            },
            'platform': platform.system(),
            'ssh_dir': str(ssh_dir)
        })

    except subprocess.TimeoutExpired:
        logger.error("SSH key generation timed out")
        return jsonify({'success': False, 'error': 'Key generation timed out'}), 500
    except Exception as e:
        logger.error(f"SSH key generation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/<key_name>/public', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_public_key(key_name):
    """
    Get the public key content for a specific key
    Useful for copying to clipboard or deploying to servers
    """
    try:
        # Sanitize key name - prevent path traversal (no dots allowed except for known extensions)
        # Remove any path separators and control characters
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:100]

        # Block path traversal attempts
        if '..' in key_name or '/' in key_name or '\\' in key_name:
            logger.warning(f"Path traversal attempt blocked in get_public_key: {key_name[:50]}")
            return jsonify({'success': False, 'error': 'Invalid key name'}), 400

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        public_key_path = ssh_dir / f"{key_name}.pub"

        if not public_key_path.exists():
            # Try without .pub extension (in case user included it)
            if key_name.endswith('.pub'):
                public_key_path = ssh_dir / key_name

        if not public_key_path.exists():
            return jsonify({
                'success': False,
                'error': f'Public key not found: {key_name}'
            }), 404

        public_key_content = public_key_path.read_text().strip()

        return jsonify({
            'success': True,
            'key_name': key_name,
            'public_key': public_key_content,
            'path': str(public_key_path)
        })

    except Exception as e:
        logger.error(f"Error reading public key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/<key_name>', methods=['DELETE'])
@login_required
@require_role('SuperAdmin')
def delete_ssh_key(key_name):
    """
    Delete an SSH key pair

    Creates a backup before deletion for safety
    """
    import shutil

    try:
        # Sanitize key name - prevent path traversal (OWASP A01:2021)
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:100]

        # Explicit path traversal check
        if '..' in key_name or '/' in key_name or '\\' in key_name:
            logger.warning(f"Path traversal attempt blocked in delete_ssh_key: {key_name[:50]}")
            return jsonify({'success': False, 'error': 'Invalid key name'}), 400

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        private_key_path = ssh_dir / key_name
        public_key_path = ssh_dir / f"{key_name}.pub"

        if not private_key_path.exists() and not public_key_path.exists():
            return jsonify({
                'success': False,
                'error': f'Key not found: {key_name}'
            }), 404

        # Create backups
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = ssh_dir / 'backup'
        backup_dir.mkdir(exist_ok=True)

        deleted_files = []

        if private_key_path.exists():
            backup_path = backup_dir / f"{key_name}.backup_{timestamp}"
            shutil.move(str(private_key_path), str(backup_path))
            deleted_files.append(str(private_key_path))
            logger.info(f"Backed up and removed: {private_key_path}")

        if public_key_path.exists():
            backup_path = backup_dir / f"{key_name}.pub.backup_{timestamp}"
            shutil.move(str(public_key_path), str(backup_path))
            deleted_files.append(str(public_key_path))
            logger.info(f"Backed up and removed: {public_key_path}")

        return jsonify({
            'success': True,
            'message': f'Key pair deleted (backed up to {backup_dir})',
            'deleted_files': deleted_files,
            'backup_dir': str(backup_dir)
        })

    except Exception as e:
        logger.error(f"Error deleting SSH key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/default', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_default_ssh_key():
    """
    Get the default/preferred SSH key for the toolkit.

    Returns the configured default key name and its full path if it exists.
    This is the key that should be used for SSH connections to servers.
    """
    import platform
    from security_settings import get_security_setting

    try:
        # Get default key name from settings
        default_key_name = get_security_setting('ssh_default_key_name', 'audit-toolkit')
        ssh_prefer_key_auth = get_security_setting('ssh_prefer_key_auth', True)

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        private_key_path = ssh_dir / default_key_name
        public_key_path = ssh_dir / f"{default_key_name}.pub"

        key_exists = private_key_path.exists() and public_key_path.exists()

        result = {
            'success': True,
            'default_key_name': default_key_name,
            'ssh_prefer_key_auth': ssh_prefer_key_auth,
            'ssh_dir': str(ssh_dir),
            'private_key_path': str(private_key_path),
            'public_key_path': str(public_key_path),
            'key_exists': key_exists,
            'platform': platform.system()
        }

        if key_exists:
            # Get key type and fingerprint
            try:
                pub_content = public_key_path.read_text().strip()
                if pub_content.startswith('ssh-ed25519'):
                    result['key_type'] = 'ed25519'
                elif pub_content.startswith('ssh-rsa'):
                    result['key_type'] = 'rsa'
                elif pub_content.startswith('ecdsa-'):
                    result['key_type'] = 'ecdsa'
                else:
                    result['key_type'] = 'unknown'
                result['public_key'] = pub_content
            except Exception as key_read_err:  # noqa: B110 - non-critical
                logger.debug(f"Could not read public key details: {key_read_err}")

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error getting default SSH key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/default', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def set_default_ssh_key():
    """
    Set the default/preferred SSH key for the toolkit.

    Request body:
    {
        "key_name": "audit-toolkit",  // Key name (must exist)
        "prefer_key_auth": true  // Whether to prefer key auth over password
    }
    """
    import json
    from config import ROOT_DIR

    try:
        data = request.get_json() or {}
        key_name = data.get('key_name')
        prefer_key_auth = data.get('prefer_key_auth', True)

        if not key_name:
            return jsonify({'success': False, 'error': 'key_name is required'}), 400

        # Sanitize key name
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:50]

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        private_key_path = ssh_dir / key_name
        public_key_path = ssh_dir / f"{key_name}.pub"

        if not private_key_path.exists() or not public_key_path.exists():
            return jsonify({
                'success': False,
                'error': f'SSH key not found: {key_name}. Generate it first.'
            }), 404

        # Update security settings
        settings_dir = ROOT_DIR / 'settings'
        settings_file = settings_dir / 'security_settings.json'

        settings = {}
        if settings_file.exists():
            with open(settings_file, 'r') as f:
                settings = json.load(f)

        settings['ssh_default_key_name'] = key_name
        settings['ssh_prefer_key_auth'] = prefer_key_auth

        settings_dir.mkdir(parents=True, exist_ok=True)
        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2)

        logger.info(f"Default SSH key set to: {key_name}")

        return jsonify({
            'success': True,
            'message': f'Default SSH key set to: {key_name}',
            'key_name': key_name,
            'prefer_key_auth': prefer_key_auth,
            'private_key_path': str(private_key_path)
        })

    except Exception as e:
        logger.error(f"Error setting default SSH key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/deploy', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def deploy_ssh_key_to_servers():
    """
    Deploy the SSH public key to specified servers using existing password credentials.

    This allows transitioning from password auth to SSH key auth, similar to ssh-copy-id.
    After deployment, servers can be updated to use key authentication.

    Request body:
    {
        "key_name": "audit-toolkit",  // Key to deploy (default: toolkit default key)
        "server_ids": [1, 2, 3],  // Server IDs to deploy to (or "all")
        "update_server_auth": true,  // Update server config to use key auth after deploy
        "backup_authorized_keys": true  // Backup existing authorized_keys
    }
    """
    from security_settings import get_security_setting
    import models.server as server_models
    import ssh_manager as ssh_manager_module

    try:
        server_manager = getattr(server_models, 'server_manager', None)
        ssh_manager = getattr(ssh_manager_module, 'ssh_manager', None)
        if server_manager is None or ssh_manager is None:
            return jsonify({'success': False, 'error': 'Server/SSH manager not initialized'}), 500

        data = request.get_json() or {}

        # Get key to deploy
        key_name = data.get('key_name') or get_security_setting('ssh_default_key_name', 'audit-toolkit')
        server_ids = data.get('server_ids', [])
        update_server_auth = data.get('update_server_auth', True)
        backup_authorized_keys = data.get('backup_authorized_keys', True)

        # Sanitize and validate key name
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:50]

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        private_key_path = ssh_dir / key_name
        public_key_path = ssh_dir / f"{key_name}.pub"

        if not public_key_path.exists():
            return jsonify({
                'success': False,
                'error': f'Public key not found: {public_key_path}. Generate the key first.'
            }), 404

        # Read public key
        public_key_content = public_key_path.read_text().strip()

        # OWASP A03:2021 - Validate SSH public key format to prevent command injection
        # SSH public keys have a strict format: <algorithm> <base64-data> [comment]
        import re
        ssh_key_pattern = re.compile(
            r'^(ssh-rsa|ssh-ed25519|ecdsa-sha2-nistp(?:256|384|521)|ssh-dss)\s+'
            r'[A-Za-z0-9+/]+=*(?:\s+.+)?$'
        )
        if not ssh_key_pattern.match(public_key_content):
            logger.warning(f"Invalid SSH public key format detected for key: {key_name}")
            return jsonify({
                'success': False,
                'error': 'Invalid SSH public key format. Key may be corrupted.'
            }), 400

        # Additional security: ensure no shell metacharacters in key content
        # SSH keys should only contain base64 chars, spaces, and simple comments
        dangerous_chars = ['`', '$', '(', ')', ';', '|', '&', '<', '>', '\n', '\r', '\\']
        for char in dangerous_chars:
            if char in public_key_content:
                logger.warning(f"Potentially malicious character '{char}' found in SSH key: {key_name}")
                return jsonify({
                    'success': False,
                    'error': 'Invalid SSH public key: contains disallowed character'
                }), 400

        # Load servers
        all_servers = server_manager.load_servers()

        if server_ids == 'all':
            # Filter to only SSH-capable servers (Linux)
            target_servers = [s for s in all_servers if s.get('os_type') != 'windows']
        elif server_ids:
            target_servers = [s for s in all_servers if s.get('id') in server_ids]
        else:
            return jsonify({'success': False, 'error': 'No server_ids provided'}), 400

        if not target_servers:
            return jsonify({'success': False, 'error': 'No matching servers found'}), 404

        results = {
            'total': len(target_servers),
            'deployed': 0,
            'failed': 0,
            'updated': 0,
            'details': []
        }

        for server in target_servers:
            server_id = server.get('id')
            server_name = server.get('name', 'Unknown')

            # Skip if already using this key
            if server.get('auth_type') == 'public_key' and server.get('key_path') == str(private_key_path):
                results['details'].append({
                    'server_id': server_id,
                    'name': server_name,
                    'status': 'skipped',
                    'message': 'Already using this key'
                })
                continue

            # Build deployment command
            backup_cmd = ""
            if backup_authorized_keys:
                backup_cmd = "cp ~/.ssh/authorized_keys ~/.ssh/authorized_keys.backup_$(date +%Y%m%d_%H%M%S) 2>/dev/null || true; "

            deploy_cmd = f'''
mkdir -p ~/.ssh && chmod 700 ~/.ssh
{backup_cmd}echo "{public_key_content}" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
echo "SSH key deployed successfully"
'''

            try:
                # Execute deployment using existing credentials
                result = ssh_manager.execute_command(server, deploy_cmd, timeout=30)

                if result.returncode == 0:
                    results['deployed'] += 1
                    detail = {
                        'server_id': server_id,
                        'name': server_name,
                        'status': 'deployed',
                        'message': 'Public key added to authorized_keys'
                    }

                    # Update server to use key auth if requested
                    if update_server_auth:
                        try:
                            update_success = server_manager.update_server(server_id, {
                                'auth_type': 'public_key',
                                'key_path': str(private_key_path),
                                'password': None,  # nosec B105
                            })
                            if update_success:
                                results['updated'] += 1
                                detail['auth_updated'] = True
                                detail['message'] = 'Key deployed and server updated to key auth'
                            else:
                                detail['auth_updated'] = False
                                detail['warning'] = 'Key deployed but server config update failed'
                        except Exception as update_err:
                            detail['auth_updated'] = False
                            detail['warning'] = f'Key deployed but config update failed: {str(update_err)[:100]}'

                    results['details'].append(detail)
                else:
                    results['failed'] += 1
                    results['details'].append({
                        'server_id': server_id,
                        'name': server_name,
                        'status': 'failed',
                        'error': result.stderr[:200] if result.stderr else 'Deployment command failed'
                    })

            except Exception as e:
                results['failed'] += 1
                results['details'].append({
                    'server_id': server_id,
                    'name': server_name,
                    'status': 'failed',
                    'error': str(e)[:200]
                })

        logger.info(f"SSH key deployment: {results['deployed']}/{results['total']} servers, "
                   f"{results['updated']} configs updated")

        return jsonify({
            'success': results['failed'] == 0,
            'partial_success': results['deployed'] > 0 and results['failed'] > 0,
            'results': results,
            'key_deployed': key_name,
            'private_key_path': str(private_key_path)
        })

    except Exception as e:
        logger.error(f"SSH key deployment failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/ssh-keys/test-key-auth/<int:server_id>', methods=['POST'])
@login_required
@require_role('SuperAdmin')
def test_key_auth(server_id):
    """
    Test SSH key authentication for a specific server.

    Uses the default toolkit SSH key to test connectivity without password.
    """
    from security_settings import get_security_setting
    import models.server as server_models

    try:
        server_manager = getattr(server_models, 'server_manager', None)
        if server_manager is None:
            return jsonify({'success': False, 'error': 'Server manager not initialized'}), 500

        # Get server
        server = server_manager.get_server(server_id)
        if not server:
            return jsonify({'success': False, 'error': 'Server not found'}), 404

        # Get default key
        key_name = get_security_setting('ssh_default_key_name', 'audit-toolkit')

        # Use configured SSH_DIR (works in Docker and native installs)
        from config import SSH_DIR
        ssh_dir = SSH_DIR

        private_key_path = ssh_dir / key_name

        if not private_key_path.exists():
            return jsonify({
                'success': False,
                'error': f'Default SSH key not found: {key_name}. Generate it first.'
            }), 404

        # Build SSH command to test key auth
        host = server.get('host')
        port = server.get('port', 22)
        user = server.get('user', 'root')

        # OWASP A03:2021 - Validate SSH parameters to prevent command injection
        import re

        # Validate hostname/IP (RFC 1123 compliant hostname or IP address)
        hostname_pattern = re.compile(
            r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*'
            r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$|'
            r'^(?:\d{1,3}\.){3}\d{1,3}$|'  # IPv4
            r'^\[?[a-fA-F0-9:]+\]?$'  # IPv6
        )
        if not host or not hostname_pattern.match(str(host)):
            logger.warning(f"Invalid hostname in test_key_auth: {str(host)[:50]}")
            return jsonify({'success': False, 'error': 'Invalid server hostname'}), 400

        # Validate port
        try:
            port = int(port)
            if not (1 <= port <= 65535):
                raise ValueError("Port out of range")
        except (ValueError, TypeError):
            return jsonify({'success': False, 'error': 'Invalid port number'}), 400

        # Validate username (alphanumeric, underscore, hyphen, max 32 chars)
        user_pattern = re.compile(r'^[a-zA-Z0-9_-]{1,32}$')
        if not user or not user_pattern.match(str(user)):
            logger.warning(f"Invalid username in test_key_auth: {str(user)[:50]}")
            return jsonify({'success': False, 'error': 'Invalid username format'}), 400

        ssh_cmd = [
            shutil.which('ssh') or 'ssh',
            '-i', str(private_key_path),
            '-o', 'PasswordAuthentication=no',
            '-o', 'BatchMode=yes',
            '-o', 'ConnectTimeout=10',
            '-o', 'StrictHostKeyChecking=accept-new',
            '-p', str(port),
            f'{user}@{host}',
            'echo "Key auth successful"'
        ]

        result = subprocess.run(ssh_cmd, capture_output=True, text=True, timeout=15, check=False)  # nosec B603

        if result.returncode == 0:
            return jsonify({
                'success': True,
                'message': 'SSH key authentication successful',
                'server_id': server_id,
                'server_name': server.get('name'),
                'key_used': key_name,
                'output': result.stdout.strip()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'SSH key authentication failed',
                'details': result.stderr[:200] if result.stderr else 'Connection failed',
                'suggestion': 'Deploy the public key to this server first using /api/admin/ssh-keys/deploy'
            })

    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Connection timed out'}), 504
    except Exception as e:
        logger.error(f"SSH key auth test failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Destination Policy Management (SuperAdmin Only)
# =============================================================================

@admin_bp.route('/settings/destination-policy', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_destination_policy():
    """
    Get the current destination whitelist/blacklist policy (SuperAdmin only)

    Returns:
    {
        'success': bool,
        'policy': {
            'id': int,
            'mode': str ('ALLOW_ALL' or 'WHITELIST_ONLY'),
            'blocked_keywords': [...],
            'whitelist_domains': [...],
            'allow_private_ips': bool,
            'log_blocked_attempts': bool,
            'is_active': bool,
            ...
        }
    }
    """
    from config import get_db_session
    from models.destination_policy import AdminDestinationPolicy

    db = get_db_session()
    try:
        policy = db.query(AdminDestinationPolicy).filter_by(is_active=True).first()

        if not policy:
            # Return default policy if none exists
            default_policy = AdminDestinationPolicy(
                name='Global Destination Policy',
                mode='ALLOW_ALL',
                blocked_keywords='wazuh,splunk,elastic,datadog,newrelic',
                allow_private_ips=False,
                log_blocked_attempts=True,
                is_active=True
            )
            return jsonify({
                'success': True,
                'policy': default_policy.to_dict(),
                'note': 'Using default policy (not yet saved)'
            })

        log_audit(
            action='view_destination_policy',
            resource_type='admin_setting',
            resource_id=policy.id,
            details={'mode': policy.mode},
            success=True
        )

        return jsonify({
            'success': True,
            'policy': policy.to_dict()
        })

    except Exception as e:
        logger.error(f"Failed to get destination policy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/settings/destination-policy', methods=['POST', 'PUT'])
@login_required
@require_role('SuperAdmin')
def update_destination_policy():
    """
    Create or update the destination whitelist/blacklist policy (SuperAdmin only)

    Request body:
    {
        'mode': str ('ALLOW_ALL' or 'WHITELIST_ONLY'),
        'blocked_keywords': str (comma-separated list),
        'whitelist_domains': str (comma-separated list),
        'allow_private_ips': bool,
        'log_blocked_attempts': bool,
        'enforce_asset_discovery': bool,
        'enforce_audit_execution': bool,
        'enforce_fleet_agent_registration': bool,
        'enforce_hypervisor_registration': bool,
        'description': str (optional)
    }

    Returns:
    {
        'success': bool,
        'policy': {...},
        'updated': bool (whether an existing policy was updated or created)
    }
    """
    from config import get_db_session
    from models.destination_policy import AdminDestinationPolicy

    db = get_db_session()
    try:
        data = request.get_json() or {}

        # Validate mode
        mode = data.get('mode', 'ALLOW_ALL').upper()
        if mode not in ('ALLOW_ALL', 'WHITELIST_ONLY'):
            return jsonify({
                'success': False,
                'error': 'Invalid mode. Must be ALLOW_ALL or WHITELIST_ONLY'
            }), 400

        # Get existing policy or create new
        policy = db.query(AdminDestinationPolicy).filter_by(is_active=True).first()
        is_update = policy is not None

        if not policy:
            policy = AdminDestinationPolicy()

        # Update fields
        policy.mode = mode
        policy.blocked_keywords = data.get('blocked_keywords', policy.blocked_keywords)
        policy.whitelist_domains = data.get('whitelist_domains', policy.whitelist_domains)
        policy.allow_private_ips = data.get('allow_private_ips', policy.allow_private_ips)
        policy.log_blocked_attempts = data.get('log_blocked_attempts', policy.log_blocked_attempts)
        policy.enforce_asset_discovery = data.get('enforce_asset_discovery', True)
        policy.enforce_audit_execution = data.get('enforce_audit_execution', True)
        policy.enforce_fleet_agent_registration = \
            data.get('enforce_fleet_agent_registration', True)
        policy.enforce_hypervisor_registration = \
            data.get('enforce_hypervisor_registration', True)
        policy.description = data.get('description', policy.description)
        policy.updated_by = current_user.username if hasattr(current_user, 'username') else 'api'

        # Validate whitelist in WHITELIST_ONLY mode
        if mode == 'WHITELIST_ONLY' and not policy.whitelist_domains:
            return jsonify({
                'success': False,
                'error': 'WHITELIST_ONLY mode requires at least one whitelisted domain'
            }), 400

        db.add(policy)
        db.commit()

        log_audit(
            action='update_destination_policy' if is_update else 'create_destination_policy',
            resource_type='admin_setting',
            resource_id=policy.id,
            details={
                'mode': policy.mode,
                'enforce_scope': {
                    'asset_discovery': policy.enforce_asset_discovery,
                    'audit_execution': policy.enforce_audit_execution,
                    'managed_agents': policy.enforce_fleet_agent_registration,
                    'hypervisors': policy.enforce_hypervisor_registration
                }
            },
            success=True
        )

        return jsonify({
            'success': True,
            'policy': policy.to_dict(),
            'updated': is_update
        })

    except Exception as e:
        logger.error(f"Failed to update destination policy: {e}")
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/settings/destination-policy/logs', methods=['GET'])
@login_required
@require_role('SuperAdmin')
def get_destination_policy_logs():
    """
    Get audit logs of destination policy enforcement (SuperAdmin only)

    Query parameters:
    - limit: int (default 100, max 1000)
    - offset: int (default 0)
    - action: str filter ('BLOCKED', 'ALLOWED', 'WARNED')
    - source_endpoint: str filter
    - destination_hostname: str filter
    - days: int (show logs from last N days, default 7)

    Returns:
    {
        'success': bool,
        'logs': [  # AdminDestinationPolicyLog.to_dict()
            {
                'id': int,
                'action': str,
                'reason': str,
                'destination': str,
                'source_endpoint': str,
                'source_user': str,
                'source_ip': str,
                'timestamp': str (ISO)
            }
        ],
        'total': int,
        'limit': int,
        'offset': int
    }
    """
    from config import get_db_session
    from models.destination_policy import AdminDestinationPolicyLog
    from datetime import timedelta, datetime as dt

    db = get_db_session()
    try:
        limit = min(int(request.args.get('limit', 100)), 1000)
        offset = int(request.args.get('offset', 0))
        action = request.args.get('action')
        source_endpoint = request.args.get('source_endpoint')
        destination_hostname = request.args.get('destination_hostname')
        days = int(request.args.get('days', 7))

        # Build query
        query = db.query(AdminDestinationPolicyLog)

        # Time filter
        cutoff = dt.utcnow() - timedelta(days=days)
        query = query.filter(AdminDestinationPolicyLog.timestamp >= cutoff)

        # Apply filters
        if action:
            query = query.filter_by(action=action)
        if source_endpoint:
            query = query.filter_by(source_endpoint=source_endpoint)
        if destination_hostname:
            query = query.filter(
                AdminDestinationPolicyLog.destination_hostname.ilike(f'%{destination_hostname}%')
            )

        # Count total before pagination
        total = query.count()

        # Apply pagination
        logs = query.order_by(AdminDestinationPolicyLog.timestamp.desc()) \
                    .offset(offset) \
                    .limit(limit) \
                    .all()

        log_audit(
            action='view_destination_policy_logs',
            resource_type='admin_audit_log',
            details={
                'total_logs': total,
                'filters': {
                    'action': action,
                    'source_endpoint': source_endpoint,
                    'destination_hostname': destination_hostname,
                    'days': days
                }
            },
            success=True
        )

        return jsonify({
            'success': True,
            'logs': [log.to_dict() for log in logs],
            'total': total,
            'limit': limit,
            'offset': offset
        })

    except Exception as e:
        logger.error(f"Failed to get destination policy logs: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


__all__ = ['admin_bp']

