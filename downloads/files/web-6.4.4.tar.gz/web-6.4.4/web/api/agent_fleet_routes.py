"""
Fleet Agent Routes - Two-Way API Agent Management

Provides enhanced agent capabilities with:
- Remote configuration push (server → agent)
- Audit/script synchronization (server → agent)
- Result ingestion to database (agent → server → audit_executions)
- Full integration with reporting and other toolkit functions

This builds on the standalone agent to create a fully fleet agent that:
1. Can be configured remotely via API
2. Pulls updated scripts automatically
3. Returns results in database-compatible format
4. Integrates seamlessly with SSH/WinRM execution paths

Author: Security Audit Toolkit Team
Date: February 17, 2026
"""

import os
import io
import json
import hashlib
import hmac
import base64
import shutil
import zipfile
import tarfile
import tempfile
import secrets
import ipaddress
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from urllib.parse import urlparse
from flask import Blueprint, jsonify, request, send_file, Response

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.serialization import load_pem_public_key, load_pem_private_key
    from cryptography.hazmat.backends import default_backend
    _CRYPTOGRAPHY_AVAILABLE = True
except Exception:
    _CRYPTOGRAPHY_AVAILABLE = False

from config import logger, ROOT_DIR
from api.archive_utils import add_directory_to_tar, add_directory_to_zip
from api.agent_pathing import get_standalone_agent_dir
from api.upload_rate_limits import get_managed_upload_limit
from version_info import get_toolkit_version

# Import feature licensing (optional)
try:
    from web.services_pkg.services.feature_licensing import Feature, get_feature_service
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    Feature = None

    def get_feature_service():
        return None

# Import auth decorators
from auth_core import require_api_key, conditional_limit, require_auth_and_permission

# Import result encryption (Phase 2)
from api.result_encryption import ResultEncryption

# Import database models
try:
    from models.database import Server, Audit, AuditExecution, FleetAgent
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    logger.warning("Database models not available - using file-based storage")

try:
    from services_pkg.services.reporting_persistence_service import ReportingPersistenceService
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = False

# Create blueprint
fleet_agent_bp = Blueprint('fleet_agent', __name__)

# Directories
AGENTS_DIR = os.path.join(ROOT_DIR, 'data', 'agents')
AGENT_CONFIG_DIR = os.path.join(ROOT_DIR, 'data', 'agent_configs')
AUDITS_DIR = os.path.join(ROOT_DIR, 'audits')
STANDALONE_AGENT_DIR = str(get_standalone_agent_dir())
FLEET_AGENT_DIR = os.path.join(ROOT_DIR, 'agents', 'fleet-agent')
if not os.path.isdir(FLEET_AGENT_DIR):
    # Transition fallback while older environments still stage fleet files
    # under the standalone source tree.
    FLEET_AGENT_DIR = STANDALONE_AGENT_DIR

# Database session (will be set by app.py)
_db_session = None
reporting_persistence_service = ReportingPersistenceService() if _REPORTING_PERSISTENCE_SERVICE_AVAILABLE else None

# Store pending registration tokens: {token: {server_data, expires_at}}
_pending_agent_registrations = {}

# Store registered fleet agents: {server_id: agent_data}
_managed_agents = {}

# Require a recent heartbeat before accepting managed poll requests
HEARTBEAT_MAX_AGE_SECONDS = int(os.environ.get('AGENT_HEARTBEAT_MAX_AGE_SEC', '180'))

MANAGED_REQUIRE_HTTPS = os.environ.get('FLEET_AGENT_REQUIRE_HTTPS', 'true').lower() != 'false'
MANAGED_ALLOW_PRIVATE_HOSTS = os.environ.get('FLEET_AGENT_ALLOW_PRIVATE_HOSTS', 'false').lower() == 'true'
MANAGED_ALLOWED_SERVER_DOMAINS = [
    d.strip().lower() for d in os.environ.get('FLEET_AGENT_ALLOWED_SERVER_DOMAINS', '').split(',')
    if d.strip()
]
MANAGED_BLOCKED_SERVER_KEYWORDS = [
    k.strip().lower() for k in os.environ.get(
        'FLEET_AGENT_BLOCKED_SERVER_KEYWORDS',
        'wazuh,splunk,elastic,datadog,newrelic'
    ).split(',') if k.strip()
]

TOOLKIT_VERSION = get_toolkit_version(default='0.0.0')


def _persist_reporting_audit_execution(db_session, execution):
    """Persist canonical reporting rows for fleet-agent audit results when available."""
    if reporting_persistence_service is None:
        return None
    return reporting_persistence_service.persist_audit_execution(db_session, execution)


def _feature_unavailable_response(feature):
    """Return standardized 403 payload when a licensed feature is unavailable."""
    if not FEATURE_LICENSING_AVAILABLE:
        return None

    try:
        user_id = None
        try:
            from flask_login import current_user
            if current_user and getattr(current_user, 'is_authenticated', False):
                user_id = str(current_user.id)
        except Exception:
            user_id = None

        service = get_feature_service()
        status = service.is_feature_available(feature, user_id)
    except Exception as exc:
        logger.warning(f"Feature licensing check failed for {getattr(feature, 'value', feature)}: {exc}")
        return None

    if status.get('available'):
        return None

    return jsonify({
        'error': 'Feature not available',
        'feature': feature.value,
        'reason': status.get('reason', 'Feature is not enabled for this license tier'),
        'code': 'FEATURE_UNAVAILABLE',
        'trial_eligible': status.get('trial_eligible', False),
        'upgrade_tier': status.get('upgrade_tier'),
    }), 403


def _get_managed_config_integrity_settings():
    """Return managed config integrity settings (security settings with env fallback)."""
    settings = {}
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings() or {}
    except Exception as err:
        logger.warning(f"Unable to load security settings for managed config integrity: {err}")

    enforce = bool(settings.get('fleet_agent_enforce_signed_config', True))

    max_age_value = settings.get('fleet_agent_config_max_age_seconds', 900)
    try:
        max_age = int(max_age_value)
    except (TypeError, ValueError):
        max_age = 900
    max_age = max(30, min(86400, max_age))

    signing_key = str(settings.get('fleet_agent_config_signing_key', '') or '').strip()
    if not signing_key:
        signing_key = os.environ.get('FLEET_AGENT_CONFIG_SIGNING_KEY', '').strip()

    use_ecdsa = bool(settings.get('fleet_agent_config_signing_use_ecdsa', False))
    ecdsa_private_key = str(settings.get('fleet_agent_config_signing_ecdsa_private_key', '') or '').strip()
    if not ecdsa_private_key:
        ecdsa_private_key = os.environ.get('FLEET_AGENT_CONFIG_SIGNING_ECDSA_PRIVATE_KEY', '').strip()

    return {
        'enforce_signed_config': enforce,
        'config_max_age_seconds': max_age,
        'signing_key': signing_key,
        'use_ecdsa': use_ecdsa,
        'ecdsa_private_key': ecdsa_private_key,
    }


def _get_managed_request_auth_settings():
    """Return managed request-signature auth settings (security settings with env fallback)."""
    settings = {}
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings() or {}
    except Exception as err:
        logger.warning(f"Unable to load security settings for managed request auth: {err}")

    require_signatures = bool(settings.get('fleet_agent_require_request_signatures', False))

    max_age_value = settings.get('fleet_agent_request_signature_max_age_seconds', 300)
    try:
        max_age = int(max_age_value)
    except (TypeError, ValueError):
        max_age = 300
    max_age = max(30, min(3600, max_age))

    signing_key = str(settings.get('fleet_agent_request_signing_key', '') or '').strip()
    if not signing_key:
        signing_key = os.environ.get('FLEET_AGENT_REQUEST_SIGNING_KEY', '').strip()

    ecdsa_dual_verify_enabled = bool(settings.get('fleet_agent_request_signature_ecdsa_dual_verify_enabled', False))

    ecdsa_public_key_pem = str(settings.get('fleet_agent_request_signature_ecdsa_public_key', '') or '').strip()
    if not ecdsa_public_key_pem:
        ecdsa_public_key_pem = os.environ.get('FLEET_AGENT_REQUEST_SIGNATURE_ECDSA_PUBLIC_KEY', '').strip()

    return {
        'require_request_signatures': require_signatures,
        'request_signature_max_age_seconds': max_age,
        'request_signing_key': signing_key,
        'ecdsa_dual_verify_enabled': ecdsa_dual_verify_enabled,
        'ecdsa_public_key_pem': ecdsa_public_key_pem,
    }


def _extract_signature_candidate(signature_header: str, prefix: str):
    value = str(signature_header or '').strip()
    expected = f"{prefix}:"
    if value.lower().startswith(expected):
        return value[len(expected):].strip()
    return ''


def _verify_hmac_signature(signature_header: str, signing_key: str, message: bytes):
    if not signing_key:
        return False

    hmac_candidate = _extract_signature_candidate(signature_header, 'hmac')
    if not hmac_candidate:
        raw_value = str(signature_header or '').strip().lower()
        if ':' in raw_value:
            return False
        hmac_candidate = raw_value

    computed_signature = hmac.new(
        signing_key.encode('utf-8'),
        message,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(hmac_candidate.lower(), computed_signature)


def _verify_ecdsa_signature(signature_header: str, public_key_pem: str, message: bytes):
    if not public_key_pem:
        return False, 'ecdsa public key is not configured'
    if not _CRYPTOGRAPHY_AVAILABLE:
        return False, 'cryptography package unavailable for ECDSA verification'

    ecdsa_b64 = _extract_signature_candidate(signature_header, 'ecdsa')
    if not ecdsa_b64:
        return False, 'missing ecdsa signature prefix'

    try:
        signature_bytes = base64.b64decode(ecdsa_b64)
    except Exception:
        return False, 'invalid base64 ecdsa signature'

    try:
        public_key = load_pem_public_key(public_key_pem.encode('utf-8'))
        public_key.verify(signature_bytes, message, ec.ECDSA(hashes.SHA256()))
    except Exception:
        return False, 'ecdsa signature mismatch'

    return True, ''


def _load_fleet_agent_runtime_config(agent_id):
    """Load fleet agent runtime config payload if present."""
    config_file = os.path.join(AGENT_CONFIG_DIR, f"{agent_id}.json")
    if not os.path.exists(config_file):
        return {}

    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        return payload if isinstance(payload, dict) else {}
    except Exception as err:
        logger.warning(f"Failed to load fleet agent runtime config for {agent_id}: {err}")
        return {}


def _resolve_managed_direct_api_credentials(agent_id):
    """Resolve direct managed API base URL/token from request or stored config."""
    req_json = request.get_json(silent=True) if request.method in ('POST', 'PUT', 'PATCH') else None
    req_json = req_json if isinstance(req_json, dict) else {}

    runtime_config = _load_fleet_agent_runtime_config(agent_id)

    base_url = (
        request.args.get('api_url')
        or req_json.get('api_url')
        or runtime_config.get('managed_api_url')
        or runtime_config.get('direct_api_url')
        or runtime_config.get('agent_api_url')
        or ''
    )
    base_url = str(base_url).strip().rstrip('/')

    token = (
        request.headers.get('X-Agent-Token')
        or request.args.get('api_token')
        or req_json.get('api_token')
        or runtime_config.get('managed_api_token')
        or runtime_config.get('direct_api_token')
        or runtime_config.get('agent_api_token')
        or ''
    )
    token = str(token).strip()

    return base_url, token


def _managed_direct_api_call(agent_id, path):
    """Call managed target-host API endpoint and return response payload/status."""
    base_url, token = _resolve_managed_direct_api_credentials(agent_id)

    if not base_url:
        return {
            'success': False,
            'error': 'Managed direct API URL not configured',
            'details': 'Provide api_url, or set managed_api_url/direct_api_url in agent config.'
        }, 400

    is_valid, reason = _validate_managed_server_url(base_url)
    if not is_valid:
        return {
            'success': False,
            'error': 'Managed direct API URL rejected by destination controls',
            'details': reason,
        }, 403

    if not token:
        return {
            'success': False,
            'error': 'Managed direct API token not configured',
            'details': 'Provide X-Agent-Token/api_token, or set managed_api_token/direct_api_token in agent config.'
        }, 400

    target_url = f"{base_url}{path}"
    headers = {
        'Accept': 'application/json',
        'X-Agent-Token': token,
    }

    req = urllib.request.Request(target_url, headers=headers, method='GET')

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:  # nosec B310 - destination policy validated
            body_raw = resp.read().decode('utf-8', errors='replace')
            try:
                body = json.loads(body_raw)
            except Exception:
                body = {'raw': body_raw}

            return {
                'success': True,
                'agent_id': agent_id,
                'target_url': target_url,
                'upstream_status': resp.status,
                'upstream': body,
            }, 200
    except urllib.error.HTTPError as err:
        body_raw = err.read().decode('utf-8', errors='replace')
        try:
            body = json.loads(body_raw)
        except Exception:
            body = {'raw': body_raw}

        return {
            'success': False,
            'agent_id': agent_id,
            'target_url': target_url,
            'upstream_status': err.code,
            'upstream': body,
            'error': 'Managed direct API request failed',
        }, 502
    except Exception as err:
        return {
            'success': False,
            'agent_id': agent_id,
            'target_url': target_url,
            'error': 'Managed direct API request failed',
            'details': str(err),
        }, 502


def _log_managed_request_auth_event(operation, outcome, agent_id=None, reason=''):
    """Emit structured fleet-agent request-auth security events."""
    payload = {
        'event_type': 'FLEET_AGENT_REQUEST_SIGNATURE_AUTH',
        'operation': operation,
        'outcome': outcome,
        'agent_id': str(agent_id or ''),
        'reason': str(reason or ''),
        'method': request.method,
        'path': request.path,
        'source_ip': request.remote_addr,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
    }

    line = f"SECURITY_EVENT|{json.dumps(payload, sort_keys=True)}"
    if outcome == 'allow':
        logger.info(line)
    elif outcome == 'warn':
        logger.warning(line)
    else:
        logger.warning(line)


def _verify_managed_request_signature(agent_id=None):
    """Verify managed request signature, payload hash, and timestamp freshness."""
    auth = _get_managed_request_auth_settings()
    if not auth['require_request_signatures']:
        return True, None

    signing_key = auth['request_signing_key']
    if not signing_key:
        _log_managed_request_auth_event('managed_request_signature', 'deny', agent_id, 'signing key is not configured')
        return False, 'Request signature enforcement enabled but signing key is not configured'

    timestamp_header = request.headers.get('X-Agent-Timestamp', '').strip()
    payload_hash_header = request.headers.get('X-Agent-Content-SHA256', '').strip().lower()
    signature_header = request.headers.get('X-Agent-Signature', '').strip()

    if not timestamp_header or not payload_hash_header or not signature_header:
        _log_managed_request_auth_event('managed_request_signature', 'deny', agent_id, 'missing signature headers')
        return False, 'Missing signature headers (X-Agent-Timestamp, X-Agent-Content-SHA256, X-Agent-Signature)'

    now = datetime.utcnow()
    request_time = None
    if timestamp_header.isdigit():
        try:
            request_time = datetime.utcfromtimestamp(int(timestamp_header))
        except (OverflowError, ValueError):
            request_time = None
    else:
        request_time = _parse_iso_datetime(timestamp_header)

    if request_time is None:
        _log_managed_request_auth_event('managed_request_signature', 'deny', agent_id, 'invalid request timestamp format')
        return False, 'Invalid request timestamp format'

    age_seconds = abs((now - request_time).total_seconds())
    if age_seconds > auth['request_signature_max_age_seconds']:
        _log_managed_request_auth_event('managed_request_signature', 'deny', agent_id, 'request timestamp outside freshness window')
        return False, 'Request timestamp is outside allowed freshness window'

    body_raw = request.get_data(cache=True, as_text=False) or b''
    computed_payload_hash = hashlib.sha256(body_raw).hexdigest()
    if not hmac.compare_digest(payload_hash_header, computed_payload_hash):
        _log_managed_request_auth_event('managed_request_signature', 'deny', agent_id, 'request payload hash mismatch')
        return False, 'Request payload hash mismatch'

    resolved_agent_id = str(agent_id or '').strip()
    if not resolved_agent_id:
        try:
            data = request.get_json(silent=True) or {}
            resolved_agent_id = str(data.get('agent_id', '')).strip()
        except Exception:
            resolved_agent_id = ''

    signature_message = (
        f"{request.method}:{request.path}:{resolved_agent_id}:{timestamp_header}:{computed_payload_hash}"
    ).encode('utf-8')

    hmac_ok = _verify_hmac_signature(signature_header, signing_key, signature_message)

    if not auth.get('ecdsa_dual_verify_enabled'):
        if not hmac_ok:
            _log_managed_request_auth_event('managed_request_signature', 'deny', resolved_agent_id or agent_id, 'request signature mismatch')
            return False, 'Request signature mismatch'
        _log_managed_request_auth_event('managed_request_signature', 'allow', resolved_agent_id or agent_id, 'verifier=hmac')
        return True, None

    ecdsa_ok, ecdsa_reason = _verify_ecdsa_signature(
        signature_header,
        auth.get('ecdsa_public_key_pem', ''),
        signature_message,
    )

    if ecdsa_ok:
        _log_managed_request_auth_event('managed_request_signature', 'allow', resolved_agent_id or agent_id, 'verifier=ecdsa')
        return True, None

    if hmac_ok:
        _log_managed_request_auth_event('managed_request_signature', 'allow', resolved_agent_id or agent_id, 'verifier=hmac')
        return True, None

    _log_managed_request_auth_event(
        'managed_request_signature',
        'deny',
        resolved_agent_id or agent_id,
        f'request signature mismatch (ecdsa_reason={ecdsa_reason})',
    )
    return False, 'Request signature mismatch'

    return True, None


def _canonicalize_config_for_signing(config):
    """Return canonical JSON string for deterministic config signing."""
    return json.dumps(config, sort_keys=True, separators=(',', ':'))


def _build_config_envelope(config, signing_key, use_ecdsa=False, ecdsa_private_key_pem=''):
    """Build compatibility signed envelope fields for fleet-agent config payload.

    Supports both HMAC (legacy) and ECDSA signing modes.
    ECDSA signatures are prefixed with 'ecdsa:' and base64-encoded.
    """
    canonical = _canonicalize_config_for_signing(config)
    payload_hash = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    version = int(config.get('config_version', 0) or 0)
    issued_at = datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'
    nonce = secrets.token_hex(16)
    message = f"{version}:{issued_at}:{nonce}:{payload_hash}"

    if use_ecdsa and ecdsa_private_key_pem and _CRYPTOGRAPHY_AVAILABLE:
        try:
            private_key = load_pem_private_key(
                ecdsa_private_key_pem.encode('utf-8'),
                password=None,
                backend=default_backend()
            )
            signature_bytes = private_key.sign(
                message.encode('utf-8'),
                ec.ECDSA(hashes.SHA256())
            )
            signature = 'ecdsa:' + base64.b64encode(signature_bytes).decode('utf-8')
        except Exception as e:
            logger.warning(f"ECDSA config signing failed, falling back to HMAC: {e}")
            signature = hmac.new(signing_key.encode('utf-8'), message.encode('utf-8'), hashlib.sha256).hexdigest()
    else:
        signature = hmac.new(signing_key.encode('utf-8'), message.encode('utf-8'), hashlib.sha256).hexdigest()

    return {
        'signature': signature,
        'nonce': nonce,
        'issued_at': issued_at,
        'payload_sha256': payload_hash,
    }


def init_fleet_agent_routes(db_session=None):
    """Initialize fleet agent routes with database session"""
    global _db_session
    _db_session = db_session


def _ensure_dirs():
    """Ensure required directories exist"""
    os.makedirs(AGENTS_DIR, exist_ok=True)
    os.makedirs(AGENT_CONFIG_DIR, exist_ok=True)


def _get_max_managed_result_files_per_host():
    """Get max fleet-agent fallback result files per host from security settings."""
    default_limit = 5000
    try:
        from security_settings import get_security_setting
        value = int(get_security_setting('fleet_agent_result_max_files_per_host', default_limit))
        return max(0, value)
    except Exception:
        return default_limit


def _get_agent_local_result_max_files():
    """Get target-agent local result file cap from centralized security settings."""
    default_limit = 1000
    try:
        from security_settings import get_security_setting
        value = int(get_security_setting('agent_local_result_max_files', default_limit))
        return max(0, value)
    except Exception:
        return default_limit


def _get_agent_local_min_free_disk_mb():
    """Get managed target local-write minimum free disk MB from centralized security settings."""
    default_limit = 512
    try:
        from security_settings import get_security_setting
        value = int(get_security_setting('agent_local_min_free_disk_mb', default_limit))
        return max(64, value)
    except Exception:
        return default_limit


def _get_agent_local_min_free_disk_pct():
    """Get managed target local-write minimum free disk percent from centralized security settings."""
    default_limit = 3
    try:
        from security_settings import get_security_setting
        value = int(get_security_setting('agent_local_min_free_disk_pct', default_limit))
        return max(1, min(95, value))
    except Exception:
        return default_limit


def _prune_result_files_for_host(host_dir, max_files):
    """Prune oldest JSON result files in host_dir, keeping newest max_files."""
    if max_files <= 0 or not os.path.isdir(host_dir):
        return 0

    files = []
    for name in os.listdir(host_dir):
        if not name.endswith('.json'):
            continue
        path = os.path.join(host_dir, name)
        if os.path.isfile(path):
            files.append(path)

    overflow = len(files) - max_files
    if overflow <= 0:
        return 0

    files.sort(key=lambda p: os.path.getmtime(p))
    removed = 0
    for path in files[:overflow]:
        try:
            os.remove(path)
            removed += 1
        except OSError as err:
            logger.warning(f"Failed to prune fleet-agent result file {path}: {err}")

    return removed


def _get_result_ingest_limits():
    """Get ingestion guardrail limits from security settings."""
    defaults = {
        'max_body_kb': 2048,
        'max_results_per_request': 100,
        'max_checks_per_result': 500,
        'max_output_chars': 200000,
    }
    try:
        from security_settings import get_security_setting
        return {
            'max_body_kb': max(128, int(get_security_setting('agent_result_ingest_max_body_kb', defaults['max_body_kb']))),
            'max_results_per_request': max(1, int(get_security_setting('agent_result_ingest_max_results_per_request', defaults['max_results_per_request']))),
            'max_checks_per_result': max(1, int(get_security_setting('agent_result_ingest_max_checks_per_result', defaults['max_checks_per_result']))),
            'max_output_chars': max(1000, int(get_security_setting('agent_result_ingest_max_output_chars', defaults['max_output_chars']))),
        }
    except Exception:
        return defaults


def _is_result_ingest_blocked_by_disk_watermark():
    """Check if ingest should be blocked because free disk is below configured watermark."""
    defaults = {
        'enabled': True,
        'min_free_mb': 1024,
        'min_free_pct': 5,
    }
    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting('agent_result_ingest_disk_guard_enabled', defaults['enabled']))
        min_free_mb = max(128, int(get_security_setting('agent_result_ingest_min_free_disk_mb', defaults['min_free_mb'])))
        min_free_pct = max(1, int(get_security_setting('agent_result_ingest_min_free_disk_pct', defaults['min_free_pct'])))
    except Exception:
        enabled = defaults['enabled']
        min_free_mb = defaults['min_free_mb']
        min_free_pct = defaults['min_free_pct']

    if not enabled:
        return False, {}

    target_dir = os.path.join(ROOT_DIR, 'data', 'agent_results')
    os.makedirs(target_dir, exist_ok=True)
    usage = shutil.disk_usage(target_dir)
    free_mb = usage.free // (1024 * 1024)
    free_pct = (usage.free / usage.total * 100) if usage.total > 0 else 0
    blocked = free_mb < min_free_mb or free_pct < min_free_pct

    details = {
        'free_mb': int(free_mb),
        'free_pct': round(free_pct, 2),
        'min_free_mb': min_free_mb,
        'min_free_pct': min_free_pct,
    }
    return blocked, details


def _write_json_secure(path, payload, mode=0o600):
    """Write JSON and apply restrictive permissions where supported."""
    with open(path, 'w') as f:
        json.dump(payload, f, indent=2)

    if os.name != 'nt':
        try:
            os.chmod(path, mode)
        except OSError as err:
            logger.warning(f"Failed to set permissions on {path}: {err}")


def _is_private_or_local_host(hostname):
    """Return True when host is localhost or private/reserved IP."""
    if not hostname:
        return True

    normalized = hostname.lower()
    if normalized in {'localhost', '127.0.0.1', '::1'}:
        return True

    try:
        ip = ipaddress.ip_address(normalized)
        return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
    except ValueError:
        return False


def _matches_allowed_domain(hostname):
    """Return True if hostname matches allowed domains policy."""
    if not MANAGED_ALLOWED_SERVER_DOMAINS:
        return True

    for domain in MANAGED_ALLOWED_SERVER_DOMAINS:
        if hostname == domain or hostname.endswith(f".{domain}"):
            return True
    return False


def _log_managed_security_event(event_type, reason, server_url=None, host=None):
    """Emit structured security events for fleet-agent policy decisions."""
    try:
        source_path = request.path
        source_ip = request.remote_addr
    except Exception:
        source_path = 'n/a'
        source_ip = 'n/a'

    payload = {
        'event_type': event_type,
        'source': 'fleet_agent_routes',
        'actor': _get_current_user(),
        'outcome': 'blocked',
        'reason': reason,
        'server_url': server_url,
        'host': host,
        'path': source_path,
        'source_ip': source_ip,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
    }
    logger.warning("SECURITY_EVENT|%s", json.dumps(payload, sort_keys=True))


def _validate_managed_server_url(server_url):
    """Validate server URL to prevent unsafe redirection destinations."""
    if not server_url or not isinstance(server_url, str):
        _log_managed_security_event('MANAGED_DESTINATION_BLOCKED', 'server_url is required', server_url=server_url)
        return False, 'server_url is required'

    try:
        parsed = urlparse(server_url.strip())
    except Exception:
        _log_managed_security_event('MANAGED_DESTINATION_BLOCKED', 'server_url is invalid', server_url=server_url)
        return False, 'server_url is invalid'

    if not parsed.scheme or not parsed.netloc:
        _log_managed_security_event('MANAGED_DESTINATION_BLOCKED', 'server_url must be an absolute URL', server_url=server_url)
        return False, 'server_url must be an absolute URL'

    # Check HTTPS requirement, but allow HTTP for localhost (development)
    is_localhost = parsed.hostname in ('localhost', '127.0.0.1', '::1', '[::1]') or (
        parsed.hostname and parsed.hostname.endswith('.local')
    )
    if MANAGED_REQUIRE_HTTPS and parsed.scheme.lower() != 'https' and not is_localhost:
        _log_managed_security_event('MANAGED_DESTINATION_BLOCKED', 'server_url must use HTTPS', server_url=server_url)
        return False, 'server_url must use HTTPS'

    host = (parsed.hostname or '').lower()
    if not host:
        _log_managed_security_event('MANAGED_DESTINATION_BLOCKED', 'server_url hostname is invalid', server_url=server_url)
        return False, 'server_url hostname is invalid'

    for blocked in MANAGED_BLOCKED_SERVER_KEYWORDS:
        if blocked in host:
            _log_managed_security_event(
                'MANAGED_DESTINATION_BLOCKED',
                f'redirection to {blocked} services is not permitted',
                server_url=server_url,
                host=host,
            )
            return False, f'redirection to {blocked} services is not permitted'

    # Allow localhost/local network even if private hosts disabled (development)
    if not MANAGED_ALLOW_PRIVATE_HOSTS and _is_private_or_local_host(host) and not is_localhost:
        _log_managed_security_event(
            'MANAGED_DESTINATION_BLOCKED',
            'private or localhost destinations are not permitted',
            server_url=server_url,
            host=host,
        )
        return False, 'private or localhost destinations are not permitted'

    # Skip allowed domain check for localhost (development)
    if not is_localhost and not _matches_allowed_domain(host):
        _log_managed_security_event(
            'MANAGED_DESTINATION_BLOCKED',
            'destination domain is not in allowed fleet-agent domains policy',
            server_url=server_url,
            host=host,
        )
        return False, 'destination domain is not in allowed fleet-agent domains policy'

    return True, None


def _escape_powershell_double_quoted_literal(value):
    """Escape user-provided content for safe embedding in PowerShell double-quoted strings."""
    if value is None:
        return ''
    escaped = str(value)
    escaped = escaped.replace('`', '``')
    escaped = escaped.replace('"', '`"')
    escaped = escaped.replace('$', '`$')
    escaped = escaped.replace('\r', '')
    escaped = escaped.replace('\n', '')
    return escaped


def _parse_iso_datetime(value):
    """Parse ISO datetime string (supports trailing Z)."""
    if not value or not isinstance(value, str):
        return None

    normalized = value.replace('Z', '+00:00')
    try:
        parsed = datetime.fromisoformat(normalized)
        return parsed.replace(tzinfo=None) if parsed.tzinfo else parsed
    except ValueError:
        return None


def _is_fresh_heartbeat(agent_id):
    """Return (is_valid, reason) for managed poll heartbeat gate."""
    agent_file = os.path.join(AGENTS_DIR, f"{agent_id}.json")
    if not os.path.exists(agent_file):
        return False, 'Agent not registered'

    try:
        with open(agent_file, 'r') as f:
            agent = json.load(f)
    except Exception:
        return False, 'Agent record unreadable'

    last_heartbeat = _parse_iso_datetime(agent.get('last_heartbeat'))
    if not last_heartbeat:
        return False, 'No heartbeat recorded'

    age_seconds = (datetime.now() - last_heartbeat).total_seconds()
    if age_seconds > HEARTBEAT_MAX_AGE_SECONDS:
        return False, f'Heartbeat stale ({int(age_seconds)}s old)'

    return True, None


# ============================================================================
# Fleet Agent Token Registration (Wizard Flow)
# ============================================================================

@fleet_agent_bp.route('/api/managed-agent/register/token', methods=['POST'])
@require_auth_and_permission('manage_servers')
def generate_fleet_agent_token():
    """
    Generate a registration token for a new fleet agent from the wizard.

    This enables the server wizard to setup fleet agent connections using
    the same token-based flow as hypervisor agents.

    Request body:
    {
        "agent_name": "production-web-01",
        "os_type": "linux" or "windows",
        "token_validity": "24h" or "1h" or "7d" or "30d",
        "key_validity_days": 90  # 30, 90, 180, 365, or 0 (never expires)
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        agent_name = data.get('agent_name')
        if not agent_name:
            return jsonify({'success': False, 'error': 'agent_name is required'}), 400

        os_type = data.get('os_type', 'linux')
        token_validity = data.get('token_validity', '24h')
        key_validity_days = int(data.get('key_validity_days', 90))

        managed_api_url = str(
            data.get('managed_api_url')
            or data.get('direct_api_url')
            or data.get('agent_api_url')
            or ''
        ).strip()
        managed_api_token = str(
            data.get('managed_api_token')
            or data.get('direct_api_token')
            or data.get('agent_api_token')
            or ''
        ).strip()

        if managed_api_url:
            is_valid, validation_error = _validate_managed_server_url(managed_api_url)
            if not is_valid:
                return jsonify({'success': False, 'error': validation_error}), 400

        # Parse token validity
        validity_hours = {
            '1h': 1,
            '24h': 24,
            '7d': 168,
            '30d': 720
        }.get(token_validity, 24)

        # Validate key_validity_days
        valid_options = [30, 90, 180, 365, 0]
        if key_validity_days not in valid_options:
            return jsonify({
                'success': False,
                'error': f'Invalid key_validity_days. Must be one of: {valid_options}'
            }), 400

        # Generate secure one-time registration token
        registration_token = secrets.token_urlsafe(32)

        # Generate server ID
        server_id = f"srv-{secrets.token_hex(8)}"

        # Calculate key expiry
        if key_validity_days > 0:
            key_expires_at = (datetime.now() + timedelta(days=key_validity_days)).isoformat()
        else:
            key_expires_at = None  # Never expires

        # Create pending registration
        pending_data = {
            'server_id': server_id,
            'agent_name': agent_name,
            'os_type': os_type,
            'connection_method': 'fleet-agent',
            'created_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(hours=validity_hours)).isoformat(),
            'key_validity_days': key_validity_days,
            'key_expires_at': key_expires_at,
            'status': 'pending'
        }

        if managed_api_url:
            pending_data['managed_api_url'] = managed_api_url
        if managed_api_token:
            pending_data['managed_api_token'] = managed_api_token

        # Store pending registration
        _pending_agent_registrations[registration_token] = pending_data

        logger.info(f"Registration token generated for fleet agent: {agent_name} ({server_id})")

        # Format validity message
        if key_validity_days == 0:
            validity_msg = 'Key will never expire'
        elif key_validity_days == 30:
            validity_msg = 'Key valid for 30 days'
        elif key_validity_days == 90:
            validity_msg = 'Key valid for 3 months'
        elif key_validity_days == 180:
            validity_msg = 'Key valid for 6 months'
        elif key_validity_days == 365:
            validity_msg = 'Key valid for 1 year'
        else:
            validity_msg = f'Key valid for {key_validity_days} days'

        expires_in = {
            '1h': '1 hour',
            '24h': '24 hours',
            '7d': '7 days',
            '30d': '30 days'
        }.get(token_validity, '24 hours')

        return jsonify({
            'success': True,
            'token': registration_token,
            'server_id': server_id,
            'expires_in': expires_in,
            'expires_at': pending_data['expires_at'],
            'key_validity_days': key_validity_days,
            'key_validity_message': validity_msg,
            'direct_api_configured': bool(managed_api_url)
        })

    except Exception as e:
        logger.error(f"Registration token generation failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/register/complete', methods=['POST'])
def complete_fleet_agent_registration():
    """
    Complete agent registration using a pending token.

    Called by the agent after being installed with a registration token.

    Request body:
    {
        "registration_token": "the-token-from-wizard",
        "agent_id": "auto-generated-or-provided",
        "hostname": "server.example.com",
        "os_type": "linux",
        "version": "1.0.0",
        "system_info": {...}
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        registration_token = data.get('registration_token')
        if not registration_token:
            return jsonify({'success': False, 'error': 'registration_token is required'}), 400

        # Validate registration token
        if registration_token not in _pending_agent_registrations:
            return jsonify({
                'success': False,
                'error': 'Invalid or expired registration token',
                'code': 'INVALID_REGISTRATION_TOKEN'
            }), 401

        pending = _pending_agent_registrations[registration_token]

        # Check if token has expired
        expires_at = datetime.fromisoformat(pending['expires_at'])
        if datetime.now() > expires_at:
            del _pending_agent_registrations[registration_token]
            return jsonify({
                'success': False,
                'error': 'Registration token has expired',
                'code': 'REGISTRATION_TOKEN_EXPIRED'
            }), 401

        # Generate permanent API token for the agent
        agent_token = secrets.token_urlsafe(32)
        agent_id = data.get('agent_id', f"agent-{secrets.token_hex(8)}")

        # Get key validity from pending registration
        key_validity_days = pending.get('key_validity_days', 90)
        key_expires_at = pending.get('key_expires_at')

        # Store agent API key in encrypted keystore
        try:
            from keystore import keystore
            keystore.store_key(
                key_type='agent',
                key_id=agent_id,
                value=agent_token,
                metadata={
                    'agent_name': pending['agent_name'],
                    'server_id': pending['server_id'],
                    'os_type': data.get('os_type', pending['os_type']),
                    'hostname': data.get('hostname', ''),
                    'key_validity_days': key_validity_days,
                    'key_expires_at': key_expires_at,
                    'registered_at': datetime.now().isoformat()
                },
                created_by='agent_registration'
            )
            logger.info(f"Stored agent API key in keystore: {agent_id}")
        except Exception as ks_err:
            logger.warning(f"Could not store agent key in keystore (will use in-memory): {ks_err}")

        managed_api_url = str(
            data.get('managed_api_url')
            or data.get('direct_api_url')
            or data.get('agent_api_url')
            or pending.get('managed_api_url')
            or pending.get('direct_api_url')
            or ''
        ).strip()
        managed_api_token = str(
            data.get('managed_api_token')
            or data.get('direct_api_token')
            or data.get('agent_api_token')
            or pending.get('managed_api_token')
            or pending.get('direct_api_token')
            or ''
        ).strip()

        if managed_api_url:
            is_valid, validation_error = _validate_managed_server_url(managed_api_url)
            if not is_valid:
                return jsonify({'success': False, 'error': validation_error}), 400

        initial_config = _get_default_agent_config(agent_id)
        if managed_api_url:
            initial_config['managed_api_url'] = managed_api_url
            initial_config['direct_api_url'] = managed_api_url
            initial_config['agent_api_url'] = managed_api_url
        if managed_api_token:
            initial_config['managed_api_token'] = managed_api_token
            initial_config['direct_api_token'] = managed_api_token
            initial_config['agent_api_token'] = managed_api_token

        # Create agent record
        agent_data = {
            'agent_id': agent_id,
            'server_id': pending['server_id'],
            'agent_name': pending['agent_name'],
            'os_type': data.get('os_type', pending['os_type']),
            'version': data.get('version', '1.0.0'),
            'hostname': data.get('hostname', ''),
            'system_info': data.get('system_info', {}),
            'capabilities': data.get('capabilities', ['audit', 'discovery']),
            'registered_at': datetime.now().isoformat(),
            'last_heartbeat': datetime.now().isoformat(),
            'status': 'online',
            'token_hash': hashlib.sha256(agent_token.encode()).hexdigest(),
            'key_validity_days': key_validity_days,
            'key_expires_at': key_expires_at,
            'key_created_at': datetime.now().isoformat(),
            'config': initial_config
        }

        _managed_agents[pending['server_id']] = agent_data

        _ensure_dirs()
        config_file = os.path.join(AGENT_CONFIG_DIR, f"{agent_id}.json")
        _write_json_secure(config_file, initial_config)

        # Create server record in database if available
        if DATABASE_AVAILABLE and _db_session:
            try:
                new_server = Server(
                    name=pending['agent_name'],
                    hostname=data.get('hostname', ''),
                    os_type=pending['os_type'],
                    connection_method='fleet-agent',
                    agent_id=agent_id,
                    status='active'
                )
                _db_session.add(new_server)

                managed_entry = _db_session.query(FleetAgent).filter(
                    FleetAgent.agent_id == agent_id
                ).first()
                if managed_entry is None:
                    managed_entry = FleetAgent(
                        agent_id=agent_id,
                        agent_type='managed',
                        name=pending['agent_name'],
                        hostname=data.get('hostname', ''),
                        os_type=data.get('os_type', pending['os_type']),
                        agent_version=data.get('version', '1.0.0'),
                        status='healthy',
                        is_active=True,
                        last_heartbeat=datetime.utcnow(),
                        registered_at=datetime.utcnow(),
                    )
                    _db_session.add(managed_entry)
                else:
                    managed_entry.name = pending['agent_name']
                    managed_entry.hostname = data.get('hostname', managed_entry.hostname)
                    managed_entry.os_type = data.get('os_type', pending['os_type'])
                    managed_entry.agent_version = data.get('version', managed_entry.agent_version)
                    managed_entry.is_active = True
                    managed_entry.last_heartbeat = datetime.utcnow()
                    managed_entry.status = 'healthy'

                _db_session.commit()
                logger.info(f"Server record created in database for agent {agent_id}")
            except Exception as db_err:
                logger.warning(f"Failed to create database record: {db_err}")

        # Mark pending registration as completed
        pending['status'] = 'completed'
        pending['agent_id'] = agent_id
        pending['completed_at'] = datetime.now().isoformat()

        # Clean up the pending token after successful registration
        del _pending_agent_registrations[registration_token]

        logger.info(f"Managed agent registration completed: {agent_id} for server {pending['agent_name']}")

        try:
            from api.agents_unified_routes import maybe_enqueue_self_update_on_register
            maybe_enqueue_self_update_on_register(agent_id)
        except Exception as enqueue_err:
            logger.warning(f"Managed registration auto-update enqueue skipped for {agent_id}: {enqueue_err}")

        return jsonify({
            'success': True,
            'agent_token': agent_token,
            'agent_id': agent_id,
            'server_id': pending['server_id'],
            'config': agent_data['config'],
            'api_version': '1.0',
            'message': 'Agent registered successfully'
        })

    except Exception as e:
        logger.error(f"Agent registration completion failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/<server_id>/status', methods=['GET'])
@require_auth_and_permission('manage_servers')
def get_fleet_agent_status(server_id):
    """
    Check registration status of a fleet agent.

    Used by the wizard to poll for agent connection after generating a token.
    """
    try:
        # Check pending registrations first
        for token, pending in _pending_agent_registrations.items():
            if pending.get('server_id') == server_id:
                if pending.get('status') == 'completed':
                    agent_data = _managed_agents.get(server_id, {})
                    return jsonify({
                        'success': True,
                        'registered': True,
                        'agent_name': pending['agent_name'],
                        'agent_id': pending.get('agent_id'),
                        'hostname': agent_data.get('hostname', ''),
                        'os_type': pending['os_type'],
                        'registered_at': pending.get('completed_at')
                    })
                else:
                    return jsonify({
                        'success': True,
                        'registered': False,
                        'agent_name': pending['agent_name'],
                        'os_type': pending['os_type'],
                        'expires_at': pending.get('expires_at')
                    })

        # Check if already registered in fleet agents
        if server_id in _managed_agents:
            agent = _managed_agents[server_id]
            return jsonify({
                'success': True,
                'registered': True,
                'agent_name': agent.get('agent_name'),
                'agent_id': agent.get('agent_id'),
                'hostname': agent.get('hostname', ''),
                'os_type': agent.get('os_type'),
                'last_heartbeat': agent.get('last_heartbeat')
            })

        # Check database
        if DATABASE_AVAILABLE and _db_session:
            try:
                server = _db_session.query(Server).filter_by(id=server_id).first()
                if server:
                    return jsonify({
                        'success': True,
                        'registered': server.status == 'active',
                        'agent_name': server.name,
                        'agent_id': server.agent_id,
                        'hostname': server.hostname,
                        'os_type': server.os_type
                    })
            except Exception as db_err:
                logger.warning(f"Database query failed: {db_err}")

        return jsonify({
            'success': False,
            'registered': False,
            'error': 'Server not found'
        }), 404

    except Exception as e:
        logger.error(f"Status check failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent Configuration Management (Server → Agent)
# ============================================================================

@fleet_agent_bp.route('/api/agent/managed/config/<agent_id>', methods=['GET'])
@require_api_key
def get_agent_config(agent_id):
    """
    Get configuration for an agent (agent pulls this)

    The agent calls this endpoint to retrieve its server-defined configuration.
    This enables remote management without direct inbound connections.

    Returns:
        - Audit schedule (when to run what)
        - Throttling settings
        - Sync settings
        - Server URL for result upload
        - Enabled audit categories
    """
    try:
        _ensure_dirs()
        config_file = os.path.join(AGENT_CONFIG_DIR, f"{agent_id}.json")

        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        else:
            # Return default configuration
            config = _get_default_agent_config(agent_id)

        storage_cfg = config.get('storage')
        if not isinstance(storage_cfg, dict):
            storage_cfg = {}
        storage_cfg.setdefault('max_local_result_files', _get_agent_local_result_max_files())
        storage_cfg.setdefault('min_free_disk_mb', _get_agent_local_min_free_disk_mb())
        storage_cfg.setdefault('min_free_disk_pct', _get_agent_local_min_free_disk_pct())
        config['storage'] = storage_cfg

        integrity = _get_managed_config_integrity_settings()

        config_security = config.get('security', {})
        if not isinstance(config_security, dict):
            config_security = {}
        config_security['enforce_signed_config'] = bool(integrity['enforce_signed_config'])
        config_security['config_max_age_seconds'] = int(integrity['config_max_age_seconds'])
        config['security'] = config_security

        # Add server metadata
        config['_metadata'] = {
            'generated_at': datetime.now().isoformat(),
            'server_version': TOOLKIT_VERSION,
            'config_version': config.get('config_version', 1)
        }

        response_payload = {
            'success': True,
            'config': config
        }

        # Sign config envelope (ECDSA or HMAC)
        can_sign_ecdsa = integrity.get('use_ecdsa') and integrity.get('ecdsa_private_key') and _CRYPTOGRAPHY_AVAILABLE
        can_sign_hmac = bool(integrity['signing_key'])

        if can_sign_ecdsa or can_sign_hmac:
            envelope = _build_config_envelope(
                config,
                integrity['signing_key'],
                use_ecdsa=integrity.get('use_ecdsa', False),
                ecdsa_private_key_pem=integrity.get('ecdsa_private_key', '')
            )
            response_payload.update({
                'config_signature': envelope['signature'],
                'config_nonce': envelope['nonce'],
                'config_issued_at': envelope['issued_at'],
                'config_payload_sha256': envelope['payload_sha256'],
                'config_envelope': envelope,
            })
        elif integrity['enforce_signed_config']:
            logger.warning(
                "Managed signed-config enforcement is enabled but no signing key is configured; "
                "config envelope cannot be generated"
            )
            _log_managed_request_auth_event(
                'managed_config_envelope',
                'warn',
                agent_id,
                'signed-config enforcement enabled but signing key not configured',
            )

        return jsonify(response_payload)

    except Exception as e:
        logger.error(f"Failed to get agent config: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/managed/config/<agent_id>', methods=['PUT'])
@require_api_key
@require_auth_and_permission('manage_agents')
def update_agent_config(agent_id):
    """
    Update configuration for an agent (admin pushes this)

    The agent will pull this config on next heartbeat/sync.

    Request body:
    {
        "schedule": {
            "enabled": true,
            "cron": "0 2 * * *",
            "audits": ["platform/baseline/*", "network/firewall/*"]
        },
        "throttle": {
            "cpu_priority": "idle",
            "min_free_memory_pct": 10,
            "max_cpu_pct": 50
        },
        "sync": {
            "auto_update_audits": true,
            "sync_interval_hours": 24
        },
        "enabled_categories": ["platform", "network", "web"],
        "disabled_audits": ["platform/baseline/example"],
        "custom_parameters": {}
    }
    """
    try:
        _ensure_dirs()
        data = request.json or {}

        config_file = os.path.join(AGENT_CONFIG_DIR, f"{agent_id}.json")

        # Load existing or create new
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
        else:
            config = _get_default_agent_config(agent_id)

        # Update with provided values
        if 'schedule' in data:
            config['schedule'] = data['schedule']
        if 'throttle' in data:
            config['throttle'] = data['throttle']
        if 'sync' in data:
            config['sync'] = data['sync']
        if 'storage' in data:
            config['storage'] = data['storage']
        if 'enabled_categories' in data:
            config['enabled_categories'] = data['enabled_categories']
        if 'disabled_audits' in data:
            config['disabled_audits'] = data['disabled_audits']
        if 'custom_parameters' in data:
            config['custom_parameters'] = data['custom_parameters']

        if 'server_url' in data:
            is_valid, validation_error = _validate_managed_server_url(data.get('server_url'))
            if not is_valid:
                return jsonify({'success': False, 'error': validation_error}), 400
            config['server_url'] = data['server_url'].strip()

        if any(k in data for k in ('managed_api_url', 'direct_api_url', 'agent_api_url')):
            direct_url = str(
                data.get('managed_api_url')
                or data.get('direct_api_url')
                or data.get('agent_api_url')
                or ''
            ).strip()
            if direct_url:
                is_valid, validation_error = _validate_managed_server_url(direct_url)
                if not is_valid:
                    return jsonify({'success': False, 'error': validation_error}), 400
            config['managed_api_url'] = direct_url
            config['direct_api_url'] = direct_url
            config['agent_api_url'] = direct_url

        if any(k in data for k in ('managed_api_token', 'direct_api_token', 'agent_api_token')):
            direct_token = str(
                data.get('managed_api_token')
                or data.get('direct_api_token')
                or data.get('agent_api_token')
                or ''
            ).strip()
            config['managed_api_token'] = direct_token
            config['direct_api_token'] = direct_token
            config['agent_api_token'] = direct_token

        # Increment version
        config['config_version'] = config.get('config_version', 0) + 1
        config['updated_at'] = datetime.now().isoformat()
        config['updated_by'] = _get_current_user()

        # Save config
        _write_json_secure(config_file, config)

        logger.info(f"Updated config for agent {agent_id}")

        return jsonify({
            'success': True,
            'message': f'Configuration updated for agent {agent_id}',
            'config_version': config['config_version']
        })

    except Exception as e:
        logger.error(f"Failed to update agent config: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _get_default_agent_config(agent_id):
    """Generate default configuration for a new agent"""
    max_local_result_files = _get_agent_local_result_max_files()
    min_free_disk_mb = _get_agent_local_min_free_disk_mb()
    min_free_disk_pct = _get_agent_local_min_free_disk_pct()
    return {
        'agent_id': agent_id,
        'config_version': 1,
        'created_at': datetime.now().isoformat(),
        'schedule': {
            'enabled': False,
            'cron': '0 2 * * *',  # 2 AM daily
            'audits': ['platform/baseline/*']
        },
        'throttle': {
            'cpu_priority': 'idle',
            'min_free_memory_pct': 10,
            'max_cpu_pct': 0,  # 0 = disabled
            'upload_rate_limit': 0,
            'batch_delay_seconds': 5
        },
        'sync': {
            'auto_update_audits': True,
            'sync_interval_hours': 24,
            'sync_on_startup': True
        },
        'storage': {
            'max_local_result_files': max_local_result_files,
            'min_free_disk_mb': min_free_disk_mb,
            'min_free_disk_pct': min_free_disk_pct,
        },
        'enabled_categories': ['platform', 'network', 'web', 'data', 'apps'],
        'disabled_audits': [],
        'custom_parameters': {}
    }


# ============================================================================
# Fleet Agent Key Management (for SuperAdmin API)
# ============================================================================

def get_all_fleet_agent_keys():
    """
    Get list of all fleet agent keys for SuperAdmin API.

    Returns:
        List of agent key info (without actual key values)
    """
    keys = []

    for server_id, agent in _managed_agents.items():
        # Check key expiration status
        status = 'active'
        key_expires = agent.get('key_expires_at')
        if key_expires:
            try:
                exp_date = datetime.fromisoformat(key_expires.replace('Z', '+00:00'))
                if exp_date < datetime.now(exp_date.tzinfo):
                    status = 'expired'
                elif (exp_date - datetime.now(exp_date.tzinfo)).days < 30:
                    status = 'expiring_soon'
            except Exception as expiry_parse_error:
                logger.debug(f"Failed to parse key expiry for fleet agent {server_id}: {expiry_parse_error}")

        # Check online status
        last_hb = agent.get('last_heartbeat')
        if last_hb:
            try:
                hb_date = datetime.fromisoformat(last_hb.replace('Z', '+00:00'))
                if hasattr(hb_date, 'tzinfo') and hb_date.tzinfo:
                    now = datetime.now(hb_date.tzinfo)
                else:
                    now = datetime.now()
                if (now - hb_date).total_seconds() > 300:  # 5 min offline threshold
                    if status == 'active':
                        status = 'offline'
            except Exception as heartbeat_parse_error:
                logger.debug(f"Failed to parse heartbeat timestamp for fleet agent {server_id}: {heartbeat_parse_error}")

        keys.append({
            'id': f"agent_{agent.get('agent_id', server_id)}",
            'agent_id': agent.get('agent_id'),
            'server_id': server_id,
            'name': agent.get('agent_name', 'Unknown Agent'),
            'type': 'agent',
            'type_name': 'Managed Server Agent',
            'os_type': agent.get('os_type', 'unknown'),
            'hostname': agent.get('hostname', ''),
            'key_preview': f"****{agent.get('token_hash', '')[-8:]}" if agent.get('token_hash') else '****',
            'created': agent.get('key_created_at') or agent.get('registered_at'),
            'expires': agent.get('key_expires_at'),
            'last_used': agent.get('last_heartbeat'),
            'status': status,
            'validity_days': agent.get('key_validity_days', 90),
            'encrypted': True
        })

    return keys


def rotate_fleet_agent_key(agent_id, rotated_by=None):
    """
    Rotate API key for a fleet agent.

    Args:
        agent_id: The agent identifier
        rotated_by: Username who initiated the rotation

    Returns:
        dict with success status and new key (if successful)
    """
    # Find agent by agent_id
    agent_entry = None
    server_id = None
    for sid, agent in _managed_agents.items():
        if agent.get('agent_id') == agent_id:
            agent_entry = agent
            server_id = sid
            break

    if not agent_entry:
        return {'success': False, 'error': 'Agent not found'}

    # Generate new token
    new_token = secrets.token_urlsafe(32)
    new_hash = hashlib.sha256(new_token.encode()).hexdigest()

    # Update agent record
    old_hash = agent_entry.get('token_hash')
    agent_entry['token_hash'] = new_hash
    agent_entry['key_created_at'] = datetime.now().isoformat()

    # Recalculate expiration if validity_days set
    validity_days = agent_entry.get('key_validity_days', 90)
    if validity_days and validity_days > 0:
        from datetime import timedelta
        agent_entry['key_expires_at'] = (datetime.now() + timedelta(days=validity_days)).isoformat()

    # Update in keystore
    try:
        from keystore import keystore
        keystore.store_key(
            key_type='agent',
            key_id=agent_id,
            value=new_token,
            metadata={
                'agent_name': agent_entry.get('agent_name'),
                'server_id': server_id,
                'os_type': agent_entry.get('os_type'),
                'hostname': agent_entry.get('hostname'),
                'key_validity_days': validity_days,
                'key_expires_at': agent_entry.get('key_expires_at'),
                'rotated_at': datetime.now().isoformat(),
                'rotated_by': rotated_by,
                'previous_hash': old_hash
            },
            created_by=rotated_by or 'system'
        )
        logger.info(f"Rotated agent key in keystore: {agent_id}")
    except Exception as ks_err:
        logger.warning(f"Could not update keystore: {ks_err}")

    logger.info(f"Managed agent key rotated for {agent_id} by {rotated_by}")

    return {
        'success': True,
        'new_key': new_token,
        'agent_id': agent_id,
        'expires': agent_entry.get('key_expires_at')
    }


def revoke_fleet_agent_key(agent_id, revoked_by=None):
    """
    Revoke API key for a fleet agent (key becomes invalid but agent record remains).

    Args:
        agent_id: The agent identifier
        revoked_by: Username who initiated the revocation

    Returns:
        dict with success status
    """
    # Find agent by agent_id
    agent_entry = None
    server_id = None
    for sid, agent in _managed_agents.items():
        if agent.get('agent_id') == agent_id:
            agent_entry = agent
            server_id = sid
            break

    if not agent_entry:
        return {'success': False, 'error': 'Agent not found'}

    # Clear the token hash to invalidate key
    agent_entry['token_hash'] = None
    agent_entry['key_revoked_at'] = datetime.now().isoformat()
    agent_entry['key_revoked_by'] = revoked_by
    agent_entry['status'] = 'revoked'

    # Remove from keystore
    try:
        from keystore import keystore
        keystore.delete_key('agent', agent_id)
        logger.info(f"Removed agent key from keystore: {agent_id}")
    except Exception as ks_err:
        logger.warning(f"Could not remove from keystore: {ks_err}")

    logger.info(f"Managed agent key revoked for {agent_id} by {revoked_by}")

    return {
        'success': True,
        'message': f'Agent key revoked for {agent_id}'
    }


def delete_fleet_agent(agent_id, deleted_by=None):
    """
    Permanently delete a fleet agent and its key.

    Args:
        agent_id: The agent identifier
        deleted_by: Username who initiated the deletion

    Returns:
        dict with success status
    """
    # Find agent by agent_id
    server_id_to_delete = None
    for sid, agent in _managed_agents.items():
        if agent.get('agent_id') == agent_id:
            server_id_to_delete = sid
            break

    if not server_id_to_delete:
        return {'success': False, 'error': 'Agent not found'}

    # Remove from in-memory store
    agent_entry = _managed_agents.pop(server_id_to_delete, None)

    # Remove from keystore
    try:
        from keystore import keystore
        keystore.delete_key('agent', agent_id)
        logger.info(f"Removed agent key from keystore: {agent_id}")
    except Exception as ks_err:
        logger.warning(f"Could not remove from keystore: {ks_err}")

    # Remove server record from database if exists
    if DATABASE_AVAILABLE and _db_session:
        try:
            server = _db_session.query(Server).filter_by(agent_id=agent_id).first()
            if server:
                _db_session.delete(server)
                _db_session.commit()
                logger.info(f"Removed server record for agent: {agent_id}")
        except Exception as db_err:
            logger.warning(f"Could not remove server record: {db_err}")

    logger.info(f"Managed agent {agent_id} permanently deleted by {deleted_by}")

    return {
        'success': True,
        'message': f'Agent {agent_id} permanently deleted'
    }


# ============================================================================
# Fleet Agent Heartbeat & Communication
# ============================================================================

@fleet_agent_bp.route('/api/managed-agent/<agent_id>/heartbeat', methods=['POST'])
@require_api_key
def fleet_agent_heartbeat(agent_id):
    """
    Receive heartbeat from fleet agent and return pending commands.

    Request body:
    {
        "status": "idle|running|error",
        "timestamp": "ISO timestamp"
    }
    """
    try:
        signature_ok, signature_error = _verify_managed_request_signature(agent_id=agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        # Find agent by agent_id in the fleet agents
        agent_entry = None
        server_id = None
        for sid, agent in _managed_agents.items():
            if agent.get('agent_id') == agent_id:
                agent_entry = agent
                server_id = sid
                break

        if not agent_entry:
            return jsonify({'success': False, 'error': 'Agent not registered'}), 404

        data = request.get_json() or {}

        # Update agent status
        agent_entry['last_heartbeat'] = datetime.now().isoformat()
        agent_entry['status'] = data.get('status', 'online')

        # Keep unified registry (FleetAgent table) heartbeat fresh
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type='managed',
                hostname=agent_entry.get('hostname') or data.get('hostname'),
                name=agent_entry.get('agent_name') or agent_entry.get('hostname') or agent_id,
                os_type=agent_entry.get('os_type'),
                agent_version=agent_entry.get('version'),
                status=agent_entry.get('status'),
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during managed heartbeat for {agent_id}: {sync_err}")

        return jsonify({
            'success': True,
            'commands': [],  # Placeholder for command queue
            'config_version': agent_entry['config'].get('config_version', 1)
        })

    except Exception as e:
        logger.error(f"Managed agent heartbeat failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/install.sh', methods=['GET'])
def download_fleet_agent_install_script_linux():
    """
    Download Linux installation script for fleet agent.

    Query params:
        server: Server URL (optional, will auto-detect)
        token: Registration token (required for auto-register)
    """
    try:
        server_url = request.args.get('server') or request.host_url.rstrip('/')
        token = request.args.get('token', '')

        is_valid, validation_error = _validate_managed_server_url(server_url)
        if not is_valid:
            return jsonify({'error': validation_error}), 400

        script = f'''#!/bin/bash
# Fleet Agent Installation Script
# Generated by Security Audit Toolkit

set -e

SERVER_URL="{server_url}"
REGISTRATION_TOKEN="{token}"
INSTALL_DIR="/opt/audit-agent"
SERVICE_NAME="audit-agent"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --server) SERVER_URL="$2"; shift 2 ;;
        --token) REGISTRATION_TOKEN="$2"; shift 2 ;;
        --install-dir) INSTALL_DIR="$2"; shift 2 ;;
        *) shift ;;
    esac
done

echo "🔧 Installing Security Audit Fleet Agent..."
echo "Server: $SERVER_URL"

# Create install directory
sudo mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# Download agent package
echo "📦 Downloading agent package..."
curl -fsSL "$SERVER_URL/api/agent/download/linux?format=package" -o agent-package.tar.gz
tar xzf agent-package.tar.gz
rm agent-package.tar.gz

# Make scripts executable
chmod +x *.sh

# Register with server if token provided
if [ -n "$REGISTRATION_TOKEN" ]; then
    echo "🔑 Registering with server..."

    HOSTNAME=$(hostname -f 2>/dev/null || hostname)
    OS_TYPE="linux"
    VERSION="{TOOLKIT_VERSION}"

    RESPONSE=$(curl -sS -X POST "$SERVER_URL/api/managed-agent/register/complete" \\
        -H "Content-Type: application/json" \\
        -d '{{"registration_token":"'"$REGISTRATION_TOKEN"'","hostname":"'"$HOSTNAME"'","os_type":"'"$OS_TYPE"'","version":"'"$VERSION"'"}}' 2>&1)

    if echo "$RESPONSE" | grep -q '"success":true'; then
        AGENT_TOKEN=$(echo "$RESPONSE" | grep -o '"agent_token":"[^"]*"' | cut -d'"' -f4)
        AGENT_ID=$(echo "$RESPONSE" | grep -o '"agent_id":"[^"]*"' | cut -d'"' -f4)
        SERVER_ID=$(echo "$RESPONSE" | grep -o '"server_id":"[^"]*"' | cut -d'"' -f4)

        # Save configuration
        cat > "$INSTALL_DIR/config.json" <<EOF
{{
    "server_url": "$SERVER_URL",
    "agent_id": "$AGENT_ID",
    "server_id": "$SERVER_ID",
    "api_key": "$AGENT_TOKEN",
    "poll_interval": 60,
    "auto_update": true
}}
EOF
        chmod 600 "$INSTALL_DIR/config.json"

        echo "✅ Agent registered successfully!"
        echo "   Agent ID: $AGENT_ID"
    else
        echo "❌ Registration failed: $RESPONSE"
        exit 1
    fi
fi

# Install systemd service (if available)
if command -v systemctl &> /dev/null; then
    echo "🔧 Installing systemd service..."
    sudo tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null <<EOF
[Unit]
Description=Security Audit Fleet Agent
After=network.target

[Service]
Type=simple
ExecStart=$INSTALL_DIR/fleet-agent.sh daemon
WorkingDirectory=$INSTALL_DIR
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable $SERVICE_NAME
    sudo systemctl start $SERVICE_NAME
    echo "✅ Service installed and started"
else
    echo "⚠️  No systemd found. Please run the agent manually."
fi

echo ""
echo "✅ Installation complete!"
echo "   Install dir: $INSTALL_DIR"
echo "   Run 'systemctl status $SERVICE_NAME' to check status"
'''

        return Response(
            script,
            mimetype='text/x-shellscript',
            headers={'Content-Disposition': 'attachment; filename=install-fleet-agent.sh'}
        )

    except Exception as e:
        logger.error(f"Failed to generate install script: {e}")
        return jsonify({'error': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/install.ps1', methods=['GET'])
def download_fleet_agent_install_script_windows():
    """
    Download Windows installation script for fleet agent.

    Query params:
        server: Server URL (optional, will auto-detect)
        token: Registration token (required for auto-register)
    """
    try:
        server_url = request.args.get('server') or request.host_url.rstrip('/')
        token = request.args.get('token', '')

        is_valid, validation_error = _validate_managed_server_url(server_url)
        if not is_valid:
            return jsonify({'error': validation_error}), 400

        safe_server_url = _escape_powershell_double_quoted_literal(server_url)
        safe_token = _escape_powershell_double_quoted_literal(token)

        script = f'''# Fleet Agent Installation Script - Windows
# Generated by Security Audit Toolkit

[CmdletBinding()]
param(
    [Parameter()]
    [string]$Server = "{safe_server_url}",

    [Parameter()]
    [string]$Token = "{safe_token}",

    [Parameter()]
    [string]$InstallDir = "$env:ProgramFiles\\AuditAgent"
)

$ErrorActionPreference = "Stop"

function Install-FleetAgent {{
    param(
        [string]$Server,
        [string]$Token,
        [string]$InstallDir = "$env:ProgramFiles\\AuditAgent"
    )

    Write-Host "🔧 Installing Security Audit Fleet Agent..." -ForegroundColor Cyan
    Write-Host "Server: $Server"

    # Create install directory
    if (-not (Test-Path $InstallDir)) {{
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    }}
    Set-Location $InstallDir

    # Download agent package
    Write-Host "📦 Downloading agent package..."
    $packageUrl = "$Server/api/agent/download/windows?format=package"
    $zipPath = Join-Path $InstallDir "agent-package.zip"
    Invoke-WebRequest -Uri $packageUrl -OutFile $zipPath -UseBasicParsing
    Expand-Archive -Path $zipPath -DestinationPath $InstallDir -Force
    Remove-Item $zipPath

    # Register with server if token provided
    if ($Token) {{
        Write-Host "🔑 Registering with server..."

        $hostname = $env:COMPUTERNAME
        $osType = "windows"
        $version = "{TOOLKIT_VERSION}"

        $body = @{{
            registration_token = $Token
            hostname = $hostname
            os_type = $osType
            version = $version
        }} | ConvertTo-Json

        try {{
            $response = Invoke-RestMethod -Uri "$Server/api/managed-agent/register/complete" `
                -Method POST -Body $body -ContentType "application/json"

            if ($response.success) {{
                # Save configuration
                $config = @{{
                    server_url = $Server
                    agent_id = $response.agent_id
                    server_id = $response.server_id
                    api_key = $response.agent_token
                    poll_interval = 60
                    auto_update = $true
                }} | ConvertTo-Json

                $configPath = Join-Path $InstallDir "config.json"
                $config | Out-File -FilePath $configPath -Encoding UTF8

                # Secure the config file
                $acl = Get-Acl $configPath
                $acl.SetAccessRuleProtection($true, $false)
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    "SYSTEM", "FullControl", "Allow")
                $acl.AddAccessRule($rule)
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    "Administrators", "FullControl", "Allow")
                $acl.AddAccessRule($rule)
                Set-Acl -Path $configPath -AclObject $acl

                Write-Host "✅ Agent registered successfully!" -ForegroundColor Green
                Write-Host "   Agent ID: $($response.agent_id)"
            }} else {{
                throw "Registration failed: $($response.error)"
            }}
        }} catch {{
            Write-Host "❌ Registration failed: $_" -ForegroundColor Red
            exit 1
        }}
    }}

    # Install Windows Service
    Write-Host "🔧 Installing Windows Service..."
    $serviceName = "AuditAgent"
    $serviceDisplay = "Security Audit Fleet Agent"
    $servicePath = Join-Path $InstallDir "fleet-agent.ps1"

    # Use NSSM or create scheduled task based on availability
    if (Get-Command nssm -ErrorAction SilentlyContinue) {{
        nssm install $serviceName powershell.exe "-ExecutionPolicy Bypass -File `"$servicePath`" daemon"
        nssm set $serviceName DisplayName $serviceDisplay
        nssm set $serviceName Start SERVICE_AUTO_START
        nssm start $serviceName
    }} else {{
        # Fallback to Scheduled Task
        $action = New-ScheduledTaskAction -Execute "powershell.exe" `
            -Argument "-ExecutionPolicy Bypass -File `"$servicePath`" daemon" `
            -WorkingDirectory $InstallDir
        $trigger = New-ScheduledTaskTrigger -AtStartup
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)

        Register-ScheduledTask -TaskName $serviceName -Action $action `
            -Trigger $trigger -Principal $principal -Settings $settings -Force
        Start-ScheduledTask -TaskName $serviceName
    }}

    Write-Host "" -ForegroundColor Green
    Write-Host "✅ Installation complete!" -ForegroundColor Green
    Write-Host "   Install dir: $InstallDir"
}}

# Run installation
Install-FleetAgent -Server $Server -Token $Token -InstallDir $InstallDir
'''  # nosec B608

        return Response(
            script,
            mimetype='text/plain',
            headers={'Content-Disposition': 'attachment; filename=Install-FleetAgent.ps1'}
        )

    except Exception as e:
        logger.error(f"Failed to generate install script: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Audit Script Synchronization (Server → Agent)
# ============================================================================

@fleet_agent_bp.route('/api/agent/managed/sync/manifest', methods=['GET'])
@require_api_key
def get_audit_manifest():
    """
    Get manifest of all available audits with checksums

    Agent uses this to determine which scripts need updating.

    Query params:
        os_type: linux or windows (filters relevant audits)
        category: optional category filter
    """
    try:
        os_type = request.args.get('os_type', 'linux')
        category_filter = request.args.get('category', '')

        manifest = {
            'generated_at': datetime.now().isoformat(),
            'server_version': TOOLKIT_VERSION,
            'os_type': os_type,
            'audits': []
        }

        # Determine audit directory based on OS
        if os_type.startswith('windows'):
            audit_dirs = [
                os.path.join(AUDITS_DIR, 'windows'),
            ]
            extension = '.ps1'
        else:
            audit_dirs = [
                os.path.join(AUDITS_DIR, 'linux'),
                os.path.join(ROOT_DIR, 'audits'),  # Legacy path
            ]
            extension = '.sh'

        # Also include lib files for dependencies
        lib_dir = os.path.join(ROOT_DIR, 'lib')

        seen_paths = set()

        for audit_dir in audit_dirs:
            if not os.path.exists(audit_dir):
                continue

            for root, dirs, files in os.walk(audit_dir):
                # Skip hidden directories
                dirs[:] = [d for d in dirs if not d.startswith('.')]

                for file in files:
                    if not file.endswith(extension):
                        continue

                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, ROOT_DIR)

                    # Skip duplicates
                    if rel_path in seen_paths:
                        continue
                    seen_paths.add(rel_path)

                    # Extract category from path
                    path_parts = rel_path.replace('\\', '/').split('/')
                    if len(path_parts) > 2:
                        audit_category = path_parts[1] if path_parts[0] == 'audits' else path_parts[0]
                    else:
                        audit_category = 'uncategorized'

                    # Apply category filter
                    if category_filter and audit_category != category_filter:
                        continue

                    # Calculate checksum
                    checksum = _calculate_file_checksum(file_path)

                    manifest['audits'].append({
                        'path': rel_path.replace('\\', '/'),
                        'name': file.replace(extension, ''),
                        'category': audit_category,
                        'checksum': checksum,
                        'size': os.path.getsize(file_path),
                        'modified': datetime.fromtimestamp(
                            os.path.getmtime(file_path)
                        ).isoformat()
                    })

        # Add lib files to manifest
        if os.path.exists(lib_dir) and os_type != 'windows':
            for file in os.listdir(lib_dir):
                if file.endswith('.sh'):
                    file_path = os.path.join(lib_dir, file)
                    rel_path = f"lib/{file}"

                    manifest['audits'].append({
                        'path': rel_path,
                        'name': file.replace('.sh', ''),
                        'category': '_lib',
                        'checksum': _calculate_file_checksum(file_path),
                        'size': os.path.getsize(file_path),
                        'modified': datetime.fromtimestamp(
                            os.path.getmtime(file_path)
                        ).isoformat()
                    })

        manifest['total_count'] = len(manifest['audits'])

        return jsonify({
            'success': True,
            'manifest': manifest
        })

    except Exception as e:
        logger.error(f"Failed to generate audit manifest: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/managed/sync/download', methods=['POST'])
@require_api_key
def download_audit_files():
    """
    Download specific audit files as a package

    Agent sends list of files it needs, server returns zip/tar.

    Request body:
    {
        "files": ["audits/linux/platform/baseline/updates.sh", "lib/common.sh"],
        "format": "tar.gz" | "zip"
    }
    """
    try:
        data = request.json or {}
        files = data.get('files', [])
        pkg_format = data.get('format', 'tar.gz')

        if not files:
            return jsonify({'success': False, 'error': 'No files specified'}), 400

        # Validate and collect files
        valid_files = []
        for file_path in files:
            # Security: prevent path traversal
            file_path = file_path.replace('..', '').strip('/')
            full_path = os.path.join(ROOT_DIR, file_path)

            # Verify file exists and is within allowed directories
            real_path = os.path.realpath(full_path)
            allowed_prefixes = [
                os.path.realpath(AUDITS_DIR),
                os.path.realpath(os.path.join(ROOT_DIR, 'lib')),
                os.path.realpath(STANDALONE_AGENT_DIR),
                os.path.realpath(FLEET_AGENT_DIR),
            ]

            if not any(real_path.startswith(p) for p in allowed_prefixes):
                logger.warning(f"Blocked access to: {file_path}")
                continue

            if os.path.exists(full_path) and os.path.isfile(full_path):
                valid_files.append((file_path, full_path))

        if not valid_files:
            return jsonify({'success': False, 'error': 'No valid files found'}), 404

        # Create package
        with tempfile.NamedTemporaryFile(delete=False, suffix=f'.{pkg_format}') as tmp:
            if pkg_format == 'zip':
                with zipfile.ZipFile(tmp.name, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for rel_path, full_path in valid_files:
                        zf.write(full_path, rel_path)
            else:
                with tarfile.open(tmp.name, 'w:gz') as tar:
                    for rel_path, full_path in valid_files:
                        tar.add(full_path, arcname=rel_path)

            return send_file(
                tmp.name,
                as_attachment=True,
                download_name=f'audit-sync.{pkg_format}',
                mimetype='application/gzip' if pkg_format == 'tar.gz' else 'application/zip'
            )

    except Exception as e:
        logger.error(f"Failed to create sync package: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# License Token Generation for Audit Scripts
# ============================================================================

# Tier-based token validity for offline operation
# Higher tiers get longer offline periods for standalone/air-gapped deployments
TIER_TOKEN_VALIDITY_DAYS = {
    'free': 7,           # Must maintain frequent connection
    'trial': 14,         # Short evaluation period
    'starter': 30,       # Occasional disconnection
    'professional': 90,  # Extended offline periods
    'business': 365,     # Air-gapped environments
    'enterprise': 365,   # Fully standalone capable
}


def _generate_license_token(machine_fingerprint: str, tier: str = None, days_valid: int = None, agent_type: str = 'managed') -> dict:
    """
    Generate a license token for audit script execution.

    Token is bound to machine fingerprint and has tier-based validity.
    Standalone agents get the full tier validity period for offline operation.
    Managed agents can request shorter validity for security.

    Args:
        machine_fingerprint: SHA256 hash of machine ID from agent
        tier: License tier (defaults to current license)
        days_valid: Override validity (capped at tier maximum)
        agent_type: 'managed' or 'standalone' - standalone gets full tier validity

    Returns:
        Token dict with machine_id, tier, issued, expires, features, signature
    """
    from services_pkg.services.license_service import get_license_service

    # Get current license status
    license_svc = get_license_service()
    status = license_svc.get_status()

    if tier is None:
        tier = status['license']['tier']

    # Determine validity based on tier
    tier_max_validity = TIER_TOKEN_VALIDITY_DAYS.get(tier.lower(), 7)

    # Standalone agents get full tier validity for offline operation
    if agent_type == 'standalone':
        actual_validity = tier_max_validity
    elif days_valid is not None:
        # Managed agents can request shorter validity (capped at tier max)
        actual_validity = min(days_valid, tier_max_validity)
    else:
        # Default for managed: 7 days or tier max if lower
        actual_validity = min(7, tier_max_validity)

    issued = datetime.utcnow()
    expires = issued + timedelta(days=actual_validity)

    # Determine features based on tier
    tier_features = {
        'free': ['audit_linux_basic'],
        'trial': ['audit_linux', 'audit_windows', 'audit_network'],
        'starter': ['audit_linux', 'audit_windows'],
        'professional': ['audit_linux', 'audit_windows', 'audit_network', 'audit_compliance'],
        'business': ['audit_linux', 'audit_windows', 'audit_network', 'audit_compliance', 'audit_cloud'],
        'enterprise': ['audit_linux', 'audit_windows', 'audit_network', 'audit_compliance', 'audit_cloud', 'audit_custom'],
    }
    features = tier_features.get(tier.lower(), ['audit_linux_basic'])

    # Create token payload
    token = {
        'machine_id': machine_fingerprint,
        'tier': tier,
        'issued': issued.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'expires': expires.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'features': features,
    }

    # Sign token with HMAC-SHA256
    # Combines local key part with server-side secret
    payload = f"{machine_fingerprint}|{tier}|{token['issued']}|{token['expires']}"

    # Use a configurable signing key
    signing_key = os.environ.get('AUDIT_TOKEN_SIGNING_KEY', 'audit-toolkit-default-signing-key-change-me')
    local_key_part = 'audit-toolkit-v5-local'  # Matches token.sh
    combined_key = f"{local_key_part}:{signing_key}"

    signature = hmac.new(
        combined_key.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    token['signature'] = signature

    return token


@fleet_agent_bp.route('/api/agent/managed/sync/license-token', methods=['POST'])
@require_api_key
def generate_agent_license_token():
    """
    Generate a license token for audit script execution on agent.

    The token is bound to the agent's machine fingerprint. Validity period
    depends on license tier and agent type:

    - Standalone agents: Get full tier validity (up to 365 days for Enterprise)
    - Managed agents: Default 7 days, can request up to tier max

    This allows standalone agents to operate completely offline for extended
    periods while fleet agents maintain tighter security with frequent refresh.

    Request body:
        {
            "machine_fingerprint": "<sha256 hash of machine id>",
            "agent_type": "standalone",  // or "managed" (default)
            "days_valid": 7  // Optional, for fleet agents only
        }

    Returns:
        {
            "success": true,
            "token": {
                "machine_id": "...",
                "tier": "professional",
                "issued": "2026-02-24T00:00:00Z",
                "expires": "2026-05-25T00:00:00Z",  // 90 days for professional standalone
                "features": [...],
                "signature": "..."
            },
            "validity_days": 90,
            "agent_type": "standalone",
            "offline_capable": true
        }
    """
    try:
        data = request.get_json() or {}

        machine_fingerprint = data.get('machine_fingerprint', '').strip()
        if not machine_fingerprint:
            return jsonify({
                'success': False,
                'error': 'machine_fingerprint is required'
            }), 400

        # Validate fingerprint format (should be hex SHA256)
        if len(machine_fingerprint) != 64 or not all(c in '0123456789abcdef' for c in machine_fingerprint.lower()):
            return jsonify({
                'success': False,
                'error': 'Invalid machine_fingerprint format (expected SHA256 hex)'
            }), 400

        # Determine agent type
        agent_type = data.get('agent_type', 'managed').lower()
        if agent_type not in ('managed', 'standalone'):
            agent_type = 'managed'

        # Get days_valid for fleet agents (standalone uses tier default)
        days_valid = data.get('days_valid')
        if days_valid is not None:
            days_valid = int(days_valid)

        token = _generate_license_token(
            machine_fingerprint=machine_fingerprint,
            days_valid=days_valid,
            agent_type=agent_type
        )

        # Calculate actual validity from token
        from datetime import datetime
        issued = datetime.strptime(token['issued'], '%Y-%m-%dT%H:%M:%SZ')
        expires = datetime.strptime(token['expires'], '%Y-%m-%dT%H:%M:%SZ')
        actual_validity = (expires - issued).days

        logger.info(f"Generated {agent_type} license token for machine {machine_fingerprint[:16]}... valid for {actual_validity} days")

        return jsonify({
            'success': True,
            'token': token,
            'validity_days': actual_validity,
            'agent_type': agent_type,
            'offline_capable': actual_validity >= 30  # 30+ days = good offline support
        })

    except Exception as e:
        logger.error(f"Failed to generate license token: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/managed/sync/full-package', methods=['GET'])
@require_api_key
def download_full_audit_package():
    """
    Download complete audit package for initial sync or full update

    Query params:
        os_type: linux or windows
        include_lib: true/false (include lib/ directory)
        machine_fingerprint: SHA256 for license token binding
        agent_type: managed or standalone (affects token validity)
    """
    try:
        os_type = request.args.get('os_type', 'linux')
        include_lib = request.args.get('include_lib', 'true').lower() == 'true'
        machine_fingerprint = request.args.get('machine_fingerprint', '')
        agent_type = request.args.get('agent_type', 'managed')

        with tempfile.NamedTemporaryFile(delete=False, suffix='.tar.gz') as tmp:
            with tarfile.open(tmp.name, 'w:gz') as tar:
                # Add OS-specific audits
                if os_type.startswith('windows'):
                    audit_path = os.path.join(AUDITS_DIR, 'windows')
                    if os.path.exists(audit_path):
                        tar.add(audit_path, arcname='audits/windows')
                else:
                    audit_path = os.path.join(AUDITS_DIR, 'linux')
                    if os.path.exists(audit_path):
                        tar.add(audit_path, arcname='audits/linux')

                # Add lib directory if requested
                if include_lib:
                    lib_path = os.path.join(ROOT_DIR, 'lib')
                    if os.path.exists(lib_path):
                        tar.add(lib_path, arcname='lib')

                # Add manifest
                manifest = _generate_package_manifest(os_type)
                manifest_bytes = json.dumps(manifest, indent=2).encode('utf-8')

                import io
                manifest_info = tarfile.TarInfo(name='manifest.json')
                manifest_info.size = len(manifest_bytes)
                tar.addfile(manifest_info, io.BytesIO(manifest_bytes))

                # Generate and include license token if machine fingerprint provided
                if machine_fingerprint and len(machine_fingerprint) == 64:
                    token = _generate_license_token(
                        machine_fingerprint=machine_fingerprint,
                        agent_type=agent_type
                    )
                    token_bytes = json.dumps(token, indent=2).encode('utf-8')
                    token_info = tarfile.TarInfo(name='license.token')
                    token_info.size = len(token_bytes)
                    tar.addfile(token_info, io.BytesIO(token_bytes))

                    logger.info(f"Included license token in package for {machine_fingerprint[:16]}...")

            return send_file(
                tmp.name,
                as_attachment=True,
                download_name=f'audit-toolkit-{os_type}.tar.gz',
                mimetype='application/gzip'
            )

    except Exception as e:
        logger.error(f"Failed to create full package: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _generate_package_manifest(os_type):
    """Generate manifest for included package"""
    return {
        'generated_at': datetime.now().isoformat(),
        'server_version': TOOLKIT_VERSION,
        'os_type': os_type,
        'package_type': 'full'
    }


# ============================================================================
# Result Ingestion (Agent → Server → Database)
# ============================================================================

@fleet_agent_bp.route('/api/agent/managed/results/ingest', methods=['POST'])
@require_api_key
@conditional_limit(get_managed_upload_limit)
def ingest_audit_results():
    """
    Ingest audit results from agent into database

    Results are stored in the same audit_executions table as SSH/WinRM results,
    enabling unified reporting and analytics.

    Request body:
    {
        "agent_id": "abc123",
        "hostname": "WORKSTATION-01",
        "results": [
            {
                "audit_path": "platform/baseline/updates",
                "executed_at": "2026-02-17T10:30:00Z",
                "completed_at": "2026-02-17T10:30:45Z",
                "exit_code": 0,
                "status": "success",
                "output": "...",
                "summary": {
                    "total": 10,
                    "pass": 8,
                    "warn": 1,
                    "fail": 1,
                    "skip": 0
                },
                "checks": [
                    {"name": "Check 1", "status": "PASS", "message": "All good"},
                    {"name": "Check 2", "status": "FAIL", "message": "Issue found"}
                ]
            }
        ]
    }
    """
    try:
        signature_ok, signature_error = _verify_managed_request_signature()
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        limits = _get_result_ingest_limits()
        max_body_bytes = limits['max_body_kb'] * 1024
        body_raw = request.get_data(cache=True, as_text=False) or b''
        if len(body_raw) > max_body_bytes:
            return jsonify({
                'success': False,
                'error': 'Request body too large',
                'limit_kb': limits['max_body_kb']
            }), 413

        disk_blocked, disk_details = _is_result_ingest_blocked_by_disk_watermark()
        if disk_blocked:
            logger.warning(f"Rejecting managed ingest due to low disk watermark: {disk_details}")
            return jsonify({
                'success': False,
                'error': 'Insufficient storage capacity on core',
                'details': disk_details
            }), 507

        data = request.get_json(silent=True)
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request body'}), 400

        agent_id = data.get('agent_id')
        hostname = data.get('hostname')
        results = data.get('results', [])

        if not agent_id or not hostname:
            return jsonify({'success': False, 'error': 'agent_id and hostname required'}), 400

        if not results:
            return jsonify({'success': False, 'error': 'No results provided'}), 400

        if not isinstance(results, list):
            return jsonify({'success': False, 'error': 'results must be an array'}), 400

        if len(results) > limits['max_results_per_request']:
            return jsonify({
                'success': False,
                'error': 'Too many results in request',
                'limit': limits['max_results_per_request']
            }), 400

        for index, result in enumerate(results):
            checks = result.get('checks', []) if isinstance(result, dict) else []
            if isinstance(checks, list) and len(checks) > limits['max_checks_per_result']:
                return jsonify({
                    'success': False,
                    'error': f'Result at index {index} exceeds checks limit',
                    'limit': limits['max_checks_per_result']
                }), 400

            output = result.get('output') if isinstance(result, dict) else None
            if output is not None and len(str(output)) > limits['max_output_chars']:
                return jsonify({
                    'success': False,
                    'error': f'Result at index {index} output exceeds size limit',
                    'limit_chars': limits['max_output_chars']
                }), 400

        ingested = []
        errors = []

        for result in results:
            try:
                execution_id = _ingest_single_result(agent_id, hostname, result)
                ingested.append({
                    'audit_path': result.get('audit_path'),
                    'execution_id': execution_id,
                    'status': 'ingested'
                })
            except Exception as e:
                errors.append({
                    'audit_path': result.get('audit_path'),
                    'error': str(e)
                })

        # Update agent last_seen
        _update_agent_status(agent_id, hostname, len(ingested))

        return jsonify({
            'success': True,
            'ingested': ingested,
            'errors': errors,
            'total_ingested': len(ingested),
            'total_errors': len(errors)
        })

    except Exception as e:
        logger.error(f"Failed to ingest results: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _ingest_single_result(agent_id, hostname, result):
    """
    Ingest a single audit result into database

    Maps agent result format to AuditExecution model.
    """
    audit_path = result.get('audit_path', '')

    if DATABASE_AVAILABLE and _db_session:
        # Database mode - insert into audit_executions table
        return _ingest_to_database(agent_id, hostname, result)
    else:
        # File mode - store as JSON (fallback)
        return _ingest_to_file(agent_id, hostname, result)


def _ingest_to_database(agent_id, hostname, result):
    """Insert result into database audit_executions table"""
    try:
        session = _db_session()

        # Initialize result encryption handler (Phase 2)
        result_encryptor = ResultEncryption()
        should_encrypt = result_encryptor.should_encrypt_result()

        # Find or create server record for this agent
        server = session.query(Server).filter(
            (Server.agent_id == agent_id) |
            (Server.hostname == hostname)
        ).first()

        if not server:
            # Create server record for unregistered agent
            server = Server(
                name=hostname,
                hostname=hostname,
                port=0,  # No SSH port for agent
                username='agent',
                connection_method='fleet-agent',
                agent_id=agent_id,
                description=f'Auto-created from agent {agent_id}'
            )
            session.add(server)
            session.flush()

        # Find or create audit record
        audit_path = result.get('audit_path', 'unknown')
        audit_name = os.path.basename(audit_path)

        audit = session.query(Audit).filter(
            Audit.file_path.contains(audit_path)
        ).first()

        if not audit:
            # Parse category from path
            path_parts = audit_path.replace('\\', '/').split('/')
            domain = path_parts[0] if path_parts else 'unknown'
            category = path_parts[1] if len(path_parts) > 1 else 'unknown'

            audit = Audit(
                name=audit_name,
                domain=domain,
                category=category,
                file_path=audit_path,
                description='Audit from agent results'
            )
            session.add(audit)
            session.flush()

        # Resolve execution record. When the queued execution_id is present, update it
        # in place instead of creating a duplicate row.
        summary = result.get('summary', {})
        summary_json = json.dumps(summary) if isinstance(summary, dict) else summary
        execution_id = result.get('execution_id')

        executed_at = result.get('executed_at')
        if isinstance(executed_at, str):
            try:
                executed_at = datetime.fromisoformat(executed_at.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                executed_at = datetime.utcnow()

        completed_at = result.get('completed_at')
        if isinstance(completed_at, str):
            try:
                completed_at = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                completed_at = datetime.utcnow()

        # Calculate duration
        duration = None
        if executed_at and completed_at:
            duration = (completed_at - executed_at).total_seconds()

        # Prepare output (encrypt if enabled)
        output_data = result.get('output', '')
        if should_encrypt:
            # Create a result wrapper with metadata and output for encryption
            result_wrapper = {
                'output': output_data,
                'checks': result.get('checks', []),
                'metadata': {
                    'agent_id': agent_id,
                    'hostname': hostname,
                    'audit_path': audit_path,
                    'status': result.get('status', 'success'),
                    'exit_code': result.get('exit_code', 0)
                }
            }

            # Encrypt the wrapper
            encrypted_wrapper = result_encryptor.encrypt(result_wrapper, agent_id)
            if encrypted_wrapper:
                output_data = json.dumps(encrypted_wrapper)
                logger.info(f"Result encrypted for agent {agent_id} (method={encrypted_wrapper.get('_encryption_derivation')})")
            else:
                logger.warning(f"Failed to encrypt result for agent {agent_id}, storing unencrypted")

        execution = None
        if execution_id is not None:
            execution = session.query(AuditExecution).filter(
                AuditExecution.id == execution_id
            ).first()

        if execution is None:
            execution = AuditExecution(
                server_id=server.id,
                audit_id=audit.id,
                status=result.get('status', 'success'),
                exit_code=result.get('exit_code', 0),
                output=output_data,
                summary=summary_json,
                duration_seconds=duration,
                executed_by=f'agent:{agent_id}',
                executed_at=executed_at or datetime.utcnow(),
                completed_at=completed_at
            )
            session.add(execution)
        else:
            execution.server_id = server.id
            execution.audit_id = audit.id
            execution.status = result.get('status', 'success')
            execution.exit_code = result.get('exit_code', 0)
            execution.output = output_data
            execution.summary = summary_json
            execution.duration_seconds = duration
            execution.executed_by = f'agent:{agent_id}'
            execution.executed_at = executed_at or execution.executed_at or datetime.utcnow()
            execution.completed_at = completed_at

        execution.server = server
        execution.audit = audit
        session.flush()
        _persist_reporting_audit_execution(session, execution)
        session.commit()

        logger.info(f"Ingested result to database: execution_id={execution.id}, encrypted={should_encrypt}")
        return execution.id

    except Exception as e:
        session.rollback()
        logger.error(f"Database ingestion failed: {e}")
        raise


def _ingest_to_file(agent_id, hostname, result):
    """Fallback: store result as JSON file (optionally encrypted)"""
    _ensure_dirs()

    result_encryptor = ResultEncryption()
    should_encrypt = result_encryptor.should_encrypt_result()

    results_dir = os.path.join(ROOT_DIR, 'data', 'agent_results', hostname)
    os.makedirs(results_dir, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    audit_name = result.get('audit_path', 'unknown').replace('/', '_').replace('\\', '_')

    result_file = os.path.join(results_dir, f"{audit_name}_{timestamp}.json")

    # Format for compatibility with reporting system
    formatted_result = {
        'agent_id': agent_id,
        'hostname': hostname,
        'source': 'fleet_agent',
        'ingested_at': datetime.now().isoformat(),
        'execution': {
            'audit_path': result.get('audit_path'),
            'executed_at': result.get('executed_at'),
            'completed_at': result.get('completed_at'),
            'status': result.get('status'),
            'exit_code': result.get('exit_code'),
            'output': result.get('output'),
            'summary': result.get('summary'),
            'checks': result.get('checks', [])
        }
    }

    # Encrypt if enabled
    if should_encrypt:
        encrypted_wrapper = result_encryptor.encrypt(formatted_result, agent_id)
        if encrypted_wrapper:
            formatted_result = encrypted_wrapper
            logger.info(f"Result encrypted to file for agent {agent_id}")
        else:
            logger.warning(f"Failed to encrypt result for agent {agent_id}, storing unencrypted")

    with open(result_file, 'w') as f:
        json.dump(formatted_result, f, indent=2, default=str)

    max_files = _get_max_managed_result_files_per_host()
    pruned = _prune_result_files_for_host(results_dir, max_files)
    if pruned > 0:
        logger.info(
            f"Pruned {pruned} fleet-agent fallback result files for host {hostname} "
            f"(max_files={max_files})"
        )

    logger.info(f"Ingested result to file: {result_file}, encrypted={should_encrypt}")
    return result_file


def _update_agent_status(agent_id, hostname, results_count):
    """Update agent's last activity status"""
    try:
        agent_file = os.path.join(AGENTS_DIR, f"{agent_id}.json")

        if os.path.exists(agent_file):
            with open(agent_file, 'r') as f:
                agent = json.load(f)
        else:
            agent = {
                'agent_id': agent_id,
                'hostname': hostname,
                'created_at': datetime.now().isoformat()
            }

        agent['last_seen'] = datetime.now().isoformat()
        agent['last_result_upload'] = datetime.now().isoformat()
        agent['total_results_uploaded'] = agent.get('total_results_uploaded', 0) + results_count

        with open(agent_file, 'w') as f:
            json.dump(agent, f, indent=2)

    except Exception as e:
        logger.warning(f"Failed to update agent status: {e}")


# ============================================================================
# Two-Way Communication Helpers
# ============================================================================

@fleet_agent_bp.route('/api/agent/managed/poll', methods=['POST'])
@require_api_key
def agent_poll():
    """
    Unified polling endpoint for fleet agents

    Agent calls this periodically to:
    1. Send heartbeat / status update
    2. Receive pending commands
    3. Get configuration updates
    4. Check for audit updates

    Request body:
    {
        "agent_id": "abc123",
        "hostname": "WORKSTATION-01",
        "status": "idle",
        "current_config_version": 1,
        "audit_checksums": {"platform/baseline/updates.sh": "abc123..."},
        "resources": {
            "cpu_pct": 25,
            "memory_free_pct": 50
        },
        "pending_results_count": 0
    }

    Response:
    {
        "success": true,
        "server_time": "2026-02-17T10:30:00Z",
        "commands": [...],
        "config_update_available": true,
        "config_version": 2,
        "audit_updates": ["platform/baseline/updates.sh"],
        "next_poll_seconds": 60
    }
    """
    try:
        # Extract agent_id from body early so it's available for audit logging even on auth failure
        data = request.json or {}
        agent_id = data.get('agent_id')

        signature_ok, signature_error = _verify_managed_request_signature(agent_id=agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        if not agent_id:
            return jsonify({'success': False, 'error': 'agent_id required'}), 400

        # Strict server-side heartbeat gate: polling is denied without recent heartbeat
        heartbeat_ok, heartbeat_error = _is_fresh_heartbeat(agent_id)
        if not heartbeat_ok:
            return jsonify({
                'success': False,
                'error': 'Heartbeat validation required',
                'details': heartbeat_error
            }), 403

        # Update agent status
        _update_agent_from_poll(agent_id, data)

        # Keep unified registry (FleetAgent table) heartbeat/type fresh for managed polling agents
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type='managed',
                hostname=data.get('hostname'),
                name=data.get('hostname') or agent_id,
                os_type=data.get('os_type'),
                agent_version=data.get('agent_version'),
                status=data.get('status', 'active'),
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during managed poll for {agent_id}: {sync_err}")

        response = {
            'success': True,
            'server_time': datetime.now().isoformat(),
            'commands': [],
            'config_update_available': False,
            'config_version': 0,
            'audit_updates': [],
            'next_poll_seconds': 60
        }

        # Check for pending commands
        from api.agent_routes import get_pending_commands
        response['commands'] = get_pending_commands(agent_id, limit=5)

        # Check for config updates
        current_version = data.get('current_config_version', 0)
        config_file = os.path.join(AGENT_CONFIG_DIR, f"{agent_id}.json")

        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
            server_version = config.get('config_version', 1)
            if server_version > current_version:
                response['config_update_available'] = True
                response['config_version'] = server_version

        # Check for audit updates
        agent_checksums = data.get('audit_checksums', {})
        if agent_checksums:
            response['audit_updates'] = _check_audit_updates(agent_checksums)

        # Adjust poll interval based on pending work
        if response['commands'] or response['config_update_available'] or response['audit_updates']:
            response['next_poll_seconds'] = 30  # Poll faster when there's work

        return jsonify(response)

    except Exception as e:
        logger.error(f"Agent poll failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/<agent_id>/direct/health', methods=['GET'])
@require_api_key
def fleet_agent_direct_health(agent_id):
    """Proxy a direct HTTPS health request to the managed target-host API."""
    payload, status_code = _managed_direct_api_call(agent_id, '/api/v1/agent/health')
    return jsonify(payload), status_code


@fleet_agent_bp.route('/api/managed-agent/<agent_id>/direct/system-info', methods=['GET'])
@require_api_key
def fleet_agent_direct_system_info(agent_id):
    """Proxy a direct HTTPS system-info request to the managed target-host API."""
    payload, status_code = _managed_direct_api_call(agent_id, '/api/v1/agent/system-info')
    return jsonify(payload), status_code


@fleet_agent_bp.route('/api/managed-agent/<agent_id>/direct/check', methods=['GET'])
@require_auth_and_permission('manage_servers')
def fleet_agent_direct_connectivity_check(agent_id):
    """Admin connectivity probe for managed direct API health and system-info."""
    health_payload, health_status = _managed_direct_api_call(agent_id, '/api/v1/agent/health')
    system_payload, system_status = _managed_direct_api_call(agent_id, '/api/v1/agent/system-info')

    all_ok = health_payload.get('success') and system_payload.get('success')
    if all_ok:
        status_code = 200
    elif any(code >= 500 for code in (health_status, system_status)):
        status_code = 502
    elif any(code == 403 for code in (health_status, system_status)):
        status_code = 403
    else:
        status_code = 400

    return jsonify({
        'success': bool(all_ok),
        'agent_id': agent_id,
        'checks': {
            'health': {
                'status_code': health_status,
                'result': health_payload,
            },
            'system_info': {
                'status_code': system_status,
                'result': system_payload,
            },
        },
    }), status_code


def _update_agent_from_poll(agent_id, data):
    """Update agent record from poll data"""
    try:
        _ensure_dirs()
        agent_file = os.path.join(AGENTS_DIR, f"{agent_id}.json")

        if os.path.exists(agent_file):
            with open(agent_file, 'r') as f:
                agent = json.load(f)
        else:
            agent = {
                'agent_id': agent_id,
                'created_at': datetime.now().isoformat()
            }

        # Update from poll data
        agent['hostname'] = data.get('hostname', agent.get('hostname'))
        agent['last_seen'] = datetime.now().isoformat()
        agent['status'] = data.get('status', 'active')
        agent['resources'] = data.get('resources', {})
        agent['pending_results_count'] = data.get('pending_results_count', 0)

        with open(agent_file, 'w') as f:
            json.dump(agent, f, indent=2)

    except Exception as e:
        logger.warning(f"Failed to update agent from poll: {e}")


def _check_audit_updates(agent_checksums):
    """
    Compare agent checksums with server and return list of changed files
    """
    updates_needed = []

    for file_path, agent_checksum in agent_checksums.items():
        full_path = os.path.join(ROOT_DIR, file_path)
        if os.path.exists(full_path):
            server_checksum = _calculate_file_checksum(full_path)
            if server_checksum != agent_checksum:
                updates_needed.append(file_path)

    return updates_needed


def _calculate_file_checksum(file_path):
    """Calculate SHA256 checksum of file"""
    sha256 = hashlib.sha256()
    try:
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except Exception:
        return ''


def _get_current_user():
    """Get current authenticated user"""
    try:
        from flask_login import current_user
        if current_user and current_user.is_authenticated:
            return current_user.username
    except Exception as e:
        logger.debug(f"Could not get current user: {e}")
    return 'system'


# ============================================================================
# Agent Execution Integration
# ============================================================================

@fleet_agent_bp.route('/api/agent/managed/execute', methods=['POST'])
@require_api_key
@require_auth_and_permission('run_audits')
def queue_agent_execution():
    """
    Queue an audit for execution on a fleet agent

    This is the entry point for running audits on agent-connected servers,
    providing parity with SSH/WinRM execution paths.

    Request body:
    {
        "agent_id": "abc123",
        "audit_path": "platform/baseline/updates",
        "priority": 5,
        "options": {
            "timeout": 300
        }
    }
    """
    try:
        data = request.json or {}
        agent_id = data.get('agent_id')
        audit_path = data.get('audit_path')

        if not agent_id or not audit_path:
            return jsonify({'success': False, 'error': 'agent_id and audit_path required'}), 400

        # Import and use the command queue function
        from api.agent_routes import queue_command_for_agent

        command = queue_command_for_agent(
            agent_id=agent_id,
            command_type='run_audit',
            command_data={
                'audit_path': audit_path,
                'options': data.get('options', {})
            },
            requested_by=_get_current_user(),
            priority=data.get('priority', 5),
            expires_hours=data.get('expires_hours', 24)
        )

        return jsonify({
            'success': True,
            'command_id': command['id'],
            'message': f'Audit queued for agent {agent_id}',
            'note': 'Results will be available when agent completes execution'
        })

    except Exception as e:
        logger.error(f"Failed to queue agent execution: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent Download Routes (for third-party deployment tools)
# ============================================================================

@fleet_agent_bp.route('/api/agent/download/<os_type>', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_agent(os_type):
    """
    Download the fleet agent for deployment via third-party tools
    (Intune, SCCM, Ansible, etc.)

    PROTECTED: Requires API key authentication.
    Downloads include embedded license token for script protection.

    URL Parameters:
        os_type: 'windows' or 'linux'

    Query Parameters:
        format: 'raw' (script only) or 'package' (with config template)
        server_url: Pre-configure server URL in agent
        agent_id: Pre-configure agent ID
    """
    from flask import Response

    try:
        if os_type not in ['windows', 'linux']:
            return jsonify({'error': 'os_type must be windows or linux'}), 400

        format_type = request.args.get('format', 'raw')
        server_url = request.args.get('server_url', '')
        agent_id = request.args.get('agent_id', '')

        if server_url:
            is_valid, validation_error = _validate_managed_server_url(server_url)
            if not is_valid:
                return jsonify({'error': validation_error}), 400

        # Determine agent file path
        agent_dir = FLEET_AGENT_DIR
        if os_type == 'windows':
            agent_file = os.path.join(agent_dir, 'fleet-agent.ps1')
            filename = 'fleet-agent.ps1'
            mimetype = 'application/octet-stream'
        else:
            agent_file = os.path.join(agent_dir, 'fleet-agent.sh')
            filename = 'fleet-agent.sh'
            mimetype = 'application/octet-stream'

        logger.info(f"Download request: os_type={os_type}, format={format_type}, file={agent_file}")

        if not os.path.exists(agent_file):
            logger.error(f"Agent file not found: {agent_file}")
            return jsonify({'error': f'Agent file not found: {filename}'}), 404

        if format_type == 'raw':
            # Read file content and return as attachment
            with open(agent_file, 'r', encoding='utf-8') as f:
                content = f.read()

            logger.info(f"Sending agent file: {filename}, size={len(content)} bytes")

            response = Response(
                content,
                mimetype=mimetype,
                headers={
                    'Content-Disposition': f'attachment; filename="{filename}"',
                    'Content-Length': str(len(content.encode('utf-8')))
                }
            )
            return response
        elif format_type == 'package':
            # Create a zip/tar package with agent + config template
            return _create_agent_package(os_type, server_url, agent_id)
        else:
            return jsonify({'error': 'format must be raw or package'}), 400

    except Exception as e:
        logger.error(f"Failed to download agent: {e}")
        return jsonify({'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/download/installer/<os_type>', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_agent_installer(os_type):
    """
    Download a self-extracting installer package for the fleet agent.

    PROTECTED: Requires API key authentication.
    Downloads include embedded license token for script protection.

    This is ideal for deployment via Intune, SCCM, or other MDM tools.

    URL Parameters:
        os_type: 'windows' or 'linux'

    Query Parameters:
        server_url: Pre-configure server URL
        api_key: Pre-configure API key (will be embedded)
        install_path: Custom installation directory
        service_name: Custom service name
        auto_start: 'true' to start service after install
    """
    try:
        if os_type not in ['windows', 'linux']:
            return jsonify({'error': 'os_type must be windows or linux'}), 400

        config = {
            'server_url': request.args.get('server_url', ''),
            'api_key': request.args.get('api_key', ''),
            'install_path': request.args.get('install_path', ''),
            'service_name': request.args.get('service_name', 'audit-agent'),
            'auto_start': request.args.get('auto_start', 'true').lower() == 'true'
        }

        if config['server_url']:
            is_valid, validation_error = _validate_managed_server_url(config['server_url'])
            if not is_valid:
                return jsonify({'error': validation_error}), 400

        return _create_installer_package(os_type, config)

    except Exception as e:
        logger.error(f"Failed to create installer: {e}")
        return jsonify({'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/download/config-template', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_config_template():
    """
    Download a configuration template for the fleet agent.

    PROTECTED: Requires API key authentication.
    """
    os_type = request.args.get('os_type', 'linux')

    max_local_result_files = _get_agent_local_result_max_files()
    min_free_disk_mb = _get_agent_local_min_free_disk_mb()
    min_free_disk_pct = _get_agent_local_min_free_disk_pct()

    config_template = {
        "server_url": "https://your-audit-server.example.com:5000",
        "agent_id": "unique-agent-id",
        "api_key": "your-api-key-here",
        "poll_interval": 60,
        "sync_interval": 3600,
        "auto_update": True,
        "tls_verify": True,
        "log_level": "INFO",
        "audit_categories": ["baseline", "hardening"],
        "result_retention_days": 30,
        "max_local_result_files": max_local_result_files,
        "min_free_disk_mb": min_free_disk_mb,
        "min_free_disk_pct": min_free_disk_pct
    }

    response = jsonify(config_template)
    response.headers['Content-Disposition'] = 'attachment; filename=agent-config.json'
    return response


@fleet_agent_bp.route('/api/agent/download/deployment-scripts', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_deployment_scripts():
    """
    Download deployment helper scripts for various platforms.

    PROTECTED: Requires API key authentication.

    Query Parameters:
        platform: 'intune', 'sccm', 'ansible', 'puppet', 'chef', 'salt', 'terraform'
    """
    platform = request.args.get('platform', 'generic')
    os_type = request.args.get('os_type', 'windows')

    scripts = _get_deployment_script(platform, os_type)
    if not scripts:
        return jsonify({'error': f'No deployment script for platform: {platform}'}), 404

    return jsonify({
        'platform': platform,
        'os_type': os_type,
        'scripts': scripts
    })


@fleet_agent_bp.route('/api/agent/download/standalone/<script_type>', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_standalone_script(script_type):
    """
    Download standalone helper scripts for JEA setup and Linux least-privilege installation workflows.

    PROTECTED: Requires API key authentication.

    These are the same scripts included in the packages, but available as individual
    downloads or focused bundles for users who need just the elevation and stream-execution pieces.

    URL Parameters:
        script_type: 'jea-setup', 'jea-session-config', 'jea-role-full', 'jea-role-readonly',
                     'setup-sudoers-linux', 'install-user', 'install-windows', 'install-linux',
                     'run-audit-wrapper', 'run-audit-jer', 'invoke-security-audit-jea',
                     'winrm-jea-wrapper-bundle', 'ssh-sudo-wrapper-bundle',
                     'precheck-winrm-target', 'precheck-ssh-target', 'prep-linux-target-expected-state',
                     'setup-linux-ssh-key-access', 'direct-api-linux-host-setup', 'direct-api-windows-host-setup',
                     'rebuild-vm-appliance', 'split-artifact-for-git', 'publish-vm-artifacts-to-github-release'
    """
    from flask import Response

    try:
        agent_dir = STANDALONE_AGENT_DIR
        jea_dir = os.path.join(agent_dir, 'jea')

        def build_zip_bundle(file_entries):
            bundle_stream = io.BytesIO()
            with zipfile.ZipFile(bundle_stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                for source_path, archive_name in file_entries:
                    archive.write(source_path, arcname=archive_name)
            bundle_stream.seek(0)
            return bundle_stream

        def build_tar_gz_bundle(file_entries):
            bundle_stream = io.BytesIO()
            with tarfile.open(fileobj=bundle_stream, mode='w:gz') as archive:
                for source_path, archive_name in file_entries:
                    archive.add(source_path, arcname=archive_name)
            bundle_stream.seek(0)
            return bundle_stream

        bundle_map = {
            'winrm-jea-wrapper-bundle': {
                'filename': 'windows-jea-winrm-wrapper-bundle.zip',
                'mimetype': 'application/zip',
                'builder': build_zip_bundle,
                'files': [
                    (os.path.join(ROOT_DIR, 'scripts', 'run-audit-jer.ps1'), 'run-audit-jer.ps1'),
                    (os.path.join(ROOT_DIR, 'deployment', 'windows', 'jea', 'Invoke-SecurityAuditJEA.ps1'), 'Invoke-SecurityAuditJEA.ps1'),
                    (os.path.join(jea_dir, 'setup-jea.ps1'), 'jea/setup-jea.ps1'),
                    (os.path.join(jea_dir, 'AuditAgent.pssc'), 'jea/AuditAgent.pssc'),
                    (os.path.join(jea_dir, 'AuditAgent.Full.psrc'), 'jea/AuditAgent.Full.psrc'),
                    (os.path.join(jea_dir, 'AuditAgent.ReadOnly.psrc'), 'jea/AuditAgent.ReadOnly.psrc'),
                ],
            },
            'ssh-sudo-wrapper-bundle': {
                'filename': 'linux-ssh-sudo-wrapper-bundle.tar.gz',
                'mimetype': 'application/gzip',
                'builder': build_tar_gz_bundle,
                'files': [
                    (os.path.join(ROOT_DIR, 'scripts', 'run-audit-wrapper.sh'), 'run-audit-wrapper.sh'),
                    (os.path.join(agent_dir, 'setup-sudoers.sh'), 'setup-sudoers.sh'),
                    (os.path.join(agent_dir, 'install-user.sh'), 'install-user.sh'),
                    (os.path.join(agent_dir, 'install-linux.sh'), 'install-linux.sh'),
                ],
            },
        }

        # Map script types to file paths and download names
        script_map = {
            'jea-setup': {
                'path': os.path.join(jea_dir, 'setup-jea.ps1'),
                'filename': 'setup-jea.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'JEA endpoint configuration script'
            },
            'jea-session-config': {
                'path': os.path.join(jea_dir, 'AuditAgent.pssc'),
                'filename': 'AuditAgent.pssc',
                'mimetype': 'application/octet-stream',
                'description': 'JEA session configuration for constrained audit endpoint'
            },
            'jea-role-full': {
                'path': os.path.join(jea_dir, 'AuditAgent.Full.psrc'),
                'filename': 'AuditAgent.Full.psrc',
                'mimetype': 'application/octet-stream',
                'description': 'JEA full-access role capability definition'
            },
            'jea-role-readonly': {
                'path': os.path.join(jea_dir, 'AuditAgent.ReadOnly.psrc'),
                'filename': 'AuditAgent.ReadOnly.psrc',
                'mimetype': 'application/octet-stream',
                'description': 'JEA read-only role capability definition'
            },
            'setup-sudoers-linux': {
                'path': os.path.join(agent_dir, 'setup-sudoers.sh'),
                'filename': 'setup-sudoers.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux least-privilege sudoers setup script'
            },
            'install-user': {
                'path': os.path.join(agent_dir, 'install-user.sh'),
                'filename': 'install-user.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux user-mode installer (no root required)'
            },
            'install-windows': {
                'path': os.path.join(agent_dir, 'install-windows.ps1'),
                'filename': 'install-windows.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Windows multi-mode installer'
            },
            'install-linux': {
                'path': os.path.join(agent_dir, 'install-linux.sh'),
                'filename': 'install-linux.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux systemd installer (root required)'
            },
            'run-audit-wrapper': {
                'path': os.path.join(ROOT_DIR, 'scripts', 'run-audit-wrapper.sh'),
                'filename': 'run-audit-wrapper.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux stream-mode audit wrapper helper for SSH execution paths'
            },
            'run-audit-jer': {
                'path': os.path.join(ROOT_DIR, 'scripts', 'run-audit-jer.ps1'),
                'filename': 'run-audit-jer.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Windows stream-mode JEA/RunAs audit wrapper helper for WinRM execution paths'
            },
            'invoke-security-audit-jea': {
                'path': os.path.join(ROOT_DIR, 'deployment', 'windows', 'jea', 'Invoke-SecurityAuditJEA.ps1'),
                'filename': 'Invoke-SecurityAuditJEA.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Windows JEA invoker for constrained endpoint audit execution'
            },
            'rebuild-vm-appliance': {
                'path': os.path.join(ROOT_DIR, 'tools', 'rebuild-vm-appliance.ps1'),
                'filename': 'rebuild-vm-appliance.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'VM appliance rebuild helper (all formats)'
            },
            'split-artifact-for-git': {
                'path': os.path.join(ROOT_DIR, 'tools', 'split-artifact-for-git.ps1'),
                'filename': 'split-artifact-for-git.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Split large artifacts into Git-safe multipart chunks'
            },
            'publish-vm-artifacts-to-github-release': {
                'path': os.path.join(ROOT_DIR, 'tools', 'publish-vm-artifacts-to-github-release.ps1'),
                'filename': 'publish-vm-artifacts-to-github-release.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Publish VM artifacts to GitHub Release assets (zero-cost off-host storage path)'
            },
            'precheck-winrm-target': {
                'path': os.path.join(ROOT_DIR, 'tools', 'precheck-winrm-target.ps1'),
                'filename': 'precheck-winrm-target.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'WinRM readiness precheck for Windows remote audit targets'
            },
            'precheck-ssh-target': {
                'path': os.path.join(ROOT_DIR, 'tools', 'precheck-ssh-target.ps1'),
                'filename': 'precheck-ssh-target.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'SSH readiness precheck for non-root Linux audit targets'
            },
            'prep-linux-target-expected-state': {
                'path': os.path.join(ROOT_DIR, 'tools', 'prep-linux-target-expected-state.sh'),
                'filename': 'prep-linux-target-expected-state.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux baseline setup for sudo-based non-root audit operations'
            },
            'setup-linux-ssh-key-access': {
                'path': os.path.join(ROOT_DIR, 'tools', 'setup-linux-ssh-key-access.sh'),
                'filename': 'setup-linux-ssh-key-access.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux SSH key-access setup helper for customer-site onboarding'
            },
            'direct-api-linux-host-setup': {
                'path': os.path.join(ROOT_DIR, 'tools', 'direct-api', 'setup-direct-api-linux-host.sh'),
                'filename': 'setup-direct-api-linux-host.sh',
                'mimetype': 'application/octet-stream',
                'description': 'Linux host Direct API endpoint installer for customer deployment pipelines'
            },
            'direct-api-windows-host-setup': {
                'path': os.path.join(ROOT_DIR, 'tools', 'direct-api', 'setup-direct-api-windows-host.ps1'),
                'filename': 'setup-direct-api-windows-host.ps1',
                'mimetype': 'application/octet-stream',
                'description': 'Windows host Direct API endpoint installer for manual/Intune-style rollout'
            }
        }

        valid_types = list(script_map.keys()) + list(bundle_map.keys())
        if script_type not in script_map and script_type not in bundle_map:
            return jsonify({
                'error': f"Invalid script_type. Valid options: {', '.join(valid_types)}"
            }), 400

        if FEATURE_LICENSING_AVAILABLE and script_type in {
            'direct-api-linux-host-setup',
            'direct-api-windows-host-setup',
        }:
            feature_denied = _feature_unavailable_response(Feature.DIRECT_API_SCANS)
            if feature_denied:
                return feature_denied

        if script_type in bundle_map:
            bundle_info = bundle_map[script_type]
            missing_files = [source_path for source_path, _ in bundle_info['files'] if not os.path.exists(source_path)]
            if missing_files:
                logger.error(f"Standalone bundle source files missing for {script_type}: {missing_files}")
                return jsonify({
                    'error': f"Bundle '{bundle_info['filename']}' is missing required source files",
                    'missing_files': missing_files,
                }), 404

            bundle_stream = bundle_info['builder'](bundle_info['files'])
            logger.info(
                f"Sending standalone helper bundle: {bundle_info['filename']}, size={bundle_stream.getbuffer().nbytes} bytes"
            )
            return send_file(
                bundle_stream,
                as_attachment=True,
                download_name=bundle_info['filename'],
                mimetype=bundle_info['mimetype'],
            )

        script_info = script_map[script_type]
        script_path = script_info['path']

        if not os.path.exists(script_path):
            logger.error(f"Standalone script not found: {script_path}")
            return jsonify({
                'error': f"Script '{script_info['filename']}' not found on server"
            }), 404

        # Read and return the file
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()

        logger.info(f"Sending standalone script: {script_info['filename']}, size={len(content)} bytes")

        response = Response(
            content,
            mimetype=script_info['mimetype'],
            headers={
                'Content-Disposition': f'attachment; filename="{script_info["filename"]}"',
                'Content-Length': str(len(content.encode('utf-8')))
            }
        )
        return response

    except Exception as e:
        logger.error(f"Failed to download standalone script: {e}")
        return jsonify({'error': str(e)}), 500


@fleet_agent_bp.route('/api/agent/jre/download/<platform>', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_jre_consolidated_agent(platform):
    """
    Download the consolidated JRE agent that supports both managed and standalone modes.

    PROTECTED: Requires API key authentication.
    Downloads include embedded license token for script protection.

    This is the preferred agent for enterprise deployments.
    It bundles:
    - Unified JRE agent (supports both managed and standalone modes)
    - ALL audit scripts (150+ scripts across all domains)
    - Library files and orchestrator
    - Agent configuration
    - License token (machine-bound on first run)

    URL Parameters:
        platform: 'windows' or 'linux'

    Query Parameters:
        mode: 'managed' (two-way API) or 'standalone' (ad-hoc audits) - default: standalone
        server_url: Pre-configure server URL (managed mode only)
        api_key: Pre-configure API key (managed mode only)
    """
    import io

    try:
        if platform not in ['linux', 'windows']:
            return jsonify({'error': 'platform must be linux or windows'}), 400

        mode = request.args.get('mode', 'standalone').lower()
        if mode not in ['managed', 'standalone']:
            mode = 'standalone'

        server_url = request.args.get('server_url', '')
        api_key = request.args.get('api_key', '')

        # Validate server URL if provided and in managed mode
        if server_url and mode == 'managed':
            is_valid, validation_error = _validate_managed_server_url(server_url)
            if not is_valid:
                return jsonify({'error': validation_error}), 400

        project_root = ROOT_DIR

        jre_candidate_dirs = [
            os.path.join(project_root, 'agents', 'jre', 'shared', 'target'),
            os.path.join(AGENTS_DIR, 'jre', 'shared', 'target'),
            os.path.join(project_root, 'web', 'agent-artifacts'),
        ]
        jre_jar_paths = []
        for candidate_dir in jre_candidate_dirs:
            if not os.path.isdir(candidate_dir):
                continue

            candidate_jars = [
                os.path.join(candidate_dir, name)
                for name in os.listdir(candidate_dir)
                if name.endswith('.jar')
                and not name.endswith('-sources.jar')
                and not name.endswith('-javadoc.jar')
            ]

            if candidate_jars:
                jre_jar_paths = sorted(candidate_jars)
                logger.info(f"Using JRE JARs from {candidate_dir}: {[os.path.basename(p) for p in jre_jar_paths]}")
                break

        logger.info(f"JRE consolidated agent download: platform={platform}, mode={mode}")

        logger.info(f"Creating JRE consolidated agent package: platform={platform}, mode={mode}")
        logger.info(f"Project root: {project_root}")
        if not jre_jar_paths:
            logger.error(f"No JRE JAR files found in candidates: {jre_candidate_dirs}")
            return jsonify({
                'error': 'JRE agent build artifacts not found. Build agents/jre/shared before downloading package.'
            }), 500

        # Create downloadable package
        if platform == 'windows':
            filename = f'unified-jre-agent-{mode}-windows.zip'
            buffer = io.BytesIO()

            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
                # 1. Add JRE agent JAR files
                logger.info("Adding JRE agent JAR files")
                for jar_path in jre_jar_paths:
                    zf.write(
                        jar_path,
                        arcname=os.path.join('agent', 'lib', os.path.basename(jar_path))
                    )

                # 2. Add ALL audit scripts
                logger.info("Adding audit scripts")
                audits_dir = os.path.join(project_root, 'audits')
                add_directory_to_zip(zf, audits_dir, 'audits')

                # 3. Add libraries
                logger.info("Adding library files")
                lib_dir = os.path.join(project_root, 'lib')
                add_directory_to_zip(zf, lib_dir, 'lib')

                # 4. Add orchestrator
                logger.info("Adding orchestrator")
                orchestrator_dir = os.path.join(project_root, 'orchestrator')
                add_directory_to_zip(zf, orchestrator_dir, 'orchestrator')

                # 5. Add tools
                logger.info("Adding tools")
                tools_dir = os.path.join(project_root, 'tools')
                add_directory_to_zip(zf, tools_dir, 'tools')

                # 6. Add documentation
                logger.info("Adding documentation")
                docs_dir = os.path.join(project_root, 'docs')
                add_directory_to_zip(zf, docs_dir, 'docs')

                # 7. Add agent configuration
                config = {
                    "mode": mode,
                    "agent_id": f"agent-{os.urandom(8).hex()}",
                    "api_key": api_key or "",
                    "server_url": server_url or "https://your-server:5000",
                    "platform": platform,
                    "agent_type": "jre-consolidated"
                }

                config_json = json.dumps(config, indent=2)
                zf.writestr('agent/config.json', config_json)

                # 8. Add root documentation files
                for readme_file in ['LICENSE', 'CONTRIBUTING.md']:
                    readme_path = os.path.join(project_root, readme_file)
                    if os.path.exists(readme_path):
                        zf.write(readme_path, arcname=readme_file)

                # 9. Add installation script for Windows
                install_script = f'''@echo off
REM Unified JRE Consolidated Agent Installation Script
REM Platform: Windows
REM Mode: {mode.upper()}
REM
REM This package includes:
REM  - Unified JRE Agent (supports {mode} and standalone modes)
REM  - 150+ Audit Scripts across all domains
REM  - Full audit library and orchestrator

setlocal enabledelayedexpansion
cd /d "%~dp0"

REM Check for Java
set "JAVA_CMD="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\\bin\\java.exe" set "JAVA_CMD=%JAVA_HOME%\\bin\\java.exe"
)
if not defined JAVA_CMD (
    for /f "delims=" %%I in ('where java 2^>nul') do (
        if not defined JAVA_CMD set "JAVA_CMD=%%I"
    )
)
if not defined JAVA_CMD (
    echo Error: Java is required but was not found via JAVA_HOME or PATH
    echo Please install Java 17 or later and set JAVA_HOME or add Java to PATH
    exit /b 1
)
"!JAVA_CMD!" -version >nul 2>&1
if errorlevel 1 (
    echo Error: Java was found but is not runnable: !JAVA_CMD!
    exit /b 1
)
echo Using Java: !JAVA_CMD!

REM Verify agent JAR exists
if not exist agent\\lib\\*.jar (
    echo Error: Agent JAR files not found
    echo Please ensure the package was extracted correctly
    exit /b 1
)

REM Setup environment
set AGENT_MODE={mode}
if not "{server_url}"=="" set SERVER_URL={server_url}
if not "{api_key}"=="" set API_KEY={api_key}

echo ====================================================
echo Unified JRE Consolidated Agent - Installation
echo ====================================================
echo Mode: !AGENT_MODE!
echo Platform: Windows
echo Audit Scripts: All 150+ scripts included
echo.

REM List audit domains
echo Available Audit Domains:
if exist audits (
    for /d %%A in (audits\\*) do (
        echo   - %%~nxA
    )
)
echo.

REM Installation instructions
echo Installation Instructions:
echo 1. Extract all files: Already done
echo 2. Ensure Java is installed: java -version
echo 3. Start agent in background:
echo    pwsh -ExecutionPolicy Bypass -File .\\START-AGENT.ps1
echo    Ready check: agent\\logs\\agent.out.log contains "Status: bootstrap initialized"
echo    Access UI on host:
echo      HTTP : http://^<host-or-ip^>:5000
echo      HTTPS: https://^<host-or-ip^>  (if TLS/reverse proxy is enabled)
echo 4. Enable auto-start on reboot:
echo    pwsh -ExecutionPolicy Bypass -File .\\ENABLE-AUTOSTART.ps1
echo 5. Configure (only if needed):
echo    - Managed mode: update server_url/api_key in agent\\config.json if not pre-filled
echo    - Standalone mode: optional unless you want custom settings
echo 6. Stop agent (if required):
echo    pwsh -ExecutionPolicy Bypass -File .\\STOP-AGENT.ps1
echo 7. Disable auto-start (optional):
echo    pwsh -ExecutionPolicy Bypass -File .\\DISABLE-AUTOSTART.ps1
echo 8. Foreground debug (optional):
echo    java -jar agent\\lib\\unified-jre-agent-shared-0.1.0.jar --mode={mode}
echo.
echo For more information, see README.md and docs directory
echo ====================================================
pause
'''
                zf.writestr('INSTALL.bat', install_script)

                start_script = f'''$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$jar = Join-Path $root 'agent\\lib\\unified-jre-agent-shared-0.1.0.jar'
if (-not (Test-Path $jar)) {{
    throw "Agent JAR not found: $jar"
}}

$javaCmd = $null
if ($env:JAVA_HOME) {{
    $candidate = Join-Path $env:JAVA_HOME 'bin\\java.exe'
    if (Test-Path $candidate) {{
        $javaCmd = $candidate
    }}
}}
if (-not $javaCmd) {{
    $cmd = Get-Command java -ErrorAction SilentlyContinue
    if ($cmd) {{
        $javaCmd = $cmd.Source
    }}
}}
if (-not $javaCmd) {{
    throw "Java not found via JAVA_HOME or PATH"
}}

$pidFile = Join-Path $root 'agent\\agent.pid'
if (Test-Path $pidFile) {{
    $existingPid = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1).Trim()
    if ($existingPid -and (Get-Process -Id $existingPid -ErrorAction SilentlyContinue)) {{
        Write-Host "Agent already running (PID $existingPid)"
        exit 0
    }}
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}}

$logDir = Join-Path $root 'agent\\logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$outLog = Join-Path $logDir 'agent.out.log'
$errLog = Join-Path $logDir 'agent.err.log'

$argLine = "-jar `"$jar`" --mode={mode}"
$proc = Start-Process -FilePath $javaCmd -ArgumentList $argLine -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
$proc.Id | Set-Content -Path $pidFile -Encoding Ascii

Write-Host "Agent started in background (PID $($proc.Id))"
Write-Host "Logs: $outLog"
Write-Host "Access UI: http://<host-or-ip>:5000 or https://<host-or-ip>"
'''
                zf.writestr('START-AGENT.ps1', start_script)

                stop_script = '''$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $root 'agent\\agent.pid'

if (-not (Test-Path $pidFile)) {
    Write-Host "No PID file found. Agent may already be stopped."
    exit 0
}

$agentPid = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1).Trim()
if (-not $agentPid) {
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    Write-Host "PID file was empty; cleaned up."
    exit 0
}

$proc = Get-Process -Id $agentPid -ErrorAction SilentlyContinue
if ($proc) {
    Stop-Process -Id $agentPid -Force
    Write-Host "Stopped agent process PID $agentPid"
} else {
    Write-Host "Process $agentPid not running; cleaning stale PID file."
}

Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
'''
                zf.writestr('STOP-AGENT.ps1', stop_script)

                enable_autostart_script = '''$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$taskName = 'AuditToolJreAgent'
$startScript = Join-Path $root 'START-AGENT.ps1'

if (-not (Test-Path $startScript)) {
    throw "Missing start script: $startScript"
}

$action = New-ScheduledTaskAction -Execute 'pwsh.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$startScript`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

try {
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
    Write-Host "Enabled auto-start on reboot via Scheduled Task: $taskName"
} catch {
    Write-Host "Failed to register Scheduled Task. Run this script in an elevated terminal (Run as Administrator)."
    throw
}
'''
                zf.writestr('ENABLE-AUTOSTART.ps1', enable_autostart_script)

                disable_autostart_script = '''$ErrorActionPreference = 'Stop'
$taskName = 'AuditToolJreAgent'
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Host "Disabled auto-start task: $taskName"
} else {
    Write-Host "Auto-start task not found: $taskName"
}
'''
                zf.writestr('DISABLE-AUTOSTART.ps1', disable_autostart_script)

                # 10. Add comprehensive README
                readme = f'''# Unified JRE Consolidated Agent - {mode.upper()} Mode

## Overview

This package contains the complete Audit Tool deployment on a single JRE agent that supports:
- **{mode.upper()} Mode**: {"Two-way API communication with server" if mode == 'managed' else "Standalone ad-hoc audits without server"}
- **150+ Audit Scripts**: Comprehensive security and compliance audits
- **Full Library Support**: All audit execution libraries and helpers
- **Orchestrator**: Multi-audit execution and result aggregation

## Contents

```
unified-jre-agent-{mode}-windows/
├── agent/
│   ├── lib/
│   │   └── unified-jre-agent-shared-0.1.0.jar  (Main JRE Agent)
│   └── config.json                             (Agent configuration)
├── audits/                                      (All 150+ audit scripts)
│   ├── linux/
│   ├── windows/
│   ├── hypervisors/
│   ├── web/
│   ├── data/
│   ├── storage/
│   ├── network/
│   ├── automation/
│   └── platform/
├── lib/                                         (Audit execution libraries)
├── orchestrator/                                (Multi-audit orchestration)
├── tools/                                       (Utility scripts and tools)
├── docs/                                        (Complete documentation)
├── README.md
├── LICENSE
├── INSTALL.bat
├── START-AGENT.ps1             (Windows background start)
├── STOP-AGENT.ps1              (Windows stop)
├── ENABLE-AUTOSTART.ps1        (Windows reboot persistence)
└── DISABLE-AUTOSTART.ps1       (Windows disable reboot persistence)
```

## Quick Start

### 1. Prerequisites

- Java 17 or later
- Windows 7+ or Linux (Ubuntu 18.04+, CentOS 7+, Debian 9+)

### 2. Installation

```bash
# Windows
INSTALL.bat

# Linux
bash install.sh
```

### 3. Configuration

Edit `agent/config.json`:

```json
{{
  "mode": "{mode}",
  "agent_id": "agent-xxxxxxxx",
  "api_key": "{"[configured]" if api_key else "[your-api-key]"}",
  "server_url": "{server_url or '[https://your-server:5000]'}",
  "platform": "{platform}",
  "agent_type": "jre-consolidated"
}}
```

### 4. Running the Agent (Background + Reboot Persistence)

```bash
# Windows (background)
pwsh -ExecutionPolicy Bypass -File .\\START-AGENT.ps1
pwsh -ExecutionPolicy Bypass -File .\\ENABLE-AUTOSTART.ps1

# Linux (background)
bash start-agent.sh
sudo bash enable-autostart.sh

# Stop/disable (when needed)
pwsh -ExecutionPolicy Bypass -File .\\STOP-AGENT.ps1
pwsh -ExecutionPolicy Bypass -File .\\DISABLE-AUTOSTART.ps1
bash stop-agent.sh
sudo bash disable-autostart.sh
```

Access the console at `http://<host-or-ip>:5000` (or `https://<host-or-ip>` when TLS/reverse proxy is enabled).

## Available Audits

This package includes **150+ audit scripts** across all domains:

- **Linux**: System hardening, services, security controls
- **Windows**: System policies, services, security baseline
- **Hypervisors**: ESXi, Proxmox, Xen, KVM, Hyper-V, vCenter
- **Web**: Application security, server configuration
- **Data**: Database security, encryption
- **Storage**: Storage security, backup verification
- **Network**: Network configuration, firewall
- **Automation**: Build pipelines, CI/CD security
- **Platform**: OS baseline, updates, compliance

Audit corpus parity is maintained across both managed and standalone packages.

## Mode Comparison

### {mode.upper()} Mode

```
Agent                Server
  ↓↑                  ↓↑
  connected for:
  - Remote audit execution
  - Configuration management
  - Real-time result push
  - Two-way API communication
```

{"Server provides:" if mode == 'managed' else "Agent provides:"}
- {"Remote audit scheduling" if mode == 'managed' else "Standalone audit execution"}
- {"Configuration updates" if mode == 'managed' else "Results stored locally"}
- {"Result aggregation" if mode == 'managed' else "No network dependency"}

## Documentation

See the `docs/` directory for:
- Detailed audit documentation
- API reference
- Configuration guide
- Security best practices
- Troubleshooting guide

## Script Protection and IP Scope

This package includes license-token based script execution controls:

- `.license_token` is embedded in package generation
- execution paths validate token + machine fingerprint + expiry
- first-run deployment placeholder token binds to the host on first execution

Protection scope: these controls gate authorized execution through the package workflow.
They do not claim absolute anti-copy DRM for files placed on endpoint storage.

## Support

For issues or questions:
1. Check `docs/troubleshooting.md`
2. Review audit logs in the agent directory
3. Check the main README.md for general information

## License

See LICENSE file for details
'''
                zf.writestr('README.md', readme)

                # 11. Add license token for script protection
                try:
                    import hashlib as _hashlib
                    placeholder_fingerprint = _hashlib.sha256(
                        f"jre-download-{platform}-{mode}-{datetime.now().isoformat()}".encode()
                    ).hexdigest()
                    license_token = _generate_license_token(
                        machine_fingerprint=placeholder_fingerprint,
                        agent_type='standalone'
                    )
                    if license_token:
                        # Mark as deployment placeholder - will bind to actual machine on first run
                        license_token['_deployment_placeholder'] = True
                        license_token['_package_type'] = 'jre-consolidated'
                        license_token_json = json.dumps(license_token, indent=2)
                        zf.writestr('.license_token', license_token_json)
                        logger.info("Embedded license token in JRE Windows package")
                except Exception as token_err:
                    logger.warning(f"Failed to embed license token: {token_err}")

            buffer.seek(0)
            logger.info(f"JRE agent package created for Windows ({mode} mode), size: {len(buffer.getvalue())} bytes")
            return send_file(
                buffer,
                mimetype='application/zip',
                as_attachment=True,
                download_name=filename
            )

        else:  # linux
            filename = f'unified-jre-agent-{mode}-linux.tar.gz'
            buffer = io.BytesIO()

            with tarfile.open(fileobj=buffer, mode='w:gz') as tar:
                # 1. Add JRE agent JAR files
                logger.info("Adding JRE agent JAR files")
                for jar_path in jre_jar_paths:
                    tar.add(
                        jar_path,
                        arcname=os.path.join('agent', 'lib', os.path.basename(jar_path))
                    )

                # 2. Add ALL audit scripts
                logger.info("Adding audit scripts")
                audits_dir = os.path.join(project_root, 'audits')
                add_directory_to_tar(tar, audits_dir, 'audits')

                # 3. Add libraries
                logger.info("Adding library files")
                lib_dir = os.path.join(project_root, 'lib')
                add_directory_to_tar(tar, lib_dir, 'lib')

                # 4. Add orchestrator
                logger.info("Adding orchestrator")
                orchestrator_dir = os.path.join(project_root, 'orchestrator')
                add_directory_to_tar(tar, orchestrator_dir, 'orchestrator')

                # 5. Add tools
                logger.info("Adding tools")
                tools_dir = os.path.join(project_root, 'tools')
                add_directory_to_tar(tar, tools_dir, 'tools')

                # 6. Add documentation
                logger.info("Adding documentation")
                docs_dir = os.path.join(project_root, 'docs')
                add_directory_to_tar(tar, docs_dir, 'docs')

                # 7. Add agent configuration
                config = {
                    "mode": mode,
                    "agent_id": f"agent-{os.urandom(8).hex()}",
                    "api_key": api_key or "",
                    "server_url": server_url or "https://your-server:5000",
                    "platform": platform,
                    "agent_type": "jre-consolidated"
                }

                config_json = json.dumps(config, indent=2)
                config_tarinfo = tarfile.TarInfo(name='agent/config.json')
                config_tarinfo.size = len(config_json.encode('utf-8'))
                tar.addfile(config_tarinfo, io.BytesIO(config_json.encode('utf-8')))

                # 8. Add root documentation files
                for readme_file in ['LICENSE', 'CONTRIBUTING.md']:
                    readme_path = os.path.join(project_root, readme_file)
                    if os.path.exists(readme_path):
                        tar.add(readme_path, arcname=readme_file)

                # 9. Add installation script for Linux
                install_script = f'''#!/bin/bash
# Unified JRE Consolidated Agent Installation Script
# Platform: Linux
# Mode: {mode.upper()}
#
# This package includes:
#  - Unified JRE Agent (supports {mode} and standalone modes)
#  - 150+ Audit Scripts across all domains
#  - Full audit library and orchestrator

set -e

cd "$(dirname "${{BASH_SOURCE[0]}}")"

# Check for Java
JAVA_CMD=""
if [ -n "${{JAVA_HOME:-}}" ] && [ -x "${{JAVA_HOME}}/bin/java" ]; then
    JAVA_CMD="${{JAVA_HOME}}/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_CMD="$(command -v java)"
fi

if [ -z "$JAVA_CMD" ]; then
    echo "Error: Java is required but was not found via JAVA_HOME or PATH"
    echo "Please install Java 17 or later:"
    echo "  Ubuntu/Debian: sudo apt-get install openjdk-17-jre"
    echo "  CentOS/RHEL:   sudo yum install java-17-openjdk"
    echo "  Alpine:        apk add openjdk17-jre"
    exit 1
fi

if ! "$JAVA_CMD" -version >/dev/null 2>&1; then
    echo "Error: Java was found but is not runnable: $JAVA_CMD"
    exit 1
fi

echo "Using Java: $JAVA_CMD"

# Verify agent JAR exists
if ! ls agent/lib/*.jar 1> /dev/null 2>&1; then
    echo "Error: Agent JAR files not found"
    echo "Please ensure the package was extracted correctly"
    exit 1
fi

# Setup environment
export AGENT_MODE={mode}
[ -n "{server_url}" ] && export SERVER_URL="{server_url}"
[ -n "{api_key}" ] && export API_KEY="{api_key}"

echo "===================================================="
echo "Unified JRE Consolidated Agent - Installation"
echo "===================================================="
echo "Mode: $AGENT_MODE"
echo "Platform: Linux"
echo "Audit Scripts: All 150+ scripts included"
echo ""

# List audit domains
echo "Available Audit Domains:"
if [ -d audits ]; then
    for domain in audits/*/; do
        domain_name=$(basename "$domain")
        echo "  - $domain_name"
    done
fi
echo ""

# Installation instructions
echo "Installation Instructions:"
echo "1. Extract files: Already done"
echo "2. Verify Java: java -version"
echo "3. Start agent in background:"
echo "   bash start-agent.sh"
echo "   Ready check: agent/logs/agent.out.log contains \"Status: bootstrap initialized\""
echo "   Access UI on host:"
echo "     HTTP : http://<host-or-ip>:5000"
echo "     HTTPS: https://<host-or-ip>  (if TLS/reverse proxy is enabled)"
echo "4. Enable auto-start on reboot (systemd):"
echo "   sudo bash enable-autostart.sh"
echo "5. Configure (only if needed):"
echo "   - Managed mode: update server_url/api_key in agent/config.json if not pre-filled"
echo "   - Standalone mode: optional unless you want custom settings"
echo "6. Stop agent (if required):"
echo "   bash stop-agent.sh"
echo "7. Disable auto-start (optional):"
echo "   sudo bash disable-autostart.sh"
echo "8. Foreground debug (optional):"
echo "   java -jar agent/lib/unified-jre-agent-shared-0.1.0.jar --mode={mode}"
echo ""
echo "For more information, see README.md and docs directory"
echo "===================================================="
'''
                script_tarinfo = tarfile.TarInfo(name='install.sh')
                script_tarinfo.size = len(install_script.encode('utf-8'))
                script_tarinfo.mode = 0o755
                tar.addfile(script_tarinfo, io.BytesIO(install_script.encode('utf-8')))

                start_script = f'''#!/bin/bash
set -euo pipefail

cd "$(dirname "${{BASH_SOURCE[0]}}")"

JAVA_CMD=""
if [ -n "${{JAVA_HOME:-}}" ] && [ -x "${{JAVA_HOME}}/bin/java" ]; then
    JAVA_CMD="${{JAVA_HOME}}/bin/java"
elif command -v java > /dev/null 2>&1; then
    JAVA_CMD="$(command -v java)"
fi

if [ -z "$JAVA_CMD" ]; then
    echo "Error: Java not found via JAVA_HOME or PATH"
    exit 1
fi

JAR="agent/lib/unified-jre-agent-shared-0.1.0.jar"
if [ ! -f "$JAR" ]; then
    echo "Error: Agent JAR not found: $JAR"
    exit 1
fi

PID_FILE="agent/agent.pid"
LOG_DIR="agent/logs"
mkdir -p "$LOG_DIR"

if [ -f "$PID_FILE" ]; then
    OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "Agent already running (PID $OLD_PID)"
        exit 0
    fi
    rm -f "$PID_FILE"
fi

nohup "$JAVA_CMD" -jar "$JAR" --mode={mode} > "$LOG_DIR/agent.out.log" 2> "$LOG_DIR/agent.err.log" < /dev/null &
echo $! > "$PID_FILE"

echo "Agent started in background (PID $(cat "$PID_FILE"))"
echo "Logs: $LOG_DIR/agent.out.log"
echo "Access UI: http://<host-or-ip>:5000 or https://<host-or-ip>"
'''
                start_tarinfo = tarfile.TarInfo(name='start-agent.sh')
                start_tarinfo.size = len(start_script.encode('utf-8'))
                start_tarinfo.mode = 0o755
                tar.addfile(start_tarinfo, io.BytesIO(start_script.encode('utf-8')))

                stop_script = '''#!/bin/bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

PID_FILE="agent/agent.pid"
if [ ! -f "$PID_FILE" ]; then
    echo "No PID file found. Agent may already be stopped."
    exit 0
fi

PID="$(cat "$PID_FILE" 2>/dev/null || true)"
if [ -z "$PID" ]; then
    rm -f "$PID_FILE"
    echo "PID file was empty; cleaned up."
    exit 0
fi

if kill -0 "$PID" 2>/dev/null; then
    kill "$PID" || true
    sleep 1
    kill -9 "$PID" 2>/dev/null || true
    echo "Stopped agent process PID $PID"
else
    echo "Process $PID not running; cleaned stale PID file."
fi

rm -f "$PID_FILE"
'''
                stop_tarinfo = tarfile.TarInfo(name='stop-agent.sh')
                stop_tarinfo.size = len(stop_script.encode('utf-8'))
                stop_tarinfo.mode = 0o755
                tar.addfile(stop_tarinfo, io.BytesIO(stop_script.encode('utf-8')))

                enable_autostart_script = '''#!/bin/bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

if ! command -v systemctl > /dev/null 2>&1; then
    echo "Error: systemd/systemctl not available on this host"
    exit 1
fi

JAVA_CMD=""
if [ -n "${JAVA_HOME:-}" ] && [ -x "${JAVA_HOME}/bin/java" ]; then
    JAVA_CMD="${JAVA_HOME}/bin/java"
elif command -v java > /dev/null 2>&1; then
    JAVA_CMD="$(command -v java)"
fi

if [ -z "$JAVA_CMD" ]; then
    echo "Error: Java not found via JAVA_HOME or PATH"
    exit 1
fi

ROOT_DIR="$(pwd)"
SERVICE_FILE="/etc/systemd/system/audit-tool-jre-agent.service"

cat <<EOF | sudo tee "$SERVICE_FILE" > /dev/null
[Unit]
Description=Audit Tool JRE Agent
After=network.target

[Service]
Type=simple
WorkingDirectory=$ROOT_DIR
ExecStart=$JAVA_CMD -jar $ROOT_DIR/agent/lib/unified-jre-agent-shared-0.1.0.jar --mode={mode}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable audit-tool-jre-agent.service
sudo systemctl restart audit-tool-jre-agent.service
sudo systemctl --no-pager --full status audit-tool-jre-agent.service || true

echo "Enabled auto-start on reboot via systemd service: audit-tool-jre-agent.service"
'''
                enable_tarinfo = tarfile.TarInfo(name='enable-autostart.sh')
                enable_tarinfo.size = len(enable_autostart_script.encode('utf-8'))
                enable_tarinfo.mode = 0o755
                tar.addfile(enable_tarinfo, io.BytesIO(enable_autostart_script.encode('utf-8')))

                disable_autostart_script = '''#!/bin/bash
set -euo pipefail

if ! command -v systemctl > /dev/null 2>&1; then
    echo "systemd/systemctl not available; nothing to disable"
    exit 0
fi

sudo systemctl disable --now audit-tool-jre-agent.service || true
sudo rm -f /etc/systemd/system/audit-tool-jre-agent.service
sudo systemctl daemon-reload

echo "Disabled auto-start service: audit-tool-jre-agent.service"
'''
                disable_tarinfo = tarfile.TarInfo(name='disable-autostart.sh')
                disable_tarinfo.size = len(disable_autostart_script.encode('utf-8'))
                disable_tarinfo.mode = 0o755
                tar.addfile(disable_tarinfo, io.BytesIO(disable_autostart_script.encode('utf-8')))

                # 10. Add comprehensive README (same as Windows)
                readme = f'''# Unified JRE Consolidated Agent - {mode.upper()} Mode

## Overview

This package contains the complete Audit Tool deployment on a single JRE agent that supports:
- **{mode.upper()} Mode**: {"Two-way API communication with server" if mode == 'managed' else "Standalone ad-hoc audits without server"}
- **150+ Audit Scripts**: Comprehensive security and compliance audits
- **Full Library Support**: All audit execution libraries and helpers
- **Orchestrator**: Multi-audit execution and result aggregation

## Contents

```
unified-jre-agent-{mode}-linux/
├── agent/
│   ├── lib/
│   │   └── unified-jre-agent-shared-0.1.0.jar  (Main JRE Agent)
│   └── config.json                             (Agent configuration)
├── audits/                                      (All 150+ audit scripts)
│   ├── linux/
│   ├── windows/
│   ├── hypervisors/
│   ├── web/
│   ├── data/
│   ├── storage/
│   ├── network/
│   ├── automation/
│   └── platform/
├── lib/                                         (Audit execution libraries)
├── orchestrator/                                (Multi-audit orchestration)
├── tools/                                       (Utility scripts and tools)
├── docs/                                        (Complete documentation)
├── README.md
├── LICENSE
└── install.sh
```

## Quick Start

### 1. Prerequisites

- Java 17 or later
- Linux: Ubuntu 18.04+, CentOS 7+, Debian 9+, Alpine 3.13+, etc.

### 2. Installation

```bash
# Extract the archive
tar -xzf unified-jre-agent-{mode}-linux.tar.gz
cd unified-jre-agent-{mode}-linux/

# Run installation script
bash install.sh
```

### 3. Configuration

Edit `agent/config.json`:

```json
{{
  "mode": "{mode}",
  "agent_id": "agent-xxxxxxxx",
  "api_key": "{"[configured]" if api_key else "[your-api-key]"}",
  "server_url": "{server_url or '[https://your-server:5000]'}",
  "platform": "{platform}",
  "agent_type": "jre-consolidated"
}}
```

### 4. Running the Agent

```bash
# {mode.upper()} Mode
java -jar agent/lib/unified-jre-agent-shared-0.1.0.jar --mode={mode}

# With environment variables
export AGENT_MODE={mode}
export SERVER_URL={server_url or 'https://your-server:5000'}
export API_KEY={"[your-api-key]" if not api_key else api_key}
java -jar agent/lib/unified-jre-agent-shared-0.1.0.jar
```

## Available Audits

This package includes **150+ audit scripts** across all domains:

- **Linux**: System hardening, services, security controls
- **Windows**: System policies, services, security baseline
- **Hypervisors**: ESXi, Proxmox, Xen, KVM, Hyper-V, vCenter
- **Web**: Application security, server configuration
- **Data**: Database security, encryption
- **Storage**: Storage security, backup verification
- **Network**: Network configuration, firewall
- **Automation**: Build pipelines, CI/CD security
- **Platform**: OS baseline, updates, compliance

## Mode Comparison

### {mode.upper()} Mode

```
Agent                Server
  ↓↑                  ↓↑
  connected for:
  - Remote audit execution
  - Configuration management
  - Real-time result push
  - Two-way API communication
```

{"Server provides:" if mode == 'managed' else "Agent provides:"}
- {"Remote audit scheduling" if mode == 'managed' else "Standalone audit execution"}
- {"Configuration updates" if mode == 'managed' else "Results stored locally"}
- {"Result aggregation" if mode == 'managed' else "No network dependency"}

## Documentation

See the `docs/` directory for:
- Detailed audit documentation
- API reference
- Configuration guide
- Security best practices
- Troubleshooting guide

## Support

For issues or questions:
1. Check `docs/troubleshooting.md`
2. Review audit logs in the agent directory
3. Check the main README.md for general information

## License

See LICENSE file for details
'''
                readme_tarinfo = tarfile.TarInfo(name='README.md')
                readme_tarinfo.size = len(readme.encode('utf-8'))
                tar.addfile(readme_tarinfo, io.BytesIO(readme.encode('utf-8')))

                # 11. Add license token for script protection
                try:
                    import hashlib as _hashlib
                    placeholder_fingerprint = _hashlib.sha256(
                        f"jre-download-{platform}-{mode}-{datetime.now().isoformat()}".encode()
                    ).hexdigest()
                    license_token = _generate_license_token(
                        machine_fingerprint=placeholder_fingerprint,
                        agent_type='standalone'
                    )
                    if license_token:
                        # Mark as deployment placeholder - will bind to actual machine on first run
                        license_token['_deployment_placeholder'] = True
                        license_token['_package_type'] = 'jre-consolidated'
                        license_token_json = json.dumps(license_token, indent=2)
                        token_tarinfo = tarfile.TarInfo(name='.license_token')
                        token_tarinfo.size = len(license_token_json.encode('utf-8'))
                        tar.addfile(token_tarinfo, io.BytesIO(license_token_json.encode('utf-8')))
                        logger.info("Embedded license token in JRE Linux package")
                except Exception as token_err:
                    logger.warning(f"Failed to embed license token: {token_err}")

            buffer.seek(0)
            logger.info(f"JRE agent package created for Linux ({mode} mode), size: {len(buffer.getvalue())} bytes")
            return send_file(
                buffer,
                mimetype='application/gzip',
                as_attachment=True,
                download_name=filename
            )

    except Exception as e:
        logger.error(f"Failed to download JRE consolidated agent: {e}")
        logger.exception(e)
        return jsonify({'error': str(e)}), 500


def _create_agent_package(os_type, server_url='', agent_id=''):
    """Create a downloadable Fleet package from the fleet-agent boundary."""
    import io

    agent_dir = FLEET_AGENT_DIR
    config = {
        "server_url": server_url or "https://your-server:5000",
        "agent_id": agent_id or "agent-" + os.urandom(4).hex(),
        "api_key": "",
        "poll_interval": 60,
        "auto_update": True,
    }

    if os_type == 'windows':
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            required_files = [
                'fleet-agent.ps1',
                'fleet-agent-api.py',
                'install-windows.ps1',
                'README.md',
                'VERSION',
            ]
            for file_name in required_files:
                file_path = os.path.join(agent_dir, file_name)
                if os.path.exists(file_path):
                    zf.write(file_path, file_name)

            add_directory_to_zip(zf, os.path.join(agent_dir, 'jea'), 'jea')
            add_directory_to_zip(zf, os.path.join(agent_dir, 'audits'), 'audits')
            add_directory_to_zip(zf, os.path.join(agent_dir, 'lib'), 'lib')

            zf.writestr('config.json', json.dumps(config, indent=2))

        buffer.seek(0)
        return send_file(
            buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name='fleet-agent-windows.zip'
        )

    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as tf:
        required_files = [
            'fleet-agent.sh',
            'fleet-agent-api.py',
            'install-linux.sh',
            'install-user.sh',
            'setup-sudoers.sh',
            'README.md',
            'VERSION',
        ]
        for file_name in required_files:
            file_path = os.path.join(agent_dir, file_name)
            if os.path.exists(file_path):
                tf.add(file_path, arcname=file_name)

        add_directory_to_tar(tf, os.path.join(agent_dir, 'audits'), 'audits')
        add_directory_to_tar(tf, os.path.join(agent_dir, 'lib'), 'lib')

        config_info = tarfile.TarInfo(name='config.json')
        config_bytes = json.dumps(config, indent=2).encode('utf-8')
        config_info.size = len(config_bytes)
        tf.addfile(config_info, io.BytesIO(config_bytes))

    buffer.seek(0)
    return send_file(
        buffer,
        mimetype='application/gzip',
        as_attachment=True,
        download_name='fleet-agent-linux.tar.gz'
    )


def _create_installer_package(os_type, config):
    """Create a self-contained installer package"""
    import io

    # Extract config values to avoid f-string backslash issues
    server_url = config.get('server_url', '')
    api_key = config.get('api_key', '')
    install_path_win = config.get('install_path', '') or 'C:\\Program Files\\AuditAgent'
    install_path_linux = config.get('install_path', '') or '/opt/audit-agent'
    service_name = config.get('service_name', 'audit-agent')
    auto_start_ps = 'true' if config.get('auto_start', True) else 'false'
    auto_start_bash = 'true' if config.get('auto_start', True) else 'false'

    if os_type == 'windows':
        # Create a PowerShell-based installer that can be run via Intune
        installer_script = '''#Requires -RunAsAdministrator
# Fleet Agent Installer for Intune/SCCM
# Auto-generated deployment package

$ErrorActionPreference = "Stop"

# Configuration (embedded)
$Config = @{{
    ServerUrl = "{server_url}"
    ApiKey = "{api_key}"
    InstallPath = "{install_path}"
    ServiceName = "{service_name}"
    AutoStart = ${auto_start}
}}

Write-Host "Installing Security Audit Fleet Agent..."

# Create install directory
$InstallDir = $Config.InstallPath
if (-not (Test-Path $InstallDir)) {{
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
}}

# Download and extract package from server
$PackageUrl = "$($Config.ServerUrl)/api/agent/download/windows?format=package"
$PackagePath = Join-Path $env:TEMP "fleet-agent-windows.zip"
$ExtractPath = Join-Path $env:TEMP "fleet-agent-windows-package"

try {{
    Invoke-WebRequest -Uri $PackageUrl -OutFile $PackagePath -UseBasicParsing
}} catch {{
    Write-Error "Failed to download package: $_"
    exit 1
}}

if (Test-Path $ExtractPath) {{
    Remove-Item -Path $ExtractPath -Recurse -Force
}}
Expand-Archive -Path $PackagePath -DestinationPath $ExtractPath -Force

# Install as Windows Service using package installer
$AgentId = "agent-$((New-Guid).ToString('N').Substring(0,8))"
$InstallScript = Join-Path $ExtractPath "install-windows.ps1"

if (-not (Test-Path $InstallScript)) {{
    Write-Error "Package did not contain install-windows.ps1"
    exit 1
}}

& $InstallScript -Mode Service -ServerUrl $Config.ServerUrl -ApiKey $Config.ApiKey -AgentId $AgentId

if ($LASTEXITCODE -ne 0) {{
    Write-Error "Installer failed with code $LASTEXITCODE"
    exit $LASTEXITCODE
}}

if ($Config.AutoStart) {{
    Start-Service -Name $Config.ServiceName -ErrorAction SilentlyContinue
}}

Remove-Item -Path $PackagePath -Force -ErrorAction SilentlyContinue
Remove-Item -Path $ExtractPath -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "Installation complete!" -ForegroundColor Green
exit 0
'''.format(
            server_url=server_url,
            api_key=api_key,
            install_path=install_path_win,
            service_name=service_name,
            auto_start=auto_start_ps
        )
        buffer = io.BytesIO(installer_script.encode('utf-8'))
        return send_file(
            buffer,
            mimetype='text/plain',
            as_attachment=True,
            download_name='Install-AuditAgent.ps1'
        )
    else:
        # Create bash installer for Linux
        installer_script = '''#!/bin/bash
# Fleet Agent Installer for Ansible/Puppet/Chef
# Auto-generated deployment package

set -e

# Configuration (embedded)
SERVER_URL="{server_url}"
API_KEY="{api_key}"
INSTALL_PATH="{install_path}"
SERVICE_NAME="{service_name}"
AUTO_START="{auto_start}"

echo "Installing Security Audit Fleet Agent..."

# Create directories
mkdir -p "$INSTALL_PATH"
mkdir -p /etc/audit-agent

# Download and extract package
TMP_DIR="$(mktemp -d)"
PACKAGE_URL="$SERVER_URL/api/agent/download/linux?format=package"
PACKAGE_PATH="$TMP_DIR/fleet-agent-linux.tar.gz"

curl -fsSL "$PACKAGE_URL" -o "$PACKAGE_PATH"
tar -xzf "$PACKAGE_PATH" -C "$TMP_DIR"

# Run package installer
AGENT_ID="agent-$(head -c 4 /dev/urandom | xxd -p)"
chmod +x "$TMP_DIR/install-linux.sh"
bash "$TMP_DIR/install-linux.sh" "$SERVER_URL" "$API_KEY" "$AGENT_ID"

if [ "$AUTO_START" = "true" ]; then
    systemctl start "$SERVICE_NAME"
fi

rm -rf "$TMP_DIR"

echo "Installation complete!"
'''.format(
            server_url=server_url,
            api_key=api_key,
            install_path=install_path_linux,
            service_name=service_name,
            auto_start=auto_start_bash
        )
        buffer = io.BytesIO(installer_script.encode('utf-8'))
        return send_file(
            buffer,
            mimetype='text/x-shellscript',
            as_attachment=True,
            download_name='install-audit-agent.sh'
        )


def _get_deployment_script(platform, os_type):
    """Get platform-specific deployment scripts"""
    scripts = {}

    if platform == 'intune':
        scripts['detection'] = '''# Intune Detection Script
$AgentPath = "C:\\Program Files\\AuditAgent\\fleet-agent.ps1"
if (Test-Path $AgentPath) {
    Write-Host "Installed"
    exit 0
} else {
    exit 1
}
'''
        scripts['remediation'] = '''# Intune Remediation Script - calls installer
$InstallerUrl = "https://your-server:5000/api/agent/download/installer/windows?server_url=https://your-server:5000&api_key=YOUR_KEY"
$TempScript = "$env:TEMP\\Install-AuditAgent.ps1"
Invoke-WebRequest -Uri $InstallerUrl -OutFile $TempScript -UseBasicParsing
& $TempScript
Remove-Item $TempScript -Force
'''
        scripts['direct_api_windows_host'] = '''# Intune Proactive Remediation - Direct API host endpoint setup (Windows)
$ServerUrl = "https://your-server:5000"
$ApiKey = "YOUR_DIRECT_API_KEY"
$SigningKey = "YOUR_DIRECT_API_SIGNING_KEY"
$ScriptUrl = "$ServerUrl/api/agent/download/standalone/direct-api-windows-host-setup"
$TempScript = "$env:TEMP\\setup-direct-api-windows-host.ps1"

Invoke-WebRequest -Uri $ScriptUrl -OutFile $TempScript -UseBasicParsing
& powershell -ExecutionPolicy Bypass -File $TempScript -ApiKey $ApiKey -SigningKey $SigningKey -Port 8443
Remove-Item $TempScript -Force
'''

    elif platform == 'sccm':
        scripts['install'] = '''# SCCM Application Installation
# Download and run the installer
$InstallerUrl = "https://your-server:5000/api/agent/download/installer/windows"
$TempScript = "$env:TEMP\\Install-AuditAgent.ps1"
Invoke-WebRequest -Uri $InstallerUrl -OutFile $TempScript -UseBasicParsing
& $TempScript
'''
        scripts['uninstall'] = '''# SCCM Application Uninstallation
& "C:\\Program Files\\AuditAgent\\fleet-agent.ps1" -Action uninstall
Remove-Item "C:\\Program Files\\AuditAgent" -Recurse -Force
'''
        scripts['detection'] = '''# SCCM Detection Method
Test-Path "C:\\Program Files\\AuditAgent\\fleet-agent.ps1"
'''
        scripts['direct_api_windows_host'] = '''# SCCM Program - Direct API host endpoint setup (Windows)
$ServerUrl = "https://your-server:5000"
$ApiKey = "YOUR_DIRECT_API_KEY"
$SigningKey = "YOUR_DIRECT_API_SIGNING_KEY"
$ScriptUrl = "$ServerUrl/api/agent/download/standalone/direct-api-windows-host-setup"
$TempScript = "$env:TEMP\\setup-direct-api-windows-host.ps1"

Invoke-WebRequest -Uri $ScriptUrl -OutFile $TempScript -UseBasicParsing
& powershell -ExecutionPolicy Bypass -File $TempScript -ApiKey $ApiKey -SigningKey $SigningKey -Port 8443
'''

    elif platform == 'ansible':
        if os_type == 'windows':
            scripts['playbook'] = '''---
# Ansible Playbook for Windows Agent Deployment
- name: Deploy Audit Fleet Agent
  hosts: windows_servers
  tasks:
    - name: Download installer
      win_get_url:
        url: "{{ audit_server_url }}/api/agent/download/installer/windows?server_url={{ audit_server_url }}&api_key={{ audit_api_key }}"
        dest: C:\\Temp\\Install-AuditAgent.ps1

    - name: Run installer
      win_shell: C:\\Temp\\Install-AuditAgent.ps1
      args:
        executable: powershell

    - name: Cleanup
      win_file:
        path: C:\\Temp\\Install-AuditAgent.ps1
        state: absent
'''
            scripts['direct_api_windows_host_playbook'] = '''---
# Ansible Playbook for Windows Direct API Host Setup
- name: Configure Direct API endpoint on Windows hosts
    hosts: windows_servers
    tasks:
        - name: Download Direct API setup script
            win_get_url:
                url: "{{ audit_server_url }}/api/agent/download/standalone/direct-api-windows-host-setup"
                dest: C:\\Temp\\setup-direct-api-windows-host.ps1

        - name: Execute Direct API setup
            win_shell: >
                powershell -ExecutionPolicy Bypass -File C:\\Temp\\setup-direct-api-windows-host.ps1
                -ApiKey "{{ direct_api_key }}"
                -SigningKey "{{ direct_api_signing_key }}"
                -Port 8443
            args:
                executable: powershell
'''
        else:
            scripts['playbook'] = '''---
# Ansible Playbook for Linux Agent Deployment
- name: Deploy Audit Fleet Agent
  hosts: linux_servers
  become: yes
  tasks:
    - name: Download installer
      get_url:
        url: "{{ audit_server_url }}/api/agent/download/installer/linux?server_url={{ audit_server_url }}&api_key={{ audit_api_key }}"
        dest: /tmp/install-audit-agent.sh
        mode: '0755'

    - name: Run installer
      shell: /tmp/install-audit-agent.sh

    - name: Cleanup
      file:
        path: /tmp/install-audit-agent.sh
        state: absent
'''
            scripts['direct_api_linux_host_playbook'] = '''---
# Ansible Playbook for Linux Direct API Host Setup
- name: Configure Direct API endpoint on Linux hosts
    hosts: linux_servers
    become: yes
    tasks:
        - name: Download Direct API setup script
            get_url:
                url: "{{ audit_server_url }}/api/agent/download/standalone/direct-api-linux-host-setup"
                dest: /tmp/setup-direct-api-linux-host.sh
                mode: '0755'

        - name: Execute Direct API setup
            shell: >
                bash /tmp/setup-direct-api-linux-host.sh
                --api-key "{{ direct_api_key }}"
                --signing-key "{{ direct_api_signing_key }}"
                --port 8443
'''

    elif platform == 'puppet':
        scripts['manifest'] = '''# Puppet Manifest for Agent Deployment
class audit_agent (
  $server_url = 'https://your-server:5000',
  $api_key = '',
) {
  $install_script = $facts['os']['family'] ? {
    'windows' => "Invoke-WebRequest -Uri '${server_url}/api/agent/download/installer/windows?server_url=${server_url}&api_key=${api_key}' -OutFile C:\\\\Temp\\\\install.ps1; & C:\\\\Temp\\\\install.ps1",
    default   => "curl -fsSL '${server_url}/api/agent/download/installer/linux?server_url=${server_url}&api_key=${api_key}' | bash",
  }

  exec { 'install_audit_agent':
    command => $install_script,
    creates => $facts['os']['family'] ? {
      'windows' => 'C:/Program Files/AuditAgent/fleet-agent.ps1',
      default   => '/opt/audit-agent/fleet-agent.sh',
    },
  }
}
'''

    elif platform == 'terraform':
        scripts['module'] = '''# Terraform Module for Agent Deployment
variable "audit_server_url" {
  description = "URL of the audit server"
  type        = string
}

variable "audit_api_key" {
  description = "API key for agent authentication"
  type        = string
  sensitive   = true
}

# For AWS EC2 instances
resource "aws_instance" "example" {
  # ... instance config ...

  user_data = <<-EOF
    #!/bin/bash
    curl -fsSL "${var.audit_server_url}/api/agent/download/installer/linux?server_url=${var.audit_server_url}&api_key=${var.audit_api_key}" | bash
  EOF
}

# For Azure VMs
resource "azurerm_virtual_machine_extension" "audit_agent" {
  name                 = "audit-agent"
  virtual_machine_id   = azurerm_virtual_machine.example.id
  publisher            = "Microsoft.Azure.Extensions"
  type                 = "CustomScript"
  type_handler_version = "2.0"

  settings = jsonencode({
    commandToExecute = "curl -fsSL '${var.audit_server_url}/api/agent/download/installer/linux?server_url=${var.audit_server_url}&api_key=${var.audit_api_key}' | bash"
  })
}
'''

    else:
        # Generic scripts
        if os_type == 'windows':
            scripts['install'] = '''# Generic Windows Installation
$ServerUrl = "https://your-server:5000"
$ApiKey = "your-api-key"
$InstallerUrl = "$ServerUrl/api/agent/download/installer/windows?server_url=$ServerUrl&api_key=$ApiKey"
Invoke-WebRequest -Uri $InstallerUrl -OutFile "$env:TEMP\\Install-AuditAgent.ps1" -UseBasicParsing
& "$env:TEMP\\Install-AuditAgent.ps1"
'''
        else:
            scripts['install'] = '''#!/bin/bash
# Generic Linux Installation
SERVER_URL="https://your-server:5000"
API_KEY="your-api-key"
curl -fsSL "$SERVER_URL/api/agent/download/installer/linux?server_url=$SERVER_URL&api_key=$API_KEY" | bash
'''

    return scripts


# ============================================================================
# Heartbeat Validation Endpoint (v5.3.0 - Strict Heartbeat Gating)
# ============================================================================

@fleet_agent_bp.route('/api/managed-agent/heartbeat', methods=['GET'])
@require_api_key
def agent_heartbeat_validation():
    """
    Heartbeat endpoint for Management Agent v5.3.0 strict heartbeat validation.

    Called by agent on EVERY polling cycle to validate connectivity and license status.
    If heartbeat fails, agent should stop execution after 3 consecutive failures.

    Query Parameters:
        agent_id: The agent identifier (required)

    Response (200 OK):
    {
        "status": "ok",
        "license_status": "active",
        "license_tier": "professional",
        "license_expiry": "2027-02-20T23:59:59Z",
        "server_time": "2026-02-20T10:00:00Z",
        "max_agents": 10,
        "current_agents": 3
    }

    Response (401):
    {
        "error": "invalid_key"
    }

    Response (403):
    {
        "error": "license_expired" or "license_invalid"
    }
    """
    try:
        agent_id = request.args.get('agent_id')

        if not agent_id:
            logger.warning("Heartbeat request without agent_id")
            return jsonify({'error': 'agent_id required'}), 400

        # Find agent in fleet agents registry
        agent_entry = None
        server_id = None
        for sid, agent in _managed_agents.items():
            if agent.get('agent_id') == agent_id:
                agent_entry = agent
                server_id = sid
                break

        if not agent_entry:
            logger.warning(f"Heartbeat from unregistered agent: {agent_id}")
            return jsonify({'error': 'agent_not_found'}), 404

        # Check license status (if database available)
        license_status = 'unknown'
        license_tier = 'community'
        license_expiry = None
        max_agents = 0
        current_agents = 0

        if DATABASE_AVAILABLE and _db_session:
            try:
                session = _db_session()

                # Find server associated with this agent
                server = session.query(Server).filter_by(agent_id=agent_id).first()

                if server:
                    # Look up customer and license info
                    # This assumes Server has a relationship to Customer via another table
                    # Adjust based on actual schema

                    license_status = 'active'  # Default: active
                    license_tier = 'professional'  # Default: professional
                    license_expiry = (datetime.utcnow() + timedelta(days=365)).isoformat()
                    max_agents = 10
                    current_agents = 1

                    # In a real implementation, fetch from Customer/License tables
                    # Left as exercise for implementer to adjust to actual schema

            except Exception as db_err:
                logger.warning(f"Database license check failed: {db_err}")

        # Update agent heartbeat status in database
        if DATABASE_AVAILABLE and _db_session:
            try:
                session = _db_session()
                agent_model = session.query(FleetAgent).filter_by(
                    agent_id=agent_id
                ).first()

                if agent_model:
                    agent_model.last_heartbeat_at = datetime.utcnow()
                    agent_model.consecutive_heartbeat_failures = 0
                    agent_model.last_heartbeat_status = 'ok'
                    agent_model.heartbeat_failure_reason = None
                    session.commit()
                    logger.debug(f"Updated heartbeat for agent: {agent_id}")

            except Exception as db_err:
                logger.warning(f"Failed to update agent heartbeat: {db_err}")

        # Return success response
        return jsonify({
            'status': 'ok',
            'license_status': license_status,
            'license_tier': license_tier,
            'license_expiry': license_expiry,
            'server_time': datetime.utcnow().isoformat(),
            'max_agents': max_agents,
            'current_agents': current_agents
        }), 200

    except Exception as e:
        logger.error(f"Heartbeat validation failed: {e}")
        return jsonify({'error': 'internal_error', 'message': str(e)}), 500


@fleet_agent_bp.route('/api/managed-agent/health', methods=['GET'])
@require_auth_and_permission('manage_servers')
def managed_agents_health():
    """
    Get health status of all fleet agents for dashboard.

    Used by dashboard to show:
    - Agent status (Active/Dark/Down)
    - Last heartbeat timestamp
    - Consecutive failure count
    - License information

    Returns:
    {
        "agents": [
            {
                "agent_id": "prod-app-01",
                "name": "Production App Server",
                "status": "active",
                "license_tier": "professional",
                "last_heartbeat_at": "2026-02-20T10:05:30Z",
                "last_heartbeat_age_seconds": 120,
                "consecutive_failures": 0,
                "license_expires": "2027-02-20T23:59:59Z"
            }
        ]
    }
    """
    try:
        now = datetime.utcnow()
        agents_health = []

        if DATABASE_AVAILABLE and _db_session:
            try:
                session = _db_session()
                agents = session.query(FleetAgent).filter(
                    FleetAgent.is_active,
                    FleetAgent.agent_type == 'managed'
                ).all()

                for agent in agents:
                    # Calculate heartbeat age
                    if agent.last_heartbeat_at:
                        heartbeat_age = (now - agent.last_heartbeat_at).total_seconds()
                    else:
                        heartbeat_age = float('inf')

                    # Determine status based on age
                    if heartbeat_age < 300:  # < 5 min
                        status = 'active'
                    elif heartbeat_age < 1800:  # < 30 min
                        status = 'dark'
                    else:
                        status = 'down'

                    # Determine if license is valid
                    license_status = 'active'
                    if agent.last_heartbeat_status == 'license_expired':
                        license_status = 'expired'
                    elif agent.last_heartbeat_status == 'license_invalid':
                        license_status = 'invalid'

                    agents_health.append({
                        'id': agent.id,
                        'agent_id': agent.agent_id,
                        'name': agent.name,
                        'status': status,
                        'license_status': license_status,
                        'license_tier': 'professional',
                        'last_heartbeat_at': agent.last_heartbeat_at.isoformat() if agent.last_heartbeat_at else None,
                        'last_heartbeat_age_seconds': int(heartbeat_age) if heartbeat_age != float('inf') else None,
                        'consecutive_failures': agent.consecutive_heartbeat_failures,
                        'last_heartbeat_status': agent.last_heartbeat_status,
                        'heartbeat_failure_reason': agent.heartbeat_failure_reason
                    })

            except Exception as db_err:
                logger.warning(f"Database health check failed: {db_err}")

        return jsonify({
            'success': True,
            'agents': agents_health,
            'total': len(agents_health),
            'timestamp': now.isoformat()
        })

    except Exception as e:
        logger.error(f"Failed to get agent health: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
