"""Agent path resolution helpers for canonical `agents/` layout."""

from pathlib import Path
from config import ROOT_DIR


def get_standalone_agent_dir() -> Path:
    """Return path to lightweight web agent directory."""
    root = Path(ROOT_DIR)
    return root / "agents" / "html-standalone"


def get_hypervisor_agent_dir() -> Path:
    """Return path to hypervisor agent directory."""
    root = Path(ROOT_DIR)
    return root / "agents" / "hypervisor"


def get_jre_shared_dir() -> Path:
    """Return path to shared JRE agent directory."""
    root = Path(ROOT_DIR)
    return root / "agents" / "jre" / "shared"
