"""
Agent Routes - Standalone Agent Communication API

Provides endpoints for:
- Agent registration (/api/agent/register)
- Agent heartbeat (/api/agent/heartbeat)
- Audit script distribution (/api/agent/audits/<path>)
- Results upload (/api/agent/results)
- Agent management (/api/agent/list, /api/agent/<id>)
"""

import os
import json
import secrets
import hashlib
import hmac
import base64
import re
import shutil
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request, g, current_app
from functools import wraps
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
    _CRYPTOGRAPHY_AVAILABLE = True
except Exception:
    _CRYPTOGRAPHY_AVAILABLE = False

# Import from config
from config import logger
from config import ROOT_DIR
from api.agent_pathing import get_standalone_agent_dir
from api.upload_rate_limits import get_standalone_upload_limit
from api.sensitive_tool_auth import (
    authenticate_sensitive_tool,
    get_sensitive_tool_auth_status,
    require_sensitive_tool_token,
    revoke_sensitive_tool_auth,
)

# Import auth decorators
from auth_core import require_api_key, conditional_limit, require_auth_and_permission, require_auth_and_role

try:
    from logging_utils import log_audit
except ImportError:
    def log_audit(*args, **kwargs):
        return None

# Import result encryption (Phase 2)
try:
    from api.result_encryption import ResultEncryption
    _ENCRYPTION_AVAILABLE = True
except ImportError:
    _ENCRYPTION_AVAILABLE = False

# Create blueprint
agent_bp = Blueprint('agent', __name__)

# ============================================================================
# Agent Storage (in-memory + file-based for persistence)
# ============================================================================
AGENTS_DIR = os.path.join(ROOT_DIR, 'data', 'agents')
AGENT_RESULTS_DIR = os.path.join(ROOT_DIR, 'data', 'agent_results')
AUDITS_DIR = os.path.join(ROOT_DIR, 'audits')
STANDALONE_AGENT_DIR = str(get_standalone_agent_dir())

# In-memory cache
_agents_cache = {}
_last_cache_refresh = None

# Core attestation controls for standalone uploads
CORE_ATTESTATION_TTL_SECONDS = int(os.environ.get('AGENT_CORE_ATTESTATION_TTL_SEC', '300'))
REQUIRE_CORE_ATTESTATION = os.environ.get('AGENT_REQUIRE_CORE_ATTESTATION', 'true').lower() == 'true'
AGENT_UPDATE_TOKEN_TTL_SECONDS = int(os.environ.get('AGENT_UPDATE_TOKEN_TTL_SEC', '900'))
AGENT_UPDATE_POLICY_FILE = os.path.join(ROOT_DIR, 'data', 'agent_update_policy.json')

DEFAULT_AGENT_UPDATE_POLICY = {
    'auto_update_on_register': False,
    'auto_update_on_poll_drift': False,
    'rollout_mode': 'manual',
    'canary_limit': 5,
    'allow_downgrade': False,
    'cooldown_minutes': 60,
    'max_attempts': 3,
}


def _hash_api_key(api_key: str) -> str:
    """Create a SHA256 hash of an API key for secure storage/comparison

    We don't store old keys in plaintext - only their hashes for validation.
    """
    if not api_key:
        return ''
    return hashlib.sha256(api_key.encode()).hexdigest()


def _ensure_dirs():
    """Ensure required directories exist"""
    os.makedirs(AGENTS_DIR, exist_ok=True)
    os.makedirs(AGENT_RESULTS_DIR, exist_ok=True)


def _get_max_standalone_result_files_per_host():
    """Get max standalone result files per host from security settings."""
    default_limit = 5000
    try:
        from security_settings import get_security_setting
        value = int(get_security_setting('standalone_agent_result_max_files_per_host', default_limit))
        return max(0, value)
    except Exception:
        return default_limit


def _prune_host_result_files(host_dir, max_files):
    """Prune oldest result files in a host directory, keeping newest max_files."""
    if max_files <= 0 or not os.path.isdir(host_dir):
        return 0

    files = []
    for name in os.listdir(host_dir):
        if not name.endswith('.json'):
            continue
        path = os.path.join(host_dir, name)
        if os.path.isfile(path):
            files.append(path)

    overflow = len(files) - max_files
    if overflow <= 0:
        return 0

    files.sort(key=lambda p: os.path.getmtime(p))
    removed = 0
    for path in files[:overflow]:
        try:
            os.remove(path)
            removed += 1
        except OSError as err:
            logger.warning(f"Failed to prune standalone agent result file {path}: {err}")

    return removed


def _get_result_ingest_limits():
    """Get ingestion guardrail limits from security settings."""
    defaults = {
        'max_body_kb': 2048,
        'max_checks_per_result': 500,
        'max_output_chars': 200000,
    }
    try:
        from security_settings import get_security_setting
        return {
            'max_body_kb': max(128, int(get_security_setting('agent_result_ingest_max_body_kb', defaults['max_body_kb']))),
            'max_checks_per_result': max(1, int(get_security_setting('agent_result_ingest_max_checks_per_result', defaults['max_checks_per_result']))),
            'max_output_chars': max(1000, int(get_security_setting('agent_result_ingest_max_output_chars', defaults['max_output_chars']))),
        }
    except Exception:
        return defaults


def _is_result_ingest_blocked_by_disk_watermark():
    """Check if ingest should be blocked because free disk is below configured watermark."""
    defaults = {
        'enabled': True,
        'min_free_mb': 1024,
        'min_free_pct': 5,
    }
    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting('agent_result_ingest_disk_guard_enabled', defaults['enabled']))
        min_free_mb = max(128, int(get_security_setting('agent_result_ingest_min_free_disk_mb', defaults['min_free_mb'])))
        min_free_pct = max(1, int(get_security_setting('agent_result_ingest_min_free_disk_pct', defaults['min_free_pct'])))
    except Exception:
        enabled = defaults['enabled']
        min_free_mb = defaults['min_free_mb']
        min_free_pct = defaults['min_free_pct']

    if not enabled:
        return False, {}

    target_dir = AGENT_RESULTS_DIR
    os.makedirs(target_dir, exist_ok=True)
    usage = shutil.disk_usage(target_dir)
    free_mb = usage.free // (1024 * 1024)
    free_pct = (usage.free / usage.total * 100) if usage.total > 0 else 0
    blocked = free_mb < min_free_mb or free_pct < min_free_pct

    details = {
        'free_mb': int(free_mb),
        'free_pct': round(free_pct, 2),
        'min_free_mb': min_free_mb,
        'min_free_pct': min_free_pct,
    }
    return blocked, details


def _load_agents():
    """Load agents from disk"""
    global _agents_cache, _last_cache_refresh

    # Refresh cache if stale (> 60 seconds)
    if _last_cache_refresh and (datetime.now() - _last_cache_refresh).seconds < 60:
        return _agents_cache

    _ensure_dirs()
    _agents_cache = {}

    for filename in os.listdir(AGENTS_DIR):
        if filename.endswith('.json'):
            try:
                with open(os.path.join(AGENTS_DIR, filename), 'r') as f:
                    agent = json.load(f)
                    _agents_cache[agent['agent_id']] = agent
            except Exception as e:
                logger.error(f"Failed to load agent {filename}: {e}")

    _last_cache_refresh = datetime.now()
    return _agents_cache


def _save_agent(agent):
    """Save agent to disk"""
    _ensure_dirs()
    filepath = os.path.join(AGENTS_DIR, f"{agent['agent_id']}.json")
    with open(filepath, 'w') as f:
        json.dump(agent, f, indent=2, default=str)
    _agents_cache[agent['agent_id']] = agent


def _generate_agent_id(hostname, os_type):
    """Generate unique agent ID based on hostname and OS"""
    data = f"{hostname}-{os_type}-{datetime.now().isoformat()}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def _attestation_serializer():
    """Create serializer for short-lived core attestation tokens."""
    secret = (
        os.environ.get('AGENT_ATTESTATION_SECRET')
        or os.environ.get('FLASK_SECRET_KEY')
        or os.environ.get('SECRET_KEY')
    )
    if not secret:
        try:
            secret = current_app.config.get('SECRET_KEY')
        except Exception:
            secret = None
    if not secret:
        return None
    return URLSafeTimedSerializer(secret)


def _server_origin():
    return request.host_url.rstrip('/')


def _sha256_file(file_path: str) -> str:
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            sha256.update(chunk)
    return sha256.hexdigest()


def _version_tuple(version: str):
    if not version:
        return (0, 0, 0)
    match = re.search(r'(\d+)\.(\d+)\.(\d+)', str(version))
    if not match:
        return (0, 0, 0)
    return tuple(int(x) for x in match.groups())


def _extract_agent_version(file_path: str, default_version: str = '0.0.0') -> str:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        patterns = [
            r'AGENT_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'\$script:AgentVersion\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'\$AGENT_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'v([0-9]+\.[0-9]+\.[0-9]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                return match.group(1)
    except Exception as version_error:
        logger.debug(f"Unable to extract agent version from {file_path}: {version_error}")
    return default_version


def _find_latest_versioned_agent(prefix: str, extension: str):
    agent_dir = STANDALONE_AGENT_DIR
    if not os.path.isdir(agent_dir):
        return None, None

    best_path = None
    best_version = None
    best_tuple = (0, 0, 0)

    pattern = re.compile(rf'^{re.escape(prefix)}-v(\d+\.\d+\.\d+){re.escape(extension)}$')
    for filename in os.listdir(agent_dir):
        match = pattern.match(filename)
        if not match:
            continue
        version = match.group(1)
        version_key = _version_tuple(version)
        if version_key > best_tuple:
            best_tuple = version_key
            best_version = version
            best_path = os.path.join(agent_dir, filename)

    return best_path, best_version


def _resolve_update_artifact(agent_type: str, os_type: str):
    agent_dir = STANDALONE_AGENT_DIR
    is_windows = str(os_type).lower().startswith('windows')
    normalized_agent_type = str(agent_type).lower().strip()

    if normalized_agent_type not in ('standalone', 'managed'):
        return None

    if normalized_agent_type == 'standalone':
        filename = 'agent.ps1' if is_windows else 'agent.sh'
        file_path = os.path.join(agent_dir, filename)
        if not os.path.isfile(file_path):
            return None
        return {
            'agent_type': 'standalone',
            'os_type': 'windows' if is_windows else 'linux',
            'file_path': file_path,
            'filename': filename,
            'version': _extract_agent_version(file_path),
        }

    if is_windows:
        versioned_path, versioned_version = _find_latest_versioned_agent('fleet-agent', '.ps1')
        fallback_path = os.path.join(agent_dir, 'fleet-agent.ps1')
    else:
        versioned_path, versioned_version = _find_latest_versioned_agent('fleet-agent', '.sh')
        fallback_path = os.path.join(agent_dir, 'fleet-agent.sh')

    if versioned_path and os.path.isfile(versioned_path):
        return {
            'agent_type': 'managed',
            'os_type': 'windows' if is_windows else 'linux',
            'file_path': versioned_path,
            'filename': os.path.basename(versioned_path),
            'version': versioned_version or _extract_agent_version(versioned_path),
        }

    if os.path.isfile(fallback_path):
        return {
            'agent_type': 'managed',
            'os_type': 'windows' if is_windows else 'linux',
            'file_path': fallback_path,
            'filename': os.path.basename(fallback_path),
            'version': _extract_agent_version(fallback_path),
        }

    return None


def _load_update_policy():
    if os.path.exists(AGENT_UPDATE_POLICY_FILE):
        try:
            with open(AGENT_UPDATE_POLICY_FILE, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    merged = DEFAULT_AGENT_UPDATE_POLICY.copy()
                    merged.update(loaded)
                    return merged
        except Exception as e:
            logger.warning(f"Failed loading update policy for poll auto-enqueue: {e}")
    return DEFAULT_AGENT_UPDATE_POLICY.copy()


def _find_recent_self_update_command(commands):
    candidates = [cmd for cmd in commands if cmd.get('command_type') == 'self_update']
    if not candidates:
        return None
    candidates.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return candidates[0]


def _maybe_enqueue_self_update_on_poll(agent_id: str):
    policy = _load_update_policy()
    if not policy.get('auto_update_on_poll_drift', False):
        return None

    agents = _load_agents()
    agent = agents.get(agent_id)
    if not agent:
        return None

    os_type = (agent.get('os_type') or 'linux').lower()
    current_version = agent.get('agent_version') or agent.get('version') or '0.0.0'
    artifact = _resolve_update_artifact('managed', os_type)
    if not artifact:
        return None

    target_version = artifact.get('version', '0.0.0')
    current_tuple = _version_tuple(current_version)
    target_tuple = _version_tuple(target_version)

    if target_tuple == current_tuple:
        return None

    if target_tuple < current_tuple and not bool(policy.get('allow_downgrade', False)):
        return None

    commands = _load_agent_commands(agent_id)
    if any(
        cmd.get('command_type') == 'self_update' and cmd.get('status') in {'pending', 'acknowledged', 'in_progress'}
        for cmd in commands
    ):
        return None

    recent = _find_recent_self_update_command(commands)
    cooldown_minutes = max(1, int(policy.get('cooldown_minutes', 60)))
    max_attempts = max(1, int(policy.get('max_attempts', 3)))

    if recent:
        try:
            recent_created = datetime.fromisoformat(recent.get('created_at'))
            age_minutes = (datetime.now() - recent_created).total_seconds() / 60.0
            if age_minutes < cooldown_minutes:
                return None
        except Exception as parse_error:
            logger.debug(f"Skipping self-update cooldown timestamp parsing for {agent_id}: {parse_error}")

        if recent.get('status') == 'failed':
            failed_attempts = sum(
                1
                for cmd in commands
                if cmd.get('command_type') == 'self_update' and cmd.get('status') == 'failed'
            )
            if failed_attempts >= max_attempts:
                return None

    command = queue_command_for_agent(
        agent_id=agent_id,
        command_type='self_update',
        command_data={
            'target_version': target_version,
            'current_version': current_version,
            'os_type': os_type,
            'agent_type': 'managed',
            'trigger': 'auto_poll',
        },
        requested_by='system:auto-poll',
        priority=2,
        expires_hours=24,
    )
    logger.info(f"Auto-enqueued managed self_update command for {agent_id}: {command.get('id')}")
    return command


def _issue_update_signature(payload: dict):
    serializer = _attestation_serializer()
    if not serializer:
        return None
    return serializer.dumps(payload, salt='agent-update-manifest-v1')


def _verify_update_signature(token: str):
    serializer = _attestation_serializer()
    if not serializer:
        return None, 'Update signing secret is not configured on server'
    try:
        payload = serializer.loads(
            token,
            salt='agent-update-manifest-v1',
            max_age=AGENT_UPDATE_TOKEN_TTL_SECONDS,
        )
        return payload, None
    except SignatureExpired:
        return None, 'Update signature token expired'
    except BadSignature:
        return None, 'Invalid update signature token'


def _issue_core_attestation_token(nonce: str, agent_id: str | None, hostname: str | None):
    """Issue signed token proving this endpoint is a trusted core server."""
    serializer = _attestation_serializer()
    if not serializer:
        return None

    payload = {
        'nonce': nonce,
        'server_origin': _server_origin(),
        'agent_id': agent_id,
        'hostname': hostname,
        'issued_at': datetime.utcnow().isoformat(),
        'jti': secrets.token_hex(8),
    }

    return serializer.dumps(payload, salt='agent-core-attestation-v1')


def _verify_core_attestation_token(token: str, agent_id: str | None, hostname: str | None):
    """Validate signed core attestation token for standalone result uploads."""
    if not token:
        return False, 'Missing core attestation token'

    serializer = _attestation_serializer()
    if not serializer:
        return False, 'Core attestation secret is not configured on server'

    try:
        payload = serializer.loads(
            token,
            salt='agent-core-attestation-v1',
            max_age=CORE_ATTESTATION_TTL_SECONDS,
        )
    except SignatureExpired:
        return False, 'Core attestation token expired'
    except BadSignature:
        return False, 'Invalid core attestation token signature'

    if payload.get('server_origin') != _server_origin():
        return False, 'Core attestation token server mismatch'

    token_agent_id = payload.get('agent_id')
    if agent_id and token_agent_id and token_agent_id != agent_id:
        return False, 'Core attestation token agent mismatch'

    token_hostname = payload.get('hostname')
    if hostname and token_hostname and token_hostname != hostname:
        return False, 'Core attestation token hostname mismatch'

    return True, None


# ============================================================================
# API Key Validation for Agents
# ============================================================================
def require_agent_api_key(f):
    """Decorator to require API key for agent endpoints"""
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get('X-API-Key') or request.args.get('api_key')

        # Allow if valid API key provided
        if api_key:
            # Check database for stored API keys first
            if _validate_agent_api_key_from_db(api_key):
                return f(*args, **kwargs)

            # Fall back to environment variable
            valid_keys = os.environ.get('AGENT_API_KEYS', '').split(',')
            valid_keys = [k.strip() for k in valid_keys if k.strip()]  # Clean up
            if api_key in valid_keys:
                return f(*args, **kwargs)

            # If no keys configured anywhere, allow in dev mode
            if not valid_keys and not _has_db_api_keys():
                logger.warning("No API keys configured - allowing request (dev mode)")
                return f(*args, **kwargs)

        # Also allow requests from registered agents with valid agent_id
        agent_id = request.headers.get('X-Agent-ID')
        if agent_id:
            agents = _load_agents()
            if agent_id in agents:
                return f(*args, **kwargs)

        return jsonify({'error': 'Unauthorized', 'message': 'Valid API key or agent ID required'}), 401

    return decorated


def _validate_agent_api_key_from_db(api_key: str) -> bool:
    """
    Validate API key against stored keys in the database.

    Checks:
    1. Global agent_api_keys list in security settings
    2. Individual agent API keys (with grace period support)

    Grace period keys are checked by hash to avoid storing old keys in plaintext.
    """
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings()

        # Check if key is in the configured global list
        stored_keys = settings.get('agent_api_keys', [])
        if isinstance(stored_keys, str):
            stored_keys = [k.strip() for k in stored_keys.split(',') if k.strip()]

        if api_key in stored_keys:
            return True

        # Check individual agent keys and grace period keys
        try:
            agents = _load_agents()
            api_key_hash = _hash_api_key(api_key)
            now = datetime.now()

            for agent_id, agent in agents.items():
                # Check current agent API key
                if agent.get('api_key') == api_key:
                    return True

                # Check grace period keys (for recently rotated keys)
                grace_keys = agent.get('grace_period_keys', [])
                for grace_key in grace_keys:
                    try:
                        # Check if grace period has expired
                        expires_str = grace_key.get('expires_at', '')
                        if expires_str:
                            # Handle various ISO format variations
                            expires_str = expires_str.replace('Z', '').replace('+00:00', '')
                            expires_at = datetime.fromisoformat(expires_str)
                            if expires_at > now:
                                # Grace period still valid - check key hash
                                if grace_key.get('key_hash') == api_key_hash:
                                    logger.debug(f"Agent {agent_id}: Using grace period key (expires {expires_at})")
                                    return True
                    except (ValueError, TypeError) as e:
                        logger.debug(f"Error parsing grace period expiry: {e}")
                        continue
        except Exception as agent_err:
            logger.debug(f"Error checking agent keys: {agent_err}")

        return False

    except Exception as e:
        logger.debug(f"Could not validate API key from settings: {e}")
        return False


def _has_db_api_keys() -> bool:
    """Check if any API keys are configured in the database."""
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings()
        stored_keys = settings.get('agent_api_keys', [])
        if isinstance(stored_keys, str):
            stored_keys = [k.strip() for k in stored_keys.split(',') if k.strip()]
        return len(stored_keys) > 0
    except Exception:
        return False


def _get_managed_request_signature_settings():
    """Load managed request-signature settings with sane bounds."""
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings() or {}
    except Exception:
        settings = {}

    require_signatures = bool(settings.get('fleet_agent_require_request_signatures', False))

    max_age_value = settings.get('fleet_agent_request_signature_max_age_seconds', 300)
    try:
        max_age = int(max_age_value)
    except (TypeError, ValueError):
        max_age = 300
    max_age = max(30, min(3600, max_age))

    signing_key = str(settings.get('fleet_agent_request_signing_key', '') or '').strip()
    if not signing_key:
        signing_key = os.environ.get('FLEET_AGENT_REQUEST_SIGNING_KEY', '').strip()

    ecdsa_dual_verify_enabled = bool(settings.get('fleet_agent_request_signature_ecdsa_dual_verify_enabled', False))

    ecdsa_public_key_pem = str(settings.get('fleet_agent_request_signature_ecdsa_public_key', '') or '').strip()
    if not ecdsa_public_key_pem:
        ecdsa_public_key_pem = os.environ.get('FLEET_AGENT_REQUEST_SIGNATURE_ECDSA_PUBLIC_KEY', '').strip()

    return {
        'require_request_signatures': require_signatures,
        'request_signature_max_age_seconds': max_age,
        'request_signing_key': signing_key,
        'ecdsa_dual_verify_enabled': ecdsa_dual_verify_enabled,
        'ecdsa_public_key_pem': ecdsa_public_key_pem,
    }


def _extract_signature_candidate(signature_header: str, prefix: str):
    value = str(signature_header or '').strip()
    expected = f"{prefix}:"
    if value.lower().startswith(expected):
        return value[len(expected):].strip()
    return ''


def _verify_hmac_signature(signature_header: str, signing_key: str, message: bytes):
    if not signing_key:
        return False

    hmac_candidate = _extract_signature_candidate(signature_header, 'hmac')
    if not hmac_candidate:
        raw_value = str(signature_header or '').strip().lower()
        if ':' in raw_value:
            return False
        hmac_candidate = raw_value

    computed_signature = hmac.new(
        signing_key.encode('utf-8'),
        message,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(hmac_candidate.lower(), computed_signature)


def _verify_ecdsa_signature(signature_header: str, public_key_pem: str, message: bytes):
    if not public_key_pem:
        return False, 'ecdsa public key is not configured'
    if not _CRYPTOGRAPHY_AVAILABLE:
        return False, 'cryptography package unavailable for ECDSA verification'

    ecdsa_b64 = _extract_signature_candidate(signature_header, 'ecdsa')
    if not ecdsa_b64:
        return False, 'missing ecdsa signature prefix'

    try:
        signature_bytes = base64.b64decode(ecdsa_b64)
    except Exception:
        return False, 'invalid base64 ecdsa signature'

    try:
        public_key = load_pem_public_key(public_key_pem.encode('utf-8'))
        public_key.verify(signature_bytes, message, ec.ECDSA(hashes.SHA256()))
    except Exception:
        return False, 'ecdsa signature mismatch'

    return True, ''


def _parse_request_timestamp(timestamp_header: str):
    if not timestamp_header:
        return None

    if timestamp_header.isdigit():
        try:
            return datetime.utcfromtimestamp(int(timestamp_header))
        except (OverflowError, ValueError):
            return None

    normalized = str(timestamp_header).strip()
    if normalized.endswith('Z'):
        normalized = normalized[:-1] + '+00:00'
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None

    if parsed.tzinfo is not None:
        return parsed.replace(tzinfo=None)
    return parsed


def _log_request_auth_event(operation: str, outcome: str, agent_id: str = '', reason: str = ''):
    """Emit structured request-auth security events for command lifecycle paths."""
    payload = {
        'event_type': 'AGENT_REQUEST_SIGNATURE_AUTH',
        'operation': operation,
        'outcome': outcome,
        'agent_id': str(agent_id or ''),
        'reason': str(reason or ''),
        'method': request.method,
        'path': request.path,
        'source_ip': request.remote_addr,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
    }

    line = f"SECURITY_EVENT|{json.dumps(payload, sort_keys=True)}"
    if outcome == 'allow':
        logger.info(line)
    else:
        logger.warning(line)


def _verify_command_request_signature(agent_id: str):
    """Verify optional Phase 3 signature headers on command endpoints."""
    auth = _get_managed_request_signature_settings()
    if not auth['require_request_signatures']:
        return True, None

    signing_key = auth['request_signing_key']
    if not signing_key:
        _log_request_auth_event('command_request_signature', 'deny', agent_id, 'signing key is not configured')
        return False, 'Request signature enforcement enabled but signing key is not configured'

    timestamp_header = request.headers.get('X-Agent-Timestamp', '').strip()
    payload_hash_header = request.headers.get('X-Agent-Content-SHA256', '').strip().lower()
    signature_header = request.headers.get('X-Agent-Signature', '').strip()

    if not timestamp_header or not payload_hash_header or not signature_header:
        _log_request_auth_event('command_request_signature', 'deny', agent_id, 'missing signature headers')
        return False, 'Missing signature headers (X-Agent-Timestamp, X-Agent-Content-SHA256, X-Agent-Signature)'

    request_time = _parse_request_timestamp(timestamp_header)
    if request_time is None:
        _log_request_auth_event('command_request_signature', 'deny', agent_id, 'invalid request timestamp format')
        return False, 'Invalid request timestamp format'

    age_seconds = abs((datetime.utcnow() - request_time).total_seconds())
    if age_seconds > auth['request_signature_max_age_seconds']:
        _log_request_auth_event('command_request_signature', 'deny', agent_id, 'request timestamp outside freshness window')
        return False, 'Request timestamp is outside allowed freshness window'

    body_raw = request.get_data(cache=True, as_text=False) or b''
    computed_payload_hash = hashlib.sha256(body_raw).hexdigest()
    if not hmac.compare_digest(payload_hash_header, computed_payload_hash):
        _log_request_auth_event('command_request_signature', 'deny', agent_id, 'request payload hash mismatch')
        return False, 'Request payload hash mismatch'

    signature_message = (
        f"{request.method}:{request.path}:{agent_id}:{timestamp_header}:{computed_payload_hash}"
    ).encode('utf-8')

    hmac_ok = _verify_hmac_signature(signature_header, signing_key, signature_message)

    if not auth.get('ecdsa_dual_verify_enabled'):
        if not hmac_ok:
            _log_request_auth_event('command_request_signature', 'deny', agent_id, 'request signature mismatch')
            return False, 'Request signature mismatch'
        _log_request_auth_event('command_request_signature', 'allow', agent_id, 'verifier=hmac')
        return True, None

    ecdsa_ok, ecdsa_reason = _verify_ecdsa_signature(
        signature_header,
        auth.get('ecdsa_public_key_pem', ''),
        signature_message,
    )

    if ecdsa_ok:
        _log_request_auth_event('command_request_signature', 'allow', agent_id, 'verifier=ecdsa')
        return True, None

    if hmac_ok:
        _log_request_auth_event('command_request_signature', 'allow', agent_id, 'verifier=hmac')
        return True, None

    _log_request_auth_event(
        'command_request_signature',
        'deny',
        agent_id,
        f'request signature mismatch (ecdsa_reason={ecdsa_reason})',
    )
    return False, 'Request signature mismatch'

    return True, None


# ============================================================================
# Agent Registration
# ============================================================================
@agent_bp.route('/api/agent/register', methods=['POST'])
@conditional_limit("20 per hour")
def register_agent():
    """
    Register a new agent or update existing registration

    Request body:
    {
        "hostname": "WORKSTATION-01",
        "os_name": "Windows 11 Pro",
        "os_version": "10.0.22631",
        "os_type": "windows-desktop",  # windows-server, windows-desktop, linux
        "architecture": "x64",
        "agent_version": "1.0.0",
        "detected_software": ["defender", "firewall", "bitlocker"]
    }
    """
    try:
        data = request.json
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request body'}), 400

        hostname = data.get('hostname')
        os_type = data.get('os_type', 'unknown')
        requested_agent_type = str(data.get('agent_type', '') or '').strip().lower()
        if requested_agent_type not in ('lightweight', 'managed', 'standalone', 'hypervisor'):
            requested_agent_type = 'lightweight'

        if not hostname:
            return jsonify({'success': False, 'error': 'Hostname is required'}), 400

        # Load security settings for approval workflow
        from security_settings import get_security_setting
        require_approval = get_security_setting('agent_require_approval', False)
        auto_approve_known = get_security_setting('agent_auto_approve_known_hosts', True)

        # Check for existing agent with same hostname
        agents = _load_agents()
        existing_agent = None
        for agent in agents.values():
            if agent.get('hostname') == hostname:
                existing_agent = agent
                break

        if existing_agent:
            # Update existing agent
            agent_id = existing_agent['agent_id']
            agent = existing_agent
            agent['last_seen'] = datetime.now().isoformat()
            agent['os_name'] = data.get('os_name', agent.get('os_name'))
            agent['os_version'] = data.get('os_version', agent.get('os_version'))
            agent['os_type'] = os_type
            agent['architecture'] = data.get('architecture', agent.get('architecture'))
            agent['agent_version'] = data.get('agent_version', agent.get('agent_version'))
            agent['detected_software'] = data.get('detected_software', agent.get('detected_software', []))
            agent['agent_type'] = requested_agent_type or agent.get('agent_type', 'lightweight')
            agent['registration_count'] = agent.get('registration_count', 0) + 1

            # Auto-approve known hosts if setting is enabled
            if auto_approve_known and agent.get('status') == 'pending_approval':
                agent['status'] = 'active'
                agent['approved_at'] = datetime.now().isoformat()
                agent['approved_reason'] = 'auto_approved_known_host'
                logger.info(f"Agent auto-approved (known host): {hostname} ({agent_id})")

            logger.info(f"Agent re-registered: {hostname} ({agent_id})")
        else:
            # Create new agent
            agent_id = _generate_agent_id(hostname, os_type)

            # Determine initial status based on approval workflow
            initial_status = 'pending_approval' if require_approval else 'active'

            agent = {
                'agent_id': agent_id,
                'hostname': hostname,
                'os_name': data.get('os_name', 'Unknown'),
                'os_version': data.get('os_version', ''),
                'os_type': os_type,
                'architecture': data.get('architecture', 'Unknown'),
                'agent_version': data.get('agent_version', 'Unknown'),
                'agent_type': requested_agent_type,
                'detected_software': data.get('detected_software', []),
                'registered_at': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat(),
                'status': initial_status,
                'registration_count': 1
            }

            if require_approval:
                logger.info(f"New agent pending approval: {hostname} ({agent_id})")
            else:
                logger.info(f"New agent registered: {hostname} ({agent_id})")

        _save_agent(agent)

        # Keep unified registry (FleetAgent table) in sync for live dashboards/stats
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type=agent.get('agent_type', 'lightweight'),
                hostname=agent.get('hostname'),
                name=agent.get('hostname') or agent_id,
                os_type=agent.get('os_type'),
                agent_version=agent.get('agent_version'),
                status=agent.get('status'),
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during register for {agent_id}: {sync_err}")

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'status': agent['status'],
            'message': 'Agent registered - pending approval' if agent['status'] == 'pending_approval' else 'Agent registered successfully',
            'server_time': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Agent registration failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/heartbeat', methods=['POST'])
@require_agent_api_key
def agent_heartbeat():
    """
    Agent heartbeat to indicate it's still active

    Headers:
        X-Agent-ID: <agent_id>

    Request body (optional):
    {
        "pending_results": 5,
        "last_audit": "platform/baseline/updates",
        "status": "idle",  # idle, running, error
        "resources": {
            "memory_free_mb": 4096,
            "memory_free_pct": 50,
            "load_avg": "0.5",  # Linux
            "cpu_usage_pct": 25  # Windows
        },
        "throttle_config": {
            "cpu_nice": 19,
            "io_class": "idle",
            "upload_limit": 0,
            "download_limit": 0
        }
    }
    """
    try:
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            return jsonify({'success': False, 'error': 'X-Agent-ID header required'}), 400

        agents = _load_agents()
        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]
        data = request.json or {}

        # Update agent status
        now_iso = datetime.now().isoformat()
        agent['last_seen'] = now_iso
        agent['last_heartbeat'] = now_iso
        agent['status'] = data.get('status', 'active')
        agent['pending_results'] = data.get('pending_results', 0)
        agent['last_audit'] = data.get('last_audit', agent.get('last_audit'))

        # Store resource information from agent
        if 'resources' in data:
            agent['resources'] = data['resources']

        # Store current throttle config from agent
        if 'throttle_config' in data:
            agent['current_throttle_config'] = data['throttle_config']

        _save_agent(agent)

        # Keep unified registry (FleetAgent table) heartbeat fresh
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type=agent.get('agent_type', 'lightweight'),
                hostname=agent.get('hostname'),
                name=agent.get('hostname') or agent_id,
                os_type=agent.get('os_type'),
                agent_version=agent.get('agent_version'),
                status=agent.get('status'),
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during heartbeat for {agent_id}: {sync_err}")

        # Return any pending commands for the agent
        commands = get_pending_commands(agent_id, limit=5)

        # Get server-recommended throttle settings for this agent
        recommended_throttle = get_agent_throttle_config(agent_id)

        # Include license delegation info if agent requests it
        license_info = None
        if data.get('request_license') or data.get('hardware_id'):
            # Agent is requesting license delegation
            hardware_id = data.get('hardware_id')
            hostname = agent.get('hostname', 'unknown')
            if hardware_id:
                core_license = _get_core_license_info()
                license_data = _load_agent_licenses()
                licenses = license_data.get('licenses', {})

                # Check if already allocated
                agent_slot = None
                for slot_id, slot_data in licenses.items():
                    if slot_data.get('hardware_id') == hardware_id:
                        agent_slot = int(slot_id)
                        # Update last seen
                        licenses[slot_id]['last_seen'] = datetime.now().isoformat()
                        license_data['licenses'] = licenses
                        _save_agent_licenses(license_data)
                        break

                if agent_slot:
                    license_info = {
                        'tier': core_license.get('tier', 'free'),
                        'agent_slot': agent_slot,
                        'max_agents': core_license.get('max_agents', 25),
                        'agents_used': len(licenses),
                        'expires_at': core_license.get('expires'),
                    }

        return jsonify({
            'success': True,
            'server_time': datetime.now().isoformat(),
            'commands': commands,
            'pending_command_count': len(commands),
            'throttle_config': recommended_throttle,
            'license': license_info  # Will be None if not requested
        })

    except Exception as e:
        logger.error(f"Agent heartbeat failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/core-attestation', methods=['POST'])
@require_agent_api_key
def core_attestation():
    """Issue a short-lived token proving this endpoint is the trusted core server."""
    try:
        data = request.json or {}
        nonce = data.get('nonce')
        if not nonce or not isinstance(nonce, str) or len(nonce) > 128:
            return jsonify({'success': False, 'error': 'nonce is required (max 128 chars)'}), 400

        agent_id = request.headers.get('X-Agent-ID') or data.get('agent_id')
        hostname = data.get('hostname')

        token = _issue_core_attestation_token(nonce, agent_id, hostname)
        if not token:
            return jsonify({
                'success': False,
                'error': 'Core attestation is not configured on this server'
            }), 503

        return jsonify({
            'success': True,
            'token': token,
            'server_origin': _server_origin(),
            'expires_in_seconds': CORE_ATTESTATION_TTL_SECONDS,
            'issued_at': datetime.utcnow().isoformat(),
        })

    except Exception as e:
        logger.error(f"Failed to issue core attestation token: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/update/manifest', methods=['GET'])
@require_agent_api_key
def get_update_manifest():
    """Return signed update manifest for agent self-update."""
    try:
        agent_type = request.args.get('agent_type', 'standalone').strip().lower()
        os_type = request.args.get('os_type', 'linux').strip().lower()
        current_version = request.args.get('current_version', '').strip()

        artifact = _resolve_update_artifact(agent_type, os_type)
        if not artifact:
            return jsonify({'success': False, 'error': 'No update artifact found for requested target'}), 404

        checksum = _sha256_file(artifact['file_path'])
        download_path = f"/api/agent/update/download?agent_type={artifact['agent_type']}&os_type={artifact['os_type']}"
        payload = {
            'agent_type': artifact['agent_type'],
            'os_type': artifact['os_type'],
            'version': artifact['version'],
            'filename': artifact['filename'],
            'sha256': checksum,
            'download_path': download_path,
            'server_origin': _server_origin(),
            'issued_at': datetime.utcnow().isoformat(),
        }
        signature = _issue_update_signature(payload)
        if not signature:
            return jsonify({'success': False, 'error': 'Update signing is not configured on this server'}), 503

        latest_version = artifact['version']
        update_available = True
        if current_version:
            update_available = _version_tuple(latest_version) > _version_tuple(current_version)

        return jsonify({
            'success': True,
            'agent_type': artifact['agent_type'],
            'os_type': artifact['os_type'],
            'current_version': current_version,
            'latest_version': latest_version,
            'update_available': update_available,
            'filename': artifact['filename'],
            'sha256': checksum,
            'download_url': f"{_server_origin()}{download_path}",
            'verify_url': f"{_server_origin()}/api/agent/update/verify",
            'signature': signature,
            'signature_ttl_seconds': AGENT_UPDATE_TOKEN_TTL_SECONDS,
        })
    except Exception as e:
        logger.error(f"Failed to generate update manifest: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/update/download', methods=['GET'])
@require_agent_api_key
def download_update_artifact():
    """Download agent script artifact for self-update."""
    try:
        agent_type = request.args.get('agent_type', 'standalone').strip().lower()
        os_type = request.args.get('os_type', 'linux').strip().lower()
        artifact = _resolve_update_artifact(agent_type, os_type)
        if not artifact:
            return jsonify({'success': False, 'error': 'No update artifact found for requested target'}), 404

        with open(artifact['file_path'], 'rb') as f:
            content = f.read()

        response = current_app.response_class(
            content,
            mimetype='application/octet-stream'
        )
        response.headers['Content-Disposition'] = f'attachment; filename={artifact["filename"]}'
        response.headers['X-Agent-Update-Version'] = artifact['version']
        response.headers['X-Agent-Update-Sha256'] = _sha256_file(artifact['file_path'])
        return response
    except Exception as e:
        logger.error(f"Failed to download update artifact: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/update/verify', methods=['POST'])
@require_agent_api_key
def verify_update_artifact():
    """Verify downloaded update artifact hash against signed update manifest token."""
    try:
        data = request.json or {}
        token = data.get('signature')
        file_sha256 = str(data.get('file_sha256', '')).strip().lower()
        if not token:
            return jsonify({'success': False, 'error': 'signature is required'}), 400
        if not re.match(r'^[a-f0-9]{64}$', file_sha256):
            return jsonify({'success': False, 'error': 'file_sha256 must be a valid SHA-256 hex string'}), 400

        payload, error = _verify_update_signature(token)
        if not payload:
            return jsonify({'success': False, 'error': error}), 400

        if payload.get('server_origin') != _server_origin():
            return jsonify({'success': False, 'error': 'Update signature server mismatch'}), 400

        if file_sha256 != str(payload.get('sha256', '')).lower():
            return jsonify({'success': False, 'error': 'Downloaded file hash does not match signed manifest'}), 400

        req_agent_type = str(data.get('agent_type', '')).strip().lower()
        req_os_type = str(data.get('os_type', '')).strip().lower()
        req_version = str(data.get('version', '')).strip()
        if req_agent_type and req_agent_type != str(payload.get('agent_type', '')).lower():
            return jsonify({'success': False, 'error': 'agent_type mismatch'}), 400
        if req_os_type and req_os_type != str(payload.get('os_type', '')).lower():
            return jsonify({'success': False, 'error': 'os_type mismatch'}), 400
        if req_version and req_version != str(payload.get('version', '')):
            return jsonify({'success': False, 'error': 'version mismatch'}), 400

        return jsonify({
            'success': True,
            'agent_type': payload.get('agent_type'),
            'os_type': payload.get('os_type'),
            'version': payload.get('version'),
            'filename': payload.get('filename'),
            'sha256': payload.get('sha256'),
        })
    except Exception as e:
        logger.error(f"Failed to verify update artifact: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Audit Distribution
# ============================================================================
@agent_bp.route('/api/agent/audits/<path:audit_path>', methods=['GET'])
@require_agent_api_key
def get_audit_script(audit_path):
    """
    Get an audit script for agent execution

    Path parameter:
        audit_path: e.g., platform/baseline/updates

    Query parameters:
        os_type: windows or linux (determines script extension)
    """
    try:
        os_type = request.args.get('os_type', 'linux')
        extension = '.ps1' if os_type.startswith('windows') else '.sh'

        # Secure path sanitization - prevent path traversal attacks
        # Remove directory traversal sequences and normalize
        audit_path = audit_path.replace('..', '').replace('\x00', '').strip('/')
        # Only allow alphanumeric, hyphens, underscores, and forward slashes
        if not re.match(r'^[a-zA-Z0-9/_-]+$', audit_path):
            return jsonify({
                'success': False,
                'error': 'Invalid audit path format'
            }), 400

        # Look for audit script
        if os_type.startswith('windows'):
            # Check Windows audits first
            script_path = os.path.join(AUDITS_DIR, 'windows', f"{audit_path}{extension}")
            if not os.path.exists(script_path):
                # Fallback to embedded audits in agent
                script_path = os.path.join(STANDALONE_AGENT_DIR, 'audits', f"{audit_path}{extension}")
        else:
            # Linux audits
            script_path = os.path.join(AUDITS_DIR, 'linux', f"{audit_path}{extension}")
            if not os.path.exists(script_path):
                script_path = os.path.join(AUDITS_DIR, f"{audit_path}{extension}")

        # Security: Verify the resolved path is within allowed directories
        real_path = os.path.realpath(script_path)
        allowed_dirs = [
            os.path.realpath(AUDITS_DIR),
            os.path.realpath(os.path.join(STANDALONE_AGENT_DIR, 'audits'))
        ]
        if not any(real_path.startswith(allowed) for allowed in allowed_dirs):
            logger.warning(f"Path traversal attempt blocked: {audit_path} -> {real_path}")
            return jsonify({
                'success': False,
                'error': 'Access denied: path outside allowed directories'
            }), 403

        if not os.path.exists(script_path):
            return jsonify({
                'success': False,
                'error': f'Audit not found: {audit_path}',
                'searched_path': script_path
            }), 404

        # Read script content
        with open(script_path, 'r', encoding='utf-8') as f:
            script_content = f.read()

        # Calculate checksum
        checksum = hashlib.sha256(script_content.encode()).hexdigest()

        return jsonify({
            'success': True,
            'audit': audit_path,
            'os_type': os_type,
            'script': script_content,
            'checksum': checksum,
            'version': '1.0'
        })

    except Exception as e:
        logger.error(f"Failed to serve audit script: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/audits', methods=['GET'])
@require_agent_api_key
def list_available_audits():
    """
    List all available audits for agents

    Query parameters:
        os_type: windows or linux
        category: filter by category (platform, web, data, etc.)
    """
    try:
        os_type = request.args.get('os_type', 'linux')
        category = request.args.get('category', '')

        audits = []
        extension = '.ps1' if os_type.startswith('windows') else '.sh'

        # Determine audit directory
        if os_type.startswith('windows'):
            audit_dirs = [
                os.path.join(AUDITS_DIR, 'windows'),
                os.path.join(STANDALONE_AGENT_DIR, 'audits')
            ]
        else:
            audit_dirs = [
                os.path.join(AUDITS_DIR, 'linux'),
                AUDITS_DIR
            ]

        for audit_dir in audit_dirs:
            if not os.path.exists(audit_dir):
                continue

            for root, dirs, files in os.walk(audit_dir):
                for file in files:
                    if file.endswith(extension):
                        rel_path = os.path.relpath(os.path.join(root, file), audit_dir)
                        audit_path = rel_path.replace(os.sep, '/').replace(extension, '')

                        # Filter by category if specified
                        if category and not audit_path.startswith(category):
                            continue

                        audits.append({
                            'path': audit_path,
                            'name': file.replace(extension, ''),
                            'category': audit_path.split('/')[0] if '/' in audit_path else 'uncategorized'
                        })

        # Deduplicate
        seen = set()
        unique_audits = []
        for audit in audits:
            if audit['path'] not in seen:
                seen.add(audit['path'])
                unique_audits.append(audit)

        return jsonify({
            'success': True,
            'os_type': os_type,
            'audits': unique_audits,
            'count': len(unique_audits)
        })

    except Exception as e:
        logger.error(f"Failed to list audits: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Results Upload
# ============================================================================
@agent_bp.route('/api/agent/results', methods=['POST'])
@require_agent_api_key
@conditional_limit(get_standalone_upload_limit)
def upload_results():
    """
    Upload audit results from agent

    Headers:
        X-Agent-ID: <agent_id> (optional, can be in body)

    Request body:
    {
        "hostname": "WORKSTATION-01",
        "os": "Windows 11 Pro",
        "agent_version": "1.0.0",
        "results": {
            "audit": "platform/baseline/updates",
            "timestamp": "2024-01-15T10:30:00Z",
            "duration_ms": 1234,
            "checks": [
                {"status": "PASS", "message": "Windows Update service is running"},
                {"status": "WARN", "message": "5 updates pending"}
            ],
            "summary": {
                "total": 10,
                "passed": 8,
                "failed": 1,
                "warnings": 1,
                "skipped": 0
            }
        }
    }
    """
    try:
        limits = _get_result_ingest_limits()
        max_body_bytes = limits['max_body_kb'] * 1024
        body_raw = request.get_data(cache=True, as_text=False) or b''
        if len(body_raw) > max_body_bytes:
            return jsonify({
                'success': False,
                'error': 'Request body too large',
                'limit_kb': limits['max_body_kb']
            }), 413

        disk_blocked, disk_details = _is_result_ingest_blocked_by_disk_watermark()
        if disk_blocked:
            logger.warning(f"Rejecting standalone ingest due to low disk watermark: {disk_details}")
            return jsonify({
                'success': False,
                'error': 'Insufficient storage capacity on core',
                'details': disk_details
            }), 507

        data = request.get_json(silent=True)
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request body'}), 400

        hostname = data.get('hostname')
        results = data.get('results')

        if not hostname or not results:
            return jsonify({'success': False, 'error': 'hostname and results are required'}), 400

        checks = results.get('checks', []) if isinstance(results, dict) else []
        if isinstance(checks, list) and len(checks) > limits['max_checks_per_result']:
            return jsonify({
                'success': False,
                'error': 'Too many checks in result payload',
                'limit': limits['max_checks_per_result']
            }), 400

        output = results.get('output') if isinstance(results, dict) else None
        if output is not None and len(str(output)) > limits['max_output_chars']:
            return jsonify({
                'success': False,
                'error': 'Result output is too large',
                'limit_chars': limits['max_output_chars']
            }), 400

        # Get agent ID from header or lookup by hostname
        agent_id = request.headers.get('X-Agent-ID')

        # Standalone/core-lock enforcement:
        # uploads without X-Agent-ID must include valid short-lived core attestation token.
        if REQUIRE_CORE_ATTESTATION and not agent_id:
            token = request.headers.get('X-Core-Attestation')
            token_ok, token_error = _verify_core_attestation_token(token, agent_id, hostname)
            if not token_ok:
                return jsonify({
                    'success': False,
                    'error': 'Core attestation required',
                    'details': token_error,
                }), 403

        if not agent_id:
            agents = _load_agents()
            for agent in agents.values():
                if agent.get('hostname') == hostname:
                    agent_id = agent['agent_id']
                    break

        # Store results
        _ensure_dirs()

        # Sanitize hostname for safe directory creation
        safe_hostname = re.sub(r'[^a-zA-Z0-9._-]', '_', hostname)[:100]
        if not safe_hostname:
            return jsonify({'success': False, 'error': 'Invalid hostname'}), 400

        # Create hostname directory
        host_dir = os.path.join(AGENT_RESULTS_DIR, safe_hostname)
        os.makedirs(host_dir, exist_ok=True)

        # Generate result filename - sanitize audit name
        audit_name = results.get('audit', 'unknown')
        safe_audit_name = re.sub(r'[^a-zA-Z0-9._/-]', '_', audit_name).replace('/', '_')[:100]
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        result_file = os.path.join(host_dir, f"{safe_audit_name}_{timestamp}.json")

        # Add metadata
        result_data = {
            'agent_id': agent_id,
            'hostname': hostname,
            'os': data.get('os', 'Unknown'),
            'agent_version': data.get('agent_version', 'Unknown'),
            'received_at': datetime.now().isoformat(),
            'results': results
        }

        # Apply encryption if enabled (Phase 2 - unified across all agents)
        if _ENCRYPTION_AVAILABLE:
            try:
                result_encryptor = ResultEncryption()
                should_encrypt = result_encryptor.should_encrypt_result()

                if should_encrypt:
                    encrypted_wrapper = result_encryptor.encrypt(result_data, agent_id)
                    if encrypted_wrapper:
                        result_data = encrypted_wrapper
                        logger.info(f"Standalone agent result encrypted for {agent_id}")
                    else:
                        logger.warning(f"Failed to encrypt standalone agent result for {agent_id}, storing unencrypted")
            except Exception as e:
                logger.error(f"Encryption error for standalone agent {agent_id}: {e}")
                # Continue without encryption if error occurs

        with open(result_file, 'w') as f:
            json.dump(result_data, f, indent=2, default=str)

        max_files = _get_max_standalone_result_files_per_host()
        pruned = _prune_host_result_files(host_dir, max_files)
        if pruned > 0:
            logger.info(
                f"Pruned {pruned} standalone result files for host {safe_hostname} "
                f"(max_files={max_files})"
            )

        logger.info(f"Received results from {hostname}: {results.get('audit', 'unknown')}")

        # Update agent last_seen
        if agent_id:
            agents = _load_agents()
            if agent_id in agents:
                agents[agent_id]['last_seen'] = datetime.now().isoformat()
                agents[agent_id]['last_audit'] = results.get('audit')
                _save_agent(agents[agent_id])

        return jsonify({
            'success': True,
            'message': 'Results uploaded successfully',
            'result_id': os.path.basename(result_file).replace('.json', '')
        })

    except Exception as e:
        logger.error(f"Failed to upload results: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent Management (Admin)
# ============================================================================
@agent_bp.route('/api/agent/list', methods=['GET'])
@require_auth_and_permission('manage_agents')
def list_agents():
    """
    List all registered agents

    Query parameters:
        status: active, inactive, all (default: all)
        os_type: windows-server, windows-desktop, linux (optional)
    """
    try:
        status_filter = request.args.get('status', 'all')
        os_type_filter = request.args.get('os_type', '')

        agents = _load_agents()
        result = []

        for agent in agents.values():
            # Filter by status
            if status_filter != 'all':
                last_seen = datetime.fromisoformat(agent.get('last_seen', '2000-01-01'))
                is_active = (datetime.now() - last_seen).total_seconds() < 3600  # 1 hour

                if status_filter == 'active' and not is_active:
                    continue
                if status_filter == 'inactive' and is_active:
                    continue

            # Filter by OS type
            if os_type_filter and agent.get('os_type') != os_type_filter:
                continue

            # Calculate online status
            last_seen = datetime.fromisoformat(agent.get('last_seen', '2000-01-01'))
            online = (datetime.now() - last_seen).total_seconds() < 300  # 5 minutes

            result.append({
                'agent_id': agent['agent_id'],
                'hostname': agent['hostname'],
                'os_name': agent.get('os_name', 'Unknown'),
                'os_type': agent.get('os_type', 'unknown'),
                'agent_version': agent.get('agent_version', 'Unknown'),
                'status': 'online' if online else 'offline',
                'last_seen': agent.get('last_seen'),
                'registered_at': agent.get('registered_at'),
                'detected_software': agent.get('detected_software', [])
            })

        return jsonify({
            'success': True,
            'agents': result,
            'count': len(result)
        })

    except Exception as e:
        logger.error(f"Failed to list agents: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>', methods=['GET'])
@require_api_key
def get_agent(agent_id):
    """Get detailed information about a specific agent"""
    try:
        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]

        # Get results count
        host_dir = os.path.join(AGENT_RESULTS_DIR, agent['hostname'].replace('/', '_').replace('\\', '_'))
        results_count = 0
        if os.path.exists(host_dir):
            results_count = len([f for f in os.listdir(host_dir) if f.endswith('.json')])

        return jsonify({
            'success': True,
            'agent': agent,
            'results_count': results_count
        })

    except Exception as e:
        logger.error(f"Failed to get agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>', methods=['DELETE'])
@require_api_key
@require_auth_and_permission('manage_agents')
def delete_agent(agent_id):
    """Delete/unregister an agent"""
    try:
        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]
        hostname = agent['hostname']

        # Delete agent file
        agent_file = os.path.join(AGENTS_DIR, f"{agent_id}.json")
        if os.path.exists(agent_file):
            os.remove(agent_file)

        # Remove from cache
        del _agents_cache[agent_id]

        logger.info(f"Agent deleted: {hostname} ({agent_id})")

        return jsonify({
            'success': True,
            'message': f'Agent {hostname} deleted successfully'
        })

    except Exception as e:
        logger.error(f"Failed to delete agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/approve', methods=['POST'])
@require_api_key
@require_auth_and_permission('manage_agents')
def approve_agent(agent_id):
    """
    Approve a pending agent registration

    Request body (optional):
    {
        "reason": "Approved by admin"
    }
    """
    try:
        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]
        hostname = agent['hostname']

        if agent.get('status') != 'pending_approval':
            return jsonify({
                'success': False,
                'error': f"Agent is not pending approval (current status: {agent.get('status')})"
            }), 400

        data = request.json or {}
        reason = data.get('reason', 'Manually approved by administrator')

        agent['status'] = 'active'
        agent['approved_at'] = datetime.now().isoformat()
        agent['approved_reason'] = reason
        agent['approved_by'] = getattr(g, 'user_id', 'api_key')

        _save_agent(agent)

        logger.info(f"Agent approved: {hostname} ({agent_id}) - {reason}")

        return jsonify({
            'success': True,
            'message': f'Agent {hostname} has been approved',
            'agent_id': agent_id,
            'status': 'active'
        })

    except Exception as e:
        logger.error(f"Failed to approve agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/reject', methods=['POST'])
@require_api_key
@require_auth_and_permission('manage_agents')
def reject_agent(agent_id):
    """
    Reject a pending agent registration

    Request body (optional):
    {
        "reason": "Unknown device"
    }
    """
    try:
        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]
        hostname = agent['hostname']

        data = request.json or {}
        reason = data.get('reason', 'Rejected by administrator')

        agent['status'] = 'rejected'
        agent['rejected_at'] = datetime.now().isoformat()
        agent['rejected_reason'] = reason
        agent['rejected_by'] = getattr(g, 'user_id', 'api_key')

        _save_agent(agent)

        logger.info(f"Agent rejected: {hostname} ({agent_id}) - {reason}")

        return jsonify({
            'success': True,
            'message': f'Agent {hostname} has been rejected',
            'agent_id': agent_id,
            'status': 'rejected'
        })

    except Exception as e:
        logger.error(f"Failed to reject agent: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/pending', methods=['GET'])
@require_api_key
def list_pending_agents():
    """List all agents pending approval"""
    try:
        agents = _load_agents()

        pending = [
            {
                'agent_id': agent['agent_id'],
                'hostname': agent['hostname'],
                'os_name': agent.get('os_name', 'Unknown'),
                'os_type': agent.get('os_type', 'unknown'),
                'registered_at': agent.get('registered_at'),
                'architecture': agent.get('architecture')
            }
            for agent in agents.values()
            if agent.get('status') == 'pending_approval'
        ]

        return jsonify({
            'success': True,
            'pending_count': len(pending),
            'agents': pending
        })

    except Exception as e:
        logger.error(f"Failed to list pending agents: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/rotate-key', methods=['POST'])
@require_auth_and_permission('admin')
def rotate_agent_key(agent_id):
    """Rotate the API key for a specific agent

    This generates a new API key for the agent. The old key remains valid
    for a grace period (configured in security settings) to prevent breaking
    scheduled scans during transition.
    """
    try:
        from web.security_settings import get_security_setting

        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({
                'success': False,
                'error': 'Agent not found'
            }), 404

        agent = agents[agent_id]
        hostname = agent.get('hostname', 'Unknown')

        # Check agent is active
        if agent.get('status') != 'active':
            return jsonify({
                'success': False,
                'error': f"Cannot rotate key for non-active agent (status: {agent.get('status')})"
            }), 400

        # Get grace period from settings (default 24 hours)
        grace_period_hours = get_security_setting('agent_api_key_grace_period_hours', 24)

        # Generate new API key
        import secrets
        new_api_key = secrets.token_urlsafe(32)
        old_api_key = agent.get('api_key')

        # Store rotation history
        if 'key_rotations' not in agent:
            agent['key_rotations'] = []

        rotation_time = datetime.now()
        grace_expiry = rotation_time + timedelta(hours=grace_period_hours)

        agent['key_rotations'].append({
            'rotated_at': rotation_time.isoformat(),
            'rotated_by': getattr(g, 'user_id', 'api_key'),
            'previous_key_created': agent.get('api_key_created_at'),
            'previous_key_hash': _hash_api_key(old_api_key) if old_api_key else None,
            'grace_period_expires': grace_expiry.isoformat()
        })

        # Store old key in grace period list (for validation during transition)
        if 'grace_period_keys' not in agent:
            agent['grace_period_keys'] = []

        if old_api_key:
            agent['grace_period_keys'].append({
                'key_hash': _hash_api_key(old_api_key),
                'expires_at': grace_expiry.isoformat(),
                'rotated_at': rotation_time.isoformat()
            })

        # Clean up expired grace period keys
        now = datetime.now()
        agent['grace_period_keys'] = [
            k for k in agent['grace_period_keys']
            if datetime.fromisoformat(k['expires_at'].replace('Z', '+00:00').replace('+00:00', '')) > now
        ]

        # Update agent with new key
        agent['api_key'] = new_api_key
        agent['api_key_created_at'] = rotation_time.isoformat()
        agent['api_key_rotation_count'] = len(agent['key_rotations'])

        # Mark that there's a pending key update for the agent
        agent['pending_key_rotation'] = {
            'new_key': new_api_key,
            'queued_at': rotation_time.isoformat(),
            'grace_period_expires': grace_expiry.isoformat(),
            'notified': False
        }

        _save_agent(agent)

        # Queue a command to notify the agent about key rotation
        try:
            queue_command_for_agent(
                agent_id=agent_id,
                command_type='key_rotation',
                command_data={
                    'action': 'rotate_api_key',
                    'grace_period_expires': grace_expiry.isoformat(),
                    'fetch_url': f'/api/agent/{agent_id}/fetch-new-key'
                },
                requested_by=getattr(g, 'user_id', 'api_key'),
                priority=1,  # High priority
                expires_hours=grace_period_hours  # Expire with grace period
            )
            logger.info(f"Queued key rotation command for agent {agent_id}")
        except Exception as cmd_err:
            logger.warning(f"Could not queue key rotation command: {cmd_err}")

        logger.info(f"API key rotated for agent: {hostname} ({agent_id}) - grace period: {grace_period_hours}h")

        return jsonify({
            'success': True,
            'message': f'API key rotated for agent {hostname}',
            'agent_id': agent_id,
            'new_api_key': new_api_key,
            'rotation_count': agent['api_key_rotation_count'],
            'grace_period_hours': grace_period_hours,
            'grace_period_expires': grace_expiry.isoformat(),
            'note': f'Update the agent configuration with this new API key. The old key remains valid for {grace_period_hours} hours to prevent disruption to scheduled scans.',
            'agent_notification': 'Agent will be notified via command queue during next heartbeat'
        })

    except Exception as e:
        logger.error(f"Failed to rotate API key for agent {agent_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/fetch-new-key', methods=['POST'])
@require_agent_api_key
def fetch_new_key(agent_id):
    """
    Allow agent to fetch its new API key during grace period

    This endpoint is called by agents after receiving a key_rotation command.
    The agent authenticates with its OLD key (still valid during grace period)
    and receives the new key.

    Headers:
        X-API-Key: Old API key (must be in grace period)
        X-Agent-ID: Agent ID

    Returns:
        new_api_key: The new API key to use
        updated_at: When the key was rotated
    """
    try:
        # Verify the requesting agent matches the target
        requesting_agent_id = request.headers.get('X-Agent-ID')
        if requesting_agent_id != agent_id:
            return jsonify({
                'success': False,
                'error': 'Agent ID mismatch'
            }), 403

        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({
                'success': False,
                'error': 'Agent not found'
            }), 404

        agent = agents[agent_id]

        # Check if there's a pending key rotation
        pending = agent.get('pending_key_rotation')
        if not pending:
            return jsonify({
                'success': False,
                'error': 'No pending key rotation for this agent'
            }), 404

        # Verify grace period hasn't expired
        grace_expiry = pending.get('grace_period_expires', '')
        if grace_expiry:
            try:
                expiry_dt = datetime.fromisoformat(grace_expiry.replace('Z', '').replace('+00:00', ''))
                if datetime.now() > expiry_dt:
                    return jsonify({
                        'success': False,
                        'error': 'Grace period has expired. Contact administrator for new key.'
                    }), 410  # Gone
            except ValueError:
                pass

        # Return the new key
        new_key = pending.get('new_key') or agent.get('api_key')

        # Mark as notified
        agent['pending_key_rotation']['notified'] = True
        agent['pending_key_rotation']['fetched_at'] = datetime.now().isoformat()
        _save_agent(agent)

        logger.info(f"Agent {agent_id} fetched new API key")

        return jsonify({
            'success': True,
            'new_api_key': new_key,
            'updated_at': agent.get('api_key_created_at'),
            'message': 'Update your configuration with this new key. Old key will expire at grace period end.',
            'grace_period_expires': grace_expiry
        })

    except Exception as e:
        logger.error(f"Failed to fetch new key for agent {agent_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/confirm-key-update', methods=['POST'])
@require_agent_api_key
def confirm_key_update(agent_id):
    """
    Agent confirms successful key update

    Called by agent after it has saved the new key and verified it works.
    This allows the server to clean up grace period data.
    """
    try:
        requesting_agent_id = request.headers.get('X-Agent-ID')
        if requesting_agent_id != agent_id:
            return jsonify({
                'success': False,
                'error': 'Agent ID mismatch'
            }), 403

        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({
                'success': False,
                'error': 'Agent not found'
            }), 404

        agent = agents[agent_id]

        # Clear pending rotation and old grace period keys
        if 'pending_key_rotation' in agent:
            del agent['pending_key_rotation']

        # Keep only very recent grace period keys (for edge cases)
        now = datetime.now()
        if 'grace_period_keys' in agent:
            agent['grace_period_keys'] = [
                k for k in agent['grace_period_keys']
                if datetime.fromisoformat(k['expires_at'].replace('Z', '').replace('+00:00', '')) > now
            ]

        agent['key_update_confirmed_at'] = now.isoformat()
        _save_agent(agent)

        logger.info(f"Agent {agent_id} confirmed key update")

        return jsonify({
            'success': True,
            'message': 'Key update confirmed. Old keys have been invalidated.'
        })

    except Exception as e:
        logger.error(f"Failed to confirm key update for agent {agent_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/keys/expiring', methods=['GET'])
@require_auth_and_permission('admin')
def list_expiring_keys():
    """List agents with API keys approaching rotation deadline

    Returns agents whose keys are older than the configured rotation period.
    """
    try:
        from web.security_settings import get_security_setting

        rotation_days = get_security_setting('agent_api_key_rotation_days') or 90
        agents = _load_agents()

        now = datetime.now()
        expiring = []

        for agent_id, agent in agents.items():
            if agent.get('status') != 'active':
                continue

            key_created = agent.get('api_key_created_at')
            if not key_created:
                # No creation date - consider it expired
                expiring.append({
                    'agent_id': agent_id,
                    'hostname': agent.get('hostname', 'Unknown'),
                    'key_age_days': None,
                    'expires_in_days': 0,
                    'status': 'unknown_age'
                })
                continue

            try:
                created_date = datetime.fromisoformat(key_created.replace('Z', '+00:00'))
                if created_date.tzinfo:
                    created_date = created_date.replace(tzinfo=None)
                key_age = (now - created_date).days
                expires_in = rotation_days - key_age

                if expires_in <= 14:  # Within 2 weeks of expiration
                    expiring.append({
                        'agent_id': agent_id,
                        'hostname': agent.get('hostname', 'Unknown'),
                        'key_age_days': key_age,
                        'expires_in_days': max(0, expires_in),
                        'status': 'expired' if expires_in <= 0 else 'expiring_soon'
                    })
            except (ValueError, TypeError) as parse_err:
                logger.warning(f"Could not parse key date for agent {agent_id}: {parse_err}")
                expiring.append({
                    'agent_id': agent_id,
                    'hostname': agent.get('hostname', 'Unknown'),
                    'key_age_days': None,
                    'expires_in_days': 0,
                    'status': 'parse_error'
                })

        return jsonify({
            'success': True,
            'rotation_policy_days': rotation_days,
            'expiring_count': len(expiring),
            'agents': sorted(expiring, key=lambda x: x.get('expires_in_days') or 0)
        })

    except Exception as e:
        logger.error(f"Failed to list expiring keys: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/<agent_id>/results', methods=['GET'])
@require_api_key
def get_agent_results(agent_id):
    """Get audit results from a specific agent"""
    try:
        agents = _load_agents()

        if agent_id not in agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = agents[agent_id]
        hostname = agent['hostname']

        # Get results
        host_dir = os.path.join(AGENT_RESULTS_DIR, hostname.replace('/', '_').replace('\\', '_'))
        results = []

        if os.path.exists(host_dir):
            for filename in sorted(os.listdir(host_dir), reverse=True)[:50]:  # Last 50
                if filename.endswith('.json'):
                    try:
                        with open(os.path.join(host_dir, filename), 'r') as f:
                            data = json.load(f)
                            results.append({
                                'id': filename.replace('.json', ''),
                                'audit': data.get('results', {}).get('audit', 'unknown'),
                                'received_at': data.get('received_at'),
                                'summary': data.get('results', {}).get('summary', {})
                            })
                    except Exception as e:
                        logger.warning(f"Failed to read result file {filename}: {e}")

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'hostname': hostname,
            'results': results,
            'count': len(results)
        })

    except Exception as e:
        logger.error(f"Failed to get agent results: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent Discovery Integration
# ============================================================================
AGENT_DISCOVERY_DIR = os.path.join(ROOT_DIR, 'data', 'agent_discovery')


def _ensure_discovery_dir():
    """Ensure discovery directory exists"""
    os.makedirs(AGENT_DISCOVERY_DIR, exist_ok=True)


@agent_bp.route('/api/agent/discovery', methods=['POST'])
@require_agent_api_key
@conditional_limit("50 per hour")
def upload_discovery():
    """
    Upload discovery data from agent

    Agents use this to report:
    - System information (OS, hostname, architecture)
    - Installed software/packages
    - Running services
    - Network configuration
    - Security status
    - Neighboring/discovered hosts

    Headers:
        X-Agent-ID: <agent_id> (optional, can be in body)
        X-API-Key: <api_key>

    Request body:
    {
        "hostname": "WORKSTATION-01",
        "os_type": "windows-desktop",
        "os_name": "Windows 11 Pro",
        "os_version": "10.0.22631",
        "architecture": "x64",
        "domain": "CORP.LOCAL",
        "ip_addresses": ["192.168.1.50", "fe80::1"],
        "mac_addresses": ["AA:BB:CC:DD:EE:FF"],
        "system_info": {
            "cpu": "Intel Core i7-12700",
            "memory_gb": 32,
            "disk_total_gb": 500,
            "disk_free_gb": 250
        },
        "packages": [
            {"name": "Microsoft Office", "version": "16.0.17328", "publisher": "Microsoft"},
            {"name": "Chrome", "version": "121.0.6167.160", "publisher": "Google"}
        ],
        "services": [
            {"name": "Windows Defender", "status": "running", "startup": "automatic"},
            {"name": "Windows Update", "status": "running", "startup": "automatic"}
        ],
        "security": {
            "firewall_enabled": true,
            "antivirus_enabled": true,
            "antivirus_name": "Windows Defender",
            "disk_encrypted": true,
            "secure_boot": true,
            "tpm_version": "2.0"
        },
        "discovered_hosts": [
            {"ip": "192.168.1.1", "hostname": "gateway", "type": "router"},
            {"ip": "192.168.1.10", "hostname": "fileserver", "type": "server", "ports": [22, 445]}
        ],
        "network_info": {
            "default_gateway": "192.168.1.1",
            "dns_servers": ["192.168.1.1", "8.8.8.8"],
            "domain_joined": true,
            "domain_controller": "dc01.corp.local"
        }
    }
    """
    try:
        data = request.json
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request body'}), 400

        hostname = data.get('hostname')
        if not hostname:
            return jsonify({'success': False, 'error': 'hostname is required'}), 400

        # Get agent ID from header or lookup
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            agents = _load_agents()
            for agent in agents.values():
                if agent.get('hostname') == hostname:
                    agent_id = agent['agent_id']
                    break

        # Store discovery data
        _ensure_discovery_dir()

        # Create discovery record
        discovery_data = {
            'agent_id': agent_id,
            'hostname': hostname,
            'received_at': datetime.now().isoformat(),
            'source': 'agent',
            **data
        }

        # Save to file
        safe_hostname = hostname.replace('/', '_').replace('\\', '_').replace(':', '_')
        discovery_file = os.path.join(AGENT_DISCOVERY_DIR, f"{safe_hostname}.json")

        with open(discovery_file, 'w') as f:
            json.dump(discovery_data, f, indent=2, default=str)

        logger.info(f"Discovery data received from agent: {hostname}")

        # Process discovered hosts - add them to pending servers
        discovered_hosts = data.get('discovered_hosts', [])
        new_hosts_count = 0
        if discovered_hosts:
            new_hosts_count = _process_discovered_hosts(discovered_hosts, hostname)

        # Update agent record with discovery timestamp
        if agent_id:
            agents = _load_agents()
            if agent_id in agents:
                agents[agent_id]['last_discovery'] = datetime.now().isoformat()
                agents[agent_id]['discovery_data'] = {
                    'packages_count': len(data.get('packages', [])),
                    'services_count': len(data.get('services', [])),
                    'discovered_hosts_count': len(discovered_hosts)
                }
                _save_agent(agents[agent_id])

        return jsonify({
            'success': True,
            'message': 'Discovery data uploaded successfully',
            'hostname': hostname,
            'new_hosts_discovered': new_hosts_count
        })

    except Exception as e:
        logger.error(f"Failed to upload discovery: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _process_discovered_hosts(discovered_hosts, reporting_agent):
    """
    Process hosts discovered by an agent

    Adds new hosts to pending server list for review.
    """
    PENDING_HOSTS_FILE = os.path.join(AGENT_DISCOVERY_DIR, '_pending_hosts.json')

    try:
        # Load existing pending hosts
        pending_hosts = {}
        if os.path.exists(PENDING_HOSTS_FILE):
            with open(PENDING_HOSTS_FILE, 'r') as f:
                pending_hosts = json.load(f)

        new_count = 0
        for host in discovered_hosts:
            ip = host.get('ip')
            if not ip:
                continue

            # Skip if already known
            if ip in pending_hosts:
                # Update last seen
                pending_hosts[ip]['last_seen'] = datetime.now().isoformat()
                pending_hosts[ip]['seen_count'] = pending_hosts[ip].get('seen_count', 0) + 1
                continue

            # Add new pending host
            pending_hosts[ip] = {
                'ip': ip,
                'hostname': host.get('hostname', ''),
                'type': host.get('type', 'unknown'),
                'ports': host.get('ports', []),
                'discovered_by': reporting_agent,
                'discovered_at': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat(),
                'seen_count': 1,
                'status': 'pending'  # pending, approved, ignored
            }
            new_count += 1

        # Save pending hosts
        with open(PENDING_HOSTS_FILE, 'w') as f:
            json.dump(pending_hosts, f, indent=2, default=str)

        return new_count

    except Exception as e:
        logger.error(f"Failed to process discovered hosts: {e}")
        return 0


@agent_bp.route('/api/agent/discovery/pending', methods=['GET'])
@require_api_key
def get_pending_hosts():
    """
    Get list of hosts discovered by agents pending approval

    Returns hosts that agents have discovered on the network
    which have not yet been added as managed servers.
    """
    try:
        PENDING_HOSTS_FILE = os.path.join(AGENT_DISCOVERY_DIR, '_pending_hosts.json')

        pending_hosts = {}
        if os.path.exists(PENDING_HOSTS_FILE):
            with open(PENDING_HOSTS_FILE, 'r') as f:
                pending_hosts = json.load(f)

        # Filter by status
        status_filter = request.args.get('status', 'pending')

        result = []
        for ip, host in pending_hosts.items():
            if status_filter != 'all' and host.get('status') != status_filter:
                continue
            result.append(host)

        # Sort by discovered_at descending
        result.sort(key=lambda x: x.get('discovered_at', ''), reverse=True)

        return jsonify({
            'success': True,
            'hosts': result,
            'count': len(result)
        })

    except Exception as e:
        logger.error(f"Failed to get pending hosts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/discovery/pending/<ip>', methods=['POST'])
@require_api_key
@require_auth_and_permission('manage_servers')
def update_pending_host(ip):
    """
    Update status of a pending discovered host

    Request body:
    {
        "status": "approved" | "ignored",
        "add_as_server": true,  // if approved, add to servers list
        "server_config": {      // optional server configuration
            "name": "FileServer",
            "os_type": "linux",
            "username": "admin"
        }
    }
    """
    try:
        PENDING_HOSTS_FILE = os.path.join(AGENT_DISCOVERY_DIR, '_pending_hosts.json')

        if not os.path.exists(PENDING_HOSTS_FILE):
            return jsonify({'success': False, 'error': 'No pending hosts found'}), 404

        with open(PENDING_HOSTS_FILE, 'r') as f:
            pending_hosts = json.load(f)

        if ip not in pending_hosts:
            return jsonify({'success': False, 'error': f'Host {ip} not found'}), 404

        data = request.json or {}
        new_status = data.get('status', 'approved')

        pending_hosts[ip]['status'] = new_status
        pending_hosts[ip]['updated_at'] = datetime.now().isoformat()

        # If approved and add_as_server, add to servers list
        if new_status == 'approved' and data.get('add_as_server'):
            server_config = data.get('server_config', {})
            # Import server manager here to avoid circular imports
            from models.server import ServerManager
            server_manager = ServerManager()

            new_server = {
                'name': server_config.get('name', pending_hosts[ip].get('hostname', ip)),
                'hostname': pending_hosts[ip].get('hostname', ip),
                'host': ip,
                'os_type': server_config.get('os_type', _guess_os_type(pending_hosts[ip])),
                'username': server_config.get('username', ''),
                'port': server_config.get('port', 22),
                'discovered_by_agent': True,
                'discovered_at': pending_hosts[ip].get('discovered_at')
            }

            # Add server
            servers = server_manager.load_servers()
            new_server['id'] = max([s.get('id', 0) for s in servers] + [0]) + 1
            servers.append(new_server)
            server_manager.save_servers(servers)

            logger.info(f"Added discovered host as server: {ip}")

        # Save updated pending hosts
        with open(PENDING_HOSTS_FILE, 'w') as f:
            json.dump(pending_hosts, f, indent=2, default=str)

        return jsonify({
            'success': True,
            'message': f'Host {ip} status updated to {new_status}'
        })

    except Exception as e:
        logger.error(f"Failed to update pending host: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _guess_os_type(host_data):
    """Guess OS type based on discovered host data"""
    hostname = (host_data.get('hostname') or '').lower()
    ports = host_data.get('ports', [])
    host_type = (host_data.get('type') or '').lower()

    # Check ports for hints
    if 3389 in ports or 5985 in ports or 5986 in ports:
        return 'windows'
    if 22 in ports:
        return 'linux'

    # Check hostname patterns
    if any(x in hostname for x in ['win', 'windows', 'dc', 'ad', 'exchange']):
        return 'windows'
    if any(x in hostname for x in ['linux', 'ubuntu', 'centos', 'rhel', 'debian']):
        return 'linux'

    # Check type
    if host_type in ['router', 'switch', 'firewall', 'appliance']:
        return 'network'

    return 'linux'  # Default to linux


@agent_bp.route('/api/agent/discovery/<hostname>', methods=['GET'])
@require_api_key
def get_agent_discovery(hostname):
    """
    Get discovery data for a specific agent/host

    Returns the most recent discovery data submitted by the agent.
    """
    try:
        _ensure_discovery_dir()

        safe_hostname = hostname.replace('/', '_').replace('\\', '_').replace(':', '_')
        discovery_file = os.path.join(AGENT_DISCOVERY_DIR, f"{safe_hostname}.json")

        if not os.path.exists(discovery_file):
            return jsonify({
                'success': False,
                'error': f'No discovery data for {hostname}'
            }), 404

        with open(discovery_file, 'r') as f:
            data = json.load(f)

        return jsonify({
            'success': True,
            'discovery': data
        })

    except Exception as e:
        logger.error(f"Failed to get discovery data: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/discovery/all', methods=['GET'])
@require_api_key
def get_all_agent_discoveries():
    """
    Get discovery data from all agents

    Query params:
        limit: Max number of results (default 100)
        os_type: Filter by OS type
    """
    try:
        _ensure_discovery_dir()

        limit = int(request.args.get('limit', 100))
        os_type_filter = request.args.get('os_type', '')

        discoveries = []

        for filename in os.listdir(AGENT_DISCOVERY_DIR):
            if not filename.endswith('.json') or filename.startswith('_'):
                continue

            try:
                with open(os.path.join(AGENT_DISCOVERY_DIR, filename), 'r') as f:
                    data = json.load(f)

                # Apply filter
                if os_type_filter and data.get('os_type') != os_type_filter:
                    continue

                discoveries.append({
                    'hostname': data.get('hostname'),
                    'os_type': data.get('os_type'),
                    'os_name': data.get('os_name'),
                    'ip_addresses': data.get('ip_addresses', []),
                    'packages_count': len(data.get('packages', [])),
                    'services_count': len(data.get('services', [])),
                    'discovered_hosts_count': len(data.get('discovered_hosts', [])),
                    'received_at': data.get('received_at')
                })

            except Exception as e:
                logger.warning(f"Failed to read discovery file {filename}: {e}")

        # Sort by received_at descending
        discoveries.sort(key=lambda x: x.get('received_at', ''), reverse=True)

        return jsonify({
            'success': True,
            'discoveries': discoveries[:limit],
            'count': len(discoveries)
        })

    except Exception as e:
        logger.error(f"Failed to get discoveries: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent Command Queue
# ============================================================================
COMMANDS_DIR = os.path.join(ROOT_DIR, 'data', 'agent_commands')


def _ensure_commands_dir():
    """Ensure commands directory exists"""
    os.makedirs(COMMANDS_DIR, exist_ok=True)


def _get_agent_commands_file(agent_id):
    """Get path to agent's command queue file"""
    return os.path.join(COMMANDS_DIR, f"{agent_id}_commands.json")


def _load_agent_commands(agent_id):
    """Load pending commands for an agent"""
    _ensure_commands_dir()
    filepath = _get_agent_commands_file(agent_id)

    if not os.path.exists(filepath):
        return []

    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load commands for agent {agent_id}: {e}")
        return []


def _save_agent_commands(agent_id, commands):
    """Save commands to agent's queue file"""
    _ensure_commands_dir()
    filepath = _get_agent_commands_file(agent_id)

    with open(filepath, 'w') as f:
        json.dump(commands, f, indent=2, default=str)


def _generate_command_id():
    """Generate unique command ID"""
    return hashlib.sha256(f"{datetime.now().isoformat()}-{os.urandom(8).hex()}".encode()).hexdigest()[:16]


def queue_command_for_agent(agent_id, command_type, command_data, requested_by=None, priority=5, expires_hours=24):
    """
    Queue a command for an agent to execute

    Args:
        agent_id: Target agent ID
        command_type: run_audit, run_plan, run_discovery, update_config
        command_data: Dict with command details
        requested_by: Username who requested the command
        priority: 1-10 (1=highest)
        expires_hours: Hours until command expires

    Returns:
        dict: Command object with ID
    """
    from datetime import timedelta

    command = {
        'id': _generate_command_id(),
        'agent_id': agent_id,
        'command_type': command_type,
        'command_data': command_data,
        'priority': priority,
        'status': 'pending',
        'requested_by': requested_by,
        'created_at': datetime.now().isoformat(),
        'expires_at': (datetime.now() + timedelta(hours=expires_hours)).isoformat(),
        'acknowledged_at': None,
        'started_at': None,
        'completed_at': None,
        'result_data': None,
        'error_message': None
    }

    # Add to queue
    commands = _load_agent_commands(agent_id)
    commands.append(command)
    _save_agent_commands(agent_id, commands)

    logger.info(f"Queued command {command['id']} ({command_type}) for agent {agent_id}")
    return command


def get_pending_commands(agent_id, limit=10):
    """
    Get pending commands for an agent (filtered and sorted by priority)

    Args:
        agent_id: Agent ID
        limit: Max commands to return

    Returns:
        list: List of pending command objects
    """
    commands = _load_agent_commands(agent_id)
    now = datetime.now()

    # Filter for pending, non-expired commands
    pending = []
    updated = False

    for cmd in commands:
        # Check expiration
        expires_at = cmd.get('expires_at')
        if expires_at:
            try:
                exp_time = datetime.fromisoformat(expires_at)
                if exp_time < now:
                    cmd['status'] = 'expired'
                    updated = True
                    continue
            except ValueError:
                pass

        if cmd.get('status') == 'pending':
            pending.append(cmd)

    # Save if any commands were expired
    if updated:
        _save_agent_commands(agent_id, commands)

    # Sort by priority (low number = high priority)
    pending.sort(key=lambda x: (x.get('priority', 5), x.get('created_at', '')))

    return pending[:limit]


# ============================================================================
# Agent Throttle Configuration
# ============================================================================
THROTTLE_CONFIG_FILE = os.path.join(ROOT_DIR, 'data', 'agent_throttle_config.json')

# Default throttle settings (minimal impact on target systems)
# These can be overridden via Admin Settings → Agent Throttle Settings
DEFAULT_THROTTLE_CONFIG = {
    # CPU throttling (Linux nice level / Windows priority)
    'cpu_nice_level': 19,  # Linux: -20 to 19 (19 = lowest priority)
    'process_priority': 'Idle',  # Windows: Idle, BelowNormal, Normal, AboveNormal, High
    'io_class': 'idle',  # Linux ionice: realtime, best-effort, idle

    # Memory thresholds (percentage)
    'min_free_memory_pct': 10,  # Don't run audits if below this
    'pause_memory_pct': 5,  # Pause execution if memory drops below this

    # Network throttling (bytes per second, 0 = unlimited)
    'upload_rate_limit': 0,
    'download_rate_limit': 0,

    # Execution limits
    'max_concurrent_audits': 1,
    'audit_timeout': 3600,  # Max seconds per audit
    'command_batch_size': 5,  # Max commands per poll
    'batch_delay': 5,  # Seconds between commands

    # Load thresholds
    'max_load_average': 0,  # 0 = disabled, else max load to start audits
    'max_cpu_pct': 0,  # 0 = disabled (Windows)

    # Heartbeat
    'heartbeat_min_interval': 30,  # Min seconds between heartbeats
    'poll_interval': 60  # Seconds between command polls
}


def _get_throttle_defaults_from_settings():
    """
    Get throttle defaults from security settings (Admin panel).
    Falls back to DEFAULT_THROTTLE_CONFIG if settings not available.
    """
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings()

        return {
            'cpu_nice_level': settings.get('agent_cpu_nice_level', DEFAULT_THROTTLE_CONFIG['cpu_nice_level']),
            'process_priority': settings.get('agent_process_priority', DEFAULT_THROTTLE_CONFIG['process_priority']),
            'io_class': settings.get('agent_io_class', DEFAULT_THROTTLE_CONFIG['io_class']),
            'min_free_memory_pct': settings.get('agent_min_free_memory_pct', DEFAULT_THROTTLE_CONFIG['min_free_memory_pct']),
            'pause_memory_pct': DEFAULT_THROTTLE_CONFIG['pause_memory_pct'],  # Not in admin UI, use default
            'upload_rate_limit': settings.get('agent_upload_rate_limit', DEFAULT_THROTTLE_CONFIG['upload_rate_limit']),
            'download_rate_limit': settings.get('agent_download_rate_limit', DEFAULT_THROTTLE_CONFIG['download_rate_limit']),
            'max_concurrent_audits': settings.get('agent_max_concurrent_audits', DEFAULT_THROTTLE_CONFIG['max_concurrent_audits']),
            'audit_timeout': settings.get('agent_audit_timeout', DEFAULT_THROTTLE_CONFIG['audit_timeout']),
            'command_batch_size': settings.get('agent_command_batch_size', DEFAULT_THROTTLE_CONFIG['command_batch_size']),
            'batch_delay': settings.get('agent_batch_delay', DEFAULT_THROTTLE_CONFIG['batch_delay']),
            'max_load_average': settings.get('agent_max_load_average', DEFAULT_THROTTLE_CONFIG['max_load_average']),
            'max_cpu_pct': settings.get('agent_max_cpu_pct', DEFAULT_THROTTLE_CONFIG['max_cpu_pct']),
            'heartbeat_min_interval': settings.get('agent_heartbeat_interval', DEFAULT_THROTTLE_CONFIG['heartbeat_min_interval']),
            'poll_interval': settings.get('agent_poll_interval', DEFAULT_THROTTLE_CONFIG['poll_interval']),
        }
    except ImportError:
        logger.warning("security_settings module not available, using hardcoded defaults")
        return DEFAULT_THROTTLE_CONFIG.copy()
    except Exception as e:
        logger.warning(f"Error loading throttle defaults from settings: {e}")
        return DEFAULT_THROTTLE_CONFIG.copy()


def _load_throttle_configs():
    """Load all agent throttle configurations"""
    if os.path.exists(THROTTLE_CONFIG_FILE):
        try:
            with open(THROTTLE_CONFIG_FILE, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def _save_throttle_configs(configs):
    """Save agent throttle configurations"""
    os.makedirs(os.path.dirname(THROTTLE_CONFIG_FILE), exist_ok=True)
    with open(THROTTLE_CONFIG_FILE, 'w') as f:
        json.dump(configs, f, indent=2, default=str)


def get_agent_throttle_config(agent_id):
    """
    Get throttle configuration for a specific agent

    Returns the agent's custom config merged with admin settings defaults,
    and then agent-specific overrides.

    Hierarchy: Admin Settings → Per-Agent Config File → Agent-Specific Overrides
    """
    configs = _load_throttle_configs()

    # Start with defaults from Admin Settings
    defaults_from_settings = _get_throttle_defaults_from_settings()

    # Apply any global overrides from config file
    global_config = configs.get('_global', {})
    result = defaults_from_settings.copy()
    result.update(global_config)

    # Get agent-specific overrides
    agent_config = configs.get(agent_id, {})

    # Merge: admin defaults <- global overrides <- agent overrides
    result.update(agent_config)

    return result


def set_agent_throttle_config(agent_id, config):
    """
    Set throttle configuration for a specific agent

    Args:
        agent_id: Agent ID or '_global' for global defaults
        config: Dict with throttle settings to override
    """
    configs = _load_throttle_configs()

    if agent_id not in configs:
        configs[agent_id] = {}

    # Only store non-default values to keep config minimal
    for key, value in config.items():
        if key in DEFAULT_THROTTLE_CONFIG:
            configs[agent_id][key] = value

    _save_throttle_configs(configs)
    return configs[agent_id]


@agent_bp.route('/api/agent/throttle', methods=['GET'])
@require_api_key
def get_all_throttle_configs():
    """
    Get all agent throttle configurations

    Returns global defaults and per-agent overrides
    """
    configs = _load_throttle_configs()
    return jsonify({
        'success': True,
        'defaults': DEFAULT_THROTTLE_CONFIG,
        'global': configs.get('_global', {}),
        'agents': {k: v for k, v in configs.items() if k != '_global'}
    })


@agent_bp.route('/api/agent/<agent_id>/throttle', methods=['GET', 'PUT'])
@require_api_key
def agent_throttle_config(agent_id):
    """
    Get or set throttle configuration for an agent

    GET: Returns current effective config (defaults + agent overrides)
    PUT: Updates agent-specific throttle settings

    Request body for PUT:
    {
        "cpu_nice_level": 19,
        "upload_rate_limit": 102400,
        "poll_interval": 120,
        ...
    }
    """
    if request.method == 'GET':
        config = get_agent_throttle_config(agent_id)
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'config': config
        })

    else:  # PUT
        data = request.json or {}

        # Validate config keys
        invalid_keys = [k for k in data.keys() if k not in DEFAULT_THROTTLE_CONFIG]
        if invalid_keys:
            return jsonify({
                'success': False,
                'error': f"Invalid throttle config keys: {invalid_keys}",
                'valid_keys': list(DEFAULT_THROTTLE_CONFIG.keys())
            }), 400

        config = set_agent_throttle_config(agent_id, data)
        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'config': get_agent_throttle_config(agent_id)
        })


@agent_bp.route('/api/agent/throttle/global', methods=['GET', 'PUT'])
@require_api_key
def global_throttle_config():
    """
    Get or set global throttle defaults

    These defaults apply to all agents unless overridden per-agent.
    Admin Settings (Admin Panel) → Global Overrides (this) → Per-Agent Config
    """
    if request.method == 'GET':
        configs = _load_throttle_configs()
        return jsonify({
            'success': True,
            'admin_defaults': _get_throttle_defaults_from_settings(),
            'global_overrides': configs.get('_global', {}),
            'effective_config': get_agent_throttle_config('_global'),
            'note': 'Admin defaults can be configured in Admin Settings → Agent Throttle Settings'
        })

    else:  # PUT
        data = request.json or {}

        # Validate config keys
        invalid_keys = [k for k in data.keys() if k not in DEFAULT_THROTTLE_CONFIG]
        if invalid_keys:
            return jsonify({
                'success': False,
                'error': f"Invalid throttle config keys: {invalid_keys}",
                'valid_keys': list(DEFAULT_THROTTLE_CONFIG.keys())
            }), 400

        config = set_agent_throttle_config('_global', data)
        return jsonify({
            'success': True,
            'config': get_agent_throttle_config('_global')
        })


@agent_bp.route('/api/agent/commands', methods=['GET'])
@require_agent_api_key
def get_agent_commands():
    """
    Get pending commands for an agent (agent polling endpoint)

    Headers:
        X-Agent-ID: Required agent identifier

    Query params:
        limit: Max commands to return (default 10)
    """
    try:
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            return jsonify({'success': False, 'error': 'X-Agent-ID header required'}), 400

        signature_ok, signature_error = _verify_command_request_signature(agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        limit = int(request.args.get('limit', 10))
        commands = get_pending_commands(agent_id, limit)
        if not commands:
            _maybe_enqueue_self_update_on_poll(agent_id)
            commands = get_pending_commands(agent_id, limit)

        return jsonify({
            'success': True,
            'commands': commands,
            'count': len(commands),
            'server_time': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Failed to get agent commands: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/commands/<command_id>/ack', methods=['POST'])
@require_agent_api_key
def acknowledge_command(command_id):
    """
    Acknowledge receipt of a command (agent marks as received)

    Headers:
        X-Agent-ID: Required agent identifier
    """
    try:
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            return jsonify({'success': False, 'error': 'X-Agent-ID header required'}), 400

        signature_ok, signature_error = _verify_command_request_signature(agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        commands = _load_agent_commands(agent_id)
        found = False

        for cmd in commands:
            if cmd['id'] == command_id:
                cmd['status'] = 'acknowledged'
                cmd['acknowledged_at'] = datetime.now().isoformat()
                found = True
                break

        if not found:
            return jsonify({'success': False, 'error': 'Command not found'}), 404

        _save_agent_commands(agent_id, commands)

        logger.info(f"Agent {agent_id} acknowledged command {command_id}")
        return jsonify({'success': True, 'message': 'Command acknowledged'})

    except Exception as e:
        logger.error(f"Failed to acknowledge command: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/commands/<command_id>/start', methods=['POST'])
@require_agent_api_key
def start_command(command_id):
    """
    Mark command as started (agent is executing)

    Headers:
        X-Agent-ID: Required agent identifier
    """
    try:
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            return jsonify({'success': False, 'error': 'X-Agent-ID header required'}), 400

        signature_ok, signature_error = _verify_command_request_signature(agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        commands = _load_agent_commands(agent_id)
        found = False

        for cmd in commands:
            if cmd['id'] == command_id:
                cmd['status'] = 'in_progress'
                cmd['started_at'] = datetime.now().isoformat()
                found = True
                break

        if not found:
            return jsonify({'success': False, 'error': 'Command not found'}), 404

        _save_agent_commands(agent_id, commands)

        logger.info(f"Agent {agent_id} started command {command_id}")
        return jsonify({'success': True, 'message': 'Command marked as started'})

    except Exception as e:
        logger.error(f"Failed to mark command started: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/commands/<command_id>/complete', methods=['POST'])
@require_agent_api_key
def complete_command(command_id):
    """
    Mark command as completed with results

    Headers:
        X-Agent-ID: Required agent identifier

    Request body:
    {
        "success": true,
        "result_data": {...},  // Command-specific results
        "error_message": null
    }
    """
    try:
        agent_id = request.headers.get('X-Agent-ID')
        if not agent_id:
            return jsonify({'success': False, 'error': 'X-Agent-ID header required'}), 400

        signature_ok, signature_error = _verify_command_request_signature(agent_id)
        if not signature_ok:
            return jsonify({'success': False, 'error': 'Request signature validation failed', 'details': signature_error}), 403

        data = request.json or {}
        commands = _load_agent_commands(agent_id)
        found = False
        command = None

        for cmd in commands:
            if cmd['id'] == command_id:
                cmd['status'] = 'completed' if data.get('success', True) else 'failed'
                cmd['completed_at'] = datetime.now().isoformat()
                cmd['result_data'] = data.get('result_data')
                cmd['error_message'] = data.get('error_message')
                found = True
                command = cmd
                break

        if not found:
            return jsonify({'success': False, 'error': 'Command not found'}), 404

        _save_agent_commands(agent_id, commands)

        # If this was an audit command, store the result
        if command is not None and command.get('command_type') in ['run_audit', 'run_plan']:
            _process_audit_result(agent_id, command, data)

        status = command['status'] if command else 'unknown'
        logger.info(f"Agent {agent_id} completed command {command_id} (status: {status})")
        return jsonify({'success': True, 'message': 'Command completed'})

    except Exception as e:
        logger.error(f"Failed to complete command: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _process_audit_result(agent_id, command, result_data):
    """
    Process audit results from agent command completion

    Stores results in standard audit results format for consistency
    """
    try:
        result = result_data.get('result_data', {})
        if not result:
            return

        # Get agent info for hostname
        agents = _load_agents()
        agent = agents.get(agent_id, {})
        hostname = agent.get('hostname', agent_id)

        # Store in agent results directory
        _ensure_dirs()
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        result_file = os.path.join(
            AGENT_RESULTS_DIR,
            f"{hostname}_{command.get('command_type', 'audit')}_{timestamp}.json"
        )

        result_entry = {
            'agent_id': agent_id,
            'hostname': hostname,
            'command_id': command['id'],
            'command_type': command['command_type'],
            'command_data': command.get('command_data'),
            'result': result,
            'requested_by': command.get('requested_by'),
            'queued_at': command.get('created_at'),
            'completed_at': command.get('completed_at'),
            'duration_seconds': _calculate_duration(command)
        }

        with open(result_file, 'w') as f:
            json.dump(result_entry, f, indent=2, default=str)

        logger.info(f"Stored audit result from agent {agent_id}: {result_file}")

    except Exception as e:
        logger.error(f"Failed to process audit result: {e}")


def _calculate_duration(command):
    """Calculate execution duration from command timestamps"""
    try:
        started = command.get('started_at')
        completed = command.get('completed_at')
        if started and completed:
            start_time = datetime.fromisoformat(started)
            end_time = datetime.fromisoformat(completed)
            return (end_time - start_time).total_seconds()
    except Exception as e:  # noqa: B110 - non-critical duration calculation
        logger.debug(f"Could not calculate command duration: {e}")
    return None


@agent_bp.route('/api/agent/commands/queue', methods=['POST'])
@require_api_key
def queue_command():
    """
    Queue a command for an agent (server-side endpoint)

    Request body:
    {
        "agent_id": "abc123",
        "command_type": "run_audit",
        "command_data": {
            "audit_path": "platform/baseline/updates",
            "options": {}
        },
        "priority": 5,
        "expires_hours": 24
    }
    """
    try:
        data = request.json
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request body'}), 400

        agent_id = data.get('agent_id')
        command_type = data.get('command_type')
        command_data = data.get('command_data', {})

        if not agent_id or not command_type:
            return jsonify({'success': False, 'error': 'agent_id and command_type required'}), 400

        # Validate command type
        valid_types = ['run_audit', 'run_plan', 'run_discovery', 'update_config', 'sync_audits', 'self_update']
        if command_type not in valid_types:
            return jsonify({
                'success': False,
                'error': f'Invalid command_type. Must be one of: {valid_types}'
            }), 400

        # Get requester from auth
        requested_by = None
        try:
            from flask_login import current_user
            if current_user and current_user.is_authenticated:
                requested_by = current_user.username
        except Exception as auth_err:  # noqa: B110 - fallback to None is acceptable
            logger.debug(f"Could not get current user for command request: {auth_err}")

        command = queue_command_for_agent(
            agent_id=agent_id,
            command_type=command_type,
            command_data=command_data,
            requested_by=requested_by,
            priority=data.get('priority', 5),
            expires_hours=data.get('expires_hours', 24)
        )

        return jsonify({
            'success': True,
            'command': command,
            'message': f'Command queued for agent {agent_id}'
        })

    except Exception as e:
        logger.error(f"Failed to queue command: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/agent/commands/history', methods=['GET'])
@require_api_key
def get_command_history():
    """
    Get command history for an agent

    Query params:
        agent_id: Required agent ID
        status: Filter by status (pending, completed, failed, etc.)
        limit: Max commands to return (default 50)
    """
    try:
        agent_id = request.args.get('agent_id')
        if not agent_id:
            return jsonify({'success': False, 'error': 'agent_id required'}), 400

        status_filter = request.args.get('status', '')
        limit = int(request.args.get('limit', 50))

        commands = _load_agent_commands(agent_id)

        # Apply filter
        if status_filter:
            commands = [c for c in commands if c.get('status') == status_filter]

        # Sort by created_at descending
        commands.sort(key=lambda x: x.get('created_at', ''), reverse=True)

        return jsonify({
            'success': True,
            'commands': commands[:limit],
            'count': len(commands)
        })

    except Exception as e:
        logger.error(f"Failed to get command history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Agent License Delegation (v1 API)
# ============================================================================
# Storage for delegated licenses
AGENT_LICENSES_FILE = os.path.join(ROOT_DIR, 'data', 'agent_licenses.json')


def _load_agent_licenses():
    """Load delegated agent licenses from file."""
    try:
        if os.path.exists(AGENT_LICENSES_FILE):
            with open(AGENT_LICENSES_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load agent licenses: {e}")
    return {'licenses': {}, 'max_agents': 25, 'core_tier': 'free'}


def _save_agent_licenses(data):
    """Save delegated agent licenses to file."""
    try:
        os.makedirs(os.path.dirname(AGENT_LICENSES_FILE), exist_ok=True)
        with open(AGENT_LICENSES_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save agent licenses: {e}")


def _get_core_license_info():
    """Get the Core Server's license information."""
    try:
        from services_pkg.services.license_service import (
            get_delegated_agent_limit_for_tier,
            get_license_service,
        )
        service = get_license_service()
        status = service.get_status()
        license_info = status.get('license', {})
        return {
            'tier': license_info.get('tier', 'free'),
            'is_valid': license_info.get('is_valid', True),
            'max_agents': get_delegated_agent_limit_for_tier(license_info.get('tier', 'free')),
            'expires': license_info.get('expires'),
        }
    except Exception as e:
        logger.error(f"Failed to get core license info: {e}")
        return {'tier': 'free', 'is_valid': True, 'max_agents': 25, 'expires': None}


def _tier_to_max_agents(tier: str) -> int:
    """Convert license tier to max agents allowed."""
    from services_pkg.services.license_service import get_delegated_agent_limit_for_tier

    return get_delegated_agent_limit_for_tier(tier)


@agent_bp.route('/api/v1/agents/license', methods=['POST'])
def request_agent_license():
    """
    Request a delegated license from the Core Server.

    This endpoint allows standalone agents to inherit licensing from
    the Core Server they connect to. The Core Server tracks license
    slots and delegates its tier to connected agents.

    Request body:
    {
        "hardware_id": "unique-hardware-fingerprint",
        "hostname": "agent-hostname",
        "agent_version": "X.Y.Z"
    }

    Headers (optional):
        X-API-Key: <agent_api_key>

    Returns:
        {
            "success": true,
            "tier": "professional",
            "license_id": "core-server-license-id",
            "agent_slot": 3,
            "max_agents": 100,
            "agents_used": 15,
            "expires_at": "2025-12-31T23:59:59",
            "features": {...}
        }
    """
    try:
        data = request.json or {}
        hardware_id = data.get('hardware_id')
        hostname = data.get('hostname', 'unknown')
        agent_version = data.get('agent_version', 'unknown')

        if not hardware_id:
            return jsonify({
                'success': False,
                'error': 'hardware_id is required'
            }), 400

        # Get Core Server's license information
        core_license = _get_core_license_info()
        core_tier = core_license.get('tier', 'free')
        max_agents = core_license.get('max_agents', 25)
        expires = core_license.get('expires')

        # Load existing agent licenses
        license_data = _load_agent_licenses()
        licenses = license_data.get('licenses', {})

        # Check if this hardware_id already has a license slot
        existing_slot = None
        for slot_id, slot_data in licenses.items():
            if slot_data.get('hardware_id') == hardware_id:
                existing_slot = int(slot_id)
                break

        if existing_slot is not None:
            # Renew existing license
            slot = existing_slot
            licenses[str(slot)]['last_seen'] = datetime.now().isoformat()
            licenses[str(slot)]['hostname'] = hostname
            licenses[str(slot)]['agent_version'] = agent_version
            logger.info(f"Agent license renewed: {hostname} (slot {slot})")
        else:
            # Check if we have available slots
            agents_used = len(licenses)
            if agents_used >= max_agents:
                return jsonify({
                    'success': False,
                    'error': 'No available agent license slots',
                    'tier': core_tier,
                    'max_agents': max_agents,
                    'agents_used': agents_used
                }), 403

            # Allocate new slot
            slot = agents_used + 1
            licenses[str(slot)] = {
                'hardware_id': hardware_id,
                'hostname': hostname,
                'agent_version': agent_version,
                'allocated_at': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat()
            }
            logger.info(f"Agent license allocated: {hostname} (slot {slot})")

        # Update and save license data
        license_data['licenses'] = licenses
        license_data['max_agents'] = max_agents
        license_data['core_tier'] = core_tier
        license_data['last_updated'] = datetime.now().isoformat()
        _save_agent_licenses(license_data)

        # Define features by tier (matching standalone agent's TIER_FEATURES)
        tier_features = {
            'free': {
                'max_agents': 25,
                'all_audits': False,
                'scheduled_audits': False,
                'core_server_integration': False,
            },
            'starter': {
                'max_agents': 50,
                'all_audits': True,
                'scheduled_audits': False,
                'core_server_integration': True,
            },
            'professional': {
                'max_agents': 150,
                'all_audits': True,
                'scheduled_audits': True,
                'core_server_integration': True,
            },
            'business': {
                'max_agents': 500,
                'all_audits': True,
                'scheduled_audits': True,
                'core_server_integration': True,
            },
            'enterprise': {
                'max_agents': 10000,
                'all_audits': True,
                'scheduled_audits': True,
                'core_server_integration': True,
            }
        }

        return jsonify({
            'success': True,
            'tier': core_tier,
            'license_id': f"core-{hashlib.sha256(ROOT_DIR.encode()).hexdigest()[:12]}",
            'agent_slot': slot,
            'max_agents': max_agents,
            'agents_used': len(licenses),
            'expires_at': expires,
            'features': tier_features.get(core_tier, tier_features['free'])
        })

    except Exception as e:
        logger.exception(f"Agent license request failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@agent_bp.route('/api/v1/agents/license', methods=['GET'])
@require_api_key
def get_agent_licenses():
    """
    Get all delegated agent licenses (admin view).

    Returns:
        {
            "core_tier": "professional",
            "max_agents": 100,
            "agents_used": 15,
            "licenses": [
                {"slot": 1, "hostname": "server1", ...},
                ...
            ]
        }
    """
    try:
        license_data = _load_agent_licenses()
        core_license = _get_core_license_info()

        # Convert licenses dict to list
        licenses_list = []
        for slot_id, slot_data in license_data.get('licenses', {}).items():
            licenses_list.append({
                'slot': int(slot_id),
                **slot_data
            })

        # Sort by slot number
        licenses_list.sort(key=lambda x: x['slot'])

        return jsonify({
            'success': True,
            'core_tier': core_license.get('tier', 'free'),
            'core_expires': core_license.get('expires'),
            'max_agents': core_license.get('max_agents', 25),
            'agents_used': len(licenses_list),
            'licenses': licenses_list
        })

    except Exception as e:
        logger.error(f"Failed to get agent licenses: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/license/<int:slot>', methods=['DELETE'])
@require_api_key
@require_auth_and_permission('manage_agents')
def revoke_agent_license(slot):
    """
    Revoke a delegated agent license (admin only).

    This frees up the license slot for another agent.
    """
    try:
        license_data = _load_agent_licenses()
        licenses = license_data.get('licenses', {})

        slot_key = str(slot)
        if slot_key not in licenses:
            return jsonify({
                'success': False,
                'error': f'License slot {slot} not found'
            }), 404

        hostname = licenses[slot_key].get('hostname', 'unknown')
        del licenses[slot_key]

        # Reindex slots to be contiguous
        new_licenses = {}
        for idx, (_, data) in enumerate(sorted(licenses.items(), key=lambda x: int(x[0])), 1):
            new_licenses[str(idx)] = data

        license_data['licenses'] = new_licenses
        license_data['last_updated'] = datetime.now().isoformat()
        _save_agent_licenses(license_data)

        logger.info(f"Agent license revoked: {hostname} (slot {slot})")

        return jsonify({
            'success': True,
            'message': f'License slot {slot} revoked for {hostname}',
            'agents_used': len(new_licenses)
        })

    except Exception as e:
        logger.error(f"Failed to revoke agent license: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Standalone Pre-Signed License Keys  (ATKS-* keys)
# ============================================================================
# These keys are generated by the Core and can be copy-pasted into a standalone
# agent's settings page.  They work both online (the standalone redeems them
# against the Core) and offline (HMAC signature is verified locally using the
# same AUDIT_TOKEN_SIGNING_KEY env var configured on both sides).
#
# Slot limits per tier — shared with live-delegated agents.
STANDALONE_KEYS_FILE = os.path.join(ROOT_DIR, 'data', 'standalone_keys.json')

from services_pkg.services.license_service import get_standalone_key_limit_for_tier


def _load_standalone_keys() -> dict:
    """Load all issued standalone pre-signed keys from disk."""
    try:
        if os.path.exists(STANDALONE_KEYS_FILE):
            with open(STANDALONE_KEYS_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load standalone keys: {e}")
    return {'keys': {}}


def _save_standalone_keys(data: dict) -> None:
    """Persist standalone pre-signed keys to disk."""
    try:
        os.makedirs(os.path.dirname(STANDALONE_KEYS_FILE), exist_ok=True)
        with open(STANDALONE_KEYS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save standalone keys: {e}")


def _sign_standalone_payload(payload_str: str) -> str:
    """
    Sign a standalone key payload with HMAC-SHA256.

    Both Core and standalone agent must share the same AUDIT_TOKEN_SIGNING_KEY
    env var for offline HMAC verification to work.
    """
    signing_key = os.environ.get(
        'AUDIT_TOKEN_SIGNING_KEY',
        'audit-toolkit-default-signing-key-change-me'
    )
    combined = f"standalone-key:{signing_key}"
    sig = hmac.new(
        combined.encode('utf-8'),
        payload_str.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    return sig[:32]  # 128-bit truncated for compactness


def _build_standalone_key_string(key_id: str, payload: dict) -> str:
    """
    Build the distributable ATKS-* key string.

    Format:  ATKS-<base64url_payload>-<32char_hmac>
    """
    payload_bytes = json.dumps(payload, separators=(',', ':')).encode('utf-8')
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).decode('ascii').rstrip('=')
    sig = _sign_standalone_payload(payload_b64)
    return f"ATKS-{payload_b64}-{sig}"


_STANDALONE_SCOPE = 'standalone_keys'
_STANDALONE_AUTH_REQUIRED_CODE = 'STANDALONE_KEYS_AUTH_REQUIRED'


def _ensure_standalone_keys_secondary_auth():
    return None


def require_standalone_keys_unlock(f):
    @require_sensitive_tool_token(
        _STANDALONE_SCOPE,
        _STANDALONE_AUTH_REQUIRED_CODE,
        'Secondary authentication required for Standalone Key management',
    )
    def wrapped(*args, **kwargs):
        denied = _ensure_standalone_keys_secondary_auth()
        if denied:
            return denied
        return f(*args, **kwargs)

    wrapped.__name__ = f.__name__
    wrapped.__doc__ = f.__doc__
    wrapped.__module__ = f.__module__
    return wrapped


@agent_bp.route('/api/v1/agents/standalone-keys/authenticate', methods=['POST'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
def authenticate_standalone_key_access():
    """Issue a short-lived unlock token for Standalone Key management."""
    data = request.get_json(silent=True) or {}
    success, response, status_code = authenticate_sensitive_tool(_STANDALONE_SCOPE, data.get('password'))
    if success:
        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_keys_unlock_granted',
            user=username or 'unknown',
            details={'ip_address': request.remote_addr},
        )
    return jsonify(response), status_code


@agent_bp.route('/api/v1/agents/standalone-keys/authenticate/status', methods=['GET'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
def standalone_key_auth_status():
    """Return Standalone Key secondary-auth status."""
    return jsonify(get_sensitive_tool_auth_status(_STANDALONE_SCOPE))


@agent_bp.route('/api/v1/agents/standalone-keys/authenticate/revoke', methods=['POST'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
def revoke_standalone_key_access():
    """Revoke the current user's Standalone Key unlock."""
    username = getattr(getattr(g, 'current_user', None), 'username', None)
    revoke_sensitive_tool_auth(_STANDALONE_SCOPE)
    log_audit(
        action='standalone_keys_unlock_revoked',
        user=username or 'unknown',
        details={'ip_address': request.remote_addr},
    )
    return jsonify({'success': True, 'message': 'Standalone Key access revoked'})


@agent_bp.route('/api/v1/agents/standalone-keys', methods=['GET'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
@require_standalone_keys_unlock
def list_standalone_keys():
    """
    List all issued standalone pre-signed keys plus slot usage per tier.

    Returns:
        {
            "tier": "business",
            "slots_total": 25,
            "slots_used": 3,
            "slots_remaining": 22,
            "keys": [
                {
                    "key_id": "...",
                    "label": "web-dmz-agent",
                    "tier": "business",
                    "issued_at": "...",
                    "expires_at": "...",
                    "redeemed": false,
                    "redeemed_at": null,
                    "redeemed_by": null,
                    "revoked": false
                },
                ...
            ]
        }
    """
    try:
        core_license = _get_core_license_info()
        core_tier = core_license.get('tier', 'free').lower()
        slots_total = get_standalone_key_limit_for_tier(core_tier)

        key_store = _load_standalone_keys()
        active_keys = [
            k for k in key_store.get('keys', {}).values()
            if not k.get('revoked')
        ]

        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_keys_viewed',
            user=username or 'unknown',
            details={
                'tier': core_tier,
                'slots_total': slots_total,
                'slots_used': len(active_keys),
            },
        )

        return jsonify({
            'success': True,
            'tier': core_tier,
            'core_expires': core_license.get('expires'),
            'slots_total': slots_total,
            'slots_used': len(active_keys),
            'slots_remaining': max(0, slots_total - len(active_keys)),
            'keys': sorted(active_keys, key=lambda k: k.get('issued_at', ''), reverse=True),
        })
    except Exception as e:
        logger.error(f"Failed to list standalone keys: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/standalone-key', methods=['POST'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
@require_standalone_keys_unlock
def generate_standalone_key():
    """
    Generate a new pre-signed standalone license key.

    Request body:
        {
            "label": "web-dmz-agent",      // Human-readable label
            "validity_days": 365            // Optional, defaults to 365
        }

    Returns:
        {
            "success": true,
            "key": "ATKS-<payload>-<sig>",
            "key_id": "...",
            "tier": "business",
            "expires_at": "...",
            "slots_remaining": 22
        }
    """
    try:
        data = request.get_json() or {}
        label = str(data.get('label', 'Unnamed Agent')).strip()[:80]
        validity_days = int(data.get('validity_days', 365))
        validity_days = max(1, min(validity_days, 730))  # 1–730 days

        core_license = _get_core_license_info()
        core_tier = core_license.get('tier', 'free').lower()

        # Standalone keys always inherit the effective Core tier exactly.
        # Community/free remains disabled for separate key issuance.
        requested_tier = core_tier

        slots_total = get_standalone_key_limit_for_tier(core_tier)
        if slots_total == 0:
            return jsonify({
                'success': False,
                'error': (
                    f'Your current license tier ({core_tier!r}) does not include '
                    'standalone pre-signed key generation. Upgrade to Starter or above.'
                ),
            }), 403

        key_store = _load_standalone_keys()
        active_keys = [
            k for k in key_store.get('keys', {}).values()
            if not k.get('revoked')
        ]

        # Duplicate-machine guard: if the admin is issuing a machine-bound
        # key, reject the request if an active (non-revoked, non-expired) key
        # for exactly that machine already exists.  The existing key must be
        # revoked first, or it must have expired, before a new one can be issued.
        incoming_machine_id = str(data.get('machine_id') or '').strip()[:64] or None
        if incoming_machine_id:
            now_check = datetime.utcnow()
            for existing in active_keys:
                if existing.get('bound_machine_id') != incoming_machine_id:
                    continue
                # Check whether it has already expired.
                existing_exp_str = existing.get('expires_at') or ''
                try:
                    existing_exp_dt = datetime.fromisoformat(
                        existing_exp_str.replace('Z', '')
                    )
                except (ValueError, AttributeError):
                    existing_exp_dt = None
                if existing_exp_dt and existing_exp_dt <= now_check:
                    # Key has expired — allow re-issue.
                    continue
                # Still live: block the request.
                return jsonify({
                    'success': False,
                    'error': (
                        'An active standalone key is already bound to this machine. '
                        'Revoke the existing key before issuing a new one.'
                    ),
                    'conflicting_key_id': existing.get('key_id'),
                    'conflicting_label': existing.get('label'),
                    'conflicting_expires_at': existing_exp_str,
                }), 409

        if len(active_keys) >= slots_total:
            return jsonify({
                'success': False,
                'error': (
                    f'Standalone key slot limit reached ({slots_total} for {core_tier!r} tier). '
                    'Revoke unused keys or upgrade your license.'
                ),
                'slots_total': slots_total,
                'slots_used': len(active_keys),
            }), 403

        now = datetime.utcnow()
        key_id = secrets.token_hex(16)
        core_host = core_license.get('core_host') or ''  # filled in if available

        # Cap key validity to the Core license expiry so a standalone key
        # can never outlive the license terms of the issuing Core server.
        # Hard maximum: 365 days regardless of what Core returns, so that
        # a perpetual/no-expiry Core license cannot produce an open-ended key.
        STANDALONE_KEY_MAX_DAYS = 365
        requested_expiry = now + timedelta(days=min(validity_days, STANDALONE_KEY_MAX_DAYS))
        core_expires_str = core_license.get('expires')
        core_expiry_dt = None
        if core_expires_str:
            try:
                core_expiry_dt = datetime.fromisoformat(core_expires_str.replace('Z', ''))
            except (ValueError, AttributeError):
                pass
        # Apply the Core expiry ceiling if it is sooner than the requested duration.
        if core_expiry_dt and requested_expiry > core_expiry_dt:
            effective_expiry = core_expiry_dt
        else:
            effective_expiry = requested_expiry
        expires_at = effective_expiry.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Optional machine binding — admin may supply the target hardware fingerprint
        # so the key is locked to a single machine at issuance time.
        bound_machine_id = str(data.get('machine_id') or '').strip()[:64] or None

        payload = {
            'v': 1,
            'kid': key_id,
            'tier': requested_tier,
            'iat': now.strftime('%Y-%m-%dT%H:%M:%SZ'),
            'exp': expires_at,
            'ac': 'standalone',          # agent_class
            'ch': core_host,             # core_host (for auto-registration)
            'lbl': label,
        }
        if bound_machine_id:
            payload['mid'] = bound_machine_id  # machine-bound fingerprint

        key_string = _build_standalone_key_string(key_id, payload)

        # Store issued key (without the key string itself — only metadata)
        key_record = {
            'key_id': key_id,
            'label': label,
            'tier': requested_tier,
            'issued_at': now.isoformat(),
            'expires_at': expires_at,
            'core_license_expires': core_expires_str or None,   # ceiling reference
            'bound_machine_id': bound_machine_id,
            'redeemed': False,
            'redeemed_at': None,
            'redeemed_by': None,
            'revoked': False,
        }
        key_store.setdefault('keys', {})[key_id] = key_record
        _save_standalone_keys(key_store)

        active_after = len([k for k in key_store['keys'].values() if not k.get('revoked')])
        logger.info(f"Standalone key generated: {key_id} label={label!r} tier={requested_tier!r}")
        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_key_generated',
            user=username or 'unknown',
            details={
                'key_id': key_id,
                'label': label,
                'tier': requested_tier,
                'expires_at': expires_at,
            },
        )

        return jsonify({
            'success': True,
            'key': key_string,
            'key_id': key_id,
            'label': label,
            'tier': requested_tier,
            'core_tier': core_tier,
            'expires_at': expires_at,
            'capped_to_core_expiry': core_expiry_dt is not None and effective_expiry == core_expiry_dt,
            'slots_total': slots_total,
            'slots_used': active_after,
            'slots_remaining': max(0, slots_total - active_after),
        })

    except Exception as e:
        logger.error(f"Failed to generate standalone key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/standalone-key/<key_id>', methods=['DELETE'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
@require_standalone_keys_unlock
def revoke_standalone_key(key_id):
    """
    Revoke a standalone pre-signed key by ID.

    Once revoked, any standalone agent using this key will fall back to
    Community tier on next license refresh.
    """
    try:
        key_store = _load_standalone_keys()
        keys = key_store.get('keys', {})

        if key_id not in keys:
            return jsonify({'success': False, 'error': f'Key {key_id!r} not found'}), 404

        label = keys[key_id].get('label', 'unknown')
        keys[key_id]['revoked'] = True
        keys[key_id]['revoked_at'] = datetime.utcnow().isoformat()
        _save_standalone_keys(key_store)

        active_remaining = len([k for k in keys.values() if not k.get('revoked')])
        logger.info(f"Standalone key revoked: {key_id} label={label!r}")
        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_key_revoked',
            user=username or 'unknown',
            details={'key_id': key_id, 'label': label},
        )

        return jsonify({
            'success': True,
            'message': f'Key {key_id!r} ({label}) revoked successfully.',
            'slots_used': active_remaining,
        })

    except Exception as e:
        logger.error(f"Failed to revoke standalone key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/standalone-key/<key_id>/purge', methods=['DELETE'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
@require_standalone_keys_unlock
def purge_standalone_key(key_id):
    """
    Permanently delete a standalone key record from the store.

    Only permitted when the key is already revoked OR has expired — an active
    key must be revoked first.  Purging a revoked/expired key does NOT free an
    additional slot (that was already freed at revocation/expiry time); it
    simply removes the dead row from the list for housekeeping.
    """
    try:
        key_store = _load_standalone_keys()
        keys = key_store.get('keys', {})

        if key_id not in keys:
            return jsonify({'success': False, 'error': f'Key {key_id!r} not found'}), 404

        record = keys[key_id]
        label = record.get('label', 'unknown')
        is_revoked = bool(record.get('revoked'))
        expires_at_str = record.get('expires_at') or ''
        try:
            is_expired = bool(
                expires_at_str
                and datetime.fromisoformat(expires_at_str.replace('Z', '')) <= datetime.utcnow()
            )
        except (ValueError, AttributeError):
            is_expired = False

        if not is_revoked and not is_expired:
            return jsonify({
                'success': False,
                'error': 'Cannot purge an active key. Revoke it first.',
            }), 409

        del keys[key_id]
        _save_standalone_keys(key_store)
        logger.info(f"Standalone key purged: {key_id} label={label!r}")
        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_key_purged',
            user=username or 'unknown',
            details={'key_id': key_id, 'label': label},
        )

        return jsonify({
            'success': True,
            'message': f'Key "{label}" permanently removed.',
        })

    except Exception as e:
        logger.error(f"Failed to purge standalone key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/standalone-keys/purge-dead', methods=['DELETE'])
@require_auth_and_role('SuperAdmin')
@require_auth_and_permission('manage_agents')
@require_standalone_keys_unlock
def purge_dead_standalone_keys():
    """
    Bulk-purge all revoked and expired standalone key records in one call.
    Active keys are left untouched.
    """
    try:
        key_store = _load_standalone_keys()
        keys = key_store.get('keys', {})
        now = datetime.utcnow()
        to_remove = []
        for kid, record in keys.items():
            if record.get('revoked'):
                to_remove.append(kid)
                continue
            exp_str = record.get('expires_at') or ''
            try:
                if exp_str and datetime.fromisoformat(exp_str.replace('Z', '')) <= now:
                    to_remove.append(kid)
            except (ValueError, AttributeError):
                pass

        for kid in to_remove:
            del keys[kid]
        _save_standalone_keys(key_store)
        logger.info(f"Bulk purged {len(to_remove)} dead standalone key(s)")
        username = getattr(getattr(g, 'current_user', None), 'username', None)
        log_audit(
            action='standalone_keys_bulk_purged',
            user=username or 'unknown',
            details={'purged': len(to_remove)},
        )

        return jsonify({
            'success': True,
            'purged': len(to_remove),
            'message': f'{len(to_remove)} dead key(s) removed.',
        })

    except Exception as e:
        logger.error(f"Failed to bulk-purge standalone keys: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agent_bp.route('/api/v1/agents/standalone-key/<key_id>/redeem', methods=['POST'])
def redeem_standalone_key(key_id):
    """
    Called by a standalone agent to redeem a pre-signed key and obtain a
    full delegated license payload.

    This is the online redemption path.  The standalone may also use the key
    offline by verifying its HMAC signature locally.

    Request body:
        {
            "key": "ATKS-<payload>-<sig>",
            "hardware_id": "<sha256 fingerprint>",
            "hostname": "agent-hostname",
            "agent_version": "X.Y.Z"
        }
    """
    try:
        data = request.get_json() or {}
        key_string = data.get('key', '').strip()
        hardware_id = data.get('hardware_id', '').strip()
        hostname = data.get('hostname', 'unknown')

        if not key_string or not hardware_id:
            return jsonify({'success': False, 'error': 'key and hardware_id are required'}), 400

        # Parse ATKS key
        if not key_string.startswith('ATKS-'):
            return jsonify({'success': False, 'error': 'Not a valid standalone key (expected ATKS- prefix)'}), 400

        parts = key_string.split('-', 2)  # ATKS, payload_b64, sig
        if len(parts) != 3:
            return jsonify({'success': False, 'error': 'Malformed standalone key'}), 400

        _, payload_b64, provided_sig = parts

        # Verify HMAC signature
        expected_sig = _sign_standalone_payload(payload_b64)
        if not hmac.compare_digest(expected_sig, provided_sig):
            return jsonify({'success': False, 'error': 'Invalid key signature'}), 403

        # Decode payload
        pad = '=' * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64 + pad))
        key_id = payload.get('kid')
        tier = payload.get('tier', 'community')
        expires_at = payload.get('exp')

        # Check expiry
        if expires_at:
            try:
                if datetime.utcnow() > datetime.strptime(expires_at, '%Y-%m-%dT%H:%M:%SZ'):
                    return jsonify({'success': False, 'error': 'Standalone key has expired'}), 403
            except ValueError:
                pass

        # Check key is not revoked
        key_store = _load_standalone_keys()
        key_record = key_store.get('keys', {}).get(key_id)
        if key_record and key_record.get('revoked'):
            return jsonify({'success': False, 'error': 'Standalone key has been revoked'}), 403

        # Enforce machine binding when the key was issued with mid in payload
        bound_mid = payload.get('mid')
        if bound_mid and bound_mid != hardware_id:
            return jsonify({
                'success': False,
                'error': 'This key is bound to a different machine and cannot be redeemed here.',
            }), 403

        # Mark as redeemed (idempotent — same agent can re-redeem)
        if key_record:
            if not key_record.get('redeemed'):
                key_record['redeemed'] = True
                key_record['redeemed_at'] = datetime.utcnow().isoformat()
                key_record['redeemed_by'] = hardware_id[:16] + '...'
            key_store['keys'][key_id] = key_record
            _save_standalone_keys(key_store)

        # Return full delegated license payload
        core_license = _get_core_license_info()
        return jsonify({
            'success': True,
            'tier': tier,
            'license_id': f"atks-{key_id}",
            'agent_slot': key_id,
            'agent_slot_type': 'standalone',
            'agent_class': 'standalone',
            'max_agents': get_standalone_key_limit_for_tier(core_license.get('tier', 'free').lower()),
            'agents_used': len([k for k in key_store.get('keys', {}).values() if not k.get('revoked')]),
            'expires_at': expires_at,
            'key_id': key_id,
        })

    except Exception as e:
        logger.error(f"Failed to redeem standalone key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
