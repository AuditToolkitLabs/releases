"""
Unified Agent Management API Routes

Provides cross-agent endpoints for:
- Unified health status across all agent types
- Synchronized agent registry (FleetAgent table)
- Normalized error tracking and diagnostics
- Bulk operations (retry failed imports, test connections)

Works with all agent types:
- Lightweight agents (file-based, polling)
- Managed agents (API-based heartbeat)
- Hypervisor agents (specialized API agents)

Author: Security Audit Toolkit Team
Date: February 19, 2026
"""

import json
import os
import re
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from sqlalchemy import and_

from config import logger, ROOT_DIR
from auth_core import require_auth_and_permission
from api.agent_pathing import get_standalone_agent_dir

# Import database models
try:
    from models.database import FleetAgent
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    logger.warning("Database models not available")

# Create blueprint
agents_unified_bp = Blueprint('agents_unified', __name__)

# Database session (will be set by app.py)
_db_session = None

AGENT_UPDATE_POLICY_FILE = os.path.join(ROOT_DIR, 'data', 'agent_update_policy.json')
STANDALONE_AGENT_DIR = str(get_standalone_agent_dir())

DEFAULT_AGENT_UPDATE_POLICY = {
    'auto_update_on_register': False,
    'auto_update_on_poll_drift': False,
    'rollout_mode': 'manual',
    'canary_limit': 5,
    'allow_downgrade': False,
    'cooldown_minutes': 60,
    'max_attempts': 3,
}


def _version_tuple(version: str):
    if not version:
        return (0, 0, 0)
    match = re.search(r'(\d+)\.(\d+)\.(\d+)', str(version))
    if not match:
        return (0, 0, 0)
    return tuple(int(x) for x in match.groups())


def _extract_agent_version(file_path: str, default_version: str = '0.0.0') -> str:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        patterns = [
            r'AGENT_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'\$script:AgentVersion\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'\$AGENT_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"',
            r'v([0-9]+\.[0-9]+\.[0-9]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                return match.group(1)
    except Exception as version_error:
        logger.debug(f"Unable to extract unified agent version from {file_path}: {version_error}")
    return default_version


def _find_latest_versioned_agent(prefix: str, extension: str):
    agent_dir = STANDALONE_AGENT_DIR
    if not os.path.isdir(agent_dir):
        return None, None

    best_path = None
    best_version = None
    best_tuple = (0, 0, 0)

    pattern = re.compile(rf'^{re.escape(prefix)}-v(\d+\.\d+\.\d+){re.escape(extension)}$')
    for filename in os.listdir(agent_dir):
        match = pattern.match(filename)
        if not match:
            continue
        version = match.group(1)
        version_key = _version_tuple(version)
        if version_key > best_tuple:
            best_tuple = version_key
            best_version = version
            best_path = os.path.join(agent_dir, filename)

    return best_path, best_version


def _resolve_target_agent_version(agent_type: str, os_type: str):
    normalized_agent_type = (agent_type or '').lower().strip()
    normalized_os = (os_type or '').lower().strip()
    is_windows = normalized_os.startswith('windows')

    if normalized_agent_type not in ('managed', 'standalone'):
        return None

    agent_dir = STANDALONE_AGENT_DIR

    if normalized_agent_type == 'standalone':
        file_path = os.path.join(agent_dir, 'agent.ps1' if is_windows else 'agent.sh')
        if not os.path.isfile(file_path):
            return None
        return _extract_agent_version(file_path)

    if is_windows:
        versioned_path, versioned_version = _find_latest_versioned_agent('fleet-agent', '.ps1')
        fallback_path = os.path.join(agent_dir, 'fleet-agent.ps1')
    else:
        versioned_path, versioned_version = _find_latest_versioned_agent('fleet-agent', '.sh')
        fallback_path = os.path.join(agent_dir, 'fleet-agent.sh')

    if versioned_path and os.path.isfile(versioned_path):
        return versioned_version or _extract_agent_version(versioned_path)

    if os.path.isfile(fallback_path):
        return _extract_agent_version(fallback_path)

    return None


def _load_update_policy():
    if os.path.exists(AGENT_UPDATE_POLICY_FILE):
        try:
            with open(AGENT_UPDATE_POLICY_FILE, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    policy = DEFAULT_AGENT_UPDATE_POLICY.copy()
                    policy.update(loaded)
                    return policy
        except Exception as e:
            logger.warning(f"Failed to load agent update policy: {e}")

    return DEFAULT_AGENT_UPDATE_POLICY.copy()


def _save_update_policy(policy):
    os.makedirs(os.path.dirname(AGENT_UPDATE_POLICY_FILE), exist_ok=True)
    with open(AGENT_UPDATE_POLICY_FILE, 'w', encoding='utf-8') as f:
        json.dump(policy, f, indent=2)


def _get_update_state(agent):
    current_version = (agent.get('agent_version') or '').strip() or None
    target_version = _resolve_target_agent_version(agent.get('agent_type'), agent.get('os_type'))

    if not current_version or not target_version:
        return {
            'current_version': current_version,
            'target_version': target_version,
            'version_drift': False,
            'update_eligible': False,
        }

    current_tuple = _version_tuple(current_version)
    target_tuple = _version_tuple(target_version)

    return {
        'current_version': current_version,
        'target_version': target_version,
        'version_drift': current_tuple != target_tuple,
        'update_eligible': agent.get('agent_type') == 'managed',
        'target_is_newer': target_tuple > current_tuple,
    }


def _get_recent_self_update(commands):
    self_updates = [c for c in commands if c.get('command_type') == 'self_update']
    if not self_updates:
        return None
    self_updates.sort(key=lambda item: item.get('created_at', ''), reverse=True)
    return self_updates[0]


def _enqueue_self_update(agent_id, trigger='manual', force=False, requested_by=None):
    from api import agent_routes

    agent = _db_session.query(FleetAgent).filter(
        FleetAgent.agent_id == agent_id
    ).first()
    if not agent:
        return False, 'Agent not found', None

    agent_data = agent.to_dict()
    update_state = _get_update_state(agent_data)
    current_version = update_state.get('current_version')
    target_version = update_state.get('target_version')

    if not target_version:
        return False, 'No target version artifact found for agent', None

    policy = _load_update_policy()
    allow_downgrade = bool(policy.get('allow_downgrade', False))
    cooldown_minutes = int(policy.get('cooldown_minutes', 60))
    max_attempts = int(policy.get('max_attempts', 3))

    current_tuple = _version_tuple(current_version or '0.0.0')
    target_tuple = _version_tuple(target_version)

    if target_tuple < current_tuple and not allow_downgrade and not force:
        return False, f'Downgrade blocked by policy ({current_version} -> {target_version})', None

    if target_tuple == current_tuple and not force:
        return False, 'Agent already on target version', None

    commands = agent_routes._load_agent_commands(agent_id)
    in_progress_states = {'pending', 'acknowledged', 'in_progress'}
    for cmd in commands:
        if cmd.get('command_type') == 'self_update' and cmd.get('status') in in_progress_states:
            return False, 'Self-update already queued for agent', cmd

    recent = _get_recent_self_update(commands)
    if recent and not force:
        try:
            recent_created = datetime.fromisoformat(recent.get('created_at'))
            age_minutes = (datetime.now() - recent_created).total_seconds() / 60.0
            if age_minutes < cooldown_minutes:
                return False, f'Cooldown active ({int(age_minutes)}m/{cooldown_minutes}m)', recent
        except Exception as parse_error:
            logger.debug(f"Skipping self-update cooldown timestamp parsing for {agent_id}: {parse_error}")

        if recent.get('status') == 'failed':
            failed_attempts = sum(
                1
                for cmd in commands
                if cmd.get('command_type') == 'self_update' and cmd.get('status') == 'failed'
            )
            if failed_attempts >= max_attempts:
                return False, f'Max self-update attempts reached ({failed_attempts})', recent

    command = agent_routes.queue_command_for_agent(
        agent_id=agent_id,
        command_type='self_update',
        command_data={
            'target_version': target_version,
            'current_version': current_version,
            'agent_type': agent_data.get('agent_type'),
            'os_type': agent_data.get('os_type'),
            'trigger': trigger,
            'force': force,
        },
        requested_by=requested_by,
        priority=2,
        expires_hours=24,
    )
    return True, 'Self-update queued', command


def maybe_enqueue_self_update_on_register(agent_id):
    policy = _load_update_policy()
    if not policy.get('auto_update_on_register', False):
        return None

    try:
        queued, message, command = _enqueue_self_update(
            agent_id=agent_id,
            trigger='auto_register',
            force=False,
            requested_by='system:auto-register',
        )
        if queued:
            logger.info(f"Queued auto self_update on register for {agent_id}: {command.get('id')}")
            return command
        logger.info(f"Skipped auto self_update on register for {agent_id}: {message}")
    except Exception as e:
        logger.warning(f"Auto self-update enqueue on register failed for {agent_id}: {e}")
    return None


def init_unified_agent_routes(db_session=None):
    """Initialize unified agent routes with database session"""
    global _db_session
    _db_session = db_session

    # Sync existing agents to FleetAgent table on init
    if _db_session:
        try:
            _sync_existing_agents_to_managed()
        except Exception as e:
            logger.warning(f"Failed to sync existing agents: {e}")


def _sync_existing_agents_to_managed():
    """
    Sync existing agents from all sources to FleetAgent table

    This function discovers agents from:
    1. Lightweight agents (agent_routes.py file storage)
    2. Managed agents (agent_fleet_routes.py)
    3. Hypervisor agents (hypervisor_agent_routes.py)
    4. Standalone servers (ssh/winrm connections via servers table)

    Only syncs new agents - existing ones are not updated.
    """
    import os
    from config import ROOT_DIR

    if not _db_session:
        return

    # 1. Sync Standalone Agents
    try:
        agents_dir = os.path.join(ROOT_DIR, 'data', 'agents')
        if os.path.exists(agents_dir):
            for filename in os.listdir(agents_dir):
                if filename.endswith('.json'):
                    try:
                        with open(os.path.join(agents_dir, filename), 'r') as f:
                            agent_data = json.load(f)
                            agent_id = agent_data.get('agent_id')

                            # Check if already exists
                            existing = _db_session.query(FleetAgent).filter(
                                FleetAgent.agent_id == agent_id
                            ).first()

                            if not existing:
                                fleet_agent = FleetAgent(
                                    agent_id=agent_id,
                                    agent_type='lightweight',
                                    name=agent_data.get('name', agent_id),
                                    hostname=agent_data.get('hostname'),
                                    os_type=agent_data.get('os_type'),
                                    is_active=True,
                                    registered_at=datetime.utcnow()
                                )
                                _db_session.add(fleet_agent)
                                logger.info(f"Synced standalone agent: {agent_id}")
                    except Exception as e:
                        logger.warning(f"Failed to sync agent {filename}: {e}")
        _db_session.commit()
    except Exception as e:
        logger.warning(f"Failed to sync standalone agents: {e}")
        _db_session.rollback()

    # 2. Sync Servers with agent_id (Fleet Agents)
    try:
        from models.database import Server

        managed_servers = _db_session.query(Server).filter(
            Server.agent_id.isnot(None),
            Server.connection_method == 'fleet-agent'
        ).all()

        for server in managed_servers:
            existing = _db_session.query(FleetAgent).filter(
                FleetAgent.agent_id == server.agent_id
            ).first()

            if not existing:
                fleet_agent = FleetAgent(
                    agent_id=server.agent_id,
                    agent_type='managed',
                    name=server.name,
                    hostname=server.hostname,
                    os_type='linux' if server.description and 'linux' in server.description.lower() else 'windows' if server.description and 'windows' in server.description.lower() else None,
                    is_active=True,
                    registered_at=server.created_at or datetime.utcnow()
                )
                _db_session.add(fleet_agent)
                logger.info(f"Synced fleet agent: {server.agent_id}")

        _db_session.commit()
    except Exception as e:
        logger.warning(f"Failed to sync fleet agents from servers: {e}")
        _db_session.rollback()

    # 3. Sync Hypervisors (as hypervisor agents)
    try:
        from models.database import Hypervisor

        hypervisors = _db_session.query(Hypervisor).all()

        for hypervisor in hypervisors:
            agent_id = f"hypervisor-{hypervisor.id}"

            existing = _db_session.query(FleetAgent).filter(
                FleetAgent.agent_id == agent_id
            ).first()

            if not existing:
                fleet_agent = FleetAgent(
                    agent_id=agent_id,
                    agent_type='hypervisor',
                    name=hypervisor.name,
                    hostname=hypervisor.hostname,
                    os_type=hypervisor.hypervisor_type,
                    is_active=hypervisor.status != 'offline',
                    registered_at=hypervisor.created_at or datetime.utcnow()
                )
                _db_session.add(fleet_agent)
                logger.info(f"Synced hypervisor agent: {agent_id}")

        _db_session.commit()
    except Exception as e:
        logger.warning(f"Failed to sync hypervisor agents: {e}")
        _db_session.rollback()


def _get_agent_health_status(agent):
    """
    Determine agent health status based on last heartbeat and errors

    Returns: (status, icon, message)
    - healthy: 🟢 (last heartbeat < 2 minutes ago)
    - degraded: 🟡 (last heartbeat 2-10 minutes ago or recent errors)
    - offline: 🔴 (no heartbeat > 10 minutes or connection errors)
    - unknown: ⚪ (never seen)
    """
    if not agent.last_heartbeat:
        return 'unknown', '⚪', 'Never registered'

    time_since_heartbeat = datetime.utcnow() - agent.last_heartbeat

    # Healthy: recent heartbeat and no recent errors
    if time_since_heartbeat < timedelta(minutes=2) and not agent.last_heartbeat_error:
        return 'healthy', '🟢', 'Connected and responding'

    # Degraded: stale heartbeat or recent errors but still seen
    if time_since_heartbeat < timedelta(minutes=10):
        if agent.last_heartbeat_error:
            return 'degraded', '🟡', f'Errors reporting: {agent.last_heartbeat_error[:50]}'
        return 'degraded', '🟡', f'Slow response ({time_since_heartbeat.seconds}s ago)'

    # Offline: no heartbeat for > 10 minutes
    return 'offline', '🔴', f'No connection for {int(time_since_heartbeat.total_seconds() / 60)}m'


def update_agent_heartbeat(
    agent_id,
    agent_type,
    error=None,
    hostname=None,
    name=None,
    os_type=None,
    agent_version=None,
    status=None,
):
    """
    Update agent heartbeat in FleetAgent table

    Called from heartbeat endpoints to keep status synchronized.

    Args:
        agent_id: Unique agent identifier
        agent_type: 'lightweight', 'managed', 'hypervisor', 'standalone'
        error: Optional error message if heartbeat failed
    """
    if not _db_session:
        return False

    try:
        normalized_type = (agent_type or 'lightweight').strip().lower()
        if normalized_type not in ('lightweight', 'managed', 'hypervisor', 'standalone'):
            normalized_type = 'lightweight'

        agent = _db_session.query(FleetAgent).filter(
            FleetAgent.agent_id == agent_id
        ).first()

        if not agent:
            # Create new agent entry if not exists
            agent = FleetAgent(
                agent_id=agent_id,
                agent_type=normalized_type,
                name=name or hostname or agent_id,
                hostname=hostname,
                os_type=os_type,
                agent_version=agent_version,
                status=status or 'unknown',
                is_active=True,
                registered_at=datetime.utcnow()
            )
            _db_session.add(agent)

        # Keep identity details fresh for dashboard + stats endpoints
        if normalized_type:
            agent.agent_type = normalized_type
        if name:
            agent.name = name
        elif hostname and (not agent.name or agent.name == agent.agent_id):
            agent.name = hostname
        if hostname:
            agent.hostname = hostname
        if os_type:
            agent.os_type = os_type
        if agent_version:
            agent.agent_version = agent_version
        if status:
            agent.status = status
        agent.is_active = True

        # Update heartbeat
        now = datetime.utcnow()
        agent.last_heartbeat = now
        agent.last_heartbeat_at = now
        agent.last_heartbeat_error = error
        if error:
            agent.last_heartbeat_status = 'connection_error'
            agent.heartbeat_failure_reason = str(error)[:200]
            agent.consecutive_heartbeat_failures = (agent.consecutive_heartbeat_failures or 0) + 1
        else:
            agent.last_heartbeat_status = 'ok'
            agent.heartbeat_failure_reason = None
            agent.consecutive_heartbeat_failures = 0

        _db_session.commit()
        return True

    except Exception as e:
        logger.error(f"Failed to update agent heartbeat: {e}")
        _db_session.rollback()
        return False


def update_agent_export_status(agent_id, success, error=None, result_id=None):
    """
    Update agent export status in FleetAgent table

    Called when agent exports audit results to core server.

    Args:
        agent_id: Unique agent identifier
        success: Boolean indicating export success
        error: Optional error message (only if success=False)
        result_id: Result ID from server (only if success=True)
    """
    if not _db_session:
        return False

    try:
        agent = _db_session.query(FleetAgent).filter(
            FleetAgent.agent_id == agent_id
        ).first()

        if not agent:
            return False

        agent.last_export_at = datetime.utcnow()
        agent.last_export_status = 'success' if success else 'failed'
        agent.last_export_error = error

        if not success:
            agent.failed_export_count += 1
        else:
            agent.failed_export_count = 0

        _db_session.commit()
        return True

    except Exception as e:
        logger.error(f"Failed to update agent export status: {e}")
        _db_session.rollback()
        return False


def update_agent_import_status(agent_id, success, error=None, result_id=None):
    """
    Update agent import status in FleetAgent table

    Called when core server receives results from agent.

    Args:
        agent_id: Unique agent identifier
        success: Boolean indicating import success
        error: Optional error message (only if success=False)
        result_id: Result ID from agent
    """
    if not _db_session:
        return False

    try:
        agent = _db_session.query(FleetAgent).filter(
            FleetAgent.agent_id == agent_id
        ).first()

        if not agent:
            return False

        agent.last_import_at = datetime.utcnow()
        agent.last_import_status = 'success' if success else 'failed'
        agent.last_import_error = error

        if not success:
            agent.failed_import_count += 1
        else:
            agent.failed_import_count = 0

        _db_session.commit()
        return True

    except Exception as e:
        logger.error(f"Failed to update agent import status: {e}")
        _db_session.rollback()
        return False


@agents_unified_bp.route('/api/agents/unified-health', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_unified_agents_health():
    """
    Get unified health status for all agents across all types

    Returns:
    {
        "total_agents": 15,
        "healthy": 12,
        "degraded": 2,
        "offline": 1,
        "unknown": 0,
        "agents": [
            {
                "id": 123,
                "agent_id": "agent-abc123",
                "agent_type": "lightweight",
                "name": "prod-web-01",
                "hostname": "web01.example.com",
                "os_type": "linux",
                "status": "healthy",
                "icon": "🟢",
                "message": "Connected and responding",
                "last_heartbeat": "2026-02-19T14:15:00Z",
                "last_heartbeat_error": null,
                "failed_export_count": 0,
                "failed_import_count": 1,
                "last_export_error": null,
                "last_import_error": "Timeout connecting to server"
            }
        ]
    }
    """
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        # Query all active agents
        agents = _db_session.query(FleetAgent).filter(
            FleetAgent.is_active.is_(True)
        ).all()

        policy = _load_update_policy()

        health_summary = {
            'total_agents': len(agents),
            'healthy': 0,
            'degraded': 0,
            'offline': 0,
            'unknown': 0,
            'agents': []
        }

        for agent in agents:
            status, icon, message = _get_agent_health_status(agent)

            # Update summary counts
            health_summary[status] = health_summary.get(status, 0) + 1

            agent_data = agent.to_dict()
            agent_data.update(_get_update_state(agent_data))
            agent_data.update({
                'status': status,
                'icon': icon,
                'message': message,
            })

            health_summary['agents'].append(agent_data)

        return jsonify({
            'success': True,
            'timestamp': datetime.utcnow().isoformat(),
            'update_policy': policy,
            **health_summary
        }), 200

    except Exception as e:
        logger.error(f"Failed to fetch unified agent health: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/unified-health/<agent_type_filter>', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_unified_agents_health_filtered(agent_type_filter):
    """
    Get health status for agents of a specific type

    Args:
        agent_type_filter: 'lightweight', 'managed', 'hypervisor', or 'standalone'

    Returns: Same as /api/agents/unified-health but filtered by type
    """
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    # Validate filter value
    valid_types = ['lightweight', 'managed', 'hypervisor', 'standalone']
    if agent_type_filter not in valid_types:
        return jsonify({
            'success': False,
            'error': f'Invalid agent_type. Must be one of: {", ".join(valid_types)}'
        }), 400

    try:
        # Query agents of specific type
        agents = _db_session.query(FleetAgent).filter(
            and_(
                FleetAgent.is_active.is_(True),
                FleetAgent.agent_type == agent_type_filter
            )
        ).all()

        policy = _load_update_policy()

        health_summary = {
            'agent_type_filter': agent_type_filter,
            'total_agents': len(agents),
            'healthy': 0,
            'degraded': 0,
            'offline': 0,
            'unknown': 0,
            'agents': []
        }

        for agent in agents:
            status, icon, message = _get_agent_health_status(agent)
            health_summary[status] = health_summary.get(status, 0) + 1

            agent_data = agent.to_dict()
            agent_data.update(_get_update_state(agent_data))
            agent_data.update({
                'status': status,
                'icon': icon,
                'message': message,
            })

            health_summary['agents'].append(agent_data)

        return jsonify({
            'success': True,
            'timestamp': datetime.utcnow().isoformat(),
            'update_policy': policy,
            **health_summary
        }), 200

    except Exception as e:
        logger.error(f"Failed to fetch filtered agent health: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/<agent_id>/health', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_agent_health(agent_id):
    """
    Get detailed health status for a specific agent

    Returns detailed information including:
    - Current status and diagnostics
    - Recent errors and error history
    - Export/import tracking
    - Last heartbeat details
    """
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        agent = _db_session.query(FleetAgent).filter(
            FleetAgent.agent_id == agent_id
        ).first()

        if not agent:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        status, icon, message = _get_agent_health_status(agent)

        agent_data = agent.to_dict(include_config=True)
        agent_data.update(_get_update_state(agent_data))
        agent_data.update({
            'status': status,
            'icon': icon,
            'message': message,
            'health_details': {
                'heartbeat_status': {
                    'last_heartbeat': agent.last_heartbeat.isoformat() if agent.last_heartbeat else None,
                    'time_since_heartbeat_seconds': (
                        (datetime.utcnow() - agent.last_heartbeat).total_seconds()
                        if agent.last_heartbeat else None
                    ),
                    'last_error': agent.last_heartbeat_error
                },
                'export_status': {
                    'last_export': agent.last_export_at.isoformat() if agent.last_export_at else None,
                    'last_status': agent.last_export_status,
                    'last_error': agent.last_export_error,
                    'failed_count': agent.failed_export_count
                },
                'import_status': {
                    'last_import': agent.last_import_at.isoformat() if agent.last_import_at else None,
                    'last_status': agent.last_import_status,
                    'last_error': agent.last_import_error,
                    'failed_count': agent.failed_import_count
                }
            }
        })

        return jsonify({
            'success': True,
            'agent': agent_data
        }), 200

    except Exception as e:
        logger.error(f"Failed to fetch agent health: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/stats', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_agents_stats():
    """
    Get aggregated statistics for all agents

    Returns:
    {
        "total_agents": 15,
        "active_agents": 14,
        "by_type": {
            "lightweight": 8,
            "managed": 4,
            "hypervisor": 2,
            "standalone": 1
        },
        "by_status": {
            "healthy": 12,
            "degraded": 2,
            "offline": 1,
            "unknown": 0
        },
        "by_os": {
            "linux": 10,
            "windows": 5
        },
        "export_stats": {
            "total_failed": 3,
            "agents_with_failures": 2
        },
        "import_stats": {
            "total_failed": 1,
            "agents_with_failures": 1
        }
    }
    """
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        agents = _db_session.query(FleetAgent).filter(
            FleetAgent.is_active.is_(True)
        ).all()

        stats = {
            'total_agents': len(agents),
            'active_agents': sum(1 for a in agents if a.is_active),
            'by_type': {},
            'by_status': {
                'healthy': 0,
                'degraded': 0,
                'offline': 0,
                'unknown': 0
            },
            'by_os': {},
            'export_stats': {
                'total_failed': sum(a.failed_export_count for a in agents),
                'agents_with_failures': sum(1 for a in agents if a.failed_export_count > 0)
            },
            'import_stats': {
                'total_failed': sum(a.failed_import_count for a in agents),
                'agents_with_failures': sum(1 for a in agents if a.failed_import_count > 0)
            }
        }

        # Count by type
        for agent in agents:
            agent_type = agent.agent_type
            stats['by_type'][agent_type] = stats['by_type'].get(agent_type, 0) + 1

            # Count by status
            status, _, _ = _get_agent_health_status(agent)
            stats['by_status'][status] = stats['by_status'].get(status, 0) + 1

            # Count by OS
            if agent.os_type:
                stats['by_os'][agent.os_type] = stats['by_os'].get(agent.os_type, 0) + 1

        return jsonify({
            'success': True,
            'timestamp': datetime.utcnow().isoformat(),
            'stats': stats
        }), 200

    except Exception as e:
        logger.error(f"Failed to fetch agents stats: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/<agent_id>/retry-failed', methods=['POST'])
@require_auth_and_permission('manage_servers')
def retry_failed_exports(agent_id):
    """
    Retry failed exports for a specific agent

    This endpoint:
    1. Finds the agent
    2. Resets failed_export_count to 0
    3. Returns affected audit IDs for manual retry

    Request body (optional):
    {
        "retry_type": "export" or "import" (default: "export")
    }

    Returns:
    {
        "success": true,
        "agent_id": "agent-123",
        "retry_type": "export",
        "failed_count_reset": 2,
        "next_steps": "Run audits again to retry exports or use /api/results/<result_id>/export"
    }
    """
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        data = request.get_json() or {}
        retry_type = data.get('retry_type', 'export')

        if retry_type not in ['export', 'import']:
            return jsonify({
                'success': False,
                'error': 'retry_type must be "export" or "import"'
            }), 400

        agent = _db_session.query(FleetAgent).filter(
            FleetAgent.agent_id == agent_id
        ).first()

        if not agent:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        # Reset failure counts and errors
        if retry_type == 'export':
            failed_count = agent.failed_export_count
            agent.failed_export_count = 0
            agent.last_export_error = None
        else:  # import
            failed_count = agent.failed_import_count
            agent.failed_import_count = 0
            agent.last_import_error = None

        _db_session.commit()

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'retry_type': retry_type,
            'failed_count_reset': failed_count,
            'next_steps': f'Retry {retry_type} operations for this agent'
        }), 200

    except Exception as e:
        logger.error(f"Failed to retry failed {retry_type}s: {e}")
        _db_session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/update-policy', methods=['GET', 'PUT'])
@require_auth_and_permission('manage_servers')
def manage_update_policy():
    """Get or update fleet agent auto-update policy."""
    if request.method == 'GET':
        return jsonify({
            'success': True,
            'policy': _load_update_policy(),
        }), 200

    try:
        data = request.get_json() or {}
        policy = _load_update_policy()

        allowed_rollout_modes = {'manual', 'all', 'canary'}
        if 'rollout_mode' in data and data['rollout_mode'] not in allowed_rollout_modes:
            return jsonify({
                'success': False,
                'error': f"rollout_mode must be one of: {', '.join(sorted(allowed_rollout_modes))}"
            }), 400

        for key in DEFAULT_AGENT_UPDATE_POLICY:
            if key in data:
                policy[key] = data[key]

        policy['canary_limit'] = max(1, int(policy.get('canary_limit', 5)))
        policy['cooldown_minutes'] = max(1, int(policy.get('cooldown_minutes', 60)))
        policy['max_attempts'] = max(1, int(policy.get('max_attempts', 3)))

        _save_update_policy(policy)

        return jsonify({
            'success': True,
            'policy': policy,
        }), 200
    except Exception as e:
        logger.error(f"Failed to update agent update policy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/<agent_id>/enqueue-self-update', methods=['POST'])
@require_auth_and_permission('manage_servers')
def enqueue_self_update(agent_id):
    """Queue a fleet agent self-update command for one agent."""
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        data = request.get_json() or {}
        force = bool(data.get('force', False))

        requested_by = 'admin'
        try:
            from flask_login import current_user
            if current_user and current_user.is_authenticated:
                requested_by = current_user.username
        except Exception as user_err:
            logger.debug(f"Could not resolve current user for self-update enqueue: {user_err}")

        queued, message, command = _enqueue_self_update(
            agent_id=agent_id,
            trigger='manual_agent',
            force=force,
            requested_by=requested_by,
        )

        if not queued:
            return jsonify({
                'success': False,
                'agent_id': agent_id,
                'message': message,
                'existing_command': command,
            }), 409

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'message': message,
            'command': command,
        }), 200
    except Exception as e:
        logger.error(f"Failed to enqueue self update for {agent_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@agents_unified_bp.route('/api/agents/updates/enqueue-drifted', methods=['POST'])
@require_auth_and_permission('manage_servers')
def enqueue_drifted_updates():
    """Queue self_update for fleet agents with version drift based on rollout policy."""
    if not DATABASE_AVAILABLE or not _db_session:
        return jsonify({'success': False, 'error': 'Database not available'}), 500

    try:
        data = request.get_json() or {}
        force = bool(data.get('force', False))

        policy = _load_update_policy()
        rollout_mode = policy.get('rollout_mode', 'manual')
        canary_limit = max(1, int(policy.get('canary_limit', 5)))

        candidates = _db_session.query(FleetAgent).filter(
            and_(
                FleetAgent.is_active.is_(True),
                FleetAgent.agent_type == 'managed'
            )
        ).all()

        drifted = []
        for candidate in candidates:
            state = _get_update_state(candidate.to_dict())
            if state.get('version_drift') and state.get('target_is_newer', True):
                drifted.append(candidate)

        if rollout_mode == 'manual':
            max_to_queue = int(data.get('limit', canary_limit))
        elif rollout_mode == 'canary':
            max_to_queue = canary_limit
        else:
            max_to_queue = len(drifted)

        selected = sorted(
            drifted,
            key=lambda a: a.last_heartbeat or datetime.min,
            reverse=True,
        )[:max_to_queue]

        requested_by = 'admin'
        try:
            from flask_login import current_user
            if current_user and current_user.is_authenticated:
                requested_by = current_user.username
        except Exception as user_err:
            logger.debug(f"Could not resolve current user for drift enqueue: {user_err}")

        queued_count = 0
        skipped = []
        queued_agents = []

        for candidate in selected:
            queued, message, command = _enqueue_self_update(
                agent_id=candidate.agent_id,
                trigger='bulk_drift',
                force=force,
                requested_by=requested_by,
            )

            if queued:
                queued_count += 1
                queued_agents.append({
                    'agent_id': candidate.agent_id,
                    'command_id': command.get('id') if command else None,
                })
            else:
                skipped.append({'agent_id': candidate.agent_id, 'reason': message})

        return jsonify({
            'success': True,
            'rollout_mode': rollout_mode,
            'drifted_total': len(drifted),
            'evaluated': len(selected),
            'queued': queued_count,
            'queued_agents': queued_agents,
            'skipped': skipped,
        }), 200
    except Exception as e:
        logger.error(f"Failed to enqueue drifted managed updates: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
