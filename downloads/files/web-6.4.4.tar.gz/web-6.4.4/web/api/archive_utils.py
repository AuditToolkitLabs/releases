"""Helpers for building downloadable archives safely.

These helpers avoid packaging runtime-only special files such as Unix sockets
(`gunicorn.ctl`), FIFOs, or other non-regular filesystem entries that may exist
inside a live installation tree.
"""

from __future__ import annotations

import logging
import os
import tarfile
import zipfile
from pathlib import Path
from typing import Iterator

logger = logging.getLogger(__name__)

_SKIP_DIR_NAMES = {
    '__pycache__',
    'node_modules',
}


def is_archiveable_file(file_path: str | os.PathLike[str]) -> bool:
    """Return True when `file_path` is a regular file suitable for packaging."""
    try:
        return os.path.isfile(file_path)
    except OSError as exc:
        logger.warning(f"Skipping unreadable archive entry {file_path}: {exc}")
        return False


def iter_archiveable_files(src_dir: str | os.PathLike[str]) -> Iterator[tuple[str, str]]:
    """Yield `(absolute_path, relative_path)` pairs for package-safe files."""
    src_dir = os.fspath(src_dir)
    if not os.path.exists(src_dir):
        return

    for root, dirs, files in os.walk(src_dir):
        dirs[:] = [
            directory
            for directory in dirs
            if not directory.startswith('.') and directory not in _SKIP_DIR_NAMES
        ]

        for filename in files:
            if filename.startswith('.'):
                continue

            file_path = os.path.join(root, filename)
            if not is_archiveable_file(file_path):
                logger.debug(f"Skipping non-regular archive entry: {file_path}")
                continue

            yield file_path, os.path.relpath(file_path, src_dir)


def _build_archive_path(arcname: str | os.PathLike[str], rel_path: str, *, windows_paths: bool = False) -> str:
    base = str(arcname).strip('/\\')
    rel = str(rel_path).replace('\\', '/').lstrip('/')
    joined = f"{base}/{rel}" if base else rel
    return joined.replace('/', '\\') if windows_paths else joined


def add_directory_to_zip(
    archive: zipfile.ZipFile,
    src_dir: str | os.PathLike[str],
    arcname: str | os.PathLike[str],
    *,
    windows_paths: bool = False,
) -> None:
    """Add a directory tree to a ZIP archive, skipping non-regular files."""
    for file_path, rel_path in iter_archiveable_files(src_dir):
        try:
            archive.write(
                file_path,
                arcname=_build_archive_path(arcname, rel_path, windows_paths=windows_paths)
            )
        except OSError as exc:
            logger.warning(f"Skipping archive entry after write failure {file_path}: {exc}")


def add_directory_to_tar(
    archive: tarfile.TarFile,
    src_dir: str | os.PathLike[str],
    arcname: str | os.PathLike[str],
) -> None:
    """Add a directory tree to a TAR archive, skipping non-regular files."""
    for file_path, rel_path in iter_archiveable_files(src_dir):
        try:
            archive.add(file_path, arcname=_build_archive_path(arcname, rel_path))
        except OSError as exc:
            logger.warning(f"Skipping archive entry after write failure {file_path}: {exc}")
