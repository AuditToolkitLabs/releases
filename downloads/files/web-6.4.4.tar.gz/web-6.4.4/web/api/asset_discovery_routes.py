"""
Asset Discovery Integration Routes

Provides integration between the main Security Audit Toolkit web interface
and the Asset Discovery & Vulnerability Management tool.

This module:
- Embeds the Asset Discovery dashboard in the main UI
- Proxies API requests to the asset-discovery service
- Provides unified authentication and access control (Flask-Login)
- Syncs server inventory between systems

The asset-discovery tool can run:
1. Embedded mode: Proxied through main web app (default)
2. Standalone mode: Direct access at its own port (8080)

Author: Security Audit Toolkit Team
"""

import os
import logging
import secrets
from datetime import datetime, timedelta
from urllib.parse import urlparse, urlunparse
from flask import Blueprint, jsonify, request, render_template_string, Response, redirect, url_for

# Try to import requests for API proxy
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Import logging
try:
    from config import logger
except ImportError:
    logger = logging.getLogger(__name__)

try:
    from config import get_db_session
    from models.user import User
    DB_LOOKUP_AVAILABLE = True
except ImportError:
    get_db_session = lambda: None
    User = None
    DB_LOOKUP_AVAILABLE = False

# Import Flask-Login for authentication
try:
    from flask_login import login_required, current_user
    from auth_login import is_authenticated
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    FLASK_LOGIN_AVAILABLE = False
    login_required = lambda f: f
    current_user = None

    def is_authenticated():
        return True

# Import disclaimer version for liability check
try:
    from api.auth_routes import DISCLAIMER_VERSION
except ImportError:
    from version_info import get_toolkit_version
    DISCLAIMER_VERSION = get_toolkit_version()

# Import feature licensing (optional)
try:
    from web.services_pkg.services.feature_licensing import Feature, get_feature_service
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    Feature = None

    def get_feature_service():
        return None


def check_disclaimer_accepted():
    """
    Check if user has accepted the current disclaimer version.
    Returns redirect URL if disclaimer not accepted, None otherwise.
    """
    if not FLASK_LOGIN_AVAILABLE or not current_user:
        return None

    # Enforce password change before disclaimer acceptance.
    if getattr(current_user, 'must_change_password', False):
        return None

    # Check disclaimer status from a fresh DB read to avoid stale session state.
    disclaimer_accepted = getattr(current_user, 'disclaimer_accepted_at', None)
    disclaimer_version = str(getattr(current_user, 'disclaimer_version', '') or '').strip()
    expected_version = str(DISCLAIMER_VERSION or '').strip()

    db = None
    db_session_factory = get_db_session
    user_model = User

    if (not db_session_factory or not user_model) and getattr(current_user, 'id', None):
        try:
            from config import get_db_session as dynamic_get_db_session
            from models.user import User as DynamicUser
            db_session_factory = dynamic_get_db_session
            user_model = DynamicUser
        except Exception:
            db_session_factory = None
            user_model = None

    if db_session_factory and user_model and getattr(current_user, 'id', None):
        db = db_session_factory()
        if db:
            try:
                fresh_user = db.query(user_model).filter(user_model.id == current_user.id).first()
                if fresh_user:
                    disclaimer_accepted = fresh_user.disclaimer_accepted_at
                    disclaimer_version = str(fresh_user.disclaimer_version or '').strip()

                    # Keep session principal consistent for downstream checks.
                    try:
                        current_user.disclaimer_accepted_at = disclaimer_accepted
                        current_user.disclaimer_version = disclaimer_version
                    except Exception as sync_error:
                        logger.debug(
                            "Unable to sync disclaimer fields to current session principal: %s",
                            sync_error,
                        )
            finally:
                db.close()

    if not disclaimer_accepted or disclaimer_version != expected_version:
        return url_for('auth.accept_disclaimer', next=request.url)

    return None


# Import auth decorators (for RBAC)
try:
    from auth_core import require_auth_and_permission, require_role, conditional_limit
    from logging_utils import log_audit
    from api.upload_rate_limits import get_asset_discovery_upload_limit
except ImportError:
    # Fallback decorator that allows all
    def require_auth_and_permission(permission):
        def decorator(f):
            return f
        return decorator

    def require_role(role):
        def decorator(f):
            return f
        return decorator

    def conditional_limit(_limit):
        def decorator(f):
            return f
        return decorator

    def get_asset_discovery_upload_limit():
        return "200 per hour"

    def log_audit(*args, **kwargs):
        pass

# Create blueprint
asset_discovery_bp = Blueprint('asset_discovery', __name__)

# Configuration
# Internal URL for API proxy (service-to-service communication)
ASSET_DISCOVERY_PORT = os.getenv('ASSET_DISCOVERY_PORT') or os.getenv('DISCOVERY_PORT') or '18080'
ASSET_DISCOVERY_URL = os.getenv('ASSET_DISCOVERY_URL', f'http://127.0.0.1:{ASSET_DISCOVERY_PORT}')
# External URL for browser access (direct links). If unset, resolve from request host.
ASSET_DISCOVERY_EXTERNAL_URL = os.getenv('ASSET_DISCOVERY_EXTERNAL_URL', '')
ASSET_DISCOVERY_ENABLED = os.getenv('ASSET_DISCOVERY_ENABLED', 'true').lower() == 'true'
DISCOVERY_PROXY_PATH = '/api/asset-discovery/'


def _normalize_discovery_path(path: str) -> str:
    normalized_path = path if path.startswith('/') else f'/{path}'
    if normalized_path in {
        '/discovery',
        '/discovery/',
        '/api/asset-discovery',
        '/api/asset-discovery/',
    }:
        return DISCOVERY_PROXY_PATH
    return normalized_path


def _build_request_discovery_url(
    path: str = '/discovery/',
    query: str = '',
    fragment: str = '',
    port: int = None,
    scheme_override: str = None,
) -> str:
    request_host = request.host
    request_hostname = request_host.split(':', 1)[0]
    request_scheme = (request.scheme or 'http').lower()
    scheme = (scheme_override or request_scheme).lower()
    normalized_path = _normalize_discovery_path(path)

    if port is not None:
        netloc = f"{request_hostname}:{port}"
    elif scheme_override and scheme != request_scheme and ':' in request_host:
        # Avoid carrying internal backend ports (for example :5000) across
        # scheme normalization to externally-facing HTTPS URLs.
        netloc = request_hostname
    else:
        netloc = request_host

    return urlunparse((scheme, netloc, normalized_path, '', query, fragment))


def _resolve_asset_discovery_external_url() -> str:
    """
    Resolve browser-facing Asset Discovery URL.

    If ASSET_DISCOVERY_EXTERNAL_URL is configured as localhost/loopback,
    rewrite it to the current request host so remote/browser clients don't
    get redirected to their own localhost.
    """
    external_url = (ASSET_DISCOVERY_EXTERNAL_URL or '').strip()
    if not external_url:
        return _build_request_discovery_url(DISCOVERY_PROXY_PATH)

    try:
        parsed = urlparse(external_url)
    except Exception:
        return external_url

    if not parsed.scheme or not parsed.netloc:
        return external_url

    host = (parsed.hostname or '').lower()
    if host not in {'localhost', '127.0.0.1', '::1'}:
        return external_url

    parsed_path = parsed.path or '/'

    # Explicit localhost:PORT should map to current host with the same port
    # so browser clients resolve correctly (instead of their own localhost).
    if parsed_path in {'', '/'}:
        return _build_request_discovery_url(
            '/',
            parsed.query or '',
            parsed.fragment or '',
            port=parsed.port,
            scheme_override=parsed.scheme,
        )

    # Keep canonical discovery proxy path with trailing slash.
    if parsed_path in {
        '/discovery',
        '/discovery/',
        '/api/asset-discovery',
        '/api/asset-discovery/',
    }:
        return _build_request_discovery_url(
            DISCOVERY_PROXY_PATH,
            parsed.query or '',
            parsed.fragment or '',
            port=parsed.port,
            scheme_override=parsed.scheme,
        )

    return _build_request_discovery_url(
        parsed_path,
        parsed.query or '',
        parsed.fragment or '',
        port=parsed.port,
        scheme_override=parsed.scheme,
    )


# ==============================================================================
# Helper Functions
# ==============================================================================

def _is_truthy(value: str) -> bool:
    return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on'}


def _feature_unavailable_response(feature):
    """Return standardized 403 payload when a licensed feature is unavailable."""
    if not FEATURE_LICENSING_AVAILABLE:
        return None

    try:
        user_id = None
        if FLASK_LOGIN_AVAILABLE and current_user and getattr(current_user, 'is_authenticated', False):
            user_id = str(current_user.id)

        service = get_feature_service()
        status = service.is_feature_available(feature, user_id)
    except Exception as exc:
        logger.warning(f"Feature licensing check failed for {getattr(feature, 'value', feature)}: {exc}")
        return None

    if status.get('available'):
        return None

    return jsonify({
        'error': 'Feature not available',
        'feature': feature.value,
        'reason': status.get('reason', 'Feature is not enabled for this license tier'),
        'code': 'FEATURE_UNAVAILABLE',
        'trial_eligible': status.get('trial_eligible', False),
        'upgrade_tier': status.get('upgrade_tier'),
    }), 403


def _should_redirect_feature_gate_to_pricing() -> bool:
    """Return True for direct browser navigations that should show upgrade UX.

    Keep API/AJAX callers on JSON payloads, but route normal document
    navigations to a user-facing pricing page.
    """
    if request.headers.get('X-Requested-With', '').lower() == 'xmlhttprequest':
        return False

    sec_fetch_dest = (request.headers.get('Sec-Fetch-Dest') or '').lower()
    sec_fetch_mode = (request.headers.get('Sec-Fetch-Mode') or '').lower()
    if sec_fetch_dest == 'document' or sec_fetch_mode == 'navigate':
        return True

    best = request.accept_mimetypes.best or ''
    return best.startswith('text/html')

def _get_asset_discovery_api_key() -> str:
    """
    Get Asset Discovery API key from keystore or environment.

    Priority:
    1. Primary key from encrypted keystore ('asset_discovery', 'primary')
    2. Any asset_discovery key from keystore
    3. Environment variable ASSET_DISCOVERY_API_KEY

    Returns:
        API key string or None if not configured
    """
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        # Try to get primary key
        api_key = keystore.get_key('asset_discovery', 'primary')
        if api_key:
            return api_key

        # Try to get any asset_discovery key
        keys = keystore.list_keys('asset_discovery')
        if keys:
            key_id = keys[0].get('key_id')
            api_key = keystore.get_key('asset_discovery', key_id)
            if api_key:
                return api_key

    except Exception as e:
        logger.debug(f"Could not retrieve key from keystore: {e}")

    # Fallback to environment variable
    return os.getenv('ASSET_DISCOVERY_API_KEY')


def _get_internal_service_token() -> str:
    """
    Get Internal Service Token for trusted web<->asset-discovery communication.

    This token allows bypassing API key and rate limiting for inter-service calls.

    Returns:
        Internal service token string or None if not configured
    """
    return os.getenv('INTERNAL_SERVICE_TOKEN')


def _is_valid_asset_discovery_api_key(api_key: str) -> bool:
    """Validate incoming key for Asset Discovery integration endpoints.

    Accepts, in order:
    1. Any key in encrypted keystore under ``asset_discovery``
    2. System API key from auth core (for bootstrap/backward compatibility)
    3. ``ASSET_DISCOVERY_API_KEY`` environment fallback
    """
    if not api_key:
        return False

    normalized_key = str(api_key).strip()
    if not normalized_key:
        return False

    try:
        from keystore import get_keystore
        keystore = get_keystore()

        keys = keystore.list_keys('asset_discovery')
        for key_info in keys:
            key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', key_id)
            if stored_value and secrets.compare_digest(str(stored_value).strip(), normalized_key):
                return True
    except Exception as e:
        logger.error(f"Asset Discovery API key validation failed: {e}")

    # Backward compatibility: allow core system API key for integration calls.
    try:
        from auth_core import get_api_key_manager
        if get_api_key_manager().validate_key(normalized_key):
            return True
    except Exception as e:
        logger.debug(f"System API key fallback validation unavailable: {e}")

    env_key = os.getenv('ASSET_DISCOVERY_API_KEY')
    if env_key and secrets.compare_digest(str(env_key).strip(), normalized_key):
        return True

    return False


def _is_trusted_internal_request() -> bool:
    """Validate trusted inter-service call via INTERNAL_SERVICE_TOKEN."""
    provided = request.headers.get('X-Internal-Service-Token')
    expected = _get_internal_service_token()
    if not provided or not expected:
        return False

    try:
        return secrets.compare_digest(str(provided).strip(), str(expected).strip())
    except Exception:
        return False


def _get_discovery_results_for_sync(discovery_manager, limit: int = 1000):
    """
    Return discovery results using the best available DiscoveryManager API.

    Compatibility order:
    1) get_all_results(limit=...)
    2) get_all_summaries()
    3) []
    """
    if hasattr(discovery_manager, 'get_all_results'):
        return discovery_manager.get_all_results(limit=limit)

    if hasattr(discovery_manager, 'get_all_summaries'):
        return discovery_manager.get_all_summaries()

    return []


def _get_asset_discovery_retention_policy():
    """Return retention controls for Asset Discovery fallback scan artifacts."""
    try:
        from security_settings import get_security_setting
        retention_days = int(get_security_setting('result_retention', 90))
        max_records = int(get_security_setting('result_retention_max_records', 100000))
    except Exception:
        retention_days = int(os.getenv('RESULT_RETENTION_DAYS', '90'))
        max_records = int(os.getenv('RESULT_RETENTION_MAX_RECORDS', '100000'))

    retention_days = max(7, retention_days)
    if max_records < 0:
        max_records = 100000
    return retention_days, max_records


def _cleanup_vulnerability_fallback_storage(vuln_dir: str, retention_days: int, max_records: int):
    """Prune fallback vulnerability files by age and by max record count."""
    try:
        files = []
        for filename in os.listdir(vuln_dir):
            if not filename.endswith('.json'):
                continue
            full_path = os.path.join(vuln_dir, filename)
            try:
                mtime = os.path.getmtime(full_path)
            except OSError:
                continue
            files.append((full_path, mtime))

        if not files:
            return {'deleted_by_age': 0, 'deleted_by_count': 0}

        deleted_by_age = 0
        deleted_by_count = 0
        cutoff_ts = (datetime.utcnow() - timedelta(days=retention_days)).timestamp()

        for full_path, mtime in list(files):
            if mtime < cutoff_ts:
                try:
                    os.remove(full_path)
                    deleted_by_age += 1
                except OSError:
                    continue

        files = [entry for entry in files if os.path.exists(entry[0])]
        files.sort(key=lambda item: item[1], reverse=True)
        if max_records > 0 and len(files) > max_records:
            overflow = files[max_records:]
            for full_path, _mtime in overflow:
                try:
                    os.remove(full_path)
                    deleted_by_count += 1
                except OSError:
                    continue

        return {
            'deleted_by_age': deleted_by_age,
            'deleted_by_count': deleted_by_count
        }
    except Exception:
        return {'deleted_by_age': 0, 'deleted_by_count': 0}


# Embedded dashboard HTML template - matches Security Audit Toolkit styling
EMBEDDED_DASHBOARD = '''
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Discovery - Security Audit Toolkit</title>
    <link rel="stylesheet" href="/static/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f1a;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1f2937;
            --border-color: #0f3460;
            --text-primary: #e5e5e5;
            --text-secondary: #a5a5a5;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --accent-red: #ef4444;
            --accent-yellow: #f59e0b;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
        }

        .asset-discovery-wrapper {
            display: flex;
            flex-direction: column;
            height: 100vh;
            background: var(--bg-primary);
        }

        /* Header matching main audit toolkit */
        .asset-discovery-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--bg-tertiary) 100%);
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .header-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-brand-icon {
            font-size: 1.75rem;
        }

        .header-brand h1 {
            font-size: 1.25rem;
            margin: 0;
            color: var(--text-primary);
            font-weight: 600;
        }

        .header-brand .brand-subtitle {
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin-top: 0.125rem;
        }

        /* Navigation */
        .asset-discovery-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }

        .nav-link:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--text-primary);
        }

        .nav-link.active {
            background: var(--accent-blue);
            color: white;
        }

        /* User info */
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding-left: 1rem;
            border-left: 1px solid var(--border-color);
            margin-left: 0.5rem;
        }

        .user-badge {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.375rem 0.75rem;
            background: rgba(59, 130, 246, 0.1);
            border-radius: 20px;
            font-size: 0.8rem;
        }

        .user-badge-icon {
            width: 24px;
            height: 24px;
            background: var(--accent-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            color: white;
        }

        .logout-btn {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            transition: all 0.2s;
            font-size: 0.8rem;
            border: 1px solid var(--border-color);
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.1);
            border-color: var(--accent-red);
            color: var(--accent-red);
        }

        /* Main content iframe */
        .asset-discovery-frame {
            flex: 1;
            border: none;
            width: 100%;
            background: var(--bg-primary);
        }

        /* Error state */
        .asset-discovery-error {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            text-align: center;
            color: var(--text-secondary);
            padding: 2rem;
        }

        .error-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }

        .asset-discovery-error h2 {
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            font-size: 1.5rem;
        }

        .asset-discovery-error p {
            margin-bottom: 0.5rem;
        }

        .error-url {
            font-family: monospace;
            background: var(--bg-card);
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.875rem;
        }

        .error-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .btn {
            padding: 0.625rem 1.25rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.875rem;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--accent-blue);
            color: white;
        }

        .btn-primary:hover {
            background: #2563eb;
        }

        .btn-secondary {
            background: var(--bg-card);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--bg-tertiary);
        }

        .help-box {
            margin-top: 2rem;
            padding: 1.5rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            max-width: 600px;
            text-align: left;
        }

        .help-box h3 {
            color: var(--text-primary);
            margin-bottom: 1rem;
            font-size: 1rem;
        }

        .help-box pre {
            background: var(--bg-primary);
            padding: 1rem;
            border-radius: 6px;
            overflow-x: auto;
            font-size: 0.8rem;
            color: var(--accent-green);
        }
    </style>
</head>
<body>
    <div class="asset-discovery-wrapper">
        <header class="asset-discovery-header">
            <div class="header-brand">
                <span class="header-brand-icon">🔍</span>
                <div>
                    <h1>Asset Discovery &amp; Vulnerability Management</h1>
                    <div class="brand-subtitle">Security Audit Toolkit Module</div>
                </div>
            </div>
            <nav class="asset-discovery-nav">
                <a href="/" class="nav-link" target="_top">🏠 Home</a>
                <a href="/overview" class="nav-link" target="_top">📖 Overview</a>
                <a href="/dashboard" class="nav-link" target="_top">📊 Dashboard</a>
                <a href="/deploy" class="nav-link" target="_top">🚀 Support Tools</a>
                <a href="/asset-discovery" class="nav-link active" target="_top">🔍 Asset Discovery</a>
                <a href="/script-studio" class="nav-link" target="_top">📝 Script Studio</a>
                <a href="/console" class="nav-link" target="_top">💻 Console</a>
                {% if current_user %}
                <div class="user-info">
                    <div class="user-badge">
                        <span class="user-badge-icon">{{ (current_user.username or 'U')[0]|upper }}</span>
                        <span>{{ current_user.username or 'User' }}</span>
                        {% if current_user.role %}
                        <span style="color: var(--accent-blue);">({{ current_user.role }})</span>
                        {% endif %}
                    </div>
                    <a href="/auth/logout" class="logout-btn">Logout</a>
                </div>
                {% endif %}
            </nav>
        </header>
        {% if service_available %}
        <iframe
            src="{{ iframe_url }}"
            class="asset-discovery-frame"
            title="Asset Discovery Dashboard"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
        ></iframe>
        {% else %}
        <div class="asset-discovery-error">
            <div class="error-icon">⚠️</div>
            <h2>Asset Discovery Service Unavailable</h2>
            <p>The Asset Discovery service is not running or not accessible.</p>
            <p>Expected URL: <code class="error-url">{{ standalone_url }}</code></p>

            <div class="error-actions">
                <a href="/" class="btn btn-secondary">← Back to Home</a>
                <button onclick="location.reload()" class="btn btn-primary">🔄 Retry Connection</button>
            </div>

            <div class="help-box">
                <h3>📋 How to start the Asset Discovery service:</h3>
                <pre># Option 1: From the repository root
cd tools/asset-discovery
python -m src.app

# Option 2: Using Docker
docker-compose -f tools/asset-discovery/docker-compose.yml up

# The service will be available at http://localhost:8080</pre>
            </div>
        </div>
        {% endif %}
    </div>
</body>
</html>
'''


def check_service_available():
    """Check if the asset discovery service is running"""
    return _resolve_asset_discovery_service_url() is not None


def _resolve_asset_discovery_service_url():
    """Resolve the live asset discovery base URL, preferring configured value."""
    if not REQUESTS_AVAILABLE:
        return None

    health_urls = [f"{ASSET_DISCOVERY_URL.rstrip('/')}/health"]
    for fallback_url in ('http://127.0.0.1:18080/health', 'http://127.0.0.1:8080/health'):
        if fallback_url not in health_urls:
            health_urls.append(fallback_url)

    for health_url in health_urls:
        try:
            response = requests.get(health_url, timeout=2)
            if response.status_code == 200:
                return health_url[:-7]
        except Exception as health_error:
            logger.debug("Asset Discovery health probe failed for %s: %s", health_url, health_error)
            continue

    return None


@asset_discovery_bp.route('')
@asset_discovery_bp.route('/')
def asset_discovery_dashboard():
    """
    Redirect to the asset discovery dashboard - requires authentication.

    Access control (same pattern as /console):
    1. User must be logged in (via Flask-Login)
    2. User must have accepted current disclaimer version
    3. User must not have pending password change requirement

    Note: We redirect directly to Asset Discovery instead of embedding in an iframe
    to avoid cross-origin content blocking issues in browsers.
    """
    # Check if user is authenticated (same pattern as console route)
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        logger.warning(f"Unauthenticated asset-discovery access attempt from {request.remote_addr}")
        return redirect(url_for('auth.login', next=request.url))

    # Check if disclaimer needs to be accepted (liability protection)
    disclaimer_redirect = check_disclaimer_accepted()
    if disclaimer_redirect:
        logger.info("User redirected to accept disclaimer for asset-discovery access")
        return redirect(disclaimer_redirect)

    # Check if user must change password
    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'must_change_password'):
        if current_user.must_change_password:
            logger.info(f"User {current_user.username} redirected to change password")
            return redirect(url_for('auth.change_password', next=request.url))

    # Log access
    user_info = 'anonymous'
    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'username'):
        user_info = current_user.username
    logger.info(f"Asset Discovery accessed by {user_info} from {request.remote_addr}")

    external_url = _resolve_asset_discovery_external_url()

    # Check if service is available - if not, show error page
    if not check_service_available():
        return render_template_string(
            EMBEDDED_DASHBOARD,
            service_available=False,
            iframe_url=external_url,
            standalone_url=external_url,
            current_user=current_user if FLASK_LOGIN_AVAILABLE else None
        )

    # Keep Asset Discovery inside the Toolkit wrapper so users retain
    # the original top navigation to Console and other pages.
    return render_template_string(
        EMBEDDED_DASHBOARD,
        service_available=True,
        iframe_url=external_url,
        standalone_url=external_url,
        current_user=current_user if FLASK_LOGIN_AVAILABLE else None
    )


@asset_discovery_bp.route('/status')
def asset_discovery_status():
    """
    Check asset discovery service status - requires authentication.

    Returns JSON with service availability and health info.
    """
    # Check if user is authenticated for API endpoints
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        return jsonify({
            'success': False,
            'error': 'Authentication required',
            'code': 401
        }), 401

    available = check_service_available()

    status = {
        'service': 'asset-discovery',
        'enabled': ASSET_DISCOVERY_ENABLED,
        'available': available,
        'url': _resolve_asset_discovery_external_url()
    }

    resolved_service_url = _resolve_asset_discovery_service_url()

    if available and REQUESTS_AVAILABLE and resolved_service_url:
        try:
            response = requests.get(f"{resolved_service_url}/health", timeout=5)
            status['health'] = response.json()
        except Exception as e:
            status['health'] = {'error': str(e)}

    return jsonify(status)


@asset_discovery_bp.route('/software-report/latest')
def asset_discovery_latest_software_report():
    """Open the latest completed Asset Discovery software update report via the main web UI."""
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        logger.warning(f"Unauthenticated software-report access attempt from {request.remote_addr}")
        return redirect(url_for('auth.login', next=request.url))

    disclaimer_redirect = check_disclaimer_accepted()
    if disclaimer_redirect:
        return redirect(disclaimer_redirect)

    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'must_change_password'):
        if current_user.must_change_password:
            return redirect(url_for('auth.change_password', next=request.url))

    if FEATURE_LICENSING_AVAILABLE:
        feature_denied = _feature_unavailable_response(Feature.ADVANCED_CVE_REPORTING)
        if feature_denied:
            if _should_redirect_feature_gate_to_pricing():
                return redirect(url_for('pricing_alias', feature='advanced_cve_reporting', tier='business'))
            return feature_denied

    if not REQUESTS_AVAILABLE:
        return jsonify({'error': 'requests module not available'}), 503

    if not ASSET_DISCOVERY_ENABLED:
        return jsonify({'error': 'Asset discovery integration is disabled'}), 503

    try:
        api_key = _get_asset_discovery_api_key()
        internal_token = _get_internal_service_token()

        headers = {'Content-Type': 'application/json'}
        if internal_token:
            headers['X-Internal-Service-Token'] = internal_token
        if api_key:
            headers['X-API-Key'] = api_key

        response = requests.get(
            f"{ASSET_DISCOVERY_URL}/api/v1/scans",
            headers=headers,
            params={'status': 'completed', 'per_page': 1, 'page': 1},
            timeout=15,
        )

        if response.status_code != 200:
            return jsonify({'error': 'Unable to fetch scans from asset discovery'}), 502

        scans_payload = response.json() if response.content else {}
        scans = scans_payload.get('scans') if isinstance(scans_payload, dict) else []
        if not scans:
            return redirect(url_for('asset_discovery.asset_discovery_dashboard'))

        latest_scan_id = scans[0].get('id')
        if not latest_scan_id:
            return redirect(url_for('asset_discovery.asset_discovery_dashboard'))

        return redirect(url_for(
            'asset_discovery.proxy_api',
            path=f'scans/{latest_scan_id}/report/software-updates',
            format='html'
        ))
    except requests.exceptions.Timeout:
        return jsonify({'error': 'Request to asset discovery service timed out'}), 504
    except requests.exceptions.ConnectionError:
        return jsonify({'error': 'Asset discovery service unavailable'}), 503
    except Exception as exc:
        logger.error(f"Error opening latest software report: {exc}")
        return jsonify({'error': 'Internal error opening software report'}), 500


@asset_discovery_bp.route('/software-report/<int:scan_id>')
def asset_discovery_scan_software_report(scan_id: int):
    """Open a specific scan software update report via the authenticated proxy."""
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    disclaimer_redirect = check_disclaimer_accepted()
    if disclaimer_redirect:
        return redirect(disclaimer_redirect)

    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'must_change_password'):
        if current_user.must_change_password:
            return redirect(url_for('auth.change_password', next=request.url))

    if FEATURE_LICENSING_AVAILABLE:
        feature_denied = _feature_unavailable_response(Feature.ADVANCED_CVE_REPORTING)
        if feature_denied:
            if _should_redirect_feature_gate_to_pricing():
                return redirect(url_for('pricing_alias', feature='advanced_cve_reporting', tier='business'))
            return feature_denied

    return redirect(url_for(
        'asset_discovery.proxy_api',
        path=f'scans/{scan_id}/report/software-updates',
        format='html'
    ))


# =============================================================================
# API Proxy Routes - Forward requests to asset-discovery service
# =============================================================================

@asset_discovery_bp.route('/api/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE', 'PATCH'])
def proxy_api(path):
    """
    Proxy API requests to the asset-discovery service - requires authentication.

    This allows the main web app to integrate with asset-discovery
    without CORS issues and with unified authentication.
    """
    # Check if user is authenticated for API endpoints
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        return jsonify({
            'success': False,
            'error': 'Authentication required',
            'code': 401
        }), 401

    normalized_path = str(path or '').strip().lstrip('/')
    normalized_lower = normalized_path.lower()

    if normalized_lower.startswith('api/v1/'):
        normalized_path = normalized_path[7:]
    elif normalized_lower.startswith('v1/'):
        normalized_path = normalized_path[3:]

    normalized_path = normalized_path.lstrip('/')
    lower_path = normalized_path.lower()

    if not normalized_path:
        return jsonify({'error': 'API path is required'}), 400

    if FEATURE_LICENSING_AVAILABLE:
        if lower_path == 'scans' and _is_truthy(request.args.get('direct_api_only')):
            feature_denied = _feature_unavailable_response(Feature.DIRECT_API_SCANS)
            if feature_denied:
                return feature_denied

        if lower_path.startswith('vulnerabilities') or (
            lower_path.startswith('scans/') and lower_path.endswith('/report/software-updates')
        ):
            feature_denied = _feature_unavailable_response(Feature.ADVANCED_CVE_REPORTING)
            if feature_denied:
                return feature_denied

    if not REQUESTS_AVAILABLE:
        return jsonify({'error': 'requests module not available'}), 503

    if not ASSET_DISCOVERY_ENABLED:
        return jsonify({'error': 'Asset discovery integration is disabled'}), 503

    # Build target URL
    resolved_service_url = _resolve_asset_discovery_service_url()
    service_url = resolved_service_url or ASSET_DISCOVERY_URL
    target_url = f"{service_url}/api/v1/{normalized_path}"

    # Forward the request
    try:
        # Get API key from keystore (primary) or environment (fallback)
        api_key = _get_asset_discovery_api_key()
        internal_token = _get_internal_service_token()

        # Prepare headers (forward relevant ones + auth)
        headers = {
            'Content-Type': request.content_type or 'application/json',
        }

        # Add internal service token for trusted inter-service communication
        # This bypasses rate limiting and API key requirements
        if internal_token:
            headers['X-Internal-Service-Token'] = internal_token

        # Add API key if configured (as fallback)
        if api_key:
            headers['X-API-Key'] = api_key

        # Make the proxied request
        response = requests.request(
            method=request.method,
            url=target_url,
            headers=headers,
            params=request.args,
            data=request.get_data(),
            timeout=30
        )

        # Return the response
        return Response(
            response.content,
            status=response.status_code,
            content_type=response.headers.get('Content-Type', 'application/json')
        )
    except requests.exceptions.ConnectionError:
        return jsonify({
            'error': 'Asset discovery service unavailable',
            'service_url': service_url
        }), 503
    except requests.exceptions.Timeout:
        return jsonify({'error': 'Request to asset discovery service timed out'}), 504
    except Exception as e:
        logger.error(f"Error proxying to asset-discovery: {e}")
        return jsonify({'error': 'Internal proxy error'}), 500


# =============================================================================
# Server Sync Routes - Sync servers between audit toolkit and asset-discovery
# =============================================================================

@asset_discovery_bp.route('/sync/servers', methods=['POST'])
@require_auth_and_permission('admin')
@require_role('Admin')
def sync_servers_to_asset_discovery():
    """
    Sync server inventory from audit toolkit to asset-discovery (requires Admin+ role)

    This creates assets in asset-discovery for each server configured
    in the main audit toolkit.
    """
    if not REQUESTS_AVAILABLE:
        log_audit(
            action='sync_servers_to_asset_discovery',
            resource_type='asset_discovery',
            success=False,
            error='requests module not available'
        )
        return jsonify({'error': 'requests module not available'}), 503

    try:
        # Import server manager
        from models.server import ServerManager
        server_manager = ServerManager()
        servers = server_manager.load_servers()

        synced = 0
        errors = []

        for server in servers:
            try:
                # Prepare asset data with elevation settings
                os_type = server.get('os_type', 'linux')
                elevation_method = server.get('elevation_method')

                # Default elevation method based on OS
                if not elevation_method:
                    elevation_method = 'sudo' if os_type == 'linux' else 'runas'

                asset_data = {
                    'hostname': server.get('name', server.get('host')),
                    'fqdn': server.get('host'),
                    'os_type': os_type,
                    'primary_ip': server.get('host'),
                    'status': 'active' if server.get('status') == 'active' else 'offline',
                    'environment': server.get('environment', 'production'),
                    'tags': server.get('tags', []),
                    # Elevation settings for least-privilege integration
                    'elevation_method': elevation_method,
                    'jea_endpoint': server.get('jea_endpoint'),
                    'execution_mode': server.get('execution_mode', 'stream'),
                    # Store in custom_attributes for additional metadata
                    'custom_attributes': {
                        'elevation_method': elevation_method,
                        'jea_endpoint': server.get('jea_endpoint'),
                        'execution_mode': server.get('execution_mode', 'stream'),
                        'connection_method': server.get('connection_method', 'ssh'),
                        'source': 'audit_toolkit'
                    }
                }

                # Post to asset-discovery
                api_key = _get_asset_discovery_api_key()
                headers = {}
                if api_key:
                    headers['X-API-Key'] = api_key

                response = requests.post(
                    f"{ASSET_DISCOVERY_URL}/api/v1/assets",
                    json=asset_data,
                    headers=headers,
                    timeout=10
                )

                if response.status_code in (200, 201):
                    synced += 1
                else:
                    errors.append({
                        'server': server.get('name'),
                        'error': response.json().get('error', 'Unknown error')
                    })
            except Exception as e:
                errors.append({
                    'server': server.get('name', 'unknown'),
                    'error': str(e)
                })

        log_audit(
            action='sync_servers_to_asset_discovery',
            resource_type='asset_discovery',
            details={
                'servers_synced': synced,
                'total_servers': len(servers),
                'errors_count': len(errors)
            },
            success=True
        )

        return jsonify({
            'success': True,
            'synced': synced,
            'total': len(servers),
            'errors': errors
        })
    except Exception as e:
        logger.error(f"Server sync failed: {e}")
        log_audit(
            action='sync_servers_to_asset_discovery',
            resource_type='asset_discovery',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/sync/discovery-results', methods=['POST'])
@require_auth_and_permission('admin')
@require_role('Admin')
def sync_discovery_results():
    """
    Sync discovery results from audit toolkit to asset-discovery

    Takes existing discovery data from the audit toolkit and
    creates/updates assets in asset-discovery with full details.
    """
    if not REQUESTS_AVAILABLE:
        log_audit(
            action='sync_discovery_results',
            resource_type='asset_discovery',
            success=False,
            error='requests module not available'
        )
        return jsonify({'error': 'requests module not available'}), 503

    try:
        # Import discovery manager
        from models.discovery import discovery_manager

        # Get all discovery results
        results = _get_discovery_results_for_sync(discovery_manager, limit=1000)

        synced = 0
        errors = []

        for result in results:
            try:
                discovery_data = result.to_dict() if hasattr(result, 'to_dict') else result
                server_id = discovery_data.get('server_id') or discovery_data.get('hostname') or 'unknown'

                if not discovery_data:
                    continue

                # Transform to asset-discovery format
                asset_data = {
                    'hostname': discovery_data.get('hostname', server_id),
                    'os_name': discovery_data.get('os_info', {}).get('name'),
                    'os_version': discovery_data.get('os_info', {}).get('version'),
                    'os_type': discovery_data.get('os_type'),
                    'kernel_version': discovery_data.get('kernel'),
                    'status': 'active',
                    # Software list
                    'software': [
                        {
                            'name': pkg.split('|')[0] if '|' in pkg else pkg,
                            'version': pkg.split('|')[1] if '|' in pkg else None
                        }
                        for pkg in discovery_data.get('packages', [])[:500]  # Limit
                    ],
                    # Services
                    'services': [
                        {'name': svc, 'status': 'running'}
                        for svc in discovery_data.get('services', [])
                    ]
                }

                # Post to asset-discovery
                response = requests.post(
                    f"{ASSET_DISCOVERY_URL}/api/v1/assets",
                    json=asset_data,
                    timeout=30
                )

                if response.status_code in (200, 201):
                    synced += 1
                else:
                    errors.append({
                        'server': server_id,
                        'error': response.json().get('error', 'Unknown error')
                    })
            except Exception as e:
                errors.append({
                    'server': server_id,
                    'error': str(e)
                })

        log_audit(
            action='sync_discovery_results',
            resource_type='asset_discovery',
            details={
                'results_synced': synced,
                'total_results': len(results),
                'errors_count': len(errors)
            },
            success=True
        )

        return jsonify({
            'success': True,
            'synced': synced,
            'total': len(results),
            'errors': errors
        })
    except Exception as e:
        logger.error(f"Discovery sync failed: {e}")
        log_audit(
            action='sync_discovery_results',
            resource_type='asset_discovery',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


# =============================================================================
# INBOUND SYNC ROUTES - Receive data FROM Asset Discovery
# =============================================================================

@asset_discovery_bp.route('/sync/receive/asset', methods=['POST'])
@conditional_limit(get_asset_discovery_upload_limit)
def receive_asset_sync():
    """
    Receive asset data from Asset Discovery and create/update server.

    This endpoint is called by Asset Discovery's sync service to push
    discovered assets to the main audit toolkit's server inventory.
    """
    # Check for X-Source header to verify request is from asset-discovery
    source = request.headers.get('X-Source', '')
    if source != 'asset-discovery':
        logger.warning(f"Received sync request from unknown source: {source}")
        # Still allow for testing, but log it

    api_key = request.headers.get('X-API-Key')
    if not (_is_trusted_internal_request() or _is_valid_asset_discovery_api_key(api_key)):
        return jsonify({'error': 'Invalid or missing X-API-Key header'}), 401

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Import server manager
        from models.server import ServerManager
        server_manager = ServerManager()

        hostname = data.get('hostname') or data.get('name')
        ip_address = data.get('ip_address')

        if not hostname and not ip_address:
            return jsonify({'error': 'hostname or ip_address required'}), 400

        # Check if server exists
        servers = server_manager.load_servers()
        existing = None
        for server in servers:
            if (server.get('hostname') == hostname or
                server.get('host') == hostname or
                server.get('host') == ip_address):
                existing = server
                break

        if existing:
            # Update existing server
            server_id = existing.get('id')
            update_tags = data.get('tags', [])
            if isinstance(update_tags, list):
                update_tags = ','.join(str(tag) for tag in update_tags)

            update_data = {
                'hostname': hostname,
                'os_type': data.get('os_type'),
                'user': data.get('user', data.get('username')),
                'password': data.get('password'),
                'auth_type': data.get('auth_type'),
                'key_path': data.get('key_path', data.get('ssh_key_path')),
                'description': data.get('description'),
                'environment': data.get('environment'),
                'location': data.get('location'),
                'owner': data.get('owner'),
                'tags': update_tags,
            }
            # Add custom attributes if provided
            if data.get('custom_attributes'):
                update_data['custom_attributes'] = data['custom_attributes']

            # Filter out None values
            update_data = {k: v for k, v in update_data.items() if v is not None}

            success = server_manager.update_server(server_id, update_data)
            if success:
                log_audit(
                    action='receive_asset_sync',
                    resource_id=str(server_id),
                    resource_type='asset_discovery',
                    details={'action': 'updated', 'hostname': hostname},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'action': 'updated',
                    'id': server_id
                })
            else:
                return jsonify({'error': 'Failed to update server'}), 500
        else:
            # Create new server with elevation settings
            os_type = data.get('os_type', 'linux')
            custom_attrs = data.get('custom_attributes', {})

            # Extract elevation settings from data or custom_attributes
            elevation_method = data.get('elevation_method') or custom_attrs.get('elevation_method')
            jea_endpoint = data.get('jea_endpoint') or custom_attrs.get('jea_endpoint')
            execution_mode = data.get('execution_mode') or custom_attrs.get('execution_mode', 'stream')

            # Default elevation method based on OS type
            if not elevation_method:
                if os_type == 'windows':
                    elevation_method = 'runas'  # Default for Windows
                else:
                    elevation_method = 'sudo'   # Default for Linux/Unix

            tags_value = data.get('tags', [])
            if isinstance(tags_value, list):
                tags_value = ','.join(str(tag) for tag in tags_value)

            new_server = {
                'name': data.get('name', hostname),
                'host': ip_address or hostname,
                'hostname': hostname,
                'port': data.get('port', 22 if os_type != 'windows' else 5985),
                'connection_method': data.get('connection_method', data.get('connection_type', 'ssh' if os_type != 'windows' else 'winrm')),
                'os_type': os_type,
                'user': data.get('user', data.get('username', 'audit_user' if os_type != 'windows' else 'Administrator')),
                'password': data.get('password'),
                'auth_type': data.get('auth_type', 'public_key'),
                'key_path': data.get('key_path', data.get('ssh_key_path')),
                'execution_mode': execution_mode,
                'elevation_method': elevation_method,
                'jea_endpoint': jea_endpoint if elevation_method == 'jea' else None,
                'description': data.get('description', 'Synced from Asset Discovery'),
                'environment': data.get('environment', 'production'),
                'location': data.get('location'),
                'owner': data.get('owner'),
                'tags': tags_value,
                'custom_attributes': data.get('custom_attributes', {}),
                'source': 'asset_discovery'
            }

            # Filter out None values
            new_server = {k: v for k, v in new_server.items() if v is not None}

            created_server = server_manager.add_server(new_server)
            created_server_id = created_server.get('id') if isinstance(created_server, dict) else created_server
            if created_server_id:
                log_audit(
                    action='receive_asset_sync',
                    resource_id=str(created_server_id),
                    resource_type='asset_discovery',
                    details={'action': 'created', 'hostname': hostname},
                    success=True
                )
                return jsonify({
                    'success': True,
                    'action': 'created',
                    'id': created_server_id
                })
            else:
                return jsonify({'error': 'Failed to create server'}), 500

    except Exception as e:
        logger.error(f"Asset sync receive failed: {e}")
        log_audit(
            action='receive_asset_sync',
            resource_type='asset_discovery',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/sync/receive/vulnerabilities', methods=['POST'])
@conditional_limit(get_asset_discovery_upload_limit)
def receive_vulnerability_sync():
    """
    Receive vulnerability data from Asset Discovery.

    This endpoint stores vulnerability scan results from Asset Discovery
    so they can be viewed in the main audit toolkit's dashboard.
    """
    source = request.headers.get('X-Source', '')
    if source != 'asset-discovery':
        logger.warning(f"Received vuln sync from unknown source: {source}")

    api_key = request.headers.get('X-API-Key')
    if not (_is_trusted_internal_request() or _is_valid_asset_discovery_api_key(api_key)):
        return jsonify({'error': 'Invalid or missing X-API-Key header'}), 401

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        hostname = data.get('hostname')
        ip_address = data.get('ip_address')
        vulnerabilities = data.get('vulnerabilities', [])
        summary = data.get('summary', {})

        if not hostname and not ip_address:
            return jsonify({'error': 'hostname or ip_address required'}), 400

        # Store vulnerability data
        # For now, we'll store in a simple format that can be queried
        try:
            from models.vulnerability import vulnerability_store

            vuln_record = {
                'hostname': hostname,
                'ip_address': ip_address,
                'vulnerabilities': vulnerabilities,
                'summary': summary,
                'recommendations': data.get('recommendations', []),
                'scan_timestamp': data.get('scan_timestamp'),
                'source': 'asset_discovery',
                'total_cves': len(vulnerabilities),
                'critical_count': summary.get('critical', 0),
                'high_count': summary.get('high', 0),
                'medium_count': summary.get('medium', 0),
                'low_count': summary.get('low', 0)
            }

            result = vulnerability_store.save_scan_result(hostname, vuln_record)

            log_audit(
                action='receive_vulnerability_sync',
                resource_type='asset_discovery',
                details={
                    'hostname': hostname,
                    'vulnerabilities_received': len(vulnerabilities),
                    'storage': 'vulnerability_store'
                },
                success=True
            )

            return jsonify({
                'success': True,
                'vulnerabilities_received': len(vulnerabilities),
                'id': result.get('id') if result else None
            })
        except ImportError:
            # Vulnerability store not available, store in simple file
            import json

            vuln_dir = os.path.join(os.path.dirname(__file__), '..', 'storage', 'vulnerabilities')
            os.makedirs(vuln_dir, exist_ok=True)

            filename = f"{hostname or ip_address}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
            filepath = os.path.join(vuln_dir, filename)

            with open(filepath, 'w') as f:
                json.dump({
                    'hostname': hostname,
                    'ip_address': ip_address,
                    'vulnerabilities': vulnerabilities,
                    'summary': summary,
                    'recommendations': data.get('recommendations', []),
                    'scan_timestamp': data.get('scan_timestamp'),
                    'source': 'asset_discovery'
                }, f, indent=2)

            retention_days, max_records = _get_asset_discovery_retention_policy()
            cleanup_stats = _cleanup_vulnerability_fallback_storage(
                vuln_dir=vuln_dir,
                retention_days=retention_days,
                max_records=max_records
            )

            log_audit(
                action='receive_vulnerability_sync',
                resource_type='asset_discovery',
                details={
                    'hostname': hostname,
                    'vulnerabilities_received': len(vulnerabilities),
                    'storage': 'file_fallback',
                    'retention_days': retention_days,
                    'max_records': max_records,
                    'cleanup': cleanup_stats
                },
                success=True
            )

            return jsonify({
                'success': True,
                'vulnerabilities_received': len(vulnerabilities),
                'stored_at': filepath
            })

    except Exception as e:
        logger.error(f"Vulnerability sync receive failed: {e}")
        log_audit(
            action='receive_vulnerability_sync',
            resource_type='asset_discovery',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/sync/receive/scan-complete', methods=['POST'])
@conditional_limit(get_asset_discovery_upload_limit)
def receive_scan_complete_notification():
    """
    Receive notification that a scan completed in Asset Discovery.

    This can trigger follow-up actions like running an audit on
    newly discovered/updated servers.
    """
    source = request.headers.get('X-Source', '')

    api_key = request.headers.get('X-API-Key')
    if not (_is_trusted_internal_request() or _is_valid_asset_discovery_api_key(api_key)):
        return jsonify({'error': 'Invalid or missing X-API-Key header'}), 401

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        scan_id = data.get('scan_id')
        scan_type = data.get('scan_type')
        assets_scanned = data.get('assets_scanned', [])
        trigger_audit = data.get('trigger_audit', False)

        logger.info(f"Received scan complete notification: {scan_type} scan {scan_id}, "
                   f"{len(assets_scanned)} assets")

        result = {
            'success': True,
            'received': True,
            'scan_id': scan_id,
            'assets_count': len(assets_scanned)
        }

        # Trigger audit if requested
        if trigger_audit and assets_scanned:
            try:
                from models.server import ServerManager
                from services.audit_service import audit_service

                server_manager = ServerManager()

                # Find matching servers
                servers = server_manager.load_servers()
                server_ids = []

                for asset in assets_scanned:
                    hostname = asset.get('hostname')
                    ip = asset.get('ip_address')

                    for server in servers:
                        if (server.get('hostname') == hostname or
                            server.get('host') == hostname or
                            server.get('host') == ip):
                            server_ids.append(server.get('id'))
                            break

                if server_ids:
                    # Schedule audit for these servers
                    audit_result = audit_service.schedule_batch_audit(
                        server_ids=server_ids,
                        audit_type='security',
                        source='asset_discovery_trigger'
                    )
                    result['audit_scheduled'] = True
                    result['audit_servers'] = len(server_ids)
                else:
                    result['audit_scheduled'] = False
                    result['audit_reason'] = 'No matching servers found'

            except Exception as e:
                logger.error(f"Failed to trigger audit: {e}")
                result['audit_scheduled'] = False
                result['audit_error'] = str(e)

        log_audit(
            action='receive_scan_complete_notification',
            resource_id=str(scan_id) if scan_id is not None else None,
            resource_type='asset_discovery',
            details={
                'scan_type': scan_type,
                'assets_count': len(assets_scanned),
                'trigger_audit': trigger_audit,
                'audit_scheduled': result.get('audit_scheduled', False)
            },
            success=True
        )

        return jsonify(result)

    except Exception as e:
        logger.error(f"Scan complete notification failed: {e}")
        log_audit(
            action='receive_scan_complete_notification',
            resource_type='asset_discovery',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


# ==============================================================================
# Asset Discovery API Key Management
# ==============================================================================

@asset_discovery_bp.route('/api/asset-discovery/keys/validate', methods=['POST'])
def validate_asset_discovery_key():
    """
    Validate an Asset Discovery API key.

    This endpoint is called by the Asset Discovery service to validate
    API keys against the main tool's encrypted keystore.

    Request:
        {
            "api_key": "key-to-validate"
        }

    Response:
        {
            "valid": true,
            "key_id": "primary",
            "metadata": {...}
        }
    """
    try:
        data = request.get_json()
        if not data or 'api_key' not in data:
            return jsonify({'valid': False, 'error': 'Missing api_key'}), 400

        api_key = str(data['api_key']).strip()
        if not api_key:
            return jsonify({'valid': False, 'error': 'Missing api_key'}), 400

        # Validate against keystore
        from keystore import get_keystore
        keystore = get_keystore()

        # Check all asset_discovery keys
        keys = keystore.list_keys('asset_discovery')
        for key_info in keys:
            key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', key_id)
            if stored_value and secrets.compare_digest(str(stored_value).strip(), api_key):
                return jsonify({
                    'valid': True,
                    'key_id': key_id,
                    'metadata': key_info.get('metadata', {})
                })

        # Backward compatibility bootstrap: permit system API key validation.
        try:
            from auth_core import get_api_key_manager
            if get_api_key_manager().validate_key(api_key):
                return jsonify({
                    'valid': True,
                    'key_id': 'system/api_key',
                    'metadata': {'source': 'system_fallback'}
                })
        except Exception as e:
            logger.debug(f"System API key fallback unavailable during validation: {e}")

        env_key = os.getenv('ASSET_DISCOVERY_API_KEY')
        if env_key and secrets.compare_digest(str(env_key).strip(), api_key):
            return jsonify({
                'valid': True,
                'key_id': 'env/ASSET_DISCOVERY_API_KEY',
                'metadata': {'source': 'env_fallback'}
            })

        return jsonify({'valid': False, 'error': 'Invalid API key'}), 401

    except Exception as e:
        logger.error(f"API key validation error: {e}")
        return jsonify({'valid': False, 'error': 'Validation failed'}), 500


@asset_discovery_bp.route('/api/asset-discovery/keys', methods=['GET'])
@login_required
@require_auth_and_permission('manage_integrations')
@require_role('Admin')
def list_asset_discovery_keys():
    """List all Asset Discovery API keys (without values)."""
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        keys = keystore.list_keys('asset_discovery')
        log_audit(
            action='list_asset_discovery_keys',
            resource_type='asset_discovery_key',
            details={'keys_count': len(keys)},
            success=True
        )
        return jsonify({'keys': keys})

    except Exception as e:
        logger.error(f"Failed to list keys: {e}")
        log_audit(
            action='list_asset_discovery_keys',
            resource_type='asset_discovery_key',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/asset-discovery/keys', methods=['POST'])
@login_required
@require_auth_and_permission('manage_integrations')
@require_role('Admin')
def create_asset_discovery_key():
    """
    Create a new Asset Discovery API key.

    Request:
        {
            "key_id": "primary",
            "description": "Main Asset Discovery API key",
            "auto_generate": true
        }
    """
    try:
        data = request.get_json() or {}
        key_id = data.get('key_id', 'primary')
        description = data.get('description', 'Asset Discovery API Key')
        auto_generate = data.get('auto_generate', True)

        from keystore import get_keystore
        import secrets

        keystore = get_keystore()

        # Check if key already exists
        if keystore.get_key('asset_discovery', key_id):
            return jsonify({'error': f'Key {key_id} already exists'}), 400

        # Generate new key
        if auto_generate:
            api_key = secrets.token_urlsafe(32)
        else:
            api_key = data.get('value')
            if not api_key:
                return jsonify({'error': 'Value required when auto_generate=false'}), 400

        # Store in keystore
        keystore.store_key(
            key_type='asset_discovery',
            key_id=key_id,
            value=api_key,
            metadata={
                'description': description,
                'created_by': current_user.username if current_user else 'system'
            }
        )

        log_audit(
            action='create_asset_discovery_key',
            resource_id=str(key_id),
            resource_type='asset_discovery_key',
            details={'description': description},
            success=True
        )

        return jsonify({
            'success': True,
            'key_id': key_id,
            'api_key': api_key,  # Only returned on creation
            'message': 'API key created successfully'
        }), 201

    except Exception as e:
        logger.error(f"Failed to create key: {e}")
        log_audit(
            action='create_asset_discovery_key',
            resource_type='asset_discovery_key',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/asset-discovery/keys/<key_id>', methods=['DELETE'])
@login_required
@require_auth_and_permission('manage_integrations')
@require_role('Admin')
def delete_asset_discovery_key(key_id):
    """Delete an Asset Discovery API key."""
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        if keystore.delete_key('asset_discovery', key_id):
            log_audit(
                action='delete_asset_discovery_key',
                resource_id=str(key_id),
                resource_type='asset_discovery_key',
                success=True
            )
            return jsonify({'success': True, 'message': 'Key deleted'})
        else:
            return jsonify({'error': 'Key not found'}), 404

    except Exception as e:
        logger.error(f"Failed to delete key: {e}")
        log_audit(
            action='delete_asset_discovery_key',
            resource_id=str(key_id),
            resource_type='asset_discovery_key',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/asset-discovery/keys/<key_id>/rotate', methods=['POST'])
@login_required
@require_auth_and_permission('manage_integrations')
@require_role('Admin')
def rotate_asset_discovery_key(key_id):
    """Rotate an Asset Discovery API key."""
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        new_key = keystore.rotate_key('asset_discovery', key_id)
        if new_key:
            log_audit(
                action='rotate_asset_discovery_key',
                resource_id=str(key_id),
                resource_type='asset_discovery_key',
                success=True
            )
            return jsonify({
                'success': True,
                'key_id': key_id,
                'new_api_key': new_key,  # Only returned on rotation
                'message': 'API key rotated successfully'
            })
        else:
            return jsonify({'error': 'Key not found'}), 404

    except Exception as e:
        logger.error(f"Failed to rotate key: {e}")
        log_audit(
            action='rotate_asset_discovery_key',
            resource_id=str(key_id),
            resource_type='asset_discovery_key',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


# ==============================================================================
# Unified Keystore API - Access ALL Key Types (Not Just Asset Discovery)
# ==============================================================================

@asset_discovery_bp.route('/api/keystore/keys/<key_type>', methods=['GET'])
def list_keystore_keys(key_type):
    """
    List all keys of a specific type from the encrypted keystore.

    This endpoint is used by Asset Discovery to access ALL key types:
    - system: System API keys
    - agent: Standalone Agent API keys
    - hypervisor_agent: Hypervisor Platform Agent keys
    - asset_discovery: Asset Discovery API keys
    - custom: Custom Integration keys
    - ssh_password: SSH Server passwords
    - api_token: External API tokens (Proxmox, Docker, etc.)

    Authentication required via Asset Discovery API key.

    Path Parameters:
        key_type: Type of keys to list

    Response:
        {
            "keys": [
                {
                    "key_id": "primary",
                    "metadata": {...},
                    "created_at": "2024-01-01T00:00:00"
                }
            ]
        }
    """
    try:
        # Authenticate via API key in header
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({'error': 'Missing X-API-Key header'}), 401

        # Validate API key against keystore
        from keystore import get_keystore
        keystore = get_keystore()

        # Check if provided key is a valid asset_discovery key
        keys = keystore.list_keys('asset_discovery')
        valid = False
        for key_info in keys:
            key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', key_id)
            if stored_value == api_key:
                valid = True
                break

        if not valid:
            return jsonify({'error': 'Invalid API key'}), 401

        # Validate key_type
        valid_types = ['system', 'agent', 'hypervisor_agent', 'asset_discovery',
                      'custom', 'ssh_password', 'api_token']
        if key_type not in valid_types:
            return jsonify({'error': f'Invalid key_type. Must be one of: {", ".join(valid_types)}'}), 400

        # List keys (without values for security)
        key_list = keystore.list_keys(key_type)
        return jsonify({'keys': key_list})

    except Exception as e:
        logger.error(f"Failed to list keys for type {key_type}: {e}")
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/keystore/keys/<key_type>/<key_id>', methods=['GET'])
def get_keystore_key(key_type, key_id):
    """
    Get a specific key value from the encrypted keystore.

    Authentication required via Asset Discovery API key.

    Path Parameters:
        key_type: Type of key (system, agent, ssh_password, etc.)
        key_id: Specific key identifier

    Response:
        {
            "key_id": "primary",
            "value": "encrypted-key-value",
            "metadata": {...}
        }
    """
    try:
        # Authenticate via API key in header
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({'error': 'Missing X-API-Key header'}), 401

        # Validate API key against keystore
        from keystore import get_keystore
        keystore = get_keystore()

        # Check if provided key is a valid asset_discovery key
        keys = keystore.list_keys('asset_discovery')
        valid = False
        for key_info in keys:
            stored_key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', stored_key_id)
            if stored_value == api_key:
                valid = True
                break

        if not valid:
            return jsonify({'error': 'Invalid API key'}), 401

        # Get key value
        value = keystore.get_key(key_type, key_id)
        if not value:
            return jsonify({'error': 'Key not found'}), 404

        # Get metadata
        keys = keystore.list_keys(key_type)
        metadata = {}
        for k in keys:
            if k.get('key_id') == key_id:
                metadata = k.get('metadata', {})
                break

        return jsonify({
            'key_id': key_id,
            'value': value,
            'metadata': metadata
        })

    except Exception as e:
        logger.error(f"Failed to get key {key_type}/{key_id}: {e}")
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/keystore/credentials/<server_id>', methods=['GET'])
def get_server_credentials(server_id):
    """
    Get all credentials for a specific server (SSH passwords, API tokens, etc.).

    This endpoint retrieves all credentials associated with a server from
    the encrypted keystore for use by Asset Discovery.

    Authentication required via Asset Discovery API key.

    Path Parameters:
        server_id: Server ID (can be server name, hostname, or numeric ID)

    Response:
        {
            "server_id": "web-01",
            "credentials": {
                "ssh_password": "encrypted-password",
                "api_token": "proxmox-api-token",
                "agent_key": "agent-api-key"
            },
            "connection_method": "ssh",
            "elevation_method": "sudo"
        }
    """
    try:
        # Authenticate via API key in header
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({'error': 'Missing X-API-Key header'}), 401

        # Validate API key
        from keystore import get_keystore
        keystore = get_keystore()

        keys = keystore.list_keys('asset_discovery')
        valid = False
        for key_info in keys:
            stored_key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', stored_key_id)
            if stored_value == api_key:
                valid = True
                break

        if not valid:
            return jsonify({'error': 'Invalid API key'}), 401

        # Get server information
        from models.server import ServerManager
        server_manager = ServerManager()

        # Try to find server by ID or hostname
        server = None
        try:
            server_id_int = int(server_id)
            server = server_manager.get_server_by_id(server_id_int)
        except (ValueError, TypeError):
            server = server_manager.get_server_by_host(server_id)

        if not server:
            return jsonify({'error': 'Server not found'}), 404

        # Collect credentials from keystore
        credentials = {}

        # SSH password (if using password auth)
        if server.get('auth_type') == 'password':
            ssh_pass = keystore.get_key('ssh_password', server.get('name'))
            if ssh_pass:
                credentials['ssh_password'] = ssh_pass
            elif server.get('password'):
                credentials['ssh_password'] = server.get('password')

        # API tokens (for hypervisors, Docker, etc.)
        api_token = keystore.get_key('api_token', server.get('name'))
        if api_token:
            credentials['api_token'] = api_token

        # Agent key (if using agent-based connection)
        if server.get('agent_id'):
            agent_key = keystore.get_key('agent', server.get('agent_id'))
            if agent_key:
                credentials['agent_key'] = agent_key

        return jsonify({
            'server_id': server.get('id'),
            'server_name': server.get('name'),
            'hostname': server.get('host'),
            'credentials': credentials,
            'connection_method': server.get('connection_method', 'ssh'),
            'elevation_method': server.get('elevation_method', 'sudo'),
            'execution_mode': server.get('execution_mode', 'stream'),
            'jea_endpoint': server.get('jea_endpoint')
        })

    except Exception as e:
        logger.error(f"Failed to get credentials for server {server_id}: {e}")
        return jsonify({'error': str(e)}), 500


# ==============================================================================
# Server List API - For Asset Discovery to Pull Servers
# ==============================================================================

@asset_discovery_bp.route('/api/servers/list', methods=['GET'])
def list_servers_for_asset_discovery():
    """
    List all servers from the main tool for Asset Discovery to import.

    This endpoint exposes the complete server inventory including connection
    methods and basic metadata (but not credentials - use /api/keystore/credentials
    for that).

    Authentication required via Asset Discovery API key.

    Query Parameters:
        limit: Maximum number of servers to return (default: 100)
        offset: Offset for pagination (default: 0)
        connection_method: Filter by connection method (ssh, winrm, api)

    Response:
        {
            "servers": [
                {
                    "id": 1,
                    "name": "web-01",
                    "hostname": "192.168.1.10",
                    "port": 22,
                    "connection_method": "ssh",
                    "elevation_method": "sudo",
                    "execution_mode": "stream",
                    "jea_endpoint": null,
                    "os_type": "linux",
                    "description": "Web server",
                    "tags": "production,web",
                    "has_ssh_password": true,
                    "has_api_token": false,
                    "has_agent_key": false
                }
            ],
            "total": 50,
            "limit": 100,
            "offset": 0
        }
    """
    try:
        # Authenticate via API key in header
        api_key = request.headers.get('X-API-Key')
        if not api_key:
            return jsonify({'error': 'Missing X-API-Key header'}), 401

        # Validate API key
        from keystore import get_keystore
        keystore = get_keystore()

        keys = keystore.list_keys('asset_discovery')
        valid = False
        for key_info in keys:
            stored_key_id = key_info.get('key_id')
            stored_value = keystore.get_key('asset_discovery', stored_key_id)
            if stored_value == api_key:
                valid = True
                break

        if not valid:
            return jsonify({'error': 'Invalid API key'}), 401

        # Parse query parameters
        limit = int(request.args.get('limit', 100))
        offset = int(request.args.get('offset', 0))
        connection_method_filter = request.args.get('connection_method')

        # Get servers
        from models.server import ServerManager
        server_manager = ServerManager()

        all_servers = server_manager.load_servers()

        # Filter by connection method if specified
        if connection_method_filter:
            all_servers = [s for s in all_servers
                          if s.get('connection_method') == connection_method_filter]

        total = len(all_servers)

        # Apply pagination
        servers = all_servers[offset:offset + limit]

        # Enrich with credential availability flags
        enriched_servers = []
        for server in servers:
            server_copy = server.copy()

            # Check credential availability (without exposing values)
            server_copy['has_ssh_password'] = bool(
                keystore.get_key('ssh_password', server.get('name')) or
                server.get('password')
            )
            server_copy['has_api_token'] = bool(
                keystore.get_key('api_token', server.get('name'))
            )
            server_copy['has_agent_key'] = bool(
                server.get('agent_id') and
                keystore.get_key('agent', server.get('agent_id'))
            )

            # Remove sensitive fields before sending
            server_copy.pop('password', None)
            server_copy.pop('key_path', None)

            enriched_servers.append(server_copy)

        return jsonify({
            'servers': enriched_servers,
            'total': total,
            'limit': limit,
            'offset': offset
        })

    except Exception as e:
        logger.error(f"Failed to list servers for Asset Discovery: {e}")
        return jsonify({'error': str(e)}), 500


@asset_discovery_bp.route('/api/servers/remove/<server_identifier>', methods=['DELETE'])
def remove_server_for_asset_discovery(server_identifier):
    """
    Remove a main-tool server by identifier for trusted Asset Discovery cleanup calls.

    Authentication:
    - Trusted inter-service token via X-Internal-Service-Token, OR
    - Valid Asset Discovery API key via X-API-Key
    """
    try:
        api_key = request.headers.get('X-API-Key')
        if not (_is_trusted_internal_request() or _is_valid_asset_discovery_api_key(api_key)):
            return jsonify({'error': 'Unauthorized request'}), 401

        from models.server import ServerManager
        server_manager = ServerManager()

        lookup = str(server_identifier or '').strip()
        if not lookup:
            return jsonify({'error': 'Missing server identifier'}), 400

        server = None
        try:
            if lookup.isdigit():
                server = server_manager.get_server_by_id(int(lookup))
        except Exception:
            server = None

        if not server:
            try:
                server = server_manager.get_server_by_host(lookup, resolve_dns=False)
            except Exception:
                server = None

        if not server:
            try:
                for candidate in server_manager.load_servers():
                    candidate_name = str(candidate.get('name') or '').strip()
                    candidate_host = str(candidate.get('host') or candidate.get('hostname') or '').strip()
                    if lookup == candidate_name or lookup == candidate_host:
                        server = candidate
                        break
            except Exception:
                server = None

        if not server:
            return jsonify({'success': False, 'error': 'Server not found'}), 404

        server_id = server.get('id')
        if server_id is None:
            return jsonify({'success': False, 'error': 'Resolved server is missing ID'}), 500

        removed = server_manager.remove_server(int(server_id))
        if not removed:
            return jsonify({
                'success': False,
                'error': 'Server deletion failed',
                'server_id': int(server_id),
                'identifier': lookup,
            }), 500

        return jsonify({
            'success': True,
            'server_id': int(server_id),
            'identifier': lookup,
        })

    except Exception as e:
        logger.error(f"Failed to remove server via Asset Discovery bridge ({server_identifier}): {e}")
        return jsonify({'error': str(e)}), 500
