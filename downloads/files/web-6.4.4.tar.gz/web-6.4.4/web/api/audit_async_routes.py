"""
Async Audit Routes - Celery-Based Execution

Provides async endpoints using Celery task queue:
- POST /api/async/execute - Execute audits asynchronously
- GET /api/async/tasks/<task_id> - Get task status
- GET /api/async/tasks/<task_id>/result - Get task result
- GET /api/async/tasks - List recent tasks
- POST /api/async/tasks/<task_id>/cancel - Cancel running task

All execution is non-blocking via Celery workers.

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import json
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from pathlib import Path

# Import from config
from config import logger
from config import ROOT_DIR, SessionLocal

# Import auth decorators
from auth_core import require_api_key, conditional_limit, safe_error_response

# Import validators
from validators import validate_path

# Import database models (optional - fallback if SQLAlchemy not available)
try:
    from models.database import Server, Audit, AuditExecution
    DATABASE_AVAILABLE = True
except ImportError:
    Server = None
    Audit = None
    AuditExecution = None
    DATABASE_AVAILABLE = False

# Import pagination utilities
from pagination import PaginationParams, paginate_query

# Import Celery tasks
from tasks.audit_tasks import execute_audit, execute_audit_plan
from celery_app import celery_app

# Import SSE for real-time streaming
from sse import get_sse_manager, create_sse_response

# Create blueprint
async_audit_bp = Blueprint('async_audits', __name__)


def _extract_execution_id(task) -> int | None:
    """Extract integer AuditExecution.id from Celery task info/result payloads."""
    candidate = None

    info = task.info if task.info else {}
    if isinstance(info, dict):
        candidate = info.get('execution_id')

    if candidate is None and task.ready() and task.successful() and isinstance(task.result, dict):
        candidate = task.result.get('execution_id')

    if candidate is None:
        return None

    try:
        return int(candidate)
    except (TypeError, ValueError):
        return None


def _json_safe_task_info(info):
    """Return task info in a JSON-serializable form."""
    if info is None:
        return {}

    try:
        json.dumps(info)
        return info
    except (TypeError, ValueError):
        return {'detail': str(info)}


# ============================================================================
# Async Audit Execution
# ============================================================================
@async_audit_bp.route('/api/async/execute', methods=['POST'])
@require_api_key
@conditional_limit("20 per hour")  # Higher limit since non-blocking
def execute_async():
    """
    Execute audits asynchronously via Celery

    Request Body:
        {
            "mode": "single|plan|server",
            "server_id": 1,  // Required if mode=single or mode=server
            "audit_path": "audits/platform/baseline/updates.sh",  // Required if mode=single
            "audit_paths": [...],  // Required if mode=plan
            "plan_name": "Custom Plan",  // Optional
            "options": {  // Optional
                "timeout": 300,
                "stream_mode": true  // true = agentless (stream scripts), false = deployed (local package)
            }
        }

    Execution Modes:
        - stream_mode=true (default): Scripts streamed via SSH/WinRM stdin (no deployment needed)
        - stream_mode=false: Scripts must be deployed to standard paths on hosts
          - Linux: /opt/audit-toolkit (via DEB/RPM package)
          - Windows: C:\\Program Files\\SecurityAuditToolkit (via MSI)

    Returns:
        {
            "success": true,
            "task_id": "abc-123-def",
            "message": "Audit execution started",
            "status_url": "/api/async/tasks/abc-123-def"
        }
    """
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        mode = data.get("mode", "single")

        # Validate mode
        if mode not in ["single", "plan", "server"]:
            return jsonify({"success": False, "error": "Invalid mode. Must be: single, plan, or server"}), 400

        # Get server_id (required for all modes)
        server_id = data.get("server_id")
        if not server_id:
            return jsonify({"success": False, "error": "server_id is required"}), 400

        # Verify server exists
        db = SessionLocal()
        try:
            db.rollback()
        except Exception as rollback_error:
            logger.debug(f"Session rollback skipped before async audit execution: {rollback_error}")
        try:
            server = db.query(Server).filter(Server.id == server_id).first()
            if not server:
                return jsonify({"success": False, "error": f"Server {server_id} not found"}), 404
        finally:
            db.close()

        # Execute based on mode
        if mode == "single":
            # Single audit execution
            audit_path = data.get("audit_path")
            if not audit_path:
                return jsonify({"success": False, "error": "audit_path is required for single mode"}), 400

            # Validate path
            if not validate_path(audit_path, ROOT_DIR):
                return jsonify({"success": False, "error": "Invalid audit path"}), 400

            options = data.get("options", {})

            # Execute task asynchronously
            task = execute_audit.apply_async(
                args=[server_id, audit_path],
                kwargs={'options': options},
                queue='audits'
            )

            logger.info(f"Started async audit execution: {audit_path} on server {server_id} (task {task.id})")

            return jsonify({
                "success": True,
                "task_id": task.id,
                "message": f"Audit execution started: {Path(audit_path).name} on {server.name}",
                "status_url": f"/api/async/tasks/{task.id}",
                "mode": "single"
            })

        elif mode == "plan":
            # Multiple audits execution (plan)
            audit_paths = data.get("audit_paths", [])
            if not audit_paths or not isinstance(audit_paths, list):
                return jsonify({"success": False, "error": "audit_paths list is required for plan mode"}), 400

            # Validate all paths
            for path in audit_paths:
                if not validate_path(path, ROOT_DIR):
                    return jsonify({"success": False, "error": f"Invalid audit path: {path}"}), 400

            plan_name = data.get("plan_name", "Custom Plan")

            # Execute plan task asynchronously
            task = execute_audit_plan.apply_async(
                args=[server_id, audit_paths, plan_name],
                queue='audits'
            )

            logger.info(f"Started async plan execution: {len(audit_paths)} audits on server {server_id} (task {task.id})")

            return jsonify({
                "success": True,
                "task_id": task.id,
                "message": f"Plan execution started: {len(audit_paths)} audits on {server.name}",
                "status_url": f"/api/async/tasks/{task.id}",
                "mode": "plan",
                "total_audits": len(audit_paths)
            })

        elif mode == "server":
            # Execute all audits on a server (full server audit)
            from models.audit import AuditManager
            audit_manager = AuditManager()

            # Discover all audits
            all_audits = audit_manager.discover_audits(force_refresh=False)
            audit_paths = [audit['path'] for audit in all_audits]

            # Execute plan with all audits
            task = execute_audit_plan.apply_async(
                args=[server_id, audit_paths, f"Full Server Audit - {server.name}"],
                queue='audits'
            )

            logger.info(f"Started full server audit: {len(audit_paths)} audits on server {server_id} (task {task.id})")

            return jsonify({
                "success": True,
                "task_id": task.id,
                "message": f"Full server audit started: {len(audit_paths)} audits on {server.name}",
                "status_url": f"/api/async/tasks/{task.id}",
                "mode": "server",
                "total_audits": len(audit_paths)
            })

    except Exception as e:
        logger.error(f"Async execution error: {e}")
        return safe_error_response(e, custom_message="Async execution failed")


# ============================================================================
# Task Status & Results
# ============================================================================
@async_audit_bp.route('/api/async/tasks/<task_id>')
@require_api_key
def get_task_status_endpoint(task_id):
    """
    Get status of a Celery task

    Returns:
        {
            "success": true,
            "task_id": "abc-123-def",
            "state": "PENDING|STARTED|RUNNING|SUCCESS|FAILURE|TIMEOUT",
            "info": {...},  // State-specific metadata
            "ready": false,
            "successful": null
        }
    """
    try:
        task = celery_app.AsyncResult(task_id)

        # Get task state
        state = task.state
        info = _json_safe_task_info(task.info)

        execution = None
        execution_id = _extract_execution_id(task)
        if execution_id is not None:
            db = SessionLocal()
            try:
                execution = db.query(AuditExecution).filter(
                    AuditExecution.id == execution_id
                ).first()
            except Exception:
                db.rollback()
                execution = None
            finally:
                db.close()

        response = {
            "success": True,
            "task_id": task_id,
            "state": state,
            "info": info,
            "ready": task.ready(),
            "successful": task.successful() if task.ready() else None
        }

        # Add database record if exists
        if execution:
            response["execution"] = {
                "id": execution.id,
                "status": execution.status,
                "exit_code": execution.exit_code,
                "duration_seconds": execution.duration_seconds,
                "executed_at": execution.executed_at.isoformat() if execution.executed_at else None,
                "completed_at": execution.completed_at.isoformat() if execution.completed_at else None
            }

        return jsonify(response)

    except Exception as e:
        logger.error(f"Error getting task status: {e}")
        return safe_error_response(e, custom_message="Failed to get task status")


@async_audit_bp.route('/api/async/tasks/<task_id>/result')
@require_api_key
def get_task_result(task_id):
    """
    Get result of a completed task

    Returns:
        {
            "success": true,
            "task_id": "abc-123-def",
            "state": "SUCCESS",
            "result": {...},  // Task return value
            "execution": {...}  // Database record with full output
        }
    """
    try:
        task = celery_app.AsyncResult(task_id)

        if not task.ready():
            return jsonify({
                "success": False,
                "error": "Task not completed yet",
                "state": task.state
            }), 400

        # Get task result
        if task.successful():
            result = task.result
        else:
            result = {"error": str(task.info)}

        # Get full execution record from database using execution_id from task payload
        execution = None
        execution_id = _extract_execution_id(task)
        if execution_id is not None:
            db = SessionLocal()
            try:
                execution = db.query(AuditExecution).filter(
                    AuditExecution.id == execution_id
                ).first()
            except Exception:
                db.rollback()
                execution = None
            finally:
                db.close()

        execution_data = None
        if execution:
            execution_data = {
                "id": execution.id,
                "server_id": execution.server_id,
                "audit_id": execution.audit_id,
                "status": execution.status,
                "exit_code": execution.exit_code,
                "output": execution.output,
                "summary": execution.summary if isinstance(execution.summary, (dict, list)) else (json.loads(execution.summary) if execution.summary else None),
                "duration_seconds": execution.duration_seconds,
                "executed_at": execution.executed_at.isoformat() if execution.executed_at else None,
                "completed_at": execution.completed_at.isoformat() if execution.completed_at else None
            }
        return jsonify({
            "success": True,
            "task_id": task_id,
            "state": task.state,
            "result": result,
            "execution": execution_data
        })

    except Exception as e:
        logger.error(f"Error getting task result: {e}")
        return safe_error_response(e, custom_message="Failed to get task result")


@async_audit_bp.route('/api/async/tasks')
@require_api_key
def list_tasks():
    """
    List recent task executions with optional pagination

    Query params:
        - cursor: Pagination cursor
        - limit: Page size (default 50, max 200)
        - include_total: Include total count (default false)
        - server_id: Filter by server
        - status: Filter by status (success, failure, running, etc.)
        - hours: Show tasks from last N hours (default 24)

    Returns:
        {
            "success": true,
            "tasks": [...],
            "pagination": {...}  // If cursor/limit provided
        }
    """
    try:
        db = SessionLocal()

        # Parse filtering query params
        server_id = request.args.get('server_id')
        status = request.args.get('status')
        hours = int(request.args.get('hours', 24))

        # Build query
        query = db.query(AuditExecution)

        # Filter by time
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        query = query.filter(AuditExecution.executed_at >= cutoff_time)

        # Filter by server
        if server_id:
            query = query.filter(AuditExecution.server_id == int(server_id))

        # Filter by status
        if status:
            query = query.filter(AuditExecution.status == status)

        # Order by most recent (for cursor pagination to work, we need consistent ordering)
        query = query.order_by(AuditExecution.executed_at.desc(), AuditExecution.id.desc())

        # Check if pagination is requested
        if 'cursor' in request.args or 'limit' in request.args:
            # Apply cursor-based pagination
            params = PaginationParams.from_request(max_limit=200)

            # Use paginate_query for SQLAlchemy queries
            result = paginate_query(
                query,
                params,
                id_field='id',
                endpoint='async_audits.list_tasks'
            )

            # Format paginated results
            tasks = []
            for execution in result['data']:
                tasks.append({
                    "id": execution.id,
                    "server_id": execution.server_id,
                    "server_name": execution.server.name if execution.server else None,
                    "audit_id": execution.audit_id,
                    "audit_name": execution.audit.name if execution.audit else None,
                    "status": execution.status,
                    "exit_code": execution.exit_code,
                    "summary": json.loads(execution.summary) if execution.summary else None,
                    "duration_seconds": execution.duration_seconds,
                    "executed_at": execution.executed_at.isoformat() if execution.executed_at else None,
                    "completed_at": execution.completed_at.isoformat() if execution.completed_at else None
                })

            db.close()

            return jsonify({
                "success": True,
                "tasks": tasks,
                "pagination": result['pagination'],
                "filters": {
                    "hours": hours,
                    "server_id": server_id,
                    "status": status
                }
            })
        else:
            # Return limited results without pagination (backward compatibility)
            limit = min(int(request.args.get('limit', 50)), 200)
            executions = query.limit(limit).all()

            # Format results
            tasks = []
            for execution in executions:
                tasks.append({
                    "id": execution.id,
                    "server_id": execution.server_id,
                    "server_name": execution.server.name if execution.server else None,
                    "audit_id": execution.audit_id,
                    "audit_name": execution.audit.name if execution.audit else None,
                    "status": execution.status,
                    "exit_code": execution.exit_code,
                    "summary": json.loads(execution.summary) if execution.summary else None,
                    "duration_seconds": execution.duration_seconds,
                    "executed_at": execution.executed_at.isoformat() if execution.executed_at else None,
                    "completed_at": execution.completed_at.isoformat() if execution.completed_at else None
                })

            db.close()

            return jsonify({
                "success": True,
                "tasks": tasks,
                "total": len(tasks),
                "filters": {
                    "hours": hours,
                    "server_id": server_id,
                    "status": status
                }
            })

    except Exception as e:
        logger.error(f"Error listing tasks: {e}")
        return safe_error_response(e, custom_message="Failed to list tasks")


@async_audit_bp.route('/api/async/tasks/<task_id>/cancel', methods=['POST'])
@require_api_key
def cancel_task(task_id):
    """
    Cancel a running task

    Note: This sends revoke signal to Celery.
    Task may not stop immediately if already executing.

    Returns:
        {
            "success": true,
            "message": "Task cancelled"
        }
    """
    try:
        celery_app.control.revoke(task_id, terminate=True)

        # Update database record
        db = SessionLocal()
        execution = db.query(AuditExecution).filter(
            AuditExecution.id == task_id
        ).first()

        if execution and execution.status == 'running':
            execution.status = 'cancelled'
            execution.completed_at = datetime.utcnow()
            execution.output = (execution.output or '') + '\n\n[CANCELLED by user]'
            db.commit()

        db.close()

        logger.info(f"Task {task_id} cancelled by user")

        return jsonify({
            "success": True,
            "message": "Task cancellation requested"
        })

    except Exception as e:
        logger.error(f"Error cancelling task: {e}")
        return safe_error_response(e, custom_message="Failed to cancel task")


@async_audit_bp.route('/api/async/tasks/<task_id>/stream')
@require_api_key
def stream_task_progress(task_id):
    """
    Stream real-time task progress via Server-Sent Events (SSE)

    This endpoint establishes an SSE connection and streams progress events
    from a running Celery task in real-time.

    Args:
        task_id: Celery task ID to stream

    Query Parameters:
        timeout: Stream timeout in seconds (default: 3600)

    Returns:
        SSE stream with events:
        - connected: Connection established
        - progress: Progress update (status, progress %, message)
        - output: Task output line (stdout/stderr)
        - complete: Task completed successfully
        - error: Task failed or error occurred
        - timeout: Stream timeout reached
        - close: Stream ended

    Event Format:
        event: progress
        data: {"task_id": "abc-123", "status": "Running", "progress": 50, "message": "..."}

    Usage:
        const eventSource = new EventSource('/api/async/tasks/abc-123/stream');
        eventSource.addEventListener('progress', (e) => {
            const data = JSON.parse(e.data);
            console.log(data.progress + '%: ' + data.message);
        });
    """
    try:
        sse_manager = get_sse_manager()

        if not sse_manager or not sse_manager.redis_client:
            return jsonify({
                "success": False,
                "error": "SSE streaming not available (Redis not configured)"
            }), 503

        # Get timeout from query params
        timeout = int(request.args.get('timeout', 3600))

        # Create SSE stream generator
        generator = sse_manager.subscribe_to_task(task_id, timeout=timeout)

        # Return SSE response
        return create_sse_response(generator)

    except Exception as e:
        logger.error(f"Error streaming task {task_id}: {e}")
        return safe_error_response(e, custom_message="Task streaming failed")


__all__ = ['async_audit_bp']
