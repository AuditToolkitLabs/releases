"""
Audit Routes - Discovery, Execution, Plans

Provides endpoints for:
- Audit discovery (/api/audits, /api/audits/refresh)
- Audit presets (/api/presets)
- System discovery (/api/discovery/run)
- Audit execution (/api/execute)
- Plan management (/api/plans, /api/plans/save)
"""

import json
import queue
import shutil
import subprocess  # nosec B404 - controlled local process execution for orchestrator/update scripts
import threading
from collections import deque
from datetime import datetime
from pathlib import Path
from flask import Blueprint, jsonify, request

# Import from config
from config import (
    logger, ROOT_DIR, PLANS_DIR, LOGS_DIR,
    ORCHESTRATOR_PATH, DISCOVERY_PATH
)

# Import auth decorators
from auth_core import (
    require_api_key, conditional_limit, safe_error_response,
    require_auth_and_permission, require_role
)
from flask_login import current_user, login_required

# Import audit logging
from logging_utils import log_audit

# Import validators
from validators import validate_path

# Import audit management
from models.audit import AuditManager

try:
    from services_pkg.services.reporting_persistence_service import ReportingPersistenceService
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = False

# Import pagination utilities
from pagination import PaginationParams, paginate_list

# Import SSE for real-time updates
from sse import get_sse_manager, create_sse_response

# Create blueprint
audit_bp = Blueprint('audits', __name__)

# Initialize audit manager
audit_manager = AuditManager()
reporting_persistence_service = ReportingPersistenceService() if _REPORTING_PERSISTENCE_SERVICE_AVAILABLE else None


def _persist_reporting_audit_execution(db_session, execution):
    """Persist canonical reporting rows for an audit execution when available."""
    if reporting_persistence_service is None:
        return None
    return reporting_persistence_service.persist_audit_execution(db_session, execution)

# ============================================================================
# Global Execution State (should be injected by main app)
# ============================================================================
execution_state = {}

def init_audit_routes(exec_state):
    """Initialize audit routes with shared state from main app"""
    global execution_state
    execution_state = exec_state


# ============================================================================
# Audit Discovery
# ============================================================================
@audit_bp.route('/api/audits')
@require_auth_and_permission('view_audits')
@login_required
@require_role('Analyst')
def get_audits():
    """
    Get list of all available audits with optional pagination (requires Analyst+ role)

    Query Parameters:
        refresh (optional): Force cache refresh (default false)
        cursor (optional): Pagination cursor
        limit (optional): Page size (default 50, max 200)
        include_total (optional): Include total count (default false)
        domain (optional): Filter by domain

    Returns:
        JSON response with audits, domains, and pagination metadata
    """
    try:
        # Check for refresh parameter
        force_refresh = request.args.get('refresh', 'false').lower() == 'true'

        audits = audit_manager.discover_audits(force_refresh=force_refresh)

        # Filter by domain if specified
        domain_filter = request.args.get('domain')
        if domain_filter:
            audits = [a for a in audits if a.get('domain') == domain_filter]

        # Group by domain
        domains = audit_manager.group_by_domain(audits)

        # Check if pagination is requested
        if 'cursor' in request.args or 'limit' in request.args:
            # Apply pagination
            params = PaginationParams.from_request(max_limit=200)

            # Use 'path' as the unique identifier for audits
            result = paginate_list(
                audits,
                params,
                id_field='path',
                endpoint='audits.get_audits'
            )

            log_audit(
                action='view_audits',
                resource_type='audits',
                details={
                    'audit_count': len(audits),
                    'domain_filter': domain_filter,
                    'paginated': True
                },
                success=True
            )

            return jsonify({
                "success": True,
                "audits": result['data'],
                "domains": domains,
                "pagination": result['pagination'],
                "cached": not force_refresh
            })
        else:
            # Return all audits (backward compatibility)
            log_audit(
                action='view_audits',
                resource_type='audits',
                details={
                    'audit_count': len(audits),
                    'domain_filter': domain_filter,
                    'paginated': False
                },
                success=True
            )

            return jsonify({
                "success": True,
                "audits": audits,
                "domains": domains,
                "total": len(audits),
                "cached": not force_refresh
            })
    except Exception as e:
        logger.error(f"Error discovering audits: {e}")
        log_audit(
            action='view_audits',
            resource_type='audits',
            success=False,
            error=str(e)
        )
        return safe_error_response(e, custom_message="Failed to discover audits")


@audit_bp.route('/api/audits/refresh', methods=['POST'])
@require_auth_and_permission('view_audits')
def refresh_audits():
    """Force refresh audit cache (PERFORMANCE: Manual cache invalidation)"""
    try:
        audits = audit_manager.discover_audits(force_refresh=True)
        return jsonify({
            "success": True,
            "message": f"Refreshed audit cache ({len(audits)} audits)",
            "total": len(audits)
        })
    except Exception as e:
        logger.error(f"Error refreshing audits: {e}")
        return safe_error_response(e, custom_message="Failed to refresh audits")


@audit_bp.route('/api/presets')
@require_auth_and_permission('view_audits')
def get_presets():
    """Get available presets"""
    presets = {
        "all": {"name": "All Audits", "description": "Run all discovered audits"},
        "platform": {"name": "Platform", "description": "Platform audits (OS, services, baseline)"},
        "web": {"name": "Web Stack", "description": "Web server audits (nginx, apache, PHP)"},
        "security": {"name": "Security Focus", "description": "Security-focused audits (firewall, SSH, updates)"},
        "minimal": {"name": "Minimal", "description": "Core audits only (updates, services, firewall)"}
    }
    return jsonify({"success": True, "presets": presets})


# ============================================================================
# Audit Execution
# ============================================================================
@audit_bp.route('/api/execute', methods=['POST'])
@require_auth_and_permission('run_audits')
@login_required
@require_role('Operator')
@conditional_limit("10 per hour")
def execute_audits():
    """Execute selected audits (requires Operator+ role)"""
    global execution_state

    if execution_state.get("running"):
        log_audit(
            action='execute_audits',
            resource_type='audit_execution',
            success=False,
            error='Execution already in progress'
        )
        return jsonify({"success": False, "error": "Execution already in progress"}), 400

    try:
        data = request.json
        if not data:
            log_audit(
                action='execute_audits',
                resource_type='audit_execution',
                success=False,
                error='Invalid request - no JSON data'
            )
            return jsonify({"success": False, "error": "Invalid request"}), 400

        mode = data.get("mode", "selection")

        # Validate mode
        if mode not in ["selection", "preset", "plan"]:
            return jsonify({"success": False, "error": "Invalid mode"}), 400

        # Determine target server OS/hypervisor
        server_id = data.get("server_id")
        os_type = "linux"
        hypervisor_type = None
        server = None
        if server_id:
            from models.server import ServerManager
            sm = ServerManager()
            server = sm.get_server_by_id(server_id)
            if server:
                os_type = server.get("os_type", "linux")
                if os_type == "hypervisor":
                    hypervisor_type = (server.get("hypervisor_type") or "").lower()

        # Special handling for hypervisors
        if os_type == "hypervisor" and hypervisor_type:
            # Map hypervisor type to audit script
            script_map = {
                "kvm": "audits/hypervisors/kvm/kvm-qemu-audit.sh",
                "esxi": "audits/hypervisors/esxi/vmware-esxi-audit.sh",
                "xen": "audits/hypervisors/xen/xen-audit.sh",
                "proxmox": "audits/hypervisors/proxmox/proxmox-audit.sh",
            }
            api_script_map = {
                "nutanix": "audits/hypervisors/nutanix/nutanix-api-audit.py",
                "vcenter": "audits/hypervisors/esxi/vcenter-api-audit.py",
                "xenorchestra": "audits/hypervisors/xen/xo-api-audit.py",
            }
            if hypervisor_type in script_map:
                # Build a plan with the correct script
                plan_path = PLANS_DIR / f"hypervisor-{hypervisor_type}.plan"
                plan_path.write_text(script_map[hypervisor_type])
                cmd = ["bash", str(ORCHESTRATOR_PATH), "--plan", str(plan_path.relative_to(ROOT_DIR))]
            elif hypervisor_type in api_script_map:
                # Run API-based audit directly
                script = api_script_map[hypervisor_type]
                endpoint = server.get("hypervisor_endpoint") or server.get("host")
                username = server.get("user")
                password = server.get("password")
                # Build command for Nutanix/vCenter/XO API audit
                cmd = ["python3", script, "--server", endpoint, "--username", username, "--password", password or ""]
            else:
                return jsonify({"success": False, "error": f"Unsupported hypervisor type: {hypervisor_type}"}), 400
        elif os_type == "windows":
            cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ORCHESTRATOR_PATH).replace(".sh", ".ps1")]
        else:
            cmd = ["bash", str(ORCHESTRATOR_PATH)]

        if mode == "preset":
            preset = data.get("preset", "all")
            # Validate preset
            allowed_presets = ["all", "platform", "web", "security", "minimal"]
            if preset not in allowed_presets:
                return jsonify({"success": False, "error": "Invalid preset"}), 400
            cmd.extend(["--preset", preset])
        elif mode == "plan":
            plan_path = data.get("plan_path")
            if not plan_path:
                return jsonify({"success": False, "error": "Plan path required"}), 400
            # Validate path is within plans directory
            if not validate_path(plan_path, PLANS_DIR):
                return jsonify({"success": False, "error": "Invalid plan path"}), 400
            cmd.extend(["--plan", plan_path])
        elif mode == "selection":
            selected_paths = data.get("paths", [])
            if not selected_paths or not isinstance(selected_paths, list):
                return jsonify({"success": False, "error": "No audits selected"}), 400

            # Validate all paths are within audits directory
            for path in selected_paths:
                if not validate_path(path, ROOT_DIR):
                    return jsonify({"success": False, "error": "Invalid audit path"}), 400

            # Save as temporary plan
            temp_plan = PLANS_DIR / "web-session.plan"
            temp_plan.write_text("\n".join(selected_paths))
            cmd.extend(["--plan", str(temp_plan.relative_to(ROOT_DIR))])
    except Exception as e:
        logger.error(f"Execute validation error: {e}")
        log_audit(
            action='execute_audits',
            resource_type='audit_execution',
            success=False,
            error=f'Validation error: {str(e)}'
        )
        return jsonify({"success": False, "error": "Invalid request data"}), 400

    # NOTE: execution_state must be a deque with maxlen for circular buffer
    # This should be set by init_audit_routes()
    if "output" in execution_state and isinstance(execution_state["output"], deque):
        execution_state["output"].clear()  # Clear deque

    execution_state.update({
        "running": True,
        "summary": None,
        "start_time": datetime.now().isoformat(),
        "log_file": None
    })

    def run_orchestrator():
        """Run orchestrator in background with async I/O (PERFORMANCE FIX)"""
        output_queue = queue.Queue()
        log_file = None

        try:
            # Create log file for full output (disk-backed)
            log_file = LOGS_DIR / f"execution-{datetime.now().strftime('%Y%m%d-%H%M%S')}.log"
            execution_state["log_file"] = str(log_file.relative_to(ROOT_DIR))

            process = subprocess.Popen(  # nosec B603 - command arguments are validated and constructed by trusted server-side logic
                cmd,
                cwd=str(ROOT_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )

            def read_output(pipe, queue, log_path):
                """Read output in dedicated thread (non-blocking)"""
                try:
                    with open(log_path, 'w') as log:
                        for line in iter(pipe.readline, ''):
                            if line:
                                # Write to disk immediately
                                log.write(line)
                                log.flush()

                                # Queue for in-memory buffer
                                queue.put({
                                    "timestamp": datetime.now().isoformat(),
                                    "line": line.rstrip()
                                })
                finally:
                    pipe.close()
                    queue.put(None)  # Signal completion

            # Start dedicated reader thread
            reader_thread = threading.Thread(
                target=read_output,
                args=(process.stdout, output_queue, log_file),
                daemon=True
            )
            reader_thread.start()

            # Process queue asynchronously (non-blocking)
            while True:
                try:
                    output = output_queue.get(timeout=0.1)
                    if output is None:  # Reader finished
                        break
                    if "output" in execution_state and isinstance(execution_state["output"], deque):
                        execution_state["output"].append(output)
                except queue.Empty:
                    continue

            # Wait for process to complete
            process.wait()
            reader_thread.join(timeout=5)

            # Parse summary from log file (avoid large in-memory string)
            if log_file.exists():
                with open(log_file, 'r') as f:
                    # Read last 1000 lines for summary
                    lines = f.readlines()[-1000:]
                    output_text = ''.join(lines)

                    if "OVERALL" in output_text:
                        for line in output_text.split("\n"):
                            if "TOTAL=" in line:
                                # Parse: TOTAL=10 PASS=8 WARN=1 FAIL=1 SKIP=0
                                parts = line.strip().split()
                                summary = {}
                                for part in parts:
                                    if "=" in part:
                                        key, val = part.split("=")
                                        summary[key.lower()] = int(val)
                                execution_state["summary"] = summary
                                break

            execution_state["running"] = False
            execution_state["exit_code"] = process.returncode

            logger.info(f"Audit execution completed. Full log: {log_file}")

        except Exception as e:
            logger.error(f"Orchestrator execution error: {e}")
            if "output" in execution_state and isinstance(execution_state["output"], deque):
                execution_state["output"].append({
                    "timestamp": datetime.now().isoformat(),
                    "line": f"ERROR: {str(e)}"
                })
            execution_state["running"] = False
            execution_state["error"] = str(e)

    # Start background thread (returns immediately)
    thread = threading.Thread(target=run_orchestrator, daemon=True)
    thread.start()

    log_audit(
        action='execute_audits',
        resource_type='audit_execution',
        details={
            'mode': data.get('mode', 'selection'),
            'server_id': data.get('server_id'),
            'os_type': os_type
        },
        success=True
    )

    return jsonify({"success": True, "message": "Execution started"})


# ============================================================================
# Audit Execution Management (REST-style endpoints)
# ============================================================================
@audit_bp.route('/api/audits/executions', methods=['GET'])
@require_auth_and_permission('view_audits')
@login_required
@require_role('Analyst')
def list_audit_executions():
    """List all audit executions with optional filtering and pagination (requires Analyst+ role)"""
    try:
        from models.database import AuditExecution, db
        from sqlalchemy import desc

        query = db.session.query(AuditExecution)

        # Optional filters
        server_id = request.args.get('server_id', type=int)
        audit_id = request.args.get('audit_id', type=int)
        status = request.args.get('status')

        if server_id:
            query = query.filter(AuditExecution.server_id == server_id)
        if audit_id:
            query = query.filter(AuditExecution.audit_id == audit_id)
        if status:
            query = query.filter(AuditExecution.status == status)

        # Order by most recent first
        query = query.order_by(desc(AuditExecution.executed_at))

        # Pagination
        limit = request.args.get('limit', 50, type=int)
        offset = request.args.get('offset', 0, type=int)
        limit = min(limit, 200)  # Cap at 200

        total = query.count()
        executions = query.offset(offset).limit(limit).all()

        log_audit(
            action='list_audit_executions',
            resource_type='audit_execution',
            details={
                'total': total,
                'executed': len(executions),
                'server_id': server_id,
                'status_filter': status
            },
            success=True
        )

        return jsonify({
            "success": True,
            "executions": [e.to_dict() for e in executions],
            "total": total,
            "limit": limit,
            "offset": offset
        })
    except Exception as e:
        logger.error(f"Error listing audit executions: {e}")
        log_audit(
            action='list_audit_executions',
            resource_type='audit_execution',
            success=False,
            error=str(e)
        )
        return safe_error_response(e, custom_message="Failed to list executions")


@audit_bp.route('/api/audits/executions/<int:execution_id>', methods=['GET'])
@require_auth_and_permission('view_audits')
def get_audit_execution(execution_id):
    """Get a specific audit execution by ID"""
    try:
        from models.database import AuditExecution, db

        execution = db.session.query(AuditExecution).filter_by(id=execution_id).first()
        if not execution:
            return jsonify({"success": False, "error": "Execution not found"}), 404

        return jsonify({
            "success": True,
            "execution": execution.to_dict(),
            **execution.to_dict()  # Also return flat for backward compat
        })
    except Exception as e:
        logger.error(f"Error getting audit execution {execution_id}: {e}")
        return safe_error_response(e, custom_message="Failed to get execution")


# Alias: GET /api/audits/<id> for test compatibility (routes to executions)
@audit_bp.route('/api/audits/<int:audit_id>', methods=['GET'])
@require_auth_and_permission('view_audits')
def get_audit_by_id(audit_id):
    """Get audit execution by ID (alias for test compatibility)"""
    try:
        from models.database import AuditExecution, db

        execution = db.session.query(AuditExecution).filter_by(id=audit_id).first()
        if not execution:
            return jsonify({"success": False, "error": "Audit not found"}), 404

        return jsonify({
            "success": True,
            "id": execution.id,
            **execution.to_dict()
        })
    except Exception as e:
        logger.error(f"Error getting audit {audit_id}: {e}")
        return safe_error_response(e, custom_message="Failed to get audit")


@audit_bp.route('/api/audits', methods=['POST'])
@require_auth_and_permission('run_audits')
@conditional_limit("10 per hour")
def create_audit():
    """Create and start a new audit execution"""
    try:
        from models.database import AuditExecution, Audit, db
        from models.server import ServerManager

        data = request.json
        if not data:
            return jsonify({"success": False, "error": "No data provided"}), 400

        server_id = data.get('server_id')
        audit_type = data.get('audit_type', 'baseline')
        scripts = data.get('scripts', [])

        if not server_id:
            return jsonify({"success": False, "error": "server_id is required"}), 400

        # Verify server exists
        sm = ServerManager()
        server = sm.get_server_by_id(server_id)
        if not server:
            return jsonify({"success": False, "error": "Server not found"}), 404

        # Find or create audit metadata entry
        audit_meta = db.session.query(Audit).filter_by(domain=audit_type).first()
        if not audit_meta:
            audit_meta = Audit(
                name=f'{audit_type}-audit',
                domain=audit_type,
                category='baseline',
                file_path=f'/audits/{audit_type}/baseline/audit.sh'
            )
            db.session.add(audit_meta)
            db.session.flush()

        # Create execution record
        execution = AuditExecution(
            server_id=server_id,
            audit_id=audit_meta.id,
            status='pending',
            executed_by=request.headers.get('X-User', 'api')
        )
        db.session.add(execution)
        db.session.flush()
        _persist_reporting_audit_execution(db.session, execution)
        db.session.commit()

        # Trigger execution in background (simplified - real impl would use Celery)
        # For now we just return the pending execution
        return jsonify({
            "success": True,
            "id": execution.id,
            "server_id": execution.server_id,
            "audit_type": audit_type,
            "status": execution.status
        }), 201

    except Exception as e:
        logger.error(f"Error creating audit: {e}")
        return safe_error_response(e, custom_message="Failed to create audit")


@audit_bp.route('/api/audits/<int:audit_id>/retry', methods=['POST'])
@require_auth_and_permission('run_audits')
def retry_audit_execution(audit_id):
    """Retry a failed audit execution"""
    try:
        from models.database import AuditExecution, db

        execution = db.session.query(AuditExecution).filter_by(id=audit_id).first()
        if not execution:
            return jsonify({"success": False, "error": "Execution not found"}), 404

        if execution.status not in ['failure', 'timeout', 'error', 'failed']:
            return jsonify({
                "success": False,
                "error": f"Cannot retry execution with status '{execution.status}'"
            }), 400

        # Create new execution as retry
        new_execution = AuditExecution(
            server_id=execution.server_id,
            audit_id=execution.audit_id,
            status='pending',
            executed_by=request.headers.get('X-User', 'api')
        )
        db.session.add(new_execution)
        db.session.flush()
        _persist_reporting_audit_execution(db.session, new_execution)
        db.session.commit()

        return jsonify({
            "success": True,
            "id": new_execution.id,
            "status": new_execution.status,
            "retried_from": audit_id
        })
    except Exception as e:
        logger.error(f"Error retrying audit {audit_id}: {e}")
        return safe_error_response(e, custom_message="Failed to retry audit")


@audit_bp.route('/api/audits/<int:audit_id>/cancel', methods=['POST'])
@require_auth_and_permission('run_audits')
def cancel_audit_execution(audit_id):
    """Cancel a running audit execution"""
    try:
        from models.database import AuditExecution, db
        from datetime import datetime

        execution = db.session.query(AuditExecution).filter_by(id=audit_id).first()
        if not execution:
            return jsonify({"success": False, "error": "Execution not found"}), 404

        if execution.status not in ['pending', 'running']:
            return jsonify({
                "success": False,
                "error": f"Cannot cancel execution with status '{execution.status}'"
            }), 400

        # Update status to cancelled
        execution.status = 'cancelled'
        execution.completed_at = datetime.utcnow()
        db.session.commit()

        # If using Celery, would revoke the task here
        # celery.control.revoke(execution.task_id, terminate=True)

        return jsonify({
            "success": True,
            "id": execution.id,
            "status": execution.status
        })
    except Exception as e:
        logger.error(f"Error cancelling audit {audit_id}: {e}")
        return safe_error_response(e, custom_message="Failed to cancel audit")


# ============================================================================
# Plan Management
# ============================================================================
@audit_bp.route('/api/audits/update', methods=['POST'])
@require_auth_and_permission('edit_settings')
def update_audit_scripts():
    """Update audit scripts by running update_audits.py"""
    try:
        update_script = Path(ROOT_DIR) / 'scripts' / 'update_audits.py'
        if not update_script.exists():
            return jsonify({"success": False, "error": "Update script not found."}), 404
        # Run update script as subprocess
        python_exec = shutil.which('python') or shutil.which('python3') or 'python'
        result = subprocess.run([  # nosec
            python_exec, str(update_script)
        ], capture_output=True, text=True)  # executable resolved from PATH and script path is trusted
        if result.returncode == 0:
            return jsonify({
                "success": True,
                "message": "Audit scripts updated successfully.",
                "output": result.stdout
            })
        else:
            return jsonify({
                "success": False,
                "error": "Update failed.",
                "output": result.stdout + result.stderr
            }), 500
    except Exception as e:
        logger.error(f"Error updating audit scripts: {e}")
        return safe_error_response(e, custom_message="Failed to update audit scripts")


# ============================================================================
# Git-Based Audit Updates
# ============================================================================
@audit_bp.route('/api/audits/git/status', methods=['GET'])
@require_auth_and_permission('view_audits')
def get_git_audit_status():
    """Get Git repository status for audit scripts"""
    try:
        from scripts.git_update_audits import get_git_status, get_audit_file_stats, check_git_available

        if not check_git_available():
            return jsonify({
                "success": False,
                "error": "Git is not available on this system"
            }), 500

        status = get_git_status()
        stats = get_audit_file_stats()

        return jsonify({
            "success": True,
            "git_status": status,
            "audit_stats": stats
        })
    except ImportError:
        return jsonify({"success": False, "error": "Git update module not found"}), 500
    except Exception as e:
        logger.error(f"Error getting git status: {e}")
        return jsonify({"success": False, "error": "Failed to get git status"}), 500


@audit_bp.route('/api/audits/git/check', methods=['GET'])
@require_auth_and_permission('view_audits')
def check_git_audit_updates():
    """Check for available audit script updates from Git"""
    try:
        from scripts.git_update_audits import check_for_audit_updates, check_git_available

        if not check_git_available():
            return jsonify({
                "success": False,
                "error": "Git is not available on this system"
            }), 500

        updates = check_for_audit_updates()

        return jsonify({
            "success": True,
            "has_updates": updates.get('has_updates', False),
            "total_changes": updates.get('total_changes', 0),
            "bash_scripts": updates.get('bash_scripts', []),
            "powershell_scripts": updates.get('powershell_scripts', []),
            "changed_files": updates.get('changed_files', [])
        })
    except ImportError:
        return jsonify({"success": False, "error": "Git update module not found"}), 500
    except Exception as e:
        logger.error(f"Error checking for updates: {e}")
        return jsonify({"success": False, "error": "Failed to check for updates"}), 500


@audit_bp.route('/api/audits/git/pull', methods=['POST'])
@require_auth_and_permission('edit_settings')
@conditional_limit("5 per hour")
def pull_git_audit_updates():
    """Pull audit script updates from Git repository"""
    try:
        from scripts.git_update_audits import pull_audit_updates, check_git_available

        if not check_git_available():
            return jsonify({
                "success": False,
                "error": "Git is not available on this system"
            }), 500

        data = request.json or {}
        force = data.get('force', False)

        # OWASP: Input validation - ensure force is boolean
        if not isinstance(force, bool):
            force = str(force).lower() in ('true', '1', 'yes')

        result = pull_audit_updates(force=force)

        if result['success']:
            # Refresh audit cache after update
            audit_manager.discover_audits(force_refresh=True)

        return jsonify(result)
    except ImportError:
        return jsonify({"success": False, "error": "Git update module not found"}), 500
    except Exception as e:
        logger.error(f"Error pulling updates: {e}")
        return jsonify({"success": False, "error": "Failed to pull updates"}), 500


@audit_bp.route('/api/plans')
@require_auth_and_permission('view_audits')
def get_plans():
    """Get available plan files"""
    try:
        plans = []
        if PLANS_DIR.exists():
            for plan_file in PLANS_DIR.glob("*.plan"):
                plans.append({
                    "name": plan_file.stem,
                    "path": str(plan_file.relative_to(ROOT_DIR)),
                    "modified": datetime.fromtimestamp(plan_file.stat().st_mtime).isoformat()
                })
        return jsonify({"success": True, "plans": sorted(plans, key=lambda x: x["modified"], reverse=True)})
    except Exception as e:
        logger.error(f"Error loading plans: {e}")
        return safe_error_response(e, custom_message="Failed to load plans")


@audit_bp.route('/api/plans/save', methods=['POST'])
@require_auth_and_permission('create_plans')
@conditional_limit("20 per hour")
def save_plan():
    """Save audit selection as plan file"""
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        plan_name = data.get("name", "custom-plan")
        paths = data.get("paths", [])

        if not paths or not isinstance(paths, list):
            return jsonify({"success": False, "error": "No audits selected"}), 400

        # Validate plan name
        if not plan_name or len(plan_name) > 100:
            return jsonify({"success": False, "error": "Invalid plan name"}), 400

        # Sanitize filename (strict)
        safe_name = "".join(c for c in plan_name if c.isalnum() or c in ('-', '_')).lower()
        if not safe_name:
            return jsonify({"success": False, "error": "Invalid plan name"}), 400

        # Validate all paths
        for path in paths:
            if not validate_path(path, ROOT_DIR):
                return jsonify({"success": False, "error": "Invalid audit path"}), 400

        plan_file = PLANS_DIR / f"{safe_name}.plan"
        plan_file.write_text("\n".join(paths))

        return jsonify({
            "success": True,
            "message": "Plan saved successfully",
            "path": str(plan_file.relative_to(ROOT_DIR))
        })
    except Exception as e:
        logger.error(f"Error saving plan: {e}")
        return safe_error_response(e, custom_message="Failed to save plan")
