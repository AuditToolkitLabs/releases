"""
Admin Authentication Management Routes

Provides unified admin endpoints for managing all authentication providers:
- Authentication status overview
- MFA management (force reset, require for roles)
- SSO provider configuration status
- User authentication statistics

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request, g
from flask_login import login_required, current_user
from sqlalchemy import func
from sqlalchemy.orm import Session as DBSession

from auth_core import require_role
from logging_utils import log_audit

logger = logging.getLogger(__name__)

# Blueprint
auth_admin_bp = Blueprint("auth_admin", __name__, url_prefix="/api/admin/auth")


# =============================================================================
# Helper Functions
# =============================================================================


def _get_db() -> DBSession:
    """Get database session from Flask g object"""
    return g.db


def _is_admin() -> bool:
    """Check if current user is admin or superadmin (hierarchy-aware).

    With the refactored has_role() that implements role hierarchy,
    an Admin check now automatically allows SuperAdmin.
    """
    if not current_user.is_authenticated:
        return False
    return current_user.has_role('Admin')


def _is_superadmin() -> bool:
    """Check if current user is superadmin only (strict check).

    This is used for operations that ONLY SuperAdmin should perform,
    deliberately NOT using hierarchy.
    """
    if not current_user.is_authenticated:
        return False
    return current_user.role == 'SuperAdmin'


# =============================================================================
# Authentication Provider Status
# =============================================================================


@auth_admin_bp.route("/providers/status")
@login_required
@require_role('Admin')
def auth_providers_status():
    """
    Get status of all authentication providers (requires Admin+ role).

    Returns unified view of:
    - Local auth status
    - LDAP status
    - Entra ID status
    - Okta status
    - MFA status
    """
    try:
        status = {
            "local": {
                "enabled": True,
                "name": "Local Authentication",
                "description": "Username/password stored in database",
            },
            "ldap": _get_ldap_status(),
            "entra": _get_entra_status(),
            "okta": _get_okta_status(),
            "mfa": _get_mfa_status(),
        }

        log_audit(
            action='view_auth_provider_status',
            resource_type='authentication_provider',
            details={'providers_count': len(status)},
            success=True
        )

        return jsonify(status)
    except Exception as e:
        log_audit(
            action='view_auth_provider_status',
            resource_type='authentication_provider',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to retrieve provider status: {str(e)}"}), 500


def _get_ldap_status() -> dict:
    """Get LDAP provider status"""
    try:
        from auth.ldap_auth import get_ldap_auth, LDAP3_AVAILABLE
        ldap = get_ldap_auth()

        if not LDAP3_AVAILABLE:
            return {
                "available": False,
                "enabled": False,
                "name": "LDAP / Active Directory",
                "error": "ldap3 library not installed",
            }

        if not ldap:
            return {
                "available": True,
                "enabled": False,
                "name": "LDAP / Active Directory",
                "configured": False,
            }

        return {
            "available": True,
            "enabled": ldap.config.enabled,
            "name": "LDAP / Active Directory",
            "configured": ldap.config.enabled,
            "server": ldap.config.server if ldap.config.enabled else None,
            "use_ssl": ldap.config.use_ssl if ldap.config.enabled else None,
        }
    except Exception as e:
        logger.warning(f"Error getting LDAP status: {e}")
        return {
            "available": False,
            "enabled": False,
            "name": "LDAP / Active Directory",
            "error": str(e),
        }


def _get_entra_status() -> dict:
    """Get Entra ID provider status"""
    try:
        from auth.entra_auth import get_entra_auth, MSAL_AVAILABLE

        if not MSAL_AVAILABLE:
            return {
                "available": False,
                "enabled": False,
                "name": "Microsoft Entra ID",
                "error": "msal library not installed",
            }

        entra = get_entra_auth()
        if not entra:
            return {
                "available": True,
                "enabled": False,
                "name": "Microsoft Entra ID",
                "configured": False,
            }

        return {
            "available": True,
            "enabled": entra.enabled,
            "name": "Microsoft Entra ID",
            "configured": entra.enabled,
            "tenant_id": entra.config.tenant_id[:8] + "..." if entra.config.tenant_id else None,
        }
    except Exception as e:
        logger.warning(f"Error getting Entra status: {e}")
        return {
            "available": False,
            "enabled": False,
            "name": "Microsoft Entra ID",
            "error": str(e),
        }


def _get_okta_status() -> dict:
    """Get Okta provider status"""
    try:
        from auth.okta import get_okta_auth, AUTHLIB_AVAILABLE

        if not AUTHLIB_AVAILABLE:
            return {
                "available": False,
                "enabled": False,
                "name": "Okta OIDC",
                "error": "authlib library not installed",
            }

        okta = get_okta_auth()
        if not okta:
            return {
                "available": True,
                "enabled": False,
                "name": "Okta OIDC",
                "configured": False,
            }

        return {
            "available": True,
            "enabled": okta.enabled,
            "name": "Okta OIDC",
            "configured": okta.enabled,
            "domain": okta.config.domain if okta.config.enabled else None,
        }
    except Exception as e:
        logger.warning(f"Error getting Okta status: {e}")
        return {
            "available": False,
            "enabled": False,
            "name": "Okta OIDC",
            "error": str(e),
        }


def _get_mfa_status() -> dict:
    """Get MFA status"""
    try:
        from auth.mfa import get_mfa_manager, mfa_available, qr_code_available

        if not mfa_available():
            return {
                "available": False,
                "enabled": False,
                "name": "Multi-Factor Authentication",
                "error": "pyotp library not installed",
            }

        mfa = get_mfa_manager()
        if not mfa:
            return {
                "available": True,
                "enabled": False,
                "name": "Multi-Factor Authentication",
                "configured": False,
            }

        return {
            "available": True,
            "enabled": True,
            "name": "Multi-Factor Authentication",
            "configured": True,
            "qr_code_available": qr_code_available(),
            "issuer": mfa.config.issuer,
        }
    except Exception as e:
        logger.warning(f"Error getting MFA status: {e}")
        return {
            "available": False,
            "enabled": False,
            "name": "Multi-Factor Authentication",
            "error": str(e),
        }


# =============================================================================
# User Authentication Statistics
# =============================================================================


@auth_admin_bp.route("/statistics")
@login_required
@require_role('Admin')
def auth_statistics():
    """
    Get authentication statistics (requires Admin+ role).

    Returns user counts by auth provider, MFA enrollment, etc.
    """
    try:
        from models.user import User

        db = _get_db()

        # Count users by auth provider
        provider_counts = (
            db.query(User.auth_provider, func.count(User.id))
            .group_by(User.auth_provider)
            .all()
        )
        users_by_provider = {provider or "local": count for provider, count in provider_counts}

        # Count users by role
        role_counts = (
            db.query(User.role, func.count(User.id))
            .group_by(User.role)
            .all()
        )
        users_by_role = {role: count for role, count in role_counts}

        # Count MFA enrollment
        mfa_enabled_count = db.query(User).filter(User.mfa_enabled.is_(True)).count()
        total_users = db.query(User).count()

        # Count active users (logged in within 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        active_users = db.query(User).filter(User.last_login >= thirty_days_ago).count()

        # Count inactive users
        inactive_users = db.query(User).filter(User.is_active.is_(False)).count()

        log_audit(
            action='view_auth_statistics',
            resource_type='user',
            details={
                'total_users': total_users,
                'active_users': active_users,
                'mfa_enabled': mfa_enabled_count
            },
            success=True
        )

        return jsonify({
            "total_users": total_users,
            "active_users": active_users,
            "inactive_users": inactive_users,
            "users_by_provider": users_by_provider,
            "users_by_role": users_by_role,
            "mfa": {
                "enabled_count": mfa_enabled_count,
                "enrollment_rate": round(mfa_enabled_count / total_users * 100, 1) if total_users > 0 else 0,
            },
        })
    except Exception as e:
        log_audit(
            action='view_auth_statistics',
            resource_type='user',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to retrieve statistics: {str(e)}"}), 500


# =============================================================================
# MFA Management
# =============================================================================


@auth_admin_bp.route("/mfa/users")
@login_required
@require_role('Admin')
def mfa_enrolled_users():
    """
    List all users with MFA enabled (requires Admin+ role).
    """
    try:
        from models.user import User

        db = _get_db()
        users = db.query(User).filter(User.mfa_enabled.is_(True)).all()

        log_audit(
            action='list_mfa_enrolled_users',
            resource_type='mfa_enrollment',
            details={'user_count': len(users)},
            success=True
        )

        return jsonify({
            "count": len(users),
            "users": [
                {
                    "id": u.id,
                    "username": u.username,
                    "email": u.email,
                    "role": u.role,
                    "mfa_enrolled_at": u.mfa_enrolled_at.isoformat() if u.mfa_enrolled_at else None,
                    "mfa_last_used_at": u.mfa_last_used_at.isoformat() if u.mfa_last_used_at else None,
                }
                for u in users
            ],
        })
    except Exception as e:
        log_audit(
            action='list_mfa_enrolled_users',
            resource_type='mfa_enrollment',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to list MFA users: {str(e)}"}), 500


@auth_admin_bp.route("/mfa/reset/<int:user_id>", methods=["POST"])
@login_required
@require_role('Admin')
def admin_reset_mfa(user_id: int):
    """
    Force reset MFA for a user (Admin+ role required. SuperAdmin only for admin users).

    This disables MFA for the user, requiring them to re-enroll.
    Only SuperAdmin can reset other admins' MFA.
    """
    try:
        from models.user import User

        # Ensure superadmin check if needed
        if not _is_admin():
            log_audit(
                action='reset_user_mfa',
                resource_id=str(user_id),
                resource_type='user_mfa',
                success=False,
                error='Insufficient permissions'
            )
            return jsonify({"error": "Admin access required"}), 403

        db = _get_db()
        user = db.query(User).filter(User.id == user_id).first()

        if not user:
            log_audit(
                action='reset_user_mfa',
                resource_id=str(user_id),
                resource_type='user_mfa',
                success=False,
                error='User not found'
            )
            return jsonify({"error": "User not found"}), 404

        # Check permissions
        if user.has_role('Admin') and not _is_superadmin():
            log_audit(
                action='reset_user_mfa',
                resource_id=str(user_id),
                resource_type='user_mfa',
                details={'target_user': user.username, 'target_role': user.role},
                success=False,
                error='Only SuperAdmin can reset admin MFA'
            )
            return jsonify({"error": "Only SuperAdmin can reset admin MFA"}), 403

        if not user.mfa_enabled:
            log_audit(
                action='reset_user_mfa',
                resource_id=str(user_id),
                resource_type='user_mfa',
                details={'target_user': user.username},
                success=False,
                error='User does not have MFA enabled'
            )
            return jsonify({"error": "User does not have MFA enabled"}), 400

        # Reset MFA
        user.mfa_enabled = False
        user.mfa_secret = None
        user.mfa_backup_codes = None
        user.mfa_enrolled_at = None
        user.mfa_last_used_at = None

        db.commit()

        log_audit(
            action='reset_user_mfa',
            resource_id=str(user_id),
            resource_type='user_mfa',
            details={'target_user': user.username, 'admin_user': current_user.username},
            success=True
        )

        logger.info(f"Admin {current_user.username} reset MFA for user {user.username}")

        return jsonify({
            "success": True,
            "message": f"MFA reset for user {user.username}",
        })
    except Exception as e:
        log_audit(
            action='reset_user_mfa',
            resource_id=str(user_id),
            resource_type='user_mfa',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to reset MFA: {str(e)}"}), 500


@auth_admin_bp.route("/mfa/require", methods=["POST"])
@login_required
@require_role('SuperAdmin')
def set_mfa_requirements():
    """
    Set MFA requirements (SuperAdmin only).

    Request body:
    {
        "require_for_roles": ["Admin", "SuperAdmin"],  // Roles that require MFA
        "grace_period_days": 7  // Days before MFA is enforced
    }
    """
    try:
        data = request.get_json() or {}
        require_for_roles = data.get("require_for_roles", [])
        grace_period_days = data.get("grace_period_days", 7)

        # Validate roles
        valid_roles = {"SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"}
        invalid_roles = set(require_for_roles) - valid_roles
        if invalid_roles:
            log_audit(
                action='set_mfa_requirements',
                resource_type='mfa_policy',
                success=False,
                error=f'Invalid roles: {invalid_roles}'
            )
            return jsonify({"error": f"Invalid roles: {invalid_roles}"}), 400

        # Store in app config or database settings
        # For now, log the configuration (actual storage TBD based on settings system)
        logger.info(
            f"MFA requirements updated by {current_user.username}: "
            f"roles={require_for_roles}, grace_period={grace_period_days} days"
        )

        log_audit(
            action='set_mfa_requirements',
            resource_type='mfa_policy',
            details={
                'require_for_roles': require_for_roles,
                'grace_period_days': grace_period_days
            },
            success=True
        )

        return jsonify({
            "success": True,
            "message": "MFA requirements updated",
            "require_for_roles": require_for_roles,
            "grace_period_days": grace_period_days,
        })
    except Exception as e:
        log_audit(
            action='set_mfa_requirements',
            resource_type='mfa_policy',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to update MFA requirements: {str(e)}"}), 500


# =============================================================================
# User Authentication Provider Management
# =============================================================================


@auth_admin_bp.route("/users")
@login_required
@require_role('Admin')
def list_users_by_provider():
    """
    List all users grouped by authentication provider (requires Admin+ role).
    """
    try:
        from models.user import User

        db = _get_db()

        # Get optional filter
        provider_filter = request.args.get("provider")

        query = db.query(User)
        if provider_filter:
            query = query.filter(User.auth_provider == provider_filter)

        users = query.order_by(User.auth_provider, User.username).all()

        # Group by provider
        by_provider = {}
        for user in users:
            provider = user.auth_provider or "local"
            if provider not in by_provider:
                by_provider[provider] = []
            by_provider[provider].append({
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "display_name": user.display_name,
                "role": user.role,
                "is_active": user.is_active,
                "mfa_enabled": user.mfa_enabled,
                "external_id": user.external_id,
                "last_login": user.last_login.isoformat() if user.last_login else None,
            })

        log_audit(
            action='list_users_by_provider',
            resource_type='user',
            details={
                'total_users': len(users),
                'provider_filter': provider_filter,
                'providers_found': len(by_provider)
            },
            success=True
        )

        return jsonify({
            "total": len(users),
            "by_provider": by_provider,
        })
    except Exception as e:
        log_audit(
            action='list_users_by_provider',
            resource_type='user',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to list users: {str(e)}"}), 500


@auth_admin_bp.route("/users/<int:user_id>/convert", methods=["POST"])
@login_required
@require_role('SuperAdmin')
def convert_user_auth_provider(user_id: int):
    """
    Convert a user to local authentication (SuperAdmin only).

    This removes external provider association and requires password reset.
    Useful when a user leaves SSO but needs to keep their account.
    """
    try:
        from models.user import User
        import secrets

        db = _get_db()
        user = db.query(User).filter(User.id == user_id).first()

        if not user:
            log_audit(
                action='convert_user_auth_provider',
                resource_id=str(user_id),
                resource_type='user',
                success=False,
                error='User not found'
            )
            return jsonify({"error": "User not found"}), 404

        if user.auth_provider == "local":
            log_audit(
                action='convert_user_auth_provider',
                resource_id=str(user_id),
                resource_type='user',
                details={'target_user': user.username},
                success=False,
                error='User already uses local authentication'
            )
            return jsonify({"error": "User already uses local authentication"}), 400

        old_provider = user.auth_provider

        # Convert to local
        user.auth_provider = "local"
        user.external_id = None
        user.must_change_password = True

        # Set a temporary random password (user must reset)
        temp_password = secrets.token_urlsafe(16)
        user.set_password(temp_password)

        db.commit()

        logger.info(
            f"SuperAdmin {current_user.username} converted user {user.username} "
            f"from {old_provider} to local auth"
        )

        log_audit(
            action='convert_user_auth_provider',
            resource_id=str(user_id),
            resource_type='user',
            details={
                'target_user': user.username,
                'previous_provider': old_provider,
                'admin': current_user.username
            },
            success=True
        )

        return jsonify({
            "success": True,
            "message": f"User {user.username} converted to local authentication",
            "previous_provider": old_provider,
            "temp_password": temp_password,
            "note": "User must change password on next login",
        })
    except Exception as e:
        log_audit(
            action='convert_user_auth_provider',
            resource_id=str(user_id),
            resource_type='user',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to convert user: {str(e)}"}), 500


# =============================================================================
# SSO Provider Testing
# =============================================================================


@auth_admin_bp.route("/test-all", methods=["POST"])
@login_required
@require_role('Admin')
def test_all_providers():
    """
    Test connectivity to all configured authentication providers (requires Admin+ role).
    """
    try:
        results = {
            "ldap": _test_ldap(),
            "entra": _test_entra(),
            "okta": _test_okta(),
        }

        # Calculate overall status
        all_passed = all(r.get("success", False) for r in results.values() if r.get("enabled", False))
        any_enabled = any(r.get("enabled", False) for r in results.values())

        log_audit(
            action='test_auth_providers',
            resource_type='authentication_provider',
            details={
                'providers_tested': len(results),
                'all_passed': all_passed,
                'any_enabled': any_enabled,
                'ldap_enabled': results.get('ldap', {}).get('enabled', False),
                'entra_enabled': results.get('entra', {}).get('enabled', False),
                'okta_enabled': results.get('okta', {}).get('enabled', False)
            },
            success=True
        )

        return jsonify({
            "results": results,
            "overall": "passed" if all_passed else ("partial" if any_enabled else "none_enabled"),
        })
    except Exception as e:
        log_audit(
            action='test_auth_providers',
            resource_type='authentication_provider',
            success=False,
            error=str(e)
        )
        return jsonify({"error": f"Failed to test providers: {str(e)}"}), 500


# =============================================================================
# LDAP Configuration Management
# =============================================================================


@auth_admin_bp.route("/ldap", methods=["GET"])
@login_required
@require_role('Admin')
def get_ldap_config():
    """
    Get LDAP configuration (requires Admin+ role).
    Returns current LDAP config with masked sensitive fields.
    """
    try:
        from auth.ldap_auth import get_ldap_auth, LDAP3_AVAILABLE

        if not LDAP3_AVAILABLE:
            return jsonify({
                "success": True,
                "available": False,
                "config": None,
                "message": "ldap3 library not installed"
            })

        ldap = get_ldap_auth()
        if not ldap:
            return jsonify({
                "success": True,
                "available": True,
                "config": {
                    "enabled": False,
                    "server": "",
                    "port": 389,
                    "security": "none",
                    "type": "ad",
                    "bind_dn": "",
                    "base_dn": "",
                    "user_filter": "(sAMAccountName={username})",
                    "username_attr": "sAMAccountName",
                    "email_attr": "mail",
                    "admin_group": "",
                    "analyst_group": "",
                    "allow_local": True,
                    "auto_create": True,
                    "verify_cert": True
                }
            })

        cfg = ldap.config
        return jsonify({
            "success": True,
            "available": True,
            "config": {
                "enabled": cfg.enabled,
                "server": cfg.server,
                "port": cfg.port,
                "security": "ssl" if cfg.use_ssl else "none",
                "type": "ad",
                "bind_dn": cfg.bind_dn,
                "base_dn": cfg.user_search_base,
                "user_filter": cfg.user_search_filter,
                "username_attr": "sAMAccountName",
                "email_attr": "mail",
                "admin_group": cfg.role_mapping.get("admin_group", ""),
                "analyst_group": cfg.role_mapping.get("analyst_group", ""),
                "allow_local": cfg.allow_local_fallback,
                "auto_create": True,
                "verify_cert": True
            }
        })
    except Exception as e:
        logger.error(f"Error getting LDAP config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/ldap", methods=["POST"])
@login_required
@require_role('Admin')
def save_ldap_config():
    """
    Save LDAP configuration (requires Admin+ role).
    Note: Currently LDAP config is read from environment variables.
    This endpoint returns success but config changes require server restart.
    """
    try:
        data = request.get_json()

        # Log the config change attempt
        log_audit(
            action='update_ldap_config',
            resource_type='authentication_provider',
            details={'enabled': data.get('enabled', False)},
            success=True
        )

        # Return success - in production, this would persist to config file
        return jsonify({
            "success": True,
            "message": "LDAP configuration noted. Note: LDAP settings are currently configured via environment variables. Changes will require updating environment and restarting the server."
        })
    except Exception as e:
        logger.error(f"Error saving LDAP config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/ldap/test", methods=["POST"])
@login_required
@require_role('Admin')
def test_ldap_config():
    """
    Test LDAP connection (requires Admin+ role).
    """
    try:
        from auth.ldap_auth import get_ldap_auth, LDAP3_AVAILABLE

        if not LDAP3_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "ldap3 library not installed"
            }), 400

        ldap = get_ldap_auth()
        if not ldap:
            return jsonify({
                "success": False,
                "error": "LDAP not configured"
            }), 400

        if not ldap.config.enabled:
            return jsonify({
                "success": False,
                "error": "LDAP is disabled"
            }), 400

        success, message = ldap.test_connection()

        log_audit(
            action='test_ldap_connection',
            resource_type='authentication_provider',
            details={'result': 'success' if success else 'failed'},
            success=success
        )

        if success:
            return jsonify({"success": True, "message": message})
        else:
            return jsonify({"success": False, "error": message}), 400
    except Exception as e:
        logger.error(f"Error testing LDAP: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# =============================================================================
# Microsoft Entra ID Configuration Management
# =============================================================================


@auth_admin_bp.route("/entra", methods=["GET"])
@login_required
@require_role('Admin')
def get_entra_config():
    """
    Get Microsoft Entra ID configuration (requires Admin+ role).
    Returns current Entra config with masked sensitive fields.
    """
    try:
        from auth.entra_auth import get_entra_auth, MSAL_AVAILABLE

        if not MSAL_AVAILABLE:
            return jsonify({
                "success": True,
                "available": False,
                "config": None,
                "message": "msal library not installed"
            })

        entra = get_entra_auth()
        if not entra:
            return jsonify({
                "success": True,
                "available": True,
                "config": {
                    "enabled": False,
                    "tenant_id": "",
                    "client_id": "",
                    "redirect_uri": "",
                    "admin_group": "",
                    "analyst_group": "",
                    "allow_local": True,
                    "auto_create": True
                }
            })

        cfg = entra.config
        return jsonify({
            "success": True,
            "available": True,
            "config": {
                "enabled": entra.enabled,
                "tenant_id": cfg.tenant_id,
                "client_id": cfg.client_id,
                "redirect_uri": cfg.redirect_uri,
                "admin_group": cfg.role_mapping.get("admin_group", "") if cfg.role_mapping else "",
                "analyst_group": cfg.role_mapping.get("analyst_group", "") if cfg.role_mapping else "",
                "allow_local": True,
                "auto_create": True
            }
        })
    except Exception as e:
        logger.error(f"Error getting Entra config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/entra", methods=["POST"])
@login_required
@require_role('Admin')
def save_entra_config():
    """
    Save Microsoft Entra ID configuration (requires Admin+ role).
    Note: Currently Entra config is read from environment variables.
    This endpoint returns success but config changes require server restart.
    """
    try:
        data = request.get_json()

        # Log the config change attempt
        log_audit(
            action='update_entra_config',
            resource_type='authentication_provider',
            details={'enabled': data.get('enabled', False)},
            success=True
        )

        # Return success - in production, this would persist to config file
        return jsonify({
            "success": True,
            "message": "Entra ID configuration noted. Note: Entra settings are currently configured via environment variables. Changes will require updating environment and restarting the server."
        })
    except Exception as e:
        logger.error(f"Error saving Entra config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/entra/test", methods=["POST"])
@login_required
@require_role('Admin')
def test_entra_config():
    """
    Test Microsoft Entra ID connection (requires Admin+ role).
    """
    try:
        from auth.entra_auth import get_entra_auth, MSAL_AVAILABLE

        if not MSAL_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "msal library not installed"
            }), 400

        entra = get_entra_auth()
        if not entra:
            return jsonify({
                "success": False,
                "error": "Entra ID not configured"
            }), 400

        if not entra.enabled:
            return jsonify({
                "success": False,
                "error": "Entra ID is disabled"
            }), 400

        success, message = entra.test_connection()

        log_audit(
            action='test_entra_connection',
            resource_type='authentication_provider',
            details={'result': 'success' if success else 'failed'},
            success=success
        )

        if success:
            return jsonify({"success": True, "message": message})
        else:
            return jsonify({"success": False, "error": message}), 400
    except Exception as e:
        logger.error(f"Error testing Entra ID: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# =============================================================================
# Break-Glass Admin Management
# =============================================================================


@auth_admin_bp.route("/break-glass/status", methods=["GET"])
@login_required
@require_role('SuperAdmin')
def break_glass_status():
    """
    Check status of the break-glass (default) admin account.

    Only SuperAdmin can access this information.

    Returns:
        - exists: Whether break-glass account exists
        - is_active: Whether the account is currently active
        - can_disable: Whether it's safe to disable
        - last_login: Last login timestamp
        - usage_since_setup: Number of logins after other admins were created
    """
    try:
        from models.user import User, AuthAuditLog, can_disable_break_glass

        db = _get_db()

        # Find the break-glass account
        break_glass = db.query(User).filter(User.is_builtin_admin.is_(True)).first()

        if not break_glass:
            return jsonify({
                "success": True,
                "exists": False,
                "message": "No break-glass account found"
            })

        # Check if it can be disabled
        can_disable, reason = can_disable_break_glass(db, break_glass.id)

        # Count post-setup usage
        usage_count = db.query(AuthAuditLog).filter(
            AuthAuditLog.user_id == break_glass.id,
            AuthAuditLog.event_type == 'break_glass_access'
        ).count()

        return jsonify({
            "success": True,
            "exists": True,
            "account": {
                "id": break_glass.id,
                "username": break_glass.username,
                "is_active": break_glass.is_active,
                "must_change_password": break_glass.must_change_password,
                "last_login": break_glass.last_login_at.isoformat() if break_glass.last_login_at else None,
                "created_at": break_glass.created_at.isoformat() if break_glass.created_at else None,
            },
            "can_disable": can_disable,
            "disable_reason": reason,
            "post_setup_usage_count": usage_count
        })
    except Exception as e:
        logger.error(f"Error checking break-glass status: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/break-glass/disable", methods=["POST"])
@login_required
@require_role('SuperAdmin')
def disable_break_glass():
    """
    Disable the break-glass (default) admin account.

    SECURITY REQUIREMENTS:
    - Must be SuperAdmin to perform this action
    - At least one OTHER active SuperAdmin must exist
    - That SuperAdmin must have logged in at least once

    This is a safety measure to prevent lockout.
    """
    try:
        from models.user import User, disable_break_glass_account

        db = _get_db()

        # Find the break-glass account
        break_glass = db.query(User).filter(User.is_builtin_admin.is_(True)).first()

        if not break_glass:
            return jsonify({
                "success": False,
                "error": "No break-glass account found"
            }), 404

        if break_glass.id == current_user.id:
            return jsonify({
                "success": False,
                "error": "Cannot disable your own account"
            }), 403

        # Attempt to disable
        success, message = disable_break_glass_account(db, break_glass.id, current_user.id)

        if success:
            log_audit(
                action='disable_break_glass_admin',
                resource_type='user_account',
                resource_id=break_glass.id,
                details={'disabled_by': current_user.id, 'reason': message},
                success=True
            )
            return jsonify({"success": True, "message": message})
        else:
            return jsonify({"success": False, "error": message}), 400

    except Exception as e:
        logger.error(f"Error disabling break-glass account: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@auth_admin_bp.route("/break-glass/enable", methods=["POST"])
@login_required
@require_role('SuperAdmin')
def enable_break_glass():
    """
    Re-enable the break-glass (default) admin account.

    This is an emergency recovery function. Only SuperAdmin can do this.
    The account will still require a password change on first use.
    """
    try:
        from models.user import User

        db = _get_db()

        # Find the break-glass account
        break_glass = db.query(User).filter(User.is_builtin_admin.is_(True)).first()

        if not break_glass:
            return jsonify({
                "success": False,
                "error": "No break-glass account found"
            }), 404

        if break_glass.is_active:
            return jsonify({
                "success": False,
                "error": "Break-glass account is already active"
            }), 400

        # Re-enable the account
        break_glass.is_active = True
        break_glass.must_change_password = True  # Force password change
        db.commit()

        log_audit(
            action='enable_break_glass_admin',
            resource_type='user_account',
            resource_id=break_glass.id,
            details={'enabled_by': current_user.id},
            success=True
        )

        logger.warning(f"Break-glass admin re-enabled by user {current_user.id}")

        return jsonify({
            "success": True,
            "message": "Break-glass account re-enabled. Password change required on first login."
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error enabling break-glass account: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# =============================================================================
# Private Helper Functions
# =============================================================================


def _test_ldap() -> dict:
    """Test LDAP connection"""
    try:
        from auth.ldap_auth import get_ldap_auth
        ldap = get_ldap_auth()

        if not ldap or not ldap.config.enabled:
            return {"enabled": False, "success": False, "message": "LDAP not configured"}

        success, message = ldap.test_connection()
        return {"enabled": True, "success": success, "message": message}
    except Exception as e:
        return {"enabled": False, "success": False, "message": str(e)}


def _test_entra() -> dict:
    """Test Entra ID connection"""
    try:
        from auth.entra_auth import get_entra_auth
        entra = get_entra_auth()

        if not entra or not entra.enabled:
            return {"enabled": False, "success": False, "message": "Entra ID not configured"}

        success, message = entra.test_connection()
        return {"enabled": True, "success": success, "message": message}
    except Exception as e:
        return {"enabled": False, "success": False, "message": str(e)}


def _test_okta() -> dict:
    """Test Okta connection"""
    try:
        from auth.okta import get_okta_auth
        okta = get_okta_auth()

        if not okta or not okta.enabled:
            return {"enabled": False, "success": False, "message": "Okta not configured"}

        success, message = okta.test_connection()
        return {"enabled": True, "success": success, "message": message}
    except Exception as e:
        return {"enabled": False, "success": False, "message": str(e)}
