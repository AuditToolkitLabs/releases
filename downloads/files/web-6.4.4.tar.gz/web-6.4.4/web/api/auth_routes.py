"""
Authentication Routes for Security Audit Toolkit

Provides:
- Login/logout endpoints
- Session management
- Password change/reset
- User profile

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import json
import logging
import markdown
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Blueprint, request, jsonify, session, redirect,
    url_for, render_template, current_app
)
from flask_login import (
    login_user, logout_user,
    login_required, current_user
)
from sqlalchemy.orm import Session as DBSession
from urllib.parse import urlparse, urljoin

from models.user import (
    User,
    UserSession,
    AuthAuditLog,
    read_initial_admin_credentials,
)
from auth_core import conditional_limit
from api.upload_rate_limits import get_login_rate_limit
from version_info import get_toolkit_version

# LDAP Authentication support
try:
    from auth.ldap_auth import (
        LDAPAuth, LDAPAuthError,
        get_ldap_auth, ldap_authenticate
    )
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False
    LDAPAuth = None
    get_ldap_auth = lambda: None
    ldap_authenticate = lambda u, p: None

# Entra ID (Azure AD) SSO support
try:
    from auth.entra_auth import get_entra_auth, entra_enabled
    ENTRA_AVAILABLE = True
except ImportError:
    ENTRA_AVAILABLE = False
    get_entra_auth = lambda: None
    entra_enabled = lambda: False

# Okta OIDC SSO support
try:
    from auth.okta import get_okta_auth, okta_enabled
    OKTA_AVAILABLE = True
except ImportError:
    OKTA_AVAILABLE = False
    get_okta_auth = lambda: None
    okta_enabled = lambda: False

# Disclaimer version - update this when terms change significantly
# Users will be required to re-accept when this version changes
DISCLAIMER_VERSION = get_toolkit_version()


def get_available_sso_providers() -> list:
    """
    Get list of available SSO providers for the login page.

    Returns:
        List of dicts with 'name', 'slug', 'login_url', 'icon' keys
    """
    providers = []

    # Check Entra ID
    if ENTRA_AVAILABLE and entra_enabled():
        providers.append({
            'name': 'Microsoft',
            'slug': 'entra',
            'login_url': '/auth/sso/entra/login',
            'icon': 'microsoft',
            'button_class': 'btn-microsoft',
        })

    # Check Okta
    if OKTA_AVAILABLE and okta_enabled():
        providers.append({
            'name': 'Okta',
            'slug': 'okta',
            'login_url': '/auth/sso/okta/login',
            'icon': 'okta',
            'button_class': 'btn-okta',
        })

    return providers


def is_safe_url(target):
    """
    Validate that redirect URL is safe (same origin).
    Prevents open redirect attacks.
    """
    if not target:
        return False
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc


def _is_disclaimer_accept_url(target):
    """
    Return True when target points to the disclaimer acceptance route.
    Handles both relative and absolute URLs.
    """
    if not target:
        return False

    accept_path = url_for('auth.accept_disclaimer').rstrip('/')
    parsed_target = urlparse(urljoin(request.host_url, target))
    target_path = (parsed_target.path or '').rstrip('/')
    return target_path == accept_path


def _normalize_next_url(target, default=None, disallow_disclaimer=False):
    """
    Normalize and validate redirect targets.

    - Enforces same-origin safety
    - Maps legacy `/home` to canonical home route `/`
    - Optionally blocks redirects back to disclaimer acceptance page
    """
    if not target:
        return default

    if not is_safe_url(target):
        return default

    parsed = urlparse(urljoin(request.host_url, target))
    normalized_path = (parsed.path or '/').rstrip('/') or '/'

    if normalized_path == '/home':
        normalized_path = url_for('home')

    normalized_target = normalized_path
    if parsed.query:
        normalized_target = f"{normalized_target}?{parsed.query}"

    if disallow_disclaimer and _is_disclaimer_accept_url(normalized_target):
        return default

    return normalized_target


def _get_initial_admin_login_hint():
    """
    Return initial generated admin credentials for login page display.

    This hint is shown only while the built-in admin still has
    must_change_password=True. After first successful password change,
    the credentials file is deleted and this hint disappears.
    """
    from config import get_db_session

    db = get_db_session()
    try:
        parsed_credentials = read_initial_admin_credentials()

        builtin_admin = db.query(User).filter(
            User.is_builtin_admin.is_(True),
            User.is_active.is_(True)
        ).order_by(User.id.asc()).first()

        if not builtin_admin or not builtin_admin.must_change_password:
            return None

        candidate_hints = []

        if parsed_credentials and parsed_credentials.get('username') == builtin_admin.username:
            candidate_hints.append({
                'username': parsed_credentials['username'],
                'password': parsed_credentials['password'],
            })

        env_username = (
            os.getenv('INITIAL_ADMIN_USERNAME', '').strip()
            or os.getenv('ADMIN_USERNAME', '').strip()
            or builtin_admin.username
        )

        env_password_candidates = [
            os.getenv('INITIAL_ADMIN_PASSWORD', '').strip(),
            os.getenv('ADMIN_PASSWORD', '').strip(),
            os.getenv('AUDIT_TOOLKIT_DEFAULT_INITIAL_ADMIN_PASSWORD', '').strip(),
            'ChangeMe123!',
        ]

        for env_password in env_password_candidates:
            if not env_password:
                continue
            candidate_hints.append({
                'username': env_username,
                'password': env_password,
            })

        for candidate in candidate_hints:
            if candidate['username'] != builtin_admin.username:
                continue

            # Only show a hint if it matches the live admin password hash.
            if builtin_admin.check_password(candidate['password']):
                return {
                    'username': candidate['username'],
                    'password': candidate['password'],
                }

        return None

    except Exception:
        return None
    finally:
        db.close()

logger = logging.getLogger(__name__)

# Blueprint
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')


# =============================================================================
# LDAP Authentication Helpers
# =============================================================================

def _try_ldap_auth(username: str, password: str, db: DBSession) -> tuple:
    """
    Attempt LDAP authentication with JIT user provisioning.

    Returns:
        Tuple of (user: User or None, error: str or None)
        If user is returned, authentication succeeded.
        If error is returned, LDAP auth failed with message.
        If both are None, LDAP is not enabled/available.
    """
    ldap = get_ldap_auth()
    if not ldap or not ldap.is_enabled:
        return None, None  # LDAP not enabled, try local

    try:
        ldap_user = ldap.authenticate(username, password)
        if not ldap_user:
            # LDAP auth failed - check if we should fallback to local
            if ldap.config.allow_local_fallback:
                return None, None  # Try local auth
            return None, 'Invalid username or password'  # No fallback

        # LDAP auth succeeded - JIT provision or update user
        user = db.query(User).filter(
            (User.username == username) | (User.email == ldap_user.email)
        ).first()

        if user:
            # Update existing user with LDAP info
            if user.auth_provider == 'local':
                # First LDAP login for existing local user
                user.auth_provider = 'ldap'
                user.external_id = ldap_user.dn
            elif user.auth_provider != 'ldap':
                # User is managed by different provider
                return None, 'Account is managed by a different authentication provider'

            # Update user info from LDAP
            if ldap_user.email:
                user.email = ldap_user.email
            if ldap_user.display_name:
                user.display_name = ldap_user.display_name

            # Update role based on LDAP groups
            new_role = ldap.get_role_for_user(ldap_user)
            if new_role != user.role:
                logger.info(f"Updating role for {username}: {user.role} -> {new_role}")
                user.role = new_role
        else:
            # JIT provision new user from LDAP
            new_role = ldap.get_role_for_user(ldap_user)
            user = User(
                username=ldap_user.username,
                email=ldap_user.email,
                display_name=ldap_user.display_name or ldap_user.username,
                role=new_role,
                auth_provider='ldap',
                external_id=ldap_user.dn,
                is_active=True,
                must_change_password=False  # LDAP users don't need local password change
            )
            # Set a random unusable password for LDAP users
            import secrets
            user.set_password(secrets.token_urlsafe(32))
            db.add(user)
            logger.info(f"JIT provisioned LDAP user: {username} with role {new_role}")

        db.commit()
        return user, None

    except LDAPAuthError as e:
        logger.error(f"LDAP authentication error: {e}")
        if ldap.config.allow_local_fallback:
            return None, None  # Try local auth on LDAP errors
        return None, 'Authentication service unavailable'


# =============================================================================
# RBAC Decorators
# =============================================================================

def require_role(*roles):
    """
    Decorator to require a minimum role level.

    Now hierarchy-aware: SuperAdmin passes any role check, Admin passes Admin+ checks, etc.

    Usage:
        @require_role('Admin')  # Allows Admin and SuperAdmin
        def admin_only():
            ...

        @require_role('Admin', 'Analyst')  # Allows Admin, SuperAdmin, or Analyst+
        def admin_or_analyst():
            ...
    """
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if not current_user.has_role(*roles):
                if request.is_json:
                    return jsonify({
                        'success': False,
                        'error': f'Insufficient permissions. Required role: {", ".join(roles)}'
                    }), 403
                return render_template('auth/forbidden.html',
                    required_roles=roles), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_permission(permission):
    """
    Decorator to require specific permission

    Usage:
        @require_permission('manage_users')
        def user_management():
            ...
    """
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if not current_user.has_permission(permission):
                if request.is_json:
                    return jsonify({
                        'success': False,
                        'error': f'Permission denied: {permission}'
                    }), 403
                return render_template('auth/forbidden.html',
                    required_permission=permission), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_minimum_role(minimum_role):
    """
    Decorator to require minimum role level

    Usage:
        @require_minimum_role('Analyst')
        def analyst_or_higher():
            ...
    """
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if not current_user.has_minimum_role(minimum_role):
                if request.is_json:
                    return jsonify({
                        'success': False,
                        'error': f'Minimum required role: {minimum_role}'
                    }), 403
                return render_template('auth/forbidden.html',
                    minimum_role=minimum_role), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# =============================================================================
# CSRF Token Endpoint
# =============================================================================

@auth_bp.route('/csrf-token', methods=['GET'])
def get_csrf_token():
    """Get a CSRF token for API calls"""
    import secrets
    from flask import session

    # Generate a new token if not exists
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_urlsafe(32)

    return jsonify({'csrf_token': session['csrf_token']})


@auth_bp.route('/ping', methods=['POST', 'GET'])
@login_required
def ping():
    """
    Session heartbeat/keep-alive endpoint.
    Called by the session manager to extend the session before timeout.
    Simply accessing this endpoint refreshes the session cookie.
    """
    from flask import session

    # Touch the session to refresh it
    session.modified = True

    return jsonify({
        'success': True,
        'message': 'Session extended',
        'authenticated': True,
        'username': current_user.username if hasattr(current_user, 'username') else None
    })


# =============================================================================
# Authentication Routes
# =============================================================================

@auth_bp.route('/login', methods=['GET', 'POST'])
@conditional_limit(get_login_rate_limit)  # Rate limit login attempts to prevent brute force
def login():
    """Login page and authentication endpoint"""
    from config import get_db_session
    from flask_login import logout_user

    force_login_prompt = request.args.get('force') == '1'

    initial_admin_hint = _get_initial_admin_login_hint()

    def render_login_page(error=None, next_value='', message=None):
        return render_template(
            'auth/login.html',
            sso_providers=get_available_sso_providers(),
            error=error,
            message=message,
            next_url=next_value or '',
            initial_admin_hint=initial_admin_hint,
        )

    # Check if user is authenticated
    # Note: current_user may not work if login_manager isn't fully initialized
    try:
        if current_user.is_authenticated and not force_login_prompt:
            next_url = request.args.get('next')
            if not next_url or not is_safe_url(next_url):
                next_url = url_for('home')

            if getattr(current_user, 'must_change_password', False):
                return redirect(url_for('auth.change_password', next=next_url))

            current_disclaimer_version = str(getattr(current_user, 'disclaimer_version', '') or '').strip()
            expected_disclaimer_version = str(DISCLAIMER_VERSION or '').strip()
            if not getattr(current_user, 'disclaimer_accepted_at', None) or current_disclaimer_version != expected_disclaimer_version:
                disclaimer_target = _normalize_next_url(next_url, default=url_for('home'))
                return redirect(url_for('auth.accept_disclaimer', next=disclaimer_target))

            return redirect(next_url)
    except Exception as e:
        logger.debug(f"User not logged in: {e}")

    if force_login_prompt:
        try:
            logout_user()
            session.clear()
        except Exception:
            pass

    if request.method == 'GET':
        next_url = _normalize_next_url(request.args.get('next'), default='')

        # Get available SSO providers for rendering login buttons
        sso_providers = get_available_sso_providers()
        error_msg = request.args.get('error')

        # Map error codes to messages
        error_messages = {
            'sso_failed': 'SSO authentication failed. Please try again.',
            'sso_invalid_state': 'Invalid SSO session. Please try again.',
            'sso_no_code': 'SSO authorization incomplete. Please try again.',
            'sso_not_configured': 'SSO is not configured.',
            'sso_token_error': 'SSO token error. Please try again.',  # nosec B105
            'sso_graph_error': 'Failed to get user information. Please try again.',
            'sso_unexpected_error': 'Unexpected SSO error. Please try again.',
            'account_disabled': 'Your account has been disabled.',
        }
        error = error_messages.get(error_msg)

        return render_template(
            'auth/login.html',
            sso_providers=sso_providers,
            error=error,
            next_url=next_url,
            initial_admin_hint=initial_admin_hint,
        )

    # POST - authenticate
    data = request.get_json() if request.is_json else request.form
    username = data.get('username', '').strip()
    password = data.get('password', '')
    next_url = _normalize_next_url(data.get('next') or request.args.get('next'))

    if not username or not password:
        if request.is_json:
            return jsonify({'success': False, 'error': 'Username and password required'}), 400
        return render_login_page(error='Username and password required', next_value=next_url)

    db = get_db_session()
    try:
        ip_address = request.remote_addr
        user_agent = request.headers.get('User-Agent', '')

        # =================================================================
        # BREAK-GLASS CHECK: Check if this is the built-in recovery admin
        # The break-glass account (like 'root' in Linux) ALWAYS uses local
        # authentication, regardless of LDAP/SSO settings. This ensures
        # operators can always recover access to the system.
        # =================================================================
        potential_user = db.query(User).filter(
            (User.username == username) | (User.email == username)
        ).first()

        is_break_glass = (
            potential_user and
            hasattr(potential_user, 'is_break_glass_account') and
            potential_user.is_break_glass_account()
        )

        # Try LDAP authentication first (if enabled) - but NOT for break-glass accounts
        user = None
        ldap_error = None

        if LDAP_AVAILABLE and not is_break_glass:
            user, ldap_error = _try_ldap_auth(username, password, db)

            if ldap_error:
                # LDAP auth failed with no fallback
                log_auth_event(db, None, 'failed_login', ip_address, user_agent,
                              username=username, success=False,
                              failure_reason=f'LDAP: {ldap_error}')
                if request.is_json:
                    return jsonify({'success': False, 'error': ldap_error}), 401
                return render_login_page(error=ldap_error, next_value=next_url)

            if user:
                # LDAP auth succeeded, check if account is active/locked
                if user.is_account_locked():
                    log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                                  success=False, failure_reason='Account locked')
                    if request.is_json:
                        return jsonify({'success': False, 'error': 'Account is locked. Please contact an administrator.'}), 403
                    return render_login_page(error='Account is locked. Please contact an administrator.', next_value=next_url)

                if not user.is_active:
                    log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                                  success=False, failure_reason='Account inactive')
                    if request.is_json:
                        return jsonify({'success': False, 'error': 'Account is inactive.'}), 403
                    return render_login_page(error='Account is inactive.', next_value=next_url)

        # If no LDAP user, try local authentication
        if not user:
            # Reuse the potential_user we already looked up (or query if not done)
            if potential_user:
                user = potential_user
            else:
                user = db.query(User).filter(
                    (User.username == username) | (User.email == username)
                ).first()

            # User not found
            if not user:
                log_auth_event(db, None, 'failed_login', ip_address, user_agent,
                              username=username, success=False,
                              failure_reason='User not found')
                if request.is_json:
                    return jsonify({'success': False, 'error': 'Invalid username or password'}), 401
                return render_login_page(error='Invalid username or password', next_value=next_url)

            # Check if user is managed by external provider
            # EXCEPTION: Break-glass accounts ALWAYS use local auth regardless of auth_provider
            user_is_break_glass = (
                hasattr(user, 'is_break_glass_account') and
                user.is_break_glass_account()
            )
            if user.auth_provider != 'local' and not user_is_break_glass:
                log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                              success=False, failure_reason=f'User managed by {user.auth_provider}')
                if request.is_json:
                    return jsonify({'success': False, 'error': f'Please use {user.auth_provider.upper()} to authenticate'}), 401
                return render_login_page(error=f'Please use {user.auth_provider.upper()} to authenticate', next_value=next_url)

            # Account locked
            if user.is_account_locked():
                log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                              success=False, failure_reason='Account locked')
                if request.is_json:
                    return jsonify({'success': False, 'error': 'Account is locked. Please contact an administrator.'}), 403
                return render_login_page(error='Account is locked. Please contact an administrator.', next_value=next_url)

            # Account inactive
            if not user.is_active:
                log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                              success=False, failure_reason='Account inactive')
                if request.is_json:
                    return jsonify({'success': False, 'error': 'Account is inactive.'}), 403
                return render_login_page(error='Account is inactive.', next_value=next_url)

            # Check password (local auth only)
            if not user.check_password(password):
                user.record_failed_login()
                db.commit()
                log_auth_event(db, user.id, 'failed_login', ip_address, user_agent,
                              success=False, failure_reason='Invalid password')
                if request.is_json:
                    return jsonify({'success': False, 'error': 'Invalid username or password'}), 401
                return render_login_page(error='Invalid username or password', next_value=next_url)

        # Check if MFA is required
        if user.mfa_enabled:
            # Store user ID for MFA verification step
            session['mfa_pending_user_id'] = user.id
            session['mfa_auth_provider'] = user.auth_provider

            # Store next URL for after MFA
            if next_url:
                session['next'] = next_url

            log_auth_event(db, user.id, 'mfa_challenge', ip_address, user_agent,
                          success=True)

            if request.is_json:
                return jsonify({
                    'success': True,
                    'mfa_required': True,
                    'redirect': url_for('mfa.verify_page')
                })
            return redirect(url_for('mfa.verify_page'))

        # Successful login (no MFA)
        user.record_successful_login(ip_address)

        # SECURITY: Log if break-glass account is being used
        if user.is_break_glass_account():
            from models.user import log_break_glass_usage
            log_break_glass_usage(db, user, ip_address=ip_address)

        # Create session - fixed 8 hour duration, no remember me
        session_duration = timedelta(hours=8)
        user_session = UserSession(
            id=UserSession.generate_session_id(),
            user_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent[:500] if user_agent else None,
            expires_at=datetime.utcnow() + session_duration,
        )
        db.add(user_session)
        db.commit()

        # Flask-Login - never remember, session expires when browser closes
        login_user(user, remember=False)

        # Store session ID
        session['session_id'] = user_session.id

        # Log successful login
        log_auth_event(db, user.id, 'login', ip_address, user_agent, success=True)

        logger.info(f"User '{user.username}' logged in from {ip_address}")

        # Check if password change required (forced)
        if user.must_change_password:
            if request.is_json:
                return jsonify({
                    'success': True,
                    'redirect': url_for('auth.change_password', next=next_url or ''),
                    'message': 'Password change required'
                })
            return redirect(url_for('auth.change_password', next=next_url or ''))

        # Check if password has expired
        try:
            from security_settings import get_password_policy
            policy = get_password_policy()
            expiry_days = policy.get('expiry_days', 0)
            if expiry_days > 0 and user.password_changed_at:
                expiry_date = user.password_changed_at + timedelta(days=expiry_days)
                if datetime.utcnow() > expiry_date:
                    user.must_change_password = True
                    db.commit()
                    logger.info(f"Password expired for user '{user.username}'")
                    if request.is_json:
                        return jsonify({
                            'success': True,
                            'redirect': url_for('auth.change_password', next=next_url or ''),
                            'message': 'Password has expired'
                        })
                    return redirect(url_for('auth.change_password', next=next_url or ''))
        except ImportError:
            pass  # Security settings module not available

        # Check if disclaimer needs to be accepted
        # Users must accept disclaimer on first login or when version changes
        # Normalize both sides to avoid whitespace/None mismatches (mirrors check_disclaimer_accepted)
        _stored_dv = str(user.disclaimer_version or '').strip()
        _expected_dv = str(DISCLAIMER_VERSION or '').strip()
        if not user.disclaimer_accepted_at or _stored_dv != _expected_dv:
            disclaimer_target = _normalize_next_url(next_url, default=url_for('home'))
            disclaimer_url = url_for('auth.accept_disclaimer', next=disclaimer_target)
            logger.info(f"User '{user.username}' redirected to accept disclaimer v{DISCLAIMER_VERSION}")
            if request.is_json:
                return jsonify({
                    'success': True,
                    'redirect': disclaimer_url,
                    'message': 'Please accept the terms of use to continue'
                })
            return redirect(disclaimer_url)

        # Validate next URL to prevent open redirect attacks
        next_url = _normalize_next_url(next_url, default=url_for('home'))

        if request.is_json:
            return jsonify({
                'success': True,
                'user': user.to_dict(),
                'redirect': next_url
            })
        return redirect(next_url)

    except Exception as e:
        logger.error(f"Login error: {e}")
        db.rollback()
        if request.is_json:
            return jsonify({'success': False, 'error': 'An error occurred during login'}), 500
        return render_login_page(error='An error occurred during login', next_value=next_url)
    finally:
        db.close()


@auth_bp.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    """Logout and invalidate session"""
    from config import get_db_session

    db = get_db_session()
    try:
        # Invalidate database session
        session_id = session.get('session_id')
        if session_id:
            user_session = db.query(UserSession).filter(
                UserSession.id == session_id
            ).first()
            if user_session:
                user_session.revoke()
                db.commit()

        # Log logout
        log_auth_event(db, current_user.id, 'logout', request.remote_addr,
                      request.headers.get('User-Agent'), success=True)

        username = current_user.username
        logout_user()
        session.clear()

        logger.info(f"User '{username}' logged out")

        if request.is_json:
            return jsonify({'success': True, 'message': 'Logged out successfully'})
        return redirect(url_for('home'))

    except Exception as e:
        logger.error(f"Logout error: {e}")
        db.rollback()
    finally:
        db.close()

    logout_user()
    session.clear()
    return redirect(url_for('home'))


@auth_bp.route('/view-disclaimer')
def view_disclaimer():
    """
    Display the full disclaimer as a rendered HTML page.
    This is publicly accessible (no login required).
    """
    # Read the disclaimer markdown file
    disclaimer_path = os.path.join(
        current_app.static_folder, 'DISCLAIMER.md'
    )

    disclaimer_content = ""
    if os.path.exists(disclaimer_path):
        with open(disclaimer_path, 'r', encoding='utf-8') as f:
            md_content = f.read()
            # Convert markdown to HTML server-side
            disclaimer_content = markdown.markdown(
                md_content,
                extensions=['tables', 'fenced_code', 'nl2br']
            )
    else:
        disclaimer_content = "<h1>Disclaimer</h1><p>Disclaimer content not found.</p>"

    return render_template(
        'auth/view_disclaimer.html',
        disclaimer_content=disclaimer_content,
        disclaimer_version=DISCLAIMER_VERSION
    )


@auth_bp.route('/accept-disclaimer', methods=['GET', 'POST'])
@login_required
def accept_disclaimer():
    """
    Display and handle disclaimer acceptance.
    Users must accept terms before using the application.
    """
    from config import get_db_session

    # GET: Show disclaimer acceptance page
    if request.method == 'GET':
        next_url = _normalize_next_url(
            request.args.get('next', url_for('home')),
            default=url_for('home'),
            disallow_disclaimer=True,
        )
        return render_template(
            'auth/accept_disclaimer.html',
            next_url=next_url,
            disclaimer_version=DISCLAIMER_VERSION
        )

    # POST: Process acceptance
    db = get_db_session()
    try:
        accept_terms = request.form.get('accept_terms')
        next_url = _normalize_next_url(
            request.form.get('next', url_for('home')),
            default=url_for('home'),
            disallow_disclaimer=True,
        )

        if not accept_terms:
            return render_template(
                'auth/accept_disclaimer.html',
                next_url=next_url,
                disclaimer_version=DISCLAIMER_VERSION,
                error="You must accept the terms to continue."
            )

        # Update user's disclaimer acceptance
        user = db.query(User).filter(User.id == current_user.id).first()
        if user:
            user.disclaimer_accepted_at = datetime.utcnow()
            user.disclaimer_version = DISCLAIMER_VERSION
            db.commit()

            # Refresh session principal to avoid stale disclaimer flags in
            # downstream route guards during immediate redirects.
            login_user(user, remember=False, force=True)
            session.modified = True

            # Log acceptance
            log_auth_event(
                db, user.id, 'disclaimer_accepted',
                request.remote_addr,
                request.headers.get('User-Agent'),
                success=True,
                details=f"Accepted disclaimer version {DISCLAIMER_VERSION}"
            )

            logger.info(f"User '{user.username}' accepted disclaimer v{DISCLAIMER_VERSION}")

        return redirect(next_url)

    except Exception as e:
        logger.error(f"Disclaimer acceptance error: {e}")
        db.rollback()
        return render_template(
            'auth/accept_disclaimer.html',
            next_url=request.form.get('next', url_for('home')),
            disclaimer_version=DISCLAIMER_VERSION,
            error="An error occurred. Please try again."
        )
    finally:
        db.close()


@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change password page"""
    from config import get_db_session

    if request.method == 'GET':
        next_url = request.args.get('next', '')
        return render_template('auth/change_password.html',
                               required=current_user.must_change_password,
                               next_url=next_url)

    data = request.get_json() if request.is_json else request.form
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    confirm_password = data.get('confirm_password', '')
    _post_next = data.get('next') or request.args.get('next', '')

    def _render_error(msg):
        return render_template('auth/change_password.html',
                               error=msg,
                               required=current_user.must_change_password,
                               next_url=_post_next)

    # Validate
    if not current_password or not new_password:
        error = 'Current and new password required'
        if request.is_json:
            return jsonify({'success': False, 'error': error}), 400
        return _render_error(error)

    if new_password != confirm_password:
        error = 'New passwords do not match'
        if request.is_json:
            return jsonify({'success': False, 'error': error}), 400
        return _render_error(error)

    # Password policy validation
    policy_error = validate_password_policy(new_password)
    if policy_error:
        if request.is_json:
            return jsonify({'success': False, 'error': policy_error}), 400
        return _render_error(policy_error)

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == current_user.id).first()

        # Verify current password
        if not user.check_password(current_password):
            if request.is_json:
                return jsonify({'success': False, 'error': 'Current password is incorrect'}), 401
            return _render_error('Current password is incorrect')

        # Check password history (prevent reuse)
        from models.user import PasswordHistory
        from werkzeug.security import check_password_hash

        # Get history count from security settings
        try:
            from security_settings import get_password_policy
            policy = get_password_policy()
            history_count = policy.get('history_count', 5)
        except ImportError:
            history_count = 5

        if history_count > 0:
            history = db.query(PasswordHistory).filter(
                PasswordHistory.user_id == user.id
            ).order_by(PasswordHistory.created_at.desc()).limit(history_count).all()

            for ph in history:
                if check_password_hash(ph.password_hash, new_password):
                    error = f'Cannot reuse one of your last {history_count} passwords'
                    if request.is_json:
                        return jsonify({'success': False, 'error': error}), 400
                    return _render_error(error)

        # Save current password to history
        if user.password_hash:
            history_entry = PasswordHistory(
                user_id=user.id,
                password_hash=user.password_hash
            )
            db.add(history_entry)

        # Set new password
        user.set_password(new_password)
        db.commit()

        # Built-in admin hygiene: remove bootstrap credentials file once
        # password has been changed successfully.
        if hasattr(user, 'is_break_glass_account') and user.is_break_glass_account():
            from models.user import remove_initial_admin_credentials_file
            remove_initial_admin_credentials_file()

        # Log password change
        log_auth_event(db, user.id, 'password_change', request.remote_addr,
                      request.headers.get('User-Agent'), success=True)

        logger.info(f"User '{user.username}' changed password")

        if request.is_json:
            return jsonify({'success': True, 'message': 'Password changed successfully'})

        # After a forced password change, check if disclaimer still needs to
        # be accepted (first-login sequence: change_pwd → disclaimer → destination).
        _cp_next = _normalize_next_url(
            request.form.get('next') or request.args.get('next'),
            default=url_for('home')
        )
        _cp_stored_dv = str(user.disclaimer_version or '').strip()
        _cp_expected_dv = str(DISCLAIMER_VERSION or '').strip()
        if not user.disclaimer_accepted_at or _cp_stored_dv != _cp_expected_dv:
            logger.info(
                f"User '{user.username}' redirected to accept disclaimer "
                f"v{DISCLAIMER_VERSION} after password change"
            )
            return redirect(url_for('auth.accept_disclaimer', next=_cp_next))

        return redirect(_cp_next)

    except Exception as e:
        logger.error(f"Password change error: {e}")
        db.rollback()
        if request.is_json:
            return jsonify({'success': False, 'error': 'An error occurred'}), 500
        return _render_error('An error occurred')
    finally:
        db.close()


@auth_bp.route('/profile', methods=['GET'])
@login_required
def profile():
    """User profile page"""
    return render_template('auth/profile.html', user=current_user)


@auth_bp.route('/me', methods=['GET'])
@login_required
def get_current_user():
    """Get current user info (API)"""
    return jsonify({
        'success': True,
        'user': current_user.to_dict()
    })


@auth_bp.route('/sessions', methods=['GET'])
@login_required
def list_sessions():
    """List user's active sessions"""
    from config import get_db_session

    db = get_db_session()
    try:
        sessions = db.query(UserSession).filter(
            UserSession.user_id == current_user.id,
            UserSession.is_active.is_(True)
        ).order_by(UserSession.last_active_at.desc()).all()

        current_session_id = session.get('session_id')

        return jsonify({
            'success': True,
            'sessions': [{
                'id': s.id[:8] + '...',
                'ip_address': s.ip_address,
                'device': s.device_info or 'Unknown',
                'created_at': s.created_at.isoformat(),
                'last_active': s.last_active_at.isoformat(),
                'is_current': s.id == current_session_id
            } for s in sessions]
        })
    finally:
        db.close()


@auth_bp.route('/sessions/<session_id>', methods=['DELETE'])
@login_required
def revoke_session(session_id):
    """Revoke a specific session"""
    from config import get_db_session

    db = get_db_session()
    try:
        # Find session (allowing partial ID match for security)
        user_session = db.query(UserSession).filter(
            UserSession.user_id == current_user.id,
            UserSession.id.like(f'{session_id}%')
        ).first()

        if not user_session:
            return jsonify({'success': False, 'error': 'Session not found'}), 404

        user_session.revoke()
        db.commit()

        log_auth_event(db, current_user.id, 'session_revoked', request.remote_addr,
                      request.headers.get('User-Agent'), success=True,
                      details=json.dumps({'revoked_session': session_id}))

        return jsonify({'success': True, 'message': 'Session revoked'})
    finally:
        db.close()


# =============================================================================
# Helper Functions
# =============================================================================

def log_auth_event(db, user_id, event_type, ip_address, user_agent,
                   username=None, success=True, failure_reason=None, details=None):
    """Log an authentication event"""
    try:
        log_entry = AuthAuditLog(
            user_id=user_id,
            event_type=event_type,
            username=username,
            ip_address=ip_address,
            user_agent=user_agent[:500] if user_agent else None,
            success=success,
            failure_reason=failure_reason,
            details=details,
        )
        db.add(log_entry)
        db.commit()
    except Exception as e:
        logger.error(f"Failed to log auth event: {e}")


def validate_password_policy(password, min_length=None):
    """
    Validate password against configurable policy from security settings.

    Args:
        password: The password to validate
        min_length: Override minimum length (defaults to security setting)

    Returns:
        None if valid, error message string if invalid
    """
    # Import here to avoid circular imports
    from security_settings import get_password_policy

    policy = get_password_policy()

    # Use provided min_length or fallback to policy setting
    actual_min_length = min_length if min_length is not None else policy['min_length']

    if len(password) < actual_min_length:
        return f'Password must be at least {actual_min_length} characters'

    if policy['require_uppercase'] and not any(c.isupper() for c in password):
        return 'Password must contain at least one uppercase letter'

    if not any(c.islower() for c in password):
        return 'Password must contain at least one lowercase letter'

    if policy['require_numbers'] and not any(c.isdigit() for c in password):
        return 'Password must contain at least one number'

    if policy['require_special']:
        special_chars = set('!@#$%^&*()_+-=[]{}|;:,.<>?')
        if not any(c in special_chars for c in password):
            return 'Password must contain at least one special character'

    return None


__all__ = [
    'auth_bp',
    'require_role',
    'require_permission',
    'require_minimum_role',
    'validate_password_policy',
]
