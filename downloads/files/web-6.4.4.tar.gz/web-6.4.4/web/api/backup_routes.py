#!/usr/bin/env python3
"""
Backup & Restore API Routes

RESTful API endpoints for database backup management:
- Create manual backups
- List backups
- Restore from backup
- Verify backup integrity
- Manage retention policies
- Monitor backup health

All endpoints require authentication (API key or session).

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import logging
from flask import Blueprint, request, jsonify, send_file
from pathlib import Path
from datetime import datetime
from auth_core import require_auth  # Use secure implementation from auth module

logger = logging.getLogger(__name__)

# Create Blueprint
backup_bp = Blueprint('backup', __name__, url_prefix='/api/backup')


def _backup_encryption_default() -> bool:
    """Resolve default backup encryption behavior from security settings."""
    try:
        from security_settings import get_security_setting
        return bool(get_security_setting('backup_encrypt', False))
    except Exception:
        return os.getenv('BACKUP_ENCRYPTION_ENABLED', 'false').lower() == 'true'


@backup_bp.route('/create', methods=['POST'])
@require_auth
def create_backup():
    """
    Create a new database backup

    POST /api/backup/create
    {
        "backup_type": "full",        // 'full' or 'incremental'
        "compress": true,              // Compress with gzip
        "encrypt": false,              // Encrypt backup
        "notify_on_success": false     // Send notification
    }

    Returns:
        201: Backup created successfully
        400: Invalid request parameters
        500: Backup creation failed
    """
    try:
        data = request.get_json() or {}

        backup_type = data.get('backup_type', 'full')
        compress = data.get('compress', True)
        encrypt = data.get('encrypt', _backup_encryption_default())
        notify_on_success = data.get('notify_on_success', False)

        # Validate backup_type
        if backup_type not in ['full', 'incremental']:
            return jsonify({'error': 'Invalid backup_type. Must be "full" or "incremental"'}), 400

        # Create backup
        from backup_manager import BackupManager
        manager = BackupManager()

        backup_info = manager.create_backup(
            backup_type=backup_type,
            compress=compress,
            encrypt=encrypt,
            include_metadata=True
        )

        # Send notification if requested
        if notify_on_success:
            try:
                from error_notifier import get_error_notifier
                notifier = get_error_notifier()
                notifier._send_email(
                    subject="Manual Backup Created",
                    body=f"Backup {backup_info['filename']} created successfully"
                )
            except Exception as e:
                logger.warning(f"Failed to send notification: {e}")

        logger.info(f"Manual backup created via API: {backup_info['filename']}")

        return jsonify({
            'status': 'success',
            'success': True,
            'message': 'Backup created successfully',
            'backup': backup_info
        }), 201

    except Exception as e:
        logger.error(f"Backup creation failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'success': False,
            'error': str(e)
        }), 500


@backup_bp.route('/list', methods=['GET'])
@require_auth
def list_backups():
    """
    List available backups

    GET /api/backup/list?limit=50

    Returns:
        200: List of backups
        500: Failed to list backups
    """
    try:
        limit = int(request.args.get('limit', 50))

        from backup_manager import BackupManager
        manager = BackupManager()

        backups = manager.list_backups(limit=limit)

        return jsonify({
            'status': 'success',
            'count': len(backups),
            'backups': backups
        }), 200

    except Exception as e:
        logger.error(f"Failed to list backups: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/download/<filename>', methods=['GET'])
@require_auth
def download_backup(filename):
    """
    Download a backup file

    GET /api/backup/download/<filename>

    Returns:
        200: Backup file
        404: Backup not found
        500: Download failed
    """
    try:
        from backup_manager import BackupManager
        manager = BackupManager()

        backup_file = manager.backup_dir / filename

        if not backup_file.exists():
            return jsonify({'error': 'Backup not found'}), 404

        # Security check: ensure file is within backup directory
        if not str(backup_file.resolve()).startswith(str(manager.backup_dir.resolve())):
            return jsonify({'error': 'Invalid backup path'}), 400

        logger.info(f"Backup downloaded via API: {filename}")

        return send_file(
            backup_file,
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        logger.error(f"Backup download failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/restore', methods=['POST'])
@require_auth
def restore_backup():
    """
    Restore database from backup

    POST /api/backup/restore
    {
        "backup_file": "backup_full_20260206_120000.sql.gz",
        "verify_checksum": true,
        "create_backup_before_restore": true
    }

    WARNING: This will replace the current database!

    Returns:
        200: Restore successful
        400: Invalid request
        404: Backup not found
        500: Restore failed
    """
    try:
        data = request.get_json() or {}

        backup_file = data.get('backup_file')
        if not backup_file:
            return jsonify({'error': 'Missing backup_file parameter'}), 400

        verify_checksum = data.get('verify_checksum', True)
        create_backup_before_restore = data.get('create_backup_before_restore', True)

        from backup_manager import BackupManager
        manager = BackupManager()

        backup_path = manager.backup_dir / backup_file

        if not backup_path.exists():
            return jsonify({'error': 'Backup file not found'}), 404

        # Perform restore
        restore_info = manager.restore_backup(
            backup_path=str(backup_path),
            verify_checksum=verify_checksum,
            create_backup_before_restore=create_backup_before_restore
        )

        logger.warning(f"Database restored via API from: {backup_file}")

        return jsonify({
            'status': 'success',
            'message': 'Database restored successfully',
            'restore': restore_info
        }), 200

    except FileNotFoundError as e:
        return jsonify({
            'status': 'error',
            'error': 'Backup file not found'
        }), 404
    except Exception as e:
        logger.error(f"Restore failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/verify/<filename>', methods=['GET'])
@require_auth
def verify_backup(filename):
    """
    Verify backup integrity

    GET /api/backup/verify/<filename>

    Returns:
        200: Verification result
        404: Backup not found
        500: Verification failed
    """
    try:
        from backup_manager import BackupManager
        manager = BackupManager()

        backup_path = manager.backup_dir / filename

        if not backup_path.exists():
            return jsonify({'error': 'Backup not found'}), 404

        verification = manager.verify_backup(str(backup_path))

        status_code = 200 if verification['valid'] else 400

        return jsonify({
            'status': 'success' if verification['valid'] else 'invalid',
            'verification': verification
        }), status_code

    except Exception as e:
        logger.error(f"Verification failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/cleanup', methods=['POST'])
@require_auth
def cleanup_backups():
    """
    Clean up old backups

    POST /api/backup/cleanup
    {
        "retention_days": 30,
        "keep_count": 10
    }

    Returns:
        200: Cleanup completed
        500: Cleanup failed
    """
    try:
        data = request.get_json() or {}

        retention_days = data.get('retention_days', 30)
        keep_count = data.get('keep_count', 10)

        from backup_manager import BackupManager
        manager = BackupManager()

        result = manager.cleanup_old_backups(
            retention_days=retention_days,
            keep_count=keep_count
        )

        logger.info(f"Backup cleanup via API: removed {result['removed']}, kept {result['kept']}")

        return jsonify({
            'status': 'success',
            'success': True,
            'message': 'Cleanup completed',
            'deleted_count': result.get('removed', 0),
            'result': result
        }), 200

    except Exception as e:
        logger.error(f"Cleanup failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'success': False,
            'error': str(e)
        }), 500


@backup_bp.route('/delete/<filename>', methods=['DELETE'])
@require_auth
def delete_backup(filename):
    """
    Delete a specific backup file

    DELETE /api/backup/delete/<filename>

    Returns:
        200: Backup deleted successfully
        404: Backup not found
        500: Delete failed
    """
    try:
        from backup_manager import BackupManager
        manager = BackupManager()

        backup_file = manager.backup_dir / filename

        # Security check: ensure file is within backup directory
        if not str(backup_file.resolve()).startswith(str(manager.backup_dir.resolve())):
            return jsonify({'success': False, 'error': 'Invalid backup path'}), 400

        if not backup_file.exists():
            return jsonify({'success': False, 'error': 'Backup not found'}), 404

        # Delete the backup file
        backup_file.unlink()

        logger.info(f"Backup deleted via API: {filename}")

        return jsonify({
            'success': True,
            'message': f'Backup {filename} deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to delete backup {filename}: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@backup_bp.route('/health', methods=['GET'])
@require_auth
def backup_health():
    """
    Check backup system health

    GET /api/backup/health

    Returns:
        200: Health status
        500: Health check failed
    """
    try:
        from tasks.backup_tasks import backup_health_check

        health = backup_health_check()

        status_code = 200 if health['status'] in ['healthy', 'warning'] else 503

        return jsonify({
            'status': 'success',
            'health': health
        }), status_code

    except Exception as e:
        logger.error(f"Health check failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/schedule', methods=['GET'])
@require_auth
def get_backup_schedule():
    """
    Get current backup schedule configuration

    GET /api/backup/schedule

    Returns:
        200: Schedule configuration
    """
    schedule = {
        'daily_backup': {
            'enabled': True,
            'time': '02:00',
            'type': 'full',
            'compress': True,
            'encrypt': _backup_encryption_default()
        },
        'weekly_backup': {
            'enabled': True,
            'day': 'Sunday',
            'time': '03:00',
            'type': 'full',
            'compress': True,
            'encrypt': True
        },
        'cleanup': {
            'enabled': True,
            'time': '04:00',
            'retention_days': int(os.getenv('BACKUP_RETENTION_DAYS', '30')),
            'keep_count': int(os.getenv('BACKUP_KEEP_COUNT', '10'))
        },
        'verification': {
            'enabled': True,
            'time': '05:00',
            'limit': 5
        },
        'health_check': {
            'enabled': True,
            'interval_minutes': 30
        }
    }

    return jsonify({
        'status': 'success',
        'schedule': schedule
    }), 200


@backup_bp.route('/stats', methods=['GET'])
@require_auth
def backup_stats():
    """
    Get backup statistics

    GET /api/backup/stats

    Returns:
        200: Backup statistics
        500: Failed to get statistics
    """
    try:
        from backup_manager import BackupManager
        manager = BackupManager()

        backups = manager.list_backups(limit=1000)

        # Calculate statistics
        total_size = sum(b.get('size_bytes', 0) for b in backups)

        by_type = {}
        by_database = {}

        for backup in backups:
            backup_type = backup.get('backup_type', 'unknown')
            db_type = backup.get('database_type', 'unknown')

            by_type[backup_type] = by_type.get(backup_type, 0) + 1
            by_database[db_type] = by_database.get(db_type, 0) + 1

        # Find oldest and newest
        oldest = None
        newest = None

        if backups:
            timestamps = [datetime.fromisoformat(b.get('timestamp', '1970-01-01')) for b in backups if b.get('timestamp')]
            if timestamps:
                oldest = min(timestamps).isoformat()
                newest = max(timestamps).isoformat()

        stats = {
            'total_backups': len(backups),
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024**2), 2),
            'total_size_gb': round(total_size / (1024**3), 2),
            'by_type': by_type,
            'by_database': by_database,
            'oldest_backup': oldest,
            'newest_backup': newest,
            'backup_directory': str(manager.backup_dir)
        }

        return jsonify({
            'status': 'success',
            'stats': stats
        }), 200

    except Exception as e:
        logger.error(f"Failed to get statistics: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/trigger/verify', methods=['POST'])
@require_auth
def trigger_verify():
    """
    Manually trigger backup verification

    POST /api/backup/trigger/verify
    {
        "limit": 5
    }

    Returns:
        202: Verification started
        500: Failed to start verification
    """
    try:
        data = request.get_json() or {}
        limit = data.get('limit', 5)

        from tasks.backup_tasks import verify_recent_backups

        # Trigger async task
        task = verify_recent_backups.apply_async(kwargs={'limit': limit})

        return jsonify({
            'status': 'success',
            'message': 'Verification task started',
            'task_id': task.id
        }), 202

    except Exception as e:
        logger.error(f"Failed to trigger verification: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/trigger/cleanup', methods=['POST'])
@require_auth
def trigger_cleanup():
    """
    Manually trigger backup cleanup

    POST /api/backup/trigger/cleanup
    {
        "retention_days": 30,
        "keep_count": 10
    }

    Returns:
        202: Cleanup started
        500: Failed to start cleanup
    """
    try:
        data = request.get_json() or {}
        retention_days = data.get('retention_days')
        keep_count = data.get('keep_count')

        from tasks.backup_tasks import cleanup_old_backups

        # Trigger async task
        task = cleanup_old_backups.apply_async(
            kwargs={
                'retention_days': retention_days,
                'keep_count': keep_count
            }
        )

        return jsonify({
            'status': 'success',
            'message': 'Cleanup task started',
            'task_id': task.id
        }), 202

    except Exception as e:
        logger.error(f"Failed to trigger cleanup: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/info', methods=['GET'])
@require_auth
def get_backup_info():
    """
    Get backup configuration and default paths

    GET /api/backup/info

    Returns:
        200: Backup configuration info including OS-specific paths
        500: Failed to get info
    """
    import platform

    try:
        from backup_manager import BackupManager
        manager = BackupManager()

        is_windows = platform.system() == 'Windows'

        # Suggested paths for different platforms
        if is_windows:
            suggested_paths = [
                'C:\\Backups',
                'D:\\Backups',
                os.path.expanduser('~\\Documents\\Backups'),
                'C:\\ProgramData\\AuditToolkit\\Backups'
            ]
            example_path = 'C:\\Backups\\audit-toolkit'
            network_example = '\\\\server\\share\\backups'
        else:
            suggested_paths = [
                '/var/backups/audit-toolkit',
                '/opt/backups',
                '/data/backups',
                os.path.expanduser('~/backups')
            ]
            example_path = '/var/backups/audit-toolkit'
            network_example = '//server/share/backups'

        return jsonify({
            'status': 'success',
            'default_path': str(manager.backup_dir),
            'default_path_exists': manager.backup_dir.exists(),
            'default_path_writable': os.access(manager.backup_dir, os.W_OK),
            'platform': platform.system(),
            'is_windows': is_windows,
            'suggested_paths': suggested_paths,
            'example_path': example_path,
            'network_example': network_example
        }), 200

    except Exception as e:
        logger.error(f"Failed to get backup info: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@backup_bp.route('/browse', methods=['POST'])
@require_auth
def browse_directories():
    """
    Browse server directories for backup location selection

    POST /api/backup/browse
    {
        "path": "/",           // Directory to browse (default: root or home)
        "show_files": false    // Include files in listing
    }

    Returns:
        200: Directory listing
        400: Invalid path
        403: Access denied
        500: Browse failed
    """
    import platform

    try:
        data = request.get_json() or {}
        target_path = data.get('path', '')
        show_files = data.get('show_files', False)

        is_windows = platform.system() == 'Windows'

        # If no path provided, start at common locations
        if not target_path:
            if is_windows:
                # Windows common paths
                common_paths = [
                    os.path.expanduser('~'),
                    'C:\\Backups',
                    'D:\\Backups',
                    os.environ.get('PROGRAMDATA', 'C:\\ProgramData'),
                    'C:\\'
                ]
            else:
                # Linux/Unix common paths
                common_paths = [
                    '/backups',
                    '/var/backups',
                    '/data',
                    os.path.expanduser('~'),
                    '/'
                ]

            for p in common_paths:
                if os.path.isdir(p) and os.access(p, os.R_OK):
                    target_path = p
                    break

            # Fallback to root
            if not target_path:
                target_path = 'C:\\' if is_windows else '/'

        # Security: Resolve and validate path
        resolved_path = Path(target_path).resolve()

        # Block access to sensitive system directories
        if is_windows:
            blocked_paths = [
                'C:\\Windows\\System32',
                'C:\\Windows\\SysWOW64',
                'C:\\$Recycle.Bin'
            ]
        else:
            blocked_paths = [
                '/proc', '/sys', '/dev', '/boot',
                '/etc/shadow', '/etc/passwd'
            ]

        resolved_str = str(resolved_path).lower() if is_windows else str(resolved_path)
        for blocked in blocked_paths:
            blocked_check = blocked.lower() if is_windows else blocked
            if resolved_str.startswith(blocked_check):
                return jsonify({'error': f'Access denied to {blocked}'}), 403

        if not resolved_path.exists():
            return jsonify({'error': 'Path does not exist'}), 400

        if not resolved_path.is_dir():
            return jsonify({'error': 'Path is not a directory'}), 400

        if not os.access(resolved_path, os.R_OK):
            return jsonify({'error': 'Permission denied'}), 403

        # List directory contents
        items = []
        try:
            for entry in sorted(
                resolved_path.iterdir(),
                key=lambda x: (not x.is_dir(), x.name.lower())
            ):
                try:
                    is_dir = entry.is_dir()
                    if is_dir or show_files:
                        items.append({
                            'name': entry.name,
                            'path': str(entry),
                            'is_dir': is_dir,
                            'writable': os.access(entry, os.W_OK) if is_dir else False,
                            'size': entry.stat().st_size if not is_dir else None
                        })
                except (PermissionError, OSError):
                    # Skip items we can't access
                    continue
        except PermissionError:
            return jsonify(
                {'error': 'Permission denied to read directory'}
            ), 403

        # Get parent path - check if at filesystem root
        is_root = (
            (is_windows and len(str(resolved_path)) <= 3) or
            (not is_windows and str(resolved_path) == '/')
        )
        parent = None if is_root else str(resolved_path.parent)

        return jsonify({
            'status': 'success',
            'current_path': str(resolved_path),
            'parent_path': parent,
            'is_writable': os.access(resolved_path, os.W_OK),
            'items': items,
            'is_windows': is_windows
        }), 200

    except Exception as e:
        logger.error(f"Directory browse failed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


def register_backup_routes(app):
    """
    Register backup routes with Flask app

    Usage:
        from api.backup_routes import register_backup_routes
        register_backup_routes(app)
    """
    app.register_blueprint(backup_bp)
    logger.info("Backup API routes registered")


__all__ = ['backup_bp', 'register_backup_routes']
