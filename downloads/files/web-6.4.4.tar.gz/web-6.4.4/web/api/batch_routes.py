#!/usr/bin/env python3
"""
Batch Audit Execution API Routes

Provides endpoints for parallel audit execution:
- Execute audit on multiple servers simultaneously
- Matrix execution (multiple audits × multiple servers)
- Progress tracking and status monitoring
- Result aggregation

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from flask import Blueprint, jsonify, request
from functools import wraps
import logging
import re

from config import (
    SessionLocal,
    MAX_CONCURRENT_SSH,
    MAX_CONNECTIONS_PER_HOST,
    SSH_COMMAND_TIMEOUT
)
from models.database import Server, Audit, AuditExecution
from tasks.parallel_executor import execute_parallel_audits, execute_audit_plan_parallel
from celery_app import celery_app
from auth_core import require_api_key, safe_error_response

logger = logging.getLogger(__name__)

batch_bp = Blueprint('batch', __name__, url_prefix='/api/batch')

# Validation constants (HIGH-03 fix)
MAX_SERVER_IDS = 500  # Max servers per batch request
MAX_AUDIT_PATH_LENGTH = 256
MAX_CONCURRENT_LIMIT = 200
MAX_TIMEOUT = 3600 * 2  # 2 hours max timeout
AUDIT_PATH_PATTERN = re.compile(r'^[a-zA-Z0-9_/.-]+\.sh$')  # Safe path characters only


def _validate_batch_input(data: dict) -> tuple[dict, str | None]:
    """
    Validate batch execution input parameters (HIGH-03 fix)

    Returns:
        Tuple of (validated_data, error_message)
        If error_message is not None, validation failed
    """
    validated = {}

    # Validate server_ids
    server_ids = data.get('server_ids')
    if server_ids is None:
        return {}, 'server_ids required'
    if not isinstance(server_ids, list):
        return {}, 'server_ids must be a list'
    if not server_ids:
        return {}, 'server_ids cannot be empty'
    if len(server_ids) > MAX_SERVER_IDS:
        return {}, f'server_ids cannot exceed {MAX_SERVER_IDS} entries'
    if not all(isinstance(sid, int) and sid > 0 for sid in server_ids):
        return {}, 'all server_ids must be positive integers'
    # Remove duplicates
    validated['server_ids'] = list(set(server_ids))

    # Validate audit_path
    audit_path = data.get('audit_path')
    if not audit_path:
        return {}, 'audit_path required'
    if not isinstance(audit_path, str):
        return {}, 'audit_path must be a string'
    if len(audit_path) > MAX_AUDIT_PATH_LENGTH:
        return {}, f'audit_path cannot exceed {MAX_AUDIT_PATH_LENGTH} characters'
    # Block path traversal
    if '..' in audit_path or audit_path.startswith('/'):
        return {}, 'audit_path cannot contain path traversal sequences'
    if not AUDIT_PATH_PATTERN.match(audit_path):
        return {}, 'audit_path contains invalid characters'
    validated['audit_path'] = audit_path

    # Validate optional parameters with bounds
    max_concurrent = data.get('max_concurrent', MAX_CONCURRENT_SSH)
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        return {}, 'max_concurrent must be a positive integer'
    validated['max_concurrent'] = min(max_concurrent, MAX_CONCURRENT_LIMIT)

    timeout = data.get('timeout', SSH_COMMAND_TIMEOUT)
    if not isinstance(timeout, int) or timeout < 1:
        return {}, 'timeout must be a positive integer'
    validated['timeout'] = min(timeout, MAX_TIMEOUT)

    # Validate stream_mode (optional, default: True for agentless execution)
    # stream_mode=True: Stream scripts via SSH stdin - NO DEPLOYMENT REQUIRED (default)
    # stream_mode=False: Execute scripts deployed at standard paths on remote hosts
    stream_mode = data.get('stream_mode', True)  # Default: agentless
    if not isinstance(stream_mode, bool):
        return {}, 'stream_mode must be a boolean'
    validated['stream_mode'] = stream_mode

    return validated, None


@batch_bp.route('/audits/execute', methods=['POST'])
@require_api_key
def execute_batch_audit():
    """
    Execute single audit on multiple servers in parallel

    Request JSON:
    {
        "server_ids": [1, 2, 3],
        "audit_path": "audits/linux/platform/baseline/updates.sh",
        "max_concurrent": 50,     # optional (default: 50)
        "timeout": 600,           # optional (default: 600)
        "stream_mode": true       # optional (default: true - agentless)
    }

    Execution Modes:
    - stream_mode=true (default): Scripts streamed via SSH/WinRM stdin (no deployment needed)
    - stream_mode=false: Scripts must be deployed to standard paths on hosts
      - Linux: /opt/audit-toolkit (via DEB/RPM package)
      - Windows: C:\\Program Files\\SecurityAuditToolkit (via MSI)

    Response:
    {
        "success": true,
        "task_id": "abc-123",
        "servers_count": 3,
        "audit_name": "updates.sh",
        "estimated_duration": 120,
        "stream_mode": true
    }
    """
    try:
        data = request.get_json()

        # Validate inputs (HIGH-03 fix - comprehensive validation)
        validated, error = _validate_batch_input(data)
        if error:
            return jsonify({'error': error}), 400

        server_ids = validated['server_ids']
        audit_path = validated['audit_path']
        max_concurrent = validated['max_concurrent']
        timeout = validated['timeout']
        stream_mode = validated['stream_mode']

        # Validate server existence
        db = SessionLocal()
        try:
            servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
            if len(servers) != len(server_ids):
                return jsonify({'error': 'Some servers not found'}), 404

            # Get audit info
            audit = db.query(Audit).filter(Audit.file_path == audit_path).first()
            audit_name = audit.name if audit else audit_path.split('/')[-1]

        finally:
            db.close()

        # Start parallel execution task
        options = {
            'max_concurrent': max_concurrent,
            'timeout': timeout,
            'stream_mode': stream_mode
        }

        task = execute_parallel_audits.apply_async(
            args=(server_ids, audit_path),
            kwargs={'options': options}
        )

        mode_str = "stream (no deployment)" if stream_mode else "deployed"
        logger.info(f"Started batch execution: task_id={task.id}, servers={len(server_ids)}, audit={audit_path}, mode={mode_str}")

        return jsonify({
            'success': True,
            'task_id': task.id,
            'servers_count': len(server_ids),
            'audit_name': audit_name,
            'audit_path': audit_path,
            'max_concurrent': max_concurrent,
            'stream_mode': stream_mode,
            'estimated_duration': len(server_ids) * 2  # rough estimate
        }), 202

    except Exception as e:
        logger.error(f"Batch execution error: {e}")
        return safe_error_response(e, custom_message="Failed to execute batch audit")


@batch_bp.route('/audits/matrix', methods=['POST'])
@require_api_key
def execute_matrix_audit():
    """
    Execute multiple audits on multiple servers (matrix execution)

    Request JSON:
    {
        "server_ids": [1, 2, 3],
        "audit_paths": [
            "platform/baseline/updates.sh",
            "platform/baseline/users.sh",
            "platform/services/ssh.sh"
        ],
        "plan_name": "Baseline Audit",  # optional
        "max_concurrent": 50             # optional
    }

    Response:
    {
        "success": true,
        "task_id": "xyz-789",
        "matrix_size": 9,
        "servers_count": 3,
        "audits_count": 3
    }
    """
    try:
        data = request.get_json()

        server_ids = data.get('server_ids', [])
        audit_paths = data.get('audit_paths', [])
        plan_name = data.get('plan_name', 'Matrix Audit')

        if not server_ids:
            return jsonify({'error': 'server_ids required'}), 400

        if not audit_paths:
            return jsonify({'error': 'audit_paths required'}), 400

        max_concurrent = data.get('max_concurrent', MAX_CONCURRENT_SSH)
        timeout = data.get('timeout', SSH_COMMAND_TIMEOUT)

        # stream_mode: True = agentless (scripts via stdin), False = deployed (local package)
        stream_mode = data.get('stream_mode', True)  # Default: agentless
        if not isinstance(stream_mode, bool):
            return jsonify({'error': 'stream_mode must be a boolean'}), 400

        # Validate inputs
        db = SessionLocal()
        try:
            servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
            if len(servers) != len(server_ids):
                return jsonify({'error': 'Some servers not found'}), 404
        finally:
            db.close()

        # Start matrix execution
        options = {
            'max_concurrent': max_concurrent,
            'timeout': timeout,
            'stream_mode': stream_mode
        }

        task = execute_audit_plan_parallel.apply_async(
            args=(server_ids, audit_paths),
            kwargs={'plan_name': plan_name, 'options': options}
        )

        matrix_size = len(server_ids) * len(audit_paths)

        logger.info(f"Started matrix execution: task_id={task.id}, matrix={matrix_size}")

        return jsonify({
            'success': True,
            'task_id': task.id,
            'matrix_size': matrix_size,
            'servers_count': len(server_ids),
            'audits_count': len(audit_paths),
            'plan_name': plan_name
        }), 202

    except Exception as e:
        logger.error(f"Matrix execution error: {e}")
        return safe_error_response(e, custom_message="Failed to execute matrix audit")


@batch_bp.route('/status/<task_id>', methods=['GET'])
@require_api_key
def get_batch_status(task_id):
    """
    Get batch execution status

    Response:
    {
        "task_id": "abc-123",
        "state": "RUNNING",
        "progress": 45,
        "status": "Executing on 50/100 servers",
        "servers_completed": 50,
        "servers_total": 100
    }
    """
    try:
        result = celery_app.AsyncResult(task_id)

        response = {
            'task_id': task_id,
            'state': result.state
        }

        if result.state == 'PENDING':
            response['status'] = 'Task not found or pending'
        elif result.state == 'STARTED':
            info = result.info or {}
            response.update(info)
        elif result.state == 'RUNNING':
            info = result.info or {}
            response.update(info)
        elif result.state == 'SUCCESS':
            response['result'] = result.result
        elif result.state == 'FAILURE':
            response['error'] = str(result.info)

        return jsonify(response)

    except Exception as e:
        logger.error(f"Status check error: {e}")
        return safe_error_response(e, custom_message="Failed to get batch status")


@batch_bp.route('/results/<task_id>', methods=['GET'])
@require_api_key
def get_batch_results(task_id):
    """
    Get batch execution results (when complete)

    Response:
    {
        "success": true,
        "summary": {
            "total_servers": 100,
            "successful_servers": 95,
            "failed_servers": 5,
            "success_rate": 95.0,
            "total_duration_seconds": 120.5
        },
        "results_by_server": {
            "server1": {...},
            "server2": {...}
        }
    }
    """
    try:
        result = celery_app.AsyncResult(task_id)

        if result.state != 'SUCCESS':
            return jsonify({
                'error': f'Task not complete: {result.state}'
            }), 400

        return jsonify(result.result)

    except Exception as e:
        logger.error(f"Results retrieval error: {e}")
        return safe_error_response(e, custom_message="Failed to get batch results")


@batch_bp.route('/settings', methods=['GET'])
@require_api_key
def get_batch_settings():
    """
    Get batch execution configuration

    Response:
    {
        "max_concurrent_ssh": 50,
        "max_connections_per_host": 5,
        "ssh_command_timeout": 600,
        "limits": {
            "recommended_max_servers": 200,
            "hard_max_concurrent": 100
        }
    }
    """
    return jsonify({
        'max_concurrent_ssh': MAX_CONCURRENT_SSH,
        'max_connections_per_host': MAX_CONNECTIONS_PER_HOST,
        'ssh_command_timeout': SSH_COMMAND_TIMEOUT,
        'limits': {
            'recommended_max_servers': 200,
            'hard_max_concurrent': 100,
            'note': 'Adjust MAX_CONCURRENT_SSH env var for custom limits'
        }
    })


@batch_bp.route('/settings', methods=['PUT'])
@require_api_key
def update_batch_settings():
    """
    Update batch execution settings (runtime override)

    Request JSON:
    {
        "max_concurrent": 75
    }

    Note: Settings are ephemeral (in-memory only)
    For persistent changes, set environment variables
    """
    try:
        data = request.get_json()

        # For now, return info about environment-based config
        # In future, could implement dynamic runtime configuration

        return jsonify({
            'message': 'Settings are environment-based',
            'current': {
                'max_concurrent_ssh': MAX_CONCURRENT_SSH,
                'max_connections_per_host': MAX_CONNECTIONS_PER_HOST
            },
            'to_change': 'Set MAX_CONCURRENT_SSH environment variable and restart'
        })

    except Exception as e:
        logger.error(f"Settings update error: {e}")
        return safe_error_response(e, custom_message="Failed to update settings")


@batch_bp.route('/servers/import', methods=['POST'])
@require_api_key
def batch_import_servers():
    """
    Batch import servers from CSV data

    Request JSON:
    {
        "servers": [
            {"hostname": "server1.example.com", "ip_address": "192.168.1.10", "os_type": "linux"},
            {"hostname": "server2.example.com", "ip_address": "192.168.1.11", "os_type": "linux"}
        ],
        "default_port": 22,
        "default_credential_id": 1,
        "skip_duplicates": true
    }

    Or upload CSV:
    {
        "csv_data": "hostname,ip_address,os_type\\nserver1.example.com,192.168.1.10,linux",
        "skip_duplicates": true
    }

    Response:
    {
        "success": true,
        "imported": 10,
        "skipped": 2,
        "errors": [],
        "server_ids": [1, 2, 3, ...]
    }
    """
    import csv
    import io
    from models.server import ServerManager

    try:
        data = request.get_json()

        servers_data = []
        skip_duplicates = data.get('skip_duplicates', True)
        default_port = data.get('default_port', 22)
        default_credential_id = data.get('default_credential_id')

        # Parse CSV data if provided
        if 'csv_data' in data:
            csv_text = data['csv_data']
            reader = csv.DictReader(io.StringIO(csv_text))
            for row in reader:
                servers_data.append({
                    'hostname': row.get('hostname', ''),
                    'ip_address': row.get('ip_address', ''),
                    'os_type': row.get('os_type', 'linux'),
                    'port': int(row.get('port', default_port)),
                    'credential_id': row.get('credential_id') or default_credential_id,
                    'description': row.get('description', '')
                })
        elif 'servers' in data:
            for server in data['servers']:
                servers_data.append({
                    'hostname': server.get('hostname', ''),
                    'ip_address': server.get('ip_address', ''),
                    'os_type': server.get('os_type', 'linux'),
                    'port': int(server.get('port', default_port)),
                    'credential_id': server.get('credential_id') or default_credential_id,
                    'description': server.get('description', '')
                })
        else:
            return jsonify({'error': 'Either servers or csv_data required'}), 400

        if not servers_data:
            return jsonify({'error': 'No servers to import'}), 400

        if len(servers_data) > MAX_SERVER_IDS:
            return jsonify({'error': f'Cannot import more than {MAX_SERVER_IDS} servers at once'}), 400

        # Validate and import
        server_manager = ServerManager()
        db = SessionLocal()

        try:
            imported = []
            skipped = []
            errors = []

            for idx, srv in enumerate(servers_data):
                try:
                    if not srv['hostname'] and not srv['ip_address']:
                        errors.append({'index': idx, 'error': 'hostname or ip_address required'})
                        continue

                    # Check for duplicates
                    if skip_duplicates:
                        existing = None
                        if srv['hostname']:
                            existing = db.query(Server).filter(Server.hostname == srv['hostname']).first()
                        if not existing and srv['ip_address']:
                            existing = db.query(Server).filter(Server.ip_address == srv['ip_address']).first()
                        if existing:
                            skipped.append({'index': idx, 'hostname': srv['hostname'], 'reason': 'duplicate'})
                            continue

                    # Create server
                    new_server = Server(
                        hostname=srv['hostname'] or srv['ip_address'],
                        ip_address=srv['ip_address'] or srv['hostname'],
                        os_type=srv['os_type'],
                        port=srv['port'],
                        credential_id=srv['credential_id'],
                        description=srv['description'],
                        status='unknown'
                    )
                    db.add(new_server)
                    db.flush()
                    imported.append(new_server.id)

                except Exception as e:
                    errors.append({'index': idx, 'hostname': srv.get('hostname'), 'error': str(e)})

            db.commit()

            logger.info(f"Batch import: imported={len(imported)}, skipped={len(skipped)}, errors={len(errors)}")

            return jsonify({
                'success': True,
                'imported': len(imported),
                'skipped': len(skipped),
                'errors': errors,
                'server_ids': imported
            }), 201

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Batch import error: {e}")
        return safe_error_response(e, custom_message="Failed to batch import servers")
