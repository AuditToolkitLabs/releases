"""
Beta License API Routes

Provides endpoints for:
- Beta program status (/api/beta/status)
- Beta registration (/api/beta/register)
- Beta key activation (/api/beta/activate)
- Usage tracking (/api/beta/usage)
- Build information (/api/beta/build)
"""

from flask import Blueprint, jsonify, request
from functools import wraps
import logging

from api.auth_routes import require_role

logger = logging.getLogger(__name__)

beta_bp = Blueprint('beta', __name__, url_prefix='/api/beta')


def get_beta_service():
    """Get beta license service instance."""
    from services_pkg.services.beta_licensing import get_beta_license_service
    return get_beta_license_service()


def require_valid_beta(f):
    """Decorator requiring valid beta license."""
    @wraps(f)
    def decorated(*args, **kwargs):
        service = get_beta_service()
        status = service.get_status()

        if not status.get('valid'):
            return jsonify({
                "error": status.get('error', 'invalid_license'),
                "message": status.get('message', 'Valid beta license required'),
                "registration_url": "/api/beta/register",
            }), 403

        return f(*args, **kwargs)
    return decorated


# ============================================================================
# Build & Program Status
# ============================================================================

@beta_bp.route('/build', methods=['GET'])
def get_build_info():
    """
    Get software build information and expiration status.

    Returns:
        Build date, version, expiration date, days remaining.
    """
    service = get_beta_service()
    build_status = service.check_build_expiration()
    return jsonify(build_status)


@beta_bp.route('/program', methods=['GET'])
def get_program_status():
    """
    Get beta program status.

    Returns:
        Whether beta program is active, dates, etc.
    """
    service = get_beta_service()
    program_status = service.check_beta_program_active()
    return jsonify(program_status)


@beta_bp.route('/status', methods=['GET'])
def get_beta_status():
    """
    Get complete beta license status.

    Returns:
        Full status including license, usage, build, program info.
    """
    service = get_beta_service()
    return jsonify(service.get_status())


# ============================================================================
# Registration & Activation
# ============================================================================

@beta_bp.route('/register', methods=['POST'])
def register_beta():
    """
    Register for beta access.

    Request body:
        {
            "email": "user@example.com",
            "organization": "ACME Corp"  // optional
        }

    Returns:
        Beta key and registration details.
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                "success": False,
                "message": "Request body required"
            }), 400

        email = data.get('email')
        if not email:
            return jsonify({
                "success": False,
                "message": "Email address required"
            }), 400

        # Basic email validation
        import re
        if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            return jsonify({
                "success": False,
                "message": "Invalid email address format"
            }), 400

        organization = data.get('organization', '')

        service = get_beta_service()
        result = service.register_beta(email, organization)

        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"Beta registration failed: {e}")
        return jsonify({
            "success": False,
            "message": f"Registration failed: {str(e)}"
        }), 500


@beta_bp.route('/activate', methods=['POST'])
def activate_beta():
    """
    Activate a beta license key.

    Request body:
        {
            "beta_key": "BETA-XXXX-XXXX-XXXX-XXXX"
        }

    Returns:
        Activation result.
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                "success": False,
                "message": "Request body required"
            }), 400

        beta_key = data.get('beta_key') or data.get('key')
        if not beta_key:
            return jsonify({
                "success": False,
                "message": "Beta key required"
            }), 400

        service = get_beta_service()
        result = service.activate_beta_key(beta_key)

        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"Beta activation failed: {e}")
        return jsonify({
            "success": False,
            "message": f"Activation failed: {str(e)}"
        }), 500


@beta_bp.route('/deactivate', methods=['POST'])
def deactivate_beta():
    """
    Deactivate current beta license.

    Returns:
        Deactivation result.
    """
    try:
        service = get_beta_service()
        result = service.deactivate()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Beta deactivation failed: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ============================================================================
# Usage Tracking
# ============================================================================

@beta_bp.route('/usage', methods=['GET'])
@require_valid_beta
def get_usage():
    """
    Get current usage statistics.

    Returns:
        Scans today, this month, machines registered, limits.
    """
    service = get_beta_service()
    status = service.get_status()

    return jsonify({
        "usage": status.get('usage', {}),
        "limits": status.get('limits', {}),
    })


@beta_bp.route('/check-scan', methods=['POST'])
def check_scan_allowed():
    """
    Check if a scan is allowed under current limits.

    Request body (optional):
        {
            "machine_id": "unique-machine-id"
        }

    Returns:
        Whether scan is allowed and remaining limits.
    """
    service = get_beta_service()

    data = request.get_json() or {}
    machine_id = data.get('machine_id')

    # Check scan limits
    scan_check = service.check_scan_allowed()
    if not scan_check.get('allowed'):
        return jsonify(scan_check), 403

    # Check machine limits if provided
    if machine_id:
        machine_check = service.check_machine_allowed(machine_id)
        if not machine_check.get('allowed'):
            return jsonify(machine_check), 403

    return jsonify(scan_check)


@beta_bp.route('/record-scan', methods=['POST'])
@require_valid_beta
def record_scan():
    """
    Record a completed scan for usage tracking.

    Request body (optional):
        {
            "machine_id": "unique-machine-id"
        }

    Returns:
        Updated usage statistics.
    """
    service = get_beta_service()

    data = request.get_json() or {}
    machine_id = data.get('machine_id')

    service.record_scan(machine_id)
    status = service.get_status()

    return jsonify({
        "success": True,
        "usage": status.get('usage', {}),
    })


# ============================================================================
# Admin Endpoints
# ============================================================================

@beta_bp.route('/generate-key', methods=['POST'])
@require_role('Admin')
def generate_beta_key():
    """
    Generate a beta key (admin only).

    Request body:
        {
            "tier": "private_beta",  // private_beta, public_beta, early_access, internal
            "identifier": "user@example.com"  // optional
        }

    Returns:
        Generated beta key.

    Note: Requires an authenticated Admin or SuperAdmin session.
    """
    try:
        from services_pkg.services.beta_licensing import BetaLicenseService, BetaTier

        data = request.get_json() or {}
        tier_str = data.get('tier', 'public_beta')
        identifier = data.get('identifier', '')

        # Map string to enum
        tier_map = {
            'private_beta': BetaTier.PRIVATE_BETA,
            'public_beta': BetaTier.PUBLIC_BETA,
            'early_access': BetaTier.EARLY_ACCESS,
            'internal': BetaTier.INTERNAL,
        }

        tier = tier_map.get(tier_str)
        if not tier:
            return jsonify({
                "success": False,
                "message": f"Invalid tier. Must be one of: {list(tier_map.keys())}"
            }), 400

        key = BetaLicenseService.generate_beta_key(tier, identifier)

        return jsonify({
            "success": True,
            "beta_key": key,
            "tier": tier_str,
        })

    except Exception as e:
        logger.error(f"Beta key generation failed: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500
