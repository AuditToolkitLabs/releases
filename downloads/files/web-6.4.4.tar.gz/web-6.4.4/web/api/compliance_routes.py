"""
Compliance Dashboard Routes - Enterprise Compliance Tracking

Provides endpoints for:
- Compliance scorecard across all frameworks
- Per-server and per-framework compliance status
- Control implementation tracking
- Compliance trend analysis
- Assessment creation and management

Author: Security Audit Toolkit Team
"""

import json
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from sqlalchemy import desc, func, and_, or_
from sqlalchemy.orm import joinedload
from sqlalchemy.exc import SQLAlchemyError

# Import from config
from config import logger

# Import database session
try:
    from models.database import db
    from models.database import AuditExecution, Server, Audit
    from models.compliance import (
        ComplianceAssessment,
        ComplianceControl,
        ComplianceTrend,
        ComplianceFrameworkConfig
    )
    from models.differential import RemediationItem
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    db = None

# Import auth decorators
from auth_core import (
    require_auth_and_permission,
    require_auth_permission_and_log,
    get_current_user
)

# Import compliance templates
try:
    from reports.compliance_templates import ComplianceTemplates, ComplianceFramework
    COMPLIANCE_TEMPLATES_AVAILABLE = True
except ImportError:
    COMPLIANCE_TEMPLATES_AVAILABLE = False
    ComplianceTemplates = None
    ComplianceFramework = None

# Import differential parser for audit output
from differential import AuditOutputParser, CheckStatus

try:
    from services_pkg.services.reporting_query_service import ReportingQueryService
    _REPORTING_QUERY_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_QUERY_SERVICE_AVAILABLE = False

try:
    from services_pkg.services.reporting_persistence_service import ReportingPersistenceService
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_PERSISTENCE_SERVICE_AVAILABLE = False

# Create blueprint
compliance_bp = Blueprint('compliance', __name__)

# Framework ID mapping
FRAMEWORK_MAP = {
    'pci-dss': 'PCI-DSS 4.0',
    'soc2': 'SOC 2 Type II',
    'iso27001': 'ISO 27001:2022',
    'nist-csf': 'NIST CSF',
    'cis': 'CIS Controls v8'
}

reporting_query_service = ReportingQueryService() if _REPORTING_QUERY_SERVICE_AVAILABLE else None
reporting_persistence_service = ReportingPersistenceService() if _REPORTING_PERSISTENCE_SERVICE_AVAILABLE else None


def _persist_reporting_compliance_assessment(db_session, assessment):
    """Persist canonical reporting rows for a compliance assessment when available."""
    if reporting_persistence_service is None:
        return None
    return reporting_persistence_service.persist_compliance_assessment(db_session, assessment)


# ============================================================================
# Compliance Dashboard - Main Scorecard
# ============================================================================

@compliance_bp.route('/api/compliance/dashboard', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_compliance_dashboard():
    """
    Get compliance dashboard with scorecard for all frameworks.

    Returns aggregated compliance scores across the organization.

    Query Parameters:
        server_id: int - Filter to specific server
        server_group_id: int - Filter to specific group
        days: int - Days of history for trends (default: 30)

    Returns:
        Dashboard with scorecard, trends, and top issues
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        server_id = request.args.get('server_id', type=int)
        server_group_id = request.args.get('server_group_id', type=int)
        days = request.args.get('days', 30, type=int)

        # Get latest assessment for each framework
        scorecard = []
        for framework_id, framework_name in FRAMEWORK_MAP.items():
            query = db.session.query(ComplianceAssessment)\
                .filter(ComplianceAssessment.framework == framework_name)

            if server_id:
                query = query.filter(ComplianceAssessment.server_id == server_id)
            if server_group_id:
                query = query.filter(ComplianceAssessment.server_group_id == server_group_id)

            # Get latest assessment
            latest = query.order_by(desc(ComplianceAssessment.assessed_at)).first()

            # Get average score across all servers for this framework
            avg_query = db.session.query(
                func.avg(ComplianceAssessment.compliance_score).label('avg_score'),
                func.count(ComplianceAssessment.id).label('assessment_count')
            ).filter(ComplianceAssessment.framework == framework_name)

            if server_id:
                avg_query = avg_query.filter(ComplianceAssessment.server_id == server_id)

            avg_result = avg_query.first()

            # Get trend for this framework
            cutoff = datetime.utcnow() - timedelta(days=days)
            trend_data = db.session.query(
                func.date(ComplianceTrend.recorded_at).label('date'),
                func.avg(ComplianceTrend.compliance_score).label('avg_score')
            ).filter(
                ComplianceTrend.framework == framework_name,
                ComplianceTrend.recorded_at >= cutoff
            ).group_by(func.date(ComplianceTrend.recorded_at))\
             .order_by(func.date(ComplianceTrend.recorded_at))\
             .all()

            # Calculate trend direction
            trend_direction = 'stable'
            if len(trend_data) >= 2:
                first_score = trend_data[0].avg_score or 0
                last_score = trend_data[-1].avg_score or 0
                if last_score > first_score + 5:
                    trend_direction = 'improving'
                elif last_score < first_score - 5:
                    trend_direction = 'declining'

            scorecard.append({
                'framework_id': framework_id,
                'framework_name': framework_name,
                'current_score': round(latest.compliance_score, 1) if latest else None,
                'status': latest.status if latest else 'unknown',
                'average_score': round(avg_result.avg_score or 0, 1),
                'assessment_count': avg_result.assessment_count or 0,
                'last_assessed': latest.assessed_at.isoformat() if latest else None,
                'trend_direction': trend_direction,
                'trend_data': [
                    {'date': str(t.date), 'score': round(t.avg_score or 0, 1)}
                    for t in trend_data
                ]
            })

        # Get top failing controls across all frameworks
        top_failing = db.session.query(ComplianceControl)\
            .join(ComplianceAssessment)\
            .filter(ComplianceControl.status == 'failed')\
            .order_by(desc(ComplianceAssessment.assessed_at))\
            .limit(10)\
            .all()

        # Get remediation summary
        remediation_stats = {
            'open': db.session.query(RemediationItem).filter(
                RemediationItem.remediation_status == 'open'
            ).count() if RemediationItem else 0,
            'in_progress': db.session.query(RemediationItem).filter(
                RemediationItem.remediation_status == 'in_progress'
            ).count() if RemediationItem else 0,
            'resolved': db.session.query(RemediationItem).filter(
                RemediationItem.remediation_status == 'resolved'
            ).count() if RemediationItem else 0
        }

        return jsonify({
            'scorecard': scorecard,
            'top_failing_controls': [c.to_dict() for c in top_failing],
            'remediation_summary': remediation_stats,
            'generated_at': datetime.utcnow().isoformat()
        })

    except Exception as e:
        try:
            db.session.rollback()
        except Exception as rollback_error:
            logger.debug(f"Session rollback skipped in compliance dashboard handler: {rollback_error}")

        error_text = str(e)
        if isinstance(e, SQLAlchemyError) and 'does not exist' in error_text:
            logger.warning("Compliance tables unavailable; returning empty dashboard payload")
            return jsonify({
                'scorecard': [],
                'top_failing_controls': [],
                'remediation_summary': {
                    'open': 0,
                    'in_progress': 0,
                    'resolved': 0
                },
                'summary': {
                    'total_frameworks': len(FRAMEWORK_MAP),
                    'assessed_frameworks': 0,
                    'average_score': 0,
                    'critical_issues': 0
                },
                'generated_at': datetime.utcnow().isoformat(),
                'filters': {
                    'server_id': request.args.get('server_id', type=int),
                    'server_group_id': request.args.get('server_group_id', type=int),
                    'days': request.args.get('days', 30, type=int)
                }
            })

        logger.error(f"Error getting compliance dashboard: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/compliance/scorecard/<framework_id>', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_framework_scorecard(framework_id: str):
    """
    Get detailed scorecard for a specific compliance framework.

    Returns all control statuses and server-by-server breakdown.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    framework_name = FRAMEWORK_MAP.get(framework_id.lower())
    if not framework_name:
        return jsonify({'error': f'Unknown framework: {framework_id}'}), 400

    try:
        # Get all assessments for this framework
        assessments = db.session.query(ComplianceAssessment)\
            .options(joinedload(ComplianceAssessment.server))\
            .filter(ComplianceAssessment.framework == framework_name)\
            .order_by(desc(ComplianceAssessment.assessed_at))\
            .all()

        # Group by server (latest per server)
        server_scores = {}
        for assessment in assessments:
            if assessment.server_id and assessment.server_id not in server_scores:
                server_scores[assessment.server_id] = assessment.to_dict()

        # Calculate aggregate statistics
        if assessments:
            total_score = sum(a.compliance_score for a in assessments[:len(server_scores)]) / len(server_scores) if server_scores else 0

            # Get control breakdown from latest assessment
            latest = assessments[0]
            controls_query = db.session.query(ComplianceControl)\
                .filter(ComplianceControl.assessment_id == latest.id)\
                .all()

            # Group controls by category
            control_categories = {}
            for control in controls_query:
                category = control.control_category or 'General'
                if category not in control_categories:
                    control_categories[category] = {
                        'total': 0,
                        'satisfied': 0,
                        'partial': 0,
                        'failed': 0,
                        'unknown': 0,
                        'controls': []
                    }
                control_categories[category]['total'] += 1
                control_categories[category][control.status] = control_categories[category].get(control.status, 0) + 1
                control_categories[category]['controls'].append(control.to_dict())
        else:
            total_score = 0
            control_categories = {}

        return jsonify({
            'framework_id': framework_id,
            'framework_name': framework_name,
            'aggregate_score': round(total_score, 1),
            'server_count': len(server_scores),
            'server_scores': list(server_scores.values()),
            'control_categories': control_categories,
            'latest_assessment': assessments[0].to_dict() if assessments else None
        })

    except Exception as e:
        logger.error(f"Error getting framework scorecard: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Compliance Assessments
# ============================================================================

@compliance_bp.route('/api/compliance/assessments', methods=['GET'])
@require_auth_and_permission('view_history')
def list_assessments():
    """
    List compliance assessments with filtering.

    Query Parameters:
        server_id: int - Filter by server
        framework: str - Filter by framework ID
        status: str - Filter by status (compliant, partial, at_risk, non_compliant)
        page: int - Page number (default: 1)
        per_page: int - Items per page (default: 20)
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        server_id = request.args.get('server_id', type=int)
        framework = request.args.get('framework')
        status = request.args.get('status')
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)

        query = db.session.query(ComplianceAssessment)\
            .options(joinedload(ComplianceAssessment.server))

        if server_id:
            query = query.filter(ComplianceAssessment.server_id == server_id)
        if framework:
            framework_name = FRAMEWORK_MAP.get(framework.lower(), framework)
            query = query.filter(ComplianceAssessment.framework == framework_name)

        total = query.count()

        assessments = query.order_by(desc(ComplianceAssessment.assessed_at))\
            .offset((page - 1) * per_page)\
            .limit(per_page)\
            .all()

        # Filter by status after query (computed property)
        if status:
            assessments = [a for a in assessments if a.status == status]

        return jsonify({
            'assessments': [a.to_dict() for a in assessments],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        logger.error(f"Error listing assessments: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/compliance/assessments/<int:assessment_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def get_assessment(assessment_id: int):
    """Get detailed assessment with all controls"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        assessment = db.session.query(ComplianceAssessment)\
            .options(
                joinedload(ComplianceAssessment.server),
                joinedload(ComplianceAssessment.controls)
            )\
            .get(assessment_id)

        if not assessment:
            return jsonify({'error': 'Assessment not found'}), 404

        if reporting_query_service is not None:
            result = reporting_query_service.build_compliance_assessment_report(
                assessment,
                server=assessment.server,
                controls=assessment.controls,
            )
        else:
            result = assessment.to_dict()
            result['controls'] = [c.to_dict() for c in assessment.controls]

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error getting assessment: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/reporting/compliance-assessments/<int:assessment_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def get_canonical_assessment_report(assessment_id: int):
    """Return canonical reporting payload for a persisted compliance assessment."""
    if not DATABASE_AVAILABLE:
        return jsonify({'success': False, 'error': 'Database not available'}), 503

    try:
        assessment = db.session.query(ComplianceAssessment)\
            .options(
                joinedload(ComplianceAssessment.server),
                joinedload(ComplianceAssessment.controls)
            )\
            .get(assessment_id)

        if not assessment:
            return jsonify({'success': False, 'error': 'Assessment not found'}), 404

        if reporting_query_service is not None:
            canonical_payload = reporting_query_service.build_compliance_assessment_canonical_payload(
                assessment,
                server=assessment.server,
                controls=assessment.controls,
            )
        else:
            canonical_payload = {
                'asset': None,
                'observation': None,
                'control_evaluation': None,
                'controls': [c.to_dict() for c in assessment.controls],
                'source_record': {
                    'assessment_id': assessment.id,
                    'server_id': assessment.server_id,
                    'framework': assessment.framework,
                    'framework_version': assessment.framework_version,
                    'execution_id': assessment.execution_id,
                    'server_hostname': assessment.server.hostname if assessment.server else None,
                },
            }

        return jsonify({'success': True, 'canonical': canonical_payload})

    except Exception as e:
        logger.error(f"Error getting canonical assessment report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@compliance_bp.route('/api/compliance/assess', methods=['POST'])
@require_auth_permission_and_log('run_audits', 'create_compliance_assessment')
def create_assessment():
    """
    Create a new compliance assessment from an audit execution.

    Maps audit results to compliance framework controls.

    Request Body:
    {
        "execution_id": 123,           # Audit execution to assess
        "framework": "pci-dss",        # Framework ID
        "notes": "Quarterly assessment"
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    if not COMPLIANCE_TEMPLATES_AVAILABLE:
        return jsonify({'error': 'Compliance templates not available'}), 503

    try:
        data = request.get_json() or {}
        execution_id = data.get('execution_id')
        framework_id = data.get('framework', '').lower()
        notes = data.get('notes')

        if not execution_id:
            return jsonify({'error': 'execution_id is required'}), 400
        if not framework_id:
            return jsonify({'error': 'framework is required'}), 400

        framework_name = FRAMEWORK_MAP.get(framework_id)
        if not framework_name:
            return jsonify({'error': f'Unknown framework: {framework_id}'}), 400

        # Get execution
        execution = db.session.query(AuditExecution).get(execution_id)
        if not execution:
            return jsonify({'error': 'Execution not found'}), 404

        # Parse audit output to get check results
        parser = AuditOutputParser()
        findings = parser.parse_to_dict(execution.output or '')

        # Convert findings to audit_results format
        audit_results = {}
        for check_name, finding in findings.items():
            # Normalize check name to match control mapping
            normalized_name = check_name.lower().replace(' ', '_')
            audit_results[normalized_name] = finding.status.value.lower()

        # Map to compliance framework
        framework_enum = {
            'pci-dss': ComplianceFramework.PCI_DSS,
            'soc2': ComplianceFramework.SOC2,
            'iso27001': ComplianceFramework.ISO27001,
            'nist-csf': ComplianceFramework.NIST_CSF,
            'cis': ComplianceFramework.CIS_CONTROLS
        }.get(framework_id)

        mapped_controls = ComplianceTemplates.map_audit_to_controls(
            framework_enum, audit_results
        )

        # Calculate scores
        score_data = ComplianceTemplates.calculate_compliance_score(mapped_controls)

        user = get_current_user()

        # Create assessment
        assessment = ComplianceAssessment(
            server_id=execution.server_id,
            execution_id=execution_id,
            framework=framework_name,
            compliance_score=score_data['percentage'],
            total_controls=score_data['total'],
            satisfied_controls=score_data['satisfied'],
            partial_controls=score_data['partial'],
            failed_controls=score_data['failed'],
            unknown_controls=score_data['unknown'],
            assessed_by=user.email if hasattr(user, 'email') else str(user),
            notes=notes
        )
        db.session.add(assessment)
        db.session.flush()  # Get assessment ID
        _persist_reporting_compliance_assessment(db.session, assessment)

        # Create control records
        for category, controls in mapped_controls.items():
            for control in controls:
                passing = sum(1 for c in control.audit_checks if audit_results.get(c) == 'pass')
                failing = sum(1 for c in control.audit_checks if audit_results.get(c) == 'fail')

                ctrl_record = ComplianceControl(
                    assessment_id=assessment.id,
                    control_id=control.id,
                    control_name=control.name,
                    control_category=category,
                    control_description=control.description,
                    status=control.status,
                    evidence=control.evidence,
                    audit_checks=json.dumps(control.audit_checks),
                    passing_checks=passing,
                    failing_checks=failing
                )
                db.session.add(ctrl_record)

        # Create trend data point
        trend = ComplianceTrend(
            server_id=execution.server_id,
            scope='server',
            framework=framework_name,
            compliance_score=score_data['percentage'],
            total_controls=score_data['total'],
            satisfied_controls=score_data['satisfied'],
            failed_controls=score_data['failed'],
            assessment_id=assessment.id
        )
        db.session.add(trend)

        db.session.commit()

        return jsonify({
            'message': 'Assessment created',
            'assessment': assessment.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating assessment: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/compliance/assess/bulk', methods=['POST'])
@require_auth_permission_and_log('run_audits', 'bulk_compliance_assessment')
def create_bulk_assessment():
    """
    Create compliance assessments for multiple executions.

    Request Body:
    {
        "execution_ids": [1, 2, 3],
        "framework": "pci-dss"
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}
        execution_ids = data.get('execution_ids', [])
        framework = data.get('framework')

        if not execution_ids:
            return jsonify({'error': 'execution_ids required'}), 400
        if not framework:
            return jsonify({'error': 'framework required'}), 400

        results = {'created': 0, 'failed': 0, 'errors': []}

        for exec_id in execution_ids:
            try:
                # Use the single assessment endpoint logic
                response = create_assessment_internal(exec_id, framework)
                if response:
                    results['created'] += 1
                else:
                    results['failed'] += 1
            except Exception as e:
                results['failed'] += 1
                results['errors'].append({'execution_id': exec_id, 'error': str(e)})

        return jsonify(results)

    except Exception as e:
        logger.error(f"Error creating bulk assessment: {e}")
        return jsonify({'error': str(e)}), 500


def create_assessment_internal(execution_id: int, framework_id: str):
    """Internal helper for creating assessments"""
    if not COMPLIANCE_TEMPLATES_AVAILABLE:
        return None

    framework_name = FRAMEWORK_MAP.get(framework_id.lower())
    if not framework_name:
        return None

    execution = db.session.query(AuditExecution).get(execution_id)
    if not execution:
        return None

    parser = AuditOutputParser()
    findings = parser.parse_to_dict(execution.output or '')

    audit_results = {}
    for check_name, finding in findings.items():
        normalized_name = check_name.lower().replace(' ', '_')
        audit_results[normalized_name] = finding.status.value.lower()

    framework_enum = {
        'pci-dss': ComplianceFramework.PCI_DSS,
        'soc2': ComplianceFramework.SOC2,
        'iso27001': ComplianceFramework.ISO27001,
        'nist-csf': ComplianceFramework.NIST_CSF,
        'cis': ComplianceFramework.CIS_CONTROLS
    }.get(framework_id.lower())

    if not framework_enum:
        return None

    mapped_controls = ComplianceTemplates.map_audit_to_controls(framework_enum, audit_results)
    score_data = ComplianceTemplates.calculate_compliance_score(mapped_controls)

    assessment = ComplianceAssessment(
        server_id=execution.server_id,
        execution_id=execution_id,
        framework=framework_name,
        compliance_score=score_data['percentage'],
        total_controls=score_data['total'],
        satisfied_controls=score_data['satisfied'],
        partial_controls=score_data['partial'],
        failed_controls=score_data['failed'],
        unknown_controls=score_data['unknown']
    )
    db.session.add(assessment)
    db.session.flush()
    _persist_reporting_compliance_assessment(db.session, assessment)

    for category, controls in mapped_controls.items():
        for control in controls:
            passing = sum(1 for c in control.audit_checks if audit_results.get(c) == 'pass')
            failing = sum(1 for c in control.audit_checks if audit_results.get(c) == 'fail')

            ctrl_record = ComplianceControl(
                assessment_id=assessment.id,
                control_id=control.id,
                control_name=control.name,
                control_category=category,
                control_description=control.description,
                status=control.status,
                evidence=control.evidence,
                audit_checks=json.dumps(control.audit_checks),
                passing_checks=passing,
                failing_checks=failing
            )
            db.session.add(ctrl_record)

    trend = ComplianceTrend(
        server_id=execution.server_id,
        scope='server',
        framework=framework_name,
        compliance_score=score_data['percentage'],
        total_controls=score_data['total'],
        satisfied_controls=score_data['satisfied'],
        failed_controls=score_data['failed'],
        assessment_id=assessment.id
    )
    db.session.add(trend)

    return assessment


# ============================================================================
# Compliance Trends
# ============================================================================

@compliance_bp.route('/api/compliance/trends', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_compliance_trends():
    """
    Get compliance trend data for charting.

    Query Parameters:
        framework: str - Framework ID (default: all)
        server_id: int - Filter to specific server
        days: int - Number of days (default: 90)
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        framework = request.args.get('framework')
        server_id = request.args.get('server_id', type=int)
        days = request.args.get('days', 90, type=int)

        cutoff = datetime.utcnow() - timedelta(days=days)

        query = db.session.query(ComplianceTrend)\
            .filter(ComplianceTrend.recorded_at >= cutoff)

        if framework:
            framework_name = FRAMEWORK_MAP.get(framework.lower(), framework)
            query = query.filter(ComplianceTrend.framework == framework_name)

        if server_id:
            query = query.filter(ComplianceTrend.server_id == server_id)

        trends = query.order_by(ComplianceTrend.recorded_at).all()

        # Group by framework and date
        grouped = {}
        for t in trends:
            if t.framework not in grouped:
                grouped[t.framework] = []
            grouped[t.framework].append(t.to_dict())

        return jsonify({
            'days': days,
            'trends': grouped
        })

    except Exception as e:
        logger.error(f"Error getting compliance trends: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/compliance/trends/summary', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_trends_summary():
    """
    Get summary of compliance trends for executive reporting.

    Returns highest/lowest scores, biggest improvements/declines.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        days = request.args.get('days', 30, type=int)
        cutoff = datetime.utcnow() - timedelta(days=days)

        summary = {}

        for framework_id, framework_name in FRAMEWORK_MAP.items():
            # Get trend data for this framework
            trends = db.session.query(ComplianceTrend)\
                .filter(
                    ComplianceTrend.framework == framework_name,
                    ComplianceTrend.recorded_at >= cutoff
                )\
                .order_by(ComplianceTrend.recorded_at)\
                .all()

            if not trends:
                continue

            scores = [t.compliance_score for t in trends]
            first_score = scores[0] if scores else 0
            last_score = scores[-1] if scores else 0

            summary[framework_id] = {
                'framework_name': framework_name,
                'current_score': round(last_score, 1),
                'previous_score': round(first_score, 1),
                'change': round(last_score - first_score, 1),
                'trend': 'improving' if last_score > first_score else ('declining' if last_score < first_score else 'stable'),
                'min_score': round(min(scores), 1),
                'max_score': round(max(scores), 1),
                'avg_score': round(sum(scores) / len(scores), 1),
                'data_points': len(trends)
            }

        return jsonify({
            'period_days': days,
            'frameworks': summary
        })

    except Exception as e:
        logger.error(f"Error getting trends summary: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Framework Configuration
# ============================================================================

@compliance_bp.route('/api/compliance/frameworks', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def list_frameworks():
    """List all available compliance frameworks"""
    frameworks = []

    for framework_id, framework_name in FRAMEWORK_MAP.items():
        frameworks.append({
            'id': framework_id,
            'name': framework_name,
            'available': COMPLIANCE_TEMPLATES_AVAILABLE
        })

    return jsonify({'frameworks': frameworks})


@compliance_bp.route('/api/compliance/frameworks/<framework_id>/controls', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_framework_controls(framework_id: str):
    """
    Get all controls defined for a compliance framework.

    Returns the control definitions without assessment status.
    """
    if not COMPLIANCE_TEMPLATES_AVAILABLE:
        return jsonify({'error': 'Compliance templates not available'}), 503

    framework_name = FRAMEWORK_MAP.get(framework_id.lower())
    if not framework_name:
        return jsonify({'error': f'Unknown framework: {framework_id}'}), 400

    try:
        framework_enum = {
            'pci-dss': ComplianceFramework.PCI_DSS,
            'soc2': ComplianceFramework.SOC2,
            'iso27001': ComplianceFramework.ISO27001,
            'nist-csf': ComplianceFramework.NIST_CSF,
            'cis': ComplianceFramework.CIS_CONTROLS
        }.get(framework_id.lower())

        controls = ComplianceTemplates.get_framework_controls(framework_enum)

        # Convert ControlMapping objects to dicts
        result = {}
        for category, control_list in controls.items():
            result[category] = [
                {
                    'id': c.id,
                    'name': c.name,
                    'description': c.description,
                    'audit_checks': c.audit_checks
                }
                for c in control_list
            ]

        return jsonify({
            'framework_id': framework_id,
            'framework_name': framework_name,
            'controls': result,
            'total_controls': sum(len(v) for v in result.values())
        })

    except Exception as e:
        logger.error(f"Error getting framework controls: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Server Compliance Status
# ============================================================================

@compliance_bp.route('/api/compliance/servers/<int:server_id>', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_server_compliance(server_id: int):
    """
    Get compliance status for a specific server across all frameworks.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        server = db.session.query(Server).get(server_id)
        if not server:
            return jsonify({'error': 'Server not found'}), 404

        # Get latest assessment for each framework
        frameworks = {}
        for framework_id, framework_name in FRAMEWORK_MAP.items():
            assessment = db.session.query(ComplianceAssessment)\
                .filter(
                    ComplianceAssessment.server_id == server_id,
                    ComplianceAssessment.framework == framework_name
                )\
                .order_by(desc(ComplianceAssessment.assessed_at))\
                .first()

            if assessment:
                frameworks[framework_id] = assessment.to_dict()
            else:
                frameworks[framework_id] = {
                    'framework_name': framework_name,
                    'status': 'not_assessed',
                    'message': 'No assessment available'
                }

        # Calculate overall compliance
        assessed_frameworks = [f for f in frameworks.values() if 'compliance_score' in f]
        overall_score = sum(f['compliance_score'] for f in assessed_frameworks) / len(assessed_frameworks) if assessed_frameworks else 0

        return jsonify({
            'server_id': server_id,
            'server_name': server.name,
            'overall_score': round(overall_score, 1),
            'frameworks': frameworks,
            'assessed_count': len(assessed_frameworks),
            'total_frameworks': len(FRAMEWORK_MAP)
        })

    except Exception as e:
        logger.error(f"Error getting server compliance: {e}")
        return jsonify({'error': str(e)}), 500


@compliance_bp.route('/api/compliance/servers', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def list_server_compliance():
    """
    List all servers with their compliance scores.

    Query Parameters:
        framework: str - Filter by framework
        status: str - Filter by status
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        framework = request.args.get('framework')

        # Get all servers
        servers = db.session.query(Server).all()

        results = []
        for server in servers:
            query = db.session.query(ComplianceAssessment)\
                .filter(ComplianceAssessment.server_id == server.id)

            if framework:
                framework_name = FRAMEWORK_MAP.get(framework.lower(), framework)
                query = query.filter(ComplianceAssessment.framework == framework_name)

            # Get latest assessments
            assessments = query.order_by(desc(ComplianceAssessment.assessed_at)).all()

            # Calculate aggregate score
            if assessments:
                # Get unique latest per framework
                latest_per_framework = {}
                for a in assessments:
                    if a.framework not in latest_per_framework:
                        latest_per_framework[a.framework] = a

                avg_score = sum(a.compliance_score for a in latest_per_framework.values()) / len(latest_per_framework)

                results.append({
                    'server_id': server.id,
                    'server_name': server.name,
                    'hostname': server.hostname,
                    'compliance_score': round(avg_score, 1),
                    'frameworks_assessed': len(latest_per_framework),
                    'last_assessed': max(a.assessed_at for a in latest_per_framework.values()).isoformat()
                })
            else:
                results.append({
                    'server_id': server.id,
                    'server_name': server.name,
                    'hostname': server.hostname,
                    'compliance_score': None,
                    'frameworks_assessed': 0,
                    'last_assessed': None
                })

        # Sort by score (not assessed at bottom)
        results.sort(key=lambda x: (x['compliance_score'] is not None, x['compliance_score'] or 0), reverse=True)

        return jsonify({
            'servers': results,
            'total': len(results)
        })

    except Exception as e:
        logger.error(f"Error listing server compliance: {e}")
        return jsonify({'error': str(e)}), 500
