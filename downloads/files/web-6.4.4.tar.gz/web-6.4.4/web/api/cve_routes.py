"""
CVE API Routes - Vulnerability Intelligence Endpoints

Provides endpoints for:
- CVE lookup and search
- Execution correlation (package → CVE mapping)
- Admin controls (enable/disable, sync, settings)
- Sync status and logs

All endpoints check if CVE integration is enabled.
Superadmin can enable/disable and trigger manual syncs.

Author: Security Audit Toolkit Team
"""

from datetime import datetime
from flask import Blueprint, jsonify, request

# Import logging
try:
    from config import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

# Import database
try:
    from models.database import db
    from models.cve import (
        CVERecord,
        CPEMatch,
        PackageCPEMap,
        CVESettings,
        CVESyncLog,
        ServerCVESummary
    )
    from models.database import Server, AuditExecution
    from services.cve_service import CVEService, CVESyncService
    DATABASE_AVAILABLE = True
except ImportError as e:
    logger.warning(f"CVE database imports failed: {e}")
    DATABASE_AVAILABLE = False
    db = None

# Import auth decorators
from auth_core import (
    require_auth_and_permission,
    require_auth_permission_and_log,
    get_current_user
)

# Create blueprint
cve_bp = Blueprint('cve', __name__)


def get_cve_service():
    """Get CVE service instance"""
    if not DATABASE_AVAILABLE:
        return None
    return CVEService(db.session)


def get_sync_service():
    """Get CVE sync service instance"""
    if not DATABASE_AVAILABLE:
        return None
    return CVESyncService(db.session)


def require_cve_enabled(f):
    """Decorator to check if CVE integration is enabled"""
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        service = get_cve_service()
        if not service:
            return jsonify({'error': 'CVE service not available'}), 503
        if not service.is_enabled():
            return jsonify({
                'error': 'CVE integration is disabled',
                'enabled': False,
                'message': 'Contact administrator to enable CVE integration'
            }), 503
        return f(*args, **kwargs)
    return decorated


# ============================================================================
# Admin Settings - Superadmin Only
# ============================================================================

@cve_bp.route('/api/admin/cve/settings', methods=['GET'])
@require_auth_and_permission('manage_settings')
def get_cve_settings():
    """
    Get CVE integration settings.

    Superadmin only - view current configuration.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        settings = db.session.query(CVESettings).first()

        if not settings:
            # Create default settings (disabled)
            settings = CVESettings(enabled=False)
            db.session.add(settings)
            db.session.commit()

        return jsonify({
            'settings': settings.to_dict(),
            'database_stats': {
                'total_cves': db.session.query(CVERecord).count(),
                'total_cpe_matches': db.session.query(CPEMatch).count(),
                'total_package_mappings': db.session.query(PackageCPEMap).count()
            }
        })

    except Exception as e:
        logger.error(f"Error getting CVE settings: {e}")
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/settings', methods=['PUT'])
@require_auth_permission_and_log('manage_settings', 'update_cve_settings')
def update_cve_settings():
    """
    Update CVE integration settings.

    Superadmin only - enable/disable, configure sync, set thresholds.

    Request Body:
    {
        "enabled": true,                      # Main on/off switch
        "nvd_api_key": "xxx",                 # Optional NVD API key
        "auto_sync_enabled": true,            # Enable scheduled sync
        "sync_schedule_cron": "0 3 * * *",    # Cron schedule
        "offline_mode": false,                # Use offline data only
        "alert_on_critical": true,            # Alert on critical CVEs
        "alert_on_high": true,                # Alert on high CVEs
        "critical_threshold": 9.0,            # CVSS threshold for critical
        "high_threshold": 7.0                 # CVSS threshold for high
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}
        user = get_current_user()

        settings = db.session.query(CVESettings).first()
        if not settings:
            settings = CVESettings(enabled=False)
            db.session.add(settings)

        # Feature toggle
        if 'enabled' in data:
            old_enabled = settings.enabled
            settings.enabled = bool(data['enabled'])
            if old_enabled != settings.enabled:
                logger.info(f"CVE integration {'enabled' if settings.enabled else 'disabled'} by {user}")

        # NVD API key
        if 'nvd_api_key' in data:
            settings.nvd_api_key = data['nvd_api_key'] if data['nvd_api_key'] else None
            # Update rate limit based on key presence
            settings.nvd_rate_limit = 50 if settings.nvd_api_key else 5

        # Auto sync settings
        if 'auto_sync_enabled' in data:
            settings.auto_sync_enabled = bool(data['auto_sync_enabled'])
        if 'sync_schedule_cron' in data:
            settings.sync_schedule_cron = data['sync_schedule_cron']

        # Offline mode
        if 'offline_mode' in data:
            settings.offline_mode = bool(data['offline_mode'])
        if 'offline_data_path' in data:
            settings.offline_data_path = data['offline_data_path']

        # Alert settings
        if 'alert_on_critical' in data:
            settings.alert_on_critical = bool(data['alert_on_critical'])
        if 'alert_on_high' in data:
            settings.alert_on_high = bool(data['alert_on_high'])
        if 'critical_threshold' in data:
            settings.critical_threshold = float(data['critical_threshold'])
        if 'high_threshold' in data:
            settings.high_threshold = float(data['high_threshold'])

        # Data retention
        if 'max_cve_age_days' in data:
            settings.max_cve_age_days = int(data['max_cve_age_days'])
        if 'purge_old_cves' in data:
            settings.purge_old_cves = bool(data['purge_old_cves'])

        settings.updated_by = str(user)
        settings.updated_at = datetime.utcnow()

        db.session.commit()

        return jsonify({
            'message': 'CVE settings updated',
            'settings': settings.to_dict()
        })

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating CVE settings: {e}")
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/enable', methods=['POST'])
@require_auth_permission_and_log('manage_settings', 'enable_cve_integration')
def enable_cve_integration():
    """
    Quick enable CVE integration.

    Superadmin only - simple on switch.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        user = get_current_user()
        settings = db.session.query(CVESettings).first()

        if not settings:
            settings = CVESettings(enabled=True)
            db.session.add(settings)
        else:
            settings.enabled = True

        settings.updated_by = str(user)
        db.session.commit()

        logger.info(f"CVE integration enabled by {user}")

        return jsonify({
            'message': 'CVE integration enabled',
            'enabled': True
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/disable', methods=['POST'])
@require_auth_permission_and_log('manage_settings', 'disable_cve_integration')
def disable_cve_integration():
    """
    Quick disable CVE integration.

    Superadmin only - emergency off switch.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        user = get_current_user()
        data = request.get_json() or {}
        reason = data.get('reason', 'No reason provided')

        settings = db.session.query(CVESettings).first()
        if settings:
            settings.enabled = False
            settings.updated_by = str(user)
            db.session.commit()

        logger.warning(f"CVE integration disabled by {user}: {reason}")

        return jsonify({
            'message': 'CVE integration disabled',
            'enabled': False,
            'reason': reason
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Manual Sync - Superadmin Only
# ============================================================================

@cve_bp.route('/api/admin/cve/sync', methods=['POST'])
@require_auth_permission_and_log('manage_settings', 'trigger_cve_sync')
def trigger_manual_sync():
    """
    Trigger manual CVE sync.

    Superadmin only - manually update CVE database.

    Request Body:
    {
        "sync_type": "delta",     # delta (default) or full
        "days_back": 7            # For delta sync, how many days back
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        sync_service = get_sync_service()
        if not sync_service:
            return jsonify({'error': 'Sync service not available'}), 503

        user = get_current_user()
        data = request.get_json() or {}

        sync_type = data.get('sync_type', 'delta')
        if sync_type not in ('delta', 'full'):
            sync_type = 'delta'

        days_back = data.get('days_back', 7)

        result = sync_service.run_sync(
            sync_type=sync_type,
            triggered_by=str(user),
            days_back=days_back
        )

        if result.get('success'):
            return jsonify({
                'message': f'{sync_type.capitalize()} sync completed',
                'result': result
            })
        else:
            return jsonify({
                'error': result.get('error', 'Sync failed'),
                'result': result
            }), 400

    except Exception as e:
        logger.error(f"Manual sync failed: {e}")
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/sync/cancel', methods=['POST'])
@require_auth_permission_and_log('manage_settings', 'cancel_cve_sync')
def cancel_sync():
    """Cancel in-progress sync"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        sync_service = get_sync_service()
        result = sync_service.cancel_sync()

        user = get_current_user()
        logger.info(f"CVE sync cancelled by {user}")

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/sync/status', methods=['GET'])
@require_auth_and_permission('manage_settings')
def get_sync_status():
    """Get current sync status"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        settings = db.session.query(CVESettings).first()

        # Get recent sync logs
        logs = db.session.query(CVESyncLog)\
            .order_by(CVESyncLog.started_at.desc())\
            .limit(10)\
            .all()

        return jsonify({
            'enabled': settings.enabled if settings else False,
            'current_status': settings.last_sync_status if settings else None,
            'last_sync': {
                'at': settings.last_sync_at.isoformat() if settings and settings.last_sync_at else None,
                'status': settings.last_sync_status if settings else None,
                'message': settings.last_sync_message if settings else None,
                'cve_count': settings.last_sync_cve_count if settings else 0
            } if settings else None,
            'recent_logs': [log.to_dict() for log in logs]
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/sync/logs', methods=['GET'])
@require_auth_and_permission('manage_settings')
def get_sync_logs():
    """Get sync history logs"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)

        query = db.session.query(CVESyncLog)
        total = query.count()

        logs = query.order_by(CVESyncLog.started_at.desc())\
            .offset((page - 1) * per_page)\
            .limit(per_page)\
            .all()

        return jsonify({
            'logs': [log.to_dict() for log in logs],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# CVE Lookup - Requires CVE Enabled
# ============================================================================

@cve_bp.route('/api/cve/status', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_cve_status():
    """
    Get CVE integration status.

    Returns whether feature is enabled without requiring admin.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        service = get_cve_service()
        settings = db.session.query(CVESettings).first()

        return jsonify({
            'enabled': service.is_enabled() if service else False,
            'has_api_key': bool(settings.nvd_api_key) if settings else False,
            'last_sync': settings.last_sync_at.isoformat() if settings and settings.last_sync_at else None,
            'total_cves': db.session.query(CVERecord).count(),
            'offline_mode': settings.offline_mode if settings else False
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/cve/search', methods=['GET'])
@require_auth_and_permission('view_history')
@require_cve_enabled
def search_cves():
    """
    Search CVE database.

    Query Parameters:
        keyword: str - Keyword search
        severity: str - CRITICAL, HIGH, MEDIUM, LOW
        vendor: str - Filter by vendor
        product: str - Filter by product
        page: int - Page number
        per_page: int - Results per page
    """
    try:
        keyword = request.args.get('keyword')
        severity = request.args.get('severity')
        vendor = request.args.get('vendor')
        product = request.args.get('product')
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)

        query = db.session.query(CVERecord)

        if keyword:
            query = query.filter(CVERecord.description.ilike(f'%{keyword}%'))
        if severity:
            query = query.filter(CVERecord.cvss_v3_severity == severity.upper())
        if vendor or product:
            query = query.join(CPEMatch)
            if vendor:
                query = query.filter(CPEMatch.vendor == vendor.lower())
            if product:
                query = query.filter(CPEMatch.product == product.lower())

        total = query.count()

        cves = query.order_by(CVERecord.cvss_v3_score.desc().nullslast())\
            .offset((page - 1) * per_page)\
            .limit(per_page)\
            .all()

        return jsonify({
            'cves': [cve.to_dict() for cve in cves],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        logger.error(f"CVE search error: {e}")
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/cve/<cve_id>', methods=['GET'])
@require_auth_and_permission('view_history')
@require_cve_enabled
def get_cve(cve_id: str):
    """Get CVE details by ID"""
    try:
        service = get_cve_service()
        result = service.lookup_cve(cve_id)

        if not result:
            return jsonify({'error': 'CVE not found'}), 404

        if 'error' in result:
            return jsonify(result), 400

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/cve/affected/<int:execution_id>', methods=['GET'])
@require_auth_and_permission('view_history')
@require_cve_enabled
def get_affected_cves(execution_id: int):
    """
    Get CVEs affecting packages in an audit execution.

    Correlates detected packages with CVE database.
    """
    try:
        service = get_cve_service()
        result = service.correlate_execution(execution_id)

        if 'error' in result:
            status = 400 if result.get('enabled') is False else 404
            return jsonify(result), status

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/cve/server/<int:server_id>', methods=['GET'])
@require_auth_and_permission('view_dashboard')
@require_cve_enabled
def get_server_cve_summary(server_id: int):
    """Get CVE summary for a server"""
    try:
        server = db.session.query(Server).get(server_id)
        if not server:
            return jsonify({'error': 'Server not found'}), 404

        summary = db.session.query(ServerCVESummary)\
            .filter(ServerCVESummary.server_id == server_id)\
            .first()

        if not summary:
            return jsonify({
                'server_id': server_id,
                'server_name': server.name,
                'message': 'No CVE scan available. Run an audit with package detection.'
            })

        return jsonify({
            'server_id': server_id,
            'server_name': server.name,
            'cve_summary': summary.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/cve/summary', methods=['GET'])
@require_auth_and_permission('view_dashboard')
@require_cve_enabled
def get_organization_cve_summary():
    """Get organization-wide CVE summary"""
    try:
        from sqlalchemy import func

        # Aggregate all server summaries
        totals = db.session.query(
            func.sum(ServerCVESummary.critical_count).label('critical'),
            func.sum(ServerCVESummary.high_count).label('high'),
            func.sum(ServerCVESummary.medium_count).label('medium'),
            func.sum(ServerCVESummary.low_count).label('low'),
            func.sum(ServerCVESummary.total_cves).label('total'),
            func.count(ServerCVESummary.id).label('servers_scanned')
        ).first()

        # Get servers with most critical CVEs
        top_critical = db.session.query(ServerCVESummary)\
            .join(Server)\
            .filter(ServerCVESummary.critical_count > 0)\
            .order_by(ServerCVESummary.critical_count.desc())\
            .limit(10)\
            .all()

        return jsonify({
            'summary': {
                'critical': totals.critical or 0,
                'high': totals.high or 0,
                'medium': totals.medium or 0,
                'low': totals.low or 0,
                'total': totals.total or 0,
                'servers_scanned': totals.servers_scanned or 0
            },
            'top_critical_servers': [
                {
                    'server_id': s.server_id,
                    'critical_count': s.critical_count,
                    'total_cves': s.total_cves
                }
                for s in top_critical
            ]
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Package to CPE Mapping - Admin
# ============================================================================

@cve_bp.route('/api/admin/cve/mappings', methods=['GET'])
@require_auth_and_permission('manage_settings')
def get_package_mappings():
    """List package-to-CPE mappings"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        distro = request.args.get('distro')

        query = db.session.query(PackageCPEMap)
        if distro:
            query = query.filter(PackageCPEMap.distro == distro.lower())

        mappings = query.order_by(PackageCPEMap.package_name).all()

        return jsonify({
            'mappings': [m.to_dict() for m in mappings],
            'total': len(mappings)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/mappings', methods=['POST'])
@require_auth_permission_and_log('manage_settings', 'add_package_cpe_mapping')
def add_package_mapping():
    """
    Add package-to-CPE mapping.

    Request Body:
    {
        "package_name": "httpd",
        "distro": "rhel",
        "cpe_vendor": "apache",
        "cpe_product": "http_server",
        "notes": "Apache HTTP Server"
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}

        required = ['package_name', 'distro', 'cpe_vendor', 'cpe_product']
        for field in required:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400

        mapping = PackageCPEMap(
            package_name=data['package_name'].lower(),
            distro=data['distro'].lower(),
            cpe_vendor=data['cpe_vendor'].lower(),
            cpe_product=data['cpe_product'].lower(),
            notes=data.get('notes')
        )

        db.session.add(mapping)
        db.session.commit()

        return jsonify({
            'message': 'Mapping added',
            'mapping': mapping.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@cve_bp.route('/api/admin/cve/mappings/<int:mapping_id>', methods=['DELETE'])
@require_auth_permission_and_log('manage_settings', 'delete_package_cpe_mapping')
def delete_package_mapping(mapping_id: int):
    """Delete a package-to-CPE mapping"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        mapping = db.session.query(PackageCPEMap).get(mapping_id)
        if not mapping:
            return jsonify({'error': 'Mapping not found'}), 404

        db.session.delete(mapping)
        db.session.commit()

        return jsonify({'message': 'Mapping deleted'})

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
