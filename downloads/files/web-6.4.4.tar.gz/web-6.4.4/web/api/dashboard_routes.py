#!/usr/bin/env python3
"""
Dashboard API Routes

Provides aggregated data endpoints for the dashboard view:
- GET /api/dashboard/summary - Overall stats (servers, audits, pass/warn/fail)
- GET /api/dashboard/recent-executions - Recent audit executions
- GET /api/dashboard/server-status - Server health overview
- GET /api/dashboard/storage-pressure - Retention pressure for DB and result files

Author: Security Audit Toolkit Team
Date: February 9, 2026
"""

import json
import logging
import os
import shutil
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from flask_login import login_required
from sqlalchemy import func, desc, text

from config import SessionLocal, ROOT_DIR
from auth_core import require_auth_and_permission, require_role, safe_error_response
from logging_utils import log_audit

logger = logging.getLogger(__name__)

# Create blueprint
dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/api/dashboard')


def _pressure_level(usage_pct):
    """Map usage percentage to severity level."""
    if usage_pct >= 95:
        return 'critical'
    if usage_pct >= 80:
        return 'warning'
    return 'ok'


def _safe_ratio(current, maximum):
    """Return usage ratio percentage with 0-safe division and unlimited support."""
    if not maximum or maximum <= 0:
        return None
    return round((current / maximum) * 100, 2)


def _get_database_size_metrics(db):
    """Return physical database size metrics with PostgreSQL and SQLite support."""
    metrics = {
        'db_engine': 'unknown',
        'physical_size_bytes': None,
        'largest_tables': [],
    }

    try:
        bind = db.get_bind()
        if bind is None:
            return metrics

        dialect_name = str(bind.dialect.name or '').lower()
        metrics['db_engine'] = dialect_name or 'unknown'

        if dialect_name == 'postgresql':
            size_row = db.execute(
                text('SELECT pg_database_size(current_database())::bigint AS size_bytes')
            ).fetchone()
            if size_row is not None:
                metrics['physical_size_bytes'] = int(size_row[0] or 0)

            table_rows = db.execute(text("""
                SELECT
                    c.relname AS table_name,
                    pg_total_relation_size(c.oid)::bigint AS size_bytes
                FROM pg_class c
                JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE c.relkind = 'r'
                  AND n.nspname NOT IN ('pg_catalog', 'information_schema')
                ORDER BY pg_total_relation_size(c.oid) DESC
                LIMIT 10
            """)).fetchall()

            metrics['largest_tables'] = [
                {
                    'table_name': str(row[0]),
                    'size_bytes': int(row[1] or 0),
                }
                for row in table_rows
            ]
            return metrics

        if dialect_name == 'sqlite':
            page_count_row = db.execute(text('PRAGMA page_count')).fetchone()
            page_size_row = db.execute(text('PRAGMA page_size')).fetchone()
            if page_count_row and page_size_row:
                page_count = int(page_count_row[0] or 0)
                page_size = int(page_size_row[0] or 0)
                metrics['physical_size_bytes'] = page_count * page_size
            return metrics
    except Exception as exc:
        logger.warning(f"Failed to collect database size metrics: {exc}")

    return metrics


@dashboard_bp.route('/summary')
@require_auth_and_permission('view_dashboard')
@login_required
@require_role('Analyst')
def get_dashboard_summary():
    """
    Get aggregated dashboard summary statistics

    Returns:
        {
            "success": true,
            "summary": {
                "total_servers": 10,
                "total_audits": 50,
                "total_pass": 200,
                "total_warn": 30,
                "total_fail": 5,
                "audit_by_domain": {"platform": 20, "network": 15, ...}
            }
        }
    """
    db = None
    try:
        db = SessionLocal()
        if db is None:
            # Fallback for when database is not configured
            log_audit(
                action='view_dashboard_summary',
                resource_type='dashboard',
                details={'db_available': False},
                success=True
            )
            return jsonify({
                'success': True,
                'summary': {
                    'total_servers': 0,
                    'total_audits': 0,
                    'total_pass': 0,  # nosec B105
                    'total_warn': 0,
                    'total_fail': 0,
                    'audit_by_domain': {}
                }
            })

        from models.database import Server, Audit, AuditExecution

        # Count servers
        total_servers = db.query(Server).count()

        # Count audits
        total_audits = db.query(Audit).count()

        # Get audit counts by domain
        domain_counts = db.query(
            Audit.domain,
            func.count(Audit.id).label('count')
        ).group_by(Audit.domain).all()

        audit_by_domain = {domain: count for domain, count in domain_counts}

        # Get pass/warn/fail totals from recent executions (last 30 days)
        cutoff = datetime.utcnow() - timedelta(days=30)
        recent_executions = db.query(AuditExecution).filter(
            AuditExecution.executed_at >= cutoff
        ).all()

        total_pass = 0
        total_warn = 0
        total_fail = 0

        for exec in recent_executions:
            if exec.summary:
                try:
                    summary = json.loads(exec.summary) if isinstance(exec.summary, str) else exec.summary
                    total_pass += summary.get('pass', 0)
                    total_warn += summary.get('warn', 0)
                    total_fail += summary.get('fail', 0)
                except (json.JSONDecodeError, TypeError):
                    pass

        summary_payload = {
            'total_servers': total_servers,
            'total_audits': total_audits,
            'total_pass': total_pass,
            'total_warn': total_warn,
            'total_fail': total_fail,
            'audit_by_domain': audit_by_domain,
            'recent_execution_count': len(recent_executions)
        }

        log_audit(
            action='view_dashboard_summary',
            resource_type='dashboard',
            details={
                'total_servers': total_servers,
                'total_audits': total_audits,
                'recent_execution_count': len(recent_executions)
            },
            success=True
        )

        return jsonify({
            'success': True,
            'summary': summary_payload
        })

    except Exception as e:
        log_audit(
            action='view_dashboard_summary',
            resource_type='dashboard',
            success=False,
            error=str(e)
        )
        logger.error(f"Failed to get dashboard summary: {e}")
        return safe_error_response(e, custom_message="Failed to get dashboard summary")

    finally:
        if db:
            db.close()


@dashboard_bp.route('/recent-executions')
@require_auth_and_permission('view_dashboard')
@login_required
@require_role('Analyst')
def get_recent_executions():
    """
    Get recent audit executions for dashboard display

    Query params:
        - limit: Max results (default 10, max 50)

    Returns:
        {
            "success": true,
            "executions": [...]
        }
    """
    db = None
    try:
        db = SessionLocal()
        if db is None:
            log_audit(
                action='view_dashboard_recent_executions',
                resource_type='dashboard',
                details={'db_available': False},
                success=True
            )
            return jsonify({'success': True, 'executions': []})

        from models.database import AuditExecution

        limit = min(int(request.args.get('limit', 10)), 50)

        executions = db.query(AuditExecution).order_by(
            desc(AuditExecution.executed_at)
        ).limit(limit).all()

        log_audit(
            action='view_dashboard_recent_executions',
            resource_type='dashboard',
            details={
                'limit': limit,
                'result_count': len(executions)
            },
            success=True
        )

        return jsonify({
            'success': True,
            'executions': [exec.to_dict() for exec in executions]
        })

    except Exception as e:
        log_audit(
            action='view_dashboard_recent_executions',
            resource_type='dashboard',
            success=False,
            error=str(e)
        )
        logger.error(f"Failed to get recent executions: {e}")
        return safe_error_response(e, custom_message="Failed to get recent executions")

    finally:
        if db:
            db.close()


@dashboard_bp.route('/trends')
@require_auth_and_permission('view_dashboard')
@login_required
@require_role('Analyst')
def get_dashboard_trends():
    """
    Get trend data for dashboard charts

    Query params:
        - days: Number of days (default 7, max 30)

    Returns:
        {
            "success": true,
            "trends": {
                "dates": ["2026-02-03", "2026-02-04", ...],
                "pass_counts": [10, 15, ...],
                "warn_counts": [2, 3, ...],
                "fail_counts": [1, 0, ...]
            }
        }
    """
    db = None
    try:
        db = SessionLocal()
        if db is None:
            log_audit(
                action='view_dashboard_trends',
                resource_type='dashboard',
                details={'db_available': False},
                success=True
            )
            return jsonify({'success': True, 'trends': {'dates': [], 'pass_counts': [], 'warn_counts': [], 'fail_counts': []}})

        from models.database import AuditExecution

        days = min(int(request.args.get('days', 7)), 30)

        # Get daily aggregates
        trends = {'dates': [], 'pass_counts': [], 'warn_counts': [], 'fail_counts': []}

        for i in range(days - 1, -1, -1):
            date = datetime.utcnow().date() - timedelta(days=i)
            start = datetime.combine(date, datetime.min.time())
            end = datetime.combine(date, datetime.max.time())

            day_executions = db.query(AuditExecution).filter(
                AuditExecution.executed_at >= start,
                AuditExecution.executed_at <= end
            ).all()

            day_pass = 0
            day_warn = 0
            day_fail = 0

            for exec in day_executions:
                if exec.summary:
                    try:
                        summary = json.loads(exec.summary) if isinstance(exec.summary, str) else exec.summary
                        day_pass += summary.get('pass', 0)
                        day_warn += summary.get('warn', 0)
                        day_fail += summary.get('fail', 0)
                    except (json.JSONDecodeError, TypeError):
                        pass

            trends['dates'].append(date.isoformat())
            trends['pass_counts'].append(day_pass)
            trends['warn_counts'].append(day_warn)
            trends['fail_counts'].append(day_fail)

        log_audit(
            action='view_dashboard_trends',
            resource_type='dashboard',
            details={
                'days': days,
                'points': len(trends['dates'])
            },
            success=True
        )

        return jsonify({
            'success': True,
            'trends': trends
        })

    except Exception as e:
        log_audit(
            action='view_dashboard_trends',
            resource_type='dashboard',
            success=False,
            error=str(e)
        )
        logger.error(f"Failed to get dashboard trends: {e}")
        return safe_error_response(e, custom_message="Failed to get dashboard trends")

    finally:
        if db:
            db.close()


@dashboard_bp.route('/storage-pressure')
@require_auth_and_permission('view_dashboard')
@login_required
@require_role('Analyst')
def get_storage_pressure():
    """
    Get storage retention pressure for audit data.

    Returns utilization for:
    - audit_executions table (database records)
    - per-host files under data/agent_results
    """
    db = None
    try:
        db = SessionLocal()

        try:
            from security_settings import get_security_setting
            max_records = int(get_security_setting('result_retention_max_records', 100000))
            hypervisor_max_records = int(get_security_setting('hypervisor_result_retention_max_records', max_records))
            standalone_host_cap = int(get_security_setting('standalone_agent_result_max_files_per_host', 5000))
            managed_host_cap = int(get_security_setting('fleet_agent_result_max_files_per_host', 5000))
            disk_guard_enabled = bool(get_security_setting('agent_result_ingest_disk_guard_enabled', True))
            min_free_disk_mb = int(get_security_setting('agent_result_ingest_min_free_disk_mb', 1024))
            min_free_disk_pct = int(get_security_setting('agent_result_ingest_min_free_disk_pct', 5))
        except Exception:
            max_records = 100000
            hypervisor_max_records = max_records
            standalone_host_cap = 5000
            managed_host_cap = 5000
            disk_guard_enabled = True
            min_free_disk_mb = 1024
            min_free_disk_pct = 5

        audit_execution_count = 0
        hypervisor_execution_count = 0
        if db is not None:
            from models.database import AuditExecution, HypervisorAuditExecution
            audit_execution_count = db.query(AuditExecution).count()
            hypervisor_execution_count = db.query(HypervisorAuditExecution).count()

        total_execution_count = audit_execution_count + hypervisor_execution_count

        audit_db_usage_pct = _safe_ratio(audit_execution_count, max_records)
        hypervisor_db_usage_pct = _safe_ratio(hypervisor_execution_count, hypervisor_max_records)
        usage_candidates = [value for value in (audit_db_usage_pct, hypervisor_db_usage_pct) if value is not None]
        db_usage_pct = max(usage_candidates) if usage_candidates else None
        db_level = _pressure_level(db_usage_pct) if db_usage_pct is not None else 'unbounded'

        results_root = os.path.join(ROOT_DIR, 'data', 'agent_results')
        host_counts = []
        total_result_files = 0

        if os.path.isdir(results_root):
            for hostname in os.listdir(results_root):
                host_path = os.path.join(results_root, hostname)
                if not os.path.isdir(host_path):
                    continue

                file_count = 0
                for _, _, files in os.walk(host_path):
                    file_count += sum(1 for name in files if name.endswith('.json'))

                total_result_files += file_count
                host_counts.append({'host': hostname, 'file_count': file_count})

        def _host_pressure(cap):
            over_limit = []
            if cap and cap > 0:
                for item in host_counts:
                    usage_pct = _safe_ratio(item['file_count'], cap)
                    if usage_pct is not None and usage_pct >= 80:
                        over_limit.append({
                            'host': item['host'],
                            'file_count': item['file_count'],
                            'cap': cap,
                            'usage_pct': usage_pct,
                            'level': _pressure_level(usage_pct),
                        })

            over_limit.sort(key=lambda i: i['usage_pct'], reverse=True)
            overall_level = 'ok'
            if any(i['level'] == 'critical' for i in over_limit):
                overall_level = 'critical'
            elif any(i['level'] == 'warning' for i in over_limit):
                overall_level = 'warning'
            elif cap <= 0:
                overall_level = 'unbounded'

            return {
                'cap_per_host': cap,
                'hosts_total': len(host_counts),
                'hosts_warning_or_higher': len(over_limit),
                'level': overall_level,
                'top_pressure_hosts': over_limit[:10],
            }

        standalone_pressure = _host_pressure(standalone_host_cap)
        managed_pressure = _host_pressure(managed_host_cap)

        disk_check_path = results_root if os.path.isdir(results_root) else os.path.join(ROOT_DIR, 'data')
        usage = shutil.disk_usage(disk_check_path)
        free_mb = usage.free // (1024 * 1024)
        free_pct = round((usage.free / usage.total * 100), 2) if usage.total > 0 else 0.0
        disk_blocked = disk_guard_enabled and (free_mb < min_free_disk_mb or free_pct < min_free_disk_pct)
        if not disk_guard_enabled:
            disk_level = 'unbounded'
        elif disk_blocked:
            disk_level = 'critical'
        elif free_mb < (min_free_disk_mb * 2) or free_pct < (min_free_disk_pct * 2):
            disk_level = 'warning'
        else:
            disk_level = 'ok'

        overall_level = 'ok'
        levels = [db_level, standalone_pressure['level'], managed_pressure['level'], disk_level]
        if 'critical' in levels:
            overall_level = 'critical'
        elif 'warning' in levels:
            overall_level = 'warning'
        elif all(level == 'unbounded' for level in levels):
            overall_level = 'unbounded'

        db_size_metrics = _get_database_size_metrics(db)

        payload = {
            'generated_at': datetime.utcnow().isoformat(),
            'overall_level': overall_level,
            'database': {
                    'audit_execution_count': audit_execution_count,
                    'hypervisor_execution_count': hypervisor_execution_count,
                    'total_execution_count': total_execution_count,
                    'max_records': max_records,
                    'hypervisor_max_records': hypervisor_max_records,
                'usage_pct': db_usage_pct,
                    'audit_usage_pct': audit_db_usage_pct,
                    'hypervisor_usage_pct': hypervisor_db_usage_pct,
                    'db_engine': db_size_metrics.get('db_engine', 'unknown'),
                    'physical_size_bytes': db_size_metrics.get('physical_size_bytes'),
                    'largest_tables': db_size_metrics.get('largest_tables', []),
                'level': db_level,
            },
            'agent_result_files': {
                'total_files': total_result_files,
                'standalone': standalone_pressure,
                'managed_fallback': managed_pressure,
            },
            'disk_watermark': {
                'enabled': disk_guard_enabled,
                'check_path': disk_check_path,
                'free_mb': int(free_mb),
                'free_pct': free_pct,
                'min_free_mb': min_free_disk_mb,
                'min_free_pct': min_free_disk_pct,
                'ingest_blocked': disk_blocked,
                'level': disk_level,
            },
            'thresholds': {
                'warning_pct': 80,
                'critical_pct': 95,
            }
        }

        log_audit(
            action='view_dashboard_storage_pressure',
            resource_type='dashboard',
            details={
                'overall_level': overall_level,
                'audit_executions_count': audit_execution_count,
                'agent_result_files_total': total_result_files,
            },
            success=True
        )

        return jsonify({'success': True, 'storage_pressure': payload})

    except Exception as e:
        log_audit(
            action='view_dashboard_storage_pressure',
            resource_type='dashboard',
            success=False,
            error=str(e)
        )
        logger.error(f"Failed to get storage pressure: {e}")
        return safe_error_response(e, custom_message="Failed to get storage pressure")

    finally:
        if db:
            db.close()


# Export blueprint
__all__ = ['dashboard_bp']
