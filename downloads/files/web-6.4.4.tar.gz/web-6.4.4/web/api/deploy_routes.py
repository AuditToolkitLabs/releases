"""
Deployment Routes - Remote Server Deployment

Provides endpoints for:
- Deploying toolkit to servers (/api/deploy)
- Checking deployment status (/api/deploy/status)
"""

import os
import io
import json
import hashlib
import tarfile
import tempfile
import threading
import uuid
import zipfile
import base64
from pathlib import Path
from datetime import datetime
from flask import Blueprint, jsonify, request, send_file

# Import from config
from config import logger
from config import ROOT_DIR
from api.archive_utils import add_directory_to_tar, add_directory_to_zip, is_archiveable_file
from api.agent_pathing import get_standalone_agent_dir
from version_info import get_toolkit_version

# Import auth decorators
from auth_core import require_api_key, conditional_limit, require_auth_and_permission

# Import server management
from models.server import ServerManager

# Import SSH management
from ssh_manager import SSHManager
from encryption import ssh_host_key_manager, password_manager
from config import SSH_DIR

# Create blueprint
deploy_bp = Blueprint('deploy', __name__)

# Initialize managers
server_manager = ServerManager()
ssh_manager = SSHManager(
    ssh_dir=SSH_DIR,
    ssh_host_key_manager=ssh_host_key_manager,
    password_manager=password_manager
)

# ============================================================================
# Global Deployment State (should be injected by main app)
# ============================================================================
deployment_state = {}
STANDALONE_AGENT_DIR = get_standalone_agent_dir()


def _get_toolkit_version() -> str:
    """Resolve current toolkit version from repository VERSION file."""
    return get_toolkit_version(default='0.0.0')


def _generate_standalone_license_token(server_id: str) -> dict:
    """
    Generate a license token for standalone agent deployment.

    Standalone agents get the full tier validity period since they
    operate independently without regular server contact.

    Args:
        server_id: Server identifier for logging

    Returns:
        License token dict to embed in agent package
    """
    try:
        from api.agent_fleet_routes import _generate_license_token
        import hashlib

        # Generate a machine fingerprint placeholder
        # The actual fingerprint will be validated on first run
        # This allows the deployed agent to bind to its host machine
        placeholder_fingerprint = hashlib.sha256(
            f"standalone-deploy-{server_id}-{datetime.now().isoformat()}".encode()
        ).hexdigest()

        # Generate token with standalone agent type (gets full tier validity)
        token = _generate_license_token(
            machine_fingerprint=placeholder_fingerprint,
            agent_type='standalone'
        )

        # Mark as pre-deployment token (agent will re-bind on first run)
        token['_deployment_placeholder'] = True
        token['_server_id'] = server_id

        logger.info(f"Generated standalone license token for server {server_id}")
        return token

    except Exception as e:
        logger.warning(f"Failed to generate standalone license token: {e}")
        return None


def _find_vm_appliance_artifact(deploy_type: str) -> Path | None:
    """Find VM appliance artifact in deployment/vm-appliance/output.

    Returns the best-matching artifact path for `deploy_type` ('ova', 'ovf', or 'vmdk'),
    or None when no artifact is available.
    """
    deploy_type = (deploy_type or '').strip().lower()
    if deploy_type not in ('ova', 'ovf', 'vmdk'):
        return None

    toolkit_version = _get_toolkit_version()
    root_path = Path(ROOT_DIR)
    output_dir = root_path / 'deployment' / 'vm-appliance' / 'output'

    base_name = f'security-audit-toolkit-{toolkit_version}.{deploy_type}'
    candidates = [
        base_name,
        base_name.replace('security-audit-toolkit', 'SecurityAuditToolkit'),
        base_name.replace(f'.{deploy_type}', f'.{deploy_type.upper()}')
    ]

    for fname in candidates:
        fpath = output_dir / fname
        if fpath.exists() and fpath.is_file():
            return fpath

    # Fallback: allow exactly one candidate of same extension.
    files = list(output_dir.glob(f'*.{deploy_type}')) + list(output_dir.glob(f'*.{deploy_type.upper()}'))
    files = [f for f in files if f.is_file()]
    if len(files) == 1:
        return files[0]

    return None


def _get_vm_output_dir() -> Path:
    return Path(ROOT_DIR) / 'deployment' / 'vm-appliance' / 'output'


def _get_vm_artifact_candidate_names(deploy_type: str) -> list[str]:
    deploy_type = (deploy_type or '').strip().lower()
    if deploy_type not in ('ova', 'ovf', 'vmdk'):
        return []

    toolkit_version = _get_toolkit_version()
    base_name = f'security-audit-toolkit-{toolkit_version}.{deploy_type}'
    return [
        base_name,
        base_name.replace('security-audit-toolkit', 'SecurityAuditToolkit'),
        base_name.replace(f'.{deploy_type}', f'.{deploy_type.upper()}')
    ]


def _is_numeric_split_part_file(path_obj: Path) -> bool:
    """Return True only for split chunk files ending with .partNNN..."""
    name = path_obj.name
    if '.part' not in name:
        return False
    suffix = name.rsplit('.part', 1)[1]
    return bool(suffix) and suffix.isdigit()


def _find_vm_split_artifact_parts(deploy_type: str) -> tuple[Path | None, list[Path], Path | None]:
    """Locate split part files for a VM artifact type.

    Returns:
      (target_file_path, sorted_part_paths, manifest_path_if_present)
    """
    output_dir = _get_vm_output_dir()
    if not output_dir.exists():
        return None, [], None

    candidate_names = _get_vm_artifact_candidate_names(deploy_type)
    for candidate_name in candidate_names:
        target = output_dir / candidate_name
        parts = sorted(
            p for p in output_dir.glob(f'{candidate_name}.part*')
            if p.is_file() and _is_numeric_split_part_file(p)
        )
        if parts:
            manifest = output_dir / f'{candidate_name}.parts.json'
            return target, parts, manifest if manifest.exists() else None

    all_parts = sorted(
        p for p in output_dir.glob(f'*.{deploy_type}.part*')
        if p.is_file() and _is_numeric_split_part_file(p)
    ) + sorted(
        p for p in output_dir.glob(f'*.{deploy_type.upper()}.part*')
        if p.is_file() and _is_numeric_split_part_file(p)
    )
    if not all_parts:
        return None, [], None

    by_base: dict[str, list[Path]] = {}
    for part in all_parts:
        base_name = part.name.split('.part', 1)[0]
        by_base.setdefault(base_name, []).append(part)

    if len(by_base) == 1:
        base_name = next(iter(by_base.keys()))
        target = output_dir / base_name
        parts = sorted(by_base[base_name])
        manifest = output_dir / f'{base_name}.parts.json'
        return target, parts, manifest if manifest.exists() else None

    return None, [], None


def _verify_split_manifest_hash(file_path: Path, manifest_path: Path | None) -> tuple[bool, str]:
    if not manifest_path or not manifest_path.exists():
        return True, ''

    try:
        with open(manifest_path, 'r', encoding='utf-8') as mf:
            manifest = json.load(mf)
        expected = str(manifest.get('source_sha256', '') or '').strip().lower()
        if not expected:
            return True, ''

        sha = hashlib.sha256()
        with open(file_path, 'rb') as src:
            for chunk in iter(lambda: src.read(1024 * 1024), b''):
                sha.update(chunk)
        actual = sha.hexdigest().lower()
        if actual != expected:
            return False, f'hash mismatch (expected {expected}, got {actual})'
        return True, ''
    except (OSError, ValueError, json.JSONDecodeError) as err:
        return False, f'manifest validation failed: {err}'


def _reassemble_vm_split_artifact(target_path: Path, parts: list[Path], manifest_path: Path | None) -> Path:
    if not parts:
        raise ValueError('No split parts provided for reassembly')

    target_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_out = target_path.with_name(f'{target_path.name}.reassemble.tmp')

    with open(tmp_out, 'wb') as out_f:
        for part in sorted(parts):
            with open(part, 'rb') as in_f:
                while True:
                    chunk = in_f.read(1024 * 1024)
                    if not chunk:
                        break
                    out_f.write(chunk)

    valid, details = _verify_split_manifest_hash(tmp_out, manifest_path)
    if not valid:
        try:
            tmp_out.unlink(missing_ok=True)
        except OSError:
            pass
        raise ValueError(f'Failed to validate reassembled artifact {target_path.name}: {details}')

    tmp_out.replace(target_path)
    return target_path


def _resolve_vm_appliance_artifact(deploy_type: str, allow_reassemble: bool = False) -> tuple[Path | None, dict]:
    """Resolve VM artifact from local full file, split parts, or external URL metadata."""
    info = {
        'source': 'none',
        'split_parts': 0,
        'split_manifest': False,
        'reassembled': False,
    }

    found = _find_vm_appliance_artifact(deploy_type)
    if found:
        info['source'] = 'local'
        return found, info

    split_target, split_parts, split_manifest = _find_vm_split_artifact_parts(deploy_type)
    if split_target and split_parts:
        info['source'] = 'split'
        info['split_parts'] = len(split_parts)
        info['split_manifest'] = bool(split_manifest)

        if allow_reassemble:
            reassembled = _reassemble_vm_split_artifact(split_target, split_parts, split_manifest)
            info['reassembled'] = True
            return reassembled, info

        return None, info

    return None, info


def _get_vm_appliance_external_url(deploy_type: str) -> str | None:
    """Return externally hosted VM appliance URL from environment, if configured."""
    deploy_type = (deploy_type or '').strip().lower()
    env_map = {
        'ova': 'VM_APPLIANCE_OVA_URL',
        'ovf': 'VM_APPLIANCE_OVF_URL',
        'vmdk': 'VM_APPLIANCE_VMDK_URL'
    }
    env_var = env_map.get(deploy_type)
    if not env_var:
        return None

    url = os.environ.get(env_var, '').strip()
    return url or None


def init_deploy_routes(deploy_state):
    """Initialize deployment routes with shared state from main app"""
    global deployment_state
    deployment_state = deploy_state


# ============================================================================
# Deployment Operations
# ============================================================================
@deploy_bp.route('/api/deploy', methods=['POST'])
@require_api_key
@conditional_limit("5 per hour")
def deploy_to_servers():
    """Deploy toolkit to selected servers

    Supported deploy_types:
    - 'full': Complete audit toolkit with web interface
    - 'scripts': Audit scripts only (no web interface)

    Note: For agent deployments, use:
    - /api/deploy/jre-agent (standalone or managed mode)
    - /api/deploy/fleet-agent (managed mode only)
    """
    global deployment_state

    if deployment_state.get("deploying"):
        return jsonify({"success": False, "error": "Deployment already in progress"}), 400

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        server_ids = data.get("server_ids", [])
        deploy_type = data.get("deploy_type", "full")  # 'full' or 'scripts'

        if not isinstance(server_ids, list):
            return jsonify({"success": False, "error": "Invalid server_ids format"}), 400
        if deploy_type not in ("full", "scripts"):
            return jsonify({"success": False, "error": "Invalid deploy_type. Use 'full' or 'scripts', or use /api/deploy/jre-agent for agent deployments"}), 400
    except Exception as e:
        logger.error(f"Deploy validation error: {e}")
        return jsonify({"success": False, "error": "Invalid request data"}), 400

    if not server_ids:
        return jsonify({"success": False, "error": "No servers selected"}), 400

    servers = server_manager.load_servers()
    target_servers = [s for s in servers if s["id"] in server_ids]

    if not target_servers:
        return jsonify({"success": False, "error": "No valid servers found"}), 400

    # Reset deployment state
    deployment_state.update({
        "deploying": True,
        "progress": [],
        "current_server": None,
        "success": None,
        "deploy_type": deploy_type
    })

    def deploy_worker():
        """Background deployment worker"""
        try:
            # Create deployment package
            type_labels = {
                "scripts": "scripts only",
                "full": "full toolkit"
            }
            type_label = type_labels.get(deploy_type, "full toolkit")
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": f"Creating {type_label} package..."
            })

            with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp_file:
                package_path = tmp_file.name

                with tarfile.open(package_path, "w:gz") as tar:
                    if deploy_type == "scripts":
                        # Scripts only package: audits + lib dependencies
                        audits_path = ROOT_DIR / "audits"
                        if audits_path.exists():
                            add_directory_to_tar(tar, audits_path, "audits")

                        lib_path = ROOT_DIR / "lib"
                        if lib_path.exists():
                            add_directory_to_tar(tar, lib_path, "lib")
                    else:
                        # Full package: all directories
                        dirs = ["audits", "lib", "orchestrator", "ci", "docs", "tools"]
                        for dir_name in dirs:
                            dir_path = ROOT_DIR / dir_name
                            if dir_path.exists():
                                add_directory_to_tar(tar, dir_path, dir_name)

                    # Add essential files for both types
                    essential_files = ["README.md", "LICENSE"]
                    if deploy_type == "full":
                        essential_files.extend([
                            "Makefile", ".shellcheckrc",
                            "install.sh", "setup.sh", "uninstall.sh"
                        ])

                    for file_name in essential_files:
                        file_path = ROOT_DIR / file_name
                        if file_path.exists() and is_archiveable_file(file_path):
                            tar.add(file_path, arcname=file_name)

                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"Package created: {os.path.getsize(package_path) / 1024:.2f} KB"
                })

            # Deploy to each server
            for server in target_servers:
                deployment_state["current_server"] = server["name"]
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"Deploying to {server['name']} ({server['host']})..."
                })

                try:
                    # Ensure host key is known before deployment
                    if not ssh_host_key_manager.host_known(server['host'], server.get('port', 22)):
                        logger.info(f"Scanning SSH key for {server['host']} before deployment")
                        ssh_host_key_manager.add_host_key(server['host'], server.get('port', 22))

                    # Create remote directory
                    mkdir_cmd = f"mkdir -p {server['remote_path']}"
                    result = ssh_manager.execute_command(server, mkdir_cmd, timeout=30)

                    if result.returncode != 0:
                        raise Exception(f"Failed to create directory: {result.stderr}")

                    # Copy package
                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"Transferring files to {server['name']}..."
                    })

                    remote_tar_path = f"{server['remote_path']}/toolkit.tar.gz"
                    result = ssh_manager.copy_file(server, package_path, remote_tar_path, timeout=120)

                    if result.returncode != 0:
                        raise Exception(f"Failed to transfer files: {result.stderr}")

                    # Extract package
                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"Extracting files on {server['name']}..."
                    })

                    extract_cmd = f"cd {server['remote_path']} && tar -xzf toolkit.tar.gz && rm toolkit.tar.gz"
                    result = ssh_manager.execute_command(server, extract_cmd, timeout=60)

                    if result.returncode != 0:
                        raise Exception(f"Failed to extract files: {result.stderr}")

                    # Make scripts executable
                    chmod_cmd = f"cd {server['remote_path']} && find . -name '*.sh' -type f -exec chmod +x {{}} +"
                    ssh_manager.execute_command(server, chmod_cmd, timeout=30)

                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"✓ Successfully deployed to {server['name']}"
                    })

                except Exception as e:
                    logger.error(f"Deployment failed for {server['name']}: {e}")
                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"✗ Failed to deploy to {server['name']}: {str(e)}"
                    })

            # Cleanup
            try:
                os.unlink(package_path)
            except Exception as e:
                logger.debug(f"Cleanup failed for {package_path}: {e}")

            deployment_state["deploying"] = False
            deployment_state["success"] = True
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": "Deployment complete!"
            })

        except Exception as e:
            deployment_state["deploying"] = False
            deployment_state["success"] = False
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": f"ERROR: {str(e)}"
            })

    # Start deployment thread
    thread = threading.Thread(target=deploy_worker, daemon=True)
    thread.start()

    return jsonify({"success": True, "message": "Deployment started"})


@deploy_bp.route('/api/deploy/status')
@require_api_key
def get_deployment_status():
    """Get deployment status"""
    return jsonify({
        "success": True,
        "deploying": deployment_state.get("deploying", False),
        "progress": deployment_state.get("progress", [])[-50:],  # Last 50 messages
        "current_server": deployment_state.get("current_server"),
        "total_messages": len(deployment_state.get("progress", []))
    })


# ============================================================================
# Agent-Specific Deployment (DEPRECATED - Use /api/deploy/jre-agent)
# ============================================================================
# DEPRECATED: Use /api/deploy/jre-agent instead with mode='standalone'
# The JRE agent provides the same functionality with no Python dependencies
# and includes the same web UI. This endpoint is kept for backward compatibility.
@deploy_bp.route('/api/deploy/agent', methods=['POST'])
@require_api_key
@conditional_limit("10 per hour")
def deploy_agent_to_servers():
    """
    Deploy standalone agent to servers [DEPRECATED]

    DEPRECATED: This endpoint is deprecated. Use /api/deploy/jre-agent instead.

    The JRE agent in standalone mode provides:
    - Same web UI on port 8088
    - No Python dependency (self-contained)
    - Same functionality as standalone agent
    - Optional upload to core server

    This endpoint remains for backward compatibility but will be removed in a future version.
    """

    # Log deprecation warning
    logger.warning("Deprecated endpoint /api/deploy/agent called. Use /api/deploy/jre-agent instead.")

    global deployment_state

    if deployment_state.get("deploying"):
        return jsonify({"success": False, "error": "Deployment already in progress"}), 400

    try:
        data = request.json or {}
        server_ids = data.get("server_ids", [])
        config = data.get("config", {})

        # Agent configuration options
        agent_config = {
            "server_url": config.get("server_url", ""),
            "api_key": config.get("api_key", ""),
            "upload_results": config.get("upload_results", True),
            "keep_local_results": config.get("keep_local_results", True),
            "include_full_audits": config.get("include_full_audits", False),
            "include_web_ui": config.get("include_web_ui", True),
            "setup_scheduled_task": config.get("setup_scheduled_task", False),
            "schedule_time": config.get("schedule_time", "02:00"),
            "disable_remote_after": config.get("disable_remote_after", False),
            # License delegation settings
            "enable_license_delegation": config.get("enable_license_delegation", True),
            "license_refresh_hours": config.get("license_refresh_hours", 1),
        }

    except Exception as e:
        logger.error(f"Agent deploy validation error: {e}")
        return jsonify({"success": False, "error": "Invalid request data"}), 400

    if not server_ids:
        return jsonify({"success": False, "error": "No servers selected"}), 400

    servers = server_manager.load_servers()
    target_servers = [s for s in servers if s["id"] in server_ids]

    if not target_servers:
        return jsonify({"success": False, "error": "No valid servers found"}), 400

    # Reset deployment state
    deployment_state.update({
        "deploying": True,
        "progress": [],
        "current_server": None,
        "success": None,
        "deploy_type": "agent"
    })

    def agent_deploy_worker():
        """Background agent deployment worker"""
        try:
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": "Starting agent deployment..."
            })

            # Create agent package
            with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp_linux:
                linux_package = tmp_linux.name
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_win:
                windows_package = tmp_win.name

            # Build Linux package
            _build_linux_agent_package(linux_package, agent_config)

            # Build Windows package
            _build_windows_agent_package(windows_package, agent_config)

            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": "Agent packages created"
            })

            # Deploy to each server
            for server in target_servers:
                deployment_state["current_server"] = server["name"]
                os_type = server.get("os_type", "linux")

                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"Deploying agent to {server['name']} ({os_type})..."
                })

                try:
                    if os_type == "windows":
                        _deploy_windows_agent(server, windows_package, agent_config)
                    else:
                        _deploy_linux_agent(server, linux_package, agent_config)

                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"✓ Agent deployed to {server['name']}"
                    })

                    # Optionally disable remote access after deployment
                    if agent_config.get("disable_remote_after"):
                        _disable_remote_access(server)
                        deployment_state["progress"].append({
                            "timestamp": datetime.now().isoformat(),
                            "message": f"✓ Remote access disabled on {server['name']}"
                        })

                except Exception as e:
                    logger.error(f"Agent deployment failed for {server['name']}: {e}")
                    deployment_state["progress"].append({
                        "timestamp": datetime.now().isoformat(),
                        "message": f"✗ Failed: {server['name']}: {str(e)}"
                    })

            # Cleanup
            for pkg in [linux_package, windows_package]:
                try:
                    os.unlink(pkg)
                except Exception as e:
                    logger.debug(f"Cleanup failed for {pkg}: {e}")

            deployment_state["deploying"] = False
            deployment_state["success"] = True
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": "Agent deployment complete!"
            })

        except Exception as e:
            deployment_state["deploying"] = False
            deployment_state["success"] = False
            deployment_state["progress"].append({
                "timestamp": datetime.now().isoformat(),
                "message": f"ERROR: {str(e)}"
            })

    # Start deployment thread
    thread = threading.Thread(target=agent_deploy_worker, daemon=True)
    thread.start()

    return jsonify({"success": True, "message": "Agent deployment started"})


# ============================================================================
# Fleet Agent Deployment
# ============================================================================
@deploy_bp.route('/api/deploy/fleet-agent', methods=['POST'])
@require_api_key
@require_auth_and_permission('deploy')
@conditional_limit("10/minute")
def deploy_fleet_agent():
    """
    Deploy fleet agent to selected servers via SSH, WinRM, or API-only mode.

    The fleet agent provides two-way API communication with the server,
    enabling remote configuration, automatic script sync, and DB-integrated results.

    Connection Methods:
    - ssh: Push deployment via SSH (Linux/Unix servers)
    - winrm: Push deployment via WinRM (Windows servers)
    - api: API-only mode - no push deployment, agent must be manually installed
           and will communicate via API endpoints

    Request body:
    {
        "server_ids": [1, 2, 3],
        "connection_method": "ssh" | "winrm" | "api",
        "config": {
            "server_url": "https://audit-server:5000",
            "api_key": "optional-api-key",
            "poll_interval": 60,
            "auto_sync": true
        }
    }

    Returns:
        For ssh/winrm: Initiates background deployment
        For api: Returns agent configuration and download links
    """
    try:
        data = request.json or {}
        server_ids = data.get("server_ids", [])
        connection_method = data.get("connection_method", "auto")  # auto, ssh, winrm, api
        config = data.get("config", {})

        if not server_ids:
            return jsonify({"success": False, "error": "No servers selected"}), 400

        # Get servers from database
        servers = []
        for server_id in server_ids:
            server = server_manager.get_server(server_id)
            if server:
                servers.append(server)

        if not servers:
            return jsonify({"success": False, "error": "No valid servers found"}), 400

        # Handle API-only mode (no push deployment needed)
        if connection_method == "api":
            return _handle_api_only_deployment(servers, config)

        # Reset deployment state for push deployments
        deployment_state["running"] = True
        deployment_state["progress"] = []
        deployment_state["completed"] = 0
        deployment_state["failed"] = 0
        deployment_state["total"] = len(servers)

        def fleet_agent_deploy_worker():
            """Background fleet agent deployment worker"""
            try:
                method_label = "SSH" if connection_method == "ssh" else "WinRM" if connection_method == "winrm" else "auto-detected"
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"Starting fleet agent deployment via {method_label}..."
                })

                for server in servers:
                    try:
                        # Determine deployment method
                        deploy_method = connection_method
                        if deploy_method == "auto":
                            server_os = server.get("os_type", "").lower()
                            server_conn = server.get("connection_type", "").lower()
                            if "windows" in server_os or server_conn == "winrm":
                                deploy_method = "winrm"
                            else:
                                deploy_method = "ssh"

                        deployment_state["progress"].append({
                            "timestamp": datetime.now().isoformat(),
                            "message": f"Deploying fleet agent to {server['name']} via {deploy_method.upper()}..."
                        })

                        # Deploy based on method
                        if deploy_method == "winrm":
                            _deploy_fleet_agent_windows(server, config)
                        else:
                            _deploy_fleet_agent_linux(server, config)

                        deployment_state["completed"] += 1
                        deployment_state["progress"].append({
                            "timestamp": datetime.now().isoformat(),
                            "message": f"✓ Managed agent deployed to {server['name']}"
                        })

                    except Exception as e:
                        deployment_state["failed"] += 1
                        logger.error(f"Managed agent deployment failed for {server['name']}: {e}")
                        deployment_state["progress"].append({
                            "timestamp": datetime.now().isoformat(),
                            "message": f"✗ Failed for {server['name']}: {str(e)}"
                        })

                deployment_state["running"] = False
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": "Managed agent deployment complete!"
                })

            except Exception as e:
                deployment_state["running"] = False
                logger.error(f"Managed agent deployment error: {e}")
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"ERROR: {str(e)}"
                })

        # Start deployment thread
        thread = threading.Thread(target=fleet_agent_deploy_worker, daemon=True)
        thread.start()

        return jsonify({"success": True, "message": "Managed agent deployment started"})

    except Exception as e:
        logger.error(f"Managed agent deploy error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# JRE Consolidated Agent Deployment
# ============================================================================
@deploy_bp.route('/api/deploy/jre-agent', methods=['POST'])
@require_api_key
@require_auth_and_permission('deploy')
@conditional_limit("10/minute")
def deploy_jre_agent():
    """
    Deploy consolidated JRE agent to selected servers.

    Supports both managed mode (two-way API) and standalone mode (ad-hoc).
    Uses SSH for Linux and WinRM for Windows deployment.

    Request body:
    {
        "server_ids": ["server1", "server2"],
        "deploy_type": "jre-agent",
        "config": {
            "mode": "managed" | "standalone",
            "server_url": "https://server:5000",
            "api_key": "key",
            "connection_method": "ssh" | "winrm" | "api",
            "poll_interval": 60,
            "auto_sync": true,
            ...
        }
    }
    """
    global deployment_state

    if deployment_state.get("deploying"):
        return jsonify({"success": False, "error": "Another deployment is in progress"}), 409

    try:
        data = request.get_json()
        server_ids = data.get('server_ids', [])
        config = data.get('config', {})

        if not server_ids:
            return jsonify({"success": False, "error": "No servers selected"}), 400

        # Get servers
        servers = []
        for server_id in server_ids:
            server = server_manager.get_server(server_id)
            if server:
                servers.append(server)

        if not servers:
            return jsonify({"success": False, "error": "No valid servers found"}), 400

        # Set deployment state
        deployment_state["deploying"] = True
        deployment_state["status"] = "starting"
        deployment_state["progress"] = ""
        deployment_state["current_server"] = None

        # Start deployment thread
        thread = threading.Thread(target=jre_agent_deploy_worker, args=(servers, config), daemon=True)
        thread.start()

        return jsonify({"success": True, "message": "JRE agent deployment started"})

    except Exception as e:
        logger.error(f"JRE agent deploy error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


def _handle_api_only_deployment(servers: list, config: dict):
    """
    Handle API-only deployment mode.

    Instead of pushing the agent, this prepares the configuration and returns
    download links and instructions for manual agent installation.
    """
    try:
        results = []
        server_url = config.get("server_url", "")
        api_key = config.get("api_key", "")

        for server in servers:
            agent_id = f"agent-{server.get('id', 'unknown')}"

            # Create/update agent configuration on server
            agent_config = {
                "agent_id": agent_id,
                "server_url": server_url,
                "api_key": api_key,
                "poll_interval": config.get("poll_interval", 60),
                "auto_sync": config.get("auto_sync", True),
                "server_name": server.get("name", ""),
                "server_host": server.get("host", "")
            }

            # Save config for this agent
            config_dir = ROOT_DIR / "data" / "agent_configs"
            config_dir.mkdir(parents=True, exist_ok=True)
            config_file = config_dir / f"{agent_id}.json"
            with open(config_file, 'w') as f:
                json.dump(agent_config, f, indent=2)

            results.append({
                "server": server.get("name"),
                "agent_id": agent_id,
                "status": "configured",
                "message": "Agent configuration created. Download and install agent manually."
            })

        return jsonify({
            "success": True,
            "method": "api",
            "message": "API-only deployment configured. Agents must be installed manually.",
            "results": results,
            "download_links": {
                "windows_script": "/api/agent/download/windows?format=raw",
                "linux_script": "/api/agent/download/linux?format=raw",
                "windows_package": "/api/agent/download/windows?format=package",
                "linux_package": "/api/agent/download/linux?format=package",
                "windows_installer_helper": "/api/agent/download/installer/windows",
                "linux_installer_helper": "/api/agent/download/installer/linux",
                "config_template": "/api/agent/download/config-template"
            },
            "instructions": {
                "windows": "1. Download windows_package\n2. Extract archive\n3. Run as admin: .\\install-windows.ps1 -Mode Service -ServerUrl <URL> -ApiKey <KEY> -AgentId <AGENT_ID>",
                "linux": "1. Download linux_package\n2. Extract archive\n3. Run as root: sudo ./install-linux.sh <URL> <KEY> <AGENT_ID>"
            }
        })

    except Exception as e:
        logger.error(f"API-only deployment error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


def jre_agent_deploy_worker(servers: list, config: dict):
    """Background JRE agent deployment worker"""
    global deployment_state

    deployment_state["running"] = True
    deployment_state["completed"] = 0
    deployment_state["failed"] = 0
    deployment_state["progress"] = []

    try:
        mode = config.get('mode', 'managed')
        connection_method = config.get('connection_method', 'ssh')
        method_label = "SSH" if connection_method == "ssh" else "WinRM" if connection_method == "winrm" else "API"

        deployment_state["progress"].append({
            "timestamp": datetime.now().isoformat(),
            "message": f"Starting JRE {mode} agent deployment via {method_label}..."
        })

        for server in servers:
            try:
                deployment_state["current_server"] = server.get('name', 'unknown')

                # Determine deployment method
                deploy_method = connection_method
                if deploy_method == "auto":
                    server_os = server.get("os_type", "").lower()
                    server_conn = server.get("connection_type", "").lower()
                    if "windows" in server_os or server_conn == "winrm":
                        deploy_method = "winrm"
                    else:
                        deploy_method = "ssh"

                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"Deploying JRE {mode} agent to {server['name']} via {deploy_method.upper()}..."
                })

                # Deploy based on method
                if deploy_method == "winrm":
                    _deploy_jre_agent_windows(server, config)
                elif deploy_method == "api":
                    _deploy_jre_agent_api(server, config)
                else:
                    _deploy_jre_agent_linux(server, config)

                deployment_state["completed"] += 1
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"✓ JRE {mode} agent deployed to {server['name']}"
                })

            except Exception as e:
                deployment_state["failed"] += 1
                logger.error(f"JRE agent deployment failed for {server['name']}: {e}")
                deployment_state["progress"].append({
                    "timestamp": datetime.now().isoformat(),
                    "message": f"✗ Failed for {server['name']}: {str(e)}"
                })

        deployment_state["running"] = False
        deployment_state["progress"].append({
            "timestamp": datetime.now().isoformat(),
            "message": "JRE agent deployment complete!"
        })

    except Exception as e:
        deployment_state["running"] = False
        logger.error(f"JRE agent deployment error: {e}")
        deployment_state["progress"].append({
            "timestamp": datetime.now().isoformat(),
            "message": f"ERROR: {str(e)}"
        })


def _generate_jre_windows_package(server_id: str, config: dict) -> str:
    """Generate JRE consolidated agent ZIP package for Windows deployment"""

    jre_agent_dir = os.path.join(ROOT_DIR, 'agents', 'jre', 'shared')
    project_root = ROOT_DIR

    # Generate temp package
    with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
        package_path = tmp.name

    with zipfile.ZipFile(package_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Add JRE agent JAR files
        target_dir = os.path.join(jre_agent_dir, 'target')
        if os.path.exists(target_dir):
            for jar_file in os.listdir(target_dir):
                if jar_file.endswith('.jar'):
                    zf.write(
                        os.path.join(target_dir, jar_file),
                        arcname=os.path.join('agent', 'lib', jar_file)
                    )

        # Add ALL audit scripts (150+)
        audits_dir = os.path.join(project_root, 'audits')
        add_directory_to_zip(zf, audits_dir, 'audits')

        # Add libraries
        lib_dir = os.path.join(project_root, 'lib')
        add_directory_to_zip(zf, lib_dir, 'lib')

        # Add orchestrator
        orchestrator_dir = os.path.join(project_root, 'orchestrator')
        add_directory_to_zip(zf, orchestrator_dir, 'orchestrator')

        # Add tools
        tools_dir = os.path.join(project_root, 'tools')
        add_directory_to_zip(zf, tools_dir, 'tools')

        # Add docs
        docs_dir = os.path.join(project_root, 'docs')
        add_directory_to_zip(zf, docs_dir, 'docs')

        # Add configuration
        agent_config = {
            "mode": "managed",
            "agent_id": f"agent-{server_id}",
            "api_key": config.get("api_key", ""),
            "server_url": config.get("server_url", "https://your-server:5000"),
            "poll_interval": config.get("poll_interval", 60),
            "auto_sync": config.get("auto_sync", True),
            "platform": "windows",
            "agent_type": "jre-consolidated"
        }
        config_json = json.dumps(agent_config, indent=2)
        zf.writestr('agent/config.json', config_json)

        # Generate and add license token for standalone agents
        mode = config.get('mode', 'managed')
        if mode == 'standalone':
            license_token = _generate_standalone_license_token(server_id)
            if license_token:
                token_json = json.dumps(license_token, indent=2)
                zf.writestr('.license_token', token_json)
                logger.info(f"Added license token to standalone agent package for {server_id}")

        # Add installation script
        install_script = '''@echo off
REM Unified JRE Consolidated Agent - Windows Setup
setlocal enabledelayedexpansion
cd /d "%~dp0"

REM Check for Java
set "JAVA_CMD="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\\bin\\java.exe" set "JAVA_CMD=%JAVA_HOME%\\bin\\java.exe"
)
if not defined JAVA_CMD (
    for /f "delims=" %%I in ('where java 2^>nul') do (
        if not defined JAVA_CMD set "JAVA_CMD=%%I"
    )
)
if not defined JAVA_CMD (
    echo Error: Java required but not found via JAVA_HOME or PATH
    exit /b 1
)
"!JAVA_CMD!" -version >nul 2>&1
if errorlevel 1 (
    echo Error: Java found but not runnable: !JAVA_CMD!
    exit /b 1
)
echo Using Java: !JAVA_CMD!

REM Create directories
if not exist "C:\\Program Files\\AuditAgent" mkdir "C:\\Program Files\\AuditAgent"
cd "C:\\Program Files\\AuditAgent"

echo Installation complete
echo Run: java -jar agent\\lib\\unified-jre-agent-shared-0.1.0.jar --mode=managed
'''
        zf.writestr('install.bat', install_script)

    return package_path


def _deploy_fleet_agent_windows(server: dict, config: dict):
    """Deploy JRE fleet agent to Windows server via WinRM"""
    try:
        from managers.winrm_manager import WinRMManager

        # Generate JRE package
        package_path = _generate_jre_windows_package(server.get('id', 'unknown'), config)

        winrm_mgr = WinRMManager()
        hostname = server.get("hostname") or server.get("ip_address")
        username = server.get("username", "Administrator")
        password = server.get("password", "")

        # Connect
        winrm_mgr.connect(hostname, username, password)

        # Create installation directory
        install_dir = r"C:\Program Files\AuditAgent"
        winrm_mgr.run_command(f'New-Item -ItemType Directory -Force -Path "{install_dir}"')

        # Upload and extract package via PowerShell
        with open(package_path, 'rb') as f:
            package_data = f.read()

        package_b64 = base64.b64encode(package_data).decode('ascii')

        # Upload via PowerShell
        upload_cmd = f'''$bytes = [Convert]::FromBase64String("{package_b64}")
Set-Content -Path "{install_dir}\\agent.zip" -Value $bytes -AsByteStream -Force
'''
        winrm_mgr.run_command(upload_cmd)

        # Extract package
        extract_cmd = f'''Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory("{install_dir}\\agent.zip", "{install_dir}", $true)
Remove-Item "{install_dir}\\agent.zip" -Force
'''
        winrm_mgr.run_command(extract_cmd)

        # Make scripts executable and setup service
        setup_cmd = f'''$env:JAVA_HOME = (Get-Command java.exe).Source | Split-Path | Split-Path
cd "{install_dir}"
dir agent\\lib\\*.jar
Write-Host "JRE Agent installed successfully"
'''
        winrm_mgr.run_command(setup_cmd)

        winrm_mgr.disconnect()

        # Cleanup temp package
        try:
            os.unlink(package_path)
        except Exception as cleanup_error:
            logger.debug(f"Temporary package cleanup skipped ({package_path}): {cleanup_error}")

    except ImportError:
        logger.warning("WinRM manager not available, skipping Windows deployment")
        raise


def _generate_jre_linux_package(server_id: str, config: dict) -> str:
    """Generate JRE consolidated agent TAR.GZ package for Linux deployment"""

    jre_agent_dir = os.path.join(ROOT_DIR, 'agents', 'jre', 'shared')
    project_root = ROOT_DIR

    # Generate temp package
    with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp:
        package_path = tmp.name

    with tarfile.open(package_path, 'w:gz') as tar:
        # Add JRE agent JAR files
        target_dir = os.path.join(jre_agent_dir, 'target')
        if os.path.exists(target_dir):
            for jar_file in os.listdir(target_dir):
                if jar_file.endswith('.jar'):
                    tar.add(
                        os.path.join(target_dir, jar_file),
                        arcname=os.path.join('agent', 'lib', jar_file)
                    )

        # Add ALL audit scripts (150+)
        audits_dir = os.path.join(project_root, 'audits')
        add_directory_to_tar(tar, audits_dir, 'audits')

        # Add libraries
        lib_dir = os.path.join(project_root, 'lib')
        add_directory_to_tar(tar, lib_dir, 'lib')

        # Add orchestrator
        orchestrator_dir = os.path.join(project_root, 'orchestrator')
        add_directory_to_tar(tar, orchestrator_dir, 'orchestrator')

        # Add tools
        tools_dir = os.path.join(project_root, 'tools')
        add_directory_to_tar(tar, tools_dir, 'tools')

        # Add docs
        docs_dir = os.path.join(project_root, 'docs')
        add_directory_to_tar(tar, docs_dir, 'docs')

        # Add configuration
        agent_config = {
            "mode": "managed",
            "agent_id": f"agent-{server_id}",
            "api_key": config.get("api_key", ""),
            "server_url": config.get("server_url", "https://your-server:5000"),
            "poll_interval": config.get("poll_interval", 60),
            "auto_sync": config.get("auto_sync", True),
            "platform": "linux",
            "agent_type": "jre-consolidated"
        }
        config_json = json.dumps(agent_config, indent=2)
        config_bytes = config_json.encode('utf-8')
        config_info = tarfile.TarInfo(name='agent/config.json')
        config_info.size = len(config_bytes)
        tar.addfile(config_info, io.BytesIO(config_bytes))

        # Generate and add license token for standalone agents
        mode = config.get('mode', 'managed')
        if mode == 'standalone':
            license_token = _generate_standalone_license_token(server_id)
            if license_token:
                token_json = json.dumps(license_token, indent=2)
                token_bytes = token_json.encode('utf-8')
                token_info = tarfile.TarInfo(name='.license_token')
                token_info.size = len(token_bytes)
                token_info.mode = 0o600  # Restrict permissions
                tar.addfile(token_info, io.BytesIO(token_bytes))
                logger.info(f"Added license token to standalone agent package for {server_id}")

        # Add installation script
        install_script = '''#!/bin/bash
# Unified JRE Consolidated Agent - Linux Setup
set -e
cd "$(dirname "$0")"

# Check for Java
JAVA_CMD=""
if [ -n "${JAVA_HOME:-}" ] && [ -x "${JAVA_HOME}/bin/java" ]; then
    JAVA_CMD="${JAVA_HOME}/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_CMD="$(command -v java)"
fi

if [ -z "$JAVA_CMD" ]; then
    echo "Error: Java required but not found via JAVA_HOME or PATH"
    echo "Install Java 17+ and set JAVA_HOME or PATH"
    exit 1
fi

if ! "$JAVA_CMD" -version >/dev/null 2>&1; then
    echo "Error: Java was found but is not runnable: $JAVA_CMD"
    exit 1
fi

echo "Using Java: $JAVA_CMD"

# Create directories
mkdir -p /opt/audit-agent
cp -r . /opt/audit-agent/
cd /opt/audit-agent
chmod +x agent/lib/*.jar

# Create systemd service
sudo tee /etc/systemd/system/audit-agent.service > /dev/null << EOF
[Unit]
Description=Unified JRE Consolidated Fleet Agent
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/audit-agent
ExecStart=/usr/bin/java -jar agent/lib/unified-jre-agent-shared-0.1.0.jar --mode=managed
Restart=always
RestartSec=10
User=root

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable audit-agent
sudo systemctl start audit-agent

echo "Installation complete"
sudo systemctl status audit-agent
'''
        install_bytes = install_script.encode('utf-8')
        install_info = tarfile.TarInfo(name='install.sh')
        install_info.size = len(install_bytes)
        install_info.mode = 0o755
        tar.addfile(install_info, io.BytesIO(install_bytes))

    return package_path


def _deploy_fleet_agent_linux(server: dict, config: dict):
    """Deploy JRE fleet agent to Linux server via SSH"""
    try:
        import base64

        # Generate JRE package
        package_path = _generate_jre_linux_package(server.get('id', 'unknown'), config)

        # Create directories
        ssh_manager.execute_command(server, "mkdir -p /opt/audit-agent", timeout=30)

        # Upload package via SCP (randomized filename to avoid predictable temp path)
        remote_tar_path = f"/opt/audit-agent/.audit-agent-{uuid.uuid4().hex}.tar.gz"
        ssh_manager.copy_file(server, package_path, remote_tar_path, timeout=120)

        # Extract package
        extract_cmd = f"cd /opt/audit-agent && tar -xzf {remote_tar_path} && rm {remote_tar_path}"
        ssh_manager.execute_command(server, extract_cmd, timeout=60)

        # Make scripts executable
        ssh_manager.execute_command(
            server,
            "chmod -R +x /opt/audit-agent/agent/lib/*.jar /opt/audit-agent/install.sh /opt/audit-agent/agent/lib/* 2>/dev/null || true",
            timeout=30
        )

        # Create systemd service
        service_content = '''[Unit]
Description=Unified JRE Consolidated Fleet Agent
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/audit-agent
ExecStart=/usr/bin/java -jar agent/lib/unified-jre-agent-shared-0.1.0.jar --mode=managed
Restart=always
RestartSec=10
User=root

[Install]
WantedBy=multi-user.target
'''
        service_b64 = base64.b64encode(service_content.encode('utf-8')).decode('ascii')
        ssh_manager.execute_command(
            server,
            f"echo '{service_b64}' | base64 -d | sudo tee /etc/systemd/system/audit-agent.service",
            timeout=30
        )

        # Enable and start service
        ssh_manager.execute_command(
            server,
            "sudo systemctl daemon-reload && sudo systemctl enable audit-agent && sudo systemctl start audit-agent",
            timeout=60
        )

        # Cleanup temp package
        try:
            os.unlink(package_path)
        except Exception as cleanup_error:
            logger.debug(f"Temporary package cleanup skipped ({package_path}): {cleanup_error}")

    except Exception as e:
        logger.error(f"SSH deployment error: {e}")
        raise


# ============================================================================
# JRE Agent Deployment Helpers (reuse fleet agent logic)
# ============================================================================
def _deploy_jre_agent_windows(server: dict, config: dict):
    """Deploy JRE consolidated agent to Windows server via WinRM"""
    # JRE agent uses same package and deployment logic as fleet agent
    config['mode'] = config.get('mode', 'managed')
    return _deploy_fleet_agent_windows(server, config)


def _deploy_jre_agent_linux(server: dict, config: dict):
    """Deploy JRE consolidated agent to Linux server via SSH"""
    # JRE agent uses same package and deployment logic as fleet agent
    config['mode'] = config.get('mode', 'managed')
    return _deploy_fleet_agent_linux(server, config)


def _deploy_jre_agent_api(server: dict, config: dict):
    """Deploy JRE agent via API-only mode (manual installation)"""
    # For API mode, create configuration and return instructions
    logger.info(f"JRE agent API-only deployment for {server.get('name')}: agent must be installed manually")
    # In practice, this would save config to the server record and return download links


def _build_linux_agent_package(package_path: str, config: dict):
    """Build Linux agent tar.gz package"""
    with tarfile.open(package_path, "w:gz") as tar:
        # Add agent script
        agent_path = STANDALONE_AGENT_DIR / "agent.sh"
        if agent_path.exists():
            tar.add(agent_path, arcname="audit-agent/agent.sh")

        # Add startup scripts
        for script in ["start-web.sh", "run-silent.sh", "setup-cli.py"]:
            script_path = STANDALONE_AGENT_DIR / script
            if script_path.exists():
                tar.add(script_path, arcname=f"audit-agent/{script}")

        # Add service files for daemon mode
        service_files = ["audit-agent.service", "audit-agent.openrc"]
        for svc_file in service_files:
            svc_path = STANDALONE_AGENT_DIR / svc_file
            if svc_path.exists():
                tar.add(svc_path, arcname=f"audit-agent/{svc_file}")

        # Add tools
        tools_dir = STANDALONE_AGENT_DIR / "tools"
        if tools_dir.exists():
            add_directory_to_tar(tar, tools_dir, "audit-agent/tools")

        # Add basic audits
        audits_dir = STANDALONE_AGENT_DIR / "audits"
        if audits_dir.exists():
            add_directory_to_tar(tar, audits_dir, "audit-agent/audits")

        # Add web UI components if requested (for managed deployments)
        if config.get("include_web_ui", True):
            web_dir = STANDALONE_AGENT_DIR / "web"
            if web_dir.exists():
                add_directory_to_tar(tar, web_dir, "audit-agent/web")

            # Add requirements for pip install
            req_file = STANDALONE_AGENT_DIR / "requirements.txt"
            if req_file.exists():
                tar.add(req_file, arcname="audit-agent/requirements.txt")

            # Add Dockerfile for container deployment option
            dockerfile = STANDALONE_AGENT_DIR / "Dockerfile"
            if dockerfile.exists():
                tar.add(dockerfile, arcname="audit-agent/Dockerfile")

            # Add docker-compose for easy startup
            compose_file = STANDALONE_AGENT_DIR / "docker-compose.yml"
            if compose_file.exists():
                tar.add(compose_file, arcname="audit-agent/docker-compose.yml")

        # Add full audit suite if requested
        if config.get("include_full_audits"):
            linux_audits = ROOT_DIR / "audits" / "linux"
            if linux_audits.exists():
                add_directory_to_tar(tar, linux_audits, "audit-agent/audits/linux")
            lib_dir = ROOT_DIR / "lib"
            if lib_dir.exists():
                add_directory_to_tar(tar, lib_dir, "audit-agent/audits/_lib")

        # Create config file
        config_content = json.dumps({
            "server_url": config.get("server_url", ""),
            "api_key": config.get("api_key", ""),
            "upload_results": config.get("upload_results", True),
            "keep_local_results": config.get("keep_local_results", True),
            # License delegation settings
            "enable_license_delegation": config.get("enable_license_delegation", True),
            "license_refresh_hours": config.get("license_refresh_hours", 1),
            "core_server_url": config.get("server_url", ""),  # For license API
        }, indent=2)

        # Add config to archive
        config_bytes = config_content.encode('utf-8')
        config_info = tarfile.TarInfo(name="audit-agent/agent.config.json")
        config_info.size = len(config_bytes)
        tar.addfile(config_info, io.BytesIO(config_bytes))


def _build_windows_agent_package(package_path: str, config: dict):
    """Build Windows agent zip package"""
    with zipfile.ZipFile(package_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Add agent script
        agent_path = STANDALONE_AGENT_DIR / "agent.ps1"
        if agent_path.exists():
            zf.write(agent_path, "audit-agent/agent.ps1")

        # Add startup and utility scripts
        ps_scripts = [
            "start-web.ps1",
            "Register-ScheduledTask.ps1",
            "setup-cli.py"
        ]
        for script in ps_scripts:
            script_path = STANDALONE_AGENT_DIR / script
            if script_path.exists():
                zf.write(script_path, f"audit-agent/{script}")

        # Add bash scripts for cross-platform support (WSL/Git Bash)
        bash_scripts = ["start-web.sh", "run-silent.sh", "agent.sh"]
        for script in bash_scripts:
            script_path = STANDALONE_AGENT_DIR / script
            if script_path.exists():
                zf.write(script_path, f"audit-agent/{script}")

        # Add tools
        tools_dir = STANDALONE_AGENT_DIR / "tools"
        if tools_dir.exists():
            add_directory_to_zip(zf, tools_dir, "audit-agent/tools")

        # Add basic audits (PowerShell only)
        audits_dir = STANDALONE_AGENT_DIR / "audits"
        if audits_dir.exists():
            for root, dirs, files in os.walk(audits_dir):
                for file in files:
                    if file.endswith('.ps1'):
                        file_path = os.path.join(root, file)
                        if not is_archiveable_file(file_path):
                            continue
                        arc_name = os.path.join("audit-agent/audits",
                                               os.path.relpath(file_path, audits_dir))
                        zf.write(file_path, arc_name)

        # Add web UI components if requested (for managed deployments)
        if config.get("include_web_ui", True):
            web_dir = STANDALONE_AGENT_DIR / "web"
            if web_dir.exists():
                add_directory_to_zip(zf, web_dir, "audit-agent/web")

            # Add requirements for pip install
            req_file = STANDALONE_AGENT_DIR / "requirements.txt"
            if req_file.exists():
                zf.write(req_file, "audit-agent/requirements.txt")

            # Add Dockerfile for container deployment option
            dockerfile = STANDALONE_AGENT_DIR / "Dockerfile"
            if dockerfile.exists():
                zf.write(dockerfile, "audit-agent/Dockerfile")

            # Add docker-compose for easy startup
            compose_file = STANDALONE_AGENT_DIR / "docker-compose.yml"
            if compose_file.exists():
                zf.write(compose_file, "audit-agent/docker-compose.yml")

        # Add full audit suite if requested
        if config.get("include_full_audits"):
            win_audits = ROOT_DIR / "audits" / "windows"
            if win_audits.exists():
                for root, dirs, files in os.walk(win_audits):
                    for file in files:
                        if file.endswith('.ps1') or file.endswith('.psm1'):
                            file_path = os.path.join(root, file)
                            if not is_archiveable_file(file_path):
                                continue
                            arc_name = os.path.join("audit-agent/audits/windows",
                                                   os.path.relpath(file_path, win_audits))
                            zf.write(file_path, arc_name)

        # Create config file
        config_content = json.dumps({
            "server_url": config.get("server_url", ""),
            "api_key": config.get("api_key", ""),
            "upload_results": config.get("upload_results", True),
            "keep_local_results": config.get("keep_local_results", True),
            # License delegation settings
            "enable_license_delegation": config.get("enable_license_delegation", True),
            "license_refresh_hours": config.get("license_refresh_hours", 1),
            "core_server_url": config.get("server_url", ""),  # For license API
        }, indent=2)
        zf.writestr("audit-agent/agent.config.json", config_content)


def _deploy_linux_agent(server: dict, package_path: str, config: dict):
    """Deploy agent to Linux server via SSH"""
    remote_path = "/opt/audit-agent"

    # Ensure host key is known
    if not ssh_host_key_manager.host_known(server['host'], server.get('port', 22)):
        ssh_host_key_manager.add_host_key(server['host'], server.get('port', 22))

    # Create directory
    ssh_manager.execute_command(server, f"sudo mkdir -p {remote_path}", timeout=30)

    # Copy package - use unique temp file to prevent symlink attacks (B108)
    # nosec B108: UUID suffix makes path unpredictable, mitigating symlink race
    remote_tar = f"/tmp/audit-agent-{uuid.uuid4().hex[:12]}.tar.gz"  # nosec B108
    result = ssh_manager.copy_file(server, package_path, remote_tar, timeout=120)
    if result.returncode != 0:
        raise Exception(f"Failed to transfer: {result.stderr}")

    # Extract and setup
    commands = [
        f"sudo tar -xzf {remote_tar} -C /opt/",
        f"sudo chmod +x {remote_path}/agent.sh",
        f"sudo chmod +x {remote_path}/audits/**/*.sh 2>/dev/null || true",
        f"rm {remote_tar}"
    ]

    for cmd in commands:
        result = ssh_manager.execute_command(server, cmd, timeout=60)

    # Setup scheduled task if requested
    if config.get("setup_scheduled_task"):
        schedule_time = config.get("schedule_time", "02:00")
        hour, minute = schedule_time.split(":")
        cron_line = f"{minute} {hour} * * * root {remote_path}/agent.sh --mode runall --quiet"
        cron_cmd = f'echo "{cron_line}" | sudo tee /etc/cron.d/audit-agent'
        ssh_manager.execute_command(server, cron_cmd, timeout=30)


def _deploy_windows_agent(server: dict, package_path: str, config: dict):
    """Deploy agent to Windows server via WinRM"""
    from winrm_manager import WinRMManager

    remote_path = "C:\\ProgramData\\AuditAgent"

    # Initialize WinRM manager
    winrm_mgr = WinRMManager(password_manager=password_manager)

    # Create directory
    winrm_mgr.execute_command(
        server,
        f"New-Item -ItemType Directory -Path '{remote_path}' -Force | Out-Null",
        timeout=30
    )

    # Copy package (base64 encode for WinRM transfer)
    import base64
    with open(package_path, 'rb') as f:
        package_data = base64.b64encode(f.read()).decode('ascii')

    # Transfer in chunks (WinRM has size limits)
    chunk_size = 100000  # ~100KB chunks
    remote_zip = f"{remote_path}\\agent.zip"

    # Clear any existing file
    winrm_mgr.execute_command(
        server,
        f"Remove-Item -Path '{remote_zip}' -Force -ErrorAction SilentlyContinue",
        timeout=30
    )

    for i in range(0, len(package_data), chunk_size):
        chunk = package_data[i:i+chunk_size]
        ps_cmd = f"""
$bytes = [Convert]::FromBase64String('{chunk}')
Add-Content -Path '{remote_zip}' -Value $bytes -Encoding Byte
"""
        winrm_mgr.execute_command(server, ps_cmd, timeout=60)

    # Extract package
    extract_cmd = f"""
Expand-Archive -Path '{remote_zip}' -DestinationPath '{remote_path}' -Force
Remove-Item -Path '{remote_zip}' -Force
"""
    winrm_mgr.execute_command(server, extract_cmd, timeout=120)

    # Setup scheduled task if requested
    if config.get("setup_scheduled_task"):
        schedule_time = config.get("schedule_time", "02:00")
        task_cmd = f"""
$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument '-ExecutionPolicy Bypass -File {remote_path}\\audit-agent\\agent.ps1 -Mode runall'
$trigger = New-ScheduledTaskTrigger -Daily -At '{schedule_time}'
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName 'Security Audit Agent' `
    -Action $action -Trigger $trigger -Principal $principal -Force
"""
        winrm_mgr.execute_command(server, task_cmd, timeout=60)


def _disable_remote_access(server: dict):
    """Disable remote access after deployment (optional security hardening)"""
    os_type = server.get("os_type", "linux")

    if os_type == "windows":
        from winrm_manager import WinRMManager
        winrm_mgr = WinRMManager(password_manager=password_manager)

        # Disable WinRM
        winrm_mgr.execute_command(
            server,
            "Stop-Service WinRM; Set-Service WinRM -StartupType Disabled",
            timeout=30
        )
    else:
        # For Linux, we could disable SSH but that's more drastic
        # Just log a warning instead
        logger.warning(f"SSH disable requested for {server['name']} - skipping (manual action required)")


@deploy_bp.route('/api/deploy/agent/download/<platform>')
def download_agent_package(platform: str):
    """
    Download agent package for manual deployment

    Args:
        platform: 'linux' or 'windows'
    """
    if platform not in ('linux', 'windows'):
        return jsonify({"success": False, "error": "Invalid platform"}), 400

    try:
        config = {
            "server_url": request.args.get("server_url", ""),
            "api_key": request.args.get("api_key", ""),
            "upload_results": True,
            "keep_local_results": True,
            "include_full_audits": request.args.get("full", "false").lower() == "true"
        }

        if platform == "linux":
            with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
                package_path = tmp.name
            _build_linux_agent_package(package_path, config)
            return send_file(
                package_path,
                as_attachment=True,
                download_name="audit-agent-linux.tar.gz",
                mimetype="application/gzip"
            )
        else:
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                package_path = tmp.name
            _build_windows_agent_package(package_path, config)
            return send_file(
                package_path,
                as_attachment=True,
                download_name="audit-agent-windows.zip",
                mimetype="application/zip"
            )
    except Exception as e:
        logger.error(f"Agent download error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@deploy_bp.route('/api/deploy/package/<deploy_type>', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def download_deploy_package(deploy_type: str):
    """Download full or JRE agent toolkit package for manual installation.

    PROTECTED: Requires API key authentication and valid license.
    Downloads include embedded license token for script protection.

    Note: 'lightweight' deploy_type is deprecated. Use 'jre' instead.
    For backward compatibility, 'lightweight' is automatically redirected to 'jre'.

    New: deploy_type='ova', 'ovf', or 'vmdk' allows secure download of virtual appliance artifacts.
    Artifacts are served from deployment/vm-appliance/output and require license token embedding.

    For deploy_type='full', this endpoint now prefers built release artifacts:
    - Windows: `deployment/windows/bin/SecurityAuditToolkit-<version>-x64.msi`
    - Linux: `deployment/linux/bin/audit-toolkit_<version>_all.deb` (default)
             or RPM via query `package_format=rpm`

    If release artifacts are unavailable, it falls back to on-the-fly package assembly.
    """
    deploy_type = (deploy_type or '').strip().lower()

    # Backward compatibility: redirect 'lightweight' to 'jre'
    if deploy_type == 'lightweight':
        logger.warning("Deprecated deploy_type 'lightweight' requested. Redirecting to 'jre'.")
        deploy_type = 'jre'


    # VM appliance artifact support (download-only)
    if deploy_type in ('ova', 'ovf', 'vmdk'):
        found, vm_source_info = _resolve_vm_appliance_artifact(deploy_type, allow_reassemble=True)
        if not found:
            return jsonify({"success": False, "error": f"No {deploy_type.upper()} appliance found. Please build and place in deployment/vm-appliance/output."}), 404

        if vm_source_info.get('reassembled'):
            logger.info(
                "Auto-reassembled split VM artifact for %s download: %s (%s parts)",
                deploy_type,
                found.name,
                vm_source_info.get('split_parts', 0)
            )

        # Embed license token as a sidecar file (not inside OVA/OVF, but delivered alongside)
        try:
            import hashlib as _hashlib
            placeholder_fingerprint = _hashlib.sha256(
                f"package-download-{deploy_type}-appliance-{datetime.now().isoformat()}".encode()
            ).hexdigest()
            license_token = _generate_standalone_license_token(f"package-{deploy_type}-appliance")
            if license_token:
                license_token['_package_type'] = deploy_type
                token_json = json.dumps(license_token, indent=2)
                # Serve as multipart/zip with OVA/OVF and .license_token
                with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
                    with zipfile.ZipFile(tmp.name, 'w', zipfile.ZIP_DEFLATED) as zf:
                        zf.write(found, arcname=found.name)
                        zf.writestr('.license_token', token_json)
                filename = f"{found.stem}-with-license.zip"
                return send_file(
                    tmp.name,
                    as_attachment=True,
                    download_name=filename,
                    mimetype='application/zip'
                )
            else:
                return send_file(
                    found,
                    as_attachment=True,
                    download_name=found.name,
                    mimetype='application/octet-stream'
                )
        except Exception as e:
            logger.error(f"VM appliance download error: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    if deploy_type not in ('full', 'jre', 'ova', 'ovf', 'vmdk'):
        return jsonify({"success": False, "error": "deploy_type must be 'full', 'jre', 'ova', 'ovf', or 'vmdk' (legacy: 'lightweight')"}), 400

    platform = request.args.get('platform', 'linux').strip().lower()
    if platform not in ('linux', 'windows'):
        return jsonify({"success": False, "error": "platform must be 'linux' or 'windows'"}), 400

    toolkit_version = _get_toolkit_version()
    package_format = request.args.get('package_format', 'auto').strip().lower()

    root_path = Path(ROOT_DIR)

    # Prefer real release binaries for full toolkit downloads.
    if deploy_type == 'full':
        try:
            if platform == 'windows':
                msi_path = root_path / 'deployment' / 'windows' / 'bin' / f'SecurityAuditToolkit-{toolkit_version}-x64.msi'
                if msi_path.exists():
                    return send_file(
                        str(msi_path),
                        as_attachment=True,
                        download_name=msi_path.name,
                        mimetype='application/x-msi'
                    )
            else:
                linux_bin = root_path / 'deployment' / 'linux' / 'bin'
                deb_path = linux_bin / f'audit-toolkit_{toolkit_version}_all.deb'
                rpm_path = linux_bin / f'audit-toolkit-{toolkit_version.replace("-beta", "")}-0.beta.1.noarch.rpm'
                rpm_fc_path = linux_bin / f'audit-toolkit-{toolkit_version.replace("-beta", "")}-0.beta.1.fc41.noarch.rpm'

                # Linux selection priority:
                # - package_format=deb: DEB only
                # - package_format=rpm: generic noarch RPM, then fc RPM
                # - auto/default: DEB first, then RPM fallback
                if package_format == 'deb':
                    if deb_path.exists():
                        return send_file(
                            str(deb_path),
                            as_attachment=True,
                            download_name=deb_path.name,
                            mimetype='application/vnd.debian.binary-package'
                        )
                elif package_format == 'rpm':
                    if rpm_path.exists():
                        return send_file(
                            str(rpm_path),
                            as_attachment=True,
                            download_name=rpm_path.name,
                            mimetype='application/x-rpm'
                        )
                    if rpm_fc_path.exists():
                        return send_file(
                            str(rpm_fc_path),
                            as_attachment=True,
                            download_name=rpm_fc_path.name,
                            mimetype='application/x-rpm'
                        )
                else:
                    if deb_path.exists():
                        return send_file(
                            str(deb_path),
                            as_attachment=True,
                            download_name=deb_path.name,
                            mimetype='application/vnd.debian.binary-package'
                        )
                    if rpm_path.exists():
                        return send_file(
                            str(rpm_path),
                            as_attachment=True,
                            download_name=rpm_path.name,
                            mimetype='application/x-rpm'
                        )
                    if rpm_fc_path.exists():
                        return send_file(
                            str(rpm_fc_path),
                            as_attachment=True,
                            download_name=rpm_fc_path.name,
                            mimetype='application/x-rpm'
                        )
        except Exception as release_send_error:
            logger.warning(f"Release artifact send failed, falling back to generated package: {release_send_error}")

    # Prefer rebuilt unified JRE release artifacts for jre downloads.
    if deploy_type == 'jre':
        try:
            # Primary rebuilt artifact produced by build_unified_jre_agent.sh
            jre_linux_path = root_path / f'unified-jre-agent-{toolkit_version}.tar.gz'

            # Optional platform-specific release artifact (if produced in future)
            jre_windows_path = root_path / f'unified-jre-agent-{toolkit_version}-windows.zip'

            if platform == 'linux' and jre_linux_path.exists():
                return send_file(
                    str(jre_linux_path),
                    as_attachment=True,
                    download_name=jre_linux_path.name,
                    mimetype='application/gzip'
                )

            if platform == 'windows' and jre_windows_path.exists():
                return send_file(
                    str(jre_windows_path),
                    as_attachment=True,
                    download_name=jre_windows_path.name,
                    mimetype='application/zip'
                )
        except Exception as jre_release_send_error:
            logger.warning(f"JRE release artifact send failed, falling back to generated package: {jre_release_send_error}")

    def add_file_if_exists(archive, file_path, arcname):
        if not is_archiveable_file(file_path):
            return
        if platform == 'windows':
            archive.write(file_path, arcname=str(arcname).replace('/', '\\\\'))
        else:
            archive.add(file_path, arcname=str(arcname))

    def add_dir_if_exists(archive, dir_path, arcname):
        if not dir_path.exists():
            return
        if platform == 'windows':
            add_directory_to_zip(archive, dir_path, arcname, windows_paths=True)
        else:
            add_directory_to_tar(archive, dir_path, arcname)

    try:
        if platform == 'windows':
            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
                package_path = tmp.name
            with zipfile.ZipFile(package_path, 'w', zipfile.ZIP_DEFLATED) as pkg:
                if deploy_type == 'jre':
                    # Package JRE agent (standalone mode)
                    jre_agent_dir = ROOT_DIR / 'agents' / 'jre' / 'shared'
                    add_dir_if_exists(pkg, jre_agent_dir, 'agents/jre/shared')
                    add_dir_if_exists(pkg, ROOT_DIR / 'lib', 'lib')
                    add_dir_if_exists(pkg, ROOT_DIR / 'audits', 'audits')
                    add_dir_if_exists(pkg, ROOT_DIR / 'tools', 'tools')
                else:
                    for dir_name in ['audits', 'lib', 'orchestrator', 'ci', 'docs', 'tools']:
                        add_dir_if_exists(pkg, ROOT_DIR / dir_name, dir_name)

                add_file_if_exists(pkg, ROOT_DIR / 'README.md', 'README.md')
                add_file_if_exists(pkg, ROOT_DIR / 'LICENSE', 'LICENSE')
                if deploy_type == 'full':
                    add_file_if_exists(pkg, ROOT_DIR / 'Makefile', 'Makefile')
                    add_file_if_exists(pkg, ROOT_DIR / '.shellcheckrc', '.shellcheckrc')
                    add_file_if_exists(pkg, ROOT_DIR / 'install.sh', 'install.sh')
                    add_file_if_exists(pkg, ROOT_DIR / 'setup.sh', 'setup.sh')
                    add_file_if_exists(pkg, ROOT_DIR / 'uninstall.sh', 'uninstall.sh')

                # Add license token for script protection
                try:
                    import hashlib as _hashlib
                    placeholder_fingerprint = _hashlib.sha256(
                        f"package-download-{deploy_type}-windows-{datetime.now().isoformat()}".encode()
                    ).hexdigest()
                    license_token = _generate_standalone_license_token(f"package-{deploy_type}")
                    if license_token:
                        license_token['_package_type'] = deploy_type
                        token_json = json.dumps(license_token, indent=2)
                        pkg.writestr('.license_token', token_json)
                        logger.info(f"Embedded license token in {deploy_type} Windows package")
                except Exception as token_err:
                    logger.warning(f"Failed to embed license token in Windows package: {token_err}")

            filename = f"audit-toolkit-{deploy_type}-{toolkit_version}-windows.zip"
            mimetype = 'application/zip'
        else:
            with tempfile.NamedTemporaryFile(suffix='.tar.gz', delete=False) as tmp:
                package_path = tmp.name
            with tarfile.open(package_path, 'w:gz') as pkg:
                if deploy_type == 'jre':
                    # Package JRE agent (standalone mode)
                    jre_agent_dir = ROOT_DIR / 'agents' / 'jre' / 'shared'
                    add_dir_if_exists(pkg, jre_agent_dir, 'agents/jre/shared')
                    add_dir_if_exists(pkg, ROOT_DIR / 'lib', 'lib')
                    add_dir_if_exists(pkg, ROOT_DIR / 'audits', 'audits')
                    add_dir_if_exists(pkg, ROOT_DIR / 'tools', 'tools')
                else:
                    for dir_name in ['audits', 'lib', 'orchestrator', 'ci', 'docs', 'tools']:
                        add_dir_if_exists(pkg, ROOT_DIR / dir_name, dir_name)

                add_file_if_exists(pkg, ROOT_DIR / 'README.md', 'README.md')
                add_file_if_exists(pkg, ROOT_DIR / 'LICENSE', 'LICENSE')
                if deploy_type == 'full':
                    add_file_if_exists(pkg, ROOT_DIR / 'Makefile', 'Makefile')
                    add_file_if_exists(pkg, ROOT_DIR / '.shellcheckrc', '.shellcheckrc')
                    add_file_if_exists(pkg, ROOT_DIR / 'install.sh', 'install.sh')
                    add_file_if_exists(pkg, ROOT_DIR / 'setup.sh', 'setup.sh')
                    add_file_if_exists(pkg, ROOT_DIR / 'uninstall.sh', 'uninstall.sh')

                # Add license token for script protection
                try:
                    import hashlib as _hashlib
                    placeholder_fingerprint = _hashlib.sha256(
                        f"package-download-{deploy_type}-linux-{datetime.now().isoformat()}".encode()
                    ).hexdigest()
                    license_token = _generate_standalone_license_token(f"package-{deploy_type}")
                    if license_token:
                        license_token['_package_type'] = deploy_type
                        token_json = json.dumps(license_token, indent=2)
                        token_info = tarfile.TarInfo(name='.license_token')
                        token_info.size = len(token_json.encode('utf-8'))
                        pkg.addfile(token_info, io.BytesIO(token_json.encode('utf-8')))
                        logger.info(f"Embedded license token in {deploy_type} Linux package")
                except Exception as token_err:
                    logger.warning(f"Failed to embed license token in Linux package: {token_err}")

            filename = f"audit-toolkit-{deploy_type}-{toolkit_version}-linux.tar.gz"
            mimetype = 'application/gzip'

        return send_file(
            package_path,
            as_attachment=True,
            download_name=filename,
            mimetype=mimetype
        )
    except Exception as e:
        logger.error(f"Toolkit package download error ({deploy_type}/{platform}): {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@deploy_bp.route('/api/deploy/package-status', methods=['GET'])
@require_auth_and_permission('deploy_scripts')
def get_deploy_package_status():
    """Return package artifact availability for GUI download controls."""
    try:
        ova_path, ova_info = _resolve_vm_appliance_artifact('ova', allow_reassemble=False)
        ovf_path, ovf_info = _resolve_vm_appliance_artifact('ovf', allow_reassemble=False)
        vmdk_path, vmdk_info = _resolve_vm_appliance_artifact('vmdk', allow_reassemble=False)
        ova_url = _get_vm_appliance_external_url('ova')
        ovf_url = _get_vm_appliance_external_url('ovf')
        vmdk_url = _get_vm_appliance_external_url('vmdk')

        ova_available = bool(ova_path) or ova_info.get('source') == 'split' or bool(ova_url)
        ovf_available = bool(ovf_path) or ovf_info.get('source') == 'split' or bool(ovf_url)
        vmdk_available = bool(vmdk_path) or vmdk_info.get('source') == 'split' or bool(vmdk_url)

        ova_source = 'local' if ova_path else ('split' if ova_info.get('source') == 'split' else ('external' if ova_url else 'none'))
        ovf_source = 'local' if ovf_path else ('split' if ovf_info.get('source') == 'split' else ('external' if ovf_url else 'none'))
        vmdk_source = 'local' if vmdk_path else ('split' if vmdk_info.get('source') == 'split' else ('external' if vmdk_url else 'none'))

        result = {
            "success": True,
            "vm_appliance": {
                "ova": {
                    "available": ova_available,
                    "filename": ova_path.name if ova_path else None,
                    "size_bytes": ova_path.stat().st_size if ova_path else None,
                    "external_url": ova_url,
                    "source": ova_source,
                    "split_parts": ova_info.get('split_parts', 0),
                    "split_manifest": ova_info.get('split_manifest', False),
                },
                "ovf": {
                    "available": ovf_available,
                    "filename": ovf_path.name if ovf_path else None,
                    "size_bytes": ovf_path.stat().st_size if ovf_path else None,
                    "external_url": ovf_url,
                    "source": ovf_source,
                    "split_parts": ovf_info.get('split_parts', 0),
                    "split_manifest": ovf_info.get('split_manifest', False),
                },
                "vmdk": {
                    "available": vmdk_available,
                    "filename": vmdk_path.name if vmdk_path else None,
                    "size_bytes": vmdk_path.stat().st_size if vmdk_path else None,
                    "external_url": vmdk_url,
                    "source": vmdk_source,
                    "split_parts": vmdk_info.get('split_parts', 0),
                    "split_manifest": vmdk_info.get('split_manifest', False),
                }
            },
            "notes": [
                "OVA/OVF/VMDK appliance artifacts are download-only and are not eligible for remote push deployment.",
                "Artifacts are resolved from deployment/vm-appliance/output.",
                "When only split parts are present (*.partNNN), downloads auto-reassemble the artifact before serving.",
                "External URLs can be configured via VM_APPLIANCE_OVA_URL, VM_APPLIANCE_OVF_URL, and VM_APPLIANCE_VMDK_URL."
            ]
        }
        return jsonify(result)
    except Exception as e:
        logger.error(f"Package status error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
