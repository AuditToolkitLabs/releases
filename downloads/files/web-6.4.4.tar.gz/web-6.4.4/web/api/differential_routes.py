"""
Differential Audit Routes - Compare audit executions and track remediation

Provides endpoints for:
- Comparing two audit executions (/api/differential/compare)
- Getting drift timeline for a server (/api/differential/drift/<server_id>)
- Listing all comparisons (/api/differential/comparisons)
- Retrieving saved comparison (/api/differential/comparisons/<id>)
- Remediation management (/api/differential/remediation/*)

Author: Security Audit Toolkit Team
"""

import json
from datetime import datetime
from flask import Blueprint, jsonify, request
from sqlalchemy import desc, and_, or_
from sqlalchemy.orm import joinedload

# Import from config
from config import logger

# Import database session
try:
    from models.database import db
    from models.database import AuditExecution, Server, Audit
    from models.differential import (
        DifferentialComparison,
        RemediationItem,
        RemediationHistory
    )
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    db = None

# Import auth decorators
from auth_core import (
    require_auth_and_permission,
    require_auth_permission_and_log,
    get_current_user
)

# Import differential utilities
from differential import (
    compare_executions,
    get_drift_timeline,
    AuditOutputParser,
    CheckStatus
)

# Create blueprint
differential_bp = Blueprint('differential', __name__)


# ============================================================================
# Comparison Endpoints
# ============================================================================

@differential_bp.route('/api/differential/compare', methods=['POST'])
@require_auth_and_permission('view_history')
def compare_audit_executions():
    """
    Compare two audit execution results.

    Request Body:
    {
        "baseline_execution_id": 123,      # Earlier execution
        "comparison_execution_id": 456,    # Later execution
        "save": false                      # Optional: save comparison to database
    }

    Returns:
        Differential comparison result with categorized changes
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}
        baseline_id = data.get('baseline_execution_id')
        comparison_id = data.get('comparison_execution_id')
        save_result = data.get('save', False)

        if not baseline_id or not comparison_id:
            return jsonify({
                'error': 'baseline_execution_id and comparison_execution_id required'
            }), 400

        # Fetch executions
        baseline = db.session.query(AuditExecution).get(baseline_id)
        comparison = db.session.query(AuditExecution).get(comparison_id)

        if not baseline:
            return jsonify({'error': f'Baseline execution {baseline_id} not found'}), 404
        if not comparison:
            return jsonify({'error': f'Comparison execution {comparison_id} not found'}), 404

        # Validate same server and audit
        if baseline.server_id != comparison.server_id:
            return jsonify({'error': 'Executions must be for the same server'}), 400
        if baseline.audit_id != comparison.audit_id:
            return jsonify({'error': 'Executions must be for the same audit'}), 400

        # Perform comparison
        diff_result = compare_executions(
            baseline_output=baseline.output or '',
            comparison_output=comparison.output or '',
            baseline_id=baseline_id,
            comparison_id=comparison_id,
            baseline_timestamp=baseline.executed_at,
            comparison_timestamp=comparison.executed_at,
            server_id=baseline.server_id,
            audit_id=baseline.audit_id
        )

        result_dict = diff_result.to_dict()

        # Optionally save to database
        if save_result:
            user = get_current_user()
            comparison_record = DifferentialComparison(
                baseline_execution_id=baseline_id,
                comparison_execution_id=comparison_id,
                server_id=baseline.server_id,
                audit_id=baseline.audit_id,
                baseline_timestamp=baseline.executed_at,
                comparison_timestamp=comparison.executed_at,
                drift_score=diff_result.drift_score,
                health_trend=diff_result.health_trend,
                new_failures_count=len(diff_result.new_failures),
                resolved_count=len(diff_result.resolved_issues),
                escalated_count=len(diff_result.escalated),
                deescalated_count=len(diff_result.deescalated),
                new_checks_count=len(diff_result.new_checks),
                removed_checks_count=len(diff_result.removed_checks),
                changes=json.dumps(result_dict.get('changes', {})),
                created_by=user.email if hasattr(user, 'email') else str(user)
            )
            db.session.add(comparison_record)
            db.session.commit()
            result_dict['saved_comparison_id'] = comparison_record.id

        return jsonify(result_dict)

    except Exception as e:
        logger.error(f"Error comparing executions: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/compare/<int:server_id>/<int:audit_id>/latest', methods=['GET'])
@require_auth_and_permission('view_history')
def compare_latest_executions(server_id: int, audit_id: int):
    """
    Compare the two most recent executions for a server/audit pair.

    Query Parameters:
        save: bool - Whether to save comparison to database (default: false)

    Returns:
        Differential comparison between last two executions
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        save_result = request.args.get('save', 'false').lower() == 'true'

        # Get last two executions
        executions = db.session.query(AuditExecution)\
            .filter(AuditExecution.server_id == server_id)\
            .filter(AuditExecution.audit_id == audit_id)\
            .filter(AuditExecution.status == 'success')\
            .order_by(desc(AuditExecution.executed_at))\
            .limit(2)\
            .all()

        if len(executions) < 2:
            return jsonify({
                'error': 'At least two successful executions required for comparison',
                'executions_found': len(executions)
            }), 400

        # Latest is comparison, second latest is baseline
        comparison = executions[0]
        baseline = executions[1]

        # Perform comparison
        diff_result = compare_executions(
            baseline_output=baseline.output or '',
            comparison_output=comparison.output or '',
            baseline_id=baseline.id,
            comparison_id=comparison.id,
            baseline_timestamp=baseline.executed_at,
            comparison_timestamp=comparison.executed_at,
            server_id=server_id,
            audit_id=audit_id
        )

        result_dict = diff_result.to_dict()

        # Optionally save
        if save_result:
            user = get_current_user()
            comparison_record = DifferentialComparison(
                baseline_execution_id=baseline.id,
                comparison_execution_id=comparison.id,
                server_id=server_id,
                audit_id=audit_id,
                baseline_timestamp=baseline.executed_at,
                comparison_timestamp=comparison.executed_at,
                drift_score=diff_result.drift_score,
                health_trend=diff_result.health_trend,
                new_failures_count=len(diff_result.new_failures),
                resolved_count=len(diff_result.resolved_issues),
                escalated_count=len(diff_result.escalated),
                deescalated_count=len(diff_result.deescalated),
                new_checks_count=len(diff_result.new_checks),
                removed_checks_count=len(diff_result.removed_checks),
                changes=json.dumps(result_dict.get('changes', {})),
                created_by=user.email if hasattr(user, 'email') else str(user)
            )
            db.session.add(comparison_record)
            db.session.commit()
            result_dict['saved_comparison_id'] = comparison_record.id

        return jsonify(result_dict)

    except Exception as e:
        logger.error(f"Error comparing latest executions: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Drift Timeline
# ============================================================================

@differential_bp.route('/api/differential/drift/<int:server_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def get_server_drift(server_id: int):
    """
    Get drift timeline for a server showing configuration changes over time.

    Query Parameters:
        audit_id: int - Filter to specific audit (optional)
        days: int - Number of days of history (default: 30)
        limit: int - Maximum number of data points (default: 50)

    Returns:
        Timeline of drift scores and health trends
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        audit_id = request.args.get('audit_id', type=int)
        days = request.args.get('days', 30, type=int)
        limit = request.args.get('limit', 50, type=int)

        # Build query
        query = db.session.query(AuditExecution)\
            .filter(AuditExecution.server_id == server_id)\
            .filter(AuditExecution.status == 'success')

        if audit_id:
            query = query.filter(AuditExecution.audit_id == audit_id)

        # Get recent executions
        from datetime import timedelta
        cutoff = datetime.utcnow() - timedelta(days=days)
        query = query.filter(AuditExecution.executed_at >= cutoff)

        executions = query.order_by(AuditExecution.executed_at)\
            .limit(limit + 1)\
            .all()

        if len(executions) < 2:
            return jsonify({
                'server_id': server_id,
                'audit_id': audit_id,
                'timeline': [],
                'message': 'Insufficient executions for drift analysis'
            })

        # Group by audit_id for multi-audit timeline
        audit_groups = {}
        for exec in executions:
            if exec.audit_id not in audit_groups:
                audit_groups[exec.audit_id] = []
            audit_groups[exec.audit_id].append(
                (exec.id, exec.executed_at, exec.output or '')
            )

        # Build drift timeline for each audit
        timelines = {}
        for a_id, exec_list in audit_groups.items():
            if len(exec_list) >= 2:
                timelines[a_id] = get_drift_timeline(exec_list, server_id, a_id)

        # Aggregate timeline if multiple audits
        if len(timelines) == 1:
            combined_timeline = list(timelines.values())[0]
        else:
            # Merge timelines by timestamp
            all_points = []
            for a_id, points in timelines.items():
                for point in points:
                    point['audit_id'] = a_id
                    all_points.append(point)
            combined_timeline = sorted(all_points, key=lambda x: x['timestamp'])

        return jsonify({
            'server_id': server_id,
            'audit_id': audit_id,
            'days': days,
            'timeline': combined_timeline
        })

    except Exception as e:
        logger.error(f"Error getting drift timeline: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/drift/summary', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_drift_summary():
    """
    Get drift summary across all servers for dashboard.

    Returns:
        Aggregated drift statistics and top drifting servers
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        # Get recent comparisons
        comparisons = db.session.query(DifferentialComparison)\
            .options(joinedload(DifferentialComparison.server))\
            .order_by(desc(DifferentialComparison.created_at))\
            .limit(100)\
            .all()

        if not comparisons:
            return jsonify({
                'total_comparisons': 0,
                'avg_drift_score': 0,
                'trend_breakdown': {'improving': 0, 'stable': 0, 'degrading': 0},
                'top_drifting_servers': []
            })

        # Calculate aggregates
        total_drift = sum(c.drift_score for c in comparisons)
        avg_drift = total_drift / len(comparisons)

        trend_breakdown = {'improving': 0, 'stable': 0, 'degrading': 0}
        for c in comparisons:
            if c.health_trend in trend_breakdown:
                trend_breakdown[c.health_trend] += 1

        # Top drifting servers (by average drift score)
        server_drift = {}
        for c in comparisons:
            if c.server_id not in server_drift:
                server_drift[c.server_id] = {
                    'server_id': c.server_id,
                    'server_name': c.server.name if c.server else f'Server {c.server_id}',
                    'scores': [],
                    'latest_trend': c.health_trend
                }
            server_drift[c.server_id]['scores'].append(c.drift_score)

        # Calculate average and sort
        top_servers = []
        for server_data in server_drift.values():
            server_data['avg_drift_score'] = round(
                sum(server_data['scores']) / len(server_data['scores']), 1
            )
            server_data['comparison_count'] = len(server_data['scores'])
            del server_data['scores']
            top_servers.append(server_data)

        top_servers = sorted(top_servers, key=lambda x: x['avg_drift_score'], reverse=True)[:10]

        return jsonify({
            'total_comparisons': len(comparisons),
            'avg_drift_score': round(avg_drift, 1),
            'trend_breakdown': trend_breakdown,
            'top_drifting_servers': top_servers
        })

    except Exception as e:
        logger.error(f"Error getting drift summary: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Saved Comparisons
# ============================================================================

@differential_bp.route('/api/differential/comparisons', methods=['GET'])
@require_auth_and_permission('view_history')
def list_comparisons():
    """
    List saved differential comparisons.

    Query Parameters:
        server_id: int - Filter by server
        audit_id: int - Filter by audit
        trend: str - Filter by health_trend (improving, stable, degrading)
        min_drift: float - Minimum drift score
        page: int - Page number (default: 1)
        per_page: int - Items per page (default: 20)
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        # Parse filters
        server_id = request.args.get('server_id', type=int)
        audit_id = request.args.get('audit_id', type=int)
        trend = request.args.get('trend')
        min_drift = request.args.get('min_drift', type=float)
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)

        # Build query
        query = db.session.query(DifferentialComparison)\
            .options(
                joinedload(DifferentialComparison.server),
                joinedload(DifferentialComparison.audit)
            )

        if server_id:
            query = query.filter(DifferentialComparison.server_id == server_id)
        if audit_id:
            query = query.filter(DifferentialComparison.audit_id == audit_id)
        if trend:
            query = query.filter(DifferentialComparison.health_trend == trend)
        if min_drift is not None:
            query = query.filter(DifferentialComparison.drift_score >= min_drift)

        # Get total count
        total = query.count()

        # Paginate
        comparisons = query.order_by(desc(DifferentialComparison.created_at))\
            .offset((page - 1) * per_page)\
            .limit(per_page)\
            .all()

        return jsonify({
            'comparisons': [c.to_dict() for c in comparisons],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        logger.error(f"Error listing comparisons: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/comparisons/<int:comparison_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def get_comparison(comparison_id: int):
    """Get a specific saved comparison by ID"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        comparison = db.session.query(DifferentialComparison)\
            .options(
                joinedload(DifferentialComparison.server),
                joinedload(DifferentialComparison.audit),
                joinedload(DifferentialComparison.baseline_execution),
                joinedload(DifferentialComparison.comparison_execution)
            )\
            .get(comparison_id)

        if not comparison:
            return jsonify({'error': 'Comparison not found'}), 404

        return jsonify(comparison.to_dict())

    except Exception as e:
        logger.error(f"Error getting comparison: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/comparisons/<int:comparison_id>', methods=['DELETE'])
@require_auth_permission_and_log('delete_all_data', 'delete_comparison')
def delete_comparison(comparison_id: int):
    """Delete a saved comparison"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        comparison = db.session.query(DifferentialComparison).get(comparison_id)
        if not comparison:
            return jsonify({'error': 'Comparison not found'}), 404

        db.session.delete(comparison)
        db.session.commit()

        return jsonify({'message': 'Comparison deleted', 'id': comparison_id})

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting comparison: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Remediation Tracking
# ============================================================================

@differential_bp.route('/api/differential/remediation', methods=['GET'])
@require_auth_and_permission('view_history')
def list_remediation_items():
    """
    List remediation items with filtering.

    Query Parameters:
        server_id: int - Filter by server
        audit_id: int - Filter by audit
        status: str - Filter by remediation_status
        priority: str - Filter by priority
        assigned_to: str - Filter by assignee
        page: int - Page number (default: 1)
        per_page: int - Items per page (default: 20)
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        # Parse filters
        server_id = request.args.get('server_id', type=int)
        audit_id = request.args.get('audit_id', type=int)
        status = request.args.get('status')
        priority = request.args.get('priority')
        assigned_to = request.args.get('assigned_to')
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)

        # Build query
        query = db.session.query(RemediationItem)\
            .options(
                joinedload(RemediationItem.server),
                joinedload(RemediationItem.audit)
            )

        if server_id:
            query = query.filter(RemediationItem.server_id == server_id)
        if audit_id:
            query = query.filter(RemediationItem.audit_id == audit_id)
        if status:
            query = query.filter(RemediationItem.remediation_status == status)
        if priority:
            query = query.filter(RemediationItem.priority == priority)
        if assigned_to:
            query = query.filter(RemediationItem.assigned_to == assigned_to)

        # Get total count
        total = query.count()

        # Order by priority, then by last seen
        priority_order = {'critical': 1, 'high': 2, 'medium': 3, 'low': 4}
        items = query.order_by(
            RemediationItem.remediation_status != 'open',  # Open items first
            RemediationItem.last_seen_at.desc()
        ).offset((page - 1) * per_page).limit(per_page).all()

        return jsonify({
            'items': [i.to_dict() for i in items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': total,
                'pages': (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        logger.error(f"Error listing remediation items: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/remediation/<int:item_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def get_remediation_item(item_id: int):
    """Get a specific remediation item with history"""
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        item = db.session.query(RemediationItem)\
            .options(
                joinedload(RemediationItem.server),
                joinedload(RemediationItem.audit),
                joinedload(RemediationItem.history)
            )\
            .get(item_id)

        if not item:
            return jsonify({'error': 'Remediation item not found'}), 404

        result = item.to_dict()
        result['history'] = [h.to_dict() for h in item.history]

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error getting remediation item: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/remediation/<int:item_id>', methods=['PUT'])
@require_auth_permission_and_log('edit_settings', 'update_remediation')
def update_remediation_item(item_id: int):
    """
    Update a remediation item.

    Request Body:
    {
        "remediation_status": "in_progress",  # open, in_progress, resolved, accepted_risk, ignored
        "priority": "high",                    # critical, high, medium, low
        "assigned_to": "john@example.com",
        "notes": "Working on fix",
        "remediation_steps": "1. Do this\n2. Do that",
        "resolution_notes": "Fixed by updating config"
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        item = db.session.query(RemediationItem).get(item_id)
        if not item:
            return jsonify({'error': 'Remediation item not found'}), 404

        data = request.get_json() or {}
        user = get_current_user()
        user_name = user.email if hasattr(user, 'email') else str(user)

        # Track changes for history
        updatable_fields = [
            'remediation_status', 'priority', 'assigned_to',
            'notes', 'remediation_steps', 'resolution_notes'
        ]

        for field in updatable_fields:
            if field in data:
                old_value = getattr(item, field)
                new_value = data[field]

                if old_value != new_value:
                    # Record history
                    history = RemediationHistory(
                        remediation_item_id=item_id,
                        field_changed=field,
                        old_value=str(old_value) if old_value else None,
                        new_value=str(new_value) if new_value else None,
                        changed_by=user_name
                    )
                    db.session.add(history)

                    # Apply change
                    setattr(item, field, new_value)

        # Handle resolution
        if data.get('remediation_status') == 'resolved' and not item.resolved_at:
            item.resolved_at = datetime.utcnow()
            item.resolved_by = user_name

        item.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify(item.to_dict())

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating remediation item: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/remediation', methods=['POST'])
@require_auth_permission_and_log('create_plans', 'create_remediation')
def create_remediation_item():
    """
    Create a new remediation item manually.

    Request Body:
    {
        "server_id": 1,
        "audit_id": 1,
        "check_name": "SSH Password Authentication",
        "check_section": "SSH Security",
        "current_status": "FAIL",
        "priority": "high",
        "assigned_to": "john@example.com",
        "notes": "Needs review"
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}
        user = get_current_user()

        required_fields = ['server_id', 'audit_id', 'check_name', 'current_status']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} is required'}), 400

        # Check for existing item
        existing = db.session.query(RemediationItem).filter(
            and_(
                RemediationItem.server_id == data['server_id'],
                RemediationItem.audit_id == data['audit_id'],
                RemediationItem.check_name == data['check_name']
            )
        ).first()

        if existing:
            return jsonify({
                'error': 'Remediation item already exists for this check',
                'existing_id': existing.id
            }), 409

        item = RemediationItem(
            server_id=data['server_id'],
            audit_id=data['audit_id'],
            check_name=data['check_name'],
            check_section=data.get('check_section', ''),
            current_status=data['current_status'],
            priority=data.get('priority', 'medium'),
            assigned_to=data.get('assigned_to'),
            notes=data.get('notes'),
            created_by=user.email if hasattr(user, 'email') else str(user)
        )

        db.session.add(item)
        db.session.commit()

        return jsonify(item.to_dict()), 201

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating remediation item: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/remediation/summary', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def get_remediation_summary():
    """
    Get remediation summary statistics for dashboard.

    Returns:
        Aggregated remediation statistics
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        # Status breakdown
        status_counts = {}
        for status in ['open', 'in_progress', 'resolved', 'accepted_risk', 'ignored']:
            count = db.session.query(RemediationItem)\
                .filter(RemediationItem.remediation_status == status)\
                .count()
            status_counts[status] = count

        # Priority breakdown (for open items only)
        priority_counts = {}
        for priority in ['critical', 'high', 'medium', 'low']:
            count = db.session.query(RemediationItem)\
                .filter(RemediationItem.remediation_status.in_(['open', 'in_progress']))\
                .filter(RemediationItem.priority == priority)\
                .count()
            priority_counts[priority] = count

        # Recent activity
        recent_resolved = db.session.query(RemediationItem)\
            .filter(RemediationItem.remediation_status == 'resolved')\
            .order_by(desc(RemediationItem.resolved_at))\
            .limit(5)\
            .all()

        return jsonify({
            'by_status': status_counts,
            'by_priority': priority_counts,
            'total_open': status_counts.get('open', 0) + status_counts.get('in_progress', 0),
            'total_resolved': status_counts.get('resolved', 0),
            'recently_resolved': [r.to_dict() for r in recent_resolved]
        })

    except Exception as e:
        logger.error(f"Error getting remediation summary: {e}")
        return jsonify({'error': str(e)}), 500


@differential_bp.route('/api/differential/remediation/sync', methods=['POST'])
@require_auth_permission_and_log('run_audits', 'sync_remediation')
def sync_remediation_items():
    """
    Sync remediation items from a recent execution.

    Creates or updates remediation items based on failing/warning checks
    in the specified execution.

    Request Body:
    {
        "execution_id": 123,
        "auto_resolve": true  # Mark items as resolved if they pass
    }
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        data = request.get_json() or {}
        execution_id = data.get('execution_id')
        auto_resolve = data.get('auto_resolve', False)

        if not execution_id:
            return jsonify({'error': 'execution_id is required'}), 400

        execution = db.session.query(AuditExecution).get(execution_id)
        if not execution:
            return jsonify({'error': 'Execution not found'}), 404

        # Parse findings
        parser = AuditOutputParser()
        findings = parser.parse_to_dict(execution.output or '')

        user = get_current_user()
        user_name = user.email if hasattr(user, 'email') else str(user)

        created = 0
        updated = 0
        resolved = 0

        for check_name, finding in findings.items():
            # Check for existing item
            existing = db.session.query(RemediationItem).filter(
                and_(
                    RemediationItem.server_id == execution.server_id,
                    RemediationItem.audit_id == execution.audit_id,
                    RemediationItem.check_name == check_name
                )
            ).first()

            if finding.status in (CheckStatus.FAIL, CheckStatus.WARN):
                if existing:
                    # Update existing item
                    if existing.current_status != finding.status.value:
                        existing.current_status = finding.status.value
                        updated += 1
                    existing.last_seen_at = execution.executed_at
                else:
                    # Create new item
                    priority = 'high' if finding.status == CheckStatus.FAIL else 'medium'
                    item = RemediationItem(
                        server_id=execution.server_id,
                        audit_id=execution.audit_id,
                        check_name=check_name,
                        check_section=finding.section,
                        current_status=finding.status.value,
                        first_execution_id=execution_id,
                        first_detected_at=execution.executed_at,
                        last_seen_at=execution.executed_at,
                        priority=priority,
                        created_by=user_name
                    )
                    db.session.add(item)
                    created += 1

            elif finding.status == CheckStatus.PASS and existing and auto_resolve:
                # Auto-resolve passing items
                if existing.remediation_status in ['open', 'in_progress']:
                    existing.remediation_status = 'resolved'
                    existing.resolved_at = datetime.utcnow()
                    existing.resolved_by = 'auto_sync'
                    existing.current_status = 'PASS'
                    resolved += 1

        db.session.commit()

        return jsonify({
            'message': 'Sync complete',
            'created': created,
            'updated': updated,
            'resolved': resolved
        })

    except Exception as e:
        db.session.rollback()
        logger.error(f"Error syncing remediation: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Parse Findings (Utility Endpoint)
# ============================================================================

@differential_bp.route('/api/differential/parse/<int:execution_id>', methods=['GET'])
@require_auth_and_permission('view_history')
def parse_execution_findings(execution_id: int):
    """
    Parse and return individual findings from an execution.

    Useful for viewing detailed check results without comparing.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({'error': 'Database not available'}), 503

    try:
        execution = db.session.query(AuditExecution)\
            .options(
                joinedload(AuditExecution.server),
                joinedload(AuditExecution.audit)
            )\
            .get(execution_id)

        if not execution:
            return jsonify({'error': 'Execution not found'}), 404

        parser = AuditOutputParser()
        findings = parser.parse(execution.output or '')

        # Group by section
        sections = {}
        for finding in findings:
            section = finding.section or 'General'
            if section not in sections:
                sections[section] = []
            sections[section].append(finding.to_dict())

        # Count by status
        status_counts = {'PASS': 0, 'FAIL': 0, 'WARN': 0, 'SKIP': 0}  # nosec B105
        for finding in findings:
            status_counts[finding.status.value] = status_counts.get(finding.status.value, 0) + 1

        return jsonify({
            'execution_id': execution_id,
            'server_id': execution.server_id,
            'server_name': execution.server.name if execution.server else None,
            'audit_id': execution.audit_id,
            'audit_name': execution.audit.name if execution.audit else None,
            'executed_at': execution.executed_at.isoformat() if execution.executed_at else None,
            'total_findings': len(findings),
            'status_counts': status_counts,
            'sections': sections,
            'findings': [f.to_dict() for f in findings]
        })

    except Exception as e:
        logger.error(f"Error parsing execution: {e}")
        return jsonify({'error': str(e)}), 500
