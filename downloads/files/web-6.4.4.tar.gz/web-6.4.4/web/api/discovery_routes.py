"""
Discovery Routes - System Discovery API

Provides endpoints for:
- Running discovery on servers (POST /api/discovery/run)
- Getting stored discovery results (GET /api/discovery/results)
- Getting results for a server (GET /api/discovery/results/<server_id>)
- Getting audit recommendations (POST /api/discovery/recommendations)

Discovery uses SSH (Linux) or WinRM (Windows) to detect:
- OS version and system information
- Installed packages with versions
- Running services and their status
- Available updates
- Security configuration

Results are stored for review in the Reports section.
"""

import subprocess  # nosec B404
import uuid
from datetime import datetime
from flask import Blueprint, jsonify, request

# Import from config
from config import logger

# Import auth decorators
from auth_core import require_api_key, conditional_limit, require_role
from flask_login import current_user, login_required

# Import audit logging
from logging_utils import log_audit

# Import WinRM management for Windows servers
try:
    from winrm_manager import winrm_manager, WINRM_AVAILABLE
except ImportError:
    winrm_manager = None
    WINRM_AVAILABLE = False

# Import discovery result storage
from models.discovery import discovery_manager

# Create blueprint
discovery_bp = Blueprint('discovery', __name__)

# Initialize managers (will be set by app.py via init_discovery_routes)
server_manager = None
ssh_manager = None
password_manager = None


def init_discovery_routes(svr_manager, ssh_mgr, pwd_manager):
    """
    Initialize discovery routes with manager instances

    Args:
        svr_manager: Server manager instance for database operations
        ssh_mgr: SSH manager instance for remote command execution
        pwd_manager: Password manager instance for credential decryption
    """
    global server_manager, ssh_manager, password_manager
    server_manager = svr_manager
    ssh_manager = ssh_mgr
    password_manager = pwd_manager


# ============================================================================
# Discovery Commands by OS
# ============================================================================

LINUX_DISCOVERY_COMMANDS = {
    # Detailed OS information
    'os_info': 'cat /etc/os-release 2>/dev/null',
    'kernel': 'uname -r 2>/dev/null',
    'architecture': 'uname -m 2>/dev/null',
    'hostname_full': 'hostname -f 2>/dev/null || hostname',

    # Package managers with version info
    'packages_dpkg': 'dpkg-query -W -f="${Package}|${Version}|${Description}\\n" 2>/dev/null | head -500',
    'packages_rpm': 'rpm -qa --qf "%{NAME}|%{VERSION}|%{SUMMARY}\\n" 2>/dev/null | head -500',
    'packages_apk': 'apk info -v 2>/dev/null | head -500',

    # Services with status
    'services_systemd': 'systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk \'{print $1}\' | head -100',
    'services_openrc': 'rc-service --list 2>/dev/null | head -100',

    # Updates with versions
    'updates_apt': 'apt list --upgradable 2>/dev/null | tail -n +2 | head -100',
    'updates_yum': 'yum check-update 2>/dev/null | tail -n +3 | awk \'{print $1, $2}\' | head -100',

    # Security checks
    'firewall_ufw': 'ufw status 2>/dev/null | head -1',
    'firewall_firewalld': 'firewall-cmd --state 2>/dev/null',
    'firewall_iptables': 'iptables -L -n 2>/dev/null | wc -l',
    'selinux': 'getenforce 2>/dev/null || cat /sys/fs/selinux/enforce 2>/dev/null',
    'apparmor': 'aa-status --enabled 2>/dev/null && echo enabled || echo disabled',
    'fail2ban': 'systemctl is-active fail2ban 2>/dev/null || rc-service fail2ban status 2>/dev/null | grep -q started && echo active',
    'ssh_config': 'grep -E "^(PermitRootLogin|PasswordAuthentication)" /etc/ssh/sshd_config 2>/dev/null',
}

WINDOWS_DISCOVERY_COMMANDS = {
    'os_info': 'Get-ComputerInfo | Select-Object OsName, OsVersion, CsName | ConvertTo-Json',
    'packages': 'Get-Package | Select-Object Name, Version | ConvertTo-Json',
    'services': 'Get-Service | Where-Object {$_.Status -eq "Running"} | Select-Object Name, DisplayName | ConvertTo-Json',
    'updates': 'Get-WindowsUpdate 2>$null | Select-Object Title | ConvertTo-Json',  # Requires PSWindowsUpdate module
}


# ============================================================================
# Discovery Endpoints
# ============================================================================

@discovery_bp.route('/api/discovery/run', methods=['POST'])
@require_api_key
@login_required
@require_role('Operator')
@conditional_limit("10 per minute")
def run_discovery():
    """
    Run discovery on a single server (requires Operator+ role)

    Request Body:
        server_id (int): Server ID to run discovery on
        format (str): Output format (json, yaml, text) - default json
        options (dict): Discovery options
            - packages (bool): Discover packages (default true)
            - services (bool): Discover services (default true)
            - updates (bool): Discover updates (default true)
            - security (bool): Discover security config (default false)

    Returns:
        JSON response with discovery results
    """
    try:
        data = request.get_json() or {}
        server_id = data.get('server_id')
        options = data.get('options', {})

        if not server_id:
            return jsonify({
                'success': False,
                'error': 'server_id is required'
            }), 400

        # Load server details
        servers = server_manager.load_servers()
        server = next((s for s in servers if s.get('id') == server_id), None)

        if not server:
            return jsonify({
                'success': False,
                'error': f'Server with ID {server_id} not found'
            }), 404

        os_type = server.get('os_type', 'linux').lower()
        hostname = server.get('hostname')
        port = server.get('port', 22 if os_type == 'linux' else 5985)
        username = server.get('username')

        # Decrypt password if needed
        password = None
        encrypted_password = server.get('password') or server.get('encrypted_password')
        if encrypted_password and password_manager:
            try:
                password = password_manager.decrypt_password(encrypted_password)
            except Exception as e:
                logger.warning(f"Could not decrypt password for {hostname}: {e}")

        result = {
            'server_id': server_id,
            'server_name': server.get('name'),
            'hostname': hostname,
            'os_type': os_type,
            'timestamp': datetime.utcnow().isoformat(),
            'success': True,
            'error': None,
            'os_info': {},
            'packages': [],
            'services': [],
            'updates': [],
            'security': {},
            'recommendations': []
        }

        try:
            # Get connection protocol preference
            connection_protocol = server.get('connection_protocol', 'auto')

            if os_type == 'windows':
                discovery_result = run_windows_discovery(
                    hostname, port, username, password, options,
                    connection_protocol=connection_protocol,
                    server=server
                )
            else:
                discovery_result = run_linux_discovery(
                    hostname, port, username, password,
                    server.get('key_path'), options
                )

            result.update(discovery_result)
            result['success'] = True

            # Get recommendations based on discovered software
            all_software = set()
            for pkg in result.get('packages', []):
                name = pkg.get('name', '') if isinstance(pkg, dict) else str(pkg)
                all_software.add(name.lower())
            for svc in result.get('services', []):
                name = svc.get('name', '') if isinstance(svc, dict) else str(svc)
                all_software.add(name.lower())

            recommendations = get_recommendations_for_software(all_software)
            result['recommendations'] = recommendations

        except Exception as discovery_error:
            result['success'] = False
            result['error'] = str(discovery_error)
            logger.error(f"Discovery failed for {hostname}: {discovery_error}")

        # Store the result for later review
        try:
            result_id = discovery_manager.save_result(result)
            result['id'] = result_id
            logger.info(f"Discovery result stored with ID {result_id} for server {server.get('name')}")

            # Log successful discovery
            log_audit(
                action='run_discovery',
                resource_id=str(server_id),
                resource_type='discovery_data',
                details={
                    'server_name': server.get('name'),
                    'hostname': hostname,
                    'os_type': os_type,
                    'result_id': result_id
                },
                success=result['success']
            )
        except Exception as store_error:
            logger.warning(f"Could not store discovery result: {store_error}")
            log_audit(
                action='run_discovery',
                resource_id=str(server_id),
                resource_type='discovery_data',
                success=False,
                error=f"Could not store result: {store_error}"
            )

        return jsonify({
            'success': result['success'],
            'data': result
        })

    except Exception as e:
        logger.error(f"Discovery error: {e}")
        log_audit(
            action='run_discovery',
            resource_id=str(server_id) if 'server_id' in locals() else 'unknown',
            resource_type='discovery_data',
            success=False,
            error=str(e)
        )
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def run_linux_discovery(hostname, port, username, password, key_path, options):
    """
    Run discovery on a Linux server via SSH

    Uses the deployed linux-discovery.sh script for comprehensive discovery.
    Falls back to individual SSH commands if script not available.

    Returns:
        dict: Discovery results with system info, packages, services, updates, network, storage
    """
    import json as json_module

    try:
        # Build SSH command base
        ssh_opts = [
            '-o', 'StrictHostKeyChecking=accept-new',
            '-o', 'ConnectTimeout=10',
            '-o', 'BatchMode=yes'
        ]

        if key_path:
            ssh_opts.extend(['-i', key_path])

        ssh_base = ['ssh'] + ssh_opts + ['-p', str(port), f'{username}@{hostname}']

        def run_ssh_cmd(cmd, timeout=30):
            """Helper to run SSH command and return output"""
            try:
                proc = subprocess.run(
                    ssh_base + [cmd],
                    capture_output=True, text=True, timeout=timeout
                )  # nosec B603
                return proc.stdout.strip() if proc.returncode == 0 else ''
            except Exception:
                return ''

        # Try to use deployed linux-discovery.sh script (more comprehensive, single SSH connection)
        # Check common deployment paths
        discovery_paths = [
            '/opt/security-audit-toolkit/tools/asset-discovery/scripts/linux-discovery.sh',
            '/opt/audit-toolkit/tools/asset-discovery/scripts/linux-discovery.sh',
            '~/security-audit-toolkit/tools/asset-discovery/scripts/linux-discovery.sh',
        ]

        script_path = None
        for path in discovery_paths:
            if run_ssh_cmd(f'test -f {path} && echo yes', timeout=5) == 'yes':
                script_path = path
                break

        if script_path:
            # Use the deployed script - single SSH connection, comprehensive output
            logger.info(f"Using deployed discovery script: {script_path}")

            # Build script arguments based on options
            # Use unique temp file to prevent symlink attacks (B108)
            # nosec B108: UUID suffix makes path unpredictable, mitigating symlink race
            discovery_temp = f"/tmp/discovery-{uuid.uuid4().hex[:12]}.json"  # nosec B108
            script_args = [f'-o {discovery_temp}']
            if options.get('lightweight', False):
                script_args.append('--lightweight')
            else:
                script_args.append('--all')  # Full discovery

            # Set limits if specified
            limit = options.get('limit', 500)
            script_args.append(f'--limit {limit}')

            # Run script and capture JSON output
            script_cmd = f'bash {script_path} {" ".join(script_args)} && cat {discovery_temp} && rm -f {discovery_temp}'
            script_output = run_ssh_cmd(script_cmd, timeout=120)

            if script_output:
                try:
                    script_result = json_module.loads(script_output)
                    # Script returns data in unified format - return directly
                    return normalize_script_output(script_result, options)
                except json_module.JSONDecodeError as e:
                    logger.warning(f"Failed to parse script output, falling back to SSH commands: {e}")

        # Fallback to legacy SSH commands (less comprehensive but always works)
        logger.info(f"Using legacy SSH discovery commands for {hostname}")
        return run_linux_discovery_legacy(ssh_base, run_ssh_cmd, options)

    except Exception as e:
        logger.error(f"Linux discovery error for {hostname}: {e}")
        raise


def normalize_script_output(script_result, options):
    """
    Normalize linux-discovery.sh output to match expected result format

    Args:
        script_result: Raw JSON output from linux-discovery.sh
        options: Discovery options dict

    Returns:
        dict: Normalized result matching DiscoveryResult schema
    """
    data = script_result.get('data', {})
    system = data.get('system', {})

    # Build os_info for backwards compatibility
    os_info = {
        'name': system.get('os_name'),
        'version': system.get('os_version'),
        'version_id': system.get('os_version'),
        'pretty_name': system.get('os_pretty_name'),
        'id': system.get('distro'),
        'id_like': system.get('distro_family'),
        'kernel': system.get('kernel_version'),
        'architecture': system.get('architecture'),
        'hostname': system.get('hostname')
    }

    result = {
        'success': script_result.get('success', True),
        'timestamp': script_result.get('scan_timestamp'),
        'system': system,
        'os_info': os_info,
        'network_interfaces': data.get('network_interfaces', []),
        'storage': data.get('storage', []),
        'packages': data.get('software', []),
        'services': data.get('services', []),
        'updates': data.get('pending_updates', []),
        'security': {},  # Script doesn't collect security - audits do this
        'errors': script_result.get('errors', [])
    }

    # Run security checks if requested (not covered by script)
    if options.get('security', False):
        # Security is collected separately via audits, not discovery
        result['security'] = {
            'note': 'Security configuration collected via security audits'
        }

    return result


def run_linux_discovery_legacy(ssh_base, run_ssh_cmd, options):
    """
    Legacy discovery using individual SSH commands

    Used as fallback when linux-discovery.sh script is not deployed.

    Args:
        ssh_base: SSH command base list
        run_ssh_cmd: Helper function to run SSH commands
        options: Discovery options dict

    Returns:
        dict: Discovery results
    """
    result = {
        'os_info': {},
        'system': {},
        'network_interfaces': [],
        'storage': [],
        'packages': [],
        'services': [],
        'updates': [],
        'security': {}
    }

    # Detailed OS Info
    try:
        os_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['os_info'])
        if os_output:
            for line in os_output.split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    result['os_info'][key.lower()] = value.strip('"')

        # Get kernel version
        kernel = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['kernel'])
        if kernel:
            result['os_info']['kernel'] = kernel

        # Get architecture
        arch = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['architecture'])
        if arch:
            result['os_info']['architecture'] = arch

        # Get full hostname
        full_hostname = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['hostname_full'])
        if full_hostname:
            result['os_info']['hostname'] = full_hostname

        # Build system dict for unified format
        result['system'] = {
            'hostname': result['os_info'].get('hostname'),
            'os_name': result['os_info'].get('name'),
            'os_version': result['os_info'].get('version_id'),
            'os_pretty_name': result['os_info'].get('pretty_name'),
            'kernel_version': result['os_info'].get('kernel'),
            'architecture': result['os_info'].get('architecture'),
            'distro': result['os_info'].get('id'),
            'distro_family': result['os_info'].get('id_like')
        }

    except Exception as e:
        logger.debug(f"OS info discovery error: {e}")

    # Packages with version info
    if options.get('packages', True):
        packages = []

        # Try dpkg-query (Debian/Ubuntu) with version and description
        dpkg_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['packages_dpkg'], timeout=60)
        if dpkg_output:
            for line in dpkg_output.split('\n'):
                if line.strip():
                    parts = line.split('|', 2)
                    pkg = {'name': parts[0].strip()}
                    if len(parts) > 1:
                        pkg['version'] = parts[1].strip()
                    if len(parts) > 2:
                        pkg['description'] = parts[2].strip()[:100]
                    packages.append(pkg)

        # Try rpm (RHEL/Fedora) with version and summary
        if not packages:
            rpm_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['packages_rpm'], timeout=60)
            if rpm_output:
                for line in rpm_output.split('\n'):
                    if line.strip():
                        parts = line.split('|', 2)
                        pkg = {'name': parts[0].strip()}
                        if len(parts) > 1:
                            pkg['version'] = parts[1].strip()
                        if len(parts) > 2:
                            pkg['description'] = parts[2].strip()[:100]
                        packages.append(pkg)

        # Try apk (Alpine)
        if not packages:
            apk_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['packages_apk'], timeout=60)
            if apk_output:
                for line in apk_output.split('\n'):
                    if line.strip():
                        parts = line.rsplit('-', 1)
                        pkg = {'name': parts[0].strip()}
                        if len(parts) > 1:
                            pkg['version'] = parts[1].strip()
                        packages.append(pkg)

        result['packages'] = packages

    # Services
    if options.get('services', True):
        services = []

        # Try systemd
        systemd_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['services_systemd'])
        if systemd_output:
            services = [{'name': s.strip().replace('.service', ''), 'status': 'running'}
                       for s in systemd_output.split('\n') if s.strip()]

        # Try OpenRC
        if not services:
            openrc_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['services_openrc'])
            if openrc_output:
                services = [{'name': s.strip(), 'status': 'available'}
                           for s in openrc_output.split('\n') if s.strip()]

        result['services'] = services

    # Updates with version info
    if options.get('updates', True):
        updates = []

        # Try apt
        apt_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['updates_apt'], timeout=60)
        if apt_output:
            for line in apt_output.split('\n'):
                if line.strip() and '/' in line:
                    parts = line.split()
                    pkg_name = parts[0].split('/')[0] if '/' in parts[0] else parts[0]
                    update = {'name': pkg_name}
                    if len(parts) > 1:
                        update['available'] = parts[1]
                    if 'from:' in line:
                        idx = line.find('from:')
                        current = line[idx+5:].strip().rstrip(']')
                        update['current'] = current
                    updates.append(update)

        # Try yum
        if not updates:
            yum_output = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['updates_yum'], timeout=60)
            if yum_output:
                for line in yum_output.split('\n'):
                    if line.strip():
                        parts = line.split()
                        update = {'name': parts[0]}
                        if len(parts) > 1:
                            update['available'] = parts[1]
                        updates.append(update)

        result['updates'] = updates

    # Security configuration
    if options.get('security', False):
        security = {}

        # Firewall status
        ufw_status = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['firewall_ufw'])
        firewalld_status = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['firewall_firewalld'])
        iptables_count = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['firewall_iptables'])

        if 'active' in ufw_status.lower():
            security['firewall_active'] = True
            security['firewall_type'] = 'ufw'
        elif 'running' in firewalld_status.lower():
            security['firewall_active'] = True
            security['firewall_type'] = 'firewalld'
        elif iptables_count and int(iptables_count) > 3:
            security['firewall_active'] = True
            security['firewall_type'] = 'iptables'
        else:
            security['firewall_active'] = False

        # SELinux status
        selinux = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['selinux'])
        security['selinux_status'] = selinux.lower() if selinux else 'not installed'

        # AppArmor status
        apparmor = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['apparmor'])
        security['apparmor_status'] = apparmor.lower() if apparmor else 'not installed'

        # Fail2ban status
        fail2ban = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['fail2ban'])
        security['fail2ban_active'] = 'active' in fail2ban.lower() if fail2ban else False

        # SSH configuration
        ssh_config = run_ssh_cmd(LINUX_DISCOVERY_COMMANDS['ssh_config'])
        if ssh_config:
            for line in ssh_config.split('\n'):
                if 'PermitRootLogin' in line:
                    security['ssh_root_login'] = 'yes' in line.lower()
                if 'PasswordAuthentication' in line:
                    security['password_auth'] = 'yes' in line.lower()

        result['security'] = security

    return result


def run_windows_discovery(hostname, port, username, password, options, connection_protocol='auto', server=None):
    """
    Run discovery on a Windows server via WinRM or SSH

    Uses the deployed windows-discovery.ps1 script for comprehensive discovery.
    Falls back to individual WinRM commands if script not available.

    Supports both WinRM (default) and OpenSSH for Windows connectivity.
    When connection_protocol='auto', tries WinRM first, then SSH fallback.

    Args:
        hostname: Remote hostname/IP
        port: Connection port (5985/5986 for WinRM, 22 for SSH)
        username: Remote username
        password: Remote password
        options: Discovery options dict
        connection_protocol: 'auto', 'winrm', or 'ssh'
        server: Full server dict (for SSH)

    Returns:
        dict: Discovery results with system info, packages, services, updates, network, storage
    """
    result = {
        'os_info': {},
        'system': {},
        'packages': [],
        'services': [],
        'updates': [],
        'network_interfaces': [],
        'storage': []
    }

    # Determine effective protocol
    use_winrm = True
    use_ssh = False

    if connection_protocol == 'ssh':
        use_winrm = False
        use_ssh = True
    elif connection_protocol == 'auto':
        # Try WinRM first if available
        use_winrm = WINRM_AVAILABLE and winrm_manager is not None
        use_ssh = not use_winrm  # Fallback to SSH
    # else: winrm (default)

    # Try WinRM
    if use_winrm:
        if not WINRM_AVAILABLE or not winrm_manager:
            if connection_protocol == 'auto':
                logger.info(f"WinRM not available, trying SSH for {hostname}")
                use_ssh = True
            else:
                raise Exception("WinRM not available - install pywinrm package")
        else:
            try:
                return _run_windows_discovery_winrm(hostname, port, username, password, options)
            except Exception as e:
                if connection_protocol == 'auto':
                    logger.warning(f"WinRM discovery failed for {hostname}: {e}, trying SSH fallback")
                    use_ssh = True
                else:
                    raise

    # Try SSH (for Windows with OpenSSH)
    if use_ssh:
        if not server:
            raise Exception("SSH fallback requires server config")
        return _run_windows_discovery_ssh(server, options)

    raise Exception("No connection method available")

def _normalize_winrm_test_connection_response(raw_response):
    """Normalize WinRM test_connection response for dict/tuple compatibility."""
    if isinstance(raw_response, dict):
        success = bool(raw_response.get('success'))
        message = raw_response.get('message') or raw_response.get('error') or 'Unknown response'
        return success, str(message)
    if isinstance(raw_response, tuple):
        if len(raw_response) >= 2:
            return bool(raw_response[0]), str(raw_response[1])
        if len(raw_response) == 1:
            return bool(raw_response[0]), ''
    return False, 'Invalid WinRM test_connection response'


def _normalize_winrm_execute_response(raw_response):
    """Normalize WinRM execute_command response for dict/tuple compatibility."""
    if isinstance(raw_response, dict):
        success = bool(raw_response.get('success'))
        stdout = raw_response.get('stdout')
        output = stdout if stdout is not None else raw_response.get('output', '')
        if not success and not output:
            output = raw_response.get('error') or raw_response.get('details') or ''
        return success, str(output)
    if isinstance(raw_response, tuple):
        if len(raw_response) >= 2:
            return bool(raw_response[0]), str(raw_response[1])
        if len(raw_response) == 1:
            return bool(raw_response[0]), ''
    return False, 'Invalid WinRM execute_command response'


def _run_windows_discovery_winrm(hostname, port, username, password, options):
    """Run Windows discovery via WinRM"""
    import json

    def _normalize_test_connection_response(raw_response):
        """Normalize WinRM test_connection response for dict/tuple compatibility."""
        if isinstance(raw_response, dict):
            success = bool(raw_response.get('success'))
            message = raw_response.get('message') or raw_response.get('error') or 'Unknown response'
            return success, str(message)
        if isinstance(raw_response, tuple):
            if len(raw_response) >= 2:
                return bool(raw_response[0]), str(raw_response[1])
            if len(raw_response) == 1:
                return bool(raw_response[0]), ''
        return False, 'Invalid WinRM test_connection response'

    def _normalize_execute_response(raw_response):
        """Normalize WinRM execute_command response for dict/tuple compatibility."""
        if isinstance(raw_response, dict):
            success = bool(raw_response.get('success'))
            stdout = raw_response.get('stdout')
            output = stdout if stdout is not None else raw_response.get('output', '')
            if not success and not output:
                output = raw_response.get('error') or raw_response.get('details') or ''
            return success, str(output)
        if isinstance(raw_response, tuple):
            if len(raw_response) >= 2:
                return bool(raw_response[0]), str(raw_response[1])
            if len(raw_response) == 1:
                return bool(raw_response[0]), ''
        return False, 'Invalid WinRM execute_command response'

    result = {
        'os_info': {},
        'system': {},
        'packages': [],
        'services': [],
        'updates': [],
        'network_interfaces': [],
        'storage': []
    }

    try:
        # Test connection first
        is_connected, msg = _normalize_test_connection_response(
            winrm_manager.test_connection(hostname, port, username, password)
        )
        if not is_connected:
            raise Exception(f"WinRM connection failed: {msg}")

        # Check for deployed discovery script
        script_paths = [
            'C:\\Program Files\\security-audit-toolkit\\tools\\asset-discovery\\scripts\\windows-discovery.ps1',
            'C:\\security-audit-toolkit\\tools\\asset-discovery\\scripts\\windows-discovery.ps1',
            'C:\\opt\\security-audit-toolkit\\tools\\asset-discovery\\scripts\\windows-discovery.ps1',
        ]

        script_path = None
        for path in script_paths:
            check_cmd = f'Test-Path "{path}"'
            success, output = _normalize_execute_response(
                winrm_manager.execute_command(hostname, port, username, password, check_cmd)
            )
            if success and 'True' in output:
                script_path = path
                logger.debug(f"Found Windows discovery script at: {path}")
                break

        if script_path:
            # Build script arguments
            script_args = ['-OutputPath', '"-"']  # Output to stdout

            if options.get('lightweight', False):
                script_args.append('-Lightweight')
            else:
                if not options.get('packages', True):
                    script_args.append('-IncludeSoftware:$false')
                if not options.get('services', True):
                    script_args.append('-IncludeServices:$false')
                if not options.get('updates', True):
                    script_args.append('-IncludeUpdates:$false')

            if options.get('throttle', False):
                script_args.append('-Throttle')

            limit = options.get('limit')
            if limit:
                script_args.append(f'-Limit {limit}')

            # Execute the script
            script_cmd = f'& "{script_path}" {" ".join(script_args)}'
            logger.debug(f"Executing Windows discovery script: {script_cmd}")

            success, output = _normalize_execute_response(
                winrm_manager.execute_command(hostname, port, username, password, script_cmd)
            )

            if success and output.strip():
                try:
                    script_result = json.loads(output.strip())
                    result = normalize_windows_script_output(script_result)
                    logger.info(f"Windows discovery via script completed for {hostname}")
                    return result
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse Windows script output: {e}")
                    # Fall through to legacy commands

        # Legacy discovery using individual commands
        logger.debug(f"Using legacy Windows discovery for {hostname}")
        return run_windows_discovery_legacy(hostname, port, username, password, options)

    except Exception as e:
        logger.error(f"Windows discovery error for {hostname}: {e}")
        raise


def _run_windows_discovery_ssh(server, options):
    """
    Run Windows discovery via SSH (OpenSSH for Windows)

    This is used when:
    1. connection_protocol='ssh' is explicitly set
    2. WinRM fails and auto-fallback is enabled

    Requires OpenSSH Server installed on Windows target.
    """
    import json

    if not ssh_manager:
        raise Exception("SSH manager not initialized")

    hostname = server.get('host') or server.get('hostname')
    ssh_port = server.get('port', 22)

    # If port is WinRM port, use SSH default
    if ssh_port in (5985, 5986):
        ssh_port = 22

    # Build SSH server config
    ssh_server = {
        'host': hostname,
        'port': ssh_port,
        'user': server.get('user') or server.get('username'),
        'password': server.get('password'),
        'auth_type': server.get('auth_type', 'password'),
        'key_path': server.get('key_path'),
        'os_type': 'windows',
        'name': server.get('name', hostname)
    }

    result = {
        'os_info': {},
        'system': {},
        'packages': [],
        'services': [],
        'updates': [],
        'network_interfaces': [],
        'storage': []
    }

    try:
        # Test SSH connection
        test_result = ssh_manager.execute_command(ssh_server, 'Write-Output Connected', timeout=15)
        if test_result.returncode != 0:
            raise Exception(f"SSH connection failed: {test_result.stderr}")

        logger.info(f"SSH connection established to Windows host {hostname}")

        # Get OS info via PowerShell
        os_cmd = 'Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,OSArchitecture,CSName | ConvertTo-Json'
        os_result = ssh_manager.execute_command(ssh_server, os_cmd, timeout=30)
        if os_result.returncode == 0 and os_result.stdout.strip():
            try:
                os_data = json.loads(os_result.stdout.strip())
                result['os_info'] = {
                    'name': os_data.get('Caption', 'Windows'),
                    'version': os_data.get('Version', ''),
                    'architecture': os_data.get('OSArchitecture', ''),
                    'hostname': os_data.get('CSName', hostname)
                }
            except json.JSONDecodeError:
                logger.warning(f"Could not parse OS info for {hostname}")

        # Get services if requested
        if options.get('services', True):
            svc_cmd = 'Get-Service | Select-Object Name,DisplayName,Status,StartType | ConvertTo-Json'
            svc_result = ssh_manager.execute_command(ssh_server, svc_cmd, timeout=60)
            if svc_result.returncode == 0 and svc_result.stdout.strip():
                try:
                    services = json.loads(svc_result.stdout.strip())
                    if isinstance(services, dict):
                        services = [services]
                    result['services'] = [
                        {
                            'name': s.get('Name', ''),
                            'display_name': s.get('DisplayName', ''),
                            'status': str(s.get('Status', '')),
                            'start_type': str(s.get('StartType', ''))
                        }
                        for s in services
                    ]
                except json.JSONDecodeError:
                    logger.warning(f"Could not parse services for {hostname}")

        # Get installed software if requested
        if options.get('packages', True):
            pkg_cmd = 'Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName,DisplayVersion,Publisher | Where-Object {$_.DisplayName} | ConvertTo-Json'
            pkg_result = ssh_manager.execute_command(ssh_server, pkg_cmd, timeout=120)
            if pkg_result.returncode == 0 and pkg_result.stdout.strip():
                try:
                    packages = json.loads(pkg_result.stdout.strip())
                    if isinstance(packages, dict):
                        packages = [packages]
                    result['packages'] = [
                        {
                            'name': p.get('DisplayName', ''),
                            'version': p.get('DisplayVersion', ''),
                            'publisher': p.get('Publisher', '')
                        }
                        for p in packages if p.get('DisplayName')
                    ]
                except json.JSONDecodeError:
                    logger.warning(f"Could not parse packages for {hostname}")

        logger.info(f"Windows SSH discovery completed for {hostname}: {len(result['services'])} services, {len(result['packages'])} packages")
        return result

    except Exception as e:
        logger.error(f"Windows SSH discovery error for {hostname}: {e}")
        raise


def normalize_windows_script_output(script_result):
    """
    Normalize Windows discovery script output to match expected API format
    """
    data = script_result.get('data', {})
    system = data.get('system', {})

    # Build os_info for backwards compatibility
    os_info = {
        'name': system.get('os_name', 'Windows'),
        'version': system.get('os_version', ''),
        'hostname': system.get('hostname', script_result.get('hostname', '')),
        'architecture': system.get('os_architecture', ''),
    }

    # Map packages from software
    packages = []
    for pkg in data.get('software', []):
        packages.append({
            'name': pkg.get('name', ''),
            'version': pkg.get('version', ''),
            'publisher': pkg.get('publisher', ''),
        })

    # Map services
    services = []
    for svc in data.get('services', []):
        services.append({
            'name': svc.get('name', ''),
            'display_name': svc.get('display_name', ''),
            'status': svc.get('status', ''),
            'start_type': svc.get('start_type', ''),
        })

    # Map updates
    updates = []
    for upd in data.get('pending_updates', []):
        updates.append({
            'name': upd.get('title', ''),
            'kb_article_ids': upd.get('kb_article_ids', []),
            'severity': upd.get('severity', ''),
            'is_security': upd.get('is_security', False),
        })

    return {
        'os_info': os_info,
        'system': system,
        'packages': packages,
        'services': services,
        'updates': updates,
        'network_interfaces': data.get('network_interfaces', []),
        'storage': data.get('storage', []),
        'windows_updates': data.get('windows_updates', []),  # Installed updates
    }


def run_windows_discovery_legacy(hostname, port, username, password, options):
    """
    Legacy Windows discovery using individual WinRM commands
    Used when discovery script is not deployed on target server
    """
    import json

    result = {
        'os_info': {},
        'packages': [],
        'services': [],
        'updates': []
    }

    try:
        # OS Info
        if options.get('packages', True) or options.get('services', True):
            try:
                success, output = _normalize_winrm_execute_response(
                    winrm_manager.execute_command(
                        hostname, port, username, password,
                        WINDOWS_DISCOVERY_COMMANDS['os_info']
                    )
                )
                if success and output.strip():
                    result['os_info'] = json.loads(output)
            except Exception as e:
                logger.debug(f"Windows OS info discovery error: {e}")

        # Packages
        if options.get('packages', True):
            try:
                success, output = _normalize_winrm_execute_response(
                    winrm_manager.execute_command(
                        hostname, port, username, password,
                        WINDOWS_DISCOVERY_COMMANDS['packages']
                    )
                )
                if success and output.strip():
                    packages_data = json.loads(output)
                    if isinstance(packages_data, list):
                        result['packages'] = [{'name': p.get('Name', '')} for p in packages_data]
                    elif isinstance(packages_data, dict):
                        result['packages'] = [{'name': packages_data.get('Name', '')}]
            except Exception as e:
                logger.debug(f"Windows packages discovery error: {e}")

        # Services
        if options.get('services', True):
            try:
                success, output = _normalize_winrm_execute_response(
                    winrm_manager.execute_command(
                        hostname, port, username, password,
                        WINDOWS_DISCOVERY_COMMANDS['services']
                    )
                )
                if success and output.strip():
                    services_data = json.loads(output)
                    if isinstance(services_data, list):
                        result['services'] = [{'name': s.get('Name', '')} for s in services_data]
                    elif isinstance(services_data, dict):
                        result['services'] = [{'name': services_data.get('Name', '')}]
            except Exception as e:
                logger.debug(f"Windows services discovery error: {e}")

        # Updates (requires PSWindowsUpdate module)
        if options.get('updates', True):
            try:
                success, output = _normalize_winrm_execute_response(
                    winrm_manager.execute_command(
                        hostname, port, username, password,
                        WINDOWS_DISCOVERY_COMMANDS['updates']
                    )
                )
                if success and output.strip():
                    updates_data = json.loads(output)
                    if isinstance(updates_data, list):
                        result['updates'] = [{'name': u.get('Title', '')} for u in updates_data]
            except Exception as e:
                logger.debug(f"Windows updates discovery error: {e}")

        return result

    except Exception as e:
        logger.error(f"Windows legacy discovery error for {hostname}: {e}")
        raise


# ============================================================================
# Audit Recommendations
# ============================================================================

# Mapping of software to recommended audits
# Each entry contains:
#   - name: Human-readable audit name
#   - audit_id: Script name (without extension) for wizard matching
#   - path: Full script path for direct execution
#   - platform: 'linux', 'windows', or 'all'
#   - description: Brief description of what the audit checks
#   - reason: Why this audit is recommended (shown in UI)
AUDIT_RECOMMENDATIONS = {
    # =====================
    # Web Servers
    # =====================
    'nginx': {
        'name': 'Nginx Security Audit',
        'audit_id': 'nginx-security-audit',
        'path': 'audits/linux/web/servers/nginx-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Nginx configuration for security best practices',
        'reason': 'Nginx web server detected'
    },
    'apache2': {
        'name': 'Apache Security Audit',
        'audit_id': 'apache-security-audit',
        'path': 'audits/linux/web/servers/apache-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Apache configuration for security best practices',
        'reason': 'Apache web server detected'
    },
    'httpd': {
        'name': 'Apache Security Audit',
        'audit_id': 'apache-security-audit',
        'path': 'audits/linux/web/servers/apache-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Apache configuration for security best practices',
        'reason': 'Apache httpd detected'
    },

    # =====================
    # Databases - Linux
    # =====================
    'mysql': {
        'name': 'MySQL Security Audit',
        'audit_id': 'mysql-security-audit',
        'path': 'audits/linux/data/relational/mysql-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit MySQL database security configuration',
        'reason': 'MySQL database detected'
    },
    'mariadb': {
        'name': 'MariaDB Security Audit',
        'audit_id': 'mysql-security-audit',
        'path': 'audits/linux/data/relational/mysql-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit MariaDB database security configuration',
        'reason': 'MariaDB database detected'
    },
    'postgresql': {
        'name': 'PostgreSQL Security Audit',
        'audit_id': 'postgresql-security-audit',
        'path': 'audits/linux/data/relational/postgresql-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit PostgreSQL database security configuration',
        'reason': 'PostgreSQL database detected'
    },
    'redis': {
        'name': 'Redis Security Audit',
        'audit_id': 'redis-security-audit',
        'path': 'audits/linux/data/cache/redis-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Redis security configuration',
        'reason': 'Redis detected'
    },
    'mongodb': {
        'name': 'MongoDB Security Audit',
        'audit_id': 'mongodb-security-audit',
        'path': 'audits/linux/data/nosql/mongodb-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit MongoDB security configuration',
        'reason': 'MongoDB detected'
    },

    # =====================
    # Containers
    # =====================
    'docker': {
        'name': 'Docker Security Audit',
        'audit_id': 'docker-security-audit',
        'path': 'audits/linux/apps/containers/docker-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Docker daemon and container security',
        'reason': 'Docker detected'
    },
    'containerd': {
        'name': 'Containerd Security Audit',
        'audit_id': 'containerd-audit',
        'path': 'audits/linux/apps/containers/containerd-audit.sh',
        'platform': 'linux',
        'description': 'Audit container runtime security',
        'reason': 'Containerd detected'
    },
    'podman': {
        'name': 'Podman Security Audit',
        'audit_id': 'podman-security-audit',
        'path': 'audits/linux/apps/containers/podman-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Podman container security',
        'reason': 'Podman detected'
    },

    # =====================
    # SSH
    # =====================
    'sshd': {
        'name': 'SSH Hardening Audit',
        'audit_id': 'ssh-hardening-audit',
        'path': 'audits/linux/platform/access/ssh-hardening-audit.sh',
        'platform': 'linux',
        'description': 'Audit SSH daemon configuration for security',
        'reason': 'SSH service detected'
    },
    'openssh-server': {
        'name': 'SSH Hardening Audit',
        'audit_id': 'ssh-hardening-audit',
        'path': 'audits/linux/platform/access/ssh-hardening-audit.sh',
        'platform': 'linux',
        'description': 'Audit SSH daemon configuration for security',
        'reason': 'OpenSSH server detected'
    },

    # =====================
    # Firewalls
    # =====================
    'ufw': {
        'name': 'UFW Firewall Audit',
        'audit_id': 'firewall-ufw-audit',
        'path': 'audits/linux/platform/firewall/firewall-ufw-audit.sh',
        'platform': 'linux',
        'description': 'Audit firewall rules and configuration',
        'reason': 'UFW firewall detected'
    },
    'firewalld': {
        'name': 'Firewall State Audit',
        'audit_id': 'firewall-state',
        'path': 'audits/linux/network/firewall/firewall-state.sh',
        'platform': 'linux',
        'description': 'Audit firewall rules and configuration',
        'reason': 'Firewalld detected'
    },
    'iptables': {
        'name': 'Firewall State Audit',
        'audit_id': 'firewall-state',
        'path': 'audits/linux/network/firewall/firewall-state.sh',
        'platform': 'linux',
        'description': 'Audit firewall rules and configuration',
        'reason': 'iptables detected'
    },

    # =====================
    # Security Tools
    # =====================
    'fail2ban': {
        'name': 'Fail2ban Security Audit',
        'audit_id': 'fail2ban-audit',
        'path': 'audits/linux/network/intrusion-prevention/fail2ban-audit.sh',
        'platform': 'linux',
        'description': 'Audit fail2ban configuration',
        'reason': 'fail2ban detected'
    },
    'auditd': {
        'name': 'Audit Daemon Audit',
        'audit_id': 'auditd-audit',
        'path': 'audits/linux/advanced-controls/auditd-audit.sh',
        'platform': 'linux',
        'description': 'Audit Linux audit daemon configuration',
        'reason': 'auditd detected'
    },

    # =====================
    # Baseline/Scheduling
    # =====================
    'crond': {
        'name': 'Cron Security Audit',
        'audit_id': 'svc-basics',
        'path': 'audits/linux/platform/baseline/svc-basics.sh',
        'platform': 'linux',
        'description': 'Audit scheduled tasks and cron jobs',
        'reason': 'Cron daemon detected'
    },
    'cron': {
        'name': 'Cron Security Audit',
        'audit_id': 'svc-basics',
        'path': 'audits/linux/platform/baseline/svc-basics.sh',
        'platform': 'linux',
        'description': 'Audit scheduled tasks and cron jobs',
        'reason': 'Cron service detected'
    },

    # =====================
    # EDR Agents
    # =====================
    'crowdstrike-falcon': {
        'name': 'CrowdStrike Falcon EDR Audit',
        'audit_id': 'crowdstrike-falcon-audit',
        'path': 'audits/linux/security/edr/crowdstrike-falcon-audit.sh',
        'platform': 'linux',
        'description': 'Audit CrowdStrike Falcon EDR agent configuration and status',
        'reason': 'CrowdStrike Falcon agent detected'
    },
    'cylance': {
        'name': 'Carbon Black EDR Audit',
        'audit_id': 'carbon-black-audit',
        'path': 'audits/linux/security/edr/carbon-black-audit.sh',
        'platform': 'linux',
        'description': 'Audit Carbon Black EDR agent configuration and status',
        'reason': 'Carbon Black/Cylance agent detected'
    },
    'sentinelone': {
        'name': 'SentinelOne EDR Audit',
        'audit_id': 'sentinelone-audit',
        'path': 'audits/linux/security/edr/sentinelone-audit.sh',
        'platform': 'linux',
        'description': 'Audit SentinelOne EDR agent configuration and status',
        'reason': 'SentinelOne agent detected'
    },
    'sophos': {
        'name': 'Sophos EDR Audit',
        'audit_id': 'sophos-audit',
        'path': 'audits/linux/security/edr/sophos-audit.sh',
        'platform': 'linux',
        'description': 'Audit Sophos EDR agent configuration and status',
        'reason': 'Sophos agent detected'
    },
    'carbonblack': {
        'name': 'Carbon Black EDR Audit',
        'audit_id': 'carbon-black-audit',
        'path': 'audits/linux/security/edr/carbon-black-audit.sh',
        'platform': 'linux',
        'description': 'Audit Carbon Black EDR agent configuration and status',
        'reason': 'Carbon Black agent detected'
    },

    # =====================
    # SIEM Agents
    # =====================
    'splunkforwarder': {
        'name': 'Splunk Forwarder Audit',
        'audit_id': 'splunk-forwarder-audit',
        'path': 'audits/linux/security/siem/splunk-forwarder-audit.sh',
        'platform': 'linux',
        'description': 'Audit Splunk Universal Forwarder agent configuration and status',
        'reason': 'Splunk Universal Forwarder detected'
    },
    'elastic-agent': {
        'name': 'Elastic Agent Audit',
        'audit_id': 'elastic-agent-audit',
        'path': 'audits/linux/security/siem/elastic-agent-audit.sh',
        'platform': 'linux',
        'description': 'Audit Elastic Agent configuration and status',
        'reason': 'Elastic Agent detected'
    },
    'wazuh-agent': {
        'name': 'Wazuh Agent Audit',
        'audit_id': 'wazuh-agent-audit',
        'path': 'audits/linux/security/edr/wazuh-agent-audit.sh',
        'platform': 'linux',
        'description': 'Audit Wazuh agent configuration and status',
        'reason': 'Wazuh agent detected'
    },
    'fluentd': {
        'name': 'Fluentd Audit',
        'audit_id': 'fluentd-audit',
        'path': 'audits/linux/security/siem/fluentd-audit.sh',
        'platform': 'linux',
        'description': 'Audit Fluentd log forwarder configuration',
        'reason': 'Fluentd detected'
    },
    'datadog-agent': {
        'name': 'Datadog Agent Audit',
        'audit_id': 'datadog-agent-audit',
        'path': 'audits/linux/security/siem/datadog-agent-audit.sh',
        'platform': 'linux',
        'description': 'Audit Datadog Agent configuration and status',
        'reason': 'Datadog Agent detected'
    },

    # =====================
    # Cloud Agents
    # =====================
    'amazon-ssm-agent': {
        'name': 'Amazon SSM Agent Audit',
        'audit_id': 'aws-ssm-audit',
        'path': 'audits/linux/cloud/aws/aws-ssm-audit.sh',
        'platform': 'linux',
        'description': 'Audit Amazon SSM agent configuration and status',
        'reason': 'Amazon SSM agent detected'
    },
    'azure-linux-agent': {
        'name': 'Azure Arc Agent Audit',
        'audit_id': 'azure-arc-audit',
        'path': 'audits/linux/cloud/azure/azure-arc-audit.sh',
        'platform': 'linux',
        'description': 'Audit Azure Linux agent configuration and status',
        'reason': 'Azure Linux agent detected'
    },
    'google-cloud-ops-agent': {
        'name': 'GCP Guest Agent Audit',
        'audit_id': 'gcp-guest-agent-audit',
        'path': 'audits/linux/cloud/gcp/gcp-guest-agent-audit.sh',
        'platform': 'linux',
        'description': 'Audit Google Cloud Ops agent configuration and status',
        'reason': 'Google Cloud Ops agent detected'
    },

    # =====================
    # Backup Agents (generic paths - scripts may not exist yet)
    # =====================
    'veeam': {
        'name': 'Veeam Backup Agent Audit',
        'audit_id': 'veeam-audit',
        'path': 'audits/linux/storage/backup/veeam-audit.sh',
        'platform': 'linux',
        'description': 'Audit Veeam backup agent configuration and status',
        'reason': 'Veeam backup agent detected'
    },
    'backup-exec': {
        'name': 'Backup Exec Agent Audit',
        'audit_id': 'backup-exec-audit',
        'path': 'audits/linux/storage/backup/backup-exec-audit.sh',
        'platform': 'linux',
        'description': 'Audit Backup Exec agent configuration and status',
        'reason': 'Backup Exec agent detected'
    },
    'networker': {
        'name': 'Dell EMC NetWorker Agent Audit',
        'audit_id': 'networker-audit',
        'path': 'audits/linux/storage/backup/networker-audit.sh',
        'platform': 'linux',
        'description': 'Audit Dell EMC NetWorker agent configuration and status',
        'reason': 'NetWorker agent detected'
    },

    # =====================
    # Hypervisors
    # =====================
    'libvirtd': {
        'name': 'KVM/QEMU Hypervisor Audit',
        'audit_id': 'kvm-qemu-audit',
        'path': 'audits/hypervisors/kvm/kvm-qemu-audit.sh',
        'platform': 'linux',
        'description': 'Audit KVM/Libvirt hypervisor configuration and security',
        'reason': 'KVM/Libvirt hypervisor detected'
    },
    'qemu-kvm': {
        'name': 'KVM/QEMU Hypervisor Audit',
        'audit_id': 'kvm-qemu-audit',
        'path': 'audits/hypervisors/kvm/kvm-qemu-audit.sh',
        'platform': 'linux',
        'description': 'Audit QEMU/KVM hypervisor configuration and security',
        'reason': 'QEMU/KVM hypervisor detected'
    },
    'xen-hypervisor': {
        'name': 'Xen Hypervisor Audit',
        'audit_id': 'xen-audit',
        'path': 'audits/hypervisors/xen/xen-audit.sh',
        'platform': 'linux',
        'description': 'Audit Xen hypervisor configuration and security',
        'reason': 'Xen hypervisor detected'
    },
    'nutanix': {
        'name': 'Nutanix Prism Audit',
        'audit_id': 'nutanix-prism-audit',
        'path': 'audits/hypervisors/nutanix/nutanix-prism-audit.sh',
        'platform': 'linux',
        'description': 'Audit Nutanix hypervisor configuration and security',
        'reason': 'Nutanix hypervisor detected'
    },
    'esxi': {
        'name': 'VMware ESXi Audit',
        'audit_id': 'vmware-esxi-audit',
        'path': 'audits/hypervisors/esxi/vmware-esxi-audit.sh',
        'platform': 'linux',
        'description': 'Audit VMware ESXi hypervisor configuration and security',
        'reason': 'VMware ESXi hypervisor detected'
    },
    'proxmox': {
        'name': 'Proxmox VE Audit',
        'audit_id': 'proxmox-audit',
        'path': 'audits/hypervisors/proxmox/proxmox-audit.sh',
        'platform': 'linux',
        'description': 'Audit Proxmox VE hypervisor configuration and security',
        'reason': 'Proxmox VE detected'
    },

    # =====================
    # Windows-Specific Software
    # =====================
    'iis': {
        'name': 'IIS Web Server Audit',
        'audit_id': 'iis-audit',
        'path': 'audits/windows/apps/web/iis-audit.ps1',
        'platform': 'windows',
        'description': 'Audit IIS web server configuration and security',
        'reason': 'IIS web server detected'
    },
    'w3svc': {
        'name': 'IIS Web Server Audit',
        'audit_id': 'iis-audit',
        'path': 'audits/windows/apps/web/iis-audit.ps1',
        'platform': 'windows',
        'description': 'Audit IIS web server configuration and security',
        'reason': 'IIS web service (W3SVC) detected'
    },
    'mssqlserver': {
        'name': 'Microsoft SQL Server Audit',
        'audit_id': 'sqlserver-audit',
        'path': 'audits/windows/apps/database/sqlserver-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Microsoft SQL Server security configuration',
        'reason': 'Microsoft SQL Server detected'
    },
    'sqlserver': {
        'name': 'Microsoft SQL Server Audit',
        'audit_id': 'sqlserver-audit',
        'path': 'audits/windows/apps/database/sqlserver-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Microsoft SQL Server security configuration',
        'reason': 'SQL Server detected'
    },
    'termservice': {
        'name': 'Remote Desktop Security Audit',
        'audit_id': 'rdp-baseline-audit',
        'path': 'audits/windows/apps/remote-desktop/rdp-baseline-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Remote Desktop security configuration',
        'reason': 'Remote Desktop Services detected'
    },
    'rdp': {
        'name': 'Remote Desktop Security Audit',
        'audit_id': 'rdp-baseline-audit',
        'path': 'audits/windows/apps/remote-desktop/rdp-baseline-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Remote Desktop security configuration',
        'reason': 'RDP detected'
    },
    'winrm': {
        'name': 'WinRM Security Audit',
        'audit_id': 'winrm',
        'path': 'audits/windows/common/winrm.ps1',
        'platform': 'windows',
        'description': 'Audit Windows Remote Management security',
        'reason': 'WinRM service detected'
    },
    'wins': {
        'name': 'Network Settings Audit',
        'audit_id': 'network_settings',
        'path': 'audits/windows/common/network_settings.ps1',
        'platform': 'windows',
        'description': 'Audit Windows Internet Name Service',
        'reason': 'WINS service detected'
    },
    'dns': {
        'name': 'DNS Client Service Audit',
        'audit_id': 'dns_client_service',
        'path': 'audits/windows/common/dns_client_service.ps1',
        'platform': 'windows',
        'description': 'Audit Windows DNS configuration',
        'reason': 'DNS Server detected'
    },
    'dhcp': {
        'name': 'DHCP Client Service Audit',
        'audit_id': 'dhcp_client_service',
        'path': 'audits/windows/common/dhcp_client_service.ps1',
        'platform': 'windows',
        'description': 'Audit Windows DHCP configuration',
        'reason': 'DHCP service detected'
    },
    'ntds': {
        'name': 'Active Directory Audit',
        'audit_id': 'active_directory',
        'path': 'audits/windows/server/active_directory.ps1',
        'platform': 'windows',
        'description': 'Audit Active Directory security configuration',
        'reason': 'Active Directory detected'
    },
    'adws': {
        'name': 'Active Directory Audit',
        'audit_id': 'active_directory',
        'path': 'audits/windows/server/active_directory.ps1',
        'platform': 'windows',
        'description': 'Audit Active Directory security configuration',
        'reason': 'Active Directory Web Services detected'
    },
    'microsoft exchange': {
        'name': 'Exchange Server Audit',
        'audit_id': 'exchange-audit',
        'path': 'audits/windows/apps/exchange/exchange-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Microsoft Exchange security configuration',
        'reason': 'Microsoft Exchange detected'
    },
    'msexchange': {
        'name': 'Exchange Server Audit',
        'audit_id': 'exchange-audit',
        'path': 'audits/windows/apps/exchange/exchange-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Microsoft Exchange security configuration',
        'reason': 'Microsoft Exchange service detected'
    },
    'sharepoint': {
        'name': 'SharePoint Server Audit',
        'audit_id': 'sharepoint-audit',
        'path': 'audits/windows/apps/sharepoint/sharepoint-audit.ps1',
        'platform': 'windows',
        'description': 'Audit SharePoint security configuration',
        'reason': 'SharePoint detected'
    },
    'hyper-v': {
        'name': 'Hyper-V Hypervisor Audit',
        'audit_id': 'hyperv',
        'path': 'audits/windows/server/hyperv.ps1',
        'platform': 'windows',
        'description': 'Audit Hyper-V hypervisor configuration and security',
        'reason': 'Hyper-V detected'
    },
    'vmms': {
        'name': 'Hyper-V Hypervisor Audit',
        'audit_id': 'hyperv',
        'path': 'audits/windows/server/hyperv.ps1',
        'platform': 'windows',
        'description': 'Audit Hyper-V hypervisor configuration and security',
        'reason': 'Hyper-V Virtual Machine Management Service detected'
    },
    'windows defender': {
        'name': 'Windows Defender Audit',
        'audit_id': 'defender_audit',
        'path': 'audits/windows/common/defender_audit.ps1',
        'platform': 'windows',
        'description': 'Audit Windows Defender configuration and status',
        'reason': 'Windows Defender detected'
    },
    'mpssvc': {
        'name': 'Windows Firewall Audit',
        'audit_id': 'firewall_audit',
        'path': 'audits/windows/common/firewall_audit.ps1',
        'platform': 'windows',
        'description': 'Audit Windows Firewall configuration',
        'reason': 'Windows Firewall service detected'
    },
    'wsus': {
        'name': 'WSUS Server Audit',
        'audit_id': 'wsus_sccm',
        'path': 'audits/windows/common/wsus_sccm.ps1',
        'platform': 'windows',
        'description': 'Audit Windows Server Update Services configuration',
        'reason': 'WSUS detected'
    },

    # =====================
    # CI/CD and Automation - Linux
    # =====================
    'jenkins': {
        'name': 'Jenkins Security Audit',
        'audit_id': 'jenkins-security-audit',
        'path': 'audits/linux/automation/ci-cd/jenkins-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Jenkins CI/CD server security configuration',
        'reason': 'Jenkins detected'
    },
    'gitlab-runner': {
        'name': 'GitLab Security Audit',
        'audit_id': 'gitlab-security-audit',
        'path': 'audits/linux/automation/ci-cd/gitlab-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit GitLab runner security configuration',
        'reason': 'GitLab Runner detected'
    },
    'ansible': {
        'name': 'Ansible Security Audit',
        'audit_id': 'ansible-security-audit',
        'path': 'audits/linux/automation/config-mgmt/ansible-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Ansible configuration management security',
        'reason': 'Ansible detected'
    },
    'terraform': {
        'name': 'Terraform Security Audit',
        'audit_id': 'terraform-security-audit',
        'path': 'audits/linux/automation/iac/terraform-security-audit.sh',
        'platform': 'linux',
        'description': 'Audit Terraform IaC security practices',
        'reason': 'Terraform detected'
    },
    'chef-client': {
        'name': 'Chef Security Audit',
        'audit_id': 'chef-audit',
        'path': 'audits/linux/automation/config-mgmt/chef-audit.sh',
        'platform': 'linux',
        'description': 'Audit Chef configuration management security',
        'reason': 'Chef client detected'
    },
    'puppet': {
        'name': 'Puppet Security Audit',
        'audit_id': 'puppet-audit',
        'path': 'audits/linux/automation/config-mgmt/puppet-audit.sh',
        'platform': 'linux',
        'description': 'Audit Puppet configuration management security',
        'reason': 'Puppet detected'
    },
    'salt-minion': {
        'name': 'SaltStack Security Audit',
        'audit_id': 'salt-audit',
        'path': 'audits/linux/automation/config-mgmt/salt-audit.sh',
        'platform': 'linux',
        'description': 'Audit SaltStack configuration management security',
        'reason': 'Salt minion detected'
    },

    # =====================
    # PHP (Linux)
    # =====================
    'php-fpm': {
        'name': 'PHP-FPM Security Audit',
        'audit_id': 'php-fpm-audit',
        'path': 'audits/linux/web/servers/php-fpm-audit.sh',
        'platform': 'linux',
        'description': 'Audit PHP-FPM configuration and security',
        'reason': 'PHP-FPM detected'
    },

    # =====================
    # Windows Nginx/Apache
    # =====================
    'nginx-windows': {
        'name': 'Nginx Security Audit (Windows)',
        'audit_id': 'nginx-audit',
        'path': 'audits/windows/apps/web/nginx-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Nginx configuration on Windows',
        'reason': 'Nginx on Windows detected'
    },
    'apache-windows': {
        'name': 'Apache Security Audit (Windows)',
        'audit_id': 'apache-audit',
        'path': 'audits/windows/apps/web/apache-audit.ps1',
        'platform': 'windows',
        'description': 'Audit Apache configuration on Windows',
        'reason': 'Apache on Windows detected'
    },

    # =====================
    # Windows MySQL/PostgreSQL/MongoDB
    # =====================
    'mysql-windows': {
        'name': 'MySQL Security Audit (Windows)',
        'audit_id': 'mysql-audit',
        'path': 'audits/windows/apps/database/mysql-audit.ps1',
        'platform': 'windows',
        'description': 'Audit MySQL database on Windows',
        'reason': 'MySQL on Windows detected'
    },
    'postgresql-windows': {
        'name': 'PostgreSQL Security Audit (Windows)',
        'audit_id': 'postgresql-audit',
        'path': 'audits/windows/apps/database/postgresql-audit.ps1',
        'platform': 'windows',
        'description': 'Audit PostgreSQL database on Windows',
        'reason': 'PostgreSQL on Windows detected'
    },
    'mongodb-windows': {
        'name': 'MongoDB Security Audit (Windows)',
        'audit_id': 'mongodb-audit',
        'path': 'audits/windows/apps/database/mongodb-audit.ps1',
        'platform': 'windows',
        'description': 'Audit MongoDB on Windows',
        'reason': 'MongoDB on Windows detected'
    },

    # =====================
    # Windows ADCS
    # =====================
    'certsvc': {
        'name': 'AD Certificate Services Audit',
        'audit_id': 'adcs_audit',
        'path': 'audits/windows/server/adcs_audit.ps1',
        'platform': 'windows',
        'description': 'Audit Active Directory Certificate Services',
        'reason': 'AD Certificate Services detected'
    },
}


@discovery_bp.route('/api/discovery/recommendations', methods=['POST'])
@require_api_key
@login_required
@require_role('Analyst')
def get_recommendations():
    """
    Get recommended audits based on discovered software (requires Analyst+ role)

    Request Body:
        packages (list): List of package names
        services (list): List of service names
        platform (str): Target platform ('linux' or 'windows', default 'linux')

    Returns:
        JSON response with recommended audits including script paths
    """
    try:
        data = request.get_json() or {}
        packages = data.get('packages', [])
        services = data.get('services', [])
        platform = data.get('platform', 'linux').lower()

        # Combine and deduplicate
        all_software = set()
        for pkg in packages:
            if isinstance(pkg, dict):
                all_software.add(pkg.get('name', '').lower())
            else:
                all_software.add(str(pkg).lower())

        for svc in services:
            if isinstance(svc, dict):
                all_software.add(svc.get('name', '').lower())
            else:
                all_software.add(str(svc).lower())

        # Use shared helper function to get recommendations with paths
        recommendations = get_recommendations_for_software(all_software, platform)

        # Log audit entry
        log_audit(
            action='get_recommendations',
            resource_id=str(len(all_software)),
            resource_type='discovery_data',
            details={
                'platform': platform,
                'software_count': len(all_software),
                'recommendation_count': len(recommendations)
            },
            success=True
        )

        return jsonify({
            'success': True,
            'recommendations': recommendations,
            'total': len(recommendations),
            'platform': platform
        })

    except Exception as e:
        logger.error(f"Recommendations error: {e}")
        log_audit(
            action='get_recommendations',
            resource_id='unknown',
            resource_type='discovery_data',
            success=False,
            error=str(e)
        )
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def get_recommendations_for_software(all_software, platform='linux'):
    """
    Get recommended audits based on a set of software names (internal helper)

    Args:
        all_software: Set of lowercase software names
        platform: Target platform ('linux' or 'windows') for baseline audits

    Returns:
        List of recommendation dicts with path, audit_id, platform fields
    """
    recommendations = []
    seen_audit_ids = set()

    for software in all_software:
        for key, rec in AUDIT_RECOMMENDATIONS.items():
            if key in software or software in key:
                if rec['audit_id'] not in seen_audit_ids:
                    # Include all fields including path and platform
                    recommendations.append(rec.copy())
                    seen_audit_ids.add(rec['audit_id'])

    # Add platform-appropriate baseline recommendations
    if platform == 'windows':
        baseline_audits = [
            {
                'name': 'System Updates Audit',
                'audit_id': 'patch_level',
                'path': 'audits/windows/common/patch_level.ps1',
                'platform': 'windows',
                'description': 'Check for pending system updates',
                'reason': 'Recommended for all Windows systems'
            },
            {
                'name': 'User Accounts Audit',
                'audit_id': 'guest_account',
                'path': 'audits/windows/common/guest_account.ps1',
                'platform': 'windows',
                'description': 'Audit user accounts and permissions',
                'reason': 'Recommended for all Windows systems'
            },
            {
                'name': 'Password Policy Audit',
                'audit_id': 'password_policy',
                'path': 'audits/windows/common/password_policy.ps1',
                'platform': 'windows',
                'description': 'Audit password policy configuration',
                'reason': 'Recommended for all Windows systems'
            }
        ]
    else:
        baseline_audits = [
            {
                'name': 'System Updates Audit',
                'audit_id': 'updates',
                'path': 'audits/linux/platform/baseline/updates.sh',
                'platform': 'linux',
                'description': 'Check for pending system updates',
                'reason': 'Recommended for all Linux systems'
            },
            {
                'name': 'OS Baseline Audit',
                'audit_id': 'os-baseline-audit',
                'path': 'audits/linux/platform/baseline/os-baseline-audit.sh',
                'platform': 'linux',
                'description': 'Audit OS baseline configuration',
                'reason': 'Recommended for all Linux systems'
            },
            {
                'name': 'Hardware Info Audit',
                'audit_id': 'hardware-info-audit',
                'path': 'audits/linux/platform/baseline/hardware-info-audit.sh',
                'platform': 'linux',
                'description': 'Gather hardware information',
                'reason': 'Recommended for all Linux systems'
            }
        ]

    for baseline in baseline_audits:
        if baseline['audit_id'] not in seen_audit_ids:
            recommendations.append(baseline)
            seen_audit_ids.add(baseline['audit_id'])

    return recommendations


# ============================================================================
# Discovery Results Retrieval Endpoints
# ============================================================================

@discovery_bp.route('/api/discovery/results')
@require_api_key
@login_required
@require_role('Analyst')
def get_all_discovery_results():
    """
    Get all stored discovery results (requires Analyst+ role)

    Query Parameters:
        limit (int): Maximum number of results (default 50)

    Returns:
        JSON response with discovery results
    """
    try:
        limit = int(request.args.get('limit', 50))
        results = discovery_manager.get_all_results(limit=limit)

        # Log audit entry
        log_audit(
            action='view_discovery_all',
            resource_id='all',
            resource_type='discovery_data',
            details={'limit': limit, 'result_count': len(results)},
            success=True
        )

        return jsonify({
            'success': True,
            'results': [r.to_dict() for r in results],
            'total': len(results)
        })

    except Exception as e:
        logger.error(f"Error getting discovery results: {e}")
        log_audit(
            action='view_discovery_all',
            resource_id='all',
            resource_type='discovery_data',
            success=False,
            error=str(e)
        )
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/results/<int:server_id>')
@require_api_key
@login_required
@require_role('Analyst')
def get_server_discovery_results(server_id):
    """
    Get discovery results for a specific server (requires Analyst+ role)

    Path Parameters:
        server_id (int): Server ID

    Query Parameters:
        limit (int): Maximum number of results (default 10)

    Returns:
        JSON response with discovery results for the server
    """
    try:
        limit = int(request.args.get('limit', 10))
        results = discovery_manager.get_results_by_server(server_id, limit=limit)

        # Get latest result summary
        latest = results[0] if results else None

        # Log audit entry
        log_audit(
            action='view_discovery_server',
            resource_id=str(server_id),
            resource_type='discovery_data',
            details={'server_id': server_id, 'result_count': len(results)},
            success=True
        )

        return jsonify({
            'success': True,
            'server_id': server_id,
            'results': [r.to_dict() for r in results],
            'total': len(results),
            'latest_summary': latest.get_summary() if latest else None
        })

    except Exception as e:
        logger.error(f"Error getting discovery results for server {server_id}: {e}")
        log_audit(
            action='view_discovery_server',
            resource_id=str(server_id),
            resource_type='discovery_data',
            success=False,
            error=str(e)
        )
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/results/<int:server_id>/latest')
@require_api_key
def get_latest_discovery_result(server_id):
    """
    Get the most recent discovery result for a server

    Path Parameters:
        server_id (int): Server ID

    Returns:
        JSON response with the latest discovery result
    """
    try:
        result = discovery_manager.get_latest_result_by_server(server_id)

        if not result:
            return jsonify({
                'success': False,
                'error': f'No discovery results found for server {server_id}'
            }), 404

        return jsonify({
            'success': True,
            'result': result.to_dict(),
            'summary': result.get_summary()
        })

    except Exception as e:
        logger.error(f"Error getting latest discovery for server {server_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/result/<int:result_id>')
@require_api_key
def get_discovery_result_by_id(result_id):
    """
    Get a specific discovery result by ID

    Path Parameters:
        result_id (int): Result ID

    Returns:
        JSON response with the discovery result
    """
    try:
        result = discovery_manager.get_result(result_id)

        if not result:
            return jsonify({
                'success': False,
                'error': f'Discovery result {result_id} not found'
            }), 404

        return jsonify({
            'success': True,
            'result': result.to_dict(),
            'summary': result.get_summary()
        })

    except Exception as e:
        logger.error(f"Error getting discovery result {result_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/result/<int:result_id>', methods=['DELETE'])
@require_api_key
@login_required
def delete_discovery_result(result_id):
    """
    Delete a specific discovery result (SuperAdmin only)

    Path Parameters:
        result_id (int): Result ID

    Returns:
        JSON response confirming deletion
    """
    # SuperAdmin-only check (explicit, not using role hierarchy)
    if not current_user.is_authenticated or current_user.role != 'SuperAdmin':
        log_audit(
            action='delete_discovery_denied',
            resource_id=str(result_id),
            resource_type='discovery_data',
            success=False,
            error='SuperAdmin role required'
        )
        return jsonify({
            'success': False,
            'error': 'SuperAdmin access required for deletion'
        }), 403

    try:
        deleted = discovery_manager.delete_result(result_id)

        if not deleted:
            log_audit(
                action='delete_discovery',
                resource_id=str(result_id),
                resource_type='discovery_data',
                success=False,
                error='Result not found'
            )
            return jsonify({
                'success': False,
                'error': f'Discovery result {result_id} not found'
            }), 404

        # Log deletion
        log_audit(
            action='delete_discovery',
            resource_id=str(result_id),
            resource_type='discovery_data',
            success=True,
            details={'deleted_by': current_user.username if hasattr(current_user, 'username') else 'unknown'}
        )

        return jsonify({
            'success': True,
            'message': f'Discovery result {result_id} deleted'
        })

    except Exception as e:
        logger.error(f"Error deleting discovery result {result_id}: {e}")
        log_audit(
            action='delete_discovery',
            resource_id=str(result_id),
            resource_type='discovery_data',
            success=False,
            error=str(e)
        )
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================================================
# Fleet-Wide Discovery Endpoints (Remote Discovery Feature)
# ============================================================================

from concurrent.futures import ThreadPoolExecutor, as_completed


@discovery_bp.route('/api/discovery/fleet/run', methods=['POST'])
@require_api_key
@conditional_limit("5 per hour")
def run_fleet_discovery():
    """
    Run discovery across multiple servers in parallel.

    Request Body:
        server_ids (list): List of server IDs to run discovery on (optional, defaults to all)
        options (dict): Discovery options passed to each server
            - packages (bool): Discover packages (default true)
            - services (bool): Discover services (default true)
            - updates (bool): Discover updates (default true)
            - security (bool): Discover security config (default false)
        max_concurrent (int): Max parallel connections (default 5, max 10)

    Returns:
        JSON response with discovery results for all servers
    """
    try:
        data = request.get_json() or {}
        server_ids = data.get('server_ids')
        options = data.get('options', {})
        max_concurrent = min(int(data.get('max_concurrent', 5)), 10)

        # Load all servers
        all_servers = server_manager.load_servers()

        # Filter servers if IDs provided
        if server_ids:
            target_servers = [s for s in all_servers if s.get('id') in server_ids]
        else:
            target_servers = all_servers

        if not target_servers:
            return jsonify({
                'success': False,
                'error': 'No servers found to run discovery on'
            }), 404

        results = []
        errors = []

        def run_single_discovery(server):
            """Run discovery on a single server (thread-safe)."""
            server_id = server.get('id')
            hostname = server.get('hostname')
            os_type = server.get('os_type', 'linux').lower()
            port = server.get('port', 22 if os_type == 'linux' else 5985)
            username = server.get('username')

            # Decrypt password if needed
            password = None
            encrypted_password = server.get('password') or server.get('encrypted_password')
            if encrypted_password and password_manager:
                try:
                    password = password_manager.decrypt_password(encrypted_password)
                except Exception as e:
                    logger.debug(f"Password decryption failed: {e}")

            result = {
                'server_id': server_id,
                'server_name': server.get('name'),
                'hostname': hostname,
                'os_type': os_type,
                'timestamp': datetime.utcnow().isoformat(),
                'success': False,
                'error': None,
                'os_info': {},
                'packages': [],
                'services': [],
                'updates': [],
                'security': {},
                'recommendations': []
            }

            try:
                if os_type == 'windows':
                    connection_protocol = server.get('connection_protocol', 'auto')
                    discovery_result = run_windows_discovery(
                        hostname,
                        port,
                        username,
                        password,
                        options,
                        connection_protocol=connection_protocol,
                        server=server
                    )
                else:
                    discovery_result = run_linux_discovery(
                        hostname, port, username, password,
                        server.get('key_path'), options
                    )

                result.update(discovery_result)
                result['success'] = True

                # Get recommendations
                all_software = set()
                for pkg in result.get('packages', []):
                    name = pkg.get('name', '') if isinstance(pkg, dict) else str(pkg)
                    all_software.add(name.lower())
                for svc in result.get('services', []):
                    name = svc.get('name', '') if isinstance(svc, dict) else str(svc)
                    all_software.add(name.lower())

                result['recommendations'] = get_recommendations_for_software(all_software)

            except Exception as e:
                result['success'] = False
                result['error'] = str(e)
                logger.error(f"Fleet discovery failed for {hostname}: {e}")

            # Store result
            try:
                result_id = discovery_manager.save_result(result)
                result['id'] = result_id
            except Exception as e:
                logger.debug(f"Failed to save discovery result: {e}")

            return result

        # Run discoveries in parallel
        with ThreadPoolExecutor(max_workers=max_concurrent) as executor:
            future_to_server = {
                executor.submit(run_single_discovery, server): server
                for server in target_servers
            }

            for future in as_completed(future_to_server):
                server = future_to_server[future]
                try:
                    result = future.result(timeout=300)
                    results.append(result)
                    if not result['success']:
                        errors.append({
                            'server_id': server.get('id'),
                            'server_name': server.get('name'),
                            'error': result.get('error')
                        })
                except Exception as e:
                    errors.append({
                        'server_id': server.get('id'),
                        'server_name': server.get('name'),
                        'error': str(e)
                    })

        # Calculate summary
        successful = sum(1 for r in results if r.get('success'))
        total_packages = sum(len(r.get('packages', [])) for r in results if r.get('success'))
        total_services = sum(len(r.get('services', [])) for r in results if r.get('success'))
        total_updates = sum(len(r.get('updates', [])) for r in results if r.get('success'))

        return jsonify({
            'success': True,
            'summary': {
                'total_servers': len(target_servers),
                'successful': successful,
                'failed': len(target_servers) - successful,
                'total_packages': total_packages,
                'total_services': total_services,
                'pending_updates': total_updates
            },
            'results': results,
            'errors': errors
        })

    except Exception as e:
        logger.error(f"Fleet discovery error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/fleet/inventory')
@require_api_key
def get_fleet_inventory():
    """
    Get aggregated fleet-wide inventory from latest discovery results.

    Provides a centralized view of all software and services across the fleet.

    Query Parameters:
        group_by (str): Group by 'software', 'service', or 'server' (default 'software')
        filter (str): Filter results by name pattern

    Returns:
        JSON response with aggregated inventory data
    """
    try:
        group_by = request.args.get('group_by', 'software')
        name_filter = request.args.get('filter', '').lower()

        # Get all servers
        all_servers = server_manager.load_servers()

        # Collect latest results for each server
        inventory = {
            'software': {},  # package_name -> [server_ids]
            'services': {},  # service_name -> [server_ids]
            'os_versions': {},  # os_name -> [server_ids]
            'update_status': {},  # server_id -> update_count
            'servers': {}  # server_id -> server_summary
        }

        for server in all_servers:
            server_id = server.get('id')
            server_name = server.get('name')

            # Get latest discovery result
            result = discovery_manager.get_latest_result_by_server(server_id)

            if not result:
                continue

            result_data = result.to_dict()

            # OS version tracking
            os_info = result_data.get('os_info', {})
            os_name = os_info.get('distro_name') or os_info.get('os_name') or 'unknown'
            os_version = os_info.get('distro_version') or os_info.get('version') or ''
            os_key = f"{os_name} {os_version}".strip()

            if os_key not in inventory['os_versions']:
                inventory['os_versions'][os_key] = []
            inventory['os_versions'][os_key].append({
                'server_id': server_id,
                'server_name': server_name
            })

            # Software/package tracking
            for pkg in result_data.get('packages', []):
                name = pkg.get('name', '') if isinstance(pkg, dict) else str(pkg)
                if name_filter and name_filter not in name.lower():
                    continue

                if name not in inventory['software']:
                    inventory['software'][name] = []

                version = pkg.get('version', '') if isinstance(pkg, dict) else ''
                inventory['software'][name].append({
                    'server_id': server_id,
                    'server_name': server_name,
                    'version': version
                })

            # Service tracking
            for svc in result_data.get('services', []):
                name = svc.get('name', '') if isinstance(svc, dict) else str(svc)
                if name_filter and name_filter not in name.lower():
                    continue

                if name not in inventory['services']:
                    inventory['services'][name] = []

                status = svc.get('status', 'unknown') if isinstance(svc, dict) else 'running'
                inventory['services'][name].append({
                    'server_id': server_id,
                    'server_name': server_name,
                    'status': status
                })

            # Update status
            updates = result_data.get('updates', [])
            inventory['update_status'][server_id] = {
                'server_name': server_name,
                'pending_updates': len(updates),
                'updates': updates[:10]  # Preview of first 10
            }

            # Per-server summary
            inventory['servers'][server_id] = {
                'server_name': server_name,
                'hostname': server.get('hostname'),
                'os': os_key,
                'package_count': len(result_data.get('packages', [])),
                'service_count': len(result_data.get('services', [])),
                'pending_updates': len(updates),
                'last_discovery': result_data.get('timestamp'),
                'recommendations': result_data.get('recommendations', [])[:5]
            }

        # Calculate statistics
        stats = {
            'total_servers': len(all_servers),
            'discovered_servers': len(inventory['servers']),
            'unique_packages': len(inventory['software']),
            'unique_services': len(inventory['services']),
            'os_distribution': {k: len(v) for k, v in inventory['os_versions'].items()},
            'servers_needing_updates': sum(
                1 for v in inventory['update_status'].values()
                if v.get('pending_updates', 0) > 0
            ),
            'total_pending_updates': sum(
                v.get('pending_updates', 0) for v in inventory['update_status'].values()
            )
        }

        return jsonify({
            'success': True,
            'statistics': stats,
            'inventory': inventory,
            'group_by': group_by
        })

    except Exception as e:
        logger.error(f"Fleet inventory error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/fleet/compare')
@require_api_key
def compare_fleet_configurations():
    """
    Compare configurations across servers to identify drift.

    Query Parameters:
        package (str): Compare specific package versions across servers
        service (str): Compare specific service status across servers

    Returns:
        JSON response with configuration comparison
    """
    try:
        package_name = request.args.get('package', '').lower()
        service_name = request.args.get('service', '').lower()

        if not package_name and not service_name:
            return jsonify({
                'success': False,
                'error': 'Specify either package or service query parameter'
            }), 400

        all_servers = server_manager.load_servers()
        comparison = {
            'query': {
                'package': package_name or None,
                'service': service_name or None
            },
            'results': [],
            'analysis': {}
        }

        versions = {}
        statuses = {}

        for server in all_servers:
            server_id = server.get('id')
            server_name = server.get('name')

            result = discovery_manager.get_latest_result_by_server(server_id)
            if not result:
                comparison['results'].append({
                    'server_id': server_id,
                    'server_name': server_name,
                    'found': False,
                    'error': 'No discovery data'
                })
                continue

            result_data = result.to_dict()

            # Package comparison
            if package_name:
                found = False
                for pkg in result_data.get('packages', []):
                    name = pkg.get('name', '') if isinstance(pkg, dict) else str(pkg)
                    if package_name in name.lower():
                        version = pkg.get('version', 'unknown') if isinstance(pkg, dict) else 'unknown'
                        comparison['results'].append({
                            'server_id': server_id,
                            'server_name': server_name,
                            'found': True,
                            'package': name,
                            'version': version
                        })

                        if version not in versions:
                            versions[version] = []
                        versions[version].append(server_name)
                        found = True
                        break

                if not found:
                    comparison['results'].append({
                        'server_id': server_id,
                        'server_name': server_name,
                        'found': False,
                        'package': package_name
                    })

            # Service comparison
            if service_name:
                found = False
                for svc in result_data.get('services', []):
                    name = svc.get('name', '') if isinstance(svc, dict) else str(svc)
                    if service_name in name.lower():
                        status = svc.get('status', 'unknown') if isinstance(svc, dict) else 'running'
                        comparison['results'].append({
                            'server_id': server_id,
                            'server_name': server_name,
                            'found': True,
                            'service': name,
                            'status': status
                        })

                        if status not in statuses:
                            statuses[status] = []
                        statuses[status].append(server_name)
                        found = True
                        break

                if not found:
                    comparison['results'].append({
                        'server_id': server_id,
                        'server_name': server_name,
                        'found': False,
                        'service': service_name
                    })

        # Drift analysis
        found_count = sum(1 for r in comparison['results'] if r.get('found'))
        not_found_count = len(comparison['results']) - found_count

        if package_name:
            is_consistent = len(versions) <= 1
            comparison['analysis'] = {
                'type': 'package',
                'query': package_name,
                'total_servers': len(comparison['results']),
                'found_on': found_count,
                'not_found_on': not_found_count,
                'version_distribution': versions,
                'is_consistent': is_consistent,
                'drift_detected': not is_consistent and len(versions) > 1,
                'recommendation': (
                    'All servers running the same version'
                    if is_consistent else
                    f'Version drift detected: {len(versions)} different versions found'
                )
            }
        else:
            is_consistent = len(statuses) <= 1
            comparison['analysis'] = {
                'type': 'service',
                'query': service_name,
                'total_servers': len(comparison['results']),
                'found_on': found_count,
                'not_found_on': not_found_count,
                'status_distribution': statuses,
                'is_consistent': is_consistent,
                'drift_detected': not is_consistent and len(statuses) > 1,
                'recommendation': (
                    'Service status consistent across all servers'
                    if is_consistent else
                    f'Status inconsistency detected: {len(statuses)} different states'
                )
            }

        return jsonify({
            'success': True,
            'comparison': comparison
        })

    except Exception as e:
        logger.error(f"Fleet comparison error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@discovery_bp.route('/api/discovery/fleet/recommendations')
@require_api_key
def get_fleet_recommendations():
    """
    Get consolidated audit recommendations across the fleet.

    Returns prioritized recommendations based on software detected across all servers.

    Returns:
        JSON response with fleet-wide recommendations
    """
    try:
        all_servers = server_manager.load_servers()

        # Aggregate all recommendations
        recommendation_counts = {}  # audit_id -> {count, servers, details}

        for server in all_servers:
            server_id = server.get('id')
            server_name = server.get('name')

            result = discovery_manager.get_latest_result_by_server(server_id)
            if not result:
                continue

            result_data = result.to_dict()

            for rec in result_data.get('recommendations', []):
                audit_id = rec.get('audit_id')
                if not audit_id:
                    continue

                if audit_id not in recommendation_counts:
                    recommendation_counts[audit_id] = {
                        'name': rec.get('name'),
                        'description': rec.get('description'),
                        'audit_id': audit_id,
                        'count': 0,
                        'servers': []
                    }

                recommendation_counts[audit_id]['count'] += 1
                recommendation_counts[audit_id]['servers'].append({
                    'server_id': server_id,
                    'server_name': server_name
                })

        # Sort by count (most common first)
        sorted_recommendations = sorted(
            recommendation_counts.values(),
            key=lambda x: x['count'],
            reverse=True
        )

        # Categorize by priority
        high_priority = [r for r in sorted_recommendations if r['count'] >= len(all_servers) * 0.5]
        medium_priority = [r for r in sorted_recommendations if len(all_servers) * 0.2 <= r['count'] < len(all_servers) * 0.5]
        low_priority = [r for r in sorted_recommendations if r['count'] < len(all_servers) * 0.2]

        return jsonify({
            'success': True,
            'total_servers': len(all_servers),
            'recommendations': {
                'high_priority': high_priority,
                'medium_priority': medium_priority,
                'low_priority': low_priority
            },
            'summary': {
                'total_recommendations': len(sorted_recommendations),
                'high_priority_count': len(high_priority),
                'medium_priority_count': len(medium_priority),
                'low_priority_count': len(low_priority)
            }
        })

    except Exception as e:
        logger.error(f"Fleet recommendations error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
