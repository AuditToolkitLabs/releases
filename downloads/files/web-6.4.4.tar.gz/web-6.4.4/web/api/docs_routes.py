#!/usr/bin/env python3
"""
API Documentation Routes

Serves Swagger UI and API documentation pages.
Also serves panel help documentation from the docs/ folder.
"""

from flask import Blueprint, render_template, send_from_directory, jsonify
from pathlib import Path
import markdown
import re

# Create blueprint
docs_bp = Blueprint('docs', __name__)

# Mapping of panel IDs to documentation files
PANEL_DOCS = {
    'home': '00-overview.md',
    'wizard': 'DEPLOYMENT-GUIDE.md',
    'audits': '04-audit-authoring.md',
    'discovery': 'discovery-tools.md',
    'execution': '11-orchestrator-examples.md',
    'logs': 'MONITORING.md',
    'reports': 'ENHANCED-REPORTING.md',
    'deploy': '16-deploy-panel-guide.md',
    'history': 'advanced-usage-examples.md',
    'schedule': 'AUDIT-SCHEDULING.md',
    'plans': 'advanced-usage-examples.md',
    'connect': 'TARGET-HOST-REQUIREMENTS.md',
    'admin': 'admin-guide.md',
    'elevation-methods': 'elevation-methods.md',
    'least-privilege': '10-least-privilege-integration.md',
    'hypervisors': '20-hypervisors-guide.md',
}

@docs_bp.route('/api/docs')
@docs_bp.route('/docs')
def api_docs():
    """
    Serve Swagger UI for interactive API documentation

    No authentication required - documentation is public
    """
    return render_template('api_docs.html')

@docs_bp.route('/static/openapi.yaml')
def openapi_spec():
    """Serve OpenAPI specification file"""
    return send_from_directory(
        'static', 'openapi.yaml', mimetype='application/yaml'
    )


@docs_bp.route('/api/openapi.json')
def openapi_spec_json():
    """
    Serve OpenAPI specification as JSON

    Converts the YAML spec to JSON format for compatibility
    with tools that prefer JSON.
    """
    import yaml
    from pathlib import Path

    yaml_path = Path(__file__).parent.parent / 'static' / 'openapi.yaml'

    try:
        with open(yaml_path, 'r', encoding='utf-8') as f:
            spec = yaml.safe_load(f)
        return jsonify(spec)
    except FileNotFoundError:
        return jsonify({'error': 'OpenAPI specification not found'}), 404
    except Exception as e:
        return jsonify({'error': f'Failed to load OpenAPI spec: {str(e)}'}), 500


@docs_bp.route('/api/help/<panel_id>')
def panel_help(panel_id):
    """
    Serve help documentation for a specific panel.

    Args:
        panel_id: The panel identifier (e.g., 'deploy', 'audits', 'connect')

    Returns:
        JSON response with title, content (HTML), and source file name
    """
    # Get the doc file for this panel
    doc_file = PANEL_DOCS.get(panel_id)
    if not doc_file:
        return jsonify({
            'error': f'No documentation found for panel: {panel_id}',
            'available': list(PANEL_DOCS.keys())
        }), 404

    # Build path to docs folder (relative to web/)
    docs_path = Path(__file__).parent.parent.parent / 'docs' / doc_file

    if not docs_path.exists():
        return jsonify({
            'error': f'Documentation file not found: {doc_file}',
            'path': str(docs_path)
        }), 404

    try:
        # Read markdown content
        md_content = docs_path.read_text(encoding='utf-8')

        # Extract title from first H1 heading
        title_match = re.search(r'^#\s+(.+)$', md_content, re.MULTILINE)
        title = title_match.group(1) if title_match else doc_file

        # Convert markdown to HTML
        html_content = markdown.markdown(
            md_content,
            extensions=['tables', 'fenced_code', 'codehilite', 'toc']
        )

        return jsonify({
            'title': title,
            'content': html_content,
            'source': doc_file,
            'panel': panel_id
        })
    except Exception as e:
        return jsonify({
            'error': f'Failed to read documentation: {str(e)}'
        }), 500


@docs_bp.route('/api/help')
def list_help_topics():
    """List all available help topics and their documentation files."""
    return jsonify({
        'topics': PANEL_DOCS,
        'count': len(PANEL_DOCS)
    })


def register_docs_routes(app):
    """
    Register documentation routes with Flask app

    Usage:
        from api.docs_routes import register_docs_routes
        register_docs_routes(app)
    """
    app.register_blueprint(docs_bp)


__all__ = ['docs_bp', 'register_docs_routes']
