"""
Enhanced Reporting API Routes for Security Audit Toolkit

Provides endpoints for:
- PDF report generation and export
- Executive summaries
- Compliance framework mapping
- Scheduled report generation
"""

import base64
import logging
from datetime import datetime
from typing import Any

from flask import Blueprint, jsonify, request

from auth_core import require_api_key, conditional_limit

logger = logging.getLogger(__name__)

# Create blueprint
enhanced_report_bp = Blueprint('enhanced_reports', __name__)

# Lazy imports for optional dependencies
_pdf_available = None
_PDFReportGenerator = None
_ComplianceTemplates = None
_ComplianceFramework = None
_ExecutiveSummaryGenerator = None


def _load_pdf_module():
    """Lazy load PDF generation module."""
    global _pdf_available, _PDFReportGenerator
    if _pdf_available is None:
        try:
            from reports.pdf_generator import PDFReportGenerator, is_pdf_available
            _PDFReportGenerator = PDFReportGenerator
            _pdf_available = is_pdf_available()
        except ImportError:
            _pdf_available = False
    return _pdf_available


def _load_compliance_module():
    """Lazy load compliance templates module."""
    global _ComplianceTemplates, _ComplianceFramework
    if _ComplianceTemplates is None:
        try:
            from reports.compliance_templates import ComplianceTemplates, ComplianceFramework
            _ComplianceTemplates = ComplianceTemplates
            _ComplianceFramework = ComplianceFramework
        except ImportError:
            pass
    return _ComplianceTemplates is not None


def _load_executive_module():
    """Lazy load executive summary module."""
    global _ExecutiveSummaryGenerator
    if _ExecutiveSummaryGenerator is None:
        try:
            from reports.executive_summary import ExecutiveSummaryGenerator
            _ExecutiveSummaryGenerator = ExecutiveSummaryGenerator
        except ImportError:
            pass
    return _ExecutiveSummaryGenerator is not None


# ============================================================================
# PDF Export Endpoints
# ============================================================================

@enhanced_report_bp.route('/api/reports/export/pdf', methods=['POST'])
@require_api_key
@conditional_limit("20 per hour")
def export_pdf():
    """
    Export audit report as PDF.

    Request body:
    {
        "report": {...},  // Report data from /api/reports/generate
        "options": {
            "compliance_framework": "pci-dss",  // Optional: pci-dss, soc2, iso27001
            "organization": "Company Name",
            "classification": "Confidential",
            "include_executive_summary": true,
            "include_compliance_mapping": true
        }
    }

    Returns: PDF as base64-encoded content or error message
    """
    if not _load_pdf_module():
        return jsonify({
            "success": False,
            "error": "PDF generation not available. Install weasyprint: pip install weasyprint"
        }), 501

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        report = data.get("report")
        if not report:
            return jsonify({"success": False, "error": "No report data provided"}), 400

        options = data.get("options", {})

        # Load compliance mapping if requested
        compliance_mapping = None
        compliance_framework = None
        recommendations = None

        if options.get("include_compliance_mapping") and _load_compliance_module():
            framework_id = options.get("compliance_framework", "").lower()
            framework_map = {
                "pci-dss": _ComplianceFramework.PCI_DSS,
                "soc2": _ComplianceFramework.SOC2,
                "iso27001": _ComplianceFramework.ISO27001,
                "nist-csf": _ComplianceFramework.NIST_CSF,
                "cis": _ComplianceFramework.CIS_CONTROLS
            }

            if framework_id in framework_map:
                framework = framework_map[framework_id]
                compliance_framework = framework.value

                # Extract audit check names from report (mock mapping)
                audit_results = _extract_audit_results(report)
                compliance_mapping = _ComplianceTemplates.map_audit_to_controls(
                    framework, audit_results
                )
                recommendations = _ComplianceTemplates.get_recommendations(
                    compliance_mapping
                )

        # Generate executive summary if requested
        executive_summary = None
        if options.get("include_executive_summary") and _load_executive_module():
            generator = _ExecutiveSummaryGenerator(
                organization=options.get("organization"),
                industry=options.get("industry", "default")
            )
            summary_data = generator.generate_summary(
                report, compliance_framework
            )
            executive_summary = summary_data["narrative"]["opening"]

        # Generate PDF
        pdf_generator = _PDFReportGenerator()
        pdf_content = pdf_generator.generate_pdf(
            report_data=report,
            compliance_framework=compliance_framework,
            compliance_mapping=_convert_mappings_to_dict(compliance_mapping),
            recommendations=recommendations,
            organization=options.get("organization"),
            classification=options.get("classification", "Confidential"),
            executive_summary=executive_summary
        )

        # Generate filename
        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        filename = f"security-audit-report-{timestamp}.pdf"

        return jsonify({
            "success": True,
            "filename": filename,
            "content": base64.b64encode(pdf_content).decode('utf-8'),
            "mime_type": "application/pdf",
            "size_bytes": len(pdf_content)
        })

    except Exception as e:
        logger.error(f"Error generating PDF: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@enhanced_report_bp.route('/api/reports/pdf/capabilities', methods=['GET'])
@require_api_key
def get_pdf_capabilities():
    """Get PDF generation capabilities and available options."""
    pdf_available = _load_pdf_module()
    compliance_available = _load_compliance_module()
    executive_available = _load_executive_module()

    capabilities = {
        "pdf_export": pdf_available,
        "compliance_mapping": compliance_available,
        "executive_summary": executive_available,
        "available_frameworks": [],
        "installation_guide": None
    }

    if not pdf_available:
        capabilities["installation_guide"] = (
            "PDF generation requires WeasyPrint. Install with: "
            "pip install weasyprint. "
            "System dependencies (Cairo, Pango) may also be required. "
            "See docs/ENHANCED-REPORTING.md for details."
        )

    if compliance_available:
        capabilities["available_frameworks"] = _ComplianceTemplates.get_available_frameworks()

    return jsonify(capabilities)


# ============================================================================
# Executive Summary Endpoints
# ============================================================================

@enhanced_report_bp.route('/api/reports/executive-summary', methods=['POST'])
@require_api_key
@conditional_limit("30 per hour")
def generate_executive_summary():
    """
    Generate executive summary from audit report.

    Request body:
    {
        "report": {...},  // Report data from /api/reports/generate
        "organization": "Company Name",
        "industry": "technology",  // Optional: for benchmarking
        "compliance_framework": "pci-dss",  // Optional
        "previous_report": {...}  // Optional: for trend analysis
    }

    Returns: Executive summary with key findings, recommendations, and narrative
    """
    if not _load_executive_module():
        return jsonify({
            "success": False,
            "error": "Executive summary module not available"
        }), 501

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        report = data.get("report")
        if not report:
            return jsonify({"success": False, "error": "No report data provided"}), 400

        generator = _ExecutiveSummaryGenerator(
            organization=data.get("organization"),
            industry=data.get("industry", "default")
        )

        summary = generator.generate_summary(
            report_data=report,
            compliance_framework=data.get("compliance_framework"),
            previous_data=data.get("previous_report", {}).get("summary")
        )

        return jsonify({
            "success": True,
            "executive_summary": summary
        })

    except Exception as e:
        logger.error(f"Error generating executive summary: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@enhanced_report_bp.route('/api/reports/executive-summary/text', methods=['POST'])
@require_api_key
@conditional_limit("30 per hour")
def generate_text_summary():
    """
    Generate one-page text summary for quick review.

    Returns: Plain text executive summary
    """
    if not _load_executive_module():
        return jsonify({
            "success": False,
            "error": "Executive summary module not available"
        }), 501

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        report = data.get("report")
        if not report:
            return jsonify({"success": False, "error": "No report data provided"}), 400

        generator = _ExecutiveSummaryGenerator(
            organization=data.get("organization"),
            industry=data.get("industry", "default")
        )

        text_summary = generator.generate_one_page_summary(report)

        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        filename = f"executive-summary-{timestamp}.txt"

        return jsonify({
            "success": True,
            "filename": filename,
            "content": text_summary,
            "mime_type": "text/plain"
        })

    except Exception as e:
        logger.error(f"Error generating text summary: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Compliance Framework Endpoints
# ============================================================================

@enhanced_report_bp.route('/api/reports/compliance/frameworks', methods=['GET'])
@require_api_key
def list_compliance_frameworks():
    """List available compliance frameworks."""
    if not _load_compliance_module():
        return jsonify({
            "success": False,
            "error": "Compliance module not available"
        }), 501

    return jsonify({
        "success": True,
        "frameworks": _ComplianceTemplates.get_available_frameworks()
    })


@enhanced_report_bp.route('/api/reports/compliance/map', methods=['POST'])
@require_api_key
@conditional_limit("30 per hour")
def map_compliance():
    """
    Map audit results to compliance framework controls.

    Request body:
    {
        "report": {...},  // Report data from /api/reports/generate
        "framework": "pci-dss"  // pci-dss, soc2, iso27001, nist-csf, cis
    }

    Returns: Control mapping with status and recommendations
    """
    if not _load_compliance_module():
        return jsonify({
            "success": False,
            "error": "Compliance module not available"
        }), 501

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        report = data.get("report")
        framework_id = data.get("framework", "").lower()

        if not report:
            return jsonify({"success": False, "error": "No report data provided"}), 400

        framework_map = {
            "pci-dss": _ComplianceFramework.PCI_DSS,
            "soc2": _ComplianceFramework.SOC2,
            "iso27001": _ComplianceFramework.ISO27001,
            "nist-csf": _ComplianceFramework.NIST_CSF,
            "cis": _ComplianceFramework.CIS_CONTROLS
        }

        if framework_id not in framework_map:
            return jsonify({
                "success": False,
                "error": f"Unknown framework: {framework_id}. Valid options: {list(framework_map.keys())}"
            }), 400

        framework = framework_map[framework_id]

        # Extract audit results from report
        audit_results = _extract_audit_results(report)

        # Map to controls
        control_mapping = _ComplianceTemplates.map_audit_to_controls(
            framework, audit_results
        )

        # Calculate score
        compliance_score = _ComplianceTemplates.calculate_compliance_score(
            control_mapping
        )

        # Get recommendations
        recommendations = _ComplianceTemplates.get_recommendations(
            control_mapping
        )

        return jsonify({
            "success": True,
            "framework": framework.value,
            "compliance_score": compliance_score,
            "control_mapping": _convert_mappings_to_dict(control_mapping),
            "recommendations": recommendations
        })

    except Exception as e:
        logger.error(f"Error mapping compliance: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Helper Functions
# ============================================================================

def _extract_audit_results(report: dict) -> dict[str, str]:
    """
    Extract audit check results from report data.

    Maps server metrics to standardized check names for compliance mapping.
    """
    audit_results = {}

    # Map common metrics to audit check names
    for server in report.get("servers", []):
        if server.get("status") != "success":
            continue

        metrics = server.get("metrics", {})
        total = metrics.get("total", 0)
        passed = metrics.get("pass", 0)
        failed = metrics.get("fail", 0)
        warn = metrics.get("warn", 0)

        if total == 0:
            continue

        pass_ratio = passed / total

        # Map to generalized check categories based on pass ratio
        # In a real implementation, this would parse specific check results

        # Security baseline checks
        if pass_ratio >= 0.9:
            audit_results.update({
                "baseline_config": "pass",
                "hardening_applied": "pass",
                "security_controls": "pass"
            })
        elif pass_ratio >= 0.7:
            audit_results.update({
                "baseline_config": "warn",
                "hardening_applied": "warn",
                "security_controls": "warn"
            })
        else:
            audit_results.update({
                "baseline_config": "fail",
                "hardening_applied": "fail",
                "security_controls": "fail"
            })

        # Authentication checks (assumes some passed if any checks passed)
        if passed > 0:
            audit_results["auth_config"] = "pass"
            audit_results["password_policy"] = "pass" if pass_ratio >= 0.8 else "warn"

        # Firewall/network checks
        if failed == 0:
            audit_results["firewall_active"] = "pass"
            audit_results["network_segmentation"] = "pass"
        elif failed < total * 0.2:
            audit_results["firewall_active"] = "warn"
            audit_results["network_segmentation"] = "warn"
        else:
            audit_results["firewall_active"] = "fail"
            audit_results["network_segmentation"] = "fail"

        # Logging checks
        audit_results["audit_logging"] = "pass" if pass_ratio >= 0.7 else "warn"
        audit_results["log_config"] = "pass" if pass_ratio >= 0.7 else "warn"

        # Access control
        audit_results["access_controls"] = "pass" if pass_ratio >= 0.8 else "warn"
        audit_results["rbac_enabled"] = "pass" if pass_ratio >= 0.8 else "warn"

    return audit_results


def _convert_mappings_to_dict(control_mapping: dict | None) -> dict | None:
    """Convert ControlMapping objects to dictionaries for JSON serialization."""
    if not control_mapping:
        return None

    result = {}
    for category, controls in control_mapping.items():
        result[category] = []
        for control in controls:
            result[category].append({
                "id": control.id,
                "name": control.name,
                "description": control.description,
                "status": control.status,
                "evidence": control.evidence,
                "audit_checks": control.audit_checks
            })
    return result
