"""
Microsoft Entra ID (Azure AD) SSO Routes

Provides OAuth 2.0 / OIDC endpoints for Microsoft Entra ID authentication:
- GET /auth/sso/entra/login - Initiate SSO login
- GET /auth/sso/entra/callback - OAuth callback handler
- GET /auth/sso/entra/logout - SSO logout
- GET /api/admin/sso/entra/status - Admin: Get Entra status
- POST /api/admin/sso/entra/test - Admin: Test Entra configuration

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import secrets
from datetime import datetime
from urllib.parse import urlparse, urljoin

from flask import (
    Blueprint,
    current_app,
    jsonify,
    redirect,
    request,
    session,
    url_for,
)
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy.orm import Session as DBSession

logger = logging.getLogger(__name__)

# Entra Authentication support
try:
    from auth.entra_auth import (
        EntraAuth,
        EntraAuthError,
        EntraTokenError,
        EntraGraphError,
        EntraUser,
        get_entra_auth,
        entra_enabled,
    )

    ENTRA_AVAILABLE = True
except ImportError:
    ENTRA_AVAILABLE = False
    EntraAuth = None
    EntraUser = None
    EntraAuthError = None
    EntraTokenError = None
    EntraGraphError = None
    get_entra_auth = lambda: None
    entra_enabled = lambda: False

# Blueprints
sso_bp = Blueprint("sso", __name__, url_prefix="/auth/sso")
entra_admin_bp = Blueprint("entra_admin", __name__, url_prefix="/api/admin/sso/entra")


# =============================================================================
# SSO Session Keys
# =============================================================================
SSO_STATE_KEY = "sso_state"
SSO_NEXT_KEY = "sso_next_url"


# =============================================================================
# Helper Functions
# =============================================================================


def is_safe_url(target):
    """
    Validate that redirect URL is safe (same origin).
    Prevents open redirect attacks.
    """
    if not target:
        return False
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return (
        test_url.scheme in ('http', 'https') and
        ref_url.netloc == test_url.netloc
    )


def _get_db() -> DBSession:
    """Get database session from Flask g object"""
    from flask import g

    return g.db


def _is_admin() -> bool:
    """Check if current user is admin or superadmin (hierarchy-aware)"""
    if not current_user.is_authenticated:
        return False
    return current_user.has_role('Admin')


def _jit_provision_entra_user(entra_user: EntraUser, db: DBSession):
    """
    Just-in-time provision or update user from Entra ID.

    Args:
        entra_user: User info from Entra ID
        db: Database session

    Returns:
        User model instance
    """
    from models.user import User

    # Look for existing user by external_id (Azure AD object ID) or username
    user = db.query(User).filter(
        (User.external_id == entra_user.external_id)
        | (User.username == entra_user.username)
    ).first()

    if user:
        # Update existing user
        if user.auth_provider == "local":
            # First SSO login for existing local user
            user.auth_provider = "entra"
            user.external_id = entra_user.external_id
            logger.info(f"Converted local user {user.username} to Entra auth")
        elif user.auth_provider not in ("entra", "local"):
            # User is managed by different provider
            raise EntraAuthError(
                "Account is managed by a different authentication provider"
            )

        # Update user info
        if entra_user.email:
            user.email = entra_user.email
        if entra_user.display_name:
            user.display_name = entra_user.display_name

        # Update role based on Entra groups
        if entra_user.role != user.role:
            logger.info(
                f"Updating role for {entra_user.username}: {user.role} -> {entra_user.role}"
            )
            user.role = entra_user.role

        user.last_login = datetime.utcnow()
    else:
        # JIT provision new user
        user = User(
            username=entra_user.username,
            email=entra_user.email,
            display_name=entra_user.display_name or entra_user.username,
            role=entra_user.role,
            auth_provider="entra",
            external_id=entra_user.external_id,
            is_active=True,
            must_change_password=False,  # SSO users don't have local passwords
            last_login=datetime.utcnow(),
        )
        # Set a random unusable password for SSO users
        user.set_password(secrets.token_urlsafe(32))
        db.add(user)
        logger.info(
            f"JIT provisioned Entra user: {entra_user.username} with role {entra_user.role}"
        )

    db.commit()
    return user


def _log_auth_event(
    db: DBSession, event_type: str, user_id: int = None, details: dict = None
):
    """Log authentication event to audit log"""
    try:
        from models.user import AuthAuditLog

        log = AuthAuditLog(
            user_id=user_id,
            event_type=event_type,
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string[:500] if request.user_agent else None,
            details=details,
            timestamp=datetime.utcnow(),
        )
        db.add(log)
        db.commit()
    except Exception as e:
        logger.warning(f"Failed to log auth event: {e}")


# =============================================================================
# SSO Routes
# =============================================================================


@sso_bp.route("/entra/login")
def entra_login():
    """
    Initiate Microsoft Entra ID SSO login.

    Query Parameters:
        next: Optional redirect URL after successful login

    Redirects to Microsoft login page.
    """
    entra = get_entra_auth()
    if not entra or not entra.enabled:
        return jsonify({
            "success": False,
            "error": "Entra ID authentication is not enabled",
        }), 400

    # Generate and store state for CSRF protection
    state = secrets.token_urlsafe(32)
    session[SSO_STATE_KEY] = state

    # Store next URL for post-login redirect (validate to prevent open redirect)
    next_url = request.args.get("next")
    if next_url and is_safe_url(next_url):
        session[SSO_NEXT_KEY] = next_url

    # Get Microsoft login URL
    auth_url = entra.get_auth_url(state=state)

    logger.debug(f"Redirecting to Entra login, state: {state[:8]}...")
    return redirect(auth_url)


@sso_bp.route("/entra/callback")
def entra_callback():
    """
    Handle OAuth callback from Microsoft.

    Query Parameters:
        code: Authorization code from Microsoft
        state: State parameter for CSRF validation
        error: Error code if authorization failed
        error_description: Error description if authorization failed

    Redirects to dashboard on success, or login page on failure.
    """
    # Check for error from Microsoft
    error = request.args.get("error")
    if error:
        error_desc = request.args.get("error_description", error)
        logger.error(f"Entra auth error: {error} - {error_desc}")
        return redirect(url_for("auth.login", error="sso_failed"))

    # Validate state (CSRF protection)
    state = request.args.get("state")
    expected_state = session.pop(SSO_STATE_KEY, None)

    if not state or state != expected_state:
        logger.warning("Entra callback: state mismatch (possible CSRF)")
        return redirect(url_for("auth.login", error="sso_invalid_state"))

    # Get authorization code
    code = request.args.get("code")
    if not code:
        logger.warning("Entra callback: missing authorization code")
        return redirect(url_for("auth.login", error="sso_no_code"))

    entra = get_entra_auth()
    if not entra or not entra.enabled:
        return redirect(url_for("auth.login", error="sso_not_configured"))

    try:
        # Exchange code for tokens and get user info
        entra_user = entra.handle_callback(code)

        # JIT provision or update user
        db = _get_db()
        user = _jit_provision_entra_user(entra_user, db)

        # Check if user is active
        if not user.is_active:
            logger.warning(f"Entra login blocked: user {user.username} is disabled")
            _log_auth_event(
                db,
                "sso_login_blocked",
                user.id,
                {"reason": "user_disabled", "provider": "entra"},
            )
            return redirect(url_for("auth.login", error="account_disabled"))

        # Check if MFA is required (MFA not handled by Entra)
        if user.mfa_enabled:
            session["mfa_pending_user_id"] = user.id
            session["mfa_provider"] = "entra"
            return redirect(url_for("auth.mfa_verify"))

        # Login successful
        login_user(user, remember=True)
        _log_auth_event(db, "sso_login_success", user.id, {"provider": "entra"})

        logger.info(
            f"Entra SSO login successful: {user.username} (role: {user.role})"
        )

        # Redirect to next URL or dashboard
        next_url = session.pop(SSO_NEXT_KEY, None)
        return redirect(next_url or url_for("dashboard.index"))

    except EntraTokenError as e:
        logger.error(f"Entra token error: {e}")
        return redirect(url_for("auth.login", error="sso_token_error"))

    except EntraGraphError as e:
        logger.error(f"Entra Graph error: {e}")
        return redirect(url_for("auth.login", error="sso_graph_error"))

    except EntraAuthError as e:
        logger.error(f"Entra auth error: {e}")
        return redirect(url_for("auth.login", error="sso_failed"))

    except Exception as e:
        logger.exception(f"Unexpected Entra callback error: {e}")
        return redirect(url_for("auth.login", error="sso_unexpected_error"))


@sso_bp.route("/entra/logout")
@login_required
def entra_logout():
    """
    Logout from both application and Entra ID.

    This performs single logout - logs out from the app
    and redirects to Microsoft to end the SSO session.
    """
    entra = get_entra_auth()

    # Log the logout event
    db = _get_db()
    _log_auth_event(db, "sso_logout", current_user.id, {"provider": "entra"})

    # Logout from Flask
    logout_user()
    session.clear()

    # If Entra is enabled and user was using SSO, redirect to MS logout
    if entra and entra.enabled and current_user.auth_provider == "entra":
        post_logout_uri = url_for("auth.login", _external=True)
        return redirect(entra.get_logout_url(post_logout_redirect_uri=post_logout_uri))

    # Otherwise just redirect to local login
    return redirect(url_for("auth.login"))


# =============================================================================
# Admin Routes
# =============================================================================


@entra_admin_bp.route("/status", methods=["GET"])
@login_required
def get_entra_status():
    """
    Get Entra ID configuration status.

    Returns configuration and availability info (secrets are masked).
    Requires Admin role.
    """
    if not _is_admin():
        return jsonify({"success": False, "error": "Admin access required"}), 403

    entra = get_entra_auth()

    # Build status response
    status = {
        "entra_available": ENTRA_AVAILABLE,
        "entra_enabled": entra.enabled if entra else False,
        "msal_installed": ENTRA_AVAILABLE,
    }

    if entra:
        config = entra.config
        status["config"] = {
            "tenant_id": config.tenant_id[:8] + "..." if config.tenant_id else None,
            "client_id": config.client_id[:8] + "..." if config.client_id else None,
            "client_secret": "***MASKED***" if config.client_secret else None,
            "redirect_uri": config.redirect_uri,
            "scopes": config.scopes,
            "default_role": config.default_role,
            "allow_local_fallback": config.allow_local_fallback,
            "role_mapping_count": len(config.role_mapping),
        }

        is_valid, errors = config.validate()
        status["config_valid"] = is_valid
        status["config_errors"] = errors

    return jsonify(status)


@entra_admin_bp.route("/test", methods=["POST"])
@login_required
def test_entra_connection():
    """
    Test Entra ID configuration.

    Tests client credentials authentication (app-only) to verify
    the configuration without user interaction.

    Requires Admin role.
    """
    if not _is_admin():
        return jsonify({"success": False, "error": "Admin access required"}), 403

    if not ENTRA_AVAILABLE:
        return jsonify({
            "success": False,
            "error": "msal library not installed",
        }), 400

    entra = get_entra_auth()
    if not entra:
        return jsonify({
            "success": False,
            "error": "Entra authentication not configured",
        }), 400

    # Run configuration test
    test_result = entra.test_configuration()

    return jsonify({
        "success": test_result.get("can_get_app_token", False),
        "test_result": test_result,
    })


@entra_admin_bp.route("/role-mapping", methods=["GET"])
@login_required
def get_role_mapping():
    """
    Get current Entra group-to-role mapping configuration.

    Requires Admin role.
    """
    if not _is_admin():
        return jsonify({"success": False, "error": "Admin access required"}), 403

    entra = get_entra_auth()
    if not entra:
        return jsonify({
            "success": False,
            "error": "Entra authentication not configured",
        }), 400

    return jsonify({
        "role_mapping": entra.config.role_mapping,
        "default_role": entra.config.default_role,
        "valid_roles": ["SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"],
    })


@entra_admin_bp.route("/users", methods=["GET"])
@login_required
def list_entra_users():
    """
    List users who authenticated via Entra ID.

    Requires Admin role.
    """
    if not _is_admin():
        return jsonify({"success": False, "error": "Admin access required"}), 403

    from models.user import User

    db = _get_db()
    users = db.query(User).filter(User.auth_provider == "entra").all()

    return jsonify({
        "count": len(users),
        "users": [
            {
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "display_name": u.display_name,
                "role": u.role,
                "external_id": u.external_id,
                "is_active": u.is_active,
                "last_login": u.last_login.isoformat() if u.last_login else None,
            }
            for u in users
        ],
    })
