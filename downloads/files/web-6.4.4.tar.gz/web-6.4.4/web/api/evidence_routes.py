"""
Compliance Evidence API Routes

Provides endpoints for:
- Collecting compliance evidence from audit executions
- Creating evidence packages for auditors
- Exporting evidence packages to ZIP
- Managing evidence attachments

Premium Feature for Enterprise Compliance

Author: Security Audit Toolkit Team
Date: February 13, 2026
"""

import hashlib
import json
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from flask import Blueprint, jsonify, request, send_file

# Import from config
from config import logger, DATA_ROOT

# Import database session
try:
    from config import SessionLocal
    from models.database import Server
    DATABASE_AVAILABLE = True
    db = SessionLocal() if SessionLocal else None
except ImportError:
    DATABASE_AVAILABLE = False
    SessionLocal = None  # type: ignore
    db = None

# Import auth decorators
from auth_core import (
    require_auth_and_permission,
    require_auth_permission_and_log,
    get_current_user,
    require_role
)
from logging_utils import log_audit

# Import evidence collector
try:
    from reports.evidence_collector import (
        ComplianceEvidenceCollector,
        EvidencePackage,
        EvidenceItem,
        EvidenceType,
        collect_evidence_for_assessment,
        export_evidence_package
    )
    EVIDENCE_COLLECTOR_AVAILABLE = True
except ImportError as e:
    EVIDENCE_COLLECTOR_AVAILABLE = False
    logger.warning(f"Evidence collector not available: {e}")

# Create blueprint
evidence_bp = Blueprint('evidence', __name__)

# Feature licensing (optional — degrades gracefully if service unavailable)
try:
    from services_pkg.services.feature_licensing import Feature, get_feature_service
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False


def _feature_unavailable_response(feature):
    """Return standardised 403 payload when a licensed feature is unavailable, or None if available."""
    if not FEATURE_LICENSING_AVAILABLE:
        return None
    try:
        user_id = None
        try:
            from flask_login import current_user
            if current_user and getattr(current_user, 'is_authenticated', False):
                user_id = str(current_user.id)
        except Exception:
            user_id = None
        service = get_feature_service()
        status = service.is_feature_available(feature, user_id)
    except Exception as exc:
        logger.warning(f"Feature licensing check failed for {getattr(feature, 'value', feature)}: {exc}")
        return None
    if status.get('available'):
        return None
    return jsonify({
        'error': 'Feature not available',
        'feature': feature.value,
        'reason': status.get('reason', 'Feature is not enabled for this license tier'),
        'code': 'FEATURE_UNAVAILABLE',
        'trial_eligible': status.get('trial_eligible', False),
        'upgrade_tier': status.get('upgrade_tier'),
    }), 403

# In-memory storage for packages (replace with database in production)
_evidence_packages: dict[str, EvidencePackage] = {}
EVIDENCE_EXPORTS_DIR = Path(DATA_ROOT) / 'evidence_exports'
EVIDENCE_EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
EVIDENCE_REGISTRY_FILE = EVIDENCE_EXPORTS_DIR / 'registry.json'
_evidence_registry: dict[str, dict[str, Any]] = {}


def _load_registry() -> dict[str, dict[str, Any]]:
    """Load persisted evidence export metadata."""
    if not EVIDENCE_REGISTRY_FILE.exists():
        return {}

    try:
        with open(EVIDENCE_REGISTRY_FILE, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        if isinstance(payload, dict):
            return payload
    except Exception as exc:
        logger.warning(f"Failed to load evidence registry: {exc}")

    return {}


def _save_registry() -> None:
    """Persist evidence export metadata atomically."""
    tmp_path = EVIDENCE_REGISTRY_FILE.with_suffix('.tmp')
    with open(tmp_path, 'w', encoding='utf-8') as f:
        json.dump(_evidence_registry, f, indent=2)
    tmp_path.replace(EVIDENCE_REGISTRY_FILE)


def _register_export(package: EvidencePackage, zip_path: str, exported_by: str) -> None:
    """Record exported package metadata for restart-safe retrieval."""
    manifest_path = EVIDENCE_EXPORTS_DIR / f"manifest-{package.id}.json"
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(package.to_manifest(), f, indent=2)

    _evidence_registry[package.id] = {
        'package_id': package.id,
        'name': package.name,
        'framework': package.framework,
        'organization': package.organization,
        'created_at': package.created_at.isoformat(),
        'signed_at': package.signed_at.isoformat() if package.signed_at else None,
        'checksum': package.package_checksum,
        'items_count': len(package.items),
        'zip_path': str(zip_path),
        'manifest_path': str(manifest_path),
        'exported_at': datetime.utcnow().isoformat(),
        'exported_by': exported_by,
        'last_verified_at': None,
        'last_verified_ok': None
    }
    _save_registry()


def _load_manifest_for_package(package_id: str) -> dict[str, Any] | None:
    """Load package manifest from memory first, then from persisted export metadata."""
    package = _evidence_packages.get(package_id)
    if package is not None:
        return package.to_manifest()

    record = _evidence_registry.get(package_id)
    if not record:
        return None

    manifest_path = record.get('manifest_path')
    if not manifest_path:
        return None

    manifest_file = Path(manifest_path)
    if not manifest_file.exists():
        return None

    try:
        with open(manifest_file, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def _verify_export_archive(zip_path: str) -> dict[str, Any]:
    """Verify integrity of an evidence ZIP using SHA256SUMS and manifest checksum."""
    result: dict[str, Any] = {
        'verified': False,
        'archive_exists': False,
        'checked_files': 0,
        'mismatches': [],
        'manifest_checksum_valid': None,
        'errors': []
    }

    archive = Path(zip_path)
    if not archive.exists():
        result['errors'].append('Archive does not exist')
        return result

    result['archive_exists'] = True

    try:
        with zipfile.ZipFile(archive, 'r') as zf:
            try:
                checksum_lines = zf.read('SHA256SUMS.txt').decode('utf-8').splitlines()
            except KeyError:
                result['errors'].append('SHA256SUMS.txt not found in archive')
                return result

            for line in checksum_lines:
                line = line.strip()
                if not line:
                    continue
                parts = line.split('  ', 1)
                if len(parts) != 2:
                    result['errors'].append(f'Invalid checksum line: {line}')
                    continue

                expected_hash, internal_path = parts[0].strip(), parts[1].strip()
                try:
                    payload = zf.read(internal_path)
                except KeyError:
                    result['mismatches'].append({
                        'path': internal_path,
                        'expected': expected_hash,
                        'actual': None,
                        'error': 'Missing file in archive'
                    })
                    continue

                actual_hash = hashlib.sha256(payload).hexdigest()
                result['checked_files'] += 1
                if actual_hash != expected_hash:
                    result['mismatches'].append({
                        'path': internal_path,
                        'expected': expected_hash,
                        'actual': actual_hash
                    })

            manifest_checksum_valid = None
            try:
                manifest = json.loads(zf.read('MANIFEST.json').decode('utf-8'))
                item_checksums = sorted(
                    item.get('checksum', '')
                    for item in manifest.get('items', [])
                    if isinstance(item, dict) and item.get('checksum')
                )
                combined = '|'.join(item_checksums)
                recomputed = hashlib.sha256(combined.encode('utf-8')).hexdigest()
                declared = manifest.get('integrity', {}).get('package_checksum')
                manifest_checksum_valid = bool(declared) and declared == recomputed
            except Exception as exc:
                result['errors'].append(f'Manifest verification failed: {exc}')

            result['manifest_checksum_valid'] = manifest_checksum_valid

            result['verified'] = (
                len(result['mismatches']) == 0
                and len(result['errors']) == 0
                and manifest_checksum_valid is not False
            )

    except Exception as exc:
        result['errors'].append(f'Archive verification failed: {exc}')

    return result


_evidence_registry = _load_registry()


# ============================================================================
# Evidence Collection Endpoints


@evidence_bp.before_request
def _gate_evidence_feature():
    """Require EVIDENCE_PACKAGER feature for all /api/evidence/* routes."""
    denied = _feature_unavailable_response(Feature.EVIDENCE_PACKAGER)
    if denied:
        return denied
# ============================================================================

@evidence_bp.route('/api/evidence/collect/execution/<int:execution_id>', methods=['POST'])
@require_auth_and_permission('manage_compliance')
@require_role('Analyst')
def collect_from_execution(execution_id: int):
    """
    Collect evidence from a single audit execution (requires Analyst+ role).

    Request Body:
    {
        "framework": "PCI-DSS",  // PCI-DSS, SOC2, ISO27001, NIST-CSF, CIS
        "add_to_package": "pkg-id"  // Optional: add to existing package
    }

    Returns:
        Collected evidence items
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        log_audit(
            action='collect_evidence_from_execution',
            resource_id=str(execution_id),
            resource_type='evidence',
            success=False,
            error='Evidence collector not available'
        )
        return jsonify({'error': 'Evidence collector not available'}), 503

    try:
        data = request.get_json() or {}
        framework = data.get('framework', 'PCI-DSS')
        add_to_package = data.get('add_to_package')

        user = get_current_user()
        username = getattr(user, 'email', None) or str(user) if user else 'unknown'

        collector = ComplianceEvidenceCollector()
        items = collector.collect_from_execution(
            execution_id=execution_id,
            framework=framework,
            collected_by=username
        )

        if not items:
            log_audit(
                action='collect_evidence_from_execution',
                resource_id=str(execution_id),
                resource_type='evidence',
                details={'framework': framework},
                success=False,
                error='No evidence collected'
            )
            return jsonify({
                'success': False,
                'error': f'No evidence collected from execution {execution_id}'
            }), 404

        # Add to existing package if specified
        if add_to_package and add_to_package in _evidence_packages:
            package = _evidence_packages[add_to_package]
            for item in items:
                package.add_item(item)
            package.calculate_package_checksum()

        log_audit(
            action='collect_evidence_from_execution',
            resource_id=str(execution_id),
            resource_type='evidence',
            details={
                'framework': framework,
                'items_collected': len(items),
                'package_id': add_to_package
            },
            success=True
        )

        return jsonify({
            'success': True,
            'items_collected': len(items),
            'items': [item.to_dict() for item in items],
            'package_id': add_to_package if add_to_package in _evidence_packages else None
        })

    except Exception as e:
        logger.error(f"Error collecting evidence: {e}")
        log_audit(
            action='collect_evidence_from_execution',
            resource_id=str(execution_id),
            resource_type='evidence',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/collect/server/<int:server_id>', methods=['POST'])
@require_auth_and_permission('manage_compliance')
@require_role('Analyst')
def collect_from_server(server_id: int):
    """
    Collect all evidence for a server over a time period (requires Analyst+ role).

    Request Body:
    {
        "framework": "PCI-DSS",
        "days": 90,
        "create_package": true  // Auto-create package from collection
    }

    Returns:
        Collected evidence items and optional package info
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        log_audit(
            action='collect_evidence_from_server',
            resource_id=str(server_id),
            resource_type='evidence',
            success=False,
            error='Evidence collector not available'
        )
        return jsonify({'error': 'Evidence collector not available'}), 503

    try:
        data = request.get_json() or {}
        framework = data.get('framework', 'PCI-DSS')
        days = min(data.get('days', 90), 365)
        create_package = data.get('create_package', False)

        user = get_current_user()
        username = getattr(user, 'email', None) or str(user) if user else 'unknown'

        collector = ComplianceEvidenceCollector()
        items = collector.collect_from_server(
            server_id=server_id,
            framework=framework,
            days=days,
            collected_by=username
        )

        result = {
            'success': True,
            'items_collected': len(items),
            'framework': framework,
            'days': days
        }

        if create_package and items:
            package = collector.create_package(
                name=f"{framework} Evidence - Server {server_id}",
                framework=framework,
                items=items,
                period_start=datetime.utcnow() - timedelta(days=days),
                period_end=datetime.utcnow(),
                created_by=username
            )
            package = collector.sign_package(package, signed_by=username)
            _evidence_packages[package.id] = package

            result['package'] = {
                'id': package.id,
                'name': package.name,
                'checksum': package.package_checksum,
                'items_count': len(package.items)
            }

        log_audit(
            action='collect_evidence_from_server',
            resource_id=str(server_id),
            resource_type='evidence',
            details={
                'framework': framework,
                'days': days,
                'items_collected': len(items),
                'package_created': create_package and bool(items)
            },
            success=True
        )

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error collecting evidence from server: {e}")
        log_audit(
            action='collect_evidence_from_server',
            resource_id=str(server_id),
            resource_type='evidence',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/collect/assessment', methods=['POST'])
@require_auth_permission_and_log('manage_compliance', 'Created compliance evidence package')
def create_assessment_package():
    """
    Create a complete evidence package for compliance assessment.

    Request Body:
    {
        "name": "Q1 2026 PCI-DSS Assessment",
        "framework": "PCI-DSS",
        "server_ids": [1, 2, 3],
        "days": 90,
        "organization": "Acme Corp",
        "description": "Quarterly PCI-DSS compliance evidence"
    }

    Returns:
        Complete evidence package metadata
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        return jsonify({'error': 'Evidence collector not available'}), 503

    try:
        data = request.get_json() or {}

        name = data.get('name', f"Evidence Package - {datetime.utcnow().strftime('%Y-%m-%d')}")
        framework = data.get('framework', 'PCI-DSS')
        server_ids = data.get('server_ids', [])
        days = min(data.get('days', 90), 365)
        organization = data.get('organization', 'Organization')
        description = data.get('description', '')

        if not server_ids:
            # Get all active servers if none specified
            if DATABASE_AVAILABLE and db:
                servers = db.query(Server).filter(Server.status == 'active').all()
                server_ids = [int(s.id) for s in servers]  # type: ignore[arg-type]

        if not server_ids:
            return jsonify({'error': 'No servers specified or available'}), 400

        user = get_current_user()
        username = getattr(user, 'email', None) or str(user) if user else 'unknown'

        # Collect evidence from all servers
        package = collect_evidence_for_assessment(
            server_ids=server_ids,
            framework=framework,
            days=days,
            organization=organization,
            collected_by=username
        )

        # Update name/description if provided
        if name:
            package.name = name
        if description:
            package.description = description

        # Store package
        _evidence_packages[package.id] = package

        return jsonify({
            'success': True,
            'package': {
                'id': package.id,
                'name': package.name,
                'framework': package.framework,
                'organization': package.organization,
                'period': {
                    'start': package.period_start.isoformat(),
                    'end': package.period_end.isoformat()
                },
                'items_count': len(package.items),
                'controls_covered': len(set(
                    c for item in package.items for c in item.control_ids
                )),
                'checksum': package.package_checksum,
                'signed_by': package.signed_by,
                'signed_at': package.signed_at.isoformat() if package.signed_at else None
            }
        })

    except Exception as e:
        logger.error(f"Error creating evidence package: {e}")
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/collect/assessment/export', methods=['POST'])
@require_auth_permission_and_log('manage_compliance', 'Created and exported compliance evidence package')
def create_and_export_assessment_package():
    """
    One-call workflow: collect assessment evidence and export ZIP.

    Request Body:
    {
        "name": "Q1 2026 PCI-DSS Assessment",
        "framework": "PCI-DSS",
        "server_ids": [1, 2, 3],
        "days": 90,
        "organization": "Acme Corp",
        "description": "Quarterly PCI-DSS compliance evidence",
        "download": true,
        "store_package": true
    }

    Returns:
        ZIP file download by default, or JSON metadata when download=false.
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        return jsonify({'error': 'Evidence collector not available'}), 503

    try:
        data = request.get_json() or {}

        name = data.get('name', f"Evidence Package - {datetime.utcnow().strftime('%Y-%m-%d')}")
        framework = data.get('framework', 'PCI-DSS')
        server_ids = data.get('server_ids', [])
        days = min(data.get('days', 90), 365)
        organization = data.get('organization', 'Organization')
        description = data.get('description', '')
        download = bool(data.get('download', True))
        store_package = bool(data.get('store_package', True))

        if not server_ids:
            # Get all active servers if none specified
            if DATABASE_AVAILABLE and db:
                servers = db.query(Server).filter(Server.status == 'active').all()
                server_ids = [int(s.id) for s in servers]  # type: ignore[arg-type]

        if not server_ids:
            return jsonify({'error': 'No servers specified or available'}), 400

        user = get_current_user()
        username = getattr(user, 'email', None) or str(user) if user else 'unknown'

        package = collect_evidence_for_assessment(
            server_ids=server_ids,
            framework=framework,
            days=days,
            organization=organization,
            collected_by=username
        )

        if name:
            package.name = name
        if description:
            package.description = description

        package.calculate_package_checksum()

        zip_path = export_evidence_package(package, output_dir=str(EVIDENCE_EXPORTS_DIR))

        if store_package:
            _evidence_packages[package.id] = package

        log_audit(
            action='create_export_assessment_evidence_package',
            resource_id=package.id,
            resource_type='evidence_package',
            details={
                'framework': framework,
                'days': days,
                'server_count': len(server_ids),
                'download_requested': download,
                'stored_in_registry': store_package,
                'zip_path': str(zip_path)
            },
            success=True
        )

        if download:
            filename = f"evidence-{package.framework}-{package.id}.zip"
            return send_file(
                zip_path,
                mimetype='application/zip',
                as_attachment=True,
                download_name=filename
            )

        return jsonify({
            'success': True,
            'package': {
                'id': package.id,
                'name': package.name,
                'framework': package.framework,
                'organization': package.organization,
                'items_count': len(package.items),
                'checksum': package.package_checksum,
                'signed_by': package.signed_by,
                'signed_at': package.signed_at.isoformat() if package.signed_at else None
            },
            'export': {
                'path': str(zip_path),
                'directory': str(EVIDENCE_EXPORTS_DIR)
            }
        })

    except Exception as e:
        logger.error(f"Error creating and exporting evidence package: {e}")
        log_audit(
            action='create_export_assessment_evidence_package',
            resource_type='evidence_package',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


# ============================================================================
# Package Management Endpoints
# ============================================================================

@evidence_bp.route('/api/evidence/packages', methods=['GET'])
@require_auth_and_permission('view_reports')
@require_role('Analyst')
def list_packages():
    """
    List all evidence packages (requires Analyst+ role).

    Returns:
        List of package summaries
    """
    try:
        packages = []
        seen: set[str] = set()

        for pkg_id, pkg in _evidence_packages.items():
            record = _evidence_registry.get(pkg_id, {})
            packages.append({
                'id': pkg.id,
                'package_id': pkg.id,
                'name': pkg.name,
                'framework': pkg.framework,
                'organization': pkg.organization,
                'created_at': pkg.created_at.isoformat(),
                'exported_at': record.get('exported_at'),
                'items_count': len(pkg.items),
                'signed': pkg.signed_at is not None,
                'exported': bool(record.get('zip_path')),
                'last_verified_ok': record.get('last_verified_ok'),
                'last_verified_at': record.get('last_verified_at'),
            })
            seen.add(pkg_id)

        for pkg_id, record in _evidence_registry.items():
            if pkg_id in seen:
                continue
            packages.append({
                'id': record.get('package_id', pkg_id),
                'package_id': record.get('package_id', pkg_id),
                'name': record.get('name', 'Unknown'),
                'framework': record.get('framework', 'Unknown'),
                'organization': record.get('organization', 'Unknown'),
                'created_at': record.get('created_at'),
                'exported_at': record.get('exported_at'),
                'items_count': int(record.get('items_count', 0)),
                'signed': bool(record.get('signed_at')),
                'exported': bool(record.get('zip_path')),
                'last_verified_ok': record.get('last_verified_ok'),
                'last_verified_at': record.get('last_verified_at'),
            })

        log_audit(
            action='list_evidence_packages',
            resource_type='evidence_package',
            details={'total_packages': len(packages)},
            success=True
        )

        return jsonify({
            'success': True,
            'packages': packages,
            'total': len(packages)
        })
    except Exception as e:
        log_audit(
            action='list_evidence_packages',
            resource_type='evidence_package',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/packages/<package_id>', methods=['GET'])
@require_auth_and_permission('view_reports')
def get_package(package_id: str):
    """
    Get evidence package details.

    Returns:
        Complete package manifest
    """
    manifest = _load_manifest_for_package(package_id)
    if manifest is None:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    return jsonify({
        'success': True,
        'manifest': manifest
    })


@evidence_bp.route('/api/evidence/packages/<package_id>', methods=['DELETE'])
@require_auth_permission_and_log('manage_compliance', 'Deleted evidence package')
@require_role('Admin')
def delete_package(package_id: str):
    """
    Delete an evidence package (requires Admin+ role).
    """
    try:
        package = _evidence_packages.get(package_id)
        record = _evidence_registry.get(package_id)
        delete_files = request.args.get('delete_files', 'false').lower() == 'true'

        if package is None and record is None:
            log_audit(
                action='delete_evidence_package',
                resource_id=package_id,
                resource_type='evidence_package',
                success=False,
                error='Package not found'
            )
            return jsonify({'error': f'Package {package_id} not found'}), 404

        package_name = package.name if package else record.get('name', package_id)

        if package_id in _evidence_packages:
            del _evidence_packages[package_id]

        deleted_files = []
        if record:
            if delete_files:
                for key in ('zip_path', 'manifest_path'):
                    file_path = record.get(key)
                    if file_path and Path(file_path).exists():
                        Path(file_path).unlink(missing_ok=True)
                        deleted_files.append(file_path)
            del _evidence_registry[package_id]
            _save_registry()

        log_audit(
            action='delete_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            details={'package_name': package_name, 'delete_files': delete_files, 'deleted_files': deleted_files},
            success=True
        )

        return jsonify({'success': True, 'deleted': package_id, 'deleted_files': deleted_files})
    except Exception as e:
        log_audit(
            action='delete_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/packages/<package_id>/sign', methods=['POST'])
@require_auth_permission_and_log('manage_compliance', 'Signed evidence package')
def sign_package(package_id: str):
    """
    Sign an evidence package (attestation).

    Returns:
        Updated package with signature
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        return jsonify({'error': 'Evidence collector not available'}), 503

    if package_id not in _evidence_packages:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    user = get_current_user()
    username = getattr(user, 'email', None) or str(user) if user else 'unknown'

    package = _evidence_packages[package_id]
    collector = ComplianceEvidenceCollector()
    package = collector.sign_package(package, signed_by=username)
    _evidence_packages[package_id] = package

    signed_at_str = package.signed_at.isoformat() if package.signed_at else ''

    return jsonify({
        'success': True,
        'package_id': package_id,
        'signed_by': package.signed_by,
        'signed_at': signed_at_str,
        'checksum': package.package_checksum
    })


# ============================================================================
# Export Endpoints
# ============================================================================

@evidence_bp.route('/api/evidence/packages/<package_id>/export', methods=['GET'])
@require_auth_and_permission('export_reports')
@require_role('Analyst')
def export_package(package_id: str):
    """
    Export evidence package to ZIP file (requires Analyst+ role).

    Query Parameters:
        download: bool - Return file download (default: true)

    Returns:
        ZIP file download or path info
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        log_audit(
            action='export_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            success=False,
            error='Evidence collector not available'
        )
        return jsonify({'error': 'Evidence collector not available'}), 503

    package = _evidence_packages.get(package_id)
    record = _evidence_registry.get(package_id)

    if package is None and record is None:
        log_audit(
            action='export_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            success=False,
            error='Package not found'
        )
        return jsonify({'error': f'Package {package_id} not found'}), 404

    download = request.args.get('download', 'true').lower() == 'true'
    user = get_current_user()
    username = getattr(user, 'email', None) or str(user) if user else 'unknown'

    try:
        if package is not None:
            zip_path = export_evidence_package(package, output_dir=str(EVIDENCE_EXPORTS_DIR))
            _register_export(package, str(zip_path), username)
        else:
            zip_path = record.get('zip_path')
            if not zip_path or not Path(zip_path).exists():
                return jsonify({'error': 'Export file not found for package'}), 404

        package_name = package.framework if package else record.get('framework', 'unknown')
        package_checksum = package.package_checksum if package else record.get('checksum')
        package_items_count = len(package.items) if package else int(record.get('items_count', 0))

        log_audit(
            action='export_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            details={
                'framework': package_name,
                'download_requested': download,
                'items_count': package_items_count,
                'zip_path': str(zip_path)
            },
            success=True
        )

        if download:
            filename = f"evidence-{package_name}-{package_id}.zip"
            return send_file(
                zip_path,
                mimetype='application/zip',
                as_attachment=True,
                download_name=filename
            )
        else:
            return jsonify({
                'success': True,
                'path': zip_path,
                'package_id': package_id,
                'checksum': package_checksum
            })

    except Exception as e:
        logger.error(f"Error exporting package: {e}")
        log_audit(
            action='export_evidence_package',
            resource_id=package_id,
            resource_type='evidence_package',
            success=False,
            error=str(e)
        )
        return jsonify({'error': str(e)}), 500


@evidence_bp.route('/api/evidence/packages/<package_id>/manifest', methods=['GET'])
@require_auth_and_permission('view_reports')
def get_manifest(package_id: str):
    """
    Get package manifest JSON (without downloading full package).

    Returns:
        Manifest JSON
    """
    manifest = _load_manifest_for_package(package_id)
    if manifest is None:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    return jsonify(manifest)


@evidence_bp.route('/api/evidence/packages/<package_id>/verify', methods=['GET'])
@require_auth_and_permission('view_reports')
@require_role('Analyst')
def verify_package_export(package_id: str):
    """Verify integrity of an exported package archive."""
    record = _evidence_registry.get(package_id)
    if not record:
        return jsonify({'error': f'No export metadata found for package {package_id}'}), 404

    zip_path = record.get('zip_path')
    if not zip_path:
        return jsonify({'error': f'No ZIP path recorded for package {package_id}'}), 404

    verification = _verify_export_archive(zip_path)
    record['last_verified_at'] = datetime.utcnow().isoformat()
    record['last_verified_ok'] = verification.get('verified', False)
    _save_registry()

    return jsonify({
        'success': True,
        'package_id': package_id,
        'zip_path': zip_path,
        'verification': verification
    })


@evidence_bp.route('/api/evidence/exports/cleanup', methods=['POST'])
@require_auth_permission_and_log('manage_compliance', 'Cleaned up evidence export artifacts')
@require_role('Admin')
def cleanup_export_artifacts():
    """Cleanup old evidence export archives using retention policy."""
    data = request.get_json() or {}
    days_to_keep = max(1, int(data.get('days_to_keep', 30)))
    dry_run = bool(data.get('dry_run', True))
    cutoff = datetime.utcnow() - timedelta(days=days_to_keep)

    to_remove: list[str] = []
    deleted_paths: list[str] = []

    for package_id, record in _evidence_registry.items():
        exported_at_raw = record.get('exported_at')
        if not exported_at_raw:
            continue
        try:
            exported_at = datetime.fromisoformat(str(exported_at_raw).replace('Z', '+00:00').replace('+00:00', ''))
        except ValueError:
            continue
        if exported_at < cutoff:
            to_remove.append(package_id)

    if not dry_run:
        for package_id in to_remove:
            record = _evidence_registry.get(package_id, {})
            for key in ('zip_path', 'manifest_path'):
                file_path = record.get(key)
                if file_path and Path(file_path).exists():
                    Path(file_path).unlink(missing_ok=True)
                    deleted_paths.append(file_path)
            _evidence_registry.pop(package_id, None)
            _evidence_packages.pop(package_id, None)
        _save_registry()

    return jsonify({
        'success': True,
        'dry_run': dry_run,
        'days_to_keep': days_to_keep,
        'candidates': len(to_remove),
        'candidate_package_ids': to_remove,
        'deleted_paths': deleted_paths
    })


@evidence_bp.route('/api/evidence/settings', methods=['GET'])
@require_auth_and_permission('view_reports')
def get_evidence_settings():
    """Return current evidence retention policy settings (read-only)."""
    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting('evidence_retention_enabled', True))
        days_raw = get_security_setting('evidence_retention_days', 30)
        days = int(days_raw) if days_raw is not None else 30
    except Exception:
        enabled = True
        days = 30
    return jsonify({
        'evidence_retention_enabled': enabled,
        'evidence_retention_days': max(1, days),
    })


# ============================================================================
# Evidence Item Endpoints
# ============================================================================

@evidence_bp.route('/api/evidence/packages/<package_id>/items', methods=['GET'])
@require_auth_and_permission('view_reports')
def list_items(package_id: str):
    """
    List evidence items in a package.

    Query Parameters:
        control_id: Filter by control ID
        type: Filter by evidence type

    Returns:
        List of evidence items
    """
    if package_id not in _evidence_packages:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    package = _evidence_packages[package_id]
    items = package.items

    # Apply filters
    control_id = request.args.get('control_id')
    evidence_type = request.args.get('type')

    if control_id:
        items = [i for i in items if control_id in i.control_ids]

    if evidence_type:
        try:
            et = EvidenceType(evidence_type)
            items = [i for i in items if i.type == et]
        except ValueError:
            pass

    return jsonify({
        'success': True,
        'items': [item.to_dict() for item in items],
        'total': len(items)
    })


@evidence_bp.route('/api/evidence/packages/<package_id>/items/<item_id>', methods=['GET'])
@require_auth_and_permission('view_reports')
def get_item(package_id: str, item_id: str):
    """
    Get specific evidence item content.

    Returns:
        Evidence item with content
    """
    if package_id not in _evidence_packages:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    package = _evidence_packages[package_id]

    item = next((i for i in package.items if i.id == item_id), None)
    if not item:
        return jsonify({'error': f'Item {item_id} not found'}), 404

    result = item.to_dict()
    result['content'] = item.content

    return jsonify({
        'success': True,
        'item': result
    })


@evidence_bp.route('/api/evidence/packages/<package_id>/items', methods=['POST'])
@require_auth_and_permission('manage_compliance')
def add_item(package_id: str):
    """
    Add custom evidence item to a package.

    Request Body:
    {
        "title": "Network Diagram",
        "type": "custom",
        "description": "Current network topology",
        "control_ids": ["PCI-1.1.2"],
        "content": "... or base64 encoded file ..."
    }

    Returns:
        Added item info
    """
    if not EVIDENCE_COLLECTOR_AVAILABLE:
        return jsonify({'error': 'Evidence collector not available'}), 503

    if package_id not in _evidence_packages:
        return jsonify({'error': f'Package {package_id} not found'}), 404

    data = request.get_json() or {}

    user = get_current_user()
    username = getattr(user, 'email', None) or str(user) if user else 'unknown'

    package = _evidence_packages[package_id]

    try:
        item = EvidenceItem(
            id=f"custom-{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}",
            type=EvidenceType(data.get('type', 'custom')),
            title=data.get('title', 'Custom Evidence'),
            description=data.get('description', ''),
            control_ids=data.get('control_ids', ['CUSTOM']),
            framework=package.framework,
            collected_at=datetime.utcnow(),
            collected_by=username,
            content=data.get('content'),
            metadata=data.get('metadata', {})
        )

        package.add_item(item)
        package.calculate_package_checksum()

        return jsonify({
            'success': True,
            'item': item.to_dict()
        })

    except Exception as e:
        logger.error(f"Error adding evidence item: {e}")
        return jsonify({'error': str(e)}), 500


# Export blueprint
__all__ = ['evidence_bp']
