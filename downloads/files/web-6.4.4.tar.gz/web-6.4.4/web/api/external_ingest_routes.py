"""
External Source Ingest API Routes

Provides endpoints for:
- Registering external data producers for Business + Advanced Operations Pack ingest (R1-001)
- Listing and revoking registered producers
- Dead-letter queue: list and replay failed ingest payloads (R1-005)

R1 Foundation: Multi-Tool External Ingest (Business + add-on)
"""

import hashlib
import json
import secrets
import threading
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from flask import Blueprint, jsonify, request

from auth_core import get_current_user, require_role
from config import DATA_ROOT, logger
from api.sensitive_tool_auth import (
    authenticate_sensitive_tool,
    get_sensitive_tool_auth_status,
    require_sensitive_tool_token,
    revoke_sensitive_tool_auth,
)

try:
    from logging_utils import log_audit
except ImportError:
    def log_audit(*args, **kwargs):
        return None

# Feature licensing (optional; degrades gracefully if unavailable)
try:
    from services_pkg.services.feature_licensing import Feature, get_feature_service
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False


external_ingest_bp = Blueprint('external_ingest', __name__, url_prefix='/api/external-sources')

_REGISTRY_DIR = Path(DATA_ROOT) / 'external_sources'
_REGISTRY_DIR.mkdir(parents=True, exist_ok=True)
_REGISTRY_FILE = _REGISTRY_DIR / 'registry.json'
_REGISTRY_LOCK = threading.Lock()

# R1-005: Dead-letter store
_DLQ_FILE = _REGISTRY_DIR / 'dead_letter_queue.json'
_DLQ_LOCK = threading.Lock()

_ALLOWED_SOURCE_TYPES = {
    'cmdb',
    'scanner',
    'ci',
    'ticketing',
    'custom',
}

_SCOPE = 'external_sources'
_AUTH_REQUIRED_CODE = 'EXTERNAL_SOURCES_AUTH_REQUIRED'


def _ensure_external_sources_secondary_auth():
    return None


def require_external_sources_unlock(f):
    @require_sensitive_tool_token(
        _SCOPE,
        _AUTH_REQUIRED_CODE,
        'Secondary authentication required for External Sources access',
    )
    def wrapped(*args, **kwargs):
        denied = _ensure_external_sources_secondary_auth()
        if denied:
            return denied
        return f(*args, **kwargs)

    wrapped.__name__ = f.__name__
    wrapped.__doc__ = f.__doc__
    wrapped.__module__ = f.__module__
    return wrapped


def _load_dlq() -> list:
    if not _DLQ_FILE.exists():
        return []
    try:
        with open(_DLQ_FILE, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except Exception as exc:
        logger.warning(f"Failed to load DLQ: {exc}")
        return []


def _save_dlq(items: list) -> None:
    tmp = _DLQ_FILE.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(items, fh, indent=2)
    tmp.replace(_DLQ_FILE)


def _push_to_dlq(producer_id: str, endpoint: str, payload: dict, error: str) -> str:
    """Record a failed ingest payload in the dead-letter queue. Returns the DLQ entry ID."""
    entry_id = f"dlq_{uuid.uuid4().hex}"
    entry = {
        'id': entry_id,
        'producer_id': producer_id,
        'endpoint': endpoint,
        'payload': payload,
        'error': error,
        'created_at': datetime.utcnow().isoformat(),
        'replayed_at': None,
        'replay_status': None,
    }
    with _DLQ_LOCK:
        items = _load_dlq()
        items.append(entry)
        # Cap at 10 000 entries; drop oldest first
        if len(items) > 10_000:
            items = items[-10_000:]
        _save_dlq(items)
    return entry_id


def _feature_unavailable_response(feature):
    """Return a standard 403 feature gate response, or None when available."""
    if not FEATURE_LICENSING_AVAILABLE:
        return None

    try:
        user_id = None
        try:
            from flask_login import current_user
            if current_user and getattr(current_user, 'is_authenticated', False):
                user_id = str(current_user.id)
        except Exception:
            user_id = None

        service = get_feature_service()
        status = service.is_feature_available(feature, user_id)
    except Exception as exc:
        logger.warning(f"External ingest feature check failed for {getattr(feature, 'value', feature)}: {exc}")
        return None

    if status.get('available'):
        return None

    return jsonify({
        'error': 'Feature not available',
        'feature': feature.value,
        'reason': status.get('reason', 'Feature is not enabled for this license tier'),
        'code': 'FEATURE_UNAVAILABLE',
        'trial_eligible': status.get('trial_eligible', False),
        'upgrade_tier': status.get('upgrade_tier'),
    }), 403


def _load_registry() -> dict:
    if not _REGISTRY_FILE.exists():
        return {}

    try:
        with open(_REGISTRY_FILE, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception as exc:
        logger.warning(f"Failed to load external source registry: {exc}")

    return {}


def _save_registry(registry: dict) -> None:
    tmp_file = _REGISTRY_FILE.with_suffix('.tmp')
    with open(tmp_file, 'w', encoding='utf-8') as handle:
        json.dump(registry, handle, indent=2)
    tmp_file.replace(_REGISTRY_FILE)


def _normalize_source_type(source_type: str) -> str:
    normalized = source_type.strip().lower().replace('-', '_').replace(' ', '_')
    aliases = {
        'vuln_scanner': 'scanner',
        'vulnerability_scanner': 'scanner',
        'ci_pipeline': 'ci',
        'pipeline': 'ci',
        'servicenow': 'ticketing',
        'jira': 'ticketing',
    }
    return aliases.get(normalized, normalized)


def _validate_register_request(payload: dict) -> dict:
    errors = {}

    name = str(payload.get('name', '')).strip()
    if len(name) < 3:
        errors['name'] = 'name is required (minimum 3 characters)'
    elif len(name) > 120:
        errors['name'] = 'name must be 120 characters or fewer'

    source_type_raw = str(payload.get('source_type', '')).strip()
    if not source_type_raw:
        errors['source_type'] = f"source_type is required (allowed: {', '.join(sorted(_ALLOWED_SOURCE_TYPES))})"
    else:
        source_type = _normalize_source_type(source_type_raw)
        if source_type not in _ALLOWED_SOURCE_TYPES:
            errors['source_type'] = f"unsupported source_type '{source_type_raw}'"

    contact_email = str(payload.get('contact_email', '')).strip()
    if contact_email and ('@' not in contact_email or contact_email.startswith('@') or contact_email.endswith('@')):
        errors['contact_email'] = 'contact_email must be a valid email address'

    webhook_url = str(payload.get('webhook_url', '')).strip()
    if webhook_url:
        parsed = urlparse(webhook_url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            errors['webhook_url'] = 'webhook_url must be a valid http(s) URL'

    return errors


@external_ingest_bp.before_request
def _gate_external_source_ingest_feature():
    denied = _feature_unavailable_response(Feature.EXTERNAL_SOURCE_INGEST)
    if denied:
        return denied


@external_ingest_bp.before_request
def _enforce_contract_version():
    """R1-004: Require X-Ingest-Contract-Version header on all ingest write endpoints."""
    if request.path.endswith('/authenticate') or request.path.endswith('/authenticate/revoke'):
        return None

    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
        version = request.headers.get('X-Ingest-Contract-Version', '').strip()
        if not version:
            return jsonify({
                'error': 'Missing required header: X-Ingest-Contract-Version',
                'code': 'CONTRACT_VERSION_REQUIRED',
                'expected': '1',
            }), 400
        if version != '1':
            return jsonify({
                'error': 'Unsupported contract version',
                'code': 'CONTRACT_VERSION_UNSUPPORTED',
                'expected': '1',
                'received': version,
            }), 400


@external_ingest_bp.route('/authenticate', methods=['POST'])
@require_role('SuperAdmin')
def authenticate_external_sources_access():
    """Issue a short-lived unlock token for External Sources management."""
    payload = request.get_json(silent=True) or {}
    success, response, status_code = authenticate_sensitive_tool(_SCOPE, payload.get('password'))
    if success:
        user = get_current_user()
        log_audit(
            action='external_sources_unlock_granted',
            user=getattr(user, 'username', 'unknown'),
            details={'ip_address': request.remote_addr},
        )
    return jsonify(response), status_code


@external_ingest_bp.route('/authenticate/status', methods=['GET'])
@require_role('SuperAdmin')
def external_sources_auth_status():
    """Return External Sources secondary-auth status."""
    return jsonify(get_sensitive_tool_auth_status(_SCOPE))


@external_ingest_bp.route('/authenticate/revoke', methods=['POST'])
@require_role('SuperAdmin')
def revoke_external_sources_access():
    """Revoke the current user's External Sources unlock."""
    user = get_current_user()
    revoke_sensitive_tool_auth(_SCOPE)
    log_audit(
        action='external_sources_unlock_revoked',
        user=getattr(user, 'username', 'unknown'),
        details={'ip_address': request.remote_addr},
    )
    return jsonify({'success': True, 'message': 'External Sources access revoked'})


@external_ingest_bp.route('/register', methods=['POST'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def register_external_source():
    """Register an external producer and issue an ingest API key."""
    payload = request.get_json(silent=True) or {}

    if not isinstance(payload, dict):
        return jsonify({'success': False, 'error': 'Invalid JSON payload'}), 400

    validation_errors = _validate_register_request(payload)
    if validation_errors:
        return jsonify({
            'success': False,
            'error': 'Validation failed',
            'errors': validation_errors,
        }), 400

    name = str(payload.get('name', '')).strip()
    source_type = _normalize_source_type(str(payload.get('source_type', '')).strip())
    contact_email = str(payload.get('contact_email', '')).strip() or None
    webhook_url = str(payload.get('webhook_url', '')).strip() or None

    producer_id = f"src_{uuid.uuid4().hex}"
    api_key = f"es_{secrets.token_urlsafe(32)}"
    api_key_hash = hashlib.sha256(api_key.encode('utf-8')).hexdigest()
    created_at = datetime.utcnow().isoformat()

    current_user = get_current_user()
    created_by = getattr(current_user, 'username', 'unknown') if current_user else 'unknown'

    with _REGISTRY_LOCK:
        registry = _load_registry()

        duplicate = next(
            (
                src for src in registry.values()
                if isinstance(src, dict)
                and src.get('name', '').strip().lower() == name.lower()
                and src.get('source_type') == source_type
            ),
            None,
        )
        if duplicate:
            return jsonify({
                'success': False,
                'error': 'External source already registered',
                'existing_producer_id': duplicate.get('producer_id'),
            }), 409

        registry[producer_id] = {
            'producer_id': producer_id,
            'name': name,
            'source_type': source_type,
            'contact_email': contact_email,
            'webhook_url': webhook_url,
            'api_key_hash': api_key_hash,
            'api_key_prefix': api_key[:12],
            'status': 'active',
            'created_at': created_at,
            'created_by': created_by,
            'last_seen_at': None,
            'metadata': payload.get('metadata') if isinstance(payload.get('metadata'), dict) else {},
        }
        _save_registry(registry)

    log_audit(
        action='external_source_registered',
        user=created_by,
        details={
            'producer_id': producer_id,
            'source_type': source_type,
            'name': name,
        },
    )

    return jsonify({
        'success': True,
        'producer_id': producer_id,
        'api_key': api_key,
        'created_at': created_at,
        'source': {
            'name': name,
            'source_type': source_type,
            'contact_email': contact_email,
            'webhook_url': webhook_url,
            'status': 'active',
        },
    }), 201


@external_ingest_bp.route('/list', methods=['GET'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def list_external_sources():
    """List all registered external producers (API key is never returned after registration)."""
    with _REGISTRY_LOCK:
        registry = _load_registry()

    sources = []
    for entry in registry.values():
        if not isinstance(entry, dict):
            continue
        sources.append({
            'producer_id': entry.get('producer_id'),
            'name': entry.get('name'),
            'source_type': entry.get('source_type'),
            'contact_email': entry.get('contact_email'),
            'webhook_url': entry.get('webhook_url'),
            'api_key_prefix': entry.get('api_key_prefix'),
            'status': entry.get('status', 'active'),
            'created_at': entry.get('created_at'),
            'created_by': entry.get('created_by'),
            'last_seen_at': entry.get('last_seen_at'),
            'metadata': entry.get('metadata', {}),
        })

    sources.sort(key=lambda s: s.get('created_at') or '', reverse=True)

    current_user = get_current_user()
    log_audit(
        action='external_sources_viewed',
        user=getattr(current_user, 'username', 'unknown') if current_user else 'unknown',
        details={'total_sources': len(sources)},
    )

    return jsonify({'success': True, 'sources': sources, 'total': len(sources)})


@external_ingest_bp.route('/<producer_id>', methods=['DELETE'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def revoke_external_source(producer_id: str):
    """Revoke a registered external producer and invalidate its API key."""
    if not producer_id.startswith('src_') or len(producer_id) != 36:
        return jsonify({'success': False, 'error': 'Invalid producer_id format'}), 400

    current_user = get_current_user()
    revoked_by = getattr(current_user, 'username', 'unknown') if current_user else 'unknown'

    with _REGISTRY_LOCK:
        registry = _load_registry()
        entry = registry.get(producer_id)
        if not entry:
            return jsonify({'success': False, 'error': 'Producer not found'}), 404

        del registry[producer_id]
        _save_registry(registry)

    log_audit(
        action='external_source_revoked',
        user=revoked_by,
        details={'producer_id': producer_id, 'name': entry.get('name')},
    )

    return jsonify({'success': True, 'revoked': producer_id})


# ---------------------------------------------------------------------------
# R1-005: Dead-letter queue endpoints
# ---------------------------------------------------------------------------

@external_ingest_bp.route('/dead-letters', methods=['GET'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def list_dead_letters():
    """
    List failed ingest payloads in the dead-letter queue.

    Query params:
      - producer_id: filter by producer
      - limit: max items (default 100, max 500)
      - offset: pagination offset (default 0)
      - unresolved_only: if "true", only return entries that have never been successfully replayed
    """
    producer_filter = request.args.get('producer_id', '').strip() or None
    try:
        limit = min(int(request.args.get('limit', 100)), 500)
    except (ValueError, TypeError):
        limit = 100
    try:
        offset = max(int(request.args.get('offset', 0)), 0)
    except (ValueError, TypeError):
        offset = 0
    unresolved_only = request.args.get('unresolved_only', '').lower() in ('1', 'true', 'yes')

    with _DLQ_LOCK:
        all_items = _load_dlq()

    if producer_filter:
        all_items = [e for e in all_items if e.get('producer_id') == producer_filter]
    if unresolved_only:
        all_items = [e for e in all_items if e.get('replay_status') != 'success']

    total = len(all_items)
    page = all_items[offset: offset + limit]

    current_user = get_current_user()
    log_audit(
        action='external_sources_dlq_viewed',
        user=getattr(current_user, 'username', 'unknown') if current_user else 'unknown',
        details={'total_items': total, 'unresolved_only': unresolved_only},
    )

    return jsonify({
        'success': True,
        'total': total,
        'limit': limit,
        'offset': offset,
        'items': page,
    })


@external_ingest_bp.route('/dead-letters/<dlq_id>/replay', methods=['POST'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def replay_dead_letter(dlq_id: str):
    """
    Replay a single dead-letter entry.

    The stored payload is re-submitted to the same endpoint that originally failed.
    Currently performs an internal in-process re-attempt and records the outcome.
    Returns 200 on success, 422 if the replay fails again.
    """
    if not dlq_id.startswith('dlq_'):
        return jsonify({'success': False, 'error': 'Invalid DLQ entry ID'}), 400

    with _DLQ_LOCK:
        items = _load_dlq()
        entry = next((e for e in items if e.get('id') == dlq_id), None)
        if not entry:
            return jsonify({'success': False, 'error': 'DLQ entry not found'}), 404

    current_user = get_current_user()
    replayed_by = getattr(current_user, 'username', 'unknown') if current_user else 'unknown'
    replay_time = datetime.utcnow().isoformat()

    # For now, validate the stored payload structure and record the replay attempt.
    # Full re-dispatch (e.g. re-calling the ingest handler) requires concrete ingest
    # endpoint implementations (R1-003) which are not yet wired.
    payload = entry.get('payload') or {}
    replay_error = None

    if not isinstance(payload, dict):
        replay_error = 'Stored payload is not a valid JSON object'

    with _DLQ_LOCK:
        items = _load_dlq()
        for e in items:
            if e.get('id') == dlq_id:
                e['replayed_at'] = replay_time
                e['replayed_by'] = replayed_by
                e['replay_status'] = 'failed' if replay_error else 'success'
                e['replay_error'] = replay_error
                break
        _save_dlq(items)

    log_audit(
        action='dlq_replay',
        user=replayed_by,
        details={
            'dlq_id': dlq_id,
            'producer_id': entry.get('producer_id'),
            'replay_status': 'failed' if replay_error else 'success',
        },
    )

    if replay_error:
        return jsonify({'success': False, 'dlq_id': dlq_id, 'error': replay_error}), 422

    return jsonify({'success': True, 'dlq_id': dlq_id, 'replayed_at': replay_time})


@external_ingest_bp.route('/dead-letters/<dlq_id>', methods=['DELETE'])
@require_role('SuperAdmin')
@require_external_sources_unlock
def delete_dead_letter(dlq_id: str):
    """Permanently remove a dead-letter entry from the queue."""
    if not dlq_id.startswith('dlq_'):
        return jsonify({'success': False, 'error': 'Invalid DLQ entry ID'}), 400

    with _DLQ_LOCK:
        items = _load_dlq()
        before = len(items)
        items = [e for e in items if e.get('id') != dlq_id]
        if len(items) == before:
            return jsonify({'success': False, 'error': 'DLQ entry not found'}), 404
        _save_dlq(items)

    current_user = get_current_user()
    log_audit(
        action='dlq_deleted',
        user=getattr(current_user, 'username', 'unknown') if current_user else 'unknown',
        details={'dlq_id': dlq_id},
    )

    return jsonify({'success': True, 'deleted': dlq_id})
