"""
Feature Licensing API Routes

Provides REST API endpoints for:
- Checking feature availability
- Activating features with keys
- Starting feature trials
- Managing feature activations (admin)
- Generating feature keys (superadmin)

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import logging
from datetime import datetime
from flask import Blueprint, request, jsonify, session
from functools import wraps

# Import RBAC decorators and audit logging
try:
    from auth_core import require_role
    from logging_utils import log_audit
    RBAC_AVAILABLE = True
except ImportError:
    RBAC_AVAILABLE = False
    require_role = lambda role: lambda f: f
    def log_audit(*args, **kwargs):
        pass

logger = logging.getLogger(__name__)

# Create blueprint
feature_bp = Blueprint('features', __name__, url_prefix='/api/features')


# ============================================================================
# Decorators
# ============================================================================

def require_auth(f):
    """Require authenticated user."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
        except Exception:
            if not session.get('user_id'):
                return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function


def require_admin(f):
    """Require Admin or SuperAdmin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            if current_user.role not in ('Admin', 'SuperAdmin'):
                return jsonify({
                    'error': 'Admin role required',
                    'code': 'ROLE_DENIED'
                }), 403
        except Exception as e:
            logger.error(f"Auth check failed: {e}")
            return jsonify({'error': 'Authentication check failed'}), 500
        return f(*args, **kwargs)
    return decorated_function


def require_superadmin(f):
    """Require SuperAdmin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            if current_user.role != 'SuperAdmin':
                return jsonify({
                    'error': 'SuperAdmin role required',
                    'code': 'ROLE_DENIED'
                }), 403
        except Exception as e:
            logger.error(f"Auth check failed: {e}")
            return jsonify({'error': 'Authentication check failed'}), 500
        return f(*args, **kwargs)
    return decorated_function


def get_current_user_id():
    """Get current user ID from Flask context."""
    try:
        from flask_login import current_user
        if current_user.is_authenticated:
            return str(current_user.id)
    except Exception as user_context_error:
        logger.debug(f"Unable to resolve current user id from Flask-Login context: {user_context_error}")
    return session.get('user_id')


def get_current_username():
    """Get current username."""
    try:
        from flask_login import current_user
        if current_user.is_authenticated:
            return current_user.username
    except Exception as user_context_error:
        logger.debug(f"Unable to resolve current username from Flask-Login context: {user_context_error}")
    return session.get('username', 'unknown')


# ============================================================================
# Feature Status Endpoints
# ============================================================================

@feature_bp.route('/status', methods=['GET'])
@require_auth
def get_all_features():
    """
    Get status of all features for current user/license.

    Returns availability, activation status, and upgrade info for each feature.
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, FEATURE_CATEGORIES
        )

        user_id = get_current_user_id()
        service = get_feature_service()

        # Get all feature statuses
        features = service.get_available_features(user_id)

        # Get user's active features
        user_features = service.get_user_features(user_id) if user_id else []

        # Get current license tier
        current_tier = service.get_current_license_tier()

        return jsonify({
            'license_tier': current_tier.value,
            'features': features,
            'activated_features': user_features,
            'categories': {
                k: {
                    'name': v['name'],
                    'description': v['description'],
                    'icon': v['icon'],
                    'feature_count': len(v['features']),
                }
                for k, v in FEATURE_CATEGORIES.items()
            },
        }), 200

    except Exception as e:
        logger.error(f"Failed to get feature status: {e}")
        return jsonify({
            'license_tier': 'free',
            'features': {},
            'activated_features': [],
            'categories': {},
            'degraded': True,
            'warning': 'Feature service unavailable',
        }), 200


@feature_bp.route('/<feature_name>/status', methods=['GET'])
@require_auth
def get_feature_status(feature_name: str):
    """
    Get status of a specific feature.

    Args:
        feature_name: Feature identifier (e.g., 'ssh_interactive')

    Returns:
        Feature availability and activation info
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature, FEATURE_CONFIG
        )

        # Validate feature name
        try:
            feature = Feature(feature_name)
        except ValueError:
            return jsonify({
                'error': 'Unknown feature',
                'feature': feature_name,
                'valid_features': [f.value for f in Feature],
            }), 404

        user_id = get_current_user_id()
        service = get_feature_service()

        status = service.is_feature_available(feature, user_id)
        config = FEATURE_CONFIG.get(feature, {})

        # Handle datetime serialization
        expires_value = status.get('expires')
        expires_str = expires_value.isoformat() if expires_value else None

        return jsonify({
            'feature': feature_name,
            'available': status['available'],
            'reason': status['reason'],
            'activation_type': status.get('activation_type'),
            'trial_eligible': status.get('trial_eligible', False),
            'upgrade_tier': status.get('upgrade_tier'),
            'expires': expires_str,
            'config': {
                'description': config.get('description', ''),
                'category': config.get('category', ''),
                'risk_level': config.get('risk_level', ''),
                'min_tier': config.get('min_tier').value if config.get('min_tier') else None,
                'min_role': config.get('min_role').value if config.get('min_role') else None,
                'requires_key': config.get('requires_key', False),
            },
        }), 200

    except Exception as e:
        logger.error(f"Failed to get feature status: {e}")
        return jsonify({'error': 'Failed to get feature status'}), 500


@feature_bp.route('/category/<category_name>', methods=['GET'])
@require_auth
def get_category_features(category_name: str):
    """
    Get features in a specific category.

    Args:
        category_name: Category identifier (e.g., 'remote_sessions')
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, FEATURE_CATEGORIES
        )

        if category_name not in FEATURE_CATEGORIES:
            return jsonify({
                'error': 'Unknown category',
                'category': category_name,
                'valid_categories': list(FEATURE_CATEGORIES.keys()),
            }), 404

        user_id = get_current_user_id()
        service = get_feature_service()

        category = FEATURE_CATEGORIES[category_name]
        features = service.get_features_by_category(category_name, user_id)

        return jsonify({
            'category': category_name,
            'name': category['name'],
            'description': category['description'],
            'icon': category['icon'],
            'features': features,
        }), 200

    except Exception as e:
        logger.error(f"Failed to get category features: {e}")
        return jsonify({'error': 'Failed to get category features'}), 500


# ============================================================================
# Feature Activation Endpoints
# ============================================================================

@feature_bp.route('/<feature_name>/activate', methods=['POST'])
@require_auth
def activate_feature(feature_name: str):
    """
    Activate a feature using an activation key.

    Request body:
        {
            "activation_key": "FEAT-XXXX-XXXX-XXXX-CHECKSUM"
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        # Validate feature name
        try:
            feature = Feature(feature_name)
        except ValueError:
            return jsonify({'error': 'Unknown feature'}), 404

        data = request.get_json() or {}
        activation_key = data.get('activation_key')

        if not activation_key:
            return jsonify({
                'error': 'Activation key required',
                'code': 'KEY_REQUIRED',
            }), 400

        user_id = get_current_user_id()
        if not user_id:
            return jsonify({'error': 'User ID not found'}), 400

        service = get_feature_service()
        result = service.activate_feature(feature, user_id, activation_key)

        if result['success']:
            logger.info(f"Feature {feature_name} activated by {get_current_username()}")
            return jsonify(result), 200
        else:
            return jsonify(result), 400

    except Exception as e:
        logger.error(f"Feature activation failed: {e}")
        return jsonify({'error': 'Activation failed'}), 500


@feature_bp.route('/<feature_name>/trial', methods=['POST'])
@require_auth
def start_feature_trial(feature_name: str):
    """
    Start a free trial for a feature.

    Only available for trial-eligible features.
    Each user can only start one trial per feature.
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        # Validate feature name
        try:
            feature = Feature(feature_name)
        except ValueError:
            return jsonify({'error': 'Unknown feature'}), 404

        user_id = get_current_user_id()
        if not user_id:
            return jsonify({'error': 'User ID not found'}), 400

        service = get_feature_service()
        result = service.start_trial(feature, user_id)

        if result['success']:
            logger.info(f"Trial started for {feature_name} by {get_current_username()}")
            return jsonify(result), 200
        else:
            return jsonify(result), 400

    except Exception as e:
        logger.error(f"Trial start failed: {e}")
        return jsonify({'error': 'Trial start failed'}), 500


@feature_bp.route('/validate-key', methods=['POST'])
@require_auth
def validate_feature_key():
    """
    Validate a feature activation key without activating.

    Request body:
        {
            "activation_key": "FEAT-XXXX-XXXX-XXXX-CHECKSUM",
            "feature": "ssh_interactive"  # optional
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        activation_key = data.get('activation_key')
        feature_name = data.get('feature')

        if not activation_key:
            return jsonify({'error': 'Activation key required'}), 400

        # If feature specified, validate for that feature
        feature = None
        if feature_name:
            try:
                feature = Feature(feature_name)
            except ValueError:
                return jsonify({'error': 'Unknown feature'}), 404

        service = get_feature_service()

        # Try to validate against specified feature or detect from key
        if feature:
            result = service.validate_feature_key(activation_key, feature)
        else:
            # Try all features to detect
            for f in Feature:
                result = service.validate_feature_key(activation_key, f)
                if result['valid']:
                    result['detected_feature'] = f.value
                    break

        return jsonify(result), 200 if result.get('valid') else 400

    except Exception as e:
        logger.error(f"Key validation failed: {e}")
        return jsonify({'error': 'Validation failed'}), 500


# ============================================================================
# Admin Feature Management
# ============================================================================

@feature_bp.route('/admin/user/<user_id>', methods=['GET'])
@require_admin
@require_role('Admin')
def get_user_features(user_id: str):
    """
    Get all feature activations for a specific user (requires Admin+ role).

    Admin function.
    """
    try:
        from web.services_pkg.services.feature_licensing import get_feature_service

        service = get_feature_service()
        features = service.get_user_features(user_id)
        all_status = service.get_available_features(user_id)

        return jsonify({
            'user_id': user_id,
            'activated_features': features,
            'feature_status': all_status,
        }), 200

    except Exception as e:
        logger.error(f"Failed to get user features: {e}")
        return jsonify({'error': 'Failed to get user features'}), 500


@feature_bp.route('/admin/grant', methods=['POST'])
@require_admin
@require_role('Admin')
def grant_feature_to_user():
    """
    Grant a feature to a user (requires Admin+ role).

    Admin function.

    Request body:
        {
            "user_id": "123",
            "feature": "ssh_interactive",
            "duration_days": 30,  # optional, null for permanent
            "notes": "Granted for project X"  # optional
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        user_id = data.get('user_id')
        feature_name = data.get('feature')
        duration_days = data.get('duration_days')
        notes = data.get('notes')

        if not user_id or not feature_name:
            log_audit(
                action='grant_feature',
                resource_id=user_id or 'unknown',
                resource_type='feature_grant',
                success=False,
                error='Missing user_id or feature'
            )
            return jsonify({'error': 'user_id and feature required'}), 400

        try:
            feature = Feature(feature_name)
        except ValueError:
            log_audit(
                action='grant_feature',
                resource_id=user_id,
                resource_type='feature_grant',
                details={'feature': feature_name},
                success=False,
                error='Unknown feature'
            )
            return jsonify({'error': 'Unknown feature'}), 404

        service = get_feature_service()
        granted_by = get_current_username()

        result = service.grant_feature(
            feature=feature,
            user_id=user_id,
            granted_by=granted_by,
            duration_days=duration_days,
            notes=notes,
        )

        if result['success']:
            logger.info(f"Feature {feature_name} granted to {user_id} by {granted_by}")
            log_audit(
                action='grant_feature',
                resource_id=user_id,
                resource_type='feature_grant',
                details={
                    'feature': feature_name,
                    'duration_days': duration_days,
                    'notes': notes,
                    'granted_by': granted_by
                },
                success=True
            )
        else:
            log_audit(
                action='grant_feature',
                resource_id=user_id,
                resource_type='feature_grant',
                details={'feature': feature_name},
                success=False,
                error=result.get('error', 'Grant failed')
            )

        return jsonify(result), 200 if result['success'] else 400

    except Exception as e:
        logger.error(f"Failed to grant feature: {e}")
        log_audit(
            action='grant_feature',
            resource_type='feature_grant',
            success=False,
            error=str(e)
        )
        return jsonify({'error': 'Failed to grant feature'}), 500


@feature_bp.route('/admin/revoke', methods=['POST'])
@require_admin
@require_role('Admin')
def revoke_feature_from_user():
    """
    Revoke a feature from a user (requires Admin+ role).

    Admin function.

    Request body:
        {
            "user_id": "123",
            "feature": "ssh_interactive"
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        user_id = data.get('user_id')
        feature_name = data.get('feature')

        if not user_id or not feature_name:
            log_audit(
                action='revoke_feature',
                resource_id=user_id or 'unknown',
                resource_type='feature_revoke',
                success=False,
                error='Missing user_id or feature'
            )
            return jsonify({'error': 'user_id and feature required'}), 400

        try:
            feature = Feature(feature_name)
        except ValueError:
            log_audit(
                action='revoke_feature',
                resource_id=user_id,
                resource_type='feature_revoke',
                details={'feature': feature_name},
                success=False,
                error='Unknown feature'
            )
            return jsonify({'error': 'Unknown feature'}), 404

        service = get_feature_service()
        revoked_by = get_current_username()

        result = service.revoke_feature(feature, user_id, revoked_by)

        if result['success']:
            logger.info(f"Feature {feature_name} revoked from {user_id} by {revoked_by}")
            log_audit(
                action='revoke_feature',
                resource_id=user_id,
                resource_type='feature_revoke',
                details={
                    'feature': feature_name,
                    'revoked_by': revoked_by
                },
                success=True
            )
        else:
            log_audit(
                action='revoke_feature',
                resource_id=user_id,
                resource_type='feature_revoke',
                details={'feature': feature_name},
                success=False,
                error=result.get('error', 'Revoke failed')
            )

        return jsonify(result), 200 if result['success'] else 400

    except Exception as e:
        logger.error(f"Failed to revoke feature: {e}")
        log_audit(
            action='revoke_feature',
            resource_type='feature_revoke',
            success=False,
            error=str(e)
        )
        return jsonify({'error': 'Failed to revoke feature'}), 500


# ============================================================================
# SuperAdmin Key Generation
# ============================================================================

@feature_bp.route('/admin/generate-key', methods=['POST'])
@require_superadmin
@require_role('SuperAdmin')
def generate_feature_key():
    """
    Generate a feature activation key (requires SuperAdmin role).

    SuperAdmin function.

    Request body:
        {
            "feature": "ssh_interactive",
            "duration_days": 365,  # optional, null for perpetual
            "org_id": "acme-corp"  # optional
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        feature_name = data.get('feature')
        duration_days = data.get('duration_days')
        org_id = data.get('org_id')

        if not feature_name:
            log_audit(
                action='generate_feature_key',
                resource_type='feature_key',
                success=False,
                error='Missing feature name'
            )
            return jsonify({'error': 'feature required'}), 400

        try:
            feature = Feature(feature_name)
        except ValueError:
            log_audit(
                action='generate_feature_key',
                resource_type='feature_key',
                details={'feature': feature_name},
                success=False,
                error='Unknown feature'
            )
            return jsonify({
                'error': 'Unknown feature',
                'valid_features': [f.value for f in Feature],
            }), 404

        service = get_feature_service()
        key = service.generate_feature_key(feature, duration_days, org_id)

        logger.info(f"Feature key generated for {feature_name} by {get_current_username()}")

        log_audit(
            action='generate_feature_key',
            resource_id=org_id or 'general',
            resource_type='feature_key',
            details={
                'feature': feature_name,
                'duration_days': duration_days,
                'org_id': org_id,
                'generated_by': get_current_username()
            },
            success=True
        )

        return jsonify({
            'feature': feature_name,
            'activation_key': key,
            'duration_days': duration_days,
            'org_id': org_id,
            'generated_at': datetime.utcnow().isoformat(),
            'generated_by': get_current_username(),
        }), 200

    except Exception as e:
        logger.error(f"Key generation failed: {e}")
        log_audit(
            action='generate_feature_key',
            resource_type='feature_key',
            success=False,
            error=str(e)
        )
        return jsonify({'error': 'Key generation failed'}), 500


@feature_bp.route('/admin/bulk-generate', methods=['POST'])
@require_superadmin
@require_role('SuperAdmin')
def bulk_generate_keys():
    """
    Generate multiple feature activation keys (requires SuperAdmin role).

    SuperAdmin function.

    Request body:
        {
            "features": ["ssh_interactive", "winrm_interactive"],
            "count": 10,
            "duration_days": 365,
            "org_id": "acme-corp"
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        feature_names = data.get('features', [])
        count = min(data.get('count', 1), 100)  # Max 100 keys
        duration_days = data.get('duration_days')
        org_id = data.get('org_id')

        if not feature_names:
            return jsonify({'error': 'features required'}), 400

        # Validate features
        features = []
        for name in feature_names:
            try:
                features.append(Feature(name))
            except ValueError:
                return jsonify({'error': f'Unknown feature: {name}'}), 404

        service = get_feature_service()
        keys = {}

        for feature in features:
            keys[feature.value] = []
            for _ in range(count):
                key = service.generate_feature_key(feature, duration_days, org_id)
                keys[feature.value].append(key)

        logger.info(
            f"Bulk key generation: {len(features)} features, {count} keys each "
            f"by {get_current_username()}"
        )

        return jsonify({
            'keys': keys,
            'count_per_feature': count,
            'total_keys': len(features) * count,
            'duration_days': duration_days,
            'org_id': org_id,
            'generated_at': datetime.utcnow().isoformat(),
        }), 200

    except Exception as e:
        logger.error(f"Bulk key generation failed: {e}")
        return jsonify({'error': 'Bulk generation failed'}), 500


# ============================================================================
# Feature Check Endpoint (for UI feature flags)
# ============================================================================

@feature_bp.route('/check', methods=['POST'])
@require_auth
def check_features():
    """
    Batch check multiple features at once.

    Useful for UI to determine which features to show/hide.

    Request body:
        {
            "features": ["ssh_interactive", "winrm_interactive", "fix_scripts_linux"]
        }
    """
    try:
        from web.services_pkg.services.feature_licensing import (
            get_feature_service, Feature
        )

        data = request.get_json() or {}
        feature_names = data.get('features', [])

        if not feature_names:
            return jsonify({'error': 'features list required'}), 400

        user_id = get_current_user_id()
        service = get_feature_service()

        results = {}
        for name in feature_names:
            try:
                feature = Feature(name)
                status = service.is_feature_available(feature, user_id)
                results[name] = {
                    'available': status['available'],
                    'reason': status['reason'],
                    'trial_eligible': status.get('trial_eligible', False),
                }
            except ValueError:
                results[name] = {
                    'available': False,
                    'reason': 'Unknown feature',
                    'trial_eligible': False,
                }

        return jsonify({
            'features': results,
            'license_tier': service.get_current_license_tier().value,
        }), 200

    except Exception as e:
        logger.error(f"Feature check failed: {e}")
        return jsonify({
            'features': {},
            'license_tier': 'free',
            'degraded': True,
            'warning': 'Feature service unavailable',
        }), 200
