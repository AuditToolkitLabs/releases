"""
Audit History Analytics API Routes

Advanced endpoints for historical audit data and trend analysis:
- GET /api/analytics/servers/<server_id>/history - Server audit history with aggregated stats
- GET /api/analytics/servers/<server_id>/compliance - Server compliance trends over time
- GET /api/analytics/servers/<server_id>/compare-runs - Compare latest run to previous (renewal/upsell demos)
- GET /api/analytics/audits/<audit_id>/history - Audit execution history across servers
- GET /api/analytics/trends - Trend analysis across all servers
- GET /api/analytics/trend-report - Comprehensive trend report for all servers
- POST /api/analytics/aggregate - Trigger daily aggregation manually

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from sqlalchemy import and_, desc

# Import from config
from config import logger
from config import SessionLocal

# Import auth decorators
from auth_core import require_api_key
from security_settings import get_security_setting

# Import pagination
from pagination import PaginationParams, paginate_query

# Import models
from models.database import Server, Audit  # noqa: F401
from models.audit_history import (
    AuditHistorySummary,
    ServerComplianceHistory,
    aggregate_daily_summaries,
    aggregate_server_compliance
)

# Create blueprint
analytics_bp = Blueprint('analytics', __name__)


def _get_analytics_max_result_set_size() -> int:
    """Get configured hard cap for analytics result windows."""
    try:
        configured = int(get_security_setting('analytics_max_result_set_size', 10000))
        return max(1000, min(configured, 100000))
    except (TypeError, ValueError):
        return 10000


# ============================================================================
# Dashboard Analytics
# ============================================================================

@analytics_bp.route('/api/analytics/dashboard')
@require_api_key
def get_dashboard():
    """
    Get comprehensive dashboard analytics

    Returns aggregated metrics for the dashboard including:
    - Server health summary
    - Recent audit results
    - Compliance trends
    - Alert summary

    Query Parameters:
        days (int): Number of days for trend data (default: 7, max: 30)

    Returns:
        {
            "success": true,
            "servers": {
                "total": 50,
                "online": 45,
                "offline": 3,
                "unknown": 2
            },
            "audits": {
                "total_executed": 1234,
                "passed": 1100,
                "failed": 134,
                "pass_rate": 89.2
            },
            "compliance": {
                "average_score": 87.5,
                "critical_findings": 12,
                "high_findings": 45
            },
            "recent_activity": [...]
        }
    """
    from models.database import AuditExecution

    try:
        db = SessionLocal()
        try:
            days = min(int(request.args.get('days', 7)), 30)
            cutoff_date = datetime.utcnow() - timedelta(days=days)

            # Server summary
            servers = db.query(Server).all()

            def _server_state(server):
                status = getattr(server, 'status', None)
                if status in ('online', 'offline'):
                    return status
                if getattr(server, 'last_audit_at', None):
                    return 'online'
                return 'unknown'

            server_stats = {
                'total': len(servers),
                'online': sum(1 for s in servers if _server_state(s) == 'online'),
                'offline': sum(1 for s in servers if _server_state(s) == 'offline'),
                'unknown': sum(1 for s in servers if _server_state(s) == 'unknown')
            }

            # Audit execution summary
            recent_executions = db.query(AuditExecution).filter(
                AuditExecution.executed_at >= cutoff_date
            ).all()

            audit_stats = {
                'total_executed': len(recent_executions),
                'passed': sum(1 for e in recent_executions if e.status == 'completed' and (e.exit_code == 0 if e.exit_code is not None else True)),
                'failed': sum(1 for e in recent_executions if e.status == 'failed' or (e.exit_code and e.exit_code > 0)),
                'running': sum(1 for e in recent_executions if e.status == 'running'),
                'pass_rate': 0.0  # nosec B105 - analytics metric name, not a credential
            }
            if audit_stats['total_executed'] > 0:
                audit_stats['pass_rate'] = round(
                    (audit_stats['passed'] / audit_stats['total_executed']) * 100, 1
                )

            # Compliance from history summaries (optional - may not exist yet)
            try:
                compliance_data = db.query(AuditHistorySummary).filter(
                    AuditHistorySummary.date >= cutoff_date.date()
                ).all()

                total_pass = sum(h.total_pass for h in compliance_data)
                total_fail = sum(h.total_fail for h in compliance_data)
                total_warn = sum(h.total_warn for h in compliance_data)
                total_checks = total_pass + total_fail + total_warn

                compliance_stats = {
                    'average_score': round((total_pass / total_checks * 100), 1) if total_checks > 0 else 0.0,
                    'critical_findings': total_fail,
                    'high_findings': total_warn,
                    'total_checks': total_checks
                }
            except Exception:
                db.rollback()
                # Table may not exist yet - return empty compliance stats
                compliance_stats = {
                    'average_score': 0.0,
                    'critical_findings': 0,
                    'high_findings': 0,
                    'total_checks': 0
                }

            # Recent activity (last 10 executions)
            recent_activity = db.query(AuditExecution).order_by(
                desc(AuditExecution.executed_at)
            ).limit(10).all()

            activity_list = []
            for exec in recent_activity:
                server = db.query(Server).filter(Server.id == exec.server_id).first()
                audit = db.query(Audit).filter(Audit.id == exec.audit_id).first()
                activity_list.append({
                    'id': exec.id,
                    'audit_name': audit.name if audit else 'Unknown',
                    'server_hostname': server.hostname if server else 'Unknown',
                    'status': exec.status,
                    'started_at': exec.executed_at.isoformat() if exec.executed_at else None
                })

            return jsonify({
                'success': True,
                'servers': server_stats,
                'audits': audit_stats,
                'compliance': compliance_stats,
                'recent_activity': activity_list,
                'period_days': days
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Dashboard analytics error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Server History Analytics
# ============================================================================

@analytics_bp.route('/api/analytics/servers/<int:server_id>/history')
@require_api_key
def get_server_history(server_id):
    """
    Get aggregated audit history for a specific server

    Query Parameters:
        days (int): Number of days to retrieve (default: 30, max: 365)
        audit_id (int): Filter by specific audit
        cursor/limit: Pagination params

    Returns:
        {
            "success": true,
            "server": {...},
            "history": [...],
            "pagination": {...}
        }
    """
    try:
        db = SessionLocal()

        # Verify server exists
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            db.close()
            return jsonify({"success": False, "error": f"Server {server_id} not found"}), 404

        # Parse query params
        days = min(int(request.args.get('days', 30)), 365)
        audit_id = request.args.get('audit_id', type=int)

        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Build query for daily summaries
        query = db.query(AuditHistorySummary).filter(
            and_(
                AuditHistorySummary.server_id == server_id,
                AuditHistorySummary.date >= start_date,
                AuditHistorySummary.date <= end_date
            )
        )

        # Filter by audit if specified
        if audit_id:
            query = query.filter(AuditHistorySummary.audit_id == audit_id)

        # Order by date descending
        query = query.order_by(desc(AuditHistorySummary.date))

        max_result_set_size = _get_analytics_max_result_set_size()
        total_records = query.count()
        if total_records > max_result_set_size:
            db.close()
            return jsonify({
                "success": False,
                "error": (
                    f"Result set too large ({total_records} records). Narrow filters "
                    f"(days/audit_id) or increase analytics_max_result_set_size "
                    f"(current: {max_result_set_size})."
                )
            }), 400

        # Apply pagination if requested
        if 'cursor' in request.args or 'limit' in request.args:
            params = PaginationParams.from_request(max_limit=500)
            result = paginate_query(query, params, id_field='id', endpoint='analytics.get_server_history')

            history = [item.to_dict() for item in result['data']]

            db.close()

            return jsonify({
                "success": True,
                "server": server.to_dict(),
                "history": history,
                "pagination": result['pagination'],
                "limits": {
                    "max_result_set_size": max_result_set_size,
                    "result_set_size": total_records
                },
                "date_range": {
                    "start": start_date.strftime('%Y-%m-%d'),
                    "end": end_date.strftime('%Y-%m-%d'),
                    "days": days
                }
            })
        else:
            # Return all (backward compatible)
            limit = min(int(request.args.get('limit', 100)), 500)
            summaries = query.limit(limit).all()
            history = [item.to_dict() for item in summaries]

            db.close()

            return jsonify({
                "success": True,
                "server": server.to_dict(),
                "history": history,
                "total": len(history),
                "limits": {
                    "max_result_set_size": max_result_set_size,
                    "result_set_size": total_records
                },
                "date_range": {
                    "start": start_date.strftime('%Y-%m-%d'),
                    "end": end_date.strftime('%Y-%m-%d'),
                    "days": days
                }
            })

    except Exception as e:
        logger.error(f"Error getting server history: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@analytics_bp.route('/api/analytics/servers/<int:server_id>/compliance')
@require_api_key
def get_server_compliance_trend(server_id):
    """
    Get compliance trend for a specific server

    Query Parameters:
        days (int): Number of days to retrieve (default: 30, max: 365)

    Returns:
        {
            "success": true,
            "server": {...},
            "compliance_trend": [...],
            "summary": {
                "current_score": 95.5,
                "avg_score": 93.2,
                "trend": "improving|declining|stable"
            }
        }
    """
    try:
        db = SessionLocal()

        # Verify server exists
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            db.close()
            return jsonify({"success": False, "error": f"Server {server_id} not found"}), 404

        # Parse query params
        days = min(int(request.args.get('days', 30)), 365)

        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Get compliance history
        compliance_records = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.server_id == server_id,
                ServerComplianceHistory.date >= start_date,
                ServerComplianceHistory.date <= end_date
            )
        ).order_by(ServerComplianceHistory.date).all()

        compliance_trend = [record.to_dict() for record in compliance_records]

        # Calculate summary statistics
        summary = {
            "current_score": None,
            "avg_score": None,
            "min_score": None,
            "max_score": None,
            "trend": "unknown",
            "data_points": len(compliance_trend)
        }

        if compliance_records:
            scores = [r.overall_compliance_score for r in compliance_records]
            summary["current_score"] = scores[-1]
            summary["avg_score"] = round(sum(scores) / len(scores), 2)
            summary["min_score"] = min(scores)
            summary["max_score"] = max(scores)

            # Determine trend (compare first half vs second half)
            if len(scores) >= 4:
                mid = len(scores) // 2
                first_half_avg = sum(scores[:mid]) / mid
                second_half_avg = sum(scores[mid:]) / (len(scores) - mid)

                if second_half_avg > first_half_avg + 2:
                    summary["trend"] = "improving"
                elif second_half_avg < first_half_avg - 2:
                    summary["trend"] = "declining"
                else:
                    summary["trend"] = "stable"

        db.close()

        return jsonify({
            "success": True,
            "server": server.to_dict(),
            "compliance_trend": compliance_trend,
            "summary": summary,
            "date_range": {
                "start": start_date.strftime('%Y-%m-%d'),
                "end": end_date.strftime('%Y-%m-%d'),
                "days": days
            }
        })

    except Exception as e:
        logger.error(f"Error getting server compliance trend: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Audit History Analytics
# ============================================================================

@analytics_bp.route('/api/analytics/audits/<int:audit_id>/history')
@require_api_key
def get_audit_history(audit_id):
    """
    Get execution history for a specific audit across all servers

    Query Parameters:
        days (int): Number of days to retrieve (default: 30)
        server_id (int): Filter by specific server
        cursor/limit: Pagination params

    Returns:
        {
            "success": true,
            "audit": {...},
            "history": [...],
            "summary": {
                "total_runs": 150,
                "success_rate": 95.5,
                "avg_compliance": 92.3
            }
        }
    """
    try:
        db = SessionLocal()

        # Verify audit exists
        audit = db.query(Audit).filter(Audit.id == audit_id).first()
        if not audit:
            db.close()
            return jsonify({"success": False, "error": f"Audit {audit_id} not found"}), 404

        # Parse query params
        days = min(int(request.args.get('days', 30)), 365)
        server_id = request.args.get('server_id', type=int)

        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Build query
        query = db.query(AuditHistorySummary).filter(
            and_(
                AuditHistorySummary.audit_id == audit_id,
                AuditHistorySummary.date >= start_date,
                AuditHistorySummary.date <= end_date
            )
        )

        # Filter by server if specified
        if server_id:
            query = query.filter(AuditHistorySummary.server_id == server_id)

        # Order by date descending
        query = query.order_by(desc(AuditHistorySummary.date))

        max_result_set_size = _get_analytics_max_result_set_size()
        total_records = query.count()
        if total_records > max_result_set_size:
            db.close()
            return jsonify({
                "success": False,
                "error": (
                    f"Result set too large ({total_records} records). Narrow filters "
                    f"(days/server_id) or increase analytics_max_result_set_size "
                    f"(current: {max_result_set_size})."
                )
            }), 400

        # Get all records for summary stats
        all_summaries = query.all()

        # Calculate summary statistics
        summary = {
            "total_runs": sum(s.total_runs for s in all_summaries),
            "total_checks": sum(s.total_checks for s in all_summaries),
            "success_rate": 0.0,
            "avg_compliance": 0.0
        }

        if all_summaries:
            successful = sum(s.successful_runs for s in all_summaries)
            total = sum(s.total_runs for s in all_summaries)
            summary["success_rate"] = round((successful / total * 100) if total > 0 else 0, 2)

            avg_compliance = sum(s.compliance_score or 0 for s in all_summaries) / len(all_summaries)
            summary["avg_compliance"] = round(avg_compliance, 2)

        # Apply pagination if requested
        if 'cursor' in request.args or 'limit' in request.args:
            params = PaginationParams.from_request(max_limit=500)
            result = paginate_query(query, params, id_field='id', endpoint='analytics.get_audit_history')

            history = [item.to_dict() for item in result['data']]

            db.close()

            return jsonify({
                "success": True,
                "audit": audit.to_dict(),
                "history": history,
                "summary": summary,
                "pagination": result['pagination'],
                "limits": {
                    "max_result_set_size": max_result_set_size,
                    "result_set_size": total_records
                },
                "date_range": {
                    "start": start_date.strftime('%Y-%m-%d'),
                    "end": end_date.strftime('%Y-%m-%d'),
                    "days": days
                }
            })
        else:
            # Return limited results
            limit = min(int(request.args.get('limit', 100)), 500)
            history = [item.to_dict() for item in all_summaries[:limit]]

            db.close()

            return jsonify({
                "success": True,
                "audit": audit.to_dict(),
                "history": history,
                "summary": summary,
                "total": len(history),
                "limits": {
                    "max_result_set_size": max_result_set_size,
                    "result_set_size": total_records
                },
                "date_range": {
                    "start": start_date.strftime('%Y-%m-%d'),
                    "end": end_date.strftime('%Y-%m-%d'),
                    "days": days
                }
            })

    except Exception as e:
        logger.error(f"Error getting audit history: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Trend Analysis
# ============================================================================

@analytics_bp.route('/api/analytics/trends')
@require_api_key
def get_trends():
    """
    Get trend analysis across all servers

    Query Parameters:
        days (int): Number of days to analyze (default: 30)
        metric (str): Metric to analyze (compliance|duration|checks) (default: compliance)

    Returns:
        {
            "success": true,
            "trends": {
                "overall_compliance": {...},
                "top_performers": [...],
                "bottom_performers": [...],
                "improving_servers": [...],
                "declining_servers": [...]
            }
        }
    """
    db = None
    try:
        db = SessionLocal()

        # Parse query params
        days = min(int(request.args.get('days', 30)), 365)
        _metric = request.args.get('metric', 'compliance')  # noqa: F841 - reserved for future use

        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Get recent compliance data for all servers
        compliance_records = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.date >= start_date,
                ServerComplianceHistory.date <= end_date
            )
        ).all()

        # Group by server
        server_stats = {}
        for record in compliance_records:
            if record.server_id not in server_stats:
                server_stats[record.server_id] = {
                    'server_id': record.server_id,
                    'server_name': record.server.name if record.server else f"Server {record.server_id}",
                    'scores': [],
                    'total_checks': 0,
                    'failed_checks': 0
                }

            stats = server_stats[record.server_id]
            stats['scores'].append(record.overall_compliance_score)
            stats['total_checks'] += record.total_checks
            stats['failed_checks'] += record.failed_checks

        # Calculate statistics for each server
        server_metrics = []
        for server_id, stats in server_stats.items():
            if not stats['scores']:
                continue

            scores = stats['scores']
            current_score = scores[-1]
            avg_score = sum(scores) / len(scores)

            # Calculate trend
            if len(scores) >= 4:
                mid = len(scores) // 2
                first_half = sum(scores[:mid]) / mid
                second_half = sum(scores[mid:]) / (len(scores) - mid)
                trend = second_half - first_half
            else:
                trend = 0

            server_metrics.append({
                'server_id': server_id,
                'server_name': stats['server_name'],
                'current_score': round(current_score, 2),
                'avg_score': round(avg_score, 2),
                'trend': round(trend, 2),
                'total_checks': stats['total_checks'],
                'failed_checks': stats['failed_checks'],
                'data_points': len(scores)
            })

        # Sort and categorize
        server_metrics.sort(key=lambda x: x['current_score'], reverse=True)

        top_performers = server_metrics[:5]  # Top 5
        bottom_performers = server_metrics[-5:]  # Bottom 5
        bottom_performers.reverse()

        improving = [s for s in server_metrics if s['trend'] > 2]
        improving.sort(key=lambda x: x['trend'], reverse=True)
        improving = improving[:5]

        declining = [s for s in server_metrics if s['trend'] < -2]
        declining.sort(key=lambda x: x['trend'])
        declining = declining[:5]

        # Overall compliance
        overall_compliance = {
            "avg_score": round(sum(s['avg_score'] for s in server_metrics) / len(server_metrics), 2) if server_metrics else 0,
            "total_servers": len(server_metrics),
            "total_checks": sum(s['total_checks'] for s in server_metrics),
            "total_failed": sum(s['failed_checks'] for s in server_metrics)
        }

        return jsonify({
            "success": True,
            "trends": {
                "overall_compliance": overall_compliance,
                "top_performers": top_performers,
                "bottom_performers": bottom_performers,
                "improving_servers": improving,
                "declining_servers": declining
            },
            "date_range": {
                "start": start_date.strftime('%Y-%m-%d'),
                "end": end_date.strftime('%Y-%m-%d'),
                "days": days
            }
        })

    except Exception as e:
        if db:
            try:
                db.rollback()
            except Exception as rollback_error:
                logger.debug(f"Trends rollback skipped after error: {rollback_error}")

        error_text = str(e).lower()
        if 'server_compliance_history' in error_text and 'does not exist' in error_text:
            logger.warning("Server compliance history table unavailable; returning empty trends payload")
            return jsonify({
                "success": True,
                "trends": {
                    "overall_compliance": {
                        "avg_score": 0,
                        "total_servers": 0,
                        "total_checks": 0,
                        "total_failed": 0
                    },
                    "top_performers": [],
                    "bottom_performers": [],
                    "improving_servers": [],
                    "declining_servers": []
                },
                "date_range": {
                    "start": (datetime.utcnow() - timedelta(days=min(int(request.args.get('days', 30)), 365))).strftime('%Y-%m-%d'),
                    "end": datetime.utcnow().strftime('%Y-%m-%d'),
                    "days": min(int(request.args.get('days', 30)), 365)
                }
            })

        logger.error(f"Error getting trends: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        if db:
            db.close()


# ============================================================================
# Compare to Previous Run (Trend Delta)
# ============================================================================

@analytics_bp.route('/api/analytics/servers/<int:server_id>/compare-runs')
@require_api_key
def compare_server_runs(server_id):
    """
    Compare latest audit run to previous run for a server - ideal for renewal/upsell demos.

    Shows improvement metrics like: "Your compliance improved from 72% to 89% (+17%)"

    Query Parameters:
        days (int): How far back to look for previous run (default: 90)
        audit_id (int): Filter to specific audit (optional, compares all if omitted)

    Returns:
        {
            "success": true,
            "server": {...},
            "comparison": {
                "current_run": {...},
                "previous_run": {...},
                "improvement": {
                    "compliance_delta": 17.0,
                    "compliance_trend": "improving",
                    "checks_fixed": 12,
                    "new_failures": 2,
                    "net_improvement": 10
                },
                "summary_text": "Compliance improved from 72% to 89% (+17%) with 12 issues resolved"
            }
        }
    """
    try:
        db = SessionLocal()

        # Verify server exists
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            db.close()
            return jsonify({"success": False, "error": f"Server {server_id} not found"}), 404

        # Parse query params
        days = min(int(request.args.get('days', 90)), 365)
        _audit_id = request.args.get('audit_id', type=int)  # noqa: F841 - reserved for future filtering

        # Calculate date range
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        # Get compliance history records
        query = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.server_id == server_id,
                ServerComplianceHistory.date >= start_date,
                ServerComplianceHistory.date <= end_date
            )
        ).order_by(desc(ServerComplianceHistory.date))

        records = query.all()

        if len(records) < 1:
            db.close()
            return jsonify({
                "success": True,
                "server": server.to_dict(),
                "comparison": None,
                "message": "No audit history found for comparison"
            })

        current_record = records[0]

        # Find previous record (at least 1 day before current)
        previous_record = None
        for record in records[1:]:
            if (current_record.date - record.date).days >= 1:
                previous_record = record
                break

        if not previous_record:
            db.close()
            return jsonify({
                "success": True,
                "server": server.to_dict(),
                "comparison": {
                    "current_run": {
                        "date": current_record.date.strftime('%Y-%m-%d'),
                        "compliance_score": round(current_record.overall_compliance_score, 1),
                        "total_checks": current_record.total_checks,
                        "passed_checks": current_record.passed_checks,
                        "failed_checks": current_record.failed_checks
                    },
                    "previous_run": None,
                    "improvement": None,
                    "summary_text": f"Current compliance: {current_record.overall_compliance_score:.1f}% (no previous run for comparison)"
                },
                "message": "Only one audit run found, no comparison available"
            })

        # Calculate improvement metrics
        compliance_delta = current_record.overall_compliance_score - previous_record.overall_compliance_score
        checks_fixed = max(0, previous_record.failed_checks - current_record.failed_checks)
        new_failures = max(0, current_record.failed_checks - previous_record.failed_checks)
        net_improvement = checks_fixed - new_failures

        # Determine trend
        if compliance_delta > 5:
            trend = "improving"
            trend_emoji = "📈"
        elif compliance_delta < -5:
            trend = "declining"
            trend_emoji = "📉"
        else:
            trend = "stable"
            trend_emoji = "➡️"

        # Generate summary text (for sales demos)
        days_between = (current_record.date - previous_record.date).days
        if compliance_delta > 0:
            summary = f"{trend_emoji} Compliance improved from {previous_record.overall_compliance_score:.1f}% to {current_record.overall_compliance_score:.1f}% (+{compliance_delta:.1f}%)"
            if checks_fixed > 0:
                summary += f" with {checks_fixed} issues resolved"
            summary += f" over {days_between} days"
        elif compliance_delta < 0:
            summary = f"{trend_emoji} Compliance decreased from {previous_record.overall_compliance_score:.1f}% to {current_record.overall_compliance_score:.1f}% ({compliance_delta:.1f}%)"
            if new_failures > 0:
                summary += f" with {new_failures} new failures"
        else:
            summary = f"{trend_emoji} Compliance stable at {current_record.overall_compliance_score:.1f}%"

        db.close()

        return jsonify({
            "success": True,
            "server": server.to_dict(),
            "comparison": {
                "current_run": {
                    "date": current_record.date.strftime('%Y-%m-%d'),
                    "compliance_score": round(current_record.overall_compliance_score, 1),
                    "total_checks": current_record.total_checks,
                    "passed_checks": current_record.passed_checks,
                    "failed_checks": current_record.failed_checks,
                    "warned_checks": current_record.warned_checks
                },
                "previous_run": {
                    "date": previous_record.date.strftime('%Y-%m-%d'),
                    "compliance_score": round(previous_record.overall_compliance_score, 1),
                    "total_checks": previous_record.total_checks,
                    "passed_checks": previous_record.passed_checks,
                    "failed_checks": previous_record.failed_checks,
                    "warned_checks": previous_record.warned_checks
                },
                "improvement": {
                    "compliance_delta": round(compliance_delta, 1),
                    "compliance_delta_pct": round(compliance_delta, 1),
                    "compliance_trend": trend,
                    "checks_fixed": checks_fixed,
                    "new_failures": new_failures,
                    "net_improvement": net_improvement,
                    "days_between_runs": days_between
                },
                "summary_text": summary
            }
        })

    except Exception as e:
        logger.error(f"Error comparing server runs: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@analytics_bp.route('/api/analytics/trend-report')
@require_api_key
def get_trend_report():
    """
    Get comprehensive trend report for all servers - executive summary with deltas.

    Perfect for renewal conversations showing org-wide improvement.

    Query Parameters:
        days (int): Analysis period (default: 30)

    Returns:
        {
            "success": true,
            "report": {
                "period": "Last 30 days",
                "overall_improvement": "+12.5%",
                "servers_improved": 8,
                "servers_declined": 2,
                "issues_resolved": 45,
                "new_issues": 12,
                "top_improvements": [...],
                "needs_attention": [...]
            }
        }
    """
    db = None
    try:
        db = SessionLocal()

        days = min(int(request.args.get('days', 30)), 365)
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        mid_date = end_date - timedelta(days=days // 2)

        # Get all compliance records
        records = db.query(ServerComplianceHistory).filter(
            and_(
                ServerComplianceHistory.date >= start_date,
                ServerComplianceHistory.date <= end_date
            )
        ).all()

        # Group by server and calculate metrics
        server_data = {}
        for record in records:
            if record.server_id not in server_data:
                server_data[record.server_id] = {
                    'server_id': record.server_id,
                    'server_name': record.server.name if record.server else f"Server {record.server_id}",
                    'first_half': [],
                    'second_half': [],
                    'all_records': []
                }

            data = server_data[record.server_id]
            data['all_records'].append(record)

            if record.date < mid_date:
                data['first_half'].append(record)
            else:
                data['second_half'].append(record)

        # Calculate improvements
        improvements = []
        total_issues_resolved = 0
        total_new_issues = 0

        for server_id, data in server_data.items():
            if not data['first_half'] or not data['second_half']:
                continue

            first_avg = sum(r.overall_compliance_score for r in data['first_half']) / len(data['first_half'])
            second_avg = sum(r.overall_compliance_score for r in data['second_half']) / len(data['second_half'])
            delta = second_avg - first_avg

            first_failures = sum(r.failed_checks for r in data['first_half']) / len(data['first_half'])
            second_failures = sum(r.failed_checks for r in data['second_half']) / len(data['second_half'])

            resolved = max(0, int(first_failures - second_failures))
            new_issues = max(0, int(second_failures - first_failures))

            total_issues_resolved += resolved
            total_new_issues += new_issues

            improvements.append({
                'server_id': server_id,
                'server_name': data['server_name'],
                'compliance_before': round(first_avg, 1),
                'compliance_after': round(second_avg, 1),
                'delta': round(delta, 1),
                'issues_resolved': resolved,
                'new_issues': new_issues,
                'trend': 'improving' if delta > 2 else ('declining' if delta < -2 else 'stable')
            })

        # Sort and categorize
        improvements.sort(key=lambda x: x['delta'], reverse=True)

        servers_improved = len([s for s in improvements if s['trend'] == 'improving'])
        servers_declined = len([s for s in improvements if s['trend'] == 'declining'])
        servers_stable = len([s for s in improvements if s['trend'] == 'stable'])

        overall_delta = sum(s['delta'] for s in improvements) / len(improvements) if improvements else 0

        return jsonify({
            "success": True,
            "report": {
                "period": f"Last {days} days",
                "period_start": start_date.strftime('%Y-%m-%d'),
                "period_end": end_date.strftime('%Y-%m-%d'),
                "summary": {
                    "overall_improvement": f"{'+' if overall_delta >= 0 else ''}{overall_delta:.1f}%",
                    "overall_delta": round(overall_delta, 1),
                    "total_servers": len(improvements),
                    "servers_improved": servers_improved,
                    "servers_stable": servers_stable,
                    "servers_declined": servers_declined,
                    "issues_resolved": total_issues_resolved,
                    "new_issues": total_new_issues,
                    "net_issues_change": total_issues_resolved - total_new_issues
                },
                "top_improvements": improvements[:5],
                "needs_attention": [s for s in improvements if s['trend'] == 'declining'][:5],
                "all_servers": improvements
            }
        })

    except Exception as e:
        if db:
            try:
                db.rollback()
            except Exception as rollback_error:
                logger.debug(f"Trend report rollback skipped after error: {rollback_error}")

        error_text = str(e).lower()
        if 'server_compliance_history' in error_text and 'does not exist' in error_text:
            logger.warning("Server compliance history table unavailable; returning empty trend report payload")
            days = min(int(request.args.get('days', 30)), 365)
            return jsonify({
                "success": True,
                "report": {
                    "period": f"Last {days} days",
                    "overall_improvement": "+0.0%",
                    "servers_improved": 0,
                    "servers_declined": 0,
                    "servers_stable": 0,
                    "issues_resolved": 0,
                    "new_issues": 0,
                    "top_improvements": [],
                    "needs_attention": []
                }
            })

        logger.error(f"Error generating trend report: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        if db:
            db.close()


# ============================================================================
# Administrative
# ============================================================================

@analytics_bp.route('/api/analytics/aggregate', methods=['POST'])
@require_api_key
def trigger_aggregation():
    """
    Manually trigger daily aggregation

    Request Body:
        {
            "target_date": "2026-02-05"  // Optional, defaults to yesterday
        }

    Returns:
        {
            "success": true,
            "summaries_created": 150,
            "compliance_records_created": 25
        }
    """
    try:
        data = request.json or {}
        target_date = data.get('target_date')

        if target_date:
            target_date = datetime.strptime(target_date, '%Y-%m-%d').date()
        else:
            target_date = (datetime.utcnow() - timedelta(days=1)).date()

        db = SessionLocal()

        # Run aggregations
        summaries_count = aggregate_daily_summaries(db, target_date)
        compliance_count = aggregate_server_compliance(db, target_date)

        db.close()

        logger.info(f"Manual aggregation completed for {target_date}: {summaries_count} summaries, {compliance_count} compliance records")

        return jsonify({
            "success": True,
            "target_date": target_date.strftime('%Y-%m-%d'),
            "summaries_created": summaries_count,
            "compliance_records_created": compliance_count
        })

    except Exception as e:
        logger.error(f"Error triggering aggregation: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


__all__ = ['analytics_bp']
