"""
History Routes - Execution History Management

Provides endpoints for:
- Listing execution history (/api/history)
- Getting history details (/api/history/<id>)
- Deleting history (/api/history, /api/history/<id>)
"""

from datetime import datetime
from flask import Blueprint, jsonify, request

# Import from config
from config import logger
from config import LOGS_DIR

# Import auth decorators
from auth_core import require_api_key, require_auth_and_permission

# Create blueprint
history_bp = Blueprint('history', __name__)

# HIGH-05 fix: File size limits to prevent memory issues
MAX_LOG_SIZE_FOR_PARSING = 10 * 1024 * 1024  # 10MB max for full parsing
MAX_LOG_SIZE_FOR_RESPONSE = 5 * 1024 * 1024  # 5MB max for API response
PARSING_CHUNK_SIZE = 64 * 1024  # 64KB chunks for streaming count


def _count_markers_streaming(file_path):
    """
    Count [PASS]/[WARN]/[FAIL] markers by streaming file in chunks (HIGH-05 fix)

    Returns:
        Tuple of (pass_count, warn_count, fail_count)
    """
    pass_count = warn_count = fail_count = 0

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            chunk_remainder = ''
            while True:
                chunk = f.read(PARSING_CHUNK_SIZE)
                if not chunk:
                    # Process any remainder
                    if chunk_remainder:
                        pass_count += chunk_remainder.count('[PASS]')
                        warn_count += chunk_remainder.count('[WARN]')
                        fail_count += chunk_remainder.count('[FAIL]')
                    break

                # Combine with previous chunk remainder to avoid missing markers at chunk boundaries
                data = chunk_remainder + chunk

                # Count markers
                pass_count += data.count('[PASS]')
                warn_count += data.count('[WARN]')
                fail_count += data.count('[FAIL]')

                # Keep last 20 chars for next iteration (longest marker is 6 chars)
                chunk_remainder = chunk[-20:] if len(chunk) >= 20 else chunk

    except Exception as e:
        logger.warning(f"Error counting markers in {file_path}: {e}")

    return pass_count, warn_count, fail_count


# ============================================================================
# Execution History
# ============================================================================
@history_bp.route('/api/history')
@require_auth_and_permission('view_history')
def get_history():
    """Get audit execution history"""
    try:
        filter_status = request.args.get('filter', '')
        history = []

        # Read execution logs from logs directory
        if LOGS_DIR.exists():
            for log_file in sorted(LOGS_DIR.glob('execution-*.log'), reverse=True):
                try:
                    # HIGH-05 fix: Check file size before processing
                    file_size = log_file.stat().st_size
                    if file_size > MAX_LOG_SIZE_FOR_PARSING:
                        logger.warning(f"Skipping large log file {log_file}: {file_size} bytes")
                        continue

                    # HIGH-05 fix: Use streaming marker counting for efficiency
                    pass_count, warn_count, fail_count = _count_markers_streaming(log_file)
                    audit_count = pass_count + warn_count + fail_count

                    # Get timestamp from file stats
                    timestamp = log_file.stat().st_mtime

                    # Determine status
                    if fail_count > 0:
                        status = 'error'
                    elif warn_count > 0:
                        status = 'warning'
                    else:
                        status = 'success'

                    # Filter by status if requested
                    if filter_status and status != filter_status:
                        continue

                    history.append({
                        'id': log_file.stem,
                        'timestamp': datetime.fromtimestamp(timestamp).isoformat(),
                        'plan_name': log_file.stem.replace('execution-', ''),
                        'audit_count': audit_count,
                        'pass_count': pass_count,
                        'warn_count': warn_count,
                        'fail_count': fail_count,
                        'status': status
                    })

                    # Limit to most recent 100
                    if len(history) >= 100:
                        break
                except Exception as e:
                    logger.warning(f"Failed to parse {log_file}: {e}")
                    continue

        return jsonify(history)
    except Exception as e:
        logger.error(f"Error getting history: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@history_bp.route('/api/history/<history_id>')
@require_auth_and_permission('view_history')
def get_history_details(history_id):
    """Get detailed history for a specific execution"""
    try:
        # Validate history_id to prevent path traversal
        if '..' in history_id or '/' in history_id or '\\' in history_id:
            return jsonify({"success": False, "error": "Invalid history ID"}), 400

        log_file = LOGS_DIR / f"{history_id}.log"
        if not log_file.exists():
            return jsonify({"success": False, "error": "History not found"}), 404

        # HIGH-05 fix: Check file size before reading
        file_size = log_file.stat().st_size
        if file_size > MAX_LOG_SIZE_FOR_RESPONSE:
            # Return truncated content with warning
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(MAX_LOG_SIZE_FOR_RESPONSE)
            content += f"\n\n... [TRUNCATED - file size {file_size} bytes exceeds limit] ..."
            truncated = True
        else:
            content = log_file.read_text()
            truncated = False

        return jsonify({
            "success": True,
            "id": history_id,
            "content": content,
            "truncated": truncated,
            "file_size": file_size,
            "timestamp": datetime.fromtimestamp(log_file.stat().st_mtime).isoformat()
        })
    except Exception as e:
        logger.error(f"Error getting history details for {history_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@history_bp.route('/api/history', methods=['DELETE'])
@require_auth_and_permission('delete_all_data')
def clear_history():
    """Clear all audit history"""
    try:
        count = 0
        if LOGS_DIR.exists():
            for log_file in LOGS_DIR.glob('execution-*.log'):
                log_file.unlink()
                count += 1

        logger.warning(f"All history cleared: {count} items deleted by API request")
        return jsonify({"success": True, "message": f"Cleared {count} history items"})
    except Exception as e:
        logger.error(f"Error clearing history: {e}")
        return jsonify({"success": False, "error": "Failed to clear history"}), 500


@history_bp.route('/api/history/servers/<int:server_id>/audits')
@require_auth_and_permission('view_history')
def get_server_audit_history(server_id):
    """
    Get audit execution history for a specific server

    Returns a list of audit executions filtered by server_id

    Args:
        server_id: The server ID to filter by

    Query Parameters:
        limit: Maximum results to return (default: 50)
        status: Filter by status (success, failure, running)

    Returns:
        JSON response with audit history for the specified server
    """
    from config import SessionLocal
    from models.database import AuditExecution, Server, Audit

    try:
        db = SessionLocal()
        try:
            # Verify server exists
            server = db.query(Server).filter(Server.id == server_id).first()
            if not server:
                return jsonify({"success": False, "error": f"Server {server_id} not found"}), 404

            # Get limit and status filter
            limit = min(int(request.args.get('limit', 50)), 200)
            status_filter = request.args.get('status', '')

            # Query executions for this server
            query = db.query(AuditExecution).filter(AuditExecution.server_id == server_id)

            if status_filter:
                query = query.filter(AuditExecution.status == status_filter)

            executions = query.order_by(AuditExecution.executed_at.desc()).limit(limit).all()

            # Build response
            audits = []
            for exec in executions:
                audit = db.query(Audit).filter(Audit.id == exec.audit_id).first()
                audits.append({
                    'id': exec.id,
                    'audit_id': exec.audit_id,
                    'audit_name': audit.name if audit else 'Unknown',
                    'server_id': exec.server_id,
                    'status': exec.status,
                    'exit_code': exec.exit_code,
                    'duration_seconds': exec.duration_seconds,
                    'executed_at': exec.executed_at.isoformat() if exec.executed_at else None,
                    'completed_at': exec.completed_at.isoformat() if exec.completed_at else None,
                    'executed_by': exec.executed_by
                })

            return jsonify({
                "success": True,
                "server_id": server_id,
                "server_hostname": server.hostname,
                "audits": audits,
                "count": len(audits)
            })
        finally:
            db.close()

    except Exception as e:
        logger.error(f"Error getting server audit history: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@history_bp.route('/api/history/<history_id>', methods=['DELETE'])
@require_auth_and_permission('view_history')
def delete_history_item(history_id):
    """Delete a specific history item"""
    try:
        # Validate history_id to prevent path traversal
        if '..' in history_id or '/' in history_id or '\\' in history_id:
            logger.warning(f"Path traversal attempt detected in history_id: {history_id}")
            return jsonify({"success": False, "error": "Invalid history ID"}), 400

        # Sanitize to alphanumeric and common safe characters
        import re
        if not re.match(r'^[a-zA-Z0-9_-]+$', history_id):
            return jsonify({"success": False, "error": "Invalid history ID format"}), 400

        log_file = LOGS_DIR / f"{history_id}.log"

        # Additional check: ensure resolved path is within LOGS_DIR
        if not str(log_file.resolve()).startswith(str(LOGS_DIR.resolve())):
            logger.warning(f"Path traversal attempt: {history_id} resolved outside LOGS_DIR")
            return jsonify({"success": False, "error": "Invalid path"}), 400

        if not log_file.exists():
            return jsonify({"success": False, "error": "History not found"}), 404

        log_file.unlink()
        logger.info(f"History item {history_id} deleted by API request")
        return jsonify({"success": True, "message": "History deleted"})
    except Exception as e:
        logger.error(f"Error deleting history item {history_id}: {e}")
        return jsonify({"success": False, "error": "Failed to delete history item"}), 500


@history_bp.route('/api/history/unified')
@require_auth_and_permission('view_history')
def get_unified_history():
    """
    Get unified audit execution history for both servers and hypervisors

    Query Parameters:
        limit: Maximum results to return (default: 50)
        source_type: Filter by source type ('servers', 'hypervisors', or empty for all)
        status: Filter by status (success, failure, running)

    Returns:
        JSON response with combined audit history
    """
    from config import SessionLocal

    try:
        db = SessionLocal()
        try:
            # Get parameters
            limit = min(int(request.args.get('limit', 50)), 200)
            source_type = request.args.get('source_type', '').lower()
            status_filter = request.args.get('status', '')

            results = []

            # Get server audit executions
            if source_type in ('', 'servers', 'all'):
                try:
                    from models.database import AuditExecution, Server, Audit
                    query = db.query(AuditExecution)
                    if status_filter:
                        query = query.filter(AuditExecution.status == status_filter)
                    server_execs = query.order_by(AuditExecution.executed_at.desc()).limit(limit).all()

                    for exec in server_execs:
                        server = db.query(Server).filter(Server.id == exec.server_id).first()
                        audit = db.query(Audit).filter(Audit.id == exec.audit_id).first()
                        results.append({
                            'id': f'server_{exec.id}',
                            'source_type': 'server',
                            'source_id': exec.server_id,
                            'source_name': server.hostname if server else 'Unknown',
                            'audit_name': audit.name if audit else 'Unknown',
                            'status': exec.status,
                            'exit_code': exec.exit_code,
                            'duration_seconds': exec.duration_seconds,
                            'executed_at': exec.executed_at.isoformat() if exec.executed_at else None,
                            'completed_at': exec.completed_at.isoformat() if exec.completed_at else None,
                            'executed_by': exec.executed_by,
                            'checks_passed': None,
                            'checks_warned': None,
                            'checks_failed': None
                        })
                except ImportError:
                    logger.debug("Server audit models not available")

            # Get hypervisor audit executions
            if source_type in ('', 'hypervisors', 'all'):
                try:
                    from models.database import HypervisorAuditExecution, Hypervisor
                    query = db.query(HypervisorAuditExecution)
                    if status_filter:
                        query = query.filter(HypervisorAuditExecution.status == status_filter)
                    hv_execs = query.order_by(HypervisorAuditExecution.started_at.desc()).limit(limit).all()

                    for exec in hv_execs:
                        hv = db.query(Hypervisor).filter(Hypervisor.id == exec.hypervisor_id).first()
                        results.append({
                            'id': f'hypervisor_{exec.id}',
                            'source_type': 'hypervisor',
                            'source_id': exec.hypervisor_id,
                            'source_name': hv.name if hv else 'Unknown',
                            'audit_name': exec.audit_type or 'security',
                            'status': exec.status,
                            'exit_code': exec.exit_code,
                            'duration_seconds': exec.duration_seconds,
                            'executed_at': exec.started_at.isoformat() if exec.started_at else None,
                            'completed_at': exec.completed_at.isoformat() if exec.completed_at else None,
                            'executed_by': exec.triggered_by,
                            'checks_passed': exec.checks_passed,
                            'checks_warned': exec.checks_warned,
                            'checks_failed': exec.checks_failed
                        })
                except ImportError:
                    logger.debug("Hypervisor audit models not available")

            # Sort combined results by executed_at descending
            results.sort(key=lambda x: x['executed_at'] or '', reverse=True)

            # Apply final limit
            results = results[:limit]

            return jsonify({
                "success": True,
                "executions": results,
                "count": len(results)
            })
        finally:
            db.close()

    except Exception as e:
        logger.error(f"Error getting unified history: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
