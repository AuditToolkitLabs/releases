"""
Hypervisor Agent API Routes

Server-side API endpoints for hypervisor-specific fleet agents.
These agents operate exclusively via API communication - no SSH/WinRM required.

Core Design:
- Agents poll for commands (scheduled audits or manual triggers)
- Agents push results to core server in JSON format
- No persistent storage on agent - all data flows to core server
- Compatible with agents/html-standalone and managed API agent patterns

Endpoints:
  # Health & Status
  GET  /api/hypervisor-agent/health            - API health check
  GET  /api/hypervisor-agent/ping              - Simple ping
  GET  /api/hypervisor-agent/openapi           - OpenAPI specification

  # Registration & Management
  POST /api/hypervisor-agent/register          - Agent registration
  GET  /api/hypervisor-agent                   - List all registered agents
  GET  /api/hypervisor-agent/{id}              - Get agent details
  DELETE /api/hypervisor-agent/{id}            - Unregister agent

  # Heartbeat & Commands
  POST /api/hypervisor-agent/{id}/heartbeat    - Heartbeat and command retrieval
  GET  /api/hypervisor-agent/{id}/commands     - Get pending commands
  POST /api/hypervisor-agent/{id}/commands     - Queue a command
  POST /api/hypervisor-agent/{id}/commands/{cmd}/ack - Acknowledge command

  # Results & Discovery (Push from Agent)
  POST /api/hypervisor-agent/{id}/results      - Submit audit results
  POST /api/hypervisor-agent/{id}/discovery    - Submit discovery data

  # Configuration
  GET  /api/hypervisor-agent/{id}/config       - Get agent configuration
  PUT  /api/hypervisor-agent/{id}/config       - Update agent configuration

  # Audit History (Read from Core Server)
  GET  /api/hypervisor-agent/{id}/audits       - Get audit history
  GET  /api/hypervisor-agent/{id}/audits/{audit_id} - Get specific audit

  # Admin
  GET  /api/hypervisor-agent/stats             - Agent statistics
  POST /api/hypervisor-agent/{id}/trigger-audit - Trigger audit
  POST /api/hypervisor-agent/bulk/trigger-audit - Bulk trigger audits
  POST /api/hypervisor-agent/{id}/rotate-key    - Rotate agent API key
"""

from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from functools import wraps
import hashlib
import hmac
import logging
import os
import secrets
import shutil
import time
from auth_core import conditional_limit
from api.upload_rate_limits import get_hypervisor_upload_limit
from api.agent_pathing import get_standalone_agent_dir, get_hypervisor_agent_dir

# Result encryption (Phase 2 - unified across all agents)
try:
    from api.result_encryption import ResultEncryption
    _ENCRYPTION_AVAILABLE = True
except ImportError:
    _ENCRYPTION_AVAILABLE = False

# Database models for durable audit result persistence
try:
    import json as _json
    from models.database import Hypervisor, HypervisorAuditExecution
    from config import get_db_session as _get_db_session
    DATABASE_AVAILABLE = True
except Exception:
    Hypervisor = None
    HypervisorAuditExecution = None
    _get_db_session = lambda: None  # noqa: E731
    DATABASE_AVAILABLE = False

# Flask-Login for user authentication
try:
    from flask_login import current_user
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    FLASK_LOGIN_AVAILABLE = False
    current_user = None

# Feature licensing for enterprise controls
try:
    from services_pkg.services.feature_licensing import (
        Feature,
        LicenseTier,
        get_feature_service,
    )
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    Feature = None
    LicenseTier = None

logger = logging.getLogger(__name__)

# =============================================================================
# Enterprise License & Anti-Abuse Protection
# =============================================================================

# Rate limit tracking (in production, use Redis)
_download_rate_limits = {}  # {user_id: {'count': N, 'reset_at': datetime}}
_registration_rate_limits = {}

# Audit trail for downloads (in production, persist to database)
_download_audit_trail = []


def _get_current_user_id() -> str:
    """Get current user ID for tracking."""
    if FLASK_LOGIN_AVAILABLE and current_user and current_user.is_authenticated:
        return str(current_user.id)
    return request.remote_addr or 'anonymous'


def _get_current_user_org() -> str:
    """Get current user's organization for license embedding."""
    if FLASK_LOGIN_AVAILABLE and current_user and current_user.is_authenticated:
        return getattr(current_user, 'organization', 'default')
    return 'default'


def _check_enterprise_license(feature_name: str = None) -> dict:
    """
    Check if user has enterprise license for hypervisor agent features.

    Returns:
        dict: {'allowed': bool, 'reason': str, 'tier': str}
    """
    # Development/testing mode bypass - set AUDIT_TOOLKIT_DEV_MODE=1 to skip license checks
    if os.getenv('AUDIT_TOOLKIT_DEV_MODE', '').lower() in ('1', 'true', 'yes'):
        return {'allowed': True, 'reason': 'dev_mode_bypass', 'tier': 'enterprise'}

    if not FEATURE_LICENSING_AVAILABLE:
        # Feature licensing not available - allow in dev mode
        return {'allowed': True, 'reason': 'dev_mode', 'tier': 'enterprise'}

    try:
        service = get_feature_service()
        user_id = _get_current_user_id()

        # Check specific feature if provided
        if feature_name and hasattr(Feature, feature_name):
            feature = getattr(Feature, feature_name)
            status = service.is_feature_available(feature, user_id)
            return {
                'allowed': status.get('available', False),
                'reason': status.get('reason', 'unknown'),
                'tier': status.get('tier', 'free'),
                'upgrade_tier': status.get('upgrade_tier', 'enterprise'),
            }

        # Default: check HYPERVISOR_AGENT_DOWNLOAD feature
        if hasattr(Feature, 'HYPERVISOR_AGENT_DOWNLOAD'):
            status = service.is_feature_available(Feature.HYPERVISOR_AGENT_DOWNLOAD, user_id)
            return {
                'allowed': status.get('available', False),
                'reason': status.get('reason', 'unknown'),
                'tier': status.get('tier', 'free'),
                'upgrade_tier': status.get('upgrade_tier', 'enterprise'),
            }

        return {'allowed': True, 'reason': 'feature_not_configured', 'tier': 'unknown'}

    except Exception as e:
        logger.warning(f"License check failed: {e}, allowing access")
        return {'allowed': True, 'reason': 'check_failed', 'tier': 'unknown'}


def _check_rate_limit(action: str, limits: dict = None) -> dict:
    """
    Check rate limits for download/registration actions.

    Args:
        action: 'download' or 'registration'
        limits: Optional custom limits {'per_day': N, 'per_month': N}

    Returns:
        dict: {'allowed': bool, 'remaining': int, 'reset_at': datetime}
    """
    user_id = _get_current_user_id()
    now = datetime.now()

    # Default limits - Enterprise gets higher limits
    default_limits = {
        'download': {'per_day': 5, 'per_month': 20},
        'registration': {'per_day': 10, 'per_month': 50},
    }

    action_limits = limits or default_limits.get(action, {'per_day': 5, 'per_month': 20})
    rate_store = _download_rate_limits if action == 'download' else _registration_rate_limits

    # Get or create user rate data
    if user_id not in rate_store:
        rate_store[user_id] = {
            'daily_count': 0,
            'monthly_count': 0,
            'daily_reset': now + timedelta(days=1),
            'monthly_reset': now + timedelta(days=30),
        }

    user_rates = rate_store[user_id]

    # Reset counters if period expired
    if now >= user_rates['daily_reset']:
        user_rates['daily_count'] = 0
        user_rates['daily_reset'] = now + timedelta(days=1)

    if now >= user_rates['monthly_reset']:
        user_rates['monthly_count'] = 0
        user_rates['monthly_reset'] = now + timedelta(days=30)

    # Check limits
    if user_rates['daily_count'] >= action_limits['per_day']:
        return {
            'allowed': False,
            'reason': 'daily_limit_exceeded',
            'remaining_daily': 0,
            'remaining_monthly': max(0, action_limits['per_month'] - user_rates['monthly_count']),
            'reset_at': user_rates['daily_reset'].isoformat(),
        }

    if user_rates['monthly_count'] >= action_limits['per_month']:
        return {
            'allowed': False,
            'reason': 'monthly_limit_exceeded',
            'remaining_daily': 0,
            'remaining_monthly': 0,
            'reset_at': user_rates['monthly_reset'].isoformat(),
        }

    return {
        'allowed': True,
        'remaining_daily': action_limits['per_day'] - user_rates['daily_count'],
        'remaining_monthly': action_limits['per_month'] - user_rates['monthly_count'],
    }


def _record_rate_limit_usage(action: str):
    """Record usage for rate limiting after successful action."""
    user_id = _get_current_user_id()
    rate_store = _download_rate_limits if action == 'download' else _registration_rate_limits

    if user_id in rate_store:
        rate_store[user_id]['daily_count'] += 1
        rate_store[user_id]['monthly_count'] += 1


def _record_download_audit(os_type: str, platform: str, format_type: str, success: bool):
    """
    Record download action for audit trail.

    In production, this should write to database/SIEM.
    """
    user_id = _get_current_user_id()
    org = _get_current_user_org()

    audit_entry = {
        'timestamp': datetime.now().isoformat(),
        'action': 'hypervisor_agent_download',
        'user_id': user_id,
        'organization': org,
        'os_type': os_type,
        'platform': platform,
        'format': format_type,
        'success': success,
        'ip_address': request.remote_addr,
        'user_agent': request.headers.get('User-Agent', 'unknown')[:100],
    }

    _download_audit_trail.append(audit_entry)

    # Keep only last 1000 entries in memory (production should persist)
    if len(_download_audit_trail) > 1000:
        _download_audit_trail.pop(0)

    logger.info(f"AUDIT: {audit_entry['action']} by {user_id} - {'SUCCESS' if success else 'FAILED'}")

hypervisor_agent_bp = Blueprint('hypervisor_agent', __name__)

# API Version
API_VERSION = "1.0.0"
API_BUILD = "2026.02.19"


def _is_superadmin() -> bool:
    """
    Check if current user is a SuperAdmin.

    Script-only downloads are restricted to SuperAdmin/developers only
    to prevent customers from bypassing the core tool.
    """
    if not FLASK_LOGIN_AVAILABLE:
        return True  # No auth = dev mode
    if not current_user or not current_user.is_authenticated:
        return False
    return getattr(current_user, 'role', '') == 'SuperAdmin'


def _get_result_ingest_limits():
    """Get ingestion guardrail limits from security settings."""
    defaults = {
        'max_body_kb': 2048,
        'max_checks_per_result': 500,
        'max_output_chars': 200000,
    }
    try:
        from security_settings import get_security_setting
        return {
            'max_body_kb': max(128, int(get_security_setting('agent_result_ingest_max_body_kb', defaults['max_body_kb']))),
            'max_checks_per_result': max(1, int(get_security_setting('agent_result_ingest_max_checks_per_result', defaults['max_checks_per_result']))),
            'max_output_chars': max(1000, int(get_security_setting('agent_result_ingest_max_output_chars', defaults['max_output_chars']))),
        }
    except Exception:
        return defaults


def _get_discovery_ingest_limits():
    """Get discovery ingestion guardrail limits from security settings."""
    defaults = {
        'max_body_kb': 2048,
        'max_items_per_collection': 5000,
        'max_total_items': 20000,
    }
    try:
        from security_settings import get_security_setting
        return {
            'max_body_kb': max(128, int(get_security_setting('agent_discovery_ingest_max_body_kb', defaults['max_body_kb']))),
            'max_items_per_collection': max(10, int(get_security_setting('agent_discovery_ingest_max_items_per_collection', defaults['max_items_per_collection']))),
            'max_total_items': max(100, int(get_security_setting('agent_discovery_ingest_max_total_items', defaults['max_total_items']))),
        }
    except Exception:
        return defaults


def _is_result_ingest_blocked_by_disk_watermark():
    """Check if ingest should be blocked because free disk is below configured watermark."""
    defaults = {
        'enabled': True,
        'min_free_mb': 1024,
        'min_free_pct': 5,
    }
    try:
        from security_settings import get_security_setting
        enabled = bool(get_security_setting('agent_result_ingest_disk_guard_enabled', defaults['enabled']))
        min_free_mb = max(128, int(get_security_setting('agent_result_ingest_min_free_disk_mb', defaults['min_free_mb'])))
        min_free_pct = max(1, int(get_security_setting('agent_result_ingest_min_free_disk_pct', defaults['min_free_pct'])))
    except Exception:
        enabled = defaults['enabled']
        min_free_mb = defaults['min_free_mb']
        min_free_pct = defaults['min_free_pct']

    if not enabled:
        return False, {}

    try:
        from config import ROOT_DIR
        target_dir = ROOT_DIR / 'data'
        os.makedirs(target_dir, exist_ok=True)
        usage = shutil.disk_usage(target_dir)
    except Exception:
        usage = shutil.disk_usage('.')
        target_dir = os.path.abspath('.')

    free_mb = usage.free // (1024 * 1024)
    free_pct = (usage.free / usage.total * 100) if usage.total > 0 else 0
    blocked = free_mb < min_free_mb or free_pct < min_free_pct

    details = {
        'free_mb': int(free_mb),
        'free_pct': round(free_pct, 2),
        'min_free_mb': min_free_mb,
        'min_free_pct': min_free_pct,
        'check_path': str(target_dir),
    }
    return blocked, details


# =============================================================================
# Persistent Storage for Hypervisor Agents
# =============================================================================

def _get_storage_path():
    """Get path to hypervisor agent storage file"""
    from config import ROOT_DIR
    return ROOT_DIR / 'settings' / 'hypervisor_agents.json'


def _load_agents_from_storage():
    """Load agents from persistent storage on startup"""
    global _agents, _commands, _next_command_id
    storage_path = _get_storage_path()

    try:
        if storage_path.exists():
            import json
            with open(storage_path, 'r') as f:
                data = json.load(f)

            _agents = data.get('agents', {})
            _next_command_id = data.get('next_command_id', 1)

            # Initialize commands for each loaded agent
            for agent_id in _agents:
                if agent_id not in _commands:
                    _commands[agent_id] = []

            logger.info(f"Loaded {len(_agents)} hypervisor agents from persistent storage")
            return True
    except Exception as e:
        logger.error(f"Error loading hypervisor agents from storage: {e}")

    return False


def _save_agents_to_storage():
    """Persist agents to storage file"""
    storage_path = _get_storage_path()

    try:
        import json

        # Ensure directory exists
        storage_path.parent.mkdir(parents=True, exist_ok=True)

        # Prepare data for storage (exclude transient data)
        data = {
            'agents': _agents,
            'next_command_id': _next_command_id,
            'updated_at': datetime.now().isoformat()
        }

        with open(storage_path, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        logger.debug(f"Saved {len(_agents)} hypervisor agents to storage")
        return True

    except Exception as e:
        logger.error(f"Error saving hypervisor agents to storage: {e}")
        return False


def get_all_hypervisor_agent_keys():
    """
    Get all hypervisor agent API keys (for admin panel integration).

    Returns list of key info dicts (without exposing actual keys).
    """
    keys = []
    for agent_id, agent_data in _agents.items():
        # Calculate key status based on expiry
        key_expires_at = agent_data.get('key_expires_at')
        key_status = agent_data.get('status', 'unknown')
        expires_in_days = None

        if key_expires_at:
            try:
                expires = datetime.fromisoformat(key_expires_at)
                now = datetime.now()
                if now > expires:
                    key_status = 'expired'
                else:
                    expires_in_days = (expires - now).days
                    # Check if expiring soon (within warning period)
                    from security_settings import get_security_setting
                    warning_days = get_security_setting('hypervisor_key_expiry_warning_days') or 14
                    if expires_in_days <= warning_days:
                        key_status = 'expiring_soon'
            except (ValueError, TypeError):
                pass

        keys.append({
            'id': f'hypervisor_{agent_id}',
            'agent_id': agent_id,
            'name': f"Hypervisor Agent: {agent_data.get('hypervisor_name', agent_id)}",
            'type': 'hypervisor_agent',
            'description': f"{agent_data.get('platform', 'unknown')} agent for {agent_data.get('hypervisor_name', 'unknown')}",
            'platform': agent_data.get('platform'),
            'hostname': agent_data.get('hostname'),
            'hypervisor_id': agent_data.get('hypervisor_id'),
            'created': agent_data.get('registered_at'),
            'last_used': agent_data.get('last_heartbeat'),
            'status': key_status,
            'has_key': bool(agent_data.get('token_hash')),
            'encrypted': agent_data.get('token_storage') == 'encrypted_keystore',
            'key_validity_days': agent_data.get('key_validity_days', 90),
            'key_expires_at': key_expires_at,
            'expires_in_days': expires_in_days,
            'key_created_at': agent_data.get('key_created_at'),
            'scope': ['hypervisor_agent']
        })
    return keys


def rotate_hypervisor_agent_key(agent_id: str, rotated_by: str = None):
    """
    Rotate API key for a hypervisor agent.

    Updates key in encrypted keystore with fallback to local hash storage.

    Args:
        agent_id: The agent ID to rotate key for
        rotated_by: Username who initiated rotation

    Returns:
        dict with new_key on success, or error
    """
    if agent_id not in _agents:
        return {'success': False, 'error': 'Agent not found'}

    # Generate new key
    new_key = secrets.token_urlsafe(32)
    new_hash = _hash_key(new_key)
    storage_method = 'local_hash'

    # Try to update key in encrypted keystore
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        rotated_key = keystore.rotate_key(
            key_type='hypervisor_agent',
            key_id=agent_id,
            rotated_by=rotated_by or 'system'
        )
        if rotated_key:
            new_key = rotated_key
            new_hash = _hash_key(new_key)
            storage_method = 'encrypted_keystore'
            logger.info(f"Hypervisor agent token rotated in encrypted keystore: {agent_id}")
    except ImportError:
        logger.debug("Keystore not available, using local hash storage")
    except Exception as e:
        logger.warning(f"Could not rotate token in keystore: {e}, using local hash")

    # Store old hash for grace period (optional)
    old_hash = _agents[agent_id].get('token_hash')
    if old_hash:
        _agents[agent_id]['previous_token_hash'] = old_hash
        _agents[agent_id]['key_rotated_at'] = datetime.now().isoformat()

    # Set new key hash (always maintain for fast auth lookups)
    _agents[agent_id]['token_hash'] = new_hash
    _agents[agent_id]['key_updated_by'] = rotated_by
    _agents[agent_id]['token_storage'] = storage_method
    _agents[agent_id]['key_created_at'] = datetime.now().isoformat()

    # Update key expiry based on validity period
    key_validity_days = _agents[agent_id].get('key_validity_days', 90)
    if key_validity_days > 0:
        new_expires_at = (datetime.now() + timedelta(days=key_validity_days)).isoformat()
        _agents[agent_id]['key_expires_at'] = new_expires_at
    else:
        _agents[agent_id]['key_expires_at'] = None  # Never expires

    # Persist changes
    _save_agents_to_storage()

    logger.info(f"Rotated API key for hypervisor agent {agent_id} by {rotated_by}")

    return {
        'success': True,
        'new_key': new_key,
        'agent_id': agent_id,
        'token_encrypted': storage_method == 'encrypted_keystore',
        'key_expires_at': _agents[agent_id].get('key_expires_at'),
        'key_validity_days': key_validity_days,
        'message': 'Key rotated successfully. Update the agent with the new key.'
    }


def revoke_hypervisor_agent_key(agent_id: str, revoked_by: str = None):
    """
    Revoke API key for a hypervisor agent (effectively unregisters it).

    Removes key from encrypted keystore and invalidates local hash.

    Args:
        agent_id: The agent ID to revoke
        revoked_by: Username who initiated revocation

    Returns:
        dict with success status
    """
    if agent_id not in _agents:
        return {'success': False, 'error': 'Agent not found'}

    # Try to delete from encrypted keystore
    try:
        from keystore import get_keystore
        keystore = get_keystore()
        keystore.delete_key('hypervisor_agent', agent_id)
        logger.info(f"Deleted hypervisor agent token from keystore: {agent_id}")
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Keystore delete for {agent_id}: {e}")

    # Clear the token hash (invalidates the key)
    _agents[agent_id]['token_hash'] = None
    _agents[agent_id]['previous_token_hash'] = None
    _agents[agent_id]['status'] = 'revoked'
    _agents[agent_id]['revoked_at'] = datetime.now().isoformat()
    _agents[agent_id]['revoked_by'] = revoked_by
    _agents[agent_id]['token_storage'] = None

    # Persist changes
    _save_agents_to_storage()

    logger.warning(f"Revoked API key for hypervisor agent {agent_id} by {revoked_by}")

    return {
        'success': True,
        'agent_id': agent_id,
        'message': 'Agent key revoked. Agent will no longer be able to authenticate.'
    }


def delete_hypervisor_agent(agent_id: str, deleted_by: str = None):
    """
    Completely remove a hypervisor agent from storage.

    Removes key from encrypted keystore and all local storage.

    Args:
        agent_id: The agent ID to delete
        deleted_by: Username who initiated deletion

    Returns:
        dict with success status
    """
    if agent_id not in _agents:
        return {'success': False, 'error': 'Agent not found'}

    agent_name = _agents[agent_id].get('hypervisor_name', agent_id)

    # Try to delete from encrypted keystore
    try:
        from keystore import get_keystore
        keystore = get_keystore()
        keystore.delete_key('hypervisor_agent', agent_id)
        logger.info(f"Deleted hypervisor agent token from keystore: {agent_id}")
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Keystore delete for {agent_id}: {e}")

    # Remove from memory
    del _agents[agent_id]
    if agent_id in _commands:
        del _commands[agent_id]
    if agent_id in _audit_cache:
        del _audit_cache[agent_id]

    # Persist changes
    _save_agents_to_storage()

    logger.warning(f"Deleted hypervisor agent {agent_id} ({agent_name}) by {deleted_by}")

    return {
        'success': True,
        'agent_id': agent_id,
        'message': f'Agent {agent_name} deleted successfully.'
    }


# =============================================================================
# In-Memory Storage (Session cache - results pushed to core server)
# =============================================================================

# Registered agents: {agent_id: agent_data}
_agents = {}

# Pending commands: {agent_id: [commands]}
_commands = {}

# Command acknowledgments: {command_id: ack_data}
_command_acks = {}

# Agent API keys for validation: {agent_id: hashed_key}
_agent_keys = {}

# Audit results cache (recent only - full history in core server DB)
_audit_cache = {}  # {agent_id: [recent_audits]}
MAX_CACHE_SIZE = 10  # Keep last N audits per agent in memory

# Auto-incrementing command ID
_next_command_id = 1

# Load agents from persistent storage on module import
_load_agents_from_storage()

# Default agent configuration template
DEFAULT_AGENT_CONFIG = {
    'poll_interval': 60,
    'audits_enabled': True,
    'auto_discovery': True,
    'categories': ['security', 'network', 'storage', 'compute'],
    'result_format': 'json',
    'compress_results': False,
    'retry_on_failure': True,
    'max_retries': 3,
    'heartbeat_timeout': 300
}


def _get_next_command_id():
    global _next_command_id
    cmd_id = _next_command_id
    _next_command_id += 1
    return cmd_id


def _hash_key(key: str) -> str:
    """Hash an API key for secure storage"""
    return hashlib.sha256(key.encode()).hexdigest()


def _validate_agent_token(agent_id: str, token: str) -> bool:
    """Validate agent token against stored hash"""
    if agent_id not in _agents:
        return False
    stored_hash = _agents[agent_id].get('token_hash')
    if not stored_hash:
        return True  # Legacy: no hash stored, accept token
    return hmac.compare_digest(stored_hash, _hash_key(token))


def _cache_audit_result(agent_id: str, result: dict):
    """Cache recent audit result (memory only - full storage on core server)"""
    if agent_id not in _audit_cache:
        _audit_cache[agent_id] = []

    _audit_cache[agent_id].insert(0, result)

    # Trim to max cache size
    if len(_audit_cache[agent_id]) > MAX_CACHE_SIZE:
        _audit_cache[agent_id] = _audit_cache[agent_id][:MAX_CACHE_SIZE]


def _queue_agent_command(agent_id: str, command_type: str, params: dict = None,
                         priority: str = 'normal') -> dict:
    """Queue a command for an agent and return the command payload."""
    command = {
        'id': _get_next_command_id(),
        'type': command_type,
        'params': params or {},
        'priority': priority,
        'created_at': datetime.now().isoformat(),
    }
    if agent_id not in _commands:
        _commands[agent_id] = []
    _commands[agent_id].append(command)
    return command


def _normalize_discovery_payload(data: dict) -> dict:
    """Normalize discovery payload into list-based collections."""
    payload = data if isinstance(data, dict) else {}

    vms = payload.get('vms')
    if isinstance(vms, dict) or vms is None:
        vms = payload.get('vm_inventory', []) if isinstance(payload.get('vm_inventory'), list) else []
    elif not isinstance(vms, list):
        vms = []
    elif not vms and isinstance(payload.get('vm_inventory'), list):
        vms = payload.get('vm_inventory', [])

    containers = payload.get('containers')
    if isinstance(containers, dict) or containers is None:
        containers = payload.get('container_inventory', []) if isinstance(payload.get('container_inventory'), list) else []
    elif not isinstance(containers, list):
        containers = []
    elif not containers and isinstance(payload.get('container_inventory'), list):
        containers = payload.get('container_inventory', [])

    storage = payload.get('storage', payload.get('datastores', []))
    if not isinstance(storage, list):
        storage = []

    networks = payload.get('networks', payload.get('network', []))
    if not isinstance(networks, list):
        networks = []

    guest_details = payload.get('guest_details', {})
    if not isinstance(guest_details, dict):
        guest_details = {}

    return {
        'vms': [vm for vm in vms if isinstance(vm, dict)],
        'containers': [ct for ct in containers if isinstance(ct, dict)],
        'storage': [item for item in storage if isinstance(item, dict)],
        'networks': [item for item in networks if isinstance(item, dict)],
        'guest_details': guest_details,
    }


def upsert_agent_discovery(agent_id: str, data: dict, metadata: dict = None) -> dict:
    """Store normalized discovery snapshot for an agent and return collection counts."""
    normalized = _normalize_discovery_payload(data)
    now_iso = datetime.now().isoformat()

    if agent_id not in _agents:
        seeded = metadata or {}
        _agents[agent_id] = {
            'agent_id': agent_id,
            'hostname': seeded.get('hostname', ''),
            'platform': seeded.get('platform', ''),
            'platform_name': seeded.get('platform_name', ''),
            'status': seeded.get('status', 'unknown'),
            'registered_at': now_iso,
            'last_seen': now_iso,
            'config': DEFAULT_AGENT_CONFIG.copy(),
        }

    _agents[agent_id]['discovery'] = {
        **normalized,
        'discovered_at': now_iso,
    }

    if metadata:
        for key in ('hostname', 'platform', 'platform_name', 'status', 'hypervisor_id'):
            if key in metadata and metadata.get(key) is not None:
                _agents[agent_id][key] = metadata.get(key)

    _agents[agent_id]['last_seen'] = now_iso
    _save_agents_to_storage()

    return {
        'vms': len(normalized['vms']),
        'containers': len(normalized['containers']),
        'storage': len(normalized['storage']),
        'networks': len(normalized['networks']),
    }


# =============================================================================
# Authentication
# =============================================================================

def require_agent_auth(f):
    """Decorator to require agent API key authentication"""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization', '')

        if not auth_header.startswith('Bearer '):
            return jsonify({
                'success': False,
                'error': 'Missing or invalid authorization header',
                'code': 'AUTH_MISSING'
            }), 401

        token = auth_header[7:]  # Remove 'Bearer ' prefix

        if not token or len(token) < 16:
            return jsonify({
                'success': False,
                'error': 'Invalid API token format',
                'code': 'AUTH_INVALID_FORMAT'
            }), 401

        # For agent-specific endpoints, validate token against agent
        agent_id = kwargs.get('agent_id')
        if agent_id and agent_id in _agents:
            if not _validate_agent_token(agent_id, token):
                return jsonify({
                    'success': False,
                    'error': 'Token does not match agent',
                    'code': 'AUTH_TOKEN_MISMATCH'
                }), 403

            # Check if key has expired
            agent_data = _agents[agent_id]
            key_expires_at = agent_data.get('key_expires_at')
            if key_expires_at:
                try:
                    expires = datetime.fromisoformat(key_expires_at)
                    if datetime.now() > expires:
                        logger.warning(f"API key expired for agent {agent_id} (expired: {key_expires_at})")
                        return jsonify({
                            'success': False,
                            'error': 'API key has expired. Please rotate the key.',
                            'code': 'AUTH_KEY_EXPIRED',
                            'expired_at': key_expires_at
                        }), 401
                except (ValueError, TypeError) as e:
                    logger.warning(f"Could not parse key_expires_at for agent {agent_id}: {e}")

        # Store token in request context for later use
        request.agent_token = token

        return f(*args, **kwargs)

    return decorated


def optional_auth(f):
    """Decorator for endpoints that work with or without auth"""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization', '')
        request.is_authenticated = False

        if auth_header.startswith('Bearer '):
            token = auth_header[7:]
            if token and len(token) >= 16:
                request.is_authenticated = True
                request.agent_token = token

        return f(*args, **kwargs)

    return decorated


# =============================================================================
# Health & Status Endpoints
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/health', methods=['GET'])
@optional_auth
def health_check():
    """
    API health check endpoint.

    Returns server status, version, and basic statistics.
    No authentication required for basic health check.
    """
    try:
        # Count agents by status
        total_agents = len(_agents)
        online = sum(1 for a in _agents.values()
                     if _is_agent_online(a))

        health_data = {
            'success': True,
            'status': 'healthy',
            'api_version': API_VERSION,
            'build': API_BUILD,
            'timestamp': datetime.now().isoformat(),
            'agents': {
                'total': total_agents,
                'online': online,
                'offline': total_agents - online
            }
        }

        # Add detailed stats if authenticated
        if getattr(request, 'is_authenticated', False):
            health_data['pending_commands'] = sum(len(cmds) for cmds in _commands.values())
            health_data['cached_audits'] = sum(len(audits) for audits in _audit_cache.values())

        return jsonify(health_data)

    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/ping', methods=['GET'])
def ping():
    """Simple ping endpoint - no auth required"""
    return jsonify({
        'pong': True,
        'timestamp': datetime.now().isoformat(),
        'version': API_VERSION
    })


def _is_agent_online(agent_data: dict, timeout_minutes: int = 5) -> bool:
    """Check if agent is online based on last heartbeat"""
    try:
        last_hb = datetime.fromisoformat(agent_data.get('last_heartbeat', ''))
        return datetime.now() - last_hb < timedelta(minutes=timeout_minutes)
    except (ValueError, TypeError):
        return False


# =============================================================================
# Hypervisor Agent Download Routes
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/download/<os_type>', methods=['GET'])
def download_hypervisor_agent(os_type):
    """
    Download the hypervisor agent package for deployment.

    This is a PURPOSE-BUILT agent for hypervisor platforms (ESXi, Proxmox, etc.)
    and is distinct from:
    - Fleet Agent (for standard Linux/Windows hosts)
    - Standalone Agent (standalone ad-hoc audits)

    URL Parameters:
        os_type: 'linux' or 'windows'

    Query Parameters:
        format: 'package' (tar.gz/zip) or 'script' (script only)
        platform: Target hypervisor platform (esxi, proxmox, xen, kvm, hyperv, nutanix, vcenter)
        key_validity: API key validity in days (30, 90, 180, 365, 0=never)
        server_url: Pre-configure server URL in agent config
    """
    from flask import Response
    import os as os_module

    format_type = request.args.get('format', 'package')
    platform = request.args.get('platform', 'esxi')

    try:
        # =====================================================================
        # ENTERPRISE LICENSE CHECK
        # Hypervisor agent downloads require Enterprise license to prevent
        # customers from developing independent tools that bypass core product
        # =====================================================================
        license_check = _check_enterprise_license('HYPERVISOR_AGENT_DOWNLOAD')
        if not license_check['allowed']:
            _record_download_audit(os_type, platform, format_type, success=False)
            logger.warning(f"Unlicensed hypervisor agent download attempt: user={_get_current_user_id()}, reason={license_check['reason']}")
            return jsonify({
                'error': 'Enterprise license required',
                'message': 'Hypervisor agent downloads require an Enterprise license.',
                'reason': license_check['reason'],
                'current_tier': license_check.get('tier', 'free'),
                'required_tier': 'enterprise',
                'upgrade_url': '/pricing?feature=hypervisor-agent',
                'code': 'ENTERPRISE_LICENSE_REQUIRED',
            }), 403

        # =====================================================================
        # RATE LIMIT CHECK
        # Prevent mass downloads that could enable offline/disconnected use
        # =====================================================================
        rate_check = _check_rate_limit('download')
        if not rate_check['allowed']:
            _record_download_audit(os_type, platform, format_type, success=False)
            logger.warning(f"Rate limited hypervisor download: user={_get_current_user_id()}, reason={rate_check['reason']}")
            return jsonify({
                'error': 'Download limit exceeded',
                'message': f'You have reached your download limit. Resets at {rate_check["reset_at"]}.',
                'remaining_daily': rate_check['remaining_daily'],
                'remaining_monthly': rate_check['remaining_monthly'],
                'reset_at': rate_check['reset_at'],
                'code': 'RATE_LIMIT_EXCEEDED',
            }), 429

        if os_type not in ['linux', 'windows']:
            return jsonify({'error': 'os_type must be linux or windows'}), 400

        format_type = request.args.get('format', 'package')
        platform = request.args.get('platform', 'esxi')
        key_validity = request.args.get('key_validity', '90')
        server_url = request.args.get('server_url', '')

        # Validate platform
        valid_platforms = ['esxi', 'vcenter', 'proxmox', 'xen', 'kvm', 'hyperv', 'nutanix']
        if platform not in valid_platforms:
            return jsonify({'error': f'platform must be one of: {", ".join(valid_platforms)}'}), 400

        # Base paths
        hypervisor_dir = str(get_hypervisor_agent_dir())
        agent_dir = str(get_standalone_agent_dir())

        logger.info(f"Hypervisor agent download: os={os_type}, format={format_type}, platform={platform}")

        if format_type == 'script':
            # Script-only downloads restricted to SuperAdmin (developer use only)
            # This prevents customers from bypassing the core tool
            if not _is_superadmin():
                logger.warning(f"Non-SuperAdmin attempted script-only download: os={os_type}")
                return jsonify({
                    'error': 'Script-only downloads are restricted to developers',
                    'message': 'Please download the full package which includes proper installation and configuration.'
                }), 403

            # Return just the main agent script
            if os_type == 'windows':
                script_file = os_module.path.join(agent_dir, 'fleet-agent.ps1')
                filename = 'hypervisor-agent.ps1'
            else:
                script_file = os_module.path.join(agent_dir, 'fleet-agent.sh')
                filename = 'hypervisor-agent.sh'

            if not os_module.path.exists(script_file):
                return jsonify({'error': f'Agent script not found: {filename}'}), 404

            with open(script_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # Record successful download (script only for superadmin)
            _record_rate_limit_usage('download')
            _record_download_audit(os_type, platform, 'script', success=True)

            return Response(
                content,
                mimetype='application/octet-stream',
                headers={
                    'Content-Disposition': f'attachment; filename="{filename}"',
                    'Content-Length': str(len(content.encode('utf-8')))
                }
            )

        elif format_type == 'package':
            # Create complete package with config and platform modules
            # Record success (will also be recorded in _create_hypervisor_agent_package)
            _record_rate_limit_usage('download')
            _record_download_audit(os_type, platform, 'package', success=True)
            return _create_hypervisor_agent_package(os_type, platform, key_validity, server_url)

        else:
            return jsonify({'error': 'format must be script or package'}), 400

    except Exception as e:
        _record_download_audit(os_type, platform, format_type, success=False)
        logger.error(f"Failed to download hypervisor agent: {e}")
        return jsonify({'error': str(e)}), 500


def _create_hypervisor_agent_package(os_type, platform, key_validity, server_url):
    """Create a downloadable hypervisor agent package"""
    from flask import send_file
    import io
    import os as os_module
    import json
    import zipfile
    import tarfile

    hypervisor_dir = str(get_hypervisor_agent_dir())
    agent_dir = str(get_standalone_agent_dir())

    # =========================================================================
    # LICENSE EMBEDDING - Prevents independent/unauthorized use
    # =========================================================================
    # Generate license fingerprint tied to this organization
    org_id = _get_current_user_org()
    user_id = _get_current_user_id()
    license_timestamp = datetime.now().isoformat()

    # Create license token that agent must validate on startup
    # In production, this should be cryptographically signed
    license_data = f"{org_id}:{user_id}:{license_timestamp}:{platform}"
    license_hash = hashlib.sha256(license_data.encode()).hexdigest()[:32]

    # Phone-home validation URL - agent must validate on startup and periodically
    validation_url = f"{server_url}/api/hypervisor-agent/validate-license"

    # Config that will be included
    config = {
        "server_url": server_url or "https://your-server:5000",
        "agent_type": "hypervisor",
        "platform": platform,
        "api_key": "",
        "registration_token": "",  # nosec B105
        "key_validity_days": int(key_validity) if key_validity != '0' else 0,
        "poll_interval": 300,
        "heartbeat_interval": 60,
        "auto_update": True,
        "features": {
            "vm_discovery": True,
            "host_metrics": True,
            "storage_audit": True,
            "network_audit": True,
            "security_audit": True
        },
        # License enforcement - agent will not operate without valid license
        "license": {
            "organization_id": org_id,
            "issued_to": user_id,
            "issued_at": license_timestamp,
            "fingerprint": license_hash,
            "validation_url": validation_url,
            "validation_interval": 86400,  # Daily validation required
            "grace_period_hours": 72,  # Hours agent works if server unreachable
            "enforce_online": True,  # Require periodic server validation
        },
        # Security: Agent must be registered with server before operating
        "require_registration": True,
        "offline_mode_disabled": True,  # Prevent standalone operation
    }

    readme_content = f'''# Hypervisor Agent Package ({platform.upper()})

## Overview

This is a PURPOSE-BUILT agent for hypervisor management and auditing.
Target platform: **{platform.upper()}**

## Installation

### Linux (ESXi, Proxmox, XCP-ng, KVM, Nutanix AHV)

```bash
# Extract package
tar -xzf hypervisor-agent-linux.tar.gz
cd hypervisor-agent

# Edit configuration
nano config.json
# Set: server_url, api_key (from web UI registration)

# Install
sudo ./install.sh

# Or manual start
sudo ./hypervisor-agent.sh start
```

### Windows (Hyper-V)

```powershell
# Extract package
Expand-Archive hypervisor-agent-windows.zip -DestinationPath .
cd hypervisor-agent

# Edit configuration
notepad config.json
# Set: server_url, api_key (from web UI registration)

# Install as service
.\\install.ps1

# Or manual start
.\\hypervisor-agent.ps1 -Action start
```

## Registration

1. Log into the Security Audit Toolkit web UI
2. Go to Hypervisors → Agent Registration
3. Generate a registration token
4. Use the token to register this agent:

   Linux: `./hypervisor-agent.sh register --token <TOKEN>`
   Windows: `.\\hypervisor-agent.ps1 -Action register -Token <TOKEN>`

## Platform-Specific Features

### {platform.upper()} Capabilities
'''

    # Add platform-specific documentation
    platform_features = {
        'esxi': '''
- VM inventory and state monitoring
- Datastore utilization auditing
- vSwitch/port group security
- Host configuration compliance
- Performance metrics collection
''',
        'vcenter': '''
- Cluster-wide VM inventory
- Distributed switch auditing
- vSAN health monitoring
- Resource pool compliance
- Permission/role auditing
''',
        'proxmox': '''
- QEMU/KVM VM management
- LXC container auditing
- Ceph storage monitoring
- Cluster node health
- Firewall rule compliance
''',
        'xen': '''
- XCP-ng/XenServer VM discovery
- Storage repository auditing
- Network configuration checks
- Pool-level compliance
- XAPI integration
''',
        'kvm': '''
- libvirt VM inventory
- QEMU configuration auditing
- Network bridge security
- Storage pool monitoring
- cgroup/namespace isolation
''',
        'hyperv': '''
- VM inventory and state
- Virtual switch auditing
- Hyper-V replica status
- Cluster shared volumes
- BitLocker integration check
''',
        'nutanix': '''
- AHV VM discovery
- Prism Element integration
- Storage container auditing
- Network segmentation checks
- AOS compliance validation
'''
    }

    readme_content += platform_features.get(platform, '- Standard hypervisor auditing\n')

    readme_content += '''

## Package Contents

- `hypervisor-agent.sh/.ps1` - Main agent script
- `config.json` - Configuration file (edit before use)
- `install.sh/.ps1` - Installation script
- `platforms/` - Platform-specific modules
- `lib/` - Shared libraries
- `README.md` - This file

## API Key Validity

This package is configured for API keys valid for: ''' + (f'{key_validity} days' if key_validity != '0' else 'Never expires') + '''

## Support

For issues or questions, refer to the main documentation or contact your administrator.
'''

    if os_type == 'windows':
        # Create ZIP for Windows
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Main agent script
            agent_file = os_module.path.join(agent_dir, 'fleet-agent.ps1')
            if os_module.path.exists(agent_file):
                zf.write(agent_file, 'hypervisor-agent/hypervisor-agent.ps1')

            # Config
            zf.writestr('hypervisor-agent/config.json', json.dumps(config, indent=2))

            # README
            zf.writestr('hypervisor-agent/README.md', readme_content)

            # Install script
            install_script = '''# Hypervisor Agent Installation Script (Windows/Hyper-V)
# Run as Administrator

param(
    [string]$ServerUrl,
    [string]$ApiKey,
    [string]$RegistrationToken
)

$InstallDir = "$env:ProgramFiles\\HypervisorAgent"
$ServiceName = "HypervisorAuditAgent"

Write-Host "Installing Hypervisor Agent..." -ForegroundColor Cyan

# Create installation directory
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

# Copy files
Copy-Item -Path ".\\hypervisor-agent.ps1" -Destination $InstallDir -Force
Copy-Item -Path ".\\config.json" -Destination $InstallDir -Force

# Update config if parameters provided
if ($ServerUrl -or $ApiKey) {
    $configPath = Join-Path $InstallDir "config.json"
    $config = Get-Content $configPath | ConvertFrom-Json
    if ($ServerUrl) { $config.server_url = $ServerUrl }
    if ($ApiKey) { $config.api_key = $ApiKey }
    $config | ConvertTo-Json -Depth 10 | Set-Content $configPath
}

# Create scheduled task or service
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$InstallDir\\hypervisor-agent.ps1`" -Action run"
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
Register-ScheduledTask -TaskName $ServiceName -Action $action -Trigger $trigger -Settings $settings -User "SYSTEM" -RunLevel Highest -Force

# Start immediately
Start-ScheduledTask -TaskName $ServiceName

Write-Host "Hypervisor Agent installed successfully!" -ForegroundColor Green
Write-Host "Config location: $InstallDir\\config.json"
'''
            zf.writestr('hypervisor-agent/install.ps1', install_script)

            # Add platform-specific module if available
            platform_file = os_module.path.join(hypervisor_dir, 'platforms', f'{platform}.py')
            if os_module.path.exists(platform_file):
                zf.write(platform_file, f'hypervisor-agent/platforms/{platform}.py')

            # Add core module
            core_file = os_module.path.join(hypervisor_dir, 'core.py')
            if os_module.path.exists(core_file):
                zf.write(core_file, 'hypervisor-agent/platforms/core.py')

            # Add __init__.py for platforms
            init_file = os_module.path.join(hypervisor_dir, 'platforms', '__init__.py')
            if os_module.path.exists(init_file):
                zf.write(init_file, 'hypervisor-agent/platforms/__init__.py')

        buffer.seek(0)
        return send_file(
            buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name='hypervisor-agent-windows.zip'
        )

    else:
        # Create tar.gz for Linux
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w:gz') as tf:
            # Main agent script
            agent_file = os_module.path.join(agent_dir, 'fleet-agent.sh')
            if os_module.path.exists(agent_file):
                tf.add(agent_file, arcname='hypervisor-agent/hypervisor-agent.sh')

            # Config as string
            config_data = json.dumps(config, indent=2).encode('utf-8')
            config_info = tarfile.TarInfo(name='hypervisor-agent/config.json')
            config_info.size = len(config_data)
            tf.addfile(config_info, io.BytesIO(config_data))

            # README as string
            readme_data = readme_content.encode('utf-8')
            readme_info = tarfile.TarInfo(name='hypervisor-agent/README.md')
            readme_info.size = len(readme_data)
            tf.addfile(readme_info, io.BytesIO(readme_data))

            # Install script
            install_script = '''#!/bin/bash
# Hypervisor Agent Installation Script (Linux)
# Supports: ESXi, Proxmox, XCP-ng, KVM, Nutanix AHV

set -e

INSTALL_DIR="/opt/hypervisor-agent"
SERVICE_NAME="hypervisor-agent"

echo "Installing Hypervisor Agent..."

# Create installation directory
sudo mkdir -p "$INSTALL_DIR"
sudo mkdir -p "$INSTALL_DIR/platforms"

# Copy files
sudo cp hypervisor-agent.sh "$INSTALL_DIR/"
sudo cp config.json "$INSTALL_DIR/"
sudo cp -r platforms/* "$INSTALL_DIR/platforms/" 2>/dev/null || true

# Make executable
sudo chmod +x "$INSTALL_DIR/hypervisor-agent.sh"

# Create systemd service if available
if command -v systemctl &> /dev/null; then
    cat << 'EOF' | sudo tee /etc/systemd/system/${SERVICE_NAME}.service
[Unit]
Description=Hypervisor Audit Agent
After=network.target

[Service]
Type=simple
ExecStart=/opt/hypervisor-agent/hypervisor-agent.sh run
Restart=always
RestartSec=30
User=root

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable ${SERVICE_NAME}
    sudo systemctl start ${SERVICE_NAME}
    echo "Agent installed as systemd service"
else
    # Fallback to cron
    (crontab -l 2>/dev/null; echo "*/5 * * * * $INSTALL_DIR/hypervisor-agent.sh run") | crontab -
    echo "Agent installed via cron"
fi

echo "Hypervisor Agent installed successfully!"
echo "Config location: $INSTALL_DIR/config.json"
'''
            install_data = install_script.encode('utf-8')
            install_info = tarfile.TarInfo(name='hypervisor-agent/install.sh')
            install_info.size = len(install_data)
            install_info.mode = 0o755
            tf.addfile(install_info, io.BytesIO(install_data))

            # Add platform-specific module if available
            platform_file = os_module.path.join(hypervisor_dir, 'platforms', f'{platform}.py')
            if os_module.path.exists(platform_file):
                tf.add(platform_file, arcname=f'hypervisor-agent/platforms/{platform}.py')

            # Add core module
            core_file = os_module.path.join(hypervisor_dir, 'core.py')
            if os_module.path.exists(core_file):
                tf.add(core_file, arcname='hypervisor-agent/platforms/core.py')

            # Add __init__.py for platforms
            init_file = os_module.path.join(hypervisor_dir, 'platforms', '__init__.py')
            if os_module.path.exists(init_file):
                tf.add(init_file, arcname='hypervisor-agent/platforms/__init__.py')

        buffer.seek(0)
        return send_file(
            buffer,
            mimetype='application/gzip',
            as_attachment=True,
            download_name='hypervisor-agent-linux.tar.gz'
        )


# =============================================================================
# OpenAPI Specification
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/openapi', methods=['GET'])
@hypervisor_agent_bp.route('/api/hypervisor-agent/openapi.json', methods=['GET'])
def openapi_spec():
    """
    OpenAPI 3.0 specification for the Hypervisor Agent API.

    This enables:
    - Auto-generated API documentation
    - Client SDK generation
    - API testing tools integration
    """
    spec = {
        'openapi': '3.0.3',
        'info': {
            'title': 'Hypervisor Agent API',
            'description': 'API for hypervisor-specific fleet agents. Agents push audit results to the core server.',
            'version': API_VERSION,
            'contact': {
                'name': 'Security Audit Toolkit',
                'url': 'https://github.com/security-audit-toolkit'
            },
            'license': {
                'name': 'Proprietary',
                'url': 'https://example.com/license'
            }
        },
        'servers': [
            {
                'url': '/api/hypervisor-agent',
                'description': 'Hypervisor Agent API'
            }
        ],
        'security': [
            {'BearerAuth': []}
        ],
        'components': {
            'securitySchemes': {
                'BearerAuth': {
                    'type': 'http',
                    'scheme': 'bearer',
                    'bearerFormat': 'API Key'
                }
            },
            'schemas': {
                'Agent': {
                    'type': 'object',
                    'properties': {
                        'agent_id': {'type': 'string', 'description': 'Unique agent identifier'},
                        'platform': {'type': 'string', 'enum': ['esxi', 'vcenter', 'proxmox', 'xen', 'kvm', 'nutanix']},
                        'platform_name': {'type': 'string'},
                        'hostname': {'type': 'string'},
                        'platform_version': {'type': 'string'},
                        'status': {'type': 'string', 'enum': ['online', 'offline', 'error']},
                        'last_heartbeat': {'type': 'string', 'format': 'date-time'},
                        'registered_at': {'type': 'string', 'format': 'date-time'},
                        'capabilities': {'type': 'array', 'items': {'type': 'string'}}
                    }
                },
                'AuditResult': {
                    'type': 'object',
                    'required': ['checks', 'summary'],
                    'properties': {
                        'execution_id': {'type': 'string'},
                        'started_at': {'type': 'string', 'format': 'date-time'},
                        'completed_at': {'type': 'string', 'format': 'date-time'},
                        'platform': {'type': 'string'},
                        'platform_version': {'type': 'string'},
                        'checks': {
                            'type': 'array',
                            'items': {'$ref': '#/components/schemas/Check'}
                        },
                        'summary': {'$ref': '#/components/schemas/Summary'}
                    }
                },
                'Check': {
                    'type': 'object',
                    'properties': {
                        'name': {'type': 'string'},
                        'status': {'type': 'string', 'enum': ['PASS', 'FAIL', 'WARN', 'SKIP']},
                        'message': {'type': 'string'},
                        'category': {'type': 'string'},
                        'severity': {'type': 'string', 'enum': ['low', 'medium', 'high', 'critical']},
                        'remediation': {'type': 'string'},
                        'compliance': {'type': 'array', 'items': {'type': 'string'}}
                    }
                },
                'Summary': {
                    'type': 'object',
                    'properties': {
                        'total': {'type': 'integer'},
                        'passed': {'type': 'integer'},
                        'failed': {'type': 'integer'},
                        'warnings': {'type': 'integer'},
                        'skipped': {'type': 'integer'}
                    }
                },
                'Command': {
                    'type': 'object',
                    'properties': {
                        'id': {'type': 'integer'},
                        'type': {'type': 'string', 'enum': ['run_audit', 'discovery', 'update_config', 'key_rotation', 'run_platform_audit_script']},
                        'params': {'type': 'object'},
                        'priority': {'type': 'string', 'enum': ['normal', 'high']},
                        'created_at': {'type': 'string', 'format': 'date-time'}
                    }
                },
                'Config': {
                    'type': 'object',
                    'properties': {
                        'poll_interval': {'type': 'integer', 'default': 60},
                        'audits_enabled': {'type': 'boolean', 'default': True},
                        'auto_discovery': {'type': 'boolean', 'default': True},
                        'categories': {'type': 'array', 'items': {'type': 'string'}},
                        'result_format': {'type': 'string', 'default': 'json'},
                        'compress_results': {'type': 'boolean', 'default': False},
                        'retry_on_failure': {'type': 'boolean', 'default': True},
                        'max_retries': {'type': 'integer', 'default': 3}
                    }
                },
                'Error': {
                    'type': 'object',
                    'properties': {
                        'success': {'type': 'boolean', 'example': False},
                        'error': {'type': 'string'},
                        'code': {'type': 'string'}
                    }
                }
            }
        },
        'paths': {
            '/health': {
                'get': {
                    'summary': 'Health check',
                    'tags': ['Status'],
                    'security': [],
                    'responses': {
                        '200': {'description': 'API is healthy'}
                    }
                }
            },
            '/ping': {
                'get': {
                    'summary': 'Simple ping',
                    'tags': ['Status'],
                    'security': [],
                    'responses': {
                        '200': {'description': 'Pong response'}
                    }
                }
            },
            '/register': {
                'post': {
                    'summary': 'Register a new agent',
                    'tags': ['Registration'],
                    'requestBody': {
                        'required': True,
                        'content': {
                            'application/json': {
                                'schema': {'$ref': '#/components/schemas/Agent'}
                            }
                        }
                    },
                    'responses': {
                        '200': {'description': 'Agent registered successfully'},
                        '401': {'description': 'Authentication required'}
                    }
                }
            },
            '/': {
                'get': {
                    'summary': 'List all registered agents',
                    'tags': ['Agents'],
                    'responses': {
                        '200': {'description': 'List of agents'}
                    }
                }
            },
            '/{agent_id}': {
                'get': {
                    'summary': 'Get agent details',
                    'tags': ['Agents'],
                    'parameters': [
                        {'name': 'agent_id', 'in': 'path', 'required': True, 'schema': {'type': 'string'}}
                    ],
                    'responses': {
                        '200': {'description': 'Agent details'},
                        '404': {'description': 'Agent not found'}
                    }
                },
                'delete': {
                    'summary': 'Unregister an agent',
                    'tags': ['Agents'],
                    'responses': {
                        '200': {'description': 'Agent unregistered'}
                    }
                }
            },
            '/{agent_id}/heartbeat': {
                'post': {
                    'summary': 'Send heartbeat and receive commands',
                    'tags': ['Communication'],
                    'responses': {
                        '200': {'description': 'Heartbeat received, commands returned'}
                    }
                }
            },
            '/{agent_id}/results': {
                'post': {
                    'summary': 'Submit audit results',
                    'tags': ['Results'],
                    'requestBody': {
                        'required': True,
                        'content': {
                            'application/json': {
                                'schema': {'$ref': '#/components/schemas/AuditResult'}
                            }
                        }
                    },
                    'responses': {
                        '200': {'description': 'Results received'}
                    }
                }
            },
            '/{agent_id}/config': {
                'get': {
                    'summary': 'Get agent configuration',
                    'tags': ['Configuration'],
                    'responses': {
                        '200': {'description': 'Agent configuration'}
                    }
                },
                'put': {
                    'summary': 'Update agent configuration',
                    'tags': ['Configuration'],
                    'responses': {
                        '200': {'description': 'Configuration updated'}
                    }
                }
            },
            '/{agent_id}/audits': {
                'get': {
                    'summary': 'Get audit history',
                    'tags': ['History'],
                    'parameters': [
                        {'name': 'limit', 'in': 'query', 'schema': {'type': 'integer', 'default': 10}},
                        {'name': 'offset', 'in': 'query', 'schema': {'type': 'integer', 'default': 0}}
                    ],
                    'responses': {
                        '200': {'description': 'Audit history'}
                    }
                }
            },
            '/{agent_id}/trigger-audit': {
                'post': {
                    'summary': 'Trigger an audit',
                    'tags': ['Commands'],
                    'responses': {
                        '200': {'description': 'Audit triggered'}
                    }
                }
            }
        },
        'tags': [
            {'name': 'Status', 'description': 'Health and status endpoints'},
            {'name': 'Registration', 'description': 'Agent registration'},
            {'name': 'Agents', 'description': 'Agent management'},
            {'name': 'Communication', 'description': 'Agent-server communication'},
            {'name': 'Results', 'description': 'Audit result submission'},
            {'name': 'Configuration', 'description': 'Agent configuration'},
            {'name': 'History', 'description': 'Audit history'},
            {'name': 'Commands', 'description': 'Command management'}
        ]
    }

    return jsonify(spec)


# =============================================================================
# Registration Endpoints
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/register', methods=['POST'])
@require_agent_auth
def register_agent():
    """
    Register a new hypervisor agent.

    Stores agent token in encrypted keystore with fallback to local hash storage.

    Request body:
    {
        "agent_id": "esxi-prod-01",
        "platform": "esxi",
        "platform_name": "VMware ESXi",
        "version": "1.0.0",
        "hostname": "esxi-prod-01.local",
        "platform_version": "8.0 Update 2",
        "capabilities": ["audit", "discovery"],
        "system_info": {...}
    }
    """
    try:
        # =====================================================================
        # LICENSE CHECK
        # Hypervisor agent registration requires Professional or higher licence
        # to prevent unauthorised agents being deployed outside licensed orgs
        # =====================================================================
        license_check = _check_enterprise_license('HYPERVISOR_AGENT_REGISTER')
        if not license_check['allowed']:
            logger.warning(f"Unlicensed agent registration attempt: reason={license_check['reason']}")
            return jsonify({
                'success': False,
                'error': 'Professional or higher licence required',
                'message': 'Hypervisor agent registration requires a Professional or Advanced Operations Pack Add-On licence.',
                'reason': license_check['reason'],
                'current_tier': license_check.get('tier', 'free'),
                'required_tier': 'professional',
                'code': 'LICENCE_REQUIRED',
            }), 403

        # =====================================================================
        # RATE LIMIT CHECK
        # Prevent mass agent registration that could indicate abuse
        # =====================================================================
        rate_check = _check_rate_limit('registration')
        if not rate_check['allowed']:
            logger.warning(f"Rate limited agent registration: reason={rate_check['reason']}")
            return jsonify({
                'success': False,
                'error': 'Registration limit exceeded',
                'message': f'You have reached your registration limit. Resets at {rate_check["reset_at"]}.',
                'remaining_daily': rate_check['remaining_daily'],
                'remaining_monthly': rate_check['remaining_monthly'],
                'reset_at': rate_check['reset_at'],
                'code': 'RATE_LIMIT_EXCEEDED',
            }), 429

        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        agent_id = data.get('agent_id')
        if not agent_id:
            return jsonify({'success': False, 'error': 'Missing agent_id'}), 400

        # Generate secure token
        agent_token = secrets.token_urlsafe(32)
        storage_method = 'local_hash'

        # Try to store token in encrypted keystore
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            keystore.store_key(
                key_type='hypervisor_agent',
                key_id=agent_id,
                value=agent_token,
                metadata={
                    'platform': data.get('platform', 'unknown'),
                    'platform_name': data.get('platform_name', 'Unknown'),
                    'hostname': data.get('hostname', ''),
                    'hypervisor_id': data.get('hypervisor_id', ''),
                    'scope': ['hypervisor_agent']
                },
                created_by='system'
            )
            storage_method = 'encrypted_keystore'
            logger.info(f"Hypervisor agent token stored in encrypted keystore: {agent_id}")
        except ImportError:
            logger.debug("Keystore not available, using local hash storage")
        except Exception as e:
            logger.warning(f"Could not store token in keystore: {e}, using local hash")

        # Store agent data with hashed token (always maintain hash for fast auth)
        agent_data = {
            'agent_id': agent_id,
            'platform': data.get('platform', 'unknown'),
            'platform_name': data.get('platform_name', 'Unknown'),
            'version': data.get('version', '1.0.0'),
            'hostname': data.get('hostname', ''),
            'platform_version': data.get('platform_version', ''),
            'capabilities': data.get('capabilities', []),
            'system_info': data.get('system_info', {}),
            'registered_at': datetime.now().isoformat(),
            'last_heartbeat': datetime.now().isoformat(),
            'status': 'online',
            'token_hash': _hash_key(agent_token),
            'token_storage': storage_method,
            'config': DEFAULT_AGENT_CONFIG.copy()
        }

        _agents[agent_id] = agent_data
        _commands[agent_id] = []

        # Persist to storage
        _save_agents_to_storage()

        # Keep unified registry (FleetAgent table) in sync for live dashboards/stats
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type='hypervisor',
                hostname=agent_data.get('hostname'),
                name=agent_data.get('platform_name') or agent_data.get('hostname') or agent_id,
                os_type=agent_data.get('platform'),
                agent_version=agent_data.get('version'),
                status='online',
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during hypervisor register for {agent_id}: {sync_err}")

        # Record rate limit usage after successful registration
        _record_rate_limit_usage('registration')

        logger.info(f"Hypervisor agent registered: {agent_id} ({agent_data['platform']})")

        return jsonify({
            'success': True,
            'agent_token': agent_token,
            'config': agent_data['config'],
            'api_version': API_VERSION,
            'token_encrypted': storage_method == 'encrypted_keystore',
            # Include license info for agent to validate
            'license': {
                'organization_id': _get_current_user_org(),
                'validation_required': True,
                'validation_url': '/api/hypervisor-agent/validate-license',
            }
        })

    except Exception as e:
        logger.error(f"Agent registration failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent', methods=['GET'])
@require_agent_auth
def list_agents():
    """List all registered hypervisor agents"""
    try:
        agents = []
        for agent_id, agent_data in _agents.items():
            # Check if agent is stale (no heartbeat in 5 minutes)
            last_hb = datetime.fromisoformat(agent_data['last_heartbeat'])
            if datetime.now() - last_hb > timedelta(minutes=5):
                agent_data['status'] = 'offline'

            agents.append({
                'agent_id': agent_id,
                'platform': agent_data['platform'],
                'platform_name': agent_data['platform_name'],
                'hostname': agent_data['hostname'],
                'platform_version': agent_data['platform_version'],
                'status': agent_data['status'],
                'last_heartbeat': agent_data['last_heartbeat'],
                'registered_at': agent_data['registered_at']
            })

        return jsonify({
            'success': True,
            'agents': agents,
            'total': len(agents)
        })

    except Exception as e:
        logger.error(f"List agents failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>', methods=['GET'])
@require_agent_auth
def get_agent(agent_id):
    """Get details for a specific agent"""
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent_data = _agents[agent_id].copy()
        agent_data.pop('token', None)  # Don't expose token

        return jsonify({
            'success': True,
            'agent': agent_data
        })

    except Exception as e:
        logger.error(f"Get agent failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>', methods=['DELETE'])
@require_agent_auth
def unregister_agent(agent_id):
    """Unregister an agent"""
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        del _agents[agent_id]
        if agent_id in _commands:
            del _commands[agent_id]

        # Persist changes
        _save_agents_to_storage()

        logger.info(f"Hypervisor agent unregistered: {agent_id}")

        return jsonify({'success': True, 'message': 'Agent unregistered'})

    except Exception as e:
        logger.error(f"Unregister agent failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Token Generation for UI (Wizard)
# =============================================================================

# Store pending registration tokens: {token: {hypervisor_data, expires_at}}
_pending_registrations = {}


@hypervisor_agent_bp.route('/api/hypervisor-agent/register/token', methods=['POST'])
def generate_registration_token():
    """
    Generate a registration token for a new agent from the UI wizard.

    This endpoint is called by the wizard to create a one-time token
    that the agent will use to register.

    Request body:
    {
        "hypervisor_name": "production-proxmox-01",
        "hypervisor_type": "proxmox",
        "datacenter": "DC-East",
        "cluster": "Production",
        "tags": "production, vmware",
        "key_validity_days": 90  # Optional: 30, 90, 180, 365, or 0 (never expires)
    }
    """
    try:
        # =====================================================================
        # ENTERPRISE LICENSE CHECK
        # Token generation requires Enterprise license - this is the entry point
        # for all hypervisor agent deployments
        # =====================================================================
        license_check = _check_enterprise_license('HYPERVISOR_AGENT_REGISTER')
        if not license_check['allowed']:
            logger.warning(f"Unlicensed registration token generation attempt: reason={license_check['reason']}")
            return jsonify({
                'success': False,
                'error': 'Enterprise license required',
                'message': 'Generating hypervisor agent registration tokens requires an Enterprise license.',
                'reason': license_check['reason'],
                'current_tier': license_check.get('tier', 'free'),
                'required_tier': 'enterprise',
                'code': 'ENTERPRISE_LICENSE_REQUIRED',
            }), 403

        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        hypervisor_name = data.get('hypervisor_name')
        if not hypervisor_name:
            return jsonify({'success': False, 'error': 'hypervisor_name is required'}), 400

        # Get key validity period from request or security settings
        from security_settings import get_security_setting
        key_validity_days = data.get('key_validity_days')
        if key_validity_days is None:
            key_validity_days = get_security_setting('hypervisor_key_validity_days') or 90

        # Validate key_validity_days is an allowed value
        valid_options = get_security_setting('hypervisor_key_validity_options') or [30, 90, 180, 365, 0]
        if key_validity_days not in valid_options:
            return jsonify({
                'success': False,
                'error': f'Invalid key_validity_days. Must be one of: {valid_options}'
            }), 400

        # Generate a secure one-time registration token
        registration_token = secrets.token_urlsafe(32)

        # Create pending hypervisor entry
        # In a real implementation, this would create a database record
        hypervisor_id = f"hv-{secrets.token_hex(8)}"

        # Calculate key expiry (0 = never expires)
        if key_validity_days > 0:
            key_expires_at = (datetime.now() + timedelta(days=key_validity_days)).isoformat()
        else:
            key_expires_at = None  # Never expires

        pending_data = {
            'hypervisor_id': hypervisor_id,
            'hypervisor_name': hypervisor_name,
            'hypervisor_type': data.get('hypervisor_type', 'unknown'),
            'datacenter': data.get('datacenter'),
            'cluster': data.get('cluster'),
            'tags': data.get('tags'),
            'connection_method': 'agent',
            'created_at': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(hours=24)).isoformat(),
            'key_validity_days': key_validity_days,
            'key_expires_at': key_expires_at,
            'status': 'pending'
        }

        # Store pending registration
        _pending_registrations[registration_token] = pending_data

        logger.info(f"Registration token generated for hypervisor: {hypervisor_name} ({hypervisor_id})")

        # Format validity message
        if key_validity_days == 0:
            validity_msg = 'Key will never expire'
        elif key_validity_days == 30:
            validity_msg = 'Key valid for 30 days'
        elif key_validity_days == 90:
            validity_msg = 'Key valid for 3 months'
        elif key_validity_days == 180:
            validity_msg = 'Key valid for 6 months'
        elif key_validity_days == 365:
            validity_msg = 'Key valid for 1 year'
        else:
            validity_msg = f'Key valid for {key_validity_days} days'

        return jsonify({
            'success': True,
            'token': registration_token,
            'hypervisor_id': hypervisor_id,
            'expires_in': '24 hours',
            'key_validity_days': key_validity_days,
            'key_expires_at': key_expires_at,
            'validity_message': validity_msg,
            'message': 'Install the agent on your hypervisor with this token'
        })

    except Exception as e:
        logger.error(f"Registration token generation failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/register/complete', methods=['POST'])
def complete_registration():
    """
    Complete agent registration using a pending token.

    Called by the agent after being installed with a registration token.

    Request body:
    {
        "registration_token": "the-token-from-wizard",
        "agent_id": "auto-generated-or-provided",
        "platform": "proxmox",
        "hostname": "proxmox-node-01.local",
        "version": "1.0.0",
        "system_info": {...}
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        registration_token = data.get('registration_token')
        if not registration_token:
            return jsonify({'success': False, 'error': 'registration_token is required'}), 400

        # Validate registration token
        if registration_token not in _pending_registrations:
            return jsonify({
                'success': False,
                'error': 'Invalid or expired registration token',
                'code': 'INVALID_REGISTRATION_TOKEN'
            }), 401

        pending = _pending_registrations[registration_token]

        # Check if token has expired
        expires_at = datetime.fromisoformat(pending['expires_at'])
        if datetime.now() > expires_at:
            del _pending_registrations[registration_token]
            return jsonify({
                'success': False,
                'error': 'Registration token has expired',
                'code': 'REGISTRATION_TOKEN_EXPIRED'
            }), 401

        # Generate permanent API token for the agent
        agent_token = secrets.token_urlsafe(32)
        agent_id = data.get('agent_id', f"agent-{secrets.token_hex(8)}")

        # Get key validity from pending registration
        key_validity_days = pending.get('key_validity_days', 90)
        key_expires_at = pending.get('key_expires_at')

        # Create agent record
        agent_data = {
            'agent_id': agent_id,
            'hypervisor_id': pending['hypervisor_id'],
            'hypervisor_name': pending['hypervisor_name'],
            'platform': data.get('platform', pending['hypervisor_type']),
            'platform_name': data.get('platform_name', pending['hypervisor_type'].upper()),
            'version': data.get('version', '1.0.0'),
            'hostname': data.get('hostname', ''),
            'platform_version': data.get('platform_version', ''),
            'capabilities': data.get('capabilities', ['audit', 'discovery']),
            'system_info': data.get('system_info', {}),
            'datacenter': pending.get('datacenter'),
            'cluster': pending.get('cluster'),
            'tags': pending.get('tags'),
            'registered_at': datetime.now().isoformat(),
            'last_heartbeat': datetime.now().isoformat(),
            'status': 'online',
            'token_hash': _hash_key(agent_token),
            'key_validity_days': key_validity_days,
            'key_expires_at': key_expires_at,
            'key_created_at': datetime.now().isoformat(),
            'config': DEFAULT_AGENT_CONFIG.copy()
        }

        _agents[agent_id] = agent_data
        _commands[agent_id] = []

        # Persist to storage
        _save_agents_to_storage()

        # Mark pending registration as completed
        pending['status'] = 'completed'
        pending['agent_id'] = agent_id
        pending['completed_at'] = datetime.now().isoformat()

        # Clean up the pending token after successful registration
        del _pending_registrations[registration_token]

        logger.info(f"Agent registration completed: {agent_id} for hypervisor {pending['hypervisor_name']}")

        return jsonify({
            'success': True,
            'agent_token': agent_token,
            'agent_id': agent_id,
            'hypervisor_id': pending['hypervisor_id'],
            'config': agent_data['config'],
            'api_version': API_VERSION,
            'message': 'Agent registered successfully'
        })

    except Exception as e:
        logger.error(f"Agent registration completion failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<hypervisor_id>/status', methods=['GET'])
def get_agent_status_by_hypervisor(hypervisor_id):
    """
    Get agent status for a hypervisor (used by wizard to poll for connection).

    Returns status of agent associated with the hypervisor ID.
    """
    try:
        # Find agent by hypervisor ID
        for agent_id, agent_data in _agents.items():
            if agent_data.get('hypervisor_id') == hypervisor_id:
                # Check if agent is stale
                last_hb = datetime.fromisoformat(agent_data['last_heartbeat'])
                if datetime.now() - last_hb > timedelta(minutes=5):
                    status = 'offline'
                else:
                    status = 'connected'

                return jsonify({
                    'success': True,
                    'status': status,
                    'agent_id': agent_id,
                    'hostname': agent_data.get('hostname'),
                    'platform': agent_data.get('platform'),
                    'last_seen': agent_data['last_heartbeat']
                })

        # Check pending registrations
        for token, pending in _pending_registrations.items():
            if pending.get('hypervisor_id') == hypervisor_id:
                return jsonify({
                    'success': True,
                    'status': 'pending',
                    'message': 'Waiting for agent to connect...'
                })

        return jsonify({
            'success': False,
            'error': 'No agent found for this hypervisor'
        }), 404

    except Exception as e:
        logger.error(f"Get agent status failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Heartbeat & Commands
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/heartbeat', methods=['POST'])
@require_agent_auth
def agent_heartbeat(agent_id):
    """
    Receive heartbeat and return pending commands.

    Request body:
    {
        "status": "idle|running|error",
        "timestamp": "ISO timestamp",
        "platform_version": "8.0 Update 2"
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not registered'}), 404

        data = request.get_json() or {}

        # Update agent status
        _agents[agent_id]['last_heartbeat'] = datetime.now().isoformat()
        _agents[agent_id]['status'] = data.get('status', 'online')
        if data.get('platform_version'):
            _agents[agent_id]['platform_version'] = data['platform_version']

        # Keep unified registry (FleetAgent table) heartbeat fresh
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            agent_entry = _agents[agent_id]
            update_agent_heartbeat(
                agent_id=agent_id,
                agent_type='hypervisor',
                hostname=agent_entry.get('hostname'),
                name=agent_entry.get('platform_name') or agent_entry.get('hostname') or agent_id,
                os_type=agent_entry.get('platform'),
                agent_version=agent_entry.get('version'),
                status=agent_entry.get('status'),
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed during hypervisor heartbeat for {agent_id}: {sync_err}")

        # Get pending commands
        pending = _commands.get(agent_id, [])

        # Return commands and clear queue
        _commands[agent_id] = []

        return jsonify({
            'success': True,
            'commands': pending
        })

    except Exception as e:
        logger.error(f"Heartbeat failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/commands', methods=['GET'])
@require_agent_auth
def get_commands(agent_id):
    """Get pending commands without consuming them"""
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        return jsonify({
            'success': True,
            'commands': _commands.get(agent_id, [])
        })

    except Exception as e:
        logger.error(f"Get commands failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/commands', methods=['POST'])
@require_agent_auth
def queue_command(agent_id):
    """
    Queue a command for an agent.

    Request body:
    {
        "type": "run_audit|discovery|update_config",
        "params": {...},
        "priority": "normal|high"
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        data = request.get_json()
        if not data or 'type' not in data:
            return jsonify({'success': False, 'error': 'Missing command type'}), 400

        command = _queue_agent_command(
            agent_id,
            data['type'],
            params=data.get('params', {}),
            priority=data.get('priority', 'normal')
        )

        logger.info(f"Command queued for {agent_id}: {command['type']} (id={command['id']})")

        return jsonify({
            'success': True,
            'command_id': command['id'],
            'message': 'Command queued'
        })

    except Exception as e:
        logger.error(f"Queue command failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/commands/<int:command_id>/ack', methods=['POST'])
@require_agent_auth
def acknowledge_command(agent_id, command_id):
    """
    Acknowledge command execution status.

    Request body:
    {
        "status": "started|completed|failed",
        "message": "Optional status message"
    }
    """
    try:
        data = request.get_json() or {}

        ack_data = {
            'command_id': command_id,
            'agent_id': agent_id,
            'status': data.get('status', 'acknowledged'),
            'message': data.get('message', ''),
            'acknowledged_at': datetime.now().isoformat()
        }

        _command_acks[command_id] = ack_data

        logger.info(f"Command {command_id} acknowledged by {agent_id}: {ack_data['status']}")

        return jsonify({'success': True})

    except Exception as e:
        logger.error(f"Command ack failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Results & Discovery
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/results', methods=['POST'])
@require_agent_auth
@conditional_limit(get_hypervisor_upload_limit)
def submit_results(agent_id):
    """
    Receive audit results from agent.

    Request body:
    {
        "execution_id": "abc123",
        "started_at": "ISO timestamp",
        "completed_at": "ISO timestamp",
        "platform": "proxmox",
        "platform_version": "8.0",
        "checks": [...],
        "summary": {"passed": 45, "failed": 3, "warnings": 7, "skipped": 2}
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        limits = _get_result_ingest_limits()
        max_body_bytes = limits['max_body_kb'] * 1024
        body_raw = request.get_data(cache=True, as_text=False) or b''
        if len(body_raw) > max_body_bytes:
            return jsonify({
                'success': False,
                'error': 'Request body too large',
                'limit_kb': limits['max_body_kb']
            }), 413

        disk_blocked, disk_details = _is_result_ingest_blocked_by_disk_watermark()
        if disk_blocked:
            logger.warning(f"Rejecting hypervisor ingest due to low disk watermark: {disk_details}")
            return jsonify({
                'success': False,
                'error': 'Insufficient storage capacity on core',
                'details': disk_details
            }), 507

        data = request.get_json(silent=True)
        if not data:
            return jsonify({'success': False, 'error': 'Missing results data'}), 400

        checks = data.get('checks', []) if isinstance(data, dict) else []
        if isinstance(checks, list) and len(checks) > limits['max_checks_per_result']:
            return jsonify({
                'success': False,
                'error': 'Too many checks in result payload',
                'limit': limits['max_checks_per_result']
            }), 400

        output = data.get('output') if isinstance(data, dict) else None
        if output is not None and len(str(output)) > limits['max_output_chars']:
            return jsonify({
                'success': False,
                'error': 'Result output is too large',
                'limit_chars': limits['max_output_chars']
            }), 400

        # Store results (in production, save to database)
        results = {
            'audit_id': data.get('execution_id') or f"audit_{int(time.time())}",
            'agent_id': agent_id,
            'hostname': _agents[agent_id].get('hostname', ''),
            'platform': data.get('platform', _agents[agent_id].get('platform')),
            'platform_version': data.get('platform_version', ''),
            'started_at': data.get('started_at'),
            'completed_at': data.get('completed_at'),
            'checks': data.get('checks', []),
            'summary': data.get('summary', {}),
            'received_at': datetime.now().isoformat()
        }

        # Apply encryption if enabled (Phase 2 - unified across all agents)
        if _ENCRYPTION_AVAILABLE:
            try:
                result_encryptor = ResultEncryption()
                should_encrypt = result_encryptor.should_encrypt_result()

                if should_encrypt:
                    encrypted_wrapper = result_encryptor.encrypt(results, agent_id)
                    if encrypted_wrapper:
                        results = encrypted_wrapper
                        logger.info(f"Hypervisor agent result encrypted for {agent_id}")
                    else:
                        logger.warning(f"Failed to encrypt hypervisor agent result for {agent_id}, storing unencrypted")
            except Exception as e:
                logger.error(f"Encryption error for hypervisor agent {agent_id}: {e}")
                # Continue without encryption if error occurs

        # Update agent last audit time
        _agents[agent_id]['last_audit'] = datetime.now().isoformat()
        _agents[agent_id]['last_audit_summary'] = results.get('summary', {})

        # Cache recent result for quick retrieval
        _cache_audit_result(agent_id, results)

        logger.info(f"Received audit results from {agent_id}: {results.get('summary', {})}")

        # Persist to database when available
        if DATABASE_AVAILABLE:
            db = _get_db_session()
            if db is not None:
                try:
                    hv_id = _agents[agent_id].get('hypervisor_id')
                    hv_row = db.query(Hypervisor).filter(Hypervisor.id == hv_id).first() if hv_id else None

                    summary_data = results.get('summary', {})
                    passed = int(summary_data.get('passed', 0))
                    failed = int(summary_data.get('failed', 0))
                    warned = int(summary_data.get('warnings', summary_data.get('warned', 0)))
                    skipped = int(summary_data.get('skipped', 0))
                    total = passed + failed + warned + skipped
                    exec_status = 'failure' if failed > 0 else 'success'

                    started_at = None
                    completed_at = None
                    try:
                        raw_start = data.get('started_at')
                        raw_end = data.get('completed_at')
                        if raw_start:
                            started_at = datetime.fromisoformat(raw_start.replace('Z', '+00:00'))
                        if raw_end:
                            completed_at = datetime.fromisoformat(raw_end.replace('Z', '+00:00'))
                    except (ValueError, AttributeError):
                        pass

                    execution = HypervisorAuditExecution(
                        hypervisor_id=hv_id,
                        audit_type='security',
                        status=exec_status,
                        output=_json.dumps(results),
                        summary=_json.dumps(summary_data),
                        checks_total=total,
                        checks_passed=passed,
                        checks_failed=failed,
                        checks_warned=warned,
                        checks_skipped=skipped,
                        started_at=started_at or datetime.utcnow(),
                        completed_at=completed_at,
                    )
                    db.add(execution)

                    if hv_row is not None:
                        hv_row.last_audit_at = datetime.utcnow()

                    db.commit()
                except Exception as db_err:
                    logger.error(f"DB persistence failed for {agent_id}: {db_err}")
                    try:
                        db.rollback()
                    except Exception:
                        pass
                finally:
                    db.close()

        _save_agents_to_storage()

        return jsonify({
            'success': True,
            'message': 'Results received',
            'summary': results.get('summary', {})
        })

    except Exception as e:
        logger.error(f"Submit results failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/discovery', methods=['POST'])
@require_agent_auth
def submit_discovery(agent_id):
    """
    Receive discovery data (VMs, containers, storage, etc.)

    Request body:
    {
        "vms": [...],
        "containers": [...],
        "storage": [...],
        "networks": [...]
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        limits = _get_discovery_ingest_limits()
        max_body_bytes = limits['max_body_kb'] * 1024
        body_raw = request.get_data(cache=True, as_text=False) or b''
        if len(body_raw) > max_body_bytes:
            return jsonify({
                'success': False,
                'error': 'Request body too large',
                'limit_kb': limits['max_body_kb']
            }), 413

        disk_blocked, disk_details = _is_result_ingest_blocked_by_disk_watermark()
        if disk_blocked:
            logger.warning(f"Rejecting hypervisor discovery ingest due to low disk watermark: {disk_details}")
            return jsonify({
                'success': False,
                'error': 'Insufficient storage capacity on core',
                'details': disk_details
            }), 507

        data = request.get_json(silent=True)
        if not data:
            return jsonify({'success': False, 'error': 'Missing discovery data'}), 400

        normalized = _normalize_discovery_payload(data)
        vms = normalized['vms']
        containers = normalized['containers']
        storage = normalized['storage']
        networks = normalized['networks']
        guest_details = normalized['guest_details']

        collections = {
            'vms': vms,
            'containers': containers,
            'storage': storage,
            'networks': networks,
        }

        for name, items in collections.items():
            if isinstance(items, list) and len(items) > limits['max_items_per_collection']:
                return jsonify({
                    'success': False,
                    'error': f'{name} exceeds max items per collection',
                    'limit': limits['max_items_per_collection']
                }), 400

        total_items = sum(len(items) for items in collections.values() if isinstance(items, list))
        if total_items > limits['max_total_items']:
            return jsonify({
                'success': False,
                'error': 'Discovery payload exceeds max total items',
                'limit': limits['max_total_items']
            }), 400

        counts = upsert_agent_discovery(agent_id, {
            'vms': vms,
            'containers': containers,
            'storage': storage,
            'networks': networks,
            'guest_details': guest_details,
        })

        vm_count = counts['vms']
        ct_count = counts['containers']

        logger.info(f"Received discovery from {agent_id}: {vm_count} VMs, {ct_count} containers")

        return jsonify({
            'success': True,
            'message': 'Discovery data received',
            'counts': {
                'vms': vm_count,
                'containers': ct_count,
                'storage': counts['storage'],
                'networks': counts['networks']
            },
            'guest_details_included': bool(guest_details),
        })

    except Exception as e:
        logger.error(f"Submit discovery failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# License Validation Endpoints (Agent Phone-Home)
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/validate-license', methods=['POST'])
def validate_agent_license():
    """
    Validate agent license - required for agent to operate.

    This is the phone-home endpoint that agents call on startup and periodically
    to validate their license. Prevents unauthorized/independent operation.

    Request body:
    {
        "agent_id": "esxi-prod-01",
        "organization_id": "org_123",
        "fingerprint": "abc123...",
        "platform": "esxi",
        "issued_at": "2026-02-19T10:00:00"
    }

    Returns:
    {
        "valid": true/false,
        "message": "License validated",
        "expires_at": "2026-03-19T10:00:00",
        "grace_period_ends": null
    }
    """
    try:
        data = request.get_json() or {}

        agent_id = data.get('agent_id', '')
        org_id = data.get('organization_id', '')
        fingerprint = data.get('fingerprint', '')
        platform = data.get('platform', '')
        issued_at = data.get('issued_at', '')

        if not all([agent_id, org_id, fingerprint]):
            return jsonify({
                'valid': False,
                'error': 'Missing required fields',
                'message': 'agent_id, organization_id, and fingerprint are required',
            }), 400

        # Regenerate fingerprint to validate
        license_data = f"{org_id}:{data.get('user_id', 'unknown')}:{issued_at}:{platform}"
        expected_hash = hashlib.sha256(license_data.encode()).hexdigest()[:32]

        # Check if agent is registered
        agent = _agents.get(agent_id)
        if not agent:
            logger.warning(f"License validation for unregistered agent: {agent_id}")
            return jsonify({
                'valid': False,
                'error': 'Agent not registered',
                'message': 'This agent is not registered with the server. Please register first.',
                'action': 'register',
            }), 403

        # Validate fingerprint (basic check - production should use crypto signatures)
        # In production, also verify against license service

        # Check Professional-or-higher license for the organization
        license_check = _check_enterprise_license('HYPERVISOR_AGENT_MANAGE')
        if not license_check['allowed']:
            logger.warning(f"License validation failed - insufficient license tier: org={org_id}, agent={agent_id}")
            return jsonify({
                'valid': False,
                'error': 'Professional or higher licence required',
                'message': 'Your organization requires a Professional or Advanced Operations Pack Add-On licence for hypervisor agents.',
                'grace_period_ends': (datetime.now() + timedelta(hours=72)).isoformat(),
            }), 403

        # License is valid
        logger.info(f"License validated for agent {agent_id}, org={org_id}")

        return jsonify({
            'valid': True,
            'message': 'License validated successfully',
            'agent_id': agent_id,
            'organization_id': org_id,
            'validated_at': datetime.now().isoformat(),
            'next_validation_required': (datetime.now() + timedelta(days=1)).isoformat(),
            'features_enabled': {
                'audit': True,
                'discovery': True,
                'remediation': license_check.get('tier') == 'enterprise',
            },
        })

    except Exception as e:
        logger.error(f"License validation error: {e}")
        return jsonify({
            'valid': False,
            'error': 'Validation failed',
            'message': str(e),
        }), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/downloads/audit', methods=['GET'])
@require_agent_auth
def get_download_audit_trail():
    """
    Get audit trail of hypervisor agent downloads.

    SuperAdmin only endpoint for reviewing download activity.
    """
    if not _is_superadmin():
        return jsonify({'error': 'SuperAdmin access required'}), 403

    # Filter parameters
    user_id = request.args.get('user_id')
    org = request.args.get('organization')
    start_date = request.args.get('start_date')

    filtered = _download_audit_trail.copy()

    if user_id:
        filtered = [e for e in filtered if e.get('user_id') == user_id]
    if org:
        filtered = [e for e in filtered if e.get('organization') == org]
    if start_date:
        filtered = [e for e in filtered if e.get('timestamp', '') >= start_date]

    return jsonify({
        'success': True,
        'count': len(filtered),
        'entries': filtered[-100:],  # Last 100 entries
        'total_downloads': sum(1 for e in filtered if e.get('success')),
        'failed_attempts': sum(1 for e in filtered if not e.get('success')),
    })


# =============================================================================
# Admin Endpoints
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/stats', methods=['GET'])
@require_agent_auth
def get_agent_stats():
    """Get statistics about registered agents"""
    try:
        total = len(_agents)
        online = sum(1 for a in _agents.values() if a.get('status') == 'online')
        offline = total - online

        by_platform = {}
        for agent in _agents.values():
            platform = agent.get('platform', 'unknown')
            by_platform[platform] = by_platform.get(platform, 0) + 1

        return jsonify({
            'success': True,
            'stats': {
                'total': total,
                'online': online,
                'offline': offline,
                'by_platform': by_platform
            }
        })

    except Exception as e:
        logger.error(f"Get stats failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/trigger-audit', methods=['POST'])
@require_agent_auth
def trigger_audit(agent_id):
    """
    Queue an audit command for an agent (convenience endpoint).

    Request body (optional):
    {
        "categories": ["security", "network"]
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        data = request.get_json() or {}

        command = _queue_agent_command(
            agent_id,
            'run_audit',
            params={'categories': data.get('categories')},
            priority='high'
        )

        logger.info(f"Audit triggered for {agent_id}")

        return jsonify({
            'success': True,
            'command_id': command['id'],
            'message': f'Audit queued for {agent_id}'
        })

    except Exception as e:
        logger.error(f"Trigger audit failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/trigger-script-audit', methods=['POST'])
@require_agent_auth
def trigger_script_audit(agent_id):
    """
    Queue a platform audit script command for an agent.

    Request body:
    {
        "script": "proxmox/proxmox-api-audit.py",
        "args": ["--help"],
        "timeout": 300
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        data = request.get_json() or {}
        script = str(data.get('script', '')).strip()
        if not script:
            return jsonify({'success': False, 'error': 'Missing script path'}), 400
        if script.startswith('/') or '..' in script:
            return jsonify({'success': False, 'error': 'Invalid script path'}), 400
        if not (script.endswith('.py') or script.endswith('.sh')):
            return jsonify({'success': False, 'error': 'Only .py or .sh scripts are allowed'}), 400

        command = _queue_agent_command(
            agent_id,
            'run_platform_audit_script',
            params={
                'script': script,
                'args': data.get('args', []),
                'timeout': int(data.get('timeout', 300)),
            },
            priority=data.get('priority', 'high'),
        )

        logger.info(f"Script audit queued for {agent_id}: {script} (id={command['id']})")

        return jsonify({
            'success': True,
            'command_id': command['id'],
            'message': f'Script audit queued for {agent_id}',
        })

    except Exception as e:
        logger.error(f"Trigger script audit failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Configuration Endpoints
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/config', methods=['GET'])
@require_agent_auth
def get_agent_config(agent_id):
    """
    Get agent configuration.

    Returns the current configuration for the agent including:
    - Poll interval
    - Enabled audit categories
    - Result format settings
    - Retry settings
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = _agents[agent_id]
        config = agent.get('config', DEFAULT_AGENT_CONFIG.copy())

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'config': config,
            'last_updated': agent.get('config_updated_at', agent.get('registered_at'))
        })

    except Exception as e:
        logger.error(f"Get config failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/config', methods=['PUT'])
@require_agent_auth
def update_agent_config(agent_id):
    """
    Update agent configuration.

    Request body (partial update supported):
    {
        "poll_interval": 120,
        "categories": ["security", "network"],
        "auto_discovery": false
    }

    Also queues an update_config command so agent picks up changes.
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Missing config data'}), 400

        agent = _agents[agent_id]
        current_config = agent.get('config', DEFAULT_AGENT_CONFIG.copy())

        # Validate and merge config
        allowed_keys = set(DEFAULT_AGENT_CONFIG.keys())
        updated_keys = []

        for key, value in data.items():
            if key in allowed_keys:
                current_config[key] = value
                updated_keys.append(key)

        agent['config'] = current_config
        agent['config_updated_at'] = datetime.now().isoformat()

        # Persist to storage
        _save_agents_to_storage()

        # Queue update_config command for agent
        command = {
            'id': _get_next_command_id(),
            'type': 'update_config',
            'params': current_config,
            'priority': 'high',
            'created_at': datetime.now().isoformat()
        }

        if agent_id not in _commands:
            _commands[agent_id] = []
        _commands[agent_id].append(command)

        logger.info(f"Config updated for {agent_id}: {updated_keys}")

        return jsonify({
            'success': True,
            'config': current_config,
            'updated_keys': updated_keys,
            'command_id': command['id']
        })

    except Exception as e:
        logger.error(f"Update config failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Audit History Endpoints
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/audits', methods=['GET'])
@require_agent_auth
def get_audit_history(agent_id):
    """
    Get audit history for an agent.

    Query params:
    - limit: Max results to return (default: 10, max: 100)
    - offset: Skip this many results (default: 0)

    Returns recent cached audits. For full history, use core server's
    audit storage API.
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        # Parse pagination
        limit = min(int(request.args.get('limit', 10)), 100)
        offset = int(request.args.get('offset', 0))

        # Get cached audits; fall back to database when cache is empty
        audits = _audit_cache.get(agent_id, [])

        if not audits and DATABASE_AVAILABLE:
            db = _get_db_session()
            if db is not None:
                try:
                    hv_id = _agents[agent_id].get('hypervisor_id')
                    if hv_id is not None:
                        try:
                            from security_settings import get_security_setting
                            retention_days = get_security_setting('hypervisor_result_retention_days', 90)
                            max_records = get_security_setting('hypervisor_result_retention_max_records', 500)
                        except Exception:
                            retention_days = 90
                            max_records = 500

                        cutoff = datetime.utcnow() - timedelta(days=int(retention_days))
                        try:
                            rows = (
                                db.query(HypervisorAuditExecution)
                                .filter(HypervisorAuditExecution.hypervisor_id == hv_id)
                                .filter(HypervisorAuditExecution.started_at >= cutoff)
                                .all()
                            )
                        except AttributeError:
                            # Class-attribute access fails for non-SQLAlchemy mocks; fetch all
                            # and apply Python-side filtering for compatibility.
                            rows = db.query(HypervisorAuditExecution).all()
                            rows = [
                                r for r in rows
                                if getattr(r, 'hypervisor_id', None) == hv_id
                                and (
                                    getattr(r, 'started_at', None) is None
                                    or getattr(r, 'started_at') >= cutoff
                                )
                            ]
                        # Sort descending by started_at, cap at max_records
                        rows = sorted(rows, key=lambda r: r.started_at or datetime.min, reverse=True)
                        rows = rows[:int(max_records)]

                        loaded = []
                        for row in rows:
                            try:
                                output_data = _json.loads(row.output) if row.output else {}
                            except Exception:
                                output_data = {}
                            try:
                                summary_data = _json.loads(row.summary) if row.summary else {}
                            except Exception:
                                summary_data = {}
                            loaded.append({
                                'audit_id': output_data.get('audit_id', str(row.id)),
                                'agent_id': agent_id,
                                'started_at': row.started_at.isoformat() if row.started_at else None,
                                'completed_at': row.completed_at.isoformat() if row.completed_at else None,
                                'platform_version': output_data.get('platform_version', ''),
                                'checks': output_data.get('checks', []),
                                'summary': summary_data,
                            })

                        if loaded:
                            _audit_cache[agent_id] = loaded
                            audits = loaded
                except Exception as db_err:
                    logger.error(f"DB history fallback failed for {agent_id}: {db_err}")
                finally:
                    db.close()
        total = len(audits)

        # Apply pagination
        paginated = audits[offset:offset + limit]

        # Return summaries only (full audit via separate endpoint)
        summaries = []
        for audit in paginated:
            summaries.append({
                'audit_id': audit.get('audit_id'),
                'started_at': audit.get('started_at'),
                'completed_at': audit.get('completed_at'),
                'summary': audit.get('summary', {}),
                'platform_version': audit.get('platform_version')
            })

        return jsonify({
            'success': True,
            'agent_id': agent_id,
            'audits': summaries,
            'pagination': {
                'total': total,
                'limit': limit,
                'offset': offset,
                'has_more': (offset + limit) < total
            }
        })

    except Exception as e:
        logger.error(f"Get audit history failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/audits/<audit_id>', methods=['GET'])
@require_agent_auth
def get_audit_detail(agent_id, audit_id):
    """
    Get full details of a specific audit.

    Returns complete audit including all checks.
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        # Search cached audits
        audits = _audit_cache.get(agent_id, [])

        for audit in audits:
            if audit.get('audit_id') == audit_id:
                return jsonify({
                    'success': True,
                    'audit': audit
                })

        return jsonify({
            'success': False,
            'error': 'Audit not found in cache',
            'hint': 'For older audits, use the core server audit storage API'
        }), 404

    except Exception as e:
        logger.error(f"Get audit detail failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Bulk Operations
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/bulk/trigger-audit', methods=['POST'])
@require_agent_auth
def bulk_trigger_audit():
    """
    Trigger audits on multiple agents at once.

    Request body:
    {
        "agent_ids": ["agent1", "agent2"],  // Optional - if omitted, all agents
        "platform": "proxmox",               // Optional - filter by platform
        "categories": ["security"],          // Optional - audit categories
        "priority": "normal"                 // Optional - command priority
    }
    """
    try:
        data = request.get_json() or {}

        # Determine target agents
        agent_ids = data.get('agent_ids')
        platform_filter = data.get('platform')

        if agent_ids:
            # Use specified agents
            target_agents = [aid for aid in agent_ids if aid in _agents]
        elif platform_filter:
            # Filter by platform
            target_agents = [
                aid for aid, agent in _agents.items()
                if agent.get('platform') == platform_filter
            ]
        else:
            # All online agents
            target_agents = [
                aid for aid, agent in _agents.items()
                if _is_agent_online(agent)
            ]

        if not target_agents:
            return jsonify({
                'success': False,
                'error': 'No matching agents found'
            }), 404

        # Queue commands for all targets
        categories = data.get('categories')
        priority = data.get('priority', 'normal')
        results = []

        for agent_id in target_agents:
            command = _queue_agent_command(
                agent_id,
                'run_audit',
                params={'categories': categories},
                priority=priority
            )

            results.append({
                'agent_id': agent_id,
                'command_id': command['id']
            })

        logger.info(f"Bulk audit triggered for {len(target_agents)} agents")

        return jsonify({
            'success': True,
            'message': f'Audit queued for {len(target_agents)} agent(s)',
            'agents': results
        })

    except Exception as e:
        logger.error(f"Bulk trigger failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Key Management
# =============================================================================

@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/rotate-key', methods=['POST'])
@require_agent_auth
def rotate_agent_key(agent_id):
    """
    Rotate agent API key.

    Generates a new token and queues a key_rotation command.
    The agent will receive the new key and update its local config.

    Request body (optional):
    {
        "immediate": true  // If true, invalidate old key immediately
    }
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        data = request.get_json() or {}
        immediate = data.get('immediate', False)

        # Generate new token
        new_token = secrets.token_urlsafe(32)
        new_hash = _hash_key(new_token)

        agent = _agents[agent_id]
        old_hash = agent.get('token_hash')

        if immediate:
            # Immediate rotation - old token invalid now
            agent['token_hash'] = new_hash
        else:
            # Grace period - both tokens valid until agent acknowledges
            agent['pending_token_hash'] = new_hash

        agent['key_rotated_at'] = datetime.now().isoformat()

        # Persist to storage
        _save_agents_to_storage()

        # Queue key rotation command
        command = {
            'id': _get_next_command_id(),
            'type': 'key_rotation',
            'params': {
                'new_token': new_token,
                'immediate': immediate
            },
            'priority': 'high',
            'created_at': datetime.now().isoformat()
        }

        if agent_id not in _commands:
            _commands[agent_id] = []
        _commands[agent_id].append(command)

        logger.info(f"Key rotation initiated for {agent_id} (immediate={immediate})")

        return jsonify({
            'success': True,
            'message': 'Key rotation initiated',
            'command_id': command['id'],
            'immediate': immediate,
            'note': 'Agent will receive new key via command queue' if not immediate else 'Old key invalidated'
        })

    except Exception as e:
        logger.error(f"Key rotation failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/hypervisor-agent/<agent_id>/rotate-key/confirm', methods=['POST'])
@require_agent_auth
def confirm_key_rotation(agent_id):
    """
    Confirm key rotation was successful.

    Called by agent after successfully updating to new key.
    This activates the pending token and invalidates the old one.
    """
    try:
        if agent_id not in _agents:
            return jsonify({'success': False, 'error': 'Agent not found'}), 404

        agent = _agents[agent_id]
        pending_hash = agent.get('pending_token_hash')

        if not pending_hash:
            return jsonify({
                'success': False,
                'error': 'No pending key rotation'
            }), 400

        # Activate new key
        agent['token_hash'] = pending_hash
        del agent['pending_token_hash']
        agent['key_confirmed_at'] = datetime.now().isoformat()

        # Persist to storage
        _save_agents_to_storage()

        logger.info(f"Key rotation confirmed for {agent_id}")

        return jsonify({
            'success': True,
            'message': 'Key rotation confirmed'
        })

    except Exception as e:
        logger.error(f"Key rotation confirm failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Agent Management UI Endpoints (Front-end uses these)
# =============================================================================

@hypervisor_agent_bp.route('/api/agents/config', methods=['POST'])
def batch_update_agent_config():
    """
    Batch update configuration for multiple agents.

    Used by the Agent Management UI to configure audit schedules.

    Request body:
    {
        "agents": ["agent-001", "agent-002"],
        "audits": ["security-hardening", "access-control"],
        "schedule": {
            "type": "immediate" | "manual" | "scheduled" | "recurring",
            "runImmediate": true/false,
            "scheduledTime": "2026-02-20T02:00:00",  // for scheduled
            "recurring": {
                "frequency": "daily" | "weekly" | "monthly",
                "timeOfDay": "02:00",
                "daysOfWeek": [1, 3, 5],  // for weekly
                "dayOfMonth": "15"  // for monthly
            }
        }
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        agent_ids = data.get('agents', [])
        audits = data.get('audits', [])
        schedule_config = data.get('schedule', {})

        if not agent_ids:
            return jsonify({'success': False, 'error': 'No agents specified'}), 400

        results = []
        schedule_type = schedule_config.get('type', 'immediate')

        for agent_id in agent_ids:
            try:
                # Initialize agent if not exists (for demo purposes)
                if agent_id not in _agents:
                    _agents[agent_id] = {
                        'agent_id': agent_id,
                        'registered_at': datetime.now().isoformat(),
                        'config': DEFAULT_AGENT_CONFIG.copy()
                    }
                    _save_agents_to_storage()  # Persist new demo agent

                agent = _agents[agent_id]
                config = agent.get('config', DEFAULT_AGENT_CONFIG.copy())

                # Build cron expression from schedule config
                cron_expr, cron_desc = _build_cron_from_schedule(schedule_config)

                # Update agent config with schedule
                config['schedule'] = {
                    'enabled': schedule_type != 'manual',
                    'type': schedule_type,
                    'cron': cron_expr,
                    'cron_description': cron_desc,
                    'audits': audits,
                    'run_immediate': schedule_config.get('runImmediate', False),
                    'created_at': datetime.now().isoformat()
                }

                if schedule_type == 'scheduled':
                    config['schedule']['scheduled_time'] = schedule_config.get('scheduledTime')
                elif schedule_type == 'recurring':
                    config['schedule']['recurring'] = schedule_config.get('recurring', {})

                agent['config'] = config
                agent['config_updated_at'] = datetime.now().isoformat()

                # If immediate execution, queue audit command
                if schedule_config.get('runImmediate') or schedule_type == 'immediate':
                    command = {
                        'id': _get_next_command_id(),
                        'type': 'run_audit',
                        'params': {'audits': audits},
                        'priority': 'normal',
                        'created_at': datetime.now().isoformat()
                    }
                    if agent_id not in _commands:
                        _commands[agent_id] = []
                    _commands[agent_id].append(command)

                results.append({
                    'agent_id': agent_id,
                    'success': True,
                    'schedule_type': schedule_type
                })

            except Exception as agent_err:
                results.append({
                    'agent_id': agent_id,
                    'success': False,
                    'error': str(agent_err)
                })

        success_count = sum(1 for r in results if r['success'])

        # Persist all changes in one write
        if success_count > 0:
            _save_agents_to_storage()

        logger.info(f"Batch config update: {success_count}/{len(agent_ids)} agents configured")

        return jsonify({
            'success': True,
            'configured': success_count,
            'total': len(agent_ids),
            'results': results
        })

    except Exception as e:
        logger.error(f"Batch config update failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/agents/trigger', methods=['POST'])
def trigger_agent_audits():
    """
    Trigger manual audit execution on selected agents.

    Request body:
    {
        "agents": ["agent-001", "agent-002"]
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Missing request body'}), 400

        agent_ids = data.get('agents', [])
        if not agent_ids:
            return jsonify({'success': False, 'error': 'No agents specified'}), 400

        results = []
        for agent_id in agent_ids:
            try:
                if agent_id not in _agents:
                    results.append({
                        'agent_id': agent_id,
                        'success': False,
                        'error': 'Agent not found'
                    })
                    continue

                agent = _agents[agent_id]
                config = agent.get('config', {})
                audits = config.get('schedule', {}).get('audits', ['security-hardening'])

                # Queue run_audit command
                command = {
                    'id': _get_next_command_id(),
                    'type': 'run_audit',
                    'params': {'audits': audits, 'trigger': 'manual'},
                    'priority': 'high',
                    'created_at': datetime.now().isoformat()
                }

                if agent_id not in _commands:
                    _commands[agent_id] = []
                _commands[agent_id].append(command)

                results.append({
                    'agent_id': agent_id,
                    'success': True,
                    'command_id': command['id']
                })

            except Exception as agent_err:
                results.append({
                    'agent_id': agent_id,
                    'success': False,
                    'error': str(agent_err)
                })

        success_count = sum(1 for r in results if r['success'])
        logger.info(f"Manual trigger: {success_count}/{len(agent_ids)} agents")

        return jsonify({
            'success': True,
            'triggered': success_count,
            'total': len(agent_ids),
            'results': results
        })

    except Exception as e:
        logger.error(f"Trigger audits failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@hypervisor_agent_bp.route('/api/agents/schedules', methods=['GET'])
def get_agent_schedules():
    """
    Get all agent schedules for the schedules page.

    Returns schedules in a format compatible with the main schedules view.
    These are displayed alongside server/hypervisor schedules.
    """
    try:
        schedules = []

        for agent_id, agent in _agents.items():
            config = agent.get('config', {})
            schedule = config.get('schedule', {})

            if not schedule.get('enabled', False) and schedule.get('type') != 'manual':
                continue

            # Skip if no schedule defined
            if not schedule:
                continue

            schedule_type = schedule.get('type', 'manual')
            cron = schedule.get('cron', '0 2 * * *')
            cron_desc = schedule.get('cron_description', 'Daily at 2:00 AM')

            # Calculate next run for active schedules
            next_run = None
            if schedule_type not in ['manual'] and schedule.get('enabled', False):
                try:
                    from croniter import croniter
                    cron_iter = croniter(cron, datetime.now())
                    next_run = cron_iter.get_next(datetime).isoformat()
                except Exception:
                    next_run = None

            schedules.append({
                'id': f'agent-{agent_id}',
                'name': f'{agent_id} Audit Schedule',
                'is_active': schedule.get('enabled', False),
                'schedule_source': 'agent',
                'agent_id': agent_id,
                'agent_name': agent.get('hostname', agent_id),
                'agent_platform': agent.get('hypervisor_type', 'unknown'),
                'cron_schedule': cron,
                'cron_description': cron_desc,
                'schedule_type': schedule_type,
                'audits': schedule.get('audits', []),
                'next_run': next_run,
                'last_run': agent.get('last_audit_run'),
                'last_status': agent.get('last_audit_status'),
                'created_at': schedule.get('created_at', agent.get('registered_at')),
                'updated_at': agent.get('config_updated_at')
            })

        logger.info(f"Returning {len(schedules)} agent schedules")

        return jsonify({
            'success': True,
            'schedules': schedules,
            'total': len(schedules)
        })

    except Exception as e:
        logger.error(f"Get agent schedules failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _build_cron_from_schedule(schedule_config):
    """
    Convert schedule configuration to cron expression.

    Returns (cron_expr, description)
    """
    schedule_type = schedule_config.get('type', 'immediate')

    if schedule_type == 'immediate':
        return '* * * * *', 'Immediate (one-time)'

    if schedule_type == 'manual':
        return '0 0 31 2 *', 'Manual trigger only'  # Never matches

    if schedule_type == 'scheduled':
        # One-time scheduled
        scheduled_time = schedule_config.get('scheduledTime')
        if scheduled_time:
            try:
                dt = datetime.fromisoformat(scheduled_time.replace('Z', '+00:00'))
                return f'{dt.minute} {dt.hour} {dt.day} {dt.month} *', f'One-time: {dt.strftime("%Y-%m-%d %H:%M")}'
            except Exception as schedule_error:
                logger.debug(f"Invalid scheduledTime provided for cron conversion: {schedule_error}")
        return '0 2 * * *', 'Scheduled'

    if schedule_type == 'recurring':
        recurring = schedule_config.get('recurring', {})
        frequency = recurring.get('frequency', 'daily')
        time_of_day = recurring.get('timeOfDay', '02:00')

        try:
            hour, minute = time_of_day.split(':')
            hour = int(hour)
            minute = int(minute)
        except Exception:
            hour, minute = 2, 0

        if frequency == 'daily':
            return f'{minute} {hour} * * *', f'Daily at {time_of_day}'

        elif frequency == 'weekly':
            days = recurring.get('daysOfWeek', [1])  # Default Monday
            day_str = ','.join(str(d) for d in days)
            day_names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
            day_desc = ', '.join(day_names[d] for d in days if 0 <= d <= 6)
            return f'{minute} {hour} * * {day_str}', f'Weekly on {day_desc} at {time_of_day}'

        elif frequency == 'monthly':
            day_of_month = recurring.get('dayOfMonth', '1')
            if day_of_month == 'last':
                # Last day of month approximation
                return f'{minute} {hour} 28 * *', f'Monthly on last day at {time_of_day}'
            return f'{minute} {hour} {day_of_month} * *', f'Monthly on day {day_of_month} at {time_of_day}'

    return '0 2 * * *', 'Daily at 2:00 AM'
