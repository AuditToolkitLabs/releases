"""
Hypervisor Routes - Hypervisor Management and Auditing API

Provides endpoints for:
- Listing hypervisors (GET /api/hypervisors)
- Adding hypervisors (POST /api/hypervisors)
- Updating hypervisors (PUT /api/hypervisors/<id>)
- Removing hypervisors (DELETE /api/hypervisors/<id>)
- Testing connections (POST /api/hypervisors/<id>/test)
- Running audits (POST /api/hypervisors/<id>/audit)
- Getting audit history (GET /api/hypervisors/<id>/history)

Storage: Database (PostgreSQL/SQLite) via SQLAlchemy ORM
Passwords/API tokens: Encrypted with Fernet before storage
Audit execution: Uses orchestrator/hypervisor-audit-runner.py (API-based, no SSH required)
"""

import os
import json
import sys
import subprocess  # nosec B404
import threading
from datetime import datetime
from flask import Blueprint, jsonify, request, g

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    requests = None
    REQUESTS_AVAILABLE = False

from config import logger, ROOT_DIR

# Import auth decorators
try:
    from auth_core import require_auth_and_permission, conditional_limit
except ImportError:
    # Fallback for testing
    def require_auth_and_permission(perm):
        def decorator(f):
            return f
        return decorator

    def conditional_limit(limit):
        def decorator(f):
            return f
        return decorator

# Import database models
try:
    from models.database import Hypervisor, HypervisorAuditExecution
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    Hypervisor = None
    HypervisorAuditExecution = None

# Import encryption for password/token storage
try:
    from encryption import password_manager
    ENCRYPTION_AVAILABLE = True
except ImportError:
    password_manager = None
    ENCRYPTION_AVAILABLE = False

# Import pagination
try:
    from pagination import PaginationParams, paginate_list
except ImportError:
    PaginationParams = None
    paginate_list = None

# =============================================================================
# Feature Licensing - Hypervisor features require licensed access
# =============================================================================
try:
    from services_pkg.services.feature_licensing import (
        Feature,
        LicenseTier,
        get_feature_service,
        require_feature,
        FEATURE_CONFIG,
    )
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    Feature = None
    LicenseTier = None
    require_feature = None

# Beta flag for testing hypervisor features in free tier
BETA_HYPERVISOR_ENABLED = os.environ.get('BETA_HYPERVISOR_ENABLED', 'false').lower() == 'true'


def _get_current_user_tier() -> str:
    """Get current user's license tier."""
    if not FEATURE_LICENSING_AVAILABLE:
        return 'enterprise'  # Dev mode - full access
    try:
        service = get_feature_service()
        user_id = None
        try:
            from flask_login import current_user
            if current_user and current_user.is_authenticated:
                user_id = str(current_user.id)
        except Exception as user_lookup_error:
            logger.debug(f"Unable to resolve current user while checking tier: {user_lookup_error}")
        # Get user's tier from service
        tier = service.get_user_tier(user_id) if hasattr(service, 'get_user_tier') else 'free'
        return tier
    except Exception:
        return 'free'


def _get_hypervisor_count() -> int:
    """Get count of configured hypervisors for current user/org."""
    if not DATABASE_AVAILABLE:
        return 0
    try:
        session = get_db_session()
        if session:
            count = session.query(Hypervisor).count()
            session.close()
            return count
    except Exception as count_error:
        logger.debug(f"Unable to count configured hypervisors: {count_error}")
    return 0


def _check_hypervisor_license(feature_name: str = 'HYPERVISOR_VIEW', platform: str = None) -> dict:
    """
    Check if user has license for hypervisor feature.

    Args:
        feature_name: The feature to check (HYPERVISOR_VIEW, HYPERVISOR_ADD, etc.)
        platform: Optional platform type to check (esxi, proxmox, etc.)

    Returns:
        dict: {
            'allowed': bool,
            'reason': str,
            'tier': str,
            'limits': dict,
            'upgrade_message': str
        }
    """
    # Beta testing bypass
    if BETA_HYPERVISOR_ENABLED:
        return {
            'allowed': True,
            'reason': 'beta_testing',
            'tier': 'beta',
            'limits': {'max_hypervisors': 2, 'platforms': ['esxi', 'hyperv']},
        }

    if not FEATURE_LICENSING_AVAILABLE:
        return {'allowed': True, 'reason': 'dev_mode', 'tier': 'enterprise'}

    try:
        service = get_feature_service()
        user_id = None
        try:
            from flask_login import current_user
            if current_user and current_user.is_authenticated:
                user_id = str(current_user.id)
        except Exception as user_lookup_error:
            logger.debug(f"Unable to resolve current user for license check: {user_lookup_error}")

        # Get the feature enum
        feature = getattr(Feature, feature_name, None)
        if not feature:
            return {'allowed': False, 'reason': 'invalid_feature', 'tier': 'unknown'}

        # Check feature availability
        status = service.is_feature_available(feature, user_id)

        if not status.get('available'):
            return {
                'allowed': False,
                'reason': status.get('reason', 'license_required'),
                'tier': status.get('tier', 'free'),
                'required_tier': status.get('upgrade_tier', 'professional'),
                'upgrade_message': status.get(
                    'reason',
                    'Hypervisor management requires a Professional licence.'
                ),
                'upgrade_url': '/pricing?feature=hypervisor',
            }

        # Get tier-specific limits
        tier = status.get('tier', 'free')
        feature_config = FEATURE_CONFIG.get(feature, {})
        limits = feature_config.get('limits', {}).get(tier, {})

        # Check platform restriction
        if platform and limits:
            allowed_platforms = limits.get('platforms', 'all')
            if allowed_platforms != 'all' and platform not in allowed_platforms:
                return {
                    'allowed': False,
                    'reason': 'platform_not_allowed',
                    'tier': tier,
                    'allowed_platforms': allowed_platforms,
                    'required_tier': 'professional+advanced_operations_pack',
                    'upgrade_message': (
                        f'Platform "{platform}" requires the Advanced Operations Pack add-on with a Professional licence. '
                        f'Your {tier} license supports: {", ".join(allowed_platforms)}'
                    ),
                    'upgrade_url': '/pricing?feature=hypervisor',
                }

        # Check hypervisor count limit
        max_hypervisors = limits.get('max_hypervisors')
        if max_hypervisors is not None:
            current_count = _get_hypervisor_count()
            if current_count >= max_hypervisors:
                return {
                    'allowed': False,
                    'reason': 'hypervisor_limit_reached',
                    'tier': tier,
                    'current_count': current_count,
                    'max_allowed': max_hypervisors,
                    'upgrade_message': f'You have reached your limit of {max_hypervisors} hypervisors. '
                                       f'Upgrade to add more.',
                    'upgrade_url': '/pricing?feature=hypervisor',
                }

        return {
            'allowed': True,
            'reason': 'licensed',
            'tier': tier,
            'limits': limits,
        }

    except Exception as e:
        logger.warning(f"License check failed: {e}, allowing access")
        return {'allowed': True, 'reason': 'check_failed', 'tier': 'unknown'}


def require_hypervisor_license(feature_name: str = 'HYPERVISOR_VIEW'):
    """
    Decorator to require hypervisor license for an endpoint.

    Usage:
        @require_hypervisor_license('HYPERVISOR_ADD')
        def add_hypervisor():
            ...
    """
    from functools import wraps

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get platform from request if available
            platform = None
            if request.is_json:
                data = request.get_json(silent=True) or {}
                platform = data.get('hypervisor_type') or data.get('type')
            elif request.args:
                platform = request.args.get('type')

            # Check license
            check = _check_hypervisor_license(feature_name, platform)

            if not check['allowed']:
                return jsonify({
                    'success': False,
                    'error': 'License required',
                    'code': 'HYPERVISOR_LICENSE_REQUIRED',
                    'reason': check['reason'],
                    'tier': check.get('tier'),
                    'required_tier': check.get('required_tier', 'professional'),
                    'message': check.get('upgrade_message',
                        'Hypervisor auditing is a premium feature requiring a Professional licence.'),
                    'upgrade_url': check.get('upgrade_url', '/pricing?feature=hypervisor'),
                    'limits': check.get('limits'),
                }), 403

            # Store license info in request context
            request.hypervisor_license = check
            return f(*args, **kwargs)

        return decorated_function
    return decorator


hypervisor_bp = Blueprint('hypervisors', __name__)

# Supported hypervisor types
SUPPORTED_HYPERVISOR_TYPES = [
    'esxi',      # VMware ESXi standalone host
    'vcenter',   # VMware vCenter Server
    'proxmox',   # Proxmox VE
    'xen',       # XCP-ng / Citrix Hypervisor (XAPI)
    'kvm',       # KVM/libvirt
    'nutanix',   # Nutanix AHV
    'xo'         # Xen Orchestra
]

# Default API ports per hypervisor type
DEFAULT_PORTS = {
    'esxi': 443,
    'vcenter': 443,
    'proxmox': 8006,
    'xen': 443,
    'kvm': 16509,  # libvirt
    'nutanix': 9440,
    'xo': 443
}

SUPPORTED_CONNECTION_METHODS = ['api', 'ssh']

# Path to hypervisor audit runner
HYPERVISOR_RUNNER = ROOT_DIR / 'orchestrator' / 'hypervisor-audit-runner.py'

# Session factory - set by init function
_session_factory = None


def get_session_local():
    """Get database session factory (lazy loading to avoid circular imports)."""
    global _session_factory
    if _session_factory is None:
        try:
            from config import SessionLocal
            _session_factory = SessionLocal
        except ImportError:
            return None
    return _session_factory


def get_db_session():
    """Get a database session."""
    SessionLocal = get_session_local()
    if SessionLocal is None:
        return None
    return SessionLocal()


def encrypt_credential(value: str) -> str:
    """Encrypt a credential value for storage."""
    if not value:
        return None
    if ENCRYPTION_AVAILABLE and password_manager:
        return password_manager.encrypt(value)
    return value  # No encryption available - store plaintext (not recommended)


def decrypt_credential(value: str) -> str:
    """Decrypt a credential value."""
    if not value:
        return None
    if ENCRYPTION_AVAILABLE and password_manager:
        return password_manager.decrypt(value)
    return value


def _normalize_connection_method(method: str) -> str:
    """Normalize connection method aliases to canonical hypervisor values."""
    if not method:
        return 'api'

    method = str(method).strip().lower()
    if method in ['api', 'https', 'rest']:
        return 'api'
    if method in ['ssh', 'direct-ssh', 'direct_ssh']:
        return 'ssh'

    return 'api'


def _safe_request_json(method: str, url: str, **kwargs):
    """Run a requests call and return parsed JSON payload when possible."""
    if not REQUESTS_AVAILABLE:
        return None
    try:
        response = requests.request(method=method, url=url, timeout=15, **kwargs)
        if response.status_code >= 400:
            return None
        return response.json()
    except Exception:
        return None


def _collect_direct_discovery(hypervisor) -> dict:
    """Best-effort VM/container/storage/network discovery for direct API audits."""
    if not REQUESTS_AVAILABLE:
        return {}

    hv_type = str(getattr(hypervisor, 'hypervisor_type', '') or '').lower()
    host = getattr(hypervisor, 'hostname', None)
    port = getattr(hypervisor, 'port', None)
    verify_ssl = bool(getattr(hypervisor, 'verify_ssl', True))
    username = getattr(hypervisor, 'username', None)
    password = decrypt_credential(getattr(hypervisor, 'password', None) or '')
    api_token = decrypt_credential(getattr(hypervisor, 'api_token', None) or '')

    if not host:
        return {}

    base_url = f"https://{host}:{port or DEFAULT_PORTS.get(hv_type, 443)}"
    discovery = {
        'vms': [],
        'containers': [],
        'storage': [],
        'networks': [],
        'guest_details': {},
    }

    if hv_type in ('vcenter', 'esxi'):
        if not username or not password:
            return discovery

        auth = (username, password)
        session_resp = _safe_request_json('POST', f"{base_url}/api/session", auth=auth, verify=verify_ssl)
        session_id = session_resp if isinstance(session_resp, str) else None
        if not session_id:
            return discovery

        headers = {'vmware-api-session-id': session_id}
        vm_data = _safe_request_json('GET', f"{base_url}/api/vcenter/vm", headers=headers, verify=verify_ssl)
        if not isinstance(vm_data, list):
            vm_data = _safe_request_json('GET', f"{base_url}/api/vm", headers=headers, verify=verify_ssl)
        if isinstance(vm_data, list):
            discovery['vms'] = [
                {
                    'id': vm.get('vm') or vm.get('id'),
                    'name': vm.get('name'),
                    'power_state': vm.get('power_state') or vm.get('power'),
                    'guest_os': vm.get('guest_OS'),
                }
                for vm in vm_data if isinstance(vm, dict)
            ]

        networks = _safe_request_json('GET', f"{base_url}/api/vcenter/network", headers=headers, verify=verify_ssl)
        if isinstance(networks, list):
            discovery['networks'] = [
                {'id': net.get('network'), 'name': net.get('name'), 'type': net.get('type')}
                for net in networks if isinstance(net, dict)
            ]

        datastores = _safe_request_json('GET', f"{base_url}/api/vcenter/datastore", headers=headers, verify=verify_ssl)
        if isinstance(datastores, list):
            discovery['storage'] = [
                {'id': ds.get('datastore'), 'name': ds.get('name'), 'type': ds.get('type')}
                for ds in datastores if isinstance(ds, dict)
            ]

        for vm in discovery['vms'][:100]:
            vm_id = vm.get('id')
            if not vm_id:
                continue
            identity = _safe_request_json('GET', f"{base_url}/api/vcenter/vm/{vm_id}/guest/identity", headers=headers, verify=verify_ssl)
            if isinstance(identity, dict):
                discovery['guest_details'][str(vm_id)] = {
                    'hostname': identity.get('host_name'),
                    'os': identity.get('full_name') or vm.get('guest_os'),
                    'ips': [],
                }

    elif hv_type == 'proxmox':
        headers = {}

        if api_token:
            headers['Authorization'] = f"PVEAPIToken={api_token}"
        elif username and password:
            auth_data = _safe_request_json(
                'POST',
                f"{base_url}/api2/json/access/ticket",
                data={'username': username, 'password': password},
                verify=verify_ssl,
            )
            if isinstance(auth_data, dict):
                auth_payload = auth_data.get('data') or {}
                ticket = auth_payload.get('ticket')
                csrf = auth_payload.get('CSRFPreventionToken')
                if ticket:
                    headers['Cookie'] = f"PVEAuthCookie={ticket}"
                if csrf:
                    headers['CSRFPreventionToken'] = csrf

        vm_resp = _safe_request_json('GET', f"{base_url}/api2/json/cluster/resources?type=vm", headers=headers, verify=verify_ssl)
        vm_items = (vm_resp or {}).get('data', []) if isinstance(vm_resp, dict) else []
        for item in vm_items:
            if not isinstance(item, dict):
                continue
            vm_type = item.get('type')
            normalized = {
                'id': str(item.get('vmid', '')),
                'name': item.get('name') or f"{vm_type}-{item.get('vmid')}",
                'node': item.get('node'),
                'status': item.get('status'),
                'type': vm_type,
            }
            if vm_type == 'lxc':
                discovery['containers'].append(normalized)
            else:
                discovery['vms'].append(normalized)

        storage_resp = _safe_request_json('GET', f"{base_url}/api2/json/storage", headers=headers, verify=verify_ssl)
        storage_items = (storage_resp or {}).get('data', []) if isinstance(storage_resp, dict) else []
        discovery['storage'] = [
            {'id': s.get('storage'), 'type': s.get('type'), 'shared': s.get('shared')}
            for s in storage_items if isinstance(s, dict)
        ]

        nodes = sorted({vm.get('node') for vm in discovery['vms'] if vm.get('node')})
        for node in nodes[:25]:
            node_net = _safe_request_json('GET', f"{base_url}/api2/json/nodes/{node}/network", headers=headers, verify=verify_ssl)
            interfaces = (node_net or {}).get('data', []) if isinstance(node_net, dict) else []
            for iface in interfaces:
                if isinstance(iface, dict) and iface.get('iface'):
                    discovery['networks'].append({
                        'name': iface.get('iface'),
                        'type': iface.get('type'),
                        'node': node,
                    })

    elif hv_type == 'nutanix':
        if not username or not password:
            return discovery

        vm_resp = _safe_request_json(
            'POST',
            f"{base_url}/api/nutanix/v3/vms/list",
            json={'kind': 'vm', 'offset': 0, 'length': 500},
            auth=(username, password),
            verify=verify_ssl,
            headers={'Content-Type': 'application/json'},
        )
        entities = (vm_resp or {}).get('entities', []) if isinstance(vm_resp, dict) else []
        for vm in entities:
            if not isinstance(vm, dict):
                continue
            metadata = vm.get('metadata', {}) or {}
            spec = vm.get('spec', {}) or {}
            resources = spec.get('resources', {}) or {}
            discovery['vms'].append({
                'id': metadata.get('uuid'),
                'name': spec.get('name') or metadata.get('uuid'),
                'power_state': resources.get('power_state'),
                'vcpus': resources.get('num_vcpus_per_socket'),
            })

    return discovery


# ============================================================================
# Hypervisor CRUD Endpoints
# ============================================================================

@hypervisor_bp.route('/api/hypervisors', methods=['GET'])
@require_auth_and_permission('view_hypervisors')
@require_hypervisor_license('HYPERVISOR_VIEW')
@conditional_limit("100 per minute")
def list_hypervisors():
    """
    List all configured hypervisors.

    Query Parameters:
        type: Filter by hypervisor type (esxi, proxmox, etc.)
        status: Filter by status (online, offline, error, unknown)
        search: Search term for name/hostname
        page: Page number (default: 1)
        per_page: Items per page (default: 25, max: 100)

    Returns:
        JSON response with hypervisors list
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        query = db.query(Hypervisor)

        # Apply filters
        hv_type = request.args.get('type')
        if hv_type and hv_type in SUPPORTED_HYPERVISOR_TYPES:
            query = query.filter(Hypervisor.hypervisor_type == hv_type)

        status = request.args.get('status')
        if status in ['online', 'offline', 'error', 'unknown']:
            query = query.filter(Hypervisor.status == status)

        search = request.args.get('search')
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                (Hypervisor.name.ilike(search_term)) |
                (Hypervisor.hostname.ilike(search_term)) |
                (Hypervisor.datacenter.ilike(search_term))
            )

        # Order by name
        query = query.order_by(Hypervisor.name)

        # Get total count
        total = query.count()

        # Pagination
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 25, type=int), 100)
        offset = (page - 1) * per_page

        hypervisors = query.offset(offset).limit(per_page).all()

        return jsonify({
            "success": True,
            "hypervisors": [h.to_dict() for h in hypervisors],
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": total,
                "pages": (total + per_page - 1) // per_page
            }
        })

    except Exception as e:
        logger.error(f"Error listing hypervisors: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors', methods=['POST'])
@require_auth_and_permission('add_hypervisors')
@require_hypervisor_license('HYPERVISOR_ADD')
@conditional_limit("20 per hour")
def add_hypervisor():
    """
    Add a new hypervisor.

    Request Body (JSON):
        name: Unique display name (required)
        hostname: IP address or FQDN (required)
        hypervisor_type: Type (esxi, vcenter, proxmox, xen, kvm, nutanix, xo) (required)
        port: API port (optional, defaults based on type)
        username: API username (optional for some types)
        password: API password (optional)
        api_token: API token for token-based auth (optional)
        verify_ssl: Verify SSL certificates (default: true)
        api_endpoint: Custom API endpoint URL (optional)
        description: Description text (optional)
        tags: Comma-separated tags (optional)
        datacenter: Datacenter name (optional)
        cluster: Cluster name (optional)

    Returns:
        JSON response with created hypervisor
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request body"}), 400

        # Validate required fields
        name = data.get('name', '').strip()
        if not name or len(name) > 255:
            return jsonify({"success": False, "error": "Name is required (max 255 chars)"}), 400

        hostname = data.get('hostname', '').strip()
        if not hostname or len(hostname) > 255:
            return jsonify({"success": False, "error": "Hostname is required (max 255 chars)"}), 400

        hv_type = data.get('hypervisor_type', '').strip().lower()
        if hv_type not in SUPPORTED_HYPERVISOR_TYPES:
            return jsonify({
                "success": False,
                "error": f"Invalid hypervisor_type. Supported: {', '.join(SUPPORTED_HYPERVISOR_TYPES)}"
            }), 400

        connection_method = _normalize_connection_method(data.get('connection_method', 'api'))
        if connection_method not in SUPPORTED_CONNECTION_METHODS:
            return jsonify({
                "success": False,
                "error": f"Invalid connection_method. Supported: {', '.join(SUPPORTED_CONNECTION_METHODS)}"
            }), 400

        # Check for duplicate name
        existing = db.query(Hypervisor).filter(Hypervisor.name == name).first()
        if existing:
            return jsonify({"success": False, "error": f"Hypervisor with name '{name}' already exists"}), 400

        # Get port (default based on type)
        port = data.get('port')
        if port is None:
            port = DEFAULT_PORTS.get(hv_type, 443)
        else:
            try:
                port = int(port)
                if not (1 <= port <= 65535):
                    raise ValueError
            except (TypeError, ValueError):
                return jsonify({"success": False, "error": "Invalid port number"}), 400

        # Encrypt credentials
        password = encrypt_credential(data.get('password'))
        api_token = encrypt_credential(data.get('api_token'))

        # Create hypervisor record
        hypervisor = Hypervisor(
            name=name,
            hostname=hostname,
            port=port,
            hypervisor_type=hv_type,
            connection_method=connection_method,
            username=data.get('username', '').strip() or None,
            password=password,
            api_token=api_token,
            verify_ssl=data.get('verify_ssl', True),
            api_endpoint=data.get('api_endpoint', '').strip() or None,
            description=data.get('description', '').strip() or None,
            tags=data.get('tags', '').strip() or None,
            datacenter=data.get('datacenter', '').strip() or None,
            cluster=data.get('cluster', '').strip() or None,
            status='unknown'
        )

        db.add(hypervisor)
        db.commit()
        db.refresh(hypervisor)

        logger.info(f"Created hypervisor: {name} ({hv_type}@{hostname}:{port})")

        # Keep unified agent registry in sync
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=f"hypervisor-{hypervisor.id}",
                agent_type='hypervisor',
                hostname=hypervisor.hostname,
                name=hypervisor.name,
                os_type=hypervisor.hypervisor_type,
                status='unknown',
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed after hypervisor create: {sync_err}")

        return jsonify({
            "success": True,
            "message": "Hypervisor added successfully",
            "hypervisor": hypervisor.to_dict()
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error adding hypervisor: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>', methods=['GET'])
@require_auth_and_permission('view_hypervisors')
@conditional_limit("100 per minute")
def get_hypervisor(hypervisor_id):
    """Get a single hypervisor by ID."""
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        return jsonify({
            "success": True,
            "hypervisor": hypervisor.to_dict(include_sensitive=True)
        })

    except Exception as e:
        logger.error(f"Error getting hypervisor {hypervisor_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>', methods=['PUT'])
@require_auth_and_permission('edit_hypervisors')
@require_hypervisor_license('HYPERVISOR_ADD')  # Same as add - modify hypervisors
@conditional_limit("20 per hour")
def update_hypervisor(hypervisor_id):
    """
    Update an existing hypervisor.

    Only provided fields are updated, others remain unchanged.
    Passwords/tokens are only updated if non-empty value is provided.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request body"}), 400

        if 'connection_method' in data:
            requested_method = _normalize_connection_method(data.get('connection_method'))
            current_method = _normalize_connection_method(getattr(hypervisor, 'connection_method', 'api'))

            if requested_method != current_method:
                current_user = getattr(g, 'current_auth_user', None)
                user_role = getattr(current_user, 'role', None)
                if user_role not in ('Admin', 'SuperAdmin'):
                    return jsonify({
                        "success": False,
                        "error": "Only Admin or SuperAdmin can change connection_method for existing hypervisors",
                        "required_roles": ["Admin", "SuperAdmin"]
                    }), 403

        # Update allowed fields
        if 'name' in data:
            name = data['name'].strip()
            if name and len(name) <= 255:
                # Check for duplicate name (excluding current record)
                existing = db.query(Hypervisor).filter(
                    Hypervisor.name == name,
                    Hypervisor.id != hypervisor_id
                ).first()
                if existing:
                    return jsonify({"success": False, "error": f"Name '{name}' already in use"}), 400
                hypervisor.name = name

        if 'hostname' in data:
            hostname = data['hostname'].strip()
            if hostname and len(hostname) <= 255:
                hypervisor.hostname = hostname

        if 'hypervisor_type' in data:
            hv_type = data['hypervisor_type'].strip().lower()
            if hv_type not in SUPPORTED_HYPERVISOR_TYPES:
                return jsonify({
                    "success": False,
                    "error": f"Invalid hypervisor_type. Supported: {', '.join(SUPPORTED_HYPERVISOR_TYPES)}"
                }), 400
            hypervisor.hypervisor_type = hv_type

        if 'connection_method' in data:
            connection_method = _normalize_connection_method(data.get('connection_method'))
            if connection_method not in SUPPORTED_CONNECTION_METHODS:
                return jsonify({
                    "success": False,
                    "error": f"Invalid connection_method. Supported: {', '.join(SUPPORTED_CONNECTION_METHODS)}"
                }), 400
            hypervisor.connection_method = connection_method

        if 'port' in data:
            try:
                port = int(data['port'])
                if 1 <= port <= 65535:
                    hypervisor.port = port
            except (TypeError, ValueError):
                pass

        if 'username' in data:
            hypervisor.username = data['username'].strip() or None

        if 'password' in data and data['password']:
            hypervisor.password = encrypt_credential(data['password'])

        if 'api_token' in data and data['api_token']:
            hypervisor.api_token = encrypt_credential(data['api_token'])

        if 'verify_ssl' in data:
            hypervisor.verify_ssl = bool(data['verify_ssl'])

        if 'api_endpoint' in data:
            hypervisor.api_endpoint = data['api_endpoint'].strip() or None

        if 'description' in data:
            hypervisor.description = data['description'].strip() or None

        if 'tags' in data:
            hypervisor.tags = data['tags'].strip() or None

        if 'datacenter' in data:
            hypervisor.datacenter = data['datacenter'].strip() or None

        if 'cluster' in data:
            hypervisor.cluster = data['cluster'].strip() or None

        hypervisor.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(hypervisor)

        logger.info(f"Updated hypervisor: {hypervisor.name}")

        # Keep unified agent registry in sync
        try:
            from api.agents_unified_routes import update_agent_heartbeat
            update_agent_heartbeat(
                agent_id=f"hypervisor-{hypervisor.id}",
                agent_type='hypervisor',
                hostname=hypervisor.hostname,
                name=hypervisor.name,
                os_type=hypervisor.hypervisor_type,
                status='unknown' if hypervisor.status == 'unknown' else hypervisor.status,
            )
        except Exception as sync_err:
            logger.warning(f"Unified agent sync failed after hypervisor update: {sync_err}")

        return jsonify({
            "success": True,
            "message": "Hypervisor updated successfully",
            "hypervisor": hypervisor.to_dict()
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating hypervisor {hypervisor_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>', methods=['DELETE'])
@require_auth_and_permission('delete_hypervisors')
@require_hypervisor_license('HYPERVISOR_ADD')  # Same as add - admin operations
@conditional_limit("10 per hour")
def delete_hypervisor(hypervisor_id):
    """Delete a hypervisor and all its audit history."""
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        name = hypervisor.name
        agent_id = f"hypervisor-{hypervisor_id}"
        db.delete(hypervisor)
        db.commit()

        logger.info(f"Deleted hypervisor: {name}")

        # Deactivate the unified agent registry entry
        try:
            from api.agents_unified_routes import _db_session as _unified_db
            from models.database import FleetAgent
            if _unified_db:
                fa = _unified_db.query(FleetAgent).filter(FleetAgent.agent_id == agent_id).first()
                if fa:
                    fa.is_active = False
                    _unified_db.commit()
        except Exception as sync_err:
            logger.warning(f"Unified agent deactivation failed after hypervisor delete: {sync_err}")

        return jsonify({
            "success": True,
            "message": f"Hypervisor '{name}' deleted successfully"
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting hypervisor {hypervisor_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ============================================================================
# Connection Testing
# ============================================================================

@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>/test', methods=['POST'])
@require_auth_and_permission('test_hypervisors')
@require_hypervisor_license('HYPERVISOR_VIEW')  # Testing allowed at view level
@conditional_limit("30 per minute")
def test_hypervisor_connection(hypervisor_id):
    """
    Test connection to a hypervisor.

    Uses the hypervisor-audit-runner.py with --test-only flag.
    Updates the hypervisor status based on result.
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        # Build test command
        decrypted_password = decrypt_credential(hypervisor.password) or ''
        decrypted_token = decrypt_credential(hypervisor.api_token) or ''
        connection_method = _normalize_connection_method(
            getattr(hypervisor, 'connection_method', 'api')
        )

        # Prepare connection test via hypervisor-audit-runner.py
        cmd = [
            sys.executable, str(HYPERVISOR_RUNNER),
            '--host', hypervisor.hostname,
            '--port', str(hypervisor.port),
            '--type', hypervisor.hypervisor_type,
            '--test-only'
        ]

        if hypervisor.username:
            cmd.extend(['--user', hypervisor.username])
        if decrypted_password:
            cmd.extend(['--password', decrypted_password])
        if decrypted_token:
            cmd.extend(['--token', decrypted_token])
        if not hypervisor.verify_ssl:
            cmd.append('--no-verify-ssl')
        if hypervisor.hypervisor_type == 'kvm':
            cmd.extend(['--transport', 'ssh' if connection_method == 'ssh' else 'tls'])

        # Run test with timeout
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(ROOT_DIR)
            )  # nosec B603

            success = result.returncode == 0
            output = result.stdout + result.stderr

            # Update status
            hypervisor.status = 'online' if success else 'error'
            hypervisor.last_connection_check = datetime.utcnow()
            hypervisor.last_connection_error = None if success else output[:500]
            db.commit()

            return jsonify({
                "success": success,
                "status": hypervisor.status,
                "message": "Connection successful" if success else "Connection failed",
                "details": output[:1000] if not success else None
            })

        except subprocess.TimeoutExpired:
            hypervisor.status = 'error'
            hypervisor.last_connection_check = datetime.utcnow()
            hypervisor.last_connection_error = "Connection timed out"
            db.commit()

            return jsonify({
                "success": False,
                "status": "error",
                "message": "Connection timed out after 30 seconds"
            }), 504

    except Exception as e:
        db.rollback()
        logger.error(f"Error testing hypervisor {hypervisor_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors/test-connection', methods=['POST'])
@require_auth_and_permission('test_hypervisors')
@conditional_limit("30 per minute")
def test_raw_hypervisor_connection():
    """
    Test connection to a hypervisor before saving.

    Request Body (JSON):
        hostname: IP or FQDN (required)
        port: Port number (optional)
        hypervisor_type: Type (required)
        username: API username (optional)
        password: API password (optional)
        api_token: API token (optional)
        verify_ssl: Verify SSL (default: true)
    """
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request body"}), 400

        hostname = data.get('hostname', '').strip()
        hv_type = data.get('hypervisor_type', '').strip().lower()
        connection_method = _normalize_connection_method(data.get('connection_method', 'api'))

        if not hostname:
            return jsonify({"success": False, "error": "Hostname is required"}), 400
        if hv_type not in SUPPORTED_HYPERVISOR_TYPES:
            return jsonify({"success": False, "error": "Invalid hypervisor type"}), 400

        port = data.get('port') or DEFAULT_PORTS.get(hv_type, 443)

        # Build test command
        cmd = [
            sys.executable, str(HYPERVISOR_RUNNER),
            '--host', hostname,
            '--port', str(port),
            '--type', hv_type,
            '--test-only'
        ]

        if data.get('username'):
            cmd.extend(['--user', data['username']])
        if data.get('password'):
            cmd.extend(['--password', data['password']])
        if data.get('api_token'):
            cmd.extend(['--token', data['api_token']])
        if not data.get('verify_ssl', True):
            cmd.append('--no-verify-ssl')
        if hv_type == 'kvm':
            cmd.extend(['--transport', 'ssh' if connection_method == 'ssh' else 'tls'])

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(ROOT_DIR)
        )  # nosec B603

        success = result.returncode == 0
        output = result.stdout + result.stderr

        return jsonify({
            "success": success,
            "message": "Connection successful" if success else "Connection failed",
            "details": output[:1000] if not success else None
        })

    except subprocess.TimeoutExpired:
        return jsonify({
            "success": False,
            "message": "Connection timed out after 30 seconds"
        }), 504
    except Exception as e:
        logger.error(f"Error testing raw connection: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Audit Execution
# ============================================================================

# Track running audits
_running_audits = {}


@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>/audit', methods=['POST'])
@require_auth_and_permission('run_hypervisor_audits')
@require_hypervisor_license('HYPERVISOR_AUDIT_BASIC')  # Audit requires audit license
@conditional_limit("10 per hour")
def run_hypervisor_audit(hypervisor_id):
    """
    Run a security audit on a hypervisor.

    Uses hypervisor-audit-runner.py to execute API-based audit.

    Request Body (JSON, optional):
        audit_type: Type of audit (security, compliance, performance) - default: security
        async: Run asynchronously (default: false)

    Returns:
        JSON with audit results or execution ID if async
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        # Check if audit already running
        if hypervisor_id in _running_audits:
            return jsonify({
                "success": False,
                "error": "Audit already running for this hypervisor",
                "execution_id": _running_audits[hypervisor_id]
            }), 409

        data = request.json or {}
        audit_type = data.get('audit_type', 'security')
        run_async = data.get('async', False)

        # Create execution record
        execution = HypervisorAuditExecution(
            hypervisor_id=hypervisor_id,
            audit_type=audit_type,
            audit_script=f"{hypervisor.hypervisor_type}-api-audit.py",
            status='running',
            started_at=datetime.utcnow()
        )
        db.add(execution)
        db.commit()
        db.refresh(execution)

        execution_id = execution.id
        _running_audits[hypervisor_id] = execution_id

        # Build audit command
        decrypted_password = decrypt_credential(hypervisor.password) or ''
        decrypted_token = decrypt_credential(hypervisor.api_token) or ''
        connection_method = _normalize_connection_method(
            getattr(hypervisor, 'connection_method', 'api')
        )

        cmd = [
            sys.executable, str(HYPERVISOR_RUNNER),
            '--host', hypervisor.hostname,
            '--port', str(hypervisor.port),
            '--type', hypervisor.hypervisor_type,
            '--output', 'json'
        ]

        if hypervisor.username:
            cmd.extend(['--user', hypervisor.username])
        if decrypted_password:
            cmd.extend(['--password', decrypted_password])
        if decrypted_token:
            cmd.extend(['--token', decrypted_token])
        if not hypervisor.verify_ssl:
            cmd.append('--no-verify-ssl')
        if hypervisor.hypervisor_type == 'kvm':
            cmd.extend(['--transport', 'ssh' if connection_method == 'ssh' else 'tls'])

        if run_async:
            # Run in background thread
            def run_audit_async():
                try:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=600,  # 10 minute timeout
                        cwd=str(ROOT_DIR)
                    )  # nosec B603
                    _complete_audit(execution_id, result, hypervisor_id)
                except subprocess.TimeoutExpired:
                    _fail_audit(execution_id, "Audit timed out after 10 minutes", hypervisor_id)
                except Exception as e:
                    _fail_audit(execution_id, str(e), hypervisor_id)

            thread = threading.Thread(target=run_audit_async, daemon=True)
            thread.start()

            return jsonify({
                "success": True,
                "message": "Audit started",
                "execution_id": execution_id,
                "async": True
            }), 202

        else:
            # Run synchronously
            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=600,
                    cwd=str(ROOT_DIR)
                )  # nosec B603
                return _complete_audit(execution_id, result, hypervisor_id)

            except subprocess.TimeoutExpired:
                return _fail_audit(execution_id, "Audit timed out after 10 minutes", hypervisor_id)

    except Exception as e:
        db.rollback()
        logger.error(f"Error running audit on hypervisor {hypervisor_id}: {e}")
        if hypervisor_id in _running_audits:
            del _running_audits[hypervisor_id]
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


def _complete_audit(execution_id: int, result, hypervisor_id: int):
    """Complete an audit execution with results."""
    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database unavailable"}), 503

    try:
        execution = db.query(HypervisorAuditExecution).filter(
            HypervisorAuditExecution.id == execution_id
        ).first()

        if not execution:
            return jsonify({"success": False, "error": "Execution not found"}), 404

        output = result.stdout + result.stderr
        success = result.returncode == 0

        # Try to parse JSON output for summary
        summary = {}
        try:
            # Look for JSON in output
            for line in output.split('\n'):
                if line.strip().startswith('{'):
                    parsed = json.loads(line)
                    if 'summary' in parsed:
                        summary = parsed['summary']
                        break
        except (json.JSONDecodeError, ValueError):
            pass

        execution.status = 'success' if success else 'failure'
        execution.exit_code = result.returncode
        execution.output = output
        execution.summary = json.dumps(summary) if summary else None
        execution.completed_at = datetime.utcnow()

        if summary:
            execution.checks_total = summary.get('total', 0)
            execution.checks_passed = summary.get('pass', 0)
            execution.checks_warned = summary.get('warn', 0)
            execution.checks_failed = summary.get('fail', 0)
            execution.checks_skipped = summary.get('skip', 0)

        if execution.started_at and execution.completed_at:
            execution.duration_seconds = (
                execution.completed_at - execution.started_at
            ).total_seconds()

        # Update hypervisor last audit time
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if hypervisor:
            hypervisor.last_audit_at = datetime.utcnow()
            hypervisor.status = 'online'

            # Best-effort VM/container discovery snapshot for direct API audits.
            try:
                discovery = _collect_direct_discovery(hypervisor)
                if discovery:
                    from api.hypervisor_agent_routes import upsert_agent_discovery
                    counts = upsert_agent_discovery(
                        agent_id=f"hypervisor-{hypervisor_id}",
                        data=discovery,
                        metadata={
                            'hypervisor_id': hypervisor_id,
                            'hostname': hypervisor.hostname,
                            'platform': hypervisor.hypervisor_type,
                            'platform_name': hypervisor.hypervisor_type,
                            'status': hypervisor.status,
                        },
                    )
                    logger.info(
                        "Direct hypervisor discovery updated for %s: %s VM(s), %s container(s)",
                        hypervisor_id,
                        counts.get('vms', 0),
                        counts.get('containers', 0),
                    )
            except Exception as discovery_err:
                logger.warning(f"Direct discovery bridge failed for hypervisor {hypervisor_id}: {discovery_err}")

        db.commit()

        # Clean up running track
        if hypervisor_id in _running_audits:
            del _running_audits[hypervisor_id]

        return jsonify({
            "success": success,
            "execution": execution.to_dict(),
            "message": "Audit completed" if success else "Audit completed with errors"
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error completing audit {execution_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


def _fail_audit(execution_id: int, error_msg: str, hypervisor_id: int):
    """Mark an audit execution as failed."""
    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database unavailable"}), 503

    try:
        execution = db.query(HypervisorAuditExecution).filter(
            HypervisorAuditExecution.id == execution_id
        ).first()

        if execution:
            execution.status = 'failure'
            execution.output = error_msg
            execution.completed_at = datetime.utcnow()
            if execution.started_at:
                execution.duration_seconds = (
                    execution.completed_at - execution.started_at
                ).total_seconds()
            db.commit()

        # Clean up running track
        if hypervisor_id in _running_audits:
            del _running_audits[hypervisor_id]

        return jsonify({
            "success": False,
            "error": error_msg,
            "execution_id": execution_id
        }), 500

    except Exception as e:
        db.rollback()
        logger.error(f"Error failing audit {execution_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ============================================================================
# License Status Endpoint
# ============================================================================

@hypervisor_bp.route('/api/hypervisors/license-status', methods=['GET'])
def get_hypervisor_license_status():
    """
    Get hypervisor feature licensing status for the current user.

    Returns availability of hypervisor features based on license tier.
    Used by frontend to show/hide features and upgrade prompts.

    Returns:
        JSON with feature availability and limits
    """
    try:
        features = {
            'view': _check_hypervisor_license('HYPERVISOR_VIEW'),
            'add': _check_hypervisor_license('HYPERVISOR_ADD'),
            'audit_basic': _check_hypervisor_license('HYPERVISOR_AUDIT_BASIC'),
            'audit_advanced': _check_hypervisor_license('HYPERVISOR_AUDIT_ADVANCED'),
            'discovery': _check_hypervisor_license('HYPERVISOR_DISCOVERY'),
            'remediation': _check_hypervisor_license('HYPERVISOR_REMEDIATION'),
            'bulk_operations': _check_hypervisor_license('HYPERVISOR_BULK_OPERATIONS'),
            'scheduling': _check_hypervisor_license('HYPERVISOR_SCHEDULING'),
            'agent_download': _check_hypervisor_license('HYPERVISOR_AGENT_DOWNLOAD'),
            'agent_register': _check_hypervisor_license('HYPERVISOR_AGENT_REGISTER'),
            'agent_manage': _check_hypervisor_license('HYPERVISOR_AGENT_MANAGE'),
        }

        # Determine overall access level
        tier = features['view'].get('tier', 'free')
        has_access = features['view'].get('allowed', False)

        # Get current hypervisor count
        current_count = _get_hypervisor_count()
        limits = features['view'].get('limits', {})
        max_hypervisors = limits.get('max_hypervisors')
        allowed_platforms = limits.get('platforms', [])

        return jsonify({
            'success': True,
            'tier': tier,
            'has_access': has_access,
            'reason': None if has_access else features['view'].get('upgrade_message'),
            'upgrade_tier': None if has_access else features['view'].get('required_tier', 'professional'),
            'beta_enabled': BETA_HYPERVISOR_ENABLED,
            'features': {
                name: {
                    'available': f.get('allowed', False),
                    'reason': f.get('reason', 'unknown'),
                }
                for name, f in features.items()
            },
            'limits': {
                'current_hypervisors': current_count,
                'max_hypervisors': max_hypervisors,
                'allowed_platforms': allowed_platforms if allowed_platforms != 'all' else 'all',
            },
            'upgrade_message': None if has_access else features['view'].get(
                'upgrade_message',
                'Hypervisor management requires a Professional licence.'
            ),
            'upgrade_url': '/pricing?feature=hypervisor',
        })

    except Exception as e:
        logger.error(f"Error getting license status: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'has_access': False,
        }), 500


# ============================================================================
# Audit History
# ============================================================================

@hypervisor_bp.route('/api/hypervisors/<int:hypervisor_id>/history', methods=['GET'])
@require_auth_and_permission('view_hypervisor_audits')
@require_hypervisor_license('HYPERVISOR_VIEW')
@conditional_limit("100 per minute")
def get_hypervisor_audit_history(hypervisor_id):
    """
    Get audit history for a hypervisor.

    Query Parameters:
        status: Filter by status (success, failure, running)
        limit: Maximum results (default: 20, max: 100)
        offset: Pagination offset
    """
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        # Verify hypervisor exists
        hypervisor = db.query(Hypervisor).filter(Hypervisor.id == hypervisor_id).first()
        if not hypervisor:
            return jsonify({"success": False, "error": "Hypervisor not found"}), 404

        query = db.query(HypervisorAuditExecution).filter(
            HypervisorAuditExecution.hypervisor_id == hypervisor_id
        )

        # Apply status filter
        status = request.args.get('status')
        if status in ['success', 'failure', 'running', 'timeout']:
            query = query.filter(HypervisorAuditExecution.status == status)

        # Order by most recent first
        query = query.order_by(HypervisorAuditExecution.started_at.desc())

        # Pagination
        limit = min(request.args.get('limit', 20, type=int), 100)
        offset = request.args.get('offset', 0, type=int)

        total = query.count()
        executions = query.offset(offset).limit(limit).all()

        return jsonify({
            "success": True,
            "hypervisor": hypervisor.to_dict(),
            "executions": [e.to_dict() for e in executions],
            "pagination": {
                "offset": offset,
                "limit": limit,
                "total": total
            }
        })

    except Exception as e:
        logger.error(f"Error getting audit history for hypervisor {hypervisor_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


@hypervisor_bp.route('/api/hypervisors/executions/<int:execution_id>', methods=['GET'])
@require_auth_and_permission('view_hypervisor_audits')
@conditional_limit("100 per minute")
def get_hypervisor_execution(execution_id):
    """Get details of a specific audit execution including full output."""
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        execution = db.query(HypervisorAuditExecution).filter(
            HypervisorAuditExecution.id == execution_id
        ).first()

        if not execution:
            return jsonify({"success": False, "error": "Execution not found"}), 404

        result = execution.to_dict()
        result['output'] = execution.output  # Include full output

        return jsonify({
            "success": True,
            "execution": result
        })

    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ============================================================================
# Bulk Operations (Enterprise only)
# ============================================================================

@hypervisor_bp.route('/api/hypervisors/bulk/test', methods=['POST'])
@require_auth_and_permission('test_hypervisors')
@require_hypervisor_license('HYPERVISOR_BULK_OPERATIONS')  # Enterprise only
@conditional_limit("5 per minute")
def bulk_test_hypervisors():
    """
    Test connections to multiple hypervisors.

    Request Body:
        hypervisor_ids: List of hypervisor IDs to test

    Returns:
        Results for each hypervisor
    """
    try:
        data = request.json
        if not data or 'hypervisor_ids' not in data:
            return jsonify({"success": False, "error": "hypervisor_ids required"}), 400

        ids = data['hypervisor_ids']
        if not isinstance(ids, list) or len(ids) > 10:
            return jsonify({"success": False, "error": "Max 10 hypervisors per bulk operation"}), 400

        results = []
        for hv_id in ids:
            try:
                # Use internal test function
                with hypervisor_bp.test_request_context():
                    response = test_hypervisor_connection(hv_id)
                    if hasattr(response, 'json'):
                        results.append({"id": hv_id, **response.json})
                    else:
                        results.append({"id": hv_id, "success": False, "error": "Unexpected response"})
            except Exception as e:
                results.append({"id": hv_id, "success": False, "error": str(e)})

        return jsonify({
            "success": True,
            "results": results
        })

    except Exception as e:
        logger.error(f"Error in bulk test: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ============================================================================
# Statistics
# ============================================================================

@hypervisor_bp.route('/api/hypervisors/stats', methods=['GET'])
@require_auth_and_permission('view_hypervisors')
@conditional_limit("60 per minute")
def get_hypervisor_stats():
    """Get aggregate statistics about hypervisors."""
    if not DATABASE_AVAILABLE:
        return jsonify({"success": False, "error": "Database not available"}), 503

    db = get_db_session()
    if not db:
        return jsonify({"success": False, "error": "Database session unavailable"}), 503

    try:
        from sqlalchemy import func

        # Total counts
        total = db.query(Hypervisor).count()

        # By type
        by_type = db.query(
            Hypervisor.hypervisor_type,
            func.count(Hypervisor.id)
        ).group_by(Hypervisor.hypervisor_type).all()

        # By status
        by_status = db.query(
            Hypervisor.status,
            func.count(Hypervisor.id)
        ).group_by(Hypervisor.status).all()

        # Recent audits (last 24 hours)
        from datetime import timedelta
        recent_cutoff = datetime.utcnow() - timedelta(hours=24)
        recent_audits = db.query(HypervisorAuditExecution).filter(
            HypervisorAuditExecution.started_at >= recent_cutoff
        ).count()

        return jsonify({
            "success": True,
            "stats": {
                "total": total,
                "by_type": {t: c for t, c in by_type},
                "by_status": {s: c for s, c in by_status},
                "recent_audits_24h": recent_audits
            }
        })

    except Exception as e:
        logger.error(f"Error getting hypervisor stats: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        db.close()


# ============================================================================
# Web UI Routes (Page Rendering)
# ============================================================================

@hypervisor_bp.route('/hypervisors')
def hypervisors_page():
    """Render the hypervisor management page.

    Note: Page itself handles authentication via JavaScript.
    API calls from the page still require authentication.
    """
    from flask import render_template
    return render_template('hypervisors.html')
