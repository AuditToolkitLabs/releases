# Integration modules for external services
"""
External service integrations for Security Audit Toolkit:
- Slack/Teams: Daily digest and real-time alerts
- ServiceNow/Jira: Ticketing and remediation tracking
- GitHub Actions: CI/CD security checks
"""

from .slack_teams import slack_teams_bp
from .ticketing import ticketing_bp
from .github_actions import github_actions_bp

__all__ = ['slack_teams_bp', 'ticketing_bp', 'github_actions_bp']
