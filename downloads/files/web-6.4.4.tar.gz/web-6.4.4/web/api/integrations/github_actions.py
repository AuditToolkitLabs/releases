"""
GitHub Actions Integration for Security Audit Toolkit.

Provides:
- Marketplace action for CI/CD security checks
- PR comments with audit summaries
- Status checks to block merges below compliance threshold
- Artifact upload for audit reports

Business Value:
- Viral growth (developers search marketplace for security actions)
- Free tier → developers try → recommend to security team → enterprise deal
- Every PR becomes a touchpoint with your tool
"""

import hashlib
import hmac
import logging
import os
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from flask import Blueprint, current_app, jsonify, request, Response

# Import auth decorators
from auth_core import require_auth_and_permission

logger = logging.getLogger(__name__)

github_actions_bp = Blueprint('github_actions', __name__, url_prefix='/api/integrations/github')


SPONSORSHIP_ACTION_ALIAS_MAP = {
        "sponsorship_created": "created",
        "gh_sponsorship_created": "created",
        "github_sponsorship_created": "created",
        "sponsorship_tier_changed": "tier_changed",
        "gh_sponsorship_tier_changed": "tier_changed",
        "github_sponsorship_tier_changed": "tier_changed",
}

SPONSORSHIP_ACTION_TO_DISPATCH_MAP = {
        "created": "sponsorship_created",
        "tier_changed": "sponsorship_tier_changed",
}


# =============================================================================
# Data Models
# =============================================================================

class CheckStatus(Enum):
    """GitHub check run status."""
    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class CheckConclusion(Enum):
    """GitHub check run conclusion."""
    SUCCESS = "success"
    FAILURE = "failure"
    NEUTRAL = "neutral"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"
    TIMED_OUT = "timed_out"
    ACTION_REQUIRED = "action_required"


@dataclass
class AuditResult:
    """Result from a security audit run."""
    server_name: str
    total_checks: int
    passed_checks: int
    failed_checks: int
    warning_checks: int
    compliance_score: float
    critical_findings: List[Dict[str, Any]]
    high_findings: List[Dict[str, Any]]
    medium_findings: List[Dict[str, Any]]
    low_findings: List[Dict[str, Any]]
    frameworks: Dict[str, float]  # Framework name -> compliance %
    run_duration_seconds: float
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class GitHubConfig:
    """Configuration for GitHub Actions integration."""
    id: str
    repo_owner: str
    repo_name: str
    app_id: Optional[str] = None
    private_key: Optional[str] = None  # For GitHub App auth
    webhook_secret: Optional[str] = None
    compliance_threshold: int = 80  # Minimum % to pass
    fail_on_critical: bool = True
    post_pr_comment: bool = True
    create_check_run: bool = True
    upload_artifact: bool = True
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.utcnow)


# =============================================================================
# GitHub Actions Workflow Generator
# =============================================================================

class WorkflowGenerator:
    """Generate GitHub Actions workflow YAML."""

    @staticmethod
    def generate_workflow(
        audit_types: Optional[List[str]] = None,
        compliance_threshold: int = 80,
        fail_on_critical: bool = True,
        schedule: Optional[str] = None,
        servers: Optional[List[str]] = None
    ) -> str:
        """Generate a complete workflow YAML file."""

        audit_types = audit_types or ["windows", "linux"]
        servers = servers or []

        # Build server matrix if provided
        server_matrix = ""
        if servers:
            server_list = ", ".join([f'"{s}"' for s in servers])
            server_matrix = """
      matrix:
        server: [{server_list}]"""

        # Build schedule trigger
        schedule_trigger = ""
        if schedule:
            schedule_trigger = """
  schedule:
    - cron: '{schedule}'"""

        workflow = """# Security Audit Toolkit - GitHub Actions Workflow
# Auto-generated workflow for continuous security compliance monitoring
# Documentation: https://github.com/audit-toolkit/docs

name: Security Audit

on:
  push:
    branches: [main, master]
  pull_request:
    branches: [main, master]
  workflow_dispatch:
    inputs:
      servers:
        description: 'Comma-separated list of servers to audit'
        required: false
        default: ''
      threshold:
        description: 'Minimum compliance percentage to pass'
        required: false
        default: '{compliance_threshold}'{schedule_trigger}

env:
  AUDIT_TOOLKIT_VERSION: 'latest'
  COMPLIANCE_THRESHOLD: {compliance_threshold}
  FAIL_ON_CRITICAL: {str(fail_on_critical).lower()}

jobs:
  security-audit:
    name: Run Security Audit
    runs-on: ubuntu-latest{server_matrix}

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install Security Audit Toolkit
        run: |
          pip install security-audit-toolkit
          # Or use Docker image:
          # docker pull ghcr.io/audit-toolkit/security-audit:${{{{ env.AUDIT_TOOLKIT_VERSION }}}}

      - name: Run Security Audit
        id: audit
        env:
          AUDIT_API_URL: ${{{{ secrets.AUDIT_API_URL }}}}
          AUDIT_API_KEY: ${{{{ secrets.AUDIT_API_KEY }}}}
        run: |
          # Run the audit and capture results
          audit-toolkit run \\
            --output json \\
            --output-file audit-results.json \\
            {"--servers ${{ matrix.server }}" if servers else ""}

          # Parse results for GitHub Actions
          SCORE=$(jq -r '.compliance_score' audit-results.json)
          CRITICAL=$(jq -r '.critical_count' audit-results.json)

          echo "compliance_score=$SCORE" >> $GITHUB_OUTPUT
          echo "critical_findings=$CRITICAL" >> $GITHUB_OUTPUT

          # Determine pass/fail
          if (( $(echo "$SCORE < ${{{{ env.COMPLIANCE_THRESHOLD }}}}" | bc -l) )); then
            echo "status=failure" >> $GITHUB_OUTPUT
          elif [[ "$CRITICAL" -gt 0 && "${{{{ env.FAIL_ON_CRITICAL }}}}" == "true" ]]; then
            echo "status=failure" >> $GITHUB_OUTPUT
          else
            echo "status=success" >> $GITHUB_OUTPUT
          fi

      - name: Upload Audit Report
        uses: actions/upload-artifact@v4
        with:
          name: security-audit-report
          path: |
            audit-results.json
            audit-report.html
          retention-days: 30

      - name: Post PR Comment
        if: github.event_name == 'pull_request'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const results = JSON.parse(fs.readFileSync('audit-results.json', 'utf8'));

            const score = results.compliance_score;
            const emoji = score >= 80 ? '🟢' : score >= 60 ? '🟡' : '🔴';
            const status = score >= ${{{{ env.COMPLIANCE_THRESHOLD }}}} ? '✅ Passed' : '❌ Failed';

            const body = `## ${{emoji}} Security Audit Results

            | Metric | Value |
            |--------|-------|
            | **Compliance Score** | ${{score.toFixed(1)}}% |
            | **Status** | ${{status}} |
            | **Total Checks** | ${{results.total_checks}} |
            | **Passed** | ${{results.passed_checks}} |
            | **Failed** | ${{results.failed_checks}} |
            | **Critical Issues** | ${{results.critical_count}} |

            ${{results.critical_count > 0 ? '### ⚠️ Critical Findings\\n' + results.critical_findings.map(f => '- ' + f.name).join('\\n') : ''}}

            <details>
            <summary>View Full Report</summary>

            ```json
            ${{JSON.stringify(results.summary, null, 2)}}
            ```

            </details>

            ---
            *Generated by [Security Audit Toolkit](https://github.com/audit-toolkit)*`;

            github.rest.issues.createComment({{
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: body
            }});

      - name: Update Check Status
        if: always()
        run: |
          if [[ "${{{{ steps.audit.outputs.status }}}}" == "failure" ]]; then
            echo "::error::Security audit failed. Compliance score: ${{{{ steps.audit.outputs.compliance_score }}}}%"
            exit 1
          fi
          echo "Security audit passed with score: ${{{{ steps.audit.outputs.compliance_score }}}}%"

  # Optional: Scheduled compliance report
  weekly-report:
    if: github.event_name == 'schedule'
    runs-on: ubuntu-latest
    steps:
      - name: Generate Weekly Report
        run: |
          curl -X POST ${{{{ secrets.AUDIT_API_URL }}}}/api/reports/weekly \\
            -H "Authorization: Bearer ${{{{ secrets.AUDIT_API_KEY }}}}" \\
            -H "Content-Type: application/json"
"""
        return workflow

    @staticmethod
    def generate_composite_action() -> str:
        """Generate a composite action for the GitHub Marketplace."""
        return """# action.yml - Security Audit Toolkit Action
name: 'Security Audit Toolkit'
description: 'Run security compliance audits on your infrastructure'
author: 'Security Audit Toolkit'

branding:
  icon: 'shield'
  color: 'blue'

inputs:
  api_url:
    description: 'Security Audit Toolkit API URL'
    required: true
  api_key:
    description: 'API key for authentication'
    required: true
  servers:
    description: 'Comma-separated list of servers to audit'
    required: false
    default: ''
  compliance_threshold:
    description: 'Minimum compliance percentage to pass (0-100)'
    required: false
    default: '80'
  fail_on_critical:
    description: 'Fail the check if critical findings exist'
    required: false
    default: 'true'
  audit_types:
    description: 'Types of audits to run (windows,linux,network)'
    required: false
    default: 'all'
  output_format:
    description: 'Output format (json,html,sarif)'
    required: false
    default: 'json'
  post_comment:
    description: 'Post results as PR comment'
    required: false
    default: 'true'

outputs:
  compliance_score:
    description: 'Overall compliance score (0-100)'
    value: ${{ steps.audit.outputs.compliance_score }}
  status:
    description: 'Audit status (success/failure)'
    value: ${{ steps.audit.outputs.status }}
  total_checks:
    description: 'Total number of checks run'
    value: ${{ steps.audit.outputs.total_checks }}
  failed_checks:
    description: 'Number of failed checks'
    value: ${{ steps.audit.outputs.failed_checks }}
  critical_count:
    description: 'Number of critical findings'
    value: ${{ steps.audit.outputs.critical_count }}
  report_url:
    description: 'URL to the full audit report'
    value: ${{ steps.audit.outputs.report_url }}

runs:
  using: 'composite'
  steps:
    - name: Setup Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.11'

    - name: Install Toolkit
      shell: bash
      run: pip install security-audit-toolkit

    - name: Run Audit
      id: audit
      shell: bash
      env:
        AUDIT_API_URL: ${{ inputs.api_url }}
        AUDIT_API_KEY: ${{ inputs.api_key }}
      run: |
        # Build server argument
        SERVERS_ARG=""
        if [[ -n "${{ inputs.servers }}" ]]; then
          SERVERS_ARG="--servers ${{ inputs.servers }}"
        fi

        # Run audit
        audit-toolkit run \\
          --api-url "$AUDIT_API_URL" \\
          --api-key "$AUDIT_API_KEY" \\
          --output ${{ inputs.output_format }} \\
          --output-file audit-results.json \\
          --types ${{ inputs.audit_types }} \\
          $SERVERS_ARG

        # Parse results
        SCORE=$(jq -r '.compliance_score // 0' audit-results.json)
        TOTAL=$(jq -r '.total_checks // 0' audit-results.json)
        FAILED=$(jq -r '.failed_checks // 0' audit-results.json)
        CRITICAL=$(jq -r '.critical_count // 0' audit-results.json)
        REPORT_URL=$(jq -r '.report_url // ""' audit-results.json)

        echo "compliance_score=$SCORE" >> $GITHUB_OUTPUT
        echo "total_checks=$TOTAL" >> $GITHUB_OUTPUT
        echo "failed_checks=$FAILED" >> $GITHUB_OUTPUT
        echo "critical_count=$CRITICAL" >> $GITHUB_OUTPUT
        echo "report_url=$REPORT_URL" >> $GITHUB_OUTPUT

        # Determine status
        THRESHOLD=${{ inputs.compliance_threshold }}
        FAIL_CRITICAL=${{ inputs.fail_on_critical }}

        if (( $(echo "$SCORE < $THRESHOLD" | bc -l) )); then
          echo "status=failure" >> $GITHUB_OUTPUT
        elif [[ "$CRITICAL" -gt 0 && "$FAIL_CRITICAL" == "true" ]]; then
          echo "status=failure" >> $GITHUB_OUTPUT
        else
          echo "status=success" >> $GITHUB_OUTPUT
        fi

    - name: Post PR Comment
      if: ${{ inputs.post_comment == 'true' && github.event_name == 'pull_request' }}
      uses: actions/github-script@v7
      with:
        script: |
          const fs = require('fs');
          let results;
          try {
            results = JSON.parse(fs.readFileSync('audit-results.json', 'utf8'));
          } catch (e) {
            results = { compliance_score: 0, total_checks: 0, passed_checks: 0, failed_checks: 0, critical_count: 0 };
          }

          const score = results.compliance_score || 0;
          const emoji = score >= 80 ? '🟢' : score >= 60 ? '🟡' : '🔴';
          const threshold = parseInt('${{ inputs.compliance_threshold }}');
          const status = score >= threshold ? '✅ Passed' : '❌ Failed';

          const body = `## ${emoji} Security Audit Results

| Metric | Value |
|--------|-------|
| **Compliance Score** | ${score.toFixed(1)}% |
| **Status** | ${status} |
| **Threshold** | ${threshold}% |
| **Total Checks** | ${results.total_checks || 0} |
| **Passed** | ${results.passed_checks || 0} |
| **Failed** | ${results.failed_checks || 0} |
| **Critical** | ${results.critical_count || 0} |

${results.report_url ? `[📊 View Full Report](${results.report_url})` : ''}

---
*Generated by [Security Audit Toolkit](https://github.com/audit-toolkit)*`;

          await github.rest.issues.createComment({
            issue_number: context.issue.number,
            owner: context.repo.owner,
            repo: context.repo.repo,
            body: body
          });

    - name: Upload Artifact
      uses: actions/upload-artifact@v4
      with:
        name: security-audit-results
        path: audit-results.json
        retention-days: 30
"""


# =============================================================================
# SARIF Report Generator (for GitHub Security tab)
# =============================================================================

class SarifGenerator:
    """Generate SARIF format reports for GitHub Security tab integration."""

    @staticmethod
    def generate_sarif(audit_result: AuditResult) -> Dict[str, Any]:
        """Generate SARIF 2.1.0 format report."""

        rules = []
        results = []

        # Process all findings
        all_findings = [
            *[(f, "error") for f in audit_result.critical_findings],
            *[(f, "error") for f in audit_result.high_findings],
            *[(f, "warning") for f in audit_result.medium_findings],
            *[(f, "note") for f in audit_result.low_findings]
        ]

        for i, (finding, level) in enumerate(all_findings):
            rule_id = f"SAT{i+1:04d}"

            # Add rule definition
            rules.append({
                "id": rule_id,
                "name": finding.get("check_name", "Unknown Check"),
                "shortDescription": {
                    "text": finding.get("check_name", "Security check failed")
                },
                "fullDescription": {
                    "text": finding.get("description", "")
                },
                "helpUri": finding.get("doc_url", "https://docs.audit-toolkit.io"),
                "help": {
                    "text": finding.get("remediation", "See documentation for remediation steps"),
                    "markdown": f"**Remediation:**\n\n{finding.get('remediation', 'N/A')}"
                },
                "properties": {
                    "tags": finding.get("compliance_refs", []),
                    "security-severity": {
                        "critical": "9.0",
                        "high": "7.0",
                        "medium": "5.0",
                        "low": "3.0"
                    }.get(finding.get("severity", "medium"), "5.0")
                }
            })

            # Add result
            results.append({
                "ruleId": rule_id,
                "ruleIndex": i,
                "level": level,
                "message": {
                    "text": f"{finding.get('check_name', 'Check')}: {finding.get('description', 'Failed')}"
                },
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": f"servers/{audit_result.server_name}",
                                "uriBaseId": "AUDIT_ROOT"
                            }
                        },
                        "logicalLocations": [
                            {
                                "name": audit_result.server_name,
                                "kind": "server"
                            }
                        ]
                    }
                ],
                "properties": {
                    "server": audit_result.server_name,
                    "severity": finding.get("severity", "medium"),
                    "compliance_refs": finding.get("compliance_refs", [])
                }
            })

        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "Security Audit Toolkit",
                            "version": "2.0.0",
                            "informationUri": "https://github.com/audit-toolkit",
                            "rules": rules
                        }
                    },
                    "results": results,
                    "invocations": [
                        {
                            "executionSuccessful": True,
                            "endTimeUtc": audit_result.timestamp.isoformat() + "Z"
                        }
                    ],
                    "originalUriBaseIds": {
                        "AUDIT_ROOT": {
                            "uri": "file:///audit/"
                        }
                    }
                }
            ]
        }

        return sarif


# =============================================================================
# API Endpoints
# =============================================================================

@github_actions_bp.route('/workflow/generate', methods=['POST'])
@require_auth_and_permission('manage_integrations')
def generate_workflow():
    """Generate a GitHub Actions workflow YAML."""
    data = request.get_json() or {}

    yaml_content = WorkflowGenerator.generate_workflow(
        audit_types=data.get('audit_types'),
        compliance_threshold=data.get('compliance_threshold', 80),
        fail_on_critical=data.get('fail_on_critical', True),
        schedule=data.get('schedule'),
        servers=data.get('servers')
    )

    return Response(
        yaml_content,
        mimetype='text/yaml',
        headers={'Content-Disposition': 'attachment; filename=security-audit.yml'}
    )


@github_actions_bp.route('/action/generate', methods=['GET'])
@require_auth_and_permission('manage_integrations')
def generate_action():
    """Generate the marketplace action YAML."""
    yaml_content = WorkflowGenerator.generate_composite_action()

    return Response(
        yaml_content,
        mimetype='text/yaml',
        headers={'Content-Disposition': 'attachment; filename=action.yml'}
    )


@github_actions_bp.route('/sarif/generate', methods=['POST'])
@require_auth_and_permission('export_reports')
def generate_sarif():
    """Generate SARIF report from audit results."""
    data = request.get_json()

    if not data:
        return jsonify({"error": "Audit data is required"}), 400

    audit_result = AuditResult(
        server_name=data.get('server_name', 'unknown'),
        total_checks=data.get('total_checks', 0),
        passed_checks=data.get('passed_checks', 0),
        failed_checks=data.get('failed_checks', 0),
        warning_checks=data.get('warning_checks', 0),
        compliance_score=data.get('compliance_score', 0),
        critical_findings=data.get('critical_findings', []),
        high_findings=data.get('high_findings', []),
        medium_findings=data.get('medium_findings', []),
        low_findings=data.get('low_findings', []),
        frameworks=data.get('frameworks', {}),
        run_duration_seconds=data.get('run_duration_seconds', 0)
    )

    sarif = SarifGenerator.generate_sarif(audit_result)

    return jsonify(sarif)


@github_actions_bp.route('/webhook', methods=['POST'])
def github_webhook():
    """Handle GitHub webhooks for check runs and PR events."""
    event_type = request.headers.get('X-GitHub-Event', '')

    # Verify webhook signature
    signature = request.headers.get('X-Hub-Signature-256', '')
    if not _verify_github_signature(request.get_data(), signature, event_type=event_type):
        logger.warning("Invalid GitHub webhook signature")
        return jsonify({"error": "Invalid signature"}), 401

    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        data = {}

    logger.info(f"GitHub webhook: {event_type}")

    if event_type == 'sponsorship':
        delivery_id = request.headers.get('X-GitHub-Delivery', '')
        forwarded, detail = _forward_sponsorship_webhook(data, delivery_id=delivery_id)
        status_code = 202 if forwarded else 200
        return jsonify({
            "received": True,
            "event": event_type,
            "forwarded": forwarded,
            **detail,
        }), status_code

    if event_type == 'check_run':
        action = data.get('action', '')
        _check_run = data.get('check_run', {})  # noqa: F841

        if action == 'requested_action':
            # User clicked a button in the check run
            requested_action = data.get('requested_action', {})
            if requested_action.get('identifier') == 'rerun_audit':
                # Trigger re-run of audit
                logger.info("Re-run audit requested via check run")

                # Extract repository info from the check run
                repo_info = data.get('repository', {})
                check_run = data.get('check_run', {})
                head_sha = check_run.get('head_sha')

                if repo_info and head_sha:
                    try:
                        # Trigger a new workflow run
                        owner = repo_info.get('owner', {}).get('login')
                        repo = repo_info.get('name')

                        if owner and repo:
                            _trigger_audit_workflow(owner, repo, head_sha)
                            logger.info(f"Triggered audit workflow for {owner}/{repo}@{head_sha}")
                    except Exception as e:
                        logger.error(f"Failed to trigger audit workflow: {e}")

    elif event_type == 'pull_request':
        action = data.get('action', '')
        pr = data.get('pull_request', {})

        if action in ['opened', 'synchronize', 'reopened']:
            # New PR or updated PR - could trigger audit
            logger.info(f"PR {pr.get('number')} {action} - consider triggering audit")

    elif event_type == 'workflow_run':
        workflow_run = data.get('workflow_run', {})
        if workflow_run.get('name') == 'Security Audit' and workflow_run.get('conclusion'):
            # Our workflow completed
            logger.info(f"Security audit workflow completed: {workflow_run.get('conclusion')}")

    return jsonify({"received": True})


@github_actions_bp.route('/check-run', methods=['POST'])
@require_auth_and_permission('manage_audits')
def create_check_run():
    """Create a GitHub check run for audit results."""
    data = request.get_json()

    required = ['owner', 'repo', 'head_sha', 'audit_results']
    if not all(k in data for k in required):
        return jsonify({"error": f"Missing required fields: {required}"}), 400

    results = data['audit_results']
    score = results.get('compliance_score', 0)
    threshold = data.get('threshold', 80)

    # Determine conclusion
    if score >= threshold and not (results.get('critical_count', 0) > 0 and data.get('fail_on_critical', True)):
        conclusion = CheckConclusion.SUCCESS
    else:
        conclusion = CheckConclusion.FAILURE

    # Build check run output
    summary = """## Security Audit Results

| Metric | Value |
|--------|-------|
| Compliance Score | {score:.1f}% |
| Threshold | {threshold}% |
| Total Checks | {results.get('total_checks', 0)} |
| Passed | {results.get('passed_checks', 0)} |
| Failed | {results.get('failed_checks', 0)} |
| Critical Issues | {results.get('critical_count', 0)} |
"""

    # Add annotations for failures
    annotations = []
    for finding in results.get('critical_findings', [])[:50]:  # GitHub limit is 50
        annotations.append({
            "path": f"servers/{finding.get('server', 'unknown')}",
            "start_line": 1,
            "end_line": 1,
            "annotation_level": "failure",
            "message": f"{finding.get('check_name', 'Check')}: {finding.get('description', 'Failed')}",
            "title": finding.get('check_name', 'Critical Finding')
        })

    check_run_data = {
        "name": "Security Audit",
        "head_sha": data['head_sha'],
        "status": CheckStatus.COMPLETED.value,
        "conclusion": conclusion.value,
        "output": {
            "title": f"Security Audit: {score:.1f}% Compliance",
            "summary": summary,
            "annotations": annotations
        },
        "actions": [
            {
                "label": "Re-run Audit",
                "description": "Trigger a new security audit",
                "identifier": "rerun_audit"
            },
            {
                "label": "View Report",
                "description": "Open the full audit report",
                "identifier": "view_report"
            }
        ]
    }

    # In production, this would POST to GitHub API
    # response = github_client.post(
    #     f"https://api.github.com/repos/{data['owner']}/{data['repo']}/check-runs",
    #     json=check_run_data,
    #     headers={"Authorization": f"Bearer {github_token}"}
    # )

    return jsonify({
        "message": "Check run created",
        "conclusion": conclusion.value,
        "check_run": check_run_data
    }), 201


@github_actions_bp.route('/status', methods=['GET'])
@require_auth_and_permission('view_dashboard')
def integration_status():
    """Get GitHub Actions integration status and usage stats."""
    return jsonify({
        "status": "active",
        "features": {
            "workflow_generator": True,
            "composite_action": True,
            "sarif_reports": True,
            "pr_comments": True,
            "check_runs": True,
            "webhooks": True
        },
        "documentation": {
            "workflow_setup": "/api/integrations/github/workflow/generate",
            "action_marketplace": "https://github.com/marketplace/actions/security-audit-toolkit",
            "sarif_integration": "/api/integrations/github/sarif/generate"
        }
    })


# =============================================================================
# Helper Functions
# =============================================================================

def _trigger_audit_workflow(owner: str, repo: str, ref: str) -> bool:
    """
    Trigger the security audit workflow via GitHub API.

    Uses the repository_dispatch event to trigger the workflow.
    Requires a GitHub token with repo scope.
    """
    payload = {
        'ref': ref,
        'triggered_by': 'check_run_button',
        'timestamp': datetime.now(UTC).isoformat()
    }
    return _dispatch_repository_event(
        owner=owner,
        repo=repo,
        event_type='security_audit_rerun',
        client_payload=payload,
    )


def _forward_sponsorship_webhook(payload: Dict[str, Any], delivery_id: str = "") -> tuple[bool, Dict[str, Any]]:
    """Forward eligible sponsorship webhook events to repository_dispatch for license fulfillment."""
    action = _normalize_sponsorship_action(str(payload.get('action', '')))
    if not action:
        logger.info("Skipping sponsorship webhook: missing action")
        return False, {"reason": "missing_action"}

    allowed_actions = _csv_setting(
        key='GITHUB_SPONSORS_ALLOWED_ACTIONS',
        default='created,tier_changed',
    )
    if action not in allowed_actions:
        logger.info("Skipping sponsorship webhook action '%s' (allowed: %s)", action, sorted(allowed_actions))
        return False, {"reason": "action_not_allowed", "action": action}

    dispatch_event = SPONSORSHIP_ACTION_TO_DISPATCH_MAP.get(action)
    if not dispatch_event:
        logger.info("Skipping sponsorship webhook action '%s': no dispatch mapping", action)
        return False, {"reason": "action_not_mapped", "action": action}

    tier_slug = _extract_sponsorship_tier_slug(payload)
    allowed_tiers = _csv_setting(
        key='GITHUB_SPONSORS_ALLOWED_TIERS',
        default='starter,professional,business',
    )
    if tier_slug and tier_slug not in allowed_tiers:
        logger.info("Skipping sponsorship tier '%s' (allowed: %s)", tier_slug, sorted(allowed_tiers))
        return False, {
            "reason": "tier_not_allowed",
            "action": action,
            "tier_slug": tier_slug,
        }

    owner, repo = _resolve_dispatch_target(payload)
    if not owner or not repo:
        logger.error("Cannot forward sponsorship webhook: missing dispatch repo target")
        return False, {
            "reason": "missing_dispatch_target",
            "action": action,
            "tier_slug": tier_slug,
        }

    client_payload = {
        'action': action,
        'event': payload,
        'bridge': {
            'source': 'github_webhook',
            'delivery_id': delivery_id,
            'received_at_utc': datetime.now(UTC).isoformat(),
        },
    }

    dispatched = _dispatch_repository_event(
        owner=owner,
        repo=repo,
        event_type=dispatch_event,
        client_payload=client_payload,
    )

    if not dispatched:
        return False, {
            "reason": "dispatch_failed",
            "action": action,
            "dispatch_event": dispatch_event,
            "tier_slug": tier_slug,
            "target": f"{owner}/{repo}",
        }

    logger.info(
        "Forwarded sponsorship webhook action '%s' to repository_dispatch '%s' (%s/%s)",
        action,
        dispatch_event,
        owner,
        repo,
    )
    return True, {
        "action": action,
        "dispatch_event": dispatch_event,
        "tier_slug": tier_slug,
        "target": f"{owner}/{repo}",
    }


def _csv_setting(key: str, default: str) -> set[str]:
    """Parse comma-separated config value to lowercase token set."""
    raw_value = (
        os.environ.get(key)
        or current_app.config.get(key)
        or default
    )
    values = {
        str(item).strip().lower().replace('-', '_')
        for item in str(raw_value).split(',')
        if str(item).strip()
    }
    return values or {
        str(item).strip().lower().replace('-', '_')
        for item in default.split(',')
        if str(item).strip()
    }


def _normalize_sponsorship_action(action: str) -> str:
    normalized = str(action or '').strip().lower().replace('-', '_')
    if not normalized:
        return ""
    return SPONSORSHIP_ACTION_ALIAS_MAP.get(normalized, normalized)


def _extract_sponsorship_tier_slug(payload: Dict[str, Any]) -> str:
    sponsorship = payload.get('sponsorship', {}) if isinstance(payload, dict) else {}
    if not isinstance(sponsorship, dict):
        return ""

    tier_obj = sponsorship.get('tier', {})
    tier_name = ""
    if isinstance(tier_obj, dict):
        tier_name = str(tier_obj.get('name', '')).strip()

    if not tier_name:
        tier_name = str(sponsorship.get('tier_name', '') or sponsorship.get('tierName', '')).strip()

    if not tier_name:
        return ""

    normalized = re.sub(r'[^a-z0-9]+', ' ', tier_name.lower()).strip()
    if re.search(r'\bstarter\b', normalized):
        return 'starter'
    if re.search(r'\bprofessional\b', normalized) or re.search(r'\bpro\b', normalized):
        return 'professional'
    if re.search(r'\bbusiness\b', normalized):
        return 'business'
    return ''


def _resolve_dispatch_target(payload: Dict[str, Any]) -> tuple[str, str]:
    """Resolve owner/repo target for repository_dispatch."""
    owner = (
        os.environ.get('GITHUB_DISPATCH_REPO_OWNER')
        or current_app.config.get('GITHUB_DISPATCH_REPO_OWNER', '')
        or os.environ.get('GITHUB_REPO_OWNER')
        or current_app.config.get('GITHUB_REPO_OWNER', '')
    )
    repo = (
        os.environ.get('GITHUB_DISPATCH_REPO_NAME')
        or current_app.config.get('GITHUB_DISPATCH_REPO_NAME', '')
        or os.environ.get('GITHUB_REPO_NAME')
        or current_app.config.get('GITHUB_REPO_NAME', '')
    )

    repository_slug = (
        os.environ.get('GITHUB_REPOSITORY')
        or current_app.config.get('GITHUB_REPOSITORY', '')
    )
    if (not owner or not repo) and isinstance(repository_slug, str) and '/' in repository_slug:
        slug_owner, slug_repo = repository_slug.split('/', 1)
        owner = owner or slug_owner.strip()
        repo = repo or slug_repo.strip()

    repo_info = payload.get('repository', {}) if isinstance(payload, dict) else {}
    if isinstance(repo_info, dict):
        if not repo:
            repo = str(repo_info.get('name', '')).strip()

        if not owner:
            owner_info = repo_info.get('owner', {})
            if isinstance(owner_info, dict):
                owner = str(owner_info.get('login', '') or owner_info.get('name', '')).strip()

        if (not owner or not repo) and isinstance(repo_info.get('full_name'), str) and '/' in repo_info['full_name']:
            full_owner, full_repo = repo_info['full_name'].split('/', 1)
            owner = owner or full_owner.strip()
            repo = repo or full_repo.strip()

    return owner.strip(), repo.strip()


def _dispatch_repository_event(
    owner: str,
    repo: str,
    event_type: str,
    client_payload: Optional[Dict[str, Any]] = None,
    ) -> bool:
    """Send repository_dispatch event to GitHub."""
    import requests

    github_token = (
        os.environ.get('GITHUB_DISPATCH_TOKEN')
        or current_app.config.get('GITHUB_DISPATCH_TOKEN', '')
        or os.environ.get('GITHUB_TOKEN')
        or current_app.config.get('GITHUB_TOKEN', '')
    )
    if not github_token:
        logger.warning("No GitHub dispatch token configured, cannot trigger workflow")
        return False

    payload: Dict[str, Any] = {'event_type': event_type}
    if isinstance(client_payload, dict):
        payload['client_payload'] = client_payload

    try:
        url = f"https://api.github.com/repos/{owner}/{repo}/dispatches"
        headers = {
            'Authorization': f'token {github_token}',
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json'
        }

        response = requests.post(url, headers=headers, json=payload, timeout=10)

        if response.status_code == 204:
            logger.info("Successfully dispatched '%s' to %s/%s", event_type, owner, repo)
            return True

        logger.error(
            "Failed to dispatch '%s' to %s/%s: %s - %s",
            event_type,
            owner,
            repo,
            response.status_code,
            response.text,
        )
        return False

    except Exception as e:
        logger.error("Error dispatching '%s' to %s/%s: %s", event_type, owner, repo, e)
        return False


def _verify_github_signature(payload: bytes, signature: str, event_type: str = "") -> bool:
    """Verify GitHub webhook signature."""
    webhook_secret: Optional[str] = None

    if event_type == 'sponsorship':
        webhook_secret = (
            os.environ.get('GITHUB_SPONSORS_WEBHOOK_SECRET')
            or current_app.config.get('GITHUB_SPONSORS_WEBHOOK_SECRET')
        )

    if not webhook_secret:
        webhook_secret = (
            os.environ.get('GITHUB_WEBHOOK_SECRET')
            or current_app.config.get('GITHUB_WEBHOOK_SECRET')
        )

    if not webhook_secret:
        return True  # Skip verification if not configured

    if not signature.startswith('sha256='):
        return False

    expected = hmac.new(
        str(webhook_secret).encode(),
        payload,
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(f"sha256={expected}", signature)
