"""
Slack and Microsoft Teams Integration for Security Audit Toolkit.

Provides:
- Webhook endpoints for receiving slash commands
- Outgoing notifications for audit alerts
- Daily/weekly security digest scheduling
- Interactive message actions

Business Value:
- Daily touchpoint = stickiness (users see value every day)
- Reduces churn (hard to cancel when integrated into workflow)
- Upsell triggers (alerts drive users to run more audits)
"""

import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List

import requests
from flask import Blueprint, current_app, jsonify, request

# Import auth decorators
from auth_core import require_auth_and_permission

logger = logging.getLogger(__name__)

slack_teams_bp = Blueprint('slack_teams', __name__, url_prefix='/api/integrations/chat')


# =============================================================================
# Data Models
# =============================================================================

class ChatPlatform(Enum):
    """Supported chat platforms."""
    SLACK = "slack"
    TEAMS = "teams"


class AlertSeverity(Enum):
    """Alert severity levels."""
    CRITICAL = "critical"  # Compliance < 50% or critical failures
    HIGH = "high"          # Compliance 50-70% or multiple failures
    MEDIUM = "medium"      # Compliance 70-85%
    LOW = "low"            # Informational
    INFO = "info"          # Success notifications


@dataclass
class ChatConfig:
    """Configuration for a chat integration."""
    id: str
    platform: ChatPlatform
    webhook_url: str
    channel: str
    enabled: bool = True
    alert_threshold: int = 80  # Compliance % below this triggers alert
    digest_enabled: bool = True
    digest_schedule: str = "daily"  # daily, weekly
    digest_time: str = "09:00"  # HH:MM in UTC
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class DigestData:
    """Data for security digest message."""
    total_servers: int
    compliant_servers: int
    compliance_percentage: float
    critical_findings: int
    new_failures: int
    improvements: int
    top_issues: List[Dict[str, Any]]
    declining_servers: List[Dict[str, Any]]
    period: str  # "daily" or "weekly"


# =============================================================================
# Message Formatters
# =============================================================================

class SlackMessageBuilder:
    """Build Slack Block Kit messages."""

    @staticmethod
    def build_digest(data: DigestData) -> Dict[str, Any]:
        """Build daily/weekly digest message."""
        emoji = "🟢" if data.compliance_percentage >= 80 else "🟡" if data.compliance_percentage >= 60 else "🔴"
        period_label = "Daily" if data.period == "daily" else "Weekly"

        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{emoji} {period_label} Security Digest",
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Total Servers:*\n{data.total_servers}"},
                    {"type": "mrkdwn", "text": f"*Compliant:*\n{data.compliant_servers}"},
                    {"type": "mrkdwn", "text": f"*Compliance Score:*\n{data.compliance_percentage:.1f}%"},
                    {"type": "mrkdwn", "text": f"*Critical Findings:*\n{data.critical_findings}"}
                ]
            },
            {"type": "divider"}
        ]

        # Trend section
        if data.improvements > 0 or data.new_failures > 0:
            trend_text = []
            if data.improvements > 0:
                trend_text.append(f"✅ {data.improvements} issues fixed")
            if data.new_failures > 0:
                trend_text.append(f"❌ {data.new_failures} new failures")

            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": "*Trends:*\n" + " | ".join(trend_text)}
            })

        # Top issues
        if data.top_issues:
            issues_text = "\n".join([
                f"• {issue['name']}: {issue['count']} servers affected"
                for issue in data.top_issues[:5]
            ])
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*Top Issues:*\n{issues_text}"}
            })

        # Declining servers warning
        if data.declining_servers:
            servers_text = ", ".join([s['name'] for s in data.declining_servers[:5]])
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"⚠️ *Attention Needed:* {servers_text}"}
            })

        # Action buttons
        blocks.append({
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "View Dashboard"},
                    "url": "{{DASHBOARD_URL}}",
                    "style": "primary"
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Run Full Audit"},
                    "action_id": "run_audit_all"
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Generate Report"},
                    "action_id": "generate_report"
                }
            ]
        })

        return {"blocks": blocks}

    @staticmethod
    def build_alert(server_name: str, compliance: float, failures: List[str], severity: AlertSeverity) -> Dict[str, Any]:
        """Build real-time alert message."""
        color = {
            AlertSeverity.CRITICAL: "#dc3545",
            AlertSeverity.HIGH: "#fd7e14",
            AlertSeverity.MEDIUM: "#ffc107",
            AlertSeverity.LOW: "#17a2b8",
            AlertSeverity.INFO: "#28a745"
        }.get(severity, "#6c757d")

        emoji = {
            AlertSeverity.CRITICAL: "🚨",
            AlertSeverity.HIGH: "⚠️",
            AlertSeverity.MEDIUM: "⚡",
            AlertSeverity.LOW: "ℹ️",
            AlertSeverity.INFO: "✅"
        }.get(severity, "📋")

        failures_text = "\n".join([f"• {f}" for f in failures[:10]])
        if len(failures) > 10:
            failures_text += f"\n... and {len(failures) - 10} more"

        return {
            "attachments": [{
                "color": color,
                "blocks": [
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"{emoji} *Security Alert: {server_name}*\nCompliance: {compliance:.1f}%"
                        }
                    },
                    {
                        "type": "section",
                        "text": {"type": "mrkdwn", "text": f"*Failed Checks:*\n{failures_text}"}
                    },
                    {
                        "type": "actions",
                        "elements": [
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "View Details"},
                                "action_id": f"view_server_{server_name}"
                            },
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "Re-run Audit"},
                                "action_id": f"rerun_audit_{server_name}"
                            }
                        ]
                    }
                ]
            }]
        }

    @staticmethod
    def build_command_response(command: str, result: Dict[str, Any]) -> Dict[str, Any]:
        """Build response to slash command."""
        if command == "status":
            return {
                "response_type": "in_channel",
                "blocks": [
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "*Security Audit Status*\n"
                                    f"• Total Servers: {result.get('total_servers', 0)}\n"
                                    f"• Compliant: {result.get('compliant', 0)}\n"
                                    f"• Score: {result.get('compliance_score', 0):.1f}%"
                        }
                    }
                ]
            }
        elif command == "server":
            server = result.get('server', {})
            return {
                "response_type": "ephemeral",
                "blocks": [
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*Server: {server.get('name', 'Unknown')}*\n"
                                    f"• Last Audit: {server.get('last_audit', 'Never')}\n"
                                    f"• Score: {server.get('score', 0):.1f}%\n"
                                    f"• Failures: {server.get('failures', 0)}"
                        }
                    }
                ]
            }
        else:
            return {
                "response_type": "ephemeral",
                "text": f"Unknown command: {command}"
            }


class TeamsMessageBuilder:
    """Build Microsoft Teams Adaptive Cards."""

    @staticmethod
    def build_digest(data: DigestData) -> Dict[str, Any]:
        """Build daily/weekly digest as Adaptive Card."""
        emoji = "🟢" if data.compliance_percentage >= 80 else "🟡" if data.compliance_percentage >= 60 else "🔴"
        period_label = "Daily" if data.period == "daily" else "Weekly"

        facts = [
            {"title": "Total Servers", "value": str(data.total_servers)},
            {"title": "Compliant", "value": str(data.compliant_servers)},
            {"title": "Compliance Score", "value": f"{data.compliance_percentage:.1f}%"},
            {"title": "Critical Findings", "value": str(data.critical_findings)}
        ]

        body = [
            {
                "type": "TextBlock",
                "size": "Large",
                "weight": "Bolder",
                "text": f"{emoji} {period_label} Security Digest"
            },
            {
                "type": "FactSet",
                "facts": facts
            }
        ]

        # Trends
        if data.improvements > 0 or data.new_failures > 0:
            trend_parts = []
            if data.improvements > 0:
                trend_parts.append(f"✅ {data.improvements} fixed")
            if data.new_failures > 0:
                trend_parts.append(f"❌ {data.new_failures} new")
            body.append({
                "type": "TextBlock",
                "text": f"**Trends:** {' | '.join(trend_parts)}",
                "wrap": True
            })

        # Top issues
        if data.top_issues:
            issues_list = [f"- {i['name']}: {i['count']} servers" for i in data.top_issues[:5]]
            body.append({
                "type": "TextBlock",
                "text": "**Top Issues:**\n" + "\n".join(issues_list),
                "wrap": True
            })

        # Declining servers
        if data.declining_servers:
            servers = ", ".join([s['name'] for s in data.declining_servers[:5]])
            body.append({
                "type": "TextBlock",
                "text": f"⚠️ **Attention Needed:** {servers}",
                "wrap": True,
                "color": "Warning"
            })

        return {
            "type": "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "body": body,
                    "actions": [
                        {
                            "type": "Action.OpenUrl",
                            "title": "View Dashboard",
                            "url": "{{DASHBOARD_URL}}"
                        },
                        {
                            "type": "Action.Submit",
                            "title": "Run Full Audit",
                            "data": {"action": "run_audit_all"}
                        }
                    ]
                }
            }]
        }

    @staticmethod
    def build_alert(server_name: str, compliance: float, failures: List[str], severity: AlertSeverity) -> Dict[str, Any]:
        """Build real-time alert as Adaptive Card."""
        color = {
            AlertSeverity.CRITICAL: "Attention",
            AlertSeverity.HIGH: "Warning",
            AlertSeverity.MEDIUM: "Warning",
            AlertSeverity.LOW: "Accent",
            AlertSeverity.INFO: "Good"
        }.get(severity, "Default")

        emoji = {
            AlertSeverity.CRITICAL: "🚨",
            AlertSeverity.HIGH: "⚠️",
            AlertSeverity.MEDIUM: "⚡",
            AlertSeverity.LOW: "ℹ️",
            AlertSeverity.INFO: "✅"
        }.get(severity, "📋")

        failures_text = "\n".join([f"- {f}" for f in failures[:10]])

        return {
            "type": "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.4",
                    "body": [
                        {
                            "type": "TextBlock",
                            "size": "Large",
                            "weight": "Bolder",
                            "text": f"{emoji} Security Alert: {server_name}",
                            "color": color
                        },
                        {
                            "type": "TextBlock",
                            "text": f"**Compliance Score:** {compliance:.1f}%",
                            "wrap": True
                        },
                        {
                            "type": "TextBlock",
                            "text": f"**Failed Checks:**\n{failures_text}",
                            "wrap": True
                        }
                    ],
                    "actions": [
                        {
                            "type": "Action.OpenUrl",
                            "title": "View Details",
                            "url": f"{{{{SERVER_URL}}}}/{server_name}"
                        },
                        {
                            "type": "Action.Submit",
                            "title": "Re-run Audit",
                            "data": {"action": "rerun_audit", "server": server_name}
                        }
                    ]
                }
            }]
        }


# =============================================================================
# Notification Service
# =============================================================================

class ChatNotificationService:
    """Send notifications to Slack/Teams."""

    def __init__(self):
        self.configs: Dict[str, ChatConfig] = {}
        self._load_configs()

    def _load_configs(self):
        """Load chat configurations from database/settings."""
        # In production, load from database
        # For now, configs are added via API
        pass

    def add_config(self, config: ChatConfig):
        """Add or update a chat configuration."""
        self.configs[config.id] = config

    def remove_config(self, config_id: str):
        """Remove a chat configuration."""
        self.configs.pop(config_id, None)

    def send_message(self, config_id: str, message: Dict[str, Any]) -> bool:
        """Send a message to the configured webhook."""
        config = self.configs.get(config_id)
        if not config or not config.enabled:
            logger.warning(f"Chat config {config_id} not found or disabled")
            return False

        try:
            response = requests.post(
                config.webhook_url,
                json=message,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            response.raise_for_status()
            logger.info(f"Message sent to {config.platform.value} channel {config.channel}")
            return True
        except requests.RequestException as e:
            logger.error(f"Failed to send message to {config_id}: {e}")
            return False

    def send_digest(self, config_id: str, data: DigestData) -> bool:
        """Send security digest to a channel."""
        config = self.configs.get(config_id)
        if not config:
            return False

        if config.platform == ChatPlatform.SLACK:
            message = SlackMessageBuilder.build_digest(data)
        else:
            message = TeamsMessageBuilder.build_digest(data)

        return self.send_message(config_id, message)

    def send_alert(self, config_id: str, server_name: str, compliance: float,
                   failures: List[str], severity: AlertSeverity) -> bool:
        """Send real-time alert to a channel."""
        config = self.configs.get(config_id)
        if not config:
            return False

        # Check if compliance is below threshold
        if compliance >= config.alert_threshold and severity not in [AlertSeverity.CRITICAL, AlertSeverity.HIGH]:
            return False  # Don't alert for minor issues above threshold

        if config.platform == ChatPlatform.SLACK:
            message = SlackMessageBuilder.build_alert(server_name, compliance, failures, severity)
        else:
            message = TeamsMessageBuilder.build_alert(server_name, compliance, failures, severity)

        return self.send_message(config_id, message)

    def broadcast_digest(self, data: DigestData) -> Dict[str, bool]:
        """Send digest to all enabled channels with digest enabled."""
        results = {}
        for config_id, config in self.configs.items():
            if config.enabled and config.digest_enabled:
                results[config_id] = self.send_digest(config_id, data)
        return results

    def broadcast_alert(self, server_name: str, compliance: float,
                        failures: List[str], severity: AlertSeverity) -> Dict[str, bool]:
        """Send alert to all enabled channels."""
        results = {}
        for config_id, config in self.configs.items():
            if config.enabled:
                results[config_id] = self.send_alert(config_id, server_name, compliance, failures, severity)
        return results


# Global service instance
notification_service = ChatNotificationService()


# =============================================================================
# API Endpoints
# =============================================================================

@slack_teams_bp.route('/configs', methods=['GET'])
@require_auth_and_permission('manage_integrations')
def list_configs():
    """List all chat integrations."""
    configs = []
    for config_id, config in notification_service.configs.items():
        configs.append({
            "id": config.id,
            "platform": config.platform.value,
            "channel": config.channel,
            "enabled": config.enabled,
            "alert_threshold": config.alert_threshold,
            "digest_enabled": config.digest_enabled,
            "digest_schedule": config.digest_schedule,
            "created_at": config.created_at.isoformat()
        })
    return jsonify({"configs": configs})


@slack_teams_bp.route('/configs', methods=['POST'])
@require_auth_and_permission('manage_integrations')
def create_config():
    """Create a new chat integration."""
    data = request.get_json()

    required = ['platform', 'webhook_url', 'channel']
    if not all(k in data for k in required):
        return jsonify({"error": f"Missing required fields: {required}"}), 400

    # Security: Enforce HTTPS for webhook URLs
    webhook_url = data['webhook_url']
    if not webhook_url.startswith('https://'):
        return jsonify({"error": "Webhook URL must use HTTPS for security"}), 400

    try:
        platform = ChatPlatform(data['platform'])
    except ValueError:
        return jsonify({"error": "Invalid platform. Use 'slack' or 'teams'"}), 400

    config_id = hashlib.sha256(f"{data['webhook_url']}{data['channel']}".encode()).hexdigest()[:16]

    config = ChatConfig(
        id=config_id,
        platform=platform,
        webhook_url=data['webhook_url'],
        channel=data['channel'],
        enabled=data.get('enabled', True),
        alert_threshold=data.get('alert_threshold', 80),
        digest_enabled=data.get('digest_enabled', True),
        digest_schedule=data.get('digest_schedule', 'daily'),
        digest_time=data.get('digest_time', '09:00')
    )

    notification_service.add_config(config)

    return jsonify({
        "message": "Configuration created",
        "config_id": config_id,
        "platform": platform.value
    }), 201


@slack_teams_bp.route('/configs/<config_id>', methods=['PUT'])
@require_auth_and_permission('manage_integrations')
def update_config(config_id: str):
    """Update a chat integration."""
    if config_id not in notification_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    data = request.get_json()
    config = notification_service.configs[config_id]

    if 'enabled' in data:
        config.enabled = data['enabled']
    if 'alert_threshold' in data:
        config.alert_threshold = data['alert_threshold']
    if 'digest_enabled' in data:
        config.digest_enabled = data['digest_enabled']
    if 'digest_schedule' in data:
        config.digest_schedule = data['digest_schedule']
    if 'digest_time' in data:
        config.digest_time = data['digest_time']
    if 'webhook_url' in data:
        # Security: Enforce HTTPS for webhook URLs
        if not data['webhook_url'].startswith('https://'):
            return jsonify({"error": "Webhook URL must use HTTPS for security"}), 400
        config.webhook_url = data['webhook_url']

    config.updated_at = datetime.utcnow()

    return jsonify({"message": "Configuration updated"})


@slack_teams_bp.route('/configs/<config_id>', methods=['DELETE'])
@require_auth_and_permission('manage_integrations')
def delete_config(config_id: str):
    """Delete a chat integration."""
    if config_id not in notification_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    notification_service.remove_config(config_id)
    return jsonify({"message": "Configuration deleted"})


@slack_teams_bp.route('/configs/<config_id>/test', methods=['POST'])
@require_auth_and_permission('manage_integrations')
def test_config(config_id: str):
    """Send a test message to verify configuration."""
    if config_id not in notification_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    _config = notification_service.configs[config_id]  # noqa: F841

    # Create test digest data
    test_data = DigestData(
        total_servers=10,
        compliant_servers=8,
        compliance_percentage=80.0,
        critical_findings=2,
        new_failures=1,
        improvements=3,
        top_issues=[{"name": "Missing patches", "count": 3}],
        declining_servers=[{"name": "server-01"}],
        period="daily"
    )

    success = notification_service.send_digest(config_id, test_data)

    if success:
        return jsonify({"message": "Test message sent successfully"})
    else:
        return jsonify({"error": "Failed to send test message"}), 500


@slack_teams_bp.route('/digest/send', methods=['POST'])
@require_auth_and_permission('manage_audits')
def send_digest_now():
    """Manually trigger digest send to all channels."""
    data = request.get_json() or {}
    period = data.get('period', 'daily')

    # Fetch real data from database
    # In production, this would query actual audit results
    digest_data = _fetch_digest_data(period)

    results = notification_service.broadcast_digest(digest_data)

    success_count = sum(1 for r in results.values() if r)
    total_count = len(results)

    return jsonify({
        "message": f"Digest sent to {success_count}/{total_count} channels",
        "results": {k: "success" if v else "failed" for k, v in results.items()}
    })


@slack_teams_bp.route('/alert/send', methods=['POST'])
@require_auth_and_permission('manage_audits')
def send_alert():
    """Send an alert for a specific server."""
    data = request.get_json()

    required = ['server_name', 'compliance', 'failures']
    if not all(k in data for k in required):
        return jsonify({"error": f"Missing required fields: {required}"}), 400

    severity = AlertSeverity(data.get('severity', 'medium'))

    results = notification_service.broadcast_alert(
        server_name=data['server_name'],
        compliance=data['compliance'],
        failures=data['failures'],
        severity=severity
    )

    success_count = sum(1 for r in results.values() if r)

    return jsonify({
        "message": f"Alert sent to {success_count} channels",
        "results": {k: "success" if v else "failed" for k, v in results.items()}
    })


# =============================================================================
# Slack Slash Command Webhook
# =============================================================================

@slack_teams_bp.route('/slack/commands', methods=['POST'])
def slack_slash_command():
    """Handle Slack slash commands like /audit."""
    # Verify request signature
    if not _verify_slack_signature(request):
        return jsonify({"error": "Invalid signature"}), 401

    command = request.form.get('command', '').lstrip('/')
    text = request.form.get('text', '').strip()
    user_id = request.form.get('user_id')
    channel_id = request.form.get('channel_id')

    logger.info(f"Slack command: /{command} {text} from {user_id} in {channel_id}")

    # Parse subcommand
    parts = text.split(maxsplit=1)
    subcommand = parts[0].lower() if parts else 'status'
    args = parts[1] if len(parts) > 1 else ''

    if subcommand == 'status':
        result = _get_audit_status()
        return jsonify(SlackMessageBuilder.build_command_response('status', result))

    elif subcommand == 'server':
        if not args:
            return jsonify({
                "response_type": "ephemeral",
                "text": "Usage: /audit server <server-name>"
            })
        result = _get_server_status(args)
        return jsonify(SlackMessageBuilder.build_command_response('server', result))

    elif subcommand == 'report':
        return jsonify({
            "response_type": "ephemeral",
            "text": "📊 Generating report... Check your email or dashboard."
        })

    elif subcommand == 'help':
        return jsonify({
            "response_type": "ephemeral",
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "*Security Audit Commands:*\n"
                                "• `/audit status` - Show overall compliance status\n"
                                "• `/audit server <name>` - Show specific server status\n"
                                "• `/audit report` - Generate compliance report\n"
                                "• `/audit help` - Show this help message"
                    }
                }
            ]
        })

    else:
        return jsonify({
            "response_type": "ephemeral",
            "text": f"Unknown command: {subcommand}. Try `/audit help`"
        })


@slack_teams_bp.route('/slack/actions', methods=['POST'])
def slack_interactive_action():
    """Handle Slack interactive actions (button clicks)."""
    payload = json.loads(request.form.get('payload', '{}'))

    action_id = payload.get('actions', [{}])[0].get('action_id', '')
    user = payload.get('user', {}).get('username', 'unknown')

    logger.info(f"Slack action: {action_id} from {user}")

    if action_id == 'run_audit_all':
        # Trigger audit for all servers
        return jsonify({
            "response_type": "in_channel",
            "text": "🔄 Starting audit for all servers..."
        })

    elif action_id == 'generate_report':
        return jsonify({
            "response_type": "ephemeral",
            "text": "📊 Report generation started. You'll receive it shortly."
        })

    elif action_id.startswith('view_server_'):
        server_name = action_id.replace('view_server_', '')
        return jsonify({
            "response_type": "ephemeral",
            "text": f"Opening details for {server_name}..."
        })

    elif action_id.startswith('rerun_audit_'):
        server_name = action_id.replace('rerun_audit_', '')
        return jsonify({
            "response_type": "in_channel",
            "text": f"🔄 Re-running audit for {server_name}..."
        })

    return jsonify({"text": "Action received"})


# =============================================================================
# Teams Webhook
# =============================================================================

@slack_teams_bp.route('/teams/webhook', methods=['POST'])
def teams_webhook():
    """Handle Microsoft Teams incoming webhook messages."""
    data = request.get_json()

    # Teams sends different message types
    message_type = data.get('type', '')

    if message_type == 'message':
        text = data.get('text', '').strip()

        # Parse commands mentioned to bot
        # Teams mentions look like <at>BotName</at> command
        text = text.split('</at>')[-1].strip() if '</at>' in text else text

        parts = text.split(maxsplit=1)
        command = parts[0].lower() if parts else ''
        _args = parts[1] if len(parts) > 1 else ''  # noqa: F841

        if command == 'status':
            result = _get_audit_status()
            return jsonify({
                "type": "message",
                "text": f"Total Servers: {result['total_servers']}, Compliant: {result['compliant']}, Score: {result['compliance_score']:.1f}%"
            })

        elif command == 'help':
            return jsonify({
                "type": "message",
                "text": "**Commands:**\n- status - Show compliance status\n- server <name> - Show server details\n- report - Generate report"
            })

        else:
            return jsonify({
                "type": "message",
                "text": f"I didn't understand '{command}'. Try 'help' for available commands."
            })

    elif message_type == 'invoke' and data.get('name') == 'adaptiveCard/action':
        # Handle Adaptive Card action
        action_data = data.get('value', {})
        action = action_data.get('action', '')

        if action == 'run_audit_all':
            return jsonify({
                "type": "message",
                "text": "🔄 Starting audit for all servers..."
            })

        elif action == 'rerun_audit':
            server = action_data.get('server', '')
            return jsonify({
                "type": "message",
                "text": f"🔄 Re-running audit for {server}..."
            })

    return jsonify({"type": "message", "text": "OK"})


# =============================================================================
# Helper Functions
# =============================================================================

def _verify_slack_signature(req) -> bool:
    """Verify Slack request signature."""
    signing_secret = current_app.config.get('SLACK_SIGNING_SECRET', '')
    if not signing_secret:
        return True  # Skip verification if not configured

    timestamp = req.headers.get('X-Slack-Request-Timestamp', '')
    signature = req.headers.get('X-Slack-Signature', '')

    # Check timestamp freshness (prevent replay attacks)
    if abs(time.time() - int(timestamp)) > 60 * 5:
        return False

    sig_basestring = f"v0:{timestamp}:{req.get_data(as_text=True)}"
    computed_signature = 'v0=' + hmac.new(
        signing_secret.encode(),
        sig_basestring.encode(),
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(computed_signature, signature)


def _fetch_digest_data(period: str) -> DigestData:
    """Fetch real audit data for digest."""
    # In production, query the database
    # For now, return placeholder data
    try:
        from models.database import Server  # noqa: F401

        # Get all servers
        servers = Server.query.filter_by(active=True).all()
        total = len(servers)

        # Calculate compliance
        compliant = sum(1 for s in servers if getattr(s, 'compliance_score', 0) >= 80)
        avg_compliance = sum(getattr(s, 'compliance_score', 0) for s in servers) / total if total > 0 else 0

        # Get critical findings from recent audits
        # ... additional queries

        return DigestData(
            total_servers=total,
            compliant_servers=compliant,
            compliance_percentage=avg_compliance,
            critical_findings=0,
            new_failures=0,
            improvements=0,
            top_issues=[],
            declining_servers=[],
            period=period
        )
    except Exception as e:
        logger.error(f"Error fetching digest data: {e}")
        return DigestData(
            total_servers=0,
            compliant_servers=0,
            compliance_percentage=0,
            critical_findings=0,
            new_failures=0,
            improvements=0,
            top_issues=[],
            declining_servers=[],
            period=period
        )


def _get_audit_status() -> Dict[str, Any]:
    """Get overall audit status."""
    try:
        from models.database import Server

        servers = Server.query.filter_by(active=True).all()
        total = len(servers)
        compliant = sum(1 for s in servers if getattr(s, 'compliance_score', 0) >= 80)
        avg = sum(getattr(s, 'compliance_score', 0) for s in servers) / total if total > 0 else 0

        return {
            "total_servers": total,
            "compliant": compliant,
            "compliance_score": avg
        }
    except Exception:
        return {
            "total_servers": 0,
            "compliant": 0,
            "compliance_score": 0.0
        }


def _get_server_status(server_name: str) -> Dict[str, Any]:
    """Get status for a specific server."""
    try:
        from models.database import Server

        server = Server.query.filter_by(name=server_name).first()
        if not server:
            return {"server": {"name": server_name, "error": "Not found"}}

        return {
            "server": {
                "name": server.name,
                "last_audit": getattr(server, 'last_audit', 'Never'),
                "score": getattr(server, 'compliance_score', 0),
                "failures": getattr(server, 'failed_checks', 0)
            }
        }
    except Exception as e:
        return {"server": {"name": server_name, "error": str(e)}}
