"""
ServiceNow and Jira Integration for Security Audit Toolkit.

Provides:
- Auto-create tickets for audit failures
- Bi-directional sync (remediation in Jira → closes finding)
- SLA tracking and escalation
- Bulk ticket creation for compliance gaps

Business Value:
- Enterprise sales requirement (they already live in ServiceNow/Jira)
- Without integration, manual copy → friction → won't use tool
- Table stakes for $50K+ enterprise deals
"""

import hashlib
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional

import requests
from flask import Blueprint, jsonify, request

# Import auth decorators
from auth_core import require_auth_and_permission

logger = logging.getLogger(__name__)

ticketing_bp = Blueprint('ticketing', __name__, url_prefix='/api/integrations/ticketing')


# =============================================================================
# Data Models
# =============================================================================

class TicketingPlatform(Enum):
    """Supported ticketing platforms."""
    SERVICENOW = "servicenow"
    JIRA = "jira"
    JIRA_CLOUD = "jira_cloud"
    JIRA_SERVER = "jira_server"


class TicketPriority(Enum):
    """Ticket priority levels."""
    CRITICAL = "critical"  # P1 - 4 hour SLA
    HIGH = "high"          # P2 - 24 hour SLA
    MEDIUM = "medium"      # P3 - 72 hour SLA
    LOW = "low"            # P4 - 1 week SLA


class TicketStatus(Enum):
    """Ticket status values."""
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    PENDING = "pending"
    RESOLVED = "resolved"
    CLOSED = "closed"


@dataclass
class TicketingConfig:
    """Configuration for a ticketing integration."""
    id: str
    platform: TicketingPlatform
    base_url: str
    project_key: str  # Jira project or ServiceNow assignment group
    username: str
    api_token: str  # Encrypted in production
    enabled: bool = True
    auto_create: bool = True  # Auto-create tickets for failures
    auto_close: bool = True   # Auto-close when remediated
    priority_mapping: Dict[str, str] = field(default_factory=dict)
    custom_fields: Dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AuditFinding:
    """An audit finding to be converted to a ticket."""
    id: str
    server_name: str
    check_name: str
    status: str  # FAIL, WARN
    severity: str  # critical, high, medium, low
    description: str
    remediation: str
    compliance_refs: List[str]  # CIS 1.2.3, NIST AC-2, etc.
    evidence: Optional[str] = None
    detected_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Ticket:
    """A ticket in the external system."""
    id: str
    external_id: str  # Jira key or ServiceNow number
    platform: TicketingPlatform
    finding_id: str
    server_name: str
    summary: str
    status: TicketStatus
    priority: TicketPriority
    assignee: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    sla_due: Optional[datetime] = None
    url: Optional[str] = None


# =============================================================================
# Ticketing Client Implementations
# =============================================================================

class TicketingClient(ABC):
    """Abstract base class for ticketing clients."""

    def __init__(self, config: TicketingConfig):
        self.config = config

    @abstractmethod
    def create_ticket(self, finding: AuditFinding) -> Optional[Ticket]:
        """Create a ticket for an audit finding."""
        pass

    @abstractmethod
    def update_ticket(self, ticket_id: str, updates: Dict[str, Any]) -> bool:
        """Update an existing ticket."""
        pass

    @abstractmethod
    def close_ticket(self, ticket_id: str, resolution: str) -> bool:
        """Close/resolve a ticket."""
        pass

    @abstractmethod
    def get_ticket(self, ticket_id: str) -> Optional[Ticket]:
        """Get ticket details."""
        pass

    @abstractmethod
    def search_tickets(self, query: Dict[str, Any]) -> List[Ticket]:
        """Search for tickets."""
        pass

    def _map_priority(self, severity: str) -> str:
        """Map audit severity to platform priority."""
        mapping = self.config.priority_mapping or {
            "critical": "1",
            "high": "2",
            "medium": "3",
            "low": "4"
        }
        return mapping.get(severity.lower(), "3")


class JiraClient(TicketingClient):
    """Jira Cloud/Server client."""

    def __init__(self, config: TicketingConfig):
        super().__init__(config)
        self.session = requests.Session()

        # Jira Cloud uses Bearer token or Basic auth with API token
        if config.platform == TicketingPlatform.JIRA_CLOUD:
            self.session.auth = (config.username, config.api_token)
        else:
            # Jira Server might use different auth
            self.session.auth = (config.username, config.api_token)

        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json"
        })

    @property
    def api_url(self) -> str:
        return f"{self.config.base_url}/rest/api/3" if self.config.platform == TicketingPlatform.JIRA_CLOUD else f"{self.config.base_url}/rest/api/2"

    def create_ticket(self, finding: AuditFinding) -> Optional[Ticket]:
        """Create a Jira issue for an audit finding."""
        compliance_text = ", ".join(finding.compliance_refs) if finding.compliance_refs else "N/A"

        description = """
h2. Audit Finding Details

*Server:* {finding.server_name}
*Check:* {finding.check_name}
*Status:* {finding.status}
*Severity:* {finding.severity}
*Detected:* {finding.detected_at.isoformat()}

h3. Description
{finding.description}

h3. Compliance References
{compliance_text}

h3. Remediation Steps
{finding.remediation}

h3. Evidence
{finding.evidence or 'See audit report for details'}

----
_Auto-generated by Security Audit Toolkit_
"""

        payload = {
            "fields": {
                "project": {"key": self.config.project_key},
                "summary": f"[{finding.severity.upper()}] {finding.server_name}: {finding.check_name}",
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [{"type": "text", "text": description}]
                        }
                    ]
                } if self.config.platform == TicketingPlatform.JIRA_CLOUD else description,
                "issuetype": {"name": "Bug"},
                "priority": {"id": self._map_priority(finding.severity)},
                "labels": ["security-audit", "automated", finding.severity]
            }
        }

        # Add custom fields
        for field_key, field_value in self.config.custom_fields.items():
            payload["fields"][field_key] = field_value

        try:
            response = self.session.post(f"{self.api_url}/issue", json=payload)
            response.raise_for_status()
            data = response.json()

            ticket_key = data.get("key")
            logger.info(f"Created Jira ticket {ticket_key} for finding {finding.id}")

            return Ticket(
                id=hashlib.sha256(f"{ticket_key}{finding.id}".encode()).hexdigest()[:16],
                external_id=ticket_key,
                platform=self.config.platform,
                finding_id=finding.id,
                server_name=finding.server_name,
                summary=f"{finding.server_name}: {finding.check_name}",
                status=TicketStatus.OPEN,
                priority=TicketPriority(finding.severity),
                url=f"{self.config.base_url}/browse/{ticket_key}",
                sla_due=self._calculate_sla(finding.severity)
            )
        except requests.RequestException as e:
            logger.error(f"Failed to create Jira ticket: {e}")
            return None

    def update_ticket(self, ticket_id: str, updates: Dict[str, Any]) -> bool:
        """Update a Jira issue."""
        payload = {"fields": updates}

        try:
            response = self.session.put(f"{self.api_url}/issue/{ticket_id}", json=payload)
            response.raise_for_status()
            return True
        except requests.RequestException as e:
            logger.error(f"Failed to update Jira ticket {ticket_id}: {e}")
            return False

    def close_ticket(self, ticket_id: str, resolution: str) -> bool:
        """Transition Jira issue to Done/Closed."""
        # First, get available transitions
        try:
            response = self.session.get(f"{self.api_url}/issue/{ticket_id}/transitions")
            response.raise_for_status()
            transitions = response.json().get("transitions", [])

            # Find "Done" or "Closed" transition
            close_transition = None
            for t in transitions:
                if t["name"].lower() in ["done", "closed", "resolved"]:
                    close_transition = t["id"]
                    break

            if not close_transition:
                logger.warning(f"No close transition found for {ticket_id}")
                return False

            # Perform transition
            payload = {
                "transition": {"id": close_transition},
                "fields": {
                    "resolution": {"name": "Fixed"}
                },
                "update": {
                    "comment": [
                        {
                            "add": {
                                "body": f"Auto-closed by Security Audit Toolkit.\nResolution: {resolution}"
                            }
                        }
                    ]
                }
            }

            response = self.session.post(
                f"{self.api_url}/issue/{ticket_id}/transitions",
                json=payload
            )
            response.raise_for_status()
            logger.info(f"Closed Jira ticket {ticket_id}")
            return True
        except requests.RequestException as e:
            logger.error(f"Failed to close Jira ticket {ticket_id}: {e}")
            return False

    def get_ticket(self, ticket_id: str) -> Optional[Ticket]:
        """Get Jira issue details."""
        try:
            response = self.session.get(f"{self.api_url}/issue/{ticket_id}")
            response.raise_for_status()
            data = response.json()

            fields = data.get("fields", {})
            status_name = fields.get("status", {}).get("name", "").lower()

            status_map = {
                "to do": TicketStatus.OPEN,
                "open": TicketStatus.OPEN,
                "in progress": TicketStatus.IN_PROGRESS,
                "pending": TicketStatus.PENDING,
                "done": TicketStatus.RESOLVED,
                "closed": TicketStatus.CLOSED
            }

            return Ticket(
                id=data.get("id"),
                external_id=data.get("key"),
                platform=self.config.platform,
                finding_id="",  # Would need to extract from description or custom field
                server_name="",
                summary=fields.get("summary", ""),
                status=status_map.get(status_name, TicketStatus.OPEN),
                priority=TicketPriority.MEDIUM,
                assignee=fields.get("assignee", {}).get("displayName") if fields.get("assignee") else None,
                url=f"{self.config.base_url}/browse/{data.get('key')}"
            )
        except requests.RequestException as e:
            logger.error(f"Failed to get Jira ticket {ticket_id}: {e}")
            return None

    def search_tickets(self, query: Dict[str, Any]) -> List[Ticket]:
        """Search Jira issues with JQL."""
        jql_parts = [f'project = "{self.config.project_key}"', 'labels = "security-audit"']

        if "server" in query:
            jql_parts.append(f'summary ~ "{query["server"]}"')
        if "status" in query:
            jql_parts.append(f'status = "{query["status"]}"')
        if "since" in query:
            jql_parts.append(f'created >= "{query["since"]}"')

        jql = " AND ".join(jql_parts)

        try:
            response = self.session.get(
                f"{self.api_url}/search",
                params={"jql": jql, "maxResults": 100}
            )
            response.raise_for_status()
            data = response.json()

            tickets = []
            for issue in data.get("issues", []):
                ticket = self.get_ticket(issue.get("key"))
                if ticket:
                    tickets.append(ticket)

            return tickets
        except requests.RequestException as e:
            logger.error(f"Failed to search Jira: {e}")
            return []

    def _calculate_sla(self, severity: str) -> datetime:
        """Calculate SLA due date based on severity."""
        sla_hours = {
            "critical": 4,
            "high": 24,
            "medium": 72,
            "low": 168  # 1 week
        }
        hours = sla_hours.get(severity.lower(), 72)
        return datetime.utcnow() + timedelta(hours=hours)


class ServiceNowClient(TicketingClient):
    """ServiceNow client."""

    def __init__(self, config: TicketingConfig):
        super().__init__(config)
        self.session = requests.Session()
        self.session.auth = (config.username, config.api_token)
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json"
        })

    @property
    def api_url(self) -> str:
        return f"{self.config.base_url}/api/now/table"

    def create_ticket(self, finding: AuditFinding) -> Optional[Ticket]:
        """Create a ServiceNow incident for an audit finding."""
        compliance_text = ", ".join(finding.compliance_refs) if finding.compliance_refs else "N/A"

        description = """
Audit Finding Details
====================

Server: {finding.server_name}
Check: {finding.check_name}
Status: {finding.status}
Severity: {finding.severity}
Detected: {finding.detected_at.isoformat()}

Description:
{finding.description}

Compliance References:
{compliance_text}

Remediation Steps:
{finding.remediation}

Evidence:
{finding.evidence or 'See audit report for details'}

---
Auto-generated by Security Audit Toolkit
"""

        # Map severity to ServiceNow impact/urgency
        impact_urgency = {
            "critical": ("1", "1"),  # High impact, High urgency
            "high": ("2", "1"),      # Medium impact, High urgency
            "medium": ("2", "2"),    # Medium impact, Medium urgency
            "low": ("3", "3")        # Low impact, Low urgency
        }
        impact, urgency = impact_urgency.get(finding.severity.lower(), ("2", "2"))

        payload = {
            "short_description": f"[Security Audit] {finding.server_name}: {finding.check_name}",
            "description": description,
            "category": "Security",
            "subcategory": "Compliance",
            "impact": impact,
            "urgency": urgency,
            "assignment_group": self.config.project_key,
            "caller_id": self.config.username,
            "u_security_finding_id": finding.id,  # Custom field
            "u_server_name": finding.server_name,  # Custom field
        }

        # Add custom fields
        for field_key, field_value in self.config.custom_fields.items():
            payload[field_key] = field_value

        try:
            response = self.session.post(f"{self.api_url}/incident", json=payload)
            response.raise_for_status()
            data = response.json().get("result", {})

            incident_number = data.get("number")
            sys_id = data.get("sys_id")

            logger.info(f"Created ServiceNow incident {incident_number} for finding {finding.id}")

            return Ticket(
                id=sys_id,
                external_id=incident_number,
                platform=TicketingPlatform.SERVICENOW,
                finding_id=finding.id,
                server_name=finding.server_name,
                summary=f"{finding.server_name}: {finding.check_name}",
                status=TicketStatus.OPEN,
                priority=TicketPriority(finding.severity),
                url=f"{self.config.base_url}/nav_to.do?uri=incident.do?sys_id={sys_id}",
                sla_due=self._calculate_sla(finding.severity)
            )
        except requests.RequestException as e:
            logger.error(f"Failed to create ServiceNow incident: {e}")
            return None

    def update_ticket(self, ticket_id: str, updates: Dict[str, Any]) -> bool:
        """Update a ServiceNow incident."""
        try:
            response = self.session.patch(f"{self.api_url}/incident/{ticket_id}", json=updates)
            response.raise_for_status()
            return True
        except requests.RequestException as e:
            logger.error(f"Failed to update ServiceNow incident {ticket_id}: {e}")
            return False

    def close_ticket(self, ticket_id: str, resolution: str) -> bool:
        """Close a ServiceNow incident."""
        payload = {
            "state": "7",  # Closed
            "close_code": "Solved (Permanently)",
            "close_notes": f"Auto-closed by Security Audit Toolkit.\nResolution: {resolution}"
        }

        try:
            response = self.session.patch(f"{self.api_url}/incident/{ticket_id}", json=payload)
            response.raise_for_status()
            logger.info(f"Closed ServiceNow incident {ticket_id}")
            return True
        except requests.RequestException as e:
            logger.error(f"Failed to close ServiceNow incident {ticket_id}: {e}")
            return False

    def get_ticket(self, ticket_id: str) -> Optional[Ticket]:
        """Get ServiceNow incident details."""
        try:
            response = self.session.get(f"{self.api_url}/incident/{ticket_id}")
            response.raise_for_status()
            data = response.json().get("result", {})

            state_map = {
                "1": TicketStatus.OPEN,        # New
                "2": TicketStatus.IN_PROGRESS,  # In Progress
                "3": TicketStatus.PENDING,      # On Hold
                "6": TicketStatus.RESOLVED,     # Resolved
                "7": TicketStatus.CLOSED        # Closed
            }

            return Ticket(
                id=data.get("sys_id"),
                external_id=data.get("number"),
                platform=TicketingPlatform.SERVICENOW,
                finding_id=data.get("u_security_finding_id", ""),
                server_name=data.get("u_server_name", ""),
                summary=data.get("short_description", ""),
                status=state_map.get(data.get("state"), TicketStatus.OPEN),
                priority=TicketPriority.MEDIUM,
                assignee=data.get("assigned_to", {}).get("display_value"),
                url=f"{self.config.base_url}/nav_to.do?uri=incident.do?sys_id={data.get('sys_id')}"
            )
        except requests.RequestException as e:
            logger.error(f"Failed to get ServiceNow incident {ticket_id}: {e}")
            return None

    def search_tickets(self, query: Dict[str, Any]) -> List[Ticket]:
        """Search ServiceNow incidents."""
        sysparm_query = ["category=Security", "subcategory=Compliance"]

        if "server" in query:
            sysparm_query.append(f"u_server_nameLIKE{query['server']}")
        if "status" in query:
            state_map = {
                "open": "1",
                "in_progress": "2",
                "pending": "3",
                "resolved": "6",
                "closed": "7"
            }
            if query["status"] in state_map:
                sysparm_query.append(f"state={state_map[query['status']]}")

        try:
            response = self.session.get(
                f"{self.api_url}/incident",
                params={"sysparm_query": "^".join(sysparm_query), "sysparm_limit": 100}
            )
            response.raise_for_status()
            data = response.json()

            tickets = []
            for incident in data.get("result", []):
                ticket = self.get_ticket(incident.get("sys_id"))
                if ticket:
                    tickets.append(ticket)

            return tickets
        except requests.RequestException as e:
            logger.error(f"Failed to search ServiceNow: {e}")
            return []

    def _calculate_sla(self, severity: str) -> datetime:
        """Calculate SLA due date based on severity."""
        sla_hours = {
            "critical": 4,
            "high": 24,
            "medium": 72,
            "low": 168
        }
        hours = sla_hours.get(severity.lower(), 72)
        return datetime.utcnow() + timedelta(hours=hours)


# =============================================================================
# Ticketing Service
# =============================================================================

class TicketingService:
    """Manage ticketing integrations and ticket lifecycle."""

    def __init__(self):
        self.configs: Dict[str, TicketingConfig] = {}
        self.clients: Dict[str, TicketingClient] = {}
        self.tickets: Dict[str, Ticket] = {}  # finding_id -> ticket

    def add_config(self, config: TicketingConfig):
        """Add or update a ticketing configuration."""
        self.configs[config.id] = config

        # Create appropriate client
        if config.platform in [TicketingPlatform.JIRA, TicketingPlatform.JIRA_CLOUD, TicketingPlatform.JIRA_SERVER]:
            self.clients[config.id] = JiraClient(config)
        elif config.platform == TicketingPlatform.SERVICENOW:
            self.clients[config.id] = ServiceNowClient(config)

    def remove_config(self, config_id: str):
        """Remove a ticketing configuration."""
        self.configs.pop(config_id, None)
        self.clients.pop(config_id, None)

    def create_ticket_for_finding(self, config_id: str, finding: AuditFinding) -> Optional[Ticket]:
        """Create a ticket for an audit finding."""
        client = self.clients.get(config_id)
        if not client:
            logger.error(f"No client found for config {config_id}")
            return None

        # Check if ticket already exists for this finding
        if finding.id in self.tickets:
            logger.info(f"Ticket already exists for finding {finding.id}")
            return self.tickets[finding.id]

        ticket = client.create_ticket(finding)
        if ticket:
            self.tickets[finding.id] = ticket

        return ticket

    def close_ticket_for_finding(self, finding_id: str, resolution: str) -> bool:
        """Close the ticket associated with a finding."""
        ticket = self.tickets.get(finding_id)
        if not ticket:
            logger.warning(f"No ticket found for finding {finding_id}")
            return False

        # Find the appropriate client
        for config_id, client in self.clients.items():
            if self.configs[config_id].platform == ticket.platform:
                success = client.close_ticket(ticket.external_id, resolution)
                if success:
                    ticket.status = TicketStatus.CLOSED
                    ticket.resolved_at = datetime.utcnow()
                return success

        return False

    def sync_ticket_status(self, finding_id: str) -> Optional[TicketStatus]:
        """Sync ticket status from external system."""
        ticket = self.tickets.get(finding_id)
        if not ticket:
            return None

        for config_id, client in self.clients.items():
            if self.configs[config_id].platform == ticket.platform:
                updated = client.get_ticket(ticket.external_id)
                if updated:
                    ticket.status = updated.status
                    ticket.assignee = updated.assignee
                    ticket.updated_at = datetime.utcnow()
                    return updated.status

        return None

    def create_bulk_tickets(self, config_id: str, findings: List[AuditFinding]) -> Dict[str, Optional[Ticket]]:
        """Create tickets for multiple findings."""
        results = {}
        for finding in findings:
            results[finding.id] = self.create_ticket_for_finding(config_id, finding)
        return results

    def get_sla_breached_tickets(self) -> List[Ticket]:
        """Get all tickets that have breached their SLA."""
        now = datetime.utcnow()
        breached = []
        for ticket in self.tickets.values():
            if ticket.sla_due and ticket.sla_due < now and ticket.status not in [TicketStatus.RESOLVED, TicketStatus.CLOSED]:
                breached.append(ticket)
        return breached


# Global service instance
ticketing_service = TicketingService()


# =============================================================================
# API Endpoints
# =============================================================================

@ticketing_bp.route('/configs', methods=['GET'])
@require_auth_and_permission('manage_integrations')
def list_configs():
    """List all ticketing integrations."""
    configs = []
    for config_id, config in ticketing_service.configs.items():
        configs.append({
            "id": config.id,
            "platform": config.platform.value,
            "base_url": config.base_url,
            "project_key": config.project_key,
            "enabled": config.enabled,
            "auto_create": config.auto_create,
            "auto_close": config.auto_close,
            "created_at": config.created_at.isoformat()
        })
    return jsonify({"configs": configs})


@ticketing_bp.route('/configs', methods=['POST'])
@require_auth_and_permission('manage_integrations')
def create_config():
    """Create a new ticketing integration."""
    data = request.get_json()

    required = ['platform', 'base_url', 'project_key', 'username', 'api_token']
    if not all(k in data for k in required):
        return jsonify({"error": f"Missing required fields: {required}"}), 400

    # Security: Enforce HTTPS for ticketing API URLs
    base_url = data['base_url'].rstrip('/')
    if not base_url.startswith('https://'):
        return jsonify({"error": "Base URL must use HTTPS for security"}), 400

    try:
        platform = TicketingPlatform(data['platform'])
    except ValueError:
        return jsonify({"error": "Invalid platform. Use 'servicenow', 'jira', 'jira_cloud', or 'jira_server'"}), 400

    config_id = hashlib.sha256(f"{base_url}{data['project_key']}".encode()).hexdigest()[:16]

    config = TicketingConfig(
        id=config_id,
        platform=platform,
        base_url=base_url,
        project_key=data['project_key'],
        username=data['username'],
        api_token=data['api_token'],
        enabled=data.get('enabled', True),
        auto_create=data.get('auto_create', True),
        auto_close=data.get('auto_close', True),
        priority_mapping=data.get('priority_mapping', {}),
        custom_fields=data.get('custom_fields', {})
    )

    ticketing_service.add_config(config)

    return jsonify({
        "message": "Configuration created",
        "config_id": config_id,
        "platform": platform.value
    }), 201


@ticketing_bp.route('/configs/<config_id>', methods=['PUT'])
@require_auth_and_permission('manage_integrations')
def update_config(config_id: str):
    """Update a ticketing integration."""
    if config_id not in ticketing_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    data = request.get_json()
    config = ticketing_service.configs[config_id]

    if 'enabled' in data:
        config.enabled = data['enabled']
    if 'auto_create' in data:
        config.auto_create = data['auto_create']
    if 'auto_close' in data:
        config.auto_close = data['auto_close']
    if 'priority_mapping' in data:
        config.priority_mapping = data['priority_mapping']
    if 'custom_fields' in data:
        config.custom_fields = data['custom_fields']

    return jsonify({"message": "Configuration updated"})


@ticketing_bp.route('/configs/<config_id>', methods=['DELETE'])
@require_auth_and_permission('manage_integrations')
def delete_config(config_id: str):
    """Delete a ticketing integration."""
    if config_id not in ticketing_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    ticketing_service.remove_config(config_id)
    return jsonify({"message": "Configuration deleted"})


@ticketing_bp.route('/configs/<config_id>/test', methods=['POST'])
@require_auth_and_permission('manage_integrations')
def test_config(config_id: str):
    """Test ticketing configuration by creating a test ticket."""
    if config_id not in ticketing_service.configs:
        return jsonify({"error": "Configuration not found"}), 404

    test_finding = AuditFinding(
        id="test-finding-001",
        server_name="test-server",
        check_name="Test Connection Check",
        status="WARN",
        severity="low",
        description="This is a test finding to verify the ticketing integration.",
        remediation="No action required - this is a test ticket.",
        compliance_refs=["TEST-001"]
    )

    ticket = ticketing_service.create_ticket_for_finding(config_id, test_finding)

    if ticket:
        return jsonify({
            "message": "Test ticket created successfully",
            "ticket_id": ticket.external_id,
            "url": ticket.url
        })
    else:
        return jsonify({"error": "Failed to create test ticket"}), 500


@ticketing_bp.route('/tickets', methods=['POST'])
@require_auth_and_permission('manage_remediation')
def create_ticket():
    """Create a ticket for a finding."""
    data = request.get_json()

    if 'config_id' not in data:
        return jsonify({"error": "config_id is required"}), 400

    required_finding = ['server_name', 'check_name', 'status', 'severity', 'description', 'remediation']
    if not all(k in data for k in required_finding):
        return jsonify({"error": f"Missing finding fields: {required_finding}"}), 400

    finding = AuditFinding(
        id=data.get('finding_id', hashlib.sha256(f"{data['server_name']}{data['check_name']}".encode()).hexdigest()[:16]),
        server_name=data['server_name'],
        check_name=data['check_name'],
        status=data['status'],
        severity=data['severity'],
        description=data['description'],
        remediation=data['remediation'],
        compliance_refs=data.get('compliance_refs', []),
        evidence=data.get('evidence')
    )

    ticket = ticketing_service.create_ticket_for_finding(data['config_id'], finding)

    if ticket:
        return jsonify({
            "message": "Ticket created",
            "ticket_id": ticket.external_id,
            "url": ticket.url,
            "sla_due": ticket.sla_due.isoformat() if ticket.sla_due else None
        }), 201
    else:
        return jsonify({"error": "Failed to create ticket"}), 500


@ticketing_bp.route('/tickets/bulk', methods=['POST'])
@require_auth_and_permission('manage_remediation')
def create_bulk_tickets():
    """Create tickets for multiple findings."""
    data = request.get_json()

    if 'config_id' not in data or 'findings' not in data:
        return jsonify({"error": "config_id and findings are required"}), 400

    findings = []
    for f in data['findings']:
        findings.append(AuditFinding(
            id=f.get('id', hashlib.sha256(f"{f['server_name']}{f['check_name']}".encode()).hexdigest()[:16]),
            server_name=f['server_name'],
            check_name=f['check_name'],
            status=f['status'],
            severity=f['severity'],
            description=f['description'],
            remediation=f['remediation'],
            compliance_refs=f.get('compliance_refs', []),
            evidence=f.get('evidence')
        ))

    results = ticketing_service.create_bulk_tickets(data['config_id'], findings)

    summary = {
        "created": sum(1 for t in results.values() if t),
        "failed": sum(1 for t in results.values() if not t),
        "tickets": [
            {"finding_id": fid, "ticket_id": t.external_id, "url": t.url}
            for fid, t in results.items() if t
        ]
    }

    return jsonify(summary), 201


@ticketing_bp.route('/tickets/<finding_id>/close', methods=['POST'])
@require_auth_and_permission('manage_remediation')
def close_ticket(finding_id: str):
    """Close a ticket by finding ID."""
    data = request.get_json() or {}
    resolution = data.get('resolution', 'Remediated via Security Audit Toolkit')

    success = ticketing_service.close_ticket_for_finding(finding_id, resolution)

    if success:
        return jsonify({"message": "Ticket closed"})
    else:
        return jsonify({"error": "Failed to close ticket"}), 500


@ticketing_bp.route('/tickets/<finding_id>/sync', methods=['POST'])
@require_auth_and_permission('manage_remediation')
def sync_ticket(finding_id: str):
    """Sync ticket status from external system."""
    status = ticketing_service.sync_ticket_status(finding_id)

    if status:
        return jsonify({"status": status.value})
    else:
        return jsonify({"error": "Ticket not found or sync failed"}), 404


@ticketing_bp.route('/tickets/sla-breached', methods=['GET'])
@require_auth_and_permission('view_reports')
def get_sla_breached():
    """Get all tickets that have breached their SLA."""
    breached = ticketing_service.get_sla_breached_tickets()

    return jsonify({
        "count": len(breached),
        "tickets": [
            {
                "ticket_id": t.external_id,
                "finding_id": t.finding_id,
                "server_name": t.server_name,
                "summary": t.summary,
                "sla_due": t.sla_due.isoformat() if t.sla_due else None,
                "overdue_hours": (datetime.utcnow() - t.sla_due).total_seconds() / 3600 if t.sla_due else 0,
                "url": t.url
            }
            for t in breached
        ]
    })


@ticketing_bp.route('/tickets', methods=['GET'])
@require_auth_and_permission('view_reports')
def list_tickets():
    """List all tracked tickets."""
    server = request.args.get('server')
    status = request.args.get('status')

    tickets = []
    for finding_id, ticket in ticketing_service.tickets.items():
        if server and server.lower() not in ticket.server_name.lower():
            continue
        if status and ticket.status.value != status:
            continue

        tickets.append({
            "finding_id": finding_id,
            "ticket_id": ticket.external_id,
            "platform": ticket.platform.value,
            "server_name": ticket.server_name,
            "summary": ticket.summary,
            "status": ticket.status.value,
            "priority": ticket.priority.value,
            "assignee": ticket.assignee,
            "created_at": ticket.created_at.isoformat(),
            "sla_due": ticket.sla_due.isoformat() if ticket.sla_due else None,
            "url": ticket.url
        })

    return jsonify({"tickets": tickets})


# =============================================================================
# Webhook Handlers for Bi-directional Sync
# =============================================================================

@ticketing_bp.route('/webhooks/jira', methods=['POST'])
def jira_webhook():
    """Handle Jira webhooks for bi-directional sync."""
    data = request.get_json()

    event_type = data.get('webhookEvent', '')
    issue = data.get('issue', {})
    issue_key = issue.get('key', '')

    logger.info(f"Jira webhook: {event_type} for {issue_key}")

    if event_type == 'jira:issue_updated':
        # Check if status changed to Done/Closed
        changelog = data.get('changelog', {})
        for item in changelog.get('items', []):
            if item.get('field') == 'status' and item.get('toString', '').lower() in ['done', 'closed', 'resolved']:
                # Find our ticket and mark finding as remediated
                for finding_id, ticket in ticketing_service.tickets.items():
                    if ticket.external_id == issue_key:
                        ticket.status = TicketStatus.RESOLVED
                        ticket.resolved_at = datetime.utcnow()
                        logger.info(f"Finding {finding_id} marked as remediated via Jira")

                        # Update finding status in database
                        _update_finding_remediation_status(finding_id, 'resolved', 'jira', issue_key)
                        break

    return jsonify({"received": True})


@ticketing_bp.route('/webhooks/servicenow', methods=['POST'])
def servicenow_webhook():
    """Handle ServiceNow webhooks for bi-directional sync."""
    data = request.get_json()

    incident_number = data.get('number', '')
    state = data.get('state', '')

    logger.info(f"ServiceNow webhook: incident {incident_number} state={state}")

    # State 6 = Resolved, 7 = Closed
    if state in ['6', '7']:
        for finding_id, ticket in ticketing_service.tickets.items():
            if ticket.external_id == incident_number:
                ticket.status = TicketStatus.RESOLVED if state == '6' else TicketStatus.CLOSED
                ticket.resolved_at = datetime.utcnow()
                logger.info(f"Finding {finding_id} marked as remediated via ServiceNow")

                # Update finding status in database
                resolved_status = 'resolved' if state == '6' else 'closed'
                _update_finding_remediation_status(finding_id, resolved_status, 'servicenow', incident_number)
                break

    return jsonify({"received": True})


def _update_finding_remediation_status(finding_id: str, status: str, source: str, ticket_id: str):
    """
    Update finding remediation status in the database.

    This records when a ticket is resolved so the finding status can be tracked.
    """
    try:
        from config import get_db_session

        db = get_db_session()
        try:
            # Try to update differential analysis if the finding is from there
            from models.differential import DifferentialAnalysis
            from datetime import datetime
            import json

            # Find any differential analyses that contain this finding
            analyses = db.query(DifferentialAnalysis).filter(
                DifferentialAnalysis.changes.contains(finding_id)
            ).all()

            for analysis in analyses:
                if analysis.changes:
                    changes = json.loads(analysis.changes) if isinstance(analysis.changes, str) else analysis.changes

                    # Mark the finding as resolved in the changes JSON
                    for category in ['new_failures', 'persistent_failures']:
                        if category in changes:
                            for finding in changes[category]:
                                if finding.get('id') == finding_id or finding.get('check_name') == finding_id:
                                    finding['remediation_status'] = status
                                    finding['remediation_source'] = source
                                    finding['remediation_ticket'] = ticket_id
                                    finding['remediated_at'] = datetime.utcnow().isoformat()

                    analysis.changes = json.dumps(changes) if isinstance(changes, dict) else changes

            db.commit()
            logger.info(f"Updated remediation status for finding {finding_id} to {status}")

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Failed to update finding remediation status: {e}")
