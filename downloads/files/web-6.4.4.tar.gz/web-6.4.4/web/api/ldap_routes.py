"""
LDAP Administration Routes for Security Audit Toolkit

Provides:
- LDAP connection testing
- LDAP configuration viewing (masked)
- LDAP user search (for testing)

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user

from api.auth_routes import require_role
from auth_core import safe_error_response

# LDAP Authentication support
try:
    from auth.ldap_auth import (
        LDAPAuth, LDAPAuthError, LDAPConfig,
        get_ldap_auth
    )
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False
    get_ldap_auth = lambda: None

logger = logging.getLogger(__name__)

# Blueprint
ldap_bp = Blueprint('ldap_admin', __name__, url_prefix='/api/admin/ldap')


# =============================================================================
# LDAP Status & Configuration
# =============================================================================

@ldap_bp.route('/status', methods=['GET'])
@login_required
@require_role('Admin')
def ldap_status():
    """
    Get LDAP status and configuration (masked)

    Returns:
        JSON with LDAP enabled status and masked config
    """
    try:
        if not LDAP_AVAILABLE:
            return jsonify({
                'success': True,
                'available': False,
                'enabled': False,
                'message': 'ldap3 library not installed'
            })

        ldap = get_ldap_auth()

        if not ldap:
            return jsonify({
                'success': True,
                'available': True,
                'enabled': False,
                'message': 'LDAP not configured'
            })

        # Get masked config
        config = ldap.config.to_safe_dict()

        # Validate config
        is_valid, errors = ldap.config.validate()

        return jsonify({
            'success': True,
            'available': True,
            'enabled': ldap.is_enabled,
            'valid': is_valid,
            'validation_errors': errors if not is_valid else [],
            'config': config
        })

    except Exception as e:
        logger.error(f"Error getting LDAP status: {e}")
        return safe_error_response(e, 'Failed to get LDAP status')


@ldap_bp.route('/test', methods=['POST'])
@login_required
@require_role('Admin')
def test_ldap_connection():
    """
    Test LDAP server connection and credentials

    Returns:
        JSON with test result (success/failure and message)
    """
    try:
        if not LDAP_AVAILABLE:
            return jsonify({
                'success': False,
                'error': 'ldap3 library not installed. Install with: pip install ldap3'
            }), 400

        ldap = get_ldap_auth()

        if not ldap:
            return jsonify({
                'success': False,
                'error': 'LDAP not configured. Set LDAP_ENABLED=true and configure server settings.'
            }), 400

        if not ldap.is_enabled:
            return jsonify({
                'success': False,
                'error': 'LDAP is disabled. Set LDAP_ENABLED=true to enable.'
            }), 400

        # Validate config first
        is_valid, errors = ldap.config.validate()
        if not is_valid:
            return jsonify({
                'success': False,
                'error': f'Configuration errors: {", ".join(errors)}'
            }), 400

        # Test connection
        success, message = ldap.test_connection()

        if success:
            return jsonify({
                'success': True,
                'message': message
            })
        else:
            return jsonify({
                'success': False,
                'error': message
            }), 400

    except Exception as e:
        logger.error(f"Error testing LDAP connection: {e}")
        return safe_error_response(e, 'Failed to test LDAP connection')


@ldap_bp.route('/search-user', methods=['POST'])
@login_required
@require_role('Admin')
def search_ldap_user():
    """
    Search for a user in LDAP (for testing/verification)

    Request body:
        {"username": "jdoe"}

    Returns:
        JSON with user info if found
    """
    try:
        if not LDAP_AVAILABLE:
            return jsonify({
                'success': False,
                'error': 'ldap3 library not installed'
            }), 400

        ldap = get_ldap_auth()

        if not ldap or not ldap.is_enabled:
            return jsonify({
                'success': False,
                'error': 'LDAP is not enabled'
            }), 400

        data = request.get_json() or {}
        username = data.get('username', '').strip()

        if not username:
            return jsonify({
                'success': False,
                'error': 'Username is required'
            }), 400

        user = ldap.get_user_info(username)

        if not user:
            return jsonify({
                'success': False,
                'error': f'User not found: {username}'
            }), 404

        # Get role that would be assigned
        assigned_role = ldap.get_role_for_user(user)

        return jsonify({
            'success': True,
            'user': {
                'username': user.username,
                'dn': user.dn,
                'email': user.email,
                'display_name': user.display_name,
                'groups': user.groups,
                'assigned_role': assigned_role
            }
        })

    except LDAPAuthError as e:
        logger.error(f"LDAP search error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    except Exception as e:
        logger.error(f"Error searching LDAP user: {e}")
        return safe_error_response(e, 'Failed to search LDAP user')


@ldap_bp.route('/role-mapping', methods=['GET'])
@login_required
@require_role('Admin')
def get_role_mapping():
    """
    Get current LDAP group to role mapping

    Returns:
        JSON with role mapping configuration
    """
    try:
        if not LDAP_AVAILABLE:
            return jsonify({
                'success': True,
                'role_mapping': {},
                'default_role': 'Viewer',
                'available_roles': ['Viewer', 'Operator', 'Analyst', 'Admin', 'SuperAdmin']
            })

        ldap = get_ldap_auth()

        if not ldap:
            return jsonify({
                'success': True,
                'role_mapping': {},
                'default_role': 'Viewer',
                'available_roles': ['Viewer', 'Operator', 'Analyst', 'Admin', 'SuperAdmin']
            })

        return jsonify({
            'success': True,
            'role_mapping': ldap.config.role_mapping,
            'default_role': ldap.config.default_role,
            'available_roles': ['Viewer', 'Operator', 'Analyst', 'Admin', 'SuperAdmin']
        })

    except Exception as e:
        logger.error(f"Error getting role mapping: {e}")
        return safe_error_response(e, 'Failed to get role mapping')


@ldap_bp.route('/validate-config', methods=['POST'])
@login_required
@require_role('Admin')
def validate_ldap_config():
    """
    Validate LDAP configuration without testing connection

    Request body (optional):
        JSON with config values to validate instead of environment

    Returns:
        JSON with validation results
    """
    try:
        data = request.get_json() or {}

        if data:
            # Create config from provided values
            config = LDAPConfig(
                enabled=data.get('enabled', False),
                server=data.get('server', ''),
                port=int(data.get('port', 389)),
                use_ssl=data.get('use_ssl', False),
                bind_dn=data.get('bind_dn', ''),
                bind_password=data.get('bind_password', ''),
                user_search_base=data.get('user_search_base', ''),
                user_search_filter=data.get('user_search_filter', '(sAMAccountName={username})'),
                group_search_base=data.get('group_search_base', ''),
                group_attribute=data.get('group_attribute', 'memberOf'),
                role_mapping=data.get('role_mapping', {}),
                default_role=data.get('default_role', 'Viewer'),
                allow_local_fallback=data.get('allow_local_fallback', True)
            )
        else:
            # Use environment config
            config = LDAPConfig.from_env()

        is_valid, errors = config.validate()

        return jsonify({
            'success': True,
            'valid': is_valid,
            'errors': errors
        })

    except Exception as e:
        logger.error(f"Error validating LDAP config: {e}")
        return safe_error_response(e, 'Failed to validate configuration')
