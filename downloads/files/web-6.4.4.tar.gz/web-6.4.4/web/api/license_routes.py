"""
License Management API Routes

Provides endpoints for:
- Checking license status
- Activating license keys
- Managing registered machines
- Generating license keys (admin only)
"""

from flask import Blueprint, jsonify, request
from functools import wraps
import logging
import os

logger = logging.getLogger(__name__)

license_bp = Blueprint('license', __name__, url_prefix='/api/license')


def _get_support_email() -> str:
    return os.environ.get('SUPPORT_EMAIL', '').strip()


def _get_billing_currency() -> str:
    return (os.environ.get('BILLING_CURRENCY', 'GBP') or 'GBP').strip().upper()


def _get_currency_symbol(currency: str) -> str:
    return {
        'USD': '$',
        'GBP': '£',
        'EUR': '€',
    }.get(currency, f'{currency} ')


def _format_yearly_price(amount: int) -> str:
    currency = _get_billing_currency()
    symbol = _get_currency_symbol(currency)
    return f"~{symbol}{amount:,}/year"


def _get_enterprise_private_checkout_url() -> str:
    """Return the private Enterprise Stripe checkout URL if configured."""
    return os.environ.get('ENTERPRISE_PRIVATE_CHECKOUT_URL', '').strip()


def get_license_service():
    """Get license service instance."""
    from services_pkg.services.license_service import get_license_service as _get_service
    return _get_service()


def require_admin(f):
    """Decorator to require admin role for endpoint."""
    @wraps(f)
    def decorated(*args, **kwargs):
        # Import here to avoid circular imports
        try:
            from auth_core import get_current_user
            user = get_current_user()
            if not user or user.get('role') not in ['admin', 'superadmin']:
                return jsonify({
                    "error": "Admin access required",
                    "code": "FORBIDDEN"
                }), 403
        except Exception as e:
            # If auth fails, allow in development mode
            logger.debug(f"Auth check skipped: {e}")
        return f(*args, **kwargs)
    return decorated


# ============================================================================
# Public Endpoints
# ============================================================================

@license_bp.route('/status', methods=['GET'])
def get_license_status():
    """
    Get current license status.

    Returns:
        JSON with license tier, machine count, limits, and features.

    Example response:
        {
            "license": {
                "tier": "free",
                "is_valid": true,
                "machine_limit": 25,
                "expires": null
            },
            "machines": {
                "count": 12,
                "limit": 25,
                "remaining": 13
            }
        }
    """
    try:
        service = get_license_service()
        return jsonify(service.get_status())
    except Exception as e:
        logger.error(f"Failed to get license status: {e}")
        return jsonify({"error": str(e)}), 500


@license_bp.route('/tiers', methods=['GET'])
def get_available_tiers():
    """
    Get available license tiers and pricing for purchase.

    Returns tiers with availability status:
    - active: Available for purchase
    - waitlist: Join waitlist (limited capacity)
    - coming_soon: Not yet available
    - partner_only: Only through partners

    Example response:
        {
            "tiers": [
                {
                    "id": "free",
                    "name": "Free",
                    "status": "active",
                    "purchasable": true,
                    "price_yearly": 0,
                    "machine_limit": 25,
                    "support": "Docs/Community"
                },
                ...
            ]
        }
    """
    from services_pkg.services.license_service import (
        LicenseTier, TIER_AVAILABILITY, TRIAL_CONFIG
    )

    support_email = _get_support_email()
    support_contact_url = f"mailto:{support_email}" if support_email else None
    billing_currency = _get_billing_currency()

    tier_info = {
        LicenseTier.FREE: {
            'name': 'Free',
            'machine_limit': 25,
            'support': 'Docs/Community',
            'price_yearly': 0,
        },
        LicenseTier.TRIAL: {
            'name': 'Trial',
            'machine_limit': TRIAL_CONFIG.get('machine_limit', 150),
            'support': 'Full features for evaluation',
            'price_yearly': 0,
            'duration_days': TRIAL_CONFIG.get('duration_days', 30),
        },
        LicenseTier.STARTER: {
            'name': 'Starter',
            'machine_limit': 50,
            'support': 'Best effort email',
        },
        LicenseTier.PROFESSIONAL: {
            'name': 'Professional',
            'machine_limit': 150,
            'support': '48hr email response',
        },
        LicenseTier.BUSINESS: {
            'name': 'Business',
            'machine_limit': 500,
            'support': 'Priority email (24hr)',
        },
        LicenseTier.ENTERPRISE: {
            'name': 'Enterprise',
            'machine_limit': 'Unlimited',
            'support': 'Priority + scheduled calls',
        },
    }

    tiers = []
    hidden_public_tiers = {LicenseTier.ENTERPRISE}
    for tier in LicenseTier:
        if tier in hidden_public_tiers:
            continue
        availability = TIER_AVAILABILITY.get(tier, {})
        info = tier_info.get(tier, {})
        contact_url = availability.get('contact_url') or support_contact_url
        tiers.append({
            'id': tier.value,
            'name': info.get('name', tier.value.title()),
            'status': availability.get('status', 'unknown'),
            'purchasable': availability.get('purchasable', False),
            'website_listed': availability.get('website_listed', True),
            'self_service_private_checkout': availability.get('self_service_private_checkout', False),
            'price_yearly': availability.get('price_yearly', info.get('price_yearly', 0)),
            'currency': billing_currency,
            'machine_limit': info.get('machine_limit'),
            'support': info.get('support'),
            'message': availability.get('message'),
            'waitlist_url': availability.get('waitlist_url'),
            'contact_url': contact_url,
            'support_email': support_email or None,
        })

    return jsonify({'tiers': tiers})


# ============================================================================
# Trial Management Endpoints
# ============================================================================

@license_bp.route('/trial/status', methods=['GET'])
def get_trial_status():
    """
    Get detailed trial status for the current installation.

    Returns trial information including:
    - Whether currently in trial
    - Days remaining
    - Whether trial was extended
    - Upgrade options when trial expires

    Example response (active trial):
        {
            "is_trial": true,
            "active": true,
            "days_remaining": 23,
            "started": "2026-02-01T00:00:00",
            "expires": "2026-03-03T00:00:00",
            "extended": false,
            "can_extend": true,
            "features_unlocked": true,
            "feature_level": "professional",
            "upgrade_prompt": false
        }

    Example response (expired trial):
        {
            "is_trial": false,
            "was_trial": true,
            "trial_started": "2026-01-01T00:00:00",
            "current_tier": "free",
            "features_unlocked": false,
            "upgrade_prompt": true
        }
    """
    try:
        service = get_license_service()
        return jsonify(service.get_trial_status())
    except Exception as e:
        logger.error(f"Failed to get trial status: {e}")
        return jsonify({"error": str(e)}), 500


@license_bp.route('/trial/extend', methods=['POST'])
def extend_trial():
    """
    Request a one-time trial extension.

    Extensions are limited to once per installation and capped at 14 days.
    Only works during an active trial (not after expiry).

    Request body (optional):
        {
            "days": 7  // Optional, defaults to max allowed (14)
        }

    Returns:
        JSON with extension result.

    Example success response:
        {
            "success": true,
            "extended_by_days": 7,
            "new_expires": "2026-03-10T00:00:00",
            "days_remaining": 14
        }

    Example failure (already extended):
        {
            "success": false,
            "error": "Trial has already been extended once"
        }
    """
    try:
        data = request.get_json() or {}
        days = data.get('days')

        service = get_license_service()
        result = service.extend_trial(days=days)

        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"Failed to extend trial: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@license_bp.route('/trial/upgrade-options', methods=['GET'])
def get_upgrade_options():
    """
    Get available upgrade options for trial/free users.

    Returns purchasable tiers with pricing to help users choose
    the right plan when their trial expires.

    Example response:
        {
            "current_tier": "trial",
            "days_remaining": 7,
            "options": [
                {
                    "tier": "starter",
                    "price_yearly": 549,
                    "machine_limit": 50,
                    "status": "active"
                },
                {
                    "tier": "professional",
                    "price_yearly": 1099,
                    "machine_limit": 150,
                    "status": "active"
                }
            ],
            "recommended": "professional"
        }
    """
    try:
        from services_pkg.services.license_service import TIER_AVAILABILITY, LicenseTier

        service = get_license_service()
        status = service.get_status()
        trial_status = service.get_trial_status()
        billing_currency = _get_billing_currency()

        # Get purchasable options
        options = []
        for tier in [LicenseTier.STARTER, LicenseTier.PROFESSIONAL]:
            availability = TIER_AVAILABILITY.get(tier, {})
            if availability.get('purchasable', False):
                options.append({
                    'tier': tier.value,
                    'price_yearly': availability.get('price_yearly', 0),
                    'currency': billing_currency,
                    'machine_limit': service._license_info.machine_limit if tier == LicenseTier.STARTER else 150,
                    'status': availability.get('status', 'unknown')
                })

        return jsonify({
            'current_tier': status['license']['tier'],
            'days_remaining': trial_status.get('days_remaining', 0),
            'options': options,
            'currency': billing_currency,
            'recommended': 'professional' if status['machines']['count'] > 50 else 'starter'
        })

    except Exception as e:
        logger.error(f"Failed to get upgrade options: {e}")
        return jsonify({"error": str(e)}), 500


@license_bp.route('/trial/register', methods=['POST'])
def register_trial():
    """
    Register and activate a new trial with anti-abuse protections.

    Requires email registration. Trial is bound to machine fingerprint
    to prevent reinstall abuse. Reports generated during trial are
    watermarked and exports are disabled.

    Request body:
        {
            "email": "user@company.com"
        }

    Returns:
        JSON with trial activation result.

    Example success response:
        {
            "success": true,
            "tier": "trial",
            "days": 14,
            "expires": "2026-03-08T00:00:00",
            "restrictions": {
                "exports_disabled": true,
                "reports_watermarked": true,
                "message": "Trial is for evaluation only. Exports disabled and reports are watermarked."
            }
        }

    Example failure (previous trial detected):
        {
            "success": false,
            "error": "A trial was previously used on this machine",
            "upgrade_options": {
                "starter": {"price": 299, "url": "https://..."},
                "professional": {"price": 799, "url": "https://..."}
            }
        }
    """
    import re
    try:
        from services_pkg.services.license_service import TRIAL_CONFIG

        data = request.get_json() or {}
        email = data.get('email', '').strip()

        # Validate email if registration required
        if TRIAL_CONFIG.get('require_registration', True):
            if not email:
                return jsonify({
                    "success": False,
                    "error": "Email address is required to start a trial",
                    "code": "EMAIL_REQUIRED"
                }), 400

            # Basic email validation
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_pattern, email):
                return jsonify({
                    "success": False,
                    "error": "Please provide a valid email address",
                    "code": "INVALID_EMAIL"
                }), 400

        service = get_license_service()

        # Get machine fingerprint for binding
        machine_id = service._get_machine_fingerprint()

        # Check for previous trial on this machine
        existing_trial = service._check_existing_trial(machine_id)
        if existing_trial:
            billing_currency = _get_billing_currency()
            return jsonify({
                "success": False,
                "error": "A trial was previously used on this machine",
                "code": "TRIAL_PREVIOUSLY_USED",
                "previous_trial": {
                    "email": existing_trial.get('email', 'unknown'),
                    "started": existing_trial.get('started'),
                    "ended": existing_trial.get('ended')
                },
                "upgrade_options": {
                    "starter": {"price": 549, "currency": billing_currency, "url": "/pricing#starter"},
                    "professional": {"price": 1099, "currency": billing_currency, "url": "/pricing#professional"}
                }
            }), 403

        # Activate trial with anti-abuse bindings
        result = service._activate_trial(email=email, machine_id=machine_id)

        if result.get('success'):
            return jsonify(result), 200
        else:
            return jsonify(result), 400

    except Exception as e:
        logger.error(f"Failed to register trial: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@license_bp.route('/activate', methods=['POST'])
def activate_license():
    """
    Activate a license key.

    Request body:
        {
            "key": "PROF-XXXX-XXXX-XXXX"
        }

    Returns:
        JSON with activation result.
    """
    try:
        data = request.get_json()
        if not data or 'key' not in data:
            return jsonify({
                "success": False,
                "message": "License key required"
            }), 400

        service = get_license_service()
        result = service.activate_license(data['key'])

        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"License activation failed: {e}")
        return jsonify({
            "success": False,
            "message": f"Activation failed: {str(e)}"
        }), 500


@license_bp.route('/deactivate', methods=['POST'])
@require_admin
def deactivate_license():
    """
    Deactivate the current license (admin only).

    Returns:
        JSON with deactivation result.
    """
    try:
        service = get_license_service()
        result = service.deactivate_license()
        return jsonify(result)
    except Exception as e:
        logger.error(f"License deactivation failed: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ============================================================================
# Keygen License Integration
# ============================================================================

@license_bp.route('/keygen/validate', methods=['POST'])
def validate_keygen_license():
    """
    Validate and activate a Keygen license key.

    Request body:
        {
            "key": "KEYGEN-LICENSE-KEY-HERE"
        }

    Returns:
        JSON with validation result and license details.

    Example success response:
        {
            "success": true,
            "valid": true,
            "tier": "professional",
            "expires_at": "2027-02-25T00:00:00Z",
            "machines_registered": 12,
            "machines_limit": 150,
            "days_remaining": 365,
            "message": "License valid and activated"
        }

    Example failure response:
        {
            "success": false,
            "valid": false,
            "error": "Invalid or expired license key"
        }
    """
    try:
        from services_pkg.services.keygen_integration import get_keygen_client
        from datetime import datetime, timezone

        data = request.get_json() or {}
        key = data.get('key', '').strip()

        if not key:
            return jsonify({
                "success": False,
                "valid": False,
                "error": "License key is required"
            }), 400

        service = get_license_service()
        machine_id = service._get_machine_fingerprint()

        # Non-transferability enforcement: caller-provided machine IDs are ignored.
        if data.get('machine_id'):
            logger.info("Ignoring caller-supplied machine_id; using local installation fingerprint")

        keygen = get_keygen_client()
        if not keygen:
            return jsonify({
                "success": False,
                "error": "Keygen service not configured",
                "code": "KEYGEN_NOT_CONFIGURED"
            }), 503

        # Validate license key with Keygen
        is_valid, license_data = keygen.validate_key(key, machine_id)

        if not is_valid:
            return jsonify({
                "success": False,
                "valid": False,
                "error": license_data.get('error', 'Validation failed')
            }), 401

        # Calculate days remaining
        expires_at = license_data.get('expires_at')
        days_remaining = 0
        if expires_at:
            try:
                exp_date = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
                if exp_date.tzinfo is not None:
                    exp_date = exp_date.astimezone(timezone.utc).replace(tzinfo=None)
                days_remaining = max(0, (exp_date - datetime.utcnow()).days)
            except (ValueError, TypeError):
                pass

        persist_result = service.activate_keygen_license(
            license_key=key,
            tier=license_data.get('tier', 'free'),
            expires_at=expires_at,
            metadata=license_data.get('metadata') if isinstance(license_data, dict) else None,
        )
        if not persist_result.get('success'):
            return jsonify({
                "success": False,
                "valid": False,
                "error": persist_result.get('message', 'Failed to persist activated license')
            }), 400

        response_data = {
            "success": True,
            "valid": True,
            "tier": license_data.get('tier', 'unknown'),
            "expires_at": expires_at,
            "machines_registered": license_data.get('machines_count', 0),
            "machines_limit": license_data.get('machines_limit', 25),
            "days_remaining": days_remaining,
            "message": persist_result.get('message', 'License activated and bound to this installation'),
            "key_id": license_data.get('id'),
            "machine_id": machine_id,
            "host_bound": True,
        }

        # Propagate add-on fields so the UI can show the right success message
        if persist_result.get('addon'):
            response_data['addon'] = True
            response_data['addons_applied'] = persist_result.get('addons_applied', [])

        logger.info(f"Keygen license activated (host-bound): {license_data.get('key')} on {machine_id}")

        return jsonify(response_data), 200

    except Exception as e:
        logger.error(f"Keygen validation error: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Validation error: {str(e)}"
        }), 500


@license_bp.route('/keygen/info', methods=['GET'])
def get_keygen_license_info():
    """
    Get information about a Keygen license key.

    Query parameters:
        key: License key to check

    Returns:
        JSON with license information.

    Example:
        GET /api/license/keygen/info?key=KEYGEN-KEY-HERE

    Response:
        {
            "success": true,
            "key": "KEYGEN-...",
            "tier": "professional",
            "expires_at": "2027-02-25T00:00:00Z",
            "machines_limit": 150,
            "status": "active"
        }
    """
    try:
        from services_pkg.services.keygen_integration import get_keygen_client

        key = request.args.get('key', '').strip()
        if not key:
            return jsonify({
                "success": False,
                "error": "License key is required"
            }), 400

        keygen = get_keygen_client()
        if not keygen:
            return jsonify({
                "success": False,
                "error": "Keygen service not configured"
            }), 503

        license_info = keygen.get_license_info(key)
        if not license_info:
            return jsonify({
                "success": False,
                "error": "License key not found"
            }), 404

        return jsonify({
            "success": True,
            "key": license_info.get('key'),
            "tier": license_info.get('tier'),
            "expires_at": license_info.get('expires_at'),
            "machines_limit": license_info.get('machines_limit'),
            "machines_registered": license_info.get('machines_count'),
            "status": license_info.get('status')
        }), 200

    except Exception as e:
        logger.error(f"Error getting Keygen license info: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@license_bp.route('/keygen/create', methods=['POST'])
@require_admin
def create_keygen_license():
    """
    Create a new Keygen license (admin only).

    Request body:
        {
            "tier": "professional",           // free, beta, starter, professional, business
            "email": "customer@example.com",
            "expires_in_days": 365,           // optional, defaults to 365 (30 for beta)
            "machines_limit": 150,             // optional
            "metadata": {                      // optional
                "order_id": "ORD-12345",
                "customer_name": "Acme Corp"
            }
        }

    Returns:
        JSON with created license key.

    Example success response:
        {
            "success": true,
            "key": "KEYGEN-XXXXXXXX-XXXXXXXX",
            "id": "keygen-license-id",
            "tier": "professional",
            "expires_at": "2027-02-25T00:00:00Z",
            "machines_limit": 150
        }
    """
    try:
        from services_pkg.services.keygen_integration import get_keygen_client

        data = request.get_json() or {}

        tier = str(data.get('tier', 'free')).strip().lower()
        email = data.get('email', '').strip()
        default_expires_in_days = 30 if tier == 'beta' else 365
        expires_in_days = data.get('expires_in_days', default_expires_in_days)
        machines_limit = data.get('machines_limit', 25)
        metadata = data.get('metadata', {})

        if metadata is None:
            metadata = {}

        if not isinstance(metadata, dict):
            return jsonify({
                "success": False,
                "error": "metadata must be an object"
            }), 400

        try:
            expires_in_days = int(expires_in_days)
        except (TypeError, ValueError):
            return jsonify({
                "success": False,
                "error": "expires_in_days must be an integer"
            }), 400

        try:
            machines_limit = int(machines_limit)
        except (TypeError, ValueError):
            return jsonify({
                "success": False,
                "error": "machines_limit must be an integer"
            }), 400

        # Validate required fields
        if not email:
            return jsonify({
                "success": False,
                "error": "Email address is required"
            }), 400

        if expires_in_days < 1:
            return jsonify({
                "success": False,
                "error": "expires_in_days must be at least 1"
            }), 400

        if machines_limit < 1:
            return jsonify({
                "success": False,
                "error": "machines_limit must be at least 1"
            }), 400

        if tier == 'beta' and expires_in_days > 90:
            return jsonify({
                "success": False,
                "error": "beta licenses are limited to a maximum of 90 days"
            }), 400

        if tier not in ['free', 'beta', 'starter', 'professional', 'business', 'enterprise']:
            return jsonify({
                "success": False,
                "error": f"Invalid tier: {tier}"
            }), 400

        keygen = get_keygen_client()
        if not keygen:
            return jsonify({
                "success": False,
                "error": "Keygen service not configured"
            }), 503

        success, result = keygen.create_license(
            tier=tier,
            email=email,
            expires_in_days=expires_in_days,
            machines_limit=machines_limit,
            metadata=metadata
        )

        if not success:
            return jsonify({
                "success": False,
                "error": result.get('error', 'License creation failed')
            }), 400

        logger.info(f"Keygen license created for {email}: {result.get('key')}")

        return jsonify({
            "success": True,
            "key": result.get('key'),
            "id": result.get('id'),
            "tier": result.get('tier'),
            "expires_at": result.get('expires_at'),
            "machines_limit": result.get('machines_limit'),
            "message": f"License created for {email}. Share the key via secure channel."
        }), 201

    except Exception as e:
        logger.error(f"Error creating Keygen license: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@license_bp.route('/check', methods=['POST'])
def check_machine_license():
    """
    Check if a machine can be audited under the current license.

    Request body:
        {
            "machine_id": "unique-machine-id",
            "hostname": "server1.example.com",
            "ip_address": "192.168.1.100",  # optional
            "os_info": "Ubuntu 22.04"       # optional
        }

    Returns:
        JSON with allowed status and message.
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                "allowed": False,
                "message": "Request body required"
            }), 400

        machine_id = data.get('machine_id')
        hostname = data.get('hostname')

        if not machine_id or not hostname:
            return jsonify({
                "allowed": False,
                "message": "machine_id and hostname are required"
            }), 400

        service = get_license_service()
        result = service.check_license(
            machine_id=machine_id,
            hostname=hostname,
            ip_address=data.get('ip_address'),
            os_info=data.get('os_info')
        )

        status_code = 200 if result.get('allowed') else 403
        return jsonify(result), status_code

    except Exception as e:
        logger.error(f"License check failed: {e}")
        return jsonify({
            "allowed": False,
            "message": str(e)
        }), 500


# ============================================================================
# Machine Management (Admin)
# ============================================================================

@license_bp.route('/machines', methods=['GET'])
@require_admin
def list_machines():
    """
    List all registered machines (admin only).

    Returns:
        JSON array of registered machines.
    """
    try:
        service = get_license_service()
        machines = service.list_machines()
        return jsonify({
            "machines": machines,
            "count": len(machines),
            "limit": service.machine_limit if service.machine_limit != float('inf') else "unlimited"
        })
    except Exception as e:
        logger.error(f"Failed to list machines: {e}")
        return jsonify({"error": str(e)}), 500


@license_bp.route('/machines/<machine_id>', methods=['DELETE'])
@require_admin
def remove_machine(machine_id):
    """
    Remove a registered machine (admin only).

    Args:
        machine_id: The machine ID to remove

    Returns:
        JSON with result.
    """
    try:
        service = get_license_service()
        if service.remove_machine(machine_id):
            return jsonify({
                "success": True,
                "message": f"Machine {machine_id} removed"
            })
        else:
            return jsonify({
                "success": False,
                "message": "Machine not found"
            }), 404
    except Exception as e:
        logger.error(f"Failed to remove machine: {e}")
        return jsonify({"error": str(e)}), 500


@license_bp.route('/machines/reset', methods=['POST'])
@require_admin
def reset_machines():
    """
    Reset all registered machines (admin only).

    WARNING: This removes all machine registrations.

    Returns:
        JSON with result.
    """
    try:
        service = get_license_service()
        service.reset_machines()
        return jsonify({
            "success": True,
            "message": "All machines have been unregistered"
        })
    except Exception as e:
        logger.error(f"Failed to reset machines: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================================
# License Key Generation (SuperAdmin Only)
# ============================================================================

@license_bp.route('/generate', methods=['POST'])
@require_admin
def generate_license_key():
    """
    Generate a new license key (superadmin only).

    Request body:
        {
            "tier": "starter" | "professional" | "business"
        }

    Returns:
        JSON with generated license key.

    Note: In production, this endpoint should be protected
    and keys should be generated through a separate admin system.
    """
    try:
        # Additional superadmin check
        try:
            from auth_core import get_current_user
            user = get_current_user()
            if not user or user.get('role') != 'superadmin':
                return jsonify({
                    "error": "SuperAdmin access required for key generation",
                    "code": "FORBIDDEN"
                }), 403
        except Exception as e:
            logger.debug(f"SuperAdmin check skipped: {e}")

        data = request.get_json()
        if not data or 'tier' not in data:
            return jsonify({
                "success": False,
                "message": "Tier is required (starter, professional, business)"
            }), 400

        tier_map = {
            "starter": "STARTER",
            "professional": "PROFESSIONAL",
            "business": "BUSINESS",
            "enterprise": "ENTERPRISE",
        }

        tier_name = data['tier'].lower()
        if tier_name not in tier_map:
            return jsonify({
                "success": False,
                "message": f"Invalid tier. Must be one of: {list(tier_map.keys())}"
            }), 400

        from services_pkg.services.license_service import LicenseService, LicenseTier
        tier = LicenseTier[tier_map[tier_name]]

        key = LicenseService.generate_license_key(tier)

        return jsonify({
            "success": True,
            "tier": tier_name,
            "key": key,
            "note": "This key is valid for 365 days from activation"
        })

    except Exception as e:
        logger.error(f"Failed to generate license key: {e}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


# ============================================================================
# Pricing Information (Public)
# ============================================================================

@license_bp.route('/pricing', methods=['GET'])
def get_pricing():
    """
    Get current pricing information.

    Note: Prices are preliminary and subject to change.

    Returns:
        JSON with pricing tiers.
    """
    billing_currency = _get_billing_currency()

    return jsonify({
        "tiers": [
            {
                "name": "Community",
                "id": "free",
                "servers": "1-25",
                "price": "Free",
                "price_yearly": 0,
                "currency": billing_currency,
                "features": [
                    "Core audit scripts (255+)",
                    "Basic dashboard",
                    "HTML reports",
                    "Community support (GitHub)"
                ]
            },
            {
                "name": "Starter",
                "id": "starter",
                "servers": "26-50",
                "price": _format_yearly_price(549),
                "price_yearly": 549,
                "currency": billing_currency,
                "features": [
                    "Up to 50 servers",
                    "Scheduled audits",
                    "PDF reports",
                    "Best-effort email support"
                ]
            },
            {
                "name": "Professional",
                "id": "professional",
                "servers": "51-150",
                "price": _format_yearly_price(1099),
                "price_yearly": 1099,
                "currency": billing_currency,
                "features": [
                    "Everything in Starter",
                    "Up to 150 servers",
                    "Scheduled audits",
                    "PDF reports",
                    "SSO support",
                    "48-hour email support"
                ]
            },
            {
                "name": "Business",
                "id": "business",
                "servers": "151-500",
                "price": _format_yearly_price(2499),
                "price_yearly": 2499,
                "currency": billing_currency,
                "features": [
                    "Everything in Professional",
                    "SIEM integration",
                    "Parallel execution",
                    "Priority support",
                    "Monthly call option"
                ]
            }
        ],
        "currency": billing_currency,
        "billing": "annual"
    })


@license_bp.route('/enterprise/private-checkout', methods=['GET'])
@require_admin
def get_enterprise_private_checkout():
    """
    Return the private Enterprise Stripe checkout URL for authorized operators.

    This endpoint is intentionally admin-only so the Enterprise checkout link
    can remain off the public website while still supporting self-service
    fulfillment via Stripe + Keygen.
    """
    return jsonify({
        "success": False,
        "message": "Enterprise tier is currently unavailable.",
        "code": "ENTERPRISE_NOT_AVAILABLE"
    }), 410
