"""
API Routes for Data Merge Service (Optimized)

Provides paginated endpoints for unified inventory across databases.

Endpoints:
- GET /api/inventory/status - Database status and summary stats
- GET /api/inventory/merged - Paginated merged inventory
- GET /api/inventory/servers - Paginated main servers
- GET /api/inventory/servers/<id> - Single server with enrichment
- GET /api/inventory/assets - Paginated discovered assets
- GET /api/inventory/summary - Lightweight statistics only
- POST /api/inventory/cache/clear - Clear query cache

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
from flask import Blueprint, jsonify, request

# Import optimized merge service
try:
    from services.data_merge_service_optimized import get_merge_service
except ImportError:
    from web.services.data_merge_service_optimized import get_merge_service

# Import Flask-Login for authentication
try:
    from flask_login import login_required, current_user
    from auth_login import is_authenticated
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    FLASK_LOGIN_AVAILABLE = False

    def login_required(f):
        return f

    current_user = None

    def is_authenticated():
        return True

logger = logging.getLogger(__name__)

# Create blueprint
merge_bp = Blueprint('merge', __name__, url_prefix='/api/inventory')


def require_auth(f):
    """Decorator to require authentication for API endpoints."""
    def wrapper(*args, **kwargs):
        if FLASK_LOGIN_AVAILABLE and not is_authenticated():
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper


@merge_bp.route('/status')
def inventory_status():
    """
    Check database status and get summary statistics.

    Returns:
        JSON with database availability and counts
    """
    try:
        service = get_merge_service()
        summary = service.get_inventory_summary()

        return jsonify({
            'status': 'ok' if summary['main_db_available'] and summary['asset_db_available'] else 'partial',
            'databases': {
                'main_db': summary['main_db_available'],
                'asset_db': summary['asset_db_available']
            },
            'counts': {
                'main_servers': summary['main_servers'],
                'discovered_assets': summary['discovered_assets']
            }
        })
    except Exception as e:
        logger.error(f"Error checking database status: {e}")
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500


@merge_bp.route('/summary')
@require_auth
def get_summary():
    """
    Get lightweight inventory summary (counts and distributions only).

    Very efficient - only queries aggregate counts, not full records.

    Returns:
        JSON with statistics and distributions
    """
    try:
        service = get_merge_service()
        summary = service.get_inventory_summary()
        return jsonify(summary)
    except Exception as e:
        logger.error(f"Error getting summary: {e}")
        return jsonify({'error': str(e)}), 500


@merge_bp.route('/merged')
@require_auth
def get_merged_inventory():
    """
    Get paginated merged inventory view.

    Query Parameters:
        - page: Page number (default: 1)
        - page_size: Records per page (default: 100, max: 500)
        - filter: 'all', 'unified', 'main_only', 'discovery_only'

    Returns:
        JSON with paginated items and metadata
    """
    try:
        page = request.args.get('page', 1, type=int)
        page_size = min(request.args.get('page_size', 100, type=int), 500)
        filter_type = request.args.get('filter', 'all')

        if filter_type not in ('all', 'unified', 'main_only', 'discovery_only'):
            return jsonify({'error': f'Invalid filter: {filter_type}'}), 400

        service = get_merge_service()
        result = service.get_merged_inventory_paginated(
            page=page,
            page_size=page_size,
            filter_type=filter_type
        )

        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting merged inventory: {e}")
        return jsonify({'error': str(e)}), 500


@merge_bp.route('/servers')
@require_auth
def get_servers():
    """
    Get paginated servers from main database.

    Query Parameters:
        - page: Page number (default: 1)
        - page_size: Records per page (default: 100, max: 500)
        - search: Optional hostname/name search

    Returns:
        JSON with paginated servers
    """
    try:
        page = request.args.get('page', 1, type=int)
        page_size = min(request.args.get('page_size', 100, type=int), 500)
        search = request.args.get('search')

        service = get_merge_service()
        result = service.get_main_servers_paginated(
            page=page,
            page_size=page_size,
            search=search
        )

        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting servers: {e}")
        return jsonify({'error': str(e)}), 500


@merge_bp.route('/servers/<int:server_id>')
@require_auth
def get_server_detail(server_id: int):
    """
    Get single server with asset-discovery enrichment.

    Efficient single-record query with optional enrichment data.

    Args:
        server_id: ID of server in main database

    Returns:
        JSON with server and enrichment data
    """
    try:
        service = get_merge_service()
        server = service.get_enriched_server(server_id)

        if server is None:
            return jsonify({'error': 'Server not found'}), 404

        return jsonify(server)
    except Exception as e:
        logger.error(f"Error getting server {server_id}: {e}")
        return jsonify({'error': str(e)}), 500


@merge_bp.route('/assets')
@require_auth
def get_assets():
    """
    Get paginated assets from asset-discovery database.

    Query Parameters:
        - page: Page number (default: 1)
        - page_size: Records per page (default: 100, max: 500)
        - search: Optional hostname search
        - status: Filter by status (active, offline, decommissioned)
        - os_type: Filter by OS type (windows, linux, macos)

    Returns:
        JSON with paginated assets
    """
    try:
        page = request.args.get('page', 1, type=int)
        page_size = min(request.args.get('page_size', 100, type=int), 500)
        search = request.args.get('search')
        status = request.args.get('status')
        os_type = request.args.get('os_type')

        service = get_merge_service()
        result = service.get_discovered_assets_paginated(
            page=page,
            page_size=page_size,
            search=search,
            status=status,
            os_type=os_type
        )

        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting assets: {e}")
        return jsonify({'error': str(e)}), 500


@merge_bp.route('/cache/clear', methods=['POST'])
@require_auth
def clear_cache():
    """
    Clear the query cache.

    Useful after data changes to ensure fresh results.

    Query Parameters:
        - pattern: Optional prefix pattern to clear specific entries

    Returns:
        JSON with confirmation
    """
    try:
        pattern = request.args.get('pattern')

        service = get_merge_service()
        service.invalidate_cache(pattern)

        return jsonify({
            'success': True,
            'message': f'Cache cleared{" (pattern: " + pattern + ")" if pattern else ""}'
        })
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        return jsonify({'error': str(e)}), 500
