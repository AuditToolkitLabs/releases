"""
Multi-Factor Authentication (MFA) Routes

Provides TOTP-based MFA endpoints:
- GET/POST /auth/mfa/setup - MFA enrollment with QR code
- GET/POST /auth/mfa/verify - MFA challenge during login
- POST /auth/mfa/disable - Disable MFA (requires password)
- GET /auth/mfa/backup-codes - Generate new backup codes
- POST /auth/mfa/recovery - Use backup code for login

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
from datetime import datetime
from functools import wraps

from flask import (
    Blueprint,
    current_app,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_login import current_user, login_required, login_user

logger = logging.getLogger(__name__)

# MFA support
try:
    from auth.mfa import (
        MFAManager,
        MFAError,
        MFASetupError,
        MFAVerificationError,
        MFAEncryptionError,
        get_mfa_manager,
        mfa_available,
        qr_code_available,
    )

    MFA_AVAILABLE = True
except ImportError:
    MFA_AVAILABLE = False
    get_mfa_manager = lambda: None
    mfa_available = lambda: False

# Blueprint
mfa_bp = Blueprint("mfa", __name__, url_prefix="/auth/mfa")


# =============================================================================
# Session Keys
# =============================================================================
MFA_PENDING_KEY = "mfa_pending_user_id"
MFA_SETUP_SECRET_KEY = "mfa_setup_secret"  # nosec B105
MFA_FAILED_ATTEMPTS_KEY = "mfa_failed_attempts"


# =============================================================================
# Helper Functions
# =============================================================================


def _get_db():
    """Get database session from Flask g object"""
    from flask import g

    return g.db


def _get_user_by_id(user_id: int):
    """Get user by ID"""
    from models.user import User

    db = _get_db()
    return db.query(User).filter(User.id == user_id).first()


def _log_mfa_event(user_id: int, event_type: str, details: dict = None):
    """Log MFA event to audit log"""
    try:
        from models.user import AuthAuditLog

        db = _get_db()
        log = AuthAuditLog(
            user_id=user_id,
            event_type=event_type,
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string[:500] if request.user_agent else None,
            details=details,
            timestamp=datetime.utcnow(),
        )
        db.add(log)
        db.commit()
    except Exception as e:
        logger.warning(f"Failed to log MFA event: {e}")


def mfa_pending_required(f):
    """
    Decorator to require MFA pending session.
    Used for MFA verification endpoints during login.
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get(MFA_PENDING_KEY)
        if not user_id:
            # No pending MFA - redirect to login
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)

    return decorated_function


# =============================================================================
# MFA Setup Routes
# =============================================================================


@mfa_bp.route("/setup", methods=["GET"])
@login_required
def setup_page():
    """
    Display MFA setup page with QR code.

    Shows QR code for authenticator app enrollment.
    """
    if not MFA_AVAILABLE:
        if request.is_json:
            return jsonify({"success": False, "error": "MFA not available"}), 400
        return render_template("auth/mfa_unavailable.html")

    mfa = get_mfa_manager()
    if not mfa:
        if request.is_json:
            return jsonify({"success": False, "error": "MFA not configured"}), 400
        return render_template("auth/mfa_unavailable.html")

    # Check if already enrolled
    if current_user.mfa_enabled:
        if request.is_json:
            return jsonify({
                "success": False,
                "error": "MFA already enabled",
                "enrolled_at": current_user.mfa_enrolled_at.isoformat()
                if current_user.mfa_enrolled_at
                else None,
            }), 400
        return redirect(url_for("dashboard.index"))

    # Generate new secret for setup
    secret = mfa.generate_secret()
    session[MFA_SETUP_SECRET_KEY] = secret

    # Generate QR code
    try:
        qr_code = mfa.generate_qr_code(secret, current_user.email or current_user.username)
        manual_code = secret  # For manual entry
    except MFASetupError as e:
        logger.error(f"QR code generation failed: {e}")
        qr_code = None
        manual_code = secret

    if request.is_json:
        return jsonify({
            "success": True,
            "qr_code": qr_code,
            "manual_code": manual_code,
            "issuer": mfa.config.issuer,
        })

    return render_template(
        "auth/mfa_setup.html",
        qr_code=qr_code,
        manual_code=manual_code,
        issuer=mfa.config.issuer,
    )


@mfa_bp.route("/setup", methods=["POST"])
@login_required
def setup_confirm():
    """
    Confirm MFA setup by verifying initial code.

    Validates that user can generate correct codes before enabling MFA.
    """
    if not MFA_AVAILABLE:
        return jsonify({"success": False, "error": "MFA not available"}), 400

    mfa = get_mfa_manager()
    if not mfa:
        return jsonify({"success": False, "error": "MFA not configured"}), 400

    # Get the setup secret from session
    secret = session.get(MFA_SETUP_SECRET_KEY)
    if not secret:
        return jsonify({
            "success": False,
            "error": "MFA setup session expired. Please start again.",
        }), 400

    # Get verification code from request
    data = request.get_json() if request.is_json else request.form
    code = data.get("code", "").strip()

    if not code:
        return jsonify({"success": False, "error": "Verification code required"}), 400

    # Verify the code
    if not mfa.verify_code(secret, code):
        return jsonify({
            "success": False,
            "error": "Invalid verification code. Please check your authenticator app.",
        }), 400

    # Code is valid - enable MFA
    try:
        db = _get_db()
        user = _get_user_by_id(current_user.id)

        # Encrypt and store secret
        encrypted_secret = mfa.encrypt_secret(secret)
        user.mfa_secret = encrypted_secret
        user.mfa_enabled = True
        user.mfa_enrolled_at = datetime.utcnow()

        # Generate backup codes
        backup_codes = mfa.generate_backup_codes()
        hashed_codes = mfa.hash_backup_codes(backup_codes)
        encrypted_codes = mfa.encrypt_backup_codes(hashed_codes)
        user.mfa_backup_codes = encrypted_codes

        db.commit()

        # Clear setup secret from session
        session.pop(MFA_SETUP_SECRET_KEY, None)

        # Log event
        _log_mfa_event(user.id, "mfa_enabled", {"method": "totp"})

        logger.info(f"MFA enabled for user {user.username}")

        if request.is_json:
            return jsonify({
                "success": True,
                "message": "MFA enabled successfully",
                "backup_codes": backup_codes,  # Show once only
            })

        return render_template("auth/mfa_setup_complete.html", backup_codes=backup_codes)

    except MFAEncryptionError as e:
        logger.error(f"MFA encryption error: {e}")
        return jsonify({"success": False, "error": "Encryption error"}), 500
    except Exception as e:
        logger.exception(f"MFA setup error: {e}")
        return jsonify({"success": False, "error": "Failed to enable MFA"}), 500


# =============================================================================
# MFA Verification Routes
# =============================================================================


@mfa_bp.route("/verify", methods=["GET"])
@mfa_pending_required
def verify_page():
    """
    Display MFA verification challenge page.

    Shown after successful password authentication for MFA-enabled users.
    """
    if request.is_json:
        return jsonify({"success": True, "mfa_required": True})

    return render_template("auth/mfa_verify.html")


@mfa_bp.route("/verify", methods=["POST"])
@mfa_pending_required
def verify_code():
    """
    Verify MFA code during login.

    Validates TOTP code and completes login if valid.
    """
    if not MFA_AVAILABLE:
        return jsonify({"success": False, "error": "MFA not available"}), 400

    mfa = get_mfa_manager()
    if not mfa:
        return jsonify({"success": False, "error": "MFA not configured"}), 400

    # Get pending user
    user_id = session.get(MFA_PENDING_KEY)
    user = _get_user_by_id(user_id)
    if not user:
        session.pop(MFA_PENDING_KEY, None)
        return jsonify({"success": False, "error": "Session expired"}), 400

    # Check failed attempts
    failed_attempts = session.get(MFA_FAILED_ATTEMPTS_KEY, 0)
    if failed_attempts >= mfa.config.max_failed_attempts:
        session.pop(MFA_PENDING_KEY, None)
        session.pop(MFA_FAILED_ATTEMPTS_KEY, None)
        _log_mfa_event(user.id, "mfa_lockout", {"attempts": failed_attempts})
        return jsonify({
            "success": False,
            "error": "Too many failed attempts. Please login again.",
        }), 429

    # Get code from request
    data = request.get_json() if request.is_json else request.form
    code = data.get("code", "").strip()

    if not code:
        return jsonify({"success": False, "error": "Verification code required"}), 400

    # Decrypt user's secret
    try:
        secret = mfa.decrypt_secret(user.mfa_secret)
    except MFAEncryptionError as e:
        logger.error(f"Failed to decrypt MFA secret for user {user.id}: {e}")
        return jsonify({"success": False, "error": "MFA configuration error"}), 500

    # Verify the code
    if not mfa.verify_code(secret, code):
        # Track failed attempt
        session[MFA_FAILED_ATTEMPTS_KEY] = failed_attempts + 1
        _log_mfa_event(user.id, "mfa_failed", {"attempts": failed_attempts + 1})

        remaining = mfa.config.max_failed_attempts - (failed_attempts + 1)
        if remaining > 0:
            return jsonify({
                "success": False,
                "error": f"Invalid code. {remaining} attempts remaining.",
            }), 400
        else:
            session.pop(MFA_PENDING_KEY, None)
            session.pop(MFA_FAILED_ATTEMPTS_KEY, None)
            return jsonify({
                "success": False,
                "error": "Too many failed attempts. Please login again.",
            }), 429

    # Code is valid - complete login
    db = _get_db()
    user.mfa_last_used_at = datetime.utcnow()
    db.commit()

    # Clear MFA session state
    session.pop(MFA_PENDING_KEY, None)
    session.pop(MFA_FAILED_ATTEMPTS_KEY, None)

    # Log the user in
    login_user(user, remember=False)
    _log_mfa_event(user.id, "mfa_verified", {"method": "totp"})

    logger.info(f"MFA verification successful for user {user.username}")

    if request.is_json:
        return jsonify({
            "success": True,
            "message": "MFA verification successful",
            "redirect": url_for("dashboard.index"),
        })

    # Redirect to dashboard
    next_url = session.pop("next", None) or url_for("dashboard.index")
    return redirect(next_url)


# =============================================================================
# Backup Code Recovery
# =============================================================================


@mfa_bp.route("/recovery", methods=["GET"])
@mfa_pending_required
def recovery_page():
    """Display backup code recovery page."""
    if request.is_json:
        return jsonify({"success": True, "recovery_required": True})

    return render_template("auth/mfa_recovery.html")


@mfa_bp.route("/recovery", methods=["POST"])
@mfa_pending_required
def recovery_verify():
    """
    Verify backup code during login.

    Validates backup code and completes login if valid.
    Each backup code can only be used once.
    """
    if not MFA_AVAILABLE:
        return jsonify({"success": False, "error": "MFA not available"}), 400

    mfa = get_mfa_manager()
    if not mfa:
        return jsonify({"success": False, "error": "MFA not configured"}), 400

    # Get pending user
    user_id = session.get(MFA_PENDING_KEY)
    user = _get_user_by_id(user_id)
    if not user:
        session.pop(MFA_PENDING_KEY, None)
        return jsonify({"success": False, "error": "Session expired"}), 400

    # Get code from request
    data = request.get_json() if request.is_json else request.form
    code = data.get("code", "").strip()

    if not code:
        return jsonify({"success": False, "error": "Backup code required"}), 400

    # Decrypt backup codes
    try:
        if not user.mfa_backup_codes:
            return jsonify({"success": False, "error": "No backup codes available"}), 400

        stored_codes = mfa.decrypt_backup_codes(user.mfa_backup_codes)
    except MFAEncryptionError as e:
        logger.error(f"Failed to decrypt backup codes for user {user.id}: {e}")
        return jsonify({"success": False, "error": "Configuration error"}), 500

    # Verify the backup code
    is_valid, code_index = mfa.verify_backup_code(stored_codes, code)

    if not is_valid:
        _log_mfa_event(user.id, "mfa_recovery_failed")
        return jsonify({"success": False, "error": "Invalid backup code"}), 400

    # Remove used backup code
    db = _get_db()
    stored_codes.pop(code_index)
    user.mfa_backup_codes = mfa.encrypt_backup_codes(stored_codes)
    user.mfa_last_used_at = datetime.utcnow()
    db.commit()

    # Clear MFA session state
    session.pop(MFA_PENDING_KEY, None)
    session.pop(MFA_FAILED_ATTEMPTS_KEY, None)

    # Log the user in
    login_user(user, remember=False)
    _log_mfa_event(user.id, "mfa_verified", {"method": "backup_code"})

    logger.info(f"MFA recovery successful for user {user.username}")

    remaining_codes = len(stored_codes)

    if request.is_json:
        return jsonify({
            "success": True,
            "message": "Recovery successful",
            "remaining_backup_codes": remaining_codes,
            "redirect": url_for("dashboard.index"),
        })

    # Redirect with warning about remaining codes
    if remaining_codes <= 3:
        session["mfa_warning"] = f"Only {remaining_codes} backup codes remaining"

    next_url = session.pop("next", None) or url_for("dashboard.index")
    return redirect(next_url)


# =============================================================================
# MFA Management Routes
# =============================================================================


@mfa_bp.route("/disable", methods=["POST"])
@login_required
def disable_mfa():
    """
    Disable MFA for current user.

    Requires password confirmation for security.
    """
    if not current_user.mfa_enabled:
        return jsonify({"success": False, "error": "MFA is not enabled"}), 400

    # Get password from request
    data = request.get_json() if request.is_json else request.form
    password = data.get("password", "")

    if not password:
        return jsonify({"success": False, "error": "Password required"}), 400

    # Verify password
    if not current_user.check_password(password):
        _log_mfa_event(current_user.id, "mfa_disable_failed", {"reason": "invalid_password"})
        return jsonify({"success": False, "error": "Invalid password"}), 400

    # Disable MFA
    db = _get_db()
    user = _get_user_by_id(current_user.id)
    user.mfa_enabled = False
    user.mfa_secret = None
    user.mfa_backup_codes = None
    db.commit()

    _log_mfa_event(user.id, "mfa_disabled")

    logger.info(f"MFA disabled for user {user.username}")

    return jsonify({"success": True, "message": "MFA disabled successfully"})


@mfa_bp.route("/backup-codes", methods=["GET"])
@login_required
def get_backup_codes():
    """
    Generate new backup codes.

    Replaces existing backup codes. Requires MFA to be enabled.
    """
    if not current_user.mfa_enabled:
        return jsonify({"success": False, "error": "MFA is not enabled"}), 400

    if not MFA_AVAILABLE:
        return jsonify({"success": False, "error": "MFA not available"}), 400

    mfa = get_mfa_manager()
    if not mfa:
        return jsonify({"success": False, "error": "MFA not configured"}), 400

    # Generate new backup codes
    backup_codes = mfa.generate_backup_codes()
    hashed_codes = mfa.hash_backup_codes(backup_codes)

    try:
        encrypted_codes = mfa.encrypt_backup_codes(hashed_codes)

        db = _get_db()
        user = _get_user_by_id(current_user.id)
        user.mfa_backup_codes = encrypted_codes
        db.commit()

        _log_mfa_event(user.id, "mfa_backup_codes_regenerated")

        logger.info(f"Backup codes regenerated for user {user.username}")

        return jsonify({
            "success": True,
            "backup_codes": backup_codes,
            "message": "New backup codes generated. Store these securely.",
        })

    except MFAEncryptionError as e:
        logger.error(f"Failed to encrypt backup codes: {e}")
        return jsonify({"success": False, "error": "Encryption error"}), 500


@mfa_bp.route("/status", methods=["GET"])
@login_required
def get_mfa_status():
    """
    Get MFA status for current user.
    """
    mfa = get_mfa_manager()

    # Count remaining backup codes
    remaining_codes = 0
    if current_user.mfa_enabled and current_user.mfa_backup_codes and mfa:
        try:
            stored_codes = mfa.decrypt_backup_codes(current_user.mfa_backup_codes)
            remaining_codes = len(stored_codes)
        except Exception as e:
            logger.debug(f"Failed to decrypt backup codes: {e}")

    return jsonify({
        "mfa_available": MFA_AVAILABLE,
        "mfa_enabled": current_user.mfa_enabled,
        "enrolled_at": current_user.mfa_enrolled_at.isoformat()
        if current_user.mfa_enrolled_at
        else None,
        "last_used": current_user.mfa_last_used_at.isoformat()
        if current_user.mfa_last_used_at
        else None,
        "remaining_backup_codes": remaining_codes,
    })
