from flask import Blueprint, jsonify, request, Response
from threading import Thread, Lock
import time
import os
import json
import uuid
from datetime import datetime
from collections import OrderedDict
from config import logger
from config import ROOT_DIR
from auth_core import require_auth

monitoring_bp = Blueprint('monitoring', __name__)

# Monitoring state
MONITORING_CONFIG = {
    'enabled': False,
    'interval': 300,  # seconds
    'plan': None,
    'last_run': None,
    'thread': None
}

# ============================================
# Bounded Data Structures (CRITICAL-04 fix)
# ============================================

# Configuration limits to prevent unbounded memory growth
MAX_ACTIVE_JOBS = 1000
MAX_QUEUE_SIZE = 500
MAX_COMPLETIONS = 50
JOB_EXPIRY_SECONDS = 3600  # 1 hour


class BoundedJobRegistry:
    """
    Thread-safe bounded registry for tracking jobs
    Automatically evicts old entries to prevent memory leaks
    """

    def __init__(self, max_size: int = 1000, expiry_seconds: int = 3600):
        self.jobs = OrderedDict()
        self.max_size = max_size
        self.expiry_seconds = expiry_seconds
        self._lock = Lock()

    def add(self, job_id: str, job: dict) -> None:
        """Add job with automatic eviction of old entries"""
        with self._lock:
            self._evict_expired()
            if len(self.jobs) >= self.max_size:
                # Remove oldest entry
                self.jobs.popitem(last=False)
                logger.warning("Job registry at capacity, evicted oldest job")
            job['_created'] = time.time()
            self.jobs[job_id] = job

    def get(self, job_id: str) -> dict:
        """Get job by ID"""
        with self._lock:
            return self.jobs.get(job_id)

    def remove(self, job_id: str) -> dict:
        """Remove and return job"""
        with self._lock:
            return self.jobs.pop(job_id, None)

    def values(self) -> list:
        """Get all jobs as list"""
        with self._lock:
            self._evict_expired()
            return list(self.jobs.values())

    def __contains__(self, job_id: str) -> bool:
        with self._lock:
            return job_id in self.jobs

    def __len__(self) -> int:
        with self._lock:
            return len(self.jobs)

    def _evict_expired(self) -> None:
        """Remove expired entries (called within lock)"""
        now = time.time()
        expired = [
            k for k, v in self.jobs.items()
            if now - v.get('_created', 0) > self.expiry_seconds
        ]
        for k in expired:
            del self.jobs[k]
        if expired:
            logger.debug(f"Evicted {len(expired)} expired jobs")


class BoundedQueue:
    """Thread-safe bounded queue for job queue"""

    def __init__(self, max_size: int = 500):
        self.items = []
        self.max_size = max_size
        self._lock = Lock()

    def append(self, item: dict) -> bool:
        """Add item, returns False if queue is full"""
        with self._lock:
            if len(self.items) >= self.max_size:
                logger.warning(f"Job queue at capacity ({self.max_size})")
                return False
            self.items.append(item)
            return True

    def pop(self, index: int = -1) -> dict:
        """Remove and return item"""
        with self._lock:
            if 0 <= index < len(self.items) or index == -1:
                return self.items.pop(index)
            return None

    def get_all(self) -> list:
        """Get copy of all items"""
        with self._lock:
            return list(self.items)

    def find_and_remove(self, job_id: str) -> dict:
        """Find job by ID and remove it"""
        with self._lock:
            for i, job in enumerate(self.items):
                if job.get('id') == job_id:
                    return self.items.pop(i)
            return None

    def __len__(self) -> int:
        with self._lock:
            return len(self.items)


class BoundedCompletions:
    """Thread-safe bounded list for completed jobs"""

    def __init__(self, max_size: int = 50):
        self.items = []
        self.max_size = max_size
        self._lock = Lock()

    def add(self, item: dict) -> None:
        """Add completion, evicting oldest if at capacity"""
        with self._lock:
            self.items.insert(0, item)
            while len(self.items) > self.max_size:
                self.items.pop()

    def find(self, job_id: str) -> dict:
        """Find completed job by ID"""
        with self._lock:
            for item in self.items:
                if item.get('id') == job_id:
                    return item
            return None

    def get_all(self) -> list:
        """Get copy of all completions"""
        with self._lock:
            return list(self.items)


# Initialize bounded data structures
ACTIVE_JOBS = BoundedJobRegistry(max_size=MAX_ACTIVE_JOBS, expiry_seconds=JOB_EXPIRY_SECONDS)
JOB_QUEUE = BoundedQueue(max_size=MAX_QUEUE_SIZE)
COMPLETIONS = BoundedCompletions(max_size=MAX_COMPLETIONS)

# SSE clients with thread safety
_sse_lock = Lock()
SSE_CLIENTS = []

# Dummy function to simulate audit execution
def run_monitoring_audits():
    """
    Real-time monitoring loop that executes audits at configured intervals.
    Uses the configured plan to run audits on relevant servers.
    """
    while MONITORING_CONFIG['enabled']:
        try:
            plan_name = MONITORING_CONFIG.get('plan')
            if not plan_name:
                logger.debug('No monitoring plan configured, skipping execution')
                time.sleep(MONITORING_CONFIG['interval'])
                continue

            logger.info(f'Running real-time monitoring audits for plan: {plan_name}')
            MONITORING_CONFIG['last_run'] = time.strftime('%Y-%m-%d %H:%M:%S')

            # Import here to avoid circular dependencies
            from models.server import ServerManager
            from models.plan import PlanManager

            # Load the plan
            plan_manager = PlanManager()
            plan = plan_manager.get_plan(plan_name)

            if not plan:
                logger.warning(f'Monitoring plan "{plan_name}" not found')
                time.sleep(MONITORING_CONFIG['interval'])
                continue

            # Get servers for this plan
            server_manager = ServerManager(use_database=False)
            servers = server_manager.load_servers()

            # Filter servers if plan has specific server targeting
            target_servers = servers
            if plan.get('servers'):
                target_server_ids = set(str(s) for s in plan['servers'])
                target_servers = [s for s in servers if str(s.get('id')) in target_server_ids]
            elif plan.get('os_type'):
                target_servers = [s for s in servers if s.get('os_type') == plan['os_type']]

            if not target_servers:
                logger.info('No servers match the monitoring plan criteria')
                time.sleep(MONITORING_CONFIG['interval'])
                continue

            # Run audits on each server
            for server in target_servers:
                if not MONITORING_CONFIG['enabled']:
                    break  # Check if stopped during execution

                server_id = server.get('id')
                server_name = server.get('name', f'Server {server_id}')

                # Create job for this server
                job_id = str(uuid.uuid4())
                categories = plan.get('categories', ['platform', 'network', 'web', 'data'])

                job = {
                    'id': job_id,
                    'name': f"Monitoring Audit - {server_name}",
                    'type': 'monitoring',
                    'serverId': str(server_id),
                    'server': server_name,
                    'categories': categories,
                    'status': 'running',
                    'progress': 0,
                    'passCount': 0,
                    'warnCount': 0,
                    'failCount': 0,
                    'skipCount': 0,
                    'startedAt': datetime.now().isoformat(),
                    'output': f"Starting monitoring audit on {server_name}...\n"
                }

                ACTIVE_JOBS[job_id] = job
                broadcast_sse({'type': 'job_started', 'name': job['name'], 'id': job_id, 'server': server_name})
                logger.info(f"Started monitoring audit job {job_id} on server {server_id}")

                # Run the audit (using simulated execution for now)
                # In production, this would be replaced with actual audit runner
                simulate_audit_execution(job_id)

            logger.info('Monitoring cycle complete')

        except Exception as e:
            logger.error(f'Error in monitoring audit loop: {e}')

        time.sleep(MONITORING_CONFIG['interval'])

@monitoring_bp.route('/api/monitoring/start', methods=['POST'])
@require_auth
def start_monitoring():
    if MONITORING_CONFIG['enabled']:
        return jsonify({'success': False, 'error': 'Monitoring already running'})
    MONITORING_CONFIG['enabled'] = True
    MONITORING_CONFIG['thread'] = Thread(target=run_monitoring_audits, daemon=True)
    MONITORING_CONFIG['thread'].start()
    logger.info('Started real-time monitoring')
    return jsonify({'success': True, 'message': 'Monitoring started'})

@monitoring_bp.route('/api/monitoring/stop', methods=['POST'])
@require_auth
def stop_monitoring():
    MONITORING_CONFIG['enabled'] = False
    logger.info('Stopped real-time monitoring')
    return jsonify({'success': True, 'message': 'Monitoring stopped'})

@monitoring_bp.route('/api/monitoring/status', methods=['GET'])
@require_auth
def monitoring_status():
    return jsonify({
        'enabled': MONITORING_CONFIG['enabled'],
        'interval': MONITORING_CONFIG['interval'],
        'plan': MONITORING_CONFIG['plan'],
        'last_run': MONITORING_CONFIG['last_run']
    })

@monitoring_bp.route('/api/monitoring/config', methods=['POST'])
@require_auth
def update_monitoring_config():
    data = request.json or {}
    MONITORING_CONFIG['interval'] = int(data.get('interval', 300))
    MONITORING_CONFIG['plan'] = data.get('plan')
    logger.info(f"Updated monitoring config: {MONITORING_CONFIG}")
    return jsonify({'success': True, 'config': MONITORING_CONFIG})


# ============================================
# Active Jobs API
# ============================================

@monitoring_bp.route('/api/monitoring/active-jobs', methods=['GET'])
@require_auth
def get_active_jobs():
    """Get list of currently running jobs"""
    jobs = ACTIVE_JOBS.values()
    return jsonify(jobs)


@monitoring_bp.route('/api/monitoring/jobs/<job_id>', methods=['GET'])
@require_auth
def get_job_details(job_id):
    """Get details of a specific job"""
    job = ACTIVE_JOBS.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(job)


@monitoring_bp.route('/api/monitoring/jobs/<job_id>/cancel', methods=['POST'])
@require_auth
def cancel_job(job_id):
    """Cancel a running job"""
    job = ACTIVE_JOBS.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404

    job['status'] = 'cancelled'
    job['cancelledAt'] = datetime.now().isoformat()

    # Move to completions
    job = ACTIVE_JOBS.remove(job_id)
    job['completedAt'] = datetime.now().isoformat()
    COMPLETIONS.add(job)

    broadcast_sse({'type': 'job_cancelled', 'jobId': job_id})
    logger.info(f"Job {job_id} cancelled")
    return jsonify({'success': True, 'message': 'Job cancelled'})


@monitoring_bp.route('/api/monitoring/jobs/<job_id>/output', methods=['GET'])
@require_auth
def get_job_output(job_id):
    """Get output of a running or completed job"""
    job = ACTIVE_JOBS.get(job_id)
    if not job:
        # Check completions
        job = COMPLETIONS.find(job_id)

    if not job:
        return jsonify({'error': 'Job not found'}), 404

    return jsonify({
        'jobId': job_id,
        'status': job.get('status', 'unknown'),
        'output': job.get('output', ''),
        'stats': {
            'pass': job.get('passCount', 0),
            'warn': job.get('warnCount', 0),
            'fail': job.get('failCount', 0),
            'skip': job.get('skipCount', 0)
        }
    })


# ============================================
# Job Queue API
# ============================================

@monitoring_bp.route('/api/monitoring/queue', methods=['GET'])
@require_auth
def get_job_queue():
    """Get list of queued jobs waiting to run"""
    return jsonify(JOB_QUEUE.get_all())


@monitoring_bp.route('/api/monitoring/queue', methods=['POST'])
@require_auth
def add_to_queue():
    """Add a job to the queue"""
    data = request.json or {}

    job = {
        'id': str(uuid.uuid4()),
        'name': data.get('name', 'Unnamed Job'),
        'type': data.get('type', 'audit'),
        'serverId': data.get('serverId'),
        'server': data.get('server'),
        'scheduledAt': data.get('scheduledAt', datetime.now().isoformat()),
        'config': data.get('config', {}),
        'addedAt': datetime.now().isoformat()
    }

    if not JOB_QUEUE.append(job):
        return jsonify({'error': 'Queue is full', 'max_size': MAX_QUEUE_SIZE}), 503

    broadcast_sse({'type': 'queue_updated', 'action': 'added', 'job': job})
    logger.info(f"Added job {job['id']} to queue")
    return jsonify({'success': True, 'job': job})


@monitoring_bp.route('/api/monitoring/queue/<job_id>/run', methods=['POST'])
@require_auth
def run_queued_job(job_id):
    """Run a queued job immediately"""
    job = JOB_QUEUE.find_and_remove(job_id)

    if not job:
        return jsonify({'error': 'Job not found in queue'}), 404

    # Create active job
    active_job = {
        'id': job['id'],
        'name': job['name'],
        'type': job.get('type', 'audit'),
        'serverId': job.get('serverId'),
        'server': job.get('server'),
        'status': 'running',
        'progress': 0,
        'passCount': 0,
        'warnCount': 0,
        'failCount': 0,
        'skipCount': 0,
        'startedAt': datetime.now().isoformat(),
        'output': ''
    }

    ACTIVE_JOBS.add(job_id, active_job)
    broadcast_sse({'type': 'job_started', 'name': job['name'], 'id': job_id})
    logger.info(f"Started queued job {job_id}")
    return jsonify({'success': True, 'jobId': job_id})


@monitoring_bp.route('/api/monitoring/queue/<job_id>', methods=['DELETE'])
@require_auth
def remove_from_queue(job_id):
    """Remove a job from the queue"""
    job = JOB_QUEUE.find_and_remove(job_id)
    if job:
        broadcast_sse({'type': 'queue_updated', 'action': 'removed', 'jobId': job_id})
        logger.info(f"Removed job {job_id} from queue")
        return jsonify({'success': True})

    return jsonify({'error': 'Job not found in queue'}), 404


# ============================================
# Completions API
# ============================================

@monitoring_bp.route('/api/monitoring/completions', methods=['GET'])
@require_auth
def get_completions():
    """Get list of recently completed jobs"""
    limit = request.args.get('limit', 10, type=int)
    completions = COMPLETIONS.get_all()
    return jsonify(completions[:limit])


@monitoring_bp.route('/api/monitoring/completions/<job_id>', methods=['GET'])
@require_auth
def get_completion_details(job_id):
    """Get details of a completed job"""
    job = COMPLETIONS.find(job_id)
    if job:
        return jsonify(job)
    return jsonify({'error': 'Completion not found'}), 404


# ============================================
# Job Management Functions
# ============================================

def create_job(name, job_type='audit', server_id=None, server_name=None, config=None):
    """Create and start a new job"""
    job_id = str(uuid.uuid4())
    job = {
        'id': job_id,
        'name': name,
        'type': job_type,
        'serverId': server_id,
        'server': server_name,
        'status': 'running',
        'progress': 0,
        'passCount': 0,
        'warnCount': 0,
        'failCount': 0,
        'skipCount': 0,
        'startedAt': datetime.now().isoformat(),
        'output': '',
        'config': config or {}
    }
    ACTIVE_JOBS.add(job_id, job)
    broadcast_sse({'type': 'job_started', 'name': name, 'id': job_id})
    return job_id


def update_job_progress(job_id, progress=None, output=None, stats=None):
    """Update progress of a running job"""
    job = ACTIVE_JOBS.get(job_id)
    if not job:
        return False

    if progress is not None:
        job['progress'] = progress

    if output:
        job['output'] += output + '\n'

    if stats:
        job['passCount'] = stats.get('pass', job['passCount'])
        job['warnCount'] = stats.get('warn', job['warnCount'])
        job['failCount'] = stats.get('fail', job['failCount'])
        job['skipCount'] = stats.get('skip', job['skipCount'])

    broadcast_sse({
        'type': 'job_progress',
        'jobId': job_id,
        'progress': job['progress'],
        'passCount': job['passCount'],
        'warnCount': job['warnCount'],
        'failCount': job['failCount']
    })
    return True


def complete_job(job_id, status='success'):
    """Mark a job as completed"""
    job = ACTIVE_JOBS.remove(job_id)
    if not job:
        return False

    job['status'] = status
    job['completedAt'] = datetime.now().isoformat()

    # Calculate duration
    started = datetime.fromisoformat(job['startedAt'])
    ended = datetime.now()
    duration = (ended - started).total_seconds()
    job['duration'] = f"{int(duration)}s" if duration < 60 else f"{int(duration//60)}m {int(duration%60)}s"

    COMPLETIONS.add(job)

    broadcast_sse({'type': 'job_completed', 'name': job['name'], 'id': job_id, 'status': status})
    return True


# ============================================
# SSE Streaming
# ============================================

def broadcast_sse(data):
    """Broadcast event to all SSE clients (thread-safe)"""
    message = f"data: {json.dumps(data)}\n\n"
    dead_clients = []

    with _sse_lock:
        clients_copy = list(SSE_CLIENTS)

    for client in clients_copy:
        try:
            client['queue'].append(message)
        except Exception:
            dead_clients.append(client)

    if dead_clients:
        with _sse_lock:
            for client in dead_clients:
                if client in SSE_CLIENTS:
                    SSE_CLIENTS.remove(client)


def sse_stream():
    """Generator for SSE stream"""
    client = {'queue': []}
    with _sse_lock:
        SSE_CLIENTS.append(client)

    try:
        # Send initial ping
        yield f"data: {json.dumps({'type': 'connected'})}\n\n"

        while True:
            # Check for messages
            while client['queue']:
                yield client['queue'].pop(0)

            # Keep-alive ping every 30 seconds
            yield ": keepalive\n\n"
            time.sleep(1)

    except GeneratorExit:
        with _sse_lock:
            if client in SSE_CLIENTS:
                SSE_CLIENTS.remove(client)


@monitoring_bp.route('/api/monitoring/stream')
@require_auth
def stream():
    """SSE endpoint for real-time updates"""
    return Response(
        sse_stream(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    )


# ============================================
# Audit Execution API
# ============================================

@monitoring_bp.route('/api/audit/run', methods=['POST'])
@require_auth
def run_audit():
    """
    Start an audit on a specific server

    Request body:
    {
        "serverId": "1",
        "categories": ["platform", "network"],  // optional, all if not specified
        "priority": "normal"  // optional: low, normal, high
    }
    """
    data = request.json or {}
    server_id = data.get('serverId')

    if not server_id:
        return jsonify({'success': False, 'error': 'serverId required'}), 400

    # Get server details
    server_name = f"Server {server_id}"

    # Try to load server from manager
    try:
        from models.server import ServerManager
        manager = ServerManager(use_database=False)
        servers = manager.load_servers()
        for s in servers:
            if str(s.get('id')) == str(server_id):
                server_name = s.get('name', server_name)
                break
    except Exception as e:
        logger.warning(f"Could not load server details: {e}")

    # Create job
    job_id = str(uuid.uuid4())
    categories = data.get('categories', ['platform', 'network', 'web', 'data'])

    job = {
        'id': job_id,
        'name': f"Security Audit - {server_name}",
        'type': 'audit',
        'serverId': server_id,
        'server': server_name,
        'categories': categories,
        'status': 'running',
        'progress': 0,
        'passCount': 0,
        'warnCount': 0,
        'failCount': 0,
        'skipCount': 0,
        'startedAt': datetime.now().isoformat(),
        'output': f"Starting audit on {server_name}...\n"
    }

    ACTIVE_JOBS[job_id] = job
    broadcast_sse({'type': 'job_started', 'name': job['name'], 'id': job_id, 'server': server_name})
    logger.info(f"Started audit job {job_id} on server {server_id}")

    # Start simulated audit in background thread
    Thread(target=simulate_audit_execution, args=(job_id,), daemon=True).start()

    return jsonify({
        'success': True,
        'jobId': job_id,
        'message': f'Audit started on {server_name}'
    })


def simulate_audit_execution(job_id):
    """
    Simulate audit execution with progress updates
    In production, this would run actual SSH commands
    """
    import random

    if job_id not in ACTIVE_JOBS:
        return

    job = ACTIVE_JOBS[job_id]
    categories = job.get('categories', ['platform', 'network', 'web', 'data'])

    audit_checks = [
        ('platform', 'System Updates', 'Checking for pending updates...'),
        ('platform', 'Kernel Version', 'Verifying kernel is up to date...'),
        ('platform', 'User Accounts', 'Auditing user account security...'),
        ('platform', 'Sudo Configuration', 'Checking sudo permissions...'),
        ('platform', 'SSH Configuration', 'Validating SSH hardening...'),
        ('network', 'Firewall Status', 'Checking firewall is active...'),
        ('network', 'Open Ports', 'Scanning for unnecessary open ports...'),
        ('network', 'Network Services', 'Auditing network service security...'),
        ('web', 'Web Server Config', 'Checking web server security settings...'),
        ('web', 'TLS Configuration', 'Validating TLS/SSL configuration...'),
        ('data', 'File Permissions', 'Checking critical file permissions...'),
        ('data', 'Backup Status', 'Verifying backup configuration...'),
    ]

    total_checks = len([c for c in audit_checks if c[0] in categories])
    completed = 0

    for category, check_name, message in audit_checks:
        if category not in categories:
            continue

        if job_id not in ACTIVE_JOBS:
            return  # Job was cancelled

        time.sleep(random.uniform(0.5, 1.5))  # Simulate check duration  # nosec B311

        # Random result
        result = random.choices(
            ['PASS', 'WARN', 'FAIL', 'SKIP'],
            weights=[60, 20, 10, 10]
        )[0]  # nosec B311

        # Update job
        job = ACTIVE_JOBS[job_id]
        completed += 1
        job['progress'] = int((completed / total_checks) * 100)

        if result == 'PASS':
            job['passCount'] += 1
            output_line = f"[PASS] {check_name}: OK"
        elif result == 'WARN':
            job['warnCount'] += 1
            output_line = f"[WARN] {check_name}: Review recommended"
        elif result == 'FAIL':
            job['failCount'] += 1
            output_line = f"[FAIL] {check_name}: Action required"
        else:
            job['skipCount'] += 1
            output_line = f"[SKIP] {check_name}: Not applicable"

        job['output'] += f"{message}\n{output_line}\n\n"

        broadcast_sse({
            'type': 'job_progress',
            'jobId': job_id,
            'progress': job['progress'],
            'output': output_line,
            'stats': {
                'pass': job['passCount'],
                'warn': job['warnCount'],
                'fail': job['failCount'],
                'skip': job['skipCount']
            }
        })

    # Complete the job
    if job_id in ACTIVE_JOBS:
        job = ACTIVE_JOBS.pop(job_id)
        job['status'] = 'completed'
        job['progress'] = 100
        job['completedAt'] = datetime.now().isoformat()
        job['output'] += f"\n{'='*50}\nAudit completed: {job['passCount']} pass, {job['warnCount']} warn, {job['failCount']} fail, {job['skipCount']} skip\n"

        # Add to completions
        COMPLETIONS.insert(0, job)
        if len(COMPLETIONS) > MAX_COMPLETIONS:
            COMPLETIONS.pop()

        broadcast_sse({
            'type': 'job_completed',
            'jobId': job_id,
            'name': job['name'],
            'stats': {
                'pass': job['passCount'],
                'warn': job['warnCount'],
                'fail': job['failCount'],
                'skip': job['skipCount']
            }
        })
        logger.info(f"Audit job {job_id} completed")
