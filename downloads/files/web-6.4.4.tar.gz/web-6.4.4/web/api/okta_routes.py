"""
Okta OIDC SSO Routes

Provides OAuth 2.0 / OIDC endpoints for Okta authentication:
- GET /auth/sso/okta/login - Initiate SSO login
- GET /auth/sso/okta/callback - OAuth callback handler
- GET /auth/sso/okta/logout - SSO logout
- GET /api/admin/sso/okta/status - Admin: Get Okta status
- POST /api/admin/sso/okta/test - Admin: Test Okta configuration

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import secrets
from datetime import datetime

from flask import (
    Blueprint,
    current_app,
    jsonify,
    redirect,
    request,
    session,
    url_for,
)
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy.orm import Session as DBSession

logger = logging.getLogger(__name__)

# Okta Authentication support
try:
    from auth.okta import (
        OktaAuth,
        OktaAuthError,
        OktaTokenError,
        OktaUserInfoError,
        OktaUser,
        get_okta_auth,
        okta_enabled,
    )

    OKTA_AVAILABLE = True
except ImportError:
    OKTA_AVAILABLE = False
    OktaAuth = None
    OktaUser = None
    OktaAuthError = None
    OktaTokenError = None
    OktaUserInfoError = None
    get_okta_auth = lambda: None
    okta_enabled = lambda: False

# Blueprints
okta_sso_bp = Blueprint("okta_sso", __name__, url_prefix="/auth/sso/okta")
okta_admin_bp = Blueprint("okta_admin", __name__, url_prefix="/api/admin/sso/okta")


# =============================================================================
# SSO Session Keys
# =============================================================================
OKTA_STATE_KEY = "okta_sso_state"
OKTA_NONCE_KEY = "okta_sso_nonce"
OKTA_NEXT_KEY = "okta_next_url"
OKTA_ID_TOKEN_KEY = "okta_id_token"  # nosec B105


# =============================================================================
# Helper Functions
# =============================================================================


def _get_db() -> DBSession:
    """Get database session from Flask g object"""
    from flask import g

    return g.db


def _is_admin() -> bool:
    """Check if current user is admin or superadmin (hierarchy-aware)"""
    if not current_user.is_authenticated:
        return False
    return current_user.has_role('Admin')


def _jit_provision_okta_user(okta_user: OktaUser, db: DBSession):
    """
    Just-in-time provision or update user from Okta.

    Args:
        okta_user: User info from Okta
        db: Database session

    Returns:
        User model instance
    """
    from models.user import User

    # Look for existing user by external_id (Okta sub) or username
    user = db.query(User).filter(
        (User.external_id == okta_user.external_id)
        | (User.username == okta_user.username)
    ).first()

    if user:
        # Update existing user
        if user.auth_provider == "local":
            # First SSO login for existing local user
            user.auth_provider = "okta"
            user.external_id = okta_user.external_id
            logger.info(f"Converted local user {user.username} to Okta auth")
        elif user.auth_provider not in ("okta", "local"):
            # User is managed by different provider
            raise OktaAuthError(
                "Account is managed by a different authentication provider"
            )

        # Update user info
        if okta_user.email:
            user.email = okta_user.email
        if okta_user.display_name:
            user.display_name = okta_user.display_name

        # Update role based on Okta groups
        if okta_user.role != user.role:
            logger.info(
                f"Updating role for {okta_user.username}: {user.role} -> {okta_user.role}"
            )
            user.role = okta_user.role

        user.last_login = datetime.utcnow()
    else:
        # JIT provision new user
        user = User(
            username=okta_user.username,
            email=okta_user.email,
            display_name=okta_user.display_name or okta_user.username,
            role=okta_user.role,
            auth_provider="okta",
            external_id=okta_user.external_id,
            is_active=True,
            must_change_password=False,  # SSO users don't have local passwords
            last_login=datetime.utcnow(),
        )
        # Set a random unusable password for SSO users
        user.set_password(secrets.token_urlsafe(32))
        db.add(user)
        logger.info(
            f"JIT provisioned Okta user: {okta_user.username} with role {okta_user.role}"
        )

    db.commit()
    return user


# =============================================================================
# SSO Endpoints
# =============================================================================


@okta_sso_bp.route("/login")
def okta_login():
    """
    Initiate Okta SSO login.

    Query Parameters:
        next: Optional URL to redirect to after login

    Returns:
        Redirect to Okta authorization endpoint
    """
    if not OKTA_AVAILABLE:
        return jsonify({"error": "Okta authentication not available"}), 501

    okta = get_okta_auth()
    if not okta or not okta.enabled:
        return jsonify({"error": "Okta authentication not configured"}), 503

    # Generate state and nonce for CSRF protection
    state = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    session[OKTA_STATE_KEY] = state
    session[OKTA_NONCE_KEY] = nonce

    # Store next URL for post-login redirect
    next_url = request.args.get("next", url_for("index"))
    session[OKTA_NEXT_KEY] = next_url

    # Get authorization URL
    auth_url = okta.get_auth_url(state=state, nonce=nonce)
    logger.info("Initiating Okta login, redirecting to Okta")

    return redirect(auth_url)


@okta_sso_bp.route("/callback")
def okta_callback():
    """
    Handle Okta OAuth callback.

    Query Parameters:
        code: Authorization code
        state: State parameter for CSRF validation
        error: Error code (if authentication failed)
        error_description: Error message

    Returns:
        Redirect to dashboard on success, login page on failure
    """
    if not OKTA_AVAILABLE:
        return jsonify({"error": "Okta authentication not available"}), 501

    okta = get_okta_auth()
    if not okta or not okta.enabled:
        return jsonify({"error": "Okta authentication not configured"}), 503

    # Check for errors from Okta
    error = request.args.get("error")
    if error:
        error_desc = request.args.get("error_description", "Unknown error")
        logger.warning(f"Okta login error: {error} - {error_desc}")
        return redirect(url_for("auth.login", error=f"Okta: {error_desc}"))

    # Validate state parameter (CSRF protection)
    state = request.args.get("state")
    expected_state = session.pop(OKTA_STATE_KEY, None)
    if not state or state != expected_state:
        logger.warning("Okta callback: state mismatch (possible CSRF)")
        return redirect(url_for("auth.login", error="Invalid authentication state"))

    # Get authorization code
    code = request.args.get("code")
    if not code:
        logger.warning("Okta callback: missing authorization code")
        return redirect(url_for("auth.login", error="Missing authorization code"))

    try:
        # Exchange code for tokens and get user info
        okta_user = okta.handle_callback(code=code, state=state)
        logger.info(f"Okta authentication successful for: {okta_user.email}")

        # JIT provision or update user
        db = _get_db()
        user = _jit_provision_okta_user(okta_user, db)

        # Check if user is active
        if not user.is_active:
            logger.warning(f"Okta login blocked: user {user.username} is deactivated")
            return redirect(url_for("auth.login", error="Account is deactivated"))

        # Store ID token for logout (available in raw_claims)
        id_token = okta_user.raw_claims.get('_id_token')
        session[OKTA_ID_TOKEN_KEY] = id_token

        # Log in the user with Flask-Login
        login_user(user, remember=True)
        logger.info(f"User {user.username} logged in via Okta SSO")

        # Redirect to original destination or dashboard
        next_url = session.pop(OKTA_NEXT_KEY, url_for("index"))

        # Check if MFA is required (even for SSO users, if enforced)
        if user.mfa_enabled:
            # Okta should handle MFA, but if local MFA is also enabled
            session["mfa_pending_user_id"] = user.id
            return redirect(url_for("mfa.verify_page"))

        return redirect(next_url)

    except OktaAuthError as e:
        logger.error(f"Okta authentication failed: {e}")
        return redirect(url_for("auth.login", error=f"Authentication failed: {str(e)}"))
    except Exception as e:
        logger.exception(f"Unexpected error during Okta login: {e}")
        return redirect(url_for("auth.login", error="An unexpected error occurred"))


@okta_sso_bp.route("/logout")
@login_required
def okta_logout():
    """
    Initiate Okta SSO logout.

    Logs out locally and optionally redirects to Okta for global logout.
    """
    if not OKTA_AVAILABLE:
        logout_user()
        return redirect(url_for("auth.login"))

    okta = get_okta_auth()

    # Get stored ID token for logout hint
    id_token = session.pop(OKTA_ID_TOKEN_KEY, None)

    # Clear session and logout locally
    username = current_user.username if current_user.is_authenticated else "unknown"
    logout_user()
    session.clear()

    logger.info(f"User {username} logged out from Okta SSO")

    # If Okta is configured, redirect to Okta logout
    if okta and okta.enabled:
        # Get post-logout redirect URL
        post_logout_uri = url_for("auth.login", _external=True)
        logout_url = okta.get_logout_url(
            id_token=id_token,
            post_logout_redirect_uri=post_logout_uri
        )
        return redirect(logout_url)

    return redirect(url_for("auth.login"))


# =============================================================================
# Admin Endpoints
# =============================================================================


@okta_admin_bp.route("/status")
@login_required
def okta_status():
    """
    Get Okta SSO configuration status (Admin only).

    Returns:
        JSON with Okta status and configuration info
    """
    if not _is_admin():
        return jsonify({"error": "Admin access required"}), 403

    status = {
        "available": OKTA_AVAILABLE,
        "enabled": False,
        "configured": False,
        "domain": None,
        "issuer": None,
        "scopes": [],
        "role_mapping": {},
        "default_role": "Viewer",
        "allow_local_fallback": True,
    }

    if not OKTA_AVAILABLE:
        status["error"] = "Authlib library not installed"
        return jsonify(status)

    okta = get_okta_auth()
    if not okta:
        status["error"] = "Okta not initialized"
        return jsonify(status)

    config = okta.config
    status.update({
        "enabled": config.enabled,
        "configured": okta.enabled,
        "domain": config.domain or None,
        "issuer": okta.issuer if config.enabled else None,
        "scopes": config.scopes,
        "role_mapping": config.role_mapping,
        "default_role": config.default_role,
        "allow_local_fallback": config.allow_local_fallback,
    })

    # Validate configuration
    is_valid, errors = config.validate()
    if not is_valid:
        status["validation_errors"] = errors

    return jsonify(status)


@okta_admin_bp.route("/test", methods=["POST"])
@login_required
def okta_test():
    """
    Test Okta connection (Admin only).

    Tests connectivity to Okta by fetching the discovery document.

    Returns:
        JSON with test results
    """
    if not _is_admin():
        return jsonify({"error": "Admin access required"}), 403

    if not OKTA_AVAILABLE:
        return jsonify({
            "success": False,
            "message": "Authlib library not installed",
        }), 501

    okta = get_okta_auth()
    if not okta:
        return jsonify({
            "success": False,
            "message": "Okta not initialized - check configuration",
        }), 503

    if not okta.config.enabled:
        return jsonify({
            "success": False,
            "message": "Okta is not enabled (OKTA_ENABLED=false)",
        }), 400

    # Test connection
    success, message = okta.test_connection()

    return jsonify({
        "success": success,
        "message": message,
        "issuer": okta.issuer if success else None,
    }), 200 if success else 502


@okta_admin_bp.route("/users")
@login_required
def okta_users():
    """
    List users authenticated via Okta (Admin only).

    Returns:
        JSON with list of Okta-authenticated users
    """
    if not _is_admin():
        return jsonify({"error": "Admin access required"}), 403

    from models.user import User

    db = _get_db()
    users = db.query(User).filter(User.auth_provider == "okta").all()

    return jsonify({
        "count": len(users),
        "users": [
            {
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "display_name": u.display_name,
                "role": u.role,
                "external_id": u.external_id,
                "is_active": u.is_active,
                "last_login": u.last_login.isoformat() if u.last_login else None,
                "created_at": u.created_at.isoformat() if u.created_at else None,
            }
            for u in users
        ],
    })


@okta_admin_bp.route("/validate-mapping", methods=["POST"])
@login_required
def validate_role_mapping():
    """
    Validate a role mapping configuration (Admin only).

    Request Body:
        {
            "role_mapping": {"GroupName": "RoleName", ...}
        }

    Returns:
        JSON with validation results
    """
    if not _is_admin():
        return jsonify({"error": "Admin access required"}), 403

    data = request.get_json() or {}
    role_mapping = data.get("role_mapping", {})

    valid_roles = {"SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"}
    errors = []

    for group_name, role in role_mapping.items():
        if role not in valid_roles:
            errors.append(f"Invalid role '{role}' for group '{group_name}'")

    return jsonify({
        "valid": len(errors) == 0,
        "errors": errors,
        "valid_roles": list(valid_roles),
    })
