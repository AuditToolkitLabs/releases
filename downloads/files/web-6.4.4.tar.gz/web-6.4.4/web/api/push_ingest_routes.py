"""
External Push Ingest API Routes (R2: Data From Anywhere)

Provides a machine-to-machine API surface for third-party tools to push data
directly into the toolkit database using producer API keys.

Endpoints:
- GET  /api/ingest/v1/health
- GET  /api/ingest/v1/schema
- POST /api/ingest/v1/findings
- POST /api/ingest/v1/findings/batch
- POST /api/ingest/v1/assets
- POST /api/ingest/v1/assets/batch
"""

import hashlib
import json
import re
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from flask import Blueprint, jsonify, request
from sqlalchemy import and_

from config import DATA_ROOT, SessionLocal, logger
from auth_core import require_role

try:
    from models.external_push import ExternalFinding, ExternalAsset
except ImportError:
    ExternalFinding = None
    ExternalAsset = None

try:
    from services_pkg.services.feature_licensing import (
        Feature,
        FEATURE_CONFIG,
        get_feature_service,
    )
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    Feature = None
    FEATURE_CONFIG = {}
    FEATURE_LICENSING_AVAILABLE = False


# Feature licensing can be imported during broader app startup while related
# modules are still initializing. Resolve gated feature symbols defensively so
# route import does not crash the whole web service on partial availability.
FEATURE_EXTERNAL_DATA_PUSH = getattr(Feature, 'EXTERNAL_DATA_PUSH', None) if FEATURE_LICENSING_AVAILABLE else None
FEATURE_EXTERNAL_ASSET_PUSH = getattr(Feature, 'EXTERNAL_ASSET_PUSH', None) if FEATURE_LICENSING_AVAILABLE else None

from api.external_ingest_routes import _push_to_dlq


push_ingest_bp = Blueprint('push_ingest', __name__, url_prefix='/api/ingest/v1')

_REGISTRY_DIR = Path(DATA_ROOT) / 'external_sources'
_REGISTRY_FILE = _REGISTRY_DIR / 'registry.json'
_REGISTRY_LOCK = threading.Lock()

_SETTINGS_FILE = _REGISTRY_DIR / 'push_ingest_settings.json'
_SETTINGS_LOCK = threading.Lock()

_RATE_LIMIT_LOCK = threading.Lock()
_RATE_LIMIT_STATE: Dict[str, Dict[str, Dict[str, Any]]] = {}

_FINDINGS_PER_MIN = 1000
_ASSETS_PER_MIN = 100
_MAX_BATCH_ITEMS = 500

_PUSH_SETTINGS_DEFAULTS = {
    'enabled': True,
    'require_contract_version_header': True,
    'findings_per_minute': _FINDINGS_PER_MIN,
    'assets_per_minute': _ASSETS_PER_MIN,
    'max_batch_items': _MAX_BATCH_ITEMS,
}

_ALLOWED_SEVERITIES = {'critical', 'high', 'medium', 'low', 'info'}
_ALLOWED_FINDING_STATUS = {'open', 'resolved', 'suppressed'}
_ALLOWED_ASSET_STATUS = {'active', 'decommissioned'}

_CVE_PATTERN = re.compile(r'^CVE-\d{4}-\d{4,}$', re.IGNORECASE)


def _json_error(message: str, status: int = 400, **extra):
    payload = {'success': False, 'error': message}
    payload.update(extra)
    return jsonify(payload), status


def _load_registry() -> dict:
    if not _REGISTRY_FILE.exists():
        return {}

    try:
        with open(_REGISTRY_FILE, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception as exc:
        logger.warning(f"Failed to load external source registry for push ingest: {exc}")

    return {}


def _save_registry(registry: dict) -> None:
    tmp_file = _REGISTRY_FILE.with_suffix('.tmp')
    with open(tmp_file, 'w', encoding='utf-8') as handle:
        json.dump(registry, handle, indent=2)
    tmp_file.replace(_REGISTRY_FILE)


def _load_push_settings() -> dict:
    if not _SETTINGS_FILE.exists():
        return dict(_PUSH_SETTINGS_DEFAULTS)

    try:
        with open(_SETTINGS_FILE, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            merged = dict(_PUSH_SETTINGS_DEFAULTS)
            merged.update(payload)
            return merged
    except Exception as exc:
        logger.warning(f"Failed to load push ingest settings: {exc}")

    return dict(_PUSH_SETTINGS_DEFAULTS)


def _save_push_settings(settings: dict) -> None:
    _SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp_file = _SETTINGS_FILE.with_suffix('.tmp')
    with open(tmp_file, 'w', encoding='utf-8') as handle:
        json.dump(settings, handle, indent=2)
    tmp_file.replace(_SETTINGS_FILE)


def _get_push_settings() -> dict:
    with _SETTINGS_LOCK:
        return _load_push_settings()


def _coerce_int(value: Any, fallback: int, min_value: int, max_value: int) -> int:
    try:
        parsed = int(value)
        if parsed < min_value:
            return min_value
        if parsed > max_value:
            return max_value
        return parsed
    except (TypeError, ValueError):
        return fallback


def _authenticate_producer(req) -> Tuple[Optional[dict], Optional[Tuple[Any, int]]]:
    auth_header = req.headers.get('Authorization', '').strip()
    if not auth_header.startswith('Bearer '):
        return None, _json_error(
            'Missing or invalid Authorization header (expected Bearer token)',
            401,
            code='AUTH_REQUIRED',
        )

    api_key = auth_header[len('Bearer '):].strip()
    if not api_key.startswith('es_'):
        return None, _json_error('Invalid API key format', 401, code='AUTH_INVALID')

    key_hash = hashlib.sha256(api_key.encode('utf-8')).hexdigest()

    with _REGISTRY_LOCK:
        registry = _load_registry()
        for entry in registry.values():
            if not isinstance(entry, dict):
                continue
            if entry.get('status') != 'active':
                continue
            if entry.get('api_key_hash') != key_hash:
                continue

            entry['last_seen_at'] = datetime.utcnow().isoformat()
            _save_registry(registry)
            return entry, None

    return None, _json_error('Authentication failed', 401, code='AUTH_INVALID')


def _ensure_feature_by_tier(feature) -> Optional[Tuple[Any, int]]:
    if not FEATURE_LICENSING_AVAILABLE or feature is None:
        return None

    try:
        service = get_feature_service()
        cfg = FEATURE_CONFIG.get(feature, {})
        min_tier = cfg.get('min_tier')
        current_tier = service.get_current_license_tier()

        if min_tier and not service.tier_satisfies(min_tier, current_tier):
            return _json_error(
                'Feature not available for current license tier',
                403,
                code='FEATURE_UNAVAILABLE',
                feature=feature.value,
                required_tier=min_tier.value,
                current_tier=current_tier.value,
            )
    except Exception as exc:
        logger.warning(f"Push ingest feature check failed for {feature.value}: {exc}")

    return None


def _enforce_rate_limit(producer_id: str, channel: str, amount: int) -> Optional[Tuple[Any, int]]:
    settings = _get_push_settings()
    if settings.get('enabled') is False:
        return _json_error('External push ingest is disabled by administrator', 503, code='INGEST_DISABLED')

    now = datetime.utcnow()
    window = now.strftime('%Y%m%d%H%M')
    limit = settings.get('findings_per_minute', _FINDINGS_PER_MIN) if channel == 'findings' else settings.get('assets_per_minute', _ASSETS_PER_MIN)
    limit = _coerce_int(limit, _FINDINGS_PER_MIN if channel == 'findings' else _ASSETS_PER_MIN, 1, 1_000_000)

    with _RATE_LIMIT_LOCK:
        state = _RATE_LIMIT_STATE.setdefault(producer_id, {})
        channel_state = state.setdefault(channel, {'window': window, 'count': 0})

        if channel_state['window'] != window:
            channel_state['window'] = window
            channel_state['count'] = 0

        if channel_state['count'] + amount > limit:
            return _json_error(
                'Rate limit exceeded',
                429,
                code='RATE_LIMIT_EXCEEDED',
                producer_id=producer_id,
                channel=channel,
                per_minute_limit=limit,
                requested=amount,
                current_window_count=channel_state['count'],
            )

        channel_state['count'] += amount

    return None


def _parse_iso_datetime(value: Any) -> Optional[datetime]:
    if value is None or value == '':
        return None
    if not isinstance(value, str):
        return None

    text = value.strip()
    if not text:
        return None

    if text.endswith('Z'):
        text = text[:-1] + '+00:00'

    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def _validate_finding_payload(payload: dict) -> Tuple[bool, Dict[str, str]]:
    errors: Dict[str, str] = {}

    title = str(payload.get('title', '')).strip()
    if not title:
        errors['title'] = 'title is required'
    elif len(title) > 500:
        errors['title'] = 'title must be 500 characters or fewer'

    severity = str(payload.get('severity', '')).strip().lower()
    if severity not in _ALLOWED_SEVERITIES:
        errors['severity'] = f"severity must be one of: {', '.join(sorted(_ALLOWED_SEVERITIES))}"

    status = str(payload.get('status', 'open')).strip().lower()
    if status and status not in _ALLOWED_FINDING_STATUS:
        errors['status'] = f"status must be one of: {', '.join(sorted(_ALLOWED_FINDING_STATUS))}"

    cve_ids = payload.get('cve_ids')
    if cve_ids is not None:
        if not isinstance(cve_ids, list):
            errors['cve_ids'] = 'cve_ids must be an array of strings'
        else:
            invalid = [c for c in cve_ids if not isinstance(c, str) or not _CVE_PATTERN.match(c.strip())]
            if invalid:
                errors['cve_ids'] = 'all cve_ids must match CVE-YYYY-NNNN format'

    cvss_score = payload.get('cvss_score')
    if cvss_score is not None:
        try:
            score = float(cvss_score)
            if score < 0.0 or score > 10.0:
                errors['cvss_score'] = 'cvss_score must be between 0.0 and 10.0'
        except (TypeError, ValueError):
            errors['cvss_score'] = 'cvss_score must be numeric'

    ts = payload.get('finding_timestamp')
    if ts is not None and _parse_iso_datetime(ts) is None:
        errors['finding_timestamp'] = 'finding_timestamp must be ISO-8601 datetime'

    return len(errors) == 0, errors


def _validate_asset_payload(payload: dict) -> Tuple[bool, Dict[str, str]]:
    errors: Dict[str, str] = {}

    hostname = str(payload.get('hostname', '')).strip()
    if not hostname:
        errors['hostname'] = 'hostname is required'
    elif len(hostname) > 255:
        errors['hostname'] = 'hostname must be 255 characters or fewer'

    status = str(payload.get('status', 'active')).strip().lower()
    if status and status not in _ALLOWED_ASSET_STATUS:
        errors['status'] = f"status must be one of: {', '.join(sorted(_ALLOWED_ASSET_STATUS))}"

    for field_name in ('ip_addresses', 'mac_addresses'):
        val = payload.get(field_name)
        if val is not None and not isinstance(val, list):
            errors[field_name] = f'{field_name} must be an array of strings'

    for field_name in ('first_seen_at', 'last_seen_at'):
        val = payload.get(field_name)
        if val is not None and _parse_iso_datetime(val) is None:
            errors[field_name] = f'{field_name} must be ISO-8601 datetime'

    return len(errors) == 0, errors


def _serialize_json_field(value: Any) -> Optional[str]:
    if value is None:
        return None
    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        return None


def _create_finding_model(payload: dict, producer: dict) -> ExternalFinding:
    return ExternalFinding(
        ingest_id=str(uuid.uuid4()),
        producer_id=producer.get('producer_id'),
        source_tool=(payload.get('source_tool') or producer.get('name')),
        source_version=payload.get('source_version'),
        title=str(payload.get('title', '')).strip(),
        severity=str(payload.get('severity', '')).strip().lower(),
        description=payload.get('description'),
        remediation=payload.get('remediation'),
        asset_hostname=payload.get('asset_hostname'),
        asset_ip=payload.get('asset_ip'),
        asset_tags=_serialize_json_field(payload.get('asset_tags')),
        cve_ids=_serialize_json_field(payload.get('cve_ids')),
        cvss_score=float(payload['cvss_score']) if payload.get('cvss_score') is not None else None,
        plugin_id=payload.get('plugin_id'),
        external_id=payload.get('external_id'),
        external_url=payload.get('external_url'),
        status=str(payload.get('status', 'open')).strip().lower(),
        raw_payload=_serialize_json_field(payload),
        finding_timestamp=_parse_iso_datetime(payload.get('finding_timestamp')),
    )


def _upsert_asset_model(db, payload: dict, producer: dict) -> ExternalAsset:
    producer_id = producer.get('producer_id')
    external_id = str(payload.get('external_id', '')).strip() or None
    hostname = str(payload.get('hostname', '')).strip()

    existing = None
    if external_id:
        existing = db.query(ExternalAsset).filter(
            and_(
                ExternalAsset.producer_id == producer_id,
                ExternalAsset.external_id == external_id,
            )
        ).first()

    if existing is None:
        existing = db.query(ExternalAsset).filter(
            and_(
                ExternalAsset.producer_id == producer_id,
                ExternalAsset.hostname == hostname,
            )
        ).first()

    if existing is None:
        existing = ExternalAsset(asset_id=str(uuid.uuid4()), producer_id=producer_id)

    existing.hostname = hostname
    existing.ip_addresses = _serialize_json_field(payload.get('ip_addresses'))
    existing.mac_addresses = _serialize_json_field(payload.get('mac_addresses'))
    existing.os_name = payload.get('os_name')
    existing.os_version = payload.get('os_version')
    existing.asset_type = payload.get('asset_type')
    existing.environment = payload.get('environment')
    existing.owner = payload.get('owner')
    existing.tags = _serialize_json_field(payload.get('tags'))
    existing.source_tool = payload.get('source_tool') or producer.get('name')
    existing.external_id = external_id
    existing.status = str(payload.get('status', 'active')).strip().lower()
    existing.raw_payload = _serialize_json_field(payload)
    existing.first_seen_at = _parse_iso_datetime(payload.get('first_seen_at'))
    existing.last_seen_at = _parse_iso_datetime(payload.get('last_seen_at'))

    return existing


@push_ingest_bp.before_request
def _enforce_contract_version_header():
    if request.endpoint in {
        'push_ingest.get_push_ingest_admin_settings',
        'push_ingest.update_push_ingest_admin_settings',
    }:
        return None

    if request.method == 'POST':
        settings = _get_push_settings()
        if settings.get('enabled') is False:
            return _json_error('External push ingest is disabled by administrator', 503, code='INGEST_DISABLED')
        if settings.get('require_contract_version_header', True) is False:
            return None

        version = request.headers.get('X-Ingest-Contract-Version', '').strip()
        if not version:
            return _json_error(
                'Missing required header: X-Ingest-Contract-Version',
                400,
                code='CONTRACT_VERSION_REQUIRED',
                expected='1',
            )
        if version != '1':
            return _json_error(
                'Unsupported contract version',
                400,
                code='CONTRACT_VERSION_UNSUPPORTED',
                expected='1',
                received=version,
            )


@push_ingest_bp.route('/health', methods=['GET'])
def health():
    return jsonify({'ok': True, 'contract_version': '1', 'api_version': '1'})


@push_ingest_bp.route('/schema', methods=['GET'])
def schema():
    settings = _get_push_settings()

    return jsonify({
        'success': True,
        'version': '1',
        'findings': {
            'required': ['title', 'severity'],
            'optional': [
                'description', 'remediation', 'asset_hostname', 'asset_ip', 'asset_tags',
                'cve_ids', 'cvss_score', 'plugin_id', 'external_id', 'external_url',
                'source_tool', 'source_version', 'status', 'finding_timestamp',
            ],
            'severity_values': sorted(_ALLOWED_SEVERITIES),
            'status_values': sorted(_ALLOWED_FINDING_STATUS),
        },
        'assets': {
            'required': ['hostname'],
            'optional': [
                'ip_addresses', 'mac_addresses', 'os_name', 'os_version', 'asset_type',
                'environment', 'owner', 'tags', 'source_tool', 'external_id', 'status',
                'first_seen_at', 'last_seen_at',
            ],
            'status_values': sorted(_ALLOWED_ASSET_STATUS),
        },
        'limits': {
            'findings_per_minute': _coerce_int(settings.get('findings_per_minute'), _FINDINGS_PER_MIN, 1, 1_000_000),
            'assets_per_minute': _coerce_int(settings.get('assets_per_minute'), _ASSETS_PER_MIN, 1, 1_000_000),
            'max_batch_items': _coerce_int(settings.get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000),
        },
        'enabled': bool(settings.get('enabled', True)),
        'require_contract_version_header': bool(settings.get('require_contract_version_header', True)),
    })


@push_ingest_bp.route('/admin/settings', methods=['GET'])
@require_role('SuperAdmin')
def get_push_ingest_admin_settings():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_ASSET_PUSH)
    if denied:
        return denied

    settings = _get_push_settings()
    return jsonify({
        'success': True,
        'settings': {
            'enabled': bool(settings.get('enabled', True)),
            'require_contract_version_header': bool(settings.get('require_contract_version_header', True)),
            'findings_per_minute': _coerce_int(settings.get('findings_per_minute'), _FINDINGS_PER_MIN, 1, 1_000_000),
            'assets_per_minute': _coerce_int(settings.get('assets_per_minute'), _ASSETS_PER_MIN, 1, 1_000_000),
            'max_batch_items': _coerce_int(settings.get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000),
        },
    })


@push_ingest_bp.route('/admin/settings', methods=['PUT'])
@require_role('SuperAdmin')
def update_push_ingest_admin_settings():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_ASSET_PUSH)
    if denied:
        return denied

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return _json_error('Invalid JSON payload', 400)

    with _SETTINGS_LOCK:
        settings = _load_push_settings()

        if 'enabled' in payload:
            settings['enabled'] = bool(payload.get('enabled'))
        if 'require_contract_version_header' in payload:
            settings['require_contract_version_header'] = bool(payload.get('require_contract_version_header'))

        if 'findings_per_minute' in payload:
            settings['findings_per_minute'] = _coerce_int(payload.get('findings_per_minute'), _FINDINGS_PER_MIN, 1, 1_000_000)
        if 'assets_per_minute' in payload:
            settings['assets_per_minute'] = _coerce_int(payload.get('assets_per_minute'), _ASSETS_PER_MIN, 1, 1_000_000)
        if 'max_batch_items' in payload:
            settings['max_batch_items'] = _coerce_int(payload.get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000)

        _save_push_settings(settings)

    return jsonify({
        'success': True,
        'settings': {
            'enabled': bool(settings.get('enabled', True)),
            'require_contract_version_header': bool(settings.get('require_contract_version_header', True)),
            'findings_per_minute': _coerce_int(settings.get('findings_per_minute'), _FINDINGS_PER_MIN, 1, 1_000_000),
            'assets_per_minute': _coerce_int(settings.get('assets_per_minute'), _ASSETS_PER_MIN, 1, 1_000_000),
            'max_batch_items': _coerce_int(settings.get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000),
        },
    })


@push_ingest_bp.route('/findings', methods=['POST'])
def ingest_finding():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_DATA_PUSH)
    if denied:
        return denied

    producer, auth_error = _authenticate_producer(request)
    if auth_error:
        return auth_error

    rl_error = _enforce_rate_limit(producer.get('producer_id'), 'findings', 1)
    if rl_error:
        return rl_error

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return _json_error('Invalid JSON payload', 400)

    valid, errors = _validate_finding_payload(payload)
    if not valid:
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/findings', payload, json.dumps(errors))
        return _json_error('Validation failed', 400, errors=errors, dlq_id=dlq_id)

    if not SessionLocal or ExternalFinding is None:
        return _json_error('Database is not available for ingest', 503, code='DB_UNAVAILABLE')

    db = None
    try:
        db = SessionLocal()
        record = _create_finding_model(payload, producer)
        db.add(record)
        db.commit()

        return jsonify({
            'success': True,
            'ingest_id': record.ingest_id,
            'producer_id': record.producer_id,
            'received_at': record.received_at.isoformat() if record.received_at else None,
        }), 201
    except Exception as exc:
        if db:
            db.rollback()
        logger.error(f"Failed to ingest finding: {exc}")
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/findings', payload, str(exc))
        return _json_error('Failed to persist finding', 500, dlq_id=dlq_id)
    finally:
        if db:
            db.close()


@push_ingest_bp.route('/findings/batch', methods=['POST'])
def ingest_findings_batch():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_DATA_PUSH)
    if denied:
        return denied

    producer, auth_error = _authenticate_producer(request)
    if auth_error:
        return auth_error

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return _json_error('Invalid JSON payload', 400)

    items = payload.get('items')
    if not isinstance(items, list):
        return _json_error('items must be an array', 400)
    if not items:
        return _json_error('items cannot be empty', 400)
    max_batch_items = _coerce_int(_get_push_settings().get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000)
    if len(items) > max_batch_items:
        return _json_error(
            f'batch size cannot exceed {max_batch_items}',
            400,
            max_batch_items=max_batch_items,
        )

    rl_error = _enforce_rate_limit(producer.get('producer_id'), 'findings', len(items))
    if rl_error:
        return rl_error

    if not SessionLocal or ExternalFinding is None:
        return _json_error('Database is not available for ingest', 503, code='DB_UNAVAILABLE')

    valid_rows: List[dict] = []
    rejected_rows: List[dict] = []

    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            rejected_rows.append({'index': idx, 'errors': {'item': 'must be an object'}})
            continue
        valid, errors = _validate_finding_payload(item)
        if valid:
            valid_rows.append(item)
        else:
            rejected_rows.append({'index': idx, 'errors': errors, 'item': item})

    db = None
    inserted_ids: List[str] = []
    dlq_ids: List[str] = []
    try:
        db = SessionLocal()

        for row in valid_rows:
            record = _create_finding_model(row, producer)
            db.add(record)
            inserted_ids.append(record.ingest_id)

        if valid_rows:
            db.commit()

        for rejected in rejected_rows:
            dlq_id = _push_to_dlq(
                producer.get('producer_id'),
                '/api/ingest/v1/findings/batch',
                rejected.get('item', {}),
                json.dumps(rejected.get('errors', {})),
            )
            dlq_ids.append(dlq_id)

        return jsonify({
            'success': True,
            'accepted': len(valid_rows),
            'rejected': len(rejected_rows),
            'ingest_ids': inserted_ids,
            'dlq_ids': dlq_ids,
        }), 201 if valid_rows else 400

    except Exception as exc:
        if db:
            db.rollback()
        logger.error(f"Failed to ingest finding batch: {exc}")
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/findings/batch', payload, str(exc))
        return _json_error('Failed to persist finding batch', 500, dlq_id=dlq_id)
    finally:
        if db:
            db.close()


@push_ingest_bp.route('/assets', methods=['POST'])
def ingest_asset():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_ASSET_PUSH)
    if denied:
        return denied

    producer, auth_error = _authenticate_producer(request)
    if auth_error:
        return auth_error

    rl_error = _enforce_rate_limit(producer.get('producer_id'), 'assets', 1)
    if rl_error:
        return rl_error

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return _json_error('Invalid JSON payload', 400)

    valid, errors = _validate_asset_payload(payload)
    if not valid:
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/assets', payload, json.dumps(errors))
        return _json_error('Validation failed', 400, errors=errors, dlq_id=dlq_id)

    if not SessionLocal or ExternalAsset is None:
        return _json_error('Database is not available for ingest', 503, code='DB_UNAVAILABLE')

    db = None
    try:
        db = SessionLocal()
        asset = _upsert_asset_model(db, payload, producer)
        db.add(asset)
        db.commit()

        return jsonify({
            'success': True,
            'asset_id': asset.asset_id,
            'producer_id': asset.producer_id,
            'hostname': asset.hostname,
            'received_at': asset.received_at.isoformat() if asset.received_at else None,
        }), 201

    except Exception as exc:
        if db:
            db.rollback()
        logger.error(f"Failed to ingest asset: {exc}")
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/assets', payload, str(exc))
        return _json_error('Failed to persist asset', 500, dlq_id=dlq_id)
    finally:
        if db:
            db.close()


@push_ingest_bp.route('/assets/batch', methods=['POST'])
def ingest_assets_batch():
    denied = _ensure_feature_by_tier(FEATURE_EXTERNAL_ASSET_PUSH)
    if denied:
        return denied

    producer, auth_error = _authenticate_producer(request)
    if auth_error:
        return auth_error

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return _json_error('Invalid JSON payload', 400)

    items = payload.get('items')
    if not isinstance(items, list):
        return _json_error('items must be an array', 400)
    if not items:
        return _json_error('items cannot be empty', 400)
    max_batch_items = _coerce_int(_get_push_settings().get('max_batch_items'), _MAX_BATCH_ITEMS, 1, 10_000)
    if len(items) > max_batch_items:
        return _json_error(
            f'batch size cannot exceed {max_batch_items}',
            400,
            max_batch_items=max_batch_items,
        )

    rl_error = _enforce_rate_limit(producer.get('producer_id'), 'assets', len(items))
    if rl_error:
        return rl_error

    if not SessionLocal or ExternalAsset is None:
        return _json_error('Database is not available for ingest', 503, code='DB_UNAVAILABLE')

    valid_rows: List[dict] = []
    rejected_rows: List[dict] = []

    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            rejected_rows.append({'index': idx, 'errors': {'item': 'must be an object'}})
            continue
        valid, errors = _validate_asset_payload(item)
        if valid:
            valid_rows.append(item)
        else:
            rejected_rows.append({'index': idx, 'errors': errors, 'item': item})

    db = None
    upserted_ids: List[str] = []
    dlq_ids: List[str] = []

    try:
        db = SessionLocal()

        for row in valid_rows:
            asset = _upsert_asset_model(db, row, producer)
            db.add(asset)
            db.flush()
            upserted_ids.append(asset.asset_id)

        if valid_rows:
            db.commit()

        for rejected in rejected_rows:
            dlq_id = _push_to_dlq(
                producer.get('producer_id'),
                '/api/ingest/v1/assets/batch',
                rejected.get('item', {}),
                json.dumps(rejected.get('errors', {})),
            )
            dlq_ids.append(dlq_id)

        return jsonify({
            'success': True,
            'accepted': len(valid_rows),
            'rejected': len(rejected_rows),
            'asset_ids': upserted_ids,
            'dlq_ids': dlq_ids,
        }), 201 if valid_rows else 400

    except Exception as exc:
        if db:
            db.rollback()
        logger.error(f"Failed to ingest asset batch: {exc}")
        dlq_id = _push_to_dlq(producer.get('producer_id'), '/api/ingest/v1/assets/batch', payload, str(exc))
        return _json_error('Failed to persist asset batch', 500, dlq_id=dlq_id)
    finally:
        if db:
            db.close()
