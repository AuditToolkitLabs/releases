#!/usr/bin/env python3
"""
Error Recovery API Routes

Provides endpoints for:
- Dead letter queue management
- Circuit breaker status and control
- Task retry and resolution
- Error metrics and statistics

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import logging
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request
from sqlalchemy import func, desc
from sqlalchemy.exc import SQLAlchemyError

from config import SessionLocal
from models.dead_letter import DeadLetterTask, TaskFailureLog
from circuit_breaker import get_circuit_breaker_registry
from auth_core import require_api_key
from celery_app import celery_app

logger = logging.getLogger(__name__)

# Create blueprint
recovery_bp = Blueprint('recovery', __name__, url_prefix='/api/recovery')


# ============================================================================
# Dead Letter Queue Endpoints
# ============================================================================

@recovery_bp.route('/dlq/tasks', methods=['GET'])
@require_api_key
def get_dlq_tasks():
    """
    Get all tasks in dead letter queue

    Query params:
        - resolved: Filter by resolution status (true/false)
        - limit: Max results (default 100)
        - offset: Pagination offset (default 0)
    """
    db = None
    try:
        db = SessionLocal()

        # Get query parameters
        resolved = request.args.get('resolved', 'false').lower() == 'true'
        limit = min(int(request.args.get('limit', 100)), 500)
        offset = int(request.args.get('offset', 0))

        # Build query
        query = db.query(DeadLetterTask).filter(
            DeadLetterTask.resolved == resolved
        ).order_by(desc(DeadLetterTask.added_to_dlq_at))

        # Get total count
        total = query.count()

        # Paginate
        tasks = query.limit(limit).offset(offset).all()

        return jsonify({
            'success': True,
            'total': total,
            'limit': limit,
            'offset': offset,
            'tasks': [task.to_dict() for task in tasks]
        })

    except Exception as e:
        logger.error(f"Failed to get DLQ tasks: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


@recovery_bp.route('/dlq/tasks/<int:task_id>', methods=['GET'])
@require_api_key
def get_dlq_task(task_id):
    """Get specific dead letter queue task with failure history"""
    db = None
    try:
        db = SessionLocal()

        # Get DLQ task
        dlq_task = db.query(DeadLetterTask).filter(DeadLetterTask.id == task_id).first()
        if not dlq_task:
            return jsonify({'success': False, 'error': 'Task not found'}), 404

        # Get failure history
        failure_logs = db.query(TaskFailureLog).filter(
            TaskFailureLog.task_id == dlq_task.task_id
        ).order_by(TaskFailureLog.failed_at).all()

        return jsonify({
            'success': True,
            'task': dlq_task.to_dict(),
            'failure_history': [log.to_dict() for log in failure_logs]
        })

    except Exception as e:
        logger.error(f"Failed to get DLQ task {task_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


@recovery_bp.route('/dlq/tasks/<int:task_id>/resolve', methods=['POST'])
@require_api_key
def resolve_dlq_task(task_id):
    """
    Mark dead letter queue task as resolved

    Body:
        - resolved_by: User who resolved the issue
        - resolution_notes: Notes about the resolution
    """
    db = None
    try:
        db = SessionLocal()
        data = request.json or {}

        # Get DLQ task
        dlq_task = db.query(DeadLetterTask).filter(DeadLetterTask.id == task_id).first()
        if not dlq_task:
            return jsonify({'success': False, 'error': 'Task not found'}), 404

        # Update resolution
        dlq_task.resolved = True
        dlq_task.resolved_at = datetime.utcnow()
        dlq_task.resolved_by = data.get('resolved_by', 'api')
        dlq_task.resolution_notes = data.get('resolution_notes', '')
        db.commit()

        logger.info(f"DLQ task {task_id} resolved by {dlq_task.resolved_by}")

        return jsonify({
            'success': True,
            'task': dlq_task.to_dict()
        })

    except Exception as e:
        logger.error(f"Failed to resolve DLQ task {task_id}: {e}")
        if db:
            db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


@recovery_bp.route('/dlq/tasks/<int:task_id>/retry', methods=['POST'])
@require_api_key
def retry_dlq_task(task_id):
    """
    Retry a failed task from dead letter queue

    Creates a new Celery task with the same parameters.
    """
    db = None
    try:
        db = SessionLocal()

        # Get DLQ task
        dlq_task = db.query(DeadLetterTask).filter(DeadLetterTask.id == task_id).first()
        if not dlq_task:
            return jsonify({'success': False, 'error': 'Task not found'}), 404

        # Get task signature
        task_name = dlq_task.task_name
        args = dlq_task.args or []
        kwargs = dlq_task.kwargs or {}

        # Submit new task
        task = celery_app.send_task(
            task_name,
            args=args,
            kwargs=kwargs
        )

        logger.info(f"Retrying DLQ task {task_id} as new task {task.id}")

        return jsonify({
            'success': True,
            'new_task_id': task.id,
            'original_task_id': dlq_task.task_id
        })

    except Exception as e:
        logger.error(f"Failed to retry DLQ task {task_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


@recovery_bp.route('/dlq/stats', methods=['GET'])
@require_api_key
def get_dlq_stats():
    """Get dead letter queue statistics"""
    db = None
    try:
        db = SessionLocal()

        # Count by status
        unresolved_count = db.query(DeadLetterTask).filter(
            DeadLetterTask.resolved.is_(False)
        ).count()

        resolved_count = db.query(DeadLetterTask).filter(
            DeadLetterTask.resolved.is_(True)
        ).count()

        # Count by task name
        task_counts = db.query(
            DeadLetterTask.task_name,
            func.count(DeadLetterTask.id).label('count')
        ).filter(
            DeadLetterTask.resolved.is_(False)
        ).group_by(DeadLetterTask.task_name).all()

        # Recent failures
        recent_failures = db.query(TaskFailureLog).order_by(
            desc(TaskFailureLog.failed_at)
        ).limit(10).all()

        return jsonify({
            'success': True,
            'stats': {
                'unresolved_tasks': unresolved_count,
                'resolved_tasks': resolved_count,
                'total_tasks': unresolved_count + resolved_count,
                'tasks_by_type': [
                    {'task_name': name, 'count': count}
                    for name, count in task_counts
                ],
                'recent_failures': [log.to_dict() for log in recent_failures]
            }
        })

    except Exception as e:
        if db:
            try:
                db.rollback()
            except Exception as rollback_error:
                logger.debug(f"Session rollback skipped in DLQ stats handler: {rollback_error}")

        error_text = str(e).lower()
        if (
            isinstance(e, SQLAlchemyError)
            and (
                ('dead_letter_tasks' in error_text and 'does not exist' in error_text)
                or ('task_failure_logs' in error_text and 'does not exist' in error_text)
            )
        ):
            logger.warning("DLQ tables unavailable; returning empty DLQ stats")
            return jsonify({
                'success': True,
                'stats': {
                    'unresolved_tasks': 0,
                    'resolved_tasks': 0,
                    'total_tasks': 0,
                    'tasks_by_type': [],
                    'recent_failures': []
                }
            })

        logger.error(f"Failed to get DLQ stats: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


# ============================================================================
# Circuit Breaker Endpoints
# ============================================================================

@recovery_bp.route('/circuit-breakers', methods=['GET'])
@require_api_key
def get_circuit_breakers():
    """Get all circuit breaker states"""
    try:
        registry = get_circuit_breaker_registry()
        stats = registry.get_all_stats()

        return jsonify({
            'success': True,
            'circuit_breakers': stats,
            'total': len(stats),
            'open_circuits': registry.get_open_circuits()
        })

    except Exception as e:
        logger.error(f"Failed to get circuit breakers: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@recovery_bp.route('/circuit-breakers/<path:service_id>/reset', methods=['POST'])
@require_api_key
def reset_circuit_breaker(service_id):
    """Reset specific circuit breaker to CLOSED state"""
    try:
        registry = get_circuit_breaker_registry()
        registry.reset_breaker(service_id)

        logger.info(f"Circuit breaker reset: {service_id}")

        return jsonify({
            'success': True,
            'service_id': service_id,
            'message': 'Circuit breaker reset to CLOSED'
        })

    except Exception as e:
        logger.error(f"Failed to reset circuit breaker {service_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@recovery_bp.route('/circuit-breakers/reset-all', methods=['POST'])
@require_api_key
def reset_all_circuit_breakers():
    """Reset all circuit breakers to CLOSED state"""
    try:
        registry = get_circuit_breaker_registry()
        registry.reset_all()

        logger.info("All circuit breakers reset")

        return jsonify({
            'success': True,
            'message': 'All circuit breakers reset to CLOSED'
        })

    except Exception as e:
        logger.error("Failed to reset all circuit breakers: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Error Metrics
# ============================================================================

@recovery_bp.route('/metrics/failures', methods=['GET'])
@require_api_key
def get_failure_metrics():
    """
    Get failure metrics and trends

    Query params:
        - hours: Time window in hours (default 24)
    """
    db = None
    try:
        db = SessionLocal()
        hours = int(request.args.get('hours', 24))

        # Calculate time window
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)

        # Count failures by task name
        task_failures = db.query(
            TaskFailureLog.task_name,
            func.count(TaskFailureLog.id).label('failure_count')
        ).filter(
            TaskFailureLog.failed_at >= cutoff_time
        ).group_by(
            TaskFailureLog.task_name
        ).all()

        # Count failures by exception type
        exception_failures = db.query(
            TaskFailureLog.exception_type,
            func.count(TaskFailureLog.id).label('failure_count')
        ).filter(
            TaskFailureLog.failed_at >= cutoff_time
        ).group_by(
            TaskFailureLog.exception_type
        ).all()

        # Get circuit breaker events
        circuit_breaker_events = db.query(TaskFailureLog).filter(
            TaskFailureLog.failed_at >= cutoff_time,
            TaskFailureLog.circuit_breaker_state.isnot(None)
        ).order_by(desc(TaskFailureLog.failed_at)).limit(20).all()

        return jsonify({
            'success': True,
            'time_window_hours': hours,
            'metrics': {
                'failures_by_task': [
                    {'task_name': name, 'failures': count}
                    for name, count in task_failures
                ],
                'failures_by_exception': [
                    {'exception_type': exc_type or 'Unknown', 'failures': count}
                    for exc_type, count in exception_failures
                ],
                'circuit_breaker_events': [log.to_dict() for log in circuit_breaker_events]
            }
        })

    except Exception as e:
        logger.error(f"Failed to get failure metrics: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if db:
            db.close()


# Export blueprint
__all__ = ['recovery_bp']
