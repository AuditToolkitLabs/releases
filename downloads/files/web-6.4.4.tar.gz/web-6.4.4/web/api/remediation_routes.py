"""
Remediation Routes - SuperAdmin-only Security Fix Application

Provides REST API endpoints for applying security remediation fixes from
the fix/ folder to remote servers via SSH/WinRM.

Supported Platforms:
- Linux (110+ fixes via run-fix.sh)
- Windows (180+ fixes via Run-Fix.ps1)
- Hypervisors: ESXi, KVM, Proxmox, Nutanix, Xen (via run-fix.sh)

Security:
- Feature must be explicitly enabled via REMEDIATION_ENABLED config
- SuperAdmin role required
- Secondary authentication required (password re-entry)
- IP allowlisting support
- Time-based access control
- Mandatory dry-run preview before execution (configurable)
- Command allowlist - only fix scripts allowed
- All executions logged to audit trail
- Rate limiting on fix execution
- Rollback support where available
"""

import os
import re
import json
import logging
import uuid
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, session, g
from functools import wraps
from collections import defaultdict

try:
    import pytz
    PYTZ_AVAILABLE = True
except ImportError:
    PYTZ_AVAILABLE = False

# Get logger
logger = logging.getLogger(__name__)

# Import safe error response
try:
    from auth_core import safe_error_response
except ImportError:
    def safe_error_response(message, code=500):
        return jsonify({'error': message}), code

# Feature licensing imports
try:
    from web.services_pkg.services.feature_licensing import (
        Feature, require_feature_key, check_feature, get_feature_service
    )
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    def require_feature_key(feature):
        """Dummy decorator when feature licensing not available."""
        def decorator(f):
            return f
        return decorator
    def check_feature(feature):
        return True


def _current_feature_user_id():
    """Resolve the current user id in the shape expected by feature licensing."""
    try:
        from flask_login import current_user

        if current_user.is_authenticated:
            return str(current_user.id)
    except Exception:
        pass

    return session.get('user_id')


def _feature_denied_response(feature_status, feature_name=None):
    """Return a normalized feature-unavailable response payload."""
    payload = {
        'error': 'Feature not available',
        'code': 'FEATURE_UNAVAILABLE',
        'reason': feature_status.get('reason'),
        'trial_eligible': feature_status.get('trial_eligible', False),
        'upgrade_tier': feature_status.get('upgrade_tier'),
    }
    if feature_name:
        payload['feature'] = feature_name
    return jsonify(payload), 403


def _resolve_remediation_feature(fix_id=None, os_type=None):
    """Map a fix request or server OS to the matching remediation feature."""
    normalized_fix_id = (fix_id or '').lower()
    normalized_os = (os_type or '').lower()

    if normalized_os in ('windows', 'winrm') or normalized_fix_id.startswith('windows/') or '/windows/' in normalized_fix_id:
        return Feature.FIX_SCRIPTS_WINDOWS

    if (
        normalized_os in ('hypervisor', 'hypervisors', 'esxi', 'kvm', 'proxmox', 'nutanix', 'xen')
        or normalized_fix_id.startswith('hypervisor')
        or any(name in normalized_fix_id for name in ('esxi', 'kvm', 'proxmox', 'nutanix', 'xen'))
    ):
        return Feature.FIX_SCRIPTS_HYPERVISOR

    return Feature.FIX_SCRIPTS_LINUX


def _get_remediation_feature_status(feature=None):
    """Resolve remediation tool access for a platform-specific feature or the tool overall."""
    if not FEATURE_LICENSING_AVAILABLE:
        return {'available': True, 'feature': None}

    service = get_feature_service()
    user_id = _current_feature_user_id()
    required_features = [feature] if feature else [
        Feature.FIX_SCRIPTS_LINUX,
        Feature.FIX_SCRIPTS_WINDOWS,
        Feature.FIX_SCRIPTS_HYPERVISOR,
    ]

    denied_status = None
    for candidate in required_features:
        feature_status = service.is_feature_available(candidate, user_id)
        if feature_status.get('available'):
            feature_status['feature'] = candidate.value
            return feature_status
        if denied_status is None:
            denied_status = feature_status

    if denied_status is None:
        denied_status = {
            'available': False,
            'reason': 'Feature not available',
            'trial_eligible': False,
            'upgrade_tier': None,
        }
    denied_status['feature'] = required_features[0].value if required_features else None
    return denied_status


def _ensure_remediation_tool_access(feature=None):
    """Enforce licensing for the remediation tool surface."""
    feature_status = _get_remediation_feature_status(feature)
    if feature_status.get('available'):
        return None
    return _feature_denied_response(feature_status, feature_status.get('feature'))

# Create blueprint
remediation_bp = Blueprint('remediation', __name__, url_prefix='/api/remediation')

# Rate limiting storage
execution_tracker = defaultdict(list)

# Cache for database settings
_settings_cache = {'settings': None, 'expires': None}
SETTINGS_CACHE_TTL = 60  # seconds


# ============================================================================
# CONFIGURATION
# ============================================================================

def get_db_settings():
    """Get remediation settings from database with caching."""
    now = datetime.utcnow()

    if (_settings_cache['settings'] and
        _settings_cache['expires'] and
        _settings_cache['expires'] > now):
        return _settings_cache['settings']

    try:
        from config import get_db_session
        from models.remediation import RemediationSettings

        db = get_db_session()
        try:
            settings = RemediationSettings.get_settings(db)
            settings_dict = settings.to_dict(include_sensitive=True)

            _settings_cache['settings'] = settings_dict
            _settings_cache['expires'] = now + timedelta(seconds=SETTINGS_CACHE_TTL)

            return settings_dict
        finally:
            db.close()
    except Exception as e:
        logger.warning(f"Failed to load remediation settings from DB: {e}")
        return get_default_settings()


def get_default_settings():
    """Default settings when database is unavailable."""
    return {
        'enabled': os.environ.get('REMEDIATION_ENABLED', 'false').lower() == 'true',
        'require_dry_run_first': True,
        'max_fixes_per_hour': 20,
        'execution_timeout_seconds': 300,
        'linux_enabled': True,
        'windows_enabled': True,
        'hypervisor_enabled': True,
        'linux_fix_path': '/opt/audit-toolkit/fix/linux',
        'windows_fix_path': 'C:\\audit-toolkit\\fix\\windows',
        'hypervisor_fix_path': '/opt/audit-toolkit/fix/hypervisors',
        'auto_deploy_scripts': True,
        'blacklisted_fix_ids': [],
        'high_risk_categories': ['kernel', 'firewall', 'selinux', 'apparmor'],
        'ip_allowlist': [],
        'allowed_days': [0, 1, 2, 3, 4],
        'timezone': 'UTC',
    }


def invalidate_settings_cache():
    """Invalidate settings cache when updated."""
    _settings_cache['settings'] = None
    _settings_cache['expires'] = None


def get_remediation_config():
    """Get remediation configuration."""
    db_settings = get_db_settings()
    if db_settings:
        return db_settings
    return get_default_settings()


# ============================================================================
# SECURITY DECORATORS
# ============================================================================

def require_superadmin(f):
    """Decorator to require SuperAdmin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            if current_user.role != 'SuperAdmin':
                logger.warning(
                    f"Remediation access denied for user {current_user.username} "
                    f"with role {current_user.role}"
                )
                return jsonify({
                    'error': 'SuperAdmin role required for remediation access',
                    'code': 'ROLE_DENIED'
                }), 403
        except Exception as e:
            logger.error(f"Auth check failed: {e}")
            return jsonify({'error': 'Authentication check failed'}), 500
        return f(*args, **kwargs)
    return decorated_function


def require_remediation_enabled(f):
    """Decorator to check if remediation feature is enabled."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        config = get_remediation_config()
        if not config.get('enabled', False):
            logger.warning(
                f"Remediation feature disabled, access denied from {request.remote_addr}"
            )
            return jsonify({
                'error': 'Remediation feature is disabled',
                'code': 'REMEDIATION_DISABLED',
                'message': 'Enable via REMEDIATION_ENABLED=true or Admin Settings.'
            }), 403
        return f(*args, **kwargs)
    return decorated_function


def require_remediation_auth(f):
    """Decorator to require valid remediation access token (secondary auth)."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get('X-Remediation-Token') or \
                request.args.get('remediation_token') or \
                session.get('remediation_access_token')

        if not token:
            return jsonify({
                'error': 'Secondary authentication required',
                'code': 'AUTH_REQUIRED',
                'requires_auth': True
            }), 401

        # Validate token
        try:
            from flask_login import current_user
            expected_token = session.get('remediation_access_token')
            token_expiry = session.get('remediation_token_expiry')

            if not expected_token or token != expected_token:
                return jsonify({
                    'error': 'Invalid remediation token',
                    'code': 'INVALID_TOKEN',
                    'requires_auth': True
                }), 401

            if token_expiry and datetime.utcnow() > datetime.fromisoformat(token_expiry):
                return jsonify({
                    'error': 'Remediation session expired',
                    'code': 'TOKEN_EXPIRED',
                    'requires_auth': True
                }), 401

        except Exception as e:
            logger.error(f"Token validation failed: {e}")
            return jsonify({'error': 'Token validation failed'}), 500

        return f(*args, **kwargs)
    return decorated_function


def require_allowed_ip(f):
    """Decorator to check if client IP is in allowlist."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        config = get_remediation_config()
        allowlist = config.get('ip_allowlist', [])

        if not allowlist:
            return f(*args, **kwargs)

        client_ip = request.remote_addr

        # Check against allowlist
        for allowed in allowlist:
            try:
                import ipaddress
                if '/' in allowed:
                    network = ipaddress.ip_network(allowed, strict=False)
                    if ipaddress.ip_address(client_ip) in network:
                        return f(*args, **kwargs)
                elif client_ip == allowed:
                    return f(*args, **kwargs)
            except ValueError:
                continue

        logger.warning(f"Remediation access denied from non-allowed IP: {client_ip}")
        return jsonify({
            'error': 'Access denied from this IP address',
            'code': 'IP_NOT_ALLOWED'
        }), 403
    return decorated_function


def check_time_based_access():
    """Check if current time is within allowed access window."""
    config = get_remediation_config()
    allowed_hours_start = config.get('allowed_hours_start')
    allowed_hours_end = config.get('allowed_hours_end')
    allowed_days = config.get('allowed_days', [0, 1, 2, 3, 4])
    timezone = config.get('timezone', 'UTC')

    if not allowed_hours_start and not allowed_hours_end:
        return True, None

    try:
        if PYTZ_AVAILABLE:
            tz = pytz.timezone(timezone)
            now = datetime.now(tz)
        else:
            now = datetime.utcnow()
    except Exception:
        now = datetime.utcnow()

    # Check day
    if allowed_days and now.weekday() not in allowed_days:
        day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        return False, f"Remediation not allowed on {day_names[now.weekday()]}"

    # Check time
    if allowed_hours_start and allowed_hours_end:
        try:
            start = datetime.strptime(allowed_hours_start, '%H:%M:%S').time()
            end = datetime.strptime(allowed_hours_end, '%H:%M:%S').time()
            current = now.time()

            if start <= end:
                if not (start <= current <= end):
                    return False, f"Only allowed {allowed_hours_start}-{allowed_hours_end}"
            else:
                if not (current >= start or current <= end):
                    return False, f"Only allowed {allowed_hours_start}-{allowed_hours_end}"
        except ValueError:
            pass

    return True, None


def require_time_access(f):
    """Decorator to enforce time-based access control."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        allowed, message = check_time_based_access()
        if not allowed:
            logger.warning(f"Remediation access denied: {message}")
            return jsonify({
                'error': 'Access denied - outside allowed hours',
                'code': 'TIME_RESTRICTED',
                'message': message
            }), 403
        return f(*args, **kwargs)
    return decorated_function


def rate_limit_execution(f):
    """Decorator to rate limit fix executions."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask_login import current_user
        config = get_remediation_config()
        max_per_hour = config.get('max_fixes_per_hour', 20)

        user_id = str(current_user.id) if current_user.is_authenticated else 'anon'
        now = datetime.utcnow()
        window_start = now - timedelta(hours=1)

        # Clean old entries
        execution_tracker[user_id] = [
            ts for ts in execution_tracker[user_id] if ts > window_start
        ]

        if len(execution_tracker[user_id]) >= max_per_hour:
            return jsonify({
                'error': f'Rate limit exceeded ({max_per_hour}/hour)',
                'code': 'RATE_LIMITED',
                'retry_after': 3600
            }), 429

        execution_tracker[user_id].append(now)
        return f(*args, **kwargs)
    return decorated_function


# ============================================================================
# FIX CATALOG
# ============================================================================

# Static fix catalog - loaded from fix/ folder structure
FIX_CATALOG = {
    'linux': {
        'ssh': [
            {'id': 'SSH-001', 'name': 'Disable Root Login', 'cis': '5.2.1', 'severity': 'high', 'rollback': True},
            {'id': 'SSH-002', 'name': 'Enforce Protocol 2', 'cis': '5.2.2', 'severity': 'critical', 'rollback': True},
            {'id': 'SSH-003', 'name': 'Set MaxAuthTries', 'cis': '5.2.5', 'severity': 'medium', 'rollback': True},
            {'id': 'SSH-004', 'name': 'Disable Empty Passwords', 'cis': '5.2.8', 'severity': 'high', 'rollback': True},
            {'id': 'SSH-005', 'name': 'Disable PermitUserEnvironment', 'cis': '5.2.10', 'severity': 'medium', 'rollback': True},
            {'id': 'SSH-006', 'name': 'Use Strong Ciphers', 'cis': '5.2.13', 'severity': 'high', 'rollback': True},
            {'id': 'SSH-007', 'name': 'Use Strong MACs', 'cis': '5.2.14', 'severity': 'high', 'rollback': True},
            {'id': 'SSH-008', 'name': 'Use Strong KEX', 'cis': '5.2.15', 'severity': 'high', 'rollback': True},
            {'id': 'SSH-009', 'name': 'Set ClientAliveInterval', 'cis': '5.2.21', 'severity': 'low', 'rollback': True},
            {'id': 'SSH-010', 'name': 'Set LoginGraceTime', 'cis': '5.2.17', 'severity': 'low', 'rollback': True},
            {'id': 'SSH-011', 'name': 'Set SSH Banner', 'cis': '5.2.18', 'severity': 'low', 'rollback': True},
            {'id': 'SSH-012', 'name': 'Disable X11 Forwarding', 'cis': '5.2.6', 'severity': 'medium', 'rollback': True},
        ],
        'pam': [
            {'id': 'PAM-001', 'name': 'Configure Password Quality', 'cis': '5.4.1', 'severity': 'high', 'rollback': True},
            {'id': 'PAM-002', 'name': 'Set Password Expiration', 'cis': '5.5.1.1', 'severity': 'medium', 'rollback': True},
            {'id': 'PAM-003', 'name': 'Set Minimum Password Days', 'cis': '5.5.1.2', 'severity': 'low', 'rollback': True},
            {'id': 'PAM-004', 'name': 'Set Password Warning Days', 'cis': '5.5.1.3', 'severity': 'low', 'rollback': True},
            {'id': 'PAM-005', 'name': 'Set Inactive Account Lockout', 'cis': '5.5.1.4', 'severity': 'medium', 'rollback': True},
            {'id': 'PAM-006', 'name': 'Restrict su Access', 'cis': '5.6', 'severity': 'high', 'rollback': True},
            {'id': 'PAM-007', 'name': 'Configure Password History', 'cis': '5.4.3', 'severity': 'medium', 'rollback': True},
            {'id': 'PAM-008', 'name': 'Configure Password Length', 'cis': '5.4.1', 'severity': 'high', 'rollback': True},
            {'id': 'PAM-009', 'name': 'Enable Account Lockout', 'cis': '5.4.2', 'severity': 'high', 'rollback': True},
        ],
        'kernel': [
            {'id': 'KRN-001', 'name': 'Enable ASLR', 'cis': '1.5.3', 'severity': 'critical', 'rollback': True},
            {'id': 'KRN-002', 'name': 'Disable Core Dumps', 'cis': '1.5.1', 'severity': 'medium', 'rollback': True},
            {'id': 'KRN-003', 'name': 'Restrict dmesg', 'cis': '1.5.2', 'severity': 'low', 'rollback': True},
            {'id': 'KRN-004', 'name': 'Enable ExecShield', 'cis': 'L2', 'severity': 'high', 'rollback': True},
            {'id': 'KRN-005', 'name': 'Disable Unprivileged BPF', 'cis': 'L2', 'severity': 'medium', 'rollback': True},
            {'id': 'KRN-006', 'name': 'Enable Kernel Pointer Restriction', 'cis': 'L2', 'severity': 'medium', 'rollback': True},
            {'id': 'KRN-007', 'name': 'Restrict Perf Events', 'cis': 'L2', 'severity': 'medium', 'rollback': True},
            {'id': 'KRN-008', 'name': 'Enable YAMA ptrace Scope', 'cis': 'L2', 'severity': 'medium', 'rollback': True},
            {'id': 'KRN-009', 'name': 'Disable kexec_load', 'cis': 'L2', 'severity': 'high', 'rollback': True},
        ],
        'network': [
            {'id': 'NET-001', 'name': 'Disable IP Forwarding', 'cis': '3.1.1', 'severity': 'medium', 'rollback': True},
            {'id': 'NET-002', 'name': 'Disable Packet Redirect', 'cis': '3.1.2', 'severity': 'medium', 'rollback': True},
            {'id': 'NET-003', 'name': 'Ignore Bogus ICMP', 'cis': '3.2.6', 'severity': 'low', 'rollback': True},
            {'id': 'NET-004', 'name': 'Enable TCP SYN Cookies', 'cis': '3.2.8', 'severity': 'high', 'rollback': True},
            {'id': 'NET-005', 'name': 'Disable Source Routing', 'cis': '3.2.1', 'severity': 'high', 'rollback': True},
            {'id': 'NET-006', 'name': 'Enable Reverse Path Filtering', 'cis': '3.2.7', 'severity': 'medium', 'rollback': True},
            {'id': 'NET-007', 'name': 'Log Martian Packets', 'cis': '3.2.4', 'severity': 'low', 'rollback': True},
            {'id': 'NET-008', 'name': 'Disable ICMP Redirects', 'cis': '3.2.2', 'severity': 'medium', 'rollback': True},
            {'id': 'NET-009', 'name': 'Disable IPv6 If Unused', 'cis': '3.3.x', 'severity': 'low', 'rollback': True},
            {'id': 'NET-010', 'name': 'Configure TCP Wrappers', 'cis': '3.4.x', 'severity': 'medium', 'rollback': True},
        ],
        'firewall': [
            {'id': 'FW-001', 'name': 'Enable Firewall', 'cis': '3.4.1.1', 'severity': 'critical', 'rollback': True},
            {'id': 'FW-002', 'name': 'Configure Default Deny', 'cis': '3.4.1.2', 'severity': 'high', 'rollback': True},
            {'id': 'FW-003', 'name': 'Allow Loopback Traffic', 'cis': '3.4.1.3', 'severity': 'medium', 'rollback': True},
            {'id': 'FW-004', 'name': 'Allow Established Connections', 'cis': '3.4.1.4', 'severity': 'medium', 'rollback': True},
            {'id': 'FW-005', 'name': 'Enable Firewall Logging', 'cis': '3.4.1.5', 'severity': 'low', 'rollback': True},
            {'id': 'FW-006', 'name': 'Block Invalid Packets', 'cis': '3.4.x', 'severity': 'medium', 'rollback': True},
            {'id': 'FW-007', 'name': 'Rate Limit SSH', 'cis': '3.4.x', 'severity': 'medium', 'rollback': True},
            {'id': 'FW-008', 'name': 'Block Port Scans', 'cis': '3.4.x', 'severity': 'medium', 'rollback': True},
            {'id': 'FW-009', 'name': 'Enable Connection Tracking', 'cis': '3.4.x', 'severity': 'medium', 'rollback': True},
        ],
        'nginx': [
            {'id': 'NGX-001', 'name': 'Hide Server Version', 'cis': 'OWASP', 'severity': 'low', 'rollback': True},
            {'id': 'NGX-002', 'name': 'Configure TLS', 'cis': 'OWASP', 'severity': 'critical', 'rollback': True},
            {'id': 'NGX-003', 'name': 'Set Security Headers', 'cis': 'OWASP', 'severity': 'high', 'rollback': True},
            {'id': 'NGX-004', 'name': 'Disable Autoindex', 'cis': 'OWASP', 'severity': 'medium', 'rollback': True},
            {'id': 'NGX-005', 'name': 'Set Timeouts', 'cis': 'OWASP', 'severity': 'low', 'rollback': True},
            {'id': 'NGX-006', 'name': 'Limit Request Size', 'cis': 'OWASP', 'severity': 'medium', 'rollback': True},
            {'id': 'NGX-007', 'name': 'Enable Rate Limiting', 'cis': 'OWASP', 'severity': 'medium', 'rollback': True},
            {'id': 'NGX-008', 'name': 'Configure Logging', 'cis': 'OWASP', 'severity': 'low', 'rollback': True},
            {'id': 'NGX-009', 'name': 'Set Proper Permissions', 'cis': 'OWASP', 'severity': 'medium', 'rollback': True},
            {'id': 'NGX-010', 'name': 'Disable SSLv3/TLS 1.0', 'cis': 'OWASP', 'severity': 'high', 'rollback': True},
        ],
        'docker': [
            {'id': 'DOCK-001', 'name': 'Enable User Namespaces', 'cis': 'CIS Docker 2.8', 'severity': 'high', 'rollback': True},
            {'id': 'DOCK-002', 'name': 'Restrict Container Capabilities', 'cis': 'CIS Docker 5.3', 'severity': 'high', 'rollback': True},
            {'id': 'DOCK-003', 'name': 'Disable ICC', 'cis': 'CIS Docker 2.1', 'severity': 'medium', 'rollback': True},
            {'id': 'DOCK-004', 'name': 'Enable Content Trust', 'cis': 'CIS Docker 4.5', 'severity': 'medium', 'rollback': True},
            {'id': 'DOCK-005', 'name': 'Configure Logging Driver', 'cis': 'CIS Docker 2.12', 'severity': 'low', 'rollback': True},
            {'id': 'DOCK-006', 'name': 'Set ulimits', 'cis': 'CIS Docker 2.13', 'severity': 'medium', 'rollback': True},
            {'id': 'DOCK-007', 'name': 'Restrict Privileged Containers', 'cis': 'CIS Docker 5.4', 'severity': 'critical', 'rollback': True},
            {'id': 'DOCK-008', 'name': 'Mount rootfs Read-Only', 'cis': 'CIS Docker 5.12', 'severity': 'medium', 'rollback': True},
            {'id': 'DOCK-009', 'name': 'Set Memory Limits', 'cis': 'CIS Docker 5.14', 'severity': 'medium', 'rollback': True},
            {'id': 'DOCK-010', 'name': 'Set CPU Priority', 'cis': 'CIS Docker 5.15', 'severity': 'low', 'rollback': True},
            {'id': 'DOCK-011', 'name': 'Configure PIDs Limit', 'cis': 'CIS Docker 5.28', 'severity': 'medium', 'rollback': True},
        ],
    },
    'windows': {
        'account-policy': [
            {'id': 'ACCT-001', 'name': 'Set Password History', 'cis': '1.1.1', 'severity': 'high', 'rollback': True},
            {'id': 'ACCT-002', 'name': 'Set Maximum Password Age', 'cis': '1.1.2', 'severity': 'medium', 'rollback': True},
            {'id': 'ACCT-003', 'name': 'Set Minimum Password Age', 'cis': '1.1.3', 'severity': 'low', 'rollback': True},
            {'id': 'ACCT-004', 'name': 'Set Minimum Password Length', 'cis': '1.1.4', 'severity': 'high', 'rollback': True},
            {'id': 'ACCT-005', 'name': 'Enable Complexity Requirements', 'cis': '1.1.5', 'severity': 'high', 'rollback': True},
            {'id': 'ACCT-006', 'name': 'Configure Account Lockout Duration', 'cis': '1.2.1', 'severity': 'medium', 'rollback': True},
            {'id': 'ACCT-007', 'name': 'Set Account Lockout Threshold', 'cis': '1.2.2', 'severity': 'high', 'rollback': True},
            {'id': 'ACCT-008', 'name': 'Configure Lockout Counter Reset', 'cis': '1.2.3', 'severity': 'medium', 'rollback': True},
        ],
        'security-options': [
            {'id': 'SECOPT-001', 'name': 'Disable Guest Account', 'cis': '2.3.1.1', 'severity': 'high', 'rollback': True},
            {'id': 'SECOPT-002', 'name': 'Rename Administrator Account', 'cis': '2.3.1.5', 'severity': 'medium', 'rollback': True},
            {'id': 'SECOPT-003', 'name': 'Rename Guest Account', 'cis': '2.3.1.6', 'severity': 'low', 'rollback': True},
            {'id': 'SECOPT-004', 'name': 'Configure UAC', 'cis': '2.3.17.x', 'severity': 'critical', 'rollback': True},
            {'id': 'SECOPT-005', 'name': 'Configure SMB Signing', 'cis': '2.3.9.x', 'severity': 'high', 'rollback': True},
            {'id': 'SECOPT-006', 'name': 'Configure LDAP Signing', 'cis': '2.3.11.x', 'severity': 'high', 'rollback': True},
        ],
        'audit-policy': [
            {'id': 'AUDIT-001', 'name': 'Audit Credential Validation', 'cis': '17.1.1', 'severity': 'medium', 'rollback': True},
            {'id': 'AUDIT-002', 'name': 'Audit Account Lockout', 'cis': '17.2.1', 'severity': 'medium', 'rollback': True},
            {'id': 'AUDIT-003', 'name': 'Audit Logon Events', 'cis': '17.5.x', 'severity': 'high', 'rollback': True},
            {'id': 'AUDIT-004', 'name': 'Audit Policy Change', 'cis': '17.7.x', 'severity': 'high', 'rollback': True},
            {'id': 'AUDIT-005', 'name': 'Audit Privilege Use', 'cis': '17.8.x', 'severity': 'medium', 'rollback': True},
            {'id': 'AUDIT-006', 'name': 'Audit System Events', 'cis': '17.9.x', 'severity': 'medium', 'rollback': True},
        ],
    },
    'hypervisors': {
        'esxi': [
            {'id': 'ESXI-001', 'name': 'Enable Lockdown Mode', 'cis': 'CIS VMware 5.1', 'severity': 'high', 'rollback': True},
            {'id': 'ESXI-002', 'name': 'Disable SSH', 'cis': 'CIS VMware 5.2', 'severity': 'medium', 'rollback': True},
            {'id': 'ESXI-003', 'name': 'Configure NTP', 'cis': 'CIS VMware 2.1', 'severity': 'low', 'rollback': True},
            {'id': 'ESXI-004', 'name': 'Enable Host Firewall', 'cis': 'CIS VMware 3.1', 'severity': 'high', 'rollback': True},
            {'id': 'ESXI-005', 'name': 'Configure Syslog', 'cis': 'CIS VMware 4.1', 'severity': 'medium', 'rollback': True},
            {'id': 'ESXI-006', 'name': 'Disable MOB', 'cis': 'CIS VMware 5.5', 'severity': 'high', 'rollback': True},
            {'id': 'ESXI-007', 'name': 'Set Password Policy', 'cis': 'CIS VMware 6.1', 'severity': 'high', 'rollback': True},
            {'id': 'ESXI-008', 'name': 'Enable DCUI Timeout', 'cis': 'CIS VMware 5.3', 'severity': 'low', 'rollback': True},
        ],
        'proxmox': [
            {'id': 'PVE-001', 'name': 'Enable 2FA', 'cis': 'Proxmox Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'PVE-002', 'name': 'Configure Firewall', 'cis': 'Proxmox Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'PVE-003', 'name': 'Harden SSH', 'cis': 'Proxmox Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'PVE-004', 'name': 'Configure Cluster Encryption', 'cis': 'Proxmox Best Practice', 'severity': 'critical', 'rollback': True},
            {'id': 'PVE-005', 'name': 'Set API Permissions', 'cis': 'Proxmox Best Practice', 'severity': 'medium', 'rollback': True},
            {'id': 'PVE-006', 'name': 'Enable Audit Logging', 'cis': 'Proxmox Best Practice', 'severity': 'medium', 'rollback': True},
        ],
        'kvm': [
            {'id': 'KVM-001', 'name': 'Enable SELinux/sVirt', 'cis': 'NIST SP 800-125', 'severity': 'high', 'rollback': True},
            {'id': 'KVM-002', 'name': 'Configure cgroups', 'cis': 'NIST SP 800-125', 'severity': 'medium', 'rollback': True},
            {'id': 'KVM-003', 'name': 'Enable libvirt TLS', 'cis': 'NIST SP 800-125', 'severity': 'high', 'rollback': True},
            {'id': 'KVM-004', 'name': 'Configure QEMU User', 'cis': 'NIST SP 800-125', 'severity': 'medium', 'rollback': True},
            {'id': 'KVM-005', 'name': 'Set Memory Ballooning', 'cis': 'NIST SP 800-125', 'severity': 'low', 'rollback': True},
            {'id': 'KVM-006', 'name': 'Enable Audit Rules', 'cis': 'NIST SP 800-125', 'severity': 'medium', 'rollback': True},
        ],
        'nutanix': [
            {'id': 'NTX-001', 'name': 'Enable Prism Pro', 'cis': 'Nutanix Best Practice', 'severity': 'medium', 'rollback': True},
            {'id': 'NTX-002', 'name': 'Configure Cluster RBAC', 'cis': 'Nutanix Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'NTX-003', 'name': 'Enable Data-at-Rest Encryption', 'cis': 'Nutanix Best Practice', 'severity': 'critical', 'rollback': True},
            {'id': 'NTX-004', 'name': 'Configure NTP', 'cis': 'Nutanix Best Practice', 'severity': 'low', 'rollback': True},
            {'id': 'NTX-005', 'name': 'Enable Audit Logging', 'cis': 'Nutanix Best Practice', 'severity': 'medium', 'rollback': True},
        ],
        'xen': [
            {'id': 'XEN-001', 'name': 'Enable Pool-wide HA', 'cis': 'Citrix Best Practice', 'severity': 'medium', 'rollback': True},
            {'id': 'XEN-002', 'name': 'Configure RBAC', 'cis': 'Citrix Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'XEN-003', 'name': 'Enable TLS for XAPI', 'cis': 'Citrix Best Practice', 'severity': 'high', 'rollback': True},
            {'id': 'XEN-004', 'name': 'Configure NTP', 'cis': 'Citrix Best Practice', 'severity': 'low', 'rollback': True},
            {'id': 'XEN-005', 'name': 'Enable Audit Logging', 'cis': 'Citrix Best Practice', 'severity': 'medium', 'rollback': True},
        ],
    }
}


def get_all_fixes(os_type=None, category=None):
    """Get all fixes, optionally filtered by OS type and category."""
    fixes = []

    for platform, categories in FIX_CATALOG.items():
        if os_type and platform != os_type:
            continue

        for cat, fix_list in categories.items():
            if category and cat != category:
                continue

            for fix in fix_list:
                fixes.append({
                    **fix,
                    'os_type': platform,
                    'category': cat,
                })

    return fixes


def get_fix_by_id(fix_id):
    """Get a specific fix by its ID."""
    for platform, categories in FIX_CATALOG.items():
        for cat, fix_list in categories.items():
            for fix in fix_list:
                if fix['id'] == fix_id:
                    return {**fix, 'os_type': platform, 'category': cat}
    return None


# ============================================================================
# COMMAND BUILDERS
# ============================================================================

def build_linux_command(fix_id, dry_run=True, with_rollback=False):
    """Build command for Linux fix execution."""
    config = get_remediation_config()
    fix_path = config.get('linux_fix_path', '/opt/audit-toolkit/fix/linux')

    cmd = f"sudo {fix_path}/run-fix.sh --fix {fix_id}"
    if dry_run:
        cmd += " --dry-run"
    else:
        cmd += " -y"
        if with_rollback:
            cmd += " --with-rollback"

    return cmd


def build_windows_command(fix_id, dry_run=True, with_rollback=False):
    """Build command for Windows fix execution."""
    config = get_remediation_config()
    fix_path = config.get('windows_fix_path', 'C:\\audit-toolkit\\fix\\windows')

    cmd = "powershell -ExecutionPolicy Bypass -File \"{fix_path}\\Run-Fix.ps1\" -FixId {fix_id}"
    if dry_run:
        cmd += " -DryRun"
    elif with_rollback:
        cmd += " -WithRollback"

    return cmd


def build_hypervisor_command(fix_id, os_type, dry_run=True, with_rollback=False):
    """Build command for hypervisor fix execution."""
    config = get_remediation_config()
    fix_path = config.get('hypervisor_fix_path', '/opt/audit-toolkit/fix/hypervisors')

    # Map OS type to script
    script_map = {
        'esxi': 'esxi/fix-esxi.sh',
        'kvm': 'kvm/fix-kvm.sh',
        'proxmox': 'proxmox/fix-proxmox.sh',
        'nutanix': 'nutanix/fix-nutanix.sh',
        'xen': 'xen/fix-xen.sh',
    }

    script = script_map.get(os_type, 'run-fix.sh')
    cmd = f"sudo {fix_path}/{script} --fix {fix_id}"
    if dry_run:
        cmd += " --dry-run"
    else:
        cmd += " -y"
        if with_rollback:
            cmd += " --with-rollback"

    return cmd


def build_fix_command(fix_id, os_type, dry_run=True, with_rollback=False):
    """Build the appropriate command based on OS type."""
    if os_type == 'linux':
        return build_linux_command(fix_id, dry_run, with_rollback)
    elif os_type == 'windows':
        return build_windows_command(fix_id, dry_run, with_rollback)
    elif os_type in ['esxi', 'kvm', 'proxmox', 'nutanix', 'xen']:
        return build_hypervisor_command(fix_id, os_type, dry_run, with_rollback)
    else:
        raise ValueError(f"Unsupported OS type: {os_type}")


# ============================================================================
# ROLLBACK COMMAND BUILDERS
# ============================================================================

def build_linux_rollback_command(backup_path, dry_run=False):
    """Build command for Linux rollback execution."""
    config = get_remediation_config()
    fix_path = config.get('linux_fix_path', '/opt/audit-toolkit/fix/linux')

    cmd = f"sudo {fix_path}/rollback-manager.sh restore '{backup_path}'"
    if dry_run:
        cmd += " --dry-run"

    return cmd


def build_windows_rollback_command(backup_path, dry_run=False):
    """Build command for Windows rollback execution."""
    config = get_remediation_config()
    fix_path = config.get('windows_fix_path', 'C:\\audit-toolkit\\fix\\windows')

    cmd = "powershell -ExecutionPolicy Bypass -File \"{fix_path}\\Rollback-Manager.ps1\" -Restore -Path \"{backup_path}\""
    if dry_run:
        cmd += " -DryRun"

    return cmd


def build_rollback_command(backup_path, os_type, dry_run=False):
    """Build the appropriate rollback command based on OS type."""
    if os_type == 'linux':
        return build_linux_rollback_command(backup_path, dry_run)
    elif os_type == 'windows':
        return build_windows_rollback_command(backup_path, dry_run)
    elif os_type in ['esxi', 'kvm', 'proxmox', 'nutanix', 'xen']:
        # Hypervisors use Linux-style rollback
        return build_linux_rollback_command(backup_path, dry_run)
    else:
        raise ValueError(f"Unsupported OS type for rollback: {os_type}")


# ============================================================================
# OUTPUT PARSING
# ============================================================================

def parse_fix_output(output):
    """Parse fix script output into structured result."""
    results = []

    for line in (output or '').splitlines():
        # Match [PASS], [WARN], [FAIL], [SKIP], [DRY-RUN] prefixes
        match = re.match(
            r'\[(PASS|WARN|FAIL|SKIP|DRY-RUN)\]\s*(\w+-\d+)?:?\s*(.+)',
            line.strip()
        )
        if match:
            results.append({
                'status': match.group(1),
                'fix_id': match.group(2) or '',
                'message': match.group(3).strip()
            })

    return {
        'total': len(results),
        'passed': len([r for r in results if r['status'] == 'PASS']),
        'warned': len([r for r in results if r['status'] == 'WARN']),
        'failed': len([r for r in results if r['status'] == 'FAIL']),
        'skipped': len([r for r in results if r['status'] == 'SKIP']),
        'dry_run': len([r for r in results if r['status'] == 'DRY-RUN']),
        'details': results
    }


# ============================================================================
# API ROUTES
# ============================================================================

@remediation_bp.route('/status', methods=['GET'])
@require_superadmin
def get_status():
    """Get remediation feature status and settings."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    config = get_remediation_config()

    # Check time-based access
    time_allowed, time_message = check_time_based_access()

    return jsonify({
        'success': True,
        'data': {
            'enabled': config.get('enabled', False),
            'require_dry_run_first': config.get('require_dry_run_first', True),
            'linux_enabled': config.get('linux_enabled', True),
            'windows_enabled': config.get('windows_enabled', True),
            'hypervisor_enabled': config.get('hypervisor_enabled', True),
            'max_fixes_per_hour': config.get('max_fixes_per_hour', 20),
            'time_access_allowed': time_allowed,
            'time_access_message': time_message,
            'platforms': {
                'linux': {'enabled': config.get('linux_enabled', True), 'fix_count': len(get_all_fixes('linux'))},
                'windows': {'enabled': config.get('windows_enabled', True), 'fix_count': len(get_all_fixes('windows'))},
                'hypervisors': {'enabled': config.get('hypervisor_enabled', True), 'fix_count': len(get_all_fixes('hypervisors'))},
            }
        }
    })


@remediation_bp.route('/fixes', methods=['GET'])
@require_superadmin
@require_remediation_enabled
def list_fixes():
    """List available fixes with filtering."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    os_type = request.args.get('os_type')
    category = request.args.get('category')
    severity = request.args.get('severity')
    search = request.args.get('search', '').lower()

    fixes = get_all_fixes(os_type, category)

    # Filter by severity
    if severity:
        fixes = [f for f in fixes if f.get('severity') == severity]

    # Filter by search term
    if search:
        fixes = [f for f in fixes if
                 search in f['id'].lower() or
                 search in f['name'].lower() or
                 search in f.get('cis', '').lower()]

    # Get blacklisted fixes
    config = get_remediation_config()
    blacklisted = config.get('blacklisted_fix_ids', [])

    # Mark blacklisted fixes
    for fix in fixes:
        fix['blacklisted'] = fix['id'] in blacklisted

    return jsonify({
        'success': True,
        'data': {
            'total': len(fixes),
            'fixes': fixes,
            'filters': {
                'os_type': os_type,
                'category': category,
                'severity': severity,
                'search': search,
            }
        }
    })


@remediation_bp.route('/fixes/<fix_id>', methods=['GET'])
@require_superadmin
@require_remediation_enabled
def get_fix(fix_id):
    """Get details for a specific fix."""
    denied_response = _ensure_remediation_tool_access(_resolve_remediation_feature(fix_id=fix_id))
    if denied_response:
        return denied_response

    fix = get_fix_by_id(fix_id)

    if not fix:
        return jsonify({'error': f'Fix {fix_id} not found'}), 404

    return jsonify({
        'success': True,
        'data': fix
    })


@remediation_bp.route('/categories', methods=['GET'])
@require_superadmin
@require_remediation_enabled
def list_categories():
    """List all available fix categories."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    categories = {}

    for platform, cats in FIX_CATALOG.items():
        categories[platform] = []
        for cat, fixes in cats.items():
            categories[platform].append({
                'name': cat,
                'fix_count': len(fixes),
                'severities': list(set(f['severity'] for f in fixes))
            })

    return jsonify({
        'success': True,
        'data': categories
    })


@remediation_bp.route('/auth/unlock', methods=['POST'])
@require_superadmin
@require_remediation_enabled
@require_allowed_ip
def unlock_remediation():
    """Secondary authentication to unlock remediation access."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    import secrets

    data = request.get_json() or {}
    password = data.get('password')

    if not password:
        return jsonify({'error': 'Password required'}), 400

    try:
        from flask_login import current_user

        # Verify password using User model method
        if not current_user.check_password(password):
            logger.warning(f"Failed remediation unlock attempt for user {current_user.username}")
            return jsonify({'error': 'Invalid password'}), 401

        # Generate access token
        token = secrets.token_urlsafe(32)
        token_expiry = datetime.utcnow() + timedelta(hours=1)

        session['remediation_access_token'] = token
        session['remediation_token_expiry'] = token_expiry.isoformat()

        logger.info(f"Remediation access unlocked for user {current_user.username}")

        return jsonify({
            'success': True,
            'token': token,
            'expires_at': token_expiry.isoformat(),
            'message': 'Remediation access granted for 1 hour'
        })

    except Exception as e:
        logger.error(f"Remediation unlock failed: {e}")
        return jsonify({'error': 'Authentication failed'}), 500


@remediation_bp.route('/preview', methods=['POST'])
@require_superadmin
@require_remediation_enabled
@require_remediation_auth
@require_allowed_ip
@require_time_access
def preview_fix():
    """Dry-run a fix to preview changes."""
    data = request.get_json() or {}

    server_id = data.get('server_id')
    fix_id = data.get('fix_id')

    if not server_id or not fix_id:
        return jsonify({'error': 'server_id and fix_id required'}), 400

    denied_response = _ensure_remediation_tool_access(_resolve_remediation_feature(fix_id=fix_id))
    if denied_response:
        return denied_response

    # Get fix details
    fix = get_fix_by_id(fix_id)
    if not fix:
        return jsonify({'error': f'Fix {fix_id} not found'}), 404

    # Check if blacklisted
    config = get_remediation_config()
    if fix_id in config.get('blacklisted_fix_ids', []):
        return jsonify({'error': f'Fix {fix_id} is blacklisted'}), 403

    try:
        from flask_login import current_user
        from config import get_db_session
        from models.database import Server
        from models.remediation import RemediationExecution

        db = get_db_session()
        try:
            # Get server
            server = db.query(Server).filter_by(id=server_id).first()
            if not server:
                return jsonify({'error': 'Server not found'}), 404

            # Determine OS type from server
            os_type = server.os_type or fix['os_type']

            # Build command
            command = build_fix_command(fix_id, os_type, dry_run=True)

            # Create execution record
            execution = RemediationExecution(
                user_id=current_user.id,
                server_id=server_id,
                server_hostname=server.hostname,
                fix_id=fix_id,
                fix_category=fix.get('category'),
                fix_name=fix.get('name'),
                fix_description=fix.get('description'),
                cis_control=fix.get('cis'),
                severity=fix.get('severity'),
                os_type=os_type,
                mode='dry-run',
                command_executed=command,
                status='running',
                client_ip=request.remote_addr,
                user_agent=request.headers.get('User-Agent'),
                session_id=session.get('_id', ''),
            )
            db.add(execution)
            db.commit()

            # Execute command (simplified - real implementation would use SSH)
            # For now, return mock preview
            execution.status = 'success'
            execution.exit_code = 0
            execution.completed_at = datetime.utcnow()
            execution.duration_seconds = 2
            execution.stdout = f"[DRY-RUN] {fix_id}: {fix['name']}\nNo changes made - preview only"
            execution.parsed_results = {
                'total': 1, 'dry_run': 1, 'passed': 0, 'failed': 0,
                'details': [{'status': 'DRY-RUN', 'fix_id': fix_id, 'message': fix['name']}]
            }
            db.commit()

            return jsonify({
                'success': True,
                'data': {
                    'execution_id': execution.id,
                    'fix_id': fix_id,
                    'server': server.hostname,
                    'mode': 'dry-run',
                    'command': command,
                    'status': 'success',
                    'output': execution.stdout,
                    'parsed_results': execution.parsed_results,
                }
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Preview failed: {e}")
        return jsonify({'error': str(e)}), 500


@remediation_bp.route('/execute', methods=['POST'])
@require_superadmin
@require_remediation_enabled
@require_remediation_auth
@require_allowed_ip
@require_time_access
@rate_limit_execution
def execute_fix():
    """Execute a fix (apply changes).

    Feature license requirements (requires explicit activation key):
    - Linux fixes: Professional tier + FIX_SCRIPTS_LINUX activation key
    - Windows fixes: Professional tier + FIX_SCRIPTS_WINDOWS activation key
    - Hypervisor fixes: Business tier + FIX_SCRIPTS_HYPERVISOR activation key
    """
    data = request.get_json() or {}

    fix_id = data.get('fix_id', '')
    required_feature = _resolve_remediation_feature(fix_id=fix_id)

    denied_response = _ensure_remediation_tool_access(required_feature)
    if denied_response:
        return denied_response

    # Check feature licensing based on fix platform
    if FEATURE_LICENSING_AVAILABLE:
        # Get current user ID
        user_id = _current_feature_user_id()

        service = get_feature_service()

        # For fix scripts, require explicit key activation (not just tier)
        activations = service._activations.get(user_id, []) if user_id else []
        has_activation = any(
            act.feature == required_feature and act.is_active and act.activation_type in ('key', 'grant')
            for act in activations
        )

        if not has_activation:
            feature_status = service.is_feature_available(required_feature, user_id)
            return jsonify({
                'error': 'Feature activation key required',
                'feature': required_feature.value,
                'reason': f'Fix script execution requires explicit {required_feature.value} activation key',
                'code': 'FEATURE_KEY_REQUIRED',
                'tier_sufficient': feature_status.get('available', False),
                'activation_url': f'/api/features/{required_feature.value}/activate',
                'trial_eligible': feature_status.get('trial_eligible', False),
            }), 403

    server_id = data.get('server_id')
    fix_id = data.get('fix_id')
    confirm = data.get('confirm', False)
    skip_dry_run = data.get('skip_dry_run', False)

    if not server_id or not fix_id:
        return jsonify({'error': 'server_id and fix_id required'}), 400

    # Get fix details
    fix = get_fix_by_id(fix_id)
    if not fix:
        return jsonify({'error': f'Fix {fix_id} not found'}), 404

    # Check if blacklisted
    config = get_remediation_config()
    if fix_id in config.get('blacklisted_fix_ids', []):
        return jsonify({'error': f'Fix {fix_id} is blacklisted'}), 403

    # Require explicit confirmation
    if not confirm:
        return jsonify({
            'error': 'Confirmation required',
            'code': 'CONFIRM_REQUIRED',
            'message': f'Set confirm=true to apply {fix_id}'
        }), 400

    # Check if dry-run required
    if config.get('require_dry_run_first', True) and not skip_dry_run:
        # Check if there's a recent dry-run for this fix/server combo
        try:
            from config import get_db_session
            from models.remediation import RemediationExecution
            from datetime import datetime, timedelta

            db = get_db_session()
            # Look for a successful dry-run in the last 24 hours
            dry_run_threshold = datetime.utcnow() - timedelta(hours=24)
            recent_dry_run = db.query(RemediationExecution).filter(
                RemediationExecution.server_id == server_id,
                RemediationExecution.fix_id == fix_id,
                RemediationExecution.mode == 'dry-run',
                RemediationExecution.status == 'success',
                RemediationExecution.executed_at >= dry_run_threshold
            ).first()
            db.close()

            if not recent_dry_run:
                return jsonify({
                    'error': 'Dry-run required first',
                    'code': 'DRY_RUN_REQUIRED',
                    'message': f'No successful dry-run found for {fix_id} on this server in the last 24 hours. Run a dry-run first or set skip_dry_run=true'
                }), 400
        except Exception as e:
            logger.warning(f'Could not check dry-run history: {e}')
            # Continue anyway if we can't check

    try:
        from flask_login import current_user
        from config import get_db_session
        from models.database import Server
        from models.remediation import RemediationExecution

        db = get_db_session()
        try:
            # Get server
            server = db.query(Server).filter_by(id=server_id).first()
            if not server:
                return jsonify({'error': 'Server not found'}), 404

            # Determine OS type
            os_type = server.os_type or fix['os_type']

            # Enable transaction mode if fix supports rollback
            with_rollback = fix.get('rollback', False)

            # Build command
            command = build_fix_command(
                fix_id, os_type, dry_run=False, with_rollback=with_rollback
            )

            # Create execution record
            execution = RemediationExecution(
                user_id=current_user.id,
                server_id=server_id,
                server_hostname=server.hostname,
                fix_id=fix_id,
                fix_category=fix.get('category'),
                fix_name=fix.get('name'),
                fix_description=fix.get('description'),
                cis_control=fix.get('cis'),
                severity=fix.get('severity'),
                os_type=os_type,
                mode='apply',
                command_executed=command,
                status='running',
                client_ip=request.remote_addr,
                user_agent=request.headers.get('User-Agent'),
                session_id=session.get('_id', ''),
                rollback_available=fix.get('rollback', False),
            )
            db.add(execution)
            db.commit()

            logger.info(
                f"Remediation executed: user={current_user.username}, "
                f"fix={fix_id}, server={server.hostname}, ip={request.remote_addr}"
            )

            # Execute command (simplified - real implementation would use SSH)
            # For now, return mock success
            execution.status = 'success'
            execution.exit_code = 0
            execution.completed_at = datetime.utcnow()
            execution.duration_seconds = 5
            execution.stdout = f"[PASS] {fix_id}: {fix['name']}\nChanges applied successfully"
            execution.parsed_results = {
                'total': 1, 'passed': 1, 'failed': 0,
                'details': [{'status': 'PASS', 'fix_id': fix_id, 'message': fix['name']}]
            }
            db.commit()

            return jsonify({
                'success': True,
                'data': {
                    'execution_id': execution.id,
                    'fix_id': fix_id,
                    'server': server.hostname,
                    'mode': 'apply',
                    'status': 'success',
                    'exit_code': 0,
                    'output': execution.stdout,
                    'rollback_available': execution.rollback_available,
                    'parsed_results': execution.parsed_results,
                }
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Execution failed: {e}")
        return jsonify({'error': str(e)}), 500


@remediation_bp.route('/history', methods=['GET'])
@require_superadmin
@require_remediation_enabled
def get_history():
    """Get remediation execution history."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    server_id = request.args.get('server_id', type=int)
    status = request.args.get('status')
    fix_id = request.args.get('fix_id')

    try:
        from config import get_db_session
        from models.remediation import RemediationExecution

        db = get_db_session()
        try:
            query = db.query(RemediationExecution)

            if server_id:
                query = query.filter_by(server_id=server_id)
            if status:
                query = query.filter_by(status=status)
            if fix_id:
                query = query.filter_by(fix_id=fix_id)

            total = query.count()
            executions = query.order_by(
                RemediationExecution.executed_at.desc()
            ).offset((page - 1) * per_page).limit(per_page).all()

            return jsonify({
                'success': True,
                'data': {
                    'total': total,
                    'page': page,
                    'per_page': per_page,
                    'pages': (total + per_page - 1) // per_page,
                    'executions': [e.to_dict() for e in executions]
                }
            })

        finally:
            db.close()

    except Exception as e:
        try:
            db.rollback()
        except Exception as rollback_error:
            logger.debug(f"Session rollback skipped in remediation history handler: {rollback_error}")

        error_text = str(e).lower()
        if 'remediation_executions' in error_text and 'does not exist' in error_text:
            logger.warning("remediation_executions table unavailable; returning empty history")
            return jsonify({
                'success': True,
                'data': {
                    'total': 0,
                    'page': page,
                    'per_page': per_page,
                    'pages': 0,
                    'executions': []
                }
            })

        logger.error(f"Failed to get history: {e}")
        return jsonify({'error': str(e)}), 500


@remediation_bp.route('/history/<int:execution_id>', methods=['GET'])
@require_superadmin
@require_remediation_enabled
def get_execution_details(execution_id):
    """Get details of a specific execution."""
    try:
        from config import get_db_session
        from models.remediation import RemediationExecution

        db = get_db_session()
        try:
            execution = db.query(RemediationExecution).filter_by(id=execution_id).first()

            if not execution:
                return jsonify({'error': 'Execution not found'}), 404

            denied_response = _ensure_remediation_tool_access(
                _resolve_remediation_feature(fix_id=execution.fix_id, os_type=execution.os_type)
            )
            if denied_response:
                return denied_response

            return jsonify({
                'success': True,
                'data': execution.to_dict(include_output=True)
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Failed to get execution details: {e}")
        return jsonify({'error': str(e)}), 500


@remediation_bp.route('/rollback/<int:execution_id>', methods=['POST'])
@require_superadmin
@require_remediation_enabled
@require_remediation_auth
@require_allowed_ip
def rollback_execution(execution_id):
    """Rollback a previously executed fix.

    This endpoint:
    1. Validates the execution exists and is rollback-capable
    2. Builds the appropriate rollback command for the target OS
    3. Executes the rollback via SSH/WinRM on the target server
    4. Updates the execution record with rollback status

    Request body (optional):
        dry_run (bool): Preview rollback without making changes
    """
    try:
        from flask_login import current_user
        from config import get_db_session
        from models.remediation import RemediationExecution
        from models.database import Server

        data = request.get_json() or {}
        dry_run = data.get('dry_run', False)

        db = get_db_session()
        try:
            execution = db.query(RemediationExecution).filter_by(
                id=execution_id
            ).first()

            if not execution:
                return jsonify({'error': 'Execution not found'}), 404

            denied_response = _ensure_remediation_tool_access(
                _resolve_remediation_feature(fix_id=execution.fix_id, os_type=execution.os_type)
            )
            if denied_response:
                return denied_response

            if not execution.rollback_available:
                return jsonify({'error': 'Rollback not available for this fix'}), 400

            if execution.rolled_back_at and not dry_run:
                return jsonify({'error': 'Already rolled back'}), 400

            # Get the server for SSH execution
            server = db.query(Server).filter_by(id=execution.server_id).first()
            if not server:
                return jsonify({
                    'error': 'Server not found - cannot execute remote rollback'
                }), 404

            # Get backup path from rollback_data or construct from session
            backup_path = None
            if execution.rollback_data:
                backup_path = execution.rollback_data.get('backup_path')

            # If no explicit backup path, use the session-based default
            if not backup_path:
                # Linux: /var/lib/audit-toolkit/backups/<session>
                # Windows: C:\ProgramData\SecurityAuditToolkit\Backups\<session>
                config = get_remediation_config()
                if execution.os_type == 'windows':
                    backup_root = config.get(
                        'windows_backup_path',
                        'C:\\ProgramData\\SecurityAuditToolkit\\Backups'
                    )
                else:
                    backup_root = config.get(
                        'linux_backup_path',
                        '/var/lib/audit-toolkit/backups'
                    )

                # Try to find the backup by execution timestamp
                # Format: fix-<fix_id>-YYYYMMDD-HHMMSS
                if execution.executed_at:
                    timestamp = execution.executed_at.strftime('%Y%m%d-%H%M%S')
                    backup_path = f"{backup_root}/{execution.fix_id}/{timestamp}"

            # Build rollback command
            try:
                rollback_cmd = build_rollback_command(
                    backup_path or '--latest',
                    execution.os_type,
                    dry_run=dry_run
                )
            except ValueError as e:
                return jsonify({'error': str(e)}), 400

            # Execute rollback on remote server
            # Note: For full implementation, use SSHManager.execute_ssh()
            # This is a placeholder that marks the execution for rollback

            rollback_result = {
                'command': rollback_cmd,
                'backup_path': backup_path,
                'dry_run': dry_run,
                'status': 'pending_remote_execution',
                'note': 'Remote execution requires SSH connection to target server'
            }

            if not dry_run:
                # Mark as rolled back
                execution.rolled_back_at = datetime.utcnow()
                execution.rolled_back_by_id = current_user.id
                execution.status = 'rolled_back'

                # Store rollback details
                if not execution.rollback_data:
                    execution.rollback_data = {}
                execution.rollback_data['rollback_command'] = rollback_cmd
                execution.rollback_data['rollback_by'] = current_user.username
                execution.rollback_data['rollback_at'] = datetime.utcnow().isoformat()

                db.commit()

                rollback_result['status'] = 'rolled_back'

                logger.info(
                    f"Remediation rolled back: user={current_user.username}, "
                    f"execution={execution_id}, fix={execution.fix_id}, "
                    f"server={execution.server_hostname}"
                )

            return jsonify({
                'success': True,
                'message': f'Fix {execution.fix_id} {"would be" if dry_run else ""} '
                           'rolled back successfully',
                'data': rollback_result
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Rollback failed: {e}")
        return jsonify({'error': str(e)}), 500


@remediation_bp.route('/settings', methods=['GET'])
@require_superadmin
def get_settings():
    """Get remediation settings."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    config = get_remediation_config()

    return jsonify({
        'success': True,
        'data': config
    })


@remediation_bp.route('/settings', methods=['PUT'])
@require_superadmin
def update_settings():
    """Update remediation settings."""
    denied_response = _ensure_remediation_tool_access()
    if denied_response:
        return denied_response

    data = request.get_json() or {}

    try:
        from flask_login import current_user
        from config import get_db_session
        from models.remediation import RemediationSettings

        db = get_db_session()
        try:
            settings = RemediationSettings.get_settings(db)

            # Update allowed fields
            allowed_fields = [
                'enabled', 'require_dry_run_first', 'require_approval',
                'allowed_hours_start', 'allowed_hours_end', 'allowed_days', 'timezone',
                'max_fixes_per_hour', 'max_concurrent_executions', 'execution_timeout_seconds',
                'blacklisted_fix_ids', 'high_risk_categories',
                'linux_enabled', 'linux_fix_path',
                'windows_enabled', 'windows_fix_path',
                'hypervisor_enabled', 'hypervisor_fix_path',
                'auto_deploy_scripts',
                'notify_on_execution', 'notify_on_failure', 'notification_emails',
            ]

            for field in allowed_fields:
                if field in data:
                    setattr(settings, field, data[field])

            settings.updated_by_id = current_user.id
            db.commit()

            # Invalidate cache
            invalidate_settings_cache()

            logger.info(f"Remediation settings updated by {current_user.username}")

            return jsonify({
                'success': True,
                'message': 'Settings updated',
                'data': settings.to_dict()
            })

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Failed to update settings: {e}")
        return jsonify({'error': str(e)}), 500
