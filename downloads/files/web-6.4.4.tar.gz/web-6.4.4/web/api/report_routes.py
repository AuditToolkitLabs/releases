"""
Report & Cleanup Routes - Remote Reports and Server Cleanup

Provides endpoints for:
- Fetching remote logs (/api/reports/servers, /api/reports/fetch/<id>)
- Generating reports (/api/reports/generate)
- Exporting reports (/api/reports/export)
- HTML Executive Reports (/api/reports/executive)
- PDF Executive Reports (/api/reports/executive/pdf)
- Server cleanup (/api/cleanup)
"""

import hashlib
import io
import json
import os
import subprocess  # nosec B404
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from functools import lru_cache
from flask import Blueprint, jsonify, request, Response

# Import from config
from config import logger

# Import auth decorators - use require_auth for session + API key support
from auth_core import require_api_key, conditional_limit, require_auth, require_role

try:
    from logging_utils import log_audit
except ImportError:
    def log_audit(*args, **kwargs):
        return None

# Feature licensing (optional — degrades gracefully if service unavailable)
try:
    from services_pkg.services.feature_licensing import Feature, get_feature_service
    _FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    _FEATURE_LICENSING_AVAILABLE = False

try:
    from services_pkg.services.reporting_query_service import ReportingQueryService
    _REPORTING_QUERY_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_QUERY_SERVICE_AVAILABLE = False

try:
    from services_pkg.services.reporting_backfill_service import ReportingBackfillService
    _REPORTING_BACKFILL_SERVICE_AVAILABLE = True
except ImportError:
    _REPORTING_BACKFILL_SERVICE_AVAILABLE = False


def _report_feature_denied(feature):
    """Return standardised 403 when a licensed report feature is unavailable, or None if available."""
    if not _FEATURE_LICENSING_AVAILABLE:
        return None
    try:
        user_id = None
        try:
            from flask_login import current_user
            if current_user and getattr(current_user, 'is_authenticated', False):
                user_id = str(current_user.id)
        except Exception:
            user_id = None
        service = get_feature_service()
        status = service.is_feature_available(feature, user_id)
    except Exception as exc:
        logger.warning(f"Feature licensing check failed for {getattr(feature, 'value', feature)}: {exc}")
        return None
    if status.get('available'):
        return None
    return jsonify({
        'error': 'Feature not available',
        'feature': feature.value,
        'reason': status.get('reason', 'Feature is not enabled for this license tier'),
        'code': 'FEATURE_UNAVAILABLE',
        'trial_eligible': status.get('trial_eligible', False),
        'upgrade_tier': status.get('upgrade_tier'),
    }), 403

# Import server management
from models.server import ServerManager

# Import SSH management
from ssh_manager import SSHManager
from encryption import ssh_host_key_manager, password_manager
from config import SSH_DIR

# Import report generators (lazy loaded)
try:
    from reports import (
        HTMLExecutiveReportGenerator,
        is_html_available,
        generate_executive_html_report,
        PDFReportGenerator,
        is_pdf_available,
        ExecutiveSummaryGenerator,
        ComplianceTemplates
    )
    HTML_REPORTS_AVAILABLE = is_html_available()
    PDF_REPORTS_AVAILABLE = is_pdf_available()
except (ImportError, OSError):
    # OSError occurs when weasyprint can't load native GTK/GObject libraries
    HTML_REPORTS_AVAILABLE = False
    PDF_REPORTS_AVAILABLE = False

# Create blueprint
report_bp = Blueprint('reports', __name__)

# Initialize managers
server_manager = ServerManager()
ssh_manager = SSHManager(
    ssh_dir=SSH_DIR,
    ssh_host_key_manager=ssh_host_key_manager,
    password_manager=password_manager
)
reporting_query_service = ReportingQueryService() if _REPORTING_QUERY_SERVICE_AVAILABLE else None
reporting_backfill_service = ReportingBackfillService() if _REPORTING_BACKFILL_SERVICE_AVAILABLE else None


def _serialize_reporting_finding(finding):
    """Serialize a persisted canonical reporting finding row."""
    asset = finding.reporting_asset
    observation = finding.reporting_observation
    data_source = observation.reporting_data_source if observation else None
    return {
        'finding_uid': finding.finding_uid,
        'title': finding.title,
        'category': finding.category,
        'severity': finding.severity,
        'priority_score': finding.priority_score,
        'status': finding.status,
        'description': finding.description,
        'remediation': finding.remediation,
        'external_reference': finding.external_reference,
        'first_observed_at': finding.first_observed_at.isoformat() if finding.first_observed_at else None,
        'last_observed_at': finding.last_observed_at.isoformat() if finding.last_observed_at else None,
        'asset': asset.to_dict() if asset else None,
        'observation': {
            'id': observation.id,
            'observation_type': observation.observation_type,
            'collected_at': observation.collected_at.isoformat() if observation.collected_at else None,
            'effective_at': observation.effective_at.isoformat() if observation.effective_at else None,
            'confidence_score': observation.confidence_score,
            'raw_summary': observation.raw_summary,
            'metadata_json': observation.metadata_json,
        } if observation else None,
        'source': {
            'source_code': data_source.source_code,
            'source_name': data_source.source_name,
            'source_type': data_source.source_type,
            'collection_method': data_source.collection_method,
            'trust_level': data_source.trust_level,
        } if data_source else None,
    }


def _serialize_reporting_control_evaluation(control_evaluation):
    """Serialize a persisted canonical reporting control evaluation row."""
    asset = control_evaluation.reporting_asset
    observation = control_evaluation.reporting_observation
    data_source = observation.reporting_data_source if observation else None
    return {
        'id': control_evaluation.id,
        'framework': control_evaluation.framework,
        'control_id': control_evaluation.control_id,
        'control_family': control_evaluation.control_family,
        'status': control_evaluation.status,
        'score': control_evaluation.score,
        'evidence_summary': control_evaluation.evidence_summary,
        'evaluated_at': control_evaluation.evaluated_at.isoformat() if control_evaluation.evaluated_at else None,
        'asset': asset.to_dict() if asset else None,
        'observation': {
            'id': observation.id,
            'observation_type': observation.observation_type,
            'collected_at': observation.collected_at.isoformat() if observation.collected_at else None,
            'effective_at': observation.effective_at.isoformat() if observation.effective_at else None,
            'confidence_score': observation.confidence_score,
            'raw_summary': observation.raw_summary,
            'metadata_json': observation.metadata_json,
        } if observation else None,
        'source': {
            'source_code': data_source.source_code,
            'source_name': data_source.source_name,
            'source_type': data_source.source_type,
            'collection_method': data_source.collection_method,
            'trust_level': data_source.trust_level,
        } if data_source else None,
    }


def _default_support_email() -> str | None:
    support_email = os.environ.get('SUPPORT_EMAIL', '').strip()
    return support_email or None


def _pdf_unavailable_response(message: str, *, fallback_format: str, fallback_endpoint: str) -> tuple[Response, int]:
    """Return a consistent 503 response with actionable PDF fallback guidance."""
    return jsonify({
        "success": False,
        "error": message,
        "error_code": "PDF_EXPORT_UNAVAILABLE",
        "fallback_format": fallback_format,
        "fallback_endpoint": fallback_endpoint,
        "capabilities_endpoint": "/api/reports/executive/capabilities",
        "remediation": "Install the optional WeasyPrint dependency and its native libraries, or use the fallback format for this export.",
    }), 503


@lru_cache(maxsize=1)
def _load_report_schema() -> dict:
    """Load the published report schema used by external consumers."""
    schema_path = os.path.join(os.path.dirname(__file__), '..', 'reports', 'report-schema.v1.json')
    with open(schema_path, 'r', encoding='utf-8') as f:
        return json.load(f)


# ============================================================================
# Audit Execution Reports
# ============================================================================


@report_bp.route('/api/reports/schema', methods=['GET'])
@require_auth
def get_report_schema():
    """Return the published versioned schema for generated reports."""
    denied = _report_feature_denied(Feature.ADVANCED_REPORTING)
    if denied:
        return denied
    try:
        return jsonify({
            "success": True,
            "schema_version": "1.0",
            "schema": _load_report_schema()
        })
    except Exception as e:
        logger.error(f"Error loading report schema: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@report_bp.route('/api/reports/audits/<int:audit_id>')
@require_auth
def get_audit_report(audit_id):
    """
    Get detailed report for a specific audit execution

    Returns:
        {
            "success": true,
            "audit": {
                "id": 1,
                "audit_name": "updates.sh",
                "server_hostname": "server1",
                "status": "completed",
                "started_at": "...",
                "completed_at": "...",
                "duration_seconds": 45,
                "results": {
                    "pass": 10,
                    "fail": 2,
                    "warn": 1,
                    "skip": 0,
                    "total": 13
                },
                "output": "..."
            }
        }
    """
    from config import SessionLocal
    from models.database import AuditExecution, Server, Audit

    try:
        db = SessionLocal()
        try:
            execution = db.query(AuditExecution).filter(
                AuditExecution.id == audit_id
            ).first()

            if not execution:
                return jsonify({'success': False, 'error': 'Audit execution not found'}), 404

            # Get related server and audit
            server = db.query(Server).filter(Server.id == execution.server_id).first()
            audit = db.query(Audit).filter(Audit.id == execution.audit_id).first()

            if reporting_query_service is not None:
                audit_payload = reporting_query_service.build_audit_execution_report(
                    execution,
                    server=server,
                    audit=audit,
                )
            else:
                # Parse output for metrics
                results = {"pass": 0, "fail": 0, "warn": 0, "skip": 0, "total": 0}  # nosec B105
                if execution.output:
                    for line in execution.output.split('\n'):
                        if '[PASS]' in line:
                            results["pass"] += 1
                            results["total"] += 1
                        elif '[FAIL]' in line:
                            results["fail"] += 1
                            results["total"] += 1
                        elif '[WARN]' in line:
                            results["warn"] += 1
                            results["total"] += 1
                        elif '[SKIP]' in line:
                            results["skip"] += 1
                            results["total"] += 1

                duration = None
                if execution.executed_at and execution.completed_at:
                    duration = (execution.completed_at - execution.executed_at).total_seconds()

                audit_payload = {
                    'id': execution.id,
                    'audit_name': audit.name if audit else 'Unknown',
                    'audit_path': audit.file_path if audit else None,
                    'server_id': execution.server_id,
                    'server_hostname': server.hostname if server else None,
                    'status': execution.status,
                    'started_at': execution.executed_at.isoformat() if execution.executed_at else None,
                    'completed_at': execution.completed_at.isoformat() if execution.completed_at else None,
                    'duration_seconds': duration,
                    'results': results,
                    'exit_code': execution.exit_code,
                    'output': execution.output
                }

            return jsonify({
                'success': True,
                'audit': audit_payload
            })
        finally:
            db.close()

    except Exception as e:
        logger.error(f"Error getting audit report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/audit-executions/<int:audit_id>', methods=['GET'])
@require_auth
def get_audit_execution_canonical_report(audit_id):
    """Return canonical reporting payload for a persisted audit execution."""
    from config import SessionLocal
    from models.database import AuditExecution, Server, Audit

    try:
        db = SessionLocal()
        try:
            execution = db.query(AuditExecution).filter(
                AuditExecution.id == audit_id
            ).first()

            if not execution:
                return jsonify({'success': False, 'error': 'Audit execution not found'}), 404

            server = db.query(Server).filter(Server.id == execution.server_id).first()
            audit = db.query(Audit).filter(Audit.id == execution.audit_id).first()

            if reporting_query_service is not None:
                canonical_payload = reporting_query_service.build_audit_execution_canonical_payload(
                    execution,
                    server=server,
                    audit=audit,
                )
            else:
                canonical_payload = {
                    'asset': None,
                    'asset_link': None,
                    'observation': None,
                    'finding': None,
                    'source_record': {
                        'execution_id': execution.id,
                        'server_id': execution.server_id,
                        'audit_id': execution.audit_id,
                        'audit_name': audit.name if audit else None,
                        'server_hostname': server.hostname if server else None,
                    },
                }

            return jsonify({'success': True, 'canonical': canonical_payload})
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error getting canonical audit execution report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/findings', methods=['GET'])
@require_auth
def list_reporting_findings():
    """List canonical findings from persisted reporting tables."""
    from config import SessionLocal
    from models.reporting import ReportingFinding, ReportingObservation
    from sqlalchemy.orm import joinedload

    try:
        severity = request.args.get('severity')
        status = request.args.get('status')
        limit = min(max(request.args.get('limit', 50, type=int) or 50, 1), 200)

        db = SessionLocal()
        try:
            query = db.query(ReportingFinding).options(
                joinedload(ReportingFinding.reporting_asset),
                joinedload(ReportingFinding.reporting_observation).joinedload(ReportingObservation.reporting_data_source),
            )

            if severity:
                query = query.filter(ReportingFinding.severity == severity)
            if status:
                query = query.filter(ReportingFinding.status == status)

            findings = query.order_by(ReportingFinding.updated_at.desc()).limit(limit).all()
            payload = [_serialize_reporting_finding(finding) for finding in findings]

            return jsonify({
                'success': True,
                'findings': payload,
                'count': len(payload),
                'filters': {
                    'severity': severity,
                    'status': status,
                    'limit': limit,
                },
                'reporting_context': {
                    'assembly_mode': 'persisted_reporting_findings',
                    'source': 'reporting_tables',
                },
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error listing reporting findings: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/findings/<string:finding_uid>', methods=['GET'])
@require_auth
def get_reporting_finding(finding_uid):
    """Return one canonical finding from persisted reporting tables."""
    from config import SessionLocal
    from models.reporting import ReportingFinding, ReportingObservation
    from sqlalchemy.orm import joinedload

    try:
        db = SessionLocal()
        try:
            finding = db.query(ReportingFinding).options(
                joinedload(ReportingFinding.reporting_asset),
                joinedload(ReportingFinding.reporting_observation).joinedload(ReportingObservation.reporting_data_source),
            ).filter(ReportingFinding.finding_uid == finding_uid).first()

            if not finding:
                return jsonify({'success': False, 'error': 'Reporting finding not found'}), 404

            return jsonify({
                'success': True,
                'finding': _serialize_reporting_finding(finding),
                'reporting_context': {
                    'assembly_mode': 'persisted_reporting_finding',
                    'source': 'reporting_tables',
                },
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error getting reporting finding {finding_uid}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/control-evaluations', methods=['GET'])
@require_auth
def list_reporting_control_evaluations():
    """List canonical control evaluations from persisted reporting tables."""
    from config import SessionLocal
    from models.reporting import ReportingControlEvaluation, ReportingObservation
    from sqlalchemy.orm import joinedload

    try:
        framework = request.args.get('framework')
        status = request.args.get('status')
        limit = min(max(request.args.get('limit', 50, type=int) or 50, 1), 200)

        db = SessionLocal()
        try:
            query = db.query(ReportingControlEvaluation).options(
                joinedload(ReportingControlEvaluation.reporting_asset),
                joinedload(ReportingControlEvaluation.reporting_observation).joinedload(ReportingObservation.reporting_data_source),
            )

            if framework:
                query = query.filter(ReportingControlEvaluation.framework == framework)
            if status:
                query = query.filter(ReportingControlEvaluation.status == status)

            control_evaluations = query.order_by(ReportingControlEvaluation.evaluated_at.desc()).limit(limit).all()
            payload = [
                _serialize_reporting_control_evaluation(control_evaluation)
                for control_evaluation in control_evaluations
            ]

            return jsonify({
                'success': True,
                'control_evaluations': payload,
                'count': len(payload),
                'filters': {
                    'framework': framework,
                    'status': status,
                    'limit': limit,
                },
                'reporting_context': {
                    'assembly_mode': 'persisted_reporting_control_evaluations',
                    'source': 'reporting_tables',
                },
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error listing reporting control evaluations: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/control-evaluations/<int:control_evaluation_id>', methods=['GET'])
@require_auth
def get_reporting_control_evaluation(control_evaluation_id):
    """Return one canonical control evaluation from persisted reporting tables."""
    from config import SessionLocal
    from models.reporting import ReportingControlEvaluation, ReportingObservation
    from sqlalchemy.orm import joinedload

    try:
        db = SessionLocal()
        try:
            control_evaluation = db.query(ReportingControlEvaluation).options(
                joinedload(ReportingControlEvaluation.reporting_asset),
                joinedload(ReportingControlEvaluation.reporting_observation).joinedload(ReportingObservation.reporting_data_source),
            ).filter(ReportingControlEvaluation.id == control_evaluation_id).first()

            if not control_evaluation:
                return jsonify({'success': False, 'error': 'Reporting control evaluation not found'}), 404

            return jsonify({
                'success': True,
                'control_evaluation': _serialize_reporting_control_evaluation(control_evaluation),
                'reporting_context': {
                    'assembly_mode': 'persisted_reporting_control_evaluation',
                    'source': 'reporting_tables',
                },
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error getting reporting control evaluation {control_evaluation_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/backfill/history', methods=['GET'])
@require_role('Admin', 'SuperAdmin')
def get_reporting_backfill_history():
    """Return recent audit-log history for manual reporting backfills."""
    from config import SessionLocal
    from models.audit_log import AuditLog

    try:
        raw_limit = request.args.get('limit', default=20, type=int)
        if raw_limit is None:
            raw_limit = 20
        limit = min(max(raw_limit, 1), 100)
        success_param = request.args.get('success')
        success_filter = None

        if success_param is not None:
            normalized_success = success_param.strip().lower()
            if normalized_success not in {'true', 'false'}:
                return jsonify({
                    'success': False,
                    'error': 'Invalid success filter. Expected true or false.',
                }), 400
            success_filter = normalized_success == 'true'

        db = SessionLocal()
        try:
            query = db.query(AuditLog).filter(
                AuditLog.action == 'backfill_reporting_tables',
                AuditLog.resource_type == 'reporting_tables',
            )

            if success_param is not None:
                query = query.filter(AuditLog.success == success_filter)

            logs = query.order_by(AuditLog.timestamp.desc()).limit(limit).all()
            payload = [
                {
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat() if log.timestamp else None,
                    'user_id': log.user_id,
                    'success': log.success,
                    'error': log.error_message,
                    'details': log.details or {},
                }
                for log in logs
            ]

            log_audit(
                action='view_reporting_backfill_history',
                resource_id='historical_reporting',
                resource_type='reporting_tables',
                details={
                    'limit': limit,
                    'success_filter': success_filter,
                    'returned_records': len(payload),
                },
                success=True,
            )

            return jsonify({
                'success': True,
                'history': payload,
                'count': len(payload),
                'filters': {
                    'limit': limit,
                    'success': success_filter,
                },
                'reporting_context': {
                    'assembly_mode': 'reporting_backfill_history',
                    'source': 'audit_log',
                },
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Error getting reporting backfill history: {e}")
        log_audit(
            action='view_reporting_backfill_history',
            resource_id='historical_reporting',
            resource_type='reporting_tables',
            success=False,
            error=str(e),
        )
        return jsonify({'success': False, 'error': str(e)}), 500


@report_bp.route('/api/reporting/backfill', methods=['POST'])
@require_role('SuperAdmin')
def backfill_reporting_tables():
    """Backfill canonical reporting tables from historical source records."""
    from config import SessionLocal

    if reporting_backfill_service is None:
        return jsonify({
            'success': False,
            'error': 'Reporting backfill service unavailable',
        }), 503

    payload = request.get_json(silent=True) or {}
    if not isinstance(payload, dict):
        return jsonify({'success': False, 'error': 'Invalid JSON payload'}), 400

    commit_every = payload.get('commit_every', 100)
    audit_limit = payload.get('audit_limit')
    assessment_limit = payload.get('assessment_limit')
    skip_audits = bool(payload.get('skip_audits', False))
    skip_assessments = bool(payload.get('skip_assessments', False))

    if not isinstance(commit_every, int) or commit_every < 1:
        return jsonify({'success': False, 'error': 'commit_every must be an integer greater than or equal to 1'}), 400
    if audit_limit is not None and (not isinstance(audit_limit, int) or audit_limit < 1):
        return jsonify({'success': False, 'error': 'audit_limit must be an integer greater than or equal to 1'}), 400
    if assessment_limit is not None and (not isinstance(assessment_limit, int) or assessment_limit < 1):
        return jsonify({'success': False, 'error': 'assessment_limit must be an integer greater than or equal to 1'}), 400
    if skip_audits and skip_assessments:
        return jsonify({'success': False, 'error': 'At least one source type must remain enabled'}), 400

    db = SessionLocal()
    try:
        if skip_audits:
            audit_summary = {'processed': 0, 'commits': 0}
        else:
            audit_summary = reporting_backfill_service.backfill_audit_executions(
                db,
                limit=audit_limit,
                commit_every=commit_every,
            )

        if skip_assessments:
            assessment_summary = {'processed': 0, 'commits': 0}
        else:
            assessment_summary = reporting_backfill_service.backfill_compliance_assessments(
                db,
                limit=assessment_limit,
                commit_every=commit_every,
            )

        log_audit(
            action='backfill_reporting_tables',
            resource_id='historical_reporting',
            resource_type='reporting_tables',
            details={
                'audit_limit': audit_limit,
                'assessment_limit': assessment_limit,
                'commit_every': commit_every,
                'skip_audits': skip_audits,
                'skip_assessments': skip_assessments,
                'audit_executions': audit_summary,
                'compliance_assessments': assessment_summary,
            },
            success=True,
        )

        return jsonify({
            'success': True,
            'backfill': {
                'audit_executions': audit_summary,
                'compliance_assessments': assessment_summary,
            },
            'filters': {
                'audit_limit': audit_limit,
                'assessment_limit': assessment_limit,
                'commit_every': commit_every,
                'skip_audits': skip_audits,
                'skip_assessments': skip_assessments,
            },
            'reporting_context': {
                'assembly_mode': 'reporting_backfill',
                'source': 'reporting_tables',
            },
        })
    except Exception as e:
        db.rollback()
        logger.error(f"Error backfilling reporting tables: {e}")
        log_audit(
            action='backfill_reporting_tables',
            resource_id='historical_reporting',
            resource_type='reporting_tables',
            details={
                'audit_limit': audit_limit,
                'assessment_limit': assessment_limit,
                'commit_every': commit_every,
                'skip_audits': skip_audits,
                'skip_assessments': skip_assessments,
            },
            success=False,
            error=str(e),
        )
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()


@report_bp.route('/api/reports/audits/<int:audit_id>/export')
@require_auth
@conditional_limit("20 per hour")
def export_audit_report(audit_id):
    """
    Export audit execution report in various formats

    Query Parameters:
        format: pdf, csv, json (default: json)

    Returns:
        - JSON: Report data as JSON
        - CSV: Downloadable CSV file
        - PDF: Downloadable PDF file
    """
    from config import SessionLocal
    from models.database import AuditExecution, Server, Audit

    try:
        export_format = request.args.get('format', 'json').lower()
        if export_format not in ('json', 'csv', 'pdf'):
            return jsonify({'error': 'Invalid format. Use: json, csv, pdf'}), 400

        db = SessionLocal()
        try:
            execution = db.query(AuditExecution).filter(
                AuditExecution.id == audit_id
            ).first()

            if not execution:
                return jsonify({'success': False, 'error': 'Audit execution not found'}), 404

            server = db.query(Server).filter(Server.id == execution.server_id).first()
            audit = db.query(Audit).filter(Audit.id == execution.audit_id).first()

            # Parse output for metrics
            results = {"pass": 0, "fail": 0, "warn": 0, "skip": 0, "total": 0}  # nosec B105
            findings = []
            if execution.output:
                for line in execution.output.split('\n'):
                    if '[PASS]' in line:
                        results["pass"] += 1
                        results["total"] += 1
                        findings.append({'status': 'PASS', 'check': line.replace('[PASS]', '').strip()})
                    elif '[FAIL]' in line:
                        results["fail"] += 1
                        results["total"] += 1
                        findings.append({'status': 'FAIL', 'check': line.replace('[FAIL]', '').strip()})
                    elif '[WARN]' in line:
                        results["warn"] += 1
                        results["total"] += 1
                        findings.append({'status': 'WARN', 'check': line.replace('[WARN]', '').strip()})
                    elif '[SKIP]' in line:
                        results["skip"] += 1
                        results["total"] += 1
                        findings.append({'status': 'SKIP', 'check': line.replace('[SKIP]', '').strip()})

            duration = None
            if execution.executed_at and execution.completed_at:
                duration = (execution.completed_at - execution.executed_at).total_seconds()

            report_data = {
                'id': execution.id,
                'audit_name': audit.name if audit else 'Unknown',
                'server_hostname': server.hostname if server else 'Unknown',
                'status': execution.status,
                'started_at': execution.executed_at.isoformat() if execution.executed_at else None,
                'completed_at': execution.completed_at.isoformat() if execution.completed_at else None,
                'duration_seconds': duration,
                'results': results,
                'findings': findings
            }

            if export_format == 'json':
                return jsonify({'success': True, 'report': report_data})

            elif export_format == 'csv':
                # Generate CSV
                import csv
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(['Status', 'Check', 'Audit', 'Server', 'Timestamp'])
                for finding in findings:
                    writer.writerow([
                        finding['status'],
                        finding['check'],
                        report_data['audit_name'],
                        report_data['server_hostname'],
                        report_data['started_at']
                    ])
                csv_content = output.getvalue()
                return Response(
                    csv_content,
                    mimetype='text/csv',
                    headers={
                        'Content-Disposition': f'attachment; filename=audit_{audit_id}_report.csv'
                    }
                )

            elif export_format == 'pdf':
                # Generate PDF
                if not PDF_REPORTS_AVAILABLE:
                    return _pdf_unavailable_response(
                        'Audit PDF generation is currently unavailable on this runtime.',
                        fallback_format='csv',
                        fallback_endpoint=f'/api/reports/audits/{audit_id}/export?format=csv'
                    )

                try:
                    generator = PDFReportGenerator()
                    pdf_bytes = generator.generate_single_audit_pdf(report_data)
                    return Response(
                        pdf_bytes,
                        mimetype='application/pdf',
                        headers={
                            'Content-Disposition': f'attachment; filename=audit_{audit_id}_report.pdf'
                        }
                    )
                except Exception as pdf_error:
                    error_msg = str(pdf_error)
                    logger.error(f"PDF generation error: {pdf_error}")
                    error_text = error_msg.lower()
                    if (
                        'weasyprint' in error_text
                        or 'not installed' in error_text
                        or 'gtk' in error_text
                        or 'gobject' in error_text
                    ):
                        return _pdf_unavailable_response(
                            f'Audit PDF generation is currently unavailable: {error_msg}',
                            fallback_format='csv',
                            fallback_endpoint=f'/api/reports/audits/{audit_id}/export?format=csv'
                        )
                    return jsonify({
                        'success': False,
                        'error': f'PDF generation failed: {error_msg}'
                    }), 500

        finally:
            db.close()

    except Exception as e:
        logger.error(f"Error exporting audit report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Log Parsing with Caching
# ============================================================================
class LRUCache:
    """Simple LRU cache implementation for log parsing"""
    def __init__(self, capacity=50):
        self.cache = OrderedDict()
        self.capacity = capacity

    def get(self, key):
        if key not in self.cache:
            return None
        self.cache.move_to_end(key)
        return self.cache[key]

    def put(self, key, value):
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        if len(self.cache) > self.capacity:
            self.cache.popitem(last=False)


_output_content_cache = LRUCache(capacity=50)


@lru_cache(maxsize=128)
def parse_audit_output_cached(output_hash):
    """Parse audit output with caching (hash-based to avoid large strings in cache)"""
    # Get actual content from global cache
    content = _output_content_cache.get(output_hash)
    if not content:
        # Content expired from cache, will be re-added on next call
        return None

    metrics = {"pass": 0, "warn": 0, "fail": 0, "skip": 0, "total": 0}  # nosec B105

    for line in content.split('\n'):
        if '[PASS]' in line:
            metrics["pass"] += 1
            metrics["total"] += 1
        elif '[WARN]' in line:
            metrics["warn"] += 1
            metrics["total"] += 1
        elif '[FAIL]' in line:
            metrics["fail"] += 1
            metrics["total"] += 1
        elif '[SKIP]' in line:
            metrics["skip"] += 1
            metrics["total"] += 1

    return metrics


def parse_audit_output(output_text):
    """Parse audit output to extract metrics (with caching)"""
    # PHASE 3 OPTIMIZATION: Cache parsed results to avoid redundant parsing
    content_hash = hashlib.sha256(output_text.encode()).hexdigest()

    # Try cached version first
    cached_result = parse_audit_output_cached(content_hash)
    if cached_result is not None:
        return cached_result

    # Not in cache, store content and parse
    _output_content_cache.put(content_hash, output_text)
    result = parse_audit_output_cached(content_hash)

    # Fallback if cache evicted immediately (shouldn't happen)
    if result is None:
        metrics = {"pass": 0, "warn": 0, "fail": 0, "skip": 0, "total": 0}  # nosec B105
        for line in output_text.split('\n'):
            if '[PASS]' in line:
                metrics["pass"] += 1
                metrics["total"] += 1
            elif '[WARN]' in line:
                metrics["warn"] += 1
                metrics["total"] += 1
            elif '[FAIL]' in line:
                metrics["fail"] += 1
                metrics["total"] += 1
            elif '[SKIP]' in line:
                metrics["skip"] += 1
                metrics["total"] += 1
        return metrics

    return metrics


# ============================================================================
# Reporting
# ============================================================================
@report_bp.route('/api/reports/servers')
@require_auth  # Accept session login OR API key
def get_report_servers():
    """Get list of servers for reporting"""
    try:
        servers = server_manager.load_servers()
        # Sanitize for API
        sanitized = [server_manager.sanitize_server_for_api(s) for s in servers]
        return jsonify({"success": True, "servers": sanitized})
    except Exception as e:
        logger.error(f"Error loading report servers: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@report_bp.route('/api/reports/fetch/<int:server_id>')
@require_auth  # Accept session login OR API key
@conditional_limit("20 per hour")
def fetch_remote_logs(server_id):
    """Fetch audit logs from a remote server with secure SSH"""
    try:
        servers = server_manager.load_servers()
        server = next((s for s in servers if s["id"] == server_id), None)

        if not server:
            return jsonify({"success": False, "error": "Server not found"}), 404

        # Ensure host key is known
        if not ssh_host_key_manager.host_known(server['host'], server.get('port', 22)):
            logger.info(f"Scanning SSH key for {server['host']} for log retrieval")
            ssh_host_key_manager.add_host_key(server['host'], server.get('port', 22))

        # Fetch log files list
        list_cmd = f"find {server['remote_path']}/logs -name '*.log' -type f -printf '%T@ %p\\n' 2>/dev/null | sort -rn | head -20 | awk '{{print $2}}'"
        result = ssh_manager.execute_command(server, list_cmd, timeout=30)

        if result.returncode != 0:
            logger.error(f"Failed to fetch logs from {server['name']}: {result.stderr}")
            return jsonify({"success": False, "error": f"Failed to fetch logs: {result.stderr}"}), 500

        log_files = result.stdout.strip().split('\n') if result.stdout.strip() else []

        # Fetch content of latest logs
        logs = []
        for log_file in log_files[:10]:  # Get latest 10 logs
            if not log_file:
                continue
            get_log_cmd = f"tail -c 50000 {log_file}"  # Last 50KB
            log_result = ssh_manager.execute_command(server, get_log_cmd, timeout=30)
            if log_result.returncode == 0:
                log_name = log_file.split('/')[-1]
                metrics = parse_audit_output(log_result.stdout)
                total = metrics.get('pass',0) + metrics.get('warn',0) + metrics.get('fail',0)
                score = 0
                if total > 0:
                    score = round((metrics.get('pass',0) + 0.5 * metrics.get('warn',0)) / total * 100, 1)
                logs.append({
                    "name": log_name,
                    "path": log_file,
                    "content": log_result.stdout,
                    "metrics": metrics,
                    "compliance_score": score
                })

        logger.info(f"Retrieved {len(logs)} logs from {server['name']}")

        return jsonify({
            "success": True,
            "server": {
                "id": server["id"],
                "name": server["name"],
                "host": server["host"]
            },
            "logs": logs,
            "timestamp": datetime.now().isoformat()
        })
    except subprocess.TimeoutExpired:
        logger.error(f"Timeout fetching logs from server {server_id}")
        return jsonify({"success": False, "error": "Connection timeout"}), 500
    except Exception as e:
        logger.error(f"Error fetching remote logs: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@report_bp.route('/api/reports/generate', methods=['POST'])
@require_auth  # Accept session login OR API key
@conditional_limit("10 per hour")
def generate_report():
    """Generate comprehensive report from multiple servers"""
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        server_ids = data.get("server_ids", [])
        report_type = data.get("report_type", "summary")

        if not server_ids or not isinstance(server_ids, list):
            return jsonify({"success": False, "error": "No servers selected"}), 400

        # Validate report type
        if report_type not in ["summary", "detailed", "comparison"]:
            return jsonify({"success": False, "error": "Invalid report type"}), 400

        servers = server_manager.load_servers()
        target_servers = [s for s in servers if s["id"] in server_ids]

        if not target_servers:
            return jsonify({"success": False, "error": "No valid servers found"}), 400

        report_servers = []

        # PERFORMANCE FIX: Parallel execution for multi-server operations
        def fetch_server_logs(server):
            """Fetch logs from single server (thread-safe)"""
            try:
                # Ensure host key is known
                if not ssh_host_key_manager.host_known(server['host'], server.get('port', 22)):
                    ssh_host_key_manager.add_host_key(server['host'], server.get('port', 22))

                # Combine commands into single SSH session for efficiency
                combined_cmd = (
                    f"latest=$(find {server['remote_path']}/logs -name '*.log' -type f "
                    f"-printf '%T@ %p\\n' 2>/dev/null | sort -rn | head -1 | awk '{{print $2}}'); "
                    "[ -n \"$latest\" ] && cat \"$latest\""
                )

                result = ssh_manager.execute_command(server, combined_cmd, timeout=60)

                if result.returncode != 0 or not result.stdout.strip():
                    return {
                        "name": server["name"],
                        "host": server["host"],
                        "status": "error",
                        "error": "No logs found or failed to fetch"
                    }

                metrics = parse_audit_output(result.stdout)

                server_report = {
                    "name": server["name"],
                    "host": server["host"],
                    "status": "success",
                    "metrics": metrics,
                    "pass_percentage": round(
                        (metrics["pass"] / metrics["total"] * 100) if metrics["total"] > 0 else 0,
                        2
                    )
                }

                if report_type == "detailed":
                    server_report["log_preview"] = result.stdout[:2000]

                return server_report

            except Exception as e:
                logger.error(f"Error fetching logs from {server['name']}: {e}")
                return {
                    "name": server["name"],
                    "host": server["host"],
                    "status": "error",
                    "error": str(e)
                }

        # Execute in parallel (max 5 concurrent connections)
        with ThreadPoolExecutor(max_workers=5) as pool:
            futures = {pool.submit(fetch_server_logs, srv): srv for srv in target_servers}

            for future in as_completed(futures):
                server_report = future.result()
                report_servers.append(server_report)

        if reporting_query_service is not None:
            report_data = reporting_query_service.build_compatibility_report(
                report_type=report_type,
                target_servers=target_servers,
                server_reports=report_servers,
            )
        else:
            report_data = {
                "title": "Security Audit Report",
                "generated": datetime.now().isoformat(),
                "schema_version": "1.0",
                "report_type": report_type,
                "servers": report_servers,
                "summary": {
                    "total_servers": len(target_servers),
                    "total_checks": 0,
                    "total_pass": 0,
                    "total_warn": 0,
                    "total_fail": 0,
                    "total_skip": 0,
                    "compliance_percentage": 0
                }
            }
            for server_report in report_servers:
                if server_report["status"] == "success":
                    metrics = server_report["metrics"]
                    report_data["summary"]["total_checks"] += metrics["total"]
                    report_data["summary"]["total_pass"] += metrics["pass"]
                    report_data["summary"]["total_warn"] += metrics["warn"]
                    report_data["summary"]["total_fail"] += metrics["fail"]
                    report_data["summary"]["total_skip"] += metrics["skip"]

            if report_data["summary"]["total_checks"] > 0:
                report_data["summary"]["compliance_percentage"] = round(
                    (report_data["summary"]["total_pass"] / report_data["summary"]["total_checks"] * 100), 2
                )

            successful_servers = sum(1 for s in report_data["servers"] if s.get("status") == "success")
            failed_servers = sum(1 for s in report_data["servers"] if s.get("status") != "success")
            total_servers = report_data["summary"]["total_servers"]
            total_checks = report_data["summary"]["total_checks"]
            total_skip = report_data["summary"]["total_skip"]

            collection_success_rate = round(
                (successful_servers / total_servers * 100) if total_servers > 0 else 0,
                2
            )
            coverage_score = round(
                ((total_checks - total_skip) / total_checks * 100) if total_checks > 0 else 0,
                2
            )

            report_data["completeness"] = {
                "collection": {
                    "successful_servers": successful_servers,
                    "failed_servers": failed_servers,
                    "collection_success_rate": collection_success_rate
                },
                "checks": {
                    "total_checks": total_checks,
                    "non_skip_checks": total_checks - total_skip,
                    "skip_checks": total_skip,
                    "coverage_score": coverage_score
                },
                "confidence_score": round((collection_success_rate + coverage_score) / 2, 2)
            }

        return jsonify({"success": True, "report": report_data})
    except Exception as e:
        logger.error(f"Error generating report: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@report_bp.route('/api/reports/export', methods=['POST'])
@require_auth  # Accept session login OR API key
@conditional_limit("30 per hour")
def export_report():
    """Export report as HTML, CSV, or JSON"""
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400

        report = data.get("report")
        export_format = data.get("format", "html")

        # Validate format
        if export_format not in ["html", "json", "csv", "sarif"]:
            return jsonify({"success": False, "error": "Invalid export format"}), 400

        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')

        if export_format == "json":
            filename = f"audit-report-{timestamp}.json"
            content = json.dumps(report, indent=2)
            mime_type = "application/json"

        elif export_format == "csv":
            filename = f"audit-report-{timestamp}.csv"
            lines = ["Server,Host,Status,Total,Pass,Warn,Fail,Skip,Pass%"]

            for server in report.get("servers", []):
                if server["status"] == "success":
                    metrics = server.get("metrics", {})
                    lines.append(
                        f"{server['name']},{server['host']},{server['status']},"
                        f"{metrics.get('total', 0)},{metrics.get('pass', 0)},"
                        f"{metrics.get('warn', 0)},{metrics.get('fail', 0)},"
                        f"{metrics.get('skip', 0)},{server.get('pass_percentage', 0)}"
                    )

            content = "\n".join(lines)
            mime_type = "text/csv"

        elif export_format == "sarif":
            sarif_denied = _report_feature_denied(Feature.SARIF_EXPORT)
            if sarif_denied:
                return sarif_denied
            filename = f"audit-report-{timestamp}.sarif.json"
            content = json.dumps(_generate_sarif_report(report), indent=2)
            mime_type = "application/sarif+json"

        else:  # HTML
            filename = f"audit-report-{timestamp}.html"
            content = _generate_html_report(report)
            mime_type = "text/html"

        return jsonify({
            "success": True,
            "filename": filename,
            "content": content,
            "mime_type": mime_type
        })
    except Exception as e:
        logger.error(f"Error exporting report: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


def _generate_html_report(report):
    """Generate HTML report from report data"""
    html_template = """<!DOCTYPE html>
<html>
<head>
    <title>{report.get('title', 'Audit Report')}</title>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .report {{ background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2563eb; border-bottom: 3px solid #2563eb; padding-bottom: 10px; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin: 20px 0; }}
        .summary-card {{ background: #f9fafb; padding: 15px; border-radius: 6px; text-align: center; border-left: 4px solid #2563eb; }}
        .summary-card.pass {{ border-left-color: #10b981; }}
        .summary-card.warn {{ border-left-color: #f59e0b; }}
        .summary-card.fail {{ border-left-color: #ef4444; }}
        .summary-card h3 {{ margin: 0 0 10px 0; font-size: 12px; color: #666; text-transform: uppercase; }}
        .summary-card .value {{ font-size: 28px; font-weight: bold; }}
        .server-section {{ margin: 30px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 6px; }}
        .server-header {{ display: flex; justify-content: space-between; align-items: center; }}
        .server-name {{ font-size: 18px; font-weight: bold; color: #1f2937; }}
        .server-host {{ color: #6b7280; font-size: 14px; }}
        .metrics-table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
        .metrics-table th {{ background: #f3f4f6; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #e5e7eb; }}
        .metrics-table td {{ padding: 10px 12px; border-bottom: 1px solid #e5e7eb; }}
        .status {{ padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }}
        .status.success {{ background: #d1fae5; color: #065f46; }}
        .status.error {{ background: #fee2e2; color: #991b1b; }}
        .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 12px; text-align: center; }}
    </style>
</head>
<body>
<div class='report'>
    <h1>{report.get('title', 'Audit Report')}</h1>
    <p>Generated: {report.get('generated')}</p>
    <div class='summary-grid'>
        <div class='summary-card'><h3>Total Checks</h3><div class='value'>{report['summary']['total_checks']}</div></div>
        <div class='summary-card pass'><h3>Pass</h3><div class='value'>{report['summary']['total_pass']}</div></div>
        <div class='summary-card warn'><h3>Warn</h3><div class='value'>{report['summary']['total_warn']}</div></div>
        <div class='summary-card fail'><h3>Fail</h3><div class='value'>{report['summary']['total_fail']}</div></div>
        <div class='summary-card'><h3>Compliance</h3><div class='value'>{report['summary']['compliance_percentage']}%</div></div>
    </div>
"""

    # Add server details
    for server in report.get("servers", []):
        status_class = "success" if server["status"] == "success" else "error"
        html_template += """    <div class='server-section'>
        <div class='server-header'>
            <div><div class='server-name'>{server['name']}</div><div class='server-host'>{server['host']}</div></div>
            <span class='status {status_class}'>{server['status'].upper()}</span>
        </div>
"""

        if server["status"] == "success":
            metrics = server.get("metrics", {})
            html_template += """        <table class='metrics-table'>
            <tr><th>Metric</th><th>Count</th></tr>
            <tr><td>Total Checks</td><td>{metrics.get('total', 0)}</td></tr>
            <tr><td>Pass</td><td style='color: #10b981; font-weight: bold;'>{metrics.get('pass', 0)}</td></tr>
            <tr><td>Warn</td><td style='color: #f59e0b; font-weight: bold;'>{metrics.get('warn', 0)}</td></tr>
            <tr><td>Fail</td><td style='color: #ef4444; font-weight: bold;'>{metrics.get('fail', 0)}</td></tr>
            <tr><td>Skip</td><td>{metrics.get('skip', 0)}</td></tr>
            <tr><td>Pass Percentage</td><td><strong>{server.get('pass_percentage', 0)}%</strong></td></tr>
        </table>
"""
        else:
            html_template += f"        <p style='color: #ef4444;'><strong>Error:</strong> {server.get('error', 'Unknown error')}</p>\n"

        html_template += "    </div>\n"

    html_template += """    <div class='footer'>
        <p>This report was generated on {report.get('generated')} by Security Audit Toolkit</p>
    </div>
</div>
</body>
</html>"""

    return html_template


def _generate_sarif_report(report):
    """Generate SARIF 2.1.0 output from report summary data."""
    rules = []
    results = []

    for server in report.get("servers", []):
        if server.get("status") != "success":
            continue

        metrics = server.get("metrics", {})
        fail_count = int(metrics.get("fail", 0))
        warn_count = int(metrics.get("warn", 0))

        if fail_count <= 0 and warn_count <= 0:
            continue

        server_id_safe = str(server.get("name", "unknown")).replace(" ", "-")

        if fail_count > 0:
            fail_rule_id = f"AUDIT-{server_id_safe}-FAIL"
            rules.append({
                "id": fail_rule_id,
                "name": f"{server.get('name', 'Server')} failed checks",
                "shortDescription": {"text": "Server has failed security checks"},
                "fullDescription": {
                    "text": f"{server.get('name', 'Server')} has {fail_count} failed checks in the generated report."
                },
                "properties": {"category": "security", "tags": ["audit", "fail"]}
            })
            results.append({
                "ruleId": fail_rule_id,
                "level": "error",
                "message": {
                    "text": f"{server.get('name', 'Server')} reported {fail_count} failed checks"
                },
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": f"servers/{server.get('name', 'unknown')}",
                            "uriBaseId": "AUDIT_ROOT"
                        }
                    }
                }]
            })

        if warn_count > 0:
            warn_rule_id = f"AUDIT-{server_id_safe}-WARN"
            rules.append({
                "id": warn_rule_id,
                "name": f"{server.get('name', 'Server')} warning checks",
                "shortDescription": {"text": "Server has warning security checks"},
                "fullDescription": {
                    "text": f"{server.get('name', 'Server')} has {warn_count} warning checks in the generated report."
                },
                "properties": {"category": "security", "tags": ["audit", "warn"]}
            })
            results.append({
                "ruleId": warn_rule_id,
                "level": "warning",
                "message": {
                    "text": f"{server.get('name', 'Server')} reported {warn_count} warning checks"
                },
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": f"servers/{server.get('name', 'unknown')}",
                            "uriBaseId": "AUDIT_ROOT"
                        }
                    }
                }]
            })

    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {
                "driver": {
                    "name": "Security Audit Toolkit",
                    "version": "1.0.0",
                    "rules": rules
                }
            },
            "results": results,
            "originalUriBaseIds": {
                "AUDIT_ROOT": {
                    "uri": "file:///audit/"
                }
            }
        }]
    }


# ============================================================================
# HTML Executive Report Endpoints
# ============================================================================
@report_bp.route('/api/reports/executive', methods=['POST'])
@require_auth
@conditional_limit("20 per hour")
def generate_executive_report():
    """
    Generate professional HTML executive report.

    Request body:
    {
        "report": {...},              # Report data from /api/reports/generate
        "organization": "Acme Corp",   # Optional: Organization name
        "compliance_framework": "PCI-DSS",  # Optional: Framework for mapping
        "classification": "Confidential",   # Optional: Document classification
        "include_charts": true,        # Optional: Include Chart.js visualizations
        "logo_url": "https://..."      # Optional: Logo URL or data URI
    }

    Returns HTML document as response.
    """
    if not HTML_REPORTS_AVAILABLE:
        return jsonify({
            "success": False,
            "error": "HTML report generation not available"
        }), 503

    try:
        data = request.json
        if not data:
            return jsonify({
                "success": False,
                "error": "Request body required"
            }), 400

        report = data.get("report")
        if not report:
            return jsonify({
                "success": False,
                "error": "Report data required"
            }), 400

        # Extract options
        organization = data.get("organization")
        compliance_framework = data.get("compliance_framework")
        classification = data.get("classification", "Confidential")
        include_charts = data.get("include_charts", True)
        logo_url = data.get("logo_url")
        contact_email = data.get("contact_email") or _default_support_email()

        # Generate executive summary if needed
        executive_summary = None
        if data.get("include_executive_summary", True):
            try:
                summary_gen = ExecutiveSummaryGenerator(
                    organization=organization,
                    industry=data.get("industry", "default")
                )
                executive_summary = summary_gen.generate_summary(report)
            except Exception as e:
                logger.warning(f"Executive summary generation failed: {e}")

        # Generate compliance mapping if framework specified
        compliance_mapping = None
        if compliance_framework:
            try:
                templates = ComplianceTemplates()
                compliance_mapping = templates.map_audit_results(
                    report, compliance_framework
                )
            except Exception as e:
                logger.warning(f"Compliance mapping failed: {e}")

        # Generate HTML report
        generator = HTMLExecutiveReportGenerator(
            organization=organization,
            logo_url=logo_url,
            contact_email=contact_email,
            classification=classification,
            include_charts=include_charts
        )

        html_content = generator.generate_report(
            report,
            compliance_framework=compliance_framework,
            executive_summary=executive_summary,
            compliance_mapping=compliance_mapping
        )

        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        filename = f"executive-report-{timestamp}.html"

        return jsonify({
            "success": True,
            "filename": filename,
            "content": html_content,
            "mime_type": "text/html",
            "size_bytes": len(html_content.encode('utf-8')),
            "generated": datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Executive report generation failed: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@report_bp.route('/api/reports/executive/download', methods=['POST'])
@require_auth
@conditional_limit("20 per hour")
def download_executive_report():
    """
    Generate and directly download HTML executive report.

    Same parameters as /api/reports/executive but returns
    the HTML file directly for download.
    """
    if not HTML_REPORTS_AVAILABLE:
        return jsonify({
            "success": False,
            "error": "HTML report generation not available"
        }), 503

    try:
        data = request.json
        if not data or not data.get("report"):
            return jsonify({
                "success": False,
                "error": "Report data required"
            }), 400

        report = data.get("report")
        organization = data.get("organization")

        # Generate HTML report
        generator = HTMLExecutiveReportGenerator(
            organization=organization,
            logo_url=data.get("logo_url"),
            contact_email=data.get("contact_email") or _default_support_email(),
            classification=data.get("classification", "Confidential"),
            include_charts=data.get("include_charts", True)
        )

        html_content = generator.generate_report(
            report,
            compliance_framework=data.get("compliance_framework")
        )

        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        filename = f"executive-report-{timestamp}.html"

        return Response(
            html_content,
            mimetype='text/html',
            headers={
                'Content-Disposition': f'attachment; filename="{filename}"',
                'Content-Length': len(html_content.encode('utf-8'))
            }
        )

    except Exception as e:
        logger.error(f"Executive report download failed: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@report_bp.route('/api/reports/executive/pdf', methods=['POST'])
@require_auth
@conditional_limit("10 per hour")
def generate_executive_pdf():
    """
    Generate PDF from executive report using WeasyPrint.

    Same parameters as /api/reports/executive but returns
    a PDF file converted from the HTML report.
    """
    if not PDF_REPORTS_AVAILABLE:
        return _pdf_unavailable_response(
            "Executive PDF generation is currently unavailable on this runtime.",
            fallback_format="html",
            fallback_endpoint="/api/reports/executive"
        )

    try:
        data = request.json
        if not data or not data.get("report"):
            return jsonify({
                "success": False,
                "error": "Report data required"
            }), 400

        report = data.get("report")
        organization = data.get("organization")

        # Generate HTML first (without external chart.js for PDF)
        generator = HTMLExecutiveReportGenerator(
            organization=organization,
            logo_url=data.get("logo_url"),
            contact_email=data.get("contact_email") or _default_support_email(),
            classification=data.get("classification", "Confidential"),
            include_charts=False  # Disable charts for PDF (Chart.js needs JS)
        )

        html_content = generator.generate_report(
            report,
            compliance_framework=data.get("compliance_framework")
        )

        # Convert HTML to PDF using WeasyPrint
        from weasyprint import HTML, CSS

        # Additional PDF-specific CSS
        pdf_css = CSS(string='''
            @page {
                size: A4;
                margin: 1.5cm;
                @bottom-center {
                    content: "Page " counter(page) " of " counter(pages);
                    font-size: 9pt;
                    color: #666;
                }
            }
        ''')

        pdf_buffer = io.BytesIO()
        HTML(string=html_content).write_pdf(
            pdf_buffer,
            stylesheets=[pdf_css]
        )
        pdf_buffer.seek(0)
        pdf_content = pdf_buffer.getvalue()

        timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        filename = f"executive-report-{timestamp}.pdf"

        return Response(
            pdf_content,
            mimetype='application/pdf',
            headers={
                'Content-Disposition': f'attachment; filename="{filename}"',
                'Content-Length': len(pdf_content)
            }
        )

    except ImportError:
        return _pdf_unavailable_response(
            "Executive PDF generation requires the optional WeasyPrint dependency.",
            fallback_format="html",
            fallback_endpoint="/api/reports/executive"
        )
    except Exception as e:
        logger.error(f"Executive PDF generation failed: {e}")
        error_text = str(e).lower()
        if 'weasyprint' in error_text or 'gtk' in error_text or 'gobject' in error_text:
            return _pdf_unavailable_response(
                f"Executive PDF generation is currently unavailable: {e}",
                fallback_format="html",
                fallback_endpoint="/api/reports/executive"
            )
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@report_bp.route('/api/reports/executive/capabilities', methods=['GET'])
def get_report_capabilities():
    """
    Get available report generation capabilities.

    Returns which report formats are available based on installed dependencies.
    """
    return jsonify({
        "success": True,
        "capabilities": {
            "html_executive": HTML_REPORTS_AVAILABLE,
            "pdf_export": PDF_REPORTS_AVAILABLE,
            "json_export": True,
            "csv_export": True,
            "compliance_mapping": HTML_REPORTS_AVAILABLE,
            "executive_summary": HTML_REPORTS_AVAILABLE,
            "supported_frameworks": [
                "PCI-DSS 4.0",
                "SOC 2 Type II",
                "ISO 27001:2022",
                "NIST CSF",
                "CIS Controls v8"
            ] if HTML_REPORTS_AVAILABLE else []
        }
    })


# ============================================================================
# Cleanup Operations
# ============================================================================
@report_bp.route('/api/cleanup', methods=['POST'])
@require_api_key
def cleanup_remote_servers():
    """Remove toolkit from remote servers"""
    try:
        data = request.json
        server_ids = data.get('server_ids', [])
        verify = data.get('verify', True)
        full_cleanup = data.get('full_cleanup', False)

        if not server_ids:
            err = "No servers specified"
            return jsonify({"success": False, "error": err}), 400

        servers = server_manager.load_servers()
        servers_to_cleanup = [s for s in servers if s['id'] in server_ids]

        if not servers_to_cleanup:
            err = "No matching servers found"
            return jsonify({"success": False, "error": err}), 404

        results = {}

        # Use thread pool for parallel cleanup
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_server = {
                executor.submit(
                    _cleanup_server, server, verify, full_cleanup
                ): server for server in servers_to_cleanup
            }

            for future in as_completed(future_to_server):
                server = future_to_server[future]
                try:
                    # 5 minute timeout per server
                    result = future.result(timeout=300)
                    results[server['id']] = result
                except Exception as e:
                    logger.error(f"Cleanup failed for {server['name']}: {e}")
                    results[server['id']] = {
                        "success": False,
                        "server_name": server['name'],
                        "server_host": server['host'],
                        "error": str(e)
                    }

        # Count successes and failures
        successful = sum(1 for r in results.values() if r.get('success'))
        failed = len(results) - successful

        return jsonify({
            "success": True,
            "summary": {
                "total": len(results),
                "successful": successful,
                "failed": failed
            },
            "results": results
        })

    except Exception as e:
        logger.error(f"Cleanup operation error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


def _cleanup_server(server, verify=True, full_cleanup=False):
    """Remove toolkit installation from a remote server

    Args:
        server: Server dict with connection details
        verify: Verify it's our toolkit before removing
        full_cleanup: If True, also removes systemd/cron/config/logs
    """
    server_name = server.get('name', 'unknown')
    remote_path = server.get('remote_path', '/opt/security-audit-toolkit')

    logger.info(f"Starting cleanup for {server_name} at {remote_path}")

    try:
        # Step 1: Verify path exists and looks like our toolkit
        if verify:
            verify_cmd = (
                f"test -d {remote_path} && "
                f"test -f {remote_path}/orchestrator/orchestrator.sh && "
                f"echo 'VERIFIED' || echo 'NOT_FOUND'"
            )

            result = ssh_manager.execute_command(server, verify_cmd, timeout=30)

            if result.returncode != 0:
                return {
                    "success": False,
                    "server_name": server_name,
                    "server_host": server['host'],
                    "error": "Failed to verify remote path"
                }

            if 'NOT_FOUND' in result.stdout:
                return {
                    "success": True,
                    "server_name": server_name,
                    "server_host": server['host'],
                    "message": "Toolkit not found (already removed or never installed)",
                    "skipped": True
                }

        # Step 2: Stop running audits
        stop_cmd = f"pkill -f {remote_path} 2>/dev/null || true"
        ssh_manager.execute_command(server, stop_cmd, timeout=30)

        # Step 3: Get disk space before cleanup
        disk_cmd = f"du -sh {remote_path} 2>/dev/null || echo '0B'"
        disk_result = ssh_manager.execute_command(server, disk_cmd, timeout=30)
        stdout = disk_result.stdout.strip()
        if disk_result.returncode == 0 and stdout:
            disk_freed = stdout.split()[0]
        else:
            disk_freed = 'unknown'

        # Step 4: Remove installation directory
        cleanup_cmd = f"rm -rf {remote_path}"
        result = ssh_manager.execute_command(server, cleanup_cmd, timeout=120)

        if result.returncode != 0:
            return {
                "success": False,
                "server_name": server_name,
                "server_host": server['host'],
                "error": "Failed to remove toolkit directory"
            }

        extra_cleaned = []

        # Step 5: Full cleanup (systemd, cron, config, logs)
        if full_cleanup:
            # Stop and remove systemd services
            systemd_cmds = [
                "systemctl stop audit-toolkit.timer 2>/dev/null || true",
                "systemctl disable audit-toolkit.timer 2>/dev/null || true",
                "rm -f /etc/systemd/system/audit-toolkit.service",
                "rm -f /etc/systemd/system/audit-toolkit.timer",
                "systemctl daemon-reload 2>/dev/null || true"
            ]
            for cmd in systemd_cmds:
                ssh_manager.execute_command(server, cmd, timeout=30)
            extra_cleaned.append("systemd services")

            # Remove cron job
            cron_cmd = "rm -f /etc/cron.d/audit-toolkit"
            ssh_manager.execute_command(server, cron_cmd, timeout=30)
            extra_cleaned.append("cron job")

            # Remove wrapper script
            wrapper_cmd = "rm -f /usr/local/bin/audit-toolkit"
            ssh_manager.execute_command(server, wrapper_cmd, timeout=30)
            extra_cleaned.append("wrapper script")

            # Remove config directory
            config_cmd = "rm -rf /etc/audit-toolkit"
            ssh_manager.execute_command(server, config_cmd, timeout=30)
            extra_cleaned.append("config files")

            # Remove log directory
            log_cmd = "rm -rf /var/log/audit-toolkit"
            ssh_manager.execute_command(server, log_cmd, timeout=30)
            extra_cleaned.append("log files")

        # Step 6: Close SSH control master
        try:
            ssh_manager.close_control_master(server)
        except Exception as e:
            logger.debug(f"Failed to close SSH control master: {e}")

        logger.info(f"Successfully cleaned up {server_name}")

        msg = "Toolkit successfully removed"
        if full_cleanup:
            msg = "Full cleanup completed (toolkit + system files)"

        return {
            "success": True,
            "server_name": server_name,
            "server_host": server['host'],
            "message": msg,
            "disk_freed": disk_freed,
            "remote_path": remote_path,
            "extra_cleaned": extra_cleaned if full_cleanup else []
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "server_name": server_name,
            "server_host": server['host'],
            "error": "Cleanup operation timed out"
        }
    except Exception as e:
        logger.error(f"Cleanup exception for {server_name}: {e}")
        return {
            "success": False,
            "server_name": server_name,
            "server_host": server['host'],
            "error": str(e)
        }
