"""
Result Encryption Module for Fleet Agent Results

Handles transparent Fernet AES-128 encryption of fleet agent audit results
at rest in the database, with support for multiple key derivation methods.

Usage:
    from result_encryption import ResultEncryption

    enc = ResultEncryption()
    encrypted_data = enc.encrypt(result_dict, agent_id)
    decrypted_data = enc.decrypt(encrypted_data, agent_id)
"""

import json
import base64
import logging
from typing import Dict, Any, Optional, Tuple
from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)


class ResultEncryption:
    """Encrypts/decrypts fleet agent results using Fernet AES-128."""

    def __init__(self, settings_provider=None):
        """
        Initialize result encryption handler.

        Args:
            settings_provider: Callable that returns settings dict (default: from security_settings)
        """
        self.settings_provider = settings_provider
        self._key_cache = {}  # Cache derived keys per agent_id

    def _get_settings(self) -> Dict[str, Any]:
        """Get current security settings."""
        if self.settings_provider:
            return self.settings_provider()

        # Default: import from security_settings
        try:
            from security_settings import get_all_security_settings
            return get_all_security_settings()
        except Exception as e:
            logger.error(f"Failed to load settings: {e}")
            return {}

    def _is_encryption_enabled(self) -> bool:
        """Check if result encryption is enabled."""
        settings = self._get_settings()
        return settings.get('fleet_agent_result_encryption_enabled', False)

    def _derive_key(self, agent_id: str) -> Optional[bytes]:
        """
        Derive encryption key based on configured method.

        Supported methods:
        - agent_id: Key derived from agent_id + salt
        - shared: Shared key from settings
        - custom: Custom key from settings (base64-encoded)

        Args:
            agent_id: Managed agent ID

        Returns:
            Fernet-compatible key bytes, or None if derivation failed
        """
        settings = self._get_settings()
        derivation_method = settings.get('fleet_agent_result_encryption_key_derivation', 'agent_id')

        # Check cache
        cache_key = f"{agent_id}:{derivation_method}"
        if cache_key in self._key_cache:
            return self._key_cache[cache_key]

        key = None

        try:
            if derivation_method == 'agent_id':
                # Derive key from agent_id using PBKDF2HMAC
                from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
                from cryptography.hazmat.primitives import hashes

                salt = b'AuditToolManaged'  # Fixed salt for deterministic derivation
                kdf = PBKDF2HMAC(
                    algorithm=hashes.SHA256(),
                    length=32,  # 256 bits for AES-256 (Fernet requires 32 bytes)
                    salt=salt,
                    iterations=100000,
                )
                derived_bytes = kdf.derive(agent_id.encode('utf-8'))
                key = base64.urlsafe_b64encode(derived_bytes)

            elif derivation_method == 'shared':
                # Use shared key from settings or generate one
                # In production, this would be configured and rotated
                import hashlib
                shared_seed = settings.get('fleet_agent_request_signing_key', 'default-shared-seed')
                derived_bytes = hashlib.sha256(shared_seed.encode('utf-8')).digest()
                key = base64.urlsafe_b64encode(derived_bytes)

            elif derivation_method == 'custom':
                # Use custom key from settings (already base64-encoded)
                custom_key_b64 = settings.get('fleet_agent_results_encryption_key_custom', '')
                if not custom_key_b64:
                    logger.error("Custom encryption key not configured")
                    return None
                key = custom_key_b64.encode('utf-8')

            # Validate key format
            if key:
                try:
                    Fernet(key)  # Will raise if invalid
                    self._key_cache[cache_key] = key
                    return key
                except Exception as e:
                    logger.error(f"Invalid derivation for {derivation_method}: {e}")
                    return None

        except Exception as e:
            logger.error(f"Failed to derive encryption key: {e}")
            return None

        return key

    def encrypt(self, result_data: Dict[str, Any], agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Encrypt result data.

        Args:
            result_data: Audit result dictionary to encrypt
            agent_id: Managed agent ID (for key derivation)

        Returns:
            Encrypted result dict with metadata, or None if encryption failed
        """
        if not self._is_encryption_enabled():
            return None  # Encryption not enabled, return original

        key = self._derive_key(agent_id)
        if not key:
            logger.error(f"Failed to derive key for agent {agent_id}")
            return None

        try:
            cipher = Fernet(key)

            # Serialize data to JSON
            plaintext = json.dumps(result_data).encode('utf-8')

            # Encrypt
            ciphertext = cipher.encrypt(plaintext)

            # Return encrypted wrapper
            return {
                '_encrypted': True,
                '_encryption_method': 'fernet-aes128',
                '_encryption_derivation': self._get_settings().get(
                    'fleet_agent_result_encryption_key_derivation', 'agent_id'
                ),
                '_encrypted_at': __import__('datetime').datetime.utcnow().isoformat() + 'Z',
                'data': ciphertext.decode('utf-8')  # Base64 encoded by Fernet
            }

        except Exception as e:
            logger.error(f"Failed to encrypt result: {e}")
            return None

    def decrypt(self, encrypted_data: Dict[str, Any], agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Decrypt result data.

        Args:
            encrypted_data: Encrypted result dictionary from encrypt()
            agent_id: Managed agent ID (for key derivation)

        Returns:
            Decrypted result dict, or None if decryption failed
        """
        if not encrypted_data:
            return None

        # Check if data is actually encrypted
        if not encrypted_data.get('_encrypted'):
            # Not encrypted, return as-is (might be legacy or unencrypted)
            return encrypted_data

        try:
            # Get the key using the same derivation method as was used to encrypt
            # In practice, we try the currently-configured method
            key = self._derive_key(agent_id)
            if not key:
                logger.error(f"Failed to derive key for decryption (agent {agent_id})")
                return None

            cipher = Fernet(key)

            # Decrypt
            ciphertext = encrypted_data.get('data', '')
            plaintext = cipher.decrypt(ciphertext.encode('utf-8'))

            # Deserialize
            return json.loads(plaintext.decode('utf-8'))

        except InvalidToken:
            logger.error(f"Invalid encryption token for agent {agent_id} (wrong key or corrupted data)")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to deserialize decrypted data: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to decrypt result: {e}")
            return None

    def should_encrypt_result(self) -> bool:
        """Check if results should be encrypted."""
        return self._is_encryption_enabled()

    def validate_key_derivation(self) -> Tuple[bool, Optional[str]]:
        """
        Validate that key derivation is properly configured.

        Returns:
            (is_valid, error_message)
        """
        settings = self._get_settings()

        if not settings.get('fleet_agent_result_encryption_enabled'):
            return True, None  # Encryption not enabled, no validation needed

        derivation_method = settings.get('fleet_agent_result_encryption_key_derivation', 'agent_id')

        if derivation_method == 'custom':
            if not settings.get('fleet_agent_results_encryption_key_custom', '').strip():
                return False, "Custom key derivation enabled but no key configured"
        elif derivation_method not in ['agent_id', 'shared']:
            return False, f"Unknown key derivation method: {derivation_method}"

        return True, None
