#!/usr/bin/env python3
"""
Enhanced Scheduling API

Provides comprehensive scheduling features:
- Maintenance Windows (blackout periods)
- Bulk schedule operations
- Schedule execution history
- Schedule templates
- Fleet-wide scheduling

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from flask import Blueprint, jsonify, request, g
from sqlalchemy import and_, or_, func
from sqlalchemy.orm import joinedload
from datetime import datetime, timedelta
from auth_core import require_api_key, conditional_limit, require_auth_and_permission, require_auth_and_minimum_role
from config import SessionLocal, logger
from models.schedule import ScheduledAudit
from models.maintenance_window import (
    MaintenanceWindow, ScheduleExecutionLog,
    is_in_maintenance_window, get_active_windows
)
from models.database import Server, Audit

# Create blueprint
schedule_enhanced_bp = Blueprint('schedule_enhanced', __name__)


# ============================================================================
# Helper Functions
# ============================================================================

def check_window_overlap(db, new_window_type, start_time=None, end_time=None,
                         day_of_week=None, start_hour=None, duration_minutes=60,
                         server_id=None, is_global=False, exclude_id=None):
    """
    Check if a proposed maintenance window overlaps with existing windows.

    Returns:
        list: Conflicting window IDs and names, empty if no conflicts
    """
    conflicts = []

    # Get existing windows that could conflict
    query = db.query(MaintenanceWindow).filter(MaintenanceWindow.is_active.is_(True))

    if exclude_id:
        query = query.filter(MaintenanceWindow.id != exclude_id)

    # Filter by scope overlap
    if is_global:
        # Global window conflicts with all
        pass
    elif server_id:
        # Server-specific conflicts with global or same server
        query = query.filter(
            (MaintenanceWindow.is_global.is_(True)) |
            (MaintenanceWindow.server_id == server_id)
        )
    else:
        # No scope specified, only check global
        query = query.filter(MaintenanceWindow.is_global.is_(True))

    existing_windows = query.all()

    for existing in existing_windows:
        overlaps = False

        if new_window_type == 'one_time' and existing.window_type == 'one_time':
            # Both one-time: check datetime overlap
            if existing.start_time and existing.end_time and start_time and end_time:
                overlaps = not (end_time <= existing.start_time or start_time >= existing.end_time)

        elif new_window_type in ('recurring', 'daily') or existing.window_type in ('recurring', 'daily'):
            # Recurring/daily: check if same day/time
            if new_window_type == 'daily' or existing.window_type == 'daily':
                # Daily overlaps if hours overlap
                new_end_hour = (start_hour or 0) + (duration_minutes or 60) // 60
                ex_end_hour = (existing.start_hour or 0) + (existing.duration_minutes or 60) // 60
                overlaps = not (new_end_hour <= (existing.start_hour or 0) or (start_hour or 0) >= ex_end_hour)
            elif day_of_week == existing.day_of_week:
                # Same day of week, check hours
                new_end_hour = (start_hour or 0) + (duration_minutes or 60) // 60
                ex_end_hour = (existing.start_hour or 0) + (existing.duration_minutes or 60) // 60
                overlaps = not (new_end_hour <= (existing.start_hour or 0) or (start_hour or 0) >= ex_end_hour)

        if overlaps:
            conflicts.append({'id': existing.id, 'name': existing.name})

    return conflicts


# ============================================================================
# Maintenance Windows CRUD
# ============================================================================

@schedule_enhanced_bp.route('/api/maintenance-windows', methods=['GET'])
@require_auth_and_permission('view_audits')
@conditional_limit("50 per minute")
def list_maintenance_windows():
    """
    List all maintenance windows

    Query Parameters:
        server_id (int): Filter by server ID
        active_only (bool): Show only active windows (default: false)
        include_expired (bool): Include past one-time windows (default: false)

    Returns:
        JSON: List of maintenance windows
    """
    db = SessionLocal()

    try:
        query = db.query(MaintenanceWindow).options(
            joinedload(MaintenanceWindow.server)
        )

        # Apply filters
        server_id = request.args.get('server_id', type=int)
        if server_id:
            query = query.filter(
                (MaintenanceWindow.server_id == server_id) |
                (MaintenanceWindow.is_global.is_(True))
            )

        active_only = request.args.get('active_only', 'false').lower() == 'true'
        if active_only:
            query = query.filter(MaintenanceWindow.is_active.is_(True))

        include_expired = request.args.get('include_expired', 'false').lower() == 'true'
        if not include_expired:
            # Exclude past one-time windows
            query = query.filter(
                (MaintenanceWindow.window_type != 'one_time') |
                (MaintenanceWindow.end_time >= datetime.utcnow())
            )

        windows = query.order_by(MaintenanceWindow.created_at.desc()).all()

        # Check which are currently active
        now = datetime.utcnow()

        return jsonify({
            'success': True,
            'maintenance_windows': [w.to_dict() for w in windows],
            'currently_active_count': sum(1 for w in windows if w.is_in_window(now)),
            'total': len(windows)
        })

    except Exception as e:
        logger.error(f"Error listing maintenance windows: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows/<int:window_id>', methods=['GET'])
@require_auth_and_permission('view_audits')
@conditional_limit("100 per minute")
def get_maintenance_window(window_id):
    """
    Get a specific maintenance window

    Path Parameters:
        window_id (int): Window ID

    Returns:
        JSON: Maintenance window details
    """
    db = SessionLocal()

    try:
        window = db.query(MaintenanceWindow).options(
            joinedload(MaintenanceWindow.server)
        ).filter(MaintenanceWindow.id == window_id).first()

        if not window:
            return jsonify({'success': False, 'error': 'Maintenance window not found'}), 404

        data = window.to_dict()

        # Add next occurrence info
        next_start, next_end = window.get_next_window()
        data['next_occurrence'] = {
            'start': next_start.isoformat() if next_start else None,
            'end': next_end.isoformat() if next_end else None
        }

        return jsonify({
            'success': True,
            'maintenance_window': data
        })

    except Exception as e:
        logger.error(f"Error getting maintenance window {window_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows', methods=['POST'])
@require_auth_and_minimum_role('Admin')
@conditional_limit("20 per minute")
def create_maintenance_window():
    """
    Create a new maintenance window

    Request Body:
        name (str): Window name (required)
        description (str): Description (optional)
        window_type (str): 'one_time', 'recurring', or 'daily'

        # For one_time:
        start_time (str): ISO datetime for start
        end_time (str): ISO datetime for end

        # For recurring/daily:
        day_of_week (int): 0=Monday, 6=Sunday (recurring only)
        start_hour (int): Hour to start (0-23)
        start_minute (int): Minute to start (0-59, default: 0)
        duration_minutes (int): Duration in minutes (default: 60)

        # Scope:
        server_id (int): Specific server (optional)
        is_global (bool): Apply to all servers (default: false)

    Returns:
        JSON: Created maintenance window
    """
    db = SessionLocal()

    try:
        data = request.json

        # Validate required fields
        if 'name' not in data:
            return jsonify({'success': False, 'error': 'name is required'}), 400

        window_type = data.get('window_type', 'one_time')
        if window_type not in ['one_time', 'recurring', 'daily']:
            return jsonify({
                'success': False,
                'error': 'window_type must be one_time, recurring, or daily'
            }), 400

        # Validate based on window type
        if window_type == 'one_time':
            if not data.get('start_time') or not data.get('end_time'):
                return jsonify({
                    'success': False,
                    'error': 'start_time and end_time are required for one_time windows'
                }), 400

            start_time = datetime.fromisoformat(data['start_time'].replace('Z', '+00:00'))
            end_time = datetime.fromisoformat(data['end_time'].replace('Z', '+00:00'))

            if end_time <= start_time:
                return jsonify({
                    'success': False,
                    'error': 'end_time must be after start_time'
                }), 400

        elif window_type == 'recurring':
            if data.get('day_of_week') is None or data.get('start_hour') is None:
                return jsonify({
                    'success': False,
                    'error': 'day_of_week and start_hour are required for recurring windows'
                }), 400

            if not (0 <= data['day_of_week'] <= 6):
                return jsonify({
                    'success': False,
                    'error': 'day_of_week must be 0-6 (Monday-Sunday)'
                }), 400

            start_time = None
            end_time = None

        elif window_type == 'daily':
            if data.get('start_hour') is None:
                return jsonify({
                    'success': False,
                    'error': 'start_hour is required for daily windows'
                }), 400

            start_time = None
            end_time = None

        # Validate scope
        server_id = data.get('server_id')
        is_global = data.get('is_global', False)

        if server_id and is_global:
            return jsonify({
                'success': False,
                'error': 'Cannot set both server_id and is_global'
            }), 400

        if server_id:
            server = db.query(Server).filter(Server.id == server_id).first()
            if not server:
                return jsonify({'success': False, 'error': 'Server not found'}), 404

        # Check for overlapping windows
        conflicts = check_window_overlap(
            db,
            new_window_type=window_type,
            start_time=start_time if window_type == 'one_time' else None,
            end_time=end_time if window_type == 'one_time' else None,
            day_of_week=data.get('day_of_week'),
            start_hour=data.get('start_hour'),
            duration_minutes=data.get('duration_minutes', 60),
            server_id=server_id,
            is_global=is_global
        )

        if conflicts:
            return jsonify({
                'success': False,
                'error': 'Window overlaps with existing maintenance windows',
                'conflicts': conflicts
            }), 409

        # Get current user for audit trail
        current_user = getattr(g, 'user', None)
        created_by_user = getattr(current_user, 'username', None) if current_user else data.get('created_by')

        # Create window
        window = MaintenanceWindow(
            name=data['name'],
            description=data.get('description'),
            window_type=window_type,
            start_time=start_time if window_type == 'one_time' else None,
            end_time=end_time if window_type == 'one_time' else None,
            day_of_week=data.get('day_of_week'),
            start_hour=data.get('start_hour'),
            start_minute=data.get('start_minute', 0),
            duration_minutes=data.get('duration_minutes', 60),
            server_id=server_id,
            is_global=is_global,
            is_active=data.get('is_active', True),
            created_by=created_by_user
        )

        db.add(window)
        db.commit()
        db.refresh(window)

        logger.info(f"Created maintenance window: {window.name} (ID: {window.id})")

        return jsonify({
            'success': True,
            'maintenance_window': window.to_dict(),
            'message': 'Maintenance window created successfully'
        }), 201

    except ValueError as e:
        return jsonify({'success': False, 'error': f'Invalid datetime format: {e}'}), 400

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating maintenance window: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows/<int:window_id>', methods=['PUT'])
@require_auth_and_minimum_role('Admin')
@conditional_limit("20 per minute")
def update_maintenance_window(window_id):
    """
    Update a maintenance window

    Path Parameters:
        window_id (int): Window ID

    Request Body:
        Any fields from the maintenance window model

    Returns:
        JSON: Updated maintenance window
    """
    db = SessionLocal()

    try:
        window = db.query(MaintenanceWindow).filter(MaintenanceWindow.id == window_id).first()
        if not window:
            return jsonify({'success': False, 'error': 'Maintenance window not found'}), 404

        data = request.json

        # Updatable fields
        updatable_fields = [
            'name', 'description', 'is_active', 'day_of_week',
            'start_hour', 'start_minute', 'duration_minutes', 'is_global'
        ]

        for field in updatable_fields:
            if field in data:
                setattr(window, field, data[field])

        # Handle datetime fields specially
        if 'start_time' in data:
            window.start_time = datetime.fromisoformat(data['start_time'].replace('Z', '+00:00'))
        if 'end_time' in data:
            window.end_time = datetime.fromisoformat(data['end_time'].replace('Z', '+00:00'))

        # Get current user for audit trail
        current_user = getattr(g, 'user', None)
        window.updated_by = getattr(current_user, 'username', None) if current_user else None

        window.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(window)

        logger.info(f"Updated maintenance window: {window.name} (ID: {window.id})")

        return jsonify({
            'success': True,
            'maintenance_window': window.to_dict(),
            'message': 'Maintenance window updated successfully'
        })

    except ValueError as e:
        return jsonify({'success': False, 'error': f'Invalid datetime format: {e}'}), 400

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating maintenance window {window_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows/<int:window_id>', methods=['DELETE'])
@require_auth_and_minimum_role('Admin')
@conditional_limit("20 per minute")
def delete_maintenance_window(window_id):
    """
    Delete a maintenance window

    Path Parameters:
        window_id (int): Window ID

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        window = db.query(MaintenanceWindow).filter(MaintenanceWindow.id == window_id).first()
        if not window:
            return jsonify({'success': False, 'error': 'Maintenance window not found'}), 404

        window_name = window.name
        db.delete(window)
        db.commit()

        logger.info(f"Deleted maintenance window: {window_name} (ID: {window_id})")

        return jsonify({
            'success': True,
            'message': f'Maintenance window "{window_name}" deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting maintenance window {window_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows/<int:window_id>/toggle', methods=['POST'])
@require_auth_and_minimum_role('Admin')
@conditional_limit("30 per minute")
def toggle_maintenance_window(window_id):
    """
    Enable or disable a maintenance window

    Path Parameters:
        window_id (int): Window ID

    Returns:
        JSON: Updated window status
    """
    db = SessionLocal()

    try:
        window = db.query(MaintenanceWindow).filter(MaintenanceWindow.id == window_id).first()
        if not window:
            return jsonify({'success': False, 'error': 'Maintenance window not found'}), 404

        window.is_active = not window.is_active
        window.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(window)

        status = 'enabled' if window.is_active else 'disabled'
        logger.info(f"Maintenance window {window.name} (ID: {window.id}) {status}")

        return jsonify({
            'success': True,
            'maintenance_window': window.to_dict(),
            'message': f'Maintenance window {status} successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error toggling maintenance window {window_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/maintenance-windows/check', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def check_maintenance_status():
    """
    Check if a server is currently in a maintenance window

    Query Parameters:
        server_id (int): Server ID to check (optional, checks global only if not provided)

    Returns:
        JSON: Current maintenance status
    """
    try:
        server_id = request.args.get('server_id', type=int)

        in_window, window_name, window_id = is_in_maintenance_window(server_id)

        return jsonify({
            'success': True,
            'in_maintenance_window': in_window,
            'window_name': window_name,
            'window_id': window_id,
            'server_id': server_id,
            'checked_at': datetime.utcnow().isoformat()
        })

    except Exception as e:
        logger.error(f"Error checking maintenance status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@schedule_enhanced_bp.route('/api/enhanced-schedule/maintenance-windows/active', methods=['GET'])
@conditional_limit("60 per minute")
def get_active_maintenance_window():
    """
    Get currently active maintenance window details (for global alert banner).

    This endpoint is accessible without authentication to allow showing
    maintenance alerts to all users.

    Returns:
        JSON: Active window details or null if none active
    """
    db = SessionLocal()

    try:
        now = datetime.utcnow()

        # Check for active one-time window
        one_time_window = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True),
            MaintenanceWindow.window_type == 'one_time',
            MaintenanceWindow.start_time <= now,
            MaintenanceWindow.end_time >= now
        ).first()

        if one_time_window:
            return jsonify({
                'success': True,
                'active_window': {
                    'id': one_time_window.id,
                    'name': one_time_window.name,
                    'window_type': one_time_window.window_type,
                    'start_time': one_time_window.start_time.isoformat() if one_time_window.start_time else None,
                    'end_time': one_time_window.end_time.isoformat() if one_time_window.end_time else None,
                    'reason': one_time_window.reason
                }
            })

        # Check for active daily window (based on current time of day)
        current_time = now.strftime('%H:%M')
        daily_windows = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True),
            MaintenanceWindow.window_type == 'daily'
        ).all()

        for window in daily_windows:
            if window.daily_start_time and window.daily_end_time:
                if window.daily_start_time <= current_time <= window.daily_end_time:
                    return jsonify({
                        'success': True,
                        'active_window': {
                            'id': window.id,
                            'name': window.name,
                            'window_type': window.window_type,
                            'daily_start_time': window.daily_start_time,
                            'daily_end_time': window.daily_end_time,
                            'reason': window.reason
                        }
                    })

        # Check for active recurring window (based on day of week and time)
        current_dow = str(now.weekday())  # 0=Monday ... 6=Sunday
        recurring_windows = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True),
            MaintenanceWindow.window_type == 'recurring'
        ).all()

        for window in recurring_windows:
            if window.recurrence_days:
                days = window.recurrence_days.split(',')
                if current_dow in days:
                    if window.daily_start_time and window.daily_end_time:
                        if window.daily_start_time <= current_time <= window.daily_end_time:
                            return jsonify({
                                'success': True,
                                'active_window': {
                                    'id': window.id,
                                    'name': window.name,
                                    'window_type': window.window_type,
                                    'daily_start_time': window.daily_start_time,
                                    'daily_end_time': window.daily_end_time,
                                    'recurrence_days': window.recurrence_days,
                                    'reason': window.reason
                                }
                            })

        # No active window
        return jsonify({
            'success': True,
            'active_window': None
        })

    except Exception as e:
        logger.error(f"Error checking active maintenance window: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Bulk Schedule Operations
# ============================================================================

@schedule_enhanced_bp.route('/api/schedules/bulk', methods=['POST'])
@require_api_key
@conditional_limit("10 per minute")
def create_bulk_schedules():
    """
    Create schedules for multiple servers at once

    Request Body:
        server_ids (list): List of server IDs
        audit_id (int): Audit to schedule
        cron_schedule (str): Cron expression
        name_template (str): Name template with {server_name} placeholder
        notification_enabled (bool): Enable notifications
        notification_emails (str): Notification emails

    Returns:
        JSON: Created schedules summary
    """
    db = SessionLocal()

    try:
        data = request.json

        # Validate required fields
        required = ['server_ids', 'audit_id', 'cron_schedule']
        missing = [f for f in required if f not in data]
        if missing:
            return jsonify({
                'success': False,
                'error': f"Missing required fields: {', '.join(missing)}"
            }), 400

        server_ids = data['server_ids']
        if not isinstance(server_ids, list) or len(server_ids) == 0:
            return jsonify({
                'success': False,
                'error': 'server_ids must be a non-empty list'
            }), 400

        # Validate cron
        is_valid, message = ScheduledAudit.validate_cron(data['cron_schedule'])
        if not is_valid:
            return jsonify({'success': False, 'error': message}), 400

        # Verify audit exists
        audit = db.query(Audit).filter(Audit.id == data['audit_id']).first()
        if not audit:
            return jsonify({'success': False, 'error': 'Audit not found'}), 404

        # Get servers
        servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
        found_ids = {s.id for s in servers}
        missing_ids = set(server_ids) - found_ids

        created = []
        errors = []

        name_template = data.get('name_template', '{server_name} - {audit_name}')

        for server in servers:
            try:
                schedule_name = name_template.format(
                    server_name=server.name,
                    audit_name=audit.name
                )

                schedule = ScheduledAudit(
                    name=schedule_name,
                    server_id=server.id,
                    audit_id=data['audit_id'],
                    cron_schedule=data['cron_schedule'],
                    is_active=data.get('is_active', True),
                    notification_enabled=data.get('notification_enabled', False),
                    notification_emails=data.get('notification_emails'),
                    notification_webhooks=data.get('notification_webhooks'),
                    last_status='pending'
                )
                schedule.calculate_next_run()

                db.add(schedule)
                db.flush()  # Get ID without committing

                created.append({
                    'schedule_id': schedule.id,
                    'server_id': server.id,
                    'server_name': server.name,
                    'name': schedule_name
                })

            except Exception as e:
                errors.append({
                    'server_id': server.id,
                    'server_name': server.name,
                    'error': str(e)
                })

        db.commit()

        # Add missing server errors
        for missing_id in missing_ids:
            errors.append({
                'server_id': missing_id,
                'error': 'Server not found'
            })

        logger.info(f"Bulk schedule creation: {len(created)} created, {len(errors)} errors")

        return jsonify({
            'success': True,
            'created': created,
            'errors': errors,
            'summary': {
                'total_requested': len(server_ids),
                'created': len(created),
                'failed': len(errors)
            }
        }), 201 if created else 400

    except Exception as e:
        db.rollback()
        logger.error(f"Error in bulk schedule creation: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/schedules/bulk/toggle', methods=['POST'])
@require_api_key
@conditional_limit("10 per minute")
def bulk_toggle_schedules():
    """
    Enable or disable multiple schedules at once

    Request Body:
        schedule_ids (list): List of schedule IDs
        enabled (bool): New enabled state

    Returns:
        JSON: Updated schedules summary
    """
    db = SessionLocal()

    try:
        data = request.json

        schedule_ids = data.get('schedule_ids', [])
        if not schedule_ids:
            return jsonify({'success': False, 'error': 'schedule_ids is required'}), 400

        enabled = data.get('enabled', True)

        # Update all matching schedules
        result = db.query(ScheduledAudit).filter(
            ScheduledAudit.id.in_(schedule_ids)
        ).update({
            ScheduledAudit.is_active: enabled,
            ScheduledAudit.updated_at: datetime.utcnow()
        }, synchronize_session=False)

        db.commit()

        status = 'enabled' if enabled else 'disabled'
        logger.info(f"Bulk schedule toggle: {result} schedules {status}")

        return jsonify({
            'success': True,
            'updated_count': result,
            'message': f'{result} schedules {status}'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error in bulk schedule toggle: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/schedules/bulk/delete', methods=['POST'])
@require_api_key
@conditional_limit("10 per minute")
def bulk_delete_schedules():
    """
    Delete multiple schedules at once

    Request Body:
        schedule_ids (list): List of schedule IDs to delete

    Returns:
        JSON: Deletion summary
    """
    db = SessionLocal()

    try:
        data = request.json

        schedule_ids = data.get('schedule_ids', [])
        if not schedule_ids:
            return jsonify({'success': False, 'error': 'schedule_ids is required'}), 400

        # Delete matching schedules
        result = db.query(ScheduledAudit).filter(
            ScheduledAudit.id.in_(schedule_ids)
        ).delete(synchronize_session=False)

        db.commit()

        logger.info(f"Bulk schedule delete: {result} schedules deleted")

        return jsonify({
            'success': True,
            'deleted_count': result,
            'message': f'{result} schedules deleted'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error in bulk schedule delete: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Schedule Execution History
# ============================================================================

@schedule_enhanced_bp.route('/api/schedules/<int:schedule_id>/history', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def get_schedule_history(schedule_id):
    """
    Get execution history for a specific schedule

    Path Parameters:
        schedule_id (int): Schedule ID

    Query Parameters:
        limit (int): Maximum results (default: 50)
        offset (int): Pagination offset (default: 0)
        status (str): Filter by status (success, failure, skipped)

    Returns:
        JSON: List of execution log entries
    """
    db = SessionLocal()

    try:
        # Verify schedule exists
        schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        query = db.query(ScheduleExecutionLog).filter(
            ScheduleExecutionLog.schedule_id == schedule_id
        )

        # Filter by status
        status_filter = request.args.get('status')
        if status_filter:
            query = query.filter(ScheduleExecutionLog.status == status_filter)

        # Pagination
        limit = min(request.args.get('limit', 50, type=int), 500)
        offset = request.args.get('offset', 0, type=int)

        total = query.count()
        logs = query.order_by(ScheduleExecutionLog.created_at.desc()).limit(limit).offset(offset).all()

        # Calculate statistics
        stats = db.query(
            ScheduleExecutionLog.status,
            func.count(ScheduleExecutionLog.id).label('count')
        ).filter(
            ScheduleExecutionLog.schedule_id == schedule_id
        ).group_by(ScheduleExecutionLog.status).all()

        stats_dict = {s.status: s.count for s in stats}

        return jsonify({
            'success': True,
            'schedule': schedule.to_dict(include_relations=False),
            'history': [log.to_dict() for log in logs],
            'statistics': {
                'total_runs': sum(stats_dict.values()),
                'successful': stats_dict.get('success', 0),
                'failed': stats_dict.get('failure', 0),
                'skipped': stats_dict.get('skipped', 0),
                'cancelled': stats_dict.get('cancelled', 0)
            },
            'pagination': {
                'total': total,
                'limit': limit,
                'offset': offset,
                'has_more': (offset + limit) < total
            }
        })

    except Exception as e:
        logger.error(f"Error getting schedule history for {schedule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_enhanced_bp.route('/api/schedules/execution-summary', methods=['GET'])
@require_api_key
@conditional_limit("30 per minute")
def get_execution_summary():
    """
    Get execution summary across all schedules

    Query Parameters:
        days (int): Number of days to look back (default: 7)
        server_id (int): Filter by server

    Returns:
        JSON: Aggregated execution statistics
    """
    db = SessionLocal()

    try:
        days = min(request.args.get('days', 7, type=int), 90)
        since = datetime.utcnow() - timedelta(days=days)

        query = db.query(ScheduleExecutionLog).filter(
            ScheduleExecutionLog.created_at >= since
        )

        # Filter by server if specified
        server_id = request.args.get('server_id', type=int)
        if server_id:
            query = query.join(ScheduledAudit).filter(ScheduledAudit.server_id == server_id)

        # Aggregate by status
        status_counts = db.query(
            ScheduleExecutionLog.status,
            func.count(ScheduleExecutionLog.id).label('count')
        ).filter(
            ScheduleExecutionLog.created_at >= since
        ).group_by(ScheduleExecutionLog.status).all()

        # Aggregate by day
        daily_counts = db.query(
            func.date(ScheduleExecutionLog.created_at).label('date'),
            ScheduleExecutionLog.status,
            func.count(ScheduleExecutionLog.id).label('count')
        ).filter(
            ScheduleExecutionLog.created_at >= since
        ).group_by(
            func.date(ScheduleExecutionLog.created_at),
            ScheduleExecutionLog.status
        ).all()

        # Build daily breakdown
        daily_breakdown = {}
        for row in daily_counts:
            date_str = row.date.isoformat() if row.date else 'unknown'
            if date_str not in daily_breakdown:
                daily_breakdown[date_str] = {'success': 0, 'failure': 0, 'skipped': 0}
            daily_breakdown[date_str][row.status] = row.count

        # Recent failures
        recent_failures = db.query(ScheduleExecutionLog).filter(
            ScheduleExecutionLog.created_at >= since,
            ScheduleExecutionLog.status == 'failure'
        ).order_by(ScheduleExecutionLog.created_at.desc()).limit(10).all()

        status_dict = {s.status: s.count for s in status_counts}

        return jsonify({
            'success': True,
            'period_days': days,
            'summary': {
                'total_executions': sum(status_dict.values()),
                'successful': status_dict.get('success', 0),
                'failed': status_dict.get('failure', 0),
                'skipped': status_dict.get('skipped', 0),
                'success_rate': round(
                    status_dict.get('success', 0) / max(sum(status_dict.values()), 1) * 100, 2
                )
            },
            'daily_breakdown': daily_breakdown,
            'recent_failures': [f.to_dict() for f in recent_failures]
        })

    except Exception as e:
        logger.error(f"Error getting execution summary: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Schedule Templates
# ============================================================================

SCHEDULE_TEMPLATES = [
    {
        'id': 'daily_security',
        'name': 'Daily Security Check',
        'description': 'Run security audits daily at 2 AM',
        'cron_schedule': '0 2 * * *',
        'recommended_audits': ['platform/baseline', 'platform/ssh', 'platform/firewall'],
        'category': 'Security'
    },
    {
        'id': 'weekly_compliance',
        'name': 'Weekly Compliance Audit',
        'description': 'Comprehensive compliance check every Sunday at midnight',
        'cron_schedule': '0 0 * * 0',
        'recommended_audits': ['platform/baseline', 'platform/users', 'platform/permissions'],
        'category': 'Compliance'
    },
    {
        'id': 'monthly_full',
        'name': 'Monthly Full Audit',
        'description': 'Complete security audit on the 1st of each month',
        'cron_schedule': '0 3 1 * *',
        'recommended_audits': ['*'],
        'category': 'Comprehensive'
    },
    {
        'id': 'web_hourly',
        'name': 'Web Server Health',
        'description': 'Hourly web server configuration check',
        'cron_schedule': '0 * * * *',
        'recommended_audits': ['web/nginx', 'web/apache', 'web/tls'],
        'category': 'Web'
    },
    {
        'id': 'database_6h',
        'name': 'Database Security',
        'description': 'Database security check every 6 hours',
        'cron_schedule': '0 */6 * * *',
        'recommended_audits': ['data/mysql', 'data/postgresql', 'data/mongodb'],
        'category': 'Data'
    },
    {
        'id': 'weekend_maintenance',
        'name': 'Weekend Deep Scan',
        'description': 'Intensive scan during weekend off-hours',
        'cron_schedule': '0 4 * * 6',
        'recommended_audits': ['*'],
        'category': 'Maintenance'
    }
]


@schedule_enhanced_bp.route('/api/schedules/templates', methods=['GET'])
@require_auth_and_permission('view_audits')
def get_schedule_templates():
    """
    Get predefined schedule templates

    Returns:
        JSON: List of schedule templates
    """
    return jsonify({
        'success': True,
        'templates': SCHEDULE_TEMPLATES
    })


@schedule_enhanced_bp.route('/api/schedules/from-template', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def create_from_template():
    """
    Create schedules from a template

    Request Body:
        template_id (str): Template ID to use
        server_ids (list): Servers to apply template to
        audit_ids (list): Override specific audits (optional)
        notification_enabled (bool): Enable notifications

    Returns:
        JSON: Created schedules
    """
    db = SessionLocal()

    try:
        data = request.json

        template_id = data.get('template_id')
        template = next((t for t in SCHEDULE_TEMPLATES if t['id'] == template_id), None)

        if not template:
            return jsonify({'success': False, 'error': 'Template not found'}), 404

        server_ids = data.get('server_ids', [])
        if not server_ids:
            return jsonify({'success': False, 'error': 'server_ids is required'}), 400

        # Get servers
        servers = db.query(Server).filter(Server.id.in_(server_ids)).all()

        # Get audits (from template or override)
        audit_ids = data.get('audit_ids')
        if audit_ids:
            audits = db.query(Audit).filter(Audit.id.in_(audit_ids)).all()
        else:
            # Get audits matching template recommendations
            rec = template['recommended_audits']
            if '*' in rec:
                audits = db.query(Audit).all()
            else:
                audits = db.query(Audit).filter(
                    or_(*[Audit.file_path.contains(r) for r in rec])
                ).all()

        created = []

        for server in servers:
            for audit in audits:
                schedule = ScheduledAudit(
                    name=f"{template['name']} - {server.name} - {audit.name}",
                    server_id=server.id,
                    audit_id=audit.id,
                    cron_schedule=template['cron_schedule'],
                    is_active=True,
                    notification_enabled=data.get('notification_enabled', False),
                    notification_emails=data.get('notification_emails'),
                    last_status='pending'
                )
                schedule.calculate_next_run()
                db.add(schedule)

                created.append({
                    'server_name': server.name,
                    'audit_name': audit.name,
                    'cron_schedule': template['cron_schedule']
                })

        db.commit()

        logger.info(f"Created {len(created)} schedules from template {template_id}")

        return jsonify({
            'success': True,
            'template': template['name'],
            'created_count': len(created),
            'schedules': created
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating from template: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Upcoming Schedules Overview
# ============================================================================

@schedule_enhanced_bp.route('/api/schedules/upcoming', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def get_upcoming_schedules():
    """
    Get upcoming scheduled audits with maintenance window awareness

    Query Parameters:
        hours (int): Look-ahead window in hours (default: 24)
        server_id (int): Filter by server

    Returns:
        JSON: List of upcoming scheduled executions
    """
    db = SessionLocal()

    try:
        hours = min(request.args.get('hours', 24, type=int), 168)  # Max 1 week
        until = datetime.utcnow() + timedelta(hours=hours)

        query = db.query(ScheduledAudit).filter(
            ScheduledAudit.is_active.is_(True),
            ScheduledAudit.next_run <= until
        ).options(
            joinedload(ScheduledAudit.server),
            joinedload(ScheduledAudit.audit)
        )

        server_id = request.args.get('server_id', type=int)
        if server_id:
            query = query.filter(ScheduledAudit.server_id == server_id)

        schedules = query.order_by(ScheduledAudit.next_run.asc()).all()

        upcoming = []
        for schedule in schedules:
            # Check if in maintenance window
            in_window, window_name = is_in_maintenance_window(
                schedule.server_id, schedule.next_run
            )

            upcoming.append({
                'schedule_id': schedule.id,
                'schedule_name': schedule.name,
                'server_id': schedule.server_id,
                'server_name': schedule.server.name if schedule.server else None,
                'audit_id': schedule.audit_id,
                'audit_name': schedule.audit.name if schedule.audit else None,
                'next_run': schedule.next_run.isoformat() if schedule.next_run else None,
                'cron_schedule': schedule.cron_schedule,
                'blocked_by_maintenance': in_window,
                'maintenance_window': window_name
            })

        # Count blocked
        blocked_count = sum(1 for u in upcoming if u['blocked_by_maintenance'])

        return jsonify({
            'success': True,
            'period_hours': hours,
            'upcoming': upcoming,
            'summary': {
                'total_scheduled': len(upcoming),
                'will_run': len(upcoming) - blocked_count,
                'blocked_by_maintenance': blocked_count
            }
        })

    except Exception as e:
        logger.error(f"Error getting upcoming schedules: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()
