"""
Schedule Routes - Scheduled Audit Management

Provides endpoints for:
- Listing schedules (/api/schedules)
- Creating schedules (/api/schedules)
- Updating schedules (/api/schedules/<id>)
- Deleting schedules (/api/schedules/<id>)
- Batch deleting schedules (/api/schedules/delete-batch)
"""

import json
from datetime import datetime
from flask import Blueprint, jsonify, request

# Import from config
from config import logger
from config import ROOT_DIR

# Import auth decorators
from auth_core import require_api_key, require_auth_and_permission

# Create blueprint
schedule_bp = Blueprint('schedules', __name__)

# Schedule storage
SCHEDULES_FILE = ROOT_DIR / "schedules.json"


# ============================================================================
# Schedule Management Helpers
# ============================================================================
def load_schedules():
    """Load schedules from file"""
    if SCHEDULES_FILE.exists():
        try:
            return json.loads(SCHEDULES_FILE.read_text())
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse schedules.json: {e}")
            return []
    return []


def save_schedules(schedules):
    """Save schedules to file"""
    try:
        SCHEDULES_FILE.write_text(json.dumps(schedules, indent=2))
        logger.debug(f"Saved {len(schedules)} schedules")
    except Exception as e:
        logger.error(f"Failed to save schedules: {e}")
        raise


# ============================================================================
# Schedule CRUD Operations
# ============================================================================
@schedule_bp.route('/api/schedules')
@require_auth_and_permission('view_audits')
def get_schedules():
    """Get all scheduled audits"""
    try:
        schedules = load_schedules()
        return jsonify(schedules)
    except Exception as e:
        logger.error(f"Error loading schedules: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@schedule_bp.route('/api/schedules/<schedule_id>', methods=['GET'])
@require_auth_and_permission('view_audits')
def get_schedule(schedule_id):
    """Get a single schedule by ID"""
    try:
        schedules = load_schedules()
        schedule = next((s for s in schedules if s['id'] == schedule_id), None)
        if schedule:
            return jsonify({"success": True, "schedule": schedule})
        return jsonify({"success": False, "error": "Schedule not found"}), 404
    except Exception as e:
        logger.error(f"Error loading schedule {schedule_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@schedule_bp.route('/api/schedules', methods=['POST'])
@require_auth_and_permission('create_schedules')
def create_schedule():
    """Create a new scheduled audit"""
    try:
        data = request.json

        # Validate required fields
        if not all(k in data for k in ['name', 'plan_name', 'frequency']):
            return jsonify({"success": False, "error": "Missing required fields"}), 400

        # Input length validation to prevent resource exhaustion
        if len(data.get('name', '')) > 100:
            return jsonify({"success": False, "error": "Schedule name too long (max 100 chars)"}), 400
        if len(data.get('plan_name', '')) > 200:
            return jsonify({"success": False, "error": "Plan name too long (max 200 chars)"}), 400
        if len(data.get('frequency', '')) > 50:
            return jsonify({"success": False, "error": "Frequency value too long"}), 400

        schedules = load_schedules()

        # Generate unique ID
        schedule_id = datetime.now().strftime('%Y%m%d%H%M%S')

        # Create schedule entry
        schedule = {
            'id': schedule_id,
            'name': data['name'],
            'plan_name': data['plan_name'],
            'frequency': data['frequency'],
            'time': data.get('time', '02:00'),
            'cron': data.get('cron'),
            'enabled': data.get('enabled', True),
            'execution_mode': data.get('execution_mode', 'stream'),  # 'stream', 'deployed', or 'server-default'
            'created': datetime.now().isoformat(),
            'next_run': None,  # Will be calculated by scheduler
            'last_run': None
        }

        schedules.append(schedule)
        save_schedules(schedules)

        # Note: Actual scheduling via APScheduler would be implemented here
        logger.info(f"Created schedule: {schedule['name']}")

        return jsonify({"success": True, "schedule": schedule})
    except Exception as e:
        logger.error(f"Error creating schedule: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@schedule_bp.route('/api/schedules/<schedule_id>', methods=['PATCH'])
@require_auth_and_permission('edit_schedules')
def update_schedule(schedule_id):
    """Update a schedule (e.g., enable/disable)"""
    try:
        data = request.json
        schedules = load_schedules()

        for schedule in schedules:
            if schedule['id'] == schedule_id:
                schedule.update(data)
                schedule['updated'] = datetime.now().isoformat()
                save_schedules(schedules)
                logger.info(f"Updated schedule: {schedule_id}")
                return jsonify({"success": True, "schedule": schedule})

        return jsonify({"success": False, "error": "Schedule not found"}), 404
    except Exception as e:
        logger.error(f"Error updating schedule {schedule_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@schedule_bp.route('/api/schedules/<schedule_id>', methods=['DELETE'])
@require_auth_and_permission('delete_schedules')
def delete_schedule(schedule_id):
    """Delete a schedule"""
    try:
        schedules = load_schedules()
        initial_count = len(schedules)
        schedules = [s for s in schedules if s['id'] != schedule_id]

        if len(schedules) == initial_count:
            return jsonify({"success": False, "error": "Schedule not found"}), 404

        save_schedules(schedules)
        logger.info(f"Deleted schedule: {schedule_id}")

        return jsonify({"success": True, "message": "Schedule deleted"})
    except Exception as e:
        logger.error(f"Error deleting schedule {schedule_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@schedule_bp.route('/api/schedules/delete-batch', methods=['POST'])
@require_auth_and_permission('delete_schedules')
def delete_schedules_batch():
    """Delete multiple schedules in one request."""
    try:
        data = request.json or {}
        schedule_ids = data.get('ids', [])

        if not isinstance(schedule_ids, list) or len(schedule_ids) == 0:
            return jsonify({"success": False, "error": "No schedule IDs provided"}), 400

        normalized_ids = []
        seen_ids = set()
        errors = []

        for raw_id in schedule_ids:
            schedule_id = str(raw_id).strip() if raw_id is not None else ''
            if not schedule_id:
                errors.append({"id": str(raw_id), "error": "Invalid schedule ID"})
                continue

            if len(schedule_id) > 100:
                errors.append({"id": schedule_id[:100], "error": "Schedule ID too long"})
                continue

            if schedule_id in seen_ids:
                continue

            seen_ids.add(schedule_id)
            normalized_ids.append(schedule_id)

        schedules = load_schedules()
        existing_schedule_ids = {str(schedule.get('id', '')) for schedule in schedules}

        deletable_ids = [schedule_id for schedule_id in normalized_ids if schedule_id in existing_schedule_ids]

        for schedule_id in normalized_ids:
            if schedule_id not in existing_schedule_ids:
                errors.append({"id": schedule_id, "error": "Schedule not found"})

        if deletable_ids:
            delete_set = set(deletable_ids)
            schedules = [schedule for schedule in schedules if str(schedule.get('id', '')) not in delete_set]
            save_schedules(schedules)

            logger.info(
                "Batch deleted %s schedule(s): %s",
                len(deletable_ids),
                ', '.join(deletable_ids),
            )

        return jsonify({
            "success": True,
            "deleted": deletable_ids,
            "errors": errors,
            "deleted_count": len(deletable_ids),
            "error_count": len(errors),
        })
    except Exception as e:
        logger.error(f"Error deleting schedules in batch: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
