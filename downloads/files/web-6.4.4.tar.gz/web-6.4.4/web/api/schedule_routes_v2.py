#!/usr/bin/env python3
"""
Enhanced Schedule Management API

Provides comprehensive CRUD operations for scheduled audits with:
- Database-backed storage
- Cron expression validation
- Notification configuration
- Schedule execution history
- Bulk operations

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

from flask import Blueprint, jsonify, request, current_app, g
from sqlalchemy import and_, or_
from sqlalchemy.orm import joinedload
from datetime import datetime, timedelta
from auth_core import require_api_key, conditional_limit, require_auth_and_permission
from config import SessionLocal, logger
from models.schedule import ScheduledAudit
from models.database import Server, Audit
from croniter import croniter

# Create blueprint
schedule_v2_bp = Blueprint('schedules_v2', __name__)


# ============================================================================
# Schedule CRUD Operations
# ============================================================================

@schedule_v2_bp.route('/api/v2/schedules', methods=['GET'])
@require_api_key
@require_auth_and_permission('view_audits')
@conditional_limit("50 per minute")
def list_schedules():
    """
    List all scheduled audits with optional filtering

    Query Parameters:
        server_id (int): Filter by server ID
        active_only (bool): Show only active schedules (default: false)
        limit (int): Maximum results (default: 100)
        offset (int): Pagination offset (default: 0)

    Returns:
        JSON: List of schedules with metadata
    """
    db = SessionLocal()

    try:
        query = db.query(ScheduledAudit).options(
            joinedload(ScheduledAudit.server),
            joinedload(ScheduledAudit.audit)
        )

        # Apply filters
        server_id = request.args.get('server_id', type=int)
        if server_id:
            query = query.filter(ScheduledAudit.server_id == server_id)

        active_only = request.args.get('active_only', 'false').lower() == 'true'
        if active_only:
            query = query.filter(ScheduledAudit.is_active.is_(True))

        # Pagination
        limit = min(request.args.get('limit', 100, type=int), 500)
        offset = request.args.get('offset', 0, type=int)

        total = query.count()
        schedules = query.order_by(ScheduledAudit.created_at.desc()).limit(limit).offset(offset).all()

        return jsonify({
            'success': True,
            'schedules': [s.to_dict() for s in schedules],
            'pagination': {
                'total': total,
                'limit': limit,
                'offset': offset,
                'has_more': (offset + limit) < total
            }
        })

    except Exception as e:
        logger.error(f"Error listing schedules: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_v2_bp.route('/api/v2/schedules/<int:schedule_id>', methods=['GET'])
@require_api_key
@require_auth_and_permission('view_audits')
@conditional_limit("100 per minute")
def get_schedule(schedule_id):
    """
    Get detailed information about a specific schedule

    Path Parameters:
        schedule_id (int): Schedule ID

    Returns:
        JSON: Schedule details
    """
    db = SessionLocal()

    try:
        schedule = db.query(ScheduledAudit).options(
            joinedload(ScheduledAudit.server),
            joinedload(ScheduledAudit.audit)
        ).filter(ScheduledAudit.id == schedule_id).first()

        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        return jsonify({
            'success': True,
            'schedule': schedule.to_dict(include_relations=True)
        })

    except Exception as e:
        logger.error(f"Error getting schedule {schedule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_v2_bp.route('/api/v2/schedules', methods=['POST'])
@require_api_key
@require_auth_and_permission('create_schedules')
@conditional_limit("20 per minute")
def create_schedule():
    """
    Create a new scheduled audit

    Request Body:
        name (str): Schedule name
        server_id (int): Server ID
        audit_id (int): Audit ID
        cron_schedule (str): Cron expression (e.g., "0 2 * * *")
        is_active (bool): Enable schedule (default: true)
        notification_enabled (bool): Enable notifications (default: false)
        notification_emails (str): Comma-separated emails
        notification_webhooks (str): Comma-separated webhook URLs

    Returns:
        JSON: Created schedule
    """
    db = SessionLocal()

    try:
        data = request.json

        # Validate required fields
        required_fields = ['name', 'server_id', 'audit_id', 'cron_schedule']
        missing = [f for f in required_fields if f not in data]
        if missing:
            return jsonify({
                'success': False,
                'error': f"Missing required fields: {', '.join(missing)}"
            }), 400

        # Validate cron expression
        is_valid, message = ScheduledAudit.validate_cron(data['cron_schedule'])
        if not is_valid:
            return jsonify({'success': False, 'error': message}), 400

        # Verify server exists
        server = db.query(Server).filter(Server.id == data['server_id']).first()
        if not server:
            return jsonify({'success': False, 'error': 'Server not found'}), 404

        # Verify audit exists
        audit = db.query(Audit).filter(Audit.id == data['audit_id']).first()
        if not audit:
            return jsonify({'success': False, 'error': 'Audit not found'}), 404

        # Create schedule
        schedule = ScheduledAudit(
            name=data['name'],
            server_id=data['server_id'],
            audit_id=data['audit_id'],
            cron_schedule=data['cron_schedule'],
            is_active=data.get('is_active', True),
            notification_enabled=data.get('notification_enabled', False),
            notification_emails=data.get('notification_emails'),
            notification_webhooks=data.get('notification_webhooks'),
            last_status='pending'
        )

        # Calculate first run time
        schedule.calculate_next_run()

        db.add(schedule)
        db.commit()
        db.refresh(schedule)

        logger.info(f"Created schedule: {schedule.name} (ID: {schedule.id})")

        return jsonify({
            'success': True,
            'schedule': schedule.to_dict(),
            'message': 'Schedule created successfully'
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating schedule: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_v2_bp.route('/api/v2/schedules/<int:schedule_id>', methods=['PUT'])
@require_api_key
@require_auth_and_permission('edit_schedules')
@conditional_limit("20 per minute")
def update_schedule(schedule_id):
    """
    Update an existing schedule

    Path Parameters:
        schedule_id (int): Schedule ID

    Request Body:
        Any fields from schedule model (partial update supported)

    Returns:
        JSON: Updated schedule
    """
    db = SessionLocal()

    try:
        schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        data = request.json

        # Update allowed fields
        updatable_fields = [
            'name', 'cron_schedule', 'is_active', 'notification_enabled',
            'notification_emails', 'notification_webhooks'
        ]

        for field in updatable_fields:
            if field in data:
                # Special validation for cron_schedule
                if field == 'cron_schedule':
                    is_valid, message = ScheduledAudit.validate_cron(data[field])
                    if not is_valid:
                        return jsonify({'success': False, 'error': message}), 400
                    # Recalculate next run if cron changed
                    schedule.cron_schedule = data[field]
                    schedule.calculate_next_run()
                else:
                    setattr(schedule, field, data[field])

        schedule.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(schedule)

        logger.info(f"Updated schedule: {schedule.name} (ID: {schedule.id})")

        return jsonify({
            'success': True,
            'schedule': schedule.to_dict(),
            'message': 'Schedule updated successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating schedule {schedule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_v2_bp.route('/api/v2/schedules/<int:schedule_id>', methods=['DELETE'])
@require_api_key
@require_auth_and_permission('delete_schedules')
@conditional_limit("20 per minute")
def delete_schedule(schedule_id):
    """
    Delete a schedule

    Path Parameters:
        schedule_id (int): Schedule ID

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        schedule_name = schedule.name
        db.delete(schedule)
        db.commit()

        logger.info(f"Deleted schedule: {schedule_name} (ID: {schedule_id})")

        return jsonify({
            'success': True,
            'message': f'Schedule "{schedule_name}" deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting schedule {schedule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Schedule Actions
# ============================================================================

@schedule_v2_bp.route('/api/v2/schedules/<int:schedule_id>/toggle', methods=['POST'])
@require_api_key
@require_auth_and_permission('edit_schedules')
@conditional_limit("30 per minute")
def toggle_schedule(schedule_id):
    """
    Enable or disable a schedule

    Path Parameters:
        schedule_id (int): Schedule ID

    Returns:
        JSON: Updated schedule with new status
    """
    db = SessionLocal()

    try:
        schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        schedule.is_active = not schedule.is_active
        schedule.updated_at = datetime.utcnow()

        # Recalculate next run if enabling
        if schedule.is_active:
            schedule.calculate_next_run()

        db.commit()
        db.refresh(schedule)

        status = 'enabled' if schedule.is_active else 'disabled'
        logger.info(f"Schedule {schedule.name} (ID: {schedule.id}) {status}")

        return jsonify({
            'success': True,
            'schedule': schedule.to_dict(),
            'message': f'Schedule {status} successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error toggling schedule {schedule_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@schedule_v2_bp.route('/api/v2/schedules/<int:schedule_id>/run-now', methods=['POST'])
@require_api_key
@require_auth_and_permission('run_audits')
@conditional_limit("10 per minute")
def run_schedule_now(schedule_id):
    """
    Trigger immediate execution of a scheduled audit (outside normal schedule)

    Path Parameters:
        schedule_id (int): Schedule ID

    Returns:
        JSON: Task ID for the triggered execution
    """
    db = SessionLocal()

    try:
        schedule = db.query(ScheduledAudit).filter(ScheduledAudit.id == schedule_id).first()
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404

        if not schedule.server or not schedule.audit:
            return jsonify({
                'success': False,
                'error': 'Schedule references a missing server or audit definition'
            }), 400

        requested_by = 'manual-trigger'
        auth_user = getattr(g, 'current_auth_user', None)
        if auth_user is not None:
            requested_by = getattr(auth_user, 'username', requested_by) or requested_by

        # Import here to avoid circular imports
        from tasks.audit_tasks import execute_audit

        # Queue immediate execution
        task = execute_audit.delay(
            server_id=schedule.server_id,
            audit_path=schedule.audit.file_path,
            options={
                'trigger': 'manual',
                'schedule_id': schedule.id,
                'schedule_name': schedule.name,
                'requested_by': requested_by,
            }
        )

        logger.info(f"Manually triggered schedule {schedule.name} (ID: {schedule.id})")

        return jsonify({
            'success': True,
            'task_id': task.id,
            'message': f'Schedule "{schedule.name}" triggered for immediate execution',
            'status': 'queued'
        })

    except Exception as e:
        logger.error(f"Error running schedule {schedule_id} now: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Utility Endpoints
# ============================================================================

@schedule_v2_bp.route('/api/v2/schedules/validate-cron', methods=['POST'])
@require_api_key
@conditional_limit("50 per minute")
def validate_cron():
    """
    Validate a cron expression and show next execution times

    Request Body:
        cron_expression (str): Cron expression to validate
        count (int): Number of next execution times to show (default: 5)

    Returns:
        JSON: Validation result and next execution times
    """
    try:
        data = request.json
        cron_expression = data.get('cron_expression')
        count = min(data.get('count', 5), 20)

        if not cron_expression:
            return jsonify({'success': False, 'error': 'cron_expression is required'}), 400

        # Validate
        is_valid, message = ScheduledAudit.validate_cron(cron_expression)

        if not is_valid:
            return jsonify({
                'success': False,
                'valid': False,
                'error': message
            }), 400

        # Calculate next executions
        base_time = datetime.utcnow()
        cron = croniter(cron_expression, base_time)
        next_runs = [cron.get_next(datetime) for _ in range(count)]

        return jsonify({
            'success': True,
            'valid': True,
            'cron_expression': cron_expression,
            'next_runs': [dt.isoformat() for dt in next_runs],
            'next_runs_readable': [dt.strftime('%Y-%m-%d %H:%M:%S UTC') for dt in next_runs]
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'valid': False,
            'error': str(e)
        }), 400


@schedule_v2_bp.route('/api/v2/schedules/cron-presets', methods=['GET'])
@require_api_key
def get_cron_presets():
    """
    Get common cron expression presets

    Returns:
        JSON: List of common cron patterns with descriptions
    """
    presets = [
        {'pattern': '* * * * *', 'description': 'Every minute', 'category': 'Testing'},
        {'pattern': '*/5 * * * *', 'description': 'Every 5 minutes', 'category': 'Frequent'},
        {'pattern': '*/15 * * * *', 'description': 'Every 15 minutes', 'category': 'Frequent'},
        {'pattern': '*/30 * * * *', 'description': 'Every 30 minutes', 'category': 'Frequent'},
        {'pattern': '0 * * * *', 'description': 'Every hour', 'category': 'Hourly'},
        {'pattern': '0 */2 * * *', 'description': 'Every 2 hours', 'category': 'Hourly'},
        {'pattern': '0 */4 * * *', 'description': 'Every 4 hours', 'category': 'Hourly'},
        {'pattern': '0 */6 * * *', 'description': 'Every 6 hours', 'category': 'Hourly'},
        {'pattern': '0 0 * * *', 'description': 'Daily at midnight', 'category': 'Daily'},
        {'pattern': '0 2 * * *', 'description': 'Daily at 2:00 AM', 'category': 'Daily'},
        {'pattern': '0 6 * * *', 'description': 'Daily at 6:00 AM', 'category': 'Daily'},
        {'pattern': '0 12 * * *', 'description': 'Daily at noon', 'category': 'Daily'},
        {'pattern': '0 0 * * 0', 'description': 'Weekly on Sunday', 'category': 'Weekly'},
        {'pattern': '0 0 * * 1', 'description': 'Weekly on Monday', 'category': 'Weekly'},
        {'pattern': '0 0 * * 5', 'description': 'Weekly on Friday', 'category': 'Weekly'},
        {'pattern': '0 0 1 * *', 'description': 'Monthly on the 1st', 'category': 'Monthly'},
        {'pattern': '0 0 15 * *', 'description': 'Monthly on the 15th', 'category': 'Monthly'},
        {'pattern': '0 0 1 */3 *', 'description': 'Quarterly', 'category': 'Quarterly'},
    ]

    return jsonify({
        'success': True,
        'presets': presets
    })
