#!/usr/bin/env python3
"""
Scheduled Report API Routes

Provides endpoints for managing scheduled PDF report delivery:
- CRUD operations for scheduled reports
- Manual trigger for immediate report generation
- Report delivery history

Author: Security Audit Toolkit Team
Date: February 11, 2026
"""

from flask import Blueprint, jsonify, request
from datetime import datetime
from typing import Optional
from auth_core import require_api_key, conditional_limit, require_auth_and_permission
from config import SessionLocal, logger
from models.scheduled_report import ScheduledReport, ComplianceFramework
from models.database import Server

# Create blueprint
scheduled_report_bp = Blueprint('scheduled_report', __name__)


# ============================================================================
# Scheduled Report CRUD
# ============================================================================

@scheduled_report_bp.route('/api/scheduled-reports', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_scheduled_reports():
    """
    List all scheduled reports

    Query Parameters:
        active_only (bool): Show only active schedules (default: false)
        compliance_framework (str): Filter by compliance framework

    Returns:
        JSON: List of scheduled reports
    """
    db = SessionLocal()

    try:
        query = db.query(ScheduledReport)

        # Apply filters
        active_only = request.args.get('active_only', 'false').lower() == 'true'
        if active_only:
            query = query.filter(ScheduledReport.is_active.is_(True))

        framework = request.args.get('compliance_framework')
        if framework:
            query = query.filter(ScheduledReport.compliance_framework == framework)

        reports = query.order_by(ScheduledReport.next_run.asc()).all()

        return jsonify({
            'success': True,
            'scheduled_reports': [r.to_dict() for r in reports],
            'total': len(reports)
        })

    except Exception as e:
        try:
            db.rollback()
        except Exception as rollback_error:
            logger.debug(f"Rollback failed while listing scheduled reports: {rollback_error}")

        error_text = str(e).lower()
        if 'scheduled_reports' in error_text and 'does not exist' in error_text:
            logger.warning("scheduled_reports table missing; returning empty list")
            return jsonify({
                'success': True,
                'scheduled_reports': [],
                'total': 0
            })

        logger.error(f"Error listing scheduled reports: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@scheduled_report_bp.route('/api/scheduled-reports/<int:report_id>', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def get_scheduled_report(report_id: int):
    """
    Get a single scheduled report by ID

    Returns:
        JSON: Scheduled report details
    """
    db = SessionLocal()

    try:
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            return jsonify({'success': False, 'error': 'Scheduled report not found'}), 404

        return jsonify({
            'success': True,
            'scheduled_report': report.to_dict()
        })

    except Exception as e:
        logger.error(f"Error getting scheduled report {report_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@scheduled_report_bp.route('/api/scheduled-reports', methods=['POST'])
@require_auth_and_permission('manage_schedules')
@conditional_limit("20 per minute")
def create_scheduled_report():
    """
    Create a new scheduled report

    Request Body:
        name (str): Report name (required)
        description (str): Optional description
        frequency (str): daily, weekly, biweekly, monthly, quarterly
        cron_schedule (str): Custom cron expression (optional, overrides frequency)
        email_recipients (list): List of email addresses (required)
        compliance_framework (str): pci-dss, soc2, iso27001, nist-csf, cis-controls
        organization (str): Organization name for branding
        classification (str): Document classification level
        server_ids (list): Specific server IDs (optional)
        server_tags (list): Server tags to filter (optional)
        include_all_servers (bool): Include all servers (default: true)
        webhook_urls (list): Optional webhook URLs

    Returns:
        JSON: Created scheduled report
    """
    db = SessionLocal()

    try:
        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'error': 'Request body required'}), 400

        # Validate required fields
        if not data.get('name'):
            return jsonify({'success': False, 'error': 'name is required'}), 400

        if not data.get('email_recipients'):
            return jsonify({'success': False, 'error': 'email_recipients is required'}), 400

        # Validate email recipients
        recipients = data.get('email_recipients', [])
        if not isinstance(recipients, list) or len(recipients) == 0:
            return jsonify({'success': False, 'error': 'email_recipients must be a non-empty list'}), 400

        # Get cron schedule
        frequency = data.get('frequency', 'weekly')
        hour = data.get('hour', 8)
        day_of_week = data.get('day_of_week', 1)

        if data.get('cron_schedule'):
            cron_schedule = data['cron_schedule']
        else:
            cron_schedule = ScheduledReport.get_cron_for_frequency(frequency, hour, day_of_week)

        # Validate compliance framework
        framework = data.get('compliance_framework', 'none')
        valid_frameworks = [f.value for f in ComplianceFramework]
        if framework not in valid_frameworks:
            return jsonify({
                'success': False,
                'error': f'Invalid compliance_framework. Must be one of: {valid_frameworks}'
            }), 400

        # Get current user from session/token
        current_user = getattr(request, 'current_user', None)
        created_by = current_user.username if current_user else data.get('created_by', 'api')

        # Create the scheduled report
        report = ScheduledReport(
            name=data['name'],
            description=data.get('description'),

            # Targeting
            server_ids=data.get('server_ids'),
            server_tags=data.get('server_tags'),
            include_all_servers=data.get('include_all_servers', True),

            # Report config
            compliance_framework=framework,
            organization=data.get('organization'),
            classification=data.get('classification', 'Confidential'),
            include_executive_summary=data.get('include_executive_summary', True),
            include_recommendations=data.get('include_recommendations', True),

            # Schedule
            cron_schedule=cron_schedule,
            frequency=frequency,
            timezone=data.get('timezone', 'UTC'),
            is_active=data.get('is_active', True),

            # Delivery
            email_recipients=recipients,
            webhook_urls=data.get('webhook_urls'),

            # Metadata
            created_by=created_by
        )

        # Calculate next run
        report.next_run = report.calculate_next_run()

        db.add(report)
        db.commit()
        db.refresh(report)

        logger.info(f"Created scheduled report: {report.name} (ID: {report.id})")

        return jsonify({
            'success': True,
            'scheduled_report': report.to_dict(),
            'message': f"Scheduled report '{report.name}' created successfully"
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating scheduled report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@scheduled_report_bp.route('/api/scheduled-reports/<int:report_id>', methods=['PUT'])
@require_auth_and_permission('manage_schedules')
@conditional_limit("20 per minute")
def update_scheduled_report(report_id: int):
    """
    Update an existing scheduled report

    Request Body: Same as create, all fields optional

    Returns:
        JSON: Updated scheduled report
    """
    db = SessionLocal()

    try:
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            return jsonify({'success': False, 'error': 'Scheduled report not found'}), 404

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Request body required'}), 400

        # Update fields if provided
        if 'name' in data:
            report.name = data['name']
        if 'description' in data:
            report.description = data['description']

        # Targeting
        if 'server_ids' in data:
            report.server_ids = data['server_ids']
        if 'server_tags' in data:
            report.server_tags = data['server_tags']
        if 'include_all_servers' in data:
            report.include_all_servers = data['include_all_servers']

        # Report config
        if 'compliance_framework' in data:
            framework = data['compliance_framework']
            valid_frameworks = [f.value for f in ComplianceFramework]
            if framework in valid_frameworks:
                report.compliance_framework = framework
        if 'organization' in data:
            report.organization = data['organization']
        if 'classification' in data:
            report.classification = data['classification']
        if 'include_executive_summary' in data:
            report.include_executive_summary = data['include_executive_summary']
        if 'include_recommendations' in data:
            report.include_recommendations = data['include_recommendations']

        # Schedule updates
        schedule_changed = False
        if 'cron_schedule' in data:
            report.cron_schedule = data['cron_schedule']
            schedule_changed = True
        elif 'frequency' in data:
            report.frequency = data['frequency']
            report.cron_schedule = ScheduledReport.get_cron_for_frequency(
                data['frequency'],
                data.get('hour', 8),
                data.get('day_of_week', 1)
            )
            schedule_changed = True

        if schedule_changed:
            report.next_run = report.calculate_next_run()

        if 'timezone' in data:
            report.timezone = data['timezone']
        if 'is_active' in data:
            report.is_active = data['is_active']

        # Delivery
        if 'email_recipients' in data:
            recipients = data['email_recipients']
            if isinstance(recipients, list) and len(recipients) > 0:
                report.email_recipients = recipients
        if 'webhook_urls' in data:
            report.webhook_urls = data['webhook_urls']

        db.commit()
        db.refresh(report)

        logger.info(f"Updated scheduled report: {report.name} (ID: {report.id})")

        return jsonify({
            'success': True,
            'scheduled_report': report.to_dict(),
            'message': f"Scheduled report '{report.name}' updated successfully"
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating scheduled report {report_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@scheduled_report_bp.route('/api/scheduled-reports/<int:report_id>', methods=['DELETE'])
@require_auth_and_permission('manage_schedules')
@conditional_limit("20 per minute")
def delete_scheduled_report(report_id: int):
    """
    Delete a scheduled report

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            return jsonify({'success': False, 'error': 'Scheduled report not found'}), 404

        report_name = report.name
        db.delete(report)
        db.commit()

        logger.info(f"Deleted scheduled report: {report_name} (ID: {report_id})")

        return jsonify({
            'success': True,
            'message': f"Scheduled report '{report_name}' deleted successfully"
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting scheduled report {report_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Scheduled Report Actions
# ============================================================================

@scheduled_report_bp.route('/api/scheduled-reports/<int:report_id>/trigger', methods=['POST'])
@require_auth_and_permission('manage_schedules')
@conditional_limit("10 per minute")
def trigger_scheduled_report(report_id: int):
    """
    Manually trigger a scheduled report to run immediately

    This queues the report for immediate generation and delivery.

    Returns:
        JSON: Task status and ID
    """
    db = SessionLocal()

    try:
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            return jsonify({'success': False, 'error': 'Scheduled report not found'}), 404

        # Import and queue the task
        try:
            from tasks.report_tasks import generate_scheduled_report
            task = generate_scheduled_report.delay(report_id)

            logger.info(f"Manually triggered scheduled report: {report.name} (task: {task.id})")

            return jsonify({
                'success': True,
                'message': f"Report '{report.name}' queued for generation",
                'task_id': task.id
            })
        except ImportError:
            # Celery not available, run synchronously
            logger.warning("Celery not available, running report generation synchronously")
            return _generate_report_sync(report, db)

    except Exception as e:
        logger.error(f"Error triggering scheduled report {report_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@scheduled_report_bp.route('/api/scheduled-reports/<int:report_id>/toggle', methods=['POST'])
@require_auth_and_permission('manage_schedules')
@conditional_limit("20 per minute")
def toggle_scheduled_report(report_id: int):
    """
    Toggle a scheduled report's active status

    Returns:
        JSON: Updated status
    """
    db = SessionLocal()

    try:
        report = db.query(ScheduledReport).filter(ScheduledReport.id == report_id).first()

        if not report:
            return jsonify({'success': False, 'error': 'Scheduled report not found'}), 404

        report.is_active = not report.is_active

        # Recalculate next run if being activated
        if report.is_active:
            report.next_run = report.calculate_next_run()

        db.commit()

        status = 'activated' if report.is_active else 'deactivated'
        logger.info(f"Scheduled report {report.name}: {status}")

        return jsonify({
            'success': True,
            'is_active': report.is_active,
            'message': f"Scheduled report '{report.name}' {status}"
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error toggling scheduled report {report_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Available Options Endpoints
# ============================================================================

@scheduled_report_bp.route('/api/scheduled-reports/frameworks', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_compliance_frameworks():
    """
    List available compliance frameworks for reports

    Returns:
        JSON: List of frameworks with descriptions
    """
    frameworks = [
        {'id': 'none', 'name': 'None', 'description': 'No compliance framework mapping'},
        {'id': 'pci-dss', 'name': 'PCI-DSS 4.0', 'description': 'Payment Card Industry Data Security Standard'},
        {'id': 'soc2', 'name': 'SOC 2 Type II', 'description': 'Service Organization Control'},
        {'id': 'iso27001', 'name': 'ISO 27001:2022', 'description': 'Information Security Management'},
        {'id': 'nist-csf', 'name': 'NIST CSF', 'description': 'Cybersecurity Framework'},
        {'id': 'cis-controls', 'name': 'CIS Controls v8', 'description': 'Center for Internet Security Controls'},
    ]

    return jsonify({
        'success': True,
        'frameworks': frameworks
    })


@scheduled_report_bp.route('/api/scheduled-reports/frequencies', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_report_frequencies():
    """
    List available report frequencies

    Returns:
        JSON: List of frequencies with cron expressions
    """
    frequencies = [
        {'id': 'daily', 'name': 'Daily', 'cron': '0 8 * * *', 'description': 'Every day at 8:00 AM'},
        {'id': 'weekly', 'name': 'Weekly', 'cron': '0 8 * * 1', 'description': 'Every Monday at 8:00 AM'},
        {'id': 'biweekly', 'name': 'Bi-weekly', 'cron': '0 8 1,15 * *', 'description': '1st and 15th of each month'},
        {'id': 'monthly', 'name': 'Monthly', 'cron': '0 8 1 * *', 'description': '1st of each month at 8:00 AM'},
        {'id': 'quarterly', 'name': 'Quarterly', 'cron': '0 8 1 1,4,7,10 *', 'description': 'Beginning of each quarter'},
    ]

    return jsonify({
        'success': True,
        'frequencies': frequencies
    })


# ============================================================================
# Helper Functions
# ============================================================================

def _generate_report_sync(report: ScheduledReport, db) -> dict:
    """
    Generate and send report synchronously (fallback when Celery unavailable)
    """
    try:
        from reports.pdf_generator import PDFReportGenerator, is_pdf_available
        from reports.compliance_templates import ComplianceTemplates
        from notifications import notification_manager

        if not is_pdf_available():
            return jsonify({
                'success': False,
                'error': 'PDF generation not available. Install WeasyPrint.'
            }), 500

        # Build report data from servers
        server_query = db.query(Server)

        if not report.include_all_servers and report.server_ids:
            server_query = server_query.filter(Server.id.in_(report.server_ids))

        servers = server_query.all()

        # Build mock report data structure
        report_data = {
            'title': report.name,
            'subtitle': 'Scheduled Security Audit Report',
            'summary': {
                'total_servers': len(servers),
                'total_checks': 0,
                'total_pass': 0,  # nosec B105
                'total_warn': 0,
                'total_fail': 0,
                'total_skip': 0,
                'compliance_percentage': 0
            },
            'servers': []
        }

        # This is a simplified version - in production, fetch actual audit data
        for server in servers:
            report_data['servers'].append({
                'name': server.name,
                'host': server.hostname,
                'status': 'success',
                'metrics': {'pass': 0, 'warn': 0, 'fail': 0, 'skip': 0, 'total': 0},  # nosec B105
                'pass_percentage': 0,  # nosec B105
            })

        # Generate compliance mapping if framework specified
        compliance_mapping = None
        if report.compliance_framework and report.compliance_framework != 'none':
            templates = ComplianceTemplates()
            compliance_mapping = templates.get_mapped_controls(
                report.compliance_framework,
                report_data
            )

        # Generate PDF
        generator = PDFReportGenerator()
        pdf_data = generator.generate_pdf(
            report_data=report_data,
            compliance_framework=report.compliance_framework if report.compliance_framework != 'none' else None,
            compliance_mapping=compliance_mapping,
            organization=report.organization,
            classification=report.classification
        )

        # Send email
        result = notification_manager.notify_scheduled_report(
            report_name=report.name,
            pdf_data=pdf_data,
            report_summary=report_data['summary'],
            email_recipients=report.get_email_list(),
            organization=report.organization,
            compliance_framework=report.compliance_framework,
            webhook_urls=report.get_webhook_list()
        )

        # Update report status
        report.last_run = datetime.utcnow()
        report.last_status = 'success' if result['email_sent'] else 'failure'
        report.run_count = (report.run_count or 0) + 1
        report.next_run = report.calculate_next_run()
        db.commit()

        return jsonify({
            'success': True,
            'message': f"Report generated and sent to {len(report.get_email_list())} recipients",
            'email_sent': result['email_sent'],
            'webhooks_sent': result['webhooks_sent']
        })

    except Exception as e:
        report.last_status = 'error'
        report.last_error = str(e)
        db.commit()

        logger.error(f"Error generating report synchronously: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
