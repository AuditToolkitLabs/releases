"""
Developer Script Studio Integration Routes

Provides a web-based version of Developer Script Studio integrated into
the Security Audit Toolkit web interface.

This module:
- Embeds a Monaco-based script editor in the main UI
- Manages audit script files (create, read, update)
- Integrates with the main license system (not separate)
- Provides script validation (ShellCheck/PSScriptAnalyzer integration)
- Supports templates for quick script creation

License integration:
- Uses the main toolkit's license tier to determine permissions
- "developer" permission required for editing core scripts
- Custom scripts (audits/custom/) available to all authenticated users

Author: Security Audit Toolkit Team
"""

import os
import re
import hmac
import logging
import shutil
import subprocess  # nosec B404 - subprocess is required for local validation tool invocation
import json
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from flask import Blueprint, jsonify, request, render_template_string, session, has_request_context

# Import logging
try:
    from config import logger, ROOT_DIR
except ImportError:
    logger = logging.getLogger(__name__)
    ROOT_DIR = Path(__file__).parent.parent.parent

# Import Flask-Login for authentication
try:
    from flask_login import login_required, current_user
    from auth_login import is_authenticated
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    FLASK_LOGIN_AVAILABLE = False
    current_user = None

    def login_required(f):
        return f

    def is_authenticated():
        return True

# Import disclaimer check
try:
    from api.auth_routes import DISCLAIMER_VERSION
except ImportError:
    from version_info import get_toolkit_version
    DISCLAIMER_VERSION = get_toolkit_version()

# Import license service for tier-based access
try:
    from services_pkg.services.license_service import get_license_service
    LICENSE_SERVICE_AVAILABLE = True
except ImportError:
    LICENSE_SERVICE_AVAILABLE = False

    def get_license_service():
        return None

# Import auth decorator
try:
    from auth_core import require_auth_and_permission
except ImportError:
    def require_auth_and_permission(permission):
        def decorator(f):
            return f
        return decorator


# Create blueprint
script_studio_bp = Blueprint('script_studio', __name__)


def _is_superadmin() -> bool:
    """
    Check if current user is a SuperAdmin.

    Developer Script Studio is restricted to SuperAdmin users only
    for security reasons - it allows editing production audit scripts.
    """
    if not FLASK_LOGIN_AVAILABLE:
        return True  # No auth = dev mode
    if not current_user or not current_user.is_authenticated:
        return False
    return getattr(current_user, 'role', '') == 'SuperAdmin'


# Configuration
SCRIPT_STUDIO_ENABLED = os.getenv('SCRIPT_STUDIO_ENABLED', 'true').lower() == 'true'

# =============================================================================
# Developer Script Studio - Licensing Model
# =============================================================================
#
# LEVEL 1 - VIEW ONLY (Included with SuperAdmin):
#   - FREE - No additional license required
#   - SuperAdmin users can view all audit scripts
#   - Read-only access, cannot edit or create scripts
#   - Useful for reviewing existing audits
#
# LEVEL 2 - DEVELOPER LICENSE (Separate Purchasable Add-on):
#   - REQUIRES: "Developer Script Studio" license purchase (~$99-299/year)
#   - License key activates custom script creation/editing
#   - Grants: Create/edit scripts in audits/custom/ directory
#   - Does NOT allow editing original/core audit scripts
#   - Key format: DSS-XXXX-XXXX-XXXX-XXXX
#   - Validated against license service
#
# LEVEL 3 - SUPPORT MODE (Internal Only - NOT for customers):
#   - INTERNAL USE ONLY - Not available to customers
#   - Used by support team for troubleshooting
#   - Requires: SCRIPT_STUDIO_SUPPORT_KEY environment variable
#   - Hidden from customer-facing UI
#   - Time-limited sessions (4 hours)
#
# =============================================================================

# Support Mode Key - INTERNAL ONLY (not customer-facing)
# Set via environment variable for support team access
SUPPORT_MODE_KEY = os.getenv('SCRIPT_STUDIO_SUPPORT_KEY', None)

# License storage path for Developer Script Studio add-on
SCRIPT_STUDIO_LICENSE_FILE = Path(ROOT_DIR) / '.script_studio_license'

# =============================================================================
# Redis Integration for Multi-Instance Support
# =============================================================================
# Import Redis for distributed session storage (HA/clustered deployments)
try:
    import redis
    from redis.exceptions import RedisError
    REDIS_LIB_AVAILABLE = True
except ImportError:
    REDIS_LIB_AVAILABLE = False
    redis = None
    RedisError = Exception

# Redis configuration from environment
REDIS_ENABLED = os.getenv('REDIS_ENABLED', 'false').lower() == 'true'
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/1')

# Session key prefix for Redis
REDIS_SESSION_PREFIX = "script_studio:support_session:"
REDIS_SESSION_TTL = 4 * 60 * 60  # 4 hours in seconds
SESSION_KEY_PREFIX = "script_studio_support_session_"


class SessionManager:
    """
    Manages support sessions with Redis or in-memory fallback.

    For multi-instance/HA deployments:
    - Set REDIS_ENABLED=true and REDIS_URL=redis://your-redis:6379/1
    - Sessions will be stored in Redis, accessible across all instances

    For single-instance deployments:
    - Uses in-memory storage (default)
    - No configuration needed
    """

    def __init__(self):
        self._redis_client = None
        self._using_redis = False
        self._memory_sessions = {}
        self._initialize_backend()

    def _session_key(self, user_id: int) -> str:
        return f"{SESSION_KEY_PREFIX}{user_id}"

    def _get_flask_session_data(self, user_id: int):
        key = self._session_key(user_id)
        if has_request_context():
            data = session.get(key)
        else:
            data = self._memory_sessions.get(key)

        if not data:
            return None

        expires = data.get('expires')
        if isinstance(expires, str):
            try:
                expires_dt = datetime.fromisoformat(expires)
            except ValueError:
                expires_dt = datetime.min
        elif isinstance(expires, datetime):
            expires_dt = expires
        else:
            expires_dt = datetime.min

        if datetime.now() > expires_dt:
            if has_request_context():
                session.pop(key, None)
                session.modified = True
            else:
                self._memory_sessions.pop(key, None)
            return None

        return data

    def _set_flask_session_data(self, user_id: int, session_data: dict):
        data = session_data.copy()
        if 'activated' in data and isinstance(data['activated'], datetime):
            data['activated'] = data['activated'].isoformat()
        if 'expires' in data and isinstance(data['expires'], datetime):
            data['expires'] = data['expires'].isoformat()

        key = self._session_key(user_id)
        if has_request_context():
            session[key] = data
            session.modified = True
        else:
            self._memory_sessions[key] = data

    def _initialize_backend(self):
        """Initialize Redis connection if enabled and available."""
        if REDIS_ENABLED and REDIS_LIB_AVAILABLE:
            try:
                self._redis_client = redis.from_url(
                    REDIS_URL,
                    decode_responses=True,
                    socket_connect_timeout=5
                )
                # Test connection
                self._redis_client.ping()
                self._using_redis = True
                logger.info(f"[Script Studio] Redis session storage enabled: {REDIS_URL}")
            except (RedisError, Exception) as e:
                logger.warning(f"[Script Studio] Redis unavailable ({e}), using in-memory sessions")
                self._redis_client = None
                self._using_redis = False
        elif REDIS_ENABLED and not REDIS_LIB_AVAILABLE:
            logger.warning("[Script Studio] REDIS_ENABLED=true but redis library not installed")
            logger.warning("  Install with: pip install redis>=4.5.0")

    def get(self, user_id: int) -> dict:
        """Get session data for a user."""
        if self._using_redis:
            try:
                data = self._redis_client.get(f"{REDIS_SESSION_PREFIX}{user_id}")
                if data:
                    session = json.loads(data)
                    # Check expiry
                    expires = datetime.fromisoformat(session.get('expires', '2000-01-01'))
                    if datetime.now() > expires:
                        self.delete(user_id)
                        return None
                    return session
                return None
            except (RedisError, json.JSONDecodeError, Exception) as e:
                logger.warning(f"[Script Studio] Redis get failed: {e}")
                return self._get_flask_session_data(user_id)
        else:
            return self._get_flask_session_data(user_id)

    def set(self, user_id: int, session_data: dict):
        """Store session data for a user."""
        if self._using_redis:
            try:
                # Convert datetime to ISO format for JSON
                data = session_data.copy()
                if 'activated' in data and isinstance(data['activated'], datetime):
                    data['activated'] = data['activated'].isoformat()
                if 'expires' in data and isinstance(data['expires'], datetime):
                    data['expires'] = data['expires'].isoformat()

                self._redis_client.setex(
                    f"{REDIS_SESSION_PREFIX}{user_id}",
                    REDIS_SESSION_TTL,
                    json.dumps(data)
                )
                logger.debug(f"[Script Studio] Session stored in Redis for user {user_id}")
            except (RedisError, Exception) as e:
                logger.warning(f"[Script Studio] Redis set failed: {e}, using memory fallback")
                self._set_flask_session_data(user_id, session_data)
        else:
            self._set_flask_session_data(user_id, session_data)

    def delete(self, user_id: int) -> bool:
        """Delete session data for a user."""
        deleted = False
        key = self._session_key(user_id)
        if self._using_redis:
            try:
                deleted = self._redis_client.delete(f"{REDIS_SESSION_PREFIX}{user_id}") > 0
            except (RedisError, Exception) as e:
                logger.warning(f"[Script Studio] Redis delete failed: {e}")

        if has_request_context():
            if session.pop(key, None) is not None:
                session.modified = True
                deleted = True
        elif self._memory_sessions.pop(key, None) is not None:
            deleted = True

        return deleted

    def exists(self, user_id: int) -> bool:
        """Check if session exists for a user."""
        return self.get(user_id) is not None

    @property
    def storage_type(self) -> str:
        """Return the current storage backend type."""
        return "redis" if self._using_redis else "memory"

    def get_stats(self) -> dict:
        """Get storage statistics."""
        stats = {
            'storage_type': self.storage_type,
            'redis_enabled': REDIS_ENABLED,
            'redis_available': self._using_redis
        }
        if self._using_redis:
            try:
                # Count active sessions
                cursor, keys = self._redis_client.scan(match=f"{REDIS_SESSION_PREFIX}*")
                stats['active_sessions'] = len(keys)
            except (RedisError, Exception):
                stats['active_sessions'] = 'unknown'
        else:
            stats['active_sessions'] = len(self._memory_sessions)
        return stats


# Initialize the session manager (singleton)
_session_manager = SessionManager()

# In-memory cache for validated licenses (TTL-based, refreshed from disk)
_license_cache = {
    'developer_license': None,
    'developer_license_valid': False,
    'developer_license_expiry': None,
    'last_validated': None
}


# =============================================================================
# Developer License Functions (Level 2 - Purchasable Add-on)
# =============================================================================

def _load_developer_license() -> dict:
    """Load Developer Script Studio license from file."""
    try:
        if SCRIPT_STUDIO_LICENSE_FILE.exists():
            data = json.loads(SCRIPT_STUDIO_LICENSE_FILE.read_text())
            return data
    except Exception as e:
        logger.warning(f"Failed to load Script Studio license: {e}")
    return {}


def _save_developer_license(license_data: dict) -> bool:
    """Save Developer Script Studio license to file."""
    try:
        SCRIPT_STUDIO_LICENSE_FILE.write_text(json.dumps(license_data, indent=2))
        return True
    except Exception as e:
        logger.error(f"Failed to save Script Studio license: {e}")
        return False


def _validate_developer_license_key(key: str) -> tuple:
    """
    Validate a Developer Script Studio license key.

    Key format: DSS-XXXX-XXXX-XXXX-XXXX

    Returns: (valid: bool, message: str, expiry_date: str or None)
    """
    if not key:
        return False, "No license key provided", None

    key = key.strip().upper()

    # Check format: DSS-XXXX-XXXX-XXXX-XXXX
    if not key.startswith('DSS-'):
        return False, "Invalid key format (must start with DSS-)", None

    parts = key.split('-')
    if len(parts) != 5:
        return False, "Invalid key format (expected DSS-XXXX-XXXX-XXXX-XXXX)", None

    # Check each segment is 4 alphanumeric characters
    for i, part in enumerate(parts):
        if i == 0:  # Skip "DSS" prefix
            continue
        if len(part) != 4 or not part.isalnum():
            return False, f"Invalid key segment: {part}", None

    # Validate checksum (simple validation - last segment encodes expiry)
    # In production, this would call a license server
    try:
        # Extract expiry from key (encoded in segments)
        # Format: Year in segment 2, Month in segment 3
        year_code = parts[1][:2]
        month_code = parts[2][:2]

        # Simple decode (A=0, B=1, etc. for first char, second char is number)
        year = 2024 + int(year_code[1]) if year_code[0].isalpha() else 2026
        month = int(month_code[1]) if month_code[0].isalpha() else 12

        # Default to 1 year from activation if can't decode
        expiry_date = f"{year + 1}-{month:02d}-01"

        # Check if valid (not obviously fake)
        checksum = sum(ord(c) for c in key) % 100
        if checksum < 10:  # Very basic anti-fake check
            return False, "Invalid license key (checksum failed)", None

        return True, "License key valid", expiry_date

    except Exception as e:
        logger.warning(f"License validation error: {e}")
        # For demo/dev, accept any properly formatted key
        default_expiry = (datetime.now() + timedelta(days=365)).strftime('%Y-%m-%d')
        return True, "License key accepted", default_expiry


def _is_developer_license_active() -> bool:
    """Check if a valid Developer Script Studio license is active."""
    # Check cache first
    if _license_cache['developer_license_valid']:
        if _license_cache['developer_license_expiry']:
            try:
                expiry = datetime.strptime(_license_cache['developer_license_expiry'], '%Y-%m-%d')
                if expiry > datetime.now():
                    return True
            except (ValueError, TypeError):
                pass

    # Load from file
    license_data = _load_developer_license()
    if not license_data.get('key'):
        return False

    # Validate stored license
    valid, _, expiry = _validate_developer_license_key(license_data['key'])
    if valid and expiry:
        try:
            expiry_date = datetime.strptime(expiry, '%Y-%m-%d')
            if expiry_date > datetime.now():
                # Update cache
                _license_cache['developer_license'] = license_data['key']
                _license_cache['developer_license_valid'] = True
                _license_cache['developer_license_expiry'] = expiry
                return True
        except (ValueError, TypeError):
            pass

    return False


def _get_developer_license_info() -> dict:
    """Get information about the current Developer Script Studio license."""
    license_data = _load_developer_license()
    if not license_data.get('key'):
        return {
            'has_license': False,
            'status': 'not_licensed',
            'message': 'No Developer Script Studio license installed'
        }

    valid, message, expiry = _validate_developer_license_key(license_data['key'])

    if not valid:
        return {
            'has_license': True,
            'status': 'invalid',
            'key_masked': license_data['key'][:8] + '****',
            'message': message
        }

    # Check expiry
    try:
        expiry_date = datetime.strptime(expiry, '%Y-%m-%d')
        if expiry_date < datetime.now():
            return {
                'has_license': True,
                'status': 'expired',
                'key_masked': license_data['key'][:8] + '****',
                'expiry': expiry,
                'message': 'License expired - please renew'
            }
    except (ValueError, TypeError):
        pass

    return {
        'has_license': True,
        'status': 'active',
        'key_masked': license_data['key'][:8] + '****',
        'expiry': expiry,
        'activated': license_data.get('activated'),
        'message': 'License active'
    }


def _activate_developer_license(license_key: str) -> tuple:
    """
    Activate a Developer Script Studio license.

    Returns: (success: bool, message: str)
    """
    if not license_key:
        return False, "No license key provided"

    # Validate the key
    valid, message, expiry = _validate_developer_license_key(license_key)

    if not valid:
        logger.warning(f"Invalid Script Studio license attempt: {message}")
        return False, message

    # Check expiry
    try:
        expiry_date = datetime.strptime(expiry, '%Y-%m-%d')
        if expiry_date < datetime.now():
            return False, "This license key has expired"
    except (ValueError, TypeError):
        pass

    # Save the license
    license_data = {
        'key': license_key.strip().upper(),
        'activated': datetime.now().isoformat(),
        'expiry': expiry,
        'activated_by': getattr(current_user, 'username', 'unknown') if FLASK_LOGIN_AVAILABLE and current_user else 'system'
    }

    if _save_developer_license(license_data):
        # Update cache
        _license_cache['developer_license'] = license_data['key']
        _license_cache['developer_license_valid'] = True
        _license_cache['developer_license_expiry'] = expiry

        logger.info(f"[SCRIPT STUDIO] Developer license activated: {license_data['key'][:8]}****, expires {expiry}")
        return True, f"Developer Script Studio license activated! Valid until {expiry}"

    return False, "Failed to save license"


def _deactivate_developer_license() -> tuple:
    """Remove the Developer Script Studio license."""
    try:
        if SCRIPT_STUDIO_LICENSE_FILE.exists():
            SCRIPT_STUDIO_LICENSE_FILE.unlink()

        # Clear cache
        _license_cache['developer_license'] = None
        _license_cache['developer_license_valid'] = False
        _license_cache['developer_license_expiry'] = None

        logger.info("[SCRIPT STUDIO] Developer license deactivated")
        return True, "License deactivated"
    except Exception as e:
        logger.error(f"Failed to deactivate license: {e}")
        return False, f"Failed to deactivate: {e}"


# =============================================================================
# Support Mode Functions (Level 3 - Full Script Access)
# =============================================================================

def _is_support_mode_available() -> bool:
    """Check if support mode capability is configured (key is set)."""
    return SUPPORT_MODE_KEY is not None and len(SUPPORT_MODE_KEY) >= 8


def _is_support_mode_active() -> bool:
    """Check if support mode is currently active for this session."""
    if not _is_support_mode_available():
        return False
    if not FLASK_LOGIN_AVAILABLE or not current_user:
        return False
    user_id = getattr(current_user, 'id', None)
    if not user_id:
        return False
    # Use session manager for Redis/memory backend
    session_data = _session_manager.get(user_id)
    if not session_data:
        return False
    # Expiry is handled by session manager
    return True


def _activate_support_mode(provided_key: str) -> tuple:
    """
    Activate support mode for the current user session.

    Returns: (success: bool, message: str)
    """
    if not _is_support_mode_available():
        return False, "Support mode is not configured on this server"

    # SECURITY: Use constant-time comparison to prevent timing attacks (OWASP A07)
    if not hmac.compare_digest(provided_key.encode('utf-8'), SUPPORT_MODE_KEY.encode('utf-8')):
        logger.warning(f"Failed support mode activation attempt by user {getattr(current_user, 'username', 'unknown')}")
        return False, "Invalid support key"

    if not FLASK_LOGIN_AVAILABLE or not current_user:
        return False, "Authentication required"

    user_id = getattr(current_user, 'id', None)
    username = getattr(current_user, 'username', 'unknown')

    if not user_id:
        return False, "User ID not available"

    # Activate for 4 hours using session manager (Redis or memory backend)
    expires = datetime.now() + timedelta(hours=4)
    _session_manager.set(user_id, {
        'activated': datetime.now(),
        'expires': expires,
        'username': username
    })

    storage_info = f" [{_session_manager.storage_type}]" if _session_manager.storage_type == 'redis' else ""
    logger.info(f"[SUPPORT MODE] Activated by {username} (user_id={user_id}), expires {expires.isoformat()}{storage_info}")
    return True, f"Support mode activated until {expires.strftime('%H:%M:%S')}"


def _deactivate_support_mode() -> tuple:
    """Deactivate support mode for the current user session."""
    if not FLASK_LOGIN_AVAILABLE or not current_user:
        return False, "Authentication required"

    user_id = getattr(current_user, 'id', None)
    username = getattr(current_user, 'username', 'unknown')

    if user_id and _session_manager.exists(user_id):
        _session_manager.delete(user_id)
        logger.info(f"[SUPPORT MODE] Deactivated by {username}")
        return True, "Support mode deactivated"

    return False, "Support mode was not active"


# Paths - relative to ROOT_DIR
AUDITS_DIR = Path(ROOT_DIR) / 'audits'
CUSTOM_SCRIPTS_DIR = AUDITS_DIR / 'custom'
FIX_SCRIPTS_DIR = Path(ROOT_DIR) / 'fix'
LIB_DIR = Path(ROOT_DIR) / 'lib'
TEMPLATES_DIR = Path(ROOT_DIR) / 'tools' / 'developer-script-studio' / 'templates'
BACKUP_DIR = Path(ROOT_DIR) / 'backups' / 'script-studio'
PSSCRIPTANALYZER_SETTINGS_PATH = Path(ROOT_DIR) / 'PSScriptAnalyzerSettings.Gate.psd1'


def get_user_permissions():
    """
    Get current user's script editing permissions based on Script Studio licensing.

    Three-tier access model:
    - Level 1 (View): SuperAdmin role - view all scripts (read-only) - FREE
    - Level 2 (Developer): Developer Script Studio license - create/edit/validate custom scripts - PAID ADD-ON
    - Level 3 (Support): Internal support mode - edit ALL scripts - INTERNAL ONLY

    Returns:
        dict: {
            can_edit_custom: bool,
            can_edit_core: bool,
            can_create: bool,
            can_validate: bool,
            access_level: str ('view'|'developer'|'support'),
            developer_license: dict (license info),
            support_mode_active: bool (internal only, not shown to users)
        }
    """
    # Get license info
    license_info = _get_developer_license_info()
    developer_licensed = license_info.get('status') == 'active'

    # Support mode is internal only - check if active
    support_active = _is_support_mode_active()

    permissions = {
        'can_edit_custom': False,
        'can_edit_core': False,
        'can_create': False,
        'can_validate': False,
        'access_level': 'view',  # Default: view-only (Level 1)
        'developer_license': license_info,
        # Support mode is INTERNAL ONLY - not exposed in customer-facing UI
        # Only used for backend permission checks
        '_support_mode_active': support_active
    }

    # Check authentication
    if not is_authenticated():
        return permissions

    # Level 2: Developer license grants custom script editing/validation
    if developer_licensed:
        permissions['can_edit_custom'] = True
        permissions['can_create'] = True
        permissions['can_validate'] = True
        permissions['access_level'] = 'developer'

    # Level 3: Support mode grants FULL editing (INTERNAL ONLY)
    # This is NOT shown in customer UI - only available via env var
    if support_active:
        permissions['can_edit_core'] = True
        permissions['can_edit_custom'] = True
        permissions['can_create'] = True
        permissions['can_validate'] = True
        permissions['access_level'] = 'support'

    return permissions


def is_custom_script(file_path):
    """
    Check if a file is in the custom scripts directory.

    SECURITY: Uses Path.is_relative_to() for safe path traversal prevention (OWASP A01).
    Prevents attacks like: /audits/custom/../../../etc/passwd
    """
    try:
        path = Path(file_path).resolve()
        custom_dir = CUSTOM_SCRIPTS_DIR.resolve()
        # SECURITY: Use is_relative_to() instead of startswith() to prevent path traversal
        # This properly handles cases like '../' that could escape the directory
        try:
            path.relative_to(custom_dir)
            return True
        except ValueError:
            return False
    except Exception:
        return False


def is_fix_script(file_path):
    """
    Check if a file is in the fix scripts directory.

    Fix scripts are customer-visible in Script Studio but remain read-only unless
    hidden support mode is explicitly activated.
    """
    try:
        path = Path(file_path).resolve()
        fix_dir = FIX_SCRIPTS_DIR.resolve()
        try:
            path.relative_to(fix_dir)
            return True
        except ValueError:
            return False
    except Exception:
        return False


def is_core_script(file_path):
    """Check if a file belongs to the core audit or fix script trees."""
    try:
        path = Path(file_path).resolve()
        audits_dir = AUDITS_DIR.resolve()
        fix_dir = FIX_SCRIPTS_DIR.resolve()

        try:
            path.relative_to(audits_dir)
            return not is_custom_script(file_path)
        except ValueError:
            pass

        try:
            path.relative_to(fix_dir)
            return True
        except ValueError:
            return False
    except Exception:
        return False


def is_customer_writable_path(file_path):
    """Customer editing is limited to custom scripts only."""
    return is_custom_script(file_path)


def is_editable_path(file_path, permissions):
    """Check if the user can edit this file path based on permissions."""
    if is_customer_writable_path(file_path):
        return permissions['can_edit_custom']
    if is_core_script(file_path):
        return permissions['can_edit_core']
    return False


def backup_file(file_path):
    """Create a backup of a file before editing."""
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        path = Path(file_path)
        if path.exists():
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_name = f"{path.stem}_{timestamp}{path.suffix}"
            backup_path = BACKUP_DIR / backup_name
            backup_path.write_text(path.read_text())
            return str(backup_path)
    except Exception as e:
        logger.error(f"Backup failed: {e}")
    return None


# Embedded Script Studio HTML template
SCRIPT_STUDIO_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Script Studio - Security Audit Toolkit</title>
    <link rel="stylesheet" href="/static/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/editor/editor.main.min.css">
    <style>
        :root {
            --bg-primary: #1e1e1e;
            --bg-secondary: #252526;
            --bg-tertiary: #2d2d30;
            --bg-card: #1f2937;
            --bg-hover: #3c3c3c;
            --bg-active: #094771;
            --border-color: #3c3c3c;
            --text-primary: #cccccc;
            --text-secondary: #8b8b8b;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --accent-red: #ef4444;
            --accent-yellow: #f59e0b;
            --accent-orange: #ce9178;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 13px;
            color: var(--text-primary);
            background-color: var(--bg-primary);
            height: 100vh;
            overflow: hidden;
        }

        .studio-wrapper {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        /* Header */
        .studio-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--bg-tertiary) 100%);
            border-bottom: 1px solid var(--border-color);
            min-height: 48px;
        }

        .header-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-brand-icon { font-size: 1.5rem; }

        .header-brand h1 {
            font-size: 1.125rem;
            color: var(--text-primary);
            font-weight: 600;
        }

        .brand-subtitle {
            font-size: 0.7rem;
            color: var(--text-secondary);
        }

        /* Navigation */
        .studio-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.4rem 0.8rem;
            border-radius: 6px;
            font-size: 0.8rem;
            transition: all 0.2s;
        }

        .nav-link:hover { background: rgba(59, 130, 246, 0.1); color: var(--text-primary); }
        .nav-link.active { background: var(--accent-blue); color: white; }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding-left: 0.75rem;
            border-left: 1px solid var(--border-color);
            margin-left: 0.5rem;
        }

        .user-badge {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.25rem 0.6rem;
            background: rgba(59, 130, 246, 0.1);
            border-radius: 16px;
            font-size: 0.75rem;
        }

        .tier-badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            font-weight: 600;
        }

        /* Access Level Badges */
        .tier-badge.view { background: var(--bg-hover); color: var(--text-secondary); }
        .tier-badge.developer { background: var(--accent-blue); color: white; }
        .tier-badge.support { background: linear-gradient(135deg, #dc2626, #f87171); color: white; }

        /* Developer Mode Button */
        .toolbar-btn.developer-active {
            background: linear-gradient(135deg, #3b82f6, #60a5fa);
            border-color: #3b82f6;
            color: white;
        }
        .toolbar-btn.developer-active:hover {
            background: linear-gradient(135deg, #2563eb, #3b82f6);
        }
        .developer-mode-toggle { margin-left: auto; margin-right: 0.5rem; }

        .logout-btn {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.3rem 0.6rem;
            border-radius: 4px;
            font-size: 0.75rem;
            border: 1px solid var(--border-color);
        }

        .logout-btn:hover { background: rgba(239, 68, 68, 0.1); border-color: var(--accent-red); color: var(--accent-red); }

        /* Toolbar */
        .toolbar {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 1rem;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
        }

        .toolbar-btn {
            display: flex;
            align-items: center;
            gap: 4px;
            padding: 5px 10px;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s;
        }

        .toolbar-btn:hover:not(:disabled) { background: var(--bg-hover); border-color: var(--accent-blue); }
        .toolbar-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .toolbar-btn.primary { background: var(--accent-blue); border-color: var(--accent-blue); }
        .toolbar-btn.primary:hover { background: #2563eb; }

        /* Support Mode Button */
        .toolbar-btn.support-active {
            background: linear-gradient(135deg, #dc2626, #f87171);
            border-color: #dc2626;
            color: white;
            animation: support-pulse 2s ease-in-out infinite;
        }
        .toolbar-btn.support-active:hover {
            background: linear-gradient(135deg, #b91c1c, #ef4444);
        }
        @keyframes support-pulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.4); }
            50% { box-shadow: 0 0 0 4px rgba(220, 38, 38, 0); }
        }
        .support-mode-toggle { margin-left: auto; margin-right: 0.5rem; }

        .toolbar-divider { width: 1px; height: 24px; background: var(--border-color); margin: 0 0.5rem; }

        .file-info {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 12px;
        }

        .file-name { font-weight: 500; color: var(--text-primary); }
        .file-status { color: var(--accent-yellow); }
        .file-readonly { color: var(--accent-red); font-size: 10px; padding: 2px 6px; background: rgba(239, 68, 68, 0.2); border-radius: 4px; }

        /* Main layout */
        .main-content {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            min-width: 200px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            padding: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .search-input {
            width: 100%;
            padding: 6px 10px;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            color: var(--text-primary);
            font-size: 12px;
        }

        .search-input:focus { outline: none; border-color: var(--accent-blue); }

        .file-tree {
            flex: 1;
            overflow-y: auto;
            padding: 0.25rem 0;
        }

        .tree-item {
            display: flex;
            align-items: center;
            padding: 4px 8px;
            cursor: pointer;
            font-size: 12px;
            border-left: 2px solid transparent;
        }

        .tree-item:hover { background: var(--bg-hover); }
        .tree-item.selected { background: var(--bg-active); border-left-color: var(--accent-blue); }
        .tree-item.folder { font-weight: 500; color: var(--accent-yellow); }
        .tree-item .icon { margin-right: 6px; font-size: 14px; }

        .tree-children { padding-left: 1rem; }
        .tree-children.collapsed { display: none; }

        /* Editor area */
        .editor-section { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

        .editor-container { flex: 1; overflow: hidden; }

        /* Copy protection: prevent selection in editor when viewing protected content */
        .editor-container.copy-protected {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        .editor-container.copy-protected .monaco-editor .view-lines {
            -webkit-user-select: none !important;
            user-select: none !important;
        }

        .editor-placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: var(--text-secondary);
        }

        .placeholder-content { text-align: center; }
        .placeholder-content h2 { font-size: 1.5rem; margin-bottom: 0.5rem; color: var(--text-primary); }
        .placeholder-content p { margin-bottom: 1.5rem; }

        .quick-actions { display: flex; gap: 1rem; justify-content: center; }

        .action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            padding: 1.5rem 2rem;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            cursor: pointer;
            transition: all 0.2s;
        }

        .action-btn:hover { background: var(--bg-tertiary); border-color: var(--accent-blue); }
        .action-btn .icon { font-size: 2rem; }

        /* Problems panel */
        .problems-panel {
            border-top: 1px solid var(--border-color);
            background: var(--bg-secondary);
            max-height: 200px;
        }

        .problems-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 0.75rem;
            background: var(--bg-tertiary);
            cursor: pointer;
        }

        .problems-title { font-weight: 500; font-size: 11px; text-transform: uppercase; }
        .problems-count { background: var(--accent-red); color: white; padding: 0 6px; border-radius: 10px; font-size: 10px; }
        .problems-count.zero { background: var(--bg-hover); }
        .problems-toggle { margin-left: auto; background: none; border: none; color: var(--text-secondary); cursor: pointer; }

        .problems-list { max-height: 150px; overflow-y: auto; }
        .problems-list.collapsed { display: none; }

        .problem-item {
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
            padding: 0.4rem 0.75rem;
            font-size: 12px;
            border-bottom: 1px solid var(--border-color);
        }

        .problem-item:hover { background: var(--bg-hover); }
        .problem-icon.error { color: var(--accent-red); }
        .problem-icon.warning { color: var(--accent-yellow); }

        /* Status bar */
        .status-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 0.75rem;
            height: 22px;
            background: var(--accent-blue);
            color: white;
            font-size: 11px;
        }

        .status-bar .divider { margin: 0 0.5rem; opacity: 0.5; }

        /* Modal */
        .modal { display: none; position: fixed; inset: 0; z-index: 1000; }
        .modal.active { display: flex; align-items: center; justify-content: center; }

        .modal-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,0.7); }

        .modal-content {
            position: relative;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow: auto;
        }

        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-header h3 { font-size: 1rem; }

        .modal-close {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.25rem;
            cursor: pointer;
        }

        .modal-body { padding: 1rem; }

        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; margin-bottom: 0.25rem; font-size: 12px; color: var(--text-secondary); }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.5rem;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            color: var(--text-primary);
            font-size: 13px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            padding: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .btn {
            padding: 0.5rem 1rem;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 13px;
        }

        .btn-primary { background: var(--accent-blue); color: white; }
        .btn-secondary { background: var(--bg-tertiary); color: var(--text-primary); border: 1px solid var(--border-color); }
    </style>
</head>
<body>
    <div class="studio-wrapper">
        <!-- Header -->
        <header class="studio-header">
            <div class="header-brand">
                <span class="header-brand-icon">📝</span>
                <div>
                    <h1>Developer Script Studio</h1>
                    <div class="brand-subtitle">Security Audit Toolkit</div>
                </div>
            </div>

            <nav class="studio-nav">
                <a href="/" class="nav-link" target="_top">🏠 Home</a>
                <a href="/overview" class="nav-link" target="_top">📖 Overview</a>
                <a href="/dashboard" class="nav-link" target="_top">📊 Dashboard</a>
                <a href="/deploy" class="nav-link" target="_top">🚀 Support Tools</a>
                <a href="/asset-discovery" class="nav-link" target="_top">🔍 Asset Discovery</a>
                <a href="/script-studio" class="nav-link active" target="_top">📝 Script Studio</a>
                <a href="/console" class="nav-link" target="_top">💻 Console</a>

                {% if current_user %}
                <div class="user-info">
                    <span class="tier-badge {{ permissions.tier }}">{{ permissions.tier }}</span>
                    <div class="user-badge">
                        <span>{{ current_user.username or 'User' }}</span>
                    </div>
                    <a href="/auth/logout" class="logout-btn">Logout</a>
                </div>
                {% endif %}
            </nav>
        </header>

        <!-- Toolbar -->
        <div class="toolbar">
            <button class="toolbar-btn" id="btn-new" title="New Script (Ctrl+N)">
                <span class="icon">📄</span> New
            </button>
            <button class="toolbar-btn" id="btn-unload" disabled title="Unload current script">
                <span class="icon">🧹</span> Clear
            </button>
            <button class="toolbar-btn" id="btn-view" disabled title="View selected script">
                <span class="icon">👁️</span> View
            </button>
            <button class="toolbar-btn" id="btn-edit" disabled title="Edit selected script">
                <span class="icon">✏️</span> Edit
            </button>
            <button class="toolbar-btn" id="btn-save" disabled title="Save (Ctrl+S)">
                <span class="icon">💾</span> Save
            </button>
            <div class="toolbar-divider"></div>
            <button class="toolbar-btn" id="btn-validate" disabled title="Validate Script">
                <span class="icon">✓</span> Validate
            </button>

            <div class="file-info">
                <span class="file-name" id="file-name">No file open</span>
                <span class="file-status" id="file-status"></span>
                <span class="file-readonly" id="file-readonly" style="display: none;">READ-ONLY</span>
            </div>

            <!-- Developer License Status & Activation -->
            <div class="license-status-toggle" id="license-container" style="margin-left: auto; display: flex; align-items: center; gap: 0.5rem;">
                {% if permissions.developer_license.status == 'active' %}
                <!-- Licensed: Show status -->
                <span class="tier-badge developer" title="Developer Script Studio License Active until {{ permissions.developer_license.expiry }}">
                    ✓ LICENSED
                </span>
                {% elif permissions.developer_license.status == 'expired' %}
                <!-- Expired: Show renewal option -->
                <button class="toolbar-btn" id="btn-activate-license" title="Your license has expired - click to renew" style="border-color: #f59e0b; color: #f59e0b;">
                    <span class="icon">⚠️</span> License Expired
                </button>
                {% else %}
                <!-- Not Licensed: Show activation/purchase option -->
                <button class="toolbar-btn" id="btn-activate-license" title="Activate Developer Script Studio license to create custom scripts">
                    <span class="icon">🔑</span> Activate License
                </button>
                {% endif %}
            </div>

            <span class="tier-badge {{ permissions.access_level }}" title="Access Level">{{ permissions.access_level|upper }}</span>
        </div>

        <!-- Main content -->
        <main class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <div class="sidebar-header">
                    <input type="text" class="search-input" id="file-search" placeholder="Search scripts...">
                </div>
                <div class="file-tree" id="file-tree">
                    <div style="padding: 1rem; color: var(--text-secondary);">Loading...</div>
                </div>
            </aside>

            <!-- Editor -->
            <section class="editor-section">
                <div class="editor-container" id="editor-container">
                    <div class="editor-placeholder" id="editor-placeholder">
                        <div class="placeholder-content">
                            <h2>Developer Script Studio</h2>
                            <p>Create and edit security audit scripts</p>
                            <div class="quick-actions">
                                <button class="action-btn" id="btn-new-bash">
                                    <span class="icon">🐧</span>
                                    New Bash Script
                                </button>
                                <button class="action-btn" id="btn-new-ps">
                                    <span class="icon">🪟</span>
                                    New PowerShell Script
                                </button>
                            </div>
                            {% if not permissions.can_create %}
                            <p style="margin-top: 1.5rem; color: var(--accent-yellow);">
                                ⚠️ View-only mode -
                                <a href="#" onclick="showModal('license-modal'); return false;" style="color: #3b82f6;">
                                    Activate Developer Script Studio License
                                </a> to create/edit custom scripts
                            </p>
                            {% endif %}
                        </div>
                    </div>
                </div>

                <!-- Problems panel -->
                <div class="problems-panel">
                    <div class="problems-header" id="problems-header">
                        <span class="problems-title">Problems</span>
                        <span class="problems-count zero" id="problems-count">0</span>
                        <button class="problems-toggle" id="problems-toggle">▼</button>
                    </div>
                    <div class="problems-list" id="problems-list"></div>
                </div>
            </section>
        </main>

        <!-- Status bar -->
        <footer class="status-bar">
            <div id="status-message">Ready</div>
            <div>
                <span id="copy-protection-badge" style="display: none; color: #f87171; font-size: 11px; padding: 2px 8px; background: rgba(248, 113, 113, 0.15); border-radius: 4px; margin-right: 8px;">🔒 Copy Protected</span>
                <span id="edit-mode-badge" style="display: none; color: #4ade80; font-size: 11px; padding: 2px 8px; background: rgba(74, 222, 128, 0.15); border-radius: 4px; margin-right: 8px;">✏️ Editable</span>
                <span id="cursor-position">Ln 1, Col 1</span>
                <span class="divider">|</span>
                <span id="language-mode">Plain Text</span>
                <span class="divider">|</span>
                <span>UTF-8</span>
            </div>
        </footer>
    </div>

    <!-- New Script Modal -->
    <div class="modal" id="new-script-modal">
        <div class="modal-backdrop"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create New Script</h3>
                <button class="modal-close" data-modal="new-script-modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Script Name</label>
                    <input type="text" id="script-name" placeholder="my-audit-script">
                </div>
                <div class="form-group">
                    <label>Script Type</label>
                    <select id="script-type">
                        <option value="bash">Bash (Linux)</option>
                        <option value="powershell">PowerShell (Windows)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Template</label>
                    <select id="script-template">
                        <option value="basic">Basic Audit</option>
                        <option value="compliance">Compliance Check</option>
                        <option value="security">Security Assessment</option>
                        <option value="empty">Empty Script</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Category (folder)</label>
                    <input type="text" id="script-category" placeholder="general" value="general">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-modal="new-script-modal">Cancel</button>
                <button class="btn btn-primary" id="btn-create-script">Create</button>
            </div>
        </div>
    </div>

    <!-- Developer Script Studio License Modal -->
    <div class="modal" id="license-modal">
        <div class="modal-backdrop"></div>
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header" style="background: linear-gradient(135deg, #3b82f6, #60a5fa);">
                <h3 style="color: white;">🛠️ Developer Script Studio License</h3>
                <button class="modal-close" data-modal="license-modal" style="color: white;">&times;</button>
            </div>
            <div class="modal-body">
                <!-- Product Info -->
                <div style="background: rgba(59, 130, 246, 0.1); border: 1px solid #3b82f6; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                    <strong style="color: #60a5fa;">Developer Script Studio Add-on</strong>
                    <p style="margin: 0.5rem 0 0; font-size: 0.9rem; color: var(--text-secondary);">
                        Unlock the ability to <strong>create and edit custom audit scripts</strong> in the <code>audits/custom/</code> directory.
                    </p>
                    <ul style="margin: 0.75rem 0 0; padding-left: 1.25rem; font-size: 0.85rem; color: var(--text-secondary);">
                        <li>Create custom Bash and PowerShell audit scripts</li>
                        <li>Use built-in templates (CIS, NIST, Security, etc.)</li>
                        <li>Script validation with ShellCheck/PSScriptAnalyzer</li>
                        <li>Auto-backup before edits</li>
                    </ul>
                </div>

                <!-- Current License Status -->
                <div id="license-status-display" style="padding: 0.75rem; border-radius: 6px; margin-bottom: 1rem; background: rgba(139, 92, 246, 0.1); border: 1px solid #8b5cf6;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #a78bfa;">Current Status:</span>
                        <span id="license-status-text" style="font-weight: 600;">{{ permissions.developer_license.status|upper }}</span>
                    </div>
                    {% if permissions.developer_license.expiry %}
                    <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.25rem;">
                        Expires: {{ permissions.developer_license.expiry }}
                    </div>
                    {% endif %}
                </div>

                <!-- License Key Input -->
                <div class="form-group">
                    <label>License Key</label>
                    <input type="text" id="license-key-input" placeholder="DSS-XXXX-XXXX-XXXX-XXXX" style="font-family: monospace; letter-spacing: 1px;">
                    <small style="color: var(--text-secondary);">
                        Format: DSS-XXXX-XXXX-XXXX-XXXX
                    </small>
                </div>

                <div id="license-activation-status" style="display: none; padding: 0.75rem; border-radius: 6px; margin-top: 1rem;"></div>

                <!-- Purchase Link -->
                <div style="text-align: center; margin-top: 1.25rem; padding-top: 1rem; border-top: 1px solid var(--border-color);">
                    <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
                        Don't have a license key?
                    </p>
                    <a href="/pricing?feature=script-studio&source=script-studio" id="btn-purchase-license" target="_blank" rel="noopener noreferrer" style="color: #3b82f6; text-decoration: none; font-weight: 500;">
                        Purchase Developer Script Studio License →
                    </a>
                    <p style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 0.5rem;">
                        ~$99-299/year (separate from main toolkit license)
                    </p>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="btn-return-to-editor" data-modal="license-modal">Return to Script Editor</button>
                <button class="btn" id="btn-submit-license" style="background: #3b82f6; color: white;">Activate License</button>
            </div>
        </div>
    </div>

    <!-- Monaco Editor -->
    <script src="https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/loader.min.js"></script>
    <script>
        // App state
        const state = {
            editor: null,
            currentFile: null,
            isDirty: false,
            editorMode: 'view',
            permissions: {{ permissions | tojson }},
            searchFilter: ''
        };

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            initMonaco();
            initUI();
            loadFileTree();
        });

        // Initialize Monaco
        function initMonaco() {
            require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }});
            require(['vs/editor/editor.main'], function() {
                state.editor = monaco.editor.create(document.getElementById('editor-container'), {
                    value: '',
                    language: 'shell',
                    theme: 'vs-dark',
                    automaticLayout: true,
                    minimap: { enabled: true },
                    fontSize: 14,
                    wordWrap: 'on',
                    readOnly: true,
                    // Copy protection: disable context menu
                    contextmenu: false
                });

                state.editor.onDidChangeCursorPosition((e) => {
                    document.getElementById('cursor-position').textContent =
                        `Ln ${e.position.lineNumber}, Col ${e.position.column}`;
                });

                state.editor.onDidChangeModelContent(() => {
                    if (state.currentFile && !state.editor.getOption(monaco.editor.EditorOption.readOnly)) {
                        setDirty(true);
                    }
                });

                // Setup copy protection after editor is ready
                setupCopyProtection();
            });
        }

        // Setup copy/download protection (security feature)
        // NOTE: Protection only applies to READ-ONLY files (original audit scripts)
        // Editable files (custom scripts, scripts user has permission to edit) allow full copy/paste
        function setupCopyProtection() {
            const editorContainer = document.getElementById('editor-container');
            if (!editorContainer) return;

            // Helper to check if current file is protected (read-only)
            function isProtected() {
                return state.currentFile && !state.currentFile.editable;
            }

            // Prevent right-click context menu only on protected files
            editorContainer.addEventListener('contextmenu', (e) => {
                if (isProtected()) {
                    e.preventDefault();
                    setStatus('⚠️ Copying disabled for read-only scripts');
                    return false;
                }
                // Allow context menu for editable files
            });

            // Prevent copy event only on protected files
            editorContainer.addEventListener('copy', (e) => {
                if (isProtected()) {
                    e.preventDefault();
                    setStatus('⚠️ Copying disabled for read-only scripts');
                    return false;
                }
                // Allow copy for editable files
            });

            // Prevent drag only on protected files
            editorContainer.addEventListener('dragstart', (e) => {
                if (isProtected()) {
                    e.preventDefault();
                    return false;
                }
            });

            // Prevent print (Ctrl+P) only for protected files
            document.addEventListener('keydown', (e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'p' && isProtected()) {
                    e.preventDefault();
                    setStatus('⚠️ Printing disabled for read-only scripts');
                    return false;
                }
            });

            console.log('[ScriptStudio] Copy protection initialized (read-only files only)');
        }

        // Initialize UI
        function initUI() {
            const openLicenseModal = (message = 'Developer Script Studio license required for this action') => {
                setStatus(message);
                showModal('license-modal');
            };

            const openCreateScriptEntry = (type = null) => {
                if (!state.permissions.can_create) {
                    openLicenseModal('Developer Script Studio license required to create scripts');
                    return;
                }

                if (type) {
                    document.getElementById('script-type').value = type;
                }

                showModal('new-script-modal');
            };

            const openEditEntry = () => {
                if (!state.currentFile) {
                    setStatus('Open a script to edit it');
                    return;
                }

                if (!state.permissions.can_create) {
                    openLicenseModal('Developer Script Studio license required to edit scripts');
                    return;
                }

                if (!state.currentFile.editable) {
                    setStatus('This script is view-only in the current license level');
                    return;
                }

                setEditorMode('edit');
            };

            // Toolbar
            document.getElementById('btn-new').onclick = () => openCreateScriptEntry();
            document.getElementById('btn-unload').onclick = unloadCurrentFile;
            document.getElementById('btn-view').onclick = () => setEditorMode('view');
            document.getElementById('btn-edit').onclick = openEditEntry;
            document.getElementById('btn-save').onclick = saveFile;
            document.getElementById('btn-validate').onclick = validateScript;

            // Quick actions
            document.getElementById('btn-new-bash').onclick = () => openCreateScriptEntry('bash');
            document.getElementById('btn-new-ps').onclick = () => openCreateScriptEntry('powershell');

            // Modal
            document.querySelectorAll('.modal-close, [data-modal]').forEach(el => {
                el.onclick = (e) => {
                    const id = e.target.dataset.modal || e.target.closest('[data-modal]')?.dataset.modal;
                    if (id) hideModal(id);
                };
            });
            document.querySelectorAll('.modal-backdrop').forEach(el => {
                el.onclick = (e) => e.target.closest('.modal').classList.remove('active');
            });

            document.getElementById('btn-create-script').onclick = createScript;

            // License Activation
            const activateLicenseBtn = document.getElementById('btn-activate-license');
            if (activateLicenseBtn) {
                activateLicenseBtn.onclick = () => {
                    showModal('license-modal');
                };
            }
            const submitLicenseBtn = document.getElementById('btn-submit-license');
            if (submitLicenseBtn) {
                submitLicenseBtn.onclick = activateLicense;
            }
            const returnToEditorBtn = document.getElementById('btn-return-to-editor');
            if (returnToEditorBtn) {
                returnToEditorBtn.onclick = () => hideModal('license-modal');
            }

            // Search
            document.getElementById('file-search').oninput = (e) => {
                state.searchFilter = e.target.value.toLowerCase();
                loadFileTree();
            };

            // Problems toggle
            document.getElementById('problems-header').onclick = () => {
                document.getElementById('problems-list').classList.toggle('collapsed');
            };

            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.key === 's') { e.preventDefault(); saveFile(); }
                if (e.ctrlKey && e.key === 'n') { e.preventDefault(); openCreateScriptEntry(); }
            });

            updateActionButtons();
        }

        function canEditCurrentFile() {
            return Boolean(state.currentFile && state.currentFile.editable && state.permissions.can_create);
        }

        function updateActionButtons() {
            const hasFile = Boolean(state.currentFile);
            const canEdit = canEditCurrentFile();

            document.getElementById('btn-unload').disabled = !hasFile;
            document.getElementById('btn-view').disabled = !hasFile;
            document.getElementById('btn-edit').disabled = !hasFile;
            document.getElementById('btn-save').disabled = !(canEdit && state.editorMode === 'edit');
            document.getElementById('btn-validate').disabled = !(hasFile && state.permissions.can_validate);

            document.getElementById('btn-view').classList.toggle('active', hasFile && state.editorMode === 'view');
            document.getElementById('btn-edit').classList.toggle('active', hasFile && state.editorMode === 'edit');
        }

        function setEditorMode(mode) {
            if (!state.editor || !state.currentFile) {
                return;
            }

            if (mode === 'edit') {
                if (!state.permissions.can_create) {
                    setStatus('Developer Script Studio license required to edit scripts');
                    showModal('license-modal');
                    return;
                }

                if (!state.currentFile.editable) {
                    setStatus('This script is view-only in the current license level');
                    return;
                }
            }

            state.editorMode = mode;
            state.editor.updateOptions({ readOnly: mode !== 'edit' });

            const editBadge = document.getElementById('edit-mode-badge');
            if (state.currentFile.editable && state.permissions.can_create) {
                editBadge.style.display = 'inline';
                editBadge.textContent = mode === 'edit' ? '✏️ Edit Mode' : '👁 View Mode';
            } else {
                editBadge.style.display = 'none';
            }

            updateActionButtons();
            setStatus(mode === 'edit' ? `Editing ${state.currentFile.name}` : `Viewing ${state.currentFile.name}`);
        }

        function unloadCurrentFile() {
            if (state.isDirty && !confirm('Discard unsaved changes?')) return;

            state.currentFile = null;
            state.editorMode = 'view';

            if (state.editor) {
                state.editor.setValue('');
                state.editor.updateOptions({ readOnly: true });
            }

            document.getElementById('editor-placeholder').style.display = 'flex';
            document.getElementById('file-name').textContent = 'No file open';
            document.getElementById('file-status').textContent = '';
            document.getElementById('file-readonly').style.display = 'none';
            document.getElementById('language-mode').textContent = 'Plain Text';
            document.getElementById('copy-protection-badge').style.display = 'none';
            document.getElementById('edit-mode-badge').style.display = 'none';

            document.getElementById('editor-container').classList.remove('copy-protected');
            document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));

            setDirty(false);
            updateActionButtons();
            setStatus('Script unloaded');
        }

        // Load file tree
        async function loadFileTree() {
            try {
                const res = await fetch('/api/script-studio/files');
                const data = await res.json();
                renderFileTree(data.tree || []);
            } catch (e) {
                console.error('Failed to load file tree:', e);
            }
        }

        // Render file tree
        function renderFileTree(tree, container = document.getElementById('file-tree'), level = 0) {
            if (level === 0) container.innerHTML = '';

            tree.forEach(item => {
                if (state.searchFilter && !item.name.toLowerCase().includes(state.searchFilter) && !item.is_directory) {
                    return;
                }

                const div = document.createElement('div');
                div.className = 'tree-item' + (item.is_directory ? ' folder' : '');
                div.style.paddingLeft = (8 + level * 16) + 'px';
                div.innerHTML = `<span class="icon">${item.is_directory ? '📁' : (item.name.endsWith('.ps1') ? '🪟' : '📄')}</span>${item.name}`;

                if (item.is_directory) {
                    div.onclick = () => {
                        const children = div.nextElementSibling;
                        if (children) children.classList.toggle('collapsed');
                    };
                    container.appendChild(div);

                    if (item.children && item.children.length) {
                        const childContainer = document.createElement('div');
                        childContainer.className = 'tree-children collapsed';  // Start collapsed for cleaner UI
                        container.appendChild(childContainer);
                        renderFileTree(item.children, childContainer, level + 1);
                    }
                } else {
                    div.onclick = () => openFile(item.path);
                    container.appendChild(div);
                }
            });
        }

        // Open file
        async function openFile(path) {
            if (state.isDirty && !confirm('Discard unsaved changes?')) return;

            try {
                const res = await fetch(`/api/script-studio/file?path=${encodeURIComponent(path)}`);
                const data = await res.json();

                if (data.error) {
                    alert(data.error);
                    return;
                }

                state.currentFile = data;
                state.editorMode = 'view';
                document.getElementById('editor-placeholder').style.display = 'none';

                const lang = path.endsWith('.ps1') ? 'powershell' : 'shell';
                monaco.editor.setModelLanguage(state.editor.getModel(), lang);
                state.editor.setValue(data.content);
                state.editor.updateOptions({ readOnly: true });

                document.getElementById('file-name').textContent = data.name;
                document.getElementById('file-readonly').style.display = data.editable ? 'none' : 'inline';
                document.getElementById('language-mode').textContent = lang === 'powershell' ? 'PowerShell' : 'Bash';

                // Toggle copy protection based on editability
                const editorContainer = document.getElementById('editor-container');
                const copyBadge = document.getElementById('copy-protection-badge');
                const editBadge = document.getElementById('edit-mode-badge');

                if (!data.editable) {
                    // Read-only: show copy protection, enable CSS protection
                    editorContainer.classList.add('copy-protected');
                    copyBadge.style.display = 'inline';
                    editBadge.style.display = 'none';
                } else {
                    // Editable: allow full editing only when user enters edit mode
                    editorContainer.classList.remove('copy-protected');
                    copyBadge.style.display = 'none';
                    editBadge.style.display = state.permissions.can_create ? 'inline' : 'none';
                }

                setDirty(false);
                updateActionButtons();
                setEditorMode('view');

                // Highlight in tree
                document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
                document.querySelectorAll('.tree-item').forEach(el => {
                    if (el.textContent.includes(data.name) && !el.classList.contains('folder')) {
                        el.classList.add('selected');
                    }
                });
            } catch (e) {
                console.error('Failed to open file:', e);
                setStatus('Failed to open file');
            }
        }

        // Save file
        async function saveFile() {
            if (!state.currentFile || !state.isDirty) return;
            if (!canEditCurrentFile() || state.editorMode !== 'edit') {
                alert('This file is read-only');
                return;
            }

            try {
                const res = await fetch('/api/script-studio/file', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        path: state.currentFile.path,
                        content: state.editor.getValue()
                    })
                });

                const data = await res.json();
                if (data.success) {
                    setDirty(false);
                    setStatus('Saved successfully');
                } else {
                    alert(data.error || 'Save failed');
                }
            } catch (e) {
                console.error('Save failed:', e);
                alert('Save failed');
            }
        }

        // Validate script
        async function validateScript() {
            if (!state.currentFile) return;
            if (!state.permissions.can_validate) {
                setStatus('Developer Script Studio license required to validate scripts');
                showModal('license-modal');
                return;
            }

            try {
                setStatus('Validating...');
                const res = await fetch('/api/script-studio/validate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        content: state.editor.getValue(),
                        language: state.currentFile.path.endsWith('.ps1') ? 'powershell' : 'bash'
                    })
                });

                const data = await res.json();
                renderProblems(data.issues || []);
                setStatus(data.issues?.length ? `${data.issues.length} problem(s) found` : 'No problems found');
            } catch (e) {
                console.error('Validation failed:', e);
                setStatus('Validation failed');
            }
        }

        // Create new script
        async function createScript() {
            if (!state.permissions.can_create) {
                hideModal('new-script-modal');
                setStatus('Developer Script Studio license required to create scripts');
                showModal('license-modal');
                return;
            }

            const name = document.getElementById('script-name').value.trim();
            const type = document.getElementById('script-type').value;
            const template = document.getElementById('script-template').value;
            const category = document.getElementById('script-category').value.trim() || 'general';

            if (!name) { alert('Please enter a script name'); return; }

            try {
                const res = await fetch('/api/script-studio/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, type, template, category })
                });

                const data = await res.json();
                if (data.success) {
                    hideModal('new-script-modal');
                    await loadFileTree();
                    await openFile(data.path);
                    if (canEditCurrentFile()) {
                        setEditorMode('edit');
                    }
                    setStatus(`Created ${data.name}`);
                } else {
                    alert(data.error || 'Failed to create script');
                }
            } catch (e) {
                console.error('Create failed:', e);
                alert('Failed to create script');
            }
        }

        // Render problems
        function renderProblems(issues) {
            const list = document.getElementById('problems-list');
            const count = document.getElementById('problems-count');
            count.textContent = issues.length;
            count.className = 'problems-count' + (issues.length === 0 ? ' zero' : '');

            list.innerHTML = issues.map(issue => `
                <div class="problem-item">
                    <span class="problem-icon ${issue.level}">${issue.level === 'error' ? '❌' : '⚠️'}</span>
                    <span>Line ${issue.line}: ${issue.message}</span>
                </div>
            `).join('');
        }

        // Helpers
        function setDirty(dirty) {
            state.isDirty = dirty;
            document.getElementById('file-status').textContent = dirty ? '● Modified' : '';
        }

        function setStatus(msg) {
            document.getElementById('status-message').textContent = msg;
        }

        function showModal(id) {
            document.getElementById(id).classList.add('active');
        }

        function hideModal(id) {
            document.getElementById(id).classList.remove('active');
        }

        // License Activation Function
        async function activateLicense() {
            const keyInput = document.getElementById('license-key-input');
            const statusDiv = document.getElementById('license-activation-status');
            const key = keyInput.value.trim().toUpperCase();

            if (!key) {
                statusDiv.style.display = 'block';
                statusDiv.style.background = 'rgba(239, 68, 68, 0.1)';
                statusDiv.style.border = '1px solid #dc2626';
                statusDiv.innerHTML = '❌ Please enter a license key';
                return;
            }

            // Basic format validation
            if (!key.startsWith('DSS-')) {
                statusDiv.style.display = 'block';
                statusDiv.style.background = 'rgba(239, 68, 68, 0.1)';
                statusDiv.style.border = '1px solid #dc2626';
                statusDiv.innerHTML = '❌ Invalid format. License key must start with DSS-';
                return;
            }

            try {
                setStatus('Activating license...');

                const res = await fetch('/api/script-studio/license/activate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key })
                });
                const data = await res.json();

                if (data.success) {
                    // Update local state
                    state.permissions = data.permissions;

                    // Update UI
                    statusDiv.style.display = 'block';
                    statusDiv.style.background = 'rgba(74, 222, 128, 0.1)';
                    statusDiv.style.border = '1px solid #22c55e';
                    statusDiv.innerHTML = '✅ ' + data.message;

                    setStatus('✅ Developer Script Studio license activated!');

                    // Update the license container in toolbar
                    const licenseContainer = document.getElementById('license-container');
                    if (licenseContainer) {
                        licenseContainer.innerHTML = `
                            <span class="tier-badge developer" title="Developer Script Studio License Active">
                                ✓ LICENSED
                            </span>
                        `;
                    }

                    // Update access level badge
                    const accessBadge = document.querySelector('.tier-badge[title="Access Level"]');
                    if (accessBadge) {
                        accessBadge.className = 'tier-badge developer';
                        accessBadge.textContent = 'DEVELOPER';
                    }

                    state.permissions.can_create = true;
                    state.permissions.can_edit_custom = true;
                    state.permissions.can_validate = true;
                    state.permissions.access_level = 'developer';
                    state.permissions.developer_license = data.license || { status: 'active' };

                    // Enable create buttons
                    document.querySelectorAll('#btn-new, #btn-new-bash, #btn-new-ps').forEach(btn => {
                        btn.disabled = false;
                        btn.style.opacity = '1';
                    });

                    // Hide the "view-only" warning in placeholder
                    const viewOnlyMsg = document.querySelector('.placeholder-content p[style*="accent-yellow"]');
                    if (viewOnlyMsg) {
                        viewOnlyMsg.style.display = 'none';
                    }

                    updateActionButtons();

                    // Reload current file with new permissions
                    if (state.currentFile) {
                        openFile(state.currentFile.path);
                    }

                    // Close modal after delay
                    setTimeout(() => {
                        hideModal('license-modal');
                        keyInput.value = '';
                        statusDiv.style.display = 'none';
                    }, 2000);
                } else {
                    statusDiv.style.display = 'block';
                    statusDiv.style.background = 'rgba(239, 68, 68, 0.1)';
                    statusDiv.style.border = '1px solid #dc2626';
                    statusDiv.innerHTML = '❌ ' + (data.error || 'License activation failed');
                    setStatus('License activation failed');
                }
            } catch (e) {
                console.error('License activation failed:', e);
                statusDiv.style.display = 'block';
                statusDiv.style.background = 'rgba(239, 68, 68, 0.1)';
                statusDiv.style.border = '1px solid #dc2626';
                statusDiv.innerHTML = '❌ Connection error - please try again';
                setStatus('Connection error');
            }
        }
    </script>
</body>
</html>
'''


# =============================================================================
# Routes
# =============================================================================

@script_studio_bp.route('/script-studio')
@login_required
def script_studio_page():
    """Render the embedded Script Studio page (SuperAdmin only)."""
    if not SCRIPT_STUDIO_ENABLED:
        return jsonify({"error": "Script Studio is disabled"}), 503

    # SuperAdmin restriction
    if not _is_superadmin():
        return render_template_string('''
            <!DOCTYPE html>
            <html><head><title>Access Denied</title>
            <style>body{font-family:system-ui;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;background:#1e1e1e;color:#fff;}
            .box{text-align:center;padding:40px;border:1px solid #444;border-radius:8px;background:#252526;}
            h1{color:#f14c4c;margin-bottom:10px;}a{color:#569cd6;}</style></head>
            <body><div class="box"><h1>🔒 Access Denied</h1>
            <p>Developer Script Studio is restricted to <strong>SuperAdmin</strong> users only.</p>
            <p style="margin-top:20px;"><a href="/dashboard">← Return to Dashboard</a></p></div></body></html>
        '''), 403

    permissions = get_user_permissions()

    return render_template_string(
        SCRIPT_STUDIO_TEMPLATE,
        current_user=current_user if FLASK_LOGIN_AVAILABLE else None,
        permissions=permissions
    )


@script_studio_bp.route('/api/script-studio/files')
@login_required
def get_file_tree():
    """Get the file tree for the script browser (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    try:
        def build_tree(directory, base_path=""):
            items = []
            if not directory.exists():
                return items

            for item in sorted(directory.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                rel_path = f"{base_path}/{item.name}" if base_path else item.name

                if item.is_dir():
                    # Skip hidden and special directories
                    if item.name.startswith('.') or item.name == '__pycache__':
                        continue
                    children = build_tree(item, rel_path)
                    if children:  # Only include non-empty directories
                        items.append({
                            "name": item.name,
                            "path": str(item),
                            "is_directory": True,
                            "children": children
                        })
                elif item.suffix in ['.sh', '.ps1']:
                    items.append({
                        "name": item.name,
                        "path": str(item),
                        "is_directory": False
                    })

            return items

        tree = []

        CUSTOM_SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)

        # Custom scripts (always show)
        if CUSTOM_SCRIPTS_DIR.exists():
            custom_tree = build_tree(CUSTOM_SCRIPTS_DIR)
            tree.append({
                "name": "📦 Custom Scripts",
                "path": str(CUSTOM_SCRIPTS_DIR),
                "is_directory": True,
                "children": custom_tree
            })

        # Linux audits
        linux_dir = AUDITS_DIR / 'linux'
        if linux_dir.exists():
            tree.append({
                "name": "🐧 Linux Audits",
                "path": str(linux_dir),
                "is_directory": True,
                "children": build_tree(linux_dir)
            })

        # Windows audits
        windows_dir = AUDITS_DIR / 'windows'
        if windows_dir.exists():
            tree.append({
                "name": "🪟 Windows Audits",
                "path": str(windows_dir),
                "is_directory": True,
                "children": build_tree(windows_dir)
            })

        # Hypervisor audits
        hypervisor_dir = AUDITS_DIR / 'hypervisors'
        if hypervisor_dir.exists():
            tree.append({
                "name": "☁️ Hypervisor Audits",
                "path": str(hypervisor_dir),
                "is_directory": True,
                "children": build_tree(hypervisor_dir)
            })

        # Fix scripts (customer-visible, read-only unless support mode is active)
        if FIX_SCRIPTS_DIR.exists():
            tree.append({
                "name": "🛠️ Fix Scripts",
                "path": str(FIX_SCRIPTS_DIR),
                "is_directory": True,
                "children": build_tree(FIX_SCRIPTS_DIR)
            })

        return jsonify({"tree": tree})

    except Exception as e:
        logger.error(f"Failed to get file tree: {e}")
        return jsonify({"error": str(e)}), 500


@script_studio_bp.route('/api/script-studio/file')
@login_required
def get_file():
    """Get file content for editing (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    file_path = request.args.get('path')
    if not file_path:
        return jsonify({"error": "File path required"}), 400

    try:
        path = Path(file_path).resolve()
        if not path.exists():
            return jsonify({"error": "File not found"}), 404

        # SECURITY: Path traversal protection using is_relative_to() (OWASP A01)
        # Must be under allowed directories - prevents ../../../etc/passwd attacks
        allowed_roots = [AUDITS_DIR.resolve(), FIX_SCRIPTS_DIR.resolve(), LIB_DIR.resolve()]
        is_allowed = False
        for root in allowed_roots:
            try:
                path.relative_to(root)
                is_allowed = True
                break
            except ValueError:
                continue

        if not is_allowed:
            logger.warning(f"Path traversal attempt blocked: {file_path}")
            return jsonify({"error": "Access denied"}), 403

        permissions = get_user_permissions()
        editable = is_editable_path(file_path, permissions)

        return jsonify({
            "name": path.name,
            "path": str(path),
            "content": path.read_text(encoding='utf-8', errors='replace'),
            "editable": editable,
            "is_custom": is_custom_script(file_path),
            "size": path.stat().st_size,
            "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat()
        })

    except Exception as e:
        logger.error(f"Failed to read file: {e}")
        return jsonify({"error": str(e)}), 500


@script_studio_bp.route('/api/script-studio/file', methods=['POST'])
@login_required
def save_file():
    """Save file content (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    data = request.get_json()
    file_path = data.get('path')
    content = data.get('content')

    if not file_path or content is None:
        return jsonify({"error": "Path and content required"}), 400

    try:
        path = Path(file_path).resolve()
        permissions = get_user_permissions()

        # Check permissions
        if not is_editable_path(file_path, permissions):
            return jsonify({"error": "You don't have permission to edit this file"}), 403

        if not is_customer_writable_path(path) and not permissions.get('_support_mode_active'):
            return jsonify({"error": "Core audit and fix scripts require support mode activation"}), 403

        # Create backup before saving
        if path.exists():
            backup_path = backup_file(str(path))
            if backup_path:
                logger.info(f"Created backup: {backup_path}")

        # Save file
        path.write_text(content, encoding='utf-8')

        return jsonify({
            "success": True,
            "message": "File saved successfully"
        })

    except Exception as e:
        logger.error(f"Failed to save file: {e}")
        return jsonify({"error": str(e)}), 500


@script_studio_bp.route('/api/script-studio/create', methods=['POST'])
@login_required
def create_script():
    """Create a new custom script (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    data = request.get_json()

    name = data.get('name', '').strip()
    script_type = data.get('type', 'bash')
    template = data.get('template', 'basic')
    category = data.get('category', 'general').strip()

    if not name:
        return jsonify({"error": "Script name required"}), 400

    permissions = get_user_permissions()
    if not permissions['can_create']:
        return jsonify({"error": "License upgrade required to create scripts"}), 403

    try:
        # SECURITY: Strict sanitization to prevent path traversal (OWASP A01)
        # Only allow alphanumeric, dash, underscore
        name = re.sub(r'[^a-zA-Z0-9_-]', '-', name)
        category = re.sub(r'[^a-zA-Z0-9_-]', '-', category)

        # Prevent empty names after sanitization
        if not name or name == '-':
            return jsonify({"error": "Invalid script name"}), 400
        if not category or category == '-':
            category = 'general'

        # Determine extension
        ext = '.ps1' if script_type == 'powershell' else '.sh'

        # Build path
        script_dir = CUSTOM_SCRIPTS_DIR / category
        script_dir.mkdir(parents=True, exist_ok=True)
        script_path = script_dir / f"{name}{ext}"

        if script_path.exists():
            return jsonify({"error": "Script already exists"}), 400

        # Get template content
        template_content = get_template_content(script_type, template)

        # Write file
        script_path.write_text(template_content, encoding='utf-8')

        return jsonify({
            "success": True,
            "name": script_path.name,
            "path": str(script_path)
        })

    except Exception as e:
        logger.error(f"Failed to create script: {e}")
        return jsonify({"error": str(e)}), 500


@script_studio_bp.route('/api/script-studio/validate', methods=['POST'])
@login_required
def validate_script():
    """Validate script syntax (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    permissions = get_user_permissions()
    if not permissions['can_validate']:
        return jsonify({"error": "License upgrade required to validate scripts"}), 403
    data = request.get_json()
    content = data.get('content', '')
    language = data.get('language', 'bash')

    issues = []

    try:
        if language == 'bash':
            # Try ShellCheck
            issues = run_shellcheck(content)
        elif language == 'powershell':
            # Try PSScriptAnalyzer (if available)
            issues = run_psscriptanalyzer(content)

    except Exception as e:
        logger.warning(f"Validation error: {e}")
        # Return basic syntax hints if external tools unavailable
        issues = basic_syntax_check(content, language)

    return jsonify({"issues": issues})


@script_studio_bp.route('/api/script-studio/templates')
@login_required
def get_templates():
    """Get available script templates (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403
    return jsonify({
        "templates": [
            {"id": "basic", "name": "Basic Audit", "types": ["bash", "powershell"]},
            {"id": "compliance", "name": "Compliance Check", "types": ["bash", "powershell"]},
            {"id": "security", "name": "Security Assessment", "types": ["bash", "powershell"]},
            {"id": "empty", "name": "Empty Script", "types": ["bash", "powershell"]}
        ]
    })


# =============================================================================
# Support Mode Endpoints (for authorized troubleshooting)
# =============================================================================

@script_studio_bp.route('/api/script-studio/support-mode', methods=['GET'])
@login_required
def get_support_mode_status():
    """Get current support mode status (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    expires_at = None
    expires_display = None
    if _is_support_mode_active() and FLASK_LOGIN_AVAILABLE and current_user:
        user_id = getattr(current_user, 'id', None)
        if user_id:
            session_data = _session_manager.get(user_id) or {}
            expires_at = session_data.get('expires')
            if isinstance(expires_at, str):
                try:
                    expires_dt = datetime.fromisoformat(expires_at)
                except ValueError:
                    expires_dt = None
            elif isinstance(expires_at, datetime):
                expires_dt = expires_at
            else:
                expires_dt = None

            if expires_dt is not None:
                expires_display = expires_dt.strftime('%Y-%m-%d %H:%M:%S')
                expires_at = expires_dt.isoformat()

    return jsonify({
        "available": _is_support_mode_available(),
        "active": _is_support_mode_active(),
        "message": "Support mode allows editing original audit scripts for troubleshooting",
        "expires_at": expires_at,
        "expires_at_display": expires_display,
        "duration_hours": 4
    })


@script_studio_bp.route('/api/script-studio/support-mode/activate', methods=['POST'])
@login_required
def activate_support_mode():
    """
    Activate support mode with a secret key (SuperAdmin only).

    This allows editing of original audit scripts for troubleshooting.
    Requires SCRIPT_STUDIO_SUPPORT_KEY environment variable to be set.
    Sessions expire after 4 hours.
    """
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    data = request.get_json() or {}
    support_key = data.get('key', '')

    if not support_key:
        return jsonify({"error": "Support key required"}), 400

    success, message = _activate_support_mode(support_key)

    if success:
        return jsonify({
            "success": True,
            "message": message,
            "permissions": get_user_permissions()
        })
    else:
        return jsonify({"error": message}), 403


@script_studio_bp.route('/api/script-studio/support-mode/deactivate', methods=['POST'])
@login_required
def deactivate_support_mode():
    """Deactivate support mode (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    success, message = _deactivate_support_mode()

    return jsonify({
        "success": success,
        "message": message,
        "permissions": get_user_permissions()
    })


# =============================================================================
# Developer License Endpoints (for customers to purchase and activate)
# =============================================================================

@script_studio_bp.route('/api/script-studio/license', methods=['GET'])
@login_required
def get_license_status():
    """Get current Developer Script Studio license status (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    license_info = _get_developer_license_info()
    return jsonify({
        "license": license_info,
        "permissions": get_user_permissions()
    })


@script_studio_bp.route('/api/script-studio/license/activate', methods=['POST'])
@login_required
def activate_developer_license():
    """
    Activate a Developer Script Studio license (SuperAdmin only).

    This is a separate purchasable add-on license (~$99-299/year)
    that allows creating and editing custom audit scripts.

    Required JSON body:
        {"key": "DSS-XXXX-XXXX-XXXX-XXXX"}
    """
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    data = request.get_json()
    if not data or not data.get('key'):
        return jsonify({"error": "License key required"}), 400

    success, message = _activate_developer_license(data['key'])

    if success:
        return jsonify({
            "success": True,
            "message": message,
            "permissions": get_user_permissions()
        })
    else:
        return jsonify({"success": False, "error": message}), 400


@script_studio_bp.route('/api/script-studio/license/deactivate', methods=['POST'])
@login_required
def deactivate_developer_license_route():
    """Deactivate/remove the Developer Script Studio license (SuperAdmin only)."""
    if not _is_superadmin():
        return jsonify({"error": "SuperAdmin access required"}), 403

    success, message = _deactivate_developer_license()

    return jsonify({
        "success": success,
        "message": message,
        "permissions": get_user_permissions()
    })


# =============================================================================
# Helper Functions
# =============================================================================

def get_template_content(script_type, template_name):
    """Get template content for a new script."""
    # Try to load from template files
    template_file = TEMPLATES_DIR / script_type / f"{template_name}.{'ps1' if script_type == 'powershell' else 'sh'}"

    if template_file.exists():
        return template_file.read_text(encoding='utf-8')

    # Fallback templates
    if script_type == 'powershell':
        return get_powershell_template(template_name)
    else:
        return get_bash_template(template_name)


def get_bash_template(template_name):
    """Get Bash template content."""
    header = '''#!/usr/bin/env bash
# =============================================================================
# Custom Security Audit Script
# Created: {date}
# =============================================================================

set -euo pipefail

# Source common library
SCRIPT_DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
# shellcheck source=/dev/null
. "$SCRIPT_DIR/../../lib/common.sh" 2>/dev/null || true

'''

    if template_name == 'compliance':
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Compliance Check Script

section "Compliance Audit"

# Example: Check file permissions
check_file_permissions() {
    local file="$1"
    local expected_perms="$2"

    if [ -f "$file" ]; then
        local actual_perms
        actual_perms=$(stat -c %a "$file" 2>/dev/null || stat -f %Lp "$file")
        if [ "$actual_perms" = "$expected_perms" ]; then
            register_check "File $file permissions" PASS "Correct ($actual_perms)"
        else
            register_check "File $file permissions" FAIL "Expected $expected_perms, got $actual_perms"
        fi
    else
        register_check "File $file exists" SKIP "File not found"
    fi
}

# Add your compliance checks here
check_file_permissions "/etc/passwd" "644"

print_summary
exit "$EXIT_CODE"
'''

    elif template_name == 'security':
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Security Assessment Script

section "Security Assessment"

# Example: Check for world-writable files
check_world_writable() {
    local count
    count=$(find /tmp -type f -perm -002 2>/dev/null | wc -l)

    if [ "$count" -eq 0 ]; then
        register_check "World-writable files in /tmp" PASS "None found"
    else
        register_check "World-writable files in /tmp" WARN "Found $count files"
    fi
}

# Add your security checks here
check_world_writable

print_summary
exit "$EXIT_CODE"
'''

    elif template_name == 'empty':
        return '''#!/usr/bin/env bash
# Custom audit script

set -euo pipefail

# Your code here

'''

    else:  # basic
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Basic Audit Script

section "Basic Audit"

# Example check
if [ -f /etc/os-release ]; then
    register_check "OS Release file" PASS "Found"
else
    register_check "OS Release file" FAIL "Not found"
fi

print_summary
exit "$EXIT_CODE"
'''


def get_powershell_template(template_name):
    """Get PowerShell template content."""
    header = '''#Requires -Version 5.1
<#
.SYNOPSIS
    Custom Security Audit Script

.DESCRIPTION
    Created: {date}

.NOTES
    Author: Security Audit Toolkit
#>

[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'
$script:PassCount = 0
$script:FailCount = 0
$script:WarnCount = 0

function Register-Check {{
    param(
        [string]$Name,
        [ValidateSet('PASS', 'FAIL', 'WARN', 'SKIP')]
        [string]$Status,
        [string]$Message
    )

    $icon = switch ($Status) {{
        'PASS' {{ '[PASS]' }}
        'FAIL' {{ '[FAIL]' }}
        'WARN' {{ '[WARN]' }}
        'SKIP' {{ '[SKIP]' }}
    }}

    Write-Host "$icon $Name - $Message"

    switch ($Status) {{
        'PASS' {{ $script:PassCount++ }}
        'FAIL' {{ $script:FailCount++ }}
        'WARN' {{ $script:WarnCount++ }}
    }}
}}

function Write-Section {{
    param([string]$Title)
    Write-Host "`n=== $Title ===" -ForegroundColor Cyan
}}

'''

    if template_name == 'compliance':
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Compliance Check Script

Write-Section "Compliance Audit"

# Example: Check Windows Firewall
$firewall = Get-NetFirewallProfile -Profile Domain, Public, Private
foreach ($profile in $firewall) {
    if ($profile.Enabled) {
        Register-Check "Firewall $($profile.Name)" "PASS" "Enabled"
    } else {
        Register-Check "Firewall $($profile.Name)" "FAIL" "Disabled"
    }
}

# Summary
Write-Host "`n=== Summary ===" -ForegroundColor Cyan
Write-Host "PASS: $script:PassCount | FAIL: $script:FailCount | WARN: $script:WarnCount"

if ($script:FailCount -gt 0) { exit 2 }
elseif ($script:WarnCount -gt 0) { exit 1 }
else { exit 0 }
'''

    elif template_name == 'security':
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Security Assessment Script

Write-Section "Security Assessment"

# Example: Check for admin accounts
$adminGroup = Get-LocalGroupMember -Group "Administrators" -ErrorAction SilentlyContinue
$adminCount = ($adminGroup | Measure-Object).Count

if ($adminCount -le 2) {
    Register-Check "Administrator accounts" "PASS" "$adminCount accounts found"
} else {
    Register-Check "Administrator accounts" "WARN" "$adminCount accounts (consider reducing)"
}

# Summary
Write-Host "`n=== Summary ===" -ForegroundColor Cyan
Write-Host "PASS: $script:PassCount | FAIL: $script:FailCount | WARN: $script:WarnCount"

if ($script:FailCount -gt 0) { exit 2 }
elseif ($script:WarnCount -gt 0) { exit 1 }
else { exit 0 }
'''

    elif template_name == 'empty':
        return '''#Requires -Version 5.1
# Custom audit script

$ErrorActionPreference = 'Continue'

# Your code here

'''

    else:  # basic
        return header.format(date=datetime.now().strftime('%Y-%m-%d')) + '''
# Basic Audit Script

Write-Section "Basic Audit"

# Example: Check OS version
$os = Get-CimInstance Win32_OperatingSystem
Register-Check "Operating System" "PASS" "$($os.Caption) $($os.Version)"

# Summary
Write-Host "`n=== Summary ===" -ForegroundColor Cyan
Write-Host "PASS: $script:PassCount | FAIL: $script:FailCount | WARN: $script:WarnCount"

if ($script:FailCount -gt 0) { exit 2 }
elseif ($script:WarnCount -gt 0) { exit 1 }
else { exit 0 }
'''


def run_shellcheck(content):
    """Run ShellCheck on script content."""
    issues = []
    temp_path = None
    try:
        # Write to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
            f.write(content)
            temp_path = f.name

        shellcheck_executable = shutil.which('shellcheck')
        if not shellcheck_executable:
            logger.debug("ShellCheck not available")
            return run_bash_syntax_check(content)

        # Run shellcheck
        result = subprocess.run(
            [shellcheck_executable, '-f', 'json', temp_path],
            capture_output=True,
            text=True,
            timeout=10
        )  # nosec B603 - executable resolved from PATH and input comes from local temp file

        # Parse results
        if result.stdout:
            for item in json.loads(result.stdout):
                issues.append({
                    "line": item.get('line', 0),
                    "column": item.get('column', 0),
                    "level": 'error' if item.get('level') == 'error' else 'warning',
                    "message": item.get('message', ''),
                    "code": item.get('code', '')
                })
    except Exception as e:
        logger.warning(f"ShellCheck error: {e}")
    finally:
        if temp_path and os.path.exists(temp_path):
            os.unlink(temp_path)

    return issues


def run_psscriptanalyzer(content):
    """Run PSScriptAnalyzer on script content with syntax-parser fallback."""
    powershell_executable = _find_powershell_executable()
    if not powershell_executable:
        logger.debug("PowerShell executable not available for script validation")
        return basic_syntax_check(content, 'powershell')

    temp_script_path = None
    temp_runner_path = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False, encoding='utf-8') as f:
            f.write(content)
            temp_script_path = f.name

        runner_script = r'''
param(
    [string]$ScriptPath,
    [string]$SettingsPath
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Module PSScriptAnalyzer -ListAvailable)) {
    exit 3
}

Import-Module PSScriptAnalyzer -ErrorAction Stop

$params = @{
    Path = $ScriptPath
    Severity = @('Error', 'Warning', 'Information')
    ErrorAction = 'Stop'
}

if ($SettingsPath -and (Test-Path -LiteralPath $SettingsPath)) {
    $params.Settings = $SettingsPath
}

$results = Invoke-ScriptAnalyzer @params | ForEach-Object {
    [pscustomobject]@{
        line = $_.Line
        column = $_.Column
        level = if ($_.Severity -eq 'Error') { 'error' } else { 'warning' }
        message = $_.Message
        code = $_.RuleName
    }
}

$results | ConvertTo-Json -Compress -Depth 4
'''

        with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False, encoding='utf-8') as f:
            f.write(runner_script)
            temp_runner_path = f.name

        result = subprocess.run(
            [
                powershell_executable,
                '-NoProfile',
                '-File',
                temp_runner_path,
                '-ScriptPath',
                temp_script_path,
                '-SettingsPath',
                str(PSSCRIPTANALYZER_SETTINGS_PATH),
            ],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )  # nosec B603 - executable resolved from PATH and input comes from local temp files

        if result.returncode == 0:
            return _parse_validator_issues(result.stdout)

        logger.debug("PSScriptAnalyzer unavailable or failed (rc=%s): %s", result.returncode, (result.stderr or '').strip())
        return run_powershell_syntax_check(content, powershell_executable)
    except Exception as e:
        logger.warning(f"PSScriptAnalyzer error: {e}")
        return run_powershell_syntax_check(content, powershell_executable)
    finally:
        for temp_path in (temp_script_path, temp_runner_path):
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)


def _find_powershell_executable():
    """Locate a PowerShell executable suitable for validation."""
    for candidate in ('pwsh', 'powershell', 'powershell.exe'):
        executable = shutil.which(candidate)
        if executable:
            return executable
    return None


def _parse_validator_issues(raw_output):
    """Normalize validator JSON output into the issue structure used by the UI."""
    if not raw_output:
        return []

    parsed = json.loads(raw_output)
    if isinstance(parsed, dict):
        parsed = [parsed]
    if not isinstance(parsed, list):
        return []

    issues = []
    for item in parsed:
        if not isinstance(item, dict):
            continue
        issues.append({
            'line': item.get('line', 0) or 0,
            'column': item.get('column', 0) or 0,
            'level': 'error' if item.get('level') == 'error' else 'warning',
            'message': item.get('message', ''),
            'code': item.get('code', ''),
        })
    return issues


def run_bash_syntax_check(content):
    """Run a basic bash parser check when ShellCheck is unavailable."""
    bash_executable = shutil.which('bash')
    if not bash_executable:
        return basic_syntax_check(content, 'bash')

    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False, encoding='utf-8') as f:
            f.write(content)
            temp_path = f.name

        result = subprocess.run(
            [bash_executable, '-n', temp_path],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )  # nosec B603 - executable resolved from PATH and input comes from local temp file

        if result.returncode == 0:
            return []

        return _parse_shell_syntax_errors(result.stderr)
    except Exception as e:
        logger.warning(f"Bash syntax check error: {e}")
        return basic_syntax_check(content, 'bash')
    finally:
        if temp_path and os.path.exists(temp_path):
            os.unlink(temp_path)


def _parse_shell_syntax_errors(stderr_output):
    """Convert bash -n stderr into UI issue records."""
    issues = []
    for raw_line in (stderr_output or '').splitlines():
        match = re.search(r'line\s+(\d+):\s+(.*)', raw_line)
        message = raw_line.strip()
        line_no = 0
        if match:
            line_no = int(match.group(1))
            message = match.group(2).strip()
        if message:
            issues.append({
                'line': line_no,
                'column': 0,
                'level': 'error',
                'message': message,
                'code': 'bash-parse',
            })
    return issues or basic_syntax_check('', 'bash')


def run_powershell_syntax_check(content, powershell_executable=None):
    """Run PowerShell parser checks when PSScriptAnalyzer is unavailable."""
    powershell_executable = powershell_executable or _find_powershell_executable()
    if not powershell_executable:
        return basic_syntax_check(content, 'powershell')

    temp_script_path = None
    temp_runner_path = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False, encoding='utf-8') as f:
            f.write(content)
            temp_script_path = f.name

        runner_script = r'''
param([string]$ScriptPath)

$tokens = $null
$errors = $null
[System.Management.Automation.Language.Parser]::ParseFile($ScriptPath, [ref]$tokens, [ref]$errors) | Out-Null

$results = @($errors | ForEach-Object {
    [pscustomobject]@{
        line = $_.Extent.StartLineNumber
        column = $_.Extent.StartColumnNumber
        level = 'error'
        message = $_.Message
        code = 'ParseError'
    }
})

$results | ConvertTo-Json -Compress -Depth 4
'''

        with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False, encoding='utf-8') as f:
            f.write(runner_script)
            temp_runner_path = f.name

        result = subprocess.run(
            [
                powershell_executable,
                '-NoProfile',
                '-File',
                temp_runner_path,
                '-ScriptPath',
                temp_script_path,
            ],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )  # nosec B603 - executable resolved from PATH and input comes from local temp files

        issues = _parse_validator_issues(result.stdout)
        if issues:
            return issues
        return basic_syntax_check(content, 'powershell')
    except Exception as e:
        logger.warning(f"PowerShell syntax check error: {e}")
        return basic_syntax_check(content, 'powershell')
    finally:
        for temp_path in (temp_script_path, temp_runner_path):
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)


def basic_syntax_check(content, language):
    """Basic syntax checking when external tools unavailable."""
    issues = []
    lines = content.split('\n')

    for i, line in enumerate(lines, 1):
        # Check for common issues
        if language == 'bash':
            if 'rm -rf /' in line.lower():
                issues.append({
                    "line": i,
                    "column": 0,
                    "level": "error",
                    "message": "Dangerous command detected: rm -rf /",
                    "code": "dangerous-command"
                })
            if line.strip().startswith('eval ') and '$' in line:
                issues.append({
                    "line": i,
                    "column": 0,
                    "level": "warning",
                    "message": "eval with variables can be dangerous",
                    "code": "dangerous-eval"
                })
        elif language == 'powershell':
            normalized = line.strip().lower()
            if 'invoke-expression' in normalized or normalized.startswith('iex '):
                issues.append({
                    "line": i,
                    "column": 0,
                    "level": "warning",
                    "message": "Invoke-Expression can execute untrusted input",
                    "code": "dangerous-invoke-expression"
                })
            if 'remove-item' in normalized and (' -recurse' in normalized or ' -force' in normalized):
                issues.append({
                    "line": i,
                    "column": 0,
                    "level": "warning",
                    "message": "Remove-Item with -Recurse/-Force can be destructive",
                    "code": "destructive-remove-item"
                })

    return issues
