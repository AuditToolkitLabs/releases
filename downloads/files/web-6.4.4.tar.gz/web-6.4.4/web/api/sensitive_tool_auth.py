"""Shared secondary-auth helpers for sensitive admin tool surfaces."""

import hashlib
import os
import secrets
import threading
from datetime import datetime, timedelta
from functools import wraps

from flask import jsonify, request, session
from flask_login import current_user

from config import get_db_session, logger
from models.user import User


_TOKEN_VALIDITY_SECONDS = int(os.environ.get('SENSITIVE_TOOL_AUTH_TOKEN_TTL_SEC', '1800'))
_AUTH_RATE_LIMIT_PER_MINUTE = int(os.environ.get('SENSITIVE_TOOL_AUTH_RATE_LIMIT_PER_MIN', '5'))

_ACCESS_TOKENS = {}
_ACCESS_TOKENS_LOCK = threading.Lock()
_AUTH_ATTEMPTS = {}
_AUTH_ATTEMPTS_LOCK = threading.Lock()


def _token_store_key(scope, user_id):
    return f'{scope}:{user_id}'


def _session_token_key(scope):
    return f'{scope}_access_token'


def _session_expiry_key(scope):
    return f'{scope}_token_expires'


def _hash_token(token):
    return hashlib.sha256(token.encode('utf-8')).hexdigest()


def _check_rate_limit(scope, user_id):
    now = datetime.utcnow()
    window_start = now - timedelta(minutes=1)
    key = _token_store_key(scope, user_id)

    with _AUTH_ATTEMPTS_LOCK:
        attempts = _AUTH_ATTEMPTS.get(key, [])
        attempts = [ts for ts in attempts if ts > window_start]
        if len(attempts) >= _AUTH_RATE_LIMIT_PER_MINUTE:
            _AUTH_ATTEMPTS[key] = attempts
            return False
        attempts.append(now)
        _AUTH_ATTEMPTS[key] = attempts

    return True


def authenticate_sensitive_tool(scope, password):
    """Verify the current user's password and issue a short-lived access token."""
    if not current_user.is_authenticated:
        return False, {'error': 'Authentication required'}, 401

    if not _check_rate_limit(scope, current_user.id):
        return False, {
            'error': 'Too many authentication attempts. Please wait a minute.',
            'code': 'RATE_LIMITED',
        }, 429

    if not password:
        return False, {'error': 'Password is required'}, 400

    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == current_user.id).first()
        if not user or not user.check_password(password):
            logger.warning('Sensitive tool auth failed for %s scope=%s', current_user.username, scope)
            return False, {'error': 'Invalid password'}, 401

        token = secrets.token_urlsafe(32)
        expires_at = datetime.utcnow() + timedelta(seconds=_TOKEN_VALIDITY_SECONDS)
        key = _token_store_key(scope, current_user.id)

        with _ACCESS_TOKENS_LOCK:
            _ACCESS_TOKENS[key] = {
                'token_hash': _hash_token(token),
                'expires_at': expires_at,
                'created_at': datetime.utcnow(),
                'ip_address': request.remote_addr,
            }

        session[_session_token_key(scope)] = token
        session[_session_expiry_key(scope)] = expires_at.isoformat()

        return True, {
            'success': True,
            'token': token,
            'expires_at': expires_at.isoformat(),
            'expires_in': _TOKEN_VALIDITY_SECONDS,
        }, 200
    finally:
        db.close()


def get_sensitive_tool_auth_status(scope):
    """Return the current user's secondary-auth status for a scope."""
    if not current_user.is_authenticated:
        return {'authenticated': False, 'message': 'Authentication required'}

    key = _token_store_key(scope, current_user.id)

    with _ACCESS_TOKENS_LOCK:
        stored = _ACCESS_TOKENS.get(key)
        if not stored:
            return {'authenticated': False, 'message': 'No access token'}

        if datetime.utcnow() > stored['expires_at']:
            _ACCESS_TOKENS.pop(key, None)
            session.pop(_session_token_key(scope), None)
            session.pop(_session_expiry_key(scope), None)
            return {'authenticated': False, 'message': 'Access token expired'}

        remaining = int((stored['expires_at'] - datetime.utcnow()).total_seconds())
        return {
            'authenticated': True,
            'expires_at': stored['expires_at'].isoformat(),
            'remaining_seconds': max(0, remaining),
        }


def revoke_sensitive_tool_auth(scope):
    """Revoke the current user's secondary-auth token for a scope."""
    if current_user.is_authenticated:
        key = _token_store_key(scope, current_user.id)
        with _ACCESS_TOKENS_LOCK:
            _ACCESS_TOKENS.pop(key, None)

    session.pop(_session_token_key(scope), None)
    session.pop(_session_expiry_key(scope), None)


def require_sensitive_tool_token(scope, denied_code, denied_message):
    """Decorator enforcing a valid secondary-auth token for the current scope."""
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401

            token = request.headers.get('X-Sensitive-Tool-Token') or session.get(_session_token_key(scope))
            if not token:
                return jsonify({
                    'error': denied_message,
                    'code': denied_code,
                }), 403

            key = _token_store_key(scope, current_user.id)
            with _ACCESS_TOKENS_LOCK:
                stored = _ACCESS_TOKENS.get(key)
                if not stored:
                    return jsonify({
                        'error': denied_message,
                        'code': denied_code,
                    }), 403

                if stored['token_hash'] != _hash_token(token):
                    return jsonify({
                        'error': denied_message,
                        'code': denied_code,
                    }), 403

                if datetime.utcnow() > stored['expires_at']:
                    _ACCESS_TOKENS.pop(key, None)
                    session.pop(_session_token_key(scope), None)
                    session.pop(_session_expiry_key(scope), None)
                    return jsonify({
                        'error': denied_message,
                        'code': denied_code,
                    }), 403

            return f(*args, **kwargs)
        return wrapped
    return decorator