#!/usr/bin/env python3
"""
Server Group API Routes

Provides comprehensive server group management:
- Group CRUD operations
- Group membership management
- Bulk operations on groups
- Group policies
- Dynamic group filtering

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from flask import Blueprint, jsonify, request
from sqlalchemy import and_, or_, func
from sqlalchemy.orm import joinedload
from datetime import datetime
import json
from auth_core import require_api_key, conditional_limit, require_auth_and_permission
from config import SessionLocal, logger
from models.server_group import (
    ServerGroup, GroupPolicy,
    server_group_membership, group_policy_assignment,
    get_servers_in_group, get_groups_for_server
)
from models.database import Server, Audit

# Create blueprint
server_group_bp = Blueprint('server_groups', __name__)


# ============================================================================
# Server Group CRUD
# ============================================================================

@server_group_bp.route('/api/server-groups', methods=['GET'])
@require_auth_and_permission('view_servers')
@conditional_limit("50 per minute")
def list_server_groups():
    """
    List all server groups

    Query Parameters:
        include_servers (bool): Include server list in response (default: false)
        parent_id (int): Filter by parent group
        flat (bool): Return flat list without hierarchy (default: true)

    Returns:
        JSON: List of server groups
    """
    db = SessionLocal()

    try:
        query = db.query(ServerGroup)

        # Filter by parent
        parent_id = request.args.get('parent_id', type=int)
        if parent_id is not None:
            query = query.filter(ServerGroup.parent_id == parent_id)

        groups = query.order_by(ServerGroup.name).all()

        include_servers = request.args.get('include_servers', 'false').lower() == 'true'
        flat = request.args.get('flat', 'true').lower() == 'true'

        if flat:
            result = [g.to_dict(include_servers=include_servers) for g in groups]
        else:
            # Build hierarchy
            result = _build_group_hierarchy(groups, include_servers)

        return jsonify({
            'success': True,
            'groups': result,
            'total': len(groups)
        })

    except Exception as e:
        logger.error(f"Error listing server groups: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


def _build_group_hierarchy(groups, include_servers=False):
    """Build hierarchical group structure"""
    # Create lookup map
    group_map = {g.id: g.to_dict(include_servers=include_servers) for g in groups}

    # Add children arrays
    for g in group_map.values():
        g['children'] = []

    # Build hierarchy
    roots = []
    for g in group_map.values():
        if g['parent_id'] and g['parent_id'] in group_map:
            group_map[g['parent_id']]['children'].append(g)
        else:
            roots.append(g)

    return roots


@server_group_bp.route('/api/server-groups/<int:group_id>', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def get_server_group(group_id):
    """
    Get a specific server group

    Path Parameters:
        group_id (int): Group ID

    Query Parameters:
        include_servers (bool): Include full server list (default: true)

    Returns:
        JSON: Server group details
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()

        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        include_servers = request.args.get('include_servers', 'true').lower() == 'true'

        data = group.to_dict(include_servers=include_servers)

        # Add child groups
        children = db.query(ServerGroup).filter(ServerGroup.parent_id == group_id).all()
        data['children'] = [c.to_dict(include_servers=False) for c in children]

        # Add applied policies
        policies = db.query(GroupPolicy).join(
            group_policy_assignment,
            GroupPolicy.id == group_policy_assignment.c.policy_id
        ).filter(
            group_policy_assignment.c.group_id == group_id
        ).all()
        data['policies'] = [p.to_dict() for p in policies]

        return jsonify({
            'success': True,
            'group': data
        })

    except Exception as e:
        logger.error(f"Error getting server group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def create_server_group():
    """
    Create a new server group

    Request Body:
        name (str): Group name (required)
        description (str): Description (optional)
        color (str): Hex color code (optional)
        icon (str): Icon name (optional)
        parent_id (int): Parent group ID (optional)
        is_dynamic (bool): Dynamic group (optional)
        dynamic_filter (object): Filter rules for dynamic groups
        server_ids (list): Initial server IDs (optional)
        policy (object): Default policy settings (optional)

    Returns:
        JSON: Created server group
    """
    db = SessionLocal()

    try:
        data = request.json

        # Validate required fields
        if 'name' not in data:
            return jsonify({'success': False, 'error': 'name is required'}), 400

        # Check for duplicate name
        existing = db.query(ServerGroup).filter(ServerGroup.name == data['name']).first()
        if existing:
            return jsonify({
                'success': False,
                'error': f"Group name '{data['name']}' already exists"
            }), 400

        # Validate parent if specified
        if data.get('parent_id'):
            parent = db.query(ServerGroup).filter(ServerGroup.id == data['parent_id']).first()
            if not parent:
                return jsonify({'success': False, 'error': 'Parent group not found'}), 404

        # Validate dynamic filter
        dynamic_filter = None
        if data.get('is_dynamic') and data.get('dynamic_filter'):
            try:
                if isinstance(data['dynamic_filter'], dict):
                    dynamic_filter = json.dumps(data['dynamic_filter'])
                else:
                    dynamic_filter = data['dynamic_filter']
            except Exception as e:
                return jsonify({
                    'success': False,
                    'error': f'Invalid dynamic_filter: {e}'
                }), 400

        # Create group
        group = ServerGroup(
            name=data['name'],
            description=data.get('description'),
            color=data.get('color', '#3498db'),
            icon=data.get('icon', 'server'),
            parent_id=data.get('parent_id'),
            is_dynamic=data.get('is_dynamic', False),
            dynamic_filter=dynamic_filter,
            default_audit_schedule=data.get('policy', {}).get('default_audit_schedule'),
            notification_emails=data.get('policy', {}).get('notification_emails'),
            created_by=data.get('created_by')
        )

        db.add(group)
        db.flush()  # Get ID

        # Add initial servers
        server_ids = data.get('server_ids', [])
        if server_ids and not group.is_dynamic:
            servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
            for server in servers:
                group.servers.append(server)

        db.commit()
        db.refresh(group)

        logger.info(f"Created server group: {group.name} (ID: {group.id})")

        return jsonify({
            'success': True,
            'group': group.to_dict(include_servers=True),
            'message': 'Server group created successfully'
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating server group: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>', methods=['PUT'])
@require_api_key
@conditional_limit("20 per minute")
def update_server_group(group_id):
    """
    Update a server group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        Any fields from the server group model

    Returns:
        JSON: Updated server group
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        data = request.json

        # Updatable fields
        updatable_fields = [
            'name', 'description', 'color', 'icon', 'parent_id',
            'is_dynamic', 'default_audit_schedule', 'notification_emails'
        ]

        for field in updatable_fields:
            if field in data:
                if field == 'parent_id':
                    # Prevent circular references
                    if data['parent_id'] == group_id:
                        return jsonify({
                            'success': False,
                            'error': 'Group cannot be its own parent'
                        }), 400
                setattr(group, field, data[field])

        # Handle dynamic filter
        if 'dynamic_filter' in data:
            if isinstance(data['dynamic_filter'], dict):
                group.dynamic_filter = json.dumps(data['dynamic_filter'])
            else:
                group.dynamic_filter = data['dynamic_filter']

        # Handle policy updates
        if 'policy' in data:
            policy = data['policy']
            if 'default_audit_schedule' in policy:
                group.default_audit_schedule = policy['default_audit_schedule']
            if 'notification_emails' in policy:
                group.notification_emails = policy['notification_emails']
            if 'maintenance_window_id' in policy:
                group.maintenance_window_id = policy['maintenance_window_id']

        group.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(group)

        logger.info(f"Updated server group: {group.name} (ID: {group.id})")

        return jsonify({
            'success': True,
            'group': group.to_dict(include_servers=True),
            'message': 'Server group updated successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating server group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>', methods=['DELETE'])
@require_api_key
@conditional_limit("20 per minute")
def delete_server_group(group_id):
    """
    Delete a server group

    Path Parameters:
        group_id (int): Group ID

    Query Parameters:
        move_children_to (int): Move child groups to this parent (optional)

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        group_name = group.name

        # Handle child groups
        children = db.query(ServerGroup).filter(ServerGroup.parent_id == group_id).all()
        if children:
            move_to = request.args.get('move_children_to', type=int)
            if move_to:
                for child in children:
                    child.parent_id = move_to
            else:
                for child in children:
                    child.parent_id = None

        db.delete(group)
        db.commit()

        logger.info(f"Deleted server group: {group_name} (ID: {group_id})")

        return jsonify({
            'success': True,
            'message': f'Server group "{group_name}" deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting server group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Group Membership Management
# ============================================================================

@server_group_bp.route('/api/server-groups/<int:group_id>/servers', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def get_group_servers(group_id):
    """
    Get all servers in a group

    Path Parameters:
        group_id (int): Group ID

    Returns:
        JSON: List of servers in the group
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        servers = get_servers_in_group(group_id, db)

        return jsonify({
            'success': True,
            'group_id': group_id,
            'group_name': group.name,
            'is_dynamic': group.is_dynamic,
            'servers': [
                {
                    'id': s.id,
                    'name': s.name,
                    'hostname': s.hostname,
                    'port': s.port,
                    'tags': s.tags,
                    'last_audit_at': s.last_audit_at.isoformat() if s.last_audit_at else None
                }
                for s in servers
            ],
            'total': len(servers)
        })

    except Exception as e:
        logger.error(f"Error getting servers for group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>/servers', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def add_servers_to_group(group_id):
    """
    Add servers to a group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        server_ids (list): List of server IDs to add

    Returns:
        JSON: Updated group membership
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        if group.is_dynamic:
            return jsonify({
                'success': False,
                'error': 'Cannot manually add servers to a dynamic group'
            }), 400

        data = request.json
        server_ids = data.get('server_ids', [])

        if not server_ids:
            return jsonify({'success': False, 'error': 'server_ids is required'}), 400

        servers = db.query(Server).filter(Server.id.in_(server_ids)).all()
        found_ids = {s.id for s in servers}
        missing_ids = set(server_ids) - found_ids

        added = []
        already_member = []

        for server in servers:
            if server in group.servers:
                already_member.append(server.id)
            else:
                group.servers.append(server)
                added.append(server.id)

        db.commit()

        logger.info(f"Added {len(added)} servers to group {group.name}")

        return jsonify({
            'success': True,
            'added': added,
            'already_member': already_member,
            'not_found': list(missing_ids),
            'message': f'{len(added)} servers added to group'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error adding servers to group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>/servers', methods=['DELETE'])
@require_api_key
@conditional_limit("20 per minute")
def remove_servers_from_group(group_id):
    """
    Remove servers from a group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        server_ids (list): List of server IDs to remove

    Returns:
        JSON: Updated group membership
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        if group.is_dynamic:
            return jsonify({
                'success': False,
                'error': 'Cannot manually remove servers from a dynamic group'
            }), 400

        data = request.json
        server_ids = data.get('server_ids', [])

        if not server_ids:
            return jsonify({'success': False, 'error': 'server_ids is required'}), 400

        servers = db.query(Server).filter(Server.id.in_(server_ids)).all()

        removed = []
        not_member = []

        for server in servers:
            if server in group.servers:
                group.servers.remove(server)
                removed.append(server.id)
            else:
                not_member.append(server.id)

        db.commit()

        logger.info(f"Removed {len(removed)} servers from group {group.name}")

        return jsonify({
            'success': True,
            'removed': removed,
            'not_member': not_member,
            'message': f'{len(removed)} servers removed from group'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error removing servers from group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/servers/<int:server_id>/groups', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def get_server_groups(server_id):
    """
    Get all groups a server belongs to

    Path Parameters:
        server_id (int): Server ID

    Returns:
        JSON: List of groups the server belongs to
    """
    db = SessionLocal()

    try:
        server = db.query(Server).filter(Server.id == server_id).first()
        if not server:
            return jsonify({'success': False, 'error': 'Server not found'}), 404

        groups = get_groups_for_server(server_id, db)

        return jsonify({
            'success': True,
            'server_id': server_id,
            'server_name': server.name,
            'groups': [
                {
                    'id': g.id,
                    'name': g.name,
                    'description': g.description,
                    'color': g.color,
                    'is_dynamic': g.is_dynamic
                }
                for g in groups
            ],
            'total': len(groups)
        })

    except Exception as e:
        logger.error(f"Error getting groups for server {server_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Bulk Group Operations
# ============================================================================

@server_group_bp.route('/api/server-groups/<int:group_id>/audit', methods=['POST'])
@require_api_key
@conditional_limit("10 per minute")
def run_audit_on_group(group_id):
    """
    Queue audit execution for all servers in a group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        audit_id (int): Audit to run (optional - uses group default if not specified)
        audit_ids (list): Multiple audits to run (optional)
        options (object): Execution options (timeout, etc.)

    Returns:
        JSON: Queued task information
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        data = request.json or {}

        servers = get_servers_in_group(group_id, db)
        if not servers:
            return jsonify({
                'success': False,
                'error': 'No servers in group'
            }), 400

        # Get audits to run
        audit_ids = data.get('audit_ids', [])
        if data.get('audit_id'):
            audit_ids.append(data['audit_id'])

        if not audit_ids:
            return jsonify({
                'success': False,
                'error': 'audit_id or audit_ids required'
            }), 400

        audits = db.query(Audit).filter(Audit.id.in_(audit_ids)).all()
        if not audits:
            return jsonify({'success': False, 'error': 'No valid audits found'}), 404

        # Queue audits for each server
        try:
            from tasks.audit_tasks import execute_audit
        except ImportError:
            return jsonify({
                'success': False,
                'error': 'Celery not available for async execution'
            }), 500

        options = data.get('options', {})
        queued_tasks = []

        for server in servers:
            for audit in audits:
                task = execute_audit.delay(
                    server_id=server.id,
                    audit_path=audit.file_path,
                    options={
                        'timeout': options.get('timeout', 600),
                        'group_id': group_id,
                        'group_name': group.name
                    }
                )
                queued_tasks.append({
                    'task_id': task.id,
                    'server_id': server.id,
                    'server_name': server.name,
                    'audit_id': audit.id,
                    'audit_name': audit.name
                })

        logger.info(f"Queued {len(queued_tasks)} audits for group {group.name}")

        return jsonify({
            'success': True,
            'group_id': group_id,
            'group_name': group.name,
            'queued_tasks': queued_tasks,
            'summary': {
                'servers': len(servers),
                'audits': len(audits),
                'total_tasks': len(queued_tasks)
            }
        })

    except Exception as e:
        logger.error(f"Error running audit on group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>/schedule', methods=['POST'])
@require_api_key
@conditional_limit("10 per minute")
def create_schedules_for_group(group_id):
    """
    Create audit schedules for all servers in a group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        audit_id (int): Audit to schedule
        cron_schedule (str): Cron expression (uses group default if not specified)
        notification_enabled (bool): Enable notifications

    Returns:
        JSON: Created schedules
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        data = request.json

        if 'audit_id' not in data:
            return jsonify({'success': False, 'error': 'audit_id is required'}), 400

        audit = db.query(Audit).filter(Audit.id == data['audit_id']).first()
        if not audit:
            return jsonify({'success': False, 'error': 'Audit not found'}), 404

        # Use provided cron or group default
        cron_schedule = data.get('cron_schedule') or group.default_audit_schedule
        if not cron_schedule:
            return jsonify({
                'success': False,
                'error': 'cron_schedule required (group has no default)'
            }), 400

        servers = get_servers_in_group(group_id, db)
        if not servers:
            return jsonify({
                'success': False,
                'error': 'No servers in group'
            }), 400

        from models.schedule import ScheduledAudit

        created = []
        for server in servers:
            schedule = ScheduledAudit(
                name=f"{group.name} - {server.name} - {audit.name}",
                server_id=server.id,
                audit_id=audit.id,
                cron_schedule=cron_schedule,
                is_active=True,
                notification_enabled=data.get('notification_enabled', False),
                notification_emails=data.get('notification_emails') or group.notification_emails,
                last_status='pending'
            )
            schedule.calculate_next_run()
            db.add(schedule)

            created.append({
                'server_id': server.id,
                'server_name': server.name
            })

        db.commit()

        logger.info(f"Created {len(created)} schedules for group {group.name}")

        return jsonify({
            'success': True,
            'group_id': group_id,
            'group_name': group.name,
            'audit_name': audit.name,
            'cron_schedule': cron_schedule,
            'created_count': len(created),
            'schedules': created
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating schedules for group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Group Policies
# ============================================================================

@server_group_bp.route('/api/group-policies', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def list_group_policies():
    """
    List all group policies

    Returns:
        JSON: List of policies
    """
    db = SessionLocal()

    try:
        policies = db.query(GroupPolicy).order_by(GroupPolicy.priority.desc()).all()

        return jsonify({
            'success': True,
            'policies': [p.to_dict() for p in policies],
            'total': len(policies)
        })

    except Exception as e:
        logger.error(f"Error listing group policies: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/group-policies', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def create_group_policy():
    """
    Create a new group policy

    Request Body:
        name (str): Policy name (required)
        description (str): Description
        audit_ids (list): Audit IDs to run
        cron_schedule (str): Cron expression
        notify_on_failure (bool): Notify on failures
        min_pass_rate (int): Minimum pass rate threshold (0-100)
        priority (int): Policy priority (higher = more important)

    Returns:
        JSON: Created policy
    """
    db = SessionLocal()

    try:
        data = request.json

        if 'name' not in data:
            return jsonify({'success': False, 'error': 'name is required'}), 400

        # Check for duplicate name
        existing = db.query(GroupPolicy).filter(GroupPolicy.name == data['name']).first()
        if existing:
            return jsonify({
                'success': False,
                'error': f"Policy name '{data['name']}' already exists"
            }), 400

        policy = GroupPolicy(
            name=data['name'],
            description=data.get('description'),
            audit_ids=json.dumps(data['audit_ids']) if data.get('audit_ids') else None,
            cron_schedule=data.get('cron_schedule'),
            timeout_seconds=data.get('timeout_seconds', 600),
            notify_on_failure=data.get('notify_on_failure', True),
            notify_on_warning=data.get('notify_on_warning', False),
            notification_channels=json.dumps(data['notification_channels']) if data.get('notification_channels') else None,
            min_pass_rate=data.get('min_pass_rate', 80),
            max_critical_findings=data.get('max_critical_findings', 0),
            is_active=data.get('is_active', True),
            priority=data.get('priority', 50)
        )

        db.add(policy)
        db.commit()
        db.refresh(policy)

        logger.info(f"Created group policy: {policy.name} (ID: {policy.id})")

        return jsonify({
            'success': True,
            'policy': policy.to_dict(),
            'message': 'Policy created successfully'
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating group policy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/group-policies/<int:policy_id>', methods=['PUT'])
@require_api_key
@conditional_limit("20 per minute")
def update_group_policy(policy_id):
    """
    Update a group policy

    Path Parameters:
        policy_id (int): Policy ID

    Request Body:
        Any fields from the policy model

    Returns:
        JSON: Updated policy
    """
    db = SessionLocal()

    try:
        policy = db.query(GroupPolicy).filter(GroupPolicy.id == policy_id).first()
        if not policy:
            return jsonify({'success': False, 'error': 'Policy not found'}), 404

        data = request.json

        updatable_fields = [
            'name', 'description', 'cron_schedule', 'timeout_seconds',
            'notify_on_failure', 'notify_on_warning', 'min_pass_rate',
            'max_critical_findings', 'is_active', 'priority'
        ]

        for field in updatable_fields:
            if field in data:
                setattr(policy, field, data[field])

        # Handle JSON fields
        if 'audit_ids' in data:
            policy.audit_ids = json.dumps(data['audit_ids'])
        if 'notification_channels' in data:
            policy.notification_channels = json.dumps(data['notification_channels'])

        policy.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(policy)

        logger.info(f"Updated group policy: {policy.name} (ID: {policy.id})")

        return jsonify({
            'success': True,
            'policy': policy.to_dict(),
            'message': 'Policy updated successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating group policy {policy_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/group-policies/<int:policy_id>', methods=['DELETE'])
@require_api_key
@conditional_limit("20 per minute")
def delete_group_policy(policy_id):
    """
    Delete a group policy

    Path Parameters:
        policy_id (int): Policy ID

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        policy = db.query(GroupPolicy).filter(GroupPolicy.id == policy_id).first()
        if not policy:
            return jsonify({'success': False, 'error': 'Policy not found'}), 404

        policy_name = policy.name
        db.delete(policy)
        db.commit()

        logger.info(f"Deleted group policy: {policy_name} (ID: {policy_id})")

        return jsonify({
            'success': True,
            'message': f'Policy "{policy_name}" deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting group policy {policy_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>/policies', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def assign_policy_to_group(group_id):
    """
    Assign a policy to a server group

    Path Parameters:
        group_id (int): Group ID

    Request Body:
        policy_id (int): Policy ID to assign

    Returns:
        JSON: Assignment confirmation
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        data = request.json
        policy_id = data.get('policy_id')

        if not policy_id:
            return jsonify({'success': False, 'error': 'policy_id is required'}), 400

        policy = db.query(GroupPolicy).filter(GroupPolicy.id == policy_id).first()
        if not policy:
            return jsonify({'success': False, 'error': 'Policy not found'}), 404

        # Check if already assigned
        existing = db.execute(
            group_policy_assignment.select().where(
                and_(
                    group_policy_assignment.c.group_id == group_id,
                    group_policy_assignment.c.policy_id == policy_id
                )
            )
        ).first()

        if existing:
            return jsonify({
                'success': False,
                'error': 'Policy already assigned to this group'
            }), 400

        # Create assignment
        db.execute(
            group_policy_assignment.insert().values(
                group_id=group_id,
                policy_id=policy_id,
                assigned_at=datetime.utcnow()
            )
        )
        db.commit()

        logger.info(f"Assigned policy {policy.name} to group {group.name}")

        return jsonify({
            'success': True,
            'message': f'Policy "{policy.name}" assigned to group "{group.name}"'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error assigning policy to group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@server_group_bp.route('/api/server-groups/<int:group_id>/policies/<int:policy_id>', methods=['DELETE'])
@require_api_key
@conditional_limit("20 per minute")
def remove_policy_from_group(group_id, policy_id):
    """
    Remove a policy from a server group

    Path Parameters:
        group_id (int): Group ID
        policy_id (int): Policy ID to remove

    Returns:
        JSON: Removal confirmation
    """
    db = SessionLocal()

    try:
        # Verify group and policy exist
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        policy = db.query(GroupPolicy).filter(GroupPolicy.id == policy_id).first()
        if not policy:
            return jsonify({'success': False, 'error': 'Policy not found'}), 404

        # Remove assignment
        result = db.execute(
            group_policy_assignment.delete().where(
                and_(
                    group_policy_assignment.c.group_id == group_id,
                    group_policy_assignment.c.policy_id == policy_id
                )
            )
        )
        db.commit()

        if result.rowcount == 0:
            return jsonify({
                'success': False,
                'error': 'Policy was not assigned to this group'
            }), 404

        logger.info(f"Removed policy {policy.name} from group {group.name}")

        return jsonify({
            'success': True,
            'message': f'Policy "{policy.name}" removed from group "{group.name}"'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error removing policy from group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Group Statistics
# ============================================================================

@server_group_bp.route('/api/server-groups/<int:group_id>/stats', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def get_group_stats(group_id):
    """
    Get statistics for a server group

    Path Parameters:
        group_id (int): Group ID

    Query Parameters:
        days (int): Number of days for historical stats (default: 7)

    Returns:
        JSON: Group statistics
    """
    db = SessionLocal()

    try:
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if not group:
            return jsonify({'success': False, 'error': 'Server group not found'}), 404

        from datetime import timedelta
        from models.database import AuditExecution

        days = min(request.args.get('days', 7, type=int), 90)
        since = datetime.utcnow() - timedelta(days=days)

        servers = get_servers_in_group(group_id, db)
        server_ids = [s.id for s in servers]

        # Get execution stats
        executions = db.query(AuditExecution).filter(
            AuditExecution.server_id.in_(server_ids),
            AuditExecution.created_at >= since
        ).all()

        total_executions = len(executions)
        successful = sum(1 for e in executions if e.exit_code == 0)
        failed = sum(1 for e in executions if e.exit_code != 0)

        # Get last audit times
        servers_audited = sum(1 for s in servers if s.last_audit_at)
        servers_never_audited = len(servers) - servers_audited

        # Calculate compliance (simplified)
        pass_rate = round(successful / max(total_executions, 1) * 100, 2)

        return jsonify({
            'success': True,
            'group': {
                'id': group.id,
                'name': group.name
            },
            'period_days': days,
            'server_stats': {
                'total_servers': len(servers),
                'servers_audited': servers_audited,
                'servers_never_audited': servers_never_audited
            },
            'execution_stats': {
                'total_executions': total_executions,
                'successful': successful,
                'failed': failed,
                'pass_rate': pass_rate
            }
        })

    except Exception as e:
        logger.error(f"Error getting stats for group {group_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()
