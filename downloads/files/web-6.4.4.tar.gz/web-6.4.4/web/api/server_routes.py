"""
Server Routes - Server Configuration Management

Provides endpoints for:
- Listing servers (GET /api/servers)
- Adding servers (POST /api/servers, POST /api/servers/add)
- Removing servers (DELETE /api/servers/remove/<id>)
- Testing SSH/WinRM connections (POST /api/servers/test/<id>)
- Testing raw connections before saving (POST /api/servers/test-connection)
- Disconnecting SSH ControlMaster (POST /api/servers/<id>/disconnect)

Storage: Database (PostgreSQL/SQLite) via SQLAlchemy ORM
Passwords: Encrypted with Fernet before storage
"""

import socket
import subprocess  # nosec B404
import os
from urllib.parse import urlparse
from datetime import datetime
from flask import Blueprint, jsonify, request, g

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    requests = None
    REQUESTS_AVAILABLE = False

from config import logger
from auth_core import conditional_limit, require_auth_and_permission
from validators import validate_host, validate_username, validate_port
from encryption import ssh_host_key_manager
try:
    from winrm_manager import winrm_manager, WINRM_AVAILABLE
except ImportError:
    winrm_manager = None
    WINRM_AVAILABLE = False
from pagination import PaginationParams, paginate_list

server_bp = Blueprint('servers', __name__)

# Initialize managers (will be set by app.py via init_server_routes)
server_manager = None
ssh_manager = None


def _resolve_asset_discovery_endpoint() -> tuple[str, bool]:
    raw_endpoint = os.getenv('ASSET_DISCOVERY_URL', 'http://localhost:8080').strip()
    if not raw_endpoint:
        raw_endpoint = 'http://localhost:8080'

    if '://' not in raw_endpoint:
        raw_endpoint = f"https://{raw_endpoint}"

    parsed = urlparse(raw_endpoint)
    if not parsed.scheme:
        parsed = urlparse(f"https://{raw_endpoint.lstrip('/')}" )

    scheme = (parsed.scheme or 'https').lower()
    host = (parsed.hostname or '').strip().lower()

    local_hosts = {'localhost', '127.0.0.1', '::1', 'host.docker.internal'}
    try:
        local_hosts.add(socket.gethostname().strip().lower())
    except Exception as host_error:
        logger.debug(f"Unable to add hostname to local host allowlist: {host_error}")
    try:
        local_hosts.add(socket.getfqdn().strip().lower())
    except Exception as fqdn_error:
        logger.debug(f"Unable to add FQDN to local host allowlist: {fqdn_error}")

    is_local_same_host = host in local_hosts if host else False

    was_upgraded_to_https = False
    if scheme == 'http' and not is_local_same_host:
        scheme = 'https'
        was_upgraded_to_https = True

    port_part = f":{parsed.port}" if parsed.port is not None else ''
    path_part = parsed.path.rstrip('/') if parsed.path else ''
    normalized = f"{scheme}://{parsed.hostname or host}{port_part}{path_part}"
    return normalized.rstrip('/'), was_upgraded_to_https


def _get_asset_discovery_endpoint() -> str:
    endpoint, _ = _resolve_asset_discovery_endpoint()
    return endpoint


def _get_asset_discovery_api_key() -> str:
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        api_key = keystore.get_key('asset_discovery', 'primary')
        if api_key:
            return str(api_key)

        keys = keystore.list_keys('asset_discovery')
        if keys:
            key_id = keys[0].get('key_id')
            api_key = keystore.get_key('asset_discovery', key_id)
            if api_key:
                return str(api_key)
    except Exception as key_lookup_error:
        logger.debug(f"Asset discovery API key lookup via keystore failed: {key_lookup_error}")

    return os.getenv('ASSET_DISCOVERY_API_KEY', '').strip()


def _is_strict_cross_tool_delete_enabled() -> bool:
    """Whether server deletes must abort when cross-tool cleanup fails."""
    return os.getenv('STRICT_CROSS_TOOL_DELETE', 'false').strip().lower() in {'1', 'true', 'yes', 'on'}


def _build_asset_payload_from_server(server: dict) -> dict:
    host = server.get('host') or server.get('hostname') or ''
    os_type = (server.get('os_type') or 'linux').lower()

    tags_value = server.get('tags', '')
    if isinstance(tags_value, str):
        tags = [t.strip() for t in tags_value.split(',') if str(t).strip()]
    elif isinstance(tags_value, list):
        tags = [str(t).strip() for t in tags_value if str(t).strip()]
    else:
        tags = []

    return {
        'hostname': server.get('name') or host,
        'fqdn': host,
        'primary_ip': host,
        'os_type': os_type,
        'status': 'active',
        'tags': tags,
        'elevation_method': server.get('elevation_method'),
        'jea_endpoint': server.get('jea_endpoint'),
        'execution_mode': server.get('execution_mode', 'stream'),
        'connection_method': server.get('connection_method', 'ssh'),
        'custom_attributes': {
            'source': 'audit_toolkit',
            'audit_tool_server_id': server.get('id'),
            'connection_method': server.get('connection_method', 'ssh'),
            'execution_mode': server.get('execution_mode', 'stream'),
            'elevation_method': server.get('elevation_method'),
            'jea_endpoint': server.get('jea_endpoint'),
        }
    }


def _sync_server_to_asset_discovery(server: dict, *, trigger_full_discovery: bool = False, onboarding_credentials: dict = None) -> dict:
    if not REQUESTS_AVAILABLE:
        return {'success': False, 'error': 'requests module not available'}

    endpoint, was_upgraded_to_https = _resolve_asset_discovery_endpoint()
    api_key = _get_asset_discovery_api_key()
    headers = {'Content-Type': 'application/json'}
    if api_key:
        headers['X-API-Key'] = api_key

    asset_payload = _build_asset_payload_from_server(server)

    try:
        asset_response = requests.post(
            f"{endpoint}/api/v1/assets",
            json=asset_payload,
            headers=headers,
            timeout=15,
        )
    except Exception as sync_error:
        return {'success': False, 'error': f'asset sync request failed: {sync_error}'}

    if asset_response.status_code not in (200, 201):
        return {
            'success': False,
            'error': f'asset sync failed with status {asset_response.status_code}',
            'details': asset_response.text[:500],
        }

    result = {
        'success': True,
        'asset_synced': True,
        'asset_status_code': asset_response.status_code,
        'scan_queued': False,
        'warnings': [],
    }

    if was_upgraded_to_https:
        logger.warning(
            "event=asset_discovery_endpoint_transport_upgrade from=http to=https endpoint=%s",
            endpoint,
        )
        result['warnings'].append(
            'Asset Discovery endpoint upgraded from http to https for remote target'
        )

    if not trigger_full_discovery:
        return result

    connection_method = str(server.get('connection_method') or '').lower()
    os_type = str(server.get('os_type') or 'linux').lower()

    if connection_method == 'fleet-agent':
        discovery_mode = 'managed'
        discovery_method = 'managed'
    elif connection_method in ('ssh', 'winrm'):
        discovery_mode = 'authenticated'
        discovery_method = connection_method
    else:
        discovery_mode = 'authenticated' if os_type == 'windows' else 'authenticated'
        discovery_method = 'winrm' if os_type == 'windows' else 'ssh'

    host = server.get('host') or server.get('hostname')
    if not host:
        result['warnings'].append('No host available for discovery trigger')
        return result

    credentials = {}
    if isinstance(onboarding_credentials, dict):
        auth_type = onboarding_credentials.get('auth_type')
        password = onboarding_credentials.get('password')
        key_path = onboarding_credentials.get('key_path')

        credentials = {
            'username': onboarding_credentials.get('user') or onboarding_credentials.get('username') or '',
            'auth_method': 'key' if auth_type == 'public_key' else 'password',
            'port': int(onboarding_credentials.get('port') or server.get('port') or (5985 if discovery_method == 'winrm' else 22)),
            'password': password if auth_type != 'public_key' else '',
            'key_path': key_path if auth_type == 'public_key' else '',
            'domain': onboarding_credentials.get('domain', ''),
        }

    if discovery_method in ('ssh', 'winrm') and not credentials.get('username'):
        result['warnings'].append('Discovery trigger skipped: username missing for authenticated discovery')
        return result

    if discovery_method in ('ssh', 'winrm') and credentials.get('auth_method') == 'password' and not str(credentials.get('password') or '').strip():
        result['warnings'].append('Discovery trigger skipped: password missing for authenticated discovery')
        return result

    if discovery_method in ('ssh', 'winrm') and credentials.get('auth_method') == 'key' and not str(credentials.get('key_path') or '').strip():
        result['warnings'].append('Discovery trigger skipped: key_path missing for key-based discovery')
        return result

    scan_payload = {
        'job_type': 'full',
        'name': f"Onboarding full discovery: {server.get('name') or host}",
        'targets': [host],
        'os_type': os_type if os_type in ('linux', 'windows') else 'auto',
        'discovery_mode': discovery_mode,
        'discovery_method': discovery_method,
        'credentials': credentials,
        'scope': {
            'packages': True,
            'services': True,
            'updates': True,
            'ports': True,
            'users': True,
            'security': True,
        },
        'schedule': 'now',
        'sync_to_audit_tool': True,
    }

    try:
        scan_response = requests.post(
            f"{endpoint}/api/v1/scans",
            json=scan_payload,
            headers=headers,
            timeout=20,
        )
    except Exception as scan_error:
        result['warnings'].append(f'Discovery trigger failed: {scan_error}')
        return result

    if scan_response.status_code in (200, 201):
        result['scan_queued'] = True
        result['scan_status_code'] = scan_response.status_code
    else:
        result['warnings'].append(
            f"Discovery trigger rejected with status {scan_response.status_code}: {scan_response.text[:300]}"
        )

    return result


def _remove_server_from_asset_discovery(server: dict) -> dict:
    if not REQUESTS_AVAILABLE:
        return {'success': False, 'error': 'requests module not available'}

    endpoint = _get_asset_discovery_endpoint()
    api_key = _get_asset_discovery_api_key()
    headers = {'Content-Type': 'application/json'}
    if api_key:
        headers['X-API-Key'] = api_key

    host = str(server.get('host') or server.get('hostname') or '').strip()
    name = str(server.get('name') or '').strip()

    raw_server_id = server.get('id')
    try:
        server_id = int(raw_server_id) if raw_server_id is not None else None
    except (TypeError, ValueError):
        server_id = None

    if not host and not name and server_id is None:
        return {'success': False, 'error': 'Missing server host/name/id for asset lookup'}

    lookup_terms = []
    for value in (host, name):
        term = str(value or '').strip()
        if term and term not in lookup_terms:
            lookup_terms.append(term)

    if not lookup_terms and server_id is not None:
        lookup_terms = [str(server_id)]

    lookup_errors = []
    candidate_assets = {}

    for lookup in lookup_terms:
        try:
            list_response = requests.get(
                f"{endpoint}/api/v1/assets",
                params={'search': lookup, 'per_page': 200},
                headers=headers,
                timeout=15,
            )
        except Exception as list_error:
            lookup_errors.append(f"lookup '{lookup}' failed: {list_error}")
            continue

        if list_response.status_code != 200:
            lookup_errors.append(
                f"lookup '{lookup}' failed with status {list_response.status_code}: {list_response.text[:200]}"
            )
            continue

        try:
            payload = list_response.json()
        except ValueError:
            lookup_errors.append(f"lookup '{lookup}' returned non-JSON response")
            continue

        assets = payload.get('assets', []) if isinstance(payload, dict) else []
        for asset in assets:
            if not isinstance(asset, dict):
                continue
            asset_id = asset.get('id')
            try:
                asset_id = int(asset_id)
            except (TypeError, ValueError):
                continue
            candidate_assets[asset_id] = asset

    if not candidate_assets and lookup_errors:
        return {
            'success': False,
            'error': 'Asset lookup failed for all candidate identifiers',
            'details': lookup_errors[:3],
        }

    host_norm = host.lower()
    name_norm = name.lower()

    marker_matches = {}
    heuristic_matches = {}

    for asset_id, candidate in candidate_assets.items():
        detailed_asset = candidate

        try:
            detail_response = requests.get(
                f"{endpoint}/api/v1/assets/{asset_id}",
                headers=headers,
                timeout=15,
            )
            if detail_response.status_code == 200:
                detail_payload = detail_response.json()
                if isinstance(detail_payload, dict):
                    detailed_asset = detail_payload
        except Exception as detail_error:
            logger.debug("Asset detail lookup failed for %s: %s", asset_id, detail_error)

        linked_server_id = None
        custom_attributes = detailed_asset.get('custom_attributes')
        if isinstance(custom_attributes, dict):
            raw_linked_id = custom_attributes.get('audit_tool_server_id')
            try:
                linked_server_id = int(raw_linked_id) if raw_linked_id is not None else None
            except (TypeError, ValueError):
                linked_server_id = None

        if server_id is not None and linked_server_id == server_id:
            marker_matches[asset_id] = detailed_asset
            continue

        asset_identifiers = {
            str(detailed_asset.get('primary_ip') or '').strip().lower(),
            str(detailed_asset.get('fqdn') or '').strip().lower(),
            str(detailed_asset.get('hostname') or '').strip().lower(),
        }
        asset_identifiers.discard('')

        if (host_norm and host_norm in asset_identifiers) or (name_norm and name_norm in asset_identifiers):
            heuristic_matches[asset_id] = detailed_asset

    targets = marker_matches if marker_matches else heuristic_matches

    if not targets:
        response = {
            'success': True,
            'removed_assets': 0,
            'matched_assets': 0,
            'lookup_candidates': len(candidate_assets),
            'note': 'No mirrored asset records matched this server',
        }
        if lookup_errors:
            response['lookup_warnings'] = lookup_errors[:3]
        return response

    removed = 0
    failed_assets = []

    for asset_id in sorted(targets):
        try:
            delete_response = requests.delete(
                f"{endpoint}/api/v1/assets/{asset_id}",
                headers=headers,
                timeout=15,
            )
        except Exception as delete_error:
            logger.debug("Failed to remove asset discovery record %s: %s", asset_id, delete_error)
            failed_assets.append({'asset_id': asset_id, 'error': str(delete_error)})
            continue

        if delete_response.status_code in (200, 204):
            removed += 1
        else:
            failed_assets.append({
                'asset_id': asset_id,
                'status_code': delete_response.status_code,
                'details': delete_response.text[:200],
            })

    result = {
        'success': len(failed_assets) == 0,
        'removed_assets': removed,
        'matched_assets': len(targets),
        'lookup_candidates': len(candidate_assets),
    }

    if failed_assets:
        result['error'] = 'One or more mirrored asset records could not be removed'
        result['failed_assets'] = failed_assets[:10]

    if lookup_errors:
        result['lookup_warnings'] = lookup_errors[:3]

    return result


def _normalize_connection_method(method: str) -> str:
    """Normalize connection method aliases to canonical values."""
    if not method:
        return "ssh"

    method = str(method).strip().lower()

    if method in ["agent", "fleet-agent", "fleet_agent"]:
        return "fleet-agent"
    if method in ["ssh", "winrm", "hypervisor"]:
        return method

    return "ssh"


def _enforce_transport_policy(os_type: str, connection_protocol: str, connection_method: str):
    """Enforce transport policy by OS.

    Policy:
    - Non-Windows hosts use SSH only.
    - Windows hosts may use auto/ssh/winrm.
    """
    normalized_os = str(os_type or "linux").strip().lower()
    normalized_protocol = str(connection_protocol or "auto").strip().lower()
    normalized_method = _normalize_connection_method(connection_method)

    if normalized_os != "windows":
        if normalized_protocol in ("auto", "winrm"):
            normalized_protocol = "ssh"
        if normalized_method == "winrm":
            normalized_method = "ssh"

    return normalized_protocol, normalized_method


def init_server_routes(svr_manager, ssh_mgr):
    """
    Initialize server routes with manager instances

    Args:
        svr_manager: ServerManager instance
        ssh_mgr: SSHManager instance
    """
    global server_manager, ssh_manager
    server_manager = svr_manager
    ssh_manager = ssh_mgr


@server_bp.route('/api/servers/status')
@require_auth_and_permission('view_servers')
@conditional_limit("1000 per minute")  # Higher limit for status polling
def get_servers_status():
    """
    Get status of all configured servers

    Returns:
        JSON response with servers and their connection status
    """
    try:
        servers = server_manager.load_servers()
        # Sanitize and add status info
        status_list = []
        for s in servers:
            sanitized = server_manager.sanitize_server_for_api(s)
            sanitized['status'] = 'idle'
            sanitized['lastRun'] = None
            sanitized['lastResult'] = None
            status_list.append(sanitized)
        return jsonify({"success": True, "servers": status_list})
    except Exception as e:
        logger.error(f"Error getting server status: {e}")
        return jsonify({"success": False, "error": "Failed to get server status"}), 500


@server_bp.route('/api/servers', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_servers():
    try:
        servers = server_manager.load_servers()
        sanitized_servers = [server_manager.sanitize_server_for_api(s) for s in servers]

        # Apply tag filtering
        tags_filter = request.args.get('tags', '')
        if tags_filter:
            filter_tags = [t.strip().lower() for t in tags_filter.split(',')]
            filtered = []
            for s in sanitized_servers:
                server_tags = s.get('tags', '')
                if isinstance(server_tags, str):
                    server_tags = [t.strip().lower() for t in server_tags.split(',') if t.strip()]
                elif isinstance(server_tags, list):
                    server_tags = [t.lower() for t in server_tags]
                else:
                    server_tags = []
                if any(ft in server_tags for ft in filter_tags):
                    filtered.append(s)
            sanitized_servers = filtered

        # Apply status filtering
        status_filter = request.args.get('status', '')
        if status_filter:
            sanitized_servers = [s for s in sanitized_servers if s.get('status', '').lower() == status_filter.lower()]

        if 'cursor' in request.args or 'limit' in request.args:
            params = PaginationParams.from_request(max_limit=200)
            result = paginate_list(sanitized_servers, params, id_field='id', endpoint='servers.get_servers')
            return jsonify({"success": True, "servers": result['data'], "pagination": result['pagination']})
        else:
            return jsonify({"success": True, "servers": sanitized_servers})
    except Exception as e:
        logger.error(f"Error loading servers: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@server_bp.route('/api/servers/<int:server_id>', methods=['GET'])
@require_auth_and_permission('view_servers')
def get_server_by_id(server_id):
    """Get a specific server by ID"""
    try:
        servers = server_manager.load_servers()
        server = next((s for s in servers if s["id"] == server_id), None)
        if not server:
            return jsonify({"success": False, "error": "Server not found"}), 404
        sanitized = server_manager.sanitize_server_for_api(server)
        return jsonify({"success": True, "server": sanitized, **sanitized})
    except Exception as e:
        logger.error(f"Error getting server {server_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@server_bp.route('/api/servers/<int:server_id>', methods=['PUT'])
@require_auth_and_permission('edit_servers')
@conditional_limit("50 per hour")
def update_server(server_id):
    """Update a server's configuration including credentials"""
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "No data provided"}), 400

        servers = server_manager.load_servers()
        server_idx = next((i for i, s in enumerate(servers) if s["id"] == server_id), None)
        if server_idx is None:
            return jsonify({"success": False, "error": "Server not found"}), 404

        server = servers[server_idx]

        requested_connection_method = data.get('connection_method')
        if requested_connection_method is not None:
            normalized_requested_method = _normalize_connection_method(requested_connection_method)
            current_method = _normalize_connection_method(server.get('connection_method'))

            if normalized_requested_method != current_method:
                current_user = getattr(g, 'current_auth_user', None)
                user_role = getattr(current_user, 'role', None)
                if user_role not in ('Admin', 'SuperAdmin'):
                    return jsonify({
                        "success": False,
                        "error": "Only Admin or SuperAdmin can change connection_method for existing servers",
                        "required_roles": ["Admin", "SuperAdmin"]
                    }), 403

        # Update allowed fields (including credentials)
        allowed_fields = ['name', 'hostname', 'port', 'username', 'tags', 'description',
                          'os_type', 'connection_protocol', 'remote_path', 'agent_id',
                          'connection_method', 'execution_mode', 'elevation_method', 'jea_endpoint',
                          'auth_type', 'password', 'key_path', 'key_passphrase']
        for field in allowed_fields:
            if field in data:
                if field == 'tags':
                    # Handle tags as JSON string or list
                    tags = data[field]
                    if isinstance(tags, list):
                        server['tags'] = ','.join(tags) if tags else ''
                    else:
                        server['tags'] = str(tags) if tags else ''
                elif field == 'hostname':
                    server['host'] = data[field]
                elif field == 'username':
                    server['user'] = data[field]
                elif field == 'execution_mode':
                    # Validate execution_mode
                    mode = data[field]
                    if mode in ['stream', 'deployed']:
                        server['execution_mode'] = mode
                    else:
                        logger.warning(f"Invalid execution_mode '{mode}', ignoring")
                elif field == 'elevation_method':
                    # Validate elevation_method
                    method = data[field]
                    valid_methods = ['sudo', 'sudo_nopasswd', 'audit_wrapper', 'runas', 'jea', 'admin', 'none']
                    if method in valid_methods:
                        server['elevation_method'] = method
                    else:
                        logger.warning(f"Invalid elevation_method '{method}', ignoring")
                elif field == 'connection_method':
                    # Validate and normalize connection method aliases
                    server['connection_method'] = _normalize_connection_method(data[field])
                elif field == 'jea_endpoint':
                    # JEA endpoint name (Windows only)
                    endpoint = data[field]
                    if endpoint and len(endpoint) <= 100:
                        server['jea_endpoint'] = endpoint
                    elif not endpoint:
                        server['jea_endpoint'] = None
                    else:
                        logger.warning("JEA endpoint too long, truncating to 100 chars")
                        server['jea_endpoint'] = endpoint[:100]
                elif field == 'auth_type':
                    # Validate auth_type
                    auth_type = data[field]
                    if auth_type in ['password', 'public_key']:
                        server['auth_type'] = auth_type
                        # Clear the other auth method when switching
                        if auth_type == 'password':
                            server['key_path'] = None
                        elif auth_type == 'public_key':
                            server['password'] = None
                    else:
                        logger.warning(f"Invalid auth_type '{auth_type}', ignoring")
                elif field == 'password':
                    # Only update password if provided (non-empty)
                    if data[field]:
                        server['password'] = data[field]
                        logger.info(f"Password updated for server {server_id}")
                elif field == 'key_path':
                    # Update SSH key path
                    server['key_path'] = data[field]
                    logger.info(f"SSH key path updated for server {server_id}")
                elif field == 'key_passphrase':
                    # Only update passphrase if provided
                    if data[field]:
                        server['key_passphrase'] = data[field]
                else:
                    server[field] = data[field]

        normalized_protocol, normalized_method = _enforce_transport_policy(
            server.get('os_type', 'linux'),
            server.get('connection_protocol', 'auto'),
            server.get('connection_method', 'ssh')
        )
        server['connection_protocol'] = normalized_protocol
        server['connection_method'] = normalized_method

        # Update via manager (handles encryption)
        success = server_manager.update_server(server_id, server)
        if success:
            # Fetch updated server to return
            servers = server_manager.load_servers()
            updated = next((s for s in servers if s['id'] == server_id), None)
            if updated:
                integration = _sync_server_to_asset_discovery(updated, trigger_full_discovery=False)
                sanitized = server_manager.sanitize_server_for_api(updated)
                return jsonify({"success": True, "server": sanitized, "integration": integration, **sanitized})
            return jsonify({"success": True, "message": "Server updated"})
        else:
            return jsonify({"success": False, "error": "Failed to update server"}), 500
    except Exception as e:
        logger.error(f"Error updating server {server_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@server_bp.route('/api/servers/find', methods=['GET'])
@require_auth_and_permission('view_servers')
@conditional_limit("100 per minute")
def find_server_by_host():
    """
    Find server(s) by hostname (FQDN) or IP address

    Query Parameters:
        host (str): Hostname or IP address to search for (required)
        resolve_dns (bool): Perform DNS resolution for matching (default: true)
        all (bool): Return all matches instead of first match (default: false)

    Returns:
        JSON response with server(s) found

    Examples:
        GET /api/servers/find?host=192.168.1.100
        GET /api/servers/find?host=server.example.com
        GET /api/servers/find?host=10.0.0.5&resolve_dns=false
        GET /api/servers/find?host=web-server&all=true
    """
    try:
        host = request.args.get('host', '').strip()
        if not host:
            return jsonify({
                "success": False,
                "error": "host parameter is required"
            }), 400

        resolve_dns = request.args.get('resolve_dns', 'true').lower() in ('true', '1', 'yes')
        find_all = request.args.get('all', 'false').lower() in ('true', '1', 'yes')

        if find_all:
            servers = server_manager.find_servers_by_host(host, resolve_dns=resolve_dns)
            sanitized = [server_manager.sanitize_server_for_api(s) for s in servers]
            return jsonify({
                "success": True,
                "count": len(sanitized),
                "servers": sanitized,
                "query": {
                    "host": host,
                    "resolve_dns": resolve_dns,
                    "find_all": True
                }
            })
        else:
            server = server_manager.get_server_by_host(host, resolve_dns=resolve_dns)
            if server:
                sanitized = server_manager.sanitize_server_for_api(server)
                return jsonify({
                    "success": True,
                    "server": sanitized,
                    "query": {
                        "host": host,
                        "resolve_dns": resolve_dns
                    }
                })
            else:
                return jsonify({
                    "success": False,
                    "error": f"No server found matching '{host}'",
                    "query": {
                        "host": host,
                        "resolve_dns": resolve_dns
                    }
                }), 404

    except Exception as e:
        logger.error(f"Error finding server by host: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@server_bp.route('/api/servers/add', methods=['POST'])
@require_auth_and_permission('add_servers')
@conditional_limit("10 per hour")
def add_server():
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400
        if not data.get("name") or len(data["name"]) > 100:
            return jsonify({"success": False, "error": "Invalid server name"}), 400
        if not validate_host(data.get("host", "")):
            return jsonify({"success": False, "error": "Invalid hostname"}), 400
        if not validate_username(data.get("user", "")):
            return jsonify({"success": False, "error": "Invalid username"}), 400
        port = data.get("port", 22)
        if not validate_port(port):
            return jsonify({"success": False, "error": "Invalid port number"}), 400
        auth_type = data.get("auth_type")
        if auth_type not in ["password", "public_key"]:
            return jsonify({"success": False, "error": "Invalid auth_type"}), 400
        remote_path = data.get("remote_path", "/opt/security-audit-toolkit")
        if not remote_path or len(remote_path) > 500 or '..' in remote_path:
            return jsonify({"success": False, "error": "Invalid remote path"}), 400
        allowed_oses = ["linux", "windows", "hypervisor"]
        os_type = data.get("os_type", "linux")
        if os_type not in allowed_oses:
            os_type = "linux"
        # Connection protocol: ssh, winrm, or auto (default)
        # auto = WinRM for Windows, SSH for Linux; with fallback
        allowed_protocols = ["auto", "ssh", "winrm"]
        connection_protocol = data.get("connection_protocol", "auto")
        if connection_protocol not in allowed_protocols:
            connection_protocol = "auto"
        # Connection method for audit execution: ssh, winrm, or fleet-agent
        # fleet-agent = use managed API agent for execution
        connection_method = _normalize_connection_method(data.get("connection_method", "ssh"))
        connection_protocol, connection_method = _enforce_transport_policy(
            os_type, connection_protocol, connection_method
        )
        # Agent ID for agent-based connections
        agent_id = data.get("agent_id", None)
        if connection_method == "fleet-agent" and not agent_id:
            logger.warning("connection_method=fleet-agent but no agent_id provided")
        # Execution mode: stream (default) or deployed
        # stream = scripts sent via SSH/WinRM stdin (agentless, no deployment)
        # deployed = scripts pre-installed on host (requires DEB/RPM/MSI package)
        allowed_execution_modes = ["stream", "deployed"]
        execution_mode = data.get("execution_mode", "stream")
        if execution_mode not in allowed_execution_modes:
            execution_mode = "stream"
        # Elevation method: how scripts get elevated privileges on target
        # Linux: sudo (default), sudo_nopasswd, audit_wrapper, none
        # Windows: runas, jea, admin, none
        allowed_elevation_methods = ["sudo", "sudo_nopasswd", "audit_wrapper", "runas", "jea", "admin", "none"]
        elevation_method = data.get("elevation_method", "sudo")
        if elevation_method not in allowed_elevation_methods:
            elevation_method = "sudo" if os_type == "linux" else "runas"
        # JEA endpoint name (Windows only, when using JEA elevation)
        jea_endpoint = data.get("jea_endpoint")
        if jea_endpoint and len(jea_endpoint) > 100:
            jea_endpoint = jea_endpoint[:100]
        server_data = {
            "name": data["name"],
            "host": data["host"],
            "port": int(port),
            "user": data["user"],
            "auth_type": auth_type,
            "password": data.get("password", "") if auth_type == "password" else None,
            "key_path": data.get("key_path", "") if auth_type == "public_key" else None,
            "remote_path": remote_path,
            "os_type": os_type,
            "connection_protocol": connection_protocol,
            "connection_method": connection_method,
            "agent_id": agent_id,
            "execution_mode": execution_mode,
            "elevation_method": elevation_method,
            "jea_endpoint": jea_endpoint,
            "description": data.get("description", ""),
            "tags": data.get("tags", "")
        }
        if os_type == "hypervisor":
            server_data["hypervisor_type"] = data.get("hypervisor_type", "")
            server_data["hypervisor_endpoint"] = data.get("hypervisor_endpoint", "")
        try:
            new_server = server_manager.add_server(server_data)
            integration = _sync_server_to_asset_discovery(
                new_server,
                trigger_full_discovery=True,
                onboarding_credentials=server_data,
            )

            if not integration.get('success'):
                logger.warning(
                    "Server added locally but Asset Discovery integration failed: %s",
                    integration,
                )
                integration = {
                    **integration,
                    'warning': 'Server saved locally; Asset Discovery sync failed',
                }

            sanitized_server = server_manager.sanitize_server_for_api(new_server)
            return jsonify({
                "success": True,
                "message": "Server added successfully",
                "server": sanitized_server,
                "integration": integration,
            })
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error adding server: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@server_bp.route('/api/servers', methods=['POST'])
@require_auth_and_permission('add_servers')
@conditional_limit("10 per hour")
def add_server_alt():
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400
        name = data.get("name")
        hostname = data.get("hostname")
        username = data.get("username")
        if not name or not hostname or not username:
            return jsonify({"success": False, "error": "Name, hostname, and username are required"}), 400
        port = data.get("port", 22)
        auth_method = data.get("auth_method", "password")

        allowed_oses = ["linux", "windows", "hypervisor"]
        os_type = data.get("os_type", "linux")
        if os_type not in allowed_oses:
            os_type = "linux"

        connection_method = _normalize_connection_method(data.get("connection_method", "ssh"))
        connection_protocol, connection_method = _enforce_transport_policy(
            os_type, data.get("connection_protocol", "auto"), connection_method
        )

        allowed_execution_modes = ["stream", "deployed"]
        execution_mode = data.get("execution_mode", "stream")
        if execution_mode not in allowed_execution_modes:
            execution_mode = "stream"

        allowed_elevation_methods = ["sudo", "sudo_nopasswd", "audit_wrapper", "runas", "jea", "admin", "none"]
        default_elevation = "sudo" if os_type == "linux" else "runas"
        elevation_method = data.get("elevation_method", default_elevation)
        if elevation_method not in allowed_elevation_methods:
            elevation_method = default_elevation

        server_data = {
            "name": name,
            "host": hostname,
            "port": int(port),
            "user": username,
            "auth_type": "public_key" if auth_method in ["key", "certificate"] else "password",
            "password": data.get("password") if auth_method == "password" else None,
            "key_path": data.get("key_path") if auth_method in ["key", "certificate"] else None,
            "remote_path": data.get("remote_path", "/opt/security-audit-toolkit"),
            "os_type": os_type,
            "connection_protocol": connection_protocol,
            "connection_method": connection_method,
            "agent_id": data.get("agent_id"),
            "execution_mode": execution_mode,
            "elevation_method": elevation_method,
            "jea_endpoint": data.get("jea_endpoint"),
            "description": data.get("description", ""),
            "tags": ""
        }
        distro = data.get("distro", "")
        version = data.get("version", "")
        if distro or version:
            detail = f"{distro} {version}".strip()
            if server_data["description"]:
                server_data["description"] += f" ({detail})"
            else:
                server_data["description"] = detail
        try:
            new_server = server_manager.add_server(server_data)
            integration = _sync_server_to_asset_discovery(
                new_server,
                trigger_full_discovery=True,
                onboarding_credentials=server_data,
            )

            if not integration.get('success'):
                logger.warning(
                    "Server added locally but Asset Discovery integration failed: %s",
                    integration,
                )
                integration = {
                    **integration,
                    'warning': 'Server saved locally; Asset Discovery sync failed',
                }

            sanitized_server = server_manager.sanitize_server_for_api(new_server)
            return jsonify({
                "success": True,
                "message": "Server added successfully",
                "server": sanitized_server,
                "integration": integration,
            })
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error adding server: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ---------------------------------------------------------------------------
# R1-002: Bulk server upsert (Business + Advanced Operations Pack)
# ---------------------------------------------------------------------------

def _check_bulk_ingest_feature():
    """Return a 403 response if the EXTERNAL_SOURCE_INGEST feature is unavailable, else None."""
    try:
        from services_pkg.services.feature_licensing import Feature, get_feature_service
        from flask_login import current_user
        user_id = str(current_user.id) if current_user and getattr(current_user, 'is_authenticated', False) else None
        status = get_feature_service().is_feature_available(Feature.EXTERNAL_SOURCE_INGEST, user_id)
        if not status.get('available'):
            return jsonify({
                'success': False,
                'error': 'Feature not available',
                'feature': 'external_source_ingest',
                'reason': status.get('reason', 'Business tier plus Advanced Operations Pack add-on required'),
                'code': 'FEATURE_UNAVAILABLE',
            }), 403
    except Exception:
        pass
    return None


@server_bp.route('/api/servers/bulk', methods=['POST'])
@require_auth_and_permission('add_servers')
@conditional_limit("30 per hour")
def bulk_upsert_servers():
    """
    R1-002 — Bulk server upsert.

    Accepts up to 500 server records and creates or updates each one atomically.
    Records are matched by (host, name); existing records are updated, new ones created.
    Returns a partial-success response listing per-item outcomes.

    Body: { "servers": [...], "idempotency_key": "<optional uuid>" }
    Each server record supports the same fields as POST /api/servers/add.

    Gate: Business tier + Advanced Operations Pack add-on (EXTERNAL_SOURCE_INGEST feature).
    Contract header: X-Ingest-Contract-Version: 1 (required).
    """
    denied = _check_bulk_ingest_feature()
    if denied:
        return denied

    # R1-004 contract version enforcement
    contract_version = request.headers.get('X-Ingest-Contract-Version', '').strip()
    if contract_version != '1':
        return jsonify({
            'success': False,
            'error': 'Missing or unsupported contract version',
            'code': 'CONTRACT_VERSION_REQUIRED',
            'expected': '1',
            'received': contract_version or None,
        }), 400

    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({'success': False, 'error': 'Invalid JSON body'}), 400

    items = body.get('servers', [])
    if not isinstance(items, list):
        return jsonify({'success': False, 'error': '"servers" must be a list'}), 400

    MAX_BATCH = 500
    if len(items) > MAX_BATCH:
        return jsonify({
            'success': False,
            'error': f'Batch too large: maximum {MAX_BATCH} records per request, received {len(items)}',
        }), 400

    if not items:
        return jsonify({'success': True, 'created': 0, 'updated': 0, 'failed': 0, 'results': []}), 200

    idempotency_key = str(body.get('idempotency_key', '')).strip() or None

    created_count = 0
    updated_count = 0
    failed_count = 0
    results = []

    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            results.append({'index': idx, 'status': 'failed', 'error': 'Item must be a JSON object'})
            failed_count += 1
            continue

        host = str(item.get('host', '')).strip()
        name = str(item.get('name', '')).strip()
        user = str(item.get('user', item.get('username', ''))).strip()

        if not host or not name or not user:
            results.append({
                'index': idx, 'status': 'failed',
                'error': '"host", "name", and "user"/"username" are required',
                'item': {'host': host, 'name': name},
            })
            failed_count += 1
            continue

        if not validate_host(host):
            results.append({'index': idx, 'status': 'failed', 'error': 'Invalid host', 'item': {'host': host, 'name': name}})
            failed_count += 1
            continue

        if not validate_username(user):
            results.append({'index': idx, 'status': 'failed', 'error': 'Invalid username', 'item': {'host': host, 'name': name}})
            failed_count += 1
            continue

        port = item.get('port', 22)
        if not validate_port(port):
            results.append({'index': idx, 'status': 'failed', 'error': 'Invalid port', 'item': {'host': host, 'name': name}})
            failed_count += 1
            continue

        allowed_oses = {'linux', 'windows', 'hypervisor'}
        os_type = str(item.get('os_type', 'linux')).lower()
        if os_type not in allowed_oses:
            os_type = 'linux'

        try:
            # Upsert: check for existing server by host
            existing = server_manager.get_server_by_host(host, resolve_dns=False)

            server_data = {
                'name': name,
                'host': host,
                'user': user,
                'port': port,
                'os_type': os_type,
                'auth_type': str(item.get('auth_type', 'password')),
                'remote_path': str(item.get('remote_path', '/opt/security-audit-toolkit')),
                'notes': str(item.get('notes', '')),
            }

            # Strip unknown auth credentials from bulk ingest to prevent inadvertent exposure
            # Passwords must be set individually via the standard single-server endpoint.
            server_data = {k: v for k, v in server_data.items() if v is not None}

            if existing:
                server_id = existing.get('id') or existing.id
                update_ok = server_manager.update_server(server_id, server_data)
                if update_ok:
                    updated_count += 1
                    results.append({'index': idx, 'status': 'updated', 'server_id': server_id, 'host': host, 'name': name})
                else:
                    failed_count += 1
                    results.append({'index': idx, 'status': 'failed', 'error': 'Update failed', 'host': host, 'name': name})
            else:
                server_data['auth_type'] = server_data.get('auth_type', 'password')
                new_server = server_manager.add_server(server_data)
                server_id = new_server.get('id') if isinstance(new_server, dict) else getattr(new_server, 'id', None)
                created_count += 1
                results.append({'index': idx, 'status': 'created', 'server_id': server_id, 'host': host, 'name': name})

        except ValueError as ve:
            failed_count += 1
            results.append({'index': idx, 'status': 'failed', 'error': str(ve), 'host': host, 'name': name})
        except Exception as exc:
            logger.error(f"Bulk upsert error at index {idx} (host={host}): {exc}")
            failed_count += 1
            results.append({'index': idx, 'status': 'failed', 'error': 'Internal error', 'host': host, 'name': name})

    try:
        from logging_utils import log_audit
        from flask_login import current_user as _cu
        log_audit(
            action='bulk_server_upsert',
            user=getattr(_cu, 'username', 'unknown') if _cu and getattr(_cu, 'is_authenticated', False) else 'unknown',
            details={
                'created': created_count,
                'updated': updated_count,
                'failed': failed_count,
                'total': len(items),
                'idempotency_key': idempotency_key,
            },
        )
    except Exception:
        pass

    http_status = 207 if failed_count > 0 and (created_count + updated_count) > 0 else (
        400 if failed_count == len(items) else 200
    )

    return jsonify({
        'success': failed_count < len(items),
        'created': created_count,
        'updated': updated_count,
        'failed': failed_count,
        'total': len(items),
        'idempotency_key': idempotency_key,
        'results': results,
    }), http_status


@server_bp.route('/api/servers/remove/<int:server_id>', methods=['DELETE'])
@require_auth_and_permission('delete_servers')
@conditional_limit("20 per hour")
def remove_server(server_id):
    try:
        existing_server = server_manager.get_server_by_id(server_id)
        if not existing_server:
            return jsonify({"success": False, "error": "Server not found"}), 404

        strict_cross_tool_delete = _is_strict_cross_tool_delete_enabled()

        if strict_cross_tool_delete:
            integration = _remove_server_from_asset_discovery(existing_server)
            if not integration.get('success'):
                logger.warning(
                    "Blocked local server deletion due to cross-tool cleanup failure (server_id=%s): %s",
                    server_id,
                    integration,
                )
                return jsonify({
                    "success": False,
                    "error": "Cross-tool cleanup failed; deletion aborted in strict mode",
                    "integration": integration,
                    "strict_mode": True,
                }), 409

            success = server_manager.remove_server(server_id)
            if success:
                return jsonify({
                    "success": True,
                    "message": "Server removed successfully",
                    "integration": integration,
                    "strict_mode": True,
                })

            logger.error(
                "Cross-tool cleanup succeeded but local delete failed (server_id=%s)",
                server_id,
            )
            return jsonify({
                "success": False,
                "error": "Local deletion failed after successful cross-tool cleanup",
                "integration": integration,
                "strict_mode": True,
            }), 500

        success = server_manager.remove_server(server_id)
        if success:
            integration = _remove_server_from_asset_discovery(existing_server)
            return jsonify({
                "success": True,
                "message": "Server removed successfully",
                "integration": integration,
                "strict_mode": False,
            })

        return jsonify({"success": False, "error": "Server not found"}), 404
    except Exception as e:
        logger.error(f"Error removing server {server_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@server_bp.route('/api/servers/<int:server_id>/disconnect', methods=['POST'])
@require_auth_and_permission('edit_servers')
def disconnect_server(server_id):
    try:
        servers = server_manager.load_servers()
        server = next((s for s in servers if s["id"] == server_id), None)
        if not server:
            return jsonify({"success": False, "error": "Server not found"}), 404
        ssh_manager.close_control_master(server)
        return jsonify({"success": True, "message": f"Disconnected from {server['name']}"})
    except Exception as e:
        logger.error(f"Error disconnecting from server {server_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@server_bp.route('/api/servers/test/<int:server_id>', methods=['POST'])
@require_auth_and_permission('run_audits')
@conditional_limit("10 per hour")
def test_server_connection(server_id):
    """Test connection to a saved server using configured protocol"""
    try:
        servers = server_manager.load_servers()
        server = next((s for s in servers if s["id"] == server_id), None)
        if not server:
            return jsonify({"success": False, "error": "Server not found"}), 404

        os_type = server.get("os_type", "linux")
        protocol = server.get("connection_protocol", "auto")
        protocol, _ = _enforce_transport_policy(os_type, protocol, server.get("connection_method", "ssh"))

        # Determine effective protocol
        if protocol == "auto":
            # Default: WinRM for Windows (more common), SSH for Linux
            effective_protocol = "winrm" if os_type == "windows" else "ssh"
        else:
            effective_protocol = protocol

        # Test WinRM
        if effective_protocol == "winrm":
            if not winrm_manager or not WINRM_AVAILABLE:
                # For Windows targets, do not silently switch protocols when WinRM libs are unavailable.
                # Instead, verify port reachability and return guidance.
                try:
                    winrm_port = int(server.get("port", 5985))
                except Exception:
                    winrm_port = 5985

                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(10)
                    conn_result = sock.connect_ex((server["host"], winrm_port))
                    sock.close()

                    if conn_result == 0:
                        return jsonify({
                            "success": True,
                            "message": f"WinRM port {winrm_port} is reachable on {server['host']}",
                            "details": "Transport connectivity verified. Install pywinrm in web runtime for full WinRM authentication testing.",
                            "protocol": "winrm",
                            "degraded": True
                        })

                    return jsonify({
                        "success": False,
                        "error": f"Cannot reach WinRM port {winrm_port} on {server['host']}",
                        "details": "Ensure WinRM is enabled and firewall rules allow inbound traffic."
                    }), 500
                except Exception as port_err:
                    return jsonify({
                        "success": False,
                        "error": "WinRM support not available",
                        "details": f"Install pywinrm: pip install pywinrm (port probe error: {port_err})"
                    }), 500
            else:
                use_ssl = server.get("port", 5985) == 5986
                result = winrm_manager.test_connection(
                    hostname=server["host"],
                    port=server.get("port", 5985),
                    username=server["user"],
                    password=server.get("password", ""),
                    use_ssl=use_ssl,
                    timeout=30
                )
                if result.get('success'):
                    result['protocol'] = 'winrm'
                    return jsonify(result)
                elif protocol == "auto":
                    # WinRM failed in auto mode - try SSH fallback
                    logger.info(f"WinRM failed for {server['host']}, trying SSH fallback")
                    effective_protocol = "ssh"
                else:
                    return jsonify(result), 500

        # Test SSH (for Linux, or Windows with OpenSSH, or fallback)
        if effective_protocol == "ssh":
            port = server.get("port", 22)
            # For Windows SSH, adjust default port if it was set to WinRM port
            if os_type == "windows" and port in (5985, 5986):
                port = 22  # SSH default
                logger.info(f"Using SSH port 22 for Windows host {server['host']}")

            if not ssh_host_key_manager.host_known(server["host"], port):
                logger.info(f"Host {server['host']} not in known_hosts, scanning...")
                if not ssh_host_key_manager.add_host_key(server["host"], port):
                    return jsonify({"success": False, "error": "Could not scan SSH host key. Verify host is reachable.", "details": f"ssh-keyscan failed for {server['host']}:{port}"}), 500
            try:
                # Adjust test command based on OS
                test_cmd = "echo Connected" if os_type != "windows" else "Write-Output Connected"
                server_copy = dict(server)
                server_copy['port'] = port
                result = ssh_manager.execute_command(server_copy, test_cmd, timeout=15)
                if result.returncode == 0:
                    return jsonify({
                        "success": True,
                        "message": "SSH connection successful",
                        "details": "Authentication verified. Server is ready.",
                        "protocol": "ssh"
                    })
                else:
                    return jsonify({"success": False, "error": f"SSH authentication failed: {result.stderr}", "details": "Check username and password/key."}), 500
            except subprocess.TimeoutExpired:
                return jsonify({"success": False, "error": "Connection timeout", "details": f"SSH to {server['host']}:{port} timed out after 15 seconds."}), 500
            except Exception as e:
                # Password-based SSH checks may require sshpass in runtime.
                if "sshpass" in str(e).lower() and server.get("auth_type") == "password":
                    try:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(10)
                        conn_result = sock.connect_ex((server["host"], int(port)))
                        sock.close()
                        if conn_result == 0:
                            return jsonify({
                                "success": True,
                                "message": f"SSH port {port} reachable on {server['host']}",
                                "details": "Transport connectivity verified. Install sshpass in web runtime for password-auth SSH command tests.",
                                "protocol": "ssh",
                                "degraded": True
                            })
                    except Exception:
                        logger.debug(
                            "SSH degraded connectivity fallback failed for %s:%s",
                            server.get("host"),
                            port,
                            exc_info=True,
                        )
                return jsonify({"success": False, "error": f"SSH error: {e}"}), 500
    except Exception as e:
        logger.error(f"Error testing server connection {server_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@server_bp.route('/api/servers/test-connection', methods=['POST'])
@require_auth_and_permission('add_servers')
@conditional_limit("10 per hour")
def test_connection_raw():
    """Test connection before saving - supports both SSH and WinRM"""
    try:
        data = request.json
        if not data:
            return jsonify({"success": False, "error": "Invalid request"}), 400
        hostname = data.get("hostname")
        port = data.get("port", 22)
        username = data.get("username")
        password = data.get("password")
        os_type = data.get("os_type", "linux")
        protocol = data.get("connection_protocol", "auto")
        protocol, _ = _enforce_transport_policy(os_type, protocol, data.get("connection_method", "ssh"))
        if not hostname or not username:
            return jsonify({"success": False, "error": "Hostname and username required"}), 400

        temp_server = {
            "host": hostname,
            "port": int(port),
            "user": username,
            "password": password,
            "auth_type": "password" if password else "public_key",
            "key_path": data.get("key_path"),
            "os_type": os_type
        }

        # Determine effective protocol
        if protocol == "auto":
            effective_protocol = "winrm" if os_type == "windows" else "ssh"
        else:
            effective_protocol = protocol

        # Try WinRM
        if effective_protocol == "winrm":
            if winrm_manager and WINRM_AVAILABLE:
                use_ssl = int(port) == 5986
                result = winrm_manager.test_connection(
                    hostname=hostname,
                    port=int(port),
                    username=username,
                    password=password,
                    use_ssl=use_ssl,
                    timeout=30
                )
                if result.get('success'):
                    result['protocol'] = 'winrm'
                    return jsonify(result)
                elif protocol == "auto":
                    # Try SSH fallback
                    logger.info(f"WinRM failed for {hostname}, trying SSH fallback")
                    effective_protocol = "ssh"
                    if int(port) in (5985, 5986):
                        port = 22  # Reset obvious WinRM defaults to SSH default
                else:
                    return jsonify(result), 500
            elif protocol == "auto":
                effective_protocol = "ssh"
                if int(port) in (5985, 5986):
                    port = 22
            else:
                # WinRM explicitly requested but not available
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(10)
                    conn_result = sock.connect_ex((hostname, int(port)))
                    sock.close()
                    if conn_result == 0:
                        return jsonify({
                            "success": True,
                            "message": f"WinRM port {port} is open on {hostname}",
                            "details": "Port connectivity verified.\nNote: Install pywinrm for full authentication testing:\npip install pywinrm",
                            "protocol": "winrm"
                        })
                    else:
                        return jsonify({
                            "success": False,
                            "error": f"Cannot reach port {port} on {hostname}",
                            "details": "Ensure WinRM is enabled on target:\nEnable-PSRemoting -Force\n\nAnd firewall allows connection:\nNew-NetFirewallRule -Name 'WinRM' -LocalPort {port} -Protocol TCP -Action Allow"
                        }), 500
                except socket.gaierror:
                    return jsonify({
                        "success": False,
                        "error": f"DNS resolution failed for {hostname}",
                        "details": "Could not resolve hostname. Verify server name or use IP address."
                    }), 500
                except socket.error as e:
                    return jsonify({
                        "success": False,
                        "error": f"Network error: {str(e)}"
                    }), 500

        # Try SSH
        if effective_protocol == "ssh":
            temp_server['port'] = int(port)
            if not ssh_host_key_manager.host_known(hostname, int(port)):
                logger.info(f"Host {hostname} not in known_hosts, scanning...")
                if not ssh_host_key_manager.add_host_key(hostname, int(port)):
                    return jsonify({
                        "success": False,
                        "error": "Could not scan SSH host key. Verify host is reachable.",
                        "details": f"ssh-keyscan failed for {hostname}:{port}"
                    }), 500
            try:
                # Use appropriate test command for OS
                test_cmd = "Write-Output Connected" if os_type == "windows" else "echo Connected"
                result = ssh_manager.execute_command(temp_server, test_cmd, timeout=15)
                if result.returncode == 0:
                    return jsonify({
                        "success": True,
                        "message": "SSH connection successful",
                        "details": "Authentication verified. Server is ready to save.",
                        "protocol": "ssh"
                    })
                else:
                    return jsonify({
                        "success": False,
                        "error": f"SSH authentication failed: {result.stderr}",
                        "details": "Check username and password/key."
                    }), 500
            except subprocess.TimeoutExpired:
                return jsonify({
                    "success": False,
                    "error": "Connection timeout",
                    "details": f"SSH to {hostname}:{port} timed out after 15 seconds."
                }), 500
            except Exception as e:
                return jsonify({"success": False, "error": f"SSH error: {e}"}), 500
    except Exception as e:
        logger.error(f"Connection test error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# =============================================================================
# Bulk Credential Management
# =============================================================================

@server_bp.route('/api/servers/credentials/bulk-update', methods=['POST'])
@require_auth_and_permission('manage_servers')
@conditional_limit("10 per minute")
def bulk_update_credentials():
    """
    Bulk update credentials for multiple servers

    Use this to rotate SSH passwords or update SSH key paths for multiple
    servers at once. Useful after key rotation or when standardizing credentials.

    Request body:
    {
        "server_ids": [1, 2, 3],  // or "all" for all servers
        "credentials": {
            "password": "new_password",  // optional
            "ssh_key_path": "/path/to/key",  // optional
            "username": "admin"  // optional
        },
        "test_connection": true  // Test each server after update
    }

    Returns:
        Success/failure status for each server
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Request body required'}), 400

        server_ids = data.get('server_ids', [])
        credentials = data.get('credentials', {})
        test_connection = data.get('test_connection', False)

        if not credentials:
            return jsonify({'success': False, 'error': 'No credentials provided'}), 400

        # Load servers
        all_servers = server_manager.load_servers()

        # Determine which servers to update
        if server_ids == 'all':
            target_servers = all_servers
        else:
            target_servers = [s for s in all_servers if s.get('id') in server_ids]

        if not target_servers:
            return jsonify({'success': False, 'error': 'No servers found matching criteria'}), 404

        results = {
            'total': len(target_servers),
            'updated': 0,
            'failed': 0,
            'connection_tested': 0,
            'connection_failed': 0,
            'details': []
        }

        for server in target_servers:
            server_id = server.get('id')
            server_name = server.get('name', 'Unknown')

            try:
                update_data = {}

                # Only include provided credentials
                if 'password' in credentials and credentials['password']:
                    update_data['password'] = credentials['password']
                if 'ssh_key_path' in credentials:
                    update_data['ssh_key_path'] = credentials['ssh_key_path']
                if 'username' in credentials:
                    update_data['username'] = credentials['username']

                if update_data:
                    success = server_manager.update_server(server_id, update_data)
                    if success:
                        results['updated'] += 1
                        detail = {'server_id': server_id, 'name': server_name, 'status': 'updated'}

                        # Test connection if requested
                        if test_connection:
                            results['connection_tested'] += 1
                            try:
                                # Reload server with new credentials
                                updated_server = server_manager.get_server(server_id)
                                test_cmd = "echo test"
                                result = ssh_manager.execute_command(updated_server, test_cmd, timeout=10)
                                if result.returncode == 0:
                                    detail['connection'] = 'success'
                                else:
                                    detail['connection'] = 'failed'
                                    detail['connection_error'] = result.stderr[:200] if result.stderr else 'Unknown error'
                                    results['connection_failed'] += 1
                            except Exception as conn_err:
                                detail['connection'] = 'failed'
                                detail['connection_error'] = str(conn_err)[:200]
                                results['connection_failed'] += 1

                        results['details'].append(detail)
                    else:
                        results['failed'] += 1
                        results['details'].append({
                            'server_id': server_id,
                            'name': server_name,
                            'status': 'failed',
                            'error': 'Update failed'
                        })
            except Exception as e:
                results['failed'] += 1
                results['details'].append({
                    'server_id': server_id,
                    'name': server_name,
                    'status': 'failed',
                    'error': str(e)[:200]
                })

        logger.info(f"Bulk credential update: {results['updated']}/{results['total']} servers updated")

        return jsonify({
            'success': results['failed'] == 0,
            'partial_success': results['updated'] > 0 and results['failed'] > 0,
            'results': results
        })

    except Exception as e:
        logger.error(f"Bulk credential update failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@server_bp.route('/api/servers/credentials/rotate-ssh-keys', methods=['POST'])
@require_auth_and_permission('manage_servers')
@conditional_limit("5 per minute")
def rotate_ssh_keys():
    """
    Generate new SSH key pair and update specified servers

    This endpoint:
    1. Generates a new SSH key pair
    2. Deploys the public key to specified servers (using current credentials)
    3. Updates server configurations to use the new key

    Request body:
    {
        "server_ids": [1, 2, 3],  // Servers to update
        "key_type": "ed25519",  // ed25519, rsa, ecdsa
        "key_bits": 4096,  // For RSA only
        "key_name": "audit_toolkit_key",  // Name for key file
        "deploy_to_servers": true,  // Deploy public key via ssh-copy-id style
        "backup_existing": true  // Backup existing authorized_keys
    }
    """
    try:
        from pathlib import Path

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Request body required'}), 400

        server_ids = data.get('server_ids', [])
        key_type = data.get('key_type', 'ed25519')
        key_bits = data.get('key_bits', 4096)
        key_name = data.get('key_name', 'audit_toolkit_key')
        deploy_to_servers = data.get('deploy_to_servers', True)
        backup_existing = data.get('backup_existing', True)

        # Validate key type
        if key_type not in ['ed25519', 'rsa', 'ecdsa']:
            return jsonify({'success': False, 'error': 'Invalid key_type. Use: ed25519, rsa, ecdsa'}), 400

        # Sanitize key name
        key_name = ''.join(c for c in key_name if c.isalnum() or c in '-_')[:50]

        # Determine key directory
        ssh_dir = Path.home() / '.ssh'
        ssh_dir.mkdir(mode=0o700, exist_ok=True)

        private_key_path = ssh_dir / key_name
        public_key_path = ssh_dir / f"{key_name}.pub"

        # Check if key already exists
        if private_key_path.exists():
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_path = ssh_dir / f"{key_name}.backup_{timestamp}"
            private_key_path.rename(backup_path)
            if public_key_path.exists():
                public_key_path.rename(ssh_dir / f"{key_name}.pub.backup_{timestamp}")
            logger.info(f"Backed up existing key to {backup_path}")

        # Generate new key pair
        keygen_cmd = ['ssh-keygen', '-t', key_type, '-f', str(private_key_path), '-N', '', '-q']
        if key_type == 'rsa':
            keygen_cmd.extend(['-b', str(key_bits)])

        result = subprocess.run(keygen_cmd, capture_output=True, text=True, check=False)  # nosec B603
        if result.returncode != 0:
            return jsonify({
                'success': False,
                'error': f'Key generation failed: {result.stderr}'
            }), 500

        # Read public key
        public_key = public_key_path.read_text().strip()

        results = {
            'key_generated': True,
            'key_type': key_type,
            'private_key_path': str(private_key_path),
            'public_key_path': str(public_key_path),
            'servers_updated': 0,
            'servers_failed': 0,
            'details': []
        }

        # Deploy to servers if requested
        if deploy_to_servers and server_ids:
            all_servers = server_manager.load_servers()
            target_servers = [s for s in all_servers if s.get('id') in server_ids]

            for server in target_servers:
                server_id = server.get('id')
                server_name = server.get('name', 'Unknown')
                username = server.get('username', 'root')

                try:
                    # Deploy public key using existing credentials
                    backup_line = "cp ~/.ssh/authorized_keys ~/.ssh/authorized_keys.backup_$(date +%Y%m%d_%H%M%S)" if backup_existing else ""
                    deploy_cmd = f'''
mkdir -p ~/.ssh && chmod 700 ~/.ssh
{backup_line}
echo "{public_key}" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
echo "Key deployed successfully"
'''
                    deploy_result = ssh_manager.execute_command(server, deploy_cmd, timeout=30)

                    if deploy_result.returncode == 0:
                        # Update server to use new key
                        update_success = server_manager.update_server(server_id, {
                            'ssh_key_path': str(private_key_path),
                            'password': None,  # nosec B105
                        })

                        if update_success:
                            results['servers_updated'] += 1
                            results['details'].append({
                                'server_id': server_id,
                                'name': server_name,
                                'status': 'success',
                                'message': 'Key deployed and server updated'
                            })
                        else:
                            results['details'].append({
                                'server_id': server_id,
                                'name': server_name,
                                'status': 'partial',
                                'message': 'Key deployed but server config update failed'
                            })
                    else:
                        results['servers_failed'] += 1
                        results['details'].append({
                            'server_id': server_id,
                            'name': server_name,
                            'status': 'failed',
                            'error': deploy_result.stderr[:200] if deploy_result.stderr else 'Deployment failed'
                        })
                except Exception as e:
                    results['servers_failed'] += 1
                    results['details'].append({
                        'server_id': server_id,
                        'name': server_name,
                        'status': 'failed',
                        'error': str(e)[:200]
                    })

        logger.info(f"SSH key rotation complete: {results['servers_updated']} servers updated")

        return jsonify({
            'success': True,
            'results': results,
            'public_key': public_key,
            'note': 'Store the public key securely. Use bulk-update endpoint to apply to additional servers.'
        })

    except Exception as e:
        logger.error(f"SSH key rotation failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@server_bp.route('/api/servers/credentials/verify', methods=['POST'])
@require_auth_and_permission('manage_servers')
@conditional_limit("30 per minute")
def verify_server_credentials():
    """
    Verify credentials work for specified servers

    Useful after credential changes to confirm connectivity.

    Request body:
    {
        "server_ids": [1, 2, 3]  // or "all"
    }
    """
    try:
        data = request.get_json()
        server_ids = data.get('server_ids', []) if data else []

        all_servers = server_manager.load_servers()

        if server_ids == 'all':
            target_servers = all_servers
        else:
            target_servers = [s for s in all_servers if s.get('id') in server_ids]

        if not target_servers:
            return jsonify({'success': False, 'error': 'No servers found'}), 404

        results = {
            'total': len(target_servers),
            'success': 0,
            'failed': 0,
            'details': []
        }

        for server in target_servers:
            server_id = server.get('id')
            server_name = server.get('name', 'Unknown')

            try:
                test_cmd = "echo connected"
                result = ssh_manager.execute_command(server, test_cmd, timeout=15)

                if result.returncode == 0:
                    results['success'] += 1
                    results['details'].append({
                        'server_id': server_id,
                        'name': server_name,
                        'status': 'connected',
                        'auth_type': 'key' if server.get('ssh_key_path') else 'password'
                    })
                else:
                    results['failed'] += 1
                    results['details'].append({
                        'server_id': server_id,
                        'name': server_name,
                        'status': 'auth_failed',
                        'error': result.stderr[:100] if result.stderr else 'Connection failed'
                    })
            except Exception as e:
                results['failed'] += 1
                results['details'].append({
                    'server_id': server_id,
                    'name': server_name,
                    'status': 'error',
                    'error': str(e)[:100]
                })

        return jsonify({
            'success': results['failed'] == 0,
            'results': results
        })

    except Exception as e:
        logger.error(f"Credential verification failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# End of server_routes.py
