"""
SIEM Integration Routes for Security Audit Toolkit

Provides:
- SIEM configuration management
- Connection testing for various SIEM platforms
- Webhook/Syslog configuration
- Platform presets (Wazuh, Splunk, ELK, Sentinel, QRadar, Graylog)

Supported Platforms:
- Wazuh (syslog)
- Splunk (HTTP Event Collector)
- Elastic SIEM / ELK Stack (Elasticsearch API)
- Microsoft Sentinel (Azure Log Analytics)
- IBM QRadar (syslog/REST)
- Graylog (GELF)
- Custom Syslog
- Custom Webhook

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import os
import socket
import ssl
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional, Tuple, List

from flask import Blueprint, request, jsonify, render_template
from flask_login import login_required

from api.auth_routes import require_role
from auth_core import safe_error_response

logger = logging.getLogger(__name__)

# Blueprint
siem_bp = Blueprint('siem_admin', __name__, url_prefix='/api/admin/siem')


# =============================================================================
# SIEM Platform Definitions
# =============================================================================

SIEM_PLATFORMS = {
    'wazuh': {
        'name': 'Wazuh',
        'description': 'Open-source security monitoring platform',
        'methods': ['syslog', 'agent'],
        'default_port': 514,
        'docs_url': 'https://documentation.wazuh.com/',
        'icon': 'shield-check'
    },
    'splunk': {
        'name': 'Splunk',
        'description': 'Enterprise SIEM with HTTP Event Collector (HEC)',
        'methods': ['webhook', 'hec'],
        'default_port': 8088,
        'docs_url': 'https://docs.splunk.com/',
        'icon': 'bar-chart'
    },
    'elastic': {
        'name': 'Elastic SIEM (ELK)',
        'description': 'Elasticsearch, Logstash, Kibana stack',
        'methods': ['webhook', 'syslog', 'filebeat'],
        'default_port': 9200,
        'docs_url': 'https://www.elastic.co/guide/',
        'icon': 'database'
    },
    'sentinel': {
        'name': 'Microsoft Sentinel',
        'description': 'Azure cloud-native SIEM',
        'methods': ['webhook', 'log_analytics'],
        'default_port': 443,
        'docs_url': 'https://docs.microsoft.com/azure/sentinel/',
        'icon': 'cloud'
    },
    'qradar': {
        'name': 'IBM QRadar',
        'description': 'Enterprise security intelligence platform',
        'methods': ['syslog', 'rest'],
        'default_port': 514,
        'docs_url': 'https://www.ibm.com/docs/qradar',
        'icon': 'server'
    },
    'graylog': {
        'name': 'Graylog',
        'description': 'Log management with GELF support',
        'methods': ['gelf', 'syslog'],
        'default_port': 12201,
        'docs_url': 'https://docs.graylog.org/',
        'icon': 'archive'
    },
    'custom_syslog': {
        'name': 'Custom Syslog',
        'description': 'Generic syslog forwarding to any target',
        'methods': ['syslog'],
        'default_port': 514,
        'docs_url': None,
        'icon': 'terminal'
    },
    'custom_webhook': {
        'name': 'Custom Webhook',
        'description': 'HTTP/HTTPS webhook to any endpoint',
        'methods': ['webhook'],
        'default_port': 443,
        'docs_url': None,
        'icon': 'link'
    }
}


# =============================================================================
# SIEM Configuration Model
# =============================================================================

@dataclass
class SIEMConfig:
    """SIEM integration configuration"""
    # General
    enabled: bool = False
    platform: str = 'custom_syslog'
    name: str = 'Default SIEM'

    # Syslog settings
    syslog_enabled: bool = False
    syslog_host: str = ''
    syslog_port: int = 514
    syslog_protocol: str = 'udp'  # udp, tcp, tls
    syslog_facility: str = 'local0'
    syslog_format: str = 'json'  # json, cef, plain

    # Webhook settings
    webhook_enabled: bool = False
    webhook_url: str = ''
    webhook_auth_type: str = 'none'  # none, bearer, api_key, basic
    webhook_auth_header: str = ''
    webhook_auth_value: str = ''  # Will be masked in output
    webhook_format: str = 'json'  # json, cef
    webhook_batch_size: int = 1
    webhook_timeout: int = 30

    # TLS/SSL
    tls_verify: bool = True
    tls_ca_cert: str = ''

    # Log categories to forward
    log_categories: List[str] = field(default_factory=lambda: [
        'security', 'audit', 'authentication'
    ])

    # Severity filter (minimum level to forward)
    min_severity: str = 'info'  # debug, info, warning, error, critical

    @classmethod
    def from_env(cls) -> 'SIEMConfig':
        """Load configuration from environment variables"""
        return cls(
            enabled=os.getenv('SIEM_ENABLED', 'false').lower() == 'true',
            platform=os.getenv('SIEM_PLATFORM', 'custom_syslog'),
            name=os.getenv('SIEM_NAME', 'Default SIEM'),
            syslog_enabled=os.getenv('SYSLOG_ENABLED', 'false').lower() == 'true',
            syslog_host=os.getenv('SYSLOG_HOST', ''),
            syslog_port=int(os.getenv('SYSLOG_PORT', '514')),
            syslog_protocol=os.getenv('SYSLOG_PROTOCOL', 'udp'),
            syslog_facility=os.getenv('SYSLOG_FACILITY', 'local0'),
            syslog_format=os.getenv('SYSLOG_FORMAT', 'json'),
            webhook_enabled=os.getenv('WEBHOOK_ENABLED', 'false').lower() == 'true',
            webhook_url=os.getenv('WEBHOOK_URL', ''),
            webhook_auth_type=os.getenv('WEBHOOK_AUTH_TYPE', 'none'),
            webhook_auth_header=os.getenv('WEBHOOK_AUTH_HEADER', ''),
            webhook_auth_value=os.getenv('WEBHOOK_AUTH_VALUE', ''),
            webhook_format=os.getenv('WEBHOOK_FORMAT', 'json'),
            webhook_batch_size=int(os.getenv('WEBHOOK_BATCH_SIZE', '1')),
            webhook_timeout=int(os.getenv('WEBHOOK_TIMEOUT', '30')),
            tls_verify=os.getenv('SIEM_TLS_VERIFY', 'true').lower() == 'true',
            tls_ca_cert=os.getenv('SIEM_TLS_CA_CERT', ''),
            log_categories=os.getenv('SIEM_LOG_CATEGORIES', 'security,audit,authentication').split(','),
            min_severity=os.getenv('SIEM_MIN_SEVERITY', 'info')
        )

    def to_safe_dict(self) -> Dict:
        """Return config dict with sensitive values masked"""
        return {
            'enabled': self.enabled,
            'platform': self.platform,
            'name': self.name,
            'syslog': {
                'enabled': self.syslog_enabled,
                'host': self.syslog_host,
                'port': self.syslog_port,
                'protocol': self.syslog_protocol,
                'facility': self.syslog_facility,
                'format': self.syslog_format
            },
            'webhook': {
                'enabled': self.webhook_enabled,
                'url': self._mask_url(self.webhook_url),
                'auth_type': self.webhook_auth_type,
                'auth_header': self.webhook_auth_header,
                'auth_value': '********' if self.webhook_auth_value else '',
                'format': self.webhook_format,
                'batch_size': self.webhook_batch_size,
                'timeout': self.webhook_timeout
            },
            'tls': {
                'verify': self.tls_verify,
                'ca_cert_configured': bool(self.tls_ca_cert)
            },
            'log_categories': self.log_categories,
            'min_severity': self.min_severity
        }

    def _mask_url(self, url: str) -> str:
        """Mask credentials in URL if present"""
        if not url:
            return ''
        # Mask any embedded credentials in URL
        import re
        return re.sub(r'://[^@]+@', '://****:****@', url)

    def validate(self) -> Tuple[bool, List[str]]:
        """Validate configuration"""
        errors = []

        if not self.enabled:
            return True, []

        # Must have at least one method enabled
        if not self.syslog_enabled and not self.webhook_enabled:
            errors.append('At least one forwarding method (syslog or webhook) must be enabled')

        # Validate syslog settings
        if self.syslog_enabled:
            if not self.syslog_host:
                errors.append('Syslog host is required when syslog is enabled')
            if self.syslog_port < 1 or self.syslog_port > 65535:
                errors.append('Syslog port must be between 1 and 65535')
            if self.syslog_protocol not in ('udp', 'tcp', 'tls'):
                errors.append('Syslog protocol must be udp, tcp, or tls')

        # Validate webhook settings
        if self.webhook_enabled:
            if not self.webhook_url:
                errors.append('Webhook URL is required when webhook is enabled')
            elif not self.webhook_url.startswith(('http://', 'https://')):
                errors.append('Webhook URL must start with http:// or https://')

            if self.webhook_auth_type not in ('none', 'bearer', 'api_key', 'basic'):
                errors.append('Invalid webhook auth type')

            if self.webhook_auth_type != 'none' and not self.webhook_auth_value:
                errors.append('Auth value required when auth type is not "none"')

        return len(errors) == 0, errors


# Global config instance
_siem_config: Optional[SIEMConfig] = None


def get_siem_config() -> SIEMConfig:
    """Get or create SIEM configuration"""
    global _siem_config
    if _siem_config is None:
        _siem_config = SIEMConfig.from_env()
    return _siem_config


# =============================================================================
# SIEM Integration Page
# =============================================================================

@siem_bp.route('/page', methods=['GET'])
@login_required
@require_role('Admin')
def siem_page():
    """SIEM integration admin page"""
    return render_template('admin/siem.html')


# =============================================================================
# SIEM Status & Configuration
# =============================================================================

@siem_bp.route('/status', methods=['GET'])
@login_required
@require_role('Admin')
def siem_status():
    """
    Get SIEM integration status and configuration (masked)

    Returns:
        JSON with SIEM enabled status and masked config
    """
    try:
        config = get_siem_config()
        is_valid, errors = config.validate()

        return jsonify({
            'success': True,
            'enabled': config.enabled,
            'valid': is_valid,
            'validation_errors': errors if not is_valid else [],
            'config': config.to_safe_dict()
        })

    except Exception as e:
        logger.error(f"Error getting SIEM status: {e}")
        return safe_error_response(e, 'Failed to get SIEM status')


@siem_bp.route('/platforms', methods=['GET'])
@login_required
@require_role('Admin')
def list_platforms():
    """
    List available SIEM platforms with their configurations

    Returns:
        JSON with platform list and details
    """
    try:
        return jsonify({
            'success': True,
            'platforms': SIEM_PLATFORMS
        })

    except Exception as e:
        logger.error(f"Error listing SIEM platforms: {e}")
        return safe_error_response(e, 'Failed to list SIEM platforms')


# =============================================================================
# Connection Testing
# =============================================================================

@siem_bp.route('/test/syslog', methods=['POST'])
@login_required
@require_role('Admin')
def test_syslog_connection():
    """
    Test syslog connection to SIEM

    Request body (optional):
        JSON with syslog settings to test instead of environment

    Returns:
        JSON with test result
    """
    try:
        data = request.get_json() or {}

        # Get settings from request or environment
        host = data.get('host') or get_siem_config().syslog_host
        try:
            port = int(data.get('port', get_siem_config().syslog_port))
        except (ValueError, TypeError):
            return jsonify({
                'success': False,
                'error': 'Invalid port number'
            }), 400
        protocol = data.get('protocol') or get_siem_config().syslog_protocol

        if not host:
            return jsonify({
                'success': False,
                'error': 'Syslog host is required'
            }), 400

        # Validate port range
        if port < 1 or port > 65535:
            return jsonify({
                'success': False,
                'error': 'Port must be between 1 and 65535'
            }), 400

        # Test connection based on protocol
        success, message = _test_syslog_tcp(host, port) if protocol in ('tcp', 'tls') else _test_syslog_udp(host, port)

        if success:
            return jsonify({
                'success': True,
                'message': message
            })
        else:
            return jsonify({
                'success': False,
                'error': message
            }), 400

    except Exception as e:
        logger.error(f"Error testing syslog connection: {e}")
        return safe_error_response(e, 'Failed to test syslog connection')


def _test_syslog_tcp(host: str, port: int) -> Tuple[bool, str]:
    """Test TCP syslog connection"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((host, port))
        sock.close()
        return True, f"Successfully connected to {host}:{port} via TCP"
    except socket.timeout:
        return False, f"Connection timed out to {host}:{port}"
    except socket.error as e:
        return False, f"Connection failed: {str(e)}"
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"


def _test_syslog_udp(host: str, port: int) -> Tuple[bool, str]:
    """Test UDP syslog (can only verify DNS resolution)"""
    try:
        # Resolve hostname
        socket.gethostbyname(host)

        # Create UDP socket and send test message
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(5)

        # Send RFC 5424 test message
        test_msg = f"<14>1 {datetime.utcnow().isoformat()}Z security-audit-toolkit - - - TEST Connection test from Security Audit Toolkit"
        sock.sendto(test_msg.encode(), (host, port))
        sock.close()

        return True, f"Test message sent to {host}:{port} via UDP (delivery not confirmed - UDP is connectionless)"
    except socket.gaierror:
        return False, f"Cannot resolve hostname: {host}"
    except Exception as e:
        return False, f"Error: {str(e)}"


@siem_bp.route('/test/webhook', methods=['POST'])
@login_required
@require_role('Admin')
def test_webhook_connection():
    """
    Test webhook connection to SIEM

    Request body (optional):
        JSON with webhook settings to test instead of environment

    Returns:
        JSON with test result
    """
    try:
        import requests
        from validators_network import validate_url

        data = request.get_json() or {}
        config = get_siem_config()

        # Get settings from request or environment
        url = data.get('url') or config.webhook_url
        auth_type = data.get('auth_type') or config.webhook_auth_type
        auth_header = data.get('auth_header') or config.webhook_auth_header
        auth_value = data.get('auth_value') or config.webhook_auth_value
        timeout = int(data.get('timeout', config.webhook_timeout))

        if not url:
            return jsonify({
                'success': False,
                'error': 'Webhook URL is required'
            }), 400

        # Validate URL (SSRF protection)
        is_valid, error_msg = validate_url(url)
        if not is_valid:
            return jsonify({
                'success': False,
                'error': f'Invalid URL: {error_msg}'
            }), 400

        # Build headers
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'SecurityAuditToolkit/1.0'
        }

        if auth_type == 'bearer' and auth_value:
            headers['Authorization'] = f'Bearer {auth_value}'
        elif auth_type == 'api_key' and auth_header and auth_value:
            headers[auth_header] = auth_value
        elif auth_type == 'basic' and auth_value:
            import base64
            encoded = base64.b64encode(auth_value.encode()).decode()
            headers['Authorization'] = f'Basic {encoded}'

        # Build test payload
        test_payload = {
            'event_type': 'connection_test',
            'source': 'security-audit-toolkit',
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'message': 'Connection test from Security Audit Toolkit'
        }

        # Send test request
        try:
            response = requests.post(
                url,
                headers=headers,
                json=test_payload,
                timeout=timeout,
                verify=config.tls_verify
            )

            if response.status_code in (200, 201, 202, 204):
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to webhook (HTTP {response.status_code})'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Webhook returned HTTP {response.status_code}: {response.text[:200]}'
                }), 400

        except requests.exceptions.Timeout:
            return jsonify({
                'success': False,
                'error': f'Connection timed out after {timeout} seconds'
            }), 400
        except requests.exceptions.SSLError as e:
            return jsonify({
                'success': False,
                'error': f'SSL/TLS error: {str(e)}'
            }), 400
        except requests.exceptions.ConnectionError as e:
            return jsonify({
                'success': False,
                'error': f'Connection failed: {str(e)}'
            }), 400

    except ImportError:
        return jsonify({
            'success': False,
            'error': 'requests library not installed'
        }), 500
    except Exception as e:
        logger.error(f"Error testing webhook connection: {e}")
        return safe_error_response(e, 'Failed to test webhook connection')


# =============================================================================
# Send Test Event
# =============================================================================

@siem_bp.route('/test/send-event', methods=['POST'])
@login_required
@require_role('Admin')
def send_test_event():
    """
    Send a test event to configured SIEM

    Returns:
        JSON with send results for each configured method
    """
    try:
        config = get_siem_config()

        if not config.enabled:
            return jsonify({
                'success': False,
                'error': 'SIEM integration is not enabled'
            }), 400

        results = {
            'syslog': None,
            'webhook': None
        }

        # Test event payload
        test_event = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': 'INFO',
            'logger': 'security',
            'event_type': 'test_event',
            'message': 'Test event from Security Audit Toolkit admin panel',
            'source': 'admin',
            'test': True
        }

        # Send via syslog if enabled
        if config.syslog_enabled:
            try:
                success, msg = _send_syslog_event(test_event, config)
                results['syslog'] = {'success': success, 'message': msg}
            except Exception as e:
                results['syslog'] = {'success': False, 'message': str(e)}

        # Send via webhook if enabled
        if config.webhook_enabled:
            try:
                success, msg = _send_webhook_event(test_event, config)
                results['webhook'] = {'success': success, 'message': msg}
            except Exception as e:
                results['webhook'] = {'success': False, 'message': str(e)}

        # Determine overall success
        overall_success = any(
            r and r.get('success')
            for r in results.values()
            if r is not None
        )

        return jsonify({
            'success': overall_success,
            'results': results
        })

    except Exception as e:
        logger.error(f"Error sending test event: {e}")
        return safe_error_response(e, 'Failed to send test event')


def _validate_syslog_host(host: str) -> Tuple[bool, str]:
    """Validate syslog host is not an internal/blocked IP (SSRF protection)"""
    import ipaddress

    try:
        # Resolve hostname to IP
        ip_str = socket.gethostbyname(host)
        ip = ipaddress.ip_address(ip_str)

        # Block private/reserved ranges
        if ip.is_private:
            return False, "Cannot send to private IP addresses"
        if ip.is_loopback:
            return False, "Cannot send to loopback addresses"
        if ip.is_link_local:
            return False, "Cannot send to link-local addresses"
        if ip.is_reserved:
            return False, "Cannot send to reserved addresses"
        if ip.is_multicast:
            return False, "Cannot send to multicast addresses"

        # Block cloud metadata endpoints
        if ip_str in ('169.254.169.254', '169.254.170.2'):
            return False, "Cannot send to cloud metadata endpoints"

        return True, ip_str
    except socket.gaierror:
        return False, f"Cannot resolve hostname: {host}"
    except ValueError as e:
        return False, f"Invalid IP address: {e}"


def _send_syslog_event(event: Dict, config: SIEMConfig) -> Tuple[bool, str]:
    """Send event via syslog"""
    sock = None
    try:
        # SSRF protection - validate syslog host
        is_valid, result = _validate_syslog_host(config.syslog_host)
        if not is_valid:
            return False, f"Invalid syslog host (SSRF protection): {result}"

        # Format message based on config
        if config.syslog_format == 'json':
            message = json.dumps(event)
        elif config.syslog_format == 'cef':
            message = _format_cef(event)
        else:
            message = event.get('message', '')

        # Create syslog message (RFC 5424)
        facility_map = {
            'local0': 16, 'local1': 17, 'local2': 18, 'local3': 19,
            'local4': 20, 'local5': 21, 'local6': 22, 'local7': 23
        }
        facility = facility_map.get(config.syslog_facility, 16)
        severity = 6  # INFO
        priority = (facility * 8) + severity

        syslog_msg = f"<{priority}>1 {event['timestamp']} security-audit-toolkit - - - {message}"

        if config.syslog_protocol == 'udp':
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(syslog_msg.encode(), (config.syslog_host, config.syslog_port))
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if config.syslog_protocol == 'tls':
                context = ssl.create_default_context()
                if not config.tls_verify:
                    context.check_hostname = False
                    context.verify_mode = ssl.CERT_NONE
                sock = context.wrap_socket(sock, server_hostname=config.syslog_host)
            sock.settimeout(10)
            sock.connect((config.syslog_host, config.syslog_port))
            sock.send(syslog_msg.encode() + b'\n')

        return True, f"Event sent via syslog ({config.syslog_protocol})"

    except Exception as e:
        return False, str(e)
    finally:
        if sock:
            try:
                sock.close()
            except Exception as e:
                logger.debug(f"Socket close failed: {e}")


def _send_webhook_event(event: Dict, config: SIEMConfig) -> Tuple[bool, str]:
    """Send event via webhook"""
    try:
        import requests
        import base64
        from validators_network import validate_url

        # SSRF protection - validate webhook URL
        is_valid, error_msg = validate_url(config.webhook_url)
        if not is_valid:
            return False, f"Invalid webhook URL (SSRF protection): {error_msg}"

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'SecurityAuditToolkit/1.0'
        }

        if config.webhook_auth_type == 'bearer' and config.webhook_auth_value:
            headers['Authorization'] = f'Bearer {config.webhook_auth_value}'
        elif config.webhook_auth_type == 'api_key' and config.webhook_auth_header and config.webhook_auth_value:
            headers[config.webhook_auth_header] = config.webhook_auth_value
        elif config.webhook_auth_type == 'basic' and config.webhook_auth_value:
            # Basic auth expects username:password format
            encoded = base64.b64encode(config.webhook_auth_value.encode()).decode()
            headers['Authorization'] = f'Basic {encoded}'

        # Format payload
        if config.webhook_format == 'cef':
            payload = {'cef': _format_cef(event)}
        else:
            payload = event

        response = requests.post(
            config.webhook_url,
            headers=headers,
            json=payload,
            timeout=config.webhook_timeout,
            verify=config.tls_verify
        )

        if response.status_code in (200, 201, 202, 204):
            return True, f"Event sent via webhook (HTTP {response.status_code})"
        else:
            return False, f"Webhook returned HTTP {response.status_code}"

    except Exception as e:
        return False, str(e)


def _format_cef(event: Dict) -> str:
    """Format event as CEF (Common Event Format)"""
    severity_map = {
        'debug': 1, 'info': 3, 'warning': 5, 'error': 7, 'critical': 10
    }
    severity = severity_map.get(event.get('level', 'info').lower(), 3)

    return (
        "CEF:0|SecurityAuditToolkit|SAT|1.0|"
        f"{event.get('event_type', 'unknown')}|"
        f"{event.get('message', 'Event')}|{severity}|"
        f"msg={event.get('message', '')} "
        f"src={event.get('source_ip', '')} "
        f"suser={event.get('username', '')}"
    )


# =============================================================================
# Configuration Validation
# =============================================================================

@siem_bp.route('/validate', methods=['POST'])
@login_required
@require_role('Admin')
def validate_config():
    """
    Validate SIEM configuration

    Request body (optional):
        JSON with config values to validate instead of environment

    Returns:
        JSON with validation result
    """
    try:
        data = request.get_json() or {}

        if data:
            # Create config from provided values
            config = SIEMConfig(
                enabled=data.get('enabled', False),
                platform=data.get('platform', 'custom_syslog'),
                name=data.get('name', 'Default SIEM'),
                syslog_enabled=data.get('syslog_enabled', False),
                syslog_host=data.get('syslog_host', ''),
                syslog_port=int(data.get('syslog_port', 514)),
                syslog_protocol=data.get('syslog_protocol', 'udp'),
                syslog_facility=data.get('syslog_facility', 'local0'),
                syslog_format=data.get('syslog_format', 'json'),
                webhook_enabled=data.get('webhook_enabled', False),
                webhook_url=data.get('webhook_url', ''),
                webhook_auth_type=data.get('webhook_auth_type', 'none'),
                webhook_auth_header=data.get('webhook_auth_header', ''),
                webhook_auth_value=data.get('webhook_auth_value', ''),
                webhook_format=data.get('webhook_format', 'json'),
                webhook_batch_size=int(data.get('webhook_batch_size', 1)),
                webhook_timeout=int(data.get('webhook_timeout', 30)),
                tls_verify=data.get('tls_verify', True),
                log_categories=data.get('log_categories', ['security', 'audit', 'authentication']),
                min_severity=data.get('min_severity', 'info')
            )
        else:
            # Use environment config
            config = get_siem_config()

        is_valid, errors = config.validate()

        return jsonify({
            'success': True,
            'valid': is_valid,
            'errors': errors
        })

    except Exception as e:
        logger.error(f"Error validating SIEM config: {e}")
        return safe_error_response(e, 'Failed to validate configuration')


# =============================================================================
# Environment Configuration Helper
# =============================================================================

@siem_bp.route('/env-template', methods=['GET'])
@login_required
@require_role('Admin')
def get_env_template():
    """
    Get environment variable template for SIEM configuration

    Query params:
        platform: Platform name to get preset for

    Returns:
        JSON with environment variable template
    """
    try:
        platform = request.args.get('platform', 'custom_syslog')

        # Base template
        template = {
            'SIEM_ENABLED': 'true',
            'SIEM_PLATFORM': platform,
            'SIEM_NAME': SIEM_PLATFORMS.get(platform, {}).get('name', 'Custom SIEM'),
            'SIEM_MIN_SEVERITY': 'info',
            'SIEM_LOG_CATEGORIES': 'security,audit,authentication'
        }

        # Add platform-specific settings
        if platform in ('wazuh', 'qradar', 'custom_syslog'):
            template.update({
                'SYSLOG_ENABLED': 'true',
                'SYSLOG_HOST': 'your-siem-server.example.com',
                'SYSLOG_PORT': str(SIEM_PLATFORMS.get(platform, {}).get('default_port', 514)),
                'SYSLOG_PROTOCOL': 'udp',
                'SYSLOG_FACILITY': 'local0',
                'SYSLOG_FORMAT': 'json'
            })

        if platform in ('splunk', 'elastic', 'sentinel', 'custom_webhook'):
            template.update({
                'WEBHOOK_ENABLED': 'true',
                'WEBHOOK_URL': _get_webhook_url_example(platform),
                'WEBHOOK_AUTH_TYPE': 'bearer',
                'WEBHOOK_AUTH_HEADER': 'Authorization',
                'WEBHOOK_AUTH_VALUE': 'your-api-token',
                'WEBHOOK_FORMAT': 'json',
                'WEBHOOK_TIMEOUT': '30'
            })

        if platform == 'graylog':
            template.update({
                'SYSLOG_ENABLED': 'true',
                'SYSLOG_HOST': 'your-graylog-server.example.com',
                'SYSLOG_PORT': '12201',
                'SYSLOG_PROTOCOL': 'udp',
                'SYSLOG_FORMAT': 'json'
            })

        # Add TLS settings
        template.update({
            'SIEM_TLS_VERIFY': 'true',
            'SIEM_TLS_CA_CERT': ''
        })

        return jsonify({
            'success': True,
            'platform': platform,
            'template': template,
            'as_env_file': '\n'.join(f'{k}={v}' for k, v in template.items())
        })

    except Exception as e:
        logger.error(f"Error getting env template: {e}")
        return safe_error_response(e, 'Failed to get environment template')


def _get_webhook_url_example(platform: str) -> str:
    """Get example webhook URL for platform"""
    examples = {
        'splunk': 'https://splunk.example.com:8088/services/collector/event',
        'elastic': 'https://elasticsearch.example.com:9200/_bulk',
        'sentinel': 'https://your-workspace.ods.opinsights.azure.com/api/logs?api-version=2016-04-01',
        'custom_webhook': 'https://your-siem.example.com/api/events'
    }
    return examples.get(platform, 'https://your-siem.example.com/api/events')
