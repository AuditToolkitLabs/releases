"""
Storage Management Routes for Security Audit Toolkit

Provides:
- Storage backend configuration info
- Storage statistics
- Storage health check
- Migration status and controls

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
from datetime import datetime
from typing import Dict, Any

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user

from api.auth_routes import require_role

logger = logging.getLogger(__name__)

# Blueprint
storage_bp = Blueprint('storage', __name__, url_prefix='/api/admin/storage')


def _get_storage_manager():
    """Lazy import storage manager to avoid circular imports."""
    try:
        from storage import storage_manager
        return storage_manager
    except ImportError as e:
        logger.error(f"Failed to import storage manager: {e}")
        return None


# =============================================================================
# Storage Information
# =============================================================================

@storage_bp.route('/info', methods=['GET'])
@login_required
@require_role('Admin')
def get_storage_info():
    """
    Get storage backend configuration and status.

    Returns:
        - backend_type: Current storage backend (LocalStorageBackend, S3StorageBackend)
        - compression_enabled: Whether compression is active
        - encryption_enabled: Whether encryption is active
        - backend-specific config (path, bucket, etc.)
    """
    manager = _get_storage_manager()
    if not manager:
        return jsonify({
            'success': False,
            'error': 'Storage module not available'
        }), 500

    try:
        info = manager.get_backend_info()
        return jsonify({
            'success': True,
            'storage': info
        })
    except Exception as e:
        logger.error(f"Error getting storage info: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@storage_bp.route('/stats', methods=['GET'])
@login_required
@require_role('Admin')
def get_storage_stats():
    """
    Get storage usage statistics.

    Returns:
        - total_files: Total number of stored files
        - total_size: Total storage used (bytes)
        - by_category: Breakdown by storage category
    """
    manager = _get_storage_manager()
    if not manager:
        return jsonify({
            'success': False,
            'error': 'Storage module not available'
        }), 500

    try:
        stats = manager.get_stats()

        # Add category breakdown
        categories = {}
        category_prefixes = {
            'reports': 'reports/',
            'audit_data': 'audit-data/',
            'scripts': 'scripts/',
            'templates': 'templates/',
            'artifacts': 'artifacts/',
            'backups': 'backups/',
            'logs': 'logs/',
        }

        for name, prefix in category_prefixes.items():
            try:
                files = manager.list_files(prefix)
                categories[name] = {
                    'file_count': len(files),
                    'total_size': sum(f.size for f in files),
                }
            except Exception:
                categories[name] = {'file_count': 0, 'total_size': 0}

        return jsonify({
            'success': True,
            'stats': stats,
            'categories': categories
        })
    except Exception as e:
        logger.error(f"Error getting storage stats: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@storage_bp.route('/health', methods=['GET'])
@login_required
@require_role('Admin')
def check_storage_health():
    """
    Check storage backend health.

    Performs:
        - Write test (creates temp file)
        - Read test (reads temp file)
        - Delete test (removes temp file)
        - Latency measurement
    """
    manager = _get_storage_manager()
    if not manager:
        return jsonify({
            'success': False,
            'error': 'Storage module not available',
            'healthy': False
        }), 500

    health_result: Dict[str, Any] = {
        'healthy': True,
        'backend_type': type(manager.backend).__name__,
        'checks': {},
        'latency_ms': None,
    }

    test_path = f"_health_check/{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
    test_data = b'Health check test data'

    import time
    start_time = time.time()

    # Write test
    try:
        manager.put(test_path, test_data)
        health_result['checks']['write'] = 'pass'
    except Exception as e:
        health_result['checks']['write'] = f'fail: {e}'
        health_result['healthy'] = False

    # Read test
    try:
        read_data = manager.get(test_path)
        if read_data == test_data:
            health_result['checks']['read'] = 'pass'
        else:
            health_result['checks']['read'] = 'fail: data mismatch'
            health_result['healthy'] = False
    except Exception as e:
        health_result['checks']['read'] = f'fail: {e}'
        health_result['healthy'] = False

    # Delete test
    try:
        manager.delete(test_path)
        health_result['checks']['delete'] = 'pass'
    except Exception as e:
        health_result['checks']['delete'] = f'fail: {e}'
        health_result['healthy'] = False

    # Calculate latency
    health_result['latency_ms'] = round((time.time() - start_time) * 1000, 2)

    return jsonify({
        'success': True,
        **health_result
    })


# =============================================================================
# File Browsing
# =============================================================================

@storage_bp.route('/files', methods=['GET'])
@login_required
@require_role('Admin')
def list_storage_files():
    """
    List files in storage.

    Query params:
        - prefix: Filter by path prefix (default: '')
        - limit: Maximum files to return (default: 100)
    """
    manager = _get_storage_manager()
    if not manager:
        return jsonify({
            'success': False,
            'error': 'Storage module not available'
        }), 500

    prefix = request.args.get('prefix', '')
    limit = min(int(request.args.get('limit', 100)), 1000)

    # Security: Sanitize prefix
    prefix = prefix.replace('..', '').lstrip('/')

    try:
        files = manager.list_files(prefix)[:limit]

        return jsonify({
            'success': True,
            'prefix': prefix,
            'count': len(files),
            'files': [
                {
                    'path': f.path,
                    'size': f.size,
                    'content_type': f.content_type,
                    'last_modified': f.last_modified.isoformat() if f.last_modified else None,
                }
                for f in files
            ]
        })
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@storage_bp.route('/files/<path:file_path>', methods=['DELETE'])
@login_required
@require_role('Admin')
def delete_storage_file(file_path: str):
    """
    Delete a file from storage.

    Args:
        file_path: Path to the file to delete
    """
    manager = _get_storage_manager()
    if not manager:
        return jsonify({
            'success': False,
            'error': 'Storage module not available'
        }), 500

    # Security: Sanitize path
    file_path = file_path.replace('..', '').lstrip('/')

    try:
        if not manager.exists(file_path):
            return jsonify({
                'success': False,
                'error': 'File not found'
            }), 404

        result = manager.delete(file_path)

        logger.info(f"File deleted by {current_user.username}: {file_path}")

        return jsonify({
            'success': result,
            'path': file_path
        })
    except Exception as e:
        logger.error(f"Error deleting file {file_path}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# =============================================================================
# Storage Configuration (Read-only)
# =============================================================================

@storage_bp.route('/config', methods=['GET'])
@login_required
@require_role('Admin')
def get_storage_config():
    """
    Get current storage configuration from environment.

    Note: Sensitive values (keys, secrets) are masked.
    """
    import os

    config = {
        'backend': os.environ.get('STORAGE_BACKEND', 'local'),
        'path': os.environ.get('STORAGE_PATH', '(default)'),
        'compression': os.environ.get('STORAGE_COMPRESSION', 'false'),
        'encryption_enabled': bool(os.environ.get('STORAGE_ENCRYPTION_KEY')),
        's3': {
            'endpoint_url': os.environ.get('S3_ENDPOINT_URL', '(AWS default)') or '(AWS default)',
            'bucket': os.environ.get('S3_BUCKET', '(not configured)'),
            'region': os.environ.get('S3_REGION', 'us-east-1'),
            'use_ssl': os.environ.get('S3_USE_SSL', 'true'),
            'path_style': os.environ.get('S3_PATH_STYLE', 'false'),
            'prefix': os.environ.get('S3_PREFIX', '(none)') or '(none)',
            'credentials_configured': bool(
                os.environ.get('S3_ACCESS_KEY') and
                os.environ.get('S3_SECRET_KEY')
            ),
        }
    }

    return jsonify({
        'success': True,
        'config': config
    })


__all__ = ['storage_bp']
