#!/usr/bin/env python3
"""
Superadmin Script Review API

Read-only access to audit scripts for Admin and SuperAdmin users.
Does NOT allow editing, copying, or downloading scripts.

Author: Security Audit Toolkit Team
Date: February 13, 2026
"""

import os
import re
import json
import shutil
import subprocess  # nosec B404
from pathlib import Path
from flask import Blueprint, jsonify, request
from auth_core import require_auth_and_minimum_role
from config import logger, AUDITS_DIR, ROOT_DIR

# Create blueprint
superadmin_bp = Blueprint('superadmin', __name__, url_prefix='/api/superadmin')

# Base directory for audit scripts - use config.AUDITS_DIR for consistency
AUDITS_BASE_DIR = str(AUDITS_DIR)

# Log the path on module load for debugging
logger.info(f"[SuperAdmin] Audits directory: {AUDITS_BASE_DIR}")
logger.info(f"[SuperAdmin] Audits directory exists: {os.path.isdir(AUDITS_BASE_DIR)}")

# Allowed script extensions
ALLOWED_EXTENSIONS = {'.sh', '.ps1', '.py', '.bash'}
DIAGNOSTICS_BUNDLES_DIR = Path(ROOT_DIR) / 'diagnostics' / 'bundles'


def sanitize_path(path: str) -> str:
    """
    Sanitize and validate a script path to prevent directory traversal.

    Args:
        path: Relative path to script

    Returns:
        Absolute path if valid

    Raises:
        ValueError: If path is invalid or attempts traversal
    """
    if not path:
        raise ValueError("Script path is required")

    # Remove any null bytes
    path = path.replace('\x00', '')

    # Normalize path separators
    path = path.replace('\\', '/')

    # Remove leading slashes
    path = path.lstrip('/')

    # Check for directory traversal attempts
    if '..' in path or path.startswith('/'):
        raise ValueError("Invalid script path: directory traversal not allowed")

    # Build absolute path
    abs_path = os.path.abspath(os.path.join(AUDITS_BASE_DIR, path))

    # Verify path is within audits directory
    if not abs_path.startswith(AUDITS_BASE_DIR):
        raise ValueError("Invalid script path: outside audits directory")

    # Verify file exists
    if not os.path.isfile(abs_path):
        raise ValueError("Script not found")

    # Verify extension
    _, ext = os.path.splitext(abs_path)
    if ext.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Invalid file type: only {', '.join(ALLOWED_EXTENSIONS)} allowed")

    return abs_path


def get_script_metadata(script_path: str) -> dict:
    """
    Extract metadata from a script file.

    Args:
        script_path: Absolute path to script

    Returns:
        Dictionary with script metadata
    """
    metadata = {
        'name': os.path.basename(script_path),
        'path': os.path.relpath(script_path, AUDITS_BASE_DIR),
        'extension': os.path.splitext(script_path)[1],
        'size_bytes': os.path.getsize(script_path),
        'modified_at': os.path.getmtime(script_path),
    }

    # Try to extract description from script header
    try:
        with open(script_path, 'r', encoding='utf-8', errors='replace') as f:
            first_lines = f.read(2048)  # Read first 2KB

        # Look for description comment
        description_patterns = [
            r'#\s*Description:\s*(.+)',
            r'#\s*Purpose:\s*(.+)',
            r'<#\s*\.SYNOPSIS\s*\n\s*(.+?)(?:\n|#>)',  # PowerShell synopsis
        ]

        for pattern in description_patterns:
            match = re.search(pattern, first_lines, re.IGNORECASE)
            if match:
                metadata['description'] = match.group(1).strip()
                break
        else:
            metadata['description'] = None

    except Exception:
        metadata['description'] = None

    return metadata


def _resolve_powershell_executable() -> str | None:
    """Resolve PowerShell executable for running diagnostics script."""
    return shutil.which('pwsh') or shutil.which('powershell')


def _tail_lines(text: str, max_lines: int = 40) -> list[str]:
    """Return last N non-empty lines for concise API diagnostics output."""
    if not text:
        return []
    lines = [line for line in text.splitlines() if line.strip()]
    return lines[-max_lines:]


# ============================================================================
# Script Listing Endpoint
# ============================================================================

@superadmin_bp.route('/audits/scripts', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def list_audit_scripts():
    """
    List all audit scripts available for review.

    Query Parameters:
        category (str): Filter by category/folder (e.g., 'linux', 'windows')
        extension (str): Filter by extension (e.g., '.sh', '.ps1')
        search (str): Search in filename

    Returns:
        JSON: List of scripts with metadata
    """
    try:
        # Get filter parameters
        category_filter = request.args.get('category', '').strip()
        extension_filter = request.args.get('extension', '').strip().lower()
        search_filter = request.args.get('search', '').strip().lower()

        scripts = []
        categories = set()

        for root, dirs, files in os.walk(AUDITS_BASE_DIR):
            # Skip hidden directories and __pycache__
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']

            for filename in files:
                _, ext = os.path.splitext(filename)
                if ext.lower() not in ALLOWED_EXTENSIONS:
                    continue

                full_path = os.path.join(root, filename)
                rel_path = os.path.relpath(full_path, AUDITS_BASE_DIR)

                # Extract category (top-level folder)
                parts = rel_path.split(os.sep)
                category = parts[0] if len(parts) > 1 else 'root'
                categories.add(category)

                # Apply filters
                if category_filter and category.lower() != category_filter.lower():
                    continue
                if extension_filter and ext.lower() != extension_filter:
                    continue
                if search_filter and search_filter not in filename.lower():
                    continue

                scripts.append({
                    'name': filename,
                    'path': rel_path.replace(os.sep, '/'),
                    'category': category,
                    'extension': ext,
                    'size_bytes': os.path.getsize(full_path),
                })

        # Sort by category then name
        scripts.sort(key=lambda x: (x['category'], x['name']))

        return jsonify({
            'success': True,
            'scripts': scripts,
            'total': len(scripts),
            'categories': sorted(categories),
            'filters': {
                'category': category_filter or None,
                'extension': extension_filter or None,
                'search': search_filter or None,
            }
        })

    except Exception as e:
        logger.error(f"Error listing audit scripts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Script View Endpoint (DEPRECATED - Use /script-studio instead)
# ============================================================================

@superadmin_bp.route('/audits/scripts/view', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def view_script():
    """
    View the content of a specific script (read-only).

    DEPRECATED: This endpoint is deprecated. Use Developer Script Studio
    at /script-studio for an improved experience with syntax highlighting,
    validation, and editing capabilities (SuperAdmin only).

    Query Parameters:
        path (str): Relative path to script within audits/

    Returns:
        JSON: Script content and metadata

    Security:
        - Path traversal prevention
        - Read-only access (no modification endpoints exist)
        - Content is returned as JSON, not as downloadable file
    """
    # Log deprecation warning
    logger.warning("DEPRECATED: /api/superadmin/audits/scripts/view is deprecated. Use /script-studio instead.")

    script_path = request.args.get('path', '').strip()

    try:
        # Validate and sanitize path
        abs_path = sanitize_path(script_path)

        # Read script content
        with open(abs_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()

        # Get metadata
        metadata = get_script_metadata(abs_path)

        # Log access for audit trail
        from flask_login import current_user
        username = current_user.username if hasattr(current_user, 'username') else 'unknown'
        logger.info(f"Script viewed: {script_path} by {username}")

        return jsonify({
            'success': True,
            'script': {
                'content': content,
                'metadata': metadata,
                'line_count': content.count('\n') + 1,
            },
            'readonly': True,
            'message': 'This content is read-only and cannot be edited, copied, or downloaded.'
        })

    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400

    except Exception as e:
        logger.error(f"Error viewing script {script_path}: {e}")
        return jsonify({'success': False, 'error': 'Failed to read script'}), 500


# ============================================================================
# Categories Endpoint
# ============================================================================

@superadmin_bp.route('/audits/categories', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def list_categories():
    """
    List all script categories (top-level folders in audits/).

    Returns:
        JSON: List of categories with script counts
    """
    try:
        categories = {}

        for item in os.listdir(AUDITS_BASE_DIR):
            item_path = os.path.join(AUDITS_BASE_DIR, item)
            if os.path.isdir(item_path) and not item.startswith('.'):
                # Count scripts in category
                count = 0
                for root, _, files in os.walk(item_path):
                    count += sum(1 for f in files if os.path.splitext(f)[1].lower() in ALLOWED_EXTENSIONS)

                if count > 0:
                    categories[item] = {
                        'name': item,
                        'script_count': count,
                        'path': item,
                    }

        return jsonify({
            'success': True,
            'categories': list(categories.values()),
            'total': len(categories)
        })

    except Exception as e:
        logger.error(f"Error listing categories: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Script Tree Endpoint (for tree view UI)
# ============================================================================

@superadmin_bp.route('/audits/tree', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def get_script_tree():
    """
    Get hierarchical tree structure of audit scripts.

    Returns:
        JSON: Tree structure suitable for tree view component
        Format: {
            "children": {
                "linux": {
                    "children": {...},
                    "scripts": [{"name": "...", "path": "..."}]
                }
            },
            "scripts": []
        }
    """
    try:
        def build_tree(directory, parent_path=''):
            """Build tree in format expected by JavaScript."""
            result = {
                'children': {},
                'scripts': []
            }

            try:
                entries = sorted(os.listdir(directory))
            except PermissionError:
                return result

            for entry in entries:
                if entry.startswith('.') or entry == '__pycache__':
                    continue

                full_path = os.path.join(directory, entry)
                rel_path = os.path.join(parent_path, entry) if parent_path else entry

                if os.path.isdir(full_path):
                    child_tree = build_tree(full_path, rel_path)
                    # Only include if has scripts or children with scripts
                    if child_tree['scripts'] or child_tree['children']:
                        result['children'][entry] = child_tree
                else:
                    _, ext = os.path.splitext(entry)
                    if ext.lower() in ALLOWED_EXTENSIONS:
                        result['scripts'].append({
                            'name': entry,
                            'path': rel_path.replace(os.sep, '/'),
                            'extension': ext,
                        })

            return result

        logger.info(f"[SuperAdmin] Building tree from: {AUDITS_BASE_DIR}")
        logger.info(f"[SuperAdmin] Directory exists: {os.path.isdir(AUDITS_BASE_DIR)}")
        if os.path.isdir(AUDITS_BASE_DIR):
            try:
                contents = os.listdir(AUDITS_BASE_DIR)
                logger.info(f"[SuperAdmin] Directory contents: {contents}")
            except Exception as e:
                logger.error(f"[SuperAdmin] Error listing directory: {e}")

        tree = build_tree(AUDITS_BASE_DIR)
        child_count = len(tree.get('children', {}))
        script_count = len(tree.get('scripts', []))
        logger.info(f"[SuperAdmin] Tree: {child_count} children, {script_count} scripts")

        return jsonify({
            'success': True,
            'tree': tree,
        })

    except Exception as e:
        logger.error(f"Error building script tree: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# Self-Audit Endpoints
# ============================================================================

@superadmin_bp.route('/self-audit', methods=['GET'])
@require_auth_and_minimum_role('SuperAdmin')
def run_self_audit():
    """
    Run a comprehensive self-audit of the Security Audit Toolkit.

    Query Parameters:
        include_deps (bool): Include dependency vulnerability scan (default: true)

    Returns:
        JSON: Complete self-audit report including:
        - Version status and update availability
        - Dependency security scan results
        - Configuration validation
        - Database migration status
        - Git repository status
        - Audit script statistics
    """
    try:
        from self_audit import run_self_audit as execute_self_audit

        include_deps = request.args.get('include_deps', 'true').lower() == 'true'
        dependency_scan_timeout_seconds = 10

        logger.info(f"[SelfAudit] Running self-audit (include_deps={include_deps})")
        report = execute_self_audit(
            include_deps=include_deps,
            dependency_scan_timeout_seconds=dependency_scan_timeout_seconds,
        )

        return jsonify({
            'success': True,
            'report': report
        })

    except ImportError as e:
        logger.error(f"Self-audit module not found: {e}")
        return jsonify({
            'success': False,
            'error': 'Self-audit module not available'
        }), 500
    except Exception as e:
        logger.error(f"Self-audit failed: {e}")
        return jsonify({
            'success': False,
            'error': f'Self-audit failed: {str(e)}'
        }), 500


@superadmin_bp.route('/self-audit/quick', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def get_quick_status():
    """
    Get a quick status check of the toolkit.

    Returns:
        JSON: Quick status including version, commit, and operational status
    """
    try:
        from self_audit import get_quick_status as quick_status

        status = quick_status()

        return jsonify({
            'success': True,
            'status': status
        })

    except ImportError:
        return jsonify({
            'success': False,
            'error': 'Self-audit module not available'
        }), 500
    except Exception as e:
        logger.error(f"Quick status check failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@superadmin_bp.route('/self-audit/version', methods=['GET'])
@require_auth_and_minimum_role('Admin')
def check_version():
    """
    Check for toolkit updates from GitHub releases.

    Returns:
        JSON: Version comparison with latest release
    """
    try:
        from self_audit import check_for_updates

        version_info = check_for_updates()

        return jsonify({
            'success': True,
            'version': version_info
        })

    except ImportError:
        return jsonify({
            'success': False,
            'error': 'Self-audit module not available'
        }), 500
    except Exception as e:
        logger.error(f"Version check failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@superadmin_bp.route('/self-audit/dependencies', methods=['GET'])
@require_auth_and_minimum_role('SuperAdmin')
def scan_dependencies():
    """
    Scan Python dependencies for known vulnerabilities.

    Returns:
        JSON: Vulnerability scan results from pip-audit
    """
    try:
        from self_audit import scan_dependencies as run_dependency_scan
        dependency_scan_timeout_seconds = 10

        logger.info("[SelfAudit] Running dependency security scan")
        scan_result = run_dependency_scan(timeout_seconds=dependency_scan_timeout_seconds)

        return jsonify({
            'success': True,
            'scan': scan_result
        })

    except ImportError:
        return jsonify({
            'success': False,
            'error': 'Self-audit module not available'
        }), 500
    except Exception as e:
        logger.error(f"Dependency scan failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@superadmin_bp.route('/self-audit/config', methods=['GET'])
@require_auth_and_minimum_role('SuperAdmin')
def validate_configuration():
    """
    Validate application configuration.

    Returns:
        JSON: Configuration validation results
    """
    try:
        from self_audit import SelfAudit

        auditor = SelfAudit()
        config_result = auditor.validate_configuration()

        return jsonify({
            'success': True,
            'configuration': config_result
        })

    except ImportError:
        return jsonify({
            'success': False,
            'error': 'Self-audit module not available'
        }), 500
    except Exception as e:
        logger.error(f"Configuration validation failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================================================
# SuperAdmin Diagnostics Endpoints
# ============================================================================

@superadmin_bp.route('/diagnostics/run', methods=['POST'])
@require_auth_and_minimum_role('SuperAdmin')
def run_superadmin_diagnostics():
    """Run consolidated diagnostics and return bundle metadata for troubleshooting."""
    try:
        shell_executable = _resolve_powershell_executable()
        if not shell_executable:
            return jsonify({
                'success': False,
                'error': 'PowerShell executable not found (pwsh or powershell)'
            }), 500

        script_path = Path(ROOT_DIR) / 'run-diagnostic-mode.ps1'
        if not script_path.exists():
            return jsonify({
                'success': False,
                'error': f'Diagnostics script not found: {script_path}'
            }), 500

        payload = request.get_json(silent=True) or {}
        core_url = payload.get('core_url', 'http://localhost:5000')
        discovery_url = payload.get('discovery_url', 'http://localhost:8080')
        api_key = payload.get('api_key', '')
        windows_target = payload.get('windows_target', '')
        linux_target = payload.get('linux_target', '')
        timeout_seconds = int(payload.get('timeout_seconds', 1800))
        timeout_seconds = max(60, min(timeout_seconds, 3600))

        command = [
            shell_executable,
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', str(script_path),
            '-CoreUrl', str(core_url),
            '-DiscoveryUrl', str(discovery_url)
        ]

        if api_key:
            command.extend(['-ApiKey', str(api_key)])
        if windows_target:
            command.extend(['-WindowsTarget', str(windows_target)])
        if linux_target:
            command.extend(['-LinuxTarget', str(linux_target)])

        result = subprocess.run(
            command,
            cwd=str(ROOT_DIR),
            capture_output=True,
            text=True,
            timeout=timeout_seconds
        )  # nosec B603

        bundle_dir = None
        summary_path = None
        zip_path = None

        for line in result.stdout.splitlines():
            if line.startswith('DIAG_BUNDLE_DIR='):
                bundle_dir = line.split('=', 1)[1].strip()
            elif line.startswith('DIAG_SUMMARY_PATH='):
                summary_path = line.split('=', 1)[1].strip()
            elif line.startswith('DIAG_ZIP_PATH='):
                zip_path = line.split('=', 1)[1].strip()

        summary_data = None
        if summary_path and os.path.isfile(summary_path):
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
            except Exception as summary_error:
                logger.warning(f'Failed to read diagnostics summary file: {summary_error}')

        gate_status = 'PASS' if result.returncode == 0 else ('WARN' if result.returncode == 1 else 'FAIL')

        return jsonify({
            'success': True,
            'diagnostic_exit_code': result.returncode,
            'gate_status': gate_status,
            'bundle_dir': bundle_dir,
            'summary_path': summary_path,
            'zip_path': zip_path,
            'summary': summary_data,
            'stdout_tail': _tail_lines(result.stdout),
            'stderr_tail': _tail_lines(result.stderr)
        })

    except subprocess.TimeoutExpired:
        return jsonify({
            'success': False,
            'error': 'Diagnostics run timed out'
        }), 504
    except Exception as e:
        logger.error(f'SuperAdmin diagnostics run failed: {e}')
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@superadmin_bp.route('/diagnostics/bundles', methods=['GET'])
@require_auth_and_minimum_role('SuperAdmin')
def list_diagnostics_bundles():
    """List available diagnostic bundles generated by diagnostic mode."""
    try:
        DIAGNOSTICS_BUNDLES_DIR.mkdir(parents=True, exist_ok=True)

        directory_bundles = []
        zip_bundles = []

        for item in sorted(DIAGNOSTICS_BUNDLES_DIR.iterdir(), key=lambda path: path.stat().st_mtime, reverse=True):
            item_data = {
                'name': item.name,
                'path': str(item),
                'modified_at': item.stat().st_mtime,
                'size_bytes': item.stat().st_size
            }
            if item.is_dir():
                directory_bundles.append(item_data)
            elif item.suffix.lower() == '.zip':
                zip_bundles.append(item_data)

        return jsonify({
            'success': True,
            'bundles_directory': str(DIAGNOSTICS_BUNDLES_DIR),
            'directories': directory_bundles,
            'archives': zip_bundles
        })

    except Exception as e:
        logger.error(f'Failed listing diagnostics bundles: {e}')
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
