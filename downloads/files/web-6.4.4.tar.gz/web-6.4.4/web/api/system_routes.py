"""
System Routes - Health, Status, Logs, Settings, Authentication

Provides endpoints for:
- Health checks (/health)
- Execution status (/api/status)
- Authentication (/api/auth)
- Log file access (/api/logs, /api/logs/<path>, /api/logs/<path>/tail)
- Settings management (/api/settings, /api/settings/test-email, /api/settings/api-key)
"""

import json
import secrets
import os  # <-- Fixed: missing import
from datetime import datetime
from flask import Blueprint, jsonify, request, Response, stream_with_context, session

# Import from config
from config import logger, LOGS_DIR, ROOT_DIR, PLANS_DIR, SERVERS_DIR, ORCHESTRATOR_PATH

# Import auth decorators
from auth_core import require_api_key, require_auth, conditional_limit, get_api_key_manager, require_auth_and_permission

# Import validators
from validators import validate_filename, validate_path

# Import encryption (for SMTP passwords)
from encryption import password_manager

# Import health checks
from health import comprehensive_health_check, readiness_check, generate_prometheus_metrics
from version_info import get_toolkit_version

system_bp = Blueprint('system', __name__)

# =============================================================================
# Global State (should be injected by main app)
# =============================================================================
execution_state = {}
deployment_state = {}
app_start_time = None
API_KEY = None
API_KEY_FILE = None
ENCRYPTION_AVAILABLE = True
def init_system_routes(exec_state, deploy_state, start_time, api_key, api_key_file):
    global execution_state, deployment_state, app_start_time, API_KEY, API_KEY_FILE
    execution_state = exec_state
    deployment_state = deploy_state
    app_start_time = start_time
    API_KEY = api_key
    API_KEY_FILE = api_key_file

    if API_KEY:
        try:
            api_key_manager = get_api_key_manager()
            api_key_manager.api_key = API_KEY
        except Exception as e:
            logger.warning(f"Could not synchronize auth_core API key manager during init: {e}")

# =============================================================================
# Health Check (minimal auth not required - used by monitoring systems)
# =============================================================================
@system_bp.route('/health')
def health_check():
    show_detailed = os.environ.get('HEALTH_DETAILED', 'false').lower() == 'true'
    # Quick mode skips slow external dependency checks (Redis, Celery)
    quick_mode = request.args.get('quick', 'false').lower() == 'true'

    # Runtime TLS policy diagnostics (for operator verification)
    try:
        from security_settings import get_security_setting
        tls_policy = {
            'strict_mode': bool(get_security_setting('tls_strict_mode', False)),
            'minimum_version_toolkit': str(get_security_setting('tls_minimum_version_toolkit', 'TLSv1_3')),
            'minimum_version_external': str(get_security_setting('tls_minimum_version_external', 'TLSv1_2')),
            'maximum_version': str(get_security_setting('tls_maximum_version', 'TLSv1_3')),
            'certificate_verification': bool(get_security_setting('tls_certificate_verification', True)),
            'log_tls_version': bool(get_security_setting('tls_log_version', True)),
        }
    except Exception:
        tls_policy = {
            'strict_mode': False,
            'minimum_version_toolkit': 'TLSv1_3',
            'minimum_version_external': 'TLSv1_2',
            'maximum_version': 'TLSv1_3',
            'certificate_verification': True,
            'log_tls_version': True,
        }

    health_data, status_code = comprehensive_health_check(
        check_dependencies=not quick_mode,
        include_system=show_detailed
    )

    # Add environment info for admin panel
    environment = os.environ.get('FLASK_ENV', os.environ.get('ENVIRONMENT', 'Development'))
    start_time_iso = app_start_time.isoformat() + 'Z' if app_start_time else None

    if not show_detailed:
        simplified = {
            "status": health_data.get("status", "unknown"),
            "timestamp": health_data.get("timestamp"),
            "version": health_data.get("version", get_toolkit_version(default='0.0.0')),
            "environment": environment,
            "start_time": start_time_iso,
            "uptime_seconds": health_data.get("uptime_seconds"),
            "checks": {},
            "tls_policy": tls_policy,
        }
        for check_name, check_data in health_data.get("checks", {}).items():
            if isinstance(check_data, dict):
                # Preserve essential fields for admin panel
                check_info = {"status": check_data.get("status", "unknown")}
                if check_name == "database" and "type" in check_data:
                    check_info["type"] = check_data["type"]
                if check_name == "celery" and "workers" in check_data:
                    check_info["workers"] = check_data["workers"]
                if check_name == "redis" and "latency_ms" in check_data:
                    check_info["latency_ms"] = check_data["latency_ms"]
                simplified["checks"][check_name] = check_info
        health_data = simplified
    else:
        health_data["environment"] = environment
        health_data["start_time"] = start_time_iso
        health_data["tls_policy"] = tls_policy
        health_data["checks"]["execution"] = {
            "status": "running" if execution_state.get("running") else "idle"
        }
        health_data["checks"]["deployment"] = {
            "status": "deploying" if deployment_state.get("deploying") else "idle"
        }
        dirs_ok = all([
            LOGS_DIR.exists(),
            PLANS_DIR.exists(),
            SERVERS_DIR.exists(),
            ORCHESTRATOR_PATH.exists()
        ])
        health_data["checks"]["filesystem"] = {
            "status": "ok" if dirs_ok else "error"
        }
    return jsonify(health_data), status_code

@system_bp.route('/ready')
def readiness_probe():
    readiness_data, status_code = readiness_check()
    readiness_data['execution_state'] = {
        'running': execution_state.get("running", False),
        'deploying': deployment_state.get("deploying", False)
    }
    if deployment_state.get("deploying"):
        readiness_data['ready'] = False
        readiness_data['reason'] = 'Deployment in progress'
        status_code = 503
    return jsonify(readiness_data), status_code

@system_bp.route('/metrics')
def prometheus_metrics():
    try:
        metrics_text = generate_prometheus_metrics()
        return Response(metrics_text, mimetype='text/plain; version=0.0.4')
    except Exception as e:
        logger.error(f"Failed to generate Prometheus metrics: {e}")
        return Response(f"# Error generating metrics: {str(e)}\n",
                       mimetype='text/plain',
                       status=500)

# =============================================================================
# Authentication
# =============================================================================
@system_bp.route('/api/auth', methods=['POST'])
@conditional_limit("5 per minute")
def authenticate():
    try:
        data = request.json
        provided_key = data.get('api_key')
        if not provided_key:
            return jsonify({"success": False, "error": "API key required"}), 400
        api_key_manager = get_api_key_manager()
        if api_key_manager.validate_key(provided_key):
            session['api_key'] = provided_key
            session.permanent = True
            logger.info(f"Successful authentication from {request.remote_addr}")
            return jsonify({"success": True, "message": "Authenticated successfully"})
        else:
            logger.warning(f"Failed authentication attempt from {request.remote_addr}")
            return jsonify({"success": False, "error": "Invalid API key"}), 403
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

# =============================================================================
# Execution Status
# =============================================================================
@system_bp.route('/api/status')
@require_api_key
def get_status():
    return jsonify({
        "success": True,
        "running": execution_state.get("running", False),
        "output": list(execution_state.get("output", [])),
        "summary": execution_state.get("summary", {}),
        "start_time": execution_state.get("start_time"),
        "log_file": execution_state.get("log_file"),
        "total_lines_in_memory": len(execution_state.get("output", []))
    })

# =============================================================================
# Log File Access
# =============================================================================
@system_bp.route('/api/logs')
@require_auth
def get_logs():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        if page < 1 or per_page < 1 or per_page > 100:
            return jsonify({"success": False, "error": "Invalid pagination parameters"}), 400
        all_logs = []
        if LOGS_DIR.exists():
            for log_file in LOGS_DIR.glob("*.log"):
                stat_info = log_file.stat()
                all_logs.append({
                    "name": log_file.name,
                    "path": str(log_file.relative_to(ROOT_DIR)),
                    "size": stat_info.st_size,
                    "modified": datetime.fromtimestamp(stat_info.st_mtime).isoformat()
                })
        all_logs.sort(key=lambda x: x["modified"], reverse=True)
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated = all_logs[start_idx:end_idx]
        return jsonify({
            "success": True,
            "logs": paginated,
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": len(all_logs),
                "pages": (len(all_logs) + per_page - 1) // per_page
            }
        })
    except ValueError:
        return jsonify({"success": False, "error": "Invalid pagination values"}), 400
    except Exception as e:
        logger.error(f"Error listing logs: {e}")
        return jsonify({"success": False, "error": "Failed to list logs"}), 500

@system_bp.route('/api/logs/<path:log_name>')
@require_auth
def get_log_content(log_name):
    try:
        if not validate_filename(log_name):
            logger.warning(f"Invalid log filename attempt: {log_name} from {request.remote_addr}")
            return jsonify({"success": False, "error": "Invalid log filename"}), 400

        log_path = LOGS_DIR / log_name

        if not validate_path(log_name, LOGS_DIR):
            logger.warning(f"Path traversal attempt: {log_name} from {request.remote_addr}")
            return jsonify({"success": False, "error": "Invalid log path"}), 400

        if not log_path.exists():
            return jsonify({"success": False, "error": "Log file not found"}), 404

        file_size = log_path.stat().st_size
        stream = request.args.get('stream') == 'true' or file_size > 10 * 1024 * 1024

        if stream:
            def generate():
                with open(log_path, 'r') as f:
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        yield chunk
            return Response(
                stream_with_context(generate()),
                mimetype='text/plain',
                headers={
                    'Content-Length': str(file_size),
                    'X-File-Size': str(file_size)
                }
            )
        else:
            content = log_path.read_text()
            return jsonify({
                "success": True,
                "content": content,
                "size": file_size
            })
    except Exception as e:
        logger.error(f"Error reading log {log_name}: {e}")
        return jsonify({"success": False, "error": "Failed to read log file"}), 500

@system_bp.route('/api/logs/<path:log_name>/tail')
@require_auth
def tail_log(log_name):
    try:
        if not validate_filename(log_name):
            return jsonify({"success": False, "error": "Invalid log filename"}), 400

        log_path = LOGS_DIR / log_name
        if not validate_path(log_name, LOGS_DIR):
            return jsonify({"success": False, "error": "Invalid log path"}), 400
        if not log_path.exists():
            return jsonify({"success": False, "error": "Log file not found"}), 404
        lines = int(request.args.get('lines', 100))
        if lines < 1 or lines > 10000:
            return jsonify({"success": False, "error": "Invalid line count (1-10000)"}), 400
        with open(log_path, 'r') as f:
            f.seek(0, 2)
            file_size = f.tell()
            read_size = min(file_size, 16384 * ((lines // 100) + 1))
            f.seek(max(0, file_size - read_size))
            last_lines = f.read().splitlines()[-lines:]
        return jsonify({
            "success": True,
            "lines": last_lines,
            "count": len(last_lines),
            "requested": lines
        })
    except ValueError:
        return jsonify({"success": False, "error": "Invalid line count"}), 400
    except Exception as e:
        logger.error(f"Error tailing log {log_name}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@system_bp.route('/api/logs/<path:log_name>', methods=['DELETE'])
@require_auth_and_permission('delete_all_data')
def delete_log(log_name):
    try:
        if not validate_filename(log_name):
            return jsonify({"success": False, "error": "Invalid log filename"}), 400
        log_path = LOGS_DIR / log_name
        if not validate_path(log_name, LOGS_DIR):
            return jsonify({"success": False, "error": "Invalid log path"}), 400
        if not log_path.exists():
            return jsonify({"success": False, "error": "Log file not found"}), 404
        log_path.unlink()
        logger.info(f"Deleted log file: {log_name}")
        return jsonify({"success": True, "message": f"Log '{log_name}' deleted"})
    except Exception as e:
        logger.error(f"Error deleting log {log_name}: {e}")
        return jsonify({"success": False, "error": "Failed to delete log file"}), 500

@system_bp.route('/api/logs/delete-batch', methods=['POST'])
@require_auth_and_permission('delete_all_data')
def delete_logs_batch():
    try:
        data = request.json or {}
        names = data.get('names', [])
        if not isinstance(names, list) or len(names) == 0:
            return jsonify({"success": False, "error": "No log names provided"}), 400
        deleted = []
        errors = []
        for log_name in names:
            if not isinstance(log_name, str):
                errors.append({"name": str(log_name), "error": "Invalid name type"})
                continue
            if not validate_filename(log_name):
                errors.append({"name": log_name, "error": "Invalid filename"})
                continue
            log_path = LOGS_DIR / log_name
            if not validate_path(log_name, LOGS_DIR):
                errors.append({"name": log_name, "error": "Invalid path"})
                continue
            if not log_path.exists():
                errors.append({"name": log_name, "error": "File not found"})
                continue
            try:
                log_path.unlink()
                deleted.append(log_name)
                logger.info(f"Batch deleted log file: {log_name}")
            except Exception as e:
                errors.append({"name": log_name, "error": str(e)})
        return jsonify({"success": True, "deleted": deleted, "errors": errors,
                        "deleted_count": len(deleted), "error_count": len(errors)})
    except Exception as e:
        logger.error(f"Error in batch log delete: {e}")
        return jsonify({"success": False, "error": "Failed to process batch delete"}), 500

# =============================================================================
# Settings Management
# =============================================================================
def load_settings():
    settings_file = ROOT_DIR / 'settings.json'
    if settings_file.exists():
        return json.loads(settings_file.read_text())
    return {}

def save_settings_data(settings):
    settings_file = ROOT_DIR / 'settings.json'
    settings_file.write_text(json.dumps(settings, indent=2))

@system_bp.route('/api/settings')
@require_auth
def get_settings():
    try:
        settings = load_settings()
        if 'email' in settings and 'smtp_password' in settings['email']:
            settings['email']['smtp_password'] = '••••••••'  # nosec B105 - redaction mask only
        return jsonify(settings)
    except Exception as e:
        logger.error(f"Error loading settings: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@system_bp.route('/api/settings', methods=['POST'])
@require_auth
def save_settings():
    try:
        data = request.json
        settings = load_settings()
        settings.update(data)
        if ENCRYPTION_AVAILABLE and 'email' in data and 'smtp_password' in data['email']:
            password = data['email']['smtp_password']
            if password and password != '••••••••':  # nosec B105 - masked placeholder comparison
                encrypted = password_manager.encrypt_password(password)
                settings['email']['smtp_password_encrypted'] = encrypted
                settings['email']['smtp_password'] = None
        save_settings_data(settings)
        return jsonify({"success": True, "message": "Settings saved"})
    except Exception as e:
        logger.error(f"Error saving settings: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@system_bp.route('/api/settings/test-email', methods=['POST'])
@require_auth
def test_email():
    try:
        import smtplib
        from email.message import EmailMessage
        data = request.json
        msg = EmailMessage()
        msg['Subject'] = 'Security Audit Toolkit - Test Email'
        msg['From'] = data['from']
        msg['To'] = data['to']
        msg.set_content('This is a test email from Security Audit Toolkit. Email notifications are working correctly.')
        with smtplib.SMTP(data['host'], data['port']) as smtp:
            smtp.starttls()
            smtp.login(data['user'], data['password'])
            smtp.send_message(msg)
        return jsonify({"success": True, "message": "Test email sent"})
    except Exception as e:
        logger.error(f"Error sending test email: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@system_bp.route('/api/settings/api-key')
@require_auth
def get_api_key():
    try:
        api_key_manager = get_api_key_manager()
        active_api_key = api_key_manager.api_key
    except Exception:
        active_api_key = API_KEY

    return jsonify({"success": True, "api_key": active_api_key})

@system_bp.route('/api/settings/api-key', methods=['POST'])
@require_auth
def regenerate_api_key():
    global API_KEY
    try:
        new_key = secrets.token_urlsafe(32)

        # Maintain legacy file for backward compatibility
        if API_KEY_FILE:
            API_KEY_FILE.write_text(new_key)

        # Synchronize auth_core in-memory state and its key file
        api_key_manager = get_api_key_manager()
        api_key_manager.api_key = new_key
        api_key_manager.key_file.write_text(new_key)

        # Best-effort sync to encrypted keystore when available
        try:
            from keystore import get_keystore
            keystore = get_keystore()
            keystore.store_key(
                key_type='system',
                key_id='api_key',
                value=new_key,
                metadata={'rotated_by': 'system_routes.regenerate_api_key'}
            )
        except Exception as keystore_error:
            logger.debug(f"Skipping keystore API key sync: {keystore_error}")
        API_KEY = new_key
        return jsonify({"success": True, "api_key": new_key})
    except Exception as e:
        logger.error(f"Error regenerating API key: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# =============================================================================
# Debug Mode Management (Support Team Troubleshooting)
# =============================================================================

# In-memory debug state (persisted to settings.json)
_debug_state = {
    'server_debug': False,
    'client_debug': False,
    'sql_debug': False,
    'sse_debug': False,
    'wizard_debug': False,
    'log_level': 'INFO',
    'enabled_at': None,
    'auto_disable_minutes': 30
}

def _load_debug_state():
    """Load debug state from settings file"""
    global _debug_state
    try:
        settings = load_settings()
        if 'debug' in settings:
            _debug_state.update(settings['debug'])
    except Exception as e:
        logger.warning(f"Could not load debug state: {e}")

def _save_debug_state():
    """Save debug state to settings file"""
    try:
        settings = load_settings()
        settings['debug'] = _debug_state
        save_settings_data(settings)
    except Exception as e:
        logger.error(f"Could not save debug state: {e}")


@system_bp.route('/api/debug/status')
@require_api_key
def get_debug_status():
    """
    Get current debug configuration status

    Returns:
        JSON object with debug state for each component
    """
    _load_debug_state()

    # Check if auto-disable time has passed
    if _debug_state.get('enabled_at'):
        from datetime import datetime
        enabled_time = datetime.fromisoformat(_debug_state['enabled_at'])
        elapsed = (datetime.utcnow() - enabled_time).total_seconds() / 60
        auto_disable = _debug_state.get('auto_disable_minutes', 30)

        if elapsed > auto_disable:
            # Auto-disable debug mode
            _debug_state['server_debug'] = False
            _debug_state['client_debug'] = False
            _debug_state['sql_debug'] = False
            _debug_state['enabled_at'] = None
            _save_debug_state()
            logger.info("Debug mode auto-disabled after timeout")

    return jsonify({
        "success": True,
        "debug": {
            "server_debug": _debug_state.get('server_debug', False),
            "client_debug": _debug_state.get('client_debug', False),
            "sql_debug": _debug_state.get('sql_debug', False),
            "sse_debug": _debug_state.get('sse_debug', False),
            "wizard_debug": _debug_state.get('wizard_debug', False),
            "log_level": _debug_state.get('log_level', 'INFO'),
            "enabled_at": _debug_state.get('enabled_at'),
            "auto_disable_minutes": _debug_state.get('auto_disable_minutes', 30)
        }
    })


@system_bp.route('/api/debug/enable', methods=['POST'])
@require_api_key
def enable_debug():
    """
    Enable debug modes for troubleshooting

    Request body:
        {
            "server": true/false,   // Python/Flask debug logging
            "client": true/false,   // JavaScript console debug
            "sql": true/false,      // SQL query logging
            "sse": true/false,      // SSE stream debugging
            "wizard": true/false,   // Wizard workflow debugging
            "log_level": "DEBUG",   // Log level (optional)
            "auto_disable_minutes": 30  // Auto-disable timeout (optional)
        }
    """
    global _debug_state

    try:
        data = request.json or {}

        # Update debug state
        if 'server' in data:
            _debug_state['server_debug'] = bool(data['server'])
        if 'client' in data:
            _debug_state['client_debug'] = bool(data['client'])
        if 'sql' in data:
            _debug_state['sql_debug'] = bool(data['sql'])
        if 'sse' in data:
            _debug_state['sse_debug'] = bool(data['sse'])
        if 'wizard' in data:
            _debug_state['wizard_debug'] = bool(data['wizard'])
        if 'log_level' in data:
            valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
            if data['log_level'].upper() in valid_levels:
                _debug_state['log_level'] = data['log_level'].upper()
        if 'auto_disable_minutes' in data:
            _debug_state['auto_disable_minutes'] = max(5, min(120, int(data['auto_disable_minutes'])))

        # Record when debug was enabled
        any_debug = _debug_state['server_debug'] or _debug_state['client_debug'] or _debug_state['sql_debug']
        if any_debug:
            _debug_state['enabled_at'] = datetime.utcnow().isoformat()

        # Apply server-side log level change
        if _debug_state['server_debug'] or _debug_state['log_level'] == 'DEBUG':
            import logging
            logging.getLogger().setLevel(logging.DEBUG)
            logger.info("Debug logging enabled")

        _save_debug_state()

        logger.info(f"Debug mode updated: server={_debug_state['server_debug']}, "
                   f"client={_debug_state['client_debug']}, sql={_debug_state['sql_debug']}")

        return jsonify({
            "success": True,
            "message": "Debug mode enabled",
            "debug": _debug_state,
            "note": f"Debug will auto-disable in {_debug_state['auto_disable_minutes']} minutes"
        })

    except Exception as e:
        logger.error(f"Error enabling debug: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@system_bp.route('/api/debug/disable', methods=['POST'])
@require_api_key
def disable_debug():
    """
    Disable all debug modes and reset to production defaults
    """
    global _debug_state

    try:
        _debug_state = {
            'server_debug': False,
            'client_debug': False,
            'sql_debug': False,
            'sse_debug': False,
            'wizard_debug': False,
            'log_level': 'INFO',
            'enabled_at': None,
            'auto_disable_minutes': 30
        }

        # Reset server log level
        import logging
        logging.getLogger().setLevel(logging.INFO)

        _save_debug_state()

        logger.info("Debug mode disabled, reset to production defaults")

        return jsonify({
            "success": True,
            "message": "Debug mode disabled",
            "debug": _debug_state
        })

    except Exception as e:
        logger.error(f"Error disabling debug: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@system_bp.route('/api/debug/client-config')
def get_client_debug_config():
    """
    Get JavaScript debug configuration for frontend injection

    This endpoint returns the current debug flags that should be
    applied to the JavaScript console debugging.

    Note: No API key required - returns only boolean flags, no sensitive data
    """
    _load_debug_state()

    return jsonify({
        "WIZARD_DEBUG": _debug_state.get('wizard_debug', False) or _debug_state.get('client_debug', False),
        "SSE_DEBUG": _debug_state.get('sse_debug', False) or _debug_state.get('client_debug', False)
    })
