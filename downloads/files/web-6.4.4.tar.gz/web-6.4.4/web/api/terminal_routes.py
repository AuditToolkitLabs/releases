"""
Terminal Routes - Interactive SSH/WinRM Terminal for SuperAdmin
Provides WebSocket-based terminal sessions for remote server administration

Security:
- Feature must be explicitly enabled via TERMINAL_ENABLED config
- SuperAdmin role required
- Secondary authentication required (password re-entry)
- Terminal access token required for all API calls
- IP allowlisting support
- Command blacklist to prevent dangerous commands
- Rate limiting on authentication
- Time-based access control (business hours)
- All commands logged to audit trail
- Session recording for compliance/playback
- Session timeout after inactivity
"""

import os
import re
import json
import gzip
import logging
import threading
import subprocess  # nosec B404 - required for managed SSH terminal process execution
import queue
import time
import secrets
import hashlib
import ipaddress
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, current_app, session, g
from functools import wraps
from collections import defaultdict

try:
    import pytz
    PYTZ_AVAILABLE = True
except ImportError:
    PYTZ_AVAILABLE = False

# Get logger
logger = logging.getLogger(__name__)

# Import safe error response
from auth_core import safe_error_response

# Feature licensing imports
try:
    from web.services_pkg.services.feature_licensing import (
        Feature, require_feature, check_feature, get_feature_service
    )
    FEATURE_LICENSING_AVAILABLE = True
except ImportError:
    FEATURE_LICENSING_AVAILABLE = False
    def require_feature(feature):
        """Dummy decorator when feature licensing not available."""
        def decorator(f):
            return f
        return decorator
    def check_feature(feature):
        return True


def _current_feature_user_id():
    """Resolve the current user id in the shape expected by feature licensing."""
    try:
        from flask_login import current_user

        if current_user.is_authenticated:
            return str(current_user.id)
    except Exception:
        pass

    return session.get('user_id')


def _feature_denied_response(feature_status, feature_name=None):
    """Return a normalized feature-unavailable response payload."""
    payload = {
        'error': 'Feature not available',
        'code': 'FEATURE_UNAVAILABLE',
        'reason': feature_status.get('reason'),
        'trial_eligible': feature_status.get('trial_eligible', False),
        'upgrade_tier': feature_status.get('upgrade_tier'),
    }
    if feature_name:
        payload['feature'] = feature_name
    return jsonify(payload), 403


def _get_terminal_feature_status(protocol=None):
    """Resolve terminal tool access for a protocol or for the tool overall."""
    if not FEATURE_LICENSING_AVAILABLE:
        return {'available': True, 'feature': None}

    service = get_feature_service()
    user_id = _current_feature_user_id()

    if protocol and str(protocol).lower() in ('winrm', 'powershell', 'ps'):
        required_features = [Feature.WINRM_INTERACTIVE]
    elif protocol and str(protocol).lower() == 'ssh':
        required_features = [Feature.SSH_INTERACTIVE]
    else:
        required_features = [Feature.SSH_INTERACTIVE, Feature.WINRM_INTERACTIVE]

    denied_status = None
    for feature in required_features:
        feature_status = service.is_feature_available(feature, user_id)
        if feature_status.get('available'):
            feature_status['feature'] = feature.value
            return feature_status
        if denied_status is None:
            denied_status = feature_status

    if denied_status is None:
        denied_status = {
            'available': False,
            'reason': 'Feature not available',
            'trial_eligible': False,
            'upgrade_tier': None,
        }
    denied_status['feature'] = required_features[0].value if required_features else None
    return denied_status


def _ensure_terminal_tool_access(protocol=None):
    """Enforce licensing for the SuperAdmin terminal tool surface."""
    feature_status = _get_terminal_feature_status(protocol)
    if feature_status.get('available'):
        return None
    return _feature_denied_response(feature_status, feature_status.get('feature'))

# Create blueprint
terminal_bp = Blueprint('terminal', __name__, url_prefix='/api/terminal')

# Active terminal sessions (in-memory, could be moved to Redis for scaling)
active_sessions = {}

# Terminal access tokens (stored separately for additional security)
terminal_access_tokens = {}

# Rate limiting storage for terminal auth attempts
auth_attempt_tracker = defaultdict(list)

# Cache for database settings (avoid hitting DB on every request)
_db_settings_cache = {'settings': None, 'expires': None}
DB_SETTINGS_CACHE_TTL = 60  # Cache for 60 seconds


def get_db_settings():
    """Get terminal settings from database with caching"""
    now = datetime.utcnow()

    # Return cached settings if still valid
    if _db_settings_cache['settings'] and _db_settings_cache['expires'] and _db_settings_cache['expires'] > now:
        return _db_settings_cache['settings']

    try:
        from config import get_db_session
        from models.terminal import TerminalAccessSettings

        db = get_db_session()
        try:
            settings = TerminalAccessSettings.get_settings(db)
            settings_dict = settings.to_dict()

            # Cache the result
            _db_settings_cache['settings'] = settings_dict
            _db_settings_cache['expires'] = now + timedelta(seconds=DB_SETTINGS_CACHE_TTL)

            return settings_dict
        finally:
            db.close()
    except Exception as e:
        logger.warning(f"Failed to load DB settings, using env vars: {e}")
        return None


def invalidate_settings_cache():
    """Invalidate the settings cache when settings are updated"""
    _db_settings_cache['settings'] = None
    _db_settings_cache['expires'] = None


# Import config values (with defaults for safety)
def get_terminal_config():
    """Get terminal configuration values - DB settings take precedence over env vars"""
    # Try to get settings from database first
    db_settings = get_db_settings()

    try:
        from config import (
            TERMINAL_ENABLED, TERMINAL_ALLOWED_IPS, TERMINAL_COMMAND_BLACKLIST,
            TERMINAL_MAX_SESSIONS_PER_USER, TERMINAL_SESSION_TIMEOUT,
            TERMINAL_TOKEN_VALIDITY, TERMINAL_AUTH_RATE_LIMIT,
            TERMINAL_ACCESS_HOURS, TERMINAL_ACCESS_DAYS, TERMINAL_ACCESS_TIMEZONE,
            TERMINAL_RECORDING_ENABLED, TERMINAL_RECORDING_MAX_SIZE_MB,
            TERMINAL_RECORDING_RETENTION_DAYS
        )

        # DB settings take precedence if available
        if db_settings:
            return {
                'enabled': db_settings.get('terminal_enabled', TERMINAL_ENABLED),
                'allowed_ips': db_settings.get('allowed_ips') or TERMINAL_ALLOWED_IPS,
                'command_blacklist': (db_settings.get('command_blacklist') or '').split(',') if db_settings.get('command_blacklist') else TERMINAL_COMMAND_BLACKLIST,
                'max_sessions': db_settings.get('max_sessions', TERMINAL_MAX_SESSIONS_PER_USER),
                'session_timeout': db_settings.get('session_timeout_minutes', 30) * 60,
                'token_validity': db_settings.get('token_validity_minutes', 60) * 60,
                'auth_rate_limit': TERMINAL_AUTH_RATE_LIMIT,
                'access_hours': db_settings.get('access_hours') or TERMINAL_ACCESS_HOURS,
                'access_days': db_settings.get('access_days') or TERMINAL_ACCESS_DAYS,
                'access_timezone': db_settings.get('access_timezone') or TERMINAL_ACCESS_TIMEZONE,
                'recording_enabled': db_settings.get('recording_enabled', TERMINAL_RECORDING_ENABLED),
                'recording_max_size_mb': db_settings.get('recording_max_size_mb', TERMINAL_RECORDING_MAX_SIZE_MB),
                'recording_retention_days': db_settings.get('recording_retention_days', TERMINAL_RECORDING_RETENTION_DAYS),
                'require_secondary_auth': db_settings.get('require_secondary_auth', True),
                'profiles_enabled': db_settings.get('profiles_enabled', False),
                'profile_restrictions_enabled': db_settings.get('profile_restrictions_enabled', False),
                'idle_timeout': db_settings.get('idle_timeout_minutes', 15) * 60
            }

        # Fall back to env vars only
        return {
            'enabled': TERMINAL_ENABLED,
            'allowed_ips': TERMINAL_ALLOWED_IPS,
            'command_blacklist': TERMINAL_COMMAND_BLACKLIST,
            'max_sessions': TERMINAL_MAX_SESSIONS_PER_USER,
            'session_timeout': TERMINAL_SESSION_TIMEOUT,
            'token_validity': TERMINAL_TOKEN_VALIDITY,
            'auth_rate_limit': TERMINAL_AUTH_RATE_LIMIT,
            'access_hours': TERMINAL_ACCESS_HOURS,
            'access_days': TERMINAL_ACCESS_DAYS,
            'access_timezone': TERMINAL_ACCESS_TIMEZONE,
            'recording_enabled': TERMINAL_RECORDING_ENABLED,
            'recording_max_size_mb': TERMINAL_RECORDING_MAX_SIZE_MB,
            'recording_retention_days': TERMINAL_RECORDING_RETENTION_DAYS,
            'require_secondary_auth': True,
            'profiles_enabled': False,
            'profile_restrictions_enabled': False,
            'idle_timeout': 900
        }
    except ImportError:
        # Defaults if config not available
        return {
            'enabled': False,
            'allowed_ips': '',
            'command_blacklist': ['rm -rf /', 'mkfs', 'dd if=', 'format c:', 'shutdown'],
            'max_sessions': 3,
            'session_timeout': 1800,
            'token_validity': 3600,  # nosec B105 - token lifetime in seconds
            'auth_rate_limit': 5,
            'access_hours': '',
            'access_days': '',
            'access_timezone': 'UTC',
            'recording_enabled': True,
            'recording_max_size_mb': 50,
            'recording_retention_days': 90,
            'require_secondary_auth': True,
            'profiles_enabled': False,
            'profile_restrictions_enabled': False,
            'idle_timeout': 900
        }


def generate_terminal_token():
    """Generate a secure random token for terminal access"""
    return secrets.token_urlsafe(32)


def hash_token(token):
    """Hash token for storage comparison"""
    return hashlib.sha256(token.encode()).hexdigest()


def is_ip_allowed(client_ip):
    """Check if client IP is in the allowlist"""
    config = get_terminal_config()
    allowed_ips = config['allowed_ips']

    # If no allowlist configured, allow all
    if not allowed_ips:
        return True

    try:
        client = ipaddress.ip_address(client_ip)

        for entry in allowed_ips.split(','):
            entry = entry.strip()
            if not entry:
                continue

            try:
                # Try as network (CIDR notation)
                if '/' in entry:
                    network = ipaddress.ip_network(entry, strict=False)
                    if client in network:
                        return True
                else:
                    # Try as single IP
                    if client == ipaddress.ip_address(entry):
                        return True
            except ValueError:
                logger.warning(f"Invalid IP allowlist entry: {entry}")
                continue

        return False

    except ValueError as e:
        logger.error(f"Invalid client IP: {client_ip} - {e}")
        return False


def is_command_allowed(command):
    """Check if command is not in the blacklist"""
    config = get_terminal_config()
    blacklist = config['command_blacklist']

    command_lower = command.lower().strip()

    for blocked in blacklist:
        blocked = blocked.strip().lower()
        if blocked and blocked in command_lower:
            logger.warning(f"Blocked command attempted: {command}")
            return False

    return True


def check_rate_limit(user_id):
    """Check if user has exceeded auth rate limit"""
    config = get_terminal_config()
    rate_limit = config['auth_rate_limit']

    now = datetime.utcnow()
    window_start = now - timedelta(minutes=1)

    # Clean old attempts
    auth_attempt_tracker[user_id] = [
        ts for ts in auth_attempt_tracker[user_id]
        if ts > window_start
    ]

    # Check limit
    if len(auth_attempt_tracker[user_id]) >= rate_limit:
        return False

    # Record attempt
    auth_attempt_tracker[user_id].append(now)
    return True


def check_time_based_access():
    """
    Check if current time is within allowed access window.
    Returns (allowed, message) tuple.
    """
    config = get_terminal_config()
    access_hours = config.get('access_hours', '')
    access_days = config.get('access_days', '')
    timezone = config.get('access_timezone', 'UTC')

    # If no restrictions configured, allow access
    if not access_hours and not access_days:
        return True, None

    # Get current time in configured timezone
    try:
        if PYTZ_AVAILABLE:
            tz = pytz.timezone(timezone)
            now = datetime.now(tz)
        else:
            # Fallback to UTC if pytz not available
            now = datetime.utcnow()
            if timezone != 'UTC':
                logger.warning(f"pytz not installed, using UTC instead of {timezone}")
    except Exception as e:
        logger.error(f"Invalid timezone {timezone}: {e}")
        now = datetime.utcnow()

    # Check day of week
    if access_days:
        day_names = {
            0: 'mon', 1: 'tue', 2: 'wed', 3: 'thu',
            4: 'fri', 5: 'sat', 6: 'sun'
        }
        current_day = day_names.get(now.weekday(), '')
        allowed_days = [d.strip().lower()[:3] for d in access_days.split(',')]

        if current_day not in allowed_days:
            return False, f"Terminal access not allowed on {now.strftime('%A')}. Allowed days: {access_days}"

    # Check time of day
    if access_hours:
        try:
            # Parse format: "09:00-18:00"
            parts = access_hours.split('-')
            if len(parts) == 2:
                start_time = datetime.strptime(parts[0].strip(), '%H:%M').time()
                end_time = datetime.strptime(parts[1].strip(), '%H:%M').time()
                current_time = now.time()

                # Handle overnight windows (e.g., 22:00-06:00)
                if start_time <= end_time:
                    # Normal window (e.g., 09:00-18:00)
                    if not (start_time <= current_time <= end_time):
                        return False, f"Terminal access only allowed between {access_hours}. Current time: {current_time.strftime('%H:%M')}"
                else:
                    # Overnight window (e.g., 22:00-06:00)
                    if not (current_time >= start_time or current_time <= end_time):
                        return False, f"Terminal access only allowed between {access_hours}. Current time: {current_time.strftime('%H:%M')}"
        except ValueError as e:
            logger.error(f"Invalid access_hours format '{access_hours}': {e}")

    return True, None


def require_time_based_access(f):
    """Decorator to enforce time-based access control"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        allowed, message = check_time_based_access()
        if not allowed:
            logger.warning(f"Terminal access denied due to time restriction: {message}")
            return jsonify({
                'error': 'Access denied - outside allowed hours',
                'code': 'TIME_RESTRICTED',
                'message': message
            }), 403
        return f(*args, **kwargs)
    return decorated_function


def require_terminal_enabled(f):
    """Decorator to check if terminal feature is enabled"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        config = get_terminal_config()
        if not config['enabled']:
            logger.warning(f"Terminal feature disabled, access denied from {request.remote_addr}")
            return jsonify({
                'error': 'Remote Terminal feature is disabled',
                'code': 'TERMINAL_DISABLED',
                'message': 'This feature must be enabled by an administrator during deployment. Set TERMINAL_ENABLED=true in environment configuration.'
            }), 403
        return f(*args, **kwargs)
    return decorated_function


def require_allowed_ip(f):
    """Decorator to check if client IP is allowed"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = request.remote_addr

        if not is_ip_allowed(client_ip):
            logger.warning(f"Terminal access denied from non-allowed IP: {client_ip}")
            return jsonify({
                'error': 'Access denied from this IP address',
                'code': 'IP_NOT_ALLOWED'
            }), 403
        return f(*args, **kwargs)
    return decorated_function


def require_superadmin(f):
    """Decorator to require SuperAdmin role for terminal access"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            if current_user.role != 'SuperAdmin':
                logger.warning(f"Terminal access denied for user {current_user.username} with role {current_user.role}")
                return jsonify({'error': 'SuperAdmin role required for terminal access'}), 403
        except Exception as e:
            logger.error(f"Auth check failed: {e}")
            return jsonify({'error': 'Authentication check failed'}), 500
        return f(*args, **kwargs)
    return decorated_function


def require_terminal_token(f):
    """Decorator to require valid terminal access token"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            from flask_login import current_user

            # Get token from header or session
            token = request.headers.get('X-Terminal-Token') or session.get('terminal_access_token')

            if not token:
                logger.warning(f"Terminal access without token by {current_user.username}")
                return jsonify({
                    'error': 'Terminal access token required',
                    'code': 'TERMINAL_AUTH_REQUIRED'
                }), 403

            # Verify token
            user_id = current_user.id
            token_hash = hash_token(token)

            if user_id not in terminal_access_tokens:
                logger.warning(f"No terminal token registered for user {current_user.username}")
                return jsonify({
                    'error': 'Terminal access token invalid or expired',
                    'code': 'TERMINAL_AUTH_REQUIRED'
                }), 403

            stored_token = terminal_access_tokens[user_id]

            # Check token hash matches
            if stored_token['token_hash'] != token_hash:
                logger.warning(f"Invalid terminal token for user {current_user.username}")
                return jsonify({
                    'error': 'Terminal access token invalid',
                    'code': 'TERMINAL_AUTH_REQUIRED'
                }), 403

            # Check token not expired
            if datetime.utcnow() > stored_token['expires_at']:
                logger.warning(f"Expired terminal token for user {current_user.username}")
                del terminal_access_tokens[user_id]
                return jsonify({
                    'error': 'Terminal access token expired',
                    'code': 'TERMINAL_AUTH_REQUIRED'
                }), 403

        except Exception as e:
            logger.error(f"Terminal token check failed: {e}")
            return jsonify({'error': 'Terminal authentication check failed'}), 500
        return f(*args, **kwargs)
    return decorated_function


def log_terminal_command(username, server_id, command, protocol='ssh'):
    """Log terminal commands for audit trail"""
    try:
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'user': username,
            'server_id': server_id,
            'protocol': protocol,
            'command': command,
            'action': 'terminal_command'
        }
        logger.info(f"TERMINAL_AUDIT: {log_entry}")

        # Could also write to database audit table
        # AuditLog.create(log_entry)

    except Exception as e:
        logger.error(f"Failed to log terminal command: {e}")


class TerminalSession:
    """Manages an interactive terminal session"""

    def __init__(self, session_id, server_id, protocol, shell, sudo=False):
        self.session_id = session_id
        self.server_id = server_id
        self.protocol = protocol
        self.shell = shell
        self.sudo = sudo
        self.created_at = datetime.utcnow()
        self.last_activity = datetime.utcnow()
        self.process = None
        self.output_queue = queue.Queue()
        self.input_queue = queue.Queue()
        self.running = False
        self.error = None

    def start(self, server_config):
        """Start the terminal session"""
        self.running = True

        if self.protocol == 'ssh':
            self._start_ssh_session(server_config)
        elif self.protocol == 'winrm':
            self._start_winrm_session(server_config)
        else:
            self.error = f"Unknown protocol: {self.protocol}"
            self.running = False

    def _start_ssh_session(self, server_config):
        """Start an SSH session using subprocess"""
        try:
            hostname = server_config.get('hostname') or server_config.get('ip')
            port = server_config.get('port', 22)
            username = server_config.get('username', 'root')
            key_file = server_config.get('key_file')

            # Build SSH command
            ssh_cmd = ['ssh', '-tt']  # Force pseudo-terminal
            ssh_cmd.extend(['-o', 'StrictHostKeyChecking=no'])
            ssh_cmd.extend(['-o', 'UserKnownHostsFile=/dev/null'])
            ssh_cmd.extend(['-o', 'ConnectTimeout=10'])

            if key_file and os.path.exists(key_file):
                ssh_cmd.extend(['-i', key_file])

            ssh_cmd.extend(['-p', str(port)])
            ssh_cmd.append(f'{username}@{hostname}')

            # Append shell command if sudo
            if self.sudo:
                ssh_cmd.append('sudo -i')

            logger.info(f"Starting SSH session: {' '.join(ssh_cmd[:5])}...")

            # Start process (note: this is simplified, production would use pty)
            self.process = subprocess.Popen(  # nosec B603 - SSH command assembled from validated server configuration
                ssh_cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0
            )

            # Start output reader thread
            self._start_output_reader()

        except Exception as e:
            self.error = f"SSH connection failed: {str(e)}"
            self.running = False
            logger.error(f"SSH session error: {e}")

    def _start_winrm_session(self, server_config):
        """Start a WinRM session"""
        try:
            # WinRM sessions are typically command-based, not interactive
            # For now, we'll use a polling-based approach
            self.error = "WinRM interactive sessions require additional configuration"
            self.running = False

        except Exception as e:
            self.error = f"WinRM connection failed: {str(e)}"
            self.running = False
            logger.error(f"WinRM session error: {e}")

    def _start_output_reader(self):
        """Start thread to read process output"""
        def reader():
            try:
                while self.running and self.process:
                    data = self.process.stdout.read(1024)
                    if data:
                        self.output_queue.put(data.decode('utf-8', errors='replace'))
                    elif self.process.poll() is not None:
                        break
                    time.sleep(0.01)
            except Exception as e:
                logger.error(f"Output reader error: {e}")
            finally:
                self.running = False

        thread = threading.Thread(target=reader, daemon=True)
        thread.start()

    def send_input(self, data):
        """Send input to the terminal"""
        self.last_activity = datetime.utcnow()

        if self.process and self.process.stdin:
            try:
                self.process.stdin.write(data.encode())
                self.process.stdin.flush()
            except Exception as e:
                logger.error(f"Send input error: {e}")
                self.error = str(e)

    def get_output(self, timeout=0.1):
        """Get pending output from the terminal"""
        output = []
        try:
            while True:
                data = self.output_queue.get(timeout=timeout)
                output.append(data)
        except queue.Empty:
            pass
        return ''.join(output)

    def close(self):
        """Close the terminal session"""
        self.running = False
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()


# ============================================================================
# Terminal Authentication Endpoints
# ============================================================================

@terminal_bp.route('/authenticate', methods=['POST'])
@require_terminal_enabled
@require_allowed_ip
@require_time_based_access
@require_superadmin
def authenticate_terminal():
    """
    Secondary authentication for terminal access.
    Requires password re-entry to generate terminal access token.
    """
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session
    from models.user import User

    # Check rate limit
    if not check_rate_limit(current_user.id):
        logger.warning(f"Terminal auth rate limit exceeded for {current_user.username}")
        return jsonify({
            'error': 'Too many authentication attempts. Please wait a minute.',
            'code': 'RATE_LIMITED'
        }), 429

    data = request.get_json()
    password = data.get('password')

    if not password:
        return jsonify({'error': 'Password is required'}), 400

    # Verify password
    db = get_db_session()
    try:
        user = db.query(User).filter(User.id == current_user.id).first()

        if not user or not user.check_password(password):
            logger.warning(f"Terminal auth failed - invalid password for {current_user.username}")
            return jsonify({'error': 'Invalid password'}), 401

        # Generate terminal access token
        config = get_terminal_config()
        token = generate_terminal_token()
        token_hash = hash_token(token)
        expires_at = datetime.utcnow() + timedelta(seconds=config['token_validity'])

        # Store token (one per user)
        terminal_access_tokens[current_user.id] = {
            'token_hash': token_hash,
            'expires_at': expires_at,
            'created_at': datetime.utcnow(),
            'ip_address': request.remote_addr
        }

        # Also store in session for convenience
        session['terminal_access_token'] = token
        session['terminal_token_expires'] = expires_at.isoformat()

        logger.info(f"Terminal access granted to {current_user.username} from {request.remote_addr}")

        return jsonify({
            'success': True,
            'token': token,
            'expires_at': expires_at.isoformat(),
            'expires_in': config['token_validity']
        })

    except Exception as e:
        logger.error(f"Terminal authentication error: {e}")
        return jsonify({'error': 'Authentication failed'}), 500
    finally:
        db.close()


@terminal_bp.route('/authenticate/status', methods=['GET'])
@require_superadmin
def check_terminal_auth():
    """Check if user has valid terminal access token"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    user_id = current_user.id

    if user_id not in terminal_access_tokens:
        return jsonify({
            'authenticated': False,
            'message': 'No terminal access token'
        })

    stored_token = terminal_access_tokens[user_id]

    if datetime.utcnow() > stored_token['expires_at']:
        del terminal_access_tokens[user_id]
        return jsonify({
            'authenticated': False,
            'message': 'Terminal access token expired'
        })

    remaining = (stored_token['expires_at'] - datetime.utcnow()).total_seconds()

    return jsonify({
        'authenticated': True,
        'expires_at': stored_token['expires_at'].isoformat(),
        'remaining_seconds': int(remaining)
    })


@terminal_bp.route('/authenticate/revoke', methods=['POST'])
@require_superadmin
def revoke_terminal_auth():
    """Revoke terminal access token"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    user_id = current_user.id

    if user_id in terminal_access_tokens:
        del terminal_access_tokens[user_id]

    session.pop('terminal_access_token', None)
    session.pop('terminal_token_expires', None)

    logger.info(f"Terminal access revoked for {current_user.username}")

    return jsonify({'success': True, 'message': 'Terminal access revoked'})


# ============================================================================
# Terminal Session Endpoints
# ============================================================================

@terminal_bp.route('/sessions', methods=['POST'])
@require_terminal_enabled
@require_allowed_ip
@require_time_based_access
@require_superadmin
@require_terminal_token
def create_session():
    """Create a new terminal session - requires secondary authentication.

    Feature license requirements:
    - SSH sessions: Professional tier + SSH_INTERACTIVE feature
    - WinRM sessions: Professional tier + WINRM_INTERACTIVE feature
    """
    from flask_login import current_user
    from models.server import ServerManager

    # Check feature licensing based on protocol
    data = request.get_json() or {}
    protocol = data.get('protocol', 'ssh')

    denied_response = _ensure_terminal_tool_access(protocol)
    if denied_response:
        return denied_response

    # Check max sessions per user
    config = get_terminal_config()
    user_sessions = [s for s in active_sessions.values() if s['user_id'] == current_user.id]
    if len(user_sessions) >= config['max_sessions']:
        return jsonify({
            'error': f'Maximum concurrent sessions ({config["max_sessions"]}) reached',
            'code': 'MAX_SESSIONS_EXCEEDED'
        }), 429

    data = request.get_json()
    server_id = data.get('server_id')
    protocol = data.get('protocol', 'ssh')
    shell = data.get('shell', 'bash')
    sudo = data.get('sudo', False)

    if not server_id:
        return jsonify({'error': 'server_id is required'}), 400

    # Load server config
    server_manager = ServerManager()
    server = server_manager.get_server(server_id)

    if not server:
        return jsonify({'error': 'Server not found'}), 404

    # Create session
    session_id = f"{current_user.id}_{server_id}_{int(time.time())}"
    session = TerminalSession(session_id, server_id, protocol, shell, sudo)

    # Store session
    active_sessions[session_id] = {
        'session': session,
        'user_id': current_user.id,
        'username': current_user.username,
        'server_name': server.get('name', server_id)
    }

    # Start session in background
    session.start(server)

    if session.error:
        del active_sessions[session_id]
        return jsonify({'error': session.error}), 500

    logger.info(f"Terminal session created: {session_id} by {current_user.username}")
    log_terminal_command(current_user.username, server_id, f"[SESSION_START] Protocol: {protocol}, Shell: {shell}")

    return jsonify({
        'session_id': session_id,
        'server': server.get('name', server_id),
        'protocol': protocol,
        'status': 'connected'
    })


@terminal_bp.route('/sessions/<session_id>/input', methods=['POST'])
@require_terminal_enabled
@require_allowed_ip
@require_superadmin
@require_terminal_token
def send_input(session_id):
    """Send input to a terminal session"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    if session_id not in active_sessions:
        return jsonify({'error': 'Session not found'}), 404

    session_data = active_sessions[session_id]

    # Verify session ownership
    if session_data['user_id'] != current_user.id:
        return jsonify({'error': 'Access denied'}), 403

    session = session_data['session']
    data = request.get_json()
    input_data = data.get('input', '')

    if input_data:
        # Check command against blacklist when command is submitted (newline)
        if '\n' in input_data or '\r' in input_data:
            cmd = input_data.strip()
            if cmd and not is_command_allowed(cmd):
                logger.warning(f"Blocked command from {current_user.username}: {cmd}")
                return jsonify({
                    'error': 'This command is blocked by security policy',
                    'code': 'COMMAND_BLOCKED'
                }), 403

        session.send_input(input_data)

        # Log command if it ends with newline
        if '\n' in input_data or '\r' in input_data:
            cmd = input_data.strip()
            if cmd:
                log_terminal_command(
                    current_user.username,
                    session.server_id,
                    cmd,
                    session.protocol
                )

    return jsonify({'status': 'ok'})


@terminal_bp.route('/sessions/<session_id>/output', methods=['GET'])
@require_superadmin
@require_terminal_token
def get_output(session_id):
    """Get output from a terminal session (polling endpoint)"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    if session_id not in active_sessions:
        return jsonify({'error': 'Session not found'}), 404

    session_data = active_sessions[session_id]

    # Verify session ownership
    if session_data['user_id'] != current_user.id:
        return jsonify({'error': 'Access denied'}), 403

    session = session_data['session']
    output = session.get_output()

    return jsonify({
        'output': output,
        'running': session.running,
        'error': session.error
    })


@terminal_bp.route('/sessions/<session_id>', methods=['DELETE'])
@require_superadmin
@require_terminal_token
def close_session(session_id):
    """Close a terminal session"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    if session_id not in active_sessions:
        return jsonify({'error': 'Session not found'}), 404

    session_data = active_sessions[session_id]

    # Verify session ownership (SuperAdmin can close any session)
    if session_data['user_id'] != current_user.id and current_user.role != 'SuperAdmin':
        return jsonify({'error': 'Access denied'}), 403

    session = session_data['session']
    session.close()

    log_terminal_command(
        current_user.username,
        session.server_id,
        '[SESSION_END]',
        session.protocol
    )

    del active_sessions[session_id]

    logger.info(f"Terminal session closed: {session_id}")

    return jsonify({'status': 'closed'})


@terminal_bp.route('/sessions', methods=['GET'])
@require_superadmin
@require_terminal_token
def list_sessions():
    """List active terminal sessions (SuperAdmin only)"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user

    sessions = []
    for session_id, data in active_sessions.items():
        sessions.append({
            'session_id': session_id,
            'user': data['username'],
            'server': data['server_name'],
            'protocol': data['session'].protocol,
            'created_at': data['session'].created_at.isoformat(),
            'last_activity': data['session'].last_activity.isoformat(),
            'running': data['session'].running
        })

    return jsonify({'sessions': sessions})


@terminal_bp.route('/status', methods=['GET'])
@require_superadmin
def get_terminal_status():
    """Get terminal feature status and configuration (non-sensitive details)"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    config = get_terminal_config()

    # Check time-based access
    time_allowed, time_message = check_time_based_access()

    return jsonify({
        'enabled': config['enabled'],
        'ip_restriction': bool(config['allowed_ips']),
        'time_restriction': bool(config.get('access_hours') or config.get('access_days')),
        'time_access_allowed': time_allowed,
        'time_access_message': time_message,
        'max_sessions': config['max_sessions'],
        'session_timeout': config['session_timeout'],
        'token_validity': config['token_validity'],
        'has_command_blacklist': len(config['command_blacklist']) > 0,
        'recording_enabled': config.get('recording_enabled', True)
    })


@terminal_bp.route('/config', methods=['GET'])
@require_terminal_enabled
@require_superadmin
def get_terminal_config_details():
    """Get full terminal configuration (SuperAdmin only)"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    config = get_terminal_config()

    # Check time-based access
    time_allowed, time_message = check_time_based_access()

    return jsonify({
        'enabled': config['enabled'],
        'allowed_ips': config['allowed_ips'] or '(all IPs allowed)',
        'command_blacklist': config['command_blacklist'],
        'max_sessions': config['max_sessions'],
        'session_timeout': config['session_timeout'],
        'token_validity': config['token_validity'],
        'auth_rate_limit': config['auth_rate_limit'],
        'access_hours': config.get('access_hours') or '(24/7)',
        'access_days': config.get('access_days') or '(all days)',
        'access_timezone': config.get('access_timezone', 'UTC'),
        'time_access_allowed': time_allowed,
        'time_access_message': time_message,
        'recording_enabled': config.get('recording_enabled', True),
        'recording_max_size_mb': config.get('recording_max_size_mb', 50),
        'recording_retention_days': config.get('recording_retention_days', 90),
        'require_secondary_auth': config.get('require_secondary_auth', True),
        'profiles_enabled': config.get('profiles_enabled', False),
        'profile_restrictions_enabled': config.get('profile_restrictions_enabled', False),
        'idle_timeout': config.get('idle_timeout', 900),
        'active_sessions': len(active_sessions),
        'active_tokens': len(terminal_access_tokens)
    })


# ============================================================================
# Settings Management (SuperAdmin UI Configuration)
# ============================================================================

@terminal_bp.route('/settings', methods=['GET'])
@require_terminal_enabled
@require_superadmin
def get_terminal_settings():
    """Get all terminal settings for admin UI"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    try:
        from config import get_db_session
        from models.terminal import TerminalAccessSettings

        db = get_db_session()
        try:
            settings = TerminalAccessSettings.get_settings(db)
            return jsonify({
                'success': True,
                'settings': settings.to_dict()
            })
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Failed to get terminal settings: {e}")
        return safe_error_response(e, custom_message="Failed to get terminal settings")


@terminal_bp.route('/settings', methods=['PUT'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def update_terminal_settings():
    """Update terminal settings (SuperAdmin only)"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    db = None
    try:
        from config import get_db_session
        from models.terminal import TerminalAccessSettings
        from flask_login import current_user

        data = request.get_json() or {}

        db = get_db_session()
        settings = TerminalAccessSettings.get_settings(db)

        # Update access hours
        if 'access_hours_start' in data:
            # Validate HH:MM format
            start = data['access_hours_start'].strip()
            if start and not re.match(r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$', start):
                return jsonify({'error': 'Invalid start time format. Use HH:MM'}), 400
            settings.access_hours_start = start or None

        if 'access_hours_end' in data:
            end = data['access_hours_end'].strip()
            if end and not re.match(r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$', end):
                return jsonify({'error': 'Invalid end time format. Use HH:MM'}), 400
            settings.access_hours_end = end or None

        # Update access days
        if 'access_days' in data:
            days = data['access_days'].strip().lower()
            if days:
                valid_days = {'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'}
                provided_days = set(d.strip() for d in days.split(','))
                if not provided_days.issubset(valid_days):
                    return jsonify({'error': 'Invalid days. Use: mon,tue,wed,thu,fri,sat,sun'}), 400
            settings.access_days = days or None

        # Update timezone
        if 'access_timezone' in data:
            tz = data['access_timezone'].strip()
            if tz and PYTZ_AVAILABLE:
                try:
                    pytz.timezone(tz)
                except Exception:
                    return jsonify({'error': f'Invalid timezone: {tz}'}), 400
            settings.access_timezone = tz or 'UTC'

        # Update feature toggles
        if 'terminal_enabled' in data:
            settings.terminal_enabled = bool(data['terminal_enabled'])
        if 'recording_enabled' in data:
            settings.recording_enabled = bool(data['recording_enabled'])
        if 'profiles_enabled' in data:
            settings.profiles_enabled = bool(data['profiles_enabled'])
        if 'profile_restrictions_enabled' in data:
            settings.profile_restrictions_enabled = bool(data['profile_restrictions_enabled'])
        if 'require_secondary_auth' in data:
            settings.require_secondary_auth = bool(data['require_secondary_auth'])

        # Update limits
        if 'max_sessions' in data:
            max_sess = int(data['max_sessions'])
            if max_sess < 1 or max_sess > 20:
                return jsonify({'error': 'Max sessions must be between 1 and 20'}), 400
            settings.max_sessions = max_sess

        if 'session_timeout_minutes' in data:
            timeout = int(data['session_timeout_minutes'])
            if timeout < 5 or timeout > 480:
                return jsonify({'error': 'Session timeout must be between 5 and 480 minutes'}), 400
            settings.session_timeout_minutes = timeout

        if 'idle_timeout_minutes' in data:
            idle = int(data['idle_timeout_minutes'])
            if idle < 1 or idle > 60:
                return jsonify({'error': 'Idle timeout must be between 1 and 60 minutes'}), 400
            settings.idle_timeout_minutes = idle

        if 'token_validity_minutes' in data:
            token = int(data['token_validity_minutes'])
            if token < 5 or token > 120:
                return jsonify({'error': 'Token validity must be between 5 and 120 minutes'}), 400
            settings.token_validity_minutes = token

        # Update security settings
        if 'allowed_ips' in data:
            ips = data['allowed_ips'].strip()
            if ips:
                # Validate each IP/CIDR
                for ip_str in ips.split(','):
                    ip_str = ip_str.strip()
                    if ip_str:
                        try:
                            if '/' in ip_str:
                                ipaddress.ip_network(ip_str, strict=False)
                            else:
                                ipaddress.ip_address(ip_str)
                        except ValueError:
                            return jsonify({'error': f'Invalid IP address: {ip_str}'}), 400
            settings.allowed_ips = ips or None

        if 'command_blacklist' in data:
            settings.command_blacklist = data['command_blacklist'].strip() or None

        # Update recording settings
        if 'recording_max_size_mb' in data:
            size = int(data['recording_max_size_mb'])
            if size < 1 or size > 500:
                return jsonify({'error': 'Recording max size must be between 1 and 500 MB'}), 400
            settings.recording_max_size_mb = size

        if 'recording_retention_days' in data:
            days = int(data['recording_retention_days'])
            if days < 1 or days > 365:
                return jsonify({'error': 'Recording retention must be between 1 and 365 days'}), 400
            settings.recording_retention_days = days

        # Track who made the change
        settings.updated_by_id = current_user.id
        settings.updated_at = datetime.utcnow()

        db.commit()

        # Invalidate the settings cache so changes take effect immediately
        invalidate_settings_cache()

        logger.info(f"Terminal settings updated by {current_user.username}")

        return jsonify({
            'success': True,
            'message': 'Settings updated successfully',
            'settings': settings.to_dict()
        })

    except ValueError as e:
        return jsonify({'error': f'Invalid value: {e}'}), 400
    except Exception as e:
        logger.error(f"Failed to update terminal settings: {e}")
        if db:
            db.rollback()
        return safe_error_response(e, custom_message="Failed to update terminal settings")
    finally:
        if db:
            db.close()


def init_terminal_routes(app):
    """Initialize terminal routes with app context"""
    pass  # No special initialization needed


def cleanup_inactive_sessions():
    """Cleanup sessions that have been inactive for too long"""
    now = datetime.utcnow()
    to_remove = []

    for session_id, data in active_sessions.items():
        session = data['session']
        inactive_seconds = (now - session.last_activity).total_seconds()
        config = get_terminal_config()
        if inactive_seconds > config['session_timeout'] or not session.running:
            session.close()
            to_remove.append(session_id)
            logger.info(f"Cleaned up inactive session: {session_id}")

    for session_id in to_remove:
        del active_sessions[session_id]


# ============================================================================
# Connection Profiles Endpoints
# ============================================================================

@terminal_bp.route('/profiles', methods=['GET'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def list_connection_profiles():
    """List saved connection profiles for quick terminal access"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    db = get_db_session()
    try:
        # Get user's own profiles + shared profiles
        profiles = db.query(TerminalConnectionProfile).filter(
            (TerminalConnectionProfile.created_by_id == current_user.id) |
            (TerminalConnectionProfile.is_shared.is_(True))
        ).order_by(TerminalConnectionProfile.name).all()

        return jsonify({
            'profiles': [p.to_dict() for p in profiles],
            'count': len(profiles)
        })
    except Exception as e:
        logger.error(f"Error listing connection profiles: {e}")
        return jsonify({'error': 'Failed to list profiles'}), 500
    finally:
        db.close()


@terminal_bp.route('/profiles', methods=['POST'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def create_connection_profile():
    """Create a new connection profile"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    data = request.get_json()

    # Validate required fields
    required = ['name', 'hostname', 'username']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required'}), 400

    db = get_db_session()
    try:
        # Check for duplicate name
        existing = db.query(TerminalConnectionProfile).filter_by(name=data['name']).first()
        if existing:
            return jsonify({'error': 'Profile with this name already exists'}), 409

        # Encrypt password if provided
        password_encrypted = None
        if data.get('password'):
            try:
                from encryption import encrypt_data
                password_encrypted = encrypt_data(data['password'])
            except Exception as e:
                logger.error(f"Failed to encrypt password: {e}")
                return jsonify({'error': 'Failed to encrypt credentials'}), 500

        profile = TerminalConnectionProfile(
            name=data['name'],
            description=data.get('description'),
            hostname=data['hostname'],
            port=data.get('port', 22),
            protocol=data.get('protocol', 'ssh'),
            username=data['username'],
            password_encrypted=password_encrypted,
            ssh_key_path=data.get('ssh_key_path'),
            use_sudo=data.get('use_sudo', False),
            default_shell=data.get('default_shell', 'bash'),
            connection_timeout=data.get('connection_timeout', 30),
            jump_host=data.get('jump_host'),
            jump_port=data.get('jump_port', 22),
            jump_username=data.get('jump_username'),
            created_by_id=current_user.id,
            is_shared=data.get('is_shared', False),
            tags=json.dumps(data.get('tags', [])) if data.get('tags') else None,
            environment=data.get('environment'),
            # Per-profile access restrictions
            access_hours_start=data.get('access_hours_start'),
            access_hours_end=data.get('access_hours_end'),
            access_days=data.get('access_days')
        )

        db.add(profile)
        db.commit()

        logger.info(f"Connection profile '{profile.name}' created by {current_user.username}")

        return jsonify({
            'success': True,
            'profile': profile.to_dict()
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating connection profile: {e}")
        return jsonify({'error': 'Failed to create profile'}), 500
    finally:
        db.close()


@terminal_bp.route('/profiles/<int:profile_id>', methods=['GET'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def get_connection_profile(profile_id):
    """Get a specific connection profile"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    db = get_db_session()
    try:
        profile = db.query(TerminalConnectionProfile).filter_by(id=profile_id).first()

        if not profile:
            return jsonify({'error': 'Profile not found'}), 404

        # Check access rights
        if profile.created_by_id != current_user.id and not profile.is_shared:
            return jsonify({'error': 'Access denied'}), 403

        return jsonify({'profile': profile.to_dict(include_sensitive=True)})

    except Exception as e:
        logger.error(f"Error getting profile {profile_id}: {e}")
        return jsonify({'error': 'Failed to get profile'}), 500
    finally:
        db.close()


@terminal_bp.route('/profiles/<int:profile_id>', methods=['PUT'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def update_connection_profile(profile_id):
    """Update a connection profile"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    data = request.get_json()

    db = get_db_session()
    try:
        profile = db.query(TerminalConnectionProfile).filter_by(id=profile_id).first()

        if not profile:
            return jsonify({'error': 'Profile not found'}), 404

        # Only creator can update
        if profile.created_by_id != current_user.id:
            return jsonify({'error': 'Only the creator can update this profile'}), 403

        # Update fields
        updatable = [
            'name', 'description', 'hostname', 'port', 'protocol', 'username',
            'ssh_key_path', 'use_sudo', 'default_shell', 'connection_timeout',
            'jump_host', 'jump_port', 'jump_username', 'is_shared', 'environment',
            # Per-profile access restrictions
            'access_hours_start', 'access_hours_end', 'access_days'
        ]

        for field in updatable:
            if field in data:
                setattr(profile, field, data[field])

        if 'tags' in data:
            profile.tags = json.dumps(data['tags']) if data['tags'] else None

        # Update password if provided
        if data.get('password'):
            try:
                from encryption import encrypt_data
                profile.password_encrypted = encrypt_data(data['password'])
            except Exception as e:
                logger.error(f"Failed to encrypt password: {e}")

        db.commit()

        logger.info(f"Connection profile '{profile.name}' updated by {current_user.username}")

        return jsonify({
            'success': True,
            'profile': profile.to_dict()
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating profile {profile_id}: {e}")
        return jsonify({'error': 'Failed to update profile'}), 500
    finally:
        db.close()


@terminal_bp.route('/profiles/<int:profile_id>', methods=['DELETE'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def delete_connection_profile(profile_id):
    """Delete a connection profile"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    db = get_db_session()
    try:
        profile = db.query(TerminalConnectionProfile).filter_by(id=profile_id).first()

        if not profile:
            return jsonify({'error': 'Profile not found'}), 404

        # Only creator can delete
        if profile.created_by_id != current_user.id:
            return jsonify({'error': 'Only the creator can delete this profile'}), 403

        profile_name = profile.name
        db.delete(profile)
        db.commit()

        logger.info(f"Connection profile '{profile_name}' deleted by {current_user.username}")

        return jsonify({'success': True, 'message': f'Profile "{profile_name}" deleted'})

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting profile {profile_id}: {e}")
        return jsonify({'error': 'Failed to delete profile'}), 500
    finally:
        db.close()


@terminal_bp.route('/profiles/<int:profile_id>/connect', methods=['POST'])
@require_terminal_enabled
@require_allowed_ip
@require_time_based_access
@require_superadmin
@require_terminal_token
def connect_with_profile(profile_id):
    """Create a terminal session using a saved connection profile"""
    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalConnectionProfile
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    # Check max sessions
    config = get_terminal_config()
    user_sessions = [s for s in active_sessions.values() if s['user_id'] == current_user.id]
    if len(user_sessions) >= config['max_sessions']:
        return jsonify({
            'error': f'Maximum concurrent sessions ({config["max_sessions"]}) reached',
            'code': 'MAX_SESSIONS_EXCEEDED'
        }), 429

    db = get_db_session()
    try:
        profile = db.query(TerminalConnectionProfile).filter_by(id=profile_id).first()

        if not profile:
            return jsonify({'error': 'Profile not found'}), 404

        denied_response = _ensure_terminal_tool_access(profile.protocol)
        if denied_response:
            return denied_response

        # Check access rights
        if profile.created_by_id != current_user.id and not profile.is_shared:
            return jsonify({'error': 'Access denied'}), 403

        # Check per-profile access restrictions if enabled
        if config.get('profile_restrictions_enabled'):
            has_profile_restrictions = (
                profile.access_hours_start or
                profile.access_hours_end or
                profile.access_days
            )

            if has_profile_restrictions:
                from datetime import datetime
                import pytz

                try:
                    tz = pytz.timezone(config.get('access_timezone', 'UTC'))
                except Exception:
                    tz = pytz.UTC

                now = datetime.now(tz)
                current_day = now.strftime('%a').lower()
                current_time = now.strftime('%H:%M')

                # Check profile access days
                if profile.access_days:
                    allowed_days = [d.strip().lower() for d in profile.access_days.split(',')]
                    if current_day not in allowed_days:
                        return jsonify({
                            'error': f'This profile is not accessible on {now.strftime("%A")}s',
                            'code': 'PROFILE_DAY_RESTRICTED'
                        }), 403

                # Check profile access hours
                if profile.access_hours_start and profile.access_hours_end:
                    if not (profile.access_hours_start <= current_time <= profile.access_hours_end):
                        return jsonify({
                            'error': f'This profile is only accessible between {profile.access_hours_start} and {profile.access_hours_end}',
                            'code': 'PROFILE_HOURS_RESTRICTED'
                        }), 403

        # Build server config from profile
        server_config = {
            'hostname': profile.hostname,
            'ip': profile.hostname,
            'port': profile.port,
            'username': profile.username,
            'name': profile.name
        }

        # Decrypt password if available
        if profile.password_encrypted:
            try:
                from encryption import decrypt_data
                server_config['password'] = decrypt_data(profile.password_encrypted)
            except Exception as e:
                logger.error(f"Failed to decrypt password: {e}")

        if profile.ssh_key_path:
            server_config['key_file'] = profile.ssh_key_path

        # Create session
        session_id = f"{current_user.id}_{profile.name}_{int(time.time())}"
        terminal_session = TerminalSession(
            session_id,
            profile.name,
            profile.protocol,
            profile.default_shell,
            profile.use_sudo
        )

        # Store session
        active_sessions[session_id] = {
            'session': terminal_session,
            'user_id': current_user.id,
            'username': current_user.username,
            'server_name': profile.name,
            'profile_id': profile_id
        }

        # Start session
        terminal_session.start(server_config)

        if terminal_session.error:
            del active_sessions[session_id]
            return jsonify({'error': terminal_session.error}), 500

        # Update profile usage
        profile.last_used_at = datetime.utcnow()
        profile.use_count += 1
        db.commit()

        logger.info(f"Terminal session created from profile '{profile.name}' by {current_user.username}")
        log_terminal_command(
            current_user.username,
            profile.name,
            f"[SESSION_START from profile] Protocol: {profile.protocol}"
        )

        return jsonify({
            'session_id': session_id,
            'server': profile.name,
            'hostname': profile.hostname,
            'protocol': profile.protocol,
            'status': 'connected'
        })

    except Exception as e:
        logger.error(f"Error connecting with profile {profile_id}: {e}")
        return jsonify({'error': 'Failed to create session'}), 500
    finally:
        db.close()


# ============================================================================
# Session Recording Endpoints
# ============================================================================

# In-memory recording buffers (moved to database on session close)
recording_buffers = {}


def start_recording(session_id, user_id, username, server_hostname, protocol, profile_id=None):
    """Start recording a terminal session"""
    config = get_terminal_config()
    if not config.get('recording_enabled', True):
        return None

    recording_buffers[session_id] = {
        'user_id': user_id,
        'username': username,
        'server_hostname': server_hostname,
        'protocol': protocol,
        'profile_id': profile_id,
        'started_at': datetime.utcnow(),
        'events': [],
        'commands': [],
        'input_count': 0,
        'output_count': 0,
        'start_time': time.time()
    }

    logger.info(f"Started recording session {session_id}")
    return session_id


def record_event(session_id, event_type, data):
    """Record a terminal event (input or output)"""
    if session_id not in recording_buffers:
        return

    recording = recording_buffers[session_id]
    config = get_terminal_config()
    max_size = config.get('recording_max_size_mb', 50) * 1024 * 1024

    # Calculate current size
    current_size = sum(len(e.get('data', '')) for e in recording['events'])
    if current_size >= max_size:
        return  # Skip if size limit reached

    elapsed = time.time() - recording['start_time']
    event = {
        't': round(elapsed, 3),
        'type': event_type,  # 'i' for input, 'o' for output
        'data': data
    }
    recording['events'].append(event)

    if event_type == 'i':
        recording['input_count'] += 1
        # Track commands (input ending with newline)
        if '\n' in data or '\r' in data:
            cmd = data.strip()
            if cmd:
                recording['commands'].append({
                    't': round(elapsed, 3),
                    'cmd': cmd
                })
    else:
        recording['output_count'] += 1


def stop_recording(session_id, error_message=None):
    """Stop recording and save to database"""
    if session_id not in recording_buffers:
        return None

    recording = recording_buffers[session_id]
    ended_at = datetime.utcnow()
    duration = (ended_at - recording['started_at']).total_seconds()

    try:
        from config import get_db_session
        from models.terminal import TerminalSessionRecording

        # Convert events to JSONL
        recording_data = '\n'.join(json.dumps(e) for e in recording['events'])
        recording_size = len(recording_data.encode('utf-8'))

        # Compress if large (> 1MB)
        is_compressed = False
        recording_compressed = None
        if recording_size > 1024 * 1024:
            recording_compressed = gzip.compress(recording_data.encode('utf-8'))
            is_compressed = True
            recording_data = None

        db = get_db_session()
        try:
            session_recording = TerminalSessionRecording(
                session_id=session_id,
                user_id=recording['user_id'],
                username=recording['username'],
                connection_profile_id=recording.get('profile_id'),
                server_hostname=recording['server_hostname'],
                protocol=recording['protocol'],
                started_at=recording['started_at'],
                ended_at=ended_at,
                duration_seconds=round(duration, 2),
                client_ip=request.remote_addr if request else None,
                recording_data=recording_data,
                recording_size_bytes=recording_size,
                recording_compressed=recording_compressed,
                is_compressed=is_compressed,
                input_event_count=recording['input_count'],
                output_event_count=recording['output_count'],
                command_count=len(recording['commands']),
                commands_json=json.dumps(recording['commands']),
                status='completed' if not error_message else 'failed',
                error_message=error_message
            )

            db.add(session_recording)
            db.commit()

            logger.info(f"Saved recording for session {session_id}: {recording_size} bytes, {len(recording['commands'])} commands")

            return session_recording.id

        except Exception as e:
            db.rollback()
            logger.error(f"Failed to save recording for {session_id}: {e}")
            return None
        finally:
            db.close()

    except ImportError as e:
        logger.error(f"Models not available for recording: {e}")
        return None
    finally:
        # Always clean up buffer
        del recording_buffers[session_id]


@terminal_bp.route('/recordings', methods=['GET'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def list_recordings():
    """List session recordings with optional filters"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalSessionRecording
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    # Query params
    user_id = request.args.get('user_id', type=int)
    hostname = request.args.get('hostname')
    flagged = request.args.get('flagged', type=bool)
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    db = get_db_session()
    try:
        query = db.query(TerminalSessionRecording)

        if user_id:
            query = query.filter(TerminalSessionRecording.user_id == user_id)
        if hostname:
            query = query.filter(TerminalSessionRecording.server_hostname.ilike(f'%{hostname}%'))
        if flagged is not None:
            query = query.filter(TerminalSessionRecording.flagged_for_review == flagged)

        total = query.count()
        recordings = query.order_by(TerminalSessionRecording.started_at.desc()) \
                         .offset(offset).limit(limit).all()

        return jsonify({
            'recordings': [r.to_summary() for r in recordings],
            'total': total,
            'limit': limit,
            'offset': offset
        })

    except Exception as e:
        logger.error(f"Error listing recordings: {e}")
        return jsonify({'error': 'Failed to list recordings'}), 500
    finally:
        db.close()


@terminal_bp.route('/recordings/<int:recording_id>', methods=['GET'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def get_recording(recording_id):
    """Get a specific session recording"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from config import get_db_session

    try:
        from models.terminal import TerminalSessionRecording
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    include_data = request.args.get('include_data', 'false').lower() == 'true'

    db = get_db_session()
    try:
        recording = db.query(TerminalSessionRecording).filter_by(id=recording_id).first()

        if not recording:
            return jsonify({'error': 'Recording not found'}), 404

        result = recording.to_dict(include_recording=include_data)

        # Decompress if needed and data requested
        if include_data and recording.is_compressed and recording.recording_compressed:
            try:
                decompressed = gzip.decompress(recording.recording_compressed).decode('utf-8')
                result['recording_data'] = decompressed
            except Exception as e:
                logger.error(f"Failed to decompress recording: {e}")
                result['recording_data'] = None
                result['decompression_error'] = str(e)

        return jsonify({'recording': result})

    except Exception as e:
        logger.error(f"Error getting recording {recording_id}: {e}")
        return jsonify({'error': 'Failed to get recording'}), 500
    finally:
        db.close()


@terminal_bp.route('/recordings/<int:recording_id>/playback', methods=['GET'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def get_recording_playback(recording_id):
    """Get recording data formatted for playback"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from config import get_db_session

    try:
        from models.terminal import TerminalSessionRecording
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    db = get_db_session()
    try:
        recording = db.query(TerminalSessionRecording).filter_by(id=recording_id).first()

        if not recording:
            return jsonify({'error': 'Recording not found'}), 404

        # Get recording data
        recording_data = recording.recording_data
        if recording.is_compressed and recording.recording_compressed:
            try:
                recording_data = gzip.decompress(recording.recording_compressed).decode('utf-8')
            except Exception as e:
                return jsonify({'error': f'Failed to decompress: {e}'}), 500

        # Parse JSONL events
        events = []
        if recording_data:
            for line in recording_data.strip().split('\n'):
                if line:
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue

        return jsonify({
            'session_id': recording.session_id,
            'username': recording.username,
            'server': recording.server_hostname,
            'started_at': recording.started_at.isoformat(),
            'duration_seconds': recording.duration_seconds,
            'events': events,
            'event_count': len(events)
        })

    except Exception as e:
        logger.error(f"Error getting recording playback {recording_id}: {e}")
        return jsonify({'error': 'Failed to get playback data'}), 500
    finally:
        db.close()


@terminal_bp.route('/recordings/<int:recording_id>/flag', methods=['POST'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def flag_recording(recording_id):
    """Flag a recording for review"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalSessionRecording
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    data = request.get_json() or {}

    db = get_db_session()
    try:
        recording = db.query(TerminalSessionRecording).filter_by(id=recording_id).first()

        if not recording:
            return jsonify({'error': 'Recording not found'}), 404

        recording.flagged_for_review = data.get('flagged', True)
        recording.review_notes = data.get('notes')

        if data.get('reviewed'):
            recording.reviewed_by_id = current_user.id
            recording.reviewed_at = datetime.utcnow()

        db.commit()

        logger.info(f"Recording {recording_id} flagged by {current_user.username}")

        return jsonify({
            'success': True,
            'flagged': recording.flagged_for_review,
            'notes': recording.review_notes
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error flagging recording {recording_id}: {e}")
        return jsonify({'error': 'Failed to flag recording'}), 500
    finally:
        db.close()


@terminal_bp.route('/recordings/<int:recording_id>', methods=['DELETE'])
@require_terminal_enabled
@require_superadmin
@require_terminal_token
def delete_recording(recording_id):
    """Delete a session recording"""
    denied_response = _ensure_terminal_tool_access()
    if denied_response:
        return denied_response

    from flask_login import current_user
    from config import get_db_session

    try:
        from models.terminal import TerminalSessionRecording
    except ImportError:
        return jsonify({'error': 'Terminal models not available'}), 500

    db = get_db_session()
    try:
        recording = db.query(TerminalSessionRecording).filter_by(id=recording_id).first()

        if not recording:
            return jsonify({'error': 'Recording not found'}), 404

        session_id = recording.session_id
        db.delete(recording)
        db.commit()

        logger.info(f"Recording {session_id} deleted by {current_user.username}")

        return jsonify({'success': True, 'message': 'Recording deleted'})

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting recording {recording_id}: {e}")
        return jsonify({'error': 'Failed to delete recording'}), 500
    finally:
        db.close()


def cleanup_old_recordings():
    """Delete recordings older than retention period"""
    config = get_terminal_config()
    retention_days = config.get('recording_retention_days', 90)

    if retention_days <= 0:
        return 0

    cutoff = datetime.utcnow() - timedelta(days=retention_days)

    try:
        from config import get_db_session
        from models.terminal import TerminalSessionRecording

        db = get_db_session()
        try:
            deleted = db.query(TerminalSessionRecording) \
                .filter(TerminalSessionRecording.started_at < cutoff) \
                .delete()
            db.commit()

            if deleted > 0:
                logger.info(f"Cleaned up {deleted} old recordings (older than {retention_days} days)")

            return deleted

        except Exception as e:
            db.rollback()
            logger.error(f"Error cleaning old recordings: {e}")
            return 0
        finally:
            db.close()

    except ImportError:
        return 0
