"""
Unified Professional Layout Routes

Provides a consistent professional wrapper for authenticated pages including:
- Console (Management Console)
- Dashboard
- Other authenticated tools

This module creates a unified look and feel matching the Asset Discovery layout
with persistent navigation, branding, and user info display.

Author: Security Audit Toolkit Team
"""

import logging
from flask import Blueprint, request, render_template_string, redirect, url_for

# Import logging
try:
    from config import logger
except ImportError:
    logger = logging.getLogger(__name__)

try:
    from config import get_db_session
    from models.user import User
    DB_LOOKUP_AVAILABLE = True
except ImportError:
    get_db_session = lambda: None
    User = None
    DB_LOOKUP_AVAILABLE = False

# Import Flask-Login for authentication
try:
    from flask_login import current_user
    from auth_login import is_authenticated
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    FLASK_LOGIN_AVAILABLE = False
    current_user = None

    def is_authenticated():
        return True

# Import disclaimer version for liability check
try:
    from api.auth_routes import DISCLAIMER_VERSION
except ImportError:
    from version_info import get_toolkit_version
    DISCLAIMER_VERSION = get_toolkit_version()


def check_disclaimer_accepted():
    """
    Check if user has accepted the current disclaimer version.
    Returns redirect URL if disclaimer not accepted, None otherwise.
    """
    if not FLASK_LOGIN_AVAILABLE or not current_user:
        return None

    # Enforce password change before disclaimer acceptance.
    if getattr(current_user, 'must_change_password', False):
        return None

    # Check disclaimer status from a fresh DB read to avoid stale session state.
    disclaimer_accepted = getattr(current_user, 'disclaimer_accepted_at', None)
    disclaimer_version = str(getattr(current_user, 'disclaimer_version', '') or '').strip()
    expected_version = str(DISCLAIMER_VERSION or '').strip()

    db = None
    db_session_factory = get_db_session
    user_model = User

    if (not db_session_factory or not user_model) and getattr(current_user, 'id', None):
        try:
            from config import get_db_session as dynamic_get_db_session
            from models.user import User as DynamicUser
            db_session_factory = dynamic_get_db_session
            user_model = DynamicUser
        except Exception:
            db_session_factory = None
            user_model = None

    if db_session_factory and user_model and getattr(current_user, 'id', None):
        db = db_session_factory()
        if db:
            try:
                fresh_user = db.query(user_model).filter(user_model.id == current_user.id).first()
                if fresh_user:
                    disclaimer_accepted = fresh_user.disclaimer_accepted_at
                    disclaimer_version = str(fresh_user.disclaimer_version or '').strip()

                    # Keep session principal consistent for downstream checks.
                    try:
                        current_user.disclaimer_accepted_at = disclaimer_accepted
                        current_user.disclaimer_version = disclaimer_version
                    except Exception as sync_error:
                        logger.debug(
                            "Unable to sync disclaimer fields to current session principal: %s",
                            sync_error,
                        )
            finally:
                db.close()

    if not disclaimer_accepted or disclaimer_version != expected_version:
        return url_for('auth.accept_disclaimer', next=request.url)

    return None


# Create blueprint
unified_layout_bp = Blueprint('unified_layout', __name__)


# =============================================================================
# Unified Professional Layout Template
# =============================================================================

UNIFIED_LAYOUT_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ page_title }} - Security Audit Toolkit</title>
    <link rel="stylesheet" href="/static/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f0f1a;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --bg-card: #1f2937;
            --border-color: #0f3460;
            --text-primary: #e5e5e5;
            --text-secondary: #a5a5a5;
            --accent-blue: #3b82f6;
            --accent-green: #10b981;
            --accent-red: #ef4444;
            --accent-yellow: #f59e0b;
            --accent-purple: #8b5cf6;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Professional Header */
        .toolkit-wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .toolkit-header {
            background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--bg-tertiary) 100%);
            border-bottom: 1px solid var(--border-color);
            padding: 0.75rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        .header-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-brand-icon {
            font-size: 1.75rem;
            filter: drop-shadow(0 0 8px rgba(59, 130, 246, 0.5));
        }

        .header-brand h1 {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }

        .brand-subtitle {
            font-size: 0.7rem;
            color: var(--text-secondary);
            margin-top: 0.1rem;
        }

        /* Navigation */
        .toolkit-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 0.875rem;
            border-radius: 6px;
            transition: all 0.2s;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.375rem;
            border: 1px solid transparent;
        }

        .nav-link:hover {
            background: rgba(59, 130, 246, 0.1);
            color: var(--text-primary);
            border-color: var(--border-color);
        }

        .nav-link.active {
            background: rgba(59, 130, 246, 0.15);
            color: var(--accent-blue);
            border-color: var(--accent-blue);
        }

        /* User Info */
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-left: 1rem;
            padding-left: 1rem;
            border-left: 1px solid var(--border-color);
        }

        .user-badge {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        .user-badge-icon {
            width: 28px;
            height: 28px;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            color: white;
            font-weight: 600;
        }

        .user-role {
            color: var(--accent-blue);
            font-size: 0.75rem;
        }

        .logout-btn {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            transition: all 0.2s;
            font-size: 0.8rem;
            border: 1px solid var(--border-color);
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.1);
            border-color: var(--accent-red);
            color: var(--accent-red);
        }

        /* Main content iframe */
        .toolkit-frame {
            flex: 1;
            border: none;
            width: 100%;
            background: var(--bg-primary);
        }

        /* Responsive */
        @media (max-width: 900px) {
            .toolkit-header {
                flex-wrap: wrap;
                gap: 0.75rem;
            }

            .toolkit-nav {
                width: 100%;
                justify-content: center;
                flex-wrap: wrap;
            }

            .user-info {
                margin-left: 0;
                padding-left: 0;
                border-left: none;
                width: 100%;
                justify-content: center;
                padding-top: 0.5rem;
                border-top: 1px solid var(--border-color);
            }
        }
    </style>
</head>
<body>
    <div class="toolkit-wrapper">
        <header class="toolkit-header">
            <div class="header-brand">
                <span class="header-brand-icon">🛡️</span>
                <div>
                    <h1>Security Audit Toolkit</h1>
                    <div class="brand-subtitle">{{ page_subtitle }}</div>
                </div>
            </div>

            {% if current_user %}
            <div class="user-info">
                <div class="user-badge">
                    <span class="user-badge-icon">{{ (current_user.username or 'U')[0]|upper }}</span>
                    <span>{{ current_user.username or 'User' }}</span>
                    {% if current_user.role %}
                    <span class="user-role">({{ current_user.role }})</span>
                    {% endif %}
                </div>
                <a href="/auth/logout" class="logout-btn">Logout</a>
            </div>
            {% endif %}
        </header>

        <iframe
            src="{{ iframe_url }}"
            class="toolkit-frame"
            title="{{ page_title }}"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads allow-top-navigation-by-user-activation"
        ></iframe>
    </div>
</body>
</html>
'''


# =============================================================================
# Routes
# =============================================================================

@unified_layout_bp.route('/console')
def console_wrapped():
    """
    Serve the management console in the unified professional layout.

    Requires authentication (same as original /console route).
    Access flow:
    1. Must be logged in
    2. Must have accepted current disclaimer version (liability protection)
    3. Must not have pending password change
    """
    # Check if user is authenticated
    if FLASK_LOGIN_AVAILABLE and not is_authenticated():
        logger.warning(f"Unauthenticated console access attempt from {request.remote_addr}")
        return redirect(url_for('auth.login', next=request.url))

    # Check if disclaimer needs to be accepted (liability protection)
    disclaimer_redirect = check_disclaimer_accepted()
    if disclaimer_redirect:
        logger.info(f"User {getattr(current_user, 'username', 'unknown')} redirected to accept disclaimer")
        return redirect(disclaimer_redirect)

    # Check if user must change password
    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'must_change_password'):
        if current_user.must_change_password:
            logger.info(f"User {current_user.username} redirected to change password")
            return redirect(url_for('auth.change_password', next=request.url))

    # Log access
    user_info = 'anonymous'
    if FLASK_LOGIN_AVAILABLE and current_user and hasattr(current_user, 'username'):
        user_info = current_user.username
    logger.info(f"Console (wrapped) accessed by {user_info} from {request.remote_addr}")

    return render_template_string(
        UNIFIED_LAYOUT_TEMPLATE,
        page_title='Management Console',
        page_subtitle='Enterprise Management Console',
        active_page='console',
        iframe_url='/console-raw?v=20260313b',
        current_user=current_user if FLASK_LOGIN_AVAILABLE else None
    )


# Dashboard route moved to app.py as a public page (no auth required)
# Users can view the dashboard without logging in - it's a read-only overview
# @unified_layout_bp.route('/dashboard')
# def dashboard_wrapped():
#     ...
