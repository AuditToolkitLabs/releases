"""
Application Update API Routes

Provides server-side update infrastructure for all deployment types:
- VM Appliance deployments (OVA/VMDK/QCOW2)
- Docker/Compose deployments
- Physical/Virtual server installations
- Python pip installations
- DEB/RPM package installations
- MSI (Windows) installations
- Direct source/git installations

This works with the universal update client (toolkit-updater.sh / toolkit-updater.ps1).
"""

import os
import json
import hashlib
import logging
import platform
import shutil
import subprocess  # nosec B404 - used for controlled archive extraction during updates
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from functools import wraps

from flask import Blueprint, request, jsonify, current_app, send_file
from version_info import get_toolkit_version

# Import auth decorators
try:
    from auth_core import require_api_key
    AUTH_AVAILABLE = True
except ImportError:
    AUTH_AVAILABLE = False
    def require_api_key(f):
        return f

logger = logging.getLogger(__name__)

# Blueprint
update_bp = Blueprint('updates', __name__)

# Configuration
TOOLKIT_VERSION = get_toolkit_version(default='0.0.0')
UPDATE_ARTIFACTS_DIR = os.environ.get('UPDATE_ARTIFACTS_DIR', '/opt/audit-toolkit/updates/artifacts')

# Update channels
CHANNELS = {
    'stable': {
        'min_version': '5.0.0',
        'description': 'Production-ready releases',
    },
    'beta': {
        'min_version': '5.1.0',
        'description': 'Pre-release testing',
    },
    'nightly': {
        'min_version': '5.2.0',
        'description': 'Latest development builds',
    }
}

# Deployment types and their preferred artifact formats
DEPLOYMENT_ARTIFACTS = {
    'docker': ['docker-compose.yml', 'full.tar.gz'],
    'appliance': ['full.tar.gz', 'source.tar.gz'],
    'source': ['full.tar.gz', 'source.tar.gz'],
    'git': ['source.tar.gz'],
    'pip': ['.whl', '.tar.gz'],
    'deb': ['.deb'],
    'rpm': ['.rpm'],
    'msi': ['.msi'],
    'windows': ['.zip', '.msi'],
}


# =============================================================================
# Helpers
# =============================================================================

def _sha256_file(file_path: str) -> str:
    """Calculate SHA256 hash of a file."""
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            sha256.update(chunk)
    return sha256.hexdigest()


def _parse_version(version: str) -> Tuple[int, ...]:
    """Parse version string to comparable tuple."""
    # Handle versions like "5.1.5", "5.1.5-beta", etc.
    clean = version.lstrip('v').split('-')[0]
    parts = clean.split('.')
    return tuple(int(p) for p in parts if p.isdigit())


def _version_compare(v1: str, v2: str) -> int:
    """Compare two version strings. Returns: -1 if v1<v2, 0 if equal, 1 if v1>v2"""
    t1, t2 = _parse_version(v1), _parse_version(v2)
    if t1 < t2:
        return -1
    elif t1 > t2:
        return 1
    return 0


def _get_latest_artifact(component: str, channel: str = 'stable') -> Optional[Dict[str, Any]]:
    """
    Find the latest update artifact for a component.

    Artifact directory structure:
        /artifacts/
            stable/
                audits/
                    audits-5.1.5.tar.gz
                    audits-5.1.5.tar.gz.sha256
                application/
                    application-5.1.5.tar.gz
                full/
                    full-5.1.5.tar.gz
    """
    artifacts_dir = Path(UPDATE_ARTIFACTS_DIR) / channel / component

    if not artifacts_dir.exists():
        return None

    # Find all .tar.gz files
    archives = list(artifacts_dir.glob('*.tar.gz'))
    if not archives:
        return None

    # Sort by version (extract from filename)
    def extract_version(p: Path) -> Tuple[int, ...]:
        # e.g., "audits-5.1.5.tar.gz" -> "5.1.5"
        name = p.stem.replace('.tar', '')  # audits-5.1.5
        version_part = name.split('-')[-1]  # 5.1.5
        return _parse_version(version_part)

    archives.sort(key=extract_version, reverse=True)
    latest = archives[0]

    # Extract version from filename
    name = latest.stem.replace('.tar', '')
    version = name.split('-')[-1]

    # Check for checksum file
    checksum_file = latest.with_suffix('.tar.gz.sha256')
    if checksum_file.exists():
        checksum = checksum_file.read_text().strip().split()[0]
    else:
        checksum = _sha256_file(str(latest))

    return {
        'component': component,
        'version': version,
        'channel': channel,
        'filename': latest.name,
        'file_path': str(latest),
        'size': latest.stat().st_size,
        'sha256': checksum,
        'modified_at': datetime.fromtimestamp(latest.stat().st_mtime).isoformat(),
    }


def _build_audit_manifest() -> Dict[str, Any]:
    """
    Build manifest of all audit scripts with their versions/checksums.

    This allows differential updates - only changed scripts need to be downloaded.
    """
    audits_dir = Path(current_app.root_path).parent / 'audits'
    manifest = {
        'generated_at': datetime.utcnow().isoformat(),
        'scripts': {},
        'categories': {},
    }

    for script in audits_dir.rglob('*.sh'):
        if script.name.startswith('_'):
            continue

        rel_path = script.relative_to(audits_dir)
        category = str(rel_path.parent)

        # Calculate checksum
        checksum = _sha256_file(str(script))

        # Get script metadata from header comments
        version = "1.0.0"
        description = ""
        with open(script, 'r') as f:
            for line in f:
                if line.startswith('# Version:'):
                    version = line.split(':')[1].strip()
                elif line.startswith('# Description:'):
                    description = line.split(':')[1].strip()
                elif not line.startswith('#'):
                    break

        manifest['scripts'][str(rel_path)] = {
            'sha256': checksum,
            'version': version,
            'size': script.stat().st_size,
            'description': description,
        }

        # Track categories
        if category not in manifest['categories']:
            manifest['categories'][category] = []
        manifest['categories'][category].append(str(rel_path))

    manifest['total_scripts'] = len(manifest['scripts'])
    return manifest


# =============================================================================
# API Routes
# =============================================================================

@update_bp.route('/api/updates/manifest', methods=['GET'])
def get_update_manifest():
    """
    Get update manifest showing available updates for any deployment type.

    Query params:
        current_version: Client's current version
        channel: Update channel (stable, beta, nightly)
        component: Which component to check (audits, application, full)
        deployment_type: How the toolkit is deployed (docker, source, pip, deb, rpm, msi, appliance)

    Headers (alternative to query params):
        X-Current-Version: Client's current version
        X-Update-Channel: Update channel
        X-Deployment-Type: Deployment type

    Returns:
        JSON manifest with update availability and download info
    """
    try:
        # Support both query params and headers
        current_version = request.args.get('current_version') or \
                          request.headers.get('X-Current-Version', '0.0.0')
        channel = request.args.get('channel') or \
                  request.headers.get('X-Update-Channel', 'stable')
        component = request.args.get('component', 'full')
        deployment_type = request.args.get('deployment_type') or \
                          request.headers.get('X-Deployment-Type', 'source')

        if channel not in CHANNELS:
            return jsonify({
                'success': False,
                'error': f'Invalid channel. Valid options: {", ".join(CHANNELS.keys())}'
            }), 400

        # Get latest artifact for requested component
        artifact = _get_latest_artifact(component, channel)

        # Build response base
        if not artifact:
            return jsonify({
                'success': True,
                'update_available': False,
                'current_version': current_version,
                'latest_version': TOOLKIT_VERSION,
                'channel': channel,
                'component': component,
                'deployment_type': deployment_type,
                'message': 'No update artifacts available on this server. Use GitHub releases.',
                'github_releases_url': f'https://github.com/AuditToolkitLabs/Audit-Tool-/releases/tag/v{TOOLKIT_VERSION}',
            })

        latest_version = artifact['version']
        update_available = _version_compare(latest_version, current_version) > 0

        response = {
            'success': True,
            'update_available': update_available,
            'current_version': current_version,
            'latest_version': latest_version,
            'channel': channel,
            'component': component,
            'checked_at': datetime.utcnow().isoformat(),
        }

        if update_available:
            server_origin = request.url_root.rstrip('/')
            response.update({
                'download_url': f"{server_origin}/api/updates/download?component={component}&channel={channel}",
                'filename': artifact['filename'],
                'size': artifact['size'],
                'sha256': artifact['sha256'],
            })

        return jsonify(response)

    except Exception as e:
        logger.error(f"Update manifest error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/download', methods=['GET'])
@require_api_key
def download_update():
    """
    Download update artifact.

    PROTECTED: Requires API key authentication.

    Query params:
        component: Which component (audits, application, full)
        channel: Update channel

    Returns:
        Streamed tar.gz file
    """
    try:
        component = request.args.get('component', 'full')
        channel = request.args.get('channel', 'stable')

        artifact = _get_latest_artifact(component, channel)

        if not artifact:
            return jsonify({
                'success': False,
                'error': 'No update artifact found'
            }), 404

        file_path = artifact['file_path']
        if not os.path.exists(file_path):
            return jsonify({
                'success': False,
                'error': 'Artifact file missing'
            }), 404

        return send_file(
            file_path,
            mimetype='application/gzip',
            as_attachment=True,
            download_name=artifact['filename']
        )

    except Exception as e:
        logger.error(f"Update download error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/scripts/manifest', methods=['GET'])
def get_scripts_manifest():
    """
    Get detailed manifest of all audit scripts.

    This enables differential script updates - clients can compare
    checksums and only download changed scripts.

    Returns:
        JSON manifest with all scripts and their checksums
    """
    try:
        manifest = _build_audit_manifest()
        return jsonify({
            'success': True,
            'toolkit_version': TOOLKIT_VERSION,
            **manifest
        })
    except Exception as e:
        logger.error(f"Scripts manifest error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/scripts/check', methods=['POST'])
def check_scripts_updates():
    """
    Check which scripts need updates based on client's current checksums.

    Request body:
        {
            "scripts": {
                "platform/baseline/updates.sh": "abc123...",
                ...
            }
        }

    Returns:
        List of scripts that differ (need update)
    """
    try:
        client_scripts = request.json.get('scripts', {})

        if not client_scripts:
            return jsonify({
                'success': False,
                'error': 'No scripts provided for comparison'
            }), 400

        server_manifest = _build_audit_manifest()
        server_scripts = server_manifest['scripts']

        updates_needed = []
        new_scripts = []
        removed_scripts = []

        # Check for updates and new scripts
        for script_path, script_info in server_scripts.items():
            if script_path in client_scripts:
                if client_scripts[script_path] != script_info['sha256']:
                    updates_needed.append({
                        'path': script_path,
                        'server_sha256': script_info['sha256'],
                        'client_sha256': client_scripts[script_path],
                    })
            else:
                new_scripts.append(script_path)

        # Check for removed scripts
        for script_path in client_scripts:
            if script_path not in server_scripts:
                removed_scripts.append(script_path)

        return jsonify({
            'success': True,
            'updates_needed': len(updates_needed),
            'new_scripts': len(new_scripts),
            'removed_scripts': len(removed_scripts),
            'details': {
                'updates': updates_needed,
                'new': new_scripts,
                'removed': removed_scripts,
            }
        })

    except Exception as e:
        logger.error(f"Scripts check error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/scripts/download/<path:script_path>', methods=['GET'])
@require_api_key
def download_script(script_path: str):
    """
    Download a single audit script.

    PROTECTED: Requires API key authentication.

    This enables incremental updates - only download changed scripts.
    """
    try:
        audits_dir = Path(current_app.root_path).parent / 'audits'
        script_file = audits_dir / script_path

        # Security: Ensure path doesn't escape audits directory
        try:
            script_file = script_file.resolve()
            audits_dir = audits_dir.resolve()
            if not str(script_file).startswith(str(audits_dir)):
                raise ValueError("Path traversal detected")
        except (ValueError, RuntimeError):
            return jsonify({'success': False, 'error': 'Invalid path'}), 400

        if not script_file.exists() or not script_file.is_file():
            return jsonify({'success': False, 'error': 'Script not found'}), 404

        return send_file(
            str(script_file),
            mimetype='text/x-shellscript',
            as_attachment=True,
            download_name=script_file.name
        )

    except Exception as e:
        logger.error(f"Script download error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/changelog', methods=['GET'])
def get_changelog():
    """
    Get changelog/release notes for versions.

    Query params:
        from_version: Starting version
        to_version: Ending version (default: latest)
    """
    try:
        changelog_file = Path(current_app.root_path).parent / 'CHANGELOG.md'

        if not changelog_file.exists():
            return jsonify({
                'success': True,
                'changelog': [],
                'message': 'No changelog available'
            })

        # Parse changelog (simple version - assumes standard format)
        content = changelog_file.read_text()

        return jsonify({
            'success': True,
            'toolkit_version': TOOLKIT_VERSION,
            'changelog_raw': content[:5000],  # First 5000 chars
        })

    except Exception as e:
        logger.error(f"Changelog error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# GUI Update Management Endpoints
# =============================================================================

def _detect_server_deployment_type() -> Dict[str, Any]:
    """
    Detect the deployment type of this server instance.

    Returns details about how the toolkit is deployed.
    """
    deployment_info = {
        'type': 'source',
        'description': 'Source/Git installation',
        'can_update': True,
        'update_method': 'git pull or manual',
    }

    root_dir = Path(current_app.root_path).parent

    # Check for deployment type marker file
    marker_file = root_dir / '.deployment-type'
    if marker_file.exists():
        dtype = marker_file.read_text().strip()
        if dtype in DEPLOYMENT_ARTIFACTS:
            deployment_info['type'] = dtype
    else:
        # Auto-detect based on environment
        if os.path.exists('/.dockerenv') or os.environ.get('DOCKER_CONTAINER'):
            deployment_info.update({
                'type': 'docker',
                'description': 'Docker container',
                'can_update': True,
                'update_method': 'docker-compose pull',
            })
        elif (root_dir / '.git').exists():
            deployment_info.update({
                'type': 'git',
                'description': 'Git repository clone',
                'can_update': True,
                'update_method': 'git pull',
            })
        elif os.path.exists('/etc/audit-toolkit'):
            # DEB/RPM installed
            if os.path.exists('/var/lib/dpkg/info/audit-toolkit.list'):
                deployment_info.update({
                    'type': 'deb',
                    'description': 'Debian package',
                    'can_update': True,
                    'update_method': 'apt upgrade',
                })
            elif os.path.exists('/var/lib/rpm'):
                deployment_info.update({
                    'type': 'rpm',
                    'description': 'RPM package',
                    'can_update': True,
                    'update_method': 'yum/dnf upgrade',
                })
        elif platform.system() == 'Windows':
            deployment_info.update({
                'type': 'windows',
                'description': 'Windows installation',
                'can_update': True,
                'update_method': 'PowerShell updater',
            })

    return deployment_info


def _get_backup_list() -> List[Dict[str, Any]]:
    """Get list of available rollback backups."""
    backups_dir = Path(os.environ.get('TOOLKIT_BACKUP_DIR', '/opt/audit-toolkit/backups'))

    if not backups_dir.exists():
        return []

    backups = []
    for backup_dir in sorted(backups_dir.iterdir(), reverse=True):
        if not backup_dir.is_dir():
            continue

        metadata_file = backup_dir / 'metadata.json'
        if metadata_file.exists():
            try:
                with open(metadata_file) as f:
                    metadata = json.load(f)
                backups.append({
                    'id': backup_dir.name,
                    'path': str(backup_dir),
                    'version': metadata.get('version', 'unknown'),
                    'created_at': metadata.get('created_at'),
                    'deployment_type': metadata.get('deployment_type', 'unknown'),
                    'components': metadata.get('components', []),
                })
            except json.JSONDecodeError:
                backups.append({
                    'id': backup_dir.name,
                    'path': str(backup_dir),
                    'version': 'unknown',
                    'created_at': backup_dir.name,  # Usually timestamp-based name
                })

    return backups[:10]  # Return last 10 backups


@update_bp.route('/api/updates/deployment-info', methods=['GET'])
def get_deployment_info():
    """
    Get information about this server's deployment type and update capabilities.

    Returns:
        JSON with deployment type, current version, update channel, and backup info
    """
    try:
        deployment = _detect_server_deployment_type()
        backups = _get_backup_list()

        # Get current update channel from settings
        channel = os.environ.get('UPDATE_CHANNEL', 'stable')

        return jsonify({
            'success': True,
            'version': TOOLKIT_VERSION,
            'deployment': deployment,
            'channel': channel,
            'available_channels': list(CHANNELS.keys()),
            'backups_available': len(backups),
            'can_rollback': len(backups) > 0,
            'last_backup': backups[0] if backups else None,
            'platform': {
                'system': platform.system(),
                'release': platform.release(),
                'machine': platform.machine(),
                'python': platform.python_version(),
            }
        })

    except Exception as e:
        logger.error(f"Deployment info error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/channel', methods=['POST'])
def set_update_channel():
    """
    Set the update channel for this installation.

    Request body:
        {"channel": "stable|beta|nightly"}
    """
    try:
        data = request.json or {}
        channel = data.get('channel', 'stable')

        if channel not in CHANNELS:
            return jsonify({
                'success': False,
                'error': f'Invalid channel. Valid options: {", ".join(CHANNELS.keys())}'
            }), 400

        # Store channel preference
        settings_file = Path(current_app.root_path).parent / 'settings' / 'update_settings.json'
        settings_file.parent.mkdir(parents=True, exist_ok=True)

        settings = {}
        if settings_file.exists():
            with open(settings_file) as f:
                settings = json.load(f)

        settings['channel'] = channel
        settings['updated_at'] = datetime.utcnow().isoformat()

        with open(settings_file, 'w') as f:
            json.dump(settings, f, indent=2)

        # Also set environment variable for current session
        os.environ['UPDATE_CHANNEL'] = channel

        return jsonify({
            'success': True,
            'channel': channel,
            'description': CHANNELS[channel]['description'],
        })

    except Exception as e:
        logger.error(f"Set channel error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/backups', methods=['GET'])
def list_backups():
    """
    List available rollback points.

    Returns:
        JSON list of available backups with their metadata
    """
    try:
        backups = _get_backup_list()

        return jsonify({
            'success': True,
            'backups': backups,
            'total': len(backups),
        })

    except Exception as e:
        logger.error(f"List backups error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/check', methods=['GET'])
def check_all_updates():
    """
    Check for available updates (both audits and application).

    Returns:
        JSON with update availability for audits and application
    """
    try:
        current_version = TOOLKIT_VERSION
        channel = os.environ.get('UPDATE_CHANNEL', 'stable')
        deployment = _detect_server_deployment_type()

        # Check for application updates
        app_artifact = _get_latest_artifact('full', channel)
        app_update_available = False
        app_latest_version = current_version

        if app_artifact:
            app_latest_version = app_artifact['version']
            app_update_available = _version_compare(app_latest_version, current_version) > 0

        # Check for audit-only updates
        audit_artifact = _get_latest_artifact('audits', channel)
        audit_update_available = False
        audit_latest_version = current_version

        if audit_artifact:
            audit_latest_version = audit_artifact['version']
            audit_update_available = _version_compare(audit_latest_version, current_version) > 0

        return jsonify({
            'success': True,
            'current_version': current_version,
            'channel': channel,
            'deployment': deployment,
            'application': {
                'update_available': app_update_available,
                'latest_version': app_latest_version,
                'artifact': app_artifact,
            },
            'audits': {
                'update_available': audit_update_available,
                'latest_version': audit_latest_version,
                'artifact': audit_artifact,
            },
            'checked_at': datetime.utcnow().isoformat(),
        })

    except Exception as e:
        logger.error(f"Check updates error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/apply', methods=['POST'])
def apply_update():
    """
    Apply an update (audits-only or full application).

    Request body:
        {
            "type": "audits" | "application",
            "create_backup": true,
            "restart_services": true
        }

    Note: For full application updates, this endpoint triggers the external
    updater script rather than attempting in-process updates (safer).
    """
    try:
        data = request.json or {}
        update_type = data.get('type', 'audits')
        create_backup = data.get('create_backup', True)
        restart_services = data.get('restart_services', True)

        if update_type not in ['audits', 'application', 'full']:
            return jsonify({
                'success': False,
                'error': 'Invalid update type. Use "audits" or "application"'
            }), 400

        channel = os.environ.get('UPDATE_CHANNEL', 'stable')
        deployment = _detect_server_deployment_type()

        # Get the artifact for download
        component = 'audits' if update_type == 'audits' else 'full'
        artifact = _get_latest_artifact(component, channel)

        if not artifact:
            return jsonify({
                'success': False,
                'error': f'No {component} update available in {channel} channel',
                'hint': 'Check GitHub releases for manual download',
                'github_url': f'https://github.com/AuditToolkitLabs/Audit-Tool-/releases/tag/v{TOOLKIT_VERSION}',
            }), 404

        # For audits-only updates, we can handle in-process
        if update_type == 'audits':
            # Simpler: extract audit scripts from artifact
            import tempfile

            root_dir = Path(current_app.root_path).parent
            audits_dir = root_dir / 'audits'

            # Create backup if requested
            if create_backup:
                backup_dir = Path(os.environ.get('TOOLKIT_BACKUP_DIR', '/opt/audit-toolkit/backups'))
                backup_dir.mkdir(parents=True, exist_ok=True)
                timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
                backup_path = backup_dir / f'audits-{timestamp}'

                import shutil
                shutil.copytree(audits_dir, backup_path)

                # Write metadata
                with open(backup_path / 'metadata.json', 'w') as f:
                    json.dump({
                        'version': TOOLKIT_VERSION,
                        'created_at': datetime.utcnow().isoformat(),
                        'type': 'audits-only',
                        'deployment_type': deployment['type'],
                    }, f, indent=2)

            # Extract new audits from artifact
            with tempfile.TemporaryDirectory() as tmp_dir:
                # Extract archive
                tar_executable = shutil.which('tar') or '/usr/bin/tar'
                subprocess.run([tar_executable, '-xzf', artifact['file_path'], '-C', tmp_dir], check=True)  # nosec

                # Find and copy audits directory
                extracted_dirs = list(Path(tmp_dir).iterdir())
                if extracted_dirs:
                    extracted_root = extracted_dirs[0]
                    extracted_audits = extracted_root / 'audits'

                    if extracted_audits.exists():
                        # Preserve local customizations by merging, not replacing
                        for item in extracted_audits.iterdir():
                            dest = audits_dir / item.name
                            if item.is_dir():
                                if dest.exists():
                                    shutil.rmtree(dest)
                                shutil.copytree(item, dest)
                            else:
                                shutil.copy2(item, dest)

            return jsonify({
                'success': True,
                'message': 'Audit scripts updated successfully',
                'from_version': TOOLKIT_VERSION,
                'to_version': artifact['version'],
                'backup_created': create_backup,
                'type': 'audits',
            })

        else:
            # Full application update - trigger external updater
            # This is safer than trying to update ourselves while running
            return jsonify({
                'success': True,
                'message': 'Full application update initiated',
                'action_required': True,
                'instructions': [
                    'Full application updates require running the external updater:',
                    '',
                    'Linux/macOS:',
                    f'  UPDATE_CHANNEL={channel} sudo bash scripts/toolkit-updater.sh download',
                    '  sudo bash scripts/toolkit-updater.sh apply',
                    '',
                    'Windows (PowerShell as Admin):',
                    f'  .\\scripts\\toolkit-updater.ps1 -Command download -Channel {channel}',
                    '  .\\scripts\\toolkit-updater.ps1 -Command apply',
                    '',
                    'Targeted patch bundle (all platforms):',
                    '  Linux/macOS: sudo bash scripts/toolkit-updater.sh patch /path/to/patch-bundle.tar.gz',
                    '  Windows: .\\scripts\\toolkit-updater.ps1 patch -PatchBundle C:\\path\\to\\patch-bundle.zip',
                    '',
                    'Or download the update package from:',
                    f'  {request.url_root}api/updates/download?component=full&channel={channel}',
                ],
                'download_url': f'{request.url_root}api/updates/download?component=full&channel={channel}',
                'artifact': artifact,
            })

    except subprocess.CalledProcessError as e:
        logger.error(f"Update subprocess error: {e}")
        return jsonify({'success': False, 'error': f'Update extraction failed: {e}'}), 500
    except Exception as e:
        logger.error(f"Apply update error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@update_bp.route('/api/updates/rollback', methods=['POST'])
def rollback_update():
    """
    Rollback to a previous backup.

    Request body:
        {"backup_id": "backup-20260224-120000"}
    """
    try:
        data = request.json or {}
        backup_id = data.get('backup_id')

        if not backup_id:
            return jsonify({
                'success': False,
                'error': 'backup_id is required'
            }), 400

        backups_dir = Path(os.environ.get('TOOLKIT_BACKUP_DIR', '/opt/audit-toolkit/backups'))
        backup_path = backups_dir / backup_id

        if not backup_path.exists():
            return jsonify({
                'success': False,
                'error': f'Backup not found: {backup_id}'
            }), 404

        # Read backup metadata
        metadata_file = backup_path / 'metadata.json'
        metadata = {}
        if metadata_file.exists():
            with open(metadata_file) as f:
                metadata = json.load(f)

        backup_type = metadata.get('type', 'full')
        root_dir = Path(current_app.root_path).parent

        # For audits-only backups, just restore audits
        if backup_type == 'audits-only' or backup_id.startswith('audits-'):
            audits_dir = root_dir / 'audits'

            # Create pre-rollback backup
            pre_backup_dir = backups_dir / f'pre-rollback-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
            import shutil
            shutil.copytree(audits_dir, pre_backup_dir / 'audits')
            with open(pre_backup_dir / 'metadata.json', 'w') as f:
                json.dump({
                    'version': TOOLKIT_VERSION,
                    'created_at': datetime.utcnow().isoformat(),
                    'type': 'pre-rollback',
                    'rollback_target': backup_id,
                }, f, indent=2)

            # Restore from backup
            if audits_dir.exists():
                shutil.rmtree(audits_dir)

            # The backup might have audits at root or in subdir
            backup_audits = backup_path / 'audits' if (backup_path / 'audits').exists() else backup_path
            shutil.copytree(backup_audits, audits_dir)

            return jsonify({
                'success': True,
                'message': f'Rolled back audits to backup: {backup_id}',
                'restored_version': metadata.get('version', 'unknown'),
                'pre_rollback_backup': pre_backup_dir.name,
            })

        else:
            # Full rollback requires external updater
            return jsonify({
                'success': True,
                'message': 'Full rollback initiated',
                'action_required': True,
                'instructions': [
                    'Full rollback requires running the external updater:',
                    '',
                    'Linux/macOS:',
                    f'  sudo bash scripts/toolkit-updater.sh rollback {backup_id}',
                    '',
                    'Windows (PowerShell as Admin):',
                    f'  .\\scripts\\toolkit-updater.ps1 -Command rollback',
                ],
                'backup_id': backup_id,
                'backup_version': metadata.get('version', 'unknown'),
            })

    except Exception as e:
        logger.error(f"Rollback error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# Registration
# =============================================================================

def register_update_routes(app):
    """Register update routes with Flask app."""
    app.register_blueprint(update_bp)
    logger.info("Update API routes registered")
