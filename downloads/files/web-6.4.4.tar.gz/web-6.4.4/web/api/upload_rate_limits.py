"""
Unified upload rate-limit helpers for all agent upload endpoints.

These helpers read SuperAdmin security settings and return Flask-Limiter
compatible limit strings (e.g., "100 per hour").

Two types of limits:
- License-capped: Enforces minimum of configured value and license tier cap
- Uncapped: Uses configured value directly (for features independent of licensing)
"""

from security_settings import get_security_setting


def _get_license_upload_cap_per_hour():
    """
    Return license-driven upload cap per hour.

    Requested policy:
      - Free: 25
      - Professional: 100
      - Enterprise: unlimited

    Business tier remains more permissive than Professional (500) to preserve
    existing product semantics.
    """
    try:
        from services_pkg.services.license_service import get_license_service, LicenseTier

        service = get_license_service()
        tier = service.license_info.tier

        if tier == LicenseTier.ENTERPRISE:
            return None  # unlimited
        if tier == LicenseTier.BUSINESS:
            return 500
        if tier == LicenseTier.PROFESSIONAL:
            return 100
        return 25
    except Exception:
        return None


def _sanitize_per_hour(value, default_value):
    """Sanitize per-hour integer limit with safe bounds."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default_value

    if parsed < 10:
        parsed = 10
    if parsed > 1000000:
        parsed = 1000000
    return parsed


def _sanitize_per_minute(value, default_value):
    """Sanitize per-minute integer limit with safe bounds."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default_value

    if parsed < 1:
        parsed = 1
    if parsed > 10000:
        parsed = 10000
    return parsed


def _per_hour_limit(setting_key, default_value):
    """Build a Flask-Limiter limit string from a security setting (license-capped)."""
    configured = get_security_setting(setting_key, default_value)
    per_hour = _sanitize_per_hour(configured, default_value)

    license_cap = _get_license_upload_cap_per_hour()
    if license_cap is not None:
        per_hour = min(per_hour, license_cap)

    return f"{per_hour} per hour"


def _per_hour_limit_uncapped(setting_key, default_value):
    """Build a Flask-Limiter limit string (no license cap - for feature-specific limits)."""
    configured = get_security_setting(setting_key, default_value)
    per_hour = _sanitize_per_hour(configured, default_value)
    return f"{per_hour} per hour"


def _per_minute_limit(setting_key, default_value):
    """Build a Flask-Limiter limit string for per-minute limits (no license cap)."""
    configured = get_security_setting(setting_key, default_value)
    per_minute = _sanitize_per_minute(configured, default_value)
    return f"{per_minute} per minute"


def get_standalone_upload_limit():
    """Rate limit for standalone agent upload endpoint (license-capped)."""
    return _per_hour_limit('standalone_agent_results_rate_limit_per_hour', 100)


def get_managed_upload_limit():
    """Rate limit for fleet agent upload endpoint (license-capped)."""
    return _per_hour_limit('fleet_agent_results_rate_limit_per_hour', 200)


def get_hypervisor_upload_limit():
    """Rate limit for hypervisor agent upload endpoint (license-capped)."""
    return _per_hour_limit('hypervisor_agent_results_rate_limit_per_hour', 200)


def get_asset_discovery_upload_limit():
    """Rate limit for asset discovery sync upload endpoint (uncapped - independent of license)."""
    return _per_hour_limit_uncapped('asset_discovery_results_rate_limit_per_hour', 200)


# =============================================================================
# Authentication Rate Limits (Security-Critical - Not License-Capped)
# =============================================================================

def get_login_rate_limit():
    """Rate limit for login attempts (prevents brute force)."""
    return _per_minute_limit('auth_login_rate_limit_per_minute', 5)


def get_password_reset_rate_limit():
    """Rate limit for password reset requests."""
    return _per_minute_limit('auth_password_reset_rate_limit_per_minute', 3)


def get_registration_rate_limit():
    """Rate limit for user registration requests."""
    return _per_minute_limit('auth_registration_rate_limit_per_minute', 5)


def get_2fa_rate_limit():
    """Rate limit for 2FA verification attempts."""
    return _per_minute_limit('auth_2fa_rate_limit_per_minute', 10)


# =============================================================================
# API Operation Rate Limits (Not License-Capped)
# =============================================================================

def get_api_general_rate_limit():
    """Rate limit for general API read operations."""
    return _per_minute_limit('api_general_rate_limit_per_minute', 100)


def get_api_write_rate_limit():
    """Rate limit for API write operations (create/update/delete)."""
    return _per_minute_limit('api_write_rate_limit_per_minute', 30)


def get_api_export_rate_limit():
    """Rate limit for export operations (CSV, PDF, etc.)."""
    return _per_minute_limit('api_export_rate_limit_per_minute', 10)


def get_api_import_rate_limit():
    """Rate limit for import operations (bulk uploads)."""
    return _per_minute_limit('api_import_rate_limit_per_minute', 5)


def get_api_search_rate_limit():
    """Rate limit for search/filter operations."""
    return _per_minute_limit('api_search_rate_limit_per_minute', 60)


# =============================================================================
# Scheduled Operations Rate Limits (Not License-Capped)
# =============================================================================

def get_schedule_list_rate_limit():
    """Rate limit for listing schedules."""
    return _per_minute_limit('schedule_list_rate_limit_per_minute', 100)


def get_schedule_create_rate_limit():
    """Rate limit for creating schedules."""
    return _per_minute_limit('schedule_create_rate_limit_per_minute', 20)


def get_schedule_run_rate_limit():
    """Rate limit for manually triggering scheduled jobs."""
    return _per_minute_limit('schedule_run_rate_limit_per_minute', 10)


def get_report_generate_rate_limit():
    """Rate limit for generating reports."""
    return _per_minute_limit('report_generate_rate_limit_per_minute', 10)


# =============================================================================
# Agent Communication Rate Limits (Not License-Capped)
# =============================================================================

def get_agent_heartbeat_rate_limit():
    """Rate limit for agent heartbeat requests."""
    return _per_minute_limit('agent_heartbeat_rate_limit_per_minute', 30)


def get_agent_command_poll_rate_limit():
    """Rate limit for agent command polling."""
    return _per_minute_limit('agent_command_poll_rate_limit_per_minute', 20)


def get_agent_registration_rate_limit():
    """Rate limit for agent registration requests."""
    return _per_minute_limit('agent_registration_rate_limit_per_minute', 5)


# =============================================================================
# Audit Execution Rate Limits (Not License-Capped)
# =============================================================================

def get_audit_start_rate_limit():
    """Rate limit for starting audits."""
    return _per_minute_limit('audit_start_rate_limit_per_minute', 10)


def get_audit_status_rate_limit():
    """Rate limit for checking audit status."""
    return _per_minute_limit('audit_status_rate_limit_per_minute', 60)


def get_upload_limit_observability_snapshot():
    """
    Return current license tier and effective upload limits for observability.

    This is intended for startup/runtime logs so operators can quickly confirm
    active policy during staging/beta/production rollouts.
    """
    tier = "unknown"
    try:
        from services_pkg.services.license_service import get_license_service
        tier = get_license_service().license_info.tier.value
    except Exception:
        tier = "unknown"

    return {
        "tier": tier,
        # Upload limits (license-capped for standalone/managed/hypervisor)
        "standalone": get_standalone_upload_limit(),
        "managed": get_managed_upload_limit(),
        "hypervisor": get_hypervisor_upload_limit(),
        "asset_discovery": get_asset_discovery_upload_limit(),  # Note: Uncapped
    }


def get_rate_limit_observability_full():
    """
    Return comprehensive rate limit snapshot for all configurable limits.

    This provides full visibility into all active rate limits for debugging
    and operational monitoring.
    """
    tier = "unknown"
    try:
        from services_pkg.services.license_service import get_license_service
        tier = get_license_service().license_info.tier.value
    except Exception:
        tier = "unknown"

    return {
        "license_tier": tier,
        "upload_limits": {
            "standalone": get_standalone_upload_limit(),
            "managed": get_managed_upload_limit(),
            "hypervisor": get_hypervisor_upload_limit(),
            "asset_discovery": get_asset_discovery_upload_limit(),
        },
        "auth_limits": {
            "login": get_login_rate_limit(),
            "password_reset": get_password_reset_rate_limit(),
            "registration": get_registration_rate_limit(),
            "2fa": get_2fa_rate_limit(),
        },
        "api_limits": {
            "general": get_api_general_rate_limit(),
            "write": get_api_write_rate_limit(),
            "export": get_api_export_rate_limit(),
            "import": get_api_import_rate_limit(),
            "search": get_api_search_rate_limit(),
        },
        "schedule_limits": {
            "list": get_schedule_list_rate_limit(),
            "create": get_schedule_create_rate_limit(),
            "run": get_schedule_run_rate_limit(),
            "report_generate": get_report_generate_rate_limit(),
        },
        "agent_limits": {
            "heartbeat": get_agent_heartbeat_rate_limit(),
            "command_poll": get_agent_command_poll_rate_limit(),
            "registration": get_agent_registration_rate_limit(),
        },
        "audit_limits": {
            "start": get_audit_start_rate_limit(),
            "status": get_audit_status_rate_limit(),
        },
    }
