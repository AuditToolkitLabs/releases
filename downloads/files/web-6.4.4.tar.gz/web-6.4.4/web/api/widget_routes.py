#!/usr/bin/env python3
"""
Dashboard Widget API Routes

Provides comprehensive dashboard widget management:
- Layout CRUD operations (create, read, update, delete)
- Widget CRUD within layouts
- Widget data retrieval (real-time metrics)
- Template-based layout creation
- User layout preferences

Author: Security Audit Toolkit Team
Date: February 10, 2026
"""

from flask import Blueprint, jsonify, request, session
from sqlalchemy import or_, func, desc
from datetime import datetime, timedelta
import json
import os
import shutil
from auth_core import require_api_key, conditional_limit
from config import SessionLocal, logger, ROOT_DIR
from models.dashboard_widget import (
    DashboardWidget, DashboardLayout, WIDGET_TYPES, DEFAULT_LAYOUTS,
    get_widget_types, get_default_layouts, create_layout_from_template
)
from models.database import Server, Audit, AuditExecution

# Create blueprint
widget_bp = Blueprint('widgets', __name__, url_prefix='/api/dashboard')


# ============================================================================
# Widget Type Catalog
# ============================================================================

@widget_bp.route('/widget-types', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_widget_types():
    """
    List all available widget types

    Returns:
        JSON: Array of widget type definitions with config schemas
    """
    return jsonify({
        'success': True,
        'widget_types': get_widget_types(),
        'total': len(WIDGET_TYPES)
    })


@widget_bp.route('/layout-templates', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_layout_templates():
    """
    List available default layout templates

    Returns:
        JSON: Array of template definitions
    """
    return jsonify({
        'success': True,
        'templates': get_default_layouts(),
        'total': len(DEFAULT_LAYOUTS)
    })


# ============================================================================
# Dashboard Layouts
# ============================================================================

@widget_bp.route('/layouts', methods=['GET'])
@require_api_key
@conditional_limit("50 per minute")
def list_layouts():
    """
    List dashboard layouts for current user

    Query Parameters:
        include_shared (bool): Include shared layouts (default: true)
        include_system (bool): Include system templates (default: true)

    Returns:
        JSON: List of layouts
    """
    db = SessionLocal()

    try:
        user_id = session.get('username', 'anonymous')
        include_shared = request.args.get('include_shared', 'true').lower() == 'true'
        include_system = request.args.get('include_system', 'true').lower() == 'true'

        # Build query
        conditions = [DashboardLayout.user_id == user_id]

        if include_shared:
            conditions.append(DashboardLayout.is_shared.is_(True))
        if include_system:
            conditions.append(DashboardLayout.is_system.is_(True))

        layouts = db.query(DashboardLayout).filter(
            or_(*conditions)
        ).order_by(DashboardLayout.is_default.desc(), DashboardLayout.name).all()

        return jsonify({
            'success': True,
            'layouts': [layout.to_dict(include_widgets=False) for layout in layouts],
            'total': len(layouts)
        })

    except Exception as e:
        try:
            db.rollback()
        except Exception as rollback_error:
            logger.debug(f"Widget layout rollback skipped after error: {rollback_error}")

        error_text = str(e).lower()
        if 'dashboard_layouts' in error_text and 'does not exist' in error_text:
            logger.warning("dashboard_layouts table missing; returning empty layouts")
            return jsonify({
                'success': True,
                'layouts': [],
                'total': 0
            })

        logger.error(f"Error listing layouts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts/<int:layout_id>', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def get_layout(layout_id):
    """
    Get a specific layout with all widgets

    Path Parameters:
        layout_id (int): Layout ID

    Returns:
        JSON: Layout with widgets array
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()

        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        return jsonify({
            'success': True,
            'layout': layout.to_dict(include_widgets=True)
        })

    except Exception as e:
        logger.error(f"Error getting layout {layout_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts', methods=['POST'])
@require_api_key
@conditional_limit("20 per minute")
def create_layout():
    """
    Create a new dashboard layout

    Request Body:
        name (str): Layout name (required)
        description (str): Description (optional)
        template (str): Template key to clone from (optional)
        grid_columns (int): Grid columns (default: 4)
        grid_row_height (int): Row height pixels (default: 150)
        theme (str): Theme name (default: 'default')

    Returns:
        JSON: Created layout
    """
    db = SessionLocal()

    try:
        data = request.json
        user_id = session.get('username', 'anonymous')

        # Use template if specified
        if data.get('template'):
            layout = create_layout_from_template(
                db,
                data['template'],
                user_id,
                name=data.get('name')
            )
            if not layout:
                return jsonify({
                    'success': False,
                    'error': f"Template '{data['template']}' not found"
                }), 404

            db.commit()
            db.refresh(layout)

            logger.info(f"Created layout from template: {layout.name}")

            return jsonify({
                'success': True,
                'layout': layout.to_dict(include_widgets=True),
                'message': 'Layout created from template'
            }), 201

        # Create empty layout
        if 'name' not in data:
            return jsonify({'success': False, 'error': 'name is required'}), 400

        layout = DashboardLayout(
            name=data['name'],
            description=data.get('description'),
            user_id=user_id,
            is_default=data.get('is_default', False),
            is_shared=data.get('is_shared', False),
            grid_columns=data.get('grid_columns', 4),
            grid_row_height=data.get('grid_row_height', 150),
            theme=data.get('theme', 'default')
        )

        db.add(layout)

        # If set as default, unset others
        if layout.is_default:
            db.query(DashboardLayout).filter(
                DashboardLayout.user_id == user_id,
                DashboardLayout.id != layout.id
            ).update({'is_default': False})

        db.commit()
        db.refresh(layout)

        logger.info(f"Created layout: {layout.name}")

        return jsonify({
            'success': True,
            'layout': layout.to_dict(include_widgets=True),
            'message': 'Layout created successfully'
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error creating layout: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts/<int:layout_id>', methods=['PUT'])
@require_api_key
@conditional_limit("20 per minute")
def update_layout(layout_id):
    """
    Update a dashboard layout

    Path Parameters:
        layout_id (int): Layout ID

    Request Body:
        Any layout fields to update

    Returns:
        JSON: Updated layout
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()
        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        data = request.json
        user_id = session.get('username', 'anonymous')

        # Updatable fields
        for field in ['name', 'description', 'grid_columns', 'grid_row_height', 'theme', 'is_shared']:
            if field in data:
                setattr(layout, field, data[field])

        # Handle default flag
        if data.get('is_default'):
            layout.is_default = True
            db.query(DashboardLayout).filter(
                DashboardLayout.user_id == user_id,
                DashboardLayout.id != layout_id
            ).update({'is_default': False})

        layout.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(layout)

        logger.info(f"Updated layout: {layout.name}")

        return jsonify({
            'success': True,
            'layout': layout.to_dict(include_widgets=True),
            'message': 'Layout updated successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating layout {layout_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts/<int:layout_id>', methods=['DELETE'])
@require_api_key
@conditional_limit("20 per minute")
def delete_layout(layout_id):
    """
    Delete a dashboard layout

    Path Parameters:
        layout_id (int): Layout ID

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()
        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        if layout.is_system:
            return jsonify({
                'success': False,
                'error': 'Cannot delete system layouts'
            }), 400

        layout_name = layout.name
        db.delete(layout)  # Cascade deletes widgets
        db.commit()

        logger.info(f"Deleted layout: {layout_name}")

        return jsonify({
            'success': True,
            'message': f'Layout "{layout_name}" deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting layout {layout_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Widget Management
# ============================================================================

@widget_bp.route('/layouts/<int:layout_id>/widgets', methods=['GET'])
@require_api_key
@conditional_limit("100 per minute")
def list_widgets(layout_id):
    """
    List all widgets in a layout

    Path Parameters:
        layout_id (int): Layout ID

    Returns:
        JSON: Array of widgets
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()
        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        widgets = db.query(DashboardWidget).filter(
            DashboardWidget.layout_id == layout_id
        ).order_by(DashboardWidget.position_y, DashboardWidget.position_x).all()

        return jsonify({
            'success': True,
            'widgets': [w.to_dict() for w in widgets],
            'total': len(widgets)
        })

    except Exception as e:
        logger.error(f"Error listing widgets: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts/<int:layout_id>/widgets', methods=['POST'])
@require_api_key
@conditional_limit("30 per minute")
def add_widget(layout_id):
    """
    Add a widget to a layout

    Path Parameters:
        layout_id (int): Layout ID

    Request Body:
        widget_type (str): Widget type key (required)
        title (str): Custom title (optional)
        position (object): {x, y, w, h} grid position
        config (object): Widget-specific configuration
        refresh_interval (int): Refresh interval in seconds

    Returns:
        JSON: Created widget
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()
        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        data = request.json
        user_id = session.get('username', 'anonymous')

        # Validate widget type
        widget_type = data.get('widget_type')
        if not widget_type or widget_type not in WIDGET_TYPES:
            return jsonify({
                'success': False,
                'error': f"Invalid widget_type. Available: {list(WIDGET_TYPES.keys())}"
            }), 400

        # Get position or use defaults
        position = data.get('position', {})
        widget_def = WIDGET_TYPES[widget_type]

        widget = DashboardWidget(
            widget_type=widget_type,
            title=data.get('title'),
            position_x=position.get('x', 0),
            position_y=position.get('y', 0),
            width=position.get('w', widget_def['default_size']['w']),
            height=position.get('h', widget_def['default_size']['h']),
            config=json.dumps(data.get('config', {})),
            refresh_interval=data.get('refresh_interval', 60),
            alert_enabled=data.get('alert_enabled', False),
            alert_threshold_warning=data.get('alert_threshold_warning'),
            alert_threshold_critical=data.get('alert_threshold_critical'),
            layout_id=layout_id,
            created_by=user_id
        )

        db.add(widget)
        db.commit()
        db.refresh(widget)

        logger.info(f"Added widget {widget_type} to layout {layout.name}")

        return jsonify({
            'success': True,
            'widget': widget.to_dict(),
            'message': 'Widget added successfully'
        }), 201

    except Exception as e:
        db.rollback()
        logger.error(f"Error adding widget: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/widgets/<int:widget_id>', methods=['PUT'])
@require_api_key
@conditional_limit("30 per minute")
def update_widget(widget_id):
    """
    Update a widget

    Path Parameters:
        widget_id (int): Widget ID

    Request Body:
        Any widget fields to update

    Returns:
        JSON: Updated widget
    """
    db = SessionLocal()

    try:
        widget = db.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
        if not widget:
            return jsonify({'success': False, 'error': 'Widget not found'}), 404

        data = request.json

        # Update simple fields
        for field in ['title', 'refresh_interval', 'alert_enabled',
                      'alert_threshold_warning', 'alert_threshold_critical', 'is_visible']:
            if field in data:
                setattr(widget, field, data[field])

        # Update position
        if 'position' in data:
            pos = data['position']
            if 'x' in pos:
                widget.position_x = pos['x']
            if 'y' in pos:
                widget.position_y = pos['y']
            if 'w' in pos:
                widget.width = pos['w']
            if 'h' in pos:
                widget.height = pos['h']

        # Update config
        if 'config' in data:
            widget.config = json.dumps(data['config'])

        widget.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(widget)

        return jsonify({
            'success': True,
            'widget': widget.to_dict(),
            'message': 'Widget updated successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error updating widget {widget_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/widgets/<int:widget_id>', methods=['DELETE'])
@require_api_key
@conditional_limit("30 per minute")
def delete_widget(widget_id):
    """
    Delete a widget

    Path Parameters:
        widget_id (int): Widget ID

    Returns:
        JSON: Deletion confirmation
    """
    db = SessionLocal()

    try:
        widget = db.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
        if not widget:
            return jsonify({'success': False, 'error': 'Widget not found'}), 404

        db.delete(widget)
        db.commit()

        return jsonify({
            'success': True,
            'message': 'Widget deleted successfully'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting widget {widget_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/layouts/<int:layout_id>/widgets/batch', methods=['PUT'])
@require_api_key
@conditional_limit("10 per minute")
def batch_update_widgets(layout_id):
    """
    Batch update widget positions (for drag-and-drop)

    Path Parameters:
        layout_id (int): Layout ID

    Request Body:
        widgets (array): [{id, position: {x, y, w, h}}, ...]

    Returns:
        JSON: Update confirmation
    """
    db = SessionLocal()

    try:
        layout = db.query(DashboardLayout).filter(DashboardLayout.id == layout_id).first()
        if not layout:
            return jsonify({'success': False, 'error': 'Layout not found'}), 404

        data = request.json
        widgets_data = data.get('widgets', [])

        updated = 0
        for w in widgets_data:
            widget = db.query(DashboardWidget).filter(
                DashboardWidget.id == w['id'],
                DashboardWidget.layout_id == layout_id
            ).first()

            if widget and 'position' in w:
                pos = w['position']
                widget.position_x = pos.get('x', widget.position_x)
                widget.position_y = pos.get('y', widget.position_y)
                widget.width = pos.get('w', widget.width)
                widget.height = pos.get('h', widget.height)
                widget.updated_at = datetime.utcnow()
                updated += 1

        db.commit()

        return jsonify({
            'success': True,
            'updated': updated,
            'message': f'{updated} widget positions updated'
        })

    except Exception as e:
        db.rollback()
        logger.error(f"Error batch updating widgets: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


# ============================================================================
# Widget Data Retrieval
# ============================================================================

@widget_bp.route('/widgets/<int:widget_id>/data', methods=['GET'])
@require_api_key
@conditional_limit("200 per minute")
def get_widget_data(widget_id):
    """
    Get real-time data for a specific widget

    Path Parameters:
        widget_id (int): Widget ID

    Returns:
        JSON: Widget data based on type
    """
    db = SessionLocal()

    try:
        widget = db.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
        if not widget:
            return jsonify({'success': False, 'error': 'Widget not found'}), 404

        config = json.loads(widget.config) if widget.config else {}
        data = _get_data_for_widget_type(db, widget.widget_type, config)

        return jsonify({
            'success': True,
            'widget_id': widget_id,
            'widget_type': widget.widget_type,
            'data': data,
            'timestamp': datetime.utcnow().isoformat()
        })

    except Exception as e:
        logger.error(f"Error getting widget data: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


@widget_bp.route('/widget-data/<widget_type>', methods=['GET'])
@require_api_key
@conditional_limit("200 per minute")
def get_widget_type_data(widget_type):
    """
    Get data for a widget type with inline config

    Path Parameters:
        widget_type (str): Widget type key

    Query Parameters:
        Varies by widget type (see config schemas)

    Returns:
        JSON: Widget data
    """
    db = SessionLocal()

    try:
        if widget_type not in WIDGET_TYPES:
            return jsonify({
                'success': False,
                'error': f"Unknown widget type: {widget_type}"
            }), 400

        # Parse config from query params
        config = {}
        for key in request.args:
            value = request.args.get(key)
            # Try to parse as JSON for arrays/objects
            try:
                config[key] = json.loads(value)
            except (json.JSONDecodeError, TypeError):
                config[key] = value

        data = _get_data_for_widget_type(db, widget_type, config)

        return jsonify({
            'success': True,
            'widget_type': widget_type,
            'data': data,
            'timestamp': datetime.utcnow().isoformat()
        })

    except Exception as e:
        logger.error(f"Error getting widget type data: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        db.close()


def _get_data_for_widget_type(db, widget_type, config):
    """Fetch data based on widget type and configuration"""

    if widget_type == 'stat_card':
        return _get_stat_card_data(db, config)

    elif widget_type == 'trend_chart':
        return _get_trend_data(db, config)

    elif widget_type == 'recent_executions':
        return _get_recent_executions_data(db, config)

    elif widget_type == 'top_risks':
        return _get_top_risks_data(db, config)

    elif widget_type == 'domain_breakdown':
        return _get_domain_breakdown_data(db, config)

    elif widget_type == 'server_group_status':
        return _get_server_group_status_data(db, config)

    elif widget_type == 'compliance_gauge':
        return _get_compliance_data(db, config)

    elif widget_type == 'schedule_timeline':
        return _get_schedule_timeline_data(db, config)

    elif widget_type == 'maintenance_window':
        return _get_maintenance_window_data(db, config)

    elif widget_type == 'execution_queue':
        return _get_execution_queue_data(db, config)

    elif widget_type == 'server_health_map':
        return _get_server_health_map_data(db, config)

    elif widget_type == 'critical_findings':
        return _get_critical_findings_data(db, config)

    elif widget_type == 'storage_pressure':
        return _get_storage_pressure_data(db, config)

    return {}


def _get_stat_card_data(db, config):
    """Get data for stat card widget"""
    metric = config.get('metric', 'total_servers')

    if metric == 'total_servers':
        value = db.query(Server).count()
    elif metric == 'total_audits':
        value = db.query(Audit).count()
    elif metric == 'pass_rate':
        # Calculate from last 30 days
        cutoff = datetime.utcnow() - timedelta(days=30)
        executions = db.query(AuditExecution).filter(
            AuditExecution.executed_at >= cutoff
        ).all()

        total_checks = 0
        total_pass = 0
        for e in executions:
            if e.summary:
                try:
                    s = json.loads(e.summary) if isinstance(e.summary, str) else e.summary
                    total_pass += s.get('pass', 0)
                    total_checks += s.get('pass', 0) + s.get('warn', 0) + s.get('fail', 0)
                except Exception as ex:
                    logger.debug(f"Failed to parse execution summary: {ex}")

        value = round(total_pass / max(total_checks, 1) * 100, 1)
    elif metric in ('fail_count', 'warn_count'):
        cutoff = datetime.utcnow() - timedelta(days=7)
        executions = db.query(AuditExecution).filter(
            AuditExecution.executed_at >= cutoff
        ).all()

        value = 0
        key = 'fail' if metric == 'fail_count' else 'warn'
        for e in executions:
            if e.summary:
                try:
                    s = json.loads(e.summary) if isinstance(e.summary, str) else e.summary
                    value += s.get(key, 0)
                except Exception as ex:
                    logger.debug(f"Failed to parse summary for {metric}: {ex}")
    elif metric == 'active_schedules':
        from models.schedule import ScheduledAudit
        value = db.query(ScheduledAudit).filter(ScheduledAudit.is_active.is_(True)).count()
    elif metric == 'pending_tasks':
        # Count running tasks (requires Celery integration)
        value = 0
    else:
        value = 0

    return {
        'metric': metric,
        'value': value,
        'title': config.get('title'),
        'icon': config.get('icon'),
        'color': config.get('color')
    }


def _get_trend_data(db, config):
    """Get trend chart data"""
    days = min(int(config.get('days', 7)), 60)
    metrics = config.get('metrics', ['pass_count', 'warn_count', 'fail_count'])

    result = {
        'labels': [],
        'datasets': {m: [] for m in metrics}
    }

    for i in range(days - 1, -1, -1):
        date = datetime.utcnow().date() - timedelta(days=i)
        start = datetime.combine(date, datetime.min.time())
        end = datetime.combine(date, datetime.max.time())

        executions = db.query(AuditExecution).filter(
            AuditExecution.executed_at >= start,
            AuditExecution.executed_at <= end
        ).all()

        day_totals = {'pass_count': 0, 'warn_count': 0, 'fail_count': 0, 'execution_count': len(executions)}  # nosec B105 - metric keys, not credentials

        for e in executions:
            if e.summary:
                try:
                    s = json.loads(e.summary) if isinstance(e.summary, str) else e.summary
                    day_totals['pass_count'] += s.get('pass', 0)
                    day_totals['warn_count'] += s.get('warn', 0)
                    day_totals['fail_count'] += s.get('fail', 0)
                except Exception as ex:
                    logger.debug(f"Failed to parse daily summary: {ex}")

        result['labels'].append(date.isoformat())
        for m in metrics:
            result['datasets'][m].append(day_totals.get(m, 0))

    return result


def _get_recent_executions_data(db, config):
    """Get recent executions data"""
    limit = min(int(config.get('limit', 10)), 50)
    status_filter = config.get('status_filter', 'all')
    server_id = config.get('server_id')
    group_id = config.get('group_id')

    query = db.query(AuditExecution)

    if server_id:
        query = query.filter(AuditExecution.server_id == server_id)

    if group_id:
        from models.server_group import get_servers_in_group
        servers = get_servers_in_group(group_id, db)
        server_ids = [s.id for s in servers]
        query = query.filter(AuditExecution.server_id.in_(server_ids))

    # Filter by status
    if status_filter == 'pass':
        query = query.filter(AuditExecution.exit_code == 0)
    elif status_filter == 'fail':
        query = query.filter(AuditExecution.exit_code != 0)

    executions = query.order_by(desc(AuditExecution.executed_at)).limit(limit).all()

    return {
        'executions': [
            {
                'id': e.id,
                'server_name': e.server.name if e.server else 'Unknown',
                'audit_name': e.audit.name if e.audit else 'Unknown',
                'executed_at': e.executed_at.isoformat() if e.executed_at else None,
                'exit_code': e.exit_code,
                'duration': e.duration_seconds,
                'summary': json.loads(e.summary) if e.summary else {}
            }
            for e in executions
        ],
        'total': len(executions)
    }


def _get_top_risks_data(db, config):
    """Get top risks/findings data"""
    limit = min(int(config.get('limit', 5)), 20)

    # Get recent executions with failures
    cutoff = datetime.utcnow() - timedelta(days=30)
    executions = db.query(AuditExecution).filter(
        AuditExecution.executed_at >= cutoff,
        AuditExecution.exit_code != 0
    ).order_by(desc(AuditExecution.executed_at)).limit(100).all()

    # Extract failure lines
    risks = []
    for e in executions:
        if e.output:
            lines = e.output.split('\n')
            for line in lines:
                if '[FAIL]' in line:
                    risks.append({
                        'message': line.replace('[FAIL]', '').strip()[:100],
                        'server': e.server.name if e.server else 'Unknown',
                        'audit': e.audit.name if e.audit else 'Unknown',
                        'date': e.executed_at.isoformat() if e.executed_at else None,
                        'severity': 'high'
                    })

    return {
        'risks': risks[:limit],
        'total': len(risks)
    }


def _get_domain_breakdown_data(db, config):
    """Get domain breakdown data"""
    metric = config.get('metric', 'audits')

    if metric == 'audits':
        counts = db.query(
            Audit.domain,
            func.count(Audit.id).label('count')
        ).group_by(Audit.domain).all()

        return {
            'labels': [d for d, c in counts],
            'values': [c for d, c in counts],
            'metric': metric
        }

    elif metric in ('executions', 'failures'):
        cutoff = datetime.utcnow() - timedelta(days=30)

        query = db.query(
            Audit.domain,
            func.count(AuditExecution.id).label('count')
        ).join(AuditExecution).filter(
            AuditExecution.executed_at >= cutoff
        )

        if metric == 'failures':
            query = query.filter(AuditExecution.exit_code != 0)

        counts = query.group_by(Audit.domain).all()

        return {
            'labels': [d for d, c in counts],
            'values': [c for d, c in counts],
            'metric': metric
        }

    return {'labels': [], 'values': [], 'metric': metric}


def _get_server_group_status_data(db, config):
    """Get server group status data"""
    group_id = config.get('group_id')
    if not group_id:
        return {'error': 'group_id required'}

    from models.server_group import ServerGroup, get_servers_in_group

    group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
    if not group:
        return {'error': 'Group not found'}

    servers = get_servers_in_group(group_id, db)
    days = int(config.get('days', 7))
    cutoff = datetime.utcnow() - timedelta(days=days)

    # Calculate group stats
    server_ids = [s.id for s in servers]
    executions = db.query(AuditExecution).filter(
        AuditExecution.server_id.in_(server_ids),
        AuditExecution.executed_at >= cutoff
    ).all()

    total_pass = 0
    total_fail = 0
    for e in executions:
        if e.exit_code == 0:
            total_pass += 1
        else:
            total_fail += 1

    pass_rate = round(total_pass / max(total_pass + total_fail, 1) * 100, 1)

    result = {
        'group_id': group_id,
        'group_name': group.name,
        'color': group.color,
        'server_count': len(servers),
        'execution_count': len(executions),
        'pass_rate': pass_rate,
        'status': 'healthy' if pass_rate >= 90 else 'warning' if pass_rate >= 70 else 'critical'
    }

    if config.get('show_servers'):
        result['servers'] = [
            {'id': s.id, 'name': s.name, 'hostname': s.hostname}
            for s in servers[:20]
        ]

    return result


def _get_compliance_data(db, config):
    """Get compliance gauge data"""
    framework = config.get('framework', 'overall')

    # Calculate overall compliance from last 30 days
    cutoff = datetime.utcnow() - timedelta(days=30)
    executions = db.query(AuditExecution).filter(
        AuditExecution.executed_at >= cutoff
    ).all()

    total_checks = 0
    total_pass = 0

    for e in executions:
        if e.summary:
            try:
                s = json.loads(e.summary) if isinstance(e.summary, str) else e.summary
                total_pass += s.get('pass', 0)
                total_checks += s.get('pass', 0) + s.get('warn', 0) + s.get('fail', 0)
            except Exception as ex:
                logger.debug(f"Failed to parse score summary: {ex}")

    score = round(total_pass / max(total_checks, 1) * 100, 1)

    # Determine status
    warning_threshold = int(config.get('threshold_warning', 80))
    critical_threshold = int(config.get('threshold_critical', 60))

    if score >= warning_threshold:
        status = 'good'
    elif score >= critical_threshold:
        status = 'warning'
    else:
        status = 'critical'

    return {
        'framework': framework,
        'score': score,
        'status': status,
        'total_checks': total_checks,
        'passed_checks': total_pass,
        'thresholds': {
            'warning': warning_threshold,
            'critical': critical_threshold
        }
    }


def _get_schedule_timeline_data(db, config):
    """Get schedule timeline data"""
    hours_ahead = min(int(config.get('hours_ahead', 24)), 168)  # Max 1 week
    show_maintenance = config.get('show_maintenance', True)

    from models.schedule import ScheduledAudit

    now = datetime.utcnow()
    cutoff = now + timedelta(hours=hours_ahead)

    schedules = db.query(ScheduledAudit).filter(
        ScheduledAudit.is_active.is_(True),
        ScheduledAudit.next_run <= cutoff
    ).order_by(ScheduledAudit.next_run).limit(20).all()

    events = [
        {
            'id': s.id,
            'type': 'schedule',
            'name': s.name,
            'server': s.server.name if s.server else 'Unknown',
            'scheduled_at': s.next_run.isoformat() if s.next_run else None
        }
        for s in schedules
    ]

    if show_maintenance:
        from models.maintenance_window import MaintenanceWindow

        windows = db.query(MaintenanceWindow).filter(
            MaintenanceWindow.is_active.is_(True),
            MaintenanceWindow.start_time <= cutoff,
            MaintenanceWindow.end_time >= now
        ).all()

        for w in windows:
            events.append({
                'id': w.id,
                'type': 'maintenance',
                'name': w.name,
                'start': w.start_time.isoformat() if w.start_time else None,
                'end': w.end_time.isoformat() if w.end_time else None
            })

    events.sort(key=lambda x: x.get('scheduled_at') or x.get('start') or '')

    return {'events': events, 'total': len(events)}


def _get_maintenance_window_data(db, config):
    """Get maintenance window data"""
    from models.maintenance_window import MaintenanceWindow

    days_ahead = int(config.get('days_ahead', 7))
    show_past = config.get('show_past', False)

    now = datetime.utcnow()
    cutoff = now + timedelta(days=days_ahead)

    query = db.query(MaintenanceWindow).filter(MaintenanceWindow.is_active.is_(True))

    if not show_past:
        query = query.filter(MaintenanceWindow.end_time >= now)

    query = query.filter(MaintenanceWindow.start_time <= cutoff)

    windows = query.order_by(MaintenanceWindow.start_time).all()

    return {
        'windows': [
            {
                'id': w.id,
                'name': w.name,
                'start': w.start_time.isoformat() if w.start_time else None,
                'end': w.end_time.isoformat() if w.end_time else None,
                'is_active': w.start_time <= now <= w.end_time if w.start_time and w.end_time else False
            }
            for w in windows
        ],
        'total': len(windows)
    }


def _get_execution_queue_data(db, config):
    """Get execution queue data"""
    limit = min(int(config.get('limit', 10)), 50)
    show_completed = config.get('show_completed', False)

    # Get recent executions (proxy for queue since we don't have actual queue state)
    cutoff = datetime.utcnow() - timedelta(hours=24)

    executions = db.query(AuditExecution).filter(
        AuditExecution.executed_at >= cutoff
    ).order_by(desc(AuditExecution.executed_at)).limit(limit).all()

    return {
        'tasks': [
            {
                'id': e.id,
                'server': e.server.name if e.server else 'Unknown',
                'audit': e.audit.name if e.audit else 'Unknown',
                'status': 'completed' if e.exit_code is not None else 'running',
                'result': 'pass' if e.exit_code == 0 else 'fail' if e.exit_code else 'pending',
                'started_at': e.executed_at.isoformat() if e.executed_at else None,
                'duration': e.duration_seconds
            }
            for e in executions
        ],
        'total': len(executions)
    }


def _get_server_health_map_data(db, config):
    """Get server health map data"""
    group_id = config.get('group_id')
    sort_by = config.get('sort_by', 'name')

    if group_id:
        from models.server_group import get_servers_in_group
        servers = get_servers_in_group(group_id, db)
    else:
        servers = db.query(Server).all()

    # Get latest execution status for each server
    cutoff = datetime.utcnow() - timedelta(days=7)

    server_status = []
    for s in servers:
        latest = db.query(AuditExecution).filter(
            AuditExecution.server_id == s.id,
            AuditExecution.executed_at >= cutoff
        ).order_by(desc(AuditExecution.executed_at)).first()

        if latest:
            status = 'pass' if latest.exit_code == 0 else 'fail'
        else:
            status = 'unknown'

        server_status.append({
            'id': s.id,
            'name': s.name,
            'hostname': s.hostname,
            'status': status,
            'last_audit': latest.executed_at.isoformat() if latest else None
        })

    # Sort
    if sort_by == 'status':
        order = {'fail': 0, 'unknown': 1, 'pass': 2}  # nosec B105 - status ordering map
        server_status.sort(key=lambda x: order.get(x['status'], 1))
    elif sort_by == 'last_audit':
        server_status.sort(key=lambda x: x['last_audit'] or '', reverse=True)
    else:
        server_status.sort(key=lambda x: x['name'])

    return {
        'servers': server_status,
        'total': len(server_status),
        'summary': {
            'pass': sum(1 for s in server_status if s['status'] == 'pass'),
            'fail': sum(1 for s in server_status if s['status'] == 'fail'),
            'unknown': sum(1 for s in server_status if s['status'] == 'unknown')
        }
    }


def _get_critical_findings_data(db, config):
    """Get critical findings counter data"""
    alert_threshold = int(config.get('alert_threshold', 1))

    # Count recent failures
    cutoff = datetime.utcnow() - timedelta(days=7)

    fail_count = db.query(AuditExecution).filter(
        AuditExecution.executed_at >= cutoff,
        AuditExecution.exit_code != 0
    ).count()

    return {
        'count': fail_count,
        'threshold': alert_threshold,
        'alert': fail_count >= alert_threshold,
        'severity': 'critical' if fail_count >= alert_threshold * 2 else 'high' if fail_count >= alert_threshold else 'low'
    }


def _get_storage_pressure_data(db, config):
    """Get retention/storage pressure data for dashboard widget."""

    def pressure_level(usage_pct):
        if usage_pct is None:
            return 'unbounded'
        if usage_pct >= 95:
            return 'critical'
        if usage_pct >= 80:
            return 'warning'
        return 'ok'

    def usage_ratio(current, maximum):
        if not maximum or maximum <= 0:
            return None
        return round((current / maximum) * 100, 2)

    try:
        from security_settings import get_security_setting
        max_records = int(get_security_setting('result_retention_max_records', 100000))
        standalone_cap = int(get_security_setting('standalone_agent_result_max_files_per_host', 5000))
        managed_cap = int(get_security_setting('fleet_agent_result_max_files_per_host', 5000))
        disk_guard_enabled = bool(get_security_setting('agent_result_ingest_disk_guard_enabled', True))
        min_free_disk_mb = int(get_security_setting('agent_result_ingest_min_free_disk_mb', 1024))
        min_free_disk_pct = int(get_security_setting('agent_result_ingest_min_free_disk_pct', 5))
    except Exception:
        max_records = 100000
        standalone_cap = 5000
        managed_cap = 5000
        disk_guard_enabled = True
        min_free_disk_mb = 1024
        min_free_disk_pct = 5

    execution_count = db.query(AuditExecution).count()
    db_usage = usage_ratio(execution_count, max_records)
    db_level = pressure_level(db_usage)

    host_dir = os.path.join(ROOT_DIR, 'data', 'agent_results')
    hosts = []
    total_files = 0
    if os.path.isdir(host_dir):
        for hostname in os.listdir(host_dir):
            current = os.path.join(host_dir, hostname)
            if not os.path.isdir(current):
                continue
            count = 0
            for _, _, files in os.walk(current):
                count += sum(1 for f in files if f.endswith('.json'))
            total_files += count
            hosts.append({'host': hostname, 'file_count': count})

    show_hosts = bool(config.get('show_hosts', True))
    top_hosts_limit = max(1, min(int(config.get('top_hosts_limit', 5)), 20))

    def top_pressure(cap):
        if cap <= 0:
            return []
        enriched = []
        for item in hosts:
            pct = usage_ratio(item['file_count'], cap)
            enriched.append({
                'host': item['host'],
                'file_count': item['file_count'],
                'usage_pct': pct,
                'level': pressure_level(pct),
            })
        enriched.sort(key=lambda x: x['usage_pct'] or 0, reverse=True)
        return enriched[:top_hosts_limit]

    standalone_top = top_pressure(standalone_cap)
    managed_top = top_pressure(managed_cap)

    disk_check_path = host_dir if os.path.isdir(host_dir) else os.path.join(ROOT_DIR, 'data')
    usage = shutil.disk_usage(disk_check_path)
    free_mb = usage.free // (1024 * 1024)
    free_pct = round((usage.free / usage.total * 100), 2) if usage.total > 0 else 0.0
    disk_blocked = disk_guard_enabled and (free_mb < min_free_disk_mb or free_pct < min_free_disk_pct)
    if not disk_guard_enabled:
        disk_level = 'unbounded'
    elif disk_blocked:
        disk_level = 'critical'
    elif free_mb < (min_free_disk_mb * 2) or free_pct < (min_free_disk_pct * 2):
        disk_level = 'warning'
    else:
        disk_level = 'ok'

    overall = 'ok'
    levels = [db_level, disk_level] + [h['level'] for h in standalone_top[:1]] + [h['level'] for h in managed_top[:1]]
    if 'critical' in levels:
        overall = 'critical'
    elif 'warning' in levels:
        overall = 'warning'

    return {
        'overall_level': overall,
        'database': {
            'count': execution_count,
            'max_records': max_records,
            'usage_pct': db_usage,
            'level': db_level,
        },
        'agent_results': {
            'hosts_total': len(hosts),
            'total_files': total_files,
            'standalone_cap_per_host': standalone_cap,
            'managed_cap_per_host': managed_cap,
            'top_standalone_hosts': standalone_top if show_hosts else [],
            'top_managed_hosts': managed_top if show_hosts else [],
        },
        'disk_watermark': {
            'enabled': disk_guard_enabled,
            'check_path': disk_check_path,
            'free_mb': int(free_mb),
            'free_pct': free_pct,
            'min_free_mb': min_free_disk_mb,
            'min_free_pct': min_free_disk_pct,
            'ingest_blocked': disk_blocked,
            'level': disk_level,
        },
        'thresholds': {'warning_pct': 80, 'critical_pct': 95}
    }
