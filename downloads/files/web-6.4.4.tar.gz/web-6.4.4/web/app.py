#!/usr/bin/env python3
"""
Security Audit Toolkit - Web Management Interface
Cross-platform Flask backend for orchestrator management

REFACTORED: Modular architecture with blueprints
- Core functionality in config.py, validators.py, encryption.py, auth.py
- Business logic in models/ (server, audit)
- SSH operations in ssh_manager.py
- API routes in api/ blueprints (system, server, audit, deploy, report, history, schedule)

"""

try:
    from config import app, create_app, ROOT_DIR, SSH_DIR, SERVERS_DIR, LIMITER_AVAILABLE, REDIS_ENABLED, SessionLocal, FORCE_HTTPS
except Exception as e:
    import sys
    print("ERROR importing app from config:", e, file=sys.stderr)
    raise

# ...rest of your code...

import os
import sys
import signal
import atexit
import logging
from collections import deque
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode
from flask import render_template, send_from_directory, request, redirect, url_for, jsonify

# Initialize comprehensive logging FIRST (before other imports)
from logging_config import setup_logging, correlation_id_middleware

logger = logging.getLogger(__name__)

# Setup logging based on environment
setup_logging(
    app_name='audit-toolkit',
    log_dir=Path(__file__).parent.parent / 'logs',
    log_level=os.getenv('LOG_LEVEL', 'INFO'),
    enable_json=os.getenv('LOG_FORMAT', 'json').lower() == 'json',
    enable_rotation=True,
    max_bytes=20 * 1024 * 1024,
    backup_count=14,
    rotation_when='midnight',
    rotation_interval=1
)

# Install correlation ID middleware
correlation_id_middleware(app)

# Import API key authentication (legacy)
from auth_core import API_KEY_FILE, API_KEY

# Import user authentication system (Flask-Login based)
from auth_login import init_auth

# Import SSE manager for real-time updates
from sse import init_sse_manager

# Import all API blueprints
from api import (
    system_bp, server_bp, audit_bp, async_audit_bp,
    deploy_bp, report_bp, history_bp, schedule_bp,
    backup_bp, recovery_bp, dashboard_bp, monitoring_bp
)
from api.history_analytics_routes import analytics_bp
from api.schedule_routes_v2 import schedule_v2_bp
from api.schedule_enhanced_routes import schedule_enhanced_bp
from api.batch_routes import batch_bp
from api.docs_routes import docs_bp
from api.discovery_routes import discovery_bp
from api.auth_routes import auth_bp
from api.admin_routes import admin_bp
from api.storage_routes import storage_bp
from api.ldap_routes import ldap_bp
from api.entra_routes import sso_bp, entra_admin_bp
from api.mfa_routes import mfa_bp
from api.okta_routes import okta_sso_bp, okta_admin_bp
from api.siem_routes import siem_bp
from api.auth_admin_routes import auth_admin_bp
from api.terminal_routes import terminal_bp
from api.remediation_routes import remediation_bp
from api.enhanced_report_routes import enhanced_report_bp
from api.server_group_routes import server_group_bp
from api.widget_routes import widget_bp
from api.differential_routes import differential_bp
from api.compliance_routes import compliance_bp
from api.evidence_routes import evidence_bp
from api.external_ingest_routes import external_ingest_bp
from api.push_ingest_routes import push_ingest_bp
from api.cve_routes import cve_bp
from api.scheduled_report_routes import scheduled_report_bp
from api.superadmin_routes import superadmin_bp
from api.asset_discovery_routes import asset_discovery_bp
from api.script_studio_routes import script_studio_bp
from api.unified_layout_routes import unified_layout_bp
from api.merge_routes import merge_bp
from api.license_routes import license_bp
from api.update_routes import update_bp
from api.agent_routes import agent_bp
from api.agent_fleet_routes import fleet_agent_bp, init_fleet_agent_routes
from api.agents_unified_routes import agents_unified_bp, init_unified_agent_routes
from api.beta_routes import beta_bp  # Beta/early access licensing
from api.feature_routes import feature_bp  # Feature-based licensing
from api.hypervisor_routes import hypervisor_bp  # Hypervisor management and auditing
from api.hypervisor_agent_routes import hypervisor_agent_bp  # Hypervisor fleet agent API
# Note: Keystore management consolidated into admin_routes.py

# Integration blueprints (Slack/Teams, ServiceNow/Jira, GitHub Actions)
from api.integrations import slack_teams_bp, ticketing_bp, github_actions_bp

# Import blueprint initializers
from api.system_routes import init_system_routes
from api.server_routes import init_server_routes
from api.audit_routes import init_audit_routes
from api.deploy_routes import init_deploy_routes
from api.discovery_routes import init_discovery_routes

# Import managers
from models.server import ServerManager
from ssh_manager import SSHManager

# ============================================================================
# Global State
# ============================================================================

# Track app start time for health checks
app_start_time = datetime.now()

# Maximum lines to keep in memory for execution output (circular buffer)
MAX_OUTPUT_LINES = 1000

# Execution state (shared with audit routes)
execution_state = {
    "running": False,
    "output": deque(maxlen=MAX_OUTPUT_LINES),  # Circular buffer (auto-evicts old entries)
    "summary": None,
    "start_time": None,
    "log_file": None,  # Full output written to disk
    "accepting_new": True
}

# Deployment state (shared with deploy routes)
deployment_state = {
    "deploying": False,
    "progress": [],
    "current_server": None,
    "success": None
}

# SSH control directory
SSH_CONTROL_DIR = SSH_DIR / "control"
SSH_CONTROL_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)

# Import encryption managers for SSH operations
from encryption import ssh_host_key_manager, password_manager

# Initialize managers
# ServerManager uses database storage (PostgreSQL/SQLite) by default
# Falls back to file storage if database unavailable
server_manager = ServerManager(
    servers_dir=SERVERS_DIR,
    password_manager=password_manager,  # Encrypt passwords before storage
    use_database=True
)
ssh_manager = SSHManager(
    ssh_dir=SSH_DIR,
    ssh_host_key_manager=ssh_host_key_manager,
    password_manager=password_manager
)

# Initialize SSE manager for real-time updates (requires Redis)
if REDIS_ENABLED:
    redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    sse_manager = init_sse_manager(redis_url)
    logger.info(f"SSE Manager initialized with Redis: {redis_url}")
else:
    sse_manager = init_sse_manager(None)
    logger.warning("SSE Manager initialized without Redis (SSE disabled)")

# Initialize Flask-Login authentication
if SessionLocal:
    init_auth(app, SessionLocal)
    logger.info("Flask-Login authentication initialized")
else:
    logger.warning("Database not available - Flask-Login authentication disabled")

# ============================================================================
# Initialize Blueprint State
# ============================================================================

# System routes need execution/deployment state
init_system_routes(
    exec_state=execution_state,
    deploy_state=deployment_state,
    start_time=app_start_time,
    api_key=API_KEY,
    api_key_file=API_KEY_FILE
)

# Server routes need manager instances
init_server_routes(svr_manager=server_manager, ssh_mgr=ssh_manager)

# Discovery routes need manager instances and password manager
init_discovery_routes(svr_manager=server_manager, ssh_mgr=ssh_manager, pwd_manager=password_manager)

# Audit routes need execution state
init_audit_routes(exec_state=execution_state)

# Deploy routes need deployment state
init_deploy_routes(deploy_state=deployment_state)

# Managed agent routes need database session factory for two-way API comm
if SessionLocal:
    init_fleet_agent_routes(SessionLocal)
    logger.info("Managed agent routes initialized with database session")


# ============================================================================
# Register Blueprints
# ============================================================================

# Authentication routes (login, logout, profile, password change)
app.register_blueprint(auth_bp)

# Admin routes (user management, audit log)
app.register_blueprint(admin_bp)

# Storage management routes (NFS/SMB/S3 backend)
app.register_blueprint(storage_bp)

# Superadmin Script Review routes (read-only audit script viewing)
app.register_blueprint(superadmin_bp)

# Note: Keystore management is handled via /api/admin/api-keys/* in admin_routes.py

# LDAP administration routes
app.register_blueprint(ldap_bp)

# Microsoft Entra ID (Azure AD) SSO routes
app.register_blueprint(sso_bp)
app.register_blueprint(entra_admin_bp)

# Multi-Factor Authentication (MFA) routes
app.register_blueprint(mfa_bp)

# Okta OIDC SSO routes
app.register_blueprint(okta_sso_bp)
app.register_blueprint(okta_admin_bp)

# SIEM Integration routes
app.register_blueprint(siem_bp)

# Unified Auth Admin routes
app.register_blueprint(auth_admin_bp)

# Enhanced Reporting routes (PDF, compliance, executive summaries)
app.register_blueprint(enhanced_report_bp)

# System routes (health, status, logs, settings, auth)
app.register_blueprint(system_bp)

# Server management routes
app.register_blueprint(server_bp)

# Discovery routes
app.register_blueprint(discovery_bp)

# Asset Discovery & Vulnerability Management (integrated tool)
app.register_blueprint(asset_discovery_bp, url_prefix='/asset-discovery')

# Developer Script Studio (integrated IDE for audit scripts)
app.register_blueprint(script_studio_bp)

# Unified Professional Layout (wraps console, dashboard with consistent header)
app.register_blueprint(unified_layout_bp)

# Audit routes (discovery, execution, plans)
app.register_blueprint(audit_bp)

# Async audit routes (Celery-based execution)
app.register_blueprint(async_audit_bp)

# Deployment routes
app.register_blueprint(deploy_bp)

# Agent routes (standalone agent communication)
app.register_blueprint(agent_bp)

# Managed agent routes (two-way API communication)
app.register_blueprint(fleet_agent_bp)

# Unified agent management routes (cross-agent health, stats, diagnostics)
app.register_blueprint(agents_unified_bp)
if SessionLocal:
    init_unified_agent_routes(SessionLocal)
    logger.info("Unified agent routes initialized with database session")

# Reporting and cleanup routes
app.register_blueprint(report_bp)

# History routes
app.register_blueprint(history_bp)

# Analytics routes (advanced history analytics)
app.register_blueprint(analytics_bp)

# Data merge routes (unified inventory across databases)
app.register_blueprint(merge_bp)

# License management routes (activation, status, machines)
app.register_blueprint(license_bp)

# Beta/Early Access licensing routes
app.register_blueprint(beta_bp)

# Feature-based licensing routes (SSH/WinRM, fix scripts, etc.)
app.register_blueprint(feature_bp)

# Hypervisor management and API-based auditing routes
app.register_blueprint(hypervisor_bp)

# Hypervisor fleet agent API routes (API-only agents like Proxmox, ESXi)
app.register_blueprint(hypervisor_agent_bp)

# Schedule routes
app.register_blueprint(schedule_bp)

# Schedule routes V2 (enhanced with notifications and cron parsing)
app.register_blueprint(schedule_v2_bp)

# Enhanced Scheduling routes (maintenance windows, bulk ops, templates)
app.register_blueprint(schedule_enhanced_bp)

# Scheduled PDF Report routes (recurring report delivery)
app.register_blueprint(scheduled_report_bp)

# Batch execution routes (parallel SSH for 100+ servers)
app.register_blueprint(batch_bp)

# API documentation routes (Swagger UI)
app.register_blueprint(docs_bp)

# Backup & restore routes
app.register_blueprint(backup_bp)

# Error recovery routes (DLQ, circuit breakers)
app.register_blueprint(recovery_bp)

# Dashboard routes (aggregated stats and metrics)
app.register_blueprint(dashboard_bp)

# Monitoring routes (real-time job monitoring and SSE)
app.register_blueprint(monitoring_bp)

# Terminal routes (SuperAdmin interactive SSH/WinRM terminal)
app.register_blueprint(terminal_bp)

# Remediation routes (SuperAdmin security fix application)
app.register_blueprint(remediation_bp)

# Server Group routes (group management, bulk ops, policies)
app.register_blueprint(server_group_bp)

# Dashboard Widget routes (customizable widgets, layouts)
app.register_blueprint(widget_bp)

# Differential Audit routes (compare executions, drift analysis, remediation)
app.register_blueprint(differential_bp)

# Compliance Dashboard routes (scorecard, assessments, trends)
app.register_blueprint(compliance_bp)

# Compliance Evidence Collector routes (evidence packages, exports)
app.register_blueprint(evidence_bp)

# External source ingest routes (enterprise multi-tool registration)
app.register_blueprint(external_ingest_bp)

# External push ingest routes (data-from-anywhere for third-party tools)
app.register_blueprint(push_ingest_bp)

# CVE Database routes (vulnerability intelligence, admin controls)
app.register_blueprint(cve_bp)

# Update & Patch Management routes (appliance/script updates, version checks)
app.register_blueprint(update_bp)

# ============================================================================
# External Integrations (Commercial Features)
# ============================================================================

# Slack/Teams Bot routes (daily digest, real-time alerts, slash commands)
app.register_blueprint(slack_teams_bp)

# ServiceNow/Jira Integration routes (ticketing, SLA tracking, webhooks)
app.register_blueprint(ticketing_bp)

# GitHub Actions Integration routes (workflow gen, SARIF, marketplace action)
app.register_blueprint(github_actions_bp)

logger.info("All blueprints registered")


# ============================================================================
# Error Handlers - Return JSON for API requests
# ============================================================================

@app.errorhandler(429)
def ratelimit_handler(e):
    """Return JSON response for rate limit errors on API endpoints"""
    from flask import jsonify
    if request.path.startswith('/api/'):
        return jsonify({
            "success": False,
            "error": "Rate limit exceeded",
            "message": str(e.description) if hasattr(e, 'description') else "Too many requests",
            "retry_after": e.get_response().headers.get('Retry-After', 60) if hasattr(e, 'get_response') else 60
        }), 429
    # For non-API routes, use default HTML response
    return e.get_response()


@app.errorhandler(500)
def internal_error_handler(e):
    """
    Handle internal server errors.
    In production, sanitize error messages to prevent information disclosure.
    """
    from flask import jsonify
    import os

    # Check if in debug/development mode
    is_debug = app.debug or os.environ.get(
        "FLASK_DEBUG", "false"
    ).lower() in ("true", "1", "yes")

    logger.error(f"Internal error on {request.path}: {e}", exc_info=True)

    if request.path.startswith('/api/'):
        if is_debug:
            # In debug mode, show detailed error for developers
            return jsonify({
                "success": False,
                "error": str(e.original_exception) if hasattr(e, 'original_exception') else str(e),
            }), 500
        else:
            # In production, return generic error message
            return jsonify({
                "success": False,
                "error": "An internal server error occurred",
            }), 500
    # For non-API routes, use default HTML response
    return e


# ============================================================================
# Cache Control for Development
# ============================================================================

@app.after_request
def add_cache_control_headers(response):
    """
    Disable browser caching in development mode for HTML, JS, and CSS files.
    This ensures changes are immediately visible without hard refresh.
    """
    import os
    is_debug = app.debug or os.environ.get(
        "FLASK_DEBUG", "false"
    ).lower() in ("true", "1", "yes")

    if is_debug:
        # Check if response is HTML, JS, or CSS
        content_type = response.headers.get('Content-Type', '')
        if any(ct in content_type for ct in ['text/html', 'application/javascript', 'text/css', 'text/javascript']):
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'

    return response


# ============================================================================
# HTTPS Enforcement Middleware
# ============================================================================

def get_enforce_https_setting():
    """
    Load the enforce_https setting from security settings file.
    Caches result briefly to avoid disk I/O on every request.

    Priority:
    1. FORCE_HTTPS env var (if true, always enforce)
    2. Security settings file enforce_https value
    """
    import json
    import time

    # Environment variable takes precedence
    if FORCE_HTTPS:
        return True

    # Simple cache to avoid reading file on every request
    cache_key = '_https_enforce_cache'
    cache_time_key = '_https_enforce_cache_time'
    cache_ttl = 30  # Cache for 30 seconds

    # Check cache
    cached = getattr(app, cache_key, None)
    cached_time = getattr(app, cache_time_key, 0)

    if cached is not None and (time.time() - cached_time) < cache_ttl:
        return cached

    # Load from file
    settings_file = ROOT_DIR / 'settings' / 'security_settings.json'
    enforce_https = False

    try:
        if settings_file.exists():
            with open(settings_file, 'r') as f:
                settings = json.load(f)
                enforce_https = settings.get('enforce_https', False)
    except Exception as e:
        logger.warning(f"Error reading security settings for HTTPS check: {e}")

    # Update cache
    setattr(app, cache_key, enforce_https)
    setattr(app, cache_time_key, time.time())

    return enforce_https


@app.before_request
def enforce_https_middleware():
    """
    Redirect HTTP to HTTPS when enforce_https is enabled in security settings.

    Exceptions:
    - Localhost/127.0.0.1 requests (for local development)
    - Health check endpoint (for load balancers)
    - Already HTTPS requests
    """
    # Skip if already HTTPS
    if request.is_secure:
        return None

    # Skip for localhost (development)
    if request.host.startswith('localhost') or request.host.startswith('127.0.0.1'):
        return None

    # Skip health check (load balancers may use HTTP internally)
    if request.path == '/health' or request.path == '/api/health':
        return None

    # Check if HTTPS enforcement is enabled
    if not get_enforce_https_setting():
        return None

    # Redirect to HTTPS
    logger.info(f"Redirecting HTTP to HTTPS: {request.url}")
    https_url = request.url.replace('http://', 'https://', 1)
    return redirect(https_url, code=301)


def _is_internal_agent_path(path: str) -> bool:
    """Return True for internal Toolkit↔Agent API communication paths."""
    internal_prefixes = (
        '/api/agent/',
        '/api/managed-agent/',
        '/api/hypervisor-agent/',
    )
    return path.startswith(internal_prefixes)


def _tls_version_rank(version: str) -> int:
    """Convert TLS version string to comparable rank."""
    if not version:
        return 0

    normalized = version.strip().lower().replace('_', '').replace('.', '')
    mapping = {
        'tlsv12': 12,
        'tlsv13': 13,
    }
    return mapping.get(normalized, 0)


def _normalize_fingerprint(value: str) -> str:
    """Normalize certificate fingerprint for comparison."""
    if not value:
        return ''
    return value.strip().lower().replace(':', '').replace('-', '').replace(' ', '')


@app.before_request
def enforce_internal_tls_policy_middleware():
    """
    Phase 2 (internal only): enforce TLS minimum for Toolkit↔Agent channels.

    Behavior:
    - Applies only to internal agent API paths.
    - Enforced only when tls_strict_mode is enabled.
    - Uses reverse-proxy TLS metadata header (X-TLS-Version) when available.
    """
    if not _is_internal_agent_path(request.path):
        return None

    # Allow local development loopback access (explicitly non-production path)
    if request.host.startswith('localhost') or request.host.startswith('127.0.0.1'):
        return None

    from security_settings import get_security_setting

    strict_mode = bool(get_security_setting('tls_strict_mode', False))
    if not strict_mode:
        return None

    minimum_required = str(get_security_setting('tls_minimum_version_toolkit', 'TLSv1_3'))
    minimum_rank = _tls_version_rank(minimum_required)
    pinning_enabled = bool(get_security_setting('agent_tls_pinning_enabled', False))
    pinned_hash = str(get_security_setting('agent_tls_pinned_cert_hash', '')).strip()

    forwarded_proto = (request.headers.get('X-Forwarded-Proto') or '').lower()
    tls_version = (
        request.headers.get('X-TLS-Version')
        or request.headers.get('X-SSL-Protocol')
        or request.environ.get('SSL_PROTOCOL')
        or ''
    )

    # Enforce HTTPS transport first for internal channel
    if forwarded_proto and forwarded_proto != 'https':
        return jsonify({
            'success': False,
            'error': 'tls_required',
            'message': 'Internal agent channel requires HTTPS/TLS transport.',
            'required_minimum': minimum_required,
            'received_transport': forwarded_proto,
        }), 426

    # Enforce minimum TLS version when provided by reverse proxy
    if tls_version:
        if _tls_version_rank(tls_version) < minimum_rank:
            return jsonify({
                'success': False,
                'error': 'tls_version_too_low',
                'message': 'Internal agent channel requires higher TLS version.',
                'required_minimum': minimum_required,
                'received_tls_version': tls_version,
            }), 426

    # Optional certificate pinning enforcement for internal channel
    if pinning_enabled:
        normalized_pinned = _normalize_fingerprint(pinned_hash)
        received_fingerprint = (
            request.headers.get('X-TLS-Client-Fingerprint')
            or request.headers.get('X-SSL-Client-Fingerprint')
            or ''
        )
        normalized_received = _normalize_fingerprint(received_fingerprint)

        if not normalized_pinned:
            return jsonify({
                'success': False,
                'error': 'tls_pinning_misconfigured',
                'message': 'Certificate pinning is enabled but no pinned hash is configured.',
            }), 503

        if not normalized_received:
            try:
                from logging_utils import log_audit
                log_audit(
                    action='tls_pinning_rejected',
                    resource_type='agent_channel',
                    success=False,
                    error='fingerprint_missing',
                    details={
                        'path': request.path,
                        'required_minimum': minimum_required,
                        'tls_version': tls_version or 'unknown'
                    }
                )
            except Exception as audit_log_error:
                logger.debug(f"Unable to write tls_pinning_rejected audit log (missing fingerprint): {audit_log_error}")

            return jsonify({
                'success': False,
                'error': 'tls_pinning_required',
                'message': 'Client certificate fingerprint is required for pinned internal channel.',
            }), 426

        if normalized_received != normalized_pinned:
            try:
                from logging_utils import log_audit
                log_audit(
                    action='tls_pinning_rejected',
                    resource_type='agent_channel',
                    success=False,
                    error='fingerprint_mismatch',
                    details={
                        'path': request.path,
                        'required_minimum': minimum_required,
                        'tls_version': tls_version or 'unknown',
                        'received_fingerprint': normalized_received,
                    }
                )
            except Exception as audit_log_error:
                logger.debug(f"Unable to write tls_pinning_rejected audit log (fingerprint mismatch): {audit_log_error}")

            return jsonify({
                'success': False,
                'error': 'tls_pinning_mismatch',
                'message': 'Pinned certificate fingerprint validation failed for internal channel.',
            }), 426

    if tls_version:
        return None

    # Strict mode fail-closed when TLS metadata is unavailable on secure channel
    if request.is_secure or forwarded_proto == 'https':
        return jsonify({
            'success': False,
            'error': 'tls_version_unknown',
            'message': 'TLS version metadata is required in strict mode for internal agent channel.',
            'required_minimum': minimum_required,
        }), 426

    return jsonify({
        'success': False,
        'error': 'tls_required',
        'message': 'Internal agent channel requires HTTPS/TLS transport.',
        'required_minimum': minimum_required,
    }), 426


@app.before_request
def maintenance_mode_middleware():
    """
    Block access when maintenance mode is enabled in security settings.

    Exceptions:
    - SuperAdmin users can still access
    - Health check endpoint (for monitoring)
    - Login page (so SuperAdmins can log in)
    - Static files
    """
    from security_settings import is_maintenance_mode, get_maintenance_message
    from flask_login import current_user

    # Skip if maintenance mode is disabled
    if not is_maintenance_mode():
        return None

    # Allow health checks
    if request.path in ['/health', '/api/health']:
        return None

    # Allow static files
    if request.path.startswith('/static/'):
        return None

    # Allow login-related routes
    if request.path in ['/login', '/auth/login', '/api/auth/login']:
        return None

    # Allow SuperAdmin users
    if current_user.is_authenticated:
        if hasattr(current_user, 'role') and current_user.role == 'SuperAdmin':
            return None

    # Block with maintenance message
    message = get_maintenance_message()
    if request.path.startswith('/api/'):
        return jsonify({
            'success': False,
            'error': 'maintenance_mode',
            'message': message
        }), 503

    # For web pages, show maintenance page
    return render_template('maintenance.html', message=message), 503


@app.before_request
def enforce_2fa_middleware():
    """
    Enforce MFA enrollment when enforce_2fa security setting is enabled.

    If enabled, users without MFA set up will be redirected to MFA setup page.

    Exceptions:
    - Unauthenticated users (let them reach login first)
    - MFA-related routes (so users can set up MFA)
    - Logout route (so users can sign out if needed)
    - Static files and health checks
    """
    from security_settings import get_authentication_settings
    from flask_login import current_user

    # Get enforce_2fa setting
    auth_settings = get_authentication_settings()
    if not auth_settings.get('enforce_2fa', False):
        return None

    # Only apply to authenticated users
    if not current_user.is_authenticated:
        return None

    # Allow static files
    if request.path.startswith('/static/'):
        return None

    # Allow health checks
    if request.path in ['/health', '/api/health']:
        return None

    # Allow MFA-related routes
    if '/mfa' in request.path:
        return None

    # Allow logout
    if request.path in ['/logout', '/auth/logout', '/api/auth/logout']:
        return None

    # Check if user has MFA enabled
    if hasattr(current_user, 'mfa_enabled') and current_user.mfa_enabled:
        return None

    # User must set up MFA - redirect or return error
    if request.path.startswith('/api/'):
        return jsonify({
            'success': False,
            'error': 'mfa_required',
            'message': 'MFA enrollment is required. Please set up MFA first.'
        }), 403

    # For web pages, redirect to MFA setup
    return redirect(url_for('mfa.setup_page'))


@app.before_request
def ip_whitelist_middleware():
    """
    Enforce IP whitelist/blacklist when configured in security settings.

    Enforcement order:
    1) If IP is in blacklist, deny.
    2) If whitelist is configured and IP is not in whitelist, deny.
    Supports single IPs and CIDR notation for both lists.
    """
    from security_settings import is_ip_allowed, is_ip_blocked

    # Always allow health checks (for monitoring from any IP)
    if request.path in ['/health', '/api/health']:
        return None

    client_ip = request.remote_addr

    # Check if behind a proxy and get real IP
    if request.headers.get('X-Forwarded-For'):
        client_ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()

    if is_ip_blocked(client_ip):
        logger.warning(f"Access denied from IP {client_ip} - in blacklist")
        if request.path.startswith('/api/'):
            return jsonify({
                'success': False,
                'error': 'ip_blocked',
                'message': 'Access denied. IP is in blacklist.'
            }), 403
        return "Access Denied - IP blacklisted", 403

    if not is_ip_allowed(client_ip):
        logger.warning(f"Access denied from IP {client_ip} - not in whitelist")
        if request.path.startswith('/api/'):
            return jsonify({
                'success': False,
                'error': 'ip_blocked',
                'message': 'Access denied. IP not in whitelist.'
            }), 403
        return "Access Denied - IP not allowed", 403


# ============================================================================
# Main Web Interface
# ============================================================================

@app.route('/favicon.ico')
def favicon():
    """Return a simple SVG favicon to prevent 404 errors"""
    svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
    <rect width="32" height="32" rx="4" fill="#2563eb"/>
    <text x="16" y="24" text-anchor="middle" fill="white" font-size="20" font-family="Arial">🔒</text>
    </svg>'''
    from flask import Response
    return Response(svg, mimetype='image/svg+xml')


@app.route('/')
def home():
    """Serve the home/landing page with site map and toolkit info"""
    # Read version from VERSION file
    # In Docker: /opt/audit-toolkit/VERSION (mounted volume)
    # Locally: ROOT_DIR/VERSION
    version = "6.2.1"  # Default fallback

    # Try Docker mounted path first
    version_candidates = [
        Path('/opt/audit-toolkit/VERSION'),  # Docker mount point
        ROOT_DIR / 'VERSION'  # Local/source directory
    ]

    for version_file in version_candidates:
        try:
            if version_file.exists():
                with open(version_file, 'r') as f:
                    version = f.read().strip()
                    break
        except Exception as e:
            logger.debug(f"Could not read version from {version_file}: {e}")

    return render_template('home.html', version=version)


@app.route('/home')
def home_alias():
    """Backward-compatible alias for legacy redirects to /home."""
    return redirect(url_for('home'))


@app.route('/overview')
def overview():
    """Serve the overview/documentation page (GitHub README-style)"""
    return send_from_directory('.', 'overview.html')


@app.route('/dashboard')
def dashboard():
    """
    Serve the public dashboard page.

    This is a read-only overview page accessible to all users without login.
    Shows security metrics, compliance scores, and system health status.
    """
    return send_from_directory('.', 'dashboard.html')


@app.route('/dashboard-raw')
def dashboard_raw():
    """Serve the raw dashboard page (for iframe embedding)"""
    return send_from_directory('.', 'dashboard.html')


@app.route('/pricing')
def pricing_alias():
    """Backward-compatible alias for pricing/upgrade links.

    Historically this route redirected to an internal JSON API endpoint, which
    surfaced raw JSON to end users. Route all upgrade links to the public
    pricing webpage for a consistent license-gating experience.
    """
    base = 'https://audittoolkitlabs.com/audit-admin-toolkit-pricing.html'

    # Preserve useful context so marketing/pricing pages can tailor copy.
    passthrough = {}
    for key in ('feature', 'tier', 'source'):
        value = request.args.get(key)
        if value:
            passthrough[key] = value

    target = f"{base}?{urlencode(passthrough)}" if passthrough else base
    return redirect(target)


@app.route('/console-raw')
def console_raw():
    """
    Serve the main management console - requires authentication.

    Access to console is controlled:
    1. User must be logged in (via Flask-Login or API key)
    2. Direct URL access is blocked - must come from home page
    3. User must not have pending password change requirement
    """
    from flask_login import current_user
    from auth_login import is_authenticated

    # Check if user is authenticated
    if not is_authenticated():
        logger.warning(f"Unauthenticated console access attempt from {request.remote_addr}")
        return redirect(url_for('auth.login', next=request.url))

    # Check if user must change password
    if hasattr(current_user, 'must_change_password') and current_user.must_change_password:
        logger.info(f"User {current_user.username} redirected to change password")
        return redirect(url_for('auth.change_password', next=request.url))

    # Check referrer to ensure access comes from home page (optional security)
    # Allow direct access for API key authenticated requests (automated tools)
    referrer = request.headers.get('Referer', '')
    api_key = request.headers.get('X-API-Key')  # Only from header, not session

    # If not using API key header, require referrer from this site
    if not api_key:
        if referrer and not referrer.startswith(request.host_url):
            logger.warning(f"Console access blocked - external referrer: {referrer}")
            return redirect(url_for('home'))

    # Log access
    user_info = current_user.username if hasattr(current_user, 'username') else 'api_key_user'
    logger.info(f"Console (raw) accessed by {user_info} from {request.remote_addr}")

    response = send_from_directory('.', 'index.html', max_age=0)
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


@app.route('/admin/users')
def admin_users():
    """Serve the user management admin page - requires Admin role"""
    from flask_login import current_user
    from auth_login import is_authenticated

    if not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    # Check for Admin role
    if hasattr(current_user, 'has_minimum_role'):
        if not current_user.has_minimum_role('Admin'):
            return render_template('auth/forbidden.html',
                message='Admin role required to access user management'), 403

    return render_template('admin/users.html')


@app.route('/admin/agents')
def admin_agents():
    """Standalone key management page - SuperAdmin only"""
    from flask_login import current_user
    from auth_login import is_authenticated

    if not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    if not hasattr(current_user, 'role') or current_user.role != 'SuperAdmin':
        return render_template('auth/forbidden.html',
            message='SuperAdmin role required to access standalone key management'), 403

    return render_template('admin/agents.html')


@app.route('/admin/destination-policy')
def admin_destination_policy_alias():
    """Backward-compatible alias for direct API hardening admin page."""
    return redirect('/api/admin/destination-policy-page')


@app.route('/schedules')
def schedules_page():
    """Serve the scheduled audits page - requires authentication."""
    from flask_login import current_user
    from auth_login import is_authenticated

    if not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    if hasattr(current_user, 'must_change_password') and current_user.must_change_password:
        return redirect(url_for('auth.change_password', next=request.url))

    return render_template('schedules.html')


@app.route('/reports')
def reports_page():
    """Serve the executive reports page - requires authentication"""
    from flask_login import current_user
    from auth_login import is_authenticated

    if not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    return render_template('reports.html')


@app.route('/api-docs')
def api_docs_alias():
    """Backward-compatible alias for the interactive API documentation page."""
    return redirect(url_for('docs.api_docs'))


@app.route('/deploy')
def deploy_page():
    """Serve the deployment center page - requires authentication"""
    from flask_login import current_user
    from auth_login import is_authenticated

    if not is_authenticated():
        return redirect(url_for('auth.login', next=request.url))

    if hasattr(current_user, 'must_change_password') and current_user.must_change_password:
        return redirect(url_for('auth.change_password', next=request.url))

    version = "6.2.1"
    for version_file in [Path('/opt/audit-toolkit/VERSION'), ROOT_DIR / 'VERSION']:
        try:
            if version_file.exists():
                with open(version_file, 'r') as f:
                    version = f.read().strip()
                    break
        except Exception:
            pass

    return render_template('deploy.html', version=version)


# ============================================================================
# Graceful Shutdown Handler
# ============================================================================

shutdown_requested = False

def graceful_shutdown(signum, frame):
    """Handle SIGTERM/SIGINT gracefully to prevent data loss"""
    global shutdown_requested

    if shutdown_requested:
        logger.warning("Force shutdown requested, terminating immediately")
        sys.exit(1)

    shutdown_requested = True
    logger.info("Graceful shutdown initiated...")

    # Stop accepting new work
    execution_state["accepting_new"] = False

    # Wait for current operations (max 30s)
    logger.info("Waiting for in-progress operations...")
    for i in range(30):
        if not execution_state["running"] and not deployment_state["deploying"]:
            break
        logger.debug(f"Still running... ({i+1}/30s)")
        import time
        time.sleep(1)

    # Close SSH connections
    logger.info("Closing SSH connections...")
    try:
        servers = server_manager.load_servers()
        for server in servers:
            try:
                ssh_manager.close_control_master(server)
            except Exception as e:
                logger.debug(f"SSH cleanup for {server.get('name')}: {e}")
    except Exception as e:
        logger.error(f"SSH cleanup error: {e}")

    # Clean temp files
    logger.info("Cleaning up temporary files...")
    try:
        import shutil
        if SSH_CONTROL_DIR.exists():
            shutil.rmtree(SSH_CONTROL_DIR, ignore_errors=True)
    except Exception as e:
        logger.error(f"Temp cleanup error: {e}")

    logger.info("Shutdown complete")
    sys.exit(0)


# Register shutdown handlers
signal.signal(signal.SIGTERM, graceful_shutdown)
signal.signal(signal.SIGINT, graceful_shutdown)



# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == '__main__':
    if __name__ == '__main__':
        logger.info("="*70)
        logger.info("Security Audit Toolkit - Web Management Interface")
        logger.info(f"Repository: {ROOT_DIR}")
        logger.info("="*70)
        logger.info(f"API Key: {API_KEY}")
        logger.info("Set X-API-Key header or authenticate via /api/auth")
        logger.info("="*70)
        logger.info("[*] Architecture: Modular with 8 API Blueprints")
        logger.info("   - system_bp: Health, status, logs, settings, auth")
        logger.info("   - server_bp: Server configuration and SSH management")
        logger.info("   - audit_bp: Discovery, execution, plans")
        logger.info("   - deploy_bp: Remote deployment operations")
        logger.info("   - report_bp: Reporting and cleanup")
        logger.info("   - history_bp: Execution history")
        logger.info("   - schedule_bp: Scheduled audits")
        logger.info("   - batch_bp: Parallel SSH execution")
        port = int(os.environ.get('FLASK_PORT', 5000))
        logger.info(f"Starting server on http://0.0.0.0:{port}")

        # Security warnings
        is_production = os.environ.get('FLASK_ENV') == 'production'
        debug_mode = not is_production

        if not is_production:
            logger.warning("Running in DEVELOPMENT mode")
            logger.warning("Set FLASK_ENV=production for production deployment")
        else:
            logger.info("Running in PRODUCTION mode")

        if not LIMITER_AVAILABLE:
            logger.warning("Rate limiting disabled (flask-limiter not installed)")
            logger.warning("Install with: pip install flask-limiter")
        else:
            logger.info("Rate limiting enabled")

        if not REDIS_ENABLED:
            logger.info("Using in-memory rate limiting (single-instance only)")
            logger.info("For multi-instance deployments, enable Redis:")
            logger.info("Set REDIS_ENABLED=true and REDIS_URL=redis://host:port/db")
        else:
            logger.info("Redis-backed rate limiting enabled (multi-instance support)")

        allowed_origins = os.environ.get('ALLOWED_ORIGINS', 'http://localhost:5001')
        if allowed_origins == 'http://localhost:5001':
            logger.warning("Using default CORS origins")
            logger.warning("Set ALLOWED_ORIGINS environment variable for production")
        else:
            logger.info(f"CORS allowed origins: {allowed_origins}")

        # Log configuration
        logger.info(f"Log format: {'JSON (structured)' if os.getenv('LOG_FORMAT', 'json').lower() == 'json' else 'Text'}")
        logger.info(f"Log level: {os.getenv('LOG_LEVEL', 'INFO')}")
        logger.info("Log rotation: Enabled (10MB max, 5 backups)")
        logger.info("Correlation IDs: Enabled")

        logger.info("Press Ctrl+C to stop")
        logger.info("="*70)

        # Note: use_debugger=False prevents Werkzeug from hijacking /console route
        # use_reloader=True keeps auto-reload on file changes
        # nosec B104 - Development server, production uses gunicorn behind nginx
        port = int(os.environ.get('FLASK_PORT', 5000))  # Default 5000 for standard Flask usage
        app.run(host='0.0.0.0', port=port, debug=debug_mode, threaded=True,  # nosec B104
                use_debugger=False, use_reloader=debug_mode)
    # Note: use_debugger=False prevents Werkzeug from hijacking /console route
