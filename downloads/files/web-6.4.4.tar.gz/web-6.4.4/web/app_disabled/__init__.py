from flask import Flask, send_from_directory
from web.config.config import Config
from flask_cors import CORS

def create_app():
    app = Flask(__name__, static_folder="../", static_url_path="")
    app.config.from_object(Config)
    CORS(app)

    @app.route("/")
    def index():
        # Serve the main HTML interface
        return send_from_directory(app.static_folder, "index.html")

    # Register blueprints here, for example:
    # from .views import example_bp
    # app.register_blueprint(example_bp)
    return app

# Create the app instance at module level for Gunicorn
app = create_app()
print("DEBUG: web/app/__init__.py loaded and app created")
