# --- API Key Auth Compatibility Layer ---
from pathlib import Path
from functools import wraps
from flask import request, session, jsonify
import logging

def conditional_limit(limit_string):
    """
    Conditionally apply rate limiting if limiter is available
    Args:
        limit_string: Rate limit string (e.g., "10 per minute")
    Returns:
        Decorator function that applies rate limiting if available
    Usage:
        @app.route('/api/endpoint')
        @conditional_limit("10 per minute")
        def endpoint():
            return {"status": "ok"}
    """
    def decorator(f):
        # Lazy import to avoid circular dependency
        try:
            from config import limiter
            if limiter:
                return limiter.limit(limit_string)(f)
        except (ImportError, AttributeError):
            pass
        return f
    return decorator


# Default API key file path
API_KEY_FILE = Path(__file__).parent.parent / '.api_key'

class APIKeyManager:
    def __init__(self, key_file):
        self.api_key = self._load_key(key_file)
    def _load_key(self, key_file):
        try:
            with open(key_file) as f:
                return f.read().strip()
        except Exception:
            return None
    def validate_key(self, provided_key):
        return provided_key == self.api_key

_api_key_manager = APIKeyManager(API_KEY_FILE)

# Legacy require_api_key defined here for backwards compatibility
# The primary implementation is in auth_core.py and is imported below
def _legacy_require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        provided_key = request.headers.get('X-API-Key') or session.get('api_key')
        if not provided_key:
            logging.warning(f"Unauthorized access attempt from {request.remote_addr}")
            return jsonify({"success": False, "error": "API key required"}), 401
        if not _api_key_manager.validate_key(provided_key):
            logging.warning(f"Invalid API key from {request.remote_addr}")
            return jsonify({"success": False, "error": "Invalid API key"}), 403
        return f(*args, **kwargs)
    return decorated_function

"""
Authentication Providers Module

External authentication provider integrations:
- LDAP / Active Directory
- Microsoft Entra ID (Azure AD)
- TOTP Multi-Factor Authentication
- Okta (OIDC)

Author: Security Audit Toolkit Team
Date: March 2026
"""

from .ldap_auth import LDAPAuth, LDAPAuthError
from .entra_auth import EntraAuth, EntraAuthError, EntraUser, get_entra_auth, entra_enabled
from .mfa import MFAManager, MFAError, get_mfa_manager, mfa_available, qr_code_available
from .okta import OktaAuth, OktaAuthError, OktaUser, get_okta_auth, okta_enabled


# Import API_KEY_FILE and require_api_key from the module-level auth_core.py
from auth_core import API_KEY_FILE, require_api_key


__all__ = [
    'API_KEY_FILE',
    'require_api_key',
    'conditional_limit',
    # LDAP
    'LDAPAuth',
    'LDAPAuthError',
    # Entra ID
    'EntraAuth',
    'EntraAuthError',
    'EntraUser',
    'get_entra_auth',
    'entra_enabled',
    # MFA
    'MFAManager',
    'MFAError',
    'get_mfa_manager',
    'mfa_available',
    'qr_code_available',
    # Okta
    'OktaAuth',
    'OktaAuthError',
    'OktaUser',
    'get_okta_auth',
    'okta_enabled',
]
