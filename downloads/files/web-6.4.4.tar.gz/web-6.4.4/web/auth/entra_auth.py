"""
Microsoft Entra ID (Azure AD) Authentication Module

This module provides OAuth 2.0 / OIDC authentication via Microsoft Entra ID.
It supports:
- SSO with Microsoft accounts
- Azure AD group-based role mapping
- JIT (just-in-time) user provisioning
- Conditional Access policy support (MFA handled by Azure)

Environment Configuration:
    ENTRA_ENABLED: Enable Entra ID authentication (default: false)
    ENTRA_TENANT_ID: Azure AD tenant ID
    ENTRA_CLIENT_ID: Application (client) ID
    ENTRA_CLIENT_SECRET: Client secret value
    ENTRA_REDIRECT_URI: OAuth callback URL
    ENTRA_SCOPES: Space-separated OAuth scopes
    ENTRA_ROLE_MAPPING: JSON mapping of Azure AD group IDs to roles
    ENTRA_DEFAULT_ROLE: Default role for users without mapped groups
    ENTRA_ALLOW_LOCAL_FALLBACK: Allow local auth when Entra unavailable

Usage:
    from auth.entra_auth import get_entra_auth

    entra = get_entra_auth()
    if entra.enabled:
        auth_url = entra.get_auth_url(state="random-state")
        # Redirect user to auth_url
        # On callback:
        user_info = entra.handle_callback(code="...")
"""

import json
import logging
import os
import secrets
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Try to import msal - may not be installed
try:
    import msal
    import requests as http_requests

    MSAL_AVAILABLE = True

except ImportError:
    MSAL_AVAILABLE = False
    logger.warning("msal not installed - Entra ID authentication unavailable")
    class DummyConfidentialClientApplication:
        pass
    class msal:
        ConfidentialClientApplication = DummyConfidentialClientApplication


class EntraAuthError(Exception):
    """Base exception for Entra authentication errors"""

    pass


class EntraConfigError(EntraAuthError):
    """Configuration error"""

    pass


class EntraTokenError(EntraAuthError):
    """Token acquisition error"""

    pass


class EntraGraphError(EntraAuthError):
    """Microsoft Graph API error"""

    pass


@dataclass
class EntraConfig:
    """Entra ID configuration loaded from environment variables"""

    enabled: bool = False
    tenant_id: str = ""
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = ""
    scopes: list = field(default_factory=lambda: ["openid", "profile", "email", "User.Read"])
    role_mapping: dict = field(default_factory=dict)
    default_role: str = "Viewer"
    allow_local_fallback: bool = True

    @classmethod
    def from_env(cls) -> "EntraConfig":
        """Load configuration from environment variables"""
        enabled = os.environ.get("ENTRA_ENABLED", "false").lower() in ("true", "1", "yes")

        # Parse scopes
        scopes_str = os.environ.get(
            "ENTRA_SCOPES", "openid profile email User.Read GroupMember.Read.All"
        )
        scopes = scopes_str.split()

        # Parse role mapping JSON
        role_mapping = {}
        mapping_str = os.environ.get("ENTRA_ROLE_MAPPING", "{}")
        try:
            role_mapping = json.loads(mapping_str)
        except json.JSONDecodeError as e:
            logger.warning(f"Invalid ENTRA_ROLE_MAPPING JSON: {e}")

        return cls(
            enabled=enabled,
            tenant_id=os.environ.get("ENTRA_TENANT_ID", ""),
            client_id=os.environ.get("ENTRA_CLIENT_ID", ""),
            client_secret=os.environ.get("ENTRA_CLIENT_SECRET", ""),
            redirect_uri=os.environ.get("ENTRA_REDIRECT_URI", ""),
            scopes=scopes,
            role_mapping=role_mapping,
            default_role=os.environ.get("ENTRA_DEFAULT_ROLE", "Viewer"),
            allow_local_fallback=os.environ.get("ENTRA_ALLOW_LOCAL_FALLBACK", "true").lower()
            in ("true", "1", "yes"),
        )

    def validate(self) -> tuple[bool, list[str]]:
        """
        Validate configuration.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []

        if not self.enabled:
            return True, []

        if not self.tenant_id:
            errors.append("ENTRA_TENANT_ID is required")
        if not self.client_id:
            errors.append("ENTRA_CLIENT_ID is required")
        if not self.client_secret:
            errors.append("ENTRA_CLIENT_SECRET is required")
        if not self.redirect_uri:
            errors.append("ENTRA_REDIRECT_URI is required")

        # Validate role mapping values
        valid_roles = {"SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"}
        for group_id, role in self.role_mapping.items():
            if role not in valid_roles:
                errors.append(f"Invalid role '{role}' for group {group_id}")

        if self.default_role not in valid_roles:
            errors.append(f"Invalid default role: {self.default_role}")

        return len(errors) == 0, errors


@dataclass
class EntraUser:
    """User information from Entra ID"""

    username: str
    email: str
    display_name: str
    external_id: str  # Azure AD object ID
    groups: list[str]  # List of group object IDs
    role: str  # Mapped role
    raw_claims: dict = field(default_factory=dict)


class EntraAuth:
    """
    Microsoft Entra ID (Azure AD) authentication handler.

    This class handles the OAuth 2.0 / OIDC flow with Microsoft identity platform.
    """

    # Microsoft endpoints
    AUTHORITY_BASE = "https://login.microsoftonline.com"
    GRAPH_BASE = "https://graph.microsoft.com/v1.0"

    # Role priority (highest first)
    ROLE_PRIORITY = ["SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"]

    def __init__(self, config: Optional[EntraConfig] = None):
        """
        Initialize Entra authentication handler.

        Args:
            config: Optional EntraConfig instance. If not provided, loads from environment.
        """
        if not MSAL_AVAILABLE:
            raise EntraConfigError(
                "msal library not installed. Install with: pip install msal"
            )

        self.config = config or EntraConfig.from_env()
        self._msal_app: Optional[msal.ConfidentialClientApplication] = None

    @property
    def enabled(self) -> bool:
        """Check if Entra authentication is enabled and configured"""
        if not self.config.enabled:
            return False
        is_valid, _ = self.config.validate()
        return is_valid

    @property
    def authority(self) -> str:
        """Get the Microsoft authority URL"""
        return f"{self.AUTHORITY_BASE}/{self.config.tenant_id}"

    @property
    def msal_app(self) -> msal.ConfidentialClientApplication:
        """
        Get or create the MSAL ConfidentialClientApplication instance.

        Returns:
            MSAL application instance
        """
        if self._msal_app is None:
            self._msal_app = msal.ConfidentialClientApplication(
                client_id=self.config.client_id,
                authority=self.authority,
                client_credential=self.config.client_secret,
            )
        return self._msal_app

    def get_auth_url(self, state: Optional[str] = None) -> str:
        """
        Get the Microsoft login URL for OAuth authorization.

        Args:
            state: Optional state parameter for CSRF protection.
                   If not provided, a random state is generated.

        Returns:
            Authorization URL to redirect the user to
        """
        if state is None:
            state = secrets.token_urlsafe(32)

        auth_url = self.msal_app.get_authorization_request_url(
            scopes=self.config.scopes,
            redirect_uri=self.config.redirect_uri,
            state=state,
        )

        logger.debug(f"Generated Entra auth URL with state: {state[:8]}...")
        return auth_url

    def handle_callback(self, code: str) -> EntraUser:
        """
        Handle the OAuth callback and get user information.

        Args:
            code: Authorization code from the callback

        Returns:
            EntraUser with user information and mapped role

        Raises:
            EntraTokenError: If token acquisition fails
            EntraGraphError: If Graph API call fails
        """
        # Exchange code for tokens
        result = self.msal_app.acquire_token_by_authorization_code(
            code=code,
            scopes=self.config.scopes,
            redirect_uri=self.config.redirect_uri,
        )

        if "error" in result:
            error_desc = result.get("error_description", result.get("error", "Unknown error"))
            logger.error(f"Entra token acquisition failed: {error_desc}")
            raise EntraTokenError(f"Failed to acquire token: {error_desc}")

        access_token = result.get("access_token")
        if not access_token:
            raise EntraTokenError("No access token in response")

        # Get user info from Microsoft Graph
        user_info = self._get_user_info(access_token)
        groups = self._get_user_groups(access_token)

        # Map groups to role
        role = self._map_groups_to_role(groups)

        # Extract username from UPN (remove domain part)
        upn = user_info.get("userPrincipalName", "")
        username = upn.split("@")[0] if upn else user_info.get("id", "")

        return EntraUser(
            username=username,
            email=user_info.get("mail") or upn,
            display_name=user_info.get("displayName", username),
            external_id=user_info.get("id", ""),
            groups=groups,
            role=role,
            raw_claims=user_info,
        )

    def _get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user profile from Microsoft Graph.

        Args:
            access_token: OAuth access token

        Returns:
            User profile dictionary
        """
        try:
            response = http_requests.get(
                f"{self.GRAPH_BASE}/me",
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=10,
            )
            response.raise_for_status()
            return response.json()
        except http_requests.RequestException as e:
            logger.error(f"Graph /me call failed: {e}")
            raise EntraGraphError(f"Failed to get user info: {e}")

    def _get_user_groups(self, access_token: str) -> list[str]:
        """
        Get user's group memberships from Microsoft Graph.

        Args:
            access_token: OAuth access token

        Returns:
            List of group object IDs
        """
        groups = []
        next_link = f"{self.GRAPH_BASE}/me/memberOf"

        try:
            while next_link:
                response = http_requests.get(
                    next_link,
                    headers={"Authorization": f"Bearer {access_token}"},
                    timeout=10,
                )
                response.raise_for_status()
                data = response.json()

                # Extract group IDs (filter to only groups, not roles/other types)
                for member in data.get("value", []):
                    if member.get("@odata.type") == "#microsoft.graph.group":
                        group_id = member.get("id")
                        if group_id:
                            groups.append(group_id)

                # Handle pagination
                next_link = data.get("@odata.nextLink")

        except http_requests.RequestException as e:
            logger.warning(f"Graph /me/memberOf call failed: {e}")
            # Don't raise - groups are optional, will use default role

        return groups

    def _map_groups_to_role(self, group_ids: list[str]) -> str:
        """
        Map Azure AD groups to application role.

        Uses role priority - if user is in multiple mapped groups,
        the highest-privilege role is assigned.

        Args:
            group_ids: List of Azure AD group object IDs

        Returns:
            Role name (default if no mapping matches)
        """
        for role in self.ROLE_PRIORITY:
            for group_id, mapped_role in self.config.role_mapping.items():
                if mapped_role == role and group_id in group_ids:
                    logger.debug(f"Mapped group {group_id} to role {role}")
                    return role

        logger.debug(f"No role mapping matched, using default: {self.config.default_role}")
        return self.config.default_role

    def get_logout_url(self, post_logout_redirect_uri: Optional[str] = None) -> str:
        """
        Get the Microsoft logout URL.

        Args:
            post_logout_redirect_uri: Optional URL to redirect to after logout

        Returns:
            Logout URL
        """
        url = f"{self.authority}/oauth2/v2.0/logout"
        if post_logout_redirect_uri:
            url += f"?post_logout_redirect_uri={post_logout_redirect_uri}"
        return url

    def test_configuration(self) -> dict[str, Any]:
        """
        Test the Entra configuration (without user interaction).

        Returns:
            Dictionary with test results
        """
        result = {
            "enabled": self.config.enabled,
            "msal_available": MSAL_AVAILABLE,
            "config_valid": False,
            "can_get_app_token": False,  # nosec B105
            "errors": [],
        }

        if not MSAL_AVAILABLE:
            result["errors"].append("msal library not installed")
            return result

        # Validate configuration
        is_valid, errors = self.config.validate()
        result["config_valid"] = is_valid
        result["errors"].extend(errors)

        if not is_valid:
            return result

        # Try to get an app-only token (tests client credentials)
        try:
            token_result = self.msal_app.acquire_token_for_client(
                scopes=["https://graph.microsoft.com/.default"]
            )
            if "access_token" in token_result:
                result["can_get_app_token"] = True
            else:
                result["errors"].append(
                    token_result.get("error_description", "Unknown token error")
                )
        except Exception as e:
            result["errors"].append(f"Token acquisition failed: {e}")

        return result


# Singleton instance
_entra_auth: Optional[EntraAuth] = None


def get_entra_auth() -> Optional[EntraAuth]:
    """
    Get the global EntraAuth instance.

    Returns:
        EntraAuth instance, or None if msal not available
    """
    global _entra_auth

    if not MSAL_AVAILABLE:
        return None

    if _entra_auth is None:
        try:
            _entra_auth = EntraAuth()
        except EntraConfigError as e:
            logger.warning(f"Entra auth initialization failed: {e}")
            return None

    return _entra_auth


def entra_enabled() -> bool:
    """Check if Entra authentication is enabled and available"""
    entra = get_entra_auth()
    return entra is not None and entra.enabled
