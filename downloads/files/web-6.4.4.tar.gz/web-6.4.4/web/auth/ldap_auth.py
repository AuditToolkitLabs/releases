"""
LDAP/Active Directory Authentication Module

Provides LDAP and Active Directory authentication for the Security Audit Toolkit.
Supports:
- User authentication against LDAP/AD
- Group-based role mapping
- JIT (Just-In-Time) user provisioning
- Connection testing for admin diagnostics

Environment Variables:
- LDAP_ENABLED: Enable LDAP authentication (default: false)
- LDAP_SERVER: LDAP server hostname or IP
- LDAP_PORT: LDAP port (default: 389, or 636 for SSL)
- LDAP_USE_SSL: Use SSL/TLS (default: false)
- LDAP_BIND_DN: Service account DN for binding
- LDAP_BIND_PASSWORD: Service account password
- LDAP_USER_SEARCH_BASE: Base DN for user searches
- LDAP_USER_SEARCH_FILTER: LDAP filter template (use {username})
- LDAP_GROUP_SEARCH_BASE: Base DN for group searches
- LDAP_GROUP_ATTRIBUTE: Attribute containing group membership
- LDAP_ROLE_MAPPING: JSON mapping of LDAP groups to app roles
- LDAP_DEFAULT_ROLE: Default role for authenticated users
- LDAP_ALLOW_LOCAL_FALLBACK: Allow local auth if LDAP fails

Author: Security Audit Toolkit Team
Date: March 2026
"""

import os
import json
import logging
from typing import Optional, Dict, Any, Tuple, List
from dataclasses import dataclass

try:
    from ldap3 import (
        Server, Connection, ALL, SUBTREE,
        AUTO_BIND_NO_TLS, AUTO_BIND_TLS_BEFORE_BIND,
        Tls
    )
    from ldap3.core.exceptions import (
        LDAPException,
        LDAPBindError as LDAP3BindError,
        LDAPSocketOpenError,
        LDAPInvalidCredentialsResult
    )
    LDAP3_AVAILABLE = True
except ImportError:
    LDAP3_AVAILABLE = False
    class Server:
        pass  # Dummy Server to avoid NameError if ldap3 is missing
    class Connection:
        pass  # Dummy Connection to avoid NameError if ldap3 is missing
    LDAPException = Exception
    LDAP3BindError = Exception
    LDAPSocketOpenError = Exception
    LDAPInvalidCredentialsResult = Exception

logger = logging.getLogger(__name__)


class LDAPAuthError(Exception):
    """Base exception for LDAP authentication errors"""
    pass


class LDAPConnectionError(LDAPAuthError):
    """LDAP connection failed"""
    pass


class LDAPBindError(LDAPAuthError):
    """LDAP bind (login) failed"""
    pass


class LDAPSearchError(LDAPAuthError):
    """LDAP search operation failed"""
    pass


class LDAPConfigError(LDAPAuthError):
    """LDAP configuration is invalid or missing"""
    pass


@dataclass
class LDAPConfig:
    """LDAP configuration settings"""
    enabled: bool = False
    server: str = ""
    port: int = 389
    use_ssl: bool = False
    bind_dn: str = ""
    bind_password: str = ""
    user_search_base: str = ""
    user_search_filter: str = "(sAMAccountName={username})"
    group_search_base: str = ""
    group_attribute: str = "memberOf"
    role_mapping: Dict[str, str] = None
    default_role: str = "Viewer"
    allow_local_fallback: bool = True
    connection_timeout: int = 10

    def __post_init__(self):
        if self.role_mapping is None:
            self.role_mapping = {}

    @classmethod
    def from_env(cls) -> 'LDAPConfig':
        """Load LDAP configuration from environment variables"""
        role_mapping_str = os.environ.get('LDAP_ROLE_MAPPING', '{}')
        try:
            role_mapping = json.loads(role_mapping_str)
        except json.JSONDecodeError:
            logger.warning("Invalid LDAP_ROLE_MAPPING JSON, using empty mapping")
            role_mapping = {}

        return cls(
            enabled=os.environ.get('LDAP_ENABLED', 'false').lower() == 'true',
            server=os.environ.get('LDAP_SERVER', ''),
            port=int(os.environ.get('LDAP_PORT', '389')),
            use_ssl=os.environ.get('LDAP_USE_SSL', 'false').lower() == 'true',
            bind_dn=os.environ.get('LDAP_BIND_DN', ''),
            bind_password=os.environ.get('LDAP_BIND_PASSWORD', ''),
            user_search_base=os.environ.get('LDAP_USER_SEARCH_BASE', ''),
            user_search_filter=os.environ.get(
                'LDAP_USER_SEARCH_FILTER',
                '(sAMAccountName={username})'
            ),
            group_search_base=os.environ.get('LDAP_GROUP_SEARCH_BASE', ''),
            group_attribute=os.environ.get('LDAP_GROUP_ATTRIBUTE', 'memberOf'),
            role_mapping=role_mapping,
            default_role=os.environ.get('LDAP_DEFAULT_ROLE', 'Viewer'),
            allow_local_fallback=os.environ.get(
                'LDAP_ALLOW_LOCAL_FALLBACK', 'true'
            ).lower() == 'true',
            connection_timeout=int(os.environ.get('LDAP_CONNECTION_TIMEOUT', '10'))
        )

    def validate(self) -> Tuple[bool, List[str]]:
        """Validate configuration, return (is_valid, list_of_errors)"""
        errors = []

        if not self.server:
            errors.append("LDAP_SERVER is required")
        if not self.bind_dn:
            errors.append("LDAP_BIND_DN is required")
        if not self.bind_password:
            errors.append("LDAP_BIND_PASSWORD is required")
        if not self.user_search_base:
            errors.append("LDAP_USER_SEARCH_BASE is required")
        if '{username}' not in self.user_search_filter:
            errors.append("LDAP_USER_SEARCH_FILTER must contain {username} placeholder")

        return (len(errors) == 0, errors)

    def to_safe_dict(self) -> Dict[str, Any]:
        """Return config as dict with sensitive values masked"""
        return {
            'enabled': self.enabled,
            'server': self.server,
            'port': self.port,
            'use_ssl': self.use_ssl,
            'bind_dn': self.bind_dn,
            'bind_password': '********' if self.bind_password else '',
            'user_search_base': self.user_search_base,
            'user_search_filter': self.user_search_filter,
            'group_search_base': self.group_search_base,
            'group_attribute': self.group_attribute,
            'role_mapping': self.role_mapping,
            'default_role': self.default_role,
            'allow_local_fallback': self.allow_local_fallback,
            'connection_timeout': self.connection_timeout
        }


@dataclass
class LDAPUser:
    """Represents a user retrieved from LDAP"""
    username: str
    dn: str
    email: Optional[str] = None
    display_name: Optional[str] = None
    groups: List[str] = None
    raw_attributes: Dict[str, Any] = None

    def __post_init__(self):
        if self.groups is None:
            self.groups = []
        if self.raw_attributes is None:
            self.raw_attributes = {}


class LDAPAuth:
    """
    LDAP/Active Directory Authentication Handler

    Provides methods for:
    - Testing LDAP connectivity
    - Authenticating users
    - Retrieving user information and groups
    - Mapping LDAP groups to application roles

    Usage:
        ldap = LDAPAuth()

        # Test connection
        success, message = ldap.test_connection()

        # Authenticate user
        user_info = ldap.authenticate('jdoe', 'password123')
        if user_info:
            role = ldap.get_role_for_user(user_info)
    """

    def __init__(self, config: Optional[LDAPConfig] = None):
        """
        Initialize LDAP authentication handler

        Args:
            config: LDAPConfig instance, or None to load from environment
        """
        if not LDAP3_AVAILABLE:
            raise LDAPConfigError(
                "ldap3 library not installed. Install with: pip install ldap3"
            )

        self.config = config or LDAPConfig.from_env()
        self._server: Optional[Server] = None

    @property
    def is_enabled(self) -> bool:
        """Check if LDAP authentication is enabled"""
        return self.config.enabled

    def _get_server(self) -> Server:
        """Get or create LDAP server connection object"""
        if self._server is None:
            tls_config = None
            if self.config.use_ssl:
                tls_config = Tls(validate=0)  # Customize TLS settings as needed

            self._server = Server(
                self.config.server,
                port=self.config.port,
                use_ssl=self.config.use_ssl,
                tls=tls_config,
                get_info=ALL,
                connect_timeout=self.config.connection_timeout
            )
        return self._server

    def _create_connection(
        self,
        bind_dn: Optional[str] = None,
        password: Optional[str] = None,
        raise_exceptions: bool = True
    ) -> Connection:
        """
        Create an LDAP connection

        Args:
            bind_dn: DN to bind as (default: service account)
            password: Password for binding (default: service account password)
            raise_exceptions: Whether to raise exceptions on bind failure

        Returns:
            LDAP Connection object
        """
        server = self._get_server()

        bind_dn = bind_dn or self.config.bind_dn
        password = password or self.config.bind_password

        auto_bind = (
            AUTO_BIND_TLS_BEFORE_BIND if self.config.use_ssl
            else AUTO_BIND_NO_TLS
        )

        try:
            conn = Connection(
                server,
                user=bind_dn,
                password=password,
                auto_bind=auto_bind,
                raise_exceptions=raise_exceptions,
                receive_timeout=self.config.connection_timeout
            )
            return conn
        except LDAPSocketOpenError as e:
            logger.error(f"LDAP connection failed: {e}")
            raise LDAPConnectionError(f"Unable to connect to LDAP server: {e}")
        except LDAPBindError as e:
            logger.error(f"LDAP bind failed: {e}")
            raise LDAPBindError(f"LDAP bind failed: {e}")

    def test_connection(self) -> Tuple[bool, str]:
        """
        Test LDAP server connectivity and credentials

        Returns:
            Tuple of (success: bool, message: str)
        """
        if not self.config.enabled:
            return False, "LDAP authentication is not enabled"

        is_valid, errors = self.config.validate()
        if not is_valid:
            return False, f"Configuration errors: {', '.join(errors)}"

        try:
            conn = self._create_connection()

            # Test a basic search to verify permissions
            conn.search(
                search_base=self.config.user_search_base,
                search_filter='(objectClass=*)',
                search_scope=SUBTREE,
                size_limit=1
            )

            conn.unbind()

            server = self._get_server()
            server_info = f"{self.config.server}:{self.config.port}"
            if server.info:
                vendor = getattr(server.info, 'vendor_name', 'Unknown')
                server_info = f"{server_info} ({vendor})"

            return True, f"Successfully connected to {server_info}"

        except LDAPConnectionError as e:
            return False, str(e)
        except LDAPBindError as e:
            return False, f"Authentication failed: {e}"
        except Exception as e:
            logger.exception("Unexpected LDAP error")
            return False, f"Unexpected error: {e}"

    def _search_user(self, username: str, conn: Connection) -> Optional[LDAPUser]:
        """
        Search for a user in LDAP

        Args:
            username: Username to search for
            conn: Active LDAP connection

        Returns:
            LDAPUser object or None if not found
        """
        search_filter = self.config.user_search_filter.replace(
            '{username}',
            username
        )

        # Attributes to retrieve
        attributes = [
            'cn', 'displayName', 'mail', 'sAMAccountName',
            'userPrincipalName', 'distinguishedName',
            self.config.group_attribute
        ]

        try:
            conn.search(
                search_base=self.config.user_search_base,
                search_filter=search_filter,
                search_scope=SUBTREE,
                attributes=attributes
            )

            if not conn.entries:
                logger.debug(f"User not found in LDAP: {username}")
                return None

            entry = conn.entries[0]

            # Extract groups
            groups = []
            if hasattr(entry, self.config.group_attribute):
                group_dns = getattr(entry, self.config.group_attribute)
                if group_dns:
                    groups = [str(g) for g in group_dns]

            # Build user object
            return LDAPUser(
                username=username,
                dn=str(entry.entry_dn),
                email=str(entry.mail) if hasattr(entry, 'mail') and entry.mail else None,
                display_name=(
                    str(entry.displayName)
                    if hasattr(entry, 'displayName') and entry.displayName
                    else str(entry.cn) if hasattr(entry, 'cn') else username
                ),
                groups=groups,
                raw_attributes=entry.entry_attributes_as_dict
            )

        except Exception as e:
            logger.error(f"LDAP search error for user {username}: {e}")
            raise LDAPSearchError(f"Failed to search for user: {e}")

    def authenticate(
        self,
        username: str,
        password: str
    ) -> Optional[LDAPUser]:
        """
        Authenticate a user against LDAP

        This performs:
        1. Service account bind to search for user
        2. User lookup to get DN
        3. Rebind as user to verify password
        4. Return user info with groups on success

        Args:
            username: Username to authenticate
            password: Password to verify

        Returns:
            LDAPUser object on success, None on authentication failure

        Raises:
            LDAPAuthError: On connection or search errors
        """
        if not self.config.enabled:
            logger.debug("LDAP authentication is disabled")
            return None

        if not username or not password:
            logger.debug("Empty username or password")
            return None

        logger.info(f"Attempting LDAP authentication for: {username}")

        try:
            # First, bind with service account to search for user
            service_conn = self._create_connection()

            try:
                user = self._search_user(username, service_conn)
                if not user:
                    logger.warning(f"LDAP user not found: {username}")
                    return None
            finally:
                service_conn.unbind()

            # Now verify user's password by binding as the user
            try:
                user_conn = self._create_connection(
                    bind_dn=user.dn,
                    password=password,
                    raise_exceptions=True
                )
                user_conn.unbind()

                logger.info(f"LDAP authentication successful for: {username}")
                return user

            except (LDAP3BindError, LDAPInvalidCredentialsResult):
                logger.warning(f"LDAP authentication failed (bad password): {username}")
                return None

        except LDAPConnectionError:
            raise
        except LDAPSearchError:
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during LDAP auth: {e}")
            raise LDAPAuthError(f"Authentication error: {e}")

    def get_role_for_user(self, user: LDAPUser) -> str:
        """
        Determine application role for an LDAP user based on group membership

        Args:
            user: LDAPUser with group information

        Returns:
            Application role name (highest privilege matching group, or default)
        """
        if not self.config.role_mapping:
            return self.config.default_role

        # Role priority order (highest first)
        role_priority = ['SuperAdmin', 'Admin', 'Analyst', 'Operator', 'Viewer']

        # Find all matching roles
        matched_roles = []
        for group_dn in user.groups:
            # Check both full DN and just the CN
            group_cn = self._extract_cn(group_dn)

            for group_pattern, role in self.config.role_mapping.items():
                if (
                    group_pattern.lower() in group_dn.lower() or
                    group_pattern.lower() == group_cn.lower()
                ):
                    matched_roles.append(role)

        if not matched_roles:
            return self.config.default_role

        # Return highest priority role
        for role in role_priority:
            if role in matched_roles:
                return role

        # If matched role not in priority list, return first match
        return matched_roles[0]

    def _extract_cn(self, dn: str) -> str:
        """Extract CN from a distinguished name"""
        if not dn:
            return ""
        for part in dn.split(','):
            if part.strip().lower().startswith('cn='):
                return part.strip()[3:]
        return dn

    def get_user_info(self, username: str) -> Optional[LDAPUser]:
        """
        Get user information from LDAP without authentication

        Args:
            username: Username to look up

        Returns:
            LDAPUser object or None if not found
        """
        if not self.config.enabled:
            return None

        try:
            conn = self._create_connection()
            try:
                return self._search_user(username, conn)
            finally:
                conn.unbind()
        except Exception as e:
            logger.error(f"Failed to get user info for {username}: {e}")
            return None

    def sync_user_groups(self, username: str) -> Optional[List[str]]:
        """
        Sync/refresh user's group memberships from LDAP

        Args:
            username: Username to sync

        Returns:
            List of group DNs or None if user not found
        """
        user = self.get_user_info(username)
        if user:
            return user.groups
        return None


# Module-level convenience instance (loaded from environment)
_default_ldap_auth: Optional[LDAPAuth] = None


def get_ldap_auth() -> Optional[LDAPAuth]:
    """
    Get the default LDAP authentication handler

    Returns:
        LDAPAuth instance or None if ldap3 not available
    """
    global _default_ldap_auth

    if not LDAP3_AVAILABLE:
        return None

    if _default_ldap_auth is None:
        try:
            _default_ldap_auth = LDAPAuth()
        except LDAPConfigError:
            return None

    return _default_ldap_auth


def ldap_authenticate(username: str, password: str) -> Optional[LDAPUser]:
    """
    Convenience function to authenticate via LDAP

    Args:
        username: Username to authenticate
        password: Password to verify

    Returns:
        LDAPUser on success, None on failure
    """
    ldap = get_ldap_auth()
    if ldap and ldap.is_enabled:
        return ldap.authenticate(username, password)
    return None
