"""
Multi-Factor Authentication (MFA) Module

This module provides TOTP-based multi-factor authentication compatible with:
- Google Authenticator
- Microsoft Authenticator
- Authy
- Any TOTP-compatible app

Features:
- TOTP generation and validation
- QR code generation for easy setup
- Backup codes for recovery
- Encrypted secret storage

Environment Configuration:
    MFA_ISSUER: Application name shown in authenticator apps (default: Security Audit Toolkit)
    MFA_ENCRYPTION_KEY: Fernet encryption key for secrets (uses FLASK_SECRET_KEY if not set)

Usage:
    from auth.mfa import get_mfa_manager

    mfa = get_mfa_manager()
    secret = mfa.generate_secret()
    qr_code = mfa.generate_qr_code(secret, "username")
    is_valid = mfa.verify_code(secret, "123456")

Author: Security Audit Toolkit Team
Date: March 2026
"""

import base64
import hashlib
import io
import json
import logging
import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

# Try to import required libraries
try:
    import pyotp

    PYOTP_AVAILABLE = True
except ImportError:
    PYOTP_AVAILABLE = False
    logger.warning("pyotp not installed - MFA unavailable")
    class DummyTOTP:
        pass
    class pyotp:
        TOTP = DummyTOTP

try:
    import qrcode

    QRCODE_AVAILABLE = True
except ImportError:
    QRCODE_AVAILABLE = False
    logger.warning("qrcode not installed - QR code generation unavailable")

try:
    from cryptography.fernet import Fernet, InvalidToken

    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    logger.warning("cryptography not installed - encryption unavailable")


class MFAError(Exception):
    """Base exception for MFA errors"""

    pass


class MFASetupError(MFAError):
    """Error during MFA setup"""

    pass


class MFAVerificationError(MFAError):
    """Error during MFA verification"""

    pass


class MFAEncryptionError(MFAError):
    """Error during secret encryption/decryption"""

    pass


@dataclass
class MFAConfig:
    """MFA configuration loaded from environment"""

    issuer: str = "Security Audit Toolkit"
    valid_window: int = 1  # Allow ±30 seconds
    backup_code_count: int = 10
    max_failed_attempts: int = 3
    lockout_duration: int = 900  # 15 minutes in seconds

    @classmethod
    def from_env(cls) -> "MFAConfig":
        """Load configuration from environment"""
        return cls(
            issuer=os.environ.get("MFA_ISSUER", "Security Audit Toolkit"),
            valid_window=int(os.environ.get("MFA_VALID_WINDOW", "1")),
            backup_code_count=int(os.environ.get("MFA_BACKUP_CODE_COUNT", "10")),
            max_failed_attempts=int(os.environ.get("MFA_MAX_FAILED_ATTEMPTS", "3")),
            lockout_duration=int(os.environ.get("MFA_LOCKOUT_DURATION", "900")),
        )


class MFAManager:
    """
    Multi-Factor Authentication manager.

    Handles TOTP generation, validation, QR codes, and backup codes.
    """

    def __init__(self, encryption_key: Optional[bytes] = None, config: Optional[MFAConfig] = None):
        """
        Initialize MFA manager.

        Args:
            encryption_key: Fernet encryption key for secrets.
                           If not provided, derives from FLASK_SECRET_KEY.
            config: Optional MFAConfig. Loads from environment if not provided.
        """
        if not PYOTP_AVAILABLE:
            raise MFAError("pyotp library not installed. Install with: pip install pyotp")

        self.config = config or MFAConfig.from_env()
        self._fernet: Optional[Fernet] = None

        # Initialize encryption if available
        if CRYPTO_AVAILABLE:
            if encryption_key:
                self._fernet = Fernet(encryption_key)
            else:
                # Derive from Flask secret key
                flask_secret = os.environ.get("FLASK_SECRET_KEY", "")
                if flask_secret:
                    # Derive a proper Fernet key from the Flask secret
                    key = self._derive_fernet_key(flask_secret)
                    self._fernet = Fernet(key)

    @staticmethod
    def _derive_fernet_key(secret: str) -> bytes:
        """Derive a Fernet-compatible key from an arbitrary secret"""
        # Use SHA256 to get 32 bytes, then base64 encode for Fernet
        digest = hashlib.sha256(secret.encode()).digest()
        return base64.urlsafe_b64encode(digest)

    # =========================================================================
    # Secret Management
    # =========================================================================

    def generate_secret(self) -> str:
        """
        Generate a new TOTP secret.

        Returns:
            Base32-encoded secret string
        """
        return pyotp.random_base32()

    def encrypt_secret(self, secret: str) -> str:
        """
        Encrypt a TOTP secret for database storage.

        Args:
            secret: Plain text TOTP secret

        Returns:
            Encrypted secret string

        Raises:
            MFAEncryptionError: If encryption not available or fails
        """
        if not self._fernet:
            raise MFAEncryptionError("Encryption not configured")

        try:
            encrypted = self._fernet.encrypt(secret.encode())
            return encrypted.decode()
        except Exception as e:
            raise MFAEncryptionError(f"Encryption failed: {e}")

    def decrypt_secret(self, encrypted_secret: str) -> str:
        """
        Decrypt a TOTP secret from database.

        Args:
            encrypted_secret: Encrypted secret string

        Returns:
            Plain text TOTP secret

        Raises:
            MFAEncryptionError: If decryption fails
        """
        if not self._fernet:
            raise MFAEncryptionError("Encryption not configured")

        try:
            decrypted = self._fernet.decrypt(encrypted_secret.encode())
            return decrypted.decode()
        except InvalidToken:
            raise MFAEncryptionError("Invalid encryption token - secret may be corrupted")
        except Exception as e:
            raise MFAEncryptionError(f"Decryption failed: {e}")

    # =========================================================================
    # TOTP Validation
    # =========================================================================

    def get_totp(self, secret: str) -> pyotp.TOTP:
        """
        Get a TOTP object for a secret.

        Args:
            secret: TOTP secret (plain text)

        Returns:
            pyotp.TOTP instance
        """
        return pyotp.TOTP(secret)

    def verify_code(self, secret: str, code: str) -> bool:
        """
        Verify a TOTP code.

        Args:
            secret: TOTP secret (plain text)
            code: 6-digit code from authenticator app

        Returns:
            True if code is valid
        """
        if not code or not secret:
            return False

        # Normalize code - remove spaces, ensure 6 digits
        code = code.replace(" ", "").strip()
        if not code.isdigit() or len(code) != 6:
            return False

        try:
            totp = self.get_totp(secret)
            return totp.verify(code, valid_window=self.config.valid_window)
        except Exception as e:
            logger.warning(f"TOTP verification error: {e}")
            return False

    def get_current_code(self, secret: str) -> str:
        """
        Get the current TOTP code (for testing/debug).

        Args:
            secret: TOTP secret

        Returns:
            Current 6-digit code
        """
        totp = self.get_totp(secret)
        return totp.now()

    # =========================================================================
    # QR Code Generation
    # =========================================================================

    def get_provisioning_uri(self, secret: str, username: str, issuer: Optional[str] = None) -> str:
        """
        Get the TOTP provisioning URI for manual entry.

        Args:
            secret: TOTP secret
            username: User's username or email
            issuer: App name (uses config if not provided)

        Returns:
            otpauth:// URI string
        """
        totp = self.get_totp(secret)
        return totp.provisioning_uri(
            name=username, issuer_name=issuer or self.config.issuer
        )

    def generate_qr_code(
        self, secret: str, username: str, issuer: Optional[str] = None
    ) -> str:
        """
        Generate a QR code for authenticator app setup.

        Args:
            secret: TOTP secret
            username: User's username or email
            issuer: App name (uses config if not provided)

        Returns:
            Base64 data URI for the QR code image

        Raises:
            MFASetupError: If QR code generation fails
        """
        if not QRCODE_AVAILABLE:
            raise MFASetupError("qrcode library not installed")

        try:
            uri = self.get_provisioning_uri(secret, username, issuer)

            # Generate QR code
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(uri)
            qr.make(fit=True)

            # Convert to image
            img = qr.make_image(fill_color="black", back_color="white")

            # Convert to base64 data URI
            buffer = io.BytesIO()
            img.save(buffer, format="PNG")
            img_str = base64.b64encode(buffer.getvalue()).decode()

            return f"data:image/png;base64,{img_str}"

        except Exception as e:
            raise MFASetupError(f"QR code generation failed: {e}")

    # =========================================================================
    # Backup Codes
    # =========================================================================

    def generate_backup_codes(self, count: Optional[int] = None) -> list[str]:
        """
        Generate single-use backup codes.

        Args:
            count: Number of codes to generate (uses config default if not provided)

        Returns:
            List of backup codes (plain text, display to user)
        """
        count = count or self.config.backup_code_count
        # Generate codes in format XXXX-XXXX for readability
        codes = []
        for _ in range(count):
            code = secrets.token_hex(4).upper()
            formatted = f"{code[:4]}-{code[4:]}"
            codes.append(formatted)
        return codes

    def hash_backup_code(self, code: str) -> str:
        """
        Hash a backup code for storage.

        Args:
            code: Plain text backup code

        Returns:
            Hashed code (SHA256 hex digest)
        """
        # Normalize: remove dashes, uppercase
        normalized = code.replace("-", "").upper()
        return hashlib.sha256(normalized.encode()).hexdigest()

    def hash_backup_codes(self, codes: list[str]) -> list[str]:
        """
        Hash a list of backup codes for database storage.

        Args:
            codes: List of plain text backup codes

        Returns:
            List of hashed codes
        """
        return [self.hash_backup_code(code) for code in codes]

    def encrypt_backup_codes(self, hashed_codes: list[str]) -> str:
        """
        Encrypt hashed backup codes for database storage.

        Args:
            hashed_codes: List of hashed backup codes

        Returns:
            Encrypted JSON string
        """
        if not self._fernet:
            raise MFAEncryptionError("Encryption not configured")

        json_str = json.dumps(hashed_codes)
        encrypted = self._fernet.encrypt(json_str.encode())
        return encrypted.decode()

    def decrypt_backup_codes(self, encrypted: str) -> list[str]:
        """
        Decrypt backup codes from database.

        Args:
            encrypted: Encrypted JSON string

        Returns:
            List of hashed backup codes
        """
        if not self._fernet:
            raise MFAEncryptionError("Encryption not configured")

        try:
            decrypted = self._fernet.decrypt(encrypted.encode())
            return json.loads(decrypted.decode())
        except Exception as e:
            raise MFAEncryptionError(f"Backup code decryption failed: {e}")

    def verify_backup_code(self, stored_codes: list[str], provided_code: str) -> tuple[bool, int]:
        """
        Verify a backup code and return its index if valid.

        Args:
            stored_codes: List of hashed backup codes from database
            provided_code: Plain text code provided by user

        Returns:
            Tuple of (is_valid, index_of_used_code)
            Index is -1 if not valid
        """
        provided_hash = self.hash_backup_code(provided_code)
        for i, stored_hash in enumerate(stored_codes):
            if secrets.compare_digest(stored_hash, provided_hash):
                return True, i
        return False, -1


# =============================================================================
# Module Functions
# =============================================================================

# Singleton manager instance
_mfa_manager: Optional[MFAManager] = None


def get_mfa_manager() -> Optional[MFAManager]:
    """
    Get the global MFAManager instance.

    Returns:
        MFAManager instance, or None if dependencies unavailable
    """
    global _mfa_manager

    if not PYOTP_AVAILABLE:
        return None

    if _mfa_manager is None:
        try:
            _mfa_manager = MFAManager()
        except MFAError as e:
            logger.warning(f"MFA manager initialization failed: {e}")
            return None

    return _mfa_manager


def mfa_available() -> bool:
    """Check if MFA is available (dependencies installed)"""
    return PYOTP_AVAILABLE


def qr_code_available() -> bool:
    """Check if QR code generation is available"""
    return QRCODE_AVAILABLE
