#!/usr/bin/env python3
"""
Authentication Module

Provides authentication for the web interface:
- API key generation and management
- RBAC permission checking decorators
- Unified auth that supports API key and session-based auth
- Security utilities
"""

import os
import secrets
import logging
import time
import threading
from datetime import datetime
from functools import wraps
from pathlib import Path
from flask import request, jsonify, session, g
from flask_login import current_user

logger = logging.getLogger(__name__)


_API_KEY_RATE_STATE = {}
_API_KEY_RATE_LOCK = threading.Lock()


def get_current_user():
    """
    Get the current authenticated user.

    Returns:
        User object if authenticated, None otherwise
    """
    if current_user.is_authenticated:
        return current_user
    return None


# =============================================================================
# Permission Constants (must match models/user.py Role.PERMISSIONS)
# =============================================================================

PERMISSIONS = {
    'view_reports': 'View audit reports',
    'view_history': 'View execution history',
    'view_audits': 'View available audits',
    'view_dashboard': 'View dashboard',
    'run_audits': 'Execute audits',
    'view_servers': 'View server list',
    'view_hypervisors': 'View hypervisor list',
    'view_logs': 'View system logs',
    'create_plans': 'Create audit plans',
    'edit_plans': 'Edit audit plans',
    'delete_plans': 'Delete audit plans',
    'create_schedules': 'Create schedules',
    'edit_schedules': 'Edit schedules',
    'delete_schedules': 'Delete schedules',
    'deploy_scripts': 'Deploy scripts to servers',
    'run_discovery': 'Run server discovery',
    'export_reports': 'Export reports',
    'add_servers': 'Add new servers',
    'edit_servers': 'Edit server configurations',
    'delete_servers': 'Delete servers',
    'manage_users': 'Manage user accounts',
    'view_admin': 'View admin panel',
    'edit_settings': 'Edit system settings',
    'delete_all_data': 'Delete all data (danger)',
    'manage_roles': 'Manage user roles',
    'regenerate_api_keys': 'Regenerate API keys',
    'view_audit_log': 'View audit log',
    'manage_backups': 'Manage backups',
    'system_maintenance': 'System maintenance',
}


class APIKeyManager:
    """Manages API key generation, storage, and validation"""

    def __init__(self, key_file):
        """
        Initialize API key manager

        Args:
            key_file: Path to API key storage file (legacy, migrates to keystore)
        """
        self.key_file = Path(key_file)
        self.api_key = self._get_or_create_api_key()

    def _get_or_create_api_key(self):
        """Get existing API key or create new one (keystore-first with file fallback)"""
        # First, try to load from encrypted keystore
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            # Check if key exists in keystore
            key = keystore.get_key('system', 'api_key')
            if key:
                logger.info("Loaded system API key from encrypted keystore")
                return key

            # Check legacy file and migrate if exists
            if self.key_file.exists():
                self.key_file.chmod(0o600)
                api_key = self.key_file.read_text().strip()
                if api_key:
                    # Migrate to keystore
                    keystore.store_key(
                        key_type='system',
                        key_id='api_key',
                        value=api_key,
                        metadata={'migrated_from': str(self.key_file)}
                    )
                    logger.info(f"Migrated API key from {self.key_file} to encrypted keystore")
                    # Keep file as backup but could delete: self.key_file.unlink()
                    return api_key

            # Generate new key and store in keystore
            api_key = secrets.token_urlsafe(32)
            keystore.store_key(
                key_type='system',
                key_id='api_key',
                value=api_key,
                metadata={'generated_at': 'initial_setup'}
            )
            logger.info("Generated new API key, stored in encrypted keystore")
            print("\n" + "="*70)
            print(f"NEW API KEY GENERATED: {api_key}")
            print("Save this key - you'll need it to access the API")
            print("Set in requests: X-API-Key header")
            print("Key stored securely in encrypted keystore")
            print("="*70 + "\n")
            return api_key

        except ImportError:
            logger.warning("Keystore module not available, using file-based storage")
        except Exception as e:
            logger.warning(f"Could not use keystore, falling back to file: {e}")

        # Fallback to file-based storage (legacy)
        if self.key_file.exists():
            self.key_file.chmod(0o600)
            api_key = self.key_file.read_text().strip()
            logger.info(f"Loaded existing API key from {self.key_file}")
            return api_key
        else:
            api_key = secrets.token_urlsafe(32)
            self.key_file.write_text(api_key)
            self.key_file.chmod(0o600)
            logger.info(f"Generated new API key: {api_key[:8]}...")
            print("\n" + "="*70)
            print(f"NEW API KEY GENERATED: {api_key}")
            print("Save this key - you'll need it to access the API")
            print("Set in requests: X-API-Key header")
            print("="*70 + "\n")
            return api_key

    def validate_key(self, provided_key):
        """
        Validate provided API key against stored key

        Args:
            provided_key: API key to validate

        Returns:
            True if valid, False otherwise

        Security: Uses constant-time comparison to prevent timing attacks
        """
        if not provided_key:
            return False

        # Fast path: in-memory match
        if self.api_key and secrets.compare_digest(provided_key, self.api_key):
            return True

        # Robust path: refresh from shared stores to handle multi-worker drift
        # (e.g., gunicorn workers with stale in-memory keys after rotate/rebuild).
        refreshed_key = None

        # 1) Encrypted keystore (authoritative when available)
        try:
            from keystore import get_keystore
            keystore = get_keystore()

            # Preferred system key id
            refreshed_key = keystore.get_key('system', 'api_key')

            # Backward compatibility with prior key id usage
            if not refreshed_key:
                refreshed_key = keystore.get_key('system', 'primary')
        except Exception:
            refreshed_key = None

        # 2) Legacy file fallback
        if not refreshed_key:
            try:
                if self.key_file.exists():
                    candidate = self.key_file.read_text().strip()
                    if candidate:
                        refreshed_key = candidate
            except Exception:
                refreshed_key = None

        if refreshed_key:
            self.api_key = refreshed_key
            return secrets.compare_digest(provided_key, refreshed_key)

        return False

    def regenerate_key(self):
        """
        Generate new API key

        Returns:
            New API key string

        Warning: This invalidates all existing API keys
        """
        new_key = secrets.token_urlsafe(32)

        # Try to store in keystore first
        try:
            from keystore import get_keystore
            keystore = get_keystore()
            keystore.store_key(
                key_type='system',
                key_id='api_key',
                value=new_key,
                metadata={'regenerated_at': 'manual_regeneration'}
            )
            logger.warning(f"API key regenerated and stored in encrypted keystore: {new_key[:8]}...")
        except Exception as e:
            logger.warning(f"Could not store in keystore, using file: {e}")
            # Fallback to file
            self.key_file.write_text(new_key)
            self.key_file.chmod(0o600)
            logger.warning(f"API key regenerated (file): {new_key[:8]}...")

        self.api_key = new_key
        return new_key


class ScopedAPIUser:
    """Virtual user for API key auth with scope-aware permissions."""

    ROLE_LEVELS = {
        'Viewer': 1,
        'Operator': 2,
        'Analyst': 3,
        'Admin': 4,
        'SecurityAdmin': 5,
        'SuperAdmin': 6,
    }

    READ_PERMISSIONS = {
        'view_reports', 'view_history', 'view_audits', 'view_dashboard',
        'view_servers', 'view_hypervisors', 'view_logs', 'view_admin',
        'view_audit_log',
    }

    WRITE_PERMISSIONS = {
        'create_plans', 'edit_plans', 'delete_plans',
        'create_schedules', 'edit_schedules', 'delete_schedules',
        'add_servers', 'edit_servers', 'delete_servers',
    }

    EXECUTE_PERMISSIONS = {
        'run_audits', 'deploy_scripts', 'run_discovery',
        'export_reports', 'manage_backups', 'system_maintenance',
    }

    ADMIN_PERMISSIONS = {
        'manage_users', 'edit_settings', 'delete_all_data',
        'manage_roles', 'regenerate_api_keys',
    }

    def __init__(self, key_context: dict):
        scopes = key_context.get('scope') or ['all']
        self.scopes = set(scopes)
        self.id = 0
        self.key_id = key_context.get('key_id', 'api_key')
        self.key_type = key_context.get('key_type', 'system')
        self.username = f"api_key_{self.key_type}_{self.key_id}"
        self.role = self._derive_role()
        self.is_active = True
        self.is_authenticated = True
        self.is_anonymous = False

    def _derive_role(self) -> str:
        if 'all' in self.scopes or 'admin' in self.scopes:
            return 'SuperAdmin'
        if 'write' in self.scopes or 'execute' in self.scopes:
            return 'Operator'
        return 'Viewer'

    def get_id(self):
        return '0'

    def has_permission(self, permission):
        if 'all' in self.scopes or 'admin' in self.scopes:
            return True
        if permission in self.READ_PERMISSIONS:
            return 'read' in self.scopes or 'write' in self.scopes or 'execute' in self.scopes
        if permission in self.WRITE_PERMISSIONS:
            return 'write' in self.scopes
        if permission in self.EXECUTE_PERMISSIONS:
            return 'execute' in self.scopes
        if permission in self.ADMIN_PERMISSIONS:
            return False
        return False

    def has_role(self, role):
        my_level = self.ROLE_LEVELS.get(self.role, 0)
        target_level = self.ROLE_LEVELS.get(role, 0)
        return my_level >= target_level

    def check_minimum_role(self, min_role):
        return self.has_role(min_role)


def _parse_iso_datetime(value: str):
    """Parse ISO datetime safely, including trailing Z."""
    if not value:
        return None
    normalized = str(value).strip()
    if normalized.endswith('Z'):
        normalized = normalized[:-1] + '+00:00'
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is not None:
        return parsed.replace(tzinfo=None)
    return parsed


def _is_expired(expires_value: str) -> bool:
    """Check whether an expiration timestamp has passed."""
    expires_at = _parse_iso_datetime(expires_value)
    return bool(expires_at and expires_at < datetime.utcnow())


def _validate_api_key_with_context(provided_key: str):
    """Validate API key and return metadata context for scoped auth."""
    if not provided_key:
        return None

    # Primary system key (backward compatible, full access)
    if _api_key_manager.validate_key(provided_key):
        return {
            'key_type': 'system',
            'key_id': 'api_key',
            'scope': ['all'],
            'rate_limit_per_minute': None,
            'source': 'system_manager'
        }

    # Encrypted keystore keys
    try:
        from keystore import get_keystore
        keystore = get_keystore()

        # Explicit system-key checks first (authoritative full-access context)
        for system_key_id in ('api_key', 'primary'):
            system_key_valid = False
            try:
                system_key_valid = keystore.validate_key('system', system_key_id, provided_key)
            except Exception as system_key_error:
                logger.debug(f"Keystore system key validation error for {system_key_id}: {system_key_error}")

            if not system_key_valid:
                continue

            # Keep in-memory manager aligned for this worker process
            try:
                _api_key_manager.api_key = provided_key
            except Exception as sync_error:
                logger.debug(f"Unable to sync system API key in memory: {sync_error}")

            return {
                'key_type': 'system',
                'key_id': system_key_id,
                'scope': ['all'],
                'rate_limit_per_minute': None,
                'source': 'keystore_system'
            }

        for key_info in keystore.list_keys():
            key_type = key_info.get('key_type')
            key_id = key_info.get('key_id')
            if not key_type or not key_id:
                continue

            if not keystore.validate_key(key_type, key_id, provided_key):
                continue

            metadata = key_info.get('metadata', {}) or {}
            if _is_expired(metadata.get('expires')):
                logger.warning(f"Expired API key rejected: {key_type}/{key_id}")
                return None

            scopes = metadata.get('scope')
            if not scopes:
                if key_type == 'system':
                    scopes = ['all']
                else:
                    scopes = ['agent'] if key_type in ('agent', 'hypervisor_agent') else ['read']

            return {
                'key_type': key_type,
                'key_id': key_id,
                'scope': scopes,
                'expires': metadata.get('expires'),
                'rate_limit_per_minute': metadata.get('rate_limit_per_minute'),
                'source': 'keystore'
            }
    except Exception as e:
        logger.debug(f"Keystore API key validation unavailable: {e}")

    # Legacy custom keys in security settings
    try:
        from security_settings import get_all_security_settings
        settings = get_all_security_settings() or {}
        for key_entry in settings.get('custom_api_keys', []):
            candidate_key = key_entry.get('key')
            if not candidate_key:
                continue
            if not secrets.compare_digest(candidate_key, provided_key):
                continue

            if key_entry.get('revoked'):
                logger.warning(f"Revoked API key rejected: {key_entry.get('id', 'legacy_custom')}")
                return None

            if _is_expired(key_entry.get('expires')):
                logger.warning(f"Expired API key rejected: {key_entry.get('id', 'legacy_custom')}")
                return None

            return {
                'key_type': 'custom',
                'key_id': key_entry.get('id', 'legacy_custom'),
                'scope': key_entry.get('scope') or ['read'],
                'expires': key_entry.get('expires'),
                'rate_limit_per_minute': key_entry.get('rate_limit_per_minute'),
                'source': 'legacy_settings'
            }
    except Exception as e:
        logger.debug(f"Legacy API key validation unavailable: {e}")

    return None


def _is_agent_path(path: str) -> bool:
    return (
        path.startswith('/api/agent')
        or path.startswith('/api/agents')
        or path.startswith('/api/managed-agent')
        or path.startswith('/api/hypervisor-agent')
    )


def _scope_allows_request(context: dict) -> tuple[bool, str]:
    """Check request path/method against key scope metadata."""
    scopes = set(context.get('scope') or [])
    path = request.path or ''
    method = (request.method or 'GET').upper()

    if 'all' in scopes or 'admin' in scopes:
        return True, ''

    if path.startswith('/api/admin') or path.startswith('/api/superadmin'):
        return False, 'Admin scope required for admin endpoints'

    if _is_agent_path(path):
        if 'agent' in scopes:
            return True, ''
        return False, 'Agent scope required for agent endpoints'

    route_scope_map = [
        ('/api/agent', {'agent'}),
        ('/api/agents', {'agent'}),
        ('/api/managed-agent', {'agent'}),
        ('/api/hypervisor-agent', {'agent'}),

        ('/api/async', {'execute'}),
        ('/api/audit', {'execute'}),
        ('/api/audits', {'execute'}),
        ('/api/backup', {'execute'}),
        ('/api/batch', {'execute'}),
        ('/api/deploy', {'execute'}),
        ('/api/discovery', {'execute'}),
        ('/api/execute', {'execute'}),
        ('/api/maintenance-windows', {'execute'}),
        ('/api/remediation', {'execute'}),
        ('/api/recovery', {'execute'}),
        ('/api/script-studio', {'execute'}),
        ('/api/terminal', {'execute'}),

        ('/api/asset-discovery', {'write'}),
        ('/api/compliance', {'write'}),
        ('/api/differential', {'write'}),
        ('/api/enhanced-schedule', {'write'}),
        ('/api/evidence', {'write'}),
        ('/api/group-policies', {'write'}),
        ('/api/hypervisors', {'write'}),
        ('/api/inventory', {'write'}),
        ('/api/plans', {'write'}),
        ('/api/presets', {'write'}),
        ('/api/scheduled-reports', {'write'}),
        ('/api/schedules', {'write'}),
        ('/api/server-groups', {'write'}),
        ('/api/servers', {'write'}),
        ('/api/settings', {'write'}),

        ('/api/analytics', {'read'}),
        ('/api/cve', {'read'}),
        ('/api/dashboard', {'read'}),
        ('/api/docs', {'read'}),
        ('/api/features', {'read'}),
        ('/api/health', {'read'}),
        ('/api/help', {'read'}),
        ('/api/history', {'read'}),
        ('/api/license', {'read'}),
        ('/api/logs', {'read'}),
        ('/api/monitoring', {'read'}),
        ('/api/openapi.json', {'read'}),
        ('/api/reports', {'read'}),
        ('/api/status', {'read'}),
        ('/health', {'read'}),
        ('/ready', {'read'}),
        ('/metrics', {'read'}),
    ]

    def _has_scope(required: set[str]) -> bool:
        if 'agent' in required:
            return 'agent' in scopes
        if 'read' in required:
            return bool(scopes.intersection({'read', 'write', 'execute'}))
        if 'write' in required:
            return bool(scopes.intersection({'write', 'execute'}))
        if 'execute' in required:
            return bool(scopes.intersection({'execute', 'write'}))
        return False

    for prefix, required in route_scope_map:
        if path.startswith(prefix):
            if _has_scope(required):
                if method in {'GET', 'HEAD', 'OPTIONS'}:
                    return True, ''
                if 'read' in required:
                    if bool(scopes.intersection({'write', 'execute'})):
                        return True, ''
                    return False, 'Write scope required for state-changing requests'
                return True, ''

            if 'execute' in required:
                return False, 'Execute scope required for this endpoint'
            if 'write' in required:
                return False, 'Write scope required for this endpoint'
            return False, 'Read scope required for this endpoint'

    read_allowed = {'read', 'write', 'execute'}
    if method in {'GET', 'HEAD', 'OPTIONS'}:
        if scopes.intersection(read_allowed):
            return True, ''
        return False, 'Read scope required'

    execute_prefixes = (
        '/api/audits', '/api/batch', '/api/remediation', '/api/terminal', '/api/recovery'
    )
    if path.startswith(execute_prefixes):
        if scopes.intersection({'execute', 'write'}):
            return True, ''
        return False, 'Execute scope required for this endpoint'

    if scopes.intersection({'write', 'execute'}):
        return True, ''
    return False, 'Write scope required for state-changing requests'


def _check_api_key_rate_limit(context: dict) -> tuple[bool, str]:
    """Enforce optional per-key rate limiting on a per-minute window."""
    raw_limit = context.get('rate_limit_per_minute')
    if raw_limit in (None, '', 0, '0'):
        return True, ''

    try:
        limit = int(raw_limit)
    except (TypeError, ValueError):
        return True, ''

    if limit <= 0:
        return True, ''

    key_ref = f"{context.get('key_type', 'unknown')}:{context.get('key_id', 'unknown')}"
    current_bucket = int(time.time() // 60)

    with _API_KEY_RATE_LOCK:
        state = _API_KEY_RATE_STATE.get(key_ref)
        if not state or state.get('bucket') != current_bucket:
            _API_KEY_RATE_STATE[key_ref] = {'bucket': current_bucket, 'count': 1}
            return True, ''

        if state['count'] >= limit:
            return False, 'API key rate limit exceeded'

        state['count'] += 1
        return True, ''


def _enforce_api_key_constraints(context: dict):
    """Apply scope and rate constraints for a validated API key context."""
    allowed, message = _scope_allows_request(context)
    if not allowed:
        logger.warning(
            f"API key scope denied for {request.path}: {context.get('key_type')}/{context.get('key_id')}"
        )
        return False, (jsonify({'success': False, 'error': message}), 403)

    within_limit, rate_message = _check_api_key_rate_limit(context)
    if not within_limit:
        logger.warning(
            f"API key rate limit exceeded for {context.get('key_type')}/{context.get('key_id')}"
        )
        return False, (jsonify({'success': False, 'error': rate_message}), 429)

    return True, None


def require_api_key_factory(api_key_manager):
    """
    Decorator factory to require API key authentication

    Args:
        api_key_manager: APIKeyManager instance

    Returns:
        Decorator function

    Usage:
        @app.route('/api/protected')
        @require_api_key_factory(api_key_manager)
        def protected_route():
            return {"data": "secret"}
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check for API key in header or session
            provided_key = request.headers.get('X-API-Key') or session.get('api_key')

            if not provided_key:
                logger.warning(f"Unauthorized access attempt from {request.remote_addr}")
                return jsonify({"success": False, "error": "API key required"}), 401

            context = _validate_api_key_with_context(provided_key)
            if not context:
                logger.warning(f"Invalid API key from {request.remote_addr}")
                return jsonify({"success": False, "error": "Invalid API key"}), 403

            allowed, error_response = _enforce_api_key_constraints(context)
            if not allowed:
                return error_response

            g.api_key_auth = context

            return f(*args, **kwargs)
        return decorated_function
    return decorator


def conditional_limit(limit_string):
    """
    Conditionally apply rate limiting if limiter is available

    Args:
        limit_string: Rate limit string (e.g., "10 per minute")

    Returns:
        Decorator function that applies rate limiting if available

    Usage:
        @app.route('/api/endpoint')
        @conditional_limit("10 per minute")
        def endpoint():
            return {"status": "ok"}
    """
    def decorator(f):
        # Lazy import to avoid circular dependency
        try:
            from config import limiter
            if limiter:
                return limiter.limit(limit_string)(f)
        except (ImportError, AttributeError):
            pass
        return f
    return decorator


def add_security_headers(response):
    """
    Add security headers to response

    Args:
        response: Flask response object

    Returns:
        Response with security headers added

    Security headers:
    - X-Content-Type-Options: Prevent MIME sniffing
    - X-Frame-Options: Prevent clickjacking
    - X-XSS-Protection: Enable XSS filtering (legacy)
    - Strict-Transport-Security: Force HTTPS (production only)
    - Content-Security-Policy: Restrict resource loading
    """
    # Prevent MIME sniffing
    response.headers['X-Content-Type-Options'] = 'nosniff'

    # Prevent clickjacking
    response.headers['X-Frame-Options'] = 'DENY'

    # Enable XSS protection (legacy browsers)
    response.headers['X-XSS-Protection'] = '1; mode=block'

    # A05-01 OWASP fix: Enable HSTS for production deployments
    # Enforces HTTPS and prevents protocol downgrade attacks
    if os.environ.get('FLASK_ENV') == 'production' or os.environ.get('ENABLE_HSTS', 'false').lower() == 'true':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains; preload'

    # Content Security Policy
    # Note: 'unsafe-inline' required for some inline styles, 'unsafe-eval' for xterm.js
    # CDN sources explicitly allowed for external dependencies
    # frame-src allows embedding asset-discovery service in iframes
    asset_discovery_url = os.environ.get('ASSET_DISCOVERY_URL', 'http://localhost:8080')
    csp_policy = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "img-src 'self' data:; "
        "font-src 'self' https://cdn.jsdelivr.net; "
        f"connect-src 'self' {asset_discovery_url}; "
        f"frame-src 'self' {asset_discovery_url}; "
        "frame-ancestors 'self'; "
        "base-uri 'self'; "
        f"form-action 'self' {asset_discovery_url};"
    )
    response.headers['Content-Security-Policy'] = csp_policy

    return response


# ==============================================================================
# CSRF Protection (OWASP A04)
# ==============================================================================

def require_csrf(f):
    """
    Decorator to require CSRF token validation for state-changing requests.

    The token must be provided in:
    - Header: X-CSRF-Token
    - Form field: csrf_token
    - JSON body: csrf_token

    Usage:
        @app.route('/api/protected', methods=['POST'])
        @require_csrf
        def protected_route():
            return {"status": "ok"}

    Note: API key authenticated requests bypass CSRF since they are
    not vulnerable to cross-site attacks (token in header).
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # API key requests bypass CSRF (already secure against cross-site)
        if request.headers.get('X-API-Key'):
            return f(*args, **kwargs)

        # Get expected token from session
        expected_token = session.get('csrf_token')

        if not expected_token:
            logger.warning(
                f"CSRF: No session token for {request.path} "
                f"from {request.remote_addr}"
            )
            return jsonify({
                "success": False,
                "error": "CSRF token missing. Please refresh the page."
            }), 403

        # Get provided token from request
        provided_token = (
            request.headers.get('X-CSRF-Token') or
            request.form.get('csrf_token') or
            (request.get_json(silent=True) or {}).get('csrf_token')
        )

        if not provided_token:
            logger.warning(
                f"CSRF: No token provided for {request.path} "
                f"from {request.remote_addr}"
            )
            return jsonify({
                "success": False,
                "error": "CSRF token required for this request"
            }), 403

        if not secrets.compare_digest(str(expected_token), str(provided_token)):
            logger.warning(
                f"CSRF: Token mismatch for {request.path} "
                f"from {request.remote_addr}"
            )
            return jsonify({
                "success": False,
                "error": "Invalid CSRF token"
            }), 403

        return f(*args, **kwargs)
    return decorated_function


# ==============================================================================
# Security Event Logging (OWASP A09)
# ==============================================================================

def log_security_event(event_type: str, details: dict = None,
                       severity: str = "info", user_id: int = None):
    """
    Log a security event for monitoring and alerting.

    Args:
        event_type: Type of event (e.g., "login_failed", "access_denied")
        details: Additional event details
        severity: "info", "warning", "critical"
        user_id: Associated user ID if applicable

    Events are logged to:
    1. Application logger (always)
    2. Security webhook if configured (SECURITY_WEBHOOK_URL env var)

    Supported event types:
    - login_success, login_failed
    - access_denied, privilege_escalation_attempt
    - csrf_violation, rate_limit_exceeded
    - account_locked, account_unlocked
    - mfa_enabled, mfa_disabled
    - api_key_regenerated
    """
    import json
    from datetime import datetime

    event = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "event_type": event_type,
        "severity": severity,
        "source_ip": request.remote_addr if request else None,
        "user_agent": request.user_agent.string[:200] if request else None,
        "user_id": user_id,
        "path": request.path if request else None,
        "details": details or {}
    }

    # Log to application logger
    log_msg = f"SECURITY_EVENT: {event_type} | {json.dumps(event)}"
    if severity == "critical":
        logger.critical(log_msg)
    elif severity == "warning":
        logger.warning(log_msg)
    else:
        logger.info(log_msg)

    # Send to webhook if configured
    webhook_url = os.environ.get('SECURITY_WEBHOOK_URL')
    if webhook_url:
        try:
            import requests as http_requests
            http_requests.post(
                webhook_url,
                json=event,
                timeout=5,
                headers={"Content-Type": "application/json"}
            )
        except Exception as e:
            logger.error(f"Failed to send security event to webhook: {e}")

    return event


# ==============================================================================
# Module-level API Key Setup
# ==============================================================================

# Default API key file path
API_KEY_FILE = Path(__file__).parent.parent / '.api_key'

# Module-level API key manager instance
_api_key_manager = APIKeyManager(API_KEY_FILE)

# Expose the current API key for backwards compatibility
API_KEY = _api_key_manager.api_key


def get_api_key_manager():
    """Get the module-level API key manager instance"""
    return _api_key_manager


def require_api_key(f):
    """
    Simple decorator to require API key authentication
    Uses the module-level API key manager.

    Usage:
        @app.route('/api/protected')
        @require_api_key
        def protected_route():
            return {"data": "secret"}
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check for API key in header or session
        provided_key = request.headers.get('X-API-Key') or session.get('api_key')

        if not provided_key:
            logger.warning(f"Unauthorized access attempt from {request.remote_addr}")
            return jsonify({"success": False, "error": "API key required"}), 401

        context = _validate_api_key_with_context(provided_key)
        if not context:
            logger.warning(f"Invalid API key from {request.remote_addr}")
            return jsonify({"success": False, "error": "Invalid API key"}), 403

        allowed, error_response = _enforce_api_key_constraints(context)
        if not allowed:
            return error_response

        g.api_key_auth = context
        g.current_auth_user = ScopedAPIUser(context)

        return f(*args, **kwargs)
    return decorated_function


# =============================================================================
# Unified Authentication with RBAC
# =============================================================================

def _get_authenticated_user():
    """
    Get the current authenticated user from either:
    1. API key authentication (returns VirtualApiUser)
    2. Session-based authentication (Flask-Login current_user)

    Returns:
        User object or None if not authenticated
    """
    # Check for API key first
    provided_key = request.headers.get('X-API-Key') or session.get('api_key')
    context = _validate_api_key_with_context(provided_key)
    if context:
        allowed, error_response = _enforce_api_key_constraints(context)
        if not allowed:
            g.api_key_auth_error = error_response
            return None

        g.api_key_auth = context
        return ScopedAPIUser(context)

    # Fall back to Flask-Login session auth
    if current_user and current_user.is_authenticated:
        return current_user

    return None


def require_auth(f):
    """
    Unified authentication decorator that accepts both API key and session auth.

    Unlike require_api_key, this also accepts Flask-Login session authentication.
    Sets g.current_auth_user for downstream access.

    Usage:
        @app.route('/api/data')
        @require_auth
        def get_data():
            user = g.current_auth_user
            return {"user": user.username}
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = _get_authenticated_user()
        if not user:
            if hasattr(g, 'api_key_auth_error'):
                return g.api_key_auth_error
            logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
            return jsonify({"success": False, "error": "Authentication required"}), 401

        g.current_auth_user = user
        return f(*args, **kwargs)
    return decorated_function


def require_auth_and_permission(permission):
    """
    Decorator to require authentication AND a specific permission.

    Supports both API key auth (SuperAdmin access) and session-based auth with RBAC.

    Args:
        permission: Permission string (e.g., 'run_audits', 'add_servers')

    Usage:
        @app.route('/api/servers', methods=['POST'])
        @require_auth_and_permission('add_servers')
        def add_server():
            return {"status": "created"}
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = _get_authenticated_user()
            if not user:
                if hasattr(g, 'api_key_auth_error'):
                    return g.api_key_auth_error
                logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
                return jsonify({"success": False, "error": "Authentication required"}), 401

            # Check permission
            if not user.has_permission(permission):
                logger.warning(
                    f"Permission denied: {getattr(user, 'username', 'unknown')} lacks '{permission}' for {request.path}"
                )
                return jsonify({
                    "success": False,
                    "error": f"Permission denied: {permission}",
                    "required_permission": permission
                }), 403

            g.current_auth_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_auth_and_role(*roles):
    """
    Decorator to require authentication AND one of the specified roles.

    Args:
        roles: Role strings (e.g., 'Admin', 'SuperAdmin')

    Usage:
        @app.route('/api/admin/settings')
        @require_auth_and_role('Admin', 'SuperAdmin')
        def admin_settings():
            return {"settings": {...}}
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = _get_authenticated_user()
            if not user:
                if hasattr(g, 'api_key_auth_error'):
                    return g.api_key_auth_error
                logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
                return jsonify({"success": False, "error": "Authentication required"}), 401

            # Check role (hierarchy-aware when supported)
            user_role = getattr(user, 'role', None)
            has_required_role = False

            if hasattr(user, 'has_role') and callable(getattr(user, 'has_role')):
                has_required_role = any(user.has_role(role) for role in roles)
            else:
                has_required_role = user_role in roles

            if not has_required_role:
                logger.warning(
                    f"Role denied: {getattr(user, 'username', 'unknown')} has role '{user_role}', required: {roles}"
                )
                return jsonify({
                    "success": False,
                    "error": f"Insufficient role. Required: {', '.join(roles)}",
                    "required_roles": list(roles)
                }), 403

            g.current_auth_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# =============================================================================
# P1-D: Role Hierarchy Validation for Assignment
# =============================================================================

def validate_role_assignment(assigner_role: str, target_role: str, action: str = 'assign') -> tuple:
    """
    Validate that assigner can assign/modify target role per P1-D security controls.

    Enforces principle: "You can only assign roles at or below your own role level."

    Role Hierarchy:
        Viewer (1) < Operator (2) < Analyst (3) < Admin (4) < SuperAdmin (5)

    Assignment Rules:
        - SuperAdmin can assign any role (1-5)
        - Admin can assign up to Admin (1-4)
        - Analyst can assign up to Analyst (1-3)
        - Operator can assign up to Operator (1-2)
        - Viewer cannot assign roles (level 1, no manage_users permission anyway)

    Args:
        assigner_role: Role of the user performing the action
        target_role: Role being assigned/checked
        action: Action type ('assign', 'create', 'modify') for error messages

    Returns:
        Tuple of (is_valid: bool, error_message: str)

    Examples:
        >>> validate_role_assignment('Admin', 'Analyst', 'assign')
        (True, '')

        >>> validate_role_assignment('Admin', 'SuperAdmin', 'assign')
        (False, 'Cannot assign SuperAdmin role (requires SuperAdmin)')

        >>> validate_role_assignment('Analyst', 'Admin', 'create')
        (False, 'Cannot create Admin role (requires Admin or higher)')

        >>> validate_role_assignment('Operator', 'Operator', 'assign')
        (True, '')  # Same level OK

    Compliance:
        - NIST 800-53: AC-2 (Account Management), AC-6 (Least Privilege)
        - SOC 2: CC6.1 (Logical Access)
        - ISO 27001: A.9.2.3 (Privileged Access)
        - PCI DSS: 7.1.2 (Role Assignment Controls)
    """
    try:
        from models.user import Role
    except ImportError:
        from web.models.user import Role

    assigner_level = Role.get_role_level(assigner_role)
    target_level = Role.get_role_level(target_role)

    # Validation: assigner must have level >= target level
    if assigner_level < target_level:
        # Provide specific error messages for common cases
        if target_role == 'SuperAdmin':
            return False, 'Cannot {} SuperAdmin role (requires SuperAdmin)'.format(action)
        elif target_role == 'Admin':
            return False, 'Cannot {} Admin role (requires Admin or higher)'.format(action)
        else:
            return False, f'Cannot {action} {target_role} role (requires {target_role} or higher)'

    return True, ''


def can_modify_user_role(admin_role: str, target_user_role: str) -> tuple:
    """
    Validate that admin can modify a user with target_user_role.

    Prevents lower-level admins from modifying higher-level users.

    Args:
        admin_role: Role of the admin performing modification
        target_user_role: Current role of the user being modified

    Returns:
        Tuple of (is_valid: bool, error_message: str)

    Examples:
        >>> can_modify_user_role('Admin', 'Viewer')
        (True, '')

        >>> can_modify_user_role('Admin', 'SuperAdmin')
        (False, 'Cannot modify SuperAdmin users (requires SuperAdmin)')

        >>> can_modify_user_role('Analyst', 'Admin')
        (False, 'Cannot modify Admin users (requires Admin or higher)')
    """
    try:
        from models.user import Role
    except ImportError:
        from web.models.user import Role

    admin_level = Role.get_role_level(admin_role)
    target_level = Role.get_role_level(target_user_role)

    if admin_level < target_level:
        if target_user_role == 'SuperAdmin':
            return False, 'Cannot modify SuperAdmin users (requires SuperAdmin)'
        else:
            return False, f'Cannot modify {target_user_role} users (requires {target_user_role} or higher)'

    return True, ''


# =============================================================================
# Password Change Enforcement
# =============================================================================


# Paths that users can access even with must_change_password=True
PASSWORD_CHANGE_EXEMPT_PATHS = {
    '/change-password',
    '/auth/change-password',
    '/api/auth/change-password',
    '/logout',
    '/auth/logout',
    '/api/auth/logout',
    '/static/',  # Static files (CSS, JS)
}


def check_password_change_required():
    """
    Check if the current user must change their password.

    This is called automatically by require_password_changed decorator,
    but can also be used manually in routes.

    Returns:
        Tuple of (must_change: bool, response or None)
        If must_change is True and this is an API request, returns error response.
    """
    if not current_user or not current_user.is_authenticated:
        return False, None

    if not hasattr(current_user, 'must_change_password'):
        return False, None

    if not current_user.must_change_password:
        return False, None

    # Check if current path is exempt
    current_path = request.path.rstrip('/')
    for exempt in PASSWORD_CHANGE_EXEMPT_PATHS:
        if current_path == exempt.rstrip('/') or current_path.startswith(exempt.rstrip('/') + '/'):
            return False, None
        # Also check with trailing slash
        if current_path.startswith('/static'):
            return False, None

    # User must change password but is accessing a non-exempt path
    logger.info(f"User {current_user.username} blocked from {request.path} - password change required")

    # For API requests, return JSON error
    if request.is_json or request.path.startswith('/api/'):
        return True, jsonify({
            "success": False,
            "error": "Password change required",
            "password_change_required": True,  # nosec B105
            "redirect": "/change-password"
        }), 403

    # For regular requests, redirect to password change
    from flask import redirect, url_for
    return True, redirect(url_for('auth.change_password', next=request.url))


def require_password_changed(f):
    """
    Decorator to block access if user must change their password.

    This decorator should be applied to protected routes to ensure
    users with must_change_password=True cannot bypass the requirement
    by accessing API endpoints directly.

    SECURITY NOTE: This is a critical control for the break-glass admin
    account which is created with a generated password that MUST be
    changed before the account can be used.

    Usage:
        @app.route('/api/sensitive')
        @login_required
        @require_password_changed
        def sensitive_route():
            return {"status": "ok"}
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        must_change, response = check_password_change_required()
        if must_change:
            return response
        return f(*args, **kwargs)
    return decorated_function


def require_auth_and_password_changed(*roles):
    """
    Combined decorator: requires auth, role, AND password not pending change.

    This is the most secure decorator combining:
    1. Authentication check
    2. Role-based access control
    3. Password change enforcement

    Usage:
        @app.route('/api/admin')
        @require_auth_and_password_changed('Admin')
        def admin_route():
            return {"status": "ok"}
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # First check authentication and role
            user = _get_authenticated_user()
            if not user:
                if hasattr(g, 'api_key_auth_error'):
                    return g.api_key_auth_error
                logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
                return jsonify({"success": False, "error": "Authentication required"}), 401

            # Check role if specified
            if roles:
                user_role = getattr(user, 'role', 'Viewer')
                has_required_role = False

                if hasattr(user, 'has_role') and callable(getattr(user, 'has_role')):
                    has_required_role = any(user.has_role(role) for role in roles)
                else:
                    has_required_role = user_role in roles

                if not has_required_role:
                    logger.warning(
                        f"Role denied: {getattr(user, 'username', 'unknown')} has '{user_role}', required: {roles}"
                    )
                    return jsonify({
                        "success": False,
                        "error": f"Required role: {roles[0]}",
                        "required_roles": list(roles)
                    }), 403

            # Check password change requirement
            if getattr(user, 'must_change_password', False):
                # Check if current path is exempt
                current_path = request.path.rstrip('/')
                is_exempt = False
                for exempt in PASSWORD_CHANGE_EXEMPT_PATHS:
                    if current_path == exempt.rstrip('/') or current_path.startswith(exempt.rstrip('/') + '/'):
                        is_exempt = True
                        break
                    if current_path.startswith('/static'):
                        is_exempt = True
                        break

                if not is_exempt:
                    logger.info(f"User {getattr(user, 'username', 'unknown')} blocked - password change required")
                    return jsonify({
                        "success": False,
                        "error": "Password change required before accessing this resource",
                        "password_change_required": True,  # nosec B105
                        "redirect": "/change-password"
                    }), 403

            g.current_auth_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_role(*roles):
    """
    Backward-compatible alias for role checks.

    Many route modules import ``require_role`` directly. Internally this maps
    to ``require_auth_and_role`` so both names remain supported.
    """
    return require_auth_and_role(*roles)


def require_auth_and_minimum_role(minimum_role):
    """
    Decorator to require authentication AND minimum role level.

    Role hierarchy: Viewer < Operator < Analyst < Admin < SuperAdmin

    Args:
        minimum_role: Minimum role string

    Usage:
        @app.route('/api/execute')
        @require_auth_and_minimum_role('Operator')
        def execute_action():
            return {"status": "ok"}
    """
    ROLE_LEVELS = {
        'Viewer': 1,
        'Operator': 2,
        'Analyst': 3,
        'Admin': 4,
        'SecurityAdmin': 5,
        'SuperAdmin': 6,
    }

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = _get_authenticated_user()
            if not user:
                if hasattr(g, 'api_key_auth_error'):
                    return g.api_key_auth_error
                logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
                return jsonify({"success": False, "error": "Authentication required"}), 401

            # Check minimum role level
            user_role = getattr(user, 'role', 'Viewer')
            user_level = ROLE_LEVELS.get(user_role, 0)
            min_level = ROLE_LEVELS.get(minimum_role, 999)

            if user_level < min_level:
                logger.warning(
                    f"Role level denied: {getattr(user, 'username', 'unknown')} has '{user_role}', minimum: '{minimum_role}'"
                )
                return jsonify({
                    "success": False,
                    "error": f"Minimum role required: {minimum_role}",
                    "minimum_role": minimum_role
                }), 403

            g.current_auth_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def safe_error_response(error: Exception, status_code: int = 500,
                        custom_message: str = None) -> tuple:
    """
    Create a safe error response that sanitizes details in production (A05-03 OWASP fix)

    Args:
        error: The exception that occurred
        status_code: HTTP status code to return
        custom_message: Optional custom message for production

    Returns:
        Tuple of (jsonify response, status_code)

    Usage:
        try:
            do_something()
        except Exception as e:
            return safe_error_response(e)
    """
    is_production = os.environ.get('FLASK_ENV') == 'production'

    if is_production:
        # Log full error for debugging, but don't expose to client
        logger.error(f"Error in {request.path}: {error}", exc_info=True)
        error_msg = custom_message or "An internal error occurred. Please try again later."
    else:
        # In development, expose full error for debugging
        error_msg = str(error)
        logger.error(f"Error in {request.path}: {error}")

    return jsonify({"success": False, "error": error_msg}), status_code


# =============================================================================
# Action Audit Logging
# =============================================================================

def log_action(action_type, resource_type=None, resource_id=None, details=None, success=True):
    """
    Log user action to AuthAuditLog for audit trail.

    Args:
        action_type: Type of action (e.g., 'create_server', 'run_audit', 'delete_schedule')
        resource_type: Type of resource affected (e.g., 'server', 'audit', 'schedule')
        resource_id: ID of the resource affected
        details: Additional details as dict
        success: Whether the action succeeded

    Usage:
        log_action('create_server', 'server', new_server.id, {'name': 'web-01'})
    """
    try:
        from models.user import AuthAuditLog
        from config import SessionLocal
        import json

        user = _get_authenticated_user()
        user_id = getattr(user, 'id', None) if user else None
        username = getattr(user, 'username', 'api_key_user') if user else 'unknown'

        details_json = json.dumps({
            'resource_type': resource_type,
            'resource_id': resource_id,
            **(details or {})
        }) if resource_type or resource_id or details else None

        db = SessionLocal()
        try:
            log_entry = AuthAuditLog(
                user_id=user_id if user_id and user_id > 0 else None,
                event_type=action_type,
                username=username,
                ip_address=request.remote_addr if request else None,
                user_agent=request.headers.get('User-Agent', '')[:500] if request else None,
                details=details_json,
                success=success,
            )
            db.add(log_entry)
            db.commit()
            logger.debug(f"Logged action: {action_type} by {username}")
        finally:
            db.close()
    except Exception as e:
        # Don't fail the request if logging fails
        logger.error(f"Failed to log action {action_type}: {e}")


def require_auth_permission_and_log(permission, action_type, resource_type=None):
    """
    Decorator combining auth, permission check, and action logging.

    Args:
        permission: Permission string required
        action_type: Action type for audit log
        resource_type: Resource type for audit log

    Usage:
        @app.route('/api/servers', methods=['POST'])
        @require_auth_permission_and_log('add_servers', 'create_server', 'server')
        def add_server():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = _get_authenticated_user()
            if not user:
                if hasattr(g, 'api_key_auth_error'):
                    return g.api_key_auth_error
                logger.warning(f"Unauthorized access attempt from {request.remote_addr} to {request.path}")
                return jsonify({"success": False, "error": "Authentication required"}), 401

            # Check permission
            if not user.has_permission(permission):
                log_action(action_type, resource_type, details={'denied': True, 'permission': permission}, success=False)
                logger.warning(
                    f"Permission denied: {getattr(user, 'username', 'unknown')} lacks '{permission}' for {request.path}"
                )
                return jsonify({
                    "success": False,
                    "error": f"Permission denied: {permission}",
                    "required_permission": permission
                }), 403

            g.current_auth_user = user

            # Execute the function
            result = f(*args, **kwargs)

            # Log successful action
            response = result[0] if isinstance(result, tuple) else result
            status_code = result[1] if isinstance(result, tuple) and len(result) > 1 else 200
            success = status_code < 400

            # Extract resource_id from kwargs if available
            resource_id = kwargs.get('server_id') or kwargs.get('schedule_id') or kwargs.get('id')
            log_action(action_type, resource_type, resource_id, success=success)

            return result
        return decorated_function
    return decorator


__all__ = [
    'APIKeyManager',
    'require_api_key',
    'require_api_key_factory',
    'require_auth',
    'require_auth_and_permission',
    'require_auth_and_role',
    'require_role',
    'require_auth_and_minimum_role',
    'require_auth_permission_and_log',
    'log_action',
    'conditional_limit',
    'add_security_headers',
    'safe_error_response',
    'API_KEY',
    'API_KEY_FILE',
    'PERMISSIONS',
    'get_api_key_manager',
]
