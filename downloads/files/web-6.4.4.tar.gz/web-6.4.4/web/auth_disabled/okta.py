"""
Okta OIDC Authentication Module

This module provides OAuth 2.0 / OIDC authentication via Okta.
It supports:
- SSO with Okta accounts
- Okta group-based role mapping
- JIT (just-in-time) user provisioning
- Automatic discovery of Okta endpoints

Environment Configuration:
    OKTA_ENABLED: Enable Okta authentication (default: false)
    OKTA_DOMAIN: Okta domain (e.g., dev-12345.okta.com)
    OKTA_CLIENT_ID: Application (client) ID
    OKTA_CLIENT_SECRET: Client secret value
    OKTA_REDIRECT_URI: OAuth callback URL
    OKTA_SCOPES: Space-separated OAuth scopes
    OKTA_ROLE_MAPPING: JSON mapping of Okta group names to roles
    OKTA_DEFAULT_ROLE: Default role for users without mapped groups
    OKTA_ALLOW_LOCAL_FALLBACK: Allow local auth when Okta unavailable

Usage:
    from auth.okta import get_okta_auth

    okta = get_okta_auth()
    if okta.enabled:
        auth_url = okta.get_auth_url(state="random-state")
        # Redirect user to auth_url
        # On callback:
        user_info = okta.handle_callback(code="...")

Author: Security Audit Toolkit Team
Date: March 2026
"""

import json
import logging
import os
import secrets
from dataclasses import dataclass, field
from typing import Any, Optional
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

# Try to import authlib - may not be installed
try:
    from authlib.jose import JsonWebKey, jwt
    from authlib.oauth2.rfc6749 import OAuth2Token
    from authlib.integrations.requests_client import OAuth2Session
    import requests as http_requests

    AUTHLIB_AVAILABLE = True
except ImportError:
    AUTHLIB_AVAILABLE = False
    logger.warning("authlib not installed - Okta authentication unavailable")


class OktaAuthError(Exception):
    """Base exception for Okta authentication errors"""

    pass


class OktaConfigError(OktaAuthError):
    """Configuration error"""

    pass


class OktaTokenError(OktaAuthError):
    """Token acquisition error"""

    pass


class OktaUserInfoError(OktaAuthError):
    """User info retrieval error"""

    pass


@dataclass
class OktaConfig:
    """Okta configuration loaded from environment variables"""

    enabled: bool = False
    domain: str = ""
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = ""
    scopes: list = field(default_factory=lambda: ["openid", "profile", "email", "groups"])
    role_mapping: dict = field(default_factory=dict)
    default_role: str = "Viewer"
    allow_local_fallback: bool = True
    # Authorization server (default is org or custom)
    auth_server_id: str = "default"

    @classmethod
    def from_env(cls) -> "OktaConfig":
        """Load configuration from environment variables"""
        enabled = os.environ.get("OKTA_ENABLED", "false").lower() in ("true", "1", "yes")

        # Parse scopes
        scopes_str = os.environ.get("OKTA_SCOPES", "openid profile email groups")
        scopes = scopes_str.split()

        # Parse role mapping JSON
        role_mapping = {}
        mapping_str = os.environ.get("OKTA_ROLE_MAPPING", "{}")
        try:
            role_mapping = json.loads(mapping_str)
        except json.JSONDecodeError as e:
            logger.warning(f"Invalid OKTA_ROLE_MAPPING JSON: {e}")

        return cls(
            enabled=enabled,
            domain=os.environ.get("OKTA_DOMAIN", ""),
            client_id=os.environ.get("OKTA_CLIENT_ID", ""),
            client_secret=os.environ.get("OKTA_CLIENT_SECRET", ""),
            redirect_uri=os.environ.get("OKTA_REDIRECT_URI", ""),
            scopes=scopes,
            role_mapping=role_mapping,
            default_role=os.environ.get("OKTA_DEFAULT_ROLE", "Viewer"),
            allow_local_fallback=os.environ.get("OKTA_ALLOW_LOCAL_FALLBACK", "true").lower()
            in ("true", "1", "yes"),
            auth_server_id=os.environ.get("OKTA_AUTH_SERVER_ID", "default"),
        )

    def validate(self) -> tuple[bool, list[str]]:
        """
        Validate configuration.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []

        if not self.enabled:
            return True, []

        if not self.domain:
            errors.append("OKTA_DOMAIN is required")
        if not self.client_id:
            errors.append("OKTA_CLIENT_ID is required")
        if not self.client_secret:
            errors.append("OKTA_CLIENT_SECRET is required")
        if not self.redirect_uri:
            errors.append("OKTA_REDIRECT_URI is required")

        # Validate role mapping values
        valid_roles = {"SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"}
        for group_name, role in self.role_mapping.items():
            if role not in valid_roles:
                errors.append(f"Invalid role '{role}' for group {group_name}")

        if self.default_role not in valid_roles:
            errors.append(f"Invalid default role: {self.default_role}")

        return len(errors) == 0, errors


@dataclass
class OktaUser:
    """User information from Okta"""

    username: str
    email: str
    display_name: str
    external_id: str  # Okta user ID (sub claim)
    groups: list[str]  # List of group names
    role: str  # Mapped role
    raw_claims: dict = field(default_factory=dict)


class OktaAuth:
    """
    Okta OIDC authentication handler.

    This class handles the OAuth 2.0 / OIDC flow with Okta identity platform.
    Uses Authlib for OAuth2/OIDC operations.
    """

    # Role priority (highest first)
    ROLE_PRIORITY = ["SuperAdmin", "Admin", "Analyst", "Operator", "Viewer"]

    def __init__(self, config: Optional[OktaConfig] = None):
        """
        Initialize Okta authentication handler.

        Args:
            config: Optional OktaConfig instance. If not provided, loads from environment.
        """
        if not AUTHLIB_AVAILABLE:
            raise OktaConfigError(
                "authlib library not installed. Install with: pip install Authlib"
            )

        self.config = config or OktaConfig.from_env()
        self._endpoints: Optional[dict] = None
        self._jwks: Optional[Any] = None

    @property
    def enabled(self) -> bool:
        """Check if Okta authentication is enabled and configured"""
        if not self.config.enabled:
            return False
        is_valid, errors = self.config.validate()
        if not is_valid:
            logger.warning(f"Okta configuration errors: {errors}")
        return is_valid

    @property
    def issuer(self) -> str:
        """Get the Okta issuer URL"""
        if self.config.auth_server_id == "default":
            # Use org authorization server
            return f"https://{self.config.domain}/oauth2/default"
        elif self.config.auth_server_id:
            # Use custom authorization server
            return f"https://{self.config.domain}/oauth2/{self.config.auth_server_id}"
        else:
            # Use Okta org URL directly
            return f"https://{self.config.domain}"

    def _get_discovery_url(self) -> str:
        """Get the OIDC discovery document URL"""
        return f"{self.issuer}/.well-known/openid-configuration"

    def _discover_endpoints(self) -> dict:
        """
        Fetch and cache OIDC discovery document.

        Returns:
            Dict with authorization_endpoint, token_endpoint, userinfo_endpoint, etc.
        """
        if self._endpoints is not None:
            return self._endpoints

        discovery_url = self._get_discovery_url()
        logger.debug(f"Fetching Okta discovery document: {discovery_url}")

        try:
            response = http_requests.get(discovery_url, timeout=10)
            response.raise_for_status()
            self._endpoints = response.json()
            logger.debug(f"Okta endpoints discovered: {list(self._endpoints.keys())}")
            return self._endpoints
        except Exception as e:
            logger.error(f"Failed to fetch Okta discovery document: {e}")
            raise OktaConfigError(f"Cannot reach Okta: {e}")

    def _decode_jwt_segment(self, segment: str, segment_name: str) -> dict[str, Any]:
        """Decode a JWT segment (header/payload) from base64url JSON."""
        import base64

        if not segment:
            raise OktaTokenError(f"ID token {segment_name} is empty")

        padding = "=" * (-len(segment) % 4)
        try:
            decoded = base64.urlsafe_b64decode(segment + padding)
            data = json.loads(decoded)
            if not isinstance(data, dict):
                raise OktaTokenError(f"ID token {segment_name} must be a JSON object")
            return data
        except OktaTokenError:
            raise
        except Exception as e:
            logger.error(f"Failed to decode ID token {segment_name}: {e}")
            raise OktaTokenError(f"Failed to decode ID token {segment_name}: {e}")

    def _get_jwks(self):
        """Fetch and cache Okta JWKS for ID token signature verification."""
        if self._jwks is not None:
            return self._jwks

        endpoints = self._discover_endpoints()
        jwks_uri = endpoints.get("jwks_uri")
        if not jwks_uri:
            raise OktaConfigError("Okta discovery document missing jwks_uri")

        try:
            response = http_requests.get(jwks_uri, timeout=10)
            response.raise_for_status()
            self._jwks = JsonWebKey.import_key_set(response.json())
            return self._jwks
        except Exception as e:
            logger.error(f"Failed to fetch Okta JWKS: {e}")
            raise OktaTokenError(f"Failed to fetch Okta signing keys: {e}")

    def get_auth_url(self, state: str, nonce: Optional[str] = None) -> str:
        """
        Generate the authorization URL for Okta login.

        Args:
            state: State parameter for CSRF protection (store in session)
            nonce: Optional nonce for ID token validation

        Returns:
            Authorization URL to redirect user to
        """
        endpoints = self._discover_endpoints()
        auth_endpoint = endpoints["authorization_endpoint"]

        params = {
            "client_id": self.config.client_id,
            "response_type": "code",
            "scope": " ".join(self.config.scopes),
            "redirect_uri": self.config.redirect_uri,
            "state": state,
        }

        if nonce:
            params["nonce"] = nonce

        auth_url = f"{auth_endpoint}?{urlencode(params)}"
        logger.debug(f"Generated Okta auth URL (state={state[:8]}...)")
        return auth_url

    def exchange_code_for_tokens(self, code: str) -> dict:
        """
        Exchange authorization code for tokens.

        Args:
            code: Authorization code from callback

        Returns:
            Dict with access_token, id_token, refresh_token, expires_in
        """
        endpoints = self._discover_endpoints()
        token_endpoint = endpoints["token_endpoint"]

        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.config.redirect_uri,
            "client_id": self.config.client_id,
            "client_secret": self.config.client_secret,
        }

        try:
            response = http_requests.post(
                token_endpoint,
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15,
            )

            if not response.ok:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get("error_description", response.text)
                logger.error(f"Okta token exchange failed: {error_msg}")
                raise OktaTokenError(f"Token exchange failed: {error_msg}")

            tokens = response.json()
            logger.debug("Successfully exchanged code for tokens")
            return tokens

        except http_requests.exceptions.RequestException as e:
            logger.error(f"Okta token request failed: {e}")
            raise OktaTokenError(f"Token request failed: {e}")

    def get_userinfo(self, access_token: str) -> dict:
        """
        Get user information from Okta userinfo endpoint.

        Args:
            access_token: Access token from token exchange

        Returns:
            Dict with user information (sub, email, name, groups, etc.)
        """
        endpoints = self._discover_endpoints()
        userinfo_endpoint = endpoints["userinfo_endpoint"]

        try:
            response = http_requests.get(
                userinfo_endpoint,
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=10,
            )

            if not response.ok:
                logger.error(f"Okta userinfo request failed: {response.text}")
                raise OktaUserInfoError(f"Userinfo request failed: {response.status_code}")

            userinfo = response.json()
            logger.debug(f"Retrieved userinfo for: {userinfo.get('email', 'unknown')}")
            return userinfo

        except http_requests.exceptions.RequestException as e:
            logger.error(f"Okta userinfo request failed: {e}")
            raise OktaUserInfoError(f"Userinfo request failed: {e}")

    def decode_id_token(self, id_token: str) -> dict:
        """
        Decode and validate ID token claims.

        Security requirements:
        - Reject unsigned tokens (`alg=none`)
        - Require non-empty signature segment
        - Verify signature against Okta JWKS
        - Validate essential claims (iss, aud, exp, iat, sub)

        Args:
            id_token: JWT ID token from token response

        Returns:
            Dict of validated claims
        """
        # Split token
        parts = id_token.split(".")
        if len(parts) != 3:
            raise OktaTokenError("Invalid ID token format")

        header = self._decode_jwt_segment(parts[0], "header")
        algorithm = str(header.get("alg", "")).strip()

        if not algorithm:
            raise OktaTokenError("ID token missing signing algorithm")

        if algorithm.lower() == "none":
            raise OktaTokenError("Unsigned ID tokens (alg=none) are not allowed")

        if not parts[2].strip():
            raise OktaTokenError("ID token signature is missing")

        if algorithm.upper().startswith("HS"):
            raise OktaTokenError("Symmetric ID token algorithms are not allowed")

        claims_options = {
            "iss": {"essential": True, "value": self.issuer},
            "aud": {"essential": True, "values": [self.config.client_id]},
            "exp": {"essential": True},
            "iat": {"essential": True},
            "sub": {"essential": True},
        }

        try:
            claims = jwt.decode(id_token, self._get_jwks(), claims_options=claims_options)
            claims.validate(leeway=60)
            return dict(claims)
        except OktaTokenError:
            raise
        except Exception as e:
            logger.error(f"Failed to verify ID token: {e}")
            raise OktaTokenError(f"Failed to verify ID token: {e}")

    def handle_callback(self, code: str, state: str) -> OktaUser:
        """
        Handle OAuth callback and return user information.

        Args:
            code: Authorization code from callback
            state: State parameter (should be validated by caller)

        Returns:
            OktaUser instance with user information
        """
        # Exchange code for tokens
        tokens = self.exchange_code_for_tokens(code)
        access_token = tokens.get("access_token")
        id_token = tokens.get("id_token")

        if not access_token:
            raise OktaTokenError("No access token in response")

        # Get user info from userinfo endpoint
        userinfo = self.get_userinfo(access_token)

        # Also decode ID token for additional claims (groups might be here)
        id_claims = {}
        if id_token:
            try:
                id_claims = self.decode_id_token(id_token)
            except Exception as e:
                logger.warning(f"Could not decode ID token: {e}")

        # Merge claims (userinfo takes precedence)
        all_claims = {**id_claims, **userinfo}

        # Extract user fields
        sub = all_claims.get("sub", "")
        email = all_claims.get("email", "")
        name = all_claims.get("name", "") or all_claims.get("preferred_username", "")

        # Extract groups (may be in userinfo or ID token claims)
        groups = all_claims.get("groups", [])
        if isinstance(groups, str):
            groups = [groups]

        # Derive username from email or name
        username = email.split("@")[0] if email else name.replace(" ", "_").lower()
        if not username:
            username = sub[:20]

        # Map groups to role
        role = self._map_groups_to_role(groups)

        return OktaUser(
            username=username,
            email=email,
            display_name=name or username,
            external_id=sub,
            groups=groups,
            role=role,
            raw_claims=all_claims,
        )

    def _map_groups_to_role(self, groups: list) -> str:
        """
        Map Okta groups to local role.

        Checks groups in priority order, returns highest-priority match.

        Args:
            groups: List of group names from Okta

        Returns:
            Role name (defaults to config.default_role)
        """
        if not groups:
            return self.config.default_role

        # Check groups in priority order (highest role first)
        for priority_role in self.ROLE_PRIORITY:
            for group_name, mapped_role in self.config.role_mapping.items():
                if mapped_role == priority_role and group_name in groups:
                    logger.debug(f"Mapped group {group_name} to role {mapped_role}")
                    return mapped_role

        logger.debug(f"No matching groups, using default role: {self.config.default_role}")
        return self.config.default_role

    def get_logout_url(self, id_token: Optional[str] = None, post_logout_redirect_uri: Optional[str] = None) -> str:
        """
        Get the Okta logout URL.

        Args:
            id_token: Optional ID token for logout hint
            post_logout_redirect_uri: Where to redirect after logout

        Returns:
            Logout URL
        """
        endpoints = self._discover_endpoints()
        end_session_endpoint = endpoints.get("end_session_endpoint")

        if not end_session_endpoint:
            # Fallback to standard Okta logout URL
            end_session_endpoint = f"https://{self.config.domain}/oauth2/v1/logout"

        params = {}
        if id_token:
            params["id_token_hint"] = id_token
        if post_logout_redirect_uri:
            params["post_logout_redirect_uri"] = post_logout_redirect_uri

        if params:
            return f"{end_session_endpoint}?{urlencode(params)}"
        return end_session_endpoint

    def test_connection(self) -> tuple[bool, str]:
        """
        Test Okta connection by fetching discovery document.

        Returns:
            Tuple of (success, message)
        """
        try:
            endpoints = self._discover_endpoints()
            issuer = endpoints.get("issuer", "unknown")
            return True, f"Connected to Okta issuer: {issuer}"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"


# =============================================================================
# Module-level helpers
# =============================================================================

_okta_auth_instance: Optional[OktaAuth] = None


def get_okta_auth() -> Optional[OktaAuth]:
    """
    Get or create the global OktaAuth instance.

    Returns:
        OktaAuth instance if authlib is available and configured, None otherwise
    """
    global _okta_auth_instance

    if not AUTHLIB_AVAILABLE:
        return None

    if _okta_auth_instance is None:
        try:
            _okta_auth_instance = OktaAuth()
        except OktaConfigError as e:
            logger.warning(f"Could not initialize OktaAuth: {e}")
            return None

    return _okta_auth_instance


def okta_enabled() -> bool:
    """Check if Okta authentication is available and enabled"""
    okta = get_okta_auth()
    return okta is not None and okta.enabled
