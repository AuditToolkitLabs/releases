"""
Flask-Login Authentication Initialization Module

Initializes Flask-Login for user session management and provides
helper functions for authentication workflows.

Author: Security Audit Toolkit Team
Date: March 2026
"""

import logging
import os
from functools import wraps
from flask import redirect, url_for, request, session
from flask_login import LoginManager, current_user

logger = logging.getLogger(__name__)

# Flask-Login instance
login_manager = LoginManager()


def init_auth(app, db_session):
    """
    Initialize Flask-Login with the Flask app

    Args:
        app: Flask application instance
        db_session: SQLAlchemy database session

    Returns:
        LoginManager instance
    """
    from models.user import (
        User,
        create_initial_admin,
        get_initial_admin_credentials_file_path,
        read_initial_admin_credentials,
    )
    # Import models with relationships to ensure mappers are configured
    from models.schedule import ScheduledAudit  # noqa - needed for Server mapper
    from models.maintenance_window import MaintenanceWindow  # noqa

    # Configure Flask-Login
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    login_manager.session_protection = 'strong'  # Detect session hijacking

    # Session configuration - no persistent cookies, session expires on browser close
    app.config.setdefault('SESSION_PERMANENT', False)
    app.config.setdefault('PERMANENT_SESSION_LIFETIME', 28800)  # 8 hours max

    # Resolve session factory for per-request DB sessions in auth callbacks.
    # Using a shared session across concurrent requests can raise SQLAlchemy
    # IllegalStateChangeError/ISCE in worker thread pools.
    session_factory = None
    if callable(db_session) and not hasattr(db_session, 'query'):
        session_factory = db_session
    else:
        try:
            from config import SessionLocal as configured_session_factory
            if configured_session_factory:
                session_factory = configured_session_factory
        except Exception:
            session_factory = None

    def _open_auth_session():
        if session_factory:
            return session_factory(), True
        return db_session, False

    def _close_auth_session(auth_db, should_close):
        if not should_close or auth_db is None:
            return
        try:
            auth_db.close()
        except Exception as close_error:
            logger.debug(f"Auth session close skipped: {close_error}")
        try:
            if hasattr(session_factory, 'remove'):
                session_factory.remove()
        except Exception as remove_error:
            logger.debug(f"Session factory cleanup skipped: {remove_error}")

    @login_manager.user_loader
    def load_user(user_id):
        """Load user by ID for session management"""
        auth_db, should_close = _open_auth_session()
        try:
            return auth_db.get(User, int(user_id))
        except Exception as e:
            logger.error(f"Error loading user {user_id}: {e}")
            return None
        finally:
            _close_auth_session(auth_db, should_close)

    @login_manager.unauthorized_handler
    def unauthorized():
        """Handle unauthorized access attempts"""
        # For API endpoints, return JSON
        if request.path.startswith('/api/'):
            from flask import jsonify
            return jsonify({'error': 'Authentication required', 'code': 401}), 401

        # For web pages, redirect to login
        return redirect(url_for('auth.login', next=request.url))

    @login_manager.request_loader
    def load_user_from_request(req):
        """
        Load user from API key or token header (for API access)

        Supports both legacy X-API-Key and new Authorization: Bearer token
        """
        # Check for legacy API key (system-level access)
        from auth_core import API_KEY
        api_key = req.headers.get('X-API-Key')
        if api_key and api_key == API_KEY:
            # Return a virtual admin user for API key access
            return VirtualApiUser()

        # Check for Bearer token (user session token)
        auth_header = req.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header[7:]
            auth_db, should_close = _open_auth_session()
            try:
                return load_user_from_token(auth_db, token)
            finally:
                _close_auth_session(auth_db, should_close)

        return None

    # Create initial admin user if none exists
    startup_db, startup_should_close = _open_auth_session()
    try:
        admin, password = create_initial_admin(startup_db)
        if admin:
            logger.info(f"Initial admin user created: {admin.username}")

        # Initial admin credentials are bootstrap-only.
        # For existing installations/upgrades, do not mutate admin password or
        # must_change_password state at startup. This prevents patch upgrades
        # from unexpectedly changing login behavior.
        if admin:
            credentials_file = get_initial_admin_credentials_file_path()
            if credentials_file and os.path.exists(credentials_file):
                file_creds = read_initial_admin_credentials()
                if file_creds and file_creds.get('username') == admin.username and not admin.check_password(file_creds.get('password', '')):
                    logger.warning(
                        "Initial admin credentials file does not match newly created admin hash: %s",
                        file_creds.get('path')
                    )
    except Exception as e:
        logger.error(f"Error creating initial admin: {e}")
    finally:
        _close_auth_session(startup_db, startup_should_close)

    # Session timeout checker
    @app.before_request
    def check_session_timeout():
        """
        Check if user session has expired based on security settings.
        Updates session activity timestamp on each request.
        """
        from datetime import datetime, timedelta
        from flask_login import logout_user

        # Skip for unauthenticated users
        if not current_user.is_authenticated:
            return None

        # Skip for API requests (they use tokens/API keys)
        if request.path.startswith('/api/'):
            return None

        # Skip for static files
        if request.path.startswith('/static/'):
            return None

        # Get session timeout from security settings
        try:
            from security_settings import get_security_setting
            timeout_minutes = get_security_setting('session_timeout', 30)
        except ImportError:
            timeout_minutes = 30

        # Check last activity timestamp
        last_activity = session.get('last_activity')
        now = datetime.utcnow()

        if last_activity:
            try:
                last_time = datetime.fromisoformat(last_activity)
                if now - last_time > timedelta(minutes=timeout_minutes):
                    logger.info(
                        f"Session timeout for user {current_user.username} "
                        f"(inactive for {timeout_minutes}+ minutes)"
                    )
                    logout_user()
                    session.clear()
                    return redirect(
                        url_for('auth.login',
                                next=request.url,
                                timeout='1')
                    )
            except (ValueError, TypeError):
                pass

        # Update last activity
        session['last_activity'] = now.isoformat()
        return None

    logger.info("Flask-Login authentication initialized")
    return login_manager


class VirtualApiUser:
    """
    Virtual user for legacy API key authentication

    Used when the system API key is provided via X-API-Key header.
    Has SuperAdmin privileges for backward compatibility.
    """

    def __init__(self):
        self.id = 0
        self.username = 'api_key_user'
        self.role = 'SuperAdmin'
        self.is_active = True
        self.is_authenticated = True
        self.is_anonymous = False

    def get_id(self):
        return '0'

    def has_permission(self, permission):
        return True  # API key has all permissions

    def has_role(self, role):
        return True  # API key has all roles

    def check_minimum_role(self, min_role):
        return True  # API key passes all role checks


def load_user_from_token(db_session, token):
    """
    Load user from a session token

    Args:
        db_session: SQLAlchemy database session
        token: Session token string

    Returns:
        User object or None
    """
    from datetime import datetime
    from models.user import UserSession

    try:
        user_session = db_session.query(UserSession).filter(
            UserSession.session_token == token,
            UserSession.is_active.is_(True),
            UserSession.expires_at > datetime.utcnow()
        ).first()

        if user_session:
            return user_session.user
    except Exception as e:
        logger.error(f"Error loading user from token: {e}")

    return None


def create_session_token(db_session, user, request_info=None):
    """
    Create a new session token for a user

    Args:
        db_session: SQLAlchemy database session
        user: User object
        request_info: Dict with ip_address and user_agent

    Returns:
        Session token string
    """
    from datetime import datetime, timedelta
    from models.user import UserSession
    import secrets

    # Generate secure token
    token = secrets.token_urlsafe(64)

    # Fixed 8 hour session - no remember me option
    expires_at = datetime.utcnow() + timedelta(hours=8)

    # Extract request info (nosec B104 - '0.0.0.0' is default IP value, not server binding)
    ip_address = request_info.get('ip_address', '0.0.0.0') if request_info else '0.0.0.0'  # nosec B104
    user_agent = request_info.get('user_agent', 'Unknown') if request_info else 'Unknown'

    # Create session record
    user_session = UserSession(
        user_id=user.id,
        session_token=token,
        ip_address=ip_address,
        user_agent=user_agent[:500],  # Truncate long user agents
        is_active=True,
        expires_at=expires_at
    )

    db_session.add(user_session)
    db_session.commit()

    return token


def invalidate_session_token(db_session, token):
    """
    Invalidate a session token

    Args:
        db_session: SQLAlchemy database session
        token: Session token to invalidate
    """
    from models.user import UserSession

    try:
        user_session = db_session.query(UserSession).filter(
            UserSession.session_token == token
        ).first()

        if user_session:
            user_session.is_active = False
            db_session.commit()
    except Exception as e:
        logger.error(f"Error invalidating session: {e}")
        db_session.rollback()


def cleanup_expired_sessions(db_session):
    """
    Remove expired session records

    Should be called periodically (e.g., by a scheduled task)
    """
    from datetime import datetime
    from models.user import UserSession

    try:
        expired = db_session.query(UserSession).filter(
            UserSession.expires_at < datetime.utcnow()
        ).delete()

        db_session.commit()
        logger.info(f"Cleaned up {expired} expired sessions")
        return expired
    except Exception as e:
        logger.error(f"Error cleaning up sessions: {e}")
        db_session.rollback()
        return 0


def require_auth(f):
    """
    Decorator that requires authentication for a view

    Checks both Flask-Login session and legacy API key
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from auth_core import API_KEY

        # Check if user is authenticated via Flask-Login
        if current_user.is_authenticated:
            return f(*args, **kwargs)

        # Check legacy API key
        api_key = request.headers.get('X-API-Key') or session.get('api_key')
        if api_key and api_key == API_KEY:
            return f(*args, **kwargs)

        # Not authenticated
        if request.path.startswith('/api/'):
            from flask import jsonify
            return jsonify({'error': 'Authentication required', 'code': 401}), 401

        return redirect(url_for('auth.login', next=request.url))

    return decorated_function


def is_authenticated():
    """
    Check if current request is authenticated

    Checks Flask-Login session or API key header (for programmatic access)
    Note: API key in session is NOT accepted - must use Flask-Login for web UI
    """
    from auth_core import API_KEY

    if current_user.is_authenticated:
        return True

    # Only accept API key from headers (for programmatic/API access)
    # Session-based API key is not accepted for security reasons
    api_key = request.headers.get('X-API-Key')
    return api_key and api_key == API_KEY
