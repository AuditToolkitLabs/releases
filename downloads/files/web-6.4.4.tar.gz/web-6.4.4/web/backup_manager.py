#!/usr/bin/env python3
"""
Backup and Restore Manager for Security Audit Toolkit

Supports both PostgreSQL and SQLite databases with:
- Full database backups
- Incremental backups (PostgreSQL)
- Point-in-time recovery
- Compression and encryption
- Automatic retention management
- Validation and integrity checks

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import sys
import gzip
import json
import shutil
import hashlib
import tempfile
import subprocess  # nosec B404
import tarfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List
from cryptography.fernet import Fernet
import logging

from database_defaults import get_runtime_default_database_url

logger = logging.getLogger(__name__)

DEFAULT_SHARED_DATA_PATHS = [
    '/opt/audit-toolkit/data/agents',
    '/opt/audit-toolkit/shared/asset-discovery-data',
    '/opt/audit-toolkit/shared/asset-discovery-logs',
]


class BackupManager:
    """
    Manages database backups and restores for both PostgreSQL and SQLite
    """

    def __init__(self, backup_dir: str = None, encryption_key: str = None):
        """
        Initialize backup manager

        Args:
            backup_dir: Directory for storing backups (default: ROOT_DIR/backups)
            encryption_key: Optional Fernet encryption key for backup encryption
        """
        from config import ROOT_DIR

        self.backup_dir = Path(backup_dir or os.getenv('BACKUP_DIR', str(ROOT_DIR / 'backups')))
        self.backup_dir.mkdir(exist_ok=True, mode=0o700)

        # Encryption setup
        self.encryption_key = encryption_key or os.getenv('BACKUP_ENCRYPTION_KEY')
        self.cipher = Fernet(self.encryption_key.encode()) if self.encryption_key else None

        # Database configuration
        data_root_env = os.getenv('AUDIT_TOOLKIT_DATA_DIR', '').strip()
        if data_root_env:
            data_root = Path(data_root_env).expanduser().resolve()
        else:
            data_root = ROOT_DIR
        self.database_url = os.getenv('DATABASE_URL', get_runtime_default_database_url(data_root=data_root))
        self.is_postgresql = self.database_url.startswith('postgresql')

        # Parse database connection details
        if self.is_postgresql:
            self._parse_postgresql_url()
        else:
            self._parse_sqlite_url()

    def _parse_postgresql_url(self):
        """Parse PostgreSQL connection URL"""
        # postgresql://user:password@host:port/database
        from urllib.parse import urlparse

        parsed = urlparse(self.database_url)
        self.pg_host = parsed.hostname or 'localhost'
        self.pg_port = parsed.port or 5432
        self.pg_user = parsed.username or 'postgres'
        self.pg_password = parsed.password or ''
        self.pg_database = parsed.path.lstrip('/') or 'audit_toolkit'

        logger.info(f"PostgreSQL backup configured: {self.pg_user}@{self.pg_host}:{self.pg_port}/{self.pg_database}")

    def _parse_sqlite_url(self):
        """Parse SQLite file path from URL"""
        # sqlite:///path/to/database.db
        self.sqlite_path = self.database_url.replace('sqlite:///', '')
        logger.info(f"SQLite backup configured: {self.sqlite_path}")

    def create_backup(
        self,
        backup_type: str = 'full',
        compress: bool = True,
        encrypt: bool = False,
        include_metadata: bool = True,
        include_shared_data: bool = None,
    ) -> Dict[str, any]:
        """
        Create a database backup

        Args:
            backup_type: 'full' or 'incremental' (PostgreSQL only)
            compress: Compress backup with gzip
            encrypt: Encrypt backup (requires encryption_key)
            include_metadata: Include backup metadata file

        Returns:
            Dict with backup details (path, size, checksum, etc.)
        """
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        backup_name = f"backup_{backup_type}_{timestamp}"
        effective_encrypt = self._resolve_backup_encryption_policy(encrypt)

        if effective_encrypt and not self.cipher:
            raise ValueError("Backup encryption is required but no encryption key configured")

        logger.info(f"Creating {backup_type} backup: {backup_name}")

        include_shared_data_effective = (
            self._resolve_include_shared_data_policy()
            if include_shared_data is None
            else bool(include_shared_data)
        )

        try:
            if self.is_postgresql:
                backup_info = self._backup_postgresql(backup_name, backup_type, compress)
            else:
                backup_info = self._backup_sqlite(backup_name, compress)

            # Encrypt if requested
            if effective_encrypt:
                try:
                    backup_info = self._encrypt_backup(backup_info)
                except Exception:
                    plaintext_file = Path(backup_info.get('filepath', ''))
                    if plaintext_file.exists():
                        plaintext_file.unlink()
                    raise

            self._enforce_backup_size_limit(backup_info)

            shared_data_backup = self._build_shared_data_backup(
                backup_name=backup_name,
                compress=compress,
                encrypt=effective_encrypt,
                include_shared_data=include_shared_data_effective,
            )
            backup_info['shared_data_backup'] = shared_data_backup

            # Create metadata file
            if include_metadata:
                self._create_metadata(backup_info)

            logger.info(f"Backup created successfully: {backup_info['filename']}")
            logger.info(f"Size: {backup_info['size_bytes'] / (1024**2):.2f} MB")
            logger.info(f"Checksum: {backup_info['checksum']}")

            return backup_info

        except Exception as e:
            logger.error(f"Backup failed: {e}", exc_info=True)
            raise

    def _resolve_backup_encryption_policy(self, requested_encrypt: bool) -> bool:
        """Determine effective backup encryption based on policy and request."""
        policy_requires_encryption = False

        try:
            from security_settings import get_security_setting
            policy_requires_encryption = bool(get_security_setting('backup_encrypt', False))
        except Exception:
            policy_requires_encryption = os.getenv('BACKUP_ENCRYPTION_ENABLED', 'false').lower() == 'true'

        return bool(requested_encrypt) or policy_requires_encryption

    def _resolve_include_shared_data_policy(self) -> bool:
        """Determine whether shared non-DB data should be included in backups."""
        try:
            from security_settings import get_security_setting
            return bool(get_security_setting('backup_include_shared_data', True))
        except Exception:
            return os.getenv('BACKUP_INCLUDE_SHARED_DATA', 'true').lower() == 'true'

    def _resolve_shared_data_paths(self) -> List[Path]:
        """Resolve configured shared data paths for backup coverage."""
        configured = None
        try:
            from security_settings import get_security_setting
            configured = get_security_setting('backup_shared_data_paths', '')
        except Exception:
            configured = os.getenv('BACKUP_SHARED_DATA_PATHS', '')

        if not configured:
            configured = ','.join(DEFAULT_SHARED_DATA_PATHS)

        raw_paths = [segment.strip() for segment in str(configured).split(',') if segment.strip()]
        return [Path(path) for path in raw_paths]

    def _build_shared_data_backup(
        self,
        backup_name: str,
        compress: bool,
        encrypt: bool,
        include_shared_data: bool,
    ) -> Dict[str, any]:
        """Create companion archive for shared data volumes/files."""
        configured_paths = self._resolve_shared_data_paths()
        configured_path_strings = [str(path) for path in configured_paths]

        if not include_shared_data:
            return {
                'included': False,
                'reason': 'backup_include_shared_data disabled',
                'configured_paths': configured_path_strings,
                'existing_paths': [],
                'missing_paths': configured_path_strings,
            }

        existing_paths = [path for path in configured_paths if path.exists()]
        missing_paths = [str(path) for path in configured_paths if not path.exists()]

        if not existing_paths:
            return {
                'included': False,
                'reason': 'no configured shared data paths exist',
                'configured_paths': configured_path_strings,
                'existing_paths': [],
                'missing_paths': missing_paths,
            }

        extension = '.tar.gz' if compress else '.tar'
        archive_file = self.backup_dir / f"{backup_name}_shared_data{extension}"

        mode = 'w:gz' if compress else 'w'
        with tarfile.open(archive_file, mode) as archive:
            for idx, path in enumerate(existing_paths):
                normalized_name = path.name or f'path-{idx + 1}'
                arcname = f"shared_data/{idx + 1:02d}-{normalized_name}"
                archive.add(path, arcname=arcname, recursive=True)

        encrypted = False
        if encrypt:
            archive_file = self._encrypt_file(archive_file)
            encrypted = True

        return {
            'included': True,
            'archive_filename': archive_file.name,
            'archive_filepath': str(archive_file),
            'archive_size_bytes': archive_file.stat().st_size,
            'archive_checksum': self._calculate_checksum(archive_file),
            'compressed': compress,
            'encrypted': encrypted,
            'configured_paths': configured_path_strings,
            'existing_paths': [str(path) for path in existing_paths],
            'missing_paths': missing_paths,
        }

    def _resolve_backup_max_size_mb(self) -> int:
        """Resolve backup max size policy in MB from security settings or env."""
        try:
            from security_settings import get_security_setting
            value = get_security_setting('backup_max_size', 500)
        except Exception:
            value = os.getenv('BACKUP_MAX_SIZE_MB', '500')

        try:
            parsed = int(value)
        except (TypeError, ValueError):
            parsed = 500

        return max(50, parsed)

    def _enforce_backup_size_limit(self, backup_info: Dict[str, any]):
        """Delete oversize backups and raise when policy threshold is exceeded."""
        backup_path = Path(backup_info.get('filepath', ''))
        size_bytes = int(backup_info.get('size_bytes', 0) or 0)
        max_size_mb = self._resolve_backup_max_size_mb()
        max_size_bytes = max_size_mb * 1024 * 1024

        if size_bytes <= max_size_bytes:
            return

        if backup_path.exists():
            backup_path.unlink()

        metadata_path = backup_path.with_suffix('.json')
        if metadata_path.exists():
            metadata_path.unlink()

        raise ValueError(
            f"Backup size {size_bytes / (1024**2):.2f} MB exceeds configured limit of {max_size_mb} MB"
        )

    def _backup_postgresql(self, backup_name: str, backup_type: str, compress: bool) -> Dict:
        """Create PostgreSQL backup using pg_dump"""
        extension = '.sql.gz' if compress else '.sql'
        backup_file = self.backup_dir / f"{backup_name}{extension}"

        # Set environment variable for password
        env = os.environ.copy()
        env['PGPASSWORD'] = self.pg_password
        pg_dump_bin = shutil.which('pg_dump') or 'pg_dump'

        # Build pg_dump command
        cmd = [
            pg_dump_bin,
            '-h', self.pg_host,
            '-p', str(self.pg_port),
            '-U', self.pg_user,
            '-d', self.pg_database,
            '-F', 'p',  # Plain text format
            '--clean',  # Include DROP commands
            '--if-exists',  # Use IF EXISTS with DROP
            '--no-owner',  # Don't output ownership commands
            '--no-privileges',  # Don't output privilege commands
        ]

        if backup_type == 'full':
            cmd.extend(['--create', '--schema-only'])  # Include CREATE DATABASE

        try:
            # Execute pg_dump
            if compress:
                # Pipe through gzip
                with open(backup_file, 'wb') as f:
                    gzip_bin = shutil.which('gzip') or 'gzip'
                    p1 = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)  # nosec B603
                    p2 = subprocess.Popen([gzip_bin], stdin=p1.stdout, stdout=f, stderr=subprocess.PIPE)  # nosec B603
                    p1.stdout.close()
                    _, stderr2 = p2.communicate()
                    _, stderr1 = p1.communicate()

                    if p1.returncode != 0:
                        raise RuntimeError(f"pg_dump failed: {stderr1.decode()}")
                    if p2.returncode != 0:
                        raise RuntimeError(f"gzip failed: {stderr2.decode()}")
            else:
                with open(backup_file, 'w') as f:
                    result = subprocess.run(
                        cmd,
                        stdout=f,
                        stderr=subprocess.PIPE,
                        env=env,
                        check=True
                    )  # nosec B603

            # Calculate checksum
            checksum = self._calculate_checksum(backup_file)

            return {
                'filename': backup_file.name,
                'filepath': str(backup_file),
                'backup_type': backup_type,
                'database_type': 'postgresql',
                'database_name': self.pg_database,
                'timestamp': datetime.utcnow().isoformat(),
                'size_bytes': backup_file.stat().st_size,
                'compressed': compress,
                'encrypted': False,
                'checksum': checksum
            }

        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"PostgreSQL backup failed: {e.stderr.decode()}")
        except FileNotFoundError:
            raise RuntimeError("pg_dump not found. Install PostgreSQL client tools.")

    def _backup_sqlite(self, backup_name: str, compress: bool) -> Dict:
        """Create SQLite backup using file copy with WAL checkpoint"""
        extension = '.db.gz' if compress else '.db'
        backup_file = self.backup_dir / f"{backup_name}{extension}"

        try:
            # Checkpoint WAL to ensure consistency
            from config import db_engine
            from sqlalchemy import text
            if db_engine:
                with db_engine.connect() as conn:
                    conn.execute(text('PRAGMA wal_checkpoint(FULL)'))

            # Copy database file
            if compress:
                with open(self.sqlite_path, 'rb') as f_in:
                    with gzip.open(backup_file, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
            else:
                shutil.copy2(self.sqlite_path, backup_file)

            # Calculate checksum
            checksum = self._calculate_checksum(backup_file)

            return {
                'filename': backup_file.name,
                'filepath': str(backup_file),
                'backup_type': 'full',
                'database_type': 'sqlite',
                'database_name': Path(self.sqlite_path).name,
                'timestamp': datetime.utcnow().isoformat(),
                'size_bytes': backup_file.stat().st_size,
                'compressed': compress,
                'encrypted': False,
                'checksum': checksum
            }

        except Exception as e:
            raise RuntimeError(f"SQLite backup failed: {e}")

    def _encrypt_backup(self, backup_info: Dict) -> Dict:
        """Encrypt backup file"""
        backup_file = Path(backup_info['filepath'])

        try:
            encrypted_file = self._encrypt_file(backup_file)

            # Update backup info
            backup_info['filepath'] = str(encrypted_file)
            backup_info['filename'] = encrypted_file.name
            backup_info['encrypted'] = True
            backup_info['size_bytes'] = encrypted_file.stat().st_size
            backup_info['checksum'] = self._calculate_checksum(encrypted_file)

            return backup_info

        except Exception as e:
            raise RuntimeError(f"Encryption failed: {e}")

    def _encrypt_file(self, plaintext_file: Path) -> Path:
        """Encrypt a plaintext file and return the encrypted file path."""
        if not self.cipher:
            raise ValueError('No encryption key configured for backup encryption')

        encrypted_file = plaintext_file.with_suffix(plaintext_file.suffix + '.enc')
        try:
            with open(plaintext_file, 'rb') as f_in:
                encrypted_data = self.cipher.encrypt(f_in.read())
            with open(encrypted_file, 'wb') as f_out:
                f_out.write(encrypted_data)
            plaintext_file.unlink()
            return encrypted_file
        except Exception:
            if encrypted_file.exists():
                encrypted_file.unlink()
            raise

    def _create_metadata(self, backup_info: Dict):
        """Create metadata file for backup"""
        metadata_file = Path(backup_info['filepath']).with_suffix('.json')

        with open(metadata_file, 'w') as f:
            json.dump(backup_info, f, indent=2)

        logger.debug(f"Metadata created: {metadata_file}")

    def _calculate_checksum(self, filepath: Path) -> str:
        """Calculate SHA256 checksum of file"""
        sha256 = hashlib.sha256()

        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)

        return sha256.hexdigest()

    def restore_backup(
        self,
        backup_path: str,
        verify_checksum: bool = True,
        create_backup_before_restore: bool = True
    ) -> Dict[str, any]:
        """
        Restore database from backup

        Args:
            backup_path: Path to backup file
            verify_checksum: Verify backup integrity before restore
            create_backup_before_restore: Create safety backup before restore

        Returns:
            Dict with restore details
        """
        backup_file = Path(backup_path)

        if not backup_file.exists():
            raise FileNotFoundError(f"Backup file not found: {backup_path}")

        logger.info(f"Starting restore from: {backup_file.name}")

        try:
            # Load and verify metadata
            metadata_file = backup_file.with_suffix('.json')
            if metadata_file.exists():
                with open(metadata_file) as f:
                    metadata = json.load(f)

                # Verify checksum
                if verify_checksum:
                    current_checksum = self._calculate_checksum(backup_file)
                    if current_checksum != metadata['checksum']:
                        raise ValueError("Checksum mismatch! Backup may be corrupted.")
                    logger.info("Checksum verified ✓")
            else:
                metadata = {'database_type': 'unknown'}
                logger.warning("No metadata file found, proceeding without verification")

            # Create safety backup
            if create_backup_before_restore:
                safety_backup = self.create_backup(
                    backup_type='full',
                    compress=True,
                    encrypt=False,
                    include_metadata=True
                )
                logger.info(f"Safety backup created: {safety_backup['filename']}")

            # Decrypt if needed
            working_file = backup_file
            if backup_file.suffix == '.enc':
                if not self.cipher:
                    raise ValueError("Backup is encrypted but no encryption key configured")
                working_file = self._decrypt_backup(backup_file)

            # Decompress if needed
            if working_file.suffix == '.gz':
                working_file = self._decompress_backup(working_file)

            # Restore based on database type
            if metadata.get('database_type') == 'postgresql' or self.is_postgresql:
                restore_info = self._restore_postgresql(working_file)
            else:
                restore_info = self._restore_sqlite(working_file)

            # Cleanup temporary files
            if working_file != backup_file:
                working_file.unlink()

            logger.info("Restore completed successfully")

            return restore_info

        except Exception as e:
            logger.error(f"Restore failed: {e}", exc_info=True)
            raise

    def _decrypt_backup(self, encrypted_file: Path) -> Path:
        """Decrypt backup file to temporary location"""
        fd, temp_path = tempfile.mkstemp(suffix='.backup')
        os.close(fd)  # Close file descriptor, we'll open with Path
        temp_file = Path(temp_path)

        try:
            with open(encrypted_file, 'rb') as f_in:
                encrypted_data = f_in.read()
                decrypted_data = self.cipher.decrypt(encrypted_data)

                with open(temp_file, 'wb') as f_out:
                    f_out.write(decrypted_data)

            logger.debug(f"Backup decrypted to: {temp_file}")
            return temp_file

        except Exception as e:
            if temp_file.exists():
                temp_file.unlink()
            raise RuntimeError(f"Decryption failed: {e}")

    def _decompress_backup(self, compressed_file: Path) -> Path:
        """Decompress gzipped backup to temporary location"""
        fd, temp_path = tempfile.mkstemp(suffix='.backup')
        os.close(fd)  # Close file descriptor, we'll open with Path
        temp_file = Path(temp_path)

        try:
            with gzip.open(compressed_file, 'rb') as f_in:
                with open(temp_file, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)

            logger.debug(f"Backup decompressed to: {temp_file}")
            return temp_file

        except Exception as e:
            if temp_file.exists():
                temp_file.unlink()
            raise RuntimeError(f"Decompression failed: {e}")

    def _restore_postgresql(self, backup_file: Path) -> Dict:
        """Restore PostgreSQL database using psql"""
        env = os.environ.copy()
        env['PGPASSWORD'] = self.pg_password
        psql_bin = shutil.which('psql') or 'psql'

        cmd = [
            psql_bin,
            '-h', self.pg_host,
            '-p', str(self.pg_port),
            '-U', self.pg_user,
            '-d', self.pg_database,
            '-', str(backup_file),
            '--single-transaction',  # Atomic restore
        ]

        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                check=True
            )  # nosec B603

            return {
                'database_type': 'postgresql',
                'database_name': self.pg_database,
                'restore_timestamp': datetime.utcnow().isoformat(),
                'source_backup': backup_file.name,
                'status': 'success'
            }

        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"PostgreSQL restore failed: {e.stderr.decode()}")
        except FileNotFoundError:
            raise RuntimeError("psql not found. Install PostgreSQL client tools.")

    def _restore_sqlite(self, backup_file: Path) -> Dict:
        """Restore SQLite database by replacing file"""
        try:
            # Close any open connections
            from config import db_engine, SessionLocal
            if SessionLocal:
                SessionLocal.remove()
            if db_engine:
                db_engine.dispose()

            # Backup current database
            current_db = Path(self.sqlite_path)
            if current_db.exists():
                backup_current = current_db.with_suffix('.db.old')
                shutil.copy2(current_db, backup_current)
                logger.debug(f"Current database backed up to: {backup_current}")

            # Replace with restored backup
            shutil.copy2(backup_file, self.sqlite_path)

            # Verify database integrity
            import sqlite3
            conn = sqlite3.connect(self.sqlite_path)
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            conn.close()

            if result[0] != 'ok':
                raise RuntimeError(f"Database integrity check failed: {result}")

            logger.info("Database integrity verified ✓")

            return {
                'database_type': 'sqlite',
                'database_name': current_db.name,
                'restore_timestamp': datetime.utcnow().isoformat(),
                'source_backup': backup_file.name,
                'status': 'success'
            }

        except Exception as e:
            # Attempt rollback if backup exists
            backup_current = Path(self.sqlite_path).with_suffix('.db.old')
            if backup_current.exists():
                shutil.copy2(backup_current, self.sqlite_path)
                logger.warning("Restored previous database after failed restore")
            raise RuntimeError(f"SQLite restore failed: {e}")

    def list_backups(self, limit: int = 50) -> List[Dict]:
        """
        List available backups with metadata

        Args:
            limit: Maximum number of backups to return

        Returns:
            List of backup info dictionaries
        """
        backups = []

        # Find all backup files
        for backup_file in sorted(self.backup_dir.glob('backup_*'), reverse=True)[:limit]:
            # Skip metadata files
            if backup_file.suffix == '.json':
                continue

            # Load metadata if available
            metadata_file = backup_file.with_suffix('.json')
            if metadata_file.exists():
                with open(metadata_file) as f:
                    metadata = json.load(f)
                backups.append(metadata)
            else:
                # Basic info without metadata
                backups.append({
                    'filename': backup_file.name,
                    'filepath': str(backup_file),
                    'size_bytes': backup_file.stat().st_size,
                    'created_at': datetime.fromtimestamp(backup_file.stat().st_mtime).isoformat()
                })

        return backups

    def cleanup_old_backups(self, retention_days: int = 30, keep_count: int = 10):
        """
        Remove old backups based on retention policy

        Args:
            retention_days: Keep backups newer than this many days
            keep_count: Always keep at least this many recent backups
        """
        cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
        backups = self.list_backups(limit=1000)

        # Sort by timestamp
        backups.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

        removed_count = 0
        kept_count = 0

        for backup in backups:
            # Keep minimum number of recent backups
            if kept_count < keep_count:
                kept_count += 1
                continue

            # Check age
            backup_time = datetime.fromisoformat(backup.get('timestamp', '1970-01-01'))
            if backup_time < cutoff_date:
                # Remove backup and metadata
                backup_path = Path(backup['filepath'])
                if backup_path.exists():
                    backup_path.unlink()
                    removed_count += 1

                metadata_path = backup_path.with_suffix('.json')
                if metadata_path.exists():
                    metadata_path.unlink()

                shared_data = backup.get('shared_data_backup', {}) or {}
                shared_archive_path = shared_data.get('archive_filepath')
                if shared_archive_path:
                    shared_archive = Path(shared_archive_path)
                    if shared_archive.exists():
                        shared_archive.unlink()

        logger.info(f"Cleanup complete: removed {removed_count} old backups, kept {kept_count}")
        return {'removed': removed_count, 'kept': kept_count}

    def verify_backup(self, backup_path: str) -> Dict[str, any]:
        """
        Verify backup integrity without restoring

        Args:
            backup_path: Path to backup file

        Returns:
            Dict with verification results
        """
        backup_file = Path(backup_path)

        if not backup_file.exists():
            return {'valid': False, 'error': 'File not found'}

        try:
            # Load metadata
            metadata_file = backup_file.with_suffix('.json')
            if not metadata_file.exists():
                return {'valid': False, 'error': 'No metadata file found'}

            with open(metadata_file) as f:
                metadata = json.load(f)

            # Verify checksum
            current_checksum = self._calculate_checksum(backup_file)
            checksum_valid = current_checksum == metadata['checksum']

            # Check file size
            size_match = backup_file.stat().st_size == metadata['size_bytes']

            shared_data = metadata.get('shared_data_backup', {}) or {}
            shared_data_valid = True
            shared_data_error = None
            if shared_data.get('included'):
                archive_path = Path(shared_data.get('archive_filepath', ''))
                if not archive_path.exists():
                    shared_data_valid = False
                    shared_data_error = 'Shared data archive missing'
                else:
                    expected_checksum = shared_data.get('archive_checksum')
                    expected_size = int(shared_data.get('archive_size_bytes', 0) or 0)
                    if expected_checksum and self._calculate_checksum(archive_path) != expected_checksum:
                        shared_data_valid = False
                        shared_data_error = 'Shared data archive checksum mismatch'
                    elif expected_size and archive_path.stat().st_size != expected_size:
                        shared_data_valid = False
                        shared_data_error = 'Shared data archive size mismatch'

            return {
                'valid': checksum_valid and size_match and shared_data_valid,
                'filename': backup_file.name,
                'checksum_valid': checksum_valid,
                'size_match': size_match,
                'shared_data_valid': shared_data_valid,
                'shared_data_error': shared_data_error,
                'backup_type': metadata.get('backup_type'),
                'database_type': metadata.get('database_type'),
                'timestamp': metadata.get('timestamp')
            }

        except Exception as e:
            return {'valid': False, 'error': str(e)}

    def get_shared_data_backup_status(self) -> Dict[str, any]:
        """Report current shared data backup coverage status."""
        include_shared_data = self._resolve_include_shared_data_policy()
        configured_paths = self._resolve_shared_data_paths()
        existing_paths = [str(path) for path in configured_paths if path.exists()]
        missing_paths = [str(path) for path in configured_paths if not path.exists()]

        return {
            'enabled': include_shared_data,
            'configured_paths': [str(path) for path in configured_paths],
            'existing_paths': existing_paths,
            'missing_paths': missing_paths,
            'fully_covered': (not include_shared_data) or bool(existing_paths),
        }


def main():
    """CLI interface for backup management"""
    import argparse

    parser = argparse.ArgumentParser(description='Database Backup & Restore Manager')
    parser.add_argument('action', choices=['backup', 'restore', 'list', 'cleanup', 'verify'],
                       help='Action to perform')
    parser.add_argument('--backup-file', help='Backup file path (for restore/verify)')
    parser.add_argument('--compress', action='store_true', default=True, help='Compress backup')
    parser.add_argument('--encrypt', action='store_true', help='Encrypt backup')
    parser.add_argument('--retention-days', type=int, default=30, help='Retention period for cleanup')
    parser.add_argument('--keep-count', type=int, default=10, help='Minimum backups to keep')

    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )

    manager = BackupManager()

    try:
        if args.action == 'backup':
            result = manager.create_backup(
                backup_type='full',
                compress=args.compress,
                encrypt=args.encrypt
            )
            print(f"\n✓ Backup created: {result['filename']}")
            print(f"  Size: {result['size_bytes'] / (1024**2):.2f} MB")
            print(f"  Path: {result['filepath']}")

        elif args.action == 'restore':
            if not args.backup_file:
                print("Error: --backup-file required for restore")
                sys.exit(1)

            result = manager.restore_backup(args.backup_file)
            print("\n✓ Restore completed successfully")
            print(f"  Database: {result['database_name']}")

        elif args.action == 'list':
            backups = manager.list_backups()
            print(f"\nFound {len(backups)} backups:\n")
            for backup in backups:
                print(f"  {backup['filename']}")
                print(f"    Size: {backup['size_bytes'] / (1024**2):.2f} MB")
                print(f"    Date: {backup.get('timestamp', 'unknown')}")
                print(f"    Type: {backup.get('database_type', 'unknown')}")
                print()

        elif args.action == 'cleanup':
            result = manager.cleanup_old_backups(
                retention_days=args.retention_days,
                keep_count=args.keep_count
            )
            print("\n✓ Cleanup complete")
            print(f"  Removed: {result['removed']} backups")
            print(f"  Kept: {result['kept']} backups")

        elif args.action == 'verify':
            if not args.backup_file:
                print("Error: --backup-file required for verify")
                sys.exit(1)

            result = manager.verify_backup(args.backup_file)
            if result['valid']:
                print("\n✓ Backup is valid")
                print(f"  File: {result['filename']}")
                print("  Checksum: ✓")
                print("  Size: ✓")
            else:
                print("\n✗ Backup is invalid")
                print(f"  Error: {result.get('error', 'Unknown error')}")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Operation failed: {e}", exc_info=True)
        print(f"\n✗ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
