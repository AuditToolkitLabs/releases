#!/usr/bin/env python3
"""
Celery Application Configuration

Configures Celery for distributed task queue:
- Redis as message broker
- PostgreSQL/SQLite as result backend
- Task routing and serialization
- Retry policies and timeouts

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import logging
from pathlib import Path
from celery import Celery
from celery.signals import setup_logging
from celery import _state

from database_defaults import get_runtime_default_database_url, normalize_database_url

logger = logging.getLogger(__name__)

IS_WINDOWS = os.name == 'nt'

# Get configuration from environment
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/1')
_data_root_env = os.getenv('AUDIT_TOOLKIT_DATA_DIR', '').strip()
if _data_root_env:
    _data_root = Path(_data_root_env).expanduser().resolve()
else:
    _data_root = Path(__file__).parent.parent.resolve()
DATABASE_URL = normalize_database_url(
    os.getenv('DATABASE_URL', get_runtime_default_database_url(data_root=_data_root)),
    data_root=_data_root
)

# Convert database URL for Celery result backend
# Celery uses 'db+' prefix for SQLAlchemy URLs
if DATABASE_URL.startswith('postgresql'):
    CELERY_RESULT_BACKEND = DATABASE_URL.replace('postgresql://', 'db+postgresql://')
elif DATABASE_URL.startswith('sqlite'):
    CELERY_RESULT_BACKEND = DATABASE_URL.replace('sqlite:///', 'db+sqlite:///')
else:
    CELERY_RESULT_BACKEND = f'db+{DATABASE_URL}'

# Create Celery app
celery_app = Celery(
    'audit_toolkit',
    broker=REDIS_URL,
    backend=CELERY_RESULT_BACKEND,
    include=['tasks.audit_tasks', 'tasks.scheduled_tasks', 'tasks.report_tasks', 'tasks.parallel_executor', 'tasks.evidence_tasks']
)

# Celery Configuration
celery_app.conf.update(
    # Task execution settings
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,

    # Result backend settings
    result_backend=CELERY_RESULT_BACKEND,
    result_expires=86400,  # Results expire after 24 hours
    result_extended=True,  # Store additional task metadata

    # Task routing
    task_routes={
        'tasks.audit_tasks.execute_audit': {'queue': 'audits'},
        'tasks.audit_tasks.execute_audit_plan': {'queue': 'audits'},
        'tasks.scheduled_tasks.run_scheduled_audit': {'queue': 'scheduled'},
    },

    # Worker settings
    worker_pool='solo' if IS_WINDOWS else 'prefork',
    worker_prefetch_multiplier=1,  # Take one task at a time (for long-running audits)
    worker_max_tasks_per_child=100,  # Restart worker after 100 tasks (prevent memory leaks)
    worker_disable_rate_limits=False,

    # Task time limits
    task_soft_time_limit=3600,  # Soft limit: 1 hour (raises SoftTimeLimitExceeded)
    task_time_limit=3900,  # Hard limit: 65 minutes (kills task)
    task_acks_late=True,  # Acknowledge task after completion (not before)
    task_reject_on_worker_lost=True,  # Requeue if worker crashes

    # Retry settings (default for all tasks)
    task_default_retry_delay=60,  # Retry after 60 seconds
    task_max_retries=3,  # Maximum 3 retries

    # Beat schedule (for Celery Beat - periodic tasks)
    beat_schedule={
        # Health check all servers every 5 minutes
        'health-check-servers': {
            'task': 'tasks.scheduled_tasks.health_check_all_servers',
            'schedule': 300.0,  # Every 5 minutes
        },
        # Check for scheduled audits every minute
        'run-scheduled-audits': {
            'task': 'tasks.scheduled_tasks.run_scheduled_audits',
            'schedule': 60.0,  # Every 60 seconds
        },
        # Cleanup old execution records (policy-controlled interval)
        'cleanup-old-executions': {
            'task': 'tasks.scheduled_tasks.cleanup_old_executions',
            'schedule': 300.0,  # Poll every 5 minutes; task enforces configured interval
        },
        # Cleanup analytics history tables (policy-controlled interval)
        'cleanup-analytics-history': {
            'task': 'tasks.scheduled_tasks.cleanup_analytics_history',
            'schedule': 300.0,  # Poll every 5 minutes; task enforces configured interval
        },
        # PostgreSQL maintenance and size alert checks (policy-controlled interval)
        'postgresql-maintenance': {
            'task': 'tasks.scheduled_tasks.run_postgresql_maintenance',
            'schedule': 300.0,  # Poll every 5 minutes; task enforces configured interval
        },
        # Update audit metadata cache daily at 3 AM
        'update-audit-metadata': {
            'task': 'tasks.scheduled_tasks.update_audit_metadata',
            'schedule': 86400.0,  # Daily (24 hours)
        },
        # Check for scheduled PDF reports every minute
        'run-scheduled-reports': {
            'task': 'tasks.report_tasks.run_scheduled_reports',
            'schedule': 60.0,  # Every 60 seconds
        },
        # Check for maintenance window start/end events every 5 minutes
        'check-maintenance-window-events': {
            'task': 'tasks.scheduled_tasks.check_maintenance_window_events',
            'schedule': 300.0,  # Every 5 minutes
        },
        # Enforce evidence export retention policy daily
        'evidence-retention-cleanup': {
            'task': 'tasks.evidence_tasks.run_evidence_retention_cleanup',
            'schedule': 86400.0,  # Every 24 hours
        },
    },

    # Monitoring
    task_send_sent_event=True,  # Send task-sent events (for Flower monitoring)
    task_track_started=True,  # Track when tasks start (not just when they finish)
    worker_send_task_events=True,  # Send task events to monitor
)


@setup_logging.connect
def configure_celery_logging(loglevel=None, **kwargs):
    """Configure Celery logging to use application logger"""
    if loglevel:
        logger.setLevel(loglevel)


def get_celery_app():
    """Get configured Celery application instance"""
    return celery_app


class _CeleryCompatProxy:
    """Compatibility wrapper that allows patching attributes like backend in tests."""

    def __init__(self, app: Celery):
        self._app = app
        self.backend = app.backend

    def __getattr__(self, item):
        return getattr(self._app, item)


# Backward-compatible alias for older imports and test patching
celery = _CeleryCompatProxy(celery_app)

# Ensure current_task proxy resolves to an object in non-worker test contexts
try:
    if _state.get_current_task() is None:
        _state._set_current_task(celery_app.Task())
except Exception as current_task_error:
    logger.debug(f"Unable to initialize Celery current_task proxy for compatibility: {current_task_error}")


# Task decorators for common patterns
def audit_task(**kwargs):
    """
    Decorator for audit execution tasks

    Provides default settings:
    - Bind to task instance (self)
    - Auto-retry on failure
    - Store result in database
    - Track progress
    """
    defaults = {
        'bind': True,
        'autoretry_for': (Exception,),
        'retry_kwargs': {'max_retries': 3, 'countdown': 60},
        'retry_backoff': True,
        'retry_jitter': True,
        'track_started': True,
    }
    defaults.update(kwargs)
    return celery_app.task(**defaults)


# Export
__all__ = [
    'celery_app',
    'celery',
    'get_celery_app',
    'audit_task',
    'REDIS_URL',
    'CELERY_RESULT_BACKEND',
]


if __name__ == '__main__':
    # Log configuration for debugging
    import logging
    logger = logging.getLogger(__name__)

    logger.info("="*70)
    logger.info("  Celery Configuration")
    logger.info("="*70)
    logger.info(f"Broker: {REDIS_URL}")
    logger.info(f"Result Backend: {CELERY_RESULT_BACKEND}")
    logger.info(f"Worker Pool: {'solo' if IS_WINDOWS else 'prefork'}")
    logger.info("Task Serializer: json")
    logger.info("Result Expires: 24 hours")
    logger.info("Soft Time Limit: 3600 seconds (1 hour)")
    logger.info("Hard Time Limit: 3900 seconds (65 minutes)")
    logger.info("Max Retries: 3")
    logger.info("Task Queues: audits, scheduled")
    logger.info("="*70)
