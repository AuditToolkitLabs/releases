#!/usr/bin/env python3
"""
Circuit Breaker Pattern Implementation

Prevents cascading failures by:
- Detecting consecutive failures
- Opening circuit when threshold reached
- Allowing periodic retry attempts
- Auto-recovery when service healthy

States:
- CLOSED: Normal operation
- OPEN: Failing, reject requests
- HALF_OPEN: Testing recovery

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import time
import logging
from datetime import datetime, timedelta
from typing import Callable, Any, Optional
from enum import Enum
from threading import Lock

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states"""
    CLOSED = "closed"       # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing recovery


class CircuitBreakerError(Exception):
    """Raised when circuit breaker is open"""
    def __init__(self, service_name: str, reset_time: datetime):
        self.service_name = service_name
        self.reset_time = reset_time
        super().__init__(
            f"Circuit breaker OPEN for {service_name}. "
            f"Will retry at {reset_time.isoformat()}"
        )


class CircuitBreaker:
    """
    Circuit Breaker Implementation

    Protects against cascading failures by:
    1. Tracking consecutive failures
    2. Opening circuit when failures exceed threshold
    3. Allowing periodic retries in HALF_OPEN state
    4. Auto-closing when success detected

    Example:
        breaker = CircuitBreaker("ssh_server", failure_threshold=5, timeout=60)

        try:
            result = breaker.call(ssh_manager.execute_ssh, server, command)
        except CircuitBreakerError as e:
            logger.error(f"Circuit open: {e}")
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type = Exception,
        half_open_max_attempts: int = 1
    ):
        """
        Initialize circuit breaker

        Args:
            name: Service name (for logging/monitoring)
            failure_threshold: Number of failures before opening circuit
            recovery_timeout: Seconds to wait before attempting recovery
            expected_exception: Exception type to catch (default: all)
            half_open_max_attempts: Max attempts in HALF_OPEN state
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.half_open_max_attempts = half_open_max_attempts

        # State tracking
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: Optional[datetime] = None
        self._last_success_time: Optional[datetime] = None
        self._half_open_attempts = 0

        # Thread safety
        self._lock = Lock()

        logger.info(
            f"Circuit breaker initialized: {name} "
            f"(threshold={failure_threshold}, timeout={recovery_timeout}s)"
        )

    @property
    def state(self) -> CircuitState:
        """Get current circuit state (thread-safe)"""
        with self._lock:
            return self._state

    @property
    def failure_count(self) -> int:
        """Get current failure count (thread-safe)"""
        with self._lock:
            return self._failure_count

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute function through circuit breaker

        Args:
            func: Function to call
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Function result

        Raises:
            CircuitBreakerError: If circuit is open
            Exception: Original exception if circuit allows execution
        """
        with self._lock:
            # Check if we should attempt execution
            if not self._can_execute():
                reset_time = self._last_failure_time + timedelta(seconds=self.recovery_timeout)
                raise CircuitBreakerError(self.name, reset_time)

        # Execute function
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result

        except self.expected_exception as e:
            self._on_failure(e)
            raise

    def _can_execute(self) -> bool:
        """Determine if execution should be attempted"""
        if self._state == CircuitState.CLOSED:
            return True

        if self._state == CircuitState.OPEN:
            # Check if recovery timeout elapsed
            if self._last_failure_time:
                time_since_failure = datetime.utcnow() - self._last_failure_time
                if time_since_failure.total_seconds() >= self.recovery_timeout:
                    # Transition to HALF_OPEN for testing
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_attempts = 0
                    logger.info(f"Circuit breaker {self.name}: OPEN -> HALF_OPEN (testing recovery)")
                    return True
            return False

        if self._state == CircuitState.HALF_OPEN:
            # Allow limited attempts in HALF_OPEN state
            if self._half_open_attempts < self.half_open_max_attempts:
                self._half_open_attempts += 1
                return True
            return False

        return False

    def _on_success(self):
        """Handle successful execution"""
        with self._lock:
            self._last_success_time = datetime.utcnow()

            if self._state == CircuitState.HALF_OPEN:
                # Success in HALF_OPEN -> transition to CLOSED
                self._state = CircuitState.CLOSED
                self._failure_count = 0
                self._half_open_attempts = 0
                logger.info(
                    f"Circuit breaker {self.name}: HALF_OPEN -> CLOSED (recovered)"
                )

            elif self._state == CircuitState.CLOSED:
                # Reset failure count on success
                if self._failure_count > 0:
                    logger.info(
                        f"Circuit breaker {self.name}: Reset failure count "
                        f"({self._failure_count} -> 0)"
                    )
                self._failure_count = 0

    def _on_failure(self, exception: Exception):
        """Handle failed execution"""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = datetime.utcnow()

            logger.warning(
                f"Circuit breaker {self.name}: Failure {self._failure_count}/{self.failure_threshold} "
                f"({exception.__class__.__name__}: {str(exception)[:100]})"
            )

            if self._state == CircuitState.HALF_OPEN:
                # Failure in HALF_OPEN -> back to OPEN
                self._state = CircuitState.OPEN
                logger.warning(
                    f"Circuit breaker {self.name}: HALF_OPEN -> OPEN (recovery failed)"
                )

            elif self._state == CircuitState.CLOSED:
                # Check if we should open circuit
                if self._failure_count >= self.failure_threshold:
                    self._state = CircuitState.OPEN
                    logger.error(
                        f"Circuit breaker {self.name}: CLOSED -> OPEN "
                        f"(threshold {self.failure_threshold} reached). "
                        f"Will retry in {self.recovery_timeout}s"
                    )

    def reset(self):
        """Manually reset circuit breaker to CLOSED state"""
        with self._lock:
            old_state = self._state
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._half_open_attempts = 0
            logger.info(f"Circuit breaker {self.name}: Manual reset ({old_state} -> CLOSED)")

    def get_stats(self) -> dict:
        """
        Get circuit breaker statistics

        Returns:
            dict: Current state and metrics
        """
        with self._lock:
            return {
                'name': self.name,
                'state': self._state.value,
                'failure_count': self._failure_count,
                'failure_threshold': self.failure_threshold,
                'recovery_timeout': self.recovery_timeout,
                'last_failure_time': self._last_failure_time.isoformat() if self._last_failure_time else None,
                'last_success_time': self._last_success_time.isoformat() if self._last_success_time else None,
                'half_open_attempts': self._half_open_attempts
            }


class CircuitBreakerRegistry:
    """
    Global registry for circuit breakers

    Manages circuit breakers per service/host to prevent cascading failures.
    One circuit breaker per unique service identifier.
    """

    def __init__(self):
        self._breakers: dict[str, CircuitBreaker] = {}
        self._lock = Lock()

    def get_breaker(
        self,
        service_id: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type = Exception
    ) -> CircuitBreaker:
        """
        Get or create circuit breaker for service

        Args:
            service_id: Unique service identifier (e.g., "ssh:192.168.1.10")
            failure_threshold: Failures before opening circuit
            recovery_timeout: Seconds before retry
            expected_exception: Exception type to catch

        Returns:
            CircuitBreaker instance
        """
        with self._lock:
            if service_id not in self._breakers:
                self._breakers[service_id] = CircuitBreaker(
                    name=service_id,
                    failure_threshold=failure_threshold,
                    recovery_timeout=recovery_timeout,
                    expected_exception=expected_exception
                )
            return self._breakers[service_id]

    def reset_breaker(self, service_id: str):
        """Reset specific circuit breaker"""
        with self._lock:
            if service_id in self._breakers:
                self._breakers[service_id].reset()

    def reset_all(self):
        """Reset all circuit breakers"""
        with self._lock:
            for breaker in self._breakers.values():
                breaker.reset()
            logger.info("All circuit breakers reset")

    def get_all_stats(self) -> list[dict]:
        """Get statistics for all circuit breakers"""
        with self._lock:
            return [breaker.get_stats() for breaker in self._breakers.values()]

    def get_open_circuits(self) -> list[str]:
        """Get list of open circuit breaker names"""
        with self._lock:
            return [
                name for name, breaker in self._breakers.items()
                if breaker.state == CircuitState.OPEN
            ]


# Global registry instance
_circuit_breaker_registry = CircuitBreakerRegistry()


def get_circuit_breaker_registry() -> CircuitBreakerRegistry:
    """Get global circuit breaker registry"""
    return _circuit_breaker_registry
