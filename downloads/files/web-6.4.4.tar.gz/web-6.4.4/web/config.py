#!/usr/bin/env python3
"""
Configuration Module for Security Audit Toolkit Web Interface

Handles all application configuration including:
- Flask app initialization
- Redis configuration
- Rate limiting setup
- Directory paths
- Logging configuration
"""

import os
import json
import logging
import secrets
import time
from urllib.parse import urlparse
from pathlib import Path
from flask import Flask, request
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from logging_config import setup_logging
from security_startup_checks import enforce_server_password_storage_format
from database_defaults import get_runtime_default_database_url, normalize_database_url

try:
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    LIMITER_AVAILABLE = True
except ImportError:
    LIMITER_AVAILABLE = False
    print("WARNING: flask-limiter not installed. Install with: pip install flask-limiter")

try:
    import redis
    from redis.exceptions import RedisError
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    print("INFO: redis library not installed. Rate limiting will use in-memory storage.")
    print("      For multi-instance deployments, install with: pip install redis")

# Redis enable flag from environment
REDIS_ENABLED = os.environ.get('REDIS_ENABLED', 'false').lower() == 'true'

# ============================================================================
# HTTPS Enforcement Configuration
# ============================================================================
# Force HTTPS via environment variable (overrides admin settings)
# Set to 'true' to enforce HTTPS at application startup
# This is separate from the admin panel setting which can be toggled at runtime
FORCE_HTTPS = os.environ.get('FORCE_HTTPS', 'false').lower() == 'true'

# ============================================================================
# Remote Terminal Feature Configuration
# ============================================================================
# Master switch - set to 'false' to completely disable terminal feature
TERMINAL_ENABLED = os.environ.get('TERMINAL_ENABLED', 'false').lower() == 'true'

# IP Allowlist - comma-separated list of allowed IPs/CIDR ranges (empty = all allowed)
# Example: "192.168.1.0/24,10.0.0.0/8,172.16.0.0/12"
TERMINAL_ALLOWED_IPS = os.environ.get('TERMINAL_ALLOWED_IPS', '').strip()

# Command blacklist - dangerous commands that will be blocked
TERMINAL_COMMAND_BLACKLIST = os.environ.get('TERMINAL_COMMAND_BLACKLIST',
    'rm -rf /,mkfs,dd if=,format c:,del /s /q,shutdown,reboot,init 0,init 6,halt,poweroff'
).split(',')

# Maximum concurrent terminal sessions per user
TERMINAL_MAX_SESSIONS_PER_USER = int(os.environ.get('TERMINAL_MAX_SESSIONS', '3'))

# Session timeout in seconds (default 30 minutes)
TERMINAL_SESSION_TIMEOUT = int(os.environ.get('TERMINAL_SESSION_TIMEOUT', '1800'))

# Token validity in seconds (default 1 hour)
TERMINAL_TOKEN_VALIDITY = int(os.environ.get('TERMINAL_TOKEN_VALIDITY', '3600'))

# Rate limiting for terminal authentication (max attempts per minute)
TERMINAL_AUTH_RATE_LIMIT = int(os.environ.get('TERMINAL_AUTH_RATE_LIMIT', '5'))

# Require approval from another admin before terminal access (future feature)
TERMINAL_REQUIRE_APPROVAL = os.environ.get('TERMINAL_REQUIRE_APPROVAL', 'false').lower() == 'true'

# Time-based access control (empty = 24/7 access)
# Format: "09:00-18:00" for 9 AM to 6 PM
TERMINAL_ACCESS_HOURS = os.environ.get('TERMINAL_ACCESS_HOURS', '').strip()

# Allowed days for terminal access (empty = all days)
# Format: "Mon,Tue,Wed,Thu,Fri" (case-insensitive)
TERMINAL_ACCESS_DAYS = os.environ.get('TERMINAL_ACCESS_DAYS', '').strip()

# Timezone for time-based access (default: UTC)
TERMINAL_ACCESS_TIMEZONE = os.environ.get('TERMINAL_ACCESS_TIMEZONE', 'UTC').strip()

# Session recording enabled (stores terminal I/O for playback)
TERMINAL_RECORDING_ENABLED = os.environ.get('TERMINAL_RECORDING_ENABLED', 'true').lower() == 'true'

# Maximum recording storage in MB per session (0 = unlimited)
TERMINAL_RECORDING_MAX_SIZE_MB = int(os.environ.get('TERMINAL_RECORDING_MAX_SIZE_MB', '50'))

# Recording retention days (older recordings auto-deleted)
TERMINAL_RECORDING_RETENTION_DAYS = int(os.environ.get('TERMINAL_RECORDING_RETENTION_DAYS', '90'))

# ============================================================================
# LDAP / Active Directory Authentication Configuration
# ============================================================================
# Master switch - set to 'true' to enable LDAP authentication
LDAP_ENABLED = os.environ.get('LDAP_ENABLED', 'false').lower() == 'true'

# LDAP Server Configuration
# For Active Directory: ldap://your-dc.domain.com:389 or ldaps://your-dc.domain.com:636
LDAP_SERVER = os.environ.get('LDAP_SERVER', 'ldap://localhost:389')

# Use SSL/TLS (ldaps://)
LDAP_USE_SSL = os.environ.get('LDAP_USE_SSL', 'false').lower() == 'true'

# Start TLS on non-SSL connection (recommended for production)
LDAP_START_TLS = os.environ.get('LDAP_START_TLS', 'false').lower() == 'true'

# Base DN for user searches (e.g., "dc=company,dc=com" or "ou=users,dc=company,dc=com")
LDAP_BASE_DN = os.environ.get('LDAP_BASE_DN', 'dc=example,dc=com')

# Bind DN - service account for LDAP queries (leave empty for anonymous bind)
# For AD: "cn=ServiceAccount,cn=Users,dc=company,dc=com" or "svc@company.com"
LDAP_BIND_DN = os.environ.get('LDAP_BIND_DN', '')

# Bind Password - service account password
LDAP_BIND_PASSWORD = os.environ.get('LDAP_BIND_PASSWORD', '')

# User search filter - {username} will be replaced with actual username
# For AD: "(sAMAccountName={username})" or "(userPrincipalName={username}@domain.com)"
# For OpenLDAP: "(uid={username})"
LDAP_USER_SEARCH_FILTER = os.environ.get('LDAP_USER_SEARCH_FILTER', '(uid={username})')

# User search attribute for binding after search (usually 'dn')
LDAP_USER_RDN_ATTR = os.environ.get('LDAP_USER_RDN_ATTR', 'uid')

# User ID attribute in LDAP (for storing external_id)
LDAP_USER_ID_ATTR = os.environ.get('LDAP_USER_ID_ATTR', 'uid')

# Additional attributes to fetch from LDAP
LDAP_USER_EMAIL_ATTR = os.environ.get('LDAP_USER_EMAIL_ATTR', 'mail')
LDAP_USER_DISPLAY_NAME_ATTR = os.environ.get('LDAP_USER_DISPLAY_NAME_ATTR', 'displayName')

# Group membership configuration (for RBAC mapping)
LDAP_GROUP_DN = os.environ.get('LDAP_GROUP_DN', 'ou=groups,dc=example,dc=com')
LDAP_GROUP_SEARCH_FILTER = os.environ.get('LDAP_GROUP_SEARCH_FILTER', '(objectClass=groupOfNames)')
LDAP_GROUP_MEMBER_ATTR = os.environ.get('LDAP_GROUP_MEMBER_ATTR', 'member')

# Role mapping: LDAP group CN -> Application role
# Format: JSON object {"LDAPGroupName": "AppRole", ...}
# Example: {"SecurityAdmins": "Admin", "SecurityAuditors": "Analyst", "SecurityViewers": "Viewer"}
LDAP_ROLE_MAPPING_JSON = os.environ.get('LDAP_ROLE_MAPPING', '{}')

# Default role for LDAP users not in any mapped group
LDAP_DEFAULT_ROLE = os.environ.get('LDAP_DEFAULT_ROLE', 'Viewer')

# Connection timeout in seconds
LDAP_CONNECT_TIMEOUT = int(os.environ.get('LDAP_CONNECT_TIMEOUT', '10'))

# Allow local auth fallback when LDAP is enabled (for emergency access)
LDAP_ALLOW_LOCAL_FALLBACK = os.environ.get('LDAP_ALLOW_LOCAL_FALLBACK', 'true').lower() == 'true'

# Auto-create local user on first LDAP login
LDAP_AUTO_CREATE_USER = os.environ.get('LDAP_AUTO_CREATE_USER', 'true').lower() == 'true'

# Sync user attributes from LDAP on each login
LDAP_SYNC_ON_LOGIN = os.environ.get('LDAP_SYNC_ON_LOGIN', 'true').lower() == 'true'


def get_ldap_role_mapping():
    """
    Parse LDAP role mapping from JSON environment variable.

    Returns:
        dict: Mapping of LDAP group names to application roles
    """
    try:
        mapping = json.loads(LDAP_ROLE_MAPPING_JSON)
        if isinstance(mapping, dict):
            return mapping
    except json.JSONDecodeError:
        pass
    return {}


def get_ldap_config():
    """
    Get complete LDAP configuration as a dictionary.

    Returns:
        dict: All LDAP configuration values
    """
    return {
        'enabled': LDAP_ENABLED,
        'server': LDAP_SERVER,
        'use_ssl': LDAP_USE_SSL,
        'start_tls': LDAP_START_TLS,
        'base_dn': LDAP_BASE_DN,
        'bind_dn': LDAP_BIND_DN,
        'bind_password': LDAP_BIND_PASSWORD,
        'user_search_filter': LDAP_USER_SEARCH_FILTER,
        'user_rdn_attr': LDAP_USER_RDN_ATTR,
        'user_id_attr': LDAP_USER_ID_ATTR,
        'user_email_attr': LDAP_USER_EMAIL_ATTR,
        'user_display_name_attr': LDAP_USER_DISPLAY_NAME_ATTR,
        'group_dn': LDAP_GROUP_DN,
        'group_search_filter': LDAP_GROUP_SEARCH_FILTER,
        'group_member_attr': LDAP_GROUP_MEMBER_ATTR,
        'role_mapping': get_ldap_role_mapping(),
        'default_role': LDAP_DEFAULT_ROLE,
        'connect_timeout': LDAP_CONNECT_TIMEOUT,
        'allow_local_fallback': LDAP_ALLOW_LOCAL_FALLBACK,
        'auto_create_user': LDAP_AUTO_CREATE_USER,
        'sync_on_login': LDAP_SYNC_ON_LOGIN,
    }


# ============================================================================
# Storage Backend Configuration (NFS/SMB/S3)
# ============================================================================
# Storage backend type: "local" | "s3"
# Note: NFS/SMB mounts work with "local" backend - just set STORAGE_PATH to mount point
STORAGE_BACKEND = os.environ.get('STORAGE_BACKEND', 'local').lower()

# Base path for local/NFS/SMB storage (default: <app_root>/storage-data)
STORAGE_PATH = os.environ.get('STORAGE_PATH', '')

# Enable gzip compression for stored data (reduces storage but increases CPU)
STORAGE_COMPRESSION = os.environ.get('STORAGE_COMPRESSION', 'false').lower() == 'true'

# Client-side encryption key (Base64-encoded 32-byte AES-256 key)
# Generate with: python -c "import secrets,base64; print(base64.b64encode(secrets.token_bytes(32)).decode())"
STORAGE_ENCRYPTION_KEY = os.environ.get('STORAGE_ENCRYPTION_KEY', '')

# S3/S3-Compatible Storage Configuration
# Endpoint URL (leave empty for AWS S3, set for MinIO/Ceph/etc.)
# Examples:
#   AWS S3: (leave empty or set to https://s3.amazonaws.com)
#   MinIO:  http://minio-server:9000
#   Ceph:   http://ceph-gateway:7480
S3_ENDPOINT_URL = os.environ.get('S3_ENDPOINT_URL', '')

# S3 credentials (can also use IAM roles if running on AWS)
S3_ACCESS_KEY = os.environ.get('S3_ACCESS_KEY', '')
S3_SECRET_KEY = os.environ.get('S3_SECRET_KEY', '')

# S3 bucket name (required for S3 backend)
S3_BUCKET = os.environ.get('S3_BUCKET', '')

# AWS region (default: us-east-1)
S3_REGION = os.environ.get('S3_REGION', 'us-east-1')

# Enable SSL for S3 connections
S3_USE_SSL = os.environ.get('S3_USE_SSL', 'true').lower() == 'true'

# Use path-style URLs (required for MinIO and some S3-compatible services)
S3_PATH_STYLE = os.environ.get('S3_PATH_STYLE', 'false').lower() == 'true'

# Optional prefix for all S3 objects (e.g., "audit-tool/" to namespace within bucket)
S3_PREFIX = os.environ.get('S3_PREFIX', '')


def get_storage_config():
    """
    Get complete storage configuration as a dictionary.

    Returns:
        dict: All storage configuration values
    """
    return {
        'backend': STORAGE_BACKEND,
        'path': STORAGE_PATH,
        'compression': STORAGE_COMPRESSION,
        'encryption_enabled': bool(STORAGE_ENCRYPTION_KEY),
        's3': {
            'endpoint_url': S3_ENDPOINT_URL,
            'bucket': S3_BUCKET,
            'region': S3_REGION,
            'use_ssl': S3_USE_SSL,
            'path_style': S3_PATH_STYLE,
            'prefix': S3_PREFIX,
            'credentials_configured': bool(S3_ACCESS_KEY and S3_SECRET_KEY),
        }
    }


try:
    from sqlalchemy import create_engine, event, text
    from sqlalchemy.orm import sessionmaker, scoped_session
    from sqlalchemy.pool import NullPool, QueuePool
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False
    print("WARNING: SQLAlchemy not installed. Database features unavailable.")
    print("         Install with: pip install sqlalchemy psycopg2-binary")

# Get repository root (read-only application files)
ROOT_DIR = Path(__file__).parent.parent.resolve()

# Writable runtime/data root (logs, history, schedules, SQLite DB, etc.)
# Defaults to ROOT_DIR for backward compatibility.
_data_root_env = os.environ.get('AUDIT_TOOLKIT_DATA_DIR', '').strip()
if _data_root_env:
    DATA_ROOT = Path(_data_root_env).expanduser().resolve()
else:
    DATA_ROOT = ROOT_DIR

# Directory paths
ORCHESTRATOR_PATH = ROOT_DIR / "orchestrator" / "orchestrator.sh"
DISCOVERY_PATH = ROOT_DIR / "orchestrator" / "discovery.sh"
AUDITS_DIR = ROOT_DIR / "audits"
LOGS_DIR = ROOT_DIR / "logs"
PLANS_DIR = ROOT_DIR / "plans"
SERVERS_DIR = ROOT_DIR / "servers"
SSH_DIR = ROOT_DIR / ".ssh"
HISTORY_DIR = ROOT_DIR / "history"
SCHEDULES_DIR = ROOT_DIR / "schedules"
SETTINGS_DIR = ROOT_DIR / "settings"

# Route writable paths to DATA_ROOT so installations under protected directories
# (e.g., Program Files on Windows) remain operational without manual ACL changes.
LOGS_DIR = DATA_ROOT / "logs"
PLANS_DIR = DATA_ROOT / "plans"
SERVERS_DIR = DATA_ROOT / "servers"
SSH_DIR = DATA_ROOT / ".ssh"
HISTORY_DIR = DATA_ROOT / "history"
SCHEDULES_DIR = DATA_ROOT / "schedules"
SETTINGS_DIR = DATA_ROOT / "settings"

# Ensure directories exist with secure permissions
def initialize_directories():
    """Create necessary directories with proper permissions"""
    from platform_utils import safe_chmod, is_windows

    LOGS_DIR.mkdir(exist_ok=True)
    PLANS_DIR.mkdir(exist_ok=True)
    SERVERS_DIR.mkdir(exist_ok=True)
    HISTORY_DIR.mkdir(exist_ok=True)
    SCHEDULES_DIR.mkdir(exist_ok=True)
    SETTINGS_DIR.mkdir(exist_ok=True)

    # SSH directory with restrictive permissions (Unix only)
    if is_windows():
        SSH_DIR.mkdir(exist_ok=True)
    else:
        SSH_DIR.mkdir(exist_ok=True, mode=0o700)

# Initialize logging (imported and configured from logging_config module)
logger = logging.getLogger(__name__)

# Parallel SSH execution configuration
MAX_CONCURRENT_SSH = int(os.getenv('MAX_CONCURRENT_SSH', 50))
MAX_CONNECTIONS_PER_HOST = int(os.getenv('MAX_CONNECTIONS_PER_HOST', 5))
SSH_COMMAND_TIMEOUT = int(os.getenv('SSH_COMMAND_TIMEOUT', 600))
SSH_RETRY_COUNT = int(os.getenv('SSH_RETRY_COUNT', 2))


def _is_production_env() -> bool:
    flask_env = os.environ.get('FLASK_ENV', '').strip().lower()
    runtime_env = os.environ.get('ENVIRONMENT', '').strip().lower()
    return flask_env == 'production' or runtime_env == 'production'


def _production_hardening_required(is_production: bool) -> bool:
    if not is_production:
        return False
    required = os.environ.get('PRODUCTION_HARDENING_REQUIRED', 'true')
    return required.strip().lower() == 'true'


def create_app():
    """Create and configure Flask application"""
    app = Flask(__name__, static_folder='static', template_folder='templates')

    is_production = _is_production_env()
    hardening_required = _production_hardening_required(is_production)

    # Security: Generate secret key for session management and CSRF protection
    secret_key = os.environ.get('FLASK_SECRET_KEY')
    if not secret_key:
        if hardening_required:
            raise RuntimeError(
                "FLASK_SECRET_KEY must be set when PRODUCTION_HARDENING_REQUIRED is enabled"
            )
        secret_key = secrets.token_hex(32)
    app.config['SECRET_KEY'] = secret_key
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    session_cookie_secure = is_production or os.environ.get('SESSION_COOKIE_SECURE', '').lower() in (
        'true', '1', 'yes'
    )
    app.config['SESSION_COOKIE_SECURE'] = session_cookie_secure
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

    # Security warning for non-production environments
    if not app.config['SESSION_COOKIE_SECURE']:
        logger.warning("SECURITY WARNING: Session cookies are NOT secure (HTTPS required in production)")
        logger.warning("Set FLASK_ENV=production (or ENVIRONMENT=production) and use HTTPS for secure deployments")

    if hardening_required:
        if not app.config['SESSION_COOKIE_SECURE']:
            raise RuntimeError(
                "SESSION_COOKIE_SECURE must be enabled when PRODUCTION_HARDENING_REQUIRED is enabled"
            )
        db_key = os.environ.get('DB_FIELD_ENCRYPTION_KEY') or os.environ.get('ENCRYPTION_KEY')
        if not db_key:
            raise RuntimeError(
                "DB_FIELD_ENCRYPTION_KEY must be set when PRODUCTION_HARDENING_REQUIRED is enabled"
            )

    # Security: Restrict CORS to specific origins
    allowed_origins = os.environ.get('ALLOWED_ORIGINS', 'http://localhost:5000').split(',')
    CORS(app, origins=allowed_origins, supports_credentials=True)

    # Security: Add Content-Security-Policy and other security headers
    @app.after_request
    def add_security_headers(response):
        """Add security headers to all responses"""
        # Content-Security-Policy - relaxed policy to allow dynamic styles
        # Note: 'unsafe-inline' needed for JS-generated styles (modals, dynamic UI)
        # Dev mode: Allow embedding in VS Code Simple Browser and other dev tools
        is_dev_mode = os.environ.get('FLASK_ENV') != 'production' and os.environ.get('FLASK_DEBUG', '0') == '1'

        # Use browser-facing discovery URL for CSP directives. Internal service URLs
        # (e.g., 127.0.0.1:18080) break remote browser access when emitted in CSP.
        asset_discovery_external_url = os.environ.get('ASSET_DISCOVERY_EXTERNAL_URL', '/discovery/').strip()
        asset_discovery_csp_source = "'self'"
        if asset_discovery_external_url:
            parsed_discovery = urlparse(asset_discovery_external_url)
            if parsed_discovery.scheme and parsed_discovery.netloc:
                discovery_host = (parsed_discovery.hostname or '').lower()
                if discovery_host in {'localhost', '127.0.0.1', '::1'}:
                    request_host = request.host.split(':', 1)[0]
                    discovery_scheme = parsed_discovery.scheme or request.scheme
                    if parsed_discovery.port:
                        asset_discovery_csp_source = f"{discovery_scheme}://{request_host}:{parsed_discovery.port}"
                else:
                    asset_discovery_csp_source = f"{parsed_discovery.scheme}://{parsed_discovery.netloc}"

        csp_directives = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com",
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com",
            "img-src 'self' data: https:",
            "font-src 'self' https://cdn.jsdelivr.net https://fonts.gstatic.com data:",
            "worker-src 'self' blob:",
            "connect-src 'self'" if asset_discovery_csp_source == "'self'" else f"connect-src 'self' {asset_discovery_csp_source}",
            "frame-src 'self'" if asset_discovery_csp_source == "'self'" else f"frame-src 'self' {asset_discovery_csp_source}",
            "frame-ancestors *" if is_dev_mode else "frame-ancestors 'self'",
            "base-uri 'self'",
            "form-action 'self'" if asset_discovery_csp_source == "'self'" else f"form-action 'self' {asset_discovery_csp_source}",
            "object-src 'none'"
        ]
        response.headers['Content-Security-Policy'] = "; ".join(csp_directives)

        # Additional security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        # In dev mode, allow embedding; in production, restrict to same origin
        if not is_dev_mode:
            response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'

        # OWASP: Permissions-Policy - restrict browser features
        response.headers['Permissions-Policy'] = (
            'accelerometer=(), camera=(), geolocation=(), gyroscope=(), '
            'magnetometer=(), microphone=(), payment=(), usb=()'
        )

        # HSTS - only enable in production with HTTPS
        if os.environ.get('FLASK_ENV') == 'production':
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'

        return response

    # Apply ProxyFix middleware if behind reverse proxy (nginx, etc.)
    # This properly handles X-Forwarded-* headers for correct IP detection and HTTPS awareness
    if os.environ.get('PROXY_FIX_X_FOR'):
        x_for = int(os.environ.get('PROXY_FIX_X_FOR', 1))
        x_proto = int(os.environ.get('PROXY_FIX_X_PROTO', 1))
        x_host = int(os.environ.get('PROXY_FIX_X_HOST', 1))
        x_port = int(os.environ.get('PROXY_FIX_X_PORT', 1))
        x_prefix = int(os.environ.get('PROXY_FIX_X_PREFIX', 0))
        app.wsgi_app = ProxyFix(
            app.wsgi_app,
            x_for=x_for,
            x_proto=x_proto,
            x_host=x_host,
            x_port=x_port,
            x_prefix=x_prefix
        )
        logger.info(f"ProxyFix middleware enabled (x_for={x_for}, x_proto={x_proto}, x_host={x_host})")

    return app

def configure_redis():
    """Configure Redis connection for distributed rate limiting"""
    redis_enabled = os.environ.get('REDIS_ENABLED', 'false').lower() == 'true'
    redis_url = os.environ.get('REDIS_URL', 'redis://localhost:6379/1')

    redis_client = None
    storage_uri = "memory://"  # Default to in-memory storage

    logger = logging.getLogger(__name__)

    if redis_enabled and REDIS_AVAILABLE:
        try:
            redis_client = redis.from_url(redis_url, decode_responses=True, socket_connect_timeout=5)
            # Test connection
            redis_client.ping()
            storage_uri = redis_url
            logger.info(f"[OK] Redis connected: {redis_url} (distributed rate limiting enabled)")
            print(f"[OK] Redis connected: {redis_url}")
        except (RedisError, Exception) as e:
            logger.warning(f"[FAIL] Redis connection failed: {e}")
            logger.info("Falling back to in-memory rate limiting (single-instance only)")
            print(f"[WARN] Redis connection failed: {e}")
            print("  Falling back to in-memory rate limiting")
            redis_client = None
            storage_uri = "memory://"
    elif redis_enabled and not REDIS_AVAILABLE:
        logger.warning("Redis enabled but 'redis' library not installed. Install with: pip install redis")
        print("[WARN] Redis enabled but 'redis' library not installed")
        print("  Install with: pip install redis")

    return redis_client, storage_uri

def configure_rate_limiter(app, storage_uri):
    """Configure rate limiting for API endpoints"""
    logger = logging.getLogger(__name__)

    # Check if development mode - use higher limits
    is_dev = os.environ.get('FLASK_ENV', 'development') == 'development'
    if is_dev:
        # Development: higher limits for testing (dashboard polls frequently)
        default_limits = ["100000 per day", "10000 per hour"]
    else:
        # Production: scaled for enterprise (100+ servers, multiple users)
        # Each server scan = ~10-15 API calls, polling = ~20/min per user
        # 100 servers × 15 calls + 5 users × 20/min × 60 = 7,500/hour
        default_limits = ["50000 per day", "5000 per hour"]

    if LIMITER_AVAILABLE:
        limiter = Limiter(
            app=app,
            key_func=get_remote_address,
            default_limits=default_limits,
            storage_uri=storage_uri
        )
        if storage_uri.startswith("redis://"):
            logger.info("Rate limiting configured with Redis (multi-instance support)")
        else:
            logger.info("Rate limiting configured with in-memory storage (single-instance only)")
        return limiter
    else:
        logger.warning("Rate limiting not available (flask-limiter not installed)")
        return None

def configure_database():
    """
    Configure database connection with support for both SQLite and PostgreSQL

    Environment Variables:
        DATABASE_URL: Connection string override (default policy-based runtime URL)
        DATABASE_POOL_SIZE: Connection pool size for PostgreSQL (default: 20)
        DATABASE_MAX_OVERFLOW: Max overflow connections for PostgreSQL (default: 40)

    Returns:
        Tuple of (engine, SessionLocal) or (None, None) if SQLAlchemy unavailable
    """
    logger = logging.getLogger(__name__)

    if not SQLALCHEMY_AVAILABLE:
        logger.warning("SQLAlchemy not available - database features disabled")
        return None, None

    # Get database URL from environment or use policy-aware runtime default
    database_url = normalize_database_url(
        os.environ.get('DATABASE_URL', get_runtime_default_database_url(data_root=DATA_ROOT)),
        data_root=DATA_ROOT
    )

    # Determine if PostgreSQL or SQLite
    is_postgresql = database_url.startswith('postgresql')

    try:
        if is_postgresql:
            # PostgreSQL configuration with connection pooling and retry logic
            pool_size = int(os.environ.get('DATABASE_POOL_SIZE', '20'))
            max_overflow = int(os.environ.get('DATABASE_MAX_OVERFLOW', '40'))
            max_retries = int(os.environ.get('DATABASE_CONNECT_RETRIES', '10'))
            retry_delay = float(os.environ.get('DATABASE_RETRY_DELAY', '2.0'))

            engine = None
            for attempt in range(max_retries):
                try:
                    engine = create_engine(
                        database_url,
                        poolclass=QueuePool,
                        pool_size=pool_size,
                        max_overflow=max_overflow,
                        pool_pre_ping=True,  # Verify connections before use
                        pool_recycle=3600,   # Recycle connections after 1 hour
                        echo=os.environ.get('SQL_ECHO', 'false').lower() == 'true'
                    )
                    # Test the connection
                    with engine.connect() as conn:
                        conn.execute(text('SELECT 1'))
                    logger.info(f"[OK] PostgreSQL connected on attempt {attempt + 1}")
                    break
                except Exception as conn_err:
                    if attempt < max_retries - 1:
                        logger.warning(f"Database connection attempt {attempt + 1}/{max_retries} failed: {conn_err}")
                        time.sleep(retry_delay)
                    else:
                        raise conn_err

            if engine is None:
                raise Exception("Failed to create database engine")

            logger.info(f"[OK] PostgreSQL configured: pool_size={pool_size}, max_overflow={max_overflow}")
            print("[OK] PostgreSQL database connected")
            print(f"  Pool: {pool_size} connections + {max_overflow} overflow")

        else:
            # SQLite configuration (simpler, no connection pooling)
            engine = create_engine(
                database_url,
                connect_args={'check_same_thread': False},
                poolclass=NullPool,  # SQLite doesn't benefit from pooling
                echo=os.environ.get('SQL_ECHO', 'false').lower() == 'true'
            )
            logger.info(f"[OK] SQLite configured: {database_url}")
            print(f"[OK] SQLite database: {database_url}")
            print("  Note: For 100+ servers, consider PostgreSQL")

        # Create session factory
        SessionLocal = scoped_session(
            sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=engine
            )
        )

        # Initialize database tables if they don't exist
        from models.database import Base
        # Import all models to register them with Base.metadata
        # This imports in the order defined in models/__init__.py
        import models  # noqa - loads all models
        logger.debug("After 'import models'")
        logger.debug(f"Tables so far: {list(Base.metadata.tables.keys())}")

        # Explicitly import models that may not be auto-loaded due to import issues
        # These have ForeignKey relationships that must be resolved
        try:
            from models.schedule import ScheduledAudit  # noqa
            logger.debug(f"ScheduledAudit imported: {ScheduledAudit.__tablename__}")
        except Exception as e:
            logger.debug(f"ScheduledAudit import failed: {type(e).__name__}: {e}")

        try:
            from models.server_group import ServerGroup  # noqa
            logger.debug(f"ServerGroup imported: {ServerGroup.__tablename__}")
        except Exception as e:
            logger.debug(f"ServerGroup import failed: {type(e).__name__}: {e}")

        logger.debug(f"Final tables: {list(Base.metadata.tables.keys())}")

        # Create tables - wrap in try/except for race condition handling
        # Multiple gunicorn workers may try to create tables simultaneously
        try:
            Base.metadata.create_all(engine)
        except Exception as create_err:
            # Check if it's a duplicate object error (race condition)
            err_str = str(create_err).lower()
            if 'already exists' in err_str or 'duplicate' in err_str:
                logger.warning(f"Tables already created by another worker: {create_err}")
            else:
                raise

        logger.info("[OK] Database tables initialized")
        return engine, SessionLocal

    except Exception as e:
        logger.error(f"[FAIL] Database configuration failed: {e}")
        print(f"[FAIL] Database configuration failed: {e}")
        return None, None

# Initialize configuration
initialize_directories()
logger = setup_logging()
app = create_app()
redis_client, storage_uri = configure_redis()
limiter = configure_rate_limiter(app, storage_uri)
db_engine, SessionLocal = configure_database()
enforce_server_password_storage_format(db_engine, logger=logger)

# Log effective upload limits (license-capped) for operational visibility.
# This runs after DB/session initialization to avoid startup circular imports.
try:
    from api.upload_rate_limits import get_upload_limit_observability_snapshot

    _upload_limit_snapshot = get_upload_limit_observability_snapshot()
    logger.info(
        "Upload limits active (tier=%s): standalone=%s managed=%s hypervisor=%s asset_discovery=%s",
        _upload_limit_snapshot["tier"],
        _upload_limit_snapshot["standalone"],
        _upload_limit_snapshot["managed"],
        _upload_limit_snapshot["hypervisor"],
        _upload_limit_snapshot["asset_discovery"],
    )
except Exception as _upload_limit_log_err:
    logger.warning("Could not log upload limit snapshot at startup: %s", _upload_limit_log_err)

# Import Base from models for ORM models (after db initialization)
try:
    from models.database import Base
except ImportError:
    Base = None  # SQLAlchemy not available

# Export datetime for app start time tracking (used in health checks)
from datetime import datetime
app_start_time = datetime.now()

__all__ = [
    'app',
    'limiter',
    'logger',
    'redis_client',
    'storage_uri',
    'db_engine',
    'SessionLocal',
    'Base',
    'app_start_time',
    'get_db_session',
    'ROOT_DIR',
    'DATA_ROOT',
    'ORCHESTRATOR_PATH',
    'DISCOVERY_PATH',
    'AUDITS_DIR',
    'LOGS_DIR',
    'PLANS_DIR',
    'SERVERS_DIR',
    'SSH_DIR',
    'HISTORY_DIR',
    'SCHEDULES_DIR',
    'SETTINGS_DIR',
]


def get_db_session():
    """
    Get a new database session

    Returns a scoped session that should be closed after use.
    Used by Flask routes for database operations.

    Returns:
        SQLAlchemy session or None if database unavailable
    """
    if SessionLocal:
        return SessionLocal()
    return None
