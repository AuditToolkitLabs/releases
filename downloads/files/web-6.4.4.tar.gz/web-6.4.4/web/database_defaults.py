#!/usr/bin/env python3
"""
Database default resolution helpers.

Policy:
- Server/standalone runtime defaults to PostgreSQL.
- Containerized runtime defaults to SQLite unless explicitly overridden.
"""

import os
from pathlib import Path
from typing import Optional


def normalize_database_url(database_url: str, data_root: Optional[Path] = None) -> str:
    """Resolve relative SQLite URLs against a stable runtime data root."""
    if not database_url:
        return database_url

    if not database_url.startswith('sqlite:///'):
        return database_url

    raw_path = database_url.replace('sqlite:///', '', 1).strip()
    if not raw_path:
        return database_url

    sqlite_path = Path(raw_path)
    if sqlite_path.is_absolute():
        return database_url

    if data_root is None:
        data_root_env = os.environ.get('AUDIT_TOOLKIT_DATA_DIR', '').strip()
        if data_root_env:
            data_root = Path(data_root_env).expanduser().resolve()
        else:
            data_root = Path(__file__).parent.parent.resolve()

    return f"sqlite:///{(data_root / sqlite_path).resolve()}"


def _is_container_runtime() -> bool:
    """Best-effort detection for Docker/Podman/Kubernetes runtimes."""
    if os.environ.get('DOCKER_CONTAINER') or os.environ.get('container'):
        return True

    if os.environ.get('KUBERNETES_SERVICE_HOST'):
        return True

    if os.name == 'posix':
        if Path('/.dockerenv').exists() or Path('/run/.containerenv').exists():
            return True

        cgroup_path = Path('/proc/1/cgroup')
        if cgroup_path.exists():
            try:
                content = cgroup_path.read_text(encoding='utf-8', errors='ignore')
                if any(marker in content for marker in ('docker', 'containerd', 'kubepods', 'lxc')):
                    return True
            except OSError:
                pass

    return False


def get_default_postgres_url() -> str:
    """Build the default PostgreSQL URL from environment overrides."""
    explicit_default = os.environ.get('POSTGRESQL_URL_DEFAULT', '').strip()
    if explicit_default:
        return explicit_default

    user = os.environ.get('POSTGRES_USER', 'audittoolkit')
    password = os.environ.get('POSTGRES_PASSWORD', 'Atk!7Xq3vL9mP2_kZ5nR8')
    host = os.environ.get('POSTGRES_HOST', 'localhost')
    port = os.environ.get('POSTGRES_PORT', '5432')
    database = os.environ.get('POSTGRES_DB', 'audittoolkit')
    return f'postgresql://{user}:{password}@{host}:{port}/{database}'


def get_default_sqlite_url(data_root: Optional[Path] = None) -> str:
    """Build the default SQLite URL for local/container test deployments."""
    if data_root is None:
        data_root_env = os.environ.get('AUDIT_TOOLKIT_DATA_DIR', '').strip()
        if data_root_env:
            data_root = Path(data_root_env).expanduser().resolve()
        else:
            data_root = Path(__file__).parent.parent.resolve()

    return f'sqlite:///{data_root}/audit_toolkit.db'


def get_runtime_default_database_url(data_root: Optional[Path] = None) -> str:
    """
    Resolve default runtime DB URL according to deployment policy.

    AUDIT_TOOLKIT_DB_MODE can explicitly force:
      - postgres
      - sqlite
    """
    db_mode = os.environ.get('AUDIT_TOOLKIT_DB_MODE', '').strip().lower()
    if db_mode in {'postgres', 'postgresql'}:
        return get_default_postgres_url()

    if db_mode == 'sqlite':
        return get_default_sqlite_url(data_root=data_root)

    if _is_container_runtime():
        return get_default_sqlite_url(data_root=data_root)

    return get_default_postgres_url()
