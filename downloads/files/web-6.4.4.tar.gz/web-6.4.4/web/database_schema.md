# PostgreSQL Database Schema Design

**Security Audit Toolkit - Database Architecture**  
**Version**: 2.0  
**Date**: February 6, 2026

---

## Overview

This schema replaces file-based storage (SQLite) with PostgreSQL for enterprise scale. Designed to support:
- **500+ servers** with optimal performance
- **Audit history tracking** with full-text search
- **Scheduled audits** with cron-like scheduling
- **Multi-user support** (future RBAC foundation)
- **Efficient queries** with proper indexing

---

## Schema: 4 Core Tables

### 1. `servers` - Server Inventory

Stores remote Linux servers managed by the toolkit.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique server ID |
| `name` | VARCHAR(255) | UNIQUE, NOT NULL | Human-readable server name |
| `hostname` | VARCHAR(255) | NOT NULL | IP address or FQDN |
| `port` | INTEGER | NOT NULL, DEFAULT 22 | SSH port |
| `username` | VARCHAR(100) | NOT NULL | SSH username |
| `password` | TEXT | NULLABLE | Encrypted password (Fernet) |
| `ssh_key_path` | VARCHAR(500) | NULLABLE | Path to SSH private key |
| `description` | TEXT | NULLABLE | Optional server description |
| `tags` | TEXT | NULLABLE | JSON array of tags (e.g., ["production", "web"]) |
| `created_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Record creation timestamp |
| `updated_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Last modification timestamp |
| `last_audit_at` | TIMESTAMP | NULLABLE | Last successful audit execution |

**Indexes**:
- `idx_servers_name` (UNIQUE) - Fast lookup by name
- `idx_servers_hostname` - Fast lookup by hostname
- `idx_servers_tags` (GIN for PostgreSQL) - Tag-based filtering

**Constraints**:
- Must have either `password` OR `ssh_key_path` (enforced in application layer)

---

### 2. `audits` - Audit Script Metadata

Stores metadata about available audit scripts for efficient discovery.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique audit ID |
| `name` | VARCHAR(255) | NOT NULL | Audit script filename (e.g., "ssh-hardening-audit.sh") |
| `domain` | VARCHAR(50) | NOT NULL | Domain (platform, web, data, apps, storage, network, automation) |
| `category` | VARCHAR(100) | NOT NULL | Category within domain (e.g., "baseline", "access") |
| `file_path` | VARCHAR(500) | UNIQUE, NOT NULL | Relative path from project root |
| `description` | TEXT | NULLABLE | Audit purpose/description |
| `created_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Discovery timestamp |
| `updated_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Last metadata update |

**Indexes**:
- `idx_audits_domain` - Filter by domain
- `idx_audits_name` - Fast lookup by script name
- `idx_audits_file_path` (UNIQUE) - Prevent duplicates

**Composite Indexes**:
- `idx_audits_domain_category` - Efficient domain + category queries

---

### 3. `audit_executions` - Execution History

Stores results of audit executions with full output for analysis.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique execution ID |
| `server_id` | INTEGER | FOREIGN KEY → servers(id), NOT NULL | Server where audit ran |
| `audit_id` | INTEGER | FOREIGN KEY → audits(id), NOT NULL | Audit script executed |
| `status` | VARCHAR(20) | NOT NULL | Execution status: `success`, `failure`, `timeout`, `running` |
| `exit_code` | INTEGER | NULLABLE | Process exit code (0 = success) |
| `output` | TEXT | NULLABLE | Full stdout/stderr from audit script |
| `summary` | TEXT | NULLABLE | JSON summary: `{"pass": 10, "warn": 2, "fail": 1}` |
| `duration_seconds` | FLOAT | NULLABLE | Execution time in seconds |
| `executed_by` | VARCHAR(100) | NULLABLE | User who triggered (for future multi-user) |
| `executed_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Execution start time |
| `completed_at` | TIMESTAMP | NULLABLE | Execution completion time |

**Indexes**:
- `idx_executions_server_id` - All executions for a server
- `idx_executions_audit_id` - All executions of an audit
- `idx_executions_status` - Filter by status
- `idx_executions_executed_at` - Time-based queries (DESC for recent first)

**Composite Indexes**:
- `idx_executions_server_audit` (server_id, audit_id, executed_at DESC) - Execution history per server+audit
- `idx_executions_server_status` (server_id, status, executed_at DESC) - Failed audits per server

**Foreign Key Constraints**:
- `ON DELETE CASCADE` - Delete executions when server/audit deleted

---

### 4. `scheduled_audits` - Scheduled Jobs

Stores scheduled audit jobs (cron-like scheduling).

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique schedule ID |
| `server_id` | INTEGER | FOREIGN KEY → servers(id), NOT NULL | Target server |
| `audit_id` | INTEGER | FOREIGN KEY → audits(id), NULLABLE | Specific audit (NULL = all audits) |
| `schedule_cron` | VARCHAR(100) | NOT NULL | Cron expression (e.g., "0 2 * * *" for 2am daily) |
| `enabled` | BOOLEAN | NOT NULL, DEFAULT TRUE | Enable/disable schedule |
| `last_run_at` | TIMESTAMP | NULLABLE | Last execution timestamp |
| `next_run_at` | TIMESTAMP | NULLABLE | Calculated next execution time |
| `created_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Schedule creation timestamp |
| `updated_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Last modification timestamp |

**Indexes**:
- `idx_scheduled_server_id` - Schedules for a server
- `idx_scheduled_enabled_next` (enabled, next_run_at) - Find next jobs to run

**Foreign Key Constraints**:
- `ON DELETE CASCADE` - Delete schedules when server/audit deleted

---

## Schema Diagram (Entity-Relationship)

```
┌─────────────────┐
│    servers      │
│─────────────────│
│ id (PK)         │◄────┐
│ name (UNIQUE)   │     │
│ hostname        │     │
│ port            │     │
│ username        │     │
│ password (enc)  │     │
│ ssh_key_path    │     │
│ tags (JSON)     │     │
│ created_at      │     │
│ updated_at      │     │
│ last_audit_at   │     │
└─────────────────┘     │
                        │
                        │
┌─────────────────┐     │     ┌──────────────────────┐
│    audits       │     │     │  audit_executions    │
│─────────────────│     │     │──────────────────────│
│ id (PK)         │◄────┼─────┤ id (PK)              │
│ name            │     │     │ server_id (FK)       │
│ domain          │     └─────┤ audit_id (FK)        │
│ category        │           │ status               │
│ file_path       │           │ exit_code            │
│ description     │           │ output (TEXT)        │
│ created_at      │           │ summary (JSON)       │
│ updated_at      │           │ duration_seconds     │
└─────────────────┘           │ executed_by          │
         │                    │ executed_at          │
         │                    │ completed_at         │
         │                    └──────────────────────┘
         │
         │
         │         ┌─────────────────────┐
         │         │ scheduled_audits    │
         │         │─────────────────────│
         │         │ id (PK)             │
         └─────────┤ server_id (FK)      │
                   │ audit_id (FK, NULL) │
                   │ schedule_cron       │
                   │ enabled             │
                   │ last_run_at         │
                   │ next_run_at         │
                   │ created_at          │
                   │ updated_at          │
                   └─────────────────────┘
```

---

## Migration Strategy

### Phase 1: Dual Support (v2.0)

Support both SQLite and PostgreSQL:
- **SQLite**: Default for single-server deployments
- **PostgreSQL**: Opt-in via `DATABASE_URL` environment variable

**Configuration Detection**:
```python
# config.py
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///audit_toolkit.db')

if DATABASE_URL.startswith('postgresql'):
    # Use PostgreSQL with connection pooling
    engine = create_engine(DATABASE_URL, pool_size=20, max_overflow=40)
else:
    # Use SQLite with simpler settings
    engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False})
```

### Phase 2: Migration Script

Provide `migrate_sqlite_to_postgres.py` to move existing data:

```bash
# Example migration
python web/scripts/migrate_to_postgres.py \
  --source sqlite:///audit_toolkit.db \
  --target postgresql://user:pass@localhost/audit_toolkit
```

---

## Performance Optimizations

### 1. Connection Pooling

**SQLAlchemy Settings**:
```python
engine = create_engine(
    DATABASE_URL,
    pool_size=20,           # 20 persistent connections
    max_overflow=40,        # Up to 40 additional connections
    pool_pre_ping=True,     # Validate connections before use
    pool_recycle=3600       # Recycle connections after 1 hour
)
```

**Expected Performance**:
- Support 60 concurrent connections (20 pool + 40 overflow)
- Handle 100+ servers with parallel audit execution

### 2. Query Optimization

**Efficient Queries**:
```python
# BAD: N+1 query problem
for server in servers:
    executions = get_executions(server.id)

# GOOD: Single query with JOIN
servers_with_executions = db.query(Server).options(
    joinedload(Server.executions)
).all()
```

**Pagination for Large Results**:
```python
# Limit 100 results per page
executions = db.query(AuditExecution)\
    .order_by(AuditExecution.executed_at.desc())\
    .limit(100)\
    .offset(page * 100)\
    .all()
```

### 3. Full-Text Search (PostgreSQL)

**Search Audit Output**:
```sql
-- Add GIN index for full-text search
CREATE INDEX idx_executions_output_fts ON audit_executions
USING GIN(to_tsvector('english', output));

-- Search query
SELECT * FROM audit_executions
WHERE to_tsvector('english', output) @@ to_tsquery('english', 'critical & vulnerability');
```

---

## Backup & Restore

### Backup Strategy

```bash
# Full backup (daily)
pg_dump -U postgres -d audit_toolkit -F c -f backup_$(date +%Y%m%d).dump

# Incremental backup (use WAL archiving)
# Configure in postgresql.conf:
# archive_mode = on
# archive_command = 'cp %p /backup/wal/%f'
```

### Restore

```bash
# Restore from dump
pg_restore -U postgres -d audit_toolkit -c backup_20260206.dump
```

---

## Security Considerations

### 1. Password Encryption

All passwords in `servers.password` are encrypted using Fernet (symmetric encryption):
```python
from cryptography.fernet import Fernet

# Encrypt before storing
encrypted = cipher.encrypt(password.encode())

# Decrypt when using
password = cipher.decrypt(encrypted).decode()
```

### 2. Connection Security

**Enforce SSL for PostgreSQL connections**:
```python
DATABASE_URL = "postgresql://user:pass@host/db?sslmode=require"
```

### 3. SQL Injection Prevention

**Always use parameterized queries**:
```python
# GOOD: SQLAlchemy ORM (automatic parameterization)
server = db.query(Server).filter(Server.name == user_input).first()

# GOOD: Raw SQL with parameters
db.execute("SELECT * FROM servers WHERE name = :name", {"name": user_input})

# BAD: String concatenation (NEVER DO THIS)
db.execute(f"SELECT * FROM servers WHERE name = '{user_input}'")
```

---

## Future Enhancements

### Phase 3: Advanced Features

1. **Multi-tenancy**:
   - Add `tenants` table
   - Add `tenant_id` foreign key to all tables
   - Row-level security policies

2. **User Management**:
   - Add `users` table with roles (admin, viewer, auditor)
   - Link `audit_executions.executed_by` to `users.id`

3. **Audit Recommendations**:
   - Add `recommendations` table
   - Link to specific `audit_executions` findings

4. **Compliance Reporting**:
   - Add `compliance_frameworks` table (PCI-DSS, HIPAA, SOC2)
   - Map audits to framework controls

---

## Testing Checklist

- [ ] Create all 4 tables successfully
- [ ] Insert 100 sample servers
- [ ] Insert 50 sample audits
- [ ] Insert 10,000 audit executions
- [ ] Query performance < 100ms for recent executions
- [ ] Full-text search works on audit output
- [ ] Foreign key constraints enforced
- [ ] Indexes improve query speed (EXPLAIN ANALYZE)
- [ ] Connection pooling handles 60 concurrent connections
- [ ] Migration from SQLite preserves all data

---

## SQL Schema (Reference)

```sql
-- Table: servers
CREATE TABLE servers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    hostname VARCHAR(255) NOT NULL,
    port INTEGER NOT NULL DEFAULT 22,
    username VARCHAR(100) NOT NULL,
    password TEXT,
    ssh_key_path VARCHAR(500),
    description TEXT,
    tags TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    last_audit_at TIMESTAMP
);

CREATE INDEX idx_servers_name ON servers(name);
CREATE INDEX idx_servers_hostname ON servers(hostname);
CREATE INDEX idx_servers_tags ON servers USING GIN((tags::jsonb));

-- Table: audits
CREATE TABLE audits (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(50) NOT NULL,
    category VARCHAR(100) NOT NULL,
    file_path VARCHAR(500) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audits_domain ON audits(domain);
CREATE INDEX idx_audits_name ON audits(name);
CREATE INDEX idx_audits_file_path ON audits(file_path);
CREATE INDEX idx_audits_domain_category ON audits(domain, category);

-- Table: audit_executions
CREATE TABLE audit_executions (
    id SERIAL PRIMARY KEY,
    server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    audit_id INTEGER NOT NULL REFERENCES audits(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL,
    exit_code INTEGER,
    output TEXT,
    summary TEXT,
    duration_seconds FLOAT,
    executed_by VARCHAR(100),
    executed_at TIMESTAMP NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMP
);

CREATE INDEX idx_executions_server_id ON audit_executions(server_id);
CREATE INDEX idx_executions_audit_id ON audit_executions(audit_id);
CREATE INDEX idx_executions_status ON audit_executions(status);
CREATE INDEX idx_executions_executed_at ON audit_executions(executed_at DESC);
CREATE INDEX idx_executions_server_audit ON audit_executions(server_id, audit_id, executed_at DESC);
CREATE INDEX idx_executions_server_status ON audit_executions(server_id, status, executed_at DESC);
CREATE INDEX idx_executions_output_fts ON audit_executions USING GIN(to_tsvector('english', output));

-- Table: scheduled_audits
CREATE TABLE scheduled_audits (
    id SERIAL PRIMARY KEY,
    server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    audit_id INTEGER REFERENCES audits(id) ON DELETE CASCADE,
    schedule_cron VARCHAR(100) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    last_run_at TIMESTAMP,
    next_run_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_scheduled_server_id ON scheduled_audits(server_id);
CREATE INDEX idx_scheduled_enabled_next ON scheduled_audits(enabled, next_run_at);
```

---

## Next Steps

1. ✅ **Schema design complete** (this document)
2. ⏳ Create SQLAlchemy models (`web/models/database.py`)
3. ⏳ Set up Alembic migrations (`web/migrations/`)
4. ⏳ Update `config.py` with database configuration
5. ⏳ Update server CRUD operations to use ORM
6. ⏳ Create migration script from SQLite
7. ⏳ Update `docker-compose.yml` with PostgreSQL service
