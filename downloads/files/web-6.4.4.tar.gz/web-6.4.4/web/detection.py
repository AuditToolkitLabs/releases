"""
OS Detection Module - Automatic Linux/Windows Detection

This module automatically detects whether a server is running Linux or Windows
by attempting SSH connection first (Linux), then falling back to WinRM (Windows).

Usage:
    from detection import detect_server_os, OSDetectionError
    
    try:
        os_info = detect_server_os(
            hostname='server.example.com',
            username='admin',
            credential='password123'
        )
        
        print(f"Detected OS: {os_info['name']}")
        print(f"Type: {os_info['type']}")
        print(f"Protocol: {os_info['protocol']}")
        
    except OSDetectionError as e:
        print(f"Detection failed: {e}")

Returns dictionary with:
    - type: 'linux' or 'windows'
    - name: 'Ubuntu 22.04', 'Windows Server 2019', etc.
    - version: '22.04', '10.0.17763', etc.
    - architecture: 'x86_64', 'x64', etc.
    - protocol: 'ssh' or 'winrm'
    - port: 22, 5985, or 5986
    - connection_type: 'ssh' or 'winrm'
    - build: '17763' (Windows only)
    - ssl: True/False
    - auth_used: 'ntlm', 'basic', etc. (WinRM only)
"""

import logging
import json
import os
import re
import paramiko
from pypsrp.client import Client
from pypsrp.powershell import PowerShell, RunspacePool
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


ALLOWED_SSH_DETECTION_COMMANDS = frozenset({
    'cat /etc/os-release',
    'uname -m',
    'uname -r',
})


def _resolve_ssh_host_key_policy() -> paramiko.MissingHostKeyPolicy:
    """Resolve SSH host key policy for OS detection.

    Defaults to strict host key rejection in production-like environments,
    and warning mode in development/test to preserve local workflow
    compatibility.
    """
    policy_mode = os.getenv('ATK_SSH_HOST_KEY_POLICY', '').strip().lower()
    if not policy_mode:
        environment = (os.getenv('FLASK_ENV') or os.getenv('ENVIRONMENT') or '').strip().lower()
        policy_mode = 'warning' if environment in {'development', 'dev', 'test', 'local'} else 'reject'

    if policy_mode == 'warning':
        return paramiko.WarningPolicy()

    return paramiko.RejectPolicy()


def _exec_ssh_detection_command(
    ssh_client: paramiko.SSHClient,
    command: str,
    timeout: int,
    strip_result: bool = True,
) -> str:
    """Execute only allowlisted detection commands via SSH."""
    if command not in ALLOWED_SSH_DETECTION_COMMANDS:
        raise ValueError(f"Unsupported SSH detection command: {command}")

    _, stdout, _ = ssh_client.exec_command(command, timeout=timeout)  # nosec B601 - command is selected from a static allowlist
    result = stdout.read().decode('utf-8', errors='replace')
    return result.strip() if strip_result else result


class OSDetectionError(Exception):
    """Raised when OS detection fails on both SSH and WinRM."""
    pass


def detect_server_os(
    hostname: str,
    port: Optional[int] = None,
    username: str = '',
    credential: str = '',
    timeout: int = 10
) -> Dict[str, Any]:
    """
    Automatically detect server OS by trying SSH first, then WinRM.
    
    Strategy:
    1. Try SSH on port 22 (or custom) → If works, it's Linux
    2. If SSH fails, try WinRM on port 5985 (HTTP) → If works, it's Windows
    3. If WinRM HTTP fails, try port 5986 (HTTPS) → If works, it's Windows
    4. If all fail, raise OSDetectionError
    
    Args:
        hostname: Server hostname or IP address
        port: Optional explicit port (default: try 22, then 5985, then 5986)
        username: Username for authentication
        credential: Password or SSH key path
        timeout: Connection timeout in seconds
    
    Returns:
        Dictionary with OS information:
        {
            'type': 'linux' or 'windows',
            'name': 'Ubuntu 22.04 LTS' or 'Windows Server 2019 Datacenter',
            'version': '22.04' or '10.0.17763',
            'architecture': 'x86_64' or 'x64',
            'build': '17763' (Windows only),
            'protocol': 'ssh' or 'winrm',
            'port': 22, 5985, or 5986,
            'connection_type': 'ssh' or 'winrm',
            'ssl': False or True,
            'auth_used': 'ntlm' or 'basic' (WinRM only)
        }
    
    Raises:
        OSDetectionError: If cannot connect via SSH or WinRM
    """
    errors = {}
    
    logger.info(f"Starting OS detection for {hostname}")
    
    # Try SSH first (Linux/Unix)
    if port is None or port == 22:
        try:
            logger.debug(f"Attempting SSH connection to {hostname}:22")
            return _detect_via_ssh(
                hostname=hostname,
                port=port or 22,
                username=username,
                credential=credential,
                timeout=timeout
            )
        except Exception as ssh_err:
            errors['ssh'] = str(ssh_err)
            logger.debug(f"SSH detection failed: {ssh_err}")
    
    # Try WinRM HTTP (Windows)
    if port is None or port == 5985:
        try:
            logger.debug(f"Attempting WinRM HTTP connection to {hostname}:5985")
            return _detect_via_winrm(
                hostname=hostname,
                port=port or 5985,
                username=username,
                credential=credential,
                use_ssl=False,
                timeout=timeout
            )
        except Exception as winrm_http_err:
            errors['winrm_http'] = str(winrm_http_err)
            logger.debug(f"WinRM HTTP detection failed: {winrm_http_err}")
    
    # Try WinRM HTTPS (Windows with SSL)
    if port is None or port == 5986:
        try:
            logger.debug(f"Attempting WinRM HTTPS connection to {hostname}:5986")
            return _detect_via_winrm(
                hostname=hostname,
                port=port or 5986,
                username=username,
                credential=credential,
                use_ssl=True,
                timeout=timeout
            )
        except Exception as winrm_https_err:
            errors['winrm_https'] = str(winrm_https_err)
            logger.debug(f"WinRM HTTPS detection failed: {winrm_https_err}")
    
    # All methods failed
    error_msg = f"Unable to connect to {hostname} via SSH or WinRM.\n"
    for proto, err in errors.items():
        error_msg += f"  {proto}: {err}\n"
    
    logger.error(error_msg)
    raise OSDetectionError(error_msg.strip())


def _detect_via_ssh(
    hostname: str,
    port: int,
    username: str,
    credential: str,
    timeout: int
) -> Dict[str, Any]:
    """
    Detect Linux/Unix OS via SSH.
    
    Connects via SSH and reads /etc/os-release for distro information.
    Also gets architecture via 'uname -m'.
    
    Args:
        hostname: Target hostname
        port: SSH port (usually 22)
        username: SSH username
        credential: Password or SSH key file path
        timeout: Connection timeout in seconds
    
    Returns:
        Dictionary with Linux OS information
    
    Raises:
        Exception: If SSH connection or detection fails
    """
    ssh = None
    
    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()

        extra_known_hosts = os.getenv('ATK_SSH_KNOWN_HOSTS_FILE', '').strip()
        if extra_known_hosts:
            try:
                ssh.load_host_keys(extra_known_hosts)
            except Exception as e:
                logger.warning(f"Failed to load SSH known hosts from {extra_known_hosts}: {e}")

        ssh.set_missing_host_key_policy(_resolve_ssh_host_key_policy())
        
        # Determine authentication method
        if credential and credential.startswith('/'):
            # File path - assume SSH key
            logger.debug(f"Using SSH key authentication: {credential}")
            ssh.connect(
                hostname=hostname,
                port=port,
                username=username,
                key_filename=credential,
                timeout=timeout
            )
        else:
            # Assume password
            logger.debug(f"Using SSH password authentication")
            ssh.connect(
                hostname=hostname,
                port=port,
                username=username,
                password=credential,
                timeout=timeout
            )
        
        # Get OS release info (standard on modern Linux)
        os_release = _exec_ssh_detection_command(ssh, 'cat /etc/os-release', timeout=5, strip_result=False)
        
        # Get architecture
        arch = _exec_ssh_detection_command(ssh, 'uname -m', timeout=5)
        
        # Get kernel version (optional, for additional info)
        kernel = _exec_ssh_detection_command(ssh, 'uname -r', timeout=5)
        
        ssh.close()
        
        # Parse /etc/os-release
        os_info = _parse_os_release(os_release)
        
        result = {
            'type': 'linux',
            'name': os_info.get('PRETTY_NAME') or os_info.get('NAME', 'Unknown Linux'),
            'version': os_info.get('VERSION_ID', 'Unknown'),
            'architecture': arch,
            'kernel': kernel,
            'protocol': 'ssh',
            'port': port,
            'connection_type': 'ssh',
            'ssl': False,  # Standard SSH is not SSL/TLS (uses own encryption)
            'distro_id': os_info.get('ID', 'unknown')
        }
        
        logger.info(f"Detected Linux: {result['name']} ({result['version']})")
        return result
        
    except Exception as e:
        logger.error(f"SSH detection failed for {hostname}: {e}")
        raise
    
    finally:
        if ssh:
            try:
                ssh.close()
            except Exception as close_error:
                logger.debug("Ignoring SSH close error for %s: %s", hostname, close_error)


def _detect_via_winrm(
    hostname: str,
    port: int,
    username: str,
    credential: str,
    use_ssl: bool,
    timeout: int
) -> Dict[str, Any]:
    """
    Detect Windows OS via WinRM (PowerShell Remoting).
    
    Connects via WinRM and queries WMI for OS information.
    
    Args:
        hostname: Target hostname
        port: WinRM port (5985 HTTP or 5986 HTTPS)
        username: Windows username
        credential: Password
        use_ssl: Whether to use HTTPS (port 5986)
        timeout: Connection timeout in seconds
    
    Returns:
        Dictionary with Windows OS information
    
    Raises:
        Exception: If WinRM connection or detection fails
    """
    # Try different authentication methods
    auth_methods = ['ntlm', 'basic']
    last_error = None
    
    for auth in auth_methods:
        try:
            logger.debug(f"Trying WinRM with {auth} authentication")
            
            client = Client(
                hostname,
                username=username,
                password=credential,
                port=port,
                ssl=use_ssl,
                auth=auth,
                cert_validation=False,  # Allow self-signed certs (development)
                read_timeout=timeout,
                operation_timeout=timeout
            )
            
            # PowerShell script to get OS information
            ps_script = """
$os = Get-WmiObject -Class Win32_OperatingSystem
$cs = Get-WmiObject -Class Win32_ComputerSystem

@{
    Caption = $os.Caption
    Version = $os.Version
    BuildNumber = $os.BuildNumber
    Architecture = $os.OSArchitecture
    ServicePackMajor = $os.ServicePackMajorVersion
    ServicePackMinor = $os.ServicePackMinorVersion
    ProductType = $os.ProductType
    Domain = $cs.Domain
    PartOfDomain = $cs.PartOfDomain
    Manufacturer = $cs.Manufacturer
    Model = $cs.Model
} | ConvertTo-Json
"""
            
            # Execute PowerShell
            output, streams, had_errors = client.execute_ps(ps_script)
            
            if had_errors:
                error_msgs = [str(e) for e in streams.error]
                raise Exception(f"PowerShell errors: {'; '.join(error_msgs)}")
            
            # Parse JSON output
            os_info = json.loads(output)
            
            # Determine Windows edition
            product_type = os_info.get('ProductType', 1)
            edition = _get_windows_edition(product_type, os_info.get('Caption', ''))
            
            result = {
                'type': 'windows',
                'name': os_info.get('Caption', 'Windows').strip(),
                'version': os_info.get('Version', 'Unknown'),
                'architecture': os_info.get('Architecture', 'Unknown').replace('-bit', ''),
                'build': os_info.get('BuildNumber', 'Unknown'),
                'protocol': 'winrm',
                'port': port,
                'connection_type': 'winrm',
                'ssl': use_ssl,
                'auth_used': auth,
                'edition': edition,
                'domain': os_info.get('Domain') if os_info.get('PartOfDomain') else None,
                'manufacturer': os_info.get('Manufacturer'),
                'model': os_info.get('Model')
            }
            
            logger.info(f"Detected Windows: {result['name']} Build {result['build']}")
            return result
            
        except Exception as e:
            last_error = e
            logger.debug(f"WinRM detection with {auth} failed: {e}")
            continue
    
    # All auth methods failed
    raise Exception(f"WinRM detection failed with all auth methods. Last error: {last_error}")


def _parse_os_release(content: str) -> Dict[str, str]:
    """
    Parse /etc/os-release file content.
    
    Example content:
        NAME="Ubuntu"
        VERSION="22.04.1 LTS (Jammy Jellyfish)"
        ID=ubuntu
        ID_LIKE=debian
        PRETTY_NAME="Ubuntu 22.04.1 LTS"
        VERSION_ID="22.04"
        VERSION_CODENAME=jammy
    
    Args:
        content: Content of /etc/os-release file
    
    Returns:
        Dictionary with parsed key=value pairs
    """
    result = {}
    
    for line in content.splitlines():
        line = line.strip()
        
        # Skip empty lines and comments
        if not line or line.startswith('#'):
            continue
        
        # Parse KEY=VALUE or KEY="VALUE"
        if '=' in line:
            key, value = line.split('=', 1)
            
            # Remove quotes from value
            value = value.strip('"').strip("'")
            
            result[key] = value
    
    return result


def _get_windows_edition(product_type: int, caption: str) -> str:
    """
    Determine Windows edition from product type and caption.
    
    Product types:
    1 = Workstation (Windows 10/11)
    2 = Domain Controller
    3 = Server
    
    Args:
        product_type: Product type from Win32_OperatingSystem.ProductType
        caption: OS caption from Win32_OperatingSystem.Caption
    
    Returns:
        Human-readable edition string
    """
    if product_type == 1:
        if 'Windows 11' in caption:
            return 'Windows 11 Workstation'
        elif 'Windows 10' in caption:
            return 'Windows 10 Workstation'
        else:
            return 'Windows Workstation'
    
    elif product_type == 2:
        return 'Domain Controller'
    
    elif product_type == 3:
        if 'Datacenter' in caption:
            return 'Windows Server Datacenter'
        elif 'Standard' in caption:
            return 'Windows Server Standard'
        elif 'Essentials' in caption:
            return 'Windows Server Essentials'
        else:
            return 'Windows Server'
    
    return 'Unknown Edition'


def get_os_version_friendly(os_info: Dict[str, Any]) -> str:
    """
    Get human-friendly OS version string.
    
    Args:
        os_info: OS information dictionary from detect_server_os()
    
    Returns:
        Friendly version string like "Windows Server 2019" or "Ubuntu 22.04 LTS"
    """
    if os_info['type'] == 'windows':
        # Map Windows build numbers to marketing versions
        build = os_info.get('build', '')
        
        build_map = {
            '17763': 'Server 2019',
            '20348': 'Server 2022',
            '14393': 'Server 2016',
            '9600': 'Server 2012 R2',
            '9200': 'Server 2012',
            '19041': '10 version 2004',
            '19042': '10 version 20H2',
            '19043': '10 version 21H1',
            '19044': '10 version 21H2',
            '22000': '11 version 21H2',
            '22621': '11 version 22H2'
        }
        
        version_name = build_map.get(build, f"Build {build}")
        
        if 'Server' in os_info['name']:
            return f"Windows {version_name}"
        else:
            return f"Windows {version_name}"
    
    else:  # Linux
        return os_info.get('name', 'Linux')


# Example usage
if __name__ == '__main__':
    """
    Example usage of OS detection.
    
    Run with: python detection.py
    """
    import sys
    
    # Test Linux detection
    print("=" * 70)
    print("Example 1: Linux Server Detection (SSH)")
    print("=" * 70)
    
    try:
        os_info = detect_server_os(
            hostname='linux-test.local',
            username='ubuntu',
            credential='password123'
        )
        
        print(f"✅ Detected: {os_info['type'].upper()}")
        print(f"   Name: {os_info['name']}")
        print(f"   Version: {os_info['version']}")
        print(f"   Architecture: {os_info['architecture']}")
        print(f"   Protocol: {os_info['protocol']}")
        print(f"   Port: {os_info['port']}")
        print(f"   Friendly: {get_os_version_friendly(os_info)}")
        
    except OSDetectionError as e:
        print(f"❌ Detection failed: {e}")
    
    # Test Windows detection
    print("\n" + "=" * 70)
    print("Example 2: Windows Server Detection (WinRM)")
    print("=" * 70)
    
    try:
        os_info = detect_server_os(
            hostname='windows-test.local',
            username='Administrator',
            credential='Password123!'
        )
        
        print(f"✅ Detected: {os_info['type'].upper()}")
        print(f"   Name: {os_info['name']}")
        print(f"   Version: {os_info['version']}")
        print(f"   Build: {os_info['build']}")
        print(f"   Architecture: {os_info['architecture']}")
        print(f"   Protocol: {os_info['protocol']}")
        print(f"   Port: {os_info['port']}")
        print(f"   SSL: {os_info['ssl']}")
        print(f"   Auth: {os_info['auth_used']}")
        print(f"   Domain: {os_info.get('domain', 'None')}")
        print(f"   Friendly: {get_os_version_friendly(os_info)}")
        
    except OSDetectionError as e:
        print(f"❌ Detection failed: {e}")
    
    # Test automatic fallback
    print("\n" + "=" * 70)
    print("Example 3: Automatic Protocol Detection")
    print("=" * 70)
    print("Tries SSH first, then WinRM automatically...")
    
    # This would try SSH on linux-test.local:22, then WinRM on 5985, then 5986
    # In real usage, provide actual test server details
