"""
Differential Audit Module

Parses audit execution output and compares results between runs to detect:
- New failures (issues that appeared since last run)
- Resolved issues (issues that were fixed)
- Status changes (severity escalations/de-escalations)
- Configuration drift over time
"""

import re
import json
from datetime import datetime
from typing import Dict, List, Optional, Tuple, NamedTuple
from dataclasses import dataclass, field
from enum import Enum


class CheckStatus(Enum):
    """Audit check status levels"""
    PASS = "PASS"  # nosec B105
    WARN = "WARN"
    FAIL = "FAIL"
    SKIP = "SKIP"

    @property
    def severity(self) -> int:
        """Numeric severity for comparison (higher = worse)"""
        return {"PASS": 0, "SKIP": 1, "WARN": 2, "FAIL": 3}.get(self.value, 0)  # nosec B105

    def __lt__(self, other):
        return self.severity < other.severity


@dataclass
class Finding:
    """Single audit finding/check result"""
    name: str
    status: CheckStatus
    message: str = ""
    section: str = ""  # Parent section if available

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "section": self.section
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Finding":
        return cls(
            name=data["name"],
            status=CheckStatus(data["status"]),
            message=data.get("message", ""),
            section=data.get("section", "")
        )


@dataclass
class DiffItem:
    """Single differential item showing change between runs"""
    check_name: str
    old_status: Optional[CheckStatus]
    new_status: Optional[CheckStatus]
    old_message: str = ""
    new_message: str = ""
    change_type: str = ""  # new_failure, resolved, escalated, deescalated, unchanged
    section: str = ""

    def to_dict(self) -> dict:
        return {
            "check_name": self.check_name,
            "old_status": self.old_status.value if self.old_status else None,
            "new_status": self.new_status.value if self.new_status else None,
            "old_message": self.old_message,
            "new_message": self.new_message,
            "change_type": self.change_type,
            "section": self.section
        }


@dataclass
class DiffResult:
    """Complete differential comparison result"""
    baseline_execution_id: int
    comparison_execution_id: int
    baseline_timestamp: datetime
    comparison_timestamp: datetime
    server_id: int
    audit_id: int

    # Change categories
    new_failures: List[DiffItem] = field(default_factory=list)
    resolved_issues: List[DiffItem] = field(default_factory=list)
    escalated: List[DiffItem] = field(default_factory=list)  # WARN -> FAIL
    deescalated: List[DiffItem] = field(default_factory=list)  # FAIL -> WARN
    unchanged_pass: List[DiffItem] = field(default_factory=list)
    unchanged_fail: List[DiffItem] = field(default_factory=list)
    unchanged_warn: List[DiffItem] = field(default_factory=list)
    new_checks: List[DiffItem] = field(default_factory=list)  # Not in baseline
    removed_checks: List[DiffItem] = field(default_factory=list)  # Not in comparison

    # Summary stats
    @property
    def total_changes(self) -> int:
        return len(self.new_failures) + len(self.resolved_issues) + \
               len(self.escalated) + len(self.deescalated)

    @property
    def drift_score(self) -> float:
        """
        Calculate drift score (0-100)
        Higher score = more significant drift from baseline
        """
        total_checks = sum([
            len(self.new_failures), len(self.resolved_issues),
            len(self.escalated), len(self.deescalated),
            len(self.unchanged_pass), len(self.unchanged_fail),
            len(self.unchanged_warn), len(self.new_checks),
            len(self.removed_checks)
        ])
        if total_checks == 0:
            return 0.0

        # Weight changes by severity
        weighted_changes = (
            len(self.new_failures) * 3 +  # New failures are bad
            len(self.escalated) * 2 +     # Escalations are concerning
            len(self.deescalated) * 0.5 + # De-escalations are neutral-good
            len(self.resolved_issues) * 0.2 +  # Resolutions are good
            len(self.new_checks) * 0.1 +  # New checks are informational
            len(self.removed_checks) * 0.5  # Removed checks may hide issues
        )
        return min(100.0, (weighted_changes / total_checks) * 100)

    @property
    def health_trend(self) -> str:
        """Determine overall health trend"""
        positive = len(self.resolved_issues) + len(self.deescalated)
        negative = len(self.new_failures) + len(self.escalated)

        if negative > positive:
            return "degrading"
        elif positive > negative:
            return "improving"
        else:
            return "stable"

    def to_dict(self) -> dict:
        return {
            "baseline_execution_id": self.baseline_execution_id,
            "comparison_execution_id": self.comparison_execution_id,
            "baseline_timestamp": self.baseline_timestamp.isoformat() if self.baseline_timestamp else None,
            "comparison_timestamp": self.comparison_timestamp.isoformat() if self.comparison_timestamp else None,
            "server_id": self.server_id,
            "audit_id": self.audit_id,
            "summary": {
                "total_changes": self.total_changes,
                "drift_score": round(self.drift_score, 1),
                "health_trend": self.health_trend,
                "new_failures": len(self.new_failures),
                "resolved_issues": len(self.resolved_issues),
                "escalated": len(self.escalated),
                "deescalated": len(self.deescalated),
                "unchanged_pass": len(self.unchanged_pass),
                "unchanged_fail": len(self.unchanged_fail),
                "unchanged_warn": len(self.unchanged_warn),
                "new_checks": len(self.new_checks),
                "removed_checks": len(self.removed_checks)
            },
            "changes": {
                "new_failures": [d.to_dict() for d in self.new_failures],
                "resolved_issues": [d.to_dict() for d in self.resolved_issues],
                "escalated": [d.to_dict() for d in self.escalated],
                "deescalated": [d.to_dict() for d in self.deescalated],
                "new_checks": [d.to_dict() for d in self.new_checks],
                "removed_checks": [d.to_dict() for d in self.removed_checks]
            },
            "unchanged": {
                "pass": [d.to_dict() for d in self.unchanged_pass],
                "fail": [d.to_dict() for d in self.unchanged_fail],
                "warn": [d.to_dict() for d in self.unchanged_warn]
            }
        }


class AuditOutputParser:
    """
    Parses audit shell script output to extract individual findings.

    Expected format from lib/common.sh register_check():
        [PASS] Check Name: message
        [FAIL] Check Name: message
        [WARN] Check Name: message
        [SKIP] Check Name: message

    Sections marked by:
        ============================================================
         Section Title
        ============================================================
    """

    # Regex patterns
    CHECK_PATTERN = re.compile(
        r'\[(?P<status>PASS|FAIL|WARN|SKIP)\]\s+(?P<name>[^:]+?)(?::\s*(?P<message>.+))?$',
        re.MULTILINE
    )

    SECTION_PATTERN = re.compile(
        r'={20,}\s*\n\s*(?P<title>[^\n=]+?)\s*\n\s*={20,}',
        re.MULTILINE
    )

    @classmethod
    def parse(cls, output: str) -> List[Finding]:
        """
        Parse audit output and extract all findings.

        Args:
            output: Raw stdout from audit script

        Returns:
            List of Finding objects
        """
        if not output:
            return []

        findings = []
        current_section = ""

        # First, extract section markers and their positions
        sections = []
        for match in cls.SECTION_PATTERN.finditer(output):
            sections.append((match.start(), match.group('title').strip()))

        # Parse all check results
        for match in cls.CHECK_PATTERN.finditer(output):
            pos = match.start()

            # Find which section this check belongs to
            for sec_pos, sec_title in reversed(sections):
                if sec_pos < pos:
                    current_section = sec_title
                    break

            try:
                status = CheckStatus(match.group('status'))
            except ValueError:
                continue

            name = match.group('name').strip()
            message = (match.group('message') or "").strip()

            findings.append(Finding(
                name=name,
                status=status,
                message=message,
                section=current_section
            ))

        return findings

    @classmethod
    def parse_to_dict(cls, output: str) -> Dict[str, Finding]:
        """
        Parse output and return findings keyed by check name.

        Args:
            output: Raw stdout from audit script

        Returns:
            Dict mapping check name to Finding
        """
        findings = cls.parse(output)
        # Use last occurrence if duplicate names (common for re-run scenarios)
        return {f.name: f for f in findings}


def compare_executions(
    baseline_output: str,
    comparison_output: str,
    baseline_id: int,
    comparison_id: int,
    baseline_timestamp: datetime,
    comparison_timestamp: datetime,
    server_id: int,
    audit_id: int
) -> DiffResult:
    """
    Compare two audit execution outputs and generate differential report.

    Args:
        baseline_output: Raw output from baseline (earlier) execution
        comparison_output: Raw output from comparison (later) execution
        baseline_id: Database ID of baseline execution
        comparison_id: Database ID of comparison execution
        baseline_timestamp: When baseline was executed
        comparison_timestamp: When comparison was executed
        server_id: Server ID
        audit_id: Audit ID

    Returns:
        DiffResult with categorized changes
    """
    parser = AuditOutputParser()

    baseline_findings = parser.parse_to_dict(baseline_output)
    comparison_findings = parser.parse_to_dict(comparison_output)

    result = DiffResult(
        baseline_execution_id=baseline_id,
        comparison_execution_id=comparison_id,
        baseline_timestamp=baseline_timestamp,
        comparison_timestamp=comparison_timestamp,
        server_id=server_id,
        audit_id=audit_id
    )

    # Get all unique check names
    all_checks = set(baseline_findings.keys()) | set(comparison_findings.keys())

    for check_name in all_checks:
        baseline = baseline_findings.get(check_name)
        comparison = comparison_findings.get(check_name)

        if baseline and comparison:
            # Check exists in both - compare status
            diff_item = DiffItem(
                check_name=check_name,
                old_status=baseline.status,
                new_status=comparison.status,
                old_message=baseline.message,
                new_message=comparison.message,
                section=comparison.section or baseline.section
            )

            if baseline.status == comparison.status:
                # Unchanged
                diff_item.change_type = "unchanged"
                if comparison.status == CheckStatus.PASS:
                    result.unchanged_pass.append(diff_item)
                elif comparison.status == CheckStatus.FAIL:
                    result.unchanged_fail.append(diff_item)
                elif comparison.status == CheckStatus.WARN:
                    result.unchanged_warn.append(diff_item)
            elif baseline.status == CheckStatus.PASS and comparison.status in (CheckStatus.FAIL, CheckStatus.WARN):
                # Was passing, now failing/warning = new failure
                diff_item.change_type = "new_failure"
                result.new_failures.append(diff_item)
            elif baseline.status in (CheckStatus.FAIL, CheckStatus.WARN) and comparison.status == CheckStatus.PASS:
                # Was failing/warning, now passing = resolved
                diff_item.change_type = "resolved"
                result.resolved_issues.append(diff_item)
            elif baseline.status == CheckStatus.WARN and comparison.status == CheckStatus.FAIL:
                # Warning escalated to failure
                diff_item.change_type = "escalated"
                result.escalated.append(diff_item)
            elif baseline.status == CheckStatus.FAIL and comparison.status == CheckStatus.WARN:
                # Failure de-escalated to warning
                diff_item.change_type = "deescalated"
                result.deescalated.append(diff_item)
            else:
                # Other status change (e.g., SKIP to PASS)
                if comparison.status.severity > baseline.status.severity:
                    diff_item.change_type = "escalated"
                    result.escalated.append(diff_item)
                else:
                    diff_item.change_type = "deescalated"
                    result.deescalated.append(diff_item)

        elif comparison and not baseline:
            # New check not in baseline
            result.new_checks.append(DiffItem(
                check_name=check_name,
                old_status=None,
                new_status=comparison.status,
                new_message=comparison.message,
                change_type="new_check",
                section=comparison.section
            ))
        elif baseline and not comparison:
            # Check removed (was in baseline, not in comparison)
            result.removed_checks.append(DiffItem(
                check_name=check_name,
                old_status=baseline.status,
                new_status=None,
                old_message=baseline.message,
                change_type="removed",
                section=baseline.section
            ))

    return result


def get_drift_timeline(
    executions: List[Tuple[int, datetime, str]],
    server_id: int,
    audit_id: int
) -> List[dict]:
    """
    Analyze drift over multiple executions to show timeline.

    Args:
        executions: List of (execution_id, timestamp, output) tuples, ordered by timestamp
        server_id: Server ID
        audit_id: Audit ID

    Returns:
        List of drift data points for timeline visualization
    """
    if len(executions) < 2:
        return []

    timeline = []

    for i in range(1, len(executions)):
        baseline_id, baseline_ts, baseline_output = executions[i-1]
        comparison_id, comparison_ts, comparison_output = executions[i]

        diff = compare_executions(
            baseline_output=baseline_output,
            comparison_output=comparison_output,
            baseline_id=baseline_id,
            comparison_id=comparison_id,
            baseline_timestamp=baseline_ts,
            comparison_timestamp=comparison_ts,
            server_id=server_id,
            audit_id=audit_id
        )

        timeline.append({
            "timestamp": comparison_ts.isoformat(),
            "execution_id": comparison_id,
            "drift_score": round(diff.drift_score, 1),
            "health_trend": diff.health_trend,
            "new_failures": len(diff.new_failures),
            "resolved": len(diff.resolved_issues),
            "escalated": len(diff.escalated),
            "deescalated": len(diff.deescalated),
            "total_changes": diff.total_changes
        })

    return timeline
