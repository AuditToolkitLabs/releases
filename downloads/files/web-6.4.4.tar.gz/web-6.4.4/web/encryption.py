#!/usr/bin/env python3
"""
Encryption Module

Provides secure password storage and SSH host key management:
- Password encryption/decryption using Fernet (symmetric encryption)
- SSH known_hosts file management
- Host key scanning and verification
"""

import logging
import os
import shutil
import subprocess  # nosec B404
from pathlib import Path

try:
    from cryptography.fernet import Fernet
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    print("WARNING: cryptography library not installed. Passwords will not be encrypted!")

logger = logging.getLogger(__name__)


class ServerPasswordManager:
    """
    Manages encrypted storage of SSH passwords

    Uses Fernet (symmetric encryption) with a key stored in .ssh/.key
    Key file permissions are restricted to 0o600 (owner read/write only)
    """

    def __init__(self, key_file, ssh_dir):
        """
        Initialize password manager

        Args:
            key_file: Path to encryption key file
            ssh_dir: SSH directory path
        """
        self.key_file = key_file or ssh_dir / ".key"
        self._cipher = None
        self._ensure_key()

    def _ensure_key(self):
        """Ensure encryption key exists, create if needed"""
        self.key_file.parent.mkdir(parents=True, exist_ok=True)

        if self.key_file.exists():
            try:
                with open(self.key_file, 'rb') as f:
                    key = f.read()
                self._cipher = Fernet(key) if ENCRYPTION_AVAILABLE else None
            except Exception as e:
                logger.error(f"Failed to load encryption key: {e}")
                self._cipher = None
        else:
            if not ENCRYPTION_AVAILABLE:
                logger.warning("Encryption not available - passwords will NOT be encrypted")
                return

            key = Fernet.generate_key()
            self.key_file.write_bytes(key)
            self._secure_key_file()  # MEDIUM-02 fix: platform-aware permissions
            self._cipher = Fernet(key)
            logger.info(f"Created new encryption key at {self.key_file}")

    def _secure_key_file(self):
        """
        Set secure file permissions on the key file (MEDIUM-02 fix)
        Platform-aware: uses icacls on Windows, chmod on Unix
        """
        import platform

        if platform.system() == 'Windows':
            try:
                # Remove inherited permissions and grant only current user read/write
                icacls_bin = shutil.which('icacls') or 'icacls'
                subprocess.run(
                    [icacls_bin, str(self.key_file), '/inheritance:r',
                     '/grant:r', f'{os.getlogin()}:(R,W)'],
                    check=True, capture_output=True
                )  # nosec B603
                logger.debug(f"Set Windows ACL on {self.key_file}")
            except Exception as e:
                logger.warning(f"Could not set Windows ACL on {self.key_file}: {e}")
        else:
            # Unix: standard chmod
            self.key_file.chmod(0o600)

    def encrypt_password(self, password):
        """
        Encrypt password for storage

        Args:
            password: Plain text password

        Returns:
            Encrypted password string

        Raises:
            RuntimeError: If encryption is not available (A02-01 OWASP fix)
        """
        # A02-01 OWASP fix: Fail secure - don't store passwords without encryption
        if not self._cipher:
            # Allow plaintext only if explicitly enabled (for testing/development)
            if os.environ.get('ALLOW_PLAINTEXT_PASSWORDS', 'false').lower() == 'true':
                logger.warning("SECURITY WARNING: Storing password in plaintext (ALLOW_PLAINTEXT_PASSWORDS=true)")
                return password
            logger.error("CRITICAL: Encryption not available - refusing to store password in plaintext")
            raise RuntimeError("Encryption required but not available. Install cryptography: pip install cryptography")

        if isinstance(password, str):
            password = password.encode()

        try:
            encrypted = self._cipher.encrypt(password)
            return encrypted.decode()
        except Exception as e:
            logger.error(f"Failed to encrypt password: {e}")
            raise RuntimeError(f"Password encryption failed: {e}") from e

    def decrypt_password(self, encrypted_password):
        """
        Decrypt password for use

        Args:
            encrypted_password: Encrypted password string

        Returns:
            Decrypted password string
        """
        if not self._cipher:
            return encrypted_password

        if isinstance(encrypted_password, str):
            encrypted_password = encrypted_password.encode()

        try:
            decrypted = self._cipher.decrypt(encrypted_password)
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Failed to decrypt password: {e}")
            # Return as-is if decryption fails (might not be encrypted)
            if isinstance(encrypted_password, bytes):
                return encrypted_password.decode()
            return encrypted_password


class SSHHostKeyManager:
    """
    Manages SSH known_hosts file for secure host verification

    Prevents man-in-the-middle attacks by verifying SSH host keys
    Uses ssh-keyscan to obtain host keys
    """

    def __init__(self, known_hosts_file):
        """
        Initialize SSH host key manager

        Args:
            known_hosts_file: Path to known_hosts file
        """
        self.known_hosts_file = known_hosts_file
        self._ensure_known_hosts()

    def _ensure_known_hosts(self):
        """Create known_hosts file if it doesn't exist"""
        self.known_hosts_file.parent.mkdir(parents=True, exist_ok=True)

        if not self.known_hosts_file.exists():
            self.known_hosts_file.touch(mode=0o600)
            logger.info(f"Created known_hosts file at {self.known_hosts_file}")
        else:
            # Ensure proper permissions
            self.known_hosts_file.chmod(0o600)

    def scan_host_key(self, host, port=22, timeout=10):
        """
        Scan and retrieve SSH host key using ssh-keyscan

        Args:
            host: Hostname or IP address
            port: SSH port (default: 22)
            timeout: Timeout in seconds

        Returns:
            Host key data string or None if scan fails
        """
        try:
            ssh_keyscan_bin = shutil.which('ssh-keyscan') or 'ssh-keyscan'
            result = subprocess.run(
                [ssh_keyscan_bin, '-p', str(port), '-t', 'rsa,ed25519', host],
                capture_output=True,
                text=True,
                timeout=timeout
            )  # nosec B603

            if result.returncode == 0 and result.stdout:
                logger.info(f"Successfully scanned SSH key from {host}:{port}")
                return result.stdout
            else:
                logger.warning(f"Failed to scan SSH key from {host}:{port}")
                return None
        except subprocess.TimeoutExpired:
            logger.error(f"Timeout scanning SSH key from {host}:{port}")
            return None
        except Exception as e:
            logger.error(f"Error scanning SSH key from {host}:{port}: {e}")
            return None

    def add_host_key(self, host, port=22):
        """
        Scan and add host key to known_hosts

        Args:
            host: Hostname or IP address
            port: SSH port (default: 22)

        Returns:
            True if successful, False otherwise
        """
        key_data = self.scan_host_key(host, port)
        if key_data:
            try:
                with open(self.known_hosts_file, 'a') as f:
                    f.write(key_data)
                logger.info(f"Added {host}:{port} to known_hosts")
                return True
            except Exception as e:
                logger.error(f"Failed to add host key to known_hosts: {e}")
                return False
        return False

    def host_known(self, host, port=22):
        """
        Check if host is in known_hosts

        Args:
            host: Hostname or IP address
            port: SSH port (default: 22)

        Returns:
            True if host is known, False otherwise
        """
        try:
            with open(self.known_hosts_file, 'r') as f:
                content = f.read()
                return f"[{host}]:{port}" in content or host in content
        except Exception:
            return False

    def remove_host(self, host, port=22):
        """
        Remove host from known_hosts

        Args:
            host: Hostname or IP address
            port: SSH port (default: 22)

        Returns:
            True if successful, False otherwise
        """
        try:
            with open(self.known_hosts_file, 'r') as f:
                lines = f.readlines()

            # Filter out lines containing the host
            filtered_lines = [
                line for line in lines
                if not (f"[{host}]:{port}" in line or (port == 22 and host in line))
            ]

            with open(self.known_hosts_file, 'w') as f:
                f.writelines(filtered_lines)

            logger.info(f"Removed {host}:{port} from known_hosts")
            return True
        except Exception as e:
            logger.error(f"Failed to remove host from known_hosts: {e}")
            return False


# ==============================================================================
# Module-level instances
# ==============================================================================

# Default paths relative to the writable data root when configured
from config import SSH_DIR as CONFIG_SSH_DIR

_SSH_DIR = CONFIG_SSH_DIR
_KEY_FILE = _SSH_DIR / '.key'
_KNOWN_HOSTS_FILE = _SSH_DIR / 'known_hosts'

# Module-level password manager instance
password_manager = ServerPasswordManager(key_file=_KEY_FILE, ssh_dir=_SSH_DIR)


def encrypt_data(value):
    """Encrypt arbitrary string data using the shared password manager."""
    if value is None:
        return None
    return password_manager.encrypt_password(value)


def decrypt_data(value):
    """Decrypt arbitrary string data using the shared password manager."""
    if value is None:
        return None
    return password_manager.decrypt_password(value)

# Module-level SSH host key manager instance
ssh_host_key_manager = SSHHostKeyManager(known_hosts_file=_KNOWN_HOSTS_FILE)


__all__ = [
    'ServerPasswordManager',
    'SSHHostKeyManager',
    'ENCRYPTION_AVAILABLE',
    'encrypt_data',
    'decrypt_data',
    'password_manager',
    'ssh_host_key_manager',
]
