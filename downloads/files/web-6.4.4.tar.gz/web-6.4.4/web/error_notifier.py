#!/usr/bin/env python3
"""
Error Notification System

Sends notifications when tasks fail:
- Email alerts for critical failures
- Webhook notifications for integrations
- Slack/Teams/Discord support
- Rate limiting to prevent notification storms

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import logging
import json
import socket
import ipaddress
import sys
from datetime import datetime, timedelta
from email.message import EmailMessage
from pathlib import Path
from typing import Optional, Dict, Any
from threading import Lock
from urllib.parse import urlparse
import requests

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from mail_delivery import MailDeliveryError, send_email_message, load_mail_delivery_config_from_settings

# Import comprehensive SSRF protection module
try:
    from validators_network import validate_url as validate_ssrf_url
    ENHANCED_SSRF = True
except ImportError:
    ENHANCED_SSRF = False

logger = logging.getLogger(__name__)


def is_safe_webhook_url(url: str) -> bool:
    """
    Validate webhook URL to prevent SSRF attacks.
    Blocks requests to private/internal IP ranges and cloud metadata endpoints.

    Uses enhanced SSRF protection from validators_network.py if available.
    """
    # Use enhanced SSRF protection if available
    if ENHANCED_SSRF:
        is_valid, error_msg, _ = validate_ssrf_url(url, dns_resolve=True)
        if not is_valid:
            logger.warning(f"SSRF protection: {error_msg}")
        return is_valid

    # Fallback to basic SSRF protection
    try:
        parsed = urlparse(url)

        # Only allow http/https schemes
        if parsed.scheme not in ('http', 'https'):
            return False

        hostname = parsed.hostname
        if not hostname:
            return False

        # Resolve hostname to IP
        try:
            ip_str = socket.gethostbyname(hostname)
            ip_obj = ipaddress.ip_address(ip_str)

            # Block private, loopback, link-local, and reserved IPs
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_reserved:
                logger.warning(f"SSRF protection: Blocked webhook to internal IP: {url}")
                return False

        except socket.gaierror:
            return True  # Allow unresolvable hostnames

        return True

    except Exception:
        return False


class NotificationRateLimiter:
    """
    Rate limiter for notifications to prevent storms

    Tracks notification frequency per service/error type
    and throttles repeated notifications.
    """

    def __init__(self, max_notifications: int = 5, window_seconds: int = 3600):
        """
        Initialize rate limiter

        Args:
            max_notifications: Max notifications per window
            window_seconds: Time window in seconds (default 1 hour)
        """
        self.max_notifications = max_notifications
        self.window_seconds = window_seconds
        self._notification_history: Dict[str, list] = {}
        self._lock = Lock()

    def should_notify(self, key: str) -> bool:
        """
        Check if notification should be sent

        Args:
            key: Notification identifier (e.g., "task:execute_audit:server123")

        Returns:
            bool: True if notification should be sent
        """
        with self._lock:
            now = datetime.utcnow()

            # Get notification history for this key
            if key not in self._notification_history:
                self._notification_history[key] = []

            # Remove old notifications outside window
            cutoff = now - timedelta(seconds=self.window_seconds)
            self._notification_history[key] = [
                ts for ts in self._notification_history[key]
                if ts > cutoff
            ]

            # Check if under limit
            if len(self._notification_history[key]) < self.max_notifications:
                self._notification_history[key].append(now)
                return True

            logger.warning(
                f"Notification rate limit exceeded for {key}: "
                f"{len(self._notification_history[key])}/{self.max_notifications} "
                f"in {self.window_seconds}s window"
            )
            return False

    def reset(self, key: Optional[str] = None):
        """Reset rate limiter for specific key or all keys"""
        with self._lock:
            if key:
                self._notification_history.pop(key, None)
            else:
                self._notification_history.clear()


class ErrorNotifier:
    """
    Error notification system

    Sends alerts via:
    - Email (SMTP)
    - Webhooks (HTTP POST)
    - Slack
    - Microsoft Teams
    - Discord
    """

    def __init__(self):
        """Initialize error notifier from environment variables"""
        # Email configuration
        self.email_enabled = os.getenv('ERROR_NOTIFICATIONS_EMAIL_ENABLED', 'false').lower() == 'true'
        self.smtp_host = os.getenv('SMTP_HOST', 'localhost')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.smtp_user = os.getenv('SMTP_USER', '')
        self.smtp_password = os.getenv('SMTP_PASSWORD', '')
        self.smtp_from = os.getenv('SMTP_FROM', 'audit-toolkit@localhost')
        self.alert_email_to = os.getenv('ALERT_EMAIL_TO', '')

        # Webhook configuration
        self.webhook_enabled = os.getenv('ERROR_NOTIFICATIONS_WEBHOOK_ENABLED', 'false').lower() == 'true'
        self.webhook_url = os.getenv('ERROR_NOTIFICATION_WEBHOOK_URL', '')

        # Slack configuration
        self.slack_enabled = os.getenv('ERROR_NOTIFICATIONS_SLACK_ENABLED', 'false').lower() == 'true'
        self.slack_webhook_url = os.getenv('SLACK_WEBHOOK_URL', '')

        # Rate limiting
        self.rate_limiter = NotificationRateLimiter(
            max_notifications=int(os.getenv('NOTIFICATION_MAX_PER_HOUR', '5')),
            window_seconds=int(os.getenv('NOTIFICATION_WINDOW_SECONDS', '3600'))
        )

        logger.info(
            "Error notifier initialized: "
            f"email={self.email_enabled}, webhook={self.webhook_enabled}, slack={self.slack_enabled}"
        )

    def notify_task_failure(
        self,
        task_id: str,
        task_name: str,
        error_message: str,
        retry_count: int,
        max_retries: int,
        server_name: Optional[str] = None,
        audit_name: Optional[str] = None,
        added_to_dlq: bool = False
    ):
        """
        Send notification about task failure

        Args:
            task_id: Celery task ID
            task_name: Task name
            error_message: Error message
            retry_count: Current retry count
            max_retries: Maximum retries
            server_name: Server name (if applicable)
            audit_name: Audit name (if applicable)
            added_to_dlq: True if task added to dead letter queue
        """
        # Build notification key for rate limiting
        notification_key = f"task:{task_name}:{server_name or 'unknown'}"

        # Check rate limit
        if not self.rate_limiter.should_notify(notification_key):
            logger.debug(f"Notification rate limited for {notification_key}")
            return

        # Build notification message
        subject = f"❌ Task Failure: {task_name}"
        if added_to_dlq:
            subject = f"🚨 Task Failed - Dead Letter Queue: {task_name}"

        body_parts = [
            f"Task: {task_name}",
            f"Task ID: {task_id}",
            f"Status: {'Added to Dead Letter Queue' if added_to_dlq else 'Retry Pending'}",
            f"Retries: {retry_count}/{max_retries}",
        ]

        if server_name:
            body_parts.append(f"Server: {server_name}")
        if audit_name:
            body_parts.append(f"Audit: {audit_name}")

        body_parts.extend([
            f"Error: {error_message[:500]}",
            f"Time: {datetime.utcnow().isoformat()}Z"
        ])

        body = "\n".join(body_parts)

        # Send notifications
        self._send_email(subject, body)
        self._send_webhook(subject, body, {
            'task_id': task_id,
            'task_name': task_name,
            'retry_count': retry_count,
            'max_retries': max_retries,
            'added_to_dlq': added_to_dlq,
            'server_name': server_name,
            'audit_name': audit_name,
            'error_message': error_message
        })
        self._send_slack(subject, body, added_to_dlq)

    def notify_circuit_breaker_open(
        self,
        service_name: str,
        failure_count: int,
        reset_time: datetime
    ):
        """
        Send notification when circuit breaker opens

        Args:
            service_name: Service name
            failure_count: Number of failures
            reset_time: When circuit will retry
        """
        notification_key = f"circuit_breaker:{service_name}"

        if not self.rate_limiter.should_notify(notification_key):
            return

        subject = f"⚡ Circuit Breaker Open: {service_name}"
        body = (
            f"Circuit breaker has opened for: {service_name}\n"
            f"Failure count: {failure_count}\n"
            f"Will retry at: {reset_time.isoformat()}Z\n"
            f"Time: {datetime.utcnow().isoformat()}Z"
        )

        self._send_email(subject, body)
        self._send_webhook(subject, body, {
            'service_name': service_name,
            'failure_count': failure_count,
            'reset_time': reset_time.isoformat()
        })
        self._send_slack(subject, body, critical=True)

    def _load_email_settings(self) -> dict:
        """Load email settings from settings.json; fall back to env vars if unavailable."""
        try:
            settings_file = Path(__file__).resolve().parent / "settings.json"
            if settings_file.exists():
                data = json.loads(settings_file.read_text())
                email = data.get("email", {})
                if email:
                    return email
        except Exception as exc:
            logger.debug(f"Could not load settings.json for email config: {exc}")
        return {
            "enabled": self.email_enabled,
            "transport": "smtp",
            "smtp_host": self.smtp_host,
            "smtp_port": self.smtp_port,
            "smtp_user": self.smtp_user,
            "smtp_password": self.smtp_password,
            "from_address": self.smtp_from,
            "to_address": self.alert_email_to,
        }

    def _send_email(self, subject: str, body: str):
        """Send email notification using transport configured in admin panel or env vars."""
        try:
            email_settings = self._load_email_settings()
            if not email_settings.get("enabled", False):
                return
            to_addr = email_settings.get("to_address") or self.alert_email_to
            if not to_addr:
                return
            transport = email_settings.get("transport", "smtp")
            from_addr = (
                email_settings.get("graph_from_address") if transport == "graph" else None
            ) or email_settings.get("from_address") or self.smtp_from

            config = load_mail_delivery_config_from_settings(email_settings)

            msg = EmailMessage()
            msg["From"] = from_addr
            msg["To"] = to_addr
            msg["Subject"] = subject
            msg.set_content(body)

            send_email_message(msg, config)
            logger.info(f"Email notification sent: {subject}")

        except MailDeliveryError as e:
            logger.error(f"Failed to send email notification: {e}")
        except Exception as e:
            logger.error(f"Failed to send email notification: {e}")

    def _send_webhook(self, subject: str, body: str, data: dict):
        """Send webhook notification"""
        if not self.webhook_enabled or not self.webhook_url:
            return

        try:
            # SSRF protection
            if not is_safe_webhook_url(self.webhook_url):
                logger.error(f"Webhook URL blocked by SSRF protection: {self.webhook_url}")
                return

            payload = {
                'subject': subject,
                'message': body,
                'data': data,
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }

            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=10,
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()

            logger.info(f"Webhook notification sent: {subject}")

        except Exception as e:
            logger.error(f"Failed to send webhook notification: {e}")

    def _send_slack(self, subject: str, body: str, critical: bool = False):
        """Send Slack notification"""
        if not self.slack_enabled or not self.slack_webhook_url:
            return

        try:
            # SSRF protection
            if not is_safe_webhook_url(self.slack_webhook_url):
                logger.error("Slack webhook URL blocked by SSRF protection")
                return

            # Format for Slack
            color = 'danger' if critical else 'warning'

            payload = {
                'attachments': [{
                    'color': color,
                    'title': subject,
                    'text': body,
                    'ts': int(datetime.utcnow().timestamp())
                }]
            }

            response = requests.post(
                self.slack_webhook_url,
                json=payload,
                timeout=10
            )
            response.raise_for_status()

            logger.info(f"Slack notification sent: {subject}")

        except Exception as e:
            logger.error(f"Failed to send Slack notification: {e}")


# Global notifier instance
_error_notifier: Optional[ErrorNotifier] = None


def get_error_notifier() -> ErrorNotifier:
    """Get global error notifier instance"""
    global _error_notifier
    if _error_notifier is None:
        _error_notifier = ErrorNotifier()
    return _error_notifier
