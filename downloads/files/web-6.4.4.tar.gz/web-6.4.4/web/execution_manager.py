"""
Execution Manager - Protocol Abstraction for Cross-Platform Audits

This module provides a unified interface for executing audit scripts on both
Linux (via SSH) and Windows (via WinRM) servers.

Architecture:
- ExecutionResult: Standardized result format across protocols
- ExecutorBase: Abstract base class defining executor interface
- SSHExecutor: Linux/Unix execution via SSH (existing functionality)
- WinRMExecutor: Windows execution via PowerShell Remoting
- ExecutionManager: Factory pattern for protocol selection

Usage:
    from execution_manager import ExecutionManager
    
    # Automatic protocol selection based on server.os_type
    result = ExecutionManager.execute_audit(
        server=server,
        audit_path='audits/platform/baseline/updates.sh',  # or .ps1
        args=['--verbose']
    )
    
    print(f"Exit code: {result.exit_code}")
    print(f"Output: {result.stdout}")
    print(f"Duration: {result.duration_ms}ms")
"""

import time
import logging
import os
import shlex
from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any
import paramiko
from pypsrp.client import Client
from pypsrp.powershell import PowerShell, RunspacePool
from pypsrp.wsman import WSMan

logger = logging.getLogger(__name__)


def _contains_unsafe_shell_tokens(value: str) -> bool:
    """Return True when shell argument contains control characters unsafe for remote execution."""
    if not isinstance(value, str):
        return True
    disallowed_tokens = ('\x00', '\n', '\r')
    return any(token in value for token in disallowed_tokens)


def _resolve_ssh_host_key_policy() -> paramiko.MissingHostKeyPolicy:
    """Resolve SSH host key policy for remote audit execution."""
    policy_mode = os.getenv('ATK_SSH_HOST_KEY_POLICY', '').strip().lower()
    if not policy_mode:
        environment = (os.getenv('FLASK_ENV') or os.getenv('ENVIRONMENT') or '').strip().lower()
        policy_mode = 'warning' if environment in {'development', 'dev', 'test', 'local'} else 'reject'

    if policy_mode == 'warning':
        return paramiko.WarningPolicy()

    return paramiko.RejectPolicy()


def _build_safe_bash_command(script_path: str, args: Optional[List[str]] = None) -> str:
    """Build a shell-safe bash command for SSH execution."""
    if _contains_unsafe_shell_tokens(script_path):
        raise ValueError('Unsafe script path content blocked for SSH execution')

    cmd_parts = ['bash', script_path]
    for arg in args or []:
        arg_text = str(arg)
        if _contains_unsafe_shell_tokens(arg_text):
            raise ValueError(f'Unsafe argument content blocked for SSH execution: {arg_text!r}')
        cmd_parts.append(arg_text)

    return ' '.join(shlex.quote(part) for part in cmd_parts)


class ExecutionResult:
    """
    Standardized execution result across all protocols (SSH and WinRM).
    
    Both Linux Bash scripts and Windows PowerShell scripts output the same
    markers: [PASS], [WARN], [FAIL], [SKIP], which are parsed identically.
    """
    
    def __init__(
        self,
        exit_code: int,
        stdout: str,
        stderr: str,
        duration_ms: int,
        protocol: str = 'unknown'
    ):
        """
        Initialize execution result.
        
        Args:
            exit_code: 0 = PASS, 1 = WARN, 2 = FAIL (convention from Bash scripts)
            stdout: Standard output containing audit markers
            stderr: Standard error (warnings/errors)
            duration_ms: Execution time in milliseconds
            protocol: 'ssh' or 'winrm'
        """
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr
        self.duration_ms = duration_ms
        self.protocol = protocol
        self.success = (exit_code == 0)  # 0 = PASS only
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'exit_code': self.exit_code,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'duration_ms': self.duration_ms,
            'protocol': self.protocol,
            'success': self.success
        }
    
    def __repr__(self):
        status = 'SUCCESS' if self.success else 'FAILURE'
        return (f"ExecutionResult(status={status}, exit_code={self.exit_code}, "
                f"protocol={self.protocol}, duration={self.duration_ms}ms)")


class ExecutorBase(ABC):
    """
    Abstract base class for all execution protocols.
    
    Subclasses must implement: connect(), execute_script(), disconnect(), test_connection()
    """
    
    def __init__(self, server):
        """
        Initialize executor with server configuration.
        
        Args:
            server: Server model instance with hostname, credentials, os_type, etc.
        """
        self.server = server
        self.connected = False
    
    @abstractmethod
    def connect(self) -> None:
        """Establish connection to remote server."""
        pass
    
    @abstractmethod
    def execute_script(
        self,
        script_path: str,
        args: Optional[List[str]] = None
    ) -> ExecutionResult:
        """
        Execute audit script on remote server.
        
        Args:
            script_path: Path to audit script (e.g., 'audits/linux/platform/baseline/updates.sh')
            args: Optional command-line arguments
        
        Returns:
            ExecutionResult with stdout, stderr, exit code, duration
        """
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Close connection to remote server."""
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """
        Test if connection is alive.
        
        Returns:
            True if connection is active, False otherwise
        """
        pass
    
    def __enter__(self):
        """Context manager entry: connect to server."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit: disconnect from server."""
        self.disconnect()


class SSHExecutor(ExecutorBase):
    """
    Execute audits via SSH on Linux/Unix servers.
    
    Uses paramiko for SSH connectivity. Supports both password and SSH key authentication.
    """
    
    def __init__(self, server):
        """
        Initialize SSH executor.
        
        Args:
            server: Server model with hostname, username, ssh_key or password
        """
        super().__init__(server)
        self.ssh = None
    
    def connect(self) -> None:
        """Establish SSH connection using paramiko."""
        try:
            self.ssh = paramiko.SSHClient()
            self.ssh.load_system_host_keys()

            extra_known_hosts = os.getenv('ATK_SSH_KNOWN_HOSTS_FILE', '').strip()
            if extra_known_hosts:
                try:
                    self.ssh.load_host_keys(extra_known_hosts)
                except Exception as e:
                    logger.warning(f"Failed to load SSH known hosts from {extra_known_hosts}: {e}")

            self.ssh.set_missing_host_key_policy(_resolve_ssh_host_key_policy())
            
            # Determine authentication method
            if self.server.ssh_key:
                # SSH key authentication (preferred)
                logger.info(f"Connecting to {self.server.hostname} via SSH (key auth)")
                self.ssh.connect(
                    hostname=self.server.hostname,
                    port=self.server.connection_port or 22,
                    username=self.server.username,
                    key_filename=self.server.ssh_key,
                    timeout=10
                )
            elif self.server.password:
                # Password authentication
                logger.info(f"Connecting to {self.server.hostname} via SSH (password auth)")
                self.ssh.connect(
                    hostname=self.server.hostname,
                    port=self.server.connection_port or 22,
                    username=self.server.username,
                    password=self.server.password,
                    timeout=10
                )
            else:
                raise ValueError("Server must have either ssh_key or password")
            
            self.connected = True
            logger.info(f"SSH connection established to {self.server.hostname}")
            
        except Exception as e:
            logger.error(f"SSH connection failed to {self.server.hostname}: {e}")
            raise
    
    def execute_script(
        self,
        script_path: str,
        args: Optional[List[str]] = None
    ) -> ExecutionResult:
        """
        Execute Bash audit script via SSH.
        
        Args:
            script_path: Path to .sh script (e.g., 'audits/linux/platform/baseline/updates.sh')
            args: Optional arguments to pass to script
        
        Returns:
            ExecutionResult with output and exit code
        """
        if not self.connected:
            raise RuntimeError("Not connected. Call connect() first.")
        
        start_time = time.time()
        
        try:
            command = _build_safe_bash_command(script_path, args)
            
            logger.debug(f"Executing on {self.server.hostname}: {command}")
            
            # Execute command
            stdin, stdout, stderr = self.ssh.exec_command(command, timeout=300)  # nosec B601 - command is shell-quoted and validated by _build_safe_bash_command
            
            # Read output
            stdout_text = stdout.read().decode('utf-8', errors='replace')
            stderr_text = stderr.read().decode('utf-8', errors='replace')
            exit_code = stdout.channel.recv_exit_status()
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            logger.info(f"SSH execution completed: exit={exit_code}, duration={duration_ms}ms")
            
            return ExecutionResult(
                exit_code=exit_code,
                stdout=stdout_text,
                stderr=stderr_text,
                duration_ms=duration_ms,
                protocol='ssh'
            )
            
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(f"SSH execution failed on {self.server.hostname}: {e}")
            
            return ExecutionResult(
                exit_code=255,  # SSH error convention
                stdout='',
                stderr=str(e),
                duration_ms=duration_ms,
                protocol='ssh'
            )
    
    def disconnect(self) -> None:
        """Close SSH connection."""
        if self.ssh:
            self.ssh.close()
            self.connected = False
            logger.info(f"SSH connection closed to {self.server.hostname}")
    
    def test_connection(self) -> bool:
        """Test if SSH connection is alive."""
        if not self.ssh or not self.connected:
            return False
        
        try:
            # Try a simple command
            transport = self.ssh.get_transport()
            return transport and transport.is_active()
        except:
            return False


class WinRMExecutor(ExecutorBase):
    """
    Execute audits via WinRM (PowerShell Remoting) on Windows servers.
    
    Uses pypsrp for PowerShell Remoting Protocol. Supports NTLM, Basic, Kerberos auth.
    """
    
    def __init__(self, server):
        """
        Initialize WinRM executor.
        
        Args:
            server: Server model with hostname, username, password, domain (optional)
        """
        super().__init__(server)
        self.client = None
        self.wsman = None
    
    def connect(self) -> None:
        """Establish WinRM connection using pypsrp."""
        try:
            # Determine port and SSL
            port = self.server.connection_port or 5985
            use_ssl = (port == 5986)
            
            # Determine authentication method
            # Priority: Kerberos (domain) > NTLM (domain) > Basic (local)
            auth_method = 'ntlm'  # Default
            username = self.server.username
            
            if self.server.domain:
                # Domain account: use NTLM or Kerberos
                username = f"{self.server.domain}\\{self.server.username}"
                # Try Kerberos if available, fall back to NTLM
                auth_method = 'ntlm'  # For now; Kerberos support in Phase 5
            
            logger.info(f"Connecting to {self.server.hostname} via WinRM "
                       f"(port={port}, ssl={use_ssl}, auth={auth_method})")
            
            # Create WinRM client
            self.wsman = WSMan(
                server=self.server.hostname,
                username=username,
                password=self.server.password,
                port=port,
                ssl=use_ssl,
                auth=auth_method,
                cert_validation=False  # Allow self-signed certs (development)
                # TODO: Phase 5 - Use proper certificate validation in production
            )
            
            # Test connection with simple command
            with RunspacePool(self.wsman) as pool:
                ps = PowerShell(pool)
                ps.add_cmdlet('Get-Host')
                output = ps.invoke()
                
                if ps.had_errors:
                    raise Exception(f"PowerShell test failed: {ps.streams.error}")
            
            self.connected = True
            logger.info(f"WinRM connection established to {self.server.hostname}")
            
        except Exception as e:
            logger.error(f"WinRM connection failed to {self.server.hostname}: {e}")
            raise
    
    def execute_script(
        self,
        script_path: str,
        args: Optional[List[str]] = None
    ) -> ExecutionResult:
        """
        Execute PowerShell audit script via WinRM.
        
        Args:
            script_path: Path to .ps1 script (e.g., 'audits/windows/platform/baseline/updates.ps1')
            args: Optional arguments to pass to script
        
        Returns:
            ExecutionResult with output and exit code
        """
        if not self.connected:
            raise RuntimeError("Not connected. Call connect() first.")
        
        start_time = time.time()
        
        try:
            # Read script content (scripts are on audit server, not Windows target)
            with open(script_path, 'r', encoding='utf-8') as f:
                script_content = f.read()
            
            logger.debug(f"Executing on {self.server.hostname}: {script_path}")
            
            # Execute PowerShell script remotely
            with RunspacePool(self.wsman) as pool:
                ps = PowerShell(pool)
                
                # Add script
                ps.add_script(script_content)
                
                # Add arguments if provided
                if args:
                    for arg in args:
                        ps.add_argument(arg)
                
                # Execute
                output = ps.invoke()
                
                # Collect output
                stdout_parts = []
                for item in output:
                    stdout_parts.append(str(item))
                
                stderr_parts = []
                if ps.streams.error:
                    for error in ps.streams.error:
                        stderr_parts.append(str(error))
                
                stdout_text = '\n'.join(stdout_parts)
                stderr_text = '\n'.join(stderr_parts)
                
                # Determine exit code from PowerShell $LASTEXITCODE or errors
                exit_code = 0
                if ps.had_errors:
                    exit_code = 2  # FAIL
                elif '[WARN]' in stdout_text:
                    exit_code = 1  # WARN
                elif '[FAIL]' in stdout_text:
                    exit_code = 2  # FAIL
                
                duration_ms = int((time.time() - start_time) * 1000)
                
                logger.info(f"WinRM execution completed: exit={exit_code}, duration={duration_ms}ms")
                
                return ExecutionResult(
                    exit_code=exit_code,
                    stdout=stdout_text,
                    stderr=stderr_text,
                    duration_ms=duration_ms,
                    protocol='winrm'
                )
                
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(f"WinRM execution failed on {self.server.hostname}: {e}")
            
            return ExecutionResult(
                exit_code=255,  # Execution error
                stdout='',
                stderr=str(e),
                duration_ms=duration_ms,
                protocol='winrm'
            )
    
    def disconnect(self) -> None:
        """Close WinRM connection."""
        if self.wsman:
            # pypsrp uses context managers; no explicit close needed
            self.wsman = None
            self.connected = False
            logger.info(f"WinRM connection closed to {self.server.hostname}")
    
    def test_connection(self) -> bool:
        """Test if WinRM connection is alive."""
        if not self.wsman or not self.connected:
            return False
        
        try:
            # Try a simple PowerShell command
            with RunspacePool(self.wsman) as pool:
                ps = PowerShell(pool)
                ps.add_cmdlet('Get-Date')
                output = ps.invoke()
                return not ps.had_errors
        except:
            return False


class ExecutionManager:
    """
    Factory for execution protocol selection.
    
    Automatically selects SSHExecutor (Linux) or WinRMExecutor (Windows) based on
   server.os_type field.
    
    Usage:
        # Method 1: Factory pattern
        executor = ExecutionManager.get_executor(server)
        executor.connect()
        result = executor.execute_script('path/to/script.sh')
        executor.disconnect()
        
        # Method 2: Context manager (preferred)
        with ExecutionManager.get_executor(server) as executor:
            result = executor.execute_script('path/to/script.sh')
        
        # Method 3: One-shot execution
        result = ExecutionManager.execute_audit(server, 'path/to/script.sh')
    """
    
    @staticmethod
    def get_executor(server) -> ExecutorBase:
        """
        Get appropriate executor for server OS type.
        
        Args:
            server: Server model instance with os_type field
        
        Returns:
            SSHExecutor for Linux, WinRMExecutor for Windows
        
        Raises:
            ValueError: If os_type is not recognized
        """
        os_type = server.os_type.lower() if server.os_type else 'linux'
        
        if os_type == 'windows':
            logger.debug(f"Creating WinRMExecutor for {server.hostname}")
            return WinRMExecutor(server)
        elif os_type in ['linux', 'unix', 'bsd']:
            logger.debug(f"Creating SSHExecutor for {server.hostname}")
            return SSHExecutor(server)
        else:
            raise ValueError(f"Unsupported OS type: {os_type}")
    
    @staticmethod
    def execute_audit(
        server,
        audit_path: str,
        args: Optional[List[str]] = None
    ) -> ExecutionResult:
        """
        One-shot audit execution with automatic protocol selection.
        
        Connects, executes script, disconnects, and returns result.
        
        Args:
            server: Server model instance
            audit_path: Path to audit script (.sh or .ps1)
            args: Optional command-line arguments
        
        Returns:
            ExecutionResult with execution outcome
        """
        executor = ExecutionManager.get_executor(server)
        
        try:
            executor.connect()
            result = executor.execute_script(audit_path, args)
            return result
        finally:
            executor.disconnect()
    
    @staticmethod
    def test_server_connection(server) -> Dict[str, Any]:
        """
        Test connection to server without executing audit.
        
        Args:
            server: Server model instance
        
        Returns:
            Dictionary with connection test results:
            {
                'success': bool,
                'protocol': 'ssh' or 'winrm',
                'duration_ms': int,
                'error': str (if success=False)
            }
        """
        start_time = time.time()
        
        try:
            executor = ExecutionManager.get_executor(server)
            executor.connect()
            is_alive = executor.test_connection()
            executor.disconnect()
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            return {
                'success': is_alive,
                'protocol': 'winrm' if server.os_type == 'windows' else 'ssh',
                'duration_ms': duration_ms,
                'error': None
            }
            
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            
            return {
                'success': False,
                'protocol': 'winrm' if server.os_type == 'windows' else 'ssh',
                'duration_ms': duration_ms,
                'error': str(e)
            }


# Example usage
if __name__ == '__main__':
    """
    Example usage of ExecutionManager.
    
    This demonstrates both SSH (Linux) and WinRM (Windows) execution.
    """
    import sys
    
    # Mock server objects for demonstration
    class MockLinuxServer:
        hostname = 'linux-test.local'
        username = 'ubuntu'
        password = os.getenv('ATK_EXAMPLE_LINUX_PASSWORD')
        ssh_key = None
        os_type = 'linux'
        connection_port = 22
        domain = None
    
    class MockWindowsServer:
        hostname = 'windows-test.local'
        username = 'Administrator'
        password = os.getenv('ATK_EXAMPLE_WINDOWS_PASSWORD')
        ssh_key = None
        os_type = 'windows'
        connection_port = 5985
        domain = None
    
    # Example 1: Linux server
    print("=" * 60)
    print("Example 1: Linux Server (SSH)")
    print("=" * 60)
    
    linux_server = MockLinuxServer()
    
    try:
        result = ExecutionManager.execute_audit(
            server=linux_server,
            audit_path='audits/linux/platform/baseline/updates.sh'
        )
        
        print(f"Exit code: {result.exit_code}")
        print(f"Success: {result.success}")
        print(f"Protocol: {result.protocol}")
        print(f"Duration: {result.duration_ms}ms")
        print(f"Output:\n{result.stdout[:500]}")  # First 500 chars
        
    except Exception as e:
        print(f"ERROR: {e}")
    
    # Example 2: Windows server
    print("\n" + "=" * 60)
    print("Example 2: Windows Server (WinRM)")
    print("=" * 60)
    
    windows_server = MockWindowsServer()
    
    try:
        result = ExecutionManager.execute_audit(
            server=windows_server,
            audit_path='audits/windows/platform/baseline/updates.ps1'
        )
        
        print(f"Exit code: {result.exit_code}")
        print(f"Success: {result.success}")
        print(f"Protocol: {result.protocol}")
        print(f"Duration: {result.duration_ms}ms")
        print(f"Output:\n{result.stdout[:500]}")
        
    except Exception as e:
        print(f"ERROR: {e}")
    
    # Example 3: Connection test
    print("\n" + "=" * 60)
    print("Example 3: Connection Test")
    print("=" * 60)
    
    for server in [linux_server, windows_server]:
        test_result = ExecutionManager.test_server_connection(server)
        
        print(f"\nServer: {server.hostname}")
        print(f"Protocol: {test_result['protocol']}")
        print(f"Success: {test_result['success']}")
        print(f"Duration: {test_result['duration_ms']}ms")
        
        if not test_result['success']:
            print(f"Error: {test_result['error']}")
