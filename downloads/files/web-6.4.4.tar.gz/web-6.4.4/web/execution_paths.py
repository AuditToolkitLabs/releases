#!/usr/bin/env python3
"""
Execution Paths - Deployment path constants for agentless vs deployed modes

Defines standard installation paths for Linux and Windows targets:
- Stream mode: No deployment required, scripts sent via SSH stdin/WinRM
- Deployed mode: Scripts pre-installed at standard paths

Author: Security Audit Toolkit Team
Date: February 16, 2026
"""

# Linux deployment paths (DEB/RPM packages)
LINUX_DEPLOY_PATH = "/opt/audit-toolkit"
LINUX_COMMAND_PREFIX = "audit-toolkit"  # Wrapper at /usr/local/bin/audit-toolkit

# Windows deployment paths (MSI installer)
WINDOWS_DEPLOY_PATH = r"C:\Program Files\SecurityAuditToolkit"
WINDOWS_COMMAND_PREFIX = r"C:\Program Files\SecurityAuditToolkit\orchestrator\Run-WindowsAudits.ps1"

# Orchestrator scripts
LINUX_ORCHESTRATOR = "orchestrator/orchestrator.sh"
WINDOWS_ORCHESTRATOR = r"audits\windows\Run-WindowsAudits.ps1"

# Default execution mode (stream = agentless, deployed = requires package)
DEFAULT_EXECUTION_MODE = "stream"  # 'stream' or 'deployed'


def get_deployed_command(audit_path: str, os_type: str = "linux") -> str:
    """
    Build command for deployed mode execution

    Args:
        audit_path: Relative path to audit script (e.g., audits/platform/baseline/updates.sh)
        os_type: Target OS type ('linux' or 'windows')

    Returns:
        Full command to execute on remote host with deployed package
    """
    if os_type.lower() == "windows":
        # Windows: Use PowerShell
        win_path = audit_path.replace('/', '\\')
        script_path = f"{WINDOWS_DEPLOY_PATH}\\{win_path}"
        return f'powershell -NonInteractive -ExecutionPolicy Bypass -File "{script_path}"'
    else:
        # Linux: Use bash
        script_path = f"{LINUX_DEPLOY_PATH}/{audit_path}"
        return f'bash "{script_path}"'


def get_orchestrator_command(os_type: str = "linux", options: str = "") -> str:
    """
    Build command to run the full orchestrator

    Args:
        os_type: Target OS type ('linux' or 'windows')
        options: Additional command-line options (e.g., '--non-interactive --preset minimal')

    Returns:
        Full orchestrator command for deployed mode
    """
    if os_type.lower() == "windows":
        cmd = f"powershell -NonInteractive -ExecutionPolicy Bypass -File \"{WINDOWS_COMMAND_PREFIX}\""
        if options:
            cmd += f" {options}"
        return cmd
    else:
        cmd = f"{LINUX_DEPLOY_PATH}/{LINUX_ORCHESTRATOR}"
        if options:
            cmd += f" {options}"
        return f"bash {cmd}"


def detect_deployment_mode(server_config: dict) -> str:
    """
    Detect whether to use stream or deployed mode based on server config

    Priority:
    1. Explicit 'execution_mode' in config
    2. 'stream_mode' flag (legacy)
    3. Default to stream mode (agentless)
    """
    if 'execution_mode' in server_config:
        return server_config['execution_mode']
    elif server_config.get('stream_mode', True):
        return 'stream'
    else:
        return 'deployed'


# Execution mode documentation
EXECUTION_MODE_HELP = """
Execution Modes:
================

STREAM MODE (Default - Agentless)
---------------------------------
Scripts are sent directly to the target via SSH stdin (Linux) or WinRM (Windows).
No deployment required on target hosts.

API: POST /api/batch/audits/execute with "stream_mode": true (default)

Pros:
  - Zero deployment overhead
  - Scripts always run latest version
  - No package management on targets

Cons:
  - Higher network traffic per execution
  - Requires SSH/WinRM shell access for full script content


DEPLOYED MODE (Local Package)
-----------------------------
Scripts are pre-installed on targets via DEB/RPM (Linux) or MSI (Windows).
Faster execution for large fleets or slow networks.

API: POST /api/batch/audits/execute with "stream_mode": false

Package installation:
    Linux (Debian/Ubuntu): sudo dpkg -i audit-toolkit_<version>_all.deb
    Linux (RHEL/Fedora):   sudo rpm -ivh audit-toolkit-<version>.noarch.rpm
    Windows:               msiexec /i SecurityAuditToolkit-<version>-x64.msi /quiet

Pros:
  - Minimal network overhead (only command + output)
  - Faster for repeated executions
  - Works with limited shell access

Cons:
  - Requires package deployment/updates
  - Version management across fleet
"""


__all__ = [
    'LINUX_DEPLOY_PATH',
    'LINUX_COMMAND_PREFIX',
    'WINDOWS_DEPLOY_PATH',
    'WINDOWS_COMMAND_PREFIX',
    'LINUX_ORCHESTRATOR',
    'WINDOWS_ORCHESTRATOR',
    'DEFAULT_EXECUTION_MODE',
    'get_deployed_command',
    'get_orchestrator_command',
    'detect_deployment_mode',
    'EXECUTION_MODE_HELP',
]
