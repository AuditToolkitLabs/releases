"""
Audit Execution Router

Routes audit execution based on server connection method:
- ssh: Execute via SSH using SSHManager
- winrm: Execute via WinRM using WinRMManager
- agent: Queue command for agent to execute

Supports two execution modes:
- stream_mode=True: Scripts sent via stdin (agentless - no deployment required)
- stream_mode=False: Scripts expected at standard deploy path (requires package)

Author: Security Audit Toolkit Team
Date: February 16, 2026
"""

from config import logger, ROOT_DIR
from execution_paths import get_deployed_command


class AuditExecutionRouter:
    """
    Routes audit execution to the appropriate backend based on server connection_method
    """

    def __init__(self, ssh_manager=None, winrm_manager=None):
        """
        Initialize router with execution backends

        Args:
            ssh_manager: SSHManager instance for SSH execution
            winrm_manager: WinRMManager instance for WinRM execution
        """
        self.ssh_manager = ssh_manager
        self.winrm_manager = winrm_manager

    @staticmethod
    def _normalize_method_for_os(connection_method, os_type):
        method = (connection_method or 'ssh').strip().lower()
        target_os = (os_type or 'linux').strip().lower()
        if target_os != 'windows' and method == 'winrm':
            return 'ssh'
        return method

    def execute_audit(self, server, audit_path, options=None):
        """
        Execute an audit on a server using the appropriate method

        Args:
            server: Server model or dict with connection_method
            audit_path: Path to audit script
            options: Optional execution options (timeout, etc.)

        Returns:
            dict with keys:
                - method: 'ssh', 'winrm', or 'agent'
                - success: bool
                - output: str (for ssh/winrm) or None (for agent)
                - exit_code: int (for ssh/winrm) or None (for agent)
                - command_id: str (for agent only)
                - error: str (if failed)
        """
        # Get connection method from server
        if hasattr(server, 'connection_method'):
            connection_method = server.connection_method or 'ssh'
            os_type = getattr(server, 'os_type', 'linux')
            agent_id = server.agent_id
        else:
            connection_method = server.get('connection_method', 'ssh')
            os_type = server.get('os_type', 'linux')
            agent_id = server.get('agent_id')

        connection_method = self._normalize_method_for_os(connection_method, os_type)

        logger.info(f"Executing audit via {connection_method}: {audit_path}")

        if connection_method == 'agent':
            return self._execute_via_agent(server, agent_id, audit_path, options)
        elif connection_method == 'winrm':
            return self._execute_via_winrm(server, audit_path, options)
        else:  # Default to SSH
            return self._execute_via_ssh(server, audit_path, options)

    def _execute_via_ssh(self, server, audit_path, options):
        """Execute audit via SSH (synchronous)"""
        if not self.ssh_manager:
            return {
                'method': 'ssh',
                'success': False,
                'error': 'SSH manager not available'
            }

        try:
            # Convert server to dict if needed
            server_dict = self._server_to_dict(server)
            timeout = options.get('timeout', 300) if options else 300

            # Determine execution mode:
            # 1. Explicit stream_mode in options takes precedence
            # 2. Otherwise, use server's configured execution_mode
            # 3. Default to stream (agentless)
            if options and 'stream_mode' in options:
                stream_mode = options['stream_mode']
            else:
                # Check server's execution_mode setting
                server_exec_mode = server_dict.get('execution_mode', 'stream')
                stream_mode = (server_exec_mode == 'stream')

            if stream_mode:
                # Stream mode: Read script locally and send via stdin
                # No deployment required on target
                script_path = ROOT_DIR / audit_path
                if not script_path.exists():
                    return {
                        'method': 'ssh',
                        'success': False,
                        'error': f'Script not found locally: {script_path}'
                    }
                with open(script_path, 'r', encoding='utf-8') as f:
                    script_content = f.read()

                # Execute via stdin using bash -s
                result = self.ssh_manager.execute_command(
                    server_dict,
                    "bash -s",
                    timeout=timeout,
                    input_data=script_content
                )
            else:
                # Deployed mode: Execute script at standard install path
                command = get_deployed_command(audit_path, os_type="linux")
                result = self.ssh_manager.execute_command(
                    server_dict,
                    command,
                    timeout=timeout
                )

            return {
                'method': 'ssh',
                'success': result.get('success', False),
                'output': result.get('output', ''),
                'exit_code': result.get('exit_code', 1),
                'error': result.get('error')
            }

        except Exception as e:
            logger.error(f"SSH execution failed: {e}")
            return {
                'method': 'ssh',
                'success': False,
                'error': str(e)
            }

    def _execute_via_winrm(self, server, audit_path, options):
        """Execute audit via WinRM (synchronous)"""
        if not self.winrm_manager:
            return {
                'method': 'winrm',
                'success': False,
                'error': 'WinRM manager not available'
            }

        try:
            server_dict = self._server_to_dict(server)
            timeout = options.get('timeout', 300) if options else 300

            # Determine execution mode:
            # 1. Explicit stream_mode in options takes precedence
            # 2. Otherwise, use server's configured execution_mode
            # 3. Default to stream (agentless)
            if options and 'stream_mode' in options:
                stream_mode = options['stream_mode']
            else:
                # Check server's execution_mode setting
                server_exec_mode = server_dict.get('execution_mode', 'stream')
                stream_mode = (server_exec_mode == 'stream')

            if stream_mode:
                # Stream mode: Read script locally and send content via WinRM
                # Supports agentless execution without pre-deployment
                script_path = ROOT_DIR / audit_path
                if not script_path.exists():
                    return {
                        'method': 'winrm',
                        'success': False,
                        'error': f'Script not found locally: {script_path}'
                    }
                with open(script_path, 'r', encoding='utf-8') as f:
                    script_content = f.read()

                # Execute PowerShell script content directly
                result = self.winrm_manager.execute_command(
                    server_dict,
                    script_content,
                    powershell=True,
                    timeout=timeout
                )
            else:
                # Deployed mode: Execute script at standard Windows install path
                command = get_deployed_command(audit_path, os_type="windows")
                result = self.winrm_manager.execute_command(
                    server_dict,
                    command,
                    powershell=True,
                    timeout=timeout
                )

            return {
                'method': 'winrm',
                'success': result.get('success', False),
                'output': result.get('stdout', ''),
                'exit_code': result.get('return_code', 1),
                'error': result.get('error')
            }

        except Exception as e:
            logger.error(f"WinRM execution failed: {e}")
            return {
                'method': 'winrm',
                'success': False,
                'error': str(e)
            }

    def _execute_via_agent(self, server, agent_id, audit_path, options):
        """
        Queue audit execution for agent (asynchronous)

        Returns immediately with command_id. Agent will poll for command,
        execute, and report results back.
        """
        if not agent_id:
            return {
                'method': 'agent',
                'success': False,
                'error': 'Server has no agent_id configured'
            }

        try:
            # Import here to avoid circular imports
            from api.agent_routes import queue_command_for_agent

            # Determine command type and data
            command_data = {
                'audit_path': audit_path,
                'options': options or {},
                'server_id': server.id if hasattr(server, 'id') else server.get('id')
            }

            # Queue command for agent
            command = queue_command_for_agent(
                agent_id=agent_id,
                command_type='run_audit',
                command_data=command_data,
                requested_by=options.get('requested_by') if options else None,
                priority=options.get('priority', 5) if options else 5,
                expires_hours=options.get('expires_hours', 24) if options else 24
            )

            logger.info(f"Queued audit for agent {agent_id}: {audit_path} (command {command['id']})")

            return {
                'method': 'agent',
                'success': True,
                'output': None,  # Results come later via agent
                'exit_code': None,
                'command_id': command['id'],
                'message': f"Audit queued for agent execution. Command ID: {command['id']}"
            }

        except Exception as e:
            logger.error(f"Agent command queue failed: {e}")
            return {
                'method': 'agent',
                'success': False,
                'error': str(e)
            }

    def execute_plan(self, server, audit_paths, plan_name=None, options=None):
        """
        Execute a plan (list of audits) on a server

        For agent-based servers, queues a single run_plan command.
        For SSH/WinRM, executes audits sequentially.

        Args:
            server: Server model or dict
            audit_paths: List of audit paths to execute
            plan_name: Optional plan name
            options: Execution options

        Returns:
            dict with execution results or command_id for agent
        """
        # Get connection method
        if hasattr(server, 'connection_method'):
            connection_method = server.connection_method or 'ssh'
            os_type = getattr(server, 'os_type', 'linux')
            agent_id = server.agent_id
        else:
            connection_method = server.get('connection_method', 'ssh')
            os_type = server.get('os_type', 'linux')
            agent_id = server.get('agent_id')

        connection_method = self._normalize_method_for_os(connection_method, os_type)

        if connection_method == 'agent':
            return self._execute_plan_via_agent(server, agent_id, audit_paths, plan_name, options)
        else:
            # Execute sequentially for SSH/WinRM
            results = []
            for audit_path in audit_paths:
                result = self.execute_audit(server, audit_path, options)
                results.append({
                    'audit_path': audit_path,
                    **result
                })
            return {
                'method': connection_method,
                'success': all(r.get('success') for r in results),
                'results': results,
                'total': len(audit_paths),
                'completed': len([r for r in results if r.get('success')])
            }

    def _execute_plan_via_agent(self, server, agent_id, audit_paths, plan_name, options):
        """Queue plan execution for agent"""
        if not agent_id:
            return {
                'method': 'agent',
                'success': False,
                'error': 'Server has no agent_id configured'
            }

        try:
            from api.agent_routes import queue_command_for_agent

            command_data = {
                'audit_paths': audit_paths,
                'plan_name': plan_name or 'Custom Plan',
                'options': options or {},
                'server_id': server.id if hasattr(server, 'id') else server.get('id')
            }

            command = queue_command_for_agent(
                agent_id=agent_id,
                command_type='run_plan',
                command_data=command_data,
                requested_by=options.get('requested_by') if options else None,
                priority=options.get('priority', 5) if options else 5,
                expires_hours=options.get('expires_hours', 24) if options else 24
            )

            logger.info(f"Queued plan for agent {agent_id}: {len(audit_paths)} audits (command {command['id']})")

            return {
                'method': 'agent',
                'success': True,
                'command_id': command['id'],
                'total': len(audit_paths),
                'message': f"Plan queued for agent execution. Command ID: {command['id']}"
            }

        except Exception as e:
            logger.error(f"Agent plan queue failed: {e}")
            return {
                'method': 'agent',
                'success': False,
                'error': str(e)
            }

    def _server_to_dict(self, server):
        """Convert server model to dict for SSH/WinRM managers"""
        if isinstance(server, dict):
            return server

        return {
            'id': server.id,
            'name': server.name,
            'host': server.hostname,
            'port': server.port,
            'user': server.username,
            'password': server.password,
            'key_path': server.ssh_key_path,
            'auth_type': 'password' if server.password else 'public_key',
            'os_type': getattr(server, 'os_type', 'linux'),
            'execution_mode': getattr(server, 'execution_mode', 'stream') or 'stream'
        }


# Singleton instance
_router_instance = None


def get_execution_router(ssh_manager=None, winrm_manager=None):
    """Get or create the execution router singleton"""
    global _router_instance
    if _router_instance is None:
        _router_instance = AuditExecutionRouter(ssh_manager, winrm_manager)
    return _router_instance


def init_execution_router(ssh_manager=None, winrm_manager=None):
    """Initialize the execution router with managers"""
    global _router_instance
    _router_instance = AuditExecutionRouter(ssh_manager, winrm_manager)
    return _router_instance
