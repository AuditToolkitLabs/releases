#!/usr/bin/env python3
"""Fix missing database columns"""
import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), '..', 'audit_toolkit.db')
print(f"Database: {db_path}")

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Check existing columns
cursor.execute("PRAGMA table_info(servers)")
columns = [row[1] for row in cursor.fetchall()]
print(f"Existing columns: {columns}")

# Add missing columns if needed
missing_columns = [
    ("connection_method", "VARCHAR(50) DEFAULT 'ssh'"),
    ("execution_mode", "VARCHAR(50) DEFAULT 'stream'"),
    ("agent_id", "VARCHAR(100)"),
    ("hypervisor_type", "VARCHAR(50)"),
    ("hypervisor_endpoint", "VARCHAR(255)"),
]

for col_name, col_def in missing_columns:
    if col_name not in columns:
        try:
            cursor.execute(f"ALTER TABLE servers ADD COLUMN {col_name} {col_def}")
            print(f"Added column: {col_name}")
        except sqlite3.OperationalError as e:
            print(f"Column {col_name} already exists or error: {e}")

conn.commit()
conn.close()
print("Done!")
