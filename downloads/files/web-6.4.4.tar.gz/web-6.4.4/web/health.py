#!/usr/bin/env python3
"""
Health Check Module

Comprehensive health and readiness checks for:
- Application health (/health)
- Readiness probes (/ready)
- Dependency checks (Redis, PostgreSQL, Celery)
- Prometheus metrics (/metrics)

Author: Security Audit Toolkit Team
Date: February 6, 2026
"""

import os
import time
import logging
import psutil
from datetime import UTC, datetime
from typing import Dict, Any, Tuple
from pathlib import Path

from database_defaults import get_runtime_default_database_url
from version_info import get_toolkit_version

logger = logging.getLogger(__name__)

# Track start time for uptime calculation
_start_time = datetime.now(UTC)


def _is_truthy(value: Any) -> bool:
    """Interpret common environment-style truthy values."""
    return str(value).strip().lower() in {'1', 'true', 'yes', 'on', 'y'}


def redis_health_enabled() -> bool:
    """Return whether Redis is expected for this deployment."""
    explicit = os.getenv('REDIS_ENABLED')
    if explicit is None:
        return True
    return _is_truthy(explicit)


def celery_health_enabled() -> bool:
    """Return whether Celery worker health should be enforced."""
    explicit = os.getenv('CELERY_HEALTHCHECK_ENABLED')
    if explicit is not None:
        return _is_truthy(explicit)

    celery_enabled = os.getenv('CELERY_ENABLED')
    if celery_enabled is not None:
        return _is_truthy(celery_enabled)

    redis_enabled = os.getenv('REDIS_ENABLED')
    if redis_enabled is not None and not _is_truthy(redis_enabled):
        return False

    return True


def get_uptime() -> float:
    """Get application uptime in seconds"""
    return (datetime.now(UTC) - _start_time).total_seconds()


def check_redis(redis_url: str = None) -> Dict[str, Any]:
    """
    Check Redis connectivity and health

    Args:
        redis_url: Redis connection URL

    Returns:
        dict: Status and metrics
    """
    if not redis_health_enabled():
        return {
            'status': 'disabled',
            'available': False,
            'message': 'Redis health check disabled (REDIS_ENABLED=false)'
        }

    try:
        import redis
        if not redis_url:
            redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')

        client = redis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)

        # Ping test
        start = time.time()
        ping_result = client.ping()
        latency_ms = (time.time() - start) * 1000

        # Get info
        info = client.info('server')

        return {
            'status': 'healthy' if ping_result else 'unhealthy',
            'available': True,
            'latency_ms': round(latency_ms, 2),
            'version': info.get('redis_version', 'unknown'),
            'uptime_seconds': info.get('uptime_in_seconds', 0),
            'connected_clients': info.get('connected_clients', 0),
            'used_memory_mb': round(info.get('used_memory', 0) / (1024 * 1024), 2)
        }

    except ImportError:
        return {
            'status': 'unavailable',
            'available': False,
            'message': 'Redis library not installed'
        }

    except Exception as e:
        logger.warning(f"Redis health check failed: {e}")
        return {
            'status': 'unhealthy',
            'available': False,
            'error': str(e)
        }


def check_database(database_url: str = None) -> Dict[str, Any]:
    """
    Check PostgreSQL database connectivity and health

    Args:
        database_url: Database connection URL

    Returns:
        dict: Status and metrics
    """
    try:
        from sqlalchemy import create_engine, text

        if not database_url:
            data_root_env = os.getenv('AUDIT_TOOLKIT_DATA_DIR', '').strip()
            if data_root_env:
                data_root = Path(data_root_env).expanduser().resolve()
            else:
                data_root = Path(__file__).parent.parent.resolve()
            database_url = os.getenv('DATABASE_URL', get_runtime_default_database_url(data_root=data_root))

        # Create engine with short timeout
        engine = create_engine(
            database_url,
            pool_pre_ping=True,
            connect_args={'connect_timeout': 2} if 'postgresql' in database_url else {}
        )

        # Test connection
        start = time.time()
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            result.fetchone()
        latency_ms = (time.time() - start) * 1000

        # Get database type
        db_type = 'sqlite' if 'sqlite' in database_url else 'postgresql'

        return {
            'status': 'healthy',
            'available': True,
            'type': db_type,
            'latency_ms': round(latency_ms, 2)
        }

    except ImportError:
        return {
            'status': 'unavailable',
            'available': False,
            'message': 'SQLAlchemy not installed'
        }

    except Exception as e:
        logger.warning(f"Database health check failed: {e}")
        return {
            'status': 'unhealthy',
            'available': False,
            'error': str(e)
        }


def check_celery() -> Dict[str, Any]:
    """
    Check Celery workers availability

    Returns:
        dict: Status and worker info
    """
    if not celery_health_enabled():
        return {
            'status': 'disabled',
            'available': False,
            'workers': 0,
            'message': 'Celery health check disabled for this deployment'
        }

    try:
        from celery_app import celery_app

        # Inspect active workers
        inspect = celery_app.control.inspect(timeout=2)

        # Get active workers
        active_workers = inspect.active()

        if active_workers is None:
            return {
                'status': 'unhealthy',
                'available': False,
                'workers': 0,
                'message': 'No Celery workers responding'
            }

        worker_count = len(active_workers)

        # Get stats
        stats = inspect.stats()
        total_tasks = 0
        if stats:
            for worker, stat in stats.items():
                total_tasks += stat.get('total', {}).get('audit_tasks.execute_audit_task', 0)

        return {
            'status': 'healthy' if worker_count > 0 else 'unhealthy',
            'available': True,
            'workers': worker_count,
            'worker_names': list(active_workers.keys()) if active_workers else [],
            'total_tasks_processed': total_tasks
        }

    except ImportError:
        return {
            'status': 'unavailable',
            'available': False,
            'message': 'Celery not installed'
        }

    except Exception as e:
        logger.warning(f"Celery health check failed: {e}")
        return {
            'status': 'unhealthy',
            'available': False,
            'error': str(e)
        }


def check_disk_space(path: Path = None) -> Dict[str, Any]:
    """
    Check disk space availability

    Args:
        path: Path to check (defaults to app root)

    Returns:
        dict: Status and disk metrics
    """
    try:
        if path is None:
            path = Path(__file__).parent.parent

        disk = psutil.disk_usage(str(path))

        free_percent = (disk.free / disk.total) * 100

        # Status thresholds
        if free_percent < 5:
            status = 'critical'
        elif free_percent < 10:
            status = 'warning'
        else:
            status = 'healthy'

        return {
            'status': status,
            'total_gb': round(disk.total / (1024**3), 2),
            'used_gb': round(disk.used / (1024**3), 2),
            'free_gb': round(disk.free / (1024**3), 2),
            'percent_used': round(disk.percent, 2),
            'percent_free': round(free_percent, 2)
        }

    except Exception as e:
        logger.warning(f"Disk space check failed: {e}")
        return {
            'status': 'unknown',
            'error': str(e)
        }


def check_memory() -> Dict[str, Any]:
    """
    Check memory usage

    Returns:
        dict: Status and memory metrics
    """
    try:
        memory = psutil.virtual_memory()

        # Status thresholds
        if memory.percent > 95:
            status = 'critical'
        elif memory.percent > 85:
            status = 'warning'
        else:
            status = 'healthy'

        return {
            'status': status,
            'total_gb': round(memory.total / (1024**3), 2),
            'available_gb': round(memory.available / (1024**3), 2),
            'percent_used': round(memory.percent, 2),
            'percent_available': round((memory.available / memory.total) * 100, 2)
        }

    except Exception as e:
        logger.warning(f"Memory check failed: {e}")
        return {
            'status': 'unknown',
            'error': str(e)
        }


def check_cpu() -> Dict[str, Any]:
    """
    Check CPU usage

    Returns:
        dict: Status and CPU metrics
    """
    try:
        # Sample CPU over 1 second
        cpu_percent = psutil.cpu_percent(interval=0.5)
        cpu_count = psutil.cpu_count()

        # Status thresholds
        if cpu_percent > 95:
            status = 'critical'
        elif cpu_percent > 85:
            status = 'warning'
        else:
            status = 'healthy'

        return {
            'status': status,
            'percent': round(cpu_percent, 2),
            'count': cpu_count
        }

    except Exception as e:
        logger.warning(f"CPU check failed: {e}")
        return {
            'status': 'unknown',
            'error': str(e)
        }


def _get_version() -> str:
    """Get application version from VERSION file or environment"""
    # Try environment variable first
    version = os.environ.get('APP_VERSION')
    if version:
        return version

    # Try VERSION file in various locations
    version_paths = [
        Path(__file__).parent.parent / 'VERSION',  # repo root
        Path(__file__).parent / 'VERSION',         # web directory
        Path('/app/VERSION'),                      # Docker container
    ]
    for path in version_paths:
        try:
            if path.exists():
                return path.read_text().strip()
        except Exception as version_read_error:
            logger.debug(f"Version probe skipped for {path}: {version_read_error}")

    return get_toolkit_version(default='0.0.0')


def comprehensive_health_check(
    check_dependencies: bool = True,
    include_system: bool = True
) -> Tuple[Dict[str, Any], int]:
    """
    Perform comprehensive health check

    Args:
        check_dependencies: Check external dependencies (Redis, DB, Celery)
        include_system: Include system metrics (CPU, memory, disk)

    Returns:
        tuple: (health_data dict, http_status_code)
    """
    health_data = {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'uptime_seconds': round(get_uptime(), 2),
        'version': _get_version(),
        'checks': {}
    }

    # System checks
    if include_system:
        health_data['checks']['disk'] = check_disk_space()
        health_data['checks']['memory'] = check_memory()
        health_data['checks']['cpu'] = check_cpu()

    # Dependency checks
    if check_dependencies:
        health_data['checks']['redis'] = check_redis()
        health_data['checks']['database'] = check_database()
        health_data['checks']['celery'] = check_celery()

    # Determine overall status
    critical_checks = []
    unhealthy_checks = []
    warning_checks = []
    unavailable_checks = []

    for check_name, check_result in health_data['checks'].items():
        status = check_result.get('status', 'unknown')

        if status == 'critical':
            critical_checks.append(check_name)
        elif status == 'unhealthy':
            unhealthy_checks.append(check_name)
        elif status == 'warning':
            warning_checks.append(check_name)
        elif status == 'unavailable':
            unavailable_checks.append(check_name)

    # Set overall status and HTTP code
    if critical_checks:
        health_data['status'] = 'critical'
        http_status = 503  # Service Unavailable
        health_data['critical_checks'] = critical_checks
    elif unhealthy_checks:
        health_data['status'] = 'unhealthy'
        http_status = 503  # Service Unavailable
        health_data['unhealthy_checks'] = unhealthy_checks
    elif warning_checks:
        health_data['status'] = 'degraded'
        http_status = 200  # Still operational
        health_data['warning_checks'] = warning_checks
    else:
        health_data['status'] = 'healthy'
        http_status = 200

    if unavailable_checks:
        health_data['unavailable_checks'] = unavailable_checks

    return health_data, http_status


def readiness_check() -> Tuple[Dict[str, Any], int]:
    """
    Readiness probe for load balancers

    Checks if application is ready to serve traffic:
    - Critical dependencies available
    - Not in maintenance mode
    - Can handle requests

    Returns:
        tuple: (readiness_data dict, http_status_code)
    """
    readiness_data = {
        'ready': True,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'checks': {}
    }

    # Check critical dependencies only
    readiness_data['checks']['database'] = check_database()

    # Check if Redis is available (non-critical)
    redis_check = check_redis()
    if redis_check.get('available'):
        readiness_data['checks']['redis'] = redis_check

    # Check Celery workers (non-critical for web requests)
    celery_check = check_celery()
    if celery_check.get('available'):
        readiness_data['checks']['celery'] = celery_check

    # Determine readiness
    critical_failures = []

    # Database must be healthy
    db_status = readiness_data['checks']['database'].get('status')
    if db_status in ['unhealthy', 'critical']:
        critical_failures.append('database')

    # Set readiness
    if critical_failures:
        readiness_data['ready'] = False
        readiness_data['failures'] = critical_failures
        http_status = 503  # Not ready
    else:
        readiness_data['ready'] = True
        http_status = 200  # Ready

    return readiness_data, http_status


def generate_prometheus_metrics() -> str:
    """
    Generate Prometheus-compatible metrics

    Returns:
        str: Prometheus metrics in text format
    """
    metrics = []

    # Application info
    metrics.append('# HELP audit_toolkit_info Application information')
    metrics.append('# TYPE audit_toolkit_info gauge')
    metrics.append('audit_toolkit_info{version="2.0"} 1')

    # Uptime
    uptime = get_uptime()
    metrics.append('# HELP audit_toolkit_uptime_seconds Application uptime in seconds')
    metrics.append('# TYPE audit_toolkit_uptime_seconds counter')
    metrics.append(f'audit_toolkit_uptime_seconds {uptime}')

    # System metrics
    try:
        disk = check_disk_space()
        metrics.append('# HELP audit_toolkit_disk_free_bytes Free disk space in bytes')
        metrics.append('# TYPE audit_toolkit_disk_free_bytes gauge')
        metrics.append(f'audit_toolkit_disk_free_bytes {disk["free_gb"] * 1024**3}')

        metrics.append('# HELP audit_toolkit_disk_usage_percent Disk usage percentage')
        metrics.append('# TYPE audit_toolkit_disk_usage_percent gauge')
        metrics.append(f'audit_toolkit_disk_usage_percent {disk["percent_used"]}')
    except Exception as e:
        logger.warning(f"Failed to collect disk metrics: {e}")

    try:
        memory = check_memory()
        metrics.append('# HELP audit_toolkit_memory_usage_percent Memory usage percentage')
        metrics.append('# TYPE audit_toolkit_memory_usage_percent gauge')
        metrics.append(f'audit_toolkit_memory_usage_percent {memory["percent_used"]}')
    except Exception as e:
        logger.warning(f"Failed to collect memory metrics: {e}")

    try:
        cpu = check_cpu()
        metrics.append('# HELP audit_toolkit_cpu_usage_percent CPU usage percentage')
        metrics.append('# TYPE audit_toolkit_cpu_usage_percent gauge')
        metrics.append(f'audit_toolkit_cpu_usage_percent {cpu["percent"]}')
    except Exception as e:
        logger.warning(f"Failed to collect CPU metrics: {e}")

    # Dependency health (1 = healthy, 0 = unhealthy, -1 = unavailable)
    try:
        redis_health = check_redis()
        redis_value = 1 if redis_health['status'] == 'healthy' else (0 if redis_health.get('available') else -1)
        metrics.append('# HELP audit_toolkit_redis_health Redis health status (1=healthy, 0=unhealthy, -1=unavailable)')
        metrics.append('# TYPE audit_toolkit_redis_health gauge')
        metrics.append(f'audit_toolkit_redis_health {redis_value}')

        if redis_health.get('latency_ms'):
            metrics.append('# HELP audit_toolkit_redis_latency_milliseconds Redis latency in milliseconds')
            metrics.append('# TYPE audit_toolkit_redis_latency_milliseconds gauge')
            metrics.append(f'audit_toolkit_redis_latency_milliseconds {redis_health["latency_ms"]}')
    except Exception as e:
        logger.warning(f"Failed to collect Redis metrics: {e}")

    try:
        db_health = check_database()
        db_value = 1 if db_health['status'] == 'healthy' else (0 if db_health.get('available') else -1)
        metrics.append('# HELP audit_toolkit_database_health Database health status (1=healthy, 0=unhealthy, -1=unavailable)')
        metrics.append('# TYPE audit_toolkit_database_health gauge')
        metrics.append(f'audit_toolkit_database_health {db_value}')

        if db_health.get('latency_ms'):
            metrics.append('# HELP audit_toolkit_database_latency_milliseconds Database latency in milliseconds')
            metrics.append('# TYPE audit_toolkit_database_latency_milliseconds gauge')
            metrics.append(f'audit_toolkit_database_latency_milliseconds {db_health["latency_ms"]}')
    except Exception as e:
        logger.warning(f"Failed to collect database metrics: {e}")

    try:
        celery_health = check_celery()
        celery_value = 1 if celery_health['status'] == 'healthy' else (0 if celery_health.get('available') else -1)
        metrics.append('# HELP audit_toolkit_celery_health Celery health status (1=healthy, 0=unhealthy, -1=unavailable)')
        metrics.append('# TYPE audit_toolkit_celery_health gauge')
        metrics.append(f'audit_toolkit_celery_health {celery_value}')

        if celery_health.get('workers') is not None:
            metrics.append('# HELP audit_toolkit_celery_workers Number of active Celery workers')
            metrics.append('# TYPE audit_toolkit_celery_workers gauge')
            metrics.append(f'audit_toolkit_celery_workers {celery_health["workers"]}')
    except Exception as e:
        logger.warning(f"Failed to collect Celery metrics: {e}")

    return '\n'.join(metrics) + '\n'
