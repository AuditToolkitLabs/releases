#!/usr/bin/env python3
"""Simple HTTPS reverse proxy for Security Audit Toolkit.

Listens on TLS port 443 (or configured port) and proxies requests to the
local web UI backend on http://127.0.0.1:5000 by default.

Environment variables:
    ATK_BACKEND_URL          Backend origin, default http://127.0.0.1:5000
    ATK_HTTPS_LISTEN_HOST    Bind host, default 0.0.0.0
    ATK_HTTPS_LISTEN_PORT    Bind port, default 443
    ATK_HTTPS_CERT           PEM certificate path (required)
    ATK_HTTPS_KEY            PEM private key path (required)
    ATK_CERT_HOSTS           Comma-separated DNS/IP SAN values
"""

from __future__ import annotations

import ipaddress
import os
import socket
import ssl
import sys
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Iterable
from urllib import error as urllib_error
from urllib import request as urllib_request
from urllib.parse import urlsplit, urlunsplit

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID


_RAW_BACKEND_URL = os.environ.get("ATK_BACKEND_URL", "http://127.0.0.1:5000").strip()
_PARSED_BACKEND_URL = urlsplit(_RAW_BACKEND_URL)
if _PARSED_BACKEND_URL.scheme not in {"http", "https"} or not _PARSED_BACKEND_URL.netloc:
    raise SystemExit("ATK_BACKEND_URL must be an absolute http(s) URL")

BACKEND_URL = urlunsplit(
    (
        _PARSED_BACKEND_URL.scheme,
        _PARSED_BACKEND_URL.netloc,
        _PARSED_BACKEND_URL.path.rstrip("/"),
        "",
        "",
    )
)
LISTEN_HOST = os.environ.get("ATK_HTTPS_LISTEN_HOST", "0.0.0.0")  # nosec B104 - reverse proxy listen interface is operator-configurable for appliance deployments
LISTEN_PORT = int(os.environ.get("ATK_HTTPS_LISTEN_PORT", "443"))
CERT_PATH = Path(os.environ.get("ATK_HTTPS_CERT", "")).expanduser()
KEY_PATH = Path(os.environ.get("ATK_HTTPS_KEY", "")).expanduser()
RAW_CERT_HOSTS = os.environ.get("ATK_CERT_HOSTS", "")
REQUEST_TIMEOUT = int(os.environ.get("ATK_HTTPS_PROXY_TIMEOUT", "120"))
HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}


def log(message: str) -> None:
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    sys.stderr.write(f"[{timestamp}] {message}\n")
    sys.stderr.flush()


def build_subject_names() -> list[str]:
    values: list[str] = []
    for item in RAW_CERT_HOSTS.split(","):
        item = item.strip()
        if item:
            values.append(item)

    for fallback in (socket.gethostname(), "localhost", "127.0.0.1", "::1"):
        if fallback and fallback not in values:
            values.append(fallback)

    try:
        hostname = socket.getfqdn()
        if hostname and hostname not in values:
            values.append(hostname)
    except OSError:
        pass

    return values


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def ensure_self_signed_certificate(cert_path: Path, key_path: Path, hosts: Iterable[str]) -> None:
    if cert_path.exists() and key_path.exists():
        return

    ensure_parent(cert_path)
    ensure_parent(key_path)

    host_list = []
    seen: set[str] = set()
    for host in hosts:
        normalized = host.strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            host_list.append(normalized)

    common_name = host_list[0] if host_list else "localhost"
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Security Audit Toolkit"),
            x509.NameAttribute(NameOID.COMMON_NAME, common_name),
        ]
    )

    san_entries: list[x509.GeneralName] = []
    for item in host_list:
        try:
            san_entries.append(x509.IPAddress(ipaddress.ip_address(item)))
        except ValueError:
            san_entries.append(x509.DNSName(item))

    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=397))
        .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_encipherment=True,
                content_commitment=False,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),
            critical=False,
        )
        .sign(private_key=key, algorithm=hashes.SHA256())
    )

    key_path.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    log(f"Generated self-signed certificate at {cert_path}")


def normalize_proxy_path(raw_path: str) -> str:
    """Normalize request path and ignore absolute-form URI scheme/host components."""
    if not raw_path:
        return "/"

    parsed = urlsplit(raw_path)
    if parsed.scheme or parsed.netloc:
        path = parsed.path or "/"
        if parsed.query:
            return f"{path}?{parsed.query}"
        return path

    if raw_path.startswith("/"):
        return raw_path
    return f"/{raw_path}"


class ProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self) -> None:  # noqa: N802
        self._proxy()

    def do_POST(self) -> None:  # noqa: N802
        self._proxy()

    def do_PUT(self) -> None:  # noqa: N802
        self._proxy()

    def do_PATCH(self) -> None:  # noqa: N802
        self._proxy()

    def do_DELETE(self) -> None:  # noqa: N802
        self._proxy()

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._proxy()

    def do_HEAD(self) -> None:  # noqa: N802
        self._proxy()

    def log_message(self, fmt: str, *args: object) -> None:
        log("%s - - %s" % (self.address_string(), fmt % args))

    def _proxy(self) -> None:
        content_length = self.headers.get("Content-Length", "0").strip() or "0"
        body = self.rfile.read(int(content_length)) if content_length.isdigit() and int(content_length) > 0 else None

        request_path = normalize_proxy_path(self.path)
        target_url = f"{BACKEND_URL}{request_path}"
        outbound_headers: dict[str, str] = {}
        for header_name, header_value in self.headers.items():
            lowered = header_name.lower()
            if lowered in HOP_BY_HOP_HEADERS or lowered == "host":
                continue
            outbound_headers[header_name] = header_value

        client_ip = self.client_address[0] if self.client_address else ""
        existing_forwarded_for = self.headers.get("X-Forwarded-For", "").strip()
        outbound_headers["X-Forwarded-For"] = f"{existing_forwarded_for}, {client_ip}".strip(", ") if client_ip else existing_forwarded_for
        outbound_headers["X-Forwarded-Proto"] = "https"
        outbound_headers["X-Forwarded-Host"] = self.headers.get("Host", f"{LISTEN_HOST}:{LISTEN_PORT}")
        outbound_headers["X-Forwarded-Port"] = str(LISTEN_PORT)

        request_obj = urllib_request.Request(target_url, data=body, headers=outbound_headers, method=self.command)

        try:
            with urllib_request.urlopen(request_obj, timeout=REQUEST_TIMEOUT) as response:  # nosec B310 - target URL is built from validated backend URL plus normalized path
                response_body = response.read()
                self._send_response(response.status, response.headers.items(), response_body)
        except urllib_error.HTTPError as exc:
            response_body = exc.read()
            self._send_response(exc.code, exc.headers.items(), response_body)
        except Exception as exc:  # pragma: no cover - operational safety net
            message = f"HTTPS proxy error: {exc}".encode("utf-8", errors="replace")
            self.send_response(502)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(message)))
            self.send_header("Connection", "close")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(message)
            self.close_connection = True

    def _send_response(self, status_code: int, headers: Iterable[tuple[str, str]], body: bytes) -> None:
        self.send_response(status_code)
        content_length_sent = False
        for header_name, header_value in headers:
            lowered = header_name.lower()
            if lowered in HOP_BY_HOP_HEADERS:
                continue
            if lowered == "content-length":
                content_length_sent = True
            self.send_header(header_name, header_value)

        if not content_length_sent:
            self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD" and body:
            self.wfile.write(body)
        self.close_connection = True


def main() -> int:
    if not CERT_PATH or not KEY_PATH:
        raise SystemExit("ATK_HTTPS_CERT and ATK_HTTPS_KEY must be set")

    hosts = build_subject_names()
    ensure_self_signed_certificate(CERT_PATH, KEY_PATH, hosts)

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile=str(CERT_PATH), keyfile=str(KEY_PATH))

    server = ProxyServer((LISTEN_HOST, LISTEN_PORT), ProxyHandler)
    server.socket = context.wrap_socket(server.socket, server_side=True)
    log(f"Starting HTTPS proxy on https://{LISTEN_HOST}:{LISTEN_PORT} -> {BACKEND_URL}")

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        log("HTTPS proxy interrupted")
    finally:
        server.server_close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
