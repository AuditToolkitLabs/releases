#!/usr/bin/env python3
"""Import servers from JSON file into database"""
import json
import sqlite3
import os
from datetime import datetime

# Paths
json_path = os.path.join(os.path.dirname(__file__), '..', 'servers', 'servers.json')
db_path = os.path.join(os.path.dirname(__file__), '..', 'audit_toolkit.db')

print(f"JSON: {json_path}")
print(f"DB: {db_path}")

# Load JSON
if not os.path.exists(json_path):
    print("No servers.json found")
    exit(1)

with open(json_path, 'r') as f:
    servers = json.load(f)

print(f"Found {len(servers)} servers in JSON")

# Insert into database
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

for server in servers:
    try:
        cursor.execute("""
            INSERT INTO servers (name, hostname, port, username, password, ssh_key_path,
                                 connection_method, execution_mode, description, tags,
                                 created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            server.get('name', 'Unknown'),
            server.get('host', server.get('hostname', '')),
            server.get('port', 22),
            server.get('user', server.get('username', '')),
            server.get('password', ''),
            server.get('key_path', ''),
            server.get('connection_method', 'ssh'),
            server.get('execution_mode', 'stream'),
            server.get('description', ''),
            server.get('tags', ''),
            datetime.utcnow().isoformat(),
            datetime.utcnow().isoformat()
        ))
        print(f"  Imported: {server.get('name')}")
    except sqlite3.IntegrityError as e:
        print(f"  Skipped (exists): {server.get('name')} - {e}")

conn.commit()
conn.close()
print("Done!")
