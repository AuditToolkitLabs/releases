-- Security Audit Toolkit - Database Initialization
-- This script runs on first PostgreSQL startup

-- Grant privileges to audit_user
GRANT ALL PRIVILEGES ON DATABASE audit_toolkit TO audit_user;
