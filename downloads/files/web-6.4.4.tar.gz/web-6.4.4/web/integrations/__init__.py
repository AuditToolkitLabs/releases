"""
Integrations Package

Third-party integrations for notifications and ticketing:
- Slack Bot: Daily digests, alerts, interactive commands
- Teams Bot: Daily digests, alerts, adaptive cards
- ServiceNow: Auto-create incidents from findings
- Jira: Auto-create issues from findings
"""

from .slack_teams_bot import SlackBot, TeamsBot, ChatBotManager

__all__ = ['SlackBot', 'TeamsBot', 'ChatBotManager']
