#!/usr/bin/env python3
"""
Centralized Encrypted Key Store

Provides secure, encrypted storage for all API keys and secrets:
- System API key
- Agent API keys (lightweight SSH/WinRM agents)
- Hypervisor agent keys (platform agents)
- Custom API keys (integrations)
- SSH/server passwords

All keys are encrypted at rest using Fernet (AES-256-CBC with HMAC).
The encryption master key is stored separately with restrictive permissions.

Storage location: settings/secure_keystore.enc
Master key location: settings/.keystore_master

Usage:
    from keystore import keystore

    # Store a key
    keystore.store_key('system', 'api_key', 'my-secret-key-123')

    # Retrieve a key
    key = keystore.get_key('system', 'api_key')

    # List all keys of a type
    keys = keystore.list_keys('agent')

    # Delete a key
    keystore.delete_key('agent', 'agent_001')

Author: Security Audit Toolkit Team
Date: March 2026
"""

import json
import logging
import os
import hashlib
import platform
import shutil
import subprocess  # nosec B404
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Dict, List, Optional, Any

try:
    from cryptography.fernet import Fernet, InvalidToken
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    Fernet = None
    InvalidToken = Exception

logger = logging.getLogger(__name__)


# Key types supported by the keystore
KEY_TYPES = {
    'system': 'System API Key',
    'agent': 'Standalone Agent API Key',
    'hypervisor_agent': 'Hypervisor Platform Agent Key',
    'asset_discovery': 'Asset Discovery API Key',
    'custom': 'Custom Integration Key',
    'ssh_password': 'SSH Server Password',  # nosec B105
    'api_token': 'External API Token (Proxmox, etc.)',  # nosec B105
}


class SecureKeyStore:
    """
    Centralized encrypted storage for all API keys and secrets.

    Keys are organized by type and ID:
    {
        "system": {
            "api_key": {"value": "...", "created": "...", "metadata": {...}}
        },
        "agent": {
            "agent_001": {"value": "...", "created": "...", "metadata": {...}},
            "agent_002": {"value": "...", "created": "...", "metadata": {...}}
        },
        ...
    }
    """

    def __init__(self, keystore_path: Path = None, master_key_path: Path = None):
        """
        Initialize the secure key store.

        Args:
            keystore_path: Path to encrypted keystore file
            master_key_path: Path to master encryption key file
        """
        from config import SETTINGS_DIR

        settings_dir = SETTINGS_DIR
        settings_dir.mkdir(parents=True, exist_ok=True)

        self.keystore_path = keystore_path or settings_dir / 'secure_keystore.enc'
        self.master_key_path = master_key_path or settings_dir / '.keystore_master'

        self._cipher = None
        self._data: Dict[str, Dict[str, Any]] = {}
        self._lock = Lock()

        # Initialize encryption
        self._ensure_master_key()

        # Load existing data
        self._load()

    def _ensure_master_key(self):
        """Ensure master encryption key exists, create if needed."""
        if not ENCRYPTION_AVAILABLE:
            logger.warning("Encryption not available - keys will NOT be encrypted at rest!")
            return

        if self.master_key_path.exists():
            try:
                key = self.master_key_path.read_bytes()
                self._cipher = Fernet(key)
                logger.debug("Loaded existing master encryption key")
            except Exception as e:
                logger.error(f"Failed to load master key: {e}")
                self._cipher = None
        else:
            try:
                key = Fernet.generate_key()
                self.master_key_path.write_bytes(key)
                self._secure_file(self.master_key_path)
                self._cipher = Fernet(key)
                logger.info(f"Generated new master encryption key at {self.master_key_path}")
            except Exception as e:
                logger.error(f"Failed to create master key: {e}")
                self._cipher = None

    def _secure_file(self, file_path: Path):
        """Set secure file permissions (owner read/write only)."""
        if platform.system() == 'Windows':
            try:
                # Remove inherited permissions, grant only current user
                icacls_bin = shutil.which('icacls') or 'icacls'
                subprocess.run(
                    [icacls_bin, str(file_path), '/inheritance:r',
                     '/grant:r', f'{os.getlogin()}:(R,W)'],
                    check=True, capture_output=True
                )  # nosec B603
                logger.debug(f"Set Windows ACL on {file_path}")
            except Exception as e:
                logger.warning(f"Could not set Windows ACL on {file_path}: {e}")
        else:
            # Unix: chmod 600
            try:
                file_path.chmod(0o600)
            except Exception as e:
                logger.warning(f"Could not set Unix permissions on {file_path}: {e}")

    def _encrypt(self, data: str) -> bytes:
        """Encrypt data string to bytes."""
        if not self._cipher:
            # Fallback: base64 encode (NOT secure, just obfuscation)
            import base64
            return b'PLAIN:' + base64.b64encode(data.encode())
        return self._cipher.encrypt(data.encode())

    def _decrypt(self, data: bytes) -> str:
        """Decrypt bytes to data string."""
        if data.startswith(b'PLAIN:'):
            # Fallback: base64 decode
            import base64
            return base64.b64decode(data[6:]).decode()

        if not self._cipher:
            raise RuntimeError("Cannot decrypt - encryption key not available")

        try:
            return self._cipher.decrypt(data).decode()
        except InvalidToken:
            raise RuntimeError("Decryption failed - invalid key or corrupted data")

    def _load(self):
        """Load keystore from encrypted file."""
        with self._lock:
            if not self.keystore_path.exists():
                self._data = {key_type: {} for key_type in KEY_TYPES}
                logger.info("Initialized empty keystore")
                return

            try:
                encrypted_data = self.keystore_path.read_bytes()
                decrypted_json = self._decrypt(encrypted_data)
                self._data = json.loads(decrypted_json)

                # Ensure all key types exist
                for key_type in KEY_TYPES:
                    if key_type not in self._data:
                        self._data[key_type] = {}

                logger.info(f"Loaded keystore with {self._count_keys()} keys")
            except Exception as e:
                logger.error(f"Failed to load keystore: {e}")
                self._data = {key_type: {} for key_type in KEY_TYPES}

    def _save(self):
        """Save keystore to encrypted file."""
        with self._lock:
            try:
                json_data = json.dumps(self._data, indent=2, default=str)
                encrypted_data = self._encrypt(json_data)

                # Write atomically
                temp_path = self.keystore_path.with_suffix('.tmp')
                temp_path.write_bytes(encrypted_data)
                temp_path.replace(self.keystore_path)

                self._secure_file(self.keystore_path)
                logger.debug(f"Saved keystore with {self._count_keys()} keys")
                return True
            except Exception as e:
                logger.error(f"Failed to save keystore: {e}")
                return False

    def _count_keys(self) -> int:
        """Count total keys in store."""
        return sum(len(keys) for keys in self._data.values())

    def _hash_key(self, key: str) -> str:
        """Create SHA256 hash of a key for comparison."""
        return hashlib.sha256(key.encode()).hexdigest()

    # ==========================================================================
    # Public API
    # ==========================================================================

    def store_key(
        self,
        key_type: str,
        key_id: str,
        value: str,
        metadata: Dict[str, Any] = None,
        created_by: str = None
    ) -> bool:
        """
        Store a key in the encrypted keystore.

        Args:
            key_type: Type of key (system, agent, hypervisor_agent, custom, etc.)
            key_id: Unique identifier for the key
            value: The actual key/secret value
            metadata: Optional metadata (description, scope, etc.)
            created_by: Username who created/updated the key

        Returns:
            True if stored successfully
        """
        if key_type not in KEY_TYPES:
            raise ValueError(f"Invalid key type: {key_type}. Must be one of: {list(KEY_TYPES.keys())}")

        with self._lock:
            entry = {
                'value': value,
                'hash': self._hash_key(value),
                'created_at': self._data.get(key_type, {}).get(key_id, {}).get('created_at', datetime.now().isoformat()),
                'updated_at': datetime.now().isoformat(),
                'created_by': created_by or self._data.get(key_type, {}).get(key_id, {}).get('created_by'),
                'metadata': metadata or self._data.get(key_type, {}).get(key_id, {}).get('metadata', {})
            }

            if key_type not in self._data:
                self._data[key_type] = {}

            self._data[key_type][key_id] = entry

        success = self._save()
        if success:
            logger.info(f"Stored key: {key_type}/{key_id}")
        return success

    def get_key(self, key_type: str, key_id: str) -> Optional[str]:
        """
        Retrieve a key value from the keystore.

        Args:
            key_type: Type of key
            key_id: Key identifier

        Returns:
            Key value or None if not found
        """
        with self._lock:
            entry = self._data.get(key_type, {}).get(key_id)
            if entry:
                return entry.get('value')
            return None

    def get_key_info(self, key_type: str, key_id: str) -> Optional[Dict[str, Any]]:
        """
        Get full key entry info (without the actual value).

        Args:
            key_type: Type of key
            key_id: Key identifier

        Returns:
            Dict with key info (excluding value) or None
        """
        with self._lock:
            entry = self._data.get(key_type, {}).get(key_id)
            if entry:
                # Return info without the actual value
                return {
                    'key_type': key_type,
                    'key_id': key_id,
                    'hash': entry.get('hash'),
                    'preview': '****' + entry.get('value', '')[-4:] if entry.get('value') else '****',
                    'created_at': entry.get('created_at'),
                    'updated_at': entry.get('updated_at'),
                    'created_by': entry.get('created_by'),
                    'metadata': entry.get('metadata', {})
                }
            return None

    def delete_key(self, key_type: str, key_id: str) -> bool:
        """
        Delete a key from the keystore.

        Args:
            key_type: Type of key
            key_id: Key identifier

        Returns:
            True if deleted, False if not found
        """
        with self._lock:
            if key_type in self._data and key_id in self._data[key_type]:
                del self._data[key_type][key_id]
                success = self._save()
                if success:
                    logger.info(f"Deleted key: {key_type}/{key_id}")
                return success
            return False

    def list_keys(self, key_type: str = None) -> List[Dict[str, Any]]:
        """
        List all keys, optionally filtered by type.

        Args:
            key_type: Optional type filter

        Returns:
            List of key info dicts (without values)
        """
        result = []
        with self._lock:
            types_to_list = [key_type] if key_type else list(KEY_TYPES.keys())

            for kt in types_to_list:
                for kid, entry in self._data.get(kt, {}).items():
                    result.append({
                        'key_type': kt,
                        'key_type_name': KEY_TYPES.get(kt, kt),
                        'key_id': kid,
                        'preview': '****' + entry.get('value', '')[-4:] if entry.get('value') else '****',
                        'created_at': entry.get('created_at'),
                        'updated_at': entry.get('updated_at'),
                        'created_by': entry.get('created_by'),
                        'metadata': entry.get('metadata', {})
                    })

        return result

    def validate_key(self, key_type: str, key_id: str, value: str) -> bool:
        """
        Validate a key value against the stored hash.

        Args:
            key_type: Type of key
            key_id: Key identifier
            value: Value to validate

        Returns:
            True if value matches stored key
        """
        with self._lock:
            entry = self._data.get(key_type, {}).get(key_id)
            if not entry:
                return False

            stored_hash = entry.get('hash')
            if not stored_hash:
                # Fallback to direct comparison
                return entry.get('value') == value

            return hashlib.sha256(value.encode()).hexdigest() == stored_hash

    def rotate_key(self, key_type: str, key_id: str, rotated_by: str = None) -> Optional[str]:
        """
        Generate a new key value (rotation).

        Args:
            key_type: Type of key
            key_id: Key identifier
            rotated_by: Username who initiated rotation

        Returns:
            New key value or None if key not found
        """
        import secrets

        with self._lock:
            if key_type not in self._data or key_id not in self._data[key_type]:
                return None

            old_entry = self._data[key_type][key_id]
            new_value = secrets.token_urlsafe(32)

            # Preserve metadata, update key
            self._data[key_type][key_id] = {
                'value': new_value,
                'hash': self._hash_key(new_value),
                'created_at': old_entry.get('created_at'),
                'updated_at': datetime.now().isoformat(),
                'created_by': old_entry.get('created_by'),
                'rotated_by': rotated_by,
                'rotated_at': datetime.now().isoformat(),
                'previous_hash': old_entry.get('hash'),
                'metadata': old_entry.get('metadata', {})
            }

        if self._save():
            logger.info(f"Rotated key: {key_type}/{key_id} by {rotated_by}")
            return new_value
        return None

    def key_exists(self, key_type: str, key_id: str) -> bool:
        """Check if a key exists."""
        with self._lock:
            return key_type in self._data and key_id in self._data[key_type]

    def get_stats(self) -> Dict[str, int]:
        """Get key count statistics by type."""
        with self._lock:
            return {kt: len(self._data.get(kt, {})) for kt in KEY_TYPES}

    # ==========================================================================
    # Migration helpers
    # ==========================================================================

    def migrate_from_file(self, file_path: Path, key_type: str, key_id: str,
                         delete_original: bool = False) -> bool:
        """
        Migrate a key from a plaintext file to the encrypted keystore.

        Args:
            file_path: Path to file containing the key
            key_type: Type to store key as
            key_id: ID for the key
            delete_original: Whether to delete the original file after migration

        Returns:
            True if migrated successfully
        """
        if not file_path.exists():
            return False

        try:
            value = file_path.read_text().strip()
            if not value:
                return False

            success = self.store_key(
                key_type=key_type,
                key_id=key_id,
                value=value,
                metadata={'migrated_from': str(file_path), 'migrated_at': datetime.now().isoformat()}
            )

            if success and delete_original:
                file_path.unlink()
                logger.info(f"Deleted original file after migration: {file_path}")

            return success
        except Exception as e:
            logger.error(f"Failed to migrate key from {file_path}: {e}")
            return False

    def export_for_backup(self, include_values: bool = False) -> Dict[str, Any]:
        """
        Export keystore data for backup purposes.

        Args:
            include_values: If True, includes actual key values (use with caution)

        Returns:
            Dict with keystore data
        """
        with self._lock:
            if include_values:
                return {
                    'exported_at': datetime.now().isoformat(),
                    'encryption_available': ENCRYPTION_AVAILABLE,
                    'data': self._data
                }
            else:
                # Export without values (safer)
                export = {
                    'exported_at': datetime.now().isoformat(),
                    'encryption_available': ENCRYPTION_AVAILABLE,
                    'key_count': self._count_keys(),
                    'by_type': {}
                }
                for kt, keys in self._data.items():
                    export['by_type'][kt] = {
                        kid: {k: v for k, v in entry.items() if k != 'value'}
                        for kid, entry in keys.items()
                    }
                return export


# ==============================================================================
# Module-level singleton instance
# ==============================================================================

# Lazy initialization to avoid import-time errors
_keystore_instance = None


def get_keystore() -> SecureKeyStore:
    """Get the singleton keystore instance."""
    global _keystore_instance
    if _keystore_instance is None:
        _keystore_instance = SecureKeyStore()
    return _keystore_instance


# Convenience alias
keystore = property(lambda self: get_keystore())


# Helper functions for common operations
def store_api_key(key_type: str, key_id: str, value: str, **kwargs) -> bool:
    """Store an API key."""
    return get_keystore().store_key(key_type, key_id, value, **kwargs)


def get_api_key(key_type: str, key_id: str) -> Optional[str]:
    """Get an API key value."""
    return get_keystore().get_key(key_type, key_id)


def validate_api_key(key_type: str, key_id: str, value: str) -> bool:
    """Validate an API key."""
    return get_keystore().validate_key(key_type, key_id, value)


def rotate_api_key(key_type: str, key_id: str, **kwargs) -> Optional[str]:
    """Rotate an API key and return new value."""
    return get_keystore().rotate_key(key_type, key_id, **kwargs)


def list_api_keys(key_type: str = None) -> List[Dict[str, Any]]:
    """List API keys."""
    return get_keystore().list_keys(key_type)


__all__ = [
    'SecureKeyStore',
    'get_keystore',
    'store_api_key',
    'get_api_key',
    'validate_api_key',
    'rotate_api_key',
    'list_api_keys',
    'KEY_TYPES',
    'ENCRYPTION_AVAILABLE',
]
